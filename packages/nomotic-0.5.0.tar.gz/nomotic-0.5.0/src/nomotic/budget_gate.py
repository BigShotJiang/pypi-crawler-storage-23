"""Pre-Execution Budget Gate.

Enforcement layer that checks budget availability before an approved
action's execution handle is issued.  If budget is exhausted the action
is **denied** — not deferred, denied.

Three budget types are supported:
  * **Daily budget** — resets at UTC midnight.
  * **Monthly budget** — resets on the first of each month UTC.
  * **Per-action cost estimate** — caller provides expected cost in metadata.

Pre-execution reservations are written as pending records and settled when
the execution completes (success or failure).  Unsettled reservations older
than ``reservation_ttl_seconds`` (default 3600) are automatically expired.
"""

from __future__ import annotations

import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable

__all__ = [
    "BudgetExhaustedError",
    "BudgetGate",
    "BudgetGateResult",
    "BudgetLimit",
    "BudgetReservation",
]


# ── Data types ─────────────────────────────────────────────────────────


@dataclass
class BudgetLimit:
    """Budget limits for a cost group."""

    group_id: str
    daily_limit_usd: float | None = None
    monthly_limit_usd: float | None = None
    per_action_limit_usd: float | None = None
    reservation_ttl_seconds: int = 3600

    # UAHS health-based adjustment fields
    uahs_adjustment_enabled: bool = False
    """When True, per_action_limit is reduced when agent UAHS < threshold."""

    uahs_health_threshold: float = 0.5
    """UAHS overall_health score below which budget reduction applies."""

    uahs_reduction_factor: float = 0.20
    """Fraction by which per_action_limit is reduced.
    0.20 = reduce by 20%. Reduced limit is never less than 10% of original.
    Only applies when uahs_adjustment_enabled=True and per_action_limit set.
    """


@dataclass
class BudgetReservation:
    """A pre-execution cost reservation."""

    reservation_id: str  # nmbr-<uuid4>
    group_id: str
    agent_id: str
    action_id: str
    estimated_cost_usd: float
    reserved_at: float
    expires_at: float
    settled: bool = False
    settled_at: float | None = None
    actual_cost_usd: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class BudgetGateResult:
    """Result of a pre-execution budget gate check."""

    approved: bool
    group_id: str
    agent_id: str
    action_id: str
    estimated_cost_usd: float
    daily_used_usd: float
    daily_limit_usd: float | None
    monthly_used_usd: float
    monthly_limit_usd: float | None
    denial_reason: str | None = None
    reservation: BudgetReservation | None = None
    health_adjusted: bool = False
    health_score: float | None = None

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return d


# ── Exception ──────────────────────────────────────────────────────────


class BudgetExhaustedError(Exception):
    """Raised when the pre-execution budget gate denies execution."""

    def __init__(self, result: BudgetGateResult) -> None:
        self.result = result
        super().__init__(
            f"Budget exhausted for group '{result.group_id}': "
            f"{result.denial_reason}"
        )


# ── Budget Gate ────────────────────────────────────────────────────────


class BudgetGate:
    """Pre-execution budget enforcement gate.

    Thread-safe.  Manages reservations and settlements.

    Args:
        limits: List of :class:`BudgetLimit` objects per group.
        audit_store: Optional audit store for reading historical costs.
            If ``None``, only reservations are tracked.
        agent_group_map: Maps ``agent_id`` → ``group_id``.  If an agent
            is not in any group the budget gate is skipped for that agent.
    """

    def __init__(
        self,
        limits: list[BudgetLimit] | None = None,
        audit_store: Any | None = None,
        agent_group_map: dict[str, str] | None = None,
    ) -> None:
        self._limits: dict[str, BudgetLimit] = {
            lim.group_id: lim for lim in (limits or [])
        }
        self._audit_store = audit_store
        self._agent_group_map: dict[str, str] = dict(agent_group_map or {})
        self._reservations: list[BudgetReservation] = []
        self._lock = threading.Lock()
        self._uahs_accessor: Callable[[str], float | None] | None = None

    # ── Configuration ──────────────────────────────────────────────

    def add_limit(self, limit: BudgetLimit) -> None:
        """Register or replace a budget limit for a group."""
        with self._lock:
            self._limits[limit.group_id] = limit

    def assign_agent_to_group(self, agent_id: str, group_id: str) -> None:
        """Map an agent to a cost group."""
        with self._lock:
            self._agent_group_map[agent_id] = group_id

    def set_uahs_accessor(
        self, accessor: Callable[[str], float | None]
    ) -> None:
        """Register a callback that returns UAHS overall_health for an agent.

        Called as: accessor(agent_id) -> float | None
        Returns None if UAHS not available for this agent.
        """
        self._uahs_accessor = accessor

    def _get_effective_per_action_limit(
        self, agent_id: str, limit: BudgetLimit
    ) -> float | None:
        """Return per_action_limit with UAHS health adjustment applied.

        If adjustment is disabled, UAHS not available, or health >= threshold:
        returns limit.per_action_limit_usd unmodified.

        If health < threshold: returns reduced limit.
        Reduction floor: 10% of original (never lower).
        """
        base = limit.per_action_limit_usd
        if base is None:
            return None
        if not limit.uahs_adjustment_enabled:
            return base
        if self._uahs_accessor is None:
            return base

        health = self._uahs_accessor(agent_id)
        if health is None or health >= limit.uahs_health_threshold:
            return base

        reduced = base * (1.0 - limit.uahs_reduction_factor)
        floor = base * 0.10
        return max(reduced, floor)

    # ── Core gate ──────────────────────────────────────────────────

    def check_and_reserve(
        self,
        agent_id: str,
        action_id: str,
        estimated_cost_usd: float = 0.0,
    ) -> BudgetGateResult:
        """Check budget availability and create a reservation if approved.

        Flow:
        1. Look up agent's group_id.  If no group → approved.
        2. Find BudgetLimit for group_id.  If none → approved.
        3. Expire stale reservations for this group.
        4. Compute current spend (actual + reserved).
        5. Check per_action_limit_usd.
        6. Check daily_limit_usd.
        7. Check monthly_limit_usd.
        8. If all pass → create reservation, return approved.
        9. If any fail → return denied with reason.
        """
        with self._lock:
            group_id = self._agent_group_map.get(agent_id)
            if group_id is None:
                return BudgetGateResult(
                    approved=True,
                    group_id="",
                    agent_id=agent_id,
                    action_id=action_id,
                    estimated_cost_usd=estimated_cost_usd,
                    daily_used_usd=0.0,
                    daily_limit_usd=None,
                    monthly_used_usd=0.0,
                    monthly_limit_usd=None,
                )

            limit = self._limits.get(group_id)
            if limit is None:
                return BudgetGateResult(
                    approved=True,
                    group_id=group_id,
                    agent_id=agent_id,
                    action_id=action_id,
                    estimated_cost_usd=estimated_cost_usd,
                    daily_used_usd=0.0,
                    daily_limit_usd=None,
                    monthly_used_usd=0.0,
                    monthly_limit_usd=None,
                )

            # Expire stale reservations
            self._expire_stale_locked(group_id)

            # Compute current spend
            daily_actual, monthly_actual = self._actual_spend_locked(group_id)
            daily_reserved, monthly_reserved = self._reserved_spend_locked(group_id)
            daily_total = daily_actual + daily_reserved
            monthly_total = monthly_actual + monthly_reserved

            # Per-action limit (with UAHS health adjustment)
            effective_limit = self._get_effective_per_action_limit(agent_id, limit)
            _health_adjusted = (
                effective_limit is not None
                and effective_limit != limit.per_action_limit_usd
            )
            _health_score: float | None = None
            if self._uahs_accessor is not None:
                _health_score = self._uahs_accessor(agent_id)

            if (
                effective_limit is not None
                and estimated_cost_usd > effective_limit
            ):
                return BudgetGateResult(
                    approved=False,
                    group_id=group_id,
                    agent_id=agent_id,
                    action_id=action_id,
                    estimated_cost_usd=estimated_cost_usd,
                    daily_used_usd=daily_total,
                    daily_limit_usd=limit.daily_limit_usd,
                    monthly_used_usd=monthly_total,
                    monthly_limit_usd=limit.monthly_limit_usd,
                    denial_reason=(
                        f"Per-action cost ${estimated_cost_usd:.4f} exceeds "
                        f"limit ${effective_limit:.4f}"
                    ),
                    health_adjusted=_health_adjusted,
                    health_score=_health_score,
                )

            # Daily limit
            if (
                limit.daily_limit_usd is not None
                and daily_total + estimated_cost_usd > limit.daily_limit_usd
            ):
                return BudgetGateResult(
                    approved=False,
                    group_id=group_id,
                    agent_id=agent_id,
                    action_id=action_id,
                    estimated_cost_usd=estimated_cost_usd,
                    daily_used_usd=daily_total,
                    daily_limit_usd=limit.daily_limit_usd,
                    monthly_used_usd=monthly_total,
                    monthly_limit_usd=limit.monthly_limit_usd,
                    denial_reason=(
                        f"Daily budget would be exceeded: "
                        f"${daily_total + estimated_cost_usd:.4f} > "
                        f"${limit.daily_limit_usd:.4f}"
                    ),
                    health_adjusted=_health_adjusted,
                    health_score=_health_score,
                )

            # Monthly limit
            if (
                limit.monthly_limit_usd is not None
                and monthly_total + estimated_cost_usd > limit.monthly_limit_usd
            ):
                return BudgetGateResult(
                    approved=False,
                    group_id=group_id,
                    agent_id=agent_id,
                    action_id=action_id,
                    estimated_cost_usd=estimated_cost_usd,
                    daily_used_usd=daily_total,
                    daily_limit_usd=limit.daily_limit_usd,
                    monthly_used_usd=monthly_total,
                    monthly_limit_usd=limit.monthly_limit_usd,
                    denial_reason=(
                        f"Monthly budget would be exceeded: "
                        f"${monthly_total + estimated_cost_usd:.4f} > "
                        f"${limit.monthly_limit_usd:.4f}"
                    ),
                    health_adjusted=_health_adjusted,
                    health_score=_health_score,
                )

            # All checks passed — create reservation
            now = time.time()
            reservation = BudgetReservation(
                reservation_id=f"nmbr-{uuid.uuid4()}",
                group_id=group_id,
                agent_id=agent_id,
                action_id=action_id,
                estimated_cost_usd=estimated_cost_usd,
                reserved_at=now,
                expires_at=now + limit.reservation_ttl_seconds,
            )
            self._reservations.append(reservation)

            return BudgetGateResult(
                approved=True,
                group_id=group_id,
                agent_id=agent_id,
                action_id=action_id,
                estimated_cost_usd=estimated_cost_usd,
                daily_used_usd=daily_total,
                daily_limit_usd=limit.daily_limit_usd,
                monthly_used_usd=monthly_total,
                monthly_limit_usd=limit.monthly_limit_usd,
                reservation=reservation,
                health_adjusted=_health_adjusted,
                health_score=_health_score,
            )

    # ── Settlement ─────────────────────────────────────────────────

    def settle(
        self,
        reservation_id: str,
        actual_cost_usd: float,
    ) -> None:
        """Mark a reservation as settled with actual cost."""
        with self._lock:
            for r in self._reservations:
                if r.reservation_id == reservation_id and not r.settled:
                    r.settled = True
                    r.settled_at = time.time()
                    r.actual_cost_usd = actual_cost_usd
                    return
            raise ValueError(f"Reservation not found or already settled: {reservation_id}")

    # ── Expiration ─────────────────────────────────────────────────

    def expire_stale_reservations(self, group_id: str | None = None) -> int:
        """Expire reservations past their TTL.  Returns count expired."""
        with self._lock:
            return self._expire_stale_locked(group_id)

    def _expire_stale_locked(self, group_id: str | None = None) -> int:
        """Internal: expire stale reservations (caller holds lock)."""
        now = time.time()
        count = 0
        for r in self._reservations:
            if r.settled:
                continue
            if group_id is not None and r.group_id != group_id:
                continue
            if now >= r.expires_at:
                r.settled = True
                r.settled_at = now
                r.actual_cost_usd = 0.0
                count += 1
        return count

    # ── Queries ────────────────────────────────────────────────────

    def get_active_reservations(
        self,
        group_id: str | None = None,
    ) -> list[BudgetReservation]:
        """Return active (unsettled, non-expired) reservations."""
        with self._lock:
            now = time.time()
            result = []
            for r in self._reservations:
                if r.settled:
                    continue
                if now >= r.expires_at:
                    continue
                if group_id is not None and r.group_id != group_id:
                    continue
                result.append(r)
            return result

    def get_current_spend(
        self,
        group_id: str,
    ) -> dict[str, float]:
        """Return current spend including active reservations.

        Returns ``{"daily_usd": float, "monthly_usd": float}``.
        """
        with self._lock:
            self._expire_stale_locked(group_id)
            daily_actual, monthly_actual = self._actual_spend_locked(group_id)
            daily_reserved, monthly_reserved = self._reserved_spend_locked(group_id)
            return {
                "daily_usd": daily_actual + daily_reserved,
                "monthly_usd": monthly_actual + monthly_reserved,
            }

    # ── Internal spend computation ─────────────────────────────────

    def _actual_spend_locked(self, group_id: str) -> tuple[float, float]:
        """Read actual costs from audit store (caller holds lock).

        Returns ``(daily_cost, monthly_cost)``.
        """
        if self._audit_store is None:
            return 0.0, 0.0

        now = datetime.now(timezone.utc)
        midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        midnight_ts = midnight.timestamp()
        month_start_ts = month_start.timestamp()

        # Find agents in this group
        agents_in_group = [
            aid for aid, gid in self._agent_group_map.items() if gid == group_id
        ]

        daily_cost = 0.0
        monthly_cost = 0.0

        for agent_id in agents_in_group:
            try:
                records = self._audit_store.query_all(agent_id)
            except Exception:
                continue
            for rec in records:
                cost = getattr(rec, "parameters", {}).get("cost_usd", 0.0)
                ts = getattr(rec, "timestamp", 0.0)
                if ts >= midnight_ts:
                    daily_cost += cost
                if ts >= month_start_ts:
                    monthly_cost += cost

        return daily_cost, monthly_cost

    def _reserved_spend_locked(self, group_id: str) -> tuple[float, float]:
        """Sum of active reservations (caller holds lock).

        Returns ``(daily_reserved, monthly_reserved)``.
        Active = unsettled and not expired.
        """
        now = time.time()
        daily = 0.0
        monthly = 0.0
        for r in self._reservations:
            if r.group_id != group_id:
                continue
            if r.settled:
                continue
            if now >= r.expires_at:
                continue
            daily += r.estimated_cost_usd
            monthly += r.estimated_cost_usd
        return daily, monthly
