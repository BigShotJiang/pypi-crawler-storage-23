"""Output Validation Governance.

Evaluates agent-produced outputs before they reach users or trigger downstream
actions. This is the governance layer between 'what the agent said' and 'what
happens because of it'.

Operates after agent generation, before output delivery. Each output evaluation
produces an OutputVerdict with one of four dispositions:

  PASS     — output meets all governance requirements, deliver as-is
  BLOCK    — output must not be delivered (governance failure)
  REDACT   — deliver the output with sensitive content removed
  ESCALATE — deliver with delay, route to human review queue

Output evaluations are hash-chained in the audit trail alongside action evaluations.
Each evaluation links back to the governance seal from the action that produced it.
"""

from __future__ import annotations

import hashlib
import hmac as _hmac_mod
import json
import re
import time
import urllib.request
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable

__all__ = [
    "OUTPUT_BLOCK",
    "OUTPUT_ESCALATE",
    "OUTPUT_PASS",
    "OUTPUT_REDACT",
    "OutputCheckResult",
    "OutputGovernor",
    "OutputGovernorConfig",
    "OutputVerdict",
    "RedactionRecord",
]

# ── Output verdict type constants ────────────────────────────────────

OUTPUT_PASS = "PASS"
OUTPUT_BLOCK = "BLOCK"
OUTPUT_REDACT = "REDACT"
OUTPUT_ESCALATE = "ESCALATE"

# ── Audit event type constants ───────────────────────────────────────

AUDIT_OUTPUT_BLOCKED = "OUTPUT_BLOCKED"
AUDIT_OUTPUT_REDACTED = "OUTPUT_REDACTED"
AUDIT_OUTPUT_ESCALATED = "OUTPUT_ESCALATED"

# ── PII detection patterns ───────────────────────────────────────────

_PII_EMAIL = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
_PII_SSN = re.compile(r'\b\d{3}-\d{2}-\d{4}\b')
_PII_CREDIT_CARD = re.compile(r'\b(?:\d{4}[- ]){3}\d{4}\b')
_PII_NHS = re.compile(r'\b\d{3}\s\d{3}\s\d{4}\b')
_PII_PHONE = re.compile(r'\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b')

# ── Confidence calibration patterns ──────────────────────────────────

_OVERCONFIDENT_PATTERNS = [
    re.compile(r'\bI am certain that\b', re.IGNORECASE),
    re.compile(r'\bdefinitely\b', re.IGNORECASE),
    re.compile(r'\bThe current price is\b', re.IGNORECASE),
    re.compile(r'\bAs of today\b', re.IGNORECASE),
    re.compile(r'\bRight now\b', re.IGNORECASE),
    re.compile(r'\bI have verified\b', re.IGNORECASE),
    re.compile(r'\bI confirmed\b', re.IGNORECASE),
]

# ── Scope consistency patterns ───────────────────────────────────────

_SCOPE_PATTERNS = [
    re.compile(r'\badmin/', re.IGNORECASE),
    re.compile(r'\bbilling/', re.IGNORECASE),
    re.compile(r'\binternal/', re.IGNORECASE),
]


# ── Data classes ─────────────────────────────────────────────────────


@dataclass
class RedactionRecord:
    """Record of a single redaction applied to an output."""

    redaction_id: str           # "nmred-<uuid4>"
    check_name: str             # Which check triggered the redaction
    pattern_matched: str        # Description of what was matched (not the data itself)
    replacement: str            # What replaced it (e.g. "[REDACTED-EMAIL]")
    character_count: int        # Characters removed (for audit without exposing content)


@dataclass
class OutputCheckResult:
    """Result of a single output check."""

    check_name: str
    passed: bool
    score: float            # 0.0 (fail) to 1.0 (pass)
    reason: str
    redactions: list[RedactionRecord] = field(default_factory=list)
    # Populated by checks that produce REDACT rather than BLOCK


@dataclass
class OutputVerdict:
    """Result of output governance evaluation."""

    verdict: str                    # OUTPUT_PASS | OUTPUT_BLOCK | OUTPUT_REDACT | OUTPUT_ESCALATE
    output_id: str                  # "nmout-<uuid4>"
    agent_id: str
    action_id: str | None           # The action that produced this output (if known)
    seal_id: str | None             # The governance seal from that action

    checks_performed: list[str]     # Names of checks that ran
    checks_failed: list[str]        # Names of checks that failed
    check_results: list[OutputCheckResult]

    redactions: list[RedactionRecord]   # All redactions from all checks combined
    redacted_output: str | None         # Modified output text (None if verdict is PASS or BLOCK)

    ucs: float                      # Output confidence score [0.0-1.0], weighted avg of check scores
    reasoning: str                  # Human-readable summary

    evaluated_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "verdict": self.verdict,
            "output_id": self.output_id,
            "agent_id": self.agent_id,
            "action_id": self.action_id,
            "seal_id": self.seal_id,
            "checks_performed": self.checks_performed,
            "checks_failed": self.checks_failed,
            "check_results": [
                {
                    "check_name": cr.check_name,
                    "passed": cr.passed,
                    "score": cr.score,
                    "reason": cr.reason,
                    "redactions": [
                        {
                            "redaction_id": r.redaction_id,
                            "check_name": r.check_name,
                            "pattern_matched": r.pattern_matched,
                            "replacement": r.replacement,
                            "character_count": r.character_count,
                        }
                        for r in cr.redactions
                    ],
                }
                for cr in self.check_results
            ],
            "redactions": [
                {
                    "redaction_id": r.redaction_id,
                    "check_name": r.check_name,
                    "pattern_matched": r.pattern_matched,
                    "replacement": r.replacement,
                    "character_count": r.character_count,
                }
                for r in self.redactions
            ],
            "redacted_output": self.redacted_output,
            "ucs": self.ucs,
            "reasoning": self.reasoning,
            "evaluated_at": self.evaluated_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OutputVerdict:
        check_results = []
        for cr_data in data.get("check_results", []):
            redactions = [
                RedactionRecord(**r) for r in cr_data.get("redactions", [])
            ]
            check_results.append(OutputCheckResult(
                check_name=cr_data["check_name"],
                passed=cr_data["passed"],
                score=cr_data["score"],
                reason=cr_data["reason"],
                redactions=redactions,
            ))
        top_redactions = [
            RedactionRecord(**r) for r in data.get("redactions", [])
        ]
        return cls(
            verdict=data["verdict"],
            output_id=data["output_id"],
            agent_id=data["agent_id"],
            action_id=data.get("action_id"),
            seal_id=data.get("seal_id"),
            checks_performed=data.get("checks_performed", []),
            checks_failed=data.get("checks_failed", []),
            check_results=check_results,
            redactions=top_redactions,
            redacted_output=data.get("redacted_output"),
            ucs=data.get("ucs", 0.0),
            reasoning=data.get("reasoning", ""),
            evaluated_at=data.get("evaluated_at", 0.0),
        )


@dataclass
class OutputGovernorConfig:
    """Per-agent output governance configuration."""

    agent_id: str = ""
    enabled_checks: list[str] = field(default_factory=lambda: [
        "pii_leakage",
        "scope_consistency",
        "content_safety",
    ])
    # Default checks. Add "confidence_calibration" and "instruction_compliance" for full suite.

    block_on_pii_leakage: bool = True
    pii_sensitivity: str = "medium"    # "low" | "medium" | "high"
    # "high" = also detect partial patterns; "low" = only full SSN/credit card/health ID

    content_safety_categories: list[str] = field(default_factory=list)
    # Custom prohibited content categories for this agent

    allowed_target_references: set[str] = field(default_factory=set)
    # Targets this agent is permitted to reference in outputs
    # If empty, scope is not enforced on output content

    custom_validators: list[Any] = field(default_factory=list)
    # Callables: (output_text: str, action_id: str | None) -> OutputCheckResult

    instruction_set: list[str] = field(default_factory=list)
    # Constraint strings for instruction_compliance check

    external_validator_url: str | None = None
    """URL to POST output for external content validation.
    When set and enable_content_safety=True, the content_safety check
    calls this URL in addition to built-in checks.
    On timeout or error: falls back to built-in check silently.
    """

    external_validator_secret: str | None = None
    """HMAC signing secret for X-Nomotic-Signature header.
    Uses same signing scheme as WebhookDispatcher (sha256=<hex>).
    """

    external_validator_timeout_seconds: float = 2.0
    """Timeout for external validator HTTP call.
    On timeout: fall back to built-in content safety check.
    """

    external_validator_weight: float = 1.0
    """Blend weight of external score vs built-in (0.0-1.0).
    1.0 = use only external score when available.
    0.5 = average of external and built-in.
    0.0 = ignore external score (built-in only).
    """


# ── OutputGovernor ───────────────────────────────────────────────────


class OutputGovernor:
    """Evaluates agent-produced outputs before operational impact."""

    def __init__(self, audit_store: Any | None = None, webhook_dispatcher: Any | None = None) -> None:
        self._configs: dict[str, OutputGovernorConfig] = {}
        self._audit_store = audit_store
        self._webhook_dispatcher = webhook_dispatcher
        self._verdict_listeners: list[Callable[[OutputVerdict], None]] = []

    # ── Configuration ────────────────────────────────────────────────

    def configure_agent(self, agent_id: str, **kwargs: Any) -> None:
        """Create or update an OutputGovernorConfig for *agent_id*.

        ``kwargs`` map to OutputGovernorConfig fields.  Merges into existing
        config if already present.
        """
        if agent_id in self._configs:
            config = self._configs[agent_id]
            for key, value in kwargs.items():
                if hasattr(config, key):
                    setattr(config, key, value)
        else:
            config = OutputGovernorConfig(agent_id=agent_id, **kwargs)
            self._configs[agent_id] = config

    def add_verdict_listener(self, listener: Callable[[OutputVerdict], None]) -> None:
        """Register a listener called after every output evaluation."""
        self._verdict_listeners.append(listener)

    # ── Main evaluation ──────────────────────────────────────────────

    def evaluate(
        self,
        output: str,
        agent_id: str,
        output_type: str = "text",
        action_id: str | None = None,
        seal_id: str | None = None,
        destination: str = "unknown",
    ) -> OutputVerdict:
        """Evaluate an agent-produced output through all enabled checks.

        Args:
            output: The text output to evaluate.
            agent_id: Which agent produced this output.
            output_type: Type of output (e.g. "text").
            action_id: The action that produced this output (if known).
            seal_id: The governance seal from that action.
            destination: Where the output is going ("user", "api", etc).

        Returns:
            OutputVerdict with disposition and details.
        """
        config = self._configs.get(agent_id, OutputGovernorConfig(agent_id=agent_id))

        check_results: list[OutputCheckResult] = []

        # Dispatch table for built-in checks
        check_dispatch: dict[str, Callable[[str, OutputGovernorConfig], OutputCheckResult]] = {
            "pii_leakage": self._check_pii_leakage,
            "scope_consistency": self._check_scope_consistency,
            "content_safety": self._check_content_safety,
            "confidence_calibration": self._check_confidence_calibration,
            "instruction_compliance": self._check_instruction_compliance,
        }

        for check_name in config.enabled_checks:
            handler = check_dispatch.get(check_name)
            if handler is not None:
                check_results.append(handler(output, config))

        # Run custom validators
        for validator in config.custom_validators:
            result = validator(output, action_id)
            if isinstance(result, OutputCheckResult):
                check_results.append(result)

        # Determine verdict type
        checks_performed = [cr.check_name for cr in check_results]
        checks_failed = [cr.check_name for cr in check_results if not cr.passed]

        all_redactions: list[RedactionRecord] = []
        for cr in check_results:
            all_redactions.extend(cr.redactions)

        # Determine overall verdict
        verdict_type = OUTPUT_PASS
        has_escalation = False

        for cr in check_results:
            if not cr.passed:
                if cr.check_name == "confidence_calibration":
                    has_escalation = True
                elif cr.redactions:
                    # Check produced redactions — REDACT rather than BLOCK
                    if verdict_type != OUTPUT_BLOCK:
                        verdict_type = OUTPUT_REDACT
                elif cr.check_name == "pii_leakage" and config.block_on_pii_leakage:
                    verdict_type = OUTPUT_BLOCK
                else:
                    verdict_type = OUTPUT_BLOCK
            elif cr.redactions:
                # Check passed but produced redactions (e.g. PII with block=False)
                if verdict_type == OUTPUT_PASS:
                    verdict_type = OUTPUT_REDACT

        # Escalation only if nothing else blocked
        if has_escalation and verdict_type == OUTPUT_PASS:
            verdict_type = OUTPUT_ESCALATE

        # Compute UCS as weighted average of check scores (equal weights)
        if check_results:
            ucs = sum(cr.score for cr in check_results) / len(check_results)
        else:
            ucs = 1.0

        # Build redacted output if verdict is REDACT
        redacted_output: str | None = None
        if verdict_type == OUTPUT_REDACT and all_redactions:
            redacted_output = output
            for rd in all_redactions:
                redacted_output = redacted_output.replace(
                    rd.pattern_matched, rd.replacement, 1
                ) if rd.pattern_matched in redacted_output else redacted_output
            # Also do regex-based replacement for PII patterns
            redacted_output = self._apply_redactions(output, all_redactions, config)

        # Build reasoning
        if verdict_type == OUTPUT_PASS:
            reasoning = "All output checks passed"
        elif verdict_type == OUTPUT_BLOCK:
            reasoning = f"Output blocked — failed checks: {', '.join(checks_failed)}"
        elif verdict_type == OUTPUT_REDACT:
            reasoning = f"Output redacted — {len(all_redactions)} redaction(s) applied"
        else:
            reasoning = f"Output escalated for human review — failed checks: {', '.join(checks_failed)}"

        output_verdict = OutputVerdict(
            verdict=verdict_type,
            output_id=f"nmout-{uuid.uuid4()}",
            agent_id=agent_id,
            action_id=action_id,
            seal_id=seal_id,
            checks_performed=checks_performed,
            checks_failed=checks_failed,
            check_results=check_results,
            redactions=all_redactions,
            redacted_output=redacted_output,
            ucs=round(ucs, 4),
            reasoning=reasoning,
        )

        # Write audit record
        self._write_audit_record(output_verdict)

        # Notify webhook for non-PASS verdicts
        self._notify_webhook(output_verdict)

        # Notify listeners
        for listener in self._verdict_listeners:
            listener(output_verdict)

        return output_verdict

    # ── Built-in checks ──────────────────────────────────────────────

    def _check_pii_leakage(self, output: str, config: OutputGovernorConfig) -> OutputCheckResult:
        """Detect PII patterns in the output."""
        sensitivity = config.pii_sensitivity
        redactions: list[RedactionRecord] = []

        # Build pattern list based on sensitivity
        patterns: list[tuple[re.Pattern[str], str, str]] = []

        # Low: SSN + credit card only
        patterns.append((_PII_SSN, "SSN pattern", "[REDACTED-SSN]"))
        patterns.append((_PII_CREDIT_CARD, "credit card pattern", "[REDACTED-CC]"))

        if sensitivity in ("medium", "high"):
            patterns.append((_PII_EMAIL, "email address", "[REDACTED-EMAIL]"))

        if sensitivity == "high":
            patterns.append((_PII_NHS, "NHS number pattern", "[REDACTED-NHS]"))
            patterns.append((_PII_PHONE, "phone number pattern", "[REDACTED-PHONE]"))

        found_any = False
        for pattern, description, replacement in patterns:
            for match in pattern.finditer(output):
                found_any = True
                redactions.append(RedactionRecord(
                    redaction_id=f"nmred-{uuid.uuid4()}",
                    check_name="pii_leakage",
                    pattern_matched=match.group(),
                    replacement=replacement,
                    character_count=len(match.group()),
                ))

        if found_any:
            if config.block_on_pii_leakage:
                return OutputCheckResult(
                    check_name="pii_leakage",
                    passed=False,
                    score=0.0,
                    reason=f"PII detected: {len(redactions)} pattern(s) found",
                    redactions=[],  # No redactions when blocking
                )
            else:
                return OutputCheckResult(
                    check_name="pii_leakage",
                    passed=True,
                    score=0.5,
                    reason=f"PII detected but redaction mode: {len(redactions)} pattern(s) found",
                    redactions=redactions,
                )

        return OutputCheckResult(
            check_name="pii_leakage",
            passed=True,
            score=1.0,
            reason="No PII patterns detected",
        )

    def _check_scope_consistency(self, output: str, config: OutputGovernorConfig) -> OutputCheckResult:
        """Check if the output references targets outside agent scope."""
        if not config.allowed_target_references:
            return OutputCheckResult(
                check_name="scope_consistency",
                passed=True,
                score=1.0,
                reason="No scope boundary configured for output validation",
            )

        violations: list[str] = []
        for pattern in _SCOPE_PATTERNS:
            for match in pattern.finditer(output):
                matched_text = match.group().strip("/")
                # Check if any allowed reference contains this prefix
                is_allowed = any(
                    matched_text.lower() in ref.lower()
                    for ref in config.allowed_target_references
                )
                if not is_allowed:
                    violations.append(matched_text)

        if violations:
            return OutputCheckResult(
                check_name="scope_consistency",
                passed=False,
                score=0.3,
                reason=f"Output references target outside agent scope: {', '.join(violations)}",
            )

        return OutputCheckResult(
            check_name="scope_consistency",
            passed=True,
            score=1.0,
            reason="Output references within agent scope",
        )

    def _call_external_validator(
        self,
        output_text: str,
        agent_id: str,
        config: OutputGovernorConfig,
    ) -> OutputCheckResult | None:
        """POST output to external validator. Returns result or None on failure.

        Request body (JSON):
            {"output": str, "agent_id": str, "timestamp": float}

        Expected response (JSON):
            {"score": float,           # 0.0=unsafe, 1.0=safe
             "reasoning": str,        # optional
             "categories": [str]}     # optional flagged categories

        On timeout, connection error, or malformed response: return None.
        Caller falls back to built-in check when None is returned.
        """
        if not config.external_validator_url:
            return None

        try:
            payload = json.dumps({
                "output": output_text,
                "agent_id": agent_id,
                "timestamp": time.time(),
            }, separators=(",", ":")).encode("utf-8")

            headers: dict[str, str] = {
                "Content-Type": "application/json",
                "User-Agent": "nomotic-output-governor/0.5.0",
            }
            if config.external_validator_secret:
                sig = _hmac_mod.new(
                    config.external_validator_secret.encode("utf-8"),
                    payload,
                    hashlib.sha256,
                ).hexdigest()
                headers["X-Nomotic-Signature"] = f"sha256={sig}"
                headers["X-Nomotic-Signature-Version"] = "v1"

            req = urllib.request.Request(
                config.external_validator_url,
                data=payload,
                headers=headers,
                method="POST",
            )
            with urllib.request.urlopen(
                req, timeout=config.external_validator_timeout_seconds
            ) as resp:
                result = json.loads(resp.read().decode("utf-8"))

            score = float(result.get("score", 1.0))
            score = max(0.0, min(1.0, score))  # Clamp to [0, 1]
            reason = result.get(
                "reasoning", f"External validator score: {score:.2f}"
            )
            return OutputCheckResult(
                check_name="content_safety_external",
                score=score,
                reason=reason,
                passed=score >= 0.5,
            )
        except Exception:
            return None  # Silently fall back to built-in

    def _check_content_safety(self, output: str, config: OutputGovernorConfig) -> OutputCheckResult:
        """Check for prohibited content categories."""
        # Compute built-in result
        if not config.content_safety_categories:
            internal_result = OutputCheckResult(
                check_name="content_safety",
                passed=True,
                score=1.0,
                reason="No content safety categories configured",
            )
        else:
            output_lower = output.lower()
            matched_categories: list[str] = []
            for category in config.content_safety_categories:
                if category.lower() in output_lower:
                    matched_categories.append(category)

            if matched_categories:
                internal_result = OutputCheckResult(
                    check_name="content_safety",
                    passed=False,
                    score=0.0,
                    reason=f"Content safety violation: matched categories {matched_categories}",
                )
            else:
                internal_result = OutputCheckResult(
                    check_name="content_safety",
                    passed=True,
                    score=1.0,
                    reason="No prohibited content detected",
                )

        # Attempt external validation if configured
        if config.external_validator_url:
            external_result = self._call_external_validator(
                output, config.agent_id, config
            )
            if external_result is not None and config.external_validator_weight > 0:
                w = min(1.0, max(0.0, config.external_validator_weight))
                blended_score = (
                    internal_result.score * (1.0 - w)
                    + external_result.score * w
                )
                combined_reason = (
                    f"Built-in: {internal_result.reason} | "
                    f"External ({w:.0%} weight): {external_result.reason}"
                )
                return OutputCheckResult(
                    check_name="content_safety",
                    score=blended_score,
                    reason=combined_reason,
                    passed=blended_score >= 0.5,
                )

        return internal_result

    def _check_confidence_calibration(self, output: str, config: OutputGovernorConfig) -> OutputCheckResult:
        """Check for overconfident assertion patterns."""
        for pattern in _OVERCONFIDENT_PATTERNS:
            match = pattern.search(output)
            if match:
                return OutputCheckResult(
                    check_name="confidence_calibration",
                    passed=False,
                    score=0.6,
                    reason=f"Overconfident assertion detected: '{match.group()}'",
                )

        return OutputCheckResult(
            check_name="confidence_calibration",
            passed=True,
            score=1.0,
            reason="No overconfident assertions detected",
        )

    def _check_instruction_compliance(self, output: str, config: OutputGovernorConfig) -> OutputCheckResult:
        """Check output against configured instruction constraints."""
        if not config.instruction_set:
            return OutputCheckResult(
                check_name="instruction_compliance",
                passed=True,
                score=1.0,
                reason="No instruction set configured",
            )

        output_lower = output.lower()
        violations: list[str] = []

        for instruction in config.instruction_set:
            instruction_lower = instruction.lower()
            # Check for "do not" instructions — if the output contains the prohibited thing
            if instruction_lower.startswith("do not "):
                prohibited = instruction_lower[len("do not "):]
                if prohibited in output_lower:
                    violations.append(instruction)
            # Check for "no " instructions
            elif instruction_lower.startswith("no "):
                prohibited = instruction_lower[len("no "):]
                if prohibited in output_lower:
                    violations.append(instruction)

        if violations:
            return OutputCheckResult(
                check_name="instruction_compliance",
                passed=False,
                score=0.2,
                reason=f"Instruction violation: {', '.join(violations)}",
            )

        return OutputCheckResult(
            check_name="instruction_compliance",
            passed=True,
            score=1.0,
            reason="Output complies with all configured instructions",
        )

    # ── Redaction application ────────────────────────────────────────

    def _apply_redactions(
        self,
        output: str,
        redactions: list[RedactionRecord],
        config: OutputGovernorConfig,
    ) -> str:
        """Apply redactions to the output text using regex patterns."""
        result = output
        sensitivity = config.pii_sensitivity

        # Apply in reverse order of pattern specificity to avoid overlaps
        patterns: list[tuple[re.Pattern[str], str]] = []
        patterns.append((_PII_SSN, "[REDACTED-SSN]"))
        patterns.append((_PII_CREDIT_CARD, "[REDACTED-CC]"))

        if sensitivity in ("medium", "high"):
            patterns.append((_PII_EMAIL, "[REDACTED-EMAIL]"))

        if sensitivity == "high":
            patterns.append((_PII_NHS, "[REDACTED-NHS]"))
            patterns.append((_PII_PHONE, "[REDACTED-PHONE]"))

        for pattern, replacement in patterns:
            result = pattern.sub(replacement, result)

        return result

    # ── Audit ────────────────────────────────────────────────────────

    def _write_audit_record(self, verdict: OutputVerdict) -> None:
        """Write an OUTPUT_EVALUATION record to the audit store."""
        if self._audit_store is None:
            return

        record_dict: dict[str, Any] = {
            "record_type": "OUTPUT_EVALUATION",
            "record_id": verdict.output_id,
            "output_id": verdict.output_id,
            "agent_id": verdict.agent_id,
            "action_id": verdict.action_id or "",
            "seal_id": verdict.seal_id or "",
            "verdict": verdict.verdict,
            "checks_failed": verdict.checks_failed,
            "redaction_count": len(verdict.redactions),
            "ucs": verdict.ucs,
            "evaluated_at": verdict.evaluated_at,
            "timestamp": verdict.evaluated_at,
            "action_type": "output_evaluation",
            "action_target": verdict.agent_id,
            "tier": 0,
            "trust_score": 0.0,
            "trust_delta": 0.0,
            "trust_trend": "stable",
            "severity": "alert" if verdict.verdict != OUTPUT_PASS else "info",
            "justification": verdict.reasoning,
        }

        # Hash chaining
        previous_hash = self._audit_store.get_last_hash(verdict.agent_id)
        record_dict["previous_hash"] = previous_hash
        hashable = dict(record_dict)
        hashable.pop("record_hash", None)
        canonical = json.dumps(hashable, sort_keys=True, separators=(",", ":"))
        record_hash = "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        record_dict["record_hash"] = record_hash

        # Write using the LogStore's append method via PersistentLogRecord
        from nomotic.audit_store import PersistentLogRecord

        log_record = PersistentLogRecord(
            record_id=verdict.output_id,
            timestamp=verdict.evaluated_at,
            agent_id=verdict.agent_id,
            action_type="output_evaluation",
            action_target=verdict.agent_id,
            verdict=verdict.verdict,
            ucs=verdict.ucs,
            tier=0,
            trust_score=0.0,
            trust_delta=0.0,
            trust_trend="stable",
            severity="alert" if verdict.verdict != OUTPUT_PASS else "info",
            justification=verdict.reasoning,
            parameters={
                "record_type": "OUTPUT_EVALUATION",
                "output_id": verdict.output_id,
                "action_id": verdict.action_id or "",
                "seal_id": verdict.seal_id or "",
                "checks_failed": verdict.checks_failed,
                "redaction_count": len(verdict.redactions),
            },
            previous_hash=previous_hash,
            record_hash=record_hash,
        )
        self._audit_store.append(log_record)

    # ── Webhook notification ─────────────────────────────────────────

    def _notify_webhook(self, verdict: OutputVerdict) -> None:
        """Notify webhook dispatcher for non-PASS verdicts."""
        if verdict.verdict == OUTPUT_PASS:
            return

        if self._webhook_dispatcher is None:
            return

        event_type_map = {
            OUTPUT_BLOCK: AUDIT_OUTPUT_BLOCKED,
            OUTPUT_REDACT: AUDIT_OUTPUT_REDACTED,
            OUTPUT_ESCALATE: AUDIT_OUTPUT_ESCALATED,
        }

        event_type = event_type_map.get(verdict.verdict)
        if event_type is None:
            return

        from nomotic.webhooks import WebhookEvent

        event = WebhookEvent(
            event_type=event_type,
            event_id=verdict.output_id,
            timestamp=verdict.evaluated_at,
            agent_id=verdict.agent_id,
            payload={
                "verdict": verdict.verdict,
                "output_id": verdict.output_id,
                "action_id": verdict.action_id,
                "seal_id": verdict.seal_id,
                "checks_failed": verdict.checks_failed,
                "ucs": verdict.ucs,
                "reasoning": verdict.reasoning,
            },
        )
        self._webhook_dispatcher.dispatch(event)
