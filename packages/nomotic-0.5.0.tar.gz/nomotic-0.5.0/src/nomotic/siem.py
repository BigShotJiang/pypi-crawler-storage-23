"""SIEM exporter — translates audit records into standard SIEM formats.

Produces formatted output in Common Event Format (CEF), Syslog (RFC 5424),
and JSON Lines (JSONL) for ingestion by ArcSight, QRadar, Splunk, Elastic,
Datadog, and other SIEM tools.

This is a thin translation layer, not a transport layer — it produces
formatted strings that users pipe to their SIEM's ingestion endpoint.

Zero runtime dependencies.  All formatting is string manipulation with
stdlib only.

Usage::

    from nomotic.siem import SIEMExporter

    exporter = SIEMExporter(format="cef")
    line = exporter.export_record(audit_record)

    exporter = SIEMExporter(format="jsonl")
    for line in exporter.export_stream(trail):
        send_to_siem(line)
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Iterator

if TYPE_CHECKING:
    from nomotic.audit import AuditRecord, AuditTrail
    from nomotic.sanitize import Sanitizer

__all__ = ["SIEMExporter"]


# ── Severity mappings ──────────────────────────────────────────────────

_CEF_SEVERITY: dict[str, int] = {
    "info": 1,
    "warning": 4,
    "alert": 7,
    "critical": 10,
}

# RFC 5424 severity: info=6, warning=4, alert(err)=2, critical=1
_SYSLOG_SEVERITY: dict[str, int] = {
    "info": 6,
    "warning": 4,
    "alert": 2,
    "critical": 1,
}


# ── Helpers ────────────────────────────────────────────────────────────


def _escape_cef(value: str) -> str:
    """Escape special characters for CEF extension values.

    CEF requires backslash, equals and newline escaping in extension values.
    Pipe characters in the header portion are escaped separately.
    """
    return (
        value
        .replace("\\", "\\\\")
        .replace("=", "\\=")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
    )


def _escape_cef_header(value: str) -> str:
    """Escape pipe and backslash characters in CEF header fields."""
    return value.replace("\\", "\\\\").replace("|", "\\|")


def _escape_syslog_sd(value: str) -> str:
    r"""Escape characters in syslog structured data param values.

    RFC 5424 §6.3.3: '"', '\\', and ']' must be escaped.
    """
    return (
        value
        .replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("]", "\\]")
    )


def _human_event_name(context_code: str) -> str:
    """Convert a context code to a human-readable event name.

    ``"GOVERNANCE.ALLOW"`` -> ``"Governance Decision: Allow"``
    ``"SECURITY.INJECTION_ATTEMPT"`` -> ``"Security: Injection Attempt"``
    """
    parts = context_code.split(".", 1)
    category = parts[0].capitalize()
    if len(parts) > 1:
        specific = parts[1].replace("_", " ").title()
    else:
        specific = "Event"
    return f"{category}: {specific}"


def _epoch_ms(ts: float) -> int:
    """Convert a Unix timestamp (seconds) to epoch milliseconds."""
    return int(ts * 1000)


def _iso8601(ts: float) -> str:
    """Convert a Unix timestamp to ISO 8601 with Z suffix."""
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%S.%f"
    )[:-3] + "Z"


# ── SIEMExporter ──────────────────────────────────────────────────────


class SIEMExporter:
    """Translates Nomotic audit records into SIEM-ingestible formats.

    Supports CEF (ArcSight/QRadar/Splunk), Syslog RFC 5424, and JSONL
    (Elastic/Datadog/Splunk HEC).

    Parameters
    ----------
    format:
        Output format — ``"cef"``, ``"syslog"``, or ``"jsonl"``.
    hostname:
        Hostname for syslog messages.  Defaults to ``"nomotic"``.
    facility:
        Syslog facility code.  Defaults to ``16`` (local0).
    include_dimension_scores:
        If ``True``, include per-dimension scores in the output.
    include_drift:
        If ``True``, include drift data when available.
    max_message_length:
        Maximum length for justification/message fields.
    sanitizer:
        Optional :class:`~nomotic.sanitize.Sanitizer` instance.
        When provided, record data is sanitized before formatting.
    """

    _FORMATS = ("cef", "syslog", "jsonl")

    def __init__(
        self,
        format: str = "jsonl",
        hostname: str = "nomotic",
        facility: int = 16,
        include_dimension_scores: bool = False,
        include_drift: bool = True,
        max_message_length: int = 1023,
        sanitizer: Sanitizer | None = None,
    ) -> None:
        if format not in self._FORMATS:
            raise ValueError(
                f"Unknown format {format!r}. Must be one of {self._FORMATS}"
            )
        self._format = format
        self._hostname = hostname
        self._facility = facility
        self._include_dimension_scores = include_dimension_scores
        self._include_drift = include_drift
        self._max_message_length = max_message_length
        self._sanitizer = sanitizer

    # ── Public API ────────────────────────────────────────────────

    def export_record(self, record: AuditRecord) -> str:
        """Export a single audit record as a formatted string."""
        data = self._prepare(record)
        if self._format == "cef":
            return self._format_cef(data)
        if self._format == "syslog":
            return self._format_syslog(data)
        return self._format_jsonl(data)

    def export_trail(self, trail: AuditTrail, **query_kwargs: Any) -> str:
        """Export matching records from a trail.

        Returns newline-separated formatted strings.  Accepts any keyword
        arguments that :meth:`AuditTrail.query` supports.
        """
        lines = list(self.export_stream(trail, **query_kwargs))
        return "\n".join(lines)

    def export_stream(
        self, trail: AuditTrail, **query_kwargs: Any
    ) -> Iterator[str]:
        """Yield formatted records one at a time for streaming to SIEM."""
        records = trail.query(**query_kwargs)
        # query() returns newest-first; SIEM ingestion usually wants chronological
        for record in reversed(records):
            yield self.export_record(record)

    # ── Internal helpers ──────────────────────────────────────────

    def _prepare(self, record: AuditRecord) -> dict[str, Any]:
        """Extract a flat dict from the record for formatting.

        If a sanitizer is configured, applies sanitization to string
        fields before formatting.
        """
        d: dict[str, Any] = {
            "timestamp": record.timestamp,
            "context_code": record.context_code,
            "severity": record.severity,
            "agent_id": record.agent_id,
            "owner_id": record.owner_id,
            "user_id": record.user_id,
            "action_type": record.action_type,
            "action_target": record.action_target,
            "verdict": record.verdict,
            "ucs": record.ucs,
            "trust_score": record.trust_score,
            "tier": record.tier,
            "justification": record.justification,
            "record_id": record.record_id,
            "record_hash": record.record_hash,
            "previous_hash": record.previous_hash,
        }

        if self._include_dimension_scores and record.dimension_scores:
            d["dimension_scores"] = record.dimension_scores

        if self._include_drift:
            if record.drift_overall is not None:
                d["drift_overall"] = record.drift_overall
            if record.drift_severity is not None:
                d["drift_severity"] = record.drift_severity

        # Sanitize if configured
        if self._sanitizer is not None:
            d = self._sanitizer.sanitize_dict(d)

        # Truncate justification
        msg = str(d.get("justification", ""))
        if len(msg) > self._max_message_length:
            msg = msg[: self._max_message_length]
        d["justification"] = msg

        return d

    # ── CEF formatting ────────────────────────────────────────────

    def _format_cef(self, data: dict[str, Any]) -> str:
        """Format as CEF (Common Event Format).

        ``CEF:0|Nomotic|GovernanceRuntime|1.0|<event_id>|<event_name>|<severity>|<extensions>``
        """
        event_id = _escape_cef_header(data["context_code"])
        event_name = _escape_cef_header(_human_event_name(data["context_code"]))
        severity = _CEF_SEVERITY.get(data["severity"], 1)

        # Build extension key=value pairs
        ext_parts: list[str] = []
        ext_parts.append(f"src={_escape_cef(data['agent_id'])}")
        ext_parts.append(f"dst={_escape_cef(data['action_target'])}")
        ext_parts.append(f"act={_escape_cef(data['action_type'])}")
        ext_parts.append(f"outcome={_escape_cef(data['verdict'])}")
        ext_parts.append(f"cs1={_escape_cef(str(data['ucs']))}")
        ext_parts.append("cs1Label=UnifiedConfidenceScore")
        ext_parts.append(f"cs2={_escape_cef(str(data['trust_score']))}")
        ext_parts.append("cs2Label=TrustScore")
        ext_parts.append(f"cn1={data['tier']}")
        ext_parts.append("cn1Label=EvaluationTier")
        ext_parts.append(f"msg={_escape_cef(data['justification'])}")
        ext_parts.append(f"rt={_epoch_ms(data['timestamp'])}")

        if self._include_dimension_scores and "dimension_scores" in data:
            for i, dim in enumerate(data["dimension_scores"]):
                label = dim.get("dimension_name", f"dim{i}")
                score = dim.get("score", 0)
                ext_parts.append(f"cs{i + 3}={score}")
                ext_parts.append(f"cs{i + 3}Label={_escape_cef(label)}")

        if self._include_drift:
            if "drift_overall" in data:
                ext_parts.append(
                    f"flexNumber1={data['drift_overall']}"
                )
                ext_parts.append("flexNumber1Label=DriftScore")
            if "drift_severity" in data:
                ext_parts.append(
                    f"flexString1={_escape_cef(data['drift_severity'])}"
                )
                ext_parts.append("flexString1Label=DriftSeverity")

        extensions = " ".join(ext_parts)
        return (
            f"CEF:0|Nomotic|GovernanceRuntime|1.0|{event_id}"
            f"|{event_name}|{severity}|{extensions}"
        )

    # ── Syslog RFC 5424 formatting ───────────────────────────────

    def _format_syslog(self, data: dict[str, Any]) -> str:
        """Format as RFC 5424 syslog message.

        ``<priority>1 <timestamp> <hostname> nomotic <pid> <msg_id> <structured_data> <message>``
        """
        sev = _SYSLOG_SEVERITY.get(data["severity"], 6)
        priority = self._facility * 8 + sev
        timestamp = _iso8601(data["timestamp"])
        pid = os.getpid()
        msg_id = data["context_code"]

        # Build structured data
        sd_params: list[str] = []
        sd_params.append(f'agent="{_escape_syslog_sd(data["agent_id"])}"')
        sd_params.append(f'action="{_escape_syslog_sd(data["action_type"])}"')
        sd_params.append(f'target="{_escape_syslog_sd(data["action_target"])}"')
        sd_params.append(f'verdict="{_escape_syslog_sd(data["verdict"])}"')
        sd_params.append(f'ucs="{data["ucs"]}"')
        sd_params.append(f'trust="{data["trust_score"]}"')
        sd_params.append(f'tier="{data["tier"]}"')

        if self._include_drift:
            if "drift_overall" in data:
                sd_params.append(f'drift="{data["drift_overall"]}"')
            if "drift_severity" in data:
                sd_params.append(
                    f'driftSeverity="{_escape_syslog_sd(data["drift_severity"])}"'
                )

        sd = "[nomotic@49152 " + " ".join(sd_params) + "]"
        message = data["justification"]

        return (
            f"<{priority}>1 {timestamp} {self._hostname} nomotic"
            f" {pid} {msg_id} {sd} {message}"
        )

    # ── JSONL formatting ─────────────────────────────────────────

    def _format_jsonl(self, data: dict[str, Any]) -> str:
        """Format as a single JSON line following ECS conventions."""
        obj: dict[str, Any] = {
            "timestamp": _iso8601(data["timestamp"]),
            "event.category": "governance",
            "event.action": data["action_type"],
            "event.outcome": data["verdict"].lower(),
            "agent.id": data["agent_id"],
            "agent.trust": data["trust_score"],
            "governance.verdict": data["verdict"],
            "governance.ucs": data["ucs"],
            "governance.tier": data["tier"],
            "governance.context_code": data["context_code"],
            "action.type": data["action_type"],
            "action.target": data["action_target"],
            "severity": data["severity"],
            "message": data["justification"],
            "audit.record_id": data["record_id"],
            "audit.record_hash": data["record_hash"],
            "audit.previous_hash": data["previous_hash"],
        }

        if self._include_dimension_scores and "dimension_scores" in data:
            obj["governance.dimension_scores"] = data["dimension_scores"]

        if self._include_drift:
            if "drift_overall" in data:
                obj["governance.drift_score"] = data["drift_overall"]
            if "drift_severity" in data:
                obj["governance.drift_severity"] = data["drift_severity"]

        return json.dumps(obj, separators=(",", ":"))
