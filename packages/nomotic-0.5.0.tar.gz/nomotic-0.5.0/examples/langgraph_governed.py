#!/usr/bin/env python3
"""LangGraph + Nomotic Governance Example.

Shows two integration patterns:
  1. governance_node -- a LangGraph node that evaluates governance
  2. govern_langchain_tools -- wraps LangChain tools with governance

Prerequisites:
    pip install nomotic langgraph langchain

Usage:
    python examples/langgraph_governed.py
"""

from __future__ import annotations

# ── Pattern 1: Governance as a graph node ────────────────────────────

# In a real LangGraph project you would build a StateGraph:
#
#   from langgraph.graph import StateGraph
#   from nomotic.integrations.langgraph_adapter import governance_node, route_on_governance
#
#   graph = StateGraph(AgentState)
#   graph.add_node("think", agent_node)
#   graph.add_node("govern", governance_node("claims-bot"))
#   graph.add_node("execute", tool_node)
#   graph.add_node("denied", denied_node)
#
#   graph.add_edge("think", "govern")
#   graph.add_conditional_edges("govern", route_on_governance)
#
# Here we demonstrate the node function directly:

from nomotic.integrations.langgraph_adapter import (  # noqa: E402
    governance_node,
    route_on_governance,
)

# Create the governance node (one line of integration code)
govern = governance_node(
    "claims-bot",         # Nomotic agent identity
    test_mode=True,       # use simulated trust
)

# Simulate graph state after the "think" node decides on an action
state = {
    "pending_action": "read_file",
    "pending_target": "report.csv",
    "pending_params": {},
}

if __name__ == "__main__":
    print("LangGraph + Nomotic Governance Demo")
    print("=" * 50)

    # Run the governance node
    result_state = govern(state)
    gov_result = result_state["governance_result"]

    print(f"\n  Action:  {state['pending_action']}")
    print(f"  Target:  {state['pending_target']}")
    print(f"  Allowed: {gov_result['allowed']}")
    print(f"  Verdict: {gov_result['verdict']}")
    print(f"  UCS:     {gov_result['ucs']:.3f}")
    print(f"  Trust:   {gov_result['trust']:.3f}")

    # Route based on governance
    merged = {**state, **result_state}
    next_node = route_on_governance(merged)
    print(f"\n  Next node: {next_node}")

    # ── Pattern 2: Wrap LangChain tools ──────────────────────────────
    print()
    print("LangChain Tool Wrapping")
    print("-" * 50)

    # Mock a LangChain tool
    class MockLangChainTool:
        name = "search"

        def _run(self, query: str, **kwargs):
            return f"Results for: {query}"

    from nomotic.integrations.langgraph_adapter import govern_langchain_tools  # noqa: E402

    tools = [MockLangChainTool()]
    governed = govern_langchain_tools("claims-bot", tools, test_mode=True)

    result = governed[0]._run("nomotic governance")
    print(f"\n  Tool:   {governed[0].name}")
    print(f"  Result: {result}")
