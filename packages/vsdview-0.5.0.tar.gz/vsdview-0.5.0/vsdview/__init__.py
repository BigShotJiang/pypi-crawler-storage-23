"""VSDView — A read-only viewer for Microsoft Visio files."""

__version__ = "0.5.0"
