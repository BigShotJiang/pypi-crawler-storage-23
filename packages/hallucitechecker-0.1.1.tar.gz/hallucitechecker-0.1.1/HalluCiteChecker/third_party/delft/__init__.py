import os

DELFT_PROJECT_DIR = os.path.dirname(__file__)
