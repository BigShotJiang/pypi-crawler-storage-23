from delft.textClassification.wrapper import Classifier
