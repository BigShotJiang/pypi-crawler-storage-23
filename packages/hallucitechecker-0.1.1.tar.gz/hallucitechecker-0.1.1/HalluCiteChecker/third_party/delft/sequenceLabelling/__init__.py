# from delft.sequenceLabelling.wrapper import Sequence
from .wrapper import Sequence
