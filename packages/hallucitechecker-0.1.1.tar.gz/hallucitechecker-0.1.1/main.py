def main():
    print("Hello from hallucitechecker!")


if __name__ == "__main__":
    main()
