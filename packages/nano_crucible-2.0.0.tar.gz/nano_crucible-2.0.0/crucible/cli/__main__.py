#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Enable running the CLI via: python -m pycrucible.cli
"""

from . import main

if __name__ == '__main__':
    main()
