"""Private logging module for the library. Configure the 'intersect-sdk-common' logger on rhw application side to control logging from this library."""

import logging

logger = logging.getLogger('intersect-sdk-common')
