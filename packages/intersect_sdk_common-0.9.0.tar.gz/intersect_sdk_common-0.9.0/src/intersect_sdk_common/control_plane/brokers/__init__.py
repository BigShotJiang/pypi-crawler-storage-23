"""Common logic for interacting with brokers on the protocol level.

These classes should be kept internal to the common library.
"""
