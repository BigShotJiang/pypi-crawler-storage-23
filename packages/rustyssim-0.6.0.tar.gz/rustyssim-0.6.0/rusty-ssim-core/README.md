# rusty-ssim-core

`rusty-ssim-core` is an **internal sub-crate** of the [Rustyssim](https://crates.io/crates/rustyssim) library,
providing its core functionalities.

**Important Note**: This crate is **not intended for external usage**. Please refer to the main
[Rustyssim crate](https://crates.io/crates/rustyssim) for intended usage.