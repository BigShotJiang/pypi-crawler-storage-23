from __future__ import annotations

import pytest

from g_gremlin_dynamics_mcp import __version__
from g_gremlin_dynamics_mcp import server


def test_main_version(capsys: pytest.CaptureFixture[str]) -> None:
    rc = server.main(["--version"])
    out = capsys.readouterr().out
    assert rc == 0
    assert out.strip() == __version__


def test_main_check(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]) -> None:
    monkeypatch.setattr(server, "check_gremlin_version", lambda: "0.1.14")
    rc = server.main(["--check"])
    out = capsys.readouterr().out
    assert rc == 0
    assert "g-gremlin 0.1.14 detected" in out


def test_main_forwards_enable_writes_and_profile(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: dict[str, object] = {}

    monkeypatch.setattr(server, "check_gremlin_version", lambda: "0.1.14")

    def _fake_launch_gremlin_mcp(*, enable_writes: bool = False, profile: str | None = None) -> int:
        calls["enable_writes"] = enable_writes
        calls["profile"] = profile
        return 17

    monkeypatch.setattr(server, "launch_gremlin_mcp", _fake_launch_gremlin_mcp)
    rc = server.main(["--enable-writes", "--profile", "prod"])
    assert rc == 17
    assert calls["enable_writes"] is True
    assert calls["profile"] == "prod"


def test_main_returns_error_on_version_failure(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]) -> None:
    monkeypatch.setattr(server, "check_gremlin_version", lambda: (_ for _ in ()).throw(RuntimeError("boom")))
    rc = server.main([])
    err = capsys.readouterr().err
    assert rc == 2
    assert "boom" in err
