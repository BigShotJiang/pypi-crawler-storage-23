# Changelog

## 0.1.1

- Strengthens startup compatibility checks by validating `g-gremlin mcp serve-dynamics --help` succeeds.
- Fails fast with a clear error when installed `g-gremlin` lacks MCP Dynamics commands.
- Adds test coverage for the missing-MCP-command failure path.

## 0.1.0

- Initial standalone Dynamics 365 / Dataverse MCP launcher package.
- Adds `g-gremlin-dynamics-mcp` entrypoint.
- Delegates to `g-gremlin mcp serve-dynamics` with optional `--enable-writes` flag passthrough.
- Adds optional `--profile` pass-through for default Dynamics profile selection.
- Adds startup check for minimum `g-gremlin` version.
- Uses `subprocess.run` passthrough on Windows for stdio transport behavior, and `execv` on Unix-like platforms.
- Replaces mutable executable-path global with cache-clearable lookup (`lru_cache`) for safer tests.
- Includes client config examples for read-only and write-enabled setup.
