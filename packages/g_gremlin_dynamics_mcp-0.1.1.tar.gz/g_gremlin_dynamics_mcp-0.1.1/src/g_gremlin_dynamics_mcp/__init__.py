"""g-gremlin Dynamics MCP launcher package."""

__version__ = "0.1.1"
MIN_GREMLIN_VERSION = "0.1.14"
