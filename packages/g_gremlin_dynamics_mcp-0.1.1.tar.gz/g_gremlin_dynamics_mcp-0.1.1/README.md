# g-gremlin-dynamics-mcp

Standalone Dynamics 365 / Dataverse MCP launcher for g-gremlin.

This package provides a dedicated `g-gremlin-dynamics-mcp` command so MCP clients can connect to Dataverse tools without calling the broader `g-gremlin` CLI directly.

It delegates to:

- `g-gremlin mcp serve-dynamics` (read/analyze tools only)
- `g-gremlin mcp serve-dynamics --enable-writes` (write tools exposed; all apply calls still require `plan_hash`)
- Optional profile selection: `g-gremlin mcp serve-dynamics --profile <name>`

## Quickstart

```bash
pipx install g-gremlin
pipx install g-gremlin-dynamics-mcp

# Configure Dynamics credentials for g-gremlin
g-gremlin auth set dynamics
```

## Dataverse Requirements

For Dataverse MCP with non-Microsoft clients:

- Enable Dataverse MCP in Power Platform Admin Center (PPAC)
- Add each non-Microsoft MCP client to the Dataverse MCP allowed clients list in PPAC
- Install the local Dataverse MCP proxy tool if needed:
  - `dotnet tool install --global Microsoft.PowerPlatform.Dataverse.MCP`

Billing note:

- External AI-agent access can consume Dataverse API/request capacity. Review licensing and limits before enabling autonomous write flows.

## Claude Desktop

```json
{
  "mcpServers": {
    "g-gremlin-dynamics": {
      "command": "g-gremlin-dynamics-mcp"
    }
  }
}
```

To expose write tools:

```json
{
  "mcpServers": {
    "g-gremlin-dynamics": {
      "command": "g-gremlin-dynamics-mcp",
      "args": ["--enable-writes"]
    }
  }
}
```

## Cursor / Windsurf

Use the same MCP server command in your client config:

```json
{
  "mcpServers": {
    "g-gremlin-dynamics": {
      "command": "g-gremlin-dynamics-mcp"
    }
  }
}
```

To expose write tools in Cursor/Windsurf, add:

```json
{
  "mcpServers": {
    "g-gremlin-dynamics": {
      "command": "g-gremlin-dynamics-mcp",
      "args": ["--enable-writes"]
    }
  }
}
```

## Health check

```bash
g-gremlin-dynamics-mcp --check
```

`--check` validates both the minimum `g-gremlin` version and that
`g-gremlin mcp serve-dynamics` is available in the installed build.

Profile-aware startup:

```bash
g-gremlin-dynamics-mcp --profile prod
```

## Development

```bash
git clone https://github.com/mikeheilmann1024/g-gremlin-dynamics-mcp
cd g-gremlin-dynamics-mcp
pip install -e ".[dev]"
pytest
```

## License

MIT
