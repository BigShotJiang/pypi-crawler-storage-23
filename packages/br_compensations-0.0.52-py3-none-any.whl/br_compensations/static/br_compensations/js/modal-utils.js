/**
 * Модуль для замены нативных alert() и confirm() на Bootstrap модальные окна
 * Совместим с Bootstrap 5
 */

(function(window) {
    'use strict';

    /**
     * Создаёт модальное окно Bootstrap 5 с заданным содержимым
     * @param {string} title - Заголовок модального окна
     * @param {string} body - Тело модального окна (поддерживает HTML)
     * @param {Array} buttons - Массив объектов кнопок {text, class, id}
     * @returns {HTMLElement} - Созданный элемент модального окна
     */
    function createModal(title, body, buttons) {
        // Генерируем уникальный ID для модального окна
        const modalId = 'bs-modal-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);

        // Обрабатываем переносы строк в сообщении
        const formattedBody = body.replace(/\r\n/g, '<br>').replace(/\n/g, '<br>').replace(/\r/g, '<br>');

        // Создаём HTML модального окна
        const modalHTML = `
            <div class="modal fade" id="${modalId}" tabindex="-1" aria-labelledby="${modalId}-label" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="${modalId}-label">${title}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            ${formattedBody}
                        </div>
                        <div class="modal-footer">
                            ${buttons.map(btn => `
                                <button type="button" 
                                        class="btn ${btn.class || 'btn-secondary'}" 
                                        id="${btn.id || ''}"
                                        data-bs-dismiss="${btn.dismiss ? 'modal' : ''}">
                                    ${btn.text}
                                </button>
                            `).join('')}
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Создаём временный контейнер и добавляем HTML
        const container = document.createElement('div');
        container.innerHTML = modalHTML;
        const modalElement = container.firstElementChild;

        // Добавляем модальное окно в DOM
        document.body.appendChild(modalElement);

        return modalElement;
    }

    /**
     * Показывает модальное окно с сообщением (замена для alert())
     * @param {string} message - Сообщение для отображения
     * @param {string} title - Заголовок модального окна (по умолчанию 'Уведомление')
     */
    function showAlert(message, title = 'Уведомление') {
        const modalElement = createModal(title, message, [
            {
                text: 'OK',
                class: 'btn-primary',
                dismiss: true
            }
        ]);

        // Инициализируем и показываем модальное окно
        const modal = new bootstrap.Modal(modalElement);
        modal.show();

        // Удаляем модальное окно из DOM после закрытия
        modalElement.addEventListener('hidden.bs.modal', function() {
            document.body.removeChild(modalElement);
        });
    }

    /**
     * Показывает модальное окно подтверждения (замена для confirm())
     * @param {string} message - Сообщение для отображения
     * @param {string} title - Заголовок модального окна (по умолчанию 'Подтверждение')
     * @returns {Promise<boolean>} - Promise, который резолвится в true или false
     */
    function showConfirm(message, title = 'Подтверждение') {
        return new Promise(function(resolve) {
            const confirmId = 'bs-confirm-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
            const cancelId = 'bs-cancel-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);

            const modalElement = createModal(title, message, [
                {
                    text: 'Подтвердить',
                    class: 'btn-primary',
                    id: confirmId,
                    dismiss: true
                },
                {
                    text: 'Отмена',
                    class: 'btn-secondary',
                    id: cancelId,
                    dismiss: true
                }
            ]);

            // Инициализируем и показываем модальное окно
            const modal = new bootstrap.Modal(modalElement);
            modal.show();

            // Обработчик кнопки подтверждения
            const confirmButton = document.getElementById(confirmId);
            if (confirmButton) {
                confirmButton.addEventListener('click', function() {
                    resolve(true);
                });
            }

            // Обработчик кнопки отмены
            const cancelButton = document.getElementById(cancelId);
            if (cancelButton) {
                cancelButton.addEventListener('click', function() {
                    resolve(false);
                });
            }

            // Удаляем модальное окно из DOM после закрытия
            modalElement.addEventListener('hidden.bs.modal', function() {
                document.body.removeChild(modalElement);
            });

            // Обработка закрытия по клику вне модального окна или по Escape
            modalElement.addEventListener('click', function(event) {
                if (event.target === modalElement) {
                    resolve(false);
                }
            });
        });
    }

    // Экспортируем функции в глобальную область видимости
    window.showAlert = showAlert;
    window.showConfirm = showConfirm;

    // Также экспортируем через объект для использования в модулях
    window.ModalUtils = {
        showAlert: showAlert,
        showConfirm: showConfirm
    };

})(window);
