import importlib.util

def is_installed(package_name):
    """Check if a package is installed using importlib."""
    spec = importlib.util.find_spec(package_name)
    return spec is not None

# Example usage:
if is_installed("numpy"):
    print("numpy is installed.")
else:
    print("numpy is not installed.")
