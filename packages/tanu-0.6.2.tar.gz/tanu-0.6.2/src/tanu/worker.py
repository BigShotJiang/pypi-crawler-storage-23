from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
import logging
from logging.handlers import RotatingFileHandler
import os
import queue
import re
import socket
import threading
import time
from collections.abc import Callable
from inspect import Parameter, Signature, signature
from pathlib import Path
from typing import Any, get_type_hints

import pika

from .config import RabbitMQConfig
from .protocol import build_error_response, build_ok_response, build_progress
from .rabbitmq import connect_blocking, declare_rpc_topology, declare_status_topology, declare_worker_queue
from .utils.object_encoder_decoder import decode_json, encode_json
from .worker_config_store import WorkerConfigStore

_DEFAULT_LOG_DIR = "tanu_logs"
_DEFAULT_CONFIG_DIR = "tanu_configs"
_DEFAULT_LOG_MAX_BYTES = 10 * 1024 * 1024  # 10 MiB
_DEFAULT_LOG_BACKUP_COUNT = 10
_ARG_LOG_THRESHOLD_BYTES = 1024  # 1 KiB

_NUMPY: Any | None = None


def _maybe_numpy() -> Any | None:
    global _NUMPY
    if _NUMPY is False:  # type: ignore[comparison-overlap]
        return None
    if _NUMPY is None:
        try:
            import numpy as np  # type: ignore[import-not-found]

            _NUMPY = np
        except Exception:
            _NUMPY = False  # type: ignore[assignment]
            return None
    return _NUMPY


def _estimate_bytes_for_log(value: Any, *, limit: int = _ARG_LOG_THRESHOLD_BYTES, _depth: int = 0) -> int:
    if limit <= 0:
        return limit + 1
    if _depth >= 2:
        try:
            return len(repr(value).encode("utf-8"))
        except Exception:
            return limit + 1

    np = _maybe_numpy()
    if np is not None and isinstance(value, np.ndarray):
        try:
            return int(value.nbytes)
        except Exception:
            return limit + 1

    if value is None or isinstance(value, (bool, int, float)):
        return len(str(value).encode("utf-8"))
    if isinstance(value, str):
        return len(value.encode("utf-8"))
    if isinstance(value, bytes):
        return len(value)

    if isinstance(value, (list, tuple)):
        if len(value) > 200:
            return limit + 1
        total = 2
        for item in value:
            total += _estimate_bytes_for_log(item, limit=limit - total, _depth=_depth + 1) + 1
            if total > limit:
                return total
        return total

    if isinstance(value, dict):
        if len(value) > 200:
            return limit + 1
        total = 2
        for k, v in value.items():
            total += _estimate_bytes_for_log(k, limit=limit - total, _depth=_depth + 1) + 1
            if total > limit:
                return total
            total += _estimate_bytes_for_log(v, limit=limit - total, _depth=_depth + 1) + 1
            if total > limit:
                return total
        return total

    try:
        return len(repr(value).encode("utf-8"))
    except Exception:
        return limit + 1


def _sanitize_value_for_command_log(value: Any) -> Any:
    np = _maybe_numpy()
    if np is not None and isinstance(value, np.ndarray):
        try:
            nbytes = int(value.nbytes)
            if nbytes > _ARG_LOG_THRESHOLD_BYTES:
                return {
                    "__tanu_log__": "numpy.ndarray",
                    "shape": list(value.shape),
                    "dtype": str(value.dtype),
                    "nbytes": nbytes,
                }
        except Exception:
            return {"__tanu_log__": "numpy.ndarray", "nbytes": None}
        return value

    if isinstance(value, list):
        size = _estimate_bytes_for_log(value)
        if size > _ARG_LOG_THRESHOLD_BYTES:
            return {
                "__tanu_log__": "list",
                "len": len(value),
                "approx_bytes": int(size),
            }
        return [_sanitize_value_for_command_log(v) for v in value]

    if isinstance(value, dict):
        return {k: _sanitize_value_for_command_log(v) for k, v in value.items()}

    if isinstance(value, tuple):
        return tuple(_sanitize_value_for_command_log(v) for v in value)

    return value


def _sanitize_kwargs_for_command_log(kwargs: dict[str, Any]) -> dict[str, Any]:
    return {k: _sanitize_value_for_command_log(v) for k, v in kwargs.items()}


def _build_pydantic_kwargs_validator(fn: Handler) -> Callable[[dict[str, Any]], dict[str, Any]] | None:
    try:
        import pydantic
        from pydantic import create_model
    except Exception as e:
        def _missing(_kwargs: dict[str, Any]) -> dict[str, Any]:
            raise RuntimeError(
                "pydantic is required for TanukiWorker input validation. "
                "Install/upgrade pydantic (supported: v1 or v2)."
            ) from e

        return _missing

    try:
        sig = signature(fn)
    except Exception:
        return None

    allow_extra = any(p.kind is Parameter.VAR_KEYWORD for p in sig.parameters.values())
    try:
        hints = get_type_hints(fn, include_extras=True)
    except Exception:
        hints = {}

    fields: dict[str, tuple[Any, Any]] = {}
    for name, p in sig.parameters.items():
        if p.kind in (Parameter.VAR_POSITIONAL, Parameter.VAR_KEYWORD):
            continue
        if name in hints:
            ann = hints[name]
        elif p.annotation is not Parameter.empty:
            ann = p.annotation
        else:
            ann = Any
        default = p.default if p.default is not Parameter.empty else ...
        fields[name] = (ann, default)

    if hasattr(pydantic, "ConfigDict"):
        from pydantic import ConfigDict  # type: ignore[attr-defined]

        model_config = ConfigDict(
            extra="allow" if allow_extra else "forbid",
            arbitrary_types_allowed=True,
        )
        model = create_model(f"_TanukiParams_{getattr(fn, '__name__', 'handler')}", __config__=model_config, **fields)

        def _validate(kwargs: dict[str, Any]) -> dict[str, Any]:
            validated = model.model_validate(kwargs)
            return dict(validated.model_dump())

        return _validate

    try:
        from pydantic import Extra  # type: ignore[attr-defined]
    except Exception:
        Extra = None  # type: ignore[assignment]

    class _Config:
        arbitrary_types_allowed = True
        extra = (
            (Extra.allow if allow_extra else Extra.forbid)
            if Extra is not None
            else ("allow" if allow_extra else "forbid")
        )

    model = create_model(f"_TanukiParams_{getattr(fn, '__name__', 'handler')}", __config__=_Config, **fields)

    def _validate_v1(kwargs: dict[str, Any]) -> dict[str, Any]:
        validated = model.parse_obj(kwargs)
        return dict(validated.dict())

    return _validate_v1

Handler = Callable[..., Any]
ProgressCallback = Callable[..., Any]


@dataclass(frozen=True, slots=True)
class ProgressContext:
    worker_name: str
    method: str
    args: list[Any]
    kwargs: dict[str, Any]
    started_at: float
    elapsed: float


ProgressProvider = Callable[[ProgressContext], Any]


@dataclass(slots=True)
class _InFlightRequest:
    method: str
    args: list[Any]
    kwargs: dict[str, Any]
    props: pika.BasicProperties
    delivery_tag: int | None
    started_at: float
    last_progress_at: float
    progress_interval: float
    progress_provider: ProgressProvider | None
    done: threading.Event = field(default_factory=threading.Event)
    response: dict[str, Any] | None = None
    client_gone: bool = False


def _normalize_progress_callback(fn: ProgressCallback) -> ProgressProvider:
    try:
        sig = signature(fn)
    except Exception:
        return lambda _ctx: fn()  # type: ignore[misc]

    if not sig.parameters:
        return lambda _ctx: fn()  # type: ignore[misc]
    return lambda ctx: fn(ctx)  # type: ignore[misc]


class TanukiWorker:
    def __init__(
        self,
        worker_name: str,
        config: RabbitMQConfig | None = None,
        *,
        worker_id: str | None = None,
        log_level: int | str = "INFO",
        command_log: bool = False,
        status_monitor: bool = False,
        status_heartbeat_interval: float = 2.0,
        log_dir: str | os.PathLike[str] = _DEFAULT_LOG_DIR,
        config_dir: str | os.PathLike[str] = _DEFAULT_CONFIG_DIR,
        log_max_bytes: int = _DEFAULT_LOG_MAX_BYTES,
        log_backup_count: int = _DEFAULT_LOG_BACKUP_COUNT,
        **config_overrides: Any,
    ) -> None:
        self._worker_name = worker_name
        self._command_log = bool(command_log)
        self._log_dir = Path(log_dir)
        self._config_dir = Path(config_dir)
        self._worker_config = WorkerConfigStore(worker_name=worker_name, config_dir=self._config_dir)

        self._logger = logging.getLogger(f"tanu.worker.{worker_name}")
        self._configure_file_logger(
            worker_name=worker_name,
            log_dir=self._log_dir,
            max_bytes=int(log_max_bytes),
            backup_count=int(log_backup_count),
        )
        self._logger.setLevel(_coerce_log_level(log_level))

        base_config = config or RabbitMQConfig()
        if config_overrides:
            allowed = {f.name for f in dataclasses.fields(RabbitMQConfig)}
            unknown = sorted(k for k in config_overrides.keys() if k not in allowed)
            if unknown:
                if "configure_logging" in unknown:
                    raise TypeError(
                        "TanukiWorker(..., configure_logging=...) was removed. "
                        "Configure logging in your app (e.g. logging.basicConfig(...)) instead."
                    )
                raise TypeError(f"unknown keyword argument(s): {unknown!r}")
            base_config = dataclasses.replace(base_config, **config_overrides)
        self._rabbitmq_config = base_config
        self._worker_id = worker_id or f"tanuki-worker:{worker_name}"
        self._status_monitor = bool(status_monitor)
        self._status_heartbeat_interval = float(status_heartbeat_interval)
        self._instance_id = f"{socket.gethostname()}:{os.getpid()}"

        _, self._realm = self._rabbitmq_config.split_worker_name(worker_name)
        self._request_exchange = self._rabbitmq_config.request_exchange_name(worker_name)
        self._reply_exchange = self._rabbitmq_config.reply_exchange_name(worker_name)
        self._routing_key = self._rabbitmq_config.request_routing_key(worker_name)
        self._status_exchange = self._rabbitmq_config.status_exchange_name()
        self._status_routing_key = self._rabbitmq_config.status_routing_key(worker_name)

        self._handlers: dict[str, Handler] = {}
        self._kwargs_validators: dict[str, Callable[[dict[str, Any]], dict[str, Any]]] = {}
        self._progress_handlers: dict[str, ProgressProvider] = {}
        self._progress_intervals: dict[str, float] = {}
        self.register("__tanuki_help__", self._tanuki_help)

        self._connection: pika.BlockingConnection | None = None
        self._connection_owner_thread_id: int | None = None
        self._consume_ch: pika.adapters.blocking_connection.BlockingChannel | None = None
        self._publish_ch: pika.adapters.blocking_connection.BlockingChannel | None = None
        self._status_ch: pika.adapters.blocking_connection.BlockingChannel | None = None
        self._queue_name: str | None = None
        self._stop_requested = False
        self._transport_thread: threading.Thread | None = None
        self._request_queue: queue.Queue[_InFlightRequest | None] | None = None

    @property
    def rabbitmq_config(self) -> RabbitMQConfig:
        return self._rabbitmq_config

    @property
    def config(self) -> WorkerConfigStore:
        return self._worker_config

    @property
    def logger(self) -> logging.Logger:
        return self._logger

    @property
    def worker_name(self) -> str:
        return self._worker_name

    def _safe_fs_name(self, name: str) -> str:
        safe = re.sub(r"[^A-Za-z0-9._@-]+", "_", name.strip())
        safe = safe.strip("._-")
        return safe or "worker"

    def _configure_file_logger(self, *, worker_name: str, log_dir: Path, max_bytes: int, backup_count: int) -> None:
        try:
            log_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            self._logger.debug("failed to create log_dir=%s", log_dir, exc_info=True)
            return

        safe_name = self._safe_fs_name(worker_name)
        base_path = log_dir / f"{safe_name}_0.log"
        base_path_str = os.path.abspath(os.fspath(base_path))
        for h in list(self._logger.handlers):
            if isinstance(h, RotatingFileHandler) and getattr(h, "baseFilename", None) == base_path_str:
                return

        handler = RotatingFileHandler(
            filename=base_path_str,
            maxBytes=max_bytes,
            backupCount=max(1, backup_count),
            encoding="utf-8",
        )
        handler.setLevel(logging.DEBUG)
        handler.setFormatter(
            logging.Formatter(
                fmt="%(asctime)s %(levelname)s %(name)s - %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )

        base_no_ext = handler.baseFilename[: -len("_0.log")]
        rotate_re = re.compile(rf"^{re.escape(base_no_ext)}_0\.log\.(\d+)$")

        def _namer(default_name: str) -> str:
            m = rotate_re.match(default_name)
            if not m:
                return default_name
            idx = m.group(1)
            return f"{base_no_ext}_{idx}.log"

        handler.namer = _namer
        self._logger.addHandler(handler)

    def handler(
        self,
        method: str,
        *,
        progress: ProgressCallback | None = None,
        progress_interval: float | None = None,
    ) -> Callable[[Handler], Handler]:
        def _decorator(fn: Handler) -> Handler:
            self._handlers[method] = fn
            validator = _build_pydantic_kwargs_validator(fn)
            if validator is not None:
                self._kwargs_validators[method] = validator
            else:
                self._kwargs_validators.pop(method, None)
            if progress is not None:
                self.set_progress(method, progress, interval=progress_interval)
            return fn

        return _decorator

    def command(
        self,
        name: str,
        *,
        progress: ProgressCallback | None = None,
        progress_interval: float | None = None,
    ) -> Callable[[Handler], Handler]:
        return self.handler(name, progress=progress, progress_interval=progress_interval)

    def register(
        self,
        method: str,
        fn: Handler,
        *,
        progress: ProgressCallback | None = None,
        progress_interval: float | None = None,
    ) -> None:
        self._handlers[method] = fn
        validator = _build_pydantic_kwargs_validator(fn)
        if validator is not None:
            self._kwargs_validators[method] = validator
        else:
            self._kwargs_validators.pop(method, None)
        if progress is not None:
            self.set_progress(method, progress, interval=progress_interval)

    def progress(self, method: str, *, interval: float | None = None) -> Callable[[ProgressCallback], ProgressCallback]:
        def _decorator(fn: ProgressCallback) -> ProgressCallback:
            self.set_progress(method, fn, interval=interval)
            return fn

        return _decorator

    def set_progress(self, method: str, fn: ProgressCallback | None, *, interval: float | None = None) -> None:
        if fn is None:
            self._progress_handlers.pop(method, None)
            self._progress_intervals.pop(method, None)
            return

        self._progress_handlers[method] = _normalize_progress_callback(fn)
        if interval is not None:
            self._progress_intervals[method] = float(interval)

    def _tanuki_help(self) -> dict[str, Any]:
        import inspect

        def _ann_to_str(ann: Any) -> str | None:
            if ann is inspect._empty:
                return None
            if isinstance(ann, type):
                return ann.__name__
            return str(ann)

        def _param_to_dict(p: Parameter) -> dict[str, Any]:
            return {
                "name": p.name,
                "kind": p.kind.name,
                "annotation": _ann_to_str(p.annotation),
                "has_default": p.default is not inspect._empty,
                "default": None if p.default is inspect._empty else repr(p.default),
            }

        commands: list[dict[str, Any]] = []
        for name, fn in sorted(self._handlers.items(), key=lambda kv: kv[0]):
            if name.startswith("__tanuki_"):
                continue
            try:
                sig: Signature = inspect.signature(fn)
                sig_str = f"{name}{sig}"
                params = [_param_to_dict(p) for p in sig.parameters.values()]
                return_ann = _ann_to_str(sig.return_annotation)
            except Exception:
                sig_str = name
                params = []
                return_ann = None

            doc = getattr(fn, "__doc__", None) or None
            if isinstance(doc, str):
                doc = doc.strip().splitlines()[0] if doc.strip() else None

            commands.append(
                {
                    "name": name,
                    "signature": sig_str,
                    "params": params,
                    "return": return_ann,
                    "doc": doc,
                }
            )

        return {
            "worker": self._worker_name,
            "realm": self._realm,
            "queue": self._rabbitmq_config.request_queue_name(self._worker_name),
            "request_exchange": self._request_exchange,
            "reply_exchange": self._reply_exchange,
            "commands": commands,
        }

    def close(self) -> None:
        if self._consume_ch and self._consume_ch.is_open:
            try:
                self._consume_ch.close()
            except Exception:
                self._logger.debug("ignore close(consume_ch) error", exc_info=True)
        if self._publish_ch and self._publish_ch.is_open:
            try:
                self._publish_ch.close()
            except Exception:
                self._logger.debug("ignore close(publish_ch) error", exc_info=True)
        if self._status_ch and self._status_ch.is_open:
            try:
                self._status_ch.close()
            except Exception:
                self._logger.debug("ignore close(status_ch) error", exc_info=True)
        if self._connection and self._connection.is_open:
            try:
                self._connection.close()
            except Exception:
                self._logger.debug("ignore close(connection) error", exc_info=True)
        self._connection = None
        self._connection_owner_thread_id = None
        self._consume_ch = None
        self._publish_ch = None
        self._status_ch = None
        self._queue_name = None

    def stop(self) -> None:
        self._stop_requested = True
        if self._request_queue is not None:
            try:
                self._request_queue.put_nowait(None)
            except Exception:
                pass

        transport_thread = self._transport_thread
        if transport_thread is not None and transport_thread.is_alive():
            if threading.current_thread() is transport_thread:
                self.close()
            return

        self.close()

    def purge(self) -> int:
        self._ensure_connected()
        assert self._consume_ch and self._queue_name
        result = self._consume_ch.queue_purge(queue=self._queue_name)
        return int(result.method.message_count)

    def _ensure_connected(self) -> None:
        thread_id = threading.get_ident()
        if (
            self._connection
            and self._connection.is_open
            and self._consume_ch
            and self._publish_ch
            and (self._status_ch or not self._status_monitor)
            and self._queue_name
            and self._connection_owner_thread_id == thread_id
        ):
            return

        self.close()

        self._connection = connect_blocking(
            self._rabbitmq_config,
            connection_name=self._worker_id,
            max_retries=0,
            log=self._logger,
        )
        self._connection_owner_thread_id = thread_id
        self._consume_ch = self._connection.channel()
        self._publish_ch = self._connection.channel()
        self._status_ch = self._connection.channel() if self._status_monitor else None

        declare_rpc_topology(self._consume_ch, self._rabbitmq_config, worker_name=self._worker_name)
        self._queue_name = declare_worker_queue(self._consume_ch, self._rabbitmq_config, worker_name=self._worker_name)
        declare_rpc_topology(self._publish_ch, self._rabbitmq_config, worker_name=self._worker_name)
        if self._status_ch is not None:
            declare_status_topology(self._status_ch, self._rabbitmq_config, worker_name=self._worker_name)

        self._publish_ch.confirm_delivery()
        self._consume_ch.basic_qos(prefetch_count=self._rabbitmq_config.prefetch_count)

    def _publish_status(self, *, state: str, method: str | None) -> None:
        if not self._status_monitor:
            return
        if self._status_ch is None or not self._status_ch.is_open:
            return

        msg: dict[str, Any] = {
            "worker": self._worker_name,
            "worker_id": self._worker_id,
            "instance_id": self._instance_id,
            "state": state,
            "method": method,
            "updated_at": time.time(),
        }
        try:
            body = encode_json(msg)
        except Exception:
            self._logger.debug("failed to encode status message", exc_info=True)
            return

        try:
            self._status_ch.basic_publish(
                exchange=self._status_exchange,
                routing_key=self._status_routing_key,
                body=body,
                properties=pika.BasicProperties(
                    content_type="application/json",
                    app_id=self._worker_id,
                    type="tanuki.status",
                ),
            )
        except Exception:
            self._logger.debug("failed to publish status message", exc_info=True)

    def _publish_reply(self, props: pika.BasicProperties, body: bytes, *, msg_type: str, warn_unroutable: bool) -> bool:
        if not props.reply_to:
            return False
        assert self._publish_ch is not None
        try:
            self._publish_ch.basic_publish(
                exchange=self._reply_exchange,
                routing_key=props.reply_to,
                body=body,
                properties=pika.BasicProperties(
                    content_type="application/json",
                    correlation_id=props.correlation_id,
                    app_id=self._worker_id,
                    type=msg_type,
                ),
                mandatory=True,
            )
            return True
        except (pika.exceptions.UnroutableError, pika.exceptions.NackError):
            if warn_unroutable:
                self._logger.warning("%s unroutable (client likely gone): reply_to=%s", msg_type, props.reply_to)
            else:
                self._logger.debug("%s unroutable (client likely gone): reply_to=%s", msg_type, props.reply_to)
            return False
        except pika.exceptions.AMQPError:
            self._logger.exception("failed to publish %s", msg_type)
            return False

    def _ack_if_needed(self, delivery_tag: int | None) -> None:
        if self._rabbitmq_config.worker_auto_ack or delivery_tag is None:
            return
        assert self._consume_ch is not None
        try:
            self._consume_ch.basic_ack(delivery_tag=delivery_tag)
        except Exception:
            self._logger.debug("ignore ack error", exc_info=True)

    def _start_inflight(
        self,
        delivery_tag: int | None,
        props: pika.BasicProperties,
        body: bytes,
        request_queue: queue.Queue[_InFlightRequest | None],
    ) -> _InFlightRequest | None:
        try:
            req = decode_json(body)
            method_name = str(req.get("method"))
            args = req.get("args") or []
            kwargs = req.get("kwargs") or {}
            if not isinstance(args, list) or not isinstance(kwargs, dict):
                raise ValueError("invalid request payload")

            fn = self._handlers.get(method_name)
            if fn is None:
                raise KeyError(f"unknown method: {method_name}")

            if args:
                raise TypeError("positional arguments are not allowed; use keyword arguments")
        except KeyError as e:
            self._logger.warning(str(e))
            resp = build_error_response(e, include_traceback=self._rabbitmq_config.include_traceback_in_error)
            self._publish_reply(props, encode_json(resp), msg_type="tanuki.response", warn_unroutable=True)
            self._ack_if_needed(delivery_tag)
            return None
        except TypeError as e:
            self._logger.warning("invalid request: %s", e)
            resp = build_error_response(e, include_traceback=self._rabbitmq_config.include_traceback_in_error)
            self._publish_reply(props, encode_json(resp), msg_type="tanuki.response", warn_unroutable=True)
            self._ack_if_needed(delivery_tag)
            return None
        except Exception as e:
            self._logger.exception("failed to decode request")
            resp = build_error_response(e, include_traceback=self._rabbitmq_config.include_traceback_in_error)
            self._publish_reply(props, encode_json(resp), msg_type="tanuki.response", warn_unroutable=True)
            self._ack_if_needed(delivery_tag)
            return None

        progress_provider = self._progress_handlers.get(method_name)
        progress_interval = float(self._progress_intervals.get(method_name, self._rabbitmq_config.progress_interval))

        if self._command_log:
            caller = getattr(props, "app_id", None) or getattr(props, "user_id", None) or "-"
            safe_kwargs = _sanitize_kwargs_for_command_log(kwargs)
            self._logger.info(
                "CALL from=%s method=%s correlation_id=%s kwargs=%s",
                caller,
                method_name,
                props.correlation_id or "-",
                safe_kwargs,
            )

        inflight = _InFlightRequest(
            method=method_name,
            args=args,
            kwargs=kwargs,
            props=props,
            delivery_tag=delivery_tag,
            started_at=time.monotonic(),
            last_progress_at=0.0,
            progress_interval=progress_interval,
            progress_provider=progress_provider,
        )

        self._publish_status(state="busy", method=method_name)
        request_queue.put(inflight)
        return inflight

    def _execute_inflight(self, inflight: _InFlightRequest) -> None:
        if inflight.args:
            try:
                raise TypeError("positional arguments are not allowed; use keyword arguments")
            except TypeError as e:
                resp = build_error_response(e, include_traceback=self._rabbitmq_config.include_traceback_in_error)
            inflight.response = resp
            inflight.done.set()
            return

        fn = self._handlers.get(inflight.method)
        if fn is None:
            resp = build_error_response(
                KeyError(f"unknown method: {inflight.method}"),
                include_traceback=self._rabbitmq_config.include_traceback_in_error,
            )
            inflight.response = resp
            inflight.done.set()
            return

        try:
            validator = self._kwargs_validators.get(inflight.method)
            if validator is not None:
                try:
                    inflight.kwargs = validator(inflight.kwargs)
                except Exception as e:
                    self._logger.warning("invalid params: method=%s err=%s", inflight.method, e)
                    resp = build_error_response(e, include_traceback=self._rabbitmq_config.include_traceback_in_error)
                    inflight.response = resp
                    inflight.done.set()
                    return

            result = fn(*inflight.args, **inflight.kwargs)
            resp = build_ok_response(result)
        except KeyError as e:
            self._logger.warning(str(e))
            resp = build_error_response(e, include_traceback=self._rabbitmq_config.include_traceback_in_error)
        except Exception as e:
            self._logger.exception("handler error")
            resp = build_error_response(e, include_traceback=self._rabbitmq_config.include_traceback_in_error)

        inflight.response = resp
        inflight.done.set()

    def _run_transport(self, request_queue: queue.Queue[_InFlightRequest | None]) -> None:
        startup_logged = False
        inflight: _InFlightRequest | None = None

        while not self._stop_requested:
            try:
                self._ensure_connected()
                assert self._connection and self._consume_ch and self._queue_name
                consumer_tag: str | None = None
                pause_consume = False
                pending: list[tuple[int | None, pika.BasicProperties, bytes]] = []
                next_status_at = time.monotonic()
                if self._status_monitor:
                    self._publish_status(state="idle", method=None)
                    if self._status_heartbeat_interval > 0:
                        next_status_at = time.monotonic() + self._status_heartbeat_interval

                def _on_request(ch, method, props: pika.BasicProperties, body: bytes) -> None:  # type: ignore[no-untyped-def]
                    nonlocal inflight, pause_consume, pending

                    delivery_tag = None if self._rabbitmq_config.worker_auto_ack else int(method.delivery_tag)
                    if inflight is not None:
                        pending.append((delivery_tag, props, body))
                        pause_consume = True
                        return

                    inflight = self._start_inflight(delivery_tag, props, body, request_queue)
                    if inflight is not None:
                        pause_consume = True

                if not startup_logged:
                    commands = sorted(k for k in self._handlers.keys() if not k.startswith("__tanuki_"))
                    cmd_str = ",".join(commands) if commands else "-"
                    realm = self._realm or "local"
                    if self._realm is None:
                        self._logger.info(
                            "TanukiWorker ready: %s (local) queue=%s cmds=%s",
                            self._worker_name,
                            self._queue_name,
                            cmd_str,
                        )
                    else:
                        self._logger.info(
                            "TanukiWorker ready: %s (realm=%s) queue=%s req=%s rep=%s cmds=%s",
                            self._worker_name,
                            realm,
                            self._queue_name,
                            self._request_exchange,
                            self._reply_exchange,
                            cmd_str,
                        )
                    self._logger.debug(
                        "TanukiWorker connection: rabbitmq=%s:%s vhost=%s",
                        self._rabbitmq_config.host,
                        self._rabbitmq_config.port,
                        self._rabbitmq_config.virtual_host,
                    )
                    startup_logged = True
                else:
                    self._logger.info(
                        "TanukiWorker reconnected: %s (realm=%s) queue=%s",
                        self._worker_name,
                        self._realm or "local",
                        self._queue_name,
                    )

                while not self._stop_requested:
                    if pause_consume and consumer_tag is not None:
                        try:
                            self._consume_ch.basic_cancel(consumer_tag)
                        except Exception:
                            self._logger.debug("ignore basic_cancel error", exc_info=True)
                        consumer_tag = None
                        pause_consume = False

                    if inflight is None:
                        if pending:
                            delivery_tag, props, body = pending.pop(0)
                            inflight = self._start_inflight(delivery_tag, props, body, request_queue)
                            continue

                        if consumer_tag is None:
                            consumer_tag = self._consume_ch.basic_consume(
                                queue=self._queue_name,
                                on_message_callback=_on_request,
                                auto_ack=self._rabbitmq_config.worker_auto_ack,
                            )
                        time_limit = 1.0
                        if self._status_monitor and self._status_heartbeat_interval > 0:
                            now = time.monotonic()
                            if now >= next_status_at:
                                self._publish_status(state="idle", method=None)
                                next_status_at = now + self._status_heartbeat_interval
                            else:
                                time_limit = min(time_limit, max(0.0, next_status_at - now))
                        self._connection.process_data_events(time_limit=time_limit)
                        continue

                    if inflight.done.is_set():
                        self._finish_inflight(inflight)
                        inflight = None
                        continue

                    now = time.monotonic()
                    progress_interval = float(inflight.progress_interval)
                    until_progress = 1.0
                    if not inflight.client_gone and progress_interval > 0:
                        elapsed = now - inflight.last_progress_at
                        until_progress = max(0.0, min(1.0, progress_interval - elapsed))

                    wait_timeout = until_progress
                    if self._status_monitor and self._status_heartbeat_interval > 0:
                        now = time.monotonic()
                        if now >= next_status_at:
                            self._publish_status(state="busy", method=inflight.method)
                            next_status_at = now + self._status_heartbeat_interval
                        else:
                            wait_timeout = min(wait_timeout, max(0.0, next_status_at - now))

                    if inflight.done.wait(timeout=wait_timeout):
                        self._finish_inflight(inflight)
                        inflight = None
                        continue

                    self._maybe_send_progress(inflight)
                    self._connection.process_data_events(time_limit=0.0)
            except pika.exceptions.AMQPError:
                if self._stop_requested:
                    break
                self._logger.exception("AMQP error; reconnecting soon")
                time.sleep(1.0)
            finally:
                self.close()

    def _maybe_send_progress(self, inflight: _InFlightRequest) -> None:
        if inflight.client_gone or inflight.progress_interval <= 0:
            return
        now = time.monotonic()
        if now - inflight.last_progress_at < inflight.progress_interval:
            return

        elapsed = now - inflight.started_at
        ctx = ProgressContext(
            worker_name=self._worker_name,
            method=inflight.method,
            args=inflight.args,
            kwargs=inflight.kwargs,
            started_at=inflight.started_at,
            elapsed=elapsed,
        )

        progress_payload: Any = {"status": "running"}
        if inflight.progress_provider is not None:
            try:
                progress_payload = inflight.progress_provider(ctx)
            except Exception:
                self._logger.exception("progress callback error; fallback to auto progress")
                inflight.progress_provider = None

        progress_msg = build_progress(progress_payload, elapsed=elapsed)
        try:
            progress_body = encode_json(progress_msg)
        except Exception:
            self._logger.exception("failed to serialize progress; fallback to auto progress")
            try:
                progress_body = encode_json(build_progress({"status": "running"}, elapsed=elapsed))
            except Exception:
                return

        if not inflight.props.reply_to:
            inflight.last_progress_at = now
            return

        ok = self._publish_reply(inflight.props, progress_body, msg_type="tanuki.progress", warn_unroutable=False)
        if not ok:
            inflight.client_gone = True
        inflight.last_progress_at = now

    def _finish_inflight(self, inflight: _InFlightRequest) -> None:
        resp = inflight.response or build_error_response(
            RuntimeError("missing response"),
            include_traceback=self._rabbitmq_config.include_traceback_in_error,
        )
        try:
            resp_body = encode_json(resp)
        except Exception as e:
            self._logger.exception("failed to serialize response")
            resp_body = encode_json(build_error_response(e, include_traceback=self._rabbitmq_config.include_traceback_in_error))

        if inflight.props.reply_to:
            self._publish_reply(inflight.props, resp_body, msg_type="tanuki.response", warn_unroutable=True)
        else:
            self._logger.debug("no reply_to set; dropping response")
        self._ack_if_needed(inflight.delivery_tag)
        self._publish_status(state="idle", method=None)

    def run(self) -> None:
        self._stop_requested = False
        self.close()
        self._request_queue = queue.Queue()
        self._transport_thread = threading.Thread(
            target=self._run_transport,
            name=f"tanuki:transport:{self._worker_name}",
            args=(self._request_queue,),
            daemon=True,
        )
        self._transport_thread.start()

        try:
            assert self._request_queue is not None
            while not self._stop_requested:
                try:
                    inflight = self._request_queue.get(timeout=0.2)
                except queue.Empty:
                    transport_thread = self._transport_thread
                    if transport_thread is not None and not transport_thread.is_alive() and not self._stop_requested:
                        raise RuntimeError("TanukiWorker transport thread stopped unexpectedly")
                    continue

                if inflight is None:
                    continue

                self._execute_inflight(inflight)
        except KeyboardInterrupt:
            self._logger.info("TanukiWorker stopping (KeyboardInterrupt)")
        finally:
            self._stop_requested = True
            if self._request_queue is not None:
                try:
                    self._request_queue.put_nowait(None)
                except Exception:
                    pass
            if self._transport_thread is not None:
                self._transport_thread.join(timeout=5.0)
            self._transport_thread = None
            self._request_queue = None
            self.close()

    def start(self) -> None:
        self.run()


def _coerce_log_level(level: int | str) -> int:
    if isinstance(level, int):
        return level
    name = level.strip().upper()
    mapping = logging.getLevelNamesMapping() if hasattr(logging, "getLevelNamesMapping") else logging._nameToLevel  # type: ignore[attr-defined]
    if name not in mapping:
        raise ValueError(f"unknown log level: {level!r}")
    return int(mapping[name])
