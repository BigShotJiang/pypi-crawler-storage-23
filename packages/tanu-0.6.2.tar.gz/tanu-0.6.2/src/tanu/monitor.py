from __future__ import annotations

import dataclasses
import logging
import threading
import time
import uuid
from typing import Any, Callable

import pika

from .config import RabbitMQConfig
from .rabbitmq import connect_blocking, declare_status_topology
from .utils.object_encoder_decoder import decode_json

logger = logging.getLogger("tanu.monitor")


class TanukiMonitor:
    def __init__(
        self,
        config: RabbitMQConfig | None = None,
        *,
        monitor_name: str | None = None,
        autostart: bool = True,
        **config_overrides: Any,
    ) -> None:
        base_config = config or RabbitMQConfig()
        if config_overrides:
            base_config = dataclasses.replace(base_config, **config_overrides)
        self._config = base_config
        self._monitor_name = monitor_name or f"tanuki-monitor:{uuid.uuid4().hex[:8]}"

        self.on_update: Callable[[str, dict[str, Any]], Any] | None = None

        self._lock = threading.Lock()
        self._status_by_worker: dict[str, dict[str, Any]] = {}

        self._stop_requested = False
        self._thread: threading.Thread | None = None

        self._connection: pika.BlockingConnection | None = None
        self._ch: pika.adapters.blocking_connection.BlockingChannel | None = None
        self._queue_name: str | None = None

        if autostart:
            self.start()

    @property
    def config(self) -> RabbitMQConfig:
        return self._config

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop_requested = False
        self._thread = threading.Thread(
            target=self._run,
            name="tanuki:monitor",
            daemon=True,
        )
        self._thread.start()

    def close(self) -> None:
        self._stop_requested = True
        if self._thread is not None and self._thread.is_alive() and threading.current_thread() is not self._thread:
            self._thread.join(timeout=5.0)
        self._thread = None
        self._close_connection()

    def stop(self) -> None:
        self.close()

    def __enter__(self) -> "TanukiMonitor":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:  # type: ignore[no-untyped-def]
        self.close()

    def get_status(self, worker_name: str) -> dict[str, Any] | None:
        with self._lock:
            if worker_name in self._status_by_worker:
                return dict(self._status_by_worker[worker_name])

            if "@" not in worker_name:
                matches = {
                    k: dict(v)
                    for k, v in self._status_by_worker.items()
                    if k == worker_name or k.startswith(f"{worker_name}@")
                }
                if len(matches) == 1:
                    return next(iter(matches.values()))
                if matches:
                    return {"worker": worker_name, "instances": matches}
        return None

    def get_all_statuses(self) -> dict[str, dict[str, Any]]:
        with self._lock:
            return {k: dict(v) for k, v in self._status_by_worker.items()}

    def list_workers(self) -> list[str]:
        with self._lock:
            return sorted(self._status_by_worker.keys())

    def _close_connection(self) -> None:
        if self._ch and self._ch.is_open:
            try:
                self._ch.close()
            except Exception:
                logger.debug("ignore close(ch) error", exc_info=True)
        if self._connection and self._connection.is_open:
            try:
                self._connection.close()
            except Exception:
                logger.debug("ignore close(connection) error", exc_info=True)
        self._connection = None
        self._ch = None
        self._queue_name = None

    def _ensure_connected(self) -> None:
        if self._connection and self._connection.is_open and self._ch and self._ch.is_open and self._queue_name:
            return

        self._close_connection()

        self._connection = connect_blocking(
            self._config,
            connection_name=self._monitor_name,
            max_retries=0,
            log=logger,
        )
        self._ch = self._connection.channel()
        declare_status_topology(self._ch, self._config)

        result = self._ch.queue_declare(queue="", exclusive=True, auto_delete=True)
        self._queue_name = result.method.queue
        self._ch.queue_bind(queue=self._queue_name, exchange=self._config.status_exchange_name(), routing_key="#")
        self._ch.basic_consume(queue=self._queue_name, on_message_callback=self._on_status, auto_ack=True)

    def _on_status(self, ch, method, props: pika.BasicProperties, body: bytes) -> None:  # type: ignore[no-untyped-def]
        try:
            msg = decode_json(body)
        except Exception:
            logger.debug("failed to decode status message", exc_info=True)
            return
        if not isinstance(msg, dict):
            return
        self._handle_status_message(msg)

    def _handle_status_message(self, msg: dict[str, Any]) -> None:
        worker = msg.get("worker")
        if not isinstance(worker, str) or not worker:
            return

        seen_at = time.time()
        merged = dict(msg)
        merged["seen_at"] = seen_at

        cb = None
        with self._lock:
            self._status_by_worker[worker] = merged
            cb = self.on_update

        if cb is not None:
            try:
                cb(worker, dict(merged))
            except Exception:
                logger.exception("TanukiMonitor on_update error")

    def _run(self) -> None:
        while not self._stop_requested:
            try:
                self._ensure_connected()
                assert self._connection is not None
                self._connection.process_data_events(time_limit=1.0)
            except pika.exceptions.AMQPError:
                if self._stop_requested:
                    break
                logger.debug("AMQP error in monitor loop; reconnecting soon", exc_info=True)
                self._close_connection()
                time.sleep(1.0)
            except Exception:
                if self._stop_requested:
                    break
                logger.debug("unexpected error in monitor loop; reconnecting soon", exc_info=True)
                self._close_connection()
                time.sleep(1.0)
