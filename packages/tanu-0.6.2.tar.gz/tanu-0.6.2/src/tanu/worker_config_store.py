from __future__ import annotations

import base64
import datetime as dt
import json
import os
import re
import threading
from collections.abc import Iterator, MutableMapping
from pathlib import Path
from typing import Any

try:
    import tomllib  # Python 3.11+
except ModuleNotFoundError:  # pragma: no cover
    try:
        import tomli as tomllib  # type: ignore[import-not-found]
    except ModuleNotFoundError as e:  # pragma: no cover
        raise ModuleNotFoundError("TOML support requires Python 3.11+ or `tomli` on Python 3.10") from e


_BARE_KEY_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def _safe_fs_name(name: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9._@-]+", "_", name.strip())
    safe = safe.strip("._-")
    return safe or "worker"


def _toml_escape_string(value: str) -> str:
    return (
        value.replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\b", "\\b")
        .replace("\t", "\\t")
        .replace("\n", "\\n")
        .replace("\f", "\\f")
        .replace("\r", "\\r")
    )


def _toml_key(key: str) -> str:
    if _BARE_KEY_RE.fullmatch(key):
        return key
    return f'"{_toml_escape_string(key)}"'


def _toml_inline_table(value: dict[str, Any]) -> str:
    items: list[str] = []
    for k, v in value.items():
        if not isinstance(k, str):
            raise TypeError("TOML keys must be str")
        items.append(f"{_toml_key(k)} = {_toml_value(v, inline=True)}")
    return "{ " + ", ".join(items) + " }"


def _toml_array(values: list[Any]) -> str:
    return "[" + ", ".join(_toml_value(v, inline=True) for v in values) + "]"


def _toml_value(value: Any, *, inline: bool) -> str:
    if value is None:
        raise TypeError("TOML does not support null (None)")
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if value == float("inf"):
            return "inf"
        if value == float("-inf"):
            return "-inf"
        if value != value:  # NaN
            return "nan"
        return repr(value)
    if isinstance(value, str):
        return f'"{_toml_escape_string(value)}"'
    if isinstance(value, bytes):
        b64 = base64.b64encode(value).decode("ascii")
        return f'"base64:{b64}"'
    if isinstance(value, Path):
        return f'"{_toml_escape_string(str(value))}"'
    if isinstance(value, dt.datetime):
        return value.isoformat()
    if isinstance(value, dt.date):
        return value.isoformat()
    if isinstance(value, dt.time):
        return value.isoformat()
    if isinstance(value, tuple):
        return _toml_array(list(value))
    if isinstance(value, list):
        return _toml_array(value)
    if isinstance(value, dict):
        if not inline:
            raise TypeError("nested dict must be handled as a TOML table")
        return _toml_inline_table(value)
    raise TypeError(f"unsupported type for TOML: {type(value).__name__}")


def dumps_toml(data: dict[str, Any]) -> str:
    lines: list[str] = []

    def _dump_table(table: dict[str, Any], *, path: list[str]) -> None:
        scalars: list[tuple[str, Any]] = []
        subtables: list[tuple[str, dict[str, Any]]] = []
        for k, v in table.items():
            if not isinstance(k, str):
                raise TypeError("TOML keys must be str")
            if isinstance(v, dict):
                subtables.append((k, v))
            else:
                scalars.append((k, v))

        for k, v in scalars:
            lines.append(f"{_toml_key(k)} = {_toml_value(v, inline=True)}")

        for k, v in subtables:
            if lines and lines[-1] != "":
                lines.append("")
            header = ".".join(_toml_key(p) for p in [*path, k])
            lines.append(f"[{header}]")
            _dump_table(v, path=[*path, k])

    _dump_table(data, path=[])
    return "\n".join(lines).rstrip() + "\n"


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (dt.datetime, dt.date, dt.time)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, bytes):
        return {"__tanu_bytes__": len(value)}
    if isinstance(value, list):
        if len(value) > 200:
            return {"__tanu_list__": len(value)}
        return [_jsonable(v) for v in value]
    if isinstance(value, dict):
        if len(value) > 200:
            return {"__tanu_dict__": len(value)}
        return {str(k): _jsonable(v) for k, v in value.items()}
    return repr(value)


class WorkerConfigStore(MutableMapping[str, Any]):
    def __init__(self, *, worker_name: str, config_dir: Path) -> None:
        self._worker_name = worker_name
        self._config_dir = Path(config_dir)
        safe_name = _safe_fs_name(worker_name)
        self._path = self._config_dir / f"{safe_name}.toml"
        self._history_path = self._config_dir / f"{safe_name}.history.jsonl"
        self._lock = threading.RLock()
        self._data: dict[str, Any] = {}
        self._load()

    @property
    def path(self) -> Path:
        return self._path

    @property
    def history_path(self) -> Path:
        return self._history_path

    def reload(self) -> None:
        with self._lock:
            self._load()

    def save(self) -> None:
        with self._lock:
            self._save_locked()

    def _load(self) -> None:
        try:
            self._config_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            return

        if not self._path.exists():
            self._data = {}
            return

        try:
            raw = self._path.read_bytes()
            if not raw.strip():
                self._data = {}
                return
            parsed = tomllib.loads(raw.decode("utf-8"))
            self._data = parsed if isinstance(parsed, dict) else {}
        except Exception:
            self._data = {}

    def _save_locked(self) -> None:
        self._config_dir.mkdir(parents=True, exist_ok=True)
        content = dumps_toml(self._data)
        tmp = self._path.with_suffix(self._path.suffix + ".tmp")
        tmp.write_text(content, encoding="utf-8")
        os.replace(tmp, self._path)

    def _append_history_locked(self, record: dict[str, Any]) -> None:
        self._config_dir.mkdir(parents=True, exist_ok=True)
        line = json.dumps(record, ensure_ascii=False, separators=(",", ":"))
        with self._history_path.open("a", encoding="utf-8") as f:
            f.write(line + "\n")

    def __getitem__(self, key: str) -> Any:
        with self._lock:
            return self._data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        if not isinstance(key, str):
            raise TypeError("config key must be str")
        with self._lock:
            old = self._data.get(key, None)
            self._data[key] = value
            self._save_locked()
            now = dt.datetime.now().astimezone().isoformat()
            self._append_history_locked(
                {
                    "ts": now,
                    "worker": self._worker_name,
                    "op": "set",
                    "key": key,
                    "old": _jsonable(old),
                    "new": _jsonable(value),
                }
            )

    def __delitem__(self, key: str) -> None:
        with self._lock:
            old = self._data[key]
            del self._data[key]
            self._save_locked()
            now = dt.datetime.now().astimezone().isoformat()
            self._append_history_locked(
                {
                    "ts": now,
                    "worker": self._worker_name,
                    "op": "del",
                    "key": key,
                    "old": _jsonable(old),
                }
            )

    def __iter__(self) -> Iterator[str]:
        with self._lock:
            return iter(dict(self._data))

    def __len__(self) -> int:
        with self._lock:
            return len(self._data)
