import unittest

from tanu import TanukiMonitor


class TestTanukiMonitor(unittest.TestCase):
    def test_handle_status_message_updates_store_and_calls_callback(self) -> None:
        monitor = TanukiMonitor(autostart=False)
        updates: list[tuple[str, dict]] = []
        monitor.on_update = lambda worker, msg: updates.append((worker, msg))  # type: ignore[assignment]

        monitor._handle_status_message({"worker": "mytanuki", "state": "idle", "method": None, "updated_at": 0})

        st = monitor.get_status("mytanuki")
        assert st is not None
        self.assertEqual(st.get("worker"), "mytanuki")
        self.assertEqual(st.get("state"), "idle")
        self.assertIn("seen_at", st)
        self.assertEqual(len(updates), 1)
        self.assertEqual(updates[0][0], "mytanuki")

    def test_get_status_base_name_matches_realm_worker(self) -> None:
        monitor = TanukiMonitor(autostart=False)
        monitor._handle_status_message({"worker": "mytanuki@lab", "state": "busy", "method": "add", "updated_at": 0})

        st = monitor.get_status("mytanuki")
        assert st is not None
        self.assertEqual(st.get("worker"), "mytanuki@lab")
        self.assertEqual(st.get("state"), "busy")
