import tempfile
import unittest

import pika

from tanu.worker import TanukiWorker, _InFlightRequest


class TestWorkerValidation(unittest.TestCase):
    def test_invalid_kwargs_returns_validation_error(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            worker = TanukiWorker("testworker", log_dir=td, config_dir=td)

            @worker.command("add")
            def add(a: int, b: int):  # type: ignore[no-untyped-def]
                return {"sum": a + b}

            props = pika.BasicProperties(correlation_id="c")
            inflight = _InFlightRequest(
                method="add",
                args=[],
                kwargs={"a": [1, 2], "b": 3},
                props=props,
                delivery_tag=None,
                started_at=0.0,
                last_progress_at=0.0,
                progress_interval=0.0,
                progress_provider=None,
            )
            worker._execute_inflight(inflight)
            assert inflight.response is not None
            self.assertFalse(inflight.response.get("ok", True))
            err = inflight.response.get("error") or {}
            self.assertEqual(err.get("type"), "ValidationError")

    def test_valid_kwargs_returns_ok(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            worker = TanukiWorker("testworker", log_dir=td, config_dir=td)

            @worker.command("add")
            def add(a: int, b: int):  # type: ignore[no-untyped-def]
                return {"sum": a + b}

            props = pika.BasicProperties(correlation_id="c")
            inflight = _InFlightRequest(
                method="add",
                args=[],
                kwargs={"a": 1, "b": 2},
                props=props,
                delivery_tag=None,
                started_at=0.0,
                last_progress_at=0.0,
                progress_interval=0.0,
                progress_provider=None,
            )
            worker._execute_inflight(inflight)
            assert inflight.response is not None
            self.assertTrue(inflight.response.get("ok", False))
            self.assertEqual(inflight.response.get("result"), {"sum": 3})

