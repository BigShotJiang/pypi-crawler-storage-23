"""Discrete distribution factories — thin facade.

Categorical stays as a native attrs struct (no internal counterpart).
Poisson and Binomial delegate to internal Distribution objects.
"""

from __future__ import annotations

import numpy as np
from attrs import frozen, field
from scipy import stats

from bossanova.internal.maths.distributions.base import Distribution


@frozen
class Categorical:
    """Categorical distribution for simulation.

    Generates categorical values from specified levels with optional probabilities.

    Args:
        levels: Category names. Either provide explicit levels or use k= for auto-naming.
        p: Probabilities for each level. Must sum to 1. If None, uniform distribution.
        k: Number of levels for auto-naming (level_1, level_2, ...).
            Ignored if levels is provided.

    Raises:
        ValueError: If neither levels nor k is provided.
        ValueError: If both levels and k are provided.
        ValueError: If p is provided without levels.
        ValueError: If the length of p does not match the length of levels.
        ValueError: If p does not sum to 1.

    Examples:
        ```python
        from bossanova.distributions import categorical

        cat = categorical(levels=["A", "B", "C"])
        rng = np.random.default_rng(42)
        samples = cat.sample(5, rng)  # shape (5,)

        cat = categorical(levels=["A", "B"], p=[0.8, 0.2])  # mostly "A"

        cat = categorical(k=4)  # level_1, level_2, level_3, level_4
        ```
    """

    levels: tuple[str, ...] | None = field(
        default=None, converter=lambda x: tuple(x) if x is not None else None
    )
    p: tuple[float, ...] | None = field(
        default=None, converter=lambda x: tuple(x) if x is not None else None
    )
    k: int | None = field(default=None)

    def __attrs_post_init__(self) -> None:
        """Validate that levels/k and p are consistent."""
        # Must have either levels or k
        if self.levels is None and self.k is None:
            msg = "Must specify either levels or k"
            raise ValueError(msg)
        if self.levels is not None and self.k is not None:
            msg = "Specify either levels or k, not both"
            raise ValueError(msg)

        # Validate p if provided
        if self.p is not None:
            if self.levels is None:
                msg = "p requires levels to be specified"
                raise ValueError(msg)
            if len(self.p) != len(self.levels):
                msg = f"p length ({len(self.p)}) must match levels length ({len(self.levels)})"
                raise ValueError(msg)
            if not np.isclose(sum(self.p), 1.0):
                msg = f"p must sum to 1.0, got {sum(self.p)}"
                raise ValueError(msg)

    @property
    def actual_levels(self) -> tuple[str, ...]:
        """Return the actual level names (resolving k if needed)."""
        if self.levels is not None:
            return self.levels
        return tuple(f"level_{i + 1}" for i in range(self.k))  # type: ignore[arg-type]

    @property
    def n_levels(self) -> int:
        """Return the number of levels."""
        return len(self.actual_levels)

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        """Sample n categorical values.

        Args:
            n: Number of samples to draw.
            rng: NumPy random number generator.

        Returns:
            Array of n categorical values as strings.
        """
        levels = self.actual_levels
        probs = self.p if self.p is not None else None
        indices = rng.choice(len(levels), size=n, p=probs)
        return np.array([levels[i] for i in indices])


# =============================================================================
# Factory functions
# =============================================================================


def categorical(
    levels: list[str] | None = None,
    *,
    p: list[float] | None = None,
    k: int | None = None,
) -> Categorical:
    """Create a categorical distribution.

    Args:
        levels: Category names. Either provide explicit levels or use k= for
            auto-naming (level_1, level_2, ...). Mutually exclusive with k.
        p: Probabilities for each level. Must sum to 1. Length must match
            levels. If None, a uniform distribution over levels is used.
            Requires levels to be specified.
        k: Number of levels for auto-naming (level_1, level_2, ...).
            Mutually exclusive with levels.

    Returns:
        Categorical distribution object.

    Raises:
        ValueError: If neither levels nor k is provided.
        ValueError: If both levels and k are provided.
        ValueError: If p is provided without levels.
        ValueError: If the length of p does not match the length of levels.
        ValueError: If p does not sum to 1.

    Examples:
        ```python
        categorical(["A", "B", "C"])
        # Categorical(levels=('A', 'B', 'C'), p=None, k=None)

        categorical(["A", "B"], p=[0.7, 0.3])
        # Categorical(levels=('A', 'B'), p=(0.7, 0.3), k=None)

        categorical(k=4)  # level_1, level_2, level_3, level_4
        # Categorical(levels=None, p=None, k=4)
        ```
    """
    return Categorical(levels=levels, p=p, k=k)


def poisson(rate: float = 1.0) -> Distribution:
    """Create a Poisson distribution.

    Args:
        rate: Rate parameter (lambda). Must be > 0. Default is 1.0.

    Returns:
        Distribution object.

    Raises:
        ValueError: If rate is not positive.

    Examples:
        ```python
        dist = poisson()           # Poisson(1)
        dist = poisson(rate=5.0)   # Poisson(5), mean = 5
        ```
    """
    if rate <= 0:
        raise ValueError("rate must be > 0")
    return Distribution(
        dist=stats.poisson(mu=rate),
        name="Poisson",
        params={"rate": rate},
    )


def binomial(n: int = 1, p: float = 0.5) -> Distribution:
    """Create a binomial distribution.

    Args:
        n: Number of trials. Must be >= 1. Default is 1 (Bernoulli).
        p: Probability of success. Must be in [0, 1]. Default is 0.5.

    Returns:
        Distribution object.

    Raises:
        ValueError: If n is not an integer >= 1 or p is not in [0, 1].

    Examples:
        ```python
        dist = binomial()              # Bernoulli(0.5)
        dist = binomial(n=10, p=0.3)   # Binomial(10, 0.3), mean = 3
        ```
    """
    if not isinstance(n, int) or n < 1:
        raise ValueError("n must be an integer >= 1")
    if not 0 <= p <= 1:
        raise ValueError(f"p ({p}) must be in [0, 1]")
    return Distribution(
        dist=stats.binom(n=n, p=p),
        name="Binomial",
        params={"n": n, "p": p},
    )


__all__ = [
    "Categorical",
    "Distribution",
    "binomial",
    "categorical",
    "poisson",
]
