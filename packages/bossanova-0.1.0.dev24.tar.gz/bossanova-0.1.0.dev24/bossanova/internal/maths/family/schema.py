"""Family configuration dataclass."""

from dataclasses import dataclass
from typing import Callable

# Conditional JAX import for Pyodide compatibility
try:
    import jax.numpy as jnp
except (ImportError, AttributeError):
    import numpy as jnp  # type: ignore[no-redef]

__all__ = [
    "ESTIMATED_DISPERSION_FAMILIES",
    "Family",
]

# Families where the dispersion/scale parameter is estimated from data
# (affects AIC/BIC parameter count and inference distribution choice).
ESTIMATED_DISPERSION_FAMILIES: frozenset[str] = frozenset(
    {"gaussian", "gamma", "tdist"}
)


@dataclass(frozen=True, slots=True)
class Family:
    """Family configuration for GLM fitting.

    All functions are pure JAX operations, enabling JIT compilation and
    automatic differentiation. This is a simple data container with no methods.

    Attributes:
        name: Family name (e.g., "gaussian", "binomial", "poisson", "tdist")
        link_name: Link function name (e.g., "identity", "logit", "log")
        link: Link function η = g(μ)
        link_inverse: Inverse link μ = g⁻¹(η)
        link_deriv: Link derivative dη/dμ
        variance: Variance function V(μ)
        deviance: Unit deviance function d(y, μ)
        loglik: Conditional log-likelihood function log p(y|μ)
        initialize: Initialization function for starting μ values.
            Signature: (y, weights=None) -> mu_init. The weights parameter
            is optional and only used by binomial family.
        dispersion: Dispersion parameter estimation function
        df: Degrees of freedom for t-distribution family (None for others)
        robust_weights: Optional function for residual-based weights (t-dist).
            Signature: (y, mu, scale) -> weights. Returns multiplicative
            weights that downweight outliers. None for standard families.
    """

    name: str
    link_name: str
    link: Callable[[jnp.ndarray], jnp.ndarray]
    link_inverse: Callable[[jnp.ndarray], jnp.ndarray]
    link_deriv: Callable[[jnp.ndarray], jnp.ndarray]
    variance: Callable[[jnp.ndarray], jnp.ndarray]
    deviance: Callable[[jnp.ndarray, jnp.ndarray], jnp.ndarray]
    loglik: Callable[[jnp.ndarray, jnp.ndarray], jnp.ndarray]
    initialize: Callable[..., jnp.ndarray]  # (y, weights=None) -> mu_init
    dispersion: Callable[[jnp.ndarray, jnp.ndarray, int], float]
    df: int | None = None
    robust_weights: Callable[[jnp.ndarray, jnp.ndarray, float], jnp.ndarray] | None = (
        None
    )
