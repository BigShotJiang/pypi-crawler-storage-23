"""Gaussian family functions for GLM fitting."""

# Conditional JAX import for Pyodide compatibility
try:
    import jax
    import jax.numpy as jnp
except (ImportError, AttributeError):
    import numpy as jnp  # type: ignore[no-redef]

    # No-op decorator when JAX is not available
    class FakeJax:
        @staticmethod
        def jit(fn):
            return fn

    jax = FakeJax()  # type: ignore[assignment]

from bossanova.internal.maths.family.links import (
    identity_link,
    identity_link_deriv,
    identity_link_inverse,
)
from bossanova.internal.maths.family.schema import Family

__all__ = [
    "gaussian",
    "gaussian_deviance",
    "gaussian_dispersion",
    "gaussian_initialize",
    "gaussian_loglik",
    "gaussian_variance",
]


# ============================================================================
# Gaussian Family Functions
# ============================================================================


@jax.jit
def gaussian_variance(mu: jnp.ndarray) -> jnp.ndarray:
    """Gaussian variance function: V(μ) = 1.

    Args:
        mu: Mean values (n,)

    Returns:
        Variance values (n,), all ones
    """
    return jnp.ones_like(mu)


@jax.jit
def gaussian_deviance(y: jnp.ndarray, mu: jnp.ndarray) -> jnp.ndarray:
    """Gaussian unit deviance: d(y, μ) = (y - μ)².

    Args:
        y: Response values (n,)
        mu: Fitted mean values (n,)

    Returns:
        Unit deviance values (n,)
    """
    return (y - mu) ** 2


@jax.jit
def gaussian_loglik(y: jnp.ndarray, mu: jnp.ndarray) -> jnp.ndarray:
    """Gaussian conditional log-likelihood (per observation).

    Computes log p(y|μ) = -0.5 * (y - μ)² ignoring constant terms.
    The full Gaussian log-likelihood includes -0.5*log(2πσ²), but this
    constant term cancels in optimization and is added separately when
    computing final log-likelihood values.

    Args:
        y: Response values (n,)
        mu: Fitted mean values (n,)

    Returns:
        Per-observation log-likelihood values (n,), NOT summed
    """
    return -0.5 * (y - mu) ** 2


def gaussian_initialize(
    y: jnp.ndarray, weights: jnp.ndarray | None = None
) -> jnp.ndarray:
    """Initialize μ for Gaussian family.

    Uses y directly as the starting value (matches R's gaussian family).

    Args:
        y: Response values (n,)
        weights: Optional prior weights (n,). Unused for Gaussian, included
            for API consistency with other families.

    Returns:
        Initial mean values (n,)
    """
    # R uses mustart <- y for Gaussian
    return y + 0.01 * jnp.std(y)


def gaussian_dispersion(y: jnp.ndarray, mu: jnp.ndarray, df_resid: int) -> float:
    """Estimate dispersion parameter for Gaussian family.

    Uses Pearson χ² / df_resid.

    Args:
        y: Response values (n,)
        mu: Fitted mean values (n,)
        df_resid: Residual degrees of freedom

    Returns:
        Dispersion estimate φ̂
    """
    var = gaussian_variance(mu)
    pearson_resid = (y - mu) / jnp.sqrt(var + 1e-10)
    pearson_chi2 = jnp.sum(pearson_resid**2)
    return float(pearson_chi2 / df_resid) if df_resid > 0 else 1.0


# ============================================================================
# Family Factory Function
# ============================================================================


def gaussian(link: str | None = None) -> Family:
    """Create Gaussian family with identity link.

    The Gaussian family is appropriate for continuous response data with
    constant variance. This is equivalent to ordinary least squares (OLS)
    when using the identity link.

    Args:
        link: Link function name. Only "identity" supported (canonical).
            Defaults to "identity" if None.

    Returns:
        Gaussian family configuration

    Raises:
        ValueError: If link is not None or "identity"

    Examples:
        >>> fam = gaussian()
        >>> fam.name
        'gaussian'
        >>> fam.link_name
        'identity'
    """
    if link is None or link == "identity":
        return Family(
            name="gaussian",
            link_name="identity",
            link=identity_link,
            link_inverse=identity_link_inverse,
            link_deriv=identity_link_deriv,
            variance=gaussian_variance,
            deviance=gaussian_deviance,
            loglik=gaussian_loglik,
            initialize=gaussian_initialize,
            dispersion=gaussian_dispersion,
        )
    else:
        raise ValueError(
            f"Invalid link '{link}' for gaussian family. Supported links: 'identity'"
        )
