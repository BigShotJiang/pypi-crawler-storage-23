"""GLM family functions for link, variance, and deviance computations.

This module provides pure JAX functions for GLM families, designed for JIT compilation
and automatic differentiation. All link, variance, and deviance functions are
stateless and composable.

Provides:
    Link functions:
        identity_link, identity_link_inverse, identity_link_deriv
        log_link, log_link_inverse, log_link_deriv
        logit_link, logit_link_inverse, logit_link_deriv
        probit_link, probit_link_inverse, probit_link_deriv
        inverse_link, inverse_link_inverse, inverse_link_deriv
        cloglog_link, cloglog_link_inverse, cloglog_link_deriv

    Link dispatchers (apply by name):
        apply_link(link_name, mu) -> eta
        apply_link_inverse(link_name, eta) -> mu
        apply_link_deriv(link_name, mu) -> d_eta/d_mu

    Family-specific functions (variance, deviance, loglik, initialize, dispersion):
        gaussian_*, binomial_*, poisson_*, gamma_*, tdist_*

    Family container:
        Family: NamedTuple holding family configuration

    Factory functions:
        gaussian(), binomial(), poisson(), gamma(), tdist()
        build_family(): Create family from string name
"""

# Family configuration
from bossanova.internal.maths.family.schema import ESTIMATED_DISPERSION_FAMILIES, Family

# Link functions and dispatchers
from bossanova.internal.maths.family.links import (
    LINK_FUNCTIONS,
    apply_link,
    apply_link_deriv,
    apply_link_inverse,
    cloglog_link,
    cloglog_link_deriv,
    cloglog_link_inverse,
    identity_link,
    identity_link_deriv,
    identity_link_inverse,
    inverse_link,
    inverse_link_deriv,
    inverse_link_inverse,
    log_link,
    log_link_deriv,
    log_link_inverse,
    logit_link,
    logit_link_deriv,
    logit_link_inverse,
    probit_link,
    probit_link_deriv,
    probit_link_inverse,
)

# Gaussian family
from bossanova.internal.maths.family.gaussian import (
    gaussian,
    gaussian_deviance,
    gaussian_dispersion,
    gaussian_initialize,
    gaussian_loglik,
    gaussian_variance,
)

# Binomial family
from bossanova.internal.maths.family.binomial import (
    binomial,
    binomial_deviance,
    binomial_dispersion,
    binomial_initialize,
    binomial_loglik,
    binomial_variance,
)

# Poisson family
from bossanova.internal.maths.family.poisson import (
    poisson,
    poisson_deviance,
    poisson_dispersion,
    poisson_initialize,
    poisson_loglik,
    poisson_variance,
)

# Gamma family
from bossanova.internal.maths.family.gamma import (
    gamma,
    gamma_deviance,
    gamma_dispersion,
    gamma_initialize,
    gamma_loglik,
    gamma_variance,
)

# Student-t family
from bossanova.internal.maths.family.tdist import (
    tdist,
    tdist_deviance,
    tdist_dispersion,
    tdist_initialize,
    tdist_loglik,
    tdist_robust_weights,
    tdist_variance,
)

# Response sampling
from bossanova.internal.maths.family.response import (
    CANONICAL_LINKS,
    resolve_sigma,
    sample_response,
)

# Family dispatcher
from bossanova.internal.maths.family.create import build_family

__all__ = [
    "CANONICAL_LINKS",
    "ESTIMATED_DISPERSION_FAMILIES",
    "LINK_FUNCTIONS",
    "Family",
    "apply_link",
    "apply_link_deriv",
    "apply_link_inverse",
    "binomial",
    "binomial_deviance",
    "binomial_dispersion",
    "binomial_initialize",
    "binomial_loglik",
    "binomial_variance",
    "build_family",
    "cloglog_link",
    "cloglog_link_deriv",
    "cloglog_link_inverse",
    "gamma",
    "gamma_deviance",
    "gamma_dispersion",
    "gamma_initialize",
    "gamma_loglik",
    "gamma_variance",
    "gaussian",
    "gaussian_deviance",
    "gaussian_dispersion",
    "gaussian_initialize",
    "gaussian_loglik",
    "gaussian_variance",
    "identity_link",
    "identity_link_deriv",
    "identity_link_inverse",
    "inverse_link",
    "inverse_link_deriv",
    "inverse_link_inverse",
    "log_link",
    "log_link_deriv",
    "log_link_inverse",
    "logit_link",
    "logit_link_deriv",
    "logit_link_inverse",
    "poisson",
    "poisson_deviance",
    "poisson_dispersion",
    "poisson_initialize",
    "poisson_loglik",
    "poisson_variance",
    "probit_link",
    "probit_link_deriv",
    "probit_link_inverse",
    "resolve_sigma",
    "sample_response",
    "tdist",
    "tdist_deviance",
    "tdist_dispersion",
    "tdist_initialize",
    "tdist_loglik",
    "tdist_robust_weights",
    "tdist_variance",
]
