"""Link functions for GLM families."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np

# Conditional JAX import for Pyodide compatibility
try:
    import jax
    import jax.numpy as jnp
    import jax.scipy as jsp
except (ImportError, AttributeError):
    import numpy as jnp  # type: ignore[no-redef]
    import scipy as jsp  # type: ignore[no-redef]

    # No-op decorator when JAX is not available
    class FakeJax:
        @staticmethod
        def jit(fn):
            return fn

    jax = FakeJax()  # type: ignore[assignment]

__all__ = [
    "LINK_FUNCTIONS",
    "apply_link",
    "apply_link_deriv",
    "apply_link_inverse",
    "apply_link_inverse_deriv",
    "cloglog_link",
    "cloglog_link_deriv",
    "cloglog_link_inverse",
    "identity_link",
    "identity_link_deriv",
    "identity_link_inverse",
    "inverse_link",
    "inverse_link_deriv",
    "inverse_link_inverse",
    "log_link",
    "log_link_deriv",
    "log_link_inverse",
    "logit_link",
    "logit_link_deriv",
    "logit_link_inverse",
    "probit_link",
    "probit_link_deriv",
    "probit_link_inverse",
]


# ============================================================================
# Link Functions (pure JAX, JIT-decorated)
# ============================================================================


@jax.jit
def identity_link(mu: jnp.ndarray) -> jnp.ndarray:
    """Identity link function: η = μ.

    Args:
        mu: Mean values (n,)

    Returns:
        Linear predictor values η (n,)
    """
    return mu


@jax.jit
def identity_link_inverse(eta: jnp.ndarray) -> jnp.ndarray:
    """Identity inverse link: μ = η.

    Args:
        eta: Linear predictor values (n,)

    Returns:
        Mean values μ (n,)
    """
    return eta


@jax.jit
def identity_link_deriv(mu: jnp.ndarray) -> jnp.ndarray:
    """Identity link derivative: dη/dμ = 1.

    Args:
        mu: Mean values (n,)

    Returns:
        Derivative values (n,)
    """
    return jnp.ones_like(mu)


@jax.jit
def log_link(mu: jnp.ndarray) -> jnp.ndarray:
    """Log link function: η = log(μ).

    Args:
        mu: Mean values (n,), must be positive

    Returns:
        Linear predictor values η (n,)
    """
    return jnp.log(mu)


@jax.jit
def log_link_inverse(eta: jnp.ndarray) -> jnp.ndarray:
    """Log inverse link: μ = exp(η).

    Args:
        eta: Linear predictor values (n,)

    Returns:
        Mean values μ (n,)
    """
    return jnp.exp(eta)


@jax.jit
def log_link_deriv(mu: jnp.ndarray) -> jnp.ndarray:
    """Log link derivative: dη/dμ = 1/μ.

    Args:
        mu: Mean values (n,), must be positive

    Returns:
        Derivative values (n,)
    """
    return 1.0 / mu


@jax.jit
def logit_link(mu: jnp.ndarray) -> jnp.ndarray:
    """Logit link function: η = log(μ/(1-μ)).

    Values are clipped to [1e-10, 1-1e-10] to avoid log(0).

    Args:
        mu: Mean values (n,), must be in (0, 1)

    Returns:
        Linear predictor values η (n,)
    """
    mu_clipped = jnp.clip(mu, 1e-10, 1 - 1e-10)
    return jnp.log(mu_clipped / (1 - mu_clipped))


@jax.jit
def logit_link_inverse(eta: jnp.ndarray) -> jnp.ndarray:
    """Logit inverse link: μ = 1/(1 + exp(-η)).

    Uses numerically stable computation to avoid overflow.

    Args:
        eta: Linear predictor values (n,)

    Returns:
        Mean values μ (n,) in (0, 1)
    """
    return jnp.where(
        eta >= 0,
        1.0 / (1.0 + jnp.exp(-eta)),
        jnp.exp(eta) / (1.0 + jnp.exp(eta)),
    )


@jax.jit
def logit_link_deriv(mu: jnp.ndarray) -> jnp.ndarray:
    """Logit link derivative: dη/dμ = 1/(μ(1-μ)).

    Values are clipped to [1e-10, 1-1e-10] to avoid division by zero.

    Args:
        mu: Mean values (n,), must be in (0, 1)

    Returns:
        Derivative values (n,)
    """
    mu_clipped = jnp.clip(mu, 1e-10, 1 - 1e-10)
    return 1.0 / (mu_clipped * (1 - mu_clipped))


@jax.jit
def probit_link(mu: jnp.ndarray) -> jnp.ndarray:
    """Probit link function: η = Φ⁻¹(μ).

    Uses the inverse error function for numerical stability.
    Values are clipped to [1e-10, 1-1e-10] to avoid infinite results.

    Args:
        mu: Mean values (n,), must be in (0, 1)

    Returns:
        Linear predictor values η (n,)
    """
    mu_clipped = jnp.clip(mu, 1e-10, 1 - 1e-10)
    # Φ⁻¹(p) = √2 * erf⁻¹(2p - 1)
    return jnp.sqrt(2.0) * jsp.special.erfinv(2.0 * mu_clipped - 1.0)


@jax.jit
def probit_link_inverse(eta: jnp.ndarray) -> jnp.ndarray:
    """Probit inverse link: μ = Φ(η).

    Args:
        eta: Linear predictor values (n,)

    Returns:
        Mean values μ (n,) in (0, 1)
    """
    return jsp.stats.norm.cdf(eta)


@jax.jit
def probit_link_deriv(mu: jnp.ndarray) -> jnp.ndarray:
    """Probit link derivative: dη/dμ = 1/φ(Φ⁻¹(μ)).

    Where φ is the standard normal PDF.
    Values are clipped to [1e-10, 1-1e-10] to avoid infinite results.

    Args:
        mu: Mean values (n,), must be in (0, 1)

    Returns:
        Derivative values (n,)
    """
    mu_clipped = jnp.clip(mu, 1e-10, 1 - 1e-10)
    eta = jnp.sqrt(2.0) * jsp.special.erfinv(2.0 * mu_clipped - 1.0)
    # φ(η) = exp(-η²/2) / √(2π)
    pdf_val = jnp.exp(-(eta**2) / 2.0) / jnp.sqrt(2.0 * jnp.pi)
    return 1.0 / (pdf_val + 1e-10)


@jax.jit
def inverse_link(mu: jnp.ndarray) -> jnp.ndarray:
    """Inverse link function: η = 1/μ.

    Canonical link for Gamma family.

    Args:
        mu: Mean values (n,), must be positive

    Returns:
        Linear predictor values η (n,)
    """
    mu_clipped = jnp.clip(mu, 1e-10, jnp.inf)
    return 1.0 / mu_clipped


@jax.jit
def inverse_link_inverse(eta: jnp.ndarray) -> jnp.ndarray:
    """Inverse link inverse: μ = 1/η.

    Args:
        eta: Linear predictor values (n,), must be positive

    Returns:
        Mean values μ (n,)
    """
    eta_clipped = jnp.clip(eta, 1e-10, jnp.inf)
    return 1.0 / eta_clipped


@jax.jit
def inverse_link_deriv(mu: jnp.ndarray) -> jnp.ndarray:
    """Inverse link derivative: dη/dμ = -1/μ².

    Args:
        mu: Mean values (n,), must be positive

    Returns:
        Derivative values (n,)
    """
    mu_clipped = jnp.clip(mu, 1e-10, jnp.inf)
    return -1.0 / (mu_clipped**2)


@jax.jit
def cloglog_link(mu: jnp.ndarray) -> jnp.ndarray:
    """Complementary log-log link function: η = log(-log(1-μ)).

    Used for asymmetric binary responses where P(Y=1) approaches 1
    faster than it approaches 0.

    Args:
        mu: Mean values (n,), must be in (0, 1)

    Returns:
        Linear predictor values η (n,)
    """
    mu_clipped = jnp.clip(mu, 1e-10, 1 - 1e-10)
    return jnp.log(-jnp.log(1 - mu_clipped))


@jax.jit
def cloglog_link_inverse(eta: jnp.ndarray) -> jnp.ndarray:
    """Cloglog inverse link: μ = 1 - exp(-exp(η)).

    Args:
        eta: Linear predictor values (n,)

    Returns:
        Mean values μ (n,) in (0, 1)
    """
    return 1 - jnp.exp(-jnp.exp(eta))


@jax.jit
def cloglog_link_deriv(mu: jnp.ndarray) -> jnp.ndarray:
    """Cloglog link derivative: dη/dμ = 1/((1-μ) * (-log(1-μ))).

    Args:
        mu: Mean values (n,), must be in (0, 1)

    Returns:
        Derivative values (n,)
    """
    mu_clipped = jnp.clip(mu, 1e-10, 1 - 1e-10)
    one_minus_mu = 1 - mu_clipped
    neg_log_one_minus_mu = -jnp.log(one_minus_mu)
    return 1.0 / (one_minus_mu * neg_log_one_minus_mu + 1e-10)


# =============================================================================
# Link Function Dispatchers
# =============================================================================

# Mapping from link name to (link, inverse, deriv) functions
LINK_FUNCTIONS = {
    "identity": (identity_link, identity_link_inverse, identity_link_deriv),
    "log": (log_link, log_link_inverse, log_link_deriv),
    "logit": (logit_link, logit_link_inverse, logit_link_deriv),
    "probit": (probit_link, probit_link_inverse, probit_link_deriv),
    "inverse": (inverse_link, inverse_link_inverse, inverse_link_deriv),
    "cloglog": (cloglog_link, cloglog_link_inverse, cloglog_link_deriv),
}

# Valid link names for error messages
VALID_LINKS = tuple(LINK_FUNCTIONS.keys())


def apply_link(link: str, mu: "np.ndarray") -> "np.ndarray":
    """Apply link function by name: η = g(μ).

    Args:
        link: Link function name. One of: identity, log, logit, probit, inverse, cloglog.
        mu: Mean values (response scale).

    Returns:
        Linear predictor values η.

    Raises:
        ValueError: If link name is not recognized.

    Examples:
        >>> import numpy as np
        >>> mu = np.array([0.2, 0.5, 0.8])
        >>> apply_link("logit", mu)
        array([-1.386,  0.   ,  1.386])
    """
    if link not in LINK_FUNCTIONS:
        raise ValueError(
            f"Unknown link function: {link!r}. Valid links: {', '.join(VALID_LINKS)}"
        )
    link_fn, _, _ = LINK_FUNCTIONS[link]
    return link_fn(mu)


def apply_link_inverse(link: str, eta: "np.ndarray") -> "np.ndarray":
    """Apply inverse link function by name: μ = g⁻¹(η).

    Args:
        link: Link function name. One of: identity, log, logit, probit, inverse, cloglog.
        eta: Linear predictor values.

    Returns:
        Mean values μ (response scale).

    Raises:
        ValueError: If link name is not recognized.

    Examples:
        >>> import numpy as np
        >>> eta = np.array([-1, 0, 1])
        >>> apply_link_inverse("logit", eta)
        array([0.269, 0.5  , 0.731])
    """
    if link not in LINK_FUNCTIONS:
        raise ValueError(
            f"Unknown link function: {link!r}. Valid links: {', '.join(VALID_LINKS)}"
        )
    _, inverse_fn, _ = LINK_FUNCTIONS[link]
    return inverse_fn(eta)


def apply_link_inverse_deriv(link: str, eta: "np.ndarray") -> "np.ndarray":
    """Compute derivative of inverse link function: dμ/dη = d/dη[g⁻¹(η)].

    Used for delta method transformation from link to data scale:
    SE_data = |dμ/dη| × SE_link.

    The derivative is computed as 1 / (dη/dμ) evaluated at μ = g⁻¹(η).
    For logit: p·(1-p). For log: exp(η). For identity: 1.

    Args:
        link: Link function name. One of: identity, log, logit, probit, inverse, cloglog.
        eta: Linear predictor values.

    Returns:
        Derivative values dμ/dη.

    Raises:
        ValueError: If link name is not recognized.
    """
    if link not in LINK_FUNCTIONS:
        raise ValueError(
            f"Unknown link function: {link!r}. Valid links: {', '.join(VALID_LINKS)}"
        )
    _, inverse_fn, deriv_fn = LINK_FUNCTIONS[link]
    mu = inverse_fn(eta)
    return 1.0 / deriv_fn(mu)


def apply_link_deriv(link: str, mu: "np.ndarray") -> "np.ndarray":
    """Apply link function derivative by name: dη/dμ.

    Args:
        link: Link function name. One of: identity, log, logit, probit, inverse, cloglog.
        mu: Mean values (response scale).

    Returns:
        Derivative values dη/dμ.

    Raises:
        ValueError: If link name is not recognized.

    Examples:
        >>> import numpy as np
        >>> mu = np.array([0.2, 0.5, 0.8])
        >>> apply_link_deriv("logit", mu)
        array([6.25, 4.  , 6.25])
    """
    if link not in LINK_FUNCTIONS:
        raise ValueError(
            f"Unknown link function: {link!r}. Valid links: {', '.join(VALID_LINKS)}"
        )
    _, _, deriv_fn = LINK_FUNCTIONS[link]
    return deriv_fn(mu)
