"""Poisson family functions for GLM fitting."""

# Conditional JAX import for Pyodide compatibility
try:
    import jax
    import jax.numpy as jnp
    import jax.scipy as jsp
except (ImportError, AttributeError):
    import numpy as jnp  # type: ignore[no-redef]
    import scipy as jsp  # type: ignore[no-redef]

    # No-op decorator when JAX is not available
    class FakeJax:
        @staticmethod
        def jit(fn):
            return fn

    jax = FakeJax()  # type: ignore[assignment]

from bossanova.internal.maths.family.links import (
    log_link,
    log_link_deriv,
    log_link_inverse,
)
from bossanova.internal.maths.family.schema import Family

__all__ = [
    "poisson",
    "poisson_deviance",
    "poisson_dispersion",
    "poisson_initialize",
    "poisson_loglik",
    "poisson_variance",
]


# ============================================================================
# Poisson Family Functions
# ============================================================================


@jax.jit
def poisson_variance(mu: jnp.ndarray) -> jnp.ndarray:
    """Poisson variance function: V(μ) = μ.

    Args:
        mu: Mean values (n,), must be positive

    Returns:
        Variance values (n,)
    """
    return mu


@jax.jit
def poisson_deviance(y: jnp.ndarray, mu: jnp.ndarray) -> jnp.ndarray:
    """Poisson unit deviance: d(y, μ) = 2[y log(y/μ) - (y - μ)].

    Uses log-space arithmetic for numerical stability.

    Args:
        y: Response values (n,), must be non-negative
        mu: Fitted mean values (n,), must be positive

    Returns:
        Unit deviance values (n,)
    """
    mu_clipped = jnp.clip(mu, 1e-10, jnp.inf)

    # Use log-space: log(a/b) = log(a) - log(b)
    dev = jnp.where(
        y > 0,
        2 * (y * (jnp.log(y) - jnp.log(mu_clipped)) - (y - mu_clipped)),
        2 * mu_clipped,  # When y = 0: 2μ
    )
    return dev


@jax.jit
def poisson_loglik(y: jnp.ndarray, mu: jnp.ndarray) -> jnp.ndarray:
    """Poisson conditional log-likelihood (per observation).

    Computes log p(y|μ) = y*log(μ) - μ - log(y!).
    The log(y!) term uses log-gamma: log(Γ(y+1)) = log(y!).

    Uses numerical stability patterns similar to poisson_deviance.

    Args:
        y: Response values (n,), must be non-negative
        mu: Fitted mean values (n,), must be positive

    Returns:
        Per-observation log-likelihood values (n,), NOT summed
    """
    mu_clipped = jnp.clip(mu, 1e-10, jnp.inf)

    # log p(y|μ) = y*log(μ) - μ - log(Γ(y+1))
    ll = jnp.where(
        y > 0,
        y * jnp.log(mu_clipped) - mu_clipped - jsp.special.gammaln(y + 1),
        -mu_clipped,  # When y = 0: -μ (since log(0!) = 0)
    )
    return ll


def poisson_initialize(
    y: jnp.ndarray, weights: jnp.ndarray | None = None
) -> jnp.ndarray:
    """Initialize μ for Poisson family.

    Adds small value to avoid zero counts (matches R's poisson family).

    Args:
        y: Response values (n,), must be non-negative
        weights: Optional prior weights (n,). Unused for Poisson, included
            for API consistency with other families.

    Returns:
        Initial mean values (n,)
    """
    # R uses mustart <- y + 0.1 for Poisson
    return y + 0.1


def poisson_dispersion(y: jnp.ndarray, mu: jnp.ndarray, df_resid: int) -> float:
    """Dispersion parameter for Poisson family.

    Fixed at 1.0 for Poisson models (can estimate for quasi-Poisson).

    Args:
        y: Response values (n,)
        mu: Fitted mean values (n,)
        df_resid: Residual degrees of freedom (unused)

    Returns:
        Dispersion value (always 1.0)
    """
    return 1.0


# ============================================================================
# Family Factory Function
# ============================================================================


def poisson(link: str | None = None) -> Family:
    """Create Poisson family for count data.

    The Poisson family is appropriate for count data where the variance
    equals the mean. Commonly used for modeling event counts, frequencies,
    or rates.

    Args:
        link: Link function name. Only "log" supported (canonical).
            Defaults to "log" if None.

    Returns:
        Poisson family configuration

    Raises:
        ValueError: If link is not None or "log"

    Examples:
        >>> fam = poisson()
        >>> fam.name
        'poisson'
        >>> fam.link_name
        'log'
    """
    if link is None or link == "log":
        return Family(
            name="poisson",
            link_name="log",
            link=log_link,
            link_inverse=log_link_inverse,
            link_deriv=log_link_deriv,
            variance=poisson_variance,
            deviance=poisson_deviance,
            loglik=poisson_loglik,
            initialize=poisson_initialize,
            dispersion=poisson_dispersion,
        )
    else:
        raise ValueError(
            f"Invalid link '{link}' for poisson family. Supported links: 'log'"
        )
