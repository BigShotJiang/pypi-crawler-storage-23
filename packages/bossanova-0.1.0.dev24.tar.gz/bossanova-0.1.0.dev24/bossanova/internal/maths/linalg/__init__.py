"""Linear algebra solvers for least squares and sparse systems."""

from bossanova.internal.maths.linalg.qr import (
    QRSolveResult,
    qr_solve,
    qr_solve_jax,
)
from bossanova.internal.maths.linalg.schur import (
    compute_vcov_schur_sparse,
)
from bossanova.internal.maths.linalg.svd import (
    SVDSolveResult,
    svd_solve,
    svd_solve_jax,
)
from bossanova.internal.maths.linalg.rank import (
    detect_rank_deficiency,
)
from bossanova.internal.maths.linalg.sparse import (
    CHOLMODFactorization,
    SPLUFactorization,
    SparseFactorization,
    compute_sparse_cholesky,
)

__all__ = [
    "CHOLMODFactorization",
    "QRSolveResult",
    "SPLUFactorization",
    "SVDSolveResult",
    "SparseFactorization",
    "compute_sparse_cholesky",
    "compute_vcov_schur_sparse",
    "detect_rank_deficiency",
    "qr_solve",
    "qr_solve_jax",
    "svd_solve",
    "svd_solve_jax",
]
