"""PIRLS (Penalized Iteratively Reweighted Least Squares) algorithm for GLMMs.

This module implements the PIRLS algorithm for fitting generalized linear mixed
models using Laplace approximation. The algorithm combines IRLS (from GLMs) with
penalized least squares (from LMMs).

The module is split into three files:
    - ``pirls_sparse.py``: Core PIRLS inner-loop routines (IRLS quantities,
      weighted PLS, deviance, log-likelihood, PIRLS iteration).
    - ``heuristics.py``: Initialization heuristics, bounds, finite-difference
      derivatives, Hessian-based vcov.
    - ``glmer.py`` (this file): Orchestrator — deviance objectives and the
      top-level ``fit_glmm_pirls`` driver.

PIRLS Algorithm:
================
For fixed variance components theta:
    1. Initialize eta from GLM fit
    2. Until convergence:
        a. Compute working weights: w = 1 / (V(mu) * (deta/dmu)^2)
        b. Compute working response: z = eta + (y - mu) * deta/dmu
        c. Solve weighted penalized least squares:
           [X'WX      X'WZL    ] [beta]   [X'Wz  ]
           [L'Z'WX  L'Z'WZL + I] [u]    = [L'Z'Wz]
        d. Update: eta = X*beta + Z*L*u
        e. Check convergence on |delta_eta|

GLMM Deviance (Laplace approximation):
======================================
    -2 log L ~ sum(dev_resid) + log|L'Z'WZL + I| + ||u||^2

where:
    - sum(dev_resid) = sum of GLM deviance residuals
    - log|L'Z'WZL + I| = log-determinant from Cholesky
    - ||u||^2 = penalty term for spherical random effects

Reference:
----------
lme4 external.cpp:
    - pwrssUpdate (lines 308-375)
MixedModels.jl generalizedlinearmixedmodel.jl:
    - pirls! function (lines 600-655)
    - deviance function (lines 84-109)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import scipy.sparse as sp

from bossanova.internal.maths.family import Family
from bossanova.internal.maths.solvers.heuristics import (
    compute_hessian_vcov,
    deriv12,
    get_theta_lower_bounds,
    init_theta_glmm,
)
from bossanova.internal.maths.solvers.pirls_sparse import (
    compute_glmm_loglik,
    compute_irls_quantities,
    glmm_deviance,
    pirls_sparse,
    solve_weighted_pls_sparse,
)

if TYPE_CHECKING:
    from bossanova.internal.maths.solvers.lambda_builder import (
        LambdaTemplate,
        PatternTemplate,
    )

__all__ = [
    "compute_glmm_loglik",
    "compute_hessian_vcov",
    "compute_irls_quantities",
    "deriv12",
    "fit_glmm_pirls",
    "get_theta_lower_bounds",
    "glmm_deviance",
    "glmm_deviance_at_fixed_theta_beta",
    "glmm_deviance_objective",
    "init_theta_glmm",
    "pirls_sparse",
    "solve_weighted_pls_sparse",
]


def glmm_deviance_objective(
    theta: np.ndarray,
    X: np.ndarray,
    Z: sp.csc_matrix,
    y: np.ndarray,
    family: Family,
    n_groups_list: list[int],
    re_structure: str,
    metadata: dict | None = None,
    prior_weights: np.ndarray | None = None,
    pirls_max_iter: int = 30,
    pirls_tol: float = 1e-7,
    verbose: bool = False,
    lambda_template: "LambdaTemplate | None" = None,
    factor_cache: dict | None = None,
    pattern_template: "PatternTemplate | None" = None,
    pirls_result_cache: dict | None = None,
) -> float:
    """Compute GLMM deviance for outer optimization.

    This is the objective function for BOBYQA optimization over theta.

    Args:
        theta: Cholesky factor elements (lower triangle, column-major)
        X: Fixed effects design matrix (n, p)
        Z: Random effects design matrix (n, q), scipy sparse
        y: Response vector (n,)
        family: GLM family (binomial, poisson)
        n_groups_list: Number of groups per grouping factor
        re_structure: Random effects structure type
        metadata: Additional RE metadata
        prior_weights: Prior observation weights
        pirls_max_iter: Maximum PIRLS iterations per theta evaluation
        pirls_tol: PIRLS convergence tolerance (1e-7 matches lme4)
        verbose: Print verbose output
        lambda_template: Optional pre-built template for efficient Lambda updates.
            If provided, uses update_lambda_from_template instead of build_lambda_sparse.
            This avoids rebuilding the sparsity pattern on each call (~10-15% speedup).
        factor_cache: Optional mutable dict for caching Cholesky factors across
            theta evaluations. Should contain keys 'factor_S22' and 'factor_S'.
            Pass an empty dict {} to enable caching; factors will be stored
            and reused across calls, avoiding repeated symbolic analysis.
        pattern_template: PatternTemplate for preserving sparsity patterns.
            Required for cross-theta factor caching. When provided, ensures S22
            has consistent sparsity pattern even when theta hits boundaries (theta=0).
        pirls_result_cache: Optional mutable dict for caching the last PIRLS result.
            When provided, stores ``{"theta": theta_copy, "result": pirls_result}``
            on each call so the caller can reuse the result at the converged theta
            without a redundant PIRLS evaluation.

    Returns:
        GLMM deviance (scalar) - the Laplace approximation of -2*logLik
    """
    from bossanova.internal.maths.solvers.lambda_builder import (
        build_lambda_sparse,
        update_lambda_from_template,
    )

    # Build Lambda from theta (use template if provided for efficiency)
    if lambda_template is not None:
        Lambda = update_lambda_from_template(lambda_template, theta)
    else:
        Lambda = build_lambda_sparse(theta, n_groups_list, re_structure, metadata)

    # Extract cached factors if caching is enabled
    factor_S22 = factor_cache.get("factor_S22") if factor_cache is not None else None
    factor_S = factor_cache.get("factor_S") if factor_cache is not None else None

    # Run PIRLS to convergence (passing cached factors for symbolic reuse)
    pirls_result = pirls_sparse(
        X=X,
        Z=Z,
        Lambda=Lambda,
        y=y,
        family=family,
        prior_weights=prior_weights,
        max_iter=pirls_max_iter,
        tol=pirls_tol,
        verbose=verbose,
        factor_S22=factor_S22,
        factor_S=factor_S,
        pattern_template=pattern_template,
    )

    # Update cache with factors for next call
    if factor_cache is not None:
        factor_cache["factor_S22"] = pirls_result.get("factor_S22")
        factor_cache["factor_S"] = pirls_result.get("factor_S")

    # Cache full PIRLS result so caller can reuse at converged theta
    if pirls_result_cache is not None:
        pirls_result_cache["theta"] = theta.copy()
        pirls_result_cache["result"] = pirls_result

    return pirls_result["deviance"]


def glmm_deviance_at_fixed_theta_beta(
    theta: np.ndarray,
    beta: np.ndarray,
    X: np.ndarray,
    Z: sp.csc_matrix,
    y: np.ndarray,
    family: Family,
    n_groups_list: list[int],
    re_structure: str,
    metadata: dict | None = None,
    prior_weights: np.ndarray | None = None,
    pirls_max_iter: int = 30,
    pirls_tol: float = 1e-7,
    verbose: bool = False,
    eta_init: np.ndarray | None = None,
    lambda_template: "LambdaTemplate | None" = None,
    factor_cache: dict | None = None,
    pattern_template: "PatternTemplate | None" = None,
) -> float:
    """Compute GLMM deviance at fixed (theta, beta) by solving only for u.

    This is the Stage 2 objective function for joint (theta, beta) optimization.
    Unlike glmm_deviance_objective which optimizes beta via PIRLS, this function
    holds beta fixed and only solves for the random effects u.

    This matches lme4's approach in Stage 2 where beta is added to the offset
    before PIRLS runs, so PIRLS only solves for u.

    Args:
        theta: Cholesky factor elements (lower triangle, column-major)
        beta: Fixed effects coefficients (p,) - held constant
        X: Fixed effects design matrix (n, p)
        Z: Random effects design matrix (n, q), scipy sparse
        y: Response vector (n,)
        family: GLM family (binomial, poisson)
        n_groups_list: Number of groups per grouping factor
        re_structure: Random effects structure type
        metadata: Additional RE metadata
        prior_weights: Prior observation weights
        pirls_max_iter: Maximum PIRLS iterations per theta evaluation
        pirls_tol: PIRLS convergence tolerance (1e-7 matches lme4)
        verbose: Print verbose output
        eta_init: Initial linear predictor for PIRLS. If provided, used as
            starting point instead of X @ beta. This matches lme4's lp0
            mechanism where the full linear predictor from Stage 1
            (X*beta + Z*Lambda*u) is saved and restored for Stage 2.
        lambda_template: Optional pre-built template for efficient Lambda updates.
            If provided, uses update_lambda_from_template instead of build_lambda_sparse.
            This avoids rebuilding the sparsity pattern on each call (~10-15% speedup).
        factor_cache: Optional mutable dict for caching Cholesky factors
            across theta evaluations. Pass an empty dict {} to enable caching.
            Caches factor_S22 and factor_S to avoid expensive Cholesky symbolic
            analysis on each evaluation.
        pattern_template: PatternTemplate for preserving sparsity patterns.
            Required for cross-theta factor caching. When provided, ensures S22
            has consistent sparsity pattern even when theta hits boundaries (theta=0).

    Returns:
        GLMM deviance (scalar) at the exact (theta, beta) point
    """
    from bossanova.internal.maths.solvers.lambda_builder import (
        build_lambda_sparse,
        update_lambda_from_template,
    )

    # Build Lambda from theta (use template if provided for efficiency)
    if lambda_template is not None:
        Lambda = update_lambda_from_template(lambda_template, theta)
    else:
        Lambda = build_lambda_sparse(theta, n_groups_list, re_structure, metadata)

    # Extract cached factors if caching is enabled
    # NOTE: We do NOT cache eta across theta evaluations. Unlike factor caching
    # (which saves expensive Cholesky symbolic analysis), eta caching can hurt
    # performance because the cached eta from a different theta may be a worse
    # starting point than eta_stage1 (lme4's lp0). lme4 always uses lp0 as the
    # initial linear predictor for Stage 2, not a cached eta from previous evals.
    factor_S22 = factor_cache.get("factor_S22") if factor_cache is not None else None
    factor_S = factor_cache.get("factor_S") if factor_cache is not None else None

    # Run PIRLS with beta fixed - only solves for u
    # If eta_init is provided, use it as starting point (lme4's lp0 mechanism)
    pirls_result = pirls_sparse(
        X=X,
        Z=Z,
        Lambda=Lambda,
        y=y,
        family=family,
        prior_weights=prior_weights,
        beta_fixed=beta,  # KEY: beta is fixed, PIRLS only solves for u
        eta_init=eta_init,  # Use cached eta or Stage 1's linear predictor
        max_iter=pirls_max_iter,
        tol=pirls_tol,
        verbose=verbose,
        factor_S22=factor_S22,
        factor_S=factor_S,
        pattern_template=pattern_template,
    )

    # Update cache with factors for next call (eta is NOT cached - see note above)
    if factor_cache is not None:
        factor_cache["factor_S22"] = pirls_result.get("factor_S22")
        factor_cache["factor_S"] = pirls_result.get("factor_S")

    return pirls_result["deviance"]


def fit_glmm_pirls(
    X: np.ndarray,
    Z: sp.csc_matrix,
    y: np.ndarray,
    family: Family,
    n_groups_list: list[int],
    re_structure: str,
    metadata: dict | None = None,
    theta_init: np.ndarray | None = None,
    prior_weights: np.ndarray | None = None,
    max_outer_iter: int = 10000,
    pirls_max_iter: int = 30,
    pirls_tol: float = 1e-7,
    verbose: bool = False,
    two_stage: bool = True,
    lambda_template: "LambdaTemplate | None" = None,
    nAGQ: int = 1,
    group_ids: np.ndarray | None = None,
) -> dict:
    """Fit GLMM using PIRLS with outer optimization over theta.

    Optimization strategy (matching lme4):
    - Stage 1: BOBYQA optimizes theta only, PIRLS solves for (beta, u) at each theta
    - Stage 2: Nelder-Mead optimizes [theta, beta] jointly, PIRLS only solves for u

    The two-stage approach matches lme4 exactly:
    - Stage 1 (nAGQ=0): Optimize theta via BOBYQA, with PIRLS finding optimal
      (beta, u) for each theta.
    - Stage 2 (nAGQ>=1): Joint optimization of [theta, beta] via Nelder-Mead,
      where beta is held fixed in PIRLS (added to offset) so PIRLS only solves
      for u. This allows the optimizer to find the global (theta, beta) optimum.
    - When nAGQ > 1, Stage 2 uses adaptive Gauss-Hermite quadrature instead
      of the Laplace approximation for more accurate marginal likelihood.

    Args:
        X: Fixed effects design matrix (n, p)
        Z: Random effects design matrix (n, q), scipy sparse
        y: Response vector (n,)
        family: GLM family (binomial, poisson)
        n_groups_list: Number of groups per grouping factor
        re_structure: Random effects structure type
        metadata: Additional RE metadata
        theta_init: Initial theta values (optional)
        prior_weights: Prior observation weights
        max_outer_iter: Maximum BOBYQA iterations for Stage 1
        pirls_max_iter: Maximum PIRLS iterations per theta evaluation
        pirls_tol: PIRLS convergence tolerance (1e-7 matches lme4)
        verbose: Print optimization progress
        two_stage: Use two-stage optimization matching lme4 (default True)
        lambda_template: Optional pre-built template for efficient Lambda updates.
            If provided, uses this template instead of building a new one.
            This is useful for bootstrap where the same template can be reused.
        nAGQ: Number of adaptive Gauss-Hermite quadrature points (default 1).
            nAGQ=1 uses the Laplace approximation. nAGQ > 1 uses AGQ for
            more accurate integration (scalar random intercept only).
        group_ids: Group membership array (n,), integer-coded. Required when
            nAGQ > 1 for per-group quadrature.

    Returns:
        Dictionary with:
        - theta: Optimized theta parameters
        - beta: Fixed effects coefficients
        - u: Spherical random effects
        - eta: Linear predictor
        - mu: Fitted values
        - deviance: Final GLMM deviance
        - loglik: Laplace log-likelihood
        - converged: Whether optimizer converged
        - n_outer_iter: Number of outer iterations
        - n_func_evals: Number of deviance evaluations
        - pirls_converged: Whether final PIRLS converged
        - pirls_n_iter: Final PIRLS iterations
    """
    import nlopt

    from bossanova.internal.maths.solvers.lambda_builder import (
        build_lambda_sparse,
        build_lambda_template,
        build_pattern_template,
    )
    from bossanova.internal.maths.solvers.optimize import optimize_theta

    n, p = X.shape

    # Initialize theta
    if theta_init is None:
        theta_init = init_theta_glmm(n_groups_list, re_structure, metadata)

    n_theta = len(theta_init)

    # Pre-build lambda template for efficient updates during optimization
    # This caches the sparsity pattern and only updates values (~10-15% speedup)
    # Use provided template if available (e.g., from bootstrap caller)
    if lambda_template is None:
        lambda_template = build_lambda_template(n_groups_list, re_structure, metadata)

    # Build pattern template for cross-theta caching
    # This is critical for matching lme4's behavior: sparsity pattern is fixed at
    # initialization and never changes during optimization, even when theta hits
    # boundaries (theta=0). Without this, CHOLMOD would use different permutations for
    # different patterns, causing numerical differences.
    pattern_template = None
    if lambda_template is not None:
        if not sp.isspmatrix_csc(Z):
            Z = Z.tocsc()
        pattern_template = build_pattern_template(Z, lambda_template)

    # =========================================================================
    # Stage 1: BOBYQA over theta only (matches lme4's nAGQ=0 stage)
    # =========================================================================
    # Cross-theta factor caching is ENABLED when pattern_template is available.
    # The pattern_template ensures S22 has a consistent sparsity pattern even when
    # theta hits boundaries (theta=0). This matches lme4's approach where the pattern
    # is fixed at initialization and never changes during optimization.
    #
    # Without pattern preservation, boundary theta values would cause:
    # - S22 at theta=[1,1,1] has 1062 nnz
    # - S22 at theta=[1.26,0,0] has 590 nnz (different pattern!)
    # - Different sparsity -> different CHOLMOD permutation -> numerical differences
    #
    # With pattern preservation, S22 always has the maximal pattern (1062 nnz).

    # Initialize factor cache for cross-theta caching (if pattern_template available)
    factor_cache_stage1 = {} if pattern_template is not None else None

    # Cache last PIRLS result to avoid redundant re-evaluation at converged theta
    pirls_result_cache: dict = {}

    def theta_objective(theta):
        return glmm_deviance_objective(
            theta=theta,
            X=X,
            Z=Z,
            y=y,
            family=family,
            n_groups_list=n_groups_list,
            re_structure=re_structure,
            metadata=metadata,
            prior_weights=prior_weights,
            pirls_max_iter=pirls_max_iter,
            pirls_tol=pirls_tol,
            verbose=False,
            lambda_template=lambda_template,
            factor_cache=factor_cache_stage1,
            pattern_template=pattern_template,
            pirls_result_cache=pirls_result_cache,
        )

    # Set bounds: diagonal elements >= 0, off-diagonal unbounded
    theta_lower = get_theta_lower_bounds(n_theta, re_structure, metadata)
    theta_upper = [float("inf")] * n_theta

    if verbose:
        print(f"Stage 1: Optimizing {n_theta} theta parameters with BOBYQA...")

    # Run Stage 1 with PDFO BOBYQA
    # Match lme4's minqa::bobyqa defaults (NOT optwrap's adj=TRUE settings)
    # minqa calculates: rhobeg = min(0.95, 0.2 * max(abs(par)))
    # For theta0=[1,1,...], this gives rhobeg=0.2
    # rhoend = 1e-6 * rhobeg = 2e-7
    rhobeg_stage1 = min(0.95, 0.2 * np.max(np.abs(theta_init)))
    stage1_result = optimize_theta(
        objective=theta_objective,
        theta0=theta_init,
        lower=theta_lower,
        upper=theta_upper,
        rhobeg=rhobeg_stage1,  # minqa default: min(0.95, 0.2*max(abs(par)))
        rhoend=1e-6 * rhobeg_stage1,  # minqa default: 1e-6 * rhobeg
        maxfun=max_outer_iter,
        verbose=verbose,
    )

    theta_stage1 = stage1_result["theta"]
    stage1_deviance = stage1_result["fun"]
    stage1_evals = stage1_result["n_evals"]
    stage1_converged = stage1_result["converged"]

    if verbose:
        print(
            f"  Stage 1 complete: deviance={stage1_deviance:.4f}, evals={stage1_evals}"
        )

    # Get beta/u from Stage 1 — reuse cached PIRLS result when available
    if (
        pirls_result_cache
        and "theta" in pirls_result_cache
        and np.allclose(pirls_result_cache["theta"], theta_stage1)
    ):
        pirls_stage1 = pirls_result_cache["result"]
    else:
        # Fallback: re-run PIRLS (should not happen in practice)
        Lambda_stage1 = build_lambda_sparse(
            theta_stage1, n_groups_list, re_structure, metadata
        )
        pirls_stage1 = pirls_sparse(
            X=X,
            Z=Z,
            Lambda=Lambda_stage1,
            y=y,
            family=family,
            prior_weights=prior_weights,
            max_iter=pirls_max_iter,
            tol=pirls_tol,
            verbose=False,
        )
    beta_stage1 = pirls_stage1["beta"]
    u_stage1 = pirls_stage1["u"]

    # Save full linear predictor from Stage 1 (lme4's lp0 mechanism)
    # This includes both fixed and random effects: eta = X*beta + Z*L*u
    # Used as starting point for Stage 2 PIRLS evaluations
    Lambda_stage1 = build_lambda_sparse(
        theta_stage1, n_groups_list, re_structure, metadata
    )
    ZL_stage1 = Z @ Lambda_stage1
    eta_stage1 = X @ beta_stage1 + ZL_stage1.toarray() @ u_stage1

    # =========================================================================
    # Stage 2: Nelder-Mead over [theta, beta] jointly (if two_stage=True)
    # =========================================================================
    if two_stage:
        if verbose:
            print(
                f"Stage 2: Joint optimization of {n_theta} theta + {p} beta "
                "with Nelder-Mead..."
            )

        # Cross-theta caching is ENABLED when pattern_template is available.
        # Same pattern preservation approach as Stage 1.
        factor_cache_stage2 = {} if pattern_template is not None else None

        # Combined objective for joint [theta, beta] optimization.
        # When nAGQ > 1, uses AGQ deviance for more accurate integration.
        # When nAGQ == 1, uses Laplace deviance (glmm_deviance_at_fixed_theta_beta).
        if nAGQ > 1:
            from bossanova.internal.maths.solvers.quadrature import (
                compute_agq_deviance,
            )

            def joint_objective(params):
                """AGQ deviance as function of combined [theta, beta] vector."""
                theta = params[:n_theta]
                beta = params[n_theta:]

                for _i, (t, lb) in enumerate(zip(theta, theta_lower)):
                    if t < lb:
                        return 1e10

                return compute_agq_deviance(
                    theta=theta,
                    beta=beta,
                    X=X,
                    Z=Z,
                    y=y,
                    family=family,
                    n_groups_list=n_groups_list,
                    re_structure=re_structure,
                    group_ids=group_ids,
                    nAGQ=nAGQ,
                    metadata=metadata,
                    prior_weights=prior_weights,
                    pirls_max_iter=pirls_max_iter,
                    pirls_tol=pirls_tol,
                    eta_init=eta_stage1,
                    lambda_template=lambda_template,
                    factor_cache=factor_cache_stage2,
                )
        else:

            def joint_objective(params):
                """Laplace deviance as function of combined [theta, beta] vector.

                Unlike Stage 1 where PIRLS optimizes both beta and u,
                Stage 2 holds beta fixed and PIRLS only solves for u.
                This allows the optimizer to find the joint (theta, beta) optimum.

                Uses eta_stage1 (the full linear predictor from Stage 1) as
                the starting point for PIRLS, matching lme4's lp0 mechanism.
                """
                theta = params[:n_theta]
                beta = params[n_theta:]

                # Enforce theta bounds (Nelder-Mead is unconstrained)
                for _i, (t, lb) in enumerate(zip(theta, theta_lower)):
                    if t < lb:
                        return 1e10  # Penalty for constraint violation

                # Compute deviance at this (theta, beta) by solving only for u
                # Pass eta_stage1 as initial linear predictor (lme4's lp0 mechanism)
                return glmm_deviance_at_fixed_theta_beta(
                    theta=theta,
                    beta=beta,
                    X=X,
                    Z=Z,
                    y=y,
                    family=family,
                    n_groups_list=n_groups_list,
                    re_structure=re_structure,
                    metadata=metadata,
                    prior_weights=prior_weights,
                    pirls_max_iter=pirls_max_iter,
                    pirls_tol=pirls_tol,
                    verbose=False,
                    eta_init=eta_stage1,  # lme4's lp0: full linear predictor from Stage 1
                    lambda_template=lambda_template,
                    factor_cache=factor_cache_stage2,
                    pattern_template=pattern_template,
                )

        # Initial guess: [theta_stage1, beta_stage1]
        x0 = np.concatenate([theta_stage1, beta_stage1])
        n_params = len(x0)

        # Use NLopt's Nelder-Mead for Stage 2 (closer to lme4's implementation)
        # Match lme4's Nelder-Mead settings (lme4/R/optimizer.R:27-33)
        # FtolAbs=1e-5, FtolRel=1e-15, XtolRel=1e-7, maxfun=10000
        def nlopt_objective(params, grad):
            return joint_objective(params)

        opt2 = nlopt.opt(nlopt.LN_NELDERMEAD, n_params)
        opt2.set_min_objective(nlopt_objective)
        opt2.set_maxeval(10000)
        opt2.set_ftol_abs(1e-5)  # Match lme4's FtolAbs
        opt2.set_ftol_rel(1e-15)  # Match lme4's FtolRel
        opt2.set_xtol_rel(1e-7)  # Match lme4's XtolRel

        # Set bounds: theta >= lower_bounds, beta unbounded (-inf, inf)
        lower_bounds = theta_lower + [float("-inf")] * p
        upper_bounds = [float("inf")] * n_params
        opt2.set_lower_bounds(lower_bounds)
        opt2.set_upper_bounds(upper_bounds)

        try:
            x_opt = np.array(opt2.optimize(x0.tolist()))
            final_deviance = opt2.last_optimum_value()
            converged = opt2.last_optimize_result() > 0
            stage2_evals = opt2.get_numevals()
        except nlopt.RoundoffLimited:
            # Optimization stopped due to roundoff - use last values
            x_opt = x0
            final_deviance = joint_objective(x0)
            converged = True
            stage2_evals = 1

        theta_opt = x_opt[:n_theta]
        beta_opt = x_opt[n_theta:]
        total_evals = stage1_evals + stage2_evals

        if verbose:
            print(
                f"  Stage 2 complete: deviance={final_deviance:.4f}, "
                f"evals={stage2_evals}"
            )

        # Get final results using beta_fixed to ensure we return values at the optimum
        # Pass eta_stage1 as initial linear predictor (lme4's lp0 mechanism)
        Lambda = build_lambda_sparse(theta_opt, n_groups_list, re_structure, metadata)
        pirls_result = pirls_sparse(
            X=X,
            Z=Z,
            Lambda=Lambda,
            y=y,
            family=family,
            prior_weights=prior_weights,
            beta_fixed=beta_opt,  # Use optimized beta
            eta_init=eta_stage1,  # lme4's lp0: full linear predictor from Stage 1
            max_iter=pirls_max_iter,
            tol=pirls_tol,
            verbose=verbose,
        )
    else:
        # Single-stage: just use Stage 1 results
        theta_opt = theta_stage1
        final_deviance = stage1_deviance
        total_evals = stage1_evals
        converged = stage1_converged
        pirls_result = pirls_stage1

    # Compute log-likelihood
    if nAGQ > 1:
        # AGQ deviance is already -2*loglik (integrated marginal likelihood)
        loglik = -0.5 * final_deviance
    else:
        # Deviance-based loglik (-0.5 * deviance) is missing the saturated model
        # normalizing constants (log(y!), log(choose(m,y))). Use the family's
        # loglik function directly, matching lme4's logLik().
        loglik = compute_glmm_loglik(
            y=y,
            mu=pirls_result["mu"],
            family=family,
            sqrL=float(np.sum(pirls_result["u"] ** 2)),
            logdet=pirls_result["logdet_L"],
            prior_weights=prior_weights,
        )

    return {
        "theta": theta_opt,
        "beta": pirls_result["beta"],
        "u": pirls_result["u"],
        "eta": pirls_result["eta"],
        "mu": pirls_result["mu"],
        "deviance": final_deviance,
        "loglik": loglik,
        "converged": converged,
        "n_outer_iter": total_evals,
        "n_func_evals": total_evals,
        "pirls_converged": pirls_result["converged"],
        "pirls_n_iter": pirls_result["n_iter"],
        "logdet_L": pirls_result["logdet_L"],
    }
