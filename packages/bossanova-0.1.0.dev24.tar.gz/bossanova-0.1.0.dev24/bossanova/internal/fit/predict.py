"""Prediction operations on containers.

Pure functions for computing predictions on new data, including
random effects contribution for mixed models. Extracted from model/core.py.

Functions:
    resolve_coef_for_predict: NaN-safe coefficients for matrix multiplication.
    validate_newdata_groups: Group column/level validation for mixed models.
    build_X_for_newdata: Design matrix construction for new observations.
    build_re_covariates: Random effects covariate matrix for valid rows.
    compute_re_contribution: BLUP contribution for mixed model predictions.
    compute_predictions: Main entry point for prediction computation.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

import numpy as np
import polars as pl
from numpy.typing import NDArray

if TYPE_CHECKING:
    from bossanova.internal.containers import (
        DataBundle,
        FitState,
        FormulaSpec,
        ModelSpec,
        PredictionState,
        REInfo,
        RankInfo,
    )

__all__ = [
    "build_X_for_newdata",
    "build_re_covariates",
    "compute_predictions",
    "compute_re_contribution",
    "resolve_coef_for_predict",
    "validate_newdata_groups",
]


def resolve_coef_for_predict(
    coef: NDArray[np.floating],
    rank_info: RankInfo | None,
) -> NDArray[np.floating]:
    """Coefficients safe for matrix multiplication (NaN -> 0).

    When rank-deficient columns produce NaN coefficients, those NaN values
    must be zeroed out for ``X @ coef`` to work correctly.  The dropped
    columns contribute nothing to predictions.

    Args:
        coef: Coefficient array, shape ``(p,)``.
        rank_info: Rank deficiency info from the DataBundle, or ``None``
            if the design is full rank.

    Returns:
        Coefficient array with NaN replaced by 0 when the design is
        rank-deficient, or the original array unchanged.
    """
    if rank_info is not None and rank_info.is_deficient:
        return np.where(np.isnan(coef), 0.0, coef)
    return coef


def validate_newdata_groups(
    re_meta: REInfo,
    training_data: pl.DataFrame | None,
    newdata: pl.DataFrame,
    allow_new_levels: bool,
) -> None:
    """Validate grouping columns and levels in new data for mixed models.

    Ensures that all grouping variables exist in *newdata* and that group
    levels are a subset of those seen during training (unless
    *allow_new_levels* is ``True``).

    Called from ``compute_predictions`` when ``varying="include"`` for
    mixed models, ensuring group structure is valid before attempting
    to compute BLUP contributions.

    Args:
        re_meta: Random effects metadata from the DataBundle.
        training_data: Original training DataFrame for extracting known
            group levels, or ``None``.
        newdata: New data for prediction as a Polars DataFrame.
        allow_new_levels: If ``True``, skip the unseen-level check.

    Raises:
        ValueError: If a grouping column is missing from *newdata*.
        ValueError: If unseen group levels are encountered and
            *allow_new_levels* is ``False``.
    """
    for group_var in re_meta.grouping_vars:
        # Check column exists
        if group_var not in newdata.columns:
            raise ValueError(
                f"Grouping variable '{group_var}' not found in newdata. "
                f"Mixed models require grouping variables for prediction. "
                f"Required grouping columns: {list(re_meta.grouping_vars)}"
            )

        # Check for unseen levels (skip if allow_new_levels)
        if not allow_new_levels and training_data is not None:
            if group_var in training_data.columns:
                known_levels = set(training_data[group_var].unique().to_list())
                new_levels = set(newdata[group_var].unique().to_list())
                unseen = new_levels - known_levels
                if unseen:
                    display = sorted(str(lv) for lv in unseen)[:10]
                    suffix = (
                        f"... and {len(unseen) - 10} more" if len(unseen) > 10 else ""
                    )
                    raise ValueError(
                        f"New levels {display}{suffix} in grouping variable "
                        f"'{group_var}' not seen during training. "
                        f"Use allow_new_levels=True for population-level "
                        f"predictions."
                    )


def build_X_for_newdata(
    formula_spec: FormulaSpec | None,
    X_names: tuple[str, ...],
    newdata: pl.DataFrame,
) -> NDArray[np.float64]:
    """Build design matrix X for new data.

    Uses the stored FormulaSpec to properly handle factors,
    transformations (log, poly, center), and interactions.  This ensures
    new data is encoded consistently with the training data.

    When no FormulaSpec is available (e.g. simulation-only workflows),
    falls back to manual column stacking.

    Args:
        formula_spec: Encoding state from ``build_design_matrices()``,
            or ``None`` for the fallback path.
        X_names: Column names of the training design matrix.
        newdata: New data for prediction as a Polars DataFrame.

    Returns:
        Design matrix with same columns as training X, shape
        ``(n_new, p)``.

    Raises:
        ValueError: If required predictor columns are missing from
            *newdata*.
        ValueError: If categorical variables have unseen levels.
    """
    # Primary path: use FormulaSpec for proper encoding
    if formula_spec is not None:
        from bossanova.internal.formula import evaluate_newdata

        return evaluate_newdata(formula_spec, newdata)

    # Fallback for models without formula spec (e.g. simulation-only)
    n = len(newdata)

    # Start with intercept if present
    if X_names[0] == "Intercept":
        columns: list[NDArray[np.float64]] = [np.ones(n)]
        predictor_names = X_names[1:]
    else:
        columns = []
        predictor_names = X_names

    # Add predictor columns
    for name in predictor_names:
        if name not in newdata.columns:
            raise ValueError(
                f"Predictor column '{name}' not found in newdata. "
                f"Required columns: {list(predictor_names)}"
            )
        columns.append(newdata[name].to_numpy())

    return np.column_stack(columns) if columns else np.ones((n, 1))


def build_re_covariates(
    newdata: pl.DataFrame,
    factor_names: list[str],
    valid_indices: NDArray[np.intp],
    formula_spec: FormulaSpec | None,
    X_names: tuple[str, ...],
) -> NDArray[np.float64]:
    """Build random effects covariate matrix for valid newdata rows.

    For each random effect term (e.g. Intercept, slope variable), extracts
    the appropriate covariate values from *newdata* for the valid rows.

    Args:
        newdata: New data DataFrame.
        factor_names: Names of random effect terms for this grouping factor
            (e.g. ``["Intercept", "x"]``).
        valid_indices: Integer indices of valid (non-NA) rows in *newdata*.
        formula_spec: FormulaSpec for proper design matrix encoding, or
            ``None`` for the fallback path.
        X_names: Column names from the training design matrix.

    Returns:
        Array of shape ``(n_valid, n_re)`` with covariate values.
    """
    n_valid = len(valid_indices)
    n_re = len(factor_names)
    X_re = np.zeros((n_valid, n_re))

    for r, re_name in enumerate(factor_names):
        if re_name in ("Intercept", "(Intercept)", "1"):
            X_re[:, r] = 1.0
        elif re_name in newdata.columns:
            all_vals = newdata[re_name].to_numpy()
            X_re[:, r] = all_vals[valid_indices]
        else:
            # Fallback: check if it matches an X column name
            # (handles transformed terms like poly(x, 2))
            X_names_list = list(X_names)
            if re_name in X_names_list:
                col_idx = X_names_list.index(re_name)
                X_new = build_X_for_newdata(formula_spec, X_names, newdata)
                X_re[:, r] = X_new[valid_indices, col_idx]
            else:
                # Last resort: treat as intercept
                X_re[:, r] = 1.0

    return X_re


def compute_re_contribution(
    re_meta: REInfo,
    theta: NDArray[np.floating],
    u: NDArray[np.floating],
    training_data: pl.DataFrame | None,
    newdata: pl.DataFrame,
    valid_mask: NDArray[np.bool_],
    allow_new_levels: bool,
    formula_spec: FormulaSpec | None,
    X_names: tuple[str, ...],
) -> NDArray[np.float64]:
    """Compute random effects contribution for new data predictions.

    For each valid observation in *newdata*, maps group labels to trained
    group indices and computes the BLUP contribution as the dot product
    of the random effects design row and the group's estimated BLUPs.

    Args:
        re_meta: Random effects metadata from the DataBundle.
        theta: Variance parameters (relative scale) from FitState.
        u: Spherical random effects from FitState.
        training_data: Original training data (Polars DataFrame) for
            extracting known group levels, or ``None``.
        newdata: New data with grouping columns.
        valid_mask: Boolean mask of valid (non-NA) rows in the design
            matrix, shape ``(n,)``.
        allow_new_levels: If ``True``, new groups get 0 RE contribution
            (population-level prediction).  If ``False``, raises ValueError.
        formula_spec: FormulaSpec for proper design matrix encoding (passed
            through to ``build_re_covariates``).
        X_names: Column names of the training design matrix (passed
            through to ``build_re_covariates``).

    Returns:
        Array of RE contributions for valid rows only, shape ``(n_valid,)``.

    Raises:
        ValueError: If a grouping variable is missing from *newdata*.
        ValueError: If unseen group levels are encountered and
            *allow_new_levels* is ``False``.
    """
    from bossanova.internal.maths.solvers.lambda_builder import build_lambda_sparse
    from bossanova.internal.fit.varying import _compute_per_factor_layout

    # Build Lambda and compute BLUPs: b = Lambda @ u
    Lambda = build_lambda_sparse(
        theta,
        re_meta.n_groups_list,
        re_meta.re_structure,
        re_meta.metadata,
    )
    b = Lambda @ u

    # Get random effect names and per-factor structure
    random_names = re_meta.random_names
    if not random_names:
        random_names = ["Intercept"]

    per_factor_n_re, per_factor_names = _compute_per_factor_layout(
        re_meta, random_names
    )
    re_structures_list = re_meta.metadata.get("re_structures_list", None)

    # Filter newdata to valid rows only
    n_valid = int(valid_mask.sum())
    valid_indices = np.where(valid_mask)[0]
    re_contribution = np.zeros(n_valid)

    b_offset = 0
    for g_idx, group_var in enumerate(re_meta.grouping_vars):
        n_groups_g = re_meta.n_groups_list[g_idx]
        n_re_this = per_factor_n_re[g_idx]
        factor_names = per_factor_names[g_idx]

        if group_var not in newdata.columns:
            raise ValueError(
                f"Grouping variable '{group_var}' not found in newdata. "
                f"Required for conditional predictions (varying='include')."
            )

        # Build mapping from training group labels to integer indices
        # This mirrors extract_group_info: sorted unique values -> 0..n_groups-1
        if training_data is not None and group_var in training_data.columns:
            unique_levels = sorted(training_data[group_var].unique().to_list())
        else:
            unique_levels = list(range(n_groups_g))
        label_to_idx = {label: idx for idx, label in enumerate(unique_levels)}

        # Get newdata group labels (all rows, then index into valid ones)
        new_labels = newdata[group_var].to_list()

        # Extract b values for this factor
        group_b = b[b_offset : b_offset + n_groups_g * n_re_this]

        # Handle layout: diagonal uses blocked, others use interleaved
        factor_struct = (
            re_structures_list[g_idx] if re_structures_list else re_meta.re_structure
        )
        if factor_struct == "diagonal":
            group_b_matrix = group_b.reshape(n_re_this, n_groups_g).T
        else:
            group_b_matrix = group_b.reshape(n_groups_g, n_re_this)

        # Build RE covariate values for valid rows
        X_re_valid = build_re_covariates(
            newdata, factor_names, valid_indices, formula_spec, X_names
        )

        # Compute RE contribution for each valid observation
        for vi, orig_idx in enumerate(valid_indices):
            label = new_labels[orig_idx]
            if label in label_to_idx:
                group_idx = label_to_idx[label]
                b_for_group = group_b_matrix[group_idx, :]
                x_re_for_obs = X_re_valid[vi, :]
                re_contribution[vi] += np.dot(x_re_for_obs, b_for_group)
            elif not allow_new_levels:
                known = sorted(str(k) for k in label_to_idx.keys())
                display = known[:10]
                suffix = f"... and {len(known) - 10} more" if len(known) > 10 else ""
                raise ValueError(
                    f"New group level '{label}' in '{group_var}' not seen "
                    f"during training. Known levels: {display}{suffix}. "
                    f"Use allow_new_levels=True for population-level "
                    f"predictions."
                )
            # else: new level with allow_new_levels=True -> contributes 0

        b_offset += n_groups_g * n_re_this

    return re_contribution


def compute_predictions(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    formula_spec: FormulaSpec | None,
    training_data: pl.DataFrame | None,
    newdata: pl.DataFrame | None,
    pred_type: Literal["response", "link"],
    *,
    varying: Literal["exclude", "include"] = "exclude",
    allow_new_levels: bool = False,
) -> PredictionState:
    """Compute predictions for given data.

    For training data (``newdata=None``), returns fitted values directly.
    For new data, builds the design matrix, computes the linear predictor,
    optionally adds random effects, and applies the inverse link function.

    Args:
        spec: Model specification (family, link, etc.).
        bundle: Training data bundle (X, X_names, rank_info, re_metadata).
        fit: Fitted state (coefficients, theta, u, fitted values).
        formula_spec: FormulaSpec for encoding new data, or ``None``.
        training_data: Original training DataFrame for group-level mapping,
            or ``None``.
        newdata: Data for prediction.  If ``None``, uses training data
            fitted values.
        pred_type: Prediction scale (``"response"`` or ``"link"``).
        varying: How to handle random effects for mixed models.
            ``"exclude"`` for population-level, ``"include"`` for
            conditional predictions with BLUPs.
        allow_new_levels: If ``True``, new groups predict at population
            level.  If ``False``, raises ValueError for unseen groups.

    Returns:
        PredictionState with fitted values and optional link-scale values.
    """
    from bossanova.internal.containers import build_prediction_state
    from bossanova.internal.maths.family import apply_link_inverse
    from bossanova.internal.maths.predict import (
        fill_valid,
        get_valid_rows,
        init_na_array,
    )

    safe_coef = resolve_coef_for_predict(fit.coef, bundle.rank_info)

    if newdata is None:
        # Use training data - return fitted values from fit
        # For mixed models with varying="include", fitted already includes BLUPs
        fitted = fit.fitted.copy()
        link_values: np.ndarray | None = None

        # For non-identity links, compute link scale values
        if spec.link != "identity":
            link_values = bundle.X @ safe_coef

            if pred_type == "link":
                return build_prediction_state(
                    fitted=link_values,
                    link=link_values,
                    X_pred=bundle.X,
                )

        return build_prediction_state(
            fitted=fitted,
            link=link_values,
            X_pred=bundle.X,
        )

    # Validate grouping columns/levels for mixed models with BLUPs
    if (
        varying == "include"
        and bundle.has_random_effects
        and bundle.re_metadata is not None
    ):
        validate_newdata_groups(
            re_meta=bundle.re_metadata,
            training_data=training_data,
            newdata=newdata,
            allow_new_levels=allow_new_levels,
        )

    # Build X matrix for new data
    X_new = build_X_for_newdata(formula_spec, bundle.X_names, newdata)

    # Handle NA rows: extract valid rows, compute only on those, fill back
    valid_mask, X_valid, n = get_valid_rows(X_new)

    if X_valid.shape[0] == 0:
        # All rows invalid — return all-NaN arrays
        nan_fitted = init_na_array(n)
        return build_prediction_state(
            fitted=nan_fitted,
            link=nan_fitted.copy(),
            X_pred=X_new,
        )

    # Compute linear predictor (link scale) on valid rows only
    eta_valid = X_valid @ safe_coef

    # Add random effects contribution for mixed models
    if varying == "include" and bundle.has_random_effects:
        re_contribution = compute_re_contribution(
            re_meta=bundle.re_metadata,
            theta=fit.theta,
            u=fit.u,
            training_data=training_data,
            newdata=newdata,
            valid_mask=valid_mask,
            allow_new_levels=allow_new_levels,
            formula_spec=formula_spec,
            X_names=bundle.X_names,
        )
        eta_valid = eta_valid + re_contribution

    # Build full-length eta with NaN at invalid positions
    eta = init_na_array(n)
    fill_valid(eta, valid_mask, eta_valid)

    if pred_type == "link":
        return build_prediction_state(
            fitted=eta,
            link=eta,
            X_pred=X_new,
        )

    # Apply inverse link function only to valid predictions
    fitted_valid = apply_link_inverse(spec.link, eta_valid)
    fitted = init_na_array(n)
    fill_valid(fitted, valid_mask, fitted_valid)

    return build_prediction_state(
        fitted=fitted,
        link=eta,
        X_pred=X_new,
    )
