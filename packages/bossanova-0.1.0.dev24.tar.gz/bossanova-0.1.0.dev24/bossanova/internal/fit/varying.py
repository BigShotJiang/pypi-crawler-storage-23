"""Varying parameter extraction for mixed-effects models.

Extracts BLUP (Best Linear Unbiased Predictor) computation and variance
component decomposition from the model class into pure functions on
containers. These operations convert fitted spherical random effects into
interpretable group-level parameters.

Internal exports:
    per_factor_re_info: Split global RE metadata into per-factor structures.
    compute_varying_state: Compute BLUPs from theta and u via Lambda matrix.
    compute_varying_spread_state: Extract variance components (tau², rho, ICC).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import polars as pl

from bossanova.internal.containers import (
    build_varying_spread_state,
    build_varying_state,
)
from bossanova.internal.containers.schemas import Col, VaryingSpreadBase
from bossanova.internal.maths.solvers.lambda_builder import build_lambda_sparse
from bossanova.internal.maths.variance import theta_to_variance_components

if TYPE_CHECKING:
    from numpy.typing import NDArray

    from bossanova.internal.containers import (
        DataBundle,
        FitState,
        REInfo,
        VaryingSpreadState,
        VaryingState,
    )


def per_factor_re_info(
    re_meta: REInfo,
    group_names: list[str],
) -> tuple[str | list[str], list[str] | dict[str, list[str]]]:
    """Split global RE metadata into per-factor structures and names.

    For crossed/nested/mixed models, the global ``re_structure`` is a single
    string (e.g. "crossed") and ``random_names`` is a concatenated list across
    all factors. This function splits them into per-factor structures and
    per-factor name dicts suitable for BLUP decomposition and convergence
    diagnostics.

    For single-factor models, returns the originals unchanged.

    Args:
        re_meta: Random effects metadata from the fitted model's DataBundle.
        group_names: Ordered list of grouping variable names
            (e.g. ``["subject"]`` or ``["subject", "item"]``).

    Returns:
        A tuple ``(re_structure, random_names)`` where:
        - For single-factor models: ``(str, list[str])`` — the originals.
        - For multi-factor models: ``(list[str], dict[str, list[str]])`` —
            per-factor structure list and a dict mapping group name to its
            random effect names.
    """
    re_structures_list = re_meta.metadata.get("re_structures_list", None)
    if re_structures_list is None or len(re_structures_list) != len(group_names):
        return re_meta.re_structure, re_meta.random_names

    # Build per-factor random names from the concatenated list
    names = re_meta.random_names or ["Intercept"]
    names_dict: dict[str, list[str]] = {}
    offset = 0
    for gi, struct in enumerate(re_structures_list):
        if struct == "intercept":
            k = 1
        elif struct in ("slope", "diagonal"):
            k = 2
        else:
            k = 1
        if offset + k <= len(names):
            names_dict[group_names[gi]] = names[offset : offset + k]
        else:
            names_dict[group_names[gi]] = (
                ["Intercept"] if k == 1 else [f"RE{j}" for j in range(k)]
            )
        offset += k

    return re_structures_list, names_dict


def _compute_per_factor_layout(
    re_meta: REInfo,
    random_names: list[str],
) -> tuple[list[int], list[list[str]]]:
    """Compute per-factor RE counts and name lists from metadata.

    Handles both single-factor and multi-factor (crossed/nested) models by
    inspecting ``re_structures_list`` in the metadata.

    Args:
        re_meta: Random effects metadata from the DataBundle.
        random_names: Global random effect names (already defaulted to
            ``["Intercept"]`` if empty).

    Returns:
        A tuple ``(per_factor_n_re, per_factor_names)`` where each list
        has one entry per grouping factor.
    """
    re_structures_list = re_meta.metadata.get("re_structures_list", None)
    n_factors = len(re_meta.grouping_vars)

    if re_structures_list is not None and len(re_structures_list) == n_factors:
        per_factor_n_re: list[int] = []
        per_factor_names: list[list[str]] = []
        name_offset = 0
        for struct in re_structures_list:
            if struct == "intercept":
                k = 1
            elif struct in ("slope", "diagonal"):
                k = 2  # matches lambda_builder hardcoded 2×2 blocks
            else:
                k = 1  # unknown structure fallback
            # Slice names from the concatenated list when possible
            if name_offset + k <= len(random_names):
                factor_names = random_names[name_offset : name_offset + k]
            else:
                factor_names = ["Intercept"] if k == 1 else [f"RE{j}" for j in range(k)]
            per_factor_n_re.append(k)
            per_factor_names.append(factor_names)
            name_offset += k
    else:
        # Single-factor model: global n_re_per_group applies uniformly
        n_re_per_group = len(random_names)
        per_factor_n_re = [n_re_per_group] * n_factors
        per_factor_names = [random_names] * n_factors

    return per_factor_n_re, per_factor_names


def compute_varying_state(
    theta: NDArray[np.floating],
    u: NDArray[np.floating],
    re_meta: REInfo,
    data: pl.DataFrame | None = None,
) -> VaryingState:
    """Compute VaryingState (BLUPs) from fitted random effects parameters.

    Converts spherical random effects ``u`` to BLUPs ``b = Lambda @ u``
    using the relative covariance factor Lambda built from ``theta``.
    Constructs a grid of group/level combinations and maps BLUP values
    to named effects.

    Args:
        theta: Variance component parameters from the fitted model.
        u: Spherical random effects vector from the fitted model.
        re_meta: Random effects metadata (grouping vars, structure, etc.).
        data: Original training data, used to extract unique group levels.
            If None, levels are labeled ``"0"``, ``"1"``, etc.

    Returns:
        VaryingState container with grid, effects dict, and group info.
    """
    # Build Lambda and compute BLUPs: b = Lambda @ u
    Lambda = build_lambda_sparse(
        theta,
        re_meta.n_groups_list,
        re_meta.re_structure,
        re_meta.metadata,
    )
    b = Lambda @ u

    # Get random effect names (e.g., ["Intercept", "Days"])
    random_names = re_meta.random_names
    if not random_names:
        random_names = ["Intercept"]

    # Compute per-factor RE counts and names
    per_factor_n_re, per_factor_names = _compute_per_factor_layout(
        re_meta, random_names
    )

    # Build effects dictionary and grid
    effects: dict[str, list] = {}
    grid_data: dict[str, list] = {Col.GROUP: [], Col.LEVEL: []}

    re_structures_list = re_meta.metadata.get("re_structures_list", None)
    b_offset = 0
    for i, group_name in enumerate(re_meta.grouping_vars):
        n_groups = re_meta.n_groups[group_name]
        n_re_this = per_factor_n_re[i]
        factor_names = per_factor_names[i]

        # Get unique levels for this group from original data
        if data is not None and group_name in data.columns:
            unique_levels = sorted(data[group_name].unique().to_list())
        else:
            unique_levels = [str(j) for j in range(n_groups)]

        # Extract b values for this factor
        group_b = b[b_offset : b_offset + n_groups * n_re_this]

        # Handle layout — diagonal uses blocked layout, others use interleaved
        factor_struct = (
            re_structures_list[i] if re_structures_list else re_meta.re_structure
        )
        if factor_struct == "diagonal":
            group_b_matrix = group_b.reshape(n_re_this, n_groups).T
        else:
            group_b_matrix = group_b.reshape(n_groups, n_re_this)

        # Add to grid
        for level_idx, level in enumerate(unique_levels):
            grid_data[Col.GROUP].append(group_name)
            grid_data[Col.LEVEL].append(str(level))

            # Add effect values
            for re_idx, re_name in enumerate(factor_names):
                if re_name not in effects:
                    effects[re_name] = []
                effects[re_name].append(group_b_matrix[level_idx, re_idx])

        b_offset += n_groups * n_re_this

    # Convert effects lists to arrays
    effects_arrays = {name: np.array(vals) for name, vals in effects.items()}

    # Build grid DataFrame
    grid = pl.DataFrame(grid_data)

    # Compute total number of groups
    total_groups = sum(re_meta.n_groups.values())

    return build_varying_state(
        grid=grid,
        effects=effects_arrays,
        grouping_var=re_meta.grouping_vars[0] if re_meta.grouping_vars else "",
        n_groups=total_groups,
    )


def compute_varying_spread_state(
    theta: NDArray[np.floating],
    sigma: float,
    re_meta: REInfo,
) -> VaryingSpreadState:
    """Compute VaryingSpreadState (variance components) from theta parameters.

    Extracts residual variance (sigma²), random effect variances (tau²),
    correlations (rho), and intraclass correlation (ICC) from the fitted
    theta vector using the random effects structure.

    Args:
        theta: Variance component parameters from the fitted model.
        sigma: Residual standard deviation from the fitted model.
        re_meta: Random effects metadata (grouping vars, structure, etc.).

    Returns:
        VaryingSpreadState container with components DataFrame and
        decomposed variance quantities.
    """
    sigma2 = sigma**2

    # Extract tau² from theta by delegating to theta_to_variance_components,
    # which already handles per-factor structure dispatch correctly.
    tau2: dict[str, float] = {}
    rho: dict[str, float] = {}

    random_names = re_meta.random_names
    if not random_names:
        random_names = ["Intercept"]

    group_names = list(re_meta.grouping_vars)

    # Determine per-factor structures and names
    re_structures_list = re_meta.metadata.get("re_structures_list", None)
    if re_structures_list is not None and len(re_structures_list) == len(group_names):
        re_structure_arg: str | list[str] = re_structures_list
        _, names_arg = per_factor_re_info(re_meta, group_names)
    else:
        re_structure_arg = re_meta.re_structure
        names_arg = random_names

    term_names, term_values = theta_to_variance_components(
        theta, sigma, group_names, names_arg, re_structure_arg
    )

    # Convert SD terms → tau2, correlation terms → rho
    for name, value in zip(term_names, term_values):
        if name == "Residual_sd":
            continue  # sigma2 is computed separately
        if ":corr_" in name:
            # "Group:corr_RE1:RE2" → "RE1_RE2"
            corr_part = name.split(":corr_", 1)[1]
            rho_key = corr_part.replace(":", "_")
            rho[rho_key] = value
        elif name.endswith("_sd"):
            # "Group:RE_sd" → "Group:RE" with variance = sd²
            tau2_key = name.removesuffix("_sd")
            tau2[tau2_key] = value**2

    # Compute ICC (for intercept-only models)
    # ICC = tau² / (tau² + sigma²)
    icc: float | None = None
    total_tau2 = sum(tau2.values())
    if total_tau2 > 0:
        icc = total_tau2 / (total_tau2 + sigma2)

    # Build components DataFrame
    components_data: dict[str, list] = {Col.COMPONENT: [], Col.ESTIMATE: []}

    # Add sigma²
    components_data[Col.COMPONENT].append(Col.SIGMA2)
    components_data[Col.ESTIMATE].append(sigma2)

    # Add tau² for each effect
    for name, value in tau2.items():
        components_data[Col.COMPONENT].append(f"{Col.TAU2_PREFIX}{name}")
        components_data[Col.ESTIMATE].append(value)

    # Add correlations
    for name, value in rho.items():
        components_data[Col.COMPONENT].append(f"{Col.RHO_PREFIX}{name}")
        components_data[Col.ESTIMATE].append(value)

    # Add ICC
    if icc is not None:
        components_data[Col.COMPONENT].append(Col.ICC)
        components_data[Col.ESTIMATE].append(icc)

    components_df = pl.DataFrame(components_data, schema=VaryingSpreadBase)

    return build_varying_spread_state(
        components=components_df,
        sigma2=sigma2,
        tau2=tau2,
        rho=rho,
        icc=icc,
    )


def build_mixed_post_fit_state(
    fit: FitState,
    bundle: DataBundle,
    data: pl.DataFrame,
    *,
    stacklevel: int = 3,
) -> tuple[VaryingState | None, VaryingSpreadState | None]:
    """Compute BLUPs, variance components, and emit convergence warnings.

    Orchestrates the post-fit assembly for mixed-effects models: computes
    VaryingState (BLUPs) and VaryingSpreadState (variance components) from
    the fitted parameters, then checks for convergence issues.

    Args:
        fit: Fitted model state containing theta, u, sigma.
        bundle: Data bundle with RE metadata and valid mask.
        data: Original training data (used for group level labels).
        stacklevel: Warning stacklevel for convergence warnings.
            Default 3 accounts for: user → ``model.fit()`` →
            ``build_mixed_post_fit_state()``.

    Returns:
        A tuple ``(varying_offsets, varying_spread)`` where either may be
        None if the required fitted parameters are missing.
    """
    import warnings

    from bossanova.internal.formula.bundle import (
        filter_valid_rows,
    )  # Deferred: avoid circular import between fit ↔ formula

    # Compute VaryingState (BLUPs)
    varying_offsets: VaryingState | None = None
    if fit.theta is not None and fit.u is not None and bundle.re_metadata is not None:
        valid_data = filter_valid_rows(data, bundle.valid_mask)
        varying_offsets = compute_varying_state(
            theta=fit.theta,
            u=fit.u,
            re_meta=bundle.re_metadata,
            data=valid_data,
        )

    # Compute VaryingSpreadState (variance components)
    varying_spread: VaryingSpreadState | None = None
    if fit.theta is not None and bundle.re_metadata is not None:
        sigma = fit.sigma if fit.sigma is not None else 1.0
        varying_spread = compute_varying_spread_state(
            theta=fit.theta,
            sigma=sigma,
            re_meta=bundle.re_metadata,
        )

    # Emit convergence warnings if any issues detected
    from bossanova.internal.fit.convergence import (
        check_convergence,
    )  # Deferred: loaded at call time to keep module import lightweight
    from bossanova.internal.maths.convergence import format_convergence_warnings

    msgs = check_convergence(fit, bundle.re_metadata)
    if msgs:
        warnings.warn(format_convergence_warnings(msgs), stacklevel=stacklevel)

    return varying_offsets, varying_spread


__all__ = [
    "build_mixed_post_fit_state",
    "compute_varying_spread_state",
    "compute_varying_state",
    "per_factor_re_info",
]
