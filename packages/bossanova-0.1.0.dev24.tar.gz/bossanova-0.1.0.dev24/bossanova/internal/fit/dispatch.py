"""Solver dispatch for model fitting.

Provides fit_model() which dispatches to the appropriate fitter based
on model specification, and resolve_solver() which determines the solver type.

Handles rank-deficient design matrices by reducing X before fitting
and expanding coefficients/vcov after, inserting NaN for dropped columns.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from attrs import evolve

from bossanova.internal.containers import (
    DataBundle,
    FitState,
    ModelSpec,
)

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import RankInfo

__all__ = [
    "VALID_SOLVERS",
    "fit_model",
    "parse_fit_kwargs",
    "resolve_solver",
    "validate_fit_method",
]

# Valid solver names for .fit(solver=...)
VALID_SOLVERS: frozenset[str] = frozenset({"qr", "irls", "pls", "pirls"})


def resolve_solver(spec: ModelSpec) -> str:
    """Select the appropriate solver for a model configuration.

    Args:
        spec: Model specification.

    Returns:
        Solver name: "qr", "irls", "pls", or "pirls".
    """
    if not spec.has_random_effects:
        return "qr" if spec.method == "ols" else "irls"
    return "pls" if spec.family == "gaussian" else "pirls"


def reduce_bundle(bundle: DataBundle, rank_info: RankInfo) -> DataBundle:
    """Reduce bundle to only kept (estimable) columns.

    Args:
        bundle: Original data bundle with rank-deficient X.
        rank_info: Rank deficiency information.

    Returns:
        New DataBundle with X reduced to kept columns, rank_info=None.
    """
    kept = rank_info.kept_indices
    return evolve(
        bundle,
        X=bundle.X[:, kept],
        X_names=tuple(bundle.X_names[i] for i in kept),
        rank_info=None,  # Reduced bundle is full rank
    )


def expand_fit_state(fit: FitState, rank_info: RankInfo) -> FitState:
    """Expand fit state from reduced to full column space.

    Inserts NaN for dropped columns in coef and vcov.
    Fitted values, residuals, and leverage are n-dimensional
    and pass through unchanged.

    Args:
        fit: FitState from fitting reduced model.
        rank_info: Original rank deficiency information.

    Returns:
        FitState with full-size coef/vcov (NaN for dropped columns).
    """
    p = rank_info.p
    kept = rank_info.kept_indices

    # Expand coef: full-size with NaN for dropped
    coef_full = np.full(p, np.nan)
    coef_full[kept] = np.asarray(fit.coef)

    # Expand vcov: full-size with NaN for dropped
    vcov_full = np.full((p, p), np.nan)
    vcov_full[np.ix_(kept, kept)] = np.asarray(fit.vcov)

    return evolve(
        fit,
        coef=coef_full,
        vcov=vcov_full,
    )


def dispatch_solver(
    solver: str,
    spec: ModelSpec,
    bundle: DataBundle,
    *,
    max_iter: int | None = None,
    max_outer_iter: int = 10000,
    tol: float | None = None,
    verbose: bool = False,
    nAGQ: int = 1,
    use_hessian: bool = False,
) -> FitState:
    """Dispatch to the concrete solver implementation.

    Accepts the union of all solver params and forwards the relevant
    subset to each backend.

    Args:
        solver: Solver name (``"qr"``, ``"irls"``, ``"pls"``, ``"pirls"``).
        spec: Model specification.
        bundle: Prepared data bundle.
        max_iter: Maximum iterations (solver-specific defaults if None).
        max_outer_iter: Maximum outer (BOBYQA) iterations for GLMER (default: 10000).
        tol: Convergence tolerance (solver-specific defaults if None).
        verbose: Print optimization progress (default: False).
        nAGQ: Quadrature points for GLMER (default: 1).
        use_hessian: Use Hessian-based vcov for GLMER (default: False).

    Returns:
        FitState from the selected solver.
    """
    from bossanova.internal.fit.glm import fit_glm_irls
    from bossanova.internal.fit.glmer import fit_glmer_pirls
    from bossanova.internal.fit.lmer import fit_lmer_pls
    from bossanova.internal.fit.ols import fit_ols_qr

    match solver:
        case "qr":
            return fit_ols_qr(spec, bundle)
        case "irls":
            return fit_glm_irls(
                spec,
                bundle,
                max_iter=max_iter if max_iter is not None else 25,
                tol=tol if tol is not None else 1e-8,
            )
        case "pls":
            return fit_lmer_pls(
                spec,
                bundle,
                max_iter=max_iter if max_iter is not None else 10000,
                verbose=verbose,
            )
        case "pirls":
            return fit_glmer_pirls(
                spec,
                bundle,
                max_iter=max_iter if max_iter is not None else 25,
                max_outer_iter=max_outer_iter,
                tol=tol if tol is not None else 1e-7,
                verbose=verbose,
                nAGQ=nAGQ,
                use_hessian=use_hessian,
            )
        case _:
            raise ValueError(f"Unknown solver: {solver}")


def fit_model(
    spec: ModelSpec,
    bundle: DataBundle,
    *,
    solver: str | None = None,
    max_iter: int | None = None,
    max_outer_iter: int = 10000,
    tol: float | None = None,
    verbose: bool = False,
    nAGQ: int = 1,
    use_hessian: bool = False,
) -> FitState:
    """Dispatch to appropriate fitter based on model specification.

    This is the main entry point for fitting models. It examines the ModelSpec
    to determine the appropriate solver and delegates to the corresponding
    fitter function.

    If the design matrix is rank-deficient (detected during bundle construction),
    the X matrix is reduced to estimable columns before fitting. After fitting,
    coefficients and vcov are expanded back to full size with NaN for dropped
    columns (matching R's lm() behavior).

    The solver selection follows the estimation method matrix:

    | Family     | Random Effects | Method  | Solver | Description              |
    |------------|----------------|---------|--------|--------------------------|
    | gaussian   | No             | ols     | qr     | QR decomposition         |
    | gaussian   | No             | ml      | irls   | Maximum likelihood       |
    | non-gauss  | No             | ml      | irls   | GLM via IRLS             |
    | gaussian   | Yes            | reml/ml | pls    | Penalized least squares  |
    | non-gauss  | Yes            | ml      | pirls  | Penalized IRLS           |

    Args:
        spec: Model specification containing formula, family, link, method,
            and parsed formula components.
        bundle: Prepared data bundle containing design matrices (X, y, Z),
            column names, valid observation mask, and optional weights/offset.
        solver: Override solver selection. If None, auto-selected via
            ``resolve_solver()``. Must be one of ``"qr"``, ``"irls"``,
            ``"pls"``, ``"pirls"``.
        max_iter: Maximum iterations (solver-specific defaults if None).
        max_outer_iter: Maximum outer (BOBYQA) iterations for GLMER (default: 10000).
        tol: Convergence tolerance (solver-specific defaults if None).
        verbose: Print optimization progress (default: False).
        nAGQ: Quadrature points for GLMER (default: 1).
        use_hessian: Use Hessian-based vcov for GLMER (default: False).

    Returns:
        FitState containing all fitting results.

    Raises:
        ValueError: If solver type is unknown or if the system is
            underdetermined (n < p after rank reduction).

    Examples:
        >>> import numpy as np
        >>> from bossanova.internal.containers import build_model_spec, DataBundle
        >>> spec = build_model_spec(
        ...     formula="y ~ x",
        ...     response_var="y",
        ...     fixed_terms=["Intercept", "x"],
        ... )
        >>> bundle = DataBundle(
        ...     X=np.array([[1.0, 1.0], [1.0, 2.0], [1.0, 3.0]]),
        ...     y=np.array([2.0, 4.0, 6.0]),
        ...     X_names=["Intercept", "x"],
        ...     y_name="y",
        ...     valid_mask=np.array([True, True, True]),
        ...     n_total=3,
        ... )
        >>> state = fit_model(spec, bundle)
        >>> state.converged
        True
        >>> state.coef  # [Intercept, x] = [0, 2]
        array([0., 2.])
    """
    resolved_solver = solver if solver is not None else resolve_solver(spec)
    rank_info = bundle.rank_info

    # Reject underdetermined systems (n < p) for fixed-effects models.
    # We check against the original column count, not the rank-reduced
    # count: if the user specified more parameters than observations the
    # design is ill-posed and should be rejected up front, even when rank
    # reduction could technically produce a solution (with df_resid = 0).
    if not spec.has_random_effects and bundle.n < bundle.p:
        raise ValueError(
            f"Underdetermined system: n={bundle.n} observations < "
            f"p={bundle.p} parameters. The model cannot be estimated. "
            f"Add more observations or remove predictors."
        )

    solver_kwargs = dict(
        max_iter=max_iter,
        max_outer_iter=max_outer_iter,
        tol=tol,
        verbose=verbose,
        nAGQ=nAGQ,
        use_hessian=use_hessian,
    )

    if rank_info is not None and rank_info.is_deficient:
        reduced = reduce_bundle(bundle, rank_info)
        fit = dispatch_solver(resolved_solver, spec, reduced, **solver_kwargs)
        return expand_fit_state(fit, rank_info)

    return dispatch_solver(resolved_solver, spec, bundle, **solver_kwargs)


def validate_fit_method(spec: ModelSpec, method_str: str) -> ModelSpec:
    """Validate and apply a user-specified fitting method to a ModelSpec.

    Checks that the method is compatible with the model's family and
    random-effects structure, then returns an evolved spec with the new method.

    Args:
        spec: Current model specification.
        method_str: User-supplied method string (e.g. ``"ols"``, ``"ml"``,
            ``"reml"``). Will be lowercased.

    Returns:
        Evolved ModelSpec with the validated method applied.

    Raises:
        ValueError: If the method is incompatible with the model configuration.
    """
    method_val = method_str.lower()
    is_gaussian = spec.family == "gaussian"
    if method_val == "ols" and (not is_gaussian or spec.has_random_effects):
        raise ValueError("method='ols' only valid for gaussian without RE")
    if method_val == "reml" and not (is_gaussian and spec.has_random_effects):
        raise ValueError("method='reml' only valid for gaussian with RE")
    return evolve(spec, method=method_val)


def parse_fit_kwargs(
    spec: ModelSpec,
    kwargs: dict[str, object],
    nAGQ: int | None,
) -> tuple[ModelSpec, str | None, dict[str, object]]:
    """Validate and extract fitting parameters from ``**kwargs``.

    Pops ``solver``, ``method``, and ``nAGQ`` from *kwargs*, validates each,
    and assembles the remaining fit-specific keyword arguments into a dict
    suitable for ``fit_model()``.

    Args:
        spec: Current model specification (may be evolved if ``method`` is set).
        kwargs: Mutable dict of user-supplied keyword arguments. Recognized keys
            are popped: ``solver``, ``method``, ``max_iter``, ``max_outer_iter``,
            ``tol``, ``verbose``, ``nAGQ``, ``use_hessian``.
        nAGQ: Explicit ``nAGQ`` parameter from the ``fit()`` signature (takes
            precedence over any value in *kwargs*).

    Returns:
        A tuple ``(updated_spec, solver_override, fit_kwargs)`` where:
        - *updated_spec* has the validated method applied (if ``method`` was set).
        - *solver_override* is the validated solver string, or None.
        - *fit_kwargs* is a dict ready to splat into ``fit_model()``.

    Raises:
        ValueError: If solver name is unknown, method is incompatible, or
            nAGQ is negative / non-integer.
    """
    # Validate and extract solver kwarg if provided
    solver_override: str | None = None
    if "solver" in kwargs:
        solver_val = str(kwargs.pop("solver"))
        if solver_val not in VALID_SOLVERS:
            raise ValueError(
                f"Unknown solver: {solver_val!r}. "
                f"Valid solvers are: {sorted(VALID_SOLVERS)}"
            )
        solver_override = solver_val

    # Update spec for spec-level kwargs (method) before solver dispatch
    if "method" in kwargs:
        spec = validate_fit_method(spec, str(kwargs.pop("method")))

    # Validate and forward nAGQ for GLMM
    if nAGQ is not None:
        if not isinstance(nAGQ, int) or nAGQ < 0:
            raise ValueError(f"nAGQ must be a non-negative integer, got {nAGQ}")
        kwargs["nAGQ"] = nAGQ

    # Extract fit-specific kwargs with defaults
    fit_kwargs: dict[str, object] = {
        "max_iter": kwargs.pop("max_iter", None),
        "max_outer_iter": int(kwargs.pop("max_outer_iter", 10000)),
        "tol": kwargs.pop("tol", None),
        "verbose": bool(kwargs.pop("verbose", False)),
        "nAGQ": int(kwargs.pop("nAGQ", 1)),
        "use_hessian": bool(kwargs.pop("use_hessian", False)),
    }
    if fit_kwargs["max_iter"] is not None:
        fit_kwargs["max_iter"] = int(fit_kwargs["max_iter"])  # type: ignore[arg-type]
    if fit_kwargs["tol"] is not None:
        fit_kwargs["tol"] = float(fit_kwargs["tol"])  # type: ignore[arg-type]

    return spec, solver_override, fit_kwargs
