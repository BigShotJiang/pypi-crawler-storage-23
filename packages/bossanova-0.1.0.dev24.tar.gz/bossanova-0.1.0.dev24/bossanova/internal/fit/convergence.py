"""Convergence diagnostics for fitted mixed-effects models.

Encapsulates the repeated pattern of extracting theta, computing bounds,
assembling per-factor RE info, and running diagnose_convergence().
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from bossanova.internal.maths.convergence import (
    ConvergenceMessage,
    diagnose_convergence,
)
from bossanova.internal.maths.solvers.heuristics import get_theta_lower_bounds
from bossanova.internal.fit.varying import per_factor_re_info

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import REInfo
    from bossanova.internal.containers.structs.state import FitState

__all__ = [
    "check_convergence",
]


def check_convergence(
    fit: FitState,
    re_meta: REInfo,
) -> list[ConvergenceMessage]:
    """Run convergence diagnostics on a fitted mixed model.

    Extracts theta and sigma from FitState, computes theta lower bounds
    and per-factor RE info from REInfo, and delegates to
    ``diagnose_convergence()`` for the actual diagnostic checks.

    Args:
        fit: Fitted model state (must have theta, sigma, converged).
        re_meta: Random effects metadata from the DataBundle.

    Returns:
        List of ConvergenceMessage objects. Empty if theta is None.
    """
    theta = fit.theta
    if theta is None:
        return []

    group_names = list(re_meta.grouping_vars)
    theta_lower = get_theta_lower_bounds(
        len(theta), re_meta.re_structure, re_meta.metadata
    )
    conv_re_structure, conv_random_names = per_factor_re_info(re_meta, group_names)

    return diagnose_convergence(
        theta=theta,
        theta_lower=theta_lower,
        group_names=group_names,
        random_names=conv_random_names,
        re_structure=conv_re_structure,
        sigma=fit.sigma or 1.0,
        converged=fit.converged,
        boundary_adjusted=False,
        restarted=False,
    )
