"""Marginal effects dispatch and routing.

Routes parsed explore formulas to the appropriate computation: EMMs for
categorical focal variables, slopes for continuous, or contrasts.
Supports ``effect_scale=`` (link/response scale), ``how=`` (mem/ame),
and ``varying=`` (marginal/conditional).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import polars as pl

from bossanova.internal.containers.builders.state import build_mee_state
from bossanova.internal.design.reference import (
    _build_continuous_reference_row,
    build_continuous_reference_matrix,
)
from bossanova.internal.marginal.conditions import (
    ResolvedConditions,
)
from bossanova.internal.marginal.bracket_contrasts import dispatch_bracket_contrasts
from bossanova.internal.marginal.contrasts import dispatch_contrasts
from bossanova.internal.marginal.emm import (
    compute_conditional_emm,
    compute_emm,
    compute_emm_crossed,
)
from bossanova.internal.marginal.resolve import (
    resolve_all_conditions,
    resolve_conditional,
    resolve_focal_at_spec,
    resolve_focal_at_values,
    resolve_focal_var,
)
from bossanova.internal.marginal.slopes import (
    _has_focal_interaction,
    compute_conditional_slopes,
    compute_slopes,
    compute_slopes_crossed,
    compute_slopes_finite_diff,
)
from bossanova.internal.marginal.validation import validate_focal_var

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import DataBundle
    from bossanova.internal.containers.structs.explore import (
        ExploreFormulaSpec,
    )
    from bossanova.internal.containers.structs.formula import FormulaSpec
    from bossanova.internal.containers.structs.specs import ModelSpec
    from bossanova.internal.containers.structs.state import (
        FitState,
        MeeState,
        VaryingState,
    )


__all__ = [
    "compute_emm_categorical",
    "dispatch_marginal_computation",
]


def dispatch_marginal_computation(
    parsed: ExploreFormulaSpec,
    bundle: DataBundle,
    fit: FitState,
    data: pl.DataFrame,
    *,
    spec: ModelSpec | None = None,
    formula_spec: object | None = None,
    varying_offsets: VaryingState | None = None,
    effect_scale: str = "link",
    varying: str = "exclude",
    how: str = "auto",
    inverse_transforms: bool = True,
    by: str | None = None,
) -> MeeState:
    """Route a parsed explore formula to the appropriate marginal computation.

    Validates the focal variable, determines whether it is categorical or
    continuous, and dispatches to the correct computation function.

    Supports ``effect_scale=`` and ``varying=`` for scale transforms and
    conditional (group-specific) effects in mixed models.  When RHS conditions
    contain bracket contrasts (e.g., ``Drug[A - B] ~ Dose[High - Low]``),
    applies them as a post-processing step after the main computation.

    Args:
        parsed: Parsed explore formula with focal variable and contrast info.
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        data: The model's data DataFrame (for variable lookup and type detection).
        spec: ModelSpec with link/family info (needed for effect_scale="response").
        formula_spec: FormulaSpec with learned encoding (needed for finite-diff slopes).
        varying_offsets: VaryingState with BLUPs (needed for conditional effects).
        effect_scale: ``"link"`` (default) or ``"response"`` (inverse-link / data scale).
        varying: ``"exclude"`` (default) or ``"include"`` (conditional effects).
        how: ``"auto"`` (default), ``"mem"`` (emmeans-style), or
            ``"ame"`` (g-computation / average marginal effect).
        inverse_transforms: When ``True`` (default), raw variable names and values
            are auto-resolved through learned formula transforms. Set to ``False``
            to use transformed-scale names/values directly.
        by: Grouping variable for faceted effects (default: None).

    Returns:
        MeeState with computed marginal effects.

    Raises:
        ValueError: If the focal variable is not found in data, is the response
            variable, or a ``by=`` variable is invalid.
    """
    result = _dispatch_marginal_core(
        parsed,
        bundle,
        fit,
        data,
        spec=spec,
        formula_spec=formula_spec,
        varying_offsets=varying_offsets,
        effect_scale=effect_scale,
        varying=varying,
        how=how,
        inverse_transforms=inverse_transforms,
        by=by,
    )

    # Post-process: apply RHS bracket contrasts
    if parsed.has_rhs_contrasts:
        from bossanova.internal.marginal.bracket_contrasts import (
            apply_rhs_bracket_contrast,
        )

        for cond in parsed.conditions:
            if cond.contrast_expr is not None:
                result = apply_rhs_bracket_contrast(result, cond.contrast_expr)

    return result


def _dispatch_marginal_core(
    parsed: ExploreFormulaSpec,
    bundle: DataBundle,
    fit: FitState,
    data: pl.DataFrame,
    *,
    spec: ModelSpec | None = None,
    formula_spec: object | None = None,
    varying_offsets: VaryingState | None = None,
    effect_scale: str = "link",
    varying: str = "exclude",
    how: str = "auto",
    inverse_transforms: bool = True,
    by: str | None = None,
) -> MeeState:
    """Core dispatch logic for marginal computation.

    Called by :func:`dispatch_marginal_computation`.  See that function
    for full documentation.

    Args:
        parsed: Parsed explore formula.
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        data: The model's data DataFrame.
        spec: ModelSpec with link/family info.
        formula_spec: FormulaSpec with learned encoding.
        varying_offsets: VaryingState with BLUPs.
        effect_scale: ``"link"`` or ``"response"``.
        varying: ``"exclude"`` or ``"include"``.
        how: ``"auto"``, ``"mem"``, or ``"ame"``.
        inverse_transforms: Whether to apply forward transforms.
        by: Grouping variable for faceted effects.

    Returns:
        MeeState with computed marginal effects (before RHS contrast
        post-processing).
    """
    focal_var = parsed.focal_var

    # Compound focal variable: Drug:Dose[Active:High - Placebo:Low]
    if ":" in focal_var and parsed.has_contrast_expr:
        from bossanova.internal.marginal.bracket_contrasts import (
            compute_compound_bracket_contrasts,
        )

        resolved = resolve_all_conditions(parsed, bundle, data, None, True)
        return compute_compound_bracket_contrasts(
            bundle,
            fit,
            focal_var,
            parsed.contrast_expr,
            data=data,
            spec=spec,
            effect_scale=effect_scale,
            resolved=resolved,
        )

    # Validate inputs and resolve how=auto
    how = _validate_dispatch_inputs(
        focal_var, data, bundle, formula_spec, effect_scale, varying, how, spec, by
    )

    fspec: FormulaSpec | None = formula_spec  # type: ignore[assignment]

    is_conditional, grouping_var = resolve_conditional(
        parsed, bundle, varying, varying_offsets
    )

    resolved = resolve_all_conditions(parsed, bundle, data, fspec, inverse_transforms)

    # Validate: focal variable must not also appear as a condition variable
    _all_condition_vars = (
        set(resolved.at_overrides)
        | set(resolved.set_categoricals)
        | set(resolved.grid_categoricals)
        | set(resolved.grid_numerics)
    )
    if focal_var in _all_condition_vars:
        msg = (
            f"Cannot condition on the focal variable itself. "
            f"'{focal_var} ~ {focal_var}' is not meaningful — "
            f"use '{focal_var}' or '{focal_var} ~ other_variable'."
        )
        raise ValueError(msg)

    resolved_focal = resolve_focal_var(
        focal_var, list(bundle.X_names), fspec, inverse_transforms
    )

    parsed = resolve_focal_at_spec(parsed, data, bundle)

    at_overrides: dict[str, float] | None = (
        resolved.at_overrides if resolved.at_overrides else None
    )

    # Detect categorical vs continuous using factor_levels as ground truth.
    # This must happen before at-value/contrast routing so that at-values
    # on categorical variables (e.g. "cyl@[4, 8]") route correctly.
    is_categorical = (
        bundle.factor_levels is not None and focal_var in bundle.factor_levels
    )
    if not is_categorical:
        col = data[focal_var]
        is_categorical = col.dtype == pl.Utf8

    # Bracket contrast expressions: Drug[A - B], Drug[* - Placebo], etc.
    if parsed.has_contrast_expr:
        return dispatch_bracket_contrasts(
            bundle,
            fit,
            focal_var,
            parsed.contrast_expr,
            data=data,
            spec=spec,
            effect_scale=effect_scale,
            how=how,
            resolved=resolved,
        )

    # Named contrast functions (pairwise, sequential, etc.)
    if parsed.has_contrast:
        if not is_categorical:
            msg = (
                f"Contrast functions like {parsed.contrast_type}() require "
                f"a categorical variable. '{focal_var}' is continuous. "
                f"For slopes, use '{focal_var}' or "
                f"'{focal_var} ~ condition'."
            )
            raise ValueError(msg)
        return dispatch_contrasts(
            bundle,
            fit,
            focal_var,
            parsed.contrast_type,
            parsed.contrast_degree,
            data,
            spec=spec,
            effect_scale=effect_scale,
            how=how,
            resolved=resolved,
            focal_at_values=parsed.focal_at_values,
            contrast_ref=parsed.contrast_ref,
            level_ordering=parsed.contrast_level_ordering,
        )

    # Route by variable type
    if is_categorical:
        return _dispatch_categorical(
            parsed,
            bundle,
            fit,
            focal_var,
            resolved,
            at_overrides=at_overrides,
            is_conditional=is_conditional,
            grouping_var=grouping_var,
            varying_offsets=varying_offsets,
            spec=spec,
            effect_scale=effect_scale,
            how=how,
        )

    return _dispatch_continuous(
        parsed,
        bundle,
        fit,
        focal_var,
        resolved_focal,
        resolved,
        data=data,
        formula_spec=fspec,
        is_conditional=is_conditional,
        grouping_var=grouping_var,
        varying_offsets=varying_offsets,
        spec=spec,
        effect_scale=effect_scale,
        how=how,
        inverse_transforms=inverse_transforms,
    )


def _validate_dispatch_inputs(
    focal_var: str,
    data: pl.DataFrame,
    bundle: DataBundle,
    formula_spec: object | None,
    effect_scale: str,
    varying: str,
    how: str,
    spec: ModelSpec | None,
    by: str | None,
) -> str:
    """Validate dispatch inputs and resolve ``how='auto'``.

    Args:
        focal_var: Name of the focal variable.
        data: The model's data DataFrame.
        bundle: DataBundle with model data and metadata.
        formula_spec: FormulaSpec with learned encoding.
        effect_scale: ``"link"`` or ``"response"``.
        varying: ``"exclude"`` or ``"include"``.
        how: ``"auto"``, ``"mem"``, or ``"ame"``.
        spec: ModelSpec with link/family info.
        by: Grouping variable for faceted effects.

    Returns:
        Resolved ``how`` value (``"mem"`` or ``"ame"``).

    Raises:
        ValueError: If any input is invalid.
    """
    if focal_var not in data.columns:
        raise ValueError(f"Variable '{focal_var}' not found in data")

    validate_focal_var(bundle, focal_var)

    # Validate focal variable is a model predictor
    _focal_model_vars: set[str] = set()
    if bundle.factor_levels is not None:
        _focal_model_vars.update(bundle.factor_levels.keys())
    _focal_model_vars.update(bundle.X_names)
    if formula_spec is not None:
        for _key, _state in formula_spec.transform_state.items():  # type: ignore[union-attr]
            _raw = _state.get("variable", "")
            if _raw:
                _focal_model_vars.add(_raw)
    if focal_var not in _focal_model_vars:
        msg = (
            f"Variable '{focal_var}' is not a predictor in the model "
            f"formula. Only model predictors can be explored."
        )
        raise ValueError(msg)

    if effect_scale not in ("link", "response"):
        raise ValueError(
            f"effect_scale must be 'link' or 'response', got {effect_scale!r}"
        )

    if varying not in ("exclude", "include"):
        raise ValueError(f"varying must be 'exclude' or 'include', got {varying!r}")

    if how not in ("auto", "mem", "ame"):
        raise ValueError(f"how must be 'auto', 'mem', or 'ame', got {how!r}")
    if how == "auto":
        how = "ame" if spec is not None and spec.link != "identity" else "mem"

    if by is not None:
        by_vars: list[str] = (
            [by] if isinstance(by, str) else list(by)  # type: ignore[arg-type]
        )
        data_cols = set(data.columns)
        for bv in by_vars:
            if bv not in data_cols:
                raise ValueError(
                    f"by= variable '{bv}' not found in data. "
                    f"Available columns: {sorted(data_cols)}"
                )

    return how


def _dispatch_categorical(
    parsed: ExploreFormulaSpec,
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    resolved: ResolvedConditions,
    *,
    at_overrides: dict[str, float] | None,
    is_conditional: bool,
    grouping_var: str | None,
    varying_offsets: VaryingState | None,
    spec: ModelSpec | None,
    effect_scale: str,
    how: str,
) -> MeeState:
    """Route categorical focal variable to the appropriate EMM computation.

    Handles at-value filtering, grid crossing, and conditional (group-specific)
    effects for categorical variables.

    Args:
        parsed: Parsed explore formula.
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical variable.
        resolved: Resolved conditions with grid, at_overrides, and/or
            set_categoricals.
        at_overrides: Scalar numeric pin overrides (or None).
        is_conditional: Whether group-specific (conditional) effects are requested.
        grouping_var: Random effects grouping variable (or None).
        varying_offsets: VaryingState with BLUPs (or None).
        spec: ModelSpec with link/family info.
        effect_scale: ``"link"`` or ``"response"``.
        how: ``"mem"`` or ``"ame"``.

    Returns:
        MeeState with computed categorical marginal effects.
    """
    if parsed.focal_at_values is not None:
        # Categorical at-values (e.g. "cyl@[4, 8]"): filter to
        # requested levels and compute EMMs for that subset.
        requested_levels = [
            str(int(v)) if isinstance(v, float) and v == int(v) else str(v)
            for v in parsed.focal_at_values
        ]

        # Validate requested levels exist in the factor
        if bundle.factor_levels is not None and focal_var in bundle.factor_levels:
            known_levels = set(bundle.factor_levels[focal_var])
            unknown = [lv for lv in requested_levels if lv not in known_levels]
            if unknown:
                available = sorted(known_levels)
                s = "s" if len(unknown) > 1 else ""
                msg = (
                    f"Level{s} {unknown} not found in variable "
                    f"'{focal_var}'. Available levels: {available}"
                )
                raise ValueError(msg)

        if resolved.has_grid:
            return compute_emm_crossed(
                bundle,
                fit,
                focal_var,
                resolved=resolved,
                levels=requested_levels,
                spec=spec,
                effect_scale=effect_scale,
                how=how,
            )

        return compute_emm_categorical(
            bundle,
            fit,
            focal_var,
            levels=requested_levels,
            at_overrides=at_overrides,
            set_categoricals=resolved.set_categoricals or None,
            spec=spec,
            effect_scale=effect_scale,
            how=how,
        )

    # Grid expansion: crossed EMMs over condition levels
    if resolved.has_grid:
        return compute_emm_crossed(
            bundle,
            fit,
            focal_var,
            resolved=resolved,
            spec=spec,
            effect_scale=effect_scale,
            how=how,
        )

    if is_conditional and grouping_var is not None and varying_offsets is not None:
        return compute_conditional_emm(
            bundle=bundle,
            fit=fit,
            focal_var=focal_var,
            explore_formula=parsed.focal_var,
            spec=spec,
            varying_offsets=varying_offsets,
            grouping_var=grouping_var,
            effect_scale=effect_scale,
            at_overrides=at_overrides,
            set_categoricals=resolved.set_categoricals or None,
        )

    return compute_emm_categorical(
        bundle,
        fit,
        focal_var,
        at_overrides=at_overrides,
        set_categoricals=resolved.set_categoricals or None,
        spec=spec,
        effect_scale=effect_scale,
        how=how,
    )


def _dispatch_continuous(
    parsed: ExploreFormulaSpec,
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    resolved_focal: str,
    resolved: ResolvedConditions,
    *,
    data: pl.DataFrame,
    formula_spec: FormulaSpec | None,
    is_conditional: bool,
    grouping_var: str | None,
    varying_offsets: VaryingState | None,
    spec: ModelSpec | None,
    effect_scale: str,
    how: str,
    inverse_transforms: bool,
) -> MeeState:
    """Route continuous focal variable to slope or at-value EMM computation.

    Handles at-value EMMs, conditional slopes, crossed slopes, and marginal
    slopes for continuous variables.

    Args:
        parsed: Parsed explore formula.
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Raw name of the continuous variable.
        resolved_focal: Transformed design-matrix name (e.g. ``"center(x)"``).
        resolved: Resolved conditions.
        data: The model's data DataFrame.
        formula_spec: FormulaSpec with learned encoding.
        is_conditional: Whether group-specific effects are requested.
        grouping_var: Random effects grouping variable (or None).
        varying_offsets: VaryingState with BLUPs (or None).
        spec: ModelSpec with link/family info.
        effect_scale: ``"link"`` or ``"response"``.
        how: ``"mem"`` or ``"ame"``.
        inverse_transforms: Whether to apply forward transforms.

    Returns:
        MeeState with computed continuous marginal effects.
    """
    if parsed.focal_at_values is not None:
        # Continuous at-values (e.g. "Days@[0, 3, 6, 9]"): EMMs at
        # specific values.  Forward-transform the at-values through the
        # formula transform so that raw-scale values (e.g. Days=0) become
        # transformed-scale values (e.g. center(Days) = 0 - mean(Days)).
        resolved_at = resolve_focal_at_values(
            focal_var, parsed.focal_at_values, formula_spec, inverse_transforms
        )
        needs_display = resolved_focal != focal_var

        if resolved.has_grid:
            return _compute_emm_at_values_crossed(
                bundle,
                fit,
                resolved_focal,
                resolved_at,
                resolved,
                display_var=focal_var if needs_display else None,
                display_values=parsed.focal_at_values if needs_display else None,
                spec=spec,
                effect_scale=effect_scale,
                how=how,
            )

        return _compute_emm_at_values(
            bundle,
            fit,
            resolved_focal,
            resolved_at,
            display_var=focal_var if needs_display else None,
            display_values=parsed.focal_at_values if needs_display else None,
            at_overrides=resolved.at_overrides or None,
            set_categoricals=resolved.set_categoricals or None,
            spec=spec,
            effect_scale=effect_scale,
            how=how,
        )

    # Continuous focal variable → slopes
    if is_conditional and grouping_var is not None and varying_offsets is not None:
        return compute_conditional_slopes(
            bundle=bundle,
            fit=fit,
            focal_var=resolved_focal,
            explore_formula=focal_var,
            spec=spec,
            varying_offsets=varying_offsets,
            grouping_var=grouping_var,
            effect_scale=effect_scale,
        )

    # Crossed / conditioned slopes: conditions on RHS
    if resolved.has_grid or resolved.set_categoricals or resolved.at_overrides:
        # Slopes path operates on a raw-data grid where column names are raw
        # (e.g. "x2"), not design-matrix names (e.g. "scale(x2)").  Swap in
        # the pre-transform overrides so keys match data grid columns;
        # evaluate_newdata will apply formula transforms during design matrix
        # construction.
        slopes_resolved = resolved
        if resolved.raw_at_overrides:
            import attrs

            slopes_resolved = attrs.evolve(
                resolved, at_overrides=resolved.raw_at_overrides
            )
        return compute_slopes_crossed(
            bundle,
            fit,
            focal_var,
            resolved=slopes_resolved,
            data=data,
            spec=spec,
            formula_spec=formula_spec,
            effect_scale=effect_scale,
        )

    return _compute_marginal_slope(
        bundle,
        fit,
        focal_var,
        resolved_focal_var=resolved_focal,
        data=data,
        spec=spec,
        formula_spec=formula_spec,
        effect_scale=effect_scale,
        how=how,
    )


def compute_emm_categorical(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    *,
    levels: list[str] | None = None,
    at_overrides: dict[str, float] | None = None,
    set_categoricals: dict[str, str] | None = None,
    spec: ModelSpec | None = None,
    effect_scale: str = "link",
    how: str = "mem",
) -> MeeState:
    """Compute EMMs for a categorical focal variable.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical variable.
        levels: Optional subset of levels to compute EMMs for (e.g. from
            ``cyl@[4, 8]`` syntax).  If None, all levels are used.
        at_overrides: Optional covariate overrides for conditioning.
        set_categoricals: Optional dict pinning non-focal categoricals to
            specific levels (e.g. ``{"Ethnicity": "Asian"}``).
        spec: ModelSpec with link info (for effect_scale="response").
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.
        how: Averaging method: ``"mem"`` or ``"ame"``.

    Returns:
        MeeState with grid of levels and their estimated means.
    """
    return compute_emm(
        bundle=bundle,
        fit=fit,
        focal_var=focal_var,
        explore_formula=focal_var,
        levels=levels,
        at_overrides=at_overrides,
        set_categoricals=set_categoricals,
        spec=spec,
        effect_scale=effect_scale,
        how=how,
    )


def _compute_emm_at_values(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    at_values: tuple[float, ...],
    *,
    display_var: str | None = None,
    display_values: tuple[float, ...] | None = None,
    at_overrides: dict[str, float] | None = None,
    set_categoricals: dict[str, str] | None = None,
    spec: ModelSpec | None = None,
    effect_scale: str = "link",
    how: str = "mem",
) -> MeeState:
    """Compute EMMs at specific values of a continuous focal variable.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the continuous focal variable (design-matrix name,
            e.g. ``"center(Days)"``).
        at_values: Specific values to evaluate at (on the design-matrix scale).
        display_var: Optional raw variable name for user-facing grid/metadata.
            Defaults to ``focal_var`` when not provided.
        display_values: Optional raw-scale at-values for user-facing grid.
            Defaults to ``at_values`` when not provided.
        at_overrides: Optional numeric covariate overrides from RHS conditions
            (e.g. ``{"z": 5.0}``).  Applied to ``X_means`` before building the
            reference matrix so that conditioned covariates are pinned rather
            than marginalized at their means.
        set_categoricals: Optional dict pinning non-focal categoricals to
            specific levels (e.g. ``{"Ethnicity": "Asian"}``).
        spec: ModelSpec with link/family info (for ``effect_scale="response"``).
        effect_scale: ``"link"`` (default) or ``"response"``.
        how: ``"mem"`` or ``"ame"``.

    Returns:
        MeeState with EMM estimates at each specified value.
    """
    if display_var is None:
        display_var = focal_var
    if display_values is None:
        display_values = at_values

    X_means = bundle.X.mean(axis=0).copy()
    X_names_list = list(bundle.X_names)

    # Apply numeric overrides to X_means
    if at_overrides:
        for var_name, value in at_overrides.items():
            if var_name in X_names_list:
                X_means[X_names_list.index(var_name)] = value

    X_ref = build_continuous_reference_matrix(
        X_names=bundle.X_names,
        focal_var=focal_var,
        at_values=at_values,
        X_means=X_means,
        set_categoricals=set_categoricals,
    )

    estimates_link = X_ref @ fit.coef
    L_matrix: np.ndarray = X_ref
    link_name: str | None = None
    L_matrix_link: np.ndarray | None = None

    if effect_scale == "response" and spec is not None and spec.link != "identity":
        from bossanova.internal.maths.family.links import (
            apply_link_inverse,
            apply_link_inverse_deriv,
        )

        estimates = np.asarray(apply_link_inverse(spec.link, estimates_link))
        d = np.asarray(apply_link_inverse_deriv(spec.link, estimates_link))
        L_matrix = d[:, np.newaxis] * X_ref
        link_name = spec.link
        L_matrix_link = X_ref
    else:
        estimates = estimates_link

    # Build grid DataFrame with the raw (user-facing) variable name and values
    grid = pl.DataFrame({display_var: list(display_values)})

    # Build explore formula string for metadata using raw name
    vals_str = ", ".join(str(v) for v in display_values)
    explore_formula = f"{display_var}@[{vals_str}]"

    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=explore_formula,
        focal_var=display_var,
        mee_type="means",
        L_matrix=L_matrix,
        how=how,
        effect_scale=effect_scale,
        link=link_name,
        L_matrix_link=L_matrix_link,
    )


def _compute_emm_at_values_crossed(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    at_values: tuple[float, ...],
    resolved: ResolvedConditions,
    *,
    display_var: str | None = None,
    display_values: tuple[float, ...] | None = None,
    spec: ModelSpec | None = None,
    effect_scale: str = "link",
    how: str = "mem",
) -> MeeState:
    """Compute EMMs at continuous at-values crossed with condition grid.

    Builds the Cartesian product of ``at_values × grid_combos`` from
    ``resolved.grid_categoricals`` and ``resolved.grid_numerics``.
    Scalar pins from ``resolved.at_overrides`` and
    ``resolved.set_categoricals`` are applied to every row.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the continuous focal variable (design-matrix name).
        at_values: Specific values to evaluate at (on the design-matrix scale).
        resolved: Resolved conditions with grid, at_overrides, and/or
            set_categoricals.
        display_var: Optional raw variable name for user-facing grid/metadata.
        display_values: Optional raw-scale at-values for user-facing grid.
        spec: ModelSpec with link/family info (for effect_scale="response").
        effect_scale: ``"link"`` (default) or ``"response"``.
        how: ``"mem"`` or ``"ame"``.

    Returns:
        MeeState with crossed grid of at-values × conditions.
    """
    from itertools import product as cartesian

    if display_var is None:
        display_var = focal_var
    if display_values is None:
        display_values = at_values

    X_means = bundle.X.mean(axis=0).copy()
    X_names_list = list(bundle.X_names)

    # Apply scalar numeric overrides to X_means
    if resolved.at_overrides:
        for var_name, value in resolved.at_overrides.items():
            if var_name in X_names_list:
                X_means[X_names_list.index(var_name)] = value

    # Build grid axes from resolved conditions
    grid_vars: list[str] = []
    grid_vals: list[list[object]] = []
    for var, levels in resolved.grid_categoricals.items():
        grid_vars.append(var)
        grid_vals.append(levels)
    for var, values in resolved.grid_numerics.items():
        grid_vars.append(var)
        grid_vals.append(values)

    grid_combos = list(cartesian(*grid_vals)) if grid_vals else [()]

    # Build reference rows for each (combo, at_value) pair
    rows: list[np.ndarray] = []
    grid_data: dict[str, list[object]] = {var: [] for var in grid_vars}
    grid_data[display_var] = []

    for combo in grid_combos:
        # Start with base X_means (already has scalar overrides)
        row_X_means = X_means.copy()
        combo_cats = (
            dict(resolved.set_categoricals) if resolved.set_categoricals else {}
        )

        for var, val in zip(grid_vars, combo):
            if isinstance(val, str):
                # Categorical grid variable: add to set_categoricals
                combo_cats[var] = val
            else:
                # Numeric grid variable: override in X_means
                if var in X_names_list:
                    row_X_means[X_names_list.index(var)] = val

        for i, at_val in enumerate(at_values):
            row = _build_continuous_reference_row(
                X_names_list,
                row_X_means,
                focal_var,
                at_val,
                set_categoricals=combo_cats or None,
            )
            rows.append(row)

            # Populate grid data
            for j, var in enumerate(grid_vars):
                grid_data[var].append(combo[j])
            disp_val = display_values[i] if display_values else at_val
            grid_data[display_var].append(disp_val)

    X_ref = np.vstack(rows)
    estimates_link = X_ref @ fit.coef
    L_matrix: np.ndarray = X_ref
    link_name: str | None = None
    L_matrix_link: np.ndarray | None = None

    if effect_scale == "response" and spec is not None and spec.link != "identity":
        from bossanova.internal.maths.family.links import (
            apply_link_inverse,
            apply_link_inverse_deriv,
        )

        estimates = np.asarray(apply_link_inverse(spec.link, estimates_link))
        d = np.asarray(apply_link_inverse_deriv(spec.link, estimates_link))
        L_matrix = d[:, np.newaxis] * X_ref
        link_name = spec.link
        L_matrix_link = X_ref
    else:
        estimates = estimates_link

    # Build grid DataFrame: condition columns first, then focal var
    grid = pl.DataFrame(grid_data)

    # Build explore formula string
    vals_str = ", ".join(str(v) for v in display_values)
    cond_parts = []
    for var in grid_vars:
        if var in resolved.grid_categoricals:
            cond_parts.append(var)
        elif var in resolved.grid_numerics:
            nums = resolved.grid_numerics[var]
            cond_parts.append(f"{var}@[{', '.join(str(v) for v in nums)}]")
    cond_str = " + ".join(cond_parts) if cond_parts else ""
    explore_formula = f"{display_var}@[{vals_str}]"
    if cond_str:
        explore_formula = f"{explore_formula} ~ {cond_str}"

    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=explore_formula,
        focal_var=display_var,
        mee_type="means",
        L_matrix=L_matrix,
        how=how,
        effect_scale=effect_scale,
        link=link_name,
        L_matrix_link=L_matrix_link,
    )


def _compute_marginal_slope(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    *,
    resolved_focal_var: str | None = None,
    data: pl.DataFrame,
    spec: ModelSpec | None = None,
    formula_spec: FormulaSpec | None = None,
    effect_scale: str = "link",
    how: str = "mem",
) -> MeeState:
    """Compute marginal slope for a continuous focal variable.

    Routes to ``compute_slopes_finite_diff`` when the model is a GLM
    (non-Gaussian or non-identity link) or when the focal variable
    participates in an interaction.  Otherwise falls back to the fast
    coefficient-extraction path (``compute_slopes``).

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the continuous variable (raw, user-facing).
        resolved_focal_var: Transformed column name for coefficient lookup
            (e.g. ``"center(x)"``).  Falls back to ``focal_var`` if None.
        data: Raw model data DataFrame.
        spec: ModelSpec with family/link info.
        formula_spec: FormulaSpec with learned encoding (for finite-diff).
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.
        how: Averaging method: ``"mem"`` or ``"ame"``.

    Returns:
        MeeState with marginal slope estimate.
    """
    coef_var = resolved_focal_var or focal_var
    needs_finite_diff = False

    # GLM (non-Gaussian or non-identity link) → finite differences
    if spec is not None and (spec.family != "gaussian" or spec.link != "identity"):
        needs_finite_diff = True

    # Interactions involving focal variable → finite differences
    # Check both raw and resolved names against X_names
    if _has_focal_interaction(coef_var, bundle.X_names):
        needs_finite_diff = True

    if needs_finite_diff and formula_spec is not None:
        # Finite-diff path uses raw focal_var: grid is built in raw data
        # space and evaluate_newdata handles transforms
        return compute_slopes_finite_diff(
            bundle=bundle,
            fit=fit,
            focal_var=focal_var,
            explore_formula=focal_var,
            spec=spec,
            formula_spec=formula_spec,
            data=data,
            effect_scale=effect_scale,
            how=how,
        )

    # Fast path: coefficient extraction — use resolved name
    return compute_slopes(
        bundle=bundle,
        fit=fit,
        focal_var=coef_var,
        explore_formula=focal_var,
        spec=spec,
        effect_scale=effect_scale,
    )
