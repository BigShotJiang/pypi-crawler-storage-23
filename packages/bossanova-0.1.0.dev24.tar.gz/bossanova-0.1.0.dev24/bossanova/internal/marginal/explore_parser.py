"""Explore formula recursive descent parser.

Parses token streams from :class:`ExploreScanner` into
:class:`ExploreFormulaSpec` containers.

Grammar::

    explore_formula  := lhs [ TILDE rhs ]

    lhs              := contrast_fn_call | contrast_expr | focal_term
    contrast_fn_call := fn_name LEFT_PAREN focal_term { COMMA arg } RIGHT_PAREN
    fn_name          := 'pairwise' | 'sequential' | 'poly'
                      | 'treatment' | 'dummy'
                      | 'sum' | 'deviation'
                      | 'helmert'
    arg              := kwarg | positional_arg
    kwarg            := IDENTIFIER EQUAL value
    positional_arg   := value

    contrast_expr    := IDENTIFIER LEFT_BRACKET contrast_list RIGHT_BRACKET
    contrast_list    := contrast_item { COMMA contrast_item }
    contrast_item    := contrast_operand MINUS contrast_operand
    contrast_operand := STAR
                      | LEFT_PAREN level_name { PLUS level_name } RIGHT_PAREN
                      | level_name
    level_name       := IDENTIFIER | STRING | NUMBER

    focal_term       := IDENTIFIER [ AT at_spec ]
    at_spec          := value
                      | LEFT_BRACKET value_list RIGHT_BRACKET
                      | [COLON] range_or_quantile
    range_or_quantile := IDENTIFIER LEFT_PAREN NUMBER RIGHT_PAREN
                         (where IDENTIFIER is 'range' or 'quantile')
    value_list       := value { COMMA value }
    value            := NUMBER | STRING | IDENTIFIER

    rhs              := condition { PLUS condition }
    condition        := IDENTIFIER LEFT_BRACKET contrast_list RIGHT_BRACKET
                      | IDENTIFIER [ AT at_spec ]
"""

from __future__ import annotations

from bossanova.internal.containers.structs.explore import (
    Condition,
    ContrastExpr,
    ContrastItem,
    ContrastOperand,
    ExploreFormulaSpec,
    ExploreFormulaError,
)
from bossanova.internal.formula.contrast_registry import (
    DEGREE_FUNCTIONS,
    ORDER_DEPENDENT,
    REF_FUNCTIONS,
    VALID_CONTRAST_FUNCTIONS,
    resolve_contrast_name,
)
from bossanova.internal.formula.parser.token import Token

__all__ = [
    "ExploreParser",
]

# At-spec generator function names
_AT_GENERATORS = frozenset({"range", "quantile"})


class ExploreParser:
    """Recursive descent parser for explore formula syntax.

    Consumes tokens produced by :class:`ExploreScanner` and builds an
    :class:`ExploreFormulaSpec` container.

    Args:
        tokens: List of tokens from the scanner.
        formula: Original formula string (for error messages).
    """

    def __init__(self, tokens: list[Token], formula: str) -> None:
        self._tokens = tokens
        self._formula = formula
        self._pos = 0

    # ------------------------------------------------------------------
    # Navigation helpers
    # ------------------------------------------------------------------

    def _at_end(self) -> bool:
        """Return True if at end of token stream."""
        return self._pos >= len(self._tokens) or self._peek().kind == "EOF"

    def _peek(self) -> Token:
        """Return current token without consuming it."""
        if self._pos >= len(self._tokens):
            return self._tokens[-1]  # EOF
        return self._tokens[self._pos]

    def _peek_next(self) -> Token:
        """Return next token without consuming current."""
        idx = self._pos + 1
        if idx >= len(self._tokens):
            return self._tokens[-1]  # EOF
        return self._tokens[idx]

    def _advance(self) -> Token:
        """Consume and return current token."""
        token = self._peek()
        if token.kind != "EOF":
            self._pos += 1
        return token

    def _match(self, kind: str) -> bool:
        """Consume current token if it matches ``kind``. Return whether it matched."""
        if not self._at_end() and self._peek().kind == kind:
            self._advance()
            return True
        return False

    def _expect(self, kind: str, message: str | None = None) -> Token:
        """Consume current token, raising if it doesn't match ``kind``.

        Args:
            kind: Expected token kind.
            message: Optional custom error message.

        Returns:
            The consumed token.

        Raises:
            ExploreFormulaError: If current token doesn't match.
        """
        token = self._peek()
        if token.kind != kind:
            msg = message or f"Expected {kind}, got {token.kind} ('{token.lexeme}')"
            raise ExploreFormulaError(msg, self._formula, token.position)
        return self._advance()

    def _error(self, message: str) -> ExploreFormulaError:
        """Create an error at the current position."""
        return ExploreFormulaError(message, self._formula, self._peek().position)

    # ------------------------------------------------------------------
    # Value parsing helpers
    # ------------------------------------------------------------------

    def _parse_value(self) -> float | str:
        """Parse a single value (NUMBER, STRING, IDENTIFIER, or negative NUMBER).

        Handles a leading ``MINUS`` before a ``NUMBER`` to support negative
        values like ``-1`` in at-spec lists.

        Returns:
            Parsed value as float or string.

        Raises:
            ExploreFormulaError: If current token is not a value.
        """
        token = self._peek()
        # Negative number: MINUS followed by NUMBER
        if token.kind == "MINUS" and self._peek_next().kind == "NUMBER":
            self._advance()  # consume MINUS
            num_token = self._advance()  # consume NUMBER
            return -num_token.literal  # type: ignore[return-value]
        if token.kind == "NUMBER":
            self._advance()
            return token.literal  # type: ignore[return-value]
        if token.kind == "STRING":
            self._advance()
            return token.literal  # type: ignore[return-value]
        if token.kind == "IDENTIFIER":
            self._advance()
            return token.lexeme
        raise self._error(
            f"Expected a value (number, string, or identifier), got '{token.lexeme}'"
        )

    def _parse_value_list(self) -> tuple[float | str, ...]:
        """Parse a comma-separated list of values.

        Returns:
            Tuple of parsed values.
        """
        values: list[float | str] = [self._parse_value()]
        while self._match("COMMA"):
            values.append(self._parse_value())
        return tuple(values)

    # ------------------------------------------------------------------
    # Top-level entry point
    # ------------------------------------------------------------------

    def parse(self) -> ExploreFormulaSpec:
        """Parse explore formula tokens into ExploreFormulaSpec container.

        Returns:
            Parsed ExploreFormulaSpec.

        Raises:
            ExploreFormulaError: If parsing fails.
        """
        lhs = self._parse_lhs()
        conditions: tuple[Condition, ...] = ()

        if self._match("TILDE"):
            conditions = self._parse_rhs()

        if not self._at_end():
            token = self._peek()
            raise self._error(
                f"Unexpected token '{token.lexeme}' after explore formula"
            )

        return ExploreFormulaSpec(
            focal_var=lhs["focal_var"],
            contrast_type=lhs.get("contrast_type"),
            contrast_degree=lhs.get("contrast_degree"),
            contrast_ref=lhs.get("contrast_ref"),
            contrast_level_ordering=lhs.get("contrast_level_ordering"),
            contrast_expr=lhs.get("contrast_expr"),
            conditions=conditions,
            focal_at_values=lhs.get("focal_at_values"),
            focal_at_range=lhs.get("focal_at_range"),
            focal_at_quantile=lhs.get("focal_at_quantile"),
        )

    # ------------------------------------------------------------------
    # LHS parsing
    # ------------------------------------------------------------------

    def _parse_lhs(self) -> dict:
        """Parse LHS: contrast_fn_call or focal_term.

        Returns:
            Dict with keys: focal_var, contrast_type, contrast_degree,
            focal_at_values, focal_at_range, focal_at_quantile.
        """
        token = self._peek()

        if token.kind != "IDENTIFIER":
            raise self._error(
                f"Expected variable name or contrast function, got '{token.lexeme}'"
            )

        # Check if this is a contrast function: IDENTIFIER followed by LEFT_PAREN
        # where the identifier is a known contrast function name
        if (
            self._peek_next().kind == "LEFT_PAREN"
            and token.lexeme in VALID_CONTRAST_FUNCTIONS
        ):
            return self._parse_contrast_fn_call()

        # Check for bracket syntax: IDENTIFIER followed by LEFT_BRACKET
        # Disambiguate: Drug[A - B] is a contrast expr; Drug[A, B] is an error
        if self._peek_next().kind == "LEFT_BRACKET":
            if self._brackets_contain_minus():
                return self._parse_contrast_expr()
            raise ExploreFormulaError(
                f"Bare bracket syntax is not supported. "
                f"Use '@' before brackets: '{token.lexeme}@[...]' "
                f"instead of '{token.lexeme}[...]'",
                self._formula,
                token.position,
            )

        # Compound variable: IDENTIFIER COLON IDENTIFIER LEFT_BRACKET
        # e.g., Drug:Dose[Active:High - Placebo:Low]
        if self._peek_next().kind == "COLON":
            bracket_pos = self._find_bracket_after_compound()
            if bracket_pos is not None and self._brackets_contain_minus(
                bracket_pos=bracket_pos
            ):
                return self._parse_contrast_expr()
            # Bare interaction syntax: x:treatment or x*treatment
            raise ExploreFormulaError(
                f"Interaction syntax ('{token.lexeme}:...') is not "
                f"supported in explore formulas. "
                f"To condition on a variable, use: "
                f"'{token.lexeme} ~ other_variable'",
                self._formula,
                self._peek_next().position,
            )

        # Bare * or + after identifier: suggest ~ syntax
        if self._peek_next().kind in ("STAR", "PLUS"):
            op = self._peek_next().lexeme
            raise ExploreFormulaError(
                f"'{op}' is not supported in explore formulas. "
                f"To condition on a variable, use '~': "
                f"'{token.lexeme} ~ other_variable'",
                self._formula,
                self._peek_next().position,
            )

        # Plain focal term (possibly with @)
        return self._parse_focal_term_result()

    def _parse_contrast_fn_call(self) -> dict:
        """Parse: fn_name LEFT_PAREN focal_term { COMMA arg } RIGHT_PAREN.

        Supports positional and keyword arguments:
        - ``poly(X, 2)`` or ``poly(X, degree=2)`` — degree parameter
        - ``treatment(X, ref=Placebo)`` — reference level

        Returns:
            Dict with contrast_type, contrast_degree, contrast_ref,
            and focal term fields.
        """
        fn_token = self._advance()  # consume function name
        fn_name = fn_token.lexeme
        contrast_type = resolve_contrast_name(fn_name)
        self._expect("LEFT_PAREN", f"Expected '(' after '{fn_name}'")

        # Parse inner focal term
        focal = self._parse_focal_term_result()

        # Parse optional arguments after the focal term
        contrast_degree = None
        contrast_ref = None
        level_ordering: list[str] | None = None

        while self._match("COMMA"):
            arg_token = self._peek()

            # Check for bracket list: [level, level, ...]
            if arg_token.kind == "LEFT_BRACKET":
                if contrast_type not in ORDER_DEPENDENT:
                    raise ExploreFormulaError(
                        f"Level ordering [list] is only valid for order-dependent "
                        f"contrasts (helmert, sequential, poly), not {fn_name}()",
                        self._formula,
                        arg_token.position,
                    )
                self._advance()  # consume LEFT_BRACKET
                level_ordering = [str(v) for v in self._parse_value_list()]
                self._expect(
                    "RIGHT_BRACKET",
                    "Expected ']' to close level ordering list",
                )
                continue

            # Check for keyword argument: IDENTIFIER EQUAL value
            if arg_token.kind == "IDENTIFIER" and self._peek_next().kind == "EQUAL":
                key_token = self._advance()  # consume key
                self._advance()  # consume EQUAL
                key = key_token.lexeme

                if key == "ref":
                    if contrast_type not in REF_FUNCTIONS:
                        raise ExploreFormulaError(
                            f"'ref' parameter is only valid for "
                            f"treatment()/dummy(), not {fn_name}()",
                            self._formula,
                            key_token.position,
                        )
                    ref_val = self._parse_value()
                    contrast_ref = str(ref_val)
                elif key == "degree":
                    contrast_degree = self._parse_degree_arg(fn_name, contrast_type)
                else:
                    raise ExploreFormulaError(
                        f"Unknown keyword argument '{key}' for {fn_name}()",
                        self._formula,
                        key_token.position,
                    )
            else:
                # Positional argument — must be degree for poly()
                contrast_degree = self._parse_degree_arg(fn_name, contrast_type)

        # Validate required parameters
        if contrast_type in REF_FUNCTIONS and contrast_ref is None:
            raise ExploreFormulaError(
                f"{fn_name}() requires a 'ref' parameter. "
                f"Example: {fn_name}({focal['focal_var']}, ref=SomeLevel)",
                self._formula,
                fn_token.position,
            )

        self._expect("RIGHT_PAREN", f"Expected ')' to close {fn_name}()")

        focal["contrast_type"] = contrast_type
        focal["contrast_degree"] = contrast_degree
        focal["contrast_ref"] = contrast_ref
        focal["contrast_level_ordering"] = (
            tuple(level_ordering) if level_ordering is not None else None
        )
        return focal

    def _parse_degree_arg(self, fn_name: str, contrast_type: str) -> int:
        """Parse and validate a degree argument (positional or from kwarg).

        Args:
            fn_name: Original function name (for error messages).
            contrast_type: Canonical contrast type name.

        Returns:
            Validated integer degree value.

        Raises:
            ExploreFormulaError: If degree is invalid or function doesn't
                accept degree.
        """
        degree_token = self._peek()
        if degree_token.kind != "NUMBER":
            raise self._error(f"Expected degree number, got '{degree_token.lexeme}'")
        self._advance()
        degree_val = degree_token.literal

        if contrast_type not in DEGREE_FUNCTIONS:
            raise ExploreFormulaError(
                f"Degree parameter is only valid for poly(), not {fn_name}()",
                self._formula,
                degree_token.position,
            )

        if not isinstance(degree_val, int):
            if isinstance(degree_val, float) and degree_val == int(degree_val):
                degree_val = int(degree_val)
            else:
                raise ExploreFormulaError(
                    f"Polynomial degree must be an integer, got {degree_val}",
                    self._formula,
                    degree_token.position,
                )

        if degree_val < 1:
            raise ExploreFormulaError(
                f"Polynomial degree must be >= 1, got {degree_val}",
                self._formula,
                degree_token.position,
            )
        return degree_val

    def _parse_focal_term_result(self) -> dict:
        """Parse focal_term and return as dict.

        Returns:
            Dict with keys: focal_var, focal_at_values, focal_at_range,
            focal_at_quantile.
        """
        var_token = self._expect("IDENTIFIER", "Expected variable name")
        var_name = var_token.lexeme

        # Reject bare bracket syntax: var[...]
        if not self._at_end() and self._peek().kind == "LEFT_BRACKET":
            raise ExploreFormulaError(
                f"Bare bracket syntax is not supported. "
                f"Use '@' before brackets: '{var_name}@[...]' "
                f"instead of '{var_name}[...]'",
                self._formula,
                self._peek().position,
            )

        at_values = None
        at_range = None
        at_quantile = None

        if self._match("AT"):
            at_values, at_range, at_quantile = self._parse_at_spec()

        return {
            "focal_var": var_name,
            "focal_at_values": at_values,
            "focal_at_range": at_range,
            "focal_at_quantile": at_quantile,
        }

    # ------------------------------------------------------------------
    # At-spec parsing
    # ------------------------------------------------------------------

    def _parse_at_spec(
        self,
    ) -> tuple[
        tuple[float | str, ...] | None,
        int | None,
        int | None,
    ]:
        """Parse at-spec after ``@`` token.

        Returns:
            Tuple of (at_values, at_range, at_quantile).
        """
        # Optional colon prefix (for :range() and :quantile() compat)
        self._match("COLON")

        token = self._peek()

        # range(n) or quantile(n)
        if (
            token.kind == "IDENTIFIER"
            and token.lexeme in _AT_GENERATORS
            and self._peek_next().kind == "LEFT_PAREN"
        ):
            return self._parse_at_generator()

        # [value_list]
        if token.kind == "LEFT_BRACKET":
            self._advance()  # consume [
            values = self._parse_value_list()
            self._expect("RIGHT_BRACKET", "Expected ']' to close at-spec value list")
            return values, None, None

        # Single value
        value = self._parse_value()
        return (value,), None, None

    def _parse_at_generator(self) -> tuple[None, int | None, int | None]:
        """Parse range(n) or quantile(n) at-spec generator.

        Returns:
            Tuple of (None, at_range, at_quantile).
        """
        gen_token = self._advance()  # consume 'range' or 'quantile'
        gen_name = gen_token.lexeme
        self._expect("LEFT_PAREN", f"Expected '(' after '{gen_name}'")

        n_token = self._expect("NUMBER", f"Expected integer inside {gen_name}()")
        n_val = n_token.literal
        if not isinstance(n_val, int):
            if isinstance(n_val, float) and n_val == int(n_val):
                n_val = int(n_val)
            else:
                raise ExploreFormulaError(
                    f"Expected integer inside {gen_name}(), got {n_val}",
                    self._formula,
                    n_token.position,
                )

        self._expect("RIGHT_PAREN", f"Expected ')' to close {gen_name}()")

        if gen_name == "range":
            return None, n_val, None
        return None, None, n_val

    # ------------------------------------------------------------------
    # Bracket contrast expression parsing
    # ------------------------------------------------------------------

    def _find_bracket_after_compound(self) -> int | None:
        """Find the LEFT_BRACKET position after a compound var (IDENT:IDENT:...).

        Scans from current position through alternating COLON IDENTIFIER pairs
        to find a LEFT_BRACKET. Returns the position of the LEFT_BRACKET,
        or None if the pattern doesn't end with a bracket.

        Does not consume tokens.

        Returns:
            Position of LEFT_BRACKET or None.
        """
        pos = self._pos + 1  # skip first IDENTIFIER
        while pos < len(self._tokens):
            if self._tokens[pos].kind != "COLON":
                break
            if pos + 1 >= len(self._tokens):
                break
            if self._tokens[pos + 1].kind != "IDENTIFIER":
                break
            pos += 2  # skip COLON + IDENTIFIER
        if pos < len(self._tokens) and self._tokens[pos].kind == "LEFT_BRACKET":
            return pos
        return None

    def _brackets_contain_minus(self, bracket_pos: int | None = None) -> bool:
        """Look ahead inside brackets to check for a MINUS token.

        Used to disambiguate contrast expressions (``Drug[A - B]``) from
        bare bracket at-specs (``Drug[A, B]`` which is an error).

        Does not consume any tokens.

        Args:
            bracket_pos: Position of the LEFT_BRACKET token. If None,
                assumes current position is at IDENTIFIER and next
                token is LEFT_BRACKET (i.e., bracket is at ``_pos + 1``).

        Returns:
            True if brackets contain a MINUS at paren depth 0.
        """
        if bracket_pos is None:
            bracket_pos = self._pos + 1
        scan_pos = bracket_pos + 1  # skip LEFT_BRACKET
        paren_depth = 0

        while scan_pos < len(self._tokens):
            token = self._tokens[scan_pos]
            if token.kind == "EOF" or token.kind == "RIGHT_BRACKET":
                break
            if token.kind == "LEFT_PAREN":
                paren_depth += 1
            elif token.kind == "RIGHT_PAREN":
                paren_depth -= 1
            elif token.kind == "MINUS" and paren_depth == 0:
                return True
            scan_pos += 1

        return False

    def _parse_contrast_expr(self) -> dict:
        """Parse bracket contrast: ``var_ref LEFT_BRACKET contrast_list RIGHT_BRACKET``.

        Supports compound variables: ``Drug:Dose[Active:High - Placebo:Low]``.

        Returns:
            Dict with focal_var, contrast_type="custom", contrast_expr,
            and None at-spec fields.
        """
        var_token = self._advance()  # consume first IDENTIFIER
        var_name = var_token.lexeme

        # Compound variable: Drug:Dose or Drug:Dose:Route
        while (
            not self._at_end()
            and self._peek().kind == "COLON"
            and self._peek_next().kind == "IDENTIFIER"
            # Stop if the IDENTIFIER is followed by LEFT_BRACKET (it's still a var part)
            # or another COLON (more components). Otherwise it might be a level name.
            and (
                self._pos + 2 < len(self._tokens)
                and self._tokens[self._pos + 2].kind in ("COLON", "LEFT_BRACKET")
            )
        ):
            self._advance()  # consume COLON
            next_part = self._advance()  # consume IDENTIFIER
            var_name = f"{var_name}:{next_part.lexeme}"

        self._advance()  # consume LEFT_BRACKET

        items = self._parse_contrast_list()

        self._expect("RIGHT_BRACKET", "Expected ']' to close contrast expression")

        expr = ContrastExpr(var=var_name, items=items)

        return {
            "focal_var": var_name,
            "contrast_type": "custom",
            "contrast_expr": expr,
            "focal_at_values": None,
            "focal_at_range": None,
            "focal_at_quantile": None,
        }

    def _parse_contrast_list(self) -> tuple[ContrastItem, ...]:
        """Parse comma-separated contrast items: ``item { COMMA item }``.

        Returns:
            Tuple of ContrastItem objects.
        """
        items: list[ContrastItem] = [self._parse_contrast_item()]
        while self._match("COMMA"):
            items.append(self._parse_contrast_item())
        return tuple(items)

    def _parse_contrast_item(self) -> ContrastItem:
        """Parse a single contrast: ``operand MINUS operand``.

        Returns:
            ContrastItem with left and right operands.
        """
        left = self._parse_contrast_operand()
        self._expect("MINUS", "Expected '-' between contrast operands")
        right = self._parse_contrast_operand()
        return ContrastItem(left=left, right=right)

    def _parse_contrast_operand(self) -> ContrastOperand:
        """Parse a contrast operand: ``STAR``, grouped levels, or single level.

        Supports:
        - ``*`` — wildcard (all unmentioned levels)
        - ``(A + B + C)`` — grouped mean
        - ``LevelName`` — single level

        Returns:
            ContrastOperand.
        """
        token = self._peek()

        # Wildcard: *
        if token.kind == "STAR":
            self._advance()
            return ContrastOperand(is_wildcard=True)

        # Grouped: (A + B + C)
        if token.kind == "LEFT_PAREN":
            self._advance()  # consume (
            levels = [self._parse_level_name()]
            while self._match("PLUS"):
                levels.append(self._parse_level_name())
            self._expect("RIGHT_PAREN", "Expected ')' to close grouped operand")
            return ContrastOperand(levels=levels)

        # Single level name
        level = self._parse_level_name()
        return ContrastOperand(levels=[level])

    def _parse_level_name(self) -> str:
        """Parse a level name, optionally compound.

        Supports:
        - ``IDENTIFIER`` — simple level name (e.g., ``Active``)
        - ``STRING`` — quoted level name (e.g., ``'Active Drug'``)
        - ``NUMBER`` — numeric level (e.g., ``4``)
        - ``IDENTIFIER COLON IDENTIFIER`` — compound level (e.g., ``Active:High``)

        Compound levels are eagerly parsed: if an IDENTIFIER is followed
        by ``COLON IDENTIFIER`` (where the next token after that is NOT
        ``LEFT_BRACKET``), it is consumed as part of the level name.

        Returns:
            Level name as string.
        """
        token = self._peek()
        if token.kind == "IDENTIFIER":
            self._advance()
            name = token.lexeme

            # Compound level: name:name2:name3...
            # Only consume COLON IDENTIFIER if the IDENTIFIER is followed by
            # a continuation token (COLON, MINUS, PLUS, COMMA, RIGHT_BRACKET,
            # RIGHT_PAREN, EOF) — not LEFT_BRACKET (which would indicate a
            # bracket contrast on a condition variable).
            while (
                not self._at_end()
                and self._peek().kind == "COLON"
                and self._peek_next().kind == "IDENTIFIER"
            ):
                self._advance()  # consume COLON
                next_part = self._advance()  # consume IDENTIFIER
                name = f"{name}:{next_part.lexeme}"

            return name
        if token.kind == "STRING":
            self._advance()
            return str(token.literal)
        if token.kind == "NUMBER":
            self._advance()
            val = token.literal
            if isinstance(val, float) and val == int(val):
                return str(int(val))
            return str(val)
        raise self._error(
            f"Expected level name (identifier, string, or number), got '{token.lexeme}'"
        )

    # ------------------------------------------------------------------
    # RHS parsing
    # ------------------------------------------------------------------

    def _parse_rhs(self) -> tuple[Condition, ...]:
        """Parse RHS conditions: condition { PLUS condition }.

        Returns:
            Tuple of Condition objects.
        """
        conditions: list[Condition] = [self._parse_condition()]
        while self._match("PLUS"):
            conditions.append(self._parse_condition())
        return tuple(conditions)

    def _parse_condition(self) -> Condition:
        """Parse a single condition: IDENTIFIER [AT at_spec | bracket_contrast].

        Supports:
        - ``Dose@High`` — pin to level
        - ``Dose@[High, Low]`` — grid over levels
        - ``Dose[High - Low]`` — bracket contrast on condition

        Returns:
            Condition object.
        """
        var_token = self._expect("IDENTIFIER", "Expected variable name in condition")
        var_name = var_token.lexeme

        # Check for bracket contrast: Var[A - B]
        if (
            not self._at_end()
            and self._peek().kind == "LEFT_BRACKET"
            and self._brackets_contain_minus(bracket_pos=self._pos)
        ):
            self._advance()  # consume LEFT_BRACKET
            items = self._parse_contrast_list()
            self._expect("RIGHT_BRACKET", "Expected ']' to close contrast expression")
            expr = ContrastExpr(var=var_name, items=items)
            return Condition(var=var_name, contrast_expr=expr)

        # Bare bracket syntax: group[X, Y] → suggest @[...]
        if not self._at_end() and self._peek().kind == "LEFT_BRACKET":
            raise ExploreFormulaError(
                f"Bare bracket syntax is not supported. "
                f"Use '@' before brackets: '{var_name}@[...]' "
                f"instead of '{var_name}[...]'",
                self._formula,
                self._peek().position,
            )

        if self._match("AT"):
            at_values, at_range, at_quantile = self._parse_at_spec()
            return Condition(
                var=var_name,
                at_values=at_values,
                at_range=at_range,
                at_quantile=at_quantile,
            )

        return Condition(var=var_name)
