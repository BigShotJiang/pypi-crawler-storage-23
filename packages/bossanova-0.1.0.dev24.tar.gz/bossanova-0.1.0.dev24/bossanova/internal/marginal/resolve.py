"""Resolution helpers for marginal effects dispatch.

Translates raw user-facing formula elements into internal representations:
variable name resolution through transforms, at-value forward transforms,
condition classification, and focal at-range/at-quantile materialization.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from bossanova.internal.marginal.conditions import (
    ResolvedConditions,
    get_column_values,
    resolve_conditions,
)

if TYPE_CHECKING:
    import polars as pl

    from bossanova.internal.containers.structs.data import DataBundle
    from bossanova.internal.containers.structs.explore import ExploreFormulaSpec
    from bossanova.internal.containers.structs.formula import FormulaSpec
    from bossanova.internal.containers.structs.state import VaryingState
    from bossanova.internal.maths.transforms import StatefulTransform

__all__ = [
    "INVERTIBLE_TRANSFORMS",
    "build_var_transform_map",
    "resolve_all_conditions",
    "resolve_at_overrides",
    "resolve_conditional",
    "resolve_focal_at_spec",
    "resolve_focal_at_values",
    "resolve_focal_var",
]

# Transforms that support forward application to raw-scale values.
INVERTIBLE_TRANSFORMS = frozenset({"center", "norm", "zscore", "scale"})


def build_var_transform_map(
    formula_spec: FormulaSpec | None,
) -> dict[str, tuple[str, StatefulTransform]]:
    """Build a mapping from raw variable names to their transformed column info.

    Inspects ``formula_spec.transform_state`` keys (e.g. ``"center(x)"``) and
    extracts the inner variable name.  Only includes invertible transforms
    (center, norm, zscore, scale).

    Args:
        formula_spec: FormulaSpec with transform_state and transforms dicts.

    Returns:
        Dict mapping raw variable name to ``(transformed_col_name, transform_obj)``.
        Empty dict when no transforms are present or formula_spec is None.
    """
    if formula_spec is None:
        return {}

    result: dict[str, tuple[str, StatefulTransform]] = {}
    for key, state in formula_spec.transform_state.items():
        transform_type = state.get("type", "")
        if transform_type not in INVERTIBLE_TRANSFORMS:
            continue
        # Extract inner variable from state dict
        variable = state.get("variable", "")
        if not variable:
            continue
        transform_obj = formula_spec.transforms.get(key)
        if transform_obj is not None:
            result[variable] = (key, transform_obj)  # type: ignore[assignment]
    return result


def resolve_at_overrides(
    at_overrides: dict[str, float] | None,
    formula_spec: FormulaSpec | None,
    inverse_transforms: bool,
) -> dict[str, float] | None:
    """Remap at-override keys through forward transforms; optionally transform values.

    Always remaps raw variable names to their transformed column names
    (e.g. ``"x"`` → ``"center(x)"``).  When ``inverse_transforms=True``,
    also forward-transforms the values (e.g. ``50`` → ``50 - mean``).
    When ``False``, values are left as-is on the user-specified scale.

    Args:
        at_overrides: Original at-override dict (may be None).
        formula_spec: FormulaSpec with learned transforms.
        inverse_transforms: Whether to apply forward transforms to values.

    Returns:
        Resolved at_overrides dict, or None if input was None.

    Raises:
        ValueError: If a raw variable maps to a non-invertible transform
            (rank, signed_rank) and ``inverse_transforms=True``.
    """
    if at_overrides is None or formula_spec is None:
        return at_overrides

    # Check for non-invertible transforms on any override variable
    if inverse_transforms:
        for key in at_overrides:
            for tkey, tstate in formula_spec.transform_state.items():
                variable = tstate.get("variable", "")
                if (
                    variable == key
                    and tstate.get("type", "") not in INVERTIBLE_TRANSFORMS
                ):
                    raise ValueError(
                        f"Cannot use inverse_transforms with {tstate.get('type', '')}({key}): "
                        f"this transform is not invertible. Use inverse_transforms=False "
                        f"and provide values on the transformed scale, or use the "
                        f"transformed column name '{tkey}' directly."
                    )

    var_map = build_var_transform_map(formula_spec)
    if not var_map:
        return at_overrides

    resolved: dict[str, float] = {}
    for var_name, value in at_overrides.items():
        if var_name in var_map:
            col_name, transform_obj = var_map[var_name]
            if inverse_transforms:
                transformed = transform_obj.transform(np.array([value]))
                resolved[col_name] = float(transformed[0])
            else:
                resolved[col_name] = value
        else:
            resolved[var_name] = value
    return resolved


def resolve_focal_at_values(
    focal_var: str,
    at_values: tuple[float, ...],
    formula_spec: FormulaSpec | None,
    inverse_transforms: bool,
) -> tuple[float, ...]:
    """Forward-transform focal at-values through a formula transform.

    When ``inverse_transforms=True`` and the focal variable has a learned
    transform (e.g. ``center(x)``), applies the forward transform to each
    at-value so that raw-scale values become transformed-scale values.

    Args:
        focal_var: Raw focal variable name (e.g. ``"Days"``).
        at_values: User-specified at-values on the raw scale.
        formula_spec: FormulaSpec with learned transforms.
        inverse_transforms: Whether to apply forward transforms.

    Returns:
        Transformed at-values tuple (or original if no transform applies).
    """
    if not inverse_transforms or formula_spec is None:
        return at_values

    var_map = build_var_transform_map(formula_spec)
    if focal_var not in var_map:
        return at_values

    _, transform_obj = var_map[focal_var]
    transformed = transform_obj.transform(np.array(at_values))
    return tuple(float(v) for v in transformed)


def resolve_focal_var(
    focal_var: str,
    X_names: tuple[str, ...] | list[str],
    formula_spec: FormulaSpec | None,
    inverse_transforms: bool,
) -> str:
    """Resolve a raw focal variable name to its transformed column name.

    Always attempts resolution regardless of ``inverse_transforms`` so that
    raw variable names (e.g. ``"x"``) are mapped to their design-matrix
    column names (e.g. ``"center(x)"``).

    Args:
        focal_var: Raw variable name from the explore formula.
        X_names: Design matrix column names.
        formula_spec: FormulaSpec with transform info.
        inverse_transforms: Unused; kept for API compatibility.

    Returns:
        The resolved column name (transformed or original).
    """
    if formula_spec is None:
        return focal_var

    # If the focal var is already in X_names, no resolution needed
    if focal_var in X_names:
        return focal_var

    var_map = build_var_transform_map(formula_spec)
    if focal_var in var_map:
        col_name, _ = var_map[focal_var]
        if col_name in X_names:
            return col_name

    return focal_var


def resolve_conditional(
    parsed: ExploreFormulaSpec,
    bundle: DataBundle,
    varying: str,
    varying_offsets: VaryingState | None,
) -> tuple[bool, str | None]:
    """Determine if conditional effects are requested and resolve grouping var.

    Args:
        parsed: Parsed explore formula.
        bundle: DataBundle with RE metadata.
        varying: "exclude" or "include".
        varying_offsets: VaryingState (None for non-mixed models).

    Returns:
        Tuple of (is_conditional, grouping_var or None).
    """
    if varying_offsets is None or bundle.re_metadata is None:
        return False, None

    grouping_vars = list(bundle.re_metadata.grouping_vars)

    # Check if any condition var is a grouping variable
    if parsed.has_conditions:
        for cond in parsed.conditions:
            if cond.var in grouping_vars:
                return True, cond.var

    # varying="include" with no condition → use first grouping var
    if varying == "include":
        return True, grouping_vars[0]

    return False, None


def resolve_focal_at_spec(
    parsed: ExploreFormulaSpec,
    data: pl.DataFrame,
    bundle: DataBundle,
) -> ExploreFormulaSpec:
    """Resolve ``focal_at_range`` / ``focal_at_quantile`` into ``focal_at_values``.

    When the parsed formula contains ``focal_at_range=n`` or
    ``focal_at_quantile=n``, this function computes the concrete values from
    the data and returns an evolved copy with ``focal_at_values`` populated.

    Args:
        parsed: Parsed explore formula (may have range/quantile fields set).
        data: Original data DataFrame for computing range/quantile values.
        bundle: DataBundle with design matrix metadata.

    Returns:
        ExploreFormulaSpec with ``focal_at_values`` resolved (or unchanged if
        neither range nor quantile was set).
    """
    import attrs

    if parsed.focal_at_range is not None:
        col_vals = get_column_values(data, bundle, parsed.focal_var)
        values = tuple(
            float(v)
            for v in np.linspace(
                float(np.min(col_vals)),
                float(np.max(col_vals)),
                parsed.focal_at_range,
            )
        )
        return attrs.evolve(parsed, focal_at_values=values, focal_at_range=None)

    if parsed.focal_at_quantile is not None:
        col_vals = get_column_values(data, bundle, parsed.focal_var)
        n = parsed.focal_at_quantile
        probs = np.linspace(0.0, 1.0, n + 2)[1:-1]  # exclude 0 and 1
        values = tuple(float(v) for v in np.quantile(col_vals, probs))
        return attrs.evolve(parsed, focal_at_values=values, focal_at_quantile=None)

    return parsed


def resolve_all_conditions(
    parsed: ExploreFormulaSpec,
    bundle: DataBundle,
    data: pl.DataFrame,
    fspec: FormulaSpec | None,
    inverse_transforms: bool,
) -> ResolvedConditions:
    """Resolve formula conditions into typed buckets.

    Classifies RHS conditions from the parsed formula, then applies
    forward transforms to numeric overrides.

    Args:
        parsed: Parsed explore formula.
        bundle: DataBundle with factor_levels and design matrix.
        data: Original data DataFrame.
        fspec: FormulaSpec with learned transforms (for forward resolution).
        inverse_transforms: Whether to apply forward transforms.

    Returns:
        ResolvedConditions with all conditions classified.
    """

    # Validate condition variables are in the model
    if parsed.has_conditions:
        _model_vars: set[str] = set()
        if bundle.factor_levels is not None:
            _model_vars.update(bundle.factor_levels.keys())
        _model_vars.update(bundle.X_names)
        # Include raw variable names from ALL transforms (not just invertible)
        if fspec is not None:
            for _key, _state in fspec.transform_state.items():
                _raw = _state.get("variable", "")
                if _raw:
                    _model_vars.add(_raw)

        for cond in parsed.conditions:
            if cond.var not in _model_vars:
                if cond.var in data.columns:
                    msg = (
                        f"Condition variable '{cond.var}' is in the data "
                        f"but not in the model formula. It must be a model "
                        f"predictor to condition on."
                    )
                else:
                    msg = (
                        f"Condition variable '{cond.var}' is not recognized. "
                        f"It must be a predictor in the model formula."
                    )
                raise ValueError(msg)

    # Resolve formula RHS conditions
    if parsed.has_conditions:
        resolved = resolve_conditions(parsed.conditions, bundle, data)
    else:
        resolved = ResolvedConditions(
            at_overrides={},
            set_categoricals={},
            grid_categoricals={},
            grid_numerics={},
        )

    # Apply forward transforms to numeric overrides
    if resolved.at_overrides:
        raw_overrides = dict(resolved.at_overrides)
        transformed = resolve_at_overrides(
            resolved.at_overrides, fspec, inverse_transforms
        )
        if transformed is not None and transformed != resolved.at_overrides:
            resolved = ResolvedConditions(
                at_overrides=transformed,
                set_categoricals=resolved.set_categoricals,
                grid_categoricals=resolved.grid_categoricals,
                grid_numerics=resolved.grid_numerics,
                raw_at_overrides=raw_overrides,
            )

    return resolved
