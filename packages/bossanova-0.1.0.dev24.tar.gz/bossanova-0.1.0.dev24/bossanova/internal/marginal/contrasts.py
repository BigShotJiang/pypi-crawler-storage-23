"""Contrast computation for marginal effects.

Applies contrast matrices to EMM estimates. Matrix builders live in
``marginal.matrices``.

Exports:
    apply_contrasts: Apply contrasts to MeeState
    apply_contrasts_grouped: Apply contrasts within condition groups
    compute_contrasts: Apply contrast matrix to EMM vector
"""

from __future__ import annotations

from itertools import combinations
from typing import TYPE_CHECKING

import numpy as np
import polars as pl

from bossanova.internal.containers.builders.state import build_mee_state
from bossanova.internal.containers.schemas import Col
from bossanova.internal.containers.structs.state import MeeState
from bossanova.internal.marginal.matrices import (
    build_all_pairwise_matrix,
    build_helmert_matrix,
    build_poly_matrix,
    build_sequential_matrix,
    build_sum_to_zero_matrix,
    build_treatment_matrix,
)

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import DataBundle
    from bossanova.internal.containers.structs.specs import ModelSpec
    from bossanova.internal.containers.structs.state import FitState, MeeState
    from bossanova.internal.marginal.conditions import ResolvedConditions

__all__ = [
    "apply_contrasts",
    "apply_contrasts_grouped",
    "compute_contrasts",
    "dispatch_contrasts",
]


def _reorder_emm(
    mee_state: MeeState,
    level_ordering: tuple[str, ...],
) -> MeeState:
    """Reorder EMM rows to match the requested level ordering.

    Used by order-dependent contrasts (helmert, sequential, poly) when
    the user specifies an explicit level ordering via bracket list syntax
    (e.g. ``poly(dose, [low, med, high])``).

    Args:
        mee_state: MeeState with EMM estimates.
        level_ordering: Requested level ordering as strings.

    Returns:
        New MeeState with rows reordered.

    Raises:
        ValueError: If requested levels don't match available levels.
    """
    focal_var = mee_state.focal_var
    current_levels = [str(v) for v in mee_state.grid[focal_var].to_list()]

    # Validate that all requested levels exist
    current_set = set(current_levels)
    missing = [lv for lv in level_ordering if lv not in current_set]
    if missing:
        raise ValueError(
            f"Level ordering contains levels not found in data: {missing}. "
            f"Available levels: {current_levels}"
        )

    # Build reordering index
    level_to_idx = {lv: i for i, lv in enumerate(current_levels)}
    reorder_idx = [level_to_idx[lv] for lv in level_ordering]

    # Reorder estimate array
    reordered_estimate = mee_state.estimate[reorder_idx]

    # Reorder grid rows
    reordered_grid = mee_state.grid[reorder_idx]

    # Reorder L_matrix if present
    reordered_L = None
    if mee_state.L_matrix is not None:
        reordered_L = mee_state.L_matrix[reorder_idx]

    return build_mee_state(
        grid=reordered_grid,
        estimate=reordered_estimate,
        explore_formula=mee_state.explore_formula,
        focal_var=focal_var,
        mee_type=mee_state.mee_type,
        L_matrix=reordered_L,
        contrast_method=mee_state.contrast_method,
        n_contrast_levels=mee_state.n_contrast_levels,
    )


def apply_contrasts(
    mee_state: MeeState,
    contrast_type: str,
    fit: FitState | None = None,
    *,
    degree: int | None = None,
    ref_idx: int | None = None,
    level_ordering: tuple[str, ...] | None = None,
) -> MeeState:
    """Apply contrast matrix to marginal means/effects.

    High-level function that takes a MeeState with EMM estimates and
    returns a new MeeState with contrast estimates.

    Args:
        mee_state: MeeState containing EMM estimates from compute_emm().
        contrast_type: Type of contrast to apply:
            - "pairwise": All pairwise comparisons (B-A, C-A, C-B, ...)
            - "sequential": Adjacent differences (B-A, C-B, D-C, ...)
            - "poly": Orthogonal polynomial contrasts
            - "treatment": Each level vs reference (requires ref_idx)
            - "sum": Each level vs grand mean
            - "helmert": Each level vs mean of previous levels
        fit: FitState with vcov for variance propagation (optional,
            only needed if computing SE during this call).
        degree: Maximum polynomial degree for poly contrasts (default: n-1).
        ref_idx: Reference level index for treatment contrasts (0-based).
        level_ordering: Explicit level ordering for order-dependent contrasts
            (e.g. from ``poly(dose, [low, med, high])``). When provided,
            EMM estimates and grid are reordered to match before applying
            the contrast matrix.

    Returns:
        New MeeState with:
        - grid: DataFrame with contrast labels
        - estimate: Contrast estimates
        - type: "contrasts"
        - focal_var: Same as input
        - explore_formula: Updated to reflect contrast

    Raises:
        ValueError: If unknown contrast_type.

    Examples:
        >>> mee = compute_emm(bundle, fit, "treatment", "treatment")
        >>> contrasts = apply_contrasts(mee, "pairwise")
        >>> contrasts.estimate  # B-A, C-A, C-B differences

    Note:
        Variance propagation for inference is deferred to .infer().
        This function only computes point estimates.
    """
    # Reorder EMM to match requested level ordering (for order-dependent contrasts)
    if level_ordering is not None:
        mee_state = _reorder_emm(mee_state, level_ordering)

    n_levels = len(mee_state.estimate)
    focal_var = mee_state.focal_var

    # Build contrast matrix and labels
    if contrast_type == "pairwise":
        C = build_all_pairwise_matrix(n_levels)
        labels = get_pairwise_labels(mee_state.grid, focal_var)
    elif contrast_type == "sequential":
        C = build_sequential_matrix(n_levels)
        labels = get_sequential_labels(mee_state.grid, focal_var)
    elif contrast_type == "poly":
        C = build_poly_matrix(n_levels, degree=degree)
        labels = get_poly_labels(C.shape[0])
    elif contrast_type == "treatment":
        idx = ref_idx if ref_idx is not None else 0
        C = build_treatment_matrix(n_levels, ref_idx=idx)
        labels = _treatment_labels(mee_state.grid, focal_var, ref_idx=idx)
    elif contrast_type == "sum":
        C = build_sum_to_zero_matrix(n_levels)
        labels = _sum_labels(mee_state.grid, focal_var)
    elif contrast_type == "helmert":
        C = build_helmert_matrix(n_levels)
        labels = _helmert_labels(mee_state.grid, focal_var)
    else:
        raise ValueError(
            f"Unknown contrast_type: {contrast_type!r}. "
            f"Valid options: 'pairwise', 'sequential', 'poly', "
            f"'treatment', 'sum', 'helmert'"
        )

    # Apply contrasts
    estimates = compute_contrasts(mee_state.estimate, C)

    # Create contrast grid
    grid = pl.DataFrame({Col.CONTRAST: labels})

    # Carry condition columns from the input EMM grid (e.g. Ethnicity@Asian)
    cond_cols = [c for c in mee_state.grid.columns if c != mee_state.focal_var]
    if cond_cols:
        # All EMM rows share the same condition values (non-grid case)
        first_row = mee_state.grid.row(0, named=True)
        for col in cond_cols:
            grid = grid.with_columns(pl.lit(first_row[col]).alias(col))
        # Reorder: condition cols first, then contrast
        grid = grid.select(cond_cols + [c for c in grid.columns if c not in cond_cols])

    # Build explore formula — include degree for poly if not max
    if contrast_type == "poly" and degree is not None and degree < n_levels - 1:
        formula = f"poly({mee_state.focal_var}, {degree})"
    else:
        formula = f"{contrast_type}({mee_state.focal_var})"

    # Compose contrast matrix with EMM design matrix for delta method
    L_matrix = None
    if mee_state.L_matrix is not None:
        L_matrix = C @ mee_state.L_matrix  # shape: (n_contrasts, n_coef)

    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=formula,
        focal_var=mee_state.focal_var,
        mee_type="contrasts",
        L_matrix=L_matrix,
        contrast_method=contrast_type,
        n_contrast_levels=n_levels,
    )


def apply_contrasts_grouped(
    mee_state: MeeState,
    contrast_type: str | None,
    *,
    degree: int | None = None,
    ref_idx: int | None = None,
    level_ordering: tuple[str, ...] | None = None,
) -> MeeState:
    """Apply contrasts within each condition group of a crossed MeeState.

    When EMMs have been computed over a crossed grid (focal levels x
    condition groups), this function applies the contrast matrix
    independently within each group of ``n_focal`` consecutive rows,
    then stacks the results.

    The number of focal levels is inferred from the focal_var column of
    ``mee_state.grid``.

    Args:
        mee_state: MeeState from ``_compute_emm_crossed()`` with
            ``n_focal x n_groups`` rows ordered as
            ``[focal_1_group_1, ..., focal_k_group_1, focal_1_group_2, ...]``.
        contrast_type: Type of contrast (pairwise, sequential, poly,
            treatment, sum, helmert).
        degree: Degree for polynomial contrasts.
        ref_idx: Reference level index for treatment contrasts.
        level_ordering: Explicit level ordering for order-dependent contrasts.
            When provided, EMM rows within each group are reordered before
            applying the contrast matrix.

    Returns:
        MeeState with ``n_contrasts x n_groups`` rows and condition columns.
    """
    # Reorder EMM to match requested level ordering (for order-dependent contrasts)
    if level_ordering is not None:
        mee_state = _reorder_emm(mee_state, level_ordering)
    # Determine n_focal from unique focal levels in grid
    focal_col = mee_state.grid[mee_state.focal_var].to_list()
    n_total = len(focal_col)

    # Find n_focal: count consecutive focal levels in first group
    focal_levels = []
    seen: set[str] = set()
    for v in focal_col:
        if v in seen:
            break
        seen.add(v)
        focal_levels.append(v)
    n_focal = len(focal_levels)
    n_groups = n_total // n_focal

    # Build contrast matrix
    focal_var = mee_state.focal_var
    if contrast_type == "pairwise":
        C = build_all_pairwise_matrix(n_focal)
        labels = _pairwise_labels_from_levels(focal_levels, focal_var=focal_var)
    elif contrast_type == "sequential":
        C = build_sequential_matrix(n_focal)
        labels = [
            f"{focal_var}{focal_levels[i + 1]} - {focal_var}{focal_levels[i]}"
            for i in range(n_focal - 1)
        ]
    elif contrast_type == "poly":
        C = build_poly_matrix(n_focal, degree=degree)
        labels = get_poly_labels(C.shape[0])
    elif contrast_type == "treatment":
        idx = ref_idx if ref_idx is not None else 0
        C = build_treatment_matrix(n_focal, ref_idx=idx)
        labels = _treatment_labels_from_levels(
            focal_levels, focal_var=focal_var, ref_idx=idx
        )
    elif contrast_type == "sum":
        C = build_sum_to_zero_matrix(n_focal)
        labels = _sum_labels_from_levels(focal_levels, focal_var=focal_var)
    elif contrast_type == "helmert":
        C = build_helmert_matrix(n_focal)
        labels = _helmert_labels_from_levels(focal_levels, focal_var=focal_var)
    else:
        raise ValueError(
            f"Unknown contrast_type: {contrast_type!r}. "
            f"Valid options: 'pairwise', 'sequential', 'poly', "
            f"'treatment', 'sum', 'helmert'"
        )

    n_contrasts = C.shape[0]

    # Apply contrast within each group
    result_estimates = np.empty(n_contrasts * n_groups)
    result_L = None
    if mee_state.L_matrix is not None:
        result_L = np.empty((n_contrasts * n_groups, mee_state.L_matrix.shape[1]))

    for g in range(n_groups):
        start = g * n_focal
        end = start + n_focal
        group_est = mee_state.estimate[start:end]
        result_estimates[g * n_contrasts : (g + 1) * n_contrasts] = C @ group_est
        if result_L is not None and mee_state.L_matrix is not None:
            group_L = mee_state.L_matrix[start:end]
            result_L[g * n_contrasts : (g + 1) * n_contrasts] = C @ group_L

    # Build grid: identify condition columns (everything except focal_var)
    grid_cols = [c for c in mee_state.grid.columns if c != mee_state.focal_var]

    grid_data: dict[str, list[object]] = {Col.CONTRAST: []}
    for col in grid_cols:
        grid_data[col] = []

    for g in range(n_groups):
        # Get condition values from the first row of this group
        group_row = mee_state.grid.row(g * n_focal, named=True)
        for _label in labels:
            grid_data[Col.CONTRAST].append(_label)
            for col in grid_cols:
                grid_data[col].append(group_row[col])

    grid = pl.DataFrame(grid_data)
    # Reorder: condition columns, then contrast
    col_order = grid_cols + [Col.CONTRAST]
    grid = grid.select(col_order)

    # Build explore formula
    if contrast_type == "poly" and degree is not None and degree < n_focal - 1:
        formula = f"poly({mee_state.focal_var}, {degree})"
    else:
        formula = f"{contrast_type}({mee_state.focal_var})"
    if grid_cols:
        formula += " ~ " + ", ".join(grid_cols)

    return build_mee_state(
        grid=grid,
        estimate=result_estimates,
        explore_formula=formula,
        focal_var=mee_state.focal_var,
        mee_type="contrasts",
        L_matrix=result_L,
        contrast_method=contrast_type,
        n_contrast_levels=n_focal,
    )


def _pairwise_labels_from_levels(
    levels: list[str],
    reverse: bool = False,
    focal_var: str = "",
) -> list[str]:
    """Generate pairwise contrast labels from a list of levels.

    Args:
        levels: Factor levels.
        reverse: If True, generate reversed labels (A - B instead of B - A).
        focal_var: Variable name to prefix levels with (e.g. "cyl" → "cyl4 - cyl6").

    Returns:
        List of contrast label strings.
    """
    labels = []
    for i, j in combinations(range(len(levels)), 2):
        li = f"{focal_var}{levels[i]}"
        lj = f"{focal_var}{levels[j]}"
        if reverse:
            labels.append(f"{li} - {lj}")
        else:
            labels.append(f"{lj} - {li}")
    return labels


def get_pairwise_labels(
    grid: pl.DataFrame, focal_var: str, reverse: bool = False
) -> list[str]:
    """Generate labels for pairwise contrasts.

    Labels include the variable name prefix, matching R's emmeans output
    (e.g. ``"cyl6 - cyl4"`` not ``"6 - 4"``).
    """
    levels = grid[focal_var].to_list()
    n = len(levels)
    labels = []
    for i, j in combinations(range(n), 2):
        li = f"{focal_var}{levels[i]}"
        lj = f"{focal_var}{levels[j]}"
        if reverse:
            labels.append(f"{li} - {lj}")
        else:
            labels.append(f"{lj} - {li}")
    return labels


def get_sequential_labels(grid: pl.DataFrame, focal_var: str) -> list[str]:
    """Generate labels for sequential contrasts.

    Labels include the variable name prefix, matching R's emmeans output
    (e.g. ``"cyl6 - cyl4"`` not ``"6 - 4"``).
    """
    levels = grid[focal_var].to_list()
    return [
        f"{focal_var}{levels[i + 1]} - {focal_var}{levels[i]}"
        for i in range(len(levels) - 1)
    ]


def get_poly_labels(degree: int) -> list[str]:
    """Generate labels for polynomial contrasts.

    Uses descriptive names matching R's emmeans output:
    linear, quadratic, cubic, quartic, quintic, then degree-N for higher.
    """
    names = ["linear", "quadratic", "cubic", "quartic", "quintic"]
    labels = []
    for d in range(degree):
        if d < len(names):
            labels.append(names[d])
        else:
            labels.append(f"degree{d + 1}")
    return labels


def _treatment_labels(
    grid: pl.DataFrame, focal_var: str, ref_idx: int = 0
) -> list[str]:
    """Generate labels for treatment contrasts (each level vs reference).

    Args:
        grid: EMM grid DataFrame.
        focal_var: Focal variable name.
        ref_idx: Index of the reference level.

    Returns:
        List of contrast label strings.
    """
    levels = grid[focal_var].to_list()
    ref = levels[ref_idx]
    return [
        f"{focal_var}{levels[i]} - {focal_var}{ref}"
        for i in range(len(levels))
        if i != ref_idx
    ]


def _treatment_labels_from_levels(
    levels: list[str], focal_var: str = "", ref_idx: int = 0
) -> list[str]:
    """Generate treatment contrast labels from a list of levels.

    Args:
        levels: Factor levels.
        focal_var: Variable name prefix.
        ref_idx: Index of the reference level.

    Returns:
        List of contrast label strings.
    """
    ref = levels[ref_idx]
    return [
        f"{focal_var}{levels[i]} - {focal_var}{ref}"
        for i in range(len(levels))
        if i != ref_idx
    ]


def _sum_labels(grid: pl.DataFrame, focal_var: str) -> list[str]:
    """Generate labels for sum-to-zero contrasts (each level vs grand mean).

    Args:
        grid: EMM grid DataFrame.
        focal_var: Focal variable name.

    Returns:
        List of contrast label strings.
    """
    levels = grid[focal_var].to_list()
    return [f"{focal_var}{levels[i]} - mean" for i in range(len(levels) - 1)]


def _sum_labels_from_levels(levels: list[str], focal_var: str = "") -> list[str]:
    """Generate sum-to-zero contrast labels from a list of levels.

    Args:
        levels: Factor levels.
        focal_var: Variable name prefix.

    Returns:
        List of contrast label strings.
    """
    return [f"{focal_var}{levels[i]} - mean" for i in range(len(levels) - 1)]


def _helmert_labels(grid: pl.DataFrame, focal_var: str) -> list[str]:
    """Generate labels for Helmert contrasts (each level vs mean of previous).

    Args:
        grid: EMM grid DataFrame.
        focal_var: Focal variable name.

    Returns:
        List of contrast label strings.
    """
    levels = grid[focal_var].to_list()
    return [
        f"{focal_var}{levels[k]} - mean({', '.join(str(levels[j]) for j in range(k))})"
        for k in range(1, len(levels))
    ]


def _helmert_labels_from_levels(levels: list[str], focal_var: str = "") -> list[str]:
    """Generate Helmert contrast labels from a list of levels.

    Args:
        levels: Factor levels.
        focal_var: Variable name prefix.

    Returns:
        List of contrast label strings.
    """
    return [
        f"{focal_var}{levels[k]} - mean({', '.join(str(levels[j]) for j in range(k))})"
        for k in range(1, len(levels))
    ]


def compute_contrasts(
    emm: np.ndarray,
    contrast_matrix: np.ndarray,
) -> np.ndarray:
    """Apply contrast matrix to EMMs.

    Transforms a vector of estimated marginal means into contrast estimates
    by matrix multiplication. This is the final step when the explore formula
    includes a contrast function like ``pairwise(treatment)``.

    Mathematical formulation:
        contrasts = C @ EMM

        Where:
        - C is the contrast matrix, shape (n_contrasts, n_levels)
        - EMM is the vector of marginal means, shape (n_levels,)
        - contrasts is the result, shape (n_contrasts,)

    Contrast matrices are designed so that:
        - Each row sums to 0 (contrasts compare, not estimate absolute levels)
        - The result represents a comparison (e.g., B - A)

    Args:
        emm: Array of estimated marginal means from compute_emm().
            Shape: (n_levels,)
        contrast_matrix: Contrast matrix from build_all_pairwise_matrix(),
            build_sequential_matrix(), or build_poly_matrix().
            Shape: (n_contrasts, n_levels)
            Rows must be orthogonal to the constant vector (sum to 0).

    Returns:
        Array of contrast estimates.
        Shape: (n_contrasts,)

    Integration with explore():
        Called after compute_emm when a contrast function is specified::

            # In model._compute_marginal_effects():
            if parsed.has_contrast:
                # First compute EMMs
                emms = compute_emm(...)

                # Build appropriate contrast matrix
                if parsed.contrast_type == "pairwise":
                    C = build_all_pairwise_matrix(n_levels)
                elif parsed.contrast_type == "sequential":
                    C = build_sequential_matrix(n_levels)
                elif parsed.contrast_type == "poly":
                    C = build_poly_matrix(n_levels, degree=parsed.contrast_degree)

                # Apply contrasts
                contrast_estimates = compute_contrasts(emms, C)

                return build_mee_state(
                    grid=contrast_grid,  # with contrast labels
                    estimate=contrast_estimates,
                    mee_type="contrasts",
                    ...
                )

    Note:
        For inference on contrasts, the variance of contrasts is:
        Var(C @ EMM) = C @ Var(EMM) @ C.T

        This is handled by the inference methods (delta method for asymp,
        direct computation for bootstrap).

    Examples:
        Apply pairwise contrasts to 3-level EMMs::

            emm = np.array([2.0, 3.5, 2.8])  # A, B, C means
            C = build_all_pairwise_matrix(3)
            # C = [[-1, 1, 0],   # B - A
            #      [-1, 0, 1],   # C - A
            #      [0, -1, 1]]   # C - B

            contrasts = compute_contrasts(emm, C)
            # contrasts: array([1.5, 0.8, -0.7])
    """
    return contrast_matrix @ emm


def dispatch_contrasts(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    contrast_type: str | None,
    contrast_degree: int | None,
    data: pl.DataFrame,
    *,
    spec: ModelSpec | None = None,
    effect_scale: str = "link",
    how: str = "mem",
    resolved: ResolvedConditions | None = None,
    focal_at_values: tuple[float | str, ...] | None = None,
    contrast_ref: str | None = None,
    level_ordering: tuple[str, ...] | None = None,
) -> MeeState:
    """Compute contrasts for a categorical focal variable.

    First computes EMMs, then applies the requested contrast matrix.
    When ``resolved`` contains grid conditions, computes crossed EMMs and
    applies grouped contrasts.  When ``focal_at_values`` is provided
    (e.g. from ``pairwise(cyl@[4, 8])``), contrasts are computed only
    over the requested subset of levels.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical variable.
        contrast_type: Type of contrast (pairwise, sequential, poly, treatment,
            sum, helmert).
        contrast_degree: Degree for polynomial contrasts (None = max).
        data: Model data for level extraction.
        spec: ModelSpec with link info (for effect_scale="response").
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.
        how: Averaging method: ``"mem"`` or ``"ame"``.
        resolved: Resolved conditions for conditioning.
        focal_at_values: Optional subset of levels from at-spec syntax
            (e.g. ``pairwise(cyl@[4, 8])``).
        contrast_ref: Reference level name for treatment contrasts.
        level_ordering: Explicit level ordering for order-dependent contrasts
            (e.g. from ``poly(dose, [low, med, high])``).

    Returns:
        MeeState with contrast estimates.
    """
    from bossanova.internal.marginal.compute import compute_emm_categorical
    from bossanova.internal.marginal.emm import compute_emm_crossed

    # Convert focal_at_values to string level names for filtering
    requested_levels: list[str] | None = None
    if focal_at_values is not None:
        requested_levels = [
            str(int(v)) if isinstance(v, float) and v == int(v) else str(v)
            for v in focal_at_values
        ]

    # Resolve ref_idx from contrast_ref (level name -> index)
    ref_idx = None
    if contrast_ref is not None:
        # We'll resolve the ref_idx after computing EMMs, when we know the levels

        def _resolve_ref_idx(grid: "pl.DataFrame") -> int:
            levels = grid[focal_var].to_list()
            if contrast_ref in levels:
                return levels.index(contrast_ref)
            # Try numeric conversion (e.g. ref="4" matching level "4")
            str_levels = [str(lv) for lv in levels]
            if contrast_ref in str_levels:
                return str_levels.index(contrast_ref)
            raise ValueError(
                f"Reference level '{contrast_ref}' not found in "
                f"levels of '{focal_var}': {levels}"
            )

    if resolved is not None and resolved.has_grid:
        # Crossed path: compute EMMs over the full grid, then group contrasts
        emm_state = compute_emm_crossed(
            bundle,
            fit,
            focal_var,
            resolved=resolved,
            spec=spec,
            effect_scale=effect_scale,
        )
        if contrast_ref is not None:
            ref_idx = _resolve_ref_idx(emm_state.grid)
        return apply_contrasts_grouped(
            emm_state,
            contrast_type,
            degree=contrast_degree,
            ref_idx=ref_idx,
            level_ordering=level_ordering,
        )

    # Simple path: no grid
    at_overrides = resolved.at_overrides if resolved and resolved.at_overrides else None
    set_cats = (
        resolved.set_categoricals if resolved and resolved.set_categoricals else None
    )
    emm_state = compute_emm_categorical(
        bundle,
        fit,
        focal_var,
        levels=requested_levels,
        at_overrides=at_overrides,
        set_categoricals=set_cats,
        spec=spec,
        effect_scale=effect_scale,
        how=how,
    )
    if contrast_ref is not None:
        ref_idx = _resolve_ref_idx(emm_state.grid)
    return apply_contrasts(
        emm_state,
        contrast_type,
        degree=contrast_degree,
        ref_idx=ref_idx,
        level_ordering=level_ordering,
    )
