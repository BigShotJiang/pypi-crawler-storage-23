"""Bracket contrast matrix builder and application.

Builds contrast weight matrices from bracket contrast expressions
(e.g., ``Drug[Active - Placebo]``, ``Drug[* - Placebo]``,
``Drug[(A + B) - C]``).

Auto-normalization: each side of ``-`` normalizes so weights sum to 1.
Wildcard expansion: ``*`` expands to all levels not mentioned on the
other side, producing one contrast row per expanded level.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import polars as pl

from bossanova.internal.containers.builders.state import build_mee_state
from bossanova.internal.containers.schemas import Col
from bossanova.internal.containers.structs.explore import (
    ContrastExpr,
    ContrastItem,
    ContrastOperand,
)

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import DataBundle
    from bossanova.internal.containers.structs.specs import ModelSpec
    from bossanova.internal.containers.structs.state import FitState, MeeState
    from bossanova.internal.marginal.conditions import ResolvedConditions

__all__ = [
    "apply_bracket_contrasts",
    "apply_bracket_contrasts_grouped",
    "apply_rhs_bracket_contrast",
    "build_bracket_contrast_matrix",
    "compute_compound_bracket_contrasts",
    "dispatch_bracket_contrasts",
]


def build_bracket_contrast_matrix(
    expr: ContrastExpr,
    levels: list[str],
) -> tuple[np.ndarray, list[str]]:
    """Build contrast matrix and labels from bracket contrast expression.

    Handles auto-normalization (each operand side sums to +1 or -1)
    and wildcard expansion (``*`` expands to all unmentioned levels).

    Args:
        expr: ContrastExpr AST from the parser.
        levels: Actual factor levels from the EMM grid.

    Returns:
        Tuple of (contrast_matrix, labels) where contrast_matrix has
        shape ``(n_contrasts, n_levels)`` and labels has length
        ``n_contrasts``.

    Raises:
        ValueError: If a level name in the expression is not found in
            levels, or if both sides of a contrast are wildcards.
    """
    n_levels = len(levels)
    level_index = {lv: i for i, lv in enumerate(levels)}

    # Expand wildcards and collect all resolved (left_levels, right_levels)
    resolved: list[tuple[list[str], list[str]]] = []
    for item in expr.items:
        resolved.extend(_expand_item(item, levels, level_index))

    n_contrasts = len(resolved)
    C = np.zeros((n_contrasts, n_levels), dtype=np.float64)
    labels: list[str] = []

    for row_idx, (left_levels, right_levels) in enumerate(resolved):
        # Auto-normalize: each side sums to ±1
        left_weight = 1.0 / len(left_levels)
        right_weight = 1.0 / len(right_levels)

        for lv in left_levels:
            C[row_idx, level_index[lv]] += left_weight
        for lv in right_levels:
            C[row_idx, level_index[lv]] -= right_weight

        labels.append(_make_label(left_levels, right_levels, expr.var))

    return C, labels


def apply_bracket_contrasts(
    mee_state: MeeState,
    expr: ContrastExpr,
) -> MeeState:
    """Apply bracket contrast expression to an EMM MeeState.

    Computes contrasts by building a weight matrix from the bracket
    expression and multiplying by the EMM estimates.

    Args:
        mee_state: MeeState with EMM estimates.
        expr: ContrastExpr from parser.

    Returns:
        New MeeState with contrast estimates, type ``"contrasts"``,
        and ``contrast_method="custom"``.
    """
    levels = [str(lv) for lv in mee_state.grid[mee_state.focal_var].to_list()]
    C, labels = build_bracket_contrast_matrix(expr, levels)

    estimates = C @ mee_state.estimate

    grid = pl.DataFrame({Col.CONTRAST: labels})

    # Carry condition columns from the input EMM grid
    cond_cols = [c for c in mee_state.grid.columns if c != mee_state.focal_var]
    if cond_cols:
        first_row = mee_state.grid.row(0, named=True)
        for col in cond_cols:
            grid = grid.with_columns(pl.lit(first_row[col]).alias(col))
        grid = grid.select(cond_cols + [c for c in grid.columns if c not in cond_cols])

    # Compose contrast matrix with EMM design matrix for delta method
    L_matrix = C @ mee_state.L_matrix if mee_state.L_matrix is not None else None

    formula = _format_expr(expr)

    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=formula,
        focal_var=mee_state.focal_var,
        mee_type="contrasts",
        L_matrix=L_matrix,
        contrast_method="custom",
        n_contrast_levels=len(levels),
    )


def apply_bracket_contrasts_grouped(
    mee_state: MeeState,
    expr: ContrastExpr,
) -> MeeState:
    """Apply bracket contrasts within each condition group of a crossed MeeState.

    Similar to ``apply_contrasts_grouped()`` but for bracket contrast
    expressions. Applies the same contrast matrix independently within
    each group of ``n_focal`` consecutive rows.

    Args:
        mee_state: MeeState from crossed EMM computation with
            ``n_focal x n_groups`` rows.
        expr: ContrastExpr from parser.

    Returns:
        MeeState with ``n_contrasts x n_groups`` rows and condition columns.
    """
    # Determine n_focal from unique focal levels in grid
    focal_col = mee_state.grid[mee_state.focal_var].to_list()
    n_total = len(focal_col)

    focal_levels: list[str] = []
    seen: set[str] = set()
    for v in focal_col:
        sv = str(v)
        if sv in seen:
            break
        seen.add(sv)
        focal_levels.append(sv)
    n_focal = len(focal_levels)
    n_groups = n_total // n_focal

    # Build bracket contrast matrix using focal levels
    C, labels = build_bracket_contrast_matrix(expr, focal_levels)
    n_contrasts = C.shape[0]

    # Apply within each group
    result_estimates = np.empty(n_contrasts * n_groups)
    result_L = None
    if mee_state.L_matrix is not None:
        result_L = np.empty((n_contrasts * n_groups, mee_state.L_matrix.shape[1]))

    for g in range(n_groups):
        start = g * n_focal
        end = start + n_focal
        group_est = mee_state.estimate[start:end]
        result_estimates[g * n_contrasts : (g + 1) * n_contrasts] = C @ group_est
        if result_L is not None and mee_state.L_matrix is not None:
            group_L = mee_state.L_matrix[start:end]
            result_L[g * n_contrasts : (g + 1) * n_contrasts] = C @ group_L

    # Build grid: condition columns + contrast labels
    grid_cols = [c for c in mee_state.grid.columns if c != mee_state.focal_var]
    grid_data: dict[str, list[object]] = {Col.CONTRAST: []}
    for col in grid_cols:
        grid_data[col] = []

    for g in range(n_groups):
        group_row = mee_state.grid.row(g * n_focal, named=True)
        for label in labels:
            grid_data[Col.CONTRAST].append(label)
            for col in grid_cols:
                grid_data[col].append(group_row[col])

    grid = pl.DataFrame(grid_data)
    col_order = grid_cols + [Col.CONTRAST]
    grid = grid.select(col_order)

    formula = _format_expr(expr)
    if grid_cols:
        formula += " ~ " + ", ".join(grid_cols)

    return build_mee_state(
        grid=grid,
        estimate=result_estimates,
        explore_formula=formula,
        focal_var=mee_state.focal_var,
        mee_type="contrasts",
        L_matrix=result_L,
        contrast_method="custom",
        n_contrast_levels=n_focal,
    )


def apply_rhs_bracket_contrast(
    mee_state: MeeState,
    expr: ContrastExpr,
) -> MeeState:
    """Apply a bracket contrast on a RHS condition column.

    After the main computation produces a crossed MeeState with a condition
    column (e.g., ``Dose`` with levels ``[High, Low]``), this collapses
    that column by applying the bracket contrast.

    The condition column must vary slowest in the grid (standard layout
    from crossed EMM/slope computation).

    Args:
        mee_state: MeeState from a crossed computation. Must contain
            ``expr.var`` as a column in the grid.
        expr: ContrastExpr specifying the contrast on the condition variable.

    Returns:
        New MeeState with the condition column replaced by contrast rows.
    """
    cond_var = expr.var

    # Get unique condition levels in order of first appearance
    cond_col = mee_state.grid[cond_var].to_list()
    cond_levels: list[str] = list(dict.fromkeys(str(v) for v in cond_col))
    n_cond = len(cond_levels)
    n_total = len(mee_state.estimate)
    n_per_cond = n_total // n_cond

    # Build contrast matrix for condition levels
    C, rhs_labels = build_bracket_contrast_matrix(expr, cond_levels)
    n_rhs = C.shape[0]

    # Apply to estimates: reshape (n_cond, n_per_cond), contract along cond axis
    est_2d = mee_state.estimate.reshape(n_cond, n_per_cond)
    result_est = (C @ est_2d).ravel()  # (n_rhs * n_per_cond,)

    # Apply to L_matrix
    result_L: np.ndarray | None = None
    if mee_state.L_matrix is not None:
        p = mee_state.L_matrix.shape[1]
        L_3d = mee_state.L_matrix.reshape(n_cond, n_per_cond, p)
        result_L = np.tensordot(C, L_3d, axes=([1], [0])).reshape(-1, p)

    # Build result grid: remove cond_var, add rhs contrast info
    other_cols = [c for c in mee_state.grid.columns if c != cond_var]
    sub_group_grid = mee_state.grid[:n_per_cond].select(other_cols)

    if n_rhs == 1:
        # Single RHS contrast: keep sub-group grid, add "rhs_contrast" column
        grid = sub_group_grid.with_columns(
            pl.lit(rhs_labels[0]).alias(Col.RHS_CONTRAST)
        )
    else:
        # Multiple RHS contrasts: repeat sub-group grid for each
        parts = []
        for label in rhs_labels:
            part = sub_group_grid.with_columns(pl.lit(label).alias(Col.RHS_CONTRAST))
            parts.append(part)
        grid = pl.concat(parts)

    # Format formula
    formula = _format_expr(expr)
    existing_formula = mee_state.explore_formula or ""
    if existing_formula:
        formula = f"{existing_formula} ~ {formula}"

    return build_mee_state(
        grid=grid,
        estimate=result_est,
        explore_formula=formula,
        focal_var=mee_state.focal_var,
        mee_type="contrasts",
        L_matrix=result_L,
        contrast_method="custom",
        n_contrast_levels=n_cond,
    )


def compute_compound_bracket_contrasts(
    bundle: object,
    fit: object,
    focal_var: str,
    contrast_expr: ContrastExpr,
    *,
    data: pl.DataFrame,
    spec: object | None = None,
    effect_scale: str = "link",
    resolved: object | None = None,
) -> MeeState:
    """Compute bracket contrasts for a compound focal variable.

    Handles compound variables like ``Drug:Dose`` by building a crossed
    EMM grid over the component variables, creating compound level names,
    and then applying the bracket contrast.

    For example, ``Drug:Dose[Active:High - Placebo:Low]`` builds EMMs over
    Drug × Dose, labels each cell as ``Active:High``, ``Active:Low``, etc.,
    and applies the contrast ``Active:High - Placebo:Low``.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Compound variable name (e.g., ``"Drug:Dose"``).
        contrast_expr: ContrastExpr from the parser.
        data: Model data DataFrame.
        spec: ModelSpec with link/family info.
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.
        resolved: ResolvedConditions for additional conditioning.

    Returns:
        MeeState with compound bracket contrast estimates.

    Raises:
        ValueError: If any component variable is not found in data or is
            not categorical.
    """
    from itertools import product as cartesian

    from bossanova.internal.design.reference import build_reference_row
    from bossanova.internal.marginal.factors import get_factor_levels
    from bossanova.internal.marginal.conditions import ResolvedConditions

    # Split compound variable into components
    components = focal_var.split(":")
    for comp in components:
        if comp not in data.columns:
            raise ValueError(
                f"Variable '{comp}' (from compound '{focal_var}') not found in data"
            )

    # Get levels for each component
    comp_levels: dict[str, list[str]] = {}
    for comp in components:
        comp_levels[comp] = get_factor_levels(bundle, comp)  # type: ignore[arg-type]

    # Build Cartesian product of all component levels
    all_combos = list(cartesian(*[comp_levels[c] for c in components]))
    compound_level_names = [":".join(combo) for combo in all_combos]
    n_cells = len(compound_level_names)

    # Build reference design matrix rows
    X_means = bundle.X.mean(axis=0).copy()  # type: ignore[union-attr]
    X_names_list = list(bundle.X_names)  # type: ignore[union-attr]

    # Apply any scalar numeric overrides from conditions
    res = resolved if isinstance(resolved, ResolvedConditions) else None
    if res and res.at_overrides:
        for var_name, value in res.at_overrides.items():
            if var_name in X_names_list:
                X_means[X_names_list.index(var_name)] = value

    p = len(X_names_list)
    X_ref = np.zeros((n_cells, p), dtype=np.float64)

    first_comp = components[0]
    for i, combo in enumerate(all_combos):
        # First component is "focal", rest go into set_categoricals
        set_cats: dict[str, str] = {}
        if res and res.set_categoricals:
            set_cats.update(res.set_categoricals)
        for j, comp in enumerate(components):
            if j > 0:
                set_cats[comp] = combo[j]

        X_ref[i] = build_reference_row(
            bundle.X_names,  # type: ignore[arg-type]
            first_comp,
            combo[0],
            X_means,
            set_categoricals=set_cats or None,
        )

    # Compute estimates
    estimates = X_ref @ fit.coef  # type: ignore[union-attr]

    # Handle response-scale transformation
    L_matrix: np.ndarray = X_ref
    link_name: str | None = None
    if effect_scale == "response" and spec is not None:
        _link = getattr(spec, "link", "identity")
        if _link != "identity":
            from bossanova.internal.maths.family.links import (
                apply_link_inverse,
                apply_link_inverse_deriv,
            )

            estimates_link = X_ref @ fit.coef  # type: ignore[union-attr]
            estimates = np.asarray(apply_link_inverse(_link, estimates_link))
            d = np.asarray(apply_link_inverse_deriv(_link, estimates_link))
            link_name = _link
            L_matrix = d[:, np.newaxis] * X_ref

    # Build grid with compound level column
    grid = pl.DataFrame({focal_var: compound_level_names})

    # Build compound EMM MeeState
    compound_emm = build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=focal_var,
        focal_var=focal_var,
        mee_type="means",
        L_matrix=L_matrix,
        effect_scale=effect_scale,
        link=link_name,
    )

    # Apply bracket contrast
    return apply_bracket_contrasts(compound_emm, contrast_expr)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _expand_item(
    item: ContrastItem,
    levels: list[str],
    level_index: dict[str, int],
) -> list[tuple[list[str], list[str]]]:
    """Expand a contrast item, handling wildcards.

    Args:
        item: ContrastItem from the AST.
        levels: All factor levels.
        level_index: Level name to index mapping.

    Returns:
        List of ``(left_levels, right_levels)`` tuples. Normally one
        tuple; wildcard operands expand to multiple.

    Raises:
        ValueError: If both sides are wildcards, or a level is not found.
    """
    left = item.left
    right = item.right

    if left.is_wildcard and right.is_wildcard:
        raise ValueError("Both sides of a contrast cannot be wildcards")

    if left.is_wildcard:
        right_levels = _resolve_levels(right, levels, level_index)
        right_set = set(right_levels)
        return [([lv], right_levels) for lv in levels if lv not in right_set]

    if right.is_wildcard:
        left_levels = _resolve_levels(left, levels, level_index)
        left_set = set(left_levels)
        return [(left_levels, [lv]) for lv in levels if lv not in left_set]

    # No wildcards: resolve both sides directly
    left_levels = _resolve_levels(left, levels, level_index)
    right_levels = _resolve_levels(right, levels, level_index)
    return [(left_levels, right_levels)]


def _resolve_levels(
    operand: ContrastOperand,
    levels: list[str],
    level_index: dict[str, int],
) -> list[str]:
    """Resolve operand level names to validated level strings.

    Args:
        operand: ContrastOperand with level names.
        levels: Actual factor levels.
        level_index: Level name to index mapping.

    Returns:
        List of validated level names.

    Raises:
        ValueError: If any level name is not found in the factor levels.
    """
    result = []
    for lv in operand.levels:
        if lv in level_index:
            result.append(lv)
        else:
            raise ValueError(f"Level '{lv}' not found in variable levels: {levels}")
    return result


def _make_label(
    left_levels: list[str],
    right_levels: list[str],
    var: str,
) -> str:
    """Generate a human-readable label for a contrast row.

    Follows the same convention as named contrasts: prefix each level
    with the variable name (e.g., ``"DrugActive - DrugPlacebo"``).

    Args:
        left_levels: Positive-side level names.
        right_levels: Negative-side level names.
        var: Variable name prefix.

    Returns:
        Label string.
    """
    if len(left_levels) == 1:
        left_str = f"{var}{left_levels[0]}"
    else:
        left_str = "(" + " + ".join(f"{var}{lv}" for lv in left_levels) + ")"

    if len(right_levels) == 1:
        right_str = f"{var}{right_levels[0]}"
    else:
        right_str = "(" + " + ".join(f"{var}{lv}" for lv in right_levels) + ")"

    return f"{left_str} - {right_str}"


def _format_operand(operand: ContrastOperand) -> str:
    """Format a ContrastOperand as a string.

    Args:
        operand: ContrastOperand to format.

    Returns:
        Formatted string (e.g., ``"A"``, ``"(A + B)"``, ``"*"``).
    """
    if operand.is_wildcard:
        return "*"
    if len(operand.levels) == 1:
        return operand.levels[0]
    return "(" + " + ".join(operand.levels) + ")"


def _format_expr(expr: ContrastExpr) -> str:
    """Format a ContrastExpr as an explore formula string.

    Args:
        expr: ContrastExpr to format.

    Returns:
        Formatted string (e.g., ``"Drug[Active - Placebo]"``).
    """
    items_str = ", ".join(
        f"{_format_operand(item.left)} - {_format_operand(item.right)}"
        for item in expr.items
    )
    return f"{expr.var}[{items_str}]"


def dispatch_bracket_contrasts(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    contrast_expr: ContrastExpr,
    *,
    data: pl.DataFrame,
    spec: ModelSpec | None = None,
    effect_scale: str = "link",
    how: str = "mem",
    resolved: ResolvedConditions | None = None,
) -> MeeState:
    """Compute bracket contrast expression for a categorical focal variable.

    First computes EMMs, then applies the bracket contrast matrix.
    When ``resolved`` contains grid conditions, computes crossed EMMs
    and applies grouped bracket contrasts.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical variable.
        contrast_expr: ContrastExpr AST from the parser.
        data: Model data DataFrame.
        spec: ModelSpec with link info (for effect_scale="response").
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.
        how: Averaging method: ``"mem"`` or ``"ame"``.
        resolved: Resolved conditions for conditioning.

    Returns:
        MeeState with bracket contrast estimates.
    """
    from bossanova.internal.marginal.compute import compute_emm_categorical
    from bossanova.internal.marginal.emm import compute_emm_crossed

    if resolved is not None and resolved.has_grid:
        emm_state = compute_emm_crossed(
            bundle,
            fit,
            focal_var,
            resolved=resolved,
            spec=spec,
            effect_scale=effect_scale,
        )
        return apply_bracket_contrasts_grouped(emm_state, contrast_expr)

    at_overrides = resolved.at_overrides if resolved and resolved.at_overrides else None
    set_cats = (
        resolved.set_categoricals if resolved and resolved.set_categoricals else None
    )
    emm_state = compute_emm_categorical(
        bundle,
        fit,
        focal_var,
        at_overrides=at_overrides,
        set_categoricals=set_cats,
        spec=spec,
        effect_scale=effect_scale,
        how=how,
    )
    return apply_bracket_contrasts(emm_state, contrast_expr)
