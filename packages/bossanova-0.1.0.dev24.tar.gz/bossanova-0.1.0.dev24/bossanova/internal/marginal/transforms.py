"""Pure transform operations for result DataFrames.

Stateless functions that transform params/effects DataFrames.
Each function takes a DataFrame + context and returns a new DataFrame.
"""

import polars as pl

from bossanova.internal.containers.schemas import Col

__all__ = [
    "convert_to_effect_size",
    "convert_to_odds_ratio",
    "convert_to_response_scale",
    "filter_effects_dataframe",
]


def convert_to_odds_ratio(
    df: pl.DataFrame,
    family: str,
) -> pl.DataFrame:
    """Exponentiate estimates and CIs to odds ratio scale.

    Args:
        df: Params DataFrame with 'estimate' and optionally 'ci_lower', 'ci_upper'.
        family: Model family string (must be "binomial").

    Returns:
        DataFrame with exponentiated estimate/CI columns.

    Raises:
        ValueError: If family is not binomial.
    """
    if family != "binomial":
        raise ValueError(
            f"convert_to_odds_ratio() only valid for binomial family, got '{family}'."
        )

    cols_to_exp = [
        c for c in (Col.ESTIMATE, Col.CI_LOWER, Col.CI_UPPER) if c in df.columns
    ]
    return df.with_columns([pl.col(c).exp() for c in cols_to_exp])


def convert_to_response_scale(
    df: pl.DataFrame,
    link: str,
) -> pl.DataFrame:
    """Apply inverse link to transform estimates to response scale.

    Args:
        df: Effects DataFrame with 'estimate' and optionally 'ci_lower', 'ci_upper'.
        link: Link function name (e.g., "logit", "log").

    Returns:
        DataFrame with transformed columns on response scale.

    Raises:
        ValueError: If family is gaussian (already on response scale).
    """
    if link == "identity":
        raise ValueError(
            "convert_to_response_scale() not needed for identity link "
            "(estimates are already on response scale)."
        )

    import numpy as np

    from bossanova.internal.maths.family import apply_link_inverse

    cols = [c for c in (Col.ESTIMATE, Col.CI_LOWER, Col.CI_UPPER) if c in df.columns]

    return df.with_columns(
        [
            pl.col(c)
            .map_batches(
                lambda s, _link=link: pl.Series(
                    np.asarray(apply_link_inverse(_link, s.to_numpy()))
                ),
                return_dtype=pl.Float64,
            )
            .alias(c)
            for c in cols
        ]
    )


def convert_to_effect_size(
    df: pl.DataFrame,
    sigma: float | None,
    df_resid: float | None,
    family: str = "gaussian",
    *,
    include_intercept: bool = False,
) -> pl.DataFrame:
    """Compute standardized effect sizes from a params DataFrame.

    Computes:
    - **d** (Cohen's d): estimate / sigma
    - **r_semi** (semi-partial r): |t| / sqrt(t^2 + df_resid)
    - **eta_sq** (eta-squared): t^2 / (t^2 + df_resid)
    - **odds_ratio**: exp(estimate) for binomial only

    Args:
        df: Params DataFrame with 'term', 'estimate', optionally 'statistic',
            'ci_lower', 'ci_upper'.
        sigma: Residual standard deviation. None if unavailable.
        df_resid: Residual degrees of freedom. None if unavailable.
        family: Model family string.
        include_intercept: Whether to include intercept row.

    Returns:
        DataFrame with added effect size columns.
    """
    result = df.clone()

    if not include_intercept and Col.TERM in result.columns:
        result = result.filter(pl.col(Col.TERM) != "Intercept")

    # Cohen's d
    if sigma is not None and sigma > 0:
        result = result.with_columns(
            (pl.col(Col.ESTIMATE) / sigma).alias(Col.COHENS_D),
        )
        if Col.CI_LOWER in result.columns:
            result = result.with_columns(
                (pl.col(Col.CI_LOWER) / sigma).alias(Col.D_LOWER),
                (pl.col(Col.CI_UPPER) / sigma).alias(Col.D_UPPER),
            )
    else:
        result = result.with_columns(pl.lit(None).cast(pl.Float64).alias(Col.COHENS_D))
        if Col.CI_LOWER in result.columns:
            result = result.with_columns(
                pl.lit(None).cast(pl.Float64).alias(Col.D_LOWER),
                pl.lit(None).cast(pl.Float64).alias(Col.D_UPPER),
            )

    # Semi-partial r and eta-squared
    if Col.STATISTIC in result.columns and df_resid is not None and df_resid > 0:
        result = result.with_columns(
            (
                pl.col(Col.STATISTIC).abs()
                / (pl.col(Col.STATISTIC).pow(2) + df_resid).sqrt()
            ).alias(Col.R_SEMI),
            (
                pl.col(Col.STATISTIC).pow(2) / (pl.col(Col.STATISTIC).pow(2) + df_resid)
            ).alias(Col.ETA_SQ),
        )
    else:
        result = result.with_columns(
            pl.lit(None).cast(pl.Float64).alias(Col.R_SEMI),
            pl.lit(None).cast(pl.Float64).alias(Col.ETA_SQ),
        )

    # Odds ratio for binomial
    if family == "binomial":
        result = result.with_columns(
            pl.col(Col.ESTIMATE).exp().alias(Col.ODDS_RATIO),
        )

    return result


# =============================================================================
# Effects filtering
# =============================================================================

# Columns that are inference/statistic outputs, not grid columns.
_STAT_COLS: frozenset[str] = frozenset(
    {
        Col.ESTIMATE,
        Col.SE,
        Col.STATISTIC,
        Col.DF,
        Col.P_VALUE,
        Col.CI_LOWER,
        Col.CI_UPPER,
        Col.CONTRAST,
    }
)


def filter_effects_dataframe(
    df: pl.DataFrame,
    *,
    terms: list[str] | str | None = None,
    levels: list[str] | str | None = None,
    contrasts: list[str] | str | None = None,
) -> pl.DataFrame:
    """Filter an effects DataFrame by term, level, or contrast.

    Pure function that applies one or more filters to a marginal-effects
    DataFrame produced by the ``effects`` property.

    Args:
        df: Effects DataFrame (from ``model.effects``).
        terms: Term name(s) to keep (filters the ``term`` column).
        levels: Level name(s) to keep (filters the first grid column, i.e.
            the first column that is not a standard statistic column).
        contrasts: Contrast label(s) to keep (filters the ``contrast`` column).

    Returns:
        Filtered DataFrame containing only matching rows.

    Raises:
        ValueError: If ``contrasts`` is given but the DataFrame has no
            ``contrast`` column.
    """
    if terms is not None:
        if isinstance(terms, str):
            terms = [terms]
        if Col.TERM in df.columns:
            df = df.filter(pl.col(Col.TERM).is_in(terms))

    if levels is not None:
        if isinstance(levels, str):
            levels = [levels]
        grid_cols = [c for c in df.columns if c not in _STAT_COLS]
        if grid_cols:
            df = df.filter(pl.col(grid_cols[0]).cast(pl.Utf8).is_in(levels))

    if contrasts is not None:
        if isinstance(contrasts, str):
            contrasts = [contrasts]
        if Col.CONTRAST not in df.columns:
            raise ValueError(
                "Cannot filter by contrast: 'contrast' column not found. "
                "This result does not contain contrasts."
            )
        df = df.filter(pl.col(Col.CONTRAST).is_in(contrasts))

    return df
