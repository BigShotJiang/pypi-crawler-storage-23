"""Data bundle containers for model computation."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from attrs import field, frozen, validators

from bossanova.internal.containers.validators import (
    is_ndarray,
    is_optional_ndarray,
    is_optional_sparse_csc,
    to_tuple,
    to_tuple_of_tuples,
)

if TYPE_CHECKING:
    import scipy.sparse as sp
    from numpy.typing import NDArray


__all__ = [
    "DataBundle",
    "REInfo",
    "RankInfo",
]


# =============================================================================
# REInfo
# =============================================================================


@frozen
class REInfo:
    """Random effects metadata.

    Stores information about random effect grouping structure, including
    the grouping variables, number of groups per variable, and indices
    mapping observations to groups.

    Attributes:
        grouping_vars: Tuple of grouping variable names (e.g., ("subject", "item")).
        n_groups: Dictionary mapping grouping variable to number of groups.
        group_indices: Dictionary mapping grouping variable to group index array.
        term_names: Tuple of random effect term names (e.g., ("(1|subject)", "(1+time|subject)")).
        group_ids_list: List of group ID arrays for each factor (for PLS fitting).
        n_groups_list: List of number of groups per factor (for PLS fitting).
        re_structure: Random effects structure type
            (intercept/slope/diagonal/nested/crossed).
        random_names: Names of random effect terms (e.g., ["Intercept", "Days"]).
        X_re: Random effects covariates for slope models (optional).
        metadata: Dictionary with additional RE structure info for lambda_builder.

    Examples:
        >>> import numpy as np
        >>> from bossanova.internal.containers.structs.data import REInfo
        >>> meta = REInfo(
        ...     grouping_vars=["subject"],
        ...     n_groups={"subject": 10},
        ...     group_indices={"subject": np.array([0, 0, 1, 1, 2, 2])},
        ...     term_names=["(1|subject)"],
        ... )
        >>> meta.grouping_vars
        ('subject',)
    """

    grouping_vars: tuple[str, ...] = field(converter=to_tuple)
    n_groups: dict[str, int] = field(factory=dict)
    group_indices: dict[str, NDArray[np.intp]] = field(factory=dict, repr=False)
    term_names: tuple[str, ...] = field(converter=to_tuple, factory=tuple)
    # Extended fields for PLS fitting
    group_ids_list: list[NDArray[np.intp]] = field(factory=list, repr=False)
    n_groups_list: list[int] = field(factory=list)
    re_structure: str = field(default="intercept")
    random_names: list[str] = field(factory=list)
    X_re: NDArray[np.float64] | list[NDArray[np.float64]] | None = field(
        default=None, repr=False
    )
    metadata: dict = field(factory=dict)


# =============================================================================
# RankInfo
# =============================================================================


@frozen
class RankInfo:
    """Rank deficiency information for a design matrix.

    Stores the result of pivoted QR rank detection: which columns are
    numerically zero and should be dropped before fitting.

    Attributes:
        rank: Effective numerical rank of X.
        p: Original number of columns in X.
        kept_indices: Sorted indices of columns retained (length rank).
        dropped_indices: Indices of columns dropped as rank-deficient.
        dropped_names: Names of dropped columns.

    Examples:
        >>> from bossanova.internal.containers.structs.data import RankInfo
        >>> info = RankInfo(
        ...     rank=2, p=3,
        ...     kept_indices=np.array([0, 1]),
        ...     dropped_indices=(2,),
        ...     dropped_names=("x2",),
        ... )
        >>> info.is_deficient
        True
    """

    rank: int = field(validator=validators.instance_of(int))
    p: int = field(validator=validators.instance_of(int))
    kept_indices: NDArray[np.intp] = field(validator=is_ndarray)
    dropped_indices: tuple[int, ...] = field(converter=tuple)
    dropped_names: tuple[str, ...] = field(converter=tuple)

    @property
    def is_deficient(self) -> bool:
        """Whether the matrix is rank-deficient."""
        return self.rank < self.p


# =============================================================================
# DataBundle
# =============================================================================


@frozen
class DataBundle:
    """Validated model data (valid observations only).

    Contains design matrices, response vector, and metadata for model fitting.
    Only valid (non-NA) observations are included in X, y, and related arrays.
    The valid_mask tracks which rows from the original data were retained.

    Attributes:
        X: Fixed effects design matrix (n x p array).
        y: Response vector (1D array of length n).
        X_names: Tuple of column names for X (length p).
        y_name: Name of the response variable.
        valid_mask: Boolean mask indicating valid rows from original data.
        n_total: Original row count before NA removal.
        Z: Random effects design matrix (sparse csc_matrix, or None).
        weights: Observation weights (1D array or None).
        offset: Model offset (1D array or None).
        factor_levels: Dict mapping factor names to their level tuples.
        re_metadata: Random effects metadata (or None for fixed-effects models).

    Examples:
        >>> import numpy as np
        >>> from bossanova.internal.containers.structs.data import DataBundle
        >>> bundle = DataBundle(
        ...     X=np.array([[1, 0], [1, 1], [1, 2]]),
        ...     y=np.array([1.0, 2.0, 3.0]),
        ...     X_names=["Intercept", "x"],
        ...     y_name="y",
        ...     valid_mask=np.array([True, True, True]),
        ...     n_total=3,
        ... )
        >>> bundle.n
        3
        >>> bundle.p
        2
    """

    # Required fields
    X: NDArray[np.floating] = field(validator=is_ndarray)
    y: NDArray[np.floating] = field(validator=is_ndarray)
    X_names: tuple[str, ...] = field(converter=to_tuple)
    y_name: str = field(validator=validators.instance_of(str))

    valid_mask: NDArray[np.bool_] = field(validator=is_ndarray)
    n_total: int = field(validator=validators.instance_of(int))

    # Optional fields
    Z: sp.csc_matrix | None = field(default=None, validator=is_optional_sparse_csc)
    weights: NDArray[np.floating] | None = field(
        default=None, validator=is_optional_ndarray
    )
    offset: NDArray[np.floating] | None = field(
        default=None, validator=is_optional_ndarray
    )

    # Factor level info (preserved even after NA drop)
    factor_levels: dict[str, tuple[str, ...]] = field(
        factory=dict, converter=to_tuple_of_tuples
    )

    # Contrast type info (e.g., {"cyl": "treatment", "am": "sum"})
    contrast_types: dict[str, str] = field(factory=dict)

    # Random effects metadata
    re_metadata: REInfo | None = field(default=None)

    # Response level mapping for auto-encoded string responses (e.g. ("No", "Yes") means No→0, Yes→1)
    response_levels: tuple[str, ...] | None = field(default=None)

    # Rank deficiency info (None means full rank or not yet checked)
    rank_info: RankInfo | None = field(default=None)

    @property
    def n(self) -> int:
        """Number of valid observations.

        Returns:
            Number of rows in the design matrix X.
        """
        return self.X.shape[0]

    @property
    def p(self) -> int:
        """Number of fixed effect parameters.

        Returns:
            Number of columns in the design matrix X.
        """
        return self.X.shape[1]

    @property
    def has_random_effects(self) -> bool:
        """Whether the bundle includes random effects.

        Returns:
            True if Z matrix is present, False otherwise.
        """
        return self.Z is not None

    @property
    def rank(self) -> int:
        """Effective rank of the fixed effects design matrix.

        Returns:
            Numerical rank if rank_info is available, otherwise p (full rank).
        """
        return self.rank_info.rank if self.rank_info is not None else self.p
