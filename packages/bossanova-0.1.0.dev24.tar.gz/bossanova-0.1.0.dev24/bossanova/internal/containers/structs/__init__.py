"""Pure frozen data classes — zero logic beyond validation."""

from bossanova.internal.containers.structs.data import DataBundle, REInfo, RankInfo
from bossanova.internal.containers.structs.display import MathDisplay, TermInfo
from bossanova.internal.containers.structs.formula import FormulaSpec
from bossanova.internal.containers.structs.explore import (
    Condition,
    ExploreFormulaSpec,
    ExploreFormulaError,
)
from bossanova.internal.containers.structs.specs import (
    FAMILIES,
    FAMILY_DEFAULT_LINKS,
    LINKS,
    METHODS,
    Distribution,
    ModelSpec,
    SimulationSpec,
    VaryingSpec,
)
from bossanova.internal.containers.structs.state import (
    CVState,
    FitState,
    InferenceState,
    JointTestState,
    MeeState,
    PredictionState,
    ProfileState,
    ResamplesState,
    SimulationInferenceState,
    VaryingSpreadState,
    VaryingState,
)

__all__ = [
    "FAMILIES",
    "FAMILY_DEFAULT_LINKS",
    "LINKS",
    "METHODS",
    "CVState",
    "Condition",
    "DataBundle",
    "Distribution",
    "ExploreFormulaError",
    "ExploreFormulaSpec",
    "FitState",
    "FormulaSpec",
    "InferenceState",
    "JointTestState",
    "MathDisplay",
    "MeeState",
    "ModelSpec",
    "PredictionState",
    "ProfileState",
    "REInfo",
    "RankInfo",
    "ResamplesState",
    "SimulationInferenceState",
    "SimulationSpec",
    "TermInfo",
    "VaryingSpec",
    "VaryingSpreadState",
    "VaryingState",
]
