"""Builder functions for specification containers."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from bossanova.internal.containers.structs.specs import (
    Distribution,
    ModelSpec,
    SimulationSpec,
    VaryingSpec,
)
from bossanova.internal.containers.validators import convert_corr_to_dict

if TYPE_CHECKING:
    from bossanova.internal.formula.parse import FormulaStructure

__all__ = [
    "build_model_spec",
    "build_model_spec_from_formula",
    "build_simulation_spec",
    "build_simulation_spec_from_formula",
    "build_varying_spec",
    "get_varying_random_terms",
    "strip_backticks",
]


def strip_backticks(name: str) -> str:
    """Remove surrounding backtick quotes from a name.

    Args:
        name: A column name, possibly surrounded by backticks.

    Returns:
        The name with backticks stripped if present.
    """
    if name.startswith("`") and name.endswith("`") and len(name) > 1:
        return name[1:-1]
    return name


def get_varying_random_terms(spec: VaryingSpec) -> tuple[str, ...]:
    """Get all random terms (Intercept + slope terms) for a VaryingSpec.

    Args:
        spec: A VaryingSpec instance.

    Returns:
        Tuple of random term names, starting with "Intercept".
    """
    return ("Intercept",) + tuple(spec.slope_sds.keys())


def build_model_spec(
    formula: str,
    *,
    family: str = "gaussian",
    link: str | None = None,
    method: str | None = None,
    response_var: str | None = None,
    fixed_terms: tuple[str, ...] | list[str] | None = None,
    random_terms: tuple[str, ...] | list[str] | None = None,
    has_random_effects: bool | None = None,
) -> ModelSpec:
    """Build a ModelSpec from raw inputs.

    This factory function handles defaults, validation, and inference of
    missing fields. In a full implementation, formula parsing would extract
    response_var, fixed_terms, and random_terms automatically.

    Args:
        formula: The model formula string.
        family: Distribution family (default: "gaussian").
        link: Link function. If None, uses canonical link for family.
        method: Estimation method. If None, inferred from family and RE.
        response_var: Response variable name. Required if not parsed.
        fixed_terms: Fixed effect terms. Required if not parsed.
        random_terms: Random effect terms (default: empty tuple).
        has_random_effects: Whether model has RE. Inferred from random_terms.

    Returns:
        A validated ModelSpec instance.

    Raises:
        ValueError: If required fields are missing or invalid.

    Examples:
        >>> spec = build_model_spec(
        ...     formula="y ~ x + treatment",
        ...     response_var="y",
        ...     fixed_terms=["Intercept", "x", "treatment"],
        ... )
        >>> spec.method
        'ols'
    """
    if response_var is None:
        raise ValueError(
            "response_var is required. "
            "Formula parsing will provide this automatically in the future."
        )
    if fixed_terms is None:
        raise ValueError(
            "fixed_terms is required. "
            "Formula parsing will provide this automatically in the future."
        )

    fixed_terms_tuple = tuple(fixed_terms)
    random_terms_tuple = tuple(random_terms) if random_terms is not None else ()

    if has_random_effects is None:
        has_random_effects = len(random_terms_tuple) > 0

    if method is None:
        is_gaussian = family == "gaussian"
        if not has_random_effects:
            method = "ols" if is_gaussian else "ml"
        else:
            method = "reml" if is_gaussian else "ml"
    else:
        # Validate user-specified method
        is_gaussian = family == "gaussian"
        if method == "ols" and (not is_gaussian or has_random_effects):
            raise ValueError("method='ols' only valid for gaussian without RE")
        if method == "reml" and not (is_gaussian and has_random_effects):
            raise ValueError("method='reml' only valid for gaussian with RE")

    kwargs: dict = {
        "formula": formula,
        "family": family,
        "has_random_effects": has_random_effects,
        "method": method,
        "response_var": response_var,
        "fixed_terms": fixed_terms_tuple,
        "random_terms": random_terms_tuple,
    }
    if link is not None:
        kwargs["link"] = link

    return ModelSpec(**kwargs)


def build_model_spec_from_formula(
    formula: str,
    *,
    family: str = "gaussian",
    link: str | None = None,
    method: str | None = None,
    structure: FormulaStructure,
) -> ModelSpec:
    """Build ModelSpec from a pre-parsed formula structure and resolve defaults.

    The caller must parse the formula into a ``FormulaStructure`` first
    (via ``extract_formula_structure``).  This keeps ``containers/`` free
    of imports from ``formula/``.

    Args:
        formula: R-style model formula (e.g., ``"y ~ x + (1|group)"``).
        family: Distribution family (default: ``"gaussian"``).
        link: Link function. If None, uses canonical link for family.
        method: Estimation method. If None, inferred from family and RE
            presence. Validated against family/RE constraints if specified.
        structure: Pre-parsed formula structure from
            ``extract_formula_structure(formula)``.

    Returns:
        A validated ModelSpec instance.

    Raises:
        ValueError: If formula is invalid or method is incompatible.

    Examples:
        >>> from bossanova.internal.formula.parse import extract_formula_structure
        >>> s = extract_formula_structure("y ~ x + treatment")
        >>> spec = build_model_spec_from_formula("y ~ x + treatment", structure=s)
        >>> spec.method
        'ols'
    """
    if "~" not in formula:
        raise ValueError(f"Invalid formula: {formula!r}. Formula must contain '~'.")

    if structure.response_var is None:
        raise ValueError(
            f"Invalid formula: {formula!r}. No response variable specified."
        )

    return build_model_spec(
        formula=formula,
        family=family,
        link=link,
        method=method,
        has_random_effects=structure.has_random_effects,
        response_var=strip_backticks(structure.response_var),
        fixed_terms=structure.fixed_term_names,
        random_terms=structure.random_terms_raw,
    )


def build_varying_spec(
    n: int,
    sd: float = 1.0,
    *,
    slope_sds: dict[str, float] | None = None,
    correlations: dict[tuple[str, str], float] | None = None,
    n_per: int | None = None,
) -> VaryingSpec:
    """Build a VaryingSpec for random effect structure.

    Args:
        n: Number of groups.
        sd: Standard deviation for random intercept.
        slope_sds: Dictionary of term -> slope SD mappings.
        correlations: Dictionary of (term1, term2) -> correlation mappings.
        n_per: Number of units per group for nested effects.

    Returns:
        VaryingSpec instance.

    Examples:
        >>> spec = build_varying_spec(n=50, sd=0.3)
    """
    return VaryingSpec(
        n=n,
        sd=sd,
        slope_sds=slope_sds or {},
        correlations=correlations or {},
        n_per=n_per,
    )


def build_simulation_spec(
    n: int,
    *,
    distributions: dict[str, Distribution] | None = None,
    coef: dict[str, float] | None = None,
    sigma: float = 1.0,
    re_spec: dict[str, VaryingSpec] | None = None,
    seed: int | None = None,
) -> SimulationSpec:
    """Build a SimulationSpec for data generation.

    Args:
        n: Total number of observations.
        distributions: Variable name -> Distribution mappings.
        coef: Coefficient name -> value mappings.
        sigma: Residual standard deviation.
        re_spec: Grouping variable -> VaryingSpec mappings.
        seed: Random seed for reproducibility.

    Returns:
        SimulationSpec instance.

    Examples:
        >>> spec = build_simulation_spec(n=100)
    """
    return SimulationSpec(
        n=n,
        distributions=distributions or {},
        coef=coef or {},
        sigma=sigma,
        re_spec=re_spec or {},
        seed=seed,
    )


# =============================================================================
# Formula-Based Builder
# =============================================================================


_CONTRAST_FUNC_RE = (
    r"(?:treatment|dummy|sum|deviation|helmert|sequential|poly)\((\w+)(?:,\s*[^)]+)?\)"
)


def parse_formula_simple(formula: str) -> dict[str, Any]:
    """Simple formula parser for simulation defaults.

    Parses a model formula to extract variable types for default distributions.
    Recognizes contrast encoding functions (``treatment(x)``, ``sum(x)``, etc.)
    as categorical markers.

    Args:
        formula: Model formula (e.g., ``"y ~ x + treatment(group) + (1|subject)"``).

    Returns:
        Dictionary with keys: response, continuous, factors, re_groups.

    Examples:
        >>> parse_formula_simple("y ~ x + z")
        {'response': 'y', 'continuous': ['x', 'z'], 'factors': [], 're_groups': []}
        >>> parse_formula_simple("y ~ treatment(group) + x")
        {'response': 'y', 'continuous': ['x'], 'factors': ['group'], 're_groups': []}
    """
    if "~" not in formula:
        msg = f"Invalid formula: missing '~'. Got: {formula}"
        raise ValueError(msg)

    parts = formula.split("~", 1)
    lhs = parts[0].strip()
    rhs = parts[1].strip() if len(parts) > 1 else ""

    response = lhs.strip()
    if not response:
        msg = f"Invalid formula: empty response variable. Got: {formula}"
        raise ValueError(msg)

    factors = re.findall(_CONTRAST_FUNC_RE, rhs)
    re_groups = re.findall(r"\([^)]+\|(\w+)\)", rhs)

    cleaned = re.sub(_CONTRAST_FUNC_RE, "", rhs)
    cleaned = re.sub(r"\([^)]+\|\w+\)", "", cleaned)

    all_terms = re.findall(r"\b([a-zA-Z_]\w*)\b", cleaned)

    excluded = {"Intercept", "1"} | set(factors)
    continuous = [t for t in all_terms if t not in excluded]

    continuous = list(dict.fromkeys(continuous))
    factors = list(dict.fromkeys(factors))
    re_groups = list(dict.fromkeys(re_groups))

    return {
        "response": response,
        "continuous": continuous,
        "factors": factors,
        "re_groups": re_groups,
    }


def build_simulation_spec_from_formula(
    formula: str,
    n: int,
    *,
    distributions: dict[str, Distribution] | None = None,
    coef: dict[str, float] | None = None,
    sigma: float = 1.0,
    seed: int | None = None,
) -> SimulationSpec:
    """Build SimulationSpec from formula with defaults for unspecified variables.

    Parses the formula to identify variable types and creates appropriate
    default distributions for variables not explicitly specified.

    Args:
        formula: Model formula (e.g., "y ~ x + factor(group) + (1|subject)").
        n: Number of observations to generate.
        distributions: User-provided distributions for specific variables.
        coef: True coefficient values (defaults to all zeros).
        sigma: Residual standard deviation.
        seed: Random seed.

    Returns:
        SimulationSpec ready for data generation.

    Raises:
        ValueError: If random effect grouping variable lacks varying() spec.

    Examples:
        >>> spec = build_simulation_spec_from_formula("y ~ x + factor(group)", n=100)
        >>> spec.n
        100
    """
    from bossanova.distributions import Varying, categorical, normal

    parsed = parse_formula_simple(formula)

    defaults: dict[str, Distribution] = {}
    for var in parsed["continuous"]:
        defaults[var] = normal(0, 1)
    for var in parsed["factors"]:
        defaults[var] = categorical(k=2)

    user_dists = distributions or {}
    for name, dist in user_dists.items():
        if not isinstance(dist, (Distribution, Varying)):
            raise TypeError(
                f"Invalid distribution for '{name}': expected a Distribution "
                f"(e.g., normal(), categorical()) or varying(), "
                f"got {type(dist).__name__}"
            )

    final_dists: dict[str, Distribution] = {**defaults, **user_dists}

    re_spec: dict[str, VaryingSpec] = {}

    for var in parsed["re_groups"]:
        if var not in final_dists:
            msg = (
                f"Random effect grouping variable '{var}' requires varying() specification. "
                f"Example: distributions={{'{var}': varying(n=50, sd=0.3)}}"
            )
            raise ValueError(msg)

        dist = final_dists[var]
        if not isinstance(dist, Varying):
            msg = (
                f"Random effect grouping variable '{var}' must use varying(), "
                f"got {type(dist).__name__}"
            )
            raise ValueError(msg)

        re_spec[var] = VaryingSpec(
            n=dist.n if dist.n is not None else 1,
            sd=dist.effective_intercept_sd,
            slope_sds=dict(dist.slope_sds),
            correlations=convert_corr_to_dict(dist.corr, dist.slope_sds),
            n_per=dist.n_per,
        )

        del final_dists[var]

    return SimulationSpec(
        n=n,
        distributions=final_dists,
        coef=coef or {},
        sigma=sigma,
        re_spec=re_spec,
        seed=seed,
    )
