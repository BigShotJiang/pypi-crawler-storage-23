"""DataFrame builders for user-facing property accessors.

Pure functions that assemble Polars DataFrames from internal state
containers. Each builder corresponds to a model property (``.params``,
``.effects``, etc.) and contains only the DataFrame construction logic
that was previously inlined in core.py property methods.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import polars as pl

from bossanova.internal.containers.builders.results import (
    append_inference_columns,
)
from bossanova.internal.containers.schemas import (
    Col,
    ParamsAsymp,
    ParamsBase,
    ParamsBoot,
    ParamsCv,
    ParamsPerm,
    VaryingCorrSchema,
)

if TYPE_CHECKING:
    from bossanova.internal.containers.structs import (
        DataBundle,
        FitState,
        InferenceState,
        JointTestState,
        MeeState,
        PredictionState,
        SimulationInferenceState,
        VaryingSpreadState,
        VaryingState,
    )

__all__ = [
    "build_effects_dataframe",
    "build_joint_test_dataframe",
    "build_params_dataframe",
    "build_predictions_dataframe",
    "build_simulations_dataframe",
    "build_varying_corr_dataframe",
    "build_varying_offsets_dataframe",
    "build_varying_params_dataframe",
    "build_varying_spread_dataframe",
]


def build_params_dataframe(
    bundle: DataBundle,
    fit: FitState,
    params_inference: InferenceState | None,
) -> pl.DataFrame:
    """Build the ``.params`` DataFrame from fit state.

    Column set varies by inference method:

    - **asymp**: all inference columns (p_value last).
    - **boot**: all inference columns; df = n_resamples.
    - **perm**: no CIs; df = n_valid_resamples.
    - **cv**: PRE columns only.
    - **None**: term + estimate only.

    Args:
        bundle: Data bundle containing ``X_names`` (coefficient labels).
        fit: Fit state containing ``coef`` (coefficient estimates).
        params_inference: Optional inference state with SE, CI, p-values.

    Returns:
        DataFrame with ``term``, ``estimate``, and method-appropriate
        inference columns.
    """
    terms = list(bundle.X_names)
    estimates = fit.coef.tolist()

    data: dict[str, list] = {Col.TERM: terms, Col.ESTIMATE: estimates}

    if params_inference is None:
        return pl.DataFrame(data, schema=ParamsBase)

    method = params_inference.method

    if method == "cv":
        data[Col.PRE] = params_inference.pre.tolist()
        data[Col.PRE_SD] = params_inference.pre_sd.tolist()
        return pl.DataFrame(data, schema=ParamsCv)

    if method == "boot":
        data[Col.SE] = params_inference.se.tolist()
        data[Col.CI_LOWER] = params_inference.ci_lower.tolist()
        data[Col.CI_UPPER] = params_inference.ci_upper.tolist()
        data[Col.STATISTIC] = params_inference.statistic.tolist()
        data[Col.DF] = params_inference.df.tolist()
        data[Col.P_VALUE] = params_inference.p_value.tolist()
        return pl.DataFrame(data, schema=ParamsBoot)

    if method == "perm":
        data[Col.SE] = params_inference.se.tolist()
        data[Col.STATISTIC] = params_inference.statistic.tolist()
        data[Col.DF] = params_inference.df.tolist()
        data[Col.P_VALUE] = params_inference.p_value.tolist()
        return pl.DataFrame(data, schema=ParamsPerm)

    # Default: asymptotic (or any unknown method)
    data[Col.SE] = params_inference.se.tolist()
    data[Col.CI_LOWER] = params_inference.ci_lower.tolist()
    data[Col.CI_UPPER] = params_inference.ci_upper.tolist()
    data[Col.STATISTIC] = params_inference.statistic.tolist()
    data[Col.DF] = params_inference.df.tolist()
    data[Col.P_VALUE] = params_inference.p_value.tolist()
    return pl.DataFrame(data, schema=ParamsAsymp)


def build_varying_offsets_dataframe(
    varying_offsets: VaryingState,
) -> pl.DataFrame:
    """Build the ``.varying_offsets`` DataFrame from varying state.

    Args:
        varying_offsets: Varying state with grid, effects, and optional PIs.

    Returns:
        DataFrame with ``group``, ``level``, effect columns, and optional
        prediction interval columns.
    """
    result = varying_offsets.grid.clone()

    for effect_name, values in varying_offsets.effects.items():
        result = result.with_columns(pl.Series(effect_name, values))

    if varying_offsets.has_inference and varying_offsets.pi_lower is not None:
        for effect_name in varying_offsets.effects:
            if effect_name in varying_offsets.pi_lower:
                result = result.with_columns(
                    pl.Series(
                        f"{Col.PI_LOWER_PREFIX}{effect_name}",
                        varying_offsets.pi_lower[effect_name],
                    ),
                    pl.Series(
                        f"{Col.PI_UPPER_PREFIX}{effect_name}",
                        varying_offsets.pi_upper[effect_name],
                    ),
                )

    return result


def build_varying_params_dataframe(
    bundle: DataBundle,
    fit: FitState,
    varying_offsets: VaryingState,
) -> pl.DataFrame:
    """Build the ``.varying_params`` DataFrame (population + offsets).

    Args:
        bundle: Data bundle containing ``X_names`` for population param lookup.
        fit: Fit state containing ``coef`` (population coefficients).
        varying_offsets: Varying state with grid and per-group effects.

    Returns:
        DataFrame with ``group``, ``level``, and effect columns where each
        value is ``population_param + BLUP``.
    """
    params_dict = dict(zip(bundle.X_names, fit.coef.tolist()))

    result = varying_offsets.grid.clone()

    for effect_name, values in varying_offsets.effects.items():
        pop_value = params_dict.get(effect_name, 0.0)
        combined = values + pop_value
        result = result.with_columns(pl.Series(effect_name, combined))

    return result


def build_varying_spread_dataframe(
    varying_spread: VaryingSpreadState,
) -> pl.DataFrame:
    """Build the ``.varying_spread`` DataFrame from variance components.

    Args:
        varying_spread: Variance component state with components DataFrame
            and optional CI information.

    Returns:
        DataFrame with ``component``, ``estimate``, and optional
        ``ci_lower``, ``ci_upper``, ``ci_method`` columns.
    """
    result = varying_spread.components.clone()

    if varying_spread.has_inference:
        ci_lower_vals = []
        ci_upper_vals = []
        ci_method_vals = []

        for comp_name in result[Col.COMPONENT].to_list():
            ci_lower_vals.append(varying_spread.ci_lower.get(comp_name, float("nan")))
            ci_upper_vals.append(varying_spread.ci_upper.get(comp_name, float("nan")))
            ci_method_vals.append(varying_spread.ci_method or "")

        result = result.with_columns(
            pl.Series(Col.CI_LOWER, ci_lower_vals),
            pl.Series(Col.CI_UPPER, ci_upper_vals),
            pl.Series(Col.CI_METHOD, ci_method_vals),
        )

    return result


def build_varying_corr_dataframe(
    varying_spread: VaryingSpreadState,
) -> pl.DataFrame:
    """Build the ``.varying_corr`` DataFrame from random effect correlations.

    Extracts correlation entries from the VaryingSpreadState ``rho`` dict
    into a tidy DataFrame. Returns an empty DataFrame (with the correct
    schema) when no correlations are present (e.g., intercept-only or
    diagonal RE structures).

    Args:
        varying_spread: Variance component state containing ``rho``
            (dict mapping ``"effect1_effect2"`` keys to correlation values).

    Returns:
        DataFrame with columns ``group``, ``effect1``, ``effect2``, ``corr``.
    """
    groups: list[str] = []
    effect1s: list[str] = []
    effect2s: list[str] = []
    corrs: list[float] = []

    for key, value in varying_spread.rho.items():
        # rho keys follow "effect1_effect2" naming from varying.py
        # which uses rho_key = corr_part.replace(":", "_")
        # where corr_part = "Intercept:Days" -> key = "Intercept_Days"
        parts = key.split("_", 1)
        if len(parts) == 2:
            effect1s.append(parts[0])
            effect2s.append(parts[1])
        else:
            effect1s.append(key)
            effect2s.append(key)
        # Extract group name from tau2 keys in spread state
        # The group is the prefix before ":" in tau2 keys
        group = _infer_group_from_spread(varying_spread)
        groups.append(group)
        corrs.append(value)

    return pl.DataFrame(
        {
            Col.GROUP: groups,
            Col.EFFECT1: effect1s,
            Col.EFFECT2: effect2s,
            Col.CORR: corrs,
        },
        schema=VaryingCorrSchema,
    )


def _infer_group_from_spread(varying_spread: VaryingSpreadState) -> str:
    """Infer the grouping variable name from VaryingSpreadState tau2 keys.

    Args:
        varying_spread: Variance component state with tau2 dict.

    Returns:
        The grouping variable name, or ``""`` if not determinable.
    """
    for key in varying_spread.tau2:
        if ":" in key:
            return key.split(":")[0]
    return ""


def build_effects_dataframe(
    mee: MeeState,
    method: str | None = None,
) -> pl.DataFrame:
    """Build the ``.effects`` DataFrame from marginal effects state.

    Column set varies by inference method: bootstrap excludes ``p_value``,
    permutation excludes ``ci_lower``/``ci_upper``.

    Args:
        mee: MeeState with grid, estimates, and optional inference.
        method: Inference method (``"asymp"``, ``"boot"``, ``"perm"``,
            or ``None``). Controls which inference columns are included.

    Returns:
        DataFrame with grid columns, ``estimate``, and method-appropriate
        inference columns.
    """
    result = mee.grid.clone()
    result = result.with_columns(pl.Series(Col.ESTIMATE, mee.estimate))
    return append_inference_columns(result, mee, method=method)


def build_joint_test_dataframe(state: JointTestState) -> pl.DataFrame:
    """Build an ANOVA-style DataFrame from joint test results.

    Args:
        state: JointTestState with terms, df, statistics, and p-values.

    Returns:
        DataFrame with ``term``, ``df1``, optional ``df2``,
        ``f_ratio`` or ``Chisq``, and ``p_value`` columns.
    """
    result = pl.DataFrame({Col.TERM: list(state.terms)})
    result = result.with_columns(pl.Series(Col.DF1, state.df1))

    if state.df2 is not None:
        result = result.with_columns(pl.Series(Col.DF2, state.df2))

    stat_name = Col.F_RATIO if state.test_type == "F" else Col.CHISQ
    result = result.with_columns(pl.Series(stat_name, state.statistic))
    result = result.with_columns(pl.Series(Col.P_VALUE, state.p_value))

    return result


def build_predictions_dataframe(pred: PredictionState) -> pl.DataFrame:
    """Build the ``.predictions`` DataFrame from prediction state.

    Args:
        pred: Prediction state with fitted values and optional link-scale,
            inference, and CV columns.

    Returns:
        DataFrame with ``fitted``, optional ``link``, inference columns,
        and optional CV columns.
    """
    data: dict[str, list] = {Col.FITTED: pred.fitted.tolist()}
    if pred.link is not None:
        data[Col.LINK] = pred.link.tolist()
    result = pl.DataFrame(data)

    result = append_inference_columns(result, pred)

    if pred.has_cv:
        result = result.with_columns(
            pl.Series(Col.CV_FITTED, pred.cv_fitted),
            pl.Series(Col.CV_RESIDUAL, pred.cv_residual),
            pl.Series(Col.CV_FOLD, pred.cv_fold),
        )

    return result


def build_simulations_dataframe(
    simulations: pl.DataFrame,
    sim_inference: SimulationInferenceState | None,
) -> pl.DataFrame:
    """Build the ``.simulations`` DataFrame with optional inference columns.

    Args:
        simulations: Base simulations DataFrame (generated data or sim columns).
        sim_inference: Optional simulation inference state with summary stats.

    Returns:
        DataFrame with simulation data and optional ``sim_mean``, ``sim_sd``,
        and quantile columns.
    """
    result = simulations.clone()

    if sim_inference is not None:
        if sim_inference.sim_mean is not None:
            result = result.with_columns(
                pl.Series(Col.SIM_MEAN, sim_inference.sim_mean)
            )
        if sim_inference.sim_sd is not None:
            result = result.with_columns(pl.Series(Col.SIM_SD, sim_inference.sim_sd))
        for q_name, q_values in sim_inference.sim_quantiles.items():
            result = result.with_columns(pl.Series(q_name, q_values))

    return result
