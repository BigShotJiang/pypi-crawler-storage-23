"""Shared validators and converters for container attrs classes."""

from __future__ import annotations

from typing import Any

import numpy as np


__all__ = [
    "convert_corr_to_dict",
    "is_ndarray",
    "is_optional_ndarray",
    "is_optional_sparse_csc",
    "normalize_conf_level",
    "to_factor_dict",
    "to_frozen_dict",
    "to_tuple",
    "to_tuple_of_tuples",
    "validate_correlations",
    "validate_sigma",
    "validate_slope_sds",
]


# =============================================================================
# Type validators (attrs validator protocol)
# =============================================================================


def is_ndarray(instance: object, attribute: object, value: object) -> None:
    """Validate that a value is a numpy ndarray."""
    if not isinstance(value, np.ndarray):
        raise TypeError(
            f"{attribute.name} must be a numpy ndarray, "  # type: ignore[union-attr]
            f"got {type(value).__name__}"
        )


def is_optional_ndarray(instance: object, attribute: object, value: object) -> None:
    """Validate that a value is a numpy ndarray or None."""
    if value is not None and not isinstance(value, np.ndarray):
        raise TypeError(
            f"{attribute.name} must be a numpy ndarray or None, "  # type: ignore[union-attr]
            f"got {type(value).__name__}"
        )


def is_optional_sparse_csc(instance: object, attribute: object, value: object) -> None:
    """Validate that a value is a scipy.sparse.csc_matrix or None."""
    if value is None:
        return
    import scipy.sparse as sp_module

    if not isinstance(value, sp_module.csc_matrix):
        raise TypeError(
            f"{attribute.name} must be a scipy.sparse.csc_matrix or None, "  # type: ignore[union-attr]
            f"got {type(value).__name__}"
        )


# =============================================================================
# Converters (attrs converter protocol)
# =============================================================================


def to_tuple(value: tuple[str, ...] | list[str]) -> tuple[str, ...]:
    """Convert list to tuple for immutability."""
    return tuple(value)


def to_tuple_of_tuples(
    value: dict[str, tuple[str, ...] | list[str]] | None,
) -> dict[str, tuple[str, ...]]:
    """Convert dict values to tuples for immutability."""
    if value is None:
        return {}
    return {k: tuple(v) for k, v in value.items()}


def to_frozen_dict(val: Any) -> dict:
    """Ensure dict values are tuples where applicable."""
    if val is None:
        return {}
    return dict(val)


def to_factor_dict(val: Any) -> dict[str, tuple[str, ...]]:
    """Convert factor dict values from lists to tuples."""
    if val is None:
        return {}
    return {k: tuple(v) if not isinstance(v, tuple) else v for k, v in val.items()}


# =============================================================================
# Parameter normalizers
# =============================================================================


def normalize_conf_level(conf_level: float | int | str) -> float:
    """Normalize conf_level to a float in (0, 1).

    Accepts multiple formats for user convenience:
        - Float in (0, 1): returned as-is (e.g. 0.95)
        - Int or float in (1, 100): divided by 100 (e.g. 95 -> 0.95)
        - String with optional ``%`` suffix: parsed and normalized
          (e.g. ``"95%"`` -> 0.95, ``"0.95"`` -> 0.95)

    Args:
        conf_level: Confidence level in any supported format.

    Returns:
        Confidence level as a float strictly between 0 and 1 (exclusive).

    Raises:
        ValueError: If the value is out of range or unparseable.
        TypeError: If the value is not a float, int, or str.
    """
    # --- String handling ---
    if isinstance(conf_level, str):
        cleaned = conf_level.strip().rstrip("%").strip()
        try:
            numeric = float(cleaned)
        except ValueError:
            msg = (
                f"Cannot parse conf_level={conf_level!r} as a number. "
                "Expected a numeric value like 0.95, 95, or '95%'."
            )
            raise ValueError(msg) from None
        return normalize_conf_level(numeric)

    # --- Numeric handling ---
    if not isinstance(conf_level, (int, float)):
        msg = (
            f"conf_level must be a float, int, or str, got {type(conf_level).__name__}"
        )
        raise TypeError(msg)

    value = float(conf_level)

    # Already in (0, 1)
    if 0 < value < 1:
        return value

    # In (1, 100) exclusive — interpret as percentage
    if 1 < value < 100:
        return value / 100.0

    # Boundary and out-of-range cases
    if value <= 0 or value >= 100:
        msg = (
            f"conf_level={conf_level!r} is out of range. "
            "Expected a value in (0, 1) or (1, 100)."
        )
        raise ValueError(msg)

    # value == 1: ambiguous — could be 100% or 1%
    # Treat as 100% which is invalid (not strictly between 0 and 1)
    msg = "conf_level=1 is ambiguous (100% or 1%). Use 0.99 for 99% or 0.01 for 1%."
    raise ValueError(msg)


# =============================================================================
# Domain validators (attrs validator protocol)
# =============================================================================


def validate_correlations(
    instance: Any, attribute: Any, value: dict[tuple[str, str], float]
) -> None:
    """Validate correlation values are in [-1, 1]."""
    for (term1, term2), corr in value.items():
        if not -1.0 <= corr <= 1.0:
            msg = (
                f"Correlation between '{term1}' and '{term2}' must be in [-1, 1], "
                f"got {corr}"
            )
            raise ValueError(msg)


def validate_slope_sds(instance: Any, attribute: Any, value: dict[str, float]) -> None:
    """Validate slope SDs are non-negative."""
    for term, sd in value.items():
        if sd < 0:
            msg = f"Slope SD for '{term}' must be non-negative, got {sd}"
            raise ValueError(msg)


def validate_sigma(instance: Any, attribute: Any, value: float) -> None:
    """Validate sigma is non-negative."""
    if value < 0:
        msg = f"sigma must be non-negative, got {value}"
        raise ValueError(msg)


# =============================================================================
# Data transformers
# =============================================================================


def convert_corr_to_dict(
    corr: float | dict[tuple[str, str], float],
    slope_sds: dict[str, float],
) -> dict[tuple[str, str], float]:
    """Convert correlation specification to dictionary format.

    Args:
        corr: Correlation as single value or dict.
        slope_sds: Dictionary of slope SDs (to determine term names).

    Returns:
        Dictionary mapping term pairs to correlations.
    """
    if isinstance(corr, dict):
        return dict(corr)

    if not slope_sds:
        return {}

    result: dict[tuple[str, str], float] = {}
    for term in slope_sds:
        result[("Intercept", term)] = corr

    return result
