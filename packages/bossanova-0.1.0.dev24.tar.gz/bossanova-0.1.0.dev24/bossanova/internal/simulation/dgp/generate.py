"""Predictor generation utilities for DGP functions.

Provides helper functions to generate predictor values from
Distribution specifications.
"""

from __future__ import annotations

from typing import Any

__all__ = [
    "generate_predictors",
]

import numpy as np


def generate_predictors(
    distributions: dict[str, Any],
    n: int,
    rng: np.random.Generator,
) -> dict[str, np.ndarray]:
    """Generate predictor values from distribution specifications.

    Args:
        distributions: Mapping of variable name to Distribution object.
            Supported types: Normal, Uniform, Categorical, Exponential, Gamma, T.
        n: Number of observations.
        rng: NumPy random number generator.

    Returns:
        Dict mapping variable names to arrays.

    Examples:
        >>> from bossanova.distributions import normal, categorical
        >>> import numpy as np
        >>> rng = np.random.default_rng(42)
        >>> result = generate_predictors(
        ...     {"x": normal(0, 2), "group": categorical(["A", "B"])},
        ...     n=10,
        ...     rng=rng,
        ... )
        >>> result["x"].shape
        (10,)
        >>> set(result["group"]).issubset({"A", "B"})
        True
    """
    result: dict[str, np.ndarray] = {}
    for name, dist in distributions.items():
        result[name] = dist.sample(n, rng)
    return result
