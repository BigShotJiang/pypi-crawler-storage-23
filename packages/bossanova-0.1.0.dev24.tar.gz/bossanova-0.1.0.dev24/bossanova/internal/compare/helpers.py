"""Shared helpers for model comparison.

Provides validation, sorting, nesting checks, and method inference
used across all comparison strategies (F-test, deviance, LRT, CV).
"""

from __future__ import annotations

from typing import Any

__all__ = [
    "check_nested",
    "get_model_type",
    "resolve_method",
    "sort_models_by_complexity",
    "validate_models",
]


# =============================================================================
# Model Type Helper
# =============================================================================


def get_model_type(model: Any) -> str:
    """Get the model type string for a fitted model.

    Args:
        model: A fitted model instance.

    Returns:
        Model type: 'lm', 'glm', 'lmer', or 'glmer'.
    """
    return model._model_type


# =============================================================================
# Validation and Sorting Helpers
# =============================================================================


def validate_models(
    models: tuple[Any, ...], method: str = "auto", refit: bool = False
) -> tuple[Any, ...]:
    """Validate that models can be compared, auto-fitting if needed.

    Checks:
    - At least 2 models provided
    - All models are fitted (auto-fits unfitted models)
    - All models are the same type
    - All models have the same response variable
    - All models have the same number of observations
    - For LRT: All models use ML estimation (not REML), unless refit=True
      or all models share the same fixed effects (REML LRT is valid for
      comparing random effects structures with identical fixed effects)

    Args:
        models: Tuple of model objects (fitted or unfitted).
        method: Comparison method (used to check REML for LRT).
        refit: If True, skip REML validation (models will be refitted).

    Returns:
        Tuple of fitted model objects.

    Raises:
        ValueError: If validation fails.
    """
    if len(models) < 2:
        raise ValueError("compare() requires at least 2 models")

    # Auto-fit unfitted models (mutates in place)
    for m in models:
        if not getattr(m, "_is_fitted", False):
            m.fit()

    # Check same type
    model_types = [get_model_type(m) for m in models]
    if len(set(model_types)) > 1:
        raise ValueError(
            f"All models must be the same type. Got: {', '.join(model_types)}"
        )

    # Check same response
    responses = [m._spec.response_var for m in models]
    if len(set(responses)) > 1:
        raise ValueError(
            f"All models must have the same response variable. Got: {', '.join(responses)}"
        )

    # Check same n observations
    n_obs = [m._bundle.n for m in models]
    if len(set(n_obs)) > 1:
        raise ValueError(
            f"All models must have the same number of observations. Got: {n_obs}"
        )

    # For LRT, check that all models use ML estimation (unless refit=True)
    model_type = model_types[0]
    inferred_method = method if method != "auto" else resolve_method(models[0])

    if inferred_method == "lrt" and model_type in ("lmer", "glmer") and not refit:
        methods = [m._spec.method for m in models]
        reml_models = [m for m, meth in zip(models, methods) if meth == "reml"]
        if reml_models:
            # REML LRT is valid when all models share the same fixed effects
            # and differ only in random effects structure (see lme4 docs).
            fixed_terms_sets = [set(m._spec.fixed_terms) for m in models]
            same_fixed = all(ft == fixed_terms_sets[0] for ft in fixed_terms_sets)
            if not same_fixed:
                raise ValueError(
                    "LRT requires ML estimation when models have different "
                    "fixed effects, but some models use REML. "
                    "Refit models with method='ml' for valid likelihood ratio "
                    "comparison, or use compare(..., refit=True) to auto-refit. "
                    f"Resolved methods: {methods}"
                )

    return models


def sort_models_by_complexity(models: tuple[Any, ...]) -> list[Any]:
    """Sort models from simplest (fewest parameters) to most complex.

    This matches R's anova() behavior which orders models by df.

    Args:
        models: Tuple of fitted model objects.

    Returns:
        List of models sorted by number of parameters (ascending).
    """

    def get_total_params(m: Any) -> int:
        """Get total parameter count for sorting."""
        model_type = get_model_type(m)
        n_fixed = m._bundle.p
        if model_type == "lmer":
            # Fixed effects + theta + sigma
            return n_fixed + len(m._fit.theta) + 1
        elif model_type == "glmer":
            # Fixed effects + theta (no sigma)
            return n_fixed + len(m._fit.theta)
        else:
            # lm/glm: just fixed effects
            return n_fixed

    return sorted(models, key=get_total_params)


def resolve_method(model: Any) -> str:
    """Infer the appropriate comparison method for a model type.

    Reads ``model._model_type`` to determine the model type and maps it
    to the corresponding comparison method.

    Args:
        model: A fitted model object with a ``_model_type`` attribute
            (one of ``"lm"``, ``"glm"``, ``"lmer"``, ``"glmer"``).

    Returns:
        Comparison method: ``"f"`` for lm, ``"lrt"`` for lmer/glmer,
        ``"deviance"`` for glm.

    Raises:
        ValueError: If the model type cannot be mapped to a comparison method.
    """

    if model._model_type == "lm":
        return "f"
    elif model._model_type == "glm":
        return "deviance"
    elif model._model_type in ("lmer", "glmer"):
        return "lrt"
    else:
        raise ValueError(f"Unknown model type: {model._model_type}")


def check_nested(
    df_diffs: list[float | int | None],
    stat_diffs: list[float | None],
    model_formulas: list[str],
    method: str,
) -> None:
    """Check that models appear to be nested and raise error if not.

    Non-nested models are detected by:
    - df <= 0: No additional parameters in augmented model
    - stat_diff < 0: Augmented model fits worse (negative SS, deviance reduction, or chi2)

    Args:
        df_diffs: List of df differences for each comparison (None for first model).
        stat_diffs: List of statistic differences (SS, dev_diff, or chi2).
        model_formulas: List of model formula strings.
        method: Comparison method ("f", "deviance", or "lrt").

    Raises:
        ValueError: If models don't appear nested.
    """
    for i, (df, stat) in enumerate(zip(df_diffs, stat_diffs)):
        if df is None:
            continue  # First model has no comparison

        # Check for non-nested indicators
        if df <= 0:
            raise ValueError(
                f"Models don't appear to be nested: df={df} for comparison "
                f"'{model_formulas[i - 1]}' vs '{model_formulas[i]}'. "
                "Nested models should have strictly increasing parameters. "
                "Use method='cv' for cross-validation comparison of non-nested models."
            )

        if stat is not None and stat < 0:
            stat_name = {"f": "SS", "deviance": "deviance reduction", "lrt": "chi2"}[
                method
            ]
            raise ValueError(
                f"Models don't appear to be nested: {stat_name}={stat:.4f} < 0 for "
                f"comparison '{model_formulas[i - 1]}' vs '{model_formulas[i]}'. "
                "The augmented model fits worse than the compact model. "
                "Use method='cv' for cross-validation comparison of non-nested models."
            )
