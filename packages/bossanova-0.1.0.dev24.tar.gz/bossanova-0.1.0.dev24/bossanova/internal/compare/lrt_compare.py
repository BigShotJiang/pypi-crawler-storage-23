"""Likelihood ratio test implementation for comparing nested mixed models.

Performs sequential LRT comparisons matching lme4's ``anova()`` behavior.
"""

import warnings
from typing import Any

import polars as pl
from scipy import stats

from bossanova.internal.containers.schemas import (
    Col,
    ComparisonLrt as ComparisonLrtSchema,
)
from bossanova.internal.maths.config import is_singular
from bossanova.internal.maths.inference import compute_aic as compute_aic
from bossanova.internal.maths.inference import compute_bic as _compute_bic
from bossanova.internal.compare.helpers import check_nested, get_model_type

__all__ = [
    "compare_lrt",
    "get_n_params",
]


def get_n_params(model: Any) -> int:
    """Get total number of parameters for a mixed model.

    Args:
        model: A fitted lmer or glmer model.

    Returns:
        Total parameter count: fixed effects + variance parameters + sigma (lmer only).
    """
    n_fixed = model._bundle.p
    n_theta = len(model._fit.theta)

    # lmer has sigma as additional parameter, glmer does not
    model_type = get_model_type(model)
    if model_type == "lmer":
        return n_fixed + n_theta + 1
    else:  # glmer
        return n_fixed + n_theta


def compare_lrt(models: list[Any]) -> pl.DataFrame:
    """Perform likelihood ratio tests for nested lmer/glmer models.

    Computes likelihood ratio chi-squared statistics comparing each model
    to the previous (simpler) model. This matches lme4's anova() behavior.

    Args:
        models: List of fitted lmer/glmer models, sorted by complexity.
            All models must use ML estimation (validated by compare()).

    Returns:
        DataFrame with columns:
        - model: Formula string
        - chi2: Likelihood ratio chi-squared statistic
        - npar: Number of parameters
        - AIC: Akaike Information Criterion
        - BIC: Bayesian Information Criterion
        - loglik: Log-likelihood
        - deviance: Deviance (-2 * loglik)
        - df: Degrees of freedom for comparison
        - p_value: p-value from chi-squared distribution

    Notes:
        The LRT statistic is: chi2 = 2 * (loglik_aug - loglik_compact)
        which follows a chi-squared distribution with df = npar_aug - npar_compact
        under the null hypothesis that the simpler model is adequate.

        ML estimation is required for valid LRT when models have different
        fixed effects. REML is accepted when all models share the same
        fixed effects (comparing random effects structures only).

        A warning is emitted when any model has singular (boundary) variance
        components, as the standard chi-squared null distribution may be
        conservative. See Self & Liang (1987).
    """
    n_models = len(models)

    # Initialize result lists
    formulas: list[str] = []
    npars: list[int] = []
    aics: list[float] = []
    bics: list[float] = []
    logliks: list[float] = []
    deviances: list[float] = []
    chi2s: list[float | None] = []
    dfs: list[int | None] = []
    p_values: list[float | None] = []

    # First model (baseline)
    m0 = models[0]
    npar0 = get_n_params(m0)

    formulas.append(m0.formula)
    npars.append(npar0)
    aics.append(compute_aic(m0._fit.loglik, npar0))
    bics.append(_compute_bic(m0._fit.loglik, npar0, m0._bundle.n))
    logliks.append(float(m0._fit.loglik))
    # Use -2*loglik for deviance (matches R's -2*log(L) column)
    deviances.append(float(-2 * m0._fit.loglik))
    chi2s.append(None)
    dfs.append(None)
    p_values.append(None)

    # Compare each model to previous
    for i in range(1, n_models):
        m_prev = models[i - 1]
        m_curr = models[i]

        npar_prev = get_n_params(m_prev)
        npar_curr = get_n_params(m_curr)

        loglik_prev = m_prev._fit.loglik
        loglik_curr = m_curr._fit.loglik

        # Degrees of freedom for this comparison
        df = npar_curr - npar_prev

        # Likelihood ratio statistic: chi2 = 2 * (loglik_aug - loglik_compact)
        chi2 = 2 * (loglik_curr - loglik_prev)

        # p-value from chi-squared distribution
        p_val = 1.0 - stats.chi2.cdf(chi2, df) if df > 0 else 1.0

        formulas.append(m_curr.formula)
        npars.append(npar_curr)
        aics.append(compute_aic(m_curr._fit.loglik, npar_curr))
        bics.append(_compute_bic(m_curr._fit.loglik, npar_curr, m_curr._bundle.n))
        logliks.append(float(m_curr._fit.loglik))
        # Use -2*loglik for deviance (matches R's -2*log(L) column)
        deviances.append(float(-2 * m_curr._fit.loglik))
        chi2s.append(float(chi2))
        dfs.append(int(df))
        p_values.append(float(p_val))

    # Check for non-nested models
    check_nested(dfs, chi2s, formulas, method="lrt")

    # Warn if any model has singular (boundary) variance components.
    # Standard chi2 null distribution is conservative in this case.
    singular_formulas = [m.formula for m in models if is_singular(m._fit.theta)]
    if singular_formulas:
        warnings.warn(
            "boundary (singular) fit detected in: "
            + ", ".join(f"'{f}'" for f in singular_formulas)
            + ". Chi-squared p-values may be conservative when variance components "
            "are on the boundary (near zero). See Self & Liang (1987).",
            UserWarning,
            stacklevel=4,
        )

    # Build DataFrame
    return pl.DataFrame(
        {
            Col.MODEL: formulas,
            Col.CHI2: chi2s,
            Col.NPAR: npars,
            Col.AIC_R: aics,
            Col.BIC_R: bics,
            Col.LOGLIK: logliks,
            Col.DEVIANCE: deviances,
            Col.DF: dfs,
            Col.P_VALUE: p_values,
        },
        schema=ComparisonLrtSchema,
    )
