"""Internal implementation modules — not part of the public API."""

__all__: list[str] = []
