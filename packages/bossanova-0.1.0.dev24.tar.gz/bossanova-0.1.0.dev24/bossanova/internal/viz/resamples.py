"""Bootstrap and permutation distribution visualization."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

import numpy as np
import polars as pl

from bossanova.internal.containers.schemas import Col
from bossanova.internal.viz.core import (
    BOSSANOVA_STYLE,
    build_facetgrid_kwargs,
    finalize_facetgrid,
    format_display_labels,
)

if TYPE_CHECKING:
    from typing import Any

    import seaborn as sns

    from bossanova.model.core import model as BaseModel

__all__ = ["plot_resamples"]


def plot_resamples(
    model: "Any",
    *,
    which: Literal["params", "mee", "effects"] = "params",
    include_intercept: bool = False,
    terms: list[str] | None = None,
    prettify: bool = False,
    height: float = 3.0,
    aspect: float = 1.2,
    col_wrap: int = 4,
    palette: str | None = None,
    show_ci: bool = True,
    show_pvalue: bool = True,
    fill: bool = True,
) -> sns.FacetGrid:
    """Plot distribution of resampled statistics.

    Visualizes bootstrap coefficient distributions or permutation null
    distributions. Requires save_resamples=True (default for n<=5000)
    during infer().

    Args:
        model: A fitted bossanova model with resampling results.
        which: What to plot:
            - "params": Model coefficients (from boot_samples_ or perm_samples_)
            - "mee": Marginal effects (from boot_mee_samples_)
        include_intercept: Include intercept in coefficient plots.
        terms: Subset of terms to plot. If None, plot all.
        prettify: Convert term names to human-readable labels (e.g.,
            "wt_hp_ratio" → "Wt Hp Ratio"). Default False.
        height: Height of each facet in inches.
        aspect: Aspect ratio of each facet (width = height * aspect).
        col_wrap: Number of columns before wrapping.
        palette: Color palette name (default: BOSSANOVA_STYLE palette).
        show_ci: For bootstrap, shade confidence interval region.
        show_pvalue: For permutation, annotate p-value.
        fill: Fill under density curve.

    Returns:
        Seaborn FacetGrid with one facet per parameter.

    Raises:
        RuntimeError: If no resampling results available.
        ValueError: If requested context has no samples.

    Examples:
        ```python
        from bossanova import model, viz, load_dataset
        mtcars = load_dataset("mtcars")
        m = model("mpg ~ wt + hp", mtcars).fit()

        # Bootstrap distributions (auto-saved for n<=5000)
        m.infer(how="boot", n=999)
        viz.plot_resamples(m)

        # Permutation null distributions
        m.infer(how="perm", n=999)
        viz.plot_resamples(m)

        # MEE bootstrap
        m.mee("wt").infer(how="boot", n=999)
        viz.plot_resamples(m, which="mee")
        ```

    See Also:
        plot_params: Forest plot of parameter estimates.
    """
    import seaborn as sns

    # Extract samples and metadata based on context
    samples, observed, names, ci_info, pvalue_info, resample_type = (
        extract_resample_data(model, which, include_intercept)
    )

    # Filter to specific terms if requested
    if terms is not None:
        mask = [n in terms for n in names]
        indices = [i for i, m in enumerate(mask) if m]
        samples = samples[:, indices]
        observed = {names[i]: observed[names[i]] for i in indices}
        if ci_info:
            ci_info = {names[i]: ci_info[names[i]] for i in indices}
        if pvalue_info:
            pvalue_info = {names[i]: pvalue_info[names[i]] for i in indices}
        names = [names[i] for i in indices]

    if len(names) == 0:
        raise ValueError("No terms to plot after filtering.")

    # Strip transforms from names for display (consistent with plot_params)
    stripped_names = format_display_labels(
        names, max_chars=25, prettify=prettify, strip_transforms=True
    )

    # Reshape to long format for FacetGrid (use stripped names for facets)
    long_data = []
    for i, name in enumerate(names):
        for val in samples[:, i]:
            long_data.append({Col.TERM: stripped_names[i], Col.VALUE: float(val)})
    plot_df = pl.DataFrame(long_data)

    # Remap dictionaries to use stripped names
    observed = {stripped_names[i]: v for i, (_, v) in enumerate(observed.items())}
    if ci_info:
        ci_info = {stripped_names[names.index(k)]: v for k, v in ci_info.items()}
    if pvalue_info:
        pvalue_info = {
            stripped_names[names.index(k)]: v for k, v in pvalue_info.items()
        }

    # Determine col_wrap based on number of terms
    n_terms = len(names)
    effective_col_wrap = min(col_wrap, n_terms)

    style = BOSSANOVA_STYLE
    if palette is None:
        palette = style["palette"]

    # Build FacetGrid kwargs
    facet_kwargs = build_facetgrid_kwargs(
        data=plot_df,
        height=height,
        aspect=aspect,
        col=Col.TERM,
        col_wrap=effective_col_wrap,
        palette=palette,
        sharex=False,  # Each param has different scale
        sharey=False,
    )

    # Create FacetGrid
    g = sns.FacetGrid(**facet_kwargs)

    # Map the density drawing function
    g.map_dataframe(
        draw_resample_density,
        observed=observed,
        ci_info=ci_info,
        pvalue_info=pvalue_info,
        resample_type=resample_type,
        style=style,
        fill=fill,
        show_ci=show_ci,
        show_pvalue=show_pvalue,
    )

    # Title based on resample type
    if resample_type == "bootstrap":
        title = "Bootstrap Distribution"
    else:
        title = "Permutation Null Distribution"

    finalize_facetgrid(g, title=title, xlabel="Value", ylabel="Density")

    return g


def extract_resample_data(
    model: BaseModel,
    which: Literal["params", "mee", "effects"],
    include_intercept: bool,
) -> tuple[np.ndarray, dict, list, dict | None, dict | None, str]:
    """Extract resampling data from model via .resamples property.

    Args:
        model: A fitted bossanova model with resampling results.
        which: What to plot (``"params"`` or ``"mee"``).
        include_intercept: Include intercept in coefficient plots.

    Returns:
        Tuple of (samples, observed, names, ci_info, pvalue_info, resample_type)
        - samples: Array of shape [n_resamples, n_params]
        - observed: Dict mapping term name to observed value
        - names: List of term names
        - ci_info: Dict mapping term name to (ci_lower, ci_upper) or None
        - pvalue_info: Dict mapping term name to p-value or None
        - resample_type: "bootstrap" or "permutation"

    Raises:
        RuntimeError: If no resampling results are available.
    """
    rs = model._resamples
    if rs is None:
        raise RuntimeError(
            "No resampling results found. Call .infer(how='boot') or "
            ".infer(how='perm') with save_resamples=True."
        )

    # Check context matches requested 'which'
    expected_context = "effects" if which in ("mee", "effects") else "params"
    if rs.context != expected_context:
        raise RuntimeError(
            f"Resamples are for '{rs.context}', but which='{which}' was requested. "
            f"Re-run .infer(how='{rs.method}') after the appropriate operation."
        )

    samples = np.asarray(rs.samples)
    observed_arr = np.asarray(rs.observed)
    names = list(rs.names)
    resample_type = "bootstrap" if rs.method == "boot" else "permutation"

    ci_info = None
    pvalue_info = None

    # Filter intercept for params context
    if rs.context == "params" and not include_intercept:
        mask = [not is_intercept(n) for n in names]
        indices = [i for i, m in enumerate(mask) if m]
        samples = samples[:, indices]
        observed_arr = observed_arr[indices]
        names = [names[i] for i in indices]

    observed = dict(zip(names, observed_arr.tolist()))

    # Extract CI / p-value info from the inference state
    if rs.method == "boot":
        # Get CIs from the inference state (params or effects)
        ci_info = _extract_ci_info(model, rs.context, names)
    elif rs.method == "perm":
        pvalue_info = _extract_pvalue_info(model, rs.context, names)

    return samples, observed, names, ci_info, pvalue_info, resample_type


def _extract_ci_info(
    model: BaseModel,
    context: str,
    names: list[str],
) -> dict[str, tuple[float, float]] | None:
    """Extract CI bounds from inference state.

    Args:
        model: The fitted model.
        context: ``"params"`` or ``"effects"``.
        names: Term names to extract CIs for.

    Returns:
        Dict mapping names to (ci_lower, ci_upper) tuples, or None.
    """
    if context == "params":
        inf = model._params_inference
        if inf is None or inf.ci_lower is None:
            return None
        all_names = list(model._bundle.X_names)
    else:
        mee = model._mee
        if mee is None or not hasattr(mee, "ci_lower") or mee.ci_lower is None:
            return None
        inf = mee
        all_names = names  # Already filtered

    ci_lower = np.asarray(inf.ci_lower)
    ci_upper = np.asarray(inf.ci_upper)

    if context == "params":
        # Map from all param names to requested subset
        result = {}
        for name in names:
            if name in all_names:
                idx = all_names.index(name)
                result[name] = (float(ci_lower[idx]), float(ci_upper[idx]))
        return result if result else None

    return {
        name: (float(ci_lower[i]), float(ci_upper[i]))
        for i, name in enumerate(names)
        if i < len(ci_lower)
    }


def _extract_pvalue_info(
    model: BaseModel,
    context: str,
    names: list[str],
) -> dict[str, float] | None:
    """Extract p-values from inference state.

    Args:
        model: The fitted model.
        context: ``"params"`` or ``"effects"``.
        names: Term names to extract p-values for.

    Returns:
        Dict mapping names to p-values, or None.
    """
    if context == "params":
        inf = model._params_inference
        if inf is None or inf.p_value is None:
            return None
        all_names = list(model._bundle.X_names)
        p_values = np.asarray(inf.p_value)
        result = {}
        for name in names:
            if name in all_names:
                idx = all_names.index(name)
                result[name] = float(p_values[idx])
        return result if result else None

    mee = model._mee
    if mee is None or not hasattr(mee, "p_value") or mee.p_value is None:
        return None
    p_values = np.asarray(mee.p_value)
    return {
        name: float(p_values[i]) for i, name in enumerate(names) if i < len(p_values)
    }


def is_intercept(name: str) -> bool:
    """Check if a term name represents an intercept."""
    lower = name.lower()
    return lower in ("intercept", "(intercept)", "1")


def draw_resample_density(
    data,  # Polars or pandas DataFrame from FacetGrid
    *,
    observed: dict[str, float],
    ci_info: dict[str, tuple[float, float]] | None,
    pvalue_info: dict[str, float] | None,
    resample_type: str,
    style: dict,
    fill: bool,
    show_ci: bool,
    show_pvalue: bool,
    **kwargs,
) -> None:
    """Draw density for a single parameter facet."""
    import matplotlib.pyplot as plt
    from scipy import stats

    ax = plt.gca()

    # Get term name from facet (works with both polars and pandas)
    term = list(data[Col.TERM])[0]
    values = np.asarray(data[Col.VALUE])
    obs = observed[term]

    # Compute KDE
    if len(np.unique(values)) < 2:
        # Degenerate case - all same value
        ax.axvline(values[0], color="C0", linewidth=2, label="Samples")
        ax.axvline(obs, color="C3", linestyle="--", linewidth=2, label="Observed")
        ax.set_xlim(values[0] - 1, values[0] + 1)
        return

    kde = stats.gaussian_kde(values)
    x_min, x_max = values.min(), values.max()
    x_pad = (x_max - x_min) * 0.1
    x_range = np.linspace(x_min - x_pad, x_max + x_pad, 200)
    density = kde(x_range)

    # Plot density line
    color = "C0"
    ax.plot(x_range, density, color=color, linewidth=1.5)

    # Fill under curve if requested
    if fill:
        ax.fill_between(x_range, density, alpha=style["ci_alpha"], color=color)

    # Observed value line
    ax.axvline(obs, color="C3", linestyle="--", linewidth=2, label="Observed")

    # For bootstrap: shade CI region
    if resample_type == "bootstrap" and show_ci and ci_info is not None:
        ci_lo, ci_hi = ci_info[term]
        ci_mask = (x_range >= ci_lo) & (x_range <= ci_hi)
        if ci_mask.any():
            ax.fill_between(
                x_range[ci_mask],
                density[ci_mask],
                alpha=0.2,
                color="C2",
                label="95% CI",
            )
        # Draw CI bounds as vertical lines
        ax.axvline(ci_lo, color="C2", linestyle=":", linewidth=1, alpha=0.7)
        ax.axvline(ci_hi, color="C2", linestyle=":", linewidth=1, alpha=0.7)

    # For permutation: annotate p-value
    if resample_type == "permutation" and show_pvalue and pvalue_info is not None:
        p = pvalue_info[term]
        p_str = f"p = {p:.3f}" if p >= 0.001 else "p < 0.001"
        ax.annotate(
            p_str,
            xy=(0.95, 0.95),
            xycoords="axes fraction",
            ha="right",
            va="top",
            fontsize=style["font_size"],
            bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8),
        )

    # Clean up axes
    ax.set_ylabel("")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
