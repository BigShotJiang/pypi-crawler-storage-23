"""VIF and multicollinearity visualization."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np

from bossanova.internal.containers.schemas import Col
from bossanova.internal.maths.inference.diagnostics import (
    compute_vif as _compute_vif_df,
)
from bossanova.internal.viz.core import (
    BOSSANOVA_STYLE,
    create_single_panel,
    format_display_labels,
)

if TYPE_CHECKING:
    import seaborn as sns
    from matplotlib.axes import Axes

    from bossanova.model.core import model as BaseModel

__all__ = ["plot_vif"]


# =============================================================================
# VIF Computation
# =============================================================================


def compute_vif(X: np.ndarray, X_names: list[str]) -> dict[str, float]:
    """Compute Variance Inflation Factor for each predictor.

    Thin wrapper around ``diagnostics.compute_vif`` that returns a dict
    for use by plot helpers. Uses the same correlation-matrix-inversion
    algorithm as ``model.vif()``.

    Args:
        X: Design matrix (n_obs, n_predictors).
        X_names: Column names for the design matrix.

    Returns:
        Dictionary mapping predictor names to VIF values.
        Intercept is excluded (VIF undefined).
    """
    df = _compute_vif_df(X, X_names)
    return dict(zip(df[Col.TERM].to_list(), df[Col.VIF].to_list()))


def compute_correlation_matrix(
    X: np.ndarray, X_names: list[str]
) -> tuple[np.ndarray, list[str]]:
    """Compute correlation matrix for design matrix predictors.

    Args:
        X: Design matrix (n_obs, n_predictors).
        X_names: Column names for the design matrix.

    Returns:
        Tuple of (correlation_matrix, predictor_names).
        Intercept is excluded.
    """
    # Find non-intercept columns
    non_intercept_idx = [i for i, name in enumerate(X_names) if name != "Intercept"]
    X_pred = X[:, non_intercept_idx]
    pred_names = [X_names[i] for i in non_intercept_idx]

    # Compute correlation matrix
    corr_matrix = np.corrcoef(X_pred, rowvar=False)

    # Handle single predictor case
    if corr_matrix.ndim == 0:
        corr_matrix = np.array([[1.0]])

    return corr_matrix, pred_names


# =============================================================================
# Main Plot Function
# =============================================================================


def plot_vif(
    model: BaseModel,
    *,
    cmap: str | None = None,
    height: float = 4.0,
    aspect: float = 1.0,
    prettify: bool = False,
) -> sns.FacetGrid:
    """Plot VIF diagnostics as correlation heatmap.

    Visualizes multicollinearity in the design matrix:
    - Correlation heatmap between predictors
    - VIF (Variance Inflation Factor) for each predictor
    - CI increase factor (sqrt(VIF)) showing confidence interval inflation

    VIF interpretation:
    - VIF = 1: No multicollinearity
    - VIF = 1-5: Moderate (generally acceptable)
    - VIF > 5: High multicollinearity (concerning)
    - VIF > 10: Severe multicollinearity (problematic)

    Works on unfitted models since the design matrix is built at initialization.

    For pairwise scatter plots including the response variable, use
    `plot_relationships()` instead.

    Args:
        model: A bossanova model. Can be fitted or unfitted.
        cmap: Matplotlib colormap name. Default "coolwarm".
        height: Figure height in inches. Default 4.0.
        aspect: Width-to-height ratio. Default 1.0 (square heatmap).
        prettify: Convert column names to human-readable labels (e.g.,
            "wt_hp_ratio" -> "Wt Hp Ratio"). Default False.

    Returns:
        Seaborn FacetGrid containing the plot.

    Examples:
        ```python
        from bossanova import model, load_dataset
        cars = load_dataset("mtcars")
        m = model("mpg ~ wt + hp + disp", cars)
        m.plot_vif()  # Correlation heatmap with VIF stats
        m.plot_vif(prettify=True)  # With prettified labels
        ```
    """
    # Get design matrix
    X = model._bundle.X
    X_names = model._bundle.X_names

    # Find non-intercept columns
    non_intercept_idx = [i for i, name in enumerate(X_names) if name != "Intercept"]
    pred_names = [X_names[i] for i in non_intercept_idx]

    n_predictors = len(pred_names)

    if n_predictors == 0:
        raise ValueError("Model has no predictors (only intercept)")

    # Compute VIF
    vif_values = compute_vif(X, X_names)
    style = BOSSANOVA_STYLE

    # Adaptive max_chars based on predictor count
    max_chars = max(12, min(25, 70 // n_predictors))

    # Display names: truncated for tick labels
    tick_names = format_display_labels(
        pred_names, max_chars=max_chars, prettify=prettify
    )

    # Full display names for VIF text (prettified but not truncated)
    full_display_names = format_display_labels(
        pred_names, max_chars=200, prettify=prettify
    )

    # Build VIF info text (one variable per line, using full display names)
    vif_lines = []
    for raw_name, display_name in zip(pred_names, full_display_names):
        vif = vif_values.get(raw_name, 1.0)
        ci_increase = np.sqrt(vif)
        if np.isinf(vif):
            vif_lines.append(f"{display_name}: VIF=\u221e")
        else:
            vif_lines.append(
                f"{display_name}: VIF={vif:.1f}, CI inc: {ci_increase:.1f}x"
            )
    vif_text = "\n".join(vif_lines)

    # Compute figure size from height/aspect
    figsize = (height * aspect, height)

    return _draw_vif_heatmap(
        X,
        X_names,
        tick_names,
        vif_text,
        n_predictors,
        style,
        cmap,
        figsize,
    )


def _draw_vif_heatmap(
    X: np.ndarray,
    X_names: list[str],
    display_names: list[str],
    vif_text: str,
    n_predictors: int,
    style: dict[str, Any],
    cmap: str | None,
    figsize: tuple[float, float],
) -> sns.FacetGrid:
    """Render VIF as correlation heatmap inside a FacetGrid.

    Args:
        X: Design matrix.
        X_names: Column names for the design matrix.
        display_names: Tick-label names (formatted/truncated).
        vif_text: Multi-line VIF annotation string.
        n_predictors: Number of predictors.
        style: BOSSANOVA_STYLE dictionary.
        cmap: Colormap name or None for default.
        figsize: Figure size (width, height).

    Returns:
        Seaborn FacetGrid wrapping the heatmap.
    """
    import seaborn as sns

    # Compute correlation matrix
    corr_matrix, _ = compute_correlation_matrix(X, X_names)

    # Create single-panel FacetGrid
    g, ax = create_single_panel(figsize)

    # Colormap: correlations are always -1 to 1, so diverging
    cmap = cmap if cmap is not None else "coolwarm"

    # Plot heatmap
    im = ax.imshow(
        corr_matrix,
        aspect="equal",
        cmap=cmap,
        vmin=-1,
        vmax=1,
        interpolation="nearest",
    )

    # Add colorbar
    fig = g.figure
    cbar = fig.colorbar(im, ax=ax, shrink=0.6, pad=0.02, aspect=30)
    cbar.ax.tick_params(labelsize=style["font_size"] - 1)
    cbar.set_label("Pearson r", rotation=270, labelpad=15, fontsize=style["font_size"])

    # Add correlation values as text annotations
    _annotate_cells(ax, corr_matrix, n_predictors, style)

    # Add faint grid lines
    for i in range(n_predictors + 1):
        ax.axhline(y=i - 0.5, color="white", linewidth=0.5, alpha=0.6)
        ax.axvline(x=i - 0.5, color="white", linewidth=0.5, alpha=0.6)

    # Set tick labels (truncated)
    ax.set_xticks(np.arange(n_predictors))
    ax.set_yticks(np.arange(n_predictors))
    ax.set_xticklabels(
        display_names, fontsize=style["font_size"] - 1, rotation=45, ha="right"
    )
    ax.set_yticklabels(display_names, fontsize=style["font_size"] - 1)

    # Add VIF info above the heatmap (left-aligned)
    ax.text(
        0.0,
        1.02,
        vif_text,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=style["font_size"] - 1,
        color="#666666",
    )

    # Add title (with extra padding for VIF text)
    title_pad = 10 + n_predictors * 12
    ax.set_title("Predictor Correlations", fontsize=style["title_size"], pad=title_pad)

    sns.despine(left=True, bottom=True)
    g.tight_layout()

    return g


def _annotate_cells(
    ax: Axes,
    corr_matrix: np.ndarray,
    n_predictors: int,
    style: dict[str, Any],
) -> None:
    """Add correlation values as text annotations to heatmap cells.

    Args:
        ax: Matplotlib axes with the heatmap.
        corr_matrix: Correlation matrix.
        n_predictors: Number of predictors.
        style: BOSSANOVA_STYLE dictionary.
    """
    for i in range(n_predictors):
        for j in range(n_predictors):
            value = corr_matrix[i, j]
            text_color = "white" if abs(value) > 0.6 else "black"
            ax.text(
                j,
                i,
                f"{value:.2f}",
                ha="center",
                va="center",
                fontsize=style["font_size"] - 2,
                color=text_color,
            )
