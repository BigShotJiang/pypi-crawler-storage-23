"""Data extraction utilities for bossanova visualizations.

Provides functions to extract standardized parameter, residual, and
random-effect DataFrames from fitted models (both legacy and unified API).
"""

from __future__ import annotations

from typing import Any, Literal

import numpy as np
import polars as pl

from bossanova.internal.containers.schemas import Col
from bossanova.internal.viz.core_protocols import (
    get_model_fitted,
    get_model_params,
    get_model_residuals,
    get_model_response,
    is_unified_model,
)

__all__ = [
    "extract_fixef",
    "extract_params",
    "extract_ranef",
    "extract_residuals",
]


def extract_params(
    model: Any,
    which: Literal["fixef", "ranef", "all"] = "fixef",
    include_intercept: bool = False,
    effect_sizes: bool = False,
    group: str | None = None,
    term: str | None = None,
) -> pl.DataFrame:
    """Extract parameter estimates from a fitted model.

    Returns a standardized DataFrame suitable for forest plot visualization.
    Supports both old BaseModel and new unified model() class.

    Args:
        model: Fitted bossanova model (lm, glm, lmer, glmer, or unified model()).
        which: Which parameters to extract.
            - "fixef": Fixed effects only (default).
            - "ranef": Random effects (lmer/glmer only).
            - "all": Both fixed and random effects.
        include_intercept: Include intercept term for fixed effects.
        effect_sizes: Return effect sizes (Cohen's d) instead of raw estimates.
        group: For ranef, which grouping factor (None = all).
        term: For ranef, which RE term (None = all).

    Returns:
        DataFrame with columns:
            - term: Parameter name
            - estimate: Point estimate
            - se: Standard error
            - ci_lower: Lower confidence bound
            - ci_upper: Upper confidence bound
            - p_value: P-value (if available)
            - group_factor: Grouping factor name (for ranef)
            - re_term: Random effect term name (for ranef)

    Raises:
        RuntimeError: If model is not fitted.
        TypeError: If which="ranef" but model has no random effects.

    Examples:
        Old API (BaseModel)::

            model = lm("mpg ~ wt + hp", data=mtcars).fit()
            df = extract_params(model)

        New API (unified model())::

            m = model("mpg ~ wt + hp", mtcars).fit()
            df = extract_params(m)
    """
    # Check model is fitted
    if not model._is_fitted:
        raise RuntimeError("Model must be fitted before extracting parameters")

    if which == "fixef":
        return extract_fixef(model, include_intercept, effect_sizes)
    elif which == "ranef":
        return extract_ranef(model, group, term)
    elif which == "all":
        fixef_df = extract_fixef(model, include_intercept, effect_sizes)
        ranef_df = extract_ranef(model, group, term)
        # Add type column for stacking
        fixef_df = fixef_df.with_columns(pl.lit("fixef").alias("param_type"))
        ranef_df = ranef_df.with_columns(pl.lit("ranef").alias("param_type"))
        # Align schemas before concat
        return pl.concat([fixef_df, ranef_df], how="diagonal")
    else:
        raise ValueError(f"which must be 'fixef', 'ranef', or 'all', got {which!r}")


def extract_fixef(
    model: Any,
    include_intercept: bool = False,
    effect_sizes: bool = False,
) -> pl.DataFrame:
    """Extract fixed effects from model.

    Args:
        model: A fitted bossanova model.
        include_intercept: Whether to include the intercept term.
        effect_sizes: Whether to return Cohen's d instead of raw estimates.
            Available effect size measures depend on model family:

            - **Gaussian (LM/LMER)**: Cohen's d, semi-partial r, eta-squared.
            - **Binomial (GLM/GLMER)**: odds ratio, semi-partial r, eta-squared.
              Cohen's d is unavailable (no residual SD).
            - **Other GLM families**: semi-partial r, eta-squared.
              Cohen's d is unavailable (no residual SD).

            Unavailable measures are returned as ``None`` columns.

    Returns:
        DataFrame with standard columns: term, estimate, se, ci_lower,
        ci_upper, p_value.
    """
    # Get parameters DataFrame using compatibility layer
    df = get_model_params(model)

    if effect_sizes:
        if not is_unified_model(model):
            msg = (
                f"Unrecognized model type {type(model).__name__!r}. "
                "Expected a bossanova model()."
            )
            raise TypeError(msg)
        df = model.to_effect_size(include_intercept=include_intercept)
        return df.select(
            pl.col(Col.TERM),
            pl.col(Col.COHENS_D).alias(Col.ESTIMATE),
            pl.col(Col.SE)
            if Col.SE in df.columns
            else pl.lit(None).cast(pl.Float64).alias(Col.SE),
            pl.col(Col.D_LOWER).alias(Col.CI_LOWER)
            if Col.D_LOWER in df.columns
            else pl.lit(None).cast(pl.Float64).alias(Col.CI_LOWER),
            pl.col(Col.D_UPPER).alias(Col.CI_UPPER)
            if Col.D_UPPER in df.columns
            else pl.lit(None).cast(pl.Float64).alias(Col.CI_UPPER),
            pl.col(Col.P_VALUE)
            if Col.P_VALUE in df.columns
            else pl.lit(None).cast(pl.Float64).alias(Col.P_VALUE),
        )

    # Filter intercept if needed
    if not include_intercept:
        # Match various intercept naming conventions
        df = df.filter(
            ~pl.col(Col.TERM)
            .str.to_lowercase()
            .is_in(["intercept", "(intercept)", "const", "_cons"])
        )

    # Select standard columns (handle different model schemas)
    cols = df.columns
    result_cols = [pl.col(Col.TERM), pl.col(Col.ESTIMATE)]

    if Col.SE in cols:
        result_cols.append(pl.col(Col.SE))
    else:
        result_cols.append(pl.lit(None).cast(pl.Float64).alias(Col.SE))

    if Col.CI_LOWER in cols:
        result_cols.append(pl.col(Col.CI_LOWER))
    else:
        result_cols.append(pl.lit(None).cast(pl.Float64).alias(Col.CI_LOWER))

    if Col.CI_UPPER in cols:
        result_cols.append(pl.col(Col.CI_UPPER))
    else:
        result_cols.append(pl.lit(None).cast(pl.Float64).alias(Col.CI_UPPER))

    if Col.P_VALUE in cols:
        result_cols.append(pl.col(Col.P_VALUE))
    else:
        result_cols.append(pl.lit(None).cast(pl.Float64).alias(Col.P_VALUE))

    return df.select(result_cols)


def extract_ranef(
    model: Any,
    group: str | None = None,
    term: str | None = None,
) -> pl.DataFrame:
    """Extract random effects from mixed model.

    Supports both old BaseModel (.varying) and new unified model() (.is_mixed).

    Args:
        model: A fitted mixed-effects bossanova model.
        group: Filter to a specific grouping factor (None = all).
        term: Filter to a specific random effect term (None = all).

    Returns:
        DataFrame in long format with columns: term, estimate, se,
        ci_lower, ci_upper, p_value, group_factor, re_term.

    Raises:
        TypeError: If model has no random effects.
    """
    # Check model has random effects
    # New unified model() class
    if hasattr(model, "_is_mixed") and not model._is_mixed:
        raise TypeError(
            f"{type(model).__name__} has no random effects. Use which='fixef' instead."
        )
    # Old BaseModel
    elif not hasattr(model, "varying"):
        raise TypeError(
            f"{type(model).__name__} has no varying effects. Use which='fixef' instead."
        )

    # Get varying effects DataFrame
    ranef_df = model.varying

    # Filter by group if specified
    if group is not None:
        if "group_factor" in ranef_df.columns:
            ranef_df = ranef_df.filter(pl.col("group_factor") == group)
        elif group not in ranef_df.columns:
            raise ValueError(
                f"Group factor '{group}' not found. Available: {ranef_df.columns}"
            )

    # Filter by term if specified
    if term is not None:
        if "re_term" in ranef_df.columns:
            ranef_df = ranef_df.filter(pl.col("re_term") == term)

    # Standardize column names for plotting
    # ranef typically has: group_id, group_factor, Intercept, slope_name, etc.
    # We need to reshape to long format: term, estimate, ...

    # Check if already in long format
    if Col.ESTIMATE in ranef_df.columns:
        return ranef_df

    # Otherwise, reshape from wide to long
    # Identify RE columns (not group_id, group_factor)
    group_cols = ["group_id", "group_factor"]
    re_cols = [c for c in ranef_df.columns if c not in group_cols]

    if not re_cols:
        raise ValueError("No random effect columns found in ranef DataFrame")

    # Melt to long format using unpivot
    # Determine which group columns actually exist
    existing_group_cols = [c for c in group_cols if c in ranef_df.columns]

    result = ranef_df.unpivot(
        on=re_cols,
        index=existing_group_cols,
        variable_name="re_term",
        value_name=Col.ESTIMATE,
    )

    # Create term column from group_id (cast to string) or empty string if not present
    if "group_id" in result.columns:
        result = result.with_columns(
            pl.col("group_id").cast(pl.String).alias(Col.TERM)
        ).drop("group_id")
    else:
        result = result.with_columns(pl.lit("").alias(Col.TERM))

    # Add group_factor column if not present
    if "group_factor" not in result.columns:
        result = result.with_columns(pl.lit("").alias("group_factor"))

    # Add None placeholder columns for standard format
    # BLUP SEs require conditional vcov (see: washington-ckyb)
    return result.with_columns(
        pl.lit(None).alias(Col.SE),
        pl.lit(None).alias(Col.CI_LOWER),
        pl.lit(None).alias(Col.CI_UPPER),
        pl.lit(None).alias(Col.P_VALUE),
    )


def extract_residuals(
    model: Any,
    residual_type: str | None = None,
) -> dict[str, np.ndarray]:
    """Extract residual diagnostics from a fitted model.

    Supports both old BaseModel and new unified model() class.

    Args:
        model: Fitted bossanova model (lm, glm, lmer, glmer, or unified model()).
        residual_type: Type of residuals. If None, uses model default.
            - "response": Raw residuals (y - fitted)
            - "pearson": Pearson residuals
            - "deviance": Deviance residuals (GLM)

    Returns:
        Dictionary with:
            - fitted: Fitted values
            - residuals: Residual values
            - std_resid: Standardized residuals
            - leverage: Hat/leverage values
            - cooksd: Cook's distance

    Raises:
        RuntimeError: If model is not fitted.

    Examples:
        Old API (BaseModel)::

            model = lm("mpg ~ wt + hp", data=mtcars).fit()
            diag = extract_residuals(model)

        New API (unified model())::

            m = model("mpg ~ wt + hp", mtcars).fit()
            diag = extract_residuals(m)
    """
    if not model._is_fitted:
        raise RuntimeError("Model must be fitted before extracting residuals")

    # Default residual type based on model
    if residual_type is None:
        # Old BaseModel: check _family attribute
        if hasattr(model, "_family"):
            residual_type = "deviance"
        # New unified model(): check family in _spec
        elif hasattr(model, "_spec") and model._spec.family != "gaussian":
            residual_type = "deviance"
        else:
            residual_type = "response"

    # Extract from model - prefer augmented data columns for consistent lengths.
    # After fit(), model.data is the original DataFrame augmented with diagnostic
    # columns (fitted, resid, hat, std_resid, cooksd) expanded to n_total rows
    # with NaN at positions where observations were dropped due to missing data.
    # We filter to non-null rows so all arrays are consistently valid-only.
    data = model.data

    # Fast path: augmented diagnostic columns exist (post-fit augmented data).
    # Filter to valid rows (non-NaN fitted) so all columns align.
    has_augmented = Col.FITTED in data.columns and Col.RESID in data.columns
    if has_augmented:
        valid_data = data.filter(pl.col(Col.FITTED).is_not_null())

        fitted = valid_data[Col.FITTED].to_numpy()
        result: dict[str, np.ndarray] = {Col.FITTED: fitted}

        # Residuals (type-specific for GLM)
        if residual_type == "pearson" and "pearson_resid" in valid_data.columns:
            result["residuals"] = valid_data["pearson_resid"].to_numpy()
        elif residual_type == "deviance" and "deviance_resid" in valid_data.columns:
            result["residuals"] = valid_data["deviance_resid"].to_numpy()
        else:
            result["residuals"] = valid_data[Col.RESID].to_numpy()

        # Standardized residuals
        if Col.STD_RESID in valid_data.columns:
            result[Col.STD_RESID] = valid_data[Col.STD_RESID].to_numpy()
        else:
            resid = result["residuals"]
            std = np.std(resid)
            result[Col.STD_RESID] = resid / std if std > 0 else resid

        n = len(fitted)

        # Leverage
        if Col.HAT in valid_data.columns:
            result["leverage"] = valid_data[Col.HAT].to_numpy()
        else:
            result["leverage"] = np.zeros(n)

        # Cook's distance
        if Col.COOKSD in valid_data.columns:
            result[Col.COOKSD] = valid_data[Col.COOKSD].to_numpy()
        else:
            result[Col.COOKSD] = np.zeros(n)

        return result

    # Fallback path: no augmented columns (e.g. old BaseModel API).
    # Use model attributes directly — these are already valid-only.
    try:
        fitted = get_model_fitted(model)
    except AttributeError:
        raise ValueError("Model has no fitted values available")

    result = {Col.FITTED: fitted}

    # Residuals
    if residual_type == "response":
        try:
            result["residuals"] = get_model_residuals(model)
        except AttributeError:
            y_col = get_model_response(model)
            y = data[y_col].to_numpy()
            result["residuals"] = y - fitted
    elif residual_type == "pearson" and "pearson_resid" in data.columns:
        result["residuals"] = data["pearson_resid"].to_numpy()
    elif residual_type == "deviance" and "deviance_resid" in data.columns:
        result["residuals"] = data["deviance_resid"].to_numpy()
    else:
        try:
            result["residuals"] = get_model_residuals(model)
        except AttributeError:
            y_col = get_model_response(model)
            y = data[y_col].to_numpy()
            result["residuals"] = y - fitted

    # Standardized residuals
    resid = result["residuals"]
    std = np.std(resid)
    result[Col.STD_RESID] = resid / std if std > 0 else resid

    n = len(fitted)
    result["leverage"] = np.zeros(n)
    result[Col.COOKSD] = np.zeros(n)

    return result
