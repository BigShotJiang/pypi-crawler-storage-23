"""Model protocol and model-data extraction utilities.

Provides a unified interface for extracting data from both the legacy
BaseModel API and the new unified model() class.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

import numpy as np
import polars as pl

from bossanova.internal.containers.schemas import Col

__all__ = [
    "ModelProtocol",
    "get_model_fitted",
    "get_model_formula",
    "get_model_params",
    "get_model_residuals",
    "get_model_response",
    "is_unified_model",
]


# =============================================================================
# Model Protocol for Unified Interface
# =============================================================================


@runtime_checkable
class ModelProtocol(Protocol):
    """Protocol for model objects that can be visualized.

    This protocol defines the minimal interface required for visualization
    functions, supporting both old BaseModel and new unified model() class.
    """

    @property
    def _is_fitted(self) -> bool:
        """Whether the model has been fitted."""
        ...

    @property
    def data(self) -> pl.DataFrame:
        """The model's data."""
        ...


def get_model_formula(model: Any) -> str:
    """Extract formula string from model, supporting both old and new API.

    Args:
        model: A bossanova model (BaseModel or unified model()).

    Returns:
        Formula string.
    """
    # New unified model() class
    if hasattr(model, "formula") and isinstance(model.formula, str):
        return model.formula
    # Old BaseModel
    if hasattr(model, "_formula"):
        return model._formula
    raise AttributeError(f"Cannot extract formula from {type(model).__name__}")


def get_model_response(model: Any) -> str:
    """Extract response variable name from model, supporting both APIs.

    Args:
        model: A bossanova model (BaseModel or unified model()).

    Returns:
        Response variable name.
    """
    # Old BaseModel has .response property
    if hasattr(model, "response"):
        return model.response
    # New unified model() class
    if hasattr(model, "_spec") and hasattr(model._spec, "response_var"):
        return model._spec.response_var
    # Fallback: parse from formula
    formula = get_model_formula(model)
    return formula.split("~")[0].strip()


def _is_model_proxy(obj: Any) -> bool:
    """Check if obj is a ModelResult proxy wrapping a unified model.

    Uses duck typing (checks for ``_model`` slot pointing to a model)
    to avoid importing from the model layer.

    Args:
        obj: Any object.

    Returns:
        True if obj is a ModelResult proxy.
    """
    inner = getattr(obj, "_model", None)
    return inner is not None and type(inner).__name__ == "model"


def get_model_params(model: Any) -> pl.DataFrame:
    """Extract parameter estimates from model, supporting both APIs.

    Args:
        model: A fitted bossanova model (or ModelResult proxy).

    Returns:
        DataFrame with term, estimate, and optional inference columns.
    """
    # New unified model() class or ModelResult proxy
    if isinstance(getattr(type(model), "params", None), property) or _is_model_proxy(
        model
    ):
        return model.params
    # Old BaseModel - .result_params attribute
    if hasattr(model, "result_params"):
        return model.result_params
    raise AttributeError(
        f"Cannot extract parameters from {type(model).__name__}. "
        "Model may not be fitted."
    )


def get_model_fitted(model: Any) -> np.ndarray:
    """Extract fitted values from model, supporting both APIs.

    Args:
        model: A fitted bossanova model.

    Returns:
        Array of fitted values.
    """
    # Old BaseModel - direct attribute
    if hasattr(model, "fitted"):
        fitted = model.fitted
        if fitted is not None:
            return np.asarray(fitted)
    # New unified model() class - from _fit state
    if hasattr(model, "_fit") and model._fit is not None:
        return model._fit.fitted
    # Fallback: check data columns
    if hasattr(model, "data") and Col.FITTED in model.data.columns:
        return model.data[Col.FITTED].to_numpy()
    raise AttributeError(
        f"Cannot extract fitted values from {type(model).__name__}. "
        "Model may not be fitted."
    )


def get_model_residuals(model: Any) -> np.ndarray:
    """Extract residuals from model, supporting both APIs.

    Args:
        model: A fitted bossanova model.

    Returns:
        Array of residual values.
    """
    # Old BaseModel - direct attribute
    if hasattr(model, "residuals"):
        residuals = model.residuals
        if residuals is not None:
            return np.asarray(residuals)
    # New unified model() class - from _fit state
    if hasattr(model, "_fit") and model._fit is not None:
        if hasattr(model._fit, "residuals"):
            return model._fit.residuals
    # Fallback: check data columns or compute
    if hasattr(model, "data"):
        if Col.RESID in model.data.columns:
            return model.data[Col.RESID].to_numpy()
        # Compute from y - fitted
        response = get_model_response(model)
        if response in model.data.columns:
            y = model.data[response].to_numpy()
            fitted = get_model_fitted(model)
            return y - fitted
    raise AttributeError(
        f"Cannot extract residuals from {type(model).__name__}. "
        "Model may not be fitted."
    )


def is_unified_model(model: Any) -> bool:
    """Check if model is the new unified model() class (or proxy).

    Args:
        model: A bossanova model or ModelResult proxy.

    Returns:
        True if model is the new unified model() class or a proxy wrapping one.
    """
    if type(model).__name__ == "model" and hasattr(model, "_spec"):
        return True
    return _is_model_proxy(model)
