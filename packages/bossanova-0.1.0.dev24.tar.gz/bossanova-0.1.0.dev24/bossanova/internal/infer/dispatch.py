"""Infer dispatch: routes .infer() calls to the correct inference backend.

Extracts the dispatch logic from model/core.py into a pure function.
Accepts all state objects as explicit params, returns an InferResult
container with populated fields.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

from attrs import frozen

if TYPE_CHECKING:
    import polars as pl

    from bossanova.internal.containers.structs.state import (
        CVState,
        DataBundle,
        FitState,
        InferenceState,
        JointTestState,
        MeeState,
        ModelSpec,
        PredictionState,
        ProfileState,
        ResamplesState,
        SimulationInferenceState,
        VaryingSpreadState,
    )

__all__ = [
    "InferResult",
    "dispatch_infer",
]


@frozen
class InferResult:
    """Immutable result of inference dispatch.

    Each field corresponds to a model attribute that may be updated by
    ``.infer()``. Fields left as ``None`` are not modified.

    Attributes:
        params_inference: Updated InferenceState (fit branch).
        mee: Updated MeeState or JointTestState (explore/joint branch).
        pred: Updated PredictionState (predict branch).
        cv: CVState from cross-validation (predict + cv).
        sim_inference: SimulationInferenceState (simulate branch).
        resamples: ResamplesState from bootstrap/permutation.
        varying_spread: Updated VaryingSpreadState (profile branch).
        profile: ProfileState from profile likelihood.
        last_op: Overridden last_op (only set by joint test branch).
    """

    params_inference: InferenceState | None = None
    mee: MeeState | JointTestState | None = None
    pred: PredictionState | None = None
    cv: CVState | None = None
    sim_inference: SimulationInferenceState | None = None
    resamples: ResamplesState | None = None
    varying_spread: VaryingSpreadState | None = None
    profile: ProfileState | None = None
    last_op: str | None = None


# Valid non-joint inference methods
_VALID_HOW = frozenset({"asymp", "boot", "perm", "cv", "profile"})


def dispatch_infer(
    *,
    how: str,
    conf_level: float,
    errors: str,
    null: float,
    alternative: str,
    last_op: str | None,
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    data: pl.DataFrame | None,
    link_override: str | None,
    mee: MeeState | JointTestState | None,
    pred: PredictionState | None,
    simulations: pl.DataFrame | None,
    varying_spread: VaryingSpreadState | None,
    is_mixed: bool,
    n_boot: int = 1000,
    n_perm: int = 1000,
    ci_type: str = "bca",
    seed: int | None = None,
    n_jobs: int = 1,
    save_resamples: bool = True,
    k: int | str = 10,
    n_steps: int = 20,
    verbose: bool = False,
    threshold: float | None = None,
    profile_auto: bool = True,
) -> InferResult:
    """Dispatch inference to the correct backend based on method and last operation.

    Pure function that implements the body of ``model.infer()``. Accepts all
    required state as explicit parameters and returns an ``InferResult``
    with the populated fields.

    Args:
        how: Inference method (``"asymp"``, ``"boot"``, ``"perm"``, ``"cv"``,
            ``"profile"``, ``"joint"``).
        conf_level: Confidence level (already normalized to 0–1 float).
        errors: Error structure (``"iid"``, ``"HC0"``–``"HC3"``, ``"hetero"``,
            ``"unequal_var"``).
        null: Null hypothesis value.
        alternative: Alternative hypothesis direction.
        last_op: Last model operation (``"fit"``, ``"explore"``, ``"predict"``,
            ``"simulate"``).
        spec: Model specification.
        bundle: Data bundle with design matrices.
        fit: Fit state with coefficients and vcov.
        data: Original data DataFrame.
        link_override: Non-default link function override (None uses spec).
        mee: Current MeeState or JointTestState from explore.
        pred: Current PredictionState from predict.
        simulations: Simulated data DataFrame.
        varying_spread: Current VaryingSpreadState.
        is_mixed: Whether the model has random effects.
        n_boot: Number of bootstrap samples (default: 1000).
        n_perm: Number of permutation samples (default: 1000).
        ci_type: Bootstrap CI type (``"bca"``, ``"percentile"``, ``"basic"``).
        seed: Random seed for reproducibility.
        n_jobs: Number of parallel jobs (default: 1).
        save_resamples: Whether to store raw resample arrays (default: True).
        k: Number of CV folds or ``"loo"`` (default: 10).
        n_steps: Profile likelihood steps (default: 20).
        verbose: Profile likelihood verbosity (default: False).
        threshold: Profile likelihood deviance threshold (default: None).
        profile_auto: Auto-compute profile CIs for variance components
            when ``how`` is ``"boot"`` or ``"perm"`` on a mixed model
            (default: True).

    Returns:
        InferResult with populated fields for the caller to assign.

    Raises:
        ValueError: If ``how``, ``null``, or ``alternative`` is invalid.
        ModelStateError: If required state is missing for the requested branch.
    """
    from bossanova.model.guards import ModelStateError

    # --- Joint tests: ANOVA-style F/chi2 per term (self-contained) ---
    if how == "joint":
        from bossanova.internal.marginal import compute_joint_test

        joint = compute_joint_test(
            fit=fit,
            bundle=bundle,
            spec=spec,
            errors=errors,
            data=data,
        )
        return InferResult(mee=joint, last_op="explore")

    # --- Validate how ---
    if how not in _VALID_HOW:
        raise ValueError(
            f"Unknown inference method: {how!r}. "
            f"Valid methods are: {sorted(_VALID_HOW)}"
        )

    # --- Validate null and alternative ---
    if not isinstance(null, (int, float)) or not math.isfinite(null):
        raise ValueError(f"null must be a finite float, got {null!r}")
    null = float(null)
    if alternative not in ("two-sided", "greater", "less"):
        raise ValueError(
            f"alternative must be 'two-sided', 'greater', or 'less', "
            f"got {alternative!r}"
        )

    # --- Profile likelihood (operates on variance components) ---
    if how == "profile":
        return _dispatch_profile(
            spec=spec,
            bundle=bundle,
            fit=fit,
            conf_level=conf_level,
            varying_spread=varying_spread,
            is_mixed=is_mixed,
            n_steps=n_steps,
            verbose=verbose,
            threshold=threshold,
        )

    # --- CV with stale predict state: reroute to fit branch ---
    # When last_op is "predict" but predictions were made on newdata (different
    # n than training data), CV can't attach training-data-sized arrays to the
    # prediction state.  Fall back to the fit branch which produces model-level
    # CV metrics (PRE, RMSE, etc.) — almost always what the user intended.
    if how == "cv" and last_op == "predict" and pred is not None:
        if len(pred.fitted) != bundle.n:
            last_op = "fit"

    # --- Dispatch based on last_op ---
    match last_op:
        case "fit":
            return _dispatch_fit(
                how=how,
                spec=spec,
                bundle=bundle,
                fit=fit,
                data=data,
                link_override=link_override,
                conf_level=conf_level,
                null=null,
                alternative=alternative,
                errors=errors,
                n_boot=n_boot,
                n_perm=n_perm,
                ci_type=ci_type,
                seed=seed,
                n_jobs=n_jobs,
                save_resamples=save_resamples,
                k=k,
                is_mixed=is_mixed,
                varying_spread=varying_spread,
                n_steps=n_steps,
                verbose=verbose,
                threshold=threshold,
                profile_auto=profile_auto,
            )
        case "explore":
            return _dispatch_explore(
                how=how,
                mee=mee,
                spec=spec,
                bundle=bundle,
                fit=fit,
                data=data,
                conf_level=conf_level,
                null=null,
                alternative=alternative,
                errors=errors,
                n_boot=n_boot,
                n_perm=n_perm,
                ci_type=ci_type,
                seed=seed,
                save_resamples=save_resamples,
            )
        case "predict":
            return _dispatch_predict(
                how=how,
                pred=pred,
                spec=spec,
                bundle=bundle,
                fit=fit,
                conf_level=conf_level,
                n_boot=n_boot,
                ci_type=ci_type,
                seed=seed,
                k=k,
            )
        case "simulate":
            return _dispatch_simulate(
                simulations=simulations,
                conf_level=conf_level,
            )
        case _:
            raise ModelStateError(
                "Call .fit(), .explore(), .predict(), or .simulate() first."
            )


# ---------------------------------------------------------------------------
# Private dispatch helpers (one per last_op branch)
# ---------------------------------------------------------------------------


def _dispatch_profile(
    *,
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    conf_level: float,
    varying_spread: VaryingSpreadState | None,
    is_mixed: bool,
    n_steps: int = 20,
    verbose: bool = False,
    threshold: float | None = None,
) -> InferResult:
    """Profile likelihood branch."""
    from bossanova.model.guards import ModelStateError

    if not is_mixed:
        raise ModelStateError(
            "Profile likelihood CIs are only available for mixed models. "
            "Use how='asymp' or how='boot' for non-mixed models."
        )
    from bossanova.internal.infer.asymptotic import (
        augment_spread_with_profile_ci,
    )
    from bossanova.internal.infer.profile import (
        compute_profile_inference,
    )

    profile = compute_profile_inference(
        spec=spec,
        bundle=bundle,
        fit=fit,
        conf_level=conf_level,
        n_steps=n_steps,
        verbose=verbose,
        threshold=threshold,
    )
    spread_out = varying_spread
    if varying_spread is not None:
        spread_out = augment_spread_with_profile_ci(varying_spread, profile, conf_level)
    return InferResult(profile=profile, varying_spread=spread_out)


def _dispatch_fit(
    *,
    how: str,
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    data: pl.DataFrame | None,
    link_override: str | None,
    conf_level: float,
    null: float,
    alternative: str,
    errors: str,
    n_boot: int = 1000,
    n_perm: int = 1000,
    ci_type: str = "bca",
    seed: int | None = None,
    n_jobs: int = 1,
    save_resamples: bool = True,
    k: int | str = 10,
    is_mixed: bool = False,
    varying_spread: VaryingSpreadState | None = None,
    n_steps: int = 20,
    verbose: bool = False,
    threshold: float | None = None,
    profile_auto: bool = True,
) -> InferResult:
    """Fit branch: parameter inference.

    When ``profile_auto`` is True and the model is mixed, also computes
    profile likelihood CIs for variance components after boot/perm.
    """
    from bossanova.internal.containers import build_params_resamples

    # CV needs special handling: compute_params_cv_inference returns both
    # InferenceState (PRE values) and CVState (model-level CV metrics).
    cv_state = None
    if how == "cv":
        from bossanova.internal.infer.cv import compute_params_cv_inference

        params_inf, cv_state = compute_params_cv_inference(
            spec=spec,
            bundle=bundle,
            data=data,
            conf_level=conf_level,
            link_override=link_override,
            k=k,
            seed=seed,
        )
    else:
        from bossanova.internal.infer.params import (
            dispatch_params_inference,
        )

        params_inf = dispatch_params_inference(
            how=how,
            spec=spec,
            bundle=bundle,
            fit=fit,
            data=data,
            conf_level=conf_level,
            null=null,
            alternative=alternative,
            errors=errors,
            link_override=link_override,
            n_boot=n_boot,
            n_perm=n_perm,
            ci_type=ci_type,
            seed=seed,
            n_jobs=n_jobs,
            save_resamples=save_resamples,
            k=k,
        )

    resamples = build_params_resamples(
        params_inf,
        fit.coef,
        tuple(bundle.X_names),
        how,
    )

    # Auto-compute profile CIs for variance components on mixed boot/perm
    profile_state = None
    spread_out = None
    if profile_auto and is_mixed and how in ("boot", "perm"):
        from bossanova.internal.infer.asymptotic import (
            augment_spread_with_profile_ci,
        )
        from bossanova.internal.infer.profile import (
            compute_profile_inference,
        )

        profile_state = compute_profile_inference(
            spec=spec,
            bundle=bundle,
            fit=fit,
            conf_level=conf_level,
            n_steps=n_steps,
            verbose=verbose,
            threshold=threshold,
        )
        if varying_spread is not None:
            spread_out = augment_spread_with_profile_ci(
                varying_spread, profile_state, conf_level
            )

    return InferResult(
        params_inference=params_inf,
        resamples=resamples,
        cv=cv_state,
        profile=profile_state,
        varying_spread=spread_out,
    )


def _dispatch_explore(
    *,
    how: str,
    mee: MeeState | JointTestState | None,
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    data: pl.DataFrame | None,
    conf_level: float,
    null: float,
    alternative: str,
    errors: str,
    n_boot: int = 1000,
    n_perm: int = 1000,
    ci_type: str = "bca",
    seed: int | None = None,
    save_resamples: bool = True,
) -> InferResult:
    """Explore branch: marginal effects inference."""
    from bossanova.internal.containers import build_mee_resamples
    from bossanova.internal.containers.structs.state import JointTestState
    from bossanova.internal.infer.mee import dispatch_mee_inference
    from bossanova.model.guards import ModelStateError

    if mee is None:
        raise ModelStateError("No explore results. Call .explore() first.")

    # Joint tests already have inference (F/chi2 stats + p-values)
    if isinstance(mee, JointTestState):
        return InferResult(mee=mee)

    mee_updated, mee_samples = dispatch_mee_inference(
        how=how,
        mee=mee,
        spec=spec,
        bundle=bundle,
        fit=fit,
        data=data,
        conf_level=conf_level,
        null=null,
        alternative=alternative,
        errors=errors,
        n_boot=n_boot,
        n_perm=n_perm,
        ci_type=ci_type,
        seed=seed,
        save_resamples=save_resamples,
    )
    resamples = build_mee_resamples(mee_updated, mee_samples, how)
    return InferResult(mee=mee_updated, resamples=resamples)


def _dispatch_predict(
    *,
    how: str,
    pred: PredictionState | None,
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    conf_level: float,
    n_boot: int = 1000,
    ci_type: str = "percentile",
    seed: int | None = None,
    k: int | str = 10,
) -> InferResult:
    """Predict branch: prediction inference."""
    from bossanova.internal.infer.prediction import (
        dispatch_prediction_inference,
    )
    from bossanova.model.guards import ModelStateError

    if pred is None:
        raise ModelStateError("No predictions. Call .predict() first.")

    pred_updated, cv = dispatch_prediction_inference(
        how=how,
        pred=pred,
        spec=spec,
        bundle=bundle,
        fit=fit,
        conf_level=conf_level,
        n_boot=n_boot,
        ci_type=ci_type,
        seed=seed,
        k=k,
    )
    return InferResult(pred=pred_updated, cv=cv)


def _dispatch_simulate(
    *,
    simulations: pl.DataFrame | None,
    conf_level: float,
) -> InferResult:
    """Simulate branch: simulation inference."""
    from bossanova.internal.infer.simulation import (
        compute_simulation_inference,
    )
    from bossanova.model.guards import ModelStateError

    if simulations is None:
        raise ModelStateError("No simulations. Call .simulate() first.")

    sim_inf = compute_simulation_inference(
        simulations=simulations,
        conf_level=conf_level,
    )
    return InferResult(sim_inference=sim_inf)
