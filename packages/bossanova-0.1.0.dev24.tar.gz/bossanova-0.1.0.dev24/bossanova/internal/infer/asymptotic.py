"""Asymptotic inference for parameters and predictions.

Provides orchestration functions for asymptotic (Wald-based) inference:
choosing vcov (robust vs standard), choosing df (Welch vs t vs z),
and wiring results into InferenceState/PredictionState containers.

The underlying math lives in ``internal/maths/inference/``. This module
is pure orchestration — it accepts containers and returns containers.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from attrs import evolve

from bossanova.internal.containers.schemas import Col
from bossanova.internal.maths.family import ESTIMATED_DISPERSION_FAMILIES

if TYPE_CHECKING:
    import polars as pl

    from bossanova.internal.containers import (
        DataBundle,
        FitState,
        InferenceState,
        ModelSpec,
        PredictionState,
    )
    from bossanova.internal.containers.structs.state import (
        ProfileState,
        VaryingSpreadState,
    )

__all__ = [
    "augment_spread_with_profile_ci",
    "compute_params_asymptotic",
    "compute_prediction_asymptotic",
    "resolve_error_type",
    "resolve_welch",
]


# =============================================================================
# Helpers
# =============================================================================


def resolve_error_type(errors: str, family: str = "gaussian") -> str:
    """Normalize errors parameter to canonical type string.

    Args:
        errors: User-facing error type (e.g. "HC3", "hetero", "unequal_var").
        family: Model family. When non-gaussian, "hetero" maps to HC0
            (matching main branch behavior) instead of HC3.

    Returns:
        Canonical type string ("HC0"-"HC3" or "unequal_var").

    Raises:
        ValueError: If errors is not a recognized type.
    """
    errors_upper = errors.upper()
    if errors_upper in ("HC0", "HC1", "HC2", "HC3"):
        return errors_upper
    if errors.lower() in ("hetero", "heteroscedastic"):
        return "HC0" if family != "gaussian" else "HC3"
    if errors.lower() == "unequal_var":
        return "unequal_var"
    raise ValueError(
        f"Unknown errors type: {errors!r}. "
        "Use 'HC0', 'HC1', 'HC2', 'HC3', 'hetero', or 'unequal_var'."
    )


def resolve_vcov(
    spec: "ModelSpec",
    bundle: "DataBundle",
    fit: "FitState",
    errors: str,
) -> np.ndarray:
    """Resolve variance-covariance matrix: robust (sandwich) or standard.

    Args:
        spec: Model specification.
        bundle: Data bundle with design matrix X.
        fit: Fit state with residuals and vcov.
        errors: Error type string (e.g. "HC3", "hetero").

    Returns:
        Variance-covariance matrix.

    Raises:
        ValueError: If HC2/HC3 requested for GLM/GLMER (leverage-based
            adjustments not well-defined for GLM).
        RuntimeError: If GLM FitState missing required IRLS fields.
    """
    hc_type = resolve_error_type(errors, family=spec.family)

    # --- Mixed models: cluster-robust (CR) estimators ---
    if spec.has_random_effects:
        cluster_ids = bundle.re_metadata.group_indices[
            bundle.re_metadata.grouping_vars[0]
        ]
        _HC_TO_CR = {"HC0": "CR0", "HC1": "CR1", "HC2": "CR2", "HC3": "CR3"}
        cr_type = _HC_TO_CR[hc_type]

        if spec.family != "gaussian":
            # GLMER: CR0/CR1 only (no leverage-based CR2/CR3)
            from bossanova.internal.maths.inference.sandwich import (
                compute_glm_cr_vcov,
            )

            if hc_type in ("HC2", "HC3"):
                raise ValueError(
                    f"GLMER only supports HC0 and HC1 robust SEs, not {hc_type}. "
                    "HC2/HC3 leverage adjustments are not well-defined for GLM."
                )
            if fit.irls_weights is None or fit.XtWX_inv is None:
                raise RuntimeError("GLMER FitState missing irls_weights or XtWX_inv.")
            return compute_glm_cr_vcov(
                X=bundle.X,
                residuals=fit.residuals,
                irls_weights=fit.irls_weights,
                cluster_ids=cluster_ids,
                XtWX_inv=fit.XtWX_inv,
                cr_type=cr_type,
            )

        # Gaussian lmer: CR0-CR3 all supported
        from bossanova.internal.maths.inference.sandwich import compute_cr_vcov

        XtX_inv = np.linalg.inv(bundle.X.T @ bundle.X)
        return compute_cr_vcov(
            X=bundle.X,
            residuals=fit.residuals,
            cluster_ids=cluster_ids,
            XtX_inv=XtX_inv,
            cr_type=cr_type,
        )

    # --- Non-mixed GLM: HC0/HC1 only ---
    if spec.family != "gaussian":
        from bossanova.internal.maths.inference.sandwich import compute_glm_hc_vcov

        if hc_type in ("HC2", "HC3"):
            raise ValueError(
                f"GLM only supports HC0 and HC1 robust SEs, not {hc_type}. "
                "HC2/HC3 leverage adjustments are not well-defined for GLM."
            )
        if fit.irls_weights is None or fit.XtWX_inv is None:
            raise RuntimeError("GLM FitState missing irls_weights or XtWX_inv.")
        return compute_glm_hc_vcov(
            X=bundle.X,
            residuals=fit.residuals,
            irls_weights=fit.irls_weights,
            XtWX_inv=fit.XtWX_inv,
            hc_type=hc_type,
        )

    # --- Gaussian LM: HC0-HC3 all supported ---
    from bossanova.internal.maths.inference.sandwich import compute_hc_vcov

    XtX_inv = np.linalg.inv(bundle.X.T @ bundle.X)
    return compute_hc_vcov(
        X=bundle.X,
        residuals=fit.residuals,
        XtX_inv=XtX_inv,
        hc_type=hc_type,
    )


def resolve_df(
    spec: "ModelSpec",
    bundle: "DataBundle",
    fit: "FitState",
    errors: str | None,
    data: "pl.DataFrame | None",
) -> float | np.ndarray | None:
    """Resolve degrees of freedom for inference.

    Returns residual df (families with estimated dispersion),
    per-coefficient Satterthwaite df (Gaussian mixed models),
    or None (z-distribution for fixed-dispersion families).

    For GLMs with estimated dispersion (Gaussian, Gamma, t-distribution),
    uses the t-distribution with residual df, matching R's ``summary.glm()``.
    For Gaussian mixed models (lmer), computes Satterthwaite df per coefficient,
    matching R's lmerTest default behavior.
    For families with fixed dispersion (Binomial, Poisson), uses the
    z-distribution (asymptotic normality).

    Note:
        Welch df (``errors='unequal_var'``) is handled upstream by
        ``resolve_welch()``, which returns both vcov and per-coefficient
        df together. This function is not called in that code path.

    Args:
        spec: Model specification.
        bundle: Data bundle with valid_mask.
        fit: Fit state with residuals and df_resid.
        errors: Error type string or None.
        data: Original data frame.

    Returns:
        Degrees of freedom (scalar, per-coefficient array, or None for z).
    """
    # Families with estimated dispersion use t-distribution with residual df
    if spec.family in ESTIMATED_DISPERSION_FAMILIES and not spec.has_random_effects:
        return fit.df_resid

    # Gaussian mixed models: Satterthwaite df (matches lmerTest default)
    if spec.family == "gaussian" and spec.has_random_effects and fit.theta is not None:
        from bossanova.internal.infer.satterthwaite_emm import (
            compute_satterthwaite_emm_df,
        )

        L = np.eye(len(fit.coef))
        return compute_satterthwaite_emm_df(bundle=bundle, fit=fit, spec=spec, L=L)

    # Fixed-dispersion families (binomial, poisson) use z-distribution
    return None


def resolve_welch(
    spec: "ModelSpec",
    bundle: "DataBundle",
    fit: "FitState",
    data: "pl.DataFrame | None",
) -> tuple[np.ndarray, np.ndarray]:
    """Compute both Welch sandwich vcov and per-coefficient Satterthwaite df.

    Shares the cell_info computation between vcov and df so the factor
    grouping is done only once. Returns per-coefficient df via the
    generalized Satterthwaite decomposition of the sandwich variance.

    For Gaussian mixed models (lmer), this provides a repeated-measures
    Welch analog: per-cell variance of marginal residuals ``y - X @ beta``
    is used instead of raw response variance, accounting for the fixed-effect
    structure while allowing unequal variances across factor cells.

    Note:
        This differs from R's approach. R's ``sandwich``/``emmeans``/``coeftest``
        use residual df (n - p) with sandwich SEs, ignoring the df correction
        entirely. Bossanova instead computes per-coefficient Satterthwaite df,
        which generalizes the classic Welch t-test to a regression framework:
        for a two-group ``y ~ factor(group)`` model, the slope's df exactly
        matches ``scipy.stats.ttest_ind(equal_var=False)`` and R's
        ``t.test(var.equal=FALSE)``.

    Args:
        spec: Model specification.
        bundle: Data bundle with design matrix X and valid_mask.
        fit: Fit state with residuals.
        data: Original data frame.

    Returns:
        Tuple of (welch_vcov, welch_df) where welch_df has shape (p,).

    Raises:
        ValueError: If model is not Gaussian, or no data, or no categorical
            variables in formula.
    """
    import polars as pl

    from bossanova.internal.maths.inference.welch import (
        compute_cell_info,
        compute_welch_vcov,
        extract_factors_from_formula,
        compute_welch_satterthwaite_df_per_coef,
    )

    if spec.family != "gaussian":
        # Welch-Satterthwaite DF is a Gaussian-specific concept. It adjusts
        # degrees of freedom for group-specific residual variances under
        # normality. For non-Gaussian families this is not meaningful because:
        #
        # - Fixed-dispersion families (binomial, Poisson) use z-based inference
        #   (asymptotic normality), so there are no DF to adjust.
        # - Estimated-dispersion families (Gamma, inverse Gaussian) model the
        #   mean-variance relationship through the variance function, which
        #   already accounts for heteroscedasticity.
        #
        # For heteroscedasticity-robust inference on GLMs, use errors='HC0'
        # or errors='HC1' (sandwich standard errors).
        alternatives = "Use errors='HC0' or errors='HC1' for robust standard errors."
        if spec.has_random_effects:
            alternatives = (
                "Use errors='HC0' or errors='HC1' for cluster-robust standard errors."
            )
        raise ValueError(
            f"errors='unequal_var' is not applicable to {spec.family} models.\n\n"
            "Welch-Satterthwaite degrees of freedom assume Gaussian residuals with "
            "group-specific variances. Non-Gaussian families already model the "
            "mean-variance relationship through their variance function "
            "(e.g., binomial: mu*(1-mu), Poisson: mu), making the Welch "
            "correction redundant and statistically inappropriate.\n\n"
            f"{alternatives}"
        )
    if data is None:
        raise ValueError(
            "errors='unequal_var' requires original data (not simulation-only models)."
        )

    factors = extract_factors_from_formula(spec.formula, data)
    if not factors:
        raise ValueError(
            "errors='unequal_var' requires at least one factor (categorical) "
            "variable in the formula. For arbitrary heteroscedasticity, "
            "use errors='hetero' instead."
        )

    valid_data = data.filter(pl.Series(bundle.valid_mask))
    cell_info = compute_cell_info(
        fit.residuals,
        valid_data,
        factors,
    )

    vcov = compute_welch_vcov(bundle.X, cell_info)
    df = compute_welch_satterthwaite_df_per_coef(bundle.X, cell_info)

    return vcov, df


# =============================================================================
# Public API
# =============================================================================


def compute_params_asymptotic(
    spec: "ModelSpec",
    bundle: "DataBundle",
    fit: "FitState",
    conf_level: float,
    errors: str | None = None,
    data: "pl.DataFrame | None" = None,
    null: float = 0.0,
    alternative: str = "two-sided",
) -> "InferenceState":
    """Compute asymptotic (Wald) inference for model parameters.

    Resolves vcov (robust via sandwich or standard from fit), resolves df
    (Welch, t, or z), and delegates to ``compute_coefficient_inference``.

    Args:
        spec: Model specification.
        bundle: Data bundle with design matrix X.
        fit: Fit state with coefficients and vcov.
        conf_level: Confidence level for intervals (e.g. 0.95).
        errors: Error type for robust SEs (e.g. "HC3", "hetero", "unequal_var")
            or None for standard errors.
        data: Original data frame (needed for Welch df with errors="unequal_var").
        null: Null hypothesis value (default 0.0).
        alternative: Alternative hypothesis direction (default "two-sided").

    Returns:
        InferenceState with SEs, test statistics, p-values, and CIs.
    """
    from bossanova.internal.containers import build_inference_state
    from bossanova.internal.maths.inference import compute_coefficient_inference

    coef = fit.coef

    # Determine vcov and df
    if errors == "unequal_var":
        # Welch: both vcov and df come from per-cell variances
        vcov, df = resolve_welch(spec, bundle, fit, data)
    else:
        # Standard or robust (sandwich) vcov
        if errors and errors not in ("iid", "auto"):
            vcov = resolve_vcov(spec, bundle, fit, errors)
        else:
            vcov = fit.vcov
        # Degrees of freedom
        df = resolve_df(spec, bundle, fit, errors, data)

    # Compute inference
    result = compute_coefficient_inference(
        coef=coef,
        vcov=vcov,
        df=df,
        conf_level=conf_level,
        null=null,
        alternative=alternative,
    )

    return build_inference_state(
        se=result.se,
        statistic=result.statistic,
        df=np.array(result.df_values),
        p_value=result.p_values,
        ci_lower=result.ci_lower,
        ci_upper=result.ci_upper,
        conf_level=conf_level,
        method="asymp",
        null=null,
        alternative=alternative,
    )


def compute_prediction_asymptotic(
    pred: "PredictionState",
    bundle: "DataBundle",
    fit: "FitState",
    spec: "ModelSpec",
    conf_level: float,
) -> "PredictionState":
    """Compute asymptotic inference for predictions via delta method.

    Computes standard errors using the delta method and confidence intervals
    using t or z critical values depending on the model family.

    Args:
        pred: Prediction state with fitted values.
        bundle: Data bundle with design matrix X.
        fit: Fit state with vcov and df_resid.
        spec: Model specification (family, random effects).
        conf_level: Confidence level for intervals (e.g. 0.95).

    Returns:
        Evolved PredictionState with se, ci_lower, ci_upper fields.
    """
    from bossanova.internal.maths.inference import (
        compute_ci,
        compute_t_critical,
        compute_z_critical,
        delta_method_se,
    )

    # Use the design matrix stored in PredictionState (training X or newdata X)
    X_pred = pred.X_pred if pred.X_pred is not None else bundle.X

    # Compute prediction SEs via delta method
    se = delta_method_se(X_pred, fit.vcov)

    # Determine critical value: t-distribution for estimated dispersion families
    if spec.family in ESTIMATED_DISPERSION_FAMILIES and not spec.has_random_effects:
        crit = compute_t_critical(conf_level, df=fit.df_resid)
    else:
        crit = compute_z_critical(conf_level)

    # Compute confidence intervals on fitted values
    ci_lower, ci_upper = compute_ci(pred.fitted, se, crit)

    return evolve(
        pred,
        se=se,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        interval_type="confidence",
        conf_level=conf_level,
    )


def augment_spread_with_profile_ci(
    spread: "VaryingSpreadState",
    profile: "ProfileState",
    conf_level: float,
) -> "VaryingSpreadState":
    """Augment variance components with profile likelihood confidence intervals.

    Maps profile CIs (on the SD scale) to variance component CIs by squaring,
    matching component names in ``spread.components`` to keys in ``profile.ci_sd``.

    Args:
        spread: Variance component state from .fit().
        profile: Profile likelihood state with ci_sd dict.
        conf_level: Confidence level used for CIs.

    Returns:
        Evolved VaryingSpreadState with ci_lower, ci_upper, conf_level, ci_method.
    """
    ci_lower_dict: dict[str, float] = {}
    ci_upper_dict: dict[str, float] = {}

    for comp_name in spread.components[Col.COMPONENT].to_list():
        if comp_name == Col.SIGMA2:
            # sigma2 CI from profile (stored as SD in ci_sd["Residual"])
            res_ci = profile.ci_sd.get("Residual")
            if res_ci:
                ci_lower_dict[comp_name] = res_ci[0] ** 2
                ci_upper_dict[comp_name] = res_ci[1] ** 2
            else:
                ci_lower_dict[comp_name] = float("nan")
                ci_upper_dict[comp_name] = float("nan")
        elif comp_name.startswith("tau2_"):
            # tau2_Group:Effect -> look up "Group:Effect" in ci_sd
            effect_key = comp_name[5:]  # strip "tau2_"
            sd_ci = profile.ci_sd.get(effect_key)
            if sd_ci:
                ci_lower_dict[comp_name] = sd_ci[0] ** 2
                ci_upper_dict[comp_name] = sd_ci[1] ** 2
            else:
                ci_lower_dict[comp_name] = float("nan")
                ci_upper_dict[comp_name] = float("nan")
        else:
            # rho, icc — no profile CIs available
            ci_lower_dict[comp_name] = float("nan")
            ci_upper_dict[comp_name] = float("nan")

    return evolve(
        spread,
        ci_lower=ci_lower_dict,
        ci_upper=ci_upper_dict,
        conf_level=conf_level,
        ci_method="profile",
    )
