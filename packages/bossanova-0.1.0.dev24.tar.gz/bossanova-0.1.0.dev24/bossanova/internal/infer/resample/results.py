"""Result containers for resampling procedures."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

import numpy as np

if TYPE_CHECKING:
    from jax import Array

__all__ = [
    "BootstrapResult",
]


@dataclass(frozen=True, slots=True)
class BootstrapResult:
    """Results from a bootstrap procedure.

    Attributes:
        observed: Observed statistics, shape [n_params].
        boot_samples: Bootstrap samples, shape [n_boot, n_params].
        ci_lower: Lower confidence bounds, shape [n_params].
        ci_upper: Upper confidence bounds, shape [n_params].
        param_names: Names of parameters.
        n_boot: Number of bootstrap samples.
        ci_type: Type of confidence interval ("percentile", "basic", or "bca").
        level: Confidence level (e.g., 0.95).
        term_types: Optional list indicating "fixef" or "ranef" for each parameter.
            Only populated for mixed model bootstrap with which="all".
    """

    observed: Array
    boot_samples: Array
    ci_lower: Array
    ci_upper: Array
    param_names: list[str]
    n_boot: int
    ci_type: Literal["percentile", "basic", "bca"]
    level: float
    term_types: list[str] | None = None

    @property
    def ci(self) -> tuple[Array, Array]:
        """Return confidence intervals as a tuple (lower, upper)."""
        return self.ci_lower, self.ci_upper

    @property
    def se(self) -> Array:
        """Bootstrap standard errors (std of boot_samples)."""
        return np.std(np.asarray(self.boot_samples), axis=0)
