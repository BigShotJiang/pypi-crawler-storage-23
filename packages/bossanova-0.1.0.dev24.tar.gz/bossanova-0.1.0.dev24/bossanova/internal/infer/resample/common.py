"""Common bootstrap execution patterns shared across model types.

This module provides the shared bootstrap execution loop (sequential/parallel),
NaN-aware CI computation, and failure-handling patterns that are duplicated
across lm.py, glm.py, and mixed.py.

All iteration functions should be standalone (not closures) for joblib
serialization compatibility.
"""

from typing import Any, Callable, Literal

import numpy as np
from joblib import Parallel, delayed
from tqdm import tqdm

from bossanova.internal.maths.rng import RNG
from bossanova.internal.infer.resample.core import (
    compute_bootstrap_ci_basic,
    compute_bootstrap_ci_bca,
    compute_bootstrap_ci_percentile,
)

# Type alias for arrays (works with both JAX and NumPy)
Array = Any

__all__ = [
    "Array",
    "collect_boot_samples",
    "compute_bootstrap_ci",
    "run_bootstrap_iterations",
    "warn_on_failures",
]


def run_bootstrap_iterations(
    iteration_fn: Callable[..., np.ndarray],
    rngs: list[RNG],
    n_boot: int,
    iter_kwargs: dict[str, Any],
    n_jobs: int = 1,
    verbose: bool = False,
    desc: str = "Bootstrap",
) -> list[np.ndarray]:
    """Run bootstrap iterations sequentially or in parallel via joblib.

    This is the shared execution loop used by all bootstrap functions.
    The iteration function must be a standalone callable (not a closure)
    to support joblib serialization.

    Args:
        iteration_fn: Standalone function for a single bootstrap iteration.
            Must accept ``rng`` as first keyword argument plus all ``iter_kwargs``.
        rngs: Pre-split RNG objects, one per iteration.
        n_boot: Number of bootstrap iterations.
        iter_kwargs: Keyword arguments forwarded to ``iteration_fn`` (excluding ``rng``).
        n_jobs: Number of parallel jobs. 1 = sequential, -1 = all cores.
        verbose: If True, show tqdm progress bar.
        desc: Description label for the progress bar.

    Returns:
        List of arrays from each iteration (may contain NaN for failures).
    """
    if n_jobs == 1:
        # Sequential execution with optional tqdm progress bar
        results: list[np.ndarray] = []
        for i in tqdm(range(n_boot), desc=desc, disable=not verbose):
            result = iteration_fn(rng=rngs[i], **iter_kwargs)
            results.append(result)
        return results

    # Parallel execution with joblib
    if verbose:
        print(f"Running {n_boot} {desc.lower()} iterations with {n_jobs} workers...")

    gen = Parallel(n_jobs=n_jobs, return_as="generator")(
        delayed(iteration_fn)(rng=rngs[i], **iter_kwargs) for i in range(n_boot)
    )
    results = list(tqdm(gen, total=n_boot, desc=desc, disable=not verbose))
    return results


def collect_boot_samples(
    boot_samples_list: list[np.ndarray],
    n_boot: int,
    context: str = "Bootstrap",
) -> tuple[np.ndarray, np.ndarray, int]:
    """Stack bootstrap samples and compute valid-sample mask.

    Counts NaN failures, issues a warning if > 10% failed, and returns
    the full array plus a boolean mask of valid (non-NaN) rows.

    Args:
        boot_samples_list: List of per-iteration coefficient arrays.
        n_boot: Total number of iterations attempted.
        context: Label for the warning message (e.g., "Bootstrap", "Permutation").

    Returns:
        Tuple of (boot_samples, valid_mask, n_failed) where:
            - boot_samples: stacked array of shape (n_boot, n_params)
            - valid_mask: boolean array of shape (n_boot,), True for non-NaN rows
            - n_failed: count of failed (all-NaN) iterations
    """
    boot_samples = np.stack(boot_samples_list, axis=0)
    valid_mask = ~np.any(np.isnan(boot_samples), axis=1)
    n_failed = int(np.sum(~valid_mask))

    warn_on_failures(n_failed, n_boot, context)

    return boot_samples, valid_mask, n_failed


def warn_on_failures(
    n_failed: int,
    n_total: int,
    context: str = "Bootstrap",
) -> None:
    """Emit a RuntimeWarning if failure rate exceeds 10%.

    Args:
        n_failed: Number of iterations that produced NaN.
        n_total: Total number of iterations attempted.
        context: Label for the warning message.
    """
    if n_failed > n_total * 0.1:
        import warnings

        warnings.warn(
            f"{context}: {n_failed}/{n_total} iterations failed to converge. "
            f"Consider increasing max_iter or checking data quality.",
            RuntimeWarning,
        )


def compute_bootstrap_ci(
    coef_obs: np.ndarray,
    boot_samples_valid: np.ndarray,
    ci_type: Literal["percentile", "basic", "bca"],
    level: float,
    jackknife_stats: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute bootstrap confidence intervals using the specified method.

    Dispatches to percentile, basic, or BCa CI computation from core.py.

    Args:
        coef_obs: Observed coefficient estimates, shape (p,).
        boot_samples_valid: Valid (non-NaN) bootstrap samples, shape (n_valid, p).
        ci_type: Type of CI: "percentile", "basic", or "bca".
        level: Confidence level (e.g. 0.95).
        jackknife_stats: Jackknife leave-one-out estimates, shape (n, p).
            Required for ``ci_type="bca"``.

    Returns:
        Tuple of (ci_lower, ci_upper) arrays, each shape (p,).

    Raises:
        ValueError: If ci_type is "bca" and jackknife_stats is None.
        ValueError: If ci_type is not recognized.
    """
    if ci_type == "percentile":
        return compute_bootstrap_ci_percentile(boot_samples_valid, level=level)
    elif ci_type == "basic":
        return compute_bootstrap_ci_basic(coef_obs, boot_samples_valid, level=level)
    elif ci_type == "bca":
        if jackknife_stats is None:
            raise ValueError("jackknife_stats required for ci_type='bca'")
        return compute_bootstrap_ci_bca(
            boot_stats=boot_samples_valid,
            observed=coef_obs,
            jackknife_stats=jackknife_stats,
            level=level,
        )
    else:
        raise ValueError(
            f"ci_type must be 'percentile', 'basic', or 'bca', got {ci_type}"
        )
