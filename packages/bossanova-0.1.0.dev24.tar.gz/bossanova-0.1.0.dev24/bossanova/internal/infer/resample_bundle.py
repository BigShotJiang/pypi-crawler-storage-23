"""Shared helper for resampling DataBundle observations."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import scipy.sparse as sp
from attrs import evolve

from bossanova.internal.containers import DataBundle

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import REInfo

__all__ = ["build_resampled_bundle"]


def _resample_re_metadata(
    meta: REInfo,
    indices: np.ndarray,
) -> REInfo:
    """Resample observation-level arrays within REInfo.

    REInfo contains three observation-level fields that must track
    the resampled rows: ``group_indices``, ``group_ids_list``, and
    ``X_re``.  Structural metadata (grouping_vars, n_groups, term_names,
    etc.) is unchanged because the group *identities* don't change —
    only which observations belong to each resample.

    Args:
        meta: Original REInfo (frozen attrs struct).
        indices: Integer or boolean index array used to resample X/y.

    Returns:
        New REInfo with resampled observation-level arrays.
    """
    new_group_indices = {k: v[indices] for k, v in meta.group_indices.items()}
    new_group_ids_list = [ids[indices] for ids in meta.group_ids_list]

    new_X_re: np.ndarray | list[np.ndarray] | None = None
    if meta.X_re is not None:
        if isinstance(meta.X_re, list):
            new_X_re = [x[indices] for x in meta.X_re]
        else:
            new_X_re = meta.X_re[indices]

    return evolve(
        meta,
        group_indices=new_group_indices,
        group_ids_list=new_group_ids_list,
        X_re=new_X_re,
    )


def build_resampled_bundle(bundle: DataBundle, indices: np.ndarray) -> DataBundle:
    """Create a new DataBundle by selecting observations at given indices.

    Handles dense X/y/valid_mask, sparse Z matrices, and observation-level
    REInfo fields (group_indices, group_ids_list, X_re).

    Args:
        bundle: Original data bundle.
        indices: Integer array of observation indices (may contain repeats
            for bootstrap, or be a boolean mask for jackknife).

    Returns:
        New DataBundle with resampled observations.
    """
    X_new = bundle.X[indices]
    y_new = bundle.y[indices]
    # Resampled bundles contain only valid observations by construction
    # (sampled from already-valid X/y), so valid_mask is all-True.
    n_resampled = int(indices.sum()) if indices.dtype == bool else len(indices)
    valid_mask_new = np.ones(n_resampled, dtype=bool)

    Z_new = None
    if bundle.Z is not None:
        if sp.issparse(bundle.Z):
            Z_new = bundle.Z[indices, :]
        else:
            Z_new = bundle.Z[indices]

    re_metadata_new = bundle.re_metadata
    if re_metadata_new is not None:
        re_metadata_new = _resample_re_metadata(re_metadata_new, indices)

    n_total = n_resampled

    return DataBundle(
        X=X_new,
        y=y_new,
        X_names=bundle.X_names,
        y_name=bundle.y_name,
        valid_mask=valid_mask_new,
        n_total=n_total,
        Z=Z_new,
        re_metadata=re_metadata_new,
        factor_levels=bundle.factor_levels,
    )
