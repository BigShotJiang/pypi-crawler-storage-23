"""Bootstrap inference methods.

Provides helper functions for bootstrap-based inference used by the model
class's infer(how='boot') method. Resampling logic is shared via
build_resampled_bundle().
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from attrs import evolve

from bossanova.internal.infer.resample_bundle import build_resampled_bundle

if TYPE_CHECKING:
    import polars as pl

    from bossanova.internal.containers import (
        DataBundle,
        FitState,
        InferenceState,
        MeeState,
        ModelSpec,
        PredictionState,
    )

__all__ = [
    "build_emm_reference_grid",
    "compute_bootstrap_params",
    "compute_bootstrap_pvalue",
    "compute_cluster_jackknife_coefs",
    "compute_jackknife_coefs",
    "compute_mee_bootstrap",
    "compute_params_bootstrap",
    "compute_params_bootstrap_mixed",
    "compute_prediction_bootstrap",
]


def _bootstrap_single(
    spec: "ModelSpec",
    bundle: "DataBundle",
    indices: np.ndarray,
    p: int,
) -> np.ndarray:
    """Fit a single bootstrap replicate. Used by compute_bootstrap_params."""
    from bossanova.internal.fit import (
        fit_model,
    )  # Deferred: avoid circular import between infer ↔ fit

    bundle_boot = build_resampled_bundle(bundle, indices)
    try:
        fit_state = fit_model(spec, bundle_boot)
        return fit_state.coef
    except Exception:
        return np.full(p, np.nan)


def compute_bootstrap_params(
    spec: "ModelSpec",
    bundle: "DataBundle",
    n_boot: int = 1000,
    seed: int | None = None,
    n_jobs: int = 1,
) -> np.ndarray:
    """Generate bootstrap distribution of coefficient estimates.

    Uses case resampling: resample observations with replacement,
    refit the model, and collect coefficient estimates.

    Args:
        spec: Model specification.
        bundle: Data bundle with X, y, etc.
        n_boot: Number of bootstrap samples.
        seed: Random seed for reproducibility.
        n_jobs: Number of parallel jobs. 1 (default) for sequential,
            -1 for all available cores.

    Returns:
        Array of shape (n_boot, n_params) with bootstrap coefficient estimates.
    """
    import sys

    from bossanova.internal.maths.rng import RNG
    from bossanova.internal.infer.resample.core import generate_bootstrap_indices

    # Clamp to sequential in Pyodide (no process forking in WASM)
    if n_jobs != 1 and sys.platform == "emscripten":
        import warnings

        warnings.warn(
            "Parallel bootstrap not available in Pyodide; falling back to sequential.",
            UserWarning,
            stacklevel=2,
        )
        n_jobs = 1

    rng = RNG.from_seed(seed)
    n = bundle.X.shape[0]
    p = len(bundle.X_names)

    # Generate all bootstrap indices at once
    boot_indices = generate_bootstrap_indices(rng, n, n_boot)

    # LM fast path: batched OLS via chunked vmap
    is_lm = (
        spec.family == "gaussian"
        and spec.link == "identity"
        and not spec.has_random_effects
    )

    if is_lm:
        from bossanova.internal.infer.resample.lm_operators import (
            compute_batched_ols_bootstrap,
        )

        return compute_batched_ols_bootstrap(boot_indices, bundle.X, bundle.y)

    if n_jobs == 1:
        # Sequential execution
        boot_coefs = np.zeros((n_boot, p))
        for b in range(n_boot):
            boot_coefs[b] = _bootstrap_single(spec, bundle, boot_indices[b], p)
    else:
        # Parallel execution via joblib
        from joblib import Parallel, delayed

        results = Parallel(n_jobs=n_jobs, return_as="generator")(
            delayed(_bootstrap_single)(spec, bundle, boot_indices[b], p)
            for b in range(n_boot)
        )
        boot_coefs = np.array(list(results))

    return boot_coefs


def compute_jackknife_coefs(
    spec: "ModelSpec",
    bundle: "DataBundle",
) -> np.ndarray:
    """Compute leave-one-out jackknife coefficient estimates.

    Used for BCa acceleration factor calculation.

    Args:
        spec: Model specification.
        bundle: Data bundle.

    Returns:
        Array of shape (n, n_params) with jackknife coefficient estimates.
    """
    from bossanova.internal.fit import (
        fit_model,
    )  # Deferred: avoid circular import between infer ↔ fit

    n = bundle.X.shape[0]
    p = len(bundle.X_names)

    jack_coefs = np.zeros((n, p))

    for i in range(n):
        mask = np.ones(n, dtype=bool)
        mask[i] = False

        bundle_jack = build_resampled_bundle(bundle, mask)

        try:
            fit_state = fit_model(spec, bundle_jack)
            jack_coefs[i] = fit_state.coef
        except Exception:
            jack_coefs[i] = np.nan

    return jack_coefs


def compute_cluster_jackknife_coefs(
    spec: "ModelSpec",
    bundle: "DataBundle",
) -> np.ndarray:
    """Compute leave-one-group-out jackknife coefficient estimates.

    For mixed models, the appropriate jackknife unit is the cluster (group),
    not individual observations. This function drops all observations from
    one group at a time and refits, producing one coefficient vector per group.

    Used for BCa acceleration factor calculation in mixed models.

    Args:
        spec: Model specification.
        bundle: Data bundle with RE metadata.

    Returns:
        Array of shape (n_groups, n_params) with jackknife coefficient estimates.

    Raises:
        ValueError: If bundle has no RE metadata (not a mixed model).
    """
    from bossanova.internal.fit import (
        fit_model,
    )  # Deferred: avoid circular import between infer ↔ fit

    if bundle.re_metadata is None:
        raise ValueError(
            "compute_cluster_jackknife_coefs requires a mixed model "
            "(bundle must have re_metadata)."
        )

    # Use first grouping variable for cluster jackknife
    grouping_var = bundle.re_metadata.grouping_vars[0]
    group_indices = bundle.re_metadata.group_indices[grouping_var]

    unique_groups = np.unique(group_indices)
    n_groups = len(unique_groups)
    p = len(bundle.X_names)
    n = bundle.X.shape[0]

    jack_coefs = np.zeros((n_groups, p))

    for i, group_id in enumerate(unique_groups):
        # Boolean mask excluding all observations from this group
        mask = np.ones(n, dtype=bool)
        mask[group_indices == group_id] = False

        bundle_jack = build_resampled_bundle(bundle, mask)

        try:
            fit_state = fit_model(spec, bundle_jack)
            jack_coefs[i] = fit_state.coef
        except Exception:
            jack_coefs[i] = np.nan

    return jack_coefs


def compute_bootstrap_pvalue(
    observed: np.ndarray,
    boot_samples: np.ndarray,
    null: float = 0.0,
    alternative: str = "two-sided",
) -> np.ndarray:
    """Compute bootstrap p-values.

    Uses the proportion of bootstrap samples as extreme or more extreme
    than the observed value (relative to null).

    Args:
        observed: Observed statistics.
        boot_samples: Bootstrap sample statistics, shape (n_boot, n_params).
        null: Null hypothesis value (default 0.0).
        alternative: "two-sided" (default), "greater", or "less".

    Returns:
        P-values for each parameter.
    """
    n_params = len(observed)
    p_values = np.zeros(n_params)

    for i in range(n_params):
        obs = observed[i]
        boot = boot_samples[:, i]

        # Remove NaN samples
        boot = boot[~np.isnan(boot)]

        if len(boot) == 0:
            p_values[i] = np.nan
            continue

        if obs == null:
            p_values[i] = 1.0
        elif alternative == "two-sided":
            # Count bootstraps that cross null
            if obs > null:
                count = np.sum(boot <= null)
            else:
                count = np.sum(boot >= null)
            # Two-sided: double the one-sided p-value
            p_values[i] = min(1.0, 2.0 * (count + 1) / (len(boot) + 1))
        elif alternative == "greater":
            # One-sided greater: proportion of bootstraps <= null
            count = np.sum(boot <= null)
            p_values[i] = (count + 1) / (len(boot) + 1)
        elif alternative == "less":
            # One-sided less: proportion of bootstraps >= null
            count = np.sum(boot >= null)
            p_values[i] = (count + 1) / (len(boot) + 1)

    return p_values


def compute_params_bootstrap(
    spec: "ModelSpec",
    bundle: "DataBundle",
    fit: "FitState",
    conf_level: float = 0.95,
    n_boot: int = 1000,
    ci_type: str = "bca",
    seed: int | None = None,
    save_resamples: bool = True,
    n_jobs: int = 1,
    null: float = 0.0,
    alternative: str = "two-sided",
) -> "InferenceState":
    """Compute bootstrap inference for parameters.

    Args:
        spec: Model specification.
        bundle: Data bundle.
        fit: Current fit state.
        conf_level: Confidence level for intervals.
        n_boot: Number of bootstrap samples.
        ci_type: CI type ("bca", "percentile", "basic").
        seed: Random seed for reproducibility.
        save_resamples: If True (default), store raw bootstrap samples
            in InferenceState. If False, discard to save memory.
        n_jobs: Number of parallel jobs. 1 (default) for sequential,
            -1 for all available cores.
        null: Null hypothesis value (default 0.0).
        alternative: Alternative hypothesis direction (default "two-sided").

    Returns:
        InferenceState with bootstrap-based SE, CI, and p-values.
    """
    from bossanova.internal.containers import build_inference_state
    from bossanova.internal.infer.resample.core import (
        BCa_MIN_NBOOT,
        compute_bootstrap_ci_basic,
        compute_bootstrap_ci_bca,
        compute_bootstrap_ci_percentile,
    )

    # Get bootstrap coefficient distribution
    boot_coefs = compute_bootstrap_params(
        spec, bundle, n_boot=n_boot, seed=seed, n_jobs=n_jobs
    )

    # Observed coefficients
    observed = fit.coef

    # Compute bootstrap standard errors
    se = np.nanstd(boot_coefs, axis=0)

    # Compute confidence intervals based on ci_type
    if ci_type == "bca":
        if n_boot < BCa_MIN_NBOOT:
            raise ValueError(
                f"BCa confidence intervals require at least {BCa_MIN_NBOOT} "
                f"bootstrap samples, got n_boot={n_boot}. "
                "Use ci_type='percentile' for small n_boot."
            )
        if bundle.re_metadata is not None:
            jack_coefs = compute_cluster_jackknife_coefs(spec, bundle)
        else:
            jack_coefs = compute_jackknife_coefs(spec, bundle)
        ci_lower, ci_upper = compute_bootstrap_ci_bca(
            boot_stats=boot_coefs,
            observed=observed,
            jackknife_stats=jack_coefs,
            level=conf_level,
        )
    elif ci_type == "percentile":
        ci_lower, ci_upper = compute_bootstrap_ci_percentile(
            boot_coefs, level=conf_level
        )
    elif ci_type == "basic":
        ci_lower, ci_upper = compute_bootstrap_ci_basic(
            observed, boot_coefs, level=conf_level
        )
    else:
        raise ValueError(
            f"Unknown ci_type: {ci_type!r}. "
            "Valid options: 'bca', 'percentile', 'basic'."
        )

    ci_lower = np.asarray(ci_lower)
    ci_upper = np.asarray(ci_upper)

    # Compute test statistics: (estimate - null) / SE
    centered = observed - null
    statistic = np.divide(
        centered, se, out=np.full_like(observed, np.nan), where=se != 0
    )

    # Compute p-values from bootstrap distribution
    p_value = compute_bootstrap_pvalue(
        observed, boot_coefs, null=null, alternative=alternative
    )

    # Degrees of freedom: number of bootstrap resamples
    df = np.full(len(observed), float(n_boot))

    return build_inference_state(
        se=se,
        statistic=statistic,
        df=df,
        p_value=p_value,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        conf_level=conf_level,
        method="boot",
        null=null,
        alternative=alternative,
        n_resamples=n_boot,
        boot_samples=boot_coefs if save_resamples else None,
    )


def compute_params_bootstrap_mixed(
    spec: "ModelSpec",
    bundle: "DataBundle",
    fit: "FitState",
    conf_level: float = 0.95,
    n_boot: int = 1000,
    ci_type: str = "bca",
    seed: int | None = None,
    save_resamples: bool = True,
    n_jobs: int = 1,
    null: float = 0.0,
    alternative: str = "two-sided",
) -> "InferenceState":
    """Compute bootstrap inference for mixed model parameters.

    Uses parametric bootstrap (simulate y* from fitted model, refit) via
    the existing ``lmer_bootstrap()`` / ``glmer_bootstrap()`` infrastructure
    instead of observation-level case resampling. This properly respects
    the cluster structure and matches R's ``bootMer(type="parametric")``.

    BCa acceleration uses cluster (leave-one-group-out) jackknife when
    ``ci_type="bca"`` is requested.

    Args:
        spec: Model specification (must have ``has_random_effects=True``).
        bundle: Data bundle with RE metadata.
        fit: Current fit state with ``coef``, ``theta``, ``sigma``.
        conf_level: Confidence level for intervals.
        n_boot: Number of bootstrap samples.
        ci_type: CI type (``"bca"``, ``"percentile"``, ``"basic"``).
        seed: Random seed for reproducibility.
        save_resamples: If True (default), store raw bootstrap samples
            in InferenceState. If False, discard to save memory.
        n_jobs: Number of parallel jobs. 1 (default) for sequential,
            -1 for all available cores.
        null: Null hypothesis value (default 0.0).
        alternative: Alternative hypothesis direction (default ``"two-sided"``).

    Returns:
        InferenceState with bootstrap-based SE, CI, and p-values.
    """
    import sys

    from bossanova.internal.containers import build_inference_state
    from bossanova.internal.infer.resample.core import (
        BCa_MIN_NBOOT,
        compute_bootstrap_ci_basic,
        compute_bootstrap_ci_bca,
        compute_bootstrap_ci_percentile,
    )

    # Clamp to sequential in Pyodide (no process forking in WASM)
    if sys.platform == "emscripten":
        n_jobs = 1

    # ---- Extract from containers ----
    re_meta = bundle.re_metadata
    assert re_meta is not None, "Mixed model bootstrap requires RE metadata"

    X = bundle.X
    Z = bundle.Z
    y = bundle.y
    weights = bundle.weights
    n_groups_list = re_meta.n_groups_list
    re_structure = re_meta.re_structure
    metadata = re_meta.metadata
    X_names = list(spec.fixed_terms)
    beta = fit.coef
    theta = fit.theta
    sigma = fit.sigma

    # ---- Dispatch to existing parametric bootstrap ----
    if spec.family == "gaussian":
        from bossanova.internal.infer.resample.lmer import lmer_bootstrap

        result = lmer_bootstrap(
            X=X,
            Z=Z,
            y=y,
            X_names=X_names,
            theta=theta,
            beta=beta,
            sigma=sigma,
            n_groups_list=n_groups_list,
            re_structure=re_structure,
            metadata=metadata,
            n_boot=n_boot,
            seed=seed,
            boot_type="parametric",
            ci_type="percentile",  # We compute our own CIs below
            method=spec.method.upper(),
            which="fixef",
            n_jobs=n_jobs,
            group_names=list(re_meta.grouping_vars),
            random_names=re_meta.random_names,
        )
    else:
        from bossanova.internal.maths.family.create import build_family
        from bossanova.internal.infer.resample.glmer import glmer_bootstrap

        family_obj = build_family(spec.family, spec.link)
        result = glmer_bootstrap(
            X=X,
            Z=Z,
            y=y,
            X_names=X_names,
            theta=theta,
            beta=beta,
            family=family_obj,
            n_groups_list=n_groups_list,
            re_structure=re_structure,
            metadata=metadata,
            weights=weights,
            n_boot=n_boot,
            seed=seed,
            boot_type="parametric",
            ci_type="percentile",  # We compute our own CIs below
            n_jobs=n_jobs,
        )

    # ---- Build inference from BootstrapResult ----
    boot_coefs = np.asarray(result.boot_samples)
    observed = fit.coef

    # Standard errors
    se = np.nanstd(boot_coefs, axis=0)

    # Confidence intervals
    if ci_type == "bca":
        if n_boot < BCa_MIN_NBOOT:
            raise ValueError(
                f"BCa confidence intervals require at least {BCa_MIN_NBOOT} "
                f"bootstrap samples, got n_boot={n_boot}. "
                "Use ci_type='percentile' for small n_boot."
            )
        jack_coefs = compute_cluster_jackknife_coefs(spec, bundle)
        ci_lower, ci_upper = compute_bootstrap_ci_bca(
            boot_stats=boot_coefs,
            observed=observed,
            jackknife_stats=jack_coefs,
            level=conf_level,
        )
    elif ci_type == "percentile":
        ci_lower, ci_upper = compute_bootstrap_ci_percentile(
            boot_coefs, level=conf_level
        )
    elif ci_type == "basic":
        ci_lower, ci_upper = compute_bootstrap_ci_basic(
            observed, boot_coefs, level=conf_level
        )
    else:
        raise ValueError(
            f"Unknown ci_type: {ci_type!r}. "
            "Valid options: 'bca', 'percentile', 'basic'."
        )

    ci_lower = np.asarray(ci_lower)
    ci_upper = np.asarray(ci_upper)

    # Test statistics and p-values
    centered = observed - null
    statistic = np.divide(
        centered, se, out=np.full_like(observed, np.nan), where=se != 0
    )
    p_value = compute_bootstrap_pvalue(
        observed, boot_coefs, null=null, alternative=alternative
    )

    # Degrees of freedom: number of bootstrap resamples
    df = np.full(len(observed), float(n_boot))

    return build_inference_state(
        se=se,
        statistic=statistic,
        df=df,
        p_value=p_value,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        conf_level=conf_level,
        method="boot",
        null=null,
        alternative=alternative,
        n_resamples=n_boot,
        boot_samples=boot_coefs if save_resamples else None,
    )


def build_emm_reference_grid(
    data: pl.DataFrame,
    bundle: "DataBundle",
    focal_var: str,
) -> np.ndarray:
    """Build reference grid X matrix for EMM computation.

    Args:
        data: The data DataFrame.
        bundle: Data bundle.
        focal_var: The focal variable for EMMs.

    Returns:
        Reference design matrix, shape (n_levels, n_params).
    """
    levels = data[focal_var].unique().sort().to_list()

    X_names = list(bundle.X_names)
    p = len(X_names)
    n_levels = len(levels)

    X_ref = np.zeros((n_levels, p))
    X_means = bundle.X.mean(axis=0)

    for i, level in enumerate(levels):
        for j, name in enumerate(X_names):
            if name == "Intercept":
                X_ref[i, j] = 1.0
            elif name.startswith(f"{focal_var}["):
                dummy_level = name[len(focal_var) + 1 : -1]
                X_ref[i, j] = 1.0 if dummy_level == level else 0.0
            else:
                X_ref[i, j] = X_means[j]

    return X_ref


def compute_mee_bootstrap(
    spec: "ModelSpec",
    bundle: "DataBundle",
    mee: "MeeState",
    data: pl.DataFrame,
    conf_level: float = 0.95,
    n_boot: int = 1000,
    ci_type: str = "bca",
    seed: int | None = None,
    null: float = 0.0,
    alternative: str = "two-sided",
    save_resamples: bool = True,
) -> "tuple[MeeState, np.ndarray | None]":
    """Compute bootstrap inference for marginal effects.

    Args:
        spec: Model specification.
        bundle: Data bundle.
        mee: Current MEE state.
        data: The data DataFrame.
        conf_level: Confidence level for intervals.
        n_boot: Number of bootstrap samples.
        ci_type: CI type ("bca", "percentile", "basic").
        seed: Random seed for reproducibility.
        null: Null hypothesis value (default 0.0).
        alternative: Alternative hypothesis direction (default "two-sided").
        save_resamples: If True (default), return raw bootstrap samples
            alongside the MeeState. If False, discard to save memory.

    Returns:
        Tuple of (MeeState augmented with bootstrap inference,
        raw bootstrap samples array or None).
    """
    from bossanova.internal.maths.rng import RNG
    from bossanova.internal.fit import (
        fit_model,
    )  # Deferred: avoid circular import between infer ↔ fit
    from bossanova.internal.infer.resample.core import (
        BCa_MIN_NBOOT,
        compute_bootstrap_ci_basic,
        compute_bootstrap_ci_bca,
        compute_bootstrap_ci_percentile,
        generate_bootstrap_indices,
    )

    rng = RNG.from_seed(seed)
    n = bundle.X.shape[0]
    n_estimates = len(mee.estimate)

    boot_indices = generate_bootstrap_indices(rng, n, n_boot)
    boot_estimates = np.zeros((n_boot, n_estimates))

    focal_var = mee.focal_var
    mee_type = mee.type

    # Determine whether response-scale recomputation is needed
    has_link_emm = mee.link is not None and mee.L_matrix_link is not None
    has_boot_slopes = (
        mee._boot_X_plus is not None
        and mee._boot_X_minus is not None
        and mee._boot_delta is not None
        and mee.link is not None
    )

    if has_link_emm or has_boot_slopes:
        from bossanova.internal.maths.family.links import apply_link_inverse

    for b in range(n_boot):
        bundle_boot = build_resampled_bundle(bundle, boot_indices[b])

        try:
            fit_state = fit_model(spec, bundle_boot)

            if has_boot_slopes:
                # Exact g-computation AME per combo for response-scale slopes
                eta_plus = mee._boot_X_plus @ fit_state.coef
                eta_minus = mee._boot_X_minus @ fit_state.coef
                pred_plus = np.asarray(apply_link_inverse(mee.link, eta_plus))
                pred_minus = np.asarray(apply_link_inverse(mee.link, eta_minus))
                boot_estimates[b] = (pred_plus - pred_minus) / mee._boot_delta
            elif has_link_emm:
                # Exact response-scale EMMs: g⁻¹(X_ref @ coef_boot)
                link_pred = mee.L_matrix_link @ fit_state.coef
                boot_estimates[b] = np.asarray(apply_link_inverse(mee.link, link_pred))
            elif mee.L_matrix is not None:
                # Link-scale or identity link: L @ coef is exact
                boot_estimates[b] = mee.L_matrix @ fit_state.coef
            elif mee_type == "means":
                X_ref = build_emm_reference_grid(data, bundle, focal_var)
                boot_estimates[b] = X_ref @ fit_state.coef
            elif mee_type == "slopes":
                if focal_var in bundle.X_names:
                    idx_var = list(bundle.X_names).index(focal_var)
                    boot_estimates[b] = fit_state.coef[idx_var]
                else:
                    boot_estimates[b] = np.nan
            else:
                boot_estimates[b] = np.nan
        except Exception:
            boot_estimates[b] = np.nan

    observed = mee.estimate
    se = np.nanstd(boot_estimates, axis=0)

    if ci_type == "bca":
        if n_boot < BCa_MIN_NBOOT:
            raise ValueError(
                f"BCa requires at least {BCa_MIN_NBOOT} bootstrap samples."
            )
        ci_lower, ci_upper = compute_bootstrap_ci_bca(
            boot_stats=boot_estimates,
            observed=observed,
            jackknife_stats=None,
            level=conf_level,
        )
    elif ci_type == "percentile":
        ci_lower, ci_upper = compute_bootstrap_ci_percentile(
            boot_estimates, level=conf_level
        )
    elif ci_type == "basic":
        ci_lower, ci_upper = compute_bootstrap_ci_basic(
            observed, boot_estimates, level=conf_level
        )
    else:
        raise ValueError(f"Unknown ci_type: {ci_type!r}.")

    ci_lower = np.asarray(ci_lower)
    ci_upper = np.asarray(ci_upper)

    centered = observed - null
    statistic = np.divide(
        centered, se, out=np.full_like(observed, np.nan), where=se != 0
    )
    p_value = compute_bootstrap_pvalue(
        observed, boot_estimates, null=null, alternative=alternative
    )
    df = np.full(n_estimates, float(n_boot))

    augmented = evolve(
        mee,
        se=se,
        df=df,
        statistic=statistic,
        p_value=p_value,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        conf_level=conf_level,
    )
    return augmented, boot_estimates if save_resamples else None


def compute_prediction_bootstrap(
    spec: "ModelSpec",
    bundle: "DataBundle",
    pred: "PredictionState",
    conf_level: float = 0.95,
    n_boot: int = 1000,
    ci_type: str = "percentile",
    seed: int | None = None,
) -> "PredictionState":
    """Compute bootstrap inference for predictions.

    Args:
        spec: Model specification.
        bundle: Data bundle.
        pred: Current prediction state.
        conf_level: Confidence level for intervals.
        n_boot: Number of bootstrap samples.
        ci_type: CI type ("percentile", "basic").
        seed: Random seed for reproducibility.

    Returns:
        PredictionState augmented with bootstrap inference.
    """
    from bossanova.internal.maths.rng import RNG
    from bossanova.internal.fit import (
        fit_model,
    )  # Deferred: avoid circular import between infer ↔ fit
    from bossanova.internal.infer.resample.core import (
        compute_bootstrap_ci_basic,
        compute_bootstrap_ci_percentile,
        generate_bootstrap_indices,
    )

    rng = RNG.from_seed(seed)
    n = bundle.X.shape[0]
    n_pred = len(pred.fitted)

    boot_indices = generate_bootstrap_indices(rng, n, n_boot)
    boot_predictions = np.zeros((n_boot, n_pred))
    X_pred = pred.X_pred if pred.X_pred is not None else bundle.X

    for b in range(n_boot):
        bundle_boot = build_resampled_bundle(bundle, boot_indices[b])

        try:
            fit_state = fit_model(spec, bundle_boot)
            boot_predictions[b] = X_pred @ fit_state.coef
        except Exception:
            boot_predictions[b] = np.nan

    observed = pred.fitted
    se = np.nanstd(boot_predictions, axis=0)

    if ci_type == "percentile":
        ci_lower, ci_upper = compute_bootstrap_ci_percentile(
            boot_predictions, level=conf_level
        )
    elif ci_type == "basic":
        ci_lower, ci_upper = compute_bootstrap_ci_basic(
            observed, boot_predictions, level=conf_level
        )
    elif ci_type == "bca":
        raise ValueError(
            "BCa is not recommended for predictions. Use 'percentile' instead."
        )
    else:
        raise ValueError(f"Unknown ci_type: {ci_type!r}.")

    ci_lower = np.asarray(ci_lower)
    ci_upper = np.asarray(ci_upper)

    return evolve(
        pred,
        se=se,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        interval_type="confidence",
        conf_level=conf_level,
    )
