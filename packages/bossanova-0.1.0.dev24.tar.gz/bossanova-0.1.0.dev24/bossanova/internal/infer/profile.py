"""Profile likelihood inference for variance components.

Builds a deviance function adapter from the model's internal state
and runs profile_likelihood() to compute CIs for variance components.

Internal exports:
    compute_profile_inference: Profile likelihood CIs for mixed models.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from bossanova.internal.containers import DataBundle, FitState, ModelSpec
    from bossanova.internal.containers.structs.state import ProfileState

__all__ = [
    "compute_profile_inference",
]


class _ProfileAdapter:
    """Lightweight adapter satisfying MixedModelProtocol for profile_likelihood.

    Wraps the unified model's internal state into the interface expected
    by ``profile_likelihood()``, avoiding dependency on the model class.

    Args:
        theta: Optimal random-effects parameter vector.
        sigma: Residual standard deviation.
        deviance: Deviance at optimal theta.
        deviance_fn: Callable mapping theta -> deviance.
        group_names: List of grouping variable names.
        random_names: Random effect names (list or dict for multi-factor).
        y: Response vector.
        X: Fixed-effects design matrix.
        re_structure: Random-effects structure specification.
        metadata: Random-effects metadata list.
    """

    def __init__(
        self,
        theta: np.ndarray,
        sigma: float,
        deviance: float,
        deviance_fn: Callable[[np.ndarray], float],
        group_names: list[str],
        random_names: "list[str] | dict[str, list[str]]",
        y: np.ndarray,
        X: np.ndarray,
        re_structure: "str | list[str]",
        metadata: list[dict],
    ) -> None:
        self._theta = theta.copy()
        self._sigma = sigma
        self._deviance = deviance
        self._deviance_fn = deviance_fn
        self._group_names = group_names
        self._random_names = random_names
        self._y = y
        self._valid_mask = np.ones(len(y), dtype=bool)
        self._X = X
        self._re_structure = re_structure
        self._metadata = metadata

    def get_theta_lower_bounds(self, n_theta: int) -> list[float]:
        """Return lower bounds for theta parameters.

        Args:
            n_theta: Number of theta parameters.

        Returns:
            List of lower bounds (0.0 for diagonal, -inf for off-diagonal).
        """
        from bossanova.internal.maths.solvers.heuristics import get_theta_lower_bounds

        return get_theta_lower_bounds(n_theta, self._re_structure, self._metadata)

    def _get_re_structure(self) -> "str | list[str]":
        """Return the random-effects structure.

        Returns:
            RE structure string or list of strings for multi-factor models.
        """
        return self._re_structure


def compute_profile_inference(
    spec: "ModelSpec",
    bundle: "DataBundle",
    fit: "FitState",
    conf_level: float = 0.95,
    *,
    n_steps: int = 20,
    verbose: bool = False,
    threshold: float | None = None,
) -> "ProfileState":
    """Compute profile likelihood CIs for variance components.

    Builds a deviance function adapter from the unified model's internal
    state and runs profile_likelihood(). Returns a ProfileState with
    profile traces, splines, and CIs on the theta and SD scales.

    Args:
        spec: Model specification.
        bundle: Data bundle with X, Z, y, and re_metadata.
        fit: Fit state with theta, sigma, and variance components.
        conf_level: Confidence level for profile CIs.
        n_steps: Number of profiling steps (default: 20).
        verbose: Print profiling progress (default: False).
        threshold: Custom deviance threshold for CIs (default: None, uses
            chi-squared quantile).

    Returns:
        ProfileState with profile traces and CIs.
    """
    from bossanova.internal.containers.structs.state import ProfileState
    from bossanova.internal.maths.inference.profile import profile_likelihood
    from bossanova.internal.maths.solvers.lambda_builder import build_lambda_template
    from bossanova.internal.maths.solvers.lmer import (
        compute_pls_invariants,
        lmm_deviance_sparse,
    )
    from bossanova.internal.fit.varying import (
        per_factor_re_info,
    )  # Deferred: avoid circular import between infer ↔ fit

    re_meta = bundle.re_metadata
    X = bundle.X
    Z = bundle.Z
    y = bundle.y
    theta = fit.theta
    sigma = fit.sigma or 1.0
    method = "REML" if spec.method == "reml" else "ML"

    group_names = list(re_meta.grouping_vars)
    n_groups_list = re_meta.n_groups_list
    re_structure = re_meta.re_structure
    metadata = re_meta.metadata

    conv_re_structure, conv_random_names = per_factor_re_info(re_meta, group_names)

    # Build lambda template for efficient updates
    lambda_template = build_lambda_template(n_groups_list, re_structure, metadata)

    pls_invariants = compute_pls_invariants(X, y)

    # Build deviance function
    def deviance_fn(th: np.ndarray) -> float:
        return lmm_deviance_sparse(
            theta=th,
            X=X,
            Z=Z,
            y=y,
            n_groups_list=n_groups_list,
            re_structure=re_structure,
            method=method,
            lambda_template=lambda_template,
            pls_invariants=pls_invariants,
            metadata=metadata,
        )

    # Compute deviance at optimal theta
    dev_opt = deviance_fn(theta)

    # Build lightweight adapter satisfying MixedModelProtocol
    adapter = _ProfileAdapter(
        theta=theta,
        sigma=sigma,
        deviance=dev_opt,
        deviance_fn=deviance_fn,
        group_names=group_names,
        random_names=conv_random_names,
        y=y,
        X=X,
        re_structure=conv_re_structure,
        metadata=metadata,
    )

    profile_kwargs: dict[str, object] = {"n_steps": n_steps, "verbose": verbose}
    if threshold is not None:
        profile_kwargs["threshold"] = threshold
    profile_data = profile_likelihood(
        adapter,
        conf_level=conf_level,
        **profile_kwargs,
    )
    profile = ProfileState(**profile_data)

    return profile
