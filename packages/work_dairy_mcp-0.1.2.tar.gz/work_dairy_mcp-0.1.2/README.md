# Work Dairy MCP

工时管理MCP服务 - 支持登录、工时填写、查询等功能

## 安装

```bash
pip install work-dairy-mcp
```

## 配置

### 环境变量

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `WORK_DAIRY_BASE_URL` | API服务地址 | `http://localhost:8080` |
| `WORK_DAIRY_TOKEN` | 认证Token（可选） | 空 |

### Cursor配置

创建 `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "work-dairy": {
      "command": "uvx",
      "args": ["work-dairy-mcp"],
      "env": {
        "WORK_DAIRY_BASE_URL": "https://your-api-server"
      }
    }
  }
}
```

## 可用工具

| 工具名称 | 说明 |
|---------|------|
| `login` | 用户登录，获取Token |
| `working_hours_add_or_update` | 工时填写 |
| `working_hours_get_page` | 工时分页查询 |
| `working_hours_get_list` | 工时列表查询 |
| `working_hours_get` | 工时详情查询 |

## 使用示例

- "帮我登录系统"
- "查询我最近的工作日志"
- "帮我填写今天的工时"
- "查看我上个月的工时记录"

## License

CTGD
