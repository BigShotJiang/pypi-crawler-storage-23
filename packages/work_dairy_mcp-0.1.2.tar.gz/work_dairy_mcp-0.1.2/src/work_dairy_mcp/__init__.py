"""Work Dairy MCP - 工时管理MCP服务"""

__version__ = "0.1.0"
