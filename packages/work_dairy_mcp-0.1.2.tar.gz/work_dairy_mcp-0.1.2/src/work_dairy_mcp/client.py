"""API客户端模块"""

import json
from typing import Any, Optional

import httpx

from .config import config


class ApiClient:
    """API客户端类"""
    
    def __init__(self, base_url: Optional[str] = None, token: Optional[str] = None):
        """
        初始化API客户端
        
        Args:
            base_url: API基础URL
            token: 认证token
        """
        self.base_url = base_url or config.base_url
        self.token = token or config.token
    
    def _get_headers(self) -> dict:
        """
        获取请求头
        
        Returns:
            dict: 请求头字典
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "no-need-encrypt": "developer",
        }
        if self.token:
            headers["Token"] = self.token
        return headers
    
    def set_token(self, token: str) -> None:
        """
        设置token
        
        Args:
            token: 认证token
        """
        self.token = token
    
    async def post(self, path: str, data: Optional[dict] = None) -> dict:
        """
        发送POST请求
        
        Args:
            path: API路径
            data: 请求数据
            
        Returns:
            dict: 响应数据
        """
        url = f"{self.base_url}{path}"
        async with httpx.AsyncClient() as client:
            response = await client.post(
                url,
                json=data,
                headers=self._get_headers(),
                timeout=30.0,
            )
            response.raise_for_status()
            return response.json()
    
    async def get(self, path: str, params: Optional[dict] = None) -> dict:
        """
        发送GET请求
        
        Args:
            path: API路径
            params: 查询参数
            
        Returns:
            dict: 响应数据
        """
        url = f"{self.base_url}{path}"
        async with httpx.AsyncClient() as client:
            response = await client.request(
                "GET",
                url,
                json=params,
                headers=self._get_headers(),
                timeout=30.0,
            )
            response.raise_for_status()
            return response.json()
    
    async def delete(self, path: str, params: Optional[dict] = None) -> dict:
        """
        发送DELETE请求
        
        Args:
            path: API路径
            params: 查询参数
            
        Returns:
            dict: 响应数据
        """
        url = f"{self.base_url}{path}"
        async with httpx.AsyncClient() as client:
            response = await client.delete(
                url,
                params=params,
                headers=self._get_headers(),
                timeout=30.0,
            )
            response.raise_for_status()
            return response.json()


api_client = ApiClient()
