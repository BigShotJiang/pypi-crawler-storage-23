"""配置模块"""

import os
from dataclasses import dataclass


@dataclass
class Config:
    """配置类"""
    
    base_url: str = os.getenv("WORK_DAIRY_BASE_URL", "http://localhost:8080")
    token: str = os.getenv("WORK_DAIRY_TOKEN", "")
    
    def get_headers(self) -> dict:
        """
        获取请求头
        
        Returns:
            dict: 包含认证信息的请求头
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers


config = Config()
