"""MCP服务主模块"""

import json
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from .client import ApiClient

server = Server("work-dairy-mcp")


@server.list_tools()
async def list_tools() -> list[Tool]:
    """
    列出所有可用的工具
    
    Returns:
        list[Tool]: 工具列表
    """
    return [
        Tool(
            name="login",
            description="用户登录接口，获取认证token",
            inputSchema={
                "type": "object",
                "properties": {
                    "account": {
                        "type": "string",
                        "description": "账号",
                    },
                    "password": {
                        "type": "string",
                        "description": "密码",
                    },
                    "login_type": {
                        "type": "integer",
                        "description": "登录类型（0：本系统登录；2：企微自动登录；4：企微扫码登录；5: 4a登录；默认：0）",
                        "default": 0,
                    },
                },
                "required": ["account", "password"],
            },
        ),
        Tool(
            name="working_hours_add_or_update",
            description="工时填写接口，用于提交工时记录",
            inputSchema={
                "type": "object",
                "properties": {
                    "token": {"type": "string", "description": "认证token（必填）"},
                    "project_code": {"type": "string", "description": "项目码"},
                    "project_name": {"type": "string", "description": "项目名称"},
                    "task_code": {"type": "string", "description": "任务码"},
                    "task_name": {"type": "string", "description": "任务名称"},
                    "status": {"type": "string", "description": "任务状态"},
                    "person_id": {"type": "integer", "description": "人员ID"},
                    "person_name": {"type": "string", "description": "人员姓名"},
                    "avatar": {"type": "string", "description": "头像"},
                    "hours": {"type": "integer", "description": "工时"},
                    "date": {"type": "string", "description": "日期，格式：yyyy-MM-dd"},
                    "job_duties": {"type": "string", "description": "描述"},
                    "type": {"type": "integer", "description": "类型：1-工作 2-请假"},
                    "role": {"type": "string", "description": "岗位"},
                },
                "required": ["token", "date"],
            },
        ),
        Tool(
            name="working_hours_get_page",
            description="工时分页查询接口",
            inputSchema={
                "type": "object",
                "properties": {
                    "token": {"type": "string", "description": "认证token（必填）"},
                    "current": {"type": "integer", "description": "当前页码", "default": 1},
                    "size": {"type": "integer", "description": "每页大小", "default": 10},
                    "group_id": {"type": "integer", "description": "群组ID"},
                    "person_id": {"type": "integer", "description": "人员ID"},
                    "person_id_list": {"type": "array", "items": {"type": "integer"}, "description": "人员ID列表"},
                    "person_name": {"type": "string", "description": "人员姓名"},
                    "start_date": {"type": "string", "description": "开始日期，格式：yyyy-MM-dd"},
                    "end_date": {"type": "string", "description": "结束日期，格式：yyyy-MM-dd"},
                    "task_code": {"type": "string", "description": "任务编码"},
                    "curr_company_id": {"type": "integer", "description": "查看人公司ID"},
                },
                "required": ["token"],
            },
        ),
        Tool(
            name="working_hours_get_list",
            description="工时列表查询接口",
            inputSchema={
                "type": "object",
                "properties": {
                    "token": {"type": "string", "description": "认证token（必填）"},
                    "group_id": {"type": "integer", "description": "群组ID"},
                    "person_id": {"type": "integer", "description": "人员ID"},
                    "person_id_list": {"type": "array", "items": {"type": "integer"}, "description": "人员ID列表"},
                    "person_name": {"type": "string", "description": "人员姓名"},
                    "start_date": {"type": "string", "description": "开始日期，格式：yyyy-MM-dd"},
                    "end_date": {"type": "string", "description": "结束日期，格式：yyyy-MM-dd"},
                    "task_code": {"type": "string", "description": "任务编码"},
                    "curr_company_id": {"type": "integer", "description": "查看人公司ID"},
                },
                "required": ["token"],
            },
        ),
        Tool(
            name="working_hours_get",
            description="工时详情查询接口",
            inputSchema={
                "type": "object",
                "properties": {
                    "token": {"type": "string", "description": "认证token（必填）"},
                    "id": {
                        "type": "integer",
                        "description": "工时记录ID",
                    },
                },
                "required": ["token", "id"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """
    调用工具
    
    Args:
        name: 工具名称
        arguments: 工具参数
        
    Returns:
        list[TextContent]: 工具执行结果
    """
    try:
        result = await _handle_tool_call(name, arguments)
        return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False, indent=2))]
    except Exception as e:
        return [TextContent(type="text", text=f"错误: {str(e)}")]


async def _handle_tool_call(name: str, arguments: dict[str, Any]) -> dict:
    """
    处理工具调用
    
    Args:
        name: 工具名称
        arguments: 工具参数
        
    Returns:
        dict: 执行结果
    """
    if name == "login":
        return await _login(arguments)
    elif name == "working_hours_add_or_update":
        return await _working_hours_add_or_update(arguments)
    elif name == "working_hours_get_page":
        return await _working_hours_get_page(arguments)
    elif name == "working_hours_get_list":
        return await _working_hours_get_list(arguments)
    elif name == "working_hours_get":
        return await _working_hours_get(arguments)
    else:
        raise ValueError(f"未知的工具: {name}")


async def _login(arguments: dict[str, Any]) -> dict:
    """
    用户登录
    
    Args:
        arguments: 登录参数
        
    Returns:
        dict: 登录结果，包含token和用户信息
    """
    client = ApiClient()
    data = {
        "account": arguments["account"],
        "password": arguments["password"],
        "loginType": arguments.get("login_type", 0),
    }
    return await client.post("/user/login", data)


async def _working_hours_add_or_update(arguments: dict[str, Any]) -> dict:
    """
    工时填写
    
    Args:
        arguments: 工时数据
        
    Returns:
        dict: 操作结果
    """
    client = ApiClient(token=arguments["token"])
    data = {
        "projectCode": arguments.get("project_code"),
        "projectName": arguments.get("project_name"),
        "taskCode": arguments.get("task_code"),
        "taskName": arguments.get("task_name"),
        "status": arguments.get("status"),
        "personId": arguments.get("person_id"),
        "personName": arguments.get("person_name"),
        "avatar": arguments.get("avatar"),
        "hours": arguments.get("hours"),
        "date": arguments.get("date"),
        "jobDuties": arguments.get("job_duties"),
        "type": arguments.get("type"),
        "role": arguments.get("role"),
    }
    data = {k: v for k, v in data.items() if v is not None}
    return await client.post("/working-hours", data)


async def _working_hours_get_page(arguments: dict[str, Any]) -> dict:
    """
    工时分页查询
    
    Args:
        arguments: 查询参数
        
    Returns:
        dict: 分页结果
    """
    client = ApiClient(token=arguments["token"])
    params = {}
    if "current" in arguments:
        params["current"] = arguments["current"]
    if "size" in arguments:
        params["size"] = arguments["size"]
    if "group_id" in arguments:
        params["groupId"] = arguments["group_id"]
    if "person_id" in arguments:
        params["personId"] = arguments["person_id"]
    if "person_id_list" in arguments:
        params["personIdList"] = arguments["person_id_list"]
    if "person_name" in arguments:
        params["personName"] = arguments["person_name"]
    if "start_date" in arguments:
        params["startDate"] = arguments["start_date"]
    if "end_date" in arguments:
        params["endDate"] = arguments["end_date"]
    if "task_code" in arguments:
        params["taskCode"] = arguments["task_code"]
    if "curr_company_id" in arguments:
        params["currCompanyId"] = arguments["curr_company_id"]
    
    return await client.get("/working-hours/page", params)


async def _working_hours_get_list(arguments: dict[str, Any]) -> dict:
    """
    工时列表查询
    
    Args:
        arguments: 查询参数
        
    Returns:
        dict: 列表结果
    """
    client = ApiClient(token=arguments["token"])
    params = {}
    if "group_id" in arguments:
        params["groupId"] = arguments["group_id"]
    if "person_id" in arguments:
        params["personId"] = arguments["person_id"]
    if "person_id_list" in arguments:
        params["personIdList"] = arguments["person_id_list"]
    if "person_name" in arguments:
        params["personName"] = arguments["person_name"]
    if "start_date" in arguments:
        params["startDate"] = arguments["start_date"]
    if "end_date" in arguments:
        params["endDate"] = arguments["end_date"]
    if "task_code" in arguments:
        params["taskCode"] = arguments["task_code"]
    if "curr_company_id" in arguments:
        params["currCompanyId"] = arguments["curr_company_id"]
    
    return await client.get("/working-hours/list", params)


async def _working_hours_get(arguments: dict[str, Any]) -> dict:
    """
    工时详情查询
    
    Args:
        arguments: 查询参数
        
    Returns:
        dict: 工时详情
    """
    client = ApiClient(token=arguments["token"])
    params = {"id": arguments["id"]}
    return await client.get("/working-hours/get", params)


def main():
    """主函数"""
    import asyncio
    
    async def run():
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())
    
    asyncio.run(run())


if __name__ == "__main__":
    main()
