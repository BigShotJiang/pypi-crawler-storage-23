"""Example: Subscribing to streams with NeonLink."""

import asyncio
import json
from typing import Any, Dict

from neonlink import ConfigBuilder, NeonLinkClient
from messaging.v1 import messaging_pb2


async def process_prediction(payload: bytes) -> Dict[str, Any]:
    """Process prediction message."""
    data = json.loads(payload)
    return {"status": "processed", "data": data}


async def main() -> None:
    config = (
        ConfigBuilder()
        .with_service_name("finai-worker")
        .with_address("neonlink:9090")
        .build()
    )

    async with NeonLinkClient(config) as client:
        # Subscribe with managed lifecycle (recommended)
        request = messaging_pb2.SubscribeRequest(
            stream_name="finai.predictions",
            consumer_group="finai-workers",
            auto_ack=False,
        )

        async def on_message(message: messaging_pb2.StreamMessage) -> None:
            try:
                print(f"Received: {message.redis_message_id}")
                result = await process_prediction(message.payload)
                print(f"Result: {result}")

                # Acknowledge after successful processing
                await client.acknowledge(message)

            except Exception as e:
                # Release for broker-managed redelivery
                if message.HasField("ack_context"):
                    await client.release_by_id(
                        redis_message_id=message.redis_message_id,
                        stream_name=message.ack_context.stream_name,
                        consumer_group=message.ack_context.consumer_group,
                        consumer_name=message.ack_context.consumer_name,
                    )

        handle = await client.subscribe_with_handle(request, on_message)

        # Wait for terminal outcome
        terminal = await handle.wait()
        if terminal is not None:
            raise terminal


if __name__ == "__main__":
    asyncio.run(main())
