"""Cozempic - Context weight-loss tool for Claude Code."""

__version__ = "0.7.4"
