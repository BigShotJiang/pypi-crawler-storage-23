# telegram-async

Nowoczesna biblioteka asynchroniczna do Telegram Bot API, wzorowana na aiogram 3.x.

## Instalacja

```bash
pip install telegram-async