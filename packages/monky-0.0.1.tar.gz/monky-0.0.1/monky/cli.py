def main():
    print("Monky CLI – Work in progress.")
    