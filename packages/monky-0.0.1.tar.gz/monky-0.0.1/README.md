# Monky

## Deterministic Repository-Aware Code Engine

Monky is a command-line code generation engine designed for deterministic, structured, repository-aware code production.

It is not a conversational assistant.  
It is not a chat interface.  
It is a controlled code execution engine.

---

## Core Identity

Monky is built as a **deterministic code engine**.

That means:

- Structured output over free-form text  
- Patch-oriented generation  
- Repository awareness  
- Minimal interface  
- Predictable behavior  

Monky does not aim to replace thinking.  
It aims to execute decisions precisely.

---

## Current Status

Early experimental release.

This version exists to:

- Reserve the namespace  
- Establish architectural direction  
- Begin deterministic engine development  

APIs are unstable.  
Behavior will evolve.

---

## Design Principles

- Deterministic behavior  
- Structured outputs (JSON / patch mode planned)  
- Repository-context execution  
- Fast startup  
- Minimal surface area  
- No conversational noise  

---

## Roadmap

- Repository indexing  
- Commit-aware caching  
- Structured patch generation  
- Deterministic output mode  
- Benchmark tracking  
- Language-specialized engine (Python-first)

---

## Installation

```bash
pip install monky
```

(Currently a minimal stub release.)

---

## Philosophy

Code generation tools should be:

- Precise  
- Predictable  
- Repository-aware  
- Quiet  

Monky is designed as an execution layer, not a discussion layer.

---

## License

MIT (planned)