"""OpenSearch Orchestrator package."""

__version__ = "0.2.5"

__all__ = ["__version__"]
