"""
S3 (Simple Storage Service) cost optimization detectors.

This module contains detectors for:
- S3 lifecycle policy optimization suggestions
"""

from typing import Any, Dict, List


def detect_s3_lifecycle_suggestions(
    s3_buckets: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Suggests S3 lifecycle policies for cost optimization.

    Note: This is a heuristic detector that recommends lifecycle policies without
    analyzing actual bucket size/access patterns (requires additional API calls not
    available in MVP).

    Args:
        s3_buckets: List of S3 bucket dictionaries from scanner
    """
    findings = []
    for b in s3_buckets:
        findings.append(
            {
                "type": "s3_lifecycle_suggestion",
                "resource_type": "s3",
                "id": b.get("Name"),
                "estimated_monthly_savings_usd": 0,
                "estimated_monthly_savings_hint_source": "heuristic",
                "potential_savings": 0,
                "confidence": 0.5,
                "severity": "low",
                "recommended_action": "add-lifecycle",
                "explanation": "No lifecycle information inspected. Consider adding lifecycle rules to transition infrequently accessed objects to cheaper storage.",
                "evidence": {
                    "inventory": {
                        "bucket_name": b.get("Name"),
                        "region": b.get("Region"),
                    },
                    "assessment": {
                        "inspected_lifecycle": False,
                    },
                },
                "verification_commands": [
                    f"aws s3api get-bucket-lifecycle-configuration --bucket {b.get('Name')}",
                    f"aws s3api get-bucket-location --bucket {b.get('Name')}",
                ],
                "remediation_commands": [],
            }
        )
    return findings
