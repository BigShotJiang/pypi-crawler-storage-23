# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
from ledger import observer_signature

class NullReceipt:
    def __init__(self, context, observer_id="Observer"):
        self.context = context
        self.meta = observer_signature(context, observer_id)

    def __str__(self):
        return f"NullReceipt({self.context}, {self.meta})"

def print_nullreceipt(context, observer_id="Observer"):
    n = NullReceipt(context, observer_id)
    print(n)

# Example usage
if __name__ == "__main__":
    print_nullreceipt("No data for timestamp T=1337")