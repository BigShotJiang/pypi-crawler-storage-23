# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
from collections import defaultdict
import time
import uuid

class InterconnectednessEngine:
    def __init__(self):
        self.nodes = set()
        self.edges = defaultdict(list)
        self.receipts = []

    def add_node(self, node):
        self.nodes.add(node)

    def connect(self, a, b, relation, observer="System", extra=None):
        edge_id = str(uuid.uuid4())
        ts = int(time.time())
        self.edges[a].append((b, relation, edge_id))
        self.edges[b].append((a, relation, edge_id))
        receipt = {
            "edge_id": edge_id,
            "from": a,
            "to": b,
            "relation": relation,
            "timestamp": ts,
            "observer": observer,
            "extra": extra or {}
        }
        self.receipts.append(receipt)

    def plug_in(self, thing, auto_add_connections=None):
        self.add_node(thing)
        if auto_add_connections:
            for target, relation in auto_add_connections:
                self.connect(thing, target, relation)

    def show_connections(self, node, depth=1, visited=None, layer=0):
        if visited is None:
            visited = set()
        indent = "    " * layer
        if node in visited or layer > depth:
            return
        visited.add(node)
        print(f"{indent}- {node}")
        for neighbor, relation, edge_id in self.edges[node]:
            print(f"{indent}    [via: {relation} | edge: {edge_id[:8]}...]")
            self.show_connections(neighbor, depth, visited, layer + 1)

    def print_receipts(self, filter_by=None):
        print("\n[RECEIPTS]")
        for r in self.receipts:
            if filter_by and (r['from'] != filter_by and r['to'] != filter_by):
                continue
            print(f"{r['timestamp']} | {r['from']} -[{r['relation']}]-> {r['to']} (Observer: {r['observer']}) id={r['edge_id'][:8]}")

# --- Orthopaedic Surgery Scenario: Dr. Yiannis Pappou ---

if __name__ == "__main__":
    h = InterconnectednessEngine()

    # Core nodes (roles, entities, devices, family)
    h.add_node("Dr. Yiannis Pappou (Ortho Surgeon)")
    h.add_node("OR #2")
    h.add_node("Patient: Michael Reyes")
    h.add_node("Nurse: Jasmine")
    h.add_node("PA: Mark")
    h.add_node("Device: Stryker Drill")
    h.add_node("Implant: Zimmer Knee")
    h.add_node("Order: Pre-op Labs")
    h.add_node("Order: Post-op X-ray")
    h.add_node("Bed #14")
    h.add_node("Family: Linda Reyes")
    h.add_node("Insurance: UnitedHealth")
    h.add_node("Admin: Carla")
    h.add_node("Physical Therapy")
    h.add_node("Pharmacy")
    h.add_node("Anesthesiologist: Dr. Chen")
    h.add_node("Rep: Stryker Field Tech")

    # Map workflow for an ortho case (Total Knee Replacement)
    h.connect("Dr. Yiannis Pappou (Ortho Surgeon)", "OR #2", "scheduled_in", observer="OR Scheduler")
    h.connect("Patient: Michael Reyes", "OR #2", "surgery_performed_in", observer="Charge Nurse")
    h.connect("Patient: Michael Reyes", "Bed #14", "post_op_bed", observer="Bed Manager")
    h.connect("Dr. Yiannis Pappou (Ortho Surgeon)", "Patient: Michael Reyes", "performed_surgery_on", observer="Hospital IT")
    h.connect("Nurse: Jasmine", "Patient: Michael Reyes", "perioperative_care", observer="OR Nurse")
    h.connect("PA: Mark", "Patient: Michael Reyes", "assisted_in_surgery", observer="OR Log")
    h.connect("Anesthesiologist: Dr. Chen", "Patient: Michael Reyes", "provided_anesthesia_for", observer="Anesthesia Record")
    h.connect("Device: Stryker Drill", "OR #2", "used_in_room", observer="Biomed")
    h.connect("Implant: Zimmer Knee", "Patient: Michael Reyes", "implanted_in", observer="Device Traceability")
    h.connect("Order: Pre-op Labs", "Patient: Michael Reyes", "ordered_for", observer="Dr. Yiannis Pappou (Ortho Surgeon)")
    h.connect("Order: Post-op X-ray", "Patient: Michael Reyes", "ordered_for", observer="PA: Mark")
    h.connect("Family: Linda Reyes", "Patient: Michael Reyes", "emergency_contact_for", observer="Admin: Carla")
    h.connect("Patient: Michael Reyes", "Insurance: UnitedHealth", "insured_by", observer="Admin: Carla")
    h.connect("Patient: Michael Reyes", "Physical Therapy", "discharged_to", observer="Case Manager")
    h.connect("Pharmacy", "Patient: Michael Reyes", "dispensed_meds_to", observer="Pharmacy Tech")
    h.connect("Rep: Stryker Field Tech", "Device: Stryker Drill", "serviced_device", observer="Biomed")

    # Real-time event: Implant audit performed
    h.plug_in("Event: Implant Audit", auto_add_connections=[
        ("Implant: Zimmer Knee", "audited"),
        ("Dr. Yiannis Pappou (Ortho Surgeon)", "notified"),
        ("Device: Stryker Drill", "checked"),
    ])

    # Show connections for Dr. Yiannis Pappou (depth=2)
    print("\n=== CONNECTIONS FOR DR. YIANNIS PAPPOU ===")
    h.show_connections("Dr. Yiannis Pappou (Ortho Surgeon)", depth=2)

    # Print full receipts log (audit trail)
    h.print_receipts(filter_by="Dr. Yiannis Pappou (Ortho Surgeon)")

    # Show the patient's entire hospital ecosystem
    print("\n=== PATIENT: MICHAEL REYES CONNECTIONS ===")
    h.show_connections("Patient: Michael Reyes", depth=3)