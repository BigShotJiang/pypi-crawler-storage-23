# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
"""
Hackett Meta OS
Receipts-native cryptographic accountability infrastructure.

Usage:
    from python.ledger import Ledger
    from python.receipts import Receipt, ReceiptGenerator

    ledger = Ledger()
    event = ledger.log_event('Patient record created', observer_id='Hospital')
    print(event)
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from ledger import Ledger, observer_signature
from receipts import Receipt, ReceiptGenerator, print_receipt
from nullreceipt import NullReceipt
from compression import compress_data, decompress_data

__version__ = '0.1.0'
__author__ = 'Andrew Hackett'
__license__ = 'MIT'

__all__ = [
    'Ledger',
    'Receipt',
    'ReceiptGenerator',
    'NullReceipt',
    'observer_signature',
    'print_receipt',
    'compress_data',
    'decompress_data',
]
