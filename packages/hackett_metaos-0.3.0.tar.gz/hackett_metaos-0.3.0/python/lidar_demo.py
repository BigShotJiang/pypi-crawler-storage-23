# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
from ledger import Ledger
import time
import uuid

# Simple ANSI escape codes for color
BOLD = "\033[1m"
END = "\033[0m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
CYAN = "\033[96m"
MAGENTA = "\033[95m"
GRAY = "\033[90m"
BLUE = "\033[94m"
BOX = "═" * 78

def section(title, icon=""):
    print(f"\n{CYAN}{BOX}\n║{END} {BOLD}{icon} {title}{END}\n{CYAN}{BOX}{END}")

def info(msg):
    print(f"{BOLD}{MAGENTA}• {msg}{END}")

def success(msg):
    print(f"{GREEN}✓ {msg}{END}")

def warn(msg):
    print(f"{YELLOW}✗ {msg}{END}")

def omitted(msg):
    print(f"{RED}✗ {msg}{END}")

def banner():
    print(f"\n{CYAN}{BOX}{END}")
    print(f"{CYAN}║{END} {BOLD}HACKETT META OS - AUTONOMOUS VEHICLE LIDAR DEMO{END}")
    print(f"{CYAN}║{END} Receipts-Native Sensor Event Logging with Omission Detection")
    print(f"{CYAN}{BOX}{END}")

def print_audit(ledger):
    section("AUDIT TRAIL & COMPRESSION", "🗂")
    compressed = ledger.compress_ledger()
    print(f"{BLUE}Audit trail compressed: {len(compressed)} bytes{END}")
    print(f"{BLUE}Events: {len(ledger.events)} | Omissions: {len(ledger.nullreceipts)}{END}")

def key_benefits():
    section("KEY BENEFITS FOR AV INDUSTRY", "🚗")
    print(f"{BOLD}✓{END} Every sensor event is {BOLD}cryptographically signed{END} & auditable")
    print(f"{BOLD}✓{END} All omissions (sensor downtime) logged as {BOLD}NullReceipts{END}")
    print(f"{BOLD}✓{END} Single-click audit trail for NHTSA/NTSB/compliance")
    print(f"{BOLD}✓{END} Tamper/backdate resistance, real-time root cause analysis")
    print(f"{BOLD}✓{END} Protects against false claims and liability (insurance, legal)")
    print(f"{CYAN}{BOX}{END}")

def simulate_lidar_event(ledger, detected_object, distance_m):
    ts = int(time.time())
    event = f"LIDAR detected: {detected_object} at {distance_m}m (ts={ts})"
    receipt = ledger.log_event(event, observer_id="LIDAR_Sensor")
    success(f"LIDAR Event: {event}")
    info(f"Receipt ID: {GRAY}{receipt['event_id']}{END} | Sig: {GRAY}{receipt['sig'][:12]}...{END}")

def simulate_sensor_failure(ledger, expected_sensor="LIDAR_Sensor"):
    context = f"No data from {expected_sensor} at {int(time.time())}"
    nullr = ledger.log_nullreceipt(context, observer_id=expected_sensor)
    omitted(f"Omission detected: {context}")
    info(f"NullReceipt ID: {GRAY}{nullr['event_id']}{END} | Sig: {GRAY}{nullr['sig'][:12]}...{END}")

if __name__ == "__main__":
    banner()
    section("LIDAR SENSOR EVENT STREAM", "📡")
    ledger = Ledger()

    # Step 1: Normal sensor readings
    simulate_lidar_event(ledger, detected_object="pedestrian", distance_m=32.6)
    simulate_lidar_event(ledger, detected_object="stop sign", distance_m=10.4)

    # Step 2: Sensor fails (no data at next interval)
    simulate_sensor_failure(ledger)

    # Step 3: Sensor recovers, resumes detection
    simulate_lidar_event(ledger, detected_object="cyclist", distance_m=17.9)

    # Step 4: Final audit/compression
    print_audit(ledger)

    key_benefits()
    print(f"{CYAN}{BOX}{END}")
    print(f"{CYAN}{BOLD}Demo Complete | github.com/adhack121-create/hackett-meta-os{END}")
    print(f"{CYAN}{BOX}{END}\n")