# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
from ledger import observer_signature
import hashlib
import json
from typing import Dict, Any

class Receipt:
    def __init__(self, event_data, observer_id="Observer"):
        self.data = event_data
        self.meta = observer_signature(event_data, observer_id)

    def __str__(self):
        return f"Receipt({self.data}, {self.meta})"

def print_receipt(event_data, observer_id="Observer"):
    r = Receipt(event_data, observer_id)
    print(r)

class ReceiptGenerator:
    """Generates cryptographic receipts for all operations"""
    
    def generate_receipt(self, operation: str, data: Any, observer_id: str) -> Dict:
        receipt_data = {
            "operation": operation,
            "data": json.dumps(data, sort_keys=True),
            "observer": observer_id
        }
        receipt_hash = hashlib.sha256(
            json.dumps(receipt_data, sort_keys=True).encode()
        ).hexdigest()
        return {
            **receipt_data,
            "receipt_hash": receipt_hash,
            "receipt_type": "operation_receipt"
        }
    
    def verify_receipt(self, receipt: Dict) -> bool:
        stored_hash = receipt.get("receipt_hash")
        receipt_copy = {k: v for k, v in receipt.items() if k != "receipt_hash"}
        computed_hash = hashlib.sha256(
            json.dumps(receipt_copy, sort_keys=True).encode()
        ).hexdigest()
        return stored_hash == computed_hash

if __name__ == "__main__":
    print_receipt("Empire initialization receipt.")
    gen = ReceiptGenerator()
    receipt = gen.generate_receipt("test_operation", {"key": "value"}, "TestObserver")
    print(f"Receipt generated: {receipt['receipt_hash'][:16]}...")
    print(f"Valid: {gen.verify_receipt(receipt)}")
