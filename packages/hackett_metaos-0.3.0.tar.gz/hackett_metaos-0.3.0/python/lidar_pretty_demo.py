# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
from ledger import Ledger
import time

# ANSI color and style codes for pretty output
BOLD = "\033[1m"
END = "\033[0m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
CYAN = "\033[96m"
GRAY = "\033[90m"
BLUE = "\033[94m"
BOX = "═" * 78

def print_header(title):
    print(f"\n{CYAN}{BOX}{END}")
    print(f"{CYAN}║{END} {BOLD}{title}{END}")
    print(f"{CYAN}{BOX}{END}")

def print_section(title, icon=""):
    print(f"\n{CYAN}{BOX}\n║{END} {BOLD}{icon} {title}{END}\n{CYAN}{BOX}{END}")

def print_event(msg, receipt_id, sig, is_omission=False):
    color = RED if is_omission else GREEN
    prefix = "✗" if is_omission else "✓"
    print(f"{color}{prefix} {msg}{END}")
    print(f"{GRAY}    Receipt ID: {receipt_id} | Sig: {sig[:12]}...{END}")

def print_audit(ledger):
    print_section("AUDIT SUMMARY", "🗂")
    compressed = ledger.compress_ledger()
    print(f"{BLUE}Audit trail compressed: {len(compressed)} bytes{END}")
    print(f"{BLUE}Events: {len(ledger.events)} | Omissions: {len(ledger.nullreceipts)}{END}")

def print_benefits():
    print_section("ENTERPRISE VALUE", "🚗")
    print(f"{BOLD}✓{END} Sensor events are {BOLD}cryptographically receipted{END} & auditable")
    print(f"{BOLD}✓{END} Omissions instantly logged as {BOLD}NullReceipts{END}")
    print(f"{BOLD}✓{END} Ready for NHTSA, insurance, and real-world compliance")
    print(f"{BOLD}✓{END} No backdating, deletion, or fraud risk")
    print(f"{BOLD}✓{END} One-click, enterprise-class audit trail")
    print(f"{CYAN}{BOX}{END}")

if __name__ == "__main__":
    print_header("HACKETT META OS - AV LIDAR DEMO (PRETTY EDITION)")
    print_section("SENSOR EVENT STREAM", "📡")
    ledger = Ledger()

    # Simulated LIDAR events
    ts = int(time.time())
    # Event 1
    event1 = f"LIDAR detected: pedestrian at 33.1m (ts={ts})"
    receipt1 = ledger.log_event(event1, observer_id="LIDAR")
    print_event(event1, receipt1['event_id'], receipt1['sig'])

    # Event 2
    event2 = f"LIDAR detected: vehicle at 21.5m (ts={ts+1})"
    receipt2 = ledger.log_event(event2, observer_id="LIDAR")
    print_event(event2, receipt2['event_id'], receipt2['sig'])

    # Omission event (sensor fails)
    omission_msg = f"No data from LIDAR at {ts+2}"
    nullr = ledger.log_nullreceipt(omission_msg, observer_id="LIDAR")
    print_event(omission_msg, nullr['event_id'], nullr['sig'], is_omission=True)

    # Event 3
    event3 = f"LIDAR detected: cyclist at 15.9m (ts={ts+3})"
    receipt3 = ledger.log_event(event3, observer_id="LIDAR")
    print_event(event3, receipt3['event_id'], receipt3['sig'])

    print_audit(ledger)
    print_benefits()
    print(f"{CYAN}{BOX}{END}")
    print(f"{CYAN}{BOLD}Demo Complete | github.com/adhack121-create/hackett-meta-os{END}")
    print(f"{CYAN}{BOX}{END}\n")