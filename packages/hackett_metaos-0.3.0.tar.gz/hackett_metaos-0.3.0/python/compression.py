# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
import zlib

def compress_data(data):
    if isinstance(data, str):
        data = data.encode()
    compressed = zlib.compress(data)
    print(f"Compressed from {len(data)} to {len(compressed)} bytes.")
    return compressed

def decompress_data(compressed):
    decompressed = zlib.decompress(compressed)
    print(f"Decompressed to {len(decompressed)} bytes.")
    return decompressed

# Example usage
if __name__ == "__main__":
    raw = "Sample ledger data for empire protocol."
    compressed = compress_data(raw)
    decompressed = decompress_data(compressed)
    print("Decompressed matches original?", decompressed.decode() == raw)