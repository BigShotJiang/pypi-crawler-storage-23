# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
import subprocess
import os

demos_dir = os.path.join(os.path.dirname(__file__), 'demos')
demo_files = [
    f for f in os.listdir(demos_dir)
    if f.endswith('_demo.py')
]

for demo in sorted(demo_files):
    print(f"\n{'='*70}\nRunning: {demo}\n{'='*70}")
    subprocess.run(['python3', os.path.join(demos_dir, demo)])