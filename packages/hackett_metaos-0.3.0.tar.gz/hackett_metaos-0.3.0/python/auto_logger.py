# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
import time, os, sys
from pathlib import Path

# Add parent dir to path so ledger is importable
sys.path.insert(0, str(Path(__file__).parent))
from ledger import Ledger

WATCH_PATH = os.path.expanduser('~/Desktop')
ledger = Ledger()

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler

    class LogHandler(FileSystemEventHandler):
        def on_any_event(self, event):
            desc = f"{event.event_type.upper()} - {event.src_path}"
            ledger.log_event(desc)
            print(desc)

    def start_watching():
        event_handler = LogHandler()
        observer = Observer()
        observer.schedule(event_handler, path=WATCH_PATH, recursive=True)
        observer.start()
        print(f"Watching {WATCH_PATH} for changes... Ctrl+C to stop.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            observer.stop()
        observer.join()

except ImportError:
    def start_watching():
        print(f"[auto_logger] watchdog not installed. Run: pip3 install watchdog")
        print(f"[auto_logger] Ledger ready. Would watch: {WATCH_PATH}")

if __name__ == '__main__':
    start_watching()
