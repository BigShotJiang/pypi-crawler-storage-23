# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - CLINICAL TRIAL DATA INTEGRITY DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"Patient enrolled at {ts}, Trial #NCT04567890, Cohort A", observer_id="ClinicalCoordinator")
ledger.log_event(f"Baseline labs collected at {ts+1}, glucose 95mg/dL", observer_id="LabSystem")
ledger.log_nullreceipt(f"Day 7 measurement missing at {ts+2}", observer_id="ProtocolEngine")
ledger.log_event(f"Day 14 measurement at {ts+3}, glucose 110mg/dL", observer_id="LabSystem")
ledger.log_nullreceipt(f"Adverse event NOT reported at {ts+4}", observer_id="SafetyMonitor")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🧬 CLINICAL TRIAL VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Protocol deviations and omissions are instantly logged")
print("✓ Data fabrication or 'fudging' is structurally impossible")
print("✓ Full FDA/EMA audit chain, instant export")
print("✓ One-click, tamper-proof evidence for regulators and sponsors")
print("═════════════════════════════════════════════════════════════════════════════")