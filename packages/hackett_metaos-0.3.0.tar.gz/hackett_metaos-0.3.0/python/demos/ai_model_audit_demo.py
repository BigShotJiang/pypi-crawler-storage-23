# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ledger import Ledger
import time

# ANSI color/style codes
BOLD = "\033[1m"
END = "\033[0m"
GREEN = "\033[92m"
RED = "\033[91m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
GRAY = "\033[90m"
BOX = "═" * 78

def print_header(title):
    print(f"\n{CYAN}{BOX}{END}")
    print(f"{CYAN}║{END} {BOLD}{title}{END}")
    print(f"{CYAN}{BOX}{END}")

def print_section(title, icon=""):
    print(f"\n{CYAN}{BOX}\n║{END} {BOLD}{icon} {title}{END}\n{CYAN}{BOX}{END}")

def print_event(msg, receipt_id, sig, observer, is_omission=False):
    color = RED if is_omission else GREEN
    prefix = "✗" if is_omission else "✓"
    who = f"{GRAY}Observer: {observer}{END}"
    print(f"{color}{prefix} {msg}{END}   {who}")
    print(f"{GRAY}    Receipt ID: {receipt_id} | Sig: {sig[:12]}...{END}")

def print_audit(ledger):
    print_section("AUDIT SUMMARY", "🗂")
    compressed = ledger.compress_ledger()
    print(f"{CYAN}Audit trail compressed: {len(compressed)} bytes{END}")
    print(f"{CYAN}Events: {len(ledger.events)} | Omissions: {len(ledger.nullreceipts)}{END}")

def print_benefits():
    print_section("AI/ML GOVERNANCE & COMPLIANCE VALUE", "🤖")
    print(f"{BOLD}✓{END} Every training, inference, and omission cryptographically receipted")
    print(f"{BOLD}✓{END} Missing datasets, skipped validations, and anomalies instantly detected/logged")
    print(f"{BOLD}✓{END} Full compliance for NIST AI RMF, EU AI Act, FDA/EMA, ISO/IEC 24028, SOC2, etc")
    print(f"{BOLD}✓{END} One-click, receipts-native audit for red-teaming, recall, or regulatory review")
    print(f"{BOLD}✓{END} Immutable lineage for every model, run, dataset, and parameter set")
    print(f"{CYAN}{BOX}{END}")

if __name__ == "__main__":
    print_header("HACKETT META OS - AI MODEL TRAINING, INFERENCE & AUDIT DEMO")
    print_section("MODEL LIFECYCLE WORKFLOW", "🧠")
    ledger = Ledger()
    ts = int(time.time())

    # Step 1: Training run started
    step1 = f"Model V7 training started, dataset: /data/imageset_421, params: epochs=50, lr=0.01, ts={ts}"
    r1 = ledger.log_event(step1, observer_id="TrainBot")
    print_event(step1, r1['event_id'], r1['sig'], r1['observer'])

    # Step 2: Training complete, metrics
    step2 = f"Model V7 training complete, accuracy=92.4%, loss=0.14, ts={ts+1}"
    r2 = ledger.log_event(step2, observer_id="EvalBot")
    print_event(step2, r2['event_id'], r2['sig'], r2['observer'])

    # Step 3: Omission - Validation dataset missing
    omission1 = f"Validation dataset missing for Model V7, ts={ts+2}"
    nr1 = ledger.log_nullreceipt(omission1, observer_id="ComplianceBot")
    print_event(omission1, nr1['event_id'], nr1['sig'], nr1['observer'], is_omission=True)

    # Step 4: Manual override to deploy model despite omission
    step4 = f"Manual override: deployed Model V7 to production, ts={ts+3}"
    r3 = ledger.log_event(step4, observer_id="Admin")
    print_event(step4, r3['event_id'], r3['sig'], r3['observer'])

    # Step 5: Inference event
    step5 = f"Inference request #100234, input: user_ABC, output: class=Dog, ts={ts+4}"
    r4 = ledger.log_event(step5, observer_id="InferenceEngine")
    print_event(step5, r4['event_id'], r4['sig'], r4['observer'])

    # Step 6: Omission - Out-of-distribution (OOD) input detected, not flagged by model
    omission2 = f"Omission: OOD input not flagged by Model V7, input: user_XYZ, ts={ts+5}"
    nr2 = ledger.log_nullreceipt(omission2, observer_id="RedTeamBot")
    print_event(omission2, nr2['event_id'], nr2['sig'], nr2['observer'], is_omission=True)

    # Step 7: Red-teaming/attack simulation event
    step7 = f"Red-teaming simulation completed, 1 vulnerability found, ts={ts+6}"
    r5 = ledger.log_event(step7, observer_id="RedTeamBot")
    print_event(step7, r5['event_id'], r5['sig'], r5['observer'])

    print_audit(ledger)
    print_benefits()
    print(f"{CYAN}{BOX}{END}")
    print(f"{CYAN}{BOLD}Demo Complete | github.com/adhack121-create/hackett-meta-os{END}")
    print(f"{CYAN}{BOX}{END}\n")