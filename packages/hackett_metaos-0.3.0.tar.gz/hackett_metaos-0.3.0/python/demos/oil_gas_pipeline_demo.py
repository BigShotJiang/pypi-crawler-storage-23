# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
import sys, os, time
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - OIL & GAS PIPELINE INTEGRITY DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())
ledger.log_event(f"Flow initiated at {ts}, Station: TX-117, Volume: 8,000 bbl", observer_id="PipelineSCADA")
ledger.log_event(f"Pressure spike at {ts+1}, Segment: Mile 312", observer_id="SensorNet")
ledger.log_nullreceipt(f"Valve status missing at {ts+2}, Segment: Mile 313", observer_id="IntegrityMonitor")
ledger.log_event(f"Leak detected and isolated at {ts+3}, Auto-shutdown triggered", observer_id="PipelineAI")
ledger.log_event(f"Regulator alert sent to PHMSA at {ts+4}", observer_id="ComplianceBot")
ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🛢️ OIL & GAS PIPELINE VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every flow, pressure, valve, and leak event cryptographically receipted")
print("✓ NullReceipts for missing telemetry or manual override = anti-fraud/accident")
print("✓ Tamper-proof, audit-native for regulators, insurers, and operators")
print("✓ One-click export for PHMSA, EPA, and disaster recovery")
print("═════════════════════════════════════════════════════════════════════════════")