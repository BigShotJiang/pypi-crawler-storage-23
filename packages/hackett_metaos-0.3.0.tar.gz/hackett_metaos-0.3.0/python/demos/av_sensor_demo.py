# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - AUTONOMOUS VEHICLE SENSOR LOG DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"LiDAR scan at {ts}.001, 15 objects detected", observer_id="LidarSensor_01")
ledger.log_nullreceipt(f"Camera frame missing at {ts}.002", observer_id="VisionSystem")
ledger.log_event(f"Radar contact at {ts}.003, object at 25m", observer_id="RadarArray")
ledger.log_nullreceipt(f"Emergency brake NOT triggered at {ts}.004", observer_id="SafetyController")
ledger.log_event(f"Collision detected at {ts}.150", observer_id="ImpactSensor")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🚗 AV LIABILITY & SENSOR CHAIN VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every sensor event, omission, and override is cryptographically receipted")
print("✓ Proves exactly what was known/missing at each moment")
print("✓ Unforgeable audit chain for liability and safety")
print("✓ No more 'he said, she said' in accident investigations")
print("═════════════════════════════════════════════════════════════════════════════")