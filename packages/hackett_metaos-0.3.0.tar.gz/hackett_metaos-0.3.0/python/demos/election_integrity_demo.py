# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - ELECTION VOTE INTEGRITY DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"Voter checked in at {ts}, Precinct #4523, Machine #12", observer_id="PollWorker")
ledger.log_event(f"Ballot cast at {ts+1}, encrypted ballot hash: a3f82b...", observer_id="VotingMachine_12")
ledger.log_event(f"Ballot recorded at {ts+2}, count incremented", observer_id="TabulationSystem")
ledger.log_nullreceipt(f"Machine audit log missing at {ts+3}", observer_id="ElectionMonitor")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🗳️ ELECTION INTEGRITY VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every voter action, ballot, and audit log cryptographically receipted")
print("✓ Voters can verify their ballot was counted (receipt ID)")
print("✓ Auditors can instantly detect missing ballots or logs")
print("✓ Unforgeable, tamper-proof election trail—regulator ready")
print("═════════════════════════════════════════════════════════════════════════════")