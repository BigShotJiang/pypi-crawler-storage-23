# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - NUCLEAR / LENR TELEMETRY & SAFETY AUDIT DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"Startup sequence initiated at {ts}, Reactor: LENR-X4, Operator: Dr. Yiannis Pappou", observer_id="ControlRoom")
ledger.log_event(f"Baseline reading: Temp 34.6°C, Neutron flux: 0.2, Input Power: 1.8kW", observer_id="SensorSuite")
ledger.log_event(f"Power ramp-up at {ts+1}, Input Power: 5.0kW, Output: 7.2kW (COP 1.44)", observer_id="AutomationController")
ledger.log_event(f"Anomalous heat spike at {ts+2}, Temp 63.2°C, Output: 11.1kW", observer_id="DataLogger")
ledger.log_nullreceipt(f"Radiation monitor gap at {ts+3}, Sensor offline for 12s", observer_id="SafetyMonitor")
ledger.log_event(f"Remote shutdown triggered at {ts+4}, All control rods inserted", observer_id="EmergencySystem")
ledger.log_event(f"Post-event analysis, data sent to regulatory node", observer_id="AuditExport")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ ☢️ NUCLEAR / LENR TELEMETRY & SAFETY VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every power change, anomaly, and control action cryptographically receipted")
print("✓ NullReceipts instantly flag missing sensor/radiation data")
print("✓ One-click, receipts-native audit for NRC, DOE, IAEA, and insurance")
print("✓ Full, tamper-proof chain for science, safety, and regulatory review")
print("✓ Empowers safer, faster, and more credible nuclear/LENR innovation")
print("═════════════════════════════════════════════════════════════════════════════")