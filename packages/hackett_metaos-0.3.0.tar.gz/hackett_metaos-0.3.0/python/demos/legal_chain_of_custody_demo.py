# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - LEGAL EVIDENCE CHAIN OF CUSTODY DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"Evidence collected at {ts}, Case #2024-CR-5678, Item #42", observer_id="Officer_Badge_4521")
ledger.log_event(f"Evidence logged at {ts+1}, Property Room A", observer_id="EvidenceCustodian")
ledger.log_nullreceipt(f"Transfer signature missing at {ts+2}", observer_id="ChainOfCustody")
ledger.log_event(f"Evidence analyzed at {ts+3}, Lab #152", observer_id="ForensicTech")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ ⚖️ LEGAL CHAIN OF CUSTODY VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every collection, transfer, and omission cryptographically receipted")
print("✓ Breaks in chain (nullreceipts) are instantly visible")
print("✓ Tamper-proof, court-admissible evidence log")
print("✓ Protects both prosecution and defense from evidence tampering")
print("═════════════════════════════════════════════════════════════════════════════")