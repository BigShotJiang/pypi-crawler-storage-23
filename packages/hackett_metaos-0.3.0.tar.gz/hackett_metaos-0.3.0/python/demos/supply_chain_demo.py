# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ledger import Ledger
import time

# ANSI color/style codes
BOLD = "\033[1m"
END = "\033[0m"
GREEN = "\033[92m"
RED = "\033[91m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
GRAY = "\033[90m"
BOX = "═" * 78

def print_header(title):
    print(f"\n{CYAN}{BOX}{END}")
    print(f"{CYAN}║{END} {BOLD}{title}{END}")
    print(f"{CYAN}{BOX}{END}")

def print_section(title, icon=""):
    print(f"\n{CYAN}{BOX}\n║{END} {BOLD}{icon} {title}{END}\n{CYAN}{BOX}{END}")

def print_event(msg, receipt_id, sig, observer, is_omission=False):
    color = RED if is_omission else GREEN
    prefix = "✗" if is_omission else "✓"
    who = f"{GRAY}Observer: {observer}{END}"
    print(f"{color}{prefix} {msg}{END}   {who}")
    print(f"{GRAY}    Receipt ID: {receipt_id} | Sig: {sig[:12]}...{END}")

def print_audit(ledger):
    print_section("AUDIT SUMMARY", "🗂")
    compressed = ledger.compress_ledger()
    print(f"{CYAN}Audit trail compressed: {len(compressed)} bytes{END}")
    print(f"{CYAN}Events: {len(ledger.events)} | Omissions: {len(ledger.nullreceipts)}{END}")

def print_benefits():
    print_section("SUPPLY CHAIN & PROVENANCE VALUE", "📦")
    print(f"{BOLD}✓{END} Every checkpoint, transfer, and omission is cryptographically receipted")
    print(f"{BOLD}✓{END} Detects and logs missed scans, custody gaps, and chain-of-custody breaks")
    print(f"{BOLD}✓{END} Full compliance for ESG, recall, customs, and anti-counterfeiting audits")
    print(f"{BOLD}✓{END} Compress and export the full provenance trail on demand")
    print(f"{BOLD}✓{END} Proves origin, authenticity, and custody for regulators, partners, and customers")
    print(f"{CYAN}{BOX}{END}")

if __name__ == "__main__":
    print_header("HACKETT META OS - SUPPLY CHAIN PROVENANCE DEMO")
    print_section("CHAIN OF CUSTODY WORKFLOW", "🔗")
    ledger = Ledger()
    ts = int(time.time())

    # Step 1: Factory origin
    step1 = f"Goods produced at Factory X, batch #A123, ts={ts}"
    r1 = ledger.log_event(step1, observer_id="Factory")
    print_event(step1, r1['event_id'], r1['sig'], r1['observer'])

    # Step 2: Customs export scan
    step2 = f"Export scanned at Port Alpha, ts={ts+1}"
    r2 = ledger.log_event(step2, observer_id="Customs_Export")
    print_event(step2, r2['event_id'], r2['sig'], r2['observer'])

    # Step 3: Omission - No import scan at destination
    omission = f"IMPORT SCAN MISSING at Port Beta, ts={ts+2}"
    nr = ledger.log_nullreceipt(omission, observer_id="Customs_Import")
    print_event(omission, nr['event_id'], nr['sig'], nr['observer'], is_omission=True)

    # Step 4: Warehouse receipt
    step4 = f"Arrived at Regional Warehouse, ts={ts+3}"
    r3 = ledger.log_event(step4, observer_id="Warehouse")
    print_event(step4, r3['event_id'], r3['sig'], r3['observer'])

    # Step 5: Distribution to Retail
    step5 = f"Delivered to Retailer Y, ts={ts+4}"
    r4 = ledger.log_event(step5, observer_id="Retailer")
    print_event(step5, r4['event_id'], r4['sig'], r4['observer'])

    print_audit(ledger)
    print_benefits()
    print(f"{CYAN}{BOX}{END}")
    print(f"{CYAN}{BOLD}Demo Complete | github.com/adhack121-create/hackett-meta-os{END}")
    print(f"{CYAN}{BOX}{END}\n")