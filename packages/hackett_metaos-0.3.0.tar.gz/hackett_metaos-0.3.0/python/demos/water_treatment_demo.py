# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
import sys, os, time
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - WATER TREATMENT COMPLIANCE DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())
ledger.log_event(f"Influent sample taken at {ts}, Plant: ShadyBrook, pH: 7.5", observer_id="LabTech")
ledger.log_event(f"Chlorine injection at {ts+1}, Dose: 2.2mg/L", observer_id="ProcessControl")
ledger.log_nullreceipt(f"Turbidity reading missing at {ts+2}, Sensor offline", observer_id="WaterMonitor")
ledger.log_event(f"Effluent released at {ts+3}, pH: 7.2, Turbidity: N/A", observer_id="DischargeOps")
ledger.log_event(f"Compliance report submitted at {ts+4}, EPA region 4", observer_id="ReportingSystem")
ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 💧 WATER TREATMENT VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every sample, chemical, and omission cryptographically receipted")
print("✓ NullReceipts for missing/failed sensor data = anti-fraud, EPA, and public trust")
print("✓ Audit trail for state, federal, and insurance compliance")
print("✓ One-click export for EPA, CDC, and municipal audits")
print("═════════════════════════════════════════════════════════════════════════════")