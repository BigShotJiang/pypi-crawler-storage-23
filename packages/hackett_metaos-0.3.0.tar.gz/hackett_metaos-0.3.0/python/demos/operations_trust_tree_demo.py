# ============================================================
# Hackett Meta OS | Author: Andrew Hackett
# Entity: Hackett Meta OS LLC | Tampa, FL
# Public Key: MCowBQYDK2VwAyEADsriWR0dUC4DXImHdrdG5cd1A0fGT7pthi2ScdhXQ/I=
# Version: 0.3.0 | Date: 2026-02-22
# This file is cryptographically signed. Unauthorized reproduction
# does not transfer authorship. Receipts or it did not happen.
# ============================================================
import sys, os, time
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - OPERATIONS TRUST TREE / BLUEPRINT DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

# Board/Exec Level
ledger.log_event(f"Strategic directive issued at {ts}, Goal: Expand EMEA operations", observer_id="BoardOfDirectors")

# Branch: Finance
ledger.log_event(f"Budget approval at {ts+1}, Dept: Finance, Amount: $12M", observer_id="CFO")
ledger.log_nullreceipt(f"Missing secondary sign-off for wire >$5M", observer_id="FinanceCompliance")

# Branch: HR/People
ledger.log_event(f"New headcount request at {ts+2}, Role: Regional Manager", observer_id="HRDirector")
ledger.log_event(f"Background check completed at {ts+3}, Result: Cleared", observer_id="HRBot")

# Branch: IT/Infrastructure
ledger.log_event(f"Cloud infra provisioned at {ts+4}, Region: Frankfurt", observer_id="CIO")
ledger.log_nullreceipt(f"Security scan not run on deploy", observer_id="CyberSecurity")

# Branch: Operations/Supply Chain
ledger.log_event(f"Supplier contract signed at {ts+5}, Vendor: MedTech Solutions", observer_id="OpsManager")
ledger.log_event(f"Shipment dispatched at {ts+6}, Lot: MT-4471", observer_id="Warehouse")
ledger.log_nullreceipt(f"QA certificate missing for Lot MT-4471", observer_id="QualityControl")
ledger.log_event(f"Delivery confirmed at {ts+7}, Location: Berlin", observer_id="FieldTeam")

# Branch: Sales/Customer
ledger.log_event(f"Major deal closed at {ts+8}, Client: NHS Trust", observer_id="SalesVP")
ledger.log_event(f"Customer onboarding started at {ts+9}", observer_id="OnboardingTeam")

# Branch: Product/R&D
ledger.log_event(f"New software version released at {ts+10}, v2.4.1", observer_id="DevOps")
ledger.log_nullreceipt(f"Automated regression tests failed to run", observer_id="QATeam")

# Executive Oversight
ledger.log_event(f"Quarterly audit complete at {ts+11}, All hands report filed", observer_id="AuditCommittee")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🌳 OPERATIONS TRUST TREE & BLUEPRINT VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every branch (Finance, HR, IT, Ops, Sales, Product, Exec) receipts events and omissions")
print("✓ NullReceipts prove compliance gaps, security, QA, and process failures instantly")
print("✓ One-click, full-org audit for SEC, ISO, FDA, and enterprise risk")
print("✓ Scales to *any* org size: from startup to global conglomerate, every forked workflow mapped")
print("✓ This is your blueprint for receipts-native, anti-fraud, plug-and-play enterprise ops")
print("═════════════════════════════════════════════════════════════════════════════")