"""BoneIO Web UI Middleware."""

from .auth import AuthMiddleware

__all__ = ["AuthMiddleware"]
