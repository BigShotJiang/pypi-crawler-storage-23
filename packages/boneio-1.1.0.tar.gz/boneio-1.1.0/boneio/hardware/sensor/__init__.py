"""Hardware sensor implementations."""

