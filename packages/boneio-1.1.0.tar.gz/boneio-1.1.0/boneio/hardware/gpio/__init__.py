"""GPIO hardware abstraction."""
