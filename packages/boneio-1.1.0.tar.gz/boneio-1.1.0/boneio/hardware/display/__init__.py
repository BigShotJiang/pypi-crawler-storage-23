"""Display hardware components."""

from boneio.hardware.display.oled import Oled

__all__ = [
    "Oled",
]
