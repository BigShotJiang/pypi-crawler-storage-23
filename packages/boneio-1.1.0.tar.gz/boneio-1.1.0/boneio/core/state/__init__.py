"""State management."""

from boneio.core.state.manager import StateManager

__all__ = ["StateManager"]
