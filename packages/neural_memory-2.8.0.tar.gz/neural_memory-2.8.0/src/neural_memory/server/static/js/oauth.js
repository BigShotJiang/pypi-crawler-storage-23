/**
 * NeuralMemory Dashboard — OAuth module (stub)
 * OAuth management is handled by CLIProxyAPI dashboard.
 * NM dashboard only checks provider status via /api/oauth/providers.
 */

const NM_OAUTH = { init() {} };
