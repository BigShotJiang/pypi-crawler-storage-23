"""Third-party framework integrations for NeuralMemory."""
