=====
Usage
=====

To use the MOPAC plug-in in a project::

    import mopac_step
