"""Allow running as `python -m consolidation_memory`."""

from consolidation_memory.cli import main

main()
