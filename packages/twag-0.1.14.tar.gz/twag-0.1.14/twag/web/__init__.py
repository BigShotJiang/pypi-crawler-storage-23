"""Web interface for twag."""

from .app import create_app

__all__ = ["create_app"]
