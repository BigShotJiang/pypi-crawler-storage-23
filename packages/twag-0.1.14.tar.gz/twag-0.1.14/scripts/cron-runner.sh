#!/bin/bash
# Cron runner for twag
#
# Add to crontab:
#   0 7 * * * ~/.local/bin/twag-cron full
#   */30 7-22 * * * ~/.local/bin/twag-cron fetch-only
#
# Or if twag is in PATH:
#   0 7 * * * /path/to/cron-runner.sh full
#   */30 7-22 * * * /path/to/cron-runner.sh fetch-only
#
# Environment variables:
#   TWAG_DATA_DIR - Override data directory (optional)
#   AUTH_TOKEN, CT0 - Twitter auth (required)
#   GEMINI_API_KEY - For triage/vision (required)
#   ANTHROPIC_API_KEY - For enrichment (optional)
#   TELEGRAM_CHAT_ID - For error notifications (optional)
#   TELEGRAM_BOT_TOKEN - For error notifications via direct API (optional fallback)

# Load environment from common locations
for envfile in ~/.env ~/.config/twag/env /etc/twag/env; do
    # shellcheck disable=SC1090
    [ -f "$envfile" ] && source "$envfile" 2>/dev/null || true
done

# Ensure PATH includes common install locations
export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"

# Validate twag is available
if ! command -v twag >/dev/null 2>&1; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') [twag] ERROR: twag not found in PATH" >&2
    exit 1
fi

# Prevent concurrent runs (flock may not be available on macOS)
if command -v flock >/dev/null 2>&1; then
    LOCK_FILE="${TWAG_DATA_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/twag}/cron.lock"
    exec 9>"$LOCK_FILE"
    if ! flock -n 9; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') [twag] Another instance is running, skipping"
        exit 0
    fi
fi

MODE="${1:-full}"
ERRORS=""
LOG_DIR="${TWAG_LOG_DIR:-$HOME/.local/share/twag/logs}"
LOG_FILE="$LOG_DIR/cron-$(date '+%Y-%m-%d').log"

# Ensure log directory exists
mkdir -p "$LOG_DIR"

log() {
    local msg="$(date '+%Y-%m-%d %H:%M:%S') [twag] $*"
    echo "$msg"
    echo "$msg" >> "$LOG_FILE"
}

# Rotate logs older than 7 days
find "$LOG_DIR" -name "cron-*.log" -mtime +7 -delete 2>/dev/null || true

notify_error() {
    local msg="$1"
    log "ERROR: $msg"

    # Try OpenClaw CLI first (if available and gateway is running)
    if command -v openclaw >/dev/null 2>&1 && [ -n "$TELEGRAM_CHAT_ID" ]; then
        if curl -sf --max-time 2 --connect-timeout 1 http://127.0.0.1:8443/health >/dev/null 2>&1; then
            openclaw message send --channel telegram --target "$TELEGRAM_CHAT_ID" \
                --message "⚠️ twag pipeline failed:
${msg}" >/dev/null 2>&1 && return 0
        fi
    fi

    # Fallback to direct Telegram API
    if [ -n "$TELEGRAM_BOT_TOKEN" ] && [ -n "$TELEGRAM_CHAT_ID" ]; then
        curl -sf --max-time 10 --connect-timeout 5 -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
            -d "chat_id=${TELEGRAM_CHAT_ID}" \
            -d "text=⚠️ twag pipeline failed: ${msg}" \
            >/dev/null 2>&1 && return 0
    fi

    # No notification method available
    log "WARNING: Could not send error notification (no TELEGRAM_BOT_TOKEN or openclaw CLI)"
}

run_cmd() {
    local desc="$1"
    shift
    
    log "Starting: $desc"
    local output
    local exit_code
    
    # Capture both stdout and stderr, log to file
    output=$("$@" 2>&1) 
    exit_code=$?
    
    # Always log output
    if [ -n "$output" ]; then
        echo "$output" | tee -a "$LOG_FILE"
    fi
    
    if [ $exit_code -ne 0 ]; then
        log "FAILED: $desc (exit code $exit_code)"
        ERRORS="${ERRORS}${desc} failed (exit $exit_code)"$'\n'
        return 1
    fi
    
    log "Completed: $desc"
    return 0
}

case "$MODE" in
    full)
        # Full cycle: fetch, process, digest, maintenance
        log "Running full cycle..."
        run_cmd "fetch" twag fetch || true
        run_cmd "process" twag process || true
        run_cmd "digest" twag digest || true
        run_cmd "decay" twag accounts decay || true
        run_cmd "prune" twag prune --days 14 || true
        ;;
    fetch-only)
        # Quick fetch during the day (no tier-1 to reduce API calls)
        log "Running fetch only..."
        run_cmd "fetch" twag fetch --no-tier1 || true
        ;;
    process-only)
        log "Running process only..."
        run_cmd "process" twag process || true
        ;;
    digest-only)
        log "Running digest only..."
        run_cmd "digest" twag digest || true
        ;;
    *)
        echo "Usage: $0 [full|fetch-only|process-only|digest-only]"
        exit 1
        ;;
esac

if [ -n "$ERRORS" ]; then
    notify_error "$ERRORS"
    log "Completed with errors"
    exit 1
fi

log "Done"
