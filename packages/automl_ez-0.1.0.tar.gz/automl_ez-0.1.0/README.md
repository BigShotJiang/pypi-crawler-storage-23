# 🤖 automl-ez — Universal AutoML Library

**End-to-end ML/DL pipelines with a single call.** Supports tabular, image, text, and time-series data.

---

## ⚡ Quick Start

### Installation

```bash
pip install automl-ez

# With all optional features:
pip install automl-ez[all]
```

### Train a Model (3 lines of code)

```python
from automl_lib import AutoML
from automl_lib.config import AutoMLConfig

# Tabular classification
config = AutoMLConfig(data_path="data.csv", target_column="label")
automl = AutoML(config)
results = automl.train()
```

### Image Classification

```python
# Point to a folder structure: data/class_a/, data/class_b/, ...
config = AutoMLConfig(data_path="data/", epochs=20)
automl = AutoML(config)
results = automl.train()
```

### Text Classification

```python
config = AutoMLConfig(
    data_path="reviews.csv",
    target_column="sentiment",
    model_name="distilbert",
)
automl = AutoML(config)
results = automl.train()
```

### Time-Series Forecasting

```python
config = AutoMLConfig(
    data_path="stock_prices.csv",
    data_type="timeseries",
    extra={"window": 30, "horizon": 7},
)
automl = AutoML(config)
results = automl.train()
```

---

## 🔮 Prediction

```python
import numpy as np
predictions = automl.predict(np.array([[5.1, 3.5, 1.4, 0.2]]))
```

---

## 📦 Export & Deploy

```python
# Export model
automl.export(format="both")  # TorchScript + ONNX

# Generate a FastAPI server
automl.deploy(output_dir="my_api/")
# Then run: cd my_api && uvicorn app:app --reload
```

---

## 🔧 Hyperparameter Tuning

```python
config = AutoMLConfig(data_path="data.csv", target_column="label")
automl = AutoML(config)
results = automl.tune_and_train()  # Optuna-powered HPO
```

---

## 💻 CLI (No-Code Mode)

```bash
# Train
automl train --data=data.csv --target=label --epochs=30

# With tuning
automl train --data=data.csv --target=label --tune --tune-trials=50

# Hardware info
automl info

# Deploy
automl deploy --model-path=automl_output/exported/model_scripted.pt
```

---

## 🏗️ Architecture

| Module              | Purpose                                        |
|---------------------|-------------------------------------------------|
| `config.py`         | Dataclass-based configuration                   |
| `detector.py`       | Auto-detect data type & task                    |
| `data_loader.py`    | Universal data ingestion                        |
| `preprocessing.py`  | Per-modality preprocessing                      |
| `model_zoo.py`      | Model registry & selection                      |
| `architecture.py`   | Configurable NN builder                         |
| `tuner.py`          | Optuna-based HPO                                |
| `trainer.py`        | Training engine (epochs, early stop, AMP)       |
| `metrics.py`        | Evaluation & visualization                      |
| `inference.py`      | Unified predict() API                           |
| `exporter.py`       | ONNX / TorchScript / FastAPI scaffold           |
| `hardware.py`       | Auto hardware detection (CUDA, MPS, CPU)        |
| `cli.py`            | Command-line interface                          |
| `utils.py`          | Logging, seeding, helpers                       |

---

## 📊 Supported Models

| Data Type    | Models Available                                    |
|-------------|-----------------------------------------------------|
| Tabular     | MLP, Random Forest, XGBoost, Gradient Boosting      |
| Image       | ResNet18, ResNet50, EfficientNet-B0, Custom CNN      |
| Text        | TextCNN, DistilBERT                                  |
| Time-Series | LSTM, Transformer                                    |

---

## 📋 Features

- ✅ Auto data type & task detection
- ✅ Auto preprocessing (scaling, encoding, normalization)
- ✅ Auto model selection
- ✅ Configurable architectures (layers, activations, dropout)
- ✅ Training engine with early stopping, checkpointing, gradient clipping
- ✅ Mixed-precision (AMP) training
- ✅ Auto hardware detection (CUDA / MPS / CPU)
- ✅ Hyperparameter tuning (Optuna)
- ✅ Training curves & confusion matrix plots
- ✅ Unified predict() API
- ✅ Export to TorchScript & ONNX
- ✅ FastAPI + Docker deployment scaffold
- ✅ CLI for no-code training
