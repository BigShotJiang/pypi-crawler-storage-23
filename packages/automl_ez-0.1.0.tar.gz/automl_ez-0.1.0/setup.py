from setuptools import setup, find_packages

setup(
    name="automl-ez",
    version="0.1.0",
    description="Universal AutoML Library – end-to-end ML/DL pipelines with a single call.",
    author="Mickey2004",
    python_requires=">=3.9",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.21",
        "pandas>=1.3",
        "scikit-learn>=1.0",
        "torch>=1.12",
        "torchvision>=0.13",
        "matplotlib>=3.5",
        "Pillow>=9.0",
        "optuna>=3.0",
    ],
    extras_require={
        "text": ["transformers>=4.20"],
        "xgboost": ["xgboost>=1.6"],
        "deploy": ["fastapi>=0.100", "uvicorn[standard]"],
        "onnx": ["onnx>=1.12"],
        "all": [
            "transformers>=4.20",
            "xgboost>=1.6",
            "fastapi>=0.100",
            "uvicorn[standard]",
            "onnx>=1.12",
            "tensorboard>=2.10",
        ],
    },
    entry_points={
        "console_scripts": [
            "automl=automl_lib.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
