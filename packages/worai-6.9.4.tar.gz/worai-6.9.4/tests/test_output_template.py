from __future__ import annotations

from datetime import datetime
from pathlib import Path

from worai.core.output_template import render_output_path_template


def test_render_output_template_without_sequence() -> None:
    out = render_output_path_template(
        "canonical_{profile}_{date}.csv",
        profile_name="acme",
        now=datetime(2026, 2, 27, 9, 30, 0),
    )
    assert out == Path("canonical_acme_20260227.csv")


def test_render_output_template_with_sequence(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / "canonical_acme_20260227_001.csv").write_text("x", encoding="utf-8")
    out = render_output_path_template(
        "canonical_{profile}_{date}_{seq:3}.csv",
        profile_name="acme",
        now=datetime(2026, 2, 27, 9, 30, 0),
    )
    assert out == Path("canonical_acme_20260227_002.csv")
