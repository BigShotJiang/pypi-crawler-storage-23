from __future__ import annotations

from rdflib import Graph
from typer.testing import CliRunner

from worai.commands import structured_data as structured_data_cmd
from worai.commands import validate as validate_cmd


class _DummyResult:
    def __init__(self) -> None:
        self.conforms = True
        self.warning_count = 0
        self.report_text = "OK"
        self.report_graph = Graph()
        self.data_graph = Graph()
        self.shape_source_map = {}


def test_validate_jsonld_subcommand_uses_validate_file(monkeypatch) -> None:
    calls = {}

    def _stub_validate_file(input_file: str, shape):
        calls["input"] = input_file
        calls["shape"] = shape
        return _DummyResult()

    monkeypatch.setattr(validate_cmd, "validate_file", _stub_validate_file)
    runner = CliRunner()
    result = runner.invoke(
        validate_cmd.app,
        ["jsonld", "data.jsonld", "--shape", "review-snippet"],
    )

    assert result.exit_code == 0
    assert "deprecated" in result.output.lower()
    assert calls["input"] == "data.jsonld"
    assert calls["shape"] == ["review-snippet"]


def test_validate_legacy_warns_on_deprecation(monkeypatch) -> None:
    monkeypatch.setattr(validate_cmd, "validate_file", lambda *_args, **_kwargs: _DummyResult())
    runner = CliRunner()
    result = runner.invoke(validate_cmd.app, ["data.jsonld"])

    assert result.exit_code == 0
    assert "deprecated" in result.output.lower()


def test_validate_legacy_rejects_webpage_url(monkeypatch) -> None:
    def _stub_validate_file(*_args, **_kwargs):
        raise RuntimeError("failed to parse")

    monkeypatch.setattr(validate_cmd, "validate_file", _stub_validate_file)
    runner = CliRunner()
    result = runner.invoke(validate_cmd.app, ["https://example.com/page"])

    assert result.exit_code != 0
    assert "structured-data validate page" in str(result.exception).lower()


def test_structured_data_validate_page_uses_render_options(monkeypatch) -> None:
    calls = {}

    def _stub_validate_jsonld_from_url(url, shape_specs=None, render_options=None):
        calls["url"] = url
        calls["shape"] = shape_specs
        calls["options"] = render_options
        return _DummyResult()

    monkeypatch.setattr(structured_data_cmd, "validate_jsonld_from_url", _stub_validate_jsonld_from_url)
    runner = CliRunner()
    result = runner.invoke(
        structured_data_cmd.app,
        [
            "validate",
            "page",
            "https://example.com",
            "--shape",
            "review-snippet",
            "--timeout-ms",
            "1000",
            "--wait-until",
            "load",
            "--headed",
            "--ignore-https-errors",
        ],
    )

    assert result.exit_code == 0
    assert calls["url"] == "https://example.com"
    assert calls["shape"] == ["review-snippet"]
    assert calls["options"].timeout_ms == 1000
    assert calls["options"].wait_until == "load"
    assert calls["options"].headless is False
    assert calls["options"].ignore_https_errors is True
