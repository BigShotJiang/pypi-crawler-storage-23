"""
Sprint 9: Production Telemetrics Platform — test suite.

Tests cover:
- JSONL file written when events are emitted
- get_summary() returns correct event counts and structure
- query_events() filters by module / event_type / since_seconds
- replay_events() loads from JSONL correctly
- get_performance_report() includes latency stats (p50/p95/p99)
- get_cost_report() includes per-module and per-model breakdown
- get_security_report() includes block rates and risk distribution
- In-memory buffer doesn't grow unbounded (maxlen enforced)

Run with: pytest tests/test_telemetrics.py -v
"""

import json
import time
from pathlib import Path
from typing import List

import pytest

from antaris_pipeline.telemetrics import TelemetricsCollector
from antaris_pipeline.events import (
    AntarisEvent,
    EventType,
    ConfidenceBasis,
    PerformanceMetrics,
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_event(
    session_id: str = "test",
    module: str = "memory",
    event_type: EventType = EventType.MEMORY_RETRIEVE,
    confidence: float = 0.9,
    latency_ms: float = 50.0,
    cost_usd: float = 0.001,
    tokens: int = 100,
    payload: dict = None,
) -> AntarisEvent:
    """Build a minimal AntarisEvent for testing."""
    return AntarisEvent(
        session_id=session_id,
        module=module,
        event_type=event_type,
        confidence=confidence,
        performance=PerformanceMetrics(
            latency_ms=latency_ms,
            cost_usd=cost_usd,
            tokens_processed=tokens,
        ),
        payload=payload or {},
    )


def _guard_event(
    allow: bool = True,
    risk_score: float = 0.1,
    session_id: str = "test",
) -> AntarisEvent:
    """Build a guard-module event."""
    et = EventType.GUARD_ALLOW if allow else EventType.GUARD_DENY
    return AntarisEvent(
        session_id=session_id,
        module="pipeline",
        event_type=et,
        payload={
            "allowed": allow,
            "risk_score": risk_score,
            "direction": "input",
        },
    )


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def collector(tmp_path):
    """Fresh TelemetricsCollector with temp output directory."""
    return TelemetricsCollector(
        session_id="test_session",
        output_dir=tmp_path / "telemetrics",
    )


@pytest.fixture
def populated_collector(tmp_path):
    """Collector pre-loaded with a variety of events."""
    c = TelemetricsCollector(
        session_id="pop_session",
        output_dir=tmp_path / "telemetrics",
    )
    # Memory events
    for i in range(3):
        c.collect_event(_make_event(module="memory", latency_ms=40.0 + i * 5, cost_usd=0.002))
    # Router events
    for i in range(2):
        c.collect_event(_make_event(
            module="router",
            event_type=EventType.ROUTER_ROUTE,
            latency_ms=30.0 + i * 5,
            cost_usd=0.005,
            payload={"selected_model": "gpt-4o-mini"},
        ))
    # Guard events (allow)
    for i in range(4):
        c.collect_event(_guard_event(allow=True, risk_score=0.1))
    # Guard deny
    c.collect_event(_guard_event(allow=False, risk_score=0.85))
    # Context event
    c.collect_event(_make_event(
        module="context",
        event_type=EventType.CONTEXT_BUILD,
        latency_ms=25.0,
    ))
    # Pipeline event
    c.collect_event(_make_event(
        module="pipeline",
        event_type=EventType.PIPELINE_COMPLETE,
        latency_ms=180.0,
        cost_usd=0.010,
    ))
    return c


# ── 1. JSONL persistence ──────────────────────────────────────────────────────

class TestJsonlPersistence:
    """JSONL file is written when events are emitted."""

    def test_jsonl_file_created_on_init(self, collector):
        """JSONL output file is created during __init__."""
        assert collector.output_file.exists()

    def test_jsonl_file_written_on_collect(self, collector):
        """collect_event() appends a JSON line to the JSONL file."""
        collector.collect_event(_make_event())
        lines = collector.output_file.read_text().strip().split("\n")
        assert len(lines) == 1
        parsed = json.loads(lines[0])
        assert "event_type" in parsed
        assert "session_id" in parsed

    def test_multiple_events_write_multiple_lines(self, collector):
        """Multiple events each produce exactly one line."""
        for _ in range(5):
            collector.collect_event(_make_event())
        lines = [
            l for l in collector.output_file.read_text().strip().split("\n") if l
        ]
        assert len(lines) == 5

    def test_jsonl_lines_are_valid_json(self, collector):
        """Every written line is parseable JSON with required fields."""
        for module in ["memory", "router", "guard"]:
            collector.collect_event(_make_event(module=module))
        for line in collector.output_file.read_text().strip().split("\n"):
            if line:
                obj = json.loads(line)
                assert "event_type" in obj
                assert "module" in obj
                assert "session_id" in obj

    def test_output_dir_creates_parent_dirs(self, tmp_path):
        """output_dir creates nested parent directories if needed."""
        nested = tmp_path / "a" / "b" / "c"
        c = TelemetricsCollector("s1", output_dir=nested)
        assert c.output_file.parent.exists()

    def test_output_file_kwarg_takes_precedence(self, tmp_path):
        """Explicit output_file overrides output_dir."""
        explicit = tmp_path / "custom_file.jsonl"
        c = TelemetricsCollector(
            "s2",
            output_file=explicit,
            output_dir=tmp_path / "should_not_be_used",
        )
        assert c.output_file == explicit


# ── 2. get_summary() ──────────────────────────────────────────────────────────

class TestGetSummary:
    """get_summary() returns correct event counts and structure."""

    def test_summary_empty_collector(self, collector):
        """get_summary() on empty collector has sensible defaults."""
        s = collector.get_summary()
        assert s["total_events"] == 0
        assert s["events_by_module"] == {}
        assert s["session_id"] == "test_session"

    def test_summary_event_count(self, collector):
        """total_events matches the number of collected events."""
        for _ in range(7):
            collector.collect_event(_make_event())
        assert collector.get_summary()["total_events"] == 7

    def test_summary_events_by_module(self, populated_collector):
        """events_by_module counts are correct per module."""
        s = populated_collector.get_summary()
        ebm = s["events_by_module"]
        assert ebm.get("memory", 0) == 3
        assert ebm.get("router", 0) == 2
        assert ebm.get("context", 0) == 1

    def test_summary_events_by_type(self, collector):
        """events_by_type keys match event type values."""
        collector.collect_event(_make_event(event_type=EventType.MEMORY_RETRIEVE))
        collector.collect_event(_make_event(event_type=EventType.ROUTER_ROUTE))
        s = collector.get_summary()
        ebt = s["events_by_type"]
        assert "memory.retrieve" in ebt
        assert "router.route" in ebt

    def test_summary_performance_keys(self, populated_collector):
        """performance dict contains avg_latency_ms, total_cost_usd, total_tokens."""
        perf = populated_collector.get_summary()["performance"]
        assert "avg_latency_ms" in perf
        assert "total_cost_usd" in perf
        assert "total_tokens" in perf
        assert perf["avg_latency_ms"] > 0
        assert perf["total_cost_usd"] > 0

    def test_summary_security_keys(self, populated_collector):
        """security dict contains total_scans, blocks, block_rate."""
        sec = populated_collector.get_summary()["security"]
        assert "total_scans" in sec
        assert "blocks" in sec
        assert "block_rate" in sec

    def test_summary_buffer_utilization(self, collector):
        """buffer_utilization is between 0 and 1."""
        for _ in range(10):
            collector.collect_event(_make_event())
        s = collector.get_summary()
        assert 0.0 <= s["buffer_utilization"] <= 1.0

    def test_summary_required_keys_present(self, populated_collector):
        """get_summary() exposes all required top-level keys."""
        s = populated_collector.get_summary()
        required = [
            "session_id", "total_events", "events_by_module",
            "events_by_type", "performance", "security",
            "average_latencies_ms", "buffer_utilization",
        ]
        for key in required:
            assert key in s, f"Missing key: {key}"


# ── 3. query_events() ─────────────────────────────────────────────────────────

class TestQueryEvents:
    """query_events() filters correctly."""

    def test_query_by_module(self, populated_collector):
        """query_events(module='memory') returns only memory events."""
        results = populated_collector.query_events(module="memory")
        assert len(results) > 0
        for e in results:
            assert e.module == "memory"

    def test_query_by_module_router(self, populated_collector):
        """query_events(module='router') returns only router events."""
        results = populated_collector.query_events(module="router")
        assert len(results) > 0
        for e in results:
            assert e.module == "router"

    def test_query_by_event_type(self, populated_collector):
        """query_events(event_type='router.route') returns only that type."""
        results = populated_collector.query_events(event_type="router.route")
        for e in results:
            assert e.event_type.value == "router.route"

    def test_query_by_module_and_type(self, populated_collector):
        """Combined module+event_type filter returns matching events."""
        results = populated_collector.query_events(
            module="memory", event_type="memory.retrieve"
        )
        for e in results:
            assert e.module == "memory"
            assert e.event_type.value == "memory.retrieve"

    def test_query_limit(self, populated_collector):
        """query_events respects the limit parameter."""
        results = populated_collector.query_events(limit=2)
        assert len(results) <= 2

    def test_query_since_seconds_recent_events_included(self, collector):
        """query_events(since_seconds=60) includes events from last minute."""
        collector.collect_event(_make_event())
        results = collector.query_events(since_seconds=60)
        assert len(results) >= 1

    def test_query_since_seconds_old_events_excluded(self, tmp_path):
        """query_events(since_seconds=1) excludes old events."""
        c = TelemetricsCollector("s_time", output_dir=tmp_path)
        ev = _make_event()
        # Manually set timestamp to the past
        from datetime import datetime, timezone, timedelta
        ev = ev.model_copy(update={"timestamp": datetime.now(timezone.utc) - timedelta(seconds=120)})
        c.collect_event(ev)
        # since_seconds=30 → 2-minute-old event should NOT appear
        results = c.query_events(since_seconds=30)
        assert len(results) == 0

    def test_query_no_filter_returns_all(self, populated_collector):
        """query_events() with no filters returns up to limit events."""
        results = populated_collector.query_events(limit=1000)
        assert len(results) > 0

    def test_query_unknown_module_returns_empty(self, populated_collector):
        """query_events(module='nonexistent') returns empty list."""
        results = populated_collector.query_events(module="nonexistent_xyz")
        assert results == []


# ── 4. replay_events() ───────────────────────────────────────────────────────

class TestReplayEvents:
    """replay_events() loads from JSONL correctly."""

    def test_replay_loads_all_events(self, tmp_path):
        """replay_events() returns all events written to the JSONL file."""
        c = TelemetricsCollector("replay_test", output_dir=tmp_path)
        for i in range(5):
            c.collect_event(_make_event(module=f"module_{i}"))

        replayed = c.replay_events(c.output_file)
        assert len(replayed) == 5

    def test_replayed_events_are_antaris_events(self, tmp_path):
        """replay_events() returns AntarisEvent instances."""
        c = TelemetricsCollector("replay_type", output_dir=tmp_path)
        c.collect_event(_make_event())
        replayed = c.replay_events(c.output_file)
        for ev in replayed:
            assert isinstance(ev, AntarisEvent)

    def test_replay_preserves_event_fields(self, tmp_path):
        """Replayed events have the same field values as original."""
        c = TelemetricsCollector("replay_fields", output_dir=tmp_path)
        orig = _make_event(module="memory", confidence=0.75)
        c.collect_event(orig)
        replayed = c.replay_events(c.output_file)
        assert len(replayed) == 1
        r = replayed[0]
        assert r.module == "memory"
        assert abs(r.confidence - 0.75) < 0.001

    def test_replay_empty_file_returns_empty_list(self, tmp_path):
        """replay_events() on an empty JSONL file returns []."""
        empty_file = tmp_path / "empty.jsonl"
        empty_file.touch()
        c = TelemetricsCollector("replay_empty", output_dir=tmp_path)
        result = c.replay_events(empty_file)
        assert result == []

    def test_replay_nonexistent_file_returns_empty_list(self, tmp_path):
        """replay_events() on a nonexistent file returns []."""
        c = TelemetricsCollector("replay_none", output_dir=tmp_path)
        result = c.replay_events(tmp_path / "does_not_exist.jsonl")
        assert result == []

    def test_replay_from_different_collector(self, tmp_path):
        """A new collector can replay events written by another collector."""
        c1 = TelemetricsCollector("writer", output_dir=tmp_path / "w")
        for _ in range(3):
            c1.collect_event(_make_event())

        c2 = TelemetricsCollector("reader", output_dir=tmp_path / "r")
        events = c2.replay_events(c1.output_file)
        assert len(events) == 3


# ── 5. get_performance_report() ──────────────────────────────────────────────

class TestGetPerformanceReport:
    """get_performance_report() includes latency stats."""

    def test_performance_report_has_per_module(self, populated_collector):
        """get_performance_report() has 'per_module' key."""
        report = populated_collector.get_performance_report()
        assert "per_module" in report

    def test_performance_report_includes_known_modules(self, populated_collector):
        """Modules that emitted latency events appear in per_module."""
        report = populated_collector.get_performance_report()
        assert "memory" in report["per_module"]
        assert "router" in report["per_module"]

    def test_performance_report_has_avg_latency(self, populated_collector):
        """Each module entry has avg_ms."""
        report = populated_collector.get_performance_report()
        for module, stats in report["per_module"].items():
            assert "avg_ms" in stats

    def test_performance_report_p50_p95_p99_with_enough_data(self, tmp_path):
        """p50/p95/p99 are present when there are >= 3 data points."""
        c = TelemetricsCollector("perf_pcts", output_dir=tmp_path)
        latencies = [10.0, 20.0, 30.0, 50.0, 80.0, 100.0, 200.0]
        for lat in latencies:
            c.collect_event(_make_event(latency_ms=lat))
        report = c.get_performance_report()
        module_stats = report["per_module"].get("memory", {})
        assert "p50_ms" in module_stats
        assert "p95_ms" in module_stats
        assert "p99_ms" in module_stats
        # p50 should be between min and max
        assert module_stats["p50_ms"] >= module_stats["min_ms"]
        assert module_stats["p50_ms"] <= module_stats["max_ms"]

    def test_performance_report_overall_key(self, populated_collector):
        """get_performance_report() includes 'overall' key."""
        report = populated_collector.get_performance_report()
        assert "overall" in report

    def test_performance_report_empty_collector(self, collector):
        """get_performance_report() on empty collector returns empty per_module."""
        report = collector.get_performance_report()
        assert report["per_module"] == {}
        assert report["total_events_with_latency"] == 0


# ── 6. get_cost_report() ─────────────────────────────────────────────────────

class TestGetCostReport:
    """get_cost_report() includes per-module and per-model breakdown."""

    def test_cost_report_has_total(self, populated_collector):
        """get_cost_report() includes total_cost_usd."""
        report = populated_collector.get_cost_report()
        assert "total_cost_usd" in report
        assert report["total_cost_usd"] > 0

    def test_cost_report_has_by_module(self, populated_collector):
        """get_cost_report() includes by_module breakdown."""
        report = populated_collector.get_cost_report()
        assert "by_module" in report
        assert len(report["by_module"]) > 0

    def test_cost_report_module_has_percentage(self, populated_collector):
        """Each module entry in by_module has a percentage field."""
        report = populated_collector.get_cost_report()
        for module, data in report["by_module"].items():
            assert "total_usd" in data
            assert "percentage" in data

    def test_cost_report_by_model(self, tmp_path):
        """get_cost_report() includes by_model breakdown when model info is in payload."""
        c = TelemetricsCollector("cost_model", output_dir=tmp_path)
        c.collect_event(_make_event(
            module="router",
            event_type=EventType.ROUTER_ROUTE,
            cost_usd=0.01,
            payload={"selected_model": "gpt-4o-mini"},
        ))
        c.collect_event(_make_event(
            module="router",
            event_type=EventType.ROUTER_ROUTE,
            cost_usd=0.05,
            payload={"selected_model": "claude-opus-4-6"},
        ))
        report = c.get_cost_report()
        assert "by_model" in report
        assert "gpt-4o-mini" in report["by_model"]
        assert "claude-opus-4-6" in report["by_model"]

    def test_cost_report_percentages_sum_to_100(self, populated_collector):
        """Module percentages approximately sum to 100%."""
        report = populated_collector.get_cost_report()
        total_pct = sum(
            data["percentage"] for data in report["by_module"].values()
        )
        assert abs(total_pct - 100.0) < 1.0  # allow floating point rounding

    def test_cost_report_empty_collector(self, collector):
        """get_cost_report() on empty collector returns zero cost."""
        report = collector.get_cost_report()
        assert report["total_cost_usd"] == 0.0


# ── 7. get_security_report() ─────────────────────────────────────────────────

class TestGetSecurityReport:
    """get_security_report() includes block rates and risk distribution."""

    def test_security_report_has_required_keys(self, populated_collector):
        """get_security_report() has all required top-level keys."""
        report = populated_collector.get_security_report()
        for key in ["total_scans", "blocked", "allowed", "block_rate",
                    "risk_distribution", "top_patterns"]:
            assert key in report, f"Missing key: {key}"

    def test_security_report_block_rate(self, populated_collector):
        """block_rate is a float between 0 and 1."""
        report = populated_collector.get_security_report()
        assert 0.0 <= report["block_rate"] <= 1.0

    def test_security_report_counts_blocks(self, tmp_path):
        """blocked count matches the number of GUARD_DENY events."""
        c = TelemetricsCollector("sec_blocks", output_dir=tmp_path)
        for _ in range(5):
            c.collect_event(_guard_event(allow=True))
        for _ in range(2):
            c.collect_event(_guard_event(allow=False, risk_score=0.9))

        report = c.get_security_report()
        assert report["blocked"] == 2
        assert report["allowed"] == 5

    def test_security_report_risk_distribution(self, tmp_path):
        """risk_distribution has low/medium/high keys."""
        c = TelemetricsCollector("sec_risk", output_dir=tmp_path)
        c.collect_event(_guard_event(allow=True, risk_score=0.1))  # low
        c.collect_event(_guard_event(allow=True, risk_score=0.5))  # medium
        c.collect_event(_guard_event(allow=False, risk_score=0.9))  # high

        report = c.get_security_report()
        dist = report["risk_distribution"]
        assert "low" in dist
        assert "medium" in dist
        assert "high" in dist
        assert dist["low"] >= 1
        assert dist["high"] >= 1

    def test_security_report_empty_collector(self, collector):
        """get_security_report() on empty collector returns zeros."""
        report = collector.get_security_report()
        assert report["total_scans"] == 0
        assert report["blocked"] == 0
        assert report["block_rate"] == 0.0

    def test_security_report_top_patterns(self, tmp_path):
        """top_patterns is a list (may be empty if no patterns in payloads)."""
        c = TelemetricsCollector("sec_patterns", output_dir=tmp_path)
        ev = AntarisEvent(
            session_id="s",
            module="pipeline",
            event_type=EventType.GUARD_SCAN,
            payload={
                "allowed": True,
                "risk_score": 0.2,
                "patterns_matched": ["injection", "obfuscation"],
            },
        )
        c.collect_event(ev)
        report = c.get_security_report()
        assert isinstance(report["top_patterns"], list)


# ── 8. Buffer bounds ──────────────────────────────────────────────────────────

class TestBufferBounds:
    """In-memory buffer doesn't grow unbounded."""

    def test_buffer_maxlen_respected(self, tmp_path):
        """Ring buffer never exceeds buffer_size entries."""
        c = TelemetricsCollector("bounded", output_dir=tmp_path, buffer_size=10)
        for _ in range(50):
            c.collect_event(_make_event())
        assert len(c._event_buffer) <= 10

    def test_buffer_maxlen_drops_oldest(self, tmp_path):
        """When buffer fills, oldest events are dropped (ring buffer behaviour)."""
        c = TelemetricsCollector("ring", output_dir=tmp_path, buffer_size=5)
        for i in range(10):
            c.collect_event(_make_event(payload={"index": i}))
        # Buffer should contain the 5 most recent events
        indices = [e.payload.get("index") for e in c._event_buffer]
        assert indices == [5, 6, 7, 8, 9]

    def test_event_count_not_bounded(self, tmp_path):
        """_event_count tracks the total ever collected, not just buffered."""
        c = TelemetricsCollector("count_all", output_dir=tmp_path, buffer_size=5)
        for _ in range(20):
            c.collect_event(_make_event())
        assert c._event_count == 20  # All 20 counted
        assert len(c._event_buffer) == 5  # But only 5 buffered

    def test_reset_clears_buffer(self, populated_collector):
        """reset() empties the event buffer and counters."""
        assert populated_collector._event_count > 0
        populated_collector.reset()
        assert populated_collector._event_count == 0
        assert len(populated_collector._event_buffer) == 0
        assert populated_collector._events_by_module == {}


# ── 9. get_summary() security stats ─────────────────────────────────────────

class TestSummarySecurityIntegration:
    """Integration: get_summary().security reflects guard events."""

    def test_summary_security_reflects_blocks(self, tmp_path):
        """summary.security.blocks matches actual block events."""
        c = TelemetricsCollector("sec_integ", output_dir=tmp_path)
        for _ in range(3):
            c.collect_event(_guard_event(allow=True))
        c.collect_event(_guard_event(allow=False, risk_score=0.8))

        summary = c.get_summary()
        sec = summary["security"]
        assert sec["blocks"] >= 1
        assert sec["total_scans"] >= 4
