# Antaris Suite v3.1.0

Agent infrastructure for intelligent, secure, and memory-persistent AI systems.

**v3.1.0** — Discord message bridge • Compaction hook fixes • Phase 4 roadmaps • All 6 modules consolidated under single canonical repo

## Packages

| Package | Version | Description |
|---------|---------|-------------|
| `antaris-memory` | 3.1.0 | Persistent memory system with BM25 search, WAL, sharding, and Discord bridge |
| `antaris-router` | 4.1.0 | Intelligent model routing with cost tracking, confidence gating, and A/B testing |
| `antaris-guard` | 3.1.0 | Prompt injection detection, reputation tracking, and rate limiting |
| `antaris-context` | 3.1.0 | Context compression, summarization, and relevance scoring |
| `antaris-pipeline` | 3.1.0 | Agent orchestration pipeline with telemetry and OpenClaw integration |
| `antaris-contracts` | 1.1.0 | Versioned state schemas, failure semantics, and debug CLI |
| `antaris-openclaw-plugin` | 1.0.0 | OpenClaw plugin — auto-recall and auto-ingest via lifecycle hooks |

## Architecture

```
antaris-openclaw-plugin   (lifecycle hooks — auto-recall + auto-ingest)
        │
antaris-pipeline          (orchestration)
   ┌────┴────────────────────┐
antaris-memory         antaris-router      antaris-guard      antaris-context
(persistence)          (model selection)   (security)         (compression)
```

## Design Principles

- **Zero external dependencies** on all core Python packages — stdlib only
- **File-based persistence** — no database required
- **Multi-process safe** — cross-platform `FileLock` using `os.mkdir()` atomicity
- **MCP-compatible** — memory and router expose MCP servers
- **Fully tested** — 835 tests, 3 external security reviews (Opus 4.6, GPT-5.2, Gemini Pro)

## Installation

```bash
# Install each package
pip install -e antaris-memory
pip install -e antaris-router
pip install -e antaris-guard
pip install -e antaris-context
pip install -e antaris-pipeline

# Install OpenClaw plugin
openclaw plugins install --link antaris-openclaw-plugin
openclaw plugins enable antaris-memory
```

## What's New in v3.1.0

- 🔗 **Discord Message Bridge** — automatic ingestion of Discord messages into antaris-memory with `message_in` hook
- 🛡️ **Compaction Hook Fixes** — 5s timeout + 30s watchdog for bridge health, auto-restart on failure
- 📋 **Phase 4 Roadmaps** — documented future directions for all 6 packages (v4.0+ features)
- 📦 **Full Consolidation** — all modules now subrepos under antaris-suite (canonical source)
- 🧪 **1,508 Total Tests** — across all packages, all passing locally and on CI

## Release

**v3.1.0** — All 4 external reviews passed (Claude Opus/GPT/Gemini/Shiro). Production-ready for enterprise deployment with full OpenClaw integration.

See `docs/MANIFEST.json` for SHA-256 integrity verification of all source files across 6 packages.
