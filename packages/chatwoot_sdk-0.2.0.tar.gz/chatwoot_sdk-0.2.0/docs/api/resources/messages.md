# Messages

Send and manage messages within conversations.

::: chatwoot.resources.messages.MessagesResource

---

::: chatwoot.resources.messages.AsyncMessagesResource
