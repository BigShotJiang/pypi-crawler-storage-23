# Agents

List and manage agents in an account.

::: chatwoot.resources.agents.AgentsResource

---

::: chatwoot.resources.agents.AsyncAgentsResource
