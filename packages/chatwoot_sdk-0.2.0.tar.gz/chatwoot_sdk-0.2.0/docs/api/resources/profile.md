# Profile

Fetch the currently authenticated user's profile.

::: chatwoot.resources.profile.ProfileResource

---

::: chatwoot.resources.profile.AsyncProfileResource
