# Inboxes

List and retrieve inbox configuration.

::: chatwoot.resources.inboxes.InboxesResource

---

::: chatwoot.resources.inboxes.AsyncInboxesResource
