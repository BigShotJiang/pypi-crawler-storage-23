# Teams

Manage teams and their agent memberships.

::: chatwoot.resources.teams.TeamsResource

---

::: chatwoot.resources.teams.TeamAgentsResource

---

::: chatwoot.resources.teams.AsyncTeamsResource

---

::: chatwoot.resources.teams.AsyncTeamAgentsResource
