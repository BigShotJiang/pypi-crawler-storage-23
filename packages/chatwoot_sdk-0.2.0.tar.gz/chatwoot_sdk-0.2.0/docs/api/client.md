# Client

The main entry point for the SDK. Both clients expose the same resource namespaces — the only difference is sync vs async.

::: chatwoot.client.ChatwootClient

---

::: chatwoot.client.AsyncChatwootClient
