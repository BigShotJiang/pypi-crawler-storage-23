# Types

Pydantic models returned by SDK methods. All fields map 1:1 to Chatwoot API response fields.

## Common

::: chatwoot.types.common

---

## Conversation

::: chatwoot.types.conversation

---

## Message

::: chatwoot.types.message

---

## Contact

::: chatwoot.types.contact

---

## Profile

::: chatwoot.types.profile

---

## Agent

::: chatwoot.types.agent

---

## Inbox

::: chatwoot.types.inbox

---

## Label

::: chatwoot.types.label

---

## Team

::: chatwoot.types.team
