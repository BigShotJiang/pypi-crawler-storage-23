"""Entry point for python -m argus (argus-cv CLI)."""

from argus.cli import app

if __name__ == "__main__":
    app()
