"""AnonCreds schema routes."""
