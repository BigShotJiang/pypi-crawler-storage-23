"""Tests for AnonCreds credential definition routes."""
