"""AnonCreds revocation registry routes."""
