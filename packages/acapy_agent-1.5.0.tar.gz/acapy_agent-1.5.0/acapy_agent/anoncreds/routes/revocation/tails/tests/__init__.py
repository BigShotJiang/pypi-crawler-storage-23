"""Tests for AnonCreds tails file routes."""
