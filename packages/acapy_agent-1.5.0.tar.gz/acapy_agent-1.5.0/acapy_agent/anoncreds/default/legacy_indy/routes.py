"""Routes for Legacy Indy Registry."""
