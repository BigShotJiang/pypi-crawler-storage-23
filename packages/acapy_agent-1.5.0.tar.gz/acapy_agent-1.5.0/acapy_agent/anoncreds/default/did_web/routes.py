"""Routes for DID Web Registry."""
