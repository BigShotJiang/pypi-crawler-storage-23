"""
This is a somewhat-mangled clone of hbmqtt.

Deprecated!
"""

from __future__ import annotations

__path__ = __import__("pkgutil").extend_path(__path__, __name__)
from moat.lib.config import register as _register

_register(__name__)
