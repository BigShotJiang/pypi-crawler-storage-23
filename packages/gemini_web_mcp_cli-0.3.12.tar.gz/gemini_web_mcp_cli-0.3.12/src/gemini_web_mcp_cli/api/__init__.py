"""API server package for Gemini Web MCP CLI."""
