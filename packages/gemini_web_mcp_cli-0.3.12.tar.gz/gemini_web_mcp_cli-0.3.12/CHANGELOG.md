# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [0.3.12] - 2026-02-210

### Fixed
- **Video generation (Veo 3.1) — model not generating video** — the root cause was that `at=` was being stripped from the StreamGenerate request body when Chrome's dummy BotGuard capture didn't include it. Without `at=`, Gemini routes the request to chat/image mode instead of Veo. Fixed by always including Chrome's live `SNlM0e` token as `at=` in all reconstructed requests.
- **Video polling 400 errors** — `batchexecute` polling calls used Python's cached access token, which mismatched Chrome's cookies. Fixed by extracting the live `SNlM0e` from `window.WIZ_global_data` during Token Factory capture and storing it as `_browser_access_token` for all subsequent Chrome-cookie calls.
- **Video URL extraction** — download URL was not found due to structural variation in the response. Added a recursive fallback scanner to `extract_video_url()` that finds any `https://` URL in the nested video data.
- **Music generation 400 error** — same root cause as video: Python's cached `at=` token mismatch with Chrome's session cookies. Fixed by the same Chrome SNlM0e extraction approach.
- **Prompt truncation in Token Factory** — long prompts were truncated by the browser input field. Fixed by typing a short dummy string (`[BotGuard Capture]`) to trigger BotGuard token generation, then rebuilding the full request body in Python with the real prompt.
- **Chrome UI persistence** — Token Factory Chrome sessions were not isolated properly, causing state bleed between captures. Fixed with proper Chrome profile isolation.
- **Login profile selection `^M` bug on retry** — additional hardening around the terminal input fix.
- **`UnboundLocalError` in `cdp.py`** — crash on login terminate when a variable was referenced before assignment.

---

## [0.3.9] - 2026-02-20

### Added
- **`gemcli hack claude -m pro`** — new `--model` / `-m` flag to launch Claude Code with a specific Gemini model (`flash`, `pro`, or `thinking`)
- **Model identity injection** — Gemini now knows which model it's running as (Flash, Pro, or Thinking) and can answer "which model are you?" correctly

### Fixed
- **Pro model context loss on model switch** — when Claude Code switched to Pro, Gemini would respond as if starting a blank conversation. Root cause: the system prompt was being merged inside the first `User:` transcript turn, confusing Gemini. Now system prompt is a clean separate prefix before the conversation history
- **System prompt refusal** — stripped "Claude" and "Anthropic" mentions from system prompts to prevent Gemini's AI identity safety filters from rejecting Claude Code's instructions
- **`[PAST CONVERSATION HISTORY]` placeholder** — Claude Code sends this placeholder when truncating history or switching models. Now properly stripped from all message turns
- **Prompt format** — reverted to the proven v0.3.5 plain transcript format that Gemini handles reliably

---

## [0.3.3] - 2026-02-19

### Fixed
- **`gemcli hack claude` Server Crash** — Moved `fastapi` and `uvicorn` back into core dependencies so the local Gemini API server can actually start out of the box. Added a friendly error message if they are missing instead of failing silently.

---

## [0.3.2] - 2026-02-19

### Fixed
- **CDP Chrome Startup** — Replaced fixed 4-second wait with a 15-second polling loop to support heavy Chrome profiles (like GenAI) when extracting cookies. Also switched CDP connections from `localhost` to `127.0.0.1` to prevent IPv6 resolution issues.

---

## [0.3.1] - 2026-02-20

### Fixed
- **Login profile selection `^M` bug** — `click.prompt` with `click.Choice` caused carriage return (`^M`) instead of Enter in remote/SSH terminals. Replaced with plain prompt + manual validation with `.strip()`.

---

## [0.3.0] - 2026-02-20

### Added
- **File upload support** — upload files (images, PDFs, documents, audio) to Gemini for context in conversations
  - `FileService` with 2-step resumable upload protocol to `push.clients6.google.com`
    - Step 1: `x-goog-upload-command: start` with filename/size → receives upload URL
    - Step 2: `x-goog-upload-command: upload, finalize` with file bytes → receives `/contrib_service/ttl_1d/...` identifier
  - `gemcli chat -f <file>` flag for attaching files (supports multiple `-f` flags)
  - `gemcli file upload <path>` standalone command for raw uploads
  - `chat` MCP tool now accepts `files` parameter (list of local file paths)
  - `file` MCP tool with `upload` action (returns file identifier)
  - `ChatService.send()` accepts `files` parameter — handles upload + format + BotGuard automatically
  - File data format: `[[file_id, 16, null, mime_type], filename, null*6, [0]]` (discovered via Chrome DevTools MCP live capture)
  - MIME type auto-detection via `mimetypes.guess_type()`
  - Bard Activity (`ESY5D` RPC) enabled before first upload per session
  - File uploads route through Token Factory (BotGuard required for attached files)
- **Protocol discovery** — live capture of Gemini file upload using Chrome DevTools MCP
  - Upload endpoint changed from `content-push.googleapis.com` to `push.clients6.google.com`
  - Uses Google's resumable upload protocol (same as NotebookLM)
  - Captured request/response for both upload steps and StreamGenerate with attachment

- **`gemcli hack claude`** — launch Claude Code connected to Gemini models
  - Local Anthropic Messages API-compatible server (`api/server.py`) backed by `GeminiClient`
  - Endpoints: `/v1/messages` (streaming + non-streaming), `/v1/models`, `/health`
  - Model mapping: `gemini-auto` (Flash), `gemini-pro`, `gemini-thinking`, plus Claude model name fallbacks
  - Auto-starts server on a free port, configures `ANTHROPIC_BASE_URL`, launches `claude`, cleans up on exit
  - `hack.py` module adapted from perplexity-web-mcp pattern
  - New `api` optional dependency group (`fastapi`, `uvicorn`)
- **Vibe Coding Alert** and educational/research disclaimer in README

### Changed
- `GeminiClient.send()` now routes through Token Factory when `file_data` is present
- MCP `chat` tool accepts optional `files` array for local file paths
- MCP `file` tool upgraded from stub to working implementation
- MCP module docstring updated (file no longer stub)

---

## [0.2.2] - 2026-02-19

### Added
- **Video generation (Veo 3.1)** — generate videos via `gemcli video` with `--output` for download
  - `VideoService` with Token Factory integration (`force_token_factory=True`)
  - `generated_video` field on `Candidate` model, `has_video` property on `StreamResponse`
  - Video data extraction at `candidate[12][59]` with proper nesting depth
  - hNvQHb-based polling for async video completion (browser cookies + proper payload)
  - `execute_rpc_with_browser_cookies()` on `GeminiClient` for full-auth RPC calls
  - `extract_video_url()` and `extract_video_metadata()` helpers (description, model, duration, resolution, scene)
  - `video` MCP tool with `generate`, `status`, and `download` actions
  - 39 video tests covering models, parser, frame merge, polling, download
- **CDP page fetch download** — browser-context `fetch()` for downloading media from `contribution.usercontent.google.com`
  - `download_via_page_fetch()` in `core/cdp.py` — runs JavaScript `fetch()` with `credentials: 'include'` from the Gemini page context via CDP, bypassing partitioned cookie restrictions
  - `download_media()` on `GeminiClient` — tries CDP page fetch first, falls back to httpx
  - `get_gemini_page_ws_url()` helper to find a Gemini tab's page-level WebSocket URL
  - All three media services (video, music, image) now use the CDP download path
- **Gemini 3.1 Pro support** — Google upgraded Pro to Gemini 3.1 Pro (same hash `e6fa609c3fa255c0`, no code change needed)

### Fixed
- **Media download 403** — video and music downloads from `contribution.usercontent.google.com` returned HTTP 403 because CDP's `Network.getAllCookies` is missing 2 critical cookies (`AEC`, `GOOGLE_ABUSE_EXEMPTION`) that exist only in Chrome's partitioned cookie store. Fixed by downloading via JavaScript `fetch()` from the Gemini page context, which has access to all cookies.
- **Frame merge preserves media data** — `build_stream_response()` no longer loses music/video/image data when a later streaming frame has candidates without media fields
- **Video data nesting** — fixed `extract_video_url` and `extract_video_metadata` to use correct path depth (`video_data[0][0][0][0]` not `video_data[0][0][0]`)
- **CLI video timeout** — increased from 180s to 300s with 15s poll interval to match typical Veo 3.1 generation time

### Changed
- Total test count: 308 (was 269)
- Video polling uses hNvQHb (conversation reload) with full browser cookies instead of kwDCne (async poll)
- Media download: services delegate to `GeminiClient.download_media()` instead of managing httpx directly

---

## [0.2.0] - 2026-02-18

### Added
- **Music generation (Lyria 3)** — generate 30-second music tracks with vocals, lyrics, instrumentals, and cover art
  - `gemcli music` CLI command with `--output` and `--format` (audio/video) options
  - `music` MCP tool with `generate` and `download` actions
  - `MusicService` in service layer (generate + download)
  - `MusicFormat` enum: `AUDIO` (MP3) and `VIDEO` (MP4 with cover art)
  - `MusicGenerationError` exception
  - `generated_music` field on `Candidate` model, `has_music` property on `StreamResponse`
  - Music data extraction at `candidate_data[12][86]` (7-entry array: MP3, MP4, metadata, lyrics, cover art)
  - Track metadata: title, album, genre, mood tags
  - Timestamped lyrics support
- **Music style presets (remix)** — 16 style presets mirroring Gemini's "Pick a track to remix" page
  - `--style / -s` option on `gemcli music` (e.g., `gemcli music "cats" -s 8-bit`)
  - `--list-styles` flag to display all available presets
  - `style` parameter on MCP `music` tool's `generate` action
  - `list_styles` action on MCP `music` tool
  - `core/music_presets.py` with all 16 presets: 90s-rap, latin-pop, folk-ballad, 8-bit, workout, reggaeton, rnb-romance, kawaii-metal, cinematic, emo, afropop, forest-bath, k-pop, birthday-roast, folk-a-cappella, bad-music
  - Convenience aliases (e.g., "rap", "metal", "ambient", "chiptune")
  - Each preset includes exact Google system prompt, preset ID, and asset URLs
  - Preset data injected at `inner[0][9][6]` in StreamGenerate request
- **Tool activation via `inner_req_list[49]`** — `tool_id` parameter on `build_streamgenerate_body()`, `stream_generate()` and `client.send()`
  - `MUSIC_TOOL_ID = 21` constant for Lyria 3
- **Persistent Chrome daemon** (`gemcli chrome start/stop/status`) — for background processes (LaunchAgent, cron) that can't launch Chrome on demand
  - `ChromeManager` in `core/chrome_manager.py` with PID tracking, health checks, and daemon lifecycle
  - Chrome runs headless, survives terminal close via `start_new_session=True`
  - Token Factory auto-discovers persistent Chrome on ports 9222-9231 (zero config)
  - `gemcli doctor` reports Chrome daemon status
  - Token Factory error handler now suggests `gemcli chrome start`
- **BotGuard for tool-based generation** — music generation requires BotGuard token even on Flash model
  - Token Factory routing for `tool_id` requests (not just Pro/Thinking)
  - BotGuard token at `inner[3]`, challenge hash at `inner[4]` in StreamGenerate body
  - CORS headers for music download (`contribution.usercontent.google.com`)
- **RPC Capture Guide** (`docs/research/RPC_CAPTURE_GUIDE.md`) — standardized methodology for discovering new Gemini RPCs
- **66 new tests** — MusicFormat, MusicService, parser extraction, music presets, ChromeManager daemon lifecycle

### Changed
- MCP server now exposes 9 consolidated tools (was 8)
- Total test count: 269 (was 203)

---

## [0.1.3] - 2026-02-16

### Fixed
- Fix OpenClaw skill installation path — add missing `workspace/` directory level (`~/.openclaw/workspace/skills/`)

---

## [0.1.2] - 2026-02-16

### Changed
- Move `mcp[cli]` from optional extra into core dependencies — `uv tool install gemini-web-mcp-cli` now works without any extras
- Remove unused `api` (fastapi/uvicorn) and `mcp` optional dependency groups
- Simplify `[all]` extra to only include `[dev]` tools

### Fixed
- Installation instructions in README updated to reflect simplified install

---

## [0.1.1] - 2026-02-16

### Fixed
- Resolve all ruff lint errors across entire codebase (unused imports, f-strings without placeholders, line-too-long, import sorting)
- Fix GitHub Actions workflow to use `uv sync` instead of `uv pip install --system` (Ubuntu externally managed Python)

### Added
- GitHub Actions release workflow: automated testing (Python 3.11/3.12/3.13), PyPI publish, and GitHub Release on tag push
- Published to PyPI as `gemini-web-mcp-cli`

---

## [0.1.0] - 2026-02-16

Initial alpha release. Full CLI and MCP server for the Gemini web interface with
chat, image generation, video generation, deep research, gems management, and
multi-profile support.

### Added

#### Core Infrastructure
- **Response parser** with UTF-16 frame decoding, JSONP prefix stripping, and nested JSON extraction (`core/parser.py`)
- **RPC transport** with batchexecute and StreamGenerate for direct HTTP to Gemini API (`core/rpc.py`)
- **Auth manager** with CDP login, cookie management, and 3-layer token refresh (`core/auth.py`)
- **Profile manager** with multi-profile support and cross-product profile sharing with NotebookLM MCP (`core/profiles.py`)
- **Constants module** with RPC IDs, endpoints, model hashes, and error codes (`core/constants.py`)
- **Exception hierarchy**: `GeminiError` base with `AuthError`, `APIError`, `UsageLimitExceeded` (1037), `ModelInvalid` (1050/1052), `TemporarilyBlocked` (1060), `TimeoutError`, `ImageGenerationError`, `VideoGenerationError`, `ResearchError`, `ProfileError`
- **Pydantic data models**: `RPCPayload`, `ConversationMetadata`, `StreamResponse`, `BatchResult`, `AuthTokens`, `AuthState`
- **GeminiClient** session manager wrapping transport, auth, and parser (`core/client.py`)

#### Service Layer
- **ChatService** — send messages, stream responses, track conversation metadata
- **ImageService** — generate images via Nano Banana / Imagen, download results
- **VideoService** — generate videos via Veo 3.1, poll status, download results
- **ResearchService** — start Deep Research queries, poll progress, retrieve reports
- **GemsService** — CRUD operations for custom system prompts (Gems)

#### CLI (`gemcli`)
- **Chat command** with model selection (`-m pro/flash/thinking`), output to file (`-o`), and conversation context
- **Interactive REPL** with slash commands: `/model`, `/verify`, `/new`, `/save`, `/history`, `/help`, `/quit`
- **Image generation** command with output path support
- **Video generation** command with output path support
- **Deep Research** command with report output
- **Gems management**: `gems list`, `gems create`, `gems delete`
- **Profile management**: `profile list`, `profile create`, `profile switch`, `profile delete`, `profile sources`
- **Configuration**: `config show`, `config get`, `config set`
- **Login**: `login` (automated CDP), `login --manual` (cookie paste), `login --check` (session validation)
- **Model shortcuts**: `-m pro`, `-m flash`, `-m thinking` with configurable default model
- **Shell completion**: `--install-completion` / `--show-completion`
- **`--version` flag** for version display
- **`--ai` flag** for AI-friendly documentation output
- **Verb-first aliases**: `gemcli list gems`, `gemcli list profiles`, `gemcli list skills`, `gemcli create gem`, `gemcli delete gem`, `gemcli install skill`, `gemcli update skill`

#### MCP Server (`gemini-web-mcp`)
- **8 consolidated MCP tools**: `chat`, `image`, `video`, `research`, `gems`, `canvas` (stub), `code` (stub), `file` (stub)
- Each tool uses action-based dispatch (e.g., `image` supports `generate` and `download` actions)

#### MCP Client Setup (`gemcli setup`)
- **`gemcli setup add <client>`** — one-command MCP configuration for AI tools
- **`gemcli setup remove <client>`** — remove MCP configuration
- **`gemcli setup list`** — show configuration status across all supported clients
- Supported clients: Claude Code, Claude Desktop, Gemini CLI, Cursor, Windsurf, Cline, Antigravity, Codex

#### Skill System (`gemcli skill`)
- **`gemcli skill install <tool>`** — install skill documentation for AI tools
- **`gemcli skill uninstall <tool>`** — remove installed skills
- **`gemcli skill list`** — show installation status across all tools with version info
- **`gemcli skill update [tool]`** — update outdated skill installations
- **`gemcli skill show`** — display full skill documentation
- Supported tools: claude-code, cursor, codex, opencode, gemini-cli, antigravity, cline, openclaw, other
- Two formats: SKILL.md (directory-based with references/) and AGENTS.md (marker-based append for Codex)
- Skill documentation includes: command reference, troubleshooting guide, workflow examples
- Version tracking with automatic injection into frontmatter and HTML comments

#### Diagnostics (`gemcli doctor`)
- **Installation checks**: gemcli and gemini-web-mcp binary detection
- **Chrome checks**: platform-aware Chrome binary detection (macOS/Windows/Linux), saved profile listing
- **Configuration checks**: config directory, profile listing, NotebookLM cross-product detection
- **Authentication checks**: cookie and token validation for active profile
- **MCP client checks**: configuration status across all registered clients (including Claude Code via subprocess)
- **Skill checks**: installation status summary
- **`--verbose` mode**: Python version, platform, Chrome binary path, cookie count, auth timestamps

#### Model Switching
- **Server-confirmed model verification** — extract and verify model hash from Gemini responses
- **Updated model hashes** from live Gemini UI (Feb 2026): Fast (`56fdd199312815e2`), Thinking (`e051ce1aa80aa576`), Pro (`e6fa609c3fa255c0`)
- **Deep recursive scan** for model hash in nested response sublists
- **Legacy model hash support** for backward compatibility
- **`preview` alias** for `fast` model (backward compatibility)
- **Token Factory** (experimental) — Chrome generates BotGuard tokens, Python replays HTTP with stolen token + all browser cookies for Pro/Thinking model access
- **BrowserTransport** — CDP-based Chrome automation for model switching via browser UI

#### Authentication
- **Automated Chrome login via CDP** with profile selection
- **First-run profile setup** with NLM profile reuse option
- **Login defaults to active profile** instead of hardcoded "default"
- **Wait for user login** instead of failing immediately on missing auth
- **NLM Chrome profile directory** support for CDP login
- **Token refresh warnings** suppressed to debug level (only shows with `--verbose`)

#### Documentation
- **README.md** with installation, quick start, profile management, MCP setup, architecture
- **CLAUDE.md** developer guide with architecture, model hashes, token factory details
- **Research documentation** (12 feature docs, auth docs, RPC reference)
- **Skill documentation** (SKILL.md, AGENTS_SECTION.md, command reference, troubleshooting, workflows)

#### Testing
- **203 unit tests** across 9 test files
- Core layer tests: auth, constants, parser, profiles, rpc
- Skill system tests: tool configs, data directory, version injection, install/uninstall, CLI commands
- Token factory tests
- Parser tests using real captured Gemini response data

#### Research & Protocol Documentation
- **Master RPC reference table** (`docs/research/known-rpcs.md`)
- **Authentication flow** documentation (cookie auth, token extraction, 3-layer refresh)
- **Cross-product profiles** documentation (NLM profile sharing)
- **Feature research docs**: chat + streaming, image generation, video generation, deep research, gems, canvas, code execution, file upload, extensions, model switching
- **BotGuard token capture** via fetch/XHR interception research
- **Model switching research** — signed request tokens, browser-driven solutions

---

## [Unreleased]

### Planned
- Token Factory integration into production code (currently experimental)
- Canvas and Code Execution service implementations
- Service/CLI/MCP integration tests

## [0.3.12] - 2026-02-21

---

[0.3.12]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.10...v0.3.12
[0.3.11]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.10...v0.3.11
[0.3.9]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.3...v0.3.9
[0.3.3]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.3.3
[0.3.2]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.3.2
[0.3.1]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.3.1
[0.3.0]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.3.0
[0.2.2]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.2.2
[0.2.0]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.2.0
[0.1.3]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.1.3
[0.1.2]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.1.2
[0.1.1]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.1.1
[0.1.0]: https://github.com/jacob-bd/gemini-web-mcp-cli/releases/tag/v0.1.0
[Unreleased]: https://github.com/jacob-bd/gemini-web-mcp-cli/compare/v0.3.12...HEAD
