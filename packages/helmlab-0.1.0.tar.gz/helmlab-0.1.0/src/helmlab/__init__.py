"""Helmlab — a data-driven analytical color space for perceptual color difference."""

__version__ = "0.1.0"

from helmlab.helmlab import Helmlab

__all__ = ["Helmlab"]
