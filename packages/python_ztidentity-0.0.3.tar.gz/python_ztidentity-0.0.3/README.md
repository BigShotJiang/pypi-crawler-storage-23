# python-ztidentity
Pythonic implementation of the ZeroTier Identity Keys

This is very slow and will not be useful for large scale key generation

## Help needed

This version uses a python based Salsa20 encryption algorithm to closely match the go code
Waiting on better library support or compiled extensions, this code is EXTREMELY slow but matches expected output
