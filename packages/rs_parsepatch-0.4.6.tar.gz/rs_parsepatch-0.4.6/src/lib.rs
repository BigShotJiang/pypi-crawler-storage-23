extern crate parsepatch;
extern crate pyo3;

pub mod common;
pub mod counts;
pub mod diffs;
pub mod init;
pub mod lines;
