from ....domain.device._device import Device

__all__ = [
    "Device",
]
