from .....infrastructure.fully_connected._dense import Dense, LazyLinear


__all__ = [
    "Dense",
    "LazyLinear",
]
