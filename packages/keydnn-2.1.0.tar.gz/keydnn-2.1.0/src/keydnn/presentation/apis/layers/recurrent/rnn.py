from .....infrastructure.recurrent._rnn_module import RNN


__all__ = [
    "RNN",
]
