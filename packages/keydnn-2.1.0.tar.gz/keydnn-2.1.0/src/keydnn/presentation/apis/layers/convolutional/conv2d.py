from .....infrastructure.convolution._conv2d_module import Conv2d

Conv2D = Conv2d

__all__ = [
    "Conv2d",
    "Conv2D",
]
