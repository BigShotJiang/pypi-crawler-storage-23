from .....infrastructure.pooling._pooling_module import MaxPool2d


MaxPool2D = MaxPool2d


__all__ = [
    "MaxPool2d",
    "MaxPool2D",
]
