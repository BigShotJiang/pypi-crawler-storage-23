from .....infrastructure.convolution.transpose._conv2d_transpose_module import (
    Conv2dTranspose,
)


Conv2DTranspose = Conv2dTranspose

__all__ = [
    "Conv2dTranspose",
    "Conv2DTranspose",
]
