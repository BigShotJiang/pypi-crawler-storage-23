from .....infrastructure.recurrent._gru_module import GRU


__all__ = [
    "GRU",
]
