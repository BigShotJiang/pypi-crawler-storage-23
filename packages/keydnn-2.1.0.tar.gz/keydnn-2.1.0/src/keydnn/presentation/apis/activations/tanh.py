from ....infrastructure.activations._modules import Tanh


__all__ = [
    "Tanh",
]
