from ....infrastructure.activations._modules import Sigmoid

__all__ = [
    "Sigmoid",
]
