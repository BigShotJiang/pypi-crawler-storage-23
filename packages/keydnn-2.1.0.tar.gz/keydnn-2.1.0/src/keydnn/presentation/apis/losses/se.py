from ....infrastructure.losses import (
    MSEFn,
    SSEFn,
)
from ....infrastructure.losses import (
    MSE,
    SSE,
)

__all__ = [
    "MSE",
    "SSE",
    "MSEFn",
    "SSEFn",
]
