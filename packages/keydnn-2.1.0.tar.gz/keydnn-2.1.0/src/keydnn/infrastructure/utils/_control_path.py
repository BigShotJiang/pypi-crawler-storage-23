from ...domain.utils._control_path import create_path_builder

default_path_builder = create_path_builder()
"""Default path-builder instance for registering stateful control paths."""
