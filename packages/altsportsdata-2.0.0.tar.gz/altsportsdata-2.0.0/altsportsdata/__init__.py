"""
AltSportsData Python SDK

Official Python SDK for the AltSportsData API — alternative sports
odds, events, and futures data for sportsbooks and betting platforms.

Quick start in Google Colab::

    !pip install altsportsdata

    from altsportsdata import AltSportsData

    client = AltSportsData(api_key="your-key", sport="wsl")
    client.list_upcoming_events()
    client.get_event_odds(event="event-id", market="eventWinner")

API Docs: https://api.dev.altsportsdata.com/public/docs/swagger
"""

__version__ = "2.0.0"
__author__ = "AltSportsData"
__description__ = "Python SDK for AltSportsData API - alternative sports betting data"

from .client import AltSportsData
from .models import (
    # Enums
    SportType,
    OddType,
    EventStatus,
    MarketStatus,
    Settlement,
    PropSettlement,
    LapStatus,
    FutureType,
    ExactasType,
    OverUnderSubMarketType,
    SortOrder,
    # Core models
    Team,
    Athlete,
    RoundScore,
    # Event models
    EventResponse,
    EventListing,
    EventParticipant,
    EventRoundListing,
    EventRoundHeatListing,
    ScoresListing,
    TeamsListing,
    # Jai Alai
    JaiAlaiEvent,
    JaiAlaiOdds,
    ScoreDetail,
    SetDetail,
    TeamDetail,
    # Odds models
    EventWinnerOdd,
    FastestLapOdd,
    HeatOddsAthlete,
    HeatOddsEvent,
    HeatOddsRound,
    HeadToHead,
    PlayerEventParticipant,
    PlayerAthlete,
    PropBet,
    DreamTeam,
    DreamTeamTeam,
    ProjectionExacta,
    ExactasAthlete,
    OverUnderOdd,
    OverUnderGroup,
    MultiOverUnder,
    SelectionDto,
    # SGP
    SgpRequest,
    SgpResponse,
    # Futures
    FutureListing,
    FutureOdds,
    FutureOdd,
    FutureOddAthlete,
    # Sports
    SportsListing,
    # Jai Alai odds
    BaseSelection,
    MoneyLineGroup,
    EventWinnerMarket,
    SpreadSelection,
    SpreadGroup,
    TotalSetsSelection,
    TotalSetsGroup,
    MatchWinnerMarketType,
    SetOdds,
)
from .exceptions import (
    AltSportsDataError,
    AuthenticationError,
    ValidationError,
    RateLimitError,
    NotFoundError,
    PermissionError,
    ServerError,
    NetworkError,
    ConfigurationError,
    DataFormatError,
)

__all__ = [
    "AltSportsData",
    # Enums
    "SportType", "OddType", "EventStatus", "MarketStatus",
    "Settlement", "PropSettlement", "LapStatus", "FutureType",
    "ExactasType", "OverUnderSubMarketType", "SortOrder",
    # Core
    "Team", "Athlete", "RoundScore",
    # Events
    "EventResponse", "EventListing", "EventParticipant",
    "EventRoundListing", "EventRoundHeatListing", "ScoresListing", "TeamsListing",
    # Jai Alai
    "JaiAlaiEvent", "JaiAlaiOdds", "ScoreDetail", "SetDetail", "TeamDetail",
    # Odds
    "EventWinnerOdd", "FastestLapOdd", "HeatOddsAthlete", "HeatOddsEvent",
    "HeatOddsRound", "HeadToHead", "PlayerEventParticipant", "PlayerAthlete",
    "PropBet", "DreamTeam", "DreamTeamTeam", "ProjectionExacta", "ExactasAthlete",
    "OverUnderOdd", "OverUnderGroup", "MultiOverUnder", "SelectionDto",
    # SGP
    "SgpRequest", "SgpResponse",
    # Futures
    "FutureListing", "FutureOdds", "FutureOdd", "FutureOddAthlete",
    # Sports
    "SportsListing",
    # Jai Alai odds
    "BaseSelection", "MoneyLineGroup", "EventWinnerMarket",
    "SpreadSelection", "SpreadGroup", "TotalSetsSelection", "TotalSetsGroup",
    "MatchWinnerMarketType", "SetOdds",
    # Exceptions
    "AltSportsDataError", "AuthenticationError", "ValidationError",
    "RateLimitError", "NotFoundError", "PermissionError", "ServerError",
    "NetworkError", "ConfigurationError", "DataFormatError",
]
