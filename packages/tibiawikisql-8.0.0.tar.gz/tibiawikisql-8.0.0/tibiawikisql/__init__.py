"""API that reads and parses information from `TibiaWiki <https://tibiawiki.fandom.com>`_."""

__author__ = "Allan Galarza"
__copyright__ = "Copyright 2025 Allan Galarza"

__license__ = "Apache 2.0"
__version__ = "8.0.0"
