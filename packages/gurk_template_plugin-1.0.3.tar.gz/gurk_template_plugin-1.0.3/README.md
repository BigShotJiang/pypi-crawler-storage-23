[![License](https://img.shields.io/badge/License-Apache%202.0-yellow?logo=apache&logoColor=white)]()
[![GitHub](https://img.shields.io/badge/GitHub-grey?logo=github)](https://github.com/ArturoRoberti/gurk_template_plugin)
[![PyPI](https://img.shields.io/badge/PyPI-3775A9?logo=pypi&logoColor=white)](https://pypi.org/project/gurk_template_plugin/)
[![Parent](https://img.shields.io/badge/Parent-gurk-brown?logo=github)](https://github.com/ArturoRoberti/gurk)

# gurk-template-plugin
Example plugin for the [gurk package manager](https://github.com/ArturoRoberti/gurk). Used for the `gurk template` command and CI testing.

# License
This project is licensed under the Apache 2.0 License - see the [LICENSE](https://github.com/ArturoRoberti/gurk_template_plugin/blob/main/LICENSE) file for details.
