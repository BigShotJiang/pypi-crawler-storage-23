{%
   include-markdown "../guides/batch-operations.md"
   rewrite-relative-urls=false
%}
