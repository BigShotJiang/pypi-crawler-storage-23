{%
   include-markdown "../../guides/backends/memory.md"
   rewrite-relative-urls=false
%}

## API Reference

::: remote_store.backends.MemoryBackend
