{%
   include-markdown "../guides/concurrency.md"
   rewrite-relative-urls=false
%}
