# Azure Backend

Connect to Azure Blob Storage or Azure Data Lake Storage Gen2.

```python
--8<-- "examples/backends/azure_backend.py"
```
