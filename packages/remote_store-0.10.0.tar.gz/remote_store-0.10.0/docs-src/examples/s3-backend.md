# S3 Backend

Connect to Amazon S3 or any S3-compatible service (MinIO, DigitalOcean Spaces, etc.).

```python
--8<-- "examples/backends/s3_backend.py"
```
