# File Operations

Full Store API: read, write, delete, move, copy, list, metadata, type checks, capabilities, to_key.

```python
--8<-- "examples/file_operations.py"
```
