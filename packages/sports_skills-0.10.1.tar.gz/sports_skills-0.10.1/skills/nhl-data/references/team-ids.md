# NHL Team IDs (ESPN)

| Team | ID | Team | ID |
|------|-----|------|-----|
| Anaheim Ducks | 25 | Nashville Predators | 27 |
| Boston Bruins | 1 | New Jersey Devils | 11 |
| Buffalo Sabres | 2 | New York Islanders | 12 |
| Calgary Flames | 3 | New York Rangers | 13 |
| Carolina Hurricanes | 7 | Ottawa Senators | 14 |
| Chicago Blackhawks | 4 | Philadelphia Flyers | 15 |
| Colorado Avalanche | 17 | Pittsburgh Penguins | 16 |
| Columbus Blue Jackets | 29 | San Jose Sharks | 18 |
| Dallas Stars | 9 | Seattle Kraken | 124292 |
| Detroit Red Wings | 5 | St. Louis Blues | 19 |
| Edmonton Oilers | 6 | Tampa Bay Lightning | 20 |
| Florida Panthers | 26 | Toronto Maple Leafs | 21 |
| Los Angeles Kings | 8 | Utah Mammoth | 129764 |
| Minnesota Wild | 30 | Vancouver Canucks | 22 |
| Montreal Canadiens | 10 | Vegas Golden Knights | 37 |
| | | Washington Capitals | 23 |
| | | Winnipeg Jets | 28 |

**Tip:** Use `get_teams` to get the full, accurate list of team IDs.
