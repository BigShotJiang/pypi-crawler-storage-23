import numpy as np
import pandas as pd
import pytest
from sklearn.linear_model import Ridge, LogisticRegression

from mosaic.pipeline import MOSAICPipeline, MOSAICResult
from mosaic.diagnostics import MOSAICDiagnostics


@pytest.fixture
def multicenter_regression():
    rng = np.random.RandomState(42)
    n_per_center = 100
    centers = np.array(["A"] * n_per_center + ["B"] * n_per_center + ["C"] * n_per_center)
    n = len(centers)
    X = rng.normal(0, 1, (n, 5))
    X[:n_per_center, 0] += 3.0
    X[n_per_center:2*n_per_center, 0] -= 2.0
    y = X @ rng.normal(0, 1, 5) + rng.normal(0, 0.5, n)
    df = pd.DataFrame(X, columns=[f"f{i}" for i in range(5)])
    return df, y, centers


@pytest.fixture
def multicenter_binary():
    rng = np.random.RandomState(42)
    n_per_center = 100
    centers = np.array(["A"] * n_per_center + ["B"] * n_per_center + ["C"] * n_per_center)
    n = len(centers)
    X = rng.normal(0, 1, (n, 5))
    X[:n_per_center, 0] += 2.0
    logits = X @ rng.normal(0, 1, 5)
    y = (logits > 0).astype(float)
    df = pd.DataFrame(X, columns=[f"f{i}" for i in range(5)])
    return df, y, centers


def test_full_pipeline_regression(multicenter_regression):
    X, y, centers = multicenter_regression
    pipe = MOSAICPipeline(
        harmonizer="ot",
        robust_learner="anchor",
        uncertainty="weighted_conformal",
        base_estimator=Ridge(),
    )
    pipe.fit(X, y, center_ids=centers)

    assert pipe.is_fitted_
    result = pipe.predict(X[:10], center_id="A")
    assert isinstance(result, MOSAICResult)
    assert result.prediction.shape == (10,)
    assert result.lower is not None
    assert result.upper is not None
    assert result.harmonized is True
    assert result.is_new_center is False


def test_pipeline_no_harmonizer(multicenter_regression):
    X, y, centers = multicenter_regression
    pipe = MOSAICPipeline(
        harmonizer=None,
        robust_learner="anchor",
        uncertainty=None,
        base_estimator=Ridge(),
    )
    pipe.fit(X, y, center_ids=centers)
    result = pipe.predict(X[:5])
    assert result.prediction.shape == (5,)
    assert result.lower is None
    assert result.harmonized is False


def test_pipeline_no_anchor(multicenter_regression):
    X, y, centers = multicenter_regression
    pipe = MOSAICPipeline(
        harmonizer="ot",
        robust_learner=None,
        uncertainty=None,
        base_estimator=Ridge(),
    )
    pipe.fit(X, y, center_ids=centers)
    result = pipe.predict(X[:5], center_id="B")
    assert result.prediction.shape == (5,)


def test_pipeline_with_cal_set(multicenter_regression):
    X, y, centers = multicenter_regression
    pipe = MOSAICPipeline(
        harmonizer="ot",
        robust_learner="anchor",
        uncertainty="weighted_conformal",
        base_estimator=Ridge(),
    )
    pipe.fit(X[:200], y[:200], center_ids=centers[:200], X_cal=X[200:], y_cal=y[200:])
    assert pipe.is_fitted_
    result = pipe.predict(X[200:210], center_id="C")
    assert result.lower is not None


def test_pipeline_new_center(multicenter_regression):
    X, y, centers = multicenter_regression
    pipe = MOSAICPipeline(
        harmonizer="ot",
        robust_learner="anchor",
        uncertainty=None,
        base_estimator=Ridge(),
    )
    pipe.fit(X, y, center_ids=centers)
    result = pipe.predict(X[:5], center_id="D_new")
    assert result.is_new_center is True


def test_pipeline_register_center(multicenter_regression):
    X, y, centers = multicenter_regression
    pipe = MOSAICPipeline(
        harmonizer="ot",
        robust_learner="anchor",
        uncertainty=None,
        base_estimator=Ridge(),
    )
    pipe.fit(X, y, center_ids=centers)
    assert "D" not in pipe.known_centers_

    rng = np.random.RandomState(99)
    X_new = pd.DataFrame(rng.normal(5, 1, (80, 5)), columns=[f"f{i}" for i in range(5)])
    pipe.register_center("D", X_new)
    assert "D" in pipe.known_centers_
    result = pipe.predict(X_new[:5], center_id="D")
    assert result.is_new_center is False


def test_pipeline_diagnose(multicenter_regression):
    X, y, centers = multicenter_regression
    pipe = MOSAICPipeline(
        harmonizer="ot",
        robust_learner="anchor",
        uncertainty="weighted_conformal",
        base_estimator=Ridge(),
    )
    pipe.fit(X, y, center_ids=centers)
    diag = pipe.diagnose(X[:10], center_id="A")
    assert isinstance(diag, MOSAICDiagnostics)
    assert isinstance(diag.feature_shifts, dict)
    assert diag.anchor_stability is not None
    assert 0 <= diag.anchor_stability <= 1
    assert diag.ot_map_summary["n_centers"] == 3
    assert diag.calibration_alpha == 0.10


def test_pipeline_save_load(multicenter_regression, tmp_path):
    X, y, centers = multicenter_regression
    pipe = MOSAICPipeline(
        harmonizer="ot",
        robust_learner="anchor",
        uncertainty=None,
        base_estimator=Ridge(),
    )
    pipe.fit(X, y, center_ids=centers)
    preds_before = pipe.predict(X[:5], center_id="A").prediction

    save_path = str(tmp_path / "test_model.mosaic")
    pipe.save(save_path)
    loaded = MOSAICPipeline.load(save_path)
    preds_after = loaded.predict(X[:5], center_id="A").prediction
    np.testing.assert_array_almost_equal(preds_before, preds_after)


def test_pipeline_not_fitted():
    pipe = MOSAICPipeline()
    with pytest.raises(RuntimeError, match="not fitted"):
        pipe.predict(np.zeros((5, 3)))


def test_pipeline_center_ids_array(multicenter_regression):
    X, y, centers = multicenter_regression
    pipe = MOSAICPipeline(
        harmonizer="ot",
        robust_learner="anchor",
        uncertainty=None,
        base_estimator=Ridge(),
    )
    pipe.fit(X, y, center_ids=centers)
    result = pipe.predict(X[:10], center_ids=np.array(["A"] * 5 + ["B"] * 5))
    assert result.prediction.shape == (10,)
    assert result.harmonized is True
