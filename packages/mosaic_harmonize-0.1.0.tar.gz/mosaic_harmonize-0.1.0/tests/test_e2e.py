"""End-to-end integration test with realistic synthetic multi-center clinical data.

Simulates the IVF use case: 4 training centers with distribution shift,
1 held-out test center. Full pipeline: OT harmonization → anchor regression
→ weighted conformal prediction.
"""
import numpy as np
import pandas as pd
import pytest
from sklearn.linear_model import Ridge

from mosaic import (
    MOSAICPipeline,
    MOSAICResult,
    MOSAICDiagnostics,
    OTHarmonizer,
    AnchorEstimator,
    ConformalCalibrator,
    CenterRegistry,
)


def _make_multicenter_data(n_per_center=200, n_features=8, seed=42):
    rng = np.random.RandomState(seed)
    centers = ["hospital_A", "hospital_B", "hospital_C", "hospital_D"]
    n_total = n_per_center * len(centers)

    X = rng.normal(0, 1, (n_total, n_features))
    center_ids = np.repeat(centers, n_per_center)

    shifts = {
        "hospital_A": np.array([0, 0, 0, 0, 0, 0, 0, 0], dtype=float),
        "hospital_B": np.array([2, -1, 0.5, 0, 0, 0, 0, 0], dtype=float),
        "hospital_C": np.array([-1, 3, 0, 1, 0, 0, 0, 0], dtype=float),
        "hospital_D": np.array([0.5, 0.5, -2, 0, 1, 0, 0, 0], dtype=float),
    }
    for i, c in enumerate(centers):
        start = i * n_per_center
        end = start + n_per_center
        X[start:end] += shifts[c]

    true_coef = rng.normal(0, 1, n_features)
    y = X @ true_coef + rng.normal(0, 1, n_total)

    cols = [f"feature_{i}" for i in range(n_features)]
    df = pd.DataFrame(X, columns=cols)
    return df, y, center_ids, centers


def _make_new_center_data(n=100, n_features=8, seed=99):
    rng = np.random.RandomState(seed)
    X = rng.normal(0, 1, (n, n_features))
    X[:, 0] += 5.0
    X[:, 1] -= 3.0
    cols = [f"feature_{i}" for i in range(n_features)]
    df = pd.DataFrame(X, columns=cols)
    true_coef = np.random.RandomState(42).normal(0, 1, n_features)
    y = X @ true_coef + rng.normal(0, 1, n)
    return df, y


class TestEndToEndPipeline:

    def test_full_pipeline_with_new_center(self):
        X, y, center_ids, centers = _make_multicenter_data()
        X_new, y_new = _make_new_center_data()

        pipe = MOSAICPipeline(
            harmonizer="ot",
            harmonizer_params={"n_quantiles": 500},
            robust_learner="anchor",
            robust_params={"gammas": [1.5, 3.0, 7.0]},
            uncertainty="weighted_conformal",
            uncertainty_params={"alpha": 0.10},
            base_estimator=Ridge(alpha=1.0),
        )

        n_train = 600
        pipe.fit(
            X.iloc[:n_train], y[:n_train],
            center_ids=center_ids[:n_train],
            X_cal=X.iloc[n_train:], y_cal=y[n_train:],
        )

        result = pipe.predict(X_new, center_id="hospital_E")
        assert isinstance(result, MOSAICResult)
        assert result.prediction.shape == (100,)
        assert result.is_new_center is True
        assert result.lower is not None
        assert result.upper is not None
        assert np.all(result.lower <= result.upper)

    def test_harmonization_reduces_shift(self):
        X, y, center_ids, centers = _make_multicenter_data()

        harmonizer = OTHarmonizer(n_quantiles=500)
        harmonizer.fit(X, center_ids)

        dists_before = harmonizer.wasserstein_distances()
        X_h = harmonizer.transform(X, center_ids=center_ids)

        harmonizer_after = OTHarmonizer(n_quantiles=500)
        harmonizer_after.fit(X_h, center_ids)
        dists_after = harmonizer_after.wasserstein_distances()

        for center in centers:
            if center in dists_before and center in dists_after:
                for feat in dists_before[center]:
                    if feat in dists_after[center]:
                        assert dists_after[center][feat] <= dists_before[center][feat] + 0.1

    def test_anchor_improves_stability(self):
        X, y, center_ids, _ = _make_multicenter_data()

        anchor = AnchorEstimator(base_estimator=Ridge(), gammas=[1.5, 3.0, 7.0])
        anchor.fit(X.values, y, anchors=center_ids)

        assert anchor.stability_score_ > 0
        assert anchor.best_gamma_ in [1.5, 3.0, 7.0]

    def test_conformal_coverage(self):
        X, y, center_ids, _ = _make_multicenter_data()
        from sklearn.model_selection import train_test_split

        X_train, X_rest, y_train, y_rest = train_test_split(
            X.values, y, test_size=0.4, random_state=42
        )
        X_cal, X_test, y_cal, y_test = train_test_split(
            X_rest, y_rest, test_size=0.5, random_state=42
        )

        model = Ridge(alpha=1.0)
        model.fit(X_train, y_train)

        cal = ConformalCalibrator(method="weighted", alpha=0.10)
        cal.calibrate(model, X_cal, y_cal, X_test=X_test)
        result = cal.predict(X_test)
        assert result.lower is not None
        assert result.upper is not None

        covered = (y_test >= result.lower) & (y_test <= result.upper)
        coverage = covered.mean()
        assert coverage >= 0.70

    def test_diagnose_output(self):
        X, y, center_ids, _ = _make_multicenter_data()

        pipe = MOSAICPipeline(
            harmonizer="ot",
            robust_learner="anchor",
            uncertainty="weighted_conformal",
            base_estimator=Ridge(),
        )
        pipe.fit(X, y, center_ids=center_ids)

        diag = pipe.diagnose(X.iloc[:10], center_id="hospital_B")
        assert isinstance(diag, MOSAICDiagnostics)
        assert len(diag.feature_shifts) > 0
        assert diag.anchor_stability is not None
        assert diag.ot_map_summary["n_centers"] == 4
        assert diag.nearest_center is not None
        assert diag.nearest_center != "hospital_B"

    def test_register_and_predict_new_center(self):
        X, y, center_ids, _ = _make_multicenter_data()
        X_new, _ = _make_new_center_data()

        pipe = MOSAICPipeline(
            harmonizer="ot",
            robust_learner="anchor",
            uncertainty=None,
            base_estimator=Ridge(),
        )
        pipe.fit(X, y, center_ids=center_ids)

        result_before = pipe.predict(X_new[:5], center_id="hospital_E")
        assert result_before.is_new_center is True

        pipe.register_center("hospital_E", X_new)
        result_after = pipe.predict(X_new[:5], center_id="hospital_E")
        assert result_after.is_new_center is False
        assert result_after.harmonized is True

    def test_save_load_roundtrip(self, tmp_path):
        X, y, center_ids, _ = _make_multicenter_data()

        pipe = MOSAICPipeline(
            harmonizer="ot",
            robust_learner="anchor",
            uncertainty=None,
            base_estimator=Ridge(),
        )
        pipe.fit(X, y, center_ids=center_ids)
        preds_orig = pipe.predict(X.iloc[:10], center_id="hospital_A").prediction

        path = str(tmp_path / "e2e_model.mosaic")
        pipe.save(path)
        loaded = MOSAICPipeline.load(path)
        preds_loaded = loaded.predict(X.iloc[:10], center_id="hospital_A").prediction

        np.testing.assert_array_almost_equal(preds_orig, preds_loaded)

    def test_center_registry_integration(self):
        X, y, center_ids, centers = _make_multicenter_data()

        registry = CenterRegistry.from_center_ids(center_ids)
        assert registry.n_centers == 4
        assert "hospital_A" in registry
        assert registry.get_info("hospital_A")["n_samples"] == 200

        summary = registry.summary()
        assert len(summary) == 4
        assert summary["n_samples"].sum() == 800

    def test_low_level_tier_composition(self):
        X, y, center_ids, _ = _make_multicenter_data()
        n_train, n_cal = 600, 100

        harmonizer = OTHarmonizer(n_quantiles=500)
        X_h = harmonizer.fit_transform(X.iloc[:n_train], center_ids[:n_train])

        anchor = AnchorEstimator(base_estimator=Ridge(), gammas=[1.5, 3.0])
        anchor.fit(X_h.values, y[:n_train], anchors=center_ids[:n_train])

        X_cal_h = harmonizer.transform(X.iloc[n_train:n_train+n_cal], center_ids=center_ids[n_train:n_train+n_cal])
        X_test_h = harmonizer.transform(X.iloc[n_train+n_cal:], center_ids=center_ids[n_train+n_cal:])

        cal = ConformalCalibrator(method="weighted", alpha=0.10)
        cal.calibrate(anchor, X_cal_h.values, y[n_train:n_train+n_cal], X_test=X_test_h.values)
        result = cal.predict(X_test_h.values)

        assert result.prediction.shape == (len(X_test_h),)
        assert result.lower is not None
        assert np.all(result.lower <= result.upper)
