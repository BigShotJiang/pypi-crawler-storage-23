import numpy as np
import pytest
from mosaic.core.anchor import AnchorEstimator
from sklearn.linear_model import Ridge, LogisticRegression


@pytest.fixture
def regression_data_with_centers():
    rng = np.random.RandomState(42)
    n = 300
    centers = np.array(["A"] * 100 + ["B"] * 100 + ["C"] * 100)
    X = rng.normal(0, 1, (n, 5))
    center_effect = np.zeros(n)
    center_effect[:100] = 2.0
    center_effect[100:200] = -1.0
    center_effect[200:] = 0.5
    y = X @ rng.normal(0, 1, 5) + center_effect + rng.normal(0, 0.5, n)
    return X, y, centers


@pytest.fixture
def binary_data_with_centers():
    rng = np.random.RandomState(42)
    n = 300
    centers = np.array(["A"] * 100 + ["B"] * 100 + ["C"] * 100)
    X = rng.normal(0, 1, (n, 5))
    logits = X @ rng.normal(0, 1, 5)
    y = (logits > 0).astype(float)
    return X, y, centers


def test_vrex_regression(regression_data_with_centers):
    X, y, centers = regression_data_with_centers
    est = AnchorEstimator(base_estimator=Ridge(), task_type="regression")
    est.fit(X, y, anchors=centers)

    assert est.is_fitted_
    assert est.best_gamma_ in [1.5, 3.0, 7.0]
    preds = est.predict(X[:10])
    assert preds.shape == (10,)


def test_stability_score(regression_data_with_centers):
    X, y, centers = regression_data_with_centers
    est = AnchorEstimator(base_estimator=Ridge())
    est.fit(X, y, anchors=centers)
    score = est.stability_score_
    assert 0 <= score <= 1


def test_auto_task_detection(regression_data_with_centers, binary_data_with_centers):
    X_r, y_r, c_r = regression_data_with_centers
    est_r = AnchorEstimator()
    est_r.fit(X_r, y_r, anchors=c_r)
    assert est_r.task_type_ == "regression"

    X_b, y_b, c_b = binary_data_with_centers
    est_b = AnchorEstimator()
    est_b.fit(X_b, y_b, anchors=c_b)
    assert est_b.task_type_ == "binary"


def test_custom_gammas(regression_data_with_centers):
    X, y, centers = regression_data_with_centers
    est = AnchorEstimator(base_estimator=Ridge(), gammas=[0.5, 1.0, 2.0])
    est.fit(X, y, anchors=centers)
    assert est.best_gamma_ in [0.5, 1.0, 2.0]


def test_explicit_val_set(regression_data_with_centers):
    X, y, centers = regression_data_with_centers
    est = AnchorEstimator(base_estimator=Ridge())
    est.fit(X[:200], y[:200], anchors=centers[:200], X_val=X[200:], y_val=y[200:])
    assert est.is_fitted_


def test_not_fitted_error():
    est = AnchorEstimator()
    with pytest.raises(RuntimeError, match="not fitted"):
        est.predict(np.zeros((5, 3)))


def test_predict_proba_classification(binary_data_with_centers):
    X, y, centers = binary_data_with_centers
    est = AnchorEstimator(base_estimator=LogisticRegression(max_iter=500), task_type="binary")
    est.fit(X, y, anchors=centers)
    proba = est.predict_proba(X[:10])
    assert proba.shape == (10, 2)
    assert np.allclose(proba.sum(axis=1), 1.0)


def test_default_estimator_regression(regression_data_with_centers):
    X, y, centers = regression_data_with_centers
    est = AnchorEstimator(task_type="regression")
    est.fit(X, y, anchors=centers)
    assert est.is_fitted_
    preds = est.predict(X[:5])
    assert preds.shape == (5,)
