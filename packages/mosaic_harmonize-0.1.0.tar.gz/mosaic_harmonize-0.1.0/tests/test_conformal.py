import numpy as np
import pytest
from mosaic.core.conformal import (
    ConformalCalibrator, ConformalResult,
    estimate_likelihood_ratios, weighted_conformal_quantile,
)
from sklearn.linear_model import Ridge, LogisticRegression


@pytest.fixture
def regression_data():
    rng = np.random.RandomState(42)
    X_cal = rng.normal(0, 1, (200, 5))
    y_cal = X_cal @ rng.normal(0, 1, 5) + rng.normal(0, 0.5, 200)
    X_test = rng.normal(0.5, 1, (100, 5))
    y_test = X_test @ rng.normal(0, 1, 5) + rng.normal(0, 0.5, 100)
    model = Ridge().fit(X_cal, y_cal)
    return model, X_cal, y_cal, X_test, y_test


def test_weighted_conformal_regression(regression_data):
    model, X_cal, y_cal, X_test, y_test = regression_data
    cal = ConformalCalibrator(method="weighted", alpha=0.10)
    cal.calibrate(model, X_cal, y_cal, X_test=X_test)
    result = cal.predict(X_test)

    assert isinstance(result, ConformalResult)
    assert result.prediction.shape == (100,)
    assert result.lower.shape == (100,)
    assert result.upper.shape == (100,)
    assert result.intervals.shape == (100, 2)
    assert np.all(result.lower <= result.upper)


def test_weighted_conformal_quantile_known():
    scores = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    weights = np.ones(5)
    q = weighted_conformal_quantile(scores, weights, 1.0, alpha=0.10)
    assert q >= 4.0


def test_estimate_likelihood_ratios():
    rng = np.random.RandomState(0)
    X_cal = rng.normal(0, 1, (100, 3))
    X_test = rng.normal(1, 1, (50, 3))
    r_cal, r_test = estimate_likelihood_ratios(X_cal, X_test)
    assert r_cal.shape == (100,)
    assert r_test.shape == (50,)
    assert np.all(r_cal > 0)
    assert np.all(r_test > 0)
    assert np.all(r_cal <= 100)
    assert np.all(r_test <= 100)


def test_auto_task_type_detection(regression_data):
    model, X_cal, y_cal, X_test, y_test = regression_data
    cal = ConformalCalibrator(method="weighted")
    cal.calibrate(model, X_cal, y_cal, X_test=X_test)
    assert cal.task_type_ == "regression"


def test_not_calibrated_error():
    cal = ConformalCalibrator()
    with pytest.raises(RuntimeError, match="not calibrated"):
        cal.predict(np.zeros((5, 3)))


def test_weighted_requires_x_test(regression_data):
    model, X_cal, y_cal, _, _ = regression_data
    cal = ConformalCalibrator(method="weighted")
    with pytest.raises(ValueError, match="X_test is required"):
        cal.calibrate(model, X_cal, y_cal)


def test_invalid_method():
    with pytest.raises(ValueError, match="method must be"):
        ConformalCalibrator(method="invalid")


def test_conformal_result_fields():
    r = ConformalResult(
        prediction=np.array([1.0]),
        lower=np.array([0.5]),
        upper=np.array([1.5]),
        method="test",
        alpha=0.10,
    )
    assert r.method == "test"
    assert r.alpha == 0.10
    assert r.prediction[0] == 1.0
