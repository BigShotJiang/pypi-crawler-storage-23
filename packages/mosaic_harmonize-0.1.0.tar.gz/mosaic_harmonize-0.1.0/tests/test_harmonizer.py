import numpy as np
import pandas as pd
import pytest
from mosaic.core.harmonizer import OTHarmonizer


@pytest.fixture
def multi_center_data():
    rng = np.random.RandomState(42)
    n = 300
    centers = np.array(["A"] * 100 + ["B"] * 100 + ["C"] * 100)
    df = pd.DataFrame({
        "feat1": np.concatenate([rng.normal(0, 1, 100), rng.normal(3, 1, 100), rng.normal(-2, 1, 100)]),
        "feat2": np.concatenate([rng.normal(10, 2, 100), rng.normal(15, 2, 100), rng.normal(8, 2, 100)]),
        "cat_col": rng.choice(["x", "y"], n),
    })
    return df, centers


def test_fit_transform_reduces_shift(multi_center_data):
    df, centers = multi_center_data
    h = OTHarmonizer(features=["feat1", "feat2"])
    df_h = h.fit_transform(df, centers)

    for col in ["feat1", "feat2"]:
        std_before = df.groupby(pd.Series(centers))[col].mean().std()
        std_after = df_h.groupby(pd.Series(centers))[col].mean().std()
        assert std_after < std_before, f"{col}: shift not reduced"


def test_wasserstein_decreases(multi_center_data):
    df, centers = multi_center_data
    h = OTHarmonizer(features=["feat1", "feat2"])
    h.fit(df, centers)
    dists = h.wasserstein_distances()
    assert len(dists) == 3
    for center, feat_dists in dists.items():
        for feat, d in feat_dists.items():
            assert d >= 0


def test_nan_handling():
    rng = np.random.RandomState(0)
    df = pd.DataFrame({
        "f1": np.concatenate([rng.normal(0, 1, 100), rng.normal(5, 1, 100)]),
        "f2": np.concatenate([rng.normal(0, 1, 100), rng.normal(5, 1, 100)]),
    })
    df.loc[10, "f1"] = np.nan
    df.loc[150, "f2"] = np.nan
    centers = np.array(["A"] * 100 + ["B"] * 100)

    h = OTHarmonizer(features=["f1", "f2"])
    df_h = h.fit_transform(df, centers)
    assert pd.isna(df_h.loc[10, "f1"])
    assert pd.isna(df_h.loc[150, "f2"])


def test_unseen_center_warning(multi_center_data):
    df, centers = multi_center_data
    h = OTHarmonizer(features=["feat1"]).fit(df, centers)
    new_data = pd.DataFrame({"feat1": [1.0, 2.0]})
    with pytest.warns(UserWarning, match="not seen during fit"):
        h.transform(new_data, center_id="UNKNOWN")


def test_auto_detect_features():
    rng = np.random.RandomState(0)
    df = pd.DataFrame({
        "num1": rng.normal(0, 1, 200),
        "num2": rng.normal(0, 1, 200),
        "cat": rng.choice(["a", "b"], 200),
    })
    centers = np.array(["X"] * 100 + ["Y"] * 100)
    h = OTHarmonizer()
    h.fit(df, centers)
    assert "num1" in h.features_
    assert "num2" in h.features_
    assert "cat" not in h.features_


def test_specific_reference():
    rng = np.random.RandomState(0)
    df = pd.DataFrame({
        "f1": np.concatenate([rng.normal(0, 1, 100), rng.normal(5, 1, 100)]),
    })
    centers = np.array(["A"] * 100 + ["B"] * 100)
    h = OTHarmonizer(features=["f1"], reference="A")
    h.fit(df, centers)
    assert h.is_fitted_


def test_fit_transform_equivalence(multi_center_data):
    df, centers = multi_center_data
    h1 = OTHarmonizer(features=["feat1"], n_quantiles=100)
    result1 = h1.fit_transform(df, centers)

    h2 = OTHarmonizer(features=["feat1"], n_quantiles=100)
    h2.fit(df, centers)
    result2 = h2.transform(df, center_ids=centers)

    pd.testing.assert_frame_equal(result1, result2)


def test_dataframe_in_dataframe_out(multi_center_data):
    df, centers = multi_center_data
    h = OTHarmonizer(features=["feat1"])
    result = h.fit_transform(df, centers)
    assert isinstance(result, pd.DataFrame)
    assert list(result.columns) == list(df.columns)


def test_feature_shift_report(multi_center_data):
    df, centers = multi_center_data
    h = OTHarmonizer(features=["feat1", "feat2"]).fit(df, centers)
    report = h.feature_shift_report()
    assert isinstance(report, pd.DataFrame)
    assert "center" in report.columns
    assert "feature" in report.columns
    assert "wasserstein_distance" in report.columns
    assert len(report) > 0


def test_not_fitted_error():
    h = OTHarmonizer()
    with pytest.raises(RuntimeError, match="not fitted"):
        h.transform(pd.DataFrame({"a": [1]}), center_id="X")
