from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd


class CenterRegistry:
    """Tracks known centers, their metadata, and provides center-level queries.

    Works alongside MOSAICPipeline to manage center lifecycle: registration,
    lookup, and incremental updates.
    """

    def __init__(self):
        self._centers: dict[str, dict] = {}

    def register(self, name: str, n_samples: int, metadata: Optional[dict] = None) -> None:
        self._centers[name] = {
            "n_samples": n_samples,
            "metadata": metadata or {},
        }

    def unregister(self, name: str) -> None:
        if name not in self._centers:
            raise KeyError(f"Center '{name}' not registered")
        del self._centers[name]

    @property
    def center_names(self) -> list[str]:
        return list(self._centers.keys())

    @property
    def n_centers(self) -> int:
        return len(self._centers)

    def get_info(self, name: str) -> dict:
        if name not in self._centers:
            raise KeyError(f"Center '{name}' not registered")
        return dict(self._centers[name])

    def summary(self) -> pd.DataFrame:
        if not self._centers:
            return pd.DataFrame(columns=["center", "n_samples"])
        rows = []
        for name, info in self._centers.items():
            row = {"center": name, "n_samples": info["n_samples"]}
            row.update(info.get("metadata", {}))
            rows.append(row)
        return pd.DataFrame(rows)

    def __contains__(self, name: str) -> bool:
        return name in self._centers

    def __len__(self) -> int:
        return len(self._centers)

    def __repr__(self) -> str:
        return f"CenterRegistry(centers={self.center_names})"

    @classmethod
    def from_center_ids(cls, center_ids) -> "CenterRegistry":
        center_ids = np.asarray(center_ids)
        registry = cls()
        for name in np.unique(center_ids):
            registry.register(str(name), int((center_ids == name).sum()))
        return registry
