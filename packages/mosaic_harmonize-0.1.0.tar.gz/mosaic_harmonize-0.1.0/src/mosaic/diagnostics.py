from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd


@dataclass
class MOSAICDiagnostics:
    shift_magnitude: float = 0.0
    feature_shifts: dict[str, float] = field(default_factory=dict)
    anchor_stability: Optional[float] = None
    nearest_center: Optional[str] = None
    calibration_alpha: Optional[float] = None
    ot_map_summary: dict = field(default_factory=dict)

    @classmethod
    def from_pipeline(cls, pipeline, X, center_id: str) -> "MOSAICDiagnostics":
        from mosaic.pipeline import MOSAICPipeline

        diag = cls()

        if pipeline.harmonizer_ is not None:
            h = pipeline.harmonizer_
            X_df = pipeline._to_dataframe(X)

            if center_id in h.maps_:
                dists = {}
                for col, m in h.maps_[center_id].items():
                    ref_q = h.reference_quantiles_[col]
                    c_q = m["center_quantiles"]
                    from scipy.stats import wasserstein_distance
                    dists[col] = float(wasserstein_distance(c_q, ref_q))
                diag.feature_shifts = dists
                diag.shift_magnitude = float(np.mean(list(dists.values()))) if dists else 0.0
            else:
                diag.feature_shifts = {}
                diag.shift_magnitude = 0.0

            # Find nearest known center by average Wasserstein distance
            if h.maps_:
                all_dists = h.wasserstein_distances()
                center_means = {}
                for c, fd in all_dists.items():
                    if fd:
                        center_means[c] = np.mean(list(fd.values()))
                if center_id in center_means:
                    others = {c: v for c, v in center_means.items() if c != center_id}
                    if others:
                        diag.nearest_center = min(others, key=others.get)
                elif center_means:
                    diag.nearest_center = min(center_means, key=center_means.get)

            diag.ot_map_summary = {
                "n_features_mapped": len(h.reference_quantiles_),
                "n_centers": len(h.center_names_),
                "reference": h.reference,
                "center_has_map": center_id in h.maps_,
            }

        if pipeline.anchor_ is not None:
            diag.anchor_stability = pipeline.anchor_.stability_score_

        if pipeline.calibrator_ is not None:
            diag.calibration_alpha = pipeline.calibrator_.alpha

        return diag
