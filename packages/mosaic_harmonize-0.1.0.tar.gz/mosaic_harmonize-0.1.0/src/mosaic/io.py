from __future__ import annotations

import pickle
from pathlib import Path


def save_pipeline(pipeline, path: str) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(pipeline, f, protocol=pickle.HIGHEST_PROTOCOL)


def load_pipeline(path: str):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"No file at {path}")
    with open(path, "rb") as f:
        return pickle.load(f)
