import warnings
from typing import Optional, Union

import numpy as np
import pandas as pd
from scipy.interpolate import interp1d
from scipy.stats import wasserstein_distance


class OTHarmonizer:
    """1D Optimal Transport quantile mapping for multi-center feature alignment.

    Learns per-center OT maps to a reference distribution and applies them
    to align features across centers.

    Parameters
    ----------
    n_quantiles : int
        Number of quantile points for the OT map.
    features : list of str or None
        Column names to harmonize. None = auto-detect numeric columns.
    reference : str
        "global" pools all centers as reference, or a specific center name.
    min_samples : int
        Minimum non-null samples per feature per center to build a map.
    """

    def __init__(
        self,
        n_quantiles: int = 1000,
        features: Optional[list[str]] = None,
        reference: str = "global",
        min_samples: int = 50,
    ):
        self.n_quantiles = n_quantiles
        self.features = features
        self.reference = reference
        self.min_samples = min_samples
        self.is_fitted_ = False

    def fit(self, X: pd.DataFrame, center_ids: np.ndarray) -> "OTHarmonizer":
        """Learn per-center OT maps to the reference distribution.

        Parameters
        ----------
        X : pd.DataFrame
            Training features.
        center_ids : array-like
            Center label for each row.
        """
        X = self._validate_dataframe(X)
        center_ids = np.asarray(center_ids)
        if len(center_ids) != len(X):
            raise ValueError(f"center_ids length {len(center_ids)} != X length {len(X)}")

        self.center_names_ = list(np.unique(center_ids))

        if self.features is not None:
            self.features_ = [f for f in self.features if f in X.columns]
        else:
            self.features_ = [
                c for c in X.select_dtypes(include=[np.number]).columns
                if X[c].notna().sum() >= self.min_samples
            ]

        quantiles = np.linspace(0, 1, self.n_quantiles + 1)

        self.reference_quantiles_ = {}
        for col in self.features_:
            if self.reference == "global":
                vals = X[col].dropna().values.astype(float)
            else:
                mask = center_ids == self.reference
                vals = X.loc[mask, col].dropna().values.astype(float)
            if len(vals) < self.min_samples:
                continue
            self.reference_quantiles_[col] = np.quantile(vals, quantiles)

        self.maps_ = {}
        for center in self.center_names_:
            center_mask = center_ids == center
            center_maps = {}
            for col in self.reference_quantiles_:
                c_vals = X.loc[center_mask, col].dropna().values.astype(float)
                if len(c_vals) < self.min_samples:
                    continue
                c_q = np.quantile(c_vals, quantiles)
                ref_q = self.reference_quantiles_[col]
                forward = interp1d(
                    c_q, ref_q, bounds_error=False,
                    fill_value=(ref_q[0], ref_q[-1]),
                )
                center_maps[col] = {"forward": forward, "center_quantiles": c_q}
            self.maps_[center] = center_maps

        self.is_fitted_ = True
        return self

    def transform(
        self,
        X: pd.DataFrame,
        center_id: Optional[str] = None,
        center_ids: Optional[np.ndarray] = None,
    ) -> pd.DataFrame:
        """Align features to the reference distribution.

        Provide either center_id (all rows from one center) or
        center_ids (per-row center labels).
        """
        self._check_fitted()
        X = self._validate_dataframe(X)
        X_out = X.copy()

        if center_id is not None and center_ids is not None:
            raise ValueError("Provide center_id or center_ids, not both")
        if center_id is not None:
            center_ids = np.full(len(X), center_id)
        if center_ids is None:
            raise ValueError("Must provide center_id or center_ids")
        center_ids = np.asarray(center_ids)

        for center in np.unique(center_ids):
            if center not in self.maps_:
                warnings.warn(
                    f"Center '{center}' not seen during fit. Data returned unchanged.",
                    UserWarning,
                    stacklevel=2,
                )
                continue
            row_mask = center_ids == center
            for col, m in self.maps_[center].items():
                if col not in X_out.columns:
                    continue
                val_mask = row_mask & X_out[col].notna()
                if val_mask.sum() == 0:
                    continue
                X_out.loc[val_mask, col] = m["forward"](
                    X_out.loc[val_mask, col].values.astype(float)
                )

        return X_out

    def fit_transform(
        self, X: pd.DataFrame, center_ids: np.ndarray
    ) -> pd.DataFrame:
        return self.fit(X, center_ids).transform(X, center_ids=center_ids)

    def wasserstein_distances(self) -> dict[str, dict[str, float]]:
        """Per-center, per-feature Wasserstein distance to reference."""
        self._check_fitted()
        result = {}
        quantiles = np.linspace(0, 1, self.n_quantiles + 1)
        for center, cmap in self.maps_.items():
            dists = {}
            for col, m in cmap.items():
                ref_q = self.reference_quantiles_[col]
                c_q = m["center_quantiles"]
                dists[col] = float(wasserstein_distance(c_q, ref_q))
            result[center] = dists
        return result

    def feature_shift_report(self) -> pd.DataFrame:
        """DataFrame of center × feature × shift magnitude."""
        self._check_fitted()
        rows = []
        dists = self.wasserstein_distances()
        for center, feat_dists in dists.items():
            for feat, dist in feat_dists.items():
                rows.append({"center": center, "feature": feat, "wasserstein_distance": dist})
        return pd.DataFrame(rows)

    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError("OTHarmonizer is not fitted. Call fit() first.")

    @staticmethod
    def _validate_dataframe(X):
        if isinstance(X, np.ndarray):
            X = pd.DataFrame(X, columns=[f"f{i}" for i in range(X.shape[1])])
        if not isinstance(X, pd.DataFrame):
            raise TypeError(f"Expected pd.DataFrame or np.ndarray, got {type(X)}")
        return X
