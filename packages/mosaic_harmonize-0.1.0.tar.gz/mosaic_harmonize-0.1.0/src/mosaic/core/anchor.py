import warnings
from typing import Optional

import numpy as np
from sklearn.base import BaseEstimator, RegressorMixin, ClassifierMixin, clone
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import r2_score, roc_auc_score, accuracy_score


class AnchorEstimator:
    """Domain-robust estimator using anchor regression or V-REx reweighting.

    Uses center IDs as anchor variables to penalize predictions that depend
    on center-specific patterns. If anchorboosting is installed and the base
    estimator is LightGBM-compatible, uses AnchorBooster. Otherwise falls back
    to V-REx iterative sample reweighting.

    Parameters
    ----------
    base_estimator : sklearn-compatible estimator or None
        Any estimator with fit/predict. None defaults to Ridge (regression)
        or LogisticRegression (classification).
    gammas : list of float or None
        Anchor penalty strengths to try. Default: [1.5, 3.0, 7.0].
    task_type : str
        "auto", "regression", "binary", or "multiclass".
    n_vrex_rounds : int
        Number of V-REx reweighting iterations (fallback mode).
    """

    def __init__(
        self,
        base_estimator=None,
        gammas: Optional[list[float]] = None,
        task_type: str = "auto",
        n_vrex_rounds: int = 5,
    ):
        self.base_estimator = base_estimator
        self.gammas = gammas or [1.5, 3.0, 7.0]
        self.task_type = task_type
        self.n_vrex_rounds = n_vrex_rounds
        self.is_fitted_ = False

    def fit(self, X, y, anchors, X_val=None, y_val=None) -> "AnchorEstimator":
        """Train with anchor regularization, selecting best gamma on validation.

        Parameters
        ----------
        X, y : training data
        anchors : center IDs (array-like, same length as X)
        X_val, y_val : validation data. If None, 20% holdout from X.
        """
        X_arr = X.values if hasattr(X, "values") else np.asarray(X, dtype=float)
        y_arr = np.asarray(y)
        anchors_arr = np.asarray(anchors)

        self.task_type_ = self._detect_task_type(y_arr) if self.task_type == "auto" else self.task_type

        if X_val is None or y_val is None:
            X_arr, X_val_arr, y_arr, y_val_arr, anchors_arr, _ = train_test_split(
                X_arr, y_arr, anchors_arr, test_size=0.2, random_state=42
            )
        else:
            X_val_arr = X_val.values if hasattr(X_val, "values") else np.asarray(X_val, dtype=float)
            y_val_arr = np.asarray(y_val)

        self.anchor_encoder_ = LabelEncoder()
        Z_train = self.anchor_encoder_.fit_transform(anchors_arr.astype(str))

        if self._can_use_anchorboosting():
            self._fit_anchorboosting(X_arr, y_arr, Z_train, X_val_arr, y_val_arr)
        else:
            self._fit_vrex(X_arr, y_arr, anchors_arr, X_val_arr, y_val_arr)

        self.is_fitted_ = True
        return self

    def predict(self, X):
        self._check_fitted()
        X_arr = X.values if hasattr(X, "values") else np.asarray(X, dtype=float)
        return self.best_model_.predict(X_arr)

    def predict_proba(self, X):
        """Predict class probabilities.

        For models with native predict_proba (e.g. LogisticRegression via V-REx),
        delegates directly. For AnchorBooster (binary), converts raw predictions
        to probabilities via sigmoid.
        """
        self._check_fitted()
        X_arr = X.values if hasattr(X, "values") else np.asarray(X, dtype=float)

        if hasattr(self.best_model_, "predict_proba"):
            return self.best_model_.predict_proba(X_arr)

        # AnchorBooster fallback: convert raw predictions to probabilities
        if self.task_type_ == "binary":
            raw = self.best_model_.predict(X_arr).astype(float)
            # Sigmoid if values look like logits (outside [0,1]), else treat as probabilities
            if raw.min() < -0.01 or raw.max() > 1.01:
                prob = 1.0 / (1.0 + np.exp(-raw))
            else:
                prob = np.clip(raw, 0.0, 1.0)
            return np.column_stack([1.0 - prob, prob])

        raise AttributeError(
            f"predict_proba not supported for task_type={self.task_type_!r} "
            "with AnchorBooster backend. Use predict() instead."
        )

    @property
    def best_gamma_(self) -> float:
        self._check_fitted()
        return self._best_gamma

    @property
    def stability_score_(self) -> float:
        """Cross-center prediction stability: 1 - normalized variance of per-center scores."""
        self._check_fitted()
        return self._stability_score

    def _can_use_anchorboosting(self) -> bool:
        try:
            import anchorboosting
            return True
        except ImportError:
            return False

    def _fit_anchorboosting(self, X, y, Z, X_val, y_val):
        from anchorboosting import AnchorBooster

        objective = "regression" if self.task_type_ == "regression" else "binary"
        best_score = -np.inf
        best_model = None
        best_gamma = None

        for gamma in self.gammas:
            try:
                model = AnchorBooster(
                    gamma=gamma, num_boost_round=1000,
                    objective=objective, learning_rate=0.05,
                )
                model.fit(X, y.astype(np.float64), Z=Z)
                preds = model.predict(X_val)
                score = self._score(y_val, preds)
                if score > best_score:
                    best_score = score
                    best_model = model
                    best_gamma = gamma
            except Exception:
                continue

        if best_model is None:
            warnings.warn("All anchorboosting gammas failed, falling back to V-REx")
            self._fit_vrex(X, y, self.anchor_encoder_.inverse_transform(Z), X_val, y_val)
            return

        self.best_model_ = best_model
        self._best_gamma = best_gamma
        self._stability_score = self._compute_stability(X, y, Z, best_model)

    def _fit_vrex(self, X, y, anchors, X_val, y_val):
        centers = np.asarray(anchors).astype(str)
        unique_centers = np.unique(centers)

        best_score = -np.inf
        best_model = None
        best_gamma = None

        for gamma in self.gammas:
            sample_weights = np.ones(len(y), dtype=float)
            model = None

            for _ in range(self.n_vrex_rounds):
                model = self._get_base_estimator()
                model.fit(X, y, sample_weight=sample_weights)

                preds_train = model.predict(X)
                center_risks = {}
                for c in unique_centers:
                    mask = centers == c
                    if mask.sum() < 5:
                        continue
                    center_risks[c] = float(np.mean((y[mask] - preds_train[mask]) ** 2))

                if len(center_risks) < 2:
                    break

                risks = np.array(list(center_risks.values()))
                mean_risk = risks.mean()
                std_risk = risks.std() + 1e-8

                for c in unique_centers:
                    if c not in center_risks:
                        continue
                    mask = centers == c
                    deviation = center_risks[c] - mean_risk
                    w_factor = 1.0 + gamma * 2.0 * deviation / std_risk
                    sample_weights[mask] = np.clip(w_factor, 0.2, 5.0)

            if model is not None:
                preds_val = model.predict(X_val)
                score = self._score(y_val, preds_val)
                if score > best_score:
                    best_score = score
                    best_model = model
                    best_gamma = gamma

        self.best_model_ = best_model or self._get_base_estimator().fit(X, y)
        self._best_gamma = best_gamma or self.gammas[0]
        self._stability_score = self._compute_stability_vrex(X, y, centers, self.best_model_)

    def _get_base_estimator(self):
        if self.base_estimator is not None:
            return clone(self.base_estimator)
        if self.task_type_ == "regression":
            return Ridge(alpha=1.0)
        return LogisticRegression(max_iter=500)

    def _score(self, y_true, y_pred):
        if self.task_type_ == "regression":
            return r2_score(y_true, y_pred)
        if self.task_type_ == "binary":
            try:
                return roc_auc_score(y_true, y_pred)
            except ValueError:
                return accuracy_score(y_true, (y_pred >= 0.5).astype(int))
        return accuracy_score(y_true, y_pred)

    def _compute_stability(self, X, y, Z, model):
        unique_z = np.unique(Z)
        if len(unique_z) < 2:
            return 1.0
        scores = []
        for z in unique_z:
            mask = Z == z
            if mask.sum() < 5:
                continue
            scores.append(self._score(y[mask], model.predict(X[mask])))
        if len(scores) < 2:
            return 1.0
        var = np.var(scores)
        return float(max(0, 1.0 - var / (np.mean(np.abs(scores)) + 1e-8)))

    def _compute_stability_vrex(self, X, y, centers, model):
        unique_c = np.unique(centers)
        if len(unique_c) < 2:
            return 1.0
        scores = []
        for c in unique_c:
            mask = centers == c
            if mask.sum() < 5:
                continue
            scores.append(self._score(y[mask], model.predict(X[mask])))
        if len(scores) < 2:
            return 1.0
        var = np.var(scores)
        return float(max(0, 1.0 - var / (np.mean(np.abs(scores)) + 1e-8)))

    @staticmethod
    def _detect_task_type(y):
        unique = np.unique(y[~np.isnan(y)] if np.issubdtype(y.dtype, np.floating) else y)
        if len(unique) == 2:
            return "binary"
        if len(unique) <= 20 and np.all(unique == unique.astype(int)):
            return "multiclass"
        return "regression"

    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError("AnchorEstimator is not fitted. Call fit() first.")
