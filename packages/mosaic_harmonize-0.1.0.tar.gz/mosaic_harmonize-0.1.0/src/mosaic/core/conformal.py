import warnings
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
from sklearn.base import BaseEstimator, RegressorMixin, ClassifierMixin
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler


@dataclass
class ConformalResult:
    prediction: np.ndarray
    lower: Optional[np.ndarray] = None
    upper: Optional[np.ndarray] = None
    intervals: Optional[np.ndarray] = None
    coverage: Optional[float] = None
    set_sizes: Optional[np.ndarray] = None
    prediction_sets: Optional[np.ndarray] = None
    method: str = ""
    alpha: float = 0.10


def estimate_likelihood_ratios(X_cal: np.ndarray, X_test: np.ndarray):
    """Density ratio w(x) = p_test(x)/p_cal(x) via logistic regression."""
    X_cal_v = X_cal.values if hasattr(X_cal, "values") else np.asarray(X_cal)
    X_test_v = X_test.values if hasattr(X_test, "values") else np.asarray(X_test)

    X_all = np.vstack([X_cal_v, X_test_v]).astype(float)
    y_all = np.array([0] * len(X_cal_v) + [1] * len(X_test_v))

    nan_mask = np.isnan(X_all)
    if nan_mask.any():
        col_means = np.nanmean(X_all, axis=0)
        for j in range(X_all.shape[1]):
            X_all[nan_mask[:, j], j] = col_means[j]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_all)

    clf = LogisticRegression(C=1.0, max_iter=500, solver="lbfgs")
    clf.fit(X_scaled, y_all)

    p_cal = clf.predict_proba(X_scaled[:len(X_cal_v)])
    p_test = clf.predict_proba(X_scaled[len(X_cal_v):])

    ratios_cal = np.clip(p_cal[:, 1] / (p_cal[:, 0] + 1e-8), 0.01, 100)
    ratios_test = np.clip(p_test[:, 1] / (p_test[:, 0] + 1e-8), 0.01, 100)

    return ratios_cal, ratios_test


def weighted_conformal_quantile(
    scores: np.ndarray, weights: np.ndarray, test_weight: float, alpha: float = 0.10
) -> float:
    """Tibshirani et al. (NeurIPS 2019) weighted conformal quantile."""
    scores_aug = np.append(scores, np.inf)
    weights_aug = np.append(weights, test_weight)
    weights_norm = weights_aug / weights_aug.sum()

    idx = np.argsort(scores_aug)
    cum = np.cumsum(weights_norm[idx])
    qi = np.searchsorted(cum, 1 - alpha)
    return scores_aug[idx[min(qi, len(scores_aug) - 1)]]


class ConformalCalibrator:
    """Conformal prediction with optional covariate shift correction.

    Parameters
    ----------
    method : str
        "weighted" (density-ratio reweighted), "standard" (split conformal via MAPIE),
        or "lac" (Least Ambiguous set-valued Classifier via MAPIE).
    alpha : float
        Miscoverage level. 0.10 means 90% target coverage.
    """

    def __init__(self, method: str = "weighted", alpha: float = 0.10):
        if method not in ("weighted", "standard", "lac"):
            raise ValueError(f"method must be 'weighted', 'standard', or 'lac', got '{method}'")
        self.method = method
        self.alpha = alpha
        self.is_calibrated_ = False

    def calibrate(self, model, X_cal, y_cal, X_test=None) -> "ConformalCalibrator":
        """Calibrate using a held-out calibration set.

        Parameters
        ----------
        model : sklearn-compatible estimator
            Must have predict(). For classification, must have predict_proba().
        X_cal, y_cal : calibration data
        X_test : test features (required for method="weighted")
        """
        self.model_ = model
        self.task_type_ = "classification" if hasattr(model, "predict_proba") else "regression"

        X_cal_v = X_cal.values if hasattr(X_cal, "values") else np.asarray(X_cal)
        y_cal_v = np.asarray(y_cal)

        if self.method == "weighted":
            if X_test is None:
                raise ValueError("X_test is required for method='weighted'")
            X_test_v = X_test.values if hasattr(X_test, "values") else np.asarray(X_test)

            preds_cal = model.predict(X_cal_v)
            self.residuals_ = np.abs(y_cal_v - preds_cal)
            self.density_ratios_cal_, self._density_ratios_test_ = estimate_likelihood_ratios(
                X_cal_v, X_test_v
            )
            self._X_test_ref = X_test_v

        elif self.method == "standard":
            self._mapie_reg = self._build_mapie_regressor(model, X_cal_v, y_cal_v)

        elif self.method == "lac":
            self._mapie_cls = self._build_mapie_classifier(model, X_cal_v, y_cal_v)

        self.is_calibrated_ = True
        return self

    def predict(self, X_test) -> ConformalResult:
        """Produce predictions with uncertainty quantification."""
        if not self.is_calibrated_:
            raise RuntimeError("ConformalCalibrator not calibrated. Call calibrate() first.")

        X_test_v = X_test.values if hasattr(X_test, "values") else np.asarray(X_test)
        preds = self.model_.predict(X_test_v)

        if self.method == "weighted":
            return self._predict_weighted(X_test_v, preds)
        elif self.method == "standard":
            return self._predict_standard(X_test_v, preds)
        elif self.method == "lac":
            return self._predict_lac(X_test_v, preds)

    def _predict_weighted(self, X_test_v, preds):
        if np.array_equal(X_test_v, self._X_test_ref):
            ratios_test = self._density_ratios_test_
        else:
            _, ratios_test = estimate_likelihood_ratios(
                np.zeros((len(self.residuals_), X_test_v.shape[1])), X_test_v
            )

        intervals = np.zeros((len(X_test_v), 2))
        for i in range(len(X_test_v)):
            q = weighted_conformal_quantile(
                self.residuals_, self.density_ratios_cal_, ratios_test[i], self.alpha
            )
            intervals[i, 0] = preds[i] - q
            intervals[i, 1] = preds[i] + q

        return ConformalResult(
            prediction=preds,
            lower=intervals[:, 0],
            upper=intervals[:, 1],
            intervals=intervals,
            method="weighted_conformal",
            alpha=self.alpha,
        )

    def _predict_standard(self, X_test_v, preds):
        y_pred, y_pis = self._mapie_reg.predict_interval(X_test_v)
        lo, hi = y_pis[:, 0], y_pis[:, 1]
        return ConformalResult(
            prediction=y_pred,
            lower=lo,
            upper=hi,
            intervals=np.column_stack([lo, hi]),
            method="standard_conformal",
            alpha=self.alpha,
        )

    def _predict_lac(self, X_test_v, preds):
        y_pred, y_sets = self._mapie_cls.predict_set(X_test_v)
        return ConformalResult(
            prediction=y_pred,
            prediction_sets=y_sets,
            set_sizes=y_sets.sum(axis=1).astype(float),
            method="lac_conformal",
            alpha=self.alpha,
        )

    @staticmethod
    def _build_mapie_regressor(model, X_cal, y_cal):
        try:
            from mapie.regression import SplitConformalRegressor
        except ImportError:
            raise ImportError("mapie is required for method='standard'. Install: pip install mapie")

        class _Wrapper(BaseEstimator, RegressorMixin):
            def __init__(self, m):
                self.m = m
            def fit(self, X, y):
                return self
            def predict(self, X):
                return self.m.predict(X)

        wrapper = _Wrapper(model)
        from mosaic.core.conformal import ConformalCalibrator as _self_ref
        mapie = SplitConformalRegressor(wrapper, prefit=True)
        mapie.conformalize(X_cal, y_cal)
        return mapie

    @staticmethod
    def _build_mapie_classifier(model, X_cal, y_cal):
        try:
            from mapie.classification import SplitConformalClassifier
        except ImportError:
            raise ImportError("mapie is required for method='lac'. Install: pip install mapie")

        class _Wrapper(BaseEstimator, ClassifierMixin):
            def __init__(self, m):
                self.m = m
                self.classes_ = np.unique(y_cal)
            def fit(self, X, y):
                return self
            def predict(self, X):
                return self.m.predict(X)
            def predict_proba(self, X):
                return self.m.predict_proba(X)

        wrapper = _Wrapper(model)
        mapie = SplitConformalClassifier(wrapper, prefit=True, conformity_score="lac")
        mapie.conformalize(X_cal, y_cal.astype(int))
        return mapie
