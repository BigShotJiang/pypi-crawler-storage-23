from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from typing import Optional, Union

import numpy as np
import pandas as pd
from sklearn.base import clone

from mosaic.core.harmonizer import OTHarmonizer
from mosaic.core.anchor import AnchorEstimator
from mosaic.core.conformal import ConformalCalibrator, ConformalResult


@dataclass
class MOSAICResult:
    prediction: np.ndarray
    lower: Optional[np.ndarray] = None
    upper: Optional[np.ndarray] = None
    coverage: Optional[float] = None
    is_new_center: bool = False
    harmonized: bool = False
    conformal_result: Optional[ConformalResult] = None


class MOSAICPipeline:
    """End-to-end multi-center harmonization → robust learning → conformal prediction.

    Chains OTHarmonizer → AnchorEstimator → ConformalCalibrator into a single
    fit/predict interface. Each tier is optional and can be disabled.
    """

    def __init__(
        self,
        harmonizer: Optional[str] = "ot",
        harmonizer_params: Optional[dict] = None,
        robust_learner: Optional[str] = "anchor",
        robust_params: Optional[dict] = None,
        uncertainty: Optional[str] = "weighted_conformal",
        uncertainty_params: Optional[dict] = None,
        base_estimator=None,
    ):
        self.harmonizer = harmonizer
        self.harmonizer_params = harmonizer_params or {}
        self.robust_learner = robust_learner
        self.robust_params = robust_params or {}
        self.uncertainty = uncertainty
        self.uncertainty_params = uncertainty_params or {}
        self.base_estimator = base_estimator
        self.is_fitted_ = False

    def fit(
        self,
        X_train,
        y_train,
        center_ids,
        X_cal=None,
        y_cal=None,
        X_val=None,
        y_val=None,
    ) -> "MOSAICPipeline":
        X_df = self._to_dataframe(X_train)
        y_arr = np.asarray(y_train)
        center_arr = np.asarray(center_ids)

        self.known_centers_ = set(np.unique(center_arr).tolist())

        # Tier 1: Harmonization
        if self.harmonizer == "ot":
            self.harmonizer_ = OTHarmonizer(**self.harmonizer_params)
            X_h = self.harmonizer_.fit_transform(X_df, center_arr)
        elif self.harmonizer is None:
            self.harmonizer_ = None
            X_h = X_df
        else:
            raise ValueError(f"Unknown harmonizer: {self.harmonizer!r}. Use 'ot' or None.")

        # Tier 2: Robust learner
        X_h_arr = X_h.values if isinstance(X_h, pd.DataFrame) else np.asarray(X_h)

        if X_val is not None:
            X_val_df = self._to_dataframe(X_val)
            if self.harmonizer_ is not None:
                X_val_df = self.harmonizer_.transform(X_val_df, center_ids=np.full(len(X_val_df), list(self.known_centers_)[0]))
            X_val_arr = X_val_df.values if isinstance(X_val_df, pd.DataFrame) else np.asarray(X_val_df)
            y_val_arr = np.asarray(y_val)
        else:
            X_val_arr = None
            y_val_arr = None

        if self.robust_learner == "anchor":
            rp = dict(self.robust_params)
            if self.base_estimator is not None and "base_estimator" not in rp:
                rp["base_estimator"] = clone(self.base_estimator)
            self.anchor_ = AnchorEstimator(**rp)
            self.anchor_.fit(X_h_arr, y_arr, anchors=center_arr, X_val=X_val_arr, y_val=y_val_arr)
            self.model_ = self.anchor_
        elif self.robust_learner is None:
            self.anchor_ = None
            if self.base_estimator is None:
                raise ValueError("base_estimator required when robust_learner is None")
            self.model_ = clone(self.base_estimator)
            self.model_.fit(X_h_arr, y_arr)
        else:
            raise ValueError(f"Unknown robust_learner: {self.robust_learner!r}. Use 'anchor' or None.")

        # Tier 3: Conformal calibration
        if self.uncertainty is not None:
            method_map = {
                "weighted_conformal": "weighted",
                "weighted": "weighted",
                "standard": "standard",
                "lac": "lac",
            }
            method = method_map.get(self.uncertainty)
            if method is None:
                raise ValueError(f"Unknown uncertainty: {self.uncertainty!r}")

            up = dict(self.uncertainty_params)
            alpha = up.pop("alpha", 0.10)
            self.calibrator_ = ConformalCalibrator(method=method, alpha=alpha)

            if X_cal is not None and y_cal is not None:
                X_cal_df = self._to_dataframe(X_cal)
                if self.harmonizer_ is not None:
                    X_cal_df = self.harmonizer_.transform(
                        X_cal_df,
                        center_ids=np.full(len(X_cal_df), list(self.known_centers_)[0]),
                    )
                X_cal_arr = X_cal_df.values if isinstance(X_cal_df, pd.DataFrame) else np.asarray(X_cal_df)
                y_cal_arr = np.asarray(y_cal)
                self.calibrator_.calibrate(
                    self.model_, X_cal_arr, y_cal_arr,
                    X_test=X_cal_arr if method == "weighted" else None,
                )
            else:
                # Use 20% of training data as calibration set
                from sklearn.model_selection import train_test_split
                _, X_cal_split, _, y_cal_split = train_test_split(
                    X_h_arr, y_arr, test_size=0.2, random_state=42
                )
                self.calibrator_.calibrate(
                    self.model_, X_cal_split, y_cal_split,
                    X_test=X_cal_split if method == "weighted" else None,
                )
        else:
            self.calibrator_ = None

        self.is_fitted_ = True
        return self

    def predict(self, X, center_id: Optional[str] = None, center_ids=None) -> MOSAICResult:
        self._check_fitted()
        X_df = self._to_dataframe(X)

        is_new = False
        if center_id is not None:
            is_new = center_id not in self.known_centers_
        if center_ids is not None:
            unique = set(np.unique(np.asarray(center_ids)).tolist())
            is_new = bool(unique - self.known_centers_)

        harmonized = False
        if self.harmonizer_ is not None:
            if center_id is not None:
                X_df = self.harmonizer_.transform(X_df, center_id=center_id)
            elif center_ids is not None:
                X_df = self.harmonizer_.transform(X_df, center_ids=np.asarray(center_ids))
            else:
                warnings.warn(
                    "No center_id provided; skipping harmonization.",
                    UserWarning, stacklevel=2,
                )
            harmonized = center_id is not None or center_ids is not None

        X_arr = X_df.values if isinstance(X_df, pd.DataFrame) else np.asarray(X_df)
        preds = self.model_.predict(X_arr)

        if self.calibrator_ is not None:
            cr = self.calibrator_.predict(X_arr)
            return MOSAICResult(
                prediction=cr.prediction,
                lower=cr.lower,
                upper=cr.upper,
                coverage=cr.coverage,
                is_new_center=is_new,
                harmonized=harmonized,
                conformal_result=cr,
            )

        return MOSAICResult(
            prediction=preds,
            is_new_center=is_new,
            harmonized=harmonized,
        )

    def diagnose(self, X, center_id: str) -> "MOSAICDiagnostics":
        self._check_fitted()
        from mosaic.diagnostics import MOSAICDiagnostics
        return MOSAICDiagnostics.from_pipeline(self, X, center_id)

    def register_center(self, center_name: str, X_new) -> None:
        """Register a new center by updating OT maps (static mode)."""
        self._check_fitted()
        if self.harmonizer_ is None:
            raise RuntimeError("No harmonizer to update.")
        X_df = self._to_dataframe(X_new)
        center_ids = np.full(len(X_df), center_name)
        all_centers = list(self.known_centers_) + [center_name]

        # Rebuild OT map for the new center only
        quantiles = np.linspace(0, 1, self.harmonizer_.n_quantiles + 1)
        from scipy.interpolate import interp1d
        center_maps = {}
        for col in self.harmonizer_.reference_quantiles_:
            if col not in X_df.columns:
                continue
            c_vals = X_df[col].dropna().values.astype(float)
            if len(c_vals) < self.harmonizer_.min_samples:
                continue
            c_q = np.quantile(c_vals, quantiles)
            ref_q = self.harmonizer_.reference_quantiles_[col]
            forward = interp1d(c_q, ref_q, bounds_error=False, fill_value=(ref_q[0], ref_q[-1]))
            center_maps[col] = {"forward": forward, "center_quantiles": c_q}
        self.harmonizer_.maps_[center_name] = center_maps
        self.harmonizer_.center_names_.append(center_name)
        self.known_centers_.add(center_name)

    def save(self, path: str) -> None:
        from mosaic.io import save_pipeline
        save_pipeline(self, path)

    @classmethod
    def load(cls, path: str) -> "MOSAICPipeline":
        from mosaic.io import load_pipeline
        return load_pipeline(path)

    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError("MOSAICPipeline is not fitted. Call fit() first.")

    @staticmethod
    def _to_dataframe(X):
        if isinstance(X, np.ndarray):
            return pd.DataFrame(X, columns=[f"f{i}" for i in range(X.shape[1])])
        if isinstance(X, pd.DataFrame):
            return X
        raise TypeError(f"Expected pd.DataFrame or np.ndarray, got {type(X)}")
