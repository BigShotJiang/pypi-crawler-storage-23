from unittest.mock import MagicMock

from fluentlog import Level
from fluentlog.events import _ConcreteEvent

from .helpers import POPULATED_FIELDS


def test_msg(complete_event):
    output_fn = MagicMock()

    complete_event._output_fn = output_fn
    complete_event.msg("This is an error message")

    output_fn.assert_called_once_with(
        {
            **POPULATED_FIELDS,
            "level": "INFO",
            "message": "This is an error message",
        }
    )


def test_send():
    output_fn = MagicMock()
    ev = _ConcreteEvent(
        level=Level.INFO, parent_fields={"from_parent": 2}, output_fn=output_fn
    )
    ev.send()
    output_fn.assert_called_once_with({"level": "INFO", "from_parent": 2})


def test_caller():
    output_fn = MagicMock()
    ev = _ConcreteEvent(
        level=Level.INFO, parent_fields={}, output_fn=output_fn
    ).caller()
    ev.send()
    payload = output_fn.call_args.args[0]
    assert payload["code.file.path"].endswith("test_event.py")  # this file
    assert payload["code.function.name"] == "test_caller"
    assert isinstance(payload["code.line.number"], int)

    def helper(e: _ConcreteEvent):
        return e.caller(skip=1)

    output_fn.reset_mock()
    ev = _ConcreteEvent(level=Level.INFO, parent_fields={}, output_fn=output_fn)
    ev = helper(ev)
    ev.send()
    payload = output_fn.call_args.args[0]
    assert payload["code.file.path"].endswith("test_event.py")  # this file
    assert payload["code.function.name"] == "test_caller"
    assert isinstance(payload["code.line.number"], int)
