from datetime import timedelta

import orjson

from fluentlog.output import orjson_fallback_default

from .helpers import POPULATED_FIELDS

# EXPECTED_PAYLOAD is POPULATED_FIELDS but with the serialized string values where relevant
EXPECTED_PAYLOAD = {
    **POPULATED_FIELDS,
    "level": "INFO",
    "any_value": "<class 'object'>",
    "data": "some bytes \x00\x01\x02",
    "exception.type": "ValueError",
    "exception.message": "This is a test error",
    "exception.stacktrace": "ValueError: This is a test error\n",
    "end_of_the_world": "2000-01-01T00:00:00",
    "duration": "0:00:05",
    "time": "2026-01-01T12:00:00",
    "message": "This is an error message",
}


def test_serialization():
    class CustomObject:
        def __repr__(self):
            return "CustomObject()"

    assert orjson_fallback_default(b"hello") == "hello"
    assert orjson_fallback_default(timedelta(seconds=5)) == "0:00:05"
    assert orjson_fallback_default(CustomObject()) == "CustomObject()"


def test_json_output(capsys, complete_event):
    complete_event.msg("This is an error message")
    captured = capsys.readouterr()
    payload = orjson.loads(captured.out)
    assert payload == EXPECTED_PAYLOAD
