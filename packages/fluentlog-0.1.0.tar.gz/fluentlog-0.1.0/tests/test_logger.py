from unittest.mock import MagicMock

from fluentlog import Level, Logger

from .helpers import POPULATED_FIELDS, populate_all_types


def test_filtering():
    output_function = MagicMock()
    logger = Logger().set_output(output_function)

    logger.info().msg("This is an info message")
    output_function.assert_called_once()
    output_function.reset_mock()

    logger.warning().msg("This is a warning message")
    output_function.assert_called_once()
    output_function.reset_mock()

    logger.error().msg("This is an error message")
    output_function.assert_called_once()
    output_function.reset_mock()

    logger.fatal().msg("This is a fatal message")
    output_function.assert_called_once()
    output_function.reset_mock()

    logger.debug().msg("This is a debug message")
    output_function.assert_not_called()

    logger.set_level(Level.DEBUG)
    logger.debug().msg("This is a debug message")
    output_function.assert_called_once()
    output_function.reset_mock()

    logger.trace().msg("This is a trace message")
    output_function.assert_not_called()

    logger.set_level(Level.TRACE)
    logger.trace().msg("This is a trace message")
    output_function.assert_called_once()


def test_binding(time_fn):
    output_function = MagicMock()
    logger = Logger(time_fn=time_fn).set_output(output_function)

    logger.info().int("i", 42).msg("Hello, world!")
    output_function.assert_called_once_with(
        {"level": "INFO", "i": 42, "message": "Hello, world!"}
    )
    output_function.reset_mock()

    logger = populate_all_types(logger.bind()).logger()
    logger.error().msg("This is an error message")
    output_function.assert_called_once_with(
        {**POPULATED_FIELDS, "level": "ERROR", "message": "This is an error message"}
    )


def test_binded_caller(time_fn):
    output_function = MagicMock()
    logger = (
        Logger(time_fn=time_fn).set_output(output_function).bind().caller().logger()
    )

    logger.info().msg("Testing caller")
    output_function.assert_called_once()
    payload = output_function.call_args.args[0]
    assert payload["code.file.path"].endswith("test_logger.py")  # this file
    assert payload["code.function.name"] == "test_binded_caller"
    assert isinstance(payload["code.line.number"], int)
