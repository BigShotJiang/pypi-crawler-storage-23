from unittest.mock import MagicMock

from fluentlog import Logger
from fluentlog.context import (
    context,
    context_logger,
)


def test_log_works_by_default():
    output_fn = MagicMock()
    context().set_output(output_fn).info().msg("Hello, world!")
    output_fn.assert_called_once_with({"level": "INFO", "message": "Hello, world!"})


def test_context_logger_uses_inner_then_restores_outer():
    outer_output = MagicMock()
    inner_output = MagicMock()
    outer = Logger().set_output(outer_output).bind().str("scope", "outer").logger()
    inner = Logger().set_output(inner_output).bind().str("scope", "inner").logger()

    def inner_fn():
        context().info().msg("inside")

    with context_logger(outer) as current:
        assert current is outer
        with context_logger(inner) as current:
            assert current is inner
            inner_fn()
        context().info().msg("outside")

    inner_output.assert_called_once_with(
        {"scope": "inner", "level": "INFO", "message": "inside"}
    )
    outer_output.assert_called_once_with(
        {"scope": "outer", "level": "INFO", "message": "outside"}
    )
