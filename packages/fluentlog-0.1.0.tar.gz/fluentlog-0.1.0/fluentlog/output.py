import sys
import typing
from datetime import timedelta

import orjson

from .typing import log_fields


def orjson_fallback_default(obj: object) -> typing.Any:
    """
    Fallback default function for orjson that handles unserializable objects.

    Bytes are decoded to UTF-8 strings with backslash replacement for errors.
    Timedelta objects are converted to their string representation (e.g. "0:10:05").

    For other unserializable objects, their repr() is used as a fallback.
    """

    if isinstance(obj, bytes):
        return obj.decode("utf-8", errors="backslashreplace")

    if isinstance(obj, timedelta):
        return str(obj)

    return repr(obj)


def json_output(payload: log_fields) -> None:
    """
    Outputs the given object as JSON to stdout using orjson with the fallback default function.
    """
    sys.stdout.buffer.write(
        orjson.dumps(
            payload,
            default=orjson_fallback_default,
            option=orjson.OPT_APPEND_NEWLINE,
        )
    )
