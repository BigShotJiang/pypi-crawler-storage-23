import enum
import typing
from datetime import date, datetime, timedelta
from logging import CRITICAL

# output_function is a function that takes a dictionary of log fields and outputs it (e.g. to stdout or a file)
type output_function = typing.Callable[[dict[str, typing.Any]], None]
# hook_function is a function that takes an Event as an argument and can modify it before it is finalized
type hook_function = typing.Callable[["Event"], "Event"]
# ts_function is a function to generate the current timestamp for an event
type ts_function = typing.Callable[[], datetime]

type log_fields = dict[str, typing.Any]


class Level(enum.IntEnum):
    TRACE = enum.auto()
    DEBUG = enum.auto()
    INFO = enum.auto()
    WARNING = enum.auto()
    ERROR = enum.auto()
    FATAL = enum.auto()

    def __str__(self) -> str:
        return self.name


class LogFieldsBuilder(typing.Protocol):
    """
    LogFieldsBuilder is the fluent interface for building loggers and events including the context.

    This protocol ensures both LoggerBuilder and Event support adding the same field types to the context.
    """

    def any(self, name: str, value: typing.Any) -> typing.Self: ...

    def bool(self, name: str, value: bool) -> typing.Self: ...

    def bytes(self, name: str, value: bytes) -> typing.Self: ...

    def caller(self, skip: int = 0) -> typing.Self:
        """
        Identifies the caller of the log method and adds it to the log fields, with the following fields:

        - `code.file.path`: The full path of the file containing the caller.
        - `code.function.name`: The name of the function containing the caller.
        - `code.line.number`: The line number of the caller in the source code.

        The optional `skip` parameter can be used to skip additional stack frames
        if the caller is wrapped in helper functions.
        """
        ...

    def dict(self, name: str, value: dict) -> typing.Self: ...

    def exception(self, exc: BaseException) -> typing.Self:
        """
        Stores the exception details in the event fields:
        - `exception.type`: the type of the exception (e.g. ValueError)
        - `exception.message`: the message of the exception
        - `exception.stacktrace`: the stack trace of the exception
        """
        ...

    def float(self, name: str, value: float) -> typing.Self: ...

    def func(self, callable: hook_function) -> typing.Self:
        """
        Runs the function if the log level is enabled.
        The function receives the event as an argument and can add fields to it.
        """
        ...

    def int(self, name: str, value: int) -> typing.Self: ...

    def list(self, name: str, value: list) -> typing.Self: ...

    def time(self, name: str, value: typing.Union[date, datetime]) -> typing.Self:
        """
        Adds a time field to the event
        """
        ...

    def timedelta(self, name: str, value: timedelta) -> typing.Self:
        """
        Adds a timedelta field to the event
        """
        ...

    def timestamp(self) -> typing.Self:
        """Adds a timestamp field to the event with the current time in ISO 8601 format."""
        ...

    # str needs to come last because it redefines what str means in the context of the class creation
    # (i.e. name: str would be interpreted Event.str instead of a string type annotation)
    def str(self, name: str, value: str) -> typing.Self: ...


class Event(LogFieldsBuilder, typing.Protocol):
    """
    Event represents a log event. It includes the context building methods plus the msg() and send()
    method to finalize and output the event.
    """

    def msg(self, message: str) -> None:
        """
        Finalizes the event and outputs it.
        The message is a human-readable string that describes the event.
        """
        ...

    def send(self) -> None:
        """
        Finalizes the event and outputs it without a message.
        This is a convenience method that calls msg("").
        """
        ...
