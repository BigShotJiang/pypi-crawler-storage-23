import inspect
from pathlib import Path

_PACKAGE_DIR = Path(__file__).resolve().parent
_DUMMY_TRACEBACK = inspect.Traceback(
    filename="<unknown>",
    lineno=0,
    function="<unknown>",
    code_context=None,
    index=0,
)


def _is_internal_frame(filename: str) -> bool:
    try:
        file_path = Path(filename).resolve()
    except (OSError, RuntimeError):  # pragma: no cover
        return False
    return file_path == _PACKAGE_DIR or _PACKAGE_DIR in file_path.parents


def find_caller_frame(skip: int = 0) -> inspect.Traceback:
    """
    Returns the first frame outside the fluentlog package.

    The ``skip`` parameter can be used to skip additional non-internal frames,
    which is useful when logs are emitted through wrapper functions.

    If no caller frame is found, returns a dummy traceback with placeholder values.
    """
    frame = inspect.currentframe()
    if frame is None:  # pragma: no cover
        # this should never happen in reality
        return _DUMMY_TRACEBACK

    frame = frame.f_back
    while frame is not None:
        if not _is_internal_frame(frame.f_code.co_filename):
            if skip == 0:
                return inspect.getframeinfo(frame)
            skip -= 1
        frame = frame.f_back
    return _DUMMY_TRACEBACK  # pragma: no cover
