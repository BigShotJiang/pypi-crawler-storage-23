from collections.abc import Generator
from contextlib import contextmanager
from contextvars import ContextVar

from .logger import Logger

_context_logger: ContextVar[Logger | None] = ContextVar("_context_logger", default=None)


def context() -> Logger:
    """
    Get the logger for the current context.
    If no logger has been set for the current context, a new logger will be returned and set as
    the context logger.
    """
    logger = _context_logger.get()
    if logger is None:
        logger = Logger()
        _context_logger.set(logger)
    return logger


@contextmanager
def context_logger(logger: Logger) -> Generator[Logger, None, None]:
    """
    Context manager to set the logger for the current context.
    This allows you to pass the logger across functions using a with statement.
    """
    # TODO when we support only python 3.14+ we can replace this with
    # with _context_logger.set(logger) as token:
    #     yield logger
    token = _context_logger.set(logger)
    try:
        yield logger
    finally:
        _context_logger.reset(token)
