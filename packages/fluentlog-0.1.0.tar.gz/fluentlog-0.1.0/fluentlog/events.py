import copy
import traceback
import typing
from datetime import date, datetime, timedelta, timezone

from .helper import find_caller_frame
from .typing import (
    Event,
    Level,
    hook_function,
    log_fields,
    output_function,
    ts_function,
)


class _DummyEvent(Event):  # pragma: no cover
    def msg(self, message: str) -> None:
        pass

    def send(self) -> None:
        pass

    def any(self, name: str, value: typing.Any) -> typing.Self:
        return self

    def bool(self, name: str, value: bool) -> typing.Self:
        return self

    def bytes(self, name: str, value: bytes) -> typing.Self:
        return self

    def caller(self, skip: int = 0) -> typing.Self:
        return self

    def dict(self, name: str, value: dict) -> typing.Self:
        return self

    def exception(self, exc: BaseException) -> typing.Self:
        return self

    def float(self, name: str, value: float) -> typing.Self:
        return self

    def func(self, callable: hook_function) -> typing.Self:
        return self

    def int(self, name: str, value: int) -> typing.Self:
        return self

    def list(self, name: str, value: list) -> typing.Self:
        return self

    def time(self, name: str, value: typing.Union[date, datetime]) -> typing.Self:
        return self

    def timedelta(self, name: str, value: timedelta) -> typing.Self:
        return self

    def timestamp(self) -> typing.Self:
        return self

    def str(self, name: str, value: str) -> typing.Self:
        return self


_DUMMY_EVENT: Event = _DummyEvent()


class _ConcreteEvent(Event):
    __slots__ = ("_fields", "_output_fn", "_time_fn", "_hooks")

    def __init__(
        self,
        *,
        level: Level,
        parent_fields: log_fields,
        output_fn: output_function,
        time_fn: ts_function = lambda: datetime.now(timezone.utc),
        hooks: list[hook_function] = [],
    ) -> None:
        self._fields: log_fields = {"level": str(level), **parent_fields}
        self._output_fn: output_function = output_fn
        self._time_fn: ts_function = time_fn
        self._hooks: list[hook_function] = hooks

    def msg(self, message: str) -> None:
        if message:
            self._fields["message"] = message
        for hook in self._hooks:
            hook(self)
        self._output_fn(self._fields)

    def send(self):
        self.msg("")

    def any(self, name: str, value: typing.Any) -> typing.Self:
        self._fields[name] = value
        return self

    def bool(self, name: str, value: bool) -> typing.Self:
        self._fields[name] = value
        return self

    def bytes(self, name: str, value: bytes) -> typing.Self:
        self._fields[name] = value
        return self

    def caller(self, skip: int = 0) -> typing.Self:
        tb = find_caller_frame(skip=skip)
        self._fields["code.file.path"] = tb.filename
        self._fields["code.function.name"] = tb.function
        self._fields["code.line.number"] = tb.lineno
        return self

    def dict(self, name: str, value: dict) -> typing.Self:
        """
        Add a dict field to the event.
        The dict is deep-copied to prevent mutations after the event is sent from affecting the logged data.
        """
        self._fields[name] = copy.deepcopy(value)
        return self

    def exception(self, exc: BaseException) -> typing.Self:
        """
        Stores the exception details in the event fields:

        - exception.type: the type of the exception (e.g. ValueError)
        - exception.message: the string representation of the exception (e.g. "invalid value")
        - exception.stacktrace: the stack trace of the exception formatted using traceback.format_exception, which
        """
        self._fields["exception.type"] = type(exc).__name__
        self._fields["exception.message"] = str(exc)
        self._fields["exception.stacktrace"] = "".join(
            traceback.format_exception(None, exc, exc.__traceback__)
        )
        return self

    def float(self, name: str, value: float) -> typing.Self:
        self._fields[name] = value
        return self

    def func(self, callable: hook_function) -> typing.Self:
        return typing.cast(typing.Self, callable(self))

    def int(self, name: str, value: int) -> typing.Self:
        self._fields[name] = value
        return self

    def list(self, name: str, value: list) -> typing.Self:
        """
        Add a list field to the event.
        The list is deep-copied to prevent mutations after the event is sent from affecting the logged data.
        """
        self._fields[name] = copy.deepcopy(value)
        return self

    def time(self, name: str, value: typing.Union[datetime, date]) -> typing.Self:
        self._fields[name] = value
        return self

    def timedelta(self, name: str, value: timedelta) -> typing.Self:
        self._fields[name] = value
        return self

    def timestamp(self) -> typing.Self:
        self._fields["time"] = self._time_fn()
        return self

    def str(self, name: str, value: str) -> typing.Self:
        self._fields[name] = value
        return self
