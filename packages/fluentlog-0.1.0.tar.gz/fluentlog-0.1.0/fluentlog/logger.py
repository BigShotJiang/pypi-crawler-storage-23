import copy
import traceback
import typing
from datetime import date, datetime, timedelta, timezone

from .events import _DUMMY_EVENT, _ConcreteEvent
from .output import json_output
from .typing import (
    Event,
    Level,
    LogFieldsBuilder,
    hook_function,
    log_fields,
    output_function,
    ts_function,
)


class Logger:
    __slots__ = ("_level", "_fields", "_output_fn", "_hooks", "_time_fn")

    def __init__(
        self,
        *,
        level: Level = Level.INFO,
        fields: log_fields | None = None,
        output_fn: output_function | None = None,
        hooks: list[hook_function] | None = None,
        time_fn: ts_function | None = None,
    ) -> None:
        self._level: Level = level
        self._fields: log_fields = fields or {}
        self._output_fn: output_function = output_fn or json_output
        self._hooks: list[hook_function] = hooks or []
        self._time_fn: ts_function = time_fn or (lambda: datetime.now(timezone.utc))

    def set_level(self, level: Level) -> None:
        self._level = level

    def set_output(self, output_fn: output_function) -> "Logger":
        self._output_fn = output_fn
        return self

    def _handle_event(self, level: Level) -> Event:
        if self._level > level:
            return _DUMMY_EVENT
        return _ConcreteEvent(
            level=level,
            parent_fields=self._fields,
            output_fn=self._output_fn,
            hooks=self._hooks,
            time_fn=self._time_fn,
        )

    def trace(self) -> Event:
        return self._handle_event(Level.TRACE)

    def debug(self) -> Event:
        return self._handle_event(Level.DEBUG)

    def info(self) -> Event:
        return self._handle_event(Level.INFO)

    def warning(self) -> Event:
        return self._handle_event(Level.WARNING)

    def error(self) -> Event:
        return self._handle_event(Level.ERROR)

    def fatal(self) -> Event:
        return self._handle_event(Level.FATAL)

    def bind(self) -> "LoggerBuilder":
        """
        Creates a new context that inherits the log level and fields of the logger.
        The context can be used to build a new logger with additional fields using the logger() method
        """
        return LoggerBuilder(parent_logger=self)


class LoggerBuilder(LogFieldsBuilder):
    __slots__ = ("_parent", "_fields", "_hooks")

    def __init__(
        self,
        *,
        parent_logger: Logger,
    ) -> None:
        """
        Creates a new context that inherits the log level and fields of the logger.
        The context can be used to build a new logger with additional fields using the logger() method.

        The parent fields are shallowed copied to prevent mutations, and event methods
        that accept dicts or lists will deep copy the data to prevent mutations after the fact
        from affecting the log output.

        The parent hooks are shallowed copied so modifying the parent logger will not modify
        the child logger.
        """
        self._parent = parent_logger
        self._fields: log_fields = {**parent_logger._fields}
        self._hooks: list[hook_function] = [*parent_logger._hooks]

    def any(self, name: str, value: typing.Any) -> "LoggerBuilder":
        self._fields[name] = value
        return self

    def bool(self, name: str, value: bool) -> "LoggerBuilder":
        self._fields[name] = value
        return self

    def bytes(self, name: str, value: bytes) -> "LoggerBuilder":
        self._fields[name] = value
        return self

    def caller(self, skip: int = 0) -> "LoggerBuilder":
        """
        Adds a hook that captures the caller's file, function, and line number for every event.
        The ``skip`` parameter skips additional non-internal frames (useful for wrapper functions).
        """
        caller_hook: hook_function = lambda e: e.caller(skip=skip)
        self._hooks.append(caller_hook)
        return self

    def dict(self, name: str, value: dict) -> "LoggerBuilder":
        """
        Adds a dict field to the context.
        The dict is deep-copied to prevent mutations after the fact from affecting the log output.
        """
        self._fields[name] = copy.deepcopy(value)
        return self

    def exception(self, exc: BaseException) -> "LoggerBuilder":
        """
        Stores the exception details in the event fields:

        - exception.type: the type of the exception (e.g. ValueError)
        - exception.message: the string representation of the exception (e.g. "invalid value")
        - exception.stacktrace: the stack trace of the exception formatted using traceback.format_exception, which
        """
        self._fields["exception.type"] = type(exc).__name__
        self._fields["exception.message"] = str(exc)
        self._fields["exception.stacktrace"] = "".join(
            traceback.format_exception(None, exc, exc.__traceback__)
        )
        return self

    def float(self, name: str, value: float) -> "LoggerBuilder":
        self._fields[name] = value
        return self

    def func(self, callable: hook_function) -> "LoggerBuilder":
        """
        Adds a hook function to the context that will be called with the event as an argument when
        an event is finalized.
        """
        self._hooks.append(callable)
        return self

    def int(self, name: str, value: int) -> "LoggerBuilder":
        self._fields[name] = value
        return self

    def list(self, name: str, value: list) -> "LoggerBuilder":
        """
        Adds a list field to the context.
        The list is deep-copied to prevent mutations after the fact from affecting the log output.
        """
        self._fields[name] = copy.deepcopy(value)
        return self

    def time(self, name: str, value: typing.Union[datetime, date]) -> "LoggerBuilder":
        self._fields[name] = value
        return self

    def timedelta(self, name: str, value: timedelta) -> "LoggerBuilder":
        self._fields[name] = value
        return self

    def str(self, name: str, value: str) -> "LoggerBuilder":
        self._fields[name] = value
        return self

    def timestamp(self) -> "LoggerBuilder":
        ts_hook = lambda e: e.time("time", self._parent._time_fn())
        self._hooks.append(ts_hook)
        return self

    def logger(self) -> Logger:
        return Logger(
            level=self._parent._level,
            fields=self._fields,
            output_fn=self._parent._output_fn,
            hooks=self._hooks,
            time_fn=self._parent._time_fn,
        )
