# Claude Code Instructions

## Git
- NEVER run git commands (add, commit, push, tag, etc.) unless the user explicitly asks
- NEVER mention Claude, AI, or include Co-Authored-By lines in git commit messages
