from scim_base import (
        SCIMBase,
        SCIM_APPS,
        scim_function,
        EnumSCIMAction,
        scim_schema
)
from lcm_base import lcm_action, EnumLCMAction
from mk_users import USERS, USERS_DB, GROUPS, GROUPS_DB, logger
from flask import current_app


class SCIMUsers(SCIMBase):

    # def get_total_results(self, request, resources=None, startIndex=None):
    #     number_users = len(USERS)

    #     if startIndex < number_users:
    #         return number_users

    #     return 0

    def get_one(self, request, obj_id=None):
        return USERS_DB[obj_id]

    def convert_page_params(self, request):
        start_index = int(request.args.get('startIndex', 0))
        count = min(int(request.args.get('count', 50)), None)

        return {
            'startIndex': start_index,
            'count': count
        }

    def run_custom(self, request, page_params={}, **kwargs):
        # this should handle the request, taking into account any flask request
        # query parameters

        # example of filter query string
        # filter=userName+eq+"b8eb04a2-4cc9-40e7-a01f-d1d47c2a56bd"&startIndex=1

        start_index = page_params.get('startIndex', 0)
        count = page_params['count']

        results = USERS[start_index:start_index+count]
        logger.info('%s', results)

        return results


class SCIMGroups(SCIMBase):

    # def get_total_results(self, request, resources=None, startIndex=None):
    #     number_groups = len(GROUPS)

    #     if startIndex < number_groups:
    #         return number_groups

    #     return 0

    def get_one(self, request, obj_id=None):
        return GROUPS_DB[obj_id]

    def convert_page_params(self, request):
        start_index = int(request.args.get('startIndex', 0))
        count = min(int(request.args.get('count', 50)), 50)

        return {
            'startIndex': start_index,
            'count': count
        }

    def run_custom(self, request, page_params={}, **kwargs):
        # this should handle the request, taking into account any flask request
        # query parameters
        start_index = page_params['startIndex']
        count = page_params['count']

        results = []

        results = GROUPS[start_index:start_index+count]
        # TODO look at paginating the members sub-attribute to see if Veza will
        # try to fetch the paginated results
        logger.info('%s', results)

        return results


@scim_schema(app_label='appname')
def get_scim_schema(*args, **kwargs):
    """TODO: Docstring for get_scim_schema.

    :flask_request: TODO
    :returns: TODO

    """

    return {
      "totalResults": 4,
      "itemsPerPage": 4,
      "startIndex": 1,
      "schemas": [
        "urn:ietf:params:scim:api:messages:2.0:ListResponse"
      ],
      "Resources": [
        {
          "schemas": [
            "urn:ietf:params:scim:schemas:core:2.0:Schema"
          ],
          "id": "urn:ietf:params:scim:schemas:core:2.0:User",
          "meta": {
            "resourceType": "Schema",
            "created": "2001-01-01T00:00:00+00:00",
            "lastModified": "2001-01-01T00:00:00+00:00",
            "version": "W/\"07e9640ac446d118dce2ef36c9e12c22d2d92be6\"",
            "location": "https://api.scim.dev/scim/v2/Schemas/urn:ietf:params:scim:schemas:core:2.0:User"
          },
          "name": "User",
          "attributes": [
            {
              "name": "userName",
              "type": "string",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": True,
              "multiValued": False,
              "caseExact": False
            },
            {
              "name": "externalId",
              "type": "string",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": False,
              "multiValued": False,
              "caseExact": False
            },
            {
              "name": "name",
              "type": "complex",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": False,
              "multiValued": False,
              "caseExact": False,
              "subAttributes": [
                {
                  "name": "formatted",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                },
                {
                  "name": "familyName",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                },
                {
                  "name": "givenName",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                }
              ]
            },
            {
              "name": "active",
              "type": "boolean",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": False,
              "multiValued": False,
              "caseExact": False
            },
            {
              "name": "password",
              "type": "string",
              "mutability": "readWrite",
              "returned": "never",
              "uniqueness": "server",
              "required": False,
              "multiValued": False,
              "caseExact": False
            },
            {
              "name": "emails",
              "type": "complex",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": True,
              "multiValued": True,
              "caseExact": False,
              "subAttributes": [
                {
                  "name": "value",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": True,
                  "multiValued": False,
                  "caseExact": False
                },
                {
                  "name": "type",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                },
                {
                  "name": "primary",
                  "type": "boolean",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                }
              ]
            },
            {
              "name": "groups",
              "type": "complex",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": False,
              "multiValued": True,
              "caseExact": False,
              "subAttributes": [
                {
                  "name": "value",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                },
                {
                  "name": "$ref",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                },
                {
                  "name": "display",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                }
              ]
            },
            {
              "name": "roles",
              "type": "complex",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": False,
              "multiValued": True,
              "caseExact": False,
              "subAttributes": [
                {
                  "name": "value",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": True,
                  "multiValued": False,
                  "caseExact": False
                },
                {
                  "name": "display",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                },
                {
                  "name": "type",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                },
                {
                  "name": "primary",
                  "type": "boolean",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                }
              ]
            }
          ]
        },
        {
          "schemas": [
            "urn:ietf:params:scim:schemas:core:2.0:Schema"
          ],
          "id": "urn:ietf:params:scim:schemas:extension:enterprise:2.0:User",
          "meta": {
            "resourceType": "Schema",
            "created": "2001-01-01T00:00:00+00:00",
            "lastModified": "2001-01-01T00:00:00+00:00",
            "version": "W/\"07e9640ac446d118dce2ef36c9e12c22d2d92be6\"",
            "location": "https://api.scim.dev/scim/v2/Schemas/urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"
          },
          "name": "User",
          "attributes": [
            {
              "name": "employeeNumber",
              "type": "string",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": False,
              "multiValued": False,
              "caseExact": False
            }
          ]
        },
        {
          "schemas": [
            "urn:ietf:params:scim:schemas:core:2.0:Schema"
          ],
          "id": "urn:ietf:params:scim:schemas:core:2.0:Group",
          "meta": {
            "resourceType": "Schema",
            "created": "2001-01-01T00:00:00+00:00",
            "lastModified": "2001-01-01T00:00:00+00:00",
            "version": "W/\"07e9640ac446d118dce2ef36c9e12c22d2d92be6\"",
            "location": "https://api.scim.dev/scim/v2/Schemas/urn:ietf:params:scim:schemas:core:2.0:Group"
          },
          "name": "Group",
          "attributes": [
            {
              "name": "displayName",
              "type": "string",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": True,
              "multiValued": False,
              "caseExact": False
            },
            {
              "name": "externalId",
              "type": "string",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": False,
              "multiValued": False,
              "caseExact": False
            },
            {
              "name": "members",
              "type": "complex",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": False,
              "multiValued": True,
              "caseExact": False,
              "subAttributes": [
                {
                  "name": "value",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": True,
                  "multiValued": False,
                  "caseExact": False
                },
                {
                  "name": "$ref",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                },
                {
                  "name": "display",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                }
              ]
            }
          ]
        },
        {
          "schemas": [
            "urn:ietf:params:scim:schemas:core:2.0:Schema"
          ],
          "id": "dev:scim:Office",
          "meta": {
            "resourceType": "Schema",
            "created": "2001-01-01T00:00:00+00:00",
            "lastModified": "2001-01-01T00:00:00+00:00",
            "version": "W/\"07e9640ac446d118dce2ef36c9e12c22d2d92be6\"",
            "location": "https://api.scim.dev/scim/v2/Schemas/dev:scim:Office"
          },
          "name": "Office",
          "attributes": [
            {
              "name": "name",
              "type": "string",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": True,
              "multiValued": False,
              "caseExact": False
            },
            {
              "name": "displayName",
              "type": "string",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": False,
              "multiValued": False,
              "caseExact": False
            },
            {
              "name": "employees",
              "type": "complex",
              "mutability": "readWrite",
              "returned": "default",
              "uniqueness": "server",
              "required": False,
              "multiValued": True,
              "caseExact": False,
              "subAttributes": [
                {
                  "name": "id",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                },
                {
                  "name": "$ref",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                },
                {
                  "name": "display",
                  "type": "string",
                  "mutability": "readWrite",
                  "returned": "default",
                  "uniqueness": "server",
                  "required": False,
                  "multiValued": False,
                  "caseExact": False
                }
              ]
            }
          ]
        }
      ]
    }


@scim_function(app_label='appname', action=EnumSCIMAction.USERS)
def appname_users():
    return SCIMUsers


# @scim_function(app_label='appname', action=EnumSCIMAction.SCHEMA)
# def appname_schema():
#     return SCIMSchema


@scim_function(app_label='appname', action=EnumSCIMAction.GROUPS)
def appname_groups():
    return SCIMGroups

@lcm_action(app_label='appname', action=EnumLCMAction.WRITEBACK)
def lcm_writeback(payload):
    current_app.logger.info('payload: %s', payload)
    # import bpdb; bpdb.set_trace()  # noqa: E702

    return payload


@lcm_action(app_label='appname', action=EnumLCMAction.WRITEBACK)
def lcm_writeback2(payload):
    current_app.logger.info('payload v2: %s', payload)
    # import bpdb; bpdb.set_trace()  # noqa: E702

    return payload
