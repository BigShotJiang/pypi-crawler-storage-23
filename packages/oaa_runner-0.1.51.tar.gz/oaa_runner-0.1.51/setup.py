import setuptools
from pathlib import Path
import os

BASE_DIR = Path(os.path.dirname(__file__))


def get_required(env=None):
    """TODO: Docstring for get_required.
    :returns: TODO

    """
    #
    # if not env:
    #     env = ''
    # else:
    #     env = f'-{env}'
    #
    # # import bpdb; bpdb.set_trace()
    # with open(BASE_DIR / f'./requirements/requirements{env}.txt', 'r') as _file:
    #     return [line.strip() for line in _file if line.strip() and not line.startswith("#")]  # noqa E501

    return [

    ]


setuptools.setup(
    # version=get_version(),
    packages=setuptools.find_namespace_packages(),
    install_requires=[
      "petl==1.7.17",
      "fire==0.7.1",
      "oaaclient==1.1.15",
      "email_validator==2.2.0",
      "python-dotenv==1.1.1",
      "pydantic",
      "python-dateutil",
      "pyyaml",
      "anytree",
      "Jinja2",
    ],
    include_package_data=True,
    extras_require={
        'mysql': ['pymysql'],
        'postgres': ['psycopg[binary]'],
        "sql": ['pymssql'], 
        "dev": [
            'bpython',
            'ipdb',
            'ipython',
            'pylint',
            'faker',
            'flake8',
            'pytest',
            'pytest-coverage',
            'coverage',
            'requests-mock',
            'build'
        ],
        "oracle": ['oracledb']
    },
    zip_safe=False
)
