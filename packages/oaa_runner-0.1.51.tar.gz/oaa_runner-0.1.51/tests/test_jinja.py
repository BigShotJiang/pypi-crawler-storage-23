from oaa.utils import jinja_env


def test_str_template():
    templ = '{{name}}'
    template = jinja_env.from_string(templ)
    result = template.render(name='kevin')
    assert result=='kevin'


def test_file_template():
    template_name = 'just_name.yaml'
    template = jinja_env.get_template(template_name)
    result = template.render(name='kevin')
    assert result=='--kevin--'
