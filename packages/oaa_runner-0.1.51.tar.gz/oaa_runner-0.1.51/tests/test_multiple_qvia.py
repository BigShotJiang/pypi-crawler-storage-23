import os
import pytest
from pathlib import Path
from oaa.app_runners.custom_app import CustomAppRunner
BASE_DIR = Path(os.path.dirname(os.path.realpath(__file__)))


@pytest.fixture
def _config(config):
    config.update(config_file=BASE_DIR / 'config-qvia-sample.yaml')

    return config


def test_source_should_have_multiple_transforms(_config):
    assert _config.config_file
    assert _config.sources
    source = _config.sources['users']
    assert len(source.field_mappings()['COMBINED_FOR_NAME'].transforms) == 1


def test_stream_and_get_stream_should_return_same_object(_config):

    source = _config.sources['users']

    assert id(source.stream) == id(source.get_stream())


def test_run_transforms_lowercase(_config):
    runner = CustomAppRunner()

    source = _config.sources['users']

    runner._run_transform(source)
    # runner.run()

    for r in source.records:
        assert 'EMAIL' in r.flds
        assert 'name' in r.flds
        assert r.name == r.name.lower()

        # import bpdb; bpdb.set_trace()  # noqa: E702
        # assert 'unique_id' in r.flds


def test_source2(_config):
    runner = CustomAppRunner()
    runner._run_transforms()
    source2 = _config.sources['application_mfa_type']
    print(source2._stream.fieldnames())

    for r in source2.records:
        assert 'mfa_type' in r.flds
        assert 'mfa_enabled' in r.flds
        assert 'mfa_enabled_for_external_and_fed' in r.flds
        assert 'mfa_enabled_for_internal' in r.flds
        assert 'unique_id' in r.flds


def test_application_as_resource(_config):
    runner = CustomAppRunner()
    runner.run(push_to_oaa=False)
    source2 = _config.sources['application_as_resource']
    print(source2._stream)

    for r in source2.records:
        assert 'unique_id' in r.flds
        assert 'name' in r.flds
        assert 'mfa_enabled_for_external_and_fed' in r.flds
        assert 'mfa_enabled_for_internal' in r.flds
        assert r['mfa_enabled_for_external_and_fed'] in (True, False)
        assert r['mfa_enabled_for_internal'] in (True, False)


def test_3_apps_resources(_config):
    runner = CustomAppRunner()

    runner.run(push_to_oaa=False)
    provider = runner._provider_object

    assert len(provider.resources) == 3


USERS = [
    ['iqviasda2@yahoo.com', 'EXT'],
    ['iqviasda3@federation.com', 'FED'],
    ['iqviasda4@iqvia.com', 'INT'],
]


@pytest.mark.parametrize('username,user_type', USERS)
def test_user_in_provider(username, user_type, _config):

    runner = CustomAppRunner()

    runner.run(push_to_oaa=False)

    provider = runner._provider_object

    assert username in provider.local_users
    user = provider.local_users[username]

    assert user.unique_id == username
    assert user.user_type == user_type


APPS = [
    ['Test OIDC Application 5', 'OIDC-OIDC-TST5', True, False],
    ['Test SAML Application', 'SAML-SAML-SSO-APP-SDA', True, False],
    ['Test OIDC Application', 'OIDC-OIDC-APP-SDA', False, True],
]


@pytest.mark.parametrize('application_name,application_id,mfa_enabled_for_external_and_fed,mfa_enabled_for_internal',
                         APPS)
def test_apps_in_resources(application_name, application_id,
                           mfa_enabled_for_external_and_fed,
                           mfa_enabled_for_internal, _config):

    runner = CustomAppRunner()

    runner.run(push_to_oaa=False)

    provider = runner._provider_object

    assert application_id in provider.resources


@pytest.mark.parametrize('application_name,application_id,mfa_enabled_for_external_and_fed,mfa_enabled_for_internal',
                         APPS)
def test_apps_in_resources(application_name, application_id,
                           mfa_enabled_for_external_and_fed,
                           mfa_enabled_for_internal, _config):
    runner = CustomAppRunner()

    runner.run(push_to_oaa=False)

    provider = runner._provider_object

    assert application_id in provider.resources
    app_resource = provider.resources[application_id]

    assert app_resource.unique_id == application_id
    assert app_resource.name == application_name
    resource_fields = provider.property_definitions.resource_properties['IQVIA Application'].keys()
    assert 'mfa_enabled_for_external_and_fed' in resource_fields
    assert 'mfa_enabled_for_internal' in resource_fields

    assert app_resource.properties
    # assert app_resource.properties['mfa_enabled_for_internal'] == mfa_enabled_for_internal
    # assert app_resource.properties['mfa_enabled_for_external_and_fed'] == mfa_enabled_for_external_and_fed
