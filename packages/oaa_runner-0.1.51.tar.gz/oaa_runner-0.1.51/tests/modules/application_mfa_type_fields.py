from oaa.hooks.decorators import hook, OAAHookEvent


@hook(event=OAAHookEvent.PRE_CREATE_OAA,
      target='application_as_resource')
def application_app_mfa_type(event,
                             sources=None,
                             source=None,
                             provider=None,
                             config=None):
    """TODO: Docstring for return_wacko.
    :returns: TODO

    read each application
    - read MFA_TYPE

    """
    # import bpdb; bpdb.set_trace()  # noqa: E702

    # app_mfa_stream = sources['application_mfa_type']._stream
    new_fields = [
        'mfa_enabled_for_internal',
        'mfa_enabled_for_external_and_fed'
    ]

    # s = sources['application_as_resource']._stream
    s = source._stream
    old_fieldnames = set(s.fieldnames())

    for f in new_fields:
        # remove these from the stream, if they are there

        if f in s.fieldnames():
            s = s.cutout(f)

    rprefix = 'right_pfx_'
    s = s.join(sources['application_mfa_type']._stream,
               rprefix=rprefix,
               key='APPLICATION_ID')

    for f in new_fields:
        s = s.rename(f'{rprefix}{f}', f)
        old_fieldnames.add(f)

    s = s.cut(*old_fieldnames)

    sources['application_as_resource']._stream = s

    # print(sources['application_as_resource']._stream)
    # import bpdb; bpdb.set_trace()  # noqa: E702

    return True
