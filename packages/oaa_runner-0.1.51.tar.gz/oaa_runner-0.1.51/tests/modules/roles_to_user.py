

def run(provider, sources=None, config=None):
    # import bpdb; bpdb.set_trace()  # noqa: E702

    # get the roles source
    roles_source = sources['users']
    roles_stream = roles_source.records

    for role in roles_stream:
        # role.username is the user this should be attached to
        user = provider.local_users[role.EMAIL]
        user.add_role(role.ROLE_TYPE,
                      apply_to_application=True,
                      resources=[provider.resources[role.APPLICATION_ID]]
                      )

    return True
