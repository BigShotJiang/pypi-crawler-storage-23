import requests
from urllib.parse import urljoin
import logging
logger = logging.getLogger(__name__)



class BaseURLSession(requests.Session):
    '''
    A base requests.Session sub-classed object that allows to set a base url
    for all subsequent requests.
    '''

    def __init__(self, base_url=None):
        super().__init__()
        self.base_url = base_url
        if self.base_url[-1] != '/':
            self.base_url += append('/')

    def request(self, method, url, *args, **kwargs):
        if url[0] == '/':
            url = url[1:]
        joined_url = urljoin(self.base_url, url)
        logger.debug('joined_url: %s', joined_url)

        return super().request(method, joined_url, *args, **kwargs)
