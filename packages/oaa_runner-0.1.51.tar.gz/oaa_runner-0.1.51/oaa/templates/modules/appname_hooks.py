import petl
import logging
from oaa.hooks.decorators import hook, OAAHookEvent
from oaaclient.templates import OAAPermission

'''
Possible Hooks:
    :code:`PRE_TRANSFORM` runs just before transforms. A particular source can be
    targeted with target=<source-name>. It is useful when you need to queue
    additional processing of the data stream. The initial connection, query,
    api request, etc will have been made at this point but no paginated
    results.

    :code:`POST_TRANSFORM` runs just after transforms have been queued. A particular
    source can be targeted with target=<source-name>. Additional tweaks the the
    stream of data can be queued here, prior to all data being read. The
    initial connection, query, api request, etc will have been made at this
    point but no paginated results.

    Keep in mind that field mapping happens during
    transforms, just after the `PRE_TRANSFORM`. This means that field mappings will
    have already happened during a POST_TRANSFORM hook execution.

    :code:`PRE_CREATE_OAA` runs after transforms. It is assumed that all paginated
    results of requests, queries, etc will be processed by this hook and read
    into memory. If no hooks listen to this event, the the objectst will be
    read into memory to create the OAA objects. A particular source can be
    targeted with target=<source-name>.

    :code:`PRE_PUSH_OAA` runs just before sending the data to Veza via the API. It
    does not have a specific source in mind. All data will have been read by
    this point and is in-memory.

    :code:`POST_PUSH_OAA` runs just after the data has been sent to Veza. Hooks that
    listen to this event have a `response` object received from Veza.
'''


logger = logging.getLogger(__name__)