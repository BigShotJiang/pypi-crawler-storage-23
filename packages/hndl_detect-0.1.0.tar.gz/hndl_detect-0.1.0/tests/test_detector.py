"""Tests for the signal-based HNDL detector."""

import uuid
from datetime import datetime, timedelta, timezone

from hndl_detect import (
    AccessSignal,
    DetectionThresholds,
    HNDLDetector,
    NetworkSignal,
    SignalType,
    ThreatSeverity,
)


def _make_signal(
    source_ip="10.0.1.50",
    destination_ip="203.0.113.10",
    port=443,
    bytes_sent=1_000_000,
    entropy=7.8,
    cipher_suite=None,
    tls_version=None,
    duration_seconds=60.0,
    timestamp=None,
):
    return NetworkSignal(
        timestamp=timestamp or datetime.now(timezone.utc),
        source_ip=source_ip,
        destination_ip=destination_ip,
        port=port,
        protocol="TCP",
        bytes_sent=bytes_sent,
        bytes_received=0,
        duration_seconds=duration_seconds,
        tls_version=tls_version,
        cipher_suite=cipher_suite,
        entropy=entropy,
        packet_count=100,
    )


class TestDetectorInit:
    def test_default_init(self):
        detector = HNDLDetector()
        assert detector.detection_count == 0
        assert len(detector.actor_profiles) == 0

    def test_custom_thresholds(self):
        thresholds = DetectionThresholds(volume_threshold_gb=5.0, fanout_threshold=20)
        detector = HNDLDetector(thresholds=thresholds)
        assert detector.thresholds.volume_threshold_gb == 5.0
        assert detector.thresholds.fanout_threshold == 20

    def test_statistics(self):
        detector = HNDLDetector()
        stats = detector.get_statistics()
        assert stats["detection_count"] == 0
        assert stats["actor_profiles"] == 0
        assert "runtime_seconds" in stats


class TestWeakCipherDetection:
    def test_detects_rsa_cbc_cipher(self):
        detector = HNDLDetector()
        signal = _make_signal(
            cipher_suite="TLS_RSA_WITH_AES_128_CBC_SHA",
            bytes_sent=200 * 1024 * 1024,
        )
        threat = detector.process_network_signal(signal)
        assert threat is not None
        assert threat.threat_type == SignalType.WEAK_CIPHER.value
        assert threat.confidence == 0.8
        assert threat.indicators["quantum_vulnerable"] is True

    def test_no_threat_for_strong_cipher(self):
        detector = HNDLDetector()
        signal = _make_signal(
            cipher_suite="TLS_AES_256_GCM_SHA384",
            bytes_sent=200 * 1024 * 1024,
        )
        threat = detector.process_network_signal(signal)
        # Strong cipher should not trigger weak cipher detection.
        # May trigger volume or other signals depending on threshold.
        if threat:
            assert threat.threat_type != SignalType.WEAK_CIPHER.value

    def test_no_threat_without_cipher(self):
        detector = HNDLDetector()
        signal = _make_signal(cipher_suite=None, bytes_sent=1000)
        threat = detector.process_network_signal(signal)
        assert threat is None


class TestVolumeSpikeDetection:
    def test_detects_volume_spike(self):
        detector = HNDLDetector(
            thresholds=DetectionThresholds(volume_threshold_gb=0.001)
        )
        # Feed enough signals from the same source to trigger volume spike
        for _ in range(5):
            signal = _make_signal(
                bytes_sent=500 * 1024 * 1024,
                entropy=7.9,
            )
            threat = detector.process_network_signal(signal)
        # At least one should trigger
        assert detector.detection_count > 0

    def test_no_spike_below_threshold(self):
        detector = HNDLDetector(
            thresholds=DetectionThresholds(volume_threshold_gb=1000.0)
        )
        signal = _make_signal(bytes_sent=1000, entropy=7.9)
        threat = detector.process_network_signal(signal)
        assert threat is None


class TestNetworkFanoutDetection:
    def test_detects_fanout(self):
        detector = HNDLDetector(
            thresholds=DetectionThresholds(
                fanout_threshold=3,
                volume_threshold_gb=999,
            )
        )
        # Send to many unique destinations
        for i in range(10):
            signal = _make_signal(
                destination_ip=f"203.0.113.{i}",
                bytes_sent=100 * 1024 * 1024,
                entropy=7.9,
            )
            threat = detector.process_network_signal(signal)

        assert detector.detection_count > 0


class TestCanaryDetection:
    def test_detects_canary_trigger(self):
        detector = HNDLDetector(
            canary_resources={"database_export:secret_records_2025"}
        )
        signal = AccessSignal(
            timestamp=datetime.now(timezone.utc),
            actor_id="user-123",
            resource_type="database_export",
            resource_id="secret_records_2025",
            action="download",
            source_ip="10.0.1.99",
        )
        threat = detector.process_access_signal(signal)
        assert threat is not None
        assert threat.threat_type == SignalType.CANARY_TRIGGER.value
        assert threat.severity == ThreatSeverity.CRITICAL
        assert threat.confidence == 0.95

    def test_no_trigger_for_normal_resource(self):
        detector = HNDLDetector(
            canary_resources={"database_export:secret_records_2025"}
        )
        # Use a known business-hours timestamp to avoid off-hours detection
        ts = datetime.now(timezone.utc).replace(hour=14, minute=0, second=0)
        signal = AccessSignal(
            timestamp=ts,
            actor_id="user-123",
            resource_type="document",
            resource_id="readme.txt",
            action="read",
            source_ip="10.0.1.99",
        )
        threat = detector.process_access_signal(signal)
        assert threat is None


class TestAbnormalAccess:
    def test_detects_bulk_offhours(self):
        detector = HNDLDetector()
        signal = AccessSignal(
            timestamp=datetime.now(timezone.utc).replace(hour=3),
            actor_id="user-456",
            resource_type="database_export",
            resource_id="all_records",
            action="export",
            source_ip="10.0.1.100",
            is_bulk=True,
            is_offhours=True,
            bytes_accessed=2 * 1024**3,
        )
        threat = detector.process_access_signal(signal)
        assert threat is not None
        assert threat.threat_type == SignalType.ABNORMAL_ACCESS.value
        assert "bulk_operation" in threat.indicators["suspicious_patterns"]
        assert "off_hours_access" in threat.indicators["suspicious_patterns"]


class TestSequentialPattern:
    def test_detects_sequential(self):
        ids = [f"record_{i}" for i in range(1, 20)]
        assert HNDLDetector._is_sequential_pattern(ids) is True

    def test_rejects_random(self):
        ids = [str(uuid.uuid4()) for _ in range(20)]
        # UUIDs have digits but are not sequential
        result = HNDLDetector._is_sequential_pattern(ids)
        # Result depends on UUID randomness; just verify no crash
        assert isinstance(result, bool)

    def test_rejects_short_list(self):
        assert HNDLDetector._is_sequential_pattern(["a", "b"]) is False
