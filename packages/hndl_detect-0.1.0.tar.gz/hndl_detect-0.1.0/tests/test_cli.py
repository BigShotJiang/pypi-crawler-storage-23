"""Tests for the CLI."""

import json
import os
import tempfile

from hndl_detect.cli import main


def _write_temp_jsonl(records):
    """Write records to a temp file and return the path."""
    fd, path = tempfile.mkstemp(suffix=".jsonl")
    with os.fdopen(fd, "w") as f:
        for record in records:
            f.write(json.dumps(record) + "\n")
    return path


class TestCLISignalMode:
    def test_empty_input(self):
        path = _write_temp_jsonl([])
        try:
            main(["--input", path])
        finally:
            os.unlink(path)

    def test_single_benign_signal(self):
        record = {
            "timestamp": "2025-01-15T14:30:00Z",
            "source_ip": "10.0.1.50",
            "destination_ip": "10.0.1.51",
            "port": 443,
            "protocol": "TCP",
            "bytes_sent": 1000,
            "bytes_received": 500,
            "duration_seconds": 1.0,
            "entropy": 3.0,
            "packet_count": 5,
        }
        path = _write_temp_jsonl([record])
        try:
            main(["--input", path])
        finally:
            os.unlink(path)

    def test_weak_cipher_triggers_alert(self, capsys):
        record = {
            "timestamp": "2025-01-15T14:30:00Z",
            "source_ip": "10.0.1.50",
            "destination_ip": "203.0.113.10",
            "port": 443,
            "protocol": "TCP",
            "bytes_sent": 200000000,
            "bytes_received": 500,
            "duration_seconds": 60.0,
            "cipher_suite": "TLS_RSA_WITH_AES_128_CBC_SHA",
            "entropy": 7.8,
            "packet_count": 1000,
        }
        path = _write_temp_jsonl([record])
        try:
            main(["--input", path])
        finally:
            os.unlink(path)

        captured = capsys.readouterr()
        if captured.out.strip():
            alert = json.loads(captured.out.strip())
            assert alert["threat_type"] == "weak_cipher"


class TestCLIRiskMode:
    def test_risk_mode_single_flow(self, capsys):
        record = {
            "timestamp": "2025-01-15T14:30:00Z",
            "source_ip": "10.0.1.50",
            "destination_ip": "203.0.113.10",
            "port": 443,
            "protocol": "TCP",
            "bytes_sent": 5000000000,
            "duration_seconds": 3600.0,
            "encrypted": True,
            "cipher_suite": "TLS_RSA_WITH_AES_128_GCM_SHA256",
            "entropy": 7.8,
            "packet_count": 50000,
        }
        path = _write_temp_jsonl([record])
        try:
            main(["--input", path, "--mode", "risk"])
        finally:
            os.unlink(path)

        captured = capsys.readouterr()
        if captured.out.strip():
            result = json.loads(captured.out.strip())
            assert "risk_assessment" in result
