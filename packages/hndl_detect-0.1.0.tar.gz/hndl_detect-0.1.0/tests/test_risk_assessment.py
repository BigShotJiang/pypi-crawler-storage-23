"""Tests for the HNDL risk assessment engine."""

from datetime import datetime, timedelta, timezone

from hndl_detect import (
    CryptoVulnerability,
    DataClassification,
    DataValueScorer,
    HarvestRiskLevel,
    HNDLRiskAssessmentEngine,
    NetworkFlow,
    PatiencePatternAnalyzer,
    QuantumHoneypotEngine,
)


def _make_flow(
    flow_id="flow-001",
    source_ip="10.0.1.50",
    dest_ip="203.0.113.10",
    bytes_transferred=5_000_000_000,
    encrypted=True,
    cipher_suite="TLS_RSA_WITH_AES_128_GCM_SHA256",
    dest_port=443,
    payload_entropy=7.8,
    data_type_hints=None,
    duration_hours=1.0,
):
    now = datetime.now(timezone.utc)
    return NetworkFlow(
        flow_id=flow_id,
        source_ip=source_ip,
        dest_ip=dest_ip,
        source_port=49152,
        dest_port=dest_port,
        protocol="TCP",
        bytes_transferred=bytes_transferred,
        packet_count=50000,
        start_time=now - timedelta(hours=duration_hours),
        end_time=now,
        encrypted=encrypted,
        cipher_suite=cipher_suite,
        payload_entropy=payload_entropy,
        data_type_hints=data_type_hints or [],
    )


class TestDataValueScorer:
    def test_negligible_for_small_flow(self):
        scorer = DataValueScorer()
        flow = _make_flow(bytes_transferred=100)
        score = scorer.score_flow(flow)
        assert score.overall_risk == HarvestRiskLevel.NEGLIGIBLE
        assert score.risk_score == 0.0

    def test_scores_rsa_as_high_crypto_risk(self):
        scorer = DataValueScorer()
        flow = _make_flow(cipher_suite="TLS_RSA_WITH_AES_128_CBC_SHA")
        score = scorer.score_flow(flow)
        assert score.crypto_vulnerability_score == CryptoVulnerability.CRITICAL_RISK.risk_factor

    def test_scores_quantum_safe_as_low_risk(self):
        scorer = DataValueScorer()
        flow = _make_flow(cipher_suite="ML-KEM-768")
        score = scorer.score_flow(flow)
        assert score.crypto_vulnerability_score == CryptoVulnerability.QUANTUM_SAFE.risk_factor

    def test_unencrypted_is_max_vulnerability(self):
        scorer = DataValueScorer()
        flow = _make_flow(encrypted=False, cipher_suite=None)
        score = scorer.score_flow(flow)
        assert score.crypto_vulnerability_score == 1.0

    def test_high_risk_for_large_rsa_flow(self):
        scorer = DataValueScorer()
        flow = _make_flow(
            bytes_transferred=50 * 1024**3,
            cipher_suite="TLS_RSA_WITH_AES_128_CBC_SHA",
            data_type_hints=["government"],
        )
        score = scorer.score_flow(flow)
        assert score.overall_risk in (HarvestRiskLevel.HIGH, HarvestRiskLevel.CRITICAL)

    def test_batch_scoring(self):
        scorer = DataValueScorer()
        flows = [_make_flow(flow_id=f"f-{i}") for i in range(5)]
        scores = scorer.score_flows_batch(flows)
        assert len(scores) == 5

    def test_high_risk_summary(self):
        scorer = DataValueScorer()
        flows = [
            _make_flow(flow_id="big", bytes_transferred=100 * 1024**3, cipher_suite="TLS_RSA_WITH_AES_128_CBC_SHA"),
            _make_flow(flow_id="small", bytes_transferred=100),
        ]
        scores = scorer.score_flows_batch(flows)
        summary = scorer.get_high_risk_summary(scores)
        assert "total_flows_assessed" in summary
        assert summary["total_flows_assessed"] == 2


class TestPatiencePatternAnalyzer:
    def test_returns_none_without_data(self):
        analyzer = PatiencePatternAnalyzer()
        result = analyzer.analyze_actor("1.2.3.4")
        assert result is None

    def test_returns_none_with_insufficient_data(self):
        analyzer = PatiencePatternAnalyzer(config={"min_observation_days": 1, "max_history_per_actor": 10000, "patience_threshold": 0.7, "consistency_threshold": 0.6, "max_daily_rate_mb": 500, "min_sessions": 5})
        flow = _make_flow()
        analyzer.record_flow(flow)
        result = analyzer.analyze_actor(flow.dest_ip)
        # Only 1 session, need min_sessions=5
        assert result is None

    def test_analyze_all_actors_empty(self):
        analyzer = PatiencePatternAnalyzer()
        assert analyzer.analyze_all_actors() == []

    def test_get_suspected_returns_empty_without_data(self):
        analyzer = PatiencePatternAnalyzer()
        assert analyzer.get_suspected_hndl_actors() == []


class TestQuantumHoneypotEngine:
    def test_create_honeypot(self):
        engine = QuantumHoneypotEngine()
        honeypot_id, data = engine.create_honeypot()
        assert len(honeypot_id) == 16
        assert len(data) > 0

    def test_mark_deployed(self):
        engine = QuantumHoneypotEngine()
        hid, _ = engine.create_honeypot()
        assert engine.mark_deployed(hid, "/data/secrets/") is True
        assert engine.mark_deployed("nonexistent", "/data/") is False

    def test_detect_exfiltration(self):
        engine = QuantumHoneypotEngine()
        hid, data = engine.create_honeypot()
        engine.mark_deployed(hid, "/data/secrets/")

        # Simulate exfiltration of honeypot data
        event = engine.check_exfiltration(data, "10.0.1.50", "evil.example.com")
        assert event is not None
        assert event.is_confirmed_hndl is True
        assert event.confidence == 0.99

    def test_no_detection_for_random_data(self):
        engine = QuantumHoneypotEngine()
        engine.create_honeypot()
        event = engine.check_exfiltration(b"random data", "10.0.1.50", "1.2.3.4")
        assert event is None

    def test_honeypot_status(self):
        engine = QuantumHoneypotEngine()
        engine.create_honeypot()
        status = engine.get_honeypot_status()
        assert status["total_honeypots"] == 1
        assert status["deployed"] == 0


class TestHNDLRiskAssessmentEngine:
    def test_assess_flow(self):
        engine = HNDLRiskAssessmentEngine()
        flow = _make_flow()
        result = engine.assess_flow(flow)
        assert "flow_id" in result
        assert "risk_assessment" in result
        assert "assessment_timestamp" in result

    def test_assess_batch(self):
        engine = HNDLRiskAssessmentEngine()
        flows = [_make_flow(flow_id=f"f-{i}") for i in range(3)]
        result = engine.assess_batch(flows)
        assert result["total_assessed"] == 3

    def test_comprehensive_status(self):
        engine = HNDLRiskAssessmentEngine()
        status = engine.get_comprehensive_status()
        assert status["engine_status"] == "OPERATIONAL"
        assert "assessment_stats" in status
        assert "honeypot_status" in status
