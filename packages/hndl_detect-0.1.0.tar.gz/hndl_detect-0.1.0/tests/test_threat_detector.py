"""Tests for the APT threat detector."""

from datetime import datetime, timezone

from hndl_detect import (
    CryptoAlgorithm,
    HNDLThreatDetector,
    NetworkFlowSimple,
)


def _make_flow_simple(
    source_ip="10.0.1.50",
    dest_ip="203.0.113.10",
    byte_count=1_000_000_000,
    encrypted=True,
    cipher_suite="TLS_RSA_WITH_AES_128_GCM_SHA256",
    duration=86400.0,
    tls_version="TLS 1.2",
    payload_entropy=7.8,
):
    return NetworkFlowSimple(
        source_ip=source_ip,
        dest_ip=dest_ip,
        source_port=49152,
        dest_port=443,
        protocol="TCP",
        packet_count=50000,
        byte_count=byte_count,
        start_time=datetime.now(timezone.utc),
        duration=duration,
        encrypted=encrypted,
        tls_version=tls_version,
        cipher_suite=cipher_suite,
        payload_entropy=payload_entropy,
    )


class TestHNDLThreatDetectorInit:
    def test_default_init(self):
        detector = HNDLThreatDetector()
        assert detector.statistics["threats_detected"] == 0
        assert len(detector.apt_signatures) == 4

    def test_statistics(self):
        detector = HNDLThreatDetector()
        stats = detector.get_statistics()
        assert stats["total_flows_analyzed"] == 0
        assert stats["active_threats"] == 0


class TestBulkCollectionDetection:
    def test_detects_bulk_collection(self):
        detector = HNDLThreatDetector()
        flows = [
            _make_flow_simple(
                dest_ip=f"external-{i}.example.com",
                byte_count=600 * 1024**2,
            )
            for i in range(5)
        ]
        threats = detector.detect_harvest_attempts(flows)
        # Should detect bulk collection from the single source to 5 destinations
        assert len(threats) > 0
        assert detector.statistics["threats_detected"] > 0

    def test_no_detection_for_small_flows(self):
        detector = HNDLThreatDetector()
        flows = [
            _make_flow_simple(byte_count=1000, duration=10.0)
            for _ in range(3)
        ]
        threats = detector.detect_harvest_attempts(flows)
        assert len(threats) == 0


class TestQuantumVulnerabilityAssessment:
    def test_rsa_2048_vulnerability(self):
        detector = HNDLThreatDetector()
        assessment = detector.assess_quantum_vulnerability(
            b"\x00" * 256,
            algorithm=CryptoAlgorithm.RSA_2048,
        )
        assert assessment["quantum_vulnerable"] is True
        assert assessment["algorithm"] == "RSA-2048"
        assert assessment["migration_priority"] in ("CRITICAL", "HIGH", "MEDIUM", "LOW")
        assert len(assessment["recommendations"]) > 0

    def test_quantum_safe_algorithm(self):
        detector = HNDLThreatDetector()
        assessment = detector.assess_quantum_vulnerability(
            b"\x00" * 100,
            algorithm=CryptoAlgorithm.CRYSTALS_KYBER,
        )
        assert assessment["quantum_vulnerable"] is False
        assert assessment["risk_score"] == 0.0

    def test_auto_detect_algorithm(self):
        detector = HNDLThreatDetector()
        # 256 bytes = RSA-2048 modulus size
        assessment = detector.assess_quantum_vulnerability(b"\x00" * 256)
        assert assessment["algorithm"] is not None


class TestThreatIntelligenceExport:
    def test_export_empty(self):
        detector = HNDLThreatDetector()
        bundle = detector.export_threat_intelligence()
        assert bundle["type"] == "bundle"
        assert len(bundle["objects"]) == 0

    def test_export_with_threats(self):
        detector = HNDLThreatDetector()
        flows = [
            _make_flow_simple(
                dest_ip=f"target-{i}.gov.example.com",
                byte_count=600 * 1024**2,
            )
            for i in range(5)
        ]
        detector.detect_harvest_attempts(flows)
        bundle = detector.export_threat_intelligence()
        assert bundle["type"] == "bundle"
        # Should have at least one threat object
        assert len(bundle["objects"]) >= 0  # May be 0 if below threshold
