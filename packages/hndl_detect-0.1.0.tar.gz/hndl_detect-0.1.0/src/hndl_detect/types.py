"""
Shared types for HNDL detection.

Dataclasses and enums used across the detector, risk assessment,
and threat detection modules.
"""

import hashlib
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class SignalType(str, Enum):
    """HNDL detection signal types."""
    VOLUME_SPIKE = "volume_spike"
    NETWORK_FANOUT = "network_fanout"
    LONG_LIVED_TLS = "long_lived_tls"
    WEAK_CIPHER = "weak_cipher"
    ABNORMAL_ACCESS = "abnormal_access"
    CANARY_TRIGGER = "canary_trigger"


class ThreatSeverity(str, Enum):
    """Threat severity levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ThreatStatus(str, Enum):
    """Threat lifecycle status."""
    ACTIVE = "active"
    INVESTIGATING = "investigating"
    MITIGATED = "mitigated"
    RESOLVED = "resolved"
    FALSE_POSITIVE = "false_positive"


class DetectionMode(str, Enum):
    """Detection processing modes."""
    REALTIME = "realtime"
    BATCH = "batch"
    HYBRID = "hybrid"


class DataClassification(Enum):
    """Data classification levels affecting harvest value."""
    PUBLIC = ("public", 0.0, 0)
    INTERNAL = ("internal", 0.2, 1)
    CONFIDENTIAL = ("confidential", 0.5, 5)
    SECRET = ("secret", 0.8, 20)
    TOP_SECRET = ("top_secret", 1.0, 50)

    def __init__(self, classification_name: str, value_factor: float, shelf_life_years: int):
        self.classification_name = classification_name
        self.value_factor = value_factor
        self.shelf_life_years = shelf_life_years


class CryptoVulnerability(Enum):
    """Cryptographic algorithm quantum vulnerability."""
    QUANTUM_SAFE = ("quantum_safe", 0.0, float("inf"))
    LOW_RISK = ("low_risk", 0.2, 2035)
    MEDIUM_RISK = ("medium_risk", 0.5, 2032)
    HIGH_RISK = ("high_risk", 0.8, 2030)
    CRITICAL_RISK = ("critical_risk", 1.0, 2028)

    def __init__(self, risk_name: str, risk_factor: float, estimated_break_year: float):
        self.risk_name = risk_name
        self.risk_factor = risk_factor
        self.estimated_break_year = estimated_break_year


class HarvestRiskLevel(Enum):
    """Overall harvest risk assessment levels."""
    NEGLIGIBLE = 1
    LOW = 2
    MODERATE = 3
    HIGH = 4
    CRITICAL = 5


class CryptoAlgorithm(Enum):
    """Cryptographic algorithms with quantum vulnerability assessment."""
    RSA_2048 = ("RSA-2048", 6.88e3, True)
    RSA_3072 = ("RSA-3072", 13.1e3, True)
    RSA_4096 = ("RSA-4096", 23.3e3, True)
    ECC_P256 = ("ECC-P256", 2.9e3, True)
    ECC_P384 = ("ECC-P384", 6.5e3, True)
    ECC_P521 = ("ECC-P521", 11.9e3, True)
    AES_128 = ("AES-128", 2.9e3, False)
    AES_256 = ("AES-256", 6.2e3, False)
    CRYSTALS_KYBER = ("CRYSTALS-Kyber", float("inf"), False)
    CRYSTALS_DILITHIUM = ("CRYSTALS-Dilithium", float("inf"), False)
    SPHINCS_PLUS = ("SPHINCS+", float("inf"), False)

    def __init__(self, algorithm_name: str, qubits_required: float, quantum_vulnerable: bool):
        self.algorithm_name = algorithm_name
        self.qubits_required = qubits_required
        self.quantum_vulnerable = quantum_vulnerable


class ThreatIndicator(Enum):
    """APT and state-sponsored threat indicators."""
    BULK_ENCRYPTION_COLLECTION = "bulk_encrypted_data_collection"
    PERSISTENT_TLS_MONITORING = "persistent_tls_session_monitoring"
    ENCRYPTED_DATA_HOARDING = "encrypted_data_accumulation"
    UNUSUAL_CERT_REQUESTS = "abnormal_certificate_requests"
    QUANTUM_TIMELINE_CORRELATION = "quantum_development_timeline_match"
    STATE_ACTOR_SIGNATURE = "state_sponsored_apt_pattern"
    LONG_TERM_STORAGE_PREP = "long_term_storage_preparation"
    SELECTIVE_TARGET_FOCUS = "selective_high_value_targeting"


# ---------------------------------------------------------------------------
# Dataclasses - Network signals
# ---------------------------------------------------------------------------

@dataclass
class NetworkSignal:
    """Network traffic signal for HNDL detection."""
    timestamp: datetime
    source_ip: str
    destination_ip: str
    port: int
    protocol: str
    bytes_sent: int
    bytes_received: int
    duration_seconds: float
    tls_version: Optional[str] = None
    cipher_suite: Optional[str] = None
    entropy: Optional[float] = None
    session_id: Optional[str] = None
    packet_count: int = 0
    flow_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    # Default entropy threshold for encrypted traffic detection
    ENTROPY_THRESHOLD: float = 7.5

    def calculate_flow_id(self) -> str:
        """Calculate unique flow identifier from 5-tuple."""
        if self.flow_id:
            return self.flow_id
        tuple_str = f"{self.source_ip}:{self.destination_ip}:{self.port}:{self.protocol}"
        self.flow_id = hashlib.sha256(tuple_str.encode()).hexdigest()[:16]
        return self.flow_id

    def is_encrypted(self) -> bool:
        """Check if traffic appears encrypted based on entropy."""
        if self.entropy is None:
            return False
        return self.entropy >= self.ENTROPY_THRESHOLD


@dataclass
class AccessSignal:
    """Access pattern signal for HNDL detection."""
    timestamp: datetime
    actor_id: str
    resource_type: str
    resource_id: str
    action: str
    source_ip: str
    user_agent: Optional[str] = None
    success: bool = True
    bytes_accessed: int = 0
    duration_ms: float = 0
    is_bulk: bool = False
    is_offhours: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Dataclasses - Threat profiles
# ---------------------------------------------------------------------------

@dataclass
class HNDLThreatProfile:
    """Complete HNDL threat profile with all indicators."""
    threat_id: str
    severity: ThreatSeverity
    confidence: float
    threat_type: str
    detected_at: datetime
    source_ip: str
    destination_ips: List[str]
    data_volume_bytes: int
    duration_seconds: int
    indicators: Dict[str, Any]
    recommendations: List[str]
    status: ThreatStatus = ThreatStatus.ACTIVE
    entropy_score: Optional[float] = None
    packet_count: Optional[int] = None
    protocol_distribution: Optional[Dict[str, int]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "threat_id": self.threat_id,
            "severity": self.severity.value,
            "confidence": self.confidence,
            "threat_type": self.threat_type,
            "detected_at": self.detected_at.isoformat(),
            "source_ip": self.source_ip,
            "destination_ips": self.destination_ips,
            "data_volume_bytes": self.data_volume_bytes,
            "duration_seconds": self.duration_seconds,
            "indicators": self.indicators,
            "recommendations": self.recommendations,
            "status": self.status.value,
            "entropy_score": self.entropy_score,
            "packet_count": self.packet_count,
            "protocol_distribution": self.protocol_distribution,
        }


@dataclass
class DetectionThresholds:
    """Configurable detection thresholds."""
    volume_threshold_gb: float = 10.0
    entropy_threshold: float = 7.5
    fanout_threshold: int = 5
    connection_duration_hours: float = 1.0
    access_rate_threshold: int = 100
    weak_cipher_severity: str = "HIGH"


@dataclass
class APTThreatProfile:
    """Profile for APT-attributed HNDL threat activity."""
    threat_id: str = field(
        default_factory=lambda: hashlib.sha256(str(time.time()).encode()).hexdigest()[:16]
    )
    detection_time: datetime = field(default_factory=datetime.now)
    source_ips: Set[str] = field(default_factory=set)
    target_systems: Set[str] = field(default_factory=set)
    harvested_data_volume: int = 0
    encryption_algorithms: Set[CryptoAlgorithm] = field(default_factory=set)
    threat_indicators: Set[ThreatIndicator] = field(default_factory=set)
    confidence_score: float = 0.0
    estimated_quantum_break_time: timedelta = field(default_factory=lambda: timedelta(days=3650))
    apt_group_attribution: Optional[str] = None
    recommended_actions: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Dataclasses - Network flows (risk assessment)
# ---------------------------------------------------------------------------

@dataclass
class NetworkFlow:
    """Network flow data for risk assessment analysis."""
    flow_id: str
    source_ip: str
    dest_ip: str
    source_port: int
    dest_port: int
    protocol: str
    bytes_transferred: int
    packet_count: int
    start_time: datetime
    end_time: datetime
    encrypted: bool
    tls_version: Optional[str] = None
    cipher_suite: Optional[str] = None
    payload_entropy: float = 0.0
    data_type_hints: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def duration_seconds(self) -> float:
        return (self.end_time - self.start_time).total_seconds()

    @property
    def bytes_per_second(self) -> float:
        duration = self.duration_seconds
        return self.bytes_transferred / duration if duration > 0 else 0


@dataclass
class NetworkFlowSimple:
    """Simplified network flow used by the APT threat detector."""
    source_ip: str
    dest_ip: str
    source_port: int
    dest_port: int
    protocol: str
    packet_count: int
    byte_count: int
    start_time: datetime
    duration: float
    encrypted: bool
    tls_version: Optional[str] = None
    cipher_suite: Optional[str] = None
    certificates: List[Dict[str, Any]] = field(default_factory=list)
    payload_entropy: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Dataclasses - Risk assessment
# ---------------------------------------------------------------------------

@dataclass
class HarvestRiskScore:
    """Comprehensive harvest risk assessment."""
    score_id: str
    assessment_time: datetime
    source_ip: str
    destination_ip: str
    overall_risk: HarvestRiskLevel
    risk_score: float

    data_value_score: float
    crypto_vulnerability_score: float
    shelf_life_score: float
    volume_score: float

    estimated_data_classification: DataClassification
    crypto_vulnerability: CryptoVulnerability
    estimated_shelf_life_years: int
    quantum_break_year: int
    data_volume_gb: float

    recommendations: List[str] = field(default_factory=list)
    immediate_actions: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "score_id": self.score_id,
            "assessment_time": self.assessment_time.isoformat(),
            "source_ip": self.source_ip,
            "destination_ip": self.destination_ip,
            "overall_risk": self.overall_risk.name,
            "risk_score": self.risk_score,
            "data_value_score": self.data_value_score,
            "crypto_vulnerability_score": self.crypto_vulnerability_score,
            "shelf_life_score": self.shelf_life_score,
            "volume_score": self.volume_score,
            "estimated_data_classification": self.estimated_data_classification.classification_name,
            "crypto_vulnerability": self.crypto_vulnerability.risk_name,
            "estimated_shelf_life_years": self.estimated_shelf_life_years,
            "quantum_break_year": self.quantum_break_year,
            "data_volume_gb": self.data_volume_gb,
            "recommendations": self.recommendations,
            "immediate_actions": self.immediate_actions,
        }


@dataclass
class PatienceIndicator:
    """Indicators of patient, methodical data collection."""
    actor_ip: str
    first_seen: datetime
    last_seen: datetime
    observation_days: int
    total_bytes: int
    session_count: int

    consistency_score: float
    patience_score: float
    daily_rate_variance: float

    all_encrypted: bool
    targets_quantum_vulnerable: bool
    avoids_detection_patterns: bool

    is_suspected_hndl: bool
    confidence: float


@dataclass
class HoneypotEvent:
    """Quantum honeypot exfiltration event."""
    event_id: str
    honeypot_id: str
    detection_time: datetime
    source_ip: str
    destination_ip: str
    data_volume_bytes: int

    is_confirmed_hndl: bool
    confidence: float

    honeypot_type: str
    apparent_data_type: str
    apparent_classification: str


@dataclass
class DataAsset:
    """Data asset for value scoring."""
    asset_id: str
    asset_name: str
    classification: DataClassification
    longevity_years: float
    crypto_algorithms: List[str]
    organization_id: str
    data_volume_gb: Optional[float] = None
    regulatory_frameworks: List[str] = field(default_factory=list)
    custom_metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ---------------------------------------------------------------------------
# Dataclasses - ISAC correlation
# ---------------------------------------------------------------------------

@dataclass
class ISACIndicator:
    """Indicator shared with/from ISAC."""
    indicator_id: str
    indicator_type: str
    value_hash: str
    first_seen: datetime
    last_seen: datetime
    sighting_count: int
    contributing_orgs: int
    confidence: float
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CorrelatedThreat:
    """Threat correlated across organizations."""
    correlation_id: str
    detection_time: datetime
    internal_indicators: List[str]
    external_indicators: List[ISACIndicator]
    correlation_type: str
    confidence: float
    organizations_affected: int
    total_data_volume_gb: float
    is_confirmed_campaign: bool
    campaign_name: Optional[str]
