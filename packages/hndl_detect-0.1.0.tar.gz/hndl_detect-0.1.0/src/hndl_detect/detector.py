"""
HNDL signal-based detector.

Implements detection of Harvest Now Decrypt Later attack patterns through
six signal types:

1. Encrypted volume spikes
2. Network fan-out (distributed exfiltration)
3. Long-lived TLS connections
4. Weak / quantum-vulnerable cipher usage
5. Abnormal access rates
6. Canary / honeypot triggers

Industry consensus holds that deterministic HNDL detection from network
traffic alone is infeasible because intent cannot be inferred. This module
provides *risk indicators* and behavioral heuristics. Definitive confirmation
requires honeypot / canary deployment.
"""

import logging
import re
import uuid
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from typing import Deque, Dict, List, Optional, Set

from .types import (
    AccessSignal,
    DetectionMode,
    DetectionThresholds,
    HNDLThreatProfile,
    NetworkSignal,
    SignalType,
    ThreatSeverity,
    ThreatStatus,
)

logger = logging.getLogger(__name__)


class ActorProfile:
    """Behavioral profile for an actor (IP address or user)."""

    def __init__(self, actor_id: str):
        self.actor_id = actor_id
        self.first_seen = datetime.now(timezone.utc)
        self.last_seen = datetime.now(timezone.utc)
        self.total_bytes: int = 0
        self.destinations: Set[str] = set()
        self.connections: List[NetworkSignal] = []
        self.access_patterns: List[AccessSignal] = []
        self.baseline_established = False
        self.baseline_bytes_per_hour: Optional[float] = None
        self.baseline_destinations_per_hour: Optional[float] = None
        self.cipher_suites_used: Set[str] = set()
        self.tls_versions_used: Set[str] = set()

    def update_network_signal(self, signal: NetworkSignal) -> None:
        """Update profile with a new network signal."""
        self.last_seen = signal.timestamp
        self.total_bytes += signal.bytes_sent
        self.destinations.add(signal.destination_ip)
        self.connections.append(signal)

        if signal.cipher_suite:
            self.cipher_suites_used.add(signal.cipher_suite)
        if signal.tls_version:
            self.tls_versions_used.add(signal.tls_version)

        # Keep only the last 24 hours of connections
        cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
        self.connections = [c for c in self.connections if c.timestamp > cutoff]

    def update_access_signal(self, signal: AccessSignal) -> None:
        """Update profile with a new access signal."""
        self.last_seen = signal.timestamp
        self.access_patterns.append(signal)

        cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
        self.access_patterns = [a for a in self.access_patterns if a.timestamp > cutoff]

    def establish_baseline(self) -> None:
        """Establish behavioral baseline from historical data."""
        if len(self.connections) < 10:
            return

        duration = (self.last_seen - self.first_seen).total_seconds() / 3600
        if duration < 1.0:
            return

        self.baseline_bytes_per_hour = self.total_bytes / duration
        self.baseline_destinations_per_hour = len(self.destinations) / duration
        self.baseline_established = True

        logger.info(
            "Baseline established for %s (bytes/hr=%.0f, dests/hr=%.1f)",
            self.actor_id,
            self.baseline_bytes_per_hour,
            self.baseline_destinations_per_hour,
        )

    def get_deviation_score(self, current_bytes_per_hour: float, current_fanout: int) -> float:
        """
        Calculate deviation from baseline.

        Returns a score where 0.0 means at baseline, and positive values
        indicate how many multiples above baseline the current behavior is.
        """
        if not self.baseline_established:
            return 0.0

        byte_deviation = 0.0
        if self.baseline_bytes_per_hour and self.baseline_bytes_per_hour > 0:
            byte_deviation = current_bytes_per_hour / self.baseline_bytes_per_hour

        fanout_deviation = 0.0
        if self.baseline_destinations_per_hour and self.baseline_destinations_per_hour > 0:
            fanout_deviation = current_fanout / self.baseline_destinations_per_hour

        return max(byte_deviation, fanout_deviation) - 1.0


class HNDLDetector:
    """
    Signal-based HNDL detection pipeline.

    Processes network and access signals through six detection heuristics
    to produce threat profiles with confidence scores.
    """

    def __init__(
        self,
        detection_mode: DetectionMode = DetectionMode.HYBRID,
        thresholds: Optional[DetectionThresholds] = None,
        canary_resources: Optional[Set[str]] = None,
    ):
        """
        Args:
            detection_mode: Processing mode (realtime, batch, or hybrid).
            thresholds: Detection threshold configuration.
            canary_resources: Set of resource paths (``type:id``) that are
                canary / honeypot assets. Access to any of these triggers
                a high-confidence alert.
        """
        self.detection_mode = detection_mode
        self.thresholds = thresholds or DetectionThresholds()

        # Actor profiles for behavioral analysis
        self.actor_profiles: Dict[str, ActorProfile] = {}

        # Signal buffers
        self.network_signal_buffer: Deque[NetworkSignal] = deque(maxlen=10000)
        self.access_signal_buffer: Deque[AccessSignal] = deque(maxlen=10000)

        # Active flow tracking
        self.active_flows: Dict[str, List[NetworkSignal]] = defaultdict(list)

        # Canary assets
        self.canary_assets: Set[str] = canary_resources or set()

        # Weak cipher patterns (quantum-vulnerable)
        self.weak_ciphers = {
            "TLS_RSA_WITH_AES_128_CBC_SHA",
            "TLS_RSA_WITH_AES_256_CBC_SHA",
            "TLS_RSA_WITH_AES_128_GCM_SHA256",
            "TLS_RSA_WITH_AES_256_GCM_SHA384",
            "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA",
            "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA",
        }
        self.weak_cipher_patterns = [
            re.compile(r".*_CBC_.*"),
            re.compile(r".*_128_.*"),
        ]

        # Statistics
        self.detection_count = 0
        self.start_time = datetime.now(timezone.utc)

        logger.info(
            "HNDLDetector initialized (mode=%s, thresholds=%s)",
            detection_mode.value,
            self.thresholds.__dict__,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def process_network_signal(self, signal: NetworkSignal) -> Optional[HNDLThreatProfile]:
        """
        Analyze a network signal for HNDL indicators.

        Returns a threat profile if any detection heuristic fires,
        otherwise ``None``.
        """
        try:
            actor_id = signal.source_ip
            if actor_id not in self.actor_profiles:
                self.actor_profiles[actor_id] = ActorProfile(actor_id)

            profile = self.actor_profiles[actor_id]
            profile.update_network_signal(signal)

            if not profile.baseline_established and len(profile.connections) >= 100:
                profile.establish_baseline()

            self.network_signal_buffer.append(signal)

            flow_id = signal.calculate_flow_id()
            self.active_flows[flow_id].append(signal)

            threat = None
            if self.detection_mode in (DetectionMode.REALTIME, DetectionMode.HYBRID):
                threat = (
                    self._detect_volume_spike(signal, profile)
                    or self._detect_network_fanout(signal, profile)
                    or self._detect_long_lived_tls(signal, flow_id)
                    or self._detect_weak_cipher(signal)
                    or self._detect_abnormal_rate(profile)
                )

            if threat:
                self.detection_count += 1
                logger.warning(
                    "HNDL threat detected: %s severity=%s confidence=%.2f",
                    threat.threat_type,
                    threat.severity.value,
                    threat.confidence,
                )

            return threat

        except Exception as e:
            logger.error("Error processing network signal: %s", e, exc_info=True)
            return None

    def process_access_signal(self, signal: AccessSignal) -> Optional[HNDLThreatProfile]:
        """
        Analyze an access pattern signal for HNDL indicators.

        Returns a threat profile if any detection heuristic fires,
        otherwise ``None``.
        """
        try:
            actor_id = signal.actor_id
            if actor_id not in self.actor_profiles:
                self.actor_profiles[actor_id] = ActorProfile(actor_id)

            profile = self.actor_profiles[actor_id]
            profile.update_access_signal(signal)
            self.access_signal_buffer.append(signal)

            threat = None
            if self.detection_mode in (DetectionMode.REALTIME, DetectionMode.HYBRID):
                threat = (
                    self._detect_canary_trigger(signal)
                    or self._detect_abnormal_access(signal, profile)
                )

            if threat:
                self.detection_count += 1
                logger.warning(
                    "HNDL threat detected: %s severity=%s confidence=%.2f",
                    threat.threat_type,
                    threat.severity.value,
                    threat.confidence,
                )

            return threat

        except Exception as e:
            logger.error("Error processing access signal: %s", e, exc_info=True)
            return None

    def get_statistics(self) -> Dict:
        """Return current detector statistics."""
        runtime = (datetime.now(timezone.utc) - self.start_time).total_seconds()
        return {
            "runtime_seconds": runtime,
            "detection_count": self.detection_count,
            "actor_profiles": len(self.actor_profiles),
            "active_flows": len(self.active_flows),
            "network_signals_buffered": len(self.network_signal_buffer),
            "access_signals_buffered": len(self.access_signal_buffer),
            "canary_assets": len(self.canary_assets),
            "detection_mode": self.detection_mode.value,
            "thresholds": self.thresholds.__dict__,
        }

    # ------------------------------------------------------------------
    # Detection heuristics
    # ------------------------------------------------------------------

    def _detect_volume_spike(
        self, signal: NetworkSignal, profile: ActorProfile
    ) -> Optional[HNDLThreatProfile]:
        """Detect encrypted volume spike."""
        if not signal.is_encrypted():
            return None

        one_hour_ago = datetime.now(timezone.utc) - timedelta(hours=1)
        recent = [c for c in profile.connections if c.timestamp > one_hour_ago]
        if not recent:
            return None

        bytes_per_hour = sum(c.bytes_sent for c in recent)
        gb_per_hour = bytes_per_hour / (1024**3)

        if gb_per_hour < self.thresholds.volume_threshold_gb:
            return None

        confidence = 0.0
        indicators: Dict[str, object] = {
            "bytes_per_hour": bytes_per_hour,
            "gb_per_hour": gb_per_hour,
            "entropy": signal.entropy,
            "connection_count": len(recent),
        }

        volume_factor = min(gb_per_hour / self.thresholds.volume_threshold_gb, 5.0) / 5.0
        confidence += 0.3 * volume_factor

        if signal.entropy and signal.entropy >= 7.5:
            entropy_factor = (signal.entropy - 7.5) / 0.5
            confidence += 0.3 * min(entropy_factor, 1.0)

        if profile.baseline_established:
            deviation = profile.get_deviation_score(bytes_per_hour, len(profile.destinations))
            if deviation > 0:
                confidence += 0.4 * min(deviation / 10.0, 1.0)
                indicators["baseline_deviation"] = deviation
        else:
            confidence += 0.2

        if gb_per_hour > 100:
            severity = ThreatSeverity.CRITICAL
        elif gb_per_hour > 50:
            severity = ThreatSeverity.HIGH
        elif gb_per_hour > 20:
            severity = ThreatSeverity.MEDIUM
        else:
            severity = ThreatSeverity.LOW

        indicators["detection_signals"] = ["volume_spike", "high_entropy"]

        return HNDLThreatProfile(
            threat_id=str(uuid.uuid4()),
            severity=severity,
            confidence=confidence,
            threat_type=SignalType.VOLUME_SPIKE.value,
            detected_at=datetime.now(timezone.utc),
            source_ip=signal.source_ip,
            destination_ips=[signal.destination_ip],
            data_volume_bytes=bytes_per_hour,
            duration_seconds=3600,
            indicators=indicators,
            recommendations=[
                "Investigate source for unauthorized data collection",
                "Review network logs for exfiltration patterns",
                "Consider blocking source IP if confirmed malicious",
                f"Data volume: {gb_per_hour:.2f} GB/hour exceeds threshold of {self.thresholds.volume_threshold_gb} GB/hour",
            ],
            entropy_score=signal.entropy,
            packet_count=sum(c.packet_count for c in recent),
        )

    def _detect_network_fanout(
        self, signal: NetworkSignal, profile: ActorProfile
    ) -> Optional[HNDLThreatProfile]:
        """Detect distributed exfiltration to many destinations."""
        one_hour_ago = datetime.now(timezone.utc) - timedelta(hours=1)
        recent = [c for c in profile.connections if c.timestamp > one_hour_ago]
        if not recent:
            return None

        unique_destinations = len(set(c.destination_ip for c in recent))
        if unique_destinations < self.thresholds.fanout_threshold:
            return None

        total_bytes = sum(c.bytes_sent for c in recent)
        if total_bytes == 0:
            return None

        encrypted_bytes = sum(c.bytes_sent for c in recent if c.is_encrypted())
        encrypted_ratio = encrypted_bytes / total_bytes

        confidence = 0.0
        indicators: Dict[str, object] = {
            "unique_destinations": unique_destinations,
            "total_bytes": total_bytes,
            "encrypted_bytes": encrypted_bytes,
            "encrypted_ratio": encrypted_ratio,
            "connection_count": len(recent),
        }

        fanout_factor = min(unique_destinations / self.thresholds.fanout_threshold, 10.0) / 10.0
        confidence += 0.4 * fanout_factor
        confidence += 0.3 * encrypted_ratio

        gb_transferred = total_bytes / (1024**3)
        if gb_transferred > 1.0:
            confidence += 0.3 * min(gb_transferred / 10.0, 1.0)

        if unique_destinations > 20 and encrypted_ratio > 0.8:
            severity = ThreatSeverity.CRITICAL
        elif unique_destinations > 10:
            severity = ThreatSeverity.HIGH
        else:
            severity = ThreatSeverity.MEDIUM

        indicators["detection_signals"] = ["network_fanout"]
        if encrypted_ratio > 0.7:
            indicators["detection_signals"].append("high_encryption_ratio")

        destination_ips = list(set(c.destination_ip for c in recent))[:20]

        return HNDLThreatProfile(
            threat_id=str(uuid.uuid4()),
            severity=severity,
            confidence=confidence,
            threat_type=SignalType.NETWORK_FANOUT.value,
            detected_at=datetime.now(timezone.utc),
            source_ip=signal.source_ip,
            destination_ips=destination_ips,
            data_volume_bytes=total_bytes,
            duration_seconds=3600,
            indicators=indicators,
            recommendations=[
                f"Investigate distributed exfiltration to {unique_destinations} destinations",
                "Review destination IPs for known threat actors",
                "Consider implementing egress filtering",
                f"Total data transferred: {gb_transferred:.2f} GB across {len(recent)} connections",
            ],
            entropy_score=(
                sum(c.entropy or 0.0 for c in recent) / len(recent)
            ),
        )

    def _detect_long_lived_tls(
        self, signal: NetworkSignal, flow_id: str
    ) -> Optional[HNDLThreatProfile]:
        """Detect extended TLS connections that may indicate continuous collection."""
        if not signal.tls_version:
            return None

        flow_signals = self.active_flows.get(flow_id, [])
        if not flow_signals:
            return None

        first_packet = min(s.timestamp for s in flow_signals)
        last_packet = max(s.timestamp for s in flow_signals)
        duration_hours = (last_packet - first_packet).total_seconds() / 3600

        if duration_hours < self.thresholds.connection_duration_hours:
            return None

        total_bytes = sum(s.bytes_sent for s in flow_signals)
        avg_entropy = sum(s.entropy or 0.0 for s in flow_signals) / len(flow_signals)

        confidence = 0.0
        indicators: Dict[str, object] = {
            "duration_hours": duration_hours,
            "total_bytes": total_bytes,
            "packet_count": len(flow_signals),
            "avg_entropy": avg_entropy,
            "tls_version": signal.tls_version,
            "cipher_suite": signal.cipher_suite,
        }

        duration_factor = min(duration_hours / 24.0, 1.0)
        confidence += 0.4 * duration_factor

        gb_transferred = total_bytes / (1024**3)
        if gb_transferred > 1.0:
            confidence += 0.3 * min(gb_transferred / 100.0, 1.0)

        if avg_entropy >= 7.5:
            confidence += 0.3

        if duration_hours > 24 and gb_transferred > 10:
            severity = ThreatSeverity.CRITICAL
        elif duration_hours > 12:
            severity = ThreatSeverity.HIGH
        elif duration_hours > 6:
            severity = ThreatSeverity.MEDIUM
        else:
            severity = ThreatSeverity.LOW

        indicators["detection_signals"] = ["long_lived_tls"]

        return HNDLThreatProfile(
            threat_id=str(uuid.uuid4()),
            severity=severity,
            confidence=confidence,
            threat_type=SignalType.LONG_LIVED_TLS.value,
            detected_at=datetime.now(timezone.utc),
            source_ip=signal.source_ip,
            destination_ips=[signal.destination_ip],
            data_volume_bytes=total_bytes,
            duration_seconds=int(duration_hours * 3600),
            indicators=indicators,
            recommendations=[
                f"Investigate {duration_hours:.1f} hour TLS connection",
                "Review connection for unauthorized data collection",
                "Consider connection time limits for sensitive resources",
                f"Total data transferred: {gb_transferred:.2f} GB",
            ],
            entropy_score=avg_entropy,
            packet_count=len(flow_signals),
        )

    def _detect_weak_cipher(self, signal: NetworkSignal) -> Optional[HNDLThreatProfile]:
        """Detect use of quantum-vulnerable cipher suites."""
        if not signal.cipher_suite:
            return None

        is_weak = False
        weak_reasons: List[str] = []

        if signal.cipher_suite in self.weak_ciphers:
            is_weak = True
            weak_reasons.append(f"Uses vulnerable cipher: {signal.cipher_suite}")

        if not is_weak:
            for pattern in self.weak_cipher_patterns:
                if pattern.match(signal.cipher_suite):
                    is_weak = True
                    weak_reasons.append(f"Matches vulnerable pattern: {pattern.pattern}")
                    break

        if not is_weak:
            return None

        confidence = 0.8
        indicators: Dict[str, object] = {
            "cipher_suite": signal.cipher_suite,
            "tls_version": signal.tls_version,
            "weak_reasons": weak_reasons,
            "quantum_vulnerable": True,
        }

        total_bytes = signal.bytes_sent
        if total_bytes > 1024**3:
            severity = ThreatSeverity.CRITICAL
        elif total_bytes > 100 * 1024**2:
            severity = ThreatSeverity.HIGH
        else:
            severity = ThreatSeverity.MEDIUM

        indicators["detection_signals"] = ["weak_cipher", "quantum_vulnerable"]

        return HNDLThreatProfile(
            threat_id=str(uuid.uuid4()),
            severity=severity,
            confidence=confidence,
            threat_type=SignalType.WEAK_CIPHER.value,
            detected_at=datetime.now(timezone.utc),
            source_ip=signal.source_ip,
            destination_ips=[signal.destination_ip],
            data_volume_bytes=total_bytes,
            duration_seconds=int(signal.duration_seconds),
            indicators=indicators,
            recommendations=[
                "Upgrade to post-quantum cipher suites",
                f"Current cipher {signal.cipher_suite} is vulnerable to quantum attacks",
                "Implement TLS 1.3 with quantum-resistant algorithms",
                "Re-encrypt data with stronger algorithms",
            ],
            entropy_score=signal.entropy,
        )

    def _detect_abnormal_rate(self, profile: ActorProfile) -> Optional[HNDLThreatProfile]:
        """Detect abnormally high request rates (automated bulk collection)."""
        one_minute_ago = datetime.now(timezone.utc) - timedelta(minutes=1)
        recent = [c for c in profile.connections if c.timestamp > one_minute_ago]
        if not recent:
            return None

        requests_per_minute = len(recent)
        if requests_per_minute < self.thresholds.access_rate_threshold:
            return None

        confidence = min(requests_per_minute / (self.thresholds.access_rate_threshold * 2), 1.0)
        indicators: Dict[str, object] = {
            "requests_per_minute": requests_per_minute,
            "threshold": self.thresholds.access_rate_threshold,
            "unique_destinations": len(set(c.destination_ip for c in recent)),
        }

        severity = ThreatSeverity.MEDIUM
        if requests_per_minute > self.thresholds.access_rate_threshold * 5:
            severity = ThreatSeverity.HIGH

        indicators["detection_signals"] = ["abnormal_access_rate"]

        return HNDLThreatProfile(
            threat_id=str(uuid.uuid4()),
            severity=severity,
            confidence=confidence,
            threat_type=SignalType.ABNORMAL_ACCESS.value,
            detected_at=datetime.now(timezone.utc),
            source_ip=profile.actor_id,
            destination_ips=list(set(c.destination_ip for c in recent))[:10],
            data_volume_bytes=sum(c.bytes_sent for c in recent),
            duration_seconds=60,
            indicators=indicators,
            recommendations=[
                f"Investigate high access rate: {requests_per_minute} requests/minute",
                "Consider rate limiting for this actor",
                "Review for automated scraping or bulk download",
            ],
        )

    def _detect_abnormal_access(
        self, signal: AccessSignal, profile: ActorProfile
    ) -> Optional[HNDLThreatProfile]:
        """Detect suspicious access patterns (bulk, off-hours, sequential)."""
        suspicious_indicators: List[str] = []
        confidence = 0.0

        if signal.is_bulk or signal.bytes_accessed > 1024**3:
            suspicious_indicators.append("bulk_operation")
            confidence += 0.3

        if signal.is_offhours or signal.timestamp.hour < 6 or signal.timestamp.hour > 22:
            suspicious_indicators.append("off_hours_access")
            confidence += 0.2

        recent_access = [
            a
            for a in profile.access_patterns
            if a.timestamp > datetime.now(timezone.utc) - timedelta(minutes=10)
        ]
        if len(recent_access) > 10:
            resource_ids = [a.resource_id for a in recent_access]
            if self._is_sequential_pattern(resource_ids):
                suspicious_indicators.append("sequential_access")
                confidence += 0.3

        if signal.resource_type in ("database_export", "backup_file", "archive"):
            suspicious_indicators.append("sensitive_resource_type")
            confidence += 0.2

        if not suspicious_indicators:
            return None

        indicators: Dict[str, object] = {
            "suspicious_patterns": suspicious_indicators,
            "access_count": len(recent_access),
            "bytes_accessed": signal.bytes_accessed,
            "resource_type": signal.resource_type,
            "is_offhours": signal.is_offhours,
        }

        severity = ThreatSeverity.MEDIUM
        if len(suspicious_indicators) >= 3:
            severity = ThreatSeverity.HIGH

        indicators["detection_signals"] = ["abnormal_access"] + suspicious_indicators

        return HNDLThreatProfile(
            threat_id=str(uuid.uuid4()),
            severity=severity,
            confidence=confidence,
            threat_type=SignalType.ABNORMAL_ACCESS.value,
            detected_at=datetime.now(timezone.utc),
            source_ip=signal.source_ip,
            destination_ips=[],
            data_volume_bytes=signal.bytes_accessed,
            duration_seconds=0,
            indicators=indicators,
            recommendations=[
                "Investigate unusual access pattern",
                "Review user authorization for bulk operations",
                f"Actor {signal.actor_id} exhibits {len(suspicious_indicators)} suspicious patterns",
                "Consider additional monitoring or access restrictions",
            ],
        )

    def _detect_canary_trigger(self, signal: AccessSignal) -> Optional[HNDLThreatProfile]:
        """Detect access to canary / honeypot resources."""
        resource_path = f"{signal.resource_type}:{signal.resource_id}"
        if resource_path not in self.canary_assets:
            return None

        confidence = 0.95
        severity = ThreatSeverity.CRITICAL

        indicators: Dict[str, object] = {
            "canary_resource": resource_path,
            "canary_type": signal.resource_type,
            "actor_id": signal.actor_id,
            "access_time": signal.timestamp.isoformat(),
            "detection_signals": ["canary_trigger", "unauthorized_access"],
        }

        return HNDLThreatProfile(
            threat_id=str(uuid.uuid4()),
            severity=severity,
            confidence=confidence,
            threat_type=SignalType.CANARY_TRIGGER.value,
            detected_at=datetime.now(timezone.utc),
            source_ip=signal.source_ip,
            destination_ips=[],
            data_volume_bytes=0,
            duration_seconds=0,
            indicators=indicators,
            recommendations=[
                "IMMEDIATE ACTION REQUIRED: Canary asset accessed",
                f"Actor {signal.actor_id} triggered honeypot at {resource_path}",
                "Initiate incident response procedures",
                "Block actor and investigate full access history",
                "Review all activity from source IP for compromise indicators",
            ],
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_sequential_pattern(resource_ids: List[str]) -> bool:
        """Check if resource IDs follow a sequential numeric pattern."""
        if len(resource_ids) < 5:
            return False
        try:
            numbers = []
            for rid in resource_ids:
                digits = "".join(c for c in rid if c.isdigit())
                if digits:
                    numbers.append(int(digits))
            if len(numbers) < 5:
                return False
            diffs = [numbers[i + 1] - numbers[i] for i in range(len(numbers) - 1)]
            incremental_count = sum(1 for d in diffs if 0 < d <= 10)
            return incremental_count / len(diffs) > 0.7
        except Exception:
            return False
