"""
hndl-detect CLI.

Reads JSONL network flow data from stdin or a file and outputs HNDL
threat alerts as JSON.

Usage examples:

    # Pipe JSONL flow data
    cat flows.jsonl | hndl-detect

    # Read from file
    hndl-detect --input flows.jsonl

    # Adjust thresholds
    hndl-detect --input flows.jsonl --volume-threshold 5.0 --fanout-threshold 10

    # Run risk assessment instead of signal detection
    hndl-detect --input flows.jsonl --mode risk

    # Output format
    hndl-detect --input flows.jsonl --format pretty
"""

import argparse
import json
import logging
import sys
from datetime import datetime, timezone
from typing import TextIO

from .detector import HNDLDetector
from .risk_assessment import HNDLRiskAssessmentEngine
from .types import (
    DetectionThresholds,
    NetworkFlow,
    NetworkSignal,
)


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        prog="hndl-detect",
        description="Detect Harvest Now Decrypt Later attack patterns in network telemetry.",
    )
    parser.add_argument(
        "--version", action="version", version="%(prog)s 0.1.0"
    )
    parser.add_argument(
        "--input", "-i",
        type=str,
        default=None,
        help="Path to JSONL input file. Reads from stdin if omitted.",
    )
    parser.add_argument(
        "--mode", "-m",
        choices=["signal", "risk"],
        default="signal",
        help="Detection mode: 'signal' for real-time signal detection, "
             "'risk' for harvest risk assessment. Default: signal.",
    )
    parser.add_argument(
        "--volume-threshold",
        type=float,
        default=10.0,
        help="Volume spike threshold in GB/hour (signal mode). Default: 10.0.",
    )
    parser.add_argument(
        "--fanout-threshold",
        type=int,
        default=5,
        help="Network fanout threshold (unique destinations). Default: 5.",
    )
    parser.add_argument(
        "--entropy-threshold",
        type=float,
        default=7.5,
        help="Entropy threshold for encrypted traffic detection. Default: 7.5.",
    )
    parser.add_argument(
        "--rate-threshold",
        type=int,
        default=100,
        help="Access rate threshold (requests/minute). Default: 100.",
    )
    parser.add_argument(
        "--format", "-f",
        choices=["json", "pretty"],
        default="json",
        help="Output format. Default: json (one JSON object per line).",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging to stderr.",
    )
    return parser.parse_args(argv)


def _open_input(path) -> TextIO:
    if path is None:
        return sys.stdin
    return open(path, "r")


def _parse_network_signal(record: dict) -> NetworkSignal:
    """Parse a JSONL record into a NetworkSignal."""
    ts = record.get("timestamp")
    if isinstance(ts, str):
        ts = datetime.fromisoformat(ts)
    elif isinstance(ts, (int, float)):
        ts = datetime.fromtimestamp(ts, tz=timezone.utc)
    else:
        ts = datetime.now(timezone.utc)

    return NetworkSignal(
        timestamp=ts,
        source_ip=record.get("source_ip", record.get("src_ip", "")),
        destination_ip=record.get("destination_ip", record.get("dst_ip", record.get("dest_ip", ""))),
        port=int(record.get("port", record.get("dest_port", record.get("dst_port", 0)))),
        protocol=record.get("protocol", "TCP"),
        bytes_sent=int(record.get("bytes_sent", record.get("bytes", record.get("byte_count", 0)))),
        bytes_received=int(record.get("bytes_received", 0)),
        duration_seconds=float(record.get("duration_seconds", record.get("duration", 0))),
        tls_version=record.get("tls_version"),
        cipher_suite=record.get("cipher_suite"),
        entropy=record.get("entropy", record.get("payload_entropy")),
        session_id=record.get("session_id"),
        packet_count=int(record.get("packet_count", 0)),
        flow_id=record.get("flow_id"),
        metadata=record.get("metadata", {}),
    )


def _parse_network_flow(record: dict) -> NetworkFlow:
    """Parse a JSONL record into a NetworkFlow for risk assessment."""
    start_time = record.get("start_time", record.get("timestamp"))
    if isinstance(start_time, str):
        start_time = datetime.fromisoformat(start_time)
    elif isinstance(start_time, (int, float)):
        start_time = datetime.fromtimestamp(start_time, tz=timezone.utc)
    else:
        start_time = datetime.now(timezone.utc)

    end_time = record.get("end_time")
    if isinstance(end_time, str):
        end_time = datetime.fromisoformat(end_time)
    elif isinstance(end_time, (int, float)):
        end_time = datetime.fromtimestamp(end_time, tz=timezone.utc)
    else:
        duration = float(record.get("duration_seconds", record.get("duration", 0)))
        from datetime import timedelta
        end_time = start_time + timedelta(seconds=duration)

    return NetworkFlow(
        flow_id=record.get("flow_id", ""),
        source_ip=record.get("source_ip", record.get("src_ip", "")),
        dest_ip=record.get("destination_ip", record.get("dst_ip", record.get("dest_ip", ""))),
        source_port=int(record.get("source_port", record.get("src_port", 0))),
        dest_port=int(record.get("port", record.get("dest_port", record.get("dst_port", 0)))),
        protocol=record.get("protocol", "TCP"),
        bytes_transferred=int(
            record.get("bytes_transferred", record.get("bytes_sent", record.get("bytes", record.get("byte_count", 0))))
        ),
        packet_count=int(record.get("packet_count", 0)),
        start_time=start_time,
        end_time=end_time,
        encrypted=record.get("encrypted", False),
        tls_version=record.get("tls_version"),
        cipher_suite=record.get("cipher_suite"),
        payload_entropy=float(record.get("payload_entropy", record.get("entropy", 0.0))),
        data_type_hints=record.get("data_type_hints", []),
        metadata=record.get("metadata", {}),
    )


def _output(obj: dict, fmt: str) -> None:
    if fmt == "pretty":
        print(json.dumps(obj, indent=2, default=str))
    else:
        print(json.dumps(obj, default=str))


def main(argv=None):
    args = parse_args(argv)

    log_level = logging.DEBUG if args.verbose else logging.WARNING
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        stream=sys.stderr,
    )

    alert_count = 0
    line_count = 0

    if args.mode == "signal":
        thresholds = DetectionThresholds(
            volume_threshold_gb=args.volume_threshold,
            entropy_threshold=args.entropy_threshold,
            fanout_threshold=args.fanout_threshold,
            access_rate_threshold=args.rate_threshold,
        )
        detector = HNDLDetector(thresholds=thresholds)

        fh = _open_input(args.input)
        try:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                line_count += 1
                try:
                    record = json.loads(line)
                except json.JSONDecodeError as e:
                    print(
                        json.dumps({"error": f"Invalid JSON on line {line_count}: {e}"}),
                        file=sys.stderr,
                    )
                    continue

                signal = _parse_network_signal(record)
                threat = detector.process_network_signal(signal)
                if threat:
                    alert_count += 1
                    _output(threat.to_dict(), args.format)
        finally:
            if fh is not sys.stdin:
                fh.close()

    elif args.mode == "risk":
        engine = HNDLRiskAssessmentEngine()

        fh = _open_input(args.input)
        try:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                line_count += 1
                try:
                    record = json.loads(line)
                except json.JSONDecodeError as e:
                    print(
                        json.dumps({"error": f"Invalid JSON on line {line_count}: {e}"}),
                        file=sys.stderr,
                    )
                    continue

                flow = _parse_network_flow(record)
                result = engine.assess_flow(flow)
                _output(result, args.format)
                if result["risk_assessment"]["overall_risk"] in ("HIGH", "CRITICAL"):
                    alert_count += 1
        finally:
            if fh is not sys.stdin:
                fh.close()

    # Print summary to stderr
    print(
        f"Processed {line_count} records, {alert_count} alerts generated.",
        file=sys.stderr,
    )


if __name__ == "__main__":
    main()
