"""
HNDL APT threat detector.

Implements batch analysis of network traffic for Harvest Now Decrypt Later
attack patterns with APT group attribution. Detection stages:

1. Traffic pattern analysis (encrypted volume, persistence, hoarding)
2. Bulk encrypted data collection monitoring
3. Persistent TLS session analysis
4. Data hoarding pattern recognition
5. APT behavioral correlation (APT28, APT29, Lazarus, Equation Group)
6. Quantum vulnerability assessment

This module operates on rule-based heuristics and signature matching.
No ML dependencies are required.
"""

import hashlib
import json
import logging
import math
import threading
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from .types import (
    APTThreatProfile,
    CryptoAlgorithm,
    NetworkFlowSimple,
    ThreatIndicator,
)

logger = logging.getLogger(__name__)


class HNDLThreatDetector:
    """
    Rule-based HNDL threat detector with APT attribution.

    Analyzes batches of network flows for harvest attack patterns and
    correlates findings against known APT group signatures.
    """

    def __init__(self, config_path: Optional[Path] = None):
        self.config = self._load_configuration(config_path)
        self.threat_profiles: Dict[str, APTThreatProfile] = {}
        self.network_baseline: Dict[str, deque] = defaultdict(lambda: deque(maxlen=10000))
        self.apt_signatures = self._load_apt_signatures()
        self.quantum_timeline = self._load_quantum_timeline()
        self.detection_thresholds = self._initialize_thresholds()
        self.alert_queue: deque = deque(maxlen=10000)
        self.statistics = self._initialize_statistics()
        self._lock = threading.RLock()

        logger.info("HNDLThreatDetector initialized")

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    @staticmethod
    def _load_configuration(config_path: Optional[Path]) -> Dict[str, Any]:
        default_config = {
            "detection_sensitivity": 0.35,
            "bulk_threshold_gb": 1,
            "persistence_window_hours": 24,
            "quantum_risk_threshold": 0.4,
            "apt_correlation_confidence": 0.6,
        }
        if config_path and config_path.exists():
            with open(config_path, "r") as f:
                user_config = json.load(f)
                default_config.update(user_config)
        return default_config

    @staticmethod
    def _load_apt_signatures() -> Dict[str, Dict[str, Any]]:
        return {
            "APT28": {
                "patterns": ["persistent_tls_1.2", "rsa_2048_focus", "gov_target_bias"],
                "ttps": ["T1560", "T1048", "T1041"],
                "confidence_weight": 0.85,
            },
            "APT29": {
                "patterns": ["encrypted_staging", "long_term_persistence", "quantum_aware"],
                "ttps": ["T1022", "T1560.001", "T1048.003"],
                "confidence_weight": 0.82,
            },
            "Lazarus": {
                "patterns": ["financial_crypto_focus", "bulk_wallet_harvest", "exchange_targeting"],
                "ttps": ["T1005", "T1114", "T1560.003"],
                "confidence_weight": 0.79,
            },
            "Equation Group": {
                "patterns": ["advanced_crypto_analysis", "selective_high_value", "quantum_prep"],
                "ttps": ["T1480", "T1025", "T1119"],
                "confidence_weight": 0.91,
            },
        }

    @staticmethod
    def _load_quantum_timeline() -> Dict[int, float]:
        """Quantum computing development timeline projections."""
        return {
            2025: 0.15,
            2026: 0.22,
            2027: 0.31,
            2028: 0.42,
            2029: 0.55,
            2030: 0.68,
            2031: 0.78,
            2032: 0.85,
            2033: 0.91,
            2034: 0.95,
            2035: 0.99,
        }

    @staticmethod
    def _initialize_thresholds() -> Dict[str, float]:
        return {
            "bulk_collection_bytes": 500 * 1024**2,
            "persistence_duration_hours": 12,
            "entropy_threshold": 7.0,
            "tls_session_abnormality": 2.5,
            "data_hoarding_rate": 10 * 1024**2,
            "cert_request_spike": 3.0,
            "quantum_risk_critical": 0.50,
        }

    @staticmethod
    def _initialize_statistics() -> Dict[str, Any]:
        return {
            "total_flows_analyzed": 0,
            "threats_detected": 0,
            "data_harvested_gb": 0.0,
            "apt_attributions": defaultdict(int),
            "vulnerable_systems": set(),
        }

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def detect_harvest_attempts(
        self, network_traffic: List[NetworkFlowSimple]
    ) -> List[APTThreatProfile]:
        """
        Detect HNDL attack patterns in a batch of network flows.

        Returns a list of threat profiles that exceed the configured
        detection sensitivity threshold.
        """
        detected_threats: List[APTThreatProfile] = []

        traffic_analysis = self._analyze_traffic_patterns(network_traffic)
        bulk_threats = self._detect_bulk_collection(traffic_analysis)
        persistence_threats = self._detect_persistent_monitoring(traffic_analysis)
        hoarding_threats = self._detect_data_hoarding(traffic_analysis)

        for threat_candidate in bulk_threats + persistence_threats + hoarding_threats:
            threat_profile = self._build_threat_profile(threat_candidate, network_traffic)
            threat_profile.apt_group_attribution = self._attribute_to_apt(threat_profile)
            threat_profile.confidence_score = self._calculate_threat_confidence(threat_profile)
            threat_profile.recommended_actions = self._generate_recommendations(threat_profile)

            if threat_profile.confidence_score >= self.config["detection_sensitivity"]:
                detected_threats.append(threat_profile)
                self.threat_profiles[threat_profile.threat_id] = threat_profile
                self._raise_alert(threat_profile)
                self.statistics["threats_detected"] += 1
                if threat_profile.apt_group_attribution:
                    self.statistics["apt_attributions"][threat_profile.apt_group_attribution] += 1

        return detected_threats

    def assess_quantum_vulnerability(
        self,
        encrypted_data: bytes,
        algorithm: Optional[CryptoAlgorithm] = None,
    ) -> Dict[str, Any]:
        """
        Assess if encrypted data is vulnerable to future quantum attacks.

        Returns a dictionary with algorithm, risk score, estimated break
        year, migration priority, and recommendations.
        """
        assessment: Dict[str, Any] = {
            "data_hash": hashlib.sha256(encrypted_data[:1024]).hexdigest()[:16],
            "assessment_time": datetime.now(timezone.utc).isoformat(),
            "algorithm": None,
            "quantum_vulnerable": False,
            "qubits_required": float("inf"),
            "estimated_break_year": None,
            "risk_score": 0.0,
            "migration_priority": "LOW",
            "recommendations": [],
        }

        if not algorithm:
            algorithm = self._detect_encryption_algorithm(encrypted_data)

        if algorithm:
            assessment["algorithm"] = algorithm.algorithm_name
            assessment["quantum_vulnerable"] = algorithm.quantum_vulnerable
            assessment["qubits_required"] = algorithm.qubits_required

            if algorithm.quantum_vulnerable:
                break_year = self._calculate_break_year(algorithm.qubits_required)
                assessment["estimated_break_year"] = break_year
                years_until_break = break_year - datetime.now().year

                if years_until_break <= 5:
                    assessment["risk_score"] = 1.0
                    assessment["migration_priority"] = "CRITICAL"
                elif years_until_break <= 10:
                    assessment["risk_score"] = 0.7
                    assessment["migration_priority"] = "HIGH"
                elif years_until_break <= 15:
                    assessment["risk_score"] = 0.4
                    assessment["migration_priority"] = "MEDIUM"
                else:
                    assessment["risk_score"] = 0.2
                    assessment["migration_priority"] = "LOW"

                assessment["recommendations"] = [
                    f"Migrate from {algorithm.algorithm_name} to quantum-safe alternative",
                    f"Estimated quantum break: {break_year}",
                    f"Required logical qubits: {algorithm.qubits_required:,.0f}",
                    "Implement crypto-agility for rapid algorithm switching",
                ]
                if assessment["migration_priority"] in ("CRITICAL", "HIGH"):
                    assessment["recommendations"].append("Schedule immediate PQC migration")

        return assessment

    def export_threat_intelligence(self) -> Dict[str, Any]:
        """Export threat intelligence in STIX-like format."""
        bundle = {
            "type": "bundle",
            "id": f"bundle--{hashlib.sha256(str(time.time()).encode()).hexdigest()}",
            "objects": [],
        }
        for threat_id, profile in self.threat_profiles.items():
            obj = {
                "type": "threat-actor",
                "id": f"threat-actor--{threat_id}",
                "created": profile.detection_time.isoformat(),
                "name": profile.apt_group_attribution or "Unknown",
                "threat_actor_types": (
                    ["nation-state"] if profile.apt_group_attribution else ["criminal"]
                ),
                "sophistication": "advanced",
                "primary_motivation": "espionage",
                "goals": ["harvest-encrypted-data", "future-decryption"],
            }
            bundle["objects"].append(obj)
        return bundle

    def get_statistics(self) -> Dict[str, Any]:
        return {
            "total_flows_analyzed": self.statistics["total_flows_analyzed"],
            "threats_detected": self.statistics["threats_detected"],
            "data_harvested_gb": self.statistics["data_harvested_gb"],
            "apt_attributions": dict(self.statistics["apt_attributions"]),
            "vulnerable_systems_count": len(self.statistics["vulnerable_systems"]),
            "active_threats": len(self.threat_profiles),
            "pending_alerts": len(self.alert_queue),
        }

    # ------------------------------------------------------------------
    # Traffic analysis
    # ------------------------------------------------------------------

    def _analyze_traffic_patterns(
        self, network_traffic: List[NetworkFlowSimple]
    ) -> Dict[str, Any]:
        analysis: Dict[str, Any] = {
            "encrypted_flows": [],
            "bulk_transfers": [],
            "persistent_connections": [],
            "suspicious_certificates": [],
            "entropy_anomalies": [],
            "timing_patterns": defaultdict(list),
        }

        for flow in network_traffic:
            self.statistics["total_flows_analyzed"] += 1

            if flow.encrypted:
                analysis["encrypted_flows"].append(flow)
                if flow.byte_count > self.detection_thresholds["bulk_collection_bytes"]:
                    analysis["bulk_transfers"].append(flow)
                    self.statistics["data_harvested_gb"] += flow.byte_count / (1024**3)
                if flow.payload_entropy > self.detection_thresholds["entropy_threshold"]:
                    analysis["entropy_anomalies"].append(flow)

            if flow.duration > self.detection_thresholds["persistence_duration_hours"] * 3600:
                analysis["persistent_connections"].append(flow)

            for cert in flow.certificates:
                if self._is_suspicious_certificate(cert):
                    analysis["suspicious_certificates"].append((flow, cert))

            hour_key = flow.start_time.hour
            analysis["timing_patterns"][hour_key].append(flow)

        return analysis

    def _detect_bulk_collection(self, traffic_analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        threats: List[Dict[str, Any]] = []
        source_grouped: Dict[str, List[NetworkFlowSimple]] = defaultdict(list)
        for flow in traffic_analysis["bulk_transfers"]:
            source_grouped[flow.source_ip].append(flow)

        for source_ip, flows in source_grouped.items():
            total_bytes = sum(f.byte_count for f in flows)
            unique_targets = set(f.dest_ip for f in flows)

            if (
                total_bytes > self.detection_thresholds["bulk_collection_bytes"]
                and len(unique_targets) > 3
            ):
                threats.append({
                    "type": ThreatIndicator.BULK_ENCRYPTION_COLLECTION,
                    "source_ip": source_ip,
                    "targets": unique_targets,
                    "volume": total_bytes,
                    "flows": flows,
                    "timestamp": datetime.now(timezone.utc),
                })
                logger.warning(
                    "Bulk collection detected from %s: %.2f GB",
                    source_ip,
                    total_bytes / (1024**3),
                )
        return threats

    def _detect_persistent_monitoring(
        self, traffic_analysis: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        threats: List[Dict[str, Any]] = []
        for flow in traffic_analysis["persistent_connections"]:
            if flow.tls_version and self._is_tls_anomalous(flow):
                threats.append({
                    "type": ThreatIndicator.PERSISTENT_TLS_MONITORING,
                    "source_ip": flow.source_ip,
                    "target_ip": flow.dest_ip,
                    "duration": flow.duration,
                    "tls_version": flow.tls_version,
                    "cipher_suite": flow.cipher_suite,
                    "timestamp": flow.start_time,
                })
                logger.warning(
                    "Persistent TLS monitoring: %s -> %s", flow.source_ip, flow.dest_ip
                )
        return threats

    def _detect_data_hoarding(self, traffic_analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        threats: List[Dict[str, Any]] = []
        time_windows: Dict[Any, Dict[str, Any]] = defaultdict(
            lambda: {"bytes": 0, "flows": []}
        )
        for flow in traffic_analysis["encrypted_flows"]:
            window_key = flow.start_time.replace(minute=0, second=0, microsecond=0)
            time_windows[window_key]["bytes"] += flow.byte_count
            time_windows[window_key]["flows"].append(flow)

        for window, data in time_windows.items():
            rate = data["bytes"] / 3600
            if rate > self.detection_thresholds["data_hoarding_rate"] / 3600:
                threats.append({
                    "type": ThreatIndicator.ENCRYPTED_DATA_HOARDING,
                    "window": window,
                    "rate": rate,
                    "total_bytes": data["bytes"],
                    "flow_count": len(data["flows"]),
                    "flows": data["flows"],
                })
                logger.warning(
                    "Data hoarding detected at %s: %.2f MB/hour",
                    window,
                    rate * 3600 / (1024**2),
                )
        return threats

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_suspicious_certificate(cert: Dict[str, Any]) -> bool:
        suspicious = 0
        if cert.get("validity_period", 0) > 365 * 5:
            suspicious += 1
        issuer = cert.get("issuer", "")
        if any(bad in issuer.lower() for bad in ("self-signed", "untrusted", "revoked")):
            suspicious += 1
        if cert.get("key_bits", 4096) < 2048:
            suspicious += 1
        if "*" in cert.get("subject", ""):
            suspicious += 1
        return suspicious >= 2

    def _is_tls_anomalous(self, flow: NetworkFlowSimple) -> bool:
        anomaly_score = 0
        if flow.tls_version in ("TLS 1.0", "TLS 1.1", "SSL 3.0"):
            anomaly_score += 2
        weak_ciphers = ("RC4", "DES", "3DES", "MD5")
        if flow.cipher_suite and any(w in flow.cipher_suite for w in weak_ciphers):
            anomaly_score += 2
        baseline_data = list(self.network_baseline[flow.source_ip])
        if baseline_data:
            baseline_duration = sum(f.duration for f in baseline_data) / len(baseline_data)
            if baseline_duration > 0 and flow.duration > baseline_duration * 3:
                anomaly_score += 1
        expected_packet_rate = flow.packet_count / max(flow.duration, 1)
        if expected_packet_rate < 0.1:
            anomaly_score += 1
        return anomaly_score >= 3

    def _build_threat_profile(
        self,
        threat_candidate: Dict[str, Any],
        network_traffic: List[NetworkFlowSimple],
    ) -> APTThreatProfile:
        profile = APTThreatProfile()

        if "source_ip" in threat_candidate:
            profile.source_ips.add(threat_candidate["source_ip"])
        elif "flows" in threat_candidate:
            profile.source_ips.update(f.source_ip for f in threat_candidate["flows"])

        if "targets" in threat_candidate:
            profile.target_systems.update(threat_candidate["targets"])
        elif "target_ip" in threat_candidate:
            profile.target_systems.add(threat_candidate["target_ip"])
        elif "flows" in threat_candidate:
            profile.target_systems.update(f.dest_ip for f in threat_candidate["flows"])

        if "volume" in threat_candidate:
            profile.harvested_data_volume = threat_candidate["volume"]
        elif "total_bytes" in threat_candidate:
            profile.harvested_data_volume = threat_candidate["total_bytes"]

        for flow in network_traffic:
            if flow.source_ip in profile.source_ips or flow.dest_ip in profile.target_systems:
                algo = self._identify_encryption_algorithm(flow)
                if algo:
                    profile.encryption_algorithms.add(algo)

        if "type" in threat_candidate:
            profile.threat_indicators.add(threat_candidate["type"])

        profile.estimated_quantum_break_time = self._estimate_quantum_break_time(
            profile.encryption_algorithms
        )
        return profile

    @staticmethod
    def _identify_encryption_algorithm(
        flow: NetworkFlowSimple,
    ) -> Optional[CryptoAlgorithm]:
        if not flow.cipher_suite:
            return None
        mapping = {
            "RSA": CryptoAlgorithm.RSA_2048,
            "RSA_2048": CryptoAlgorithm.RSA_2048,
            "RSA_3072": CryptoAlgorithm.RSA_3072,
            "RSA_4096": CryptoAlgorithm.RSA_4096,
            "ECDHE": CryptoAlgorithm.ECC_P256,
            "ECDSA": CryptoAlgorithm.ECC_P256,
            "P-256": CryptoAlgorithm.ECC_P256,
            "P-384": CryptoAlgorithm.ECC_P384,
            "P-521": CryptoAlgorithm.ECC_P521,
            "AES128": CryptoAlgorithm.AES_128,
            "AES256": CryptoAlgorithm.AES_256,
            "AES_128": CryptoAlgorithm.AES_128,
            "AES_256": CryptoAlgorithm.AES_256,
        }
        for cipher_name, algorithm in mapping.items():
            if cipher_name in flow.cipher_suite.upper():
                return algorithm
        return CryptoAlgorithm.RSA_2048

    def _attribute_to_apt(self, threat_profile: APTThreatProfile) -> Optional[str]:
        attribution_scores: Dict[str, float] = {}
        for apt_group, signature in self.apt_signatures.items():
            score = 0.0
            pattern_matches = sum(
                1
                for p in signature["patterns"]
                if self._check_apt_pattern(p, threat_profile)
            )
            if signature["patterns"]:
                score += (
                    pattern_matches / len(signature["patterns"])
                ) * signature["confidence_weight"]
            ttp_matches = self._check_ttps(signature["ttps"], threat_profile)
            score += ttp_matches * 0.1
            attribution_scores[apt_group] = score

        best_match = max(attribution_scores.items(), key=lambda x: x[1])
        if best_match[1] >= self.config["apt_correlation_confidence"]:
            return best_match[0]
        return None

    def _check_apt_pattern(self, pattern: str, profile: APTThreatProfile) -> bool:
        checks = {
            "persistent_tls_1.2": ThreatIndicator.PERSISTENT_TLS_MONITORING
            in profile.threat_indicators,
            "rsa_2048_focus": any(
                algo in (CryptoAlgorithm.RSA_2048, CryptoAlgorithm.RSA_3072)
                for algo in profile.encryption_algorithms
            ),
            "gov_target_bias": self._check_government_targets(profile.target_systems),
            "encrypted_staging": ThreatIndicator.ENCRYPTED_DATA_HOARDING
            in profile.threat_indicators,
            "long_term_persistence": profile.estimated_quantum_break_time.days > 3650,
            "quantum_aware": ThreatIndicator.QUANTUM_TIMELINE_CORRELATION
            in profile.threat_indicators,
            "financial_crypto_focus": self._check_financial_targets(profile.target_systems),
            "bulk_wallet_harvest": profile.harvested_data_volume > 100 * 1024**3,
            "exchange_targeting": self._check_exchange_targets(profile.target_systems),
            "advanced_crypto_analysis": len(profile.encryption_algorithms) > 3,
            "selective_high_value": ThreatIndicator.SELECTIVE_TARGET_FOCUS
            in profile.threat_indicators,
            "quantum_prep": ThreatIndicator.LONG_TERM_STORAGE_PREP
            in profile.threat_indicators,
        }
        return checks.get(pattern, False)

    @staticmethod
    def _check_government_targets(targets: Set[str]) -> bool:
        indicators = (".gov", ".mil", "state.", "federal.", "dod.", "nsa.", "cia.")
        return any(
            any(ind in t.lower() for ind in indicators) for t in targets
        )

    @staticmethod
    def _check_financial_targets(targets: Set[str]) -> bool:
        indicators = ("bank", "finance", "trading", "exchange", "crypto", "wallet", "payment")
        return any(
            any(ind in t.lower() for ind in indicators) for t in targets
        )

    @staticmethod
    def _check_exchange_targets(targets: Set[str]) -> bool:
        indicators = ("binance", "coinbase", "kraken", "bitfinex", "huobi", "okex")
        return any(
            any(ind in t.lower() for ind in indicators) for t in targets
        )

    @staticmethod
    def _check_ttps(ttps: List[str], profile: APTThreatProfile) -> int:
        mapping = {
            "T1560": ThreatIndicator.BULK_ENCRYPTION_COLLECTION,
            "T1048": ThreatIndicator.ENCRYPTED_DATA_HOARDING,
            "T1041": ThreatIndicator.BULK_ENCRYPTION_COLLECTION,
            "T1022": ThreatIndicator.ENCRYPTED_DATA_HOARDING,
            "T1005": ThreatIndicator.SELECTIVE_TARGET_FOCUS,
            "T1114": ThreatIndicator.BULK_ENCRYPTION_COLLECTION,
            "T1480": ThreatIndicator.LONG_TERM_STORAGE_PREP,
            "T1025": ThreatIndicator.BULK_ENCRYPTION_COLLECTION,
            "T1119": ThreatIndicator.ENCRYPTED_DATA_HOARDING,
        }
        return sum(
            1
            for ttp in ttps
            if ttp in mapping and mapping[ttp] in profile.threat_indicators
        )

    def _calculate_threat_confidence(self, profile: APTThreatProfile) -> float:
        confidence = 0.0
        weights = {
            "indicators": 0.35,
            "volume": 0.25,
            "algorithms": 0.20,
            "attribution": 0.10,
            "timeline": 0.10,
        }

        if profile.threat_indicators:
            indicator_score = min(0.3 + len(profile.threat_indicators) * 0.15, 1.0)
            confidence += indicator_score * weights["indicators"]

        if profile.harvested_data_volume > 0:
            volume_score = min(profile.harvested_data_volume / (1 * 1024**3), 1.0)
            volume_score = max(volume_score, 0.2)
            confidence += volume_score * weights["volume"]

        if profile.encryption_algorithms:
            vuln_algos = sum(
                1 for a in profile.encryption_algorithms if a.quantum_vulnerable
            )
            if vuln_algos > 0:
                algo_score = 0.5 + (
                    vuln_algos / len(profile.encryption_algorithms)
                ) * 0.5
                confidence += algo_score * weights["algorithms"]

        if profile.apt_group_attribution:
            confidence += weights["attribution"]

        current_year = datetime.now().year
        if current_year in self.quantum_timeline:
            confidence += self.quantum_timeline[current_year] * weights["timeline"]

        if profile.threat_indicators:
            confidence = max(confidence, 0.40)

        return min(confidence, 1.0)

    @staticmethod
    def _generate_recommendations(profile: APTThreatProfile) -> List[str]:
        recommendations: List[str] = []

        if profile.confidence_score >= 0.9:
            recommendations.append("CRITICAL: Initiate incident response immediately")
            recommendations.append("Isolate affected systems from network")
            recommendations.append("Preserve forensic evidence for investigation")

        if any(a.quantum_vulnerable for a in profile.encryption_algorithms):
            recommendations.append(
                "Migrate vulnerable encryption to post-quantum algorithms immediately"
            )
            recommendations.append("Deploy CRYSTALS-Kyber for key encapsulation")
            recommendations.append("Implement CRYSTALS-Dilithium for digital signatures")

        if profile.apt_group_attribution:
            recommendations.append(
                f"Apply {profile.apt_group_attribution} specific countermeasures"
            )
            recommendations.append("Implement threat hunting for known TTPs")
            recommendations.append("Share threat intelligence with sector ISAC")

        if profile.harvested_data_volume > 10 * 1024**3:
            recommendations.append("Rotate all encryption keys for affected systems")
            recommendations.append("Re-encrypt sensitive data with quantum-safe algorithms")
            recommendations.append("Implement data loss prevention (DLP) controls")

        recommendations.append("Enable perfect forward secrecy (PFS) on all TLS connections")
        recommendations.append("Implement network segmentation to limit lateral movement")
        recommendations.append("Deploy deception technology to detect future harvest attempts")

        return recommendations

    @staticmethod
    def _detect_encryption_algorithm(
        encrypted_data: bytes,
    ) -> Optional[CryptoAlgorithm]:
        data_len = len(encrypted_data)
        if data_len % 256 == 0:
            return CryptoAlgorithm.RSA_2048
        elif data_len % 384 == 0:
            return CryptoAlgorithm.RSA_3072
        elif data_len % 512 == 0:
            return CryptoAlgorithm.RSA_4096
        elif data_len in (64, 65):
            return CryptoAlgorithm.ECC_P256
        elif data_len in (96, 97):
            return CryptoAlgorithm.ECC_P384
        elif data_len in (132, 133):
            return CryptoAlgorithm.ECC_P521
        elif data_len % 16 == 0:
            entropy = _calculate_entropy(encrypted_data)
            if entropy > 7.9:
                return CryptoAlgorithm.AES_256
            else:
                return CryptoAlgorithm.AES_128
        return None

    @staticmethod
    def _calculate_break_year(qubits_required: float) -> int:
        current_qubits = 1000
        growth_rate = 1.5
        years_needed = math.log(qubits_required / current_qubits) / math.log(growth_rate)
        return datetime.now().year + int(math.ceil(years_needed))

    def _estimate_quantum_break_time(
        self, algorithms: Set[CryptoAlgorithm]
    ) -> timedelta:
        if not algorithms:
            return timedelta(days=3650)
        min_break_year = 2100
        for algo in algorithms:
            if algo.quantum_vulnerable:
                break_year = self._calculate_break_year(algo.qubits_required)
                min_break_year = min(min_break_year, break_year)
        years_until_break = max(min_break_year - datetime.now().year, 0)
        return timedelta(days=years_until_break * 365)

    def _raise_alert(self, threat_profile: APTThreatProfile) -> None:
        severity = "CRITICAL"
        if threat_profile.confidence_score < 0.9:
            severity = "HIGH" if threat_profile.confidence_score >= 0.7 else "MEDIUM"
        if threat_profile.confidence_score < 0.5:
            severity = "LOW"

        alert = {
            "alert_id": threat_profile.threat_id,
            "severity": severity,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "threat_type": "HNDL_HARVEST_ATTEMPT",
            "confidence": threat_profile.confidence_score,
            "attribution": threat_profile.apt_group_attribution,
            "affected_systems": list(threat_profile.target_systems),
            "data_at_risk_gb": threat_profile.harvested_data_volume / (1024**3),
            "quantum_break_timeline": str(threat_profile.estimated_quantum_break_time),
            "recommended_actions": threat_profile.recommended_actions,
        }
        self.alert_queue.append(alert)
        logger.warning("HNDL alert: %s severity=%s", alert["alert_id"], severity)


def _calculate_entropy(data: bytes) -> float:
    """Calculate Shannon entropy of data."""
    if not data:
        return 0.0
    freq: Dict[int, int] = defaultdict(int)
    for byte in data:
        freq[byte] += 1
    entropy = 0.0
    data_len = len(data)
    for count in freq.values():
        if count > 0:
            probability = count / data_len
            entropy -= probability * math.log2(probability)
    return entropy
