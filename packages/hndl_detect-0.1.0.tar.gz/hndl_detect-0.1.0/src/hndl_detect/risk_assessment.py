"""
HNDL risk assessment engine.

Shifts from binary "detection" (nearly impossible) to actionable risk
assessment. Four sub-engines:

1. **DataValueScorer** - Score outbound data by how attractive it is to
   an HNDL attacker (quantum vulnerability, classification, shelf life,
   volume).
2. **PatiencePatternAnalyzer** - Detect methodical, long-term collection
   patterns that distinguish HNDL from opportunistic exfiltration.
3. **QuantumHoneypotEngine** - Deception-based definitive detection via
   planted data that only an HNDL attacker would exfiltrate.
4. **CrossOrgCorrelator** - ISAC integration for multi-victim campaign
   correlation.
"""

import hashlib
import logging
import secrets
import statistics
import threading
import time
from collections import defaultdict, deque
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Tuple

from .types import (
    CorrelatedThreat,
    CryptoVulnerability,
    DataClassification,
    HarvestRiskLevel,
    HarvestRiskScore,
    HoneypotEvent,
    ISACIndicator,
    NetworkFlow,
    PatienceIndicator,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data Value Scoring
# ---------------------------------------------------------------------------

class DataValueScorer:
    """
    Score outbound data by how attractive it is to HNDL attackers.

    Instead of detecting attackers (nearly impossible), assess the data's
    vulnerability to harvesting. High score = high harvest risk.

    Factors:
    1. Quantum vulnerability of encryption used
    2. Data shelf life (how long it remains valuable)
    3. Data classification / sensitivity
    4. Volume (worth the storage cost to an adversary)
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or self._default_config()
        self._data_type_patterns = self._load_data_type_patterns()
        self._cipher_vulnerabilities = self._load_cipher_vulnerabilities()

        self.weights = {
            "crypto_vulnerability": 0.35,
            "data_value": 0.30,
            "shelf_life": 0.20,
            "volume": 0.15,
        }

        logger.info("DataValueScorer initialized")

    @staticmethod
    def _default_config() -> Dict[str, Any]:
        return {
            "min_volume_bytes": 1_000_000,
            "high_value_threshold": 0.7,
            "critical_threshold": 0.9,
            "quantum_timeline_year": 2030,
        }

    @staticmethod
    def _load_data_type_patterns() -> Dict[str, Dict[str, Any]]:
        return {
            "financial": {
                "keywords": ["bank", "finance", "payment", "transaction", "account", "credit"],
                "ports": [443, 8443],
                "classification": DataClassification.CONFIDENTIAL,
                "shelf_life_years": 7,
            },
            "healthcare": {
                "keywords": ["health", "medical", "patient", "hipaa", "diagnosis"],
                "ports": [443],
                "classification": DataClassification.CONFIDENTIAL,
                "shelf_life_years": 50,
            },
            "government": {
                "keywords": ["gov", "mil", "federal", "state", "classified"],
                "ports": [443, 8443],
                "classification": DataClassification.SECRET,
                "shelf_life_years": 25,
            },
            "intellectual_property": {
                "keywords": ["patent", "trade_secret", "proprietary", "research"],
                "ports": [443],
                "classification": DataClassification.CONFIDENTIAL,
                "shelf_life_years": 20,
            },
            "personal_data": {
                "keywords": ["pii", "ssn", "identity", "personal"],
                "ports": [443],
                "classification": DataClassification.CONFIDENTIAL,
                "shelf_life_years": 75,
            },
            "communications": {
                "keywords": ["email", "message", "chat", "voip"],
                "ports": [443, 993, 995, 587],
                "classification": DataClassification.INTERNAL,
                "shelf_life_years": 5,
            },
        }

    @staticmethod
    def _load_cipher_vulnerabilities() -> Dict[str, CryptoVulnerability]:
        return {
            "TLS_RSA": CryptoVulnerability.CRITICAL_RISK,
            "RSA_2048": CryptoVulnerability.CRITICAL_RISK,
            "RSA_3072": CryptoVulnerability.HIGH_RISK,
            "RSA_4096": CryptoVulnerability.MEDIUM_RISK,
            "ECDHE": CryptoVulnerability.HIGH_RISK,
            "ECDSA": CryptoVulnerability.HIGH_RISK,
            "P-256": CryptoVulnerability.HIGH_RISK,
            "P-384": CryptoVulnerability.HIGH_RISK,
            "P-521": CryptoVulnerability.MEDIUM_RISK,
            "DHE": CryptoVulnerability.HIGH_RISK,
            "DH_2048": CryptoVulnerability.HIGH_RISK,
            "AES_128": CryptoVulnerability.MEDIUM_RISK,
            "AES_256": CryptoVulnerability.LOW_RISK,
            "CHACHA20": CryptoVulnerability.LOW_RISK,
            "KYBER": CryptoVulnerability.QUANTUM_SAFE,
            "DILITHIUM": CryptoVulnerability.QUANTUM_SAFE,
            "SPHINCS": CryptoVulnerability.QUANTUM_SAFE,
            "ML-KEM": CryptoVulnerability.QUANTUM_SAFE,
            "ML-DSA": CryptoVulnerability.QUANTUM_SAFE,
        }

    def score_flow(self, flow: NetworkFlow) -> HarvestRiskScore:
        """Calculate harvest risk score for a network flow."""
        if flow.bytes_transferred < self.config["min_volume_bytes"]:
            return self._create_negligible_score(flow)

        crypto_score = self._score_crypto_vulnerability(flow)
        data_value_score = self._score_data_value(flow)
        shelf_life_score, shelf_life_years = self._score_shelf_life(flow)
        volume_score = self._score_volume(flow)

        composite_score = (
            crypto_score * self.weights["crypto_vulnerability"]
            + data_value_score * self.weights["data_value"]
            + shelf_life_score * self.weights["shelf_life"]
            + volume_score * self.weights["volume"]
        )

        risk_level = self._determine_risk_level(composite_score)
        crypto_vuln = self._get_crypto_vulnerability(flow)
        data_class = self._classify_data_type(flow)
        recommendations, immediate_actions = self._generate_recommendations(
            composite_score, crypto_vuln, data_class, flow
        )

        return HarvestRiskScore(
            score_id=hashlib.sha256(f"{flow.flow_id}{time.time()}".encode()).hexdigest()[:16],
            assessment_time=datetime.now(timezone.utc),
            source_ip=flow.source_ip,
            destination_ip=flow.dest_ip,
            overall_risk=risk_level,
            risk_score=composite_score,
            data_value_score=data_value_score,
            crypto_vulnerability_score=crypto_score,
            shelf_life_score=shelf_life_score,
            volume_score=volume_score,
            estimated_data_classification=data_class,
            crypto_vulnerability=crypto_vuln,
            estimated_shelf_life_years=shelf_life_years,
            quantum_break_year=int(crypto_vuln.estimated_break_year) if crypto_vuln.estimated_break_year != float("inf") else 9999,
            data_volume_gb=flow.bytes_transferred / (1024**3),
            recommendations=recommendations,
            immediate_actions=immediate_actions,
        )

    def score_flows_batch(self, flows: List[NetworkFlow]) -> List[HarvestRiskScore]:
        """Score multiple flows."""
        return [self.score_flow(f) for f in flows]

    def get_high_risk_summary(self, scores: List[HarvestRiskScore]) -> Dict[str, Any]:
        """Summarize high-risk flows."""
        high_risk = [s for s in scores if s.overall_risk in (HarvestRiskLevel.HIGH, HarvestRiskLevel.CRITICAL)]
        return {
            "total_flows_assessed": len(scores),
            "high_risk_flows": len(high_risk),
            "critical_flows": len([s for s in scores if s.overall_risk == HarvestRiskLevel.CRITICAL]),
            "total_data_at_risk_gb": sum(s.data_volume_gb for s in high_risk),
            "most_vulnerable_destinations": self._get_top_destinations(high_risk),
            "most_common_vulnerabilities": self._get_vulnerability_distribution(high_risk),
        }

    # ---- internal helpers ----

    def _score_crypto_vulnerability(self, flow: NetworkFlow) -> float:
        if not flow.encrypted:
            return 1.0
        if not flow.cipher_suite:
            return 0.7
        return self._get_crypto_vulnerability(flow).risk_factor

    def _get_crypto_vulnerability(self, flow: NetworkFlow) -> CryptoVulnerability:
        if not flow.cipher_suite:
            return CryptoVulnerability.MEDIUM_RISK
        cipher_upper = flow.cipher_suite.upper()
        for pattern, vulnerability in self._cipher_vulnerabilities.items():
            if pattern in cipher_upper:
                return vulnerability
        return CryptoVulnerability.MEDIUM_RISK

    def _score_data_value(self, flow: NetworkFlow) -> float:
        return self._classify_data_type(flow).value_factor

    def _classify_data_type(self, flow: NetworkFlow) -> DataClassification:
        dest_lower = flow.dest_ip.lower() if flow.dest_ip else ""
        for _data_type, patterns in self._data_type_patterns.items():
            for keyword in patterns["keywords"]:
                if keyword in dest_lower:
                    return patterns["classification"]
                for hint in flow.data_type_hints:
                    if keyword in hint.lower():
                        return patterns["classification"]
        gov_patterns = [".gov", ".mil", "federal", "state."]
        for pat in gov_patterns:
            if pat in dest_lower:
                return DataClassification.SECRET
        if flow.encrypted and flow.dest_port == 443:
            return DataClassification.INTERNAL
        return DataClassification.PUBLIC

    def _score_shelf_life(self, flow: NetworkFlow) -> Tuple[float, int]:
        data_class = self._classify_data_type(flow)
        shelf_life = data_class.shelf_life_years
        for _data_type, patterns in self._data_type_patterns.items():
            for hint in flow.data_type_hints:
                if any(kw in hint.lower() for kw in patterns["keywords"]):
                    shelf_life = max(shelf_life, patterns["shelf_life_years"])
        score = min(shelf_life / 50.0, 1.0)
        return score, shelf_life

    @staticmethod
    def _score_volume(flow: NetworkFlow) -> float:
        gb = flow.bytes_transferred / (1024**3)
        if gb <= 0.001:
            return 0.0
        elif gb < 0.1:
            return 0.2
        elif gb < 1:
            return 0.4
        elif gb < 10:
            return 0.6
        elif gb < 100:
            return 0.8
        else:
            return 1.0

    @staticmethod
    def _determine_risk_level(score: float) -> HarvestRiskLevel:
        if score < 0.2:
            return HarvestRiskLevel.NEGLIGIBLE
        elif score < 0.4:
            return HarvestRiskLevel.LOW
        elif score < 0.6:
            return HarvestRiskLevel.MODERATE
        elif score < 0.8:
            return HarvestRiskLevel.HIGH
        else:
            return HarvestRiskLevel.CRITICAL

    @staticmethod
    def _generate_recommendations(
        score: float,
        crypto_vuln: CryptoVulnerability,
        data_class: DataClassification,
        flow: NetworkFlow,
    ) -> Tuple[List[str], List[str]]:
        recommendations: List[str] = []
        immediate_actions: List[str] = []
        if score >= 0.8:
            immediate_actions.append("CRITICAL: Migrate this data flow to post-quantum encryption immediately")
            immediate_actions.append("Review if this data transfer is authorized and necessary")
        if crypto_vuln in (CryptoVulnerability.CRITICAL_RISK, CryptoVulnerability.HIGH_RISK):
            recommendations.append(f"Encryption uses {crypto_vuln.risk_name} algorithm - migrate to ML-KEM/ML-DSA")
            recommendations.append(f"Estimated quantum break year: {int(crypto_vuln.estimated_break_year)}")
        if data_class in (DataClassification.SECRET, DataClassification.TOP_SECRET):
            recommendations.append("High-value data detected - ensure PQC protection")
            recommendations.append("Consider data segmentation to reduce exposure")
        if flow.bytes_transferred > 10 * 1024**3:
            recommendations.append("Large data volume - high storage ROI for attackers")
            recommendations.append("Consider breaking into smaller, separately encrypted transfers")
        if not recommendations:
            recommendations.append("Current risk level acceptable, continue monitoring")
        return recommendations, immediate_actions

    def _create_negligible_score(self, flow: NetworkFlow) -> HarvestRiskScore:
        return HarvestRiskScore(
            score_id=hashlib.sha256(f"{flow.flow_id}{time.time()}".encode()).hexdigest()[:16],
            assessment_time=datetime.now(timezone.utc),
            source_ip=flow.source_ip,
            destination_ip=flow.dest_ip,
            overall_risk=HarvestRiskLevel.NEGLIGIBLE,
            risk_score=0.0,
            data_value_score=0.0,
            crypto_vulnerability_score=0.0,
            shelf_life_score=0.0,
            volume_score=0.0,
            estimated_data_classification=DataClassification.PUBLIC,
            crypto_vulnerability=CryptoVulnerability.QUANTUM_SAFE,
            estimated_shelf_life_years=0,
            quantum_break_year=2100,
            data_volume_gb=flow.bytes_transferred / (1024**3),
            recommendations=["Data volume too small to warrant harvest risk assessment"],
            immediate_actions=[],
        )

    @staticmethod
    def _get_top_destinations(scores: List[HarvestRiskScore], top_n: int = 5) -> List[Dict[str, Any]]:
        dest_risk: Dict[str, Dict[str, float]] = defaultdict(
            lambda: {"total_risk": 0.0, "flow_count": 0, "data_gb": 0.0}
        )
        for score in scores:
            dest_risk[score.destination_ip]["total_risk"] += score.risk_score
            dest_risk[score.destination_ip]["flow_count"] += 1
            dest_risk[score.destination_ip]["data_gb"] += score.data_volume_gb
        sorted_dests = sorted(dest_risk.items(), key=lambda x: x[1]["total_risk"], reverse=True)
        return [
            {
                "destination": dest,
                "avg_risk": data["total_risk"] / data["flow_count"],
                "flow_count": int(data["flow_count"]),
                "data_gb": data["data_gb"],
            }
            for dest, data in sorted_dests[:top_n]
        ]

    @staticmethod
    def _get_vulnerability_distribution(scores: List[HarvestRiskScore]) -> Dict[str, int]:
        dist: Dict[str, int] = defaultdict(int)
        for score in scores:
            dist[score.crypto_vulnerability.risk_name] += 1
        return dict(dist)


# ---------------------------------------------------------------------------
# Patience Pattern Analysis
# ---------------------------------------------------------------------------

class PatiencePatternAnalyzer:
    """
    Detect HNDL through behavioral patience analysis.

    HNDL attackers have no time pressure. They can collect data slowly
    over months or years because quantum computers capable of breaking
    current encryption are still years away. This creates a distinctive
    behavioral signature:

    - Traditional exfil: fast, bursty, time-sensitive
    - HNDL harvesting: slow, steady, methodical, patient

    By analyzing transfer patience patterns we can separate HNDL from
    normal exfiltration attempts.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or self._default_config()
        self._actor_history: Dict[str, deque] = defaultdict(
            lambda: deque(maxlen=self.config["max_history_per_actor"])
        )
        self._actor_first_seen: Dict[str, datetime] = {}
        self._lock = threading.RLock()
        logger.info("PatiencePatternAnalyzer initialized")

    @staticmethod
    def _default_config() -> Dict[str, Any]:
        return {
            "min_observation_days": 7,
            "max_history_per_actor": 10000,
            "patience_threshold": 0.7,
            "consistency_threshold": 0.6,
            "max_daily_rate_mb": 500,
            "min_sessions": 5,
        }

    def record_flow(self, flow: NetworkFlow) -> None:
        """Record a flow for pattern analysis."""
        actor_key = flow.dest_ip
        with self._lock:
            if actor_key not in self._actor_first_seen:
                self._actor_first_seen[actor_key] = flow.start_time
            self._actor_history[actor_key].append({
                "timestamp": flow.start_time,
                "bytes": flow.bytes_transferred,
                "encrypted": flow.encrypted,
                "cipher_suite": flow.cipher_suite,
                "duration": flow.duration_seconds,
            })

    def analyze_actor(self, dest_ip: str) -> Optional[PatienceIndicator]:
        """Analyze a destination for HNDL patience patterns."""
        with self._lock:
            if dest_ip not in self._actor_history:
                return None
            history = list(self._actor_history[dest_ip])
            first_seen = self._actor_first_seen.get(dest_ip)

        if not history or not first_seen:
            return None

        last_seen = max(h["timestamp"] for h in history)
        observation_days = (last_seen - first_seen).days

        if observation_days < self.config["min_observation_days"]:
            return None
        if len(history) < self.config["min_sessions"]:
            return None

        total_bytes = sum(h["bytes"] for h in history)
        daily_bytes = self._calculate_daily_bytes(history)
        consistency_score = self._calculate_consistency(daily_bytes)
        daily_rate_variance = self._calculate_variance(daily_bytes)
        patience_score = self._calculate_patience_score(
            history, observation_days, daily_bytes, consistency_score
        )

        all_encrypted = all(h["encrypted"] for h in history)
        targets_quantum_vulnerable = self._check_quantum_vulnerable(history)
        avoids_detection = self._check_avoids_detection(history, daily_bytes)

        is_suspected = (
            patience_score >= self.config["patience_threshold"]
            and all_encrypted
            and avoids_detection
        )

        confidence = self._calculate_confidence(
            patience_score, consistency_score, observation_days, len(history)
        )

        return PatienceIndicator(
            actor_ip=dest_ip,
            first_seen=first_seen,
            last_seen=last_seen,
            observation_days=observation_days,
            total_bytes=total_bytes,
            session_count=len(history),
            consistency_score=consistency_score,
            patience_score=patience_score,
            daily_rate_variance=daily_rate_variance,
            all_encrypted=all_encrypted,
            targets_quantum_vulnerable=targets_quantum_vulnerable,
            avoids_detection_patterns=avoids_detection,
            is_suspected_hndl=is_suspected,
            confidence=confidence,
        )

    def analyze_all_actors(self) -> List[PatienceIndicator]:
        """Analyze all tracked actors."""
        with self._lock:
            actors = list(self._actor_history.keys())
        results = []
        for actor in actors:
            indicator = self.analyze_actor(actor)
            if indicator:
                results.append(indicator)
        return results

    def get_suspected_hndl_actors(self) -> List[PatienceIndicator]:
        """Return only actors with suspected HNDL behavior."""
        return [i for i in self.analyze_all_actors() if i.is_suspected_hndl]

    # ---- internal helpers ----

    @staticmethod
    def _calculate_daily_bytes(history: List[Dict[str, Any]]) -> Dict[str, int]:
        daily: Dict[str, int] = defaultdict(int)
        for h in history:
            day_key = h["timestamp"].strftime("%Y-%m-%d")
            daily[day_key] += h["bytes"]
        return dict(daily)

    @staticmethod
    def _calculate_consistency(daily_bytes: Dict[str, int]) -> float:
        if len(daily_bytes) < 3:
            return 0.0
        values = list(daily_bytes.values())
        mean_val = statistics.mean(values)
        if mean_val == 0:
            return 0.0
        std_val = statistics.stdev(values) if len(values) > 1 else 0
        cv = std_val / mean_val
        return min(max(0, 1 - cv), 1.0)

    @staticmethod
    def _calculate_variance(daily_bytes: Dict[str, int]) -> float:
        if len(daily_bytes) < 2:
            return 0.0
        values = list(daily_bytes.values())
        return statistics.variance(values) if len(values) > 1 else 0.0

    def _calculate_patience_score(
        self,
        history: List[Dict],
        observation_days: int,
        daily_bytes: Dict[str, int],
        consistency: float,
    ) -> float:
        score = 0.0
        if observation_days >= 90:
            score += 0.3
        elif observation_days >= 30:
            score += 0.2
        elif observation_days >= 14:
            score += 0.1

        score += consistency * 0.25

        avg_daily_mb = statistics.mean(daily_bytes.values()) / (1024**2) if daily_bytes else 0
        if avg_daily_mb < 100:
            score += 0.25
        elif avg_daily_mb < 500:
            score += 0.15

        max_daily = max(daily_bytes.values()) if daily_bytes else 0
        avg_daily = statistics.mean(daily_bytes.values()) if daily_bytes else 0
        if avg_daily > 0:
            burst_ratio = max_daily / avg_daily
            if burst_ratio < 2:
                score += 0.2
            elif burst_ratio < 5:
                score += 0.1

        return min(score, 1.0)

    @staticmethod
    def _check_quantum_vulnerable(history: List[Dict]) -> bool:
        vulnerable_patterns = ["RSA", "ECDHE", "ECDSA", "DHE", "P-256", "P-384"]
        for h in history:
            cipher = h.get("cipher_suite", "")
            if cipher and any(p in cipher.upper() for p in vulnerable_patterns):
                return True
        return False

    def _check_avoids_detection(
        self, history: List[Dict], daily_bytes: Dict[str, int]
    ) -> bool:
        if not daily_bytes:
            return False
        avg_daily_mb = statistics.mean(daily_bytes.values()) / (1024**2)
        if avg_daily_mb > self.config["max_daily_rate_mb"]:
            return False
        if not all(h["encrypted"] for h in history):
            return False
        return True

    @staticmethod
    def _calculate_confidence(
        patience_score: float,
        consistency_score: float,
        observation_days: int,
        session_count: int,
    ) -> float:
        data_factor = min(session_count / 50, 1.0) * 0.3
        time_factor = min(observation_days / 60, 1.0) * 0.3
        pattern_factor = (patience_score + consistency_score) / 2 * 0.4
        return min(data_factor + time_factor + pattern_factor, 1.0)


# ---------------------------------------------------------------------------
# Quantum Honeypot Engine
# ---------------------------------------------------------------------------

class QuantumHoneypotEngine:
    """
    Deception-based HNDL detection using quantum honeypots.

    This is the only definitive way to detect HNDL intent:

    1. Generate fake high-value data that *appears* to be quantum-
       vulnerable, highly classified, and long-lived.
    2. Plant this data where attackers might find it.
    3. Monitor for exfiltration of honeypot data.
    4. If honeypot data is exfiltrated, the attacker is confirmed to be
       harvesting for future quantum decryption.

    No legitimate user would exfiltrate fake data. If someone takes the
    bait, they are harvesting based on perceived future value.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or self._default_config()
        self._honeypots: Dict[str, Dict[str, Any]] = {}
        self._honeypot_signatures: Dict[str, bytes] = {}
        self._detections: List[HoneypotEvent] = []
        self._lock = threading.RLock()
        logger.info("QuantumHoneypotEngine initialized")

    @staticmethod
    def _default_config() -> Dict[str, Any]:
        return {
            "honeypot_size_min_kb": 100,
            "honeypot_size_max_kb": 10000,
            "signature_length": 32,
            "entropy_target": 7.9,
        }

    def create_honeypot(
        self,
        apparent_type: str = "FINANCIAL_RECORDS",
        apparent_classification: str = "SECRET",
        apparent_encryption: str = "RSA-2048",
    ) -> Tuple[str, bytes]:
        """
        Create a quantum honeypot.

        Returns ``(honeypot_id, honeypot_data)``.
        """
        honeypot_id = hashlib.sha256(secrets.token_bytes(32)).hexdigest()[:16]

        size = (
            secrets.randbelow(
                self.config["honeypot_size_max_kb"] - self.config["honeypot_size_min_kb"]
            )
            + self.config["honeypot_size_min_kb"]
        )
        size_bytes = size * 1024
        content = secrets.token_bytes(size_bytes)

        signature = secrets.token_bytes(self.config["signature_length"])
        positions = [0, size_bytes // 4, size_bytes // 2, 3 * size_bytes // 4]
        content_array = bytearray(content)
        for pos in positions:
            if pos + len(signature) < len(content_array):
                content_array[pos : pos + len(signature)] = signature

        honeypot_data = bytes(content_array)

        with self._lock:
            self._honeypots[honeypot_id] = {
                "id": honeypot_id,
                "created": datetime.now(timezone.utc).isoformat(),
                "apparent_type": apparent_type,
                "apparent_classification": apparent_classification,
                "apparent_encryption": apparent_encryption,
                "size_bytes": len(honeypot_data),
                "signature_hash": hashlib.sha256(signature).hexdigest(),
                "deployed": False,
                "exfiltrated": False,
            }
            self._honeypot_signatures[honeypot_id] = signature

        logger.info(
            "Honeypot created: %s (type=%s, class=%s)",
            honeypot_id,
            apparent_type,
            apparent_classification,
        )
        return honeypot_id, honeypot_data

    def mark_deployed(self, honeypot_id: str, location: str) -> bool:
        """Mark a honeypot as deployed to a specific location."""
        with self._lock:
            if honeypot_id not in self._honeypots:
                return False
            self._honeypots[honeypot_id]["deployed"] = True
            self._honeypots[honeypot_id]["deployment_location"] = location
            self._honeypots[honeypot_id]["deployment_time"] = datetime.now(timezone.utc).isoformat()
        logger.info("Honeypot %s deployed to %s", honeypot_id, location)
        return True

    def check_exfiltration(
        self, network_data: bytes, source_ip: str, dest_ip: str
    ) -> Optional[HoneypotEvent]:
        """
        Check if network data contains honeypot content.

        If honeypot data is found in outbound traffic, HNDL activity is
        confirmed.
        """
        with self._lock:
            for honeypot_id, signature in self._honeypot_signatures.items():
                if signature in network_data:
                    honeypot = self._honeypots[honeypot_id]
                    event = HoneypotEvent(
                        event_id=hashlib.sha256(
                            f"{honeypot_id}{time.time()}".encode()
                        ).hexdigest()[:16],
                        honeypot_id=honeypot_id,
                        detection_time=datetime.now(timezone.utc),
                        source_ip=source_ip,
                        destination_ip=dest_ip,
                        data_volume_bytes=len(network_data),
                        is_confirmed_hndl=True,
                        confidence=0.99,
                        honeypot_type="quantum_vulnerable_decoy",
                        apparent_data_type=honeypot["apparent_type"],
                        apparent_classification=honeypot["apparent_classification"],
                    )
                    self._honeypots[honeypot_id]["exfiltrated"] = True
                    self._honeypots[honeypot_id]["exfiltration_time"] = datetime.now(timezone.utc).isoformat()
                    self._honeypots[honeypot_id]["exfiltration_dest"] = dest_ip
                    self._detections.append(event)
                    logger.critical(
                        "HONEYPOT EXFILTRATION DETECTED - CONFIRMED HNDL ACTIVITY: "
                        "honeypot=%s dest=%s type=%s",
                        honeypot_id,
                        dest_ip,
                        honeypot["apparent_type"],
                    )
                    return event
        return None

    def get_honeypot_status(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "total_honeypots": len(self._honeypots),
                "deployed": len([h for h in self._honeypots.values() if h["deployed"]]),
                "exfiltrated": len([h for h in self._honeypots.values() if h["exfiltrated"]]),
                "total_detections": len(self._detections),
            }

    def get_detections(self) -> List[HoneypotEvent]:
        with self._lock:
            return list(self._detections)


# ---------------------------------------------------------------------------
# Cross-Organization Correlation (ISAC Integration)
# ---------------------------------------------------------------------------

class CrossOrgCorrelator:
    """
    Cross-organization HNDL threat correlation via ISAC integration.

    HNDL attackers (especially nation-states) target multiple organizations.
    By anonymizing and sharing indicators through an ISAC, we can correlate
    across victims and dramatically increase confidence.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or self._default_config()
        self._internal_indicators: Dict[str, ISACIndicator] = {}
        self._external_indicators: Dict[str, ISACIndicator] = {}
        self._correlations: List[CorrelatedThreat] = []
        self._lock = threading.RLock()
        self._org_id = hashlib.sha256(secrets.token_bytes(16)).hexdigest()[:8]
        logger.info("CrossOrgCorrelator initialized (org_id=%s)", self._org_id)

    @staticmethod
    def _default_config() -> Dict[str, Any]:
        return {
            "correlation_threshold": 0.7,
            "min_external_sightings": 2,
            "campaign_threshold": 3,
            "indicator_ttl_days": 90,
            "anonymization_enabled": True,
        }

    def create_indicator(
        self, indicator_type: str, value: str, tags: Optional[List[str]] = None
    ) -> ISACIndicator:
        """Create an ISAC indicator from an internal detection."""
        if self.config["anonymization_enabled"]:
            value_hash = hashlib.sha256(value.encode()).hexdigest()
        else:
            value_hash = value

        indicator_id = hashlib.sha256(
            f"{indicator_type}{value_hash}{self._org_id}".encode()
        ).hexdigest()[:16]

        indicator = ISACIndicator(
            indicator_id=indicator_id,
            indicator_type=indicator_type,
            value_hash=value_hash,
            first_seen=datetime.now(timezone.utc),
            last_seen=datetime.now(timezone.utc),
            sighting_count=1,
            contributing_orgs=1,
            confidence=0.5,
            tags=tags or [],
            metadata={"origin_org": self._org_id},
        )
        with self._lock:
            self._internal_indicators[indicator_id] = indicator
        return indicator

    def share_indicators(self) -> List[Dict[str, Any]]:
        """Get indicators in a shareable format for ISAC submission."""
        with self._lock:
            return [
                {
                    "indicator_id": ind.indicator_id,
                    "type": ind.indicator_type,
                    "value_hash": ind.value_hash,
                    "first_seen": ind.first_seen.isoformat(),
                    "last_seen": ind.last_seen.isoformat(),
                    "sighting_count": ind.sighting_count,
                    "tags": ind.tags,
                    "origin": self._org_id,
                }
                for ind in self._internal_indicators.values()
            ]

    def receive_external_indicators(self, indicators: List[Dict[str, Any]]) -> int:
        """Receive indicators from ISAC. Returns number of new indicators."""
        new_count = 0
        with self._lock:
            for ind_data in indicators:
                indicator_id = ind_data.get("indicator_id")
                if indicator_id in self._external_indicators:
                    existing = self._external_indicators[indicator_id]
                    existing.sighting_count += 1
                    existing.last_seen = datetime.now(timezone.utc)
                    existing.contributing_orgs = ind_data.get("contributing_orgs", 1)
                else:
                    indicator = ISACIndicator(
                        indicator_id=indicator_id,
                        indicator_type=ind_data.get("type", "unknown"),
                        value_hash=ind_data.get("value_hash", ""),
                        first_seen=datetime.fromisoformat(ind_data["first_seen"]),
                        last_seen=datetime.now(timezone.utc),
                        sighting_count=ind_data.get("sighting_count", 1),
                        contributing_orgs=ind_data.get("contributing_orgs", 1),
                        confidence=ind_data.get("confidence", 0.5),
                        tags=ind_data.get("tags", []),
                        metadata=ind_data.get("metadata", {}),
                    )
                    self._external_indicators[indicator_id] = indicator
                    new_count += 1
        self._check_correlations()
        return new_count

    def get_correlations(self) -> List[CorrelatedThreat]:
        with self._lock:
            return list(self._correlations)

    def get_campaigns(self) -> List[CorrelatedThreat]:
        with self._lock:
            return [c for c in self._correlations if c.is_confirmed_campaign]

    def get_correlation_summary(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "internal_indicators": len(self._internal_indicators),
                "external_indicators": len(self._external_indicators),
                "total_correlations": len(self._correlations),
                "confirmed_campaigns": len([c for c in self._correlations if c.is_confirmed_campaign]),
            }

    # ---- internal ----

    def _check_correlations(self) -> None:
        with self._lock:
            for _int_id, internal in self._internal_indicators.items():
                for _ext_id, external in self._external_indicators.items():
                    if internal.value_hash == external.value_hash:
                        self._create_correlation(internal, external)

    def _create_correlation(self, internal: ISACIndicator, external: ISACIndicator) -> None:
        for existing in self._correlations:
            if internal.indicator_id in existing.internal_indicators:
                return
        orgs_affected = external.contributing_orgs + 1
        is_campaign = orgs_affected >= self.config["campaign_threshold"]
        confidence = min(
            0.5 + (external.sighting_count * 0.1) + (orgs_affected * 0.1), 0.99
        )
        correlation = CorrelatedThreat(
            correlation_id=hashlib.sha256(
                f"{internal.indicator_id}{external.indicator_id}".encode()
            ).hexdigest()[:16],
            detection_time=datetime.now(timezone.utc),
            internal_indicators=[internal.indicator_id],
            external_indicators=[external],
            correlation_type="HNDL_MULTI_ORG",
            confidence=confidence,
            organizations_affected=orgs_affected,
            total_data_volume_gb=0.0,
            is_confirmed_campaign=is_campaign,
            campaign_name=(
                f"HNDL-{orgs_affected}ORG-{datetime.now(timezone.utc).strftime('%Y%m')}"
                if is_campaign
                else None
            ),
        )
        self._correlations.append(correlation)
        logger.warning(
            "Cross-org correlation detected: id=%s orgs=%d campaign=%s",
            correlation.correlation_id,
            orgs_affected,
            is_campaign,
        )


# ---------------------------------------------------------------------------
# Unified Risk Assessment Engine
# ---------------------------------------------------------------------------

class HNDLRiskAssessmentEngine:
    """
    Unified HNDL risk assessment engine combining all four sub-engines.

    Provides comprehensive risk assessment rather than binary detection.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.data_scorer = DataValueScorer(self.config.get("data_scoring"))
        self.patience_analyzer = PatiencePatternAnalyzer(self.config.get("patience"))
        self.honeypot_engine = QuantumHoneypotEngine(self.config.get("honeypot"))
        self.correlator = CrossOrgCorrelator(self.config.get("correlation"))

        self._assessment_count = 0
        self._high_risk_count = 0
        self._confirmed_hndl_count = 0

        logger.info("HNDLRiskAssessmentEngine initialized with all sub-engines")

    def assess_flow(self, flow: NetworkFlow) -> Dict[str, Any]:
        """Comprehensive risk assessment for a single flow."""
        self._assessment_count += 1

        risk_score = self.data_scorer.score_flow(flow)
        self.patience_analyzer.record_flow(flow)

        honeypot_event = None
        if hasattr(flow, "payload") and getattr(flow, "payload", None):
            honeypot_event = self.honeypot_engine.check_exfiltration(
                flow.payload, flow.source_ip, flow.dest_ip
            )

        if risk_score.overall_risk in (HarvestRiskLevel.HIGH, HarvestRiskLevel.CRITICAL):
            self._high_risk_count += 1
        if honeypot_event:
            self._confirmed_hndl_count += 1

        return {
            "flow_id": flow.flow_id,
            "risk_assessment": risk_score.to_dict(),
            "honeypot_detection": honeypot_event.__dict__ if honeypot_event else None,
            "assessment_timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def assess_batch(self, flows: List[NetworkFlow]) -> Dict[str, Any]:
        """Assess multiple flows."""
        assessments = [self.assess_flow(f) for f in flows]
        high_risk = [
            a
            for a in assessments
            if a["risk_assessment"]["overall_risk"] in ("HIGH", "CRITICAL")
        ]
        return {
            "total_assessed": len(assessments),
            "high_risk_count": len(high_risk),
            "assessments": assessments,
            "summary": self.data_scorer.get_high_risk_summary(
                [self.data_scorer.score_flow(f) for f in flows]
            ),
        }

    def get_patience_analysis(self) -> List[Dict[str, Any]]:
        indicators = self.patience_analyzer.analyze_all_actors()
        return [
            {
                "actor_ip": i.actor_ip,
                "observation_days": i.observation_days,
                "patience_score": i.patience_score,
                "consistency_score": i.consistency_score,
                "is_suspected_hndl": i.is_suspected_hndl,
                "confidence": i.confidence,
                "total_bytes": i.total_bytes,
                "session_count": i.session_count,
            }
            for i in indicators
        ]

    def get_suspected_hndl_actors(self) -> List[Dict[str, Any]]:
        indicators = self.patience_analyzer.get_suspected_hndl_actors()
        return [
            {
                "actor_ip": i.actor_ip,
                "patience_score": i.patience_score,
                "confidence": i.confidence,
                "observation_days": i.observation_days,
                "total_bytes_gb": i.total_bytes / (1024**3),
            }
            for i in indicators
        ]

    def create_honeypot(self, **kwargs) -> Tuple[str, bytes]:
        return self.honeypot_engine.create_honeypot(**kwargs)

    def get_honeypot_detections(self) -> List[HoneypotEvent]:
        return self.honeypot_engine.get_detections()

    def share_with_isac(self) -> List[Dict[str, Any]]:
        return self.correlator.share_indicators()

    def receive_isac_indicators(self, indicators: List[Dict[str, Any]]) -> int:
        return self.correlator.receive_external_indicators(indicators)

    def get_comprehensive_status(self) -> Dict[str, Any]:
        return {
            "engine_status": "OPERATIONAL",
            "assessment_stats": {
                "total_assessments": self._assessment_count,
                "high_risk_flows": self._high_risk_count,
                "confirmed_hndl": self._confirmed_hndl_count,
            },
            "honeypot_status": self.honeypot_engine.get_honeypot_status(),
            "patience_analysis": {
                "tracked_actors": len(self.patience_analyzer._actor_history),
                "suspected_hndl": len(self.patience_analyzer.get_suspected_hndl_actors()),
            },
            "cross_org_status": self.correlator.get_correlation_summary(),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
