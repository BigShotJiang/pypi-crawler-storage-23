"""
hndl-detect: Detect Harvest Now Decrypt Later attack patterns in network telemetry.

Public API
----------

Detector (signal-based, real-time / hybrid):

    >>> from hndl_detect import HNDLDetector, NetworkSignal, DetectionThresholds
    >>> detector = HNDLDetector(thresholds=DetectionThresholds(volume_threshold_gb=5.0))
    >>> threat = detector.process_network_signal(signal)

Risk assessment (batch, flow-level scoring):

    >>> from hndl_detect import HNDLRiskAssessmentEngine, NetworkFlow
    >>> engine = HNDLRiskAssessmentEngine()
    >>> result = engine.assess_flow(flow)

APT threat detection (batch, APT attribution):

    >>> from hndl_detect import HNDLThreatDetector, NetworkFlowSimple
    >>> td = HNDLThreatDetector()
    >>> threats = td.detect_harvest_attempts(flows)
"""

from .types import (
    # Enums
    SignalType,
    ThreatSeverity,
    ThreatStatus,
    DetectionMode,
    DataClassification,
    CryptoVulnerability,
    HarvestRiskLevel,
    CryptoAlgorithm,
    ThreatIndicator,
    # Dataclasses
    NetworkSignal,
    AccessSignal,
    HNDLThreatProfile,
    DetectionThresholds,
    APTThreatProfile,
    NetworkFlow,
    NetworkFlowSimple,
    HarvestRiskScore,
    PatienceIndicator,
    HoneypotEvent,
    DataAsset,
    ISACIndicator,
    CorrelatedThreat,
)

from .detector import HNDLDetector, ActorProfile

from .risk_assessment import (
    DataValueScorer,
    PatiencePatternAnalyzer,
    QuantumHoneypotEngine,
    CrossOrgCorrelator,
    HNDLRiskAssessmentEngine,
)

from .threat_detector import HNDLThreatDetector

__version__ = "0.1.0"
__author__ = "Brian James Rutherford"

__all__ = [
    # Version
    "__version__",
    # Enums
    "SignalType",
    "ThreatSeverity",
    "ThreatStatus",
    "DetectionMode",
    "DataClassification",
    "CryptoVulnerability",
    "HarvestRiskLevel",
    "CryptoAlgorithm",
    "ThreatIndicator",
    # Dataclasses
    "NetworkSignal",
    "AccessSignal",
    "HNDLThreatProfile",
    "DetectionThresholds",
    "APTThreatProfile",
    "NetworkFlow",
    "NetworkFlowSimple",
    "HarvestRiskScore",
    "PatienceIndicator",
    "HoneypotEvent",
    "DataAsset",
    "ISACIndicator",
    "CorrelatedThreat",
    # Classes
    "HNDLDetector",
    "ActorProfile",
    "DataValueScorer",
    "PatiencePatternAnalyzer",
    "QuantumHoneypotEngine",
    "CrossOrgCorrelator",
    "HNDLRiskAssessmentEngine",
    "HNDLThreatDetector",
]
