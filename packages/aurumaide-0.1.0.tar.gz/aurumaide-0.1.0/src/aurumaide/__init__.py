"""AurumAide — Personal AI assistant."""

__version__ = "0.1.0"
