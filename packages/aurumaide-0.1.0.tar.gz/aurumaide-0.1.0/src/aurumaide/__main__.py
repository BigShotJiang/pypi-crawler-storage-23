"""CLI entry point for aurumaide."""

import argparse
import sys

from aurumaide.google_chat import chat
from aurumaide.utility.logger import initialize

DEFAULT_MODEL = "gemini-2.0-flash"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="aurumaide",
        description="AurumAide — Personal AI assistant",
    )
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help=f"Google AI model to use (default: {DEFAULT_MODEL})",
    )
    parser.add_argument(
        "--one-shot",
        action="store_true",
        help="Answer the query and exit without entering interactive mode",
    )
    parser.add_argument(
        "--file",
        metavar="FILE_PATH",
        help="Read the user query from a file (incompatible with positional arguments)",
    )
    parser.add_argument(
        "arguments",
        nargs="*",
        help="Words that are joined by spaces to form the initial query",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.file and args.arguments:
        parser.error("--file cannot be used together with positional arguments")

    if args.file:
        with open(args.file, encoding="utf-8") as f:
            query = f.read().strip()
    elif args.arguments:
        query = " ".join(args.arguments)
    else:
        query = None

    if args.one_shot and not query:
        parser.error("--one-shot requires a query (provide arguments or --file)")

    initialize()
    chat(model=args.model, query=query, one_shot=args.one_shot)
    return 0


if __name__ == "__main__":
    sys.exit(main())
