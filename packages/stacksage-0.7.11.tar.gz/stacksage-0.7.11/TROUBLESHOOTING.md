# Troubleshooting: AssumeRole Access Denied

## Error
```
RuntimeError: AssumeRole failed for arn:aws:iam::735235878057:role/StackSageAuditorRole: 
An error occurred (AccessDenied) when calling the AssumeRole operation: 
User: arn:aws:iam::022161940349:user/stacksage-admin is not authorized to perform: 
sts:AssumeRole on resource: arn:aws:iam::735235878057:role/StackSageAuditorRole
```

## Root Cause

The **auditor user lacks permission to assume roles**. There are two parts to cross-account role assumption:

1. **Customer Account (735235878057)**: Trust policy allows auditor account to assume the role ✅ **CORRECT**
2. **Auditor Account (022161940349)**: User/role needs permission to assume roles ❌ **MISSING**

Your customer trust policy is correct:
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::022161940349:root"
            },
            "Action": "sts:AssumeRole",
            "Condition": {
                "StringEquals": {
                    "sts:ExternalId": "stacksage-external-id"
                }
            }
        }
    ]
}
```

But the `stacksage-admin` user needs an IAM policy in the **auditor account** that grants `sts:AssumeRole` permission.

## Solution: Attach IAM Policy to Auditor User

### Quick Fix (Automated)

Run the fix script with your auditor account credentials:

```bash
export AWS_ACCESS_KEY_ID=AKIAQKKHUL56RJMXTNMB
export AWS_SECRET_ACCESS_KEY=VNqiWoDcwcQxYaI4BOqgLR71LvK5eytoZ+FMvaJg
export AWS_DEFAULT_REGION=ap-south-1

bash scripts/fix_auditor_permissions.sh
```

This will:
1. Create an IAM policy `StackSageAssumeRolePolicy` (if it doesn't exist)
2. Attach it to the `stacksage-admin` user
3. Test that AssumeRole works

### Manual Fix (AWS Console)

1. **Go to CloudFormation Console** in account `735235878057`
   - URL: https://ap-south-1.console.aws.amazon.com/cloudformation

2. **Update Stack**:
   - Select stack: `StackSage-Detector-Test`
   - Click **"Update"**
   - Choose **"Use current template"**
   - Click **"Next"**

3. **Update Parameters**:
   - **AuditorAccountId**: Change to `022161940349` ← **Your actual auditor account**
   - Click **"Next"** → **"Next"**
   - Check **"I acknowledge that AWS CloudFormation might create IAM resources"**
   - Click **"Submit"**

4. **Wait for Update** (2-3 minutes)
   - Stack status: `UPDATE_IN_PROGRESS` → `UPDATE_COMPLETE`

5. **Re-run the audit**:
   ```bash
   bash scripts/run_audit.sh .env
   ```

---

### Option 2: Manually Update IAM Role Trust Policy

If you can't update the stack, manually fix the trust policy:

1. **Go to IAM Console** in account `735235878057`
   - URL: https://console.aws.amazon.com/iam

2. **Find the Role**:
   - Click **"Roles"**
   - Search for: `StackSageAuditorRole`
   - Click on the role

3. **Edit Trust Policy**:
   - Click **"Trust relationships"** tab
   - Click **"Edit trust policy"**

4. **Update the Principal**:
   
   Change:
   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Effect": "Allow",
         "Principal": {
           "AWS": "arn:aws:iam::WRONG_ACCOUNT_ID:root"
         },
         "Action": "sts:AssumeRole",
         "Condition": {
           "StringEquals": {
             "sts:ExternalId": "stacksage-external-id"
           }
         }
       }
     ]
   }
   ```
   
   To:
   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Effect": "Allow",
         "Principal": {
           "AWS": "arn:aws:iam::022161940349:root"
         },
         "Action": "sts:AssumeRole",
         "Condition": {
           "StringEquals": {
             "sts:ExternalId": "stacksage-external-id"
           }
         }
       }
     ]
   }
   ```

5. **Save Changes**

6. **Re-run the audit**:
   ```bash
   bash scripts/run_audit.sh .env
   ```

---

## Verification

After fixing, verify your credentials can assume the role:

```bash
docker run --rm \
  -e AWS_ACCESS_KEY_ID=AKIAQKKHUL56RJMXTNMB \
  -e AWS_SECRET_ACCESS_KEY=VNqiWoDcwcQxYaI4BOqgLR71LvK5eytoZ+FMvaJg \
  -e AWS_DEFAULT_REGION=ap-south-1 \
  -v "$PWD":/app -w /app \
  stacksage-audit:latest bash -lc \
  "aws sts assume-role \
    --role-arn arn:aws:iam::735235878057:role/StackSageAuditorRole \
    --role-session-name test-session \
    --external-id stacksage-external-id"
```

If successful, you should see temporary credentials in the output.

---

## Summary

- **Your auditor account**: `022161940349`
- **Customer account**: `735235878057`
- **Required action**: Update CloudFormation stack's `AuditorAccountId` parameter to `022161940349`
- **Or**: Manually edit IAM role trust policy to allow `arn:aws:iam::022161940349:root`
