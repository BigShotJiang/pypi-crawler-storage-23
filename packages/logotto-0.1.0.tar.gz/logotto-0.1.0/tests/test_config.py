from logotto.config import load_config


def test_kwargs_take_priority_over_env_vars(monkeypatch):
    monkeypatch.setenv("LOGOTTO_API_KEY", "env-key")
    monkeypatch.setenv("LOGOTTO_APP_NAME", "env-app")
    config = load_config(api_key="kwarg-key", app_name="kwarg-app")
    assert config["api_key"] == "kwarg-key"
    assert config["app_name"] == "kwarg-app"


def test_falls_back_to_env_vars(monkeypatch):
    monkeypatch.setenv("LOGOTTO_API_KEY", "env-key")
    monkeypatch.setenv("LOGOTTO_APP_NAME", "env-app")
    config = load_config()
    assert config["api_key"] == "env-key"
    assert config["app_name"] == "env-app"


def test_default_app_name_when_no_env(monkeypatch):
    monkeypatch.delenv("LOGOTTO_APP_NAME", raising=False)
    config = load_config(api_key="key")
    assert config["app_name"] == "unknown-app"


def test_debug_enabled_via_env(monkeypatch):
    monkeypatch.setenv("LOGOTTO_DEBUG", "1")
    config = load_config()
    assert config["debug"] is True


def test_debug_not_enabled_for_other_values(monkeypatch):
    monkeypatch.setenv("LOGOTTO_DEBUG", "true")
    config = load_config()
    assert config["debug"] is False


def test_debug_false_by_default(monkeypatch):
    monkeypatch.delenv("LOGOTTO_DEBUG", raising=False)
    config = load_config()
    assert config["debug"] is False


def test_debug_kwarg_takes_priority(monkeypatch):
    monkeypatch.delenv("LOGOTTO_DEBUG", raising=False)
    config = load_config(debug=True)
    assert config["debug"] is True
