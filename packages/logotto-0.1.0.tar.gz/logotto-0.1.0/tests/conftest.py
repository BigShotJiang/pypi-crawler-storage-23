import logging
import sys
import pytest
import logotto
from opentelemetry.sdk._logs import LoggingHandler


@pytest.fixture(autouse=True)
def reset_logotto():
    """Reset all logotto and logging state between tests."""
    original_excepthook = sys.excepthook
    original_root_level = logging.getLogger().level

    yield

    # Restore excepthook in case init() replaced it
    sys.excepthook = original_excepthook

    # Shut down and reset module state
    logotto.shutdown()
    logotto._target_logger_name = None
    logotto._original_excepthook = None

    # Remove any logotto handlers added to loggers during the test
    for name, logger in list(logging.Logger.manager.loggerDict.items()):
        if isinstance(logger, logging.Logger):
            logger.handlers = [h for h in logger.handlers if not isinstance(h, LoggingHandler)]
    root = logging.getLogger()
    root.handlers = [h for h in root.handlers if not isinstance(h, LoggingHandler)]
    root.setLevel(original_root_level)
