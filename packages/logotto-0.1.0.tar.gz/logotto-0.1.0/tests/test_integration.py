"""
Integration tests — hit the real Logotto backend.

Requires LOGOTTO_API_KEY to be set (e.g. via .env or shell export).
All tests are skipped automatically when the key is absent, so the
normal unit-test suite stays green without credentials.

Run just these tests:
    pytest tests/test_integration.py -v
"""

import json
import logging
import os
import time
import urllib.error
import urllib.request
import uuid

import pytest

import logotto

# Load .env if python-dotenv is available (installed separately; not a hard dep).
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))
except ImportError:
    pass

API_KEY = os.getenv("LOGOTTO_API_KEY")
BASE_URL = "https://api.logotto.com"
APP_NAME = "logotto-pypi-integration"

pytestmark = pytest.mark.skipif(
    not API_KEY,
    reason="LOGOTTO_API_KEY not set — skipping integration tests",
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fetch_logs(source=None, limit=100):
    url = f"{BASE_URL}/api/logs?limit={limit}"
    if source:
        url += f"&source={source}"
    req = urllib.request.Request(url, headers={"x-api-key": API_KEY})
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read())["logs"]


def _wait_for_marker(marker, source=APP_NAME, timeout=20, interval=2):
    """Poll /api/logs until a message containing *marker* appears."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            logs = _fetch_logs(source=source)
            matched = [l for l in logs if marker in l.get("message", "")]
            if matched:
                return matched
        except Exception:
            pass
        time.sleep(interval)
    return []


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_basic_log_ingestion():
    """An INFO log appears in /api/logs after shutdown."""
    marker = f"basic-{uuid.uuid4()}"

    logotto.init(api_key=API_KEY, app_name=APP_NAME)
    logging.info(marker)
    logotto.shutdown()

    matched = _wait_for_marker(marker)
    assert matched, f"Log with marker '{marker}' not found within timeout"
    assert matched[0]["level"] == "INFO"
    assert matched[0]["source"] == APP_NAME


def test_multiple_levels_all_ingested():
    """INFO, WARNING, and ERROR logs all reach the backend."""
    marker = f"levels-{uuid.uuid4()}"

    logotto.init(api_key=API_KEY, app_name=APP_NAME)
    root = logging.getLogger()
    root.info(f"{marker} INFO")
    root.warning(f"{marker} WARNING")
    root.error(f"{marker} ERROR")
    logotto.shutdown()

    matched = _wait_for_marker(marker)
    assert matched, f"Logs with marker '{marker}' not found within timeout"

    levels = {l["level"] for l in matched}
    assert "INFO" in levels
    assert "WARN" in levels   # OTLP maps Python WARNING → WARN
    assert "ERROR" in levels


def test_invalid_api_key_returns_401():
    """The backend rejects a bogus API key with HTTP 401."""
    payload = json.dumps({"resourceLogs": []}).encode()
    req = urllib.request.Request(
        f"{BASE_URL}/api/ingest",
        data=payload,
        headers={"Content-Type": "application/json", "x-api-key": "logotto_bogus_key"},
        method="POST",
    )
    with pytest.raises(urllib.error.HTTPError) as exc_info:
        urllib.request.urlopen(req, timeout=10)
    assert exc_info.value.code == 401
