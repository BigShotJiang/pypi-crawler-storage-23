import json
import urllib.error
from unittest.mock import MagicMock, patch

from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk._logs.export import LogRecordExportResult

from logotto._exporter import LogottoExporter


def _make_record(body="hello", severity_text="INFO", timestamp=1_000_000_000, trace_id=0, span_id=0):
    """Build a minimal mock ReadableLogRecord."""
    lr = MagicMock()
    lr.body = body
    lr.severity_text = severity_text
    lr.timestamp = timestamp
    lr.observed_timestamp = timestamp + 1000
    lr.severity_number.value = 9
    lr.trace_id = trace_id
    lr.span_id = span_id
    lr.attributes = {}

    record = MagicMock()
    record.log_record = lr
    record.resource = Resource.create({"service.name": "test-svc"})
    return record


def _make_exporter(**kwargs):
    return LogottoExporter("https://api.logotto.com/api/ingest", "test-key", **kwargs)


def _fake_urlopen(request=None, timeout=None):
    """Context manager mock that simulates a successful HTTP response."""
    m = MagicMock()
    m.__enter__ = lambda s: m
    m.__exit__ = MagicMock(return_value=False)
    return m


# --- Basic behaviour ---

def test_empty_batch_returns_success():
    assert _make_exporter().export([]) == LogRecordExportResult.SUCCESS


def test_disabled_exporter_returns_failure():
    exporter = _make_exporter()
    exporter._disabled = True
    assert exporter.export([_make_record()]) == LogRecordExportResult.FAILURE


# --- HTTP success ---

def test_successful_export_returns_success():
    exporter = _make_exporter()
    with patch("urllib.request.urlopen", _fake_urlopen):
        assert exporter.export([_make_record()]) == LogRecordExportResult.SUCCESS


def test_correct_headers_sent():
    exporter = LogottoExporter("https://api.logotto.com/api/ingest", "my-api-key")
    captured = {}

    def fake_urlopen(req, timeout=None):
        captured["headers"] = req.headers
        return _fake_urlopen()

    with patch("urllib.request.urlopen", fake_urlopen):
        exporter.export([_make_record()])

    assert captured["headers"].get("X-api-key") == "my-api-key"
    assert captured["headers"].get("Content-type") == "application/json"


# --- OTLP payload structure ---

def test_otlp_payload_structure():
    exporter = _make_exporter()
    captured = {}

    def fake_urlopen(req, timeout=None):
        captured["payload"] = json.loads(req.data)
        return _fake_urlopen()

    with patch("urllib.request.urlopen", fake_urlopen):
        exporter.export([_make_record(body="hello", severity_text="INFO", timestamp=1_000_000_000)])

    rl = captured["payload"]["resourceLogs"][0]
    assert any(
        a["key"] == "service.name" and a["value"]["stringValue"] == "test-svc"
        for a in rl["resource"]["attributes"]
    )
    sl = rl["scopeLogs"][0]
    assert sl["scope"]["name"] == "logotto"
    log = sl["logRecords"][0]
    assert log["body"]["stringValue"] == "hello"
    assert log["severityText"] == "INFO"
    assert log["timeUnixNano"] == "1000000000"


def test_records_sorted_by_timestamp():
    exporter = _make_exporter()
    shared_resource = Resource.create({"service.name": "test-svc"})
    records = [
        _make_record(body="third", timestamp=3_000),
        _make_record(body="first", timestamp=1_000),
        _make_record(body="second", timestamp=2_000),
    ]
    for r in records:
        r.resource = shared_resource
    captured = {}

    def fake_urlopen(req, timeout=None):
        captured["payload"] = json.loads(req.data)
        return _fake_urlopen()

    with patch("urllib.request.urlopen", fake_urlopen):
        exporter.export(records)

    logs = captured["payload"]["resourceLogs"][0]["scopeLogs"][0]["logRecords"]
    bodies = [l["body"]["stringValue"] for l in logs]
    assert bodies == ["first", "second", "third"]


def test_zero_trace_and_span_ids_become_empty_strings():
    exporter = _make_exporter()
    captured = {}

    def fake_urlopen(req, timeout=None):
        captured["payload"] = json.loads(req.data)
        return _fake_urlopen()

    with patch("urllib.request.urlopen", fake_urlopen):
        exporter.export([_make_record(trace_id=0, span_id=0)])

    log = captured["payload"]["resourceLogs"][0]["scopeLogs"][0]["logRecords"][0]
    assert log["traceId"] == ""
    assert log["spanId"] == ""


def test_nonzero_trace_and_span_ids_formatted_as_hex():
    exporter = _make_exporter()
    captured = {}

    def fake_urlopen(req, timeout=None):
        captured["payload"] = json.loads(req.data)
        return _fake_urlopen()

    with patch("urllib.request.urlopen", fake_urlopen):
        exporter.export([_make_record(trace_id=255, span_id=16)])

    log = captured["payload"]["resourceLogs"][0]["scopeLogs"][0]["logRecords"][0]
    assert log["traceId"] == "0" * 30 + "ff"
    assert log["spanId"] == "0" * 14 + "10"


# --- HTTP errors ---

def test_401_disables_exporter_and_returns_failure():
    exporter = _make_exporter()
    with patch("urllib.request.urlopen", side_effect=urllib.error.HTTPError(None, 401, "Unauthorized", {}, None)):
        result = exporter.export([_make_record()])
    assert result == LogRecordExportResult.FAILURE
    assert exporter._disabled is True


def test_403_disables_exporter_and_returns_failure():
    exporter = _make_exporter()
    with patch("urllib.request.urlopen", side_effect=urllib.error.HTTPError(None, 403, "Forbidden", {}, None)):
        result = exporter.export([_make_record()])
    assert result == LogRecordExportResult.FAILURE
    assert exporter._disabled is True


def test_other_http_error_does_not_disable_exporter():
    exporter = _make_exporter()
    with patch("urllib.request.urlopen", side_effect=urllib.error.HTTPError(None, 500, "Server Error", {}, None)):
        result = exporter.export([_make_record()])
    assert result == LogRecordExportResult.FAILURE
    assert exporter._disabled is False


def test_network_error_returns_failure():
    exporter = _make_exporter()
    with patch("urllib.request.urlopen", side_effect=OSError("Connection refused")):
        result = exporter.export([_make_record()])
    assert result == LogRecordExportResult.FAILURE
    assert exporter._disabled is False


def test_auth_error_printed_to_stderr(capsys):
    exporter = _make_exporter()
    with patch("urllib.request.urlopen", side_effect=urllib.error.HTTPError(None, 401, "Unauthorized", {}, None)):
        exporter.export([_make_record()])
    assert "401" in capsys.readouterr().err


def test_debug_mode_prints_batch_size_on_success(capsys):
    exporter = _make_exporter(debug=True)
    with patch("urllib.request.urlopen", _fake_urlopen):
        exporter.export([_make_record(), _make_record()])
    assert "2" in capsys.readouterr().err
