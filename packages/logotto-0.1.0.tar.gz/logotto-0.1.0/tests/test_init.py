import logging
import sys
import logotto
from opentelemetry.sdk._logs import LoggingHandler


def test_not_initialized_before_init():
    assert not logotto._already_initialized()


def test_missing_api_key_returns_none_and_warns(monkeypatch, capsys):
    monkeypatch.delenv("LOGOTTO_API_KEY", raising=False)
    result = logotto.init(app_name="test")
    assert result is None
    assert not logotto._already_initialized()
    assert "api_key" in capsys.readouterr().err


def test_successful_init_returns_provider(monkeypatch):
    monkeypatch.setenv("LOGOTTO_API_KEY", "test-key")
    result = logotto.init(app_name="test")
    assert result is not None
    assert logotto._already_initialized()


def test_second_init_creates_independent_provider(monkeypatch):
    monkeypatch.setenv("LOGOTTO_API_KEY", "test-key")
    first = logotto.init(app_name="service-a")
    second = logotto.init(app_name="service-b")
    assert first is not second
    assert len(logotto._providers) == 2


def test_shutdown_resets_initialized_state(monkeypatch):
    monkeypatch.setenv("LOGOTTO_API_KEY", "test-key")
    logotto.init(app_name="test")
    assert logotto._already_initialized()
    logotto.shutdown()
    assert not logotto._already_initialized()


def test_shutdown_is_idempotent():
    logotto.shutdown()
    logotto.shutdown()  # should not raise


def test_handler_attached_to_root_logger_by_default(monkeypatch):
    monkeypatch.setenv("LOGOTTO_API_KEY", "test-key")
    logotto.init(app_name="test")
    handlers = logging.getLogger().handlers
    assert any(isinstance(h, LoggingHandler) for h in handlers)


def test_handler_attached_to_specific_logger(monkeypatch):
    monkeypatch.setenv("LOGOTTO_API_KEY", "test-key")
    logotto.init(app_name="test", logger="myapp")
    assert logotto._target_logger_name == "myapp"
    assert any(isinstance(h, LoggingHandler) for h in logging.getLogger("myapp").handlers)
    assert not any(isinstance(h, LoggingHandler) for h in logging.getLogger().handlers)


def test_root_logger_level_raised_to_info(monkeypatch):
    monkeypatch.setenv("LOGOTTO_API_KEY", "test-key")
    logging.getLogger().setLevel(logging.WARNING)
    logotto.init(app_name="test")
    assert logging.getLogger().level <= logging.INFO


def test_root_logger_level_not_lowered(monkeypatch):
    monkeypatch.setenv("LOGOTTO_API_KEY", "test-key")
    logging.getLogger().setLevel(logging.DEBUG)
    logotto.init(app_name="test")
    assert logging.getLogger().level == logging.DEBUG


def test_custom_level_is_respected(monkeypatch):
    monkeypatch.setenv("LOGOTTO_API_KEY", "test-key")
    logotto.init(app_name="test", level=logging.WARNING)
    handler = next(h for h in logging.getLogger().handlers if isinstance(h, LoggingHandler))
    assert handler.level == logging.WARNING


def test_excepthook_is_replaced_after_init(monkeypatch):
    monkeypatch.setenv("LOGOTTO_API_KEY", "test-key")
    original = sys.excepthook
    logotto.init(app_name="test")
    assert sys.excepthook is not original


def test_excepthook_calls_original(monkeypatch):
    monkeypatch.setenv("LOGOTTO_API_KEY", "test-key")
    calls = []
    sys.excepthook = lambda *a: calls.append(a)
    logotto.init(app_name="test")
    sys.excepthook(ValueError, ValueError("test"), None)
    assert len(calls) == 1


def test_debug_mode_prints_init_message(monkeypatch, capsys):
    monkeypatch.setenv("LOGOTTO_API_KEY", "test-key")
    logotto.init(app_name="my-app", debug=True)
    assert "my-app" in capsys.readouterr().err
