# logotto

Ship Python logs to [Logotto](https://logotto.com) with one line.

## Install

```bash
pip install logotto
```

## Quickstart

The fastest path — set your credentials as environment variables and import `logotto.auto`. This attaches a handler to Python's root logger so any existing `logging` calls in your code (and in libraries you use) are automatically captured and forwarded to Logotto. No other changes to your code needed.

```bash
export LOGOTTO_API_KEY=your-api-key
export LOGOTTO_APP_NAME=my-app
```

```python
import logotto.auto
import logging

logging.info("Server started")
logging.error("Something broke")
```

That's it. All `logging` calls are automatically captured and shipped.

## Explicit setup

If you prefer to initialise in code:

```python
import logotto
import logging

logotto.init(api_key="your-api-key", app_name="my-app")

logging.info("Server started")
logging.warning("Something looks off")
logging.error("Something broke")
```

No shutdown call required — logs are flushed automatically when your process exits.

## Environment variables

| Variable | Description | Default |
|---|---|---|
| `LOGOTTO_API_KEY` | Your Logotto API key | — |
| `LOGOTTO_APP_NAME` | Name shown in the dashboard | `unknown-app` |
| `LOGOTTO_DEBUG` | Print debug info to stderr (`1` to enable) | — |

kwargs passed to `init()` take priority over environment variables.

## Advanced

### Target a specific logger

By default the root logger is used, capturing everything. To only capture logs
from a specific logger and its children:

```python
logotto.init(api_key="...", app_name="...", logger="myapp")
```

### Set a minimum log level

By default, `INFO` and above are captured. To change this:

```python
import logging
logotto.init(api_key="...", app_name="...", level=logging.WARNING)
```

### Debug mode

Prints batch sizes and failures to stderr — useful when verifying your setup:

```python
logotto.init(api_key="...", app_name="...", debug=True)
# or: export LOGOTTO_DEBUG=1
```

### Multiple services in one process

You can call `init()` once per service. Each call registers an independent
handler and ships logs under its own `app_name`:

```python
import logotto
import logging

logotto.init(api_key="...", app_name="auth-service",    logger="auth")
logotto.init(api_key="...", app_name="payment-service", logger="payment")

logging.getLogger("auth").info("User logged in")
logging.getLogger("payment").info("Payment processed")
```

Named loggers don't propagate to the root logger, so the two services don't
interfere with each other.

### Explicit shutdown

Not required, but available if you need to flush before your process exits
on its own (e.g. in a long-running background service):

```python
logotto.shutdown()
```
