import atexit
import logging
import sys
import traceback

from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from opentelemetry.sdk.resources import Resource

from ._exporter import LogottoExporter
from .config import load_config

_providers = []
_original_excepthook = None
_target_logger_name = None


def _already_initialized() -> bool:
    """Return True if at least one provider has been registered."""
    return bool(_providers)


def init(
    api_key=None,
    app_name=None,
    endpoint="https://api.logotto.com",
    level=None,
    debug=False,
    logger=None,
):
    global _original_excepthook, _target_logger_name

    config = load_config(api_key=api_key, app_name=app_name, debug=debug)

    if not config["api_key"]:
        print(
            "[logotto] no api_key provided and LOGOTTO_API_KEY not set — logs will not be sent.",
            file=sys.stderr,
        )
        return None

    resource = Resource.create({"service.name": config["app_name"]})
    provider = LoggerProvider(resource=resource)
    _providers.append(provider)

    exporter = LogottoExporter(endpoint + "/api/ingest", config["api_key"], debug=config["debug"])
    provider.add_log_record_processor(BatchLogRecordProcessor(exporter))

    otel_handler = LoggingHandler(logger_provider=provider)
    effective_level = level if level is not None else logging.INFO
    otel_handler.setLevel(effective_level)

    _target_logger_name = logger
    target_logger = logging.getLogger(logger)  # None → root logger
    target_logger.propagate = logger is not None  # named loggers shouldn't bubble to root
    if target_logger.level == logging.NOTSET or target_logger.level > effective_level:
        target_logger.setLevel(effective_level)
    target_logger.addHandler(otel_handler)

    # Exception hook and atexit — set up once only
    if _original_excepthook is None:
        _original_excepthook = sys.excepthook

        def _excepthook(exc_type, exc_value, exc_traceback):
            capture_exception(exc_value)
            _original_excepthook(exc_type, exc_value, exc_traceback)

        sys.excepthook = _excepthook
        atexit.register(shutdown)

    if config["debug"]:
        print(f"[logotto] initialized for '{config['app_name']}'", file=sys.stderr)

    return provider


def capture_exception(exc):
    """Manually capture and ship an exception."""
    msg = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    logging.getLogger(_target_logger_name).error(msg)


def shutdown():
    global _providers
    for provider in _providers:
        provider.force_flush()
        provider.shutdown()
    _providers = []
