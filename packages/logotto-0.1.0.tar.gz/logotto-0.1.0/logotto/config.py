import os


def load_config(api_key=None, app_name=None, debug=False):
    return {
        "api_key": api_key or os.getenv("LOGOTTO_API_KEY"),
        "app_name": app_name or os.getenv("LOGOTTO_APP_NAME", "unknown-app"),
        "debug": debug or os.getenv("LOGOTTO_DEBUG") == "1",
    }
