import json
import sys
import urllib.request
import urllib.error
from typing import Sequence

from opentelemetry.sdk._logs.export import LogRecordExporter, LogRecordExportResult
from opentelemetry.sdk._logs import ReadableLogRecord


def _attr_to_otlp(key: str, value) -> dict:
    if isinstance(value, bool):
        return {"key": key, "value": {"boolValue": value}}
    elif isinstance(value, int):
        return {"key": key, "value": {"intValue": str(value)}}
    elif isinstance(value, float):
        return {"key": key, "value": {"doubleValue": value}}
    else:
        return {"key": key, "value": {"stringValue": str(value)}}


def _format_trace_id(trace_id: int) -> str:
    if not trace_id:
        return ""
    return format(trace_id, "032x")


def _format_span_id(span_id: int) -> str:
    if not span_id:
        return ""
    return format(span_id, "016x")


def _record_to_otlp(record: ReadableLogRecord) -> dict:
    lr = record.log_record
    body = lr.body if lr.body is not None else ""
    severity_text = lr.severity_text or ""

    log_record = {
        "timeUnixNano": str(lr.timestamp) if lr.timestamp else "0",
        "observedTimeUnixNano": str(lr.observed_timestamp) if lr.observed_timestamp else "0",
        "severityNumber": lr.severity_number.value if lr.severity_number else 0,
        "severityText": severity_text,
        "body": {"stringValue": str(body)},
        "traceId": _format_trace_id(lr.trace_id),
        "spanId": _format_span_id(lr.span_id),
    }

    if lr.attributes:
        log_record["attributes"] = [
            _attr_to_otlp(k, v) for k, v in lr.attributes.items()
        ]

    return log_record


class LogottoExporter(LogRecordExporter):
    def __init__(self, endpoint: str, api_key: str, debug: bool = False):
        self._endpoint = endpoint
        self._api_key = api_key
        self._disabled = False
        self._debug = debug

    def export(self, batch: Sequence[ReadableLogRecord]) -> LogRecordExportResult:
        if self._disabled:
            return LogRecordExportResult.FAILURE
        if not batch:
            return LogRecordExportResult.SUCCESS

        try:
            # Group records by resource
            resource_map: dict = {}
            for record in batch:
                resource = record.resource
                resource_key = id(resource)
                if resource_key not in resource_map:
                    resource_map[resource_key] = {
                        "resource": resource,
                        "records": [],
                    }
                resource_map[resource_key]["records"].append(record)

            resource_logs = []
            for entry in resource_map.values():
                resource = entry["resource"]
                resource_attrs = [
                    _attr_to_otlp(k, v)
                    for k, v in (resource.attributes or {}).items()
                ]
                sorted_records = sorted(
                    entry["records"],
                    key=lambda r: (r.log_record.timestamp or 0, r.log_record.observed_timestamp or 0),
                )
                log_records_otlp = [_record_to_otlp(r) for r in sorted_records]
                resource_logs.append({
                    "resource": {"attributes": resource_attrs},
                    "scopeLogs": [{
                        "scope": {"name": "logotto"},
                        "logRecords": log_records_otlp,
                    }],
                })

            body = {"resourceLogs": resource_logs}
            payload = json.dumps(body).encode("utf-8")
        except Exception as e:
            print(f"[logotto] serialisation error: {e}", file=sys.stderr)
            return LogRecordExportResult.FAILURE

        try:
            req = urllib.request.Request(
                self._endpoint,
                data=payload,
                headers={
                    "Content-Type": "application/json",
                    "x-api-key": self._api_key,
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10):
                pass

            if self._debug:
                print(f"[logotto] sent batch of {len(batch)} records", file=sys.stderr)
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                self._disabled = True
                print(
                    f"\n[logotto] AUTHENTICATION ERROR (HTTP {e.code}): invalid API key. "
                    "No further logs will be sent. "
                    "Check the api_key passed to logotto.init().\n",
                    file=sys.stderr,
                )
            else:
                print(f"[logotto] export failed: HTTP {e.code} {e.reason}", file=sys.stderr)
            return LogRecordExportResult.FAILURE
        except Exception as e:
            print(f"[logotto] export failed: {e}", file=sys.stderr)
            return LogRecordExportResult.FAILURE

        return LogRecordExportResult.SUCCESS

    def shutdown(self):
        pass  # no persistent connections or buffers to clean up
