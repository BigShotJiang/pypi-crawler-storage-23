"""Services used to test global service-registry behavior."""

