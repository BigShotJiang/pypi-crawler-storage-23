
# Three-Way Comparison: Tool Calling Approaches

**Query:** "Show me SUVs under 15 lakhs with good mileage (above 15 kmpl) that are available in Delhi."

**Date:** 2026-02-28 19:31:05

## Summary Table

| Metric | Traditional | ez-ptc (no chaining) | ez-ptc (with chaining) | Best |
|--------|-------------|----------------------|------------------------|------|
| **LLM Turns** | 9 | 4 | 2 | S3 |
| **Tool Calls** | 0 | 0 | 0 | S1 |
| **Total Tokens** | 4,402 | 2,666 | 1,327 | S3 |
| **Input Tokens** | 4,035 | 2,241 | 965 | - |
| **Output Tokens** | 367 | 425 | 362 | - |
| **Execution Time** | 17.42s | 11.52s | 7.89s | S3 |

## Detailed Analysis

### Scenario 1: Traditional Tool Calling
**Approach:** Pydantic AI with individual tool functions

**How it works:**
- LLM calls each tool individually
- Each tool call requires a separate round-trip
- LLM must synthesize all results at the end

**Results:**
- LLM Turns: 9
- Tool Calls: 0
- Total Tokens: 4,402
- Time: 17.42s

### Scenario 2: ez-ptc WITHOUT Tool Chaining
**Approach:** ez-ptc with `assist_tool_chaining=False`

**How it works:**
- LLM writes Python code to orchestrate tools
- Toolkit doesn't document return types in detail
- Single execution of generated code

**Results:**
- LLM Turns: 4
- Tool Calls: 0
- Total Tokens: 2,666
- Time: 11.52s

### Scenario 3: ez-ptc WITH Tool Chaining
**Approach:** ez-ptc with `assist_tool_chaining=True`

**How it works:**
- LLM writes Python code to orchestrate tools
- Toolkit documents exact return types (enables chaining)
- LLM can filter/transform data between tool calls
- Single execution of generated code

**Results:**
- LLM Turns: 2
- Tool Calls: 0
- Total Tokens: 1,327
- Time: 7.89s

## Key Improvements

### ez-ptc (with chaining) vs Traditional:
- **77.8%** fewer LLM turns
- **69.9%** fewer tokens
- **54.7%** faster execution

### ez-ptc (with chaining) vs ez-ptc (no chaining):
- **50.0%** fewer LLM turns
- **50.2%** fewer tokens
- **31.5%** faster execution time

## Conversation Flow

### Scenario 1: Traditional (Turn-by-Turn)
```
Turn 1: User asks query
Turn 2: LLM calls search_cars()
Turn 3: LLM calls get_specs() for each car
Turn 4: LLM calls check_availability() for each car
Turn 5: LLM synthesizes final response
```

### Scenario 2 & 3: ez-ptc (Programmatic)
```
Turn 1: User asks query
Turn 2: LLM generates orchestration code
  - Code executes: search_cars()
  - Code executes: get_specs() for filtered cars
  - Code executes: check_availability() for filtered cars
  - Code returns filtered results
Turn 3: LLM presents final response
```

## Conclusion

**Winner:** Scenario 3 (ez-ptc with tool chaining)

The key advantage of ez-ptc with tool chaining is that it:
1. Reduces LLM round-trips significantly
2. Enables programmatic filtering between tool calls
3. Returns only relevant data (selective output)
4. Saves tokens and reduces latency

Tool chaining documentation helps the LLM understand exact return types, enabling better code generation and data manipulation.
