
# Three-Way Comparison: Tool Calling Approaches

**Query:** "SUVs with mileage >15 kmpl, available in Delhi with specs and dealer availability."

**Date:** 2026-02-28 20:33:27

## Summary Table

| Metric | Traditional | ez-ptc (no chaining) | ez-ptc (with chaining) | Best |
|--------|-------------|----------------------|------------------------|------|
| **LLM Turns** | 4 | 2 | 2 | S3 |
| **Tool Calls** | 0 | 0 | 0 | S1 |
| **Total Tokens** | 5,708 | 3,627 | 2,498 | S3 |
| **Input Tokens** | 4,470 | 1,783 | 1,736 | - |
| **Output Tokens** | 1,238 | 1,844 | 762 | - |
| **Execution Time** | 13.48s | 27.45s | 9.04s | S3 |

## Detailed Analysis

### Scenario 1: Traditional Tool Calling
**Approach:** Pydantic AI with individual tool functions

**How it works:**
- LLM calls each tool individually
- Each tool call requires a separate round-trip
- LLM must synthesize all results at the end

**Results:**
- LLM Turns: 4
- Tool Calls: 0
- Total Tokens: 5,708
- Time: 13.48s

### Scenario 2: ez-ptc WITHOUT Tool Chaining
**Approach:** ez-ptc with `assist_tool_chaining=False`

**How it works:**
- LLM writes Python code to orchestrate tools
- Toolkit doesn't document return types in detail
- Single execution of generated code

**Results:**
- LLM Turns: 2
- Tool Calls: 0
- Total Tokens: 3,627
- Time: 27.45s

### Scenario 3: ez-ptc WITH Tool Chaining
**Approach:** ez-ptc with `assist_tool_chaining=True`

**How it works:**
- LLM writes Python code to orchestrate tools
- Toolkit documents exact return types (enables chaining)
- LLM can filter/transform data between tool calls
- Single execution of generated code

**Results:**
- LLM Turns: 2
- Tool Calls: 0
- Total Tokens: 2,498
- Time: 9.04s

## Key Improvements

### ez-ptc (with chaining) vs Traditional:
- **50.0%** fewer LLM turns
- **56.2%** fewer tokens
- **32.9%** faster execution

### ez-ptc (with chaining) vs ez-ptc (no chaining):
- **0.0%** more LLM turns
- **31.1%** fewer tokens
- **67.1%** faster execution time

## Conclusion

**Winner:** Scenario 3 (ez-ptc with tool chaining)

The key advantage of ez-ptc with tool chaining is that it:
1. Reduces LLM round-trips significantly
2. Enables programmatic filtering between tool calls
3. Returns only relevant data (selective output)
4. Saves tokens and reduces latency

Tool chaining documentation helps the LLM understand exact return types, enabling better code generation and data manipulation.
