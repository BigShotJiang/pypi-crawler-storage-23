
# Three-Way Comparison: Tool Calling Approaches

**Query:** "SUVs with mileage >15 kmpl, available in Delhi with specs and dealer availability."

**Date:** 2026-02-28 23:35:53

## Summary Table

| Metric | Traditional | ez-ptc (no chaining) | ez-ptc (with chaining) | Best |
|--------|-------------|----------------------|------------------------|------|
| **LLM Turns** | 4 | 3 | 2 | S3 |
| **Tool Calls** | 0 | 0 | 0 | S1 |
| **Total Tokens** | 5,619 | 3,273 | 2,604 | S3 |
| **Input Tokens** | 4,470 | 2,833 | 1,760 | - |
| **Output Tokens** | 1,149 | 440 | 844 | - |
| **Execution Time** | 11.26s | 5.61s | 5.73s | S2 |

## Detailed Analysis

### Scenario 1: Traditional Tool Calling
**Approach:** Pydantic AI with individual tool functions

**How it works:**
- LLM calls each tool individually
- Each tool call requires a separate round-trip
- LLM must synthesize all results at the end

**Results:**
- LLM Turns: 4
- Tool Calls: 0
- Total Tokens: 5,619
- Time: 11.26s

**LLM-Generated Code:**

**Turn 1:**

```python
search_cars(body_type="SUV")
```

**Turn 2:**

```python
get_specs(car_id="suv_001")
get_specs(car_id="suv_002")
get_specs(car_id="suv_003")
get_specs(car_id="suv_004")
get_specs(car_id="suv_005")
get_specs(car_id="suv_006")
get_specs(car_id="suv_007")
get_specs(car_id="suv_008")
get_specs(car_id="suv_009")
get_specs(car_id="suv_010")
get_specs(car_id="suv_011")
get_specs(car_id="suv_012")
get_specs(car_id="suv_013")
get_specs(car_id="suv_014")
get_specs(car_id="suv_015")
```

**Turn 3:**

```python
check_availability(car_id="suv_001", city="Delhi")
check_availability(car_id="suv_002", city="Delhi")
check_availability(car_id="suv_004", city="Delhi")
check_availability(car_id="suv_005", city="Delhi")
check_availability(car_id="suv_006", city="Delhi")
check_availability(car_id="suv_007", city="Delhi")
check_availability(car_id="suv_010", city="Delhi")
check_availability(car_id="suv_011", city="Delhi")
check_availability(car_id="suv_012", city="Delhi")
check_availability(car_id="suv_015", city="Delhi")
```

### Scenario 2: ez-ptc WITHOUT Tool Chaining
**Approach:** ez-ptc with `assist_tool_chaining=False`

**How it works:**
- LLM writes Python code to orchestrate tools
- Toolkit doesn't document return types in detail
- Single execution of generated code

**Results:**
- LLM Turns: 3
- Tool Calls: 0
- Total Tokens: 3,273
- Time: 5.61s

**LLM-Generated Code:**

**Turn 1:**

```python
from typing import List

results = search_cars('SUV')

filtered = []
for car in results:
    try:
        specs = get_specs(car.id)
        if getattr(specs, 'mileage', None) and specs.mileage > 15:
            availability = check_availability(car.id, 'Delhi')
            filtered.append({
                'car': car,
                'specs': specs,
                'availability': availability
            })
    except Exception as e:
        print('Error processing car', car, e)

print(filtered)

```

**Turn 2:**

```python
results = search_cars('SUV')

filtered = []
for car in results:
    car_id = car.get('car_id')
    specs = get_specs(car_id)
    mileage = specs.get('mileage') if isinstance(specs, dict) else getattr(specs, 'mileage', None)
    if mileage and mileage > 15:
        availability = check_availability(car_id, 'Delhi')
        filtered.append({
            'car': car,
            'specs': specs,
            'availability': availability
        })

print(filtered)

```

### Scenario 3: ez-ptc WITH Tool Chaining
**Approach:** ez-ptc with `assist_tool_chaining=True`

**How it works:**
- LLM writes Python code to orchestrate tools
- Toolkit documents exact return types (enables chaining)
- LLM can filter/transform data between tool calls
- Single execution of generated code

**Results:**
- LLM Turns: 2
- Tool Calls: 0
- Total Tokens: 2,604
- Time: 5.73s

**LLM-Generated Code:**

```python
from typing import List

# Step 1: search all SUVs
suvs = search_cars('SUV')

# Step 2: filter by mileage >15 kmpl by fetching specs
results = []
for car in suvs:
    specs = get_specs(car['car_id'])
    if specs['kmpl'] > 15:
        avail = check_availability(car['car_id'], 'Delhi')
        if avail['available']:
            results.append({
                'car_id': car['car_id'],
                'name': car['name'],
                'price': car['price'],
                'body_type': car['body_type'],
                'specs': specs,
                'availability': avail
            })

print(results)
```

## Key Improvements

### ez-ptc (with chaining) vs Traditional:
- **50.0%** fewer LLM turns
- **53.7%** fewer tokens
- **49.1%** faster execution

### ez-ptc (with chaining) vs ez-ptc (no chaining):
- **33.3%** fewer LLM turns
- **20.4%** fewer tokens
- **2.1%** slower execution time

## Conclusion

**Winner:** Scenario 3 (ez-ptc with tool chaining)

The key advantage of ez-ptc with tool chaining is that it:
1. Reduces LLM round-trips significantly
2. Enables programmatic filtering between tool calls
3. Returns only relevant data (selective output)
4. Saves tokens and reduces latency

Tool chaining documentation helps the LLM understand exact return types, enabling better code generation and data manipulation.
