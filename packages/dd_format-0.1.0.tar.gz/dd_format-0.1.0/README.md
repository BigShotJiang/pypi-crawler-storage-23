# dd-format
Abstraction layer for formatting document from markdown to others such as html, pdf
