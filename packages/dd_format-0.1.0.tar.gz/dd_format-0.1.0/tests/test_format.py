"""Basic tests for dd-format writers."""

import os
import tempfile
from pathlib import Path

from dd_format.pdf_writer import markdown_to_pdf
from dd_format.html_writer import markdown_to_html

SAMPLE_MD = """\
# Test Document

## Section One

This is a **bold** paragraph with `inline code`.

- Item one
- Item two

### Subsection

```
code block here
```

---

Regular paragraph.
"""


def test_markdown_to_pdf():
    fd, path = tempfile.mkstemp(suffix=".pdf")
    os.close(fd)
    try:
        out = markdown_to_pdf(SAMPLE_MD, path, title="Test")
        assert out.exists()
        assert out.stat().st_size > 0
    finally:
        Path(path).unlink(missing_ok=True)


def test_markdown_to_html():
    fd, path = tempfile.mkstemp(suffix=".html")
    os.close(fd)
    try:
        out = markdown_to_html(SAMPLE_MD, path, title="Test")
        assert out.exists()
        content = out.read_text()
        assert "<h1>" in content
        assert "<strong>bold</strong>" in content
        assert "<code>inline code</code>" in content
        assert "<li>" in content
        assert "<pre>" in content
    finally:
        Path(path).unlink(missing_ok=True)


def test_html_no_title():
    fd, path = tempfile.mkstemp(suffix=".html")
    os.close(fd)
    try:
        out = markdown_to_html("# Hello", path)
        content = out.read_text()
        assert "<title>Document</title>" in content
    finally:
        Path(path).unlink(missing_ok=True)
