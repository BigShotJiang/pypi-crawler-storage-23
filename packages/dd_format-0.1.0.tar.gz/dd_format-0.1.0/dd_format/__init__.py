"""dd-format: convert markdown to PDF, DOCX, and HTML."""

from dd_format.pdf_writer import markdown_to_pdf
from dd_format.html_writer import markdown_to_html

__all__ = ["markdown_to_pdf", "markdown_to_html", "markdown_to_docx"]
__version__ = "0.1.0"


def markdown_to_docx(md_text: str, output_path: str, title: str = ""):
    """Lazy import — requires ``pip install dd-format[docx]``."""
    from dd_format.docx_writer import markdown_to_docx as _impl
    return _impl(md_text, output_path, title=title)
