"""Convert markdown text to a self-contained HTML file."""

from __future__ import annotations

import html
from pathlib import Path

_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<style>
:root {{
    --bg: #0f1117; --card: #1a1d27; --accent: #4f8ef7;
    --text: #e0e0e0; --sub: #9ca3af; --border: #2d3148;
}}
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{
    background: var(--bg); color: var(--text);
    font-family: 'Segoe UI', system-ui, sans-serif;
    padding: 2rem; max-width: 800px; margin: 0 auto;
    line-height: 1.7;
}}
h1 {{ font-size: 1.8rem; color: var(--accent); margin: 1.5rem 0 0.5rem; }}
h2 {{ font-size: 1.4rem; color: var(--accent); margin: 1.2rem 0 0.4rem; }}
h3 {{ font-size: 1.1rem; color: var(--accent); margin: 1rem 0 0.3rem; }}
p  {{ margin: 0.5rem 0; }}
ul {{ padding-left: 1.5rem; margin: 0.5rem 0; }}
li {{ margin: 0.2rem 0; }}
pre {{
    background: var(--card); border: 1px solid var(--border);
    border-radius: 8px; padding: 1rem; overflow-x: auto;
    font-family: 'Cascadia Code', 'Fira Code', monospace; font-size: 0.88rem;
    margin: 0.8rem 0;
}}
code {{
    background: var(--card); padding: 0.15rem 0.4rem; border-radius: 4px;
    font-family: 'Cascadia Code', 'Fira Code', monospace; font-size: 0.88rem;
}}
strong {{ color: #fff; }}
hr {{ border: none; border-top: 1px solid var(--border); margin: 1.5rem 0; }}
</style>
</head>
<body>
{body}
</body>
</html>"""


def markdown_to_html(md_text: str, output_path: str, title: str = "") -> Path:
    """Convert simple markdown to a dark-mode, self-contained HTML file.

    Supports: headings, bold, code spans, fenced code blocks,
    bullet lists, horizontal rules, and paragraphs.

    Parameters
    ----------
    md_text : str
        Markdown-formatted text.
    output_path : str
        Destination file path.
    title : str, optional
        HTML ``<title>`` value (defaults to "Document").

    Returns
    -------
    Path
        The output file path.
    """
    lines = md_text.split("\n")
    out: list[str] = []
    in_code = False
    in_list = False

    for line in lines:
        stripped = line.strip()

        # Fenced code blocks
        if stripped.startswith("```"):
            if in_code:
                out.append("</pre>")
            else:
                if in_list:
                    out.append("</ul>")
                    in_list = False
                out.append("<pre>")
            in_code = not in_code
            continue
        if in_code:
            out.append(html.escape(line))
            continue

        if not stripped:
            if in_list:
                out.append("</ul>")
                in_list = False
            continue

        # Horizontal rule
        if stripped in ("---", "***", "___"):
            if in_list:
                out.append("</ul>")
                in_list = False
            out.append("<hr>")
            continue

        # Headings
        if stripped.startswith("### "):
            if in_list:
                out.append("</ul>")
                in_list = False
            out.append(f"<h3>{_inline(stripped[4:])}</h3>")
        elif stripped.startswith("## "):
            if in_list:
                out.append("</ul>")
                in_list = False
            out.append(f"<h2>{_inline(stripped[3:])}</h2>")
        elif stripped.startswith("# "):
            if in_list:
                out.append("</ul>")
                in_list = False
            out.append(f"<h1>{_inline(stripped[2:])}</h1>")
        # Bullet lists
        elif stripped.startswith("- ") or stripped.startswith("* "):
            if not in_list:
                out.append("<ul>")
                in_list = True
            out.append(f"<li>{_inline(stripped[2:])}</li>")
        # Paragraphs
        else:
            if in_list:
                out.append("</ul>")
                in_list = False
            out.append(f"<p>{_inline(stripped)}</p>")

    if in_list:
        out.append("</ul>")
    if in_code:
        out.append("</pre>")

    body = "\n".join(out)
    doc_title = html.escape(title or "Document")
    result = _TEMPLATE.format(title=doc_title, body=body)

    p = Path(output_path)
    p.write_text(result, encoding="utf-8")
    return p


def _inline(text: str) -> str:
    """Process inline markdown: **bold**, `code`, and escape HTML."""
    import re

    # Escape HTML first, then apply markdown formatting
    text = html.escape(text)
    # Bold
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    # Code spans
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    return text
