"""dd-format CLI: convert markdown files to PDF, DOCX, or HTML."""

from __future__ import annotations

import sys
from pathlib import Path

import click


@click.command()
@click.argument("source", type=click.Path(exists=True))
@click.option(
    "--format",
    "out_fmt",
    type=click.Choice(["pdf", "html", "docx"]),
    default="pdf",
    show_default=True,
    help="Output format.",
)
@click.option(
    "--out",
    default="",
    help="Output file path (default: <source>.<format>).",
)
@click.option(
    "--title",
    default="",
    help="Document title.",
)
def main(source: str, out_fmt: str, out: str, title: str) -> None:
    """Convert a markdown file to PDF, DOCX, or HTML.

    \b
    Examples:
      dd-format notes.md
      dd-format notes.md --format html --out notes.html
      dd-format notes.md --format docx --title "My Notes"
    """
    src = Path(source)
    md_text = src.read_text(encoding="utf-8")

    if not out:
        out = str(src.with_suffix(f".{out_fmt}"))

    if out_fmt == "pdf":
        from dd_format.pdf_writer import markdown_to_pdf
        markdown_to_pdf(md_text, out, title=title)
    elif out_fmt == "html":
        from dd_format.html_writer import markdown_to_html
        markdown_to_html(md_text, out, title=title)
    elif out_fmt == "docx":
        try:
            from dd_format.docx_writer import markdown_to_docx
        except ImportError:
            click.echo(
                "Error: python-docx is required for DOCX output.\n"
                "Install it with: pip install dd-format[docx]",
                err=True,
            )
            sys.exit(1)
        markdown_to_docx(md_text, out, title=title)

    click.echo(f"Written: {out}")


if __name__ == "__main__":
    main()
