from __future__ import annotations

import copy
import io
from contextlib import redirect_stdout
from typing import Any, Dict, List

import numpy as np
import torch
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval


class COCODetectionEvaluator:
    """Evaluate object-detection predictions with COCO mAP metrics.

    Wraps ``pycocotools.cocoeval.COCOeval`` and returns a clean dict of
    scalar metrics that can be logged directly.
    """

    def evaluate(
        self,
        y_pred: List[Dict[str, torch.Tensor]],
        y_true: List[Dict[str, torch.Tensor]],
    ) -> Dict[str, float]:
        """Compute COCO detection metrics.

        Parameters
        ----------
        y_pred : list[dict]
            One dict per image with keys:

            * ``"boxes"``  – ``FloatTensor[N, 4]`` in ``[x1, y1, x2, y2]``
            * ``"scores"`` – ``FloatTensor[N]``
            * ``"labels"`` – ``LongTensor[N]``

        y_true : list[dict]
            One dict per image with keys:

            * ``"boxes"``  – ``FloatTensor[N, 4]`` in ``[x1, y1, x2, y2]``
            * ``"labels"`` – ``LongTensor[N]``
            * ``"area"``   – ``FloatTensor[N]``
            * ``"image_id"`` – ``int``

        Returns
        -------
        dict[str, float]
            Keys: ``mAP``, ``mAP_50``, ``mAP_75``, ``mAP_small``,
            ``mAP_medium``, ``mAP_large``, ``mAR_1``, ``mAR_10``,
            ``mAR_100``, ``mAR_small``, ``mAR_medium``, ``mAR_large``.
        """
        if len(y_pred) != len(y_true):
            raise ValueError(
                f"y_pred has {len(y_pred)} images but y_true has {len(y_true)}"
            )
        if len(y_pred) == 0:
            return {k: 0.0 for k in _METRIC_NAMES}

        # Suppress all pycocotools console output
        with redirect_stdout(io.StringIO()):
            coco_gt = self._build_coco_gt(y_true)
            coco_dt = self._build_coco_dt(coco_gt, y_pred, y_true)
            coco_eval = COCOeval(coco_gt, coco_dt, iouType="bbox")
            coco_eval.evaluate()
            coco_eval.accumulate()
            coco_eval.summarize()

        stats = coco_eval.stats  # numpy array of length 12
        return {name: float(stats[i]) for i, name in enumerate(_METRIC_NAMES)}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_coco_gt(y_true: List[Dict[str, Any]]) -> COCO:
        """Build a pycocotools COCO object from ground-truth dicts."""
        images = []
        annotations = []
        ann_id = 1
        category_ids: set = set()

        for gt in y_true:
            image_id = int(gt["image_id"])
            images.append({"id": image_id, "width": 0, "height": 0})

            boxes = gt["boxes"]
            labels = gt["labels"]
            areas = gt.get("area", None)

            if isinstance(boxes, torch.Tensor):
                boxes = boxes.cpu().numpy()
            if isinstance(labels, torch.Tensor):
                labels = labels.cpu().numpy()
            if areas is not None and isinstance(areas, torch.Tensor):
                areas = areas.cpu().numpy()

            for j in range(len(boxes)):
                x1, y1, x2, y2 = boxes[j]
                w, h = x2 - x1, y2 - y1
                area = float(areas[j]) if areas is not None else float(w * h)
                cat_id = int(labels[j])
                category_ids.add(cat_id)
                annotations.append(
                    {
                        "id": ann_id,
                        "image_id": image_id,
                        "category_id": cat_id,
                        "bbox": [float(x1), float(y1), float(w), float(h)],
                        "area": area,
                        "iscrowd": 0,
                    }
                )
                ann_id += 1

        categories = [{"id": cid} for cid in sorted(category_ids)]

        dataset_dict: Dict[str, Any] = {
            "images": images,
            "annotations": annotations,
            "categories": categories,
        }

        coco_gt = COCO()
        coco_gt.dataset = dataset_dict
        coco_gt.createIndex()
        return coco_gt

    @staticmethod
    def _build_coco_dt(
        coco_gt: COCO,
        y_pred: List[Dict[str, Any]],
        y_true: List[Dict[str, Any]],
    ) -> COCO:
        """Build a COCO results object from prediction dicts."""
        results: List[Dict[str, Any]] = []

        for pred, gt in zip(y_pred, y_true):
            image_id = int(gt["image_id"])

            boxes = pred["boxes"]
            scores = pred["scores"]
            labels = pred["labels"]

            if isinstance(boxes, torch.Tensor):
                boxes = boxes.cpu().numpy()
            if isinstance(scores, torch.Tensor):
                scores = scores.cpu().numpy()
            if isinstance(labels, torch.Tensor):
                labels = labels.cpu().numpy()

            for j in range(len(boxes)):
                x1, y1, x2, y2 = boxes[j]
                w, h = x2 - x1, y2 - y1
                results.append(
                    {
                        "image_id": image_id,
                        "category_id": int(labels[j]),
                        "bbox": [float(x1), float(y1), float(w), float(h)],
                        "score": float(scores[j]),
                    }
                )

        if not results:
            return _empty_coco_dt(coco_gt)

        return coco_gt.loadRes(results)


# Ordered to match pycocotools COCOeval.stats indices
_METRIC_NAMES = [
    "mAP",
    "mAP_50",
    "mAP_75",
    "mAP_small",
    "mAP_medium",
    "mAP_large",
    "mAR_1",
    "mAR_10",
    "mAR_100",
    "mAR_small",
    "mAR_medium",
    "mAR_large",
]


def _empty_coco_dt(coco_gt: COCO) -> COCO:
    """Return a COCO result object with zero detections."""
    coco_dt = COCO()
    coco_dt.dataset = copy.deepcopy(coco_gt.dataset)
    coco_dt.dataset["annotations"] = []
    coco_dt.createIndex()
    return coco_dt
