HF_REPO_ID = "aadityabuilds/tree-distribution-shift"

DEFAULT_SPLITS = ["train", "val", "ood_test"]

METADATA_FIELDS = ["country", "state", "zone", "region", "biome"]

AVAILABLE_CONFIGS = [
    "intl_train_IN__ood_US",
    "intl_train_US__ood_IN",
    "biome_Rajasthan_train_WET__ood_DRY",
    "biome_Rajasthan_train_DRY__ood_WET",
    "biome_Karnataka_train_WET__ood_DRY",
    "biome_Karnataka_train_DRY__ood_WET",
    "region_train_North__ood_South",
    "region_train_South__ood_North",
]

SPLIT_DESCRIPTIONS = {
    "train": "90% of the in-distribution pool (training)",
    "val": "10% held-out from the in-distribution pool (validation)",
    "ood_test": "Held-out portion from the out-of-distribution pool",
}
