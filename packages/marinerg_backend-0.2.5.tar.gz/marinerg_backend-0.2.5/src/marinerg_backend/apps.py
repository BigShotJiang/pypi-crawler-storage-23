from django.apps import AppConfig


class MarinergBackendConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "marinerg_backend"
