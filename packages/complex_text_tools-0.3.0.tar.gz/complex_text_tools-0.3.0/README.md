# Complex Text Tools

[![PyPI version](https://badge.fury.io/py/complex-text-tools.svg)](https://badge.fury.io/py/complex-text-tools)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/complex-text-tools)
![PyPI - License](https://img.shields.io/pypi/l/complex-text-tools)

一个用于处理包含中英文混合字符的复杂文本的Python包，能够规范化空格、修复标点符号并根据特定规则计算文本长度。

## 功能特性

- **规范化空格**：自动在中英文/数字之间添加空格，移除中文之间的空格
- **修复标点符号**：智能转换中英文标点，处理混合括号
- **计算有效长度**：参考 Word 字数统计规则，支持中文日期格式

## 安装

```bash
pip install complex-text-tools
```

## 使用方法

### 规范化空格

```python
from complex_text_tools import remove_extra_spaces

# 自动在中英文之间添加空格
text1 = "这是中文English文本"
print(remove_extra_spaces(text1))
# 输出: "这是中文 English 文本"

# 自动在中文和数字之间添加空格
text2 = "数量是100个"
print(remove_extra_spaces(text2))
# 输出: "数量是 100 个"

# 移除中文之间的空格
text3 = "这 是 中 文"
print(remove_extra_spaces(text3))
# 输出: "这是中文"
```

### 计算有效文本长度

```python
from complex_text_tools import count_eff_len

# 中文日期格式统计（参考 Word 规则）
text = "2024年1月15日"
print(count_eff_len(text))
# 输出: 6 (2024=1, 年=1, 1=1, 月=1, 15=1, 日=1)

# 混合文本统计
text2 = "这是一段包含 English 和 123.45 的文本"
print(count_eff_len(text2))
# 输出: 13
```

### 修复标点符号

```python
from complex_text_tools import fix_punctuation

# 智能转换圆括号（根据上下文判断）
text1 = "(3)中文内容"
print(fix_punctuation(text1))
# 输出: "（3）中文内容"

text2 = "（3）english"
print(fix_punctuation(text2))
# 输出: "(3)english"

# 修复混合方括号
text3 = "[测试】内容"
print(fix_punctuation(text3))
# 输出: "【测试】内容"
```

## 许可证

该项目基于 MIT 许可证 - 详情请见 [LICENSE](LICENSE) 文件。