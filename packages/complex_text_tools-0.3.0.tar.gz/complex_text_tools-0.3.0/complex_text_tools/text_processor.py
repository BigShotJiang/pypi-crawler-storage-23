#!/usr/bin/env python
# -*- coding: utf-8 -*-
import re


def remove_extra_spaces(text: str) -> str:
    """
    规范化混合字符串中的空格
    规则：
    - 中文之间：移除空格
    - 中英文之间：保留一个空格（如果没有则添加）
    - 中文和数字之间：保留一个空格（如果没有则添加）
    - 中文和英文标点之间：移除空格
    - 英文单词和标点之间：遵循英文排版规范
    """
    # 1. 中文和英文之间添加空格（如果紧邻没有空格）
    text = re.sub(r"([\u4e00-\u9fff])([a-zA-Z])", r"\1 \2", text)
    text = re.sub(r"([a-zA-Z])([\u4e00-\u9fff])", r"\1 \2", text)
    
    # 2. 中文和数字之间添加空格（如果紧邻没有空格）
    text = re.sub(r"([\u4e00-\u9fff])(\d)", r"\1 \2", text)
    text = re.sub(r"(\d)([\u4e00-\u9fff])", r"\1 \2", text)
    
    # 3. 匹配中文字符之间的空格（移除）
    pattern1 = r"(?<=[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef])\s+(?=[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef])"

    # 4. 匹配中英文字符之间的空格（保留一个）
    pattern2 = r"(?<=[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef])\s+(?=[a-zA-Z])|(?<=[a-zA-Z])\s+(?=[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef])"

    # 5. 匹配中文字符与英文符号之间的空格（移除）
    pattern3 = r"(?<=[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef])\s+(?=[\[\]\(\)\{\}\"\'\:\;\?\!\,\.\`\~])|(?<=[\[\]\(\)\{\}\"\'\:\;\?\!\,\.\`\~])\s+(?=[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef])"

    # 6. 处理英文单词与标点之间的空格
    pattern4a = r"(\w)\s+([^\w\s])"  # 单词和标点之间无空格
    pattern4b = r"([^\w\s])\s+(\w)"  # 标点和单词之间保留一个空格
    pattern4c = r"(\w)\s{2,}(\w)"    # 单词间多余空格替换为一个空格

    # 7. 处理英文符号之间的多余空格
    pattern5 = r"([^\w\s])\s{2,}([^\w\s])"
    
    # 8. 移除英文标点之间的空格
    pattern7 = r"([^\w\s])\s+([^\w\s])"
    
    # 按顺序处理各种空格
    text = re.sub(pattern2, " ", text)  # 中英文之间保留一个空格
    text = re.sub(pattern1, "", text)   # 中文之间移除空格
    text = re.sub(pattern3, "", text)   # 中文与英文符号之间移除空格
    text = re.sub(pattern4a, r"\1\2", text)   # 单词和标点之间无空格
    text = re.sub(pattern4b, r"\1 \2", text)  # 标点和单词之间保留一个空格
    text = re.sub(pattern4c, r"\1 \2", text)  # 单词间多余空格替换为一个空格
    text = re.sub(pattern5, r"\1\2", text)    # 英文符号之间的多余空格
    text = re.sub(pattern7, r"\1\2", text)    # 英文标点之间的空格

    return text


def count_eff_len(text: str) -> int:
    """
    根据指定规则统计文本字数，支持：
    - i'm, don't 等带撇号单词计为 1 字
    - 数字、等式、日期等复杂结构整体计 1 字
    - 所有标点各计 1 字
    """
    if not text or not text.strip():
        return 0

    # 预处理：统一空白字符
    text = re.sub(r"\s+", " ", text.strip())
    count = 0
    remaining_text = text

    # 1. 中文日期格式（数字+年/月/日），参考 Word 字数统计规则
    # 每个数字算1字，中文单位算1字
    # 例如："2024年" = 2字, "2024年1月" = 4字, "2024年1月15日" = 6字
    chinese_date_parts = re.findall(r"\d+(?=[年月日])", remaining_text)
    count += len(chinese_date_parts)
    for match in chinese_date_parts:
        remaining_text = remaining_text.replace(match, " ", 1)

    # 2. 带连接符的数字（如日期、电话、版本号）
    connected_numbers = re.findall(r"\b\d+[-\/.]\d+(?:[-\/.]\d+)*\b", remaining_text)
    count += len(connected_numbers)
    for match in connected_numbers:
        remaining_text = remaining_text.replace(match, " ", 1)

    # 3. 简单等式和比较式（如 1+1=2, x>y, 5<=10）
    equations = re.findall(
        r"\b(?:\d+|[a-zA-Z])+(?:[+\-*/=<>≤≥]+(?:\d+|[a-zA-Z])+)+\b", remaining_text
    )
    count += len(equations)
    for match in equations:
        remaining_text = remaining_text.replace(match, " ", 1)

    # 4. 各种数字：整数、小数、百分数、分数
    numbers = re.findall(r"\b\d+(?:\.\d+)?%?|\d+/\d+\b", remaining_text)
    valid_numbers = [n for n in numbers if re.search(r"\d", n)]
    count += len(valid_numbers)
    for match in valid_numbers:
        remaining_text = remaining_text.replace(match, " ", 1)

    # 5. 英文单词（含撇号，如 i'm, don't, it's, can't，以及下划线连接的单词）
    # 使用之前调试时工作正常的正则表达式
    words = re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*(?![\u4e00-\u9fff\uf900-\ufaff])", remaining_text)
    # 过滤掉纯下划线和没有字母的词
    english_words = [w for w in words if re.search(r"[a-zA-Z]", w)]
    count += len(english_words)
    for match in english_words:
        remaining_text = remaining_text.replace(match, " ", 1)

    # 6. 中文字符（含中文标点）
    chinese_chars = re.findall(r"[\u4e00-\u9fff\uf900-\ufaff]", remaining_text)
    count += len(chinese_chars)
    for char in chinese_chars:
        remaining_text = remaining_text.replace(char, " ", 1)

    # 7. 剩余的所有标点符号（中英文）
    punctuation = re.findall(r"[^\w\s]", remaining_text)
    count += len(punctuation)

    return count


def fix_punctuation(text):
    """修复文本的标点符号"""
    def replace_punc(match):
        punc = match.group()
        return {
            ',': '，',
            '.': '。',
            ';': '；',
            ':': '：',
            '?': '？',
            '!': '！',
        }.get(punc, punc)
    
    # 1. 处理圆括号
    # 规则（优先级从高到低）：
    # - 前面是中文 → 中文括号
    # - 后面是中文/中文标点 → 中文括号
    # - 后面是英文 → 英文括号
    
    def fix_to_chinese_paren(match):
        content = match.group(1)
        return '（' + content + '）'
    
    def fix_to_english_paren(match):
        content = match.group(1)
        return '(' + content + ')'
    
    # 1a. 前面是中文 → 中文括号（使用占位符标记已处理）
    # 先标记前面是中文的括号
    text = re.sub(r'(?<=[\u4e00-\u9fff])[（(]([^()（）]+?)[)）]', lambda m: '\x00CHINESE_PAREN\x00' + m.group(1) + '\x00END_PAREN\x00', text)
    
    # 1b. 后面是中文/中文标点 → 中文括号
    text = re.sub(r'[（(]([^()（）]+?)[)）](?=[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef])', fix_to_chinese_paren, text)
    
    # 1c. 后面是英文 → 英文括号
    text = re.sub(r'[（(]([^()（）]+?)[)）](?=[a-zA-Z])', fix_to_english_paren, text)
    
    # 恢复标记的中文括号
    text = re.sub(r'\x00CHINESE_PAREN\x00([^()（）]+?)\x00END_PAREN\x00', r'（\1）', text)
    
    # 2. 处理混合方括号（左右不一致）：[xxx】或【xxx] -> 【xxx】
    def fix_mixed_brackets(match):
        content = match.group(2)
        return '【' + content + '】'
    
    text = re.sub(r'(\[)(.+?)(】)', fix_mixed_brackets, text)
    text = re.sub(r'(【)(.+?)(\])', fix_mixed_brackets, text)
    
    # 3. 处理一边是中文的标点符号（不包括括号）
    pattern = r'(?<=[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef])[,.;:?!]|[,.;:?!](?=[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef])'
    text = re.sub(pattern, replace_punc, text)
    
    # 4. 合并重复标点
    text = re.sub(r'，+', '，', text)
    text = re.sub(r'。+', '。', text)
    
    return text


if __name__ == "__main__":
    text = "成人CHF患者患病率已达1.3%,且患病后5年生存率仅约50%,严重威胁了患者生命健康[2]。"
    print(fix_punctuation(text))