import fontforge
import psMat
from numbers import Real
from . import util


__all__ = ["glyphHasNestedRefs", "selectGlyphsWithNestedRefs", "decomposeNestedRefs"]


def glyphHasNestedRefs(glyph: fontforge.glyph) -> bool:
    """
    Checks if glyph has nested references

    :param glyph: Fontforge glyph object
    :type glyph: fontforge.glyph
    :return: ``True`` if at least one reference is nested, ``False`` otherwise
    :rtype: bool
    """
    font = glyph.font
    for ref in glyph.references:
        (srcglyph, _, _) = ref
        if len(font[srcglyph].references) > 0:
            return True
    return False


def selectGlyphsWithNestedRefs(font: fontforge.font, moreless: Real = 0):
    """
    Selects glyphs with nested references

    :param font: Fontforge font object
    :type font: fontforge.font
    :param moreless: If positive, selects relevant glyphs in addition to the current selection. \
    If negative, deselects such glyphs. If zero, forgets current selection and then selects.
    :type moreless: numbers.Real
    """
    glyphsWithNestedRefs = set()
    for glyph in font.glyphs():
        if glyphHasNestedRefs(glyph):
            glyphsWithNestedRefs.add(glyph.glyphname)
    if moreless == 0:
        font.selection.none()
    for glyph in glyphsWithNestedRefs:
        font.selection.select(('more',) if moreless >= 0 else ('less',), glyph)


def _setUndoLayer(undoDict: dict[str, set[int]], glyph: fontforge.glyph, layerNum: int = -1):
    if layerNum == -1:
        layerNum = abs(fontforge.activeLayer())  # if still -1 (guide layer) set to 1 (foreground)
    if glyph.glyphname not in undoDict:
        undoDict[glyph.glyphname] = set()
    if layerNum not in undoDict[glyph.glyphname]:
        undoDict[glyph.glyphname].add(layerNum)
        glyph.preserveLayerAsUndo(layerNum)


def decomposeNestedRefs(font: fontforge.font, allGlyphs: bool = False):
    """
    Decomposes nested references into simple ones

    Nested references are known to cause problems in some environments.
    This function decomposes such refs into single-level ones.

    :param font: Fontforge font object
    :type font: fontforge.font
    :param allGlyphs: Ignores current selection and processes all glyphs
    :type allGlyphs: bool
    """
    undoable = {}
    while True:
        nestedRefsFound = False
        for glyph in util.selectedGlyphs(font, allGlyphs):
            decomposedRef = []
            for ref in glyph.references:
                (srcglyph, matrix, _) = ref
                if len(font[srcglyph].references) > 0:
                    _setUndoLayer(undoable, glyph)
                    for srcref in font[srcglyph].references:
                        decomposedRef += [(srcref[0], psMat.compose(srcref[1], matrix), False)]
                    for layerNum in range(min(glyph.layer_cnt, font[srcglyph].layer_cnt)):
                        # in case there are both contours and references
                        layer = font[srcglyph].layers[layerNum].dup()
                        if not layer.isEmpty():
                            layer.transform(matrix)
                            _setUndoLayer(undoable, glyph, layerNum)
                            glyph.layers[layerNum] += layer
                    nestedRefsFound = True
                else:
                    decomposedRef += [ref]
            if glyph.references != tuple(decomposedRef):
                glyph.references = tuple(decomposedRef)
        if not nestedRefsFound:
            break
