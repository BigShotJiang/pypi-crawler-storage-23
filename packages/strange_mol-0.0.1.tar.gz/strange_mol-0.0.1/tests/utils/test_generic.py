# =======================
# Python internal package
# =======================
# D
import dataclasses

# P
import pathlib

# T
import tempfile
import textwrap

# ================
# External package
# ================
# P
import pytest

# ==============
# Module package
# ==============
# P
from src.strange.utils.data import (
    check_typing,
)


@dataclasses.dataclass
class TestTyping:
    field_a: int = 0
    field_b: float = 0.0
    field_c: str = "value"


@pytest.mark.parametrize(
    "data_class",
    [
        TestTyping(field_a="0.0"),
        TestTyping(field_a=0.0),
        TestTyping(field_b=0),
        TestTyping(field_c=0),
        TestTyping(0, 0.0, 0),
    ],
)
def test_error(data_class) -> None:
    with pytest.raises(TypeError):
        print(data_class)
        check_typing(data_class)


@pytest.mark.parametrize(
    "data_class",
    [
        TestTyping(field_a=0),
        TestTyping(field_b=1.60),
        TestTyping(field_c="Tchoupitchou"),
        TestTyping(0, 0.0, "0"),
    ],
)
def test_working(data_class) -> None:
    check_typing(data_class)
