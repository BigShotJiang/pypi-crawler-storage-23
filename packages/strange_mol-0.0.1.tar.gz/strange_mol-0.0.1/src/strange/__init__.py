"""Input a ligand and its receptor, gets possible interaction."""

__authors__ = ["Lucas ROUAUD"]
__contact__ = ["lucas.rouaud@gmail.com"]
__version__ = "0.0.1"
__date__ = "2025_01_28"
__copyright__ = "MIT License"
