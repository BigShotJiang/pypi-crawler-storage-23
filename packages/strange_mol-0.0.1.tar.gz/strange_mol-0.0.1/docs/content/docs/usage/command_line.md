# Command line interface

## `--help` and parameters explained

To get the program help, you can run:

```bash
strange --help
```

{{% details title="Full help message" open=false %}}

```bash
usage: strange -i [FILE] [[FILE] ...] -o [FILE][.csv] [-h] [-v]
               [-s [str][None] [[str][None] ...]]
               [-p [FILE]['.toml'|'.json'|'.yaml'|'.yml'][None]]
               [--pharmacophore [FILE]['.csv'][None] [[FILE]['.csv'][None] ...]]
               [--feature_file [FILE]['.fdef'][None]]
               [--visualization [FILE]['.mvsj'][None]] [-a [int|str][0]]

  ██████ ▄▄▄█████▓ ██▀███   ▄▄▄       ███▄    █   ▄████ ▓█████ 
▒██    ▒ ▓  ██▒ ▓▒▓██ ▒ ██▒▒████▄     ██ ▀█   █  ██▒ ▀█▒▓█   ▀ 
░ ▓██▄   ▒ ▓██░ ▒░▓██ ░▄█ ▒▒██  ▀█▄  ▓██  ▀█ ██▒▒██░▄▄▄░▒███   
  ▒   ██▒░ ▓██▓ ░ ▒██▀▀█▄  ░██▄▄▄▄██ ▓██▒  ▐▌██▒░▓█  ██▓▒▓█  ▄ 
▒██████▒▒  ▒██▒ ░ ░██▓ ▒██▒ ▓█   ▓██▒▒██░   ▓██░░▒▓███▀▒░▒████▒
▒ ▒▓▒ ▒ ░  ▒ ░░   ░ ▒▓ ░▒▓░ ▒▒   ▓▒█░░ ▒░   ▒ ▒  ░▒   ▒ ░░ ▒░ ░
░ ░▒  ░ ░    ░      ░▒ ░ ▒░  ▒   ▒▒ ░░ ░░   ░ ▒░  ░   ░  ░ ░  ░
░  ░  ░    ░        ░░   ░   ░   ▒      ░   ░ ░ ░ ░   ░    ░   
      ░              ░           ░  ░         ░       ░    ░  ░

Program to compute interaction between two molecules from their
pharmacophore. The simplest command line is:

$ strange -i protein.pdb ligand.pdb -o interaction.csv

 Legend: 
    - int: Integer.
    - str: String.
    - [type|type][value]: Types of the input required, follow by the
        default value. So if this optional arguments is not used, "value"
        will be chosen.

 Documentation: NONE YET 

Note that if `--output` is not given, then `--pharmacophore` is mandatory.
The program then will compute only pharmacophore for a given molecule /
selection.

options:
  -i, --input [FILE] [[FILE] ...]
                         Mandatory 
                        Path to input one or two molecular structure files.
                        
  -o, --output [FILE][.csv]
                         Mandatory 
                        Path to output computed interactions.
                        
  -h, --help            Display this help message, then exit the program.
                        
  -v, --version         Display program version, then exit.
                        
  -s, --selection [str][None] [[str][None] ...]
                        One or two strings for filtering molecules through 'MDAnalysis':
                        - First string applied to first given structure.
                        - Second string applied to the second given structure.
                        - If only one structure is given, first and second selection 
                          are applied to it.
                        
  -p, --parameter [FILE]['.toml'|'.json'|'.yaml'|'.yml'][None]
                        Path to input parameter file.
                        
  --pharmacophore [FILE]['.csv'][None] [[FILE]['.csv'][None] ...]
                        Path to output computed pharmacophores. If given, except two files as output.
                        
  --feature_file [FILE]['.fdef'][None]
                        Path to input pharmacophore feature file.
                        
  --visualization [FILE]['.mvsj'][None]
                        Path to output visualization file:
                        - '.mvsj' to visualize using Mol*.
                        - '.pml' to visualize using PyMOL.
                        
  -a, --add_hydrogen [int|str][0]
                        Which structure to add hydrogen:
                        - 0 or 'none': no addition.
                        - 1 or 'first': first structure only.
                        - 2 or 'second': the second structure only.
                        - 3 or 'both': both structure.
                        - If only one structure is given, it is duplicated. Meaning 
                          that 1 applied for this structure with first given 
                          selection, if any. And that 2 applied for this structure 
                          with second given selection, if any.
                        
                          In this case, it is advice to simply use 'both'.
```

{{% /details %}}

**Here, is a table giving parameters details:**

- **Bold parameters** are mandatory.
- [option in brackets] must be given together.
  So `[opt1 opt2]` for parameter `-x` will be translated to `-x opt1 opt2` in the CLI.

|      **Parameter**       |                                                                                                                   **Value type**                                                                                                                   | **Explaination**                                                                                                                                                                                                                                                | **Values example**                                             |
| :----------------------: | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------- |
|  **`--input` or `-i`**   |                                                                                                  One or two files with molecules.                                                                                                  | This is where you input the molecules to compute pharmacophore and interaction from.                                                                                                                                                                            | [protein.pdb ligand.sdf] <br> [protein.pdb]                    |
|  **`--output` or `-o`**  |                                                                                            A `.csv` files to store compute interaction.                                                                                            | This files is going to contain which pharmacophores are interacting, and some other parameters.                                                                                                                                                                 | [interaction.csv]                                              |
|     `--help` or `-h`     |                                                                                                                                                                                                                                                    |                                                                                                                                                                                                                                                                 |                                                                |
|   `--version` or `-v`    |                                                                                                                                                                                                                                                    |                                                                                                                                                                                                                                                                 |                                                                |
|  `--selection` or `-s`   | Selection to apply to the molecule. Work only for files parsed by MDAnalysis (not `.sdf`, `.mol`, `.mol2`, `xyz`). For more details, check [MDAnalysis selection algebra](https://docs.mdanalysis.org/stable/documentation_pages/selections.html). | This parameter will let you select subparts of your molecule to make the computation.                                                                                                                                                                           | ["protein" "resid CEL"] <br> ["chainID A" "chainID B"]         |
|  `--parameter` or `-p`   |                                                                            Parameter file to configure the software. [Check the associated section](../../parameter/).                                                                             | The parameter file that you will input here is going to change the software behaviour.                                                                                                                                                                          | [parameters.yml] <br> [parameters.json] <br> [parameters.toml] |
|    `--pharmacophore`     |                                                                                                  Two `.csv` files to store compute pharmacophore.                                                                                                  | The computed pharmacophore. If you gave two molecules, the first file correspond to the first molecule, the second one to the second molecule. If one molecule is given, first and second files will respectfully correspond to the first and second selection. | [protein.csv ligand.csv]                                       |
|     `--feature_file`     |                                                                                    A `.fdef` file that is going to be used by RDKit to identify pharmacophore.                                                                                     | This file contained SMART that are used to define certain type of pharmacophore with RDKit.                                                                                                                                                                     | [feature_file.fdef]                                            |
|    `--visualization`     |                                                                              You can either give a `.pml` file or a `.mvsj` file to visualize using PyMOL or MolStar.                                                                              | Use this to visualize the pharmacophore using PyMOL (`pymol visualization.pml`) or MolStar (open first the `visualization.mvsj`, then load it, then your molecules).                                                                                            | [interaction.pml] <br> [interaction.mvsj]                      |
| `--add_hydrogen` or `-a` |                                                                                               If you want to add hydrogens to your input molecules.                                                                                                | You can choose, with this option, to add hydrogen to the first input molecule only, the second input molecule only, both or none. If one file is given, it will correspond to the selection (first selection only, second only, both or none).                  | [0] <br> ["both"]                                              |

## Usage example

### CLI usage

> [!CAUTION]
> **Structure quality**
>
> We except to have a molecular structure of “good quality”.
> Meaning no GAP, fully resolved and possibly with hydrogens.
> Our program try to add hydrogens, but it can remains a source of issues.

> [!INFO]
> **Structure choice**
>
> For next example, a fully resolved RMN structure is choosen.
> We do that to have the hydrogens position.

Here, we compute an interaction between a ligand and a protein:

```
wget https://files.rcsb.org/view/9i38.pdb
strange --input 9i38.pdb --output interaction.csv --selection "protein" "resname FDD"
```

### Results


