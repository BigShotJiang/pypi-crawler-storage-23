# van\_der\_waals\_radius

Module used to setup van der Waals radius.

{{< katex />}}

## VanDerWaalsRadius

Contains a list of element linked to their VdW radii, in Å.

### Citation

Alvarez, S. (2013).
A cartography of the van der Waals territories.
Dalton Transactions, 42(24), 8617.
https://doi.org/10.1039/c3dt50599e

{{% details title="Code block details" open=false %}}
```python
class VanDerWaalsRadius:
    """Contains a list of element linked to their VdW radii, in Å.

    Citation
    --------
    Alvarez, S. (2013).
    A cartography of the van der Waals territories.
    Dalton Transactions, 42(24), 8617.
    https://doi.org/10.1039/c3dt50599e
    """

    def __post_init__(self) -> None:
        """Check if user values are good typing. In other words, `str` instead
        of `float` for instance.
        """
        check_typing(self)

    def dict(self) -> dict[str, float]:
        """Convert this whole enumerate into a dictonnary. If None, element is
        skipped during the convertion.

        Returns
        -------
        `dict[str, float]`
            The dictionnary.
        """
        data: dict[str, float | None] = dataclasses.asdict(self)

        # Filter out all None from the dictionnary.
        return dict(filter(lambda item: item[1] is not None, data.items()))

    H: float | None = 1.20
    He: float | None = 1.43
    Li: float | None = 2.12
    Be: float | None = 1.98
    B: float | None = 1.91
    C: float | None = 1.77
    N: float | None = 1.66
    O: float | None = 1.50
    F: float | None = 1.46
    Ne: float | None = 1.58
    Na: float | None = 2.50
    Mg: float | None = 2.51
    Al: float | None = 2.25
    Si: float | None = 2.19
    P: float | None = 1.90
    S: float | None = 1.89
    Cl: float | None = 1.82
    Ar: float | None = 1.83
    K: float | None = 2.73
    Ca: float | None = 2.62
    Sc: float | None = 2.58
    Ti: float | None = 2.46
    V: float | None = 2.42
    Cr: float | None = 2.45
    Mn: float | None = 2.45
    Fe: float | None = 2.44
    Co: float | None = 2.40
    Ni: float | None = 2.40
    Cu: float | None = 2.38
    Zn: float | None = 2.39
    Ga: float | None = 2.32
    Ge: float | None = 2.29
    As: float | None = 1.88
    Se: float | None = 1.82
    Br: float | None = 1.86
    Kr: float | None = 2.25
    Rb: float | None = 3.21
    Sr: float | None = 2.84
    Y: float | None = 2.75
    Zr: float | None = 2.52
    Nb: float | None = 2.56
    Mo: float | None = 2.45
    Tc: float | None = 2.44
    Ru: float | None = 2.46
    Rh: float | None = 2.44
    Pd: float | None = 2.15
    Ag: float | None = 2.53
    Cd: float | None = 2.49
    In: float | None = 2.43
    Sn: float | None = 2.42
    Sb: float | None = 2.47
    Te: float | None = 1.99
    I: float | None = 2.04
    Xe: float | None = 2.06
    Cs: float | None = 3.48
    Ba: float | None = 3.03
    La: float | None = 2.98
    Ce: float | None = 2.88
    Pr: float | None = 2.92
    Nd: float | None = 2.95
    Pm: float | None = None
    Sm: float | None = 2.90
    Eu: float | None = 2.87
    Gd: float | None = 2.83
    Tb: float | None = 2.79
    Dy: float | None = 2.87
    Ho: float | None = 2.81
    Er: float | None = 2.83
    Tm: float | None = 2.79
    Yb: float | None = 2.80
    Lu: float | None = 2.74
    Hf: float | None = 2.63
    Ta: float | None = 2.53
    W: float | None = 2.57
    Re: float | None = 2.49
    Os: float | None = 2.48
    Ir: float | None = 2.41
    Pt: float | None = 2.29
    Au: float | None = 2.32
    Hg: float | None = 2.45
    Tl: float | None = 2.47
    Pb: float | None = 2.60
    Bi: float | None = 2.54
    Po: float | None = None
    At: float | None = None
    Rn: float | None = None
    Ac: float | None = 2.8
    Th: float | None = 2.93
    Pa: float | None = 2.88
    U: float | None = 2.71
    Np: float | None = 2.82
    Pu: float | None = 2.81
    Am: float | None = 2.83
    Cm: float | None = 3.05
    Bk: float | None = 3.4
    Cf: float | None = 3.05
    Es: float | None = 2.7
    Fm: float | None = None
    Md: float | None = None
    No: float | None = None
    Lr: float | None = None
    Rf: float | None = None
    Db: float | None = None
    Sg: float | None = None
    Bh: float | None = None
    Hs: float | None = None
    Mt: float | None = None
    Ds: float | None = None
    Rg: float | None = None
    Cn: float | None = None
    Nh: float | None = None
    Fl: float | None = None
    Mc: float | None = None
    Lv: float | None = None
    Ts: float | None = None
    Og: float | None = None
```
{{% /details %}}
### \_\_post\_init\_\_

Check if user values are good typing. In other words, `str` instead
of `float` for instance.

{{% details title="Code block details" open=false %}}
```python
def __post_init__(self) -> None:
        """Check if user values are good typing. In other words, `str` instead
        of `float` for instance.
        """
        check_typing(self)
```
{{% /details %}}
### dict

Convert this whole enumerate into a dictonnary. If None, element is
skipped during the convertion.

#### Returns

**`dict[str, float]`**

The dictionnary.

{{% details title="Code block details" open=false %}}
```python
def dict(self) -> dict[str, float]:
        """Convert this whole enumerate into a dictonnary. If None, element is
        skipped during the convertion.

        Returns
        -------
        `dict[str, float]`
            The dictionnary.
        """
        data: dict[str, float | None] = dataclasses.asdict(self)

        # Filter out all None from the dictionnary.
        return dict(filter(lambda item: item[1] is not None, data.items()))
```
{{% /details %}}
