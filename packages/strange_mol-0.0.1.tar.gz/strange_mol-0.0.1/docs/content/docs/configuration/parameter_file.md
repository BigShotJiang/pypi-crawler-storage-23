# Parameter file

{{< katex />}}

## Setup

For the parameter file, we are accepting these formats:

- `.json`.
- `.yml`.
- `.toml`.

You can configure **four main categories**:

- `miscellaneous`: For global things.
- `interaction_configuration`: Setup constants used to defini if two
  pharmacophore are in interaction.
- `visualisation`: Setup how the visualization will looks (mostly colors).
- `vdw_radius`: Setup atoms van der Waals atoms radius. This is used in order to
  determine if two atoms are connected.

## Files syntax example

> [!WARNING]
> The next example are not full. They are just here to give an idea on how to
> create the configuration file.

{{< tabs >}}

    {{% tab ".json" %}}

```json
{
  "miscellaneous": {
    "enable_vdw_radius": true
  },
  "vdw_radius": {
    "H": 1.20
  },
  "interaction_configuration": {
    "min_dist": 0.5
  },
  "visualization": {
    "hydrophobe__color": "#FFFF00"
  }
}
```

    {{% /tab %}}

    {{% tab ".yml" %}}

```yaml
miscellaneous:
  enable_vdw_radius: True
vdw_radius:
  H: 1.20
interaction_configuration:
  min_dist: 0.5
visualization:
  hydrophobe__color: "#FFFF00"
```

    {{% /tab %}}

    {{% tab ".toml" %}}

```toml
[miscellaneous]
enable_vdw_radius = true

[vdw_radius]
H = 1.20

[interaction_configuration]
min_dist = 0.5

[visualization]
hydrophobe__color = "#FFFF00"
```

    {{% /tab %}}

{{< /tabs >}}

## Available configuration options

### Miscellaneous

<div align="center">

|    **Option**     | **Type** | **Default value** | **Explaination**                                                                                                                                                                                                             |
| :---------------: | :------- | :---------------: | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
|   csv_separator   | `str`    |        ","        | Define what is the sepator that is going to be used in the produced `.csv` files                                                                                                                                             |
| enable_vdw_radius | `bool`   |       Famse       | Enable the usage of custom van der Waals radius for the atoms.                                                                                                                                                               |
| number_neighbour  | `int`    |         3         | Define the maximum numbers of atoms to filter out intramolecular interaction. Meaning that if an interaction is detected between two atoms that are topologycally close up to three atoms, it is not going to be considered. |

</div>

### Interaction configuration

<div align="center">

|       **Option**       | **Type** | **Default value** | **Explaination**                                                                                                                                                                                                                                                                                                                                                      |
| :--------------------: | :------: | :---------------: | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
|        min_dist        | `float`  |        0.5        | Minimum distance to considerated an interaction.                                                                                                                                                                                                                                                                                                                      |
|    hydroph_dist_max    | `float`  |        4.0        | Maximum distance to considerated an hydrophobic interaction.                                                                                                                                                                                                                                                                                                          |
|     hbond_dist_max     | `float`  |        2.5        | Maximum distance to considerated an hydrogen bond.                                                                                                                                                                                                                                                                                                                    |
|  hbond_don_angle_min   | `float`  |       120.0       | Minimum angle to considerated an hydrogen bond. If we have an `—O—H` donor and a `O—` acceptor, the angle is `—O—H O'—`.                                                                                                                                                                                                                                              |
|  hbond_don_angle_max   | `float`  |       180.0       | Maximum angle to considerated an hydrogen bond. If we have an `—O—H` donor and a `O—` acceptor, the angle is `—O—H O'—`.                                                                                                                                                                                                                                              |
|    pistack_dist_max    | `float`  |        5.5        | Maximum distance to considerated a $\pi$ stacking interaction.                                                                                                                                                                                                                                                                                                        |
|    pistack_ang_dev     | `float`  |       30.0        | Maximum angle to considerated a $\pi$ stacking interaction. The angle is computed between the normal vectors of two aromatic cycle.                                                                                                                                                                                                                                   |
|   pistack_offset_max   | `float`  |        2.0        | Maximum offset to considerated a $\pi$ stacking interaction. It is actually the distance between a first aromatic cycle center, and a second aromatic cycle center projected on this first aromatic cycle plane through this second aromatic normal vector. In the case of a $\pi$ anion or cation, this is the charge that is projected on the aromatic cycle plane. |
|   pication_dist_max    | `float`  |        6.0        | Maximum distance to considerated a $\pi$ cation interaction.                                                                                                                                                                                                                                                                                                          |
|    pianion_dist_max    | `float`  |        5.0        | Maximum distance to considerated a $\pi$ anion interaction.                                                                                                                                                                                                                                                                                                           |
|  saltbridge_dist_max   | `float`  |        5.5        | Maximum distance to considerated a salt bridge interaction.                                                                                                                                                                                                                                                                                                           |
|    halogen_dist_max    | `float`  |        4.0        | Maximum distance to considerated a halogen interaction.                                                                                                                                                                                                                                                                                                               |
|   halogen_acc_angle    | `float`  |       120.0       | Optimal halogen acceptor angle. If we have `—X—A` for the halogen acceptor and `H—Y—` for the halogen donor, the angle is `—X—A H—`.                                                                                                                                                                                                                                  |
|   halogen_don_angle    | `float`  |       165.0       | Optimal halogen donor angle. If we have `—X—A` for the halogen acceptor and `H—Y—` for the halogen donor, the angle is `—A H—Y—`.                                                                                                                                                                                                                                     |
|   halogen_angle_dev    | `float`  |       30.0        | Angle deviation to determine acceptation interval in the case of halogen angle .                                                                                                                                                                                                                                                                                      |
| water_bridge_dist_min  | `float`  |        2.5        | Minimum distance to considerated a water bridge interaction.                                                                                                                                                                                                                                                                                                          |
| water_bridge_dist_max  | `float`  |        4.1        | Maximum distance to considerated a water bridge interaction.                                                                                                                                                                                                                                                                                                          |
| water_bridge_omega_min | `float`  |       71.0        | ?                                                                                                                                                                                                                                                                                                                                                                     |
| water_bridge_omega_max | `float`  |       140.0       | ?                                                                                                                                                                                                                                                                                                                                                                     |
| water_bridge_theta_min | `float`  |       100.0       | ?                                                                                                                                                                                                                                                                                                                                                                     |
|     metal_dist_max     | `float`  |        3.0        | Maximum distance to considerated a metal interaction.                                                                                                                                                                                                                                                                                                                 |

</div>

### Visualization

<div align="center">

|         **Option**         | **Type** | **Default value** | **Explaination**                                    |
| :------------------------: | :------- | :---------------: | :-------------------------------------------------- |
|       donor__radius        | `float`  |       1 / 3       | Hydrogen bond donor pharmacophore sphere size.      |
|        donor__color        | `string` |     "#FDE725"     | Hydrogen bond donor pharmacophore sphere colour.    |
|      acceptor__radius      | `float`  |       1 / 3       | Hydrogen bond acceptor pharmacophore sphere size.   |
|      acceptor__color       | `string` |     "#ADDC30"     | Hydrogen bond acceptor pharmacophore sphere colour. |
|      negative__radius      | `float`  |       1 / 3       | Negative pharmacophore sphere size.                 |
|      negative__color       | `string` |     "#5EC962"     | Negative pharmacophore sphere colour.               |
|      positive__radius      | `float`  |       1 / 3       | Positive pharmacophore sphere size.                 |
|      positive__color       | `string` |     "#28AE80"     | Positive pharmacophore sphere colour.               |
|      aromatic__radius      | `float`  |       1 / 3       | Aromatic pharmacophore sphere size.                 |
|      aromatic__color       | `string` |     "#21918C"     | Aromatic pharmacophore sphere colour.               |
|     hydrophobe__radius     | `float`  |       1 / 3       | Hydrophobic pharmacophore sphere size.              |
|     hydrophobe__color      | `string` |     "#2C728E"     | Hydrophobic pharmacophore sphere colour.            |
| lumped_hydrophobe__radius  | `float`  |       1 / 3       | Lumped hydrophobic pharmacophore sphere size.       |
|  lumped_hydrophobe__color  | `string` |     "#3B528B"     | Lumped hydrophobic pharmacophore sphere colour.     |
|   halogen_donor__radius    | `float`  |       1 / 3       | Halogen donor pharmacophore sphere size.            |
|    halogen_donor__color    | `string` |     "#472D7B"     | Halogen donor pharmacophore sphere colour.          |
|  halogen_acceptor__radius  | `float`  |       1 / 3       | Halogen acceptor pharmacophore sphere size.         |
|  halogen_acceptor__color   | `string` |     "#440154"     | Halogen acceptor pharmacophore sphere colour.       |
|    hydrophobic__radius     | `float`  |      1 / 30       | Hydrophobic interaction line radius / width.        |
|  hydrophobic__dash_length  | `float`  |      1 / 30       | Hydrophobic interaction dash length.                |
|     hydrophobic__color     | `string` |     "#FDE725"     | Hydrophobic interaction line colour.                |
|   hydrogen_bond__radius    | `float`  |      1 / 30       | Hydrogen bond interaction line radius / width.      |
| hydrogen_bond__dash_length | `float`  |      1 / 30       | Hydrogen bond interaction dash length.              |
|    hydrogen_bond__color    | `string` |     "#90D743"     | Hydrogen bond interaction line colour.              |
|    pi_stacking__radius     | `float`  |      1 / 30       | $\pi$ stacking interaction line radius / width.     |
|  pi_stacking__dash_length  | `float`  |      1 / 30       | $\pi$ stacking interaction line dash length.        |
|     pi_stacking__color     | `string` |     "#35B779"     | $\pi$ stacking interaction line colour.             |
|     pi_cation__radius      | `float`  |      1 / 30       | $\pi$ cation interaction line radius / width.       |
|   pi_cation__dash_length   | `float`  |      1 / 30       | $\pi$ cation interaction line dash length.          |
|      pi_cation__color      | `string` |     "#21918C"     | $\pi$ cation interaction line colour.               |
|      pi_anion__radius      | `float`  |      1 / 30       | $\pi$ anion interaction line radius / width.        |
|   pi_anion__dash_length    | `float`  |      1 / 30       | $\pi$ anion interaction line dash length.           |
|      pi_anion__color       | `string` |     "#31688E"     | $\pi$ anion interaction line colour.                |
|    salt_bridge__radius     | `float`  |      1 / 30       | Salt bridge interaction line radius / width.        |
|  salt_bridge__dash_length  | `float`  |      1 / 30       | Salt bridge interaction line dash length.           |
|     salt_bridge__color     | `string` |     "#443983"     | Salt bridge interaction line colour.                |
|    halogen_bond__radius    | `float`  |      1 / 30       | Halogen bond interaction line radius / width.       |
| halogen_bond__dash_length  | `float`  |      1 / 30       | Halogen bond interaction line dash length.          |
|    halogen_bond__color     | `string` |     "#440154"     | Halogen bond interaction line colour.               |

</div>

### Van der Waals radius

> [!CAUTION]
> These options are only read when the option `enable_vdw_radius` in
> `miscellaneous` is set to `True`!

All these parameters are used to define a van der Waals radii. It is used by
`MDAnalysis` to define if two atoms are topologycally connected.

<div align="center">

| **Option** | **Type**          | **Default value** |
| :--------: | :---------------- | :---------------: |
|     H      | `float` or `None` |       1.20        |
|     He     | `float` or `None` |       1.43        |
|     Li     | `float` or `None` |       2.12        |
|     Be     | `float` or `None` |       1.98        |
|     B      | `float` or `None` |       1.91        |
|     C      | `float` or `None` |       1.77        |
|     N      | `float` or `None` |       1.66        |
|     O      | `float` or `None` |       1.50        |
|     F      | `float` or `None` |       1.46        |
|     Ne     | `float` or `None` |       1.58        |
|     Na     | `float` or `None` |       2.50        |
|     Mg     | `float` or `None` |       2.51        |
|     Al     | `float` or `None` |       2.25        |
|     Si     | `float` or `None` |       2.19        |
|     P      | `float` or `None` |       1.90        |
|     S      | `float` or `None` |       1.89        |
|     Cl     | `float` or `None` |       1.82        |
|     Ar     | `float` or `None` |       1.83        |
|     K      | `float` or `None` |       2.73        |
|     Ca     | `float` or `None` |       2.62        |
|     Sc     | `float` or `None` |       2.58        |
|     Ti     | `float` or `None` |       2.46        |
|     V      | `float` or `None` |       2.42        |
|     Cr     | `float` or `None` |       2.45        |
|     Mn     | `float` or `None` |       2.45        |
|     Fe     | `float` or `None` |       2.44        |
|     Co     | `float` or `None` |       2.40        |
|     Ni     | `float` or `None` |       2.40        |
|     Cu     | `float` or `None` |       2.38        |
|     Zn     | `float` or `None` |       2.39        |
|     Ga     | `float` or `None` |       2.32        |
|     Ge     | `float` or `None` |       2.29        |
|     As     | `float` or `None` |       1.88        |
|     Se     | `float` or `None` |       1.82        |
|     Br     | `float` or `None` |       1.86        |
|     Kr     | `float` or `None` |       2.25        |
|     Rb     | `float` or `None` |       3.21        |
|     Sr     | `float` or `None` |       2.84        |
|     Y      | `float` or `None` |       2.75        |
|     Zr     | `float` or `None` |       2.52        |
|     Nb     | `float` or `None` |       2.56        |
|     Mo     | `float` or `None` |       2.45        |
|     Tc     | `float` or `None` |       2.44        |
|     Ru     | `float` or `None` |       2.46        |
|     Rh     | `float` or `None` |       2.44        |
|     Pd     | `float` or `None` |       2.15        |
|     Ag     | `float` or `None` |       2.53        |
|     Cd     | `float` or `None` |       2.49        |
|     In     | `float` or `None` |       2.43        |
|     Sn     | `float` or `None` |       2.42        |
|     Sb     | `float` or `None` |       2.47        |
|     Te     | `float` or `None` |       1.99        |
|     I      | `float` or `None` |       2.04        |
|     Xe     | `float` or `None` |       2.06        |
|     Cs     | `float` or `None` |       3.48        |
|     Ba     | `float` or `None` |       3.03        |
|     La     | `float` or `None` |       2.98        |
|     Ce     | `float` or `None` |       2.88        |
|     Pr     | `float` or `None` |       2.92        |
|     Nd     | `float` or `None` |       2.95        |
|     Pm     | `float` or `None` |       None        |
|     Sm     | `float` or `None` |       2.90        |
|     Eu     | `float` or `None` |       2.87        |
|     Gd     | `float` or `None` |       2.83        |
|     Tb     | `float` or `None` |       2.79        |
|     Dy     | `float` or `None` |       2.87        |
|     Ho     | `float` or `None` |       2.81        |
|     Er     | `float` or `None` |       2.83        |
|     Tm     | `float` or `None` |       2.79        |
|     Yb     | `float` or `None` |       2.80        |
|     Lu     | `float` or `None` |       2.74        |
|     Hf     | `float` or `None` |       2.63        |
|     Ta     | `float` or `None` |       2.53        |
|     W      | `float` or `None` |       2.57        |
|     Re     | `float` or `None` |       2.49        |
|     Os     | `float` or `None` |       2.48        |
|     Ir     | `float` or `None` |       2.41        |
|     Pt     | `float` or `None` |       2.29        |
|     Au     | `float` or `None` |       2.32        |
|     Hg     | `float` or `None` |       2.45        |
|     Tl     | `float` or `None` |       2.47        |
|     Pb     | `float` or `None` |       2.60        |
|     Bi     | `float` or `None` |       2.54        |
|     Po     | `float` or `None` |       None        |
|     At     | `float` or `None` |       None        |
|     Rn     | `float` or `None` |       None        |
|     Ac     | `float` or `None` |        2.8        |
|     Th     | `float` or `None` |       2.93        |
|     Pa     | `float` or `None` |       2.88        |
|     U      | `float` or `None` |       2.71        |
|     Np     | `float` or `None` |       2.82        |
|     Pu     | `float` or `None` |       2.81        |
|     Am     | `float` or `None` |       2.83        |
|     Cm     | `float` or `None` |       3.05        |
|     Bk     | `float` or `None` |        3.4        |
|     Cf     | `float` or `None` |       3.05        |
|     Es     | `float` or `None` |        2.7        |
|     Fm     | `float` or `None` |       None        |
|     Md     | `float` or `None` |       None        |
|     No     | `float` or `None` |       None        |
|     Lr     | `float` or `None` |       None        |
|     Rf     | `float` or `None` |       None        |
|     Db     | `float` or `None` |       None        |
|     Sg     | `float` or `None` |       None        |
|     Bh     | `float` or `None` |       None        |
|     Hs     | `float` or `None` |       None        |
|     Mt     | `float` or `None` |       None        |
|     Ds     | `float` or `None` |       None        |
|     Rg     | `float` or `None` |       None        |
|     Cn     | `float` or `None` |       None        |
|     Nh     | `float` or `None` |       None        |
|     Fl     | `float` or `None` |       None        |
|     Mc     | `float` or `None` |       None        |
|     Lv     | `float` or `None` |       None        |
|     Ts     | `float` or `None` |       None        |
|     Og     | `float` or `None` |       None        |

</div>
