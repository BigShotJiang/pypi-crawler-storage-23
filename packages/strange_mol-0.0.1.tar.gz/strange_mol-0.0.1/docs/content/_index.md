+++
title = "strange"
layout = "landing"
+++

<div class="book-hero">

# strange

A python software used to computed interaction between two molecules, from their
pharmacophore.

[{{< badge style="info" title="python" value="3.13.0" >}}](https://www.python.org/downloads/release/python-3130/)
[{{< badge style="info" title="Documentation" value="hugo-book" >}}](https://hugo-book-demo.netlify.app/)
[{{< badge style="warning" title="License" value="MIT" >}}](https://mit-license.org/)
[{{< badge style="warning" title="License" value="CC-BY" >}}](https://creativecommons.org/licenses/by/4.0/)

</div>

{{% molstar %}}

<style>
    #molstar-4 {
        height: 15cm;
    }
</style>

{{% columns %}}

- {{< card >}}
  ## 📝 Contributors

  Lucas ROUAUD

  {{< /card >}}

- {{< card >}}
  ## 🙇‍♂️ Acknowledgement

  - **Original idea:** Etienne REBOUL
  - **Formula checking:** Charles ROBERT
  - **Beta testing:** Isleme KHALFAOUI, Malek MELLITI

  {{< /card >}}

- {{< card >}}
  ## 🦊 GitLab repository

  https://gitlab.galaxy.ibpc.fr/rouaud/strange

  {{< /card >}}

{{% /columns %}}
