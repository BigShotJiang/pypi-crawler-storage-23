# strange

python -m src.strange -i ~/Downloads/4jet_cleaned.gro -a "both" -s "protein" "not protein" -o ~/Downloads/test.csv --visualisation ~/Downloads/test.mvsj --pharmacophore ~/Downloads/pharmacophore_1.csv ~/Downloads/pharmacophore_2.csv
