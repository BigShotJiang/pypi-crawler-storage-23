===================
Code Reference
===================

.. toctree::
    :maxdepth: 2

    diff
    coefs
    pde
    stencils
