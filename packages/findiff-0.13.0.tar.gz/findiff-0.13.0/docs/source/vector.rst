===============
Module *vector*
===============

.. automodule:: findiff.vector
    :members:
