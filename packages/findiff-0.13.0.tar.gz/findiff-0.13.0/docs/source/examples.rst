========
Examples
========

.. toctree::
    :maxdepth: 1

    examples-basic
    examples-vector-calculus
    examples-polar
    examples-non-uniform-grids
    examples-matrix
    examples-periodic


