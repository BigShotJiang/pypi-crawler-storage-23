=============
Partial Differential Equations
=============

.. automodule:: findiff.pde
    :members:
