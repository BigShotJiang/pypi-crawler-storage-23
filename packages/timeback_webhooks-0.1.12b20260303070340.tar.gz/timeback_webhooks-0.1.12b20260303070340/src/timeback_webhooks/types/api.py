"""
Webhooks API Types

Pydantic models for the Webhooks API responses and entities.
Mirrors the TypeScript SDK's protocol types.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS
# ═══════════════════════════════════════════════════════════════════════════════

FilterType = Literal["string", "number", "boolean"]

FilterOperation = Literal[
    "eq",
    "neq",
    "gt",
    "gte",
    "lt",
    "lte",
    "contains",
    "notContains",
    "in",
    "notIn",
    "startsWith",
    "endsWith",
    "regexp",
]

# ═══════════════════════════════════════════════════════════════════════════════
# ENTITIES
# ═══════════════════════════════════════════════════════════════════════════════


class Webhook(BaseModel):
    """A registered webhook."""

    id: str
    sensor: str | None = None
    name: str
    description: str | None = None
    target_url: str = Field(alias="targetUrl")
    secret: str
    active: bool
    created_at: str | None = Field(None, alias="created_at")
    updated_at: str | None = Field(None, alias="updated_at")
    deleted_at: str | None = Field(None, alias="deleted_at")

    model_config = {"populate_by_name": True}


class WebhookFilter(BaseModel):
    """A filter attached to a webhook that controls which events trigger delivery."""

    id: str
    webhook_id: str = Field(alias="webhookId")
    filter_key: str = Field(alias="filterKey")
    filter_value: str = Field(alias="filterValue")
    filter_type: FilterType = Field(alias="filterType")
    filter_operator: FilterOperation = Field(alias="filterOperator")
    active: bool
    created_at: str | None = Field(None, alias="created_at")
    updated_at: str | None = Field(None, alias="updated_at")
    deleted_at: str | None = Field(None, alias="deleted_at")

    model_config = {"populate_by_name": True}


# ═══════════════════════════════════════════════════════════════════════════════
# API RESPONSES
# ═══════════════════════════════════════════════════════════════════════════════


class WebhookListResponse(BaseModel):
    """Response for GET /webhooks/"""

    webhooks: list[Webhook]


class WebhookResponse(BaseModel):
    """Response for POST/GET/PUT /webhooks/:id and activate/deactivate."""

    webhook: Webhook


class WebhookDeleteResponse(BaseModel):
    """Response for DELETE /webhooks/:id"""

    message: str


class WebhookFilterListResponse(BaseModel):
    """Response for GET /webhook-filters/ and GET /webhook-filters/webhook/:webhookId"""

    filters: list[WebhookFilter]


class WebhookFilterResponse(BaseModel):
    """Response for POST/GET/PUT /webhook-filters/:id"""

    filter: WebhookFilter


class WebhookFilterDeleteResponse(BaseModel):
    """Response for DELETE /webhook-filters/:id"""

    message: str
