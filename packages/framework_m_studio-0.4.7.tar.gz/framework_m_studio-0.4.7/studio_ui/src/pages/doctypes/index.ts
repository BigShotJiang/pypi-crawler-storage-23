/**
 * DocType Pages Index
 */

export { DocTypeList } from "./list";
export { DocTypeEdit } from "./edit";
