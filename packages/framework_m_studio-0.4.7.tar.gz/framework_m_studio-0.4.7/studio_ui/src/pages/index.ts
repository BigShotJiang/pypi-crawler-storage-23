/**
 * Pages Index
 */

export * from "./doctypes";
