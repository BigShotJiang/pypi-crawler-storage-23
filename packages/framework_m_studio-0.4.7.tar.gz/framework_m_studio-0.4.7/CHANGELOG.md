# Changelog

## framework-m-studio v0.4.7

### Bug Fixes

- server ips to 0.0.0.0 instead of 127.0.0.1 (97e0960)


## framework-m-studio v0.4.6

### Bug Fixes

- implement m dev mode flag (5fd57e0)


## framework-m-studio v0.4.5

### Bug Fixes

- refine readme reading (8c8adb6)


## framework-m-studio v0.4.4

### Bug Fixes

- code preview, rename doctypes and add new docs (c711fdd)


## framework-m-studio v0.4.3

### Bug Fixes

- mock static assets for robust api testing (9332b17)
- build UI in publish job + remove test dependencies (ebe7661)


## framework-m-studio v0.4.2

### Bug Fixes

- preserve static assets in build (b155a0b)


## framework-m-studio v0.4.1

### Bug Fixes

- update studio readme to www.frameworkm.dev (91de2da)


## framework-m-studio v0.4.0

### Features

- implement dynamic versioning and dev groups in app scaffolding (2d66119)

### Bug Fixes

- use last tag version as base for release bump (bfefd3f)
- support version bumping for package.json in release script (2b6a7c3)
- fix build crash and ensure static assets are packaged (bdc18b7)
- force include gitignored static assets in packages (4fd49a5)


## framework-m-studio v0.3.5

### Bug Fixes

- trigger doc builds on studio changes (d1a2a7b)
- synchronize pages rules with build-docs (3b2d9b7)
- aggressive filtering and dependency decoupling (6b8dbf0)
- global dummy assets and artifact integrity (f6d39f2)
- dual-track artifacts and tag optimization (6b9cdfb)
- optimize tag pipeline and kill duplication (d9154ae)
- use hatch artifacts to resolve duplicate filenames (e499457)


## framework-m-studio v0.3.4

### Bug Fixes

- robustly detect existing tags in auto_tag_release (8aeef39)


## framework-m-studio v0.3.3

### Bug Fixes

- bulletproof tagging and gitlab pypi upload idempotency (530466b)
- make auto_tag_release script idempotent (c211ab5)


## framework-m-studio v0.3.2

### Bug Fixes

- remove unsupported --skip-existing from gitlab twine upload (a1b6a96)


## framework-m-studio v0.3.1

### Bug Fixes

- make test-workspace needs optional (96450fc)
- restore gitlint general section header (7131edc)
- adjust gitlint limits and script for long release titles (1a1371e)
- resolve duplicate filenames in wheel and improve CI robustness (e24c0ef)


## framework-m-studio v0.3.0

### Features

- support namespaced app, test directory and dev.py moved to studio (37beae6)


## framework-m-studio v0.2.8

### Bug Fixes

- add ruff code style badge to README (c2482ea)


## framework-m-studio v0.2.7

### Bug Fixes

- add Python version and license badges to README (90d1adf)


## framework-m-studio v0.2.6

### Bug Fixes

- format and lint (090018f)


## framework-m-studio v0.2.3

### Bug Fixes

- ensure static assets are bundled in the wheel (ce0a0e1)


## framework-m-studio v0.2.2

### Bug Fixes

- add badges to readme (012333b)


## framework-m-studio v0.2.1

### Bug Fixes

- modernize aesthetics (300cdda)


## framework-m-studio 0.2.0

### Features

- implement path prefix architecture for UI/API separation (7a8d2d2)
- add cloud workspace & git adapter, controller scaffolding and sandbox (a7a4a3e)
- implement Studio backend and frontend (abf5d03)

### Bug Fixes

- include static files in package for PyPI publishing (565bcb8)

