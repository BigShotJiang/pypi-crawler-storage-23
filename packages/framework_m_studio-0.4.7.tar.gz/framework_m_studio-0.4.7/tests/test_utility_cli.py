"""Tests for Utility CLI Commands in Studio."""

from __future__ import annotations

import pytest


class TestUtilityImport:
    """Tests for utility module imports."""

    def test_import_console_command(self) -> None:
        """console_command should be importable."""
        from framework_m_studio.cli.utility import console_command

        assert console_command is not None

    def test_import_routes_command(self) -> None:
        """routes_command should be importable."""
        from framework_m_studio.cli.utility import routes_command

        assert routes_command is not None


class TestCheckIPython:
    """Tests for check_ipython_installed function."""

    def test_check_ipython_installed_returns_bool(self) -> None:
        """check_ipython_installed should return bool."""
        from framework_m_studio.cli.utility import check_ipython_installed

        result = check_ipython_installed()
        assert isinstance(result, bool)


class TestConsoleCommand:
    """Tests for console_command function."""

    def test_console_command_is_callable(self) -> None:
        """console_command should be callable."""
        from framework_m_studio.cli.utility import console_command

        assert callable(console_command)


class TestRoutesCommand:
    """Tests for routes_command function."""

    def test_routes_command_is_callable(self) -> None:
        """routes_command should be callable."""
        from framework_m_studio.cli.utility import routes_command

        assert callable(routes_command)

    def test_routes_command_output(self, capsys: pytest.CaptureFixture[str]) -> None:
        """routes_command should print route info."""
        from framework_m_studio.cli.utility import routes_command

        routes_command(app_path=None)
        captured = capsys.readouterr()
        assert "routes" in captured.out.lower()


class TestUtilityExports:
    """Tests for utility module exports."""

    def test_all_exports(self) -> None:
        """utility module should export expected items."""
        from framework_m_studio.cli import utility

        assert "console_command" in utility.__all__
        assert "routes_command" in utility.__all__
