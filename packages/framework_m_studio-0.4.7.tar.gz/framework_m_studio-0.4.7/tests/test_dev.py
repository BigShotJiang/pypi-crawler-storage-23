"""Tests for Dev CLI Command - Comprehensive Coverage."""

from __future__ import annotations

import os
import signal
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestDevImport:
    """Tests for dev module imports."""

    def test_import_dev_command(self) -> None:
        """dev_command should be importable."""
        from framework_m_studio.cli.dev import dev_command

        assert dev_command is not None

    def test_import_constants(self) -> None:
        """Constants should be importable."""
        from framework_m_studio.cli.dev import (
            DEFAULT_BACKEND_PORT,
            DEFAULT_FRONTEND_PORT,
            DEFAULT_STUDIO_PORT,
        )

        assert DEFAULT_BACKEND_PORT == 8888
        assert DEFAULT_FRONTEND_PORT == 5173
        assert DEFAULT_STUDIO_PORT == 9999


class TestGetPythonPath:
    """Tests for _get_pythonpath function."""

    def test_get_pythonpath_returns_string(self) -> None:
        """_get_pythonpath should return a string."""
        from framework_m_studio.cli.dev import _get_pythonpath

        result = _get_pythonpath()
        assert isinstance(result, str)

    def test_get_pythonpath_includes_cwd(self) -> None:
        """_get_pythonpath should include current directory."""
        from framework_m_studio.cli.dev import _get_pythonpath

        result = _get_pythonpath()
        cwd = str(Path.cwd())
        assert cwd in result

    def test_get_pythonpath_includes_src(self, tmp_path: Path) -> None:
        """_get_pythonpath should include src if it exists."""
        from framework_m_studio.cli.dev import _get_pythonpath

        src_path = tmp_path / "src"
        src_path.mkdir()

        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            result = _get_pythonpath()

        assert str(src_path) in result

    def test_get_pythonpath_preserves_existing(self, tmp_path: Path) -> None:
        """_get_pythonpath should preserve existing PYTHONPATH."""
        from framework_m_studio.cli.dev import _get_pythonpath

        with (
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
            patch.dict(os.environ, {"PYTHONPATH": "/existing/path"}),
        ):
            result = _get_pythonpath()

        assert "/existing/path" in result


class TestFindApp:
    """Tests for _find_app function."""

    def test_find_app_explicit(self) -> None:
        """_find_app should return explicit app path."""
        from framework_m_studio.cli.dev import _find_app

        result = _find_app("myapp.main:create_app")
        assert result == "myapp.main:create_app"

    def test_find_app_with_app_py(self, tmp_path: Path) -> None:
        """_find_app should find app.py."""
        from framework_m_studio.cli.dev import _find_app

        (tmp_path / "app.py").write_text("app = None")

        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            result = _find_app()

        assert result == "app:app"

    def test_find_app_with_app_package(self, tmp_path: Path) -> None:
        """_find_app should find app/__init__.py."""
        from framework_m_studio.cli.dev import _find_app

        (tmp_path / "app").mkdir()
        (tmp_path / "app" / "__init__.py").write_text("app = None")

        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            result = _find_app()

        assert result == "app:app"

    def test_find_app_with_src_app(self, tmp_path: Path) -> None:
        """_find_app should find src/app."""
        from framework_m_studio.cli.dev import _find_app

        (tmp_path / "src" / "app").mkdir(parents=True)
        (tmp_path / "src" / "app" / "__init__.py").write_text("app = None")

        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            result = _find_app()

        assert result == "src.app:app"

    def test_find_app_with_main_py(self, tmp_path: Path) -> None:
        """_find_app should find main.py."""
        from framework_m_studio.cli.dev import _find_app

        (tmp_path / "main.py").write_text("app = None")

        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            result = _find_app()

        assert result == "main:app"

    def test_find_app_with_main_py_without_app_falls_back(self, tmp_path: Path) -> None:
        """_find_app should not select main.py if it has no ASGI symbol."""
        from framework_m_studio.cli.dev import _find_app

        (tmp_path / "main.py").write_text(
            'def main():\n    print("hello")\n\nif __name__ == "__main__":\n    main()\n'
        )

        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            result = _find_app()

        assert result == "framework_m_standard.adapters.web.app:create_app"

    def test_find_app_prefers_create_app_factory(self, tmp_path: Path) -> None:
        """_find_app should use create_app when app variable is absent."""
        from framework_m_studio.cli.dev import _find_app

        (tmp_path / "app.py").write_text("def create_app():\n    return object()\n")

        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            result = _find_app()

        assert result == "app:create_app"

    def test_find_app_default_fallback(self, tmp_path: Path) -> None:
        """_find_app should return framework standard app when nothing found."""
        from framework_m_studio.cli.dev import _find_app

        with patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path):
            result = _find_app()

        assert result == "framework_m_standard.adapters.web.app:create_app"


class TestCheckFrontendExists:
    """Tests for _check_frontend_exists function."""

    def test_check_frontend_exists_true(self, tmp_path: Path) -> None:
        """_check_frontend_exists should return True when valid."""
        from framework_m_studio.cli.dev import _check_frontend_exists

        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()
        (frontend_dir / "package.json").write_text("{}")

        assert _check_frontend_exists(frontend_dir) is True

    def test_check_frontend_exists_no_dir(self, tmp_path: Path) -> None:
        """_check_frontend_exists should return False when dir missing."""
        from framework_m_studio.cli.dev import _check_frontend_exists

        frontend_dir = tmp_path / "frontend"
        assert _check_frontend_exists(frontend_dir) is False

    def test_check_frontend_exists_no_package_json(self, tmp_path: Path) -> None:
        """_check_frontend_exists should return False when no package.json."""
        from framework_m_studio.cli.dev import _check_frontend_exists

        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()
        assert _check_frontend_exists(frontend_dir) is False


class TestDevCommand:
    """Tests for dev_command function."""

    def test_dev_command_is_callable(self) -> None:
        """dev_command should be callable."""
        from framework_m_studio.cli.dev import dev_command

        assert callable(dev_command)

    def test_dev_command_creates_backend_process(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """dev_command should create backend process."""
        from framework_m_studio.cli.dev import dev_command

        # Create frontend directory
        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()
        (frontend_dir / "package.json").write_text("{}")

        mock_manager = MagicMock()

        with (
            patch("framework_m_studio.cli.dev.Manager", return_value=mock_manager),
            patch("framework_m_studio.cli.dev.Printer"),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
        ):
            dev_command(frontend_dir=frontend_dir)

        # Check manager.add_process was called with backend
        calls = mock_manager.add_process.call_args_list
        process_names = [call[0][0] for call in calls]
        assert "backend" in process_names

    def test_dev_command_creates_frontend_process(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """dev_command should create frontend process when exists."""
        from framework_m_studio.cli.dev import dev_command

        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()
        (frontend_dir / "package.json").write_text("{}")

        mock_manager = MagicMock()

        with (
            patch("framework_m_studio.cli.dev.Manager", return_value=mock_manager),
            patch("framework_m_studio.cli.dev.Printer"),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
        ):
            dev_command(frontend_dir=frontend_dir)

        calls = mock_manager.add_process.call_args_list
        process_names = [call[0][0] for call in calls]
        assert "frontend" in process_names

    def test_dev_command_skips_frontend_when_no_frontend(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """dev_command should skip frontend when no_frontend=True."""
        from framework_m_studio.cli.dev import dev_command

        mock_manager = MagicMock()

        with (
            patch("framework_m_studio.cli.dev.Manager", return_value=mock_manager),
            patch("framework_m_studio.cli.dev.Printer"),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
        ):
            dev_command(no_frontend=True)

        calls = mock_manager.add_process.call_args_list
        process_names = [call[0][0] for call in calls]
        assert "frontend" not in process_names
        assert "backend" in process_names

    def test_dev_command_adds_studio_when_flag_set(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """dev_command should add studio when --studio flag set."""
        from framework_m_studio.cli.dev import dev_command

        mock_manager = MagicMock()

        with (
            patch("framework_m_studio.cli.dev.Manager", return_value=mock_manager),
            patch("framework_m_studio.cli.dev.Printer"),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
        ):
            dev_command(no_frontend=True, studio=True)

        calls = mock_manager.add_process.call_args_list
        process_names = [call[0][0] for call in calls]
        assert "studio" in process_names

    def test_dev_command_prints_startup_info(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """dev_command should print startup information."""
        from framework_m_studio.cli.dev import dev_command

        mock_manager = MagicMock()

        with (
            patch("framework_m_studio.cli.dev.Manager", return_value=mock_manager),
            patch("framework_m_studio.cli.dev.Printer"),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
        ):
            dev_command(no_frontend=True)

        captured = capsys.readouterr()
        assert "Backend" in captured.out
        assert "8888" in captured.out

    def test_dev_command_custom_ports(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """dev_command should use custom ports."""
        from framework_m_studio.cli.dev import dev_command

        mock_manager = MagicMock()

        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()
        (frontend_dir / "package.json").write_text("{}")

        with (
            patch("framework_m_studio.cli.dev.Manager", return_value=mock_manager),
            patch("framework_m_studio.cli.dev.Printer"),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
        ):
            dev_command(
                port=9000,
                frontend_port=3000,
                frontend_dir=frontend_dir,
            )

        captured = capsys.readouterr()
        assert "9000" in captured.out
        assert "3000" in captured.out

    def test_dev_command_calls_manager_loop(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """dev_command should call manager.loop()."""
        from framework_m_studio.cli.dev import dev_command

        mock_manager = MagicMock()

        with (
            patch("framework_m_studio.cli.dev.Manager", return_value=mock_manager),
            patch("framework_m_studio.cli.dev.Printer"),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
        ):
            dev_command(no_frontend=True)

        mock_manager.loop.assert_called_once()

    def test_dev_command_warns_missing_frontend(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """dev_command should warn when frontend missing."""
        from framework_m_studio.cli.dev import dev_command

        mock_manager = MagicMock()

        with (
            patch("framework_m_studio.cli.dev.Manager", return_value=mock_manager),
            patch("framework_m_studio.cli.dev.Printer"),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
        ):
            dev_command(frontend_dir=tmp_path / "nonexistent")

        captured = capsys.readouterr()
        assert "not found" in captured.out.lower() or "skipping" in captured.out.lower()

    def test_dev_command_missing_frontend_sets_backend_static_mode(
        self, tmp_path: Path
    ) -> None:
        """When frontend is missing, backend should serve static UI (M_DEV_MODE=false)."""
        from framework_m_studio.cli.dev import dev_command

        mock_manager = MagicMock()

        with (
            patch("framework_m_studio.cli.dev.Manager", return_value=mock_manager),
            patch("framework_m_studio.cli.dev.Printer"),
            patch("framework_m_studio.cli.dev.Path.cwd", return_value=tmp_path),
        ):
            dev_command(frontend_dir=tmp_path / "missing-frontend")

        backend_call = next(
            call
            for call in mock_manager.add_process.call_args_list
            if call.args and call.args[0] == "backend"
        )
        env = backend_call.kwargs.get("env", {})
        assert env.get("M_DEV_MODE") == "false"


class TestDevExports:
    """Tests for dev module exports."""

    def test_all_exports(self) -> None:
        """dev module should export expected items."""
        from framework_m_studio.cli import dev

        assert "dev_command" in dev.__all__


class TestDevSignalHandling:
    """Tests for signal handling in dev command."""

    def test_signal_handler_terminates_manager(self) -> None:
        """Signal handler should terminate manager."""
        from framework_m_studio.cli.dev import dev_command

        mock_manager = MagicMock()
        signal_handler_called = []

        original_signal = signal.signal

        def capture_signal(signum: int, handler: object) -> object:
            if signum in (signal.SIGINT, signal.SIGTERM):
                signal_handler_called.append((signum, handler))
            return original_signal(signum, handler)

        with (
            patch("framework_m_studio.cli.dev.Manager", return_value=mock_manager),
            patch("framework_m_studio.cli.dev.Printer"),
            patch("signal.signal", side_effect=capture_signal),
        ):
            dev_command(no_frontend=True)

        # Check that signal handlers were registered
        assert len(signal_handler_called) >= 2


class TestDevCommandExecution:
    """Tests for dev command CLI execution."""

    def test_dev_help(self) -> None:
        """dev --help should work."""
        import subprocess

        result = subprocess.run(
            [sys.executable, "-m", "framework_m_core.cli.main", "dev", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "dev" in result.stdout.lower() or "start" in result.stdout.lower()
