"""Tests for Build CLI Commands - Comprehensive Coverage."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest


class TestBuildImport:
    """Tests for build module imports."""

    def test_import_build_command(self) -> None:
        """build_command should be importable."""
        from framework_m_studio.cli.build import build_command

        assert build_command is not None

    def test_import_build_docker_command(self) -> None:
        """build_docker_command should be importable."""
        from framework_m_studio.cli.build import build_docker_command

        assert build_docker_command is not None


class TestGetDefaultImageName:
    """Tests for get_default_image_name function."""

    def test_get_default_image_name_returns_string(self) -> None:
        """get_default_image_name should return a string."""
        from framework_m_studio.cli.build import get_default_image_name

        result = get_default_image_name()
        assert isinstance(result, str)
        assert ":" in result  # Should have name:tag format

    def test_get_default_image_name_from_config(self) -> None:
        """get_default_image_name should read from config."""
        from framework_m_studio.cli.build import get_default_image_name

        mock_config: dict[str, Any] = {
            "framework": {"name": "myapp", "version": "1.0.0"}
        }

        with patch(
            "framework_m_studio.cli.build.load_config", return_value=mock_config
        ):
            result = get_default_image_name()

        assert "myapp" in result
        assert "1.0.0" in result

    def test_get_default_image_name_defaults(self) -> None:
        """get_default_image_name should use defaults if no config."""
        from framework_m_studio.cli.build import get_default_image_name

        with patch("framework_m_studio.cli.build.load_config", return_value={}):
            result = get_default_image_name()

        assert "framework-m-app" in result
        assert "latest" in result


class TestBuildDockerCmd:
    """Tests for build_docker_cmd function."""

    def test_build_docker_cmd_basic(self) -> None:
        """build_docker_cmd should build basic docker command."""
        from framework_m_studio.cli.build import build_docker_cmd

        cmd = build_docker_cmd(tag="myapp:v1")

        assert "docker" in cmd[0]
        assert "build" in cmd
        assert "-t" in cmd
        assert "myapp:v1" in cmd

    def test_build_docker_cmd_with_dockerfile(self) -> None:
        """build_docker_cmd should include dockerfile path."""
        from framework_m_studio.cli.build import build_docker_cmd

        cmd = build_docker_cmd(tag="myapp:v1", dockerfile="custom.Dockerfile")

        assert "-f" in cmd
        assert "custom.Dockerfile" in cmd

    def test_build_docker_cmd_no_cache(self) -> None:
        """build_docker_cmd should add --no-cache flag."""
        from framework_m_studio.cli.build import build_docker_cmd

        cmd = build_docker_cmd(tag="myapp:v1", no_cache=True)

        assert "--no-cache" in cmd

    def test_build_docker_cmd_with_build_args(self) -> None:
        """build_docker_cmd should add build args."""
        from framework_m_studio.cli.build import build_docker_cmd

        cmd = build_docker_cmd(tag="myapp:v1", build_args=["VERSION=1.0"])

        assert "--build-arg" in cmd
        assert "VERSION=1.0" in cmd

    def test_build_docker_cmd_context(self) -> None:
        """build_docker_cmd should include context path."""
        from framework_m_studio.cli.build import build_docker_cmd

        cmd = build_docker_cmd(tag="myapp:v1", context="./app")

        assert "./app" in cmd


class TestBuildCommand:
    """Tests for build_command function."""

    def test_build_command_is_callable(self) -> None:
        """build_command should be callable."""
        from framework_m_studio.cli.build import build_command

        assert callable(build_command)

    def test_build_command_no_package_json(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """build_command should show message when no package.json."""
        from framework_m_studio.cli.build import build_command

        with patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path):
            build_command(mode="production", output=Path("dist"))

        captured = capsys.readouterr()
        # Implementation returns early with warning
        assert "no frontend directory found" in captured.out.lower()

    def test_build_command_with_package_json_npm_success(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """build_command should run npm build when package.json exists in frontend/."""
        from framework_m_studio.cli.build import build_command

        # Create frontend subdirectory with package.json
        # The build command looks in Path.cwd() / "frontend" for package.json
        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()
        package_json = frontend_dir / "package.json"
        package_json.write_text('{"name": "test"}')

        mock_run = MagicMock()

        with (
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
            patch("subprocess.run", mock_run),
        ):
            build_command(mode="production", output=Path("dist"))

        # subprocess.run is called multiple times: pnpm --version, pnpm install, pnpm run build
        assert mock_run.called
        captured = capsys.readouterr()
        # Expect some build-related output (e.g., "running" or build info)
        assert "running" in captured.out.lower() or "build" in captured.out.lower()

    def test_build_command_npm_not_found(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """build_command should handle npm not found."""
        from framework_m_studio.cli.build import build_command

        package_json = tmp_path / "package.json"
        package_json.write_text('{"name": "test"}')

        with (
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
            patch("subprocess.run", side_effect=FileNotFoundError()),
        ):
            build_command(mode="production", output=Path("dist"))
            # Should return early because frontend dir detection logic might fail if not mocked precisely
            # or if it falls through to the try/except block

    def test_build_command_npm_build_fails(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """build_command should handle npm build failure."""
        from framework_m_studio.cli.build import build_command

        package_json = tmp_path / "package.json"
        package_json.write_text('{"name": "test"}')

        with (
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
            patch(
                "subprocess.run",
                side_effect=subprocess.CalledProcessError(1, ["npm"]),
            ),
        ):
            build_command(mode="production", output=Path("dist"))


class TestBuildDockerCommand:
    """Tests for build_docker_command function."""

    def test_build_docker_command_is_callable(self) -> None:
        """build_docker_command should be callable."""
        from framework_m_studio.cli.build import build_docker_command

        assert callable(build_docker_command)

    def test_build_docker_command_no_dockerfile(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """build_docker_command should fail when no Dockerfile."""
        from framework_m_studio.cli.build import build_docker_command

        with pytest.raises(SystemExit) as exc:
            build_docker_command(
                tag=None,
                dockerfile=str(tmp_path / "nonexistent"),
                context=".",
                no_cache=False,
                push=False,
            )
        assert exc.value.code == 1

        captured = capsys.readouterr()
        assert "not found" in captured.err.lower()

    def test_build_docker_command_success(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """build_docker_command should run docker build."""
        from framework_m_studio.cli.build import build_docker_command

        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("FROM python:3.12")

        mock_run = MagicMock()
        mock_run.return_value.returncode = 0

        with patch("subprocess.run", mock_run):
            build_docker_command(
                tag="myapp:v1",
                dockerfile=str(dockerfile),
                context=".",
                no_cache=False,
                push=False,
            )

        captured = capsys.readouterr()
        assert "Docker Build" in captured.out
        assert "myapp:v1" in captured.out

    def test_build_docker_command_with_push(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """build_docker_command should push when requested."""
        from framework_m_studio.cli.build import build_docker_command

        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("FROM python:3.12")

        mock_run = MagicMock()
        mock_run.return_value.returncode = 0

        with patch("subprocess.run", mock_run):
            build_docker_command(
                tag="myapp:v1",
                dockerfile=str(dockerfile),
                context=".",
                no_cache=False,
                push=True,
            )

        # Should be called twice: build and push
        assert mock_run.call_count == 2
        captured = capsys.readouterr()
        assert "Pushing" in captured.out

    def test_build_docker_command_docker_not_found(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """build_docker_command should handle docker not found."""
        from framework_m_studio.cli.build import build_docker_command

        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("FROM python:3.12")

        with patch("subprocess.run", side_effect=FileNotFoundError()):
            with pytest.raises(SystemExit) as exc:
                build_docker_command(
                    tag="myapp:v1",
                    dockerfile=str(dockerfile),
                    context=".",
                    no_cache=False,
                    push=False,
                )
            assert exc.value.code == 1

    def test_build_docker_command_build_fails(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """build_docker_command should handle build failure."""
        from framework_m_studio.cli.build import build_docker_command

        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("FROM python:3.12")

        mock_run = MagicMock()
        mock_run.return_value.returncode = 1

        with patch("subprocess.run", mock_run):
            with pytest.raises(SystemExit) as exc:
                build_docker_command(
                    tag="myapp:v1",
                    dockerfile=str(dockerfile),
                    context=".",
                    no_cache=False,
                    push=False,
                )
            assert exc.value.code == 1


class TestBuildExecution:
    """Tests for build command execution."""

    def test_build_help(self) -> None:
        """build --help should work."""
        result = subprocess.run(
            [sys.executable, "-m", "framework_m_core.cli.main", "build", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0

    def test_build_docker_help(self) -> None:
        """build:docker --help should work."""
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "framework_m_core.cli.main",
                "build:docker",
                "--help",
            ],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        # assert "docker" in result.stdout.lower()


class TestBuildExports:
    """Tests for build module exports."""

    def test_all_exports(self) -> None:
        """build module should export expected items."""
        from framework_m_studio.cli import build

        assert "build_command" in build.__all__
        assert "build_docker_command" in build.__all__


class TestDiscoverFrontendPlugins:
    """Tests for discover_frontend_plugins function - Phase 1 Implementation."""

    def test_discover_frontend_plugins_no_plugins(self, tmp_path: Path) -> None:
        """Should return empty list when no plugins found."""
        from framework_m_studio.cli.build import discover_frontend_plugins

        with (
            patch("importlib.metadata.entry_points", return_value=[]),
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
        ):
            plugins = discover_frontend_plugins()

        assert plugins == []

    def test_discover_local_apps(self, tmp_path: Path) -> None:
        """Should discover plugins from local apps/ directory."""
        from framework_m_studio.cli.build import discover_frontend_plugins

        # Create mock apps structure
        apps_dir = tmp_path / "apps"
        apps_dir.mkdir()

        app1 = apps_dir / "custom_app"
        app1.mkdir()
        (app1 / "frontend").mkdir()
        (app1 / "frontend" / "index.ts").write_text("// Plugin 1")

        app2 = apps_dir / "wms_app"
        app2.mkdir()
        (app2 / "frontend").mkdir()
        (app2 / "frontend" / "index.ts").write_text("// Plugin 2")

        with (
            patch("importlib.metadata.entry_points", return_value=[]),
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
        ):
            plugins = discover_frontend_plugins()

        assert len(plugins) == 2
        assert any(p["name"] == "custom_app" for p in plugins)
        assert any(p["name"] == "wms_app" for p in plugins)
        assert all(p["source"] == "local" for p in plugins)
        assert all(p["package"] is None for p in plugins)

    def test_discover_installed_plugins(self) -> None:
        """Should discover plugins from Python entry points."""
        from framework_m_studio.cli.build import discover_frontend_plugins

        # Mock entry point
        mock_ep = MagicMock()
        mock_ep.name = "business_m"
        mock_ep.module = "business_m.frontend:plugin"

        # Mock importlib.resources
        mock_files = MagicMock()
        mock_frontend = MagicMock()
        mock_frontend.is_dir.return_value = True
        mock_index = MagicMock()
        mock_index.is_file.return_value = True
        mock_index.__str__.return_value = "/path/to/business_m/frontend/index.ts"
        mock_frontend.__truediv__.return_value = mock_index
        mock_files.__truediv__.return_value = mock_frontend

        with (
            patch("importlib.metadata.entry_points", return_value=[mock_ep]),
            patch("importlib.resources.files", return_value=mock_files),
            patch(
                "framework_m_studio.cli.build.Path.cwd",
                return_value=Path("/nonexistent"),
            ),
        ):
            plugins = discover_frontend_plugins()

        assert len(plugins) == 1
        assert plugins[0]["name"] == "business_m"
        assert plugins[0]["source"] == "installed"
        assert plugins[0]["package"] == "business_m"

    def test_discover_mixed_sources(self, tmp_path: Path) -> None:
        """Should discover from both entry points and local apps."""
        from framework_m_studio.cli.build import discover_frontend_plugins

        # Local app
        apps_dir = tmp_path / "apps"
        apps_dir.mkdir()
        local = apps_dir / "local_app"
        local.mkdir()
        (local / "frontend").mkdir()
        (local / "frontend" / "index.ts").write_text("// Local")

        # Entry point
        mock_ep = MagicMock()
        mock_ep.name = "installed_app"
        mock_ep.module = "installed_app.frontend:plugin"

        mock_files = MagicMock()
        mock_frontend = MagicMock()
        mock_frontend.is_dir.return_value = True
        mock_index = MagicMock()
        mock_index.is_file.return_value = True
        mock_index.__str__.return_value = "/path/to/installed_app/frontend/index.ts"
        mock_frontend.__truediv__.return_value = mock_index
        mock_files.__truediv__.return_value = mock_frontend

        with (
            patch("importlib.metadata.entry_points", return_value=[mock_ep]),
            patch("importlib.resources.files", return_value=mock_files),
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
        ):
            plugins = discover_frontend_plugins()

        assert len(plugins) == 2
        sources = {p["source"] for p in plugins}
        assert "local" in sources
        assert "installed" in sources


class TestGeneratePluginEntry:
    """Tests for _generate_plugin_entry function - Phase 2 Implementation."""

    def test_generate_entry_local_plugins(self, tmp_path: Path) -> None:
        """Should generate entry file with relative imports for local plugins."""
        from framework_m_studio.cli.build import (
            FrontendPluginInfo,
            _generate_plugin_entry,
        )

        # Create mock plugin paths
        plugin_dir = tmp_path / "apps" / "test_app" / "frontend"
        plugin_dir.mkdir(parents=True)
        index_file = plugin_dir / "index.ts"
        index_file.write_text("export const register = () => {};")

        plugins: list[FrontendPluginInfo] = [
            FrontendPluginInfo(
                name="test_app",
                path=index_file,
                source="local",
                package=None,
            )
        ]

        entry_file = tmp_path / ".m" / "entry.tsx"
        entry_file.parent.mkdir(parents=True, exist_ok=True)

        with patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path):
            _generate_plugin_entry(entry_file, plugins)

        content = entry_file.read_text()

        # Should use relative import
        assert "../../apps/test_app/frontend/index.ts" in content
        assert "register_test_app" in content
        assert "registerAllPlugins" in content

    def test_generate_entry_installed_plugins(self, tmp_path: Path) -> None:
        """Should generate entry file with package imports for installed plugins."""
        from framework_m_studio.cli.build import (
            FrontendPluginInfo,
            _generate_plugin_entry,
        )

        plugins: list[FrontendPluginInfo] = [
            FrontendPluginInfo(
                name="business_m",
                path=Path("/installed/business_m/frontend/index.ts"),
                source="installed",
                package="business_m",
            )
        ]

        entry_file = tmp_path / "entry.tsx"
        _generate_plugin_entry(entry_file, plugins)

        content = entry_file.read_text()

        # Should use package import with alias
        assert "@business_m/frontend" in content
        assert "register_business_m" in content
        assert "registerAllPlugins" in content

    def test_generate_entry_mixed_plugins(self, tmp_path: Path) -> None:
        """Should handle both local and installed plugins in one entry."""
        from framework_m_studio.cli.build import (
            FrontendPluginInfo,
            _generate_plugin_entry,
        )

        # Local plugin
        local_dir = tmp_path / "apps" / "local_app" / "frontend"
        local_dir.mkdir(parents=True)
        local_index = local_dir / "index.ts"
        local_index.write_text("export const register = () => {};")

        plugins: list[FrontendPluginInfo] = [
            FrontendPluginInfo(
                name="business_m",
                path=Path("/installed/business_m/frontend/index.ts"),
                source="installed",
                package="business_m",
            ),
            FrontendPluginInfo(
                name="local_app",
                path=local_index,
                source="local",
                package=None,
            ),
        ]

        entry_file = tmp_path / ".m" / "entry.tsx"
        entry_file.parent.mkdir(parents=True, exist_ok=True)

        with patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path):
            _generate_plugin_entry(entry_file, plugins)

        content = entry_file.read_text()

        # Should have both import styles
        assert "@business_m/frontend" in content
        assert "../../apps/local_app/frontend/index.ts" in content
        assert "register_business_m" in content
        assert "register_local_app" in content


class TestGenerateViteConfig:
    """Tests for _generate_vite_config function - Phase 3 Implementation."""

    def test_generate_vite_config_no_installed(self, tmp_path: Path) -> None:
        """Should generate minimal config when no installed plugins."""
        from framework_m_studio.cli.build import (
            FrontendPluginInfo,
            _generate_vite_config,
        )

        # Only local plugin
        plugins: list[FrontendPluginInfo] = [
            FrontendPluginInfo(
                name="local_app",
                path=tmp_path / "apps" / "local_app" / "frontend" / "index.ts",
                source="local",
                package=None,
            )
        ]

        config_file = tmp_path / "vite.config.ts"
        _generate_vite_config(config_file, plugins)

        content = config_file.read_text()

        # Should have empty alias section
        assert "defineConfig" in content
        assert "resolve" in content
        assert "alias" in content

    def test_generate_vite_config_with_installed(self, tmp_path: Path) -> None:
        """Should generate alias config for installed plugins."""
        from framework_m_studio.cli.build import (
            FrontendPluginInfo,
            _generate_vite_config,
        )

        # Installed plugin
        frontend_dir = Path("/installed/business_m/frontend")
        plugins: list[FrontendPluginInfo] = [
            FrontendPluginInfo(
                name="business_m",
                path=frontend_dir / "index.ts",
                source="installed",
                package="business_m",
            )
        ]

        config_file = tmp_path / "vite.config.ts"
        _generate_vite_config(config_file, plugins)

        content = config_file.read_text()

        # Should have alias mapping
        assert "defineConfig" in content
        assert "@business_m/frontend" in content
        assert str(frontend_dir) in content

    def test_generate_vite_config_multiple_installed(self, tmp_path: Path) -> None:
        """Should generate aliases for multiple installed plugins."""
        from framework_m_studio.cli.build import (
            FrontendPluginInfo,
            _generate_vite_config,
        )

        plugins: list[FrontendPluginInfo] = [
            FrontendPluginInfo(
                name="business_m",
                path=Path("/installed/business_m/frontend/index.ts"),
                source="installed",
                package="business_m",
            ),
            FrontendPluginInfo(
                name="wms_app",
                path=Path("/installed/wms_app/frontend/index.ts"),
                source="installed",
                package="wms_app",
            ),
        ]

        config_file = tmp_path / "vite.config.ts"
        _generate_vite_config(config_file, plugins)

        content = config_file.read_text()

        # Should have both aliases
        assert "@business_m/frontend" in content
        assert "@wms_app/frontend" in content
        assert "/installed/business_m/frontend" in content
        assert "/installed/wms_app/frontend" in content


class TestPluginDiscoveryIntegration:
    """Integration tests for multi-package plugin discovery - Phase 6."""

    def test_discover_plugins_empty_workspace(self, tmp_path: Path) -> None:
        """Should handle empty workspace gracefully."""
        from framework_m_studio.cli.build import discover_frontend_plugins

        with (
            patch("importlib.metadata.entry_points", return_value=[]),
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
        ):
            plugins = discover_frontend_plugins()

        assert plugins == []

    def test_discover_plugins_no_apps_dir(self, tmp_path: Path) -> None:
        """Should handle missing apps/ directory."""
        from framework_m_studio.cli.build import discover_frontend_plugins

        # No apps/ directory exists
        with (
            patch("importlib.metadata.entry_points", return_value=[]),
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
        ):
            plugins = discover_frontend_plugins()

        assert plugins == []

    def test_discover_plugins_app_without_frontend(self, tmp_path: Path) -> None:
        """Should skip apps without frontend directory."""
        from framework_m_studio.cli.build import discover_frontend_plugins

        apps_dir = tmp_path / "apps"
        apps_dir.mkdir()
        no_frontend_app = apps_dir / "no_frontend"
        no_frontend_app.mkdir()
        # No frontend/ subdirectory

        with (
            patch("importlib.metadata.entry_points", return_value=[]),
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
        ):
            plugins = discover_frontend_plugins()

        assert plugins == []

    def test_discover_plugins_deduplication(self, tmp_path: Path) -> None:
        """Should handle duplicate plugin names (last one wins)."""
        from framework_m_studio.cli.build import discover_frontend_plugins

        # Local app with same name as installed
        apps_dir = tmp_path / "apps"
        apps_dir.mkdir()
        local = apps_dir / "business_m"
        local.mkdir()
        (local / "frontend").mkdir()
        (local / "frontend" / "index.ts").write_text("// Local override")

        # Installed plugin
        mock_ep = MagicMock()
        mock_ep.name = "business_m"
        mock_ep.module = "business_m.frontend:plugin"

        mock_files = MagicMock()
        mock_frontend = MagicMock()
        mock_frontend.is_dir.return_value = True
        mock_index = MagicMock()
        mock_index.is_file.return_value = True
        mock_index.__str__.return_value = "/installed/business_m/frontend/index.ts"
        mock_frontend.__truediv__.return_value = mock_index
        mock_files.__truediv__.return_value = mock_frontend

        with (
            patch("importlib.metadata.entry_points", return_value=[mock_ep]),
            patch("importlib.resources.files", return_value=mock_files),
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
        ):
            plugins = discover_frontend_plugins()

        # Should have both (no automatic deduplication)
        assert len(plugins) == 2
        names = [p["name"] for p in plugins]
        assert names.count("business_m") == 2

    def test_discover_plugins_entry_point_error_handling(self, tmp_path: Path) -> None:
        """Should handle entry point errors gracefully."""
        from framework_m_studio.cli.build import discover_frontend_plugins

        # Mock failing entry point
        def failing_entry_points(group: str):
            raise RuntimeError("Entry point system error")

        with (
            patch("importlib.metadata.entry_points", side_effect=failing_entry_points),
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
        ):
            plugins = discover_frontend_plugins()

        # Should continue and return empty list (no crash)
        assert plugins == []

    def test_discover_plugins_multiple_local_apps(self, tmp_path: Path) -> None:
        """Should discover all local apps in apps/ directory."""
        from framework_m_studio.cli.build import discover_frontend_plugins

        apps_dir = tmp_path / "apps"
        apps_dir.mkdir()

        # Create 3 apps
        for app_name in ["app1", "app2", "app3"]:
            app_dir = apps_dir / app_name
            app_dir.mkdir()
            (app_dir / "frontend").mkdir()
            (app_dir / "frontend" / "index.ts").write_text(f"// {app_name}")

        with (
            patch("importlib.metadata.entry_points", return_value=[]),
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
        ):
            plugins = discover_frontend_plugins()

        assert len(plugins) == 3
        names = {p["name"] for p in plugins}
        assert names == {"app1", "app2", "app3"}

    def test_discover_plugins_installed_missing_frontend(self) -> None:
        """Should skip installed plugins with no frontend source."""
        from framework_m_studio.cli.build import discover_frontend_plugins

        # Mock entry point for package without frontend
        mock_ep = MagicMock()
        mock_ep.name = "no_frontend_pkg"
        mock_ep.module = "no_frontend_pkg.backend:app"

        # Mock importlib.resources to return non-existent frontend
        mock_files = MagicMock()
        mock_frontend = MagicMock()
        mock_frontend.is_dir.return_value = False  # No frontend dir
        mock_files.__truediv__.return_value = mock_frontend

        with (
            patch("importlib.metadata.entry_points", return_value=[mock_ep]),
            patch("importlib.resources.files", return_value=mock_files),
            patch(
                "framework_m_studio.cli.build.Path.cwd",
                return_value=Path("/nonexistent"),
            ),
        ):
            plugins = discover_frontend_plugins()

        # Should skip package without frontend
        assert plugins == []


class TestBuildPluginModeIntegration:
    """Integration tests for _build_plugin_mode - Phase 6."""

    def test_build_plugin_mode_fallback_to_indie(self, tmp_path: Path) -> None:
        """Should fall back to indie mode when no plugins found."""
        from framework_m_studio.cli.build import _build_plugin_mode

        # Workspace with no plugins
        output = tmp_path / "output"

        with (
            patch(
                "framework_m_studio.cli.build.discover_frontend_plugins",
                return_value=[],
            ),
            patch("framework_m_studio.cli.build._build_indie_mode") as mock_indie,
        ):
            _build_plugin_mode("production", output)

        # Should call indie mode
        mock_indie.assert_called_once_with("production", output)

    def test_build_plugin_mode_missing_base_frontend(self, tmp_path: Path) -> None:
        """Should exit if frontend/package.json missing."""
        from framework_m_studio.cli.build import (
            FrontendPluginInfo,
            _build_plugin_mode,
        )

        plugins: list[FrontendPluginInfo] = [
            FrontendPluginInfo(
                name="test_app",
                path=tmp_path / "apps" / "test" / "frontend" / "index.ts",
                source="local",
                package=None,
            )
        ]

        with (
            patch(
                "framework_m_studio.cli.build.discover_frontend_plugins",
                return_value=plugins,
            ),
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
            pytest.raises(SystemExit) as exc_info,
        ):
            _build_plugin_mode("production", tmp_path / "output")

        assert exc_info.value.code == 1

    def test_build_plugin_mode_generates_files(self, tmp_path: Path) -> None:
        """Should generate entry and config files."""
        from framework_m_studio.cli.build import (
            FrontendPluginInfo,
            _build_plugin_mode,
        )

        # Setup
        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()
        (frontend_dir / "package.json").write_text('{"name": "frontend"}')
        (frontend_dir / "node_modules").mkdir()

        local_app = tmp_path / "apps" / "test_app"
        local_app.mkdir(parents=True)
        (local_app / "frontend").mkdir()
        (local_app / "frontend" / "index.ts").write_text(
            "export const register = () => {};"
        )

        plugins: list[FrontendPluginInfo] = [
            FrontendPluginInfo(
                name="test_app",
                path=local_app / "frontend" / "index.ts",
                source="local",
                package=None,
            )
        ]

        with (
            patch(
                "framework_m_studio.cli.build.discover_frontend_plugins",
                return_value=plugins,
            ),
            patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path),
            patch("framework_m_studio.cli.build._has_command", return_value=True),
            patch("subprocess.run"),
        ):
            _build_plugin_mode("production", tmp_path / "output")

        # Check generated files
        entry_file = tmp_path / ".m" / "build" / "entry.tsx"
        config_file = tmp_path / ".m" / "build" / "vite.config.ts"

        assert entry_file.exists()
        assert config_file.exists()

        # Verify entry content
        entry_content = entry_file.read_text()
        assert "register_test_app" in entry_content
        assert "registerAllPlugins" in entry_content

    def test_build_plugin_mode_preserves_plugin_order(self, tmp_path: Path) -> None:
        """Should preserve plugin registration order (entry points first, then local)."""
        from framework_m_studio.cli.build import (
            FrontendPluginInfo,
            _generate_plugin_entry,
        )

        plugins: list[FrontendPluginInfo] = [
            FrontendPluginInfo(
                name="base_pkg",
                path=Path("/installed/base/frontend/index.ts"),
                source="installed",
                package="base_pkg",
            ),
            FrontendPluginInfo(
                name="custom_app",
                path=tmp_path / "apps" / "custom" / "frontend" / "index.ts",
                source="local",
                package=None,
            ),
        ]

        entry_file = tmp_path / "entry.tsx"

        with patch("framework_m_studio.cli.build.Path.cwd", return_value=tmp_path):
            _generate_plugin_entry(entry_file, plugins)

        content = entry_file.read_text()

        # Check order in registration calls
        base_idx = content.find("register_base_pkg()")
        custom_idx = content.find("register_custom_app()")

        # base_pkg should be registered before custom_app
        assert base_idx < custom_idx
