"""Tests for Protocol Scanner module.

Tests for auto-generating Protocol reference documentation.
"""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent


class TestProtocolScanner:
    """Tests for protocol_scanner module."""

    def test_parse_protocol_file(self, tmp_path: Path) -> None:
        """parse_protocol_file should extract Protocol info."""
        from framework_m_studio.protocol_scanner import parse_protocol_file

        code = dedent('''
            """Repository Protocol - Core interface for data access."""
            
            from typing import Protocol, TypeVar
            
            T = TypeVar("T")
            
            
            class RepositoryProtocol(Protocol[T]):
                """Protocol for data repositories.
                
                Implementations:
                - SQLAlchemyRepository: For SQL databases
                - MongoRepository: For MongoDB
                """
                
                async def get(self, id: str) -> T | None:
                    """Get an entity by ID."""
                    ...
                
                async def save(self, entity: T) -> T:
                    """Save an entity."""
                    ...
        ''')

        file_path = tmp_path / "repository.py"
        file_path.write_text(code)

        protocols = parse_protocol_file(file_path)

        assert len(protocols) == 1
        proto = protocols[0]
        assert proto["name"] == "RepositoryProtocol"
        assert "Protocol for data repositories" in proto["docstring"]
        assert len(proto["methods"]) == 2
        assert proto["methods"][0]["name"] == "get"
        assert proto["methods"][1]["name"] == "save"

    def test_parse_protocol_extracts_adapters(self, tmp_path: Path) -> None:
        """parse_protocol_file should extract adapter names from docstring."""
        from framework_m_studio.protocol_scanner import parse_protocol_file

        code = dedent('''
            from typing import Protocol
            
            
            class CacheProtocol(Protocol):
                """Protocol for caching.
                
                Implementations:
                - RedisCache: Using Redis
                - MemoryCache: In-memory for testing
                - NullCache: No-op for development
                """
                
                async def get(self, key: str) -> str | None: ...
        ''')

        file_path = tmp_path / "cache.py"
        file_path.write_text(code)

        protocols = parse_protocol_file(file_path)

        assert len(protocols) == 1
        adapters = protocols[0]["adapters"]
        assert "RedisCache" in adapters
        assert "MemoryCache" in adapters
        assert "NullCache" in adapters

    def test_scan_protocols_directory(self, tmp_path: Path) -> None:
        """scan_protocols should find all Protocol files."""
        from framework_m_studio.protocol_scanner import scan_protocols

        # Create interfaces directory
        interfaces_dir = tmp_path / "interfaces"
        interfaces_dir.mkdir()

        # Create two protocol files
        (interfaces_dir / "repository.py").write_text(
            dedent('''
            from typing import Protocol
            class RepositoryProtocol(Protocol):
                """Repository protocol."""
                async def get(self, id: str) -> None: ...
        ''')
        )

        (interfaces_dir / "cache.py").write_text(
            dedent('''
            from typing import Protocol
            class CacheProtocol(Protocol):
                """Cache protocol."""
                async def get(self, key: str) -> str | None: ...
        ''')
        )

        protocols = scan_protocols(interfaces_dir)

        assert len(protocols) == 2
        names = [p["name"] for p in protocols]
        assert "RepositoryProtocol" in names
        assert "CacheProtocol" in names

    def test_generate_protocol_markdown(self) -> None:
        """generate_protocol_markdown should create proper docs."""
        from framework_m_studio.protocol_scanner import generate_protocol_markdown

        protocol_info = {
            "name": "CacheProtocol",
            "docstring": "Protocol for caching data.",
            "file_path": "/path/to/cache.py",
            "methods": [
                {
                    "name": "get",
                    "signature": "async def get(self, key: str) -> str | None",
                    "docstring": "Get a value by key.",
                },
                {
                    "name": "set",
                    "signature": "async def set(self, key: str, value: str) -> None",
                    "docstring": "Set a value.",
                },
            ],
            "adapters": ["RedisCache", "MemoryCache"],
        }

        markdown = generate_protocol_markdown(protocol_info)

        assert "# CacheProtocol" in markdown
        assert "Protocol for caching data" in markdown
        assert "## Methods" in markdown
        assert "### `get`" in markdown
        assert "### `set`" in markdown
        assert "## Adapters" in markdown
        assert "RedisCache" in markdown
        assert "MemoryCache" in markdown

    def test_generate_comparison_table(self) -> None:
        """generate_comparison_table should create Indie vs Enterprise table."""
        from framework_m_studio.protocol_scanner import generate_comparison_table

        protocols = [
            {
                "name": "PermissionProtocol",
                "adapters": [
                    "RbacPermissionAdapter",
                    "OpaPermissionAdapter",
                    "SpiceDbPermissionAdapter",
                ],
            },
            {
                "name": "CacheProtocol",
                "adapters": ["MemoryCache", "RedisCache"],
            },
        ]

        # Indie adapters (simple, local, in-memory)
        indie_adapters = {"RbacPermissionAdapter", "MemoryCache"}

        table = generate_comparison_table(protocols, indie_adapters)

        assert "| Protocol | Indie | Enterprise |" in table
        assert "PermissionProtocol" in table
        assert "RbacPermissionAdapter" in table
        assert "OpaPermissionAdapter" in table
        assert "SpiceDbPermissionAdapter" in table
