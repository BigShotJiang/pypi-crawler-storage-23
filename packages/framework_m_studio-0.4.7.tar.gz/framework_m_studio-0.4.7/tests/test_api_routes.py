"""Tests for Studio API Routes."""

from __future__ import annotations

from collections.abc import Generator
from pathlib import Path

import pytest
from litestar.status_codes import HTTP_200_OK
from litestar.testing import TestClient


def test_health_check(client: TestClient) -> None:
    """Test health check endpoint."""
    response = client.get("/studio/api/health")
    assert response.status_code == HTTP_200_OK
    assert response.json() == {"status": "ok", "service": "framework-m-studio"}


def test_studio_root_redirect(client: TestClient) -> None:
    """Test /studio redirects to /studio/ui/."""
    # TestClient follows redirects by default? default is True in requests, usually False in starlette/litestar
    # Litestar TestClient is based on httpx.
    response = client.get("/studio", follow_redirects=False)
    # Redirect defaults to 307 in Litestar but might be 302 depending on version/config
    # Test output showed 302
    assert response.status_code in (302, 307)
    assert response.headers["location"] == "/studio/ui/"


@pytest.fixture
def mock_static_assets() -> Generator[None, None, None]:
    """Ensure index.html exists for the duration of the test."""
    # Path to static assets
    static_dir = Path(__file__).parents[1] / "src" / "framework_m_studio" / "static"
    static_dir.mkdir(parents=True, exist_ok=True)
    index_html = static_dir / "index.html"

    created = False
    if not index_html.exists():
        index_html.write_text("<!DOCTYPE html><html><body>Mock Studio UI</body></html>")
        created = True

    yield

    # Cleanup only if we created it
    if created and index_html.exists():
        index_html.unlink()


def test_studio_ui_root(client: TestClient, mock_static_assets: None) -> None:
    """Test /studio/ui/ serves index.html."""
    response = client.get("/studio/ui/")
    assert response.status_code == HTTP_200_OK
    assert "text/html" in response.headers["content-type"]
    assert response.text


def test_list_field_types(client: TestClient) -> None:
    """Test /studio/api/field-types endpoint."""
    # Mock FieldRegistry first to avoid external dependencies?
    # But adapter is loaded. It should work if framework_m is installed.
    # We might need to mock if database dependencies are strict.
    # Current FieldRegistry is memory-based/hardcoded for standard types in _register_standard_types.

    response = client.get("/studio/api/field-types")
    assert response.status_code == HTTP_200_OK
    data = response.json()
    assert "field_types" in data
    assert len(data["field_types"]) > 0
    # Check for a known type
    types = [t["name"] for t in data["field_types"]]
    assert "str" in types


def test_create_doctype_with_link_field(client: TestClient, tmp_path) -> None:
    """Test creating a DocType with Link field via API."""
    import os
    from pathlib import Path

    # Set working directory to tmp_path for this test
    original_cwd = Path.cwd()
    os.chdir(tmp_path)

    try:
        # Create namespaced directory structure: src/test_app/doctypes/
        app_name = "test_app"
        (tmp_path / "src" / app_name / "doctypes").mkdir(parents=True, exist_ok=True)

        # Create pyproject.toml with app name
        (tmp_path / "pyproject.toml").write_text(f'[project]\nname = "{app_name}"\n')

        # First create a Supplier DocType
        supplier_data = {
            "name": "Supplier",
            "app": app_name,
            "docstring": "Supplier master",
            "fields": [
                {
                    "name": "supplier_name",
                    "type": "str",
                    "required": True,
                    "label": "Supplier Name",
                }
            ],
        }

        response = client.post("/studio/api/doctype/Supplier", json=supplier_data)
        assert response.status_code in (200, 201)

        # Now create PurchaseOrder with Link to Supplier
        po_data = {
            "name": "PurchaseOrder",
            "app": app_name,
            "docstring": "Purchase Order document",
            "fields": [
                {
                    "name": "supplier",
                    "type": "Link",
                    "required": True,
                    "label": "Supplier",
                    "link_doctype": "Supplier",
                },
                {
                    "name": "total_amount",
                    "type": "float",
                    "required": True,
                    "label": "Total Amount",
                },
            ],
        }

        response = client.post("/studio/api/doctype/PurchaseOrder", json=po_data)
        assert response.status_code in (200, 201)
        assert "PurchaseOrder" in response.json()["message"]

        # Verify the DocType was created correctly
        response = client.get("/studio/api/doctype/PurchaseOrder")
        assert response.status_code == HTTP_200_OK

        data = response.json()
        assert data["name"] == "PurchaseOrder"
        assert len(data["fields"]) == 2

        # Check Link field
        fields_by_name = {f["name"]: f for f in data["fields"]}
        supplier_field = fields_by_name["supplier"]

        assert supplier_field["type"] == "Link"
        assert supplier_field["link_doctype"] == "Supplier"
        assert supplier_field["label"] == "Supplier"
        assert supplier_field["required"] is True

    finally:
        os.chdir(original_cwd)


def test_update_doctype_preserves_link_field(client: TestClient, tmp_path) -> None:
    """Test updating a DocType preserves Link field metadata."""
    import os
    from pathlib import Path

    original_cwd = Path.cwd()
    os.chdir(tmp_path)

    try:
        # Create namespaced directory structure: src/test_app/doctypes/
        app_name = "test_app"
        (tmp_path / "src" / app_name / "doctypes").mkdir(parents=True, exist_ok=True)

        # Create pyproject.toml with app name
        (tmp_path / "pyproject.toml").write_text(f'[project]\nname = "{app_name}"\n')

        # Create Supplier first
        supplier_data = {
            "name": "Supplier",
            "app": app_name,
            "fields": [{"name": "name", "type": "str", "required": True}],
        }
        client.post("/studio/api/doctype/Supplier", json=supplier_data)

        # Create Invoice with Link field
        initial_data = {
            "name": "Invoice",
            "app": app_name,
            "fields": [
                {
                    "name": "supplier",
                    "type": "Link",
                    "required": True,
                    "link_doctype": "Supplier",
                }
            ],
        }

        response = client.post("/studio/api/doctype/Invoice", json=initial_data)
        assert response.status_code in (200, 201)

        # Update Invoice to add another field
        updated_data = {
            "name": "Invoice",
            "app": app_name,
            "fields": [
                {
                    "name": "supplier",
                    "type": "Link",
                    "required": True,
                    "link_doctype": "Supplier",
                },
                {"name": "invoice_number", "type": "str", "required": True},
            ],
        }

        response = client.post("/studio/api/doctype/Invoice", json=updated_data)
        assert response.status_code in (200, 201)

        # Verify Link field is preserved
        response = client.get("/studio/api/doctype/Invoice")
        assert response.status_code == HTTP_200_OK

        data = response.json()
        fields_by_name = {f["name"]: f for f in data["fields"]}

        supplier_field = fields_by_name["supplier"]
        assert supplier_field["type"] == "Link"
        assert supplier_field["link_doctype"] == "Supplier"

    finally:
        os.chdir(original_cwd)
