"""Tests for DocType Discovery Service."""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

from framework_m_studio.discovery import (
    DocTypeInfo,
    FieldInfo,
    doctype_to_dict,
    parse_doctype_file,
    scan_doctypes,
)


class TestFieldInfo:
    """Tests for FieldInfo dataclass."""

    def test_field_info_creation(self) -> None:
        """FieldInfo should be creatable with required fields."""
        field = FieldInfo(name="title", type="str")
        assert field.name == "title"
        assert field.type == "str"
        assert field.required is True
        assert field.default is None

    def test_field_info_with_defaults(self) -> None:
        """FieldInfo should accept optional fields."""
        field = FieldInfo(
            name="status",
            type="str",
            default='"pending"',
            required=False,
            description="Current status",
        )
        assert field.default == '"pending"'
        assert field.required is False
        assert field.description == "Current status"

    def test_field_info_with_link_doctype(self) -> None:
        """FieldInfo should support link_doctype for Link fields."""
        field = FieldInfo(
            name="supplier",
            type="Link",
            link_doctype="Supplier",
            required=True,
        )
        assert field.type == "Link"
        assert field.link_doctype == "Supplier"
        assert field.table_doctype is None

    def test_field_info_with_table_doctype(self) -> None:
        """FieldInfo should support table_doctype for Table fields."""
        field = FieldInfo(
            name="items",
            type="Table",
            table_doctype="OrderItem",
            required=False,
        )
        assert field.type == "Table"
        assert field.table_doctype == "OrderItem"
        assert field.link_doctype is None


class TestDocTypeInfo:
    """Tests for DocTypeInfo dataclass."""

    def test_doctype_info_creation(self) -> None:
        """DocTypeInfo should be creatable with required fields."""
        doctype = DocTypeInfo(
            name="Todo",
            module="myapp.doctypes.todo",
            file_path="/path/to/todo.py",
        )
        assert doctype.name == "Todo"
        assert doctype.module == "myapp.doctypes.todo"
        assert doctype.fields == []
        assert doctype.meta == {}


class TestParseDocTypeFile:
    """Tests for parse_doctype_file function."""

    def test_parse_simple_doctype(self, tmp_path: Path) -> None:
        """parse_doctype_file should extract DocType from simple file."""
        code = dedent(
            '''
            """Todo DocType module."""
            
            from framework_m.core.base import BaseDocType
            
            
            class Todo(BaseDocType):
                """A simple todo item."""
                
                title: str
                completed: bool = False
        '''
        )

        file_path = tmp_path / "todo.py"
        file_path.write_text(code)

        doctypes = parse_doctype_file(file_path)

        assert len(doctypes) == 1
        assert doctypes[0].name == "Todo"
        assert len(doctypes[0].fields) == 2

        # Check title field
        title_field = next(f for f in doctypes[0].fields if f.name == "title")
        assert title_field.type == "str"
        assert title_field.required is True

        # Check completed field
        completed_field = next(f for f in doctypes[0].fields if f.name == "completed")
        assert completed_field.type == "bool"
        assert completed_field.required is False  # Has default

    def test_parse_file_without_doctype(self, tmp_path: Path) -> None:
        """parse_doctype_file should return empty list for non-DocType files."""
        code = dedent(
            '''
            """Some utility module."""
            
            def helper():
                pass
        '''
        )

        file_path = tmp_path / "utils.py"
        file_path.write_text(code)

        doctypes = parse_doctype_file(file_path)

        assert doctypes == []

    def test_parse_invalid_python(self, tmp_path: Path) -> None:
        """parse_doctype_file should return empty list for invalid Python."""
        file_path = tmp_path / "invalid.py"
        file_path.write_text("this is not { valid python")

        doctypes = parse_doctype_file(file_path)

        assert doctypes == []

    def test_parse_optional_fields(self, tmp_path: Path) -> None:
        """parse_doctype_file should detect Optional fields as not required."""
        code = dedent(
            """
            from framework_m.core.base import BaseDocType
            from typing import Optional
            
            
            class User(BaseDocType):
                name: str
                email: str | None = None
                phone: Optional[str] = None
        """
        )

        file_path = tmp_path / "user.py"
        file_path.write_text(code)

        doctypes = parse_doctype_file(file_path)

        assert len(doctypes) == 1

        name_field = next(f for f in doctypes[0].fields if f.name == "name")
        assert name_field.required is True

        email_field = next(f for f in doctypes[0].fields if f.name == "email")
        assert email_field.required is False

    def test_parse_link_field(self, tmp_path: Path) -> None:
        """parse_doctype_file should extract Link field metadata."""
        code = dedent(
            """
            from framework_m_core.domain.base_doctype import BaseDocType
            from framework_m_core.domain.mixins import Link
            from typing import Annotated
            from pydantic import Field
            
            
            class PurchaseOrder(BaseDocType):
                supplier: Annotated[str, Link("Supplier")] = Field(..., label="Supplier")
                amount: float
        """
        )

        file_path = tmp_path / "purchase_order.py"
        file_path.write_text(code)

        doctypes = parse_doctype_file(file_path)

        assert len(doctypes) == 1
        assert doctypes[0].name == "PurchaseOrder"

        supplier_field = next(f for f in doctypes[0].fields if f.name == "supplier")
        assert supplier_field.type == "Link"
        assert supplier_field.link_doctype == "Supplier"
        assert supplier_field.required is True

    def test_parse_optional_link_field(self, tmp_path: Path) -> None:
        """parse_doctype_file should handle optional Link fields."""
        code = dedent(
            """
            from framework_m_core.domain.base_doctype import BaseDocType
            from framework_m_core.domain.mixins import Link
            from typing import Annotated
            from pydantic import Field
            
            
            class Invoice(BaseDocType):
                customer: Annotated[str, Link("Customer")] | None = None
        """
        )

        file_path = tmp_path / "invoice.py"
        file_path.write_text(code)

        doctypes = parse_doctype_file(file_path)

        assert len(doctypes) == 1

        customer_field = next(f for f in doctypes[0].fields if f.name == "customer")
        assert customer_field.type == "Link"
        assert customer_field.link_doctype == "Customer"
        assert customer_field.required is False


class TestScanDocTypes:
    """Tests for scan_doctypes function."""

    def test_scan_finds_doctypes(self, tmp_path: Path) -> None:
        """scan_doctypes should find DocTypes in directory tree."""
        # Create a DocType file
        src_dir = tmp_path / "src" / "doctypes"
        src_dir.mkdir(parents=True)

        (src_dir / "todo.py").write_text(
            dedent(
                """
            from framework_m.core.base import BaseDocType
            
            class Todo(BaseDocType):
                title: str
        """
            )
        )

        doctypes = scan_doctypes(tmp_path)

        assert len(doctypes) == 1
        assert doctypes[0].name == "Todo"

    def test_scan_excludes_tests(self, tmp_path: Path) -> None:
        """scan_doctypes should exclude test files by default."""
        # Create a test file with DocType
        tests_dir = tmp_path / "tests"
        tests_dir.mkdir()

        (tests_dir / "test_todo.py").write_text(
            dedent(
                """
            from framework_m.core.base import BaseDocType
            
            class TestDocType(BaseDocType):
                name: str
        """
            )
        )

        doctypes = scan_doctypes(tmp_path)

        assert len(doctypes) == 0

    def test_scan_excludes_test_files_not_dirs(self, tmp_path: Path) -> None:
        """scan_doctypes should exclude test_*.py files but not test_* directories."""
        # Create a directory starting with test_ containing DocTypes
        test_app_dir = tmp_path / "src" / "test_app" / "doctypes"
        test_app_dir.mkdir(parents=True)

        (test_app_dir / "todo.py").write_text(
            dedent(
                """
            from framework_m.core.base import BaseDocType
            
            class Todo(BaseDocType):
                title: str
        """
            )
        )

        # Create a test file that should be excluded
        (test_app_dir / "test_todo.py").write_text(
            dedent(
                """
            from framework_m.core.base import BaseDocType
            
            class TestTodo(BaseDocType):
                name: str
        """
            )
        )

        doctypes = scan_doctypes(tmp_path)

        # Should find Todo but not TestTodo
        assert len(doctypes) == 1
        assert doctypes[0].name == "Todo"

    def test_scan_namespaced_structure(self, tmp_path: Path) -> None:
        """scan_doctypes should find DocTypes in namespaced app structure."""
        # Create namespaced structure: src/<app>/doctypes/<doctype>/doctype.py
        app_dir = tmp_path / "src" / "my_app" / "doctypes" / "invoice"
        app_dir.mkdir(parents=True)

        (app_dir / "doctype.py").write_text(
            dedent(
                """
            from framework_m.core.base import BaseDocType
            
            class Invoice(BaseDocType):
                number: str
                amount: float
        """
            )
        )

        doctypes = scan_doctypes(tmp_path)

        assert len(doctypes) == 1
        assert doctypes[0].name == "Invoice"
        assert len(doctypes[0].fields) == 2

    def test_scan_excludes_pycache(self, tmp_path: Path) -> None:
        """scan_doctypes should exclude __pycache__ directories."""
        # Create a __pycache__ directory with .py files
        cache_dir = tmp_path / "src" / "__pycache__"
        cache_dir.mkdir(parents=True)

        (cache_dir / "todo.cpython-312.py").write_text(
            dedent(
                """
            from framework_m.core.base import BaseDocType
            
            class Todo(BaseDocType):
                title: str
        """
            )
        )

        doctypes = scan_doctypes(tmp_path)

        assert len(doctypes) == 0


class TestDocTypeToDict:
    """Tests for doctype_to_dict function."""

    def test_converts_to_dict(self) -> None:
        """doctype_to_dict should convert DocTypeInfo to dictionary."""
        doctype = DocTypeInfo(
            name="Todo",
            module="app.doctypes.todo",
            file_path="/path/to/todo.py",
            docstring="A todo item.",
            fields=[
                FieldInfo(name="title", type="str"),
                FieldInfo(name="done", type="bool", default="False"),
            ],
        )

        result = doctype_to_dict(doctype)

        assert result["name"] == "Todo"
        assert result["module"] == "app.doctypes.todo"
        assert result["docstring"] == "A todo item."
        assert len(result["fields"]) == 2
        assert result["fields"][0]["name"] == "title"

    def test_converts_link_fields(self) -> None:
        """doctype_to_dict should include link_doctype metadata."""
        doctype = DocTypeInfo(
            name="Order",
            module="app.doctypes.order",
            file_path="/path/to/order.py",
            fields=[
                FieldInfo(
                    name="customer",
                    type="Link",
                    link_doctype="Customer",
                    required=True,
                ),
                FieldInfo(
                    name="items",
                    type="Table",
                    table_doctype="OrderItem",
                    required=False,
                ),
            ],
        )

        result = doctype_to_dict(doctype)

        customer_field = result["fields"][0]
        assert customer_field["name"] == "customer"
        assert customer_field["type"] == "Link"
        assert customer_field["link_doctype"] == "Customer"

        items_field = result["fields"][1]
        assert items_field["name"] == "items"
        assert items_field["type"] == "Table"
        assert items_field["table_doctype"] == "OrderItem"
