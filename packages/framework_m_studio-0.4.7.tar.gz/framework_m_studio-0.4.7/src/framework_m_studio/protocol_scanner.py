"""Protocol Scanner - Extract Protocol definitions for documentation.

This module scans Python files for Protocol class definitions and extracts
their method signatures, docstrings, and adapter implementations.

Features:
- Parse Protocol classes using LibCST
- Extract method signatures and docstrings
- Parse adapter names from docstrings
- Generate markdown documentation
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import libcst as cst

# =============================================================================
# Data Models
# =============================================================================


@dataclass
class MethodInfo:
    """Parsed method information from a Protocol class."""

    name: str
    signature: str
    docstring: str | None = None


@dataclass
class ProtocolInfo:
    """Parsed Protocol information."""

    name: str
    file_path: str
    docstring: str | None = None
    methods: list[MethodInfo] = field(default_factory=list)
    adapters: list[str] = field(default_factory=list)


# =============================================================================
# LibCST Visitor for Protocol Parsing
# =============================================================================


class ProtocolParserVisitor(cst.CSTVisitor):
    """LibCST visitor to extract Protocol information."""

    def __init__(self) -> None:
        self.protocols: list[ProtocolInfo] = []
        self._current_class: str | None = None
        self._current_docstring: str | None = None
        self._current_methods: list[MethodInfo] = []
        self._is_protocol: bool = False

    def visit_ClassDef(self, node: cst.ClassDef) -> bool:
        """Visit class definition."""
        class_name = node.name.value

        # Check if this is a Protocol class
        is_protocol = False
        for arg in node.bases:
            base_name = _get_base_name(arg)
            if "Protocol" in base_name:
                is_protocol = True
                break

        if is_protocol:
            self._current_class = class_name
            self._is_protocol = True
            self._current_methods = []
            self._current_docstring = _extract_docstring(node)

        return True

    def leave_ClassDef(self, node: cst.ClassDef) -> None:
        """Leave class definition."""
        if self._current_class == node.name.value and self._is_protocol:
            # Extract adapters from docstring
            adapters = _extract_adapters(self._current_docstring)

            protocol = ProtocolInfo(
                name=self._current_class,
                file_path="",
                docstring=self._current_docstring,
                methods=self._current_methods,
                adapters=adapters,
            )
            self.protocols.append(protocol)

            self._current_class = None
            self._is_protocol = False
            self._current_methods = []
            self._current_docstring = None

    def visit_FunctionDef(self, node: cst.FunctionDef) -> bool:
        """Visit function/method definition."""
        if self._is_protocol and self._current_class:
            method_name = node.name.value
            if not method_name.startswith("_"):
                # Get full signature
                signature = _build_signature(node)
                method_docstring = _extract_function_docstring(node)

                method = MethodInfo(
                    name=method_name,
                    signature=signature,
                    docstring=method_docstring,
                )
                self._current_methods.append(method)

        return False


# =============================================================================
# Helper Functions
# =============================================================================


def _get_base_name(arg: cst.Arg) -> str:
    """Get base class name from Arg node."""
    if isinstance(arg.value, cst.Name):
        return arg.value.value
    if isinstance(arg.value, cst.Subscript) and isinstance(arg.value.value, cst.Name):
        return arg.value.value.value
    return ""


def _extract_docstring(node: cst.ClassDef) -> str | None:
    """Extract docstring from class definition."""
    if not node.body or not node.body.body:
        return None

    first_stmt = node.body.body[0]
    if not isinstance(first_stmt, cst.SimpleStatementLine):
        return None

    if not first_stmt.body or not isinstance(first_stmt.body[0], cst.Expr):
        return None

    expr = first_stmt.body[0].value
    if isinstance(expr, cst.SimpleString):
        value = expr.value
        if value.startswith('"""') or value.startswith("'''"):
            return value[3:-3].strip()
        elif value.startswith('"') or value.startswith("'"):
            return value[1:-1].strip()

    return None


def _extract_function_docstring(node: cst.FunctionDef) -> str | None:
    """Extract docstring from function definition."""
    if not node.body or not node.body.body:
        return None

    first_stmt = node.body.body[0]
    if not isinstance(first_stmt, cst.SimpleStatementLine):
        return None

    if not first_stmt.body or not isinstance(first_stmt.body[0], cst.Expr):
        return None

    expr = first_stmt.body[0].value
    if isinstance(expr, cst.SimpleString):
        value = expr.value
        if value.startswith('"""') or value.startswith("'''"):
            return value[3:-3].strip()
        elif value.startswith('"') or value.startswith("'"):
            return value[1:-1].strip()

    return None


def _build_signature(node: cst.FunctionDef) -> str:
    """Build method signature string."""
    # Get async prefix
    is_async = node.asynchronous is not None
    prefix = "async def " if is_async else "def "

    # Get function name and parameters
    name = node.name.value
    params = cst.Module(body=[]).code_for_node(node.params)

    # Get return type if available
    return_type = ""
    if node.returns:
        return_type = " -> " + cst.Module(body=[]).code_for_node(
            node.returns.annotation
        )

    return f"{prefix}{name}({params}){return_type}"


def _extract_adapters(docstring: str | None) -> list[str]:
    """Extract adapter names from Protocol docstring.

    Looks for patterns like:
    - Implementations:
    - SomeAdapter: Description
    """
    if not docstring:
        return []

    adapters: list[str] = []

    # Look for adapter names after "Implementations:" line
    in_implementations = False
    for line in docstring.split("\n"):
        line = line.strip()

        if "Implementations:" in line or "Implementation:" in line:
            in_implementations = True
            continue

        if in_implementations:
            # Check for "- AdapterName: description" pattern
            match = re.match(r"-\s*(\w+)(?:Adapter|Cache|Repository)?:", line)
            if match:
                # Extract the full adapter name
                adapter_match = re.match(r"-\s*(\w+):", line)
                if adapter_match:
                    adapters.append(adapter_match.group(1))
            elif line.startswith("-"):
                # Simple "- AdapterName" pattern
                adapter_match = re.match(r"-\s*(\w+)", line)
                if adapter_match:
                    adapters.append(adapter_match.group(1))
            elif not line:
                # Empty line may end the list
                if adapters:
                    break

    return adapters


# =============================================================================
# Public API
# =============================================================================


def parse_protocol_file(file_path: Path) -> list[dict[str, Any]]:
    """Parse a Python file and extract Protocol definitions.

    Args:
        file_path: Path to the Python file

    Returns:
        List of protocol info dictionaries
    """
    source = file_path.read_text(encoding="utf-8")

    try:
        tree = cst.parse_module(source)
    except cst.ParserSyntaxError:
        return []

    visitor = ProtocolParserVisitor()
    tree.visit(visitor)

    result = []
    for proto in visitor.protocols:
        proto.file_path = str(file_path.absolute())
        result.append(protocol_to_dict(proto))

    return result


def scan_protocols(interfaces_dir: Path) -> list[dict[str, Any]]:
    """Scan a directory for Protocol definitions.

    Args:
        interfaces_dir: Path to interfaces directory

    Returns:
        List of all protocol info dictionaries
    """
    protocols: list[dict[str, Any]] = []

    for py_file in interfaces_dir.glob("*.py"):
        if py_file.name.startswith("_"):
            continue

        file_protocols = parse_protocol_file(py_file)
        protocols.extend(file_protocols)

    return protocols


def generate_protocol_markdown(protocol_info: dict[str, Any]) -> str:
    """Generate markdown documentation for a Protocol.

    Args:
        protocol_info: Protocol information dictionary

    Returns:
        Markdown string
    """
    from pathlib import Path

    name = protocol_info.get("name", "Unknown")
    docstring = protocol_info.get("docstring", "")
    methods = protocol_info.get("methods", [])
    adapters = protocol_info.get("adapters", [])
    file_path = protocol_info.get("file_path", "")

    lines = [f"# {name}", ""]

    if docstring:
        # Clean up the docstring - remove the "Implementations:" section
        clean_docstring = _clean_docstring_for_markdown(docstring)
        if clean_docstring:
            lines.extend([clean_docstring, ""])

    # Source file link
    if file_path:
        filename = Path(file_path).name
        file_uri = f"file://{file_path}"
        lines.extend([f"**Source**: [{filename}]({file_uri})", ""])

    # Methods section
    if methods:
        lines.extend(["## Methods", ""])
        for method in methods:
            lines.append(f"### `{method['name']}`")
            lines.append("")
            lines.append("```python")
            lines.append(method["signature"])
            lines.append("```")
            lines.append("")
            if method.get("docstring"):
                lines.extend([method["docstring"], ""])

    # Adapters section
    if adapters:
        lines.extend(["## Adapters", ""])
        for adapter in adapters:
            lines.append(f"- `{adapter}`")
        lines.append("")

    return "\n".join(lines)


def _clean_docstring_for_markdown(docstring: str) -> str:
    """Remove Implementations section from docstring for markdown."""
    lines = docstring.split("\n")
    result_lines = []
    skip_until_empty = False

    for line in lines:
        if "Implementations:" in line or "Implementation:" in line:
            skip_until_empty = True
            continue

        if skip_until_empty:
            if line.strip().startswith("-"):
                continue
            if not line.strip():
                skip_until_empty = False
                continue

        result_lines.append(line)

    return "\n".join(result_lines).strip()


def protocol_to_dict(protocol: ProtocolInfo) -> dict[str, Any]:
    """Convert ProtocolInfo to dictionary."""
    return {
        "name": protocol.name,
        "file_path": protocol.file_path,
        "docstring": protocol.docstring,
        "methods": [
            {
                "name": m.name,
                "signature": m.signature,
                "docstring": m.docstring,
            }
            for m in protocol.methods
        ],
        "adapters": protocol.adapters,
    }


def generate_comparison_table(
    protocols: list[dict[str, Any]],
    indie_adapters: set[str],
) -> str:
    """Generate Indie vs Enterprise comparison table.

    Args:
        protocols: List of protocol info dicts
        indie_adapters: Set of adapter names considered "Indie" (simple, local)

    Returns:
        Markdown table string
    """
    lines = [
        "# Protocol Adapter Comparison",
        "",
        "| Protocol | Indie | Enterprise |",
        "|----------|-------|------------|",
    ]

    for proto in sorted(protocols, key=lambda p: p["name"]):
        name = proto["name"]
        adapters = proto.get("adapters", [])

        indie_list = [a for a in adapters if a in indie_adapters]
        enterprise_list = [a for a in adapters if a not in indie_adapters]

        indie_str = ", ".join(f"`{a}`" for a in indie_list) or "-"
        enterprise_str = ", ".join(f"`{a}`" for a in enterprise_list) or "-"

        lines.append(f"| {name} | {indie_str} | {enterprise_str} |")

    lines.append("")
    return "\n".join(lines)


__all__ = [
    "MethodInfo",
    "ProtocolInfo",
    "generate_comparison_table",
    "generate_protocol_markdown",
    "parse_protocol_file",
    "protocol_to_dict",
    "scan_protocols",
]
