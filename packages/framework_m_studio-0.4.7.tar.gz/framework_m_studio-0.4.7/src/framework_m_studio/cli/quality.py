"""Quality assurance commands for Framework M."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Annotated

import cyclopts


def get_pythonpath() -> str:
    """Construct PYTHONPATH including current directory and src."""
    cwd = Path.cwd()
    paths = [str(cwd)]

    src = cwd / "src"
    if src.exists():
        paths.append(str(src))

    return ":".join(paths)


def build_pytest_command(
    verbose: bool = False,
    coverage: bool = False,
    filter_expr: str | None = None,
    extra_args: tuple[str, ...] = (),
) -> list[str]:
    """Build pytest command."""
    cmd = [sys.executable, "-m", "pytest"]
    if verbose:
        cmd.append("-v")
    if coverage:
        cmd.append("--cov")
    if filter_expr:
        cmd.extend(["-k", filter_expr])
    if extra_args:
        cmd.extend(extra_args)
    else:
        cmd.append(".")
    return cmd


def build_ruff_check_command(
    fix: bool = False,
    extra_args: tuple[str, ...] = (),
) -> list[str]:
    """Build ruff check command."""
    cmd = [sys.executable, "-m", "ruff", "check"]
    if fix:
        cmd.append("--fix")
    if extra_args:
        cmd.extend(extra_args)
    return cmd


def build_ruff_format_command(
    check: bool = False,
    extra_args: tuple[str, ...] = (),
) -> list[str]:
    """Build ruff format command."""
    cmd = [sys.executable, "-m", "ruff", "format"]
    if check:
        cmd.append("--check")
    if extra_args:
        cmd.extend(extra_args)
    return cmd


def build_mypy_command(
    strict: bool = False,
    extra_args: tuple[str, ...] = (),
) -> list[str]:
    """Build mypy command."""
    cmd = [sys.executable, "-m", "mypy"]
    if strict:
        cmd.append("--strict")
    if extra_args:
        cmd.extend(extra_args)
    return cmd


def _run_command(cmd: list[str]) -> None:
    """Run a command and exit with its return code."""
    try:
        subprocess.run(cmd, check=True)
        sys.exit(0)
    except subprocess.CalledProcessError as e:
        sys.exit(e.returncode)
    except KeyboardInterrupt:
        print("\nInterrupted.")
        sys.exit(130)


def test_command(
    path: Annotated[
        str | None, cyclopts.Parameter(name="--path", help="Test path")
    ] = None,
    verbose: Annotated[
        bool, cyclopts.Parameter(name="--verbose", help="Verbose output")
    ] = False,
    coverage: Annotated[
        bool, cyclopts.Parameter(name="--coverage", help="Enable coverage")
    ] = False,
    filter: Annotated[
        str | None, cyclopts.Parameter(name="--filter", help="Filter tests")
    ] = None,
) -> None:
    """Run tests using pytest."""
    extra = (path,) if path else ()
    cmd = build_pytest_command(
        verbose=verbose, coverage=coverage, filter_expr=filter, extra_args=extra
    )
    _run_command(cmd)


def lint_command(
    fix: Annotated[bool, cyclopts.Parameter(name="--fix", help="Fix issues")] = False,
) -> None:
    """Lint code using ruff."""
    cmd = build_ruff_check_command(fix=fix)
    _run_command(cmd)


def format_command(
    check: Annotated[
        bool, cyclopts.Parameter(name="--check", help="Check only")
    ] = False,
) -> None:
    """Format code using ruff."""
    cmd = build_ruff_format_command(check=check)
    _run_command(cmd)


def typecheck_command(
    strict: Annotated[
        bool, cyclopts.Parameter(name="--strict", help="Strict mode")
    ] = False,
) -> None:
    """Type check code using mypy."""
    cmd = build_mypy_command(strict=strict)
    _run_command(cmd)


__all__ = [
    "build_mypy_command",
    "build_pytest_command",
    "build_ruff_check_command",
    "build_ruff_format_command",
    "format_command",
    "get_pythonpath",
    "lint_command",
    "test_command",
    "typecheck_command",
]
