"""Dev CLI Command - Development server with hot reload.

This module provides the `m dev` command for running the full development
stack with automatic hot reload using honcho for process management.

Architecture:
- Uses honcho.manager.Manager for concurrent process management
- Supports Procfile and m.toml [dev] configuration
- All processes have hot reload enabled
- Graceful shutdown on Ctrl+C

Configuration Precedence (highest to lowest):
1. CLI flags (--enable-worker, --procfile, etc.)
2. Procfile processes (explicit user definition)
3. m.toml [dev] custom processes
4. m.toml [dev] backend/frontend overrides
5. Default processes

Usage:
    m dev                           # Backend + Frontend (defaults)
    m dev --studio                  # + Studio on port 9999
    m dev --app myapp:app           # Custom backend module
    m dev --frontend-dir ./ui       # Custom frontend path
    m dev --no-frontend             # Backend only
    m dev --enable-worker           # Add worker process
    m dev --enable-scheduler        # Add scheduler process
    m dev --procfile Procfile.dev   # Load custom Procfile
"""

from __future__ import annotations

import ast
import os
import signal
import sys
from pathlib import Path
from typing import Annotated

import cyclopts
from framework_m_core.dev_config import (
    get_default_processes,
    load_dev_config_from_toml,
    load_procfile,
    merge_process_configs,
)
from honcho.manager import Manager
from honcho.printer import Printer

from framework_m_studio.cli.build import (
    _generate_plugin_entry,
    _generate_vite_config,
    discover_frontend_plugins,
)
from framework_m_studio.cli.studio import DEFAULT_STUDIO_APP

# Default ports
DEFAULT_BACKEND_PORT = 8888
DEFAULT_FRONTEND_PORT = 5173
DEFAULT_STUDIO_PORT = 9999


def _display_host(host: str) -> str:
    """Return browser-friendly host for user-facing URLs."""
    return "localhost" if host in {"0.0.0.0", "::"} else host


def _get_pythonpath() -> str:
    """Get PYTHONPATH with src/ directory included."""
    cwd = Path.cwd()
    src_path = cwd / "src"

    paths = []
    if src_path.exists():
        paths.append(str(src_path))
    paths.append(str(cwd))

    existing = os.environ.get("PYTHONPATH", "")
    if existing:
        paths.append(existing)

    return os.pathsep.join(paths)


def _find_app(explicit_app: str | None = None) -> str:
    """Find the Litestar app to run."""
    if explicit_app:
        return explicit_app

    def detect_asgi_symbol(module_file: Path) -> str | None:
        """Detect ASGI entry symbol in a Python module.

        Returns:
            "app" if a top-level app variable is defined,
            "create_app" if a top-level create_app function is defined,
            otherwise None.
        """
        try:
            source = module_file.read_text(encoding="utf-8")
            tree = ast.parse(source)
        except (OSError, SyntaxError, UnicodeDecodeError):
            return None

        has_create_app = False

        for node in tree.body:
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == "app":
                        return "app"
            elif isinstance(node, ast.AnnAssign):
                if isinstance(node.target, ast.Name) and node.target.id == "app":
                    return "app"
            elif (
                isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                and node.name == "create_app"
            ):
                has_create_app = True

        if has_create_app:
            return "create_app"

        return None

    cwd = Path.cwd()

    candidates: list[tuple[Path, str]] = [
        (cwd / "app.py", "app"),
        (cwd / "app" / "__init__.py", "app"),
        (cwd / "src" / "app" / "__init__.py", "src.app"),
        (cwd / "main.py", "main"),
    ]

    for module_file, module_name in candidates:
        if module_file.exists():
            symbol = detect_asgi_symbol(module_file)
            if symbol:
                return f"{module_name}:{symbol}"

    return "framework_m_standard.adapters.web.app:create_app"


def _check_frontend_exists(frontend_dir: Path) -> bool:
    """Check if frontend directory exists and is valid."""
    return frontend_dir.exists() and (frontend_dir / "package.json").exists()


def dev_command(
    app: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--app",
            help="Backend app path (module:attribute format)",
        ),
    ] = None,
    host: Annotated[
        str,
        cyclopts.Parameter(name="--host", help="Host to bind to"),
    ] = "0.0.0.0",
    port: Annotated[
        int,
        cyclopts.Parameter(name="--port", help="Backend port"),
    ] = DEFAULT_BACKEND_PORT,
    frontend_dir: Annotated[
        Path,
        cyclopts.Parameter(
            name="--frontend-dir",
            help="Frontend directory path",
        ),
    ] = Path("frontend"),
    frontend_port: Annotated[
        int,
        cyclopts.Parameter(name="--frontend-port", help="Frontend dev server port"),
    ] = DEFAULT_FRONTEND_PORT,
    studio: Annotated[
        bool,
        cyclopts.Parameter(
            name="--studio",
            help="Also start Studio on port 9999",
        ),
    ] = False,
    studio_port: Annotated[
        int,
        cyclopts.Parameter(name="--studio-port", help="Studio port"),
    ] = DEFAULT_STUDIO_PORT,
    no_frontend: Annotated[
        bool,
        cyclopts.Parameter(
            name="--no-frontend",
            help="Skip frontend, run backend only",
        ),
    ] = False,
    enable_worker: Annotated[
        bool,
        cyclopts.Parameter(
            name="--enable-worker",
            help="Enable worker process (m worker)",
        ),
    ] = False,
    enable_scheduler: Annotated[
        bool,
        cyclopts.Parameter(
            name="--enable-scheduler",
            help="Enable scheduler process (m worker --scheduler-only)",
        ),
    ] = False,
    procfile: Annotated[
        Path | None,
        cyclopts.Parameter(
            name="--procfile",
            help="Path to Procfile for custom process definitions",
        ),
    ] = None,
) -> None:
    """Start development servers with hot reload.

    Runs backend (uvicorn --reload) and frontend (pnpm dev) concurrently
    using honcho for process management.

    Configuration is loaded from multiple sources with the following precedence:
    1. CLI flags (highest priority)
    2. Procfile (if specified with --procfile)
    3. m.toml [dev] section
    4. Default processes

    Examples:
        # Basic usage
        m dev                           # Backend + Frontend (defaults)
        m dev --studio                  # + Studio on port 9999
        m dev --app myapp:create_app    # Custom backend
        m dev --no-frontend             # Backend only

        # With workers and schedulers
        m dev --enable-worker           # Add worker process
        m dev --enable-scheduler        # Add scheduler process

        # Custom configuration
        m dev --procfile Procfile.dev   # Load custom Procfile
    """
    # Find app path
    app_path = _find_app(app)

    # Set up environment
    env = os.environ.copy()
    env["PYTHONPATH"] = _get_pythonpath()

    frontend_exists = _check_frontend_exists(frontend_dir)
    run_frontend_process = (not no_frontend) and frontend_exists

    # Set dev mode flag:
    # - true: API-only backend (when frontend dev server is running, or explicit --no-frontend)
    # - false: backend serves bundled/prebuilt Desk UI (fallback when frontend is missing)
    env["M_DEV_MODE"] = "true" if (run_frontend_process or no_frontend) else "false"

    # Set backend URL for Vite proxy configuration
    display_host = _display_host(host)
    env["VITE_BACKEND_URL"] = f"http://{display_host}:{port}"

    if not no_frontend and not frontend_exists:
        print(f"⚠️  Frontend not found at {frontend_dir}. Skipping frontend process.")
        print("   Backend will serve bundled/prebuilt Desk UI.")

    # === Plugin Discovery for Multi-Package UI ===
    if run_frontend_process:
        plugins = discover_frontend_plugins()

        if plugins:
            print(f"\n🔌 Discovered {len(plugins)} frontend plugin(s):")
            for plugin in plugins:
                source_label = (
                    f"installed: {plugin['package']}"
                    if plugin["source"] == "installed"
                    else "local"
                )
                print(f"  - {plugin['name']}: {plugin['path']} ({source_label})")
            print()

            # Generate temp entry and config for plugin mode
            temp_dir = Path.cwd() / ".m" / "dev"
            temp_dir.mkdir(parents=True, exist_ok=True)

            entry_file = temp_dir / "entry.tsx"
            _generate_plugin_entry(entry_file, plugins)

            vite_config_file = temp_dir / "vite.config.ts"
            _generate_vite_config(vite_config_file, plugins)

            # Pass to Vite dev server via env vars
            env["VITE_ENTRY"] = str(entry_file)
            env["VITE_CONFIG"] = str(vite_config_file)

            print(f"📝 Generated plugin entry: {entry_file}")
            print(f"⚙️  Generated Vite config: {vite_config_file}")
            print()

    # === Configuration Loading ===

    # 1. Load m.toml [dev] config
    toml_config = load_dev_config_from_toml()

    # Apply port overrides from m.toml if not explicitly set via CLI
    if "backend_port" in toml_config and port == DEFAULT_BACKEND_PORT:
        port = toml_config["backend_port"]
        env["VITE_BACKEND_URL"] = f"http://{display_host}:{port}"

    if "frontend_port" in toml_config and frontend_port == DEFAULT_FRONTEND_PORT:
        frontend_port = toml_config["frontend_port"]

    # Apply enable flags from m.toml if not explicitly set via CLI
    if not enable_worker and toml_config.get("enable_worker", False):
        enable_worker = True

    if not enable_scheduler and toml_config.get("enable_scheduler", False):
        enable_scheduler = True

    # 2. Get default processes
    defaults = get_default_processes(
        app=app_path,
        host=host,
        port=port,
        frontend_dir=frontend_dir,
        frontend_port=frontend_port,
        no_frontend=not run_frontend_process,
    )

    # 3. Load Procfile if specified (CLI or m.toml)
    procfile_processes: dict[str, str] = {}
    if procfile and procfile.exists():
        procfile_processes = load_procfile(procfile)
        print(f"📄 Loaded processes from {procfile}")
    elif toml_config.get("procfile"):
        procfile_str = toml_config.get("procfile")
        if procfile_str:
            procfile_path = Path(procfile_str)
            if procfile_path.exists():
                procfile_processes = load_procfile(procfile_path)
                print(f"📄 Loaded processes from {procfile_path}")

    # 4. Merge all configurations
    processes = merge_process_configs(defaults, procfile_processes, toml_config)

    # 5. Add optional processes from CLI flags
    if studio:
        studio_cmd = (
            f"{sys.executable} -m uvicorn {DEFAULT_STUDIO_APP} "
            f"--host {host} --port {studio_port} --reload"
        )
        processes["studio"] = studio_cmd

    if enable_worker:
        processes["worker"] = "m worker --concurrency 4"

    if enable_scheduler:
        processes["scheduler"] = "m worker --scheduler-only"

    # 6. Validate we have processes to run
    if not processes:
        print("❌ No processes to run!")
        print("\nTry one of:")
        print("  m dev                    # Run with defaults")
        print("  m dev --enable-worker    # Enable worker")
        print("  m dev --procfile <path>  # Use custom Procfile")
        return

    # Print startup info
    print("=" * 60)
    print("  Framework M Development Server")
    print("=" * 60)
    print()
    print("Processes:")
    for name in processes:
        if name == "backend":
            print(f"  🚀 Backend:    http://{display_host}:{port}")
        elif name == "frontend":
            print(f"  🎨 Frontend:   http://{display_host}:{frontend_port}")
        elif name == "studio":
            print(f"  🎯 Studio:     http://{display_host}:{studio_port}")
        elif name == "worker":
            print("  ⚙️  Worker:     Running")
        elif name == "scheduler":
            print("  ⏰ Scheduler:  Running")
        else:
            print(f"  📦 {name.capitalize()}:      Running")
    print()
    print("  Press Ctrl+C to stop all servers")
    print("=" * 60)
    print()

    # Create honcho manager
    manager = Manager(Printer(output=sys.stdout))

    # Add all processes
    for name, cmd in processes.items():
        manager.add_process(name, cmd, env=env)

    # Handle graceful shutdown
    def signal_handler(signum: int, frame: object) -> None:
        print("\n\n🛑 Stopping all servers...")
        manager.terminate()

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # Run all processes
    manager.loop()

    print("\n✅ All servers stopped.")


__all__ = ["dev_command"]
