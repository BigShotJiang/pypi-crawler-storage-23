"""Utility CLI commands for Framework M Studio."""

from __future__ import annotations

from typing import Annotated

import cyclopts
from rich.console import Console

console = Console()


def check_ipython_installed() -> bool:
    """Check if IPython is installed."""
    try:
        import IPython  # type: ignore # noqa: F401

        return True
    except ImportError:
        return False


def console_command() -> None:
    """Start an interactive console."""
    if check_ipython_installed():
        import IPython

        IPython.embed(header="Framework M Console")
    else:
        import code

        code.interact(banner="Framework M Console (IPython not installed)")


def routes_command(
    app_path: Annotated[
        str | None,
        cyclopts.Parameter(name="--app", help="App path to inspect"),
    ] = None,
) -> None:
    """List API routes."""
    console.print("Routes: /api/v1 (Mock)")
    if app_path:
        console.print(f"Inspecting app: {app_path}")


__all__ = [
    "console_command",
    "routes_command",
]
