"""Checklist Parser - Extract features from Phase checklists.

This module parses markdown checklist files to extract:
- Completed features ([x])
- Feature metadata (phase, category, description)
- Implementation status

Used for generating:
- Features documentation page
- Release notes from version diffs
- Progress tracking
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class ChecklistItem:
    """A single checklist item from a phase."""

    phase: str
    section: str
    description: str
    completed: bool
    subsection: str | None = None
    line_number: int = 0
    indent_level: int = 0


@dataclass
class PhaseInfo:
    """Information about a phase from its checklist."""

    phase_id: str
    title: str
    objective: str
    items: list[ChecklistItem] = field(default_factory=list)
    completion_percentage: float = 0.0


def parse_checklist_file(filepath: Path) -> PhaseInfo:
    """Parse a phase checklist markdown file.

    Args:
        filepath: Path to the checklist markdown file.

    Returns:
        PhaseInfo with extracted items and metadata.

    Example:
        >>> phase = parse_checklist_file(Path("checklists/phase-01-core-kernel.md"))
        >>> print(f"{phase.title}: {phase.completion_percentage:.0f}% complete")
        Phase 01: Core Kernel & Interfaces: 95% complete
    """
    content = filepath.read_text()
    lines = content.split("\n")

    # Extract phase metadata from filename and first heading
    phase_id = _extract_phase_id(filepath.name)
    title = ""
    objective = ""
    current_section = "Unknown"
    current_subsection: str | None = None
    items: list[ChecklistItem] = []

    for line_num, line in enumerate(lines, 1):
        # Extract title from first H1
        if line.startswith("# ") and not title:
            title = line[2:].strip()
            continue

        # Extract objective
        if line.startswith("**Objective**:"):
            objective = line.split(":", 1)[1].strip()
            continue

        # Track current section (## headers)
        if line.startswith("## "):
            current_section = line[3:].strip()
            current_subsection = None
            continue

        # Track subsections (### headers)
        if line.startswith("### "):
            current_subsection = line[4:].strip()
            continue

        # Parse checklist items
        if match := re.match(r"^(\s*)- \[([ x])\] (.+)$", line):
            indent = match.group(1)
            is_checked = match.group(2) == "x"
            description = match.group(3).strip()

            items.append(
                ChecklistItem(
                    phase=phase_id,
                    section=current_section,
                    subsection=current_subsection,
                    description=description,
                    completed=is_checked,
                    line_number=line_num,
                    indent_level=len(indent),
                )
            )

    # Calculate completion percentage
    completed_count = sum(1 for item in items if item.completed)
    total_count = len(items)
    completion_percentage = (
        (completed_count / total_count * 100) if total_count > 0 else 0.0
    )

    return PhaseInfo(
        phase_id=phase_id,
        title=title,
        objective=objective,
        items=items,
        completion_percentage=completion_percentage,
    )


def _extract_phase_id(filename: str) -> str:
    """Extract phase ID from filename.

    Args:
        filename: Checklist filename (e.g., "phase-01-core-kernel.md")

    Returns:
        Phase ID (e.g., "01")

    Example:
        >>> _extract_phase_id("phase-01-core-kernel.md")
        '01'
        >>> _extract_phase_id("phase-11-package-split.md")
        '11'
    """
    match = re.search(r"phase-(\d+[a-z]?)", filename)
    return match.group(1) if match else "unknown"


def scan_all_checklists(checklists_dir: Path) -> list[PhaseInfo]:
    """Scan all checklist files in a directory.

    Args:
        checklists_dir: Directory containing phase-*.md files.

    Returns:
        List of PhaseInfo objects, sorted by phase ID.

    Example:
        >>> phases = scan_all_checklists(Path("checklists"))
        >>> for phase in phases:
        ...     print(f"{phase.phase_id}: {phase.completion_percentage:.0f}%")
    """
    checklist_files = sorted(checklists_dir.glob("phase-*.md"))
    phases = [parse_checklist_file(f) for f in checklist_files]
    return sorted(phases, key=lambda p: p.phase_id)


def group_by_category(items: list[ChecklistItem]) -> dict[str, list[ChecklistItem]]:
    """Group checklist items by section.

    Args:
        items: List of checklist items.

    Returns:
        Dictionary mapping section names to items.

    Example:
        >>> items = phase.items
        >>> grouped = group_by_category(items)
        >>> for category, category_items in grouped.items():
        ...     print(f"{category}: {len(category_items)} items")
    """
    groups: dict[str, list[ChecklistItem]] = {}
    for item in items:
        section_key = f"{item.section}"
        if item.subsection:
            section_key = f"{item.section} > {item.subsection}"

        if section_key not in groups:
            groups[section_key] = []
        groups[section_key].append(item)

    return groups


def filter_completed(items: list[ChecklistItem]) -> list[ChecklistItem]:
    """Filter to only completed items.

    Args:
        items: List of checklist items.

    Returns:
        List of completed items only.
    """
    return [item for item in items if item.completed]


def generate_features_summary(phases: list[PhaseInfo]) -> str:
    """Generate a markdown summary of all features.

    Args:
        phases: List of phase information objects.

    Returns:
        Markdown-formatted feature summary.

    Example:
        >>> phases = scan_all_checklists(Path("checklists"))
        >>> summary = generate_features_summary(phases)
        >>> print(summary)
    """
    lines = [
        "# Framework M Features",
        "",
        "Auto-generated feature list from phase checklists.",
        "",
        "## Overview",
        "",
        "| Phase | Title | Completion |",
        "|-------|-------|------------|",
    ]

    # Overview table
    for phase in phases:
        completion_bar = _progress_bar(phase.completion_percentage)
        lines.append(
            f"| {phase.phase_id} | [{phase.title}](#{_slugify(phase.title)}) | {completion_bar} {phase.completion_percentage:.0f}% |"
        )

    lines.extend(["", "---", ""])

    # Detailed sections
    for phase in phases:
        lines.append(f"## {phase.title}")
        lines.append("")
        lines.append(f"**Phase**: {phase.phase_id}")
        lines.append(f"**Objective**: {phase.objective}")
        lines.append(f"**Status**: {phase.completion_percentage:.0f}% Complete")
        lines.append("")

        # Group by category
        grouped = group_by_category(phase.items)
        for category, items in grouped.items():
            completed = [i for i in items if i.completed]
            pending = [i for i in items if not i.completed]

            lines.append(f"### {category}")
            lines.append("")
            lines.append(
                f"**Progress**: {len(completed)}/{len(items)} ({len(completed) / len(items) * 100:.0f}%)"
            )
            lines.append("")

            if completed:
                lines.append("**Completed:**")
                lines.append("")
                for item in completed:
                    lines.append(f"- ✅ {item.description}")
                lines.append("")

            if pending:
                lines.append("**Pending:**")
                lines.append("")
                for item in pending:
                    lines.append(f"- ⏳ {item.description}")
                lines.append("")

        lines.append("---")
        lines.append("")

    return "\n".join(lines)


def _progress_bar(percentage: float, width: int = 10) -> str:
    """Generate a text progress bar.

    Args:
        percentage: Completion percentage (0-100).
        width: Width of the progress bar in characters.

    Returns:
        Unicode progress bar string.

    Example:
        >>> _progress_bar(75, 10)
        '████████░░'
    """
    filled = int(percentage / 100 * width)
    empty = width - filled
    return "█" * filled + "░" * empty


def _slugify(text: str) -> str:
    """Convert text to URL-friendly slug.

    Args:
        text: Text to slugify.

    Returns:
        Lowercase slug with hyphens.

    Example:
        >>> _slugify("Core Kernel & Interfaces")
        'core-kernel--interfaces'
    """
    slug = text.lower()
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = re.sub(r"[-\s]+", "-", slug)
    return slug.strip("-")


def compare_versions(
    old_items: list[ChecklistItem],
    new_items: list[ChecklistItem],
) -> dict[str, Any]:
    """Compare two versions of checklist items to find changes.

    Args:
        old_items: Checklist items from old version.
        new_items: Checklist items from new version.

    Returns:
        Dictionary with newly_completed, newly_added, and removed items.

    Example:
        >>> changes = compare_versions(old_phase.items, new_phase.items)
        >>> print(f"Newly completed: {len(changes['newly_completed'])}")
    """
    # Create lookup by description for comparison
    old_map = {item.description: item for item in old_items}
    new_map = {item.description: item for item in new_items}

    newly_completed = []
    newly_added = []
    removed = []

    # Find newly completed items
    for desc, new_item in new_map.items():
        old_item = old_map.get(desc)
        if old_item and not old_item.completed and new_item.completed:
            newly_completed.append(new_item)
        elif not old_item:
            newly_added.append(new_item)

    # Find removed items
    for desc in old_map:
        if desc not in new_map:
            removed.append(old_map[desc])

    return {
        "newly_completed": newly_completed,
        "newly_added": newly_added,
        "removed": removed,
    }


def generate_release_notes(changes: dict[str, Any], version: str) -> str:
    """Generate release notes from checklist changes.

    Args:
        changes: Dictionary from compare_versions().
        version: Version string (e.g., "1.0.0").

    Returns:
        Markdown-formatted release notes.

    Example:
        >>> changes = compare_versions(old_items, new_items)
        >>> notes = generate_release_notes(changes, "1.0.0")
    """
    lines = [
        f"# Release {version}",
        "",
        "## What's New",
        "",
    ]

    newly_completed = changes.get("newly_completed", [])
    newly_added = changes.get("newly_added", [])

    if newly_completed:
        # Group by phase
        by_phase: dict[str, list[ChecklistItem]] = {}
        for item in newly_completed:
            if item.phase not in by_phase:
                by_phase[item.phase] = []
            by_phase[item.phase].append(item)

        lines.append("### Completed Features")
        lines.append("")

        for phase_id in sorted(by_phase.keys()):
            items = by_phase[phase_id]
            lines.append(f"#### Phase {phase_id}")
            lines.append("")
            for item in items:
                section_info = f"{item.section}"
                if item.subsection:
                    section_info += f" > {item.subsection}"
                lines.append(f"- **{section_info}**: {item.description}")
            lines.append("")

    if newly_added:
        lines.append("### New Checklist Items")
        lines.append("")
        for item in newly_added:
            lines.append(f"- {item.description}")
        lines.append("")

    if not newly_completed and not newly_added:
        lines.append("_No new features in this release._")
        lines.append("")

    return "\n".join(lines)
