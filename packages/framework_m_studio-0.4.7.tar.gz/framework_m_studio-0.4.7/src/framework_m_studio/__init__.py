"""Framework M Studio - Visual DocType Builder & Developer Tools.

This package provides development-time tools for Framework M:
- Visual DocType builder (Studio UI)
- LibCST-based code generators
- Extended CLI commands (codegen, docs)

This package is separated from framework-m core to keep the
runtime lightweight. Install as a dev dependency.
"""

from __future__ import annotations

import importlib.metadata

try:
    __version__ = importlib.metadata.version("framework-m-studio")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = ["__version__"]
