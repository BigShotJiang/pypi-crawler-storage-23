"""Documentation Generator for Framework M.

Generates API documentation from DocTypes and Controllers.
Supports markdown output and MkDocs integration.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen


def escape_mdx(text: str) -> str:
    """Escape MDX special characters like braces in text.

    Docusaurus/MDX treats {braces} as JSX expressions. This function
    escapes them using HTML entities so they are rendered as literal text.
    """
    if not text:
        return ""
    return text.replace("{", "&#123;").replace("}", "&#125;")


def format_field_table(fields: list[dict[str, Any]]) -> str:
    """Format fields as a markdown table.

    Args:
        fields: List of field dictionaries.

    Returns:
        Markdown table string.
    """
    if not fields:
        return "_No fields defined._\n"

    lines = [
        "| Field | Type | Required | Description | Validators |",
        "|-------|------|----------|-------------|------------|",
    ]

    for field in fields:
        name = field.get("name", "")
        field_type = field.get("type", "str")
        required = "✓" if field.get("required", True) else ""
        description = escape_mdx(field.get("description", "")) or "-"

        # Format validators
        validators = field.get("validators", {})
        if validators:
            validator_strs = []
            if validators.get("min_value") is not None:
                validator_strs.append(f"min: {validators['min_value']}")
            if validators.get("max_value") is not None:
                validator_strs.append(f"max: {validators['max_value']}")
            if validators.get("min_length") is not None:
                validator_strs.append(f"minLen: {validators['min_length']}")
            if validators.get("max_length") is not None:
                validator_strs.append(f"maxLen: {validators['max_length']}")
            if validators.get("pattern"):
                validator_strs.append(f"pattern: `{validators['pattern']}`")
            validators_str = ", ".join(validator_strs) if validator_strs else "-"
        else:
            validators_str = "-"

        lines.append(
            f"| {name} | {field_type} | {required} | {description} | {validators_str} |"
        )

    return "\n".join(lines) + "\n"


def format_meta_section(meta: dict[str, Any]) -> str:
    """Format Meta configuration as markdown.

    Args:
        meta: Meta configuration dictionary.

    Returns:
        Markdown string.
    """
    if not meta:
        return ""

    lines = ["## Configuration", "", "| Setting | Value |", "|---------|-------|"]

    settings = [
        ("Table Name", meta.get("tablename")),
        ("Naming Pattern", meta.get("name_pattern")),
        ("Submittable", meta.get("is_submittable")),
        ("Track Changes", meta.get("track_changes")),
    ]

    for setting, value in settings:
        if value is not None:
            lines.append(f"| {setting} | `{value}` |")

    if len(lines) > 4:  # Has at least one setting
        lines.append("")
        return "\n".join(lines)
    return ""


def format_permission_matrix(
    permissions: dict[str, list[str]] | None,
) -> str:
    """Format permissions as a role-based matrix table.

    Creates a table where rows are roles and columns are permission types.
    Shows ✓ for granted permissions.

    Args:
        permissions: Dict of permission_type -> list of roles

    Returns:
        Markdown table string.
    """
    if not permissions:
        return "_No permissions defined._\n"

    # Collect all roles and permission types
    all_roles: set[str] = set()
    for roles in permissions.values():
        all_roles.update(roles)

    # Sort for consistent output
    sorted_roles = sorted(all_roles)
    sorted_actions = sorted(permissions.keys())

    # Build header
    header_cols = ["Role"] + [action.capitalize() for action in sorted_actions]
    header = "| " + " | ".join(header_cols) + " |"
    separator = "|" + "|".join(["------"] * len(header_cols)) + "|"

    lines = [header, separator]

    # Build rows for each role
    for role in sorted_roles:
        row = [role]
        for action in sorted_actions:
            has_permission = role in permissions.get(action, [])
            row.append("✓" if has_permission else "")
        lines.append("| " + " | ".join(row) + " |")

    lines.append("")
    return "\n".join(lines)


def generate_doctype_markdown(doctype_info: dict[str, Any]) -> str:
    """Generate markdown documentation for a DocType.

    Args:
        doctype_info: DocType information dictionary.

    Returns:
        Markdown string.
    """
    from pathlib import Path

    name = doctype_info.get("name", "Unknown")
    docstring = escape_mdx(doctype_info.get("docstring", ""))
    fields = doctype_info.get("fields", [])
    meta = doctype_info.get("meta", {})
    file_path = doctype_info.get("file_path", "")

    lines = [
        f"# {name}",
        "",
    ]

    if docstring:
        lines.extend([docstring, ""])

    # Source file link
    if file_path:
        filename = Path(file_path).name
        file_uri = f"file://{file_path}"
        lines.extend([f"**Source**: [{filename}]({file_uri})", ""])

    # Fields section
    lines.extend(
        [
            "## Fields",
            "",
            format_field_table(fields),
        ]
    )

    # Permissions section
    permissions = meta.get("permissions") if meta else None
    if permissions:
        lines.extend(
            [
                "## Permissions",
                "",
                format_permission_matrix(permissions),
            ]
        )

    # Meta configuration section
    meta_section = format_meta_section(meta)
    if meta_section:
        lines.append(meta_section)

    # Controller info placeholder
    lines.extend(
        [
            "## Controller",
            "",
            "Controller hooks are implemented in `*_controller.py` files.",
            "Available lifecycle hooks:",
            "",
            "- `validate()` - Called before save, raise exceptions for validation errors",
            "- `before_insert()` - Called before inserting a new document",
            "- `after_insert()` - Called after successfully inserting",
            "- `before_save()` - Called before saving (insert or update)",
            "- `after_save()` - Called after saving",
            "- `before_delete()` - Called before deleting",
            "- `after_delete()` - Called after deleting",
            "",
        ]
    )

    return "\n".join(lines)


def generate_index(doctypes: list[str]) -> str:
    """Generate index.md with links to all DocTypes.

    Args:
        doctypes: List of DocType names.

    Returns:
        Index markdown string.
    """
    lines = [
        "# API Reference",
        "",
        "## DocTypes",
        "",
    ]

    for name in sorted(doctypes):
        filename = name.lower() + ".md"
        lines.append(f"- [{name}]({filename})")

    lines.append("")
    return "\n".join(lines)


def generate_api_reference(
    doctypes: list[dict[str, Any]],
    output_dir: Path,
) -> None:
    """Generate API reference documentation for all DocTypes.

    Args:
        doctypes: List of DocType info dictionaries.
        output_dir: Output directory for markdown files.
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    doctype_names = []

    for doctype in doctypes:
        name = doctype.get("name", "Unknown")
        doctype_names.append(name)

        markdown = generate_doctype_markdown(doctype)
        filename = name.lower() + ".md"
        (output_dir / filename).write_text(markdown)

    # Generate index
    index_md = generate_index(doctype_names)
    (output_dir / "index.md").write_text(index_md)


def export_openapi_json(
    openapi_url: str,
    output_file: Path,
    *,
    timeout: int = 30,
) -> None:
    """Export OpenAPI JSON from a running app.

    Args:
        openapi_url: URL to fetch OpenAPI schema from.
        output_file: Output file path for JSON.
        timeout: Request timeout in seconds.
    """
    request = Request(openapi_url)
    request.add_header("Accept", "application/json")

    with urlopen(request, timeout=timeout) as response:
        schema = json.loads(response.read().decode("utf-8"))

    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(json.dumps(schema, indent=2))


def generate_openapi_markdown(
    schema: dict[str, Any],
    *,
    include_examples: bool = False,
) -> str:
    """Generate human-readable markdown from OpenAPI schema.

    Groups endpoints by tags and includes method, path, and summary.

    Args:
        schema: OpenAPI JSON schema dict
        include_examples: If True, include request/response examples

    Returns:
        Markdown string
    """
    info = schema.get("info", {})
    title = info.get("title", "API Reference")
    version = info.get("version", "")
    paths = schema.get("paths", {})

    lines = [f"# {title}"]
    if version:
        lines.append(f"\n**Version**: {version}")
    lines.append("")

    # Group endpoints by tag - now store full details if examples needed
    endpoints_by_tag: dict[str, list[dict[str, Any]]] = {}

    for path, methods in paths.items():
        for method, details in methods.items():
            if method in ("get", "post", "put", "patch", "delete"):
                summary = details.get("summary", details.get("operationId", ""))
                tags = details.get("tags", ["Other"])
                for tag in tags:
                    if tag not in endpoints_by_tag:
                        endpoints_by_tag[tag] = []
                    endpoints_by_tag[tag].append(
                        {
                            "method": method.upper(),
                            "path": path,
                            "summary": summary,
                            "details": details if include_examples else {},
                        }
                    )

    # Generate sections by tag
    for tag in sorted(endpoints_by_tag.keys()):
        lines.extend([f"## {tag}", ""])

        lines.extend(
            ["| Method | Path | Description |", "|--------|------|-------------|"]
        )

        for endpoint in endpoints_by_tag[tag]:
            lines.append(
                f"| {endpoint['method']} | `{endpoint['path']}` | {endpoint['summary']} |"
            )

        lines.append("")

        # Include examples if requested
        if include_examples:
            for endpoint in endpoints_by_tag[tag]:
                details = endpoint.get("details", {})

                # Request example
                request_body = details.get("requestBody", {})
                if request_body:
                    content = request_body.get("content", {})
                    json_content = content.get("application/json", {})
                    example = json_content.get("example")
                    if example:
                        lines.append(
                            f"### {endpoint['method']} {endpoint['path']} - Request"
                        )
                        lines.append("")
                        lines.append("```json")
                        lines.append(json.dumps(example, indent=2))
                        lines.append("```")
                        lines.append("")

                # Response example
                responses = details.get("responses", {})
                for status_code, response in responses.items():
                    content = response.get("content", {})
                    json_content = content.get("application/json", {})
                    example = json_content.get("example")
                    if example:
                        lines.append(
                            f"### {endpoint['method']} {endpoint['path']} - Response ({status_code})"
                        )
                        lines.append("")
                        lines.append("```json")
                        lines.append(json.dumps(example, indent=2))
                        lines.append("```")
                        lines.append("")

    return "\n".join(lines)


def run_docs_generate(
    output: str = "./docs/api",
    project_root: str | None = None,
    openapi_url: str | None = None,
    build_site: bool = False,
) -> None:
    """Run the documentation generator.

    Args:
        output: Output directory for documentation.
        project_root: Project root directory (for DocType discovery).
        openapi_url: Optional OpenAPI URL to export.
        build_site: If True, run mkdocs build if available.
    """
    from framework_m_studio.discovery import doctype_to_dict, scan_doctypes

    output_dir = Path(output)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Determine project root
    root = Path(project_root) if project_root else Path.cwd()

    # Scan for DocTypes
    doctypes = scan_doctypes(root)
    doctype_infos = [doctype_to_dict(dt) for dt in doctypes]

    # Generate API reference
    generate_api_reference(doctype_infos, output_dir)

    print(f"📚 Generated documentation for {len(doctypes)} DocTypes")
    print(f"   Output: {output_dir}")

    # Export OpenAPI if URL provided
    if openapi_url:
        openapi_file = output_dir / "openapi.json"
        try:
            export_openapi_json(openapi_url, openapi_file)
            print(f"   OpenAPI: {openapi_file}")
        except Exception as e:
            print(f"   ⚠️  Failed to export OpenAPI: {e}")

    # Run mkdocs build if requested
    if build_site:
        run_mkdocs_build(root)


def run_mkdocs_build(project_root: Path) -> bool:
    """Run mkdocs build if mkdocs is installed.

    Args:
        project_root: Project root directory.

    Returns:
        True if build succeeded, False otherwise.
    """
    import shutil
    import subprocess

    # Check if mkdocs is available
    mkdocs_path = shutil.which("mkdocs")
    if not mkdocs_path:
        print("   [i] mkdocs not found, skipping site build")
        print("      Install with: pip install mkdocs-material")
        return False

    # Check if mkdocs.yml exists
    mkdocs_config = project_root / "mkdocs.yml"
    if not mkdocs_config.exists():
        print("   [i] No mkdocs.yml found, skipping site build")
        return False

    # Run mkdocs build
    print("   🔨 Building documentation site...")
    try:
        result = subprocess.run(
            [mkdocs_path, "build"],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode == 0:
            print("   ✅ Site built successfully")
            return True
        else:
            print(f"   ❌ mkdocs build failed: {result.stderr}")
            return False
    except subprocess.TimeoutExpired:
        print("   ❌ mkdocs build timed out")
        return False
    except Exception as e:
        print(f"   ❌ mkdocs build error: {e}")
        return False


def export_rag_corpus(
    project_root: Path,
    output_file: Path,
    include_tests: bool = False,
) -> None:
    """Export documentation and source code as a JSONL corpus for RAG/LLM.

    Args:
        project_root: Project root directory.
        output_file: Output file path (.jsonl).
        include_tests: If True, include test files in the corpus.
    """
    import json

    corpus = []

    # 1. Export DocTypes
    from framework_m_studio.discovery import doctype_to_dict, scan_doctypes

    doctypes = scan_doctypes(project_root)
    for dt in doctypes:
        dt_dict = doctype_to_dict(dt)
        corpus.append(
            {
                "id": f"doctype-{dt_dict['name'].lower()}",
                "type": "doctype",
                "title": f"DocType: {dt_dict['name']}",
                "content": generate_doctype_markdown(dt_dict),
                "metadata": {
                    "module": dt.__module__,
                    "name": dt_dict["name"],
                },
            }
        )

    # 2. Export Markdown Files (Docs, ADRs, RFCs, Frontend Docs)
    doc_paths = list(project_root.glob("docs/**/*.md"))
    doc_paths.extend(project_root.glob("checklists/*.md"))
    doc_paths.extend(project_root.glob("frontend/docs/**/*.md"))

    for path in doc_paths:
        if path.name == "index.md" or "generated" in str(path):
            continue

        try:
            content = path.read_text()
            rel_path = path.relative_to(project_root)
            doc_type = "doc"
            if "adr" in str(rel_path):
                doc_type = "adr"
            elif "rfc" in str(rel_path):
                doc_type = "rfc"
            elif "checklist" in str(rel_path):
                doc_type = "checklist"
            elif "frontend/docs" in str(rel_path):
                doc_type = "frontend-doc"

            corpus.append(
                {
                    "id": f"file-{str(rel_path).replace('/', '-')}",
                    "type": doc_type,
                    "title": f"Document: {rel_path}",
                    "content": content,
                    "metadata": {
                        "path": str(rel_path),
                    },
                }
            )
        except Exception as e:
            print(f"   ⚠️  Failed to read {path}: {e}")

    # 3. Export Tests (Optional)
    if include_tests:
        test_paths = list(project_root.glob("tests/**/*.py"))
        for path in test_paths:
            try:
                content = path.read_text()
                rel_path = path.relative_to(project_root)
                corpus.append(
                    {
                        "id": f"test-{str(rel_path).replace('/', '-')}",
                        "type": "test",
                        "title": f"Test: {rel_path}",
                        "content": f"```python\n{content}\n```",
                        "metadata": {
                            "path": str(rel_path),
                        },
                    }
                )
            except Exception as e:
                print(f"   ⚠️  Failed to read {path}: {e}")

    # Write JSONL
    output_file.parent.mkdir(parents=True, exist_ok=True)
    with output_file.open("w") as f:
        for entry in corpus:
            f.write(json.dumps(entry) + "\n")


def run_docs_export(
    output: str = "./docs/machine/corpus.jsonl",
    project_root: str | None = None,
    include_tests: bool = False,
) -> None:
    """Run the documentation export.

    Args:
        output: Output file path for the corpus.
        project_root: Project root directory.
        include_tests: If True, include tests in the export.
    """
    root = Path(project_root) if project_root else Path.cwd()
    output_file = Path(output)

    print(f"📤 Exporting RAG corpus to {output_file}...")
    export_rag_corpus(root, output_file, include_tests=include_tests)
    print("   ✅ Export complete")
