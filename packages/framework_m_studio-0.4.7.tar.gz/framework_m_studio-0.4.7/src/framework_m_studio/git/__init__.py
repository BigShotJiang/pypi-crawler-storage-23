# Git module for Studio Cloud Mode
