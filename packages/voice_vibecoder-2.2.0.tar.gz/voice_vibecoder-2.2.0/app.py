#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.10"
# dependencies = ["voice-vibecoder"]
# [tool.uv.sources]
# voice-vibecoder = { path = "." }
# ///
"""Standalone entry point for Olaf The Vibecoder."""

from voice_vibecoder import VoiceCodingApp

VoiceCodingApp().run()
