"""Claude Agent SDK runner.

Implements the AgentRunner protocol using the Claude Agent SDK for
streaming code agent interactions. Handles session resume/retry,
SDK event processing, and tool permission delegation.
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Any, Awaitable, Callable

from claude_agent_sdk import (
    AssistantMessage,
    ClaudeAgentOptions,
    PermissionResultAllow,
    PermissionResultDeny,
    ProcessError,
    ResultMessage,
    TextBlock,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
    query,
)

from voice_vibecoder.code_providers import AgentOutput, AgentResult

logger = logging.getLogger(__name__)


def _sdk_permission_mode(mode: str) -> str | None:
    if mode == "bypass":
        return "bypassPermissions"
    elif mode == "acceptEdits":
        return "acceptEdits"
    return "default"


def _basename(path: str) -> str:
    return path.rsplit("/", 1)[-1] if path else "unknown"


def describe_tool_call(name: str, inp: dict) -> str:
    """Human-readable description of a Claude tool invocation."""
    if name == "Read":
        path = inp.get("file_path", "")
        limit = inp.get("limit")
        s = f"\\[Read] {_basename(path)}"
        if limit:
            s += f" (first {limit} lines)"
        return s
    elif name == "Edit":
        return f"\\[Edit] {_basename(inp.get('file_path', ''))}"
    elif name == "Write":
        base = _basename(inp.get("file_path", ""))
        content = inp.get("content", "")
        line_count = len(content.splitlines()) if content else 0
        suffix = f" ({line_count} lines)" if line_count else ""
        return f"\\[Write] {base}{suffix}"
    elif name == "Bash":
        cmd = inp.get("command", "")
        # For multi-line commands (heredocs, chained), show only the first line
        first_line = cmd.split("\n", 1)[0].strip()
        preview = first_line[:120] + "..." if len(first_line) > 120 else first_line
        return f"\\[Bash] {preview}"
    elif name == "Glob":
        return f"\\[Glob] {inp.get('pattern', '')}"
    elif name == "Grep":
        return f"\\[Grep] {inp.get('pattern', '')}"
    elif name == "Task":
        desc = inp.get("description", "")
        return f"\\[Task] {desc}" if desc else "\\[Task] subagent"
    elif name == "WebSearch":
        return f"\\[WebSearch] {inp.get('query', '')}"
    elif name == "WebFetch":
        url = inp.get("url", "")
        return f"\\[WebFetch] {url[:60]}"
    elif name.startswith("mcp__"):
        # MCP tool: mcp__<server>__<tool> → [Server: tool description]
        parts = name.split("__", 2)
        server = parts[1].capitalize() if len(parts) > 1 else "MCP"
        tool = parts[2] if len(parts) > 2 else name
        # Strip server prefix from tool name (e.g. jira_search → search)
        if tool.lower().startswith(server.lower() + "_"):
            tool = tool[len(server) + 1:]
        label = tool.replace("_", " ").capitalize()
        # Add context from input parameters
        detail = ""
        if "issue_key" in inp:
            detail = inp["issue_key"]
        elif "jql" in inp:
            detail = inp["jql"][:60]
        elif "query" in inp:
            detail = inp["query"][:60]
        elif "project_key" in inp:
            detail = inp["project_key"]
        suffix = f" {detail}" if detail else ""
        return f"\\[{server}] {label}{suffix}"
    else:
        return f"\\[{name}]"


MAX_DIFF_LINES = 20


def _emit_edit_diff(
    on_output: Callable[[AgentOutput], None],
    name: str,
    inp: dict,
) -> None:
    """Emit inline diff lines after a file_edit header."""
    if name == "Write":
        content = inp.get("content", "")
        if not content:
            return
        lines = content.splitlines()
        for i, line in enumerate(lines):
            if i >= MAX_DIFF_LINES:
                on_output(AgentOutput(category="diff_add", content=f"... (+{len(lines) - i} more)"))
                break
            on_output(AgentOutput(category="diff_add", content=line))
        return

    if name != "Edit":
        return
    old = inp.get("old_string", "")
    new = inp.get("new_string", "")
    if not old and not new:
        return
    removed = old.splitlines() if old else []
    added = new.splitlines() if new else []
    count = 0
    for line in removed:
        if count >= MAX_DIFF_LINES:
            on_output(AgentOutput(category="diff_del", content="..."))
            break
        on_output(AgentOutput(category="diff_del", content=line))
        count += 1
    for line in added:
        if count >= MAX_DIFF_LINES:
            on_output(AgentOutput(category="diff_add", content="..."))
            break
        on_output(AgentOutput(category="diff_add", content=line))
        count += 1


class ClaudeRunner:
    """AgentRunner implementation using the Claude Agent SDK."""

    def __init__(
        self,
        permission_mode: str = "bypass",
        env: dict[str, str] | None = None,
        mcp_servers: dict[str, dict] | None = None,
    ) -> None:
        self._permission_mode = permission_mode
        self._env = env
        self._mcp_servers = mcp_servers
        self._task: asyncio.Task | None = None

    async def run(
        self,
        message: str,
        cwd: str,
        session_id: str | None = None,
        on_output: Callable[[AgentOutput], None] | None = None,
        can_use_tool: Callable[[str, dict, Any], Awaitable[Any]] | None = None,
    ) -> AgentResult:
        self._task = asyncio.current_task()
        stderr_lines: list[str] = []

        def _capture_stderr(line: str) -> None:
            stderr_lines.append(line)
            if on_output:
                on_output(AgentOutput(category="text", content=f"[stderr] {line}"))

        env = (self._env.copy() if self._env else os.environ.copy())
        env.pop("CLAUDECODE", None)

        model = os.environ.get("CLAUDE_MODEL") or None

        options = ClaudeAgentOptions(
            cwd=cwd,
            model=model,
            permission_mode=_sdk_permission_mode(self._permission_mode),
            can_use_tool=lambda tool, inp, ctx: self._sdk_can_use_tool(
                tool, inp, ctx, can_use_tool
            ),
            setting_sources=["user", "project"],
            env=env,
            debug_stderr=None,
            stderr=_capture_stderr,
        )

        if self._mcp_servers:
            options.mcp_servers = self._mcp_servers

        if session_id:
            options.resume = session_id

        was_resume = bool(session_id)

        try:
            return await self._stream(message, session_id or "", options, on_output)
        except Exception as e:
            if was_resume and isinstance(e, ProcessError):
                logger.info("Resume failed, retrying as fresh session")
                if on_output:
                    on_output(AgentOutput(
                        category="text",
                        content="Resume failed, starting fresh session...",
                    ))
                options.resume = None
                stderr_lines.clear()
                try:
                    return await self._stream(message, "", options, on_output)
                except (ProcessError, Exception) as retry_err:
                    raise self._wrap_error(retry_err, stderr_lines) from retry_err
            raise self._wrap_error(e, stderr_lines) from e

    def cancel(self) -> bool:
        task = self._task
        if task and not task.done():
            task.cancel()
            return True
        return False

    # -- Internal --

    async def _stream(
        self,
        message: str,
        session_id: str,
        options: ClaudeAgentOptions,
        on_output: Callable[[AgentOutput], None] | None,
    ) -> AgentResult:
        result_text = ""
        result_session_id: str | None = None

        async def _prompt():
            yield {
                "type": "user",
                "message": {"role": "user", "content": message},
                "parent_tool_use_id": None,
                "session_id": session_id,
            }

        async for msg in query(prompt=_prompt(), options=options):
            if isinstance(msg, AssistantMessage):
                for block in msg.content:
                    if isinstance(block, TextBlock):
                        text = block.text.strip()
                        if text and on_output:
                            for line in text.splitlines():
                                if line.strip():
                                    on_output(AgentOutput(
                                        category="text", content=line,
                                    ))

                    elif isinstance(block, ToolUseBlock):
                        if not block.name:
                            continue
                        desc = describe_tool_call(block.name, block.input)
                        if on_output:
                            category = (
                                "file_edit" if block.name in ("Edit", "Write")
                                else "bash" if block.name == "Bash"
                                else "tool_call"
                            )
                            on_output(AgentOutput(
                                category=category, content=desc,
                            ))
                            if block.name in ("Edit", "Write"):
                                _emit_edit_diff(on_output, block.name, block.input)

                    elif isinstance(block, ToolResultBlock):
                        content = block.content or ""
                        if isinstance(content, str) and content.strip() and on_output:
                            preview = content[:200] + ("..." if len(content) > 200 else "")
                            on_output(AgentOutput(
                                category="tool_result", content=preview,
                            ))

            elif isinstance(msg, UserMessage):
                if isinstance(msg.content, list):
                    for block in msg.content:
                        if isinstance(block, ToolResultBlock):
                            content = block.content or ""
                            if isinstance(content, str) and content.strip():
                                pass  # Already routed via AssistantMessage

            elif isinstance(msg, ResultMessage):
                result_text = msg.result or ""
                if msg.session_id:
                    result_session_id = msg.session_id

        return AgentResult(text=result_text, session_id=result_session_id)

    async def _sdk_can_use_tool(
        self,
        tool_name: str,
        input_data: dict[str, Any],
        context: Any,
        external_callback: Callable[[str, dict, Any], Awaitable[Any]] | None,
    ) -> PermissionResultAllow | PermissionResultDeny:
        if tool_name == "EnterPlanMode":
            return PermissionResultAllow(updated_input=input_data)

        if tool_name in ("AskUserQuestion", "ExitPlanMode") and external_callback:
            try:
                result = await external_callback(tool_name, input_data, context)
            except Exception as e:
                return PermissionResultDeny(message=str(e))

            if result is None:
                return PermissionResultDeny(
                    message="User did not respond or rejected."
                )

            if tool_name == "AskUserQuestion":
                questions = input_data.get("questions", [])
                answers = {q.get("question", ""): result for q in questions}
                return PermissionResultAllow(
                    updated_input={"questions": questions, "answers": answers}
                )

            # ExitPlanMode — approved
            return PermissionResultAllow(updated_input=input_data)

        return PermissionResultAllow(updated_input=input_data)

    @staticmethod
    def _wrap_error(err: Exception, stderr_lines: list[str]) -> RuntimeError:
        stderr_text = "\n".join(stderr_lines[-20:]) if stderr_lines else ""
        if isinstance(err, ProcessError):
            msg = f"Claude process error (exit code {err.exit_code})"
            if stderr_text:
                msg += f":\n{stderr_text}"
            elif err.stderr:
                msg += f": {err.stderr}"
        else:
            msg = f"Error running Claude: {err}"
            if stderr_text:
                msg += f"\nStderr: {stderr_text}"
        return RuntimeError(msg)
