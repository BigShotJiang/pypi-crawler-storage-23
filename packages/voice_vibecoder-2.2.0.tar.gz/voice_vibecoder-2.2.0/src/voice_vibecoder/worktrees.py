"""Git worktree management for multi-instance agent sessions.

Provides functions to list, create, and resolve git worktrees so each
agent instance can work in its own branch directory.
"""

from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

# Module-level configurable path — set via configure_paths() from screen.py.
# Defaults to cwd parent; overridden at startup with repo_root.parent.
WORKTREES_DIR = Path.cwd().parent


def configure_paths(worktrees_dir: Path) -> None:
    """Set the worktrees directory."""
    global WORKTREES_DIR
    WORKTREES_DIR = worktrees_dir


@dataclass
class WorktreeInfo:
    path: Path
    branch: str
    head: str
    is_main: bool


_worktree_cache: tuple[float, Path, list["WorktreeInfo"]] | None = None
_WORKTREE_CACHE_TTL = 10  # seconds


def list_worktrees(repo_root: Path) -> list[WorktreeInfo]:
    """Parse `git worktree list --porcelain` (cached for 10s)."""
    global _worktree_cache
    now = time.monotonic()
    if _worktree_cache:
        cached_time, cached_root, cached_result = _worktree_cache
        if cached_root == repo_root and (now - cached_time) < _WORKTREE_CACHE_TTL:
            return cached_result

    result = _list_worktrees_uncached(repo_root)
    _worktree_cache = (now, repo_root, result)
    return result


def invalidate_worktree_cache() -> None:
    """Clear the worktree cache (call after creating/removing worktrees)."""
    global _worktree_cache
    _worktree_cache = None


def _list_worktrees_uncached(repo_root: Path) -> list[WorktreeInfo]:
    """Parse `git worktree list --porcelain` and return structured info."""
    result = subprocess.run(
        ["git", "worktree", "list", "--porcelain"],
        cwd=str(repo_root),
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return []

    worktrees: list[WorktreeInfo] = []
    current: dict[str, str] = {}
    for line in result.stdout.splitlines():
        if not line.strip():
            if "worktree" in current:
                path = Path(current["worktree"])
                branch_ref = current.get("branch", "")
                branch = branch_ref.removeprefix("refs/heads/") if branch_ref else ""
                head = current.get("HEAD", "")
                is_main = "bare" not in current and path == repo_root
                worktrees.append(WorktreeInfo(
                    path=path, branch=branch, head=head, is_main=is_main,
                ))
            current = {}
            continue
        if line.startswith("worktree "):
            current["worktree"] = line.split(" ", 1)[1]
        elif line.startswith("HEAD "):
            current["HEAD"] = line.split(" ", 1)[1]
        elif line.startswith("branch "):
            current["branch"] = line.split(" ", 1)[1]
        elif line == "bare":
            current["bare"] = "true"

    # Handle last entry (no trailing blank line)
    if "worktree" in current:
        path = Path(current["worktree"])
        branch_ref = current.get("branch", "")
        branch = branch_ref.removeprefix("refs/heads/") if branch_ref else ""
        head = current.get("HEAD", "")
        is_main = path == repo_root
        worktrees.append(WorktreeInfo(
            path=path, branch=branch, head=head, is_main=is_main,
        ))

    return worktrees


def get_current_branch(path: Path) -> str:
    """Get the current branch name for a directory."""
    result = subprocess.run(
        ["git", "branch", "--show-current"],
        cwd=str(path),
        capture_output=True,
        text=True,
    )
    return result.stdout.strip() if result.returncode == 0 else ""


def ensure_worktree(branch: str, repo_root: Path) -> Path:
    """Get existing worktree for branch, or create a new one.

    If the branch exists locally, creates a worktree for it.
    Otherwise, creates a new branch with `-b`.
    """
    # Check if an existing worktree already has this branch
    for wt in list_worktrees(repo_root):
        if wt.branch == branch:
            return wt.path

    # Determine target path
    safe_name = branch.replace("/", "-")
    target = WORKTREES_DIR / f"{repo_root.name}-{safe_name}"
    target.parent.mkdir(parents=True, exist_ok=True)

    # Check if branch exists locally
    check = subprocess.run(
        ["git", "rev-parse", "--verify", f"refs/heads/{branch}"],
        cwd=str(repo_root),
        capture_output=True,
        text=True,
    )

    if check.returncode == 0:
        subprocess.run(
            ["git", "worktree", "add", str(target), branch],
            cwd=str(repo_root),
            capture_output=True, text=True, check=True,
        )
    else:
        subprocess.run(
            ["git", "worktree", "add", "-b", branch, str(target)],
            cwd=str(repo_root),
            capture_output=True, text=True, check=True,
        )

    invalidate_worktree_cache()
    return target


def remove_worktree(branch: str, repo_root: Path, delete_branch: bool = False) -> None:
    """Remove a git worktree and optionally delete the branch.

    Raises subprocess.CalledProcessError on failure.
    """
    worktrees = list_worktrees(repo_root)
    wt = next((w for w in worktrees if w.branch == branch), None)
    if not wt:
        raise ValueError(f"No worktree found for branch '{branch}'")
    if wt.is_main:
        raise ValueError("Cannot remove the main worktree")

    subprocess.run(
        ["git", "worktree", "remove", str(wt.path), "--force"],
        cwd=str(repo_root),
        capture_output=True, text=True, check=True,
    )
    invalidate_worktree_cache()

    if delete_branch:
        subprocess.run(
            ["git", "branch", "-D", branch],
            cwd=str(repo_root),
            capture_output=True,
            text=True,
            check=True,
        )


def resolve_worktree_path(branch: str, repo_root: Path) -> Path:
    """Ensure a worktree exists for the branch.

    Returns repo_root if the branch is already checked out there (git
    doesn't allow two worktrees for the same branch). Otherwise creates
    a new worktree under WORKTREES_DIR.
    """
    return ensure_worktree(branch, repo_root)
