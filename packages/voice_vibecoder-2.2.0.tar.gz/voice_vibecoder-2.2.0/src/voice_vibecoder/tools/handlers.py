"""Tool handlers for branch management, status, diff, and UI commands.

Each function handles one tool call from the dispatcher in dispatch.py.
"""

import subprocess

from voice_vibecoder.instances import AgentInstance, InstanceStatus, InstanceType
from voice_vibecoder.tools import dispatch as _dispatch
from voice_vibecoder.tools.dispatch import (
    _resolve_instance,
    cancel_all_tasks,
    cancel_instance_task,
)
from voice_vibecoder.worktrees import remove_worktree, resolve_worktree_path


def get_startup_context() -> str:
    """Build a context string with current instances, agents, and worktrees for the system prompt."""
    from voice_vibecoder.code_providers.registry import get_agent

    parts = []

    enabled = _dispatch._enabled_agents
    if len(enabled) > 1:
        labels = [get_agent(a).label for a in enabled]
        parts.append(f"Enabled agents: {', '.join(labels)}")
        parts.append(f"Default agent: {get_agent(enabled[0]).label}")
        parts.append("Use the 'agent' parameter in send_to_agent/send_to_session to pick a specific agent.")

    if _dispatch._registry:
        code_instances = _dispatch._registry.get_all_code_instances()
        sessions = _dispatch._registry.get_all_sessions()

        if code_instances:
            parts.append("Active code instances:")
            for inst in code_instances:
                agent_label = get_agent(inst.agent_type).label
                parts.append(f"  - {inst.branch} ({inst.status.value}) [{agent_label}]")

        if sessions:
            parts.append("Active sessions:")
            for inst in sessions:
                agent_label = get_agent(inst.agent_type).label
                parts.append(f"  - {inst.display_name} ({inst.status.value}) [{agent_label}]")

    if _dispatch._repo_root:
        from voice_vibecoder.worktrees import list_worktrees

        active_branches = set()
        if _dispatch._registry:
            active_branches = {
                inst.branch for inst in _dispatch._registry.get_all_code_instances()
            }
        worktrees = list_worktrees(_dispatch._repo_root)
        available = [wt for wt in worktrees if wt.branch and wt.branch not in active_branches and not wt.is_main]
        if available:
            parts.append("Available worktrees (not yet active):")
            for wt in available:
                parts.append(f"  - {wt.branch}")

    if not parts:
        return ""
    return "Current state:\n" + "\n".join(parts)


def _handle_switch_agent(agent: str, branch: str | None = None) -> str:
    from voice_vibecoder.code_providers.registry import get_agent

    if not _dispatch._registry:
        return "Error: tools not configured."

    agent = agent.lower().strip()
    try:
        agent_info = get_agent(agent)
    except KeyError:
        return f"Unknown agent '{agent}'. Use 'claude' or 'cursor'."

    instance = _resolve_instance(branch)
    if not instance:
        if branch:
            return f"No instance for branch '{branch}'."
        return "No agent instance available."

    if instance.agent_type == agent:
        return f"'{instance.branch}' is already using {agent_info.label}."

    instance.agent_type = agent
    instance.session_id = ""  # Fresh session with the new agent
    _dispatch._registry._save_state()

    if _dispatch._registry.on_output:
        _dispatch._registry.on_output(
            instance.instance_id, f"text:Switched to {agent_info.label}"
        )

    # Refresh the panel header to show the new agent badge
    if _dispatch._registry.on_status_change:
        _dispatch._registry.on_status_change(instance.instance_id, instance.status)

    return f"Switched '{instance.branch}' to {agent_info.label}."


def _handle_create_branch_instance(branch: str) -> str:
    if not branch.strip():
        return "Error: branch name is required."
    if not _dispatch._registry or not _dispatch._repo_root:
        return "Error: tools not configured."

    existing = _dispatch._registry.get_by_branch(branch)
    if existing:
        return f"Instance for branch '{branch}' already exists (status: {existing.status.value})."

    try:
        worktree_path = resolve_worktree_path(branch, _dispatch._repo_root)
    except subprocess.CalledProcessError as e:
        return f"Error creating worktree for '{branch}': {e.stderr or e}"

    instance = _dispatch._registry.create_instance(branch, str(worktree_path))
    return f"Created instance for '{branch}'."


def _handle_get_agent_status(branch: str | None = None, session_name: str | None = None) -> str:
    if not _dispatch._registry:
        return "No agent instances."

    if session_name:
        instance = _resolve_instance(session_name=session_name)
        if not instance:
            return f"No session '{session_name}'."
        return _format_instance_status(instance)

    if branch:
        instance = _resolve_instance(branch=branch)
        if not instance:
            return f"No instance for branch '{branch}'."
        return _format_instance_status(instance)

    instances = _dispatch._registry.get_all()
    if not instances:
        return "No agent instances."
    if len(instances) == 1:
        return _format_instance_status(instances[0])

    parts = []
    for inst in instances:
        parts.append(f"[{inst.display_key}] {_format_instance_status(inst)}")
    return "\n".join(parts)


def _format_instance_status(instance: AgentInstance) -> str:
    key = instance.display_key
    if instance.status == InstanceStatus.WAITING_INPUT:
        q = instance.pending_question
        formatted = q.get("formatted", "") if q else ""
        return f"Waiting for input on '{key}': {formatted}"
    elif instance.status == InstanceStatus.RUNNING:
        snippet = instance.output_buffer[-500:] if instance.output_buffer else ""
        status = f"Working on '{key}'."
        if snippet:
            status += f"\n\n{snippet}"
        return status
    elif instance.output_buffer:
        snippet = instance.output_buffer[:500]
        return f"Done on '{key}':\n{snippet}"
    else:
        return f"Idle on '{key}'."


def _handle_cancel_agent(branch: str | None = None, session_name: str | None = None) -> str:
    if not _dispatch._registry:
        return "No active agent task to cancel."

    if session_name:
        instance = _resolve_instance(session_name=session_name)
        if not instance:
            return f"No session '{session_name}'."
        if cancel_instance_task(instance):
            return "Cancelled."
        return f"No active task on session '{session_name}'."

    if branch:
        instance = _resolve_instance(branch=branch)
        if not instance:
            return f"No instance for branch '{branch}'."
        if cancel_instance_task(instance):
            return "Cancelled."
        return f"No active task on '{branch}'."

    count = cancel_all_tasks()
    if count > 0:
        return "Cancelled."
    return "No active tasks."


def _handle_reset_agent(branch: str | None = None, session_name: str | None = None) -> str:
    if not _dispatch._registry:
        return "No instances to reset."

    if session_name:
        instance = _resolve_instance(session_name=session_name)
        if not instance:
            return f"No session '{session_name}'."
        cancel_instance_task(instance)
        instance.session_id = ""
        instance.first_call = True
        return "Reset."

    if branch:
        instance = _resolve_instance(branch=branch)
        if not instance:
            return f"No instance for branch '{branch}'."
        cancel_instance_task(instance)
        instance.session_id = ""
        instance.first_call = True
        return "Reset."

    for inst in _dispatch._registry.get_all():
        cancel_instance_task(inst)
        inst.session_id = ""
        inst.first_call = True
    return "Reset."


def _handle_list_branches() -> str:
    from voice_vibecoder.worktrees import list_worktrees

    parts = []
    status_icons = {
        "idle": "○", "running": "⏳", "waiting_input": "❓", "error": "✗",
    }

    if _dispatch._registry:
        # Code instances
        code_instances = _dispatch._registry.get_all_code_instances()
        if code_instances:
            parts.append("Active code instances:")
            for inst in code_instances:
                icon = status_icons.get(inst.status.value, "?")
                parts.append(f"  {icon} {inst.branch} ({inst.status.value})")

        # Session instances
        sessions = _dispatch._registry.get_all_sessions()
        if sessions:
            parts.append("\nActive sessions:")
            for inst in sessions:
                icon = status_icons.get(inst.status.value, "?")
                parts.append(f"  {icon} {inst.display_name} ({inst.status.value})")

    # Available worktrees not yet registered
    if _dispatch._repo_root:
        active_branches = set()
        if _dispatch._registry:
            active_branches = {inst.branch for inst in _dispatch._registry.get_all_code_instances()}
        worktrees = list_worktrees(_dispatch._repo_root)
        available = [wt for wt in worktrees if wt.branch and wt.branch not in active_branches]
        if available:
            parts.append("\nAvailable worktrees (use create_branch_instance to activate):")
            for wt in available:
                label = f"  {wt.branch}"
                if wt.is_main:
                    label += " (main)"
                parts.append(label)

    if not parts:
        return "No active instances and no worktrees found."
    return "\n".join(parts)


def _handle_answer_question(answer: str, branch: str | None = None, session_name: str | None = None) -> str:
    if not answer.strip():
        return "Error: empty answer."

    instance = _resolve_instance(branch=branch, session_name=session_name)
    if not instance:
        if session_name:
            return f"No session '{session_name}'."
        if branch:
            return f"No instance for branch '{branch}'."
        return "No agent instance available."

    key = instance.display_key
    future = instance.pending_answer
    bg_loop = instance._bg_loop

    if not future or not bg_loop:
        return f"Agent on '{key}' has no pending question."

    if future.done():
        return f"Agent on '{key}' already received an answer."

    # Show the answer in the panel
    if _dispatch._registry and _dispatch._registry.on_output:
        _dispatch._registry.on_output(instance.instance_id, f"user_prompt:{answer}")

    try:
        bg_loop.call_soon_threadsafe(future.set_result, answer)
    except RuntimeError:
        return f"Agent on '{key}' is no longer running."

    return "Answered."


def _fuzzy_match_file(query: str, paths: list[str]) -> str | None:
    """Fuzzy match a file query against a list of paths."""
    q = query.lower()
    # Exact full path
    exact = [p for p in paths if p == query]
    if exact:
        return exact[0]
    # Exact basename
    by_name = [p for p in paths if p.rsplit("/", 1)[-1].lower() == q]
    if len(by_name) == 1:
        return by_name[0]
    # Substring in full path
    partial = [p for p in paths if q in p.lower()]
    if len(partial) == 1:
        return partial[0]
    if partial:
        return min(partial, key=len)
    return None


def _handle_show_diff(branch: str | None = None, file: str | None = None) -> str:
    from voice_vibecoder.ui.diff_view import get_diff_files, get_diff_content, format_diff_content

    instance = _resolve_instance(branch)

    if not instance and branch and _dispatch._repo_root:
        from voice_vibecoder.worktrees import list_worktrees

        from voice_vibecoder.tools.dispatch import _fuzzy_match_branch

        worktrees = list_worktrees(_dispatch._repo_root)
        wt_branches = [w.branch for w in worktrees if w.branch]
        matched = _fuzzy_match_branch(branch, wt_branches)
        wt = next((w for w in worktrees if w.branch == matched), None) if matched else None
        if wt:
            worktree_path = str(wt.path)
            files = get_diff_files(worktree_path)
            if file:
                matched_file = _fuzzy_match_file(file, [f.path for f in files])
                if matched_file:
                    files = [f for f in files if f.path == matched_file]
                    raw_diff = get_diff_content(worktree_path, file_path=matched_file)
                else:
                    return f"No file matching '{file}' in changes on '{branch}'."
            else:
                raw_diff = get_diff_content(worktree_path)
            if not files:
                return f"No changes on '{branch}' vs main."
            file_list = ", ".join(f.path for f in files[:10])
            summary = f"'{branch}' has {len(files)} changed file(s): {file_list}\n\n{raw_diff}"
            return summary

    if not instance:
        if branch:
            return f"No instance for branch '{branch}'."
        return "No instance available."

    files = get_diff_files(instance.worktree_path)

    matched_file = None
    if file:
        matched_file = _fuzzy_match_file(file, [f.path for f in files])
        if matched_file:
            raw_diff = get_diff_content(instance.worktree_path, file_path=matched_file)
        else:
            return f"No file matching '{file}' in changes on '{instance.branch}'."
    else:
        raw_diff = get_diff_content(instance.worktree_path)

    diff_lines = format_diff_content(raw_diff)

    if _dispatch._registry and _dispatch._registry.on_ui_command:
        _dispatch._registry.on_ui_command(instance.instance_id, "show_diff", {
            "files": files,
            "diff_lines": diff_lines,          # Rich-formatted (for TUI)
            "raw_diff": raw_diff,              # Raw diff text (for web)
        })

    file_count = len(files)
    if file_count == 0:
        return f"No changes on '{instance.branch}' vs main."
    if matched_file:
        return f"Showing diff for '{matched_file}' on '{instance.branch}'."
    return f"Showing diff for '{instance.branch}': {file_count} file{'s' if file_count != 1 else ''} changed."


def _handle_show_output(branch: str | None = None, session_name: str | None = None) -> str:
    # Also exit fullscreen if active — "go back" / "show output" should restore normal view
    if _dispatch._registry and _dispatch._registry.fullscreen_id:
        fs_id = _dispatch._registry.fullscreen_id
        if _dispatch._registry.on_ui_command:
            _dispatch._registry.on_ui_command(fs_id, "fullscreen", {})

    instance = _resolve_instance(branch=branch, session_name=session_name)
    if not instance:
        if session_name:
            return f"No session '{session_name}'."
        if branch:
            return f"No instance for branch '{branch}'."
        return "No instance available."

    if _dispatch._registry and _dispatch._registry.on_ui_command:
        _dispatch._registry.on_ui_command(instance.instance_id, "show_output", {})

    return "Switched to output view."


def _handle_toggle_fullscreen(branch: str | None = None, session_name: str | None = None) -> str:
    # When no branch/session specified, un-fullscreen whichever panel is currently fullscreened
    if not branch and not session_name and _dispatch._registry:
        fs_id = _dispatch._registry.fullscreen_id
        if fs_id and _dispatch._registry.on_ui_command:
            _dispatch._registry.on_ui_command(fs_id, "fullscreen", {})
            return "Toggled."

    instance = _resolve_instance(branch=branch, session_name=session_name)
    if not instance:
        if session_name:
            return f"No session '{session_name}'."
        if branch:
            return f"No instance for branch '{branch}'."
        return "No instance available."

    if _dispatch._registry and _dispatch._registry.on_ui_command:
        _dispatch._registry.on_ui_command(instance.instance_id, "fullscreen", {})

    return "Toggled."


def _handle_remove_branch_instance(branch: str) -> str:
    if not branch.strip():
        return "Error: branch name is required."
    if not _dispatch._registry:
        return "No instances."

    instance = _resolve_instance(branch=branch)
    if not instance:
        return f"No instance for branch '{branch}'."

    cancel_instance_task(instance)

    if _dispatch._registry.on_ui_command:
        _dispatch._registry.on_ui_command(instance.instance_id, "remove", {})

    _dispatch._registry.remove_instance(instance.instance_id)
    return f"Removed '{branch}'."


def _handle_remove_session(session_name: str) -> str:
    """Remove a session instance and its panel."""
    if not session_name.strip():
        return "Error: session_name is required."
    if not _dispatch._registry:
        return "No instances."

    instance = _resolve_instance(session_name=session_name)
    if not instance:
        return f"No session '{session_name}'."

    cancel_instance_task(instance)

    if _dispatch._registry.on_ui_command:
        _dispatch._registry.on_ui_command(instance.instance_id, "remove", {})

    _dispatch._registry.remove_instance(instance.instance_id)
    return f"Removed session '{instance.display_name}'."


def _handle_delete_worktree(branch: str, delete_branch: bool = False) -> str:
    if not branch.strip():
        return "Error: branch name is required."
    if not _dispatch._repo_root:
        return "Error: repo root not configured."

    # Fuzzy match against worktree branches
    from voice_vibecoder.tools.dispatch import _fuzzy_match_branch
    from voice_vibecoder.worktrees import list_worktrees

    worktrees = list_worktrees(_dispatch._repo_root)
    wt_branches = [w.branch for w in worktrees if w.branch and not w.is_main]
    resolved = _fuzzy_match_branch(branch, wt_branches) or branch

    # Remove active instance first if one exists
    if _dispatch._registry:
        instance = _dispatch._registry.get_by_branch(resolved)
        if instance:
            cancel_instance_task(instance)
            if _dispatch._registry.on_ui_command:
                _dispatch._registry.on_ui_command(instance.instance_id, "remove", {})
            _dispatch._registry.remove_instance(instance.instance_id)

    try:
        remove_worktree(resolved, _dispatch._repo_root, delete_branch=delete_branch)
    except ValueError as e:
        return f"Error: {e}"
    except subprocess.CalledProcessError as e:
        return f"Error removing worktree: {e.stderr or e}"

    msg = f"Deleted worktree for '{resolved}'."
    if delete_branch:
        msg += " Branch also deleted."
    return msg
