import os
from pathlib import Path
from typing import Literal, Optional

from pydantic import AliasChoices, Field, computed_field
from pydantic_settings import BaseSettings, SettingsConfigDict

# ── Core Services ─────────────────────────────────────────────────────────────


class ServiceConfig(BaseSettings):
    """Base class for service configurations with internal/external URL handling."""

    service_name: str
    service_port: int
    external_host: str = Field(default="localhost", description="Hostname for external access")
    external_port: int
    external_protocol: str = Field(
        default="http", description="Protocol for external access (http/https)"
    )
    public_url: Optional[str] = Field(
        default=None,
        description="Override URL for external access (e.g. reverse-proxy or CDN endpoint)",
    )
    external_service: bool = Field(
        default=False, description="True when the service is outside the Docker Compose network"
    )

    @property
    def internal_url(self) -> str:
        """URL for internal service-to-service communication."""
        return f"http://{self.service_name}:{self.service_port}"

    @property
    def external_url(self) -> str:
        """URL for external access."""
        if self.public_url:
            return self.public_url
        return f"{self.external_protocol}://{self.external_host}:{self.external_port}"

    @property
    def url(self) -> str:
        context = os.getenv("DEPICTIO_CONTEXT", "server")

        if context == "server":
            # Use public_url only for truly external services
            if self.public_url and self.external_service:
                return self.public_url

            return self.internal_url

        return self.external_url

    @property
    def port(self) -> int:
        return self.external_port


class FastAPIConfig(ServiceConfig):
    """FastAPI backend server configuration."""

    service_name: str = Field(default="depictio-backend")
    service_port: int = Field(default=8058)
    external_port: int = Field(default=8058)
    host: str = Field(default="0.0.0.0", description="Bind address for the FastAPI server")
    workers: int = Field(default=4, description="Number of Gunicorn worker processes")
    ssl: bool = Field(default=False, description="Enable SSL/TLS")
    logging_level: str = Field(
        default="INFO", description="Logging level (DEBUG, INFO, WARNING, ERROR)"
    )

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_FASTAPI_")


class DashConfig(ServiceConfig):
    """Dash frontend server configuration."""

    service_name: str = Field(default="depictio-frontend")
    service_port: int = Field(default=5080)
    external_port: int = Field(default=5080)
    host: str = Field(default="0.0.0.0", description="Bind address for the Dash server")
    workers: int = Field(default=4, description="Number of Gunicorn worker processes")
    debug: bool = Field(default=True, description="Enable Dash debug mode with hot reload")
    auto_generate_figures: bool = Field(
        default=False, description="Enable automatic figure generation in UI mode"
    )

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_DASH_")


class MongoDBConfig(ServiceConfig):
    """MongoDB database connection configuration."""

    service_name: str = Field(default="mongo")
    service_port: int = Field(default=27018)
    external_port: int = Field(default=27018)
    db_name: str = Field(default="depictioDB", description="MongoDB database name")
    wipe: bool = Field(
        default=False, description="Wipe the database on startup (destructive — development only)"
    )

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_MONGODB_")

    class Collections(BaseSettings):
        data_collection: str = Field(default="data_collections")
        workflow_collection: str = Field(default="workflows")
        runs_collection: str = Field(default="runs")
        files_collection: str = Field(default="files")
        users_collection: str = Field(default="users")
        tokens_collection: str = Field(default="tokens")
        groups_collection: str = Field(default="groups")
        deltatables_collection: str = Field(default="deltatables")
        jbrowse_collection: str = Field(default="jbrowse")
        dashboards_collection: str = Field(default="dashboards")
        initialization_collection: str = Field(default="initialization")
        projects_collection: str = Field(default="projects")
        multiqc_collection: str = Field(default="multiqc")
        test_collection: str = Field(default="test")

    collections: Collections = Field(default_factory=Collections)


class S3DepictioCLIConfig(ServiceConfig):
    """S3/MinIO object storage configuration."""

    service_name: str = Field(default="minio")
    service_port: int = Field(default=9000)
    external_port: int = Field(default=9000)
    root_user: str = Field(default="minio", description="MinIO/S3 root access key")
    root_password: str = Field(default="minio123", description="MinIO/S3 root secret key")
    bucket: str = Field(
        default="depictio-bucket", description="Default S3 bucket name for Depictio data"
    )

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_MINIO_")

    @property
    def endpoint_url(self) -> str:
        """Returns URL for Polars and other S3 clients."""
        return self.url

    @property
    def host(self) -> str:
        return self.external_host

    # Aliases for S3 compatibility
    @property
    def aws_access_key_id(self) -> str:
        return self.root_user

    @property
    def aws_secret_access_key(self) -> str:
        return self.root_password


class AuthConfig(BaseSettings):
    """Authentication and authorisation configuration."""

    keys_dir: Path = Field(
        default_factory=lambda: Path(__file__).parent.parent.parent.parent / "keys",
        description="Directory for JWT public/private key files",
    )
    keys_algorithm: Literal["RS256", "RS512", "ES256", "SHA256"] = Field(
        default="RS256", description="JWT signing algorithm"
    )
    cli_config_dir: Path = Field(
        default_factory=lambda: Path(__file__).parent.parent.parent.parent / ".depictio",
        description="Directory for CLI configuration files (admin token, etc.)",
    )
    internal_api_key_env: Optional[str] = Field(
        default=None,
        description="Internal API key for service-to-service communication (auto-generated if unset)",
    )
    unauthenticated_mode: bool = Field(default=False, description="Enable unauthenticated mode")
    single_user_mode: bool = Field(
        default=False,
        description="Enable single-user mode for personal/self-hosted instances. "
        "Grants admin privileges to the anonymous user for full functionality without authentication.",
    )
    public_mode: bool = Field(
        default=False,
        description="Enable public mode for public Depictio instances with sign-in modal",
        validation_alias=AliasChoices("public_mode", "unauthenticated_mode"),
    )
    demo_mode: bool = Field(
        default=False,
        description="Enable demo mode with guided tour tooltips for first-time users. "
        "Extends public mode with interactive onboarding hints.",
    )
    anonymous_user_email: str = Field(
        default="anonymous@depict.io",
        description="Default anonymous user email",
    )
    temporary_user_expiry_hours: int = Field(
        default=24,
        description="Number of hours until temporary users expire",
    )
    temporary_user_expiry_minutes: int = Field(
        default=0,
        description="Number of minutes until temporary users expire",
    )

    # Google OAuth
    google_oauth_enabled: bool = Field(
        default=False, description="Enable Google OAuth authentication"
    )
    google_oauth_client_id: Optional[str] = Field(
        default=None, description="Google OAuth client ID"
    )
    google_oauth_client_secret: Optional[str] = Field(
        default=None, description="Google OAuth client secret"
    )
    google_oauth_redirect_uri: Optional[str] = Field(
        default=None, description="Google OAuth redirect URI"
    )

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_AUTH_", case_sensitive=False)

    def __init__(self, **data: object) -> None:
        super().__init__(**data)

        import os

        # Manually read environment variables if not set
        # This is needed because Pydantic v2 nested BaseSettings don't automatically
        # read environment variables when instantiated via default_factory
        if self.internal_api_key_env is None:
            self.internal_api_key_env = os.getenv("DEPICTIO_AUTH_INTERNAL_API_KEY")

        # Read auth mode environment variables
        env_public_mode = os.getenv("DEPICTIO_AUTH_PUBLIC_MODE", "").lower()
        if env_public_mode in ("true", "1", "yes"):
            object.__setattr__(self, "public_mode", True)

        env_single_user_mode = os.getenv("DEPICTIO_AUTH_SINGLE_USER_MODE", "").lower()
        if env_single_user_mode in ("true", "1", "yes"):
            object.__setattr__(self, "single_user_mode", True)

        env_unauthenticated_mode = os.getenv("DEPICTIO_AUTH_UNAUTHENTICATED_MODE", "").lower()
        if env_unauthenticated_mode in ("true", "1", "yes"):
            object.__setattr__(self, "unauthenticated_mode", True)

        env_demo_mode = os.getenv("DEPICTIO_AUTH_DEMO_MODE", "").lower()
        if env_demo_mode in ("true", "1", "yes"):
            object.__setattr__(self, "demo_mode", True)

    @computed_field
    @property
    def is_single_user_mode(self) -> bool:
        """Returns True if single-user mode is enabled.

        Single-user mode provides full admin functionality for personal instances.
        """
        return self.single_user_mode

    @computed_field
    @property
    def is_public_mode(self) -> bool:
        """Returns True if public mode is enabled.

        Public mode allows anonymous access with optional sign-in for interactive features.
        """
        return self.public_mode or self.unauthenticated_mode

    @computed_field
    @property
    def is_demo_mode(self) -> bool:
        """Returns True if demo mode is enabled.

        Demo mode extends public mode with guided tour tooltips for first-time users.
        """
        return self.demo_mode

    @computed_field
    @property
    def requires_anonymous_user(self) -> bool:
        """Returns True if any mode requiring anonymous user is enabled."""
        return self.is_single_user_mode or self.is_public_mode

    @computed_field
    @property
    def internal_api_key(self) -> str:
        """
        Get the internal API key using the existing key_utils_base functions.
        This maintains consistency and avoids code duplication.
        """
        if self.internal_api_key_env:
            return self.internal_api_key_env

        from depictio.api.v1.key_utils_base import _load_or_generate_api_internal_key

        return _load_or_generate_api_internal_key(
            keys_dir=self.keys_dir,
            algorithm=self.keys_algorithm,
        )


# ── Infrastructure ────────────────────────────────────────────────────────────


class LoggingConfig(BaseSettings):
    """Application logging configuration."""

    verbosity_level: str = Field(
        default="ERROR", description="Log verbosity level (DEBUG, INFO, WARNING, ERROR, CRITICAL)"
    )

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_LOGGING_")


class CacheConfig(BaseSettings):
    """Redis cache configuration settings."""

    # Redis connection settings
    redis_host: str = Field(default="redis", description="Redis server hostname")
    redis_port: int = Field(default=6379, description="Redis server port")
    redis_password: str | None = Field(default=None, description="Redis password")
    redis_db: int = Field(default=0, description="Redis database number")
    redis_ssl: bool = Field(default=False, description="Use SSL for Redis connection")

    # Cache behavior settings
    enable_redis_cache: bool = Field(
        default=True, description="Enable Redis caching for DataFrames"
    )
    fallback_to_memory: bool = Field(
        default=True, description="Fallback to in-memory cache if Redis fails"
    )

    # Cache expiration settings
    default_ttl: int = Field(default=3600, description="Default cache TTL in seconds (1 hour)")
    dataframe_ttl: int = Field(
        default=1800, description="DataFrame cache TTL in seconds (30 minutes)"
    )

    # Cache limits
    max_dataframe_size_mb: int = Field(
        default=100, description="Maximum DataFrame size to cache (MB)"
    )
    redis_max_memory_mb: int = Field(default=1024, description="Redis max memory limit (MB)")

    # Cache key settings
    cache_key_prefix: str = Field(default="depictio:df:", description="Prefix for cache keys")
    cache_version: str = Field(default="v1", description="Cache version for key namespacing")

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_CACHE_")


class CeleryConfig(BaseSettings):
    """Celery task queue configuration for background processing."""

    # Redis broker settings (uses same Redis as cache but different DB)
    broker_host: str = Field(default="redis", description="Redis broker hostname")
    broker_port: int = Field(default=6379, description="Redis broker port")
    broker_password: Optional[str] = Field(default=None, description="Redis broker password")
    broker_db: int = Field(default=1, description="Redis database for Celery broker")

    # Result backend settings
    result_backend_host: str = Field(default="redis", description="Redis result backend hostname")
    result_backend_port: int = Field(default=6379, description="Redis result backend port")
    result_backend_password: Optional[str] = Field(
        default=None, description="Redis result backend password"
    )
    result_backend_db: int = Field(default=2, description="Redis database for Celery results")

    # Worker settings
    worker_concurrency: int = Field(default=2, description="Number of concurrent worker processes")
    worker_pool: str = Field(default="threads", description="Worker pool type (threads, processes)")
    worker_prefetch_multiplier: int = Field(default=1, description="Worker prefetch multiplier")
    worker_max_tasks_per_child: int = Field(
        default=50, description="Max tasks per worker before restart"
    )

    # Task settings
    task_soft_time_limit: int = Field(
        default=300, description="Task soft time limit in seconds (5min)"
    )
    task_time_limit: int = Field(default=600, description="Task hard time limit in seconds (10min)")
    result_expires: int = Field(default=3600, description="Task result expiration in seconds (1hr)")

    # Queue settings
    default_queue: str = Field(default="dashboard_tasks", description="Default task queue name")

    # Monitoring settings
    worker_send_task_events: bool = Field(default=True, description="Enable task event monitoring")
    task_send_sent_event: bool = Field(default=True, description="Send task sent events")

    @computed_field
    @property
    def _redis_password(self) -> str:
        """Get Redis password from environment, fallback to cache password or default."""
        if self.broker_password:
            return self.broker_password
        import os

        redis_password = os.getenv("REDIS_PASSWORD", "")
        return redis_password

    @computed_field
    @property
    def broker_url(self) -> str:
        """Construct Redis broker URL."""
        password = self._redis_password
        if password and password != "":
            return f"redis://:{password}@{self.broker_host}:{self.broker_port}/{self.broker_db}"
        return f"redis://{self.broker_host}:{self.broker_port}/{self.broker_db}"

    @computed_field
    @property
    def result_backend_url(self) -> str:
        """Construct Redis result backend URL."""
        result_password = self.result_backend_password or self._redis_password
        if result_password and result_password != "":
            return f"redis://:{result_password}@{self.result_backend_host}:{self.result_backend_port}/{self.result_backend_db}"
        return f"redis://{self.result_backend_host}:{self.result_backend_port}/{self.result_backend_db}"

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_CELERY_")


class S3CacheConfig(BaseSettings):
    """S3 file caching configuration for MultiQC and other S3 operations.

    The cache directory stores downloaded S3 files locally to avoid repeated downloads.
    Default location is ~/.depictio/s3_cache (persistent across restarts).

    Environment variable: DEPICTIO_S3_CACHE_DIR
    Example: export DEPICTIO_S3_CACHE_DIR=/data/depictio_s3_cache

    Note: The previous default /tmp/depictio_s3_cache was ephemeral and caused
    repeated downloads after system restarts.
    """

    cache_dir: str = Field(
        default="~/.depictio/s3_cache",
        description="Local directory for S3 file cache. Use DEPICTIO_S3_CACHE_DIR to override.",
    )
    mount_points: str = Field(default="", description="Comma-separated S3 FUSE mount points")

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_S3_")


# ── Optional Features ─────────────────────────────────────────────────────────


class JBrowseConfig(BaseSettings):
    """JBrowse genomics viewer integration configuration."""

    enabled: bool = Field(default=False, description="Enable JBrowse genomics viewer integration")

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_JBROWSE_")


class BackupConfig(BaseSettings):
    """Backup and restore configuration settings."""

    base_dir: Path = Field(default_factory=lambda: Path(__file__).parent.parent.parent.parent)
    backup_dir: str = Field(default="backups")
    s3_backup_strategy: str = Field(
        default="s3_to_s3",
        description="Strategy for S3 data backup: 's3_to_s3', 'local', or 'both'",
    )
    s3_local_backup_dir: str = Field(default="backups/s3_data_backups")
    backup_s3_enabled: bool = Field(default=False, description="Enable separate backup S3 bucket")
    backup_s3_bucket: str = Field(default="depictio-backups", description="Backup S3 bucket name")
    backup_s3_endpoint_url: Optional[str] = Field(
        default=None, description="Backup S3 endpoint URL"
    )
    backup_s3_access_key: Optional[str] = Field(default=None, description="Backup S3 access key")
    backup_s3_secret_key: Optional[str] = Field(default=None, description="Backup S3 secret key")
    backup_s3_region: str = Field(default="us-east-1", description="Backup S3 region")
    compress_local_backups: bool = Field(default=True, description="Compress local S3 data backups")
    backup_file_retention_days: int = Field(default=30, description="Days to retain backup files")

    @computed_field
    @property
    def backup_path(self) -> str:
        """Get absolute backup directory path for MongoDB backups."""
        return str(self.base_dir / self.backup_dir)

    @computed_field
    @property
    def s3_local_backup_path(self) -> str:
        """Get absolute local backup directory path for S3 data."""
        return str(self.base_dir / self.s3_local_backup_dir)

    @computed_field
    @property
    def backup_s3_config(self) -> Optional[dict]:
        """Get backup S3 configuration if enabled."""
        if not self.backup_s3_enabled:
            return None

        config = {
            "region_name": self.backup_s3_region,
            "verify": False,  # Disable SSL verification for play.minio.io
        }

        if self.backup_s3_endpoint_url:
            config["endpoint_url"] = self.backup_s3_endpoint_url
        if self.backup_s3_access_key:
            config["aws_access_key_id"] = self.backup_s3_access_key
        if self.backup_s3_secret_key:
            config["aws_secret_access_key"] = self.backup_s3_secret_key

        return config

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_BACKUP_")


class EventsConfig(BaseSettings):
    """Configuration for real-time event system (WebSocket notifications).

    Enables automatic dashboard updates when backend data changes.
    Supports MongoDB change streams for data_collection updates.
    """

    enabled: bool = Field(default=False, description="Enable real-time event system")
    redis_host: str = Field(default="redis", description="Redis server hostname for pub/sub")
    redis_port: int = Field(default=6379, description="Redis server port")
    redis_password: Optional[str] = Field(default=None, description="Redis password")
    redis_db: int = Field(
        default=3, description="Redis database number (separate from cache=0, celery=1,2)"
    )
    mongodb_change_streams_enabled: bool = Field(
        default=True, description="Enable MongoDB change streams for data_collections"
    )
    ws_heartbeat_interval: int = Field(
        default=30, description="WebSocket heartbeat/ping interval in seconds"
    )
    ws_connection_timeout: int = Field(
        default=60, description="WebSocket connection timeout in seconds"
    )
    debounce_ms: int = Field(
        default=1000, description="Debounce interval in milliseconds for rapid updates"
    )

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_EVENTS_")

    @computed_field
    @property
    def redis_url(self) -> str:
        """Construct Redis URL for pub/sub."""
        if self.redis_password:
            return f"redis://:{self.redis_password}@{self.redis_host}:{self.redis_port}/{self.redis_db}"
        return f"redis://{self.redis_host}:{self.redis_port}/{self.redis_db}"


class DashboardYAMLConfig(BaseSettings):
    """Configuration for YAML-based dashboard management.

    Enables file-based dashboard editing where users can read/write YAML files
    directly from a designated directory for version control and IaC workflows.
    """

    # DEPRECATED: YAML system is being phased out in favor of JSON-based API (see YAML_MONGODB_ANALYSIS.md)
    enabled: bool = Field(
        default=False, description="Enable YAML-based dashboard management (DEPRECATED)"
    )
    local_dir: Path = Field(
        default_factory=lambda: (
            Path(__file__).parent.parent.parent.parent.parent / "dashboards" / "local"
        ),
        description="Directory for instance-specific dashboard YAML files (auto-synced)",
    )
    templates_dir: Path = Field(
        default_factory=lambda: (
            Path(__file__).parent.parent.parent.parent.parent / "dashboards" / "templates"
        ),
        description="Directory for template dashboard YAML files (version control)",
    )
    base_dir: Path | None = Field(
        default=None,
        description="DEPRECATED: Use local_dir instead. Base directory for dashboard YAML files",
    )
    organize_by_project: bool = Field(
        default=True,
        description="Organize YAML files in subdirectories by project name",
    )
    use_dashboard_title: bool = Field(
        default=True,
        description="Use dashboard title in filename (vs just ID)",
    )
    include_export_metadata: bool = Field(
        default=True,
        description="Include export timestamp and version in YAML files",
    )
    compact_mode: bool = Field(
        default=True,
        description="Use compact YAML format with references (75-80% smaller files)",
    )
    mvp_mode: bool = Field(
        default=True,
        description="Use MVP minimal YAML format (60-80 lines, human-readable IDs, no layout)",
    )
    regenerate_stats: bool = Field(
        default=True,
        description="Regenerate column statistics on import instead of storing in YAML",
    )
    auto_layout: bool = Field(
        default=False,
        description="Auto-generate component layout on import if missing",
    )
    auto_export_on_save: bool = Field(
        default=False,
        description="Automatically export to YAML when dashboard is saved (DEPRECATED)",
    )
    auto_import_on_change: bool = Field(
        default=False,
        description="Automatically import from YAML when files change (requires watcher) (DEPRECATED)",
    )
    watcher_debounce_seconds: float = Field(
        default=2.0,
        description="Seconds to wait after file change before syncing",
    )
    watch_local_dir: bool = Field(
        default=False,
        description="Watch and auto-sync local dashboards directory (DEPRECATED)",
    )
    watch_templates_dir: bool = Field(
        default=False,
        description="Watch and auto-sync templates directory (useful for template development)",
    )
    enable_validation: bool = Field(
        default=True,
        description="Enable validation gate before syncing YAML to MongoDB",
    )
    block_on_validation_errors: bool = Field(
        default=True,
        description="Block sync if validation fails (set False to only warn)",
    )
    validate_column_names: bool = Field(
        default=True,
        description="Validate that column names exist in data collection schema",
    )
    validate_component_types: bool = Field(
        default=True,
        description="Validate chart types, aggregation functions, and filter types",
    )

    model_config = SettingsConfigDict(
        env_prefix="DEPICTIO_DASHBOARD_YAML_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @computed_field
    @property
    def yaml_dir_path(self) -> str:
        """Get absolute YAML directory path (defaults to local_dir)."""
        if self.base_dir is not None:
            return str(self.base_dir.resolve())
        return str(self.local_dir.resolve())

    @computed_field
    @property
    def templates_path(self) -> str:
        """Get absolute templates directory path."""
        return str(self.templates_dir.resolve())


# ── Observability & Development ───────────────────────────────────────────────


class PerformanceConfig(BaseSettings):
    """Performance and timeout settings that can be tuned per environment."""

    # HTTP client timeouts (in seconds)
    http_client_timeout: int = Field(default=30)
    api_request_timeout: int = Field(default=60)

    # Playwright/browser timeouts (in milliseconds)
    browser_navigation_timeout: int = Field(default=60000)  # 60s default
    browser_page_load_timeout: int = Field(default=90000)  # 90s default
    browser_element_timeout: int = Field(default=30000)  # 30s default

    # Screenshot-specific timeouts (production typically needs longer)
    screenshot_navigation_timeout: int = Field(default=45000)  # 45s for navigation
    screenshot_content_wait: int = Field(default=15000)  # 15s for content
    screenshot_stabilization_wait: int = Field(default=5000)  # 5s for stability
    screenshot_capture_timeout: int = Field(default=90000)  # 90s for actual screenshot capture
    screenshot_api_timeout: int = Field(default=300)  # 5 minutes for complete screenshot API call

    # Service readiness check settings
    service_readiness_retries: int = Field(default=5)
    service_readiness_delay: int = Field(default=3)
    service_readiness_timeout: int = Field(default=10)

    # DNS and network performance settings
    dns_cache_ttl: int = Field(default=300)  # 5 minutes
    connection_pool_size: int = Field(
        default=25, description="HTTP connection pool size for multi-worker environments"
    )
    max_keepalive_connections: int = Field(
        default=20, description="Max persistent HTTP connections (increased for 4 workers)"
    )

    # Loading spinner optimization settings
    disable_loading_spinners: bool = Field(
        default=True, description="Disable all loading spinners for maximum performance"
    )

    # Animation optimization settings
    disable_animations: bool = Field(
        default=True, description="Disable SVG and CSS animations for maximum performance"
    )
    disable_theme_animations: bool = Field(
        default=True, description="Disable theme CSS injection and complex theme operations"
    )

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_PERFORMANCE_")


class AnalyticsConfig(BaseSettings):
    """Configuration for analytics tracking."""

    enabled: bool = Field(default=False, description="Enable analytics tracking")
    session_timeout_minutes: int = Field(
        default=30,
        description="Session timeout in minutes",
        ge=5,
        le=1440,
    )
    cleanup_days: int = Field(
        default=90,
        description="Days to retain analytics data",
        ge=1,
        le=365,
    )
    track_anonymous_users: bool = Field(
        default=True,
        description="Track anonymous user sessions",
    )
    cleanup_enabled: bool = Field(
        default=True,
        description="Enable automatic cleanup of old analytics data",
    )

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_ANALYTICS_")


class GoogleAnalyticsConfig(BaseSettings):
    """Configuration for Google Analytics tracking."""

    enabled: bool = Field(default=False, description="Enable Google Analytics tracking")
    tracking_id: Optional[str] = Field(
        default=None,
        description="Google Analytics tracking ID (GA4 measurement ID)",
    )

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_GOOGLE_ANALYTICS_")

    @property
    def is_configured(self) -> bool:
        """Check if Google Analytics is properly configured."""
        return self.enabled and self.tracking_id is not None


class ProfilingConfig(BaseSettings):
    """Configuration for application profiling."""

    enabled: bool = Field(default=False, description="Enable application profiling")
    profile_dir: str = Field(default="./prof_files", description="Directory to save profile files")
    sort_by: str = Field(default="cumtime,tottime", description="Profile sorting criteria")
    restrictions: int = Field(default=50, description="Number of top functions to show in reports")
    memory_profiling: bool = Field(default=False, description="Enable memory usage profiling")

    # Werkzeug-specific options
    werkzeug_enabled: bool = Field(default=True, description="Enable Werkzeug request profiling")
    werkzeug_stream: bool = Field(default=False, description="Stream profiling output to terminal")
    werkzeug_safe_mode: bool = Field(
        default=True, description="Enable safe mode to prevent profiler conflicts"
    )

    # Callback profiling options
    profile_callbacks: bool = Field(
        default=False, description="Enable automatic callback profiling"
    )
    profile_slow_callbacks_only: bool = Field(
        default=True, description="Only profile callbacks slower than threshold"
    )
    slow_callback_threshold: float = Field(
        default=0.1, description="Threshold in seconds for slow callbacks"
    )

    model_config = SettingsConfigDict(env_prefix="DEPICTIO_PROFILING_")

    @computed_field
    @property
    def sort_criteria(self) -> tuple[str, ...]:
        """Parse sort criteria string into tuple."""
        return tuple(s.strip() for s in self.sort_by.split(","))

    @computed_field
    @property
    def profile_path(self) -> Path:
        """Get resolved profile directory path."""
        return Path(self.profile_dir).resolve()


# ── Root ──────────────────────────────────────────────────────────────────────


class Settings(BaseSettings):
    """Root application settings, composed of all subsystem configurations."""

    context: str = Field(
        default="server", description="Runtime context: 'server' (API/worker) or 'client' (CLI)"
    )

    # Core services
    fastapi: FastAPIConfig = Field(default_factory=FastAPIConfig)
    dash: DashConfig = Field(default_factory=DashConfig)
    mongodb: MongoDBConfig = Field(default_factory=MongoDBConfig)
    minio: S3DepictioCLIConfig = Field(default_factory=S3DepictioCLIConfig)
    auth: AuthConfig = Field(default_factory=AuthConfig)

    # Infrastructure
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    cache: CacheConfig = Field(default_factory=CacheConfig)
    celery: CeleryConfig = Field(default_factory=CeleryConfig)
    s3_cache: S3CacheConfig = Field(default_factory=S3CacheConfig)

    # Optional features
    jbrowse: JBrowseConfig = Field(default_factory=JBrowseConfig)
    backup: BackupConfig = Field(default_factory=BackupConfig)
    events: EventsConfig = Field(default_factory=EventsConfig)
    dashboard_yaml: DashboardYAMLConfig = Field(default_factory=DashboardYAMLConfig)

    # Observability & development
    performance: PerformanceConfig = Field(default_factory=PerformanceConfig)
    analytics: AnalyticsConfig = Field(default_factory=AnalyticsConfig)
    google_analytics: GoogleAnalyticsConfig = Field(default_factory=GoogleAnalyticsConfig)
    profiling: ProfilingConfig = Field(default_factory=ProfilingConfig)

    model_config = SettingsConfigDict(
        env_prefix="DEPICTIO_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",  # Ignore extra fields in .env that aren't in the model
    )
