\# plugin-exemplo

&nbsp; 

Plugin do mtcli que adiciona o comando plugin de exemplo.

&nbsp; 

---

&nbsp; 

\## Instalação

&nbsp; 

```cmd

git clone git@github.com:vfranca/plugin-exemplo.git

cd plugin-exemplo

pip install .

```



