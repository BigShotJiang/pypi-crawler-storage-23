"""
Interface CLI do plugin mtcli-range.

Comando:
    mt range
"""

import click
from mtcli.logger import setup_logger
from .range_controller import RangeController
from .conf import (
    get_default_symbol,
    get_default_range,
    get_default_timeframe,
    get_default_bars,
)

log = setup_logger("mtcli.range.cli")


@click.command("range")
@click.version_option(package_name="mtcli-range")
@click.option("-s", "--symbol", default=get_default_symbol(), show_default=True, help="Ativo.")
@click.option("-t", "--timeframe", default=get_default_timeframe(), show_default=True, help="Timeframe base.")
@click.option("-b", "--bars", default=get_default_bars(), show_default=True, help="Quantidade de candles base.")
@click.option("-r", "--range-size", default=get_default_range(), show_default=True, help="Tamanho do range.")
@click.option("--ancorar-abertura", is_flag=True, help="Inicia o Range a partir da abertura do primeiro candle.")
@click.option("--numerar", is_flag=True, help="Numera as linhas exibidas.")
def range_command(symbol, timeframe, bars, range_size, ancorar_abertura, numerar):
    """
    Exibe gráfico de Range no terminal.

    Exemplos:

        mt range -s WING26 -t m5 -b 1000 -r 60
        mt range --ancorar-abertura
        mt range --numerar
    """

    try:
        controller = RangeController(
            symbol=symbol,
            timeframe=timeframe,
            bars=bars,
            range_size=range_size,
            ancorar_abertura=ancorar_abertura,
            numerar=numerar,
        )

        controller.executar()

    except Exception as e:
        log.error(f"Erro ao executar mt range: {e}")
        click.echo(f"Erro: {e}")
