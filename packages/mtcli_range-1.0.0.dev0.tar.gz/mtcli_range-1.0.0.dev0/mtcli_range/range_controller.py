"""
Controller do plugin mtcli-range.

Orquestra:
- Conexão MT5
- Model
- View
"""

from mtcli.mt5_context import mt5_conexao
from mtcli.logger import setup_logger
from mtcli.domain.timeframe import Timeframe
from .range_model import RangeModel
from .range_view import RangeView

log = setup_logger("mtcli.range.controller")


class RangeController:
    """
    Controlador principal do fluxo.
    """

    def __init__(
        self,
        symbol: str,
        timeframe: str,
        bars: int,
        range_size: float,
        ancorar_abertura: bool,
        numerar: bool,
    ):
        self.symbol = symbol
        self.timeframe = Timeframe.from_string(timeframe)
        self.bars = bars
        self.range_size = range_size
        self.ancorar_abertura = ancorar_abertura
        self.numerar = numerar

    def executar(self):
        """
        Executa o fluxo completo do gráfico Range.
        """

        with mt5_conexao():
            model = RangeModel(
                self.symbol,
                self.timeframe.mt5_const,
                self.bars,
                self.range_size,
                ancorar_abertura=self.ancorar_abertura,
            )

            blocos = model.gerar_range()

        RangeView.exibir_header(
            self.symbol,
            self.range_size,
            self.ancorar_abertura,
        )

        RangeView.exibir_blocos(
            blocos,
            numerar=self.numerar,
        )
