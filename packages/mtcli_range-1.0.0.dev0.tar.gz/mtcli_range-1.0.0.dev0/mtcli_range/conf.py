"""
Configuração do plugin mtcli-range.

Lê parâmetros do arquivo mtcli.ini na seção [range].
Permite definir valores padrão para:
- símbolo
- tamanho do range
- timeframe base
- quantidade de candles
"""

import configparser
import os


CONFIG_PATH = os.path.join(os.getcwd(), "mtcli.ini")

config = configparser.ConfigParser()
config.read(CONFIG_PATH)

SECTION = "range"


def get_default_symbol() -> str:
    """Retorna símbolo padrão do arquivo .ini."""
    return config.get(SECTION, "symbol", fallback="WIN$")


def get_default_range() -> float:
    """Retorna tamanho do range padrão."""
    return config.getfloat(SECTION, "range_size", fallback=50.0)


def get_default_timeframe() -> str:
    """Retorna timeframe base padrão."""
    return config.get(SECTION, "timeframe", fallback="m5")


def get_default_bars() -> int:
    """Retorna quantidade padrão de candles base."""
    return config.getint(SECTION, "bars", fallback=500)
