"""
Model responsável pela geração dos blocos Range.

O Range é baseado em movimentação de preço fixa (range_size).
Um novo bloco é criado somente quando o preço se move
range_size pontos acima ou abaixo do fechamento (ou abertura ancorada).
"""

from dataclasses import dataclass
from typing import List
import MetaTrader5 as mt5
from mtcli.logger import setup_logger

log = setup_logger("mtcli.range.model")


@dataclass
class RangeBlock:
    """Representa um bloco de Range."""
    open: float
    close: float
    direction: str  # "UP" ou "DOWN"


class RangeModel:
    """
    Responsável por:
    - Buscar dados no MT5
    - Calcular blocos de Range
    """

    def __init__(
        self,
        symbol: str,
        timeframe_const: int,
        bars: int,
        range_size: float,
        ancorar_abertura: bool = False,
    ):
        self.symbol = symbol
        self.timeframe_const = timeframe_const
        self.bars = bars
        self.range_size = range_size
        self.ancorar_abertura = ancorar_abertura

    def obter_candles(self):
        """Obtém candles do MT5."""
        log.info(f"Buscando {self.bars} candles de {self.symbol}")
        rates = mt5.copy_rates_from_pos(
            self.symbol,
            self.timeframe_const,
            0,
            self.bars
        )

        if rates is None:
            raise RuntimeError("Erro ao obter dados do MT5.")

        return rates

    def gerar_range(self) -> List[RangeBlock]:
        """
        Constrói blocos de Range a partir dos candles base.
        """

        rates = self.obter_candles()

        if len(rates) == 0:
            return []

        blocos: List[RangeBlock] = []

        # 🔹 Âncora inicial
        if self.ancorar_abertura:
            ultimo_preco_base = rates[0]["open"]
            log.info("Range ancorado na abertura do primeiro candle.")
        else:
            ultimo_preco_base = rates[0]["close"]
            log.info("Range iniciado a partir do fechamento do primeiro candle.")

        for candle in rates[1:]:
            preco = candle["close"]

            while abs(preco - ultimo_preco_base) >= self.range_size:

                if preco > ultimo_preco_base:
                    novo_close = ultimo_preco_base + self.range_size
                    direcao = "UP"
                else:
                    novo_close = ultimo_preco_base - self.range_size
                    direcao = "DOWN"

                bloco = RangeBlock(
                    open=ultimo_preco_base,
                    close=novo_close,
                    direction=direcao
                )

                blocos.append(bloco)
                ultimo_preco_base = novo_close

        log.info(f"{len(blocos)} blocos de range gerados.")
        return blocos
