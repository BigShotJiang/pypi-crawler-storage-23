# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

### Added

- Standards: distribution.md, plugins.md, shell.md, naming.md
- CLI: `punt init` scaffolding, `punt audit` compliance checks
- Plugin: `/punt reconcile` command (in progress)

### Changed

- Rewrote distribution.md around projection model and one-command principle
- Updated plugins.md with marketplace patterns and MCP server key naming guidance
