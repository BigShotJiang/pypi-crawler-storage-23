``` python
print('Hello Markdown!')
```
``` result
```
