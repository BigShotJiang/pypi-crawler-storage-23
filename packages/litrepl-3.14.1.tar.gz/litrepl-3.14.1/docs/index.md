# Litrepl

**Litrepl** is a {!static/description.md!}

The [repository](https://github.com/sergei-mironov/litrepl) includes a Vim plugin to demonstrate
editor integration.
