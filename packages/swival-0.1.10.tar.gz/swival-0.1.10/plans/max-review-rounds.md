# Make `max_review_rounds` configurable

Currently `MAX_REVIEW_ROUNDS = 5` is a hardcoded constant in `agent.py:1178`.
This plan makes it a proper config/CLI option following existing patterns.

## Changes

### 1. `swival/config.py`

- Add `"max_review_rounds": int` to `CONFIG_KEYS`
- Add `"max_review_rounds": 5` to `_ARGPARSE_DEFAULTS`
- Add `"max_review_rounds"` to the `_DROP_KEYS` set in `config_to_session_kwargs()` (it's CLI-only, not a Session kwarg)
- Add a commented-out example to `generate_config()`

No `_CONFIG_TO_ARGPARSE` mapping needed — the config key already matches the argparse dest.

### 2. `swival/agent.py`

- Remove the `MAX_REVIEW_ROUNDS = 5` constant
- Add `--max-review-rounds` to the argparse parser (with `default=_UNSET`, like other int options)
- Validate `>= 0` **after config merge** (not only in argparse) so negative values from `swival.toml` are also rejected. Value of 0 means "no retries, accept the first answer"
- In the review loop, replace `MAX_REVIEW_ROUNDS` references with `args.max_review_rounds`
- Add `"max_review_rounds": args.max_review_rounds` to the `_report_settings()` dict

### 3. Tests

- Update `test_reviewer.py` tests that reference `agent.MAX_REVIEW_ROUNDS` to use the new config path
- Update the shared fake arg namespace in reviewer tests to include `max_review_rounds`
- Add tests for:
  - Custom value flows through correctly (CLI flag overrides default)
  - `--max-review-rounds 0` disables retries
  - Negative values are rejected (both via CLI and via toml)
  - Explicit precedence test for `max_review_rounds`: global toml sets 3, project toml sets 7, CLI sets 10 — verify CLI wins, then project wins over global, then global wins over default

### 4. Docs

- Add `--max-review-rounds` to the CLI reference in `docs.md/`
- Regenerate HTML with `make website`

### 5. No changes to `session.py`

The reviewer loop lives in `main()`, not in `Session` or `run_agent_loop()`, so Session doesn't need this option.
