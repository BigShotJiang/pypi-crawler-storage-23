#ifndef __WRAP_XSF_H__
#define __WRAP_XSF_H__
#ifdef __cplusplus
extern "C" {
#endif

double hyp2f1(double a, double b, double c, double z);

#ifdef __cplusplus
}
#endif
#endif
