###################TEST WHETHER THE PACKAGE CAN BE IMPORTED####################
def test_top_import():
    import galpy


def test_orbit_import():
    import galpy.orbit


def test_potential_import():
    import galpy.potential


def test_actionAngle_import():
    import galpy.actionAngle


def test_df_import():
    import galpy.df


def test_util_import():
    import galpy.util
    import galpy.util.conversion
    import galpy.util.coords
    import galpy.util.multi
    import galpy.util.plot
