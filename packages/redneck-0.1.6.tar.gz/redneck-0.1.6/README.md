<p align="center">
  <img src="https://raw.githubusercontent.com/Ariss-Interactive/redneck/refs/heads/master/docs/assets/logo.png" alt="Redneck">
</p>

<hr>

Redneck is a small, plugin-driven, declarative modpack builder, allowing you to declare a mod with a few lines of YAML code.