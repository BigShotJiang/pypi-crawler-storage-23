"""Grid Data Models MCP Server.

MCP (Model Context Protocol) server integration for grid-data-models,
providing AI agents with tools for validation, system operations, and inspection.
"""

from gdm.mcp.version import __version__

__all__ = ["__version__"]
