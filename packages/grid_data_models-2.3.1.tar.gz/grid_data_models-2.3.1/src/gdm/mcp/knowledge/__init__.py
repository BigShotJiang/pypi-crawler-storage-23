"""Knowledge and documentation tools for GDM."""
