"""Viewer route handlers.

These modules keep `codemem.viewer` focused on the HTTP server/handler while
isolating route logic into small, testable units.
"""
