from __future__ import annotations

import shutil

import clypi
from clypi import Boxes, Spin

_MIN_WIDTH = 40
_CONTENT_WIDTH = 72


def _terminal_width() -> int:
    cols = shutil.get_terminal_size((80, 24)).columns
    return max(_MIN_WIDTH, cols)


bold = clypi.Styler(bold=True)
dim = clypi.Styler(dim=True)
cyan = clypi.Styler(fg="cyan")
green = clypi.Styler(fg="green", bold=True)
yellow = clypi.Styler(fg="yellow")
red = clypi.Styler(fg="red")
magenta = clypi.Styler(fg="magenta")
white = clypi.Styler(fg="white")
gray = clypi.Styler(fg="white", dim=True)


def hr(char: str = "─", width: int | None = None) -> str:
    w = min(width or _terminal_width(), _CONTENT_WIDTH)
    return dim(clypi.separator(separator=char, width=w))


def box(text: str, width: int | None = None, style: str = "default") -> str:
    from clypi import ColorType

    w = min(width or _terminal_width(), _CONTENT_WIDTH)
    color_map: dict[str, ColorType] = {
        "default": "cyan",
        "success": "green",
        "warning": "yellow",
        "error": "red",
    }
    box_color = color_map.get(style, "cyan")

    return clypi.boxed(
        text,
        width=w,
        style=Boxes.ROUNDED,
        color=box_color,
        align="center",
    )


STATUS_RUNNING = green("●")
STATUS_STOPPED = dim("○")
STATUS_ERROR = red("●")

ARROW_RIGHT = cyan("›")
ARROW_DOWN = cyan("▼")
BULLET = cyan("•")
TRIANGLE = cyan("▸")
CHECK = green("✓")
CROSS = red("✗")
SPINNER = cyan(Spin.DOTS.value[0])  # Or use clypi.spinner directly where needed


def pad(n: int = 1) -> str:
    return "\n" * n
