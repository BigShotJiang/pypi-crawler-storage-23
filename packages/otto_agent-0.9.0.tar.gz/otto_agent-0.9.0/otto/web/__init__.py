"""Otto web dashboard — package root.

Re-exports for backward compatibility:
    from otto.web import ConfigServer
    from otto.web import _MASKED_TOKEN
    otto.web.web → aiohttp.web   (for test patching compat)
    otto.web.helpers              (for test patching of _daemon_status)
"""

from __future__ import annotations

from aiohttp import web  # noqa: F401 — exposes otto.web.web for test compat

from otto.web import helpers  # noqa: F401 — exposes otto.web.helpers for patching
from otto.web.helpers import _MASKED_TOKEN  # noqa: F401
from otto.web.server import ConfigServer  # noqa: F401

__all__ = ["ConfigServer", "_MASKED_TOKEN"]
