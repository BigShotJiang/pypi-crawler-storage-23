"""pyntc - Python library for structural verification according to NTC 2018."""

__version__ = "0.1.0"
