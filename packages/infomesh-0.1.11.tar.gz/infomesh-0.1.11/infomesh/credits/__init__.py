"""Incentive system."""
