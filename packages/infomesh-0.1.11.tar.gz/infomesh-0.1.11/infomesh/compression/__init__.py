"""Data compression."""
