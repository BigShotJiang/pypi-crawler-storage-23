"""Rich console with fallback."""
try:
    from rich.console import Console
    console = Console()
except ImportError:
    import re as _re
    class _C:
        def print(self, *a, **k):
            print(_re.sub(r"\[/?[a-zA-Z0-9_ ]*\]", "", " ".join(str(x) for x in a)))
        def input(self, p=""):
            return input(p)
    console = _C()  # type: ignore
