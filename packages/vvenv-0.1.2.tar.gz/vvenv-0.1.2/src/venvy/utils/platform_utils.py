"""Cross-platform utility helpers."""

from __future__ import annotations

import os
import platform
from pathlib import Path
from typing import Optional


IS_WINDOWS = platform.system() == "Windows"


def get_active_venv() -> Optional[str]:
    """Return the path to the currently active virtual environment, if any."""
    return os.environ.get("VIRTUAL_ENV")


def get_venv_python(venv_path: Path) -> Path:
    """Get the Python executable path inside a venv."""
    if IS_WINDOWS:
        return venv_path / "Scripts" / "python.exe"
    return venv_path / "bin" / "python"


def is_venv_active(venv_path: Path) -> bool:
    """Check if the given venv is currently active."""
    active = get_active_venv()
    if not active:
        return False
    return Path(active).resolve() == venv_path.resolve()


def get_shell_init_script() -> str:
    """
    Returns a shell function definition that users can add to their
    shell config (~/.bashrc, ~/.zshrc, etc.) so that:
      - `venvy +` activates the local venv
      - `venvy -` deactivates the venv
      - `pip install ...` and `pip uninstall ...` auto-update requirements
    """
    return r'''
# ── venvy shell integration ──────────────────────────────────────────
# Add this to your ~/.bashrc or ~/.zshrc

function venvy() {
  case "$1" in
    +)
      local venv
      venv="$(command venvy _find-venv 2>/dev/null)"
      if [ -n "$venv" ]; then
        source "$venv/bin/activate"
        echo "✓ Activated: $venv"
      else
        echo "✗ No virtual environment found. Run: venvy create venv"
      fi
      ;;
    -)
      if [ -n "$VIRTUAL_ENV" ]; then
        deactivate
        echo "✓ Deactivated virtual environment."
      else
        echo "✗ No active virtual environment."
      fi
      ;;
    *)
      command venvy "$@"
      ;;
  esac
}

function pip() {
  local action="$1"
  if [ "$action" = "install" ] || [ "$action" = "uninstall" ]; then
    command venvy pip "$@"
  else
    command pip "$@"
  fi
}
# ─────────────────────────────────────────────────────────────────────
'''


def get_shell_init_script_windows() -> str:
    """
    Returns a PowerShell function for Windows users.
    """
    return r'''
# ── venvy PowerShell integration ─────────────────────────────────────
# Add this to your $PROFILE

function venvy {
  param([Parameter(ValueFromRemainingArguments=$true)]$args)
  switch ($args[0]) {
    '+' {
      $venv = (venvy.exe _find-venv 2>$null)
      if ($venv) {
        & "$venv\Scripts\Activate.ps1"
        Write-Host "✓ Activated: $venv" -ForegroundColor Green
      } else {
        Write-Host "✗ No virtual environment found. Run: venvy create venv" -ForegroundColor Red
      }
    }
    '-' {
      if ($env:VIRTUAL_ENV) {
        deactivate
        Write-Host "✓ Deactivated virtual environment." -ForegroundColor Green
      } else {
        Write-Host "✗ No active virtual environment." -ForegroundColor Red
      }
    }
    default { & venvy.exe @args }
  }
}

function pip {
  param([Parameter(ValueFromRemainingArguments=$true)]$args)
  if ($args[0] -eq 'install' -or $args[0] -eq 'uninstall') {
    venvy pip @args
  } else {
    pip.exe @args
  }
}
# ─────────────────────────────────────────────────────────────────────
'''
