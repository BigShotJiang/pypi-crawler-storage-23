"""venvy install-hook — inject pip auto-tracking into an existing venv."""
from __future__ import annotations
from pathlib import Path
import typer
from venvy.core.venv_manager import find_venv, inject_hook
from venvy.utils.console import console


def install_hook_command(venv_dir: str = "") -> None:
    if venv_dir:
        venv_path = Path(venv_dir).resolve()
    else:
        venv_path = find_venv()

    if not venv_path or not venv_path.exists():
        console.print(
            "[red]✗[/red] No virtual environment found.\n"
            "  Pass path explicitly: [bold]venvy install-hook .venv[/bold]\n"
            "  Or create one: [bold]venvy create venv[/bold]"
        )
        raise typer.Exit(1)

    console.print(f"[cyan]→[/cyan] Injecting hook into [bold]{venv_path}[/bold]...")
    if inject_hook(venv_path):
        console.print(
            "[green]✓[/green] Done! Now [bold]pip install[/bold] / [bold]pip uninstall[/bold] "
            "in this venv will auto-update requirements.txt"
        )
    else:
        console.print("[red]✗[/red] Hook injection failed — is this a valid venv?")
        raise typer.Exit(1)
