"""
venvy.commands.info
~~~~~~~~~~~~~~~~~~~
Implements: venvy info / venvy status
"""

from __future__ import annotations

import os
from pathlib import Path

from rich.console import Console
from rich.table import Table

from venvy.core.config import VenvyConfig
from venvy.core.requirements import RequirementsManager
from venvy.core.venv import VenvManager

console = Console()


def cmd_info() -> None:
    """Show info about the current project's virtual environment."""
    cwd = Path.cwd()
    config = VenvyConfig.find(cwd)

    if config:
        console.print(f"\n[bold cyan]venvy[/bold cyan] — Project Info\n")
        root = VenvyConfig.find_root(cwd) or cwd
        venv_mgr = VenvManager(project_root=root, venv_name=config.venv_name)

        table = Table(show_header=False, box=None, padding=(0, 2))
        table.add_column(style="bold dim")
        table.add_column()

        table.add_row("Project root", str(root))
        table.add_row("Config file", ".venvy.json")
        table.add_row("Venv name", config.venv_name)
        table.add_row("Venv path", str(venv_mgr.venv_path))
        table.add_row("Venv exists", "[green]Yes[/green]" if venv_mgr.exists else "[red]No[/red]")
        table.add_row(
            "Venv active",
            "[green]Yes[/green]" if venv_mgr.is_active() else "[dim]No[/dim]",
        )
        table.add_row("Requirements file", config.requirements_file)
        table.add_row("ipykernel", "Yes" if config.ipykernel else "No")

        console.print(table)

        # Show packages
        req_path = root / config.requirements_file
        req_mgr = RequirementsManager(req_path)
        if req_mgr.exists:
            packages = req_mgr.list_packages()
            if packages:
                console.print(f"\n[bold]Packages in {config.requirements_file}:[/bold]")
                for name, spec in sorted(packages.items()):
                    console.print(f"  [cyan]{name}[/cyan]{spec}")
        console.print()
    else:
        # Fallback: just check active venv
        active = os.environ.get("VIRTUAL_ENV")
        if active:
            console.print(f"\n[yellow]Active venv:[/yellow] {active}")
            console.print("[dim]No .venvy.json found. Run `venvy create venv` to initialize.[/dim]\n")
        else:
            console.print("\n[dim]No active virtual environment. No .venvy.json found.[/dim]")
            console.print("Run [bold cyan]venvy create venv[/bold cyan] to get started.\n")
