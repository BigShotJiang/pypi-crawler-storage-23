"""
venvy inject — inject pip tracker into an existing venv.
Useful when user created venv manually (python -m venv .venv).
"""
from __future__ import annotations
from pathlib import Path

import typer
from venvy.core.injector import inject, is_injected
from venvy.core.venv_manager import find
from venvy.utils.console import console


def run(venv_path_str: str = "") -> None:
    cwd = Path.cwd()

    if venv_path_str:
        venv = Path(venv_path_str).resolve()
    else:
        venv = find(cwd)

    if not venv or not venv.exists():
        console.print(
            "[red]✗[/red] No virtual environment found.\n"
            "  Create one with [bold]venvy create venv[/bold] or specify path:\n"
            "  [dim]venvy inject .venv[/dim]"
        )
        raise typer.Exit(1)

    if is_injected(venv):
        console.print(f"[green]✓[/green] pip tracker already installed in [bold]{venv.name}[/bold]")
        return

    inject(venv)
    console.print(
        f"[green]✓[/green] pip tracker installed in [bold]{venv.name}[/bold]\n"
        f"[dim]pip install/uninstall will now auto-update requirements.txt[/dim]"
    )
