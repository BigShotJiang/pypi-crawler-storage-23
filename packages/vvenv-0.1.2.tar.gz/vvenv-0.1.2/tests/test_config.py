"""Tests for config module."""

import json
import pytest
from pathlib import Path

from venvy.core.config import (
    VenvyConfig,
    load_config,
    save_config,
    find_project_root,
    VENVY_DIR,
    CONFIG_FILE,
)


def test_config_defaults():
    cfg = VenvyConfig()
    assert cfg.venv_name == ".venv"
    assert cfg.requirements_file == "requirements.txt"
    assert cfg.install_ipykernel is False


def test_config_roundtrip(tmp_path):
    cfg = VenvyConfig(venv_name=".venv", requirements_file="reqs.txt", install_ipykernel=True)
    save_config(cfg, tmp_path)
    loaded = load_config(tmp_path)
    assert loaded is not None
    assert loaded.venv_name == ".venv"
    assert loaded.requirements_file == "reqs.txt"
    assert loaded.install_ipykernel is True


def test_load_config_missing(tmp_path):
    assert load_config(tmp_path) is None


def test_find_project_root(tmp_path):
    # No config yet
    assert find_project_root(tmp_path) is None

    # Create config
    save_config(VenvyConfig(), tmp_path)

    # Should find from subdir
    subdir = tmp_path / "a" / "b"
    subdir.mkdir(parents=True)
    root = find_project_root(subdir)
    assert root == tmp_path
