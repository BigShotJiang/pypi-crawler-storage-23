"""SlurmTerm UI screens / tab widgets."""
