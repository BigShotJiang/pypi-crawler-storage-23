"""SlurmTerm — A Terminal User Interface for Slurm."""

__version__ = "0.1.0"
