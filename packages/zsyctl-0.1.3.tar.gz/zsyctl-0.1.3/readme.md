## 开发目的
开发一个命令行工具，上传到 pypi，可以直接下载使用的
## 功能需求
1. 命令行名称 zsyctl
2. 下载功能
   - zsyctl download --dataset <id> <output_path>
   - zsyctl download --model <id> <output_path>
   - id: 资源id
   - output_path: 输出路径
   - 示例：
     - zsyctl download --dataset id --local_dir ./dir
     - zsyctl download --model id --local_dir ./dir
3. 下载之前，先去调用接口 https://cloud.ai4net.cn/center/server/zsyctl/auth 获取s3 的临时凭证，然后使用临时凭证下载，其中环境变量 CENTER_HOST 是中心域名，默认是 cloud.ai4net.cn，ZONE是当前集群的 id
4. 这个临时凭证是个 jwtToken 加密的，可解密，解密后，是 s3 的 key 和 secret，以及中心集群的s3 地址和当前集群的s3 地址
5. 先测试当前集群是否有数据，没有则使用中心集群下载
6. 然后就可以通过地址、账号密码下载了