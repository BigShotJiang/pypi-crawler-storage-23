"""
FFI bindings to the MicroPDF Rust library.

This module is a backwards-compatible re-export from ffi_native.
For new code, import directly from micropdf.ffi_native.

This module uses cffi to interface with the compiled Rust library.
It defines all the C function signatures and provides a low-level interface.
"""

# Re-export everything from the consolidated module
from .ffi_native import (
    ffi,
    lib,
    FZ_STORE_DEFAULT,
    MockLib,
    get_platform_info,
    get_lib_name,
    find_library,
    download_library,
    load_library,
    get_library_path,
    is_native_available,
    reload_library,
)

# Backwards-compatible alias
_find_library = find_library

__all__ = [
    "ffi",
    "lib",
    "FZ_STORE_DEFAULT",
    "MockLib",
    "_find_library",
]
