"""
Native library loading for MicroPDF Python bindings.

This module is a backwards-compatible re-export from ffi_native.
For new code, import directly from micropdf.ffi_native.

This module handles finding and loading the native MicroPDF library,
including downloading prebuilt binaries if they're not available.
"""

# Re-export everything from the consolidated module
from .ffi_native import (
    # Platform detection
    PLATFORM_MAP,
    ARCH_MAP,
    LIB_NAMES,
    get_platform_info,
    get_lib_name,
    # Library functions
    find_library,
    download_library,
    load_library,
    get_library_path,
    is_native_available,
    reload_library,
)

# Version
try:
    from .version import __version__
except ImportError:
    __version__ = "0.6.0"

# Import constants for re-export
from .ffi_native import PLATFORM_MAP, ARCH_MAP, LIB_NAMES

__all__ = [
    "PLATFORM_MAP",
    "ARCH_MAP",
    "LIB_NAMES",
    "get_platform_info",
    "get_lib_name",
    "find_library",
    "download_library",
    "load_library",
    "get_library_path",
    "is_native_available",
    "reload_library",
]
