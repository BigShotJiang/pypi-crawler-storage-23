"""
Consolidated FFI and native library loading for MicroPDF Python bindings.

This module handles:
1. Platform detection
2. Native library discovery and loading
3. FFI bindings via cffi
4. Fallback mock library for testing/development

Usage:
    from micropdf.ffi_native import ffi, lib, FZ_STORE_DEFAULT, get_library_path
"""

import os
import sys
import platform
import urllib.request
import tarfile
import tempfile
import shutil
from pathlib import Path
from typing import Optional
from cffi import FFI

# =============================================================================
# Version
# =============================================================================

try:
    from .version import __version__
except ImportError:
    __version__ = "0.6.0"

# =============================================================================
# Platform Detection
# =============================================================================

PLATFORM_MAP = {
    "Linux": "linux",
    "Darwin": "darwin",
    "Windows": "win32",
}

ARCH_MAP = {
    "x86_64": "x64",
    "AMD64": "x64",
    "aarch64": "arm64",
    "arm64": "arm64",
    "i386": "ia32",
    "i686": "ia32",
}

LIB_NAMES = {
    "linux": "libmicropdf.so",
    "darwin": "libmicropdf.dylib",
    "win32": "micropdf.dll",
}


def get_platform_info() -> tuple[str, str]:
    """Get the current platform and architecture."""
    system = platform.system()
    machine = platform.machine()
    plat = PLATFORM_MAP.get(system, system.lower())
    arch = ARCH_MAP.get(machine, machine)
    return plat, arch


def get_lib_name() -> str:
    """Get the library name for the current platform."""
    plat, _ = get_platform_info()
    return LIB_NAMES.get(plat, "libmicropdf.so")


# =============================================================================
# Library Discovery
# =============================================================================

def find_library() -> Optional[Path]:
    """
    Find the native library.

    Search order:
    1. MICROPDF_LIB_PATH environment variable
    2. Bundled in package (lib/<platform>-<arch>/)
    3. Rust build output (../micropdf-rs/target/release/)
    4. System library paths

    Returns:
        Path to the library, or None if not found.
    """
    plat, arch = get_platform_info()
    lib_name = get_lib_name()
    package_dir = Path(__file__).parent

    # 1. Check environment variable first
    env_path = os.environ.get("MICROPDF_LIB_PATH")
    if env_path:
        env_lib = Path(env_path)
        if env_lib.is_file() and env_lib.exists():
            return env_lib
        if env_lib.is_dir():
            for candidate in [lib_name, "libmicropdf.so", "libmicropdf.dylib", "micropdf.dll"]:
                candidate_path = env_lib / candidate
                if candidate_path.exists():
                    return candidate_path

    # 2. Check bundled library
    lib_dir = package_dir / "lib" / f"{plat}-{arch}"
    bundled_path = lib_dir / lib_name
    if bundled_path.exists():
        return bundled_path

    # Also check lib directory for any matching library
    if lib_dir.exists():
        for f in lib_dir.iterdir():
            if f.suffix in (".so", ".dylib", ".dll") and "micropdf" in f.name:
                return f

    # 3. Check Rust build output (development mode)
    rust_target = package_dir.parent.parent.parent / "micropdf-rs" / "target" / "release" / lib_name
    if rust_target.exists():
        return rust_target

    # Also check debug build
    rust_debug = package_dir.parent.parent.parent / "micropdf-rs" / "target" / "debug" / lib_name
    if rust_debug.exists():
        return rust_debug

    # 4. Check system library paths
    system_paths = []
    if plat == "linux":
        system_paths = ["/usr/local/lib", "/usr/lib", "/lib", os.path.expanduser("~/.local/lib")]
    elif plat == "darwin":
        system_paths = ["/usr/local/lib", "/opt/homebrew/lib"]

    for system_path in system_paths:
        system_lib = Path(system_path) / lib_name
        if system_lib.exists():
            return system_lib

    return None


def download_library() -> Optional[Path]:
    """
    Download the prebuilt library.

    Returns:
        Path to the downloaded library, or None if download failed.
    """
    if os.environ.get("MICROPDF_SKIP_DOWNLOAD", "").lower() in ("1", "true", "yes"):
        return None

    plat, arch = get_platform_info()
    lib_name = get_lib_name()
    download_url = f"https://bitbucket.org/lexmata/micropdf/downloads/micropdf-{plat}-{arch}.tar.gz"

    package_dir = Path(__file__).parent
    lib_dir = package_dir / "lib" / f"{plat}-{arch}"
    target_path = lib_dir / lib_name

    try:
        lib_dir.mkdir(parents=True, exist_ok=True)

        with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as tmp:
            tmp_path = Path(tmp.name)

        urllib.request.urlretrieve(download_url, tmp_path)

        with tarfile.open(tmp_path, "r:gz") as tar:
            tar.extractall(lib_dir.parent)

        tmp_path.unlink()

        if target_path.exists():
            return target_path

        # Check if extraction put files in a subdirectory
        for pattern in ["*.so", "*.dylib", "*.dll"]:
            for f in lib_dir.parent.rglob(pattern):
                if "micropdf" in f.name:
                    shutil.copy(f, target_path)
                    return target_path

        return None

    except Exception:
        return None


def load_library() -> Optional[Path]:
    """
    Load the native MicroPDF library.

    Returns:
        Path to the library, or None if not available.
    """
    lib_path = find_library()
    if lib_path:
        return lib_path

    lib_path = download_library()
    if lib_path:
        return lib_path

    return None


# Module-level library path cache
_library_path: Optional[Path] = None


def get_library_path() -> Optional[Path]:
    """Get the path to the native library (cached)."""
    global _library_path
    if _library_path is None:
        _library_path = load_library()
    return _library_path


# =============================================================================
# FFI Definitions
# =============================================================================

ffi = FFI()

# Core FFI definitions
ffi.cdef("""
    // Type aliases
    typedef int8_t i8;
    typedef int16_t i16;
    typedef int32_t i32;
    typedef int64_t i64;
    typedef uint8_t u8;
    typedef uint16_t u16;
    typedef uint32_t u32;
    typedef uint64_t u64;
    typedef float f32;
    typedef double f64;

    // Geometry structures
    typedef struct { float x, y; } fz_point;
    typedef struct { float x0, y0, x1, y1; } fz_rect;
    typedef struct { int x0, y0, x1, y1; } fz_irect;
    typedef struct { float a, b, c, d, e, f; } fz_matrix;
    typedef struct { fz_point ul, ur, ll, lr; } fz_quad;

    // Opaque handle types
    typedef uint64_t fz_context;
    typedef uint64_t fz_document;
    typedef uint64_t fz_page;
    typedef uint64_t fz_pixmap;
    typedef uint64_t fz_buffer;
    typedef uint64_t fz_colorspace;
    typedef uint64_t fz_stext_page;
    typedef uint64_t fz_link;
    typedef uint64_t fz_stream;
    typedef uint64_t fz_output;
    typedef uint64_t fz_font;
    typedef uint64_t fz_image;
    typedef uint64_t fz_cookie;
    typedef uint64_t fz_device_handle;
    typedef uint64_t fz_path;

    // Context functions
    fz_context fz_new_context(const void* alloc, const void* locks, size_t max_store);
    void fz_drop_context(fz_context ctx);
    fz_context fz_clone_context(fz_context ctx);

    // Document functions
    fz_document fz_open_document(fz_context ctx, const char* filename);
    fz_document fz_open_document_with_buffer(fz_context ctx, const char* magic, const unsigned char* data, size_t len);
    void fz_drop_document(fz_context ctx, fz_document doc);
    int fz_count_pages(fz_context ctx, fz_document doc);
    int fz_needs_password(fz_context ctx, fz_document doc);
    int fz_authenticate_password(fz_context ctx, fz_document doc, const char* password);
    int fz_has_permission(fz_context ctx, fz_document doc, int permission);
    int fz_lookup_metadata(fz_context ctx, fz_document doc, const char* key, char* buf, int size);
    void pdf_save_document(fz_context ctx, fz_document doc, const char* filename, const void* opts);

    // Page functions
    fz_page fz_load_page(fz_context ctx, fz_document doc, int number);
    void fz_drop_page(fz_context ctx, fz_page page);
    fz_rect fz_bound_page(fz_context ctx, fz_page page);

    // Colorspace functions
    fz_colorspace fz_device_rgb(fz_context ctx);
    fz_colorspace fz_device_gray(fz_context ctx);
    fz_colorspace fz_device_bgr(fz_context ctx);
    fz_colorspace fz_device_cmyk(fz_context ctx);
    int fz_colorspace_n(fz_context ctx, fz_colorspace cs);
    const char* fz_colorspace_name(fz_context ctx, fz_colorspace cs);

    // Matrix functions
    fz_matrix fz_identity(void);
    fz_matrix fz_scale(float sx, float sy);
    fz_matrix fz_translate(float tx, float ty);
    fz_matrix fz_rotate(float degrees);
    fz_matrix fz_concat(fz_matrix a, fz_matrix b);

    // Pixmap functions
    fz_pixmap fz_new_pixmap(fz_context ctx, fz_colorspace cs, int w, int h, int alpha);
    fz_pixmap fz_new_pixmap_from_page(fz_context ctx, fz_page page, fz_matrix ctm, fz_colorspace cs, int alpha);
    void fz_drop_pixmap(fz_context ctx, fz_pixmap pix);
    int fz_pixmap_width(fz_context ctx, fz_pixmap pix);
    int fz_pixmap_height(fz_context ctx, fz_pixmap pix);
    int fz_pixmap_components(fz_context ctx, fz_pixmap pix);
    int fz_pixmap_stride(fz_context ctx, fz_pixmap pix);
    unsigned char* fz_pixmap_samples(fz_context ctx, fz_pixmap pix);
    void fz_clear_pixmap(fz_context ctx, fz_pixmap pix);

    // Buffer functions
    fz_buffer fz_new_buffer(fz_context ctx, size_t capacity);
    fz_buffer fz_new_buffer_from_copied_data(fz_context ctx, const unsigned char* data, size_t size);
    void fz_drop_buffer(fz_context ctx, fz_buffer buf);
    size_t fz_buffer_storage(fz_context ctx, fz_buffer buf, unsigned char** datap);
    const unsigned char* fz_buffer_data(fz_context ctx, fz_buffer buf, size_t* len);
    void fz_append_data(fz_context ctx, fz_buffer buf, const void* data, size_t len);
    void fz_append_string(fz_context ctx, fz_buffer buf, const char* str);
    void fz_clear_buffer(fz_context ctx, fz_buffer buf);
    fz_buffer fz_new_buffer_from_pixmap_as_png(fz_context ctx, fz_pixmap pix, int color_params);

    // Text extraction functions
    fz_stext_page fz_new_stext_page_from_page(fz_context ctx, fz_page page, const void* options);
    void fz_drop_stext_page(fz_context ctx, fz_stext_page stext);
    fz_buffer fz_new_buffer_from_stext_page(fz_context ctx, fz_stext_page stext);
    int fz_search_stext_page(fz_context ctx, fz_stext_page stext, const char* needle, int* mark, fz_quad* hit_bbox, int hit_max);

    // Link functions
    fz_link fz_load_links(fz_context ctx, fz_page page);
    void fz_drop_link(fz_context ctx, fz_link link);
    fz_rect fz_link_rect(fz_context ctx, fz_link link);
    const char* fz_link_uri(fz_context ctx, fz_link link);
    fz_link fz_link_next(fz_context ctx, fz_link link);

    // Stream functions
    fz_stream fz_open_file(fz_context ctx, const char* filename);
    fz_stream fz_open_memory(fz_context ctx, const unsigned char* data, size_t len);
    void fz_drop_stream(fz_context ctx, fz_stream stm);
    size_t fz_read(fz_context ctx, fz_stream stm, unsigned char* data, size_t len);
    int fz_read_byte(fz_context ctx, fz_stream stm);
    int fz_is_eof(fz_context ctx, fz_stream stm);
    void fz_seek(fz_context ctx, fz_stream stm, int64_t offset, int whence);
    int64_t fz_tell(fz_context ctx, fz_stream stm);

    // Output functions
    fz_output fz_new_output_with_path(fz_context ctx, const char* filename, int append);
    fz_output fz_new_output_with_buffer(fz_context ctx, fz_buffer buf);
    void fz_drop_output(fz_context ctx, fz_output out);
    void fz_write_data(fz_context ctx, fz_output out, const void* data, size_t size);
    void fz_write_string(fz_context ctx, fz_output out, const char* s);
    void fz_write_byte(fz_context ctx, fz_output out, unsigned char byte);
    int64_t fz_tell_output(fz_context ctx, fz_output out);

    // Font functions
    fz_font fz_new_font(fz_context ctx, const char* name, int is_bold, int is_italic, uint64_t font_file);
    fz_font fz_new_font_from_file(fz_context ctx, const char* name, const char* path, int index, int use_glyph_bbox);
    fz_font fz_new_font_from_memory(fz_context ctx, const char* name, const unsigned char* data, int len, int index, int use_glyph_bbox);
    void fz_drop_font(fz_context ctx, fz_font font);
    void fz_font_name(fz_context ctx, fz_font font, char* buf, int size);
    int fz_font_is_bold(fz_context ctx, fz_font font);
    int fz_font_is_italic(fz_context ctx, fz_font font);

    // Image functions
    fz_image fz_new_image_from_file(fz_context ctx, const char* path);
    fz_image fz_new_image_from_buffer(fz_context ctx, fz_buffer buffer);
    fz_image fz_new_image_from_pixmap(fz_context ctx, fz_pixmap pixmap, fz_image mask);
    void fz_drop_image(fz_context ctx, fz_image image);
    int fz_image_width(fz_context ctx, fz_image image);
    int fz_image_height(fz_context ctx, fz_image image);

    // Cookie functions
    fz_cookie fz_new_cookie(fz_context ctx);
    void fz_drop_cookie(fz_context ctx, fz_cookie cookie);
    void fz_abort_cookie(fz_context ctx, fz_cookie cookie);
    int fz_cookie_is_aborted(fz_context ctx, fz_cookie cookie);

    // Path functions
    fz_path fz_new_path(fz_context ctx);
    void fz_drop_path(fz_context ctx, fz_path path);
    void fz_moveto(fz_context ctx, fz_path path, float x, float y);
    void fz_lineto(fz_context ctx, fz_path path, float x, float y);
    void fz_curveto(fz_context ctx, fz_path path, float x1, float y1, float x2, float y2, float x3, float y3);
    void fz_closepath(fz_context ctx, fz_path path);
    void fz_rectto(fz_context ctx, fz_path path, float x, float y, float w, float h);

    // Enhanced MicroPDF Functions
    int32_t mp_add_blank_page(int32_t ctx, int32_t doc, float width, float height);
    int32_t mp_merge_pdfs(int32_t ctx, const char * const * paths, int32_t count, const char * output_path);
    int32_t mp_split_pdf(int32_t ctx, const char * input_path, const char * output_dir);
    int32_t mp_write_pdf(int32_t ctx, int32_t doc, const char * path);
    int32_t mp_optimize_pdf(int32_t ctx, const char * path);
    int32_t mp_linearize_pdf(int32_t ctx, const char * input_path, const char * output_path);
    int32_t mp_add_watermark(int32_t ctx, const char * input_path, const char * output_path, const char * text, float x, float y, float font_size, float opacity);
    int32_t mp_draw_rectangle(int32_t ctx, int32_t page, float x, float y, float width, float height, float r, float g, float b, float alpha, int32_t fill);
    int32_t mp_draw_circle(int32_t ctx, int32_t page, float x, float y, float radius, float r, float g, float b, float alpha, int32_t fill);
    int32_t mp_draw_line(int32_t ctx, int32_t page, float x0, float y0, float x1, float y1, float r, float g, float b, float alpha, float line_width);
    void mp_free_string(char * s);

    // ============================================================================
    // Convenience Functions - High-level wrappers for common PDF operations
    // ============================================================================

    // Result structures
    typedef struct {
        int32_t page_count;
        int32_t is_encrypted;
        int32_t needs_password;
        char* version;
        char* title;
        char* author;
        char* subject;
        char* creator;
    } MpPdfInfo;

    typedef struct {
        float width;
        float height;
    } MpPageDimensions;

    typedef struct {
        uint8_t* data;
        size_t data_len;
        int32_t width;
        int32_t height;
    } MpRenderedPage;

    typedef struct {
        char* text;
        size_t text_len;
        int32_t pages_processed;
    } MpExtractedText;

    // Document information
    int32_t mp_get_pdf_info(const char* pdf_path, MpPdfInfo* info_out);
    void mp_free_pdf_info(MpPdfInfo* info);
    int32_t mp_get_page_count(const char* pdf_path);
    int32_t mp_get_page_dimensions(const char* pdf_path, int32_t page_num, MpPageDimensions* dims_out);

    // Text extraction
    int32_t mp_extract_text(const char* pdf_path, MpExtractedText* result_out);
    char* mp_extract_page_text(const char* pdf_path, int32_t page_num);
    void mp_free_extracted_text(MpExtractedText* result);

    // Page rendering
    int32_t mp_render_page_to_png(const char* pdf_path, int32_t page_num, float scale, MpRenderedPage* result_out);
    int32_t mp_render_page_to_rgb(const char* pdf_path, int32_t page_num, float scale, MpRenderedPage* result_out);
    void mp_free_rendered_page(MpRenderedPage* result);

    // File operations
    int32_t mp_merge_pdf_files(const char* const* input_paths, int32_t input_count, const char* output_path);
    int32_t mp_split_pdf_to_pages(const char* pdf_path, const char* output_dir);
    int32_t mp_copy_pages(const char* pdf_path, const char* output_path, const int32_t* page_numbers, int32_t page_count);

    // Validation and repair
    int32_t mp_is_valid_pdf(const char* pdf_path);
    int32_t mp_repair_damaged_pdf(const char* pdf_path, const char* output_path);

    // Memory management for convenience functions
    void mp_free_bytes(uint8_t* data, size_t len);
""")

# =============================================================================
# Constants
# =============================================================================

FZ_STORE_DEFAULT = 256 * 1024 * 1024  # 256 MB

# =============================================================================
# Library Loading
# =============================================================================

class MockLib:
    """Mock library that raises errors when functions are called."""

    def __getattr__(self, name: str):
        def mock_func(*args, **kwargs):
            raise RuntimeError(
                f"Function '{name}' requires native library. "
                "Please install micropdf with native bindings or set MICROPDF_LIB_PATH."
            )
        return mock_func


def _load_ffi_library() -> object:
    """Load the FFI library, returning MockLib if not available."""
    lib_path = get_library_path()

    if lib_path is not None:
        try:
            return ffi.dlopen(str(lib_path))
        except OSError:
            pass

    return MockLib()


# Load library at module import
lib = _load_ffi_library()


def is_native_available() -> bool:
    """Check if the native library is available."""
    return not isinstance(lib, MockLib)


def reload_library() -> bool:
    """Reload the native library. Returns True if successful."""
    global lib, _library_path
    _library_path = None
    lib = _load_ffi_library()
    return is_native_available()


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # FFI objects
    "ffi",
    "lib",
    # Constants
    "FZ_STORE_DEFAULT",
    # Platform functions
    "get_platform_info",
    "get_lib_name",
    # Library functions
    "find_library",
    "download_library",
    "load_library",
    "get_library_path",
    "is_native_available",
    "reload_library",
    # Classes
    "MockLib",
]
