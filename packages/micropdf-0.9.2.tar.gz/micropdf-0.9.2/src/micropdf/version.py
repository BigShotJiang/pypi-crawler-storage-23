"""Version information for MicroPDF Python bindings."""

__version__ = "0.9.2"

