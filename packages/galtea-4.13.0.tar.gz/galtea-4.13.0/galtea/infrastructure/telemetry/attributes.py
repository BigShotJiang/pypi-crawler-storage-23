"""
OpenTelemetry attribute constants for Galtea.

This module defines the attribute namespaces and keys used for span attributes.
See: https://docs.galtea.ai/concepts/product/version/session/trace#trace-types
"""

# Attribute namespaces
GALTEA_NAMESPACE = "galtea"

# Galtea entity attributes (used for Galtea API export)
# Session entity
GALTEA_ATTR_SESSION_ID = f"{GALTEA_NAMESPACE}.session.id"

# InferenceResult entity
GALTEA_ATTR_INFERENCE_RESULT_ID = f"{GALTEA_NAMESPACE}.inference_result.id"

# Trace entity attributes (maps to TraceBase fields in domain/models/trace.py)
GALTEA_ATTR_TRACE_TYPE = f"{GALTEA_NAMESPACE}.trace.type"
GALTEA_ATTR_TRACE_DESCRIPTION = f"{GALTEA_NAMESPACE}.trace.description"  # maps to description (from docstring)
GALTEA_ATTR_TRACE_INPUT = f"{GALTEA_NAMESPACE}.trace.input"  # maps to input_data
GALTEA_ATTR_TRACE_OUTPUT = f"{GALTEA_NAMESPACE}.trace.output"  # maps to output_data
GALTEA_ATTR_TRACE_ERROR = f"{GALTEA_NAMESPACE}.trace.error"
GALTEA_ATTR_TRACE_LATENCY_MS = f"{GALTEA_NAMESPACE}.trace.latency_ms"
GALTEA_ATTR_TRACE_METADATA = f"{GALTEA_NAMESPACE}.trace.metadata"
GALTEA_ATTR_TRACE_PARENT_ID = f"{GALTEA_NAMESPACE}.trace.parent_id"  # maps to parent_trace_id

# Version entity
GALTEA_ATTR_VERSION_ID = f"{GALTEA_NAMESPACE}.version.id"

# TestCase entity
GALTEA_ATTR_TEST_CASE_ID = f"{GALTEA_NAMESPACE}.test_case.id"
