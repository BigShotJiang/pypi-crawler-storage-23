"""
OpenTelemetry span processors for Galtea SDK.

This module provides custom span processors that export traces to Galtea API.
"""

from galtea.infrastructure.telemetry.processors.galtea_processor import GalteaSpanProcessor

__all__ = [
    "GalteaSpanProcessor",
]
