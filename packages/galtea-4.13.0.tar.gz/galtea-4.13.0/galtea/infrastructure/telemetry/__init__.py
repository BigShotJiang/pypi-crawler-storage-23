"""
OpenTelemetry-based telemetry infrastructure for Galtea SDK.

This module provides the core OpenTelemetry infrastructure for tracing,
including custom span processors for exporting to Galtea.
"""

from galtea.infrastructure.telemetry.attributes import (
    GALTEA_ATTR_INFERENCE_RESULT_ID,
    GALTEA_ATTR_SESSION_ID,
    GALTEA_ATTR_TRACE_ERROR,
    GALTEA_ATTR_TRACE_INPUT,
    GALTEA_ATTR_TRACE_LATENCY_MS,
    GALTEA_ATTR_TRACE_METADATA,
    GALTEA_ATTR_TRACE_OUTPUT,
    GALTEA_ATTR_TRACE_PARENT_ID,
    GALTEA_ATTR_TRACE_TYPE,
    GALTEA_NAMESPACE,
)
from galtea.infrastructure.telemetry.provider import (
    TelemetryConfig,
    get_tracer,
    initialize_telemetry,
    shutdown_telemetry,
)

__all__ = [
    "GALTEA_ATTR_INFERENCE_RESULT_ID",
    "GALTEA_ATTR_SESSION_ID",
    "GALTEA_ATTR_TRACE_ERROR",
    "GALTEA_ATTR_TRACE_INPUT",
    "GALTEA_ATTR_TRACE_LATENCY_MS",
    "GALTEA_ATTR_TRACE_METADATA",
    "GALTEA_ATTR_TRACE_OUTPUT",
    "GALTEA_ATTR_TRACE_PARENT_ID",
    "GALTEA_ATTR_TRACE_TYPE",
    "GALTEA_NAMESPACE",
    "TelemetryConfig",
    "get_tracer",
    "initialize_telemetry",
    "shutdown_telemetry",
]
