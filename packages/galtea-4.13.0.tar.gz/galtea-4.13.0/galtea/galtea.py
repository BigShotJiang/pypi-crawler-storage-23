import logging
import warnings
from typing import Final

from galtea.application.services.conversation_simulator_service import ConversationSimulatorService
from galtea.application.services.evaluation_service import EvaluationService
from galtea.application.services.evaluation_task_service import EvaluationTaskService
from galtea.application.services.inference_result_service import InferenceResultService
from galtea.application.services.metric_service import MetricService
from galtea.application.services.metric_type_service import MetricTypeService
from galtea.application.services.product_service import ProductService
from galtea.application.services.session_service import SessionService
from galtea.application.services.simulator_service import SimulatorService
from galtea.application.services.specification_service import SpecificationService
from galtea.application.services.test_case_service import TestCaseService
from galtea.application.services.test_service import TestService
from galtea.application.services.trace_service import TraceService
from galtea.application.services.version_service import VersionService
from galtea.infrastructure.clients.http_client import Client
from galtea.infrastructure.telemetry.provider import TelemetryConfig, initialize_telemetry, shutdown_telemetry
from galtea.utils.validate_installed_version import validate_installed_version

_logger = logging.getLogger(__name__)


class Galtea:
    def __init__(
        self,
        api_key: str,
        suppress_updatable_version_message: bool = False,
    ):
        """Initialize the Galtea SDK with the provided API key.

        Args:
            api_key: The API key to access the Galtea platform for authentication.
            suppress_updatable_version_message: If True, suppresses the message about a newer version available.
        """
        self.__client: Final = Client(api_key)

        # Initialize OpenTelemetry-based telemetry
        telemetry_config = TelemetryConfig(
            http_client=self.__client,
            service_name="galtea-sdk",
        )
        self._tracer_provider = initialize_telemetry(telemetry_config)
        _logger.debug("Telemetry initialized")
        self.products: Final = ProductService(self.__client)
        self.tests: Final = TestService(self.__client, self.products)
        self.test_cases: Final = TestCaseService(self.__client, self.tests)
        self.versions: Final = VersionService(self.__client, self.products)
        self.metrics: Final = MetricService(self.__client)
        self.specifications: Final = SpecificationService(self.__client)
        self.sessions: Final = SessionService(self.__client, self.test_cases, self.tests, self.versions)
        self.traces: Final = TraceService(self.__client)
        self.inference_results: Final = InferenceResultService(
            self.__client,
            self.sessions,
            self.tests,
            self.test_cases,
            self.traces,
        )
        self.evaluations: Final = EvaluationService(
            self.__client,
            self.metrics,
            self.sessions,
            self.test_cases,
            self.tests,
            self.versions,
            self.inference_results,
        )
        self.conversation_simulator: Final = ConversationSimulatorService(self.__client)
        self.simulator: Final = SimulatorService(
            self.sessions,
            self.test_cases,
            self.inference_results,
            self.conversation_simulator,
        )

        # DEPRECATED: Use `self.metrics` instead.
        self.__metric_types: MetricTypeService = MetricTypeService(self.__client)
        # DEPRECATED: Use `self.evaluations` instead.
        self.__evaluation_tasks: EvaluationTaskService = EvaluationTaskService(
            self.__client,
            self.evaluations,
            self.__metric_types,
            self.sessions,
            self.test_cases,
        )

        # Validate that the installed version of the SDK is compatible with the API
        validate_installed_version(self.__client, suppress_updatable_version_message)

    @property
    def metric_types(self) -> MetricTypeService:
        warnings.warn(
            (
                "galtea.metric_types is deprecated and will be removed in a future release.\n"
                "Use galtea.metrics API instead."
            ),
            DeprecationWarning,
            stacklevel=2,
        )
        return self.__metric_types

    @metric_types.setter
    def metric_types(self, value: MetricTypeService) -> None:
        warnings.warn(
            (
                "galtea.metric_types is deprecated and will be removed in a future release.\n"
                "Use galtea.metrics API instead."
            ),
            DeprecationWarning,
            stacklevel=2,
        )
        self.__metric_types = value

    @property
    def evaluation_tasks(self) -> EvaluationTaskService:
        warnings.warn(
            (
                "galtea.evaluation_tasks is deprecated and will be removed in a future release.\n"
                "Use galtea.evaluations API instead."
            ),
            DeprecationWarning,
            stacklevel=2,
        )
        return self.__evaluation_tasks

    @evaluation_tasks.setter
    def evaluation_tasks(self, value: EvaluationTaskService) -> None:
        warnings.warn(
            (
                "galtea.evaluation_tasks is deprecated and will be removed in a future release.\n"
                "Use galtea.evaluations API instead."
            ),
            DeprecationWarning,
            stacklevel=2,
        )
        self.__evaluation_tasks = value

    def shutdown(self) -> None:
        """Shutdown the Galtea client and flush pending telemetry.

        This method should be called when the application is shutting down
        to ensure all pending traces are exported.
        """
        shutdown_telemetry()
        _logger.debug("Galtea client shutdown complete")

    def __enter__(self) -> "Galtea":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit - ensures telemetry is flushed."""
        self.shutdown()
