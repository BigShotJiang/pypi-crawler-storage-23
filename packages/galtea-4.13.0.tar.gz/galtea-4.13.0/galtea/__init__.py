from galtea.application.services.evaluation_service import MetricInput
from galtea.domain.models.evaluation import Evaluation, EvaluationStatus
from galtea.domain.models.generate_next_turn import GenerateNextTurnRequest, GenerateNextTurnResponse
from galtea.domain.models.inference_result import (
    CostInfoProperties,
    InferenceResult,
    InferenceResultStatus,
    InferenceResultUpdate,
    UsageInfoProperties,
)
from galtea.domain.models.metric import Metric
from galtea.domain.models.product import OperatorType, Product, RiskLevel
from galtea.domain.models.session import Session
from galtea.domain.models.specification import Specification, SpecificationBase, SpecificationType
from galtea.domain.models.test import Test
from galtea.domain.models.test_case import TestCase
from galtea.domain.models.trace import NodeType, Trace, TraceBase, TraceType
from galtea.domain.models.version import Version
from galtea.galtea import Galtea
from galtea.infrastructure.telemetry.processors.galtea_processor import GalteaSpanProcessor
from galtea.utils.agent import (
    Agent,
    AgentCallable,
    AgentInput,
    AgentResponse,
    AgentType,
    AsyncAgentCallable,
    AsyncStructuredAgentCallable,
    ChatHistory,
    ChatMessage,
    ConversationMessage,
    StructuredAgentCallable,
    SyncAgentCallable,
    SyncStructuredAgentCallable,
)
from galtea.utils.agent_executor import execute_agent, is_async_callable
from galtea.utils.custom_score_metric import CustomScoreEvaluationMetric
from galtea.utils.test_type import TestType
from galtea.utils.tracing import (
    GalteaSpan,
    clear_context,
    get_inference_result_id,
    get_session_id,
    set_context,
    start_trace,
    trace,
)

__all__ = [
    "Agent",
    "AgentCallable",
    "AgentInput",
    "AgentResponse",
    "AgentType",
    "AsyncAgentCallable",
    "AsyncStructuredAgentCallable",
    "ChatHistory",
    "ChatMessage",
    "ConversationMessage",
    "CostInfoProperties",
    "CustomScoreEvaluationMetric",
    "Evaluation",
    "EvaluationStatus",
    "Galtea",
    "GalteaSpan",
    "GalteaSpanProcessor",
    "GenerateNextTurnRequest",
    "GenerateNextTurnResponse",
    "InferenceResult",
    "InferenceResultStatus",
    "InferenceResultUpdate",
    "Metric",
    "MetricInput",
    "NodeType",  # Deprecated, use TraceType instead. Will be removed in a future version.
    "OperatorType",
    "Product",
    "RiskLevel",
    "Session",
    "Specification",
    "SpecificationBase",
    "SpecificationType",
    "StructuredAgentCallable",
    "SyncAgentCallable",
    "SyncStructuredAgentCallable",
    "Test",
    "TestCase",
    "TestType",
    "Trace",
    "TraceBase",
    "TraceType",
    "UsageInfoProperties",
    "Version",
    "clear_context",
    "execute_agent",
    "get_inference_result_id",
    "get_session_id",
    "is_async_callable",
    "set_context",
    "start_trace",
    "trace",
]
