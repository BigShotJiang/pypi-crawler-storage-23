from enum import Enum
from typing import List, Optional

from galtea.utils.from_camel_case_base_model import FromCamelCaseBaseModel


class SpecificationType(str, Enum):
    """
    The type of specification that classifies the kind of behavioral expectation.

    Attributes:
        CAPABILITY: A core function the product can perform — what the product is
            designed to accomplish or deliver.
        INABILITY: An action or task the product is fundamentally unable to do even
            if a malicious actor gained full control over it.
        POLICY: A mandatory rule or guideline the product must follow — from
            restrictions to behavioral guidelines.
    """

    CAPABILITY = "CAPABILITY"
    INABILITY = "INABILITY"
    POLICY = "POLICY"


class SpecificationBase(FromCamelCaseBaseModel):
    product_id: str
    description: str
    type: SpecificationType
    test_type: Optional[str] = None
    test_variant: Optional[str] = None
    metric_ids: Optional[List[str]] = None


class Specification(SpecificationBase):
    id: str
    created_at: str
    deleted_at: Optional[str] = None
