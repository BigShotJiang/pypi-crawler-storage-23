from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .block import Block


@dataclass
class ChatInfo:
    chat_name: str
    description: str = ""
    created_at: Optional[str] = None
    last_activity_at: Optional[str] = None
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    total_cost_usd: float = 0.0
    device: str = "cpu"

    @classmethod
    def from_dict(cls, data: dict) -> ChatInfo:
        return cls(
            chat_name=data.get("chat_name", ""),
            description=data.get("description", ""),
            created_at=data.get("created_at"),
            last_activity_at=data.get("last_activity_at"),
            total_input_tokens=data.get("total_input_tokens", 0),
            total_output_tokens=data.get("total_output_tokens", 0),
            total_cost_usd=data.get("total_cost_usd", 0.0),
            device=data.get("device", "cpu"),
        )


@dataclass
class ChatStatus:
    chat_name: str
    is_running: bool
    task_id: Optional[str] = None
    status: Optional[str] = None

    @classmethod
    def from_task(cls, chat_name: str, task: Optional[dict]) -> ChatStatus:
        if task is None:
            return cls(chat_name=chat_name, is_running=False)
        return cls(
            chat_name=chat_name,
            is_running=task.get("status") == "running",
            task_id=task.get("task_id"),
            status=task.get("status"),
        )


@dataclass
class ChatPollResult:
    chat_name: str
    is_running: bool
    task_id: Optional[str] = None
    status: Optional[str] = None
    total_blocks: int = 0
    tail_blocks: list[Block] = field(default_factory=list)
