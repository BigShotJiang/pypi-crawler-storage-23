from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class UploadResult:
    filename: str
    status: str
    storage_key: Optional[str] = None
    format_type: Optional[str] = None
    error: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> UploadResult:
        return cls(
            filename=data.get("filename", ""),
            status=data.get("status", ""),
            storage_key=data.get("storage_key"),
            format_type=data.get("format_type"),
            error=data.get("error"),
        )


@dataclass
class UploadResponse:
    success: bool
    message: str
    project: Optional[str] = None
    folder: Optional[str] = None
    total_files: int = 0
    completed: int = 0
    failed: int = 0
    results: list[UploadResult] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> UploadResponse:
        return cls(
            success=data.get("success", False),
            message=data.get("message", ""),
            project=data.get("job_name"),
            folder=data.get("folder"),
            total_files=data.get("total_files", 0),
            completed=data.get("completed", 0),
            failed=data.get("failed", 0),
            results=[UploadResult.from_dict(r) for r in data.get("results", [])],
        )


@dataclass
class FileInfo:
    file_name: str
    folder: Optional[str] = None
    storage_key: Optional[str] = None
    format_type: Optional[str] = None
    parent_file_name: Optional[str] = None
    created_at: Optional[str] = None
    metadata: Optional[dict] = None
    alias: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> FileInfo:
        return cls(
            file_name=data.get("file_name", ""),
            folder=data.get("folder"),
            storage_key=data.get("storage_key"),
            format_type=data.get("format_type"),
            parent_file_name=data.get("parent_file_name"),
            created_at=data.get("created_at"),
            metadata=data.get("metadata"),
            alias=data.get("alias"),
        )


@dataclass
class FileUrl:
    file_name: str
    url: str
    expires_in: int = 3600

    @classmethod
    def from_dict(cls, data: dict) -> FileUrl:
        return cls(
            file_name=data.get("file_name", ""),
            url=data.get("url", ""),
            expires_in=data.get("expires_in", 3600),
        )
