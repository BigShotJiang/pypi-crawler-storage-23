from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class WorkspaceFile:
    name: str
    location: str
    folder: str = ""
    size: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> WorkspaceFile:
        return cls(
            name=data.get("name", ""),
            location=data.get("location", data.get("file_location", "")),
            folder=data.get("folder", ""),
            size=data.get("size", 0),
        )


@dataclass
class FileContent:
    location: str
    content: str
    size: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> FileContent:
        return cls(
            location=data.get("file_location", data.get("location", "")),
            content=data.get("content", ""),
            size=data.get("size", 0),
        )
