from __future__ import annotations

from typing import Literal, Optional

Environment = Optional[Literal["accelerated_cpu", "accelerated_gpu"]]

_DEFAULT_BASE_URL = "https://agentsapi.litefold.ai"
_ACCELERATED_CPU_URL = "https://anindyadeep--litefold-backend-litefoldbackend-api.modal.run"
_ACCELERATED_GPU_URL = "https://anindyadeep--litefold-backend-gpu-litefoldgpubackend-api.modal.run"


def resolve_rosalind_url(environment: Environment) -> Optional[str]:
    if environment == "accelerated_cpu":
        return _ACCELERATED_CPU_URL
    if environment == "accelerated_gpu":
        return _ACCELERATED_GPU_URL
    return None


def resolve_platform_url(environment: Environment) -> Optional[str]:
    if environment in ("accelerated_cpu", "accelerated_gpu"):
        return _ACCELERATED_CPU_URL
    return None
