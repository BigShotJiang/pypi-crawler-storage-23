from __future__ import annotations

from .._http import HttpClient
from .._environment import Environment, resolve_platform_url
from ..models.structure import (
    StructureJobSubmission,
    StructureJob,
    StructureJobStatus,
    StructurePredictionResult,
)


class StructureNamespace:
    def __init__(self, http: HttpClient):
        self._http = http

    def _url(self, environment: Environment) -> str | None:
        return resolve_platform_url(environment)

    def submit(
        self,
        project: str,
        job_name: str,
        file_names: list[str],
        environment: Environment = None,
    ) -> StructureJobSubmission:
        data = self._http.post("/structure/submit", json={
            "job_name": job_name,
            "file_names": file_names,
        }, base_url=self._url(environment))
        return StructureJobSubmission.from_dict(data)

    def list_jobs(self, project: str, environment: Environment = None) -> list[StructureJob]:
        data = self._http.get("/structure/jobs", base_url=self._url(environment))
        return [StructureJob.from_dict(j) for j in data.get("jobs", [])]

    def get_status(
        self, project: str, job_name: str, environment: Environment = None,
    ) -> StructureJobStatus:
        data = self._http.get(
            f"/structure/jobs/{job_name}/status", base_url=self._url(environment),
        )
        return StructureJobStatus.from_dict(data)

    def get_result(
        self,
        project: str,
        job_name: str,
        file_name: str,
        environment: Environment = None,
    ) -> StructurePredictionResult:
        data = self._http.get(
            f"/structure/jobs/{job_name}/files/{file_name}/result",
            base_url=self._url(environment),
        )
        return StructurePredictionResult.from_dict(data)
