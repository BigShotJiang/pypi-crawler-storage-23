from __future__ import annotations

from .._http import HttpClient
from .structure import StructureNamespace
from .docking import DockingNamespace
from .sbdd import SBDDNamespace
from .design import DesignNamespace


class LabNamespace:
    """LiteFold Lab — structure prediction, docking, SBDD, and protein design.

    Usage:
        client.lab.structure.submit(...)
        client.lab.docking.find_pockets(...)
        client.lab.docking.submit(...)
        client.lab.sbdd.submit(...)
        client.lab.design.validate_and_submit(...)
    """

    def __init__(self, http: HttpClient):
        self.structure = StructureNamespace(http)
        self.docking = DockingNamespace(http)
        self.sbdd = SBDDNamespace(http)
        self.design = DesignNamespace(http)
