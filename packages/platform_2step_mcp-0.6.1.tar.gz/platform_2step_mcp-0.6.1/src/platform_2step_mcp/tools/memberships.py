"""Membership tools for MCP."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from ..client import Platform2StepClient

MEMBERSHIP_TOOLS: list[Tool] = [
    Tool(
        name="list_memberships",
        description="List memberships for a company. Returns all memberships with their IDs, names, and details.",
        inputSchema={
            "type": "object",
            "properties": {
                "company_id": {
                    "type": "integer",
                    "description": "Company ID to list memberships for",
                },
                "client_ids": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "Client IDs to filter memberships (required by upstream API)",
                },
                "page": {
                    "type": "integer",
                    "description": "Page number (default 1)",
                },
                "per_page": {
                    "type": "integer",
                    "description": "Results per page (default 25, max 100)",
                },
            },
            "required": ["company_id", "client_ids"],
        },
    ),
    Tool(
        name="get_membership",
        description="Get details of a specific membership.",
        inputSchema={
            "type": "object",
            "properties": {
                "membership_id": {
                    "type": "integer",
                    "description": "Membership ID",
                },
                "date": {
                    "type": "string",
                    "format": "date",
                    "description": "Date for pricing (YYYY-MM-DD, optional)",
                },
            },
            "required": ["membership_id"],
        },
    ),
]


async def handle_membership_tool(
    name: str,
    arguments: dict[str, Any],
    client: Platform2StepClient,
) -> list[TextContent]:
    """Handle membership tool calls.

    Args:
        name: Tool name.
        arguments: Tool arguments.
        client: Platform2Step HTTP client.

    Returns:
        List of TextContent with the result.
    """
    if name == "list_memberships":
        result = await client.list_memberships(
            company_id=arguments["company_id"],
            client_ids=arguments["client_ids"],
            page=arguments.get("page", 1),
            per_page=arguments.get("per_page", 25),
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    elif name == "get_membership":
        result = await client.get_membership(
            membership_id=arguments["membership_id"],
            date=arguments.get("date"),
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    raise ValueError(f"Unknown membership tool: {name}")
