"""Tests for category tools."""

import pytest
import respx
from httpx import Response

from platform_2step_mcp.client import Platform2StepClient
from platform_2step_mcp.tools.categories import CATEGORY_TOOLS, handle_category_tool


class TestCategoryToolDefinitions:
    """Tests for category tool definitions."""

    def test_all_tools_defined(self):
        """Test that all expected tools are defined."""
        tool_names = [t.name for t in CATEGORY_TOOLS]
        assert "list_categories" in tool_names
        assert "list_services_by_category" in tool_names
        assert "get_category" in tool_names
        assert len(CATEGORY_TOOLS) == 3

    def test_list_categories_schema(self):
        """Test list_categories input schema."""
        tool = next(t for t in CATEGORY_TOOLS if t.name == "list_categories")
        schema = tool.inputSchema

        assert schema["type"] == "object"
        assert "company_id" in schema["properties"]
        assert schema["required"] == ["company_id"]


class TestListCategoriesHandler:
    """Tests for list_categories handler."""

    async def test_list_categories_returns_json(
        self,
        client: Platform2StepClient,
        mock_api: respx.MockRouter,
        sample_categories_response: dict,
    ):
        """Test that list_categories returns formatted JSON."""
        mock_api.get("/api/v1/categories").mock(
            return_value=Response(200, json=sample_categories_response)
        )

        result = await handle_category_tool(
            "list_categories", {"company_id": 1238}, client
        )

        assert len(result) == 1
        assert result[0].type == "text"
        assert "Cortes de Pelo" in result[0].text


class TestErrorHandling:
    """Tests for error handling in handlers."""

    async def test_unknown_tool_raises_error(
        self, client: Platform2StepClient, mock_api: respx.MockRouter
    ):
        """Test that unknown tool names raise ValueError."""
        with pytest.raises(ValueError, match="Unknown category tool"):
            await handle_category_tool("unknown_tool", {}, client)
