# Platform-2Step MCP

MCP server that enables AI agents (Claude, GPT, etc.) to interact with AgendaPro's Platform API safely through a human-in-the-loop confirmation system.

## Quick Start

```bash
# Install
uv pip install -e .

# Authenticate (one-time, interactive)
export PLATFORM_2STEPS_BFF_URL=https://ap-api.agendaprodev.com/platform-2steps-bff
platform-mcp-auth login

# Run server
platform-2step-mcp
```

## Claude Desktop Setup

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "platform-2step": {
      "command": "uvx",
      "args": ["platform-2step-mcp"],
      "env": {
        "PLATFORM_2STEPS_BFF_URL": "https://ap-api.agendaprodev.com/platform-2steps-bff"
      }
    }
  }
}
```

## Documentation

For comprehensive documentation including:
- Architecture overview and authentication flows
- All available MCP tools with parameters
- API endpoints and operation flows
- Security rules and limits
- Development and debugging

See **[CLAUDE.md](./CLAUDE.md)**.

For shared documentation across the Platform MCP ecosystem, see the megarepo's `docs/shared/` directory.

## License

MIT
