"""bicep-whatif-advisor: Azure What-If deployment analyzer using LLMs."""

__version__ = "3.5.4"
