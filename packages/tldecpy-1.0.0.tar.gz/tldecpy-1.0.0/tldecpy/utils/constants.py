"""
Physical constants and numerical tolerances.
"""

# Boltzmann constant in eV/K
KB_EV = 8.617333262e-5

# Numerical constraints
EPSILON = 1e-10
