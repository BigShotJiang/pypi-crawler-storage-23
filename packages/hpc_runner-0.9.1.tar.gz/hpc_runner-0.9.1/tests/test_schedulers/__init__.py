"""Tests for schedulers."""
