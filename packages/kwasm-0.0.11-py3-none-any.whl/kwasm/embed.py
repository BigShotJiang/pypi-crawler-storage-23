"""Embed kwasm GDS viewer in Jupyter notebooks."""

from __future__ import annotations

import base64
import gzip
import html
import tempfile
import warnings
from collections.abc import Iterable
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from IPython.display import HTML

CWD = Path(__file__).parent

_B64_DECODE_JS = (
    "Uint8Array.from(atob({var}), function(c) {{ return c.charCodeAt(0); }})"
)


def _embed_js(var_name: str, b64: str, window_attr: str) -> str:
    """Build a JS IIFE that decodes base64 data into a Blob URL."""
    decode = _B64_DECODE_JS.format(var=f"{var_name}B64")
    return (
        f"    (function() {{\n"
        f'        var {var_name}B64 = "{b64}";\n'
        f"        var {var_name}Bin = {decode};\n"
        f"        window.{window_attr} = "
        f"URL.createObjectURL(new Blob([{var_name}Bin]));\n"
        f"    }})();\n"
    )


def bundle(
    gds: str | Path,
    output: str | Path | None = None,
    lyp: str | Path | None = None,
    lyrdb: str | Path | None = None,
    netlist: str | Path | dict | None = None,
) -> Path:
    """Bundle a GDS layout into a single self-contained HTML file."""
    gds_path = Path(gds)
    if output is None:
        output = f"{gds_path.stem}.html"
    gds_bytes = gds_path.read_bytes()
    lyp_bytes = Path(lyp).read_bytes() if lyp is not None else None
    lyrdb_bytes = Path(lyrdb).read_bytes() if lyrdb is not None else None
    netlist_bytes = _netlist_to_bytes(netlist)
    html_str = _build_html(
        gds_bytes,
        tools=(
            "select",
            "move",
            "ruler",
            "clear-rulers",
            "fit-all",
            "reload",
            "top-ports",
            "instance-ports",
            "text",
            "theme",
        ),
        drop=True,
        layers=True,
        lyp_bytes=lyp_bytes,
        lyrdb_bytes=lyrdb_bytes,
        netlist_bytes=netlist_bytes,
    )
    # Update title with the GDS filename
    html_str = html_str.replace(
        "<title>kwasm - Layout Viewer</title>",
        f"<title>kwasm - {gds_path.stem}</title>",
    )
    out = Path(output)
    out.write_text(html_str)
    return out


def show(
    component_or_path: str | Path | object,
    height: int = 500,
    tools: Iterable[str] = (),
    *,
    drop: bool = False,
    layers: bool = True,
    lyp: str | Path | None = None,
    lyrdb: str | Path | None = None,
    netlist: str | Path | dict | None = None,
) -> HTML:
    """Display a GDS layout in a Jupyter notebook using kwasm.

    Args:
        component_or_path: A file path (str or Path) to a .gds file,
            or a gdsfactory Component (anything with a .write_gds() method).
        height: Height of the viewer in pixels.
        tools: iterable of toolbar tool names to show. Empty (default)
            hides the toolbar. Available names: select, move, ruler,
            clear-rulers, fit-all, reload, top-ports, instance-ports,
            text, theme.
        drop: Whether to enable drag & drop of GDS files. Defaults to False.
        layers: Whether to show the layer panel. Defaults to True.
        lyp: Optional path (str or Path) to a .lyp layer properties file.
        lyrdb: Optional path (str or Path) to a .lyrdb report database file.
        netlist: Optional path (str or Path) to a .pic.yml netlist file,
            or a dict (serialized to JSON for the WASM backend).

    Returns:
        IPython.display.HTML object for notebook rendering.

    """
    from IPython.display import HTML

    path = (
        Path(component_or_path) if isinstance(component_or_path, (str, Path)) else None
    )

    if path is not None:
        gds_bytes = path.read_bytes()
    else:
        # Duck-type: assume it has .write_gds()
        with tempfile.NamedTemporaryFile(suffix=".gds", delete=False) as f:
            tmp = Path(f.name)
        try:
            cast(Any, component_or_path).write_gds(tmp)
            gds_bytes = tmp.read_bytes()
        finally:
            tmp.unlink(missing_ok=True)

    if lyp is not None:
        lyp_bytes = Path(lyp).read_bytes()
    else:
        lyp_text = _get_active_lyp()
        lyp_bytes = lyp_text.encode() if lyp_text is not None else None
    lyrdb_bytes = Path(lyrdb).read_bytes() if lyrdb is not None else None
    netlist_bytes = _netlist_to_bytes(netlist)

    full_html = _build_html(
        gds_bytes,
        tools=tuple(tools),
        drop=drop,
        layers=layers,
        lyp_bytes=lyp_bytes,
        lyrdb_bytes=lyrdb_bytes,
        netlist_bytes=netlist_bytes,
    )
    escaped = html.escape(full_html, quote=True)

    iframe = (
        f'<iframe srcdoc="{escaped}" '
        f'width="100%" height="{height}" '
        f'style="border:none"></iframe>'
    )

    # IPython suggests IFrame, but IFrame only supports src (URLs),
    # not srcdoc (inline HTML). Suppress the warning.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        return HTML(iframe)


def _netlist_to_bytes(
    netlist: str | Path | dict | None,
) -> bytes | None:
    """Convert a netlist argument to bytes.

    Accepts a file path (str or Path) or a dict (serialized to JSON,
    which is valid YAML and parsed by the Rust backend).
    """
    if isinstance(netlist, dict):
        import json

        return json.dumps(netlist).encode()
    if netlist is not None:
        return Path(netlist).read_bytes()
    return None


def _read_artifacts() -> str:
    """Read the pre-built bundled HTML from dist/."""
    bundled = CWD / "kwasm-bundled.html"
    if not bundled.exists():
        msg = f"{bundled} not found. Run 'python build.py' first."
        raise FileNotFoundError(msg)
    return bundled.read_text()


def _build_html(
    gds_bytes: bytes,
    tools: tuple[str, ...] = (),
    *,
    drop: bool = False,
    layers: bool = True,
    lyp_bytes: bytes | None = None,
    lyrdb_bytes: bytes | None = None,
    netlist_bytes: bytes | None = None,
) -> str:
    """Build a self-contained HTML string with embedded GDS."""
    result = _read_artifacts()
    gds_b64 = base64.b64encode(gzip.compress(gds_bytes)).decode("ascii")

    # Build data script with embedded GDS (+ optional LYP/LYRDB/netlist)
    data_js = "    // --- Embedded GDS layout (base64 -> Blob URL) ---\n" + _embed_js(
        "gds", gds_b64, "_embeddedLayoutUrl"
    )

    if lyp_bytes is not None:
        lyp_b64 = base64.b64encode(lyp_bytes).decode("ascii")
        data_js += "\n    // --- Embedded LYP layer properties ---\n" + _embed_js(
            "lyp", lyp_b64, "_kwasmLypUrl"
        )

    if lyrdb_bytes is not None:
        lyrdb_b64 = base64.b64encode(lyrdb_bytes).decode("ascii")
        data_js += "\n    // --- Embedded LYRDB report database ---\n" + _embed_js(
            "lyrdb", lyrdb_b64, "_kwasmLyrdbUrl"
        )

    if netlist_bytes is not None:
        netlist_b64 = base64.b64encode(netlist_bytes).decode("ascii")
        data_js += "\n    // --- Embedded netlist YAML ---\n" + _embed_js(
            "netlist", netlist_b64, "_kwasmNetlistUrl"
        )

    # Inject overrides for the in-page JS to pick up
    drop_js = "window._kwasmDropDisabled = true;" if not drop else ""
    layers_js = "window._kwasmLayersDisabled = true;" if not layers else ""
    tools_value = ",".join(tools)
    override_js = (
        "Object.defineProperty(window, '_kwasmToolsOverride', "
        f"{{value: '{tools_value}'}});"
        f"{drop_js}"
        f"{layers_js}"
    )

    injected = f"<script>\n    {override_js}\n{data_js}</script>\n"

    result = result.replace("<script>", injected + "<script>", 1)

    return result


def _get_active_lyp() -> str | None:
    import gdsfactory as gf

    try:
        pdk = gf.get_active_pdk()
    except Exception:  # noqa: BLE001
        return None

    layer_views = pdk.layer_views
    if layer_views is None:
        return None

    if isinstance(layer_views, str | Path):
        try:
            return Path(layer_views).read_text()
        except Exception:  # noqa: BLE001
            return None

    with tempfile.NamedTemporaryFile(suffix=".lyp", delete=False) as f:
        layer_props = Path(f.name).resolve()
        try:
            layer_views.to_lyp(filepath=layer_props)
            return layer_props.read_text()
        except Exception:  # noqa: BLE001
            return None
        finally:
            layer_props.unlink(missing_ok=True)
