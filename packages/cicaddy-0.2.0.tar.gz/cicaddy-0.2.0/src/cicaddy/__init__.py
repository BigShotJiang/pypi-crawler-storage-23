"""Cicaddy - Platform-agnostic pipeline AI agent.

Provides a multi-step execution engine with MCP tool integration,
multi-provider AI support, and extensible agent architecture.
"""

__version__ = "0.1.0"
