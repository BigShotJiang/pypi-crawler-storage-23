"""Report generation modules for Cicaddy."""

from .html_formatter import HTMLReportFormatter

__all__ = [
    "HTMLReportFormatter",
]
