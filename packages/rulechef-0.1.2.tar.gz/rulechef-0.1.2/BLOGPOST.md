# RuleChef: Learn Rules From Examples, Corrections, and LLM Interactions

RuleChef turns labeled examples and corrections into fast, deterministic rules.
It's a practical bridge between expensive LLM calls and reliable production
pipelines: start with LLMs, learn the patterns, then run at rule speed.

---

## Why RuleChef?

Many teams start with LLMs for extraction or classification, then hit the same
wall:

- high cost per call
- latency variance
- hard‑to‑debug output drift
- difficult to enforce schemas

RuleChef lets you:

- learn rules from examples and corrections
- evaluate and refine rules automatically
- run the learned rules locally, fast and cheap
- keep the system grounded in explicit patterns you can inspect

---

## Core Concepts

**Task**
Define the input and output schemas for your task (extraction, NER,
classification, transformation).

**Examples & Corrections**
Examples are positive supervised data. Corrections are high‑signal feedback
that tells the learner exactly what went wrong.

**Rules**
Rules are learnable units (regex, code, or spaCy matcher/dependency patterns)
that map inputs to structured outputs.

**Coordinator**
Decides *when* to learn. The agentic coordinator can plan sampling strategies
based on buffer stats and failures.

---

## How It Works

```mermaid
flowchart TD
  A[Inputs + Examples] --> B[Rule Learner]
  B --> C[Ruleset]
  C --> D[Evaluation]
  D -->|Failures| B
  D -->|Good Enough| E[Persist Rules]
```

RuleChef's design centers on a buffer‑first learning flow:

1) **Buffer** collects examples, corrections, and observations.
2) **Coordinator** decides whether to trigger learning.
3) **Learner** synthesizes or patches rules using a prompt‑builder.
4) **Executor** runs rules locally with deterministic output.

The rules are persisted to disk and can be reused without re‑training.

---

## Key Features

### Schema‑Aware Rules With Pydantic

RuleChef accepts either a simple dict schema or a Pydantic model. With
Pydantic, it extracts valid label sets from `Literal` fields, validates
outputs at runtime, and generates readable schema fragments for prompts.

### Incremental Rule Patching

Instead of re‑synthesizing an entire ruleset on every iteration, RuleChef can
generate *patch rules* targeted at known failures, merge them into the existing
ruleset, and prune weak rules. This preserves stable behavior while fixing
specific errors.

### Agentic Coordinator

The agentic coordinator decides *when* to learn and *how* to sample based on
buffer composition, correction count, and recent failure signals. It analyzes
per-class metrics each iteration, focuses on weak classes, and stops early when
performance plateaus.

---

## A Minimal Quickstart

```python
from openai import OpenAI
from rulechef import RuleChef, Task

client = OpenAI(api_key="...")

task = Task(
    name="Q&A",
    description="Extract answer spans from text",
    input_schema={"question": "str", "context": "str"},
    output_schema={"spans": "List[Span]"},
    text_field="context",
)

chef = RuleChef(task, client)

chef.add_example(
    {"question": "When?", "context": "Built in 1991"},
    {"spans": [{"text": "1991", "start": 9, "end": 13}]},
)

chef.learn_rules()

result = chef.extract({"question": "When?", "context": "Renovated in 2033"})
print(result)
```

---

## Benchmark: Banking77 Intent Classification

To measure how well RuleChef performs on a real task, we benchmarked it on a
subset of the [Banking77](https://huggingface.co/datasets/legacy-datasets/banking77)
intent classification dataset -- 77 banking customer service intent classes with
~13K examples.

### Setup

- **5 classes** pinned: `beneficiary_not_allowed`, `card_arrival`,
  `disposable_card_limits`, `exchange_rate`, `pending_cash_withdrawal`
- **5-shot per class** (25 training examples total)
- **Dev set**: remaining ~660 unused training examples (for refinement)
- **Test set**: 200 held-out examples from the official test split (never seen during learning)
- **Regex-only** rules (no code, no spaCy)
- **Agentic coordinator** guiding 15 refinement iterations
- **Model**: Kimi K2 via Groq API

### Results on Held-Out Test Set

| Metric | Value |
|--------|-------|
| Accuracy (exact match) | **60.5%** |
| Micro Precision | **100%** |
| Micro Recall | 60.5% |
| Micro F1 | **75.4%** |
| Macro F1 | **71.7%** |
| Coverage | 60.5% (121/200) |
| Rules learned | 108 |
| Learning time | ~144s |
| Per-query latency | **0.19ms** |

### Per-Class Breakdown

| Class | Precision | Recall | F1 |
|-------|-----------|--------|-----|
| exchange_rate | 100% | 95% | 97% |
| pending_cash_withdrawal | 100% | 82% | 90% |
| card_arrival | 100% | 62% | 77% |
| disposable_card_limits | 100% | 40% | 57% |
| beneficiary_not_allowed | 100% | 22% | 37% |

### Sample Rules

Here are a few of the 108 regex rules RuleChef learned automatically:

```
exchange_rate_keywords       (?i)\bexchange\s+rates?\b
track_card_delivery          (?i)\b(?:track|delivery|status|arrival|come|received).*\bcard\b
cash_withdrawal_pending      (?i)\b(?:cash|withdrawal|atm).*\b(?:pending|still|waiting)\b
disposable_limit_keywords    (?i)\bdisposable\s+cards?\b(?=.*\b(?:maximum|limit|how many)\b)
beneficiary_ultra_broad      (?i)\bbeneficiar(?:y|ies)\b.*\b(?:not allowed|fail|denied|can't)\b
```

The full set of learned rules is saved in
[`benchmarks/results_banking77.json`](https://github.com/KRLabsOrg/rulechef/blob/main/benchmarks/results_banking77.json).

### Key Takeaways

1. **Precision is perfect** -- zero false positives across all classes. In
   production, wrong answers are worse than no answer, and rules never give
   a wrong answer.

2. **Recall scales with complexity**. Simple keyword patterns (`exchange_rate`
   at 95%) are easy; nuanced paraphrases (`beneficiary_not_allowed` at 22%)
   need more examples or refinement iterations.

3. **Zero runtime cost**. After learning, every query is a regex match -- no API
   calls, no tokens, no latency. At 0.19ms per query, you can process ~5K
   queries per second on a single CPU.

4. **The agentic coordinator matters**. Without it (simple heuristic coordinator,
   3 iterations), accuracy drops to ~49% and Macro F1 to ~60%. The coordinator's
   per-class guidance lifts Macro F1 from ~60% to 71.7%.

Reproduce with:
```bash
pip install rulechef[benchmark]
python benchmarks/benchmark_banking77.py \
    --classes beneficiary_not_allowed,card_arrival,disposable_card_limits,exchange_rate,pending_cash_withdrawal \
    --shots 5 --max-iterations 15 --agentic \
    --base-url https://api.groq.com/openai/v1 \
    --model moonshotai/kimi-k2-instruct-0905
```

---

## What Makes It Different

- **Rules from real data**: learn from your examples and corrections instead of
  hand‑coding patterns.
- **Transparent outputs**: rules are inspectable and editable.
- **Cost control**: rules replace repeated LLM inference.
- **Faster iteration**: patch rules to fix specific failures without retraining
  everything.

---

## Try It

RuleChef is open source and designed to be practical from day one.
If you're building extraction systems that need to scale, it's worth a look.

- Repository: https://github.com/KRLabsOrg/rulechef
- Documentation: https://krlabsorg.github.io/rulechef
