"""Cross-platform path management for the Ilum CLI.

Uses XDG Base Directory conventions on Linux/macOS and standard
Windows directories (``%APPDATA%`` / ``%LOCALAPPDATA%``) on Windows.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class IlumPaths:
    config_dir: Path
    data_dir: Path
    state_dir: Path
    cache_dir: Path

    @classmethod
    def default(cls) -> IlumPaths:
        if sys.platform == "win32":
            appdata = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
            localappdata = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
            return cls(
                config_dir=appdata / "ilum",
                data_dir=appdata / "ilum" / "data",
                state_dir=localappdata / "ilum" / "state",
                cache_dir=localappdata / "ilum" / "cache",
            )
        return cls(
            config_dir=Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "ilum",
            data_dir=Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
            / "ilum",
            state_dir=Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state"))
            / "ilum",
            cache_dir=Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / "ilum",
        )

    def all_dirs(self) -> list[Path]:
        """Return all managed directories."""
        return [self.config_dir, self.data_dir, self.state_dir, self.cache_dir]

    def ensure_dirs(self) -> None:
        for d in self.all_dirs():
            d.mkdir(parents=True, exist_ok=True)
