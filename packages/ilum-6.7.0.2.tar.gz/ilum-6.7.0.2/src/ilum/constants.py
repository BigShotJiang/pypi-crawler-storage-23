"""Shared constants for the Ilum CLI."""

from __future__ import annotations

# Chart repository
CHART_REPO_NAME: str = "ilum"
CHART_REPO_URL: str = "https://charts.ilum.cloud"

# Chart reference
DEFAULT_CHART_REF: str = f"{CHART_REPO_NAME}/ilum"

# Bundled chart location inside the API Docker image
BUNDLED_CHART_PATH: str = "/opt/ilum-chart"

# Defaults
DEFAULT_RELEASE_NAME: str = "ilum"
DEFAULT_NAMESPACE: str = "default"
HELM_TIMEOUT: str = "20m"

# Minimum tool versions (major, minor)
MIN_HELM_VERSION: tuple[int, int] = (3, 12)
MIN_KUBECTL_VERSION: tuple[int, int] = (1, 28)
MIN_DOCKER_VERSION: tuple[int, int] = (24, 0)

# Health-check endpoint mappings
HEALTH_ENDPOINTS: dict[str, str] = {
    "ilum-core": "/actuator/health",
    "airflow": "/health",
    "superset": "/health",
    "minio": "/minio/health/ready",
}

# Default NodePorts used by Ilum charts.
# Mapping: nodePort → (service description, Helm values override key)
DEFAULT_NODEPORTS: dict[int, tuple[str, str]] = {
    31777: ("ilum-ui", "ilum-ui.service.nodePort"),
}

# Access types
DEFAULT_ACCESS_TYPE: str = "nodeport"
VALID_ACCESS_TYPES: tuple[str, ...] = ("nodeport", "port-forward", "ingress")
DEFAULT_UI_SERVICE_PORT: int = 9777


def is_local_chart(chart: str) -> bool:
    """True if *chart* is a local filesystem path rather than a repo reference."""
    from pathlib import Path

    return chart.startswith(("/", "./", "../")) or Path(chart).is_dir()
