"""Cross-platform compatibility helpers."""

from __future__ import annotations

import sys
from typing import IO

if sys.platform == "win32":
    import msvcrt

    def lock_file(f: IO[str]) -> None:
        """Acquire an exclusive lock on *f* (Windows)."""
        msvcrt.locking(f.fileno(), msvcrt.LK_LOCK, 1)

    def unlock_file(f: IO[str]) -> None:
        """Release the lock on *f* (Windows)."""
        f.seek(0)
        msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)

else:
    import fcntl

    def lock_file(f: IO[str]) -> None:
        """Acquire an exclusive lock on *f* (Unix)."""
        fcntl.flock(f, fcntl.LOCK_EX)

    def unlock_file(f: IO[str]) -> None:
        """Release the lock on *f* (Unix)."""
        fcntl.flock(f, fcntl.LOCK_UN)
