"""Allow running as ``python -m ilum``."""

from ilum.cli.main import app

app()
