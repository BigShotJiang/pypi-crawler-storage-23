"""Entry point for ``ilum-api`` console script."""

from __future__ import annotations

import os


def main() -> None:
    """Start the Ilum API server via uvicorn."""
    import uvicorn

    host = os.environ.get("ILUM_API_HOST", "0.0.0.0")  # noqa: S104
    port = int(os.environ.get("ILUM_API_PORT", "8080"))

    uvicorn.run(
        "ilum.api.app:create_app",
        host=host,
        port=port,
        factory=True,
    )


if __name__ == "__main__":
    main()
