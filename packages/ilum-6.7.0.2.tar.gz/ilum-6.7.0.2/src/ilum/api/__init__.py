"""FastAPI REST layer for Ilum module management."""

from __future__ import annotations
