"""Structured error code registry for the Ilum CLI."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ErrorCode:
    """Describes a single error code."""

    code: str  # e.g. "ILUM-001"
    category: str  # "prerequisite" | "cluster" | "helm" | "config" | "module" | "values"
    title: str


ERROR_REGISTRY: dict[str, ErrorCode] = {
    "ILUM-001": ErrorCode("ILUM-001", "prerequisite", "Tool not found"),
    "ILUM-002": ErrorCode("ILUM-002", "prerequisite", "Tool version too old"),
    "ILUM-010": ErrorCode("ILUM-010", "cluster", "Cluster unreachable"),
    "ILUM-011": ErrorCode("ILUM-011", "cluster", "Namespace not found"),
    "ILUM-020": ErrorCode("ILUM-020", "helm", "Helm command failed"),
    "ILUM-021": ErrorCode("ILUM-021", "helm", "Helm timeout"),
    "ILUM-022": ErrorCode("ILUM-022", "helm", "Release stuck"),
    "ILUM-023": ErrorCode("ILUM-023", "helm", "Release not found"),
    "ILUM-024": ErrorCode("ILUM-024", "helm", "Release already exists"),
    "ILUM-030": ErrorCode("ILUM-030", "config", "Config file invalid"),
    "ILUM-031": ErrorCode("ILUM-031", "config", "Config key not found"),
    "ILUM-040": ErrorCode("ILUM-040", "module", "Unknown module"),
    "ILUM-041": ErrorCode("ILUM-041", "module", "Module conflict"),
    "ILUM-050": ErrorCode("ILUM-050", "values", "Values parse error"),
    "ILUM-051": ErrorCode("ILUM-051", "values", "Values drift detected"),
    "ILUM-060": ErrorCode("ILUM-060", "auth", "Unknown auth provider"),
    "ILUM-061": ErrorCode("ILUM-061", "auth", "Auth parameter missing"),
    "ILUM-062": ErrorCode("ILUM-062", "auth", "Auth configuration failed"),
    "ILUM-063": ErrorCode("ILUM-063", "auth", "Auth status detection failed"),
    "ILUM-070": ErrorCode("ILUM-070", "exec", "Exec failed / No pods found"),
    "ILUM-071": ErrorCode("ILUM-071", "events", "Events query failed"),
    "ILUM-072": ErrorCode("ILUM-072", "metrics", "Metrics unavailable"),
    "ILUM-073": ErrorCode("ILUM-073", "helm", "Rollback failed"),
}
