"""``ilum preset`` command group."""

from __future__ import annotations

import typer

import ilum.cli.output as output_mod
from ilum.core.presets import list_presets

preset_app = typer.Typer(help="Manage deployment presets.")


@preset_app.command("list")
def preset_list() -> None:
    """List available deployment presets."""
    console = output_mod.console
    presets = list_presets()

    from ilum.cli.formatters import CommandResult, OutputFormat, ResultFormatter

    fmt = OutputFormat(console.output_format)

    if fmt != OutputFormat.TABLE:
        data_list = [
            {
                "name": p.name,
                "description": p.description,
                "modules": list(p.modules),
                "module_count": len(p.modules),
            }
            for p in presets
        ]
        result = CommandResult(data=data_list, summary=f"{len(data_list)} presets")
        ResultFormatter().format(result, fmt, console)
        return

    rows = [[p.name, p.description, str(len(p.modules))] for p in presets]
    console.table(
        title="Deployment Presets",
        columns=["Name", "Description", "Modules"],
        rows=rows,
    )
