"""Root Typer application for the Ilum CLI."""

from __future__ import annotations

from importlib.metadata import version as pkg_version

import typer

from ilum.cli.access_cmd import access_app
from ilum.cli.airgap_cmd import airgap_app
from ilum.cli.auth_cmd import auth_app
from ilum.cli.cleanup_cmd import cleanup
from ilum.cli.cluster_cmd import cluster_app
from ilum.cli.config_cmd import config_app
from ilum.cli.connect_cmd import connect
from ilum.cli.deps_cmd import deps_app
from ilum.cli.diff_cmd import diff
from ilum.cli.doctor_cmd import doctor
from ilum.cli.exec_cmd import exec_cmd
from ilum.cli.history_cmd import history
from ilum.cli.init_cmd import init
from ilum.cli.install_cmd import install
from ilum.cli.logs_cmd import logs
from ilum.cli.module_cmd import module_app
from ilum.cli.preset_cmd import preset_app
from ilum.cli.quickstart_cmd import quickstart
from ilum.cli.rollback_cmd import rollback
from ilum.cli.status_cmd import status
from ilum.cli.top_cmd import top
from ilum.cli.uninstall_cmd import uninstall
from ilum.cli.upgrade_cmd import upgrade
from ilum.cli.values_cmd import values

app = typer.Typer(
    name="ilum",
    help="CLI installer and management tool for the Ilum Data Lakehouse platform.",
    invoke_without_command=True,
    rich_markup_mode="rich",
)

# ── Getting Started ──────────────────────────────────────────
app.command(rich_help_panel="Getting Started")(quickstart)
app.command(rich_help_panel="Getting Started")(init)
app.command(rich_help_panel="Getting Started")(connect)

# ── Deploy ───────────────────────────────────────────────────
app.command(rich_help_panel="Deploy")(install)
app.command(rich_help_panel="Deploy")(upgrade)
app.command(rich_help_panel="Deploy")(rollback)
app.command(rich_help_panel="Deploy")(uninstall)
app.command(rich_help_panel="Deploy")(cleanup)

# ── Observe ──────────────────────────────────────────────────
app.command(rich_help_panel="Observe")(status)
app.command(rich_help_panel="Observe")(doctor)
app.command(rich_help_panel="Observe")(logs)
app.command(rich_help_panel="Observe")(top)
app.command(name="exec", rich_help_panel="Observe")(exec_cmd)
app.command(rich_help_panel="Observe")(history)

# ── Configuration ────────────────────────────────────────────
app.command(rich_help_panel="Configuration")(values)
app.command(rich_help_panel="Configuration")(diff)
app.add_typer(module_app, name="module", help="Manage Ilum platform modules.", rich_help_panel="Configuration")
app.add_typer(preset_app, name="preset", help="Manage deployment presets.", rich_help_panel="Configuration")
app.add_typer(access_app, name="access", help="Access the Ilum UI via port-forward or ingress.", rich_help_panel="Configuration")
app.add_typer(auth_app, name="auth", help="Manage authentication and OAuth configuration.", rich_help_panel="Configuration")

# ── CLI & Environment ────────────────────────────────────────
app.add_typer(cluster_app, name="cluster", help="Manage local Kubernetes clusters.", rich_help_panel="CLI & Environment")
app.add_typer(config_app, name="config", help="Manage CLI configuration.", rich_help_panel="CLI & Environment")
app.add_typer(deps_app, name="deps", help="Manage CLI dependencies.", rich_help_panel="CLI & Environment")
app.add_typer(airgap_app, name="airgap", help="Air-gapped deployment tooling.", rich_help_panel="CLI & Environment")


def _version_callback(value: bool) -> None:
    if value:
        try:
            v = pkg_version("ilum")
        except Exception:
            v = "0.1.0-dev"
        typer.echo(f"ilum {v}")
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        help="Print version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose output."),
    output: str = typer.Option(
        "table",
        "--output",
        "-o",
        help="Output format: table, json, yaml, csv.",
    ),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress informational output."),
    no_headers: bool = typer.Option(
        False, "--no-headers", help="Omit column headers from table and CSV output."
    ),
    field_selector: str | None = typer.Option(
        None,
        "--field-selector",
        help="Comma-separated list of fields to include in output.",
    ),
) -> None:
    """Ilum CLI — installer and management tool for the Ilum Data Lakehouse."""
    import ilum.cli.output as output_mod

    if verbose:
        output_mod.console = output_mod.IlumConsole(verbose=True)

    output_mod.console.output_format = output
    output_mod.console.quiet = quiet
    output_mod.console.no_headers = no_headers
    if field_selector:
        output_mod.console.field_selector = [f.strip() for f in field_selector.split(",")]

    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)


if __name__ == "__main__":
    app()
