"""Shell completion functions for the Ilum CLI."""

from __future__ import annotations


def complete_module_names(incomplete: str) -> list[str]:
    """Return module names matching *incomplete* for shell completion."""
    from ilum.core.modules import ModuleResolver

    resolver = ModuleResolver()
    all_names = [m.name for m in resolver.all_modules()]
    if not incomplete:
        return all_names
    return [n for n in all_names if n.startswith(incomplete)]


def complete_profile_names(incomplete: str) -> list[str]:
    """Return profile names matching *incomplete* for shell completion."""
    try:
        from ilum.config.manager import ConfigManager
        from ilum.config.paths import IlumPaths

        paths = IlumPaths.default()
        mgr = ConfigManager(paths)
        config = mgr.load()
        all_names = list(config.profiles.keys())
    except Exception:
        return []

    if not incomplete:
        return all_names
    return [n for n in all_names if n.startswith(incomplete)]


def complete_check_names(incomplete: str) -> list[str]:
    """Return doctor check names matching *incomplete* for shell completion."""
    all_checks = [
        "helm",
        "kubectl",
        "docker",
        "helm-repo",
        "cluster",
        "namespace",
        "pods",
        "pvcs",
        "rbac",
        "release",
        "compatibility",
        "storage-class",
    ]
    if not incomplete:
        return all_checks
    return [n for n in all_checks if n.startswith(incomplete)]
