"""Ilum CLI — installer and management tool for the Ilum Data Lakehouse platform."""
