#!/usr/bin/env bash
# Ilum CLI Installer
# Usage: curl -fsSL https://get.ilum.cloud/cli | bash
#   or:  ILUM_VERSION=0.2.0 bash install.sh
set -euo pipefail

REPO="ilum-cloud/ilum-cli"
INSTALL_DIR="${ILUM_INSTALL_DIR:-/usr/local/bin}"
FALLBACK_DIR="${ILUM_FALLBACK_DIR:-${HOME}/.local/bin}"

# Colours (when stdout is a terminal)
if [ -t 1 ]; then
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[0;33m'
    BLUE='\033[0;34m'
    NC='\033[0m'
else
    RED='' GREEN='' YELLOW='' BLUE='' NC=''
fi

info()  { printf "${BLUE}==>${NC} %s\n" "$*"; }
ok()    { printf "${GREEN}==>${NC} %s\n" "$*"; }
warn()  { printf "${YELLOW}WARNING:${NC} %s\n" "$*"; }
err()   { printf "${RED}ERROR:${NC} %s\n" "$*" >&2; }
die()   { err "$@"; exit 1; }

# ---------------------------------------------------------------------------
# Parse arguments
# ---------------------------------------------------------------------------

NO_PATH_SETUP=0
CLI_VERSION=""

while [ $# -gt 0 ]; do
    case "$1" in
        --version)
            CLI_VERSION="$2"
            shift 2
            ;;
        --no-path)
            NO_PATH_SETUP=1
            shift
            ;;
        -h|--help)
            echo "Usage: install.sh [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --version <ver>  Install a specific version (e.g. 0.2.0)"
            echo "  --no-path        Skip PATH setup"
            echo "  -h, --help       Show this help"
            exit 0
            ;;
        *)
            err "Unknown argument: $1"
            exit 1
            ;;
    esac
done

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

fetch() {
    if command -v curl >/dev/null 2>&1; then
        curl -fsSL "$@"
    elif command -v wget >/dev/null 2>&1; then
        wget -qO- "$@"
    else
        die "Neither curl nor wget found. Please install one of them."
    fi
}

detect_platform() {
    OS=$(uname -s | tr '[:upper:]' '[:lower:]')
    ARCH=$(uname -m)
    case "$ARCH" in
        x86_64)         ARCH="amd64" ;;
        aarch64|arm64)  ARCH="arm64" ;;
        *)              die "Unsupported architecture: $ARCH" ;;
    esac

    case "$OS" in
        linux|darwin) ;;
        *)            die "Unsupported operating system: $OS" ;;
    esac

    PLATFORM="${OS}-${ARCH}"
    info "Detected platform: ${PLATFORM}"
}

check_explicit_version() {
    VERSION_EXPLICIT=false
    if [ -n "$CLI_VERSION" ]; then
        VERSION="$CLI_VERSION"
        VERSION_EXPLICIT=true
        info "Using version from --version flag: ${VERSION}"
        return
    fi

    if [ -n "${ILUM_VERSION:-}" ]; then
        VERSION="${ILUM_VERSION}"
        VERSION_EXPLICIT=true
        info "Using pinned version: ${VERSION}"
        return
    fi
    VERSION=""
}

resolve_version_from_github() {
    if [ -n "${VERSION:-}" ]; then
        return
    fi

    info "Querying latest release from GitHub..."
    VERSION=$(fetch "${ILUM_GITHUB_API:-https://api.github.com}/repos/${REPO}/releases/latest" \
        | grep '"tag_name"' \
        | sed -E 's/.*"tag_name": *"cli-v([^"]+)".*/\1/')

    if [ -z "${VERSION:-}" ]; then
        die "Could not determine latest version from GitHub. Try: pip install ilum, pipx install ilum, or set ILUM_VERSION manually."
    fi
    info "Latest version: ${VERSION}"
}

version_label() {
    if [ -n "${VERSION:-}" ]; then
        echo " ${VERSION}"
    fi
}

# ---------------------------------------------------------------------------
# Python version check
# ---------------------------------------------------------------------------

check_python_version() {
    local py_cmd=""
    if command -v python3 >/dev/null 2>&1; then
        py_cmd="python3"
    elif command -v python >/dev/null 2>&1; then
        py_cmd="python"
    else
        PYTHON_OK=0
        return
    fi

    local py_version
    py_version=$("$py_cmd" -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null) || {
        PYTHON_OK=0
        return
    }

    local major minor
    major="${py_version%%.*}"
    minor="${py_version#*.}"

    if [ "$major" -ge 3 ] 2>/dev/null && [ "$minor" -ge 11 ] 2>/dev/null; then
        PYTHON_OK=1
    else
        PYTHON_OK=0
        warn "Python ${py_version} found, but >= 3.11 is required for pip/pipx/uv install."
    fi
}

# ---------------------------------------------------------------------------
# Installation strategies (tiered fallback)
# ---------------------------------------------------------------------------

try_brew_install() {
    [ "$(uname -s)" = "Darwin" ] || return 1
    command -v brew >/dev/null 2>&1 || return 1
    info "Installing via Homebrew..."
    brew tap ilum-cloud/tap https://github.com/ilum-cloud/ilum 2>/dev/null
    brew install ilum && return 0
    warn "Homebrew install failed, trying next method..."
    return 1
}

try_pipx_install() {
    command -v pipx >/dev/null 2>&1 || return 1
    local pkg="ilum"
    [ "$VERSION_EXPLICIT" = true ] && pkg="ilum==${VERSION}"
    info "Installing via pipx..."
    pipx install "$pkg" && return 0
    warn "pipx install failed, trying next method..."
    return 1
}

try_uv_install() {
    command -v uv >/dev/null 2>&1 || return 1
    local pkg="ilum"
    [ "$VERSION_EXPLICIT" = true ] && pkg="ilum==${VERSION}"
    info "Installing via uv..."
    uv tool install "$pkg" && return 0
    warn "uv install failed, trying next method..."
    return 1
}

try_pip_install() {
    local pip_cmd=""
    if command -v pip3 >/dev/null 2>&1; then
        pip_cmd="pip3"
    elif command -v pip >/dev/null 2>&1; then
        pip_cmd="pip"
    else
        # Fall back to python -m pip
        local py_cmd=""
        if command -v python3 >/dev/null 2>&1; then
            py_cmd="python3"
        elif command -v python >/dev/null 2>&1; then
            py_cmd="python"
        fi
        [ -n "$py_cmd" ] && "$py_cmd" -m pip --version >/dev/null 2>&1 && pip_cmd="$py_cmd -m pip"
    fi
    [ -z "$pip_cmd" ] && return 1
    local pkg="ilum"
    [ "$VERSION_EXPLICIT" = true ] && pkg="ilum==${VERSION}"
    info "Installing via pip ($pip_cmd)..."
    $pip_cmd install "$pkg" && return 0
    warn "pip install failed, trying next method..."
    return 1
}

download_binary() {
    local tarball="ilum-${PLATFORM}.tar.gz"
    local base_url="${ILUM_DOWNLOAD_BASE:-https://github.com}/${REPO}/releases/download/cli-v${VERSION}"
    local tmpdir
    tmpdir=$(mktemp -d)
    trap "rm -rf '${tmpdir}'" EXIT

    info "Downloading ${tarball}..."
    fetch "${base_url}/${tarball}" > "${tmpdir}/${tarball}"
    fetch "${base_url}/SHA256SUMS"  > "${tmpdir}/SHA256SUMS"

    # Verify checksum
    info "Verifying checksum..."
    (cd "${tmpdir}" && grep "${tarball}" SHA256SUMS | sha256sum -c --quiet 2>/dev/null) || \
    (cd "${tmpdir}" && grep "${tarball}" SHA256SUMS | shasum -a 256 -c --quiet 2>/dev/null) || \
        die "Checksum verification failed!"
    ok "Checksum OK"

    # Extract
    tar -xzf "${tmpdir}/${tarball}" -C "${tmpdir}"

    # Install binary
    local target="${INSTALL_DIR}/ilum"
    if [ -w "${INSTALL_DIR}" ]; then
        mv "${tmpdir}/ilum" "${target}"
        chmod +x "${target}"
    elif command -v sudo >/dev/null 2>&1; then
        info "Installing to ${INSTALL_DIR} (requires sudo)..."
        sudo mv "${tmpdir}/ilum" "${target}"
        sudo chmod +x "${target}"
    else
        # Fallback to user directory
        mkdir -p "${FALLBACK_DIR}"
        target="${FALLBACK_DIR}/ilum"
        mv "${tmpdir}/ilum" "${target}"
        chmod +x "${target}"
        warn "${FALLBACK_DIR} may not be in your PATH."
        warn "Add it with: export PATH=\"${FALLBACK_DIR}:\$PATH\""
    fi

    ok "Installed ilum to ${target}"
}

# ---------------------------------------------------------------------------
# PATH setup
# ---------------------------------------------------------------------------

setup_path() {
    local install_dir="$1"

    if [ "$NO_PATH_SETUP" -eq 1 ]; then
        return
    fi

    # Check if already in PATH
    case ":$PATH:" in
        *":$install_dir:"*) return ;;
    esac

    local shell_name
    shell_name="$(basename "${SHELL:-/bin/bash}")"
    local rc_file=""

    case "$shell_name" in
        bash) rc_file="$HOME/.bashrc" ;;
        zsh)  rc_file="$HOME/.zshrc" ;;
        fish) rc_file="$HOME/.config/fish/config.fish" ;;
        *)    rc_file="" ;;
    esac

    if [ -z "$rc_file" ]; then
        warn "$install_dir is not in your PATH."
        info "Add it manually: export PATH=\"$install_dir:\$PATH\""
        return
    fi

    local path_line="export PATH=\"$install_dir:\$PATH\""
    if [ "$shell_name" = "fish" ]; then
        path_line="set -gx PATH $install_dir \$PATH"
    fi

    # Idempotency check
    if [ -f "$rc_file" ] && grep -qF "$install_dir" "$rc_file" 2>/dev/null; then
        info "$install_dir already in $rc_file"
        return
    fi

    info "Adding $install_dir to PATH in $rc_file"
    mkdir -p "$(dirname "$rc_file")"
    echo "" >> "$rc_file"
    echo "# Added by ilum CLI installer" >> "$rc_file"
    echo "$path_line" >> "$rc_file"
    ok "Updated $rc_file — restart your shell or run: source $rc_file"
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

verify_install() {
    if command -v ilum >/dev/null 2>&1; then
        local installed_version
        installed_version="$(ilum --version 2>&1 || true)"
        if [ -n "${VERSION:-}" ]; then
            if echo "$installed_version" | grep -q "$VERSION"; then
                ok "Verified: $installed_version"
            else
                warn "Version mismatch: expected $VERSION, got: $installed_version"
            fi
        else
            ok "Verified: $installed_version"
        fi
    else
        local shell_name rc_hint
        shell_name="$(basename "${SHELL:-/bin/bash}")"
        case "$shell_name" in
            bash) rc_hint="$HOME/.bashrc" ;;
            zsh)  rc_hint="$HOME/.zshrc" ;;
            fish) rc_hint="$HOME/.config/fish/config.fish" ;;
            *)    rc_hint="your shell rc file" ;;
        esac
        info "Run 'source $rc_hint' or restart your terminal, then run: ilum --version"
    fi
}

main() {
    info "Ilum CLI Installer"
    echo

    detect_platform
    check_explicit_version
    echo

    check_python_version

    # Tiered fallback: brew (macOS) → pipx → uv → pip → binary download
    if try_brew_install; then
        ok "Ilum CLI installed via Homebrew"
        return 0
    fi

    if [ "$PYTHON_OK" -eq 1 ]; then
        if try_pipx_install; then
            ok "Ilum CLI$(version_label) installed via pipx"
            return 0
        fi

        if try_uv_install; then
            ok "Ilum CLI$(version_label) installed via uv"
            return 0
        fi

        if try_pip_install; then
            ok "Ilum CLI$(version_label) installed via pip"
            info "Tip: run 'ilum' to get started, or 'python -m ilum' if not on PATH."
            return 0
        fi
    fi

    # Binary download requires a known version from GitHub
    resolve_version_from_github

    info "Falling back to binary download..."
    download_binary

    echo
    ok "Ilum CLI ${VERSION} installed successfully!"
    info "Run 'ilum init' to get started."

    # PATH setup
    setup_path "${INSTALL_DIR}"

    # Verify installation
    verify_install
}

main "$@"
