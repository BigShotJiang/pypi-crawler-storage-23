#!/bin/zsh

brew install uv
uv sync
source ./.venv/bin/activate
uv pip install -e '.[build]'
pyinstaller ilum.spec --distpath dist/arm64 --clean