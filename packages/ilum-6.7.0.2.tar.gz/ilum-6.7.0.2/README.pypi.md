# ilum CLI

Deploy and manage the [Ilum Data Lakehouse](https://ilum.cloud) platform on Kubernetes — from a single command.

![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue)

## What is ilum?

The ilum CLI wraps Helm and kubectl into a single tool purpose-built for the Ilum platform. It manages 32 modules with automatic dependency resolution, detects configuration drift between upgrades, and provides interactive wizards, health checks, and structured output — so you never have to hand-edit Helm values or chase dependency order again.

## Quickstart

### Install

**Linux / macOS**

```bash
curl -fsSL https://get.ilum.cloud/cli | bash
```

**Windows (PowerShell)**

```powershell
irm https://get.ilum.cloud/cli/windows | iex
```

**pip / pipx / uv**

```bash
pip install ilum        # or: pipx install ilum / uv tool install ilum
```

### Deploy

```bash
ilum quickstart
```

One command that:
- Checks prerequisites (Helm, kubectl, Docker)
- Detects an existing cluster or creates a local one (k3d/minikube/kind)
- Installs the Ilum platform with sensible defaults
- Shows deployment status when complete

Once running:

```bash
ilum status        # release info, pod readiness, enabled modules
ilum access open   # open the Ilum UI in your browser
```

### Step-by-step alternative

Prefer full control? Use the interactive wizard instead:

```bash
ilum init       # configure cluster, select modules, set options
ilum install    # deploy with your configuration
```

## Key Commands

| | Command | Description |
|-|---------|-------------|
| **Setup** | `ilum init` | Interactive setup wizard |
| | `ilum quickstart` | One-command install with defaults |
| | `ilum install` | Install the platform |
| | `ilum upgrade` | Upgrade an existing installation |
| | `ilum connect` | Attach to an existing Ilum release |
| **Operations** | `ilum status` | Release info, pod readiness, modules |
| | `ilum doctor` | Run 13 health checks |
| | `ilum logs <module>` | Stream pod logs |
| | `ilum exec <module>` | Shell into a pod |
| | `ilum top` | Resource usage per module |
| **Modules** | `ilum module enable <name>` | Enable a module (resolves deps) |
| | `ilum module disable <name>` | Disable a module |
| | `ilum module list` | List all 32 available modules |
| **Config** | `ilum values` | View live Helm values |
| | `ilum diff` | Compare values across sources |
| | `ilum rollback` | Roll back to a previous revision |
| | `ilum config` | Manage CLI configuration and profiles |
| | `ilum cleanup` | Tiered full-environment teardown |

## Modules

Ilum ships with 32 optional modules organized into 10 categories. When you enable a module, the CLI automatically resolves and enables its dependencies.

| Category | Modules |
|----------|---------|
| Core | core, ui, api, livy-proxy |
| Notebooks | jupyter, jupyterhub, zeppelin |
| SQL & Catalogs | sql (Kyuubi), trino, hive-metastore, nessie, unity-catalog |
| Orchestration | airflow, kestra, n8n, nifi, mageai |
| Analytics | superset, streamlit, marquez |
| AI & ML | mlflow, langfuse |
| Infrastructure | mongodb, kafka, postgresql, gitea, clickhouse |
| Storage | minio |
| Monitoring | monitoring (Prometheus + Grafana), loki, graphite |
| Security | openldap |

```bash
# Enable langfuse — automatically pulls in postgresql + clickhouse
ilum module enable langfuse
```

## Prerequisites

| Tool | Minimum Version | Notes |
|------|-----------------|-------|
| Helm | 3.12+ | Required |
| kubectl | 1.28+ | Required |
| Docker | 24.0+ | For local clusters only |

`ilum quickstart` and `ilum deps install` handle missing tools automatically.

## Documentation

Full documentation is available at [ilum.cloud/docs](https://ilum.cloud/docs).

## Links

- [ilum.cloud](https://ilum.cloud) — Platform homepage
- [Documentation](https://ilum.cloud/docs)
- [Issues](https://github.com/ilum-cloud/ilum-cli/issues)
