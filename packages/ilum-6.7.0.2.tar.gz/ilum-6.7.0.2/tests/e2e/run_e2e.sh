#!/usr/bin/env bash
# =============================================================================
# run_e2e.sh — Master E2E Test Orchestrator for ilum-cli
# =============================================================================
# Usage:
#   ./run_e2e.sh                 # Run all phases (0-14)
#   ./run_e2e.sh --phase 5       # Run single phase
#   ./run_e2e.sh --from 3        # Run from phase 3 onwards
#   ./run_e2e.sh --to 5          # Run phases 0-5
#   ./run_e2e.sh --from 3 --to 7 # Run phases 3-7
#   E2E_VERBOSE=1 ./run_e2e.sh   # Verbose logging
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source helpers
# shellcheck source=test_helpers.sh
source "$SCRIPT_DIR/test_helpers.sh"

# ---------------------------------------------------------------------------
# CLI Argument Parsing
# ---------------------------------------------------------------------------
PHASE_ONLY=""
FROM_PHASE=0
TO_PHASE=14

while [[ $# -gt 0 ]]; do
    case "$1" in
        --phase)
            PHASE_ONLY="$2"
            shift 2
            ;;
        --from)
            FROM_PHASE="$2"
            shift 2
            ;;
        --to)
            TO_PHASE="$2"
            shift 2
            ;;
        --verbose|-v)
            export E2E_VERBOSE=1
            shift
            ;;
        --help|-h)
            echo "Usage: $0 [--phase N] [--from N] [--to N] [--verbose]"
            echo ""
            echo "Phases:"
            echo "  0  Environment Validation"
            echo "  1  Read-Only Commands"
            echo "  2  Init & Config Init"
            echo "  3  Connect"
            echo "  4  Status/Info Commands"
            echo "  5  Module Enable/Disable"
            echo "  6  Upgrade & Configuration"
            echo "  7  Config Management Deep"
            echo "  8  Advanced Scenarios"
            echo "  9  Uninstall/Cleanup"
            echo "  10 Full Lifecycle Regression"
            echo "  11 Dependency Detection, Cluster Lifecycle & Quickstart"
            echo "  12 Multi-Provider Cluster Lifecycle (k3d, kind)"
            echo "  13 Preset Live Installs (development, data-engineering)"
            echo "  14 Multi-Module Enable/Disable Combinations"
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

# ---------------------------------------------------------------------------
# Phase runners
# ---------------------------------------------------------------------------

run_phase() {
    local phase_num="$1"
    local phase_script="$SCRIPT_DIR/phase_${phase_num}.sh"

    if [[ ! -f "$phase_script" ]]; then
        log_warn "Phase script not found: $phase_script — skipping"
        return 0
    fi

    # shellcheck source=/dev/null
    source "$phase_script"
}

should_run_phase() {
    local phase="$1"
    if [[ -n "$PHASE_ONLY" ]]; then
        [[ "$phase" == "$PHASE_ONLY" ]]
    else
        [[ "$phase" -ge "$FROM_PHASE" && "$phase" -le "$TO_PHASE" ]]
    fi
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

main() {
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  ilum-cli End-to-End Test Suite${NC}"
    echo -e "${CYAN}  $(date)${NC}"
    echo -e "${CYAN}  Results: $TEST_LOG_DIR${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo ""

    log_info "Starting E2E test suite"
    log_info "ILUM binary: $ILUM"
    log_info "Test results: $TEST_LOG_DIR"

    local phases=(0 1 2 3 4 5 6 7 8 9 10 11 12 13 14)

    for phase in "${phases[@]}"; do
        if should_run_phase "$phase"; then
            run_phase "$phase" || true
        fi
    done

    print_summary
}

main "$@"
