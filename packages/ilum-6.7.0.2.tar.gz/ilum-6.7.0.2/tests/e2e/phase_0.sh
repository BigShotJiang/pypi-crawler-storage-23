#!/usr/bin/env bash
# =============================================================================
# Phase 0: Environment Validation
# =============================================================================
# Verify all tools present, cluster running, deployment healthy.
# =============================================================================

print_phase "Phase 0: Environment Validation"

# P0-001: Docker is available
run_test "P0-001" "Docker is available" docker version
assert_exit_code 0 || true

# P0-002: kubectl is available
run_test "P0-002" "kubectl is available" kubectl version --client
assert_exit_code 0 || true

# P0-003: Helm is available
run_test "P0-003" "Helm is available" helm version
assert_exit_code 0 || true

# P0-004: Minikube is running
run_test "P0-004" "Minikube cluster is running" minikube status -p ilum-dev
assert_exit_code 0 || true

# P0-005: ilum CLI binary exists and runs
run_test "P0-005" "ilum CLI is available" "$ILUM" --version
assert_exit_code 0 || true

# P0-006: Helm release exists
run_test "P0-006" "Helm release 'ilum' exists" helm status "$HELM_RELEASE" -n "$HELM_NAMESPACE"
assert_exit_code 0 || true

# P0-007: Pods are running in default namespace
run_test "P0-007" "Pods exist in namespace" kubectl get pods -n "$HELM_NAMESPACE" --no-headers
assert_output_not_empty || true

# Backup existing config state
backup_config
log_info "Phase 0 complete — environment validated"
