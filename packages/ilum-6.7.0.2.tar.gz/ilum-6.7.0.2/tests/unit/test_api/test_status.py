"""Tests for status and health endpoints."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest
from fastapi.testclient import TestClient

from ilum.core.kubernetes import PodStatus
from ilum.core.release import ReleaseInfo


class TestHealth:
    def test_health_returns_200(self, api_client: TestClient) -> None:
        resp = api_client.get("/api/v1/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"

    def test_health_no_auth_required(self, api_client: TestClient) -> None:
        """Health endpoint should always be accessible."""
        resp = api_client.get("/api/v1/health")
        assert resp.status_code == 200

    def test_health_returns_release_name_not_namespace(
        self,
        api_client: TestClient,
        mock_api_manager: MagicMock,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """B1: Health should return the release name, not the namespace."""
        mock_api_manager.helm.namespace = "my-namespace"
        monkeypatch.setenv("ILUM_RELEASE_NAME", "my-release")
        resp = api_client.get("/api/v1/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["release"] == "my-release"
        assert data["namespace"] == "my-namespace"

    def test_health_release_defaults_to_ilum(
        self,
        api_client: TestClient,
        mock_api_manager: MagicMock,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """B1: When ILUM_RELEASE_NAME is not set, release defaults to 'ilum'."""
        mock_api_manager.helm.namespace = "default"
        monkeypatch.delenv("ILUM_RELEASE_NAME", raising=False)
        resp = api_client.get("/api/v1/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["release"] == "ilum"


class TestRelease:
    def test_get_release(
        self,
        api_client: TestClient,
        mock_api_manager: MagicMock,
        sample_release_info: ReleaseInfo,
    ) -> None:
        mock_api_manager.get_release_info.return_value = sample_release_info
        resp = api_client.get("/api/v1/release")
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "ilum"
        assert data["status"] == "deployed"
        assert data["chart_version"] == "6.7.0"
        assert data["revision"] == 3

    def test_get_release_not_found(
        self, api_client: TestClient, mock_api_manager: MagicMock
    ) -> None:
        from ilum.errors import ReleaseNotFoundError

        mock_api_manager.get_release_info.side_effect = ReleaseNotFoundError(
            "Release not found", error_code="ILUM-023"
        )
        resp = api_client.get("/api/v1/release")
        assert resp.status_code == 404
        data = resp.json()
        assert data["error_code"] == "ILUM-023"


class TestPods:
    def test_list_pods(
        self,
        api_client: TestClient,
        mock_api_manager: MagicMock,
        sample_pods: list[PodStatus],
    ) -> None:
        mock_api_manager.k8s.list_pods.return_value = sample_pods
        resp = api_client.get("/api/v1/pods")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 2
        assert data[0]["name"] == "ilum-core-0"
        assert data[0]["ready"] is True
        assert data[1]["restart_count"] == 1

    def test_list_pods_empty(self, api_client: TestClient, mock_api_manager: MagicMock) -> None:
        mock_api_manager.k8s.list_pods.return_value = []
        resp = api_client.get("/api/v1/pods")
        assert resp.status_code == 200
        assert resp.json() == []
