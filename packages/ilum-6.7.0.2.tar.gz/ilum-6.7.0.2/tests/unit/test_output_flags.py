"""Tests for --output and --quiet global flags."""

from __future__ import annotations

from ilum.cli.output import IlumConsole


class TestQuietMode:
    def test_quiet_suppresses_success(self, capsys) -> None:
        console = IlumConsole()
        console.quiet = True
        console.success("should not appear")
        captured = capsys.readouterr()
        assert "should not appear" not in captured.out

    def test_quiet_suppresses_info(self, capsys) -> None:
        console = IlumConsole()
        console.quiet = True
        console.info("should not appear")
        captured = capsys.readouterr()
        assert "should not appear" not in captured.out

    def test_quiet_suppresses_warning(self, capsys) -> None:
        console = IlumConsole()
        console.quiet = True
        console.warning("should not appear")
        captured = capsys.readouterr()
        assert "should not appear" not in captured.out

    def test_quiet_does_not_suppress_error(self, capsys) -> None:
        console = IlumConsole()
        console.quiet = True
        console.error("must appear")
        captured = capsys.readouterr()
        assert "must appear" in captured.err

    def test_not_quiet_by_default(self) -> None:
        console = IlumConsole()
        assert console.quiet is False

    def test_quiet_setter(self) -> None:
        console = IlumConsole()
        console.quiet = True
        assert console.quiet is True


class TestOutputFormat:
    def test_default_is_table(self) -> None:
        console = IlumConsole()
        assert console.output_format == "table"

    def test_output_format_setter(self) -> None:
        console = IlumConsole()
        console.output_format = "json"
        assert console.output_format == "json"


class TestMainCallback:
    def test_quiet_flag_sets_console(self) -> None:
        from typer.testing import CliRunner

        from ilum.cli.main import app

        runner = CliRunner()
        result = runner.invoke(app, ["--quiet", "--help"])
        # --help exits with 0, but the quiet flag should have been parsed
        assert result.exit_code == 0

    def test_output_flag_sets_console(self) -> None:
        from typer.testing import CliRunner

        from ilum.cli.main import app

        runner = CliRunner()
        result = runner.invoke(app, ["--output", "json", "--help"])
        assert result.exit_code == 0

    def test_output_short_flag(self) -> None:
        from typer.testing import CliRunner

        from ilum.cli.main import app

        runner = CliRunner()
        result = runner.invoke(app, ["-o", "yaml", "--help"])
        assert result.exit_code == 0

    def test_quiet_short_flag(self) -> None:
        from typer.testing import CliRunner

        from ilum.cli.main import app

        runner = CliRunner()
        result = runner.invoke(app, ["-q", "--help"])
        assert result.exit_code == 0
