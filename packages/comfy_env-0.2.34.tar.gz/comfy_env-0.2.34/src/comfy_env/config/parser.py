"""Configuration parsing for comfy-env."""

import copy
from pathlib import Path
from typing import Any, Dict, List, Optional

import tomli

from .types import ComfyEnvConfig, ComfyEnvOptions, NodeDependency, DEFAULT_HEALTH_CHECK_TIMEOUT

ROOT_CONFIG_FILE_NAME = "comfy-env-root.toml"  # Main node config
CONFIG_FILE_NAME = "comfy-env.toml"  # Isolated folder config


def load_config(path: Path) -> ComfyEnvConfig:
    """Load and parse config file."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path, "rb") as f:
        return parse_config(tomli.load(f))


def discover_config(node_dir: Path, root: bool = True) -> Optional[ComfyEnvConfig]:
    """Find and load config from directory. Checks root config first if root=True."""
    node_dir = Path(node_dir)
    if root:
        root_path = node_dir / ROOT_CONFIG_FILE_NAME
        if root_path.exists():
            return load_config(root_path)
    config_path = node_dir / CONFIG_FILE_NAME
    return load_config(config_path) if config_path.exists() else None


def parse_config(data: Dict[str, Any]) -> ComfyEnvConfig:
    """Parse TOML data into ComfyEnvConfig."""
    data = copy.deepcopy(data)

    python_version = data.pop("python", None)
    python_version = str(python_version) if python_version else None

    cuda_packages = _ensure_list(data.pop("cuda", {}).get("packages", []))
    apt_packages = _ensure_list(data.pop("apt", {}).get("packages", []))
    brew_packages = _ensure_list(data.pop("brew", {}).get("packages", []))
    env_vars = {str(k): str(v) for k, v in data.pop("env_vars", {}).items()}
    node_reqs = _parse_node_reqs(data.pop("node_reqs", {}))
    options = _parse_options(data.pop("options", {}))

    return ComfyEnvConfig(
        python=python_version,
        cuda_packages=cuda_packages,
        apt_packages=apt_packages,
        brew_packages=brew_packages,
        env_vars=env_vars,
        node_reqs=node_reqs,
        options=options,
        pixi_passthrough=data,
    )


def _parse_options(data: Dict[str, Any]) -> ComfyEnvOptions:
    """Parse [options] section into ComfyEnvOptions."""
    return ComfyEnvOptions(
        health_check_timeout=float(data.get("health_check_timeout", DEFAULT_HEALTH_CHECK_TIMEOUT)),
    )


def _parse_node_reqs(data: Dict[str, Any]) -> List[NodeDependency]:
    result = []
    for name, value in data.items():
        if isinstance(value, str):
            # Plain string: "owner/repo" or full URL
            result.append(NodeDependency(name=name, github=value))
        else:
            # Dict: { github = "...", tag = "..." } or { registry = "...", version = "..." }
            result.append(NodeDependency(
                name=name,
                github=value.get("github") or value.get("repo"),  # "repo" for backward compat
                tag=value.get("tag"),
                branch=value.get("branch"),
                commit=value.get("commit"),
                registry=value.get("registry"),
                version=value.get("version"),
            ))
    return result


def _ensure_list(value) -> List:
    return value if isinstance(value, list) else ([value] if value else [])
