"""Shared pytest fixtures for integration tests."""
