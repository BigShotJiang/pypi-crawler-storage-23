# CHANGELOG

<!-- version list -->

## v0.2.0 (2026-02-19)

### Features

- Accelerate
  ([`4934c94`](https://github.com/ssslakter/trainer-tools/commit/4934c94d52b40223c00d00cc82dee71da9a66b58))


## v0.1.4 (2026-02-12)

### Patch

- Update batch transforms, simplify skip optimizer, update evaluate
  ([`64a7098`](https://github.com/ssslakter/trainer-tools/commit/64a709800cc92c7728248757faff29403ca326de))


## v0.1.3 (2026-02-11)

### Bug Fixes

- Publish semres version
  ([`b3fddb4`](https://github.com/ssslakter/trainer-tools/commit/b3fddb471973b5e3b53da56f88b233e1fd80f98f))

### Patch

- Add semantic releases
  ([`6523fd6`](https://github.com/ssslakter/trainer-tools/commit/6523fd695d4b16d5e39ea7a17249cc7a4600a764))


## v0.1.2 (2026-02-10)

- Initial Release
