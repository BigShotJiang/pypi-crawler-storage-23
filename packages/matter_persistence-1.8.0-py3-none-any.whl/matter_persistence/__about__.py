# SPDX-FileCopyrightText: 2023-present Rômulo Jales <romulo@thisismatter.com>
#
# SPDX-License-Identifier: MIT
__version__ = "1.8.0"
