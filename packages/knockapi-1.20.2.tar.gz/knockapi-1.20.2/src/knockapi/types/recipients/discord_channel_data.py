# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union
from typing_extensions import TypeAlias

from ..._models import BaseModel

__all__ = [
    "DiscordChannelData",
    "Connection",
    "ConnectionDiscordChannelConnection",
    "ConnectionDiscordIncomingWebhookConnection",
    "ConnectionDiscordIncomingWebhookConnectionIncomingWebhook",
]


class ConnectionDiscordChannelConnection(BaseModel):
    """Discord channel connection."""

    channel_id: str
    """Discord channel ID."""


class ConnectionDiscordIncomingWebhookConnectionIncomingWebhook(BaseModel):
    """Discord incoming webhook object."""

    url: str
    """Incoming webhook URL."""


class ConnectionDiscordIncomingWebhookConnection(BaseModel):
    """Discord incoming webhook connection."""

    incoming_webhook: ConnectionDiscordIncomingWebhookConnectionIncomingWebhook
    """Discord incoming webhook object."""


Connection: TypeAlias = Union[ConnectionDiscordChannelConnection, ConnectionDiscordIncomingWebhookConnection]


class DiscordChannelData(BaseModel):
    """Discord channel data."""

    connections: List[Connection]
    """List of Discord channel connections."""
