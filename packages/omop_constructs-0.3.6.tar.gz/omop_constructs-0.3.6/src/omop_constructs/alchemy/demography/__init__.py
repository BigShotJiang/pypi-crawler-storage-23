from .demography_matview import PersonDemography

__all__ = ["PersonDemography"]