"""CoT (Chain-of-Thought) acceleration module (Task3.5)."""

from __future__ import annotations

from sagellm_compression.cot.accelerator import CoTAccelerationResult, CoTAccelerator
from sagellm_compression.cot.configs import (
    ChainShorteningConfig,
    CoTAcceleratorConfig,
    CoTStrategyType,
    ParallelChainsConfig,
    PromptCompressionConfig,
)
from sagellm_compression.cot.detector import CoTDetectionResult, CoTDetector
from sagellm_compression.cot.metrics import CoTMetrics
from sagellm_compression.cot.prompt_compressor import (
    CompressionResult,
    HeuristicPromptCompressor,
    PromptCompressor,
)
from sagellm_compression.cot.templates import CoTTemplateManager

__all__ = [
    # Configs
    "CoTAcceleratorConfig",
    "CoTStrategyType",
    "PromptCompressionConfig",
    "ChainShorteningConfig",
    "ParallelChainsConfig",
    # Detector
    "CoTDetector",
    "CoTDetectionResult",
    # Compressor
    "PromptCompressor",
    "HeuristicPromptCompressor",
    "CompressionResult",
    # Accelerator
    "CoTAccelerator",
    "CoTAccelerationResult",
    # Metrics
    "CoTMetrics",
    # Templates
    "CoTTemplateManager",
]
