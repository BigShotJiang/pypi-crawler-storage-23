"""Sparsity module for sagellm-compression (Task3.2).

This module provides a sparsification framework including:
- Sparsifier: Applies structured/unstructured sparsity to model weights.
- StubSparsifier: Deterministic CPU-only stub for CI/unit testing.
- SparseWeight / SparseModel: Sparse tensor representations.
- SparsityConfig, UnstructuredSparsityConfig, NMSparsityConfig, BlockSparsityConfig.
"""

from __future__ import annotations

from sagellm_compression.sparsity.configs import (
    BlockSparsityConfig,
    NMSparsityConfig,
    SparsityConfig,
    SparsityType,
    UnstructuredSparsityConfig,
)
from sagellm_compression.sparsity.sparsifier import SparseModel, SparseWeight, Sparsifier
from sagellm_compression.sparsity.stub_sparsifier import StubSparsifier

__all__ = [
    # Configs
    "SparsityConfig",
    "SparsityType",
    "UnstructuredSparsityConfig",
    "NMSparsityConfig",
    "BlockSparsityConfig",
    # Core
    "Sparsifier",
    "StubSparsifier",
    "SparseWeight",
    "SparseModel",
]
