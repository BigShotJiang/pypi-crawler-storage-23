# TkinterWeb 
**Fast and lightweight web browser, rich text, and app design widgets for Tkinter.**

## Overview
**TkinterWeb adds HTML and CSS rendering capabilities to Tkinter widgets.**

Common use cases include displaying help files, documentation, and other HTML content, rendering images (including SVG), building rich-text editors, designing apps with HTML templates, and creating more modern-looking interfaces, with advanced styling and even round buttons!

All [major operating systems](https://tkinterweb.readthedocs.io/en/latest/compatibility.html#a-note-on-tkhtml-binaries) running Python 3.2+ are supported. 

## Installation
**To install TkinterWeb, simply type `pip install tkinterweb[recommended]` in the command prompt or terminal. That's it!**

## Usage

**TkinterWeb provides:**
* A [frame widget](https://tkinterweb.readthedocs.io/en/latest/api/htmlframe.html) to display and edit websites, help files, RSS feeds, and any other styled HTML in Tkinter.
* A [label widget](https://tkinterweb.readthedocs.io/en/latest/api/htmlframe.html#tkinterweb.HtmlLabel) that can display styled HTML.
* A [text widget](https://tkinterweb.readthedocs.io/en/latest/api/htmlframe.html#tkinterweb.HtmlText) that allows the user to edit styled HTML.

**TkinterWeb can be used in any Tkinter application to display and edit websites, help pages, documentation, and much more! Here is an example:**

```
import tkinter as tk
from tkinterweb import HtmlFrame # import the HtmlFrame widget

root = tk.Tk() # create the Tkinter window
frame = HtmlFrame(root) # create the HTML widget
frame.load_website("https://tkinterweb.readthedocs.io/en/latest/") # load a website
frame.pack(fill="both", expand=True) # attach the HtmlFrame widget to the window
root.mainloop()
```
![Output](https://raw.githubusercontent.com/Andereoo/TkinterWeb/main/images/tkinterweb-demo.png)

**Visit the [Read the Docs home page](https://tkinterweb.readthedocs.io/en/latest/) for more information!**
