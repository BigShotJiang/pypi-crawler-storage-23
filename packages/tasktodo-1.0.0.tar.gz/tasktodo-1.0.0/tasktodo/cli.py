from ndca import NDCA
import os
import subprocess
import sys 
import time

n = NDCA()
n.file("data/.local/data/tasktodo/.data.ndca", autosave=True)
version = "1.0.0"

def refresh():
    os.system("cls" if os.name == "nt" else "clear")
    main()

def clear():
    os.system("cls" if os.name == "nt" else "clear")
    
def restart():
    refresh()
    python = sys.executable
    os.execv(python, [python] + sys.argv) 
    
def setup():
    print("Welcome by your personal Task Manager!")
    name = input("How should i call you?: ")
    print("Is the name", name, "correct?")
    name_correct = input("y/n: ")
    if name_correct != "y":
        restart()
    else:
        n.write("name", name)
        print("Hello", name + "!")
        time.sleep(0.75)
        refresh()

def add():
    clear()
    print("Add an task to your list!")
    task_name = input("name of task: ")
    if task_name == "":
        refresh()
    task_content = input("content of task: ")
    n.write(task_name, task_content)
    print(f"Task '{task_name}' has been saved!")
    time.sleep(1)
    refresh()

def remove():
    clear()
    print("Remove an task from your list!")
    task_name = input("name of task: ")
    if task_name == "":
        refresh()
    if n.exists(task_name) != True:
        print("task not found!")
        time.sleep(0.5)
        refresh()
    n.delete(task_name)
    print(f"Task {task_name} has been removed!")
    time.sleep(1)
    refresh()

def show_list():
    clear()
    print("Your tasks:\n")
    
    keys = n.keys()
    
    tasks_found = False
    
    for key in keys:
        if key != "name":
            tasks_found = True
            print(f"- {key}: {n.get(key)}")
    
    if not tasks_found:
        print("No tasks found.")
    
    input("\nPress Enter to go back...\n")
    refresh()

def reset_all():
    n.wipe()
    restart()

def info():
    print(f"v{version}")
    print("created by Viren Sahti!")
    input("Enter to continue...")
    refresh()
    
def main():
    if n.exists("name") != True:
        setup()
    name = n.get("name")
    print(f"Welcome back {name}!\n\nTaskTodo!")
    print("""
1. add
2. remove
3. list
4. reset
5. info
6. exit
    """)
    while (True):
        choice = input("tt_1/6: ")
        if choice == "1":
            add()
        elif choice == "2":
            remove()
        elif choice == "3":
            show_list()
        elif choice == "4":
            reset_all()
        elif choice == "5":
            info()
        elif choice == "6":
            print("Bye!")
            exit()
        else:
            print("Invalid choice!")
            input("Press enter to continue!\n")
            refresh()

if __name__ == "__main__":
    main()