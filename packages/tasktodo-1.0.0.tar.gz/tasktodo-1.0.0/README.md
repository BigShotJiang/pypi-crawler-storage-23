# TaskTodo

TaskTodo is a simple Python CLI tool to manage your personal tasks.  
It uses **NDCA** for safe, persistent, human-readable storage.

## Installation

```bash
pip install tasktodo