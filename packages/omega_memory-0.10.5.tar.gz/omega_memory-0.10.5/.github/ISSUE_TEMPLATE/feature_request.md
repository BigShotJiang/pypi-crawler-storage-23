---
name: Feature Request
about: Suggest a feature for OMEGA
title: '[Feature] '
labels: enhancement
assignees: ''
---

**Problem**
What problem does this solve?

**Proposed Solution**
How should it work?

**Alternatives Considered**
Any other approaches you've thought about.
