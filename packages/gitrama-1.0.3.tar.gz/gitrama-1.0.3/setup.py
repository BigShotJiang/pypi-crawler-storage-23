"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

This software is proprietary and confidential.
Unauthorized copying, distribution, or use is strictly prohibited.

Gitrama LLC
South Carolina Limited Liability Company
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

setup(
    name="gitrama",
    version="1.0.3",
    author="Alfonso Harding",
    author_email="contact@gitrama.ai",
    description="AI-powered Git workflow automation — smarter commits, branches, PRs, and repo chat",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://gitrama.ai",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Version Control :: Git",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Utilities",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Operating System :: OS Independent",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: POSIX :: Linux",
        "Operating System :: MacOS",
        "Environment :: Console",
        "Natural Language :: English",
    ],
    python_requires=">=3.11",
    install_requires=[
        "typer>=0.9.0",
        "rich>=13.0.0",
        "requests>=2.31.0",
        "pyperclip>=1.8.2",
    ],
    entry_points={
        "console_scripts": [
            "gitrama=gitrama.cli:app",
            "gtr=gitrama.cli:app",
        ],
    },
    keywords=[
        "git",
        "ai",
        "automation",
        "cli",
        "workflow",
        "developer-tools",
        "commit",
        "branch",
        "pull-request",
        "productivity",
        "openai",
        "anthropic",
        "llm",
        "askgit",
    ],
    project_urls={
        "Homepage":      "https://gitrama.ai",
        "Documentation": "https://gitrama.ai/docs_v4.html",
        "Bug Reports":   "https://github.com/ahmaxdev/gitrama-cli/issues",
        "Source":        "https://github.com/ahmaxdev/gitrama-cli",
        "Changelog":     "https://github.com/ahmaxdev/gitrama-cli/releases",
    },
    license="Proprietary",
    include_package_data=True,
    zip_safe=False,
)