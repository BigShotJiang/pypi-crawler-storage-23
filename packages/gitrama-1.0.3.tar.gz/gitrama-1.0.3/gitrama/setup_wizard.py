"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

Gitrama LLC
South Carolina Limited Liability Company
"""
"""
gtr setup — Interactive provider configuration wizard.
Add this command to your existing cli.py.
"""
import typer
import requests
from rich.console import Console
from rich.panel   import Panel
from rich.prompt  import Prompt, Confirm
from rich.table   import Table

from .config     import set_value, get_value
from .ai_client  import (
    AIClient,
    PROVIDER_GITRAMA, PROVIDER_OPENAI,
    PROVIDER_ANTHROPIC, PROVIDER_OLLAMA,
    DEFAULT_MODELS, GITRAMA_DEFAULT_URL,
)

console = Console()


def setup():
    """
    ⚙️  Interactive setup wizard — configure your AI provider.

    Choose between Gitrama hosted (free, no key needed),
    OpenAI, Anthropic, or a local Ollama instance.
    """
    console.print()
    console.print(Panel.fit(
        "[bold cyan]Gitrama Setup Wizard[/bold cyan]\n"
        "[dim]Configure your AI provider in under a minute.[/dim]",
        border_style="cyan"
    ))
    console.print()

    # ── Step 1: Choose provider ───────────────────────────────────────────────
    console.print("[bold]Step 1 of 3 — Choose your AI provider[/bold]\n")

    table = Table(show_header=True, header_style="bold cyan", box=None, padding=(0, 2))
    table.add_column("#",        style="bold yellow", width=4)
    table.add_column("Provider", style="bold white",  width=16)
    table.add_column("Cost",     style="green",       width=14)
    table.add_column("Details")

    table.add_row("1", "Gitrama Hosted", "Free",         "Default. Uses Gitrama's AI server. No key needed.")
    table.add_row("2", "OpenAI",         "Your API key", "GPT-4o, GPT-4o-mini. Fast and reliable.")
    table.add_row("3", "Anthropic",      "Your API key", "Claude Haiku or Sonnet. Excellent at code.")
    table.add_row("4", "Ollama (local)", "Free",         "Run models locally. 100% private, no internet.")

    console.print(table)
    console.print()

    choice = Prompt.ask(
        "[bold yellow]Enter number[/bold yellow]",
        choices=["1", "2", "3", "4"],
        default="1"
    )

    provider_map = {
        "1": PROVIDER_GITRAMA,
        "2": PROVIDER_OPENAI,
        "3": PROVIDER_ANTHROPIC,
        "4": PROVIDER_OLLAMA,
    }
    provider = provider_map[choice]
    set_value("provider", provider)
    console.print(f"\n[green]✓[/green] Provider set to [bold]{provider}[/bold]\n")

    # ── Step 2: Provider-specific config ─────────────────────────────────────
    console.print("[bold]Step 2 of 3 — Provider configuration[/bold]\n")

    if provider == PROVIDER_GITRAMA:
        _setup_gitrama()

    elif provider == PROVIDER_OPENAI:
        _setup_openai()

    elif provider == PROVIDER_ANTHROPIC:
        _setup_anthropic()

    elif provider == PROVIDER_OLLAMA:
        _setup_ollama()

    # ── Step 3: Test connection ───────────────────────────────────────────────
    console.print("\n[bold]Step 3 of 3 — Testing connection[/bold]\n")
    console.print("[dim]Connecting to your AI provider...[/dim]")

    try:
        client = AIClient()
        result = client.health_check()
        console.print(f"[bold green]✓ Connection successful![/bold green]")
        if isinstance(result, dict):
            if result.get("model"):
                console.print(f"  Model:    [cyan]{result['model']}[/cyan]")
            if result.get("provider"):
                console.print(f"  Provider: [cyan]{result['provider']}[/cyan]")
    except Exception as e:
        console.print(f"[bold red]✗ Connection failed:[/bold red] {e}")
        console.print()
        if Confirm.ask("[yellow]Would you like to try a different provider?[/yellow]"):
            setup()
            return
        else:
            console.print("[dim]You can re-run 'gtr setup' at any time.[/dim]")
            return

    # ── Done ──────────────────────────────────────────────────────────────────
    console.print()
    console.print(Panel.fit(
        f"[bold green]Gitrama is ready![/bold green]\n\n"
        f"Provider: [cyan]{provider}[/cyan]\n"
        f"Run [bold]gtr health[/bold] to verify anytime.\n"
        f"Run [bold]gtr setup[/bold] again to switch providers.",
        border_style="green"
    ))
    console.print()


# ── Provider setup helpers ────────────────────────────────────────────────────

def _setup_gitrama():
    """Configure Gitrama hosted server."""
    current_url = get_value("api_url") or GITRAMA_DEFAULT_URL
    console.print(f"Using Gitrama hosted server: [cyan]{current_url}[/cyan]")
    console.print("[dim]No API key required. You're good to go.[/dim]")

    if Confirm.ask("\nUse a custom server URL instead?", default=False):
        url = Prompt.ask("Enter your server URL", default=current_url)
        set_value("api_url", url.rstrip("/"))
        console.print(f"[green]✓[/green] Server URL updated.")


def _setup_openai():
    """Configure OpenAI BYOK."""
    console.print("You'll need an OpenAI API key.")
    console.print("[dim]Get one at: https://platform.openai.com/api-keys[/dim]\n")

    api_key = Prompt.ask("Enter your OpenAI API key [dim](input masked: sk-••••••••)[/dim]")
    if not api_key.startswith("sk-"):
        console.print("[yellow]⚠ That doesn't look like an OpenAI key (should start with sk-)[/yellow]")
        if not Confirm.ask("Continue anyway?", default=False):
            return

    set_value("api_key", api_key)

    # Model selection
    console.print()
    model_table = Table(show_header=False, box=None, padding=(0, 2))
    model_table.add_column("#",     style="bold yellow", width=4)
    model_table.add_column("Model", style="white",       width=20)
    model_table.add_column("Notes", style="dim")
    model_table.add_row("1", "gpt-4o-mini",  "Recommended. Fast, cheap, great for Git tasks.")
    model_table.add_row("2", "gpt-4o",       "More powerful. Higher cost.")
    model_table.add_row("3", "gpt-4-turbo",  "Strong reasoning. Moderate cost.")
    model_table.add_row("4", "Custom",       "Enter your own model name.")
    console.print(model_table)
    console.print()

    model_choice = Prompt.ask("Choose model", choices=["1", "2", "3", "4"], default="1")
    model_map = {
        "1": "gpt-4o-mini",
        "2": "gpt-4o",
        "3": "gpt-4-turbo",
    }
    if model_choice == "4":
        model = Prompt.ask("Enter model name")
    else:
        model = model_map[model_choice]

    set_value("model", model)
    console.print(f"[green]✓[/green] OpenAI configured with model [cyan]{model}[/cyan]")


def _setup_anthropic():
    """Configure Anthropic BYOK."""
    console.print("You'll need an Anthropic API key.")
    console.print("[dim]Get one at: https://console.anthropic.com/[/dim]\n")

    api_key = Prompt.ask("Enter your Anthropic API key [dim](input masked: sk-ant-••••••••)[/dim]")
    if not api_key.startswith("sk-ant-"):
        console.print("[yellow]⚠ That doesn't look like an Anthropic key (should start with sk-ant-)[/yellow]")
        if not Confirm.ask("Continue anyway?", default=False):
            return

    set_value("api_key", api_key)

    # Model selection
    console.print()
    model_table = Table(show_header=False, box=None, padding=(0, 2))
    model_table.add_column("#",     style="bold yellow", width=4)
    model_table.add_column("Model", style="white",       width=34)
    model_table.add_column("Notes", style="dim")
    model_table.add_row("1", "claude-haiku-4-5-20251001",  "Recommended. Fastest and most affordable.")
    model_table.add_row("2", "claude-sonnet-4-6",          "More capable. Moderate cost.")
    model_table.add_row("3", "Custom",                     "Enter your own model name.")
    console.print(model_table)
    console.print()

    model_choice = Prompt.ask("Choose model", choices=["1", "2", "3"], default="1")
    model_map = {
        "1": "claude-haiku-4-5-20251001",
        "2": "claude-sonnet-4-6",
    }
    if model_choice == "3":
        model = Prompt.ask("Enter model name")
    else:
        model = model_map[model_choice]

    set_value("model", model)
    console.print(f"[green]✓[/green] Anthropic configured with model [cyan]{model}[/cyan]")


def _setup_ollama():
    """Configure local Ollama instance."""
    console.print("Ollama runs AI models locally on your machine.")
    console.print("[dim]Install Ollama at: https://ollama.ai — then run: ollama pull llama3[/dim]\n")

    ollama_url = Prompt.ask(
        "Ollama server URL",
        default=get_value("ollama_url") or "http://localhost:11434"
    )
    set_value("ollama_url", ollama_url.rstrip("/"))

    # Check if Ollama is actually running
    try:
        resp = requests.get(f"{ollama_url.rstrip('/')}/api/tags", timeout=3)
        resp.raise_for_status()
        models = [m["name"] for m in resp.json().get("models", [])]
        if models:
            console.print(f"\n[green]✓ Ollama is running.[/green] Found {len(models)} model(s):\n")
            for i, m in enumerate(models[:8], 1):
                console.print(f"  {i}. {m}")
            console.print()
            model_input = Prompt.ask("Enter model name to use", default=models[0])
        else:
            console.print("[yellow]⚠ Ollama is running but no models found.[/yellow]")
            console.print("[dim]Pull a model first: ollama pull llama3[/dim]")
            model_input = Prompt.ask("Enter model name", default="llama3")
    except Exception:
        console.print("[yellow]⚠ Could not reach Ollama at that URL.[/yellow]")
        console.print("[dim]Make sure Ollama is running: ollama serve[/dim]")
        model_input = Prompt.ask("Enter model name anyway", default="llama3")

    set_value("model", model_input)
    console.print(f"[green]✓[/green] Ollama configured with model [cyan]{model_input}[/cyan]")
