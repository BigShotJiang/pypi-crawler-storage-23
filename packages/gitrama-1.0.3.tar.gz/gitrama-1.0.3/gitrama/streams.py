"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

This software is proprietary and confidential.
Unauthorized copying, distribution, or use is strictly prohibited.

Gitrama LLC
South Carolina Limited Liability Company
"""

"""
Gitrama Streams - Multi-context workflow management
Switch between WIP, hotfix, and custom work streams
"""

import json
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, List
from rich.console import Console
from rich.table import Table

console = Console()

STREAMS_FILE = Path.home() / ".gitrama" / "streams.json"

# Default streams
DEFAULT_STREAMS = {
    "wip": "Work in Progress - Main feature work",
    "hotfix": "Urgent bug fixes and patches",
    "review": "Code review feedback and changes",
    "experiment": "Try new ideas without commitment"
}


class StreamManager:
    def __init__(self):
        self.streams_file = STREAMS_FILE
        self.streams_file.parent.mkdir(parents=True, exist_ok=True)
        self.data = self.load_streams()
    
    def load_streams(self) -> dict:
        """Load streams from config file"""
        if not self.streams_file.exists():
            # Initialize with defaults
            data = {
                "current": "wip",
                "streams": {
                    name: {
                        "description": desc,
                        "branch": None,
                        "has_changes": False,
                        "last_active": None
                    }
                    for name, desc in DEFAULT_STREAMS.items()
                }
            }
            self.save_streams(data)
            return data
        
        with open(self.streams_file, 'r') as f:
            return json.load(f)
    
    def save_streams(self, data: dict = None):
        """Save streams to config file"""
        if data is None:
            data = self.data
        
        with open(self.streams_file, 'w') as f:
            json.dump(data, f, indent=2)
    
    def get_current_branch(self) -> str:
        """Get current git branch"""
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError:
            return "(no repo detected)"
    
    def has_uncommitted_changes(self) -> bool:
        """Check if there are uncommitted changes"""
        try:
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                capture_output=True,
                text=True
            )
            return bool(result.stdout.strip())
        except Exception:
            return False
    
    def stash_changes(self, message: str = "Gitrama stream switch"):
        """Stash current changes"""
        if self.has_uncommitted_changes():
            subprocess.run(
                ["git", "stash", "push", "-m", message],
                check=True
            )
            return True
        return False
    
    def pop_stash(self):
        """Pop most recent stash"""
        try:
            subprocess.run(
                ["git", "stash", "pop"],
                check=True
            )
            return True
        except subprocess.CalledProcessError:
            return False
    
    def switch_stream(self, stream_name: str) -> bool:
        """Switch to a different stream"""
        if stream_name not in self.data["streams"]:
            console.print(f"❌ Stream '{stream_name}' not found!", style="red")
            return False
        
        current_stream = self.data["current"]
        
        if current_stream == stream_name:
            console.print(f"✅ Already on stream: {stream_name}", style="yellow")
            return True
        
        console.print(f"🔄 Switching from '{current_stream}' to '{stream_name}'...")
        
        # Save current stream state
        current_branch = self.get_current_branch()
        has_changes = self.has_uncommitted_changes()
        
        self.data["streams"][current_stream]["branch"] = current_branch
        self.data["streams"][current_stream]["has_changes"] = has_changes
        self.data["streams"][current_stream]["last_active"] = datetime.now().isoformat()
        
        # Stash if needed
        if has_changes:
            console.print("📦 Stashing current changes...", style="cyan")
            self.stash_changes(f"Stream: {current_stream}")
        
        # Switch to target stream
        target_stream = self.data["streams"][stream_name]
        target_branch = target_stream.get("branch")
        
        # If stream has a saved branch, checkout it
        if target_branch:
            console.print(f"🌿 Checking out branch: {target_branch}", style="cyan")
            try:
                subprocess.run(
                    ["git", "checkout", target_branch],
                    check=True,
                    capture_output=True
                )
            except subprocess.CalledProcessError:
                console.print(f"⚠️  Branch '{target_branch}' not found, staying on current branch", style="yellow")
        
        # Pop stash if this stream had changes
        if target_stream.get("has_changes"):
            console.print("📂 Restoring changes...", style="cyan")
            self.pop_stash()
        
        # Update current stream
        self.data["current"] = stream_name
        self.save_streams()
        
        console.print(f"✅ Switched to stream: [bold green]{stream_name}[/bold green]")
        return True
    
    def list_streams(self):
        """Display all streams"""
        table = Table(title="🌊 Gitrama Streams")
        
        table.add_column("Stream", style="cyan", no_wrap=True)
        table.add_column("Description", style="white")
        table.add_column("Branch", style="yellow")
        table.add_column("Changes", style="magenta")
        table.add_column("Active", style="green")
        
        current = self.data["current"]
        
        for name, info in self.data["streams"].items():
            is_current = "✓" if name == current else ""
            branch = info.get("branch") or "-"
            changes = "Yes" if info.get("has_changes") else "No"
            desc = info.get("description", "Custom stream")
            
            table.add_row(
                name,
                desc,
                branch,
                changes,
                is_current
            )
        
        console.print(table)
    
    def create_stream(self, name: str, description: str = "Custom stream"):
        """Create a new custom stream"""
        if name in self.data["streams"]:
            console.print(f"❌ Stream '{name}' already exists!", style="red")
            return False
        
        self.data["streams"][name] = {
            "description": description,
            "branch": None,
            "has_changes": False,
            "last_active": None
        }
        self.save_streams()
        
        console.print(f"✅ Created stream: [bold green]{name}[/bold green]")
        console.print(f"   {description}", style="dim")
        return True
    
    def delete_stream(self, name: str):
        """Delete a custom stream"""
        if name in DEFAULT_STREAMS:
            console.print(f"❌ Cannot delete default stream: {name}", style="red")
            return False
        
        if name not in self.data["streams"]:
            console.print(f"❌ Stream '{name}' not found!", style="red")
            return False
        
        if self.data["current"] == name:
            console.print(f"❌ Cannot delete active stream! Switch first.", style="red")
            return False
        
        del self.data["streams"][name]
        self.save_streams()
        
        console.print(f"✅ Deleted stream: {name}", style="green")
        return True
    
    def merge_stream(self, target_branch: str) -> bool:
        """
        Merge the current stream's branch into a target branch.
        Asks user whether to delete stream branch and push after merging.

        Args:
            target_branch: Branch to merge into (e.g. main, develop)

        Returns:
            bool: True if merge succeeded
        """
        current_stream = self.data.get("current")
        stream_info    = self.data["streams"].get(current_stream, {})
        stream_branch  = stream_info.get("branch") or self.get_current_branch()

        # ── Guard: uncommitted changes ────────────────────────────────────────
        if self.has_uncommitted_changes():
            console.print("❌ You have uncommitted changes!", style="bold red")
            console.print("\n💡 Commit or stash them first:", style="yellow")
            console.print("   gtr commit", style="white")
            console.print("   gtr stash push", style="white")
            return False

        # ── Guard: already on target ──────────────────────────────────────────
        if stream_branch == target_branch:
            console.print(f"❌ Stream branch and target are both '{target_branch}'!", style="bold red")
            return False

        console.print(f"\n🔀 Merging [cyan]{stream_branch}[/cyan] → [bold green]{target_branch}[/bold green]")

        # ── Switch to target branch ───────────────────────────────────────────
        console.print(f"🌿 Switching to '{target_branch}'...", style="cyan")
        result = subprocess.run(
            ["git", "checkout", target_branch],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            console.print(f"❌ Could not switch to '{target_branch}':\n{result.stderr}", style="bold red")
            return False

        # ── Merge ─────────────────────────────────────────────────────────────
        with console.status(f"[cyan]🔀 Merging {stream_branch}...", spinner="dots"):
            merge_result = subprocess.run(
                ["git", "merge", "--no-ff", stream_branch,
                 "-m", f"merge({current_stream}): merge {stream_branch} into {target_branch}"],
                capture_output=True, text=True
            )

        if merge_result.returncode != 0:
            console.print(f"❌ Merge failed — you may have conflicts:", style="bold red")
            console.print(f"[dim]{merge_result.stderr}[/dim]")
            console.print("\n🔧 Resolve conflicts then run:", style="yellow")
            console.print("   git add .", style="white")
            console.print("   git commit", style="white")
            return False

        console.print(f"✅ Merged successfully into [bold green]{target_branch}[/bold green]!", style="bold green")

        # ── Ask: push to remote? ──────────────────────────────────────────────
        if typer.confirm(f"\n🚀 Push '{target_branch}' to remote?", default=True):
            with console.status(f"[cyan]🚀 Pushing {target_branch}...", spinner="dots"):
                push_result = subprocess.run(
                    ["git", "push", "origin", target_branch],
                    capture_output=True, text=True
                )
            if push_result.returncode == 0:
                console.print(f"✅ Pushed [bold green]{target_branch}[/bold green] to remote!", style="bold green")
            else:
                console.print(f"⚠️  Push failed:\n{push_result.stderr}", style="yellow")
                console.print("💡 Push manually: gtr push", style="dim")
        else:
            console.print("💡 Push when ready: gtr push", style="dim")

        # ── Ask: delete stream branch? ────────────────────────────────────────
        if typer.confirm(f"\n🗑️  Delete stream branch '{stream_branch}'?", default=False):
            del_result = subprocess.run(
                ["git", "branch", "-d", stream_branch],
                capture_output=True, text=True
            )
            if del_result.returncode == 0:
                console.print(f"✅ Branch '[dim]{stream_branch}[/dim]' deleted.", style="green")
                # Clear branch from stream data
                self.data["streams"][current_stream]["branch"] = None
                self.data["streams"][current_stream]["has_changes"] = False
                self.save_streams()
            else:
                console.print(f"⚠️  Could not delete branch: {del_result.stderr}", style="yellow")
                console.print("💡 Delete manually: git branch -d " + stream_branch, style="dim")
        else:
            console.print(f"💡 Branch '[dim]{stream_branch}[/dim]' kept.", style="dim")

        console.print(f"\n💚 Stream merge complete!", style="bold green")
        return True


    def status(self):
        """Show detailed status of all streams"""
        console.print("\n🌊 Stream Status\n", style="bold cyan")
        
        current = self.data["current"]
        console.print(f"Current stream: [bold green]{current}[/bold green]")
        console.print(f"Current branch: [yellow]{self.get_current_branch()}[/yellow]")
        console.print(f"Uncommitted changes: {'Yes' if self.has_uncommitted_changes() else 'No'}")
        console.print()
        
        self.list_streams()