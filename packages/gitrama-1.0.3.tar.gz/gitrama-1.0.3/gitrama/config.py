"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

This software is proprietary and confidential.
Unauthorized copying, distribution, or use is strictly prohibited.

Gitrama LLC
South Carolina Limited Liability Company
"""

"""
Configuration management for Gitrama
Stores user preferences in ~/.gitrama/config.json
"""

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

# ─── Provider URL Map ─────────────────────────────────────────────────────────
PROVIDER_URLS = {
    "gitrama":   "https://vast-connector.gitrama.io",
    "openai":    "https://api.openai.com/v1",
    "anthropic": "https://api.anthropic.com/v1",
    "ollama":    "http://localhost:11434",
}

VALID_PROVIDERS = list(PROVIDER_URLS.keys())

# ─── Default Configuration ────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "api_url":     "https://vast-connector.gitrama.io",
    "provider":    "gitrama",
    "auto_commit": False,
    "style":       "default",
    "max_retries": 3,
    "timeout":     30,
}


# ─── Path Helpers ─────────────────────────────────────────────────────────────

def get_config_dir() -> Path:
    """Get the Gitrama config directory"""
    config_dir = Path.home() / ".gitrama"
    config_dir.mkdir(exist_ok=True)
    return config_dir

def get_config_file() -> Path:
    """Get the config file path"""
    return get_config_dir() / "config.json"


# ─── Load / Save ──────────────────────────────────────────────────────────────

def load_config() -> Dict[str, Any]:
    """
    Load configuration from file.
    Merges stored config with defaults so new keys are always present.
    """
    config_file = get_config_file()

    if not config_file.exists():
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()

    try:
        with open(config_file, 'r') as f:
            config = json.load(f)

        # Merge with defaults (handles newly added keys)
        merged = DEFAULT_CONFIG.copy()
        merged.update(config)
        return merged

    except (json.JSONDecodeError, IOError) as e:
        print(f"⚠️  Error loading config: {e}")
        print("Using default configuration")
        return DEFAULT_CONFIG.copy()


def save_config(config: Dict[str, Any]) -> None:
    """Save configuration to file"""
    config_file = get_config_file()
    try:
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=2)
    except IOError as e:
        print(f"❌ Error saving config: {e}")


# ─── Get / Set ────────────────────────────────────────────────────────────────

def get_value(key: str) -> Optional[Any]:
    """Get a single configuration value"""
    return load_config().get(key)


def set_value(key: str, value: Any) -> None:
    """Set a single configuration value"""
    config = load_config()
    config[key] = value
    save_config(config)


# ─── Provider Setter (auto-updates api_url) ───────────────────────────────────

def set_provider(provider: str, api_key: Optional[str] = None,
                 model: Optional[str] = None) -> str:
    """
    Set the AI provider and automatically update api_url to match.

    Args:
        provider: One of gitrama | openai | anthropic | ollama
        api_key:  Optional API key (required for openai/anthropic)
        model:    Optional model override

    Returns:
        str: The api_url that was set

    Raises:
        ValueError: If provider is not recognised
    """
    provider = provider.lower().strip()

    if provider not in VALID_PROVIDERS:
        raise ValueError(
            f"Unknown provider '{provider}'. "
            f"Valid options: {', '.join(VALID_PROVIDERS)}"
        )

    config = load_config()
    config["provider"] = provider
    config["api_url"]  = PROVIDER_URLS[provider]

    if api_key:
        config["api_key"] = api_key

    if model:
        config["model"] = model

    save_config(config)
    return config["api_url"]


# ─── Reset ────────────────────────────────────────────────────────────────────

def reset_config() -> None:
    """Reset configuration to defaults"""
    save_config(DEFAULT_CONFIG)
