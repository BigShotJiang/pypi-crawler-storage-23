"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

This software is proprietary and confidential.
Unauthorized copying, distribution, or use is strictly prohibited.

Gitrama LLC
South Carolina Limited Liability Company
"""

"""
Git command wrappers for Gitrama CLI.
Provides AI-enhanced, styled, and safety-guarded versions of common Git commands.
"""
import os
import sys
import io

# Force UTF-8 on Windows legacy console — fixes all emoji/unicode encoding errors
if sys.platform == "win32":
    os.system("chcp 65001 > nul")
    if hasattr(sys.stdout, "buffer"):
        sys.stdout = io.TextIOWrapper(
            sys.stdout.buffer, encoding="utf-8", errors="replace"
        )
    if hasattr(sys.stderr, "buffer"):
        sys.stderr = io.TextIOWrapper(
            sys.stderr.buffer, encoding="utf-8", errors="replace"
        )

import subprocess
from typing import Optional, List

import typer
from rich.console import Console
from rich.panel import Panel

from .ai_client import AIClient

console = Console()

# ─── Dangerous commands requiring confirmation ────────────────────────────────

DANGEROUS_COMMANDS = {
    "reset --hard": "This will permanently discard all uncommitted changes.",
    "reset":        "This will move HEAD and may discard changes.",
    "revert":       "This will create a new commit that undoes changes.",
    "stash drop":   "This will permanently delete a stash entry.",
    "stash clear":  "This will permanently delete ALL stash entries.",
    "merge":        "This will merge branches and may cause conflicts.",
}


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _run(cmd: List[str], capture: bool = True) -> subprocess.CompletedProcess:
    """Run a shell command and return the result."""
    return subprocess.run(
        cmd,
        capture_output=capture,
        text=True,
        timeout=30,
        encoding="utf-8",
        errors="replace"
    )


def _ai_explain(prompt: str, content: str, max_tokens: int = 200) -> Optional[str]:
    """Ask AI to explain or summarize content. Returns None on failure."""
    try:
        ai = AIClient()
        return ai._chat(prompt, content, max_tokens=max_tokens)
    except Exception:
        return None


def _confirm_dangerous(command_key: str) -> bool:
    """Warn user and ask confirmation before a destructive operation."""
    warning = DANGEROUS_COMMANDS.get(command_key, "This operation may be destructive.")
    console.print(f"\n[bold yellow]Warning:[/bold yellow] {warning}")
    return typer.confirm("Are you sure you want to continue?", default=False)


def _success(msg: str):
    console.print(f"\n[bold green]{msg}[/bold green]")


def _error(msg: str):
    console.print(f"\n[bold red]{msg}[/bold red]")


def _info(msg: str):
    console.print(f"\n[cyan]{msg}[/cyan]")


# ─── ADD ──────────────────────────────────────────────────────────────────────

def add(
    files: Optional[List[str]] = typer.Argument(None, help="Files to stage (default: all)"),
    patch: bool = typer.Option(False, "--patch", "-p", help="Interactively stage hunks"),
):
    """Stage files for commit."""
    cmd = ["git", "add"]
    if patch:
        cmd.append("--patch")
    if files:
        cmd.extend(files)
    else:
        cmd.append(".")

    result = _run(cmd)

    if result.returncode == 0:
        staged = _run(["git", "status", "--porcelain"])
        staged_files = [l for l in staged.stdout.splitlines() if l.startswith(("A ", "M ", "D "))]
        _success(f"Staged {len(staged_files)} file(s)!")
        for f in staged_files[:10]:
            console.print(f"   [cyan]{f}[/cyan]")
        if len(staged_files) > 10:
            console.print(f"   [dim]... and {len(staged_files) - 10} more[/dim]")
        console.print("\n[yellow]Next: [bold]gtr commit[/bold][/yellow]")
    else:
        _error(f"Add failed:\n{result.stderr}")
        raise typer.Exit(1)


# ─── PUSH ─────────────────────────────────────────────────────────────────────

def push(
    remote: str = typer.Argument("origin", help="Remote name"),
    branch: Optional[str] = typer.Argument(None, help="Branch name"),
    force: bool = typer.Option(False, "--force", "-f", help="Force push"),
    set_upstream: bool = typer.Option(False, "--set-upstream", "-u", help="Set upstream tracking"),
):
    """Push commits to remote."""
    if force:
        console.print("\n[bold yellow]Warning:[/bold yellow] Force push will overwrite remote history.")
        if not typer.confirm("Are you sure?", default=False):
            console.print("Push cancelled.")
            raise typer.Exit(0)

    cmd = ["git", "push"]
    if set_upstream:
        cmd += ["-u"]
    if force:
        cmd += ["--force"]
    cmd.append(remote)
    if branch:
        cmd.append(branch)

    with console.status("Pushing to remote...", spinner="dots"):
        result = _run(cmd, capture=False)

    if result.returncode == 0:
        _success("Push successful!")
    else:
        _error("Push failed. Check your remote connection and permissions.")
        raise typer.Exit(1)


# ─── PULL ─────────────────────────────────────────────────────────────────────

def pull(
    remote: str = typer.Argument("origin", help="Remote name"),
    branch: Optional[str] = typer.Argument(None, help="Branch name"),
    rebase: bool = typer.Option(False, "--rebase", "-r", help="Pull with rebase"),
):
    """Pull latest changes with AI summary."""
    cmd = ["git", "pull"]
    if rebase:
        cmd.append("--rebase")
    cmd.append(remote)
    if branch:
        cmd.append(branch)

    with console.status("Pulling latest changes...", spinner="dots"):
        result = _run(cmd)

    if result.returncode != 0:
        _error(f"Pull failed:\n{result.stderr}")
        raise typer.Exit(1)

    output = result.stdout.strip()
    console.print(f"\n[dim]{output}[/dim]")

    if "Already up to date" in output:
        _success("Already up to date.")
        return

    with console.status("Summarizing changes...", spinner="dots"):
        summary = _ai_explain(
            "You are a Git assistant. Summarize what changed in this pull in 1-2 sentences, plain English.",
            output,
            max_tokens=100
        )

    if summary:
        console.print(Panel(summary, title="What changed", border_style="cyan"))

    _success("Pull complete!")


# ─── FETCH ────────────────────────────────────────────────────────────────────

def fetch(
    remote: str = typer.Argument("origin", help="Remote name"),
    all_remotes: bool = typer.Option(False, "--all", "-a", help="Fetch all remotes"),
    prune: bool = typer.Option(False, "--prune", "-p", help="Prune deleted remote branches"),
):
    """Fetch remote changes without merging."""
    cmd = ["git", "fetch"]
    if all_remotes:
        cmd.append("--all")
    if prune:
        cmd.append("--prune")
    if not all_remotes:
        cmd.append(remote)

    with console.status("Fetching from remote...", spinner="dots"):
        result = _run(cmd)

    if result.returncode != 0:
        _error(f"Fetch failed:\n{result.stderr}")
        raise typer.Exit(1)

    _success("Fetch complete!")
    if result.stdout.strip():
        console.print(f"[dim]{result.stdout.strip()}[/dim]")


# ─── STATUS ───────────────────────────────────────────────────────────────────

def status(
    ai: bool = typer.Option(True, "--ai/--no-ai", help="Show AI suggestion"),
):
    """Show working tree status with AI interpretation."""
    result = _run(["git", "status"])

    if result.returncode != 0:
        _error("Failed to get git status.")
        raise typer.Exit(1)

    console.print(f"\n[bold cyan]Git Status[/bold cyan]\n")
    console.print(result.stdout)

    short = _run(["git", "status", "--porcelain"])
    if ai and short.stdout.strip():
        with console.status("Analyzing status...", spinner="dots"):
            suggestion = _ai_explain(
                "You are a Git assistant. In 1-2 sentences summarize the working tree state and suggest the logical next step.",
                short.stdout,
                max_tokens=80
            )
        if suggestion:
            console.print(Panel(suggestion, title="AI Suggestion", border_style="yellow"))


# ─── LOG ──────────────────────────────────────────────────────────────────────

def log(
    count: int = typer.Option(10, "--count", "-n", help="Number of commits to show"),
    oneline: bool = typer.Option(False, "--oneline", "-o", help="One line per commit"),
    ai: bool = typer.Option(False, "--ai", help="AI summary of recent commits"),
):
    """Show commit history with optional AI summary."""
    fmt = "--oneline" if oneline else "--pretty=format:%C(yellow)%h%Creset %C(cyan)%an%Creset %C(dim)%ar%Creset %s"
    result = _run(["git", "log", fmt, f"-{count}"])

    if result.returncode != 0:
        _error("Failed to get git log.")
        raise typer.Exit(1)

    console.print(f"\n[bold cyan]Recent Commits (last {count})[/bold cyan]\n")
    console.print(result.stdout)

    if ai:
        with console.status("Summarizing commit history...", spinner="dots"):
            summary = _ai_explain(
                "You are a Git assistant. Summarize the theme and progress of these recent commits in 2-3 sentences.",
                result.stdout,
                max_tokens=150
            )
        if summary:
            console.print(Panel(summary, title="Commit Summary", border_style="cyan"))


# ─── DIFF ─────────────────────────────────────────────────────────────────────

def diff(
    staged: bool = typer.Option(False, "--staged", "-s", help="Show staged changes"),
    ai: bool = typer.Option(True, "--ai/--no-ai", help="Show AI explanation"),
    branch: Optional[str] = typer.Argument(None, help="Branch to diff against"),
):
    """Show changes with AI explanation."""
    cmd = ["git", "diff"]
    if staged:
        cmd.append("--staged")
    if branch:
        cmd.append(branch)

    result = _run(cmd)

    if result.returncode != 0:
        _error("Failed to get diff.")
        raise typer.Exit(1)

    if not result.stdout.strip():
        console.print("\n[dim]No changes to show.[/dim]")
        return

    console.print(f"\n[bold cyan]Diff[/bold cyan]\n")
    console.print(result.stdout[:3000])

    if ai:
        with console.status("Explaining changes...", spinner="dots"):
            explanation = _ai_explain(
                "You are a senior engineer. Explain what these code changes do in plain English. Be concise.",
                result.stdout[:3000],
                max_tokens=200
            )
        if explanation:
            console.print(Panel(explanation, title="What Changed", border_style="green"))


# ─── MERGE ────────────────────────────────────────────────────────────────────

def merge(
    branch: str = typer.Argument(..., help="Branch to merge into current"),
    no_ff: bool = typer.Option(True, "--no-ff/--ff", help="No fast-forward merge"),
    message: Optional[str] = typer.Option(None, "-m", "--message", help="Merge commit message"),
):
    """Merge a branch with confirmation."""
    if not _confirm_dangerous("merge"):
        console.print("Merge cancelled.")
        raise typer.Exit(0)

    cmd = ["git", "merge"]
    if no_ff:
        cmd.append("--no-ff")
    if message:
        cmd += ["-m", message]
    cmd.append(branch)

    with console.status(f"Merging '{branch}'...", spinner="dots"):
        result = _run(cmd)

    if result.returncode == 0:
        _success(f"Merged '{branch}' successfully!")
        if result.stdout.strip():
            console.print(f"[dim]{result.stdout.strip()}[/dim]")
    else:
        _error(f"Merge failed. You may have conflicts:\n{result.stderr}")
        _info("Resolve conflicts then run: gtr add . && gtr commit")
        raise typer.Exit(1)


# ─── STASH ────────────────────────────────────────────────────────────────────

def stash(
    action: str = typer.Argument("push", help="Action: push | pop | list | drop | clear | show"),
    message: Optional[str] = typer.Option(None, "-m", "--message", help="Stash message"),
    index: int = typer.Option(0, "--index", "-i", help="Stash index for drop/show"),
):
    """Stash changes with AI labeling."""
    if action == "push":
        cmd = ["git", "stash", "push"]
        if message:
            cmd += ["-m", message]
        else:
            diff_result = _run(["git", "diff"])
            if diff_result.stdout.strip():
                with console.status("Generating stash label...", spinner="dots"):
                    label = _ai_explain(
                        "Generate a short 5-8 word stash description for these changes. Return only the description.",
                        diff_result.stdout[:1500],
                        max_tokens=20
                    )
                if label:
                    cmd += ["-m", label.strip()]

        result = _run(cmd)
        if result.returncode == 0:
            _success("Changes stashed!")
            console.print(f"[dim]{result.stdout.strip()}[/dim]")
        else:
            _error(f"Stash failed:\n{result.stderr}")
            raise typer.Exit(1)

    elif action == "pop":
        result = _run(["git", "stash", "pop"])
        if result.returncode == 0:
            _success("Stash popped!")
        else:
            _error(f"Stash pop failed:\n{result.stderr}")
            raise typer.Exit(1)

    elif action == "list":
        result = _run(["git", "stash", "list"])
        console.print(f"\n[bold cyan]Stash List[/bold cyan]\n")
        console.print(result.stdout if result.stdout else "[dim]No stashes found.[/dim]")

    elif action == "drop":
        if not _confirm_dangerous("stash drop"):
            console.print("Cancelled.")
            raise typer.Exit(0)
        result = _run(["git", "stash", "drop", f"stash@{{{index}}}"])
        if result.returncode == 0:
            _success(f"Stash {index} dropped.")
        else:
            _error(f"Drop failed:\n{result.stderr}")
            raise typer.Exit(1)

    elif action == "clear":
        if not _confirm_dangerous("stash clear"):
            console.print("Cancelled.")
            raise typer.Exit(0)
        _run(["git", "stash", "clear"])
        _success("All stashes cleared.")

    elif action == "show":
        result = _run(["git", "stash", "show", "-p", f"stash@{{{index}}}"])
        console.print(result.stdout)

    else:
        _error(f"Unknown stash action: {action}")
        _info("Valid actions: push | pop | list | drop | clear | show")
        raise typer.Exit(1)


# ─── RESET ────────────────────────────────────────────────────────────────────

def reset(
    mode: str = typer.Option("mixed", "--mode", "-m", help="Reset mode: soft | mixed | hard"),
    target: str = typer.Argument("HEAD", help="Commit to reset to"),
):
    """Reset HEAD with safety confirmation."""
    key = "reset --hard" if mode == "hard" else "reset"
    if not _confirm_dangerous(key):
        console.print("Reset cancelled.")
        raise typer.Exit(0)

    result = _run(["git", "reset", f"--{mode}", target])

    if result.returncode == 0:
        _success(f"Reset to {target} ({mode} mode).")
        if result.stdout.strip():
            console.print(f"[dim]{result.stdout.strip()}[/dim]")
    else:
        _error(f"Reset failed:\n{result.stderr}")
        raise typer.Exit(1)


# ─── REVERT ───────────────────────────────────────────────────────────────────

def revert(
    commit: str = typer.Argument("HEAD", help="Commit hash to revert"),
    no_edit: bool = typer.Option(False, "--no-edit", help="Skip commit message editor"),
):
    """Revert a commit safely."""
    if not _confirm_dangerous("revert"):
        console.print("Revert cancelled.")
        raise typer.Exit(0)

    cmd = ["git", "revert", commit]
    if no_edit:
        cmd.append("--no-edit")

    with console.status(f"Reverting {commit}...", spinner="dots"):
        result = _run(cmd)

    if result.returncode == 0:
        _success(f"Reverted commit {commit}.")
        if result.stdout.strip():
            console.print(f"[dim]{result.stdout.strip()}[/dim]")
    else:
        _error(f"Revert failed:\n{result.stderr}")
        raise typer.Exit(1)