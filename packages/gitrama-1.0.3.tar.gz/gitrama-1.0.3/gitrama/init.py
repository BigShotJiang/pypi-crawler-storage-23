"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.
"""

__version__ = "1.0.0"
__author__ = "Alfonso Harding"
__email__ = "contact@gitrama.ai"
__license__ = "Proprietary"
