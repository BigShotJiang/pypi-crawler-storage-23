"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

This software is proprietary and confidential.
Unauthorized copying, distribution, or use is strictly prohibited.

Gitrama LLC
South Carolina Limited Liability Company
"""

"""
Gitrama CLI
Main command-line interface for Gitrama
"""
import os
import sys

if sys.platform == "win32":
    os.system("chcp 65001 > nul")

import typer
import subprocess
from rich.console import Console
from typing import Optional

from .chat_client import chat
from .config import load_config, save_config, set_value, get_value, reset_config, DEFAULT_CONFIG
from .ai_client import AIClient
from .git_utils import (
    get_staged_files,
    get_staged_diff,
    commit_changes,
    has_staged_changes,
    get_current_branch,
    branch_exists,
    create_branch,
    checkout_branch,
    get_branch_commits,
    get_branch_diff,
    get_default_branch
)
from .streams import StreamManager
from .setup_wizard import setup
from .git_wrapper import (
    add, push, pull, fetch,
    status, log, diff,
    merge, stash, reset, revert
)

# Create app with custom help
app = typer.Typer(
    name="gtr",
    help="🌿 AI-Powered Git Workflow Automation",
    add_completion=False,
    rich_markup_mode="rich",
    invoke_without_command=True,
)

console = Console()

# Banner
BANNER = """
 ██████╗ ██╗████████╗██████╗  █████╗ ███╗   ███╗ █████╗ 
██╔════╝ ██║╚══██╔══╝██╔══██╗██╔══██╗████╗ ████║██╔══██╗
██║  ███╗██║   ██║   ██████╔╝███████║██╔████╔██║███████║
██║   ██║██║   ██║   ██╔══██╗██╔══██║██║╚██╔╝██║██╔══██║
╚██████╔╝██║   ██║   ██║  ██║██║  ██║██║ ╚═╝ ██║██║  ██║
 ╚═════╝ ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝

         🌿 AI-Powered Git Workflow v1.0.3 🌿
"""

VERSION = "1.0.3"

# ─── Register git wrapper commands at top level ───────────────────────────────
app.command()(chat)
app.command("ask")(chat)
app.command()(add)
app.command()(setup)
app.command()(push)
app.command()(pull)
app.command()(fetch)
app.command()(status)
app.command()(log)
app.command()(diff)
app.command()(merge)
app.command()(stash)
app.command()(reset)
app.command()(revert)


# ─── Main callback ────────────────────────────────────────────────────────────
@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False, "--version", "-v",
        help="Show version and exit",
        is_eager=True,
    ),
):
    """🌿 Gitrama — AI-Powered Git Workflow Automation"""
    if version:
        console.print(f"gitrama {VERSION}", style="bold green")
        raise typer.Exit(0)
    if ctx.invoked_subcommand is None:
        console.print(BANNER)
        console.print(ctx.get_help())
        raise typer.Exit(0)


# ─── Help command ─────────────────────────────────────────────────────────────
@app.command(name="help")
def help_command():
    """📖 Show help and all available commands."""
    console.print(BANNER)
    console.print("  [bold cyan]gtr --help[/bold cyan]              Full command reference")
    console.print("  [bold cyan]gtr <command> --help[/bold cyan]    Help for a specific command\n")
    console.print("[bold white]Core Commands:[/bold white]")
    console.print("  [green]gtr chat[/green]               Chat with AskG.I.T. about your repo")
    console.print("  [green]gtr commit[/green]             AI-powered commit message")
    console.print("  [green]gtr branch[/green]             AI-powered branch name")
    console.print("  [green]gtr pr[/green]                 AI-powered PR description")
    console.print("  [green]gtr summary[/green]            Summary of staged changes\n")
    console.print("[bold white]Git Commands:[/bold white]")
    console.print("  [green]gtr status[/green]             Git status")
    console.print("  [green]gtr add[/green]                Stage files")
    console.print("  [green]gtr push[/green]               Push to remote")
    console.print("  [green]gtr pull[/green]               Pull from remote")
    console.print("  [green]gtr log[/green]                Commit history")
    console.print("  [green]gtr diff[/green]               Show changes")
    console.print("  [green]gtr stash[/green]              Stash changes")
    console.print("  [green]gtr fetch[/green]              Fetch from remote\n")
    console.print("[bold white]Workflow:[/bold white]")
    console.print("  [green]gtr stream[/green]             Manage work streams")
    console.print("  [green]gtr checkout[/green]           Switch branches\n")
    console.print("[bold white]Shortcuts:[/bold white]")
    console.print("  [green]gtr c[/green]                  Shortcut for commit")
    console.print("  [green]gtr b[/green]                  Shortcut for branch")
    console.print("  [green]gtr s[/green]                  Shortcut for stream")
    console.print("  [green]gtr h[/green]                  Shortcut for health\n")
    console.print("[bold white]Other:[/bold white]")
    console.print("  [green]gtr config[/green]             Manage configuration")
    console.print("  [green]gtr health[/green]             Check AI server")
    console.print("  [green]gtr setup[/green]              Run setup wizard")
    console.print("  [green]gtr welcome[/green]            Quick start guide")
    console.print("  [green]gtr tips[/green]               Tips and best practices")
    console.print("  [green]gtr version[/green]            Show version\n")
    console.print("📚 [dim]https://gitrama.ai[/dim]\n")


# ─── AI Commands ──────────────────────────────────────────────────────────────
@app.command()
def commit(
    message: Optional[str] = typer.Option(
        None,
        "-m",
        "--message",
        help="Custom commit message (skips AI generation)"
    ),
    auto: bool = typer.Option(
        False,
        "-y",
        "--yes",
        help="Skip confirmation and commit immediately"
    )
):
    """
    🤖 Generate AI-powered commit messages

    Analyzes your staged changes and generates a conventional
    commit message following best practices.

    \b
    EXAMPLES:
      gtr commit              Interactive mode (default)
      gtr commit -y           Auto-commit without confirmation
      gtr commit -m "fix bug" Use custom message instead of AI

    \b
    REQUIREMENTS:
      • Stage changes first: gtr status
      • AI server must be running (check: gtr health)
    """
    try:
        if not has_staged_changes():
            console.print("❌ No staged changes found!", style="bold red")
            console.print("\n💡 Stage your changes first:", style="yellow")
            console.print("   git add <files>", style="white")
            console.print("\n🔧 Quick check:", style="dim")
            console.print("   gtr status  # See what's changed", style="dim")
            raise typer.Exit(1)

        if message:
            if commit_changes(message):
                console.print(f"✅ 🎉 Commit created successfully!", style="bold green")
                console.print(f"   📝 {message}", style="dim")
                console.print("\n💡 Next steps:", style="yellow")
                console.print("   • gtr pr   - Generate PR description", style="white")
                console.print("   • gtr push - Push to remote", style="white")
            else:
                console.print("❌ Failed to commit!", style="bold red")
                raise typer.Exit(1)
            return

        files = get_staged_files()
        diff_output = get_staged_diff()

        if not files or not diff_output:
            console.print("❌ No changes to commit!", style="bold red")
            raise typer.Exit(1)

        console.print(f"📝 Found {len(files)} file(s) staged", style="cyan")

        with console.status("[cyan]🤖 Generating commit message...", spinner="dots"):
            ai = AIClient()
            generated_message = ai.generate_commit_message(diff_output, files)

        if not generated_message:
            console.print("❌ Failed to generate commit message!", style="bold red")
            console.print("\n🔧 Troubleshooting:", style="yellow")
            console.print("   1. gtr health      - Check AI server status", style="white")
            console.print("   2. gtr config list - Verify configuration", style="white")
            console.print("\n📚 Help: https://gitrama.ai/docs", style="dim")
            raise typer.Exit(1)

        console.print("\n✨ Generated message:", style="bold green")
        console.print(f"   {generated_message}", style="bold white")
        console.print()

        if auto or typer.confirm("Use this message?", default=True):
            if commit_changes(generated_message):
                console.print("✅ 🎉 Commit created successfully!", style="bold green")
                console.print(f"   📝 {generated_message}", style="dim")
                console.print("\n💡 Next steps:", style="yellow")
                console.print("   • gtr pr   - Generate PR description", style="white")
                console.print("   • gtr push - Push to remote", style="white")
            else:
                console.print("❌ Failed to commit!", style="bold red")
                console.print("\n🔧 Try:", style="yellow")
                console.print("   gtr status", style="white")
                raise typer.Exit(1)
        else:
            console.print("❌ Commit cancelled", style="yellow")
            console.print("💡 Run again when ready, or use: gtr commit -m \"your message\"", style="dim")
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"\n❌ Error: {e}", style="bold red")
        console.print("\n🔧 Quick fixes:", style="yellow")
        console.print("   1. gtr health      - Check server status", style="white")
        console.print("   2. gtr status      - Verify staged changes", style="white")
        console.print("   3. gtr config list - Check configuration", style="white")
        console.print("\n📚 Need help? Visit: https://gitrama.ai/docs", style="dim")
        raise typer.Exit(1)


@app.command()
def branch(
    description: Optional[str] = typer.Argument(None, help="Branch description"),
    create: bool = typer.Option(True, "--create/--no-create", help="Create and switch to branch"),
    all_branches: bool = typer.Option(False, "--all", "-a", help="List all branches including remote"),
):
    """
    🌿 Generate AI-powered branch names

    Analyzes your description and generates a conventional
    branch name following best practices.

    \b
    EXAMPLES:
      gtr branch "Add user authentication"
      → feat/add-user-authentication

      gtr branch "Fix memory leak"
      → fix/memory-leak

      gtr branch "Update docs" --no-create
      → docs/update-docs (name only, doesn't create)
    """
    try:
       # No args or --all flag = list branches
        if description is None or all_branches:
            try:
                with console.status("Fetching remote branches...", spinner="dots"):
                    subprocess.run(["git", "fetch", "--all", "--prune"],
                                   capture_output=True, text=True, timeout=30)
                flag = "-a" if all_branches or description is None else ""
                result = subprocess.run(
                    ["git", "branch", "-a"],
                    capture_output=True, text=True, check=True
                )
                console.print("\n🌿 [bold]Branches (local + remote):[/bold]\n")
                console.print(result.stdout)
            except subprocess.CalledProcessError:
                console.print("❌ Warning: You are not in a git repository.  Please swich to a git repo enabled directory.", style="red")
            except subprocess.TimeoutExpired:
                console.print("⚠️ Fetch timed out — showing local branches only", style="yellow")
                result = subprocess.run(
                    ["git", "branch", "-a"],
                    capture_output=True, text=True
                )
                console.print(result.stdout)
            return

        with console.status("[cyan]🤖 Generating branch name...", spinner="dots"):
            ai = AIClient()
            branch_name = ai.generate_branch_name(description)

        if not branch_name:
            console.print("❌ Failed to generate branch name!", style="red")
            console.print("\n🔧 Try:", style="yellow")
            console.print("   • Simpler description", style="white")
            console.print("   • Check: gtr health", style="white")
            raise typer.Exit(1)

        console.print(f"✨ Generated: [bold green]{branch_name}[/bold green]")

        if branch_exists(branch_name):
            console.print(f"⚠️  Branch '{branch_name}' already exists!", style="yellow")
            if not typer.confirm("Switch to existing branch?"):
                console.print("❌ Aborted", style="red")
                raise typer.Exit(1)
            if checkout_branch(branch_name):
                console.print(f"✅ Switched to: [bold green]{branch_name}[/bold green]")
            else:
                console.print("❌ Failed to switch branch!", style="red")
                raise typer.Exit(1)
            return

        if create:
            console.print("🌿 Creating branch...", style="cyan")
            if create_branch(branch_name, checkout=True):
                console.print(f"✅ 🎉 Created and switched to: [bold green]{branch_name}[/bold green]")
                console.print("\n💡 Next steps:", style="yellow")
                console.print("   • Make your changes", style="white")
                console.print("   • gtr status  - See what changed", style="white")
                console.print("   • gtr commit  - Generate commit message", style="white")
            else:
                console.print("❌ Failed to create branch!", style="red")
                console.print("\n🔧 Check:", style="yellow")
                console.print("   gtr status", style="white")
                raise typer.Exit(1)
        else:
            console.print(f"\n💡 To create this branch, run:", style="yellow")
            console.print(f"   git checkout -b {branch_name}", style="white")

    except Exception as e:
        console.print(f"\n❌ Error: {e}", style="red")
        console.print("\n🔧 Quick fixes:", style="yellow")
        console.print("   1. gtr health - Check server status", style="white")
        console.print("   2. Try different description", style="white")
        console.print("   3. gtr config list - Check settings", style="white")
        console.print("\n📚 Need help? Visit: https://gitrama.ai/docs", style="dim")
        raise typer.Exit(1)


@app.command()
def checkout(
    target: str = typer.Argument(..., help="Branch name or commit hash"),
    create: bool = typer.Option(False, "--create", "-b", help="Create and switch to new branch"),
):
    """
    🔀 Switch branches or restore files.

    \b
    EXAMPLES:
      gtr checkout main           Switch to main
      gtr checkout -b feat/login  Create and switch to new branch
    """
    cmd = ["git", "checkout"]
    if create:
        cmd.append("-b")
    cmd.append(target)

    with console.status(f"🔀 Switching to {target}...", spinner="dots"):
        result = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")

    if result.returncode == 0:
        console.print(f"\n✅ Switched to {'new ' if create else ''}branch '[bold green]{target}[/bold green]'.")
    else:
        console.print(f"\n❌ Checkout failed:\n{result.stderr}", style="bold red")
        raise typer.Exit(1)


@app.command()
def pr(
    base: Optional[str] = typer.Option(
        None, "--base", "-b",
        help="Base branch to compare against (default: main/master)"
    ),
    copy: bool = typer.Option(
        True, "--copy/--no-copy",
        help="Copy to clipboard"
    ),
):
    """
    🔀 Generate AI-powered Pull Request descriptions

    Analyzes your branch commits and changes to generate
    a professional PR description with title and body.

    \b
    EXAMPLES:
      gtr pr                     Generate PR for current branch
      gtr pr --base develop      Compare against develop branch
      gtr pr --no-copy          Don't copy to clipboard
    """
    try:
        current_branch = get_current_branch()
        if not current_branch:
            console.print("❌ Could not determine current branch!", style="red")
            raise typer.Exit(1)

        if not base:
            base = get_default_branch()

        if current_branch == base:
            console.print(f"⚠️  You're on the base branch '{base}'!", style="yellow")
            console.print("\n💡 Switch to a feature branch first:", style="yellow")
            console.print(f"   gtr branch \"Your feature description\"", style="white")
            raise typer.Exit(1)

        console.print(f"🔍 Analyzing branch: [cyan]{current_branch}[/cyan]")
        console.print(f"   Comparing to: [dim]{base}[/dim]\n")

        commits = get_branch_commits(base)
        if not commits:
            console.print(f"❌ No commits found between {base} and {current_branch}!", style="red")
            console.print("\n💡 Make sure you have commits:", style="yellow")
            console.print("   gtr log", style="white")
            raise typer.Exit(1)

        console.print(f"📝 Found {len(commits)} commit(s)", style="green")
        console.print("📊 Analyzing changes...", style="cyan")
        total_diff = get_branch_diff(base)

        if not total_diff:
            console.print("⚠️  No diff found!", style="yellow")
            raise typer.Exit(1)

        with console.status("[cyan]🤖 Generating PR description...", spinner="dots"):
            ai = AIClient()
            pr_data = ai.generate_pr_description(commits, total_diff, current_branch)

        title = pr_data.get('title', '')
        description = pr_data.get('description', '')

        if not title or not description:
            console.print("\n❌ Failed to generate PR description!", style="red")
            console.print("\n🔧 Troubleshooting:", style="yellow")
            console.print("   1. gtr health - Check server status", style="white")
            console.print("   2. Verify commits: gtr log", style="white")
            raise typer.Exit(1)

        console.print("\n" + "=" * 60, style="green")
        console.print(f"{title}", style="bold green")
        console.print("=" * 60, style="green")
        console.print(description, style="white")
        console.print("=" * 60, style="green")

        if copy:
            try:
                import pyperclip
                pyperclip.copy(f"{title}\n\n{description}")
                console.print("\n✅ 📋 Copied to clipboard!", style="bold green")
                console.print("\n💡 Next steps:", style="yellow")
                console.print("   1. Go to GitHub/GitLab", style="white")
                console.print("   2. Create new Pull Request", style="white")
                console.print("   3. Paste (Ctrl+V / Cmd+V)", style="white")
                console.print("   4. Review and submit! 🚀", style="white")
            except ImportError:
                console.print("\n💡 Install pyperclip for clipboard support:", style="yellow")
                console.print("   pip install pyperclip", style="dim")
            except Exception:
                console.print("\n⚠️  Couldn't copy to clipboard", style="yellow")
                console.print("💡 Copy manually from above", style="dim")

        console.print("\n💚 PR description ready!", style="bold green")

    except subprocess.CalledProcessError as e:
        console.print(f"\n❌ Git error: {e}", style="red")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"\n❌ Error: {e}", style="red")
        console.print("\n🔧 Quick fixes:", style="yellow")
        console.print("   1. gtr health - Check server", style="white")
        console.print("   2. gtr status - Verify repo state", style="white")
        raise typer.Exit(1)


@app.command()
def summary():
    """
    📊 Quick summary of staged changes

    \b
    EXAMPLES:
      gtr summary            Show summary of staged changes
    """
    try:
        files = get_staged_files()
        if not files:
            console.print("❌ No staged changes!", style="red")
            console.print("\n💡 Stage your changes first:", style="yellow")
            console.print("   git add <files>", style="white")
            console.print("\n🔧 See what's changed:", style="dim")
            console.print("   gtr status", style="dim")
            raise typer.Exit(1)

        try:
            diff_output = get_staged_diff()
            if not diff_output:
                diff_output = ""
        except Exception:
            diff_output = ""

        additions = diff_output.count('\n+') if diff_output else 0
        deletions = diff_output.count('\n-') if diff_output else 0
        net_change = additions - deletions

        console.print("\n📊 Change Summary:", style="bold cyan")
        console.print()
        console.print(f"  📁 Files changed: {len(files)}", style="white")

        if diff_output:
            console.print(f"  ➕ Lines added:   +{additions}", style="green")
            console.print(f"  ➖ Lines removed: -{deletions}", style="red")
            console.print(f"  📈 Net change:    {net_change:+d}", style="yellow")
        else:
            console.print(f"  ℹ️  Line counts unavailable", style="dim")

        console.print()
        console.print("📁 Modified files:", style="bold white")
        for i, file in enumerate(files[:10], 1):
            console.print(f"   {i}. {file}", style="cyan")

        if len(files) > 10:
            console.print(f"   ... and {len(files) - 10} more", style="dim")

        console.print("\n💡 Next steps:", style="yellow")
        console.print("   • gtr commit - Generate commit message", style="white")
        console.print("   • gtr diff   - See detailed changes", style="white")
        console.print()

    except Exception as e:
        console.print(f"\n❌ Error: {e}", style="red")
        console.print("\n🔧 Quick check:", style="yellow")
        console.print("   gtr status", style="white")
        raise typer.Exit(1)


@app.command()
def stream(
    action: Optional[str] = typer.Argument(None, help="Action: list, switch, create, delete, status"),
    name: Optional[str] = typer.Argument(None, help="Stream name"),
    description: Optional[str] = typer.Option(None, "--desc", "-d", help="Stream description"),
):
    """
    🌊 Manage work streams (WIP, hotfix, etc.)

    \b
    EXAMPLES:
      gtr stream list
      gtr stream switch hotfix
      gtr stream switch wip
      gtr stream create epic --desc "Epic feature work"
      gtr stream delete epic
      gtr stream status

    \b
    DEFAULT STREAMS:
      • wip        Work in Progress
      • hotfix     Urgent bug fixes
      • review     Code review changes
      • experiment Try new ideas safely
    """
    try:
        manager = StreamManager()

        if action is None or action == "status":
            manager.status()
        elif action == "list":
            manager.list_streams()
        elif action == "switch":
            if not name:
                console.print("❌ Stream name required!", style="red")
                console.print("   gtr stream switch <name>", style="white")
                raise typer.Exit(1)
            manager.switch_stream(name)
        elif action == "create":
            if not name:
                console.print("❌ Stream name required!", style="red")
                console.print("   gtr stream create <name> --desc 'Description'", style="white")
                raise typer.Exit(1)
            manager.create_stream(name, description or "Custom stream")
        elif action == "delete":
            if not name:
                console.print("❌ Stream name required!", style="red")
                console.print("   gtr stream delete <name>", style="white")
                raise typer.Exit(1)
            manager.delete_stream(name)
        elif action == "status":
            manager.status()
        elif action == "merge":
            if not name:
                console.print("❌ Target branch required!", style="red")
                console.print("   gtr stream merge <target_branch>", style="white")
                console.print("   Example: gtr stream merge main", style="white")
                raise typer.Exit(1)
            manager.merge_stream(name)
        else:
            console.print(f"❌ Unknown action: {action}", style="red")
            console.print("\n💡 Valid actions: list, switch, create, delete, status", style="yellow")
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"\n❌ Error: {e}", style="red")
        console.print("\n🔧 Try:", style="yellow")
        console.print("   gtr stream list  - See all streams", style="white")
        raise typer.Exit(1)


@app.command()
def health():
    """
    💚 Check AI server health status

    \b
    EXAMPLES:
      gtr health         Check server status
    """
    console.print("🔍 Checking AI server...", style="cyan")

    try:
        ai = AIClient()
        console.print(f"📡 API URL: {ai.api_url}", style="dim")
        result = ai.health_check()

        if result and result.get("status") == "healthy":
            console.print("\n✅ AI server is healthy!", style="bold green")
            console.print(f"   🤖 Model: {result.get('model', 'Unknown')}", style="white")
            console.print(f"   🌐 Connected to: {ai.api_url}", style="dim")
            console.print("\n💡 You're ready to use Gitrama!", style="yellow")
        else:
            console.print("\n❌ AI server returned unexpected response!", style="bold red")
            console.print(f"   Response: {result}", style="dim")
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"\n❌ Error connecting to AI server!", style="bold red")
        console.print(f"   Details: {str(e)}", style="red")
        console.print("\n🔧 Troubleshooting:", style="yellow")
        console.print("   1. gtr config list - Verify provider and api_url", style="white")
        console.print("   2. gtr config set provider anthropic", style="white")
        console.print("\n📚 Need help? Visit: https://gitrama.ai/docs", style="dim")
        raise typer.Exit(1)


@app.command()
def config(
    action: str = typer.Argument(..., help="Action: set, get, list, or reset"),
    key: Optional[str] = typer.Argument(None, help="Configuration key"),
    value: Optional[str] = typer.Argument(None, help="Configuration value"),
):
    """
    ⚙️  Manage Gitrama configuration

    \b
    EXAMPLES:
      gtr config list
      gtr config get api_url
      gtr config set provider anthropic
      gtr config reset

    \b
    AVAILABLE SETTINGS:
      • provider     AI provider: gitrama | openai | anthropic | ollama
      • api_key      Your API key
      • model        Model override
      • auto_commit  Skip confirmation (true/false)
      • timeout      Request timeout in seconds
    """
    if action == "set":
        if not key or not value:
            console.print("❌ Usage: gtr config set <key> <value>", style="red")
            raise typer.Exit(1)

        if key == "provider":
            from .config import set_provider
            try:
                url = set_provider(value)
                console.print(f"✅ Provider set to: {value}", style="bold green")
                console.print(f"   🌐 API URL auto-set to: {url}", style="cyan")
            except ValueError as e:
                console.print(f"❌ {e}", style="bold red")
                raise typer.Exit(1)
        else:
            set_value(key, value)
            console.print(f"✅ Set {key} = {value}", style="green")

    elif action == "get":
        if not key:
            console.print("❌ Usage: gtr config get <key>", style="red")
            raise typer.Exit(1)
        val = get_value(key)
        if val is None:
            console.print(f"❌ Key '{key}' not found", style="red")
        else:
            console.print(f"{key} = {val}", style="cyan")

    elif action == "list":
        cfg = load_config()
        console.print("\n📋 Current Configuration:", style="bold cyan")
        console.print()
        _SENSITIVE_KEYS = {"gitrama_token", "api_key", "token", "secret", "password"}
        for k, v in cfg.items():
            if k.lower() in _SENSITIVE_KEYS and v:
                masked = v[:4] + "••••" + v[-4:] if len(v) > 8 else "••••••••"
                console.print(f"  {k}: {masked}", style="white")
            else:
                console.print(f"  {k}: {v}", style="white")
        console.print()

    elif action == "reset":
        reset_config()
        console.print("✅ Configuration reset to defaults", style="green")

    else:
        console.print(f"❌ Unknown action: {action}", style="red")
        console.print("Valid actions: set, get, list, reset", style="yellow")
        raise typer.Exit(1)


@app.command()
def version():
    """📦 Show Gitrama version."""
    console.print(BANNER, style="bold green")
    console.print(f"Version: {VERSION}", style="cyan")
    console.print("Python: 3.11+", style="dim")
    console.print("\n💡 https://gitrama.ai", style="yellow")


@app.command()
def welcome():
    """👋 Show welcome banner and quick start."""
    console.print(BANNER, style="bold green")
    console.print("Welcome to Gitrama! 🎉\n", style="bold cyan")
    console.print("Quick Start:", style="bold white")
    console.print("  gtr status             See what changed", style="white")
    console.print("  gtr commit             AI commit message", style="white")
    console.print("  gtr push               Push to remote", style="white")
    console.print("  gtr pull               Pull latest", style="white")
    console.print("  gtr branch 'desc'      AI branch name", style="white")
    console.print("  gtr pr                 AI PR description", style="white")
    console.print("  gtr stream switch wip  Switch context", style="white")
    console.print("  gtr log                Commit history", style="white")
    console.print("  gtr diff               See changes", style="white")
    console.print("\n💡 Type 'gtr --help' for all commands", style="yellow")
    console.print("📚 Docs: https://gitrama.ai\n", style="dim")


@app.command()
def tips():
    """💡 Show helpful tips and best practices."""
    console.print("\n💡 Gitrama Tips & Best Practices\n", style="bold cyan")
    console.print("1. Stage intentionally", style="bold white")
    console.print("   Group related changes for better commit messages", style="dim")
    console.print("   Example: git add auth.py login.py\n", style="green")
    console.print("2. Review before committing", style="bold white")
    console.print("   Always review the AI-generated message", style="dim")
    console.print("   Edit if needed before confirming\n", style="green")
    console.print("3. Use conventional commits", style="bold white")
    console.print("   Gitrama follows conventional commits automatically", style="dim")
    console.print("   Types: feat, fix, docs, refactor, test, chore\n", style="green")
    console.print("4. Use streams for context switching", style="bold white")
    console.print("   Switch between tasks without stashing", style="dim")
    console.print("   Example: gtr stream switch hotfix\n", style="green")
    console.print("5. Replace git with gtr", style="bold white")
    console.print("   gtr push, gtr pull, gtr log, gtr diff...", style="dim")
    console.print("   Everything you need, AI-enhanced 🌿\n", style="green")
    console.print("💚 Happy committing!\n", style="bold green")


# ─── Shortcuts ────────────────────────────────────────────────────────────────

@app.command(name="c")
def commit_alias(
    message: Optional[str] = typer.Option(None, "-m", "--message"),
    auto: bool = typer.Option(False, "-y", "--yes")
):
    """Shortcut for 'gtr commit'"""
    commit(message=message, auto=auto)


@app.command(name="h")
def health_alias():
    """Shortcut for 'gtr health'"""
    health()


@app.command(name="b")
def branch_alias(
    description: str = typer.Argument(...),
    create: bool = typer.Option(True, "--create/--no-create")
):
    """Shortcut for 'gtr branch'"""
    branch(description=description, create=create)


@app.command(name="s")
def stream_alias(
    action: str = typer.Argument(...),
    name: Optional[str] = typer.Argument(None),
    description: Optional[str] = typer.Option(None, "--desc", "-d"),
):
    """Shortcut for 'gtr stream'"""
    stream(action=action, name=name, description=description)


if __name__ == "__main__":
    app()
