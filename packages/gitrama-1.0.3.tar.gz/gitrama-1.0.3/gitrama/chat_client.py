"""
Gitrama AskGIT - Thin Chat Client
Ships in pip package. Contains zero IP.
All intelligence lives at api.gitrama.ai.

Copyright © 2026 Gitrama LLC. All Rights Reserved.
"""

import os
import re
import subprocess
import platform
from typing import Optional, List

import typer
import requests
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule

from .config import get_value
from .streams import StreamManager

console = Console()

# ─── Server config ────────────────────────────────────────────────────────────
CHAT_SERVER_URL = "https://api.gitrama.ai"
REQUEST_TIMEOUT = 30

# ─── Runtime config — fetched from server, not hardcoded ─────────────────────
# These are populated by _load_server_config() at session start.
# Nothing valuable lives here in the shipped package.
SAFE_COMMANDS: dict = {}
BLOCKED_COMMANDS: list = []
INTENT_MAP: list = []

# ─── Minimal fallback config (used only if server is unreachable) ─────────────
# Intentionally sparse — just enough to not crash. No real logic exposed.
_FALLBACK_SAFE_COMMANDS = {
    # ── gtr commands ──
    "gtr status":     {"args": False, "confirm": False, "category": "read"},
    "gtr log":        {"args": True,  "confirm": False, "category": "read"},
    "gtr diff":       {"args": True,  "confirm": False, "category": "read"},
    "gtr add":        {"args": True,  "confirm": True,  "category": "write"},
    "gtr commit":     {"args": True,  "confirm": True,  "category": "write"},
    "gtr push":       {"args": True,  "confirm": True,  "category": "write"},
    "gtr branch":     {"args": True,  "confirm": False, "category": "read"},
    "gtr stream":     {"args": True,  "confirm": False, "category": "read"},
    "gtr health":     {"args": False, "confirm": False, "category": "read"},
    "gtr compare":    {"args": True,  "confirm": False, "category": "read"},
    "gtr pr":         {"args": False, "confirm": True,  "category": "write"},
    # ── git read commands (safe, no confirmation needed) ──
    "git branch":     {"args": True,  "confirm": False, "category": "read"},
    "git log":        {"args": True,  "confirm": False, "category": "read"},
    "git status":     {"args": False, "confirm": False, "category": "read"},
    "git diff":       {"args": True,  "confirm": False, "category": "read"},
    "git shortlog":   {"args": True,  "confirm": False, "category": "read"},
    "git rev-list":   {"args": True,  "confirm": False, "category": "read"},
    "git ls-files":   {"args": True,  "confirm": False, "category": "read"},
    "git show":       {"args": True,  "confirm": False, "category": "read"},
    "git grep":       {"args": True,  "confirm": False, "category": "read"},
    "git stash list": {"args": False, "confirm": False, "category": "read"},
    "git tag":        {"args": True,  "confirm": False, "category": "read"},
    "git remote":     {"args": True,  "confirm": False, "category": "read"},
    "git blame":      {"args": True,  "confirm": False, "category": "read"},
    "git config":     {"args": True,  "confirm": False, "category": "read"},
    # ── git write commands (need confirmation) ──
    "git checkout":   {"args": True,  "confirm": True,  "category": "write"},
    "git switch":     {"args": True,  "confirm": True,  "category": "write"},
    "git stash push": {"args": True,  "confirm": True,  "category": "write"},
    "git stash pop":  {"args": False, "confirm": True,  "category": "write"},
    # ── system read commands (safe) ──
    "git rev-parse":  {"args": True,  "confirm": False, "category": "read"},
    "find .":         {"args": True,  "confirm": False, "category": "read"},
}

_FALLBACK_BLOCKED = ["rm", "del", "format", "shutdown", "reboot", "mkfs",
                     "git push --force", "git reset --hard"]

_FALLBACK_INTENT = [
    # ── Branch operations ──
    (["list branches", "show branches", "all branches", "how many branches",
      "what branches", "branch list"], "git branch -a"),
    (["latest branch", "newest branch", "recently created branch",
      "last created branch", "most recent branch"], "git branch -a --sort=-creatordate"),
    # ── Status & info ──
    (["status", "what's changed", "show status", "my status"], "gtr status"),
    (["show log", "recent commits", "last commits", "commit history",
      "show commits"], "gtr log"),
    # ── Repo stats ──
    (["how many files", "file count", "number of files", "total files"], "__builtin_file_count__"),
    (["how many commits", "total commits", "commit count"], "git rev-list --count HEAD"),
    (["contributors", "who contributed", "authors", "who worked"], "git shortlog -sn --no-merges"),
    (["repo age", "when was this repo created", "first commit"], "git log --reverse --oneline -1"),
    # ── Merge history ──
    (["last merges", "recent merges", "merge history", "show merges",
      "last ten merges", "last 10 merges"], "git log --merges --oneline -10"),
    # ── Staging & committing ──
    (["stage all", "add all", "stage everything", "stage my files"], "gtr add ."),
    (["stage and commit", "add and commit"], "gtr add . && gtr commit --yes"),
    (["push my changes", "push to remote", "push it"], "gtr push"),
    # ── Repo/directory info ──
    (["which directory", "what directory", "where am i", "what repo",
      "which repo", "current directory", "current repo", "what project",
      "which project", "pwd", "repo root", "repo path"], "git rev-parse --show-toplevel"),
]


def _load_server_config(token: str) -> bool:
    """
    Fetch INTENT_MAP, SAFE_COMMANDS, BLOCKED_COMMANDS from api.gitrama.ai/config.
    Populates module-level globals at session start.
    Returns True if loaded from server, False if using fallback.
    """
    global SAFE_COMMANDS, BLOCKED_COMMANDS, INTENT_MAP
    try:
        response = requests.get(
            f"{CHAT_SERVER_URL}/config",
            headers={"x-gitrama-token": token},
            timeout=10,
        )
        if response.status_code == 200:
            data = response.json()
            # INTENT_MAP comes back as list of [triggers_list, command] pairs
            INTENT_MAP = [
                (item[0], item[1]) for item in data.get("intent_map", [])
            ]
            SAFE_COMMANDS = data.get("safe_commands", _FALLBACK_SAFE_COMMANDS)
            BLOCKED_COMMANDS = data.get("blocked_commands", _FALLBACK_BLOCKED)

            # Normalize SAFE_COMMANDS: server may return a flat list of strings
            # but _is_command_safe() expects a dict with metadata.
            # If it's a list, convert to dict using fallback metadata where available.
            if isinstance(SAFE_COMMANDS, list):
                normalized = {}
                for cmd in SAFE_COMMANDS:
                    if cmd in _FALLBACK_SAFE_COMMANDS:
                        normalized[cmd] = _FALLBACK_SAFE_COMMANDS[cmd]
                    else:
                        # Unknown command from server — default to read, allow args, no confirm
                        normalized[cmd] = {"args": True, "confirm": False, "category": "read"}
                SAFE_COMMANDS = normalized

            # Merge fallback commands into server set — ensures critical client-side
            # commands (git config, etc.) are always available even if server config
            # hasn't been updated yet. Server values take precedence for duplicates.
            for cmd, meta in _FALLBACK_SAFE_COMMANDS.items():
                if cmd not in SAFE_COMMANDS:
                    SAFE_COMMANDS[cmd] = meta

            # Fix #19: Force-patch — any intent with | wc must use builtin instead
            # This protects Windows even if the server config hasn't been updated yet
            _WC_BUILTIN_MAP = {
                "git ls-files | wc -l": "__builtin_file_count__",
            }
            INTENT_MAP = [
                (triggers, _WC_BUILTIN_MAP.get(cmd, cmd))
                for triggers, cmd in INTENT_MAP
            ]
            # Also ensure wc never appears in safe commands
            SAFE_COMMANDS.pop("wc", None)

            return True
        else:
            SAFE_COMMANDS = _FALLBACK_SAFE_COMMANDS
            BLOCKED_COMMANDS = _FALLBACK_BLOCKED
            INTENT_MAP = _FALLBACK_INTENT
            return False
    except Exception:
        SAFE_COMMANDS = _FALLBACK_SAFE_COMMANDS
        BLOCKED_COMMANDS = _FALLBACK_BLOCKED
        INTENT_MAP = _FALLBACK_INTENT
        return False


# ─── Git helpers (all run locally) ───────────────────────────────────────────
def _run(cmd: List[str], timeout: int = 10) -> str:
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=timeout, encoding="utf-8", errors="replace"
        )
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        return ""
    except Exception:
        return ""


def _is_git_repo() -> bool:
    """Check if current directory is inside a git repo."""
    result = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        capture_output=True, text=True
    )
    return result.returncode == 0


def _get_repo_context() -> dict:
    """Load repo context with timeouts to prevent hanging on large repos."""
    ctx = {}
    ctx["repo_root"]    = _run(["git", "rev-parse", "--show-toplevel"])
    ctx["branch"]       = _run(["git", "rev-parse", "--abbrev-ref", "HEAD"])
    ctx["remote"]       = _run(["git", "remote", "get-url", "origin"])
    ctx["commits"]      = _run(["git", "log", "--oneline", "-20"], timeout=15)
    ctx["status"]       = _run(["git", "status", "--porcelain"], timeout=10)
    ctx["stashes"]      = _run(["git", "stash", "list"])
    ctx["os"]           = platform.system()
    ctx["staged"]       = _run(["git", "diff", "--staged", "--name-only"], timeout=10) or "none"
    ctx["modified"]     = _run(["git", "diff", "--name-only"], timeout=10) or "none"
    ctx["contributors"] = _run(["git", "shortlog", "-sn", "--no-merges", "-10"], timeout=15)
    try:
        manager = StreamManager()
        ctx["stream"] = manager.data.get("current", "wip")
    except Exception:
        ctx["stream"] = "unknown"
    return ctx


def _get_repo_stats() -> str:
    total_commits = _run(["git", "rev-list", "--count", "HEAD"], timeout=15)
    first_commit  = _run(["git", "log", "--reverse", "--pretty=format:%ad", "--date=short", "-1"], timeout=15)
    total_authors = len(set(_run(["git", "log", "--pretty=format:%ae"], timeout=15).splitlines()))
    file_count    = len(_run(["git", "ls-files"], timeout=15).splitlines())
    branches      = _run(["git", "branch", "-a", "--format=%(refname:short)"], timeout=10)
    branch_count  = len([b for b in branches.splitlines() if b.strip()])
    return (
        f"Total commits: {total_commits} | First commit: {first_commit} | "
        f"Authors: {total_authors} | Files: {file_count} | Branches: {branch_count}"
    )


def _build_git_context_string(ctx: dict) -> str:
    """Format repo context into a string to send to server."""
    return f"""Branch: {ctx.get('branch', 'unknown')}
Branch: {ctx.get('branch', 'unknown')}    
Remote: {ctx.get('remote', 'unknown')}
Stream: {ctx.get('stream', 'unknown')}

Recent commits (last 20):
{ctx.get('commits', 'No commits found')}

Status: {ctx.get('status', 'Clean')}
Staged: {ctx.get('staged', 'none')}
Modified: {ctx.get('modified', 'none')}
Stashes: {ctx.get('stashes', 'none')}
Top contributors:
{ctx.get('contributors', 'unknown')}"""


def _fetch_file_diff(filepath: str) -> str:
    result = _run(["git", "diff", "HEAD", "--", filepath])
    if not result:
        result = _run(["git", "diff", "--staged", "--", filepath])
    return result or f"No changes detected in {filepath}"


def _fetch_file_log(filepath: str, count: int = 10) -> str:
    return _run(["git", "log", "--oneline", f"-{count}", "--follow", "--", filepath])


def _fetch_file_content(filepath: str) -> str:
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
        if len(lines) > 200:
            return "".join(lines[:200]) + f"\n... (truncated, {len(lines)} total lines)"
        return "".join(lines)
    except FileNotFoundError:
        return f"File not found: {filepath}"
    except Exception as e:
        return f"Could not read file: {e}"


def _fetch_branch_diff(base: str, target: str = None) -> str:
    if target:
        return _run(["git", "diff", f"{base}...{target}"])
    return _run(["git", "diff", base])


def _fetch_full_history(limit: int = 500) -> str:
    return _run([
        "git", "log", "--pretty=format:%h|%an|%ae|%ad|%s",
        "--date=short", f"-{limit}"
    ], timeout=30)


def _fetch_author_history(author: str, limit: int = 100) -> str:
    return _run([
        "git", "log", f"--author={author}",
        "--pretty=format:%h|%ad|%s", "--date=short", f"-{limit}"
    ], timeout=20)


def _fetch_date_range_history(after: str, before: str = None) -> str:
    cmd = [
        "git", "log", "--pretty=format:%h|%an|%ad|%s",
        "--date=short", f"--after={after}",
    ]
    if before:
        cmd.append(f"--before={before}")
    return _run(cmd, timeout=20)


def _fetch_full_file_history(filepath: str) -> str:
    return _run([
        "git", "log", "--follow",
        "--pretty=format:%h|%an|%ad|%s",
        "--date=short", "--", filepath
    ], timeout=20)


# ─── Context enrichment (runs locally, appended to message) ──────────────────
def _enrich_prompt_with_context(user_input: str) -> str:
    extra = []
    lower = user_input.lower()
    file_pattern = re.compile(
        r'[\w/.-]+\.(?:py|js|ts|jsx|tsx|json|md|yaml|yml|txt|sh|env|toml|cfg|ini|html|css)'
    )
    full_files = file_pattern.findall(user_input)

    if any(w in lower for w in ["diff", "compare", "changed", "difference", "vs", "versus"]):
        for filepath in full_files:
            diff = _fetch_file_diff(filepath)
            if diff:
                extra.append(f"\n### Current diff for `{filepath}`:\n```\n{diff[:3000]}\n```")

    if any(w in lower for w in ["history", "log", "commits for", "who changed", "when was", "last modified"]):
        for filepath in full_files:
            log = _fetch_file_log(filepath)
            if log:
                extra.append(f"\n### Commit history for `{filepath}`:\n```\n{log}\n```")

    if any(w in lower for w in ["show me", "read", "content of", "what's in", "open", "display"]):
        for filepath in full_files:
            content = _fetch_file_content(filepath)
            extra.append(f"\n### Content of `{filepath}`:\n```\n{content}\n```")

    branch_diff_match = re.search(r'diff\s+(\S+)\s+(?:vs|versus|and|to)\s+(\S+)', lower)
    if branch_diff_match:
        base = branch_diff_match.group(1)
        target = branch_diff_match.group(2)
        diff = _fetch_branch_diff(base, target)
        if diff:
            extra.append(f"\n### Diff between `{base}` and `{target}`:\n```\n{diff[:3000]}\n```")

    if any(w in lower for w in ["staged", "about to commit", "what am i committing"]):
        staged_diff = _run(["git", "diff", "--staged"])
        if staged_diff:
            extra.append(f"\n### Currently staged changes:\n```\n{staged_diff[:3000]}\n```")

    if any(w in lower for w in ["full status", "detailed status", "what's changed"]):
        full_status = _run(["git", "status"])
        if full_status:
            extra.append(f"\n### Full git status:\n```\n{full_status}\n```")

    return "\n".join(extra)


def _deep_enrich_prompt(user_input: str) -> str:
    import datetime
    extra = []
    lower = user_input.lower()

    file_pattern = re.compile(
        r'[\w/.-]+\.(?:py|js|ts|jsx|tsx|json|md|yaml|yml|txt|sh|env|toml|cfg|ini|html|css)'
    )
    full_files = file_pattern.findall(user_input)

    if full_files and any(w in lower for w in [
        "history", "log", "changed", "touched", "modified",
        "evolution", "commits for", "who changed", "when was"
    ]):
        for filepath in full_files:
            log = _fetch_full_file_history(filepath)
            if log:
                extra.append(
                    f"\n### Full history of `{filepath}` (every commit ever):\n"
                    f"Format: hash|author|date|message\n```\n{log[:4000]}\n```"
                )

    author_patterns = [
        r"(?:by|from|author|commits? by|work by|what did|show me)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)",
        r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)'s\s+commits?",
    ]
    for pattern in author_patterns:
        match = re.search(pattern, user_input)
        if match:
            author = match.group(1)
            log = _fetch_author_history(author)
            if log:
                extra.append(
                    f"\n### All commits by `{author}`:\n"
                    f"Format: hash|date|message\n```\n{log[:4000]}\n```"
                )
            break

    month_map = {
        "january": "01", "february": "02", "march": "03", "april": "04",
        "may": "05", "june": "06", "july": "07", "august": "08",
        "september": "09", "october": "10", "november": "11", "december": "12",
        "jan": "01", "feb": "02", "mar": "03", "apr": "04",
        "jun": "06", "jul": "07", "aug": "08",
        "sep": "09", "oct": "10", "nov": "11", "dec": "12"
    }

    month_year = re.search(
        r'(january|february|march|april|may|june|july|august|september|october|november|december|'
        r'jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\s+(\d{4})', lower
    )
    if month_year:
        month = month_map[month_year.group(1)]
        year = month_year.group(2)
        after = f"{year}-{month}-01"
        next_month = int(month) + 1
        next_year = year
        if next_month > 12:
            next_month = 1
            next_year = str(int(year) + 1)
        before = f"{next_year}-{next_month:02d}-01"
        log = _fetch_date_range_history(after, before)
        if log:
            extra.append(
                f"\n### Commits from {month_year.group(1).capitalize()} {year}:\n"
                f"```\n{log[:4000]}\n```"
            )

    quarter = re.search(r'q([1-4])\s*(\d{4})', lower)
    if quarter:
        q = int(quarter.group(1))
        year = quarter.group(2)
        quarter_starts = {"1": "01", "2": "04", "3": "07", "4": "10"}
        quarter_ends = {"1": "04", "2": "07", "3": "10", "4": "01"}
        after = f"{year}-{quarter_starts[str(q)]}-01"
        end_year = str(int(year) + 1) if q == 4 else year
        before = f"{end_year}-{quarter_ends[str(q)]}-01"
        log = _fetch_date_range_history(after, before)
        if log:
            extra.append(f"\n### Commits from Q{q} {year}:\n```\n{log[:4000]}\n```")

    if "last year" in lower or "previous year" in lower:
        year = datetime.datetime.now().year - 1
        log = _fetch_date_range_history(f"{year}-01-01", f"{year+1}-01-01")
        if log:
            extra.append(f"\n### All commits from {year}:\n```\n{log[:4000]}\n```")

    if "this year" in lower:
        year = datetime.datetime.now().year
        log = _fetch_date_range_history(f"{year}-01-01")
        if log:
            extra.append(f"\n### All commits so far in {year}:\n```\n{log[:4000]}\n```")

    since_date = re.search(r'(?:since|after|from)\s+(\d{4}-\d{2}-\d{2})', lower)
    if since_date:
        log = _fetch_date_range_history(since_date.group(1))
        if log:
            extra.append(f"\n### Commits since {since_date.group(1)}:\n```\n{log[:4000]}\n```")

    if any(w in lower for w in [
        "all commits", "full history", "entire history",
        "every commit", "show all", "whole history",
        "complete history", "all changes"
    ]):
        log = _fetch_full_history(200)
        if log:
            extra.append(
                f"\n### Full repo commit history (last 200):\n"
                f"Format: hash|author|email|date|message\n```\n{log[:5000]}\n```"
            )

    return "\n".join(extra)


# ─── Command execution (stays client-side — runs on their machine) ────────────
def _extract_commands_from_response(response: str) -> List[str]:
    """Extract executable commands from AI response. Supports gtr, git, find."""
    # [EXECUTE: <command>] tags — strip these so they never leak to user
    commands = re.findall(r'\[EXECUTE:\s*([^\]]+)\]', response)
    # Also catch malformed variants: [EXECUTE <command>], [execute: <command>]
    commands += re.findall(r'\[(?:EXECUTE|execute)\s*:?\s*([^\]]+)\]', response)
    # Code blocks with gtr/git/find commands
    code_cmds = re.findall(
        r'```(?:bash|powershell|shell)?\s*\n?((?:gtr|git|find)\s[^\n`]+)',
        response
    )
    commands.extend(code_cmds)
    # Deduplicate while preserving order
    seen = set()
    unique = []
    for cmd in commands:
        c = cmd.strip()
        if c and c not in seen:
            seen.add(c)
            unique.append(c)
    return unique


def _sanitize_response(response: str) -> str:
    """Fix #20: Strip all EXECUTE tag variants from AI responses before displaying to user."""
    # Remove [EXECUTE: ...] tags — fully case-insensitive, handles malformed variants
    cleaned = re.sub(r'\[execute\s*:?\s*[^\]]*\]', '', response, flags=re.IGNORECASE)
    # Remove any double-blank-lines left behind
    cleaned = re.sub(r'\n{3,}', '\n\n', cleaned)
    return cleaned.strip()


def _fix_windows_quotes(command: str) -> str:
    """Fix #20: Replace problematic double quotes in git format strings on Windows."""
    if platform.system() != "Windows":
        return command
    # git log/show format strings: swap inner double quotes for single quotes
    # e.g., git log --format="%H %s" → git log --format='%H %s'
    if "--format=" in command or "--pretty=" in command:
        command = re.sub(r'--(?:format|pretty)="([^"]*)"', r"--format='\1'", command)
    return command


def _is_command_safe(command: str) -> tuple:
    """Check if command is safe to execute. Returns (is_safe, needs_confirm, category)."""
    cmd_lower = command.lower().strip()

    # Builtin commands are always safe
    if cmd_lower.startswith("__builtin_"):
        return True, False, "read"

    # Block dangerous commands
    for blocked in BLOCKED_COMMANDS:
        if blocked in cmd_lower:
            return False, False, f"'{blocked}' is blocked for safety"

    # Fix: Block Unix-only commands on Windows before they hit subprocess
    if platform.system() == "Windows":
        _UNIX_ONLY = ["cat ", "head ", "tail ", "wc ", "grep ", "sed ", "awk ",
                       "xargs ", "cat\t", "head\t", "tail\t"]
        first_token = cmd_lower.split()[0] if cmd_lower.split() else ""
        if first_token in ("cat", "head", "tail", "wc", "grep", "sed", "awk", "xargs"):
            return False, False, f"'{first_token}' is a Unix command not available on Windows"
        # Also catch piped Unix commands (e.g., "git ls-files | wc -l")
        if "|" in cmd_lower:
            pipe_target = cmd_lower.split("|")[-1].strip().split()[0] if cmd_lower.split("|")[-1].strip() else ""
            if pipe_target in ("wc", "head", "tail", "grep", "sed", "awk", "xargs", "cat"):
                return False, False, f"'{pipe_target}' is a Unix command not available on Windows"

    # Check against safe commands list
    for safe_cmd, meta in SAFE_COMMANDS.items():
        if cmd_lower == safe_cmd or (meta.get("args") and cmd_lower.startswith(safe_cmd)):
            return True, meta.get("confirm", False), meta.get("category", "read")

    # Allow piped commands where base command is safe (e.g., git branch -a | findstr discord)
    base_cmd = cmd_lower.split("|")[0].strip()
    for safe_cmd, meta in SAFE_COMMANDS.items():
        if base_cmd == safe_cmd or (meta.get("args") and base_cmd.startswith(safe_cmd)):
            return True, meta.get("confirm", False), meta.get("category", "read")

    return False, False, "Command not in AskG.I.T.'s approved execution list"


def _run_gtr_command(command: str) -> str:
    # ── Builtin handlers: cross-platform replacements for piped Unix commands ──
    if command == "__builtin_file_count__":
        try:
            result = subprocess.run(
                ["git", "ls-files"], capture_output=True, text=True,
                timeout=30, encoding="utf-8", errors="replace"
            )
            files = [f for f in result.stdout.strip().split("\n") if f.strip()]
            return f"This repository contains {len(files)} tracked file(s)."
        except Exception as e:
            return f"Could not count files: {e}"

    try:
        # Fix #20: Fix Windows quote escaping before execution
        command = _fix_windows_quotes(command)
        if "&&" in command:
            parts = [p.strip() for p in command.split("&&")]
            outputs = []
            for part in parts:
                result = subprocess.run(
                    part, shell=True, capture_output=True, text=True,
                    timeout=60, encoding="utf-8", errors="replace"
                )
                output = result.stdout.strip() or result.stderr.strip()
                outputs.append(f"$ {part}\n{output}")
            return "\n\n".join(outputs)
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True,
            timeout=60, encoding="utf-8", errors="replace"
        )
        output = result.stdout.strip()
        error = result.stderr.strip()
        return output if output else (error if error else "Command completed successfully")
    except subprocess.TimeoutExpired:
        return "Command timed out after 60 seconds"
    except Exception as e:
        return f"Execution error: {e}"


def _detect_intent(user_input: str) -> Optional[str]:
    """Detect user intent and map to a command. Returns None if no match."""
    lower = user_input.lower().strip()

    # ── Always-available: repo/directory info ──
    if any(w in lower for w in [
        "which directory", "what directory", "where am i",
        "what repo", "which repo", "current directory",
        "current repo", "what project", "which project",
        "pwd", "repo root", "repo path"
    ]):
        return "git rev-parse --show-toplevel"

    # ── Special: search/grep — extract the search term ──
    search_match = re.search(
        r'(?:find occurrences?|search for|grep|find word|search files|look for|find in files)'
        r'[\s:]*["\']?(\w[\w\s]*\w|\w+)["\']?',
        lower
    )
    if search_match:
        term = search_match.group(1).strip()
        return f'git grep -i -n "{term}"'

    # ── Special: switch/checkout branch — fuzzy match ──
    switch_match = re.search(
        r'(?:switch to|checkout|go to|change to|move to)\s+(?:the\s+)?(?:branch\s+)?(.+)',
        lower
    )
    if switch_match:
        target = switch_match.group(1).strip().strip('"\'')
        # Get all branches and fuzzy match
        all_branches = _run(["git", "branch", "-a", "--format=%(refname:short)"])
        if all_branches:
            branches = [b.strip() for b in all_branches.splitlines() if b.strip()]
            # Try exact match first
            for branch in branches:
                if branch == target or branch.endswith(f"/{target}"):
                    return f"git checkout {branch}"
            # Fuzzy match — check if target words appear in branch name
            target_words = target.lower().split()
            best_match = None
            best_score = 0
            for branch in branches:
                branch_lower = branch.lower()
                score = sum(1 for word in target_words if word in branch_lower)
                if score > best_score:
                    best_score = score
                    best_match = branch
            if best_match and best_score > 0:
                return f"git checkout {best_match}"
        return None

    # ── Standard intent map lookup ──
    for triggers, command in INTENT_MAP:
        if any(trigger in lower for trigger in triggers):
            return command

    return None


# ── Fix #21: Command logging (replaces raw command display) ──────────────────
def _log_command(command: str, output: str):
    """Log executed commands to ~/.gitrama/logs/ for debugging. No user-facing display."""
    from datetime import datetime
    log_dir = os.path.expanduser("~/.gitrama/logs")
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, f"askgit_{datetime.now().strftime('%Y-%m-%d')}.log")
    try:
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().isoformat()}] CMD: {command}\n")
            f.write(f"  OUTPUT: {output[:500]}\n\n")
    except Exception:
        pass  # Logging should never crash the app


def _friendly_action_description(command: str) -> str:
    """Convert raw git/gtr commands to user-friendly descriptions for write confirmations."""
    cmd = command.lower().strip()
    if "gtr add" in cmd or "git add" in cmd:
        return "Stage files for commit"
    if "gtr commit" in cmd:
        return "Create a new commit with AI-generated message"
    if "gtr push" in cmd or "git push" in cmd:
        return "Push commits to remote"
    if "git checkout" in cmd or "git switch" in cmd:
        branch = cmd.split()[-1] if len(cmd.split()) > 2 else "another branch"
        return f"Switch to branch: {branch}"
    if "git stash push" in cmd:
        return "Stash current changes"
    if "git stash pop" in cmd:
        return "Restore stashed changes"
    if "gtr pr" in cmd:
        return "Create a pull request"
    # Fallback: generic description without showing the raw command
    return "Execute a write operation on your repository"


def _handle_execution(command: str, user_name: str) -> Optional[str]:
    # ── Fix #19: Builtin commands always safe, always auto-execute ──
    if command.startswith("__builtin_"):
        with console.status("Fetching...", spinner="dots"):
            output = _run_gtr_command(command)
        console.print(Panel(
            output,
            title="[bold green]AskG.I.T.[/bold green]",
            border_style="green", padding=(1, 2)
        ))
        console.print()
        _log_command(command, output)
        return output

    is_safe, needs_confirm, category = _is_command_safe(command)
    if not is_safe:
        # Don't print rejection to user — return sentinel so caller can handle gracefully
        _log_command(command, f"BLOCKED: {category}")
        return "__BLOCKED__"

    # ── Fix #21: Read commands auto-execute — no command display, no y/n ──
    if category == "read" or not needs_confirm:
        with console.status("Fetching...", spinner="dots"):
            output = _run_gtr_command(command)
        console.print(Panel(
            output,
            title="[bold green]AskG.I.T.[/bold green]",
            border_style="green", padding=(1, 2)
        ))
        console.print()
        _log_command(command, output)
        return output

    # ── Write commands: confirm but show friendly description, not raw command ──
    action_desc = _friendly_action_description(command)
    console.print(f"\n[bold yellow]AskG.I.T. wants to:[/bold yellow] {action_desc}")

    try:
        console.print("[dim]Proceed? ([bold]y[/bold]/n): [/dim]", end="")
        confirm = input().strip().lower()
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelled.[/dim]")
        return None

    if confirm not in ("y", "yes", ""):
        console.print("[dim]Skipped.[/dim]\n")
        return None

    with console.status("Running...", spinner="dots"):
        output = _run_gtr_command(command)

    console.print(Panel(
        output,
        title="[bold green]AskG.I.T.[/bold green]",
        border_style="green", padding=(1, 2)
    ))
    console.print()
    _log_command(command, output)
    return output


# ─── Server call ──────────────────────────────────────────────────────────────
def _call_server(
    messages: List[dict],
    git_context: str,
    os_name: str,
    stream_name: str,
    deep: bool,
    repo_stats: str,
    token: str,
    max_tokens: int = 500,
) -> str:
    headers = {
        "Content-Type": "application/json",
        "x-gitrama-token": token,
    }
    payload = {
        "messages": messages,
        "git_context": git_context,
        "os_name": os_name,
        "stream_name": stream_name,
        "deep": deep,
        "repo_stats": repo_stats,
        "max_tokens": max_tokens,
    }
    try:
        response = requests.post(
            f"{CHAT_SERVER_URL}/chat",
            headers=headers,
            json=payload,
            timeout=REQUEST_TIMEOUT,
        )
        if response.status_code == 401:
            console.print("[red]Authentication failed. Check your GITRAMA_TOKEN.[/red]")
            raise typer.Exit(1)
        if response.status_code != 200:
            console.print(f"[red]Server error ({response.status_code}). Try again.[/red]")
            raise typer.Exit(1)
        return response.json().get("reply", "")
    except requests.exceptions.ConnectionError:
        console.print("[red]Cannot reach api.gitrama.ai. Check your connection.[/red]")
        raise typer.Exit(1)
    except requests.exceptions.Timeout:
        console.print("[red]Request timed out. Try again.[/red]")
        raise typer.Exit(1)


# ─── Directory navigation within AskG.I.T. session ───────────────────────────
def _handle_cd(user_input: str) -> Optional[str]:
    """
    Detect cd commands and resolve the target path WITHOUT changing directory.
    Returns the resolved absolute path on success, None if not a cd command.
    """
    stripped = user_input.strip()

    # Match: cd <path>, cd "<path>", cd '<path>'
    cd_match = re.match(r'^cd\s+["\']?(.+?)["\']?\s*$', stripped, re.IGNORECASE)
    if not cd_match:
        return None

    target = cd_match.group(1).strip()

    # Expand ~ and environment variables
    target = os.path.expanduser(target)
    target = os.path.expandvars(target)

    # Resolve relative paths
    target = os.path.abspath(target)

    if not os.path.isdir(target):
        console.print(f"\n[yellow]Directory not found:[/yellow] {target}\n")
        return None

    return target


def _execute_cd(target: str) -> Optional[str]:
    """Actually change the working directory. Returns path on success, None on failure."""
    try:
        os.chdir(target)
        return target
    except PermissionError:
        console.print(f"\n[yellow]Permission denied:[/yellow] {target}\n")
        return None
    except Exception as e:
        console.print(f"\n[yellow]Cannot change directory:[/yellow] {e}\n")
        return None


def _reload_context(deep: bool = False) -> tuple:
    """
    Reload repo context after a directory change.
    Returns (in_repo, ctx, git_context, summary).
    """
    in_repo = _is_git_repo()
    if in_repo:
        ctx = _get_repo_context()
        if deep:
            ctx["repo_stats"] = _get_repo_stats()
        git_context = _build_git_context_string(ctx)
        summary = _format_context_summary(ctx, deep=deep)
    else:
        ctx = {"os": platform.system(), "stream": "none", "branch": "—", "commits": ""}
        git_context = "No repository detected. User is not inside a git project."
        summary = (
            f"[cyan]OS:[/cyan]         {platform.system()}\n"
            f"[cyan]Mode:[/cyan]       General Query — no repo detected\n"
            f"[cyan]Directory:[/cyan]  {os.getcwd()}\n"
            "[dim]💡 Use [bold]cd <path>[/bold] to navigate to a git project.[/dim]"
        )
    return in_repo, ctx, git_context, summary


# ─── Context summary panel ────────────────────────────────────────────────────
def _format_context_summary(ctx: dict, deep: bool = False) -> str:
    commit_count   = len([l for l in ctx.get("commits", "").splitlines() if l.strip()])
    staged_count   = len([l for l in ctx.get("staged", "").splitlines() if l.strip() and l != "none"])
    modified_count = len([l for l in ctx.get("modified", "").splitlines() if l.strip() and l != "none"])
    stash_count    = len([l for l in ctx.get("stashes", "").splitlines() if l.strip() and l != "none"])

    lines = [
        f"[cyan]Branch:[/cyan]     {ctx.get('branch', 'unknown')}",
        f"[cyan]Stream:[/cyan]     {ctx.get('stream', 'unknown')}",
        f"[cyan]OS:[/cyan]         {ctx.get('os', 'unknown')}",
    ]
    if deep:
        lines.append(f"[bold green]Mode:[/bold green]       Deep - Full History Access")
        lines.append(f"[cyan]Repo Stats:[/cyan] {ctx.get('repo_stats', 'loading...')}")
    else:
        lines.append(f"[cyan]Mode:[/cyan]       Free - Last {commit_count} commits")
    lines += [
        f"[cyan]Staged:[/cyan]     {staged_count} file(s)",
        f"[cyan]Modified:[/cyan]   {modified_count} file(s)",
        f"[cyan]Stashes:[/cyan]    {stash_count}",
    ]
    if ctx.get("remote"):
        lines.append(f"[cyan]Remote:[/cyan]     {ctx.get('remote')}")
    return "\n".join(lines)


# ─── Main chat command ─────────────────────────────────────────────────────────
def chat(
    stream: Optional[str] = typer.Option(
        None, "--stream", "-s",
        help="Override active stream context (wip | hotfix | review | experiment)"
    ),
    deep: bool = typer.Option(
        False, "--deep", "-d",
        help="Enable full repo history access"
    ),
    demo: bool = typer.Option(
        False, "--demo",
        help="Demo mode — disables tier restrictions for presentations"
    ),
    query: Optional[str] = typer.Option(
        None, "--query", "-q",
        help="Ask a single question and exit (non-interactive)"
    ),
):
    """Chat with AskG.I.T. - powered by Gitrama. Ask anything about your repo."""

    # Fix #2: Demo flag forces deep mode with no tier messaging
    if demo:
        deep = True

    token = get_value("GITRAMA_TOKEN") or ""

    # ── Single-shot query mode ──
    if query:
        in_repo = _is_git_repo()

        with console.status("Connecting to AskG.I.T....", spinner="dots"):
            _load_server_config(token)

        if in_repo:
            ctx = _get_repo_context()
            if stream:
                ctx["stream"] = stream
            if deep:
                ctx["repo_stats"] = _get_repo_stats()
            git_context = _build_git_context_string(ctx)

            # Check for intent match first
            intent_command = _detect_intent(query)
            if intent_command:
                output = _run_gtr_command(intent_command)
                console.print(Panel(
                    output,
                    title="[bold green]AskG.I.T.[/bold green]",
                    border_style="green", padding=(1, 2)
                ))
                _log_command(intent_command, output)
                raise typer.Exit(0)
        else:
            ctx = {"os": platform.system(), "stream": "none"}
            git_context = "No repository detected. User is not inside a git project."

        # Send to server
        with console.status("AskG.I.T. thinking...", spinner="dots"):
            response = _call_server(
                messages=[{"role": "user", "content": query}],
                git_context=git_context,
                os_name=ctx.get("os", platform.system()),
                stream_name=ctx.get("stream", "none"),
                deep=deep,
                repo_stats=ctx.get("repo_stats", ""),
                token=token,
                max_tokens=800 if deep else 500,
            )

        clean_response = _sanitize_response(response)
        if clean_response:
            console.print(Panel(
                clean_response,
                title="[bold green]AskG.I.T.[/bold green]",
                border_style="green", padding=(1, 2)
            ))
        raise typer.Exit(0)

    # ── Initial context detection ──
    in_repo = _is_git_repo()

    with console.status("Connecting to AskG.I.T....", spinner="dots"):
        config_loaded = _load_server_config(token)

    if not config_loaded:
        console.print("[dim yellow]Running in offline mode — some features limited.[/dim yellow]")

    # Load context based on whether we're in a repo
    if in_repo:
        status_msg = "Loading full repo history..." if deep else "Loading repo context..."
        with console.status(status_msg, spinner="dots"):
            ctx = _get_repo_context()
            if stream:
                ctx["stream"] = stream
            if deep:
                ctx["repo_stats"] = _get_repo_stats()
            git_context = _build_git_context_string(ctx)
            summary = _format_context_summary(ctx, deep=deep)
    else:
        ctx = {"os": platform.system(), "stream": "none", "branch": "—", "commits": ""}
        git_context = "No repository detected. User is not inside a git project."
        summary = (
            f"[cyan]OS:[/cyan]         {platform.system()}\n"
            f"[cyan]Mode:[/cyan]       General Query — no repo detected\n"
            f"[cyan]Directory:[/cyan]  {os.getcwd()}\n"
            "[dim]💡 Use [bold]cd <path>[/bold] to navigate to a git project for full intelligence.[/dim]"
        )

    # ── Display panel ──
    def _get_panel_style():
        if demo:
            return "AskG.I.T. - powered by Gitrama  [Demo Mode]", "bold green"
        if not in_repo:
            return "AskG.I.T. - powered by Gitrama  [General Mode]", "yellow"
        if deep:
            return "AskG.I.T. - powered by Gitrama  [Deep Mode]", "green"
        return "AskG.I.T. - powered by Gitrama", "cyan"

    panel_title, panel_color = _get_panel_style()

    console.print()
    console.print(Panel(summary, title=panel_title, border_style=panel_color, padding=(1, 2)))

    if in_repo:
        console.print(
            "\n[dim]Ask me anything about your repo, commits, branches, or workflow.[/dim]"
            "\n[dim]Use [bold]cd <path>[/bold] to switch projects. "
            "Type [bold]exit[/bold] to leave.[/dim]\n"
        )
        if demo:
            console.print("[bold green]Demo mode — full access, no tier restrictions.[/bold green]\n")
        elif deep:
            console.print(
                "[bold green]Deep mode active - I have access to your full repo history.[/bold green]\n"
                "[dim]Try: 'show all commits by Alfonso', 'what changed in Q1 2025', "
                "'full history of ai_client.py'[/dim]\n"
            )
        else:
            console.print(
                "[dim yellow]Free tier: last 20 commits loaded. "
                "Run [bold]gtr chat --deep[/bold] for full repo history.[/dim yellow]\n"
            )
    else:
        console.print(
            "\n[dim]I can help with git commands, workflows, and coding questions.[/dim]"
            "\n[dim]Use [bold]cd <path>[/bold] to navigate to a git project for full intelligence.[/dim]"
            "\n[dim]Type [bold]exit[/bold] to leave.[/dim]\n"
        )

    # ── Unified chat loop ──
    history: List[dict] = []
    user_name = "You"
    current_repo_path = os.getcwd() if in_repo else None

    while True:
        try:
            prompt_color = "bold cyan" if in_repo else "bold yellow"
            console.print(f"[{prompt_color}]{user_name} >[/{prompt_color}] ", end="")
            user_input = input().strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n\n[dim]Goodbye! - AskG.I.T.[/dim]")
            raise typer.Exit(0)

        if user_input.lower() in ("exit", "quit", "q", ":q", "bye"):
            console.print("\n[dim]Goodbye! - AskG.I.T.[/dim]")
            raise typer.Exit(0)

        if not user_input:
            continue

        # ── cd interception: navigate directories within session ──
        cd_target = _handle_cd(user_input)
        if cd_target is not None:
            # Check if this would actually change repo context
            target_is_same_dir = (os.path.abspath(cd_target) == os.path.abspath(os.getcwd()))

            if not target_is_same_dir and in_repo and len(history) > 0:
                # User has an active conversation in a repo — warn before switching
                target_name = os.path.basename(cd_target)
                current_name = os.path.basename(current_repo_path) if current_repo_path else "current directory"
                msg_count = len([m for m in history if m["role"] == "user"])

                console.print()
                console.print(Panel(
                    f"You're about to leave [bold]{current_name}[/bold] and move to "
                    f"[bold]{target_name}[/bold].\n\n"
                    f"Your conversation will carry over, but I'll lose access to "
                    f"[bold]{current_name}[/bold]'s commits, branches, and files "
                    f"once we switch.\n\n"
                    f"💬 {msg_count} message(s) in this session",
                    title="[yellow]🔀 Switching Projects[/yellow]",
                    border_style="yellow", padding=(1, 2)
                ))

                try:
                    console.print("[dim]Ready to switch? ([bold]y[/bold]/n): [/dim]", end="")
                    confirm = input().strip().lower()
                except (KeyboardInterrupt, EOFError):
                    console.print("\n[dim]Cancelled.[/dim]")
                    continue

                if confirm not in ("y", "yes", ""):
                    console.print("[dim]Staying in current directory.[/dim]\n")
                    continue

            # Execute the directory change
            new_dir = _execute_cd(cd_target)
            if new_dir is None:
                continue

            was_in_repo = in_repo
            prev_repo = current_repo_path
            with console.status("Scanning new directory...", spinner="dots"):
                in_repo, ctx, git_context, summary = _reload_context(deep=deep)
                if stream and in_repo:
                    ctx["stream"] = stream

            # Track current repo path for boundary messages
            current_repo_path = os.getcwd() if in_repo else None

            # ── Inject context boundary into conversation history ──
            # This tells the LLM that prior messages were about a different repo/context
            if was_in_repo or in_repo:
                prev_name = os.path.basename(prev_repo) if prev_repo else "no repo"
                new_name = os.path.basename(current_repo_path) if current_repo_path else "no repo"
                if prev_name != new_name:
                    boundary_msg = (
                        f"[CONTEXT SWITCH] The user has navigated to a different directory. "
                        f"Previous context was '{prev_name}'. "
                    )
                    if in_repo:
                        boundary_msg += (
                            f"Now in repository '{new_name}' "
                            f"(branch: {ctx.get('branch', 'unknown')}). "
                            f"All prior repo-specific information (commits, branches, files) "
                            f"is from the PREVIOUS repo and no longer applies. "
                            f"Use only the new git_context for repo questions going forward."
                        )
                    else:
                        boundary_msg += (
                            "The user is no longer inside a git repository. "
                            "Do not reference any prior repo-specific data."
                        )
                    history.append({"role": "user", "content": boundary_msg})
                    history.append({
                        "role": "assistant",
                        "content": f"Understood — I've switched context to '{new_name}'. "
                                   "How can I help with this project?"
                    })

            panel_title, panel_color = _get_panel_style()

            if in_repo and not was_in_repo:
                # Transitioned from general → repo mode
                console.print()
                console.print(Panel(
                    summary,
                    title=panel_title,
                    border_style=panel_color, padding=(1, 2)
                ))
                console.print("[bold green]Repo detected! Full intelligence activated.[/bold green]\n")
            elif in_repo:
                # Switched between repos
                console.print()
                console.print(Panel(
                    summary,
                    title=panel_title,
                    border_style=panel_color, padding=(1, 2)
                ))
                console.print("[dim green]Switched repo context.[/dim green]\n")
            else:
                # Left a repo or moved to another non-repo directory
                console.print(f"[dim]📂 {new_dir}[/dim]")
                if was_in_repo:
                    console.print("[dim yellow]No git repo here — switched to general mode.[/dim yellow]\n")
                else:
                    console.print("[dim]💡 Use [bold]cd <path>[/bold] to navigate to a git project.[/dim]\n")
            continue

        # ── Intent detection (only when in a repo) ──
        if in_repo:
            intent_command = _detect_intent(user_input)
            if intent_command:
                output = _handle_execution(intent_command, user_name)
                if output:
                    history.append({
                        "role": "user",
                        "content": f"I ran `{intent_command}`. Output:\n{output}\nPlease analyze and tell me what happened."
                    })
                    with console.status("AskG.I.T. analyzing...", spinner="dots"):
                        response = _call_server(
                            messages=history,
                            git_context=git_context,
                            os_name=ctx.get("os", platform.system()),
                            stream_name=ctx.get("stream", "none"),
                            deep=deep,
                            repo_stats=ctx.get("repo_stats", ""),
                            token=token,
                            max_tokens=400,
                        )
                    history.append({"role": "assistant", "content": response})
                    console.print()
                    console.print(Panel(
                        response,
                        title="[bold green]AskG.I.T.[/bold green]",
                        border_style="green", padding=(1, 2)
                    ))
                    console.print()
                continue

        # ── Enrich with live git data (only when in a repo) ──
        enriched_input = user_input
        if in_repo:
            with console.status("Fetching repo data...", spinner="dots"):
                extra_context = _deep_enrich_prompt(user_input) if deep else _enrich_prompt_with_context(user_input)
            if extra_context:
                enriched_input = f"{user_input}\n\n[Live repo data fetched:]{extra_context}"

        history.append({"role": "user", "content": enriched_input})

        with console.status("AskG.I.T. thinking...", spinner="dots"):
            response = _call_server(
                messages=history,
                git_context=git_context,
                os_name=ctx.get("os", platform.system()),
                stream_name=ctx.get("stream", "none"),
                deep=deep,
                repo_stats=ctx.get("repo_stats", ""),
                token=token,
                max_tokens=800 if deep else 500,
            )

        history.append({"role": "assistant", "content": response})

        # Check for execute commands in response (only when in a repo)
        if in_repo:
            commands_to_run = _extract_commands_from_response(response)
        else:
            commands_to_run = []

        # Display clean response
        clean_response = _sanitize_response(response)
        if clean_response:
            console.print()
            console.print(Panel(
                clean_response,
                title="[bold green]AskG.I.T.[/bold green]",
                border_style="green", padding=(1, 2)
            ))
            console.print()

        # Run any commands the AI requested
        execution_outputs = []
        blocked_count = 0
        for command in commands_to_run:
            output = _handle_execution(command, user_name)
            if output == "__BLOCKED__":
                blocked_count += 1
            elif output:
                execution_outputs.append(f"$ {command}\n{output}")

        # If ALL commands were blocked, show one gentle message (not per-command)
        if blocked_count > 0 and len(execution_outputs) == 0:
            console.print()
            console.print("[dim]I wasn't able to run that command directly. Try rephrasing your request.[/dim]")
            console.print()
            # Don't feed failure back to AI — it tends to cascade with more bad commands
            continue

        # Feed execution results back for analysis (only successful outputs)
        if execution_outputs:
            combined_output = "\n\n".join(execution_outputs)
            history.append({
                "role": "user",
                "content": f"Commands executed. Results:\n{combined_output}\nAnalyze and summarize what happened."
            })
            with console.status("AskG.I.T. analyzing results...", spinner="dots"):
                followup = _call_server(
                    messages=history,
                    git_context=git_context,
                    os_name=ctx.get("os", platform.system()),
                    stream_name=ctx.get("stream", "none"),
                    deep=deep,
                    repo_stats=ctx.get("repo_stats", ""),
                    token=token,
                    max_tokens=400,
                )
            history.append({"role": "assistant", "content": followup})

            # Follow-up may contain commands — run them (1 retry max, then stop)
            followup_commands = _extract_commands_from_response(followup) if in_repo else []
            clean_followup = _sanitize_response(followup)
            if clean_followup:
                console.print(Panel(
                    clean_followup,
                    title="[bold green]AskG.I.T.[/bold green]",
                    border_style="green", padding=(1, 2)
                ))
                console.print()

            # Execute follow-up commands (this is the last retry — no further cascading)
            if followup_commands:
                retry_outputs = []
                for cmd in followup_commands:
                    out = _handle_execution(cmd, user_name)
                    if out and out != "__BLOCKED__":
                        retry_outputs.append(f"$ {cmd}\n{out}")
                # If retry produced results, show one final analysis — then STOP
                if retry_outputs:
                    retry_combined = "\n\n".join(retry_outputs)
                    history.append({
                        "role": "user",
                        "content": f"Follow-up results:\n{retry_combined}\nBriefly summarize."
                    })
                    with console.status("AskG.I.T. analyzing...", spinner="dots"):
                        final = _call_server(
                            messages=history,
                            git_context=git_context,
                            os_name=ctx.get("os", platform.system()),
                            stream_name=ctx.get("stream", "none"),
                            deep=deep,
                            repo_stats=ctx.get("repo_stats", ""),
                            token=token,
                            max_tokens=300,
                        )
                    history.append({"role": "assistant", "content": final})
                    clean_final = _sanitize_response(final)
                    if clean_final:
                        console.print(Panel(
                            clean_final,
                            title="[bold green]AskG.I.T.[/bold green]",
                            border_style="green", padding=(1, 2)
                        ))
                        console.print()

        # Keep history manageable
        if len(history) > 40:
            history = history[-40:]
