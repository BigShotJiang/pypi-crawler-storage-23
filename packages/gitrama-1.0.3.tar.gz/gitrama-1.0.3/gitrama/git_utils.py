"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

This software is proprietary and confidential.
Unauthorized copying, distribution, or use is strictly prohibited.

Gitrama LLC
South Carolina Limited Liability Company
"""
"""
Git utilities for Gitrama
Helper functions for interacting with Git
"""

import subprocess
from typing import List, Tuple, Optional


def get_staged_files() -> List[str]:
    """
    Get list of staged files
    
    Returns:
        list: List of staged file paths
    """
    try:
        result = subprocess.run(
            ["git", "diff", "--cached", "--name-only"],
            capture_output=True,
            text=True,
            check=True
        )
        files = [f.strip() for f in result.stdout.split('\n') if f.strip()]
        return files
    except subprocess.CalledProcessError:
        return []


def get_staged_diff() -> str:
    """Get diff of staged changes with safe encoding"""
    try:
        result = subprocess.run(
            ["git", "diff", "--cached"],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',  # Replace invalid characters
            check=False  # Don't raise on non-zero exit
        )
        return result.stdout if result.returncode == 0 else ""
    except Exception:
        return ""

def commit_changes(message: str) -> bool:
    """
    Commit staged changes with given message
    
    Args:
        message: Commit message
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        subprocess.run(
            ["git", "commit", "-m", message],
            capture_output=True,
            text=True,
            check=True
        )
        return True
    except subprocess.CalledProcessError:
        return False


def get_current_branch() -> str:
    """
    Get the current branch name
    
    Returns:
        str: Current branch name
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError:
        return ""


def branch_exists(branch_name: str) -> bool:
    """
    Check if a branch exists
    
    Args:
        branch_name: Name of branch to check
        
    Returns:
        bool: True if branch exists, False otherwise
    """
    try:
        subprocess.run(
            ["git", "rev-parse", "--verify", branch_name],
            capture_output=True,
            check=True
        )
        return True
    except subprocess.CalledProcessError:
        return False


def create_branch(branch_name: str, checkout: bool = True) -> bool:
    """
    Create a new branch
    
    Args:
        branch_name: Name of branch to create
        checkout: Whether to checkout the new branch
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        if checkout:
            subprocess.run(
                ["git", "checkout", "-b", branch_name],
                capture_output=True,
                check=True
            )
        else:
            subprocess.run(
                ["git", "branch", branch_name],
                capture_output=True,
                check=True
            )
        return True
    except subprocess.CalledProcessError:
        return False


def checkout_branch(branch_name: str) -> bool:
    """
    Checkout an existing branch
    
    Args:
        branch_name: Name of branch to checkout
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        subprocess.run(
            ["git", "checkout", branch_name],
            capture_output=True,
            check=True
        )
        return True
    except subprocess.CalledProcessError:
        return False


def get_branch_commits(base_branch: str = "master") -> List[dict]:
    """
    Get commits in current branch that aren't in base branch
    
    Args:
        base_branch: Base branch to compare against
        
    Returns:
        list: List of commit dicts with 'hash' and 'message'
    """
    try:
        # Get commits not in base branch
        result = subprocess.run(
            ["git", "log", f"{base_branch}..HEAD", "--format=%H|||%s"],
            capture_output=True,
            text=True,
            check=True
        )
        
        commits = []
        for line in result.stdout.strip().split('\n'):
            if line:
                hash_msg = line.split('|||')
                if len(hash_msg) == 2:
                    commits.append({
                        'hash': hash_msg[0],
                        'message': hash_msg[1]
                    })
        
        return commits
    except subprocess.CalledProcessError:
        return []


def get_branch_diff(base_branch: str = "master") -> str:
    """
    Get diff between current branch and base branch
    
    Args:
        base_branch: Base branch to compare against
        
    Returns:
        str: Git diff output
    """
    try:
        result = subprocess.run(
            ["git", "diff", base_branch, "HEAD"],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout
    except subprocess.CalledProcessError:
        return ""


def get_default_branch() -> str:
    """
    Get the default branch name (main or master)
    
    Returns:
        str: Default branch name
    """
    try:
        # Try to get from remote
        result = subprocess.run(
            ["git", "symbolic-ref", "refs/remotes/origin/HEAD"],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            return result.stdout.strip().split('/')[-1]
    except:
        pass
    
    # Fallback: check which exists locally
    for branch in ['main', 'master']:
        result = subprocess.run(
            ["git", "rev-parse", "--verify", branch],
            capture_output=True
        )
        if result.returncode == 0:
            return branch
    
    return "master"  # Final fallback


def get_repo_root() -> str:
    """
    Get the root directory of the git repository
    
    Returns:
        str: Absolute path to repo root, or empty string if not in a repo
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError:
        return ""


def is_git_repo() -> bool:
    """
    Check if current directory is in a git repository
    
    Returns:
        bool: True if in a git repo, False otherwise
    """
    try:
        subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            capture_output=True,
            check=True
        )
        return True
    except subprocess.CalledProcessError:
        return False


def has_staged_changes() -> bool:
    """
    Check if there are staged changes
    
    Returns:
        bool: True if there are staged changes, False otherwise
    """
    try:
        result = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            capture_output=True
        )
        # Exit code 0 = no changes, 1 = has changes
        return result.returncode == 1
    except subprocess.CalledProcessError:
        return False


def has_unstaged_changes() -> bool:
    """
    Check if there are unstaged changes
    
    Returns:
        bool: True if there are unstaged changes, False otherwise
    """
    try:
        result = subprocess.run(
            ["git", "diff", "--quiet"],
            capture_output=True
        )
        # Exit code 0 = no changes, 1 = has changes
        return result.returncode == 1
    except subprocess.CalledProcessError:
        return False


def get_commit_count(base_branch: Optional[str] = None) -> int:
    """
    Get number of commits in current branch
    
    Args:
        base_branch: Base branch to compare against. If None, counts all commits.
        
    Returns:
        int: Number of commits
    """
    try:
        if base_branch:
            result = subprocess.run(
                ["git", "rev-list", "--count", f"{base_branch}..HEAD"],
                capture_output=True,
                text=True,
                check=True
            )
        else:
            result = subprocess.run(
                ["git", "rev-list", "--count", "HEAD"],
                capture_output=True,
                text=True,
                check=True
            )
        return int(result.stdout.strip())
    except (subprocess.CalledProcessError, ValueError):
        return 0


def get_remote_url() -> str:
    """
    Get the remote URL of the repository
    
    Returns:
        str: Remote URL, or empty string if no remote
    """
    try:
        result = subprocess.run(
            ["git", "config", "--get", "remote.origin.url"],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError:
        return ""


def list_branches(all_branches: bool = False) -> List[str]:
    """
    List all branches
    
    Args:
        all_branches: If True, include remote branches
        
    Returns:
        list: List of branch names
    """
    try:
        cmd = ["git", "branch"]
        if all_branches:
            cmd.append("-a")
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=True
        )
        
        branches = []
        for line in result.stdout.split('\n'):
            line = line.strip()
            if line:
                # Remove * prefix from current branch
                branch = line.lstrip('* ').strip()
                branches.append(branch)
        
        return branches
    except subprocess.CalledProcessError:
        return []


def get_last_commit_message() -> str:
    """
    Get the message of the last commit
    
    Returns:
        str: Last commit message
    """
    try:
        result = subprocess.run(
            ["git", "log", "-1", "--pretty=%B"],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError:
        return ""


def get_file_stats(base_branch: Optional[str] = None) -> Tuple[int, int]:
    """
    Get file change statistics (additions and deletions)
    
    Args:
        base_branch: Base branch to compare against. If None, uses staged changes.
        
    Returns:
        tuple: (additions, deletions) as integers
    """
    try:
        if base_branch:
            result = subprocess.run(
                ["git", "diff", base_branch, "HEAD", "--numstat"],
                capture_output=True,
                text=True,
                check=True
            )
        else:
            result = subprocess.run(
                ["git", "diff", "--cached", "--numstat"],
                capture_output=True,
                text=True,
                check=True
            )
        
        additions = 0
        deletions = 0
        
        for line in result.stdout.split('\n'):
            if line:
                parts = line.split('\t')
                if len(parts) >= 2:
                    try:
                        additions += int(parts[0]) if parts[0] != '-' else 0
                        deletions += int(parts[1]) if parts[1] != '-' else 0
                    except ValueError:
                        pass
        
        return additions, deletions
    except subprocess.CalledProcessError:
        return 0, 0