# Gitrama 🌿

> **AI-Powered Git Workflow Automation**  
> Replace `git` with `gtr` — your AI-enhanced Git CLI that writes commit messages, names branches, generates PRs, and manages your workflow context.

<div align="center">

![Version](https://img.shields.io/badge/version-1.0.0-green)
![Python](https://img.shields.io/badge/python-3.11+-blue)
![License](https://img.shields.io/badge/license-Proprietary-red)
![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey)

</div>

---

## ✨ What is Gitrama?

Gitrama is a drop-in replacement for the `git` CLI — powered by AI. Every command you know from git works with `gtr`, but with AI superpowers built in:

- 🤖 **AI commit messages** — never write `git commit -m "fix stuff"` again
- 🌿 **AI branch names** — conventional, clean, generated from plain English
- 🔀 **AI PR descriptions** — professional pull requests in seconds
- 📊 **AI status interpretation** — tells you what to do next, not just what changed
- 🌊 **Streams** — switch between hotfix, wip, and experiment contexts without stashing
- 🔧 **Full git wrapper** — `gtr push`, `gtr pull`, `gtr log`, `gtr diff` and more

---

## 🚀 Quick Start

```bash
# Install
git clone https://github.com/ahmaxdev/gitrama-cli.git
cd gitrama-cli
pip install -e .

# Configure your AI provider
gtr setup

# The new git workflow
gtr status          # See what changed + AI suggestion
gtr add             # Stage files
gtr commit          # AI-generated commit message
gtr push            # Push to remote
```

---

## 📦 Installation

### Requirements

- Python 3.11+
- Git 2.0+
- An AI provider API key (Anthropic, OpenAI, or Ollama)

### Install from Source

```bash
git clone https://github.com/ahmaxdev/gitrama-cli.git
cd gitrama-cli

# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (macOS/Linux)
source venv/bin/activate

# Install
pip install -e .

# Verify
gtr --version
```

### Install from PyPI *(coming soon)*

```bash
pip install gitrama
```

---

## ⚙️ Configuration

### Setup Wizard

```bash
gtr setup
```

The setup wizard walks you through configuring your AI provider interactively.

### Manual Configuration

```bash
# Set provider (automatically updates API URL)
gtr config set provider anthropic    # or openai | ollama | gitrama

# Set your API key
gtr config set api_key sk-ant-...

# Set model (optional)
gtr config set model claude-sonnet-4-6

# View all settings
gtr config list
```

### Supported Providers

| Provider | Description | API Key Required |
|----------|-------------|-----------------|
| `anthropic` | Claude models (recommended) | Yes |
| `openai` | GPT models | Yes |
| `ollama` | Local models (free, private) | No |
| `gitrama` | Gitrama hosted server | No |

---

## 📋 Commands

### AI Commands

| Command | Description |
|---------|-------------|
| `gtr commit` | Generate AI commit message from staged changes |
| `gtr branch "description"` | Generate AI branch name and create branch |
| `gtr pr` | Generate AI pull request title and description |
| `gtr summary` | Quick summary of staged changes |

### Git Wrapper Commands

| Command | Description |
|---------|-------------|
| `gtr add [files]` | Stage files (default: all) |
| `gtr status` | Working tree status + AI suggestion |
| `gtr push` | Push to remote |
| `gtr pull` | Pull with AI summary of changes |
| `gtr fetch` | Fetch remote changes |
| `gtr log` | Commit history with optional AI summary |
| `gtr diff` | Show changes with AI explanation |
| `gtr merge <branch>` | Merge with confirmation guard |
| `gtr checkout <branch>` | Switch branches |
| `gtr stash [push\|pop\|list\|drop]` | Stash with AI labels |
| `gtr reset` | Reset with safety confirmation |
| `gtr revert` | Revert commit safely |

### Stream Commands

| Command | Description |
|---------|-------------|
| `gtr stream list` | Show all streams |
| `gtr stream switch <name>` | Switch to a stream |
| `gtr stream create <name>` | Create custom stream |
| `gtr stream merge <branch>` | Merge stream into target branch |
| `gtr stream status` | Detailed stream status |
| `gtr stream delete <name>` | Delete custom stream |

### Utility Commands

| Command | Description |
|---------|-------------|
| `gtr health` | Check AI server status |
| `gtr config list` | Show all configuration |
| `gtr setup` | Interactive setup wizard |
| `gtr tips` | Show tips and best practices |
| `gtr welcome` | Show welcome banner |
| `gtr version` | Show version info |

### Shortcuts

| Shortcut | Full Command |
|----------|-------------|
| `gtr c` | `gtr commit` |
| `gtr b` | `gtr branch` |
| `gtr h` | `gtr health` |
| `gtr s` | `gtr stream` |

---

## 🌊 Streams

Streams let you switch between work contexts instantly — no manual stashing required.

```bash
# Working on a feature
gtr stream switch wip
gtr branch "Add user dashboard"
# ... make changes, commit ...

# URGENT: Production bug!
gtr stream switch hotfix
# Your wip work is saved automatically
gtr branch "Fix payment crash"
gtr commit
gtr push

# Back to feature work
gtr stream switch wip
# Your dashboard work is restored!

# Merge hotfix when done
gtr stream merge main
```

### Default Streams

| Stream | Purpose |
|--------|---------|
| `wip` | Work in Progress — main feature work |
| `hotfix` | Urgent bug fixes and patches |
| `review` | Code review feedback and changes |
| `experiment` | Try new ideas safely |

---

## 💡 Real-World Workflow

```bash
# Start your day
gtr status                          # AI tells you where you left off

# Create a feature branch
gtr branch "Add OAuth login"        # → feat/add-oauth-login

# Make changes, then commit
gtr add auth.py login.py
gtr commit                          # → feat(auth): add OAuth login with Google provider

# Generate PR when ready
gtr pr                              # Full PR description copied to clipboard

# Push and merge
gtr push
gtr stream merge main
```

---

## 🔧 Examples

### AI Commit Message

```bash
$ gtr commit
📝 Found 3 file(s) staged
🤖 Generating commit message...

✨ Generated message:
   feat(auth): add JWT-based user authentication with refresh tokens

Use this message? [Y/n]: y
✅ 🎉 Commit created successfully!
```

### AI Status Suggestion

```bash
$ gtr status

📊 Git Status

On branch feat/add-payment-processing
Changes not staged for commit:
  modified: payment.py

┌─ 🤖 AI Suggestion ──────────────────────────┐
│ You have unstaged changes in payment.py.    │
│ Stage with: gtr add payment.py              │
│ Then commit with: gtr commit                │
└─────────────────────────────────────────────┘
```

### AI Branch Name

```bash
$ gtr branch "Fix the memory leak in the payment processor"
🤖 Generating branch name...
✨ Generated: fix/memory-leak-payment-processor
✅ 🎉 Created and switched to: fix/memory-leak-payment-processor
```

---

## 🗺️ Roadmap

### v1.0.0 ✅ Released
- AI commit messages
- AI branch names
- AI PR descriptions
- Full git command wrapper
- Multi-provider AI support (Anthropic, OpenAI, Ollama)
- Streams workflow
- Safety guards on destructive commands
- Setup wizard
- `gtr chat` — interactive AI chat about your repo (recent commits)

### v1.1.0 🔜 Coming Soon
- `gtr remote` — remote management wrapper

### v1.2.0 Premium 💎
- `gtr chat` — full repo history, years back
- Deep commit search by date, author, file
- Code evolution tracking
- Team features
- Freemium model

---

## 🏢 About

**Gitrama LLC**  
South Carolina Limited Liability Company

- 🌐 Website: [gitrama.ai](https://gitrama.ai)
- 📧 Contact: contact@gitrama.ai
- 🐙 GitHub: [github.com/ahmaxdev](https://github.com/ahmaxdev)

---

## ⚖️ License

Copyright © 2026 Gitrama LLC. All Rights Reserved.

This software is proprietary and confidential. Unauthorized copying, distribution, or use is strictly prohibited.

For licensing inquiries: contact@gitrama.ai

---

<div align="center">

**Built by a developer who was tired of writing commit messages.** 🌿

*Stop typing `git`. Start typing `gtr`.*

</div>
