"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

Tests for Gitrama CLI commands.
Run with: pytest tests/ -v
"""

import pytest
from unittest.mock import patch, MagicMock
from typer.testing import CliRunner
from gitrama.cli import app

runner = CliRunner()


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def mock_ai_client():
    """Mock AIClient to avoid real API calls in tests."""
    with patch("gitrama.cli.AIClient") as mock:
        client = MagicMock()
        mock.return_value = client
        yield client


@pytest.fixture
def mock_git_staged():
    """Mock staged changes present."""
    with patch("gitrama.cli.has_staged_changes", return_value=True), \
         patch("gitrama.cli.get_staged_files", return_value=["auth.py", "config.py"]), \
         patch("gitrama.cli.get_staged_diff", return_value="diff --git a/auth.py..."):
        yield


@pytest.fixture
def mock_git_no_staged():
    """Mock no staged changes."""
    with patch("gitrama.cli.has_staged_changes", return_value=False):
        yield


@pytest.fixture
def mock_git_branch():
    """Mock current branch as feature branch."""
    with patch("gitrama.cli.get_current_branch", return_value="feat/add-auth"), \
         patch("gitrama.cli.get_default_branch", return_value="main"), \
         patch("gitrama.cli.get_branch_commits", return_value=["abc123 feat: add auth"]), \
         patch("gitrama.cli.get_branch_diff", return_value="diff --git a/auth.py..."):
        yield


# ─── Version / Welcome / Tips ─────────────────────────────────────────────────

class TestInfoCommands:

    def test_version(self):
        result = runner.invoke(app, ["version"])
        assert result.exit_code == 0
        assert "1.0.0" in result.output

    def test_welcome(self):
        result = runner.invoke(app, ["welcome"])
        assert result.exit_code == 0
        assert "Quick Start" in result.output
        assert "gtr commit" in result.output
        assert "gtr push" in result.output

    def test_tips(self):
        result = runner.invoke(app, ["tips"])
        assert result.exit_code == 0
        assert "Stage intentionally" in result.output
        assert "conventional commits" in result.output

    def test_help(self):
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "AI-Powered Git Workflow" in result.output

    def test_no_subcommand_shows_banner(self):
        result = runner.invoke(app, [])
        assert result.exit_code == 0
        assert "GITRAMA" in result.output or "Gitrama" in result.output


# ─── Commit ───────────────────────────────────────────────────────────────────

class TestCommit:

    def test_commit_no_staged_changes(self, mock_git_no_staged):
        result = runner.invoke(app, ["commit"])
        assert result.exit_code == 1
        assert "No staged changes" in result.output

    def test_commit_with_custom_message(self, mock_git_staged):
        with patch("gitrama.cli.commit_changes", return_value=True):
            result = runner.invoke(app, ["commit", "-m", "fix: resolve auth bug"])
        assert result.exit_code == 0
        assert "successfully" in result.output.lower()

    def test_commit_custom_message_fails(self, mock_git_staged):
        with patch("gitrama.cli.commit_changes", return_value=False):
            result = runner.invoke(app, ["commit", "-m", "fix: something"])
        assert result.exit_code == 1
        assert "Failed" in result.output

    def test_commit_ai_generated_auto(self, mock_git_staged, mock_ai_client):
        mock_ai_client.generate_commit_message.return_value = "feat: add authentication module"
        with patch("gitrama.cli.commit_changes", return_value=True):
            result = runner.invoke(app, ["commit", "--yes"])
        assert result.exit_code == 0
        assert "successfully" in result.output.lower()

    def test_commit_ai_generated_confirmed(self, mock_git_staged, mock_ai_client):
        mock_ai_client.generate_commit_message.return_value = "feat: add auth"
        with patch("gitrama.cli.commit_changes", return_value=True):
            result = runner.invoke(app, ["commit"], input="y\n")
        assert result.exit_code == 0

    def test_commit_ai_generated_rejected(self, mock_git_staged, mock_ai_client):
        mock_ai_client.generate_commit_message.return_value = "feat: add auth"
        result = runner.invoke(app, ["commit"], input="n\n")
        assert result.exit_code == 1
        assert "cancelled" in result.output.lower()

    def test_commit_ai_fails(self, mock_git_staged, mock_ai_client):
        mock_ai_client.generate_commit_message.return_value = None
        result = runner.invoke(app, ["commit"])
        assert result.exit_code == 1
        assert "Failed" in result.output

    def test_commit_alias(self, mock_git_staged, mock_ai_client):
        mock_ai_client.generate_commit_message.return_value = "feat: add auth"
        with patch("gitrama.cli.commit_changes", return_value=True):
            result = runner.invoke(app, ["c", "--yes"])
        assert result.exit_code == 0


# ─── Branch ───────────────────────────────────────────────────────────────────

class TestBranch:

    def test_branch_generates_name(self, mock_ai_client):
        mock_ai_client.generate_branch_name.return_value = "feat/add-user-auth"
        with patch("gitrama.cli.branch_exists", return_value=False), \
             patch("gitrama.cli.create_branch", return_value=True):
            result = runner.invoke(app, ["branch", "Add user authentication"])
        assert result.exit_code == 0
        assert "feat/add-user-auth" in result.output

    def test_branch_no_create(self, mock_ai_client):
        mock_ai_client.generate_branch_name.return_value = "docs/update-readme"
        with patch("gitrama.cli.branch_exists", return_value=False):
            result = runner.invoke(app, ["branch", "Update readme", "--no-create"])
        assert result.exit_code == 0
        assert "docs/update-readme" in result.output

    def test_branch_already_exists_switch(self, mock_ai_client):
        mock_ai_client.generate_branch_name.return_value = "feat/existing"
        with patch("gitrama.cli.branch_exists", return_value=True), \
             patch("gitrama.cli.checkout_branch", return_value=True):
            result = runner.invoke(app, ["branch", "existing feature"], input="y\n")
        assert result.exit_code == 0
        assert "Switched" in result.output

    def test_branch_already_exists_cancelled(self, mock_ai_client):
        mock_ai_client.generate_branch_name.return_value = "feat/existing"
        with patch("gitrama.cli.branch_exists", return_value=True):
            result = runner.invoke(app, ["branch", "existing feature"], input="n\n")
        assert result.exit_code == 1

    def test_branch_ai_fails(self, mock_ai_client):
        mock_ai_client.generate_branch_name.return_value = None
        result = runner.invoke(app, ["branch", "Something"])
        assert result.exit_code == 1
        assert "Failed" in result.output

    def test_branch_create_fails(self, mock_ai_client):
        mock_ai_client.generate_branch_name.return_value = "feat/new"
        with patch("gitrama.cli.branch_exists", return_value=False), \
             patch("gitrama.cli.create_branch", return_value=False):
            result = runner.invoke(app, ["branch", "new feature"])
        assert result.exit_code == 1

    def test_branch_alias(self, mock_ai_client):
        mock_ai_client.generate_branch_name.return_value = "fix/bug"
        with patch("gitrama.cli.branch_exists", return_value=False), \
             patch("gitrama.cli.create_branch", return_value=True):
            result = runner.invoke(app, ["b", "fix a bug"])
        assert result.exit_code == 0


# ─── PR ───────────────────────────────────────────────────────────────────────

class TestPR:

    def test_pr_generates_description(self, mock_git_branch, mock_ai_client):
        mock_ai_client.generate_pr_description.return_value = {
            "title": "feat: Add authentication",
            "description": "## Summary\nAdds user auth module"
        }
        with patch("gitrama.cli.pyperclip", MagicMock()):
            result = runner.invoke(app, ["pr"])
        assert result.exit_code == 0
        assert "feat: Add authentication" in result.output

    def test_pr_on_base_branch(self):
        with patch("gitrama.cli.get_current_branch", return_value="main"), \
             patch("gitrama.cli.get_default_branch", return_value="main"):
            result = runner.invoke(app, ["pr"])
        assert result.exit_code == 1
        assert "base branch" in result.output

    def test_pr_no_commits(self, mock_ai_client):
        with patch("gitrama.cli.get_current_branch", return_value="feat/auth"), \
             patch("gitrama.cli.get_default_branch", return_value="main"), \
             patch("gitrama.cli.get_branch_commits", return_value=[]), \
             patch("gitrama.cli.get_branch_diff", return_value=""):
            result = runner.invoke(app, ["pr"])
        assert result.exit_code == 1
        assert "No commits" in result.output

    def test_pr_ai_fails(self, mock_git_branch, mock_ai_client):
        mock_ai_client.generate_pr_description.return_value = {
            "title": "", "description": ""
        }
        result = runner.invoke(app, ["pr"])
        assert result.exit_code == 1
        assert "Failed" in result.output

    def test_pr_custom_base(self, mock_ai_client):
        mock_ai_client.generate_pr_description.return_value = {
            "title": "feat: Something",
            "description": "Description here"
        }
        with patch("gitrama.cli.get_current_branch", return_value="feat/auth"), \
             patch("gitrama.cli.get_default_branch", return_value="main"), \
             patch("gitrama.cli.get_branch_commits", return_value=["abc feat: auth"]), \
             patch("gitrama.cli.get_branch_diff", return_value="diff..."):
            result = runner.invoke(app, ["pr", "--base", "develop"])
        assert result.exit_code == 0


# ─── Summary ──────────────────────────────────────────────────────────────────

class TestSummary:

    def test_summary_with_staged(self, mock_git_staged):
        result = runner.invoke(app, ["summary"])
        assert result.exit_code == 0
        assert "Files changed" in result.output
        assert "auth.py" in result.output

    def test_summary_no_staged(self, mock_git_no_staged):
        result = runner.invoke(app, ["summary"])
        assert result.exit_code == 1
        assert "No staged changes" in result.output


# ─── Stream ───────────────────────────────────────────────────────────────────

class TestStream:

    def test_stream_list(self):
        with patch("gitrama.cli.StreamManager") as mock:
            manager = MagicMock()
            mock.return_value = manager
            result = runner.invoke(app, ["stream", "list"])
        assert result.exit_code == 0
        manager.list_streams.assert_called_once()

    def test_stream_status(self):
        with patch("gitrama.cli.StreamManager") as mock:
            manager = MagicMock()
            mock.return_value = manager
            result = runner.invoke(app, ["stream", "status"])
        assert result.exit_code == 0
        manager.status.assert_called_once()

    def test_stream_switch(self):
        with patch("gitrama.cli.StreamManager") as mock:
            manager = MagicMock()
            mock.return_value = manager
            result = runner.invoke(app, ["stream", "switch", "hotfix"])
        assert result.exit_code == 0
        manager.switch_stream.assert_called_once_with("hotfix")

    def test_stream_switch_no_name(self):
        with patch("gitrama.cli.StreamManager"):
            result = runner.invoke(app, ["stream", "switch"])
        assert result.exit_code == 1
        assert "name required" in result.output.lower()

    def test_stream_create(self):
        with patch("gitrama.cli.StreamManager") as mock:
            manager = MagicMock()
            mock.return_value = manager
            result = runner.invoke(app, ["stream", "create", "epic", "--desc", "Epic work"])
        assert result.exit_code == 0
        manager.create_stream.assert_called_once_with("epic", "Epic work")

    def test_stream_create_no_name(self):
        with patch("gitrama.cli.StreamManager"):
            result = runner.invoke(app, ["stream", "create"])
        assert result.exit_code == 1

    def test_stream_delete(self):
        with patch("gitrama.cli.StreamManager") as mock:
            manager = MagicMock()
            mock.return_value = manager
            result = runner.invoke(app, ["stream", "delete", "epic"])
        assert result.exit_code == 0
        manager.delete_stream.assert_called_once_with("epic")

    def test_stream_unknown_action(self):
        with patch("gitrama.cli.StreamManager"):
            result = runner.invoke(app, ["stream", "invalid"])
        assert result.exit_code == 1
        assert "Unknown action" in result.output

    def test_stream_alias(self):
        with patch("gitrama.cli.StreamManager") as mock:
            manager = MagicMock()
            mock.return_value = manager
            result = runner.invoke(app, ["s", "list"])
        assert result.exit_code == 0


# ─── Health ───────────────────────────────────────────────────────────────────

class TestHealth:

    def test_health_passing(self, mock_ai_client):
        mock_ai_client.health_check.return_value = {
            "status": "healthy",
            "model": "claude-opus-4-6"
        }
        result = runner.invoke(app, ["health"])
        assert result.exit_code == 0
        assert "healthy" in result.output.lower()

    def test_health_failing(self, mock_ai_client):
        mock_ai_client.health_check.return_value = {"status": "error"}
        result = runner.invoke(app, ["health"])
        assert result.exit_code == 1

    def test_health_exception(self, mock_ai_client):
        mock_ai_client.health_check.side_effect = Exception("Connection refused")
        result = runner.invoke(app, ["health"])
        assert result.exit_code == 1
        assert "Error" in result.output

    def test_health_alias(self, mock_ai_client):
        mock_ai_client.health_check.return_value = {"status": "healthy", "model": "gpt-4o"}
        result = runner.invoke(app, ["h"])
        assert result.exit_code == 0


# ─── Config ───────────────────────────────────────────────────────────────────

class TestConfig:

    def test_config_list(self):
        with patch("gitrama.cli.load_config", return_value={"provider": "anthropic", "api_key": "test"}):
            result = runner.invoke(app, ["config", "list"])
        assert result.exit_code == 0
        assert "provider" in result.output
        assert "anthropic" in result.output

    def test_config_set(self):
        with patch("gitrama.cli.set_value") as mock_set:
            result = runner.invoke(app, ["config", "set", "model", "gpt-4o"])
        assert result.exit_code == 0
        mock_set.assert_called_once_with("model", "gpt-4o")

    def test_config_set_provider(self):
        with patch("gitrama.cli.set_provider", return_value="https://api.anthropic.com") as mock_set:
            result = runner.invoke(app, ["config", "set", "provider", "anthropic"])
        assert result.exit_code == 0
        assert "anthropic" in result.output

    def test_config_set_invalid_provider(self):
        with patch("gitrama.cli.set_provider", side_effect=ValueError("Invalid provider")):
            result = runner.invoke(app, ["config", "set", "provider", "invalid"])
        assert result.exit_code == 1

    def test_config_set_missing_value(self):
        result = runner.invoke(app, ["config", "set", "model"])
        assert result.exit_code == 1

    def test_config_get(self):
        with patch("gitrama.cli.get_value", return_value="anthropic"):
            result = runner.invoke(app, ["config", "get", "provider"])
        assert result.exit_code == 0
        assert "anthropic" in result.output

    def test_config_get_missing_key(self):
        with patch("gitrama.cli.get_value", return_value=None):
            result = runner.invoke(app, ["config", "get", "nonexistent"])
        assert result.exit_code == 0
        assert "not found" in result.output

    def test_config_get_no_key(self):
        result = runner.invoke(app, ["config", "get"])
        assert result.exit_code == 1

    def test_config_reset(self):
        with patch("gitrama.cli.reset_config") as mock_reset:
            result = runner.invoke(app, ["config", "reset"])
        assert result.exit_code == 0
        mock_reset.assert_called_once()

    def test_config_unknown_action(self):
        result = runner.invoke(app, ["config", "invalid"])
        assert result.exit_code == 1
        assert "Unknown action" in result.output


# ─── Checkout ─────────────────────────────────────────────────────────────────

class TestCheckout:

    def test_checkout_existing_branch(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stderr="")
            result = runner.invoke(app, ["checkout", "main"])
        assert result.exit_code == 0
        assert "Switched" in result.output

    def test_checkout_new_branch(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stderr="")
            result = runner.invoke(app, ["checkout", "-b", "feat/new"])
        assert result.exit_code == 0
        assert "new" in result.output.lower()

    def test_checkout_fails(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=1,
                stderr="error: pathspec 'nonexistent' did not match"
            )
            result = runner.invoke(app, ["checkout", "nonexistent"])
        assert result.exit_code == 1
        assert "failed" in result.output.lower()


# ─── Chat ─────────────────────────────────────────────────────────────────────

class TestChat:

    def test_chat_registered(self):
        """Verify chat command is registered and reachable."""
        result = runner.invoke(app, ["chat", "--help"])
        assert result.exit_code == 0

    def test_ask_registered(self):
        """Verify ask alias is registered."""
        result = runner.invoke(app, ["ask", "--help"])
        assert result.exit_code == 0


# ─── Git Wrapper Commands ─────────────────────────────────────────────────────

class TestGitWrappers:

    def test_status_registered(self):
        result = runner.invoke(app, ["status", "--help"])
        assert result.exit_code == 0

    def test_log_registered(self):
        result = runner.invoke(app, ["log", "--help"])
        assert result.exit_code == 0

    def test_diff_registered(self):
        result = runner.invoke(app, ["diff", "--help"])
        assert result.exit_code == 0

    def test_push_registered(self):
        result = runner.invoke(app, ["push", "--help"])
        assert result.exit_code == 0

    def test_pull_registered(self):
        result = runner.invoke(app, ["pull", "--help"])
        assert result.exit_code == 0

    def test_fetch_registered(self):
        result = runner.invoke(app, ["fetch", "--help"])
        assert result.exit_code == 0

    def test_stash_registered(self):
        result = runner.invoke(app, ["stash", "--help"])
        assert result.exit_code == 0

    def test_merge_registered(self):
        result = runner.invoke(app, ["merge", "--help"])
        assert result.exit_code == 0

    def test_add_registered(self):
        result = runner.invoke(app, ["add", "--help"])
        assert result.exit_code == 0