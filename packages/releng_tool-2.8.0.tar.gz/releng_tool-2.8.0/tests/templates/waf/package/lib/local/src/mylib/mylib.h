#pragma once

void process();
