#include <iostream>

void process() {
    std::cout << "process\n";
}
