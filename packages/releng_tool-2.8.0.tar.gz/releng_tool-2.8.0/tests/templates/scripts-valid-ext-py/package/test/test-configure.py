file_flag = TARGET_DIR / 'invoked-configure'
releng_touch(file_flag)
