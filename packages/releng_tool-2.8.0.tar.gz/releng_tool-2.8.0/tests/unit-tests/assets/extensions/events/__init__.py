# sample extension that registers on various events
def releng_setup(app):
    app.connect('config-loaded', on_config_event)
    app.connect('package-bootstrap-finished', on_pkg_bootstrap_finished)
    app.connect('package-bootstrap-started', on_pkg_bootstrap_started)
    app.connect('package-build-finished', on_pkg_build_finished)
    app.connect('package-build-started', on_pkg_build_started)
    app.connect('package-configure-finished', on_pkg_configure_finished)
    app.connect('package-configure-started', on_pkg_configure_started)
    app.connect('package-install-finished', on_pkg_install_finished)
    app.connect('package-install-started', on_pkg_install_started)
    app.connect('package-postprocess-finished', on_pkg_postprocess_finished)
    app.connect('package-postprocess-started', on_pkg_postprocess_started)
    app.connect('post-build-finished', on_post_build_finished)
    app.connect('post-build-started', on_post_build_started)


def on_config_event(env):
    env['last-event'] = 'config-loaded'


def on_pkg_bootstrap_finished(env):
    env['last-event'] = 'package-bootstrap-finished'


def on_pkg_bootstrap_started(env):
    env['last-event'] = 'package-bootstrap-started'


def on_pkg_build_finished(env):
    env['last-event'] = 'package-build-finished'


def on_pkg_build_started(env):
    env['last-event'] = 'package-build-started'


def on_pkg_configure_finished(env):
    env['last-event'] = 'package-configure-finished'


def on_pkg_configure_started(env):
    env['last-event'] = 'package-configure-started'


def on_pkg_install_finished(env):
    env['last-event'] = 'package-install-finished'


def on_pkg_install_started(env):
    env['last-event'] = 'package-install-started'


def on_pkg_postprocess_finished(env):
    env['last-event'] = 'package-postprocess-finished'


def on_pkg_postprocess_started(env):
    env['last-event'] = 'package-postprocess-started'


def on_post_build_started(env):
    env['last-event'] = 'post-build-started'


def on_post_build_finished(env):
    env['last-event'] = 'post-build-finished'
