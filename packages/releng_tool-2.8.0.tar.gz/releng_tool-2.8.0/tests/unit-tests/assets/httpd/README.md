The following holds test keys to validate URL related features of
releng-tool. This includes public and "private" keys for unit testing
preparing a local https instance.
