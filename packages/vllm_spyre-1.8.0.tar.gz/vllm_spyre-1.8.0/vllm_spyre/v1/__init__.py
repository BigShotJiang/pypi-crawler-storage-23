"""This module holds the v1 compatible implementations of spyre-related classes"""
