"""Allow running the MCP server as ``python -m specterqa.mcp``."""

from specterqa.mcp.server import main

main()
