"""SpecterQA CLI — Typer + Rich command-line interface."""
