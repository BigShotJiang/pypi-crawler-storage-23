"""Allow running as python -m specterqa."""

from specterqa.cli.app import app

app()
