"""SpecterQA — AI persona-based behavioral testing for web apps."""

__version__ = "0.3.0"
