"""
Drive grid module
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Guille Gutierrez guillermo.gutierrezmorote@concordia.ca
"""
from typing import TypeVar

import networkx as nx
import osmnx as ox

from hub.city_model_structure.city_object import CityObject
from hub.city_model_structure.drive.drive_edge import DriveEdge
from hub.city_model_structure.drive.drive_node import DriveNode

City = TypeVar('City')

class DriveGraph(CityObject):
  """
  Drive graph class
  """

  def __init__(self, date: str, tool: str, crs: str, nodes: list[DriveNode], edges: list[DriveEdge], name: str, city: City, osm_graph: ox.graph) -> None:
    super().__init__(name, None)
    self._date = date
    self._tool = tool
    self._crs = crs
    self._nodes = nodes
    self._edges = edges
    self._city = city
    self._type = 'drive'
    self._osm_graph = osm_graph
    self._shortest_path_tree = None
    self._source_node = None

  @property
  def source_node(self) -> DriveNode:
    return self._source_node

  @property
  def city(self) -> City:
    """
    Get city graph
    :return: City
    """
    return self._city

  @property
  def date(self) -> str:
    """
    Get drive graph creation date
    :return: string
    """
    return self._date

  @property
  def tool(self) -> str:
    """
    Get drive graph creation tool
    :return: string
    """
    return self._tool

  @property
  def crs(self) -> str:
    """
    Get drive graph coordinate reference system
    :return: string
    """
    return self._crs

  @property
  def nodes(self) -> list[DriveNode]:
    """
    Get drive graph nodes
    :return: [Nodes]
    """
    return self._nodes

  @property
  def edges(self) -> list[DriveEdge]:
    """
    Get drive graph edges
    :return: [Edges]
    """
    return self._edges

  @property
  def osm_graph(self) -> ox.graph:
    """
    Get drive graph contains the source graph object from
    :return: osmnx.graph
    """
    return self._osm_graph

  def get_shortest_path_tree(self, source: DriveNode):
    """
    Retrieve the shortest path tree starting from source drive node
    :param source: source drive node
    :return: Dictionary of shortest path lengths keyed by target
    """
    if source is None:
      deg = dict(self._osm_graph.degree())
      source = max(deg, key=deg.get)

    if source != self._source_node: # ensures that only recalculate on a new source node
      self._shortest_path_tree = nx.single_source_dijkstra_path(self._osm_graph, source=source, weight='length')
      self._source_node = source

    return self._shortest_path_tree




