"""
Drive node module
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Guille Gutierrez guillermo.gutierrezmorote@concordia.ca
"""
from typing import TypeVar

from hub.city_model_structure.attributes.node import Node

Edge = TypeVar('Edge')


class DriveNode(Node):
  def __init__(self, name: str, x: float, y: float, street_count: int) -> None:
    self._x = x
    self._y = y
    self._street_count = street_count
    super().__init__(name=name)

  @property
  def x(self) -> float:
    """
    X position of the drive node in WGS 84
    :return: x position of the drive node
    """
    return self._x

  @property
  def y(self) -> float:
    """
    Y position of the drive node in WGS 84
    :return: y position of the drive node
    """
    return self._y

  @property
  def street_count(self) -> int:
    """
    Street count of the drive node
    :return: Street count of the drive node
    """
    return self._street_count
