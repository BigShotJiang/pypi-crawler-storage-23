"""
Drive edge module
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Guille Gutierrez guillermo.gutierrezmorote@concordia.ca
"""
from typing import TypeVar

from hub.city_model_structure.attributes.edge import Edge
from hub.city_model_structure.drive.drive_node import DriveNode

Node = TypeVar('Node')


class DriveEdge(Edge):
  def __init__(self, name: str, nodes: list[DriveNode], highway_type: str, lanes: int, max_speed: int, street_name: str, oneway: bool, width: float, is_reversed: bool, length: float):
    super().__init__(name, nodes)
    self._highway_type = highway_type
    self._lanes = lanes
    self._max_speed = max_speed
    self._street_name = street_name
    self._oneway = oneway
    self._width = width
    self._is_reversed = is_reversed
    self._length = length

  @property
  def highway_type(self):
    """
    Get were the edge highway type
    :return: string
    """
    return self._highway_type

  @property
  def lanes(self):
    """
    Get the number of lanes
    :return: int
    """
    return self._lanes

  @property
  def max_speed(self):
    """
    Get the maximum speed
    :return: int
    """
    return self._max_speed

  @property
  def street_name(self):
    """
    Get the street name
    :return: str
    """
    return self._street_name

  @property
  def oneway(self):
    """
    Get were the edge is oneway
    :return: boolean
    """
    return self._oneway

  @property
  def width(self):
    """
    Get the edge (road) width
    :return: float
    """
    return self._width

  @property
  def is_reversed(self):
    """
    Get were the edge is reversed
    :return: boolean
    """
    return self._is_reversed

  @property
  def length(self):
    """
    Get the edge (road) length
    :return: float
    """
    return self._length

