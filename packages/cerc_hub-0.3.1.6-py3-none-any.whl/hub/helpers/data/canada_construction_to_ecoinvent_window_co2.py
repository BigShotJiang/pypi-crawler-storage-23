"""
Dictionaries module for Canada construction to Hub window CO2 emissions
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2019 - 2025 Concordia CERC group
Project Coder Koa Wells kekoa.wells@concordia.ca
"""

class CanadaConstructionToEcoinventWindowCo2:
  """
  Canada construction to Hub window CO2 emissions class
  """

  # TODO update catalog with updated canadian CO2 values
  def __init__(self):
    self._dictionary = {
      'GLZ_SC': {
        'name': '1',
        'factor': 1.0
      },
      'GLZ_DC_AIR': {
        'name': '2',
        'factor': 1.0
      },
      'GLZ_DLE_ARG': {
        'name': '2',
        'factor': 1.0
      },
      'GLZ_TC_ARG': {
        'name': '3',
        'factor': 1.0
      },
      'GLZ_TLE_AK': {
        'name': '3',
        'factor': 1.0
      },
      'GLZ_DSYS': {
        'name': '4',
        'factor': 1.0
      },
      'GLZ_TSYS': {
        'name': '5',
        'factor': 1.0
      },
      'GLZ_DCW': {
        'name': '6',
        'factor': 1.0
      },
      'GLZ_TCW': {
        'name': '6',
        'factor': 1.0
      }
    }

  @property
  def dictionary(self) -> dict:
    """
    Get the dictionary
    :return: {}
    """
    return self._dictionary
