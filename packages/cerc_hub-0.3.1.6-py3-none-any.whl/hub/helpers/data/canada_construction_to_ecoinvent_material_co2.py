"""
Dictionaries module for Canada construction to Hub material CO2 emissions
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2019 - 2025 Concordia CERC group
Project Coder Koa Wells kekoa.wells@concordia.ca
"""


class CanadaConstructionToEcoinventMaterialCo2:
  """
  Canada construction to Hub material CO2 emissions class
  """

  # TODO update catalog with updated canadian CO2 values
  def __init__(self):
    self._dictionary = {
        "CONC_NW": {
            "name": "cast_concrete",
            "factor": 1.0
        },
        "CONC_LW": {
            "name": "cast_concrete",
            "factor": 1.0
        },
        "CONC_HW": {
            "name": "cast_concrete",
            "factor": 1.0
        },
        "CONC_PC": {
            "name": "cast_concrete",
            "factor": 1.0
        },
        "BRICK_CLAY": {
            "name": "outer_brickwork",
            "factor": 1.0
        },
        "BRICK_2WY": {
            "name": "outer_brickwork",
            "factor": 1.0
        },
        "BRICK_3WY": {
            "name": "outer_brickwork",
            "factor": 1.0
        },
        "CMU": {
            "name": "medium_concrete_block",
            "factor": 1.0
        },
        "CONC_STD": {
            "name": "screed_floor_roof",
            "factor": 1.0
        },
        "STONE_LS": {
            "name": "outer_brickwork",
            "factor": 1.0
        },
        "LUMB_SPF_2X4": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "LUMB_SPF_2X6": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "PLY": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "OSB": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "CLT": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "GLULAM": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "LVL": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "STL_SECTION": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "STL_REBAR": {
            "name": "cast_concrete",
            "factor": 1.0
        },
        "MET_DECK": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "BGW_RSFW": {
            "name": "outer_brickwork",
            "factor": 1.0
        },
        "CW_BP_GS": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "STUCCO": {
            "name": "gypsum_plastering",
            "factor": 1.0
        },
        "FCS": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "MS_AL": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "MS_GS": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "ACM": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "BRICK_VEN": {
            "name": "outer_brickwork",
            "factor": 1.0
        },
        "STONE_VEN": {
            "name": "outer_brickwork",
            "factor": 1.0
        },
        "EIFS_EPS": {
            "name": "xps_extruded_polystyrene",
            "xps_extruded_polystyrene": 1.0
        },
        "CW_GLZ_DBL": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "CW_GLZ_TRPL": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "ACOUSTIC_PNL": {
            "name": "plasterboard",
            "factor": 1.0
        },
        "ROOF_ASPH_SHNG": {
            "name": "asphalt",
            "factor": 1.0
        },
        "ROOF_WOOD_SHNG": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "BUR_STD": {
            "name": "asphalt",
            "factor": 1.0
        },
        "BUR_HR": {
            "name": "asphalt",
            "factor": 1.0
        },
        "ROOF_MODBIT_SBS": {
            "name": "asphalt",
            "factor": 1.0
        },
        "ROOF_EPDM": {
            "name": "asphalt",
            "factor": 1.0
        },
        "ROOF_TPO": {
            "name": "asphalt",
            "factor": 1.0
        },
        "ROOF_PVC": {
            "name": "asphalt",
            "factor": 1.0
        },
        "ROOF_MET_STL": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "ROOF_MET_AL": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "ROOF_GREEN": {
            "name": "screed_floor_roof",
            "factor": 1.0
        },
        "ROOF_MEM_NR": {
            "name": "asphalt",
            "factor": 1.0
        },
        "ROOF_MEM_HR": {
            "name": "asphalt",
            "factor": 1.0
        },
        "FR_DLS": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "RF_STM50": {
            "name": "screed_floor_roof",
            "factor": 1.0
        },
        "MW_BATT": {
            "name": "mw_glass_wool",
            "factor": 1.0
        },
        "MW_BRD": {
            "name": "mw_glass_wool",
            "factor": 1.0
        },
        "XPS": {
            "name": "xps_extruded_polystyrene",
            "factor": 1.0
        },
        "EPS": {
            "name": "urea_formaldehyde_foam",
            "factor": 1.0
        },
        "POLYISO": {
            "name": "xps_extruded_polystyrene",
            "factor": 1.0
        },
        "FGB_BATT": {
            "name": "mw_glass_wool",
            "factor": 1.0
        },
        "CELL_LF": {
            "name": "urea_formaldehyde_foam",
            "factor": 1.0
        },
        "SPF_CC": {
            "name": "urea_formaldehyde_foam",
            "factor": 1.0
        },
        "SPF_OC": {
            "name": "urea_formaldehyde_foam",
            "factor": 1.0
        },
        "WFB": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "HEMP_BATT": {
            "name": "mw_glass_wool",
            "factor": 1.0
        },
        "SW_BATT": {
            "name": "mw_glass_wool",
            "factor": 1.0
        },
        "AERO": {
            "name": "mw_glass_wool",
            "factor": 1.0
        },
        "SSW_R20": {
            "name": "plasterboard",
            "factor": 1.0
        },
        "SSW_R22": {
            "name": "plasterboard",
            "factor": 1.0
        },
        "GYP": {
            "name": "plasterboard",
            "factor": 1.0
        },
        "MDF": {
            "name": "tR20, plasterboardimber_flooring",
            "factor": 1.0
        },
        "PB": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "PLAST_LATH": {
            "name": "gypsum_plastering",
            "factor": 1.0
        },
        "CARPET": {
            "name": "urea_formaldehyde_foam",
            "factor": 1.0
        },
        "CARPET_PAD": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "VINYL": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "LAMINATE": {
            "name": "ttimber_flooringimber_flooring",
            "factor": 1.0
        },
        "CER_TILE": {
            "name": "screed_floor_roof",
            "factor": 1.0
        },
        "GRAN_TILE": {
            "name": "screed_floor_roof",
            "factor": 1.0
        },
        "HARD_WOOD_OAK": {
            "name": "timber_flooring",
            "factor": 1.0
        },
        "ACT": {
            "name": "urea_formaldehyde_foam",
            "factor": 1.0
        },
        "PIPE_CU": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "PIPE_PEX": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "PIPE_PVC": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "PIPE_CI": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "DUCT_GS": {
            "name": "lightweight_metallic_cladding",
            "factor": 1.0
        },
        "VB_POLY": {
            "name": "urea_formaldehyde_foam",
            "factor": 1.0
        },
        "AB_MEM": {
            "name": "urea_formaldehyde_foam",
            "factor": 1.0
        },
        "WRB": {
            "name": "urea_formaldehyde_foam",
            "factor": 1.0
        },
        "CAVITY_25": {
            "name": "air_gap",
            "factor": 1.0
        },
        "GRAVEL_BASE": {
            "name": "screed_floor_roof",
            "factor": 1.0
        },
    }

  @property
  def dictionary(self) -> dict:
    """
    Get the dictionary
    :return: {}
    """
    return self._dictionary
