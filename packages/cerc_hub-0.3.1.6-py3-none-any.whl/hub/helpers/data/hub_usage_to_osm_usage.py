"""
Dictionaries module for hub usage to OSM usage
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Guille Gutierrez Guillermo.GutierrezMorote@concordia.ca
"""

import hub.helpers.constants as cte


class HubUsageToOsmUsage:
  """
  Hub usage to OSM usage class
  """

  def __init__(self):
    self._dictionary = {
      cte.RESIDENTIAL: 'residential',
      cte.SINGLE_FAMILY_HOUSE: 'house',
      cte.MULTI_FAMILY_HOUSE: 'apartments',
      cte.ROW_HOUSE: 'terrace',
      cte.MID_RISE_APARTMENT: 'apartments',
      cte.HIGH_RISE_APARTMENT: 'apartments',
      cte.OFFICE_AND_ADMINISTRATION: 'office',
      cte.SMALL_OFFICE: 'office',
      cte.MEDIUM_OFFICE: 'office',
      cte.LARGE_OFFICE: 'office',
      cte.COURTHOUSE: 'courthouse',
      cte.FIRE_STATION: 'fire_station',
      cte.PENITENTIARY: 'prison',
      cte.POLICE_STATION: 'police',
      cte.POST_OFFICE: 'post_office',
      cte.LIBRARY: 'library',
      cte.EDUCATION: 'school',
      cte.PRIMARY_SCHOOL: 'school',
      cte.PRIMARY_SCHOOL_WITH_SHOWER: 'school',
      cte.SECONDARY_SCHOOL: 'school',
      cte.UNIVERSITY: 'university',
      cte.LABORATORY_AND_RESEARCH_CENTER: 'research_institute',
      cte.STAND_ALONE_RETAIL: 'retail',
      cte.HOSPITAL: 'hospital',
      cte.OUT_PATIENT_HEALTH_CARE: 'clinic',
      cte.HEALTH_CARE: 'clinic',
      cte.RETIREMENT_HOME_OR_ORPHANAGE: 'social_facility',
      cte.COMMERCIAL: 'commercial',
      cte.STRIP_MALL: 'retail',
      cte.SUPERMARKET: 'supermarket',
      cte.RETAIL_SHOP_WITHOUT_REFRIGERATED_FOOD: 'retail',
      cte.RETAIL_SHOP_WITH_REFRIGERATED_FOOD: 'retail',
      cte.RESTAURANT: 'restaurant',
      cte.QUICK_SERVICE_RESTAURANT: 'fast_food',
      cte.FULL_SERVICE_RESTAURANT: 'restaurant',
      cte.HOTEL: 'hotel',
      cte.HOTEL_MEDIUM_CLASS: 'hotel',
      cte.SMALL_HOTEL: 'hotel',
      cte.LARGE_HOTEL: 'hotel',
      cte.DORMITORY: 'dormitory',
      cte.EVENT_LOCATION: 'events_venue',
      cte.CONVENTION_CENTER: 'convention_centre',
      cte.HALL: 'hall',
      cte.GREEN_HOUSE: 'greenhouse',
      cte.INDUSTRY: 'industrial',
      cte.WORKSHOP: 'workshop',
      cte.WAREHOUSE: 'warehouse',
      cte.WAREHOUSE_REFRIGERATED: 'warehouse',
      cte.SPORTS_LOCATION: 'sports_centre',
      cte.SPORTS_ARENA: 'sports_hall',
      cte.GYMNASIUM: 'sports_hall',
      cte.MOTION_PICTURE_THEATRE: 'cinema',
      cte.MUSEUM: 'museum',
      cte.PERFORMING_ARTS_THEATRE: 'theatre',
      cte.TRANSPORTATION: 'transportation',
      cte.AUTOMOTIVE_FACILITY: 'garage',
      cte.PARKING_GARAGE: 'garage',
      cte.RELIGIOUS: 'religious',
      cte.NON_HEATED: 'shed',
      cte.DATACENTER: 'data_center',
      cte.FARM: 'farm',
    }

  @property
  def dictionary(self) -> dict:
    """
    Get the dictionary
    :return: {}
    """
    return self._dictionary