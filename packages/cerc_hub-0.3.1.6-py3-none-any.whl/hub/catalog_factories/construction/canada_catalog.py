"""
Canada construction catalog
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2022 Concordia CERC group
Project Coder Pilar Monsalvete Alvarez de Uribarri pilar.monsalvete@concordia.ca
"""

import json
from pathlib import Path
import numpy as np
import pandas as pd
from hub.catalog_factories.catalog import Catalog
from hub.catalog_factories.data_models.construction.content import Content
from hub.catalog_factories.construction.construction_helper import ConstructionHelper
from hub.catalog_factories.data_models.construction.construction import Construction
from hub.catalog_factories.data_models.construction.archetype import Archetype
from hub.catalog_factories.data_models.construction.window import Window
from hub.catalog_factories.data_models.construction.material import Material
from hub.catalog_factories.data_models.construction.layer import Layer
import hub.helpers.constants as cte


class CanadaCatalog(Catalog):
  """
  Canada catalog class
  """

  def __init__(self, path, filename='canada_archetypes_construction.xlsx'):
    _catalog_path = Path(path / filename).resolve()
    self._catalog_data = self.read_catalog_file(_catalog_path)

    self._catalog_windows = self._load_windows()
    self._catalog_materials = self._load_materials()
    self._catalog_constructions = self._load_constructions()
    self._catalog_archetypes = self._load_archetypes()

    # store the full catalog data model in self._content
    self._content = Content(self._catalog_archetypes,
                            self._catalog_constructions,
                            self._catalog_materials,
                            self._catalog_windows)

  def read_catalog_file(self, catalog_path: Path):
    """ 
    read catalog from file 
    :param catalog_path: the path to the catalog
    """
    catalog_data = pd.read_excel(
        catalog_path,
        sheet_name=['Archetypes',
                    'Constructions',
                    'Materials',
                    'Windows'],
        header=0
    )
    return catalog_data

  def _load_windows(self):
    """ 
    load windows from catalog
    """
    windows = self._catalog_data['Windows']
    _catalog_windows = []
    for _, window in windows.iterrows():
      name = window['name']
      window_id = window['id']
      g_value = window['shgc']
      window_type = 'window'
      frame_ratio = window['frame_ratio']
      overall_u_value = window['u_value_w_per_m2k']
      _catalog_windows.append(Window(window_id, frame_ratio, g_value, overall_u_value, name, window_type))
    return _catalog_windows

  def _load_materials(self):
    """ 
    load materials from catalog
    """
    _catalog_materials = []
    materials = self._catalog_data['Materials']
    for _, material in materials.iterrows():
      name = material['name']
      material_id = material['id']
      no_mass = False
      thermal_resistance = None
      conductivity = material['conductivity_w_per_mk']
      solar_absorptance = material['solar_absorptance']
      density = material['density_kg_per_m3']
      specific_heat = material['specific_heat_j_per_kgk']
      solar_absorptance = material['solar_absorptance']
      thermal_absorptance = material['thermal_absorptance']
      visible_absorptance = material['visible_absorptance']
      _material = Material(material_id,
                           name,
                           solar_absorptance,
                           thermal_absorptance,
                           visible_absorptance,
                           no_mass,
                           thermal_resistance,
                           conductivity,
                           density,
                           specific_heat)
      _catalog_materials.append(_material)
    return _catalog_materials

  def _load_constructions(self):
    """ 
    load constructions from catalog and gather associated materials in layers
    """
    _catalog_constructions = []
    constructions = self._catalog_data['Constructions']
    for _, construction in constructions.iterrows():
      name = f'{construction['function']} - {construction['construction_year']} - cz{construction['climate_zone']} - {construction['construction_surface']}'
      construction_id = f'{construction['function']}_{construction['construction_year']}_{construction['climate_zone']}'
      construction_type = ConstructionHelper().canada_surfaces_types_to_hub_types[construction['construction_surface']]
      construction_window = None
      construction_window_ratio = None

      layers = []
      for layer_num in range(1, 8):
        if construction[f'layer_{layer_num}'] == np.nan:
          pass
        layer_name = f'layer_{layer_num}'
        layer_id = layer_num
        material_id = f'{construction[f'layer_{layer_num}']}'
        thickness = construction[f'layer_{layer_num}_thickness_m']
        for material in self._catalog_materials:
          if str(material_id) == str(material.id):
            layers.append(Layer(layer_id, layer_name, material, thickness))
            break

      _window = construction['window']
      if _window is not np.nan:
        for window in self._catalog_windows:
          if str(window.id) == _window:
            construction_window = window
            construction_window_ratio = json.loads(str(construction['window_ratio']))

      _catalog_constructions.append(Construction(construction_id, construction_type, name,
                                    layers, construction_window_ratio, construction_window))
    return _catalog_constructions

  def _load_archetypes(self):
    """ 
    load constructions from catalog and gather associated constructions
    """
    _catalog_archetypes = []
    archetypes = self._catalog_data['Archetypes']
    for _, archetype in archetypes.iterrows():
      name = f'{archetype["function"]} - {archetype["construction_year"]} - cz{archetype["climate_zone"]}'
      archetype_id = f'{archetype["function"]}_{archetype["construction_year"]}_{archetype["climate_zone"]}'
      function = archetype['function']
      climate_zone = archetype['climate_zone']
      construction_period = archetype['construction_year']
      average_storey_height = archetype['average_storey_height']
      thermal_capacity = float(archetype['thermal_capacity']) * 1000
      extra_loses_due_to_thermal_bridges = archetype['extra_loses_due_thermal_bridges']
      infiltration_rate_for_ventilation_system_off = (
          archetype['infiltration_rate_for_ventilation_system_off'] / cte.HOUR_TO_SECONDS
      )
      infiltration_rate_for_ventilation_system_on = (
          archetype['infiltration_rate_for_ventilation_system_on'] / cte.HOUR_TO_SECONDS
      )
      infiltration_rate_area_for_ventilation_system_off = (
          archetype['infiltration_rate_area_for_ventilation_system_off']
      )
      infiltration_rate_area_for_ventilation_system_on = (
          archetype['infiltration_rate_area_for_ventilation_system_on']
      )

      construction_id = f'{archetype['construction_archetype_map']}_{archetype['construction_year']}_{archetype['climate_zone']}'
      archetype_constructions = []
      for construction in self._catalog_constructions:
        if str(construction_id) == str(construction.id):
          archetype_constructions.append(construction)

      _catalog_archetypes.append(Archetype(archetype_id,
                                           name,
                                           function,
                                           climate_zone,
                                           construction_period,
                                           archetype_constructions,
                                           average_storey_height,
                                           thermal_capacity,
                                           extra_loses_due_to_thermal_bridges,
                                           None,
                                           infiltration_rate_for_ventilation_system_off,
                                           infiltration_rate_for_ventilation_system_on,
                                           infiltration_rate_area_for_ventilation_system_off,
                                           infiltration_rate_area_for_ventilation_system_on
                                           ))
    return _catalog_archetypes

  def names(self, category=None):
    """
    Get the catalog elements names
    :parm: optional category filter
    """
    if category is None:
      _names = {'archetypes': [], 'constructions': [], 'materials': [], 'windows': []}
      for archetype in self._content.archetypes:
        _names['archetypes'].append(archetype.name)
      for construction in self._content.constructions:
        _names['constructions'].append(construction.name)
      for material in self._content.materials:
        _names['materials'].append(material.name)
      for window in self._content.windows:
        _names['windows'].append(window.name)
    else:
      _names = {category: []}
      if category.lower() == 'archetypes':
        for archetype in self._content.archetypes:
          _names[category].append(archetype.name)
      elif category.lower() == 'constructions':
        for construction in self._content.constructions:
          _names[category].append(construction.name)
      elif category.lower() == 'materials':
        for material in self._content.materials:
          _names[category].append(material.name)
      elif category.lower() == 'windows':
        for window in self._content.windows:
          _names[category].append(window.name)
      else:
        raise ValueError(f'Unknown category [{category}]')
    return _names

  def entries(self, category=None):
    """
    Get the catalog elements
    :parm: optional category filter
    """
    if category is None:
      return self._content
    if category.lower() == 'archetypes':
      return self._content.archetypes
    if category.lower() == 'constructions':
      return self._content.constructions
    if category.lower() == 'materials':
      return self._content.materials
    if category.lower() == 'windows':
      return self._content.windows
    raise ValueError(f'Unknown category [{category}]')

  def get_entry(self, name):
    """
    Get one catalog element by names
    :parm: entry name
    """
    for entry in self._content.archetypes:
      if entry.name.lower() == name.lower():
        return entry
    for entry in self._content.constructions:
      if entry.name.lower() == name.lower():
        return entry
    for entry in self._content.materials:
      if entry.name.lower() == name.lower():
        return entry
    for entry in self._content.windows:
      if entry.name.lower() == name.lower():
        return entry
    raise IndexError(f"{name} doesn't exists in the catalog")
