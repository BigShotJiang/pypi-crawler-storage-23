"""
Power Distribution System OSM exporter
SPDX-License-Identifier: LGPL-3.0-or-later
Copyright © 2026 Concordia CERC group
Code coder: Guille Gutierrez Morote guillermo.gutierrezmorote@concordia.ca
Code contributors: Bilal Khan khan.bilal@mail.concordia.ca
"""
import logging
import math

import osmnx as ox
import pyproj
from pyproj import Transformer
from shapely.constructive import centroid

from hub.city_model_structure.city import City
from hub.city_model_structure.drive.drive_edge import DriveEdge
from hub.city_model_structure.drive.drive_graph import DriveGraph
from hub.city_model_structure.drive.drive_node import DriveNode
from hub.helpers.geometry_helper import GeometryHelper


def _get_node(nodes: list[DriveNode], name: str) -> DriveNode | None:
  for node in nodes:
    if node.name == name:
      return node
  return None


class Osm:
  """
  Import to an osm file
  """

  def __init__(self, city: City):
    """
    :param city: the city object to export
    """
    self._city = city
    self._srs_name = city.srs_name
    self._enrich()

  def _enrich(self):
    """
    Export the city to an osm file
    :return: None
    """
    distance = abs(math.sqrt((self._city.lower_corner[0] - self._city.upper_corner[0])**2 + (self._city.lower_corner[1] - self._city.upper_corner[1])**2))
    x = self._city.upper_corner[0] + (self._city.lower_corner[0] - self._city.upper_corner[0]) / 2
    y = self._city.upper_corner[1] + (self._city.lower_corner[1] - self._city.upper_corner[1]) / 2
    center = self._transform((x,y))
    _graph = ox.graph_from_point(center_point=center, dist=distance, network_type='drive', simplify=False)
    nodes = []
    edges = []
    nodes_dict = {}
    for node_id, node_data in _graph.nodes(data=True):
      drive_node = DriveNode(node_id, node_data['x'], node_data['y'], node_data['street_count'])
      nodes.append(drive_node)
      nodes_dict[node_id] = drive_node

    for node_1, node_2, edge_data in _graph.edges(data=True):
      edge_nodes = [_get_node(nodes, node_1), _get_node(nodes, node_2)]
      width = -1
      if 'width' in edge_data:
        width = edge_data['width']
      edge = DriveEdge(name=edge_data['osmid'], nodes=edge_nodes, highway_type=edge_data['highway'], lanes=edge_data['lanes'], max_speed=edge_data['maxspeed'], street_name=edge_data['name'], oneway=edge_data['oneway'], width=width, is_reversed=edge_data['reversed'], length=edge_data['length'])
      edges.append(edge)

    drive_graph = DriveGraph("", "", "", nodes=nodes, edges=edges, name="Drive Graph", city=self._city, osm_graph=_graph)
    self._city.add_city_object(drive_graph)
    for building in self._city.buildings:
      _centroid = building.centroid
      _gps_center = self._transform((_centroid[0], _centroid[1]))
      nearest = ox.nearest_nodes(_graph, _gps_center[1], _gps_center[0])
      building.nearest_node = nodes_dict[nearest]
    return

  def _transform(self, coordinates):
    gps = pyproj.CRS('EPSG:4326')  # LatLon with WGS84 datum used by GPS units and Google Earth
    try:
      if self._srs_name in GeometryHelper.srs_transformations:
        self._srs_name = GeometryHelper.srs_transformations[self._srs_name]
      input_reference = pyproj.CRS(self._srs_name)  # Projected coordinate system from input data
    except pyproj.exceptions.CRSError as err:
      logging.error('Invalid projection reference system, please check the input data.')
      raise pyproj.exceptions.CRSError from err
    transformer = Transformer.from_crs(input_reference, gps)
    return transformer.transform(coordinates[0], coordinates[1])

  @property
  def city(self):
    return self._city
