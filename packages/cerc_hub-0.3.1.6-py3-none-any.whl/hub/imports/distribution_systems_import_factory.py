"""
Distribution System importer
SPDX-License-Identifier: LGPL-3.0-or-later
Copyright © 2026 Concordia CERC group
Code coder: Guille Gutierrez Morote guillermo.gutierrezmorote@concordia.ca
Code contributors: Bilal Khan khan.bilal@mail.concordia.ca
"""
from pathlib import Path

from hub.city_model_structure.city import City
from hub.imports.distribution_systems.osm import Osm
from hub.helpers.utils import validate_import_export_type


class DistributionSystemImportFactory:
  """
  Exports factory class for roads?
  """
  def __init__(self, handler: str, city: City):
    """
    :param city: the city object
    :param handler: the handler object determine input file format
    """
    self._city = city
    self._handler = '_' + handler.lower()
    validate_import_export_type(DistributionSystemImportFactory, handler)

  def _osm(self):
    """
    import city roads from osm
    :return: none
    """
    return Osm(self._city).city

  def enrich(self):
    """
    Export the city given to the class using the given export type handler
    :return: None
    """
    _handlers = {
      '_osm': self._osm(),
    }
    return _handlers[self._handler]