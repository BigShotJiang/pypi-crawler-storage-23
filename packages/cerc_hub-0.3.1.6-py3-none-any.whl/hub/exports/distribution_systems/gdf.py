"""
Geo data frame exporter based in osm
SPDX-License-Identifier: LGPL-3.0-or-later
Copyright © 2026 Concordia CERC group
Code coder: Guille Gutierrez Morote guillermo.gutierrezmorote@concordia.ca
Code contributors: Bilal Khan khan.bilal@mail.concordia.ca
"""
import json
from pathlib import Path

import geopandas as gpd
import osmnx as ox
import pyproj
from pyproj import Transformer
from shapely.geometry import LineString

from hub.city_model_structure.city import City
from hub.helpers.dictionaries import Dictionaries
from hub.helpers.geometry_helper import GeometryHelper
import logging

class GDF:
  """
  Export to an osm file
  """

  def __init__(self, city: City, path: Path, filename: str | None):
    """
    :param city: the city object to export
    :param path: the path to export results
    :param filename: The base name of the output file, uses city name if None
    """
    self._city = city
    self._path = path
    self._srs_name = self._city.srs_name
    if  self._city.drive_graph.source_node is None:
      self._city.drive_graph.get_shortest_path_tree(self._city.drive_graph.source_node)
    self._filename = filename if filename else self._city.drive_graph.source_node


    self._export()

  def _transform(self, coordinates):
    gps = pyproj.CRS('EPSG:4326')  # LatLon with WGS84 datum used by GPS units and Google Earth
    try:
      if self._srs_name in GeometryHelper.srs_transformations:
        self._srs_name = GeometryHelper.srs_transformations[self._srs_name]
      input_reference = pyproj.CRS(self._srs_name)  # Projected coordinate system from input data
    except pyproj.exceptions.CRSError as err:
      logging.error('Invalid projection reference system, please check the input data.')
      raise pyproj.exceptions.CRSError from err
    transformer = Transformer.from_crs(input_reference, gps)
    return transformer.transform(coordinates[0], coordinates[1])

  def _export(self):
    """
    Export the city to an osm file
    :return: None
    """
    _buildings_connected = {
      "type": "FeatureCollection",
      "features": []
    }

    for building in self._city.buildings:
      _gps_center = self._transform((building.centroid[0], building.centroid[1]))
      _building_feature = {
        "type": "Feature",
        "properties": {
          "name": building.name,
          "nearest_node": building.nearest_node.name,
          "building": Dictionaries().hub_usage_to_osm_usage[building.function]
        },
        "geometry": {
          "type": "Point",
          "coordinates": [_gps_center[1], _gps_center[0]]
        }
      }
      _buildings_connected["features"].append(_building_feature)
    with open(self._path / f'{self._filename}_buildings_connected.geojson', 'w', encoding='utf-8') as f:
      json.dump(_buildings_connected, f, indent=2)
    nodes_gdf, edges_gdf = ox.graph_to_gdfs(self._city.drive_graph.osm_graph, nodes=True, edges=True)
    nodes_gdf.to_file(self._path / f'{self._filename}_nodes.geojson', driver='GeoJSON')
    edges_gdf.to_file(self._path / f'{self._filename}_streets.geojson', driver='GeoJSON')
    feeder_edge_set = set()
    building_nodes = set(int(building.nearest_node.name) for building in self._city.buildings)
    _sortest_tree = self._city.drive_graph.get_shortest_path_tree(self._city.drive_graph.source_node)
    for bn in building_nodes:
      path = _sortest_tree.get(bn)
      if not path:
        # building node not reachable from source
        continue
      for a, b in zip(path[:-1], path[1:]):
        feeder_edge_set.add((int(a), int(b)))

    feeder_records = []
    nodes_gdf.index = nodes_gdf.index.map(int)
    nodes_idx = set(nodes_gdf.index)
    for (u, v) in feeder_edge_set:
      if u in nodes_idx and v in nodes_idx:
        pu = nodes_gdf.loc[u].geometry
        pv = nodes_gdf.loc[v].geometry
        line = LineString([pu.coords[0], pv.coords[0]])
        feeder_records.append({'u': u, 'v': v, 'geometry': line})

    if feeder_records:
      feeder_gdf = gpd.GeoDataFrame(feeder_records, geometry='geometry', crs=nodes_gdf.crs)
      feeder_out = self._path / f'{self._filename}_feeder_edges.geojson'
      feeder_gdf.to_file(feeder_out, driver='GeoJSON')