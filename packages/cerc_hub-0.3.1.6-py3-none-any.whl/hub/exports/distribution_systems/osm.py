"""
Power Distribution System OSM exporter
SPDX-License-Identifier: LGPL-3.0-or-later
Copyright © 2026 Concordia CERC group
Code coder: Guille Gutierrez Morote guillermo.gutierrezmorote@concordia.ca
Code contributors: Bilal Khan khan.bilal@mail.concordia.ca
"""
import math
from pathlib import Path

import pyproj
import logging

from pyproj import Transformer

from hub.city_model_structure.city import City
from hub.helpers.geometry_helper import GeometryHelper
import osmnx as ox



class Osm:
  """
  Export to an osm file
  """

  def __init__(self, city: City, path: Path, filename: str | None):
    """
    :param city: the city object to export
    :param path: the path to export results
    :param filename: The base name of the output file, uses city name if None
    """
    self._city = city
    self._path = path
    self._filename = filename if filename else self._city.name
    self._output_file = Path(f'{self._path}/{self._filename}.osm').resolve()
    self._srs_name = city.srs_name

    self._export()

  def _export(self):
    """
    Export the city to an osm file
    :return: None
    """
    distance = abs(math.sqrt((self._city.lower_corner[0] - self._city.upper_corner[0])**2 + (self._city.lower_corner[1] - self._city.upper_corner[1])**2))
    x = self._city.upper_corner[0] + (self._city.lower_corner[0] - self._city.upper_corner[0]) / 2
    y = self._city.upper_corner[1] + (self._city.lower_corner[1] - self._city.upper_corner[1]) / 2
    center = self._transform((x,y))
    _graph = ox.graph_from_point(center_point=center, dist=distance, network_type='drive', simplify=False)
    ox.save_graphml(_graph, filepath=self._output_file, encoding='utf-8')

    return

  def _transform(self, coordinates):
    gps = pyproj.CRS('EPSG:4326')  # LatLon with WGS84 datum used by GPS units and Google Earth
    try:
      if self._srs_name in GeometryHelper.srs_transformations:
        self._srs_name = GeometryHelper.srs_transformations[self._srs_name]
      input_reference = pyproj.CRS(self._srs_name)  # Projected coordinate system from input data
    except pyproj.exceptions.CRSError as err:
      logging.error('Invalid projection reference system, please check the input data.')
      raise pyproj.exceptions.CRSError from err
    transformer = Transformer.from_crs(input_reference, gps)
    return transformer.transform(coordinates[0], coordinates[1])
