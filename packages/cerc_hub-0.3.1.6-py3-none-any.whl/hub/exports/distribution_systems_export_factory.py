"""
Distribution System exporter
SPDX-License-Identifier: LGPL-3.0-or-later
Copyright © 2026 Concordia CERC group
Code coder: Guille Gutierrez Morote guillermo.gutierrezmorote@concordia.ca
Code contributors: Bilal Khan khan.bilal@mail.concordia.ca
"""
from pathlib import Path

from hub.city_model_structure.city import City
from hub.exports.distribution_systems.osm import Osm
from hub.exports.distribution_systems.gdf import GDF
from hub.helpers.utils import validate_import_export_type


class DistributionSystemExportFactory:
  """
  Exports factory class for roads?
  """
  def __init__(self, handler: str, city: City, path: Path | str, filename: str | None = None):
    """
    :param city: the city object to export
    :param handler: the handler object determine output file format
    :param path: the path to export results
    :param filename: The base name of the output file, uses city name if None
    """
    self._city = city
    self._handler = '_' + handler.lower()
    validate_import_export_type(DistributionSystemExportFactory, handler)
    if isinstance(path, str):
      path = Path(path)
    self._path = path
    self._filename = filename

  def _osm(self):
    """
    Export city roads to osm file
    :return: none
    """
    return Osm(self._city, self._path, self._filename)

  def _geo_data_frame(self):
    """
    Export city current drive graph sortest path tree to geo data frame files
    :return: none
    """
    return GDF(self._city, self._path, self._filename)

  def export(self):
    """
    Export the city given to the class using the given export type handler
    :return: None
    """
    _handlers = {
      '_osm': self._osm(),
      '_geo_data_frame': self._geo_data_frame(),
    }
    return _handlers[self._handler]