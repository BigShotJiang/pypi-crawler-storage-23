import hub.exports.building_energy.idf_helper as idf_cte
from hub.exports.building_energy.idf_helper.idf_base import IdfBase


class IdfWindowsConstructions(IdfBase):
  @staticmethod
  def add(cerc_idf, thermal_boundary):
    name = f'{thermal_boundary.construction_id}_window'
    if name not in cerc_idf.windows_added_to_idf:
      return  # Material not added or already assigned to construction
    construction_id = f'{thermal_boundary.construction_id}_window_construction'
    if construction_id not in cerc_idf.constructions_added_to_idf:
      cerc_idf.constructions_added_to_idf[construction_id] = True
      file = cerc_idf.files['constructions']
      cerc_idf.write_to_idf_format(file, idf_cte.CONSTRUCTION)
      cerc_idf.write_to_idf_format(file, construction_id, 'Name')
      cerc_idf.write_to_idf_format(file, name, 'Outside Layer', ';')
