# myls 🗂️

A custom `ls`-like terminal tool built with Python.

## Install

```bash
pip install myls
```

## Usage

```bash
myls              # list current directory
myls /home        # list a specific path
```

## Sample Output

```
  Directory: /home/user/projects

  PERMS        SIZE   MODIFIED           NAME
  ───────────────────────────────────────────────────────
  drwxr-xr-x    4K  2024-03-01 10:22  src/
  -rw-r--r--    2K  2024-02-28 09:15  README.md
  -rwxr-xr-x    8K  2024-03-01 11:00  build*

  3 items
```

## License

MIT
