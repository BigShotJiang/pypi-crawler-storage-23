import os
import tempfile
from myls.main import format_size, format_permissions, list_directory
import stat


def test_format_size():
    assert format_size(500)    == " 500B"
    assert format_size(1024)   == "   1K"
    assert format_size(1024*1024) == "   1M"


def test_format_permissions():
    # Get permissions of this file itself
    mode = os.stat(__file__).st_mode
    result = format_permissions(mode)
    assert len(result) == 10        # e.g. -rw-r--r--
    assert result[0] in ("-", "d")


def test_list_directory(capsys):
    with tempfile.TemporaryDirectory() as tmp:
        # Create a test file inside temp dir
        open(os.path.join(tmp, "hello.txt"), "w").close()
        list_directory(tmp)
        captured = capsys.readouterr()
        assert "hello.txt" in captured.out
        assert "1 items" in captured.out
