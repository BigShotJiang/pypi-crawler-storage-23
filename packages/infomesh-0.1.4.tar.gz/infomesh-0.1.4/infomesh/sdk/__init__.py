"""InfoMesh Python SDK client.

Feature #21: Provides a pythonic client for the MCP tools,
usable as a library without needing MCP transport.
"""

from __future__ import annotations
