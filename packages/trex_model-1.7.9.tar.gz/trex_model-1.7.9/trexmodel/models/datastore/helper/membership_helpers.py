from datetime import datetime
import logging
from trexmodel.models.datastore.customer_models import CustomerTierMembership,\
    CustomerTierMembershipAccumulatedRewardSummary, Customer
from trexmodel.models.datastore.membership_models import MerchantTierMembership
from trexconf import program_conf
from trexmodel.models.datastore.model_decorators import model_transactional
from trexlib.utils.common.date_util import convert_date_to_datetime

logger = logging.getLogger("helpers")

def convert_transaction_reward_summary_to_accumulated_reward_summary(transaction_reward_summary):
    accumulated_reward_summary = {}
    for key, value in transaction_reward_summary.items():
        accumulated_reward_summary[key] = value.get('amount')
    return accumulated_reward_summary

def update_customer_tier_membership_from_adding_reward_summary(customer_acct, merchant_acct=None, transaction_details=None, entitled_datetime=None, reward_summary={}):
    
    if merchant_acct is None:
        merchant_acct = customer_acct.registered_merchant_acct
    
    logger.info('---update_customer_tier_membership_from_adding_reward_summary---')
    logger.info('reward_summary=%s, entitled_datetime=%s', reward_summary, entitled_datetime)
    logger.info(f'merchant_acct.is_tier_membership_configured={merchant_acct.is_tier_membership_configured}')
    if merchant_acct.is_tier_membership_configured:
        
        merchant_tier_membership_list                               = MerchantTierMembership.list_by_merchant_acct(merchant_acct)
        existing_tier_membership                                    = customer_acct.tier_membership_entity
        membership_to_assign                                        = None
        
        #highest_entitle_qualification_details                       = {}
        carry_over_amount                                           = 0 
        accumulated_summary                                         = reward_summary.copy() 
        existing_tier_index                                         = -1
        final_tier_index                                            = len(merchant_tier_membership_list)-1
        upgraded_tier_index                                         = -1 
        completed_tier_accumulated_reward_summary                   = {}
        reward_summary_key                                          = map_accumulated_amount_key_from_qualified_type(merchant_tier_membership_list[-1].entitle_qualification_type)
        
        customer_tier_membership_accumulated_reward_summary_list    = CustomerTierMembershipAccumulatedRewardSummary.list_by_customer(customer_acct)
        
        logger.info(f'>>>>>>>>>>>> accumulated_summary={accumulated_summary}')
        
        logger.info('customer_tier_membership_accumulated_reward_summary_list=%s', customer_tier_membership_accumulated_reward_summary_list)
        
        if existing_tier_membership:
            existing_tier_index = next((i for i, p in enumerate(merchant_tier_membership_list) if p.key_in_str == existing_tier_membership.key_in_str), -1)
        
            logger.info(f'existing_tier_membership={existing_tier_membership.label}, existing_tier_index={existing_tier_index}')
        
        if existing_tier_index+1==len(merchant_tier_membership_list):
            logger.info('already in the highest tier, thus continue update the accumulated reward summary')
            
            CustomerTierMembershipAccumulatedRewardSummary.add_accumulated_reward(customer_acct, 
                                                                            accumulated_summary         = reward_summary,
                                                                            merchant_tier_membership    = existing_tier_membership,
            
                                                                            )
            
        else:
            
            if existing_tier_membership:
                for i in range(-1, existing_tier_index+1):
                    tier_accumulated_reward_summary = next((p for p in customer_tier_membership_accumulated_reward_summary_list if p.tier_index == i), None)
                    
                    if tier_accumulated_reward_summary:
                        
                        for k,v in tier_accumulated_reward_summary.accumulated_summary.items():
                            logger.debug('Going to %s add %s', accumulated_summary.get(k,0), v)
                            accumulated_summary[k] = accumulated_summary.get(k,0) +v
                            logger.debug('end up=%s', accumulated_summary[k])
                        
                        if tier_accumulated_reward_summary.completed==True:
                            for k,v in tier_accumulated_reward_summary.accumulated_summary.items():
                                completed_tier_accumulated_reward_summary[k] = completed_tier_accumulated_reward_summary.get(k,0)+v
            else:
                tier_accumulated_reward_summary = next((p for p in customer_tier_membership_accumulated_reward_summary_list if p.tier_index == -1), None)
                
                if tier_accumulated_reward_summary:
                    for k,v in tier_accumulated_reward_summary.accumulated_summary.items():
                        accumulated_summary[k] = accumulated_summary.get(k,0)+v
                
            #logger.debug('existing_tier_index=%s', existing_tier_index)
            
            total_accumulated_point         = accumulated_summary.get('point',0)
            total_accumulated_stamp         = accumulated_summary.get('stamp',0) 
            total_accumulated_prepaid       = accumulated_summary.get('prepaid',0)
            
            if total_accumulated_point<0:
                total_accumulated_point = 0;
            
            if total_accumulated_stamp<0:
                total_accumulated_stamp = 0;
            
            if total_accumulated_prepaid<0:
                total_accumulated_prepaid = 0;        
            
            #logger.debug('total_transact_amount=%s', total_transact_amount)
            logger.info('total_accumulated_point=%s', total_accumulated_point)
            logger.info('total_accumulated_stamp=%s', total_accumulated_stamp)
            logger.info('total_accumulated_prepaid=%s', total_accumulated_prepaid)
                
            for i in range(existing_tier_index+1, len(merchant_tier_membership_list)):
                membership = merchant_tier_membership_list[i]
                
                if membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_AUTO_ASSIGN:
                    if membership_to_assign is None:
                        upgraded_tier_index = i
                        membership_to_assign = membership
                        
                        logger.info('Found auto assign tier membership')
                      
                elif membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_POINT_AMOUNT:
                    logger.debug('checking tier membership(%d-%s) is based on accumulated point amount, where amount is %s', i, membership.label, membership.entitle_qualification_value)
                    if total_accumulated_point >= membership.entitle_qualification_value:
                        upgraded_tier_index = i
                        membership_to_assign = membership
                        if total_accumulated_point-membership.entitle_qualification_value>0:
                            carry_over_amount       = total_accumulated_point - membership.entitle_qualification_value
                        
                        logger.info('Found %s tier membership to assign', membership.label)
                    else:
                        logger.info('Condition %s is not match and stop here', membership.label)  
                        
                        break
                        
                elif membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_STAMP_AMOUNT:
                    logger.debug('checking tier membership(%d-%s) is based on accumulated stamp amount, where amount is %s', i, membership.label, membership.entitle_qualification_value)
                    if total_accumulated_stamp >= membership.entitle_qualification_value:
                        upgraded_tier_index = i
                        membership_to_assign = membership
                        if total_accumulated_stamp-membership.entitle_qualification_value>0:
                            carry_over_amount       = total_accumulated_stamp - membership.entitle_qualification_value
                        
                         
                        logger.info('Found %s tier membership to assign', membership.label)
                    else:
                        logger.info('Condition %s is not match and stop here', membership.label)  
                        
                        break     
                        
                elif membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_PREPAID_AMOUNT:
                    logger.debug('checking tier membership(%d-%s) is based on accumulated prepaid amount, where amount is %s',i, membership.label,  membership.entitle_qualification_value)
                    if total_accumulated_prepaid >= membership.entitle_qualification_value:
                        upgraded_tier_index = i
                        membership_to_assign = membership
                        if total_accumulated_prepaid-membership.entitle_qualification_value>0:
                            carry_over_amount           = total_accumulated_prepaid - membership.entitle_qualification_value
                        
                        logger.info('Found %s tier membership to assign', membership.label)
                    else:
                        logger.info('Condition %s is not match and stop here', membership.label)        
                        break
                
            
            logger.info('existing_tier_index=%d, upgraded_tier_index=%d', existing_tier_index, upgraded_tier_index)
            
                
            if membership_to_assign:
                logger.info('found upgrading tier membership to assign')
                if existing_tier_index>=0:
                    upgraded_tier_level_count = upgraded_tier_index - existing_tier_index
                else:
                    upgraded_tier_level_count = upgraded_tier_index + 1  
                
                logger.info('upgraded_tier_level_count=%d', upgraded_tier_level_count)
                    
                
                
                if transaction_details:
                    entitled_datetime = transaction_details.transact_datetime
                
                if entitled_datetime is None:
                    entitled_datetime = datetime.utcnow()
                
                logger.info('membership_to_assign=%s, entitled_datetime=%s', membership_to_assign.label, entitled_datetime)
                
                if existing_tier_membership:
                    
                    logger.info('existing_tier_membership=%s', existing_tier_membership.label)
                    
                    
                    CustomerTierMembership.change(customer_acct,
                                              membership_to_assign, 
                                              transaction_details=transaction_details,
                                              entitled_datetime=entitled_datetime,
                                              )
                    
                    logger.debug('final_tier_index=%d', final_tier_index)
                    for i in range(existing_tier_index, upgraded_tier_index+1):
                        tier_membership = merchant_tier_membership_list[i]
                        logger.debug('%d) tier_membership (%s)', i, tier_membership.label)
                        if i<upgraded_tier_index:
                            accumulated_completed_tier_reward_amount = merchant_tier_membership_list[i+1].entitle_qualification_value - merchant_tier_membership_list[i].entitle_qualification_value
                            logger.debug('accumulated_completed_tier_reward_amount=%s', accumulated_completed_tier_reward_amount)
                                
                            _accumulated_summary = {
                                                reward_summary_key: accumulated_completed_tier_reward_amount
                                            }
                                
                            logger.debug('Going to define completed tier membership %s with accumulated reward=%s', tier_membership.label, _accumulated_summary)
                            CustomerTierMembershipAccumulatedRewardSummary.complete(customer_acct, 
                                                                    accumulated_summary         = _accumulated_summary,
                                                                    merchant_tier_membership    = tier_membership,
                                                                    tier_index                  = i,
                                                                    )
                        else:
                            
                            _accumulated_summary = {
                                                    reward_summary_key:carry_over_amount
                                                }
                            
                            #check is the tier is the last tier, and check the tier 
                            logger.debug('Going to define new tier membership %s with accumulated reward=%s', tier_membership.label, _accumulated_summary)
                            CustomerTierMembershipAccumulatedRewardSummary.create(customer_acct, 
                                                                created_date                = entitled_datetime.date(), 
                                                                accumulated_summary         = _accumulated_summary,
                                                                merchant_tier_membership    = tier_membership,
                                                                tier_index                  = i,
                                                                )
                        
                        #check_reward_for_new_membership(customer_acct, transaction_details, membership_to_assign)
                        
                        
                        
                        
                    
                else:
                    logger.info('found new tier membership to assign, upgraded_tier_level_count=%d', upgraded_tier_level_count)
                    
                    CustomerTierMembership.create(customer_acct, 
                                                  membership_to_assign, 
                                                  transaction_details         = transaction_details,
                                                  entitled_datetime           = entitled_datetime,
                                                  
                                                  )
                    
                    if upgraded_tier_level_count>0:
                        
                        for i in range(upgraded_tier_level_count):
                            tier_membership = merchant_tier_membership_list[i]
                            logger.info('%d) tier_membership (%s), entitle qualification type=%s, entitle qualification value=%s', i, tier_membership.label, tier_membership.entitle_qualification_type, tier_membership.entitle_qualification_value)
                            '''
                            if i==0:
                                
                                if tier_membership.entitle_qualification_type!=program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_AUTO_ASSIGN:
                                    _accumulated_summary = {
                                                        reward_summary_key: 0#tier_membership.entitle_qualification_value
                                                    }
                                    logger.debug('_accumulated_summary=%s', _accumulated_summary) 
                                    
                                CustomerTierMembershipAccumulatedRewardSummary.complete(customer_acct, 
                                                                    accumulated_summary         = _accumulated_summary,
                                                                    merchant_tier_membership    = tier_membership,
                                                                    tier_index                  = i,
                                                                    created_date                = entitled_datetime.date(),
                                                                    )
                            
                            
                            
                                    
                            '''    
                            if i<upgraded_tier_index:
                                accumulated_completed_tier_reward_amount = merchant_tier_membership_list[i+1].entitle_qualification_value - merchant_tier_membership_list[i].entitle_qualification_value
                                logger.debug('accumulated_completed_tier_reward_amount=%s', accumulated_completed_tier_reward_amount)
                                
                                _accumulated_summary = {
                                                        reward_summary_key: accumulated_completed_tier_reward_amount
                                                    }
                                '''
                                if tier_membership.entitle_qualification_type==program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_AUTO_ASSIGN:
                                    _accumulated_summary = {
                                                        reward_summary_key: 0#tier_membership.entitle_qualification_value
                                                    }
                                '''
                                logger.info('tier index=%d tier label=%s, tier completed reward summary=%s', i, tier_membership.label, _accumulated_summary)
                                
                                CustomerTierMembershipAccumulatedRewardSummary.complete(customer_acct, 
                                                                        accumulated_summary         = _accumulated_summary,
                                                                        merchant_tier_membership    = tier_membership,
                                                                        tier_index                  = i,
                                                                        created_date                = entitled_datetime.date(), 
                                                                        )
                            else:
                                accumulated_tier_reward_amount = accumulated_summary.get(reward_summary_key, 0) - merchant_tier_membership_list[i].entitle_qualification_value
                                if accumulated_tier_reward_amount<0:
                                    accumulated_tier_reward_amount = 0 
                                _accumulated_summary =    {
                                                            reward_summary_key: accumulated_tier_reward_amount
                                                            }
                                logger.info('tier index=%d tier label=%s, tier accumulated summary=%s', i, tier_membership.label, _accumulated_summary)
                                
                                CustomerTierMembershipAccumulatedRewardSummary.create(customer_acct, 
                                                                        created_date                = entitled_datetime.date(), 
                                                                        accumulated_summary         = _accumulated_summary,
                                                                        merchant_tier_membership    = tier_membership,
                                                                        tier_index                  = i,
                                                                        )
                                    
                    else:
                        CustomerTierMembershipAccumulatedRewardSummary.create(customer_acct, 
                                                                            created_date                = entitled_datetime.date(), 
                                                                            accumulated_summary         = accumulated_summary,
                                                                            merchant_tier_membership    = membership_to_assign,
                                                                            tier_index                  = upgraded_tier_index,
                                                                            )
                    #check_reward_for_new_membership(customer_acct, transaction_details, membership_to_assign)
                    
                    
            else:
                if existing_tier_membership:
                    logger.info('tier index=%d tier label=%s, tier accumulated summary=%s', existing_tier_index, existing_tier_membership.label, accumulated_summary)    
                    CustomerTierMembershipAccumulatedRewardSummary.add_accumulated_reward(customer_acct, 
                                                                        accumulated_summary         = reward_summary,
                                                                        merchant_tier_membership    = existing_tier_membership,
                                                                        )
                    
                    logger.debug('not tier membership to upgrade, thus remain as existing tier membership')
                else:
                    logger.info('no existing tier membership')
                    CustomerTierMembershipAccumulatedRewardSummary.add_accumulated_reward(customer_acct, 
                                                                        accumulated_summary         = reward_summary,
                                                                        entitled_datetime           = entitled_datetime,
                                                                        )
                    
    else:
        logger.debug('no tier membership is configured thus ignore')
        
def update_customer_tier_membership_from_reverting_reward_summary(
        customer_acct, 
        merchant_acct=None, 
        reward_summary={}, ):
    
    if merchant_acct is None:
        merchant_acct = customer_acct.registered_merchant_acct
    
    logger.debug('---update_customer_tier_membership_from_reverting_reward_summary---')
    if merchant_acct.is_tier_membership_configured:
        merchant_tier_membership_list                               = MerchantTierMembership.list_by_merchant_acct(merchant_acct)
        existing_tier_membership                                    = customer_acct.tier_membership_entity
        membership_to_assign                                        = None
        
        #highest_entitle_qualification_details                       = {}
        accumulated_summary                                         = {}
        existing_tier_index                                         = -1
        downgraded_tier_index                                       = 0
        completed_tier_accumulated_reward_summary                   = {}
        reward_summary_key                                          = map_accumulated_amount_key_from_qualified_type(merchant_tier_membership_list[-1].entitle_qualification_type)
        customer_tier_membership_accumulated_reward_summary_list    = CustomerTierMembershipAccumulatedRewardSummary.list_by_customer(customer_acct)
        
        if existing_tier_membership:
            existing_tier_index = next((i for i, p in enumerate(merchant_tier_membership_list) if p.key_in_str == existing_tier_membership.key_in_str), -1)
            
            for i in range(-1, existing_tier_index+1):
                tier_accumulated_reward_summary = next((p for p in customer_tier_membership_accumulated_reward_summary_list if p.tier_index == i), None)
                
                if tier_accumulated_reward_summary:
                    
                    for k,v in tier_accumulated_reward_summary.accumulated_summary.items():
                        accumulated_summary[k] = accumulated_summary.get(k,0)+v
                    
                    if tier_accumulated_reward_summary.completed==True:
                        for k,v in tier_accumulated_reward_summary.accumulated_summary.items():
                            completed_tier_accumulated_reward_summary[k] = completed_tier_accumulated_reward_summary.get(k,0)+v
            
            logger.debug('completed_tier_accumulated_reward_summary=%s', completed_tier_accumulated_reward_summary)
            
        else:
            tier_accumulated_reward_summary = next((p for p in customer_tier_membership_accumulated_reward_summary_list if p.tier_index == -1), None)
            
            if tier_accumulated_reward_summary:
                logger.debug('tier_accumulated_reward_summary=%s', tier_accumulated_reward_summary)
                for k,v in tier_accumulated_reward_summary.accumulated_summary.items():
                    accumulated_summary[k] = accumulated_summary.get(k,0)+v
            
            logger.debug('accumulated_summary=%s', accumulated_summary)
            
        logger.debug('Going to deduct reverted reward summary')
        
        for k,v in accumulated_summary.items():
            accumulated_summary[k] = accumulated_summary[k] - reward_summary.get(k, 0) 
        
        logger.debug('accumulated_summary=%s', accumulated_summary)    
        logger.debug('existing_tier_index=%s', existing_tier_index)
        
        total_accumulated_point         = accumulated_summary.get('point',0)
        total_accumulated_stamp         = accumulated_summary.get('stamp',0) 
        total_accumulated_prepaid       = accumulated_summary.get('prepaid',0)
        
        if total_accumulated_point<0:
            total_accumulated_point = 0;
        
        if total_accumulated_stamp<0:
            total_accumulated_stamp = 0;
        
        if total_accumulated_prepaid<0:
            total_accumulated_prepaid = 0;        
        
        #logger.debug('total_transact_amount=%s', total_transact_amount)
        logger.debug('total_accumulated_point=%s', total_accumulated_point)
        logger.debug('total_accumulated_stamp=%s', total_accumulated_stamp)
        logger.debug('total_accumulated_prepaid=%s', total_accumulated_prepaid)
        
        proceed_to_check_downgrade_tier = True
        
        if existing_tier_membership:
            logger.debug('Check whether existing tier membership condition is still achieved')
            
            if existing_tier_membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_AUTO_ASSIGN:
                proceed_to_check_downgrade_tier = False
                  
            elif existing_tier_membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_POINT_AMOUNT:
                logger.debug('checking tier membership(%s) is based on accumulated point amount, where amount is %s', existing_tier_membership.label, existing_tier_membership.entitle_qualification_value)
                if total_accumulated_point >= existing_tier_membership.entitle_qualification_value:
                    proceed_to_check_downgrade_tier = False
                    
            elif existing_tier_membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_STAMP_AMOUNT:
                logger.debug('checking tier membership(%s) is based on accumulated stamp amount, where amount is %s', existing_tier_membership.label, existing_tier_membership.entitle_qualification_value)
                if total_accumulated_stamp >= existing_tier_membership.entitle_qualification_value:
                    proceed_to_check_downgrade_tier = False
                    
            elif existing_tier_membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_PREPAID_AMOUNT:
                logger.debug('checking tier membership(%s) is based on accumulated prepaid amount, where amount is %s',existing_tier_membership.label,  existing_tier_membership.entitle_qualification_value)
                if total_accumulated_prepaid >= existing_tier_membership.entitle_qualification_value:
                    proceed_to_check_downgrade_tier = False
            
        logger.debug('proceed_to_check_downgrade_tier=%s', proceed_to_check_downgrade_tier)
            
        if proceed_to_check_downgrade_tier:
            downgraded_tier_index = -1
            
            for i in range(existing_tier_index-1, -1, -1):
                membership = merchant_tier_membership_list[i]
                
                if membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_AUTO_ASSIGN:
                    if membership_to_assign is None:
                        downgraded_tier_index = i
                        membership_to_assign = membership
                        logger.debug('Found auto assign tier membership')
                        break
                      
                elif membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_POINT_AMOUNT:
                    logger.debug('checking tier membership(%d-%s) is based on accumulated point amount, where amount is %s', i, membership.label, membership.entitle_qualification_value)
                    if total_accumulated_point >= membership.entitle_qualification_value:
                        downgraded_tier_index = i
                        membership_to_assign = membership
                        logger.debug('Found %s tier membership to assign', membership.label)
                        break
                        
                elif membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_STAMP_AMOUNT:
                    logger.debug('checking tier membership(%d-%s) is based on accumulated stamp amount, where amount is %s', i, membership.label, membership.entitle_qualification_value)
                    if total_accumulated_stamp >= membership.entitle_qualification_value:
                        downgraded_tier_index = i
                        membership_to_assign = membership
                        logger.debug('Found %s tier membership to assign', membership.label)
                        break     
                        
                elif membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_PREPAID_AMOUNT:
                    logger.debug('checking tier membership(%d-%s) is based on accumulated prepaid amount, where amount is %s',i, membership.label,  membership.entitle_qualification_value)
                    if total_accumulated_prepaid >= membership.entitle_qualification_value:
                        downgraded_tier_index = i
                        membership_to_assign = membership
                        logger.debug('Found %s tier membership to assign', membership.label)
                        break
            
            logger.debug('existing_tier_index=%d, downgraded_tier_index=%d', existing_tier_index, downgraded_tier_index)   
            
            if existing_tier_membership:
                
                logger.debug('existing_tier_membership=%s, membership_to_assign=%s', existing_tier_membership.label, membership_to_assign.label)
                entitle_qualification_type = existing_tier_membership.entitle_qualification_type
                if membership_to_assign:
                    CustomerTierMembership.change(customer_acct,
                                              membership_to_assign, 
                                              is_upgrade = False
                                              )
                    if membership_to_assign.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_AUTO_ASSIGN:
                        if entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_POINT_AMOUNT:
                            total_accumulated_amount = total_accumulated_point
                        elif entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_STAMP_AMOUNT:
                            total_accumulated_amount = total_accumulated_stamp
                        elif entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_PREPAID_AMOUNT:
                            total_accumulated_amount = total_accumulated_prepaid
                    else:
                        if entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_POINT_AMOUNT:
                            total_accumulated_amount = total_accumulated_point - membership_to_assign.entitle_qualification_value
                        elif entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_STAMP_AMOUNT:
                            total_accumulated_amount = total_accumulated_stamp - membership_to_assign.entitle_qualification_value
                        elif entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_PREPAID_AMOUNT:
                            total_accumulated_amount = total_accumulated_prepaid - membership_to_assign.entitle_qualification_value
                    
                    new_accumulated_summary = {
                            reward_summary_key : total_accumulated_amount
                        }
                    
                    CustomerTierMembershipAccumulatedRewardSummary.update(customer_acct, membership_to_assign, 
                                                        accumulated_summary         = new_accumulated_summary,
                                                        )   
                    for i in range(existing_tier_index, downgraded_tier_index, -1):
                        membership = merchant_tier_membership_list[i]
                        CustomerTierMembershipAccumulatedRewardSummary.delete_for_customer_by_tier_membership(customer_acct, membership)
                    
                else:
                    if entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_POINT_AMOUNT:
                        total_accumulated_amount = total_accumulated_point
                    elif entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_STAMP_AMOUNT:
                        total_accumulated_amount = total_accumulated_stamp
                    elif entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_PREPAID_AMOUNT:
                        total_accumulated_amount = total_accumulated_prepaid
                    
                    new_accumulated_summary = {
                            reward_summary_key : total_accumulated_amount
                        }
                    CustomerTierMembershipAccumulatedRewardSummary.update(customer_acct, None, 
                                                            accumulated_summary         = new_accumulated_summary,
                                                            )
                    
                    for i in range(existing_tier_index, -1, -1):
                        membership = merchant_tier_membership_list[i]
                        CustomerTierMembershipAccumulatedRewardSummary.delete_for_customer_by_tier_membership(customer_acct, membership)
                    
                    
            else:
                CustomerTierMembershipAccumulatedRewardSummary.deduct_accumulated_reward(customer_acct, None, accumulated_summary=reward_summary)    
        else:
            CustomerTierMembershipAccumulatedRewardSummary.deduct_accumulated_reward(customer_acct, existing_tier_membership, accumulated_summary=reward_summary)
                    
    else:
        logger.debug('no tier membership is configured thus ignore')        

def patch_tier_membership_dirty_data(customer_acct, customer_tier_membership):
    logger.info(f'--patch_tier_membership_dirty_data--, customer_tier_membership.is_expired={customer_tier_membership.is_expired}')
    if customer_tier_membership.is_expired:
        existing_tier_membership            = customer_acct.tier_membership_entity
        customer_tier_membership_accumulated_reward_summary= CustomerTierMembershipAccumulatedRewardSummary.get_by_customer_and_merchant_tier_membership(customer_acct, existing_tier_membership)
        if customer_tier_membership_accumulated_reward_summary is None:
            customer_tier_membership_accumulated_reward_summary = CustomerTierMembershipAccumulatedRewardSummary.get_by_customer(customer_acct)
            
            if customer_tier_membership_accumulated_reward_summary:
                accumulated_reward_summary_merchant_tier_membership = customer_tier_membership_accumulated_reward_summary.merchant_tier_membership_entity
                if accumulated_reward_summary_merchant_tier_membership:
                    if accumulated_reward_summary_merchant_tier_membership.key_in_str!=existing_tier_membership.key_in_str:
                        logger.info('The accumulate reward summary merchant tier membership is not same as customer merchant tier membership, thus check to choose one')
                        logger.info(f'customer_tier_membership_accumulated_reward_summary.is_expired={customer_tier_membership_accumulated_reward_summary.is_expired}')
                        if customer_tier_membership_accumulated_reward_summary.is_expired == False:
                            
                            existing_tier_membership =  accumulated_reward_summary_merchant_tier_membership
        
                            CustomerTierMembership.change(customer_acct, accumulated_reward_summary_merchant_tier_membership, entitled_datetime=convert_date_to_datetime(customer_tier_membership_accumulated_reward_summary.created_date))                    
    
@model_transactional(desc='assign_eligible_maintain_or_downgrade_tier_membership')
def assign_eligible_maintain_or_downgrade_tier_membership(customer_acct, merchant_acct=None, entitled_datetime=None):
    if merchant_acct is None:
        merchant_acct = customer_acct.registered_merchant_acct
    logger.info('---assign_eligible_maintain_or_downgrade_tier_membership---')
    accumulated_reward_amount           = 0    
    membership_to_assign                = None
    existing_tier_index                 = -1
    existing_tier_membership            = customer_acct.tier_membership_entity
    merchant_tier_membership_list       = []
    assign_tier_membership_index        = 0
    today                               = datetime.utcnow().date()
    #existing_accumulated_reward_summary = None
    
    
    if entitled_datetime is None:
        entitled_datetime = datetime.utcnow()
    
    if existing_tier_membership:
        logger.info(f'existing_tier_membership={existing_tier_membership.label}')
    else:
        logger.info('No existing tier membership')
    logger.info(f'merchant_acct.is_tier_membership_configured={merchant_acct.is_tier_membership_configured}')
    
    if merchant_acct.is_tier_membership_configured:
        merchant_tier_membership_list           = MerchantTierMembership.list_by_merchant_acct(merchant_acct)
        reward_summary_key                      = map_accumulated_amount_key_from_qualified_type(merchant_tier_membership_list[-1].entitle_qualification_type)
    
    if existing_tier_membership: 
        existing_tier_index                 = next((i for i, p in enumerate(merchant_tier_membership_list) if p.key_in_str == existing_tier_membership.key_in_str), -1)
        logger.info('Going to get accumulated reward amount by existing tier membership(%s), existing_tier_index=%d', existing_tier_membership.label, existing_tier_index)
        
        customer_tier_membership_accumulated_reward_summary= CustomerTierMembershipAccumulatedRewardSummary.get_by_customer_and_merchant_tier_membership(customer_acct, existing_tier_membership)
        if customer_tier_membership_accumulated_reward_summary:
            accumulated_reward_amount = customer_tier_membership_accumulated_reward_summary.accumulated_summary.get(reward_summary_key, 0)
    else:
        customer_tier_membership_accumulated_reward_summary= CustomerTierMembershipAccumulatedRewardSummary.get_by_customer_and_merchant_tier_membership(customer_acct, None)
        if customer_tier_membership_accumulated_reward_summary:
            accumulated_reward_amount = customer_tier_membership_accumulated_reward_summary.accumulated_summary.get(reward_summary_key, 0)
        
    
    logger.info(f'customer_tier_membership_accumulated_reward_summary={customer_tier_membership_accumulated_reward_summary}')    
    logger.info('accumulated_reward_amount=%s', accumulated_reward_amount)
     
    
    to_proceed = customer_tier_membership_accumulated_reward_summary.is_expired
    
    logger.info('to_proceed=%s', to_proceed)
    #for i in range(0, total_merchant_tier_membership_level):
    if to_proceed:
        logger.info('Going to check whether allow to maintain existing tier since the existing tier is expired')
        
        
        for i in range(0, existing_tier_index+1):
            membership = merchant_tier_membership_list[i]
            logger.info(f'{membership.label} allow to maintain qualification={membership.allow_tier_maintain}')
            if membership.allow_tier_maintain:
            
                if membership.maintain_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_AUTO_ASSIGN:
                    if membership_to_assign is None:
                        membership_to_assign = membership
                        assign_tier_membership_index = i
                        logger.info(f'Found {membership.label} auto assign tier membership')
                        
                      
                elif membership.maintain_qualification_type in (program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_POINT_AMOUNT, program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_STAMP_AMOUNT, program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_PREPAID_AMOUNT):
                    logger.debug('checking tier membership(%d-%s) is based on accumulated point amount, where amount is %s', i, membership.label, membership.entitle_qualification_value)
                    if accumulated_reward_amount >= membership.maintain_qualification_value:
                        membership_to_assign = membership
                        assign_tier_membership_index = i
                        logger.info('Found %s tier membership to assign', membership.label)
                    else:
                        logger.info(f'Condition {membership.label} is not match and stop here')        
                        break
                        
            else:
                
                if membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_AUTO_ASSIGN:
                    if membership_to_assign is None:
                        membership_to_assign = membership
                        assign_tier_membership_index = i
                        logger.info(f'Found {membership.label} auto assign tier membership')
                            
                
                    
        if membership_to_assign is None:
            logger.info('Going to check membership to assign based on entitle qualification')
            
            total_merchant_tier_membership_level    = len(merchant_tier_membership_list)
            
            if existing_tier_membership is not None:
            
                logger.info('Check accumulated point will be reseted after rolling_period')
                
                if existing_tier_membership.enable_rolling_period:
                    logger.info('The existing tier membership have enabled rolling period')
                    rolling_period_expiry_date = existing_tier_membership.calculate_rolling_period_expiry_date().date()
                    _accumulated_reward_amount = accumulated_reward_amount
                    if today>rolling_period_expiry_date:
                        _accumulated_reward_amount = 0
                        
                
                if _accumulated_reward_amount>0:
                    logger.info('Going to check entitled membership')    
                
                    
                    for i in range(0, total_merchant_tier_membership_level+1):
                        if membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_AUTO_ASSIGN:
                            if membership_to_assign is None:
                                membership_to_assign = membership
                                assign_tier_membership_index = i
                                logger.debug('Found auto assign tier membership')
                                
                              
                        elif membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_POINT_AMOUNT:
                            logger.debug('checking tier membership(%d-%s) is based on accumulated point amount, where amount is %s', i, membership.label, membership.entitle_qualification_value)
                            if accumulated_reward_amount >= membership.maintain_qualification_value:
                                membership_to_assign = membership
                                assign_tier_membership_index = i
                                logger.debug('Found %s tier membership to assign', membership.label)
                            else:
                                logger.debug('Condition is not match and stop here')        
                                break
                                
                                
                        elif membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_STAMP_AMOUNT:
                            logger.debug('checking tier membership(%d-%s) is based on accumulated stamp amount, where amount is %s', i, membership.label, membership.entitle_qualification_value)
                            if accumulated_reward_amount >= membership.maintain_qualification_value:
                                membership_to_assign = membership
                                assign_tier_membership_index = i
                                logger.debug('Found %s tier membership to assign', membership.label)
                            else:
                                logger.debug('Condition is not match and stop here')        
                                break         
                                
                        elif membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_ACCUMULATED_PREPAID_AMOUNT:
                            logger.debug('checking tier membership(%d-%s) is based on accumulated prepaid amount, where amount is %s',i, membership.label,  membership.entitle_qualification_value)
                            if accumulated_reward_amount >= membership.maintain_qualification_value:
                                membership_to_assign = membership
                                assign_tier_membership_index = i
                                logger.debug('Found %s tier membership to assign', membership.label)
                            else:
                                logger.debug('Condition is not match and stop here')        
                                break
                else:
                    for i in range(0, total_merchant_tier_membership_level+1):
                        if membership.entitle_qualification_type == program_conf.MEMBERSHIP_ENTITLE_QUALIFICATION_TYPE_AUTO_ASSIGN:
                            membership_to_assign = membership
                            assign_tier_membership_index = i
                            logger.debug('Found auto assign tier membership')
                            break
                    
        
        
    else:
        logger.info('Existing tier is not yet expired')
    
    
    if to_proceed:                        
        if membership_to_assign is not None:
            logger.info(f"membership_to_assign={membership_to_assign.label}, tier_index={assign_tier_membership_index}")
            
            if existing_tier_membership:
                logger.info('There is existing tier membership')
                downgraded_tier_level_count = existing_tier_index - assign_tier_membership_index
                
                logger.info(f'existing_tier_index={existing_tier_index}, downgraded_tier_level_count={downgraded_tier_level_count}')
                '''
                balance_after_maintain_tier_reward_amount = accumulated_reward_amount - membership_to_assign.maintain_qualification_value
                
                accumulated_summary = {
                                    reward_summary_key: balance_after_maintain_tier_reward_amount
                                    }
                CustomerTierMembershipAccumulatedRewardSummary.update(customer_acct, membership_to_assign, accumulated_summary)
                '''
                
                
                accumulated_summary = {
                                    reward_summary_key: 0
                                    }
                
                if downgraded_tier_level_count>0:
                    for i in range(existing_tier_index, downgraded_tier_level_count, -1):
                        tier_membership = merchant_tier_membership_list[i]
                        CustomerTierMembershipAccumulatedRewardSummary.delete_all_for_customer_by_tier_membership(customer_acct, tier_membership)
                        logger.info(f'After removed ({i}) tier membership={tier_membership.label}')
                    
                    CustomerTierMembershipAccumulatedRewardSummary.delete_all_for_customer_by_tier_membership(customer_acct, existing_tier_membership)
                    logger.info(f'After removed tier membership accumulated reward summary={existing_tier_membership.label}')
                    CustomerTierMembershipAccumulatedRewardSummary.delete_all_for_customer_by_tier_membership(customer_acct, membership_to_assign)
                    logger.info(f'After removed tier membership accumulated reward summary={membership_to_assign.label}')
                    CustomerTierMembershipAccumulatedRewardSummary.create(customer_acct, merchant_tier_membership=membership_to_assign, accumulated_summary=accumulated_summary)
                    logger.info(f'After created tier membership accumulated reward summary={membership_to_assign.label}')
                    
                
                else:
                    CustomerTierMembershipAccumulatedRewardSummary.delete_all_for_customer_by_tier_membership(customer_acct, existing_tier_membership)
                    logger.info(f'After removed tier membership accumulated reward summary={existing_tier_membership.label}')
                    CustomerTierMembershipAccumulatedRewardSummary.delete_all_for_customer_by_tier_membership(customer_acct, membership_to_assign)
                    logger.info(f'After removed tier membership accumulated reward summary={membership_to_assign.label}')
                    CustomerTierMembershipAccumulatedRewardSummary.create(customer_acct, merchant_tier_membership=membership_to_assign, accumulated_summary=accumulated_summary)
                    logger.info(f'After created tier membership accumulated reward summary={membership_to_assign.label}')
                    
                customer_tier_membership = CustomerTierMembership.change(customer_acct, membership_to_assign, is_upgrade=False, entitled_datetime=entitled_datetime)
                
                if customer_tier_membership:
                    logger.info(f'customer_tier_membership = {customer_tier_membership.merchant_tier_membership_entity.label}') 
                else:
                    logger.info('Cannot get customer tier membership')
                    
                return customer_tier_membership
                
            else:
                logger.debug('If there is tier to assign but there is no existing tier, which is not correct')
        else:
            if existing_tier_membership:
                logger.debug('Do not entitle any tier membership, thus going to remove customer tier membership')
                CustomerTierMembership.remove(customer_acct, existing_tier_membership)
            
            CustomerTierMembershipAccumulatedRewardSummary.delete_all_for_customer(customer_acct)
            
            logger.info('Going to create balance of tier membership accumulated reward summary ')
            
            _accumulated_summary = {
                                    map_accumulated_amount_key_from_qualified_type(merchant_tier_membership_list[-1].entitle_qualification_type)
                                    : accumulated_reward_amount
                                    }
            CustomerTierMembershipAccumulatedRewardSummary.create(customer_acct, 
                                                                    created_date                = entitled_datetime.date(), 
                                                                    accumulated_summary         = _accumulated_summary,
                                                                    )
            return None
                

def map_accumulated_amount_key_from_qualified_type(entitle_qualification_type):
    
    if 'acc_point'==entitle_qualification_type:
        return 'point'
    elif 'acc_stamp'==entitle_qualification_type:
        return 'stamp'
    elif 'acc_prepaid'==entitle_qualification_type:
        return 'prepaid'


