"""Portfolio reading and strategy management functions."""

from .._internal import _call_tool
from .types import PortfolioResponse, TerminateStrategyResult


def read_portfolio() -> PortfolioResponse:
    """Read the current portfolio balance and positions.

    Returns:
        PortfolioResponse containing:
        - strategy: Strategy-specific data with total/realized/unrealized PnL,
          current value, cost basis, and transactions
        - wallet: Wallet data with current balance, total/realized/unrealized PnL,
          current value, cost basis, and positions
    """
    result = _call_tool("read_portfolio", {})
    return PortfolioResponse.model_validate(result)


def terminate_strategy(should_liquidate: bool = False) -> TerminateStrategyResult:
    """Terminate the current strategy and optionally liquidate all positions.

    Args:
        should_liquidate: If True, sells all non-USDC positions back to USDC before terminating.
                         If False, terminates the strategy immediately without liquidation.

    Returns:
        TerminateStrategyResult containing:
        - success: Whether the termination was successful
        - liquidated_positions: List of LiquidatedPosition objects (if should_liquidate=True)
        - final_usdc_balance: Final USDC balance after liquidation

    Example:
        >>> # Terminate strategy without liquidation
        >>> result = terminate_strategy(should_liquidate=False)
        >>> print(result.success)
        True

        >>> # Terminate strategy with liquidation
        >>> result = terminate_strategy(should_liquidate=True)
        >>> print(result.liquidated_positions)
        [LiquidatedPosition(market_id="...", token_type="YES", amount=100, expected_proceeds=95.5)]
        >>> print(result.final_usdc_balance)
        1000.50
    """
    params = {
        "shouldLiquidate": should_liquidate,
    }
    result = _call_tool("terminate_strategy", params)
    return TerminateStrategyResult.model_validate(result)
