"""Sign and broadcast EVM transactions via the moonpay CLI (mp) for live-local trading.

No private keys are exposed — all key operations stay inside the mp CLI keychain.
"""

from __future__ import annotations

import base64
import json
import subprocess
from typing import Any


def sign_and_submit_tx(pending_tx: dict[str, Any], wallet_address: str) -> str:
    """Sign an unsigned EVM transaction with the moonpay CLI and broadcast it.

    Expects the API to return either:
    - ``raw_tx``: hex-encoded RLP-encoded unsigned transaction bytes, OR
    - ``raw_tx_b64``: base64-encoded RLP-encoded unsigned transaction bytes

    Flow:
        1. Encode tx bytes as base64 for ``mp transaction sign``
        2. ``mp transaction sign --wallet <addr> --chain polygon --transaction <b64>``
        3. ``mp transaction send --transaction <signedHex> --chain polygon``

    Args:
        pending_tx: Dict returned from the Dawn API. Must contain ``raw_tx`` or
                    ``raw_tx_b64`` plus ``tx_id`` for logging.
        wallet_address: The moonpay wallet address or name (from ``dawn wallet current``).

    Returns:
        Transaction hash string (0x...).

    Raises:
        ValueError: If the tx data is missing or the moonpay CLI returns unexpected output.
        subprocess.CalledProcessError: If the mp CLI exits with a non-zero code.
    """
    # Build base64 representation of the unsigned tx for mp CLI
    if "raw_tx_b64" in pending_tx:
        tx_b64 = pending_tx["raw_tx_b64"]
    elif "raw_tx" in pending_tx:
        raw_hex: str = pending_tx["raw_tx"]
        raw_bytes = bytes.fromhex(raw_hex.removeprefix("0x"))
        tx_b64 = base64.b64encode(raw_bytes).decode()
    else:
        raise ValueError(
            "pending_tx must contain 'raw_tx' (hex) or 'raw_tx_b64' (base64). "
            f"Got keys: {list(pending_tx.keys())}"
        )

    tx_id = pending_tx.get("tx_id", "")

    # Step 1: Sign with moonpay CLI
    sign_result = subprocess.run(  # noqa: S603
        [  # noqa: S607
            "mp",
            "--json",
            "transaction",
            "sign",
            "--wallet",
            wallet_address,
            "--chain",
            "polygon",
            "--transaction",
            tx_b64,
        ],
        capture_output=True,
        text=True,
        check=True,
    )

    try:
        signed_data: dict[str, Any] = json.loads(sign_result.stdout)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"mp transaction sign returned non-JSON: {sign_result.stdout[:300]}"
        ) from exc

    signed_tx: str | None = signed_data.get("signedTransaction") or signed_data.get("transaction")
    if not signed_tx:
        raise ValueError(
            "mp transaction sign: no 'signedTransaction' or 'transaction' key in output: "
            f"{sign_result.stdout[:300]}"
        )

    # Step 2: Broadcast with moonpay CLI
    send_result = subprocess.run(  # noqa: S603
        [  # noqa: S607
            "mp",
            "--json",
            "transaction",
            "send",
            "--transaction",
            signed_tx,
            "--chain",
            "polygon",
            "--message",
            f"Dawn strategy trade (txId={tx_id})",
        ],
        capture_output=True,
        text=True,
        check=True,
    )

    try:
        send_data: dict[str, Any] = json.loads(send_result.stdout)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"mp transaction send returned non-JSON: {send_result.stdout[:300]}"
        ) from exc

    tx_hash: str | None = send_data.get("transactionHash") or send_data.get("hash")
    if not tx_hash:
        raise ValueError(
            f"mp transaction send returned unexpected output (no transactionHash/hash key): "
            f"{send_result.stdout[:300]}"
        )

    return tx_hash
