"""Website data extraction with structured output."""

from typing import Any

from .._internal import _call_tool
from .types import ExtractStructuredDataResponse, ExtractTextResponse


def extract_text_from_urls(urls: list[str]) -> ExtractTextResponse:
    """Fetch plain text content from one or more URLs. May not be reliable for all websites.

    This is a simple text extraction tool that retrieves the main text content
    from web pages. For reliable, structured data extraction with schema validation,
    use extract_structured_data_from_url instead.

    Args:
        urls: List of URLs to fetch (1-10 URLs)
            Example: ["https://example.com", "https://example.org"]

    Returns:
        ExtractTextResponse containing:
            - success: Whether the fetch succeeded
            - contents: List of content objects with url, title, and text
            - error: Error message if fetch failed

    Examples:
        # Fetch text from a single URL
        result = extract_text_from_urls(["https://example.com"])
        if result.success:
            print(f"Title: {result.contents[0].title}")
            print(f"Text: {result.contents[0].text}")

        # Fetch text from multiple URLs
        result = extract_text_from_urls([
            "https://example.com",
            "https://example.org"
        ])
        for content in result.contents:
            print(f"{content.url}: {len(content.text)} characters")

    Note:
        This tool may not be reliable for all URLs. For complex extractions
        or structured data, use extract_structured_data_from_url instead.
    """
    result = _call_tool("extract_text_from_urls", {"urls": urls})
    return ExtractTextResponse(
        success=result.get("success", False),
        contents=result.get("contents", []),
        error=result.get("error"),
    )


def extract_structured_data_from_url(
    url: str,
    data_description: str,
    json_schema: dict[str, Any],
) -> ExtractStructuredDataResponse:
    """Extract structured data from websites using powerful visual browser automation.

    Args:
        url: The URL to extract data from (must be a valid HTTP/HTTPS URL)
        data_description: Natural language description of the data to extract
            Example: "The product name and price in USD"
        json_schema: JSON Schema object to structure the extracted data.
            The extracted data will conform to this schema.
            Example: {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "price": {"type": "number"}
                },
                "required": ["name", "price"]
            }

    Returns:
        ExtractStructuredDataResponse containing:
            - success: Whether the extraction succeeded
            - data: The extracted data (in format defined by json_schema)
            - error: Error message if extraction failed
            - url: The URL that was processed

    Examples:
        result = extract_structured_data_from_url(
            url="https://example.com/product",
            data_description="Product details: name, price, and whether it's in stock",
            json_schema={
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "price": {"type": "number"},
                    "in_stock": {"type": "boolean"}
                },
                "required": ["name", "price"]
            }
        )
        print(f"Product: {result.data['name']}, Price: ${result.data['price']}")
    """
    params: dict[str, Any] = {
        "url": url,
        "data_description": data_description,
    }

    if json_schema is not None:
        params["json_schema"] = json_schema

    result = _call_tool("extract_structured_data_from_url", params)
    return ExtractStructuredDataResponse(
        success=result.get("success", False),
        data=result.get("data"),
        error=result.get("error"),
        url=result.get("url", url),
    )
