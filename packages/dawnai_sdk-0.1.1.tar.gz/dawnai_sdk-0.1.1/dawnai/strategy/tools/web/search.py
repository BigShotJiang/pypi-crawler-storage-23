"""Web browser search functionality."""

from typing import Any

from .._internal import _call_tool
from .types import BrowserSearchResponse, BrowserSearchResult


def browser_search(
    query: str,
    limit: int = 10,
    category: str | None = None,
    start_published_date: str | None = None,
    end_published_date: str | None = None,
    include_domains: list[str] | None = None,
    exclude_domains: list[str] | None = None,
) -> BrowserSearchResponse:
    """Search the web for information.

    Args:
        query: Search query
        limit: Number of results to return (max 100)
        category: Optional category filter ('company', 'research paper', 'news',
                   'linkedin profile', 'github', 'tweet', 'personal site', 'pdf')
        start_published_date: Start date for filtering results (YYYY-MM-DD)
        end_published_date: End date for filtering results (YYYY-MM-DD)
        include_domains: List of domains to include
        exclude_domains: List of domains to exclude

    Returns:
        BrowserSearchResponse containing:
        - success: Boolean indicating if the search was successful
        - results: List of search results, each containing:
            - title: The title of the result
            - url: The URL of the result
            - published_date: (optional) The published date
        - error: (optional) Error message if the search failed
    """
    params: dict[str, Any] = {"query": query, "num_results": limit}
    if category:
        params["category"] = category
    if start_published_date:
        params["start_published_date"] = start_published_date
    if end_published_date:
        params["end_published_date"] = end_published_date
    if include_domains:
        params["include_domains"] = include_domains
    if exclude_domains:
        params["exclude_domains"] = exclude_domains

    result = _call_tool("browser_search", params)

    # API now returns snake_case
    results = [
        BrowserSearchResult(
            title=r.get("title"),
            url=r.get("url"),
            published_date=r.get("published_date"),
        )
        for r in result.get("results", [])
    ]

    return BrowserSearchResponse(
        success=result.get("success", False),
        results=results,
        error=result.get("error"),
    )
