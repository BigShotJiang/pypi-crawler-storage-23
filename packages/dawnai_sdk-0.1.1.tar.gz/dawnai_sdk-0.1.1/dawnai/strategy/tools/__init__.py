"""Tool functions for strategy development with strong typing.

This module provides access to all trading, data, and utility functions
for developing algorithmic trading strategies.
"""

# Configuration
from .config import configure

# Cryptocurrency functions
from .crypto.exchanges import get_exchange_symbols, get_exchanges
from .crypto.ohlcv import get_cryptocurrency_ohlcv
from .crypto.types import (
    CryptocurrencyExchange,
    CryptocurrencyOhlcv,
    CryptocurrencyOhlcvResponse,
    CryptocurrencySymbol,
    ExchangesResponse,
    ExchangeSymbolsResponse,
)
from .polymarket.data import (
    get_polymarket_order_book,
    get_polymarket_prices,
    get_polymarket_timeseries,
)
from .polymarket.markets import (
    get_polymarket_market_details,
    polymarket_event_markets,
    polymarket_event_search,
    polymarket_list_events,
)

# Polymarket functions
from .polymarket.trading import (
    polymarket_buy_token,
    polymarket_sell_token,
    polymarket_simulate_buy,
    polymarket_simulate_sell,
)

# Re-export all types for backward compatibility
from .polymarket.types import (
    BuyTokenResult,
    EventInfo,
    GetPolymarketPricesResponse,
    MarketPriceData,
    Order,
    OrderBookData,
    OrderBookResponse,
    OrderResult,
    PolymarketEvent,
    PolymarketEventMarketsResponse,
    PolymarketEventSearchResponse,
    PolymarketListEventsResponse,
    PolymarketMarket,
    SellTokenResult,
    SimulateTradeResult,
    Tag,
    TimeseriesPoint,
    TokenInfo,
)

# Portfolio functions
from .portfolio.management import read_portfolio, terminate_strategy
from .portfolio.types import (
    LiquidatedPosition,
    PortfolioResponse,
    StrategyData,
    StrategyTransaction,
    TerminateStrategyResult,
    WalletData,
    WalletPosition,
)

# Social media functions
from .social.twitter import get_tweet_info, get_user_tweets, search_tweets
from .social.types import (
    SearchTweetsResponse,
    Tweet,
    TweetInfoResponse,
    TwitterUser,
    UserTweetsResponse,
)

# Sports functions
from .sports.data import get_events, get_odds_as_probabilities, get_scores, get_sports
from .sports.types import (
    Bookmaker,
    Event,
    EventMetadata,
    GetEventsResponse,
    GetOddsAsProbabilitiesResponse,
    GetScoresResponse,
    GetSportsResponse,
    Market,
    OddsEvent,
    OddsMetadata,
    Outcome,
    Score,
    ScoreEvent,
    ScoresMetadata,
    Sport,
    SportMetadata,
)

# Utility functions
from .utils.agents import run_agent
from .utils.classify_text import classify_text
from .utils.state import get_state, set_state
from .utils.types import ClassifyTextResponse

# Web functions
from .web.extract import extract_structured_data_from_url, extract_text_from_urls
from .web.search import browser_search
from .web.types import (
    BrowserSearchResponse,
    BrowserSearchResult,
    ExtractStructuredDataResponse,
    ExtractTextContent,
    ExtractTextResponse,
)

__all__ = [
    "Bookmaker",
    "BrowserSearchResponse",
    "BrowserSearchResult",
    "BuyTokenResult",
    "ClassifyTextResponse",
    "CryptocurrencyExchange",
    "CryptocurrencyOhlcv",
    "CryptocurrencyOhlcvResponse",
    "CryptocurrencySymbol",
    "Event",
    "EventInfo",
    "EventMetadata",
    "ExchangeSymbolsResponse",
    "ExchangesResponse",
    "ExtractStructuredDataResponse",
    "ExtractTextContent",
    "ExtractTextResponse",
    "GetEventsResponse",
    "GetOddsAsProbabilitiesResponse",
    "GetPolymarketPricesResponse",
    "GetScoresResponse",
    "GetSportsResponse",
    "LiquidatedPosition",
    "Market",
    "MarketPriceData",
    "OddsEvent",
    "OddsMetadata",
    "Order",
    "OrderBookData",
    "OrderBookResponse",
    "OrderResult",
    "Outcome",
    "PolymarketEvent",
    "PolymarketEventMarketsResponse",
    "PolymarketEventSearchResponse",
    "PolymarketListEventsResponse",
    "PolymarketMarket",
    "PortfolioResponse",
    "Score",
    "ScoreEvent",
    "ScoresMetadata",
    "SearchTweetsResponse",
    "SellTokenResult",
    "SimulateTradeResult",
    "Sport",
    "SportMetadata",
    "StrategyData",
    "StrategyTransaction",
    "Tag",
    "TerminateStrategyResult",
    "TimeseriesPoint",
    "TokenInfo",
    "Tweet",
    "TweetInfoResponse",
    "TwitterUser",
    "UserTweetsResponse",
    "WalletData",
    "WalletPosition",
    "browser_search",
    "classify_text",
    "configure",
    "extract_structured_data_from_url",
    "extract_text_from_urls",
    "get_cryptocurrency_ohlcv",
    "get_events",
    "get_exchange_symbols",
    "get_exchanges",
    "get_odds_as_probabilities",
    "get_polymarket_market_details",
    "get_polymarket_order_book",
    "get_polymarket_prices",
    "get_polymarket_timeseries",
    "get_scores",
    "get_sports",
    "get_state",
    "get_tweet_info",
    "get_user_tweets",
    "polymarket_buy_token",
    "polymarket_event_markets",
    "polymarket_event_search",
    "polymarket_list_events",
    "polymarket_sell_token",
    "polymarket_simulate_buy",
    "polymarket_simulate_sell",
    "read_portfolio",
    "run_agent",
    "search_tweets",
    "set_state",
    "terminate_strategy",
]
