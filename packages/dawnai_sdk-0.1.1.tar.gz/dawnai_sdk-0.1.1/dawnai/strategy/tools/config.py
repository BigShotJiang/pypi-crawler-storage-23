"""Configuration management for the SDK."""

from ...config import configure as update_config


def configure(base_url: str | None = None, api_key: str | None = None) -> None:
    """Configure the SDK with API endpoints.

    Args:
        base_url: API base URL (optional, can be set via env or config file)
        api_key: API key (optional, can be set via env or config file)
    """
    kwargs = {}
    if base_url is not None:
        kwargs["base_url"] = base_url
    if api_key is not None:
        kwargs["api_key"] = api_key

    if kwargs:
        update_config(**kwargs)
