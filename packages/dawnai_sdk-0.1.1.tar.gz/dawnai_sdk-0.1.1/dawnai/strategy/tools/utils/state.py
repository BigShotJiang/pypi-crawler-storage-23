"""State management utilities for strategies."""

from typing import Any

from .._internal import _call_tool


def get_state(key: str) -> Any:
    """Get a value from the strategy state.

    Args:
        key: The key to retrieve

    Returns:
        The stored value, or None if the key doesn't exist

    Example:
        >>> position_size = get_state("position_size")
        >>> if position_size is None:
        ...     position_size = 0
    """
    result = _call_tool("get_state", {"key": key})
    return result.get("value") if result.get("found") else None


def set_state(key: str, value: Any) -> None:
    """Set a value in the strategy state.

    Args:
        key: The key to store
        value: The value to store (must be JSON serializable)

    Example:
        >>> set_state("position_size", 100)
        >>> set_state("last_trade_time", datetime.now().isoformat())
    """
    _call_tool("set_state", {"key": key, "value": value})
