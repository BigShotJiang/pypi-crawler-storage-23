"""Polymarket market search and event management functions."""

from __future__ import annotations

from typing import Any, Literal

from .._internal import _call_tool
from .types import (
    EventInfo,
    PolymarketEvent,
    PolymarketEventMarketsResponse,
    PolymarketEventSearchResponse,
    PolymarketListEventsResponse,
    PolymarketMarket,
    Tag,
)


def polymarket_event_search(
    query: str,
    limit: int = 10,
    events_status: str = "active",
    sort: str | None = None,
    ascending: bool = False,
    page: int = 1,
) -> PolymarketEventSearchResponse:
    """Search for Polymarket events and tags.

    Args:
        query: Search query for finding Polymarket events and tags
        limit: Maximum number of events to return (default: 10)
        events_status: Status filter for events ('active' or 'resolved', default: 'active')
        sort: Sort order for resulting events ('volume_24hr', 'volume', 'liquidity',
            'start_date', 'end_date')
        ascending: Sort in ascending order (default: False for descending if sort is specified)
        page: Page number for pagination (default: 1)

    Returns:
        PolymarketEventSearchResponse containing matching events with their associated tags,
        plus a top-level tags array of all matching tags. By default, returns active events.
    """
    params = {
        "query": query,
        "limit": int(limit) if isinstance(limit, str) else limit,
        "events_status": events_status,
        "page": int(page) if isinstance(page, str) else page,
    }

    # Only include sort and ascending parameters if specified
    if sort is not None:
        params["sort"] = sort
        params["ascending"] = ascending
    result = _call_tool("polymarket_event_search", params)

    # Parse events as PolymarketEvent models for validation
    events_data = result.get("events", [])
    validated_events: list[PolymarketEvent] = []
    for event_data in events_data:
        if isinstance(event_data, dict):
            event = PolymarketEvent(**event_data)
            validated_events.append(event)

    # Parse tags
    tags_data = result.get("tags", [])
    validated_tags: list[Tag] = []
    for tag_data in tags_data:
        if isinstance(tag_data, dict):
            tag = Tag(**tag_data)
            validated_tags.append(tag)

    return PolymarketEventSearchResponse(
        events=validated_events,
        tags=validated_tags,
        count=result.get("count", 0),
        error=result.get("error"),
    )


def polymarket_event_markets(
    event_id: int,
    limit: int = 10,
    offset: int = 0,
    order: Literal["volume24hr", "volume", "liquidity", "startDate", "endDate"] | None = None,
    ascending: bool = False,
    active: bool | None = None,
    closed: bool | None = None,
) -> PolymarketEventMarketsResponse:
    """Get markets for a specific Polymarket event with pagination and filtering options.

    Args:
        event_id: The ID of the event to get markets for
        limit: Maximum number of markets to return (default: 10)
        offset: Number of markets to skip for pagination (default: 0)
        order: Sort markets by 'volume24hr', 'volume', 'liquidity', 'startDate', or 'endDate'
        ascending: Sort in ascending order (default: False for descending)
        active: Filter for active markets only
        closed: Filter for closed markets only

    Returns:
        PolymarketEventMarketsResponse containing:
        - markets: List of market information for the event
        - count: Number of markets returned in this page
        - total_markets: Total number of markets for this event (after filtering)
        - event_info: Information about the event (id, title, description, slug)
        - error: Optional error message if the request failed

    Example:
        >>> result = polymarket_event_markets(12345, limit=5, active=True)
        >>> print(f"Event: {result.event_info.title}")
        >>> print(f"Found {result.total_markets} active markets")
        >>> for market in result.markets:
        ...     print(f"Market: {market.question}")
    """
    params: dict[str, Any] = {
        "event_id": event_id,
        "limit": limit,
        "offset": offset,
        "ascending": ascending,
    }

    if order is not None:
        params["order"] = order
    if active is not None:
        params["active"] = active
    if closed is not None:
        params["closed"] = closed

    result = _call_tool("polymarket_event_markets", params)

    if not isinstance(result, dict):
        return PolymarketEventMarketsResponse(
            markets=[],
            count=0,
            total_markets=0,
            event_info=EventInfo(id=str(event_id), title="", slug=""),
            error="Invalid response format",
        )

    # Parse markets data
    markets_data = result.get("markets", [])
    validated_markets: list[PolymarketMarket] = []
    for market_data in markets_data:
        if isinstance(market_data, dict):
            market = PolymarketMarket(**market_data)
            validated_markets.append(market)

    # Parse event info
    event_info_data = result.get("event_info", {"id": str(event_id), "title": "", "slug": ""})
    event_info = EventInfo(**event_info_data)

    return PolymarketEventMarketsResponse(
        markets=validated_markets,
        count=result.get("count", 0),
        total_markets=result.get("total_markets", 0),
        event_info=event_info,
        error=result.get("error"),
    )


def polymarket_list_events(
    limit: int = 10,
    offset: int = 0,
    order: str | None = None,
    ascending: bool = False,
    id: list[int] | None = None,
    slug: list[str] | None = None,
    tag_id: int | None = None,
    exclude_tag_id: list[int] | None = None,
    related_tags: bool | None = None,
    featured: bool | None = None,
    cyom: bool | None = None,
    include_chat: bool | None = None,
    include_template: bool | None = None,
    recurrence: str | None = None,
    closed: bool | None = None,
    start_date_min: str | None = None,
    start_date_max: str | None = None,
    end_date_min: str | None = None,
    end_date_max: str | None = None,
) -> PolymarketListEventsResponse:
    """List Polymarket events with advanced filtering and sorting options.

    Args:
        limit: Maximum number of events to return (default: 10)
        offset: Number of events to skip for pagination (default: 0)
        order: Comma-separated fields to sort by (e.g., "volume", "volume_24hr", "liquidity",
            "start_date", "end_date"). Both snake_case and camelCase are supported.
        ascending: Sort in ascending order (default: False for descending)
        id: Filter by event IDs (array of numbers)
        slug: Filter by event slugs (array of strings)
        tag_id: Filter by tag ID
        exclude_tag_id: Exclude events with these tag IDs (array of numbers)
        related_tags: Include related tags in response
        featured: Filter for featured events only
        cyom: Filter for Create Your Own Market events
        include_chat: Include chat information
        include_template: Include template information
        recurrence: Filter by recurrence type
        closed: Filter for closed events
        start_date_min: Minimum start date (ISO date-time)
        start_date_max: Maximum start date (ISO date-time)
        end_date_min: Minimum end date (ISO date-time)
        end_date_max: Maximum end date (ISO date-time)

    Returns:
        PolymarketListEventsResponse containing matching events.
        Returns simplified event metadata including marketCount but not nested market details.
    """
    params: dict[str, Any] = {
        "limit": int(limit) if isinstance(limit, str) else limit,
        "offset": int(offset) if isinstance(offset, str) else offset,
        "ascending": ascending,
    }

    # Only include optional parameters if specified
    if order is not None:
        params["order"] = order
    if id is not None:
        params["id"] = id
    if slug is not None:
        params["slug"] = slug
    if tag_id is not None:
        params["tag_id"] = tag_id
    if exclude_tag_id is not None:
        params["exclude_tag_id"] = exclude_tag_id
    if related_tags is not None:
        params["related_tags"] = related_tags
    if featured is not None:
        params["featured"] = featured
    if cyom is not None:
        params["cyom"] = cyom
    if include_chat is not None:
        params["include_chat"] = include_chat
    if include_template is not None:
        params["include_template"] = include_template
    if recurrence is not None:
        params["recurrence"] = recurrence
    if closed is not None:
        params["closed"] = closed
    if start_date_min is not None:
        params["start_date_min"] = start_date_min
    if start_date_max is not None:
        params["start_date_max"] = start_date_max
    if end_date_min is not None:
        params["end_date_min"] = end_date_min
    if end_date_max is not None:
        params["end_date_max"] = end_date_max

    result = _call_tool("polymarket_list_events", params)

    # Parse events as PolymarketEvent models for validation,
    # then convert back to dicts for JSON serializability
    events_data = result.get("events", [])
    validated_events: list[PolymarketEvent] = []
    for event_data in events_data:
        if isinstance(event_data, dict):
            event = PolymarketEvent(**event_data)
            validated_events.append(event)

    return PolymarketListEventsResponse(
        events=validated_events,
        count=result.get("count", 0),
        error=result.get("error"),
    )


def get_polymarket_market_details(market_id: str) -> PolymarketMarket | None:
    """Get detailed information about a Polymarket market and its tokens.

    Args:
        market_id: Market ID to get details for (e.g. "123456")

    Returns:
        PolymarketMarket object containing market details and tokens or None if not found

    Example:
        >>> market_details = get_polymarket_market_details("123456")
        >>> print(market_details.question)
        >>> print(market_details.tokens)
    """
    result = _call_tool("get_polymarket_market_details", {"market_id": market_id})

    if not result:
        return None

    return PolymarketMarket(**result)
