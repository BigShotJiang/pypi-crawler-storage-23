"""Polymarket trading functions for buying and selling tokens."""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from ....config import get_config
from .._internal import _call_tool, _call_tool_local
from .._local_wallet import sign_and_submit_tx
from .types import BuyTokenResult, Order, OrderResult, SellTokenResult, SimulateTradeResult


def _call_trade_tool(tool_name: str, params: dict[str, Any]) -> Any:
    """Execute a trade via /execute-local using the user's login JWT.

    Trade tools always require a strategy context — they are never sandboxed.
    DAWNAI_STRATEGY_ID must be set, either by:
      - `dawn run strategy.py --name <name> [--live]`
      - `dawn sdk tool <tool_name> --input <json>`  (wallet must be configured)
    """
    config = get_config()
    if not config.strategy_id:
        raise ValueError(
            f"'{tool_name}' requires a strategy context.\n"
            "Launch via: dawn run strategy.py --name <name> [--live]\n"
            "Or for direct calls: dawn sdk tool polymarket_buy_token --input <json>\n"
            "(Requires a wallet: dawn wallet use <address>)"
        )
    return _call_tool_local(
        tool_name,
        params,
        strategy_id=config.strategy_id,
        local_eoa_address=config.local_wallet_address or None,
    )


def _handle_pending_tx(result: dict[str, Any]) -> OrderResult | None:
    """If the API returned a pending_tx, sign and broadcast via moonpay CLI.

    Returns a completed OrderResult if the tx was signed and submitted,
    or None if there is no pending_tx (paper/simulation result).
    """
    pending_tx = result.get("pending_tx")
    if not pending_tx:
        return None

    config = get_config()
    wallet_address = config.local_wallet_address
    if not wallet_address:
        raise ValueError(
            "DAWN_LOCAL_WALLET_ADDRESS is required for live-local trading. "
            "Set it via environment variable or run `dawn wallet use <address>`."
        )

    tx_hash = sign_and_submit_tx(pending_tx, wallet_address)
    result_data = result.get("result") or {}

    return OrderResult(
        success=True,
        order_id=pending_tx.get("tx_id", ""),
        transaction_hash=tx_hash,
        executed_price=Decimal(result_data.get("executed_price", "0")),
        executed_amount=Decimal(result_data.get("executed_amount", "0")),
    )


def polymarket_buy_token(
    token_id: str,
    amount: Decimal,
) -> BuyTokenResult:
    """Execute a real buy trade for specific Polymarket tokens by token ID.

    This will spend real USDC to purchase tokens on Polymarket.

    In live-local mode (DAWN_LOCAL_WALLET_ADDRESS set), the API returns an unsigned
    transaction which is signed by the moonpay CLI and submitted to Polygon.

    Args:
        token_id: The specific token ID to buy
        amount: How much should be traded in USDC (as Decimal). Must be at least $1.

    Returns:
        BuyTokenResult containing:
        - result: Order execution result with success, order_id, transaction_hash,
                 executed_price, executed_amount
        - error: Optional error message if trade failed
    """
    params = {
        "token_id": token_id,
        "amount": str(amount),  # Convert Decimal to string for API
    }

    result = _call_trade_tool("polymarket_buy_token", params)

    if not isinstance(result, dict):
        return BuyTokenResult(
            result=OrderResult(
                success=False,
                order_id="",
                transaction_hash=None,
                executed_price=Decimal(0),
                executed_amount=Decimal(0),
            ),
            error="Unexpected tool response type",
        )

    # Live-local: API returned unsigned tx — sign and submit via moonpay CLI
    signed_order = _handle_pending_tx(result)
    if signed_order is not None:
        return BuyTokenResult(result=signed_order)

    result_data = result.get("result") or {}
    error = result.get("error")

    order_result = OrderResult(
        success=result_data.get("success", False),
        order_id=result_data.get("order_id", ""),
        transaction_hash=result_data.get("transaction_hash", None),
        executed_price=Decimal(result_data.get("executed_price", "0")),
        executed_amount=Decimal(result_data.get("executed_amount", "0")),
    )

    return BuyTokenResult(result=order_result, error=error)


def polymarket_sell_token(
    token_id: str,
    amount: Decimal,
) -> SellTokenResult:
    """Execute a real sell trade for specific Polymarket tokens by token ID.

    This will sell real tokens on Polymarket for USDC.

    In live-local mode (DAWN_LOCAL_WALLET_ADDRESS set), the API returns an unsigned
    transaction which is signed by the moonpay CLI and submitted to Polygon.

    Args:
        token_id: The specific token ID to sell
        amount: How many tokens to sell (as Decimal)

    Returns:
        SellTokenResult containing:
        - result: Order execution result with success, order_id, transaction_hash,
                 executed_price, executed_amount
        - error: Optional error message if trade failed
    """
    params = {
        "token_id": token_id,
        "amount": str(amount),  # Convert Decimal to string for API
    }

    result = _call_trade_tool("polymarket_sell_token", params)

    if not isinstance(result, dict):
        return SellTokenResult(
            result=OrderResult(
                success=False,
                order_id="",
                transaction_hash=None,
                executed_price=Decimal(0),
                executed_amount=Decimal(0),
            ),
            error="Unexpected tool response type",
        )

    # Live-local: API returned unsigned tx — sign and submit via moonpay CLI
    signed_order = _handle_pending_tx(result)
    if signed_order is not None:
        return SellTokenResult(result=signed_order)

    result_data = result.get("result") or {}
    error = result.get("error")

    order_result = OrderResult(
        success=result_data.get("success", False),
        order_id=result_data.get("order_id", ""),
        transaction_hash=result_data.get("transaction_hash", None),
        executed_price=Decimal(result_data.get("executed_price", "0")),
        executed_amount=Decimal(result_data.get("executed_amount", "0")),
    )

    return SellTokenResult(result=order_result, error=error)


def polymarket_simulate_buy(
    token_id: str,
    usd_amount: Decimal,
) -> SimulateTradeResult:
    """Simulate buying Polymarket tokens without executing the trade.

    Use this to preview order book consumption, slippage, and price impact
    before committing real funds to a buy order.

    Args:
        token_id: The specific token ID to simulate buying
        usd_amount: Amount of USDC to spend on this purchase (as Decimal)

    Returns:
        SimulateTradeResult containing:
        - average_price: Weighted average execution price per token
        - tokens_traded: Number of tokens you would receive
        - usd_amount: Total USD spent (should match input)
        - market_price_after: Next ask price after your buy order
        - consumed_orders: List of ask orders that would be consumed
        - price_impact_percent: Price impact as percentage
        - error: Optional error message if simulation failed

    Example:
        >>> result = polymarket_simulate_buy("0x123...", Decimal("100"))
        >>> print(f"You'll get {result.tokens_traded} tokens")
        >>> print(f"Avg price: ${result.average_price}")
        >>> print(f"Market moves to: ${result.market_price_after}")
        >>> print(f"Price impact: {result.price_impact_percent}%")
    """
    params = {
        "token_id": token_id,
        "usd_amount": str(usd_amount),  # Convert Decimal to string for API
    }

    result = _call_tool("polymarket_simulate_buy", params)

    if not isinstance(result, dict):
        return SimulateTradeResult(
            average_price=Decimal(0),
            tokens_traded=Decimal(0),
            usd_amount=Decimal(0),
            market_price_after=None,
            consumed_orders=[],
            price_impact_percent=None,
            error="Unexpected tool response type",
        )

    error = result.get("error")

    # Parse consumed orders (asks for buy orders)
    consumed_list = result.get("consumed_asks", [])
    consumed_orders = [
        Order(
            price=Decimal(order_data.get("price", "0")),
            size=Decimal(order_data.get("size", "0")),
        )
        for order_data in consumed_list
        if isinstance(order_data, dict)
    ]

    return SimulateTradeResult(
        average_price=Decimal(result.get("average_price", "0")),
        tokens_traded=Decimal(result.get("tokens_bought", "0")),
        usd_amount=Decimal(result.get("usd_amount", "0")),
        market_price_after=(
            Decimal(result["market_price_after"])
            if result.get("market_price_after") is not None
            else None
        ),
        consumed_orders=consumed_orders,
        price_impact_percent=(
            Decimal(result["price_impact_percent"])
            if result.get("price_impact_percent") is not None
            else None
        ),
        error=error,
    )


def polymarket_simulate_sell(
    token_id: str,
    token_amount: Decimal,
) -> SimulateTradeResult:
    """Simulate selling Polymarket tokens without executing the trade.

    Use this to preview order book consumption, slippage, and price impact
    before committing to a sell order.

    Args:
        token_id: The specific token ID to simulate selling
        token_amount: Number of tokens to sell (as Decimal, NOT USD amount)

    Returns:
        SimulateTradeResult containing:
        - average_price: Weighted average execution price per token
        - tokens_traded: Number of tokens you would sell (should match input)
        - usd_amount: Total USD you would receive
        - market_price_after: Next bid price after your sell order
        - consumed_orders: List of bid orders that would be consumed
        - price_impact_percent: Price impact as percentage
        - error: Optional error message if simulation failed

    Example:
        >>> result = polymarket_simulate_sell("0x123...", Decimal("100"))
        >>> print(f"You'll get ${result.usd_amount} USDC")
        >>> print(f"Avg price: ${result.average_price}")
        >>> print(f"Market moves to: ${result.market_price_after}")
        >>> print(f"Price impact: {result.price_impact_percent}%")
    """
    params = {
        "token_id": token_id,
        "token_amount": str(token_amount),  # Convert Decimal to string for API
    }

    result = _call_tool("polymarket_simulate_sell", params)

    if not isinstance(result, dict):
        return SimulateTradeResult(
            average_price=Decimal(0),
            tokens_traded=Decimal(0),
            usd_amount=Decimal(0),
            market_price_after=None,
            consumed_orders=[],
            price_impact_percent=None,
            error="Unexpected tool response type",
        )

    error = result.get("error")

    # Parse consumed orders (bids for sell orders)
    consumed_list = result.get("consumed_bids", [])
    consumed_orders = [
        Order(
            price=Decimal(order_data.get("price", "0")),
            size=Decimal(order_data.get("size", "0")),
        )
        for order_data in consumed_list
        if isinstance(order_data, dict)
    ]

    return SimulateTradeResult(
        average_price=Decimal(result.get("average_price", "0")),
        tokens_traded=Decimal(result.get("tokens_sold", "0")),
        usd_amount=Decimal(result.get("usd_received", "0")),
        market_price_after=(
            Decimal(result["market_price_after"])
            if result.get("market_price_after") is not None
            else None
        ),
        consumed_orders=consumed_orders,
        price_impact_percent=(
            Decimal(result["price_impact_percent"])
            if result.get("price_impact_percent") is not None
            else None
        ),
        error=error,
    )
