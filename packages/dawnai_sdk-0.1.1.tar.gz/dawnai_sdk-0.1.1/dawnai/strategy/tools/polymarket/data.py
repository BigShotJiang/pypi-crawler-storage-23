"""Polymarket data functions for prices, order books, and timeseries."""

from __future__ import annotations

from decimal import Decimal
from typing import Literal

from .._internal import _call_tool
from .types import (
    GetPolymarketPricesResponse,
    MarketPriceData,
    Order,
    OrderBookData,
    OrderBookResponse,
    TimeseriesPoint,
)


def get_polymarket_prices(market_id: str) -> GetPolymarketPricesResponse:
    """Get current prices for all tokens in a Polymarket market.

    Args:
        market_id: Polymarket market ID (must be a numeric string)

    Returns:
        GetPolymarketPricesResponse containing:
        - prices: Dictionary mapping token IDs to MarketPriceData (BUY/SELL prices).
                The BUY price is the best bid price and the SELL price is the best ask price.
          Note: This dictionary will be empty if the market has closed.
        - error: Optional error message if the request failed

    Example:
        >>> result = get_polymarket_prices("123456")
        >>> print(result.prices)
        {
            "token_abc123": MarketPriceData(BUY="0.55", SELL="0.54"),
            "token_def456": MarketPriceData(BUY="0.45", SELL="0.46")
        }
    """
    result = _call_tool("get_polymarket_prices", {"market_id": market_id})

    # Safely handle non-dict responses
    if not isinstance(result, dict):
        return GetPolymarketPricesResponse(prices={}, error="Invalid response format")

    prices_data = result.get("prices", {})
    error = result.get("error")

    # Convert prices to MarketPriceData objects
    prices = {}
    if isinstance(prices_data, dict):
        for token_id, price_info in prices_data.items():
            if isinstance(price_info, dict):
                prices[token_id] = MarketPriceData(
                    BUY=str(price_info.get("BUY", "0")), SELL=str(price_info.get("SELL", "0"))
                )

    return GetPolymarketPricesResponse(prices=prices, error=error)


def get_polymarket_order_book(market_id: str, side: str) -> OrderBookResponse:
    """Get order book for a Polymarket market side (outcome).

    Args:
        market_id: Market ID to get order book for (e.g., "123456")
        side: Side (outcome) to get order book for (e.g., "Yes", "No", "Up", "Down").
              Matched case-insensitively (with whitespace trimmed) against the market's
              available outcomes. For binary markets (2 outcomes), if no exact match is found,
              falls back to: "yes" -> first outcome, anything else -> second outcome.
              For markets with more than 2 outcomes, an exact match is required.

    Returns:
        OrderBookResponse containing order book data and optional error message.
        The order book includes bids/asks with price and size information,
        along with market metadata like tick_size and min_order_size.

    Example:
        >>> # Standard Yes/No market
        >>> result = get_polymarket_order_book("123456", side="Yes")
        >>> if result.order_book:
        ...     print(f"Tick size: {result.order_book.tick_size}")
        ...     print(f"Min order size: {result.order_book.min_order_size}")
        ...     if result.order_book.bids:
        ...         best_bid = result.order_book.bids[0]
        ...         print(f"Best bid: {best_bid.price} (size: {best_bid.size})")
        ...     if result.order_book.asks:
        ...         best_ask = result.order_book.asks[0]
        ...         print(f"Best ask: {best_ask.price} (size: {best_ask.size})")
        ...
        >>> # Market with custom outcomes
        >>> result = get_polymarket_order_book("789012", side="Up")
    """
    result = _call_tool("get_polymarket_order_book", {"market_id": market_id, "side": side})

    order_book = result.get("order_book")
    if order_book:
        # Convert to OrderBookData format matching the API response
        order_book_data = OrderBookData(
            market=order_book.get("market", ""),
            asset_id=order_book.get("asset_id", ""),
            hash=order_book.get("hash", ""),
            timestamp=order_book.get("timestamp", ""),  # Keep as string
            bids=[
                Order(price=Decimal(str(b.get("price", 0))), size=Decimal(str(b.get("size", 0))))
                for b in order_book.get("bids", [])
            ],
            asks=[
                Order(price=Decimal(str(a.get("price", 0))), size=Decimal(str(a.get("size", 0))))
                for a in order_book.get("asks", [])
            ],
            min_order_size=order_book.get("min_order_size", "0"),
            tick_size=order_book.get("tick_size", "0"),
            neg_risk=order_book.get("neg_risk", False),
        )
        return OrderBookResponse(order_book=order_book_data, error=result.get("error"))

    return OrderBookResponse(order_book=None, error=result.get("error"))


def get_polymarket_timeseries(
    market_id: str,
    side: str,
    interval: Literal["1m", "1h", "6h", "1d", "1w", "max"] = "1h",
    fidelity: int = 60,
) -> list[TimeseriesPoint]:
    """Get time series data for a Polymarket market side (outcome).

    Args:
        market_id: Market ID to get time series data for (e.g., "123456")
        side: Side (outcome) to get time series data for (e.g., "Yes", "No", "Up", "Down").
              Matched case-insensitively (with whitespace trimmed) against the market's
              available outcomes. For binary markets (2 outcomes), if no exact match is found,
              falls back to: "yes" -> first outcome, anything else -> second outcome.
              For markets with more than 2 outcomes, an exact match is required.
        interval: Time interval for the data ("max", "1d", "1h", "6h", "1w", "1m")
        fidelity: Fidelity in seconds for data resolution

    Returns:
        List of time series data points with timestamp and price

    Example:
        >>> # Standard Yes/No market
        >>> timeseries = get_polymarket_timeseries("123456", side="Yes", interval="1h")
        >>> for point in timeseries:
        ...     print(f"Time: {point.t}, Price: {point.p}")
        ...
        >>> # Market with custom outcomes
        >>> timeseries = get_polymarket_timeseries("789012", side="Down", interval="1d")
    """
    result = _call_tool(
        "get_polymarket_timeseries",
        {
            "market_id": market_id,
            "side": side,
            "interval": interval,
            "fidelity": fidelity,
        },
    )

    return [
        TimeseriesPoint(
            t=point.get("t", 0),
            p=Decimal(str(point.get("p", 0))),
        )
        for point in result.get("history", [])
    ]
