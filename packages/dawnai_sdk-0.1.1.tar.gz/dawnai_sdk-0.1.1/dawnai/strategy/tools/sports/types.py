"""Sports data types and response models.

This module provides Pydantic models for sports data from The Odds API,
including sports listings, events, odds, and scores.
"""

from __future__ import annotations

from pydantic import BaseModel

# Sports Types
# -----------------------------------------------------------------------------


class Sport(BaseModel):
    """Sport information from The Odds API.

    Attributes:
        key: Unique identifier for the sport (e.g., 'americanfootball_nfl')
        group: Sport category group (e.g., 'American Football')
        title: Human-readable sport name (e.g., 'NFL')
        description: Full description of the sport
        active: Whether the sport is currently in season
        has_outrights: Whether the sport supports outright betting markets
    """

    key: str
    group: str
    title: str
    description: str
    active: bool
    has_outrights: bool


class SportMetadata(BaseModel):
    """Metadata about sports listing.

    Attributes:
        count: Total number of sports returned
        active_count: Number of sports currently in season
    """

    count: int
    active_count: int


class GetSportsResponse(BaseModel):
    """Response from get_sports function.

    Attributes:
        success: Whether the request was successful
        data: List of sports information
        error: Error message if request failed
        metadata: Additional metadata about the response
    """

    success: bool
    data: list[Sport]
    error: str | None = None
    metadata: SportMetadata


# Event Types
# -----------------------------------------------------------------------------


class Event(BaseModel):
    """Sports event information.

    Attributes:
        id: Unique event identifier
        sport_key: Sport identifier this event belongs to
        sport_title: Human-readable sport name
        commence_time: ISO 8601 timestamp when the event starts
        home_team: Name of the home team
        away_team: Name of the away team
    """

    id: str
    sport_key: str
    sport_title: str
    commence_time: str
    home_team: str
    away_team: str


class EventMetadata(BaseModel):
    """Metadata about events listing.

    Attributes:
        sport: Sport key the events belong to
        count: Number of events returned
    """

    sport: str
    count: int


class GetEventsResponse(BaseModel):
    """Response from get_events function.

    Attributes:
        success: Whether the request was successful
        data: List of events
        error: Error message if request failed
        metadata: Additional metadata about the response
    """

    success: bool
    data: list[Event]
    error: str | None = None
    metadata: EventMetadata


# Odds Types
# -----------------------------------------------------------------------------


class Outcome(BaseModel):
    """Betting outcome within a market.

    Attributes:
        name: Name of the outcome (e.g., team name or 'Over'/'Under')
        probability: Implied probability for this outcome (0-1, converted from American odds)
        point: Point spread or total points (for spreads/totals markets)
    """

    name: str
    probability: float  # Implied probability between 0 and 1
    point: float | None = None


class Market(BaseModel):
    """Betting market with outcomes.

    Attributes:
        key: Market type identifier (e.g., 'h2h', 'spreads', 'totals')
        outcomes: List of betting outcomes in this market
    """

    key: str
    outcomes: list[Outcome]


class Bookmaker(BaseModel):
    """Bookmaker with their markets and odds.

    Attributes:
        key: Bookmaker identifier
        title: Human-readable bookmaker name
        last_update: ISO 8601 timestamp of last odds update
        markets: List of markets offered by this bookmaker
    """

    key: str
    title: str
    last_update: str
    markets: list[Market]


class OddsEvent(BaseModel):
    """Event with odds information.

    Attributes:
        id: Unique event identifier
        sport_key: Sport identifier this event belongs to
        sport_title: Human-readable sport name
        commence_time: ISO 8601 timestamp when the event starts
        home_team: Name of the home team
        away_team: Name of the away team
        bookmakers: List of bookmakers offering odds for this event
    """

    id: str
    sport_key: str
    sport_title: str
    commence_time: str
    home_team: str
    away_team: str
    bookmakers: list[Bookmaker]


class OddsMetadata(BaseModel):
    """Metadata about odds response.

    Attributes:
        sport: Sport key the odds belong to
        regions: Regions requested
        markets: Markets requested
        count: Number of events with odds returned
    """

    sport: str
    regions: str
    markets: str | None = None
    count: int


class GetOddsAsProbabilitiesResponse(BaseModel):
    """Response from get_odds_as_probabilities function.

    Attributes:
        success: Whether the request was successful
        data: List of events with odds information
        error: Error message if request failed
        metadata: Additional metadata about the response
    """

    success: bool
    data: list[OddsEvent]
    error: str | None = None
    metadata: OddsMetadata


# Scores Types
# -----------------------------------------------------------------------------


class Score(BaseModel):
    """Team score information.

    Attributes:
        name: Team name
        score: Current or final score as string
    """

    name: str
    score: str


class ScoreEvent(BaseModel):
    """Event with score information.

    Attributes:
        id: Unique event identifier
        sport_key: Sport identifier this event belongs to
        sport_title: Human-readable sport name
        commence_time: ISO 8601 timestamp when the event starts
        completed: Whether the event has finished
        home_team: Name of the home team
        away_team: Name of the away team
        scores: List of team scores (None if event hasn't started)
        last_update: ISO 8601 timestamp of last score update (None if no scores)
    """

    id: str
    sport_key: str
    sport_title: str
    commence_time: str
    completed: bool
    home_team: str
    away_team: str
    scores: list[Score] | None = None
    last_update: str | None = None


class ScoresMetadata(BaseModel):
    """Metadata about scores response.

    Attributes:
        sport: Sport key the scores belong to
        days_from: Number of days in the past requested
        count: Total number of events returned
        completed_count: Number of completed events
        live_count: Number of live events
        upcoming_count: Number of upcoming events
    """

    sport: str
    days_from: int | None = None
    count: int
    completed_count: int
    live_count: int
    upcoming_count: int


class GetScoresResponse(BaseModel):
    """Response from get_scores function.

    Attributes:
        success: Whether the request was successful
        data: List of events with scores
        error: Error message if request failed
        metadata: Additional metadata about the response
    """

    success: bool
    data: list[ScoreEvent]
    error: str | None = None
    metadata: ScoresMetadata
