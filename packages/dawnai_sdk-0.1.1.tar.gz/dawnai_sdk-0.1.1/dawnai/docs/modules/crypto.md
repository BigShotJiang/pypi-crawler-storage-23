# Crypto Module

**Path**: `dawnai.strategy.tools.crypto`

## Module Description

Cryptocurrency data and exchange functions.

## Available Functions

### `get_cryptocurrency_ohlcv(symbol_id: str, period_id: Literal['1SEC', '1MIN', '5MIN', '15MIN', '30MIN', '1HRS', '4HRS', '8HRS', '1DAY', '7DAY', '1MTH'], limit: int | None = None, time_start: str | None = None, time_end: str | None = None, endpoint: Literal['history', 'latest'] | None = None) -> CryptocurrencyOhlcvResponse`

Get OHLCV (Open, High, Low, Close, Volume) candlestick data for cryptocurrency trading.

Args:
    symbol_id: Symbol identifier (e.g., 'COINBASE_SPOT_BTC_USD', 'BINANCE_SPOT_BTC_USDT')
    period_id: Time period for candlestick data ('1SEC', '1MIN', '5MIN', '15MIN', '30MIN',
    '1HRS', '4HRS', '8HRS', '1DAY', '7DAY', '1MTH')
    limit: Number of candlestick records to return (1-10000, default: 100)
    time_start: Start time in ISO 8601 format (e.g., '2023-01-01T00:00:00Z')
    time_end: End time in ISO 8601 format (e.g., '2023-12-31T23:59:59Z')
    endpoint: Data type ('history' for historical data, 'latest' for most recent data)

Returns:
    CryptocurrencyOhlcvResponse containing:
    - success: Boolean indicating if the request was successful
    - data: List of CryptocurrencyOhlcv objects with candlestick price and volume data,
    ordered from most recent to oldest
    - error: Optional error message if the request failed
    - metadata: Additional metadata including symbol_id, period_id, endpoint, and count

Example:
    >>> ohlcv = get_cryptocurrency_ohlcv("COINBASE_SPOT_BTC_USD", "1DAY", limit=30)
    >>> if ohlcv.success:
    ...     for candle in ohlcv.data:
    ...         print(f"Open: {candle.price_open}")
    ...         print(f"High: {candle.price_high}")
    ...         print(f"Low: {candle.price_low}")
    ...         print(f"Close: {candle.price_close}")
    ...         print(f"Volume: {candle.volume_traded}")

### `get_exchange_symbols(exchange_id: str) -> ExchangeSymbolsResponse`

Get active trading symbols for a specific cryptocurrency exchange.

Args:
    exchange_id: Exchange identifier (e.g., 'BINANCE', 'COINBASE')

Returns:
    ExchangeSymbolsResponse containing:
    - success: Boolean indicating if the request was successful
    - data: List of CryptocurrencySymbol objects with symbol_id, asset_id_base, asset_id_quote
    - error: Optional error message if the request failed
    - metadata: Additional metadata including exchange_id and count of symbols

Example:
    >>> symbols = get_exchange_symbols("COINBASE")
    >>> if symbols.success:
    ...     for symbol in symbols.data:
    ...         print(f"{symbol.asset_id_base}/{symbol.asset_id_quote}: {symbol.symbol_id}")

### `get_exchanges() -> ExchangesResponse`

Get a list of all available cryptocurrency exchanges.

Returns:
    ExchangesResponse containing:
    - success: Boolean indicating if the request was successful
    - data: List of CryptocurrencyExchange objects with exchange_id, name, and optional website
    - error: Optional error message if the request failed
    - metadata: Additional metadata including count of exchanges

Example:
    >>> exchanges = get_exchanges()
    >>> if exchanges.success:
    ...     for exchange in exchanges.data:
    ...         print(f"{exchange.name}: {exchange.exchange_id}")

## Available Types

### `CryptocurrencyExchange`

Cryptocurrency exchange information.

Fields:
    exchange_id: str
    name: str
    website: str | None = None

### `CryptocurrencyOhlcv`

OHLCV (Open, High, Low, Close, Volume) candlestick data for cryptocurrency trading.

Fields:
    time_period_start: str
    time_period_end: str
    time_open: str | None = None
    time_close: str | None = None
    price_open: float
    price_high: float
    price_low: float
    price_close: float
    volume_traded: float
    trades_count: int | None = None

### `CryptocurrencyOhlcvResponse`

Response from get_cryptocurrency_ohlcv function.

Fields:
    success: bool
    data: list[CryptocurrencyOhlcv]
    error: str | None
    metadata: dict[str, Any]

### `CryptocurrencySymbol`

Active trading symbol data for cryptocurrency exchanges.

Fields:
    symbol_id: str
    asset_id_base: str
    asset_id_quote: str

### `ExchangeSymbolsResponse`

Response from get_exchange_symbols function.

Fields:
    success: bool
    data: list[CryptocurrencySymbol]
    error: str | None
    metadata: dict[str, Any]

### `ExchangesResponse`

Response from get_exchanges function.

Fields:
    success: bool
    data: list[CryptocurrencyExchange]
    error: str | None
    metadata: dict[str, Any]
