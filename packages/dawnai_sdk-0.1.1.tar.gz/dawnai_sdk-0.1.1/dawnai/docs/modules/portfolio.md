# Portfolio Module

**Path**: `dawnai.strategy.tools.portfolio`

## Module Description

Portfolio management and strategy control functions.

## Available Functions

### `read_portfolio() -> PortfolioResponse`

Read the current portfolio balance and positions.

Returns:
    PortfolioResponse containing:
    - strategy: Strategy-specific data with total/realized/unrealized PnL,
    current value, cost basis, and transactions
    - wallet: Wallet data with current balance, total/realized/unrealized PnL,
    current value, cost basis, and positions

### `terminate_strategy(should_liquidate: bool = False) -> TerminateStrategyResult`

Terminate the current strategy and optionally liquidate all positions.

Args:
    should_liquidate: If True, sells all non-USDC positions back to USDC before terminating.
    If False, terminates the strategy immediately without liquidation.

Returns:
    TerminateStrategyResult containing:
    - success: Whether the termination was successful
    - liquidated_positions: List of LiquidatedPosition objects (if should_liquidate=True)
    - final_usdc_balance: Final USDC balance after liquidation

Example:
    >>> # Terminate strategy without liquidation
    >>> result = terminate_strategy(should_liquidate=False)
    >>> print(result.success)
    True

    >>> # Terminate strategy with liquidation
    >>> result = terminate_strategy(should_liquidate=True)
    >>> print(result.liquidated_positions)
    [LiquidatedPosition(market_id="...", token_type="YES", amount=100, expected_proceeds=95.5)]
    >>> print(result.final_usdc_balance)
    1000.50

## Available Types

### `LiquidatedPosition`

Structure for a liquidated position during strategy termination.

Fields:
    market_id: str
    token_type: Literal['YES', 'NO']
    amount: Decimal
    expected_proceeds: Decimal

### `PortfolioResponse`

Response from read_portfolio function.

Fields:
    strategy: StrategyData
    wallet: WalletData

### `StrategyData`

Strategy-specific portfolio data.

Fields:
    total_pnl: Decimal
    total_pnl_percent: Decimal
    realized_pnl: Decimal
    realized_pnl_percent: Decimal
    unrealized_pnl: Decimal
    unrealized_pnl_percent: Decimal
    current_value: Decimal
    cost_basis: Decimal
    transactions: list[StrategyTransaction]

### `StrategyTransaction`

Strategy transaction record.

Fields:
    token_id: str
    market_id: str | None = None
    amount: Decimal
    price: Decimal
    type: Literal['BUY', 'SELL', 'DEPOSIT', 'WITHDRAW']
    fee: Decimal
    transaction_hash: str | None = None
    created_at: str

### `TerminateStrategyResult`

Result from terminate_strategy function.

Fields:
    success: bool
    liquidated_positions: list[LiquidatedPosition] | None = None
    final_usdc_balance: Decimal | None = None

### `WalletData`

Wallet-specific portfolio data.

Fields:
    current_balance: Decimal
    total_pnl: Decimal
    total_pnl_percentage: Decimal
    realized_pnl: Decimal
    realized_pnl_percent: Decimal
    unrealized_pnl: Decimal
    unrealized_pnl_percent: Decimal
    current_value: Decimal
    cost_basis: Decimal
    positions: list[WalletPosition]

### `WalletPosition`

Individual wallet position information.

Fields:
    token_id: str
    market_id: str | None = None
    amount: Decimal
    cost_basis: Decimal
    current_value: Decimal
    pnl: Decimal
    pnl_percent: Decimal
