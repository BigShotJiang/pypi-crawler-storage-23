"""GRIP — the memory layer for AI."""
__version__ = "0.4.1"
