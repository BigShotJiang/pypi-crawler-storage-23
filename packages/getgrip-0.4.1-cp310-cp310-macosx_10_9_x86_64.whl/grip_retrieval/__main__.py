"""Allow running as: python -m grip_retrieval"""

import os
import sys


def main():
    # Quick help
    if len(sys.argv) > 1 and sys.argv[1] in ("--help", "-h"):
        print("GRIP — Get a grip on your data.")
        print()
        print("Usage: getgrip [--port PORT]")
        print()
        print("Quick setup:")
        print("  1. Install Ollama (https://ollama.com) and run: ollama pull llama3.2")
        print("  2. Run: getgrip")
        print("  3. Open http://localhost:7878")
        print("  4. Add your files, hit Configure, start asking questions.")
        print()
        print("Options:")
        print("  --port PORT    Listen port (default: 7878)")
        print("  --help, -h     Show this help")
        print()
        print("Environment variables:")
        print("  GRIP_DATA_DIR       Data directory (default: ~/.grip)")
        print("  GRIP_LICENSE_KEY    License key for paid tiers")
        print()
        print("Docs: https://getgrip.dev")
        return

    # Parse --port
    port = 7878
    if "--port" in sys.argv:
        idx = sys.argv.index("--port")
        if idx + 1 < len(sys.argv):
            port = int(sys.argv[idx + 1])

    # Add ~/.grip/packages/ to sys.path so pip-installed extras are importable
    grip_home = os.environ.get("GRIP_DATA_DIR") or os.path.join(
        os.path.expanduser("~"), ".grip"
    )
    pkg_dir = os.path.join(grip_home, "packages")
    if os.path.isdir(pkg_dir) and pkg_dir not in sys.path:
        sys.path.insert(0, pkg_dir)

    import uvicorn
    from .server import app  # noqa: F401
    uvicorn.run(app, host="0.0.0.0", port=port)


if __name__ == "__main__":
    main()
