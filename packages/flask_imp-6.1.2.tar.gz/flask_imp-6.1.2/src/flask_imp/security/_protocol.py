import typing as t

from flask import Response


class ValidCheckpoint(t.Protocol):
    def action(
        self,
        fail_url: t.Optional[t.Union[str, t.Callable[[], t.Any]]] = None,
        fail_json: t.Optional[t.Dict[str, t.Any]] = None,
        fail_response: t.Optional[Response] = None,
        fail_status: int = 403,
        pass_url: t.Optional[t.Union[str, t.Callable[[], t.Any]]] = None,
        message: t.Optional[str] = None,
        message_category: str = "message",
    ) -> t.Any: ...

    def pass_(self) -> bool: ...
