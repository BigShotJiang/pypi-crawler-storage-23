#!/usr/bin/env python
"""Proof-of-life: connect to Slack, list workspace & channels, disconnect."""

import sys
import os

# Ensure src is on the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from appif.adapters.slack import SlackConnector

def main():
    print("=== Slack Connector Proof-of-Life ===\n")

    # 1. Construct (loads tokens from ~/.env)
    print("1. Constructing connector...")
    connector = SlackConnector()
    print(f"   Status: {connector.get_status().value}")
    print(f"   Capabilities: {connector.get_capabilities()}\n")

    # 2. Connect
    print("2. Connecting to Slack...")
    connector.connect()
    print(f"   Status: {connector.get_status().value}\n")

    # 3. List accounts
    print("3. Listing accounts...")
    accounts = connector.list_accounts()
    for acct in accounts:
        print(f"   Workspace: {acct.display_name} (id={acct.account_id})")
    print()

    # 4. List targets (channels)
    if accounts:
        account_id = accounts[0].account_id
        print(f"4. Listing targets for {account_id}...")
        targets = connector.list_targets(account_id)
        print(f"   Found {len(targets)} conversations:")
        for t in targets[:20]:  # Show first 20
            print(f"   - [{t.type}] {t.display_name} ({t.target_id})")
        if len(targets) > 20:
            print(f"   ... and {len(targets) - 20} more")
    print()

    # 5. Register a listener and show it works
    print("5. Registering a test listener...")
    received = []

    class ProofListener:
        def on_message(self, event):
            received.append(event)
            print(f"   📩 Received: [{event.conversation_ref.type}] {event.author.display_name}: {event.content.text[:80]}")

    listener = ProofListener()
    connector.register_listener(listener)
    print("   Listener registered (would receive realtime events if we waited)\n")

    # 6. Disconnect
    print("6. Disconnecting...")
    connector.unregister_listener(listener)
    connector.disconnect()
    print(f"   Status: {connector.get_status().value}\n")

    print("=== All checks passed ===")


if __name__ == "__main__":
    main()