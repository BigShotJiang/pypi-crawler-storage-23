"""Slack event → MessageEvent normalizer.

Transforms raw Slack event payloads into canonical MessageEvent objects.
No Slack types leak past this module — only domain types exit.
"""

from __future__ import annotations

from datetime import UTC, datetime

from appif.domain.messaging.models import (
    ConversationRef,
    MessageContent,
    MessageEvent,
)


def normalize_message(event: dict, team_id: str, bot_user_id: str | None, resolve_user) -> MessageEvent | None:
    """Normalize a Slack message event dict into a MessageEvent.

    Returns None if the event should be filtered (e.g., the bot's own
    messages, or unsupported subtypes).

    Args:
        event: Raw Slack event payload (from Bolt ``message`` handler).
        team_id: Workspace / team ID.
        bot_user_id: The bot's own user ID (to filter echo).
        resolve_user: Callable(user_id: str) -> Identity.
    """
    # Skip bot's own messages
    user_id = event.get("user")
    if user_id and user_id == bot_user_id:
        return None

    # Skip message subtypes we don't handle (but allow some)
    subtype = event.get("subtype")
    _skip_subtypes = {
        "channel_join",
        "channel_leave",
        "channel_topic",
        "channel_purpose",
        "channel_name",
        "channel_archive",
        "channel_unarchive",
        "group_join",
        "group_leave",
        "group_topic",
        "group_purpose",
        "group_name",
        "group_archive",
        "group_unarchive",
        "pinned_item",
        "unpinned_item",
    }
    if subtype in _skip_subtypes:
        return None

    # Bot messages without a user field — use bot_id as fallback
    if user_id is None:
        bot_id = event.get("bot_id")
        if bot_id:
            # Skip if it's our own bot
            if bot_id == bot_user_id:
                return None
            from appif.domain.messaging.models import Identity

            author = Identity(id=bot_id, display_name=event.get("username", bot_id), connector="slack")
        else:
            return None  # No author identifiable
    else:
        author = resolve_user(user_id)

    # Message ID — prefer client_msg_id, fall back to ts
    message_id = event.get("client_msg_id") or event.get("ts", "")

    # Timestamp
    ts_str = event.get("ts", "0")
    timestamp = _slack_ts_to_datetime(ts_str)

    # Conversation reference
    channel_id = event.get("channel", "")
    thread_ts = event.get("thread_ts")

    if thread_ts and thread_ts != event.get("ts"):
        conv_type = "thread"
        opaque_id = {"channel": channel_id, "thread_ts": thread_ts}
    elif event.get("channel_type") == "im":
        conv_type = "dm"
        opaque_id = {"channel": channel_id}
    else:
        conv_type = "channel"
        opaque_id = {"channel": channel_id}

    conversation_ref = ConversationRef(
        connector="slack",
        account_id=team_id,
        type=conv_type,
        opaque_id=opaque_id,
    )

    # Content
    text = event.get("text", "")
    attachments = []
    if event.get("files"):
        for f in event["files"]:
            attachments.append(
                {
                    "id": f.get("id", ""),
                    "name": f.get("name", ""),
                    "mimetype": f.get("mimetype", ""),
                    "url": f.get("url_private", ""),
                }
            )

    content = MessageContent(text=text, attachments=attachments)

    # Metadata — lightly normalized platform facts
    metadata = {}
    if subtype:
        metadata["subtype"] = subtype
    if event.get("edited"):
        metadata["edited"] = True
        metadata["edited_ts"] = event["edited"].get("ts")
    if event.get("reactions"):
        metadata["reactions"] = event["reactions"]
    if thread_ts:
        metadata["thread_ts"] = thread_ts
    if event.get("reply_count"):
        metadata["reply_count"] = event["reply_count"]

    return MessageEvent(
        message_id=message_id,
        connector="slack",
        account_id=team_id,
        conversation_ref=conversation_ref,
        author=author,
        timestamp=timestamp,
        content=content,
        metadata=metadata,
    )


def _slack_ts_to_datetime(ts: str) -> datetime:
    """Convert Slack's timestamp string (e.g., '1708257600.000100') to datetime."""
    try:
        epoch = float(ts)
        return datetime.fromtimestamp(epoch, tz=UTC)
    except (ValueError, TypeError, OSError):
        return datetime.now(tz=UTC)
