"""SlackConnector — transport adapter for Slack workspaces.

Implements the Connector protocol using Bolt for Socket Mode and
slack_sdk for API calls. All Slack-specific types and mechanics
are encapsulated here.
"""

from __future__ import annotations

import logging
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime

from slack_bolt import App
from slack_bolt.adapter.socket_mode import SocketModeHandler
from slack_sdk import WebClient

from appif.adapters.slack._auth import SlackAuth, StaticTokenAuth
from appif.adapters.slack._normalizer import normalize_message
from appif.adapters.slack._rate_limiter import call_with_retry
from appif.adapters.slack._user_cache import UserCache
from appif.domain.messaging.errors import NotAuthorized, NotSupported, TargetUnavailable, TransientFailure
from appif.domain.messaging.models import (
    Account,
    BackfillScope,
    ConnectorCapabilities,
    ConnectorStatus,
    ConversationRef,
    MessageContent,
    MessageEvent,
    SendReceipt,
    Target,
)
from appif.domain.messaging.ports import MessageListener

logger = logging.getLogger(__name__)

_CONNECTOR_NAME = "slack"


class SlackConnector:
    """Slack implementation of the Connector protocol.

    All Bolt and slack_sdk usage is internal. The public interface
    exposes only domain types.
    """

    def __init__(
        self,
        bot_token: str | None = None,
        app_token: str | None = None,
        *,
        auth: SlackAuth | None = None,
        user_cache_ttl: float = 3600.0,
        max_retries: int = 3,
        listener_pool_size: int = 4,
    ):
        # Auth is pluggable — inject any SlackAuth implementation,
        # or fall back to StaticTokenAuth (env vars / constructor args).
        if auth is not None:
            self._auth = auth
        else:
            self._auth = StaticTokenAuth(bot_token=bot_token, app_token=app_token)

        self._auth.validate()

        self._max_retries = max_retries
        self._user_cache_ttl = user_cache_ttl
        self._listener_pool_size = listener_pool_size

        # Internal state
        self._status = ConnectorStatus.DISCONNECTED
        self._listeners: list[MessageListener] = []
        self._listeners_lock = threading.Lock()

        # Slack SDK objects — initialized on connect()
        self._client: WebClient | None = None
        self._app: App | None = None
        self._socket_handler: SocketModeHandler | None = None
        self._socket_thread: threading.Thread | None = None
        self._user_cache: UserCache | None = None
        self._bot_user_id: str | None = None
        self._team_id: str | None = None
        self._team_name: str | None = None

        # Executor for fire-and-forget listener dispatch
        self._executor: ThreadPoolExecutor | None = None

    # -- Lifecycle -----------------------------------------------------------

    def connect(self) -> None:
        """Authenticate with Slack and start Socket Mode."""
        if self._status == ConnectorStatus.CONNECTED:
            return

        self._status = ConnectorStatus.CONNECTING
        try:
            self._client = WebClient(token=self._auth.bot_token)
            self._user_cache = UserCache(self._client, ttl_seconds=self._user_cache_ttl)
            self._executor = ThreadPoolExecutor(
                max_workers=self._listener_pool_size, thread_name_prefix="slack-listener"
            )

            # Verify authentication and get bot identity
            auth_response = call_with_retry(
                self._client.auth_test, connector_name=_CONNECTOR_NAME, max_retries=self._max_retries
            )
            self._bot_user_id = auth_response.data.get("user_id")
            self._team_id = auth_response.data.get("team_id")
            self._team_name = auth_response.data.get("team", "")

            logger.info(
                "slack_authenticated",
                extra={"team_id": self._team_id, "team_name": self._team_name, "bot_user_id": self._bot_user_id},
            )

            # Create Bolt app and register event handler
            self._app = App(token=self._auth.bot_token, name="appif-slack")

            @self._app.event("message")
            def _handle_message(event, say):  # noqa: ARG001
                self._on_slack_message(event)

            # Start Socket Mode in a background thread
            self._socket_handler = SocketModeHandler(self._app, self._auth.app_token)
            self._socket_thread = threading.Thread(
                target=self._socket_handler.start, name="slack-socket-mode", daemon=True
            )
            self._socket_thread.start()

            self._status = ConnectorStatus.CONNECTED
            logger.info("slack_connected", extra={"team_id": self._team_id})

        except (NotAuthorized, TransientFailure):
            self._status = ConnectorStatus.ERROR
            raise
        except Exception as exc:
            self._status = ConnectorStatus.ERROR
            raise TransientFailure(_CONNECTOR_NAME, reason=str(exc)) from exc

    def disconnect(self) -> None:
        """Tear down Socket Mode and clean up resources."""
        if self._status == ConnectorStatus.DISCONNECTED:
            return

        try:
            if self._socket_handler:
                self._socket_handler.close()
            if self._executor:
                self._executor.shutdown(wait=False)
            if self._user_cache:
                self._user_cache.clear()
        except Exception as exc:
            logger.warning("slack_disconnect_error", extra={"error": str(exc)})
        finally:
            self._socket_handler = None
            self._socket_thread = None
            self._app = None
            self._client = None
            self._user_cache = None
            self._executor = None
            self._status = ConnectorStatus.DISCONNECTED
            logger.info("slack_disconnected")

    def get_status(self) -> ConnectorStatus:
        """Return current lifecycle state."""
        return self._status

    # -- Discovery -----------------------------------------------------------

    def list_accounts(self) -> list[Account]:
        """Return the configured workspace as an Account."""
        if not self._team_id:
            return []
        return [
            Account(
                account_id=self._team_id,
                display_name=self._team_name or self._team_id,
                connector=_CONNECTOR_NAME,
            )
        ]

    def list_targets(self, account_id: str, *, member_only: bool = False) -> list[Target]:
        """List channels, DMs, and groups the bot can see.

        Args:
            account_id: Workspace account ID.
            member_only: If True, return only channels the bot has joined
                (i.e. can read history from). Defaults to False for
                backward compatibility.
        """
        self._ensure_connected()
        assert self._client is not None

        targets: list[Target] = []
        cursor = None

        while True:
            kwargs = {"types": "public_channel,private_channel,im,mpim", "limit": 200}
            if cursor:
                kwargs["cursor"] = cursor

            response = call_with_retry(
                self._client.conversations_list,
                connector_name=_CONNECTOR_NAME,
                max_retries=self._max_retries,
                **kwargs,
            )

            for channel in response.data.get("channels", []):
                # Filter to only joined channels when requested
                if member_only and not channel.get("is_member", False):
                    continue

                channel_type = _resolve_channel_type(channel)
                display_name = channel.get("name") or channel.get("id", "")
                if channel.get("is_im"):
                    # For DMs, show the other user's name if available
                    display_name = f"DM:{channel.get('user', channel.get('id', ''))}"

                targets.append(
                    Target(
                        target_id=channel["id"],
                        display_name=display_name,
                        type=channel_type,
                        account_id=account_id,
                    )
                )

            # Pagination
            cursor = response.data.get("response_metadata", {}).get("next_cursor")
            if not cursor:
                break

        return targets

    # -- Inbound -------------------------------------------------------------

    def register_listener(self, listener: MessageListener) -> None:
        """Subscribe a listener to receive inbound message events."""
        with self._listeners_lock:
            if listener not in self._listeners:
                self._listeners.append(listener)

    def unregister_listener(self, listener: MessageListener) -> None:
        """Remove a previously registered listener."""
        with self._listeners_lock:
            try:
                self._listeners.remove(listener)
            except ValueError:
                pass

    # -- Outbound ------------------------------------------------------------

    def send(self, conversation: ConversationRef, content: MessageContent) -> SendReceipt:
        """Send a message to the specified conversation."""
        self._ensure_connected()
        assert self._client is not None

        channel = conversation.opaque_id.get("channel")
        if not channel:
            raise TargetUnavailable(_CONNECTOR_NAME, target=str(conversation.opaque_id), reason="no channel in ref")

        kwargs = {"channel": channel, "text": content.text}
        thread_ts = conversation.opaque_id.get("thread_ts")
        if thread_ts:
            kwargs["thread_ts"] = thread_ts

        response = call_with_retry(
            self._client.chat_postMessage,
            connector_name=_CONNECTOR_NAME,
            max_retries=self._max_retries,
            **kwargs,
        )

        msg_ts = response.data.get("ts", "")
        return SendReceipt(
            external_id=msg_ts,
            timestamp=_slack_ts_to_datetime(msg_ts),
        )

    # -- Durability ----------------------------------------------------------

    def backfill(self, account_id: str, scope: BackfillScope) -> None:
        """Retrieve historical messages and dispatch to listeners."""
        self._ensure_connected()
        assert self._client is not None
        assert self._user_cache is not None

        conversation_ids = scope.conversation_ids
        if not conversation_ids:
            # Backfill all conversations if none specified
            targets = self.list_targets(account_id)
            conversation_ids = tuple(t.target_id for t in targets)

        for channel_id in conversation_ids:
            self._backfill_channel(channel_id, scope)

    # -- Capability introspection --------------------------------------------

    def get_capabilities(self) -> ConnectorCapabilities:
        """Return what this connector supports."""
        return ConnectorCapabilities(
            supports_realtime=True,
            supports_backfill=True,
            supports_threads=True,
            supports_reply=True,
            supports_auto_send=True,
            delivery_mode="AUTOMATIC",
        )

    # -- Internal: Event dispatch --------------------------------------------

    def _on_slack_message(self, event: dict) -> None:
        """Handle an incoming Slack message event (called by Bolt)."""
        if not self._team_id or not self._user_cache:
            return

        message_event = normalize_message(
            event=event,
            team_id=self._team_id,
            bot_user_id=self._bot_user_id,
            resolve_user=self._user_cache.resolve,
        )

        if message_event is None:
            return

        self._dispatch_to_listeners(message_event)

    def _dispatch_to_listeners(self, event: MessageEvent) -> None:
        """Fire-and-forget dispatch to all registered listeners."""
        with self._listeners_lock:
            listeners = list(self._listeners)

        for listener in listeners:
            if self._executor:
                self._executor.submit(self._safe_deliver, listener, event)
            else:
                self._safe_deliver(listener, event)

    @staticmethod
    def _safe_deliver(listener: MessageListener, event: MessageEvent) -> None:
        """Deliver to a single listener, catching any exception."""
        try:
            listener.on_message(event)
        except Exception:
            logger.exception(
                "slack_listener_error",
                extra={"listener": type(listener).__name__, "message_id": event.message_id},
            )

    # -- Internal: Backfill --------------------------------------------------

    def _backfill_channel(self, channel_id: str, scope: BackfillScope) -> None:
        """Backfill a single channel's history."""
        assert self._client is not None
        assert self._user_cache is not None
        assert self._team_id is not None

        cursor = None
        while True:
            kwargs: dict = {"channel": channel_id, "limit": 200}
            if scope.oldest:
                kwargs["oldest"] = str(scope.oldest.timestamp())
            if scope.latest:
                kwargs["latest"] = str(scope.latest.timestamp())
            if cursor:
                kwargs["cursor"] = cursor

            response = call_with_retry(
                self._client.conversations_history,
                connector_name=_CONNECTOR_NAME,
                max_retries=self._max_retries,
                **kwargs,
            )

            for msg in response.data.get("messages", []):
                msg["channel"] = channel_id
                message_event = normalize_message(
                    event=msg,
                    team_id=self._team_id,
                    bot_user_id=self._bot_user_id,
                    resolve_user=self._user_cache.resolve,
                )
                if message_event:
                    self._dispatch_to_listeners(message_event)

                # If this message has replies, backfill the thread
                if msg.get("reply_count", 0) > 0:
                    self._backfill_thread(channel_id, msg["ts"], scope)

            cursor = response.data.get("response_metadata", {}).get("next_cursor")
            if not cursor or not response.data.get("has_more"):
                break

    def _backfill_thread(self, channel_id: str, thread_ts: str, scope: BackfillScope) -> None:
        """Backfill a single thread's replies."""
        assert self._client is not None
        assert self._user_cache is not None
        assert self._team_id is not None

        cursor = None
        while True:
            kwargs: dict = {"channel": channel_id, "ts": thread_ts, "limit": 200}
            if cursor:
                kwargs["cursor"] = cursor

            response = call_with_retry(
                self._client.conversations_replies,
                connector_name=_CONNECTOR_NAME,
                max_retries=self._max_retries,
                **kwargs,
            )

            for msg in response.data.get("messages", []):
                # Skip the parent message (already handled)
                if msg.get("ts") == thread_ts and not msg.get("parent_user_id"):
                    continue

                msg["channel"] = channel_id
                msg["thread_ts"] = thread_ts
                message_event = normalize_message(
                    event=msg,
                    team_id=self._team_id,
                    bot_user_id=self._bot_user_id,
                    resolve_user=self._user_cache.resolve,
                )
                if message_event:
                    self._dispatch_to_listeners(message_event)

            cursor = response.data.get("response_metadata", {}).get("next_cursor")
            if not cursor or not response.data.get("has_more"):
                break

    # -- Internal: Helpers ---------------------------------------------------

    def _ensure_connected(self) -> None:
        """Raise if connector is not in CONNECTED state."""
        if self._status != ConnectorStatus.CONNECTED:
            raise NotSupported(_CONNECTOR_NAME, operation=f"not connected (status={self._status.value})")


def _resolve_channel_type(channel: dict) -> str:
    """Map Slack channel info to a target type string."""
    if channel.get("is_im"):
        return "dm"
    if channel.get("is_mpim"):
        return "group"
    if channel.get("is_private"):
        return "private_channel"
    return "channel"


def _slack_ts_to_datetime(ts: str) -> datetime:
    """Convert Slack timestamp to datetime."""
    try:
        return datetime.fromtimestamp(float(ts), tz=UTC)
    except (ValueError, TypeError, OSError):
        return datetime.now(tz=UTC)
