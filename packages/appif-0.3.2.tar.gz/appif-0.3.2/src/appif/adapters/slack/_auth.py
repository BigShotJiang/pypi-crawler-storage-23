"""Pluggable authentication for the Slack connector.

The connector accepts any ``SlackAuth`` implementation. The default
``StaticTokenAuth`` loads pre-configured tokens from environment variables.
A future ``OAuthInstallationAuth`` can be dropped in without changing
the connector.
"""

from __future__ import annotations

import os
from typing import Protocol

from dotenv import load_dotenv

from appif.domain.messaging.errors import NotAuthorized

_CONNECTOR_NAME = "slack"


class SlackAuth(Protocol):
    """Authentication provider for the Slack connector.

    Implementations resolve bot and app tokens by whatever means
    they choose — environment variables, OAuth installation store,
    secrets manager, etc.
    """

    @property
    def bot_token(self) -> str:
        """Bot user OAuth token (xoxb-...)."""
        ...

    @property
    def app_token(self) -> str:
        """App-level token for Socket Mode (xapp-...)."""
        ...

    def validate(self) -> None:
        """Validate that required credentials are available.

        Raises ``NotAuthorized`` if credentials are missing or invalid.
        """
        ...


class StaticTokenAuth:
    """Load static tokens from constructor args or environment variables.

    This is the default auth provider. Tokens are long-lived and
    pre-configured in ``~/.env``.
    """

    def __init__(
        self,
        bot_token: str | None = None,
        app_token: str | None = None,
        *,
        env_file: str = "~/.env",
    ):
        load_dotenv(os.path.expanduser(env_file))
        self._bot_token = bot_token if bot_token is not None else os.environ.get("APPIF_SLACK_BOT_OAUTH_TOKEN", "")
        self._app_token = app_token if app_token is not None else os.environ.get("APPIF_SLACK_BOT_APP_LEVEL_TOKEN", "")

    @property
    def bot_token(self) -> str:
        return self._bot_token

    @property
    def app_token(self) -> str:
        return self._app_token

    def validate(self) -> None:
        if not self._bot_token:
            raise NotAuthorized(_CONNECTOR_NAME, reason="APPIF_SLACK_BOT_OAUTH_TOKEN is required")
        if not self._app_token:
            raise NotAuthorized(
                _CONNECTOR_NAME,
                reason="APPIF_SLACK_BOT_APP_LEVEL_TOKEN (or APPIF_SLACK_APP_TOKEN) is required for Socket Mode",
            )
