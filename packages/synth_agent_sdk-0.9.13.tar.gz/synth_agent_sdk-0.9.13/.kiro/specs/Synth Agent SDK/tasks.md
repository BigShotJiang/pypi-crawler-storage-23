# Implementation Plan: Synth Agent SDK

## Overview

Build the Synth SDK bottom-up: core types and errors first, then the tool system, provider layer, agent core, middleware (memory, guards, structured output, tracing), orchestration (pipeline, graph, teams), evaluation, deployment (AgentCore), and finally the CLI with terminal branding. Each task builds on the previous, with property tests validating correctness at each layer.

## Tasks

- [x] 1. Project scaffolding and core types
  - [x] 1.1 Create package structure and `pyproject.toml`
    - Create the `synth/` directory tree as defined in the design
    - Set up `pyproject.toml` with minimal core dependencies (pydantic, httpx, click, typing-extensions), optional extras for providers (`synth[anthropic]`, `synth[openai]`, `synth[bedrock]`, `synth[agentcore]`, `synth[all]`), and dev dependencies (pytest, pytest-asyncio, hypothesis, pytest-cov)
    - Create `synth/__init__.py` with public API exports
    - _Requirements: 18.1, 18.2, 18.3_

  - [x] 1.2 Implement core data models in `synth/types.py`
    - Implement `RunResult`, `TokenUsage`, `ToolCallRecord` dataclasses
    - Implement stream event types: `TokenEvent`, `ToolCallEvent`, `ToolResultEvent`, `ThinkingEvent`, `DoneEvent`, `ErrorEvent`, `StageEvent`
    - Define `StreamEvent` union type
    - Implement `GuardContext`, `GuardResult` dataclasses
    - Implement `Checkpoint`, `PausedRun` dataclasses
    - Implement `TeamResult`, `AgentContribution` dataclasses
    - _Requirements: 1.2, 3.2, 3.3, 3.4, 3.5, 3.6, 8.1, 9.6_

  - [x] 1.3 Implement error hierarchy in `synth/errors.py`
    - Implement `SynthError` base class with `component` and `suggestion` fields
    - Implement all error subclasses: `SynthConfigError`, `ToolDefinitionError`, `ToolExecutionError`, `GuardViolationError`, `CostLimitError`, `SynthParseError`, `GraphRoutingError`, `GraphLoopError`, `RunNotFoundError`, `PipelineError`
    - _Requirements: 15.1, 15.2_

  - [x]* 1.4 Write property tests for error message structure
    - **Property 36: Error message structure**
    - **Validates: Requirements 15.1**

- [x] 2. Tool system
  - [x] 2.1 Implement `@tool` decorator and JSON schema generation in `synth/tools/decorator.py`
    - Inspect function signature and type hints to generate JSON schema
    - Validate type annotations and docstring presence at decoration time
    - Store schema as `fn._tool_schema` attribute
    - Map Python types (str, int, float, bool, list, dict, Optional) to JSON Schema types
    - _Requirements: 2.1, 2.5_

  - [x]* 2.2 Write property tests for tool schema generation and validation
    - **Property 1: Tool schema generation round-trip**
    - **Validates: Requirements 2.1**
    - **Property 5: Tool definition validation at decoration time**
    - **Validates: Requirements 2.5**

  - [x] 2.3 Implement `ToolKit` in `synth/tools/toolkit.py`
    - Accept list of `@tool` functions, expose `get_schemas()` and `get_tools()`
    - _Requirements: 2.6_

  - [x] 2.4 Implement `ToolExecutor` in `synth/tools/executor.py`
    - Execute tool functions by name with provided args
    - Wrap exceptions in `ToolExecutionError` with tool name, args, and original exception
    - Emit `TypeMismatchWarning` when return type doesn't match annotation
    - _Requirements: 2.3, 2.4, 15.4_

  - [x]* 2.5 Write property tests for tool execution
    - **Property 3: Tool execution feeds result back into conversation**
    - **Validates: Requirements 2.3**
    - **Property 4: Tool execution error structure**
    - **Validates: Requirements 2.4**
    - **Property 2: Tool registration completeness**
    - **Validates: Requirements 2.2, 2.6**
    - **Property 38: Type mismatch warning for tool return values**
    - **Validates: Requirements 15.4**

- [x] 3. Provider layer
  - [x] 3.1 Implement `BaseProvider` ABC in `synth/providers/base.py`
    - Define `complete()` and `stream()` abstract methods
    - Define `Message` and `ProviderResponse` types
    - _Requirements: 4.1_

  - [x] 3.2 Implement `ProviderRouter` in `synth/providers/router.py`
    - Prefix-based routing for `claude-`, `gpt-`, `gemini-`, `ollama/`, `bedrock/`
    - Raise `SynthConfigError` for unknown model strings with available providers listed
    - Raise `SynthConfigError` for missing provider packages with `pip install` command
    - Support `base_url` override for custom endpoints
    - _Requirements: 4.1, 4.2, 4.3, 1.3_

  - [x] 3.3 Implement retry logic in `synth/providers/retry.py`
    - Exponential backoff with jitter for HTTP 429 and 5xx
    - Configurable `max_retries` and `retry_backoff` base
    - _Requirements: 4.5, NFR-2.1_

  - [x]* 3.4 Write property tests for provider routing and retry
    - **Property 9: Provider routing correctness**
    - **Validates: Requirements 4.1**
    - **Property 10: Retry with exponential backoff**
    - **Validates: Requirements 4.5**
    - **Property 41: Invalid model string raises SynthConfigError**
    - **Validates: Requirements 1.3**

  - [x] 3.5 Implement `MockProvider` in `tests/conftest.py`
    - Configurable responses, tool call simulation, error injection
    - No live API calls
    - _Requirements: NFR-3.2_

  - [x] 3.6 Implement provider stubs for Anthropic, OpenAI, Google, Ollama, Bedrock
    - `synth/providers/anthropic.py`, `openai.py`, `google.py`, `ollama.py`, `bedrock.py`
    - Each implements `BaseProvider` with provider-specific SDK calls
    - Bedrock uses `boto3` `bedrock-runtime` client with AWS credential auth
    - _Requirements: 4.1, 4.2, 4.4_

- [x] 4. Checkpoint — Core foundations
  - Ensure all tests pass, ask the user if questions arise.

- [x] 5. Agent core
  - [x] 5.1 Implement `Agent` class in `synth/agent.py`
    - Constructor with `model`, `instructions`, `tools`, `memory`, `guards`, `output_schema`, `base_url`, `max_retries`, `retry_backoff`
    - Default model when none provided
    - Resolve provider via `ProviderRouter`
    - Register tools from individual functions and ToolKits
    - _Requirements: 1.1, 1.4, 1.5, 2.2, 2.6_

  - [x] 5.2 Implement `arun()` execution flow in `synth/agent.py`
    - Memory retrieval → input guards → provider call → tool execution loop → output guards → structured output parsing → trace finalization
    - Return `RunResult` with all fields populated
    - _Requirements: 1.2, 2.3, 16.2_

  - [x] 5.3 Implement sync/async compatibility in `synth/_compat.py`
    - `run_sync()` function that detects existing event loops and bridges correctly
    - Implement `agent.run()` as sync wrapper around `arun()`
    - _Requirements: 16.1, 16.2_

  - [x] 5.4 Implement `astream()` and `stream()` in `synth/agent.py`
    - Async generator yielding typed events: `TokenEvent`, `ToolCallEvent`, `ToolResultEvent`, `ThinkingEvent`, `DoneEvent`, `ErrorEvent`
    - Sync `stream()` wraps `astream()` via `_compat`
    - Clean generator closure on error
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 16.3, 16.4_

  - [x]* 5.5 Write property tests for agent core
    - **Property 42: RunResult contains all required fields**
    - **Validates: Requirements 1.2**
    - **Property 6: Stream event type mapping**
    - **Validates: Requirements 3.2, 3.3, 3.4**
    - **Property 7: DoneEvent is always the final stream event**
    - **Validates: Requirements 3.5**
    - **Property 8: ErrorEvent on stream interruption**
    - **Validates: Requirements 3.6**

- [x] 6. Memory system
  - [x] 6.1 Implement `BaseMemory` ABC and `Memory` factory in `synth/memory/base.py`
    - Define `get_messages()` and `add_messages()` abstract methods
    - `Memory.thread()`, `Memory.persistent()`, `Memory.semantic()` factory methods
    - _Requirements: 5.1_

  - [x] 6.2 Implement `ThreadMemory` in `synth/memory/thread.py`
    - In-process dict keyed by `thread_id`
    - Stateless behavior when no `thread_id` provided
    - Token counting and automatic summarisation/truncation when approaching context limit
    - _Requirements: 5.1, 5.2, 5.3, 5.6_

  - [x] 6.3 Implement `PersistentMemory` in `synth/memory/persistent.py`
    - Redis-backed storage using Redis lists
    - _Requirements: 5.4_

  - [x] 6.4 Implement `SemanticMemory` in `synth/memory/semantic.py`
    - Vector embedding storage with cosine similarity retrieval
    - _Requirements: 5.5_

  - [x]* 6.5 Write property tests for memory
    - **Property 11: Thread memory round-trip**
    - **Validates: Requirements 5.1, 5.2**
    - **Property 12: Memory truncation on context limit**
    - **Validates: Requirements 5.6**

- [x] 7. Guard system
  - [x] 7.1 Implement `BaseGuard` ABC and `Guard` factory in `synth/guards/base.py`
    - Define `check()` abstract method
    - `Guard.no_pii_output()`, `Guard.max_cost()`, `Guard.no_tool_calls()`, `Guard.custom()` factory methods
    - _Requirements: 12.1, 12.2, 12.3, 12.4_

  - [x] 7.2 Implement guard implementations
    - `PIIGuard` in `synth/guards/pii.py` — regex-based PII detection (emails, phones, SSNs)
    - `CostGuard` in `synth/guards/cost.py` — cumulative cost tracking via `GuardContext`
    - `ToolFilterGuard` in `synth/guards/tool_filter.py` — `fnmatch` glob matching
    - `CustomGuard` in `synth/guards/custom.py` — wraps user function
    - _Requirements: 12.1, 12.2, 12.3, 12.4, 12.5_

  - [x] 7.3 Implement guard evaluation pipeline in Agent
    - Evaluate guards in declaration order, stop at first violation
    - Wire into Agent's `arun()` flow (input guards before provider call, output guards after)
    - _Requirements: 12.6_

  - [x]* 7.4 Write property tests for guards
    - **Property 29: PII guard detects PII patterns**
    - **Validates: Requirements 12.1**
    - **Property 30: Cost guard enforces limit**
    - **Validates: Requirements 12.2**
    - **Property 31: Tool filter guard matches glob patterns**
    - **Validates: Requirements 12.3**
    - **Property 32: Custom guard invocation**
    - **Validates: Requirements 12.4**
    - **Property 33: Guard evaluation order and short-circuit**
    - **Validates: Requirements 12.6**

- [x] 8. Structured output
  - [x] 8.1 Implement `StructuredOutputHandler` in `synth/structured/output.py`
    - Add system message with Pydantic `model_json_schema()`
    - Parse model output into Pydantic model instance
    - Retry with corrective prompt on parse failure up to `max_retries`
    - Raise `SynthParseError` after exhausting retries
    - _Requirements: 17.1, 17.2, 17.3_

  - [x] 8.2 Wire structured output into Agent and Pipeline
    - Agent applies schema enforcement on `arun()` output
    - Pipeline applies schema enforcement only on final stage output
    - _Requirements: 17.1, 17.4_

  - [x]* 8.3 Write property tests for structured output
    - **Property 39: Structured output Pydantic parsing**
    - **Validates: Requirements 17.1**
    - **Property 40: Structured output retry on parse failure**
    - **Validates: Requirements 17.2**

- [x] 9. Tracing system
  - [x] 9.1 Implement `Trace`, `TraceSpan`, and `TraceCollector` in `synth/tracing/trace.py`
    - `TraceCollector` context manager that collects spans during a run
    - `TraceSpan` with name, type, timestamps, metadata
    - `Trace` with spans list, total_tokens, total_cost, total_latency_ms
    - _Requirements: 10.1_

  - [x] 9.2 Implement trace export and forwarding in `synth/tracing/exporter.py`
    - `trace.export()` writes OpenTelemetry-compatible JSON to disk
    - `trace.show()` opens HTML timeline in default browser
    - Auto-forward to `SYNTH_TRACE_ENDPOINT` if set
    - _Requirements: 10.2, 10.3, 10.4_

  - [x] 9.3 Implement trace integrations in `synth/tracing/integrations.py`
    - Langfuse, Datadog, Honeycomb adapter stubs with one-line config
    - _Requirements: 10.5_

  - [x] 9.4 Wire tracing into Agent execution flow
    - Create `TraceCollector` at start of each `arun()`/`astream()` call
    - Record spans for provider calls, tool executions, guard checks
    - Attach finalized `Trace` to `RunResult`
    - _Requirements: 10.1_

  - [x]* 9.5 Write property tests for tracing
    - **Property 24: Trace completeness**
    - **Validates: Requirements 10.1**
    - **Property 25: Trace export produces valid OTEL JSON**
    - **Validates: Requirements 10.3**

- [x] 10. Checkpoint — Agent + middleware integration
  - Ensure all tests pass, ask the user if questions arise.

- [x] 11. Orchestration: Pipeline
  - [x] 11.1 Implement `Pipeline` class in `synth/orchestration/pipeline.py`
    - Sequential execution: each stage receives previous stage's `result.text` as prompt
    - `ParallelGroup` for concurrent execution via `asyncio.gather()`
    - Error handling: capture partial results, raise `PipelineError` with failed step index and agent name
    - _Requirements: 6.1, 6.2, 6.4_

  - [x] 11.2 Implement Pipeline streaming
    - Wrap each event in `StageEvent(stage_name, event)`
    - Yield events from each stage in sequence
    - _Requirements: 6.3_

  - [x] 11.3 Wire `output_schema` support into Pipeline
    - Apply structured output validation only on final stage output
    - _Requirements: 17.4_

  - [x]* 11.4 Write property tests for Pipeline
    - **Property 13: Pipeline sequential data flow**
    - **Validates: Requirements 6.1**
    - **Property 14: Pipeline error halts with partial results**
    - **Validates: Requirements 6.2**
    - **Property 15: Pipeline streaming labels events with stage name**
    - **Validates: Requirements 6.3**

- [x] 12. Orchestration: Graph
  - [x] 12.1 Implement `Graph` class and `@node` decorator in `synth/orchestration/graph.py`
    - `add_node()`, `add_edge()` with optional `when` condition, `set_entry()`
    - `Graph.END` sentinel for termination
    - Execution engine: entry node → evaluate edges → follow matching → concurrent independent nodes → loop detection via `max_iterations`
    - _Requirements: 7.1, 7.2, 7.3, 7.5, 7.6, 15.3_

  - [x] 12.2 Implement graph checkpointing integration
    - `with_checkpointing()` method, persist state after each node
    - `resume(run_id)` to restore and continue from checkpoint
    - Default to `LocalCheckpointStore`, support `RedisCheckpointStore`
    - _Requirements: 7.4, 13.1, 13.2, 13.3, 13.4, 13.5_

  - [x] 12.3 Implement checkpointing stores
    - `BaseCheckpointStore` ABC in `synth/checkpointing/base.py`
    - `LocalCheckpointStore` in `synth/checkpointing/local.py` — JSON files in `.synth/checkpoints/`, atomic writes (write-to-temp-then-rename)
    - `RedisCheckpointStore` in `synth/checkpointing/redis.py` — Redis hashes with transactions
    - _Requirements: 13.1, 13.2, 13.4, 13.5, NFR-2.2_

  - [x] 12.4 Implement `graph.visualise()` for Mermaid diagram output
    - Traverse node/edge definitions, produce Mermaid diagram string
    - _Requirements: 7.7_

  - [x]* 12.5 Write property tests for Graph
    - **Property 16: Graph conditional edge routing**
    - **Validates: Requirements 7.1, 7.2**
    - **Property 17: Graph raises GraphRoutingError on dead end**
    - **Validates: Requirements 7.3**
    - **Property 18: Checkpoint persistence per step**
    - **Validates: Requirements 7.4, 13.1**
    - **Property 19: Graph termination at Graph.END**
    - **Validates: Requirements 7.5**
    - **Property 20: Graph visualise contains all nodes and edges**
    - **Validates: Requirements 7.7**
    - **Property 34: Checkpoint resume continues correctly**
    - **Validates: Requirements 13.2**
    - **Property 35: RunNotFoundError for missing checkpoint**
    - **Validates: Requirements 13.3**
    - **Property 37: GraphLoopError on max iterations**
    - **Validates: Requirements 15.3**

- [x] 13. Orchestration: Human-in-the-Loop
  - [x] 13.1 Implement human-in-the-loop in `synth/orchestration/human_in_loop.py`
    - `with_human_in_the_loop(pause_at, timeout, fallback)` on Graph
    - Return `PausedRun` when reaching a pause node
    - `PausedRun.resume(human_input)` continues from checkpoint
    - Timeout handling: abort or route to fallback node
    - Persist full checkpoint so resume works cross-process
    - _Requirements: 8.1, 8.2, 8.3, 8.4_

  - [x]* 13.2 Write property tests for human-in-the-loop
    - **Property 21: Pause/resume round-trip**
    - **Validates: Requirements 8.2, 8.4**

- [x] 14. Orchestration: AgentTeam
  - [x] 14.1 Implement `AgentTeam` in `synth/orchestration/team.py`
    - Orchestrator agent with agent descriptions for routing decisions
    - `strategy="auto"`: orchestrator decides routing dynamically
    - `strategy="parallel"`: dispatch to all agents concurrently via `asyncio.gather()`
    - `handoff(target_agent, context)` special tool injected into team agents
    - Error handling: log failure, notify orchestrator, allow re-routing
    - Return `TeamResult` with contributions, message trace, synthesised answer
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5, 9.6_

  - [x]* 14.2 Write property tests for AgentTeam
    - **Property 22: Parallel team executes all agents**
    - **Validates: Requirements 9.3**
    - **Property 23: TeamResult contains all contributions**
    - **Validates: Requirements 9.6**

- [x] 15. Checkpoint — Orchestration integration
  - Ensure all tests pass, ask the user if questions arise.

- [x] 16. Evaluation framework
  - [x] 16.1 Implement `Eval` class in `synth/eval/eval.py`
    - `add_case(input, expected, checker)` for case management
    - `run()` / `arun()` to execute cases against live agent
    - _Requirements: 11.1_

  - [x] 16.2 Implement scorers in `synth/eval/scorers.py`
    - `ExactMatchScorer`: binary 1.0/0.0 scoring
    - `SemanticSimilarityScorer`: cosine similarity of embeddings
    - Custom checker support: `checker(output, expected) -> float`
    - _Requirements: 11.2, 11.3_

  - [x] 16.3 Implement `EvalReport` and comparison in `synth/eval/report.py`
    - `EvalReport` with per-case results, overall score, cost, latency
    - `compare(baseline)` classifies cases as regression, improvement, or unchanged
    - _Requirements: 11.4, 11.5_

  - [x]* 16.4 Write property tests for evaluation
    - **Property 26: Eval scoring correctness**
    - **Validates: Requirements 11.2, 11.3, 11.4**
    - **Property 27: Eval comparison identifies regressions and improvements**
    - **Validates: Requirements 11.5**

- [x] 17. AWS AgentCore deployment
  - [x] 17.1 Implement `AgentCoreAdapter` in `synth/deploy/agentcore/adapter.py`
    - Translate AgentCore invocation payload to Synth `run()` input
    - Translate `RunResult` back to AgentCore response format
    - Integrate with AgentCore credential provider for AWS service access
    - _Requirements: 20.4, 20.5_

  - [x] 17.2 Implement `@agentcore_handler` decorator in `synth/deploy/agentcore/handler.py`
    - Wrap Agent or Graph into AgentCore-compatible request handler
    - _Requirements: 20.1_

  - [x] 17.3 Implement manifest generation in `synth/deploy/agentcore/manifest.py`
    - Generate agent descriptor with name, description, actions, IAM permissions
    - _Requirements: 20.3_

  - [x] 17.4 Implement AgentCore memory integration in `synth/deploy/agentcore/memory.py`
    - Route memory operations to AgentCore managed memory when available
    - Fall back to Synth-native Memory backend if unavailable
    - _Requirements: 20.6_

  - [x] 17.5 Implement deployment packager in `synth/deploy/packager.py`
    - Package agent code, dependencies, and config into deployment artifact
    - Support `--dry-run` validation mode
    - _Requirements: 20.2, 20.8_

  - [x] 17.6 Implement AgentCore trace forwarding
    - Forward trace data to AgentCore observability infrastructure
    - In addition to any Synth-configured trace endpoints
    - _Requirements: 20.7_

  - [x] 17.7 Implement AgentCore checkpoint integration
    - Use AgentCore managed state persistence for Graph checkpoints when deployed
    - _Requirements: 20.10_

  - [x]* 17.8 Write property tests for AgentCore
    - **Property 45: AgentCore manifest generation**
    - **Validates: Requirements 20.3**
    - **Property 46: AgentCore payload translation round-trip**
    - **Validates: Requirements 20.4**

- [x] 18. CLI
  - [x] 18.1 Implement CLI entry point in `synth/cli/main.py`
    - Click-based CLI with `synth` as the root command
    - Register subcommands: `dev`, `run`, `eval`, `trace`, `deploy`, `doctor`
    - _Requirements: 14.1_

  - [x] 18.2 Implement `synth run` in `synth/cli/run_cmd.py`
    - Load agent from file, execute with prompt, print RunResult and trace summary
    - _Requirements: 14.2_

  - [x] 18.3 Implement `synth eval` in `synth/cli/eval_cmd.py`
    - Load agent and dataset, run evaluation, print report
    - Exit with non-zero code if pass rate below threshold
    - _Requirements: 14.3, 11.6_

  - [x]* 18.4 Write property test for eval CLI exit code
    - **Property 28: Eval CLI exit code reflects pass rate**
    - **Validates: Requirements 11.6**

  - [x] 18.5 Implement `synth dev` in `synth/cli/dev.py`
    - Local REPL with hot-reload on file save
    - Open trace UI in browser
    - _Requirements: 14.1, 14.5_

  - [x] 18.6 Implement `synth trace` in `synth/cli/trace_cmd.py`
    - Open stored trace for a run ID in browser trace viewer
    - _Requirements: 14.4_

  - [x] 18.7 Implement `synth deploy` in `synth/cli/deploy_cmd.py`
    - `--target agentcore` flag, `--dry-run` validation
    - Raise `SynthConfigError` if `synth[agentcore]` not installed
    - _Requirements: 20.2, 20.8, 20.9_

  - [x] 18.8 Implement `synth doctor` in `synth/cli/doctor.py`
    - Check environment variables, provider credentials, dependency versions
    - Report issues with fix instructions
    - _Requirements: 15.5_

- [x] 19. Terminal branding and boot sequence
  - [x] 19.1 Implement boot sequence in `synth/cli/banner.py`
    - ASCII art logo + `SynthSDK` block letters + `[ AUTHENTICATION: GRANTED ]`
    - Boot status lines with `[   OK   ]` and `[ ERROR  ]` badges
    - Randomised delays (40–120ms) between lines
    - Flicker effect on ERROR line (3 rapid bold toggles)
    - Borders and dividers spanning terminal width
    - _Requirements: 19.1, 19.2, 19.3, 19.4, 19.5, 19.6_

  - [x] 19.2 Implement boot sequence controls
    - Default terminal width of 80 when undetermined
    - Skip boot sequence when `SYNTH_NO_BANNER=1` is set
    - Monochrome mode when `NO_COLOR` is set or stdout is not a TTY
    - Session-level idempotence: display only once per process
    - Consistent colour palette: bright green, dim green, bold yellow, bgRed white
    - _Requirements: 19.7, 19.8, 19.9, 19.10, 19.11_

  - [x]* 19.3 Write property tests for boot sequence
    - **Property 43: Boot sequence monochrome in no-color mode**
    - **Validates: Requirements 19.9**
    - **Property 44: Boot sequence display idempotence**
    - **Validates: Requirements 19.10**

- [x] 20. Final checkpoint — Full integration
  - Ensure all tests pass end-to-end
  - Verify public API exports in `synth/__init__.py` match design
  - Confirm `pyproject.toml` extras install correctly
  - Ask the user if questions arise
