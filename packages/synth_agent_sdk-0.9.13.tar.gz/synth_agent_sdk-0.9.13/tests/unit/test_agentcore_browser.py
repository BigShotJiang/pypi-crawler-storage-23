"""Unit tests for synth.deploy.agentcore.browser.

Covers ``BrowserTools`` — construction, lazy client init, session
management, and the navigate/search/extract methods.
"""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from synth.deploy.agentcore.browser import BrowserTools
from synth.errors import SynthConfigError


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------


class TestBrowserToolsInit:
    """Tests for ``BrowserTools.__init__``."""

    def test_default_region(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            bt = BrowserTools()
        assert bt._region == "us-east-1"

    def test_region_from_env(self) -> None:
        with patch.dict(
            "os.environ", {"AWS_DEFAULT_REGION": "eu-west-1"},
        ):
            bt = BrowserTools()
        assert bt._region == "eu-west-1"

    def test_explicit_region(self) -> None:
        bt = BrowserTools(region="ap-southeast-1")
        assert bt._region == "ap-southeast-1"

    def test_default_timeout(self) -> None:
        bt = BrowserTools()
        assert bt._session_timeout == 900

    def test_custom_timeout(self) -> None:
        bt = BrowserTools(session_timeout=1800)
        assert bt._session_timeout == 1800

    def test_client_initially_none(self) -> None:
        bt = BrowserTools()
        assert bt._client is None


# ---------------------------------------------------------------------------
# _get_client — lazy init
# ---------------------------------------------------------------------------


class TestGetClient:
    """Tests for lazy BrowserClient initialisation."""

    def test_import_error_raises_config_error(self) -> None:
        bt = BrowserTools()
        with patch.dict(
            "sys.modules",
            {
                "bedrock_agentcore": None,
                "bedrock_agentcore.tools": None,
                "bedrock_agentcore.tools.browser_client": None,
            },
        ):
            with pytest.raises(
                SynthConfigError, match="bedrock-agentcore",
            ):
                bt._get_client()

    def test_client_cached_after_first_call(self) -> None:
        mock_client = MagicMock()
        bt = BrowserTools()
        bt._client = mock_client
        assert bt._get_client() is mock_client


# ---------------------------------------------------------------------------
# cleanup
# ---------------------------------------------------------------------------


class TestCleanup:
    """Tests for session cleanup."""

    def test_cleanup_stops_client(self) -> None:
        mock_client = MagicMock()
        bt = BrowserTools()
        bt._client = mock_client

        bt.cleanup()

        mock_client.stop.assert_called_once()
        assert bt._client is None

    def test_cleanup_when_no_client(self) -> None:
        bt = BrowserTools()
        bt.cleanup()  # Should not raise
        assert bt._client is None

    def test_cleanup_handles_stop_error(self) -> None:
        mock_client = MagicMock()
        mock_client.stop.side_effect = RuntimeError("fail")
        bt = BrowserTools()
        bt._client = mock_client

        bt.cleanup()  # Should not raise
        assert bt._client is None


# ---------------------------------------------------------------------------
# navigate
# ---------------------------------------------------------------------------


class TestNavigate:
    """Tests for ``BrowserTools.navigate``."""

    def test_returns_error_when_both_paths_fail(self) -> None:
        mock_client = MagicMock()
        mock_client.generate_ws_headers.side_effect = RuntimeError(
            "no session",
        )
        bt = BrowserTools()
        bt._client = mock_client

        with patch.object(
            BrowserTools, "_navigate_httpx",
            side_effect=RuntimeError("httpx failed"),
        ):
            result = bt.navigate("https://example.com")

        parsed = json.loads(result)
        assert "error" in parsed

    def test_httpx_path_used_first(self) -> None:
        bt = BrowserTools()
        with patch.object(
            BrowserTools, "_navigate_httpx",
            return_value="Title: Test\nURL: http://test\n\nContent",
        ):
            result = bt.navigate("http://test")

        assert "Title: Test" in result

    def test_fallback_when_httpx_fails_and_no_playwright(self) -> None:
        bt = BrowserTools()

        with patch.object(
            BrowserTools, "_navigate_httpx",
            side_effect=RuntimeError("httpx failed"),
        ), patch.object(
            BrowserTools, "_navigate_playwright",
            side_effect=ImportError("no playwright"),
        ):
            result = bt.navigate("https://example.com")

        assert "Could not fetch" in result


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------


class TestSearch:
    """Tests for ``BrowserTools.search`` (httpx only, no Playwright)."""

    def test_returns_error_when_search_fails(self) -> None:
        bt = BrowserTools()

        with patch.object(
            BrowserTools, "_search_httpx",
            side_effect=RuntimeError("httpx failed"),
        ):
            result = bt.search("test query")

        parsed = json.loads(result)
        assert "error" in parsed

    def test_returns_formatted_results(self) -> None:
        bt = BrowserTools()
        fake_results = [
            {"title": "R1", "url": "http://r1.com", "snippet": "s1"},
        ]
        with patch.object(
            BrowserTools, "_search_httpx", return_value=fake_results,
        ):
            result = bt.search("test")

        assert "R1" in result
        assert "http://r1.com" in result

    def test_returns_no_results_message(self) -> None:
        bt = BrowserTools()
        with patch.object(
            BrowserTools, "_search_httpx", return_value=[],
        ):
            result = bt.search("impossible query")

        assert "No results found" in result

    def test_no_playwright_used_for_search(self) -> None:
        """Search must never call Playwright (async-safe)."""
        bt = BrowserTools()
        with patch.object(
            BrowserTools, "_search_httpx", return_value=[],
        ):
            # Should not attempt to create a browser client
            assert bt._client is None
            bt.search("test")
            assert bt._client is None


# ---------------------------------------------------------------------------
# extract
# ---------------------------------------------------------------------------


class TestExtract:
    """Tests for ``BrowserTools.extract``."""

    def test_returns_error_on_exception(self) -> None:
        mock_client = MagicMock()
        mock_client.generate_ws_headers.side_effect = RuntimeError(
            "fail",
        )
        bt = BrowserTools()
        bt._client = mock_client

        result = bt.extract("https://example.com", "h1")

        parsed = json.loads(result)
        assert "error" in parsed


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------


class TestExport:
    """Tests for package-level exports."""

    def test_browser_tools_importable_from_agentcore(self) -> None:
        from synth.deploy.agentcore import BrowserTools as BT
        assert BT is BrowserTools
