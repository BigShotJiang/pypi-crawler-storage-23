"""Unit tests for server.py runtime state tracking and drift detection.

Covers task 1.1: _original_config, _disabled_tools, _all_tools state,
_load_agent() snapshotting, and _has_drift() helper.
"""

from __future__ import annotations

import importlib
import json
import sys
import types
from typing import Any
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers — import server module with mocked StaticFiles
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _patch_static_files():
    """Patch StaticFiles to avoid directory check during server import."""
    with patch("starlette.staticfiles.StaticFiles.__init__", return_value=None):
        # Force re-import if already cached with a broken state
        mod_name = "synth.cli._ui_assets.server"
        if mod_name in sys.modules:
            del sys.modules[mod_name]
        yield
        # Clean up after test
        if mod_name in sys.modules:
            del sys.modules[mod_name]


def _get_server():
    """Import the server module for direct state inspection."""
    import synth.cli._ui_assets.server as srv
    return srv


def _make_mock_agent(
    model: str = "claude-sonnet-4-5",
    instructions: str = "Be helpful.",
    tools: dict[str, Any] | None = None,
) -> MagicMock:
    """Build a mock agent with the attributes _load_agent reads."""
    agent = MagicMock()
    agent.model = model
    agent.instructions = instructions
    agent._registered_tools = tools if tools is not None else {}
    return agent


# ---------------------------------------------------------------------------
# Module-level state defaults
# ---------------------------------------------------------------------------


class TestModuleLevelState:
    """Verify that module-level state variables are initialised correctly."""

    def test_original_config_starts_empty(self):
        srv = _get_server()
        assert srv._original_config == {}

    def test_disabled_tools_starts_empty(self):
        srv = _get_server()
        assert srv._disabled_tools == set()

    def test_all_tools_starts_empty(self):
        srv = _get_server()
        assert srv._all_tools == {}


# ---------------------------------------------------------------------------
# _load_agent() snapshotting
# ---------------------------------------------------------------------------


class TestLoadAgentSnapshot:
    """Verify _load_agent snapshots config and populates _all_tools."""

    def _patch_and_load(self, srv, mock_agent: MagicMock):
        """Patch importlib to return a module with the given mock agent."""
        fake_spec = MagicMock()
        fake_spec.loader.exec_module = lambda m: setattr(m, "agent", mock_agent)

        with patch.object(
            importlib.util, "spec_from_file_location", return_value=fake_spec
        ):
            return srv._load_agent()

    def test_snapshots_model(self):
        srv = _get_server()
        mock_agent = _make_mock_agent(model="gpt-4o")
        self._patch_and_load(srv, mock_agent)
        assert srv._original_config["model"] == "gpt-4o"

    def test_snapshots_instructions(self):
        srv = _get_server()
        mock_agent = _make_mock_agent(instructions="Test instructions")
        self._patch_and_load(srv, mock_agent)
        assert srv._original_config["instructions"] == "Test instructions"

    def test_snapshots_tool_names_sorted(self):
        srv = _get_server()
        tools = {"zebra": lambda: None, "alpha": lambda: None}
        mock_agent = _make_mock_agent(tools=tools)
        self._patch_and_load(srv, mock_agent)
        assert srv._original_config["tool_names"] == ["alpha", "zebra"]

    def test_populates_all_tools(self):
        srv = _get_server()
        fn_a = lambda: "a"
        fn_b = lambda: "b"
        tools = {"tool_a": fn_a, "tool_b": fn_b}
        mock_agent = _make_mock_agent(tools=tools)
        self._patch_and_load(srv, mock_agent)
        assert "tool_a" in srv._all_tools
        assert "tool_b" in srv._all_tools
        assert srv._all_tools["tool_a"] is fn_a

    def test_resets_disabled_tools(self):
        srv = _get_server()
        srv._disabled_tools = {"old_tool"}
        mock_agent = _make_mock_agent()
        self._patch_and_load(srv, mock_agent)
        assert srv._disabled_tools == set()

    def test_sets_agent_status_loaded(self):
        srv = _get_server()
        mock_agent = _make_mock_agent()
        self._patch_and_load(srv, mock_agent)
        assert srv._agent_status["loaded"] is True
        assert srv._agent_status["error"] is None

    def test_returns_agent_instance(self):
        srv = _get_server()
        mock_agent = _make_mock_agent()
        result = self._patch_and_load(srv, mock_agent)
        assert result is mock_agent

    def test_empty_tools_snapshot(self):
        srv = _get_server()
        mock_agent = _make_mock_agent(tools={})
        self._patch_and_load(srv, mock_agent)
        assert srv._original_config["tool_names"] == []
        assert srv._all_tools == {}


# ---------------------------------------------------------------------------
# _has_drift()
# ---------------------------------------------------------------------------


class TestHasDrift:
    """Verify _has_drift compares current agent state against snapshot."""

    def _setup_state(
        self,
        srv,
        original_model: str = "claude-sonnet-4-5",
        original_instructions: str = "Be helpful.",
        original_tool_names: list[str] | None = None,
        current_model: str = "claude-sonnet-4-5",
        current_instructions: str = "Be helpful.",
        current_tools: dict[str, Any] | None = None,
    ):
        """Set up server state for drift detection testing."""
        if original_tool_names is None:
            original_tool_names = []
        if current_tools is None:
            current_tools = {}

        srv._original_config = {
            "model": original_model,
            "instructions": original_instructions,
            "tool_names": sorted(original_tool_names),
        }
        srv._agent = _make_mock_agent(
            model=current_model,
            instructions=current_instructions,
            tools=current_tools,
        )

    def test_no_drift_when_identical(self):
        srv = _get_server()
        self._setup_state(srv)
        assert srv._has_drift() is False

    def test_drift_on_model_change(self):
        srv = _get_server()
        self._setup_state(srv, current_model="gpt-4o")
        assert srv._has_drift() is True

    def test_drift_on_instructions_change(self):
        srv = _get_server()
        self._setup_state(srv, current_instructions="New instructions")
        assert srv._has_drift() is True

    def test_drift_on_tool_added(self):
        srv = _get_server()
        self._setup_state(
            srv,
            original_tool_names=[],
            current_tools={"new_tool": lambda: None},
        )
        assert srv._has_drift() is True

    def test_drift_on_tool_removed(self):
        srv = _get_server()
        self._setup_state(
            srv,
            original_tool_names=["search"],
            current_tools={},
        )
        assert srv._has_drift() is True

    def test_no_drift_with_same_tools(self):
        srv = _get_server()
        self._setup_state(
            srv,
            original_tool_names=["alpha", "beta"],
            current_tools={"alpha": lambda: None, "beta": lambda: None},
        )
        assert srv._has_drift() is False

    def test_no_drift_when_no_original_config(self):
        srv = _get_server()
        srv._original_config = {}
        srv._agent = _make_mock_agent()
        assert srv._has_drift() is False

    def test_no_drift_when_no_agent(self):
        srv = _get_server()
        srv._original_config = {
            "model": "x", "instructions": "", "tool_names": [],
        }
        srv._agent = None
        assert srv._has_drift() is False

    def test_tool_order_does_not_matter(self):
        """Tool names are sorted before comparison, so order is irrelevant."""
        srv = _get_server()
        self._setup_state(
            srv,
            original_tool_names=["beta", "alpha"],
            current_tools={"alpha": lambda: None, "beta": lambda: None},
        )
        assert srv._has_drift() is False

# ---------------------------------------------------------------------------
# _parse_agentcore_yaml()
# ---------------------------------------------------------------------------


class TestParseAgentcoreYaml:
    """Verify agentcore.yaml detection and parsing."""

    def test_returns_none_when_no_yaml_file(self, tmp_path):
        srv = _get_server()
        srv.AGENT_FILE = str(tmp_path / "agent.py")
        result = srv._parse_agentcore_yaml()
        assert result is None

    def test_returns_metadata_when_yaml_exists(self, tmp_path):
        srv = _get_server()
        agent_file = tmp_path / "agent.py"
        agent_file.write_text("agent = None")
        yaml_file = tmp_path / "agentcore.yaml"
        yaml_file.write_text(
            "agent_name: my-agent\naws_region: us-east-1\n"
            "model_id: bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0\n"
        )
        srv.AGENT_FILE = str(agent_file)
        try:
            import yaml  # noqa: F401
        except ImportError:
            pytest.skip("PyYAML not installed")
        result = srv._parse_agentcore_yaml()
        assert result is not None
        assert result["detected"] is True
        assert result["agent_name"] == "my-agent"
        assert result["aws_region"] == "us-east-1"
        assert result["model_id"] == "bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0"

    def test_returns_empty_strings_for_missing_fields(self, tmp_path):
        srv = _get_server()
        agent_file = tmp_path / "agent.py"
        agent_file.write_text("agent = None")
        yaml_file = tmp_path / "agentcore.yaml"
        yaml_file.write_text("some_other_key: value\n")
        srv.AGENT_FILE = str(agent_file)
        try:
            import yaml  # noqa: F401
        except ImportError:
            pytest.skip("PyYAML not installed")
        result = srv._parse_agentcore_yaml()
        assert result is not None
        assert result["detected"] is True
        assert result["agent_name"] == ""
        assert result["aws_region"] == ""
        assert result["model_id"] == ""

    def test_returns_none_on_invalid_yaml(self, tmp_path):
        srv = _get_server()
        agent_file = tmp_path / "agent.py"
        agent_file.write_text("agent = None")
        yaml_file = tmp_path / "agentcore.yaml"
        yaml_file.write_text(": : : invalid yaml [[[")
        srv.AGENT_FILE = str(agent_file)
        try:
            import yaml  # noqa: F401
        except ImportError:
            pytest.skip("PyYAML not installed")
        # Invalid YAML may parse as a string or raise — either way, no crash
        result = srv._parse_agentcore_yaml()
        # Should either return metadata (if yaml parsed it oddly) or None
        assert result is None or isinstance(result, dict)


# ---------------------------------------------------------------------------
# GET /api/config endpoint
# ---------------------------------------------------------------------------


class TestGetConfigEndpoint:
    """Verify GET /api/config returns correct structure and data."""

    @pytest.fixture(autouse=True)
    def _setup_server(self):
        """Get a fresh server reference for each test."""
        self.srv = _get_server()

    def _setup_agent(
        self,
        model: str = "claude-sonnet-4-5",
        instructions: str = "Be helpful.",
        tools: dict[str, Any] | None = None,
        guards: list | None = None,
        disabled: set[str] | None = None,
    ):
        """Configure server state with a mock agent."""
        if tools is None:
            tools = {}
        agent = _make_mock_agent(model=model, instructions=instructions, tools=tools)
        agent.guards = guards if guards is not None else []
        self.srv._agent = agent
        self.srv._all_tools = dict(tools)
        self.srv._disabled_tools = disabled if disabled is not None else set()
        self.srv._original_config = {
            "model": model,
            "instructions": instructions,
            "tool_names": sorted(tools.keys()),
        }

    @pytest.mark.asyncio
    async def test_returns_503_when_no_agent(self):
        self.srv._agent = None
        response = await self.srv.get_config()
        assert response.status_code == 503
        body = json.loads(response.body)
        assert body["error"] == "No agent loaded."

    @pytest.mark.asyncio
    async def test_returns_model(self):
        self._setup_agent(model="gpt-4o")
        response = await self.srv.get_config()
        body = json.loads(response.body)
        assert body["model"] == "gpt-4o"

    @pytest.mark.asyncio
    async def test_returns_instructions(self):
        self._setup_agent(instructions="Custom instructions here")
        response = await self.srv.get_config()
        body = json.loads(response.body)
        assert body["instructions"] == "Custom instructions here"

    @pytest.mark.asyncio
    async def test_returns_tools_with_enabled_status(self):
        def search():
            """Search the web"""
        search._tool_schema = {"description": "Search the web"}

        def calc():
            """Do math"""
        calc._tool_schema = {"description": "Do math"}

        tools = {"search": search, "calculator": calc}
        self._setup_agent(tools=tools, disabled={"calculator"})
        response = await self.srv.get_config()
        body = json.loads(response.body)
        tools_by_name = {t["name"]: t for t in body["tools"]}
        assert tools_by_name["search"]["enabled"] is True
        assert tools_by_name["search"]["description"] == "Search the web"
        assert tools_by_name["calculator"]["enabled"] is False
        assert tools_by_name["calculator"]["description"] == "Do math"

    @pytest.mark.asyncio
    async def test_tool_description_falls_back_to_docstring(self):
        def my_tool():
            """Fallback docstring description"""
        my_tool._tool_schema = {}

        self._setup_agent(tools={"my_tool": my_tool})
        response = await self.srv.get_config()
        body = json.loads(response.body)
        assert body["tools"][0]["description"] == "Fallback docstring description"

    @pytest.mark.asyncio
    async def test_returns_guards_with_name_and_type(self):
        class PIIGuard:
            name = "no_pii_output"

        class CostGuard:
            name = "cost_limit"

        self._setup_agent(guards=[PIIGuard(), CostGuard()])
        response = await self.srv.get_config()
        body = json.loads(response.body)
        assert len(body["guards"]) == 2
        assert body["guards"][0]["name"] == "no_pii_output"
        assert body["guards"][0]["type"] == "PIIGuard"
        assert body["guards"][1]["name"] == "cost_limit"
        assert body["guards"][1]["type"] == "CostGuard"

    @pytest.mark.asyncio
    async def test_returns_has_drift_flag(self):
        self._setup_agent(model="claude-sonnet-4-5")
        # Mutate model to create drift
        self.srv._agent.model = "gpt-4o"
        response = await self.srv.get_config()
        body = json.loads(response.body)
        assert body["has_drift"] is True

    @pytest.mark.asyncio
    async def test_returns_no_drift_when_unchanged(self):
        self._setup_agent()
        response = await self.srv.get_config()
        body = json.loads(response.body)
        assert body["has_drift"] is False

    @pytest.mark.asyncio
    async def test_returns_agentcore_not_detected_when_no_yaml(self, tmp_path):
        self._setup_agent()
        self.srv.AGENT_FILE = str(tmp_path / "agent.py")
        response = await self.srv.get_config()
        body = json.loads(response.body)
        assert body["agentcore"]["detected"] is False

    @pytest.mark.asyncio
    async def test_returns_agentcore_metadata_when_yaml_exists(self, tmp_path):
        try:
            import yaml  # noqa: F401
        except ImportError:
            pytest.skip("PyYAML not installed")
        self._setup_agent()
        agent_file = tmp_path / "agent.py"
        agent_file.write_text("agent = None")
        yaml_file = tmp_path / "agentcore.yaml"
        yaml_file.write_text(
            "agent_name: test-agent\naws_region: us-west-2\n"
            "model_id: bedrock/model-123\n"
        )
        self.srv.AGENT_FILE = str(agent_file)
        response = await self.srv.get_config()
        body = json.loads(response.body)
        assert body["agentcore"]["detected"] is True
        assert body["agentcore"]["agent_name"] == "test-agent"
        assert body["agentcore"]["aws_region"] == "us-west-2"
        assert body["agentcore"]["model_id"] == "bedrock/model-123"

    @pytest.mark.asyncio
    async def test_returns_empty_tools_and_guards(self):
        self._setup_agent(tools={}, guards=[])
        response = await self.srv.get_config()
        body = json.loads(response.body)
        assert body["tools"] == []
        assert body["guards"] == []

    @pytest.mark.asyncio
    async def test_response_contains_all_required_keys(self):
        self._setup_agent()
        response = await self.srv.get_config()
        body = json.loads(response.body)
        required_keys = {"model", "instructions", "tools", "guards", "has_drift", "agentcore"}
        assert required_keys.issubset(body.keys())


# ---------------------------------------------------------------------------
# _build_models_by_provider() and GET /api/models endpoint
# ---------------------------------------------------------------------------


class TestBuildModelsByProvider:
    """Verify _build_models_by_provider groups models by display name."""

    def test_returns_dict_of_provider_to_models(self):
        srv = _get_server()
        result = srv._build_models_by_provider()
        assert isinstance(result, dict)
        for display_name, models in result.items():
            assert isinstance(display_name, str)
            assert isinstance(models, list)
            assert all(isinstance(m, str) for m in models)

    def test_contains_anthropic_provider(self):
        srv = _get_server()
        result = srv._build_models_by_provider()
        # _PROVIDERS has "anthropic" with display "Anthropic (Claude)"
        assert "Anthropic (Claude)" in result

    def test_anthropic_models_include_default(self):
        srv = _get_server()
        result = srv._build_models_by_provider()
        models = result.get("Anthropic (Claude)", [])
        assert "claude-sonnet-4-5" in models

    def test_contains_openai_provider(self):
        srv = _get_server()
        result = srv._build_models_by_provider()
        assert "OpenAI (GPT)" in result

    def test_openai_models_include_default(self):
        srv = _get_server()
        result = srv._build_models_by_provider()
        models = result.get("OpenAI (GPT)", [])
        assert "gpt-4o" in models

    def test_contains_ollama_provider(self):
        srv = _get_server()
        result = srv._build_models_by_provider()
        assert "Llama (via Ollama)" in result

    def test_ollama_models_include_default(self):
        srv = _get_server()
        result = srv._build_models_by_provider()
        models = result.get("Llama (via Ollama)", [])
        assert "ollama/llama3.2" in models

    def test_contains_google_provider(self):
        srv = _get_server()
        result = srv._build_models_by_provider()
        assert "Google Gemini" in result

    def test_contains_agentcore_provider(self):
        srv = _get_server()
        result = srv._build_models_by_provider()
        assert "AWS AgentCore (Bedrock)" in result

    def test_no_duplicate_models_per_provider(self):
        srv = _get_server()
        result = srv._build_models_by_provider()
        for models in result.values():
            assert len(models) == len(set(models))

    def test_all_models_are_nonempty_strings(self):
        srv = _get_server()
        result = srv._build_models_by_provider()
        for models in result.values():
            assert len(models) > 0
            for m in models:
                assert m.strip() != ""


class TestGetModelsEndpoint:
    """Verify GET /api/models returns correct structure."""

    @pytest.fixture(autouse=True)
    def _setup_server(self):
        self.srv = _get_server()

    @pytest.mark.asyncio
    async def test_returns_providers_key(self):
        response = await self.srv.get_models()
        body = json.loads(response.body)
        assert "providers" in body

    @pytest.mark.asyncio
    async def test_providers_is_dict(self):
        response = await self.srv.get_models()
        body = json.loads(response.body)
        assert isinstance(body["providers"], dict)

    @pytest.mark.asyncio
    async def test_each_provider_has_model_list(self):
        response = await self.srv.get_models()
        body = json.loads(response.body)
        for name, models in body["providers"].items():
            assert isinstance(name, str)
            assert isinstance(models, list)
            assert len(models) > 0

    @pytest.mark.asyncio
    async def test_response_status_is_200(self):
        response = await self.srv.get_models()
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_contains_known_providers(self):
        response = await self.srv.get_models()
        body = json.loads(response.body)
        providers = body["providers"]
        # At minimum, Anthropic and OpenAI should be present
        assert "Anthropic (Claude)" in providers
        assert "OpenAI (GPT)" in providers


# ---------------------------------------------------------------------------
# PATCH /api/config endpoint
# ---------------------------------------------------------------------------


class TestUpdateConfigEndpoint:
    """Verify PATCH /api/config updates model, instructions, and tools."""

    @pytest.fixture(autouse=True)
    def _setup_server(self):
        """Get a fresh server reference for each test."""
        self.srv = _get_server()

    def _setup_agent(
        self,
        model: str = "claude-sonnet-4-5",
        instructions: str = "Be helpful.",
        tools: dict[str, Any] | None = None,
        disabled: set[str] | None = None,
    ):
        """Configure server state with a mock agent for PATCH tests."""
        if tools is None:
            tools = {}
        agent = _make_mock_agent(
            model=model, instructions=instructions, tools=tools,
        )
        agent.base_url = None
        agent.guards = []
        self.srv._agent = agent
        self.srv._all_tools = dict(tools)
        self.srv._disabled_tools = disabled if disabled is not None else set()
        self.srv._original_config = {
            "model": model,
            "instructions": instructions,
            "tool_names": sorted(tools.keys()),
        }

    def _make_request(self, body: dict[str, Any]) -> MagicMock:
        """Build a mock Request whose .json() returns the given body."""
        req = MagicMock()
        req.json = MagicMock(return_value=self._async_return(body))
        return req

    @staticmethod
    async def _async_return(value):
        return value

    # --- 503 when no agent ---

    @pytest.mark.asyncio
    async def test_returns_503_when_no_agent(self):
        self.srv._agent = None
        req = self._make_request({})
        response = await self.srv.update_config(req)
        assert response.status_code == 503
        body = json.loads(response.body)
        assert body["error"] == "No agent loaded."

    # --- Instructions update ---

    @pytest.mark.asyncio
    async def test_updates_instructions(self):
        self._setup_agent(instructions="Old instructions")
        req = self._make_request({"instructions": "New instructions"})
        response = await self.srv.update_config(req)
        body = json.loads(response.body)
        assert body["status"] == "updated"
        assert self.srv._agent.instructions == "New instructions"

    @pytest.mark.asyncio
    async def test_instructions_update_returns_drift(self):
        self._setup_agent(instructions="Original")
        req = self._make_request({"instructions": "Changed"})
        response = await self.srv.update_config(req)
        body = json.loads(response.body)
        assert body["has_drift"] is True

    # --- Model update ---

    @pytest.mark.asyncio
    async def test_updates_model_with_valid_prefix(self):
        self._setup_agent(model="claude-sonnet-4-5")
        req = self._make_request({"model": "gpt-4o"})
        with patch(
            "synth.providers.router.ProviderRouter.resolve"
        ) as mock_resolve:
            mock_provider = MagicMock()
            mock_resolve.return_value = mock_provider
            response = await self.srv.update_config(req)
        body = json.loads(response.body)
        assert body["status"] == "updated"
        assert self.srv._agent.model == "gpt-4o"
        assert self.srv._agent.provider is mock_provider

    @pytest.mark.asyncio
    async def test_returns_400_for_invalid_model(self):
        from synth.errors import SynthConfigError

        self._setup_agent(model="claude-sonnet-4-5")
        req = self._make_request({"model": "invalid-model-xyz"})
        with patch(
            "synth.providers.router.ProviderRouter.resolve",
            side_effect=SynthConfigError(
                message="Model 'invalid-model-xyz' not recognized.",
                component="ProviderRouter",
                suggestion="Use a valid model prefix.",
            ),
        ):
            response = await self.srv.update_config(req)
        assert response.status_code == 400
        body = json.loads(response.body)
        assert "error" in body

    @pytest.mark.asyncio
    async def test_invalid_model_leaves_model_unchanged(self):
        from synth.errors import SynthConfigError

        self._setup_agent(model="claude-sonnet-4-5")
        req = self._make_request({"model": "bad-model"})
        with patch(
            "synth.providers.router.ProviderRouter.resolve",
            side_effect=SynthConfigError(
                message="Not recognized.",
                component="ProviderRouter",
                suggestion="Fix it.",
            ),
        ):
            await self.srv.update_config(req)
        assert self.srv._agent.model == "claude-sonnet-4-5"

    @pytest.mark.asyncio
    async def test_model_update_passes_base_url(self):
        self._setup_agent()
        self.srv._agent.base_url = "http://localhost:11434"
        req = self._make_request({"model": "ollama/llama3.2"})
        with patch(
            "synth.providers.router.ProviderRouter.resolve"
        ) as mock_resolve:
            mock_resolve.return_value = MagicMock()
            await self.srv.update_config(req)
            mock_resolve.assert_called_once_with(
                "ollama/llama3.2", base_url="http://localhost:11434",
            )

    # --- Tool toggles ---

    @pytest.mark.asyncio
    async def test_disables_tool(self):
        fn_search = lambda: "result"
        fn_calc = lambda: 42
        tools = {"search": fn_search, "calculator": fn_calc}
        self._setup_agent(tools=tools)
        req = self._make_request({"tools": {"calculator": False}})
        response = await self.srv.update_config(req)
        body = json.loads(response.body)
        assert body["status"] == "updated"
        assert "calculator" in self.srv._disabled_tools
        assert "calculator" not in self.srv._agent._registered_tools

    @pytest.mark.asyncio
    async def test_reenables_tool(self):
        fn_search = lambda: "result"
        fn_calc = lambda: 42
        tools = {"search": fn_search, "calculator": fn_calc}
        self._setup_agent(tools=tools, disabled={"calculator"})
        req = self._make_request({"tools": {"calculator": True}})
        response = await self.srv.update_config(req)
        body = json.loads(response.body)
        assert body["status"] == "updated"
        assert "calculator" not in self.srv._disabled_tools
        assert "calculator" in self.srv._agent._registered_tools

    @pytest.mark.asyncio
    async def test_tool_toggle_rebuilds_tool_executor(self):
        fn_search = lambda: "result"
        tools = {"search": fn_search}
        self._setup_agent(tools=tools)
        old_executor = self.srv._agent.tool_executor
        req = self._make_request({"tools": {"search": False}})
        await self.srv.update_config(req)
        # tool_executor should be a new ToolExecutor instance
        from synth.tools.executor import ToolExecutor

        assert isinstance(self.srv._agent.tool_executor, ToolExecutor)

    @pytest.mark.asyncio
    async def test_ignores_unknown_tool_names(self):
        fn_search = lambda: "result"
        tools = {"search": fn_search}
        self._setup_agent(tools=tools)
        req = self._make_request({"tools": {"nonexistent": False}})
        response = await self.srv.update_config(req)
        body = json.loads(response.body)
        assert body["status"] == "updated"
        assert "nonexistent" not in self.srv._disabled_tools

    @pytest.mark.asyncio
    async def test_all_tools_unchanged_after_toggle(self):
        fn_a = lambda: "a"
        fn_b = lambda: "b"
        tools = {"tool_a": fn_a, "tool_b": fn_b}
        self._setup_agent(tools=tools)
        original_all_tools = dict(self.srv._all_tools)
        req = self._make_request({"tools": {"tool_a": False}})
        await self.srv.update_config(req)
        assert self.srv._all_tools == original_all_tools

    # --- Combined updates ---

    @pytest.mark.asyncio
    async def test_updates_multiple_fields_at_once(self):
        fn_search = lambda: "result"
        tools = {"search": fn_search}
        self._setup_agent(
            model="claude-sonnet-4-5",
            instructions="Old",
            tools=tools,
        )
        req = self._make_request({
            "model": "gpt-4o",
            "instructions": "New",
            "tools": {"search": False},
        })
        with patch(
            "synth.providers.router.ProviderRouter.resolve"
        ) as mock_resolve:
            mock_resolve.return_value = MagicMock()
            response = await self.srv.update_config(req)
        body = json.loads(response.body)
        assert body["status"] == "updated"
        assert self.srv._agent.model == "gpt-4o"
        assert self.srv._agent.instructions == "New"
        assert "search" in self.srv._disabled_tools

    @pytest.mark.asyncio
    async def test_empty_body_is_noop(self):
        self._setup_agent(model="claude-sonnet-4-5", instructions="Keep me")
        req = self._make_request({})
        response = await self.srv.update_config(req)
        body = json.loads(response.body)
        assert body["status"] == "updated"
        assert self.srv._agent.model == "claude-sonnet-4-5"
        assert self.srv._agent.instructions == "Keep me"

    @pytest.mark.asyncio
    async def test_response_contains_warnings_list(self):
        self._setup_agent()
        req = self._make_request({"instructions": "Updated"})
        response = await self.srv.update_config(req)
        body = json.loads(response.body)
        assert "warnings" in body
        assert isinstance(body["warnings"], list)


# ---------------------------------------------------------------------------
# POST /api/config/save endpoint
# ---------------------------------------------------------------------------


class TestSaveConfigEndpoint:
    """Tests for the POST /api/config/save endpoint (task 1.5).

    Validates Requirements 5.1, 5.2, 5.3, 5.4.
    """

    def _setup_server(self):
        self.srv = _get_server()

    def _setup_agent(
        self,
        model: str = "claude-sonnet-4-5",
        instructions: str = "Be helpful.",
        tools: dict[str, Any] | None = None,
    ):
        self._setup_server()
        agent = _make_mock_agent(model=model, instructions=instructions, tools=tools)
        self.srv._agent = agent
        self.srv._all_tools = tools if tools is not None else {}
        self.srv._disabled_tools = set()
        self.srv._original_config = {
            "model": model,
            "instructions": instructions,
            "tool_names": sorted((tools or {}).keys()),
        }

    def _make_request(self, body: dict[str, Any] | None = None) -> MagicMock:
        req = MagicMock()

        async def _async_json():
            return body or {}

        req.json = _async_json
        return req

    # --- 503 when no agent loaded ---

    @pytest.mark.asyncio
    async def test_returns_503_when_no_agent(self):
        self._setup_server()
        self.srv._agent = None
        req = self._make_request()
        response = await self.srv.save_config(req)
        assert response.status_code == 503
        body = json.loads(response.body)
        assert "No agent loaded" in body["error"]

    # --- 400 for empty model ---

    @pytest.mark.asyncio
    async def test_returns_400_when_model_empty(self):
        self._setup_agent(model="")
        req = self._make_request()
        response = await self.srv.save_config(req)
        assert response.status_code == 400
        body = json.loads(response.body)
        assert "Model string must not be empty" in body["error"]

    # --- 400 for empty instructions ---

    @pytest.mark.asyncio
    async def test_returns_400_when_instructions_empty(self):
        self._setup_agent(model="claude-sonnet-4-5", instructions="")
        req = self._make_request()
        response = await self.srv.save_config(req)
        assert response.status_code == 400
        body = json.loads(response.body)
        assert "Instructions must not be empty" in body["error"]

    # --- Successful save with string-literal agent file ---

    @pytest.mark.asyncio
    async def test_saves_successfully_with_patchable_source(self, tmp_path):
        self._setup_agent(model="gpt-4o", instructions="New instructions")
        agent_source = (
            'from synth import Agent\n'
            'agent = Agent(\n'
            '    model="claude-sonnet-4-5",\n'
            '    instructions="Be helpful.",\n'
            '    tools=[search, calc]\n'
            ')\n'
        )
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(agent_source, encoding="utf-8")
        self.srv.AGENT_FILE = str(agent_file)

        req = self._make_request()
        response = await self.srv.save_config(req)
        body = json.loads(response.body)

        assert response.status_code == 200
        assert body["status"] == "saved"
        assert body["warnings"] == []

    @pytest.mark.asyncio
    async def test_patched_file_contains_new_model(self, tmp_path):
        self._setup_agent(model="gpt-4o", instructions="New instructions")
        agent_source = (
            'agent = Agent(\n'
            '    model="claude-sonnet-4-5",\n'
            '    instructions="Be helpful.",\n'
            '    tools=[search]\n'
            ')\n'
        )
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(agent_source, encoding="utf-8")
        self.srv.AGENT_FILE = str(agent_file)

        req = self._make_request()
        await self.srv.save_config(req)

        written = agent_file.read_text(encoding="utf-8")
        assert 'model="gpt-4o"' in written

    @pytest.mark.asyncio
    async def test_patched_file_contains_new_instructions(self, tmp_path):
        self._setup_agent(model="gpt-4o", instructions="New instructions")
        agent_source = (
            'agent = Agent(\n'
            '    model="claude-sonnet-4-5",\n'
            '    instructions="Be helpful.",\n'
            '    tools=[search]\n'
            ')\n'
        )
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(agent_source, encoding="utf-8")
        self.srv.AGENT_FILE = str(agent_file)

        req = self._make_request()
        await self.srv.save_config(req)

        written = agent_file.read_text(encoding="utf-8")
        assert 'instructions="New instructions"' in written

    # --- Warnings for non-patchable fields ---

    @pytest.mark.asyncio
    async def test_warns_when_model_not_patchable(self, tmp_path):
        self._setup_agent(model="gpt-4o", instructions="Be helpful.")
        agent_source = (
            'agent = Agent(\n'
            '    model=os.environ["MODEL"],\n'
            '    instructions="Be helpful.",\n'
            '    tools=[search]\n'
            ')\n'
        )
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(agent_source, encoding="utf-8")
        self.srv.AGENT_FILE = str(agent_file)

        req = self._make_request()
        response = await self.srv.save_config(req)
        body = json.loads(response.body)

        assert body["status"] == "saved"
        assert any("model" in w for w in body["warnings"])

    @pytest.mark.asyncio
    async def test_warns_when_instructions_not_patchable(self, tmp_path):
        self._setup_agent(model="gpt-4o", instructions="Be helpful.")
        agent_source = (
            'agent = Agent(\n'
            '    model="claude-sonnet-4-5",\n'
            '    instructions=load_instructions(),\n'
            '    tools=[search]\n'
            ')\n'
        )
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(agent_source, encoding="utf-8")
        self.srv.AGENT_FILE = str(agent_file)

        req = self._make_request()
        response = await self.srv.save_config(req)
        body = json.loads(response.body)

        assert body["status"] == "saved"
        assert any("instructions" in w for w in body["warnings"])

    @pytest.mark.asyncio
    async def test_warns_when_tools_not_patchable(self, tmp_path):
        self._setup_agent(model="gpt-4o", instructions="Be helpful.")
        agent_source = (
            'agent = Agent(\n'
            '    model="claude-sonnet-4-5",\n'
            '    instructions="Be helpful.",\n'
            ')\n'
        )
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(agent_source, encoding="utf-8")
        self.srv.AGENT_FILE = str(agent_file)

        req = self._make_request()
        response = await self.srv.save_config(req)
        body = json.loads(response.body)

        assert body["status"] == "saved"
        assert any("tools" in w for w in body["warnings"])

    # --- Updates _original_config after save ---

    @pytest.mark.asyncio
    async def test_updates_original_config_after_save(self, tmp_path):
        self._setup_agent(model="gpt-4o", instructions="New instructions")
        agent_source = (
            'agent = Agent(\n'
            '    model="claude-sonnet-4-5",\n'
            '    instructions="Be helpful.",\n'
            '    tools=[search]\n'
            ')\n'
        )
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(agent_source, encoding="utf-8")
        self.srv.AGENT_FILE = str(agent_file)

        req = self._make_request()
        await self.srv.save_config(req)

        assert self.srv._original_config["model"] == "gpt-4o"
        assert self.srv._original_config["instructions"] == "New instructions"

    @pytest.mark.asyncio
    async def test_drift_resets_after_save(self, tmp_path):
        self._setup_agent(model="gpt-4o", instructions="New instructions")
        # Original config was set to match the agent in _setup_agent,
        # so override to simulate drift
        self.srv._original_config = {
            "model": "claude-sonnet-4-5",
            "instructions": "Be helpful.",
            "tool_names": [],
        }
        assert self.srv._has_drift() is True

        agent_source = (
            'agent = Agent(\n'
            '    model="claude-sonnet-4-5",\n'
            '    instructions="Be helpful.",\n'
            '    tools=[]\n'
            ')\n'
        )
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(agent_source, encoding="utf-8")
        self.srv.AGENT_FILE = str(agent_file)

        req = self._make_request()
        await self.srv.save_config(req)

        assert self.srv._has_drift() is False

    # --- 500 on file write failure ---

    @pytest.mark.asyncio
    async def test_returns_500_when_file_read_fails(self, tmp_path):
        self._setup_agent(model="gpt-4o", instructions="Be helpful.")
        self.srv.AGENT_FILE = str(tmp_path / "nonexistent" / "agent.py")

        req = self._make_request()
        response = await self.srv.save_config(req)
        assert response.status_code == 500
        body = json.loads(response.body)
        assert "Failed to read agent file" in body["error"]

    @pytest.mark.asyncio
    async def test_returns_500_when_atomic_write_fails(self, tmp_path):
        self._setup_agent(model="gpt-4o", instructions="Be helpful.")
        agent_source = (
            'agent = Agent(\n'
            '    model="claude-sonnet-4-5",\n'
            '    instructions="Be helpful.",\n'
            '    tools=[]\n'
            ')\n'
        )
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(agent_source, encoding="utf-8")
        self.srv.AGENT_FILE = str(agent_file)

        req = self._make_request()
        with patch(
            "synth.cli.edit_cmd._atomic_write",
            side_effect=OSError("disk full"),
        ):
            response = await self.srv.save_config(req)
        assert response.status_code == 500
        body = json.loads(response.body)
        assert "Failed to write agent file" in body["error"]

    # --- Response structure ---

    @pytest.mark.asyncio
    async def test_response_contains_status_and_warnings(self, tmp_path):
        self._setup_agent(model="gpt-4o", instructions="Be helpful.")
        agent_source = (
            'agent = Agent(\n'
            '    model="claude-sonnet-4-5",\n'
            '    instructions="Be helpful.",\n'
            '    tools=[]\n'
            ')\n'
        )
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(agent_source, encoding="utf-8")
        self.srv.AGENT_FILE = str(agent_file)

        req = self._make_request()
        response = await self.srv.save_config(req)
        body = json.loads(response.body)

        assert "status" in body
        assert "warnings" in body
        assert isinstance(body["warnings"], list)

    @pytest.mark.asyncio
    async def test_tool_names_sorted_in_original_config(self, tmp_path):
        tools = {"zebra": MagicMock(), "alpha": MagicMock()}
        self._setup_agent(
            model="gpt-4o", instructions="Be helpful.", tools=tools,
        )
        agent_source = (
            'agent = Agent(\n'
            '    model="claude-sonnet-4-5",\n'
            '    instructions="Be helpful.",\n'
            '    tools=[alpha, zebra]\n'
            ')\n'
        )
        agent_file = tmp_path / "agent.py"
        agent_file.write_text(agent_source, encoding="utf-8")
        self.srv.AGENT_FILE = str(agent_file)

        req = self._make_request()
        await self.srv.save_config(req)

        assert self.srv._original_config["tool_names"] == ["alpha", "zebra"]


# ---------------------------------------------------------------------------
# _lifespan() async context manager
# ---------------------------------------------------------------------------


class TestLifespan:
    """Verify _lifespan loads persisted data and the agent on startup."""

    @pytest.mark.asyncio
    async def test_calls_all_load_functions(self):
        srv = _get_server()
        with (
            patch.object(srv, "_load_conversations") as m_conv,
            patch.object(srv, "_load_prompts") as m_prompts,
            patch.object(srv, "_load_evals") as m_evals,
            patch.object(srv, "_load_scenarios") as m_scenarios,
            patch.object(srv, "_load_agent") as m_agent,
        ):
            async with srv._lifespan(srv.app):
                pass
        m_conv.assert_called_once()
        m_prompts.assert_called_once()
        m_evals.assert_called_once()
        m_scenarios.assert_called_once()
        m_agent.assert_called_once()

    @pytest.mark.asyncio
    async def test_sets_agent_status_error_on_load_failure(self):
        srv = _get_server()
        srv._agent_status["error"] = None
        with (
            patch.object(srv, "_load_conversations"),
            patch.object(srv, "_load_prompts"),
            patch.object(srv, "_load_evals"),
            patch.object(srv, "_load_scenarios"),
            patch.object(
                srv, "_load_agent",
                side_effect=RuntimeError("bad agent file"),
            ),
        ):
            async with srv._lifespan(srv.app):
                pass
        assert srv._agent_status["error"] == "bad agent file"

    @pytest.mark.asyncio
    async def test_does_not_set_error_on_successful_load(self):
        srv = _get_server()
        srv._agent_status["error"] = "stale error"
        with (
            patch.object(srv, "_load_conversations"),
            patch.object(srv, "_load_prompts"),
            patch.object(srv, "_load_evals"),
            patch.object(srv, "_load_scenarios"),
            patch.object(srv, "_load_agent"),
        ):
            async with srv._lifespan(srv.app):
                pass
        # Error should not be overwritten on success — it stays as-is
        # because the lifespan only sets error in the except branch.
        # The _load_agent mock succeeds, so the print branch runs instead.
        assert srv._agent_status["error"] == "stale error"

    @pytest.mark.asyncio
    async def test_yields_control_to_application(self):
        """Verify the context manager yields (app runs between startup/shutdown)."""
        srv = _get_server()
        entered = False
        with (
            patch.object(srv, "_load_conversations"),
            patch.object(srv, "_load_prompts"),
            patch.object(srv, "_load_evals"),
            patch.object(srv, "_load_scenarios"),
            patch.object(srv, "_load_agent"),
        ):
            async with srv._lifespan(srv.app):
                entered = True
        assert entered is True
