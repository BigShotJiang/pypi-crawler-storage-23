"""Unit tests for the MockProvider in conftest.py."""

from __future__ import annotations

import pytest

from synth.providers.base import (
    ProviderDoneEvent,
    ProviderResponse,
    TextChunkEvent,
    ToolCallChunkEvent,
    ToolCallInfo,
)
from synth.types import TokenUsage

from tests.conftest import MockProvider, ProviderCallRecord


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_USAGE = TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15)


def _resp(text: str = "hello", tool_calls: list[ToolCallInfo] | None = None) -> ProviderResponse:
    return ProviderResponse(text=text, usage=_USAGE, tool_calls=tool_calls or [])


# ---------------------------------------------------------------------------
# Tests — complete()
# ---------------------------------------------------------------------------


class TestMockProviderComplete:
    """Tests for MockProvider.complete()."""

    @pytest.mark.asyncio
    async def test_default_response(self, mock_provider: MockProvider) -> None:
        resp = await mock_provider.complete([{"role": "user", "content": "hi"}])
        assert resp.text == "mock response"
        assert resp.usage.total_tokens == 30

    @pytest.mark.asyncio
    async def test_custom_responses_in_order(self) -> None:
        provider = MockProvider(responses=[_resp("first"), _resp("second")])
        r1 = await provider.complete([{"role": "user", "content": "a"}])
        r2 = await provider.complete([{"role": "user", "content": "b"}])
        assert r1.text == "first"
        assert r2.text == "second"

    @pytest.mark.asyncio
    async def test_responses_cycle(self) -> None:
        provider = MockProvider(responses=[_resp("only")])
        r1 = await provider.complete([{"role": "user", "content": "a"}])
        r2 = await provider.complete([{"role": "user", "content": "b"}])
        assert r1.text == "only"
        assert r2.text == "only"

    @pytest.mark.asyncio
    async def test_tool_call_simulation(self) -> None:
        tc = ToolCallInfo(id="tc_1", name="get_weather", args={"city": "Seattle"})
        provider = MockProvider(responses=[_resp("", tool_calls=[tc])])
        resp = await provider.complete([{"role": "user", "content": "weather?"}])
        assert len(resp.tool_calls) == 1
        assert resp.tool_calls[0].name == "get_weather"

    @pytest.mark.asyncio
    async def test_error_injection(self) -> None:
        provider = MockProvider(error=RuntimeError("rate limited"))
        with pytest.raises(RuntimeError, match="rate limited"):
            await provider.complete([{"role": "user", "content": "hi"}])

    @pytest.mark.asyncio
    async def test_call_history_recorded(self) -> None:
        provider = MockProvider()
        msgs = [{"role": "user", "content": "hello"}]
        tools = [{"name": "t", "parameters": {}}]
        await provider.complete(msgs, tools=tools, temperature=0.5)

        assert len(provider.call_history) == 1
        rec = provider.call_history[0]
        assert rec.method == "complete"
        assert rec.messages == msgs
        assert rec.tools == tools
        assert rec.kwargs == {"temperature": 0.5}

    @pytest.mark.asyncio
    async def test_error_still_records_call(self) -> None:
        provider = MockProvider(error=ValueError("boom"))
        with pytest.raises(ValueError):
            await provider.complete([{"role": "user", "content": "x"}])
        assert len(provider.call_history) == 1
        assert provider.call_history[0].method == "complete"


# ---------------------------------------------------------------------------
# Tests — stream()
# ---------------------------------------------------------------------------


class TestMockProviderStream:
    """Tests for MockProvider.stream()."""

    @pytest.mark.asyncio
    async def test_default_stream_events(self, mock_provider: MockProvider) -> None:
        events = [e async for e in mock_provider.stream([{"role": "user", "content": "hi"}])]
        assert len(events) == 2
        assert isinstance(events[0], TextChunkEvent)
        assert isinstance(events[1], ProviderDoneEvent)

    @pytest.mark.asyncio
    async def test_custom_stream_events(self) -> None:
        custom_events = [
            TextChunkEvent(text="chunk1"),
            TextChunkEvent(text="chunk2"),
            ProviderDoneEvent(usage=_USAGE),
        ]
        provider = MockProvider(stream_events=[custom_events])
        events = [e async for e in provider.stream([{"role": "user", "content": "go"}])]
        assert len(events) == 3
        assert events[0].text == "chunk1"  # type: ignore[union-attr]
        assert events[1].text == "chunk2"  # type: ignore[union-attr]

    @pytest.mark.asyncio
    async def test_stream_events_cycle(self) -> None:
        batch = [TextChunkEvent(text="a"), ProviderDoneEvent(usage=_USAGE)]
        provider = MockProvider(stream_events=[batch])
        e1 = [e async for e in provider.stream([{"role": "user", "content": "1"}])]
        e2 = [e async for e in provider.stream([{"role": "user", "content": "2"}])]
        assert len(e1) == len(e2) == 2

    @pytest.mark.asyncio
    async def test_stream_error_injection(self) -> None:
        provider = MockProvider(error=ConnectionError("timeout"))
        with pytest.raises(ConnectionError, match="timeout"):
            async for _ in provider.stream([{"role": "user", "content": "hi"}]):
                pass  # pragma: no cover

    @pytest.mark.asyncio
    async def test_stream_records_call_history(self) -> None:
        provider = MockProvider()
        msgs = [{"role": "user", "content": "stream me"}]
        _ = [e async for e in provider.stream(msgs, tools=None, max_tokens=100)]
        assert len(provider.call_history) == 1
        assert provider.call_history[0].method == "stream"

    @pytest.mark.asyncio
    async def test_stream_with_tool_call_events(self) -> None:
        events = [
            ToolCallChunkEvent(id="tc_1", name="search", args={"q": "test"}),
            ProviderDoneEvent(usage=_USAGE),
        ]
        provider = MockProvider(stream_events=[events])
        collected = [e async for e in provider.stream([{"role": "user", "content": "go"}])]
        assert isinstance(collected[0], ToolCallChunkEvent)
        assert collected[0].name == "search"
