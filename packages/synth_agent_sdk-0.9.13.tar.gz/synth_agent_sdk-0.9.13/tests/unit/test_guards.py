"""Unit tests for the guard system base layer.

Covers ``BaseGuard`` ABC enforcement, ``Guard`` factory methods, and
concrete guard stub instantiation.
"""

from __future__ import annotations

import pytest

from synth.guards.base import BaseGuard, Guard
from synth.guards.cost import CostGuard
from synth.guards.custom import CustomGuard
from synth.guards.pii import PIIGuard
from synth.guards.tool_filter import ToolFilterGuard
from synth.types import GuardContext, GuardResult


# ---------------------------------------------------------------------------
# BaseGuard ABC enforcement
# ---------------------------------------------------------------------------


class TestBaseGuard:
    """Tests for the BaseGuard abstract base class."""

    def test_cannot_instantiate_directly(self) -> None:
        """BaseGuard cannot be instantiated without implementing check()."""
        with pytest.raises(TypeError, match="check"):
            BaseGuard(name="test")  # type: ignore[abstract]

    def test_concrete_subclass_must_implement_check(self) -> None:
        """A subclass that does not implement check() cannot be instantiated."""

        class IncompleteGuard(BaseGuard):
            pass

        with pytest.raises(TypeError, match="check"):
            IncompleteGuard(name="incomplete")  # type: ignore[abstract]

    @pytest.mark.asyncio
    async def test_concrete_subclass_with_check_is_instantiable(self) -> None:
        """A subclass that implements check() can be instantiated and called."""

        class ValidGuard(BaseGuard):
            async def check(
                self, content: str, context: GuardContext
            ) -> GuardResult:
                return GuardResult(passed=True)

        guard = ValidGuard(name="valid")
        assert guard.name == "valid"

        ctx = GuardContext(cumulative_cost=0.0, tool_calls=[], run_id=None)
        result = await guard.check("hello", ctx)
        assert result.passed is True
        assert result.violation_message is None

    def test_name_attribute_stored(self) -> None:
        """The name passed to the constructor is stored on the instance."""

        class StubGuard(BaseGuard):
            async def check(
                self, content: str, context: GuardContext
            ) -> GuardResult:
                return GuardResult(passed=True)

        guard = StubGuard(name="my-guard")
        assert guard.name == "my-guard"


# ---------------------------------------------------------------------------
# Guard factory methods
# ---------------------------------------------------------------------------


class TestGuardFactory:
    """Tests for the Guard static factory methods."""

    def test_no_pii_output_returns_pii_guard(self) -> None:
        guard = Guard.no_pii_output()
        assert isinstance(guard, PIIGuard)
        assert isinstance(guard, BaseGuard)
        assert guard.name == "PIIGuard"

    def test_max_cost_returns_cost_guard(self) -> None:
        guard = Guard.max_cost(dollars=0.50)
        assert isinstance(guard, CostGuard)
        assert isinstance(guard, BaseGuard)
        assert guard.name == "CostGuard"
        assert guard.limit == 0.50

    def test_no_tool_calls_returns_tool_filter_guard(self) -> None:
        patterns = ["delete_*", "drop_*"]
        guard = Guard.no_tool_calls(patterns)
        assert isinstance(guard, ToolFilterGuard)
        assert isinstance(guard, BaseGuard)
        assert guard.name == "ToolFilterGuard"
        assert guard.patterns == patterns

    def test_custom_returns_custom_guard(self) -> None:
        fn = lambda content: True  # noqa: E731
        guard = Guard.custom(fn)
        assert isinstance(guard, CustomGuard)
        assert isinstance(guard, BaseGuard)
        assert guard.name == "CustomGuard"
        assert guard.fn is fn


# ---------------------------------------------------------------------------
# Concrete guard stubs — async check() returns passing result
# ---------------------------------------------------------------------------


class TestGuardStubs:
    """Verify that stub guard implementations are callable and return
    a passing ``GuardResult``."""

    @pytest.fixture()
    def context(self) -> GuardContext:
        return GuardContext(
            cumulative_cost=0.0, tool_calls=[], run_id=None
        )

    @pytest.mark.asyncio
    async def test_pii_guard_stub(self, context: GuardContext) -> None:
        guard = PIIGuard()
        result = await guard.check("some text", context)
        assert isinstance(result, GuardResult)
        assert result.passed is True

    @pytest.mark.asyncio
    async def test_cost_guard_stub(self, context: GuardContext) -> None:
        guard = CostGuard(limit=1.0)
        result = await guard.check("some text", context)
        assert isinstance(result, GuardResult)
        assert result.passed is True

    @pytest.mark.asyncio
    async def test_tool_filter_guard_stub(
        self, context: GuardContext
    ) -> None:
        guard = ToolFilterGuard(patterns=["delete_*"])
        result = await guard.check("some text", context)
        assert isinstance(result, GuardResult)
        assert result.passed is True

    @pytest.mark.asyncio
    async def test_custom_guard_stub(self, context: GuardContext) -> None:
        guard = CustomGuard(fn=lambda c: True)
        result = await guard.check("some text", context)
        assert isinstance(result, GuardResult)
        assert result.passed is True


# ---------------------------------------------------------------------------
# PIIGuard — real detection
# ---------------------------------------------------------------------------


class TestPIIGuard:
    """Tests for PIIGuard regex-based PII detection."""

    @pytest.fixture()
    def guard(self) -> PIIGuard:
        return PIIGuard()

    @pytest.fixture()
    def context(self) -> GuardContext:
        return GuardContext(cumulative_cost=0.0, tool_calls=[], run_id=None)

    @pytest.mark.asyncio
    async def test_detects_email(
        self, guard: PIIGuard, context: GuardContext
    ) -> None:
        result = await guard.check("Contact user@example.com", context)
        assert result.passed is False
        assert result.violation_message is not None
        assert "email" in result.violation_message

    @pytest.mark.asyncio
    async def test_detects_phone_dashes(
        self, guard: PIIGuard, context: GuardContext
    ) -> None:
        result = await guard.check("Call 555-123-4567", context)
        assert result.passed is False
        assert "phone" in result.violation_message  # type: ignore[operator]

    @pytest.mark.asyncio
    async def test_detects_phone_parens(
        self, guard: PIIGuard, context: GuardContext
    ) -> None:
        result = await guard.check("Call (555) 123-4567", context)
        assert result.passed is False
        assert "phone" in result.violation_message  # type: ignore[operator]

    @pytest.mark.asyncio
    async def test_detects_ssn(
        self, guard: PIIGuard, context: GuardContext
    ) -> None:
        result = await guard.check("SSN: 123-45-6789", context)
        assert result.passed is False
        assert "SSN" in result.violation_message  # type: ignore[operator]

    @pytest.mark.asyncio
    async def test_passes_clean_text(
        self, guard: PIIGuard, context: GuardContext
    ) -> None:
        result = await guard.check(
            "The weather is nice today.", context
        )
        assert result.passed is True
        assert result.violation_message is None

    @pytest.mark.asyncio
    async def test_passes_empty_string(
        self, guard: PIIGuard, context: GuardContext
    ) -> None:
        result = await guard.check("", context)
        assert result.passed is True


# ---------------------------------------------------------------------------
# CostGuard — real cost checking
# ---------------------------------------------------------------------------


class TestCostGuard:
    """Tests for CostGuard cumulative cost enforcement."""

    @pytest.mark.asyncio
    async def test_fails_when_cost_exceeds_limit(self) -> None:
        guard = CostGuard(limit=0.10)
        ctx = GuardContext(
            cumulative_cost=0.15, tool_calls=[], run_id=None
        )
        result = await guard.check("any text", ctx)
        assert result.passed is False
        assert result.violation_message is not None
        assert "0.15" in result.violation_message
        assert "0.10" in result.violation_message

    @pytest.mark.asyncio
    async def test_passes_when_under_limit(self) -> None:
        guard = CostGuard(limit=1.00)
        ctx = GuardContext(
            cumulative_cost=0.05, tool_calls=[], run_id=None
        )
        result = await guard.check("any text", ctx)
        assert result.passed is True
        assert result.violation_message is None

    @pytest.mark.asyncio
    async def test_passes_when_exactly_at_limit(self) -> None:
        guard = CostGuard(limit=0.50)
        ctx = GuardContext(
            cumulative_cost=0.50, tool_calls=[], run_id=None
        )
        result = await guard.check("any text", ctx)
        assert result.passed is True

    @pytest.mark.asyncio
    async def test_fails_when_just_over_limit(self) -> None:
        guard = CostGuard(limit=0.50)
        ctx = GuardContext(
            cumulative_cost=0.5001, tool_calls=[], run_id=None
        )
        result = await guard.check("any text", ctx)
        assert result.passed is False


# ---------------------------------------------------------------------------
# ToolFilterGuard — real fnmatch filtering
# ---------------------------------------------------------------------------


class TestToolFilterGuard:
    """Tests for ToolFilterGuard glob-based tool call blocking."""

    @pytest.mark.asyncio
    async def test_blocks_matching_tool(self) -> None:
        guard = ToolFilterGuard(patterns=["delete_*"])
        ctx = GuardContext(
            cumulative_cost=0.0,
            tool_calls=["delete_user"],
            run_id=None,
        )
        result = await guard.check("", ctx)
        assert result.passed is False
        assert "delete_user" in result.violation_message  # type: ignore[operator]
        assert "delete_*" in result.violation_message  # type: ignore[operator]

    @pytest.mark.asyncio
    async def test_passes_non_matching_tool(self) -> None:
        guard = ToolFilterGuard(patterns=["delete_*"])
        ctx = GuardContext(
            cumulative_cost=0.0,
            tool_calls=["get_user"],
            run_id=None,
        )
        result = await guard.check("", ctx)
        assert result.passed is True

    @pytest.mark.asyncio
    async def test_blocks_on_any_matching_pattern(self) -> None:
        guard = ToolFilterGuard(patterns=["delete_*", "drop_*"])
        ctx = GuardContext(
            cumulative_cost=0.0,
            tool_calls=["drop_table"],
            run_id=None,
        )
        result = await guard.check("", ctx)
        assert result.passed is False
        assert "drop_table" in result.violation_message  # type: ignore[operator]

    @pytest.mark.asyncio
    async def test_passes_empty_tool_calls(self) -> None:
        guard = ToolFilterGuard(patterns=["delete_*"])
        ctx = GuardContext(
            cumulative_cost=0.0, tool_calls=[], run_id=None
        )
        result = await guard.check("", ctx)
        assert result.passed is True

    @pytest.mark.asyncio
    async def test_blocks_first_matching_tool_in_list(self) -> None:
        guard = ToolFilterGuard(patterns=["rm_*"])
        ctx = GuardContext(
            cumulative_cost=0.0,
            tool_calls=["get_data", "rm_file", "list_items"],
            run_id=None,
        )
        result = await guard.check("", ctx)
        assert result.passed is False
        assert "rm_file" in result.violation_message  # type: ignore[operator]


# ---------------------------------------------------------------------------
# CustomGuard — real function invocation
# ---------------------------------------------------------------------------


class TestCustomGuard:
    """Tests for CustomGuard user-function delegation."""

    @pytest.fixture()
    def context(self) -> GuardContext:
        return GuardContext(cumulative_cost=0.0, tool_calls=[], run_id=None)

    @pytest.mark.asyncio
    async def test_passes_when_fn_returns_true(
        self, context: GuardContext
    ) -> None:
        guard = CustomGuard(fn=lambda c: True)
        result = await guard.check("hello", context)
        assert result.passed is True

    @pytest.mark.asyncio
    async def test_fails_when_fn_returns_false(
        self, context: GuardContext
    ) -> None:
        guard = CustomGuard(fn=lambda c: False)
        result = await guard.check("hello", context)
        assert result.passed is False
        assert result.violation_message is not None
        assert "Custom guard check failed" in result.violation_message

    @pytest.mark.asyncio
    async def test_fails_when_fn_raises_exception(
        self, context: GuardContext
    ) -> None:
        def bad_fn(content: str) -> bool:
            raise ValueError("something broke")

        guard = CustomGuard(fn=bad_fn)
        result = await guard.check("hello", context)
        assert result.passed is False
        assert result.violation_message is not None
        assert "something broke" in result.violation_message

    @pytest.mark.asyncio
    async def test_fn_receives_content(
        self, context: GuardContext
    ) -> None:
        received: list[str] = []

        def capture_fn(content: str) -> bool:
            received.append(content)
            return True

        guard = CustomGuard(fn=capture_fn)
        await guard.check("test input", context)
        assert received == ["test input"]


# ---------------------------------------------------------------------------
# Guard evaluation pipeline in Agent — Task 7.3
# ---------------------------------------------------------------------------

from unittest.mock import AsyncMock, patch

from synth.agent import Agent
from synth.errors import CostLimitError, GuardViolationError
from synth.guards.cost import CostGuard
from synth.providers.base import ProviderResponse, ToolCallInfo
from synth.types import RunResult, TokenUsage
from tests.conftest import MockProvider


def _patch_router(mock_provider: MockProvider | None = None):
    """Return a patch that makes ``ProviderRouter.resolve`` return a MockProvider."""
    provider = mock_provider or MockProvider()
    return patch(
        "synth.agent.ProviderRouter.resolve",
        return_value=provider,
    )


class TestGuardEvaluationPipeline:
    """Tests for guard evaluation wired into Agent.arun().

    Validates Requirement 12.6: guards evaluated in declaration order,
    first violation stops evaluation.
    """

    @pytest.mark.asyncio
    async def test_guards_evaluated_in_order(self) -> None:
        """All guards are called in declaration order when all pass."""
        call_order: list[str] = []

        class TrackingGuard(BaseGuard):
            async def check(self, content, context):
                call_order.append(self.name)
                return GuardResult(passed=True)

        guards = [
            TrackingGuard(name="first"),
            TrackingGuard(name="second"),
            TrackingGuard(name="third"),
        ]

        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(model="claude-sonnet-4-5", guards=guards)
            await agent.arun("hello")

        # Input guards + output guards = each guard called twice
        assert call_order == [
            "first", "second", "third",  # input
            "first", "second", "third",  # output
        ]

    @pytest.mark.asyncio
    async def test_first_violation_stops_evaluation(self) -> None:
        """When a guard fails, subsequent guards are not evaluated."""
        call_order: list[str] = []

        class PassGuard(BaseGuard):
            async def check(self, content, context):
                call_order.append(self.name)
                return GuardResult(passed=True)

        class FailGuard(BaseGuard):
            async def check(self, content, context):
                call_order.append(self.name)
                return GuardResult(
                    passed=False, violation_message="blocked"
                )

        guards = [
            PassGuard(name="pass1"),
            FailGuard(name="fail"),
            PassGuard(name="pass2"),
        ]

        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(model="claude-sonnet-4-5", guards=guards)
            with pytest.raises(GuardViolationError):
                await agent.arun("hello")

        # Input guards: pass1 evaluated, fail evaluated, pass2 skipped
        assert call_order == ["pass1", "fail"]

    @pytest.mark.asyncio
    async def test_guard_violation_error_has_correct_fields(self) -> None:
        """GuardViolationError contains guard_name, violating_content, remediation."""

        class FailGuard(BaseGuard):
            async def check(self, content, context):
                return GuardResult(
                    passed=False, violation_message="bad content detected"
                )

        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(
                model="claude-sonnet-4-5",
                guards=[FailGuard(name="MyGuard")],
            )
            with pytest.raises(GuardViolationError) as exc_info:
                await agent.arun("test prompt")

        err = exc_info.value
        assert err.guard_name == "MyGuard"
        assert err.violating_content == "test prompt"
        assert err.remediation == "bad content detected"
        assert err.component == "MyGuard"
        assert "bad content detected" in str(err)

    @pytest.mark.asyncio
    async def test_cost_limit_error_raised_for_cost_guard(self) -> None:
        """CostGuard violations raise CostLimitError (subclass of GuardViolationError)."""
        guard = CostGuard(limit=0.05)

        # The cost guard checks context.cumulative_cost, which is 0.0 for
        # input guards. Wire it as an output guard by making it pass on input
        # (cost=0.0 < 0.05) but we need to test the CostLimitError path.
        # Use _evaluate_guards directly with high cost.
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(model="claude-sonnet-4-5", guards=[guard])

            with pytest.raises(CostLimitError) as exc_info:
                await agent._evaluate_guards(
                    "some text",
                    tool_call_names=[],
                    cumulative_cost=0.10,
                )

        err = exc_info.value
        assert isinstance(err, GuardViolationError)
        assert err.guard_name == "CostGuard"
        assert err.component == "CostGuard"

    @pytest.mark.asyncio
    async def test_no_error_when_all_guards_pass(self) -> None:
        """No exception raised when every guard passes."""

        class PassGuard(BaseGuard):
            async def check(self, content, context):
                return GuardResult(passed=True)

        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(
                model="claude-sonnet-4-5",
                guards=[PassGuard(name="g1"), PassGuard(name="g2")],
            )
            result = await agent.arun("hello")

        assert isinstance(result, RunResult)
        assert result.text == "mock response"

    @pytest.mark.asyncio
    async def test_input_guards_run_before_provider_call(self) -> None:
        """Input guards that fail prevent the provider from being called."""
        class FailGuard(BaseGuard):
            async def check(self, content, context):
                return GuardResult(
                    passed=False, violation_message="input blocked"
                )

        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(
                model="claude-sonnet-4-5",
                guards=[FailGuard(name="InputBlocker")],
            )
            with pytest.raises(GuardViolationError, match="input blocked"):
                await agent.arun("bad input")

        # Provider should never have been called
        assert len(provider.call_history) == 0

    @pytest.mark.asyncio
    async def test_output_guards_run_after_response(self) -> None:
        """Output guards inspect the provider's response text."""
        checked_contents: list[str] = []

        class RecordGuard(BaseGuard):
            async def check(self, content, context):
                checked_contents.append(content)
                return GuardResult(passed=True)

        response = ProviderResponse(
            text="response with data",
            usage=TokenUsage(
                input_tokens=5, output_tokens=10, total_tokens=15,
            ),
        )
        provider = MockProvider(responses=[response])
        with _patch_router(provider):
            agent = Agent(
                model="claude-sonnet-4-5",
                guards=[RecordGuard(name="recorder")],
            )
            await agent.arun("my prompt")

        # Guard called twice: once for input (prompt), once for output (response)
        assert checked_contents == ["my prompt", "response with data"]

    @pytest.mark.asyncio
    async def test_output_guard_receives_tool_call_names(self) -> None:
        """Output guard context includes names of tools called during the run."""
        captured_contexts: list[GuardContext] = []

        class ContextCapture(BaseGuard):
            async def check(self, content, context):
                captured_contexts.append(context)
                return GuardResult(passed=True)

        # Set up provider that requests a tool call then returns final text
        tool_response = ProviderResponse(
            text="",
            usage=TokenUsage(
                input_tokens=5, output_tokens=5, total_tokens=10,
            ),
            tool_calls=[
                ToolCallInfo(id="tc_1", name="greet", args={"name": "World"}),
            ],
        )
        final_response = ProviderResponse(
            text="done",
            usage=TokenUsage(
                input_tokens=5, output_tokens=5, total_tokens=10,
            ),
        )
        provider = MockProvider(responses=[tool_response, final_response])

        from synth.tools.decorator import tool as tool_decorator

        @tool_decorator
        def greet(name: str) -> str:
            """Greet someone."""
            return f"Hi {name}"

        with _patch_router(provider):
            agent = Agent(
                model="claude-sonnet-4-5",
                tools=[greet],
                guards=[ContextCapture(name="ctx_cap")],
            )
            await agent.arun("say hi")

        # Input guard context: no tool calls yet
        assert captured_contexts[0].tool_calls == []
        # Output guard context: greet was called
        assert captured_contexts[1].tool_calls == ["greet"]

    @pytest.mark.asyncio
    async def test_output_guard_violation_after_successful_provider_call(
        self,
    ) -> None:
        """An output guard violation raises even after a successful provider call."""
        call_count = 0

        class OutputFailGuard(BaseGuard):
            """Passes on first check (input), fails on second (output)."""
            async def check(self, content, context):
                nonlocal call_count
                call_count += 1
                if call_count == 1:
                    return GuardResult(passed=True)
                return GuardResult(
                    passed=False,
                    violation_message="output rejected",
                )

        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(
                model="claude-sonnet-4-5",
                guards=[OutputFailGuard(name="OutputBlocker")],
            )
            with pytest.raises(GuardViolationError, match="output rejected"):
                await agent.arun("hi")

        # Provider was called (input guard passed)
        assert len(provider.call_history) == 1

    @pytest.mark.asyncio
    async def test_violating_content_truncated_to_100_chars(self) -> None:
        """violating_content is truncated to first 100 characters."""
        long_content = "x" * 200

        class FailGuard(BaseGuard):
            async def check(self, content, context):
                return GuardResult(
                    passed=False, violation_message="too long"
                )

        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(
                model="claude-sonnet-4-5",
                guards=[FailGuard(name="trunc")],
            )
            with pytest.raises(GuardViolationError) as exc_info:
                await agent.arun(long_content)

        assert len(exc_info.value.violating_content) == 100

    @pytest.mark.asyncio
    async def test_no_guards_skips_evaluation(self) -> None:
        """Agent with no guards runs without guard-related errors."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(model="claude-sonnet-4-5", guards=[])
            result = await agent.arun("hello")

        assert isinstance(result, RunResult)
        assert len(provider.call_history) == 1
