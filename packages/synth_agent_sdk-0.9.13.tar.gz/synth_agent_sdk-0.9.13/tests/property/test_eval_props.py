"""Property-based tests for the evaluation framework.

**Property 26: Eval scoring correctness**
**Validates: Requirements 11.2, 11.3, 11.4**

**Property 27: Eval comparison identifies regressions and improvements**
**Validates: Requirements 11.5**
"""

from __future__ import annotations

from hypothesis import given, settings
from hypothesis import strategies as st

from synth.eval.report import EvalCaseResult, EvalComparison, EvalReport
from synth.eval.scorers import CustomScorer, ExactMatchScorer


# ---------------------------------------------------------------------------
# Property 26: Eval scoring correctness
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    output=st.text(min_size=1, max_size=30),
    expected=st.text(min_size=1, max_size=30),
)
def test_eval_scoring_exact_match(output: str, expected: str):
    """Property 26: Eval scoring correctness — exact match.

    For any set of eval cases with string expected values, exact matches
    should score 1.0 and non-matches should score 0.0.

    **Validates: Requirements 11.2, 11.3, 11.4**
    """
    scorer = ExactMatchScorer()
    score = scorer.score(output, expected)

    if output.strip() == expected.strip():
        assert score == 1.0
    else:
        assert score == 0.0


@settings(max_examples=100)
@given(
    output=st.text(min_size=1, max_size=30),
    expected=st.text(min_size=1, max_size=30),
    custom_score=st.floats(min_value=0.0, max_value=1.0),
)
def test_eval_scoring_custom_checker(
    output: str, expected: str, custom_score: float,
):
    """Property 26: When a custom checker is provided, the eval should
    use that function's return value as the score.

    **Validates: Requirements 11.2, 11.3, 11.4**
    """
    scorer = CustomScorer(lambda o, e: custom_score)
    score = scorer.score(output, expected)
    assert score == custom_score


# ---------------------------------------------------------------------------
# Property 27: Eval comparison identifies regressions and improvements
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    n_cases=st.integers(min_value=1, max_value=10),
    data=st.data(),
)
def test_eval_comparison_identifies_regressions_and_improvements(
    n_cases: int, data,
):
    """Property 27: Eval comparison identifies regressions and improvements.

    For any two EvalReport objects, compare() should correctly classify
    each case as regression, improvement, or unchanged, and the counts
    should sum to the total number of cases.

    **Validates: Requirements 11.5**
    """
    baseline_cases = []
    current_cases = []

    for i in range(n_cases):
        input_text = f"case_{i}"
        base_score = data.draw(
            st.floats(min_value=0.0, max_value=1.0), label=f"base_{i}",
        )
        curr_score = data.draw(
            st.floats(min_value=0.0, max_value=1.0), label=f"curr_{i}",
        )

        baseline_cases.append(EvalCaseResult(
            input=input_text, expected="x", actual="y",
            score=base_score, passed=base_score >= 0.5,
            latency_ms=1.0, cost=0.0,
        ))
        current_cases.append(EvalCaseResult(
            input=input_text, expected="x", actual="y",
            score=curr_score, passed=curr_score >= 0.5,
            latency_ms=1.0, cost=0.0,
        ))

    baseline = EvalReport(cases=baseline_cases, overall_score=0.5)
    current = EvalReport(cases=current_cases, overall_score=0.5)

    comparison = current.compare(baseline)

    # Counts must sum to total
    total = (
        len(comparison.regressions)
        + len(comparison.improvements)
        + len(comparison.unchanged)
    )
    assert total == n_cases
