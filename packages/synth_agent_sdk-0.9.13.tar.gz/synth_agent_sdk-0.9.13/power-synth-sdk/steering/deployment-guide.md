# Deployment and Operations Guide

## CLI Reference

### synth init

Interactive project setup — walks through provider selection, feature toggles, and generates a complete project:

```bash
synth init
```

Generates: `agent.py`, `tools.py` (optional), `synth.toml`, `eval_dataset.json` (optional), `eval_config.json` (AgentCore + eval), `README.md`.

### synth create

Scaffold specific project types:

```bash
synth create agent my-bot              # Interactive provider selection
synth create agent my-bot -p openai    # Skip prompt, use OpenAI
synth create team my-team              # Multi-agent team + pipeline
synth create tool my-tools             # Standalone tools file
synth create mcp my-server             # MCP server with FastMCP
synth create ui my-ui                  # Local browser-based testing UI
```

Provider options for `synth create agent`: anthropic, openai, llama, gemini, agentcore.

AgentCore scaffolding includes `.env.template`, deployment handler, and deploy instructions.

### synth dev

Start a rich terminal UI for interactive agent development:

```bash
synth dev my_agent.py
```

Features:
- Fallout-inspired terminal interface with ASCII art header
- Streaming token-by-token response rendering (green text typing effect)
- Tool call visualization with lightning bolt icons, args, results, and latency
- Slash commands: `/tools`, `/reload`, `/trace`, `/export`, `/clear`, `/model`, `/cost`, `/help`, `/quit`
- Markdown rendering for agent responses via `rich`
- Persistent status bar showing model, turn count, total tokens, cumulative cost
- Multi-line input support (backslash continuation)
- Command history with up/down arrows via `prompt_toolkit`
- Hot-reload with `/reload` to pick up agent changes without restarting

Suppress the boot sequence: `SYNTH_NO_BANNER=1 synth dev my_agent.py`

### synth run

Execute an agent with a prompt and print the result:

```bash
synth run my_agent.py "What is the capital of France?"
```

Prints the RunResult text and a trace summary to stdout.

### synth bench

Benchmark agent performance over multiple runs:

```bash
synth bench my_agent.py "Hello" --runs 20 --warmup 2
```

Reports:
- Latency percentiles: p50, p95, p99, avg, min, max
- Token usage: average per run, total
- Cost: per run, total
- Reliability: success rate, error count

### synth eval

Run an evaluation suite against your agent:

```bash
synth eval my_agent.py --dataset cases.json
```

- Runs each case against the live agent
- Prints pass/fail report with summary score
- Exits non-zero if pass rate falls below threshold

### synth trace

Open a stored trace in the browser:

```bash
synth trace <run_id>
```

### synth deploy

Package and deploy to AWS AgentCore:

```bash
# Deploy
synth deploy --target agentcore my_agent.py

# Dry run (validate without deploying)
synth deploy --target agentcore --dry-run my_agent.py
```

Requires `pip install synth-agent-sdk[agentcore]`.

### synth doctor

Check environment, credentials, and dependencies:

```bash
synth doctor
```

Reports issues with fix instructions for:
- Missing environment variables
- Invalid provider credentials
- Missing or outdated dependencies

### synth help

Show a curated getting-started guide with common workflows, provider table, and environment variable reference:

```bash
synth help
```

## AWS AgentCore Deployment

### Prerequisites

```bash
pip install synth-agent-sdk[agentcore]
```

This installs `boto3` for AWS Bedrock Runtime access.

### Wrapping an Agent

Use the `@agentcore_handler` decorator to make your agent AgentCore-compatible:

```python
from synth import Agent, tool
from synth.deploy.agentcore import agentcore_handler

@tool
def lookup_order(order_id: str) -> dict:
    """Look up an order by ID."""
    return {"order_id": order_id, "status": "shipped"}

agent = Agent(
    model="bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0",
    instructions="You are a customer service agent.",
    tools=[lookup_order],
)

handler = agentcore_handler(agent)
```

### Wrapping a Graph

```python
from synth import Graph
from synth.deploy.agentcore import agentcore_handler

graph = Graph(state_schema=MyState)
# ... define nodes and edges ...

handler = agentcore_handler(graph)
```

### What the Handler Does

The `AgentCoreAdapter` behind the decorator:
1. Translates AgentCore invocation payloads into Synth's `run()` input format
2. Executes the agent or graph
3. Translates the RunResult back into AgentCore's response format
4. Uses runtime-provided IAM credentials (no static AWS keys needed)
5. Routes memory operations to AgentCore's managed memory when available
6. Forwards traces to AgentCore's observability infrastructure

### Agent Manifest

The deploy command generates an agent manifest declaring:
- Agent name and description
- Supported actions
- Required IAM permissions (least-privilege)

### Deployment Flow

```bash
# 1. Validate configuration
synth deploy --target agentcore --dry-run

# 2. Deploy
synth deploy --target agentcore
```

The packager bundles code and dependencies but excludes:
- `.env` files
- Credential files
- `.synth/checkpoints/` directories

### Bedrock Provider for AgentCore

When deployed to AgentCore, use the Bedrock provider since the runtime provides IAM credentials automatically:

```python
agent = Agent(
    model="bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0",
    instructions="...",
)
```

The Bedrock provider uses `boto3` with AWS credential auth — no API keys needed in AgentCore.

**Blank content handling:** The Bedrock Converse API rejects empty text content blocks. The provider automatically sanitizes all message content via `_sanitize_text()`, replacing blank or whitespace-only strings with `"(no content)"`. This prevents `ValidationException` errors when tools (e.g., web search) return empty results.

### Checkpointing in AgentCore

When deployed to AgentCore with graph-based orchestration, the SDK uses AgentCore's managed state persistence instead of local disk or self-managed Redis:

```python
graph.with_checkpointing()  # Automatically uses AgentCore storage when deployed
```

## Tracing and Observability

### AgentCore Evaluations

When using `synth init` with the AgentCore provider and "eval" feature enabled, the wizard generates evaluation configuration:

**Generated files:**
- `eval_config.json` — Online evaluation config with three built-in evaluators and 1.0 sampling rate
- `agentcore.yaml` — Updated with `evaluations:` section and evaluation IAM permissions
- `eval_dataset.json` — Local evaluation dataset (generated for all providers)

**Built-in evaluators:**
- `Builtin.Helpfulness` (TRACE level)
- `Builtin.Correctness` (TRACE level)
- `Builtin.GoalSuccessRate` (SESSION level)

**Dashboard integration:**
The AgentCore tab in the testing dashboard shows an Evaluations sub-section when configured:
- Evaluator score summary table (scores below 0.5 flagged in red)
- Online evaluation config status (active/disabled, sampling rate, evaluator list)
- "Run Evaluation" button for on-demand evaluation

**API endpoints:**
- `GET /api/agentcore/evaluations` — fetch evaluation scores
- `POST /api/agentcore/evaluations/run` — trigger on-demand evaluation
- `GET /api/agentcore/evaluations/config` — get evaluation config status

All evaluation endpoints apply credential scrubbing via `_scrub_credentials()` and `_scrub_dict()`.

### Automatic Tracing

Every `run()` and `stream()` call produces a trace:

```python
result = agent.run("Hello")
trace = result.trace

trace.total_tokens      # Total token count
trace.total_cost        # Total cost in USD
trace.total_latency_ms  # Total wall-clock time
trace.spans             # list[TraceSpan]
```

### TraceSpan

Each span records a discrete operation:

```python
for span in trace.spans:
    print(f"{span.type}: {span.name}")
    print(f"  Duration: {span.end_time - span.start_time}")
    print(f"  Metadata: {span.metadata}")
```

Span types: `llm_call`, `tool_call`, `guard_check`, `node_execution`

### Viewing Traces

```python
# Open in browser as HTML timeline
result.trace.show()

# Export as OpenTelemetry JSON
result.trace.export("trace.json")
```

### Auto-Forwarding

Set `SYNTH_TRACE_ENDPOINT` to automatically forward all traces:

```bash
export SYNTH_TRACE_ENDPOINT=https://otel-collector.example.com/v1/traces
```

### Third-Party Integrations

One-line configuration for:
- Langfuse
- Datadog
- Honeycomb

Traces are transformed into provider-specific formats automatically.

## Checkpointing

### Local Disk (Default)

Stores JSON files in `.synth/checkpoints/{run_id}/`:

```python
from synth.checkpointing import LocalCheckpointStore

graph.with_checkpointing(store=LocalCheckpointStore())
```

Uses atomic writes (write-to-temp-then-rename) for safety.

### Redis

For distributed environments:

```python
from synth.checkpointing import RedisCheckpointStore

graph.with_checkpointing(
    store=RedisCheckpointStore("redis://localhost:6379")
)
```

Uses Redis transactions for atomicity. Supports TLS and authentication.

### Resuming Runs

```python
# Start a run with an ID
result = graph.run(state, run_id="workflow-abc")

# If interrupted, resume later (even from a different process)
result = graph.resume("workflow-abc")

# If no checkpoint exists
# Raises RunNotFoundError
```

## Coding Conventions (Quick Reference)

When contributing to the SDK:

- Python 3.10+, `from __future__ import annotations` in every module
- Module-level docstring in every file
- `PascalCase` classes, `snake_case` functions, `UPPER_SNAKE_CASE` constants
- All public functions fully type-annotated
- `@dataclass` for internal types, Pydantic `BaseModel` for user-facing schemas
- Async-first: `arun`/`astream` are primary, sync wrappers via `_compat.run_sync()`
- All errors inherit from `SynthError` with `component` and `suggestion`
- Provider SDKs lazily imported with friendly `SynthConfigError` on missing package
- 90%+ test coverage, pytest runner, `@pytest.mark.asyncio` for async tests
