"""BedrockProvider — AWS Bedrock Runtime model adapter.

Routes requests through the AWS Bedrock Runtime API using ``boto3``.
Supports both short-form model IDs (``bedrock/claude-sonnet-4-5``) and
full ARN-style identifiers
(``bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0``).

AWS credentials are resolved from the environment (IAM role, env vars,
or AWS config) — no Synth-specific API key is required.
"""

from __future__ import annotations

import json
from collections.abc import AsyncGenerator
from typing import Any

from synth.errors import SynthConfigError
from synth.providers.base import (
    BaseProvider,
    ProviderDoneEvent,
    ProviderErrorEvent,
    ProviderEvent,
    ProviderResponse,
    TextChunkEvent,
    ToolCallChunkEvent,
    ToolCallInfo,
)
from synth.types import Message, TokenUsage

try:
    import boto3
except ImportError:
    boto3 = None  # type: ignore[assignment]


class BedrockProvider(BaseProvider):
    """LLM provider adapter for AWS Bedrock Runtime.

    Parameters
    ----------
    model:
        Model identifier, e.g. ``"bedrock/claude-sonnet-4-5"`` or
        ``"bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0"``.
        The ``bedrock/`` prefix is stripped before calling the API.
    base_url:
        Optional custom Bedrock endpoint URL.
    **kwargs:
        Extra options forwarded to the ``boto3`` client constructor
        (e.g. ``region_name``).
    """

    def __init__(self, model: str, base_url: str | None = None, **kwargs: Any) -> None:
        if boto3 is None:
            raise SynthConfigError(
                message="Provider package 'boto3' is not installed. "
                "Run: pip install synth-agent-sdk[bedrock]",
                component="BedrockProvider",
                suggestion="pip install synth-agent-sdk[bedrock]",
            )

        # Strip the "bedrock/" prefix for the actual model ID
        self._model_id = model.removeprefix("bedrock/")

        client_kwargs: dict[str, Any] = {}
        if base_url is not None:
            client_kwargs["endpoint_url"] = base_url
        if "region_name" in kwargs:
            client_kwargs["region_name"] = kwargs.pop("region_name")

        self._client = boto3.client("bedrock-runtime", **client_kwargs)

    # -----------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------

    @staticmethod
    def _sanitize_text(text: str | None) -> str:
        """Ensure text content is non-empty for the Bedrock Converse API.

        The Bedrock Converse API rejects any ``ContentBlock`` where the
        ``text`` field is blank.  This helper coalesces empty or ``None``
        values to a safe placeholder.
        """
        if not text or not text.strip():
            return "(no content)"
        return text

    def _build_messages(
        self, messages: list[Message]
    ) -> tuple[list[dict[str, Any]] | None, list[dict[str, Any]]]:
        """Split messages into system prompts and Bedrock Converse message list.

        Translates the SDK's generic message format into the Bedrock
        Converse API format.  Key translations:

        - ``role: "system"`` → extracted as the ``system`` parameter
        - ``role: "tool"`` → ``role: "user"`` with ``toolResult``
          content blocks (Bedrock does not accept ``role: "tool"``)
        - ``role: "assistant"`` preceding tool results → injected
          ``toolUse`` content blocks so the conversation is valid

        Consecutive tool results are merged into a single ``user``
        message, and their preceding assistant messages are merged
        into a single ``assistant`` message with ``toolUse`` blocks.
        """
        import uuid

        system: list[dict[str, Any]] | None = None
        api_messages: list[dict[str, Any]] = []

        # First pass: pair up assistant + tool messages and assign
        # synthetic tool-use IDs so Bedrock can correlate them.
        i = 0
        while i < len(messages):
            msg = messages[i]

            if msg["role"] == "system":
                system = [{"text": self._sanitize_text(msg["content"])}]
                i += 1
                continue

            if msg["role"] == "tool":
                # Collect consecutive tool results
                tool_use_blocks: list[dict[str, Any]] = []
                tool_result_blocks: list[dict[str, Any]] = []

                while i < len(messages) and messages[i]["role"] == "tool":
                    tool_id = f"tool_{uuid.uuid4().hex[:12]}"
                    tool_name = messages[i].get("tool_name", "tool_call")
                    tool_use_blocks.append({
                        "toolUse": {
                            "toolUseId": tool_id,
                            "name": tool_name,
                            "input": {},
                        }
                    })
                    tool_result_blocks.append({
                        "toolResult": {
                            "toolUseId": tool_id,
                            "content": [
                                {"text": self._sanitize_text(
                                    messages[i]["content"]
                                )},
                            ],
                        }
                    })
                    i += 1

                # If the previous api_message is an assistant with only
                # text, replace it with one that includes toolUse blocks
                if api_messages and api_messages[-1]["role"] == "assistant":
                    prev = api_messages[-1]
                    prev["content"] = prev["content"] + tool_use_blocks
                else:
                    # No preceding assistant message — inject one
                    api_messages.append({
                        "role": "assistant",
                        "content": tool_use_blocks,
                    })

                api_messages.append({
                    "role": "user",
                    "content": tool_result_blocks,
                })
                continue

            # Regular user or assistant message
            api_messages.append({
                "role": msg["role"],
                "content": [{"text": self._sanitize_text(msg["content"])}],
            })
            i += 1

        # Bedrock requires alternating user/assistant roles.  Merge
        # consecutive messages with the same role.
        api_messages = self._merge_consecutive_roles(api_messages)

        return system, api_messages

    @staticmethod
    def _merge_consecutive_roles(
        messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Merge consecutive messages with the same role.

        Bedrock Converse API requires strictly alternating
        user/assistant roles.  This merges adjacent same-role
        messages by combining their content blocks.
        """
        if not messages:
            return messages

        merged: list[dict[str, Any]] = [messages[0]]
        for msg in messages[1:]:
            if msg["role"] == merged[-1]["role"]:
                merged[-1]["content"].extend(msg["content"])
            else:
                merged.append(msg)
        return merged

    def _build_tool_config(
        self, tools: list[dict[str, Any]] | None
    ) -> dict[str, Any] | None:
        """Convert Synth tool schemas to Bedrock toolConfiguration format."""
        if not tools:
            return None
        tool_specs = []
        for t in tools:
            tool_specs.append({
                "toolSpec": {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "inputSchema": {
                        "json": t.get("parameters", {}),
                    },
                }
            })
        return {"tools": tool_specs}

    # -----------------------------------------------------------------
    # BaseProvider interface
    # -----------------------------------------------------------------

    async def complete(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> ProviderResponse:
        """Send a completion request to the AWS Bedrock Runtime Converse API.

        Uses the synchronous ``boto3`` client wrapped in an executor to
        avoid blocking the event loop.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Extra options (``temperature``, ``maxTokens``, etc.).
        """
        import asyncio

        system, api_messages = self._build_messages(messages)
        api_kwargs: dict[str, Any] = {
            "modelId": self._model_id,
            "messages": api_messages,
        }
        if system is not None:
            api_kwargs["system"] = system

        tool_config = self._build_tool_config(tools)
        if tool_config is not None:
            api_kwargs["toolConfig"] = tool_config

        if kwargs:
            inference_config: dict[str, Any] = {}
            if "temperature" in kwargs:
                inference_config["temperature"] = kwargs.pop("temperature")
            if "max_tokens" in kwargs:
                inference_config["maxTokens"] = kwargs.pop("max_tokens")
            if inference_config:
                api_kwargs["inferenceConfig"] = inference_config

        loop = asyncio.get_running_loop()
        response = await loop.run_in_executor(
            None, lambda: self._client.converse(**api_kwargs)
        )

        # Parse response
        text_parts: list[str] = []
        tool_calls: list[ToolCallInfo] = []
        output = response.get("output", {})
        message_content = output.get("message", {}).get("content", [])
        for block in message_content:
            if "text" in block:
                text_parts.append(block["text"])
            elif "toolUse" in block:
                tu = block["toolUse"]
                tool_calls.append(
                    ToolCallInfo(
                        id=tu.get("toolUseId", ""),
                        name=tu.get("name", ""),
                        args=tu.get("input", {}),
                    )
                )

        usage_data = response.get("usage", {})
        usage = TokenUsage(
            input_tokens=usage_data.get("inputTokens", 0),
            output_tokens=usage_data.get("outputTokens", 0),
            total_tokens=usage_data.get("totalTokens", 0),
        )

        return ProviderResponse(
            text="".join(text_parts),
            usage=usage,
            tool_calls=tool_calls,
            raw=response,
        )

    async def stream(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ProviderEvent, None]:
        """Stream a completion from the AWS Bedrock Runtime Converse API.

        Uses ``converseStream`` via the synchronous ``boto3`` client,
        processing the event stream in an executor to avoid blocking.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Extra options (``temperature``, ``maxTokens``, etc.).
        """
        import asyncio

        system, api_messages = self._build_messages(messages)
        api_kwargs: dict[str, Any] = {
            "modelId": self._model_id,
            "messages": api_messages,
        }
        if system is not None:
            api_kwargs["system"] = system

        tool_config = self._build_tool_config(tools)
        if tool_config is not None:
            api_kwargs["toolConfig"] = tool_config

        if kwargs:
            inference_config: dict[str, Any] = {}
            if "temperature" in kwargs:
                inference_config["temperature"] = kwargs.pop("temperature")
            if "max_tokens" in kwargs:
                inference_config["maxTokens"] = kwargs.pop("max_tokens")
            if inference_config:
                api_kwargs["inferenceConfig"] = inference_config

        input_tokens = 0
        output_tokens = 0

        # Accumulator state for tool calls that arrive across
        # contentBlockStart → contentBlockDelta* → contentBlockStop.
        _current_tool_id: str = ""
        _current_tool_name: str = ""
        _current_tool_input_chunks: list[str] = []

        try:
            loop = asyncio.get_running_loop()
            response = await loop.run_in_executor(
                None, lambda: self._client.converse_stream(**api_kwargs)
            )

            event_stream = response.get("stream", [])
            for event in event_stream:
                if "contentBlockStart" in event:
                    start = event["contentBlockStart"].get("start", {})
                    if "toolUse" in start:
                        tu = start["toolUse"]
                        _current_tool_id = tu.get("toolUseId", "")
                        _current_tool_name = tu.get("name", "")
                        _current_tool_input_chunks = []

                elif "contentBlockDelta" in event:
                    delta = event["contentBlockDelta"].get("delta", {})
                    if "text" in delta:
                        yield TextChunkEvent(text=delta["text"])
                    elif "toolUse" in delta:
                        # Partial JSON input chunk — accumulate
                        chunk = delta["toolUse"].get("input", "")
                        if chunk:
                            _current_tool_input_chunks.append(chunk)

                elif "contentBlockStop" in event:
                    # Emit the fully assembled tool call
                    if _current_tool_name:
                        raw_input = "".join(_current_tool_input_chunks)
                        try:
                            args = json.loads(raw_input) if raw_input else {}
                        except json.JSONDecodeError:
                            args = {}
                        yield ToolCallChunkEvent(
                            id=_current_tool_id,
                            name=_current_tool_name,
                            args=args,
                        )
                        _current_tool_id = ""
                        _current_tool_name = ""
                        _current_tool_input_chunks = []

                elif "metadata" in event:
                    usage_data = event["metadata"].get("usage", {})
                    input_tokens = usage_data.get("inputTokens", 0)
                    output_tokens = usage_data.get("outputTokens", 0)

            yield ProviderDoneEvent(
                usage=TokenUsage(
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=input_tokens + output_tokens,
                )
            )
        except Exception as exc:
            yield ProviderErrorEvent(error=exc)
