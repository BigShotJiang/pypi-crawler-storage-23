"""Pipeline class for linear sequential agent chaining.

A ``Pipeline`` executes a list of agents (or ``ParallelGroup`` stages)
in order, passing each stage's output text as the next stage's prompt.
Supports structured output validation on the final stage, streaming with
stage-labelled events, and error handling with partial results.

Example::

    from synth import Agent, Pipeline
    pipeline = Pipeline([agent_a, agent_b, agent_c])
    result = pipeline.run("Summarise this document.")
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator, Generator
from typing import Any

from pydantic import BaseModel

from synth._compat import run_sync
from synth.errors import PipelineError
from synth.structured.output import StructuredOutputHandler
from synth.types import (
    DoneEvent,
    ErrorEvent,
    RunResult,
    StageEvent,
    StreamEvent,
    TokenUsage,
)


# ---------------------------------------------------------------------------
# ParallelGroup
# ---------------------------------------------------------------------------


class ParallelGroup:
    """Wraps agents for concurrent execution within a pipeline stage.

    Parameters
    ----------
    agents:
        The agents to execute concurrently.
    merge:
        Optional function to merge results.  Receives a list of
        ``RunResult`` objects and returns a single merged text string.
        Defaults to newline-joined concatenation of result texts.
    """

    def __init__(
        self,
        agents: list[Any],
        merge: Any | None = None,
    ) -> None:
        self.agents = agents
        self._merge = merge or self._default_merge

    @staticmethod
    def _default_merge(results: list[RunResult]) -> str:
        """Concatenate result texts separated by newlines."""
        return "\n".join(r.text for r in results)


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------


class Pipeline:
    """Sequential (and optionally parallel) agent pipeline.

    Each stage receives the previous stage's ``result.text`` as its prompt.
    ``ParallelGroup`` stages run their agents concurrently via
    ``asyncio.gather()`` and merge outputs before continuing.

    Parameters
    ----------
    stages:
        An ordered list of ``Agent`` instances and/or ``ParallelGroup``
        objects defining the pipeline.
    """

    def __init__(self, stages: list[Any]) -> None:
        self._stages = stages

    # ------------------------------------------------------------------
    # Sync wrappers
    # ------------------------------------------------------------------

    def run(
        self,
        input: str,
        *,
        output_schema: type[BaseModel] | None = None,
    ) -> RunResult:
        """Execute the pipeline synchronously.

        Parameters
        ----------
        input:
            The initial prompt fed to the first stage.
        output_schema:
            Optional Pydantic model for validating the final stage output.

        Returns
        -------
        RunResult
            The result from the final stage.
        """
        return run_sync(self.arun(input, output_schema=output_schema))

    def stream(
        self,
        input: str,
    ) -> Generator[StageEvent, None, None]:
        """Stream pipeline events synchronously.

        Wraps :meth:`astream` by consuming the async generator in a
        dedicated thread.

        Parameters
        ----------
        input:
            The initial prompt fed to the first stage.

        Yields
        ------
        StageEvent
            Each event labelled with the stage name that produced it.
        """
        import queue
        import threading

        q: queue.Queue[StageEvent | Exception | None] = queue.Queue()

        async def _consume() -> None:
            try:
                async for event in self.astream(input):
                    q.put(event)
            except Exception as exc:
                q.put(exc)
            finally:
                q.put(None)

        thread = threading.Thread(
            target=lambda: asyncio.run(_consume()),
            daemon=True,
        )
        thread.start()

        while True:
            item = q.get()
            if item is None:
                break
            if isinstance(item, Exception):
                raise item
            yield item

        thread.join()

    # ------------------------------------------------------------------
    # Async implementation
    # ------------------------------------------------------------------

    async def arun(
        self,
        input: str,
        *,
        output_schema: type[BaseModel] | None = None,
    ) -> RunResult:
        """Execute the pipeline asynchronously.

        Parameters
        ----------
        input:
            The initial prompt fed to the first stage.
        output_schema:
            Optional Pydantic model for validating the final stage output.

        Returns
        -------
        RunResult
            The result from the final stage.

        Raises
        ------
        PipelineError
            If any stage fails, with partial results from prior stages.
        """
        current_input = input
        partial_results: list[RunResult] = []

        for idx, stage in enumerate(self._stages):
            try:
                if isinstance(stage, ParallelGroup):
                    result = await self._run_parallel(stage, current_input)
                else:
                    result = await stage.arun(current_input)
            except PipelineError:
                raise
            except Exception as exc:
                agent_name = self._stage_name(stage, idx)
                raise PipelineError(
                    message=(
                        f"Pipeline failed at step {idx} "
                        f"(agent '{agent_name}'): {exc}"
                    ),
                    component="Pipeline",
                    suggestion=(
                        f"Check the agent at step {idx} "
                        f"('{agent_name}') for errors."
                    ),
                    failed_step=idx,
                    agent_name=agent_name,
                    partial_results=partial_results,
                ) from exc

            partial_results.append(result)
            current_input = result.text

        final_result = partial_results[-1]

        # Structured output validation on final stage only
        if output_schema is not None:
            handler = StructuredOutputHandler(output_schema)
            parsed = handler.parse(final_result.text)
            final_result = RunResult(
                text=final_result.text,
                output=parsed,
                tokens=final_result.tokens,
                cost=final_result.cost,
                latency_ms=final_result.latency_ms,
                trace=final_result.trace,
                tool_calls=final_result.tool_calls,
            )

        return final_result

    async def astream(
        self,
        input: str,
    ) -> AsyncGenerator[StageEvent, None]:
        """Stream pipeline events asynchronously.

        Each event is wrapped in a ``StageEvent`` with the stage name.

        Parameters
        ----------
        input:
            The initial prompt fed to the first stage.

        Yields
        ------
        StageEvent
            Events from each stage, labelled with the stage name.
        """
        current_input = input

        for idx, stage in enumerate(self._stages):
            stage_name = self._stage_name(stage, idx)

            if isinstance(stage, ParallelGroup):
                # For parallel groups, run and yield a DoneEvent
                result = await self._run_parallel(stage, current_input)
                yield StageEvent(
                    stage_name=stage_name,
                    event=DoneEvent(result=result),
                )
                current_input = result.text
            else:
                # Stream from the individual agent
                final_result: RunResult | None = None
                async for event in stage.astream(current_input):
                    if isinstance(event, DoneEvent):
                        final_result = event.result
                    yield StageEvent(
                        stage_name=stage_name,
                        event=event,
                    )

                if final_result is not None:
                    current_input = final_result.text

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    async def _run_parallel(
        group: ParallelGroup, input: str,
    ) -> RunResult:
        """Execute a ParallelGroup concurrently and merge results."""
        results: list[RunResult] = await asyncio.gather(
            *(agent.arun(input) for agent in group.agents)
        )

        merged_text = group._merge(results)

        # Aggregate token usage
        total_input = sum(r.tokens.input_tokens for r in results)
        total_output = sum(r.tokens.output_tokens for r in results)
        total_cost = sum(r.cost for r in results)
        total_latency = max(r.latency_ms for r in results)

        return RunResult(
            text=merged_text,
            output=None,
            tokens=TokenUsage(
                input_tokens=total_input,
                output_tokens=total_output,
                total_tokens=total_input + total_output,
            ),
            cost=total_cost,
            latency_ms=total_latency,
            trace=None,
            tool_calls=[],
        )

    @staticmethod
    def _stage_name(stage: Any, idx: int) -> str:
        """Derive a human-readable name for a pipeline stage."""
        if isinstance(stage, ParallelGroup):
            return f"parallel_group_{idx}"
        if hasattr(stage, "instructions") and stage.instructions:
            # Use first 30 chars of instructions as a name hint
            return stage.instructions[:30].strip()
        if hasattr(stage, "model"):
            return f"{stage.model}_step_{idx}"
        return f"stage_{idx}"
