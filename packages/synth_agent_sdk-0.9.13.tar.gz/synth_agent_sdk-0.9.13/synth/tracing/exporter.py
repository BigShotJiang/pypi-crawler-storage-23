"""Trace export and forwarding for the Synth SDK.

Provides OpenTelemetry-compatible JSON export, browser-based trace
visualisation, and automatic forwarding to ``SYNTH_TRACE_ENDPOINT``.
"""

from __future__ import annotations

import json
import os
import tempfile
import uuid
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from synth.tracing.trace import Trace, TraceSpan


# ---------------------------------------------------------------------------
# OTEL JSON helpers
# ---------------------------------------------------------------------------

def _span_to_otel(span: TraceSpan, trace_id: str) -> dict[str, Any]:
    """Convert a ``TraceSpan`` to an OpenTelemetry-compatible span dict."""
    return {
        "traceId": trace_id,
        "spanId": uuid.uuid4().hex[:16],
        "name": span.name,
        "kind": 1,  # SPAN_KIND_INTERNAL
        "startTimeUnixNano": _dt_to_nanos(span.start_time),
        "endTimeUnixNano": _dt_to_nanos(span.end_time),
        "attributes": [
            {"key": "span.type", "value": {"stringValue": span.type}},
            *[
                {"key": k, "value": _otel_attr_value(v)}
                for k, v in span.metadata.items()
            ],
        ],
        "status": {"code": 1},  # STATUS_CODE_OK
    }


def _dt_to_nanos(dt: datetime) -> int:
    """Convert a datetime to nanoseconds since Unix epoch."""
    return int(dt.replace(tzinfo=timezone.utc).timestamp() * 1_000_000_000)


def _otel_attr_value(value: Any) -> dict[str, Any]:
    """Wrap a Python value in an OTEL attribute value envelope."""
    if isinstance(value, bool):
        return {"boolValue": value}
    if isinstance(value, int):
        return {"intValue": value}
    if isinstance(value, float):
        return {"doubleValue": value}
    return {"stringValue": str(value)}


def _trace_to_otel(trace: Trace) -> dict[str, Any]:
    """Build a full OTEL-compatible JSON structure from a Trace."""
    trace_id = uuid.uuid4().hex
    return {
        "resourceSpans": [
            {
                "resource": {
                    "attributes": [
                        {
                            "key": "service.name",
                            "value": {"stringValue": "synth-sdk"},
                        },
                    ],
                },
                "scopeSpans": [
                    {
                        "scope": {"name": "synth.tracing"},
                        "spans": [
                            _span_to_otel(s, trace_id)
                            for s in trace.spans
                        ],
                    },
                ],
            },
        ],
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def export_trace(trace: Trace, *, path: str | None = None) -> str:
    """Write an OpenTelemetry-compatible JSON file to disk.

    Parameters
    ----------
    trace:
        The ``Trace`` to export.
    path:
        Destination file path.  When ``None`` a timestamped file is
        created in the current directory.

    Returns
    -------
    str
        The absolute path of the written file.
    """
    otel_data = _trace_to_otel(trace)

    if path is None:
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        path = f"synth_trace_{ts}.json"

    dest = Path(path).resolve()
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(otel_data, indent=2), encoding="utf-8")

    # Auto-forward if endpoint configured
    _maybe_forward(otel_data)

    return str(dest)


def show_trace(trace: Trace) -> None:
    """Open a minimal HTML timeline of the trace in the default browser."""
    otel_data = _trace_to_otel(trace)
    html = _build_timeline_html(trace, otel_data)

    with tempfile.NamedTemporaryFile(
        suffix=".html", delete=False, mode="w", encoding="utf-8",
    ) as f:
        f.write(html)
        webbrowser.open(f"file://{f.name}")


# ---------------------------------------------------------------------------
# Forwarding
# ---------------------------------------------------------------------------

def _maybe_forward(otel_data: dict[str, Any]) -> None:
    """POST trace data to ``SYNTH_TRACE_ENDPOINT`` if configured."""
    endpoint = os.environ.get("SYNTH_TRACE_ENDPOINT")
    if not endpoint:
        return

    # Validate HTTPS per security rules
    if not endpoint.startswith("https://"):
        import warnings

        warnings.warn(
            "SYNTH_TRACE_ENDPOINT should use HTTPS. "
            "Skipping trace forwarding for non-HTTPS endpoint.",
            stacklevel=2,
        )
        return

    try:
        import httpx

        payload = json.dumps(otel_data).encode("utf-8")
        # Enforce payload size limit (1 MB) to prevent exfiltration
        if len(payload) > 1_048_576:
            import warnings

            warnings.warn(
                "Trace payload exceeds 1 MB limit. Skipping forwarding.",
                stacklevel=2,
            )
            return

        httpx.post(
            endpoint,
            content=payload,
            headers={"Content-Type": "application/json"},
            timeout=10.0,
        )
    except Exception:  # noqa: BLE001 — best-effort forwarding
        pass


# ---------------------------------------------------------------------------
# HTML timeline (minimal)
# ---------------------------------------------------------------------------

def _build_timeline_html(
    trace: Trace, otel_data: dict[str, Any],
) -> str:
    """Build a self-contained HTML page showing the trace timeline."""
    rows = ""
    for span in trace.spans:
        duration_ms = (
            (span.end_time - span.start_time).total_seconds() * 1000
        )
        rows += (
            f"<tr>"
            f"<td>{span.name}</td>"
            f"<td>{span.type}</td>"
            f"<td>{span.start_time.isoformat()}</td>"
            f"<td>{duration_ms:.1f} ms</td>"
            f"</tr>\n"
        )

    return f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><title>Synth Trace</title>
<style>
body {{ font-family: monospace; background: #111; color: #0f0; padding: 1em; }}
table {{ border-collapse: collapse; width: 100%; }}
th, td {{ border: 1px solid #0f0; padding: 6px 10px; text-align: left; }}
th {{ background: #222; }}
</style></head>
<body>
<h1>Synth Trace</h1>
<p>Spans: {len(trace.spans)} | Tokens: {trace.total_tokens}
 | Cost: ${trace.total_cost:.4f}
 | Latency: {trace.total_latency_ms:.1f} ms</p>
<table>
<tr><th>Name</th><th>Type</th><th>Start</th><th>Duration</th></tr>
{rows}</table>
<details><summary>Raw OTEL JSON</summary>
<pre>{json.dumps(otel_data, indent=2)}</pre>
</details>
</body></html>"""
