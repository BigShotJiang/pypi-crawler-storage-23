"""ThreadMemory — in-process conversation memory.

Stores messages in an in-process dictionary keyed by ``thread_id``.
Supports token counting and automatic truncation when approaching
the context limit.
"""

from __future__ import annotations

import warnings

from synth.memory.base import BaseMemory
from synth.types import Message


# ---------------------------------------------------------------------------
# Warning class
# ---------------------------------------------------------------------------


class ContextTruncationWarning(UserWarning):
    """Emitted when memory truncates older messages to fit context limit."""


# ---------------------------------------------------------------------------
# ThreadMemory
# ---------------------------------------------------------------------------


class ThreadMemory(BaseMemory):
    """In-process thread-scoped memory backend.

    Stores conversation history in a dictionary keyed by ``thread_id``.
    Messages are kept in insertion order within each thread.

    When the estimated token count for a thread exceeds ``max_tokens``,
    older messages are removed from the front and a
    :class:`ContextTruncationWarning` is emitted.

    Parameters
    ----------
    max_tokens:
        Maximum estimated token count per thread before truncation
        kicks in.  Defaults to ``100_000``.

    Examples
    --------
    ::

        mem = ThreadMemory(max_tokens=500)
        await mem.add_messages("t1", [{"role": "user", "content": "hi"}])
    """

    def __init__(self, max_tokens: int = 100_000) -> None:
        self._threads: dict[str, list[Message]] = {}
        self._max_tokens = max_tokens

    async def get_messages(self, thread_id: str) -> list[Message]:
        """Retrieve all messages for the given thread.

        Parameters
        ----------
        thread_id:
            Unique identifier for the conversation thread.

        Returns
        -------
        list[Message]
            Ordered list of messages in the thread, or an empty list if the
            thread does not exist.
        """
        return list(self._threads.get(thread_id, []))

    async def add_messages(self, thread_id: str, messages: list[Message]) -> None:
        """Append messages to the given thread.

        After appending, the thread is checked against the token limit.
        If the estimated token count exceeds ``max_tokens``, older messages
        are removed from the front until the count fits.

        Parameters
        ----------
        thread_id:
            Unique identifier for the conversation thread.
        messages:
            Messages to append.
        """
        if thread_id not in self._threads:
            self._threads[thread_id] = []
        self._threads[thread_id].extend(messages)
        self._truncate_if_needed(thread_id)

    # ------------------------------------------------------------------
    # Token estimation
    # ------------------------------------------------------------------

    def _estimate_tokens(self, messages: list[Message]) -> int:
        """Estimate the total token count for a list of messages.

        Uses a simple character-based heuristic: ``len(content) // 4``.
        This is a rough proxy that avoids a dependency on a tokeniser
        library while still providing a reasonable approximation.

        Parameters
        ----------
        messages:
            Messages to estimate tokens for.

        Returns
        -------
        int
            Estimated total token count.
        """
        return sum(len(m["content"]) // 4 for m in messages)

    # ------------------------------------------------------------------
    # Truncation
    # ------------------------------------------------------------------

    def _truncate_if_needed(self, thread_id: str) -> None:
        """Remove oldest messages if the thread exceeds the token limit.

        Emits a single :class:`ContextTruncationWarning` when truncation
        occurs.
        """
        messages = self._threads[thread_id]
        if self._estimate_tokens(messages) <= self._max_tokens:
            return

        while self._estimate_tokens(messages) > self._max_tokens and len(messages) > 1:
            messages.pop(0)

        warnings.warn(
            f"Thread '{thread_id}' exceeded token limit. "
            "Older messages truncated.",
            ContextTruncationWarning,
            stacklevel=2,
        )
