"""Local testing UI server — bridges the browser to your Synth agent.

Run:
    python server.py

Then open http://localhost:8420 in your browser.
"""

from __future__ import annotations

import asyncio
import importlib.util
import json
import sys
import time
import uuid
from contextlib import asynccontextmanager
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

try:
    from fastapi import FastAPI, Request
    from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
    from fastapi.staticfiles import StaticFiles
    import uvicorn
except ImportError:
    print("Missing dependencies. Install them with:")
    print("  pip install uvicorn fastapi")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Evaluation data models
# ---------------------------------------------------------------------------


@dataclass
class EvaluationResult:
    """A single evaluation score from AgentCore Evaluations.

    Parameters
    ----------
    evaluator_name : str
        Name of the evaluator that produced this score.
    score : float
        Numeric evaluation score.
    level : str
        Evaluation granularity — one of ``"SESSION"``, ``"TRACE"``, or
        ``"TOOL_CALL"``.
    timestamp : str
        ISO 8601 timestamp of when the evaluation was performed.
    """

    evaluator_name: str
    score: float
    level: str
    timestamp: str


@dataclass
class EvaluationConfigStatus:
    """Online evaluation configuration status.

    Parameters
    ----------
    config_name : str
        Name of the online evaluation configuration.
    active : bool
        Whether the configuration is currently active.
    sampling_rate : float
        Fraction of traffic sampled for evaluation (0.0–1.0).
    evaluators : list[str]
        List of evaluator identifiers included in this configuration.
    """

    config_name: str
    active: bool
    sampling_rate: float
    evaluators: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Configuration — point this at your agent file
# ---------------------------------------------------------------------------
AGENT_FILE = "../agent.py"
PERSIST_FILE = Path(__file__).parent / "conversations.json"
PROMPTS_FILE = Path(__file__).parent / "prompts.json"
EVALS_FILE = Path(__file__).parent / "evals.json"
SCENARIOS_FILE = Path(__file__).parent / "scenarios.json"

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

@asynccontextmanager
async def _lifespan(application: FastAPI):
    """Load persisted data and the agent on startup."""
    _load_conversations()
    _load_prompts()
    _load_evals()
    _load_scenarios()
    try:
        _load_agent()
        print(f"Agent loaded from {AGENT_FILE}")
    except Exception as exc:
        _agent_status["error"] = str(exc)
        print(f"Warning: could not load agent: {exc}")
    yield


app = FastAPI(title="Synth Agent UI", lifespan=_lifespan)
app.mount("/static", StaticFiles(directory=Path(__file__).parent / "static"), name="static")

_agent = None
_agent_status = {"loaded": False, "error": None, "file": AGENT_FILE}
_conversations: dict[str, list[dict]] = {"default": []}
_current_conv = "default"
_prompts: dict[str, list[dict]] = {}
_evals: list[dict] = []
_scenarios: list[dict] = []

# Runtime configuration state for drift detection and tool toggling
_original_config: dict[str, Any] = {}
_disabled_tools: set[str] = set()
_all_tools: dict[str, Any] = {}


# ---------------------------------------------------------------------------
# Persistence helpers
# ---------------------------------------------------------------------------

def _load_conversations():
    global _conversations
    if PERSIST_FILE.exists():
        try:
            _conversations = json.loads(PERSIST_FILE.read_text(encoding="utf-8"))
        except Exception:
            _conversations = {"default": []}
    try:
        PERSIST_FILE.write_text(json.dumps(_conversations, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save conversations: {e}")


def _save_conversations():
    try:
        PERSIST_FILE.write_text(json.dumps(_conversations, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save conversations: {e}")


def _load_prompts():
    global _prompts
    if PROMPTS_FILE.exists():
        try:
            _prompts = json.loads(PROMPTS_FILE.read_text(encoding="utf-8"))
        except Exception:
            _prompts = {}


def _save_prompts():
    try:
        PROMPTS_FILE.write_text(json.dumps(_prompts, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save prompts: {e}")


def _load_evals():
    global _evals
    if EVALS_FILE.exists():
        try:
            _evals = json.loads(EVALS_FILE.read_text(encoding="utf-8"))
        except Exception:
            _evals = []


def _save_evals():
    try:
        EVALS_FILE.write_text(json.dumps(_evals, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save evals: {e}")


def _load_scenarios():
    global _scenarios
    if SCENARIOS_FILE.exists():
        try:
            _scenarios = json.loads(SCENARIOS_FILE.read_text(encoding="utf-8"))
        except Exception:
            _scenarios = []


def _save_scenarios():
    try:
        SCENARIOS_FILE.write_text(json.dumps(_scenarios, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save scenarios: {e}")


# ---------------------------------------------------------------------------
# Agent loader
# ---------------------------------------------------------------------------

def _load_agent():
    """Load the agent module and snapshot its configuration."""
    global _agent, _agent_status, _original_config, _disabled_tools, _all_tools

    # Ensure the agent's parent directory is on sys.path so that
    # sibling imports (e.g. ``from tools import ...``) resolve
    # regardless of where the server is launched from.
    agent_dir = str(Path(AGENT_FILE).resolve().parent)
    if agent_dir not in sys.path:
        sys.path.insert(0, agent_dir)

    spec = importlib.util.spec_from_file_location("_agent_mod", AGENT_FILE)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load agent from '{AGENT_FILE}'")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if not hasattr(mod, "agent"):
        raise RuntimeError(f"'{AGENT_FILE}' must define an 'agent' variable.")
    _agent = mod.agent
    _agent_status = {"loaded": True, "error": None, "file": AGENT_FILE}

    # Snapshot original config for drift detection
    tools = getattr(_agent, "_registered_tools", {})
    _original_config = {
        "model": getattr(_agent, "model", ""),
        "instructions": getattr(_agent, "instructions", ""),
        "tool_names": sorted(tools.keys()),
    }

    # Populate full tool registry (never mutated after load)
    _all_tools = dict(tools)

    # Reset disabled tools on fresh load
    _disabled_tools = set()

    return _agent


def _has_drift() -> bool:
    """Check if current agent config differs from the original snapshot."""
    if not _original_config or _agent is None:
        return False
    current_model = getattr(_agent, "model", "")
    current_instructions = getattr(_agent, "instructions", "")
    current_tools = getattr(_agent, "_registered_tools", {})
    current_tool_names = sorted(current_tools.keys())
    return (
        current_model != _original_config.get("model", "")
        or current_instructions != _original_config.get("instructions", "")
        or current_tool_names != _original_config.get("tool_names", [])
    )


def _run_agent(prompt: str):
    """Run agent synchronously, return (result, elapsed_ms)."""
    start = time.perf_counter()
    result = _agent.run(prompt)
    elapsed = (time.perf_counter() - start) * 1000
    return result, elapsed


def _build_msg(result, elapsed_ms: float) -> dict:
    text = result.text or (result.output.answer if result.output else "")
    return {
        "type": "done",
        "text": text,
        "output": result.output.model_dump() if result.output else None,
        "tokens": {
            "input": result.tokens.input_tokens,
            "output": result.tokens.output_tokens,
            "total": result.tokens.total_tokens,
        },
        "cost": result.cost,
        "latency_ms": round(elapsed_ms, 1),
        "tool_calls": [
            {"name": tc.name, "args": tc.args, "result": str(tc.result),
             "latency_ms": round(tc.latency_ms, 1)}
            for tc in result.tool_calls
        ],
        "trace": _serialize_trace(result),
    }


def _serialize_trace(result):
    trace = getattr(result, "trace", None)
    if trace is None:
        return []
    spans = getattr(trace, "spans", [])
    return [
        {
            "name": getattr(s, "name", "?"),
            "type": getattr(s, "span_type", "?"),
            "duration_ms": round(getattr(s, "duration_ms", 0.0), 1),
            "metadata": {k: v for k, v in getattr(s, "metadata", {}).items()},
        }
        for s in spans
    ]


async def _evaluate_guards_for_ui(
    response_text: str,
    tool_call_names: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Evaluate all agent guards and return results for UI display.

    Runs each guard's ``check()`` method individually with timing,
    capturing pass/fail status and violation messages.  This is a
    read-only evaluation for visibility — it does not raise on failure.

    Parameters
    ----------
    response_text:
        The agent response text to check against output guards.
    tool_call_names:
        Names of tools called during the run (may be empty).

    Returns
    -------
    list[dict[str, Any]]
        One dict per guard with keys: name, guard_type, passed,
        duration_ms, violation_message.
    """
    if _agent is None or not getattr(_agent, "guards", None):
        return []

    from synth.types import GuardContext

    context = GuardContext(
        cumulative_cost=0.0,
        tool_calls=tool_call_names or [],
        run_id=None,
    )

    results: list[dict[str, Any]] = []
    for guard in _agent.guards:
        start = time.perf_counter()
        try:
            result = await guard.check(response_text, context)
            elapsed = (time.perf_counter() - start) * 1000
            results.append({
                "name": guard.name,
                "guard_type": type(guard).__name__,
                "passed": result.passed,
                "duration_ms": round(elapsed, 2),
                "violation_message": result.violation_message,
            })
        except Exception as exc:
            elapsed = (time.perf_counter() - start) * 1000
            results.append({
                "name": guard.name,
                "guard_type": type(guard).__name__,
                "passed": False,
                "duration_ms": round(elapsed, 2),
                "violation_message": str(exc),
            })

    return results


@app.get("/", response_class=HTMLResponse)
async def index():
    html = (Path(__file__).parent / "static" / "index.html").read_text(encoding="utf-8")
    return HTMLResponse(content=html)


# ---------------------------------------------------------------------------
# Streaming chat endpoint (SSE)
# ---------------------------------------------------------------------------
@app.post("/api/chat/stream")
async def chat_stream(request: Request):
    if _agent is None:
        async def err():
            yield f"data: {json.dumps({'type': 'error', 'error': 'No agent loaded.'})}\n\n"
        return StreamingResponse(err(), media_type="text/event-stream")

    body = await request.json()
    prompt = body.get("prompt", "")
    conv_id = body.get("conversation", "default")

    if not prompt.strip():
        async def err():
            yield f"data: {json.dumps({'type': 'error', 'error': 'Empty prompt.'})}\n\n"
        return StreamingResponse(err(), media_type="text/event-stream")

    async def generate():
        start = time.perf_counter()
        try:
            loop = asyncio.get_event_loop()
            full_text = ""
            result = None
            tool_call_names: list[str] = []

            def _stream():
                return list(_agent.stream(prompt))

            events = await loop.run_in_executor(None, _stream)

            for event in events:
                etype = type(event).__name__
                if etype == "ThinkingEvent":
                    thinking = getattr(event, "thinking", "") or getattr(event, "text", "")
                    if thinking:
                        yield f"data: {json.dumps({'type': 'thinking', 'text': thinking})}\n\n"
                        await asyncio.sleep(0)
                elif etype == "TokenEvent":
                    token = getattr(event, "text", "") or getattr(event, "token", "")
                    if token:
                        full_text += token
                        yield f"data: {json.dumps({'type': 'token', 'text': token})}\n\n"
                        await asyncio.sleep(0)
                elif etype == "ToolCallEvent":
                    tool_call_names.append(
                        getattr(event, "name", "?"),
                    )
                    yield f"data: {json.dumps({'type': 'tool_call', 'name': getattr(event, 'name', '?')})}\n\n"
                    await asyncio.sleep(0)
                elif etype == "DoneEvent":
                    result = getattr(event, "result", None)

            elapsed = (time.perf_counter() - start) * 1000
            if result is None:
                result = await loop.run_in_executor(
                    None, _agent.run, prompt,
                )
                full_text = result.text or ""

            text = full_text or result.text or (
                result.output.answer if result.output else ""
            )

            # Evaluate guards for UI visibility
            guard_results = await _evaluate_guards_for_ui(
                text, tool_call_names,
            )
            if guard_results:
                yield f"data: {json.dumps({'type': 'guard_result', 'guards': guard_results})}\n\n"
                await asyncio.sleep(0)

            msg = _build_msg(result, elapsed)
            msg["text"] = text

            if conv_id not in _conversations:
                _conversations[conv_id] = []
            _conversations[conv_id].append({"role": "user", "content": prompt, "ts": time.time()})
            _conversations[conv_id].append({"role": "agent", "data": msg, "ts": time.time()})
            _save_conversations()
            yield f"data: {json.dumps(msg)}\n\n"
        except Exception as exc:
            import traceback
            traceback.print_exc()
            yield f"data: {json.dumps({'type': 'error', 'error': str(exc)})}\n\n"

    return StreamingResponse(
        generate(), media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------------------------------------------------------------------------
# Non-streaming fallback
# ---------------------------------------------------------------------------
@app.post("/api/chat")
async def chat(request: Request):
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    body = await request.json()
    prompt = body.get("prompt", "")
    conv_id = body.get("conversation", "default")
    if not prompt.strip():
        return JSONResponse({"error": "Empty prompt."}, status_code=400)
    try:
        loop = asyncio.get_event_loop()
        result, elapsed = await loop.run_in_executor(
            None, lambda: _run_agent(prompt),
        )
        msg = _build_msg(result, elapsed)

        # Evaluate guards for UI visibility
        response_text = msg.get("text", "")
        tool_names = [tc["name"] for tc in msg.get("tool_calls", [])]
        guard_results = await _evaluate_guards_for_ui(
            response_text, tool_names,
        )
        msg["guards"] = guard_results

        if conv_id not in _conversations:
            _conversations[conv_id] = []
        _conversations[conv_id].append({"role": "user", "content": prompt, "ts": time.time()})
        _conversations[conv_id].append({"role": "agent", "data": msg, "ts": time.time()})
        _save_conversations()
        return JSONResponse(msg)
    except Exception as exc:
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(exc)}, status_code=500)


# ---------------------------------------------------------------------------
# Agent management
# ---------------------------------------------------------------------------

@app.post("/api/reload")
async def reload_agent():
    try:
        _load_agent()
        return JSONResponse({"status": "reloaded"})
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


def _parse_agentcore_yaml() -> dict[str, Any] | None:
    """Parse agentcore.yaml from the agent file directory, if present.

    The returned dict includes an ``evaluations_configured`` flag that is
    ``True`` when either the YAML contains an ``evaluations`` section or
    an ``eval_config.json`` file exists alongside the agent.
    """
    agent_dir = Path(AGENT_FILE).resolve().parent
    yaml_path = agent_dir / "agentcore.yaml"
    if not yaml_path.exists():
        return None
    try:
        import yaml  # type: ignore[import-untyped]

        with yaml_path.open(encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}

        # Detect evaluations: YAML section OR eval_config.json presence
        has_eval_section = bool(data.get("evaluations"))
        has_eval_config = _parse_eval_config() is not None
        evaluations_configured = has_eval_section or has_eval_config

        return {
            "detected": True,
            "agent_name": data.get("agent_name", ""),
            "aws_region": data.get("aws_region", ""),
            "model_id": data.get("model_id", ""),
            "evaluations_configured": evaluations_configured,
        }
    except ImportError:
        return None
    except Exception:
        return None


def _parse_eval_config() -> dict[str, Any] | None:
    """Parse eval_config.json from the agent file directory, if present.

    Returns
    -------
    dict[str, Any] | None
        Parsed JSON contents, or ``None`` when the file is missing or
        contains invalid JSON.
    """
    agent_dir = Path(AGENT_FILE).resolve().parent
    config_path = agent_dir / "eval_config.json"
    if not config_path.exists():
        return None
    try:
        with config_path.open(encoding="utf-8") as fh:
            return json.load(fh)
    except (json.JSONDecodeError, OSError):
        return None


@app.get("/api/config")
async def get_config():
    """Return the agent's current runtime configuration."""
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)

    # Build tools list with enabled status
    tools_list: list[dict[str, Any]] = []
    for name, fn in _all_tools.items():
        schema = getattr(fn, "_tool_schema", {})
        description = schema.get("description", "") or fn.__doc__ or ""
        tools_list.append({
            "name": name,
            "description": description,
            "enabled": name not in _disabled_tools,
        })

    # Build guards list
    guards_list: list[dict[str, str]] = []
    for guard in getattr(_agent, "guards", []):
        guard_name = getattr(guard, "name", "") or getattr(guard, "_name", "")
        guards_list.append({
            "name": guard_name,
            "type": type(guard).__name__,
        })

    response: dict[str, Any] = {
        "model": getattr(_agent, "model", ""),
        "instructions": getattr(_agent, "instructions", ""),
        "tools": tools_list,
        "guards": guards_list,
        "has_drift": _has_drift(),
    }

    # Include AgentCore deployment metadata if available
    agentcore = _parse_agentcore_yaml()
    if agentcore is not None:
        response["agentcore"] = agentcore
    else:
        response["agentcore"] = {"detected": False}

    return JSONResponse(response)


@app.patch("/api/config")
async def update_config(request: Request) -> JSONResponse:
    """Update the agent's runtime configuration (model, instructions, tools).

    Accepts optional ``model``, ``instructions``, and ``tools`` fields.
    Only provided fields are updated.
    """
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)

    body = await request.json()
    warnings_list: list[str] = []

    # --- Model update ---
    if "model" in body:
        new_model = body["model"]
        from synth.providers.router import ProviderRouter
        from synth.errors import SynthConfigError

        router = ProviderRouter()
        try:
            base_url = getattr(_agent, "base_url", None)
            new_provider = router.resolve(new_model, base_url=base_url)
            _agent.model = new_model
            _agent.provider = new_provider
        except SynthConfigError as exc:
            return JSONResponse(
                {"error": str(exc)},
                status_code=400,
            )

    # --- Instructions update ---
    if "instructions" in body:
        _agent.instructions = body["instructions"]

    # --- Tool toggles ---
    if "tools" in body:
        tool_toggles: dict[str, bool] = body["tools"]
        for tool_name, enabled in tool_toggles.items():
            if tool_name not in _all_tools:
                continue
            if enabled:
                _disabled_tools.discard(tool_name)
            else:
                _disabled_tools.add(tool_name)

        # Rebuild active tool set from _all_tools minus disabled
        active_tools = {
            k: v for k, v in _all_tools.items() if k not in _disabled_tools
        }
        _agent._registered_tools = active_tools

        # Rebuild tool executor with updated tool set
        from synth.tools.executor import ToolExecutor

        _agent.tool_executor = ToolExecutor(active_tools)

    return JSONResponse({
        "status": "updated",
        "warnings": warnings_list,
        "has_drift": _has_drift(),
    })


@app.post("/api/config/save")
async def save_config(request: Request) -> JSONResponse:
    """Persist the current runtime config to the agent file on disk.

    Reads the agent source, applies regex patches for model, instructions,
    and tools list, then writes atomically.  Fields whose source patterns
    don't match (e.g. env-var references) are skipped with a warning.
    """
    global _original_config

    if _agent is None:
        return JSONResponse(
            {"error": "No agent loaded."},
            status_code=503,
        )

    current_model: str = getattr(_agent, "model", "")
    current_instructions: str = getattr(_agent, "instructions", "")

    if not current_model:
        return JSONResponse(
            {"error": "Model string must not be empty."},
            status_code=400,
        )
    if not current_instructions:
        return JSONResponse(
            {"error": "Instructions must not be empty."},
            status_code=400,
        )

    from synth.cli.edit_cmd import (
        _atomic_write,
        _patch_instructions,
        _patch_model,
        _patch_tools_list,
    )

    agent_path = str(Path(AGENT_FILE).resolve())
    warnings_list: list[str] = []

    try:
        source = Path(agent_path).read_text(encoding="utf-8")
    except Exception as exc:
        return JSONResponse(
            {"error": f"Failed to read agent file: {exc}"},
            status_code=500,
        )

    # --- Patch model ---
    patched = _patch_model(source, current_model)
    if patched == source:
        warnings_list.append(
            "Could not patch 'model' — value is not a string literal."
        )
    source = patched

    # --- Patch instructions ---
    patched = _patch_instructions(source, current_instructions)
    if patched == source:
        warnings_list.append(
            "Could not patch 'instructions' — value is not a string literal."
        )
    source = patched

    # --- Patch tools list ---
    active_tools = getattr(_agent, "_registered_tools", {})
    tool_names = sorted(active_tools.keys())
    patched = _patch_tools_list(source, tool_names)
    if patched == source:
        warnings_list.append(
            "Could not patch 'tools' — tools list pattern not found."
        )
    source = patched

    # --- Write atomically ---
    try:
        _atomic_write(agent_path, source)
    except Exception as exc:
        return JSONResponse(
            {"error": f"Failed to write agent file: {exc}"},
            status_code=500,
        )

    # Update the original config snapshot so drift resets
    _original_config = {
        "model": current_model,
        "instructions": current_instructions,
        "tool_names": tool_names,
    }

    return JSONResponse({"status": "saved", "warnings": warnings_list})


def _build_models_by_provider() -> dict[str, list[str]]:
    """Build a mapping of provider display names to available model IDs.

    Combines ``_PROVIDERS`` from ``synth.cli.init_cmd`` (display names and
    default models) with ``_PROVIDER_SPECS`` from ``synth.providers.router``
    (prefix-based routing metadata).
    """
    from synth.cli.init_cmd import _PROVIDERS
    from synth.providers.router import _PROVIDER_SPECS  # noqa: F401

    # Build grouped result from _PROVIDERS, keyed by display name.
    # Each _PROVIDERS entry has a display name and a default model.
    providers: dict[str, list[str]] = {}

    for _key, pcfg in _PROVIDERS.items():
        display = pcfg.get("display", _key)
        model = pcfg.get("model", "")
        if not model:
            continue
        if display not in providers:
            providers[display] = []
        if model not in providers[display]:
            providers[display].append(model)

    return providers



@app.get("/api/models")
async def get_models() -> JSONResponse:
    """Return available models grouped by provider display name."""
    providers = _build_models_by_provider()
    return JSONResponse({"providers": providers})


@app.get("/api/tools")
async def list_tools():
    if _agent is None:
        return JSONResponse({"tools": []})
    tools = getattr(_agent, "_registered_tools", {})
    tool_list = []
    for name, fn in tools.items():
        schema = getattr(fn, "_tool_schema", {})
        tool_list.append({
            "name": name,
            "description": schema.get("description", ""),
            "parameters": schema.get("parameters", {}),
        })
    return JSONResponse({"tools": tool_list})


@app.post("/api/tools/test")
async def test_tool(request: Request):
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    body = await request.json()
    tool_name = body.get("name", "")
    tool_args = body.get("args", {})
    tools = getattr(_agent, "_registered_tools", {})
    if tool_name not in tools:
        return JSONResponse({"error": f"Tool '{tool_name}' not found."}, status_code=404)
    start = time.perf_counter()
    try:
        fn = tools[tool_name]
        if asyncio.iscoroutinefunction(fn):
            result = await fn(**tool_args)
        else:
            result = fn(**tool_args)
        elapsed = (time.perf_counter() - start) * 1000
        return JSONResponse({"result": str(result), "latency_ms": round(elapsed, 1)})
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


# ---------------------------------------------------------------------------
# Conversations
# ---------------------------------------------------------------------------

@app.get("/api/conversations")
async def list_conversations():
    return JSONResponse({"conversations": list(_conversations.keys()), "current": _current_conv})


@app.get("/api/conversations/{conv_id}")
async def get_conversation(conv_id: str):
    return JSONResponse({"messages": _conversations.get(conv_id, [])})


@app.post("/api/conversations")
async def create_conversation(request: Request):
    global _current_conv
    body = await request.json()
    conv_id = body.get("id", f"chat-{len(_conversations) + 1}")
    _conversations[conv_id] = []
    _current_conv = conv_id
    _save_conversations()
    return JSONResponse({"id": conv_id})


@app.delete("/api/conversations/{conv_id}")
async def delete_conversation(conv_id: str):
    global _current_conv
    if conv_id in _conversations and conv_id != "default":
        del _conversations[conv_id]
        if _current_conv == conv_id:
            _current_conv = "default"
        _save_conversations()
    return JSONResponse({"status": "deleted"})


# ---------------------------------------------------------------------------
# Prompt management
# ---------------------------------------------------------------------------

@app.get("/api/prompts")
async def list_prompts():
    return JSONResponse({"prompts": {n: v for n, v in _prompts.items()}})


@app.post("/api/prompts")
async def save_prompt(request: Request):
    body = await request.json()
    name = body.get("name", "").strip()
    text = body.get("text", "").strip()
    notes = body.get("notes", "")
    if not name or not text:
        return JSONResponse({"error": "name and text required"}, status_code=400)
    if name not in _prompts:
        _prompts[name] = []
    version = len(_prompts[name]) + 1
    _prompts[name].append({"version": version, "text": text, "notes": notes, "created_at": time.time()})
    _save_prompts()
    return JSONResponse({"name": name, "version": version})


@app.delete("/api/prompts/{name}")
async def delete_prompt(name: str):
    if name in _prompts:
        del _prompts[name]
        _save_prompts()
    return JSONResponse({"status": "deleted"})


@app.delete("/api/prompts/{name}/{version}")
async def delete_prompt_version(name: str, version: int):
    if name in _prompts:
        _prompts[name] = [v for v in _prompts[name] if v["version"] != version]
        if not _prompts[name]:
            del _prompts[name]
        _save_prompts()
    return JSONResponse({"status": "deleted"})


# ---------------------------------------------------------------------------
# A/B testing
# ---------------------------------------------------------------------------

@app.post("/api/ab-test")
async def ab_test(request: Request):
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    body = await request.json()
    input_text = body.get("input", "").strip()
    prompt_a = body.get("prompt_a", "").strip()
    prompt_b = body.get("prompt_b", "").strip()
    if not input_text:
        return JSONResponse({"error": "input required"}, status_code=400)
    loop = asyncio.get_event_loop()

    async def run_variant(system_prompt, label):
        try:
            full_prompt = f"{system_prompt}\n\n{input_text}" if system_prompt else input_text
            result, elapsed = await loop.run_in_executor(None, lambda: _run_agent(full_prompt))
            return {
                "label": label, "prompt": system_prompt,
                "text": result.text or (result.output.answer if result.output else ""),
                "tokens": {"input": result.tokens.input_tokens, "output": result.tokens.output_tokens, "total": result.tokens.total_tokens},
                "cost": result.cost, "latency_ms": round(elapsed, 1),
            }
        except Exception as exc:
            return {"label": label, "prompt": system_prompt, "error": str(exc)}

    results = await asyncio.gather(run_variant(prompt_a, "A"), run_variant(prompt_b, "B"))
    return JSONResponse({"results": list(results), "input": input_text})


# ---------------------------------------------------------------------------
# Evals
# ---------------------------------------------------------------------------

@app.get("/api/evals")
async def list_evals():
    return JSONResponse({"evals": _evals})


@app.post("/api/evals")
async def create_eval(request: Request):
    body = await request.json()
    name = body.get("name", "").strip()
    input_text = body.get("input", "").strip()
    expected = body.get("expected", "").strip()
    if not name or not input_text:
        return JSONResponse({"error": "name and input required"}, status_code=400)
    eval_case = {"id": str(uuid.uuid4())[:8], "name": name, "input": input_text, "expected": expected, "golden": None, "created_at": time.time()}
    _evals.append(eval_case)
    _save_evals()
    return JSONResponse(eval_case)


@app.delete("/api/evals/{eval_id}")
async def delete_eval(eval_id: str):
    global _evals
    _evals = [e for e in _evals if e["id"] != eval_id]
    _save_evals()
    return JSONResponse({"status": "deleted"})


@app.post("/api/evals/run")
async def run_evals(request: Request):
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    body = await request.json()
    ids = body.get("ids", None)
    use_llm_judge = body.get("llm_judge", False)
    cases = _evals if ids is None else [e for e in _evals if e["id"] in ids]
    if not cases:
        return JSONResponse({"results": []})
    loop = asyncio.get_event_loop()
    results = []
    for case in cases:
        try:
            result, elapsed = await loop.run_in_executor(None, lambda c=case: _run_agent(c["input"]))
            actual = result.text or (result.output.answer if result.output else "")
            expected = case.get("expected", "")
            golden = case.get("golden")
            score = _simple_score(actual, expected) if expected else None
            regression = _simple_score(actual, golden) if golden else None
            llm_score, llm_reason = None, None
            if use_llm_judge and expected:
                llm_score, llm_reason = await loop.run_in_executor(None, lambda a=actual, e=expected: _llm_judge(a, e))
            results.append({
                "id": case["id"], "name": case["name"], "input": case["input"],
                "expected": expected, "actual": actual, "score": score,
                "llm_score": llm_score, "llm_reason": llm_reason,
                "regression_score": regression, "golden": golden,
                "latency_ms": round(elapsed, 1),
                "tokens": {"input": result.tokens.input_tokens, "output": result.tokens.output_tokens, "total": result.tokens.total_tokens},
                "cost": result.cost, "pass": score is not None and score >= 0.5,
            })
        except Exception as exc:
            results.append({"id": case["id"], "name": case["name"], "error": str(exc), "pass": False})
    return JSONResponse({"results": results})


@app.post("/api/evals/{eval_id}/set-golden")
async def set_golden(eval_id: str, request: Request):
    body = await request.json()
    text = body.get("text", "")
    for e in _evals:
        if e["id"] == eval_id:
            e["golden"] = text
            _save_evals()
            return JSONResponse({"status": "saved"})
    return JSONResponse({"error": "not found"}, status_code=404)


def _simple_score(actual, expected):
    if not expected:
        return 1.0
    a_words = set(actual.lower().split())
    e_words = set(expected.lower().split())
    if not e_words:
        return 1.0
    return round(len(a_words & e_words) / len(e_words), 3)


def _llm_judge(actual, expected):
    import re
    judge_prompt = (
        f"You are an evaluator. Score the following response against the expected output.\n\n"
        f"Expected: {expected}\n\nActual: {actual}\n\n"
        f'Reply with JSON only: {{"score": <0.0-1.0>, "reason": "<one sentence>"}}'
    )
    try:
        result = _agent.run(judge_prompt)
        text = result.text or ""
        m = re.search(r'\{.*\}', text, re.DOTALL)
        if m:
            data = json.loads(m.group())
            return float(data.get("score", 0)), str(data.get("reason", ""))
    except Exception:
        pass
    return 0.0, "Judge failed"


# ---------------------------------------------------------------------------
# Scenarios (multi-turn)
# ---------------------------------------------------------------------------

@app.get("/api/scenarios")
async def list_scenarios():
    return JSONResponse({"scenarios": _scenarios})


@app.post("/api/scenarios")
async def create_scenario(request: Request):
    body = await request.json()
    name = body.get("name", "").strip()
    turns = body.get("turns", [])
    if not name:
        return JSONResponse({"error": "name required"}, status_code=400)
    scenario = {"id": str(uuid.uuid4())[:8], "name": name, "turns": turns, "created_at": time.time()}
    _scenarios.append(scenario)
    _save_scenarios()
    return JSONResponse(scenario)


@app.put("/api/scenarios/{scenario_id}")
async def update_scenario(scenario_id: str, request: Request):
    body = await request.json()
    for s in _scenarios:
        if s["id"] == scenario_id:
            s["name"] = body.get("name", s["name"])
            s["turns"] = body.get("turns", s["turns"])
            _save_scenarios()
            return JSONResponse(s)
    return JSONResponse({"error": "not found"}, status_code=404)


@app.delete("/api/scenarios/{scenario_id}")
async def delete_scenario(scenario_id: str):
    global _scenarios
    _scenarios = [s for s in _scenarios if s["id"] != scenario_id]
    _save_scenarios()
    return JSONResponse({"status": "deleted"})


@app.post("/api/scenarios/{scenario_id}/run")
async def run_scenario(scenario_id: str):
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    scenario = next((s for s in _scenarios if s["id"] == scenario_id), None)
    if not scenario:
        return JSONResponse({"error": "not found"}, status_code=404)
    loop = asyncio.get_event_loop()
    results = []
    for turn in scenario["turns"]:
        if turn.get("role") != "user":
            continue
        content = turn["content"]
        try:
            result, elapsed = await loop.run_in_executor(None, lambda c=content: _run_agent(c))
            results.append({
                "input": content,
                "output": result.text or (result.output.answer if result.output else ""),
                "latency_ms": round(elapsed, 1),
                "tokens": {"input": result.tokens.input_tokens, "output": result.tokens.output_tokens, "total": result.tokens.total_tokens},
                "cost": result.cost,
            })
        except Exception as exc:
            results.append({"input": content, "error": str(exc)})
    return JSONResponse({"scenario": scenario["name"], "results": results})


# ---------------------------------------------------------------------------
# Credential scrubbing helper
# ---------------------------------------------------------------------------


def _scrub_credentials(text: str) -> str:
    """Apply credential redaction to *text*, returning it unchanged if the
    ``CredentialResolver`` is unavailable.
    """
    try:
        from synth.deploy.agentcore.credentials import (
            CredentialResolver,
        )

        return CredentialResolver().redact_credentials(text)
    except ImportError:
        return text


def _scrub_dict(data: Any) -> Any:
    """Recursively scrub credential patterns from all string values in a
    JSON-serialisable structure.
    """
    if isinstance(data, str):
        return _scrub_credentials(data)
    if isinstance(data, dict):
        return {k: _scrub_dict(v) for k, v in data.items()}
    if isinstance(data, list):
        return [_scrub_dict(item) for item in data]
    return data


# ---------------------------------------------------------------------------
# AgentCore Evaluations endpoints
# ---------------------------------------------------------------------------


@app.get("/api/agentcore/evaluations")
async def get_evaluations() -> JSONResponse:
    """Return evaluation scores from AgentCore Evaluations API.

    Returns a list of :class:`EvaluationResult` dicts.  When evaluations
    are not configured (no ``eval_config.json``), returns an empty list
    with an informational message.
    """
    eval_cfg = _parse_eval_config()
    if eval_cfg is None:
        return JSONResponse({
            "results": [],
            "message": "Evaluations not configured — "
                       "no eval_config.json found.",
        })

    try:
        # TODO: Replace stub with real AgentCore Evaluations API call
        # via AgentCore_Client once the client service is implemented.
        # For now, return placeholder data shaped from the config.
        from datetime import datetime, timezone

        results: list[dict[str, Any]] = []
        for evaluator in eval_cfg.get("evaluators", []):
            result = EvaluationResult(
                evaluator_name=evaluator.get("id", "unknown"),
                score=0.0,
                level=evaluator.get("level", "TRACE"),
                timestamp=datetime.now(timezone.utc).isoformat(),
            )
            results.append(asdict(result))

        scrubbed = _scrub_dict({"results": results})
        return JSONResponse(scrubbed)
    except Exception as exc:
        error_msg = _scrub_credentials(str(exc))
        return JSONResponse(
            {"error": error_msg},
            status_code=500,
        )


@app.post("/api/agentcore/evaluations/run")
async def run_on_demand_evaluation(request: Request) -> JSONResponse:
    """Trigger an on-demand evaluation against the most recent session.

    Accepts a JSON body with an optional ``evaluators`` list to select
    which evaluators to run.  When omitted, all configured evaluators
    are used.
    """
    eval_cfg = _parse_eval_config()
    if eval_cfg is None:
        return JSONResponse(
            {"error": "Evaluations not configured — "
                      "no eval_config.json found."},
            status_code=400,
        )

    try:
        body = await request.json()
    except Exception:
        body = {}

    requested = body.get("evaluators")

    try:
        # TODO: Replace stub with real AgentCore Evaluations API call
        # via AgentCore_Client.  Should invoke RunEvaluation against
        # the most recent agent session.
        from datetime import datetime, timezone

        configured = eval_cfg.get("evaluators", [])
        if requested:
            configured = [
                e for e in configured
                if e.get("id") in requested
            ]

        results: list[dict[str, Any]] = []
        for evaluator in configured:
            result = EvaluationResult(
                evaluator_name=evaluator.get("id", "unknown"),
                score=0.0,
                level=evaluator.get("level", "TRACE"),
                timestamp=datetime.now(timezone.utc).isoformat(),
            )
            results.append(asdict(result))

        scrubbed = _scrub_dict({"results": results})
        return JSONResponse(scrubbed)
    except Exception as exc:
        error_msg = _scrub_credentials(str(exc))
        return JSONResponse(
            {"error": error_msg},
            status_code=500,
        )


@app.get("/api/agentcore/evaluations/config")
async def get_evaluation_config() -> JSONResponse:
    """Return the current online evaluation configuration status.

    Returns an :class:`EvaluationConfigStatus` dict when configured,
    or a ``null`` config with a message when ``eval_config.json`` is
    absent.
    """
    eval_cfg = _parse_eval_config()
    if eval_cfg is None:
        return JSONResponse({
            "config": None,
            "message": "Evaluations not configured — "
                       "no eval_config.json found.",
        })

    try:
        evaluator_ids = [
            e.get("id", "unknown")
            for e in eval_cfg.get("evaluators", [])
        ]
        status = EvaluationConfigStatus(
            config_name=eval_cfg.get("config_name", ""),
            active=True,
            sampling_rate=float(eval_cfg.get("sampling_rate", 1.0)),
            evaluators=evaluator_ids,
        )
        scrubbed = _scrub_dict({"config": asdict(status)})
        return JSONResponse(scrubbed)
    except Exception as exc:
        error_msg = _scrub_credentials(str(exc))
        return JSONResponse(
            {"error": error_msg},
            status_code=500,
        )


# ---------------------------------------------------------------------------
# Info / health
# ---------------------------------------------------------------------------

@app.get("/api/info")
async def agent_info():
    tools = getattr(_agent, "_registered_tools", {}) if _agent else {}
    return JSONResponse({
        "model": getattr(_agent, "model", "unknown") if _agent else "not loaded",
        "tools": len(tools),
        "instructions": getattr(_agent, "instructions", "")[:200] if _agent else "",
        "status": _agent_status,
    })


@app.get("/api/health")
async def health():
    return JSONResponse({"ok": True, "agent_loaded": _agent is not None})


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8420)
