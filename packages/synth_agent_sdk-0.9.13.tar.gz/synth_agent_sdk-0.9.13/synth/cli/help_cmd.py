"""``synth help`` command — curated getting-started guide and command reference.

Displays a quick-reference card in the terminal with common workflows,
command usage, and links to documentation.
"""

from __future__ import annotations

import click


# ---------------------------------------------------------------------------
# Help content
# ---------------------------------------------------------------------------

def run_help() -> None:
    """Display the Synth SDK quick-reference guide."""
    color = _supports_color()

    _section("QUICK START", color)
    _line("  pip install synth-agent-sdk[anthropic]", color)
    _line('  export ANTHROPIC_API_KEY="sk-..."', color)
    _line("  synth create agent my-bot", color)
    _line('  synth run my-bot/agent.py "Hello!"', color)
    _blank()

    _section("COMMANDS", color)
    _cmd("synth create agent <name>",
         "Scaffold a new agent (interactive provider selection)", color)
    _cmd("synth create team <name>",
         "Scaffold a multi-agent team + pipeline", color)
    _cmd("synth create tool <name>",
         "Generate a standalone tools file with examples", color)
    _cmd("synth create mcp <name>",
         "Scaffold an MCP server with FastMCP", color)
    _cmd("synth create ui <name>",
         "Scaffold a local browser-based testing UI", color)
    _blank()
    _cmd("synth run <file> \"prompt\"",
         "Execute an agent with a prompt", color)
    _cmd("synth dev <file>",
         "Start interactive REPL with hot-reload", color)
    _cmd("synth eval <file> --dataset <json>",
         "Run evaluation suite against an agent", color)
    _cmd("synth deploy --target agentcore <file>",
         "Package and deploy to AWS AgentCore", color)
    _blank()
    _cmd("synth trace <run_id>",
         "Open a stored trace in the browser", color)
    _cmd("synth doctor",
         "Check environment, credentials, and dependencies", color)
    _cmd("synth init",
         "Interactive project setup (like npm init)", color)
    _cmd("synth bench <file> \"prompt\" -n 20",
         "Benchmark agent latency, tokens, and cost", color)
    _cmd("synth help",
         "Show this guide", color)
    _blank()

    _section("COMMON WORKFLOWS", color)
    _workflow("Quick start with synth init", [
        "synth init                       # interactive setup",
        "cd my-project",
        "synth dev agent.py               # rich TUI",
    ], color)
    _workflow("Build an agent with tools", [
        "synth create agent my-bot        # pick your provider",
        "synth create tool my-tools       # scaffold tool functions",
        "# import tools in agent.py, add to tools=[]",
        'synth run my-bot/agent.py "test it"',
    ], color)
    _workflow("Test with the browser UI", [
        "synth create ui my-ui",
        "pip install uvicorn fastapi",
        "# edit my-ui/server.py to point at your agent",
        "python my-ui/server.py           # open localhost:8420",
    ], color)
    _workflow("Deploy to AgentCore", [
        "synth create agent my-service    # choose AgentCore",
        "pip install synth-agent-sdk[agentcore]",
        "aws configure",
        "synth deploy --target agentcore --dry-run my-service/agent.py",
        "synth deploy --target agentcore my-service/agent.py",
    ], color)
    _workflow("Build an MCP server", [
        "synth create mcp my-server",
        "pip install mcp",
        "python my-server/server.py",
    ], color)
    _workflow("Benchmark your agent", [
        'synth bench agent.py "Hello" --runs 20',
        "# Reports p50/p95/p99 latency, tokens, cost",
    ], color)

    _section("PROVIDERS", color)
    _line("  Anthropic    claude-sonnet-4-5          synth[anthropic]", color)
    _line("  OpenAI       gpt-4o                     synth[openai]", color)
    _line("  Gemini       gemini/gemini-2.0-flash    synth[google]", color)
    _line("  Llama        ollama/llama3.2            synth[ollama]", color)
    _line("  AgentCore    bedrock/us.anthropic.*     synth[agentcore]", color)
    _blank()

    _section("ENVIRONMENT VARIABLES", color)
    _line("  ANTHROPIC_API_KEY       Anthropic provider", color)
    _line("  OPENAI_API_KEY          OpenAI provider", color)
    _line("  GOOGLE_API_KEY          Google Gemini provider", color)
    _line("  SYNTH_TRACE_ENDPOINT    OTEL trace export URL (HTTPS)", color)
    _line("  SYNTH_NO_BANNER=1       Suppress boot sequence", color)
    _blank()

    _section("LINKS", color)
    _line("  Docs:    https://github.com/synth-agent-sdk", color)
    _line("  PyPI:    https://pypi.org/project/synth-agent-sdk/", color)
    _blank()


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _supports_color() -> bool:
    """Check if the terminal supports colour output."""
    import os
    import sys
    if os.environ.get("NO_COLOR"):
        return False
    if not hasattr(sys.stdout, "isatty"):
        return False
    return sys.stdout.isatty()


def _section(title: str, color: bool) -> None:
    """Print a section header."""
    styled = click.style(f"  ── {title} ", fg="green") if color else f"  -- {title} "
    click.echo(styled)
    click.echo("")


def _line(text: str, color: bool) -> None:
    """Print a plain line."""
    click.echo(text)


def _blank() -> None:
    """Print a blank line."""
    click.echo("")


def _cmd(cmd: str, desc: str, color: bool) -> None:
    """Print a command + description row."""
    styled_cmd = click.style(f"  {cmd}", fg="cyan") if color else f"  {cmd}"
    click.echo(f"{styled_cmd}")
    click.echo(click.style(f"      {desc}", dim=True) if color else f"      {desc}")


def _workflow(title: str, steps: list[str], color: bool) -> None:
    """Print a workflow block."""
    styled = click.style(f"  {title}:", fg="yellow") if color else f"  {title}:"
    click.echo(styled)
    for step in steps:
        click.echo(click.style(f"    {step}", dim=True) if color else f"    {step}")
    click.echo("")
