"""Agent discovery — scan the workspace for agent files and check deployment status.

Provides ``discover_agents()`` which walks the local directory tree
looking for Python files that define an ``agent`` variable, and
``prompt_agent_selection()`` which presents an interactive picker.
"""

from __future__ import annotations

import importlib.util
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import click


@dataclass
class DiscoveredAgent:
    """A locally discovered agent file with optional deployment metadata."""

    file: str
    name: str
    model: str = ""
    has_agentcore_yaml: bool = False
    is_deployed: bool = False
    aws_region: str = ""
    cloud_status: str = ""
    agent_id: str = ""


def discover_agents(root: str = ".") -> list[DiscoveredAgent]:
    """Scan *root* for Python files that define an ``agent`` variable.

    Looks for ``agent.py`` and ``agent_*.py`` files, attempts a
    lightweight AST-free check (grep for ``agent = Agent(``), and
    inspects sibling ``agentcore.yaml`` for deployment metadata.

    Parameters
    ----------
    root:
        Directory to scan (defaults to CWD).

    Returns
    -------
    list[DiscoveredAgent]
        Agents found, sorted by file path.
    """
    agents: list[DiscoveredAgent] = []
    root_path = Path(root).resolve()

    for dirpath, dirnames, filenames in os.walk(root):
        # Skip hidden dirs, __pycache__, dist, node_modules, .venv
        dirnames[:] = [
            d for d in dirnames
            if not d.startswith(".")
            and d not in ("__pycache__", "dist", "node_modules",
                          ".venv", "venv", "ui")
        ]

        for fname in filenames:
            if not fname.endswith(".py"):
                continue
            if not (fname == "agent.py"
                    or fname.startswith("agent_")):
                continue

            fpath = Path(dirpath) / fname
            # Quick text check — avoid importing arbitrary code
            try:
                content = fpath.read_text(encoding="utf-8")
            except Exception:
                continue

            if "agent" not in content or "Agent(" not in content:
                continue

            rel = str(fpath.relative_to(root_path))
            agent_dir = fpath.parent

            # Extract agent name from the directory
            agent_name = agent_dir.name
            if agent_dir == root_path:
                agent_name = fpath.stem

            # Check for agentcore.yaml
            ac_yaml = agent_dir / "agentcore.yaml"
            has_ac = ac_yaml.exists()

            # Try to extract model string
            model = ""
            model_match = re.search(
                r'model\s*=\s*["\']([^"\']+)["\']', content,
            )
            if model_match:
                model = model_match.group(1)

            # Check deployment status via agentcore.yaml
            aws_region = ""
            is_deployed = False
            if has_ac:
                try:
                    yaml_text = ac_yaml.read_text(encoding="utf-8")
                    for yline in yaml_text.splitlines():
                        yline = yline.strip()
                        if yline.startswith("aws_region:"):
                            aws_region = (
                                yline.split(":", 1)[1]
                                .strip().strip("\"'")
                            )
                        if yline.startswith("deployed:"):
                            val = (
                                yline.split(":", 1)[1]
                                .strip().lower()
                            )
                            is_deployed = val == "true"
                except Exception:
                    pass

            agents.append(DiscoveredAgent(
                file=rel,
                name=agent_name,
                model=model,
                has_agentcore_yaml=has_ac,
                is_deployed=is_deployed,
                aws_region=aws_region,
            ))

    agents.sort(key=lambda a: a.file)
    return agents


def prompt_agent_selection(
    agents: list[DiscoveredAgent],
) -> DiscoveredAgent | None:
    """Present an interactive agent picker.

    Parameters
    ----------
    agents:
        List of discovered agents.

    Returns
    -------
    DiscoveredAgent | None
        The selected agent, or ``None`` if the user cancels.
    """
    click.echo("")
    click.echo(click.style(
        "  Discovered agents:", fg="cyan",
    ))
    click.echo("")

    for i, ag in enumerate(agents, 1):
        status = ""
        if ag.cloud_status:
            status = _format_cloud_status(ag.cloud_status)
        elif ag.has_agentcore_yaml:
            if ag.is_deployed:
                status = click.style(
                    " [deployed]", fg="green",
                )
            else:
                status = click.style(
                    " [not deployed]", fg="yellow",
                )

        model_info = ""
        if ag.model:
            model_info = click.style(
                f" ({ag.model})", dim=True,
            )

        click.echo(
            f"    {click.style(str(i), fg='green')}. "
            f"{ag.name}"
            f"{model_info}"
            f"{status}"
            f"  {click.style(ag.file, dim=True)}"
        )

    click.echo("")

    choice = click.prompt(
        click.style("  Select agent (number)", fg="cyan"),
        type=click.IntRange(1, len(agents)),
        default=1,
    )

    return agents[choice - 1]


def ensure_deployed(agent: DiscoveredAgent) -> bool:
    """Check if an AgentCore agent is deployed; offer to deploy if not.

    When the agent has an ``agentcore.yaml`` but is not yet deployed,
    prompts the user to deploy before opening the interactive REPL.
    If the agent is already live, prints a confirmation and returns
    immediately.

    Parameters
    ----------
    agent:
        The discovered agent to check.

    Returns
    -------
    bool
        ``True`` if the agent is deployed (or was just deployed),
        ``False`` if the user declined deployment.
    """
    if not agent.has_agentcore_yaml:
        return True

    # If we already confirmed live status via cloud check, skip
    if agent.cloud_status == "ACTIVE":
        click.echo("")
        click.echo(click.style(
            f"  Agent '{agent.name}' is live on AgentCore "
            f"({agent.aws_region}).",
            fg="green",
        ))
        return True

    if agent.is_deployed and agent.cloud_status != "FAILED":
        return True

    click.echo("")
    click.echo(click.style(
        f"  Agent '{agent.name}' is not deployed to AgentCore.",
        fg="yellow",
    ))

    if not click.confirm(
        click.style("  Deploy now?", fg="cyan"),
        default=True,
    ):
        click.echo(click.style(
            "  Skipping deployment. You can deploy later with: "
            f"synth deploy --target agentcore {agent.file}",
            dim=True,
        ))
        return False

    from synth.cli.deploy_cmd import run_deploy

    run_deploy(
        target="agentcore",
        dry_run=False,
        file=agent.file,
    )
    agent.is_deployed = True
    agent.cloud_status = "ACTIVE"
    return True


# -------------------------------------------------------------------
# Cloud status helpers
# -------------------------------------------------------------------

_STATUS_COLORS: dict[str, str] = {
    "ACTIVE": "green",
    "CREATING": "cyan",
    "UPDATING": "cyan",
    "FAILED": "red",
    "DELETING": "yellow",
    "UNKNOWN": "yellow",
}


def _format_cloud_status(status: str) -> str:
    """Return a styled status badge for terminal display."""
    color = _STATUS_COLORS.get(status, "white")
    return click.style(f" [{status.lower()}]", fg=color)


def check_agentcore_status(
    agents: list[DiscoveredAgent],
) -> list[DiscoveredAgent]:
    """Enrich agents with live deployment status from AgentCore.

    Queries the AgentCore CLI (``agentcore list``) to determine which
    agents are actually deployed in the AWS account.  Falls back to the
    local ``agentcore.yaml`` ``deployed`` flag when the CLI is
    unavailable or the call fails.

    Parameters
    ----------
    agents:
        Agents discovered locally.  Only those with
        ``has_agentcore_yaml=True`` are checked.

    Returns
    -------
    list[DiscoveredAgent]
        The same list, mutated in place with ``cloud_status`` and
        ``agent_id`` populated where possible.
    """
    ac_agents = [a for a in agents if a.has_agentcore_yaml]
    if not ac_agents:
        return agents

    deployed_map = _query_agentcore_cli(ac_agents)

    for ag in ac_agents:
        info = deployed_map.get(ag.name)
        if info is not None:
            ag.cloud_status = info.get("status", "UNKNOWN")
            ag.agent_id = info.get("agent_id", "")
            ag.is_deployed = ag.cloud_status == "ACTIVE"
        elif ag.is_deployed:
            # Local yaml says deployed but cloud doesn't know about it
            ag.cloud_status = "UNKNOWN"

    return agents


def _query_agentcore_cli(
    agents: list[DiscoveredAgent],
) -> dict[str, dict[str, str]]:
    """Run ``agentcore list`` and parse the output.

    Returns a mapping of ``{agent_name: {status, agent_id}}`` for
    agents found in the account.  Returns an empty dict on any failure.
    """
    import shutil
    import subprocess
    import sys
    from pathlib import Path

    agentcore_bin = shutil.which("agentcore")
    if not agentcore_bin:
        scripts_dir = Path(sys.executable).parent
        candidate = scripts_dir / (
            "agentcore.exe" if sys.platform == "win32" else "agentcore"
        )
        if candidate.exists():
            agentcore_bin = str(candidate)

    if not agentcore_bin:
        return {}

    # Determine region from the first agent that has one configured
    region = ""
    aws_profile: str | None = None
    for ag in agents:
        if ag.aws_region:
            region = ag.aws_region
            break

    # Read aws_profile from the first agent's agentcore.yaml
    for ag in agents:
        ac_yaml = Path(ag.file).parent / "agentcore.yaml"
        if ac_yaml.exists():
            try:
                text = ac_yaml.read_text(encoding="utf-8")
                for line in text.splitlines():
                    line = line.strip()
                    if line.startswith("aws_profile:"):
                        aws_profile = (
                            line.split(":", 1)[1].strip().strip("\"'")
                        )
                        break
            except Exception:
                pass
            if aws_profile:
                break

    sub_env = os.environ.copy()
    if aws_profile:
        sub_env["AWS_PROFILE"] = aws_profile
    sub_env["PYTHONIOENCODING"] = "utf-8"
    sub_env["PYTHONWARNINGS"] = "ignore"

    cmd = [agentcore_bin, "list"]
    if region:
        cmd.extend(["--region", region])

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
            env=sub_env,
        )
        if result.returncode != 0:
            return {}

        return _parse_agentcore_list(result.stdout)

    except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
        return {}


def _parse_agentcore_list(output: str) -> dict[str, dict[str, str]]:
    """Parse the tabular output of ``agentcore list``.

    Expected format (columns separated by whitespace)::

        NAME            STATUS    AGENT_ID
        my-agent        ACTIVE    abc-123
        other-agent     CREATING  def-456

    Returns
    -------
    dict[str, dict[str, str]]
        ``{name: {status, agent_id}}``.
    """
    result: dict[str, dict[str, str]] = {}
    lines = output.strip().splitlines()

    # Skip header line(s) — look for the first line that doesn't
    # look like a separator or header
    data_lines = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        # Skip separator lines (e.g., "---  ------  --------")
        if set(stripped.replace(" ", "")) <= {"-", "="}:
            continue
        data_lines.append(stripped)

    if len(data_lines) < 2:
        # Only header or empty — no agents listed
        return result

    # First data line is the header; rest are agent rows
    for row in data_lines[1:]:
        parts = row.split()
        if len(parts) >= 2:
            name = parts[0]
            status = parts[1].upper()
            agent_id = parts[2] if len(parts) >= 3 else ""
            result[name] = {"status": status, "agent_id": agent_id}

    return result
