"""``synth run`` command — execute an agent with a prompt."""

from __future__ import annotations

import importlib.util
import sys

import click

from synth.errors import SynthError


def run_agent(file: str, prompt: str) -> None:
    """Load an agent from *file*, execute with *prompt*, print result."""
    try:
        agent = _load_agent(file)
        result = agent.run(prompt)

        # Print result text to stdout (pipeable)
        click.echo(result.text)

        # Print trace summary to stderr
        click.echo(
            f"\n--- Trace: {result.tokens.total_tokens} tokens | "
            f"${result.cost:.4f} | {result.latency_ms:.0f}ms ---",
            err=True,
        )
    except SynthError as exc:
        click.echo(click.style(f"Error: {exc}", fg="red"), err=True)
        click.echo(click.style(f"Suggestion: {exc.suggestion}", fg="yellow"), err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(click.style(f"Unexpected error: {exc}", fg="red"), err=True)
        click.echo("Run 'synth doctor' to check your environment.", err=True)
        sys.exit(1)


def _load_agent(file: str):
    """Import a Python file and return the ``agent`` variable."""
    spec = importlib.util.spec_from_file_location("_agent_module", file)
    if spec is None or spec.loader is None:
        click.echo(click.style(f"Cannot load '{file}'.", fg="red"), err=True)
        sys.exit(1)

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    if not hasattr(module, "agent"):
        click.echo(
            click.style(
                f"File '{file}' must define an 'agent' variable.",
                fg="red",
            ),
            err=True,
        )
        sys.exit(1)

    return module.agent
