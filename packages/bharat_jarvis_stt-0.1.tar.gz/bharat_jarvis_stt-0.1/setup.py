from setuptools import setup, find_packages

setup(
    name='Bharat_Jarvis_stt',
    version='0.1',
    author='Parth Rai & Amogh',
    author_email='parthrai60924@gmail.com',
    description='This is Bharat Jarvis created by Parth Rai with helper Amogh Pandey both are studying in Sunbeam School Mau (U.P)',
    packages=find_packages(),
    install_requires=[
        'selenium',
        'webdriver-manager'
    ],
)
