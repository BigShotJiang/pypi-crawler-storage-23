from setuptools import setup, find_packages
import os

# 读取README.md
def read_file(filename):
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            return f.read()
    except:
        return "Audio Player By DVS - Advanced audio processing and playback library"

# 获取README内容
long_description = read_file("README.md")

setup(
    name="ap_ds",
    version="2.3.6",  # 更新为2.3.6版本
    description="Audio Player By DVS - Advanced audio processing and playback",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="DVS",
    author_email="me@dvsyun.top",
    url="https://www.dvsyun.top/ap_ds",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        # 自定义许可信息
        "License :: Other/Proprietary License",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: MacOS",
        "Operating System :: POSIX :: Linux",  # 添加Linux支持
        "Operating System :: Unix",  # 添加Unix支持
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Multimedia :: Sound/Audio",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="audio music player playback sdl2 dvs",
    python_requires=">=3.7",
    install_requires=[],  # 纯Python依赖
    include_package_data=True,
    # 添加许可证信息 - 根据要求修改
    license="License information can be found in the PyPi documentation or official website: dvsyun.top/ap.ds",
    # 确保包含所有必要的文件
    package_data={
        '': ['*.md', '*.txt', '*.py'],  # 包含所有markdown和文本文件
    },
    # 添加项目URLs
    project_urls={
        'Documentation': 'https://www.dvsyun.top/ap.ds',
        'Source': 'https://github.com/dvs/ap_ds',  # 如果有GitHub仓库可以修改
        'License Info': 'https://www.dvsyun.top/ap.ds',
    },
)
