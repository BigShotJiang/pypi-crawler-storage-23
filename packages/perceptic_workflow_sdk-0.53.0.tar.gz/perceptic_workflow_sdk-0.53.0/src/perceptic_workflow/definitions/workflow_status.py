# (c) Copyright 2025 Perceptic Technologies Ltd. All rights reserved.
#
# AUTO-GENERATED FILE - DO NOT EDIT
# Generated from: workflow-status.schema.json

from __future__ import annotations


from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel



class WorkflowStatus(BaseModel):
    """
    Workflow-specific status payload returned by the workflow status query.
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        frozen=True,
    )

    status: str
    """
    Workflow-defined status identifier.
    """

    description: str
    """
    Human-readable workflow status details.
    """

