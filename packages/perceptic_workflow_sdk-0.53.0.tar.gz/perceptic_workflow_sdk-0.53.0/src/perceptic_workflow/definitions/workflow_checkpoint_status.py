# (c) Copyright 2025 Perceptic Technologies Ltd. All rights reserved.
#
# AUTO-GENERATED FILE - DO NOT EDIT
# Generated from: workflow-checkpoint-status.schema.json

from __future__ import annotations

from enum import Enum


class WorkflowCheckpointStatus(str, Enum):
    """Status of a workflow checkpoint."""

    ACCEPTED = "ACCEPTED"
    COMPLETED = "COMPLETED"
    REJECTED = "REJECTED"
