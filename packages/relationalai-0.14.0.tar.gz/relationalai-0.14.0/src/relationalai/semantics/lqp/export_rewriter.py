#----------------------------------------------------------------------------------------------
# This is a custom LQP rewriter that filters extra columns from CSV export. It is used in the
# LQP executor, when the format="csv", to ensure only intended columns are being exported.
#----------------------------------------------------------------------------------------------

from dataclasses import replace
from lqp import ir as lqp_ir

class ExtraColumnsFilter:

    def __init__(self, original_cols: list[str]):
        self.original_cols = set(original_cols)

    def filter_read(self, read: lqp_ir.Read) -> lqp_ir.Read:
        """Filter data_columns to only include columns in original_cols."""
        if not isinstance(read.read_type, lqp_ir.Export):
            return read

        config = read.read_type.config
        assert isinstance(config, lqp_ir.ExportCSVConfig) and config.data_columns is not None, \
            "Expected ExportCSVConfig with data_columns in the read type"

        data_columns = config.data_columns

        new_data_columns = [col for col in data_columns if col.column_name in self.original_cols]

        # Reconstruct the nested structure with filtered data_columns
        new_config = replace(config, data_columns=new_data_columns)
        new_read_type = replace(read.read_type, config=new_config)
        new_read = replace(read, read_type=new_read_type)

        return new_read
