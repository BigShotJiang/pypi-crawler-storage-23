import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Literal, Optional, Tuple, Union

import frontmatter
import git
from dotenv import find_dotenv, load_dotenv
from git.repo.fun import BadName, BadObject, name_to_object
from modaic_client import get_modaic_client, settings
from modaic_client.exceptions import (
    AuthenticationError,
    ModaicError,
    RepositoryNotFoundError,
    RevisionNotFoundError,
)

from .module_utils import (
    add_metadata_to_readme,
    copy_update_from,
    copy_update_program_dir,
    create_sync_dir,
    smart_link,
    sync_dir_from,
)
from .utils import aggresive_rmtree

if TYPE_CHECKING:
    from .precompiled import PrecompiledProgram, Retriever
    from .probe import ProbeModel

env_file = find_dotenv(usecwd=True)
load_dotenv(env_file)


@dataclass
class Commit:
    """
    Represents a commit in a git repository.
    Args:
        repo: The path to the git repository.
        sha: The full commit SHA.
    """

    repo: str
    sha: str

    def __repr__(self):
        return f"{self.repo}@{self.sha}"

    def __str__(self):
        return f"{self.repo}@{self.sha}"


def create_remote_repo(repo_path: str, access_token: str, exist_ok: bool = False, private: bool = False) -> bool:
    """Deprecated: Use ModaicClient.create_repo instead."""
    return get_modaic_client().create_repo(repo_path, exist_ok=exist_ok, private=private, access_token=access_token)


def _has_ref(repo: git.Repo, ref: str) -> bool:
    try:
        repo.rev_parse(ref)
        return True
    except BadName:
        return False


def _attempt_push(repo: git.Repo, branch: str, tag: Optional[str] = None) -> None:
    refs = [branch]
    if tag:
        try:
            repo.git.tag(tag)
        except git.exc.GitCommandError:
            raise ModaicError(f"tag: {tag} already exists") from None
        refs.append(tag)

    try:
        repo.remotes.origin.push(refs)
    except git.exc.GitCommandError as e:  # handle nothing to push error
        raise ModaicError(f"Git push failed: {e.stderr}") from None


def sync_and_push(
    module: Union["PrecompiledProgram", "Retriever", "ProbeModel"],
    repo_path: str,
    access_token: Optional[str] = None,
    commit_message: str = "(no commit message)",
    private: bool = False,
    branch: str = "main",
    tag: str = None,
    with_code: bool = False,
    metadata: dict = None,
) -> Commit:
    """
    1. Syncs a non-git repository to a git repository.
    2. Pushes the git repository to modaic hub.

    Args:
        sync_dir: The 'sync' directory containing the desired layout of symlinks to the source code files.
        repo_path: The path on Modaic hub to create the remote repository. e.g. "user/repo"
        access_token: The access token to use for authentication.
        commit_message: The message to use for the commit.
        private: Whether the repository should be private. Defaults to False.
        branch: The branch to push to. Defaults to "main".
        tag: The tag to push to. Defaults to None.
        metadata: The metadata to add to the commit. Defaults to None.
    Warning:
        This is not the standard pull/push workflow. No merging/rebasing is done.
        This simply pushes new changes to make main mirror the local directory.

    Warning:
        Assumes that the remote repository exists
    """
    # First create the sync directory which will be used to update the git repository.
    # if module was loaded from AutoProgram/AutoRetriever, we will use its source repo from settings.modaic_cache/modaic_hub to update the repo_dir
    # other wise bootstrap sync_dir from working directory.
    if module._from_auto:
        sync_dir = sync_dir_from(module._source)
    else:
        sync_dir = create_sync_dir(repo_path, module, with_code=with_code)
    save_auto_json = with_code and not module._from_auto
    is_probe = hasattr(module, "_is_probe") and module._is_probe
    if is_probe:
        module.save(sync_dir)
    else:
        module.save_precompiled(sync_dir, _with_auto_classes=save_auto_json)

    if not access_token and settings.modaic_token:
        access_token = settings.modaic_token
    elif not access_token and not settings.modaic_token:
        raise AuthenticationError("settings.modaic_token is not set")

    if "/" in branch:
        raise ModaicError(
            f"Branch name '{branch}' is invalid. Must be a single branch name without any remote prefix (e.g., 'main', not 'origin/main')"
        )

    if "/" not in repo_path:
        raise NotImplementedError(
            "Modaic fast paths not yet implemented. Please load programs with 'user/repo' or 'org/repo' format"
        )
    assert repo_path.count("/") <= 1, f"Extra '/' in repo_path: {repo_path}"
    # TODO: try pushing first and on error create the repo. create_remote_repo currently takes ~1.5 seconds to run
    create_remote_repo(repo_path, access_token, exist_ok=True, private=private)

    repo_dir = settings.staging_dir / repo_path
    repo_dir.mkdir(parents=True, exist_ok=True)

    # Initialize git as git repo if not already initialized.
    repo = git.Repo.init(repo_dir)
    remote_url = _make_git_url(repo_path, access_token)
    try:
        if "origin" not in [r.name for r in repo.remotes]:
            repo.create_remote("origin", remote_url)
        else:
            repo.remotes.origin.set_url(remote_url)

        try:
            repo.remotes.origin.fetch()
        except git.exc.GitCommandError as e:
            if "repository" in e.stderr.lower() and "not found" in e.stderr.lower():
                raise RepositoryNotFoundError(f"Repository '{repo_path}' does not exist") from None
            else:
                raise ModaicError(f"Git fetch failed: {e.stderr}") from None

        # Handle main branch separately. Get latest version of main, add changes, and push.
        if branch == "main":
            try:
                repo.git.switch("-C", "main", "origin/main")
            except git.exc.GitCommandError:
                pass
            _sync_repo(sync_dir, repo_dir, mirror=not is_probe, metadata=metadata)
            repo.git.add("-A")
            # git commit exits non-zero when there is nothing to commit (clean tree).
            # Treat that as a no-op, but bubble up unexpected commit errors.
            _smart_commit(repo, commit_message, access_token)
            _attempt_push(repo, "main", tag)
            return Commit(repo_path, repo.head.commit.hexsha)

        # Ensure existence of main branch.
        # first attempt to sync main branch with origin
        try:
            repo.git.switch("-C", "main", "origin/main")
        # if that fails we must add changes to main and push.
        except git.exc.GitCommandError:
            _sync_repo(sync_dir, repo_dir, mirror=not is_probe, metadata=metadata)
            repo.git.add("-A")
            _smart_commit(repo, commit_message, access_token)
            repo.remotes.origin.push("main")

        # Now that main exists, switch to target branch and sync.
        # Switch to the branch or create it if it doesn't exist. And ensure it is up to date.
        try:
            repo.git.switch("-C", branch, f"origin/{branch}")
        except git.exc.GitCommandError:
            # if origin/branch does not exist this is a new branch
            # if source_commit is provided, start the new branch there
            if module._source_commit and _has_ref(repo, module._source_commit.sha):
                repo.git.switch("-C", branch, module._source_commit.sha)
            # otherwise start the new branch from main
            else:
                repo.git.switch("-C", branch)

        _sync_repo(sync_dir, repo_dir, mirror=not is_probe, metadata=metadata)
        repo.git.add("-A")

        # Handle error when working tree is clean (nothing to commit)
        _smart_commit(repo, commit_message, access_token)
        _attempt_push(repo, branch, tag)
        return Commit(repo_path, repo.head.commit.hexsha)
    except Exception as e:
        try:
            aggresive_rmtree(repo_dir)
        except Exception:
            raise ModaicError(
                f"Failed to cleanup settings.modaic_cache after a failed operation. We recommend manually deleting your modaic cache as it may be corrupted. Your cache is located at {settings.modaic_cache}"
            ) from e
        raise e


def _smart_commit(repo: git.Repo, commit_message: str, access_token: str) -> None:
    user_info = get_user_info(access_token)
    repo.git.config("user.email", user_info["email"])
    repo.git.config("user.name", user_info["name"])
    try:
        repo.git.commit("-m", commit_message)
    except git.exc.GitCommandError as e:
        if "nothing to commit" in str(e).lower():
            raise ModaicError("Nothing to commit") from None
        raise ModaicError(f"Git commit failed: {e.stderr}") from e


def get_headers(access_token: str) -> Dict[str, str]:
    """Deprecated: Use ModaicClient._get_git_headers instead."""
    return get_modaic_client()._get_git_headers(access_token=access_token)


@lru_cache(maxsize=32)
def get_user_info(access_token: str) -> Dict[str, Any]:
    """
    Returns the user info for the given access token.
    Caches the result in-process by access_token.

    Returns:
        Dict with keys: login, email, avatar_url, name
    """
    return get_modaic_client().get_user_info(access_token=access_token)


# TODO:
def git_snapshot(
    repo_path: str,
    *,
    rev: str = "main",
    access_token: Optional[str] = None,
) -> Tuple[Path, Optional[Commit]]:
    """
    Ensure a local cached checkout of a hub repository and return its path.

    Args:
      repo_path: Hub path ("user/repo").
      rev: Branch, tag, or full commit SHA to checkout; defaults to "main".

    Returns:
      Absolute path to the local cached repository under settings.modaic_hub_cache/repo_path.
    """

    if access_token is None and settings.modaic_token is not None:
        access_token = settings.modaic_token

    program_dir = Path(settings.modaic_hub_cache) / repo_path
    main_dir = program_dir / "main"

    try:
        main_dir.parent.mkdir(parents=True, exist_ok=True)
        remote_url = _make_git_url(repo_path, access_token)

        # Ensure we have a main checkout at program_dir/main
        if not (main_dir / ".git").exists():
            shutil.rmtree(main_dir, ignore_errors=True)
            git.Repo.clone_from(remote_url, main_dir, multi_options=["--branch", "main"])

        # Attatch origin
        main_repo = git.Repo(main_dir)
        if "origin" not in [r.name for r in main_repo.remotes]:
            main_repo.create_remote("origin", remote_url)
        else:
            main_repo.remotes.origin.set_url(remote_url)

        main_repo.remotes.origin.fetch()

        revision = resolve_revision(main_repo, rev)

        if revision.type == "commit" or revision.type == "tag":
            rev_dir = program_dir / revision.sha

            if not rev_dir.exists():
                main_repo.git.worktree("add", str(rev_dir.resolve()), revision.sha)

            shortcut_dir = program_dir / revision.name
            shortcut_dir.unlink(missing_ok=True)
            smart_link(shortcut_dir, rev_dir)

        elif revision.type == "branch":
            rev_dir = program_dir / revision.name

            if not rev_dir.exists():
                main_repo.git.worktree("add", str(rev_dir.resolve()), f"origin/{revision.name}")
            else:
                repo = git.Repo(rev_dir)
                repo.remotes.origin.pull(revision.name)

            # get the up to date sha for the branch
            revision = resolve_revision(main_repo, f"origin/{revision.name}")

        return rev_dir, Commit(repo_path, revision.sha)

    except Exception as e:
        try:
            aggresive_rmtree(program_dir)
        except Exception:
            raise ModaicError(
                f"Failed to cleanup settings.modaic_cache after a failed operation. We recommend manually deleting your modaic cache as it may be corrupted. Your cache is located at {settings.modaic_cache}"
            ) from e
        if isinstance(e, git.exc.GitCommandError):
            if "remote: Not found." in e.stderr:
                raise RepositoryNotFoundError(f"Repository '{repo_path}' does not exist") from None
        raise e


def _move_to_commit_sha_folder(repo: git.Repo) -> git.Repo:
    """
    Moves the repo to a new path based on the commit SHA. (Unused for now)
    Args:
        repo: The git.Repo object.

    Returns:
        The new git.Repo object.
    """
    commit = repo.head.commit
    repo_dir = Path(repo.working_dir)
    new_path = repo_dir / commit.hexsha
    repo_dir.rename(new_path)
    return git.Repo(new_path)


def load_repo(
    repo_path: str, access_token: Optional[str] = None, is_local: bool = False, rev: str = "main"
) -> Tuple[Path, Optional[Commit]]:
    if is_local:
        path = Path(repo_path)
        if not path.exists():
            raise FileNotFoundError(f"Local repo path {repo_path} does not exist")
        return path, None
    else:
        return git_snapshot(repo_path, access_token=access_token, rev=rev)


@dataclass
class Revision:
    """
    Represents a revision of a git repository.
    Args:
        type: The type of the revision. e.g. "branch", "tag", "commit"
        name: The name of the revision. e.g. "main", "v1.0.0", "1234567"
        sha: Full commit SHA of the revision. e.g. "1234567890abcdef1234567890abcdef12345678" (None for branches)
    """

    type: Literal["branch", "tag", "commit"]
    name: str
    sha: str


def resolve_revision(repo: git.Repo, rev: str) -> Revision:
    """
    Resolves the revision to a branch, tag, or commit SHA.
    Args:
        repo: The git.Repo object.
        rev: The revision to resolve.

    Returns:
        Revision dataclass where:
          - type ∈ {"branch", "tag", "commit"}
          - name is the normalized name:
              - branch: branch name without any remote prefix (e.g., "main", not "origin/main")
              - tag: tag name (e.g., "v1.0.0")
              - commit: full commit SHA
          - sha is the target commit SHA for branch/tag, or the commit SHA itself for commit
    Raises:
        ValueError: If the revision is not a valid branch, tag, or commit SHA.

    Example:
        >>> resolve_revision(repo, "main")
        Revision(type="branch", name="main", sha="<sha>")
        >>> resolve_revision(repo, "v1.0.0")
        Revision(type="tag", name="v1.0.0", sha="<sha>")
        >>> resolve_revision(repo, "1234567890")
        Revision(type="commit", name="<sha>", sha="<sha>")
    """
    repo.remotes.origin.fetch()

    # Fast validation of rev; if not found, try origin/<rev> for branches existing only on remote
    try:
        ref = repo.rev_parse(rev)
    except BadName:
        try:
            ref = repo.rev_parse(f"origin/{rev}")
        except BadName:
            raise RevisionNotFoundError(
                f"Revision '{rev}' is not a valid branch, tag, or commit SHA", rev=rev
            ) from None
        else:
            rev = f"origin/{rev}"

    if not isinstance(ref, git.objects.Commit):
        raise RevisionNotFoundError(f"Revision '{rev}' is not a valid branch, tag, or commit SHA", rev=rev) from None

    # Try to resolve to a reference where possible (branch/tag), else fallback to commit
    try:
        ref = name_to_object(repo, rev, return_ref=True)
    except BadObject:
        pass

    # Commit SHA case
    if isinstance(ref, git.objects.Commit):
        full_sha = ref.hexsha
        return Revision(type="commit", name=full_sha[:7], sha=full_sha)

    # refs/tags/<tag>
    m_tag = re.match(r"^refs/tags/(?P<tag>.+)$", ref.name)
    if m_tag:
        tag_name = m_tag.group("tag")
        commit_sha = ref.commit.hexsha  # TagReference.commit returns the peeled commit
        return Revision(type="tag", name=tag_name, sha=commit_sha)

    # refs/heads/<branch>
    m_head = re.match(r"^refs/heads/(?P<branch>.+)$", ref.name)
    if m_head:
        branch_name = m_head.group("branch")
        commit_sha = ref.commit.hexsha
        return Revision(type="branch", name=branch_name, sha=commit_sha)

    # refs/remotes/<remote>/<branch> (normalize branch name without remote, e.g., drop 'origin/')
    m_remote = re.match(r"^refs/remotes/(?P<remote>[^/]+)/(?P<branch>.+)$", ref.name)
    if m_remote:
        branch_name = m_remote.group("branch")
        commit_sha = ref.commit.hexsha
        return Revision(type="branch", name=branch_name, sha=commit_sha)

    # Some refs may present as "<remote>/<branch>" or just "<branch>" in name; handle common forms
    m_remote_simple = re.match(r"^(?P<remote>[^/]+)/(?P<branch>.+)$", ref.name)
    if m_remote_simple:
        branch_name = m_remote_simple.group("branch")
        commit_sha = ref.commit.hexsha
        return Revision(type="branch", name=branch_name, sha=commit_sha)

    # If we still haven't matched, attempt to treat as a tag/branch name directly
    # Try heads/<name>
    try:
        possible_ref = name_to_object(repo, f"refs/heads/{ref.name}", return_ref=True)
        commit_sha = possible_ref.commit.hexsha
        return Revision(type="branch", name=ref.name, sha=commit_sha)
    except Exception:
        pass
    # Try tags/<name>
    try:
        possible_ref = name_to_object(repo, f"refs/tags/{ref.name}", return_ref=True)
        commit_sha = possible_ref.commit.hexsha
        return Revision(type="tag", name=ref.name, sha=commit_sha)
    except Exception:
        pass

    # As a last resort, if it peels to a commit, return commit
    try:
        commit_obj = repo.commit(ref.name)
        full_sha = commit_obj.hexsha
        return Revision(type="commit", name=full_sha, sha=full_sha)
    except Exception:
        raise RevisionNotFoundError(f"Revision '{rev}' is not a valid branch, tag, or commit SHA", rev=rev) from None


# Not in use currently
def _update_staging_dir(
    module: Union["PrecompiledProgram", "Retriever"],
    repo_dir: Path,
    repo_path: str,
    with_code: bool = False,
    source: Optional[Path] = None,
):
    # if source is not None then module was loaded with AutoProgram/AutoRetriever, we will use its source repo from settings.modaic_cache/modaic_hub to update the repo_dir
    if source and sys.platform.startswith("win"):
        # Windows - source provided: Copy code from source into repo_dir
        copy_update_from(repo_dir, source)
    elif source and not sys.platform.startswith("win"):
        # Linux/Unix - source provided: Sync code from source into repo_dir (uses symlinks)
        sync_dir = sync_dir_from(source)
        _sync_repo(sync_dir, repo_dir)
    elif not source and sys.platform.startswith("win"):
        # Windows - no source provided: Copy code from workspace into repo_dir
        copy_update_program_dir(repo_dir, repo_path, with_code=with_code)
    elif not source and not sys.platform.startswith("win"):
        # Linux/Unix - no source provided: Sync code from workspace into repo_dir (uses symlinks)
        sync_dir = create_sync_dir(repo_path, module, with_code=with_code)
        _sync_repo(sync_dir, repo_dir)

    # save auto_classes.json only if we are saving the code and not using a source repo
    save_auto_json = with_code and not source
    module.save_precompiled(repo_dir, _with_auto_classes=save_auto_json)


def _sync_repo(sync_dir: Path, repo_dir: Path, mirror: bool = True, metadata: dict = None) -> None:
    """Syncs a 'sync' directory containing the a desired layout of symlinks to the source code files to the 'repo' directory a git repository tracked by modaic hub"""
    original_readme_path = repo_dir / "README.md"
    text = original_readme_path.read_text(encoding="utf-8") if original_readme_path.exists() else ""
    post = frontmatter.loads(text)
    original_metadata = post.metadata
    if sys.platform.startswith("win"):
        cmd = [
            "robocopy",
            f"{sync_dir.resolve()}/",
            f"{repo_dir.resolve()}/",
        ]
        if mirror:
            cmd.append("/MIR")
        cmd.extend(
            [
                "/XD",
                ".git",  # make sure .git is not deleted
            ]
        )
        subprocess.run(cmd)
    else:
        cmd = [
            "rsync",
            "-aL",
        ]
        if mirror:
            cmd.append("--delete")
        cmd.extend(
            [
                "--ignore-times",  # rsync usually looks at edit times to determine if it should skip a file.  Disabling this behavior is useful for our pytest-suite.
                f"{sync_dir.resolve()}/",
                f"{repo_dir.resolve()}/",
                "--exclude",
                ".git",  # make sure .git is not deleted
            ]
        )
        subprocess.run(cmd)

    if metadata is not None:
        readme_path = repo_dir / "README.md"
        if not readme_path.exists():
            readme_path.write_text("", encoding="utf-8")
            metadata = original_metadata | metadata
        add_metadata_to_readme(readme_path, metadata)


def _make_git_url(repo_path: str, access_token: Optional[str] = None) -> str:
    protocol = "https://" if settings.modaic_git_url.startswith("https://") else "http://"

    if access_token is None:
        return f"{protocol}{settings.modaic_git_url.replace('https://', '').replace('http://', '')}/{repo_path}.git"
    else:
        username = get_user_info(access_token)["login"]
        return f"{protocol}{username}:{access_token}@{settings.modaic_git_url.replace('https://', '').replace('http://', '')}/{repo_path}.git"
