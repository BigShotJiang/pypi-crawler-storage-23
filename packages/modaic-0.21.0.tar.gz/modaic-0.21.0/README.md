# modaic

A Python framework for packaging and reproducing DSPy programs.

## Installation

```bash
pip install modaic
```

## Documentation

Full documentation at [docs.modaic.dev](https://docs.modaic.dev).
