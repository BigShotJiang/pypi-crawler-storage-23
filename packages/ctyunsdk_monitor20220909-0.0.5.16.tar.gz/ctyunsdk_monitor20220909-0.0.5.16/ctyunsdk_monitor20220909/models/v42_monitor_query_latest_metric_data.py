from typing import Optional, List

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V42MonitorQueryLatestMetricDataRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    service: str  # 云监控服务，具体服务参见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    dimension: str  # 云监控维度，具体维度参见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    itemNameList: List[str]  # 待查监控项名称，单次请求长度限制为10，具体设备对应监控项参见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    dimensions: List['V42MonitorQueryLatestMetricDataRequestDimensions']  # 查询设备标签列表，用于定位要查询监控数据的目标设备，多标签查询取交集，单次请求设备数量限制为10

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V42MonitorQueryLatestMetricDataRequestDimensions:
    name: str  # 设备标签键，取值范围参考[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)响应的dimensions字段。<br>以云主机为例，该字段为uuid。
    value: List[str]  # 设备标签键所对应的值，最大数量限制为10。<br>以云主机为例，该字段为云主机的instanceID。


@dataclass_json
@dataclass
class V42MonitorQueryLatestMetricDataResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V42MonitorQueryLatestMetricDataReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V42MonitorQueryLatestMetricDataReturnObj:
    itemList: Optional[List['V42MonitorQueryLatestMetricDataReturnObjItemList']] = None  # 监控项数据


@dataclass_json
@dataclass
class V42MonitorQueryLatestMetricDataReturnObjItemList:
    itemName: Optional[str] = None  # 监控项名称，具体设备对应监控项参见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    itemDesc: Optional[str] = None  # 监控项中文介绍
    itemUnit: Optional[str] = None  # 监控项单位
    value: Optional[float] = None  # 监控项值，具体请参考对应监控项文档
    timestamp: Optional[int] = None  # 监控数据采样Unix时间戳
    dimensions: Optional[List['V42MonitorQueryLatestMetricDataReturnObjItemListDimensions']] = None  # 监控项标签


@dataclass_json
@dataclass
class V42MonitorQueryLatestMetricDataReturnObjItemListDimensions:
    name: Optional[str] = None  # 监控项标签键
    value: Optional[str] = None  # 监控项标签键对应的值
