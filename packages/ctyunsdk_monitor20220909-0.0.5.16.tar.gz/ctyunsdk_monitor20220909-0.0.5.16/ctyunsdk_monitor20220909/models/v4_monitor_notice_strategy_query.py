from typing import Optional, List

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorNoticeStrategyQueryRequest(CtyunOpenAPIRequest):
    service: Optional[str] = None  # 云监控服务。取值范围： <br />ecs：云主机。 <br />evs：云硬盘。 <br />pms：物理机。 <br />... <br />具体服务参见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    dimension: Optional[str] = None  # 云监控维度。取值范围： <br />ecs：云主机。 <br />disk：云硬盘。 <br />pms：物理机。 <br />... <br />具体服务参见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    noticeStrategyName: Optional[str] = None  # 策略名称（支持模糊搜索），长度2-40个字符
    pageNo: Optional[int] = None  # 页码，默认为1
    pageSize: Optional[int] = None  # 页大小，默认为10

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorNoticeStrategyQueryResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorNoticeStrategyQueryReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorNoticeStrategyQueryReturnObj:
    noticeStrategyList: Optional[List[object]] = None  # 通知模板
    totalCount: Optional[int] = None  # 总记录数
    currentCount: Optional[int] = None  # 当前页记录数
    totalPage: Optional[int] = None  # 总页数
