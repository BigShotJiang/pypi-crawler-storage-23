from typing import Optional, List

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorQueryItemsRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    service: Optional[str] = None  # 云监控服务，取值范围：参见本接口返回
    dimension: Optional[str] = None  # 云监控维度，取值范围：参见本接口返回
    itemType: Optional[str] = None  # 本参数表示监控项类型。不传返回全部类型。取值范围：<br>series：指标类型。<br>event：事件类型。<br>根据以上范围取值。
    isEnterpriseProject: Optional[bool] = None  # 是否支持企业项目
    ignoreItems: Optional[bool] = None  # 是否展示监控项详情，默认值：false，展示监控项详情。

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQueryItemsResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorQueryItemsReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQueryItemsReturnObj:
    data: Optional[List['V4MonitorQueryItemsReturnObjData']] = None  # 统计信息列表


@dataclass_json
@dataclass
class V4MonitorQueryItemsReturnObjData:
    service: Optional[str] = None  # 云监控服务
    description: Optional[str] = None  # 描述
    dimensions: Optional[List['V4MonitorQueryItemsReturnObjDataDimensions']] = None  # 维度列表
    serviceCount: Optional[int] = None  # 服务下监控项数量


@dataclass_json
@dataclass
class V4MonitorQueryItemsReturnObjDataDimensions:
    dimension: Optional[str] = None  # 云监控维度
    description: Optional[str] = None  # 描述
    monitorItems: Optional[List['V4MonitorQueryItemsReturnObjDataDimensionsMonitorItems']] = None  # 监控资源列表
    dimensionCount: Optional[int] = None  # 维度下监控项数量


@dataclass_json
@dataclass
class V4MonitorQueryItemsReturnObjDataDimensionsMonitorItems:
    name: Optional[str] = None  # 监控项的key
    metricName: Optional[str] = None  # 监控项名称
    description: Optional[str] = None  # 监控指标描述
    unit: Optional[str] = None  # 指标单位
    unitRelations: Optional[List['V4MonitorQueryItemsReturnObjDataDimensionsMonitorItemsUnitRelations']] = None  # 单位转换字典
    dimensions: Optional[List[str]] = None  # 设备标签列表
    isAlarm: Optional[int] = None  # 本参数表示是否支持告警。取值范围：<br>0：不支持。<br>1：支持。<br>根据以上范围取值。
    isEvent: Optional[int] = None  # 本参数表示是否为事件类型。取值范围：<br>0：事件类型。<br>1：指标类型。<br>根据以上范围取值。
    period: Optional[int] = None  # 上报周期
    statistics: Optional[List[str]] = None  # 本参数表示趋势计算类型。取值范围：<br>max：最大值。<br>&#32;min：最小值。<br>&#32;avg：平均值。<br>&#32;sum：求和。<br>var：方差。<br>origin：原始值。<br>根据以上范围取值。
    itemType: Optional[int] = None  # 本参数表示监控项类型。取值范围：<br>0：实例指标。<br>1：分组指标。<br>根据以上范围取值。
    metricClass: Optional[str] = None  # 监控类英文名
    metricClassName: Optional[str] = None  # 监控类名称


@dataclass_json
@dataclass
class V4MonitorQueryItemsReturnObjDataDimensionsMonitorItemsUnitRelations:
    unit: Optional[str] = None  # 单位
    weight: Optional[float] = None  # 权重
