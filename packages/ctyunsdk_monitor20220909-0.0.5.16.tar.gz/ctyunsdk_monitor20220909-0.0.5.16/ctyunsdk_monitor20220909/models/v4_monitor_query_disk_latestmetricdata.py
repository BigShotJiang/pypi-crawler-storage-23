from typing import Optional, List

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorQueryDiskLatestmetricdataRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    deviceUUIDList: List[str]  # 查询设备ID列表，具体值参考监控对象查询返回字段deviceUUID
    pageNo: Optional[int] = None  # 页码，默认为1
    page: Optional[int] = None  # 页码，默认为1，建议使用pageNo，该参数后续会下线
    pageSize: Optional[int] = None  # 页大小，默认为20

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQueryDiskLatestmetricdataResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorQueryDiskLatestmetricdataReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQueryDiskLatestmetricdataReturnObj:
    result: Optional[List['V4MonitorQueryDiskLatestmetricdataReturnObjResult']] = None  # 返回数据结果
    totalCount: Optional[int] = None  # 获取对象数据条数
    totalPage: Optional[int] = None  # 总页数
    currentCount: Optional[int] = None  # 当前页记录数
    page: Optional[int] = None  # 页码，建议参考请求参数pageNo，该参数后续会下线
    pageSize: Optional[int] = None  # 页大小，建议参考请求参数pageSize，该参数后续会下线


@dataclass_json
@dataclass
class V4MonitorQueryDiskLatestmetricdataReturnObjResult:
    regionID: Optional[str] = None  # 所属资源池ID
    fUID: Optional[str] = None  # 唯一键
    fuserLastUpdated: Optional[str] = None  # 最近更新时间
    deviceUUID: Optional[str] = None  # 设备ID
    itemList: Optional['V4MonitorQueryDiskLatestmetricdataReturnObjResultItemList'] = None  # 监控项内容


@dataclass_json
@dataclass
class V4MonitorQueryDiskLatestmetricdataReturnObjResultItemList:
    samplingTime: Optional[int] = None  # 监控数据采集时间
    item1: Optional[str] = None  # 监控项具体内容
    item2: Optional[str] = None  # 监控项具体内容
