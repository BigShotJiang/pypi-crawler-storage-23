from typing import Optional, List

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorQuerySiteEventRequest(CtyunOpenAPIRequest):
    taskID: str  # 站点监控任务 ID
    startTime: int  # 查询起始时间戳，秒级
    endTime: int  # 查询截止时间戳，秒级
    pageNo: Optional[int] = None  # 页码，默认为1
    pageSize: Optional[int] = None  # 页大小，默认为10

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQuerySiteEventResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorQuerySiteEventReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQuerySiteEventReturnObj:
    totalCount: Optional[int] = None  # 获取对象数据条数
    totalPage: Optional[int] = None  # 总页数
    currentCount: Optional[int] = None  # 当前页记录数
    eventList: Optional[List['V4MonitorQuerySiteEventReturnObjEventList']] = None  # 事件列表


@dataclass_json
@dataclass
class V4MonitorQuerySiteEventReturnObjEventList:
    taskID: Optional[str] = None  # 站点监控任务 ID
    time: Optional[str] = None  # 事件发生时间
    name: Optional[str] = None  # 事件名称
    description: Optional[str] = None  # 事件描述
    pointID: Optional[str] = None  # 探测节点唯一ID
    pointName: Optional[str] = None  # 探测节点名称
    pointIP: Optional[str] = None  # 探测节点IP
    targetAddr: Optional[str] = None  # 探测目标地址
    targetIP: Optional[str] = None  # 探测目标IP
    dnsServer: Optional[str] = None  # DNS服务器
    responseTime: Optional[str] = None  # 响应时间
    errCode: Optional[int] = None  # 错误码
    detail: Optional[object] = None  # 事件详情
