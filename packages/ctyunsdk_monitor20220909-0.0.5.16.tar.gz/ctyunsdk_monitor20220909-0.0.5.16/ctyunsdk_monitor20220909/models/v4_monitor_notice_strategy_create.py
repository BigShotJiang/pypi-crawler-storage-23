from typing import Optional, List

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorNoticeStrategyCreateRequest(CtyunOpenAPIRequest):
    noticeStrategyName: str  # 策略名称，长度2-40个字符
    service: str  # 云监控服务。取值范围： <br />ecs：云主机。 <br />evs：云硬盘。 <br />pms：物理机。 <br />... <br />具体服务参见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    dimension: str  # 云监控维度。取值范围： <br />ecs：云主机。 <br />disk：云硬盘。 <br />pms：物理机。 <br />... <br />具体服务参见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    isConverge: bool  # 是否收敛，默认值：false
    notice: Optional[object] = None  # 通知配置信息
    description: Optional[str] = None  # 策略描述，长度2-40个字符
    converge: Optional[object] = None  # 收敛配置信息
    webhook: Optional[List[object]] = None  # webhook配置信息

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorNoticeStrategyCreateResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorNoticeStrategyCreateReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorNoticeStrategyCreateReturnObj:
    noticeStrategyID: Optional[str] = None  # 通知策略ID
