from typing import Optional, List

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V41MonitorQueryLatestMetricDataRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    deviceType: str  # 设备类型。取值范围：<br>vm：云主机。<br>bare_metal：裸金属。<br>disk：云磁盘。<br>scaling：弹性伸缩。<br>traffic：共享带宽。<br>eip：弹性IP。<br>elb：负载均衡。<br>listener：监听器。<br>cstor_sfs：弹性文件。<br>site_monitor：站点监控。<br>natgw：NAT网关。<br>zos_bucket：对象存储-存储桶。<br>zos_user：对象存储-用户。<br>vnet_monitor_endpoint_statistic：VPC终端节点。<br>vnet_endpoint_service_statistic：VPC终端节点服务。<br>ipsec_vpn_gw_stats：VPN网关。<br>ipsec_vpn_conn_stats：VPN IPsec连接。<br>ssl_vpn_user_stats：VPN SSL客户端。<br>ssl_vpn_nwi_session_count：VPN SSL连接。<br>mrgw_qos_stats_job：流量镜像。<br>vnet_monitor_mc_statistic：组播。<br>cda_physical_line：云专线-物理专线。<br>cda_virtual_gateway_base：云专线-专线网关。<br>cda_virtual_gateway：云专线-专线网关健康检查。<br>根据以上范围取值。
    deviceUUIDList: List[str]  # 查询设备ID列表，具体值参考接口：监控对象查询系列返回字段deviceUUID

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V41MonitorQueryLatestMetricDataResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V41MonitorQueryLatestMetricDataReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V41MonitorQueryLatestMetricDataReturnObj:
    result: Optional[List['V41MonitorQueryLatestMetricDataReturnObjResult']] = None  # 返回数据结果


@dataclass_json
@dataclass
class V41MonitorQueryLatestMetricDataReturnObjResult:
    regionID: Optional[str] = None  # 所属资源池ID
    deviceUUID: Optional[str] = None  # 设备ID
    itemList: Optional[List['V41MonitorQueryLatestMetricDataReturnObjResultItemList']] = None  # 监控项内容


@dataclass_json
@dataclass
class V41MonitorQueryLatestMetricDataReturnObjResultItemList:
    itemName: Optional[str] = None  # 监控项名称，具体设备对应监控项参见[监控项列表：查询](https://www.ctyun.cn/document/10032263/10039882)
    value: Optional[str] = None  # 监控项值，具体请参考对应监控项文档
    samplingTime: Optional[int] = None  # 监控数据采集时间
