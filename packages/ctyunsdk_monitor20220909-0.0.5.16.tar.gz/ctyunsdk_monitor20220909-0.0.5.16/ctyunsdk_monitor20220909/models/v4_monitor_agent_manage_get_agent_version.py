from typing import Optional, List

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorAgentManageGetAgentVersionRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    ecsInfo: Optional['V4MonitorAgentManageGetAgentVersionRequestEcsInfo'] = None  # 云主机信息，和物理机信息至少一个不为空
    pmsInfo: Optional['V4MonitorAgentManageGetAgentVersionRequestPmsInfo'] = None  # 物理机信息，和云主机信息至少一个不为空

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorAgentManageGetAgentVersionRequestEcsInfo:
    instanceIDList: List[str]  # 云主机ID列表
    version: Optional[str] = None  # 云主机指定的agent版本号


@dataclass_json
@dataclass
class V4MonitorAgentManageGetAgentVersionRequestPmsInfo:
    instanceIDList: List[str]  # 物理机ID列表
    version: Optional[str] = None  # 物理机指定的agent版本号


@dataclass_json
@dataclass
class V4MonitorAgentManageGetAgentVersionResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorAgentManageGetAgentVersionReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorAgentManageGetAgentVersionReturnObj:
    ecsList: Optional[List['V4MonitorAgentManageGetAgentVersionReturnObjEcsList']] = None  # 云主机列表
    pmsList: Optional[List['V4MonitorAgentManageGetAgentVersionReturnObjPmsList']] = None  # 物理机列表


@dataclass_json
@dataclass
class V4MonitorAgentManageGetAgentVersionReturnObjEcsList:
    instanceName: Optional[str] = None  # 实例名称
    instanceID: Optional[str] = None  # 实例ID
    systemType: Optional[str] = None  # 本参数表示操作系统类型。取值范围：<br>windows：windows。<br>linux：linux。<br>根据以上范围取值。
    version: Optional[str] = None  # 云主机agent版本号
    compareResult: Optional[str] = None  # 本参数表示云主机agent当前版本和指定版本号的比较结果，当不指定版本号时，为equal。取值范围：<br>higher：更高。<br>equal：相等。<br>lower：更低。<br>unknown：未知。<br>根据以上范围取值。


@dataclass_json
@dataclass
class V4MonitorAgentManageGetAgentVersionReturnObjPmsList:
    instanceName: Optional[str] = None  # 实例名称
    instanceID: Optional[str] = None  # 实例ID
    systemType: Optional[str] = None  # 本参数表示操作系统类型。取值范围：<br>windows：windows。<br>linux：linux。<br>根据以上范围取值。
    version: Optional[str] = None  # 物理机agent版本号
    compareResult: Optional[str] = None  # 本参数表示物理机agent当前版本和指定版本号的比较结果，当不指定版本号时，为equal。取值范围：<br>higher：更高。<br>equal：相等。<br>lower：更低。<br>根据以上范围取值。
