from typing import Optional, List

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    service: str  # 本参数表示云监控服务。取值范围：<br>ecs：云主机。<br>...<br>具体服务参见[云监控：查询服务维度及监控项](https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=22&api=15746&data=90&isNormal=1&vid=84)
    dimension: str  # 本参数表示云监控维度。取值范围：<br>ecs：云主机。<br>...<br>具体服务参见[云监控：查询服务维度及监控项](https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=22&api=15746&data=90&isNormal=1&vid=84)
    viewType: str  # 视图类型。取值范围：<br>timeSeries：折线图。<br>gauge：仪表盘。<br>barChart：柱状图。<br>table：表格。<br>pieChart：饼状图。<br>根据以上范围取值。
    itemNameList: List[str]  # 监控指标，指标项最多支持20个， 当viewType为gauge和pieChart时，仅支持单监控指标
    resources: List['V4MonitorMonitorBoardPreviewViewDataRequestResources']  # 监控资源实例，监控对象最多支持20个， 当viewType为gauge时，仅支持单资源实例
    startTime: Optional[int] = None  # 查询起始Unix时间戳,  startTime和endTime成对使用，且时间间隔不超过90天
    endTime: Optional[int] = None  # 查询结束Unix时间戳，  startTime和endTime成对使用，且时间间隔不超过90天
    fun: Optional[str] = None  # 本参数表示聚合类型。默认值为avg。取值范围:<br>raw：原始值。<br>avg：平均值。<br>min：最小值。<br>max：最大值。<br>variance：方差。<br>sum：求和。<br>根据以上范围取值。
    period: Optional[int] = None  # 聚合周期，单位：秒，默认300，需不小于60，推荐使用60的整倍数。当fun为raw时本参数无效。
    name: Optional[str] = None  # 监控视图名称
    compares: Optional[List[str]] = None  # 同比环比比较时间配置，格式为“数字+单位”，单位为空时默认为秒。<br>当前只支持1d和7d。<br>单位取值范围：<br>m：分钟。<br>h：小时。<br>d：天。<br>根据以上范围取值。
    gaugePattern: Optional['V4MonitorMonitorBoardPreviewViewDataRequestGaugePattern'] = None  # 仪表盘配置，仅当viewType为gauge时生效

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataRequestResources:
    resource: List['V4MonitorMonitorBoardPreviewViewDataRequestResourcesResource']  # 资源


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataRequestResourcesResource:
    key: str  # 资源实例标签键
    value: str  # 资源实例标签值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataRequestGaugePattern:
    minVal: Optional[int] = None  # 仪表盘最小值。默认值为0
    maxVal: Optional[int] = None  # 仪表盘最大值。默认值为100
    threshold: Optional[List[int]] = None  # 仪表盘中间分段取值，长度必须为2。默认值为[30,80]


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorMonitorBoardPreviewViewDataReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObj:
    viewID: Optional[str] = None  # 视图ID
    viewName: Optional[str] = None  # 视图名称
    viewType: Optional[str] = None  # 视图类型。取值范围:<br>timeSeries：折线图。<br>gauge：仪表盘。<br>barChart：柱状图。<br>table：表格。<br>pieChart：饼状图。<br>根据以上范围取值。
    monitorType: Optional[str] = None  # 视图属性。取值范围:<br>metric：指标。<br>resource：实例。<br>根据以上范围取值。
    viewData: Optional['V4MonitorMonitorBoardPreviewViewDataReturnObjViewData'] = None  # 数据


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewData:
    timeSeriesData: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTimeSeriesData']] = None  # 折线图数据
    barChartData: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataBarChartData']] = None  # 柱状图数据
    gaugeData: Optional['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataGaugeData'] = None  # 仪表盘数据
    pieChartData: Optional['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataPieChartData'] = None  # 饼状图数据
    tableData: Optional['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTableData'] = None  # 表格数据


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTimeSeriesData:
    itemName: Optional[str] = None  # 监控项名称
    itemDesc: Optional[str] = None  # 监控项中文介绍
    itemUnit: Optional[str] = None  # 监控项单位
    unitRelations: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTimeSeriesDataUnitRelations']] = None  # 单位转换字典
    compareType: Optional[str] = None  # 本参数表示比较类型。取值范围:<br>1d：环比。<br>7d：同比。<br>0d：原始。<br>根据以上范围取值。
    itemData: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTimeSeriesDataItemData']] = None  # 折线图数据
    dimensions: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTimeSeriesDataDimensions']] = None  # 监控项标签
    resource: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTimeSeriesDataResource']] = None  # 资源


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTimeSeriesDataUnitRelations:
    unit: Optional[str] = None  # 单位
    weight: Optional[float] = None  # 权重


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTimeSeriesDataItemData:
    value: Optional[float] = None  # 监控项值，具体请参考对应监控项文档
    timestamp: Optional[int] = None  # 监控数据Unix时间戳


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTimeSeriesDataDimensions:
    name: Optional[str] = None  # 监控项标签键
    value: Optional[str] = None  # 监控项标签键对应的值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTimeSeriesDataResource:
    key: Optional[str] = None  # 资源实例标签键
    value: Optional[str] = None  # 资源实例标签值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataBarChartData:
    itemName: Optional[str] = None  # 监控项名称
    itemDesc: Optional[str] = None  # 监控项中文介绍
    itemUnit: Optional[str] = None  # 监控项单位
    unitRelations: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataBarChartDataUnitRelations']] = None  # 单位转换字典
    compareType: Optional[str] = None  # 本参数表示比较类型。取值范围:<br>1d：环比。<br>7d：同比。<br>0d：原始。<br>根据以上范围取值。
    itemData: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataBarChartDataItemData']] = None  # 柱状图数据
    dimensions: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataBarChartDataDimensions']] = None  # 监控项标签
    resource: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataBarChartDataResource']] = None  # 资源


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataBarChartDataUnitRelations:
    unit: Optional[str] = None  # 单位
    weight: Optional[float] = None  # 权重


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataBarChartDataItemData:
    value: Optional[float] = None  # 监控项值，具体请参考对应监控项文档
    timestamp: Optional[int] = None  # 监控数据Unix时间戳


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataBarChartDataDimensions:
    name: Optional[str] = None  # 监控项标签键
    value: Optional[str] = None  # 监控项标签键对应的值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataBarChartDataResource:
    key: Optional[str] = None  # 资源实例标签键
    value: Optional[str] = None  # 资源实例标签值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataGaugeData:
    itemName: Optional[str] = None  # 监控项名称
    itemDesc: Optional[str] = None  # 监控项中文介绍
    itemUnit: Optional[str] = None  # 监控项单位
    rawValue: Optional[str] = None  # 监控项原始值
    compareData: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataGaugeDataCompareData']] = None  # 比较数据
    minValue: Optional[int] = None  # 表盘最小值
    maxValue: Optional[int] = None  # 表盘最大值
    threshold: Optional[List[int]] = None  # 表盘阈值
    resource: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataGaugeDataResource']] = None  # 资源


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataGaugeDataCompareData:
    value: Optional[str] = None  # 监控项值，具体请参考对应监控项文档
    compareType: Optional[str] = None  # 本参数表示比较类型。取值范围:<br>1d：环比。<br>7d：同比。<br>根据以上范围取值。


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataGaugeDataResource:
    key: Optional[str] = None  # 资源实例标签键
    value: Optional[str] = None  # 资源实例标签值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataPieChartData:
    itemName: Optional[str] = None  # 监控项名称
    itemDesc: Optional[str] = None  # 监控项中文介绍
    itemUnit: Optional[str] = None  # 监控项单位
    itemData: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataPieChartDataItemData']] = None  # 饼图数据


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataPieChartDataItemData:
    rawValue: Optional[float] = None  # 监控项原始值
    compareData: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataPieChartDataItemDataCompareData']] = None  # 比较数据
    resource: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataPieChartDataItemDataResource']] = None  # 资源
    proportion: Optional[str] = None  # 占比


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataPieChartDataItemDataCompareData:
    value: Optional[str] = None  # 监控项值，具体请参考对应监控项文档
    compareType: Optional[str] = None  # 本参数表示比较类型。取值范围:<br>1d：环比。<br>7d：同比。<br>根据以上范围取值。


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataPieChartDataItemDataResource:
    key: Optional[str] = None  # 资源实例标签键
    value: Optional[str] = None  # 资源实例标签值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTableData:
    tableHead: Optional[List[str]] = None  # 表头
    itemData: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTableDataItemData']] = None  # 表格数据


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTableDataItemData:
    service: Optional[str] = None  # 服务
    dimension: Optional[str] = None  # 维度
    dimensions: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTableDataItemDataDimensions']] = None  # 监控项标签
    timestamp: Optional[int] = None  # 监控数据Unix时间戳
    itemName: Optional[str] = None  # 监控项名称
    itemDesc: Optional[str] = None  # 监控项中文介绍
    itemUnit: Optional[str] = None  # 监控项单位
    rawValue: Optional[float] = None  # 监控项原始值
    compareData: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTableDataItemDataCompareData']] = None  # 比较数据
    resource: Optional[List['V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTableDataItemDataResource']] = None  # 资源


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTableDataItemDataDimensions:
    name: Optional[str] = None  # 监控项标签键
    value: Optional[str] = None  # 监控项标签键对应的值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTableDataItemDataCompareData:
    value: Optional[str] = None  # 监控项值，具体请参考对应监控项文档
    compareType: Optional[str] = None  # 本参数表示比较类型。取值范围:<br>1d：环比。<br>7d：同比。<br>根据以上范围取值。


@dataclass_json
@dataclass
class V4MonitorMonitorBoardPreviewViewDataReturnObjViewDataTableDataItemDataResource:
    key: Optional[str] = None  # 资源实例标签键
    value: Optional[str] = None  # 资源实例标签值
