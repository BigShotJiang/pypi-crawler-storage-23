from typing import Optional, List

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorDescribeSiteMonitorRequest(CtyunOpenAPIRequest):
    taskID: str  # 站点监控任务 ID

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorDescribeSiteMonitorResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorDescribeSiteMonitorReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorDescribeSiteMonitorReturnObj:
    taskID: Optional[str] = None  # 站点监控任务ID
    taskName: Optional[str] = None  # 站点监控任务名称，支持中英文
    protocol: Optional[str] = None  # 本参数表示探测类型。取值范围：<br>http：http探测。<br>ping：ping探测。<br>tcp：tcp探测。<br>udp：udp探测。<br>pagehttp：浏览器探测。<br>根据以上范围取值。
    address: Optional[str] = None  # 站点地址。<br>ping示例：www.ctyun.cn<br>tcp/udp示例：www.ctyun.cn:80<br>http示例：http://www.ctyun.cn或https://www.ctyun.cn
    evalInterval: Optional[int] = None  # 本参数表示探测间隔，单位秒。取值范围：<br>60：60s。<br>300：300s。<br>1200：1200s。<br>1800：1800s。<br>根据以上范围取值。
    probePoint: Optional[List[str]] = None  # 探测节点ID列表
    status: Optional[bool] = None  # 状态
    options: Optional['V4MonitorDescribeSiteMonitorReturnObjOptions'] = None  # 拨测参数
    lastChange: Optional[str] = None  # 最近更新时间


@dataclass_json
@dataclass
class V4MonitorDescribeSiteMonitorReturnObjOptions:
    httpMethod: Optional[str] = None  # 本参数表示HTTP方法。取值范围：<br>GET：GET方法。<br>POST：POST方法。<br>HEAD：HEAD方法。<br>根据以上范围取值。
    headers: Optional[str] = None  # 请求头信息，多个换行分隔
    cookies: Optional[str] = None  # 请求Cookies，多个用逗号分隔
    redirectLimit: Optional[int] = None  # 重定向次数限制
    verifySkip: Optional[bool] = None  # 本参数表示是否跳过验证校验。取值范围：<br>true：跳过。<br>false：不跳过。<br>根据以上范围取值。
    timeout: Optional[int] = None  # 超时时间，单位毫秒
    authUser: Optional[str] = None  # 用户名
    authPwd: Optional[str] = None  # 加密后的密码
    bodyContent: Optional[str] = None  # 请求体内容，json字符串
    dnsServer: Optional[str] = None  # DNS服务器
    dnsHijackWhiteList: Optional[str] = None  # DNS劫持白名单，冒号前为要判断的域名，冒号后为白名单ip地址，多个ip用竖线分隔
    weekdays: Optional[List[int]] = None  # 本参数表示拨测日列表。
    startTime: Optional[str] = None  # 拨测起始时段
    endTime: Optional[str] = None  # 拨测结束时段
    responseAssertions: Optional[List[object]] = None  # Response断言，当条件均满足时，则判断为正常
    deviceType: Optional[str] = None  # 本参数表示设备类型。取值范围：<br>PC：PC端。<br>根据以上范围取值。
    browserType: Optional[str] = None  # 本参数表示浏览器。取值范围：<br>Chrome：Chrome浏览器。<br>根据以上范围取值。
    autoScrolling: Optional[bool] = None  # 本参数表示自动滚屏是否启动。取值范围：<br>false：不启动。<br>根据以上范围取值。
