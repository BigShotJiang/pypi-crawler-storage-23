from mayan.apps.dependencies.classes import PythonDependency

PythonDependency(
    module=__name__, name='django-solo', version_string='==2.5.1'
)
