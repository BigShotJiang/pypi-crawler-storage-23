from mayan.apps.icons.icons import Icon

icon_ajax_refresh = Icon(
    driver_name='fontawesome', symbol='sync'
)

icon_menu_actions = Icon(driver_name='fontawesome', symbol='ellipsis-v')
icon_menu_views = Icon(driver_name='fontawesome', symbol='eye')
