IMPORT_ERROR_EXCLUSION_TEXTS = (
    'doesn\'t look like a module path', 'No module named'
)
