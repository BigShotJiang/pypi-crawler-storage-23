class AuthenticationError(Exception):
    """Base exception for authentication error."""
