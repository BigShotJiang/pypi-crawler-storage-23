from mayan.apps.icons.icons import Icon

icon_model_property_list = Icon(
    driver_name='fontawesome', symbol='code-commit'
)
icon_property_model_list = Icon(
    driver_name='fontawesome', symbol='window-restore'
)
