class DatabaseWarning(UserWarning):
    """
    Warning when using unsupported database backends.
    """
