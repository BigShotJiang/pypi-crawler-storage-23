from mayan.apps.smart_settings.setting_namespaces import (
    SettingNamespaceMigration
)
from mayan.apps.smart_settings.utils import smart_yaml_load


class ConvertSettingMigration(SettingNamespaceMigration):
    """
    From version 0001 to 0002 backend arguments are no longer quoted
    but YAML valid too. Changed in version 3.3.
    """
    def converter_graphics_backend_arguments_0001(self, value):
        return smart_yaml_load(value=value)
