"""
Core utilities and configuration for LLMaps.

Modules:
- config.py: library configuration
- generator.py: core HTML/MapLibre config generation
- utils.py: shared helpers
"""

