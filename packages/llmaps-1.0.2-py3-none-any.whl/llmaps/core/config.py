"""
Configuration primitives for LLMaps.

Will store defaults for tile providers, template paths and other options.
"""

