
import unittest
from doitagent.config import Config
from doitagent.security.sandbox import Sandbox
from doitagent.agent.memory import Memory
from doitagent.exceptions import DoItAgentError, SecurityError

class TestDoItAgentFunctional(unittest.TestCase):
    def setUp(self):
        self.config = Config()
        self.sandbox = Sandbox(self.config.security)
        self.memory = Memory(max_entries=10)

    def test_sandbox_execution(self):
        """Test that the sandbox can execute safe commands and block unsafe ones."""
        # Safe command
        result = self.sandbox.run("echo 'Functional Test'")
        self.assertTrue(result["success"])
        self.assertIn("Functional Test", result["output"])

        # Unsafe command (should be blocked by sandbox)
        with self.assertRaises(SecurityError):
            self.sandbox.run("rm -rf /")

    def test_memory_operations(self):
        """Test that memory can store and retrieve tasks and skills."""
        # Store a task
        self.memory.add("test task", "test result")
        recent = self.memory.recent(1)
        self.assertEqual(len(recent), 1)
        self.assertEqual(recent[0]["task"], "test task")

        # Store a skill
        self.memory.save_skill("test_skill", "A test skill", ["step 1", "step 2"])
        skill = self.memory.get_skill("test_skill")
        self.assertIsNotNone(skill)
        self.assertEqual(skill["steps"], ["step 1", "step 2"])

    def test_config_defaults(self):
        """Test that default configuration is loaded correctly."""
        self.assertEqual(self.config.llm.backend, "ollama")
        self.assertTrue(self.config.security.safe_mode)

if __name__ == "__main__":
    unittest.main()
