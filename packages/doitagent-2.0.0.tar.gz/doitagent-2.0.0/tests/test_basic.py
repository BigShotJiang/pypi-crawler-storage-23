"""Basic tests for DoItAgent."""

import pytest
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


# ─── Config tests ─────────────────────────────────────────────────────────────

class TestConfig:
    def test_default_config(self):
        from doitagent.config import Config
        cfg = Config()
        assert cfg.llm.backend == "ollama"
        assert cfg.llm.model == "mistral"
        assert cfg.security.safe_mode is True
        assert cfg.daemon.restart_on_crash is True

    def test_config_save_load(self, tmp_path, monkeypatch):
        from doitagent import config as cfg_module
        monkeypatch.setattr(cfg_module, "CONFIG_FILE", tmp_path / "config.json")
        from doitagent.config import Config
        cfg = Config()
        cfg.llm.backend = "openai"
        cfg.llm.model = "gpt-4o"
        # Just test it doesn't crash
        # (keyring may not be available in test env)


# ─── Exception tests ──────────────────────────────────────────────────────────

class TestExceptions:
    def test_base_exception(self):
        from doitagent.exceptions import DoItAgentError
        e = DoItAgentError("test", code="TEST")
        assert str(e) == "[TEST] test"
        assert e.code == "TEST"

    def test_security_error(self):
        from doitagent.exceptions import SecurityError
        e = SecurityError("blocked", action="rm -rf /")
        assert e.code == "SECURITY_ERROR"
        assert e.action == "rm -rf /"

    def test_llm_error(self):
        from doitagent.exceptions import LLMError
        e = LLMError("connection failed", backend="ollama")
        assert e.backend == "ollama"


# ─── Security sandbox tests ────────────────────────────────────────────────────

class TestSandbox:
    def test_classify_critical(self):
        from doitagent.security.sandbox import classify_command, RISK_CRITICAL
        assert classify_command("format c: /fs:ntfs") == RISK_CRITICAL

    def test_classify_high(self):
        from doitagent.security.sandbox import classify_command, RISK_HIGH
        assert classify_command("shutdown /s /t 0") == RISK_HIGH

    def test_classify_low(self):
        from doitagent.security.sandbox import classify_command, RISK_LOW
        assert classify_command("echo hello") == RISK_LOW

    def test_sandbox_blocks_critical(self):
        from doitagent.security.sandbox import Sandbox
        from doitagent.exceptions import SecurityError
        sb = Sandbox()
        with pytest.raises(SecurityError):
            sb.run("format c: /fs:ntfs")

    def test_sandbox_run_safe(self):
        from doitagent.security.sandbox import Sandbox
        sb = Sandbox()
        result = sb.run("echo hello_from_sandbox")
        assert result["success"] is True
        assert "hello_from_sandbox" in result["output"]

    def test_sandbox_python(self):
        from doitagent.security.sandbox import Sandbox
        sb = Sandbox()
        result = sb.run_python("print('sandbox_python_ok')")
        assert result["success"] is True
        assert "sandbox_python_ok" in result["output"]

    def test_audit_log(self):
        from doitagent.security.sandbox import audit_log, get_audit_log
        audit_log("test", "echo hi", "LOW", "ok", approved=True)
        log = get_audit_log(5)
        assert any(e["command"] == "echo hi" for e in log)


# ─── Memory tests ─────────────────────────────────────────────────────────────

class TestMemory:
    def test_add_and_retrieve(self, tmp_path, monkeypatch):
        import doitagent.config as cfg_module
        monkeypatch.setattr(cfg_module, "MEMORY_DIR", tmp_path)
        # Patch HISTORY_FILE and friends used in Memory
        import doitagent.agent.memory as mem_module
        monkeypatch.setattr(mem_module, "HISTORY_FILE", tmp_path / "history.jsonl")
        monkeypatch.setattr(mem_module, "SKILLS_FILE",  tmp_path / "skills.json")
        monkeypatch.setattr(mem_module, "PREFS_FILE",   tmp_path / "preferences.json")

        from doitagent.agent.memory import Memory
        m = Memory(max_entries=100)
        m.add("take a screenshot", "screenshot.png")
        recent = m.recent(1)
        assert len(recent) == 1
        assert recent[0]["task"] == "take a screenshot"

    def test_skill_lifecycle(self, tmp_path, monkeypatch):
        import doitagent.agent.memory as mem_module
        monkeypatch.setattr(mem_module, "HISTORY_FILE", tmp_path / "history.jsonl")
        monkeypatch.setattr(mem_module, "SKILLS_FILE",  tmp_path / "skills.json")
        monkeypatch.setattr(mem_module, "PREFS_FILE",   tmp_path / "preferences.json")

        from doitagent.agent.memory import Memory
        m = Memory()
        m.save_skill("test_skill", "A test skill", ["step1", "step2"])
        skill = m.get_skill("test_skill")
        assert skill is not None
        assert skill["steps"] == ["step1", "step2"]
        assert m.delete_skill("test_skill") is True
        assert m.get_skill("test_skill") is None

    def test_skill_expansion(self, tmp_path, monkeypatch):
        import doitagent.agent.memory as mem_module
        monkeypatch.setattr(mem_module, "HISTORY_FILE", tmp_path / "history.jsonl")
        monkeypatch.setattr(mem_module, "SKILLS_FILE",  tmp_path / "skills.json")
        monkeypatch.setattr(mem_module, "PREFS_FILE",   tmp_path / "preferences.json")

        from doitagent.agent.memory import Memory
        m = Memory()
        m.save_skill("morning", "Morning routine", ["take screenshot", "check email"])
        expanded = m.expand_skill("run morning skill")
        assert "take screenshot" in expanded
        assert "check email" in expanded


# ─── Version test ─────────────────────────────────────────────────────────────

def test_version():
    from doitagent._version import __version__
    parts = __version__.split(".")
    assert len(parts) == 3
    assert all(p.isdigit() for p in parts)


def test_import():
    import doitagent
    assert hasattr(doitagent, "Agent")
    assert hasattr(doitagent, "__version__")
