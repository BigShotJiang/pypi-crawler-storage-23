"""
DoItAgent CLI
=============
Commands:
  doit setup     — Interactive setup wizard (run first!)
  doit start     — Start Telegram bot + watchdog daemon
  doit stop      — Stop the daemon
  doit status    — Show agent status
  doit "task"    — Run a single task
  doit           — Interactive chat mode
  doit --version — Show version
"""

from __future__ import annotations

import os
import sys
import asyncio
import json
import platform
import subprocess
import getpass
import time
from pathlib import Path
from typing import Optional

# ─── Rich console setup ───────────────────────────────────────────────────────

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    from rich.prompt import Prompt, Confirm
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich import box
    RICH = True
except ImportError:
    RICH = False

console = Console() if RICH else None


def _print(msg: str, style: str = ""):
    if RICH and console:
        console.print(msg, style=style)
    else:
        print(msg)


def _ask(prompt: str, default: str = "", password: bool = False) -> str:
    if RICH:
        if password:
            return getpass.getpass(f"  {prompt}: ")
        return Prompt.ask(f"  [cyan]{prompt}[/cyan]", default=default) or default
    val = input(f"  {prompt} [{default}]: ").strip() if default else input(f"  {prompt}: ").strip()
    return val or default


def _confirm(prompt: str, default: bool = True) -> bool:
    if RICH:
        return Confirm.ask(f"  [cyan]{prompt}[/cyan]", default=default)
    ans = input(f"  {prompt} ({'Y/n' if default else 'y/N'}): ").strip().lower()
    if not ans:
        return default
    return ans in ("y", "yes")


def _banner():
    banner_text = """
  ██████╗  ██████╗     ██╗████████╗     █████╗  ██████╗ ███████╗███╗   ██╗████████╗
  ██╔══██╗██╔═══██╗    ██║╚══██╔══╝    ██╔══██╗██╔════╝ ██╔════╝████╗  ██║╚══██╔══╝
  ██║  ██║██║   ██║    ██║   ██║       ███████║██║  ███╗█████╗  ██╔██╗ ██║   ██║
  ██║  ██║██║   ██║    ██║   ██║       ██╔══██║██║   ██║██╔══╝  ██║╚██╗██║   ██║
  ██████╔╝╚██████╔╝    ██║   ██║       ██║  ██║╚██████╔╝███████╗██║ ╚████║   ██║
  ╚═════╝  ╚═════╝     ╚═╝   ╚═╝       ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝"""

    if RICH:
        console.print(banner_text, style="bold cyan")
        console.print(
            "        [yellow]⚡ The World's Most Powerful Personal AGI — v2.0.0[/yellow]\n"
            "        [dim]Control your PC via Telegram · Voice · Code · CLI[/dim]\n"
        )
    else:
        print(banner_text)
        print("  ⚡ The World's Most Powerful Personal AGI — v2.0.0\n")


# ─── Setup Wizard ─────────────────────────────────────────────────────────────

def run_setup():
    """Interactive setup wizard."""
    _banner()
    _print("  [bold]Welcome to DoItAgent Setup[/bold]" if RICH else "  Welcome to DoItAgent Setup")
    _print("  [dim]This configures your personal AGI in ~3 minutes.[/dim]\n" if RICH else "  This configures your AGI in ~3 minutes.\n")

    from doitagent.config import Config, LLMConfig, TelegramConfig, SecurityConfig, DaemonConfig

    cfg = Config.load()

    # ── Step 1: LLM ──────────────────────────────────────────────────────────
    _print("\n  [bold cyan][1/5] AI Brain[/bold cyan]" if RICH else "\n  [1/5] AI Brain")
    _print("  [dim]Choose how the agent thinks.[/dim]\n" if RICH else "  Choose how the agent thinks.\n")

    if RICH:
        t = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
        t.add_column(style="bold yellow")
        t.add_column(style="green")
        t.add_column(style="dim")
        t.add_row("1", "Ollama (LOCAL)", "FREE · No internet · Runs on your GPU/CPU")
        t.add_row("2", "NVIDIA NIM",    "FREE tier · Ultra-fast GPU · nvapi-... key")
        t.add_row("3", "Anthropic",     "Most intelligent · claude-opus-4-6 · API key")
        t.add_row("4", "OpenAI",        "GPT-4o · API key required")
        t.add_row("5", "DeepSeek",      "Cheapest cloud · Nearly free")
        console.print(t)

    choice = _ask("Choice", default="1")
    backend_map = {"1": "ollama", "2": "nvidia", "3": "anthropic", "4": "openai", "5": "deepseek"}
    backend = backend_map.get(choice, "ollama")
    cfg.llm.backend = backend

    if backend == "ollama":
        _check_ollama()
        model_choice = _ask("Model [mistral/llama3/deepseek-r1/phi3]", default="mistral")
        cfg.llm.model = model_choice
        _pull_ollama_model(model_choice)

    elif backend == "nvidia":
        _print("\n  [dim]Get free key at: https://build.nvidia.com[/dim]\n" if RICH else "\n  Get free key: https://build.nvidia.com\n")
        cfg.llm.api_key = _ask("NVIDIA API Key (nvapi-...)", password=True)
        model_options = {
            "1": "meta/llama-3.1-70b-instruct",
            "2": "meta/llama-3.1-405b-instruct",
            "3": "nvidia/llama-3.1-nemotron-70b-instruct",
            "4": "mistralai/mistral-large-2-instruct",
            "5": "deepseek-ai/deepseek-r1",
        }
        _print("  [dim]Models: 1=Llama-70B  2=Llama-405B  3=Nemotron-70B  4=Mistral-Large  5=DeepSeek-R1[/dim]\n" if RICH else "  1=Llama-70B 2=Llama-405B 3=Nemotron 4=Mistral 5=DeepSeek\n")
        m = _ask("Model", default="1")
        cfg.llm.model = model_options.get(m, model_options["1"])

    else:
        key_urls = {
            "anthropic": "https://console.anthropic.com",
            "openai": "https://platform.openai.com/api-keys",
            "deepseek": "https://platform.deepseek.com",
        }
        default_models = {
            "anthropic": "claude-opus-4-6",
            "openai": "gpt-4o",
            "deepseek": "deepseek-chat",
        }
        url = key_urls.get(backend, "")
        _print(f"\n  [dim]Get key at: {url}[/dim]\n" if RICH else f"\n  Get key: {url}\n")
        cfg.llm.api_key = _ask(f"{backend.capitalize()} API Key", password=True)
        cfg.llm.model = default_models.get(backend, "")

    _print(f"\n  [green]✓[/green] Brain: {cfg.llm.backend}/{cfg.llm.model}\n" if RICH else f"\n  ✓ Brain: {cfg.llm.backend}/{cfg.llm.model}\n")

    # ── Step 2: Telegram ─────────────────────────────────────────────────────
    _print("  [bold cyan][2/5] Telegram Bot[/bold cyan]\n" if RICH else "\n  [2/5] Telegram Bot\n")

    setup_tg = _confirm("Connect Telegram? (control PC from anywhere)", default=True)
    if setup_tg:
        _print(
            "  [dim]Steps:\n"
            "  1. Open Telegram → search @BotFather\n"
            "  2. Send: /newbot\n"
            "  3. Give it a name & username\n"
            "  4. Copy the token it gives you\n[/dim]\n"
            if RICH else
            "  1. Telegram → @BotFather → /newbot → copy token\n"
        )
        cfg.telegram.token = _ask("Bot Token (from @BotFather)", password=True)

        _print(
            "\n  [dim]Get your User ID:\n"
            "  → Telegram → search @userinfobot → send any message → copy your ID[/dim]\n"
            if RICH else
            "\n  Get User ID: Telegram → @userinfobot → send msg → copy ID\n"
        )
        uid = _ask("Your Telegram User ID (numbers)", default="")
        if uid.isdigit():
            cfg.telegram.allowed_user_ids = [int(uid)]
        cfg.telegram.require_approval = _confirm("Ask approval before dangerous actions?", default=True)
        _print("  [green]✓[/green] Telegram configured\n" if RICH else "  ✓ Telegram configured\n")
    else:
        _print("  [dim]Skipped. Run 'doit setup' later to add Telegram.[/dim]\n" if RICH else "  Skipped.\n")

    # ── Step 3: Security ─────────────────────────────────────────────────────
    _print("  [bold cyan][3/5] Security[/bold cyan]\n" if RICH else "\n  [3/5] Security\n")
    cfg.security.safe_mode = _confirm("Enable safe mode? (recommended — confirms before deleting files)", default=True)
    cfg.security.sandbox_shell = _confirm("Sandbox shell commands? (runs in isolated temp dir)", default=True)
    cfg.security.audit_log = _confirm("Enable audit log? (logs all executed commands)", default=True)

    # ── Step 4: Daemon ───────────────────────────────────────────────────────
    _print("\n  [bold cyan][4/5] 24/7 Daemon[/bold cyan]\n" if RICH else "\n  [4/5] 24/7 Daemon\n")
    cfg.daemon.auto_start = _confirm("Start DoItAgent automatically on system boot?", default=True)
    cfg.daemon.restart_on_crash = _confirm("Auto-restart if agent crashes?", default=True)
    if cfg.daemon.auto_start:
        from doitagent.daemon.watchdog import setup_autostart
        result = setup_autostart(enable=True)
        _print(f"  [green]✓[/green] {result}\n" if RICH else f"  ✓ {result}\n")

    # ── Step 5: Optional packages ─────────────────────────────────────────────
    _print("  [bold cyan][5/5] Optional Packages[/bold cyan]\n" if RICH else "\n  [5/5] Optional Packages\n")
    install_extra = _confirm("Install all optional packages? (OCR, voice, media — ~200MB)", default=True)
    if install_extra:
        _install_extras()

    # ── Save & finish ─────────────────────────────────────────────────────────
    cfg.save()

    _print("\n" + ("─" * 56))
    _print("\n  [bold green]✅ Setup complete![/bold green]\n" if RICH else "\n  Setup complete!\n")

    if RICH:
        t = Table(title="Your Configuration", box=box.ROUNDED, show_header=False)
        t.add_column("Key", style="cyan")
        t.add_column("Value", style="green")
        t.add_row("Brain",    f"{cfg.llm.backend}/{cfg.llm.model}")
        t.add_row("Telegram", "Configured ✓" if cfg.telegram.token else "Not set")
        t.add_row("Safe Mode",f"{'On' if cfg.security.safe_mode else 'Off'}")
        t.add_row("Daemon",   f"{'Auto-start' if cfg.daemon.auto_start else 'Manual'}")
        console.print(t)

    _print("\n  [bold]Next steps:[/bold]\n" if RICH else "\n  Next steps:\n")
    _print("  [cyan]doit start[/cyan]        — Start Telegram bot (24/7)\n" if RICH else "  doit start       — Start Telegram bot\n")
    _print("  [cyan]doit[/cyan]              — Interactive chat mode\n" if RICH else "  doit             — Interactive chat\n")
    _print("  [cyan]doit \"do something\"[/cyan] — Run a task directly\n\n" if RICH else "  doit 'task'      — Run a task\n\n")

    start_now = _confirm("Start the Telegram bot now?", default=True)
    if start_now:
        _start_bot()


def _check_ollama():
    result = subprocess.run(["ollama", "--version"], capture_output=True, text=True)
    if result.returncode != 0:
        _print("  [yellow]Ollama not found.[/yellow]" if RICH else "  Ollama not found.")
        _print("  [dim]Download from: https://ollama.ai/download[/dim]" if RICH else "  Download: https://ollama.ai")
        if platform.system() == "Windows":
            import webbrowser
            webbrowser.open("https://ollama.ai/download")
        input("  Press ENTER after installing Ollama: ")
    else:
        _print("  [green]✓[/green] Ollama installed" if RICH else "  ✓ Ollama installed")


def _pull_ollama_model(model: str):
    _print(f"\n  [dim]Pulling model {model} (may take a few minutes)...[/dim]\n" if RICH else f"\n  Pulling {model}...\n")
    try:
        subprocess.run(["ollama", "pull", model], check=False)
        _print(f"  [green]✓[/green] Model {model} ready" if RICH else f"  ✓ Model {model} ready")
    except Exception:
        _print(f"  [yellow]Run manually: ollama pull {model}[/yellow]" if RICH else f"  Run: ollama pull {model}")


def _install_extras():
    packages = [
        ("playwright", "Browser automation"),
        ("python-docx openpyxl reportlab pdfplumber", "Document creation"),
        ("duckduckgo-search beautifulsoup4 lxml", "Web search"),
        ("opencv-python pytesseract mss", "Screen vision"),
        ("pyttsx3 pygame psutil pyautogui pyperclip", "System control"),
        ("plyer send2trash apscheduler", "Utilities"),
    ]
    for pkgs, desc in packages:
        _print(f"  Installing {desc}...", end="\r" if not RICH else "")
        subprocess.run(
            [sys.executable, "-m", "pip", "install", *pkgs.split(), "-q",
             "--disable-pip-version-check"],
            capture_output=True
        )
        _print(f"  [green]✓[/green] {desc}         " if RICH else f"  ✓ {desc}")

    # Playwright browsers
    subprocess.run([sys.executable, "-m", "playwright", "install", "chromium", "--quiet"],
                   capture_output=True)


def _start_bot():
    _print("\n  [bold green]Starting DoItAgent Telegram Bot...[/bold green]\n" if RICH else "\n  Starting...\n")
    try:
        from doitagent.telegram.bot import main as bot_main
        bot_main()
    except Exception as e:
        _print(f"  [red]Error: {e}[/red]" if RICH else f"  Error: {e}")


# ─── Main CLI ─────────────────────────────────────────────────────────────────

def main():
    import click

    @click.group(invoke_without_command=True)
    @click.pass_context
    @click.option("--version", is_flag=True, help="Show version")
    @click.option("--verbose", "-v", is_flag=True, help="Verbose output")
    def cli(ctx, version, verbose):
        """DoItAgent — The World's Most Powerful Personal AGI Agent."""
        if version:
            from doitagent._version import __version__
            click.echo(f"doitagent {__version__}")
            return

        if ctx.invoked_subcommand is None:
            # No subcommand → interactive chat or single task from args
            args = sys.argv[1:]
            if args and not args[0].startswith("-"):
                # doit "some task"
                _banner()
                _run_single_task(" ".join(args), verbose=verbose)
            else:
                # doit → interactive mode
                _banner()
                _interactive_mode(verbose=verbose)

    @cli.command()
    def setup():
        """Interactive setup wizard."""
        run_setup()

    @cli.command()
    @click.option("--daemon", is_flag=True, default=True, help="Run with watchdog daemon")
    def start(daemon):
        """Start the Telegram bot (24/7)."""
        _banner()
        if daemon:
            from doitagent.daemon.watchdog import Watchdog, main as watchdog_main
            _print("  Starting watchdog + Telegram bot...\n")
            watchdog_main()
        else:
            _start_bot()

    @cli.command()
    def stop():
        """Stop the running daemon."""
        from doitagent.daemon.watchdog import stop_daemon
        if stop_daemon():
            _print("[green]✓ DoItAgent stopped.[/green]" if RICH else "✓ Stopped.")
        else:
            _print("[yellow]No running daemon found.[/yellow]" if RICH else "No daemon running.")

    @cli.command()
    def status():
        """Show agent and system status."""
        _banner()
        try:
            from doitagent.core import Agent
            ai = Agent()
            ai.print_status()
        except Exception as e:
            _print(f"[red]Error: {e}[/red]" if RICH else f"Error: {e}")

    @cli.command()
    @click.argument("task")
    @click.option("--verbose", "-v", is_flag=True)
    def run(task, verbose):
        """Execute a single task."""
        _run_single_task(task, verbose=verbose)

    @cli.command()
    def listen():
        """Start voice command mode."""
        from doitagent.core import Agent
        ai = Agent()
        ai.listen()

    @cli.command()
    def reset():
        """Reset all configuration."""
        from doitagent.config import CONFIG_FILE
        if _confirm("Reset all configuration?", default=False):
            CONFIG_FILE.unlink(missing_ok=True)
            _print("[green]✓ Config reset. Run 'doit setup' to reconfigure.[/green]" if RICH else "✓ Config reset.")

    try:
        cli(standalone_mode=False)
    except SystemExit:
        pass
    except Exception as e:
        _print(f"\n[red]Error: {e}[/red]\n" if RICH else f"\nError: {e}\n")
        sys.exit(1)


def _run_single_task(task: str, verbose: bool = False):
    try:
        from doitagent.core import Agent
        ai = Agent(verbose=verbose)
        result = ai.do(task)
        if RICH:
            console.print(Panel(str(result), title="✅ Result", style="green"))
        else:
            print(f"\n✅ Result:\n{result}\n")
    except Exception as e:
        _print(f"[red]Error: {e}[/red]\n" if RICH else f"Error: {e}\n")


def _interactive_mode(verbose: bool = False):
    from doitagent.config import Config
    cfg = Config.load()
    if not cfg.is_configured():
        _print("[yellow]Not configured. Running setup...[/yellow]\n" if RICH else "Not configured. Running setup...\n")
        run_setup()
        return

    _print(f"  [dim]Brain: {cfg.llm.backend}/{cfg.llm.model} | Type [bold]exit[/bold] to quit[/dim]\n" if RICH else f"  Brain: {cfg.llm.backend}/{cfg.llm.model} | Type 'exit' to quit\n")

    try:
        from doitagent.core import Agent
        ai = Agent(verbose=verbose)
    except Exception as e:
        _print(f"[red]Failed to start agent: {e}[/red]" if RICH else f"Failed: {e}")
        return

    while True:
        try:
            if RICH:
                task = console.input("[bold cyan]You:[/bold cyan] ").strip()
            else:
                task = input("  You: ").strip()

            if not task:
                continue
            if task.lower() in ("exit", "quit", "q", "bye"):
                _print("[dim]Goodbye![/dim]\n" if RICH else "Goodbye!\n")
                break

            result = ai.do(task)
            if RICH:
                console.print(f"[bold green]Agent:[/bold green] {result}\n")
            else:
                print(f"\n  Agent: {result}\n")

        except KeyboardInterrupt:
            _print("\n[dim]Goodbye![/dim]\n" if RICH else "\nGoodbye!\n")
            break


if __name__ == "__main__":
    main()
