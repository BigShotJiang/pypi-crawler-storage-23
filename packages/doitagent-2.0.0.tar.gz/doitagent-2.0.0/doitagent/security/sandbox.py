"""
Security sandbox for DoItAgent.
Provides:
- Command risk analysis
- Sandboxed shell execution (temp dir, limited scope)
- Audit logging of all executed commands
- Reversible action tracking (undo support)
"""

from __future__ import annotations

import os
import re
import json
import shutil
import tempfile
import logging
import subprocess
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Optional, Callable

from doitagent.config import SecurityConfig, SANDBOX_DIR, LOG_DIR
from doitagent.exceptions import SecurityError

logger = logging.getLogger("doitagent.security")

# ─── Risk classification ──────────────────────────────────────────────────────

RISK_CRITICAL = "CRITICAL"   # Never auto-execute
RISK_HIGH     = "HIGH"       # Require explicit approval
RISK_MEDIUM   = "MEDIUM"     # Warn and log
RISK_LOW      = "LOW"        # Execute normally

CRITICAL_PATTERNS = [
    r"\bformat\s+[a-z]:",
    r"\bmkfs\b",
    r"\bdd\s+if=",
    r":\(\)\s*\{",                     # Fork bomb
    r"\brm\s+-rf\s+/\b",
    r"\bdel\s+/[sf]\s+/[qf]\s+[a-z]:\\",
    r"\bshutdown\s+/[sr]\s+/f",
    r"system32\\cmd",
    r"\bnetsh\s+firewall",
    r"reg\s+delete\s+hklm",
]

HIGH_PATTERNS = [
    r"\bdelete\b.*\.(exe|sys|dll|bat)",
    r"\brmdir\b",
    r"\bdel\b",
    r"\bkill\s+-9\b",
    r"\btaskkill\b",
    r"\bshutdown\b",
    r"\brestart\b",
    r"\bformat\b",
    r"\bregistry\b",
    r"\bregedit\b",
    r"\bnetsh\b",
    r"\bwmic\b",
    r"\bsfc\s+/scannow",
    r"\bdiskpart\b",
]

MEDIUM_PATTERNS = [
    r"\bpip\s+install\b",
    r"\bnpm\s+install\b",
    r"\bcurl\b",
    r"\bwget\b",
    r"\bpowershell\b",
    r"\bcmd\b",
    r"\bsudo\b",
    r"\bchmod\b",
    r"\bchown\b",
]


def classify_command(command: str) -> str:
    """Classify the risk level of a shell command."""
    cmd_lower = command.lower()
    for pattern in CRITICAL_PATTERNS:
        if re.search(pattern, cmd_lower):
            return RISK_CRITICAL
    for pattern in HIGH_PATTERNS:
        if re.search(pattern, cmd_lower):
            return RISK_HIGH
    for pattern in MEDIUM_PATTERNS:
        if re.search(pattern, cmd_lower):
            return RISK_MEDIUM
    return RISK_LOW


def classify_action(description: str) -> str:
    """Classify the risk level of a natural language action description."""
    desc_lower = description.lower()
    high_words = {"delete", "remove", "erase", "format", "shutdown", "restart",
                  "kill", "drop table", "uninstall", "wipe", "destroy"}
    medium_words = {"install", "download", "run script", "execute", "modify system"}
    for w in high_words:
        if w in desc_lower:
            return RISK_HIGH
    for w in medium_words:
        if w in desc_lower:
            return RISK_MEDIUM
    return RISK_LOW


# ─── Audit log ────────────────────────────────────────────────────────────────

AUDIT_FILE = LOG_DIR / "audit.jsonl"


def audit_log(action: str, command: str, risk: str, result: str, approved: bool = True):
    """Append an entry to the audit log."""
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "action": action,
        "command": command[:500],
        "risk": risk,
        "result": result[:200],
        "approved": approved,
    }
    try:
        with open(AUDIT_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass


def get_audit_log(limit: int = 50) -> list[dict]:
    """Read the last N audit log entries."""
    if not AUDIT_FILE.exists():
        return []
    entries = []
    with open(AUDIT_FILE, encoding="utf-8") as f:
        for line in f:
            try:
                entries.append(json.loads(line.strip()))
            except Exception:
                pass
    return entries[-limit:]


# ─── Sandbox execution ────────────────────────────────────────────────────────

class Sandbox:
    """
    Sandboxed command execution.
    - Runs commands in an isolated temp directory
    - Captures all output
    - Enforces timeouts
    - Blocks critical patterns
    - Logs everything
    """

    def __init__(self, config: Optional[SecurityConfig] = None):
        self.config = config or SecurityConfig()
        self._workdir = SANDBOX_DIR / "workspace"
        self._workdir.mkdir(parents=True, exist_ok=True)

    def run(
        self,
        command: str,
        cwd: Optional[str] = None,
        timeout: int = 60,
        env: Optional[dict] = None,
        approval_callback: Optional[Callable[[str, str], bool]] = None,
    ) -> dict:
        """
        Execute a shell command with safety checks.

        Args:
            command:           Shell command string.
            cwd:               Working directory (default: sandbox workdir).
            timeout:           Max execution time in seconds.
            env:               Additional env vars.
            approval_callback: Called for HIGH/CRITICAL risks → returns True to approve.

        Returns:
            {success, stdout, stderr, returncode, risk, approved}
        """
        risk = classify_command(command)

        # Block critical commands entirely
        if risk == RISK_CRITICAL:
            msg = f"CRITICAL command blocked: {command[:80]}"
            logger.warning(msg)
            audit_log("shell_run", command, risk, "BLOCKED", approved=False)
            raise SecurityError(msg, action=command)

        # Check user-configured blocked patterns
        for blocked in (self.config.blocked_commands or []):
            if blocked.lower() in command.lower():
                msg = f"Blocked by policy: {command[:80]}"
                audit_log("shell_run", command, risk, "POLICY_BLOCKED", approved=False)
                raise SecurityError(msg, action=command)

        # Require approval for HIGH risk
        approved = True
        if risk == RISK_HIGH and self.config.safe_mode:
            if approval_callback:
                approved = approval_callback(command, risk)
                if not approved:
                    audit_log("shell_run", command, risk, "DENIED_BY_USER", approved=False)
                    return {
                        "success": False, "stdout": "", "stderr": "Denied by user.",
                        "returncode": -1, "risk": risk, "approved": False
                    }
            else:
                # No callback — log warning but allow (caller is responsible)
                logger.warning(f"HIGH-risk command executing: {command[:80]}")

        work_dir = Path(cwd) if cwd else self._workdir
        merged_env = {**os.environ, **(env or {})}

        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=str(work_dir),
                capture_output=True,
                text=True,
                timeout=timeout,
                env=merged_env,
            )
            stdout = result.stdout.strip()
            stderr = result.stderr.strip()
            success = result.returncode == 0

            audit_log(
                "shell_run", command, risk,
                f"rc={result.returncode} out={stdout[:100]}",
                approved=approved
            )

            return {
                "success": success,
                "stdout": stdout,
                "stderr": stderr,
                "returncode": result.returncode,
                "risk": risk,
                "approved": approved,
                "output": stdout or stderr,
            }

        except subprocess.TimeoutExpired:
            msg = f"Command timed out ({timeout}s): {command[:80]}"
            audit_log("shell_run", command, risk, "TIMEOUT", approved=approved)
            return {
                "success": False, "stdout": "", "stderr": msg,
                "returncode": -1, "risk": risk, "approved": approved,
                "output": msg,
            }
        except Exception as e:
            audit_log("shell_run", command, risk, f"ERROR: {e}", approved=approved)
            return {
                "success": False, "stdout": "", "stderr": str(e),
                "returncode": -1, "risk": risk, "approved": approved,
                "output": str(e),
            }

    def run_python(self, code: str, timeout: int = 30) -> dict:
        """
        Execute Python code in an isolated subprocess.
        """
        import sys
        tmp = self._workdir / f"_sandbox_{hashlib.md5(code.encode()).hexdigest()[:8]}.py"
        tmp.write_text(code, encoding="utf-8")
        try:
            result = subprocess.run(
                [sys.executable, str(tmp)],
                capture_output=True, text=True,
                timeout=timeout, cwd=str(self._workdir)
            )
            return {
                "success": result.returncode == 0,
                "output": result.stdout.strip() or result.stderr.strip(),
                "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip(),
                "returncode": result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "output": f"Python timed out ({timeout}s)", "returncode": -1}
        finally:
            tmp.unlink(missing_ok=True)

    def safe_delete(self, path: str, config: Optional[SecurityConfig] = None) -> dict:
        """Delete a file/folder with size check and recycle bin preference."""
        p = Path(os.path.expanduser(path))
        sec = config or self.config

        if not p.exists():
            return {"success": False, "output": f"Path not found: {path}"}

        # Size check
        size_mb = _path_size_mb(p)
        if size_mb > sec.max_file_delete_mb and sec.safe_mode:
            raise SecurityError(
                f"File too large to auto-delete: {size_mb:.1f}MB > {sec.max_file_delete_mb}MB limit",
                action=f"delete:{path}"
            )

        # Prefer recycle bin
        try:
            import send2trash
            send2trash.send2trash(str(p))
            audit_log("delete", str(p), RISK_MEDIUM, "recycled")
            return {"success": True, "output": f"Moved to Recycle Bin: {p}"}
        except ImportError:
            pass

        # Hard delete
        if p.is_dir():
            shutil.rmtree(str(p))
        else:
            p.unlink()
        audit_log("delete", str(p), RISK_MEDIUM, "deleted")
        return {"success": True, "output": f"Deleted: {p}"}


def _path_size_mb(path: Path) -> float:
    if path.is_file():
        return path.stat().st_size / 1_048_576
    total = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
    return total / 1_048_576
