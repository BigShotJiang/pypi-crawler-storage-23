"""
KeyboardMouseModule — Full keyboard and mouse control.
Click, type, hotkeys, drag, scroll anywhere on screen.
"""

import time
import logging
from typing import Optional, Tuple, List

logger = logging.getLogger("doit.kb")


class KeyboardMouseModule:
    """Control keyboard and mouse — click anywhere, type anything, send hotkeys."""

    def __init__(self, verbose: bool = True):
        self.verbose = verbose

    def click(self, x: int, y: int, button: str = "left", clicks: int = 1) -> str:
        """
        Click at screen coordinates.

        Args:
            x, y:    Screen coordinates.
            button:  "left", "right", "middle". Default "left".
            clicks:  Number of clicks. 2 = double click.

        Returns:
            Confirmation.

        Example:
            ai.kb.click(500, 300)
            ai.kb.click(500, 300, clicks=2)  # double click
            ai.kb.click(800, 200, button="right")  # right click
        """
        import pyautogui
        pyautogui.click(x=x, y=y, button=button, clicks=clicks)
        return f"Clicked ({x}, {y}) {button} x{clicks}"

    def click_text(self, text: str) -> str:
        """
        Find text on screen and click it.

        Args:
            text: Text to find and click.

        Returns:
            Confirmation or error if not found.

        Example:
            ai.kb.click_text("OK")
            ai.kb.click_text("Submit")
        """
        from doit.modules.screen import ScreenModule
        screen = ScreenModule(verbose=False)
        pos = screen.find_text_on_screen(text)
        if pos:
            return self.click(*pos)
        return f"Could not find text on screen: '{text}'"

    def type(self, text: str, interval: float = 0.02) -> str:
        """
        Type text as if using a keyboard.

        Args:
            text:     Text to type.
            interval: Delay between keystrokes in seconds. Default 0.02.

        Returns:
            Confirmation.

        Example:
            ai.kb.type("Hello, World!")
            ai.kb.type("my password123", interval=0.05)
        """
        import pyautogui
        pyautogui.typewrite(text, interval=interval)
        return f"Typed: {text[:30]}..."

    def type_fast(self, text: str) -> str:
        """
        Type text instantly (no delay) — faster but less human-like.
        Good for long texts.
        """
        import pyautogui
        import pyperclip
        pyperclip.copy(text)
        pyautogui.hotkey("ctrl", "v")
        return f"Typed (paste method): {len(text)} chars"

    def hotkey(self, *keys: str) -> str:
        """
        Press a keyboard shortcut.

        Args:
            *keys: Keys to press simultaneously.

        Returns:
            Confirmation.

        Example:
            ai.kb.hotkey("ctrl", "c")        # Copy
            ai.kb.hotkey("ctrl", "v")        # Paste
            ai.kb.hotkey("alt", "tab")       # Switch windows
            ai.kb.hotkey("win", "d")         # Show desktop
            ai.kb.hotkey("ctrl", "shift", "esc")  # Task manager
        """
        import pyautogui
        pyautogui.hotkey(*keys)
        return f"Hotkey: {'+'.join(keys)}"

    def press(self, key: str) -> str:
        """
        Press a single key.

        Args:
            key: Key name. e.g. "enter", "tab", "escape", "f5", "delete"

        Example:
            ai.kb.press("enter")
            ai.kb.press("escape")
            ai.kb.press("f5")
        """
        import pyautogui
        pyautogui.press(key)
        return f"Pressed: {key}"

    def move_mouse(self, x: int, y: int, duration: float = 0.3) -> str:
        """
        Move mouse to coordinates.

        Args:
            x, y:     Target coordinates.
            duration: Movement time in seconds. Default 0.3 (smooth).
        """
        import pyautogui
        pyautogui.moveTo(x, y, duration=duration)
        return f"Mouse moved to ({x}, {y})"

    def drag(self, start_x: int, start_y: int, end_x: int, end_y: int, duration: float = 0.5) -> str:
        """
        Click and drag from one position to another.

        Args:
            start_x, start_y: Starting coordinates.
            end_x, end_y:     Ending coordinates.
            duration:         Drag duration in seconds.

        Example:
            ai.kb.drag(100, 100, 500, 100)  # drag horizontally
        """
        import pyautogui
        pyautogui.moveTo(start_x, start_y)
        pyautogui.dragTo(end_x, end_y, duration=duration, button="left")
        return f"Dragged ({start_x},{start_y}) → ({end_x},{end_y})"

    def scroll(self, clicks: int = 3, x: Optional[int] = None, y: Optional[int] = None) -> str:
        """
        Scroll the mouse wheel.

        Args:
            clicks: Positive = scroll up, Negative = scroll down.
            x, y:   Position to scroll at. None = current position.

        Example:
            ai.kb.scroll(-5)   # scroll down 5 clicks
            ai.kb.scroll(3)    # scroll up 3 clicks
        """
        import pyautogui
        if x and y:
            pyautogui.scroll(clicks, x=x, y=y)
        else:
            pyautogui.scroll(clicks)
        return f"Scrolled {clicks} clicks"

    def get_mouse_position(self) -> Tuple[int, int]:
        """Get current mouse cursor coordinates."""
        import pyautogui
        return pyautogui.position()

    def copy(self) -> str:
        """Press Ctrl+C and return clipboard contents."""
        import pyautogui
        import pyperclip
        pyautogui.hotkey("ctrl", "c")
        time.sleep(0.3)
        return pyperclip.paste()

    def paste(self, text: Optional[str] = None) -> str:
        """
        Paste text or clipboard contents.

        Args:
            text: Text to paste. None = paste current clipboard.
        """
        import pyautogui
        import pyperclip
        if text:
            pyperclip.copy(text)
        pyautogui.hotkey("ctrl", "v")
        return f"Pasted: {(text or 'clipboard')[:30]}"

    def get_clipboard(self) -> str:
        """Return current clipboard text."""
        try:
            import pyperclip
            return pyperclip.paste()
        except Exception as e:
            return f"Error getting clipboard: {e}"

    def set_clipboard(self, text: str) -> str:
        """Set clipboard to given text."""
        import pyperclip
        pyperclip.copy(text)
        return f"Clipboard set: {text[:50]}"

    def select_all(self) -> str:
        """Press Ctrl+A to select all."""
        return self.hotkey("ctrl", "a")

    def undo(self) -> str:
        """Press Ctrl+Z to undo."""
        return self.hotkey("ctrl", "z")

    def save(self) -> str:
        """Press Ctrl+S to save."""
        return self.hotkey("ctrl", "s")

    def close_window(self) -> str:
        """Press Alt+F4 to close current window."""
        return self.hotkey("alt", "f4")

    def screenshot_to_clipboard(self) -> str:
        """Press Win+Shift+S to open Windows Snipping Tool."""
        return self.hotkey("win", "shift", "s")

    def wait(self, seconds: float) -> str:
        """Wait for N seconds."""
        time.sleep(seconds)
        return f"Waited {seconds}s"
