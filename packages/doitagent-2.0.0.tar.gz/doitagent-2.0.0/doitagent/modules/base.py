"""Base class for all DoItAgent modules."""

from __future__ import annotations
import logging
from doitagent.config import AgentConfig


class BaseModule:
    """All capability modules inherit from this."""

    module_name: str = "base"

    def __init__(self, config: AgentConfig):
        self.config = config
        self.log = logging.getLogger(f"doitagent.{self.module_name}")

    def _require(self, import_name: str, pip_name: str = "") -> bool:
        """Ensure an optional dependency is available."""
        from doitagent.utils.installer import ensure
        return ensure(import_name, pip_name or import_name, auto=self.config.auto_install_deps)

    def tools(self) -> dict:
        """Return dict of {name: callable} for all public methods."""
        import inspect
        result = {}
        for name in dir(self):
            if name.startswith("_"):
                continue
            method = getattr(self, name)
            if callable(method) and name != "tools" and hasattr(method, "__doc__") and method.__doc__:
                result[f"{self.module_name}.{name}"] = method
        return result
