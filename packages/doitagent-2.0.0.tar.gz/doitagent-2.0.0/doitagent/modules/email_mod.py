"""
EmailModule — Send and read emails.
Supports Gmail (via IMAP/SMTP), Outlook, and any SMTP server.
"""

from __future__ import annotations
import os
import logging
import smtplib
import imaplib
import email as email_lib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from typing import Optional, List
from pathlib import Path

logger = logging.getLogger("doitagent.email")


class EmailModule:
    """Send and receive emails via SMTP/IMAP."""

    module_name = "email"

    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self._smtp_host = os.environ.get("DOIT_SMTP_HOST", "smtp.gmail.com")
        self._smtp_port = int(os.environ.get("DOIT_SMTP_PORT", "587"))
        self._imap_host = os.environ.get("DOIT_IMAP_HOST", "imap.gmail.com")
        self._email = os.environ.get("DOIT_EMAIL", "")
        self._password = os.environ.get("DOIT_EMAIL_PASSWORD", "")

    def configure(self, email: str, password: str, smtp_host: str = "smtp.gmail.com",
                  smtp_port: int = 587, imap_host: str = "imap.gmail.com"):
        """
        Configure email credentials.

        Args:
            email:     Your email address.
            password:  App password (for Gmail: https://myaccount.google.com/apppasswords).
            smtp_host: SMTP server. Default: smtp.gmail.com
            smtp_port: SMTP port. Default: 587
            imap_host: IMAP server. Default: imap.gmail.com

        Example:
            ai.email.configure("me@gmail.com", "app_password_here")
        """
        self._email = email
        self._password = password
        self._smtp_host = smtp_host
        self._smtp_port = smtp_port
        self._imap_host = imap_host
        return "Email configured."

    def send(self, to: str, subject: str, body: str,
             attachments: Optional[List[str]] = None, html: bool = False) -> str:
        """
        Send an email.

        Args:
            to:          Recipient email address (or comma-separated list).
            subject:     Email subject line.
            body:        Email body text.
            attachments: List of file paths to attach.
            html:        Send as HTML email. Default False.

        Returns:
            Confirmation message.

        Example:
            ai.email.send("boss@company.com", "Report Ready", "See attached report.", ["~/report.pdf"])
            ai.email.send("friend@gmail.com", "Hello!", "How are you?")
        """
        if not self._email or not self._password:
            return "Email not configured. Call ai.email.configure() first."

        msg = MIMEMultipart()
        msg["From"] = self._email
        msg["To"] = to
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "html" if html else "plain"))

        # Attach files
        for fpath in (attachments or []):
            fpath = os.path.expanduser(fpath)
            if os.path.exists(fpath):
                with open(fpath, "rb") as f:
                    part = MIMEBase("application", "octet-stream")
                    part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header("Content-Disposition", f"attachment; filename={Path(fpath).name}")
                msg.attach(part)

        try:
            with smtplib.SMTP(self._smtp_host, self._smtp_port) as server:
                server.starttls()
                server.login(self._email, self._password)
                server.send_message(msg)
            if self.verbose:
                logger.info(f"Email sent to {to}: {subject}")
            return f"Email sent to {to}"
        except Exception as e:
            return f"Failed to send email: {e}"

    def read_inbox(self, limit: int = 10, unread_only: bool = False, folder: str = "INBOX") -> List[dict]:
        """
        Read emails from inbox.

        Args:
            limit:       Number of emails to return. Default 10.
            unread_only: Return only unread emails. Default False.
            folder:      Mailbox folder. Default "INBOX".

        Returns:
            List of email dicts with subject, sender, date, body snippet.

        Example:
            emails = ai.email.read_inbox(limit=5, unread_only=True)
            for e in emails:
                print(e['subject'], e['sender'])
        """
        if not self._email or not self._password:
            return [{"error": "Email not configured. Call ai.email.configure() first."}]

        try:
            mail = imaplib.IMAP4_SSL(self._imap_host)
            mail.login(self._email, self._password)
            mail.select(folder)

            criteria = "UNSEEN" if unread_only else "ALL"
            _, message_ids = mail.search(None, criteria)
            ids = message_ids[0].split()[-limit:]

            emails = []
            for mid in reversed(ids):
                _, msg_data = mail.fetch(mid, "(RFC822)")
                msg = email_lib.message_from_bytes(msg_data[0][1])
                body = ""
                if msg.is_multipart():
                    for part in msg.walk():
                        if part.get_content_type() == "text/plain":
                            body = part.get_payload(decode=True).decode("utf-8", errors="replace")[:500]
                            break
                else:
                    body = msg.get_payload(decode=True).decode("utf-8", errors="replace")[:500]

                emails.append({
                    "id": mid.decode(),
                    "subject": msg.get("Subject", ""),
                    "sender": msg.get("From", ""),
                    "date": msg.get("Date", ""),
                    "body_snippet": body[:200],
                    "unread": criteria == "UNSEEN",
                })

            mail.logout()
            return emails

        except Exception as e:
            return [{"error": f"Failed to read email: {e}"}]

    def search_emails(self, query: str, limit: int = 10) -> List[dict]:
        """
        Search emails by keyword.

        Args:
            query: Search text (searches subject and body).
            limit: Max results. Default 10.

        Returns:
            List of matching email dicts.
        """
        if not self._email:
            return [{"error": "Email not configured."}]

        try:
            mail = imaplib.IMAP4_SSL(self._imap_host)
            mail.login(self._email, self._password)
            mail.select("INBOX")

            _, ids = mail.search(None, f'TEXT "{query}"')
            found = ids[0].split()[-limit:]
            emails = []
            for mid in reversed(found):
                _, msg_data = mail.fetch(mid, "(RFC822)")
                msg = email_lib.message_from_bytes(msg_data[0][1])
                emails.append({
                    "subject": msg.get("Subject", ""),
                    "sender": msg.get("From", ""),
                    "date": msg.get("Date", ""),
                })

            mail.logout()
            return emails
        except Exception as e:
            return [{"error": str(e)}]
