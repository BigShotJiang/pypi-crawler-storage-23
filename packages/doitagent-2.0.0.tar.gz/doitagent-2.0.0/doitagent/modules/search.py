"""
SearchModule — Web search and page scraping. 100% free.
"""

import logging
from typing import List, Optional

logger = logging.getLogger("doit.search")


class SearchModule:
    """Search the web and scrape pages — no API key needed."""

    def __init__(self, verbose: bool = True):
        self.verbose = verbose

    def web_search(self, query: str, num_results: int = 5) -> List[dict]:
        """
        Search the web using DuckDuckGo (free, no API key).

        Args:
            query:       Search query.
            num_results: Number of results to return. Default 5.

        Returns:
            List of dicts with title, url, snippet.

        Example:
            results = ai.search.web_search("python automation tutorial")
            results = ai.search.web_search("best free AI tools 2024", num_results=10)
        """
        try:
            from duckduckgo_search import DDGS
            with DDGS() as ddgs:
                results = list(ddgs.text(query, max_results=num_results))
            return [{"title": r["title"], "url": r["href"], "snippet": r["body"]} for r in results]
        except ImportError:
            return self._fallback_search(query, num_results)

    def _fallback_search(self, query: str, num_results: int) -> List[dict]:
        """Fallback search using requests + BeautifulSoup."""
        try:
            import requests
            from bs4 import BeautifulSoup

            url = f"https://html.duckduckgo.com/html/?q={query.replace(' ', '+')}"
            headers = {"User-Agent": "Mozilla/5.0"}
            resp = requests.get(url, headers=headers, timeout=10)
            soup = BeautifulSoup(resp.text, "html.parser")

            results = []
            for r in soup.select(".result")[:num_results]:
                title_el = r.select_one(".result__title")
                link_el = r.select_one(".result__url")
                snippet_el = r.select_one(".result__snippet")
                if title_el and link_el:
                    results.append({
                        "title": title_el.get_text(strip=True),
                        "url": link_el.get_text(strip=True),
                        "snippet": snippet_el.get_text(strip=True) if snippet_el else "",
                    })
            return results
        except Exception as e:
            return [{"error": f"Search failed: {e}"}]

    def scrape_page(self, url: str, extract: str = "text") -> str:
        """
        Scrape content from a webpage.

        Args:
            url:     URL to scrape.
            extract: "text" = clean text, "html" = raw HTML, "links" = all links

        Returns:
            Scraped content.

        Example:
            text = ai.search.scrape_page("https://example.com")
            links = ai.search.scrape_page("https://example.com", extract="links")
        """
        try:
            import requests
            from bs4 import BeautifulSoup

            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
            resp = requests.get(url, headers=headers, timeout=15)
            soup = BeautifulSoup(resp.text, "html.parser")

            # Remove scripts and styles
            for script in soup(["script", "style", "nav", "footer"]):
                script.decompose()

            if extract == "text":
                return soup.get_text(separator="\n", strip=True)
            elif extract == "html":
                return str(soup)
            elif extract == "links":
                links = []
                for a in soup.find_all("a", href=True):
                    links.append({"text": a.get_text(strip=True), "url": a["href"]})
                return str(links)
            return soup.get_text()

        except Exception as e:
            return f"Error scraping {url}: {e}"

    def search_and_summarize(self, query: str) -> str:
        """
        Search the web and return a text summary of top results.

        Args:
            query: What to search for.

        Returns:
            Summary of search results.
        """
        results = self.web_search(query, num_results=5)
        if not results or "error" in results[0]:
            return f"No results found for: {query}"

        lines = [f"Search results for: '{query}'\n"]
        for i, r in enumerate(results, 1):
            lines.append(f"{i}. {r['title']}")
            lines.append(f"   URL: {r['url']}")
            if r.get("snippet"):
                lines.append(f"   {r['snippet'][:200]}")
            lines.append("")

        return "\n".join(lines)

    def get_page_text(self, url: str, max_chars: int = 5000) -> str:
        """
        Get readable text from any URL.

        Args:
            url:       URL to fetch.
            max_chars: Max characters to return.

        Returns:
            Page text content.
        """
        text = self.scrape_page(url, extract="text")
        return text[:max_chars]

    def search_news(self, topic: str, num_results: int = 5) -> List[dict]:
        """
        Search for recent news on a topic.

        Args:
            topic: News topic to search.
            num_results: Number of articles.

        Returns:
            List of news articles.
        """
        try:
            from duckduckgo_search import DDGS
            with DDGS() as ddgs:
                results = list(ddgs.news(topic, max_results=num_results))
            return results
        except Exception:
            return self.web_search(f"{topic} news today", num_results)
