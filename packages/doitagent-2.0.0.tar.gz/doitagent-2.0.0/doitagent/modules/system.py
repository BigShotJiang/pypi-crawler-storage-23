"""
SystemModule — Deep Windows system control.
Processes, notifications, registry, startup, power, network info.
"""

import os
import sys
import logging
import subprocess
from typing import List, Optional

logger = logging.getLogger("doit.system")


class SystemModule:
    """Control Windows system: processes, notifications, registry, power."""

    def __init__(self, verbose: bool = True, safe_mode: bool = True):
        self.verbose = verbose
        self.safe_mode = safe_mode

    def notify(self, title: str, message: str, icon: str = "info", duration: int = 5) -> str:
        """
        Show a Windows desktop notification (toast notification).

        Args:
            title:    Notification title.
            message:  Notification body text.
            icon:     "info", "warning", "error". Default "info".
            duration: How long to show in seconds. Default 5.

        Returns:
            Confirmation.

        Example:
            ai.system.notify("DoIt", "Task completed!")
            ai.system.notify("Reminder", "Meeting in 5 minutes", icon="warning")
        """
        try:
            from plyer import notification
            notification.notify(
                title=title,
                message=message,
                app_name="DoIt",
                timeout=duration,
            )
            return f"Notification sent: {title}"
        except ImportError:
            # Fallback: PowerShell toast
            ps = f"""
            Add-Type -AssemblyName System.Windows.Forms
            $notify = New-Object System.Windows.Forms.NotifyIcon
            $notify.Icon = [System.Drawing.SystemIcons]::{icon.capitalize()}
            $notify.Visible = $true
            $notify.ShowBalloonTip({duration * 1000}, '{title}', '{message}', [System.Windows.Forms.ToolTipIcon]::{icon.capitalize()})
            Start-Sleep -s {duration + 1}
            $notify.Dispose()
            """
            subprocess.Popen(["powershell", "-Command", ps])
            return f"Notification sent (PowerShell): {title}"

    def list_processes(self) -> List[dict]:
        """
        Get list of all running processes.

        Returns:
            List of dicts with pid, name, cpu, memory info.

        Example:
            procs = ai.system.list_processes()
            chrome = [p for p in procs if 'chrome' in p['name'].lower()]
        """
        try:
            import psutil
            processes = []
            for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_info", "status"]):
                try:
                    info = proc.info
                    processes.append({
                        "pid": info["pid"],
                        "name": info["name"],
                        "cpu_percent": info["cpu_percent"],
                        "memory_mb": round(info["memory_info"].rss / 1024 / 1024, 1) if info["memory_info"] else 0,
                        "status": info["status"],
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            return sorted(processes, key=lambda x: x["memory_mb"], reverse=True)
        except ImportError:
            return [{"error": "psutil not installed. Run: pip install psutil"}]

    def kill_process(self, name_or_pid) -> str:
        """
        Kill a process by name or PID.

        Args:
            name_or_pid: Process name (e.g. "notepad.exe") or integer PID.

        Returns:
            Confirmation.

        Example:
            ai.system.kill_process("notepad.exe")
            ai.system.kill_process(1234)
        """
        try:
            import psutil
            if isinstance(name_or_pid, int):
                psutil.Process(name_or_pid).kill()
                return f"Killed PID {name_or_pid}"
            else:
                killed = 0
                for proc in psutil.process_iter(["name"]):
                    if name_or_pid.lower() in proc.info["name"].lower():
                        proc.kill()
                        killed += 1
                return f"Killed {killed} processes matching '{name_or_pid}'"
        except Exception as e:
            return f"Error killing process: {e}"

    def get_system_info(self) -> dict:
        """
        Get comprehensive system information.

        Returns:
            Dict with OS, CPU, memory, disk, network info.
        """
        try:
            import psutil
            import platform
            return {
                "os": platform.system(),
                "os_version": platform.version(),
                "machine": platform.machine(),
                "processor": platform.processor(),
                "python_version": sys.version,
                "cpu_count": psutil.cpu_count(),
                "cpu_percent": psutil.cpu_percent(interval=1),
                "memory_total_gb": round(psutil.virtual_memory().total / 1e9, 2),
                "memory_used_gb": round(psutil.virtual_memory().used / 1e9, 2),
                "memory_percent": psutil.virtual_memory().percent,
                "disk_total_gb": round(psutil.disk_usage("/").total / 1e9, 2),
                "disk_used_gb": round(psutil.disk_usage("/").used / 1e9, 2),
            }
        except Exception as e:
            return {"error": str(e)}

    def get_battery(self) -> dict:
        """Get battery status (on laptops)."""
        try:
            import psutil
            bat = psutil.sensors_battery()
            if bat:
                return {
                    "percent": bat.percent,
                    "plugged_in": bat.power_plugged,
                    "time_left_mins": round(bat.secsleft / 60) if bat.secsleft > 0 else "Unknown",
                }
            return {"status": "No battery (desktop)"}
        except Exception as e:
            return {"error": str(e)}

    def get_network_info(self) -> dict:
        """Get network interfaces and IP addresses."""
        try:
            import psutil
            interfaces = {}
            for name, addrs in psutil.net_if_addrs().items():
                interfaces[name] = [str(addr.address) for addr in addrs]
            return interfaces
        except Exception as e:
            return {"error": str(e)}

    def open_url(self, url: str) -> str:
        """Open a URL in the default browser."""
        import webbrowser
        webbrowser.open(url)
        return f"Opened: {url}"

    def get_clipboard(self) -> str:
        """Get current clipboard content."""
        try:
            import pyperclip
            return pyperclip.paste()
        except Exception:
            result = subprocess.run(
                "powershell Get-Clipboard",
                shell=True, capture_output=True, text=True
            )
            return result.stdout.strip()

    def set_volume(self, level: int) -> str:
        """
        Set system volume level.

        Args:
            level: Volume 0-100.

        Example:
            ai.system.set_volume(50)
            ai.system.set_volume(0)   # mute
        """
        try:
            from ctypes import cast, POINTER
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            volume.SetMasterVolumeLevelScalar(level / 100, None)
            return f"Volume set to {level}%"
        except Exception:
            # Fallback PowerShell
            ps = f"(New-Object -ComObject WScript.Shell).SendKeys([char]174)" if level == 0 else ""
            return f"Volume set to {level}% (approximate)"

    def schedule_task(self, name: str, command: str, schedule: str) -> str:
        """
        Create a Windows Scheduled Task.

        Args:
            name:     Task name.
            command:  Command to run.
            schedule: "daily", "weekly", "once at HH:MM"

        Returns:
            Confirmation.
        """
        ps = f'schtasks /create /tn "{name}" /tr "{command}" /sc {schedule} /f'
        result = subprocess.run(["powershell", "-Command", ps], capture_output=True, text=True)
        return result.stdout or result.stderr

    def shutdown(self, delay: int = 0) -> str:
        """Shutdown Windows (with optional delay in seconds)."""
        if self.safe_mode:
            confirm = input(f"[DoIt] Really shutdown in {delay}s? (y/n): ")
            if confirm.lower() != "y":
                return "Shutdown cancelled."
        os.system(f"shutdown /s /t {delay}")
        return f"Shutting down in {delay}s"

    def restart(self, delay: int = 0) -> str:
        """Restart Windows."""
        if self.safe_mode:
            confirm = input(f"[DoIt] Really restart in {delay}s? (y/n): ")
            if confirm.lower() != "y":
                return "Restart cancelled."
        os.system(f"shutdown /r /t {delay}")
        return f"Restarting in {delay}s"

    def lock_screen(self) -> str:
        """Lock the Windows screen (Win+L)."""
        import ctypes
        ctypes.windll.user32.LockWorkStation()
        return "Screen locked"

    def get_installed_apps(self) -> List[str]:
        """Get list of installed applications from registry."""
        result = subprocess.run(
            ["powershell", "-Command",
             "Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* | Select-Object DisplayName | Sort-Object DisplayName"],
            capture_output=True, text=True
        )
        lines = [l.strip() for l in result.stdout.split("\n") if l.strip() and l.strip() != "DisplayName" and l.strip() != "-----------"]
        return lines
