"""
MediaModule — Play music, video, control volume, text-to-speech.
"""

import os
import logging
import subprocess
from typing import Optional

logger = logging.getLogger("doit.media")


class MediaModule:
    """Play and control audio/video media."""

    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self._vlc_instance = None

    def play(self, path_or_url: str) -> str:
        """
        Play audio or video from file or URL.

        Args:
            path_or_url: File path or URL (YouTube, etc.) to play.

        Returns:
            Confirmation.

        Example:
            ai.media.play("C:/Music/song.mp3")
            ai.media.play("https://www.youtube.com/watch?v=...")
            ai.media.play("~/Music/playlist.m3u")
        """
        path_or_url = os.path.expanduser(path_or_url)

        # Try python-vlc first (best cross-format support)
        try:
            import vlc
            instance = vlc.Instance()
            player = instance.media_player_new()
            media = instance.media_new(path_or_url)
            player.set_media(media)
            player.play()
            self._vlc_instance = (instance, player)
            return f"Playing: {path_or_url}"
        except ImportError:
            pass

        # Try pygame for local audio
        if os.path.exists(str(path_or_url)):
            try:
                import pygame
                pygame.mixer.init()
                pygame.mixer.music.load(path_or_url)
                pygame.mixer.music.play()
                return f"Playing: {path_or_url}"
            except ImportError:
                pass

        # Fallback: open with default Windows media player
        os.startfile(path_or_url) if os.path.exists(str(path_or_url)) else subprocess.Popen(
            f'start "" "{path_or_url}"', shell=True
        )
        return f"Opened media: {path_or_url}"

    def play_youtube(self, query_or_url: str) -> str:
        """
        Play YouTube video in browser or via yt-dlp.

        Args:
            query_or_url: YouTube URL or search query like "lofi hip hop radio"

        Returns:
            Confirmation.

        Example:
            ai.media.play_youtube("lofi hip hop study music")
            ai.media.play_youtube("https://youtube.com/watch?v=xyz")
        """
        if not query_or_url.startswith("http"):
            # Search YouTube
            query = query_or_url.replace(" ", "+")
            url = f"https://www.youtube.com/results?search_query={query}"
        else:
            url = query_or_url

        import webbrowser
        webbrowser.open(url)
        return f"Opened YouTube: {query_or_url}"

    def play_spotify(self, query: str) -> str:
        """
        Open Spotify and play a song/artist/playlist.

        Args:
            query: Song, artist, or playlist name.

        Returns:
            Confirmation.
        """
        # Try Spotify URI
        uri = f"spotify:search:{query.replace(' ', '%20')}"
        try:
            os.startfile(uri)
            return f"Spotify: {query}"
        except Exception:
            import webbrowser
            webbrowser.open(f"https://open.spotify.com/search/{query.replace(' ', '%20')}")
            return f"Opened Spotify web: {query}"

    def pause(self) -> str:
        """Pause currently playing media (sends media key)."""
        try:
            import pyautogui
            pyautogui.press("playpause")
            return "Paused/Resumed media"
        except Exception:
            return self._send_media_key("pause")

    def stop(self) -> str:
        """Stop currently playing media."""
        if self._vlc_instance:
            self._vlc_instance[1].stop()
            return "Stopped VLC media"
        return self._send_media_key("stop")

    def next_track(self) -> str:
        """Skip to next track."""
        return self._send_media_key("next")

    def prev_track(self) -> str:
        """Go to previous track."""
        return self._send_media_key("prev")

    def set_volume(self, level: int) -> str:
        """
        Set system volume.

        Args:
            level: 0-100

        Example:
            ai.media.set_volume(70)
        """
        try:
            from ctypes import cast, POINTER
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            volume.SetMasterVolumeLevelScalar(level / 100, None)
            return f"Volume set to {level}%"
        except Exception as e:
            # Fallback using nircmd if available
            subprocess.run(f"nircmd setsysvolume {int(level * 655.35)}", shell=True)
            return f"Volume set to {level}% (approximate)"

    def mute(self) -> str:
        """Toggle mute."""
        return self._send_media_key("mute")

    def volume_up(self, steps: int = 5) -> str:
        """Increase volume by N steps."""
        try:
            import pyautogui
            for _ in range(steps):
                pyautogui.press("volumeup")
            return f"Volume up x{steps}"
        except Exception:
            return "Volume up"

    def volume_down(self, steps: int = 5) -> str:
        """Decrease volume by N steps."""
        try:
            import pyautogui
            for _ in range(steps):
                pyautogui.press("volumedown")
            return f"Volume down x{steps}"
        except Exception:
            return "Volume down"

    def text_to_speech(self, text: str, save_path: Optional[str] = None) -> str:
        """
        Convert text to speech using free local TTS.

        Args:
            text:      Text to speak.
            save_path: Optionally save audio to file (.mp3/.wav).

        Returns:
            Confirmation, or path to saved audio file.

        Example:
            ai.media.text_to_speech("Task completed successfully!")
            ai.media.text_to_speech("Hello World", "~/Desktop/hello.mp3")
        """
        # Try pyttsx3 (works fully offline)
        try:
            import pyttsx3
            engine = pyttsx3.init()
            if save_path:
                save_path = os.path.expanduser(save_path)
                engine.save_to_file(text, save_path)
                engine.runAndWait()
                return save_path
            else:
                engine.say(text)
                engine.runAndWait()
                return f"Spoken: {text[:50]}..."
        except ImportError:
            pass

        # Fallback: Windows SAPI via PowerShell
        ps = f"Add-Type -AssemblyName System.speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{text}')"
        subprocess.run(["powershell", "-Command", ps])
        return f"Spoken (SAPI): {text[:50]}"

    def record_audio(self, duration: int = 5, save_path: str = "recording.wav") -> str:
        """
        Record audio from microphone.

        Args:
            duration:  Recording length in seconds.
            save_path: Path to save WAV file.

        Returns:
            Path to recorded file.
        """
        try:
            import sounddevice as sd
            import scipy.io.wavfile as wav
            import numpy as np

            save_path = os.path.expanduser(save_path)
            logger.info(f"Recording {duration}s...")
            audio = sd.rec(int(duration * 44100), samplerate=44100, channels=1, dtype="int16")
            sd.wait()
            wav.write(save_path, 44100, audio)
            return save_path
        except ImportError:
            return "sounddevice not installed. Run: pip install sounddevice scipy"

    def _send_media_key(self, action: str) -> str:
        """Send media keys via PowerShell."""
        key_map = {
            "pause": 0xB3, "stop": 0xB2, "next": 0xB0,
            "prev": 0xB1, "mute": 0xAD
        }
        vk = key_map.get(action, 0xB3)
        ps = f"""
        $shell = New-Object -ComObject WScript.Shell
        $shell.SendKeys([char]{vk})
        """
        subprocess.run(["powershell", "-Command", ps])
        return f"Media key: {action}"
