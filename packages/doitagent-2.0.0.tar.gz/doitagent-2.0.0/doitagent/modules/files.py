"""
FilesModule — Complete file and folder CRUD + extras.
Create, read, update, delete, move, copy, search, zip files.
"""

import os
import shutil
import glob
import json
import logging
from typing import Optional, List, Union
from pathlib import Path
from datetime import datetime

logger = logging.getLogger("doit.files")


class FilesModule:
    """Full file and folder operations."""

    def __init__(self, verbose: bool = True, safe_mode: bool = True):
        self.verbose = verbose
        self.safe_mode = safe_mode

    # ─── CREATE ───────────────────────────────

    def create_file(self, path: str, content: str = "") -> str:
        """
        Create a new file with optional content.

        Args:
            path:    File path to create. Supports ~ for home dir.
            content: Text content to write. Default empty.

        Returns:
            Absolute path to the created file.

        Example:
            ai.files.create_file("~/Desktop/notes.txt", "Hello World")
            ai.files.create_file("C:/projects/app.py", "print('hello')")
        """
        path = os.path.expanduser(path)
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        if self.verbose:
            logger.info(f"Created: {path}")
        return os.path.abspath(path)

    def create_folder(self, path: str) -> str:
        """
        Create a folder (and any parent folders needed).

        Args:
            path: Folder path to create.

        Returns:
            Absolute path to created folder.

        Example:
            ai.files.create_folder("~/Desktop/MyProject/src")
        """
        path = os.path.expanduser(path)
        os.makedirs(path, exist_ok=True)
        if self.verbose:
            logger.info(f"Folder created: {path}")
        return os.path.abspath(path)

    # ─── READ ────────────────────────────────

    def read_file(self, path: str) -> str:
        """
        Read and return the content of a file.

        Args:
            path: Path to file to read.

        Returns:
            File content as string.

        Example:
            content = ai.files.read_file("~/Desktop/notes.txt")
        """
        path = os.path.expanduser(path)
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()

    def list_folder(self, path: str = ".", pattern: str = "*") -> List[dict]:
        """
        List contents of a folder.

        Args:
            path:    Folder to list. Default current directory.
            pattern: Glob pattern. e.g. "*.txt", "*.py"

        Returns:
            List of dicts with name, path, size, type, modified.

        Example:
            items = ai.files.list_folder("~/Desktop")
            items = ai.files.list_folder("C:/projects", "*.py")
        """
        path = os.path.expanduser(path)
        items = []
        for entry in Path(path).glob(pattern):
            stat = entry.stat()
            items.append({
                "name": entry.name,
                "path": str(entry.absolute()),
                "size": stat.st_size,
                "type": "folder" if entry.is_dir() else "file",
                "extension": entry.suffix,
                "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
            })
        return sorted(items, key=lambda x: x["name"])

    def find_files(self, pattern: str, search_dir: str = "~") -> List[str]:
        """
        Recursively find files matching a pattern.

        Args:
            pattern:    Glob or name pattern. e.g. "*.pdf", "report*"
            search_dir: Root directory to search from.

        Returns:
            List of matching file paths.

        Example:
            pdfs = ai.files.find_files("*.pdf", "~/Documents")
            reports = ai.files.find_files("report*", "C:/work")
        """
        search_dir = os.path.expanduser(search_dir)
        results = []
        for p in Path(search_dir).rglob(pattern):
            results.append(str(p))
        return results

    def file_info(self, path: str) -> dict:
        """
        Get detailed info about a file or folder.

        Returns:
            Dict with name, size, created, modified, type, permissions.
        """
        path = os.path.expanduser(path)
        p = Path(path)
        stat = p.stat()
        return {
            "name": p.name,
            "path": str(p.absolute()),
            "size_bytes": stat.st_size,
            "size_human": self._human_size(stat.st_size),
            "type": "folder" if p.is_dir() else "file",
            "extension": p.suffix,
            "created": datetime.fromtimestamp(stat.st_ctime).isoformat(),
            "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
            "exists": p.exists(),
        }

    # ─── UPDATE ──────────────────────────────

    def write_file(self, path: str, content: str) -> str:
        """
        Overwrite a file with new content.

        Args:
            path:    File to write to (created if doesn't exist).
            content: New content.

        Returns:
            Path to file.
        """
        return self.create_file(path, content)

    def append_file(self, path: str, content: str) -> str:
        """
        Append content to an existing file.

        Args:
            path:    File to append to.
            content: Content to add at the end.

        Returns:
            Path to file.

        Example:
            ai.files.append_file("~/log.txt", "New log entry\n")
        """
        path = os.path.expanduser(path)
        with open(path, "a", encoding="utf-8") as f:
            f.write(content)
        return os.path.abspath(path)

    def replace_in_file(self, path: str, old_text: str, new_text: str) -> str:
        """
        Find and replace text inside a file.

        Args:
            path:     File to edit.
            old_text: Text to find.
            new_text: Text to replace with.

        Returns:
            Path to file.
        """
        content = self.read_file(path)
        new_content = content.replace(old_text, new_text)
        return self.write_file(path, new_content)

    def rename(self, path: str, new_name: str) -> str:
        """
        Rename a file or folder.

        Args:
            path:     Current path.
            new_name: New name (just the name, not full path).

        Returns:
            New path.

        Example:
            new_path = ai.files.rename("~/Desktop/old.txt", "new.txt")
        """
        path = os.path.expanduser(path)
        parent = Path(path).parent
        new_path = parent / new_name
        os.rename(path, new_path)
        return str(new_path)

    def move(self, source: str, destination: str) -> str:
        """
        Move a file or folder to a new location.

        Args:
            source:      File/folder to move.
            destination: Destination path or folder.

        Returns:
            New path.

        Example:
            ai.files.move("~/Downloads/report.pdf", "~/Documents/reports/")
        """
        source = os.path.expanduser(source)
        destination = os.path.expanduser(destination)
        result = shutil.move(source, destination)
        if self.verbose:
            logger.info(f"Moved: {source} → {result}")
        return result

    def copy(self, source: str, destination: str) -> str:
        """
        Copy a file or folder to a new location.

        Args:
            source:      File/folder to copy.
            destination: Destination path.

        Returns:
            Path to the copy.
        """
        source = os.path.expanduser(source)
        destination = os.path.expanduser(destination)
        if os.path.isdir(source):
            result = shutil.copytree(source, destination)
        else:
            result = shutil.copy2(source, destination)
        return result

    # ─── DELETE ──────────────────────────────

    def delete(self, path: str, confirm: bool = None) -> str:
        """
        Delete a file or folder permanently.

        Args:
            path:    File or folder to delete.
            confirm: Override safe_mode confirmation.

        Returns:
            Confirmation message.

        Example:
            ai.files.delete("~/Desktop/old_file.txt")
        """
        path = os.path.expanduser(path)

        should_confirm = confirm if confirm is not None else self.safe_mode
        if should_confirm:
            ans = input(f"[DoIt] Delete '{path}'? This cannot be undone. (y/n): ")
            if ans.lower() != "y":
                return "Delete cancelled."

        if os.path.isdir(path):
            shutil.rmtree(path)
        else:
            os.remove(path)

        if self.verbose:
            logger.info(f"Deleted: {path}")
        return f"Deleted: {path}"

    def trash(self, path: str) -> str:
        """
        Move file to Recycle Bin (safer than delete).

        Args:
            path: File to trash.

        Returns:
            Confirmation message.
        """
        try:
            import send2trash
            send2trash.send2trash(os.path.expanduser(path))
            return f"Moved to Recycle Bin: {path}"
        except ImportError:
            logger.warning("send2trash not installed. Using permanent delete.")
            return self.delete(path, confirm=False)

    # ─── EXTRAS ──────────────────────────────

    def zip_folder(self, folder_path: str, output_path: Optional[str] = None) -> str:
        """
        Compress a folder into a ZIP file.

        Args:
            folder_path: Folder to zip.
            output_path: Where to save ZIP. Default: same location as folder.

        Returns:
            Path to the ZIP file.
        """
        folder_path = os.path.expanduser(folder_path)
        if not output_path:
            output_path = folder_path + ".zip"
        shutil.make_archive(folder_path, "zip", folder_path)
        return folder_path + ".zip"

    def unzip(self, zip_path: str, extract_to: Optional[str] = None) -> str:
        """
        Extract a ZIP file.

        Args:
            zip_path:   Path to ZIP file.
            extract_to: Where to extract. Default: same folder as ZIP.

        Returns:
            Path to extracted folder.
        """
        import zipfile
        zip_path = os.path.expanduser(zip_path)
        if not extract_to:
            extract_to = os.path.dirname(zip_path)
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_to)
        return extract_to

    def read_json(self, path: str) -> dict:
        """Read a JSON file and return as dict."""
        return json.loads(self.read_file(path))

    def write_json(self, path: str, data: dict, indent: int = 2) -> str:
        """Write a dict to a JSON file."""
        return self.create_file(path, json.dumps(data, indent=indent, ensure_ascii=False))

    def get_desktop_path(self) -> str:
        """Return path to user's Desktop."""
        return os.path.join(os.path.expanduser("~"), "Desktop")

    def get_downloads_path(self) -> str:
        """Return path to user's Downloads folder."""
        return os.path.join(os.path.expanduser("~"), "Downloads")

    def _human_size(self, size: int) -> str:
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} PB"
