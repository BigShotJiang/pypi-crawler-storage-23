"""
DocumentsModule — Create Word, Excel, PDF, CSV documents.
"""

import os
import logging
from typing import Optional, List, Any

logger = logging.getLogger("doit.docs")


class DocumentsModule:
    """Create and edit Word, Excel, PDF, and text documents."""

    def __init__(self, verbose: bool = True):
        self.verbose = verbose

    # ─── WORD DOCUMENTS ──────────────────────

    def create_word(self, path: str, title: str = "", content: str = "", paragraphs: List[str] = None) -> str:
        """
        Create a Word (.docx) document.

        Args:
            path:       Save path. e.g. "~/Desktop/report.docx"
            title:      Document title (heading 1).
            content:    Main body text.
            paragraphs: List of paragraphs to add.

        Returns:
            Path to created document.

        Example:
            ai.docs.create_word(
                "~/Desktop/report.docx",
                title="Sales Report Q3",
                paragraphs=["Revenue increased by 20%", "New markets: Asia, Europe"]
            )
        """
        try:
            from docx import Document
            from docx.shared import Pt, RGBColor
            from docx.enum.text import WD_ALIGN_PARAGRAPH

            doc = Document()
            path = os.path.expanduser(path)

            if title:
                heading = doc.add_heading(title, 0)
                heading.alignment = WD_ALIGN_PARAGRAPH.CENTER

            if content:
                doc.add_paragraph(content)

            if paragraphs:
                for para in paragraphs:
                    doc.add_paragraph(para)

            doc.save(path)
            if self.verbose:
                logger.info(f"Word document created: {path}")
            return path

        except ImportError:
            return "python-docx not installed. Run: pip install python-docx"

    def add_table_to_word(self, doc_path: str, headers: List[str], rows: List[List[Any]]) -> str:
        """
        Add a table to an existing Word document.

        Args:
            doc_path: Path to .docx file.
            headers:  List of column headers.
            rows:     List of rows (each row is a list of values).

        Returns:
            Path to updated document.

        Example:
            ai.docs.add_table_to_word(
                "report.docx",
                headers=["Name", "Sales", "Region"],
                rows=[["Alice", "$50K", "North"], ["Bob", "$40K", "South"]]
            )
        """
        from docx import Document
        from docx.shared import Pt
        from docx.oxml.ns import qn

        doc_path = os.path.expanduser(doc_path)
        doc = Document(doc_path)

        table = doc.add_table(rows=1 + len(rows), cols=len(headers))
        table.style = "Table Grid"

        # Header row
        for i, header in enumerate(headers):
            cell = table.cell(0, i)
            cell.text = header
            cell.paragraphs[0].runs[0].bold = True

        # Data rows
        for r_idx, row in enumerate(rows):
            for c_idx, value in enumerate(row):
                table.cell(r_idx + 1, c_idx).text = str(value)

        doc.save(doc_path)
        return doc_path

    # ─── EXCEL ───────────────────────────────

    def create_excel(self, path: str, sheet_name: str = "Sheet1", headers: List[str] = None, rows: List[List] = None) -> str:
        """
        Create an Excel (.xlsx) spreadsheet.

        Args:
            path:       Save path.
            sheet_name: Name of first sheet.
            headers:    Column headers.
            rows:       Data rows.

        Returns:
            Path to created file.

        Example:
            ai.docs.create_excel(
                "~/Desktop/data.xlsx",
                headers=["Date", "Product", "Revenue"],
                rows=[
                    ["2024-01-01", "Widget A", 1500],
                    ["2024-01-02", "Widget B", 2300],
                ]
            )
        """
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill, Alignment

            wb = Workbook()
            ws = wb.active
            ws.title = sheet_name
            path = os.path.expanduser(path)

            if headers:
                ws.append(headers)
                # Style header row
                for cell in ws[1]:
                    cell.font = Font(bold=True, color="FFFFFF")
                    cell.fill = PatternFill(fill_type="solid", fgColor="2E86AB")
                    cell.alignment = Alignment(horizontal="center")

            if rows:
                for row in rows:
                    ws.append(row)

            # Auto-fit column widths
            for column in ws.columns:
                max_length = max(len(str(cell.value or "")) for cell in column)
                ws.column_dimensions[column[0].column_letter].width = min(max_length + 4, 50)

            wb.save(path)
            if self.verbose:
                logger.info(f"Excel file created: {path}")
            return path

        except ImportError:
            return "openpyxl not installed. Run: pip install openpyxl"

    def read_excel(self, path: str, sheet_name: Optional[str] = None) -> List[List]:
        """
        Read data from an Excel file.

        Args:
            path:       Path to .xlsx file.
            sheet_name: Sheet name. None = first sheet.

        Returns:
            List of rows as lists.
        """
        from openpyxl import load_workbook
        path = os.path.expanduser(path)
        wb = load_workbook(path)
        ws = wb[sheet_name] if sheet_name else wb.active
        return [[cell.value for cell in row] for row in ws.iter_rows()]

    # ─── CSV ─────────────────────────────────

    def create_csv(self, path: str, headers: List[str], rows: List[List]) -> str:
        """
        Create a CSV file.

        Args:
            path:    Save path.
            headers: Column headers.
            rows:    Data rows.

        Returns:
            Path to created file.
        """
        import csv
        path = os.path.expanduser(path)
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows(rows)
        return path

    def read_csv(self, path: str) -> List[dict]:
        """Read CSV and return list of dicts (one per row)."""
        import csv
        path = os.path.expanduser(path)
        with open(path, "r", encoding="utf-8") as f:
            return list(csv.DictReader(f))

    # ─── PDF ─────────────────────────────────

    def create_pdf(self, path: str, title: str = "", content: str = "", paragraphs: List[str] = None) -> str:
        """
        Create a PDF document.

        Args:
            path:       Save path.
            title:      PDF title.
            content:    Body text.
            paragraphs: List of paragraphs.

        Returns:
            Path to PDF.

        Example:
            ai.docs.create_pdf(
                "~/Desktop/report.pdf",
                title="Annual Report",
                paragraphs=["Q1 was strong.", "Q2 exceeded targets."]
            )
        """
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.lib.units import inch

            path = os.path.expanduser(path)
            doc = SimpleDocTemplate(path, pagesize=A4)
            styles = getSampleStyleSheet()
            story = []

            if title:
                story.append(Paragraph(title, styles["Title"]))
                story.append(Spacer(1, 0.2 * inch))

            if content:
                story.append(Paragraph(content, styles["Normal"]))
                story.append(Spacer(1, 0.1 * inch))

            if paragraphs:
                for para in paragraphs:
                    story.append(Paragraph(para, styles["Normal"]))
                    story.append(Spacer(1, 0.1 * inch))

            doc.build(story)
            if self.verbose:
                logger.info(f"PDF created: {path}")
            return path

        except ImportError:
            return "reportlab not installed. Run: pip install reportlab"

    def read_pdf(self, path: str) -> str:
        """
        Extract text from a PDF file.

        Args:
            path: Path to PDF.

        Returns:
            Extracted text.
        """
        try:
            import pdfplumber
            path = os.path.expanduser(path)
            with pdfplumber.open(path) as pdf:
                return "\n".join(page.extract_text() or "" for page in pdf.pages)
        except ImportError:
            try:
                import PyPDF2
                path = os.path.expanduser(path)
                with open(path, "rb") as f:
                    reader = PyPDF2.PdfReader(f)
                    return "\n".join(page.extract_text() for page in reader.pages)
            except ImportError:
                return "Install: pip install pdfplumber"

    def convert_to_pdf(self, input_path: str, output_path: Optional[str] = None) -> str:
        """
        Convert a Word/HTML file to PDF.

        Args:
            input_path:  Source file (.docx, .html, .txt)
            output_path: Output path. None = same folder.

        Returns:
            Path to PDF.
        """
        input_path = os.path.expanduser(input_path)
        if not output_path:
            output_path = os.path.splitext(input_path)[0] + ".pdf"

        try:
            import subprocess
            # Try LibreOffice headless
            subprocess.run([
                "soffice", "--headless", "--convert-to", "pdf", "--outdir",
                os.path.dirname(output_path), input_path
            ], check=True)
            return output_path
        except Exception:
            return f"LibreOffice not found. Install LibreOffice for .docx to PDF conversion."
