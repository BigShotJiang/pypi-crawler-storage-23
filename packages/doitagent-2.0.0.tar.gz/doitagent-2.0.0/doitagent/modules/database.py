"""
DatabaseModule — SQLite CRUD operations.
Full create/read/update/delete for local databases.
"""

import os
import logging
import sqlite3
from typing import List, Any, Optional

logger = logging.getLogger("doit.db")


class DatabaseModule:
    """SQLite database operations — no server needed, 100% free."""

    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self._connections = {}

    def connect(self, db_path: str = "~/.doit/doit.db") -> str:
        """
        Connect to a SQLite database (creates it if not exists).

        Args:
            db_path: Path to database file. Default ~/.doit/doit.db

        Returns:
            Confirmation with db path.

        Example:
            ai.db.connect("~/myapp.db")
            ai.db.connect(":memory:")  # in-memory DB
        """
        db_path = os.path.expanduser(db_path)
        if db_path != ":memory:":
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self._connections[db_path] = sqlite3.connect(db_path, check_same_thread=False)
        self._connections[db_path].row_factory = sqlite3.Row
        self._current_db = db_path
        return f"Connected to: {db_path}"

    def _get_conn(self, db_path: Optional[str] = None) -> sqlite3.Connection:
        path = db_path or getattr(self, "_current_db", None)
        if path and path in self._connections:
            return self._connections[path]
        self.connect()
        return self._connections[self._current_db]

    def execute(self, sql: str, params: tuple = (), db_path: Optional[str] = None) -> Any:
        """
        Execute any SQL statement.

        Args:
            sql:     SQL to execute.
            params:  Query parameters (for safety, avoids injection).
            db_path: DB to use. Default: last connected.

        Returns:
            Rows for SELECT, rowcount for INSERT/UPDATE/DELETE.

        Example:
            ai.db.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, email TEXT)")
            ai.db.execute("INSERT INTO users (name, email) VALUES (?, ?)", ("Alice", "a@b.com"))
            rows = ai.db.execute("SELECT * FROM users WHERE name=?", ("Alice",))
        """
        conn = self._get_conn(db_path)
        cursor = conn.cursor()
        cursor.execute(sql, params)
        conn.commit()
        if sql.strip().upper().startswith("SELECT"):
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
        return cursor.rowcount

    def create_table(self, table_name: str, columns: dict, db_path: Optional[str] = None) -> str:
        """
        Create a table.

        Args:
            table_name: Name of the table.
            columns:    Dict of {column_name: type} e.g. {"name": "TEXT", "age": "INTEGER"}

        Returns:
            Confirmation.

        Example:
            ai.db.create_table("products", {
                "id": "INTEGER PRIMARY KEY AUTOINCREMENT",
                "name": "TEXT NOT NULL",
                "price": "REAL",
                "created_at": "TEXT DEFAULT CURRENT_TIMESTAMP"
            })
        """
        cols = ", ".join(f"{name} {dtype}" for name, dtype in columns.items())
        sql = f"CREATE TABLE IF NOT EXISTS {table_name} ({cols})"
        self.execute(sql, db_path=db_path)
        return f"Table '{table_name}' created"

    def insert(self, table: str, data: dict, db_path: Optional[str] = None) -> int:
        """
        Insert a row into a table.

        Args:
            table: Table name.
            data:  Dict of {column: value}.

        Returns:
            ID of inserted row.

        Example:
            id = ai.db.insert("users", {"name": "Alice", "email": "alice@example.com"})
        """
        cols = ", ".join(data.keys())
        placeholders = ", ".join("?" * len(data))
        sql = f"INSERT INTO {table} ({cols}) VALUES ({placeholders})"
        conn = self._get_conn(db_path)
        cursor = conn.cursor()
        cursor.execute(sql, tuple(data.values()))
        conn.commit()
        return cursor.lastrowid

    def select(self, table: str, where: Optional[str] = None, params: tuple = (), limit: int = 100, db_path: Optional[str] = None) -> List[dict]:
        """
        Select rows from a table.

        Args:
            table:  Table name.
            where:  WHERE clause. e.g. "age > 18" or "name = ?"
            params: Parameters for WHERE clause.
            limit:  Max rows to return.

        Returns:
            List of row dicts.

        Example:
            all_users = ai.db.select("users")
            adults = ai.db.select("users", "age > 18")
            alice = ai.db.select("users", "name = ?", ("Alice",))
        """
        sql = f"SELECT * FROM {table}"
        if where:
            sql += f" WHERE {where}"
        sql += f" LIMIT {limit}"
        return self.execute(sql, params, db_path=db_path)

    def update(self, table: str, data: dict, where: str, params: tuple = (), db_path: Optional[str] = None) -> int:
        """
        Update rows in a table.

        Args:
            table:  Table name.
            data:   Dict of {column: new_value}.
            where:  WHERE condition.
            params: WHERE clause parameters.

        Returns:
            Number of rows updated.

        Example:
            ai.db.update("users", {"email": "new@email.com"}, "name = ?", ("Alice",))
        """
        set_clause = ", ".join(f"{col} = ?" for col in data.keys())
        sql = f"UPDATE {table} SET {set_clause} WHERE {where}"
        all_params = tuple(data.values()) + params
        return self.execute(sql, all_params, db_path=db_path)

    def delete(self, table: str, where: str, params: tuple = (), db_path: Optional[str] = None) -> int:
        """
        Delete rows from a table.

        Args:
            table:  Table name.
            where:  WHERE condition.
            params: WHERE clause parameters.

        Returns:
            Number of rows deleted.

        Example:
            ai.db.delete("users", "name = ?", ("Alice",))
            ai.db.delete("logs", "created_at < '2023-01-01'")
        """
        sql = f"DELETE FROM {table} WHERE {where}"
        return self.execute(sql, params, db_path=db_path)

    def list_tables(self, db_path: Optional[str] = None) -> List[str]:
        """List all tables in the database."""
        rows = self.execute("SELECT name FROM sqlite_master WHERE type='table'", db_path=db_path)
        return [r["name"] for r in rows]

    def drop_table(self, table: str, db_path: Optional[str] = None) -> str:
        """Drop (delete) a table."""
        self.execute(f"DROP TABLE IF EXISTS {table}", db_path=db_path)
        return f"Table '{table}' dropped"

    def export_to_csv(self, table: str, output_path: str, db_path: Optional[str] = None) -> str:
        """Export a table to CSV file."""
        import csv
        rows = self.select(table, db_path=db_path)
        if not rows:
            return "No data to export"
        output_path = os.path.expanduser(output_path)
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        return output_path
