"""
ScreenModule — See and understand the screen.
Capture screenshots, read text via OCR, find UI elements.
"""

import os
import logging
from typing import Optional, Tuple, List

logger = logging.getLogger("doit.screen")


class ScreenModule:
    """Full screen capture, OCR, and element detection."""

    def __init__(self, verbose: bool = True):
        self.verbose = verbose

    def screenshot(self, save_path: Optional[str] = None, region: Optional[Tuple] = None) -> str:
        """
        Take a screenshot of the screen or a region.

        Args:
            save_path: Where to save. Defaults to ~/Desktop/screenshot.png
            region:    (x, y, width, height) to capture a region. None = full screen.

        Returns:
            Path to the saved screenshot.

        Example:
            path = ai.screen.screenshot()
            path = ai.screen.screenshot("C:/shots/now.png")
            path = ai.screen.screenshot(region=(0, 0, 800, 600))
        """
        try:
            import mss
            import mss.tools

            if not save_path:
                desktop = os.path.join(os.path.expanduser("~"), "Desktop")
                save_path = os.path.join(desktop, "screenshot.png")

            with mss.mss() as sct:
                if region:
                    x, y, w, h = region
                    monitor = {"top": y, "left": x, "width": w, "height": h}
                else:
                    monitor = sct.monitors[1]  # Primary monitor

                img = sct.grab(monitor)
                mss.tools.to_png(img.rgb, img.size, output=save_path)

            if self.verbose:
                logger.info(f"Screenshot saved: {save_path}")
            return save_path

        except ImportError:
            return self._fallback_screenshot(save_path)

    def _fallback_screenshot(self, save_path: Optional[str] = None) -> str:
        """Fallback using PIL if mss not available."""
        try:
            from PIL import ImageGrab
            if not save_path:
                save_path = os.path.join(os.path.expanduser("~"), "Desktop", "screenshot.png")
            img = ImageGrab.grab()
            img.save(save_path)
            return save_path
        except Exception as e:
            return f"Error taking screenshot: {e}"

    def read_text(self, image_path: Optional[str] = None, region: Optional[Tuple] = None) -> str:
        """
        Read all text visible on screen using OCR (Tesseract).

        Args:
            image_path: Path to image to read. None = take new screenshot.
            region:     Screen region to read (x, y, w, h)

        Returns:
            All text found on screen as a string.

        Example:
            text = ai.screen.read_text()
            text = ai.screen.read_text(region=(100, 100, 500, 300))
        """
        try:
            import pytesseract
            from PIL import Image

            if not image_path:
                image_path = self.screenshot(region=region)

            text = pytesseract.image_to_string(Image.open(image_path))
            return text.strip()

        except ImportError:
            return "pytesseract not installed. Run: pip install pytesseract pillow"
        except Exception as e:
            return f"Error reading screen text: {e}"

    def find_text_on_screen(self, text: str) -> Optional[Tuple[int, int]]:
        """
        Find where specific text appears on screen. Returns (x, y) coordinates.

        Args:
            text: The text to find on screen.

        Returns:
            (x, y) center coordinates of the text, or None if not found.

        Example:
            pos = ai.screen.find_text_on_screen("Submit")
            if pos:
                ai.kb.click(*pos)
        """
        try:
            import pytesseract
            from PIL import Image, ImageGrab
            import numpy as np

            screen = ImageGrab.grab()
            data = pytesseract.image_to_data(screen, output_type=pytesseract.Output.DICT)

            for i, word in enumerate(data["text"]):
                if text.lower() in word.lower() and int(data["conf"][i]) > 60:
                    x = data["left"][i] + data["width"][i] // 2
                    y = data["top"][i] + data["height"][i] // 2
                    return (x, y)
            return None

        except Exception as e:
            logger.error(f"find_text_on_screen error: {e}")
            return None

    def find_image_on_screen(self, template_path: str, confidence: float = 0.8) -> Optional[Tuple[int, int]]:
        """
        Find an image/icon on screen using template matching (OpenCV).

        Args:
            template_path: Path to the image to look for.
            confidence:    Match confidence 0-1. Default 0.8.

        Returns:
            (x, y) center coordinates, or None if not found.

        Example:
            pos = ai.screen.find_image_on_screen("close_button.png")
            if pos:
                ai.kb.click(*pos)
        """
        try:
            import cv2
            import numpy as np
            from PIL import ImageGrab

            screen = np.array(ImageGrab.grab())
            screen_gray = cv2.cvtColor(screen, cv2.COLOR_RGB2GRAY)
            template = cv2.imread(template_path, cv2.IMREAD_GRAYSCALE)

            result = cv2.matchTemplate(screen_gray, template, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(result)

            if max_val >= confidence:
                h, w = template.shape
                center_x = max_loc[0] + w // 2
                center_y = max_loc[1] + h // 2
                return (center_x, center_y)
            return None

        except Exception as e:
            logger.error(f"find_image_on_screen error: {e}")
            return None

    def get_screen_size(self) -> Tuple[int, int]:
        """
        Get the screen width and height.

        Returns:
            (width, height) in pixels.
        """
        try:
            import pyautogui
            return pyautogui.size()
        except Exception:
            return (1920, 1080)

    def watch_for_change(self, region: Tuple, callback, interval: float = 1.0):
        """
        Watch a screen region and call callback when it changes.

        Args:
            region:   (x, y, w, h) region to monitor
            callback: Function to call when change detected
            interval: Check every N seconds

        Example:
            def on_change():
                print("Screen changed!")
            ai.screen.watch_for_change((0, 0, 300, 100), on_change, interval=0.5)
        """
        import time
        import threading
        from PIL import ImageGrab
        import numpy as np

        def _watch():
            prev = None
            while True:
                x, y, w, h = region
                current = np.array(ImageGrab.grab(bbox=(x, y, x+w, y+h)))
                if prev is not None and not np.array_equal(current, prev):
                    callback()
                prev = current
                time.sleep(interval)

        t = threading.Thread(target=_watch, daemon=True)
        t.start()
        return t
