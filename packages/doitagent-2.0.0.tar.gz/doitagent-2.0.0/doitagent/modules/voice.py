"""
VoiceModule — Speech recognition and Text-to-Speech. 100% free, runs locally.
Uses OpenAI Whisper (free/local) for STT and pyttsx3 for TTS.
"""

import os
import logging
from typing import Optional

logger = logging.getLogger("doit.voice")


class VoiceModule:
    """Listen to voice commands and speak responses. All free, all local."""

    def __init__(self, verbose: bool = True):
        self.verbose = verbose

    def listen(self, duration: int = 5, language: str = "en") -> str:
        """
        Listen for a voice command via microphone.
        Uses OpenAI Whisper locally (free, very accurate).

        Args:
            duration: How many seconds to listen. Default 5.
            language: Language code. Default "en".

        Returns:
            Transcribed text of what was spoken.

        Example:
            command = ai.voice.listen()
            command = ai.voice.listen(duration=10)
        """
        # Try Whisper first (most accurate)
        try:
            import whisper
            import sounddevice as sd
            import numpy as np
            import tempfile
            import scipy.io.wavfile as wav

            if self.verbose:
                logger.info(f"Listening for {duration}s...")

            audio = sd.rec(int(duration * 16000), samplerate=16000, channels=1, dtype="float32")
            sd.wait()

            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                wav.write(f.name, 16000, (audio * 32767).astype("int16"))
                tmp_path = f.name

            model = whisper.load_model("base")
            result = model.transcribe(tmp_path, language=language)
            os.unlink(tmp_path)

            text = result["text"].strip()
            if self.verbose:
                logger.info(f"Heard: {text}")
            return text

        except ImportError:
            return self._listen_speechrecognition(duration)

    def _listen_speechrecognition(self, duration: int = 5) -> str:
        """Fallback: use SpeechRecognition library (requires internet)."""
        try:
            import speech_recognition as sr
            r = sr.Recognizer()
            with sr.Microphone() as source:
                r.adjust_for_ambient_noise(source, duration=0.5)
                if self.verbose:
                    logger.info(f"Listening for {duration}s...")
                audio = r.listen(source, timeout=duration, phrase_time_limit=duration)
            return r.recognize_google(audio)
        except ImportError:
            return "No STT library. Install: pip install openai-whisper sounddevice scipy"
        except Exception as e:
            return f"Listening error: {e}"

    def speak(self, text: str, rate: int = 175, volume: float = 1.0) -> str:
        """
        Convert text to speech and play it.

        Args:
            text:   Text to speak.
            rate:   Speaking rate (words per minute). Default 175.
            volume: Volume 0.0-1.0. Default 1.0.

        Returns:
            Confirmation.

        Example:
            ai.voice.speak("Task completed successfully!")
            ai.voice.speak("Error occurred. Please try again.", rate=150)
        """
        try:
            import pyttsx3
            engine = pyttsx3.init()
            engine.setProperty("rate", rate)
            engine.setProperty("volume", volume)
            engine.say(text)
            engine.runAndWait()
            return f"Spoke: {text[:60]}..."
        except ImportError:
            return self._speak_powershell(text)

    def _speak_powershell(self, text: str) -> str:
        """Fallback: use Windows built-in SAPI TTS via PowerShell."""
        import subprocess
        text_safe = text.replace("'", " ").replace('"', " ")
        ps = f"Add-Type -AssemblyName System.speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{text_safe}')"
        subprocess.run(["powershell", "-Command", ps])
        return f"Spoke (SAPI): {text[:60]}"

    def transcribe_file(self, audio_path: str, language: str = "en") -> str:
        """
        Transcribe an audio file to text using Whisper.

        Args:
            audio_path: Path to audio file (.wav, .mp3, .m4a, etc.)
            language:   Language code.

        Returns:
            Full transcription as text.

        Example:
            text = ai.voice.transcribe_file("~/recordings/meeting.mp3")
        """
        try:
            import whisper
            audio_path = os.path.expanduser(audio_path)
            model = whisper.load_model("base")
            result = model.transcribe(audio_path, language=language)
            return result["text"]
        except ImportError:
            return "Whisper not installed. Run: pip install openai-whisper"

    def save_speech(self, text: str, output_path: str) -> str:
        """
        Convert text to speech and save as audio file.

        Args:
            text:        Text to convert.
            output_path: Save path (.mp3, .wav).

        Returns:
            Path to audio file.

        Example:
            path = ai.voice.save_speech("Hello World", "~/Desktop/hello.mp3")
        """
        output_path = os.path.expanduser(output_path)
        try:
            import pyttsx3
            engine = pyttsx3.init()
            engine.save_to_file(text, output_path)
            engine.runAndWait()
            return output_path
        except Exception as e:
            return f"Error saving speech: {e}"

    def list_voices(self) -> list:
        """List available TTS voices on the system."""
        try:
            import pyttsx3
            engine = pyttsx3.init()
            voices = engine.getProperty("voices")
            return [{"id": v.id, "name": v.name, "languages": v.languages} for v in voices]
        except Exception as e:
            return [{"error": str(e)}]
