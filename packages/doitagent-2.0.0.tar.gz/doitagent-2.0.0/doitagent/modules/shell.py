"""
ShellModule — Run any shell command, PowerShell, Python scripts.
The hands of the agent for system-level operations.
"""

import os
import subprocess
import logging
import sys
from typing import Optional, List

logger = logging.getLogger("doit.shell")

DANGEROUS_PATTERNS = [
    "format c:", "rm -rf /", "del /s /q c:", 
    "shutdown /s", "reg delete", "diskpart"
]


class ShellModule:
    """Execute shell commands, PowerShell, batch scripts, Python files."""

    def __init__(self, verbose: bool = True, safe_mode: bool = True):
        self.verbose = verbose
        self.safe_mode = safe_mode

    def run(self, command: str, shell: bool = True, timeout: int = 60, cwd: Optional[str] = None) -> str:
        """
        Run a shell command (cmd.exe / bash).

        Args:
            command: The command to run.
            shell:   Use shell mode. Default True.
            timeout: Max seconds to wait. Default 60.
            cwd:     Working directory for the command.

        Returns:
            Command stdout output (or stderr if error).

        Example:
            output = ai.shell.run("dir C:/Users")
            output = ai.shell.run("python --version")
            output = ai.shell.run("ipconfig")
        """
        if self._is_dangerous(command):
            return f"Blocked: dangerous command detected: {command}"

        try:
            result = subprocess.run(
                command,
                shell=shell,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=cwd,
            )
            output = result.stdout.strip() or result.stderr.strip()
            if self.verbose:
                logger.info(f"CMD: {command[:60]} → {output[:80]}")
            return output or "(no output)"

        except subprocess.TimeoutExpired:
            return f"Command timed out after {timeout}s: {command}"
        except Exception as e:
            return f"Error running command: {e}"

    def powershell(self, script: str, timeout: int = 60) -> str:
        """
        Run a PowerShell script or command.

        Args:
            script:  PowerShell code to execute.
            timeout: Max wait time in seconds.

        Returns:
            Output from PowerShell.

        Example:
            output = ai.shell.powershell("Get-Process | Select-Object Name, CPU | Sort-Object CPU -Descending")
            output = ai.shell.powershell("Get-EventLog -LogName System -Newest 10")
            ai.shell.powershell("Set-Volume -DriveLetter C -NewFileSystemLabel 'MyDrive'")
        """
        cmd = f'powershell -NonInteractive -Command "{script.replace(chr(34), chr(39))}"'
        return self.run(cmd, timeout=timeout)

    def run_python(self, script_path: str, args: List[str] = None) -> str:
        """
        Run a Python script file.

        Args:
            script_path: Path to .py file.
            args:        List of arguments to pass.

        Returns:
            Script output.

        Example:
            output = ai.shell.run_python("~/scripts/process_data.py", ["--input", "data.csv"])
        """
        script_path = os.path.expanduser(script_path)
        cmd = [sys.executable, script_path] + (args or [])
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return result.stdout or result.stderr

    def run_python_code(self, code: str) -> str:
        """
        Execute Python code directly (inline).

        Args:
            code: Python code as string.

        Returns:
            Output/result of execution.

        Example:
            result = ai.shell.run_python_code("import math; print(math.pi)")
        """
        import tempfile
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(code)
            tmp_path = f.name
        try:
            result = self.run_python(tmp_path)
        finally:
            os.unlink(tmp_path)
        return result

    def open_app(self, app: str) -> str:
        """
        Open an application by name or path.

        Args:
            app: App name ("notepad", "calc", "chrome") or full path.

        Returns:
            Confirmation.

        Example:
            ai.shell.open_app("notepad")
            ai.shell.open_app("calc")
            ai.shell.open_app("C:/Program Files/VLC/vlc.exe")
        """
        app_shortcuts = {
            "notepad": "notepad.exe",
            "calculator": "calc.exe",
            "calc": "calc.exe",
            "paint": "mspaint.exe",
            "explorer": "explorer.exe",
            "chrome": "chrome",
            "firefox": "firefox",
            "edge": "msedge",
            "word": "winword",
            "excel": "excel",
            "powerpoint": "powerpnt",
            "vlc": "vlc",
            "spotify": "spotify",
            "vscode": "code",
        }
        app_cmd = app_shortcuts.get(app.lower(), app)
        subprocess.Popen(app_cmd, shell=True)
        return f"Opened: {app}"

    def kill_process(self, process_name: str) -> str:
        """
        Kill a running process by name.

        Args:
            process_name: e.g. "notepad.exe", "chrome.exe"

        Returns:
            Confirmation.

        Example:
            ai.shell.kill_process("notepad.exe")
        """
        return self.run(f"taskkill /F /IM {process_name}")

    def list_processes(self) -> str:
        """List all running processes."""
        return self.run("tasklist /FO TABLE")

    def set_env_var(self, name: str, value: str, permanent: bool = False) -> str:
        """
        Set an environment variable.

        Args:
            name:      Variable name.
            value:     Variable value.
            permanent: Save permanently to system. Default False (session only).
        """
        os.environ[name] = value
        if permanent:
            self.run(f'setx {name} "{value}"')
            return f"Permanently set {name}={value}"
        return f"Set {name}={value} (session only)"

    def get_env_var(self, name: str) -> str:
        """Get the value of an environment variable."""
        return os.environ.get(name, f"(not set: {name})")

    def pip_install(self, package: str) -> str:
        """
        Install a Python package via pip.

        Args:
            package: Package name. e.g. "requests", "pandas==2.0"

        Returns:
            Installation output.

        Example:
            ai.shell.pip_install("pandas")
            ai.shell.pip_install("playwright")
        """
        return self.run(f"{sys.executable} -m pip install {package}")

    def create_bat_script(self, commands: List[str], save_path: str) -> str:
        """
        Create and optionally run a Windows batch script.

        Args:
            commands:  List of commands for the script.
            save_path: Where to save the .bat file.

        Returns:
            Path to the created batch file.
        """
        save_path = os.path.expanduser(save_path)
        with open(save_path, "w") as f:
            f.write("@echo off\n")
            for cmd in commands:
                f.write(cmd + "\n")
        return save_path

    def _is_dangerous(self, command: str) -> bool:
        """Check if a command matches known dangerous patterns."""
        if not self.safe_mode:
            return False
        cmd_lower = command.lower()
        return any(pattern in cmd_lower for pattern in DANGEROUS_PATTERNS)
