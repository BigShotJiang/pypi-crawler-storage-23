"""
BrowserModule — Full web browser control.
Open pages, click, fill forms, scrape data, take web screenshots.
Powered by Playwright (free, open source).
"""

import logging
from typing import Optional, List, Any

logger = logging.getLogger("doit.browser")


class BrowserModule:
    """Control any web browser - chromium, firefox, webkit."""

    def __init__(self, verbose: bool = True, browser_type: str = "chromium", headless: bool = False):
        self.verbose = verbose
        self.browser_type = browser_type
        self.headless = headless
        self._browser = None
        self._page = None
        self._playwright = None

    def _ensure_open(self):
        """Lazily start browser on first use."""
        if self._page is None:
            self.open()

    def open(self, url: Optional[str] = None, headless: bool = False) -> str:
        """
        Open the browser (and optionally navigate to a URL).

        Args:
            url:      URL to open. e.g. "https://google.com"
            headless: Run without visible window. Default False.

        Returns:
            Current page URL.

        Example:
            ai.browser.open("https://google.com")
            ai.browser.open("https://youtube.com")
        """
        try:
            from playwright.sync_api import sync_playwright

            if self._playwright is None:
                self._playwright = sync_playwright().start()

            browser_fn = getattr(self._playwright, self.browser_type)
            self._browser = browser_fn.launch(headless=headless or self.headless)
            self._page = self._browser.new_page()

            if url:
                self._page.goto(url, wait_until="domcontentloaded")
                if self.verbose:
                    logger.info(f"Opened: {url}")

            return self._page.url

        except ImportError:
            return "Playwright not installed. Run: pip install playwright && playwright install chromium"
        except Exception as e:
            return f"Error opening browser: {e}"

    def goto(self, url: str) -> str:
        """
        Navigate to a URL.

        Args:
            url: Full URL to navigate to.

        Returns:
            Current page URL.

        Example:
            ai.browser.goto("https://news.ycombinator.com")
        """
        self._ensure_open()
        self._page.goto(url, wait_until="domcontentloaded")
        return self._page.url

    def click(self, selector: str) -> str:
        """
        Click on an element.

        Args:
            selector: CSS selector, text, or XPath.
                      Examples: "button#submit", "text=Login", "//input[@name='q']"

        Returns:
            Confirmation message.

        Example:
            ai.browser.click("text=Sign In")
            ai.browser.click("button.submit-btn")
        """
        self._ensure_open()
        self._page.click(selector)
        return f"Clicked: {selector}"

    def type_text(self, selector: str, text: str, clear_first: bool = True) -> str:
        """
        Type text into an input field.

        Args:
            selector:    CSS selector of the input.
            text:        Text to type.
            clear_first: Clear existing content first. Default True.

        Returns:
            Confirmation message.

        Example:
            ai.browser.type_text("input[name='q']", "python tutorials")
            ai.browser.type_text("#username", "myuser@email.com")
        """
        self._ensure_open()
        if clear_first:
            self._page.fill(selector, "")
        self._page.type(selector, text)
        return f"Typed '{text}' into {selector}"

    def search_google(self, query: str) -> str:
        """
        Open Google and search for a query.

        Args:
            query: What to search for.

        Returns:
            Page HTML or summary of results.

        Example:
            results = ai.browser.search_google("python automation tutorial")
        """
        self._ensure_open()
        self._page.goto("https://www.google.com")
        self._page.fill("textarea[name='q']", query)
        self._page.keyboard.press("Enter")
        self._page.wait_for_load_state("domcontentloaded")
        return self.get_text("body")[:2000]

    def get_text(self, selector: str = "body") -> str:
        """
        Get text content of a page or element.

        Args:
            selector: CSS selector. Default "body" = full page text.

        Returns:
            Text content.

        Example:
            text = ai.browser.get_text("h1")
            full_text = ai.browser.get_text()
        """
        self._ensure_open()
        try:
            return self._page.inner_text(selector)
        except Exception:
            return self._page.content()

    def get_html(self, selector: str = "html") -> str:
        """Get HTML of a page or element."""
        self._ensure_open()
        return self._page.inner_html(selector)

    def screenshot(self, save_path: str = "browser_screenshot.png", full_page: bool = True) -> str:
        """
        Take a screenshot of the current web page.

        Args:
            save_path: Where to save the screenshot.
            full_page: Capture full scrollable page. Default True.

        Returns:
            Path to saved screenshot.
        """
        self._ensure_open()
        self._page.screenshot(path=save_path, full_page=full_page)
        return save_path

    def scroll(self, direction: str = "down", amount: int = 500) -> str:
        """
        Scroll the page.

        Args:
            direction: "up", "down", "top", "bottom"
            amount:    Pixels to scroll. Default 500.
        """
        self._ensure_open()
        if direction == "down":
            self._page.evaluate(f"window.scrollBy(0, {amount})")
        elif direction == "up":
            self._page.evaluate(f"window.scrollBy(0, -{amount})")
        elif direction == "top":
            self._page.evaluate("window.scrollTo(0, 0)")
        elif direction == "bottom":
            self._page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        return f"Scrolled {direction}"

    def fill_form(self, field_map: dict) -> str:
        """
        Fill multiple form fields at once.

        Args:
            field_map: Dict of {selector: value} pairs.

        Returns:
            Confirmation.

        Example:
            ai.browser.fill_form({
                "#first-name": "John",
                "#last-name": "Doe",
                "#email": "john@example.com",
            })
        """
        self._ensure_open()
        for selector, value in field_map.items():
            self._page.fill(selector, value)
        return f"Filled {len(field_map)} fields"

    def get_all_links(self) -> List[dict]:
        """Get all links on the current page."""
        self._ensure_open()
        links = self._page.eval_on_selector_all(
            "a[href]",
            "els => els.map(el => ({text: el.innerText.trim(), href: el.href}))"
        )
        return links

    def execute_js(self, script: str) -> Any:
        """
        Run arbitrary JavaScript on the page.

        Args:
            script: JavaScript code to execute.

        Returns:
            Return value of the script.

        Example:
            title = ai.browser.execute_js("return document.title")
            ai.browser.execute_js("document.querySelector('#popup').remove()")
        """
        self._ensure_open()
        return self._page.evaluate(script)

    def wait_for(self, selector: str, timeout: int = 10000) -> str:
        """
        Wait for an element to appear on the page.

        Args:
            selector: CSS selector to wait for.
            timeout:  Max wait time in ms. Default 10000.
        """
        self._ensure_open()
        self._page.wait_for_selector(selector, timeout=timeout)
        return f"Element appeared: {selector}"

    def download_file(self, url: str, save_path: str) -> str:
        """
        Download a file from a URL.

        Args:
            url:       Direct URL to the file.
            save_path: Local path to save to.

        Returns:
            Path to downloaded file.
        """
        import requests
        import os
        save_path = os.path.expanduser(save_path)
        response = requests.get(url, stream=True)
        with open(save_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        return save_path

    def close(self):
        """Close the browser."""
        if self._browser:
            self._browser.close()
        if self._playwright:
            self._playwright.stop()
        self._browser = None
        self._page = None
        self._playwright = None
        return "Browser closed"

    def get_current_url(self) -> str:
        """Get the current page URL."""
        if self._page:
            return self._page.url
        return "Browser not open"

    def get_title(self) -> str:
        """Get the current page title."""
        self._ensure_open()
        return self._page.title()
