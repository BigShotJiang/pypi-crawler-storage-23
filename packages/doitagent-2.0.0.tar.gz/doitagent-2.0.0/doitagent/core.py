"""
Agent — The main DoItAgent class.
Ties together all modules, LLM, memory, security, and the executor.
"""

from __future__ import annotations

import logging
import os
import threading
from pathlib import Path
from typing import Any, Callable, Optional

from doitagent.config import Config, AgentConfig
from doitagent.exceptions import ConfigError, ModuleError
from doitagent.llm.client import LLMClient
from doitagent.agent.executor import AgentExecutor
from doitagent.agent.memory import Memory
from doitagent.security.sandbox import Sandbox

logger = logging.getLogger("doitagent.core")


class Agent:
    """
    DoItAgent — Your personal AI that controls your PC.

    Quick start:
        from doitagent import Agent
        ai = Agent()
        ai.do("take a screenshot")
        ai.do("create a Word document about AI")
        ai.do("search for Python tutorials")

    With custom LLM:
        ai = Agent.with_ollama("mistral")
        ai = Agent.with_nvidia("nvapi-...", model="llama-3.1-70b")
        ai = Agent.with_anthropic("sk-ant-...", model="claude-opus-4-6")

    Direct module access:
        ai.screen.screenshot()
        ai.files.create_file("~/notes.txt", "hello")
        ai.browser.goto("https://google.com")
        ai.shell.run("ipconfig")
        ai.docs.create_word("report.docx", title="My Report")
        ai.db.insert("tasks", {"name": "Buy milk", "done": False})
        ai.voice.speak("Task complete!")
        ai.search.web_search("python tutorials")
        ai.media.play_youtube("lofi music")
        ai.email.send("boss@company.com", "Done", "Report attached.")
    """

    def __init__(
        self,
        config: Optional[Config] = None,
        llm: Optional[str] = None,
        model: Optional[str] = None,
        api_key: Optional[str] = None,
        verbose: bool = False,
        safe_mode: bool = True,
        memory: bool = True,
        auto_install: bool = True,
    ):
        """
        Initialize DoItAgent.

        Args:
            config:      Full Config object (auto-loads from disk if None).
            llm:         LLM backend: "ollama" | "nvidia" | "anthropic" | "openai" | "deepseek"
            model:       Model name. e.g. "mistral", "claude-opus-4-6", "gpt-4o"
            api_key:     API key for cloud LLMs. Not needed for Ollama.
            verbose:     Log each step taken. Default False.
            safe_mode:   Confirm before destructive actions. Default True.
            memory:      Remember past tasks. Default True.
            auto_install: Auto pip-install missing packages. Default True.
        """
        # Load or build config
        if config is None:
            cfg = Config.load()
            if llm:
                cfg.llm.backend = llm
            if model:
                cfg.llm.model = model
            if api_key:
                cfg.llm.api_key = api_key
            cfg.security.safe_mode = safe_mode
            cfg.agent.verbose = verbose
            cfg.agent.memory_enabled = memory
            cfg.agent.auto_install_deps = auto_install
            self._cfg = cfg
        else:
            self._cfg = config

        # Setup logging
        from doitagent.utils.logger import setup_logging
        from doitagent.config import LOG_DIR
        setup_logging(verbose=verbose, log_file=LOG_DIR / "agent.log")

        # Initialize core components
        self._llm   = LLMClient(self._cfg.llm)
        self._memory = Memory(self._cfg.agent.memory_max_entries) if self._cfg.agent.memory_enabled else Memory(0)
        self._sandbox = Sandbox(self._cfg.security)

        # Initialize all modules
        self._init_modules()

        # Build tool registry
        self._tools = self._build_tools()

        # Initialize executor
        self._executor = AgentExecutor(
            llm=self._llm,
            tools=self._tools,
            memory=self._memory,
            config=self._cfg.agent,
        )

        if verbose:
            logger.info(f"Agent ready — {self._llm.backend}/{self._llm.model} | {len(self._tools)} tools")

    # ─── Factory methods ──────────────────────────────────────────────────────

    @classmethod
    def with_ollama(cls, model: str = "mistral", **kwargs) -> "Agent":
        """Create an Agent using Ollama (free local LLM)."""
        return cls(llm="ollama", model=model, **kwargs)

    @classmethod
    def with_nvidia(cls, api_key: str, model: str = "llama-3.1-70b", **kwargs) -> "Agent":
        """Create an Agent using NVIDIA NIM (free tier available)."""
        return cls(llm="nvidia", model=model, api_key=api_key, **kwargs)

    @classmethod
    def with_anthropic(cls, api_key: str, model: str = "claude-opus-4-6", **kwargs) -> "Agent":
        """Create an Agent using Anthropic Claude."""
        return cls(llm="anthropic", model=model, api_key=api_key, **kwargs)

    @classmethod
    def with_openai(cls, api_key: str, model: str = "gpt-4o", **kwargs) -> "Agent":
        """Create an Agent using OpenAI."""
        return cls(llm="openai", model=model, api_key=api_key, **kwargs)

    @classmethod
    def with_deepseek(cls, api_key: str, model: str = "deepseek-chat", **kwargs) -> "Agent":
        """Create an Agent using DeepSeek."""
        return cls(llm="deepseek", model=model, api_key=api_key, **kwargs)

    # ─── Primary API ──────────────────────────────────────────────────────────

    def do(self, task: str, confirm: bool = False) -> Any:
        """
        Execute any task in natural language.

        This is the primary method. The agent will reason about the task,
        call the appropriate tools, and return the result.

        Args:
            task:    What you want done. Anything goes.
            confirm: If True, show the plan before executing.

        Returns:
            Result of the task (string, file path, data, etc.)

        Examples:
            ai.do("take a screenshot")
            ai.do("create an Excel report from ~/data.csv")
            ai.do("find all PDFs in Downloads folder and zip them")
            ai.do("search the web for Python automation tools")
            ai.do("play lofi music on youtube")
            ai.do("create a Word document summarizing today's AI news")
            ai.do("what is my current IP address?")
        """
        confirm_cb = (lambda plan: input(f"\nPlan: {plan}\nExecute? (y/n): ").lower() == "y") if confirm else None
        return self._executor.run(task, confirm_callback=confirm_cb)

    def pipeline(self, *tasks: str) -> list:
        """
        Run multiple tasks sequentially, passing results forward.

        Args:
            *tasks: Tasks to run in order.

        Returns:
            List of results.

        Example:
            ai.pipeline(
                "search the web for top 5 Python frameworks in 2024",
                "create a Word doc summarizing the results",
                "save it to Desktop as frameworks.docx",
            )
        """
        results = []
        context = ""
        for task in tasks:
            full_task = f"{task}. Previous result context: {context[:300]}" if context else task
            result = self.do(full_task)
            results.append(result)
            context = str(result)
        return results

    def watch(self, trigger: str, action: str, interval: int = 30) -> threading.Thread:
        """
        Monitor a condition and auto-execute an action when it triggers.

        Args:
            trigger:  Natural language condition to watch for.
                      e.g. "new file appears in Downloads folder"
            action:   What to do when triggered.
                      e.g. "move the file to Documents and notify me"
            interval: Check every N seconds. Default 30.

        Returns:
            Background thread (daemon).

        Example:
            ai.watch(
                trigger="CPU usage exceeds 90%",
                action="list the top 10 processes by CPU and notify me",
                interval=60,
            )
        """
        import time

        def _loop():
            logger.info(f"Watching: {trigger!r}")
            while True:
                try:
                    resp = self._llm.complete(
                        f"Is this condition currently true? Answer ONLY 'yes' or 'no':\n{trigger}"
                    )
                    if "yes" in resp.lower():
                        logger.info(f"Trigger fired: {trigger}")
                        self.do(action)
                except Exception as e:
                    logger.error(f"Watch error: {e}")
                time.sleep(interval)

        t = threading.Thread(target=_loop, daemon=True)
        t.start()
        return t

    def schedule(self, task: str, when: str) -> Any:
        """
        Schedule a task to run at a specific time or interval.

        Args:
            task: What to do.
            when: Natural language schedule.
                  e.g. "every day at 9am", "every monday at 8:30am",
                       "in 30 minutes", "every hour"

        Returns:
            APScheduler job.

        Example:
            ai.schedule("take a screenshot and save with timestamp", "every day at 9am")
            ai.schedule("search for AI news and save to daily_news.txt", "every morning at 7am")
        """
        try:
            from apscheduler.schedulers.background import BackgroundScheduler
        except ImportError:
            return "apscheduler not installed. Run: pip install apscheduler"

        # Parse the natural language schedule
        cron = self._llm.complete(
            f"Convert this schedule to a cron expression. Return ONLY the cron string (5 fields), nothing else:\n'{when}'"
        ).strip()

        sched = BackgroundScheduler()
        try:
            from apscheduler.triggers.cron import CronTrigger
            job = sched.add_job(
                lambda: self.do(task),
                CronTrigger.from_crontab(cron),
                id=f"doit_{hash(task)}",
            )
            sched.start()
            logger.info(f"Scheduled '{task[:50]}' — {when} (cron: {cron})")
            return job
        except Exception as e:
            # Fallback: interval-based
            logger.warning(f"Cron parse failed ({cron}): {e}. Using interval.")
            job = sched.add_job(lambda: self.do(task), "interval", minutes=60)
            sched.start()
            return job

    def learn(self, skill_name: str, description: str, steps: list[str]) -> str:
        """
        Teach the agent a reusable multi-step skill.

        Args:
            skill_name:  Name to call this skill.
            description: Brief description.
            steps:       List of steps to execute in order.

        Returns:
            Confirmation string.

        Example:
            ai.learn(
                skill_name="morning_briefing",
                description="My morning startup routine",
                steps=[
                    "take a screenshot",
                    "search web for today's tech news",
                    "save news to ~/Desktop/news.txt",
                    "say 'Good morning! Your briefing is ready.'",
                ],
            )
            ai.do("run morning_briefing skill")
        """
        self._memory.save_skill(skill_name, description, steps)
        return f"Skill '{skill_name}' saved with {len(steps)} steps. Use: ai.do('run {skill_name} skill')"

    def listen(self):
        """
        Start voice command mode. Listens continuously for spoken commands.
        Say 'DoIt stop' to exit voice mode.

        Requires: pip install doitagent[voice]
        """
        logger.info("Voice mode active. Say 'DoIt stop' to exit.")
        while True:
            try:
                command = self.voice.listen(duration=6)
                if not command:
                    continue
                logger.info(f"Voice: {command}")
                if "doit stop" in command.lower() or "do it stop" in command.lower():
                    self.voice.speak("Goodbye!")
                    break
                result = self.do(command)
                # Speak a summary (max 200 chars)
                summary = str(result)[:200]
                self.voice.speak(summary)
            except KeyboardInterrupt:
                break

    def status(self) -> dict:
        """Return a dict with agent status information."""
        import platform
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=1)
            ram = psutil.virtual_memory()
            sys_info = {"cpu": cpu, "ram_used_gb": round(ram.used/1e9, 2), "ram_pct": ram.percent}
        except Exception:
            sys_info = {}

        mem_stats = self._memory.stats()
        return {
            "version": "2.0.0",
            "llm": f"{self._llm.backend}/{self._llm.model}",
            "tools": len(self._tools),
            "memory": mem_stats,
            "safe_mode": self._cfg.security.safe_mode,
            "platform": platform.system(),
            "system": sys_info,
        }

    def print_status(self):
        """Print a formatted status table to the terminal."""
        s = self.status()
        try:
            from rich.table import Table
            from rich.console import Console
            from rich import box
            console = Console()
            t = Table(title="🤖 DoItAgent Status", box=box.ROUNDED)
            t.add_column("Property", style="cyan")
            t.add_column("Value", style="green")
            for k, v in s.items():
                t.add_row(str(k), str(v))
            console.print(t)
        except ImportError:
            for k, v in s.items():
                print(f"  {k}: {v}")

    # ─── Module initialization ─────────────────────────────────────────────────

    def _init_modules(self):
        """Lazy-initialize all capability modules."""
        cfg = self._cfg.agent
        sandbox = self._sandbox

        from doitagent.modules.screen import ScreenModule
        from doitagent.modules.files import FilesModule
        from doitagent.modules.browser import BrowserModule
        from doitagent.modules.shell import ShellModule
        from doitagent.modules.keyboard_mouse import KeyboardMouseModule
        from doitagent.modules.system import SystemModule
        from doitagent.modules.media import MediaModule
        from doitagent.modules.documents import DocumentsModule
        from doitagent.modules.database import DatabaseModule
        from doitagent.modules.search import SearchModule
        from doitagent.modules.voice import VoiceModule
        from doitagent.modules.email_mod import EmailModule

        verbose = self._cfg.agent.verbose
        safe = self._cfg.security.safe_mode

        self.screen  = ScreenModule(verbose=verbose)
        self.files   = FilesModule(verbose=verbose, safe_mode=safe)
        self.browser = BrowserModule(verbose=verbose)
        self.shell   = ShellModule(verbose=verbose, safe_mode=safe)
        self.kb      = KeyboardMouseModule(verbose=verbose)
        self.system  = SystemModule(verbose=verbose, safe_mode=safe)
        self.media   = MediaModule(verbose=verbose)
        self.docs    = DocumentsModule(verbose=verbose)
        self.db      = DatabaseModule(verbose=verbose)
        self.search  = SearchModule(verbose=verbose)
        self.voice   = VoiceModule(verbose=verbose)
        self.email   = EmailModule(verbose=verbose)

    def _build_tools(self) -> dict:
        """Collect all module methods into a flat tool registry."""
        registry = {}
        modules = {
            "screen":  self.screen,
            "files":   self.files,
            "browser": self.browser,
            "shell":   self.shell,
            "kb":      self.kb,
            "system":  self.system,
            "media":   self.media,
            "docs":    self.docs,
            "db":      self.db,
            "search":  self.search,
            "voice":   self.voice,
            "email":   self.email,
        }
        import inspect
        for module_name, module_obj in modules.items():
            for method_name in dir(module_obj):
                if method_name.startswith("_"):
                    continue
                method = getattr(module_obj, method_name)
                if (
                    callable(method)
                    and hasattr(method, "__doc__")
                    and method.__doc__
                    and not method_name.startswith("tools")
                ):
                    registry[f"{module_name}.{method_name}"] = method
        return registry

    # ─── Properties ───────────────────────────────────────────────────────────

    @property
    def memory(self) -> Memory:
        return self._memory

    @property
    def llm(self) -> LLMClient:
        return self._llm

    @property
    def tools(self) -> dict:
        return self._tools

    def __repr__(self) -> str:
        return f"Agent(llm={self._llm.backend!r}, model={self._llm.model!r}, tools={len(self._tools)})"
