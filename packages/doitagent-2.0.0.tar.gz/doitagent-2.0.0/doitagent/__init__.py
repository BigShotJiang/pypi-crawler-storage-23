"""
DoItAgent v2.0.0 — The World's Most Powerful Personal AGI Agent
"""
from doitagent._version import __version__
from doitagent.core import Agent
from doitagent.exceptions import DoItAgentError, LLMError, ModuleError, SecurityError, ConfigError

__all__ = ["Agent", "__version__", "DoItAgentError", "LLMError", "ModuleError", "SecurityError", "ConfigError"]
__author__ = "DoItAgent Contributors"
__license__ = "MIT"
