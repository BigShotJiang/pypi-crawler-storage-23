"""
Secure configuration management for DoItAgent.
Config is stored encrypted at ~/.doitagent/config.json
Secrets (API keys, tokens) stored in system keyring when available.
"""

from __future__ import annotations

import json
import os
import platform
import logging
from pathlib import Path
from typing import Any, Optional
from dataclasses import dataclass, field, asdict

logger = logging.getLogger("doitagent.config")

# Platform-specific config dir
def _config_dir() -> Path:
    if platform.system() == "Windows":
        base = Path(os.environ.get("APPDATA", Path.home()))
    elif platform.system() == "Darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    d = base / "doitagent"
    d.mkdir(parents=True, exist_ok=True)
    return d

CONFIG_DIR = _config_dir()
CONFIG_FILE = CONFIG_DIR / "config.json"
LOG_DIR = CONFIG_DIR / "logs"
MEMORY_DIR = CONFIG_DIR / "memory"
SKILLS_DIR = CONFIG_DIR / "skills"
SANDBOX_DIR = CONFIG_DIR / "sandbox"

for _d in (LOG_DIR, MEMORY_DIR, SKILLS_DIR, SANDBOX_DIR):
    _d.mkdir(parents=True, exist_ok=True)


@dataclass
class LLMConfig:
    backend: str = "ollama"          # ollama | nvidia | anthropic | openai | deepseek
    model: str = "mistral"
    api_key: str = ""
    temperature: float = 0.7
    max_tokens: int = 4096
    timeout: int = 120
    base_url: str = ""               # For custom endpoints


@dataclass
class TelegramConfig:
    token: str = ""
    allowed_user_ids: list = field(default_factory=list)
    require_approval: bool = True    # Ask before dangerous actions
    max_file_size_mb: int = 50
    notification_on_complete: bool = True
    send_screenshots: bool = True


@dataclass
class SecurityConfig:
    safe_mode: bool = True
    sandbox_shell: bool = True       # Run shell commands in sandbox
    blocked_commands: list = field(default_factory=lambda: [
        "format", "mkfs", "dd if=", ":(){ :|:& };:",
        "rm -rf /", "del /s /q c:", "shutdown /s /f"
    ])
    blocked_domains: list = field(default_factory=lambda: [
        "malware", "phishing"
    ])
    max_file_delete_mb: int = 100    # Don't delete files larger than this without approval
    require_approval_for: list = field(default_factory=lambda: [
        "delete", "format", "shutdown", "registry", "system32"
    ])
    audit_log: bool = True


@dataclass
class DaemonConfig:
    enabled: bool = True
    auto_start: bool = True          # Start on system boot
    watchdog_interval: int = 30      # Seconds between health checks
    restart_on_crash: bool = True
    max_restarts: int = 10
    heartbeat_interval: int = 300    # Send Telegram heartbeat every N seconds


@dataclass
class AgentConfig:
    verbose: bool = False
    memory_enabled: bool = True
    memory_max_entries: int = 1000
    task_timeout: int = 300          # Max seconds per task
    max_iterations: int = 25         # Max LLM reasoning steps
    parallel_tasks: bool = False     # Allow concurrent tasks
    auto_install_deps: bool = True   # Auto pip install missing packages


@dataclass
class Config:
    llm: LLMConfig = field(default_factory=LLMConfig)
    telegram: TelegramConfig = field(default_factory=TelegramConfig)
    security: SecurityConfig = field(default_factory=SecurityConfig)
    daemon: DaemonConfig = field(default_factory=DaemonConfig)
    agent: AgentConfig = field(default_factory=AgentConfig)
    version: str = "2.0.0"

    def save(self):
        """Save config to disk. API keys saved to keyring separately."""
        data = asdict(self)
        # Remove secrets before writing to disk
        _scrub_secrets(data)
        with open(CONFIG_FILE, "w") as f:
            json.dump(data, f, indent=2)
        # Save secrets to keyring
        _save_secrets(self)
        logger.debug(f"Config saved to {CONFIG_FILE}")

    @classmethod
    def load(cls) -> "Config":
        """Load config from disk, merge keyring secrets."""
        if not CONFIG_FILE.exists():
            return cls()
        try:
            with open(CONFIG_FILE) as f:
                data = json.load(f)
            cfg = _dict_to_config(data)
            _load_secrets(cfg)
            return cfg
        except Exception as e:
            logger.warning(f"Config load error: {e}. Using defaults.")
            return cls()

    @classmethod
    def exists(cls) -> bool:
        return CONFIG_FILE.exists()

    def is_configured(self) -> bool:
        """Returns True if minimum config is present."""
        return bool(self.llm.backend)

    def has_telegram(self) -> bool:
        return bool(self.telegram.token)

    def has_llm_key(self) -> bool:
        if self.llm.backend == "ollama":
            return True
        return bool(self.llm.api_key)


def _scrub_secrets(data: dict):
    """Remove secrets from dict before saving to disk."""
    if "llm" in data:
        data["llm"]["api_key"] = ""
    if "telegram" in data:
        data["telegram"]["token"] = ""


def _save_secrets(cfg: Config):
    """Save API keys to system keyring (more secure than disk)."""
    try:
        import keyring
        if cfg.llm.api_key:
            keyring.set_password("doitagent", "llm_api_key", cfg.llm.api_key)
        if cfg.telegram.token:
            keyring.set_password("doitagent", "telegram_token", cfg.telegram.token)
    except Exception:
        # Fallback: store in separate secrets file with restricted permissions
        _save_secrets_file(cfg)


def _load_secrets(cfg: Config):
    """Load API keys from system keyring."""
    try:
        import keyring
        key = keyring.get_password("doitagent", "llm_api_key")
        if key:
            cfg.llm.api_key = key
        token = keyring.get_password("doitagent", "telegram_token")
        if token:
            cfg.telegram.token = token
    except Exception:
        _load_secrets_file(cfg)


def _secrets_file() -> Path:
    return CONFIG_DIR / ".secrets"


def _save_secrets_file(cfg: Config):
    secrets = {
        "llm_api_key": cfg.llm.api_key,
        "telegram_token": cfg.telegram.token,
    }
    p = _secrets_file()
    with open(p, "w") as f:
        json.dump(secrets, f)
    # Restrict file permissions on Unix
    try:
        os.chmod(p, 0o600)
    except Exception:
        pass


def _load_secrets_file(cfg: Config):
    p = _secrets_file()
    if not p.exists():
        return
    try:
        with open(p) as f:
            secrets = json.load(f)
        cfg.llm.api_key = secrets.get("llm_api_key", "")
        cfg.telegram.token = secrets.get("telegram_token", "")
    except Exception:
        pass


def _dict_to_config(data: dict) -> Config:
    """Reconstruct Config from a dict, handling missing keys gracefully."""
    cfg = Config()
    if "llm" in data:
        d = data["llm"]
        cfg.llm = LLMConfig(
            backend=d.get("backend", "ollama"),
            model=d.get("model", "mistral"),
            api_key=d.get("api_key", ""),
            temperature=d.get("temperature", 0.7),
            max_tokens=d.get("max_tokens", 4096),
            timeout=d.get("timeout", 120),
            base_url=d.get("base_url", ""),
        )
    if "telegram" in data:
        d = data["telegram"]
        cfg.telegram = TelegramConfig(
            token=d.get("token", ""),
            allowed_user_ids=d.get("allowed_user_ids", []),
            require_approval=d.get("require_approval", True),
            max_file_size_mb=d.get("max_file_size_mb", 50),
            notification_on_complete=d.get("notification_on_complete", True),
            send_screenshots=d.get("send_screenshots", True),
        )
    if "security" in data:
        d = data["security"]
        cfg.security = SecurityConfig(
            safe_mode=d.get("safe_mode", True),
            sandbox_shell=d.get("sandbox_shell", True),
            blocked_commands=d.get("blocked_commands", cfg.security.blocked_commands),
            max_file_delete_mb=d.get("max_file_delete_mb", 100),
            require_approval_for=d.get("require_approval_for", cfg.security.require_approval_for),
            audit_log=d.get("audit_log", True),
        )
    if "daemon" in data:
        d = data["daemon"]
        cfg.daemon = DaemonConfig(
            enabled=d.get("enabled", True),
            auto_start=d.get("auto_start", True),
            watchdog_interval=d.get("watchdog_interval", 30),
            restart_on_crash=d.get("restart_on_crash", True),
            max_restarts=d.get("max_restarts", 10),
            heartbeat_interval=d.get("heartbeat_interval", 300),
        )
    if "agent" in data:
        d = data["agent"]
        cfg.agent = AgentConfig(
            verbose=d.get("verbose", False),
            memory_enabled=d.get("memory_enabled", True),
            memory_max_entries=d.get("memory_max_entries", 1000),
            task_timeout=d.get("task_timeout", 300),
            max_iterations=d.get("max_iterations", 25),
            auto_install_deps=d.get("auto_install_deps", True),
        )
    return cfg


# Convenience function
def load() -> Config:
    return Config.load()


def save(cfg: Config):
    cfg.save()
