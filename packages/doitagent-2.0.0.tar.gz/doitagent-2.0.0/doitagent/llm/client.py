"""
Unified LLM client supporting all backends.
Ollama · NVIDIA NIM · Anthropic · OpenAI · DeepSeek
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Iterator, Optional

from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from doitagent.config import LLMConfig
from doitagent.exceptions import LLMError

logger = logging.getLogger("doitagent.llm")

NVIDIA_BASE_URL = "https://integrate.api.nvidia.com/v1"
DEEPSEEK_BASE_URL = "https://api.deepseek.com"

NVIDIA_MODELS: dict[str, str] = {
    "llama-3.1-405b": "meta/llama-3.1-405b-instruct",
    "llama-3.1-70b":  "meta/llama-3.1-70b-instruct",
    "llama-3.1-8b":   "meta/llama-3.1-8b-instruct",
    "mistral-large":  "mistralai/mistral-large-2-instruct",
    "mistral-nemo":   "mistralai/mistral-nemo-12b-instruct",
    "phi-3-medium":   "microsoft/phi-3-medium-128k-instruct",
    "gemma-2-27b":    "google/gemma-2-27b-it",
    "qwen-72b":       "qwen/qwen2-72b-instruct",
    "deepseek-r1":    "deepseek-ai/deepseek-r1",
    "nemotron-70b":   "nvidia/llama-3.1-nemotron-70b-instruct",
    "nemotron-super": "nvidia/llama-3.3-nemotron-super-49b-v1",
}

AGENT_SYSTEM_PROMPT = """You are DoItAgent, an ultra-powerful, fully autonomous Windows PC agent.
You control the user's computer on their behalf through a rich set of tools.

TOOLS AVAILABLE:
{tool_descriptions}

EXECUTION RULES:
1. Think step-by-step. Break complex tasks into atomic tool calls.
2. To call a tool, respond ONLY with a JSON block (no extra text):
   ```json
   {{"tool": "module.function", "args": {{"param1": "value1"}}}}
   ```
3. After receiving a tool result, decide: done? or call next tool?
4. When fully done, respond with plain text summary starting with "DONE:"
5. Never give up without trying at least 3 different approaches.
6. For file paths, always use absolute paths or ~/Desktop etc.
7. Be concise in final summaries — users want results, not essays.
8. If a task requires multiple sequential steps, do ALL of them.

SAFETY:
- Never perform destructive actions without explicit confirmation in the request.
- Always prefer reversible actions (e.g. Recycle Bin over permanent delete).
"""


class LLMClient:
    """
    Unified LLM client. Same interface for all backends.
    Auto-loads config from ~/.doitagent/config.json

    Usage:
        client = LLMClient.from_config()
        response = client.complete("What is 2 + 2?")
        response = client.chat([{"role": "user", "content": "Hello"}])
    """

    def __init__(self, config: LLMConfig):
        self.config = config
        self._client = None
        self._init()

    @classmethod
    def from_config(cls) -> "LLMClient":
        from doitagent.config import Config
        return cls(Config.load().llm)

    def _init(self):
        b = self.config.backend.lower()
        try:
            if b == "ollama":
                import ollama  # noqa
                self._client = ("ollama", None)

            elif b == "nvidia":
                from openai import OpenAI
                c = OpenAI(
                    base_url=NVIDIA_BASE_URL,
                    api_key=self.config.api_key,
                )
                model = NVIDIA_MODELS.get(self.config.model, self.config.model)
                self.config.model = model
                self._client = ("openai_compat", c)

            elif b == "anthropic":
                import anthropic
                self._client = ("anthropic", anthropic.Anthropic(api_key=self.config.api_key))

            elif b in ("openai", "deepseek"):
                from openai import OpenAI
                url = DEEPSEEK_BASE_URL if b == "deepseek" else (self.config.base_url or None)
                c = OpenAI(api_key=self.config.api_key, base_url=url)
                self._client = ("openai_compat", c)

            else:
                raise LLMError(f"Unknown backend: {b}", backend=b)

            logger.debug(f"LLM ready: {self.config.backend}/{self.config.model}")

        except ImportError as e:
            raise LLMError(
                f"Backend '{b}' not installed: {e}. Run: pip install doitagent[{b}]",
                backend=b
            )

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type(Exception),
        reraise=True,
    )
    def chat(
        self,
        messages: list[dict],
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> str:
        """Send chat messages and get a text response."""
        if not self._client:
            raise LLMError("Client not initialized", backend=self.config.backend)

        kind, client = self._client
        temp = temperature if temperature is not None else self.config.temperature
        tokens = max_tokens or self.config.max_tokens

        try:
            if kind == "ollama":
                import ollama
                msgs = []
                if system:
                    msgs.append({"role": "system", "content": system})
                msgs.extend(messages)
                resp = ollama.chat(
                    model=self.config.model,
                    messages=msgs,
                    options={"temperature": temp, "num_predict": tokens},
                )
                return resp["message"]["content"]

            elif kind == "anthropic":
                resp = client.messages.create(
                    model=self.config.model,
                    max_tokens=tokens,
                    system=system or "",
                    messages=messages,
                    temperature=temp,
                )
                return resp.content[0].text

            elif kind == "openai_compat":
                full_msgs = []
                if system:
                    full_msgs.append({"role": "system", "content": system})
                full_msgs.extend(messages)
                resp = client.chat.completions.create(
                    model=self.config.model,
                    messages=full_msgs,
                    temperature=temp,
                    max_tokens=tokens,
                )
                return resp.choices[0].message.content

        except Exception as e:
            raise LLMError(str(e), backend=self.config.backend)

        return ""

    def complete(self, prompt: str, system: Optional[str] = None) -> str:
        """Single-turn completion."""
        return self.chat([{"role": "user", "content": prompt}], system=system)

    def stream(
        self,
        messages: list[dict],
        system: Optional[str] = None,
    ) -> Iterator[str]:
        """Stream tokens as they arrive."""
        if not self._client:
            yield "LLM not initialized."
            return

        kind, client = self._client

        try:
            if kind == "ollama":
                import ollama
                msgs = []
                if system:
                    msgs.append({"role": "system", "content": system})
                msgs.extend(messages)
                for chunk in ollama.chat(model=self.config.model, messages=msgs, stream=True):
                    yield chunk["message"]["content"]

            elif kind == "openai_compat":
                full_msgs = []
                if system:
                    full_msgs.append({"role": "system", "content": system})
                full_msgs.extend(messages)
                stream = client.chat.completions.create(
                    model=self.config.model,
                    messages=full_msgs,
                    temperature=self.config.temperature,
                    max_tokens=self.config.max_tokens,
                    stream=True,
                )
                for chunk in stream:
                    delta = chunk.choices[0].delta.content
                    if delta:
                        yield delta

            elif kind == "anthropic":
                with client.messages.stream(
                    model=self.config.model,
                    max_tokens=self.config.max_tokens,
                    system=system or "",
                    messages=messages,
                ) as stream:
                    for text in stream.text_stream:
                        yield text

        except Exception as e:
            yield f"\n[LLM Error: {e}]"

    def extract_tool_call(self, response: str) -> Optional[dict]:
        """Parse a tool call JSON block from a model response."""
        patterns = [
            r'```json\s*(\{.*?\})\s*```',
            r'```\s*(\{"tool".*?\})\s*```',
            r'(\{"tool"\s*:.*?"args"\s*:.*?\})',
        ]
        for pattern in patterns:
            m = re.search(pattern, response, re.DOTALL)
            if m:
                try:
                    return json.loads(m.group(1))
                except json.JSONDecodeError:
                    pass
        return None

    @property
    def backend(self) -> str:
        return self.config.backend

    @property
    def model(self) -> str:
        return self.config.model

    def __repr__(self) -> str:
        return f"LLMClient(backend={self.backend!r}, model={self.model!r})"
