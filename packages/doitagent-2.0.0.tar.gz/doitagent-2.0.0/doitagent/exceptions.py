"""Custom exceptions for DoItAgent."""


class DoItAgentError(Exception):
    """Base exception for all DoItAgent errors."""
    def __init__(self, message: str = "", code: str = "UNKNOWN"):
        super().__init__(message)
        self.code = code
        self.message = message

    def __str__(self):
        return f"[{self.code}] {self.message}"


class ConfigError(DoItAgentError):
    """Raised when configuration is missing or invalid."""
    def __init__(self, message: str = "Configuration error"):
        super().__init__(message, code="CONFIG_ERROR")


class LLMError(DoItAgentError):
    """Raised when LLM backend fails."""
    def __init__(self, message: str = "LLM error", backend: str = "unknown"):
        super().__init__(message, code="LLM_ERROR")
        self.backend = backend


class ModuleError(DoItAgentError):
    """Raised when a module operation fails."""
    def __init__(self, message: str = "Module error", module: str = "unknown"):
        super().__init__(message, code="MODULE_ERROR")
        self.module = module


class SecurityError(DoItAgentError):
    """Raised when a security check fails or dangerous action is blocked."""
    def __init__(self, message: str = "Security check failed", action: str = ""):
        super().__init__(message, code="SECURITY_ERROR")
        self.action = action


class TelegramError(DoItAgentError):
    """Raised when Telegram bot encounters an error."""
    def __init__(self, message: str = "Telegram error"):
        super().__init__(message, code="TELEGRAM_ERROR")


class SandboxError(DoItAgentError):
    """Raised when sandboxed execution fails."""
    def __init__(self, message: str = "Sandbox error"):
        super().__init__(message, code="SANDBOX_ERROR")


class DaemonError(DoItAgentError):
    """Raised when the daemon/watchdog encounters an error."""
    def __init__(self, message: str = "Daemon error"):
        super().__init__(message, code="DAEMON_ERROR")


class ToolNotFoundError(DoItAgentError):
    """Raised when the agent requests an unknown tool."""
    def __init__(self, tool_name: str):
        super().__init__(f"Tool not found: {tool_name}", code="TOOL_NOT_FOUND")
        self.tool_name = tool_name


class TaskTimeoutError(DoItAgentError):
    """Raised when a task exceeds its time limit."""
    def __init__(self, task: str, timeout: int):
        super().__init__(f"Task timed out after {timeout}s: {task}", code="TASK_TIMEOUT")
        self.timeout = timeout
