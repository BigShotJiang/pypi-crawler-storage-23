"""Auto-install missing optional dependencies at runtime."""

from __future__ import annotations
import sys
import subprocess
import importlib
import logging
from typing import Optional

logger = logging.getLogger("doitagent.installer")

PACKAGE_MAP = {
    # import_name -> pip_package
    "pytesseract": "pytesseract",
    "cv2": "opencv-python",
    "mss": "mss",
    "playwright": "playwright",
    "docx": "python-docx",
    "openpyxl": "openpyxl",
    "reportlab": "reportlab",
    "pdfplumber": "pdfplumber",
    "PyPDF2": "PyPDF2",
    "duckduckgo_search": "duckduckgo-search",
    "bs4": "beautifulsoup4",
    "lxml": "lxml",
    "pyttsx3": "pyttsx3",
    "pygame": "pygame",
    "vlc": "python-vlc",
    "whisper": "openai-whisper",
    "sounddevice": "sounddevice",
    "scipy": "scipy",
    "speech_recognition": "SpeechRecognition",
    "pyautogui": "pyautogui",
    "pyperclip": "pyperclip",
    "psutil": "psutil",
    "send2trash": "send2trash",
    "apscheduler": "apscheduler",
    "plyer": "plyer",
    "pywinauto": "pywinauto",
    "win32api": "pywin32",
    "pycaw": "pycaw",
    "ollama": "ollama",
    "openai": "openai",
    "anthropic": "anthropic",
    "keyring": "keyring",
    "rich": "rich",
    "aiofiles": "aiofiles",
    "tenacity": "tenacity",
}


def ensure(import_name: str, pip_name: Optional[str] = None, auto: bool = True) -> bool:
    """
    Ensure a package is importable. Auto-installs if missing and auto=True.

    Args:
        import_name: Python import name (e.g. "cv2")
        pip_name:    PyPI package name if different (e.g. "opencv-python")
        auto:        Auto-install without prompting.

    Returns:
        True if package is available after this call.
    """
    try:
        importlib.import_module(import_name)
        return True
    except ImportError:
        pkg = pip_name or PACKAGE_MAP.get(import_name, import_name)
        if not auto:
            logger.warning(f"Missing package: {pkg}. Install with: pip install {pkg}")
            return False

        logger.info(f"Auto-installing {pkg}...")
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", pkg, "-q",
                 "--disable-pip-version-check"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            importlib.invalidate_caches()
            importlib.import_module(import_name)
            logger.info(f"✓ Installed {pkg}")
            return True
        except Exception as e:
            logger.warning(f"Could not auto-install {pkg}: {e}")
            return False


def ensure_playwright():
    """Install Playwright + Chromium browser."""
    if not ensure("playwright", auto=True):
        return False
    try:
        subprocess.check_call(
            [sys.executable, "-m", "playwright", "install", "chromium", "--quiet"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        return True
    except Exception:
        return False


def check_optional(packages: list[str]) -> dict[str, bool]:
    """Check availability of multiple packages. Returns {name: available}."""
    result = {}
    for pkg in packages:
        try:
            importlib.import_module(pkg)
            result[pkg] = True
        except ImportError:
            result[pkg] = False
    return result
