"""Centralized logging with Rich for beautiful terminal output."""

from __future__ import annotations
import logging
import sys
from pathlib import Path
from typing import Optional

_setup_done = False


def setup_logging(verbose: bool = False, log_file: Optional[Path] = None):
    global _setup_done
    if _setup_done:
        return
    _setup_done = True

    level = logging.DEBUG if verbose else logging.INFO

    # Try Rich handler first (beautiful colored output)
    try:
        from rich.logging import RichHandler
        from rich.console import Console

        console = Console(stderr=True)
        handlers = [RichHandler(
            console=console,
            show_path=False,
            markup=True,
            rich_tracebacks=True,
            tracebacks_show_locals=verbose,
        )]
    except ImportError:
        # Fallback plain handler
        handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(logging.Formatter(
            "[%(asctime)s] [%(name)s] %(levelname)s: %(message)s",
            datefmt="%H:%M:%S"
        ))
        handlers = [handler]

    # File handler
    if log_file:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setFormatter(logging.Formatter(
            "%(asctime)s | %(name)s | %(levelname)s | %(message)s"
        ))
        file_handler.setLevel(logging.DEBUG)
        handlers.append(file_handler)

    logging.basicConfig(
        level=level,
        handlers=handlers,
        force=True,
    )

    # Silence noisy third-party loggers
    for noisy in ("httpx", "httpcore", "telegram", "urllib3", "PIL", "asyncio"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"doitagent.{name}")
