"""
AgentExecutor — The autonomous reasoning + tool execution loop.
Supports multi-step tasks, retries, tool result feedback, and streaming.
"""

from __future__ import annotations

import inspect
import json
import logging
import time
from typing import Any, Callable, Optional

from doitagent.llm.client import LLMClient, AGENT_SYSTEM_PROMPT
from doitagent.agent.memory import Memory
from doitagent.config import AgentConfig
from doitagent.exceptions import TaskTimeoutError, ToolNotFoundError, LLMError

logger = logging.getLogger("doitagent.executor")


class AgentExecutor:
    """
    Autonomous task executor.

    Runs the observe → reason → act → observe loop until the task
    is complete or max_iterations is reached.
    """

    def __init__(
        self,
        llm: LLMClient,
        tools: dict[str, Callable],
        memory: Memory,
        config: AgentConfig,
        on_step: Optional[Callable[[str, str, Any], None]] = None,
    ):
        self.llm = llm
        self.tools = tools
        self.memory = memory
        self.config = config
        self.on_step = on_step  # callback(tool_name, args_str, result)

    def run(
        self,
        task: str,
        confirm_callback: Optional[Callable[[str], bool]] = None,
    ) -> str:
        """
        Execute a task. Returns the final result string.

        Args:
            task:             Natural language task description.
            confirm_callback: Called with plan before executing (returns True to proceed).
        """
        start_time = time.time()

        # Expand known skills
        task = self.memory.expand_skill(task)

        # Build system prompt with tool descriptions
        tools_desc = self._build_tools_description()
        system = AGENT_SYSTEM_PROMPT.format(tool_descriptions=tools_desc)

        # Inject memory context
        ctx = self.memory.get_context_summary()
        if ctx:
            system += f"\n\n{ctx}"

        messages = [{"role": "user", "content": task}]
        final_result = f"Task completed: {task}"
        last_tool_result = None

        for iteration in range(self.config.max_iterations):
            # Timeout check
            elapsed = time.time() - start_time
            if elapsed > self.config.task_timeout:
                raise TaskTimeoutError(task, self.config.task_timeout)

            # Call LLM
            try:
                response = self.llm.chat(messages, system=system)
            except LLMError as e:
                logger.error(f"LLM error on iteration {iteration}: {e}")
                # Try fallback direct tool match
                response = self._keyword_fallback(task)
                if not response:
                    return f"LLM error: {e}"

            # Check if LLM is done
            stripped = response.strip()
            if stripped.upper().startswith("DONE:") or (
                iteration > 0 and not self.llm.extract_tool_call(response)
            ):
                final_result = stripped.replace("DONE:", "").strip() or stripped
                break

            # Try to extract a tool call
            tool_call = self.llm.extract_tool_call(response)

            if not tool_call:
                # Plain text response with no tool call = final answer
                final_result = stripped
                break

            tool_name = tool_call.get("tool", "")
            tool_args = tool_call.get("args", {})

            if self.config.verbose:
                logger.info(f"  [{iteration+1}] {tool_name}({_fmt_args(tool_args)})")

            # Confirm step if callback given (first step only)
            if confirm_callback and iteration == 0:
                if not confirm_callback(f"Execute: {tool_name}({_fmt_args(tool_args)})"):
                    return "Task cancelled by user."

            # Execute the tool
            tool_result = self._execute_tool(tool_name, tool_args)
            last_tool_result = tool_result

            if self.on_step:
                self.on_step(tool_name, _fmt_args(tool_args), tool_result)

            # Feed result back to LLM
            messages.append({"role": "assistant", "content": response})
            messages.append({
                "role": "user",
                "content": f"Tool result for {tool_name}: {str(tool_result)[:2000]}"
            })

            # If the tool produced a file path, that might be the answer
            if isinstance(tool_result, str) and _looks_like_path(tool_result):
                final_result = tool_result

        # Save to memory
        result_str = str(final_result)
        self.memory.add(task, result_str)

        return result_str

    def _execute_tool(self, tool_name: str, args: dict) -> Any:
        """Execute a named tool with argument validation."""
        if tool_name not in self.tools:
            # Try partial match
            matches = [k for k in self.tools if tool_name.split(".")[-1] in k]
            if matches:
                tool_name = matches[0]
            else:
                raise ToolNotFoundError(tool_name)

        fn = self.tools[tool_name]
        try:
            sig = inspect.signature(fn)
            valid_args = {}
            for k, v in args.items():
                if k in sig.parameters:
                    # Type coercion
                    param = sig.parameters[k]
                    ann = param.annotation
                    try:
                        if ann is int:
                            v = int(v)
                        elif ann is float:
                            v = float(v)
                        elif ann is bool:
                            v = str(v).lower() in ("true", "1", "yes")
                    except Exception:
                        pass
                    valid_args[k] = v
            return fn(**valid_args)
        except Exception as e:
            logger.error(f"Tool {tool_name} error: {e}")
            return f"Error in {tool_name}: {e}"

    def _build_tools_description(self) -> str:
        """Build a compact tool catalog for the LLM."""
        lines = []
        current_module = ""
        for name in sorted(self.tools.keys()):
            module = name.split(".")[0] if "." in name else ""
            if module != current_module:
                lines.append(f"\n[{module.upper()}]")
                current_module = module
            fn = self.tools[name]
            doc = (fn.__doc__ or "").strip().split("\n")[0][:80]
            try:
                sig = inspect.signature(fn)
                params = [
                    f"{p}={v.default!r}" if v.default is not inspect.Parameter.empty else p
                    for p, v in list(sig.parameters.items())[:4]
                    if p != "self"
                ]
                sig_str = f"({', '.join(params)})"
            except Exception:
                sig_str = "(...)"
            lines.append(f"  {name}{sig_str} — {doc}")
        return "\n".join(lines[:120])  # Cap to avoid context overflow

    def _keyword_fallback(self, task: str) -> str:
        """When LLM is unavailable, map keywords to tool calls."""
        task_lower = task.lower()
        mapping = {
            "screenshot": '{"tool": "screen.screenshot", "args": {}}',
            "search": '{"tool": "search.web_search", "args": {"query": "' + task[:50] + '"}}',
            "list files": '{"tool": "files.list_folder", "args": {"path": "~/Desktop"}}',
            "run:": '{"tool": "shell.run", "args": {"command": "' + task.split("run:")[-1].strip() + '"}}',
        }
        for kw, call in mapping.items():
            if kw in task_lower:
                return call
        return ""


def _fmt_args(args: dict) -> str:
    parts = []
    for k, v in args.items():
        v_str = str(v)[:40]
        parts.append(f"{k}={v_str!r}")
    return ", ".join(parts[:3])


def _looks_like_path(s: str) -> bool:
    import os
    s = s.strip()
    if len(s) > 300:
        return False
    return os.path.exists(s) or s.startswith("~/") or (len(s) > 3 and s[1] == ":")
