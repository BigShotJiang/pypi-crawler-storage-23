"""
Persistent memory for DoItAgent.
Stores task history, learned patterns, and user preferences.
Uses a simple JSON-lines store (no external vector DB required).
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from doitagent.config import MEMORY_DIR

logger = logging.getLogger("doitagent.memory")

HISTORY_FILE = MEMORY_DIR / "history.jsonl"
SKILLS_FILE  = MEMORY_DIR / "skills.json"
PREFS_FILE   = MEMORY_DIR / "preferences.json"


class Memory:
    """
    Simple, fast, persistent memory for the agent.

    Stores:
    - Task history (what was asked, what was done)
    - Learned skills (reusable workflows)
    - User preferences (name, common paths, preferences)
    """

    def __init__(self, max_entries: int = 1000):
        self.max_entries = max_entries
        self._history: list[dict] = []
        self._skills: dict[str, dict] = {}
        self._prefs: dict = {}
        self._load()

    # ─── History ──────────────────────────────────────────────────────────────

    def add(self, task: str, result: str, metadata: Optional[dict] = None):
        """Record a task execution."""
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "task": task[:500],
            "result": result[:300],
            **(metadata or {}),
        }
        self._history.append(entry)
        if len(self._history) > self.max_entries:
            self._history = self._history[-self.max_entries:]
        self._save_history()

    def recent(self, n: int = 20) -> list[dict]:
        """Return the N most recent task entries."""
        return self._history[-n:]

    def search(self, query: str, limit: int = 10) -> list[dict]:
        """Simple keyword search over task history."""
        q = query.lower()
        matches = [e for e in reversed(self._history) if q in e.get("task", "").lower()]
        return matches[:limit]

    def clear_history(self):
        self._history = []
        HISTORY_FILE.write_text("", encoding="utf-8")

    # ─── Skills ───────────────────────────────────────────────────────────────

    def save_skill(self, name: str, description: str, steps: list[str]):
        """Save a reusable multi-step skill."""
        self._skills[name.lower()] = {
            "name": name,
            "description": description,
            "steps": steps,
            "created": datetime.utcnow().isoformat(),
            "run_count": 0,
        }
        self._save_skills()
        logger.info(f"Skill saved: {name}")

    def get_skill(self, name: str) -> Optional[dict]:
        return self._skills.get(name.lower())

    def list_skills(self) -> list[dict]:
        return list(self._skills.values())

    def delete_skill(self, name: str) -> bool:
        if name.lower() in self._skills:
            del self._skills[name.lower()]
            self._save_skills()
            return True
        return False

    def expand_skill(self, task: str) -> str:
        """If task references a skill, expand it to its steps."""
        task_lower = task.lower()
        for name, skill in self._skills.items():
            if name in task_lower or f"run {name}" in task_lower:
                steps = "\n".join(f"{i+1}. {s}" for i, s in enumerate(skill["steps"]))
                skill["run_count"] = skill.get("run_count", 0) + 1
                self._save_skills()
                return (
                    f"Execute the '{skill['name']}' skill step by step:\n{steps}\n"
                    f"Complete ALL steps in order."
                )
        return task

    # ─── Preferences ──────────────────────────────────────────────────────────

    def set_pref(self, key: str, value):
        self._prefs[key] = value
        self._save_prefs()

    def get_pref(self, key: str, default=None):
        return self._prefs.get(key, default)

    def get_context_summary(self) -> str:
        """Return a short context string to inject into LLM prompts."""
        recent = self.recent(5)
        if not recent:
            return ""
        lines = ["Recent tasks (for context):"]
        for e in recent:
            lines.append(f"  - {e['task'][:80]}")
        return "\n".join(lines)

    # ─── Persistence ──────────────────────────────────────────────────────────

    def _load(self):
        # History
        if HISTORY_FILE.exists():
            for line in HISTORY_FILE.read_text(encoding="utf-8").splitlines():
                try:
                    self._history.append(json.loads(line))
                except Exception:
                    pass
            self._history = self._history[-self.max_entries:]

        # Skills
        if SKILLS_FILE.exists():
            try:
                self._skills = json.loads(SKILLS_FILE.read_text(encoding="utf-8"))
            except Exception:
                self._skills = {}

        # Prefs
        if PREFS_FILE.exists():
            try:
                self._prefs = json.loads(PREFS_FILE.read_text(encoding="utf-8"))
            except Exception:
                self._prefs = {}

    def _save_history(self):
        with open(HISTORY_FILE, "a", encoding="utf-8") as f:
            if self._history:
                f.write(json.dumps(self._history[-1]) + "\n")

    def _save_skills(self):
        SKILLS_FILE.write_text(
            json.dumps(self._skills, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    def _save_prefs(self):
        PREFS_FILE.write_text(
            json.dumps(self._prefs, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    def stats(self) -> dict:
        return {
            "total_tasks": len(self._history),
            "skills": len(self._skills),
            "oldest_task": self._history[0]["timestamp"][:10] if self._history else "none",
        }
