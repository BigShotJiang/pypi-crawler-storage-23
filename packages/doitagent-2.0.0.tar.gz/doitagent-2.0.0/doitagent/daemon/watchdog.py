"""
DoItAgent Daemon & Watchdog
============================
Keeps the agent running 24/7.
- Auto-restarts on crash
- Health monitoring
- Periodic Telegram heartbeat
- Windows auto-start on boot
- Cross-platform (Windows service / Linux systemd / macOS launchd)
"""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import subprocess
import sys
import time
import json
import signal
from datetime import datetime
from pathlib import Path
from typing import Optional

from doitagent.config import Config, DaemonConfig, CONFIG_DIR, LOG_DIR
from doitagent.exceptions import DaemonError

logger = logging.getLogger("doitagent.daemon")

PID_FILE   = CONFIG_DIR / "daemon.pid"
STATE_FILE = CONFIG_DIR / "daemon_state.json"


# ─── Process management ───────────────────────────────────────────────────────

def write_pid():
    PID_FILE.write_text(str(os.getpid()))


def read_pid() -> Optional[int]:
    if PID_FILE.exists():
        try:
            return int(PID_FILE.read_text().strip())
        except Exception:
            pass
    return None


def is_running() -> bool:
    pid = read_pid()
    if not pid:
        return False
    try:
        import psutil
        return psutil.pid_exists(pid) and any(
            "doitagent" in " ".join(p.cmdline()).lower()
            for p in [psutil.Process(pid)]
        )
    except Exception:
        return False


def stop_daemon():
    pid = read_pid()
    if not pid:
        return False
    try:
        import psutil
        proc = psutil.Process(pid)
        proc.terminate()
        proc.wait(timeout=10)
        PID_FILE.unlink(missing_ok=True)
        return True
    except Exception as e:
        logger.error(f"Could not stop daemon: {e}")
        return False


# ─── State ────────────────────────────────────────────────────────────────────

def _save_state(state: dict):
    STATE_FILE.write_text(json.dumps(state, indent=2))


def _load_state() -> dict:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except Exception:
            pass
    return {"restarts": 0, "started_at": None, "last_alive": None}


# ─── Watchdog ─────────────────────────────────────────────────────────────────

class Watchdog:
    """
    Monitors the Telegram bot process and restarts it on crash.
    Sends periodic heartbeat messages to Telegram.
    """

    def __init__(self, config: DaemonConfig, telegram_token: str = "", user_ids: list = None):
        self.config = config
        self.telegram_token = telegram_token
        self.user_ids = user_ids or []
        self._proc: Optional[subprocess.Popen] = None
        self._restart_count = 0
        self._start_time = datetime.utcnow()
        self._running = True

    def start(self):
        """Start the watchdog loop. Blocks forever."""
        logger.info("Watchdog started")
        write_pid()
        _save_state({"restarts": 0, "started_at": datetime.utcnow().isoformat()})

        # Handle signals
        signal.signal(signal.SIGTERM, self._handle_signal)
        try:
            signal.signal(signal.SIGINT, self._handle_signal)
        except Exception:
            pass

        while self._running:
            try:
                self._start_bot()
                self._monitor()
            except Exception as e:
                logger.error(f"Watchdog error: {e}")

            if not self._running:
                break

            if self._restart_count >= self.config.max_restarts:
                logger.critical(f"Max restarts ({self.config.max_restarts}) reached. Stopping.")
                self._notify(f"⚠️ DoItAgent stopped after {self._restart_count} crashes.")
                break

            logger.info(f"Restarting bot in 5s (restart #{self._restart_count + 1})")
            time.sleep(5)

    def _start_bot(self):
        """Spawn the Telegram bot as a subprocess."""
        cmd = [sys.executable, "-m", "doitagent.telegram.bot"]
        log_file = LOG_DIR / "bot.log"

        with open(log_file, "a") as lf:
            self._proc = subprocess.Popen(
                cmd,
                stdout=lf,
                stderr=lf,
                env=os.environ.copy(),
            )
        logger.info(f"Bot started (PID {self._proc.pid})")
        self._notify(
            f"✅ DoItAgent online\n"
            f"🔁 Restart #{self._restart_count}\n"
            f"🕐 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        )

    def _monitor(self):
        """Monitor the subprocess. Block until it dies."""
        last_heartbeat = time.time()

        while self._running:
            time.sleep(self.config.watchdog_interval)

            # Check if process is alive
            if self._proc and self._proc.poll() is not None:
                rc = self._proc.returncode
                logger.warning(f"Bot process died (rc={rc})")
                self._restart_count += 1
                _save_state({
                    "restarts": self._restart_count,
                    "last_crash": datetime.utcnow().isoformat(),
                    "last_return_code": rc,
                })
                if self.config.restart_on_crash:
                    self._notify(f"⚠️ Bot crashed (code {rc}). Restarting...")
                return

            # Heartbeat
            now = time.time()
            if self.config.heartbeat_interval > 0 and (now - last_heartbeat) >= self.config.heartbeat_interval:
                uptime = _human_duration(int(now - self._start_time.timestamp()))
                self._notify(f"💓 DoItAgent alive | Uptime: {uptime}", silent=True)
                last_heartbeat = now

    def _notify(self, message: str, silent: bool = False):
        """Send a Telegram notification."""
        if not self.telegram_token or not self.user_ids:
            return
        try:
            import requests
            for uid in self.user_ids:
                requests.post(
                    f"https://api.telegram.org/bot{self.telegram_token}/sendMessage",
                    json={
                        "chat_id": uid,
                        "text": message,
                        "disable_notification": silent,
                    },
                    timeout=10,
                )
        except Exception:
            pass

    def _handle_signal(self, signum, frame):
        logger.info(f"Signal {signum} received. Stopping watchdog.")
        self._running = False
        if self._proc:
            self._proc.terminate()
        PID_FILE.unlink(missing_ok=True)


# ─── Auto-start setup ─────────────────────────────────────────────────────────

def setup_autostart(enable: bool = True) -> str:
    """Configure DoItAgent to start automatically on system boot."""
    system = platform.system()

    if system == "Windows":
        return _setup_windows_autostart(enable)
    elif system == "Linux":
        return _setup_linux_autostart(enable)
    elif system == "Darwin":
        return _setup_macos_autostart(enable)
    else:
        return f"Auto-start not supported on {system}"


def _setup_windows_autostart(enable: bool) -> str:
    """Add/remove from Windows startup via Task Scheduler."""
    task_name = "DoItAgentDaemon"
    python_exe = sys.executable
    script = f'"{python_exe}" -m doitagent.daemon.watchdog'

    if enable:
        cmd = (
            f'schtasks /create /tn "{task_name}" /tr {script} '
            f'/sc ONLOGON /rl HIGHEST /f'
        )
    else:
        cmd = f'schtasks /delete /tn "{task_name}" /f'

    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode == 0:
        return f"Windows auto-start {'enabled' if enable else 'disabled'}"
    else:
        # Fallback: registry startup key
        try:
            import winreg
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0, winreg.KEY_SET_VALUE
            )
            if enable:
                winreg.SetValueEx(key, "DoItAgent", 0, winreg.REG_SZ, script)
            else:
                try:
                    winreg.DeleteValue(key, "DoItAgent")
                except FileNotFoundError:
                    pass
            winreg.CloseKey(key)
            return f"Registry auto-start {'enabled' if enable else 'disabled'}"
        except Exception as e:
            return f"Could not setup auto-start: {e}"


def _setup_linux_autostart(enable: bool) -> str:
    """Create a systemd user service."""
    service_dir = Path.home() / ".config" / "systemd" / "user"
    service_dir.mkdir(parents=True, exist_ok=True)
    service_file = service_dir / "doitagent.service"

    if enable:
        content = f"""[Unit]
Description=DoItAgent Personal AGI
After=network.target

[Service]
Type=simple
ExecStart={sys.executable} -m doitagent.daemon.watchdog
Restart=always
RestartSec=10
Environment=PATH={os.environ.get('PATH', '/usr/bin')}

[Install]
WantedBy=default.target
"""
        service_file.write_text(content)
        subprocess.run(["systemctl", "--user", "daemon-reload"])
        subprocess.run(["systemctl", "--user", "enable", "doitagent"])
        subprocess.run(["systemctl", "--user", "start", "doitagent"])
        return "Systemd service created and started"
    else:
        subprocess.run(["systemctl", "--user", "disable", "doitagent"])
        subprocess.run(["systemctl", "--user", "stop", "doitagent"])
        if service_file.exists():
            service_file.unlink()
        return "Systemd service removed"


def _setup_macos_autostart(enable: bool) -> str:
    """Create a macOS LaunchAgent plist."""
    plist_dir = Path.home() / "Library" / "LaunchAgents"
    plist_dir.mkdir(parents=True, exist_ok=True)
    plist_file = plist_dir / "dev.doitagent.plist"

    if enable:
        content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key><string>dev.doitagent</string>
    <key>ProgramArguments</key>
    <array>
        <string>{sys.executable}</string>
        <string>-m</string>
        <string>doitagent.daemon.watchdog</string>
    </array>
    <key>RunAtLoad</key><true/>
    <key>KeepAlive</key><true/>
    <key>StandardOutPath</key><string>{LOG_DIR}/daemon.log</string>
    <key>StandardErrorPath</key><string>{LOG_DIR}/daemon.log</string>
</dict>
</plist>"""
        plist_file.write_text(content)
        subprocess.run(["launchctl", "load", str(plist_file)])
        return "macOS LaunchAgent created and loaded"
    else:
        subprocess.run(["launchctl", "unload", str(plist_file)])
        if plist_file.exists():
            plist_file.unlink()
        return "macOS LaunchAgent removed"


def _human_duration(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        return f"{seconds // 60}m {seconds % 60}s"
    else:
        h = seconds // 3600
        m = (seconds % 3600) // 60
        return f"{h}h {m}m"


def main():
    """Entry point for running the watchdog directly."""
    from doitagent.config import Config
    cfg = Config.load()
    wd = Watchdog(
        config=cfg.daemon,
        telegram_token=cfg.telegram.token,
        user_ids=cfg.telegram.allowed_user_ids,
    )
    wd.start()


if __name__ == "__main__":
    main()
