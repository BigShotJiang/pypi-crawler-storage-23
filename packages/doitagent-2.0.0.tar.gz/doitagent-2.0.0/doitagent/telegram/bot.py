"""
DoItAgent Telegram Bot — Production Grade
==========================================
Full-featured bot: natural language, file upload/download,
approval workflow, streaming, inline keyboards, rate limiting.
"""

from __future__ import annotations

import asyncio
import io
import json
import logging
import os
import time
from datetime import datetime
from functools import wraps
from pathlib import Path
from typing import Optional

logger = logging.getLogger("doitagent.telegram")

# ─── Templates ────────────────────────────────────────────────────────────────

WELCOME = """
👋 *Hey {name}!* I'm your DoItAgent.

I control your PC remotely. Just tell me what to do in plain English.

*Try:*
• `take a screenshot`
• `list files on Desktop`
• `create a Word doc about AI trends`
• `search web for Python news`
• `play lofi music on youtube`
• `run: ipconfig`

Type /help to see everything I can do.
🧠 Brain: `{llm}/{model}`
"""

HELP = """
🤖 *DoItAgent — Full Command Reference*

*📸 Screen*
`take a screenshot` · `read text on screen` · `find [text] on screen`

*📁 Files & Folders*
`list [folder]` · `create file [name] with [content]`
`find all PDFs in Downloads` · `move [file] to [folder]`
`delete [file]` · `zip [folder]` · `read [file]`

*🌐 Browser*
`open [url]` · `search google for [query]`
`click [element]` · `fill form` · `scrape [url]`
`download file from [url]`

*📄 Documents*
`create Word doc about [topic]`
`make Excel with [data]`
`create PDF report` · `read PDF [file]`

*🎵 Media*
`play [song/url]` · `pause music` · `next track`
`set volume to [N]%` · `say [text] out loud`

*💻 System & Shell*
`run: [command]` · `show running processes`
`open [app]` · `kill [process]` · `system info`

*🔍 Search*
`search for [query]` · `get news about [topic]`
`scrape [website]`

*📧 Email*
`send email to [addr] subject [subject] body [body]`
`read my inbox` · `search emails for [keyword]`

*⚙️ Special Commands*
`/status` — System stats
`/screenshot` — Instant screenshot
`/history` — Last 20 commands
`/skills` — List learned skills
`/audit` — Security audit log
`/stop` — Stop agent
`/help` — This menu
"""


def _chunk(text: str, size: int = 4000) -> list[str]:
    """Split long text into Telegram-safe chunks."""
    return [text[i:i+size] for i in range(0, len(text), size)]


def authorized_only(fn):
    """Decorator: reject messages from unauthorized users."""
    @wraps(fn)
    async def wrapper(self, update, context, *args, **kwargs):
        uid = update.effective_user.id
        if self.allowed_ids and uid not in self.allowed_ids:
            logger.warning(f"Unauthorized: {uid}")
            await update.message.reply_text("⛔ Unauthorized.")
            return
        return await fn(self, update, context, *args, **kwargs)
    return wrapper


def rate_limited(calls_per_minute: int = 20):
    """Decorator: simple per-user rate limiting."""
    user_calls: dict[int, list] = {}
    def decorator(fn):
        @wraps(fn)
        async def wrapper(self, update, context, *args, **kwargs):
            uid = update.effective_user.id
            now = time.time()
            calls = [t for t in user_calls.get(uid, []) if now - t < 60]
            if len(calls) >= calls_per_minute:
                await update.message.reply_text("⏳ Slow down — rate limit reached.")
                return
            calls.append(now)
            user_calls[uid] = calls
            return await fn(self, update, context, *args, **kwargs)
        return wrapper
    return decorator


class DoItAgentBot:
    """Production-grade Telegram bot for DoItAgent."""

    def __init__(self):
        from doitagent.config import Config
        self.cfg = Config.load()
        self.token = self.cfg.telegram.token
        self.allowed_ids = set(self.cfg.telegram.allowed_user_ids)
        self._pending: dict[str, dict] = {}   # Pending approvals
        self._agent = None
        self._init_agent()

    def _init_agent(self):
        try:
            from doitagent.core import Agent
            self._agent = Agent(config=self.cfg, verbose=self.cfg.agent.verbose)
            logger.info(f"Agent ready: {self.cfg.llm.backend}/{self.cfg.llm.model}")
        except Exception as e:
            logger.error(f"Agent init failed: {e}")

    def _is_dangerous(self, text: str) -> bool:
        if not self.cfg.telegram.require_approval:
            return False
        danger = {"delete", "remove", "format", "shutdown", "restart",
                  "kill", "wipe", "drop", "uninstall", "rm ", "del "}
        t = text.lower()
        return any(w in t for w in danger)

    async def run(self):
        """Start the bot and block until stopped."""
        try:
            from telegram import Update
            from telegram.ext import (
                Application, CommandHandler, MessageHandler,
                CallbackQueryHandler, filters
            )
        except ImportError:
            raise ImportError(
                "python-telegram-bot not installed. Run: pip install doitagent"
            )

        if not self.token:
            raise ValueError("Telegram token not configured. Run: doit setup")

        app = Application.builder().token(self.token).build()

        # Commands
        app.add_handler(CommandHandler("start",      self.cmd_start))
        app.add_handler(CommandHandler("help",       self.cmd_help))
        app.add_handler(CommandHandler("status",     self.cmd_status))
        app.add_handler(CommandHandler("screenshot", self.cmd_screenshot))
        app.add_handler(CommandHandler("history",    self.cmd_history))
        app.add_handler(CommandHandler("skills",     self.cmd_skills))
        app.add_handler(CommandHandler("audit",      self.cmd_audit))
        app.add_handler(CommandHandler("stop",       self.cmd_stop))
        app.add_handler(CommandHandler("clear",      self.cmd_clear))

        # Callbacks (inline keyboard approvals)
        app.add_handler(CallbackQueryHandler(self.cb_approval))

        # File uploads
        app.add_handler(MessageHandler(filters.PHOTO,        self.handle_photo))
        app.add_handler(MessageHandler(filters.Document.ALL, self.handle_document))

        # Natural language messages
        app.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND, self.handle_message
        ))

        # Error handler
        app.add_error_handler(self._error_handler)

        logger.info("Telegram bot starting...")
        _print_startup_banner(self.cfg)

        await app.run_polling(drop_pending_updates=True, allowed_updates=Update.ALL_TYPES)

    # ─── Command handlers ─────────────────────────────────────────────────────

    @authorized_only
    async def cmd_start(self, update, context):
        name = update.effective_user.first_name or "there"
        text = WELCOME.format(
            name=name,
            llm=self.cfg.llm.backend,
            model=self.cfg.llm.model[:20],
        )
        await update.message.reply_text(text, parse_mode="Markdown")

    @authorized_only
    async def cmd_help(self, update, context):
        await update.message.reply_text(HELP, parse_mode="Markdown")

    @authorized_only
    async def cmd_status(self, update, context):
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=1)
            ram = psutil.virtual_memory()
            disk = psutil.disk_usage("/")
            uptime_s = int(time.time() - psutil.boot_time())
            h, rem = divmod(uptime_s, 3600)
            m = rem // 60

            from doitagent.daemon.watchdog import read_pid, STATE_FILE
            daemon_pid = read_pid()
            daemon_status = f"PID {daemon_pid}" if daemon_pid else "Not running"

            if self._agent:
                mem_stats = self._agent.memory.stats()
                mem_text = f"\n📚 Memory: {mem_stats['total_tasks']} tasks | {mem_stats['skills']} skills"
            else:
                mem_text = ""

            text = (
                f"⚙️ *DoItAgent Status*\n\n"
                f"🧠 LLM: `{self.cfg.llm.backend}/{self.cfg.llm.model}`\n"
                f"🤖 Daemon: `{daemon_status}`\n"
                f"💻 CPU: `{cpu:.1f}%`\n"
                f"🧮 RAM: `{ram.used//1024**2}MB / {ram.total//1024**2}MB ({ram.percent:.0f}%)`\n"
                f"💾 Disk: `{disk.used//1024**3}GB / {disk.total//1024**3}GB`\n"
                f"⏱ Uptime: `{h}h {m}m`\n"
                f"🔐 Safe Mode: `{'On' if self.cfg.security.safe_mode else 'Off'}`"
                f"{mem_text}\n"
                f"🕐 `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`"
            )
        except Exception as e:
            text = f"⚙️ Agent Online\n`{self.cfg.llm.backend}/{self.cfg.llm.model}`\nError: {e}"

        await update.message.reply_text(text, parse_mode="Markdown")

    @authorized_only
    async def cmd_screenshot(self, update, context):
        msg = await update.message.reply_text("📸 Taking screenshot...")
        try:
            path = await asyncio.get_event_loop().run_in_executor(
                None, self._agent.screen.screenshot
            )
            await update.message.reply_photo(photo=open(path, "rb"), caption="📸 Current screen")
            await msg.delete()
        except Exception as e:
            await msg.edit_text(f"❌ Screenshot failed: {e}")

    @authorized_only
    async def cmd_history(self, update, context):
        if not self._agent:
            await update.message.reply_text("Agent not initialized.")
            return
        history = self._agent.memory.recent(20)
        if not history:
            await update.message.reply_text("No history yet.")
            return
        lines = ["📜 *Recent Commands:*\n"]
        for e in reversed(history[-15:]):
            t = e.get("timestamp", "")[:16]
            task = e.get("task", "")[:60]
            lines.append(f"`{t}` — _{task}_")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    @authorized_only
    async def cmd_skills(self, update, context):
        if not self._agent:
            return
        skills = self._agent.memory.list_skills()
        if not skills:
            await update.message.reply_text("No skills learned yet.\nUse: _teach skill [name]: step1, step2..._")
            return
        lines = ["🎯 *Learned Skills:*\n"]
        for s in skills:
            lines.append(f"• *{s['name']}* — {s['description'][:60]}")
            lines.append(f"  Steps: {len(s['steps'])} | Runs: {s.get('run_count', 0)}")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    @authorized_only
    async def cmd_audit(self, update, context):
        from doitagent.security.sandbox import get_audit_log
        entries = get_audit_log(20)
        if not entries:
            await update.message.reply_text("Audit log is empty.")
            return
        lines = ["🔍 *Audit Log (last 20):*\n"]
        for e in reversed(entries):
            risk_emoji = {"LOW": "🟢", "MEDIUM": "🟡", "HIGH": "🔴", "CRITICAL": "⛔"}.get(e["risk"], "⚪")
            lines.append(f"{risk_emoji} `{e['timestamp'][11:19]}` {e['action']}: `{e['command'][:50]}`")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    @authorized_only
    async def cmd_stop(self, update, context):
        await update.message.reply_text("⏹ Stopping DoItAgent. Goodbye!")
        await asyncio.sleep(1)
        os._exit(0)

    @authorized_only
    async def cmd_clear(self, update, context):
        if self._agent:
            self._agent.memory.clear_history()
        await update.message.reply_text("🧹 History cleared.")

    # ─── Message handler ──────────────────────────────────────────────────────

    @authorized_only
    @rate_limited(calls_per_minute=30)
    async def handle_message(self, update, context):
        text = update.message.text.strip()
        if not text:
            return

        # Check for skill teaching syntax: "teach skill morning_briefing: step1, step2"
        if text.lower().startswith("teach skill "):
            await self._handle_teach_skill(update, context, text)
            return

        # Safety check
        if self._is_dangerous(text):
            await self._request_approval(update, context, text)
            return

        await self._execute(update, context, text)

    async def _execute(self, update, context, task: str, extra_msg: str = ""):
        if not self._agent:
            await update.message.reply_text("❌ Agent not initialized. Run: doit setup")
            return

        thinking = await update.message.reply_text(
            f"🤔 *Working...*\n`{task[:60]}`", parse_mode="Markdown"
        )
        steps_log = []

        def on_step(tool_name: str, args_str: str, result):
            steps_log.append(f"→ `{tool_name}({args_str[:40]})`")

        if hasattr(self._agent, "_executor"):
            self._agent._executor.on_step = on_step

        try:
            result = await asyncio.get_event_loop().run_in_executor(
                None, self._agent.do, task
            )

            result_str = str(result)

            # If result is a file path — send the file
            if _is_sendable_path(result_str):
                await self._send_file(update, result_str, f"✅ {task[:60]}")
                await thinking.delete()
                return

            # Build response
            parts = [f"✅ *Done!*\n"]
            if steps_log and self.cfg.agent.verbose:
                parts.append("_Steps:_\n" + "\n".join(steps_log[-5:]) + "\n")
            parts.append(result_str[:3500])

            full = "\n".join(parts)
            for chunk in _chunk(full, 3800):
                await update.message.reply_text(chunk, parse_mode="Markdown")
            await thinking.delete()

        except Exception as e:
            await thinking.edit_text(f"❌ Error: {str(e)[:500]}")
            logger.exception(f"Task execution error: {task}")

    async def _request_approval(self, update, context, command: str):
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        cmd_id = str(update.message.message_id)
        self._pending[cmd_id] = command

        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ Yes, do it", callback_data=f"approve:{cmd_id}"),
            InlineKeyboardButton("❌ Cancel",     callback_data=f"deny:{cmd_id}"),
        ]])
        await update.message.reply_text(
            f"⚠️ *Potentially destructive action:*\n```\n{command[:200]}\n```\nExecute on your PC?",
            reply_markup=kb, parse_mode="Markdown",
        )

    async def cb_approval(self, update, context):
        query = update.callback_query
        await query.answer()
        data = query.data

        if data.startswith("approve:"):
            cmd_id = data[8:]
            command = self._pending.pop(cmd_id, None)
            if command:
                await query.edit_message_text(f"✅ Executing: _{command[:80]}_", parse_mode="Markdown")
                # Create a fake update-like object to reuse _execute
                await self._execute_approved(query, context, command)
        elif data.startswith("deny:"):
            cmd_id = data[5:]
            self._pending.pop(cmd_id, None)
            await query.edit_message_text("❌ Cancelled.")

    async def _execute_approved(self, query, context, command: str):
        try:
            result = await asyncio.get_event_loop().run_in_executor(
                None, self._agent.do, command
            )
            result_str = str(result)[:3500]
            for chunk in _chunk(f"✅ *Done!*\n{result_str}", 3800):
                await context.bot.send_message(
                    chat_id=query.message.chat_id,
                    text=chunk, parse_mode="Markdown"
                )
        except Exception as e:
            await context.bot.send_message(
                chat_id=query.message.chat_id,
                text=f"❌ Error: {e}"
            )

    async def handle_photo(self, update, context):
        """Handle incoming photos — OCR + AI analysis."""
        if self.allowed_ids and update.effective_user.id not in self.allowed_ids:
            return
        msg = await update.message.reply_text("🔍 Analyzing image...")
        try:
            photo = update.message.photo[-1]
            f = await context.bot.get_file(photo.file_id)
            from doitagent.config import SANDBOX_DIR
            tmp = SANDBOX_DIR / f"photo_{photo.file_id[:8]}.jpg"
            await f.download_to_drive(str(tmp))
            caption = update.message.caption or "Extract all text and describe this image."
            result = await asyncio.get_event_loop().run_in_executor(
                None, self._agent.do, f"{caption} [Image: {tmp}]"
            )
            await msg.edit_text(f"📷 *Result:*\n{str(result)[:3000]}", parse_mode="Markdown")
        except Exception as e:
            await msg.edit_text(f"❌ Image error: {e}")

    async def handle_document(self, update, context):
        """Handle uploaded files — save to Downloads and process."""
        if self.allowed_ids and update.effective_user.id not in self.allowed_ids:
            return
        doc = update.message.document
        msg = await update.message.reply_text(f"📎 Saving `{doc.file_name}`...", parse_mode="Markdown")
        try:
            f = await context.bot.get_file(doc.file_id)
            save_path = Path.home() / "Downloads" / doc.file_name
            await f.download_to_drive(str(save_path))
            caption = update.message.caption or f"I just received {doc.file_name}. What should I do with it?"
            result = await asyncio.get_event_loop().run_in_executor(
                None, self._agent.do,
                f"{caption} File is at: {save_path}"
            )
            await msg.edit_text(
                f"✅ *Saved!* `{save_path}`\n\n{str(result)[:2000]}",
                parse_mode="Markdown"
            )
        except Exception as e:
            await msg.edit_text(f"❌ File error: {e}")

    async def _handle_teach_skill(self, update, context, text: str):
        """Parse and save a skill from chat: 'teach skill name: step1, step2'"""
        try:
            # "teach skill morning_briefing: take screenshot, check email, play music"
            rest = text[len("teach skill "):].strip()
            if ":" in rest:
                name, steps_str = rest.split(":", 1)
                steps = [s.strip() for s in steps_str.split(",") if s.strip()]
            else:
                await update.message.reply_text(
                    "Format: `teach skill [name]: step1, step2, step3`", parse_mode="Markdown"
                )
                return

            if not steps:
                await update.message.reply_text("Need at least one step.")
                return

            self._agent.memory.save_skill(
                name.strip(),
                f"Custom skill: {name.strip()}",
                steps
            )
            steps_display = "\n".join(f"  {i+1}. {s}" for i, s in enumerate(steps))
            await update.message.reply_text(
                f"✅ *Skill '{name.strip()}' saved!*\n\n"
                f"Steps:\n{steps_display}\n\n"
                f"Use: _run {name.strip()} skill_",
                parse_mode="Markdown"
            )
        except Exception as e:
            await update.message.reply_text(f"❌ Error saving skill: {e}")

    async def _send_file(self, update, path: str, caption: str):
        """Send a file back to the user."""
        p = Path(path.strip())
        ext = p.suffix.lower()
        try:
            if ext in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
                await update.message.reply_photo(photo=open(p, "rb"), caption=caption)
            else:
                await update.message.reply_document(
                    document=open(p, "rb"),
                    filename=p.name,
                    caption=caption
                )
        except Exception as e:
            await update.message.reply_text(f"{caption}\nFile: `{path}`\n(Send error: {e})", parse_mode="Markdown")

    async def _error_handler(self, update, context):
        logger.error(f"Telegram error: {context.error}", exc_info=context.error)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _is_sendable_path(result: str) -> bool:
    result = result.strip()
    if len(result) > 400:
        return False
    p = Path(os.path.expanduser(result))
    if p.exists() and p.is_file():
        ext = p.suffix.lower()
        return ext in (".png", ".jpg", ".jpeg", ".gif", ".pdf", ".docx",
                       ".xlsx", ".csv", ".txt", ".mp3", ".wav", ".zip")
    return False


def _print_startup_banner(cfg):
    print(f"""
╔══════════════════════════════════════════════╗
║  🤖  DoItAgent Telegram Bot  v2.0.0          ║
║  ─────────────────────────────────────────── ║
║  Brain:    {cfg.llm.backend}/{cfg.llm.model[:20]:<20}  ║
║  Safe:     {'✅ On' if cfg.security.safe_mode else '⚠️  Off':<20}              ║
║  Status:   ✅ Online                         ║
╚══════════════════════════════════════════════╝

  Open Telegram and message your bot to start!
  Press Ctrl+C to stop.
""")


# ─── Entry point ──────────────────────────────────────────────────────────────

def main():
    """Run the Telegram bot."""
    import sys
    from doitagent.utils.logger import setup_logging
    from doitagent.config import LOG_DIR
    setup_logging(log_file=LOG_DIR / "bot.log")

    from doitagent.config import Config
    cfg = Config.load()
    if not cfg.telegram.token:
        print("\n❌ Telegram not configured. Run: doit setup\n")
        sys.exit(1)

    bot = DoItAgentBot()
    try:
        asyncio.run(bot.run())
    except KeyboardInterrupt:
        print("\n\n⏹ Bot stopped. Goodbye!\n")


if __name__ == "__main__":
    main()
