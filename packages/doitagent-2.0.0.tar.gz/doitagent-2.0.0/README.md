# 🤖 DoItAgent — The World's Most Powerful Personal AGI

[![PyPI version](https://badge.fury.io/py/doitagent.svg)](https://badge.fury.io/py/doitagent)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20Linux%20%7C%20macOS-lightgrey.svg)](https://github.com/doitagent/doitagent)

> **Control your entire PC from anywhere via Telegram, voice, or Python.**  
> Natural language. 100% free. Runs 24/7. Fully autonomous.

---

## ⚡ What is DoItAgent?

DoItAgent is a Python library that turns any computer into an AI-powered agent you can control from **anywhere in the world** via Telegram. Tell it what to do in plain English — it executes.

```python
from doitagent import Agent

ai = Agent()                                                    # auto-loads config
ai.do("take a screenshot and save it to Desktop")
ai.do("find all PDFs in Downloads, zip them, email to me")
ai.do("search for today's AI news and create a Word summary doc")
ai.do("play lofi music on YouTube")
ai.do("what processes are consuming most memory?")
ai.do("create an Excel budget spreadsheet with 3 months of data")
```

Or message your **Telegram bot** from your phone — your laptop executes it instantly.

---

## 🚀 Quick Start

```bash
# Install
pip install doitagent

# Setup (interactive wizard — takes ~3 minutes)
doit setup

# Start the 24/7 Telegram bot
doit start

# Or use the interactive terminal
doit
```

That's it. The wizard handles everything.

---

## 📱 Telegram Setup

After `doit setup`, message your bot from anywhere:

```
take a screenshot
list files on my Desktop
create a Word doc about AI trends
open Chrome and go to YouTube  
run: ipconfig
search for Python news
make an Excel file with my budget
set volume to 60%
zip my Documents folder
say "task complete" out loud
teach skill morning: take screenshot, check email, play music
run morning skill
```

---

## 🧠 Supported LLM Backends

| Backend | Cost | Privacy | Setup |
|---------|------|---------|-------|
| **Ollama** | Free | 100% local | `doit setup` → option 1 |
| **NVIDIA NIM** | Free tier | API | `nvapi-...` key from build.nvidia.com |
| **Anthropic** | ~$0.05/task | API | `sk-ant-...` key |
| **OpenAI** | ~$0.05/task | API | `sk-...` key |
| **DeepSeek** | ~$0.001/task | API | Key from platform.deepseek.com |

```python
# Ollama (free, local)
ai = Agent.with_ollama("mistral")

# NVIDIA NIM (free tier)
ai = Agent.with_nvidia("nvapi-your-key", model="llama-3.1-70b")

# Anthropic
ai = Agent.with_anthropic("sk-ant-...", model="claude-opus-4-6")

# OpenAI
ai = Agent.with_openai("sk-...", model="gpt-4o")

# DeepSeek
ai = Agent.with_deepseek("your-key")
```

---

## 🔧 12 Capability Modules

### `ai.screen` — See the Screen
```python
ai.screen.screenshot()                           # Full screenshot → file path
ai.screen.screenshot(region=(0,0,800,600))       # Region screenshot
ai.screen.read_text()                            # OCR all text on screen
ai.screen.find_text_on_screen("Submit")          # → (x, y) coordinates
ai.screen.find_image_on_screen("icon.png")       # Template matching
ai.screen.watch_for_change((0,0,300,100), cb)    # Monitor region
```

### `ai.files` — File CRUD
```python
ai.files.create_file("~/Desktop/notes.txt", "content")
ai.files.read_file("~/Desktop/notes.txt")
ai.files.list_folder("~/Desktop", "*.pdf")
ai.files.find_files("*.pdf", "~/Downloads")
ai.files.move("~/Downloads/file.pdf", "~/Documents/")
ai.files.copy("~/file.txt", "~/backup/")
ai.files.trash("~/old.txt")                      # Recycle bin (safe)
ai.files.zip_folder("~/Project")
ai.files.unzip("~/archive.zip", "~/extracted/")
ai.files.read_json("~/config.json")
ai.files.write_json("~/config.json", {"key": "val"})
```

### `ai.browser` — Web Browser (Playwright)
```python
ai.browser.open("https://google.com")
ai.browser.goto("https://news.ycombinator.com")
ai.browser.click("text=Sign In")
ai.browser.type_text("input[name='q']", "python")
ai.browser.search_google("best Python books 2024")
ai.browser.get_text()                            # Full page text
ai.browser.screenshot("page.png", full_page=True)
ai.browser.fill_form({"#email": "me@x.com", "#pw": "pass"})
ai.browser.download_file("https://x.com/file.pdf", "~/file.pdf")
ai.browser.execute_js("return document.title")
```

### `ai.shell` — Commands & Scripts
```python
ai.shell.run("ipconfig")
ai.shell.run("dir C:/Users")
ai.shell.powershell("Get-Process | Sort CPU -Desc | Select -First 10")
ai.shell.open_app("notepad")
ai.shell.open_app("chrome")
ai.shell.kill_process("notepad.exe")
ai.shell.run_python("~/scripts/process.py", ["--input", "data.csv"])
ai.shell.run_python_code("import math; print(math.pi)")
ai.shell.pip_install("pandas numpy")
```

### `ai.kb` — Keyboard & Mouse
```python
ai.kb.click(500, 300)
ai.kb.click(500, 300, clicks=2)                  # Double-click
ai.kb.click_text("OK")                           # Find & click text on screen
ai.kb.type("Hello World!")
ai.kb.type_fast("Long text goes here...")        # Paste method
ai.kb.hotkey("ctrl", "c")
ai.kb.hotkey("ctrl", "shift", "esc")             # Task manager
ai.kb.hotkey("win", "d")                         # Show desktop
ai.kb.press("enter")
ai.kb.scroll(-5)                                 # Scroll down
ai.kb.drag(100, 100, 500, 100)
ai.kb.set_clipboard("Copy this!")
```

### `ai.system` — Windows System
```python
ai.system.notify("DoItAgent", "Task complete!")
ai.system.list_processes()                       # → List[dict]
ai.system.kill_process("notepad.exe")
ai.system.get_system_info()                      # CPU, RAM, disk
ai.system.get_battery()
ai.system.get_network_info()
ai.system.set_volume(70)
ai.system.lock_screen()
ai.system.get_installed_apps()
ai.system.schedule_task("MyTask", "python script.py", "daily")
```

### `ai.media` — Audio & Video
```python
ai.media.play("C:/Music/song.mp3")
ai.media.play_youtube("lofi hip hop study")
ai.media.play_spotify("Discover Weekly")
ai.media.pause()
ai.media.next_track()
ai.media.set_volume(80)
ai.media.text_to_speech("Task completed!")
ai.media.record_audio(duration=10, save_path="~/recording.wav")
```

### `ai.docs` — Document Creation
```python
# Word
path = ai.docs.create_word("report.docx", title="Q3 Report",
    paragraphs=["Revenue up 20%", "New markets: Asia, Europe"])
ai.docs.add_table_to_word("report.docx",
    headers=["Name","Sales"], rows=[["Alice","$50K"]])

# Excel
path = ai.docs.create_excel("data.xlsx",
    headers=["Date","Revenue","Units"],
    rows=[["Jan",50000,120], ["Feb",62000,155]])

# PDF
path = ai.docs.create_pdf("report.pdf", title="Annual Report",
    paragraphs=["Summary paragraph here."])
text = ai.docs.read_pdf("document.pdf")

# CSV
ai.docs.create_csv("export.csv", ["Name","Email"], [["Alice","a@b.com"]])
data = ai.docs.read_csv("export.csv")
```

### `ai.db` — SQLite Database
```python
ai.db.connect("~/myapp.db")                      # or ":memory:"
ai.db.create_table("tasks", {
    "id":   "INTEGER PRIMARY KEY AUTOINCREMENT",
    "name": "TEXT NOT NULL",
    "done": "INTEGER DEFAULT 0",
    "created_at": "TEXT DEFAULT CURRENT_TIMESTAMP",
})
id = ai.db.insert("tasks", {"name": "Buy groceries"})
rows = ai.db.select("tasks")
rows = ai.db.select("tasks", "done = ?", (0,))
ai.db.update("tasks", {"done": 1}, "id = ?", (id,))
ai.db.delete("tasks", "done = 1")
ai.db.execute("SELECT COUNT(*) as total FROM tasks")
ai.db.export_to_csv("tasks", "~/tasks.csv")
```

### `ai.search` — Web Search & Scraping
```python
results = ai.search.web_search("Python automation 2024", num_results=10)
summary = ai.search.search_and_summarize("latest AI news")
text    = ai.search.scrape_page("https://example.com")
links   = ai.search.scrape_page("https://example.com", extract="links")
news    = ai.search.search_news("artificial intelligence", num_results=5)
page    = ai.search.get_page_text("https://docs.python.org", max_chars=5000)
```

### `ai.voice` — Speech I/O
```python
command = ai.voice.listen()                      # Listen 5 seconds
command = ai.voice.listen(duration=10)
ai.voice.speak("Task completed successfully!")
text    = ai.voice.transcribe_file("~/meeting.mp3")
path    = ai.voice.save_speech("Hello", "~/hello.mp3")
voices  = ai.voice.list_voices()
```

### `ai.email` — Send & Read Email
```python
ai.email.configure("me@gmail.com", "app_password")
ai.email.send("boss@company.com", "Report Ready", "See attached.", ["~/report.pdf"])
emails = ai.email.read_inbox(limit=10, unread_only=True)
found  = ai.email.search_emails("invoice")
```

---

## 🔗 Advanced Features

### Pipelines — Chain tasks
```python
ai.pipeline(
    "search the web for top 5 Python frameworks in 2024",
    "create a Word document summarizing the results with a comparison table",
    "save it to Desktop as python_frameworks_2024.docx",
)
```

### Watch Triggers — React to events
```python
ai.watch(
    trigger="CPU usage exceeds 90%",
    action="notify me and save a list of top processes to Desktop/cpu_alert.txt",
    interval=60,
)
ai.watch(
    trigger="new PDF appears in Downloads folder",
    action="move it to Documents/PDFs/ and send me a Telegram notification",
    interval=15,
)
```

### Schedule Tasks — Time-based automation
```python
ai.schedule("take a screenshot and save with timestamp", "every day at 9am")
ai.schedule("search for AI news and append to ~/daily_news.txt", "every morning at 7am")
ai.schedule("clear old files in ~/Downloads older than 30 days", "every sunday at midnight")
```

### Learn Skills — Reusable workflows
```python
ai.learn(
    skill_name="morning_briefing",
    description="My morning routine",
    steps=[
        "take a screenshot of current desktop",
        "search the web for today's top tech news",
        "create a text file ~/Desktop/briefing.txt with the news",
        "say 'Good morning! Your briefing is ready.'",
    ],
)
ai.do("run morning_briefing skill")
```

### Voice Command Mode
```python
ai.listen()  # Speak commands aloud. Say "DoIt stop" to exit.
```

---

## 🛡️ Security

- **Safe mode** — confirms before deleting files or dangerous actions
- **Sandbox** — shell commands run in isolated temp directory
- **Risk classification** — CRITICAL/HIGH/MEDIUM/LOW for every command
- **Audit log** — every action logged to `~/.doitagent/logs/audit.jsonl`
- **Approval workflow** — Telegram bot asks before destructive actions
- **User whitelist** — only your Telegram user ID can control the bot
- **Secrets in keyring** — API keys stored in OS keyring, not plain text

---

## 🔄 24/7 Daemon

```bash
doit start           # Start with watchdog (auto-restarts on crash)
doit stop            # Stop the daemon
doit status          # Check status
```

Features:
- Automatic restart on crash (configurable max attempts)
- Periodic Telegram heartbeat messages
- Cross-platform: Windows Task Scheduler / Linux systemd / macOS LaunchAgent
- PID file management
- Full crash log

---

## 📦 Installation Options

```bash
# Minimal
pip install doitagent

# With voice (Whisper STT + pyttsx3 TTS)
pip install doitagent[voice]

# With Windows-specific extras
pip install doitagent[windows]

# Everything
pip install doitagent[all]
```

---

## 🗂️ Project Structure

```
doitagent/
├── core.py              # Agent — the main class
├── config.py            # Secure configuration
├── cli.py               # CLI (doit command)
├── exceptions.py        # Exception hierarchy
├── _version.py
├── agent/
│   ├── executor.py      # LLM reasoning loop
│   └── memory.py        # Persistent memory
├── llm/
│   └── client.py        # Multi-backend LLM client
├── modules/
│   ├── screen.py        # Screen vision & OCR
│   ├── files.py         # File CRUD
│   ├── browser.py       # Playwright automation
│   ├── shell.py         # Shell execution
│   ├── keyboard_mouse.py
│   ├── system.py        # Windows system
│   ├── media.py         # Audio/video
│   ├── documents.py     # Word/Excel/PDF
│   ├── database.py      # SQLite
│   ├── search.py        # Web search
│   ├── voice.py         # STT + TTS
│   └── email_mod.py     # Email
├── telegram/
│   └── bot.py           # Telegram bot
├── security/
│   └── sandbox.py       # Sandboxing + audit
├── daemon/
│   └── watchdog.py      # 24/7 daemon
└── utils/
    ├── logger.py         # Rich logging
    └── installer.py      # Auto-install deps
```

---

## 💻 CLI Reference

```bash
doit setup                    # First-time setup wizard
doit start                    # Start Telegram bot (24/7)
doit stop                     # Stop daemon
doit status                   # Show agent status
doit "take a screenshot"      # Run a single task
doit                          # Interactive chat mode
doit listen                   # Voice command mode
doit run reset                # Reset configuration
doit --version                # Show version
```

---

## 🤝 Contributing

```bash
git clone https://github.com/doitagent/doitagent
cd doitagent
pip install -e .[dev]
pytest tests/
```

---

## 📄 License

MIT License — Free to use, modify, distribute.

---

*Because life's too short to click things yourself.*
