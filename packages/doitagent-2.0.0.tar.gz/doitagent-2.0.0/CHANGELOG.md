# Changelog

## [2.0.0] — 2024

### Added
- 12 capability modules: screen, files, browser, shell, kb, system, media, docs, db, search, voice, email
- NVIDIA NIM backend (free tier GPU inference)
- Anthropic, OpenAI, DeepSeek, Ollama LLM backends
- Production Telegram bot with approval workflow, file upload/download, rate limiting
- 24/7 daemon with auto-restart watchdog
- Cross-platform auto-start (Windows Task Scheduler / Linux systemd / macOS LaunchAgent)
- Rich CLI with interactive setup wizard
- Persistent memory (task history, skills, preferences)
- Security sandbox with risk classification and audit logging
- Secrets stored in OS keyring (not plain text)
- Pipeline, watch, schedule, learn, listen APIs
- Auto-install missing dependencies
- Full type hints and docstrings

## [1.0.0] — Initial release
- Basic automation modules
- Telegram bot
- Ollama support
