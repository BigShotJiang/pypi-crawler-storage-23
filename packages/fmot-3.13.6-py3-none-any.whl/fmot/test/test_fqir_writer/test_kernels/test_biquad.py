import numpy as np
from scipy import signal
from fmot.fqir.writer import new_fqir_graph, FQIRWriter
from fmot.fqir.writer.kernels import write_biquad
import pytest


ERROR_TOL_PERCENT = 5e-2
ERROR_TOL_ABSOLUTE = 5e2


@pytest.mark.parametrize(
    ["b", "a"],
    [
        ([1, 0, 0], [1, 0, 0]),  # pass through
        ([2, 0, 0], [2, 0, 0]),  # pass through with scaling
        ([0.5, 0, 0], [0.5, 0, 0]),  # pass through with scaling
        (
            [0.00146032, 0.00292063, 0.00146032],
            [1, -1.88903308, 0.89487434],
        ),  # lowpass butterworth at cutoff 200 Hz (fs=16000)
        (
            [0.00145179, 0.00290357, 0.00145179],
            [1, -1.91092536, 0.91744109],
        ),  # lowpass chebyshev at cutoff 200 Hz (fs=16000)
        (
            [0.00844269, 0.01688539, 0.00844269],
            [1, -1.72377617, 0.75754694],
        ),  # lowpass butterworth at cutoff 500 Hz (fs=16000)
        (
            [0.00851966, 0.01703931, 0.00851966],
            [1, -1.76849143, 0.80672828],
        ),  # lowpass chebyshev at cutoff 500 Hz (fs=16000)
        (
            [0.02995458, 0.05990916, 0.02995458],
            [1, -1.45424359, 0.57406192],
        ),  # lowpass butterworth at cutoff 1000 Hz (fs=16000)
        (
            [0.03080743, 0.06161486, 0.03080743],
            [1, -1.51568444, 0.65395046],
        ),  # lowpass chebyshev at cutoff 1000 Hz (fs=16000)
        (
            [0.18669433, -0.37338867, 0.18669433],
            [1, 0.46293803, 0.20971536],
        ),  # highpass butterworth at cutoff 5000 Hz (fs=16000)
        (
            [0.19710553, -0.39421105, 0.19710553],
            [1, 0.45627663, 0.34090079],
        ),  # highpass chebyshev at cutoff 5000 Hz (fs=16000)
        (
            [0.09763107, -0.19526215, 0.09763107],
            [1, 0.94280904, 0.33333333],
        ),  # highpass butterworth at cutoff 6000 Hz (fs=16000)
        (
            [0.10255744, -0.20511488, 0.10255744],
            [1, 0.98650792, 0.44679329],
        ),  # highpass chebyshev at cutoff 6000 Hz (fs=16000)
        (
            [0.02995458, -0.05990916, 0.02995458],
            [1, 1.45424359, 0.57406192],
        ),  # highpass butterworth at cutoff 7000 Hz (fs=16000)
        (
            [0.03080743, -0.06161486, 0.03080743],
            [1, 1.51568444, 0.65395046],
        ),  # highpass chebyshev at cutoff 7000 Hz (fs=16000)
    ],
)
@pytest.mark.parametrize(
    "input",
    [
        [2**12, 0, 0, 0, 0, 0, 0, 0],  # impulse
        [
            2**12,
            2**12,
            2**12,
            2**12,
            2**12,
            2**12,
            2**12,
            2**12,
        ],  # step
        [2**12, 0, 2**12, 0, 2**12, 0, 2**12, 0],
        [2**12, 0, 0, 2**12, 0, 0, 2**12, 0],
    ],
)
@pytest.mark.parametrize("num_trailing_zeros", [992])
@pytest.mark.parametrize("hop", [2, 4, 8])
@pytest.mark.parametrize("input_precision", ["int24", "int16"])
@pytest.mark.parametrize("output_precision", ["int24", "int16"])
def test_biquad_with_known_input_known_filter(
    input: list[int],
    b: list[float],
    a: list[float],
    hop: int,
    num_trailing_zeros: int,
    input_precision: str,
    output_precision: str,
):
    """
    Test that the FQIR writer's biquad filter matches the scipy.signal.lfilter function for known input and filter.

    Args:
        input (list[int]): list of input values.
        b (list[float]): list of feedforward coefficients.
        a (list[float]): list of feedback coefficients.
        hop (int): number of samples per hop.
        num_trailing_zeros (int): number of trailing zeros to add to the input.
        input_precision (str): precision of the input.
        output_precision (str): precision of the output.
    """
    # define quanta for the input and output
    input_quanta = -1 * int(input_precision.split("int")[1]) + 1
    output_quanta = -1 * int(output_precision.split("int")[1]) + 1

    # create the graph
    main = new_fqir_graph()
    writer = FQIRWriter.from_fqir(main, output_precision)

    # add the input to the graph
    x = writer.add_input(channels=hop, quanta=input_quanta, precision=input_precision)

    # write the biquad filter
    y = write_biquad(writer, x, b=b, a=a, quanta=output_quanta)

    # add the output to the graph
    writer.add_outputs([y], append=False)

    # extend input with trailing zeros and reshape into frames
    input_vals = list(input) + num_trailing_zeros * [0]
    if len(input_vals) % hop != 0:
        raise ValueError(
            f"input length {len(input_vals)} is not divisible by hop={hop}"
        )
    x_vals = np.array(input_vals, dtype=np.int32).reshape(-1, hop)

    # run the graph and compute the expected output
    y_vals = main.run(x_vals)
    x_real = x_vals.flatten().astype(np.float32) * (2**input_quanta)
    y_real = signal.lfilter(b, a, x_real)
    y_expected = y_real / (2**output_quanta)

    # compute error element-wise
    y_expected_flat = y_expected.flatten()
    y_vals_flat = y_vals.flatten()
    for i in range(len(y_expected_flat)):
        percent_error = np.abs(y_vals_flat[i] - y_expected_flat[i]) / np.abs(
            y_expected_flat[i] + 1e-8
        )
        error = np.abs(y_vals_flat[i] - y_expected_flat[i])
        assert percent_error <= ERROR_TOL_PERCENT or error <= ERROR_TOL_ABSOLUTE, (
            f"percent error={percent_error}\n"
            f"error={error}\n"
            f"FQIR output[{i}]={y_vals.flatten()[i]}\n"
            f"Expected output[{i}]={y_expected.flatten()[i]}\n"
            f"index={i}"
        )


@pytest.mark.parametrize(
    ["b", "a"],
    [
        ([1, 0, 0], [1, 0, 0]),  # pass through
        ([2, 0, 0], [2, 0, 0]),  # pass through with scaling
        ([0.5, 0, 0], [0.5, 0, 0]),  # pass through with scaling
        (
            [0.00146032, 0.00292063, 0.00146032],
            [1, -1.88903308, 0.89487434],
        ),  # lowpass butterworth at cutoff 200 Hz (fs=16000)
        (
            [0.00145179, 0.00290357, 0.00145179],
            [1, -1.91092536, 0.91744109],
        ),  # lowpass chebyshev at cutoff 200 Hz (fs=16000)
        (
            [0.00844269, 0.01688539, 0.00844269],
            [1, -1.72377617, 0.75754694],
        ),  # lowpass butterworth at cutoff 500 Hz (fs=16000)
        (
            [0.00851966, 0.01703931, 0.00851966],
            [1, -1.76849143, 0.80672828],
        ),  # lowpass chebyshev at cutoff 500 Hz (fs=16000)
        (
            [0.02995458, 0.05990916, 0.02995458],
            [1, -1.45424359, 0.57406192],
        ),  # lowpass butterworth at cutoff 1000 Hz (fs=16000)
        (
            [0.03080743, 0.06161486, 0.03080743],
            [1, -1.51568444, 0.65395046],
        ),  # lowpass chebyshev at cutoff 1000 Hz (fs=16000)
        (
            [0.18669433, -0.37338867, 0.18669433],
            [1, 0.46293803, 0.20971536],
        ),  # highpass butterworth at cutoff 5000 Hz (fs=16000)
        (
            [0.19710553, -0.39421105, 0.19710553],
            [1, 0.45627663, 0.34090079],
        ),  # highpass chebyshev at cutoff 5000 Hz (fs=16000)
        (
            [0.09763107, -0.19526215, 0.09763107],
            [1, 0.94280904, 0.33333333],
        ),  # highpass butterworth at cutoff 6000 Hz (fs=16000)
        (
            [0.10255744, -0.20511488, 0.10255744],
            [1, 0.98650792, 0.44679329],
        ),  # highpass chebyshev at cutoff 6000 Hz (fs=16000)
        (
            [0.02995458, -0.05990916, 0.02995458],
            [1, 1.45424359, 0.57406192],
        ),  # highpass butterworth at cutoff 7000 Hz (fs=16000)
        (
            [0.03080743, -0.06161486, 0.03080743],
            [1, 1.51568444, 0.65395046],
        ),  # highpass chebyshev at cutoff 7000 Hz (fs=16000)
    ],
)
@pytest.mark.parametrize("input_length", [8, 16, 32, 64, 128])
@pytest.mark.parametrize("num_trailing_zeros", [992])
@pytest.mark.parametrize("hop", [2, 4, 8])
@pytest.mark.parametrize("input_precision", ["int24", "int16"])
@pytest.mark.parametrize("output_precision", ["int24", "int16"])
def test_biquad_with_random_input_known_filter(
    b: list[float],
    a: list[float],
    input_length: int,
    hop: int,
    num_trailing_zeros: int,
    input_precision: str,
    output_precision: str,
):
    """
    Test that the FQIR writer's biquad filter matches the scipy.signal.lfilter function for random input and known filter.

    Args:
        b (list[float]): list of feedforward coefficients.
        a (list[float]): list of feedback coefficients.
        input_length (int): length of the input.
        hop (int): number of samples per hop.
        num_trailing_zeros (int): number of trailing zeros to add to the input.
        input_precision (str): precision of the input.
        output_precision (str): precision of the output.
    """
    # define quanta for the input and output
    input_quanta = -1 * int(input_precision.split("int")[1]) + 1
    output_quanta = -1 * int(output_precision.split("int")[1]) + 1

    # create the graph
    main = new_fqir_graph()
    writer = FQIRWriter.from_fqir(main, output_precision)

    # add the input to the graph
    x = writer.add_input(channels=hop, quanta=input_quanta, precision=input_precision)

    # write the biquad filter
    y = write_biquad(writer, x, b=b, a=a, quanta=output_quanta)

    # add the output to the graph
    writer.add_outputs([y], append=False)

    # extend input with trailing zeros and reshape into frames
    bw = int(input_precision.split("int")[1])
    input = np.random.randint(
        low=-(2 ** (bw - 10)),
        high=2 ** (bw - 10) - 1,
        size=input_length,
    ).tolist()
    input_vals = list(input) + num_trailing_zeros * [0]
    if len(input_vals) % hop != 0:
        raise ValueError(
            f"input length {len(input_vals)} is not divisible by hop={hop}"
        )
    x_vals = np.array(input_vals, dtype=np.int32).reshape(-1, hop)

    # run the graph and compute the expected output
    y_vals = main.run(x_vals)
    x_real = x_vals.flatten().astype(np.float32) * (2**input_quanta)
    y_real = signal.lfilter(b, a, x_real)
    y_expected = y_real / (2**output_quanta)

    # compute error element-wise
    y_expected_flat = y_expected.flatten()
    y_vals_flat = y_vals.flatten()
    for i in range(len(y_expected_flat)):
        percent_error = np.abs(y_vals_flat[i] - y_expected_flat[i]) / np.abs(
            y_expected_flat[i] + 1e-8
        )
        error = np.abs(y_vals_flat[i] - y_expected_flat[i])
        assert percent_error <= ERROR_TOL_PERCENT or error <= ERROR_TOL_ABSOLUTE, (
            f"percent error={percent_error}\n"
            f"error={error}\n"
            f"FQIR output[{i}]={y_vals.flatten()[i]}\n"
            f"Expected output[{i}]={y_expected.flatten()[i]}\n"
            f"index={i}"
        )


@pytest.mark.parametrize(
    "input_length",
    [
        8,
        8,
        8,
        8,
        8,
        16,
        16,
        16,
        16,
        16,
        32,
        32,
        32,
        32,
        32,
        64,
        64,
        64,
        64,
        64,
        128,
        128,
        128,
        128,
        128,
    ],
)
@pytest.mark.parametrize("num_trailing_zeros", [992])
@pytest.mark.parametrize("hop", [2, 4, 8])
@pytest.mark.parametrize("input_precision", ["int24", "int16"])
@pytest.mark.parametrize("output_precision", ["int24", "int16"])
def test_biquad_with_random_input_random_filter(
    input_length: int,
    num_trailing_zeros: int,
    hop: int,
    input_precision: str,
    output_precision: str,
):
    """
    Test that the FQIR writer's biquad filter matches the scipy.signal.lfilter function for random input and filter.

    Args:
        input_length (int): length of the input.
        num_trailing_zeros (int): number of trailing zeros to add to the input.
        hop (int): number of samples per hop.
        input_precision (str): precision of the input.
        output_precision (str): precision of the output.
    """
    # generate the random input with relatively low magnitude to avoid overflow
    input_quanta = -1 * int(input_precision.split("int")[1]) + 1
    output_quanta = -1 * int(output_precision.split("int")[1]) + 1

    # create the graph
    main = new_fqir_graph()
    writer = FQIRWriter.from_fqir(main, output_precision)

    # add the input to the graph
    x = writer.add_input(channels=hop, quanta=input_quanta, precision=input_precision)

    # generate the random filter
    b = np.random.uniform(-5, 5, 3).tolist()
    a = np.random.uniform(-5, 5, 3).tolist()

    # keep on generating random filter until it is stable
    _, p, _ = signal.tf2zpk(b, a)
    while np.any(np.abs(p) >= 1):
        b = np.random.uniform(-5, 5, 3).tolist()
        a = np.random.uniform(-5, 5, 3).tolist()
        _, p, _ = signal.tf2zpk(b, a)

    # write the biquad filter
    y = write_biquad(writer, x, b=b, a=a, quanta=output_quanta)

    # add the output to the graph
    writer.add_outputs([y], append=False)

    # extend input with trailing zeros and reshape into frames
    bw = int(input_precision.split("int")[1])
    input = np.random.randint(
        low=-(2 ** (bw - 10)),
        high=2 ** (bw - 10) - 1,
        size=input_length,
    ).tolist()
    input_vals = list(input) + num_trailing_zeros * [0]
    if len(input_vals) % hop != 0:
        raise ValueError(
            f"input length {len(input_vals)} is not divisible by hop={hop}"
        )
    x_vals = np.array(input_vals, dtype=np.int32).reshape(-1, hop)

    # run the graph and compute the expected output
    y_vals = main.run(x_vals)
    x_real = x_vals.flatten().astype(np.float32) * (2**input_quanta)
    y_real = signal.lfilter(b, a, x_real)
    y_expected = y_real / (2**output_quanta)

    # compute error element-wise
    y_expected_flat = y_expected.flatten()
    y_vals_flat = y_vals.flatten()
    for i in range(len(y_expected_flat)):
        percent_error = np.abs(y_vals_flat[i] - y_expected_flat[i]) / np.abs(
            y_expected_flat[i] + 1e-8
        )
        error = np.abs(y_vals_flat[i] - y_expected_flat[i])
        assert percent_error <= ERROR_TOL_PERCENT or error <= ERROR_TOL_ABSOLUTE, (
            f"percent error={percent_error}\n"
            f"error={error}\n"
            f"FQIR output[{i}]={y_vals.flatten()[i]}\n"
            f"Expected output[{i}]={y_expected.flatten()[i]}\n"
            f"index={i}"
        )
