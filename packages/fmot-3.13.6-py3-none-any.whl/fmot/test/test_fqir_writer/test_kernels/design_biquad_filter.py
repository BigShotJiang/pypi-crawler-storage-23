#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import matplotlib.pyplot as plt
from scipy import signal


def _parse_cutoffs(raw: str) -> list[float]:
    return [float(x) for x in raw.split(",") if x.strip()]


def _format_coeffs(b: np.ndarray, a: np.ndarray) -> str:
    b_s = np.array2string(b, separator=", ", precision=8)
    a_s = np.array2string(a, separator=", ", precision=8)
    return f"{b_s}, {a_s}"


def _plot_response(
    cutoff: float,
    fs: float,
    kind: str,
    b_butter: np.ndarray,
    a_butter: np.ndarray,
    b_cheby: np.ndarray,
    a_cheby: np.ndarray,
    out_dir: Path,
) -> None:
    w, h_butter = signal.freqz(b_butter, a_butter, fs=fs)
    _, h_cheby = signal.freqz(b_cheby, a_cheby, fs=fs)

    mag_butter = abs(h_butter)
    mag_cheby = abs(h_cheby)

    plt.figure(figsize=(8, 4))
    plt.plot(w, mag_butter, label="Butterworth")
    plt.plot(w, mag_cheby, label="Chebyshev I")
    plt.title(f"{kind} cutoff={cutoff} Hz, fs={fs} Hz")
    plt.xlabel("Frequency (Hz)")
    plt.ylabel("|H(e^jw)|")
    plt.xscale("log")
    plt.grid(True, alpha=0.3)
    plt.legend()

    out_path = out_dir / f"{kind}_cutoff_{cutoff:g}Hz.png"
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()


def design_filters(
    cutoffs: Sequence[float],
    fs: float,
    ripple: float,
    kind: str,
) -> list[tuple[float, np.ndarray, np.ndarray, np.ndarray, np.ndarray]]:
    results = []
    for cutoff in cutoffs:
        if kind in {"lowpass", "highpass"}:
            wn = cutoff
        elif kind == "bandpass":
            if not isinstance(cutoff, Iterable):
                raise ValueError("bandpass requires cutoff to be a pair (low, high)")
            wn = cutoff
        else:
            raise ValueError(f"Unsupported kind: {kind}")

        b_butter, a_butter = signal.butter(2, wn, btype=kind, fs=fs, output="ba")
        b_cheby, a_cheby = signal.cheby1(2, ripple, wn, btype=kind, fs=fs, output="ba")
        results.append((cutoff, b_butter, a_butter, b_cheby, a_cheby))
    return results


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate 2nd-order Butterworth and Chebyshev I filters."
    )
    parser.add_argument(
        "--cutoffs",
        default="5000, 6000, 7000",
        help="Comma-separated cutoff frequencies in Hz.",
    )
    parser.add_argument("--fs", type=float, default=16000.0, help="Sample rate in Hz.")
    parser.add_argument(
        "--ripple",
        type=float,
        default=1.0,
        help="Chebyshev Type I passband ripple in dB.",
    )
    parser.add_argument(
        "--kind",
        choices=["lowpass", "highpass", "bandpass"],
        default="highpass",
        help="Filter type.",
    )
    args = parser.parse_args()

    cutoffs = _parse_cutoffs(args.cutoffs)
    results = design_filters(cutoffs, fs=args.fs, ripple=args.ripple, kind=args.kind)
    plot_dir = Path(__file__).resolve().parent / "plot"
    plot_dir.mkdir(parents=True, exist_ok=True)

    for cutoff, b_butter, a_butter, b_cheby, a_cheby in results:
        print(f"cutoff={cutoff} Hz")
        print(f"  butter: {_format_coeffs(b_butter, a_butter)}")
        print(f"  cheby1: {_format_coeffs(b_cheby, a_cheby)}")
        print("")
        _plot_response(
            cutoff,
            fs=args.fs,
            kind=args.kind,
            b_butter=b_butter,
            a_butter=a_butter,
            b_cheby=b_cheby,
            a_cheby=a_cheby,
            out_dir=plot_dir,
        )


if __name__ == "__main__":
    main()
