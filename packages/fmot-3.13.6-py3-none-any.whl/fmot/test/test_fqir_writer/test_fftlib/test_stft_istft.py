from fmot.nn import design_wola
from scipy.signal import get_window
import numpy as np
from fmot.fqir.writer import new_fqir_graph, FQIRWriter
from typing import Optional
import torch
import pytest


@pytest.mark.parametrize(
    ["hop_size", "window_size", "quanta"],
    [[64, 128, -11], [64, 512, -10], [320, 640, -9]],
)
@pytest.mark.parametrize("window_fn", [None, "hann", "hamming"])
@pytest.mark.parametrize("order", [0, 1, 2, 3])
def test_stft(hop_size, window_size, window_fn: Optional[str], quanta: int, order: int):
    if window_fn is not None:
        window_fn = get_window(window_fn, window_size)
        window_fn_torch = torch.as_tensor(window_fn)
    else:
        window_fn_torch = None

    graph = new_fqir_graph()
    writer = FQIRWriter.from_fqir(graph)
    x = writer.add_input(hop_size, quanta=-15, precision="int16")
    re, im = writer.stft(x, window_size, hop_size, order, window_fn, quanta)
    writer.add_outputs([re, im])

    x_vals = np.random.randint(low=-(2**14), high=2**14, size=(30, hop_size))
    re_fqir, im_fqir = graph.run(x_vals)

    y_fqir = (re_fqir + 1j * im_fqir) * 2**quanta

    x_torch = torch.as_tensor(x_vals).flatten()
    x_torch = x_torch * 2 ** (-15)
    x_torch = torch.nn.functional.pad(x_torch, (window_size - hop_size, 0))
    y_torch = torch.stft(
        x_torch,
        n_fft=window_size,
        hop_length=hop_size,
        window=window_fn_torch,
        return_complex=True,
        center=False,
    ).T.numpy()

    error = np.mean(np.abs(y_fqir - y_torch) ** 2)
    assert error < 6e-3


@pytest.mark.parametrize(
    ["hop_size", "window_size", "quanta"],
    [[64, 128, -11], [64, 512, -10], [320, 640, -9]],
)
@pytest.mark.parametrize("window_fn", [None, "hann", "hamming"])
@pytest.mark.parametrize("order", [0, 1, 2, 3])
def test_identity_stft_istft(
    hop_size, window_size, window_fn: Optional[str], quanta: int, order: int
):
    if window_fn is not None:
        window_fn = get_window(window_fn, window_size)
        window_fn_torch = torch.as_tensor(window_fn)
        synth_window_torch = design_wola(
            window_fn_torch, hop_size=hop_size, synthesis_window_size=2 * hop_size
        )
        synth_window = synth_window_torch.numpy()
    else:
        window_fn = None
        synth_window = np.ones(2 * hop_size) / 2

    graph = new_fqir_graph()
    writer = FQIRWriter.from_fqir(graph)
    x = writer.add_input(hop_size, quanta=-15, precision="int16")
    re, im = writer.stft(x, window_size, hop_size, order, window_fn, quanta)
    y = writer.istft(re, im, window_size, hop_size, order, synth_window, quanta=-15)
    writer.add_outputs([y])

    x = np.random.randint(low=-(2**14), high=2**14, size=(30, hop_size))
    y = graph.run(x)

    x = x[:-1]
    y = y[1:]

    nmse = np.mean((x - y) ** 2) / np.mean(x**2)
    print(nmse)
    assert nmse < 2e-3


if __name__ == "__main__":
    # test_stft(64, 128, "hann", -11, 3)
    test_identity_stft_istft(64, 128, "hann", -11, 3)
