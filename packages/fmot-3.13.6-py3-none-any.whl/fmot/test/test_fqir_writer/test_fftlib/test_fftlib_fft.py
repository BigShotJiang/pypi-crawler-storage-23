from fmot.fqir.writer import FQIRWriter, new_fqir_graph, fftlib
import numpy as np
import pytest


@pytest.mark.parametrize(
    ["channels", "order", "perm_lmax"],
    [
        # perm-lmax only needs to be tested on inputs longer than 512
        [128, 3, None],
        [128, 3, None],
        [640, 3, 512],
        [640, 3, None],
        [640, 3, 512],
        [640, 3, None],
    ],
)
def test_rfft(channels, order, perm_lmax):
    graph = new_fqir_graph()
    writer = FQIRWriter.from_fqir(graph)
    x = writer.add_input(channels, quanta=-15, precision="int16")
    re, im = fftlib.rfft(writer, x, order, quanta=None, perm_lmax=perm_lmax)
    writer.add_outputs([re, im])

    # print(graph)

    x = np.random.randint(-(2**15), 2**15, size=(10, channels))
    re_fqir, im_fqir = graph.run(x)
    re_fqir = re_fqir * 2 ** (re.quanta)
    im_fqir = im_fqir * 2 ** (im.quanta)
    y_fqir = re_fqir + 1j * im_fqir

    y_np = np.fft.rfft(x.astype(np.float32) * 2**-15)

    nmse = np.mean(np.abs(y_fqir - y_np) ** 2)
    nmse = nmse / np.mean(np.abs(y_np) ** 2)
    print(f"{nmse=}")
    print(graph.footprint_bytes())
    assert nmse < 1e-4


@pytest.mark.parametrize(
    ["channels", "order", "perm_lmax", "quanta_rfft"],
    [
        # perm-lmax only needs to be tested on inputs longer than 512
        [128, 3, None, None],
        [128, 3, None, None],
        [640, 3, 512, -10],
        [640, 3, None, -10],
        [640, 3, 512, -10],
        [640, 3, None, -10],
    ],
)
def test_rfft_irfft(channels, order, perm_lmax, quanta_rfft):
    graph = new_fqir_graph()
    writer = FQIRWriter.from_fqir(graph)
    x = writer.add_input(channels, quanta=-15, precision="int16")
    re, im = fftlib.rfft(writer, x, order, quanta=quanta_rfft, perm_lmax=perm_lmax)
    y = fftlib.irfft(writer, re, im, order, quanta=-15, perm_lmax=perm_lmax)
    writer.add_outputs([y])

    x = np.random.randint(-(2**15), 2**15, size=(10, channels))
    y = graph.run(x)

    nmse = np.mean(np.abs(x - y) ** 2)
    nmse = nmse / np.mean(np.abs(x) ** 2)
    print(f"{nmse=}")
    # print(graph.footprint_bytes())
    assert nmse < 1e-3
