from .rewriters import (
    rewrite_bias_squeeze_conv2d_expand_with_fused_conv1d,
    edit_qdq_scales_to_power_of_two,
)
