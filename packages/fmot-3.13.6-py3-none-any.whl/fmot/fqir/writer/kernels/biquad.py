from fmot.fqir.writer import FQIRWriter
from fmot.fqir import TensorProto
from scipy import signal
import numpy as np


def write_biquad(
    writer: FQIRWriter,
    x: TensorProto,
    b: list[float],
    a: list[float],
    quanta: int,
):
    """Generate a second-order IIR Biquad filter with static filter weights.

    This implementation runs a per-sample loop and keeps history in state buffers.

    The Biquad filter is defined by the following difference equation in time-domain:
    y[n] = (b_0 * x[n] + b_1 * x[n-1] + b_2 * x[n-2] - a_1 * y[n-1] - a_2 * y[n-2]) / a_0

    and has the following transfer function in the z-domain:
    H(z) = (b_0 + b_1 * z^-1 + b_2 * z^-2) / (a_0 + a_1 * z^-1 + a_2 * z^-2)

    Arguments:
        writer (FQIRWriter): FQIRWriter instance
        x (TensorProto): input signal (single channel)
        b (list[float]): feedforward coefficients (length 3)
        a (list[float]): feedback coefficients (length 3)
        quanta (int): quanta of the output signal
    Returns:
        TensorProto: concatenated output samples (single channel)
    """
    # check if biquad coefficients are valid
    if len(b) != 3:
        raise ValueError("b must be a list of length 3")
    if len(a) != 3:
        raise ValueError("a must be a list of length 3")

    # check for filter stability (all poles must be inside unit circle)
    _, p, _ = signal.tf2zpk(b, a)
    if np.any(np.abs(p) >= 1):
        raise ValueError("biquad coefficients are unstable")

    # buffers store [x[n-1], x[n-2]] and [y[n-1], y[n-2]]
    x_buffer = writer.add_zeros_buffer(channels=2, quanta=x.quanta, precision=x.dtype)
    y_buffer = writer.add_zeros_buffer(
        channels=2, quanta=quanta, precision=writer.output_precision
    )

    with writer.for_loop_writer(
        n_iter=x.shape[0], x_to_slice=[x], x_recurse_init=[x_buffer, y_buffer]
    ) as lwriter:
        # unpack loop inputs (note that if there is a single input, we need to add the "," because this is a list-unpack)
        (x_t,) = lwriter.sliced_inputs
        x_hist, y_hist = lwriter.recursed_inputs

        # split the history buffers into the previous input and output samples
        x_1, x_2 = lwriter.split(x_hist, [1, 1])
        y_1, y_2 = lwriter.split(y_hist, [1, 1])

        # perform biquad filter operation
        y_t = lwriter.multiply(x_t, b[0], quanta=quanta)
        y_t = lwriter.add(
            y_t, lwriter.multiply(x_1, b[1], quanta=quanta), quanta=quanta
        )
        y_t = lwriter.add(
            y_t, lwriter.multiply(x_2, b[2], quanta=quanta), quanta=quanta
        )
        y_t = lwriter.sub(
            y_t, lwriter.multiply(y_1, a[1], quanta=quanta), quanta=quanta
        )
        y_t = lwriter.sub(
            y_t, lwriter.multiply(y_2, a[2], quanta=quanta), quanta=quanta
        )
        y_t = lwriter.multiply(y_t, 1.0 / a[0], quanta=quanta)

        # rotate the history buffers
        x_next = lwriter.rotate(x_hist, x_t, insert_end=False)
        y_next = lwriter.rotate(y_hist, y_t, insert_end=False)

        # update the history buffers
        lwriter.update_recursed_state(x_hist, x_next)
        lwriter.update_recursed_state(y_hist, y_next)

        # return the concatenated output and the final values of the history buffers
        y_concat = lwriter.return_concatenated(y_t)
        x_final = lwriter.return_final(x_next)
        y_final = lwriter.return_final(y_next)

    # assign the final values of the history buffers to the buffers
    writer.assign(x_buffer, x_final)
    writer.assign(y_buffer, y_final)

    return y_concat
