"""Implement additional FQIR Optimizations using FQIRWriter tools..."""
from fmot.fqir import GraphProto, TensorProto, NodeProto
from typing import TYPE_CHECKING
import numpy as np

if TYPE_CHECKING:
    from fmot.fqir.writer import FQIRWriter


def _insert_broadcast_vvmul(writer: "FQIRWriter", node: NodeProto):
    with writer.replacing(node) as rwriter:
        x = node.inputs["x"]
        y = node.inputs["y"]
        z = node.outputs[0]

        input_sizes = set([z.shape[0] for z in [x, y]])
        broad_p = np.ones((max(input_sizes), 1), dtype=np.int32)
        broad_p = writer.add_parameter(
            broad_p, name=f"{node.name}_broadcast", precision="int8", quanta=0
        )

        if x.shape[0] == 1:
            with rwriter.with_precision(x.dtype) as pwriter:
                x = pwriter.matmul(broad_p, x, quanta=x.quanta, round=False)
        elif y.shape[0] == 1:
            with rwriter.with_precision(y.dtype) as pwriter:
                y = pwriter.matmul(broad_p, y, quanta=y.quanta, round=False)

        with rwriter.with_precision(z.dtype) as pwriter:
            z = pwriter.multiply(x, y, quanta=z.quanta, round=node.constants["rounded"])

        rwriter.set_replacements([z])


def kernelize_broadcast_vvmul(writer: "FQIRWriter"):
    """Temporary fix: any vvmul operations with mismatched input sizes will have
    a broadcast applied."""
    from fmot.fqir.writer import FQIRWriter

    for node in writer.arith.nodes:
        if node.opname == "vvmul":
            input_sizes = set([x.shape[0] for x in node.inputs.values()])
            if len(input_sizes) == 1:
                continue
            if 1 not in input_sizes:
                raise ValueError(
                    f"ILLEGAL: node {node} has mismatched input sizes: {input_sizes}"
                )

            _insert_broadcast_vvmul(writer, node)

        elif node.subgraph is not None:
            sub_writer = FQIRWriter(
                arith=node.subgraph, init=None, act_precision="int16", main=None
            )
            kernelize_broadcast_vvmul(sub_writer)
