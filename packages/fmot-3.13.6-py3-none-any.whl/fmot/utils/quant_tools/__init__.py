from .diagnosis import get_quant_diagnosis
