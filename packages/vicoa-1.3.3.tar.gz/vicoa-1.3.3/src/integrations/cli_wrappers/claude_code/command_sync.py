"""Helpers for scanning Claude slash commands from command folders."""

from pathlib import Path


def _extract_command_description(content: str, command_name: str) -> str:
    """Extract the best available description from command markdown."""
    description = ""
    lines = content.split("\n")

    # Check for YAML-style front matter.
    if lines and lines[0].strip() == "---":
        end_index = None
        for idx in range(1, len(lines)):
            if lines[idx].strip() == "---":
                end_index = idx
                break

        if end_index:
            for front_line in lines[1:end_index]:
                parts = front_line.split(":", 1)
                if len(parts) != 2:
                    continue
                key, value = parts[0].strip().lower(), parts[1].strip()
                if key == "description" and value:
                    description = value.strip("'\" ")
                    break

    # Fallback to first non-empty content or heading line.
    if not description:
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.startswith("#"):
                description = stripped.lstrip("#").strip()
            else:
                description = stripped
            break

    if not description:
        description = f"Custom command: {command_name}"

    return description


def scan_claude_commands(agent_type: str = "claude") -> dict:
    """Scan Claude command directories for custom user slash commands.

    Args:
        agent_type: Agent type ('claude', 'codex', or 'opencode')

    Returns:
        Dict of commands {command_name: {description: ...}}
    """
    _ = agent_type  # Reserved for future per-agent command source behavior.

    commands = {}
    commands_dirs = [
        Path.home() / ".claude" / "commands",
        Path.cwd() / ".claude" / "commands",
    ]
    for commands_dir in commands_dirs:
        if not commands_dir.exists():
            continue

        for file_path in sorted(commands_dir.rglob("*.md")):
            if not file_path.is_file():
                continue

            rel_path = file_path.relative_to(commands_dir)
            command_parts = list(rel_path.parts[:-1]) + [file_path.stem]
            command_name = ":".join(command_parts)
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()

                description = _extract_command_description(content, command_name)

                # Local ./.claude commands overwrite same-named global commands.
                commands[command_name] = {"description": description}
            except Exception as e:
                print(f"Warning: Could not read command file {file_path}: {e}")

    return commands
