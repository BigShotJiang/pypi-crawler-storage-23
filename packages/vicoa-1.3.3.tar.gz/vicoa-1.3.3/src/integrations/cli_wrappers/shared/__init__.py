"""Shared components for agent CLI wrappers.

This module provides reusable infrastructure for wrapping different AI coding agents
(Claude Code, OpenCode, Codex, etc.) with Vicoa integration.
"""

from integrations.headless.acp_client import ACPClient, ACPError, ACPResponse

__all__ = ["ACPClient", "ACPError", "ACPResponse"]
