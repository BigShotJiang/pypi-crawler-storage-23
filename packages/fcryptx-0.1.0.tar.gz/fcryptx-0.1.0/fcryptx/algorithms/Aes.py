# Import statements
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
import os


class Aes:
    def __init__(self, key):
        self.key = key
    

    # Will generate key based on the master key
    def convert_key_bits(self,salt: bytes,bit_len):
        kdf = Scrypt(
            salt=salt,
            length=bit_len//8, # Generate key based on the bit size(128,192,256)
            n=2**14,
            r=8,
            p=1
        )
        return kdf.derive(self.key.encode())



    #  encryption using salt + nonce
    def encrypt(self, fdata, bit_len):
        salt = os.urandom(16)
        nonce = os.urandom(12)
        key = self.convert_key_bits(salt, bit_len)

        aesgcm = AESGCM(key)
        
        data = fdata.encode()
        # We are embedding salt + nonce in the string, so that it can be split during decryption
        return salt+nonce+aesgcm.encrypt(nonce,data, None)
    



    # decryption function
    def decrypt(self, encrypted_text, bit_len):
        # Spliting the bytes using slicing operator
        salt = encrypted_text[:16]
        nonce = encrypted_text[16:28]
        enc_text = encrypted_text[28:]

        key = self.convert_key_bits(salt, bit_len)

        aesgcm = AESGCM(key)

        return aesgcm.decrypt(nonce, enc_text, None)