class Arguments:
    def __init__(self, args):
        self.command = []
        self.options = []
        self.optionValues = {}
        self.args = args

        for arg in args:
            if '-' in arg:
                if '=' in arg:
                    split_options = arg.split("=")
                    self.optionValues[split_options[0]]=split_options[1]
                    self.options.append(split_options[0])
                else:
                    self.options.append(arg)
            else:
                self.command.append(arg)
            

    def hasOption(self,option):
        return option in self.options
    
    def getOptionValue(self,option):
        return self.optionValues.get(option)

            