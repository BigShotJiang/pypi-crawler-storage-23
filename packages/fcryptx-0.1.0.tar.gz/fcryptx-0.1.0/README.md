# fcryptx

A lightweight AES encryption and decryption utility that works both as a **command-line tool** and a **Python library**.

It supports **AES-128, AES-192, and AES-256** encryption for secure file protection.

---

# Requirements

* Python **3.8+**

---

# Installation

```bash
pip install fcryptx
```

---

# Command Line Usage

```
fcryptx [--e | --d] --algorithm=AES-<128|192|256> --key=<secret_key> --file=<path> [--out=<path>]
```

## Options

| Option         | Description                               |
| -------------- | ----------------------------------------- |
| `--e`          | Encrypt file                              |
| `--d`          | Decrypt file                              |
| `--algorithm`  | AES algorithm (AES-128, AES-192, AES-256) |
| `--key`        | Secret key for encryption/decryption      |
| `--file`       | Input file path                           |
| `--out`        | Output directory (optional)               |
| `-h`, `--help` | Show help message                         |

---

# Examples

### Encrypt a file

```bash
fcryptx --e --algorithm=AES-256 --key=mysecretkey --file=data.txt
```

### Decrypt a file

```bash
fcryptx --d --algorithm=AES-256 --key=mysecretkey --file=data.enc
```

### Encrypt with custom output directory

```bash
fcryptx --e --algorithm=AES-128 --key=mysecretkey --file=data.txt --out=/home/user/
```

### Decrypt with custom output directory

```bash
fcryptx --d --algorithm=AES-128 --key=mysecretkey --file=data.enc --out=/home/user/
```

---

# Python Usage

You can also use **fcryptx** as a Python library.

```python
import fcryptx

cipher = fcryptx.AES("mysecretkey", 256)
cipher.encrypt_file("data.txt")
```

Decrypt:

```python
cipher.decrypt_file("data.enc")
```

---

# Dependencies

* cryptography (>=46.0.5)

This will be installed automatically.

---

# Build Debian Package

```
python setup.py --command-packages=stdeb.command bdist_deb
```

---

# License

MIT License
