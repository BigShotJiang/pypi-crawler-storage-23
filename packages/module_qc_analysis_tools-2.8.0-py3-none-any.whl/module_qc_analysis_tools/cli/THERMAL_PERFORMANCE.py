from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

import arrow
import matplotlib.pyplot as plt
import numpy as np
import typer
from module_qc_data_tools import (
    get_layer_from_sn,
    load_json,
    outputDataFrame,
    qcDataFrame,
    save_dict_list,
)

from module_qc_analysis_tools import __version__
from module_qc_analysis_tools.cli.globals import (
    CONTEXT_SETTINGS,
    OPTIONS,
    LogLevel,
)
from module_qc_analysis_tools.utils.analysis import (
    check_layer,
)
from module_qc_analysis_tools.utils.misc import (
    DataExtractor,
    JsonChecker,
    bcolors,
    calc_temp_ntc,
    get_inputs,
    get_NtcCalPar,
    get_time_stamp,
    getImuxMap,
    getVmuxMap,
)

app = typer.Typer(context_settings=CONTEXT_SETTINGS)

log = logging.getLogger("analysis")

EMPTY_VAL = -999


def calculate_TFM(i, v, T, T_ref):
    power_consumption = i * v
    power_density = power_consumption / (4 * 2.055 * 2.1021)
    return (T - T_ref) / power_density


def analyze_FE(inputDF):
    #  Get info
    data_in = outputDataFrame()
    data_in.from_dict(inputDF)
    qcframe = qcDataFrame()
    qcframe = data_in.get_results()
    metadata = qcframe.get_meta_data()

    chipID = metadata.get("ChipID")
    FE_ID = chipID - 11
    # qc_config = get_qc_config(
    #     qc_criteria_path, test_type, metadata.get("ModuleSN")
    # )

    # Read chipname from input DF
    try:
        chipname = metadata.get("Name")
        log.debug(f" Found chip name = {chipname} from chip config")
    except Exception:
        log.warning(
            bcolors.WARNING
            + "Chip name not found in input from {filename}, skipping."
            + bcolors.ENDC
        )

    extractor = DataExtractor(data_in, "THERMAL_PERFORMANCE")
    # extractor = DataExtractor(inputDF)
    calculated_data = extractor.calculate()
    Vmux_map = getVmuxMap()
    Imux_map = getImuxMap()

    T_values_names = []
    for imux in range(32):
        T_values_names.append(Imux_map[imux])
    for vmux in range(40):
        T_values_names.append(Vmux_map[vmux])

    V_INA_FE = np.mean(np.array(calculated_data["VinA"]["Values"]))
    V_IND_FE = np.mean(np.array(calculated_data["VinD"]["Values"]))
    I_INA_FE = np.mean(np.array(calculated_data["IinA"]["Values"]))
    I_IND_FE = np.mean(np.array(calculated_data["IinD"]["Values"]))

    # if inputDF._subtestType == "TP_TEMP":
    chipname_str = next(iter(metadata.get("ChipConfigs")))
    NtcCalPar = get_NtcCalPar(metadata["ChipConfigs"][chipname_str]["Parameter"])
    T_NTC_FE = calc_temp_ntc(calculated_data, NtcCalPar)
    return FE_ID, V_INA_FE, V_IND_FE, I_INA_FE, I_IND_FE, T_NTC_FE


@app.command()
def main(
    input_meas: Path = OPTIONS["input_meas"],
    base_output_dir: Path = OPTIONS["output_dir"],
    # qc_criteria_path: Path = OPTIONS["qc_criteria"],
    input_layer: str = OPTIONS["layer"],
    site: str = OPTIONS["site"],
    verbosity: LogLevel = OPTIONS["verbosity"],
):
    """
    Performs the THERMAL PERFORMANCE.

    It produces an output file with the calculated temperature from the internal and external temperature sensor, VDDA/VDDD and VINA/VIND.
    """
    test_type = Path(__file__).stem
    time_start = datetime.now().strftime("%Y-%m-%d_%H%M%S")

    output_dir = base_output_dir.joinpath(test_type).joinpath(f"{time_start}")
    output_dir.mkdir(parents=True, exist_ok=False)

    log.setLevel(verbosity.value)
    log.addHandler(logging.FileHandler(f"{output_dir}/output.log"))

    # Turn off matplotlib DEBUG messages
    plt.set_loglevel(level="warning")
    # Turn off pytest DEBUG messages
    pil_logger = logging.getLogger("PIL")
    pil_logger.setLevel(logging.INFO)

    log.info("")
    log.info(" ===============================================")
    log.info(" \tPerforming Thermal Performance analysis")
    log.info(" ===============================================")
    log.info("")

    allinputs = get_inputs(input_meas)

    alloutput = []
    timestamps = []

    for filename in sorted(allinputs):
        log.info("")
        log.info(f" Loading {filename}")
        meas_timestamp = get_time_stamp(filename)
        inputDFs = load_json(filename)
        # inputDF_FEs = inputDFs[0][0]["results"]["FE"]
        log.debug(
            f" There are results from {len(inputDFs)} measuremnet(s) stored in this file"
        )
        data = {}
        chipnames = []
        # results = {}

        for inputDF in inputDFs:
            # Check file integrity
            checker = JsonChecker(inputDF, test_type)
            try:
                checker.check(keywords_length=False)
            except BaseException as exc:
                log.exception(exc)
                log.warning(
                    bcolors.WARNING
                    + " JsonChecker check not passed, skipping this input."
                    + bcolors.ENDC
                )
                continue
            else:
                log.debug(" JsonChecker check passed!")

            #  Get info
            serialNumber = inputDF._serialNumber

            qcframe = inputDF.get_results()
            metadata = qcframe.get_meta_data()

            if input_layer == "Unknown":
                try:
                    layer = get_layer_from_sn(serialNumber)
                except Exception:
                    log.error(bcolors.WARNING + " Something went wrong." + bcolors.ENDC)
            else:
                log.warning(
                    bcolors.WARNING
                    + f" Overwriting default layer config {get_layer_from_sn(serialNumber)} with manual input {input_layer}!"
                    + bcolors.ENDC
                )
                layer = input_layer
            check_layer(layer)

            institution = metadata.get("Institution")
            if site != "" and institution != "":
                log.warning(
                    bcolors.WARNING
                    + f" Overwriting default institution {institution} with manual input {site}!"
                    + bcolors.ENDC
                )
                institution = site
            elif site != "":
                institution = site

            if institution == "":
                log.error(
                    bcolors.ERROR
                    + "No institution found. Please specify your testing site either in the measurement data or specify with the --site option. "
                    + bcolors.ENDC
                )
                return

            # qc_config = get_qc_config(
            #     qc_criteria_path, test_type, metadata.get("serialNumber")
            # )

            # Create an output DF
            data = qcDataFrame()
            SETUP_ID = qcframe.get_meta_data()["SETUP_ID"]
            data.add_property("SETUP_ID", SETUP_ID)
            TIM = qcframe.get_meta_data()["THERMAL_INTERFACE_MATERIAL"]
            data.add_property("TIM", TIM)
            POSITION = qcframe.get_meta_data()["POSITION"]
            data.add_property("POSITION", POSITION)
            data.add_property(
                "ANALYSIS_VERSION",
                __version__,
            )
            try:
                YARR_VERSION = qcframe.get_properties().get("YARR_VERSION")
                data.add_property(
                    "YARR_VERSION",
                    YARR_VERSION,
                )
            except Exception as e:
                log.warning(f"Unable to find YARR version! Require YARR >= v1.5.2. {e}")
                data.add_property("YARR_VERSION", "")
            MEASUREMENT_VERSION = qcframe.get_properties().get(
                test_type + "_MEASUREMENT_VERSION"
            )
            data.add_meta_data(
                "MEASUREMENT_VERSION",
                MEASUREMENT_VERSION,
            )
            time_start = qcframe.get_meta_data()["TimeStart"]
            time_end = qcframe.get_meta_data()["TimeEnd"]
            duration = arrow.get(time_end) - arrow.get(time_start)

            data.add_property(
                "MEASUREMENT_DATE",
                arrow.get(time_start).isoformat(timespec="milliseconds"),
            )
            data.add_property("MEASUREMENT_DURATION", int(duration.total_seconds()))

            data.add_meta_data("QC_LAYER", layer)
            data.add_meta_data("INSTITUTION", institution)
            data._meta_data.update(metadata)

            #   Calculate quanties
            # Vmux conversion is embedded.
            # def calculate(self):
            #     # Convert values from list to numpy array
            #     for key, value in self.df.items():
            #         self.df.update(
            #             {
            #                 key: {
            #                     "X": value["X"],
            #                     "Unit": value["Unit"],
            #                     "Values": np.array(value["Values"]),
            #                 }
            #             }
            #         )

            #         df_keys = self.df.copy().keys()

            #         # Calculate basic quantities
            #         for key in df_keys:
            #             newQuantity = self.getQuantity(key)
            #             if newQuantity:
            #                 self.df.update(newQuantity)

            # extractor = DataExtractor(inputDF, test_type)
            calculated_data = qcframe._data
            # calculated_data = extractor.calculate()

            T_NTC_MOD = np.mean(np.array(calculated_data["TExtExtNTC"]["Values"]))
            log.debug(f" T Ext Ext NTC: {T_NTC_MOD} C")

            T_CO2_IN = np.mean(
                np.array(calculated_data["TCoolingHead_CO2_In"]["Values"])
            )
            T_CO2_EX = np.mean(
                np.array(calculated_data["TCoolingHead_CO2_Ex"]["Values"])
            )
            V_MON = np.mean(np.array(calculated_data["ModuleVoltage"]["Values"]))
            I_MON = np.mean(np.array(calculated_data["ModuleCurrent"]["Values"]))

            resistance_cable = qcframe.get_meta_data()["resistance_cable"]
            resistance_pigtail = qcframe.get_meta_data()["resistance_pigtail"]
            V_MON = V_MON - (resistance_cable + resistance_pigtail) * I_MON

            round_value = 3

            data.add_parameter("T_CO2_IN", T_CO2_IN, round_value)
            data.add_parameter("T_CO2_EX", T_CO2_EX, round_value)
            data.add_parameter("V_MON", V_MON, round_value)
            data.add_parameter("I_MON", I_MON, round_value)

            data.add_parameter("POWER_CONSUMPTION", V_MON * I_MON, round_value)

            data.add_parameter("T_NTC_MOD", T_NTC_MOD, round_value)

            T_ref = (T_CO2_IN + T_CO2_EX) / 2.0
            TFM_MOD = calculate_TFM(I_MON, V_MON, T_NTC_MOD, T_ref)
            data.add_parameter("TFM_MOD", TFM_MOD, round_value)

            tmpresults = {}

            # for inputDF_FE in qcframe["FE"]:
            # inputDF_FEs = qcframe._property["FE"]
            inputDF_FEs = qcframe.get_properties().get("FE")
            for inputDF_FE in inputDF_FEs:
                FE_ID, V_INA_FE, V_IND_FE, I_INA_FE, I_IND_FE, T_NTC_FE = analyze_FE(
                    inputDF_FE
                )
                data.add_parameter(
                    f"V_IN_FE{FE_ID}",
                    (V_INA_FE * I_INA_FE + V_IND_FE * I_IND_FE) / (I_INA_FE + I_IND_FE),
                    round_value,
                )
                # data.add_parameter(f"V_INA_FE{FE_ID}", V_INA_FE, round_value)
                # data.add_parameter(f"V_IND_FE{FE_ID}", V_IND_FE, round_value)
                data.add_parameter(f"I_IN_FE{FE_ID}", I_INA_FE + I_IND_FE, round_value)
                # data.add_parameter(f"I_INA_FE{FE_ID}", I_INA_FE, round_value)
                # data.add_parameter(f"I_IND_FE{FE_ID}", I_IND_FE, round_value)
                data.add_parameter(f"T_NTC_FE{FE_ID}", T_NTC_FE, round_value)
                TFM_FE = calculate_TFM(I_MON, V_MON, T_NTC_FE, T_ref)
                data.add_parameter(f"TFM_FE{FE_ID}", TFM_FE, round_value)
                # Load values to dictionary for QC analysis
                tmpresults.update({"ChipNTC_vs_ExtExt": T_NTC_FE - T_NTC_MOD})

                log.debug(
                    f" There are results from {len(chipnames)} chip(s) stored in this file"
                )

        #  Output a json file
        outputDF = outputDataFrame()
        outputDF._serialNumber = serialNumber
        outputDF.set_test_type(test_type)

        # Perform QC analysis
        # passes_qc, summary, rounded_results = perform_qc_analysis(
        #     test_type,
        #     qc_config,
        #     layer,
        #     results.get(key),
        # )
        passes_qc = True

        # for result, value in rounded_results.items():
        #     if "_vs_" in result:
        #         continue  # Skip adding temperature differences
        #     df.add_parameter(result, value)
        outputDF.set_results(data)
        # print_result_summary(summary, test_type, output_dir, key)
        if passes_qc == -1:
            log.error(
                bcolors.ERROR
                + f" QC analysis for {serialNumber} was NOT successful. Please fix and re-run. Continuing to next chip.."
                + bcolors.ENDC
            )
            continue
        log.info("")
        if passes_qc:
            log.info(
                f" Module {serialNumber} passes QC? "
                + bcolors.OKGREEN
                + f"{passes_qc}"
                + bcolors.ENDC
            )
        else:
            log.info(
                f" Module {serialNumber} passes QC? "
                + bcolors.BADRED
                + f"{passes_qc}"
                + bcolors.ENDC
            )
        log.info("")

        outputDF.set_pass_flag(passes_qc)

        alloutput += [outputDF.to_dict(True)]
        timestamps += [meas_timestamp]

    # Only store results from same timestamp into same file
    dfs = np.array(alloutput)
    tss = np.array(timestamps)
    for x in np.unique(tss):
        outfile = output_dir.joinpath(f"{serialNumber}.json")
        log.info(f" Saving output of analysis to: {outfile}")
        save_dict_list(
            outfile,
            dfs[tss == x].tolist(),
        )


if __name__ == "__main__":
    typer.run(main)
