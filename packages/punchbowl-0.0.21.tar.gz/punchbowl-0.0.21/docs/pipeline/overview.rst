Pipeline Overview
==================

The PUNCH data processing pipeline is implemented in three primary numbered levels, with an additional processing level for QuickPUNCH data.
