Data Product Codes
====================

PUNCH data products are organized into data processing levels from Level 0 (raw camera data) to Level 3 (calibrated science data). Within and across levels distinct data products and calibration files are marked with a unique identifying product code. For data in the spacecraft frame, each spacecraft is marked with a unique numeral identity - 1,2,3 for each WFI, or 4 for NFI.

Data Product Codes
------------------

.. list-table::
   :header-rows: 1

   * - **Level**
     - **Code**
     - **Description**
   * - 0
     - PM1, PM2, PM3, PM4, PZ1, PZ2, PZ3, PZ4, PP1, PP2, PP3, PP4, CR1, CR2, CR3, CR4
     - Standard polarization (PM for -60 degree, PZ for 0 degree, PP for +60 degree polarization) and clear (CR) images
   * - 0
     - PX1, PX2, PX3, PX4
     - Science images in a nonstandard polarization state or when the filter wheel packet is stale
   * - 1
     - PM1, PM2, PM3, PM4, PZ1, PZ2, PZ3, PZ4, PP1, PP2, PP3, PP4, CR1, CR2, CR3, CR4
     - Standard polarization (PM for -60 degree, PZ for 0 degree, PP for +60 degree polarization) and clear (CR) images (photometrically calibrated)
   * - 2
     - PTM
     - Polarized science mosaics (Trefoil) in output coordinates, resolved into MZP polarization triplets, and uncertainty layer
   * - 2
     - CTM
     - Clear science mosaics (Trefoil) in output coordinates, resolved into image and uncertainty layer
   * - 2
     - PNN
     - Polarized NFI images in output coordinates, resolved into MZP polarization triplets, and uncertainty layer
   * - 2
     - CNN
     - Clear NFI images in output coordinates, resolved into image, and uncertainty layer
   * - Q
     - CNN
     - QuickPUNCH NFI images
   * - Q
     - CTM
     - QuickPUNCH Mosaic images (5.4–80 Rsun)
   * - L
     - CNN
     - Quicklook Clear NFI images
   * - L
     - PNN
     - Quicklook Polarized NFI images
   * - L
     - CTM
     - Quicklook Clear Mosaic images
   * - L
     - PTM
     - Quicklook Polarized Mosaic images
   * - 3
     - CAM
     - Clear low-noise science mosaic, bkg-sub & resolved into B & uncertainty layer
   * - 3
     - PAN
     - Polarized low-noise NFI science image, bkg-sub & resolved into B, pB, & uncertainty layer
   * - 3
     - CAN
     - Clear low-noise NFI science image, bkg-sub & resolved into B & uncertainty layer
   * - 3
     - PIM
     - Polarized science mosaics (trefoils), with F-corona subtraction, without starfield subtraction, and still in the MZP system
   * - 3
     - CIM
     - Clear science mosaics (trefoils), with F-corona subtraction and without starfield subtraction
   * - 3
     - PTM
     - Polarized K PUNCH science mosaics (Trefoil), bkg-sub & resolved into B, pB, & uncertainty layer
   * - 3
     - CTM
     - Clear K science mosaics (Trefoil), bkg-sub & resolved into B & uncertainty layer
   * - 3
     - PNN
     - Polarized K NFI science image, bkg-sub & resolved into B, pB, & uncertainty layer
   * - 3
     - CNN
     - Clear K NFI science image, bkg-sub & resolved into B & uncertainty layer
   * - 3
     - VAM
     - Mosaic derived wind velocity maps: 1440 pos. angles at various altitudes
   * - 3
     - PAM
     - Polarized low-noise science mosaic, bkg-sub & resolved into B, pB, & uncertainty layer


Calibration Product Codes
-------------------------

.. list-table::
   :header-rows: 1

   * - Level
     - Code
     - Description
   * - 0
     - DK1, DK2, DK3, DK4, DY1, DY2, DY3, DY4
     - Polarizer in dark position, used for calibration; stim lamp off (DK) or on (DY)
   * - 0
     - OV1, OV2, OV3, OV4
     - CCD over-scan images
   * - 0
     - XI1, XI2, XI3, XI4
     - Experimental image (no set parameters; variable crop)
   * - 1
     - BD1, BD2, BD3, BD4
     - Deficient pixel (boolean) map
   * - 1
     - DS1, DS2, DS3, DS4
     - Optical distortion models
   * - 1
     - FQ1, FQ2, FQ3, FQ4
     - Flat-field parameters (quartic polynomial coefficients), by pixel
   * - 1
     - GM1, GM2, GM3, GM4, GZ1, GZ2, GZ3, GZ4, GP1, GP2, GP3, GP4, GR1, GR2, GR3, GR4
     - Vignetting functions for the standard polarization (GM, GZ, GP) and clear (GR) states
   * - 1
     - LM1, LM2, LM3, LM4, LZ1, LZ2, LZ3, LZ4, LP1, LP2, LP3, LP4, LR1, LR2, LR3, LR4
     - Outlier limits used for image rejection, saved as NumPy format instead of FITS
   * - 1
     - MS1, MS2, MS3, MS4
     - Mask files to define where image is undefined for each satellite
   * - 1
     - QR1, QR2, QR3, QR4
     - Intermediate level-1 processing necessary for QuickPUNCH
   * - 1
     - SM1, SM2, SM3, SM4, SZ1, SZ2, SZ3, SZ4, SP1, SP2, SP3, SP4, SR1, SR2, SR3, SR4
     - Instrumental additive stray light model for the standard polarization (SM, SZ, SP) and clear (SR) states
   * - 1
     - TM1, TM2, TM3, TM4, TZ1, TZ2, TZ3, TZ4, TP1, TP2, TP3, TP4, TR1, TR2, TR3, TR4
     - Dynamic instrumental additive stray light model for the standard polarization (TM, TZ, TP) and clear (TR) states
   * - 1
     - XM1, XM2, XM3, XM4, XZ1, XZ2, XZ3, XZ4, XP1, XP2, XP3, XP4, XR1, XR2, XR3, XR4
     - Result of the "L1 early" pipeline stage, an input to dynamic stray light model generation.
   * - 1
     - YM1, YM2, YM3, YM4, YZ1, YZ2, YZ3, YZ4, YP1, YP2, YP3, YP4, YR1, YR2, YR3, YR4
     - Result of the "L1 middle" pipeline stage, an input to static stray light model generation.
   * - 1
     - RM1, RM2, RM3, RM4, RZ1, RZ2, RZ3, RZ4, RP1, RP2, RP3, RP4, RC1, RC2, RC3, RC4
     - Point Spread Function (PSF) model for the standard polarization and clear states
   * - Q
     - CFN
     - QuickPUNCH NFI images F corona model
   * - Q
     - CFM
     - QuickPUNCH Mosaic images (5.4–80 Rsun) F corona model
   * - 3
     - PFM
     - Polarized mosaic F corona model, resolved into MZP pol. triplets, and uncertainty layer
   * - 3
     - CFM
     - Clear mosaic F corona model, resolved into image and uncertainty layer
   * - 3
     - PFN
     - Polarized NFI F-corona model, resolved into MZP pol. triplets, and uncertainty layer
   * - 3
     - CFN
     - Clear NFI F-corona model, resolved into image and uncertainty layer
   * - 3
     - PSM
     - Polarized mosaic stellar model, resolved into MZP pol. triplets, and uncertainty layer
   * - 3
     - CSM
     - Clear mosaic stellar model, resolved into image and uncertainty layer
   * - 3
     - PSN
     - Polarized NFI stellar model, resolved into MZP pol. triplets, and uncertainty layer
   * - 3
     - CSN
     - Clear NFI stellar model, resolved into image and uncertainty layer
