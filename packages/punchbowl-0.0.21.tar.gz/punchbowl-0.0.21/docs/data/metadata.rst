Metadata Description
====================

Each PUNCH FITS file contains metadata in the form of a FITS-compliant header, describing the accompanying data observation.

Header keywords
---------------

.. csv-table::
   :header-rows: 1
   :file: omniheader_select.csv
