Automation
==========

This section is about what we used to call "punchpipe."
It's how the SOC automates file generation on their servers.
It's not necessary to understand the science calibration.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   control/index
   levels/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
