"""
This subpackage includes what used to be called 'punchpipe.' It's the automation segment for punchbowl. It handles
scheduling all the file creation for the SOC on their servers. It is not needed to run the other parts of punchbowl and
no other parts of punchbowl should rely on it. The average scientist will not need to use it.
"""
