"""Tests for sardis-compliance package."""
