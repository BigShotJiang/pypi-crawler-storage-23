"""Wafer Wevin CLI - thin wrapper that calls rollouts in-process.
Adds:
- Wafer auth (proxy token from ~/.wafer/credentials.json)
- Wafer templates (default)
"""
from __future__ import annotations

import json
import logging
import os
import sys
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from wafer.cli.agent_config import AgentConfig
    from wafer.core.rollouts import Endpoint, Environment
    from wafer.core.rollouts.dtypes import AgentSession, StreamEvent, ToolCall, Trajectory
    from wafer.core.rollouts.store import FileSessionStore


_DEFAULT_MAX_TURNS = 50


class StreamingChunkFrontend:
    """Frontend that emits real-time JSON chunk events.
    Designed for programmatic consumption by extensions/UIs.
    Emits events in the format expected by wevin-extension handleWevinEvent:
    - {type: 'session_start', session_id: '...', model: '...'}
    - {type: 'text_delta', delta: '...'}
    - {type: 'tool_call_start', tool_name: '...'}
    - {type: 'tool_call_end', tool_name: '...', args: {...}}
    - {type: 'tool_result', is_error: bool}
    - {type: 'score', reward: float, ...}
    - {type: 'session_end'}
    - {type: 'error', error: '...'}
    """

    _EVAL_RESULT_PREFIX = "EVAL_RESULT_JSON:"

    def __init__(self, session_id: str | None = None, model: str | None = None) -> None:
        self._current_tool_call: dict | None = None
        self._session_id = session_id
        self._model = model
        self._stopped = False
        self._session_start_emitted = False
        self._num_turns: int = 0

    def _emit(self, obj: dict) -> None:
        """Emit a single NDJSON line."""
        print(json.dumps(obj, ensure_ascii=False), flush=True)

    def _maybe_emit_score(self, event: object) -> None:
        """Extract and emit score from ToolResultReceived if it contains metrics."""
        details = getattr(event, "details", None)
        if details and "metrics" in details:
            metrics = details["metrics"]
            weighted = [(m["value"], m.get("weight", 0.0)) for m in metrics if m.get("weight", 0.0) > 0]
            reward = sum(v * w for v, w in weighted) / sum(w for _, w in weighted) if weighted else 0.0
            self._emit({"type": "score", "reward": reward, "metrics": metrics, "turn": self._num_turns})
            return
        content = getattr(event, "content", None)
        if not isinstance(content, str):
            return
        for line in content.splitlines():
            if not line.startswith(self._EVAL_RESULT_PREFIX):
                continue
            try:
                data = json.loads(line[len(self._EVAL_RESULT_PREFIX):])
                metrics = data.get("metrics", [])
                weighted = [(m["value"], m.get("weight", 0.0)) for m in metrics if m.get("weight", 0.0) > 0]
                reward = sum(v * w for v, w in weighted) / sum(w for _, w in weighted) if weighted else 0.0
                self._emit({"type": "score", "reward": reward, "metrics": metrics, "turn": self._num_turns})
            except (json.JSONDecodeError, ValueError, KeyError):
                pass

    async def start(self) -> None:
        """Initialize frontend and emit session_start if session_id is known."""
        if self._session_id:
            self._emit({
                "type": "session_start",
                "session_id": self._session_id,
                "model": self._model,
            })
            self._session_start_emitted = True

    def emit_session_start(self, session_id: str, model: str | None = None) -> None:
        """Emit session_start event (for new sessions created during run)."""
        if self._session_start_emitted:
            return
        self._emit({
            "type": "session_start",
            "session_id": session_id,
            "model": model if model else self._model,
        })
        self._session_start_emitted = True

    def finalize(self, session_id: str | None = None) -> None:
        """Emit session_start (if needed) and session_end in correct order."""
        if session_id and not self._session_start_emitted:
            self.emit_session_start(session_id)
        self._emit({"type": "session_end"})

    async def stop(self) -> None:
        """Mark session as stopped. session_end is emitted by finalize()."""
        self._stopped = True

    async def handle_event(self, event: StreamEvent) -> None:
        """Handle streaming event by emitting JSON."""
        from wafer.core.rollouts.dtypes import (
            StreamDone,
            StreamError,
            TextDelta,
            ThinkingDelta,
            ToolCallEnd,
            ToolCallStart,
            ToolResultDelta,
            ToolResultReceived,
        )
        if isinstance(event, TextDelta):
            # Emit text delta immediately for real-time streaming
            self._emit({"type": "text_delta", "delta": event.delta})
        elif isinstance(event, ThinkingDelta):

            pass
        elif isinstance(event, ToolCallStart):
            self._current_tool_call = {
                "id": event.tool_call_id,
                "name": event.tool_name,
            }
            self._emit({
                "type": "tool_call_start",
                "tool_name": event.tool_name,
            })
        elif isinstance(event, ToolCallEnd):
            tool_call = event.tool_call
            self._emit({
                "type": "tool_call_end",
                "tool_name": tool_call.name,
                "args": tool_call.args if tool_call.args else {},
            })
            self._num_turns += 1
        elif isinstance(event, ToolResultReceived):
            result_event: dict[str, object] = {"type": "tool_result", "is_error": event.is_error}
            if event.error:
                result_event["error"] = event.error
            if event.content:
                if isinstance(event.content, list):
                    result_event["content"] = "\n".join(
                        str(item) if not isinstance(item, dict) else item.get("text", str(item))
                        for item in event.content
                    )
                else:
                    result_event["content"] = str(event.content)
            self._emit(result_event)
            self._maybe_emit_score(event)
        elif isinstance(event, ToolResultDelta):
            self._emit({
                "type": "tool_result_delta",
                "tool_call_id": event.tool_call_id,
                "delta": event.delta,
            })
        elif isinstance(event, StreamDone):
            # Will be handled by stop()
            pass
        elif isinstance(event, StreamError):
            self._emit({"type": "error", "error": str(event.error)})

    async def get_input(self, prompt: str = "") -> str:
        """Get user input - not supported in JSON mode."""
        raise RuntimeError(
            "StreamingChunkFrontend does not support interactive input. "
            "Use -p to provide input or use a single-turn template (e.g. trace-analyze)."
        )

    async def confirm_tool(self, tool_call: ToolCall) -> bool:
        """Auto-approve all tools in JSON mode."""
        return True

    def show_loader(self, text: str) -> None:
        """No-op for JSON mode."""
        pass

    def hide_loader(self) -> None:
        """No-op for JSON mode."""
        pass


def _make_wafer_token_refresh() -> Callable[[], Awaitable[str | None]]:
    from .auth import load_credentials, refresh_access_token, save_credentials

    async def _refresh() -> str | None:
        creds = load_credentials()
        if not creds or not creds.refresh_token:
            return None
        try:
            new_access, new_refresh = refresh_access_token(creds.refresh_token)
            save_credentials(new_access, new_refresh, creds.email)
            return new_access
        except Exception as exc:
            logging.getLogger(__name__).warning("wafer token refresh failed: %s", exc)
            return None
    return _refresh


def _track_auth_failure(error_type: str, *, had_credentials: bool, source: str) -> None:
    assert error_type, "error_type must not be empty"
    assert source, "source must not be empty"
    from .analytics import track_event
    track_event("cli_auth_failure", {
        "error_type": error_type,
        "had_credentials": had_credentials,
        "source": source,
    })


def _resolve_wafer_token() -> tuple[str, str | None, bool, bool]:
    from .auth import get_valid_token, load_credentials
    wafer_token = os.environ.get("WAFER_AUTH_TOKEN", "")
    token_source = "WAFER_AUTH_TOKEN" if wafer_token else None
    had_credentials = False
    uses_credentials_file = False
    if not wafer_token:
        try:
            creds = load_credentials()
            had_credentials = creds is not None and bool(creds.access_token)
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            pass
        wafer_token = get_valid_token()
        if wafer_token:
            token_source = "~/.wafer/credentials.json"
            uses_credentials_file = True
    return wafer_token, token_source, had_credentials, uses_credentials_file


def _get_wafer_auth(
) -> tuple[str | None, str | None, Callable[[], Awaitable[str | None]] | None]:
    from .global_config import get_api_url
    wafer_token, token_source, had_credentials, uses_credentials_file = _resolve_wafer_token()
    if wafer_token:
        api_url = get_api_url()
        refresh = _make_wafer_token_refresh() if uses_credentials_file else None
        return f"{api_url}/v1/anthropic", wafer_token, refresh
    if had_credentials:
        print(
            "Error: Wafer credentials expired and refresh failed.\n"
            "  Run 'wafer login' to re-authenticate.\n",
            file=sys.stderr,
        )
        _track_auth_failure("credentials_expired_refresh_failed", had_credentials=True, source="proxy")
    else:
        print("Error: No API credentials found", file=sys.stderr)
        print("  Run 'wafer login' to authenticate.\n", file=sys.stderr)
        _track_auth_failure("no_credentials", had_credentials=False, source="proxy")
    return None, None, None


def _get_session_preview(session: AgentSession) -> str:
    assert session is not None, "session must not be None"
    assert hasattr(session, "messages"), "session must have messages attribute"
    messages = getattr(session, "messages", None)
    if not messages:
        return ""
    for msg in messages:
        if msg.role == "user" and isinstance(msg.content, str):
            preview = msg.content[:50].replace("\n", " ")
            if len(msg.content) > 50:
                preview += "..."
            return preview
    return ""


def _get_log_file_path() -> Path:
    assert Path.home().exists(), "home directory must exist"
    assert Path.home().is_dir(), "home path must be a directory"
    log_dir = Path.home() / ".wafer" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    return log_dir / "wevin_debug.log"


def _setup_logging(verbose_env: bool = False) -> None:
    assert isinstance(verbose_env, bool), "verbose_env must be a bool"
    import logging.config
    log_file = _get_log_file_path()
    handlers: dict = {
        "file": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": str(log_file),
            "maxBytes": 10_000_000,
            "backupCount": 3,
            "formatter": "json",
            "level": "DEBUG",
        },
    }
    if verbose_env:
        handlers["stderr"] = {
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stderr",
            "formatter": "brief",
            "level": "INFO",
        }
    wafer_handler_list = ["file", "stderr"] if verbose_env else ["file"]
    logging.config.dictConfig({
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "json": {
                "format": '{"ts": "%(asctime)s", "level": "%(levelname)s", "logger": "%(name)s", "msg": "%(message)s"}',
            },
            "brief": {
                "format": "%(asctime)s %(levelname)-5s %(name)s: %(message)s",
                "datefmt": "%H:%M:%S",
            },
        },
        "handlers": handlers,
        "loggers": {
            # wafer loggers: DEBUG to file, INFO+ to stderr when verbose
            "wafer": {"level": "DEBUG", "handlers": wafer_handler_list, "propagate": False},
            # Suppress noisy third-party loggers
            "hpack": {"level": "WARNING"},
            "grpclib": {"level": "WARNING"},
            "modal": {"level": "INFO"},
        },
        "root": {"level": "WARNING", "handlers": ["file"]},
    })


def _unwrap_exception(e: BaseException) -> BaseException:
    assert e is not None, "exception must not be None"
    assert isinstance(e, BaseException), "e must be a BaseException"
    actual = e
    while isinstance(actual, ExceptionGroup) and actual.exceptions:
        actual = actual.exceptions[0]
    return actual


def _build_endpoint(
    config: AgentConfig,
    api_base: str,
    api_key: str,
    api_key_refresh: Callable[[], Awaitable[str | None]] | None = None,
) -> Endpoint:
    assert config is not None, "agent config must not be None"
    assert api_base, "api_base must not be empty"
    from wafer.core.rollouts import Endpoint
    provider, model_id = config.model.split("/", 1)
    thinking_config = (
        {"type": "enabled", "budget_tokens": config.thinking_budget_tokens}
        if config.thinking_enabled else None
    )
    ctx_mgmt_cfg = config.context_management
    context_management = None
    if provider == "anthropic":
        supports_compaction = model_id in ("claude-opus-4-6", "claude-sonnet-4-6")
        edits: list[dict[str, Any]] = []
        if config.thinking_enabled:
            edits.append({
                "type": "clear_thinking_20251015",
                "keep": {"type": "thinking_turns", "value": ctx_mgmt_cfg.thinking_turns_keep},
            })
        edits.append({
            "type": "clear_tool_uses_20250919",
            "trigger": {"type": "input_tokens", "value": ctx_mgmt_cfg.tool_uses_trigger_tokens},
            "keep": {"type": "tool_uses", "value": ctx_mgmt_cfg.tool_uses_keep},
            "clear_at_least": {"type": "input_tokens", "value": ctx_mgmt_cfg.tool_uses_clear_at_least_tokens},
        })
        if supports_compaction:
            edits.append({
                "type": "compact_20260112",
                "trigger": {"type": "input_tokens", "value": ctx_mgmt_cfg.compact_trigger_tokens},
                "pause_after_compaction": ctx_mgmt_cfg.pause_after_compaction,
            })
        context_management = {"edits": edits}
    endpoint_kwargs: dict[str, Any] = {
        "provider": provider,
        "model": model_id,
        "api_base": api_base,
        "api_key": api_key,
        "api_key_refresh": api_key_refresh,
        "thinking": thinking_config,
        "max_tokens": config.max_tokens,
        "max_completion_tokens": config.max_completion_tokens,
        "reasoning_effort": config.reasoning_effort,
        "context_management": context_management,
    }
    if config.temperature is not None:
        endpoint_kwargs["temperature"] = config.temperature
    return Endpoint(**endpoint_kwargs)


def _build_environment(
    config: AgentConfig,
    tools_override: list[str] | None,
    has_target: bool = False,
    template_args: dict[str, str] | None = None,
) -> Environment:
    assert config is not None, "agent config must not be None"
    dir_arg = (template_args or {}).get("dir")
    if dir_arg:
        working_dir = Path(dir_arg).resolve()
    else:
        working_dir = Path.cwd()
    resolved_tools = list(tools_override or config.tools)
    from wafer.core.environments.wafer_ai import WaferAiEnvironment
    from wafer.core.rollouts.templates import DANGEROUS_BASH_COMMANDS
    if config.include_skills and "skill" not in resolved_tools:
        resolved_tools = list(resolved_tools) + ["skill"]
    denylist = config.bash_denylist if config.bash_denylist is not None else DANGEROUS_BASH_COMMANDS
    allowed_paths = [Path(p) for p in config.volumes.values()] if config.volumes else None
    env = WaferAiEnvironment(
        working_dir=working_dir,
        allowed_paths=allowed_paths,
        enabled_tools=resolved_tools,
        bash_allowlist=config.bash_allowlist,
        bash_denylist=denylist,
        confirm_tools=config.confirm_tools,
    )  # type: ignore[assignment]
    return env


def _resolve_session_id(resume: str | None, session_store: FileSessionStore) -> str | None:
    assert session_store is not None, "session_store must not be None"
    assert isinstance(resume, (str, type(None))), "resume must be a string or None"
    if not resume:
        return None
    session_id = resume if resume != "last" else session_store.get_latest_id_sync()  # type: ignore[union-attr]
    if not session_id:
        print("Error: No session to resume", file=sys.stderr)
        sys.exit(1)
    return session_id


def _get_default_template() -> AgentConfig:
    """Load default template from bundled TOML (default.toml)."""
    from wafer.core.rollouts.templates import load_template

    return load_template("default")


def _load_template(
    template_name: str, template_args: dict[str, str] | None = None
) -> tuple[AgentConfig | None, str | None]:
    assert template_name, "template_name must not be empty"
    assert isinstance(template_name, str), "template_name must be a string"
    try:
        from pathlib import Path

        path = Path(template_name)
        if path.suffix == ".toml" and path.exists():
            from wafer.cli.agent_config import load_agent_config
            config = load_agent_config(path)
        else:
            from wafer.core.rollouts.templates import load_template
            config = load_template(template_name)
        _ = config.interpolate_prompt(template_args or {})
        return config, None
    except Exception as e:
        return None, str(e)


def _handle_get_session(
    get_session: str, json_output: bool, session_store: FileSessionStore
) -> None:
    assert get_session, "get_session must not be empty"
    assert session_store is not None, "session_store must not be None"
    from dataclasses import asdict

    import trio

    async def _get_session() -> None:
        try:
            session, err = await session_store.get(get_session)  # type: ignore[union-attr]
            if err or not session:
                _print_error(err or f"Session {get_session} not found", json_output)
                sys.exit(1)
            if json_output:
                _print_session_json(session, asdict)
            else:
                _print_session_text(session)
        except KeyboardInterrupt:
            sys.exit(130)
        except Exception as e:
            _print_error(f"Failed to load session {get_session}: {e}", json_output)
            sys.exit(1)
    try:
        trio.run(_get_session)
    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as e:
        _print_error(f"Failed to run session loader: {e}", json_output)
        sys.exit(1)


def _print_error(msg: str, json_output: bool) -> None:
    assert isinstance(msg, str), "msg must be a string"
    assert isinstance(json_output, bool), "json_output must be a bool"
    if json_output:
        from .output import json_error
        print(json_error(msg))
    else:
        print(f"Error: {msg}", file=sys.stderr)


def _print_session_json(session: AgentSession, asdict: Callable[..., dict[str, Any]]) -> None:
    assert session is not None, "session must not be None"
    assert callable(asdict), "asdict must be callable"
    try:
        messages_data = [asdict(msg) for msg in session.messages]
    except Exception as e:
        from .output import json_error
        print(json_error(f"Failed to serialize messages: {e}"))
        sys.exit(1)
    from .output import json_response
    print(
        json_response(data={
            "session_id": session.session_id,
            "status": session.status.value,
            "model": session.endpoint.model if session.endpoint else None,
            "created_at": session.created_at,
            "updated_at": session.updated_at,
            "messages": messages_data,
            "tags": session.tags,
        })
    )


def _extract_text_content(content: object) -> str:
    """Extract displayable text from a message content field."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
            elif hasattr(block, "type") and getattr(block, "type", None) == "text":
                parts.append(getattr(block, "text", ""))
        return " ".join(parts) if parts else "(tool calls only)"
    return str(content) if content else ""


def _print_session_text(session: AgentSession) -> None:
    assert session is not None, "session must not be None"
    assert hasattr(session, "session_id"), "session must have session_id"
    print(f"Session: {session.session_id}")
    print(f"Status:  {session.status.value}")
    print(f"Model:   {session.endpoint.model if session.endpoint else 'unknown'}")
    print(f"Messages: {len(session.messages)}")
    for i, msg in enumerate(session.messages):
        text = _extract_text_content(msg.content)[:100]
        print(f"  [{i}] {msg.role}: {text}")


def _handle_list_sessions(json_output: bool, session_store: FileSessionStore) -> None:
    assert isinstance(json_output, bool), "json_output must be a bool"
    assert session_store is not None, "session_store must not be None"
    sessions = session_store.list_sync(limit=50)  # type: ignore[union-attr]
    if json_output:
        sessions_data = []
        for s in sessions:
            sessions_data.append({
                "session_id": s.session_id,
                "status": s.status.value,
                "model": s.endpoint.model if s.endpoint else None,
                "created_at": s.created_at if hasattr(s, "created_at") else None,
                "updated_at": s.updated_at if hasattr(s, "updated_at") else None,
                "message_count": len(s.messages),
                "preview": _get_session_preview(s),
            })
        from .output import json_response
        print(json_response(data={"sessions": sessions_data}))
    else:
        if not sessions:
            print("No sessions found.")
        else:
            print(f"  {'ID':<36s}  {'STATUS':12s}  {'MODEL':30s}  PROMPT")
            print(f"  {'─' * 36}  {'─' * 12}  {'─' * 30}  {'─' * 40}")
            for s in sessions:
                sid = s.session_id
                status = s.status.value
                model = (s.endpoint.model if s.endpoint else "unknown")[:30]
                preview = _get_session_preview(s)[:60]
                print(f"  {sid:<36s}  {status:12s}  {model:30s}  {preview}")


def _setup_wafer_env_vars() -> None:
    assert os.environ is not None, "os.environ must be available"
    from .global_config import get_api_url
    if "WAFER_API_URL" not in os.environ:
        os.environ["WAFER_API_URL"] = get_api_url()
    if "WAFER_AUTH_TOKEN" not in os.environ:
        from .auth import get_valid_token
        _token = get_valid_token()
        if _token:
            os.environ["WAFER_AUTH_TOKEN"] = _token


def _load_and_validate_template(
    template: str,
    template_args: dict[str, str] | None,
    prompt: str | None,
) -> AgentConfig:
    assert template, "template name must not be empty"
    assert isinstance(template, str), "template must be a string"
    loaded_template, err = _load_template(template, template_args)
    if err or loaded_template is None:
        from wafer.cli.agent_config import list_bundled_templates

        print(f"Error: Template not found: {template}", file=sys.stderr)
        print(f"  Detail: {err}", file=sys.stderr)
        available = list_bundled_templates()
        if available:
            print(f"  Available templates: {', '.join(available)}", file=sys.stderr)
        sys.exit(1)
    if not prompt and loaded_template.description:
        print(f"Template: {loaded_template.name}", file=sys.stderr)
        print(f"  {loaded_template.description}", file=sys.stderr)
        print(file=sys.stderr)
    return loaded_template



def _build_run_environment(
    config: AgentConfig,
    template_args: dict[str, str] | None,
    _agent_logger: logging.Logger,
) -> Environment:
    assert config is not None, "agent config must not be None"
    assert _agent_logger is not None, "_agent_logger must not be None"
    return _build_environment(
        config, None, has_target=False, template_args=template_args,
    )


def _execute_with_trio(run: Callable[[], Awaitable[None]]) -> None:
    assert callable(run), "run must be callable"
    import trio
    import trio_asyncio

    async def _with_asyncio_bridge() -> None:
        async with trio_asyncio.open_loop():
            await run()

    try:
        trio.run(_with_asyncio_bridge)
    except KeyboardInterrupt:
        pass
    except BaseExceptionGroup as eg:
        actual = _unwrap_exception(eg)
        if isinstance(actual, SystemExit):
            sys.exit(actual.code)
        raise


async def _init_trajectory(
    session_id: str | None,
    session_store: FileSessionStore,
    system_prompt: str,
) -> Trajectory:
    assert session_store is not None, "session_store must not be None"
    assert isinstance(system_prompt, str), "system_prompt must be a string"
    from wafer.core.rollouts import Message, Trajectory
    if session_id:
        existing_session, err = await session_store.get(session_id)  # type: ignore[union-attr]
        if err:
            print(f"Error loading session: {err}", file=sys.stderr)
            sys.exit(1)
        assert existing_session is not None
        return Trajectory(messages=existing_session.messages)
    return Trajectory(messages=[Message(role="system", content=system_prompt)])


async def _run_noninteractive(  # noqa: PLR0913
    trajectory: Trajectory,
    endpoint: Endpoint,
    environment: Environment,
    session_store: FileSessionStore,
    session_id: str | None,
    prompt: str | None,
    json_output: bool,
    output_format: str | None,
    resolved_single_turn: bool,
    _agent_logger: logging.Logger,
    max_turns: int = 50,
) -> None:
    assert trajectory is not None, "trajectory must not be None"
    assert endpoint is not None, "endpoint must not be None"
    from wafer.core.rollouts.agent_session import AgentSessionConfig, run_agent_session
    from wafer.core.rollouts.frontends import NoneFrontend

    if output_format == "stream-json":
        from wafer.core.rollouts.frontends.json_frontend import JsonFrontend
        frontend = JsonFrontend(include_thinking=False, include_timing=True)
    elif json_output:
        model_name = endpoint.model if hasattr(endpoint, "model") else None
        frontend = StreamingChunkFrontend(session_id=session_id, model=model_name)
    else:
        frontend = NoneFrontend(show_tool_calls=True, show_thinking=False)

    system_prompt = trajectory.messages[0].content if trajectory.messages else ""
    assert isinstance(system_prompt, str), "system_prompt must be a string"

    session_config = AgentSessionConfig(
        prompt=prompt or "",
        system_prompt=system_prompt,
        endpoint=endpoint,
        environment=environment,
        frontend=frontend,
        session_store=session_store,
        session_id=session_id,
        single_turn=resolved_single_turn,
        max_turns=max_turns,
    )

    _agent_logger.info(
        "Starting run_agent_session (single_turn=%s, prompt=%s)",
        resolved_single_turn,
        bool(prompt),
    )
    result = await run_agent_session(session_config)
    _agent_logger.info("run_agent_session completed (%d states)", len(result.states))

    result_session_id = result.session_id or (
        result.states[0].session_id if result.states and result.states[0].session_id else None
    )

    if isinstance(frontend, StreamingChunkFrontend):
        frontend.finalize(session_id=result_session_id)

    if result_session_id:
        print(f"\nResume with: wafer agent --resume {result_session_id}", file=sys.stderr)


def _resolve_template(
    template: str | None,
    template_args: dict[str, str] | None,
    prompt: str | None,
    json_output: bool,
    file_config: AgentConfig | None = None,
) -> AgentConfig:
    assert isinstance(json_output, bool), "json_output must be a bool"
    assert isinstance(template, (str, type(None))), "template must be a string or None"
    if template:
        loaded_template, err = _load_template(template, template_args)
        if loaded_template is None:
            _load_and_validate_template(template, template_args, prompt)
            raise AssertionError("unreachable")
        return loaded_template
    return _get_default_template()


def _init_auth_and_env(
) -> tuple[str, str, Callable[[], Awaitable[str | None]] | None]:
    _setup_logging(verbose_env=False)
    api_base, api_key, api_key_refresh = _get_wafer_auth()
    if not api_base or not api_key:
        sys.exit(1)
    assert api_base is not None
    assert api_key is not None
    _setup_wafer_env_vars()
    return api_base, api_key, api_key_refresh


async def _run_agent_loop(  # noqa: PLR0913
    environment: Environment,
    session_id: str | None,
    session_store: FileSessionStore,
    system_prompt: str,
    interactive: bool,
    endpoint: Endpoint,
    prompt: str | None,
    json_output: bool,
    output_format: str | None,
    resolved_single_turn: bool,
    _agent_logger: logging.Logger,
    max_turns: int = 50,
) -> None:
    assert environment is not None, "environment must not be None"
    assert endpoint is not None, "endpoint must not be None"
    if hasattr(environment, "setup"):
        await environment.setup()
    trajectory = await _init_trajectory(session_id, session_store, system_prompt)
    try:
        if interactive:
            from wafer.core.rollouts.frontends.tui.interactive_agent import (
                run_interactive_agent,
            )
            await run_interactive_agent(
                trajectory, endpoint, environment, session_store,
                session_id, theme_name="minimal", debug=False,
                debug_layout=False, initial_prompt=prompt,
            )
        else:
            await _run_noninteractive(
                trajectory, endpoint, environment, session_store,
                session_id, prompt, json_output, output_format,
                resolved_single_turn, _agent_logger, max_turns=max_turns,
            )
    except KeyboardInterrupt:
        pass
    except BaseException as e:
        actual_error = _unwrap_exception(e)
        print(f"\n{type(actual_error).__name__}: {actual_error}", file=sys.stderr)
        sys.exit(1)


def main(  # noqa: PLR0913
    prompt: str | None = None,
    interactive: bool = False,
    resume: str | None = None,
    template: str | None = None,
    template_args: dict[str, str] | None = None,
    list_sessions: bool = False,
    get_session: str | None = None,
    json_output: bool = False,
    output_format: str | None = None,
    single_turn_override: bool | None = None,
    file_config: AgentConfig | None = None,
) -> None:
    """Run wevin agent in-process via rollouts."""
    from wafer.core.rollouts import FileSessionStore
    session_store = FileSessionStore()
    if get_session:
        _handle_get_session(get_session, json_output, session_store)
        return
    if list_sessions:
        _handle_list_sessions(json_output, session_store)
        return
    structured_output = json_output or output_format == "stream-json"
    if structured_output:
        print(json.dumps({"type": "initializing"}), flush=True)
    _agent_logger = logging.getLogger("wafer.agent")
    api_base, api_key, api_key_refresh = _init_auth_and_env()

    config = _resolve_template(template, template_args, prompt, structured_output, file_config=file_config)
    if file_config is not None:
        config = config.with_overrides(file_config.to_dict())
    config = config.interpolate_prompt(template_args)

    resolved_single_turn = (
        single_turn_override if single_turn_override is not None
        else (True if structured_output else config.single_turn)
    )
    if not sys.stdin.isatty():
        resolved_single_turn = True
    endpoint = _build_endpoint(config, api_base, api_key, api_key_refresh)
    environment = _build_run_environment(config, template_args, _agent_logger)

    ctx = config.context
    prompt_working_dir = (
        getattr(environment, "working_dir", Path.cwd()) if ctx.working_dir else None
    )

    target_lines: list[str] | None = None
    default_target: str | None = None
    if ctx.targets:
        try:
            from wafer.cli.targets import get_default_target, get_target_info, list_targets, load_target
            target_names = list_targets()
            default_target = get_default_target()
            if target_names:
                collected: list[str] = []
                ssh_types = {"Baremetal", "VM"}
                for name in target_names:
                    try:
                        target_obj = load_target(name)
                        info = get_target_info(target_obj)
                        marker = " (default)" if name == default_target else ""
                        target_type = info.get("Type", "unknown")
                        exec_mode = "ssh/sandbox" if target_type in ssh_types else "workspace/sync"
                        collected.append(f"- `{name}`{marker}: {info['GPU']}, {target_type}, {exec_mode}")
                    except (ImportError, FileNotFoundError, OSError, AttributeError):
                        pass
                if collected:
                    target_lines = collected
        except (ImportError, FileNotFoundError, OSError, AttributeError):
            pass

    sandbox_lines: list[str] | None = None
    if ctx.sandboxes:
        try:
            from wafer.cli.sandboxes_api import db_list_active_sandboxes
            active_sandboxes = db_list_active_sandboxes()
            if active_sandboxes:
                from datetime import datetime, timezone
                collected_sb: list[str] = []
                now = datetime.now(timezone.utc)
                for s in active_sandboxes:
                    expires = datetime.fromisoformat(s["expires_at"].replace("Z", "+00:00"))
                    ttl_hours = max(0, (expires - now).total_seconds() / 3600)
                    ttl_label = f"{ttl_hours:.1f}h" if ttl_hours >= 1 else f"{int(ttl_hours * 60)}m"
                    collected_sb.append(
                        f"- `{s['id']}` on `{s['target_name']}`: expires in {ttl_label}"
                    )
                if collected_sb:
                    sandbox_lines = collected_sb
        except (ImportError, FileNotFoundError, OSError, AttributeError):
            pass

    system_prompt = config.build_full_prompt(
        working_dir=prompt_working_dir,
        targets=target_lines,
        default_target=default_target,
        sandboxes=sandbox_lines,
    )
    session_store = FileSessionStore()
    session_id = _resolve_session_id(resume, session_store)

    max_turns = config.max_turns if config.max_turns is not None else _DEFAULT_MAX_TURNS

    async def run() -> None:
        await _run_agent_loop(
            environment, session_id, session_store, system_prompt,
            interactive, endpoint, prompt, json_output,
            output_format, resolved_single_turn, _agent_logger,
            max_turns=max_turns,
        )

    _execute_with_trio(run)
