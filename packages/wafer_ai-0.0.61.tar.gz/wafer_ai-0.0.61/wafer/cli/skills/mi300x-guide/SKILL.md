---
name: mi300x-guide
description: AMD MI300X (CDNA3 gfx942) optimization guide. Sandbox commands, HIP vs CUDA differences, profiling.
---

# AMD MI300X (CDNA3) — HIP Optimization Guide

## Hardware Specs

- Architecture: CDNA3 (gfx942)
- Compute Units: 304
- Memory: 192GB HBM3, ~5.3 TB/s bandwidth
- Target name: `mi300x`

## Sandbox Commands

```bash
# Score your solution: use the eval_task tool (see your instruction for the URL).
# Do NOT run task.py directly — it is not in your workspace during evals.

# Run any command with local file sync
wafer sandbox run --target mi300x --sync . -- <command>

# Profile with rocprof-compute (sync first so binary is on remote)
wafer sandbox run --target mi300x --sync . -- rocprof-compute profile <binary>

# Check GPU status (no sync needed)
wafer sandbox run --target mi300x -- rocm-smi
```

## Building HIP Extensions with torch.utils.cpp_extension.load

Use this proven working pattern for compiling HIP kernels with PyTorch on MI300X:

```python
import os
from filelock import FileLock
from torch.utils.cpp_extension import load

# Required env vars — MUST be set before calling load()
os.environ.update({
    "CXX": "/opt/rocm-7.0.0/bin/hipcc",
    "PYTORCH_ROCM_ARCH": "gfx942",
})

HIP_SRC = r"""
#include <torch/extension.h>
#include <hip/hip_runtime.h>
#include <hip/hip_fp16.h>
#include <ATen/hip/HIPContext.h>

// Your HIP kernel here
__global__ void my_kernel(...) { ... }

// Wrapper function
torch::Tensor my_op(torch::Tensor input) {
    // launch kernel
    hipStream_t stream = at::hip::getCurrentHIPStream();
    hipLaunchKernelGGL(my_kernel, grid, block, 0, stream,
        input.data_ptr<float>(), ...
    );
    return output;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("my_op", &my_op, "My HIP operation");
}
"""

# Write source to file (required — do NOT use load_inline on MI300X)
with open("my_kernel.cu", "w") as f:
    f.write(HIP_SRC)

# Build with FileLock to prevent race conditions
with FileLock("build.lock"):
    os.makedirs("torch-build", exist_ok=True)
    module = load(
        name="my_kernel",
        sources=["my_kernel.cu"],
        build_directory="torch-build",
        verbose=False,
        extra_cuda_cflags=["--offload-arch=gfx942", "-std=c++20", "-O2"],
        extra_cflags=["-O2"],
    )

# Use the compiled module
result = module.my_op(input_tensor)
```

**Critical notes:**

- **Use `load()` not `load_inline()`** — file-based compilation is more reliable on ROCm
- **CXX must be clang++** — gcc will not work for HIP compilation
- **PYTORCH_ROCM_ARCH=gfx942** — must match the MI300X architecture
- **--offload-arch=gfx942** in extra_cuda_cflags — required for correct GPU targeting
- **FileLock** prevents race conditions when multiple processes compile simultaneously

## HIP-Specific Headers

Available on MI300X:

| Header | Purpose |
| ------ | ------- |
| `hip/hip_runtime.h` | Core HIP runtime |
| `hip/hip_fp16.h` | Half precision support |
| `hip/hip_cooperative_groups.h` | Cooperative groups |
| `hip/hip_ext.h` | Extensions (e.g., hipExtMallocWithFlags) |
| `rocwmma/rocwmma.hpp` | Wavefront matrix multiply-accumulate (matrix cores) |
| `torch/extension.h` | PyTorch/pybind11 bindings |

## Key HIP vs CUDA Differences

- **Wavefront size: 64** (not 32) — adjust all warp-level code
- **Warp shuffle**: `__shfl()` works but takes 64 lanes
- **Atomics**: `__hip_atomic_*` with explicit memory scope (`__HIP_MEMORY_SCOPE_AGENT`, `__HIP_MEMORY_SCOPE_SYSTEM`)
- **Built-in intrinsics**: `__builtin_amdgcn_*` (e.g., `__builtin_amdgcn_readfirstlane`, `__builtin_amdgcn_wave_barrier`)
- **Compiler**: Use `hipcc` instead of `nvcc` for standalone compilation
- **Diagnostics**: Use `rocm-smi` instead of `nvidia-smi`
- **Profiling**: Use `rocprof-compute` for profiling
- **Kernel syntax**: Nearly identical to CUDA (`__global__`, `<<<blocks, threads>>>`)

## Optimization Strategies

- **64-wide wavefronts** — adjust tiling and reduction logic
- **LDS (Local Data Share)** — equivalent to CUDA shared memory
- **Vectorized loads**: `vec_t<16, f16>` pattern for 128-bit loads
- **MFMA instructions** via rocWMMA for matrix operations
- **`__builtin_nontemporal_load/store`** for streaming memory access
- **Memory coalescing** — same principles as CUDA
- **Occupancy**: balance VGPR/SGPR usage and LDS

## Kernel Format (KernelBench)

The reference file contains a PyTorch `Model` class. You must write a `ModelNew` class that:

1. Has the same `__init__` signature as `Model`
2. Has a `forward()` method with the same input/output signature
3. Uses custom HIP kernels (with `__global__` definitions), **NOT** PyTorch ops

**Use the `load()` pattern above** — do **NOT** use `load_inline()`; file-based compilation is more reliable on ROCm/MI300X.

The reference file also provides:

- `get_inputs()` — generates test inputs for forward()
- `get_init_inputs()` — generates constructor arguments

Score your solution using the `eval_task` tool when provided in your instruction.

## Scoring

- Score = geometric mean speedup across all workloads (if all pass correctness)
- If any workload fails correctness: score = pass_rate * 0.1
