---
name: b200-guide
description: NVIDIA B200 (Blackwell sm_100) optimization guide. Sandbox commands, profiling, kernel format.
---

# NVIDIA B200 (Blackwell) — CUDA Optimization Guide

## Hardware Specs

- Architecture: Blackwell (sm_100)
- SMs: 192
- Shared memory: 192KB per SM
- Memory: HBM3e, ~8 TB/s bandwidth
- Target name: `b200`

## Sandbox Commands

```bash
# Score your solution: use the eval_task tool (see your instruction for the URL).
# Do NOT run task.py directly — it is not in your workspace during evals.

# Run any command with local file sync
wafer sandbox run --target b200 --sync . -- <command>

# Profile with NVIDIA Nsight Compute (sync first so binary is on remote)
wafer sandbox run --target b200 --sync . -- ncu --set full ./binary

# Profile with NVIDIA Nsight Systems
wafer sandbox run --target b200 --sync . -- nsys profile ./binary

# Check GPU status (no sync needed)
wafer sandbox run --target b200 -- nvidia-smi
```

## Kernel Format (KernelBench)

The reference file contains a PyTorch `Model` class. You must write a `ModelNew` class that:
1. Has the same `__init__` signature as `Model`
2. Has a `forward()` method with the same input/output signature
3. Uses custom CUDA kernels (with `__global__` definitions and `torch.utils.cpp_extension.load_inline`), NOT PyTorch ops

The reference file also provides:
- `get_inputs()` — generates test inputs for forward()
- `get_init_inputs()` — generates constructor arguments

## Optimization Strategies

- **Memory coalescing**: Ensure threads in a warp access consecutive memory addresses
- **Warp-level primitives**: Use `__shfl_*` intrinsics for intra-warp communication
- **Shared memory tiling**: Tile data into shared memory to reduce global memory traffic
- **Occupancy**: Balance register usage and shared memory to maximize active warps
- **Vectorized loads**: Use `float4`/`int4` for 128-bit loads when alignment allows
- **Tensor cores**: Use WMMA/MMA for matrix operations when applicable

## Scoring

- Score = geometric mean speedup across all workloads (if all pass correctness)
- If any workload fails correctness: score = pass_rate * 0.1
- All workloads must pass accuracy checks for full score
