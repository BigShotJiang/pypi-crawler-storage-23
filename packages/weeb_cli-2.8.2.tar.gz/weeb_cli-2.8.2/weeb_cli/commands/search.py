from .search import search_anime

__all__ = ['search_anime']
