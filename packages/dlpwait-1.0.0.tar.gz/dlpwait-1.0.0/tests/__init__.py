"""Tests for the DLPWait library."""
