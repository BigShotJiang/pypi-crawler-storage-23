# -*- encoding: utf-8 -*-
__all__ = (
    'Schema',
    'SchemaLiteral',
    'parse',
    'loads',
    'load',
    'loadVersionAttrsFromClientJar',
    'converters'
)

import enum
import json
import os
from contextlib import nullcontext
from io import TextIOWrapper
from zipfile import BadZipFile
from zipfile import LargeZipFile
from zipfile import ZipFile

import cattrs
from typing_extensions import Any
from typing_extensions import IO
from typing_extensions import Literal
from typing_extensions import NamedTuple
from typing_extensions import TypeAlias
from typing_extensions import overload

from mcschemas.models.assetindex import AssetIndex
from mcschemas.models.clientmanifest import ClientManifest
from mcschemas.models.mojangjava import MojangJavaRuntimeIndex
from mcschemas.models.mojangjava import MojangJavaRuntimeManifest
from mcschemas.models.versionattrs import VersionAttributes
from mcschemas.models.versionmanifest import VersionManifest
from mcschemas.models.yggdrasil import EndpointAuthenticateResponse
from mcschemas.models.yggdrasil import EndpointRefreshResponse
from mcschemas.models.yggdrasil import ErrorResponse
from mcschemas.models.yggdrasil import ReferenceServerMetadata
from mcschemas.models.yggdrasil import TextureProperty
from mcschemas.models.yggdrasil import YggdrasilApiMetadata
from mcschemas.parser import converters

_SchemaTargets: TypeAlias = (
        AssetIndex
        | ClientManifest
        | VersionManifest
        | VersionAttributes
        | MojangJavaRuntimeIndex
        | MojangJavaRuntimeManifest
        | ErrorResponse
        | EndpointAuthenticateResponse
        | EndpointRefreshResponse
        | YggdrasilApiMetadata
        | ReferenceServerMetadata
        | TextureProperty
)


class _SchemaAttribute(NamedTuple):
    target: type[_SchemaTargets]
    buildable: bool


class Schema(_SchemaAttribute, enum.Enum):
    VERSION_MANIFEST = (VersionManifest, False)
    CLIENT_MANIFEST = (ClientManifest, False)
    ASSET_INDEX = (AssetIndex, False)
    VERSION_ATTRIBUTES = (VersionAttributes, False)
    MOJANG_JAVA_RUNTIME_INDEX = (MojangJavaRuntimeIndex, False)
    MOJANG_JAVA_RUNTIME_MANIFEST = (MojangJavaRuntimeManifest, False)
    TEXTURE_PROPERTY = (TextureProperty, False)
    ERROR_RESPONSE = (ErrorResponse, False)
    ENDPOINT_AUTHENTICATE_RESPONSE = (EndpointAuthenticateResponse, False)
    ENDPOINT_REFRESH_RESPONSE = (EndpointRefreshResponse, False)
    YGGDRASIL_API_METADATA = (YggdrasilApiMetadata, False)
    REFERENCE_SERVER_METADATA = (ReferenceServerMetadata, False)


SchemaLiteral: TypeAlias = Literal[
    Schema.VERSION_MANIFEST,
    Schema.CLIENT_MANIFEST,
    Schema.ASSET_INDEX,
    Schema.VERSION_ATTRIBUTES,
    Schema.MOJANG_JAVA_RUNTIME_INDEX,
    Schema.MOJANG_JAVA_RUNTIME_MANIFEST,
    Schema.TEXTURE_PROPERTY,
    Schema.ERROR_RESPONSE,
    Schema.ENDPOINT_AUTHENTICATE_RESPONSE,
    Schema.ENDPOINT_REFRESH_RESPONSE,
    Schema.YGGDRASIL_API_METADATA,
    Schema.REFERENCE_SERVER_METADATA
]


@overload
def parse(
        obj: Any,
        schema: Literal[Schema.ASSET_INDEX], /,
        *, converter: cattrs.BaseConverter | None = ...
) -> AssetIndex: ...


@overload
def parse(
        obj: Any,
        schema: Literal[Schema.CLIENT_MANIFEST], /,
        *, converter: cattrs.BaseConverter | None = ...
) -> ClientManifest: ...


@overload
def parse(
        obj: Any,
        schema: Literal[Schema.VERSION_MANIFEST], /,
        *, converter: cattrs.BaseConverter | None = ...
) -> VersionManifest: ...


@overload
def parse(
        obj: Any,
        schema: Literal[Schema.VERSION_ATTRIBUTES], /,
        *, converter: cattrs.BaseConverter | None = ...
) -> VersionAttributes: ...


@overload
def parse(
        obj: Any,
        schema: Literal[Schema.MOJANG_JAVA_RUNTIME_INDEX], /,
        *, converter: cattrs.BaseConverter | None = ...
) -> MojangJavaRuntimeIndex: ...


@overload
def parse(
        obj: Any,
        schema: Literal[Schema.MOJANG_JAVA_RUNTIME_MANIFEST], /,
        *, converter: cattrs.BaseConverter | None = ...
) -> MojangJavaRuntimeManifest: ...


@overload
def parse(
        obj: Any,
        schema: Literal[Schema.TEXTURE_PROPERTY], /,
        *, converter: cattrs.BaseConverter | None = ...
) -> TextureProperty: ...


@overload
def parse(
        obj: Any,
        schema: Literal[Schema.ERROR_RESPONSE], /,
        *, converter: cattrs.BaseConverter | None = ...
) -> ErrorResponse: ...


@overload
def parse(
        obj: Any,
        schema: Literal[Schema.ENDPOINT_AUTHENTICATE_RESPONSE], /,
        *, converter: cattrs.BaseConverter | None = ...
) -> EndpointAuthenticateResponse: ...


@overload
def parse(
        obj: Any,
        schema: Literal[Schema.ENDPOINT_REFRESH_RESPONSE], /,
        *, converter: cattrs.BaseConverter | None = ...
) -> EndpointRefreshResponse: ...


@overload
def parse(
        obj: Any,
        schema: Literal[Schema.YGGDRASIL_API_METADATA], /,
        *, converter: cattrs.BaseConverter | None = ...
) -> YggdrasilApiMetadata: ...


@overload
def parse(
        obj: Any,
        schema: Literal[Schema.REFERENCE_SERVER_METADATA], /,
        *, converter: cattrs.BaseConverter | None = ...
) -> ReferenceServerMetadata: ...


def parse(
        obj: Any,
        schema: Any, /,
        *, converter: cattrs.BaseConverter | None = None
) -> Any:
    if schema not in Schema:
        raise TypeError(
                'Schema must be one member of the enum {0.__module__}.{0.__name__}, '
                'but {1!r} ({2.__qualname__} object) is not'.format(
                        Schema, obj, type(obj)
                )
        )
    cl = schema.target

    if converter is None:
        converter = converters.DedicatedConverter()
    elif not isinstance(converter, cattrs.BaseConverter):
        raise TypeError(
                '{0!r} must be a {1.__module__}.{1.__name__} object, '
                'a {2.__module__}.{2.__name__} object or None '
                '(got {3!r} that is {4.__qualname__!s} object)'.format(
                        'converter', cattrs.Converter, cattrs.BaseConverter, converter, type(converter)
                )
        )

    return converter.structure(obj, cl)


@overload
def loads(
        s: str,
        schema: Literal[Schema.ASSET_INDEX], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_loads_kwargs: Any
) -> AssetIndex: ...


@overload
def loads(
        s: str,
        schema: Literal[Schema.CLIENT_MANIFEST], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_loads_kwargs: Any
) -> ClientManifest: ...


@overload
def loads(
        s: str,
        schema: Literal[Schema.VERSION_MANIFEST], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_loads_kwargs: Any
) -> VersionManifest: ...


@overload
def loads(
        s: str,
        schema: Literal[Schema.VERSION_ATTRIBUTES], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> VersionAttributes: ...


@overload
def loads(
        s: str,
        schema: Literal[Schema.MOJANG_JAVA_RUNTIME_INDEX], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> MojangJavaRuntimeIndex: ...


@overload
def loads(
        s: str,
        schema: Literal[Schema.MOJANG_JAVA_RUNTIME_MANIFEST], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> MojangJavaRuntimeManifest: ...


@overload
def loads(
        s: str,
        schema: Literal[Schema.TEXTURE_PROPERTY], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> TextureProperty: ...


@overload
def loads(
        s: str,
        schema: Literal[Schema.ERROR_RESPONSE], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> ErrorResponse: ...


@overload
def loads(
        s: str,
        schema: Literal[Schema.ENDPOINT_AUTHENTICATE_RESPONSE], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> EndpointAuthenticateResponse: ...


@overload
def loads(
        s: str,
        schema: Literal[Schema.ENDPOINT_REFRESH_RESPONSE], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> EndpointRefreshResponse: ...


@overload
def loads(
        s: str,
        schema: Literal[Schema.YGGDRASIL_API_METADATA], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> YggdrasilApiMetadata: ...


@overload
def loads(
        s: str,
        schema: Literal[Schema.REFERENCE_SERVER_METADATA], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> ReferenceServerMetadata: ...


def loads(
        s: str,
        schema: Any, /,
        *, converter: cattrs.BaseConverter | None = None,
        **json_loads_kwargs: Any
) -> Any:
    return parse(json.loads(s, **json_loads_kwargs), schema, converter=converter)


@overload
def load(
        fp: IO[str],
        schema: Literal[Schema.ASSET_INDEX], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> AssetIndex: ...


@overload
def load(
        fp: IO[str],
        schema: Literal[Schema.CLIENT_MANIFEST], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> ClientManifest: ...


@overload
def load(
        fp: IO[str],
        schema: Literal[Schema.VERSION_MANIFEST], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> VersionManifest: ...


@overload
def load(
        fp: IO[str],
        schema: Literal[Schema.VERSION_ATTRIBUTES], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> VersionAttributes: ...


@overload
def load(
        fp: IO[str],
        schema: Literal[Schema.MOJANG_JAVA_RUNTIME_INDEX], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> MojangJavaRuntimeIndex: ...


@overload
def load(
        fp: IO[str],
        schema: Literal[Schema.MOJANG_JAVA_RUNTIME_MANIFEST], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> MojangJavaRuntimeManifest: ...


@overload
def load(
        fp: IO[str],
        schema: Literal[Schema.TEXTURE_PROPERTY], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> TextureProperty: ...


@overload
def load(
        fp: IO[str],
        schema: Literal[Schema.ERROR_RESPONSE], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> ErrorResponse: ...


@overload
def load(
        fp: IO[str],
        schema: Literal[Schema.ENDPOINT_AUTHENTICATE_RESPONSE], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> EndpointAuthenticateResponse: ...


@overload
def load(
        fp: IO[str],
        schema: Literal[Schema.ENDPOINT_REFRESH_RESPONSE], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> EndpointRefreshResponse: ...


@overload
def load(
        fp: IO[str],
        schema: Literal[Schema.YGGDRASIL_API_METADATA], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> YggdrasilApiMetadata: ...


@overload
def load(
        fp: IO[str],
        schema: Literal[Schema.REFERENCE_SERVER_METADATA], /,
        *, converter: cattrs.BaseConverter | None = ...,
        **json_load_kwargs: Any
) -> ReferenceServerMetadata: ...


def load(
        fp: IO[str],
        schema: Any, /,
        *, converter: cattrs.BaseConverter | None = None,
        **json_load_kwargs: Any
) -> Any:
    return parse(json.load(fp, **json_load_kwargs), schema, converter=converter)


def loadVersionAttrsFromClientJar(
        file: str | os.PathLike[str] | IO[bytes], /,
        *, converter: cattrs.BaseConverter | None = None,
        **json_load_kwargs: Any
) -> VersionAttributes:
    if isinstance(file, str):
        fp_ctx = open(file, mode='rb')
    else:
        fp_ctx = nullcontext(file)  # type: ignore[assignment]

    with fp_ctx as fp:
        with ZipFile(fp, mode='r') as zfp:
            try:
                version_json_member_fp = zfp.open('version.json', mode='r')
            except (KeyError, BadZipFile, LargeZipFile):
                raise

            with TextIOWrapper(version_json_member_fp, encoding='utf-8') as version_json_fp:
                return load(version_json_fp, Schema.VERSION_ATTRIBUTES, converter=converter, **json_load_kwargs)
