# -*- encoding: utf-8 -*-
__all__ = (
    'TextureProperty',
    'ErrorResponse',
    'EndpointAuthenticateResponse',
    'EndpointRefreshResponse',
    'YggdrasilApiMetadata',
    'ReferenceServerMetadata',
    'nodes'
)

from uuid import UUID as UUIDType

import attrs
from typing_extensions import Any
from typing_extensions import TypedDict

from mcschemas.models.yggdrasil import nodes


@attrs.define(kw_only=True, slots=True)
class TextureProperty:
    timestamp: int
    profileId: UUIDType
    profileName: str
    signatureRequired: bool | None = None
    textures: nodes.ClassifiedTextures


@attrs.define(kw_only=True, slots=True)
class ErrorResponse:
    error: str
    errorMessage: str
    cause: str | None = None


@attrs.define(kw_only=True, slots=True)
class EndpointAuthenticateResponse:
    accessToken: str
    clientToken: str
    availablePlayerProfiles: nodes.AvailablePlayerProfiles = attrs.field(alias='availableProfiles')
    selectedPlayerProfile: nodes.PlayerProfile | None = attrs.field(alias='selectedProfile', default=None)
    userProfile: nodes.UserProfile | None = attrs.field(alias='user', default=None)


@attrs.define(kw_only=True, slots=True)
class EndpointRefreshResponse:
    accessToken: str
    clientToken: str
    selectedPlayerProfile: nodes.PlayerProfile | None = attrs.field(alias='selectedProfile', default=None)
    userProfile: nodes.UserProfile | None = attrs.field(alias='user', default=None)


@attrs.define(kw_only=True, slots=True)
class YggdrasilApiMetadata:
    serverMetadata: dict[str, Any] = attrs.field(alias='meta')
    skinDomainAllowlist: list[str] = attrs.field(alias='skinDomains')
    signaturePublicKey: str = attrs.field(alias='signaturePublickey')


ReferenceServerMetadata = TypedDict(
        'ReferenceServerMetadata',
        {
            'serverName'                         : str,
            'implementationName'                 : str,
            'implementationVersion'              : str,
            'links'                              : dict[str, str],
            'feature.non_email_login'            : bool,
            'feature.legacy_skin_api'            : bool,
            'feature.no_mojang_namespace'        : bool,
            'feature.enable_mojang_anti_features': bool,
            'feature.enable_profile_key'         : bool,
            'feature.username_check'             : bool,
            'feature.openid_configuration_url'   : str
        },
        total=False
)
