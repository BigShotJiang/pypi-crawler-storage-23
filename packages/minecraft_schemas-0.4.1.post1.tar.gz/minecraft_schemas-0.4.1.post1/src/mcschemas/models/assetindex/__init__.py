# -*- encoding: utf-8 -*-
__all__ = (
    'AssetIndex',
    'nodes'
)

from collections.abc import Iterator
from collections.abc import MutableMapping
from pathlib import Path

import attrs
from typing_extensions import TypeAlias
from typing_extensions import override

from mcschemas.models.assetindex import nodes

AssetFileRelativePath: TypeAlias = Path


@attrs.define(kw_only=True, slots=True)
class AssetIndex(MutableMapping[AssetFileRelativePath, nodes.AssetFileEntry]):
    objects: dict[AssetFileRelativePath, nodes.AssetFileEntry]
    """
    A mapping of asset files.
    The key of the mapping is relative path to asset files
    under ``.minecraft/assets/`` in ``pathlib.Path`` object,
    and the value is ``mcschemas.models.assetindex.nodes.AssetFileEntry`` object.
    """
    virtual: bool | None = None
    map_to_resources: bool | None = None

    @override
    def __len__(self) -> int:
        return len(self.objects)

    @override
    def __iter__(self) -> Iterator[AssetFileRelativePath]:
        return iter(self.objects)

    @override
    def __getitem__(self, key: str | AssetFileRelativePath, /) -> nodes.AssetFileEntry:
        return self.objects[Path(key)]

    @override
    def __setitem__(self, key: str | AssetFileRelativePath, value: nodes.AssetFileEntry, /) -> None:
        self.objects[Path(key)] = value

    @override
    def __delitem__(self, key: str | AssetFileRelativePath, /) -> None:
        del self.objects[Path(key)]
