# -*- encoding: utf-8 -*-
__all__ = (
    'AssetFileEntry',
)

import os

import attrs

from mcschemas.models.specials import Sha1Sum


@attrs.define(kw_only=True, slots=True)
class AssetFileEntry:
    hash: Sha1Sum
    """The SHA-1 hash of this asset file."""
    size: int
    """The size of this asset file."""

    @property
    def objectStorePath(self) -> str:
        return os.sep.join((self.hash.hexdigest[:2], self.hash.hexdigest))

    @property
    def objectWebPath(self) -> str:
        return '/'.join((self.hash.hexdigest[:2], self.hash.hexdigest))
