"""Tests for reviewer helper functions."""

from prlens.reviewer import _is_excluded, _determine_event, _build_summary


class TestIsExcluded:
    def test_exact_filename_match(self):
        assert _is_excluded("yarn.lock", ["yarn.lock"]) is True

    def test_glob_basename_match(self):
        assert _is_excluded("path/to/yarn.lock", ["*.lock"]) is True

    def test_glob_full_path_match(self):
        assert _is_excluded("src/generated/schema.py", ["src/generated/*.py"]) is True

    def test_directory_prefix_at_root(self):
        assert _is_excluded("migrations/0001_initial.py", ["migrations/"]) is True

    def test_directory_prefix_nested(self):
        assert _is_excluded("app/migrations/0001_initial.py", ["migrations"]) is True

    def test_no_false_positive_on_similar_name(self):
        # "test" pattern should not match "test_helpers.py" at root
        assert _is_excluded("test_helpers.py", ["tests/"]) is False

    def test_not_excluded_when_no_patterns(self):
        assert _is_excluded("src/main.py", []) is False

    def test_not_excluded_when_no_match(self):
        assert _is_excluded("src/main.py", ["migrations/", "*.lock"]) is False


class TestDetermineEvent:
    def test_approve_when_no_comments(self):
        assert _determine_event([]) == "APPROVE"

    def test_request_changes_on_critical(self):
        assert _determine_event([{"severity": "critical"}]) == "REQUEST_CHANGES"

    def test_request_changes_on_major(self):
        assert _determine_event([{"severity": "major"}]) == "REQUEST_CHANGES"

    def test_comment_on_minor_only(self):
        assert _determine_event([{"severity": "minor"}, {"severity": "nitpick"}]) == "COMMENT"

    def test_request_changes_when_mixed_with_critical(self):
        comments = [{"severity": "nitpick"}, {"severity": "critical"}, {"severity": "minor"}]
        assert _determine_event(comments) == "REQUEST_CHANGES"

    def test_defaults_missing_severity_to_minor(self):
        assert _determine_event([{}]) == "COMMENT"


class TestBuildSummary:
    def test_shows_reviewed_count(self):
        summary = [{"filename": "foo.py", "count": 2, "skipped": False, "error": None}]
        body = _build_summary(summary, 2)
        assert "Reviewed **1** file(s)" in body

    def test_shows_skipped_count(self):
        summary = [{"filename": "yarn.lock", "count": 0, "skipped": True, "error": None}]
        body = _build_summary(summary, 0)
        assert "skipped **1**" in body

    def test_lists_files_with_comments(self):
        summary = [
            {"filename": "src/foo.py", "count": 3, "skipped": False, "error": None},
            {"filename": "src/bar.py", "count": 0, "skipped": False, "error": None},
        ]
        body = _build_summary(summary, 3)
        assert "src/foo.py" in body
        assert "3 comment(s)" in body

    def test_clean_files_not_in_table(self):
        summary = [{"filename": "src/bar.py", "count": 0, "skipped": False, "error": None}]
        body = _build_summary(summary, 0)
        # Clean files should appear in summary text but not as a table row with comment count
        assert "Clean" in body
