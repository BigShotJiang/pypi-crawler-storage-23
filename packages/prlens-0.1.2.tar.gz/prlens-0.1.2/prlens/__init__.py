"""lens: AI-powered GitHub PR code reviewer for teams."""

__version__ = "0.1.0"
