from github import Github


def get_repo(repo_name: str, token: str):
    return Github(token).get_repo(repo_name)


def get_pull(repo, pr_number: int):
    return repo.get_pull(pr_number)


def get_pull_requests(repo, state: str = "open"):
    return repo.get_pulls(state=state)


def get_diff(pr):
    return pr.get_files()
