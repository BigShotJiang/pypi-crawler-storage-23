"""load_random function for the reservoir module."""

from typing import Any, Dict, List, Optional

import pandas as pd

from ..utils.api import make_request


def load_random(
    filters: Optional[Dict[str, Any]] = None,
    fields: Optional[List[str]] = None,
    partitions: Optional[List[str]] = None,
) -> pd.DataFrame:
    """
    Load a random reservoir model from the reservoir datasets in the database.

    Args:
        filters: Optional query filters.
        fields: Optional selected fields.
        partitions: Optional partition dimensions.

    Returns:
        pandas.DataFrame: DataFrame containing all rows from the selected dataset.
    """
    try:
        api_data = make_request(filters=filters, fields=fields, partitions=partitions)

        if "data" in api_data and "columns" in api_data:
            data = api_data["data"]
            dataset_id = api_data.get("dataset_id", "Unknown")

            if len(data) == 0:
                raise ValueError("API returned dataset with no data")

            df = pd.DataFrame(data)
            print(f"Loaded dataset with ID: {dataset_id}")
            return df

        raise ValueError("API response does not contain 'data' and 'columns' fields")

    except Exception as e:
        if "not initialized" in str(e):
            raise e
        raise RuntimeError(f"Error loading reservoir data: {e}")
