"""Runtime workflow selector and invocation client for PDS sessions."""

from __future__ import annotations

import json
import queue
import threading
import uuid
from dataclasses import dataclass
from typing import Any, Dict, Iterable, Iterator, List, Optional

from ..utils.api import read_workflow_definition


def _pascal_case(value: str) -> str:
    parts = [part for part in str(value).replace("-", "_").split("_") if part]
    return "".join(part[:1].upper() + part[1:] for part in parts)


def _normalize_mode(mode: str, *, input_streaming: bool, output_streaming: bool) -> str:
    normalized = str(mode or "").strip().lower()
    aliases = {
        "unary": "unary",
        "client_stream": "client_stream",
        "client-stream": "client_stream",
        "server_stream": "server_stream",
        "server-stream": "server_stream",
        "bidi": "bi_di",
        "bi_di": "bi_di",
        "bi-di": "bi_di",
        "bidirectional": "bi_di",
    }
    if normalized in aliases:
        return aliases[normalized]

    if input_streaming and output_streaming:
        return "bi_di"
    if input_streaming:
        return "client_stream"
    if output_streaming:
        return "server_stream"
    return "unary"


@dataclass(slots=True)
class OperationSpec:
    """Normalized operation definition from deployment metadata."""

    function_name: str
    rpc_name: str
    mode: str
    param_names: List[str]
    input_streaming: bool
    output_streaming: bool

    @classmethod
    def from_manifest(cls, payload: Dict[str, Any]) -> "OperationSpec":
        function_name = str(payload.get("function_name") or "").strip()
        if not function_name:
            raise ValueError("Operation manifest entry missing function_name")

        input_streaming = bool(payload.get("input_streaming", False))
        output_streaming = bool(payload.get("output_streaming", False))
        mode = _normalize_mode(
            str(payload.get("mode") or ""),
            input_streaming=input_streaming,
            output_streaming=output_streaming,
        )

        rpc_name = str(payload.get("rpc_name") or "").strip() or _pascal_case(function_name)
        params = payload.get("params") if isinstance(payload.get("params"), list) else []
        param_names = [
            str(param.get("name")).strip()
            for param in params
            if isinstance(param, dict) and str(param.get("name", "")).strip()
        ]

        return cls(
            function_name=function_name,
            rpc_name=rpc_name,
            mode=mode,
            param_names=param_names,
            input_streaming=input_streaming,
            output_streaming=output_streaming,
        )


@dataclass(slots=True)
class WorkflowSpec:
    """Runtime workflow metadata resolved from deployment ID."""

    deployment_id: str
    workflow_name: str
    operations: Dict[str, OperationSpec]

    @classmethod
    def from_definition(cls, definition: Dict[str, Any]) -> "WorkflowSpec":
        deployment_id = str(definition.get("deployment_id") or "").strip()
        if not deployment_id:
            raise ValueError("Workflow definition is missing deployment_id")

        workflow_name = str(definition.get("workflow_name") or deployment_id).strip() or deployment_id
        manifest = definition.get("operation_manifest")
        if not isinstance(manifest, list):
            manifest = []

        operations: Dict[str, OperationSpec] = {}
        for entry in manifest:
            if not isinstance(entry, dict):
                continue
            operation = OperationSpec.from_manifest(entry)
            operations[operation.function_name] = operation

        return cls(
            deployment_id=deployment_id,
            workflow_name=workflow_name,
            operations=operations,
        )


class JobTracker:
    """Track socket events and completion for one workflow stream job."""

    def __init__(self, *, output_streaming: bool) -> None:
        self.output_streaming = output_streaming
        self._result_queue: "queue.Queue[tuple[str, Any]]" = queue.Queue()
        self._done = threading.Event()
        self._lock = threading.Lock()
        self._error: Optional[str] = None
        self._result: Any = None
        self._has_result = False
        self._completed = False

    def add_result(self, value: Any) -> None:
        with self._lock:
            if self._completed:
                return
            if self.output_streaming:
                self._result_queue.put(("result", value))
            else:
                self._result = value
                self._has_result = True
                self._done.set()

    def set_error(self, message: str) -> None:
        with self._lock:
            if self._completed:
                return
            self._error = str(message)
            self._completed = True
            self._done.set()
            self._result_queue.put(("error", self._error))

    def set_completed(self) -> None:
        with self._lock:
            if self._completed:
                return
            self._completed = True
            self._done.set()
            if self.output_streaming:
                self._result_queue.put(("done", None))

    def wait_unary_result(self, timeout_seconds: float) -> Any:
        if not self._done.wait(timeout_seconds):
            raise TimeoutError(f"Workflow call timed out after {timeout_seconds:.1f}s")
        with self._lock:
            if self._error:
                raise RuntimeError(self._error)
            if not self._has_result:
                raise RuntimeError("Workflow call completed without a result")
            return self._result

    def stream_results(self, timeout_seconds: float) -> Iterator[Any]:
        while True:
            try:
                kind, payload = self._result_queue.get(timeout=timeout_seconds)
            except queue.Empty as exc:
                raise TimeoutError(f"Workflow stream timed out after {timeout_seconds:.1f}s") from exc

            if kind == "result":
                yield payload
                continue
            if kind == "error":
                raise RuntimeError(str(payload))
            if kind == "done":
                return


class WorkflowHandle:
    """Operation selector handle for one workflow specification."""

    def __init__(self, client: "WorkflowsClient", spec: WorkflowSpec):
        self._client = client
        self._spec = spec

    def __getattr__(self, operation_name: str):
        op = self._spec.operations.get(operation_name)
        if op is None:
            known = ", ".join(sorted(self._spec.operations.keys())) or "<none>"
            raise AttributeError(
                f"Workflow '{self._spec.workflow_name}' does not define operation '{operation_name}'. "
                f"Available: {known}"
            )

        def _invoke(*args, **kwargs):
            return self._client.invoke(self._spec, op, *args, **kwargs)

        return _invoke


class WorkflowsClient:
    """Selector API for invoking workflow operations over Socket.IO."""

    def __init__(
        self,
        *,
        session: Any,
        deployment_ids: Optional[List[str]] = None,
        call_timeout: float = 60.0,
    ) -> None:
        self._session = session
        self._call_timeout = float(call_timeout)
        self._lock = threading.Lock()
        self._specs_by_id: Dict[str, WorkflowSpec] = {}
        self._ids_by_alias: Dict[str, List[str]] = {}
        self._jobs: Dict[str, JobTracker] = {}

        for deployment_id in deployment_ids or []:
            self._ensure_spec(str(deployment_id).strip())

    def _ensure_spec(self, deployment_id: str) -> WorkflowSpec:
        normalized = str(deployment_id or "").strip()
        if not normalized:
            raise ValueError("workflow selector cannot be empty")

        with self._lock:
            existing = self._specs_by_id.get(normalized)
        if existing is not None:
            return existing

        definition = read_workflow_definition(normalized)
        spec = WorkflowSpec.from_definition(definition)

        with self._lock:
            self._specs_by_id[spec.deployment_id] = spec
            self._ids_by_alias.setdefault(spec.workflow_name, [])
            if spec.deployment_id not in self._ids_by_alias[spec.workflow_name]:
                self._ids_by_alias[spec.workflow_name].append(spec.deployment_id)
            return spec

    def __call__(self, selector: str) -> WorkflowHandle:
        selected = str(selector or "").strip()
        if not selected:
            raise ValueError("workflow selector cannot be empty")

        with self._lock:
            by_id = self._specs_by_id.get(selected)
            if by_id is not None:
                return WorkflowHandle(self, by_id)
            matches = list(self._ids_by_alias.get(selected, []))

        if len(matches) > 1:
            ids = ", ".join(sorted(matches))
            raise KeyError(
                f"Workflow alias '{selected}' is ambiguous across deployment IDs: {ids}. "
                "Select by deployment ID."
            )
        if len(matches) == 1:
            with self._lock:
                return WorkflowHandle(self, self._specs_by_id[matches[0]])

        try:
            by_id = self._ensure_spec(selected)
            return WorkflowHandle(self, by_id)
        except Exception as exc:
            raise KeyError(
                f"Workflow selector '{selected}' was not found. "
                "Use a deployment ID from initialize(workflows=[...]) or a unique workflow_name alias."
            ) from exc

    @staticmethod
    def _decode_json(value: Any) -> Any:
        if not isinstance(value, str):
            return value
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value

    def _register_job(self, job_id: str, tracker: JobTracker) -> None:
        with self._lock:
            self._jobs[job_id] = tracker

    def _pop_job(self, job_id: str) -> Optional[JobTracker]:
        with self._lock:
            return self._jobs.pop(job_id, None)

    def _get_job(self, job_id: str) -> Optional[JobTracker]:
        with self._lock:
            return self._jobs.get(job_id)

    @staticmethod
    def _serialize(value: Any) -> str:
        return json.dumps(value, default=str)

    def _build_unary_params(self, operation: OperationSpec, args: tuple[Any, ...], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        if args and isinstance(args[0], dict) and len(args) == 1 and not kwargs and not operation.param_names:
            return dict(args[0])

        if len(args) > len(operation.param_names):
            raise TypeError(
                f"Operation '{operation.function_name}' received {len(args)} positional args "
                f"but only {len(operation.param_names)} parameters are defined."
            )

        params: Dict[str, Any] = {}
        for index, value in enumerate(args):
            if index >= len(operation.param_names):
                break
            params[operation.param_names[index]] = value

        for key, value in kwargs.items():
            if operation.param_names and key not in operation.param_names:
                known = ", ".join(operation.param_names)
                raise TypeError(
                    f"Unknown parameter '{key}' for operation '{operation.function_name}'. "
                    f"Expected one of: {known}"
                )
            params[key] = value

        missing = [name for name in operation.param_names if name not in params]
        if missing:
            raise TypeError(
                f"Missing required parameters for '{operation.function_name}': {', '.join(missing)}"
            )

        return params

    def _coerce_stream_item(self, operation: OperationSpec, item: Any) -> Dict[str, Any]:
        if isinstance(item, dict):
            return dict(item)

        if len(operation.param_names) == 1:
            return {operation.param_names[0]: item}

        if isinstance(item, (tuple, list)) and len(item) == len(operation.param_names):
            return {name: value for name, value in zip(operation.param_names, item)}

        raise TypeError(
            f"Input stream items for '{operation.function_name}' must be dicts, "
            "single values (for one-parameter operations), or tuples/lists matching parameter count."
        )

    def invoke(self, spec: WorkflowSpec, operation: OperationSpec, *args, **kwargs):
        if not self._session.connected:
            raise ConnectionError("PDS session is not connected to a workspace master.")

        job_id = f"job-{uuid.uuid4().hex}"
        tracker = JobTracker(output_streaming=operation.output_streaming)
        self._register_job(job_id, tracker)

        try:
            if operation.input_streaming:
                if not args:
                    raise TypeError(
                        f"Operation '{operation.function_name}' expects an input iterable as the first positional argument."
                    )
                if kwargs:
                    raise TypeError(
                        f"Operation '{operation.function_name}' does not accept keyword args when input_streaming=True."
                    )
                stream_source = args[0]
                params_json = "{}"
            else:
                params = self._build_unary_params(operation, args, kwargs)
                params_json = self._serialize(params)

            self._session.emit(
                "workflow_stream_start",
                {
                    "workflow_name": spec.workflow_name,
                    "job_id": job_id,
                    "rpc_name": operation.rpc_name,
                    "mode": operation.mode,
                    "params_json": params_json,
                },
                require_connected=True,
            )

            if operation.input_streaming:
                chunk_index = 0
                for item in stream_source:
                    payload = self._coerce_stream_item(operation, item)
                    self._session.emit(
                        "workflow_stream_chunk",
                        {
                            "workflow_name": spec.workflow_name,
                            "job_id": job_id,
                            "chunk_id": f"chunk-{chunk_index}",
                            "payload_json": self._serialize(payload),
                            "is_final": False,
                        },
                        require_connected=True,
                    )
                    chunk_index += 1

                self._session.emit(
                    "workflow_stream_chunk",
                    {
                        "workflow_name": spec.workflow_name,
                        "job_id": job_id,
                        "chunk_id": "final",
                        "payload_json": "{}",
                        "is_final": True,
                    },
                    require_connected=True,
                )
            else:
                self._session.emit(
                    "workflow_stream_chunk",
                    {
                        "workflow_name": spec.workflow_name,
                        "job_id": job_id,
                        "chunk_id": "final",
                        "payload_json": params_json,
                        "is_final": True,
                    },
                    require_connected=True,
                )

            if operation.output_streaming:
                def _generator():
                    try:
                        for value in tracker.stream_results(self._call_timeout):
                            yield value
                    finally:
                        self._pop_job(job_id)

                return _generator()

            result = tracker.wait_unary_result(self._call_timeout)
            return result
        finally:
            if not operation.output_streaming:
                self._pop_job(job_id)

    def on_stream_started(self, _payload: Dict[str, Any]) -> None:
        """Socket callback for stream start acknowledgements."""

    def on_stream_update(self, payload: Dict[str, Any]) -> None:
        job_id = str((payload or {}).get("job_id", "")).strip()
        if not job_id:
            return

        tracker = self._get_job(job_id)
        if tracker is None:
            return

        result_json = (payload or {}).get("result_json")
        decoded = self._decode_json(result_json)
        tracker.add_result(decoded)

    def on_stream_error(self, payload: Dict[str, Any]) -> None:
        job_id = str((payload or {}).get("job_id", "")).strip()
        message = str((payload or {}).get("message", "Workflow invocation failed"))
        if not job_id:
            return

        tracker = self._pop_job(job_id)
        if tracker is not None:
            tracker.set_error(message)

    def on_stream_completed(self, payload: Dict[str, Any]) -> None:
        job_id = str((payload or {}).get("job_id", "")).strip()
        if not job_id:
            return

        tracker = self._pop_job(job_id)
        if tracker is not None:
            tracker.set_completed()

    def fail_all_pending(self, message: str) -> None:
        with self._lock:
            pending = list(self._jobs.items())
            self._jobs.clear()

        for _, tracker in pending:
            tracker.set_error(message)
