"""
Workflows module for per_datasets
"""

from .runtime import WorkflowsClient

class workflow:
    """No-op decorators used for build-time discovery."""

    @staticmethod
    def unary(func):
        return func

    @staticmethod
    def client_stream(func):
        return func

    @staticmethod
    def server_stream(func):
        return func

    @staticmethod
    def bi_di(func):
        return func


__all__ = ["workflow", "WorkflowsClient"]
