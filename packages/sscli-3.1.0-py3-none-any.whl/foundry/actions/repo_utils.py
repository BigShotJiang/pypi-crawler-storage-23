import hashlib
import shutil
import subprocess
import tarfile
from datetime import datetime
from pathlib import Path
from tempfile import NamedTemporaryFile

import requests
from foundry.auth import get_access_token, get_current_license_info
from foundry.constants import API_BASE_URL, console, TEMPLATES_DIR
from foundry.utils import is_internal_dev
from rich.panel import Panel

def download_template(template_name, template_info, target_path):
    """Downloads a template to the target path.

    SECURITY: Re-verifies GitHub auth AND license server membership on every
    download attempt, not just at initial login. Prevents access after revocation.
    """
    # Local template fallback for internal development
    local_template_path = TEMPLATES_DIR / template_name
    if is_internal_dev() and local_template_path.exists():
        console.print("   - Using local template from development environment...")
        try:
            shutil.copytree(local_template_path, target_path, dirs_exist_ok=False)
            return True
        except FileExistsError:
            console.print(f"[red]Error: {target_path.name} already exists![/red]")
            return False
    else:
        # SECURITY: Re-verify GitHub auth + license server membership before download
        license_info = get_current_license_info(verify=True)
        if license_info.get("tier", "free") == "free" and not license_info.get("authorized", False):
            console.print("[red]✗ Access Denied:[/red] Valid license required to download templates.")
            console.print("  Run [bold]sscli login[/bold] to authenticate.")
            return False

        token = get_access_token()
        if not token:
            console.print("[red]✗ GitHub authentication required.[/red] Run [bold]sscli login[/bold].")
            return False

        download_url = f"{API_BASE_URL}/v1/templates/{template_name}/download"
        console.print("   - Downloading template from License Server...")

        try:
            response = requests.get(
                download_url,
                headers={"Authorization": f"Bearer {token}"},
                timeout=30,
            )
        except requests.RequestException as exc:
            console.print(f"[red]Download failed:[/red] {exc}")
            return False

        if response.status_code != 200:
            console.print(f"[red]Download failed:[/red] Server returned {response.status_code}")
            if response.text:
                console.print(response.text)
            return False

        checksum_expected = response.headers.get("X-Template-Sha256")
        user_id = response.headers.get("X-Foundry-User-Id")

        target_path.mkdir(parents=True, exist_ok=True)
        with NamedTemporaryFile(delete=False, suffix=".tar.gz") as temp_file:
            temp_file.write(response.content)
            temp_path = Path(temp_file.name)

        checksum_actual = _sha256_file(temp_path)
        if checksum_expected and checksum_actual != checksum_expected:
            console.print("[red]Download failed:[/red] checksum mismatch.")
            temp_path.unlink(missing_ok=True)
            return False

        try:
            with tarfile.open(temp_path, "r:gz") as tar:
                tar.extractall(path=target_path)
        except tarfile.TarError as exc:
            console.print(f"[red]Extraction failed:[/red] {exc}")
            temp_path.unlink(missing_ok=True)
            return False
        finally:
            temp_path.unlink(missing_ok=True)

        _write_fingerprint(target_path, user_id)
        return True

def initialize_github_repo(target_path: Path, config: dict):
    """Initializes a local git repo and creates a remote on GitHub using 'gh' CLI."""
    repo_owner = config.get("owner")
    repo_name = config.get("name")
    repo_desc = config.get("description")
    repo_vis = config.get("visibility", "private")
    
    # Construct full repo path if owner is provided
    full_repo_name = f"{repo_owner}/{repo_name}" if repo_owner else repo_name

    console.print(f"   - Initializing GitHub repository: [cyan]{full_repo_name}[/cyan] ({repo_vis})...")
    
    try:
        # Check if gh is authenticated
        auth_check = subprocess.run(["gh", "auth", "status"], capture_output=True, text=True)
        if auth_check.returncode != 0:
            console.print("   [yellow]⚠️  'gh' CLI is not authenticated. Skipping automatic repository creation.[/yellow]")
            console.print("   [yellow]   Run 'gh auth login' and try again later or manage the repo manually.[/yellow]")
            return False

        # 1. Initialize local git
        subprocess.run(["git", "init", "-b", "main"], cwd=str(target_path), check=True, capture_output=True)
        
        # 2. Add all files
        subprocess.run(["git", "add", "."], cwd=str(target_path), check=True, capture_output=True)
        
        # 3. Initial commit
        subprocess.run(["git", "commit", "-m", "feat: initial bootstrap from Seed & Source"], 
                       cwd=str(target_path), check=True, capture_output=True)
        
        # 4. Create remote repo using gh CLI
        cmd = [
            "gh", "repo", "create", full_repo_name,
            f"--{repo_vis}",
            "--description", repo_desc,
            "--source", ".",
            "--remote", "origin",
            "--push"
        ]
        
        result = subprocess.run(cmd, cwd=str(target_path), capture_output=True, text=True)
        
        if result.returncode == 0:
            console.print(f"   [green]✓ Successfully created and pushed to GitHub![/green]")
            return True
        else:
            console.print(f"   [red]✗ Failed to create GitHub repository:[/red] {result.stderr.strip()}")
            return False
            
    except Exception as e:
        console.print(f"   [red]✗ Error during GitHub initialization:[/red] {e}")
        return False

def handle_clone_error(stderr):
    """Provides helpful feedback for Git clone failures."""
    console.print("[bold red]Download Error:[/bold red]")
    if "403" in stderr or "401" in stderr:
        console.print(Panel(
            "[bold yellow]Organization Access Required[/bold yellow]\n\n"
            "It looks like your GitHub token doesn't have access to the private repository.\n"
            "1. Go to your [bold]GitHub Settings -> Applications -> Authorized OAuth Apps[/bold].\n"
            "2. Find 'Seed & Source License'.\n"
            "3. Ensure access is [bold]GRANTED[/bold] for the 'seed-source' organization.",
            title="Access Denied", border_style="red"
        ))
    else:
        console.print(f"Error Message: {stderr}")


def _sha256_file(path: Path) -> str:
    hasher = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def _write_fingerprint(target_path: Path, user_id: str | None) -> None:
    if not user_id:
        return

    fingerprint_dir = target_path / ".foundry"
    fingerprint_dir.mkdir(parents=True, exist_ok=True)

    raw = f"{user_id}:{datetime.utcnow().isoformat()}".encode("utf-8")
    user_hash = hashlib.sha256(raw).hexdigest()

    owner_file = fingerprint_dir / "owner"
    owner_file.write_text(
        f"user_hash={user_hash}\ncreated_at={datetime.utcnow().isoformat()}Z\n",
        encoding="utf-8",
    )
