:orphan:

Dummy Module
============

.. autofunction:: dummy_module_future_annotations.function_with_py310_annotations
