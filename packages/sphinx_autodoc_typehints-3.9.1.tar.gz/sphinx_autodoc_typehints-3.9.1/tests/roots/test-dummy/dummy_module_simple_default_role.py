from __future__ import annotations


def function(x: bool, y: int) -> str:
    """
    Function docstring.

    :param x: `foo`
    :param y: ``bar``
    """
