from __future__ import annotations

from wrong_module_path import A, f

__all__ = ["A", "f"]
