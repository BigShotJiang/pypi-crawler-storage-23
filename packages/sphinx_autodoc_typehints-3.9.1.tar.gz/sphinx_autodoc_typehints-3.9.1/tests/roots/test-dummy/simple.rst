:orphan:

Simple Module
=============

.. autofunction:: dummy_module_simple.function
