"""Wall loss utilities, strategies, builders, and factory.

Provides rate calculators, strategy classes, and builders for particle wall
loss in spherical and rectangular chambers. Includes charged wall loss with
image-charge enhancement even at zero wall potential, optional electric-field
drift, and deterministic or particle-resolved helpers.
"""

from .rate import (
    get_charged_wall_loss_rate as get_charged_wall_loss_rate,
)
from .rate import (
    get_rectangle_wall_loss_rate as get_rectangle_wall_loss_rate,
)
from .rate import (
    get_spherical_wall_loss_rate as get_spherical_wall_loss_rate,
)
from .wall_loss_builders import (
    ChargedWallLossBuilder as ChargedWallLossBuilder,
)
from .wall_loss_builders import (
    RectangularWallLossBuilder as RectangularWallLossBuilder,
)
from .wall_loss_builders import (
    SphericalWallLossBuilder as SphericalWallLossBuilder,
)
from .wall_loss_factories import (
    WallLossFactory as WallLossFactory,
)
from .wall_loss_strategies import (
    ChargedWallLossStrategy as ChargedWallLossStrategy,
)
from .wall_loss_strategies import (
    RectangularWallLossStrategy as RectangularWallLossStrategy,
)
from .wall_loss_strategies import (
    SphericalWallLossStrategy as SphericalWallLossStrategy,
)
from .wall_loss_strategies import (
    WallLossStrategy as WallLossStrategy,
)
from .wall_loss_strategies import (
    get_particle_resolved_wall_loss_step as get_particle_resolved_wall_loss_step,  # noqa: E501
)

__all__ = [
    "WallLossStrategy",
    "SphericalWallLossStrategy",
    "RectangularWallLossStrategy",
    "ChargedWallLossStrategy",
    "SphericalWallLossBuilder",
    "RectangularWallLossBuilder",
    "ChargedWallLossBuilder",
    "WallLossFactory",
    "get_rectangle_wall_loss_rate",
    "get_spherical_wall_loss_rate",
    "get_charged_wall_loss_rate",
    "get_particle_resolved_wall_loss_step",
]
