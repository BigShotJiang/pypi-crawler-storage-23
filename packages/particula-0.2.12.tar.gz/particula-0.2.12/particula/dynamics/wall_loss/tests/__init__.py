"""Tests for wall loss strategies.

This package contains unit tests for wall loss rate
functions and strategy classes.
"""
