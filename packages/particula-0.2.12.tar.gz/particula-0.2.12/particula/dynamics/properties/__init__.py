"""Shared dynamic-property utilities."""
