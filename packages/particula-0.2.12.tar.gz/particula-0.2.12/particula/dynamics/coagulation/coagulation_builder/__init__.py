"""Builder utilities for coagulation models."""
