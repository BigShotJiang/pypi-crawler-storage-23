"""Coagulation kernel strategy implementations."""
