"""Particle-resolved coagulation step sub-package."""
