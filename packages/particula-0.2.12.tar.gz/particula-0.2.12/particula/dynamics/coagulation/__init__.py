"""Coagulation dynamics sub-package."""
