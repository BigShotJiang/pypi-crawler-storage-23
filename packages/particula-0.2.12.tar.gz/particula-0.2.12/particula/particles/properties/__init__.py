"""Particle property utilities."""
