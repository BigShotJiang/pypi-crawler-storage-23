"""Gas-phase property utilities."""
