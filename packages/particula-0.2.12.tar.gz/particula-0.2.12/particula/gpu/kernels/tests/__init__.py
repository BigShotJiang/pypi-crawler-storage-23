"""Tests for GPU kernels."""
