"""Tests for GPU property functions."""
