"""Tests for GPU data types and operations."""
