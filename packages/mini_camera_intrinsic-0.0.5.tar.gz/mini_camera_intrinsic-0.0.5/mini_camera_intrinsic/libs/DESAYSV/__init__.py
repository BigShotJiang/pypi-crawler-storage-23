# -*- coding: utf-8 -*-
"""DESAYSV 相机内参解析（log + camera_id 映射）."""

from .parser import parse

__all__ = ["parse"]
