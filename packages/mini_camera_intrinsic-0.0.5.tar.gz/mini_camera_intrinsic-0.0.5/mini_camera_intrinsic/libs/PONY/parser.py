# -*- coding: utf-8 -*-
"""
PONY 相机内参解析：从 log 文件（含 EEPROM 512 字节）解析，返回与 D02 单组内参同构的 List[dict]。
参考：calib_func/XZT_intrinsic_convert (caminfo_parser + convert_protobuf)。

V0.0.5：支持多 log，按 frame_id 聚合，每相机最多 5 条，选出现次数最多的参数。
"""

import os
import struct
import zlib
from collections import defaultdict
from typing import Dict, List, Optional, Tuple

from ..._types import intrinsic_item_to_d2_format

_ROUND_PRECISION = 6
_MAX_RECORDS_PER_CAMERA = 5


def _bytes_to_double(byte_list: List[int]) -> float:
    if len(byte_list) != 8:
        raise ValueError("Exactly 8 bytes required")
    return struct.unpack("<d", bytes(byte_list))[0]


def _compute_crc32(data_bytes: List[int]) -> int:
    return zlib.crc32(bytes(data_bytes)) & 0xFFFFFFFF


class _CameraMatrix:
    """192 bytes from offset 96 in 512-byte EEPROM block."""

    def __init__(self, data: List[int]):
        if len(data) != 192:
            raise ValueError("Expected 192 bytes for CameraMatrix")
        self.data = data
        self.width = (data[1] << 8) | data[0]
        self.height = (data[3] << 8) | data[2]
        self.distortion_model = data[4]
        self.fx = _bytes_to_double(data[5:13])
        self.fy = _bytes_to_double(data[13:21])
        self.cx = _bytes_to_double(data[21:29])
        self.cy = _bytes_to_double(data[29:37])
        self.pinhole_k1 = _bytes_to_double(data[37:45])
        self.pinhole_k2 = _bytes_to_double(data[45:53])
        self.pinhole_p1 = _bytes_to_double(data[53:61])
        self.pinhole_p2 = _bytes_to_double(data[61:69])
        self.pinhole_k3 = _bytes_to_double(data[69:77])
        self.pinhole_k4 = _bytes_to_double(data[77:85])
        self.pinhole_k5 = _bytes_to_double(data[85:93])
        self.pinhole_k6 = _bytes_to_double(data[93:101])
        self.fisheye_k1 = _bytes_to_double(data[101:109])
        self.fisheye_k2 = _bytes_to_double(data[109:117])
        self.fisheye_k3 = _bytes_to_double(data[117:125])
        self.fisheye_k4 = _bytes_to_double(data[125:133])
        crc = struct.unpack("<I", bytes(data[-4:]))[0]
        if crc != _compute_crc32(data[:-4]):
            raise ValueError("CameraMatrix CRC32 check failed")


def _parse_pony_log(file_path: str) -> Dict[str, dict]:
    """
    从 PONY log 解析出每个相机的 frame_id 与 512 字节 EEPROM data。
    返回 { camera_name: { "frame_id": str, "data": list of int } }。
    """
    cameras: Dict[str, dict] = {}
    current_camera = None
    collecting_data = False
    data_lines_collected = 0
    expected_lines = 32  # 512 bytes / 16 bytes per line

    with open(file_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            if "Match pipeline" in line and "read camera inrinsic" in line:
                parts = line.split()
                for part in parts:
                    if part.startswith("CameraDeviceGroup"):
                        current_camera = part.rstrip(":")[:-1]
                        cameras[current_camera] = {"frame_id": "", "data": []}
                        collecting_data = False
                        data_lines_collected = 0
                        break
            elif "Frame id" in line and current_camera:
                cameras[current_camera]["frame_id"] = line.split(":")[-1].strip()
            elif "EEPROM data length:  512" in line:
                collecting_data = True
            elif collecting_data and line.strip().startswith("0x"):
                hex_values = line.strip().split()
                byte_values = [int(h, 16) for h in hex_values]
                cameras[current_camera]["data"].extend(byte_values)
                data_lines_collected += 1
                if data_lines_collected >= expected_lines:
                    collecting_data = False

    return cameras


def _camera_data_to_d2_item(
    frame_id: str, data_512: List[int]
) -> dict:
    """将单相机 512 字节转为 D02 单组内参 dict。"""
    matrix = _CameraMatrix(data_512[96:288])
    width = matrix.width
    height = matrix.height
    intrinsic = [
        matrix.fx,
        0.0,
        matrix.cx,
        0.0,
        matrix.fy,
        matrix.cy,
        0.0,
        0.0,
        1.0,
    ]
    if matrix.distortion_model == 1:  # pinhole
        model_type = "PINHOLE"
        distortion = [
            matrix.pinhole_k1,
            matrix.pinhole_k2,
            matrix.pinhole_p1,
            matrix.pinhole_p2,
            matrix.pinhole_k3,
            matrix.pinhole_k4,
            matrix.pinhole_k5,
            matrix.pinhole_k6,
        ]
        use_pinhole = True
    elif matrix.distortion_model == 2:  # fisheye
        model_type = "FISHEYE"
        distortion = [
            matrix.fisheye_k1,
            matrix.fisheye_k2,
            matrix.fisheye_k3,
            matrix.fisheye_k4,
        ]
        use_pinhole = False
    else:
        model_type = "PINHOLE"
        distortion = [
            matrix.pinhole_k1,
            matrix.pinhole_k2,
            matrix.pinhole_p1,
            matrix.pinhole_p2,
            matrix.pinhole_k3,
            matrix.pinhole_k4,
            matrix.pinhole_k5,
            matrix.pinhole_k6,
        ]
        use_pinhole = True

    return intrinsic_item_to_d2_format(
        frame_id=frame_id,
        model_type=model_type,
        width=width,
        height=height,
        intrinsic=intrinsic,
        distortion=distortion,
        use_pinhole=use_pinhole,
    )


def _param_signature(item: dict) -> Tuple:
    """将内参 dict 转为可哈希 key，用于频次统计。浮点数四舍五入到 6 位。"""
    ph = item.get("pinhole") or item.get("fisheye")
    if not ph:
        return ()
    intrinsic = ph.get("intrinsic", [])
    distortion = ph.get("distortion", [])
    int_tup = tuple(round(float(x), _ROUND_PRECISION) for x in intrinsic)
    dist_tup = tuple(round(float(x), _ROUND_PRECISION) for x in distortion)
    return (item.get("model_type", ""), int_tup, dist_tup)


def _completeness_score(item: dict) -> int:
    """数据最全得分：intrinsic 非零数 + distortion 非零数，越大越全。"""
    ph = item.get("pinhole") or item.get("fisheye")
    if not ph:
        return 0
    intrinsic = ph.get("intrinsic", [])
    distortion = ph.get("distortion", [])
    count = sum(1 for x in intrinsic if x and abs(float(x)) > 1e-10)
    count += sum(1 for x in distortion if x is not None and abs(float(x)) > 1e-10)
    return count


def _aggregate_intrinsics(
    records: List[dict],
    max_per_camera: int = _MAX_RECORDS_PER_CAMERA,
) -> List[dict]:
    """
    按 frame_id 聚合：每相机最多 max_per_camera 条，选出现次数最多的参数；
    次数相同时选数据最全的一条。每个相机只输出一次。
    """
    by_frame: Dict[str, List[dict]] = defaultdict(list)
    for rec in records:
        fid = rec.get("frame_id", "").strip()
        if not fid:
            continue
        lst = by_frame[fid]
        if len(lst) < max_per_camera:
            lst.append(rec)

    result: List[dict] = []
    for frame_id, items in by_frame.items():
        if not items:
            continue
        sig_counts: Dict[Tuple, List[dict]] = defaultdict(list)
        for it in items:
            sig = _param_signature(it)
            sig_counts[sig].append(it)
        best_sig = max(sig_counts.keys(), key=lambda s: len(sig_counts[s]))
        candidates = sig_counts[best_sig]
        best = max(candidates, key=_completeness_score)
        result.append(best)
    return result


def _parse_single_log_to_items(path: str, tag_source: bool = False) -> List[dict]:
    """解析单个 log 文件，返回 List[dict]。tag_source=True 时附加 _source_file。"""
    cameras = _parse_pony_log(path)
    result: List[dict] = []
    for _name, info in cameras.items():
        frame_id = info.get("frame_id", "").strip()
        data = info.get("data", [])
        if not frame_id or len(data) != 512:
            continue
        try:
            item = _camera_data_to_d2_item(frame_id, data)
            if tag_source:
                item["_source_file"] = path
            result.append(item)
        except (ValueError, IndexError):
            continue
    return result


def _aggregate_intrinsics_with_stats(
    records: List[dict],
    max_per_camera: int = _MAX_RECORDS_PER_CAMERA,
) -> Tuple[List[dict], dict]:
    """
    按 frame_id 聚合并返回统计与预警。
    返回 (List[dict], stats_dict)，stats 含 count_by_frame、warnings。
    """
    by_frame: Dict[str, List[dict]] = defaultdict(list)
    for rec in records:
        fid = rec.get("frame_id", "").strip()
        if not fid:
            continue
        lst = by_frame[fid]
        if len(lst) < max_per_camera:
            lst.append(rec)

    result: List[dict] = []
    count_by_frame: Dict[str, List[dict]] = {}
    warnings: List[dict] = []

    for frame_id, items in by_frame.items():
        if not items:
            continue
        sig_to_items: Dict[Tuple, List[dict]] = defaultdict(list)
        for it in items:
            sig = _param_signature(it)
            sig_to_items[sig].append(it)
        best_sig = max(sig_to_items.keys(), key=lambda s: len(sig_to_items[s]))
        candidates = sig_to_items[best_sig]
        best = max(candidates, key=_completeness_score)
        out_item = {k: v for k, v in best.items() if k != "_source_file"}
        result.append(out_item)

        groups = []
        for sig, group in sig_to_items.items():
            files = []
            for it in group:
                f = it.get("_source_file")
                if f and f not in files:
                    files.append(f)
            groups.append({"count": len(group), "files": sorted(files)})
        count_by_frame[frame_id] = groups

        if len(sig_to_items) > 1:
            dominant = {"count": len(sig_to_items[best_sig]), "files": []}
            for it in sig_to_items[best_sig]:
                f = it.get("_source_file")
                if f and f not in dominant["files"]:
                    dominant["files"].append(f)
            dominant["files"] = sorted(dominant["files"])
            others = []
            for sig, group in sig_to_items.items():
                if sig == best_sig:
                    continue
                files = []
                for it in group:
                    f = it.get("_source_file")
                    if f and f not in files:
                        files.append(f)
                others.append({"count": len(group), "files": sorted(files)})
            warnings.append(
                {
                    "frame_id": frame_id,
                    "message": "参数不一致，存在多种取值",
                    "dominant": dominant,
                    "others": others,
                }
            )

    return result, {"count_by_frame": count_by_frame, "warnings": warnings}


def parse(
    log_path: str = "",
    file_path: str = "",
    log_paths: Optional[List[str]] = None,
    return_stats: bool = False,
):
    """
    解析 PONY log 文件，返回 List[dict]，每项与 D02 单组内参 YAML 同构。

    入参：log_paths（多文件）或 log_path/file_path（单文件，二选一）。
    多 log 时按 frame_id 聚合，每相机最多 5 条，选出现次数最多的参数。
    return_stats=True 时返回 (List[dict], stats_dict)，stats 含 count_by_frame、warnings。
    """
    paths: List[str] = []
    if log_paths:
        paths = list(log_paths)
    elif log_path or file_path:
        paths = [log_path or file_path]

    if not paths:
        raise ValueError("PONY requires log_paths, or log_path/file_path")

    for p in paths:
        if not os.path.isfile(p):
            raise FileNotFoundError(f"Log file not found: {p}")

    need_stats = return_stats
    all_records: List[dict] = []
    for p in paths:
        all_records.extend(_parse_single_log_to_items(p, tag_source=need_stats))

    if len(paths) > 1:
        if return_stats:
            result, stats = _aggregate_intrinsics_with_stats(all_records)
            return result, stats
        return _aggregate_intrinsics(all_records)
    if return_stats:
        count_by_frame = {}
        for rec in all_records:
            fid = rec.get("frame_id", "").strip()
            if fid:
                count_by_frame[fid] = [
                    {"count": 1, "files": [rec.get("_source_file", paths[0])]}
                ]
            rec.pop("_source_file", None)
        return all_records, {"count_by_frame": count_by_frame, "warnings": []}
    for rec in all_records:
        rec.pop("_source_file", None)
    return all_records
