import os
from pathlib import Path
from typing import Dict, List, Tuple


def _ensure_dir(root_dir: str, model_name: str) -> Path:
    path = Path(root_dir)
    if not path.exists() or not path.is_dir():
        raise ValueError(f"{model_name} root_dir must be an existing directory")
    return path


def discover_desaysv_inputs(root_dir: str) -> Tuple[List[str], str]:
    """
    在 root_dir 下递归查找 DESAYSV 所需的 log_paths 和 camera_id_path。

    :param root_dir: 根目录路径（支持相对或绝对路径）
    :return: (log_paths, camera_id_path)
    """
    base = _ensure_dir(root_dir, "DESAYSV")

    log_paths: List[str] = []
    camera_id_files: List[str] = []

    for dirpath, _dirnames, filenames in os.walk(base):
        for name in filenames:
            lower_name = name.lower()
            # log 文件
            if lower_name.endswith(".log"):
                log_paths.append(str(Path(dirpath) / name))
            # camera_id 文件：名称以 camera_id 开头（兼容 camera_id / camera_id_xxx）
            if name.startswith("camera_id"):
                camera_id_files.append(str(Path(dirpath) / name))

    if not log_paths:
        raise ValueError("DESAYSV: no .log files found under root_dir")

    if not camera_id_files:
        raise ValueError("DESAYSV: camera_id file not found under root_dir")

    if len(camera_id_files) > 1:
        raise ValueError(
            "DESAYSV: multiple camera_id files found under root_dir, please specify explicitly"
        )

    return sorted(log_paths), camera_id_files[0]


def discover_pony_inputs(root_dir: str) -> List[str]:
    """
    在 root_dir 下递归查找 PONY 所需的 log 文件列表。

    优先匹配 *.INFO*，若没有则回退到 *.log*。
    """
    base = _ensure_dir(root_dir, "PONY")

    info_candidates: List[str] = []
    log_candidates: List[str] = []

    for dirpath, _dirnames, filenames in os.walk(base):
        for name in filenames:
            # 优先 *.INFO*
            if ".INFO" in name:
                info_candidates.append(str(Path(dirpath) / name))
            elif ".log" in name:
                log_candidates.append(str(Path(dirpath) / name))

    candidates = info_candidates or log_candidates
    if not candidates:
        raise ValueError("PONY: no INFO/log files found under root_dir")

    return sorted(candidates)


DISCOVERY_HANDLERS: Dict[str, object] = {
    "DESAYSV": discover_desaysv_inputs,
    "PONY": discover_pony_inputs,
}

