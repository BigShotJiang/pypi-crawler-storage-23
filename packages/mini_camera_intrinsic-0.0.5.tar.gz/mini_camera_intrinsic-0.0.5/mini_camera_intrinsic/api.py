# -*- coding: utf-8 -*-
"""
顶层 API：parse_intrinsics(camera_model, **kwargs)、save_intrinsics_to_dir(intrinsics_list, output_dir)。
相机型号到解析器硬编码映射。
"""

import copy
from pathlib import Path
from typing import Any, Dict, List, Tuple, Union

import yaml

from .libs.DESAYSV.parser import parse as parse_desay_sv
from .libs.PONY.parser import parse as parse_pony
from .libs.discovery import (
    DISCOVERY_HANDLERS,
    discover_desaysv_inputs,
    discover_pony_inputs,
)

CAMERA_MODEL_DESAYSV = "DESAYSV"
CAMERA_MODEL_PONY = "PONY"

_SUPPORTED_MODELS = (CAMERA_MODEL_DESAYSV, CAMERA_MODEL_PONY)


def parse_intrinsics(
    camera_model: str,
    return_stats: bool = False,
    **kwargs: Any,
) -> Union[List[dict], Tuple[List[dict], dict]]:
    """
    按相机型号解析内参，返回 List[dict]，每项与 D02 单组内参 YAML 同构。

    :param camera_model: "DESAYSV" | "PONY"
    :param return_stats: 仅 PONY 支持；True 时返回 (items, stats)
    :param kwargs: DESAYSV: log_dir 或 log_paths, camera_id_path 或 camera_id_mapping
                  PONY: log_paths（多文件）或 log_path/file_path（单文件）
    :return: List[dict] 或 (List[dict], dict)（PONY 且 return_stats=True 时）
    """
    if camera_model not in _SUPPORTED_MODELS:
        raise ValueError(
            f"Unsupported camera_model: {camera_model!r}. "
            f"Supported: {list(_SUPPORTED_MODELS)}"
        )
    if camera_model == CAMERA_MODEL_DESAYSV:
        return parse_desay_sv(**kwargs)
    if camera_model == CAMERA_MODEL_PONY:
        return parse_pony(return_stats=return_stats, **kwargs)
    return []


def parse_intrinsics_from_dir(
    camera_model: str,
    root_dir: str,
    return_stats: bool = False,
    **kwargs: Any,
) -> Union[List[dict], Tuple[List[dict], dict]]:
    """
    按相机型号 + 根目录自动发现输入文件并解析内参。

    :param camera_model: "DESAYSV" | "PONY"
    :param root_dir: 根目录路径（包含 log / camera_id 等文件，可为相对或绝对路径）
    :param return_stats: 仅 PONY 支持；True 时返回 (items, stats)，stats 含 count_by_frame、warnings
    :param kwargs: 预留扩展用的可选参数（当前未使用）
    :return: List[dict] 或 (List[dict], dict)（PONY 且 return_stats=True 时）
    """
    if camera_model not in _SUPPORTED_MODELS:
        raise ValueError(
            f"Unsupported camera_model: {camera_model!r}. "
            f"Supported: {list(_SUPPORTED_MODELS)}"
        )

    # 使用按型号划分的 discovery 函数进行目录扫描
    handler = DISCOVERY_HANDLERS.get(camera_model)
    if handler is None:
        raise ValueError(
            f"No discovery handler registered for camera_model: {camera_model!r}"
        )

    if camera_model == CAMERA_MODEL_DESAYSV:
        log_paths, camera_id_path = discover_desaysv_inputs(root_dir)
        return parse_intrinsics(
            CAMERA_MODEL_DESAYSV,
            log_paths=log_paths,
            camera_id_path=camera_id_path,
            **kwargs,
        )

    if camera_model == CAMERA_MODEL_PONY:
        log_paths = discover_pony_inputs(root_dir)
        return parse_intrinsics(
            CAMERA_MODEL_PONY,
            log_paths=log_paths,
            return_stats=return_stats,
            **kwargs,
        )

    return []


class _FlowList(list):
    """YAML 输出时列表以方括号单行显示。"""


def _flow_list_representer(dumper: yaml.Dumper, data: _FlowList) -> Any:
    return dumper.represent_sequence("tag:yaml.org,2002:seq", data, flow_style=True)


class _IntrinsicsYamlDumper(yaml.SafeDumper):
    pass


_IntrinsicsYamlDumper.add_representer(_FlowList, _flow_list_representer)


def save_intrinsics_to_dir(
    intrinsics_list: List[dict],
    output_dir: str,
) -> None:
    """
    将内参列表写入 output_dir/intrinsics/*.yaml，格式与 D02 解析 pb 后写出的一致。

    :param intrinsics_list: parse_intrinsics(...) 的返回值
    :param output_dir: 输出根目录，其下会创建 intrinsics/ 并写入 <frame_id>.yaml
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    intrinsics_dir = out / "intrinsics"
    intrinsics_dir.mkdir(exist_ok=True)

    for item in intrinsics_list:
        fid = item.get("frame_id", "unknown")
        safe_name = fid.replace("/", "_")
        out_item = copy.deepcopy(item)
        for model_key in ("pinhole", "fisheye"):
            ph = out_item.get(model_key) or {}
            if "intrinsic" in ph and isinstance(ph["intrinsic"], list):
                ph["intrinsic"] = _FlowList(ph["intrinsic"])
            if "distortion" in ph and isinstance(ph["distortion"], list):
                ph["distortion"] = _FlowList(ph["distortion"])
        path = intrinsics_dir / f"{safe_name}.yaml"
        with open(path, "w", encoding="utf-8") as f:
            yaml.dump(
                out_item,
                f,
                allow_unicode=True,
                default_flow_style=False,
                sort_keys=False,
                Dumper=_IntrinsicsYamlDumper,
            )
