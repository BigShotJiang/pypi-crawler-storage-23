# mini-camera-intrinsic

按相机型号解析内参，返回统一字典；支持保存为与 D02（pb_calibration）一致的本地 YAML 格式。

## 安装

```bash
pip install mini-camera-intrinsic
```

## 功能

- **parse_intrinsics_from_dir(camera_model, root_dir, **kwargs)**：按相机型号 + 根目录自动遍历子目录，发现对应格式的 log / camera_id 后调用上层解析逻辑，返回 `List[dict]`。
- **save_intrinsics_to_dir(intrinsics_list, output_dir)**：将上述列表写入 `output_dir/intrinsics/*.yaml`。

支持的相机型号（硬编码）：`DESAYSV`、`PONY`。

## 快速开始：按目录自动解析（统一方式）

当你已经有一整个相机日志目录（例如本仓库的 `tests/fixtures`），可以仅传入根目录，由库内部自动遍历子文件夹并发现需要的 log / camera_id 文件：

```python
from mini_camera_intrinsic import (
    CAMERA_MODEL_DESAYSV,
    CAMERA_MODEL_PONY,
    parse_intrinsics_from_dir,
    save_intrinsics_to_dir,
)

# DESAYSV：传入包含 .log 和 camera_id 的根目录
items_desay = parse_intrinsics_from_dir(
    CAMERA_MODEL_DESAYSV,
    root_dir="./tests/fixtures/DESAYSV",  # 相对路径或绝对路径均可
)

# PONY：传入包含 pony log 的根目录
items_pony = parse_intrinsics_from_dir(
    CAMERA_MODEL_PONY,
    root_dir="./tests/fixtures/PONY",
)

# 统一保存为 D02 风格的 YAML
save_intrinsics_to_dir(items_desay, "./output_desay")
save_intrinsics_to_dir(items_pony, "./output_pony")
```

典型工程用法：只要日志目录结构与 `tests/fixtures` 类似（DESAYSV 目录下有若干 `*.log` 和一个 `camera_id` 文件，PONY 目录下有 `*.INFO*` 或 `*.log*`），即可直接将该目录路径作为 `root_dir` 传入。

### 返回格式（dict）

每条内参与 D02 单组 intrinsic YAML 一致，例如：

- `frame_id`: str  
- `model_type`: `"PINHOLE"` | `"FISHEYE"`  
- `pinhole`（或 `fisheye`）: `width`, `height`, `intrinsic`（9 个数）, `distortion`（4 或 8 个数）

便于 API 调用与 `save_intrinsics_to_dir` 入参。

## 依赖

- Python >= 3.10  
- PyYAML >= 6.0  

## License

MIT
