"""
The :mod:`skfb.core` module implements core components such as NDArray to store
predictions and fallbacks.
"""
