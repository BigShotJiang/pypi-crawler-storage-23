"""The :mod:`skfb.utils` module includes validation tools."""

__all__ = ("check_X_y_sample_weight",)

from ._validation import check_X_y_sample_weight
