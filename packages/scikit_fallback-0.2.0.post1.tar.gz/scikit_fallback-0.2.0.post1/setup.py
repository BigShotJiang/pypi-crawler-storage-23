#! /usr/bin/env python
"""Installs scikit-fallback following ``pyproject.toml``."""

from setuptools import setup


if __name__ == "__main__":
    setup()
