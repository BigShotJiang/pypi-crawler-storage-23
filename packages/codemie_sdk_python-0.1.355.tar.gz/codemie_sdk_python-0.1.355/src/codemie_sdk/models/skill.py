"""Models for skill-related data structures."""

from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field

from .common import User


class SkillVisibility(str, Enum):
    """Skill visibility options."""

    PROJECT = "project"
    PRIVATE = "private"
    PUBLIC = "public"


class SkillCategory(BaseModel):
    """Skill category model."""

    model_config = ConfigDict(extra="ignore")

    value: str  # Category value (e.g., "development", "testing")
    label: str  # Human-readable label (e.g., "Development", "Testing")
    description: Optional[str] = None


class SkillBase(BaseModel):
    """Base skill model."""

    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    description: str
    project: str
    visibility: SkillVisibility
    categories: List[str] = Field(default_factory=list)
    created_date: datetime = Field(alias="createdDate")


class SkillListResponse(SkillBase):
    """Skill list item response."""

    created_by: Optional[User] = Field(None, alias="created_by")
    updated_date: Optional[datetime] = Field(None, alias="updatedDate")
    is_attached: Optional[bool] = Field(None, alias="is_attached")
    reactions_count: Optional[int] = Field(None, alias="reactionsCount")
    assistants_count: Optional[int] = Field(None, alias="assistantsCount")


class SkillDetailResponse(SkillListResponse):
    """Full skill details response."""

    content: str
    slug: Optional[str] = None
    icon_url: Optional[str] = Field(None, alias="iconUrl")


class SkillCreateRequest(BaseModel):
    """Request to create a skill."""

    name: str
    description: str
    content: str
    project: str
    visibility: Optional[SkillVisibility] = SkillVisibility.PROJECT
    categories: Optional[List[str]] = Field(default_factory=list)


class SkillUpdateRequest(BaseModel):
    """Request to update a skill."""

    name: Optional[str] = None
    description: Optional[str] = None
    content: Optional[str] = None
    project: Optional[str] = None
    visibility: Optional[SkillVisibility] = None
    categories: Optional[List[str]] = None


class SkillImportRequest(BaseModel):
    """Request to import a skill from .md file."""

    file_content: str
    filename: str
    project: str
    visibility: Optional[SkillVisibility] = SkillVisibility.PROJECT


class SkillAttachRequest(BaseModel):
    """Request to attach skill to assistant."""

    skill_id: str


class SkillBulkAttachRequest(BaseModel):
    """Request to bulk attach skill to assistants."""

    assistant_ids: List[str]


class SkillListPaginatedResponse(BaseModel):
    """Paginated list of skills."""

    model_config = ConfigDict(extra="ignore")

    skills: List[SkillListResponse]
    page: int
    per_page: int = Field(alias="perPage")
    total: int
    pages: int


class SkillReactionResponse(BaseModel):
    """Skill reaction response."""

    model_config = ConfigDict(extra="ignore")

    resource_id: str = Field(alias="resourceId")
    reaction: str
    reaction_at: str = Field(alias="reactionAt")
    resource_type: Optional[str] = Field(None, alias="resourceType")
