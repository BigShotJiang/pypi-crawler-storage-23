from .linear import FourOverSixLinear

__all__ = ["FourOverSixLinear"]
