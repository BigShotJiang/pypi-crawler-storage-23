from .frontend import fp4_matmul

__all__ = ["fp4_matmul"]
