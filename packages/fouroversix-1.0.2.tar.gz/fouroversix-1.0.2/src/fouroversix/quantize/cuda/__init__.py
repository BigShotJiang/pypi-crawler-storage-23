from .backend import CUDAQuantizeBackend

__all__ = ["CUDAQuantizeBackend"]
