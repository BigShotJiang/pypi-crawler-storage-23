"""
Tool registration modules.

Each module exposes `register(mcp, Context)` which defines `gm_*` tools on the provided FastMCP instance.
"""

