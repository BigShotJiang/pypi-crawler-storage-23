"""Flow Platform SDK - Python SDK for interacting with the Uniphore Platform API.

Public API:
    from flow_platform_sdk import platform_api

    # Use the service directly
    result = await platform_api.list_connectors()
"""

from .services.platform_api import PlatformApiService

# Singleton service instance
platform_api = PlatformApiService()

__version__ = "1.0.0"
__all__ = ["platform_api"]
