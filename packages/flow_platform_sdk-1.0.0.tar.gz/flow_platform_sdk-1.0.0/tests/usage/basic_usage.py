"""Basic usage example - shows how to use the SDK."""

import asyncio

from flow_platform_sdk import platform_api


async def main():
    """Basic SDK usage example."""
    # Data Connectors
    print("=== Listing Connectors ===")
    connectors = await platform_api.list_connectors()
    print(f"Available connectors: {connectors}\n")

    # Get schema
    print("=== Getting Schema ===")
    schema = await platform_api.get_schema(connector_id="conn_123")
    print(f"Schema: {schema}\n")

    # Execute query
    print("=== Executing Query ===")
    result = await platform_api.execute_query(
        connector_id="conn_123",
        sql_query="SELECT * FROM customers LIMIT 10",
        max_rows=10,
    )
    print(f"Query result: {result}\n")

    # Knowledge Base
    print("=== Listing Knowledge Bases ===")
    kbs = await platform_api.list_knowledge_bases()
    print(f"Knowledge bases: {kbs}\n")

    # Query knowledge base
    print("=== Querying Knowledge Base ===")
    answer = await platform_api.query_knowledge_base(
        knowledge_base_id="kb_123",
        query="What is the company revenue?",
    )
    print(f"Answer: {answer}")


if __name__ == "__main__":
    asyncio.run(main())
