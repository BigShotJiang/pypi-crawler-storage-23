from __future__ import annotations

from typing import Any

import click


class CommaSeparatedChoice(click.Choice):
    def convert(
        self,
        value: str,
        param: click.Parameter | None,
        ctx: click.Context | None,
    ) -> list[str] | None:
        pieces = value.split(",")
        return [super(click.Choice, self).convert(piece, param, ctx) for piece in pieces]


class CustomUsageArgsCommand(click.Command):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self._usage_args = kwargs.pop("usage_args")
        super().__init__(*args, **kwargs)

    def format_usage(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        if self._usage_args:
            formatter.write_usage(ctx.command_path, self._usage_args)
        else:
            super().format_usage(ctx, formatter)
