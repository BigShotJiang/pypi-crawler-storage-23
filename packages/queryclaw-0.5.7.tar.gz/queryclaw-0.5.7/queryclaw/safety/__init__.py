"""Safety layer for QueryClaw — policy, validation, dry-run, audit."""
