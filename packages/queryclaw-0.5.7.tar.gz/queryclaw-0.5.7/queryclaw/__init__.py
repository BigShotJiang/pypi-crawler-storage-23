"""QueryClaw — AI-Native Database Agent for Safe & Autonomous Operations."""

__version__ = "0.5.7"
