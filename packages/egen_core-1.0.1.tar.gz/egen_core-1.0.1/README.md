<p align="center">
  <img src="https://i.ibb.co/5X8LK2TQ/ATHENA-PROJECT.png" alt="Athena Project" width="400"/>
</p>

<h1 align="center">EGen-Core</h1>

<p align="center">
  <strong>The Athena Project (2025–2026)</strong> — Memory-efficient LLM inference engine.<br/>
  Run 70B+ models on 4GB VRAM. No quantization required.<br/>
  Developed by <a href="https://github.com/ErebusTN">ErebusTN</a>.
</p>

<p align="center">
  <a href="https://pypi.org/project/EGen-Core/"><img src="https://img.shields.io/pypi/v/EGen-Core?color=blue&logo=pypi" alt="PyPI"/></a>
  <a href="https://github.com/ErebusTN/EGen-Core/blob/main/LICENSE"><img src="https://img.shields.io/badge/License-MIT-green.svg" alt="License"/></a>
</p>

---

See the [main README](../README.md) for full documentation, installation, and usage instructions.

## Package Structure

```
egen_core/
├── __init__.py              # Public API exports
├── auto_model.py            # AutoModel architecture detection
├── egen_core_base.py        # Base model class (layer-wise inference)
├── egen_core_llama.py       # Llama/Llama2/Llama3 support
├── egen_core_chatglm.py     # ChatGLM support
├── egen_core_qwen.py        # QWen support
├── egen_core_qwen2.py       # QWen2 support
├── egen_core_baichuan.py    # Baichuan support
├── egen_core_internlm.py    # InternLM support
├── egen_core_mistral.py     # Mistral support
├── egen_core_mixtral.py     # Mixtral support
├── egen_core_llama_mlx.py   # Apple Silicon MLX backend
├── profiler.py              # Layer loading profiler
├── utils.py                 # Utilities (splitting, memory, compression)
├── tokenization_baichuan.py # Baichuan tokenizer
└── persist/                 # Model persistence backends
    ├── model_persister.py
    ├── safetensor_model_persister.py
    └── mlx_model_persister.py
```
