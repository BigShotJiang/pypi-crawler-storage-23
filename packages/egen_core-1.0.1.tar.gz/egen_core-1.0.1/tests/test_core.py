import pytest
from egen_core import AutoModel

def test_automodel_import():
    assert AutoModel is not None

def test_egen_core_initialization():
    print("EGen-Core test suite running.")
    assert True
