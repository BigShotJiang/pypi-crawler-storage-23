import sys
import unittest

#sys.path.insert(0, '../egen_core')

from ..egen_core.auto_model import AutoModel



class TestAutoModel(unittest.TestCase):
    def setUp(self):
        pass
    def tearDown(self):
        pass

    def test_auto_model_should_return_correct_model(self):
        mapping_dict = {
            'garage-bAInd/Platypus2-7B': 'EGenCoreLlama2',
            'Qwen/Qwen-7B': 'EGenCoreQWen',
            'internlm/internlm-chat-7b': 'EGenCoreInternLM',
            'THUDM/chatglm3-6b-base': 'EGenCoreChatGLM',
            'baichuan-inc/Baichuan2-7B-Base': 'EGenCoreBaichuan',
            'mistralai/Mistral-7B-Instruct-v0.1': 'EGenCoreMistral',
            'mistralai/Mixtral-8x7B-v0.1': 'EGenCoreMixtral'
        }


        for k,v in mapping_dict.items():
            module, cls = AutoModel.get_module_class(k)
            self.assertEqual(cls, v, f"expecting {v}")

