import sys
import setuptools
from setuptools.command.install import install
import subprocess


class PostInstallCommand(install):
    """Post-installation: upgrade transformers to latest version."""
    def run(self):
        install.run(self)
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "transformers"])
        except subprocess.CalledProcessError:
            print("Warning: Unable to upgrade transformers package. Please upgrade manually.")


with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="EGen-Core",
    version="1.0.1",
    author="ErebusTN",
    author_email="mouhebzayani@erebustn.io",
    description=(
        "EGen-Core — The Athena Project (2025–2026). A high-performance, memory-efficient "
        "inference engine for large language models. Run 70B+ parameter models on a single "
        "4GB GPU without quantization, distillation, or pruning. Supports layer-wise sharded "
        "inference, 4-bit/8-bit block-wise compression, multi-architecture auto-detection, "
        "and Apple Silicon (MLX) acceleration. Developed by ErebusTN."
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ErebusTN/EGen-Core",
    project_urls={
        "Bug Tracker": "https://github.com/ErebusTN/EGen-Core/issues",
        "Documentation": "https://github.com/ErebusTN/EGen-Core#readme",
        "Source Code": "https://github.com/ErebusTN/EGen-Core",
    },
    packages=setuptools.find_packages(),
    python_requires=">=3.8",
    install_requires=[
        'tqdm',
        'torch',
        'transformers',
        'accelerate',
        'safetensors',
        'optimum',
        'huggingface-hub',
        'scipy',
    ],
    extras_require={
        'compression': ['bitsandbytes'],
        'mlx': ['mlx', 'sentencepiece'],
    },
    cmdclass={
        'install': PostInstallCommand,
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
    ],
    keywords="llm inference memory-efficient large-language-model transformer sharded-inference",
)
