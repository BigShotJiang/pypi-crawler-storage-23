---
name: Feature Request
about: Suggest an improvement
labels: enhancement
---

## What problem does this solve?
<!-- Describe the pain point, not the solution -->

## Proposed solution
<!-- How would you like it to work? -->

## Alternatives considered
<!-- What else did you think about? -->

## Are you willing to implement this?
[ ] Yes  [ ] No  [ ] Maybe with guidance
