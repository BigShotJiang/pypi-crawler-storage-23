"""EchoTrace — The Voice AI Reliability Profiler."""

__version__ = "0.1.0"
