"""
EchoTrace Core.
Contains business logic, models, and telemetry.
Strictly decoupled from UI/TUI frameworks.
"""
