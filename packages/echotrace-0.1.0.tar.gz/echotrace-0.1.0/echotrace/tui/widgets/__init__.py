"""EchoTrace TUI widgets package."""
