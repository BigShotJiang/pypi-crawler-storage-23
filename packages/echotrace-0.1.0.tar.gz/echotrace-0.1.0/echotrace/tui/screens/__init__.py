"""
Screens package for EchoTrace TUI.
"""

from echotrace.tui.screens.main import MainScreen

__all__ = ["MainScreen"]
