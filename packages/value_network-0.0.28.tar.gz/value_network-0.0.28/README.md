## Value network (wip)

Exploration into some new research surrounding value networks

## Install

```bash
$ pip install value-network
```

## Usage

First, organize your videos (trajectories). The videos should have a suffix `.1` for success and `.0` for failure.

```text
.
├── data
│   ├── traj_0.1.mp4
│   ├── traj_1.0.mp4
│   └── traj_2.1.mp4
└── ...
```

### 1. Train

Train the `SigLIP` value network by passing the folder containing the videos. The tool will automatically handle the conversion.

```bash
$ value-network-cli train --trajectories-folder ./data --max-steps 1000 --model_output_path ./model.pt
```

You can also opt to use the `HL-Gauss` loss, which has been shown to be more scalable for value learning.

```bash
$ value-network-cli train --trajectories-folder ./data --loss-module hlgauss --hl-gauss-min -2 --hl-gauss-max 2 --hl-gauss-num-bins 100
```

### 2. Predict

Use the trained model to predict the value of any image

```bash
$ value-network-cli predict-value ./model.pt ./frame.png
```

If you trained with `HL-Gauss`, you must specify the loss module and any non-default parameters during prediction as well.

```bash
$ value-network-cli predict-value ./model.pt ./frame.png --loss-module hlgauss --hl-gauss-num-bins 100
```

### 3. Visualize

To visualize the predicted values over a video, you can use the `visualize` command. First, generate the `.npy` file using `predict-value` on a video, then run `visualize`.

```bash
$ value-network-cli predict-value ./model.pt ./video.mp4 --output-path ./values.npy
$ value-network-cli visualize ./video.mp4 ./values.npy
```

## Citations

```bibtex
@inproceedings{Imani2018ImprovingRP,
    title   = {Improving Regression Performance with Distributional Losses},
    author  = {Ehsan Imani and Martha White},
    booktitle = {International Conference on Machine Learning},
    year    = {2018},
    url     = {https://api.semanticscholar.org/CorpusID:48365278}
}
```

```bibtex
@article{Farebrother2024StopRT,
    title   = {Stop Regressing: Training Value Functions via Classification for Scalable Deep RL},
    author  = {Jesse Farebrother and Jordi Orbay and Quan Ho Vuong and Adrien Ali Taiga and Yevgen Chebotar and Ted Xiao and Alex Irpan and Sergey Levine and Pablo Samuel Castro and Aleksandra Faust and Aviral Kumar and Rishabh Agarwal},
    journal = {ArXiv},
    year   = {2024},
    volume = {abs/2403.03950},
    url    = {https://api.semanticscholar.org/CorpusID:268253088}
}
```

```bibtex
@misc{lee2025banelexplorationposteriorsgenerative,
    title    = {BaNEL: Exploration Posteriors for Generative Modeling Using Only Negative Rewards}, 
    author   = {Sangyun Lee and Brandon Amos and Giulia Fanti},
    year     = {2025},
    eprint   = {2510.09596},
    archivePrefix = {arXiv},
    primaryClass = {cs.LG},
    url      = {https://arxiv.org/abs/2510.09596}, 
}
```

```bibtex
@misc{ma2024visionlanguagemodelsincontext,
    title   = {Vision Language Models are In-Context Value Learners}, 
    author  = {Yecheng Jason Ma and Joey Hejna and Ayzaan Wahid and Chuyuan Fu and Dhruv Shah and Jacky Liang and Zhuo Xu and Sean Kirmani and Peng Xu and Danny Driess and Ted Xiao and Jonathan Tompson and Osbert Bastani and Dinesh Jayaraman and Wenhao Yu and Tingnan Zhang and Dorsa Sadigh and Fei Xia},
    year    = {2024},
    eprint  = {2411.04549},
    archivePrefix = {arXiv},
    primaryClass = {cs.RO},
    url     = {https://arxiv.org/abs/2411.04549}, 
}
```

```bibtex
@misc{yang2026riseselfimprovingrobotpolicy,
    title   = {RISE: Self-Improving Robot Policy with Compositional World Model}, 
    author  = {Jiazhi Yang and Kunyang Lin and Jinwei Li and Wencong Zhang and Tianwei Lin and Longyan Wu and Zhizhong Su and Hao Zhao and Ya-Qin Zhang and Li Chen and Ping Luo and Xiangyu Yue and Hongyang Li},
    year    = {2026},
    eprint  = {2602.11075},
    archivePrefix = {arXiv},
    primaryClass = {cs.RO},
    url     = {https://arxiv.org/abs/2602.11075}, 
}
```
