import torch
import pytest
from value_network import SigLIPValueNetwork

param = pytest.mark.parametrize

def test_value_network_output_shape():
    batch = 2
    image_size = 224
    
    net = SigLIPValueNetwork(
        siglip_depth = 2,
        siglip_dim = 128,
        siglip_heads = 4,
        siglip_mlp_dim = 256
    )

    # Input shape: (batch, channels, height, width)
    images = torch.randn(batch, 3, image_size, image_size)
    
    output = net(images)
    
    assert output.shape == (batch,)
    print(f"Output shape: {output.shape}")

@param('multiple_targets', (False, True))
def test_value_network_mse_loss(multiple_targets):
    batch = 4
    image_size = 224
    
    net = SigLIPValueNetwork(
        siglip_depth = 1,
        siglip_dim = 64,
        siglip_heads = 2,
        siglip_mlp_dim = 128
    )
    
    images = torch.randn(batch, 3, image_size, image_size)
    
    if multiple_targets:
        targets = (torch.randn(batch), torch.randn(batch))
    else:
        targets = torch.randn(batch)

    output = net(images, targets = targets)

    if multiple_targets:
        loss = sum(output)
    else:
        loss = output

    loss.backward()
