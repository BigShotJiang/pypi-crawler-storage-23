"""EDASuite - Lightweight EDA library for data analysis."""

from importlib.metadata import version, PackageNotFoundError

from edasuite.exceptions import (
    AnalysisError,
    ConfigurationError,
    DataLoadError,
    DataValidationError,
    EDASuiteError,
    FeatureTypeError,
    MissingDataError,
    OutputFormattingError,
    StabilityAnalysisError,
    TargetAnalysisError,
)
from edasuite.data.loader import DataLoader
from edasuite.schema import (
    ColumnConfig,
    ColumnRole,
    ColumnType,
    DatasetSchema,
    Sentinels,
)
from edasuite.eda import EDARunner
from edasuite.viewer import serve_results

try:
    __version__ = version("edasuite")
except PackageNotFoundError:
    __version__ = "0.0.5"

__author__ = "LattIQ Development Team"
__email__ = "dev@lattiq.com"

__all__ = [
    "EDARunner",
    # Viewer
    "serve_results",
    # Data Loading Utilities
    "DataLoader",
    # Schema types
    "ColumnConfig",
    "ColumnType",
    "ColumnRole",
    "Sentinels",
    "DatasetSchema",
    # Exceptions
    "EDASuiteError",
    "DataLoadError",
    "DataValidationError",
    "AnalysisError",
    "ConfigurationError",
    "FeatureTypeError",
    "MissingDataError",
    "StabilityAnalysisError",
    "OutputFormattingError",
    "TargetAnalysisError",
]
