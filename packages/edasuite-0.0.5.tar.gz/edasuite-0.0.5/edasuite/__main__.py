"""Allow running edasuite as a module: python -m edasuite."""

from edasuite.cli import main

main()
