"""Infrastructure utilities for EDASuite."""

from edasuite.utils.logger import get_logger

__all__ = ["get_logger"]
