"""Data I/O utilities for EDASuite."""

from edasuite.data.loader import DataLoader

__all__ = ["DataLoader"]
