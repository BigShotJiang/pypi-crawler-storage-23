"""EDASuite results viewer — serves an interactive browser dashboard."""

from edasuite.viewer.server import serve_results

__all__ = ["serve_results"]
