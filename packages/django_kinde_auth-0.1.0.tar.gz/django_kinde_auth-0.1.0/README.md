# django-kinde-auth

Reusable Django app for passwordless authentication via [Kinde](https://kinde.com). Drop-in plugin for any Django project.

## Install

```bash
pip install django-kinde-auth
```

Or with uv:

```bash
uv add django-kinde-auth
```

## Setup

1. **Add the app** to `INSTALLED_APPS`:

   ```python
   INSTALLED_APPS = [
       # ...
       "django_kinde_auth",
   ]
   ```

2. **Configure Kinde** (see [Kinde configuration](#kinde-configuration) below).

3. **Settings** (in Django settings or environment):
   - `KINDE_CLIENT_ID` – from Kinde Back-end app
   - `KINDE_CLIENT_SECRET` – from Kinde Back-end app
   - `KINDE_ISSUER_URL` – e.g. `https://<your_subdomain>.kinde.com`
   - `KINDE_CALLBACK_URL` – full URL of your callback (e.g. `https://yourapp.com/auth/callback/`)
   - `KINDE_LOGOUT_REDIRECT` – (optional) URL after logout, default `/`
   - `KINDE_LOGIN_REDIRECT` – (optional) URL after successful login, default `/`
   - `KINDE_REQUIRE_FOR_ADMIN` – (optional) when `True`, unauthenticated `/admin/` is redirected to Kinde; when `False`, use plain Django login. Default `False`. Set in settings or env (`KINDE_REQUIRE_FOR_ADMIN=true`).

4. **URLs** – include the app URLs (e.g. under `/auth/`):

   ```python
   path("auth/", include("django_kinde_auth.urls", namespace="kinde_auth")),
   ```

5. **Templates** – add the context processor so `kinde_authenticated` and `kinde_user` are available globally:

   ```python
   TEMPLATES[0]["OPTIONS"]["context_processors"].append(
       "django_kinde_auth.context_processors.kinde_auth"
   )
   ```

6. **Optional: require Kinde for admin** – add the middleware and set `KINDE_REQUIRE_FOR_ADMIN = True`:

   ```python
   MIDDLEWARE = [
       # ...
       "django_kinde_auth.middleware.RequireKindeLoginForAdminMiddleware",
   ]
   ```

## Usage in templates

- `{% if kinde_authenticated %}` … show logged-in UI; `kinde_user.full_name`, `kinde_user.email`, `kinde_user.initials`, etc.
- Sign in: `{% url 'kinde_auth:login' %}`
- Sign up: `{% url 'kinde_auth:register' %}`
- Sign out: `{% url 'kinde_auth:logout' %}`

## Usage in views

```python
from django_kinde_auth.views import get_user_context

def my_view(request):
    ctx = get_user_context(request)
    if not ctx["kinde_authenticated"]:
        return redirect("kinde_auth:login")
    # use ctx["kinde_user"]
```

## Kinde configuration

In the [Kinde dashboard](https://app.kinde.com) (Settings → Applications → your Back-end app):

1. **Callback URL** – Add the exact callback URL your app uses, e.g. `http://127.0.0.1:8000/auth/callback/` (local) or `https://yourdomain.com/auth/callback/` (production).
2. **Logout redirect URL** (if required) – e.g. `https://yourdomain.com/` or `http://127.0.0.1:8000/`.
3. **App keys** – Copy Client ID and Client Secret into your Django settings or env.
4. **Issuer** – Set `KINDE_ISSUER_URL` to `https://<your_subdomain>.kinde.com`.
5. **Passwordless** – In Kinde, configure the connection types you want (e.g. magic link, social).

## User creation and lifecycle

**Kinde is the source of truth.** Users are created or invited in Kinde (or self-register at `/auth/register/`). On first login we create the Django `User` automatically (username `kinde_<id>`, staff by default). To give admin access, set `is_staff`/`is_superuser` in Django after their first login, or set `KINDE_SYNC_SUPERUSER = True` in settings.

## Publishing (GitHub / PyPI)

- **GitHub:** Push the `django-kinde-auth/` directory to its own repo (or keep it in a monorepo).
- **PyPI:** From the `django-kinde-auth/` directory:
  ```bash
  pip install build twine
  python -m build
  twine upload dist/*
  ```
  Or with uv: `uv run build` then `uv run twine upload dist/*`. Bump `version` in `pyproject.toml` for each release.

## License

MIT
