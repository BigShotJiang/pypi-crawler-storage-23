"""Inject kinde_user, kinde_authenticated and kinde_require_for_admin into template context."""

from django.conf import settings

from .views import get_user_context


def kinde_auth(request):
    """Add kinde_authenticated, kinde_user and kinde_require_for_admin to every template."""
    ctx = get_user_context(request)
    ctx["kinde_require_for_admin"] = getattr(settings, "KINDE_REQUIRE_FOR_ADMIN", False)
    return ctx
