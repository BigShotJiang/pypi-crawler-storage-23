"""
Sync Kinde user to Django User and log in.

Used when you want Django admin (and request.user) to work with Kinde login.
"""

import re

from django.conf import settings
from django.contrib.auth import get_user_model, login

User = get_user_model()

# Username must be unique; Kinde id can contain chars we need to strip


def _username_from_kinde_id(kinde_id: str) -> str:
    safe = re.sub(r"[^\w\-.]", "_", str(kinde_id))[:150]
    return f"kinde_{safe}" if safe else "kinde_unknown"


def sync_kinde_user_and_login(
    request,
    kinde_user_id: str,
    email: str = "",
    first_name: str = "",
    last_name: str = "",
):
    """
    Get or create a Django User from Kinde identity and log them in.

    Uses username = kinde_<id>; sets email, first_name, last_name, is_staff (and
    optionally is_superuser from settings). Call from the Kinde callback after
    storing the Kinde session.
    """
    username = _username_from_kinde_id(kinde_user_id)
    is_staff = getattr(settings, "KINDE_SYNC_STAFF", True)
    is_superuser = getattr(settings, "KINDE_SYNC_SUPERUSER", False)
    user, created = User.objects.get_or_create(
        username=username,
        defaults={
            "email": (email or "").strip() or f"{username}@kinde.local",
            "first_name": (first_name or "").strip(),
            "last_name": (last_name or "").strip(),
            "is_staff": is_staff,
            "is_superuser": is_superuser,
            "is_active": True,
        },
    )
    if not created:
        user.email = (email or "").strip() or user.email
        user.first_name = (first_name or "").strip() or user.first_name
        user.last_name = (last_name or "").strip() or user.last_name
        user.is_staff = is_staff
        user.is_active = True
        user.save(
            update_fields=["email", "first_name", "last_name", "is_staff", "is_active"]
        )
    login(request, user, backend="django.contrib.auth.backends.ModelBackend")
    return user
