"""
Redirect unauthenticated admin visits to Kinde login.

Add this middleware when you want /admin/ to require Kinde authentication.
When Kinde is not configured (no KINDE_CLIENT_ID), admin uses normal Django login.
"""

from urllib.parse import quote

from django.shortcuts import redirect
from django.urls import reverse

from .conf import get_kinde_config


class RequireKindeLoginForAdminMiddleware:
    """
    If request path is under /admin/ and user is not authenticated,
    redirect to Kinde login with ?next= so they return to admin after login.
    No redirect when Kinde is not configured (so Django admin login still works).
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        from django.conf import settings
        if not getattr(settings, "KINDE_REQUIRE_FOR_ADMIN", False):
            return self.get_response(request)
        if not request.path.startswith("/admin/") or request.user.is_authenticated:
            return self.get_response(request)
        cfg = get_kinde_config(request)
        if not cfg.get("client_id"):
            return self.get_response(request)
        login_url = reverse("kinde_auth:login")
        next_url = quote(request.get_full_path())
        return redirect(f"{login_url}?next={next_url}")
