# Django app for Kinde passwordless authentication
