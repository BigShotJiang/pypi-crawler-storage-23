"""
Kinde OAuth views: login, register, callback, logout.

Session key for authenticated user id: kinde_user_id.
In-memory store of Kinde client per user (lean; replace with Redis/DB later if needed).
"""

from django.shortcuts import redirect, render
from django.urls import reverse

from .conf import get_kinde_config

# In-memory store: user_id -> {kinde_client, user_first_name, user_last_name, ...}
# Per-process; fine for single-worker dev. For production consider Redis/session-backed storage.
_user_clients = {}

SESSION_KEY_USER_ID = "kinde_user_id"


def _get_client_for_request(request):
    """Return Kinde API client for current session user or None."""
    user_id = request.session.get(SESSION_KEY_USER_ID)
    if not user_id:
        return None
    entry = _user_clients.get(user_id)
    return entry.get("kinde_client") if entry else None


def _get_new_client(request):
    """Build a new KindeApiClient from settings/env."""
    from kinde_sdk.kinde_api_client import GrantType, KindeApiClient

    cfg = get_kinde_config(request)
    if not cfg.get("client_id") or not cfg.get("issuer_url"):
        raise ValueError(
            "Kinde auth is not configured. Set KINDE_CLIENT_ID and KINDE_ISSUER_URL "
            "(and KINDE_CLIENT_SECRET, KINDE_CALLBACK_URL) in settings or environment."
        )
    return KindeApiClient(
        domain=cfg["issuer_url"],
        callback_url=cfg["callback_url"],
        client_id=cfg["client_id"],
        client_secret=cfg.get("client_secret") or "",
        grant_type=GrantType.AUTHORIZATION_CODE,
    )


def get_user_context(request):
    """
    Return a dict with kinde_user and kinde_authenticated for templates/context.

    Use in your views or add a context processor that injects these.
    """
    user_id = request.session.get(SESSION_KEY_USER_ID)
    if not user_id:
        return {"kinde_authenticated": False, "kinde_user": None}
    entry = _user_clients.get(user_id)
    if not entry:
        return {"kinde_authenticated": False, "kinde_user": None}
    client = entry.get("kinde_client")
    if not client or not client.is_authenticated():
        return {"kinde_authenticated": False, "kinde_user": None}
    first = entry.get("user_first_name") or ""
    last = entry.get("user_last_name") or ""
    initials = (first[:1] + (last[:1] if last else first[1:2])).upper() if first else ""
    return {
        "kinde_authenticated": True,
        "kinde_user": {
            "id": user_id,
            "first_name": first,
            "last_name": last,
            "full_name": f"{first} {last}".strip() or "User",
            "initials": initials or "?",
            "email": entry.get("user_email") or "",
        },
    }


def login(request):
    """Redirect to Kinde hosted login. Preserves ?next= in session for post-login redirect."""
    if request.session.get(SESSION_KEY_USER_ID):
        return redirect(request.session.get("kinde_next") or _login_redirect_default())
    next_url = request.GET.get("next", "").strip()
    if next_url and next_url.startswith("/"):
        request.session["kinde_next"] = next_url
    client = _get_new_client(request)
    return redirect(client.get_login_url())


def register(request):
    """Redirect to Kinde hosted registration."""
    if request.session.get(SESSION_KEY_USER_ID):
        return redirect(_login_redirect_default())
    client = _get_new_client(request)
    return redirect(client.get_register_url())


def callback(request):
    """Handle OAuth callback from Kinde: exchange code for tokens and store user."""
    if request.session.get(SESSION_KEY_USER_ID):
        return redirect(_login_redirect_default())
    try:
        client = _get_new_client(request)
    except ValueError as e:
        return _callback_error(request, str(e))
    try:
        client.fetch_token(authorization_response=request.build_absolute_uri())
    except Exception as e:  # noqa: BLE001
        return _callback_error(request, f"Token exchange failed: {e}")
    user_details = client.get_user_details()
    user_id = user_details.get("id") or user_details.get("sub")
    if not user_id:
        return _callback_error(request, "No user id in Kinde response.")
    request.session[SESSION_KEY_USER_ID] = user_id
    _user_clients[user_id] = {
        "kinde_client": client,
        "user_first_name": user_details.get("given_name"),
        "user_last_name": user_details.get("family_name"),
        "user_email": user_details.get("email"),
    }
    # Sync to Django User and log in so admin (and request.user) work
    from .django_sync import sync_kinde_user_and_login

    sync_kinde_user_and_login(
        request,
        kinde_user_id=user_id,
        email=user_details.get("email"),
        first_name=user_details.get("given_name"),
        last_name=user_details.get("family_name"),
    )
    redirect_to = request.session.pop("kinde_next", None) or _login_redirect_default()
    return redirect(redirect_to)


def _callback_error(request, message):
    """Render a minimal error page when callback fails (e.g. no user id)."""
    return render(
        request,
        "kinde_auth/callback_error.html",
        {"message": message},
        status=400,
    )


def _login_redirect_default():
    """Default URL after login (override via KINDE_LOGIN_REDIRECT or use /)."""
    import os

    from django.conf import settings

    url = (
        getattr(settings, "KINDE_LOGIN_REDIRECT", None)
        or os.environ.get("KINDE_LOGIN_REDIRECT")
        or "/"
    )
    return url


def logout(request):
    """Clear session and redirect to Kinde logout, then to KINDE_LOGOUT_REDIRECT."""
    from django.contrib.auth import logout as auth_logout

    user_id = request.session.get(SESSION_KEY_USER_ID)
    cfg = get_kinde_config(request)
    logout_redirect = cfg.get("logout_redirect") or "/"
    auth_logout(request)
    request.session.clear()
    if user_id and user_id in _user_clients:
        client = _user_clients[user_id].get("kinde_client")
        del _user_clients[user_id]
        if client:
            return redirect(client.logout(redirect_to=logout_redirect))
    return redirect(logout_redirect)
