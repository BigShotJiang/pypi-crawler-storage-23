"""
Kinde configuration from Django settings.

Host project should set these (e.g. from env):

  KINDE_CLIENT_ID
  KINDE_CLIENT_SECRET
  KINDE_ISSUER_URL       e.g. https://<your_subdomain>.kinde.com
  KINDE_CALLBACK_URL     full URL Kinde redirects to after login (e.g. https://yourapp.com/auth/callback/)
  KINDE_LOGOUT_REDIRECT  full URL to redirect to after logout (optional; defaults to /)

Or use a single KINDE_ISSUER_URL and set KINDE_CALLBACK_URL / KINDE_LOGOUT_REDIRECT
per environment.
"""

from django.conf import settings


def get_kinde_config(request=None):
    """Return Kinde config dict from settings (and optionally request for callback/logout URLs)."""
    cfg = {
        "client_id": getattr(settings, "KINDE_CLIENT_ID", None)
        or _env("KINDE_CLIENT_ID"),
        "client_secret": getattr(settings, "KINDE_CLIENT_SECRET", None)
        or _env("KINDE_CLIENT_SECRET"),
        "issuer_url": getattr(settings, "KINDE_ISSUER_URL", None) or _env("KINDE_ISSUER_URL"),
        "callback_url": getattr(settings, "KINDE_CALLBACK_URL", None) or _env("KINDE_CALLBACK_URL"),
        "logout_redirect": getattr(settings, "KINDE_LOGOUT_REDIRECT", None)
        or _env("KINDE_LOGOUT_REDIRECT")
        or "/",
    }
    if request and not cfg["callback_url"]:
        from django.urls import reverse
        cfg["callback_url"] = request.build_absolute_uri(reverse("kinde_auth:callback"))
    if request and not cfg["logout_redirect"]:
        cfg["logout_redirect"] = request.build_absolute_uri("/")
    return cfg


def _env(key, default=None):
    import os
    return os.environ.get(key, default)
