"""
Pytest configuration file.

This file configures pytest behavior including warning filters for external libraries.
"""
