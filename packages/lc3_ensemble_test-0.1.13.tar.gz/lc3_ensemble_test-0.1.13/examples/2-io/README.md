# IO Example

This example demonstrates using simulator input and output. This example briefly demonstrates the usage of:

- `autograder.LC3UnitTestCase.setInput`,
- `autograder.LC3UnitTestCase.assertInput`, and
- `autograder.LC3UnitTestCase.assertOutput`.
