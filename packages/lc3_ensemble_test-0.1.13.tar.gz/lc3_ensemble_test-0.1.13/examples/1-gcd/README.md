# GCD Example

This example computes `GCD` through a helper function `MOD`. This example briefly demonstrates the usage of:

- `autograder.LC3UnitTestCase.assertSubroutineCalled`, and
- `autograder.LC3UnitTestCase.assertSubroutineCalledInOrder`.
