# Test Cases

These are basic test cases to check that the autograder is doing normal things.

For examples of test suites, try the `examples/` folder.
