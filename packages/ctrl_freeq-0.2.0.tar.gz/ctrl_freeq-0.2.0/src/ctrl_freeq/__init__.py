__all__ = [
    "__version__",
]

# Project version following PEP 440 / SemVer-compatible
__version__ = "0.2.0"
