"""Tests for ml4t-diagnostic.visualization module."""
