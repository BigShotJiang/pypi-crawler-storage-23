"""Test suite for ml4t-diagnostic."""
