"""Integration tests with external libraries."""
