# ML3 platform client SDK

## Installation
```bash
pip install ml3-platform-sdk
```

## Usage
Please refer to the [documentation](https://ml-cube.github.io/ml3-platform-docs/)
