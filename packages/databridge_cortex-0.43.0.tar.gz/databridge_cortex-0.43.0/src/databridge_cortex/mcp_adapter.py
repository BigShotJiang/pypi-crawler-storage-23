"""Package-backed MCP adapter for cortex tools."""

from src.cortex_agent.mcp_impl import register_cortex_agent_tools
from src.cortex_agent.analyst_impl import register_analyst_tools

__all__ = ["register_cortex_agent_tools", "register_analyst_tools"]
