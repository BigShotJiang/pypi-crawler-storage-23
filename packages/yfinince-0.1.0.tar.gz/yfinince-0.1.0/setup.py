from pathlib import Path

from setuptools import find_packages, setup

BASE_DIR = Path(__file__).parent
README = (BASE_DIR / "README.md").read_text(encoding="utf-8")


setup(
	name="yfinince",
	version="0.1.0",
	author="yfinince",
	description="A lightweight personal Python utility package for modular experimentation and structured development.",
	long_description=README,
	long_description_content_type="text/markdown",
	license="MIT",
	packages=find_packages(),
	include_package_data=True,
	python_requires=">=3.8",
	classifiers=[
		"Programming Language :: Python :: 3",
		"Programming Language :: Python :: 3 :: Only",
		"Programming Language :: Python :: 3.8",
		"Programming Language :: Python :: 3.9",
		"Programming Language :: Python :: 3.10",
		"Programming Language :: Python :: 3.11",
		"Operating System :: OS Independent",
	],
)