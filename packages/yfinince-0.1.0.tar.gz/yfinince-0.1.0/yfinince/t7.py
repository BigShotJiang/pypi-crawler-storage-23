# 1. RSI 
# 1. Price Change
=C12-C11 

#2. Gain
=IF(D11>0,D11,0) 

#3. Loss 
=IF(D12<0,ABS(D12),0)

#3. Separate Gain and Loss 
Average Gain =AVERAGE(E11:E14) 
Average Loss =AVERAGE(F11:F14)

RS = Average Gain / Average Loss
RSI = 100-(100/(1+RS))

# 2 - MACD
#12 Days EMA
=AVERAGE(C41:C52)

#26 Days EMA
=AVERAGE(C41:C66)

#MACD Line
# =EMA(12) - EMA(26)
=D67-E67

#Signal Line 36th line
=AVERAGE(D67:D75)

#Histogram (MACD Line - Signal Line)
=F67-G67

#Action
=IF(D67>G67,"Buy",IF(D67<G67,"Sell","Hold"))

# PLot Macd Histogram >>
