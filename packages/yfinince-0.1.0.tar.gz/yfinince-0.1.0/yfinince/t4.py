# Visualize Stock Market Data

import yfinance as yf
import pandas as pd
import matplotlib.pyplot as plt

ticker = "AAPL"

data = yf.download(ticker, period="6mo", auto_adjust=True)

if data.empty:
    print("No data found. Please check the ticker symbol or internet connection.")
else:
    plt.figure(figsize=(10, 5))
    plt.plot(data.index, data["Close"])
    plt.title(f"{ticker} Stock Price Trend (6 Months)")
    plt.xlabel("Date")
    plt.ylabel("Closing Price (USD)")
    plt.grid(True)
    plt.tight_layout()
    plt.show()