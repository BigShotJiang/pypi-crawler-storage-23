# -SMA
#Moving Average (5 Days) And Chart 
#in 6
=AVERAGE(B2:B6)


# -EMA
# SMA (5 Days) And Chart
=AVERAGE(B2:B6)

# EMA (5 Days)
# in 7th

=(B7-D6)*(2/(5+1))+D6

#x
a=(2/N+1)