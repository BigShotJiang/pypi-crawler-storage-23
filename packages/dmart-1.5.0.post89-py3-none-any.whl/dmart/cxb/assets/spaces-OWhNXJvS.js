import{w as s}from"./svelte-BVB2sXw9.js";const o=s(null);export{o as s};
