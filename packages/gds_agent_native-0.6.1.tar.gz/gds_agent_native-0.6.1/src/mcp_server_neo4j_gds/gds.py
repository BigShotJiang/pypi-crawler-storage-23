from graphdatascience import GraphDataScience
import uuid
from contextlib import contextmanager
import logging


logger = logging.getLogger("mcp_server_neo4j_gds")


@contextmanager
def projected_graph_from_params(gds, node_labels=None, undirected=False, **kwargs):
    """
    Project a graph from the database, delegating to projected_graph.

    Supports both:
    - Positional node_labels as the 2nd argument.
    - nodeLabels/relTypes passed either directly as kwargs or nested under a 'kwargs' dict.

    Returns the projected GDS graph. The caller is responsible for dropping it
    (e.g., gds.graph.drop(G)).
    """
    # Unwrap if the caller passed a nested 'kwargs' dict
    params = (
        kwargs.get("kwargs")
        if "kwargs" in kwargs and isinstance(kwargs.get("kwargs"), dict)
        else kwargs
    )

    # Prefer explicit node_labels positional arg, fall back to params["nodeLabels"]
    nodeLabels = params.get("nodeLabels", node_labels)
    relTypes = params.get("relTypes")

    with projected_graph(
        gds, node_labels=nodeLabels, relationship_types=relTypes, undirected=undirected
    ) as G:
        yield G


def _build_relationship_projection(relationship_types, undirected):
    """Build the relationship projection spec for gds.graph.project().

    - Directed + no types -> "*"
    - Directed + types -> ["TYPE1", "TYPE2"]
    - Undirected + no types -> {"*": {"orientation": "UNDIRECTED"}}
    - Undirected + types -> {"TYPE1": {"orientation": "UNDIRECTED"}, ...}
    """
    if undirected:
        if not relationship_types:
            return {"*": {"orientation": "UNDIRECTED"}}
        return {rt: {"orientation": "UNDIRECTED"} for rt in relationship_types}
    else:
        if not relationship_types:
            return "*"
        return relationship_types


@contextmanager
def projected_graph(gds, node_labels=None, relationship_types=None, undirected=False):
    """
    Project a graph from the database using native GDS projection.

    Args:
        gds: GraphDataScience instance
        node_labels: specifies node labels to project. If empty, all nodes are projected. Default is []
        relationship_types: specifies relationship types to project. If empty, all relationships are projected. Default is [].
        undirected: If True, project as undirected graph. Default is False (directed).
    """
    if relationship_types is None:
        relationship_types = []
    if node_labels is None:
        node_labels = []

    graph_name = f"temp_graph_{uuid.uuid4().hex[:8]}"

    try:
        node_spec = node_labels if node_labels else "*"
        rel_spec = _build_relationship_projection(relationship_types, undirected)

        logger.info(f"Projecting graph '{graph_name}' with nodes={node_spec}, rels={rel_spec}")
        G, _ = gds.graph.project(graph_name, node_spec, rel_spec)
        yield G
    finally:
        try:
            gds.graph.drop(graph_name)
        except Exception:
            pass  # graph may not have been created if projection failed


def get_node_labels(gds: GraphDataScience):
    df = gds.run_cypher("CALL db.labels() YIELD label RETURN collect(label) AS labels")
    return df["labels"].iloc[0] if not df.empty else []


def count_nodes(gds: GraphDataScience):
    df = gds.run_cypher("MATCH (n) RETURN count(n) AS count")
    return int(df["count"].iloc[0])


def get_node_properties_keys(gds: GraphDataScience, node_labels=None):
    if node_labels is None:
        node_labels = []
    df = gds.run_cypher(
        "CALL db.schema.nodeTypeProperties() "
        "YIELD nodeLabels, propertyName "
        "RETURN collect(DISTINCT propertyName) AS properties_keys"
    )
    if df.empty:
        return []
    all_props = df["properties_keys"].iloc[0]
    if not node_labels:
        return all_props
    # Filter: re-query with label filter
    df = gds.run_cypher(
        "CALL db.schema.nodeTypeProperties() "
        "YIELD nodeLabels, propertyName "
        "WHERE ANY(l IN nodeLabels WHERE l IN $labels) "
        "RETURN collect(DISTINCT propertyName) AS properties_keys",
        params={"labels": node_labels},
    )
    return df["properties_keys"].iloc[0] if not df.empty else []


def get_relationship_properties_keys(gds: GraphDataScience, relationshipTypes=None):
    if relationshipTypes is None:
        relationshipTypes = []
    if not relationshipTypes:
        df = gds.run_cypher(
            "CALL db.schema.relTypeProperties() "
            "YIELD relType, propertyName "
            "RETURN collect(DISTINCT propertyName) AS properties_keys"
        )
    else:
        # relType from the procedure is formatted as ":`TYPE`", so strip it for comparison
        df = gds.run_cypher(
            "CALL db.schema.relTypeProperties() "
            "YIELD relType, propertyName "
            "WITH substring(relType, 2, size(relType)-3) AS cleanType, propertyName "
            "WHERE cleanType IN $types "
            "RETURN collect(DISTINCT propertyName) AS properties_keys",
            params={"types": relationshipTypes},
        )
    if df.empty:
        return []
    return df["properties_keys"].iloc[0]


def get_relationship_types(gds: GraphDataScience):
    df = gds.run_cypher(
        "CALL db.relationshipTypes() YIELD relationshipType "
        "RETURN collect(relationshipType) AS relationship_types"
    )
    return df["relationship_types"].iloc[0] if not df.empty else []


