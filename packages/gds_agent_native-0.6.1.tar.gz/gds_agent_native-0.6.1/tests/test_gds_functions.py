import os

import pytest
from graphdatascience import GraphDataScience

from neo4j import GraphDatabase

NEO4J_IMAGE = "neo4j:2025.05.0"
NEO4J_BOLT_PORT = 7687
NEO4J_HTTP_PORT = 7474
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "testpassword"


@pytest.mark.asyncio
def test_projection_with_labels_and_types(neo4j_container):
    """Test native projection with specific labels and relationship types."""
    os.environ["NEO4J_URI"] = neo4j_container
    os.environ["NEO4J_USERNAME"] = NEO4J_USER
    os.environ["NEO4J_PASSWORD"] = NEO4J_PASSWORD

    driver = GraphDatabase.driver(neo4j_container, auth=(NEO4J_USER, NEO4J_PASSWORD))
    existing_count2 = -2
    gds = GraphDataScience(driver)
    with driver.session() as session:
        session.run("CREATE (:Foo{prop1:1.0})-[:REL1{ relprop1: 2.0}] ->(:Foo)")
        session.run("CREATE (:Foo{prop1:1})-[:REL2{ relprop1: 2.0}] ->(:Bar)")
        session.run(
            "CREATE (:Bar)-[:REL3{ prop: 2.0, relprop2:2.0}] ->(:IGNOREME{prop2:[4]})"
        )

    from mcp_server.src.mcp_server_neo4j_gds.gds import projected_graph_from_params

    with projected_graph_from_params(
        gds,
        ["Foo"],
        undirected=False,
        relTypes=["REL1", "REL2"],
        nodeLabels=["Foo", "Bar"],
    ) as G:
        node_count = G.node_count()
        node_labels = set(G.node_labels())
        rel_count = G.relationship_count()
        rel_types = set(G.relationship_types())

    with driver.session() as session:
        session.run("MATCH (n:Foo)  DETACH DELETE n")
        session.run("MATCH (n:Bar)  DETACH DELETE n")
        session.run("MATCH (n:IGNOREME)  DETACH DELETE n")

        res = session.run(
            "MATCH (n) WHERE 'Foo' IN labels(n) OR 'Bar' IN labels(n) OR 'IGNOREME' IN labels(n) RETURN count(n) as count"
        )
        existing_count2 = res.single()["count"]

    driver.close()
    # assertions at the end to ensure failures do not affect other tests
    assert existing_count2 == 0

    assert node_count == 5
    assert node_labels == {"Foo", "Bar"}

    assert rel_count == 2
    assert rel_types == {"REL1", "REL2"}

    list_result = gds.graph.list()
    assert len(list_result) == 0


@pytest.mark.asyncio
def test_get_labels_and_types_and_properties(neo4j_container):
    """Test utility functions for getting labels, types, and properties."""
    os.environ["NEO4J_URI"] = neo4j_container
    os.environ["NEO4J_USERNAME"] = NEO4J_USER
    os.environ["NEO4J_PASSWORD"] = NEO4J_PASSWORD

    driver = GraphDatabase.driver(neo4j_container, auth=(NEO4J_USER, NEO4J_PASSWORD))
    existing_count2 = -2
    gds = GraphDataScience(driver)
    with driver.session() as session:
        session.run(
            "CREATE (:Foo{prop1:1, prop3:5})-[:R1{relprop1:2}]->(:Bar:SpareBar), (:Bar)-[:R2{relprop2:2}]->(:Bar{prop2:2})"
        )

    from mcp_server.src.mcp_server_neo4j_gds.gds import (
        get_node_labels,
        get_relationship_types,
        get_relationship_properties_keys,
        get_node_properties_keys,
    )

    node_labels = get_node_labels(gds)
    rel_types = get_relationship_types(gds)
    rel_props = get_relationship_properties_keys(gds)
    node_props = get_node_properties_keys(gds)

    with driver.session() as session:
        session.run("MATCH (n:Foo)  DETACH DELETE n")
        session.run("MATCH (n:Bar)  DETACH DELETE n")

        res = session.run(
            "MATCH (n) WHERE 'Foo' IN labels(n) OR 'Bar' IN labels(n) OR 'SpareBar' IN labels(n) RETURN count(n) as count"
        )
        existing_count2 = res.single()["count"]

    driver.close()
    # assertions at the end to ensure failures do not affect other tests
    assert existing_count2 == 0

    assert "Foo" in node_labels
    assert "Bar" in node_labels
    assert "SpareBar" in node_labels
    assert "R1" in rel_types
    assert "R2" in rel_types
    assert "relprop1" in rel_props
    assert "relprop2" in rel_props
    assert "prop1" in node_props
    assert "prop2" in node_props
    assert "prop3" in node_props


@pytest.mark.asyncio
def test_native_projection_all_nodes(neo4j_container):
    """Test native projection with no labels or types (projects everything)."""
    os.environ["NEO4J_URI"] = neo4j_container
    os.environ["NEO4J_USERNAME"] = NEO4J_USER
    os.environ["NEO4J_PASSWORD"] = NEO4J_PASSWORD

    driver = GraphDatabase.driver(neo4j_container, auth=(NEO4J_USER, NEO4J_PASSWORD))
    gds = GraphDataScience(driver)
    with driver.session() as session:
        session.run("CREATE (:A)-[:X]->(:B)-[:Y]->(:C)")

    from mcp_server.src.mcp_server_neo4j_gds.gds import projected_graph

    with projected_graph(gds) as G:
        node_count = G.node_count()
        rel_count = G.relationship_count()

    with driver.session() as session:
        session.run("MATCH (n) WHERE 'A' IN labels(n) OR 'B' IN labels(n) OR 'C' IN labels(n) DETACH DELETE n")

    driver.close()

    assert node_count == 3
    assert rel_count == 2

    list_result = gds.graph.list()
    assert len(list_result) == 0


@pytest.mark.asyncio
def test_native_projection_undirected(neo4j_container):
    """Test native projection with undirected=True."""
    os.environ["NEO4J_URI"] = neo4j_container
    os.environ["NEO4J_USERNAME"] = NEO4J_USER
    os.environ["NEO4J_PASSWORD"] = NEO4J_PASSWORD

    driver = GraphDatabase.driver(neo4j_container, auth=(NEO4J_USER, NEO4J_PASSWORD))
    gds = GraphDataScience(driver)
    with driver.session() as session:
        session.run("CREATE (:U1)-[:LINK]->(:U2)")

    from mcp_server.src.mcp_server_neo4j_gds.gds import projected_graph

    with projected_graph(gds, undirected=True) as G:
        node_count = G.node_count()
        # Undirected doubles the relationship count (each direction)
        rel_count = G.relationship_count()

    with driver.session() as session:
        session.run("MATCH (n) WHERE 'U1' IN labels(n) OR 'U2' IN labels(n) DETACH DELETE n")

    driver.close()

    assert node_count == 2
    # GDS stores undirected as 2 directed edges internally
    assert rel_count == 2

    list_result = gds.graph.list()
    assert len(list_result) == 0


@pytest.mark.asyncio
def test_native_projection_cleanup_on_error(neo4j_container):
    """Test that the projected graph is cleaned up even when an error occurs."""
    os.environ["NEO4J_URI"] = neo4j_container
    os.environ["NEO4J_USERNAME"] = NEO4J_USER
    os.environ["NEO4J_PASSWORD"] = NEO4J_PASSWORD

    driver = GraphDatabase.driver(neo4j_container, auth=(NEO4J_USER, NEO4J_PASSWORD))
    gds = GraphDataScience(driver)
    with driver.session() as session:
        session.run("CREATE (:ErrTest)-[:LINK]->(:ErrTest)")

    from mcp_server.src.mcp_server_neo4j_gds.gds import projected_graph

    with pytest.raises(RuntimeError, match="intentional test error"):
        with projected_graph(gds) as G:
            assert G.node_count() > 0
            raise RuntimeError("intentional test error")

    with driver.session() as session:
        session.run("MATCH (n:ErrTest) DETACH DELETE n")

    driver.close()

    # Verify the graph was dropped despite the error
    list_result = gds.graph.list()
    assert len(list_result) == 0
