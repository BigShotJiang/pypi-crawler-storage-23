// -------------------------------------------------------------------------------------------------
//  Copyright (C) 2015-2026 Nautech Systems Pty Ltd. All rights reserved.
//  https://nautechsystems.io
//
//  Licensed under the GNU Lesser General Public License Version 3.0 (the "License");
//  You may not use this file except in compliance with the License.
//  You may obtain a copy of the License at https://www.gnu.org/licenses/lgpl-3.0.en.html
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// -------------------------------------------------------------------------------------------------

//! BitMEX-specific enumerations shared by HTTP and WebSocket components.

use std::borrow::Cow;

use nautilus_model::enums::{
    ContingencyType, LiquiditySide, OrderSide, OrderSideSpecified, OrderStatus, OrderType,
    PositionSide, TimeInForce,
};
use serde::{Deserialize, Deserializer, Serialize};
use strum::{AsRefStr, Display, EnumIter, EnumString};

/// Represents the status of a BitMEX symbol.
#[derive(
    Copy,
    Clone,
    Debug,
    Display,
    PartialEq,
    Eq,
    AsRefStr,
    EnumIter,
    EnumString,
    Serialize,
    Deserialize,
)]
#[serde(rename_all = "PascalCase")]
#[cfg_attr(
    feature = "python",
    pyo3::pyclass(
        module = "nautilus_trader.core.nautilus_pyo3.bitmex",
        eq,
        eq_int,
        from_py_object,
        rename_all = "SCREAMING_SNAKE_CASE",
    )
)]
pub enum BitmexSymbolStatus {
    /// Symbol is open for trading.
    Open,
    /// Symbol is closed for trading.
    Closed,
    /// Symbol is unlisted.
    Unlisted,
}

/// Represents the side of an order or trade (Buy/Sell).
#[derive(
    Copy,
    Clone,
    Debug,
    Display,
    PartialEq,
    Eq,
    AsRefStr,
    EnumIter,
    EnumString,
    Serialize,
    Deserialize,
)]
pub enum BitmexSide {
    /// Buy side of a trade or order.
    #[serde(rename = "Buy", alias = "BUY", alias = "buy")]
    Buy,
    /// Sell side of a trade or order.
    #[serde(rename = "Sell", alias = "SELL", alias = "sell")]
    Sell,
}

impl From<OrderSideSpecified> for BitmexSide {
    fn from(value: OrderSideSpecified) -> Self {
        match value {
            OrderSideSpecified::Buy => Self::Buy,
            OrderSideSpecified::Sell => Self::Sell,
        }
    }
}

impl From<BitmexSide> for OrderSide {
    fn from(side: BitmexSide) -> Self {
        match side {
            BitmexSide::Buy => Self::Buy,
            BitmexSide::Sell => Self::Sell,
        }
    }
}

/// Represents the position side for BitMEX positions.
#[derive(
    Copy,
    Clone,
    Debug,
    Display,
    PartialEq,
    Eq,
    AsRefStr,
    EnumIter,
    EnumString,
    Serialize,
    Deserialize,
)]
#[cfg_attr(
    feature = "python",
    pyo3::pyclass(
        module = "nautilus_trader.core.nautilus_pyo3.bitmex",
        eq,
        eq_int,
        from_py_object
    )
)]
pub enum BitmexPositionSide {
    /// Long position.
    #[serde(rename = "LONG", alias = "Long", alias = "long")]
    Long,
    /// Short position.
    #[serde(rename = "SHORT", alias = "Short", alias = "short")]
    Short,
    /// No position.
    #[serde(rename = "FLAT", alias = "Flat", alias = "flat")]
    Flat,
}

impl From<BitmexPositionSide> for PositionSide {
    fn from(side: BitmexPositionSide) -> Self {
        match side {
            BitmexPositionSide::Long => Self::Long,
            BitmexPositionSide::Short => Self::Short,
            BitmexPositionSide::Flat => Self::Flat,
        }
    }
}

impl From<PositionSide> for BitmexPositionSide {
    fn from(side: PositionSide) -> Self {
        match side {
            PositionSide::Long => Self::Long,
            PositionSide::Short => Self::Short,
            PositionSide::Flat | PositionSide::NoPositionSide => Self::Flat,
        }
    }
}

/// Represents the available order types on BitMEX.
#[derive(
    Copy,
    Clone,
    Debug,
    Display,
    PartialEq,
    Eq,
    AsRefStr,
    EnumIter,
    EnumString,
    Serialize,
    Deserialize,
)]
pub enum BitmexOrderType {
    /// Market order, executed immediately at current market price.
    Market,
    /// Limit order, executed only at specified price or better.
    Limit,
    /// Stop Market order, triggers a market order when price reaches stop price.
    Stop,
    /// Stop Limit order, triggers a limit order when price reaches stop price.
    StopLimit,
    /// Market if touched order, triggers a market order when price reaches touch price.
    MarketIfTouched,
    /// Limit if touched order, triggers a limit order when price reaches touch price.
    LimitIfTouched,
    /// Pegged order, price automatically tracks market.
    Pegged,
}

impl TryFrom<OrderType> for BitmexOrderType {
    type Error = anyhow::Error;

    fn try_from(value: OrderType) -> Result<Self, Self::Error> {
        match value {
            OrderType::Market => Ok(Self::Market),
            OrderType::Limit => Ok(Self::Limit),
            OrderType::StopMarket => Ok(Self::Stop),
            OrderType::StopLimit => Ok(Self::StopLimit),
            OrderType::MarketIfTouched => Ok(Self::MarketIfTouched),
            OrderType::LimitIfTouched => Ok(Self::LimitIfTouched),
            OrderType::TrailingStopMarket => Ok(Self::Pegged),
            OrderType::TrailingStopLimit => Ok(Self::Pegged),
            OrderType::MarketToLimit => {
                anyhow::bail!("MarketToLimit order type is not supported by BitMEX")
            }
        }
    }
}

impl BitmexOrderType {
    /// Try to convert from Nautilus OrderType with anyhow::Result.
    ///
    /// # Errors
    ///
    /// Returns an error if the order type is MarketToLimit (not supported by BitMEX).
    pub fn try_from_order_type(value: OrderType) -> anyhow::Result<Self> {
        Self::try_from(value)
    }
}

impl From<BitmexOrderType> for OrderType {
    fn from(value: BitmexOrderType) -> Self {
        match value {
            BitmexOrderType::Market => Self::Market,
            BitmexOrderType::Limit => Self::Limit,
            BitmexOrderType::Stop => Self::StopMarket,
            BitmexOrderType::StopLimit => Self::StopLimit,
            BitmexOrderType::MarketIfTouched => Self::MarketIfTouched,
            BitmexOrderType::LimitIfTouched => Self::LimitIfTouched,
            BitmexOrderType::Pegged => Self::Limit,
        }
    }
}

/// Represents the possible states of an order throughout its lifecycle.
#[derive(
    Copy,
    Clone,
    Debug,
    Display,
    PartialEq,
    Eq,
    AsRefStr,
    EnumIter,
    EnumString,
    Serialize,
    Deserialize,
)]
pub enum BitmexOrderStatus {
    /// Order has been placed but not yet processed.
    New,
    /// Order is awaiting confirmation.
    PendingNew,
    /// Order has been partially filled.
    PartiallyFilled,
    /// Order has been completely filled.
    Filled,
    /// Order modification is in progress.
    PendingReplace,
    /// Order cancellation is pending.
    PendingCancel,
    /// Order has been canceled by user or system.
    Canceled,
    /// Order was rejected by the system.
    Rejected,
    /// Order has expired according to its time in force.
    Expired,
}

impl From<BitmexOrderStatus> for OrderStatus {
    fn from(value: BitmexOrderStatus) -> Self {
        match value {
            BitmexOrderStatus::New => Self::Accepted,
            BitmexOrderStatus::PendingNew => Self::Submitted,
            BitmexOrderStatus::PartiallyFilled => Self::PartiallyFilled,
            BitmexOrderStatus::Filled => Self::Filled,
            BitmexOrderStatus::PendingReplace => Self::PendingUpdate,
            BitmexOrderStatus::PendingCancel => Self::PendingCancel,
            BitmexOrderStatus::Canceled => Self::Canceled,
            BitmexOrderStatus::Rejected => Self::Rejected,
            BitmexOrderStatus::Expired => Self::Expired,
        }
    }
}

/// Specifies how long an order should remain active.
#[derive(
    Copy,
    Clone,
    Debug,
    Display,
    PartialEq,
    Eq,
    AsRefStr,
    EnumIter,
    EnumString,
    Serialize,
    Deserialize,
)]
pub enum BitmexTimeInForce {
    Day,
    GoodTillCancel,
    AtTheOpening,
    ImmediateOrCancel,
    FillOrKill,
    GoodTillCrossing,
    GoodTillDate,
    AtTheClose,
    GoodThroughCrossing,
    AtCrossing,
}

impl TryFrom<BitmexTimeInForce> for TimeInForce {
    type Error = anyhow::Error;

    fn try_from(value: BitmexTimeInForce) -> Result<Self, Self::Error> {
        match value {
            BitmexTimeInForce::Day => Ok(Self::Day),
            BitmexTimeInForce::GoodTillCancel => Ok(Self::Gtc),
            BitmexTimeInForce::GoodTillDate => Ok(Self::Gtd),
            BitmexTimeInForce::ImmediateOrCancel => Ok(Self::Ioc),
            BitmexTimeInForce::FillOrKill => Ok(Self::Fok),
            BitmexTimeInForce::AtTheOpening => Ok(Self::AtTheOpen),
            BitmexTimeInForce::AtTheClose => Ok(Self::AtTheClose),
            _ => anyhow::bail!("Unsupported BitmexTimeInForce: {value}"),
        }
    }
}

impl TryFrom<TimeInForce> for BitmexTimeInForce {
    type Error = anyhow::Error;

    fn try_from(value: TimeInForce) -> Result<Self, Self::Error> {
        match value {
            TimeInForce::Day => Ok(Self::Day),
            TimeInForce::Gtc => Ok(Self::GoodTillCancel),
            TimeInForce::Gtd => Ok(Self::GoodTillDate),
            TimeInForce::Ioc => Ok(Self::ImmediateOrCancel),
            TimeInForce::Fok => Ok(Self::FillOrKill),
            TimeInForce::AtTheOpen => Ok(Self::AtTheOpening),
            TimeInForce::AtTheClose => Ok(Self::AtTheClose),
        }
    }
}

impl BitmexTimeInForce {
    /// Try to convert from Nautilus TimeInForce with anyhow::Result.
    ///
    /// # Errors
    ///
    /// Returns an error if the time in force is not supported by BitMEX.
    pub fn try_from_time_in_force(value: TimeInForce) -> anyhow::Result<Self> {
        Self::try_from(value)
    }
}

/// Represents the available contingency types on BitMEX.
#[derive(
    Copy,
    Clone,
    Debug,
    Display,
    PartialEq,
    Eq,
    AsRefStr,
    EnumIter,
    EnumString,
    Serialize,
    Deserialize,
)]
pub enum BitmexContingencyType {
    OneCancelsTheOther,
    OneTriggersTheOther,
    OneUpdatesTheOtherAbsolute,
    OneUpdatesTheOtherProportional,
    #[serde(rename = "")]
    Unknown, // Can be empty
}

impl From<BitmexContingencyType> for ContingencyType {
    fn from(value: BitmexContingencyType) -> Self {
        match value {
            BitmexContingencyType::OneCancelsTheOther => Self::Oco,
            BitmexContingencyType::OneTriggersTheOther => Self::Oto,
            BitmexContingencyType::OneUpdatesTheOtherProportional => Self::Ouo,
            BitmexContingencyType::OneUpdatesTheOtherAbsolute => Self::Ouo,
            BitmexContingencyType::Unknown => Self::NoContingency,
        }
    }
}

impl TryFrom<ContingencyType> for BitmexContingencyType {
    type Error = anyhow::Error;

    fn try_from(value: ContingencyType) -> Result<Self, Self::Error> {
        match value {
            ContingencyType::NoContingency => Ok(Self::Unknown),
            ContingencyType::Oco => Ok(Self::OneCancelsTheOther),
            ContingencyType::Oto => Ok(Self::OneTriggersTheOther),
            ContingencyType::Ouo => anyhow::bail!("OUO contingency type not supported by BitMEX"),
        }
    }
}

/// Represents the available peg price types on BitMEX.
#[derive(
    Copy,
    Clone,
    Debug,
    Display,
    PartialEq,
    Eq,
    AsRefStr,
    EnumIter,
    EnumString,
    Serialize,
    Deserialize,
)]
pub enum BitmexPegPriceType {
    LastPeg,
    OpeningPeg,
    MidPricePeg,
    MarketPeg,
    PrimaryPeg,
    PegToVWAP,
    TrailingStopPeg,
    PegToLimitPrice,
    ShortSaleMinPricePeg,
    #[serde(rename = "")]
    Unknown, // Can be empty
}

/// Represents the available execution instruments on BitMEX.
#[derive(
    Copy,
    Clone,
    Debug,
    Display,
    PartialEq,
    Eq,
    AsRefStr,
    EnumIter,
    EnumString,
    Serialize,
    Deserialize,
)]
pub enum BitmexExecInstruction {
    ParticipateDoNotInitiate,
    AllOrNone,
    MarkPrice,
    IndexPrice,
    LastPrice,
    Close,
    ReduceOnly,
    Fixed,
    #[serde(rename = "")]
    Unknown, // Can be empty
}

impl BitmexExecInstruction {
    /// Joins execution instructions into the comma-separated string expected by BitMEX.
    pub fn join(instructions: &[Self]) -> String {
        instructions
            .iter()
            .map(ToString::to_string)
            .collect::<Vec<_>>()
            .join(",")
    }
}

/// Represents the type of execution that generated a trade.
#[derive(Clone, Debug, Display, PartialEq, Eq, AsRefStr, EnumIter, EnumString, Serialize)]
pub enum BitmexExecType {
    /// New order placed.
    New,
    /// Normal trade execution.
    Trade,
    /// Order canceled.
    Canceled,
    /// Cancel request rejected.
    CancelReject,
    /// Order replaced.
    Replaced,
    /// Order rejected.
    Rejected,
    /// Order amendment rejected.
    AmendReject,
    /// Funding rate execution.
    Funding,
    /// Settlement execution.
    Settlement,
    /// Order suspended.
    Suspended,
    /// Order released.
    Released,
    /// Insurance payment.
    Insurance,
    /// Rebalance.
    Rebalance,
    /// Liquidation execution.
    Liquidation,
    /// Bankruptcy execution.
    Bankruptcy,
    /// Trial fill (testnet only).
    TrialFill,
    /// Stop/trigger order activated by system.
    TriggeredOrActivatedBySystem,
    /// Unknown execution type (not yet supported).
    #[strum(disabled)]
    Unknown(String),
}

impl<'de> Deserialize<'de> for BitmexExecType {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        let s = String::deserialize(deserializer)?;

        match s.as_str() {
            "New" => Ok(Self::New),
            "Trade" => Ok(Self::Trade),
            "Canceled" => Ok(Self::Canceled),
            "CancelReject" => Ok(Self::CancelReject),
            "Replaced" => Ok(Self::Replaced),
            "Rejected" => Ok(Self::Rejected),
            "AmendReject" => Ok(Self::AmendReject),
            "Funding" => Ok(Self::Funding),
            "Settlement" => Ok(Self::Settlement),
            "Suspended" => Ok(Self::Suspended),
            "Released" => Ok(Self::Released),
            "Insurance" => Ok(Self::Insurance),
            "Rebalance" => Ok(Self::Rebalance),
            "Liquidation" => Ok(Self::Liquidation),
            "Bankruptcy" => Ok(Self::Bankruptcy),
            "TrialFill" => Ok(Self::TrialFill),
            "TriggeredOrActivatedBySystem" => Ok(Self::TriggeredOrActivatedBySystem),
            other => Ok(Self::Unknown(other.to_string())),
        }
    }
}

/// Indicates whether the execution was maker or taker.
#[derive(
    Copy,
    Clone,
    Debug,
    Display,
    PartialEq,
    Eq,
    AsRefStr,
    EnumIter,
    EnumString,
    Serialize,
    Deserialize,
)]
pub enum BitmexLiquidityIndicator {
    /// Provided liquidity to the order book (maker).
    /// BitMEX returns "Added" in REST API responses and "AddedLiquidity" in WebSocket messages.
    #[serde(rename = "Added")]
    #[serde(alias = "AddedLiquidity")]
    Maker,
    /// Took liquidity from the order book (taker).
    /// BitMEX returns "Removed" in REST API responses and "RemovedLiquidity" in WebSocket messages.
    #[serde(rename = "Removed")]
    #[serde(alias = "RemovedLiquidity")]
    Taker,
}

impl From<BitmexLiquidityIndicator> for LiquiditySide {
    fn from(value: BitmexLiquidityIndicator) -> Self {
        match value {
            BitmexLiquidityIndicator::Maker => Self::Maker,
            BitmexLiquidityIndicator::Taker => Self::Taker,
        }
    }
}

/// Represents BitMEX instrument types (CFI codes).
///
/// The CFI (Classification of Financial Instruments) code is a 6-character code
/// following ISO 10962 standard that classifies financial instruments.
///
/// See: <https://support.bitmex.com/hc/en-gb/articles/6299296145565-What-are-the-Typ-Values-for-Instrument-endpoint>
#[derive(
    Copy,
    Clone,
    Debug,
    Display,
    PartialEq,
    Eq,
    AsRefStr,
    EnumIter,
    EnumString,
    Serialize,
    Deserialize,
)]
#[serde(rename_all = "UPPERCASE")]
pub enum BitmexInstrumentType {
    /// Legacy futures (settled).
    #[serde(rename = "FXXXS")]
    LegacyFutures,

    /// Legacy futures (settled, variant).
    #[serde(rename = "FXXXN")]
    LegacyFuturesN,

    /// Futures spreads (settled).
    #[serde(rename = "FMXXS")]
    FuturesSpreads,

    /// Prediction Markets (non-standardized financial future on index, cash settled).
    /// CFI code FFICSX - traders predict outcomes of events.
    #[serde(rename = "FFICSX")]
    PredictionMarket,

    /// Stock-based Perpetual Contracts (e.g., SPY, equity derivatives).
    /// CFI code FFSCSX - financial future on stocks, cash settled.
    #[serde(rename = "FFSCSX")]
    StockPerpetual,

    /// Perpetual Contracts (crypto).
    #[serde(rename = "FFWCSX")]
    PerpetualContract,

    /// Perpetual Contracts (FX underliers).
    #[serde(rename = "FFWCSF")]
    PerpetualContractFx,

    /// Futures (calendar futures, cash settled).
    #[serde(rename = "FFCCSX")]
    Futures,

    /// Spot trading pairs.
    #[serde(rename = "IFXXXP")]
    Spot,

    /// Call options (European, cash settled).
    #[serde(rename = "OCECCS")]
    CallOption,

    /// Put options (European, cash settled).
    #[serde(rename = "OPECCS")]
    PutOption,

    /// Swap rate contracts (yield products).
    #[serde(rename = "SRMCSX")]
    SwapRate,

    /// Reference basket contracts.
    #[serde(rename = "RCSXXX")]
    ReferenceBasket,

    /// BitMEX Basket Index.
    #[serde(rename = "MRBXXX")]
    BasketIndex,

    /// BitMEX Crypto Index.
    #[serde(rename = "MRCXXX")]
    CryptoIndex,

    /// BitMEX FX Index.
    #[serde(rename = "MRFXXX")]
    FxIndex,

    /// BitMEX Lending/Premium Index.
    #[serde(rename = "MRRXXX")]
    LendingIndex,

    /// BitMEX Volatility Index.
    #[serde(rename = "MRIXXX")]
    VolatilityIndex,

    /// BitMEX Stock/Securities Index.
    #[serde(rename = "MRSXXX")]
    StockIndex,

    /// BitMEX Yield/Dividend Index.
    #[serde(rename = "MRVDXX")]
    YieldIndex,
}

/// Represents the different types of instrument subscriptions available on BitMEX.
#[derive(Clone, Debug, Display, PartialEq, Eq, AsRefStr, EnumIter, EnumString, Serialize)]
pub enum BitmexProductType {
    /// All instruments AND indices.
    #[serde(rename = "instrument")]
    All,

    /// All instruments, but no indices.
    #[serde(rename = "CONTRACTS")]
    Contracts,

    /// All indices, but no tradeable instruments.
    #[serde(rename = "INDICES")]
    Indices,

    /// Only derivative instruments, and no indices.
    #[serde(rename = "DERIVATIVES")]
    Derivatives,

    /// Only spot instruments, and no indices.
    #[serde(rename = "SPOT")]
    Spot,

    /// Specific instrument subscription (e.g., "instrument:XBTUSD").
    #[serde(rename = "instrument")]
    #[serde(untagged)]
    Specific(String),
}

impl BitmexProductType {
    /// Converts the product type to its websocket subscription string.
    #[must_use]
    pub fn to_subscription(&self) -> Cow<'static, str> {
        match self {
            Self::All => Cow::Borrowed("instrument"),
            Self::Specific(symbol) => Cow::Owned(format!("instrument:{symbol}")),
            Self::Contracts => Cow::Borrowed("CONTRACTS"),
            Self::Indices => Cow::Borrowed("INDICES"),
            Self::Derivatives => Cow::Borrowed("DERIVATIVES"),
            Self::Spot => Cow::Borrowed("SPOT"),
        }
    }
}

impl<'de> Deserialize<'de> for BitmexProductType {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        let s = String::deserialize(deserializer)?;

        match s.as_str() {
            "instrument" => Ok(Self::All),
            "CONTRACTS" => Ok(Self::Contracts),
            "INDICES" => Ok(Self::Indices),
            "DERIVATIVES" => Ok(Self::Derivatives),
            "SPOT" => Ok(Self::Spot),
            s if s.starts_with("instrument:") => {
                let symbol = s.strip_prefix("instrument:").unwrap();
                Ok(Self::Specific(symbol.to_string()))
            }
            _ => Err(serde::de::Error::custom(format!(
                "Invalid product type: {s}"
            ))),
        }
    }
}

/// Represents the tick direction of the last trade.
#[derive(
    Copy,
    Clone,
    Debug,
    Display,
    PartialEq,
    Eq,
    AsRefStr,
    EnumIter,
    EnumString,
    Serialize,
    Deserialize,
)]
pub enum BitmexTickDirection {
    /// Price increased on last trade.
    PlusTick,
    /// Price decreased on last trade.
    MinusTick,
    /// Price unchanged, but previous tick was plus.
    ZeroPlusTick,
    /// Price unchanged, but previous tick was minus.
    ZeroMinusTick,
}

/// Represents the state of an instrument.
#[derive(
    Clone,
    Copy,
    Debug,
    Display,
    PartialEq,
    Eq,
    AsRefStr,
    EnumIter,
    EnumString,
    Serialize,
    Deserialize,
)]
pub enum BitmexInstrumentState {
    /// Instrument is open for trading.
    Open,
    /// Instrument is closed for trading.
    Closed,
    /// Instrument is unlisted.
    Unlisted,
    /// Instrument is settled.
    Settled,
    /// Instrument is delisted.
    Delisted,
}

/// Represents the fair price calculation method.
#[derive(
    Clone, Debug, Display, PartialEq, Eq, AsRefStr, EnumIter, EnumString, Serialize, Deserialize,
)]
pub enum BitmexFairMethod {
    /// Funding rate based.
    FundingRate,
    /// Impact mid price.
    ImpactMidPrice,
    /// Last price.
    LastPrice,
}

/// Represents the mark price calculation method.
#[derive(
    Clone, Debug, Display, PartialEq, Eq, AsRefStr, EnumIter, EnumString, Serialize, Deserialize,
)]
pub enum BitmexMarkMethod {
    /// Fair price.
    FairPrice,
    /// Fair price for stock-based perpetuals.
    FairPriceStox,
    /// Last price.
    LastPrice,
    /// Last price for pre-launch instruments.
    LastPricePreLaunch,
    /// Composite index.
    CompositeIndex,
}

#[cfg(test)]
mod tests {
    use rstest::rstest;

    use super::*;

    #[rstest]
    fn test_bitmex_side_deserialization() {
        // Test all case variations
        assert_eq!(
            serde_json::from_str::<BitmexSide>(r#""Buy""#).unwrap(),
            BitmexSide::Buy
        );
        assert_eq!(
            serde_json::from_str::<BitmexSide>(r#""BUY""#).unwrap(),
            BitmexSide::Buy
        );
        assert_eq!(
            serde_json::from_str::<BitmexSide>(r#""buy""#).unwrap(),
            BitmexSide::Buy
        );
        assert_eq!(
            serde_json::from_str::<BitmexSide>(r#""Sell""#).unwrap(),
            BitmexSide::Sell
        );
        assert_eq!(
            serde_json::from_str::<BitmexSide>(r#""SELL""#).unwrap(),
            BitmexSide::Sell
        );
        assert_eq!(
            serde_json::from_str::<BitmexSide>(r#""sell""#).unwrap(),
            BitmexSide::Sell
        );
    }

    #[rstest]
    fn test_bitmex_order_type_deserialization() {
        assert_eq!(
            serde_json::from_str::<BitmexOrderType>(r#""Market""#).unwrap(),
            BitmexOrderType::Market
        );
        assert_eq!(
            serde_json::from_str::<BitmexOrderType>(r#""Limit""#).unwrap(),
            BitmexOrderType::Limit
        );
        assert_eq!(
            serde_json::from_str::<BitmexOrderType>(r#""Stop""#).unwrap(),
            BitmexOrderType::Stop
        );
        assert_eq!(
            serde_json::from_str::<BitmexOrderType>(r#""StopLimit""#).unwrap(),
            BitmexOrderType::StopLimit
        );
        assert_eq!(
            serde_json::from_str::<BitmexOrderType>(r#""MarketIfTouched""#).unwrap(),
            BitmexOrderType::MarketIfTouched
        );
        assert_eq!(
            serde_json::from_str::<BitmexOrderType>(r#""LimitIfTouched""#).unwrap(),
            BitmexOrderType::LimitIfTouched
        );
        assert_eq!(
            serde_json::from_str::<BitmexOrderType>(r#""Pegged""#).unwrap(),
            BitmexOrderType::Pegged
        );
    }

    #[rstest]
    fn test_instrument_type_serialization() {
        // Tradeable instruments
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::PerpetualContract).unwrap(),
            r#""FFWCSX""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::PerpetualContractFx).unwrap(),
            r#""FFWCSF""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::StockPerpetual).unwrap(),
            r#""FFSCSX""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::Spot).unwrap(),
            r#""IFXXXP""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::Futures).unwrap(),
            r#""FFCCSX""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::PredictionMarket).unwrap(),
            r#""FFICSX""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::CallOption).unwrap(),
            r#""OCECCS""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::PutOption).unwrap(),
            r#""OPECCS""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::SwapRate).unwrap(),
            r#""SRMCSX""#
        );

        // Legacy instruments
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::LegacyFutures).unwrap(),
            r#""FXXXS""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::LegacyFuturesN).unwrap(),
            r#""FXXXN""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::FuturesSpreads).unwrap(),
            r#""FMXXS""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::ReferenceBasket).unwrap(),
            r#""RCSXXX""#
        );

        // Index types
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::BasketIndex).unwrap(),
            r#""MRBXXX""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::CryptoIndex).unwrap(),
            r#""MRCXXX""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::FxIndex).unwrap(),
            r#""MRFXXX""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::LendingIndex).unwrap(),
            r#""MRRXXX""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::VolatilityIndex).unwrap(),
            r#""MRIXXX""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::StockIndex).unwrap(),
            r#""MRSXXX""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexInstrumentType::YieldIndex).unwrap(),
            r#""MRVDXX""#
        );
    }

    #[rstest]
    fn test_instrument_type_deserialization() {
        // Tradeable instruments
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""FFWCSX""#).unwrap(),
            BitmexInstrumentType::PerpetualContract
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""FFWCSF""#).unwrap(),
            BitmexInstrumentType::PerpetualContractFx
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""FFSCSX""#).unwrap(),
            BitmexInstrumentType::StockPerpetual
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""IFXXXP""#).unwrap(),
            BitmexInstrumentType::Spot
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""FFCCSX""#).unwrap(),
            BitmexInstrumentType::Futures
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""FFICSX""#).unwrap(),
            BitmexInstrumentType::PredictionMarket
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""OCECCS""#).unwrap(),
            BitmexInstrumentType::CallOption
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""OPECCS""#).unwrap(),
            BitmexInstrumentType::PutOption
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""SRMCSX""#).unwrap(),
            BitmexInstrumentType::SwapRate
        );

        // Legacy instruments
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""FXXXS""#).unwrap(),
            BitmexInstrumentType::LegacyFutures
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""FXXXN""#).unwrap(),
            BitmexInstrumentType::LegacyFuturesN
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""FMXXS""#).unwrap(),
            BitmexInstrumentType::FuturesSpreads
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""RCSXXX""#).unwrap(),
            BitmexInstrumentType::ReferenceBasket
        );

        // Index types
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""MRBXXX""#).unwrap(),
            BitmexInstrumentType::BasketIndex
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""MRCXXX""#).unwrap(),
            BitmexInstrumentType::CryptoIndex
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""MRFXXX""#).unwrap(),
            BitmexInstrumentType::FxIndex
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""MRRXXX""#).unwrap(),
            BitmexInstrumentType::LendingIndex
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""MRIXXX""#).unwrap(),
            BitmexInstrumentType::VolatilityIndex
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""MRSXXX""#).unwrap(),
            BitmexInstrumentType::StockIndex
        );
        assert_eq!(
            serde_json::from_str::<BitmexInstrumentType>(r#""MRVDXX""#).unwrap(),
            BitmexInstrumentType::YieldIndex
        );

        // Error case
        assert!(serde_json::from_str::<BitmexInstrumentType>(r#""INVALID""#).is_err());
    }

    #[rstest]
    fn test_subscription_strings() {
        assert_eq!(BitmexProductType::All.to_subscription(), "instrument");
        assert_eq!(
            BitmexProductType::Specific("XBTUSD".to_string()).to_subscription(),
            "instrument:XBTUSD"
        );
        assert_eq!(BitmexProductType::Contracts.to_subscription(), "CONTRACTS");
        assert_eq!(BitmexProductType::Indices.to_subscription(), "INDICES");
        assert_eq!(
            BitmexProductType::Derivatives.to_subscription(),
            "DERIVATIVES"
        );
        assert_eq!(BitmexProductType::Spot.to_subscription(), "SPOT");
    }

    #[rstest]
    fn test_serialization() {
        // Test serialization
        assert_eq!(
            serde_json::to_string(&BitmexProductType::All).unwrap(),
            r#""instrument""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexProductType::Specific("XBTUSD".to_string())).unwrap(),
            r#""XBTUSD""#
        );
        assert_eq!(
            serde_json::to_string(&BitmexProductType::Contracts).unwrap(),
            r#""CONTRACTS""#
        );
    }

    #[rstest]
    fn test_deserialization() {
        assert_eq!(
            serde_json::from_str::<BitmexProductType>(r#""instrument""#).unwrap(),
            BitmexProductType::All
        );
        assert_eq!(
            serde_json::from_str::<BitmexProductType>(r#""instrument:XBTUSD""#).unwrap(),
            BitmexProductType::Specific("XBTUSD".to_string())
        );
        assert_eq!(
            serde_json::from_str::<BitmexProductType>(r#""CONTRACTS""#).unwrap(),
            BitmexProductType::Contracts
        );
    }

    #[rstest]
    fn test_error_cases() {
        assert!(serde_json::from_str::<BitmexProductType>(r#""invalid_type""#).is_err());
        assert!(serde_json::from_str::<BitmexProductType>(r"123").is_err());
        assert!(serde_json::from_str::<BitmexProductType>(r"{}").is_err());
    }

    #[rstest]
    fn test_order_side_from_specified() {
        assert_eq!(BitmexSide::from(OrderSideSpecified::Buy), BitmexSide::Buy);
        assert_eq!(BitmexSide::from(OrderSideSpecified::Sell), BitmexSide::Sell);
    }

    #[rstest]
    fn test_order_type_try_from() {
        // Valid conversions
        assert_eq!(
            BitmexOrderType::try_from(OrderType::Market).unwrap(),
            BitmexOrderType::Market
        );
        assert_eq!(
            BitmexOrderType::try_from(OrderType::Limit).unwrap(),
            BitmexOrderType::Limit
        );

        // MarketToLimit should fail
        let result = BitmexOrderType::try_from(OrderType::MarketToLimit);
        assert!(result.is_err());
        assert!(result.unwrap_err().to_string().contains("not supported"));
    }

    #[rstest]
    fn test_time_in_force_conversions() {
        // BitMEX to Nautilus (all supported variants)
        assert_eq!(
            TimeInForce::try_from(BitmexTimeInForce::Day).unwrap(),
            TimeInForce::Day
        );
        assert_eq!(
            TimeInForce::try_from(BitmexTimeInForce::GoodTillCancel).unwrap(),
            TimeInForce::Gtc
        );
        assert_eq!(
            TimeInForce::try_from(BitmexTimeInForce::ImmediateOrCancel).unwrap(),
            TimeInForce::Ioc
        );

        // Unsupported BitMEX variants should fail
        let result = TimeInForce::try_from(BitmexTimeInForce::GoodTillCrossing);
        assert!(result.is_err());
        assert!(result.unwrap_err().to_string().contains("Unsupported"));

        // Nautilus to BitMEX (all supported variants)
        assert_eq!(
            BitmexTimeInForce::try_from(TimeInForce::Day).unwrap(),
            BitmexTimeInForce::Day
        );
        assert_eq!(
            BitmexTimeInForce::try_from(TimeInForce::Gtc).unwrap(),
            BitmexTimeInForce::GoodTillCancel
        );
        assert_eq!(
            BitmexTimeInForce::try_from(TimeInForce::Fok).unwrap(),
            BitmexTimeInForce::FillOrKill
        );
    }

    #[rstest]
    fn test_helper_methods() {
        // Test try_from_order_type helper
        let result = BitmexOrderType::try_from_order_type(OrderType::Limit);
        assert!(result.is_ok());
        assert_eq!(result.unwrap(), BitmexOrderType::Limit);

        let result = BitmexOrderType::try_from_order_type(OrderType::MarketToLimit);
        assert!(result.is_err());

        // Test try_from_time_in_force helper
        let result = BitmexTimeInForce::try_from_time_in_force(TimeInForce::Ioc);
        assert!(result.is_ok());
        assert_eq!(result.unwrap(), BitmexTimeInForce::ImmediateOrCancel);
    }
}
