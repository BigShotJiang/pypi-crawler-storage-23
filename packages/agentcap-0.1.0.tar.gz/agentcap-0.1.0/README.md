# agentcap
`agentcap` is a cost guardrail for LLM agent runs. It calculates safe token limits before execution and enforces strict budget ceilings using real usage data.

## Install

```bash
pip install agentcap
```

## Documentation
See [DOCUMENTATION.md](DOCUMENTATION.md) for full usage details.

## Supported models
See [agentcap/models.json](agentcap/models.json) for the list of currently supported models.
To add more models, open a PR.

Note: Prices may change. Please verify with the provider.

## Model pricing sources
OpenAI pricing: https://developers.openai.com/api/docs/pricing?latest-pricing=standard  
Anthropic pricing: https://platform.claude.com/docs/en/about-claude/pricing  
Gemini pricing: https://ai.google.dev/gemini-api/docs/pricing#standard
