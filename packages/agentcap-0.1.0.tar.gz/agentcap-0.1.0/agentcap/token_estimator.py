from math import ceil

def estimate_tokens(text: str) -> int:
    if not text:
        return 0
    return ceil(len(text) / 4) + 30
