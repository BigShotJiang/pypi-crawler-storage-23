from __future__ import annotations

from dataclasses import dataclass
import json
import importlib.resources as resources

from .exceptions import InvalidArguments, UnknownModelError

@dataclass(frozen=True, slots=True)
class ModelPrice:
    input_per_1m: float
    output_per_1m: float

def _load_model_prices() -> dict[str, dict[str, float]]:
    data_file = resources.files(__package__).joinpath("models.json")
    with data_file.open("r", encoding="utf-8") as handle:
        raw = json.load(handle)
    if not isinstance(raw, dict):
        raise InvalidArguments("models.json must contain a JSON object at the root")
    return raw

def get_model_price(model: str) -> ModelPrice:
    if not isinstance(model, str) or not model.strip():
        raise InvalidArguments("model must be a non-empty string")

    models = _load_model_prices()
    model_key = model.strip()
    if model_key not in models:
        raise UnknownModelError(f"Unknown model: {model_key}")

    row = models[model_key]
    try:
        input_per_1m = float(row["input_per_1m"])
        output_per_1m = float(row["output_per_1m"])
    except (TypeError, KeyError, ValueError) as exc:
        raise InvalidArguments(f"Invalid pricing entry for model: {model_key}") from exc

    return ModelPrice(input_per_1m=input_per_1m, output_per_1m=output_per_1m)
