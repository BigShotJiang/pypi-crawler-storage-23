from __future__ import annotations

from dataclasses import dataclass
from math import floor

from .exceptions import BudgetExceeded, InvalidArguments
from .pricing import get_model_price
from .token_estimator import estimate_tokens

@dataclass(slots=True)
class PlanResult:
    model: str
    budget_usd: float
    effective_budget_usd: float
    prompt_tokens: int
    estimated_input_cost_usd: float
    remaining_budget_usd: float
    max_output_tokens: int
    warnings: list[str]

class AgentCap:
    def __init__(
        self,
        model: str,
        budget_usd: float,
        safety_margin: float = 0.90,
        min_output_tokens: int = 16,
        low_budget_warning_threshold: float = 0.15,
    ) -> None:
        if not isinstance(model, str) or not model.strip():
            raise InvalidArguments("model must be a non-empty string")
        if budget_usd <= 0:
            raise InvalidArguments("budget_usd must be greater than 0")
        if not (0 < safety_margin <= 1):
            raise InvalidArguments("safety_margin must be in the range (0, 1]")
        if min_output_tokens < 1:
            raise InvalidArguments("min_output_tokens must be >= 1")
        if not (0 <= low_budget_warning_threshold <= 1):
            raise InvalidArguments(
                "low_budget_warning_threshold must be in the range [0, 1]"
            )

        self.model = model.strip()
        self.budget_usd = float(budget_usd)
        self.safety_margin = float(safety_margin)
        self.min_output_tokens = int(min_output_tokens)
        self.low_budget_warning_threshold = float(low_budget_warning_threshold)
        self._price = get_model_price(self.model)

    def estimate_cost(self, prompt_tokens: int, output_tokens: int) -> float:
        if prompt_tokens < 0 or output_tokens < 0:
            raise InvalidArguments("prompt_tokens and output_tokens must be >= 0")

        input_cost = (prompt_tokens / 1_000_000) * self._price.input_per_1m
        output_cost = (output_tokens / 1_000_000) * self._price.output_per_1m
        return input_cost + output_cost

    def plan(self, prompt_text: str) -> PlanResult:
        if not isinstance(prompt_text, str) or not prompt_text.strip():
            raise InvalidArguments("prompt_text must be a non-empty string")

        prompt_tokens = estimate_tokens(prompt_text)
        effective_budget = self.budget_usd * self.safety_margin
        input_cost = (prompt_tokens / 1_000_000) * self._price.input_per_1m

        if input_cost >= effective_budget:
            raise BudgetExceeded("Prompt alone exceeds budget.")

        remaining = effective_budget - input_cost
        cost_per_output_token = self._price.output_per_1m / 1_000_000
        if cost_per_output_token <= 0:
            raise InvalidArguments("model output pricing must be greater than 0")

        max_output_tokens = floor(remaining / cost_per_output_token)
        if max_output_tokens < self.min_output_tokens:
            raise BudgetExceeded("Not enough budget for minimum output tokens.")

        warnings: list[str] = []
        if remaining <= self.budget_usd * self.low_budget_warning_threshold:
            warnings.append(
                "Low remaining budget after prompt. Consider increasing budget or "
                "shortening prompt."
            )

        return PlanResult(
            model=self.model,
            budget_usd=self.budget_usd,
            effective_budget_usd=effective_budget,
            prompt_tokens=prompt_tokens,
            estimated_input_cost_usd=input_cost,
            remaining_budget_usd=remaining,
            max_output_tokens=max_output_tokens,
            warnings=warnings,
        )

    def finalize(self, prompt_tokens: int, output_tokens: int) -> float:
        actual_cost = self.estimate_cost(prompt_tokens, output_tokens)
        if actual_cost > self.budget_usd:
            raise BudgetExceeded("Run exceeded budget.")
        return actual_cost
