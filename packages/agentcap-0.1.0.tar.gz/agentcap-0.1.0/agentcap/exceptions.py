class UnknownModelError(ValueError):
    """Raised when a model name is not found in pricing data."""

class BudgetExceeded(RuntimeError):
    """Raised when a planned or actual run exceeds budget constraints."""

class InvalidArguments(ValueError):
    """Raised when inputs are invalid."""
