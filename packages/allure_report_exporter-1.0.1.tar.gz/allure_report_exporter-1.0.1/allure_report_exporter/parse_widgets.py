from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Iterable

from .model import (
    AttachmentRef,
    FailureDetail,
    ParameterEntry,
    ReportData,
    ReportMetadata,
    StatusCounts,
    SuiteOverviewRow,
    TestDetail,
    TrendPoint,
)

LOGGER = logging.getLogger(__name__)
EXCERPT_LIMIT = 600
STEP_SUMMARY_LIMIT = 80


def parse_report_widgets(
    html_report_dir: Path,
    metadata: ReportMetadata,
    include_attachments: bool = True,
    max_tests: int | None = None,
) -> ReportData:
    resolved_root = html_report_dir.resolve()
    widgets_dir = resolved_root / "widgets"
    data_dir = resolved_root / "data"
    notes: list[str] = []

    summary_payload = _load_json(widgets_dir / "summary.json")
    if not isinstance(summary_payload, dict):
        notes.append("Summary widget: Not available.")
        counts = StatusCounts()
        duration_ms: int | None = None
    else:
        counts = StatusCounts.from_mapping(summary_payload.get("statistic"))
        duration_ms = _read_duration(summary_payload.get("time"))

    suites = _parse_suites(widgets_dir, notes)
    trend = _parse_trend(widgets_dir, notes)
    tests, failures, tests_truncated = _parse_test_cases(
        data_dir=data_dir,
        include_attachments=include_attachments,
        max_tests=max_tests,
        notes=notes,
    )

    widgets_found: list[str] = []
    if widgets_dir.exists():
        widgets_found = sorted(path.name for path in widgets_dir.glob("*.json"))

    return ReportData(
        metadata=metadata,
        summary=counts,
        duration_ms=duration_ms,
        suites=suites,
        failures=failures,
        tests=tests,
        trend=trend,
        notes=notes,
        widgets_found=widgets_found,
        tests_truncated=tests_truncated,
        html_report_dir=resolved_root,
    )


def _load_json(path: Path) -> Any:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        LOGGER.warning("Invalid JSON in %s", path)
        return None


def _read_duration(time_mapping: Any) -> int | None:
    if not isinstance(time_mapping, dict):
        return None
    for key in ("duration", "sumDuration"):
        value = _int_or_none(time_mapping.get(key))
        if value is not None and value >= 0:
            return value
    start = _int_or_none(time_mapping.get("start"))
    stop = _int_or_none(time_mapping.get("stop"))
    if start is not None and stop is not None and stop >= start:
        return stop - start
    return None


def _parse_suites(widgets_dir: Path, notes: list[str]) -> list[SuiteOverviewRow]:
    for filename in ("suites.json", "packages.json"):
        payload = _load_json(widgets_dir / filename)
        if payload is None:
            continue
        rows = _suite_rows_from_payload(payload)
        if rows:
            return rows
    notes.append("Suites/Packages overview: Not available.")
    return []


def _suite_rows_from_payload(payload: Any) -> list[SuiteOverviewRow]:
    rows: list[SuiteOverviewRow] = []
    if isinstance(payload, dict):
        children = payload.get("children")
        if isinstance(children, list):
            for child in children:
                if not isinstance(child, dict):
                    continue
                name = str(child.get("name") or "(unnamed)")
                counts = StatusCounts.from_mapping(child.get("statistic"))
                rows.append(SuiteOverviewRow(name=name, counts=counts))
    elif isinstance(payload, list):
        for node in payload:
            if not isinstance(node, dict):
                continue
            name = str(node.get("name") or "(unnamed)")
            counts = StatusCounts.from_mapping(node.get("statistic"))
            rows.append(SuiteOverviewRow(name=name, counts=counts))
    return rows


def _parse_trend(widgets_dir: Path, notes: list[str]) -> list[TrendPoint]:
    payload = _load_json(widgets_dir / "history-trend.json")
    if not isinstance(payload, list):
        notes.append("Trend: Not available.")
        return []
    trend: list[TrendPoint] = []
    for index, point in enumerate(payload):
        if not isinstance(point, dict):
            continue
        label = (
            str(point.get("reportName"))
            if point.get("reportName")
            else str(point.get("buildName") or point.get("buildOrder") or f"Run {index + 1}")
        )
        counts = StatusCounts.from_mapping(point.get("data") or point.get("statistic"))
        trend.append(TrendPoint(label=label, counts=counts))
    if not trend:
        notes.append("Trend: Not available.")
    return trend


def _parse_test_cases(
    data_dir: Path,
    include_attachments: bool,
    max_tests: int | None,
    notes: list[str],
) -> tuple[list[TestDetail], list[FailureDetail], bool]:
    test_cases_dir = data_dir / "test-cases"
    attachments_dir = data_dir / "attachments"
    if not test_cases_dir.exists():
        notes.append("Per-test details: Not available (data/test-cases missing).")
        return [], [], False

    tests: list[TestDetail] = []
    failures: list[FailureDetail] = []
    truncated = False

    for case_path in sorted(test_cases_dir.glob("*.json")):
        payload = _load_json(case_path)
        if not isinstance(payload, dict):
            continue
        detail = _to_test_detail(payload, attachments_dir, include_attachments)
        if max_tests is None or len(tests) < max_tests:
            tests.append(detail)
        else:
            truncated = True
        if detail.status in {"failed", "broken"}:
            failures.append(
                FailureDetail(
                    uid=detail.uid,
                    name=detail.name,
                    status=detail.status,
                    message_excerpt=_excerpt(detail.message),
                    trace_excerpt=_excerpt(detail.trace),
                    attachments=detail.attachments,
                )
            )
    return tests, failures, truncated


def _to_test_detail(
    payload: dict[str, Any],
    attachments_dir: Path,
    include_attachments: bool,
) -> TestDetail:
    uid = str(payload.get("uid") or "")
    name = str(payload.get("name") or "(unnamed)")
    full_name = str(payload.get("fullName") or name)
    status = str(payload.get("status") or "unknown").lower()
    if status not in {"passed", "failed", "broken", "skipped", "unknown"}:
        status = "unknown"
    labels = _extract_labels(payload.get("labels"))
    suites = _extract_suites(labels)
    details = payload.get("statusDetails") or {}
    stage = payload.get("testStage") or {}
    message = str(
        details.get("message")
        or payload.get("statusMessage")
        or (stage.get("statusMessage") if isinstance(stage, dict) else "")
        or ""
    )
    trace = str(
        details.get("trace")
        or payload.get("statusTrace")
        or (stage.get("statusTrace") if isinstance(stage, dict) else "")
        or ""
    )
    duration_ms = _extract_duration(payload.get("time"))
    parameters = _extract_parameters(payload.get("parameters"))
    setup_steps = _flatten_steps(_collect_stage_steps(payload, "beforeStages"))
    execution_steps = _flatten_steps(_collect_execution_steps(payload))
    teardown_steps = _flatten_steps(_collect_stage_steps(payload, "afterStages"))
    steps_summary = setup_steps + execution_steps + teardown_steps

    attachments: list[AttachmentRef] = []
    if include_attachments:
        attachments = _extract_attachments(payload, attachments_dir)

    return TestDetail(
        uid=uid,
        name=name,
        full_name=full_name,
        status=status,
        duration_ms=duration_ms,
        suites=suites,
        labels=labels,
        message=message,
        trace=trace,
        parameters=parameters,
        setup_steps=setup_steps,
        execution_steps=execution_steps,
        teardown_steps=teardown_steps,
        steps_summary=steps_summary,
        attachments=attachments,
    )


def _extract_labels(raw_labels: Any) -> dict[str, list[str]]:
    labels: dict[str, list[str]] = {}
    if not isinstance(raw_labels, list):
        return labels
    for item in raw_labels:
        if not isinstance(item, dict):
            continue
        key = str(item.get("name") or "").strip()
        value = str(item.get("value") or "").strip()
        if not key or not value:
            continue
        labels.setdefault(key, [])
        if value not in labels[key]:
            labels[key].append(value)
    return labels


def _extract_suites(labels: dict[str, list[str]]) -> list[str]:
    names: list[str] = []
    for key in ("parentSuite", "suite", "subSuite", "package", "testClass"):
        for value in labels.get(key, []):
            if value not in names:
                names.append(value)
    return names


def _extract_parameters(raw_parameters: Any) -> list[ParameterEntry]:
    if not isinstance(raw_parameters, list):
        return []
    parameters: list[ParameterEntry] = []
    seen: set[tuple[str, str]] = set()
    for item in raw_parameters:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip()
        value = str(item.get("value") or "").strip()
        if not name:
            continue
        key = (name, value)
        if key in seen:
            continue
        seen.add(key)
        parameters.append(ParameterEntry(name=name, value=value))
    return parameters


def _extract_duration(raw_time: Any) -> int | None:
    if not isinstance(raw_time, dict):
        return None
    duration = _int_or_none(raw_time.get("duration"))
    if duration is not None:
        return max(0, duration)
    start = _int_or_none(raw_time.get("start"))
    stop = _int_or_none(raw_time.get("stop"))
    if start is not None and stop is not None and stop >= start:
        return stop - start
    return None


def _flatten_steps(raw_steps: Any) -> list[str]:
    if not isinstance(raw_steps, list):
        return []

    lines: list[str] = []

    def walk(steps: Iterable[Any], depth: int) -> None:
        for step in steps:
            if len(lines) >= STEP_SUMMARY_LIMIT:
                return
            if not isinstance(step, dict):
                continue
            step_name = str(step.get("name") or "(step)")
            status = str(step.get("status") or "unknown")
            duration = _extract_duration(step.get("time"))
            suffix = f" [{status}]"
            if duration is not None:
                suffix += f" ({duration} ms)"
            lines.append(f"{'  ' * depth}{step_name}{suffix}")
            child_steps = step.get("steps")
            if isinstance(child_steps, list):
                walk(child_steps, depth + 1)

    walk(raw_steps, 0)
    return lines


def _extract_attachments(payload: dict[str, Any], attachments_dir: Path) -> list[AttachmentRef]:
    raw_attachments: list[dict[str, Any]] = []
    seen: set[str] = set()

    for attachment_container in _attachment_containers(payload):
        if isinstance(attachment_container, list):
            raw_attachments.extend(
                item for item in attachment_container if isinstance(item, dict)
            )

    def walk_steps(raw_steps: Any) -> None:
        if not isinstance(raw_steps, list):
            return
        for step in raw_steps:
            if not isinstance(step, dict):
                continue
            step_attachments = step.get("attachments")
            if isinstance(step_attachments, list):
                raw_attachments.extend(item for item in step_attachments if isinstance(item, dict))
            walk_steps(step.get("steps"))

    walk_steps(_collect_step_roots(payload))

    attachments: list[AttachmentRef] = []
    for raw in raw_attachments:
        source = str(raw.get("source") or "").strip()
        if not source or source in seen:
            continue
        seen.add(source)
        name = str(raw.get("name") or source)
        mime_type = str(raw.get("type") or "application/octet-stream")
        path = attachments_dir / source
        exists = path.exists()
        if not exists:
            LOGGER.warning("Attachment referenced but missing: %s", path)
        attachments.append(
            AttachmentRef(
                name=name,
                mime_type=mime_type,
                source=source,
                path=path,
                exists=exists,
                inline_image=exists and mime_type.startswith("image/"),
            )
        )
    return attachments


def _collect_step_roots(payload: dict[str, Any]) -> list[Any]:
    roots: list[Any] = []
    roots.extend(_collect_stage_steps(payload, "beforeStages"))
    roots.extend(_collect_execution_steps(payload))
    roots.extend(_collect_stage_steps(payload, "afterStages"))
    return roots


def _collect_execution_steps(payload: dict[str, Any]) -> list[Any]:
    roots: list[Any] = []
    if isinstance(payload.get("steps"), list):
        roots.extend(payload.get("steps"))

    test_stage = payload.get("testStage")
    if isinstance(test_stage, dict) and isinstance(test_stage.get("steps"), list):
        roots.extend(test_stage.get("steps"))
    return roots


def _collect_stage_steps(payload: dict[str, Any], stage_key: str) -> list[Any]:
    roots: list[Any] = []
    stages = payload.get(stage_key)
    if not isinstance(stages, list):
        return roots
    for stage in stages:
        if isinstance(stage, dict) and isinstance(stage.get("steps"), list):
            roots.extend(stage.get("steps"))
    return roots


def _attachment_containers(payload: dict[str, Any]) -> list[Any]:
    containers: list[Any] = [payload.get("attachments")]

    test_stage = payload.get("testStage")
    if isinstance(test_stage, dict):
        containers.append(test_stage.get("attachments"))

    for stage_key in ("beforeStages", "afterStages"):
        stages = payload.get(stage_key)
        if not isinstance(stages, list):
            continue
        for stage in stages:
            if isinstance(stage, dict):
                containers.append(stage.get("attachments"))

    return containers


def _excerpt(value: str, limit: int = EXCERPT_LIMIT) -> str:
    normalized = value.strip()
    if len(normalized) <= limit:
        return normalized
    return f"{normalized[: limit - 3]}..."


def _int_or_none(value: Any) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return int(value)
    try:
        return int(value)
    except (TypeError, ValueError):
        return None
