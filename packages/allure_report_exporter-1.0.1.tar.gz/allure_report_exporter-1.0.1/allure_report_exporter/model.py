from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

STATUS_KEYS = ("passed", "failed", "broken", "skipped", "unknown")


def _int_or_zero(value: Any) -> int:
    if value is None:
        return 0
    if isinstance(value, bool):
        return int(value)
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0


@dataclass(slots=True)
class StatusCounts:
    total: int = 0
    passed: int = 0
    failed: int = 0
    broken: int = 0
    skipped: int = 0
    unknown: int = 0

    @classmethod
    def from_mapping(cls, mapping: Mapping[str, Any] | None) -> "StatusCounts":
        mapping = mapping or {}
        return cls(
            total=_int_or_zero(mapping.get("total")),
            passed=_int_or_zero(mapping.get("passed")),
            failed=_int_or_zero(mapping.get("failed")),
            broken=_int_or_zero(mapping.get("broken")),
            skipped=_int_or_zero(mapping.get("skipped")),
            unknown=_int_or_zero(mapping.get("unknown")),
        )

    @property
    def computed_total(self) -> int:
        return self.passed + self.failed + self.broken + self.skipped + self.unknown

    @property
    def pass_rate(self) -> float:
        denominator = self.total if self.total > 0 else self.computed_total
        if denominator <= 0:
            return 0.0
        return (self.passed / denominator) * 100.0


@dataclass(slots=True)
class ReportMetadata:
    title: str = "Allure Test Report"
    project: str = ""
    build_url: str = ""
    commit: str = ""
    branch: str = ""
    logo_path: str = ""
    footer_text: str = ""
    environment: dict[str, str] = field(default_factory=dict)
    generated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass(slots=True)
class AttachmentRef:
    name: str
    mime_type: str
    source: str
    path: Path | None
    exists: bool
    inline_image: bool

    @property
    def uri(self) -> str:
        if self.path is None:
            return ""
        try:
            return self.path.resolve().as_uri()
        except (ValueError, OSError):
            return ""


@dataclass(slots=True)
class SuiteOverviewRow:
    name: str
    counts: StatusCounts


@dataclass(slots=True)
class ParameterEntry:
    name: str
    value: str


@dataclass(slots=True)
class TrendPoint:
    label: str
    counts: StatusCounts


@dataclass(slots=True)
class FailureDetail:
    uid: str
    name: str
    status: str
    message_excerpt: str
    trace_excerpt: str
    attachments: list[AttachmentRef] = field(default_factory=list)


@dataclass(slots=True)
class TestDetail:
    uid: str
    name: str
    full_name: str
    status: str
    duration_ms: int | None
    suites: list[str]
    labels: dict[str, list[str]]
    steps_summary: list[str]
    message: str
    trace: str
    parameters: list[ParameterEntry] = field(default_factory=list)
    setup_steps: list[str] = field(default_factory=list)
    execution_steps: list[str] = field(default_factory=list)
    teardown_steps: list[str] = field(default_factory=list)
    attachments: list[AttachmentRef] = field(default_factory=list)


@dataclass(slots=True)
class ReportData:
    metadata: ReportMetadata
    summary: StatusCounts
    duration_ms: int | None
    suites: list[SuiteOverviewRow] = field(default_factory=list)
    failures: list[FailureDetail] = field(default_factory=list)
    tests: list[TestDetail] = field(default_factory=list)
    trend: list[TrendPoint] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    widgets_found: list[str] = field(default_factory=list)
    tests_truncated: bool = False
    html_report_dir: Path | None = None

    @property
    def pass_rate(self) -> float:
        return self.summary.pass_rate
