from __future__ import annotations

import argparse
import logging
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Sequence

from .allure_cli import AllureCliError, generate_report
from .model import ReportMetadata
from .parse_widgets import parse_report_widgets
from .render_html import render_report_html

LOGGER = logging.getLogger(__name__)


class ReportBuildError(RuntimeError):
    """Raised for build-stage dependency or rendering errors."""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="allure-report",
        description=(
            "Generate professional PDF and DOCX reports from Allure results by first "
            "building an Allure HTML report with Allure CLI."
        ),
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    build = subparsers.add_parser("build", help="Build report outputs from allure-results.")
    build.add_argument("--results", required=True, help="Path to allure-results directory.")
    build.add_argument("--out", required=True, help="Output directory for generated artifacts.")
    build.add_argument(
        "--format",
        choices=("html", "pdf", "docx", "both"),
        default="both",
        help="Output format. html keeps generated report artifacts only.",
    )
    build.add_argument(
        "--allure-binary",
        default=None,
        help="Optional explicit path to Allure executable.",
    )
    build.add_argument(
        "--single-file",
        action="store_true",
        help="Pass --single-file to allure generate when supported by the installed CLI.",
    )
    build.add_argument(
        "--keep-html",
        dest="keep_html",
        action="store_true",
        default=True,
        help="Keep generated Allure HTML report folder (default: true).",
    )
    build.add_argument(
        "--discard-html",
        dest="keep_html",
        action="store_false",
        help="Delete generated Allure HTML report folder after export.",
    )
    build.add_argument("--title", default="Allure Test Report", help="Report title.")
    build.add_argument("--project", default="", help="Project name displayed on the cover page.")
    build.add_argument("--build-url", default="", help="Build URL metadata.")
    build.add_argument("--commit", default="", help="Commit SHA metadata.")
    build.add_argument("--branch", default="", help="Branch metadata.")
    build.add_argument(
        "--logo-path",
        default="",
        help="Optional local logo image path to render on the cover page.",
    )
    build.add_argument(
        "--footer-text",
        default="",
        help="Optional footer text rendered on HTML/PDF and DOCX report pages.",
    )
    build.add_argument(
        "--template-file",
        default="",
        help="Optional custom Jinja2 template file path for printable HTML rendering.",
    )
    build.add_argument(
        "--css-file",
        default="",
        help="Optional custom CSS file path used by the printable HTML template.",
    )
    build.add_argument(
        "--environment",
        action="append",
        default=[],
        metavar="KEY:VALUE",
        help="Environment entry. Repeat for multiple values.",
    )
    build.add_argument(
        "--include-attachments",
        dest="include_attachments",
        action="store_true",
        default=True,
        help="Include attachments in generated outputs (default: true).",
    )
    build.add_argument(
        "--no-include-attachments",
        dest="include_attachments",
        action="store_false",
        help="Do not include attachments in generated outputs.",
    )
    build.add_argument(
        "--max-tests",
        type=int,
        default=200,
        help="Max test cases in per-test detail section.",
    )
    build.add_argument(
        "--log-level",
        default="INFO",
        choices=("DEBUG", "INFO", "WARNING", "ERROR"),
        help="Log verbosity.",
    )
    build.set_defaults(handler=run_build)
    return parser


def run_build(args: argparse.Namespace) -> int:
    logging.basicConfig(
        level=getattr(logging, args.log_level.upper(), logging.INFO),
        format="%(levelname)s %(name)s - %(message)s",
    )
    if args.max_tests is not None and args.max_tests <= 0:
        raise ValueError("--max-tests must be greater than 0.")

    results_dir = Path(args.results).expanduser().resolve()
    out_dir = Path(args.out).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    html_report_dir = out_dir / "allure-report-html"

    LOGGER.info("Generating Allure HTML report with Allure CLI.")
    generate_report(
        results_dir=results_dir,
        out_dir=html_report_dir,
        allure_binary=args.allure_binary,
        single_file=args.single_file,
    )

    metadata = ReportMetadata(
        title=args.title,
        project=args.project,
        build_url=args.build_url,
        commit=args.commit,
        branch=args.branch,
        logo_path=args.logo_path,
        footer_text=args.footer_text,
        environment=parse_environment_values(args.environment),
        generated_at=datetime.now(timezone.utc),
    )
    LOGGER.info("Parsing report widgets and data files.")
    report_data = parse_report_widgets(
        html_report_dir=html_report_dir,
        metadata=metadata,
        include_attachments=args.include_attachments,
        max_tests=args.max_tests,
    )

    outputs: list[Path] = []
    printable_html = out_dir / "report-print.html"
    render_report_html(
        report=report_data,
        output_html_path=printable_html,
        include_attachments=args.include_attachments,
        template_path=Path(args.template_file).expanduser().resolve()
        if args.template_file
        else None,
        css_path=Path(args.css_file).expanduser().resolve() if args.css_file else None,
    )
    outputs.append(printable_html)

    if args.format in {"pdf", "both"}:
        try:
            from .pdf import PdfRenderError, build_pdf
        except ImportError as exc:
            raise ReportBuildError(
                "PDF output requested but Playwright dependency is missing. "
                "Install project dependencies and run `playwright install chromium`."
            ) from exc
        LOGGER.info("Rendering PDF output.")
        try:
            outputs.append(build_pdf(printable_html, out_dir / "report.pdf"))
        except PdfRenderError as exc:
            raise ReportBuildError(str(exc)) from exc

    if args.format in {"docx", "both"}:
        try:
            from .docx import DocxRenderError, build_docx
        except ImportError as exc:
            raise ReportBuildError(
                "DOCX output requested but python-docx is missing. "
                "Install project dependencies first."
            ) from exc
        LOGGER.info("Rendering DOCX output.")
        try:
            outputs.append(
                build_docx(
                    report=report_data,
                    output_docx_path=out_dir / "report.docx",
                    include_attachments=args.include_attachments,
                )
            )
        except DocxRenderError as exc:
            raise ReportBuildError(str(exc)) from exc

    if args.format == "html":
        LOGGER.info("HTML artifacts generated only.")

    keep_html = args.keep_html or args.format == "html"
    if not keep_html and html_report_dir.exists():
        LOGGER.info("Removing generated Allure HTML report directory.")
        shutil.rmtree(html_report_dir, ignore_errors=True)

    LOGGER.info("Generated outputs:")
    for output in outputs:
        LOGGER.info(" - %s", output)
    if keep_html:
        LOGGER.info(" - %s", html_report_dir)
    return 0


def parse_environment_values(values: Sequence[str]) -> dict[str, str]:
    environment: dict[str, str] = {}
    for item in values:
        if ":" not in item:
            raise ValueError(
                f"Invalid --environment value '{item}'. Expected KEY:VALUE format."
            )
        key, value = item.split(":", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            raise ValueError(
                f"Invalid --environment value '{item}'. Key cannot be empty."
            )
        environment[key] = value
    return environment


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    handler = getattr(args, "handler", None)
    if handler is None:
        parser.print_help()
        return 2
    try:
        return int(handler(args))
    except (AllureCliError, ReportBuildError, ValueError, OSError) as exc:
        LOGGER.error("%s", exc)
        return 1
