from __future__ import annotations

import logging
import math
import re
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape
from markupsafe import Markup

from .model import ReportData

ASSETS_DIR = Path(__file__).resolve().parent / "assets"
LOGGER = logging.getLogger(__name__)
STATUS_COLORS = {
    "passed": "#2e7d32",
    "failed": "#c62828",
    "broken": "#ef6c00",
    "skipped": "#546e7a",
    "unknown": "#7b1fa2",
}
ANCHOR_SAFE_PATTERN = re.compile(r"[^A-Za-z0-9_-]+")


def render_report_html(
    report: ReportData,
    output_html_path: Path,
    include_attachments: bool = True,
    template_path: Path | None = None,
    css_path: Path | None = None,
) -> Path:
    resolved_template = template_path.resolve() if template_path else ASSETS_DIR / "report_template.html.j2"
    resolved_css = css_path.resolve() if css_path else ASSETS_DIR / "report.css"
    if not resolved_template.exists():
        raise FileNotFoundError(f"Template file does not exist: {resolved_template}")
    if not resolved_css.exists():
        raise FileNotFoundError(f"CSS file does not exist: {resolved_css}")

    env = Environment(
        loader=FileSystemLoader(str(resolved_template.parent)),
        autoescape=select_autoescape(["html", "xml"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    template = env.get_template(resolved_template.name)
    css = resolved_css.read_text(encoding="utf-8")
    chart_svg = Markup(_build_status_donut_svg(report.summary))
    test_anchor_map = {
        test.uid: make_test_anchor_id(uid=test.uid, index=index)
        for index, test in enumerate(report.tests, start=1)
    }
    logo_uri = _to_file_uri(report.metadata.logo_path) if report.metadata.logo_path else ""

    rendered = template.render(
        report=report,
        css=css,
        logo_uri=logo_uri,
        footer_text=report.metadata.footer_text.strip(),
        status_chart_svg=chart_svg,
        include_attachments=include_attachments,
        format_duration=format_duration,
        make_test_anchor_id=make_test_anchor_id,
        test_anchor_map=test_anchor_map,
    )
    output_html_path.parent.mkdir(parents=True, exist_ok=True)
    output_html_path.write_text(rendered, encoding="utf-8")
    return output_html_path


def format_duration(duration_ms: int | None) -> str:
    if duration_ms is None:
        return "Not available"
    if duration_ms < 1000:
        return f"{duration_ms} ms"
    seconds = duration_ms / 1000.0
    if seconds < 60:
        return f"{seconds:.2f} s"
    minutes = seconds / 60.0
    if minutes < 60:
        return f"{minutes:.2f} min"
    hours = minutes / 60.0
    return f"{hours:.2f} h"


def make_test_anchor_id(uid: str, index: int) -> str:
    raw = uid.strip() if uid else f"case-{index}"
    slug = ANCHOR_SAFE_PATTERN.sub("-", raw).strip("-")
    if not slug:
        slug = f"case-{index}"
    return f"test-{index}-{slug}"


def _to_file_uri(path_value: str) -> str:
    candidate = Path(path_value).expanduser()
    if not candidate.exists():
        LOGGER.warning("Logo file does not exist: %s", candidate)
        return ""
    try:
        return candidate.resolve().as_uri()
    except (ValueError, OSError):
        LOGGER.warning("Could not convert logo path to URI: %s", candidate)
        return ""


def _build_status_donut_svg(summary: object) -> str:
    total = max(getattr(summary, "total", 0), 0)
    if total <= 0:
        total = max(getattr(summary, "computed_total", 0), 0)
    if total <= 0:
        total = 1

    size = 240
    stroke = 42
    radius = (size - stroke) / 2.0
    center = size / 2.0
    circumference = 2.0 * math.pi * radius

    segments: list[str] = []
    offset = 0.0
    for status in ("passed", "failed", "broken", "skipped", "unknown"):
        value = max(0, int(getattr(summary, status, 0)))
        if value <= 0:
            continue
        segment = circumference * (value / total)
        color = STATUS_COLORS[status]
        segments.append(
            "<circle class='ring-segment' "
            f"cx='{center}' cy='{center}' r='{radius}' "
            f"stroke='{color}' stroke-width='{stroke}' fill='none' "
            "stroke-linecap='butt' "
            f"stroke-dasharray='{segment:.4f} {circumference:.4f}' "
            f"stroke-dashoffset='{-offset:.4f}' "
            f"transform='rotate(-90 {center} {center})' />"
        )
        offset += segment

    return (
        "<svg viewBox='0 0 240 240' role='img' aria-label='Status distribution chart'>"
        "<circle cx='120' cy='120' r='99' stroke='#eceff1' stroke-width='42' fill='none'/>"
        + "".join(segments)
        + f"<text x='120' y='115' text-anchor='middle' class='chart-total'>{int(getattr(summary, 'total', 0))}</text>"
        + "<text x='120' y='137' text-anchor='middle' class='chart-label'>Total</text>"
        + "</svg>"
    )
