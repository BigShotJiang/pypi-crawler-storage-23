from __future__ import annotations

from pathlib import Path


class PdfRenderError(RuntimeError):
    """Raised when PDF rendering cannot be completed."""


def check_playwright_ready() -> tuple[bool, str]:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return (
            False,
            "Playwright is not installed. Install dependencies then run: playwright install chromium",
        )

    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(headless=True)
            browser.close()
    except Exception as exc:  # pragma: no cover - environment-dependent
        return (
            False,
            "Playwright Chromium is unavailable. Run: playwright install chromium "
            f"(details: {exc})",
        )
    return True, ""


def build_pdf(report_html_path: Path, output_pdf_path: Path) -> Path:
    ready, reason = check_playwright_ready()
    if not ready:
        raise PdfRenderError(reason)

    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:  # pragma: no cover - handled above
        raise PdfRenderError(
            "Playwright is not installed. Install dependencies and run playwright install chromium."
        ) from exc

    report_html_path = report_html_path.resolve()
    output_pdf_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(report_html_path.as_uri(), wait_until="load")
            page.emulate_media(media="print")
            page.pdf(
                path=str(output_pdf_path),
                format="A4",
                print_background=True,
                margin={"top": "0.5in", "right": "0.4in", "bottom": "0.5in", "left": "0.4in"},
            )
            browser.close()
    except Exception as exc:
        if isinstance(exc, PermissionError):
            raise PdfRenderError(
                "Failed to write PDF file because it is locked or not writable. "
                "Close the PDF if open and retry."
            ) from exc
        raise PdfRenderError(
            "Failed to generate PDF with Playwright. "
            "Ensure Chromium is installed via `playwright install chromium`. "
            f"Details: {exc}"
        ) from exc

    if not output_pdf_path.exists() or output_pdf_path.stat().st_size <= 0:
        raise PdfRenderError(f"PDF was not created or is empty: {output_pdf_path}")
    return output_pdf_path
