from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.shared import Inches

from .model import ReportData
from .render_html import format_duration


class DocxRenderError(RuntimeError):
    """Raised for DOCX generation errors."""


def build_docx(
    report: ReportData,
    output_docx_path: Path,
    include_attachments: bool = True,
) -> Path:
    document = Document()
    _apply_branding(document, report)
    _add_cover(document, report)
    document.add_page_break()
    _add_contents(document, report)
    _add_executive_summary(document, report)
    _add_suites_overview(document, report)
    _add_failures(document, report)
    _add_test_details(document, report, include_attachments=include_attachments)

    output_docx_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        document.save(str(output_docx_path))
    except Exception as exc:
        raise DocxRenderError(f"Failed to save DOCX file: {output_docx_path}") from exc

    if not output_docx_path.exists() or output_docx_path.stat().st_size <= 0:
        raise DocxRenderError(f"DOCX was not created or is empty: {output_docx_path}")
    return output_docx_path


def _add_cover(document: Document, report: ReportData) -> None:
    if report.metadata.logo_path:
        logo_path = Path(report.metadata.logo_path).expanduser()
        if logo_path.exists() and logo_path.is_file():
            try:
                document.add_picture(str(logo_path), width=Inches(1.8))
            except Exception:
                document.add_paragraph(f"Logo rendering skipped: {logo_path}")
    document.add_heading(report.metadata.title, level=0)
    if report.metadata.project:
        document.add_paragraph(f"Project: {report.metadata.project}")
    document.add_paragraph(f"Generated: {report.metadata.generated_at.isoformat()}")
    if report.metadata.build_url:
        document.add_paragraph(f"Build URL: {report.metadata.build_url}")
    if report.metadata.commit:
        document.add_paragraph(f"Commit: {report.metadata.commit}")
    if report.metadata.branch:
        document.add_paragraph(f"Branch: {report.metadata.branch}")

    document.add_heading("Environment", level=1)
    if report.metadata.environment:
        table = document.add_table(rows=1, cols=2)
        table.style = "Table Grid"
        table.rows[0].cells[0].text = "Key"
        table.rows[0].cells[1].text = "Value"
        for key, value in sorted(report.metadata.environment.items()):
            row = table.add_row().cells
            row[0].text = key
            row[1].text = value
    else:
        document.add_paragraph("Not provided")


def _add_contents(document: Document, report: ReportData) -> None:
    document.add_heading("Contents", level=1)
    for entry in (
        "1. Executive Summary",
        "2. Status Distribution and Trend",
        "3. Suites/Packages Overview",
        "4. Failures",
        "5. Per-test Detail",
    ):
        document.add_paragraph(entry)
    if report.tests:
        document.add_paragraph("Per-test index:")
        for index, test in enumerate(report.tests, start=1):
            document.add_paragraph(f"{index}. {test.name}")


def _apply_branding(document: Document, report: ReportData) -> None:
    footer_text = report.metadata.footer_text.strip()
    if not footer_text:
        return
    for section in document.sections:
        footer = section.footer
        paragraph = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
        paragraph.text = footer_text


def _add_executive_summary(document: Document, report: ReportData) -> None:
    document.add_heading("Executive Summary", level=1)
    document.add_paragraph(f"Total Duration: {format_duration(report.duration_ms)}")
    document.add_paragraph(f"Pass Rate: {report.pass_rate:.2f}%")

    summary_table = document.add_table(rows=1, cols=7)
    summary_table.style = "Table Grid"
    headers = ["Total", "Passed", "Failed", "Broken", "Skipped", "Unknown", "Pass Rate"]
    for index, label in enumerate(headers):
        summary_table.rows[0].cells[index].text = label

    row = summary_table.add_row().cells
    row[0].text = str(report.summary.total)
    row[1].text = str(report.summary.passed)
    row[2].text = str(report.summary.failed)
    row[3].text = str(report.summary.broken)
    row[4].text = str(report.summary.skipped)
    row[5].text = str(report.summary.unknown)
    row[6].text = f"{report.pass_rate:.2f}%"

    document.add_heading("Trend", level=2)
    if report.trend:
        trend_table = document.add_table(rows=1, cols=7)
        trend_table.style = "Table Grid"
        trend_headers = ["Run", "Total", "Passed", "Failed", "Broken", "Skipped", "Unknown"]
        for index, label in enumerate(trend_headers):
            trend_table.rows[0].cells[index].text = label
        for point in report.trend:
            trow = trend_table.add_row().cells
            trow[0].text = point.label
            trow[1].text = str(point.counts.total)
            trow[2].text = str(point.counts.passed)
            trow[3].text = str(point.counts.failed)
            trow[4].text = str(point.counts.broken)
            trow[5].text = str(point.counts.skipped)
            trow[6].text = str(point.counts.unknown)
    else:
        document.add_paragraph("Not available")


def _add_suites_overview(document: Document, report: ReportData) -> None:
    document.add_heading("Suites/Packages Overview", level=1)
    if not report.suites:
        document.add_paragraph("Not available")
        return
    table = document.add_table(rows=1, cols=7)
    table.style = "Table Grid"
    headers = ["Suite/Package", "Total", "Passed", "Failed", "Broken", "Skipped", "Unknown"]
    for index, header in enumerate(headers):
        table.rows[0].cells[index].text = header

    for suite in report.suites:
        row = table.add_row().cells
        row[0].text = suite.name
        row[1].text = str(suite.counts.total)
        row[2].text = str(suite.counts.passed)
        row[3].text = str(suite.counts.failed)
        row[4].text = str(suite.counts.broken)
        row[5].text = str(suite.counts.skipped)
        row[6].text = str(suite.counts.unknown)


def _add_failures(document: Document, report: ReportData) -> None:
    document.add_heading("Failures", level=1)
    if not report.failures:
        document.add_paragraph("No failed or broken tests.")
        return

    for failure in report.failures:
        document.add_heading(failure.name, level=2)
        document.add_paragraph(f"Status: {failure.status.upper()}")
        document.add_paragraph(f"UID: {failure.uid or 'Not available'}")
        if failure.message_excerpt:
            document.add_paragraph(f"Message: {failure.message_excerpt}")
        else:
            document.add_paragraph("Message: Not available")


def _add_test_details(document: Document, report: ReportData, include_attachments: bool) -> None:
    document.add_heading("Per-test Detail", level=1)
    if not report.tests:
        document.add_paragraph("Not available")
        return
    if report.tests_truncated:
        document.add_paragraph(
            "Per-test detail was truncated by --max-tests. Increase it to include more tests."
        )

    for index, test in enumerate(report.tests, start=1):
        document.add_heading(f"{index}. {test.name}", level=2)
        document.add_paragraph(f"Status: {test.status.upper()}")
        document.add_paragraph(f"Duration: {format_duration(test.duration_ms)}")
        document.add_paragraph(f"UID: {test.uid or 'Not available'}")
        if test.suites:
            document.add_paragraph(f"Suites: {', '.join(test.suites)}")
        else:
            document.add_paragraph("Suites: Not available")

        if test.parameters:
            document.add_paragraph("Parameters:")
            parameter_table = document.add_table(rows=1, cols=2)
            parameter_table.style = "Table Grid"
            parameter_table.rows[0].cells[0].text = "Name"
            parameter_table.rows[0].cells[1].text = "Value"
            for parameter in test.parameters:
                prow = parameter_table.add_row().cells
                prow[0].text = parameter.name
                prow[1].text = parameter.value
        else:
            document.add_paragraph("Parameters: none")

        document.add_paragraph("Execution:")
        if test.setup_steps:
            document.add_paragraph("Set up:")
            for line in test.setup_steps:
                document.add_paragraph(line, style="List Bullet")
        else:
            document.add_paragraph("Set up: Not available")

        if test.execution_steps:
            document.add_paragraph("Test body:")
            for line in test.execution_steps:
                document.add_paragraph(line, style="List Bullet")
        else:
            document.add_paragraph("Test body: Not available")

        if test.teardown_steps:
            document.add_paragraph("Tear down:")
            for line in test.teardown_steps:
                document.add_paragraph(line, style="List Bullet")
        else:
            document.add_paragraph("Tear down: Not available")

        if test.message:
            document.add_paragraph(f"Message: {test.message}")
        if test.trace:
            document.add_paragraph(f"Trace excerpt: {test.trace[:600]}")

        if not include_attachments:
            continue

        if not test.attachments:
            document.add_paragraph("Attachments: none")
            continue

        document.add_paragraph("Attachments:")
        table = document.add_table(rows=1, cols=4)
        table.style = "Table Grid"
        table.rows[0].cells[0].text = "Name"
        table.rows[0].cells[1].text = "Type"
        table.rows[0].cells[2].text = "Exists"
        table.rows[0].cells[3].text = "Path"
        inline_image_count = 0
        for attachment in test.attachments:
            row = table.add_row().cells
            row[0].text = attachment.name
            row[1].text = attachment.mime_type
            row[2].text = "Yes" if attachment.exists else "No"
            row[3].text = str(attachment.path) if attachment.path else attachment.source

            if (
                attachment.inline_image
                and attachment.exists
                and attachment.path is not None
                and inline_image_count < 3
            ):
                try:
                    document.add_paragraph(f"Inline image: {attachment.name}")
                    document.add_picture(str(attachment.path), width=Inches(5.8))
                    inline_image_count += 1
                except Exception:
                    document.add_paragraph(
                        f"Inline image rendering skipped for attachment: {attachment.name}"
                    )
