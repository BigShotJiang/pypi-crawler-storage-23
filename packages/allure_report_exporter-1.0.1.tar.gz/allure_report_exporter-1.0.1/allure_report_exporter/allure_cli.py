from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path
from typing import Sequence

MIN_ALLURE_VERSION = (2, 37, 0)
VERSION_PATTERN = re.compile(r"(\d+)\.(\d+)\.(\d+)")
STRICT_LINE_VERSION_PATTERN = re.compile(r"^\s*(\d+)\.(\d+)\.(\d+)\s*$")


class AllureCliError(RuntimeError):
    """Raised for Allure CLI setup or execution problems."""


def discover_allure_binary(explicit_path: str | None = None) -> str:
    if explicit_path:
        candidate = Path(explicit_path).expanduser()
        if candidate.exists():
            return str(candidate)
        raise AllureCliError(
            f"Allure binary was not found at '{explicit_path}'. "
            "Pass a valid path via --allure-binary or install Allure in PATH."
        )

    for name in ("allure", "allure.bat", "allure.cmd"):
        resolved = shutil.which(name)
        if resolved:
            return resolved

    raise AllureCliError(
        "Allure CLI was not found in PATH. Install Allure Commandline 2.37.0+ "
        "and retry, or pass --allure-binary <path>."
    )


def parse_version(version_text: str) -> tuple[int, int, int] | None:
    strict_matches = []
    for line in version_text.splitlines():
        line_match = STRICT_LINE_VERSION_PATTERN.match(line)
        if line_match:
            strict_matches.append(tuple(int(part) for part in line_match.groups()))
    if strict_matches:
        return strict_matches[-1]

    all_matches = VERSION_PATTERN.findall(version_text)
    if not all_matches:
        return None
    major, minor, patch = all_matches[-1]
    return int(major), int(minor), int(patch)


def _run_command(command: Sequence[str]) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            list(command),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
        )
    except FileNotFoundError as exc:
        raise AllureCliError(
            f"Unable to run command: {' '.join(command)}. "
            "The binary may be missing or not executable."
        ) from exc


def get_allure_version(allure_binary: str) -> tuple[int, int, int]:
    result = _run_command([allure_binary, "--version"])
    output = (result.stdout or "") + "\n" + (result.stderr or "")
    version = parse_version(output)
    if result.returncode != 0:
        raise AllureCliError(
            "Failed to query Allure version with '--version'. "
            f"Exit code: {result.returncode}\nOutput:\n{output.strip()}"
        )
    if version is None:
        raise AllureCliError(
            "Could not parse Allure version output. "
            "Expected semantic version like '2.37.0'. "
            f"Output: {output.strip()}"
        )
    return version


def is_compatible_version(
    actual: tuple[int, int, int],
    minimum: tuple[int, int, int] = MIN_ALLURE_VERSION,
) -> bool:
    return actual >= minimum


def ensure_allure_compatible(allure_binary: str) -> tuple[int, int, int]:
    version = get_allure_version(allure_binary)
    if not is_compatible_version(version):
        raise AllureCliError(
            f"Allure version {version[0]}.{version[1]}.{version[2]} is not supported. "
            "Install Allure Commandline 2.37.0 or newer."
        )
    return version


def generate_report(
    results_dir: Path,
    out_dir: Path,
    allure_binary: str | None = None,
    single_file: bool = False,
) -> Path:
    resolved_results = results_dir.resolve()
    resolved_out = out_dir.resolve()
    if not resolved_results.exists():
        raise AllureCliError(f"Results directory does not exist: {resolved_results}")
    if not resolved_results.is_dir():
        raise AllureCliError(f"Results path is not a directory: {resolved_results}")

    binary = discover_allure_binary(allure_binary)
    ensure_allure_compatible(binary)
    resolved_out.parent.mkdir(parents=True, exist_ok=True)

    command: list[str] = [
        binary,
        "generate",
        str(resolved_results),
        "--clean",
        "-o",
        str(resolved_out),
    ]
    if single_file:
        command.append("--single-file")

    result = _run_command(command)
    if result.returncode != 0:
        combined = "\n".join(part for part in (result.stdout, result.stderr) if part)
        raise AllureCliError(
            "Allure report generation failed.\n"
            f"Command: {' '.join(command)}\n"
            f"Exit code: {result.returncode}\n"
            f"Output:\n{combined.strip()}"
        )

    summary_path = resolved_out / "widgets" / "summary.json"
    if not summary_path.exists():
        raise AllureCliError(
            f"Allure generate completed but expected widget file is missing: {summary_path}"
        )
    return resolved_out
