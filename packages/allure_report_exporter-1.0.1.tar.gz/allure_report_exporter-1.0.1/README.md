# allure-report-exporter

[![PyPI version](https://img.shields.io/pypi/v/allure-report-exporter.svg)](https://pypi.org/project/allure-report-exporter/)
[![Python versions](https://img.shields.io/pypi/pyversions/allure-report-exporter.svg)](https://pypi.org/project/allure-report-exporter/)
[![License](https://img.shields.io/pypi/l/allure-report-exporter.svg)](./LICENSE)
[![Docs](https://img.shields.io/badge/docs-github%20pages-blue)](https://rmutegeki.github.io/allure-report-exporter/)

Generate professional **PDF** and **DOCX** reports from Allure results, with full support for **Allure Commandline 2.37.0+**.

This project intentionally uses:

1. `allure generate` to build official Allure HTML.
2. `allure-report-html/widgets/*.json` + `data/*` as the parsing source.

This makes the exporter resilient to raw results schema shifts.

## Highlights

- Allure 2.37.0+ compatibility precheck
- `pdf`, `docx`, `both`, and `html` build modes
- Rich per-test detail: parameters, setup/test/teardown steps, attachments
- Clickable table of contents for quick navigation
- Branding support: custom logo and footer text
- Optional template and CSS override for fully custom report styling
- Works on Windows and Linux

## Documentation

- GitHub Pages docs: <https://rmutegeki.github.io/allure-report-exporter/>
- Includes onboarding for:
  - new users (install, quick start, CLI, troubleshooting)
  - developers (setup, architecture, testing, release workflow)

Run docs locally:

```bash
# pip
python -m pip install -e .[docs]
mkdocs serve

# uv
uv sync --extra docs
uv run mkdocs serve
```

## Installation

### Install with pip

```bash
python -m pip install allure-report-exporter
python -m playwright install chromium
```

### Install with uv

```bash
uv tool install allure-report-exporter
uvx playwright install chromium
```

For development (editable install):

```bash
# pip
python -m pip install -e .[dev]

# uv
uv sync --extra dev
```

## Allure prerequisite

Install Allure Commandline 2.37.0 or newer and verify:

```bash
allure --version
```

The CLI validates version before report generation.

## Quick start

```bash
allure-report build --results ./allure-results --out ./allure-report-out --format both
```

Outputs:

- `report.pdf`
- `report.docx`
- `report-print.html`
- `allure-report-html/` (kept by default)

## Usage examples

Build HTML only:

```bash
allure-report build --results ./allure-results --out ./allure-report-out --format html
```

Build PDF only:

```bash
allure-report build --results ./allure-results --out ./allure-report-out --format pdf
```

Build DOCX only:

```bash
allure-report build --results ./allure-results --out ./allure-report-out --format docx
```

Build both:

```bash
allure-report build --results ./allure-results --out ./allure-report-out --format both
```

Include metadata:

```bash
allure-report build \
  --results ./allure-results \
  --out ./allure-report-out \
  --format both \
  --title "Nightly QA Report" \
  --project "Turnlamp" \
  --build-url "https://ci.example/build/124" \
  --commit "abc1234" \
  --branch "main" \
  --environment OS:Windows \
  --environment Browser:Chromium
```

## Branding and template customization

### Add a logo and footer text

```bash
allure-report build \
  --results ./allure-results \
  --out ./allure-report-out \
  --format both \
  --logo-path ./branding/company-logo.png \
  --footer-text "Copyright dSPACE 2026"
```

### Use your own template and CSS

```bash
allure-report build \
  --results ./allure-results \
  --out ./allure-report-out \
  --format pdf \
  --template-file ./custom/report_template.html.j2 \
  --css-file ./custom/report.css
```

Start from the defaults:

- [`allure_report_exporter/assets/report_template.html.j2`](./allure_report_exporter/assets/report_template.html.j2)
- [`allure_report_exporter/assets/report.css`](./allure_report_exporter/assets/report.css)

## Viewing official Allure HTML

Do not open `allure-report-html/index.html` directly with `file://`.
Use:

```bash
allure open ./allure-report-out/allure-report-html
```

or:

```bash
cd ./allure-report-out/allure-report-html
python -m http.server 8080
```

Then open `http://localhost:8080`.

## Testing

```bash
pytest -q
```

## Publish to PyPI

Full release instructions are in [`PUBLISHING.md`](./PUBLISHING.md).

## Project structure

```text
allure-report/
  pyproject.toml
  README.md
  PUBLISHING.md
  CHANGELOG.md
  LICENSE
  allure_report_exporter/
  tests/
```

