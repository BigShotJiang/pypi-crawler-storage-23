from __future__ import annotations

from pathlib import Path

from allure_report_exporter.model import ReportMetadata
from allure_report_exporter.parse_widgets import parse_report_widgets
from allure_report_exporter.render_html import render_report_html


def test_render_html_has_toc_and_no_widgets_card(
    tmp_path: Path,
    fixture_report_dir: Path,
) -> None:
    report = parse_report_widgets(
        html_report_dir=fixture_report_dir,
        metadata=ReportMetadata(title="Render Check"),
        include_attachments=True,
        max_tests=20,
    )
    output = tmp_path / "report-print.html"
    render_report_html(report=report, output_html_path=output, include_attachments=True)
    html = output.read_text(encoding="utf-8")

    assert "Table of Contents" in html
    assert "<a href=\"#test-" in html
    assert "Parameters" in html
    assert ">Widgets<" not in html

    failures_block = html.split("<h2>Failures</h2>", 1)[1].split("<h2>Per-test Detail</h2>", 1)[0]
    assert "Trace excerpt" not in failures_block
    assert "Open this test in Per-test Detail" in failures_block


def test_render_html_supports_logo_footer_and_custom_template(
    tmp_path: Path,
    fixture_report_dir: Path,
) -> None:
    logo = fixture_report_dir / "data" / "attachments" / "sample-image.png"
    custom_template = tmp_path / "custom_template.j2"
    custom_css = tmp_path / "custom.css"
    custom_template.write_text(
        (
            "<html><head><style>{{ css }}</style></head><body>"
            "<h1>{{ report.metadata.title }}</h1>"
            "<p id='logo'>{{ logo_uri }}</p>"
            "<p id='footer'>{{ footer_text }}</p>"
            "</body></html>"
        ),
        encoding="utf-8",
    )
    custom_css.write_text("body { color: #123456; }", encoding="utf-8")

    report = parse_report_widgets(
        html_report_dir=fixture_report_dir,
        metadata=ReportMetadata(
            title="Branded Render",
            logo_path=str(logo),
            footer_text="Copyright dSPACE 2026",
        ),
        include_attachments=True,
        max_tests=20,
    )
    output = tmp_path / "custom-report.html"
    render_report_html(
        report=report,
        output_html_path=output,
        include_attachments=True,
        template_path=custom_template,
        css_path=custom_css,
    )
    html = output.read_text(encoding="utf-8")

    assert "Branded Render" in html
    assert "file:///" in html
    assert "Copyright dSPACE 2026" in html
    assert "#123456" in html
