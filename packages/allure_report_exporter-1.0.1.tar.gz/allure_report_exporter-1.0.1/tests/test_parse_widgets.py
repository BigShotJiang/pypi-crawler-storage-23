from __future__ import annotations

import json
from pathlib import Path

from allure_report_exporter.model import ReportMetadata
from allure_report_exporter.parse_widgets import parse_report_widgets


def test_parse_summary_from_fixture(fixture_report_dir: Path) -> None:
    report = parse_report_widgets(
        html_report_dir=fixture_report_dir,
        metadata=ReportMetadata(title="Fixture Report"),
        include_attachments=True,
        max_tests=100,
    )
    summary = report.summary
    assert summary.total >= 0
    assert summary.passed >= 0
    assert summary.failed >= 0
    assert summary.broken >= 0
    assert summary.skipped >= 0
    assert summary.unknown >= 0

    raw_summary = json.loads(
        (fixture_report_dir / "widgets" / "summary.json").read_text(encoding="utf-8")
    )
    raw_stat = raw_summary.get("statistic", {})
    raw_total = int(raw_stat.get("total", 0))
    raw_parts = sum(int(raw_stat.get(key, 0)) for key in ("passed", "failed", "broken", "skipped", "unknown"))
    if raw_total == raw_parts:
        assert summary.total == summary.computed_total

    assert report.tests


