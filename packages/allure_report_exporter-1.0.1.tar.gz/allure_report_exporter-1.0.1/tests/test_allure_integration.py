from __future__ import annotations

from pathlib import Path

import pytest

from allure_report_exporter.allure_cli import generate_report
from allure_report_exporter.model import ReportMetadata
from allure_report_exporter.parse_widgets import parse_report_widgets


def test_generate_html_from_local_results(
    tmp_path: Path,
    local_results_dir: Path,
    allure_binary_or_skip: str,
) -> None:
    if not local_results_dir.exists():
        pytest.skip(f"Local results directory not found: {local_results_dir}")

    generated = generate_report(
        results_dir=local_results_dir,
        out_dir=tmp_path / "allure-report-html",
        allure_binary=allure_binary_or_skip,
        single_file=False,
    )
    assert (generated / "widgets" / "summary.json").exists()


def test_parse_generated_report_when_allure_available(
    tmp_path: Path,
    local_results_dir: Path,
    allure_binary_or_skip: str,
) -> None:
    if not local_results_dir.exists():
        pytest.skip(f"Local results directory not found: {local_results_dir}")

    generated = generate_report(
        results_dir=local_results_dir,
        out_dir=tmp_path / "allure-report-html",
        allure_binary=allure_binary_or_skip,
        single_file=False,
    )
    report = parse_report_widgets(
        html_report_dir=generated,
        metadata=ReportMetadata(title="Integration"),
        include_attachments=True,
        max_tests=80,
    )
    assert report.summary.total >= 0
    assert report.summary.computed_total >= 0
    if report.summary.total == report.summary.computed_total:
        assert report.summary.total == report.summary.computed_total


