from __future__ import annotations

from pathlib import Path

import pytest

pytest.importorskip("docx")

from allure_report_exporter.docx import build_docx
from allure_report_exporter.model import ReportMetadata
from allure_report_exporter.parse_widgets import parse_report_widgets


def test_build_docx_from_fixture(tmp_path: Path, fixture_report_dir: Path) -> None:
    report = parse_report_widgets(
        html_report_dir=fixture_report_dir,
        metadata=ReportMetadata(title="Fixture DOCX"),
        include_attachments=True,
        max_tests=20,
    )
    output = tmp_path / "report.docx"
    build_docx(report=report, output_docx_path=output, include_attachments=True)
    assert output.exists()
    assert output.stat().st_size > 0
