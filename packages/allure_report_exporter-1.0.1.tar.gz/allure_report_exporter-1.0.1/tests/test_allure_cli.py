from __future__ import annotations

from allure_report_exporter.allure_cli import parse_version


def test_parse_version_simple() -> None:
    assert parse_version("2.37.0") == (2, 37, 0)


def test_parse_version_from_noisy_windows_batch_output() -> None:
    noisy_output = """
D:\\demo\\TA_SDK_26.1-0.2.5>set JAVA_HOME=C:\\Program Files\\Java\\jdk1.8.0_202
"C:\\Program Files\\Java\\jdk1.8.0_202/bin/java.exe" io.qameta.allure.CommandLine --version
2.37.0
"""
    assert parse_version(noisy_output) == (2, 37, 0)
