from __future__ import annotations

from pathlib import Path

import pytest

from allure_report_exporter.model import ReportMetadata
from allure_report_exporter.parse_widgets import parse_report_widgets
from allure_report_exporter.pdf import build_pdf, check_playwright_ready
from allure_report_exporter.render_html import render_report_html


def test_build_pdf_from_fixture(tmp_path: Path, fixture_report_dir: Path) -> None:
    ready, reason = check_playwright_ready()
    if not ready:
        pytest.skip(reason)

    report = parse_report_widgets(
        html_report_dir=fixture_report_dir,
        metadata=ReportMetadata(title="Fixture PDF"),
        include_attachments=True,
        max_tests=20,
    )
    html_path = tmp_path / "report-print.html"
    render_report_html(report=report, output_html_path=html_path, include_attachments=True)
    output_pdf = tmp_path / "report.pdf"
    build_pdf(report_html_path=html_path, output_pdf_path=output_pdf)

    assert output_pdf.exists()
    assert output_pdf.stat().st_size > 0


