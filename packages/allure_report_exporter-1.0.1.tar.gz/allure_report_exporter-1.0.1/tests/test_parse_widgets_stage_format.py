from __future__ import annotations

import json
from pathlib import Path

from allure_report_exporter.model import ReportMetadata
from allure_report_exporter.parse_widgets import parse_report_widgets


def test_extracts_stage_steps_attachments_and_status_fields(tmp_path: Path) -> None:
    report_dir = tmp_path / "generated-report"
    widgets_dir = report_dir / "widgets"
    test_cases_dir = report_dir / "data" / "test-cases"
    attachments_dir = report_dir / "data" / "attachments"
    widgets_dir.mkdir(parents=True)
    test_cases_dir.mkdir(parents=True)
    attachments_dir.mkdir(parents=True)

    (widgets_dir / "summary.json").write_text(
        json.dumps(
            {
                "statistic": {
                    "passed": 0,
                    "failed": 1,
                    "broken": 0,
                    "skipped": 0,
                    "unknown": 0,
                    "total": 1,
                },
                "time": {"duration": 1234},
            }
        ),
        encoding="utf-8",
    )
    (widgets_dir / "suites.json").write_text(
        json.dumps({"children": [{"name": "suite-a", "statistic": {"failed": 1, "total": 1}}]}),
        encoding="utf-8",
    )

    source_name = "evidence.txt"
    (attachments_dir / source_name).write_text("hello", encoding="utf-8")
    (test_cases_dir / "case.json").write_text(
        json.dumps(
            {
                "uid": "case-1",
                "name": "stage-format-case",
                "fullName": "suite.case",
                "status": "failed",
                "statusMessage": "top-level message",
                "statusTrace": "top-level trace",
                "labels": [{"name": "suite", "value": "suite-a"}],
                "parameters": [{"name": "battery_voltage", "value": "12"}],
                "time": {"duration": 1234},
                "beforeStages": [
                    {
                        "steps": [
                            {
                                "name": "Setup Ports",
                                "status": "passed",
                            }
                        ]
                    }
                ],
                "testStage": {
                    "steps": [
                        {
                            "name": "Main step",
                            "status": "failed",
                            "attachments": [
                                {
                                    "name": "Evidence",
                                    "source": source_name,
                                    "type": "text/plain",
                                }
                            ],
                        }
                    ]
                },
                "afterStages": [
                    {
                        "steps": [
                            {
                                "name": "Teardown Ports",
                                "status": "passed",
                            }
                        ]
                    }
                ],
            }
        ),
        encoding="utf-8",
    )

    report = parse_report_widgets(
        html_report_dir=report_dir,
        metadata=ReportMetadata(title="Stage Schema"),
        include_attachments=True,
        max_tests=10,
    )

    assert report.tests
    test = report.tests[0]
    assert test.message == "top-level message"
    assert "top-level trace" in test.trace
    assert test.parameters
    assert test.parameters[0].name == "battery_voltage"
    assert test.parameters[0].value == "12"
    assert test.setup_steps and any("Setup Ports" in step for step in test.setup_steps)
    assert test.execution_steps and any("Main step" in step for step in test.execution_steps)
    assert test.teardown_steps and any("Teardown Ports" in step for step in test.teardown_steps)
    assert test.attachments
    assert test.attachments[0].source == source_name
    assert test.attachments[0].exists
