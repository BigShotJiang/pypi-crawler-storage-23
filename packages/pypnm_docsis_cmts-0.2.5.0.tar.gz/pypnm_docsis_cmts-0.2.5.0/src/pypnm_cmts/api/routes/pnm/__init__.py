# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Maurice Garcia

"""PNM orchestration API routes."""

from pypnm_cmts.api.routes.pnm.router import router

__all__ = [
    "router",
]
