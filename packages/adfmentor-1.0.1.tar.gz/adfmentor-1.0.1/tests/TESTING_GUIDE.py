"""Guide for creating test homework scenarios."""

# =============================================================================
# SCENARIO 1: Basic Copy Activity (Easy - 70-80 expected score)
# =============================================================================
"""
Homework: Create a simple copy activity from Blob to SQL Database

Expected submission files:
- pipeline.json (1 Copy activity)
- dataset_input.json (Blob CSV)
- dataset_output.json (SQL Table)
- linkedservice_blob.json
- linkedservice_sql.json

Missing elements (lower score):
- No error handling
- No parameterization
- Hardcoded values
"""

# =============================================================================
# SCENARIO 2: Data Transformation Pipeline (Medium - 80-90 expected)
# =============================================================================
"""
Homework: Create pipeline that:
1. Reads JSON from REST API
2. Transforms data with Mapping Data Flow
3. Writes to Azure SQL

Expected submission files:
- pipeline.json (Copy + Data Flow)
- dataflow.json (transformation logic)
- dataset_rest.json
- dataset_sql.json
- linkedservice_rest.json
- linkedservice_sql.json
- answers.txt (explanation)

Good elements (higher score):
- Data Flow transformations
- Multiple activities
- Written explanations
"""

# =============================================================================
# SCENARIO 3: Advanced ETL with Error Handling (Hard - 90-100 expected)
# =============================================================================
"""
Homework: Create production-ready pipeline:
1. ForEach loop processing multiple files
2. Error handling with web activity notifications
3. Parameterized for different environments
4. Retry logic configured

Expected submission files:
- pipeline.json (complex with ForEach, error paths)
- dataset_input.json
- dataset_output.json
- linkedservice_blob.json
- linkedservice_sql.json
- linkedservice_webhook.json (for notifications)
- answers.txt (detailed explanations)

Excellent elements (high score):
- Retry policies
- Error notifications
- Parameters
- Multiple environments support
"""

# =============================================================================
# SCENARIO 4: Text-Only Conceptual Questions (Variable score)
# =============================================================================
"""
Homework: Answer these questions in answers.txt:
1. Explain the difference between Copy Activity and Data Flow
2. When would you use incremental loading vs full load?
3. How do you secure credentials in ADF?
4. Describe a real-world ETL scenario you would implement

Expected submission:
- answers.txt only

Grading based on:
- Understanding of concepts
- Practical examples
- Depth of explanation
"""

# =============================================================================
# HOW TO CREATE TEST SUBMISSIONS
# =============================================================================

def create_basic_submission():
    """
    Create a basic (low quality) submission for testing.
    
    Structure:
    test-submissions/
    └── basic-homework/
        ├── pipeline.json (simple copy, no parameters)
        ├── dataset_input.json
        └── dataset_output.json
    
    Expected score: 60-75
    Missing: error handling, parameterization, best practices
    """
    pass


def create_medium_submission():
    """
    Create a medium quality submission.
    
    Structure:
    test-submissions/
    └── medium-homework/
        ├── pipeline.json (copy + transformation, some parameters)
        ├── dataset_input.json
        ├── dataset_output.json
        ├── linkedservice_blob.json
        └── linkedservice_sql.json
    
    Expected score: 75-85
    Has: basic structure, some parameterization
    Missing: comprehensive error handling, security
    """
    pass


def create_excellent_submission():
    """
    Create an excellent quality submission (like lesson-3).
    
    Structure:
    test-submissions/
    └── excellent-homework/
        ├── pipeline.json (ForEach, retry, notifications)
        ├── dataset_input.json
        ├── dataset_output.json
        ├── linkedservice_blob.json
        ├── linkedservice_sql.json
        └── answers.txt (detailed explanations)
    
    Expected score: 85-95
    Has: everything well-implemented
    Room for improvement: minor optimizations
    """
    pass
