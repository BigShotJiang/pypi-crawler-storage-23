"""Simple diagnostic test to verify API is working."""

import os
from dotenv import load_dotenv
from ADFMentor import ADFMentor

load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")
print(f"API Key loaded: {api_key[:15]}..." if api_key else "ERROR: No API key!")

print("\nTesting single evaluation...")
mentor = ADFMentor(api_key=api_key)

try:
    result = mentor.evaluate_adf("lesson-3.zip")
    
    print(f"\n✅ Evaluation successful!")
    print(f"Score: {result.get('score')}/100")
    print(f"Feedback: {result.get('feedback')[:150]}...")
    
except Exception as e:
    print(f"\n❌ Error: {str(e)}")
