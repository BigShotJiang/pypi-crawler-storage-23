"""Quick test using folder directly instead of ZIP."""

import os
from dotenv import load_dotenv
from ADFMentor import ADFMentor

load_dotenv()

print("Testing with lesson-3/lesson-3 folder directly...")
print("="*70)

mentor = ADFMentor(api_key=os.getenv("GEMINI_API_KEY"))

# Test 1: Using folder directly
print("\nTest 1: Folder submission")
result = mentor.evaluate_adf("lesson-3/lesson-3/")
print(f"Score: {result.get('score')}/100")
print(f"Feedback: {result.get('feedback')[:200]}...")

# Test 2: Using a single JSON
print("\n" + "="*70)
print("Test 2: Single JSON file")
result = mentor.evaluate_adf("lesson-3/lesson-3/pipeline.json")
print(f"Score: {result.get('score')}/100")
print(f"Feedback: {result.get('feedback')[:200]}...")

# Test 3: Using text answer
print("\n" + "="*70)
print("Test 3: Text answer only")
text_prompt = """
Evaluate this student's written ADF answers.
Grade on technical accuracy, clarity, and practical understanding.
Return score 0-100 and concise feedback (50-100 words).
"""
result = mentor.evaluate_adf(
    "lesson-3/lesson-3/answers.txt",
    question="Explain Linked Services in ADF and error handling.",
    prompt=text_prompt
)
print(f"Score: {result.get('score')}/100")
print(f"Feedback: {result.get('feedback')[:200]}...")

print("\n" + "="*70)
print("✅ All tests with folder structure completed!")
