"""Real-world scenario tests for ADFMentor with lesson-3 example."""

import os
from dotenv import load_dotenv
from ADFMentor import ADFMentor

load_dotenv()

def test_lesson3_zip():
    """Test ZIP submission (lesson-3.zip)."""
    print("\n" + "="*70)
    print("TEST 1: ZIP File Submission")
    print("="*70)
    
    mentor = ADFMentor(api_key=os.getenv("GEMINI_API_KEY"))
    result = mentor.evaluate_adf("lesson-3.zip")
    
    print(f"Score: {result['score']}/100")
    print(f"\nFeedback:\n{result['feedback']}")
    print("="*70)


def test_lesson3_folder():
    """Test folder submission (lesson-3/)."""
    print("\n" + "="*70)
    print("TEST 2: Folder Submission")
    print("="*70)
    
    mentor = ADFMentor(api_key=os.getenv("GEMINI_API_KEY"))
    result = mentor.evaluate_adf("lesson-3/lesson-3/")
    
    print(f"Score: {result['score']}/100")
    print(f"\nFeedback:\n{result['feedback']}")
    print("="*70)


def test_single_json():
    """Test single JSON file submission."""
    print("\n" + "="*70)
    print("TEST 3: Single JSON File")
    print("="*70)
    
    mentor = ADFMentor(api_key=os.getenv("GEMINI_API_KEY"))
    result = mentor.evaluate_adf("lesson-3/lesson-3/pipeline.json")
    
    print(f"Score: {result['score']}/100")
    print(f"\nFeedback:\n{result['feedback']}")
    print("="*70)


def test_text_answer():
    """Test text-only answer submission."""
    print("\n" + "="*70)
    print("TEST 4: Text Answer Only")
    print("="*70)
    
    mentor = ADFMentor(api_key=os.getenv("GEMINI_API_KEY"))
    result = mentor.evaluate_adf(
        "lesson-3/lesson-3/answers.txt",
        question="Explain what Linked Services are in ADF and how to handle pipeline errors."
    )
    
    print(f"Score: {result['score']}/100")
    print(f"\nFeedback:\n{result['feedback']}")
    print("="*70)


def test_with_custom_rubric():
    """Test with custom grading criteria."""
    print("\n" + "="*70)
    print("TEST 5: Custom Rubric (Focus on Error Handling)")
    print("="*70)
    
    custom_rubric = """
Grade this ADF pipeline ONLY on error handling and resilience:

1. Error Handling Activities (40 points)
   - Try-catch patterns or failure paths?
   - Retry logic configured?
   
2. Timeout Configuration (30 points)
   - Appropriate timeout values?
   - Activity-level timeouts set?
   
3. Monitoring & Logging (30 points)
   - Error notifications?
   - Logging mechanisms?

Return score 0-100 and brief feedback (30-50 words).
"""
    
    mentor = ADFMentor(api_key=os.getenv("GEMINI_API_KEY"))
    result = mentor.evaluate_adf("lesson-3.zip", prompt=custom_rubric)
    
    print(f"Score: {result['score']}/100")
    print(f"\nFeedback:\n{result['feedback']}")
    print("="*70)


if __name__ == "__main__":
    print("\n" + "="*70)
    print("REAL-WORLD ADFMentor TESTING")
    print("Using lesson-3 homework submission")
    print("="*70)
    
    # Run all tests
    test_lesson3_zip()
    test_lesson3_folder()
    test_single_json()
    test_text_answer()
    test_with_custom_rubric()
    
    print("\n✅ All tests completed!")
