"""Test with text answer + custom prompt (bypasses JSON validation)."""

import os
from dotenv import load_dotenv
from ADFMentor import ADFMentor

load_dotenv()

print("Testing text-based evaluation...")
print("="*70)

mentor = ADFMentor(api_key=os.getenv("GEMINI_API_KEY"))

# Read the answers file
with open("lesson-3/lesson-3/answers.txt", "r", encoding="utf-8") as f:
    answers_content = f.read()

# Create a custom prompt
custom_prompt = """
Evaluate this ADF student's written answers about Azure Data Factory concepts.

Grade on:
1. Understanding of Linked Services (30 points)
2. Problem-solving for pipeline errors (30 points)  
3. Explanation clarity (20 points)
4. Technical accuracy (20 points)

Return JSON with score (0-100) and brief feedback (50-100 words).
"""

result = mentor.evaluate_adf(
    "lesson-3/lesson-3/answers.txt",
    question=custom_prompt,
    prompt=custom_prompt
)

print(f"✅ Evaluation Complete!")
print(f"Score: {result.get('score')}/100")
print(f"\nFeedback:")
print(result.get('feedback'))
