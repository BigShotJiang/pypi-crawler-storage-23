import sys, os, io
from dotenv import load_dotenv

load_dotenv()

if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

sys.path.insert(0, '.')
from ADFMentor import ADFMentor

homework = """
ADF Lesson 10 - ETL Pipeline

Build a pipeline copying SQL Server → Blob Storage
- Copy Activity + linked services + datasets
- Error handling (bonus)
- Explain linked services, Copy vs Data Flow, 3 best practices
"""

print("ADF Homework Grading\n" + homework + "\n")

api_key = os.getenv('GEMINI_API_KEY')
mentor = ADFMentor(api_key=api_key, model_name="gemini-2.5-flash-lite")

print("[Student 1] simple_pipeline.json")
s1 = mentor.evaluate_adf("tests/files/simple_pipeline.json", question=homework)
print(f"Score: {s1['score']}/100\n{s1['feedback']}\n")

print("[Student 2] complex_adf_project.zip")
s2 = mentor.evaluate_adf("tests/files/complex_adf_project.zip", question=homework)
print(f"Score: {s2['score']}/100\n{s2['feedback']}")
if 'metadata_report' in s2:
    print(f"Components:\n{s2['metadata_report']}\n")

print("[Student 3] invalid_adf.zip")
s3 = mentor.evaluate_adf("tests/files/invalid_adf.zip", question=homework)
print(f"Score: {s3['score']}/100\n{s3['feedback']}\n")

print("[Student 4] complex_adf_project/ (folder)")
s4 = mentor.evaluate_adf("tests/files/complex_adf_project", question=homework)
print(f"Score: {s4['score']}/100\n{s4['feedback']}\n")

print("="*60)
results = [
    ("Student 1", s1['score']),
    ("Student 2", s2['score']),
    ("Student 3", s3['score']),
    ("Student 4", s4['score']),
]
for name, score in results:
    grade = 'A' if score >= 90 else 'B' if score >= 80 else 'C' if score >= 70 else 'D' if score >= 60 else 'F'
    print(f"{name}: {score}/100 ({grade})")
