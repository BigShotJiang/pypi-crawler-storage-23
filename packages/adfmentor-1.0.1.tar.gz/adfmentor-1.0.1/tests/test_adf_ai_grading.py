import sys, os
from dotenv import load_dotenv

sys.path.insert(0, '.')
load_dotenv()

from ADFMentor import ADFMentor

homework = """
Azure Data Factory - Lesson 10: ETL Pipeline

Build an ADF solution:
1. Copy data from SQL Server to Blob Storage
2. Transform with proper activities
3. Add error handling
4. Use parameters
5. Follow naming conventions
"""

prompts = {
    "pipeline": """Evaluate pipeline logic: correctness (40 pts), activity selection (30 pts), performance (20 pts), completeness (10 pts). Feedback 50-80 words.""",
    "architecture": """Evaluate design: architecture (40 pts), error handling (30 pts), security (20 pts), best practices (10 pts). Feedback 50-80 words.""",
    "configuration": """Evaluate config: connectivity (40 pts), schema (35 pts), reusability (15 pts), practices (10 pts). Feedback 50-80 words."""
}

api_key = os.getenv('GEMINI_API_KEY')
mentor = ADFMentor(api_key=api_key, model_name="gemini-2.5-flash-lite")

print("ADF AI Grading - Multi-Prompt Test\n")
print(homework + "\n")

# Test 1: Pipeline evaluation
print("\n[TEST 1] Pipeline Logic")
r1 = mentor.evaluate_adf("tests/files/simple_pipeline.json", prompts["pipeline"], homework)
print(f"Score: {r1['score']}/100\n{r1['feedback']}")

# Test 2: Architecture evaluation
print("\n[TEST 2] Architecture Design")
r2 = mentor.evaluate_adf("tests/files/complex_adf_project.zip", prompts["architecture"], homework)
print(f"Score: {r2['score']}/100\n{r2['feedback']}")

# Test 3: Configuration evaluation
print("\n[TEST 3] Configuration Setup")
r3 = mentor.evaluate_adf("tests/files/complex_adf_project", prompts["configuration"], homework)
print(f"Score: {r3['score']}/100\n{r3['feedback']}")

# Test 4: Default (no custom prompt)
print("\n[TEST 4] Default Comprehensive")
r4 = mentor.evaluate_adf("tests/files/complex_adf_project.zip", question=homework)
print(f"Score: {r4['score']}/100\n{r4['feedback']}")

print("\n" + "="*60)
results = {
    "Pipeline": r1['score'],
    "Architecture": r2['score'],
    "Configuration": r3['score'],
    "Default": r4['score'],
}
for eval_type, score in results.items():
    print(f"{eval_type}: {score}/100")
