import sys, os
from dotenv import load_dotenv

load_dotenv()
sys.path.insert(0, '.')

from ADFMentor import ADFMentor

api_key = os.getenv('GEMINI_API_KEY')
mentor = ADFMentor(api_key=api_key, model_name="gemini-2.5-flash-lite")

print("[1] ARM template")
r1 = mentor.evaluate_adf("qa_tests/fixtures/adf_samples/arm_template.json")
print(f"{r1['score']}/100\n{r1['feedback']}\n")

print("[2] Pipeline JSON")
r2 = mentor.evaluate_adf("qa_tests/fixtures/adf_samples/pipeline.json")
print(f"{r2['score']}/100\n{r2['feedback']}\n")

print("[3] Simple pipeline")
r3 = mentor.evaluate_adf("tests/files/simple_pipeline.json")
print(f"{r3['score']}/100\n{r3['feedback'][:200]}...\n")

print("[4] Complex project ZIP")
r4 = mentor.evaluate_adf("tests/files/complex_adf_project.zip")
print(f"{r4['score']}/100\n{r4['feedback'][:200]}...")
if 'metadata_report' in r4:
    print(f"\n{r4['metadata_report'][:400]}...\n")

print("[5] Invalid ZIP (has .py files)")
r5 = mentor.evaluate_adf("tests/files/invalid_with_python.zip")
print(f"{r5['score']}/100\n{r5['feedback']}\n")

print("[6] Error: unsupported file")
r6 = mentor.evaluate_adf("tests/test.py")
print(f"{r6['score']}/100\n{r6['feedback'][:100]}...\n")

print("[7] Error: missing file")
r7 = mentor.evaluate_adf("/nonexistent/path.json")
print(f"{r7['score']}/100\n{r7['feedback'][:100]}...\n")

print("="*50)
print(f"ARM: {r1['score']}/100")
print(f"Pipeline: {r2['score']}/100")
print(f"Simple: {r3['score']}/100")
print(f"Complex: {r4['score']}/100")
print(f"Invalid: {r5['score']}/100")
