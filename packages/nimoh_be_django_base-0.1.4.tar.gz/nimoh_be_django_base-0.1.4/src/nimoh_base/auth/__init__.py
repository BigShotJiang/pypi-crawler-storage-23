# Models must NOT be imported here — doing so triggers AppRegistryNotReady
# before Django's app registry is fully populated.
# Import directly from the module path:
#
#   from nimoh_base.auth.models import AbstractNimohUser
