"""Monitoring app configuration."""

from django.apps import AppConfig


class MonitoringConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "nimoh_base.monitoring"
    label = "nimoh_monitoring"
    verbose_name = "Nimoh Base: Monitoring"
