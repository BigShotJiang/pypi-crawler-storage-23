"""
nimoh_base.cli.generators
==========================
Jinja2-driven project file generator.

``render_project(cfg, output_dir)`` writes a full Django project tree to disk by
rendering every ``*.j2`` template found under ``nimoh_base/project_template/``.
"""

from __future__ import annotations

import os
import stat
from pathlib import Path

# Location of the template tree relative to this file:
#   src/nimoh_base/cli/generators.py
#   src/nimoh_base/project_template/**/*.j2
_TEMPLATE_ROOT = Path(__file__).parent.parent / "project_template"


def _get_jinja_env():
    """Return a configured Jinja2 Environment scoped to the template root."""
    try:
        from jinja2 import Environment, FileSystemLoader, StrictUndefined
    except ImportError as exc:
        raise ImportError("Jinja2 is required for project generation: pip install 'nimoh-be-django-base[cli]'") from exc

    return Environment(
        loader=FileSystemLoader(str(_TEMPLATE_ROOT)),
        undefined=StrictUndefined,
        keep_trailing_newline=True,
        autoescape=False,
    )


def _strip_j2(name: str) -> str:
    """Remove the trailing ``.j2`` extension from a template filename."""
    return name[:-3] if name.endswith(".j2") else name


def render_project(cfg, output_dir: str | os.PathLike | None = None) -> Path:
    """
    Render the full project template tree for *cfg* into *output_dir*.

    Parameters
    ----------
    cfg:
        A ``ProjectConfig`` instance from ``nimoh_base.cli.prompts``.
    output_dir:
        Parent directory inside which ``cfg.project_slug/`` is created.
        Defaults to ``cfg.output_dir``.

    Returns
    -------
    Path
        The root directory of the generated project.
    """
    from nimoh_base.cli.prompts import ProjectConfig  # local import to avoid circulars

    if not isinstance(cfg, ProjectConfig):
        raise TypeError(f"Expected ProjectConfig, got {type(cfg)}")

    output_path = Path(output_dir or cfg.output_dir).resolve()
    project_root = output_path / cfg.project_slug
    project_root.mkdir(parents=True, exist_ok=True)

    env = _get_jinja_env()
    ctx = _build_context(cfg)

    rendered: list[Path] = []

    for template_path in sorted(_TEMPLATE_ROOT.rglob("*")):
        if not template_path.is_file():
            continue

        # Template path relative to _TEMPLATE_ROOT (e.g. "config/settings/base.py.j2")
        rel = template_path.relative_to(_TEMPLATE_ROOT)

        # All path parts except possibly a leading "project_slug" placeholder dir:
        parts = list(rel.parts)

        # Resolve the "{{ project_slug }}" directory placeholder:
        # Any part literally named "project_slug" is replaced with the real slug.
        parts = [cfg.project_slug if p == "project_slug" else p for p in parts]

        # Strip .j2 from the final filename
        parts[-1] = _strip_j2(parts[-1])

        target = project_root.joinpath(*parts)
        target.parent.mkdir(parents=True, exist_ok=True)

        template = env.get_template(str(rel.as_posix()))
        content = template.render(**ctx)
        target.write_text(content, encoding="utf-8")

        # Make manage.py executable
        if target.name == "manage.py":
            target.chmod(target.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP)

        rendered.append(target)

    return project_root


def _build_context(cfg) -> dict:
    """Convert a ``ProjectConfig`` into the Jinja2 template context dict."""
    return {
        "project_name": cfg.project_name,
        "project_slug": cfg.project_slug,
        "description": cfg.description,
        "author": cfg.author,
        "author_email": cfg.author_email,
        "django_secret_key": cfg.django_secret_key,
        "site_name": cfg.site_name,
        "support_email": cfg.support_email,
        "noreply_email": cfg.noreply_email,
        "cache_key_prefix": cfg.cache_key_prefix,
        "celery_app_name": cfg.celery_app_name,
        "db_engine": cfg.db_engine,
        "db_name": cfg.db_name,
        "db_user": cfg.db_user,
        "db_password": cfg.db_password,
        "db_host": cfg.db_host,
        "db_port": cfg.db_port,
        "redis_url": cfg.redis_url,
        "frontend_url": cfg.frontend_url,
        "use_celery": cfg.use_celery,
        "use_channels": cfg.use_channels,
        "use_sendgrid": cfg.use_sendgrid,
        "use_monitoring": cfg.use_monitoring,
        "use_privacy": cfg.use_privacy,
        # Computed helpers used inside some templates
        "db_django_engine": _db_engine_string(cfg.db_engine),
        "nimoh_base_version": _package_version(),
    }


def _db_engine_string(engine: str) -> str:
    mapping = {
        "postgresql": "django.db.backends.postgresql",
        "sqlite": "django.db.backends.sqlite3",
    }
    return mapping.get(engine, "django.db.backends.postgresql")


def _package_version() -> str:
    try:
        from importlib.metadata import version

        return version("nimoh-be-django-base")
    except Exception:
        return "0.1.0"
