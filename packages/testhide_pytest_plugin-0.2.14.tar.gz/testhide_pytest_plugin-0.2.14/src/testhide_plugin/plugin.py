# -*- coding: utf-8 -*-

__author__ = 'thuesdays@gmail.com'

import os
import signal
import time
import socket
import shutil
import re
from hashlib import md5
import xml.etree.ElementTree as ET
from datetime import datetime

import pluggy
import pytest
from . import hookspecs

# This global instance holds our active plugin, but only if it's enabled.
plugin_instance = None


class FileLock:
    """
    A simple context manager for file locking. This prevents race conditions
    when multiple processes or fast-running tests try to write to the same file.
    It now includes a timeout to prevent infinite loops.
    """
    
    def __init__(self, lock_file_path, timeout=15):
        self.lock_file_path = lock_file_path
        self.timeout = timeout
        self._lock_file_handle = None
    
    def __enter__(self):
        """Acquires the lock, waiting up to the specified timeout."""
        start_time = time.time()
        while True:
            try:
                # The flags O_CREAT | O_EXCL ensure that this operation is atomic.
                self._lock_file_handle = os.open(self.lock_file_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                break  # Lock acquired
            except FileExistsError:
                if time.time() - start_time > self.timeout:
                    raise TimeoutError(
                        f"Could not acquire lock on {self.lock_file_path} within {self.timeout} seconds.")
                time.sleep(0.1)  # Wait for the other process to release the lock
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Releases the lock."""
        if self._lock_file_handle is not None:
            os.close(self._lock_file_handle)
            os.remove(self.lock_file_path)


class TesthidePlugin:
    """
    A pytest plugin that provides robust, incremental XML reporting with optional JIRA integration.
    It uses a universal temporary directory and merge strategy for all execution modes,
    ensuring full compatibility with pytest-xdist and pytest-rerunfailures.
    """
    
    def __init__(self, config):
        self.config = config
        self.session = None
        self.report_xml_path = config.option.report_xml
        self.temp_dir = os.path.join(str(config.rootdir), f".{os.path.basename(self.report_xml_path)}_temp")
        self.is_xdist_master = not hasattr(config, "workerinput")
        self.is_xdist_run = getattr(config.option, 'dist', 'no') != 'no'
        self.rerun_counters = {}
        self.test_reports = {}
        
        self.jira_enabled = all([
            config.option.jira_url,
            config.option.jira_username,
            config.option.jira_password
        ])
        self.jira = None
        self._merged = False
        
        if self.is_xdist_master:
            for sig in (signal.SIGINT, signal.SIGTERM):
                signal.signal(sig, self._signal_flush)
    
    def _init_jira_helper(self):
        """
        Initializes the JIRA connection.
        """
        if not self.jira_enabled:
            return
        
        from jira import JIRA  # Lazy import to avoid dependency if not used
        
        for _ in range(3):  # Retry connection
            try:
                self.jira = JIRA(
                    self.config.option.jira_url,
                    basic_auth=(self.config.option.jira_username, self.config.option.jira_password)
                )
                return  # Success
            except Exception as e:
                self.config.warn('JIRA_CONNECTION_ERROR', f"JIRA connection attempt failed: {e}")
                time.sleep(3)
        
        self.config.warn('JIRA_CONNECTION_FAILED', "Could not establish JIRA connection after multiple retries.")
        self.jira_enabled = False  # Disable if connection failed
    
    def _get_issue_by_test_id(self, test_id: str):
        """
        Gets a JIRA issue by a unique test failure ID.
        """
        if not self.jira:
            return None
        try:
            issues = self.jira.search_issues(f'description ~ "{test_id}" ORDER BY updated')
            return issues[0] if issues else None
        except Exception as e:
            self.config.warn('JIRA_SEARCH_ERROR', f"Failed to search JIRA for {test_id}: {e}")
            return None
    
    def _get_cleaned_traceback(self, report):
        """
        Filters the traceback to show only relevant entries by removing
        internal calls from pytest and pluggy.
        """
        if not hasattr(report.longrepr, 'reprtraceback'):
            return str(report.longrepr)
        
        final_trace_lines = []
        blacklist_keywords = ['/_pytest/', '/pluggy/']
        
        for entry in report.longrepr.reprtraceback.reprentries:
            lines_to_process = []
            if hasattr(entry, 'lines'):
                lines_to_process = entry.lines
            elif hasattr(entry, 'longrepr'):
                lines_to_process = str(entry.longrepr).split('\n')
            
            for line in lines_to_process:
                normalized_line = line.replace('\\', '/')
                is_blacklisted = any(keyword in normalized_line for keyword in blacklist_keywords)
                if not is_blacklisted:
                    final_trace_lines.append(line)
        
        summary = report.longrepr.reprcrash.message
        
        if final_trace_lines:
            if not final_trace_lines[0].strip().startswith("Traceback"):
                final_trace_lines.insert(0, "Traceback (most recent call last):")
            
            if summary not in "".join(final_trace_lines):
                final_trace_lines.append(summary)
            
            return "".join(final_trace_lines)
        else:
            return summary
    
    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_makereport(self, item, call):
        """
        This wrapper hook intercepts the report after it is created and attaches it to the 'item'
        object itself. We store per-phase reports so that pytest_runtest_logreport
        can pick the "worst" outcome after all phases (including teardown) complete.
        """
        outcome = yield
        report = outcome.get_result()
        
        if getattr(report, 'outcome', '') != 'rerun':
            # Store reports per-phase on the item
            if not hasattr(item, '_phase_reports'):
                item._phase_reports = {}
            item._phase_reports[report.when] = report
            # Keep _final_report for backward compat (best non-teardown report)
            if report.when in ('setup', 'call'):
                item._final_report = report
        
        if call.when == 'call' and call.excinfo:
            fail_message = str(call.excinfo.value)
            try:
                fail_id = '%s.%s.%s.%s' % \
                          (item.module.__name__,
                           item.cls.__name__ if item.cls
                           else item.module.__name__,
                           re.sub(r'\[.+\]$', '', item.name),
                           '%s(%s)' % (call.excinfo.typename, fail_message))
            except AttributeError:
                return
            fail_id = fail_id.encode('utf-8')
            fail_id = md5(fail_id).hexdigest()
            item.fail_id = fail_id
    
    def pytest_runtest_logreport(self, report):
        """
        Called after each phase report (setup, call, teardown) is generated.
        We write XML only after the teardown phase — at that point all three
        phase reports are available, including teardown fixture errors that
        pytest_runtest_teardown would have missed.
        """
        if report.when != 'teardown':
            return
        
        # Retrieve the item via the stored reference in the session
        item = report._item if hasattr(report, '_item') else None
        if item is None:
            # Fallback: look up item from session by nodeid
            try:
                item = self._find_item_by_nodeid(report.nodeid)
            except Exception:
                pass
        if item is None:
            return
        
        phase_reports = getattr(item, '_phase_reports', {})
        setup_report = phase_reports.get('setup')
        call_report = phase_reports.get('call')
        teardown_report = phase_reports.get('teardown')
        
        # Determine the "effective" report to use for the XML entry.
        # Priority: setup error > call failure > teardown error > call passed
        if setup_report and setup_report.failed:
            effective_report = setup_report
        elif call_report and call_report.failed:
            effective_report = call_report
        elif teardown_report and teardown_report.failed:
            effective_report = teardown_report
        elif call_report:
            effective_report = call_report
        elif setup_report:
            effective_report = setup_report
        else:
            effective_report = teardown_report
        
        if not effective_report:
            return
        
        # Calculate total duration across all phases
        total_duration = sum(
            getattr(r, 'duration', 0) for r in phase_reports.values() if r
        )
        
        filepath, line, _ = effective_report.location
        name = item.name
        classname_path = effective_report.nodeid.split('::')
        if len(classname_path) > 2:
            classname = ".".join(classname_path[:-1]).replace('/', '.')
        else:
            classname = os.path.splitext(os.path.basename(filepath))[0]
        
        fail_id = getattr(item, 'fail_id', None)
        test_resolution = 'Unresolved'
        
        # Check if teardown failed (even if call passed)
        teardown_failed = teardown_report and teardown_report.failed
        
        # Detect xpass (unexpected pass on a strict xfail marker) BEFORE the
        # failed branch.  pytest marks these as 'failed' but they are actually
        # passing tests whose xfail marker should be removed — treat as Passed.
        is_xpass = (
            effective_report.failed
            and not teardown_failed
            and (
                getattr(effective_report, 'wasxfail', None)
                or (isinstance(effective_report.longrepr, str) and effective_report.longrepr.startswith('[XPASS(strict)]'))
            )
        )
        
        if is_xpass:
            testcase_attrs = {
                'classname': classname, 'name': name, 'file': str(filepath),
                'line': str(line), 'time': f"{total_duration:.3f}", "fail_id": '',
                "test_resolution": "Passed",
            }
            testcase = ET.Element('testcase', **testcase_attrs)
        
        elif effective_report.failed or teardown_failed:
            # Determine which report to use for the error/failure message
            if teardown_failed and not (effective_report.failed and effective_report.when in ('setup', 'call')):
                # Teardown error takes precedence if call didn't fail
                error_report = teardown_report
                tag = 'error'
                test_resolution = 'Teardown Error'
            elif effective_report.when == 'setup':
                error_report = effective_report
                tag = 'error'
            else:
                error_report = effective_report
                tag = 'failure'
            
            failure_message = str(error_report.longrepr.reprcrash.message) if hasattr(error_report.longrepr, 'reprcrash') else str(
                error_report.longrepr)
            
            if self.jira_enabled and tag == 'failure':
                try:
                    if fail_id:
                        issue = self._get_issue_by_test_id(fail_id)
                        if issue:
                            issue_text = issue.fields.summary
                            issue_type = issue.fields.issuetype.name
                            issue_id = issue.permalink()
                            status_name = issue.fields.status.name
                            if status_name in ('Verified', 'Closed'):
                                if hasattr(issue.fields, 'customfield_10020') and issue.fields.customfield_10020:
                                    status = issue.fields.customfield_10020.value
                                    if status_name == 'Verified' and status == 'Verified at Branch':
                                        test_resolution = 'Verified at Branch'
                                    else:
                                        test_resolution = 'Need to reopen'
                                else:
                                    test_resolution = 'Need to reopen'
                            elif status_name in ['Resolved', 'In Testing']:
                                test_resolution = 'Resolved in branch'
                            else:
                                test_resolution = 'Known issue'
                            failure_message = f'{test_resolution} {issue_id} {issue_type} [{issue_text}]'
                except Exception as e:
                    self.config.warn('JIRA_MARKER_ERROR', f"JIRA marker failed: {e}")
            
            testcase_attrs = {
                'classname': classname, 'name': name, 'file': str(filepath),
                'line': str(line), 'time': f"{total_duration:.3f}", "fail_id": fail_id or '', "test_resolution": test_resolution,
            }
            testcase = ET.Element('testcase', **testcase_attrs)
            failure_element = ET.SubElement(testcase, tag, message=failure_message)
            failure_element.text = self._get_cleaned_traceback(error_report)
        
        elif effective_report.skipped:
            # Detect xfail (expected failure): pytest marks these as "skipped"
            # but sets the wasxfail attribute with the xfail reason.
            xfail_reason = getattr(effective_report, 'wasxfail', None)
            if xfail_reason:
                # xfail tests are reported as failures with "Known Issue" resolution,
                # matching the backend/frontend convention for known bugs.
                test_resolution = 'Known Issue'
                # Extract error message from longrepr
                if isinstance(effective_report.longrepr, tuple) and len(effective_report.longrepr) >= 3:
                    failure_message = f"Known Issue: {xfail_reason}"
                    failure_text = f"{effective_report.longrepr[0]}:{effective_report.longrepr[1]}: {effective_report.longrepr[2]}"
                else:
                    failure_message = f"Known Issue: {xfail_reason}"
                    failure_text = str(effective_report.longrepr)
                testcase_attrs = {
                    'classname': classname, 'name': name, 'file': str(filepath),
                    'line': str(line), 'time': f"{total_duration:.3f}", "fail_id": fail_id or '',
                    "test_resolution": test_resolution,
                }
                testcase = ET.Element('testcase', **testcase_attrs)
                failure_element = ET.SubElement(testcase, 'failure', message=failure_message)
                failure_element.text = failure_text
            else:
                test_resolution = 'Skipped'
                testcase_attrs = {
                    'classname': classname, 'name': name, 'file': str(filepath),
                    'line': str(line), 'time': f"{total_duration:.3f}", "fail_id": '',
                    "test_resolution": test_resolution,
                }
                testcase = ET.Element('testcase', **testcase_attrs)
                # longrepr is a tuple (file, lineno, message) for normal skips,
                # but can be a ReprExceptionInfo object for xfail+teardown-error.
                if isinstance(effective_report.longrepr, tuple) and len(effective_report.longrepr) >= 3:
                    skip_message = str(effective_report.longrepr[2])
                    skip_text = f"{effective_report.longrepr[0]}:{effective_report.longrepr[1]}: {skip_message}"
                else:
                    skip_message = str(effective_report.longrepr)
                    skip_text = skip_message
                skipped_attrs = {'type': 'pytest.skip', 'message': skip_message}
                ET.SubElement(testcase, 'skipped', **skipped_attrs).text = skip_text
        else:
            testcase_attrs = {
                'classname': classname, 'name': name, 'file': str(filepath),
                'line': str(line), 'time': f"{total_duration:.3f}", "fail_id": '',
                "test_resolution": "Passed",
            }
            testcase = ET.Element('testcase', **testcase_attrs)
        
        all_properties = self.config.hook.pytest_testhide_get_test_case_properties(item=item, report=effective_report)
        flat_properties = [prop for sublist in all_properties for prop in sublist]
        if flat_properties:
            properties_element = ET.SubElement(testcase, 'properties')
            for prop_name, prop_value in flat_properties:
                ET.SubElement(properties_element, 'property', name=str(prop_name), value=str(prop_value))
                
        nodeid_hash = md5(item.nodeid.encode('utf-8')).hexdigest()
        worker = getattr(self.config, 'workerinput', {}).get('workerid', 'master')
        fname = os.path.join(self.temp_dir, f"{nodeid_hash}_{worker}.xml")
        
        if os.name == 'nt' and not fname.startswith('\\\\?\\'):
            fname = f"\\\\?\\{os.path.abspath(fname)}"
        
        os.makedirs(os.path.dirname(fname), exist_ok=True)
        ET.ElementTree(testcase).write(fname, encoding='utf-8', xml_declaration=True)
    
    def _find_item_by_nodeid(self, nodeid):
        """Look up a test item from the session by its nodeid."""
        if self.session:
            for item in self.session.items:
                if item.nodeid == nodeid:
                    return item
        return None
    
    def pytest_collectreport(self, report):
        """
        Captures collection errors (import failures, conftest crashes, syntax errors)
        and writes them as <testcase> with <error> to the XML.
        Without this hook, ERROR tests from the collection phase are completely
        missing from the report because pytest never creates test items for them,
        so pytest_runtest_teardown is never called.
        """
        if not report.failed:
            return

        nodeid = report.nodeid
        # Derive classname: replace path separators with dots, strip .py
        file_part = nodeid.split("::")[0]
        classname = file_part.replace("/", ".").replace("\\", ".").replace(".py", "")
        name = nodeid.rsplit("::", 1)[-1] if "::" in nodeid else nodeid

        message = (
            str(report.longrepr.reprcrash.message)
            if hasattr(report.longrepr, 'reprcrash')
            else str(report.longrepr)
        )
        trace = str(report.longrepr)

        testcase = ET.Element('testcase',
            classname=classname,
            name=name,
            file=file_part,
            line="0",
            time="0.000",
            fail_id="",
            test_resolution="Collection Error",
        )
        error_el = ET.SubElement(testcase, 'error', message=message)
        error_el.text = trace

        # Write to temp dir using the same pattern as pytest_runtest_teardown
        nodeid_hash = md5(nodeid.encode('utf-8')).hexdigest()
        worker = getattr(self.config, 'workerinput', {}).get('workerid', 'master')
        fname = os.path.join(self.temp_dir, f"{nodeid_hash}_{worker}.xml")

        if os.name == 'nt' and not fname.startswith('\\\\?\\'):
            fname = f"\\\\?\\{os.path.abspath(fname)}"

        os.makedirs(os.path.dirname(fname), exist_ok=True)
        ET.ElementTree(testcase).write(fname, encoding='utf-8', xml_declaration=True)

    def pytest_sessionstart(self, session):
        """
        Initializes the reporting process. Only the master node will
        clean up the temporary directory and initialize the JIRA connection.
        """
        self.session = session
        if self.is_xdist_master:
            self._init_jira_helper()
            
            if os.path.exists(self.temp_dir):
                shutil.rmtree(self.temp_dir)
            os.makedirs(self.temp_dir, exist_ok=True)
    
    def _merge_temp_dir_into_final(self):
        """Read everything from temp_dir and update the final junittests.xml (once!)."""
        if self._merged:
            return
        self._merged = True
        
        with FileLock(self.report_xml_path + ".lock"):
            root = ET.Element('testsuites')
            suite = ET.SubElement(root, 'testsuite',
                                  name='pytest',
                                  timestamp=datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3],
                                  hostname=socket.gethostname())
            
            props = ET.SubElement(suite, 'properties')
            ET.SubElement(props, 'property', name='ip_address',
                          value=socket.gethostbyname(socket.gethostname()))
            ET.SubElement(props, 'property', name='hostname',
                          value=socket.gethostname())
            
            for meta in self.config.hook.pytest_testhide_add_metadata(plugin=self):
                for k, v in meta:
                    ET.SubElement(props, 'property', name=str(k), value=str(v))
            
            if os.path.exists(self.temp_dir):
                for fname in sorted(os.listdir(self.temp_dir)):
                    if fname.endswith('.xml'):
                        try:
                            case_tree = ET.parse(os.path.join(self.temp_dir, fname))
                            suite.append(case_tree.getroot())
                        except ET.ParseError:
                            continue
            
            cases = suite.findall('testcase')
            suite.set('tests', str(len(cases)))
            suite.set('failures', str(len(suite.findall('.//failure'))))
            suite.set('errors', str(len(suite.findall('.//error'))))
            suite.set('skipped', str(len(suite.findall('.//skipped'))))
            suite.set('time', f"{sum(float(c.get('time', 0)) for c in cases):.3f}")
            
            tmp = self.report_xml_path + '.tmp'
            ET.indent(ET.ElementTree(root), space='\t', level=0)
            ET.ElementTree(root).write(tmp, encoding='utf-8', xml_declaration=True)
            os.replace(tmp, self.report_xml_path)
        
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def _signal_flush(self, signum, frame):
        try:
            self._merge_temp_dir_into_final()
        finally:
            signal.signal(signum, signal.SIG_DFL)
            os.kill(os.getpid(), signum)
    
    def pytest_sessionfinish(self, session):
        """
        Finalizes the report. Only the master node will merge all temporary files.
        The entire merge and write process is protected by a file lock.
        """
        if self.is_xdist_master:
            self._merge_temp_dir_into_final()
    
    def pytest_unconfigure(self, config):
        """
        Called by PyTest once at the very end, after pytest_sessionfinish.
        """
        pass


# --- Global functions that pytest discovers via entry points ---

def pytest_addoption(parser):
    """Adds all command-line options for the plugin."""
    group = parser.getgroup('testhide-reporting', 'Testhide Incremental Reporting')
    group.addoption('--report-xml', action='store', default=None, help='Enable incremental XML reporting.')
    
    # JIRA options for automatic integration
    group.addoption('--jira-url', dest='jira_url', default=None, action='store', help='JIRA URL for integration.')
    group.addoption('--jira-username', dest='jira_username', default=None, action='store', help='JIRA username.')
    group.addoption('--jira-password', dest='jira_password', default=None, action='store',
                    help='JIRA password or API token.')


@pytest.hookimpl(tryfirst=True)
def pytest_configure(config):
    try:
        config.pluginmanager.add_hookspecs(hookspecs)
    except pluggy.PluginValidationError:
        pass
    
    if not config.option.report_xml:
        return
    
    base_name = "testhide_plugin"
    
    if config.pluginmanager.has_plugin(base_name + "_active"):
        return
    
    config.pluginmanager.register(TesthidePlugin(config), base_name + "_active")
