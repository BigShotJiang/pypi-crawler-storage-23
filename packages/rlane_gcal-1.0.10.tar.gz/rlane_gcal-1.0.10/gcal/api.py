"""Interface to Google Calendar."""

from argparse import Namespace
from typing import Any, Iterator

import libgoogle

__all__ = ["GoogleCalendarAPI"]


class GoogleCalendarAPI:
    """Interface to Google Calendar.

    See https://developers.google.com/calendar/api/v3/reference
    """

    def __init__(self, options: Namespace) -> None:
        """Connect to Google Calendar."""

        self.options = options
        self.service = libgoogle.connect("calendar.readonly", "v3")

    def get_users_calendar_list(self) -> Iterator[dict[str, Any]]:
        """Yield each calendar in user's calendar list."""

        page_token = None
        while True:
            calendar_list = self.service.calendarList().list(pageToken=page_token).execute()
            for calendar in calendar_list["items"]:
                if self.options.includes and calendar["summary"] not in self.options.includes:
                    continue
                if self.options.excludes and calendar["summary"] in self.options.excludes:
                    continue
                yield calendar
            page_token = calendar_list.get("nextPageToken")
            if not page_token:
                break
