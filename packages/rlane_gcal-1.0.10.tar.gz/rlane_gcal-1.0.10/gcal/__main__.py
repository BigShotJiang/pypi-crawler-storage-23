"""Enable running with `python -m`."""

from gcal.cli import main

if __name__ == "__main__":
    main()
