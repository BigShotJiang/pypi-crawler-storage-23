package com.worsoft.worsoft.hr.mapper;

import com.worsoft.worsoft.common.data.datascope.WorsoftBaseMapper;
import com.worsoft.worsoft.hr.entity.ContractSignBatchEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ContractSignBatchMapper extends WorsoftBaseMapper<ContractSignBatchEntity> {

}
