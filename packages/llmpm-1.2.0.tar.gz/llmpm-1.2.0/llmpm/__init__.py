"""llmpm — LLM Package Manager."""

__version__ = "1.2.0"
__author__ = "llmpm contributors"
