"""Nexus-Dev: MCP Server for Persistent AI Coding Assistant Memory."""

__version__ = "0.1.0"
__author__ = "Marco Mornati"
