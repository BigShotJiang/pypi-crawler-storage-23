# PYTHON_ARGCOMPLETE_OK
# -*- coding: utf-8 -*-
# Copyright (c) 2026 Guennadi Maximov C. All Rights Reserved.
"""
Version updater from a target file.

Copyright (c) 2026 Guennadi Maximov C. All Rights Reserved.
"""
import sys

from .update import main

if __name__ == "__main__":
    sys.exit(main())

# vim: set ts=4 sts=4 sw=4 et ai si sta:
