# update-version
Python script to update version file.

<!-- vim: set ts=2 sts=2 sw=2 et ai si sta: -->
