"""
Configuration settings for additory v0.1.3.

Provides add.set() and add.get() functions for global configuration.
"""

from typing import Any, Optional, Dict
from pathlib import Path


class Settings:
    """Global settings manager."""
    
    def __init__(self):
        self._settings: Dict[str, Any] = {}
    
    def set(self, **kwargs):
        """
        Set configuration values.
        
        Supported settings:
        - expressions: Path to user expressions folder
        - play: Game to play (easter egg - launches game immediately!)
        - backend: Default backend (future)
        - logging: Enable logging (future)
        
        Examples:
            add.set(expressions="/path/to/folder")
            add.set(logging=True)
            add.set(backend="polars")
            add.set(play='tictactoe')  # Easter egg!
        """
        for key, value in kwargs.items():
            if key == 'expressions':
                self._set_expressions(value)
            elif key == 'play':
                self._set_play(value)
            elif key == 'backend':
                self._set_backend(value)
            elif key == 'logging':
                self._set_logging(value)
            else:
                raise ValueError(
                    f"Unknown setting '{key}'. "
                    f"Supported: expressions, play, backend, logging"
                )
    
    def get(self, key: str) -> Any:
        """
        Get configuration value.
        
        Args:
            key: Setting key
            
        Returns:
            Setting value or None if not set
        """
        return self._settings.get(key)
    
    def _set_expressions(self, folder_path: str):
        """Set user expressions folder."""
        # Validate path
        path = Path(folder_path)
        if not path.exists():
            raise ValueError(f"Folder does not exist: {folder_path}")
        if not path.is_dir():
            raise ValueError(f"Path is not a directory: {folder_path}")
        
        # Load expressions
        import sys
        from pathlib import Path as PathLib
        
        # Add python-specific to path if not already there
        python_specific_path = PathLib(__file__).parent.parent
        if str(python_specific_path) not in sys.path:
            sys.path.insert(0, str(python_specific_path))
        
        from expressions import set_user_folder
        set_user_folder(folder_path)
        
        # Store setting
        self._settings['expressions'] = str(path.absolute())
        self._settings['expressions_namespace'] = path.name
    
    def _set_play(self, game: str):
        """Set game to play (easter egg feature)."""
        # Import games module
        import sys
        from pathlib import Path as PathLib
        
        # Add python-specific to path if not already there
        python_specific_path = PathLib(__file__).parent.parent
        if str(python_specific_path) not in sys.path:
            sys.path.insert(0, str(python_specific_path))
        
        from games import play
        
        # Store setting
        self._settings['play'] = game
        
        # Launch the game immediately
        play(game)
    
    def _set_backend(self, backend: str):
        """Set default backend (future feature)."""
        valid_backends = ['polars', 'pandas', 'cudf']
        if backend not in valid_backends:
            raise ValueError(
                f"Invalid backend '{backend}'. "
                f"Valid options: {', '.join(valid_backends)}"
            )
        self._settings['backend'] = backend
    
    def _set_logging(self, enabled: bool):
        """Set logging enabled (future feature)."""
        if not isinstance(enabled, bool):
            raise ValueError("logging must be True or False")
        self._settings['logging'] = enabled


# Global settings instance
_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Get the global settings instance (singleton)."""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def set_config(**kwargs):
    """Set configuration values."""
    settings = get_settings()
    settings.set(**kwargs)


def get_config(key: str) -> Any:
    """Get configuration value."""
    settings = get_settings()
    return settings.get(key)
