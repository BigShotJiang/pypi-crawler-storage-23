"""
Expression Loader - Load and manage .add expression files

Handles loading expressions from:
- Inbuilt expressions (core.add, finance.add, medical.add)
- User-defined expressions from custom folder
"""

import re
from pathlib import Path
from typing import Dict, Optional, Tuple
import hashlib


class Expression:
    """Represents a single expression."""
    
    def __init__(self, name: str, expression: str, description: str, sha: Optional[str] = None):
        self.name = name
        self.expression = expression
        self.description = description
        self.sha = sha
    
    def __repr__(self):
        return f"Expression(name='{self.name}', expression='{self.expression}')"


class ExpressionRegistry:
    """Registry for managing expressions from multiple sources."""
    
    def __init__(self):
        self.inbuilt: Dict[str, Expression] = {}
        self.user_folder: Optional[UserFolder] = None
        self._load_inbuilt()
    
    def _load_inbuilt(self):
        """Load all inbuilt expressions from .add files."""
        # Get the inbuilt_expressions directory
        inbuilt_dir = Path(__file__).parent.parent / "inbuilt_expressions"
        
        if not inbuilt_dir.exists():
            # No inbuilt expressions available
            return
        
        # Load all .add files
        for add_file in inbuilt_dir.glob("*.add"):
            expressions = load_add_file(add_file)
            
            # Check for duplicates
            for name, expr in expressions.items():
                if name in self.inbuilt:
                    raise ValueError(
                        f"Duplicate expression name '{name}' found in builtin files "
                        f"(already defined in another file)"
                    )
                self.inbuilt[name] = expr
    
    def set_user_folder(self, folder_path: str):
        """Set user expressions folder."""
        folder_path_obj = Path(folder_path)
        
        if not folder_path_obj.exists():
            raise ValueError(f"Folder does not exist: {folder_path}")
        
        if not folder_path_obj.is_dir():
            raise ValueError(f"Path is not a directory: {folder_path}")
        
        # Derive namespace from folder name
        namespace = folder_path_obj.name
        
        # Load all .add files from folder
        expressions = {}
        for add_file in folder_path_obj.glob("*.add"):
            file_expressions = load_add_file(add_file)
            
            # Check for duplicates within folder
            for name, expr in file_expressions.items():
                if name in expressions:
                    raise ValueError(
                        f"Duplicate expression name '{name}' found in user folder "
                        f"(defined in multiple .add files)"
                    )
                expressions[name] = expr
        
        # Check for conflicts with inbuilt
        conflicts = set(expressions.keys()) & set(self.inbuilt.keys())
        if conflicts:
            raise ValueError(
                f"Name conflict - expression(s) {conflicts} in user namespace '{namespace}' "
                f"conflict with inbuilt expressions"
            )
        
        # Create user folder
        self.user_folder = UserFolder(
            path=folder_path_obj,
            namespace=namespace,
            expressions=expressions
        )
    
    def resolve(self, reference: str) -> Expression:
        """
        Resolve an expression reference.
        
        Args:
            reference: Expression reference (e.g., 'inbuilt:bmi', 'my_folder:custom')
            
        Returns:
            Expression object
            
        Raises:
            ValueError: If reference is invalid or expression not found
        """
        # Parse reference
        parts = reference.split(':', 1)
        if len(parts) != 2:
            raise ValueError(
                f"Invalid expression reference '{reference}'. "
                f"Expected format: 'namespace:name'"
            )
        
        namespace, name = parts
        
        # Check inbuilt namespace
        if namespace == 'inbuilt':
            if name not in self.inbuilt:
                available = ', '.join(sorted(self.inbuilt.keys())[:5])
                raise ValueError(
                    f"Expression '{name}' not found in namespace 'inbuilt'. "
                    f"Available: {available}..."
                )
            return self.inbuilt[name]
        
        # Check user namespace
        if self.user_folder and self.user_folder.namespace == namespace:
            if name not in self.user_folder.expressions:
                available = ', '.join(sorted(self.user_folder.expressions.keys())[:5])
                raise ValueError(
                    f"Expression '{name}' not found in namespace '{namespace}'. "
                    f"Available: {available}..."
                )
            return self.user_folder.expressions[name]
        
        # Unknown namespace
        available_namespaces = ['inbuilt']
        if self.user_folder:
            available_namespaces.append(self.user_folder.namespace)
        
        raise ValueError(
            f"Unknown namespace '{namespace}'. "
            f"Available namespaces: {', '.join(available_namespaces)}"
        )
    
    def list_expressions(self, namespace: Optional[str] = None) -> Dict[str, list]:
        """
        List all expressions, optionally filtered by namespace.
        
        Args:
            namespace: Optional namespace to filter by
            
        Returns:
            Dict with namespace as key and list of expression names as value
        """
        result = {}
        
        if namespace is None or namespace == 'inbuilt':
            result['inbuilt'] = sorted(self.inbuilt.keys())
        
        if self.user_folder and (namespace is None or namespace == self.user_folder.namespace):
            result[self.user_folder.namespace] = sorted(self.user_folder.expressions.keys())
        
        return result


class UserFolder:
    """Represents a user expressions folder."""
    
    def __init__(self, path: Path, namespace: str, expressions: Dict[str, Expression]):
        self.path = path
        self.namespace = namespace
        self.expressions = expressions
    
    def __repr__(self):
        return f"UserFolder(namespace='{self.namespace}', expressions={len(self.expressions)})"


def load_add_file(file_path: Path) -> Dict[str, Expression]:
    """
    Load expressions from a .add file.
    
    Format:
        [expression_name]
        expression = "formula"
        description = "description"
        sha = "hash" (optional)
    
    Args:
        file_path: Path to .add file
        
    Returns:
        Dict mapping expression name to Expression object
    """
    expressions = {}
    
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Parse TOML-like format
    # Pattern: [name] followed by key = "value" lines
    pattern = r'\[(\w+)\]\s*\n((?:.*=.*\n?)*)'
    matches = re.findall(pattern, content, re.MULTILINE)
    
    for name, block in matches:
        # Parse key-value pairs
        expr_data = {}
        for line in block.strip().split('\n'):
            if '=' in line and not line.strip().startswith('#'):
                key, value = line.split('=', 1)
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                expr_data[key] = value
        
        # Create Expression object
        if 'expression' not in expr_data or 'description' not in expr_data:
            raise ValueError(
                f"Invalid expression '{name}' in {file_path.name}: "
                f"missing 'expression' or 'description'"
            )
        
        expressions[name] = Expression(
            name=name,
            expression=expr_data['expression'],
            description=expr_data['description'],
            sha=expr_data.get('sha')
        )
    
    return expressions


def compute_sha256(expression: str) -> str:
    """Compute SHA-256 hash of expression."""
    return hashlib.sha256(expression.encode()).hexdigest()


# Global registry instance
_registry: Optional[ExpressionRegistry] = None


def get_registry() -> ExpressionRegistry:
    """Get the global expression registry (singleton)."""
    global _registry
    if _registry is None:
        _registry = ExpressionRegistry()
    return _registry


def set_user_folder(folder_path: str):
    """Set user expressions folder."""
    registry = get_registry()
    registry.set_user_folder(folder_path)


def resolve_expression(reference: str) -> Expression:
    """Resolve an expression reference."""
    registry = get_registry()
    return registry.resolve(reference)


def list_expressions(namespace: Optional[str] = None) -> Dict[str, list]:
    """List all expressions."""
    registry = get_registry()
    return registry.list_expressions(namespace)
