"""
Expression system for additory v0.1.3.

Provides expression loading, registry, and resolution for @calc mode.
"""

from .loader import (
    Expression,
    ExpressionRegistry,
    UserFolder,
    get_registry,
    set_user_folder,
    resolve_expression,
    list_expressions,
    load_add_file,
    compute_sha256
)

__all__ = [
    'Expression',
    'ExpressionRegistry',
    'UserFolder',
    'get_registry',
    'set_user_folder',
    'resolve_expression',
    'list_expressions',
    'load_add_file',
    'compute_sha256'
]
