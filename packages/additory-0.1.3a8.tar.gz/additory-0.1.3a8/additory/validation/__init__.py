"""
Validation module for additory operations.

This module provides validation functions for:
- Cardinality validation (add.to)
- Position validation (add.to)
- Synthetic data validation (add.synthetic)
"""

from .cardinality import (
    validate_cardinality,
    get_cardinality_type
)

from .position import (
    validate_position,
    validate_string_position,
    normalize_position
)

from .synthetic import (
    validate_synthetic_request,
    validate_strategy_format,
    validate_increment_conflicts
)

__all__ = [
    # Cardinality validation
    'validate_cardinality',
    'get_cardinality_type',
    
    # Position validation
    'validate_position',
    'validate_string_position',
    'normalize_position',
    
    # Synthetic validation
    'validate_synthetic_request',
    'validate_strategy_format',
    'validate_increment_conflicts',
]
