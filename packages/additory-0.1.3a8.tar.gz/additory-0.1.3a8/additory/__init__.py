"""
Additory - Data augmentation and transformation library

Public API:
- to() - Data operations (lookup, merge, sort, summarize)
- transform() - Transform data within DataFrame
- synthetic() - Synthetic data generation
- set() - Configure settings

Example:
    >>> import additory as add
    >>> import polars as pl
    >>> 
    >>> df = pl.DataFrame({'weight': [70, 80], 'height': [1.75, 1.80]})
    >>> 
    >>> # Use builtin expression
    >>> result = add.transform('@calc', df, expression='inbuilt:bmi', as='bmi')
    >>> 
    >>> # Use @knn imputation
    >>> result = add.transform('@knn', df, fetch=['age'], strategy={'k': 5})
    >>> 
    >>> # Configure settings
    >>> add.set(expressions='/path/to/my_expressions')
"""

import sys
import os

# Add parent directory to path to import from python-specific
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Try to import Rust bindings
try:
    from . import _additory
    RUST_AVAILABLE = True
except ImportError:
    RUST_AVAILABLE = False
    _additory = None

# Import Python features
from config import settings
from expressions import loader
from games import games as games_module

# Import core parsing modules
from additory.core.param_handler import (
    normalize_column_input,
    normalize_key_input,
    normalize_by_input,
    normalize_expression_input,
    normalize_as_input,
    validate_expression_as_match,
)
from additory.core.mode_parser import parse_strategy_value

# Version
__version__ = "0.1.3a8"

def to(fetch_to, fetch_from, fetch, against, position=None, *, 
       strategy=None, join_type='lookup', as_type=None):
    """
    Add data from external source to target DataFrame.
    
    Modes:
    - LOOKUP (default): Add columns from reference by joining on key
    
    Args:
        fetch_to: Target DataFrame (polars or pandas)
        fetch_from: Reference DataFrame (required)
        fetch: Column(s) to add (str or list)
               - Single: 'col' or ['col'] (both work)
               - Multiple: ['col1', 'col2'] (list required)
        against: Key column(s) for joining (str or tuple)
                 - Single: 'key' or ['key'] (both work)
                 - Multiple: ('key1', 'key2') (tuple required)
        position: DataFrame-level position for ALL fetched columns
                  - String: 'after:col', 'before:col', 'start', 'end'
                  - Numeric: 0 to n-1 (positive) or -1 to -(n-1) (negative)
        strategy: Column-level control (dict)
                  - mode: Aggregation mode (e.g., 'first', 'sum', 'concat[,]')
                  - position: Column-specific position (overrides df-level)
                  - rename: Column rename mapping
        join_type: Join type ('lookup', 'left', 'inner', 'outer')
        as_type: Output format (None, 'pandas', 'polars')
        
    Returns:
        DataFrame: Result DataFrame (same type as fetch_to unless as_type specified)
        
    Raises:
        ImportError: If Rust bindings are not available
        ValueError: If required parameters are missing or invalid
        RuntimeError: If operation fails
        
    Examples:
        >>> # Add single column
        >>> result = add.to(df, ref_df, 'age', 'id')
        
        >>> # Add multiple columns
        >>> result = add.to(df, ref_df, ['age', 'salary'], 'id')
        
        >>> # Multiple keys
        >>> result = add.to(df, ref_df, 'amount', ('customer_id', 'date'))
        
        >>> # With position
        >>> result = add.to(df, ref_df, 'age', 'id', position='after:name')
        
        >>> # With strategy
        >>> result = add.to(df, ref_df, 'amount', 'id', 
        ...                 strategy={'mode': 'sum', 'rename': {'amount': 'total'}})
    """
    import polars as pl
    import pandas as pd
    
    if not RUST_AVAILABLE:
        raise ImportError(
            "add.to() requires Rust bindings. "
            "Install with: pip install additory[rust]"
        )
    
    # Normalize inputs using new parsing
    fetch = normalize_column_input(fetch)
    against = normalize_key_input(against)
    
    # Parse strategy if provided
    if strategy is not None:
        if isinstance(strategy, str):
            # Simple mode string
            strategy = parse_strategy_value(strategy)
        elif isinstance(strategy, dict):
            # Dict with mode and other options
            if 'mode' in strategy:
                strategy = parse_strategy_value(strategy)
            # else: keep as-is (might be other options without mode)
    
    # Validate fetch_from parameter
    if fetch_from is None:
        raise ValueError("fetch_from parameter is required for add.to()")
    
    # Detect DataFrame types
    target_is_pandas = isinstance(fetch_to, pd.DataFrame) if fetch_to is not None else False
    target_is_polars = isinstance(fetch_to, pl.DataFrame) if fetch_to is not None else False
    
    ref_is_pandas = isinstance(fetch_from, pd.DataFrame)
    ref_is_polars = isinstance(fetch_from, pl.DataFrame)
    
    # Validate DataFrame types
    if fetch_to is not None and not target_is_pandas and not target_is_polars:
        raise TypeError(
            f"fetch_to must be pandas or polars DataFrame, got {type(fetch_to).__name__}"
        )
    
    if not ref_is_pandas and not ref_is_polars:
        raise TypeError(
            f"fetch_from must be pandas or polars DataFrame, got {type(fetch_from).__name__}"
        )
    
    # Convert to polars if needed
    if fetch_to is not None:
        target_pl = pl.from_pandas(fetch_to) if target_is_pandas else fetch_to
    else:
        target_pl = None
    
    fetch_from_pl = pl.from_pandas(fetch_from) if ref_is_pandas else fetch_from
    
    # Convert target to Arrow IPC bytes
    import io
    
    if target_pl is not None:
        target_buffer = io.BytesIO()
        target_pl.write_ipc(target_buffer)
        target_bytes = target_buffer.getvalue()
    else:
        target_bytes = None
    
    # Convert fetch_from to Arrow IPC bytes
    ref_buffer = io.BytesIO()
    fetch_from_pl.write_ipc(ref_buffer)
    ref_bytes = ref_buffer.getvalue()
    
    # Prepare parameters
    params = {
        'fetch_from': ref_bytes,
        'fetch': fetch,
        'against': against,
        'position': position,
        'strategy': strategy,
        'join_type': join_type,
        'logging': False,
    }
    
    # Call Rust to function
    try:
        result_bytes = _additory.to(target_bytes, params)
    except Exception as e:
        raise RuntimeError(f"add.to() failed: {e}") from e
    
    # Convert back to DataFrame
    result_buffer = io.BytesIO(result_bytes)
    result_df = pl.read_ipc(result_buffer)
    
    # Convert to requested output type
    if as_type == 'pandas':
        return result_df.to_pandas()
    elif as_type == 'polars':
        return result_df
    elif target_is_pandas:
        return result_df.to_pandas()
    else:
        return result_df


def transform(mode, df, expression=None, *, where=None, by=None, fetch=None,
              columns=None, strategy=None, as_=None, fetch_at='end', logging=False):
    """
    Transform data within DataFrame.
    
    Modes:
    - @filter, @sort, @transpose, @aggregate, @split
    - @calc, @extract, @onehot, @label, @harmonize
    - @knn (Python-only)
    
    Args:
        mode (str): Transform mode (e.g., '@calc', '@knn', '@sort')
        df: Input DataFrame (polars or pandas)
        fetch: Column(s) to transform/select (str or list)
               - Single: 'col' or ['col'] (both work)
               - Multiple: ['col1', 'col2'] (list required)
        by: Separator/grouping/sort column (str or tuple)
            - Single: 'col' or ['col'] (both work)
            - Multiple: ('col1', 'col2') (tuple required)
        expression: Expression(s) for @calc mode (str or list)
                    - Single: 'expr' (string)
                    - Multiple: ['expr1', 'expr2'] (list)
        where: Filter condition (str)
        as_: New name(s)/order (str or list)
             - Single: 'name' (string)
             - Multiple: ['name1', 'name2'] (list)
             - Sort order: 'asc' or 'desc' (string)
        fetch_at: Position for new columns ('start', 'end', 'after:col', 'before:col')
        strategy: Advanced options (dict or str)
                  - If str: mode string (e.g., 'first:anycase', 'concat[,]')
                  - If dict: {'mode': 'first:anycase', 'k': 5, ...}
        logging: Enable detailed logging
        
    Returns:
        DataFrame: Transformed DataFrame (same type as input)
        
    Raises:
        ImportError: If Rust bindings are not available
        ValueError: If parameters are invalid
        RuntimeError: If transformation fails
        
    Examples:
        >>> # Filter rows
        >>> result = add.transform('@filter', df, where='age > 18')
        
        >>> # Calculate with single expression
        >>> result = add.transform('@calc', df, expression='inbuilt:bmi', as_='bmi')
        
        >>> # Calculate with multiple expressions
        >>> result = add.transform('@calc', df,
        ...     expression=['inbuilt:bmi', 'price * quantity'],
        ...     as_=['bmi', 'total'])
        
        >>> # KNN imputation
        >>> result = add.transform('@knn', df, fetch=['age'], strategy={'k': 5})
        
        >>> # Sort ascending
        >>> result = add.transform('@sort', df, by='date', as_='asc')
        
        >>> # Sort descending
        >>> result = add.transform('@sort', df, by='date', as_='desc')
    """
    import polars as pl
    import pandas as pd
    
    # Normalize inputs using new parsing
    if fetch is not None:
        fetch = normalize_column_input(fetch)
    if by is not None:
        by = normalize_by_input(by)
    if expression is not None:
        expression = normalize_expression_input(expression)
    if as_ is not None:
        as_ = normalize_as_input(as_)
    
    # Validate expression and as_ match for @calc mode
    if mode == '@calc' and expression is not None and as_ is not None:
        validate_expression_as_match(expression, as_)
    
    # Parse strategy if provided
    if strategy is not None:
        if isinstance(strategy, str):
            # Simple mode string
            strategy = parse_strategy_value(strategy)
        elif isinstance(strategy, dict):
            # Dict with mode and other options
            if 'mode' in strategy:
                strategy = parse_strategy_value(strategy)
            # else: keep as-is (might be other options without mode)
    
    # Detect backend
    is_pandas = isinstance(df, pd.DataFrame)
    is_polars = isinstance(df, pl.DataFrame)
    
    if not is_pandas and not is_polars:
        raise TypeError(
            f"DataFrame must be pandas or polars, got {type(df).__name__}"
        )
    
    # Convert to polars if needed
    if is_pandas:
        df_pl = pl.from_pandas(df)
    else:
        df_pl = df
    
    # Call Rust implementation if available
    if RUST_AVAILABLE:
        # Convert to Arrow IPC bytes
        import io
        buffer = io.BytesIO()
        df_pl.write_ipc(buffer)
        df_bytes = buffer.getvalue()
        
        # Prepare parameters
        params = {
            'mode': mode,
            'fetch': fetch,
            'by': by,
            'expression': expression,
            'where': where,
            'as': as_,
            'fetch_at': fetch_at,
            'strategy': strategy,
            'logging': logging,
        }
        
        # Call Rust transform
        try:
            result_bytes = _additory.transform(df_bytes, params)
        except Exception as e:
            raise RuntimeError(f"Transform failed: {e}") from e
        
        # Convert back to DataFrame
        result_buffer = io.BytesIO(result_bytes)
        result_df = pl.read_ipc(result_buffer)
    else:
        # Fallback to pure Python (limited modes)
        if mode == '@knn':
            # Use Python KNN implementation
            from transform.knn import perform_knn_imputation
            
            if not fetch:
                raise ValueError("fetch parameter is required for @knn mode")
            
            strategy_dict = strategy if isinstance(strategy, dict) else {}
            result_df = perform_knn_imputation(df_pl, fetch, strategy_dict)
        else:
            raise NotImplementedError(
                f"Mode {mode} requires Rust bindings. "
                f"Install with: pip install additory[rust]"
            )
    
    # Convert back to pandas if needed
    if is_pandas:
        return result_df.to_pandas()
    else:
        return result_df


def set(**kwargs):
    """
    Configure additory settings.
    
    Settings:
    - expressions (str): Path to user expressions folder
    - backend (str): DataFrame backend ('polars' or 'pandas')
    - logging (bool): Enable logging (True/False)
    - play (str): Launch game ('tictactoe' or 'sudoku') - undocumented easter egg
    
    Args:
        **kwargs: Configuration key-value pairs
        
    Examples:
        >>> # Set expressions folder
        >>> add.set(expressions='/path/to/my_expressions')
        
        >>> # Enable logging
        >>> add.set(logging=True)
    """
    # Handle special case: play game (easter egg)
    if 'play' in kwargs:
        game_name = kwargs.pop('play')
        games_module.launch_game(game_name)
    
    # Set remaining configuration
    if kwargs:
        settings.set_config(**kwargs)


# Expose key functions
__all__ = [
    'to',
    'transform',
    'set',
    '__version__',
    'RUST_AVAILABLE',
]


# Print warning if Rust bindings not available
if not RUST_AVAILABLE:
    import warnings
    warnings.warn(
        "Rust bindings not available. Only Python-only modes (@knn) will work. "
        "Install Rust bindings with: pip install additory[rust]",
        ImportWarning
    )
