"""
Deduce strategy for synthetic data generation.

Uses TF-IDF + cosine similarity to deduce missing labels based on text similarity.
Pure Python implementation (no LLMs, no external APIs).
"""

import warnings
from typing import Union, List
import pandas as pd
import polars as pl
import numpy as np

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


def deduce_labels(df: Union[pd.DataFrame, pl.DataFrame], 
                  target_column: str,
                  text_columns: Union[str, List[str]]) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Deduce missing labels using TF-IDF + cosine similarity.
    
    This is a pure Python implementation that uses text similarity to predict
    missing labels. Your data never leaves your machine.
    
    Args:
        df: DataFrame with some labeled and some unlabeled rows
        target_column: Column with labels to deduce (contains None/null for unlabeled)
        text_columns: Column(s) to use for text similarity (str or list of str)
    
    Returns:
        DataFrame with deduced labels filled in
    
    Raises:
        ImportError: If scikit-learn is not installed
        ValueError: If insufficient labeled examples (< 3)
    
    Examples:
        >>> df = pd.DataFrame({
        ...     'text': ['Cannot log in', 'Reset password', 'App crashes', 'Billing issue', 'Login error'],
        ...     'category': ['Technical', 'Account', 'Technical', 'Billing', None]
        ... })
        >>> result = deduce_labels(df, 'category', 'text')
        >>> result['category'].tolist()
        ['Technical', 'Account', 'Technical', 'Billing', 'Technical']
        
        >>> # Multiple text columns for better accuracy
        >>> df = pd.DataFrame({
        ...     'title': ['Bug fix', 'New feature', 'Bug report'],
        ...     'description': ['Fixed login', 'Added dashboard', 'Login broken'],
        ...     'category': ['Bug', 'Feature', None]
        ... })
        >>> result = deduce_labels(df, 'category', ['title', 'description'])
    """
    if not SKLEARN_AVAILABLE:
        raise ImportError(
            "scikit-learn is required for deduce strategy. "
            "Install it with: pip install scikit-learn"
        )
    
    # Convert to Pandas for processing (easier with sklearn)
    is_polars = isinstance(df, pl.DataFrame)
    if is_polars:
        df_work = df.to_pandas()
    else:
        df_work = df.copy()
    
    # Ensure text_columns is a list
    if isinstance(text_columns, str):
        text_columns = [text_columns]
    
    # Separate labeled and unlabeled rows
    labeled_mask = df_work[target_column].notna()
    labeled = df_work[labeled_mask]
    unlabeled = df_work[~labeled_mask]
    
    # Validate minimum labeled examples
    n_labeled = len(labeled)
    if n_labeled < 3:
        raise ValueError(
            f"Insufficient labeled examples: found {n_labeled}, minimum 3 required. "
            f"Please manually label at least 3 examples per category."
        )
    
    # Warn if few labeled examples
    if n_labeled < 5:
        warnings.warn(
            f"Only {n_labeled} labeled examples found. "
            f"For better accuracy, label at least 5 examples per category.",
            UserWarning
        )
    
    # If no unlabeled rows, return original
    if len(unlabeled) == 0:
        return df
    
    # Combine text columns into single text field
    def combine_text(row):
        texts = []
        for col in text_columns:
            if col in row.index and pd.notna(row[col]):
                texts.append(str(row[col]))
        return ' '.join(texts)
    
    labeled_text = labeled.apply(combine_text, axis=1)
    unlabeled_text = unlabeled.apply(combine_text, axis=1)
    
    # TF-IDF vectorization
    vectorizer = TfidfVectorizer(
        max_features=1000,
        stop_words='english',
        ngram_range=(1, 2)  # Use unigrams and bigrams
    )
    
    try:
        labeled_vectors = vectorizer.fit_transform(labeled_text)
        unlabeled_vectors = vectorizer.transform(unlabeled_text)
    except ValueError as e:
        # Handle case where vocabulary is empty
        raise ValueError(
            f"Could not vectorize text: {e}. "
            f"Ensure text columns contain meaningful text content."
        )
    
    # Compute cosine similarity
    similarities = cosine_similarity(unlabeled_vectors, labeled_vectors)
    
    # Find most similar labeled row for each unlabeled row
    most_similar_indices = np.argmax(similarities, axis=1)
    
    # Get labels from most similar rows
    labeled_labels = labeled[target_column].values
    predictions = labeled_labels[most_similar_indices]
    
    # Fill in predictions
    df_work.loc[~labeled_mask, target_column] = predictions
    
    # Convert back to Polars if needed
    if is_polars:
        return pl.from_pandas(df_work)
    
    return df_work


def validate_deduce_request(df: Union[pd.DataFrame, pl.DataFrame],
                           target_column: str,
                           text_columns: Union[str, List[str]]) -> tuple[bool, str]:
    """
    Validate deduce strategy request.
    
    Args:
        df: DataFrame to validate
        target_column: Target column name
        text_columns: Text column name(s)
    
    Returns:
        tuple: (is_valid, error_message)
    
    Examples:
        >>> df = pd.DataFrame({
        ...     'text': ['a', 'b', 'c'],
        ...     'label': ['A', 'B', None]
        ... })
        >>> is_valid, msg = validate_deduce_request(df, 'label', 'text')
        >>> is_valid
        False  # Only 2 labeled examples
    """
    # Convert to Pandas for validation
    if isinstance(df, pl.DataFrame):
        df_work = df.to_pandas()
    else:
        df_work = df
    
    # Check target column exists
    if target_column not in df_work.columns:
        return False, f"Target column '{target_column}' not found in DataFrame"
    
    # Check text columns exist
    if isinstance(text_columns, str):
        text_columns = [text_columns]
    
    for col in text_columns:
        if col not in df_work.columns:
            return False, f"Text column '{col}' not found in DataFrame"
    
    # Count labeled examples
    n_labeled = df_work[target_column].notna().sum()
    
    if n_labeled < 3:
        return False, (
            f"Insufficient labeled examples: found {n_labeled}, minimum 3 required. "
            f"Please manually label at least 3 examples per category."
        )
    
    return True, ""


def get_similarity_scores(df: Union[pd.DataFrame, pl.DataFrame],
                         target_column: str,
                         text_columns: Union[str, List[str]],
                         top_k: int = 3) -> pd.DataFrame:
    """
    Get similarity scores for unlabeled rows (for debugging/analysis).
    
    Args:
        df: DataFrame with labeled and unlabeled rows
        target_column: Target column name
        text_columns: Text column name(s)
        top_k: Number of top similar labeled rows to return
    
    Returns:
        DataFrame with similarity scores for each unlabeled row
    
    Examples:
        >>> df = pd.DataFrame({
        ...     'text': ['Cannot log in', 'Reset password', 'Login error'],
        ...     'category': ['Technical', 'Account', None]
        ... })
        >>> scores = get_similarity_scores(df, 'category', 'text', top_k=2)
        >>> scores.columns.tolist()
        ['row_index', 'predicted_label', 'top_1_label', 'top_1_score', 'top_2_label', 'top_2_score']
    """
    if not SKLEARN_AVAILABLE:
        raise ImportError(
            "scikit-learn is required for deduce strategy. "
            "Install it with: pip install scikit-learn"
        )
    
    # Convert to Pandas
    if isinstance(df, pl.DataFrame):
        df_work = df.to_pandas()
    else:
        df_work = df.copy()
    
    # Ensure text_columns is a list
    if isinstance(text_columns, str):
        text_columns = [text_columns]
    
    # Separate labeled and unlabeled
    labeled_mask = df_work[target_column].notna()
    labeled = df_work[labeled_mask]
    unlabeled = df_work[~labeled_mask]
    
    if len(unlabeled) == 0:
        return pd.DataFrame()
    
    # Combine text columns
    def combine_text(row):
        texts = []
        for col in text_columns:
            if col in row.index and pd.notna(row[col]):
                texts.append(str(row[col]))
        return ' '.join(texts)
    
    labeled_text = labeled.apply(combine_text, axis=1)
    unlabeled_text = unlabeled.apply(combine_text, axis=1)
    
    # TF-IDF vectorization
    vectorizer = TfidfVectorizer(max_features=1000, stop_words='english')
    labeled_vectors = vectorizer.fit_transform(labeled_text)
    unlabeled_vectors = vectorizer.transform(unlabeled_text)
    
    # Compute similarities
    similarities = cosine_similarity(unlabeled_vectors, labeled_vectors)
    
    # Build results DataFrame
    results = []
    labeled_labels = labeled[target_column].values
    
    for i, row_idx in enumerate(unlabeled.index):
        row_similarities = similarities[i]
        top_indices = np.argsort(row_similarities)[-top_k:][::-1]
        
        result = {
            'row_index': row_idx,
            'predicted_label': labeled_labels[top_indices[0]]
        }
        
        for k in range(top_k):
            if k < len(top_indices):
                idx = top_indices[k]
                result[f'top_{k+1}_label'] = labeled_labels[idx]
                result[f'top_{k+1}_score'] = row_similarities[idx]
        
        results.append(result)
    
    return pd.DataFrame(results)
