"""
Synthetic data generation strategies.
"""

from .increment import parse_increment_strategy, generate_increment
from .deduce import deduce_labels

__all__ = [
    'parse_increment_strategy',
    'generate_increment',
    'deduce_labels',
]
