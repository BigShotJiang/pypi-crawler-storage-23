"""
Synthetic data generation strategies.

This module provides strategies for generating synthetic data.
"""

from .strategies.increment import parse_increment_strategy, generate_increment
from .strategies.deduce import deduce_labels

__all__ = [
    'parse_increment_strategy',
    'generate_increment',
    'deduce_labels',
]
