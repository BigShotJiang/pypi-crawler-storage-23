"""
Tests for deduce strategy.

Tests deduce_labels(), validate_deduce_request(), and related functions.
"""

import pytest
import pandas as pd
import polars as pl
import warnings
from additory.synthetic.strategies.deduce import (
    deduce_labels,
    validate_deduce_request,
    get_similarity_scores,
    SKLEARN_AVAILABLE
)


# Skip all tests if sklearn not available
pytestmark = pytest.mark.skipif(
    not SKLEARN_AVAILABLE,
    reason="scikit-learn not installed"
)


class TestDeduceLabels:
    """Test deduce_labels() function."""
    
    def test_simple_deduce_pandas(self):
        """Test simple label deduction with Pandas."""
        df = pd.DataFrame({
            'text': [
                'Cannot log in to my account',
                'How do I reset my password?',
                'App crashes when I click submit',
                'Need help with billing',
                'The app won\'t open',
                'Question about my invoice',
                'Error message on login screen'
            ],
            'category': [
                'Technical',
                'Account',
                'Technical',
                'Billing',
                None,  # To be deduced
                None,  # To be deduced
                None   # To be deduced
            ]
        })
        
        result = deduce_labels(df, 'category', 'text')
        
        # Check that all categories are filled
        assert result['category'].notna().all()
        
        # Check specific predictions (should be similar to labeled examples)
        # "The app won't open" should be similar to "App crashes" (Technical)
        assert result.loc[4, 'category'] == 'Technical'
        
        # "Question about my invoice" should be similar to "Need help with billing" (Billing)
        assert result.loc[5, 'category'] == 'Billing'
        
        # "Error message on login screen" should be similar to "Cannot log in" (Technical)
        assert result.loc[6, 'category'] == 'Technical'
    
    def test_simple_deduce_polars(self):
        """Test simple label deduction with Polars."""
        df = pl.DataFrame({
            'text': [
                'Cannot log in',
                'Reset password',
                'App crashes',
                'Billing issue',
                'Login error'
            ],
            'category': [
                'Technical',
                'Account',
                'Technical',
                'Billing',
                None
            ]
        })
        
        result = deduce_labels(df, 'category', 'text')
        
        # Check result is Polars DataFrame
        assert isinstance(result, pl.DataFrame)
        
        # Check that all categories are filled
        assert result['category'].null_count() == 0
        
        # "Login error" should be similar to "Cannot log in" (Technical)
        assert result['category'][4] == 'Technical'
    
    def test_multiple_text_columns(self):
        """Test deduce with multiple text columns."""
        df = pd.DataFrame({
            'title': ['Bug fix', 'New feature', 'Bug report', 'Feature request'],
            'description': ['Fixed login', 'Added dashboard', 'Login broken', 'Need analytics'],
            'category': ['Bug', 'Feature', None, None]
        })
        
        result = deduce_labels(df, 'category', ['title', 'description'])
        
        # Check all filled
        assert result['category'].notna().all()
        
        # "Bug report" + "Login broken" should be similar to "Bug fix" + "Fixed login" (Bug)
        assert result.loc[2, 'category'] == 'Bug'
        
        # "Feature request" + "Need analytics" should be similar to "New feature" + "Added dashboard" (Feature)
        assert result.loc[3, 'category'] == 'Feature'
    
    def test_insufficient_labeled_examples(self):
        """Test error with insufficient labeled examples."""
        df = pd.DataFrame({
            'text': ['Task 1', 'Task 2', 'Task 3'],
            'category': ['A', 'B', None]  # Only 2 labeled
        })
        
        with pytest.raises(ValueError, match="Insufficient labeled examples"):
            deduce_labels(df, 'category', 'text')
    
    def test_no_unlabeled_rows(self):
        """Test with no unlabeled rows (returns original)."""
        df = pd.DataFrame({
            'text': ['Task 1', 'Task 2', 'Task 3'],
            'category': ['A', 'B', 'C']  # All labeled
        })
        
        result = deduce_labels(df, 'category', 'text')
        
        # Should return original DataFrame
        pd.testing.assert_frame_equal(result, df)
    
    def test_warning_few_examples(self):
        """Test warning with few labeled examples."""
        df = pd.DataFrame({
            'text': ['Task 1', 'Task 2', 'Task 3', 'Task 4'],
            'category': ['A', 'B', 'C', None]  # 3 labeled (minimum)
        })
        
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = deduce_labels(df, 'category', 'text')
            
            # Should have warning
            assert len(w) == 1
            assert "Only 3 labeled examples" in str(w[0].message)
    
    def test_single_text_column_as_list(self):
        """Test with single text column passed as list."""
        df = pd.DataFrame({
            'text': ['Cannot log in', 'Reset password', 'App crashes', 'Login error'],
            'category': ['Technical', 'Account', 'Technical', None]
        })
        
        result = deduce_labels(df, 'category', ['text'])  # List with single element
        
        assert result['category'].notna().all()
        assert result.loc[3, 'category'] == 'Technical'
    
    def test_preserves_labeled_rows(self):
        """Test that labeled rows are preserved."""
        df = pd.DataFrame({
            'text': ['Task 1', 'Task 2', 'Task 3', 'Task 4', 'Task 5'],
            'category': ['A', 'B', 'C', None, None]
        })
        
        result = deduce_labels(df, 'category', 'text')
        
        # Check labeled rows unchanged
        assert result.loc[0, 'category'] == 'A'
        assert result.loc[1, 'category'] == 'B'
        assert result.loc[2, 'category'] == 'C'
        
        # Check unlabeled rows filled
        assert result.loc[3, 'category'] is not None
        assert result.loc[4, 'category'] is not None


class TestValidateDeduceRequest:
    """Test validate_deduce_request() function."""
    
    def test_valid_request_pandas(self):
        """Test valid deduce request with Pandas."""
        df = pd.DataFrame({
            'text': ['a', 'b', 'c', 'd'],
            'label': ['A', 'B', 'C', None]  # 3 labeled
        })
        
        is_valid, msg = validate_deduce_request(df, 'label', 'text')
        assert is_valid
        assert msg == ""
    
    def test_valid_request_polars(self):
        """Test valid deduce request with Polars."""
        df = pl.DataFrame({
            'text': ['a', 'b', 'c', 'd'],
            'label': ['A', 'B', 'C', None]
        })
        
        is_valid, msg = validate_deduce_request(df, 'label', 'text')
        assert is_valid
        assert msg == ""
    
    def test_target_column_not_found(self):
        """Test error when target column not found."""
        df = pd.DataFrame({
            'text': ['a', 'b', 'c'],
            'label': ['A', 'B', None]
        })
        
        is_valid, msg = validate_deduce_request(df, 'nonexistent', 'text')
        assert not is_valid
        assert "Target column 'nonexistent' not found" in msg
    
    def test_text_column_not_found(self):
        """Test error when text column not found."""
        df = pd.DataFrame({
            'text': ['a', 'b', 'c'],
            'label': ['A', 'B', None]
        })
        
        is_valid, msg = validate_deduce_request(df, 'label', 'nonexistent')
        assert not is_valid
        assert "Text column 'nonexistent' not found" in msg
    
    def test_insufficient_labeled_examples(self):
        """Test error with insufficient labeled examples."""
        df = pd.DataFrame({
            'text': ['a', 'b', 'c'],
            'label': ['A', 'B', None]  # Only 2 labeled
        })
        
        is_valid, msg = validate_deduce_request(df, 'label', 'text')
        assert not is_valid
        assert "Insufficient labeled examples" in msg
        assert "found 2, minimum 3 required" in msg
    
    def test_multiple_text_columns(self):
        """Test validation with multiple text columns."""
        df = pd.DataFrame({
            'text1': ['a', 'b', 'c', 'd'],
            'text2': ['x', 'y', 'z', 'w'],
            'label': ['A', 'B', 'C', None]
        })
        
        is_valid, msg = validate_deduce_request(df, 'label', ['text1', 'text2'])
        assert is_valid
        assert msg == ""


class TestGetSimilarityScores:
    """Test get_similarity_scores() function."""
    
    def test_get_scores_basic(self):
        """Test getting similarity scores."""
        df = pd.DataFrame({
            'text': ['Cannot log in', 'Reset password', 'App crashes', 'Login error'],
            'category': ['Technical', 'Account', 'Technical', None]
        })
        
        scores = get_similarity_scores(df, 'category', 'text', top_k=2)
        
        # Check structure
        assert 'row_index' in scores.columns
        assert 'predicted_label' in scores.columns
        assert 'top_1_label' in scores.columns
        assert 'top_1_score' in scores.columns
        assert 'top_2_label' in scores.columns
        assert 'top_2_score' in scores.columns
        
        # Check only unlabeled row
        assert len(scores) == 1
        assert scores['row_index'].iloc[0] == 3
        
        # Check prediction
        assert scores['predicted_label'].iloc[0] == 'Technical'
    
    def test_get_scores_no_unlabeled(self):
        """Test with no unlabeled rows."""
        df = pd.DataFrame({
            'text': ['Task 1', 'Task 2', 'Task 3'],
            'category': ['A', 'B', 'C']  # All labeled
        })
        
        scores = get_similarity_scores(df, 'category', 'text')
        
        # Should return empty DataFrame
        assert len(scores) == 0
    
    def test_get_scores_top_k(self):
        """Test with different top_k values."""
        df = pd.DataFrame({
            'text': ['Task 1', 'Task 2', 'Task 3', 'Task 4', 'Task 5'],
            'category': ['A', 'B', 'C', None, None]
        })
        
        # top_k=1
        scores = get_similarity_scores(df, 'category', 'text', top_k=1)
        assert 'top_1_label' in scores.columns
        assert 'top_2_label' not in scores.columns
        
        # top_k=3
        scores = get_similarity_scores(df, 'category', 'text', top_k=3)
        assert 'top_1_label' in scores.columns
        assert 'top_2_label' in scores.columns
        assert 'top_3_label' in scores.columns


class TestDeduceIntegration:
    """Integration tests for deduce strategy."""
    
    def test_support_ticket_categorization(self):
        """Test realistic support ticket categorization."""
        df = pd.DataFrame({
            'ticket_text': [
                'Cannot log in to my account',
                'How do I reset my password?',
                'App crashes when I click submit',
                'Need help with billing',
                'The app won\'t open',
                'Question about my invoice',
                'Error message on login screen',
                'Want to upgrade my plan',
                'App freezes on startup'
            ],
            'category': [
                'Technical',
                'Account',
                'Technical',
                'Billing',
                None,  # Should be Technical
                None,  # Should be Billing
                None,  # Should be Technical
                None,  # Should be Billing
                None   # Should be Technical
            ]
        })
        
        result = deduce_labels(df, 'category', 'ticket_text')
        
        # Check all filled
        assert result['category'].notna().all()
        
        # Check predictions make sense
        assert result.loc[4, 'category'] == 'Technical'  # "app won't open"
        assert result.loc[5, 'category'] == 'Billing'    # "question about invoice"
        assert result.loc[6, 'category'] == 'Technical'  # "error message on login"
        assert result.loc[7, 'category'] == 'Billing'    # "upgrade my plan"
        assert result.loc[8, 'category'] == 'Technical'  # "app freezes"
    
    def test_task_status_deduction(self):
        """Test task status deduction."""
        df = pd.DataFrame({
            'comment': [
                'Task completed successfully',
                'Still in progress',
                'Finished the work',
                'Not started yet',
                'Will do it tomorrow',
                'All done',
                'Haven\'t begun'
            ],
            'status': [
                'Complete',
                'Incomplete',
                'Complete',
                'Incomplete',
                None,  # Should be Incomplete
                None,  # Should be Complete
                None   # Should be Incomplete
            ]
        })
        
        result = deduce_labels(df, 'status', 'comment')
        
        # Check all filled
        assert result['status'].notna().all()
        
        # Check predictions
        assert result.loc[4, 'status'] == 'Incomplete'  # "will do it tomorrow"
        assert result.loc[5, 'status'] == 'Complete'    # "all done"
        assert result.loc[6, 'status'] == 'Incomplete'  # "haven't begun"


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
