"""
Tests for synthetic data validation.

Tests validate_synthetic_request(), validate_strategy_format(), and validate_increment_conflicts().
"""

import pytest
import pandas as pd
import polars as pl
from additory.validation import (
    validate_synthetic_request,
    validate_strategy_format,
    validate_increment_conflicts
)


class TestValidateSyntheticRequest:
    """Test validate_synthetic_request() function."""
    
    def test_valid_augment_mode(self):
        """Test valid augment mode request."""
        df = pd.DataFrame({'age': [25, 30, 35], 'salary': [50000, 60000, 70000]})
        
        is_valid, msg = validate_synthetic_request(
            'augment', df, 100, {'age': 'range:18-65'}
        )
        assert is_valid
        assert msg == ""
    
    def test_valid_new_mode(self):
        """Test valid @new mode request."""
        is_valid, msg = validate_synthetic_request(
            '@new', None, 100, {'id': 'increment', 'age': 'range:18-65'}
        )
        assert is_valid
        assert msg == ""
    
    def test_valid_analyze_mode(self):
        """Test valid @analyze mode request."""
        df = pd.DataFrame({'age': [25, 30, 35], 'salary': [50000, 60000, 70000]})
        
        is_valid, msg = validate_synthetic_request(
            '@analyze', df, 100, None
        )
        assert is_valid
        assert msg == ""
    
    def test_invalid_mode(self):
        """Test invalid mode."""
        is_valid, msg = validate_synthetic_request(
            'invalid_mode', None, 100, None
        )
        assert not is_valid
        assert "Invalid mode: 'invalid_mode'" in msg
    
    def test_augment_requires_df(self):
        """Test augment mode requires DataFrame."""
        is_valid, msg = validate_synthetic_request(
            'augment', None, 100, None
        )
        assert not is_valid
        assert "Mode 'augment' requires a DataFrame" in msg
    
    def test_analyze_requires_df(self):
        """Test @analyze mode requires DataFrame."""
        is_valid, msg = validate_synthetic_request(
            '@analyze', None, 100, None
        )
        assert not is_valid
        assert "Mode '@analyze' requires a DataFrame" in msg
    
    def test_invalid_n(self):
        """Test invalid n parameter."""
        # Zero
        is_valid, msg = validate_synthetic_request(
            '@new', None, 0, {'id': 'increment'}
        )
        assert not is_valid
        assert "n must be a positive integer" in msg
        
        # Negative
        is_valid, msg = validate_synthetic_request(
            '@new', None, -10, {'id': 'increment'}
        )
        assert not is_valid
        assert "n must be a positive integer" in msg
        
        # Non-integer
        is_valid, msg = validate_synthetic_request(
            '@new', None, 10.5, {'id': 'increment'}
        )
        assert not is_valid
        assert "n must be a positive integer" in msg
    
    def test_invalid_fetch_type(self):
        """Test invalid fetch type."""
        is_valid, msg = validate_synthetic_request(
            '@new', None, 100, ['id', 'age']  # Should be dict, not list
        )
        assert not is_valid
        assert "fetch must be a dict" in msg
    
    def test_distribution_insufficient_rows(self):
        """Test distribution strategy with insufficient rows."""
        # Small DataFrame (< 30 rows)
        df = pd.DataFrame({'age': [25, 30, 35]})  # Only 3 rows
        
        is_valid, msg = validate_synthetic_request(
            'augment', df, 100, {'age': 'distribution'}
        )
        assert not is_valid
        assert "uses 'distribution' strategy" in msg
        assert "Minimum 30 rows required" in msg
    
    def test_distribution_sufficient_rows(self):
        """Test distribution strategy with sufficient rows."""
        # Large DataFrame (>= 30 rows)
        df = pd.DataFrame({'age': list(range(30, 60))})  # 30 rows
        
        is_valid, msg = validate_synthetic_request(
            'augment', df, 100, {'age': 'distribution'}
        )
        assert is_valid
        assert msg == ""
    
    def test_increment_step_size_limit(self):
        """Test increment step size limit (step <= n/2)."""
        # Valid step size
        is_valid, msg = validate_synthetic_request(
            '@new', None, 100, {'id': 'increment[10]'}
        )
        assert is_valid
        assert msg == ""
        
        # Invalid step size (> n/2)
        is_valid, msg = validate_synthetic_request(
            '@new', None, 100, {'id': 'increment[60]'}
        )
        assert not is_valid
        assert "step size 60 which exceeds n/2" in msg
    
    def test_linked_list_consistency(self):
        """Test linked list level consistency."""
        # Valid - all levels same size
        linked_list = [
            ['a', 'b', 'c'],
            ['x', 'y', 'z'],
            ['1', '2', '3']
        ]
        is_valid, msg = validate_synthetic_request(
            '@new', None, 100, {'col': linked_list}
        )
        assert is_valid
        assert msg == ""
        
        # Invalid - inconsistent sizes
        linked_list = [
            ['a', 'b', 'c'],
            ['x', 'y'],  # Only 2 items
            ['1', '2', '3']
        ]
        is_valid, msg = validate_synthetic_request(
            '@new', None, 100, {'col': linked_list}
        )
        assert not is_valid
        assert "inconsistent linked list sizes" in msg
    
    def test_deduce_insufficient_examples(self):
        """Test deduce strategy with insufficient labeled examples."""
        # DataFrame with < 3 labeled examples
        df = pd.DataFrame({
            'text': ['hello', 'world', 'test', 'data'],
            'label': ['A', 'B', None, None]  # Only 2 labeled
        })
        
        is_valid, msg = validate_synthetic_request(
            'augment', df, 100, {'label': 'deduce:label'}
        )
        assert not is_valid
        assert "uses 'deduce:label'" in msg
        assert "Minimum 3 required" in msg
    
    def test_deduce_sufficient_examples(self):
        """Test deduce strategy with sufficient labeled examples."""
        # DataFrame with >= 3 labeled examples
        df = pd.DataFrame({
            'text': ['hello', 'world', 'test', 'data', 'more'],
            'label': ['A', 'B', 'C', None, None]  # 3 labeled
        })
        
        is_valid, msg = validate_synthetic_request(
            'augment', df, 100, {'label': 'deduce:label'}
        )
        assert is_valid
        assert msg == ""
    
    def test_multiple_errors(self):
        """Test multiple validation errors."""
        is_valid, msg = validate_synthetic_request(
            'invalid_mode', None, -10, ['not', 'a', 'dict']
        )
        assert not is_valid
        # Should contain multiple error messages
        assert "Invalid mode" in msg
        assert "n must be a positive integer" in msg
        assert "fetch must be a dict" in msg
    
    def test_polars_dataframe(self):
        """Test with Polars DataFrame."""
        df = pl.DataFrame({'age': [25, 30, 35], 'salary': [50000, 60000, 70000]})
        
        is_valid, msg = validate_synthetic_request(
            'augment', df, 100, {'age': 'range:18-65'}
        )
        assert is_valid
        assert msg == ""


class TestValidateStrategyFormat:
    """Test validate_strategy_format() function."""
    
    def test_valid_strategies(self):
        """Test valid strategy formats."""
        valid_strategies = [
            'increment',
            'increment[5]',
            'increment:start=100',
            'range:18-65',
            'choice:[A,B,C]',
            'distribution',
            'deduce:label',
            'uuid',
            'timestamp',
            'date',
            'time',
            'datetime',
            'email',
            'phone',
            'name',
            'address',
            'city',
            'state',
            'zip',
            'country',
        ]
        
        for strategy in valid_strategies:
            is_valid, msg = validate_strategy_format(strategy)
            assert is_valid, f"Failed for strategy={strategy}"
            assert msg == ""
    
    def test_invalid_strategy(self):
        """Test invalid strategy format."""
        is_valid, msg = validate_strategy_format('invalid_strategy')
        assert not is_valid
        assert "Unknown strategy: 'invalid_strategy'" in msg
    
    def test_non_string_strategy(self):
        """Test non-string strategy (should return valid)."""
        # Non-string strategies validated elsewhere (e.g., linked lists)
        for strategy in [123, ['a', 'b'], {'key': 'value'}]:
            is_valid, msg = validate_strategy_format(strategy)
            assert is_valid
            assert msg == ""


class TestValidateIncrementConflicts:
    """Test validate_increment_conflicts() function."""
    
    def test_no_conflicts(self):
        """Test no increment conflicts."""
        fetch = {
            'id': 'increment',
            'seq': 'increment:start=100',
            'order': 'increment:start=1000'
        }
        
        is_valid, msg = validate_increment_conflicts(fetch)
        assert is_valid
        assert msg == ""
    
    def test_duplicate_start_values(self):
        """Test duplicate start values (conflict)."""
        fetch = {
            'id': 'increment:start=1',
            'seq': 'increment:start=1'  # Duplicate start
        }
        
        is_valid, msg = validate_increment_conflicts(fetch)
        assert not is_valid
        assert "Increment conflict" in msg
        assert "both start at 1" in msg
    
    def test_default_start_conflict(self):
        """Test default start value conflict."""
        fetch = {
            'id': 'increment',  # Default start=1
            'seq': 'increment:start=1'  # Explicit start=1
        }
        
        is_valid, msg = validate_increment_conflicts(fetch)
        assert not is_valid
        assert "Increment conflict" in msg
    
    def test_no_increment_strategies(self):
        """Test with no increment strategies."""
        fetch = {
            'age': 'range:18-65',
            'name': 'choice:[A,B,C]'
        }
        
        is_valid, msg = validate_increment_conflicts(fetch)
        assert is_valid
        assert msg == ""
    
    def test_empty_fetch(self):
        """Test with empty fetch."""
        is_valid, msg = validate_increment_conflicts({})
        assert is_valid
        assert msg == ""
        
        is_valid, msg = validate_increment_conflicts(None)
        assert is_valid
        assert msg == ""
    
    def test_increment_with_pattern(self):
        """Test increment with pattern parameter."""
        fetch = {
            'id': 'increment:start=1:pattern=EMP_[001]',
            'seq': 'increment:start=100:pattern=SEQ_[0001]'
        }
        
        is_valid, msg = validate_increment_conflicts(fetch)
        assert is_valid
        assert msg == ""


class TestSyntheticValidationIntegration:
    """Integration tests for synthetic validation."""
    
    def test_full_validation_workflow(self):
        """Test full validation workflow."""
        df = pd.DataFrame({
            'age': list(range(25, 55)),  # 30 rows
            'salary': list(range(50000, 80000, 1000)),
            'label': ['A'] * 10 + ['B'] * 10 + [None] * 10
        })
        
        fetch = {
            'id': 'increment',
            'seq': 'increment:start=100',
            'age': 'distribution',
            'label': 'deduce:label'
        }
        
        # Validate request
        is_valid, msg = validate_synthetic_request('augment', df, 100, fetch)
        assert is_valid
        assert msg == ""
        
        # Validate strategies
        for col, strategy in fetch.items():
            is_valid, msg = validate_strategy_format(strategy)
            assert is_valid, f"Failed for {col}={strategy}"
        
        # Validate increment conflicts
        is_valid, msg = validate_increment_conflicts(fetch)
        assert is_valid
    
    def test_multiple_validation_failures(self):
        """Test multiple validation failures."""
        df = pd.DataFrame({'age': [25, 30]})  # Only 2 rows
        
        fetch = {
            'id': 'increment:start=1',
            'seq': 'increment:start=1',  # Conflict
            'age': 'distribution',  # Insufficient rows
            'data': 'increment[60]'  # Step too large
        }
        
        # Request validation should catch distribution issue
        is_valid, msg = validate_synthetic_request('augment', df, 100, fetch)
        assert not is_valid
        
        # Increment conflicts
        is_valid, msg = validate_increment_conflicts(fetch)
        assert not is_valid


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
