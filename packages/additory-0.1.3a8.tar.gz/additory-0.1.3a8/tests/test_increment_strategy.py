"""
Tests for increment strategy.

Tests parse_increment_strategy(), generate_increment(), and related functions.
"""

import pytest
from additory.synthetic.strategies.increment import (
    parse_increment_strategy,
    generate_increment,
    validate_increment_step,
    format_with_pattern
)


class TestParseIncrementStrategy:
    """Test parse_increment_strategy() function."""
    
    def test_simple_increment(self):
        """Test simple increment (no parameters)."""
        step, start, pattern = parse_increment_strategy('increment')
        assert step == 1
        assert start == 1
        assert pattern is None
    
    def test_increment_with_step(self):
        """Test increment with step size."""
        step, start, pattern = parse_increment_strategy('increment[3]')
        assert step == 3
        assert start == 1
        assert pattern is None
        
        step, start, pattern = parse_increment_strategy('increment[5]')
        assert step == 5
        assert start == 1
        assert pattern is None
    
    def test_increment_with_start(self):
        """Test increment with start value."""
        step, start, pattern = parse_increment_strategy('increment:start=100')
        assert step == 1
        assert start == 100
        assert pattern is None
        
        step, start, pattern = parse_increment_strategy('increment:start=1000')
        assert step == 1
        assert start == 1000
        assert pattern is None
    
    def test_increment_with_pattern(self):
        """Test increment with pattern."""
        step, start, pattern = parse_increment_strategy('increment:start=1:pattern=EMP_[001]')
        assert step == 1
        assert start == 1
        assert pattern == 'EMP_[001]'
        
        step, start, pattern = parse_increment_strategy('increment:pattern=ID_[0001]')
        assert step == 1
        assert start == 1
        assert pattern == 'ID_[0001]'
    
    def test_increment_step_and_start(self):
        """Test increment with both step and start."""
        step, start, pattern = parse_increment_strategy('increment[5]:start=100')
        assert step == 5
        assert start == 100
        assert pattern is None
    
    def test_increment_all_parameters(self):
        """Test increment with all parameters."""
        step, start, pattern = parse_increment_strategy('increment[2]:start=1:pattern=EMP_[001]')
        assert step == 2
        assert start == 1
        assert pattern == 'EMP_[001]'
        
        step, start, pattern = parse_increment_strategy('increment[10]:start=100:pattern=ID_[0001]')
        assert step == 10
        assert start == 100
        assert pattern == 'ID_[0001]'
    
    def test_increment_pattern_with_spaces(self):
        """Test increment with pattern containing spaces."""
        step, start, pattern = parse_increment_strategy('increment:pattern=USER [001]')
        assert step == 1
        assert start == 1
        assert pattern == 'USER [001]'


class TestGenerateIncrement:
    """Test generate_increment() function."""
    
    def test_simple_increment(self):
        """Test simple increment sequence."""
        result = generate_increment(5)
        assert result == [1, 2, 3, 4, 5]
        
        result = generate_increment(10)
        assert result == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    def test_increment_with_step(self):
        """Test increment with step size."""
        result = generate_increment(5, step=3)
        assert result == [1, 4, 7, 10, 13]
        
        result = generate_increment(5, step=5)
        assert result == [1, 6, 11, 16, 21]
        
        result = generate_increment(5, step=10)
        assert result == [1, 11, 21, 31, 41]
    
    def test_increment_with_start(self):
        """Test increment with start value."""
        result = generate_increment(5, start=100)
        assert result == [100, 101, 102, 103, 104]
        
        result = generate_increment(5, start=1000)
        assert result == [1000, 1001, 1002, 1003, 1004]
    
    def test_increment_step_and_start(self):
        """Test increment with both step and start."""
        result = generate_increment(5, step=5, start=100)
        assert result == [100, 105, 110, 115, 120]
        
        result = generate_increment(3, step=10, start=50)
        assert result == [50, 60, 70]
    
    def test_increment_with_pattern(self):
        """Test increment with pattern."""
        result = generate_increment(3, pattern='EMP_[001]')
        assert result == ['EMP_001', 'EMP_002', 'EMP_003']
        
        result = generate_increment(3, pattern='ID_[0001]')
        assert result == ['ID_0001', 'ID_0002', 'ID_0003']
    
    def test_increment_pattern_with_step(self):
        """Test increment with pattern and step."""
        result = generate_increment(3, step=5, pattern='ID_[001]')
        assert result == ['ID_001', 'ID_006', 'ID_011']
        
        result = generate_increment(3, step=10, start=100, pattern='ID_[0001]')
        assert result == ['ID_0100', 'ID_0110', 'ID_0120']
    
    def test_increment_pattern_padding(self):
        """Test pattern padding with different widths."""
        # 3-digit padding
        result = generate_increment(3, pattern='EMP_[001]')
        assert result == ['EMP_001', 'EMP_002', 'EMP_003']
        
        # 4-digit padding
        result = generate_increment(3, pattern='ID_[0001]')
        assert result == ['ID_0001', 'ID_0002', 'ID_0003']
        
        # 5-digit padding
        result = generate_increment(3, pattern='USER_[00001]')
        assert result == ['USER_00001', 'USER_00002', 'USER_00003']
    
    def test_increment_pattern_overflow(self):
        """Test pattern with values exceeding padding width."""
        # Value 123 with 2-digit padding
        result = generate_increment(3, start=123, pattern='ID_[01]')
        assert result == ['ID_123', 'ID_124', 'ID_125']  # No truncation
    
    def test_increment_single_value(self):
        """Test generating single value."""
        result = generate_increment(1)
        assert result == [1]
        
        result = generate_increment(1, start=100, pattern='ID_[001]')
        assert result == ['ID_100']
    
    def test_increment_zero_values(self):
        """Test generating zero values."""
        result = generate_increment(0)
        assert result == []


class TestValidateIncrementStep:
    """Test validate_increment_step() function."""
    
    def test_valid_step_sizes(self):
        """Test valid step sizes."""
        is_valid, msg = validate_increment_step(10, 100)
        assert is_valid
        assert msg == ""
        
        is_valid, msg = validate_increment_step(50, 100)
        assert is_valid
        assert msg == ""
        
        is_valid, msg = validate_increment_step(1, 100)
        assert is_valid
        assert msg == ""
    
    def test_invalid_step_sizes(self):
        """Test invalid step sizes (> n/2)."""
        is_valid, msg = validate_increment_step(60, 100)
        assert not is_valid
        assert "Step size 60 exceeds n/2" in msg
        
        is_valid, msg = validate_increment_step(100, 100)
        assert not is_valid
        assert "Step size 100 exceeds n/2" in msg
    
    def test_edge_case_step_equals_half(self):
        """Test edge case where step equals n/2."""
        is_valid, msg = validate_increment_step(50, 100)
        assert is_valid
        
        # Just over n/2
        is_valid, msg = validate_increment_step(51, 100)
        assert not is_valid


class TestFormatWithPattern:
    """Test format_with_pattern() function."""
    
    def test_format_with_3_digit_padding(self):
        """Test formatting with 3-digit padding."""
        assert format_with_pattern(5, 'EMP_[001]') == 'EMP_005'
        assert format_with_pattern(123, 'EMP_[001]') == 'EMP_123'
        assert format_with_pattern(1, 'EMP_[001]') == 'EMP_001'
    
    def test_format_with_4_digit_padding(self):
        """Test formatting with 4-digit padding."""
        assert format_with_pattern(5, 'ID_[0001]') == 'ID_0005'
        assert format_with_pattern(123, 'ID_[0001]') == 'ID_0123'
        assert format_with_pattern(1, 'ID_[0001]') == 'ID_0001'
    
    def test_format_with_5_digit_padding(self):
        """Test formatting with 5-digit padding."""
        assert format_with_pattern(5, 'USER_[00001]') == 'USER_00005'
        assert format_with_pattern(12345, 'USER_[00001]') == 'USER_12345'
    
    def test_format_overflow(self):
        """Test formatting with value exceeding padding."""
        assert format_with_pattern(1234, 'ID_[01]') == 'ID_1234'
        assert format_with_pattern(12345, 'ID_[001]') == 'ID_12345'
    
    def test_format_no_placeholder(self):
        """Test formatting without valid placeholder."""
        assert format_with_pattern(5, 'EMP_') == 'EMP_5'
        assert format_with_pattern(123, 'ID') == 'ID123'


class TestIncrementIntegration:
    """Integration tests for increment strategy."""
    
    def test_parse_and_generate(self):
        """Test parsing strategy and generating values."""
        # Simple increment
        step, start, pattern = parse_increment_strategy('increment')
        result = generate_increment(5, step, start, pattern)
        assert result == [1, 2, 3, 4, 5]
        
        # With step
        step, start, pattern = parse_increment_strategy('increment[3]')
        result = generate_increment(5, step, start, pattern)
        assert result == [1, 4, 7, 10, 13]
        
        # With start
        step, start, pattern = parse_increment_strategy('increment:start=100')
        result = generate_increment(5, step, start, pattern)
        assert result == [100, 101, 102, 103, 104]
        
        # With pattern
        step, start, pattern = parse_increment_strategy('increment:pattern=EMP_[001]')
        result = generate_increment(3, step, start, pattern)
        assert result == ['EMP_001', 'EMP_002', 'EMP_003']
        
        # All parameters
        step, start, pattern = parse_increment_strategy('increment[5]:start=100:pattern=ID_[0001]')
        result = generate_increment(3, step, start, pattern)
        assert result == ['ID_0100', 'ID_0105', 'ID_0110']
    
    def test_validate_and_generate(self):
        """Test validation before generation."""
        n = 100
        step = 10
        
        # Validate
        is_valid, msg = validate_increment_step(step, n)
        assert is_valid
        
        # Generate
        result = generate_increment(n, step=step)
        assert len(result) == n
        assert result[0] == 1
        assert result[-1] == 1 + (n-1) * step


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
