"""
Tests for cardinality validation.

Tests validate_cardinality() and get_cardinality_type() functions.
"""

import pytest
import pandas as pd
import polars as pl
from additory.validation import validate_cardinality, get_cardinality_type


class TestCardinalityValidation:
    """Test cardinality validation for add.to() operations."""
    
    def test_one_to_one_lookup(self):
        """Test 1:1 relationship with lookup join type."""
        # Pandas
        df1 = pd.DataFrame({'id': [1, 2, 3], 'val': ['a', 'b', 'c']})
        df2 = pd.DataFrame({'id': [1, 2, 3], 'data': ['x', 'y', 'z']})
        
        is_valid, msg = validate_cardinality(df1, df2, 'id', 'lookup')
        assert is_valid
        assert msg == ""
        
        # Polars
        df1_pl = pl.DataFrame({'id': [1, 2, 3], 'val': ['a', 'b', 'c']})
        df2_pl = pl.DataFrame({'id': [1, 2, 3], 'data': ['x', 'y', 'z']})
        
        is_valid, msg = validate_cardinality(df1_pl, df2_pl, 'id', 'lookup')
        assert is_valid
        assert msg == ""
    
    def test_one_to_many_lookup(self):
        """Test 1:many relationship with lookup join type (valid)."""
        # Pandas - target has unique keys, source has duplicates
        df1 = pd.DataFrame({'id': [1, 2, 3], 'val': ['a', 'b', 'c']})
        df2 = pd.DataFrame({'id': [1, 1, 2, 2, 3], 'data': ['x1', 'x2', 'y1', 'y2', 'z']})
        
        is_valid, msg = validate_cardinality(df1, df2, 'id', 'lookup')
        assert is_valid
        assert msg == ""
        
        # Polars
        df1_pl = pl.DataFrame({'id': [1, 2, 3], 'val': ['a', 'b', 'c']})
        df2_pl = pl.DataFrame({'id': [1, 1, 2, 2, 3], 'data': ['x1', 'x2', 'y1', 'y2', 'z']})
        
        is_valid, msg = validate_cardinality(df1_pl, df2_pl, 'id', 'lookup')
        assert is_valid
        assert msg == ""
    
    def test_many_to_one_lookup(self):
        """Test many:1 relationship with lookup join type (valid)."""
        # Pandas - target has duplicates, source has unique keys
        df1 = pd.DataFrame({'id': [1, 1, 2, 2, 3], 'val': ['a1', 'a2', 'b1', 'b2', 'c']})
        df2 = pd.DataFrame({'id': [1, 2, 3], 'data': ['x', 'y', 'z']})
        
        is_valid, msg = validate_cardinality(df1, df2, 'id', 'lookup')
        assert is_valid
        assert msg == ""
        
        # Polars
        df1_pl = pl.DataFrame({'id': [1, 1, 2, 2, 3], 'val': ['a1', 'a2', 'b1', 'b2', 'c']})
        df2_pl = pl.DataFrame({'id': [1, 2, 3], 'data': ['x', 'y', 'z']})
        
        is_valid, msg = validate_cardinality(df1_pl, df2_pl, 'id', 'lookup')
        assert is_valid
        assert msg == ""
    
    def test_many_to_many_lookup_invalid(self):
        """Test many:many relationship with lookup join type (invalid)."""
        # Pandas - both have duplicates
        df1 = pd.DataFrame({'id': [1, 1, 2, 2], 'val': ['a1', 'a2', 'b1', 'b2']})
        df2 = pd.DataFrame({'id': [1, 1, 2, 2], 'data': ['x1', 'x2', 'y1', 'y2']})
        
        is_valid, msg = validate_cardinality(df1, df2, 'id', 'lookup')
        assert not is_valid
        assert "Many:many relationship detected" in msg
        assert "add.to() requires 1:many or many:1 relationships" in msg
        
        # Polars
        df1_pl = pl.DataFrame({'id': [1, 1, 2, 2], 'val': ['a1', 'a2', 'b1', 'b2']})
        df2_pl = pl.DataFrame({'id': [1, 1, 2, 2], 'data': ['x1', 'x2', 'y1', 'y2']})
        
        is_valid, msg = validate_cardinality(df1_pl, df2_pl, 'id', 'lookup')
        assert not is_valid
        assert "Many:many relationship detected" in msg
    
    def test_one_to_one_explicit_join(self):
        """Test 1:1 relationship with explicit join type (valid)."""
        # Pandas
        df1 = pd.DataFrame({'id': [1, 2, 3], 'val': ['a', 'b', 'c']})
        df2 = pd.DataFrame({'id': [1, 2, 3], 'data': ['x', 'y', 'z']})
        
        for join_type in ['left', 'inner', 'outer']:
            is_valid, msg = validate_cardinality(df1, df2, 'id', join_type)
            assert is_valid, f"Failed for join_type={join_type}"
            assert msg == ""
    
    def test_one_to_many_explicit_join_invalid(self):
        """Test 1:many relationship with explicit join type (invalid)."""
        # Pandas - target has unique keys, source has duplicates
        df1 = pd.DataFrame({'id': [1, 2, 3], 'val': ['a', 'b', 'c']})
        df2 = pd.DataFrame({'id': [1, 1, 2, 2, 3], 'data': ['x1', 'x2', 'y1', 'y2', 'z']})
        
        for join_type in ['left', 'inner', 'outer']:
            is_valid, msg = validate_cardinality(df1, df2, 'id', join_type)
            assert not is_valid, f"Should fail for join_type={join_type}"
            assert f"join_type='{join_type}' requires 1:1 relationship" in msg
            assert "1:many relationship" in msg
    
    def test_many_to_one_explicit_join_invalid(self):
        """Test many:1 relationship with explicit join type (invalid)."""
        # Pandas - target has duplicates, source has unique keys
        df1 = pd.DataFrame({'id': [1, 1, 2, 2, 3], 'val': ['a1', 'a2', 'b1', 'b2', 'c']})
        df2 = pd.DataFrame({'id': [1, 2, 3], 'data': ['x', 'y', 'z']})
        
        for join_type in ['left', 'inner', 'outer']:
            is_valid, msg = validate_cardinality(df1, df2, 'id', join_type)
            assert not is_valid, f"Should fail for join_type={join_type}"
            assert f"join_type='{join_type}' requires 1:1 relationship" in msg
            assert "many:1 relationship" in msg
    
    def test_multiple_keys_tuple(self):
        """Test cardinality validation with multiple keys (tuple)."""
        # Pandas - 1:1 on composite key
        df1 = pd.DataFrame({
            'id': [1, 1, 2],
            'date': ['2024-01-01', '2024-01-02', '2024-01-01'],
            'val': ['a', 'b', 'c']
        })
        df2 = pd.DataFrame({
            'id': [1, 1, 2],
            'date': ['2024-01-01', '2024-01-02', '2024-01-01'],
            'data': ['x', 'y', 'z']
        })
        
        is_valid, msg = validate_cardinality(df1, df2, ('id', 'date'), 'lookup')
        assert is_valid
        assert msg == ""
        
        # Polars
        df1_pl = pl.DataFrame({
            'id': [1, 1, 2],
            'date': ['2024-01-01', '2024-01-02', '2024-01-01'],
            'val': ['a', 'b', 'c']
        })
        df2_pl = pl.DataFrame({
            'id': [1, 1, 2],
            'date': ['2024-01-01', '2024-01-02', '2024-01-01'],
            'data': ['x', 'y', 'z']
        })
        
        is_valid, msg = validate_cardinality(df1_pl, df2_pl, ('id', 'date'), 'lookup')
        assert is_valid
        assert msg == ""
    
    def test_multiple_keys_many_to_many(self):
        """Test many:many with multiple keys (invalid)."""
        # Pandas - duplicates on composite key
        df1 = pd.DataFrame({
            'id': [1, 1, 1],
            'date': ['2024-01-01', '2024-01-01', '2024-01-02'],
            'val': ['a1', 'a2', 'b']
        })
        df2 = pd.DataFrame({
            'id': [1, 1, 1],
            'date': ['2024-01-01', '2024-01-01', '2024-01-02'],
            'data': ['x1', 'x2', 'y']
        })
        
        is_valid, msg = validate_cardinality(df1, df2, ('id', 'date'), 'lookup')
        assert not is_valid
        assert "Many:many relationship detected" in msg


class TestGetCardinalityType:
    """Test get_cardinality_type() function."""
    
    def test_one_to_one(self):
        """Test 1:1 cardinality detection."""
        df1 = pd.DataFrame({'id': [1, 2, 3], 'val': ['a', 'b', 'c']})
        df2 = pd.DataFrame({'id': [1, 2, 3], 'data': ['x', 'y', 'z']})
        
        cardinality = get_cardinality_type(df1, df2, 'id')
        assert cardinality == '1:1'
    
    def test_one_to_many(self):
        """Test 1:many cardinality detection."""
        df1 = pd.DataFrame({'id': [1, 2, 3], 'val': ['a', 'b', 'c']})
        df2 = pd.DataFrame({'id': [1, 1, 2, 2, 3], 'data': ['x1', 'x2', 'y1', 'y2', 'z']})
        
        cardinality = get_cardinality_type(df1, df2, 'id')
        assert cardinality == '1:many'
    
    def test_many_to_one(self):
        """Test many:1 cardinality detection."""
        df1 = pd.DataFrame({'id': [1, 1, 2, 2, 3], 'val': ['a1', 'a2', 'b1', 'b2', 'c']})
        df2 = pd.DataFrame({'id': [1, 2, 3], 'data': ['x', 'y', 'z']})
        
        cardinality = get_cardinality_type(df1, df2, 'id')
        assert cardinality == 'many:1'
    
    def test_many_to_many(self):
        """Test many:many cardinality detection."""
        df1 = pd.DataFrame({'id': [1, 1, 2, 2], 'val': ['a1', 'a2', 'b1', 'b2']})
        df2 = pd.DataFrame({'id': [1, 1, 2, 2], 'data': ['x1', 'x2', 'y1', 'y2']})
        
        cardinality = get_cardinality_type(df1, df2, 'id')
        assert cardinality == 'many:many'
    
    def test_multiple_keys(self):
        """Test cardinality detection with multiple keys."""
        df1 = pd.DataFrame({
            'id': [1, 1, 2],
            'date': ['2024-01-01', '2024-01-02', '2024-01-01'],
            'val': ['a', 'b', 'c']
        })
        df2 = pd.DataFrame({
            'id': [1, 1, 2],
            'date': ['2024-01-01', '2024-01-02', '2024-01-01'],
            'data': ['x', 'y', 'z']
        })
        
        cardinality = get_cardinality_type(df1, df2, ('id', 'date'))
        assert cardinality == '1:1'


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
