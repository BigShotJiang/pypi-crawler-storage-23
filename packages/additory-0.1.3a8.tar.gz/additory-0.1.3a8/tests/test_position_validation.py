"""
Tests for position validation.

Tests validate_position(), validate_string_position(), and normalize_position() functions.
"""

import pytest
import pandas as pd
import polars as pl
from additory.validation import (
    validate_position,
    validate_string_position,
    normalize_position
)


class TestValidatePosition:
    """Test validate_position() function."""
    
    def test_none_position(self):
        """Test None position (valid - means append to end)."""
        is_valid, msg = validate_position(None, 5)
        assert is_valid
        assert msg == ""
    
    def test_string_position(self):
        """Test string positions (valid - validated at runtime)."""
        for pos in ['after:id', 'before:name', 'start', 'end']:
            is_valid, msg = validate_position(pos, 5)
            assert is_valid, f"Failed for position={pos}"
            assert msg == ""
    
    def test_valid_positive_indices(self):
        """Test valid positive indices."""
        n_columns = 5
        for pos in [0, 1, 2, 3, 4]:
            is_valid, msg = validate_position(pos, n_columns)
            assert is_valid, f"Failed for position={pos}"
            assert msg == ""
    
    def test_invalid_positive_indices(self):
        """Test invalid positive indices (>= n_columns)."""
        n_columns = 5
        for pos in [5, 6, 10, 100]:
            is_valid, msg = validate_position(pos, n_columns)
            assert not is_valid, f"Should fail for position={pos}"
            assert f"Invalid position index {pos}" in msg
            assert "Valid range: 0 to 4" in msg
    
    def test_valid_negative_indices(self):
        """Test valid negative indices."""
        n_columns = 5
        for pos in [-1, -2, -3, -4]:
            is_valid, msg = validate_position(pos, n_columns)
            assert is_valid, f"Failed for position={pos}"
            assert msg == ""
    
    def test_invalid_negative_indices(self):
        """Test invalid negative indices (< -(n_columns-1))."""
        n_columns = 5
        for pos in [-5, -6, -10, -100]:
            is_valid, msg = validate_position(pos, n_columns)
            assert not is_valid, f"Should fail for position={pos}"
            assert f"Invalid position index {pos}" in msg
            assert "Valid range: 0 to 4" in msg
    
    def test_invalid_type(self):
        """Test invalid position type."""
        for pos in [1.5, [], {}, True]:
            is_valid, msg = validate_position(pos, 5)
            assert not is_valid
            assert "Position must be int, str, or None" in msg
    
    def test_edge_cases(self):
        """Test edge cases."""
        # Single column DataFrame
        is_valid, msg = validate_position(0, 1)
        assert is_valid
        
        is_valid, msg = validate_position(1, 1)
        assert not is_valid
        
        is_valid, msg = validate_position(-1, 1)
        assert not is_valid  # -1 is invalid for single column (range is 0 to 0)


class TestValidateStringPosition:
    """Test validate_string_position() function."""
    
    def test_special_keywords(self):
        """Test special keyword positions."""
        df = pd.DataFrame({'a': [1, 2], 'b': [3, 4]})
        
        for pos in ['start', 'end']:
            is_valid, msg = validate_string_position(pos, df)
            assert is_valid, f"Failed for position={pos}"
            assert msg == ""
    
    def test_after_valid_column(self):
        """Test after:col with valid column."""
        df = pd.DataFrame({'id': [1, 2], 'name': ['a', 'b'], 'age': [25, 30]})
        
        for col in ['id', 'name', 'age']:
            is_valid, msg = validate_string_position(f'after:{col}', df)
            assert is_valid, f"Failed for after:{col}"
            assert msg == ""
    
    def test_before_valid_column(self):
        """Test before:col with valid column."""
        df = pd.DataFrame({'id': [1, 2], 'name': ['a', 'b'], 'age': [25, 30]})
        
        for col in ['id', 'name', 'age']:
            is_valid, msg = validate_string_position(f'before:{col}', df)
            assert is_valid, f"Failed for before:{col}"
            assert msg == ""
    
    def test_after_invalid_column(self):
        """Test after:col with invalid column."""
        df = pd.DataFrame({'id': [1, 2], 'name': ['a', 'b']})
        
        is_valid, msg = validate_string_position('after:nonexistent', df)
        assert not is_valid
        assert "Column 'nonexistent' not found" in msg
        assert "Available columns:" in msg
    
    def test_before_invalid_column(self):
        """Test before:col with invalid column."""
        df = pd.DataFrame({'id': [1, 2], 'name': ['a', 'b']})
        
        is_valid, msg = validate_string_position('before:nonexistent', df)
        assert not is_valid
        assert "Column 'nonexistent' not found" in msg
    
    def test_invalid_directive(self):
        """Test invalid directive (not after/before)."""
        df = pd.DataFrame({'id': [1, 2], 'name': ['a', 'b']})
        
        is_valid, msg = validate_string_position('invalid:id', df)
        assert not is_valid
        assert "Invalid position directive: 'invalid'" in msg
        assert "Expected 'after' or 'before'" in msg
    
    def test_invalid_format(self):
        """Test invalid string format."""
        df = pd.DataFrame({'id': [1, 2], 'name': ['a', 'b']})
        
        is_valid, msg = validate_string_position('invalid_format', df)
        assert not is_valid
        assert "Invalid position format" in msg
    
    def test_non_string_position(self):
        """Test non-string position (should return valid)."""
        df = pd.DataFrame({'id': [1, 2], 'name': ['a', 'b']})
        
        for pos in [0, 1, None]:
            is_valid, msg = validate_string_position(pos, df)
            assert is_valid
            assert msg == ""
    
    def test_polars_dataframe(self):
        """Test with Polars DataFrame."""
        df = pl.DataFrame({'id': [1, 2], 'name': ['a', 'b'], 'age': [25, 30]})
        
        is_valid, msg = validate_string_position('after:id', df)
        assert is_valid
        
        is_valid, msg = validate_string_position('after:nonexistent', df)
        assert not is_valid
        assert "Column 'nonexistent' not found" in msg


class TestNormalizePosition:
    """Test normalize_position() function."""
    
    def test_none_position(self):
        """Test None position (becomes end)."""
        result = normalize_position(None, 5)
        assert result == 5
    
    def test_string_position(self):
        """Test string positions (stay as strings)."""
        for pos in ['after:id', 'before:name', 'start', 'end']:
            result = normalize_position(pos, 5)
            assert result == pos
    
    def test_positive_indices(self):
        """Test positive indices (stay the same)."""
        n_columns = 5
        for pos in [0, 1, 2, 3, 4]:
            result = normalize_position(pos, n_columns)
            assert result == pos
    
    def test_negative_indices(self):
        """Test negative indices (converted to positive)."""
        n_columns = 5
        
        # -1 → 5 (end)
        assert normalize_position(-1, n_columns) == 5
        
        # -2 → 4
        assert normalize_position(-2, n_columns) == 4
        
        # -3 → 3
        assert normalize_position(-3, n_columns) == 3
        
        # -4 → 2
        assert normalize_position(-4, n_columns) == 2
    
    def test_edge_cases(self):
        """Test edge cases."""
        # Single column
        assert normalize_position(0, 1) == 0
        assert normalize_position(None, 1) == 1
        
        # Large DataFrame
        assert normalize_position(-1, 100) == 100
        assert normalize_position(-10, 100) == 91
        assert normalize_position(50, 100) == 50


class TestPositionValidationIntegration:
    """Integration tests for position validation."""
    
    def test_validate_then_normalize(self):
        """Test validation followed by normalization."""
        n_columns = 5
        
        # Valid positive
        is_valid, msg = validate_position(2, n_columns)
        assert is_valid
        normalized = normalize_position(2, n_columns)
        assert normalized == 2
        
        # Valid negative
        is_valid, msg = validate_position(-2, n_columns)
        assert is_valid
        normalized = normalize_position(-2, n_columns)
        assert normalized == 4
        
        # Invalid positive
        is_valid, msg = validate_position(5, n_columns)
        assert not is_valid
        # Don't normalize invalid positions
        
        # String position
        df = pd.DataFrame({'id': [1], 'name': ['a'], 'age': [25]})
        is_valid, msg = validate_string_position('after:id', df)
        assert is_valid
        normalized = normalize_position('after:id', n_columns)
        assert normalized == 'after:id'
    
    def test_full_workflow(self):
        """Test full validation workflow."""
        df = pd.DataFrame({
            'id': [1, 2, 3],
            'name': ['a', 'b', 'c'],
            'age': [25, 30, 35]
        })
        n_columns = len(df.columns)
        
        # Test various positions
        test_cases = [
            (None, True, 3),
            (0, True, 0),
            (2, True, 2),
            (-1, True, 3),
            (-2, True, 2),
            ('start', True, 'start'),
            ('end', True, 'end'),
            ('after:id', True, 'after:id'),
            (10, False, None),
            (-10, False, None),
        ]
        
        for pos, should_be_valid, expected_normalized in test_cases:
            # Validate numeric/None positions
            if not isinstance(pos, str):
                is_valid, msg = validate_position(pos, n_columns)
                assert is_valid == should_be_valid, f"Failed for position={pos}"
                
                if is_valid:
                    normalized = normalize_position(pos, n_columns)
                    assert normalized == expected_normalized
            else:
                # Validate string positions
                is_valid, msg = validate_string_position(pos, df)
                assert is_valid == should_be_valid, f"Failed for position={pos}"
                
                if is_valid:
                    normalized = normalize_position(pos, n_columns)
                    assert normalized == expected_normalized


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
