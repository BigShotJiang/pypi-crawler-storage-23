"""
Tests for mode parsing (v0.1.3a5)

Tests the simplified mode syntax:
- Simple mode: 'first', 'sum', 'concat'
- Mode with match: 'first:anycase', 'first:trim'
- Concat with separator: 'concat[,]', 'concat[\n]', 'concat[;]'
"""

import pytest
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from additory.core.mode_parser import parse_mode, validate_mode, parse_strategy_value


class TestParseMode:
    """Test parse_mode() function"""
    
    def test_simple_mode(self):
        """Test simple mode parsing"""
        mode, match, separator = parse_mode('first')
        assert mode == 'first'
        assert match == 'auto'
        assert separator is None
    
    def test_mode_with_match(self):
        """Test mode:match parsing"""
        mode, match, separator = parse_mode('first:anycase')
        assert mode == 'first'
        assert match == 'anycase'
        assert separator is None
    
    def test_concat_default(self):
        """Test concat without separator (default pipe)"""
        mode, match, separator = parse_mode('concat')
        assert mode == 'concat'
        assert match == 'auto'
        assert separator == '|'
    
    def test_concat_pipe(self):
        """Test concat with explicit pipe"""
        mode, match, separator = parse_mode('concat[|]')
        assert mode == 'concat'
        assert match == 'auto'
        assert separator == '|'
    
    def test_concat_comma(self):
        """Test concat with comma"""
        mode, match, separator = parse_mode('concat[,]')
        assert mode == 'concat'
        assert match == 'auto'
        assert separator == ','
    
    def test_concat_newline(self):
        """Test concat with newline"""
        mode, match, separator = parse_mode('concat[\\n]')
        assert mode == 'concat'
        assert match == 'auto'
        assert separator == '\n'
    
    def test_concat_tab(self):
        """Test concat with tab"""
        mode, match, separator = parse_mode('concat[\\t]')
        assert mode == 'concat'
        assert match == 'auto'
        assert separator == '\t'
    
    def test_concat_semicolon(self):
        """Test concat with semicolon"""
        mode, match, separator = parse_mode('concat[;]')
        assert mode == 'concat'
        assert match == 'auto'
        assert separator == ';'
    
    def test_concat_space(self):
        """Test concat with space"""
        mode, match, separator = parse_mode('concat[ ]')
        assert mode == 'concat'
        assert match == 'auto'
        assert separator == ' '
    
    def test_all_basic_modes(self):
        """Test all basic modes"""
        basic_modes = [
            'auto', 'strict', 'first', 'last', 'shortest', 'longest',
            'most_common', 'forward_fill', 'backward_fill'
        ]
        for mode_str in basic_modes:
            mode, match, separator = parse_mode(mode_str)
            assert mode == mode_str
            assert match == 'auto'
            assert separator is None
    
    def test_all_numeric_modes(self):
        """Test all numeric modes"""
        numeric_modes = ['sum', 'count', 'average', 'min', 'max']
        for mode_str in numeric_modes:
            mode, match, separator = parse_mode(mode_str)
            assert mode == mode_str
            assert match == 'auto'
            assert separator is None
    
    def test_all_match_modifiers(self):
        """Test all match modifiers"""
        match_modifiers = ['auto', 'anycase', 'fuzzy', 'enforce_case', 'trim']
        for match_mod in match_modifiers:
            mode, match, separator = parse_mode(f'first:{match_mod}')
            assert mode == 'first'
            assert match == match_mod
            assert separator is None
    
    def test_empty_string(self):
        """Test empty string raises error"""
        with pytest.raises(ValueError, match="Mode string cannot be empty"):
            parse_mode('')
    
    def test_non_string_input(self):
        """Test non-string input raises error"""
        with pytest.raises(TypeError, match="Mode must be string"):
            parse_mode(123)
    
    def test_empty_mode_before_colon(self):
        """Test empty mode before colon raises error"""
        with pytest.raises(ValueError, match="Mode cannot be empty before ':'"):
            parse_mode(':anycase')
    
    def test_empty_match_after_colon(self):
        """Test empty match after colon raises error"""
        with pytest.raises(ValueError, match="Match modifier cannot be empty after ':'"):
            parse_mode('first:')
    
    def test_multiple_colons(self):
        """Test multiple colons (only first is used)"""
        mode, match, separator = parse_mode('first:any:case')
        assert mode == 'first'
        assert match == 'any:case'  # Everything after first colon
        assert separator is None


class TestValidateMode:
    """Test validate_mode() function"""
    
    def test_valid_basic_modes(self):
        """Test all valid basic modes"""
        basic_modes = [
            'auto', 'strict', 'first', 'last', 'shortest', 'longest',
            'most_common', 'forward_fill', 'backward_fill'
        ]
        for mode in basic_modes:
            assert validate_mode(mode) is True
    
    def test_valid_numeric_modes(self):
        """Test all valid numeric modes"""
        numeric_modes = ['sum', 'count', 'average', 'min', 'max']
        for mode in numeric_modes:
            assert validate_mode(mode) is True
    
    def test_valid_concat_mode(self):
        """Test concat mode"""
        assert validate_mode('concat') is True
    
    def test_valid_match_modifiers(self):
        """Test all valid match modifiers"""
        match_modifiers = ['auto', 'anycase', 'fuzzy', 'enforce_case', 'trim']
        for match in match_modifiers:
            assert validate_mode('first', match) is True
    
    def test_invalid_mode(self):
        """Test invalid mode raises error"""
        with pytest.raises(ValueError, match="Invalid mode 'invalid'"):
            validate_mode('invalid')
    
    def test_invalid_match(self):
        """Test invalid match modifier raises error"""
        with pytest.raises(ValueError, match="Invalid match modifier 'invalid'"):
            validate_mode('first', 'invalid')


class TestParseStrategyValue:
    """Test parse_strategy_value() function"""
    
    def test_simple_string(self):
        """Test simple string strategy"""
        result = parse_strategy_value('first')
        assert result['mode'] == 'first'
        assert result['match'] == 'auto'
        assert result['separator'] is None
    
    def test_string_with_match(self):
        """Test string with match modifier"""
        result = parse_strategy_value('first:anycase')
        assert result['mode'] == 'first'
        assert result['match'] == 'anycase'
        assert result['separator'] is None
    
    def test_concat_string(self):
        """Test concat string"""
        result = parse_strategy_value('concat[,]')
        assert result['mode'] == 'concat'
        assert result['match'] == 'auto'
        assert result['separator'] == ','
    
    def test_dict_with_mode(self):
        """Test dict with mode"""
        result = parse_strategy_value({
            'mode': 'first:anycase',
            'position': 'after:id'
        })
        assert result['mode'] == 'first'
        assert result['match'] == 'anycase'
        assert result['separator'] is None
        assert result['position'] == 'after:id'
    
    def test_dict_without_mode(self):
        """Test dict without mode raises error"""
        with pytest.raises(ValueError, match="Strategy dict must contain 'mode' key"):
            parse_strategy_value({'position': 'after:id'})
    
    def test_invalid_type(self):
        """Test invalid type raises error"""
        with pytest.raises(TypeError, match="Strategy value must be string or dict"):
            parse_strategy_value(123)


class TestEdgeCases:
    """Test edge cases and special scenarios"""
    
    def test_concat_with_special_chars(self):
        """Test concat with special characters"""
        # Pipe
        mode, match, sep = parse_mode('concat[|]')
        assert sep == '|'
        
        # Comma
        mode, match, sep = parse_mode('concat[,]')
        assert sep == ','
        
        # Semicolon
        mode, match, sep = parse_mode('concat[;]')
        assert sep == ';'
        
        # Space
        mode, match, sep = parse_mode('concat[ ]')
        assert sep == ' '
    
    def test_concat_with_escape_sequences(self):
        """Test concat with escape sequences"""
        # Newline
        mode, match, sep = parse_mode('concat[\\n]')
        assert sep == '\n'
        
        # Tab
        mode, match, sep = parse_mode('concat[\\t]')
        assert sep == '\t'
        
        # Carriage return
        mode, match, sep = parse_mode('concat[\\r]')
        assert sep == '\r'
    
    def test_mode_with_colon_in_name(self):
        """Test that colon in column name doesn't interfere"""
        # This is handled by having column names as dict keys (strings)
        # and mode as dict values, so no confusion
        pass
    
    def test_case_sensitivity(self):
        """Test that modes are case-sensitive"""
        # 'First' is not the same as 'first'
        with pytest.raises(ValueError, match="Invalid mode 'First'"):
            validate_mode('First')


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

