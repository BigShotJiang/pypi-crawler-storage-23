"""
Integration tests for v0.1.3a5 API

Tests the updated API with new parsing:
- Positional parameters
- Flexible input formats
- Mode:match syntax
"""

import pytest
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the parsing functions directly (API functions require Rust bindings)
from additory.core.param_handler import (
    normalize_column_input,
    normalize_key_input,
    normalize_by_input,
    normalize_expression_input,
    normalize_as_input,
)
from additory.core.mode_parser import parse_strategy_value


class TestAPIParameterNormalization:
    """Test that API parameter normalization works correctly"""
    
    def test_to_single_column_string(self):
        """Test add.to() with single column as string"""
        fetch = normalize_column_input('name')
        assert fetch == 'name'
    
    def test_to_single_column_list(self):
        """Test add.to() with single column as list"""
        fetch = normalize_column_input(['name'])
        assert fetch == 'name'
    
    def test_to_multiple_columns(self):
        """Test add.to() with multiple columns"""
        fetch = normalize_column_input(['name', 'city'])
        assert fetch == ['name', 'city']
    
    def test_to_single_key_string(self):
        """Test add.to() with single key as string"""
        against = normalize_key_input('customer_id')
        assert against == 'customer_id'
    
    def test_to_single_key_list(self):
        """Test add.to() with single key as list"""
        against = normalize_key_input(['customer_id'])
        assert against == 'customer_id'
    
    def test_to_multiple_keys(self):
        """Test add.to() with multiple keys"""
        against = normalize_key_input(('customer_id', 'date'))
        assert against == ('customer_id', 'date')
    
    def test_transform_sort_single(self):
        """Test add.transform('@sort') with single column"""
        by = normalize_by_input('age')
        assert by == 'age'
    
    def test_transform_sort_multiple(self):
        """Test add.transform('@sort') with multiple columns"""
        by = normalize_by_input(('salary', 'age'))
        assert by == ('salary', 'age')
    
    def test_transform_calc_single_expression(self):
        """Test add.transform('@calc') with single expression"""
        expr = normalize_expression_input('price * quantity')
        assert expr == 'price * quantity'
    
    def test_transform_calc_multiple_expressions(self):
        """Test add.transform('@calc') with multiple expressions"""
        expr = normalize_expression_input(['a + b', 'a * b'])
        assert expr == ['a + b', 'a * b']


class TestAPIStrategyParsing:
    """Test that API strategy parsing works correctly"""
    
    def test_strategy_simple_string(self):
        """Test strategy as simple string"""
        strategy = parse_strategy_value('first')
        assert strategy['mode'] == 'first'
        assert strategy['match'] == 'auto'
    
    def test_strategy_mode_with_match(self):
        """Test strategy with mode:match"""
        strategy = parse_strategy_value('first:anycase')
        assert strategy['mode'] == 'first'
        assert strategy['match'] == 'anycase'
    
    def test_strategy_concat_with_separator(self):
        """Test strategy with concat[sep]"""
        strategy = parse_strategy_value('concat[,]')
        assert strategy['mode'] == 'concat'
        assert strategy['separator'] == ','
    
    def test_strategy_dict_with_mode(self):
        """Test strategy as dict with mode"""
        strategy = parse_strategy_value({
            'mode': 'first:anycase',
            'position': 'after:id'
        })
        assert strategy['mode'] == 'first'
        assert strategy['match'] == 'anycase'
        assert strategy['position'] == 'after:id'


class TestAPISignatures:
    """Test that API signatures match specifications"""
    
    def test_to_signature(self):
        """Test add.to() signature"""
        import additory as add
        import inspect
        
        sig = inspect.signature(add.to)
        params = list(sig.parameters.keys())
        
        # Check required positional parameters
        assert 'fetch_to' in params
        assert 'fetch_from' in params
        assert 'fetch' in params
        assert 'against' in params
        
        # Check optional parameters
        assert 'position' in params
        assert 'strategy' in params
        assert 'join_type' in params
        assert 'as_type' in params
        
        # Check defaults
        assert sig.parameters['position'].default is None
        assert sig.parameters['strategy'].default is None
        assert sig.parameters['join_type'].default == 'lookup'
        assert sig.parameters['as_type'].default is None
    
    def test_transform_signature(self):
        """Test add.transform() signature"""
        import additory as add
        import inspect
        
        sig = inspect.signature(add.transform)
        params = list(sig.parameters.keys())
        
        # Check required positional parameters
        assert 'mode' in params
        assert 'df' in params
        
        # Check optional parameters
        assert 'fetch' in params
        assert 'by' in params
        assert 'expression' in params
        assert 'where' in params
        assert 'as_' in params
        assert 'fetch_at' in params
        assert 'strategy' in params
        assert 'logging' in params
        
        # Check defaults
        assert sig.parameters['fetch'].default is None
        assert sig.parameters['by'].default is None
        assert sig.parameters['expression'].default is None
        assert sig.parameters['where'].default is None
        assert sig.parameters['as_'].default is None
        assert sig.parameters['fetch_at'].default == 'end'
        assert sig.parameters['strategy'].default is None
        assert sig.parameters['logging'].default is False


class TestAPIUsageExamples:
    """Test realistic API usage examples"""
    
    def test_to_positional_basic(self):
        """Test add.to() with positional parameters"""
        # Simulate: add.to(df, ref_df, 'name', 'customer_id')
        fetch = normalize_column_input('name')
        against = normalize_key_input('customer_id')
        
        assert fetch == 'name'
        assert against == 'customer_id'
    
    def test_to_positional_multiple_columns(self):
        """Test add.to() with multiple columns positionally"""
        # Simulate: add.to(df, ref_df, ['name', 'city'], 'customer_id')
        fetch = normalize_column_input(['name', 'city'])
        against = normalize_key_input('customer_id')
        
        assert fetch == ['name', 'city']
        assert against == 'customer_id'
    
    def test_to_positional_multiple_keys(self):
        """Test add.to() with multiple keys positionally"""
        # Simulate: add.to(df, ref_df, 'amount', ('customer_id', 'date'))
        fetch = normalize_column_input('amount')
        against = normalize_key_input(('customer_id', 'date'))
        
        assert fetch == 'amount'
        assert against == ('customer_id', 'date')
    
    def test_transform_calc_positional(self):
        """Test add.transform('@calc') with positional parameters"""
        # Simulate: add.transform('@calc', df, expression='a + b', as_='sum')
        expr = normalize_expression_input('a + b')
        as_val = normalize_as_input('sum')
        
        assert expr == 'a + b'
        assert as_val == 'sum'
    
    def test_transform_sort_positional(self):
        """Test add.transform('@sort') with positional parameters"""
        # Simulate: add.transform('@sort', df, by='date', as_='desc')
        by = normalize_by_input('date')
        as_val = normalize_as_input('desc')
        
        assert by == 'date'
        assert as_val == 'desc'


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
