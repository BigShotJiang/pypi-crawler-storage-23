"""
Tests for parameter handler (v0.1.3a5)

Tests flexible input formats:
- Single column: 'col' or ['col'] (both work)
- Multiple columns: ['col1', 'col2'] (list required)
- Single key: 'key' or ['key'] (both work)
- Multiple keys: ('key1', 'key2') (tuple required)
"""

import pytest
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from additory.core.param_handler import (
    normalize_column_input,
    normalize_key_input,
    normalize_by_input,
    normalize_expression_input,
    normalize_as_input,
    validate_expression_as_match,
)


class TestNormalizeColumnInput:
    """Test normalize_column_input() function"""
    
    def test_single_column_string(self):
        """Test single column as string"""
        result = normalize_column_input('name')
        assert result == 'name'
    
    def test_single_column_list(self):
        """Test single column as list (converted to string)"""
        result = normalize_column_input(['name'])
        assert result == 'name'
    
    def test_multiple_columns_list(self):
        """Test multiple columns as list"""
        result = normalize_column_input(['name', 'city'])
        assert result == ['name', 'city']
    
    def test_none_input(self):
        """Test None input"""
        result = normalize_column_input(None)
        assert result is None
    
    def test_empty_list(self):
        """Test empty list raises error"""
        with pytest.raises(ValueError, match="Column list cannot be empty"):
            normalize_column_input([])
    
    def test_invalid_type(self):
        """Test invalid type raises error"""
        with pytest.raises(TypeError, match="Column input must be string or list"):
            normalize_column_input(123)


class TestNormalizeKeyInput:
    """Test normalize_key_input() function"""
    
    def test_single_key_string(self):
        """Test single key as string"""
        result = normalize_key_input('customer_id')
        assert result == 'customer_id'
    
    def test_single_key_list(self):
        """Test single key as list (converted to string)"""
        result = normalize_key_input(['customer_id'])
        assert result == 'customer_id'
    
    def test_multiple_keys_tuple(self):
        """Test multiple keys as tuple"""
        result = normalize_key_input(('customer_id', 'date'))
        assert result == ('customer_id', 'date')
    
    def test_multiple_keys_list_error(self):
        """Test multiple keys as list raises error"""
        with pytest.raises(ValueError, match="Multiple keys must be tuple, not list"):
            normalize_key_input(['customer_id', 'date'])
    
    def test_none_input(self):
        """Test None input"""
        result = normalize_key_input(None)
        assert result is None
    
    def test_empty_list(self):
        """Test empty list raises error"""
        with pytest.raises(ValueError, match="Key list cannot be empty"):
            normalize_key_input([])
    
    def test_empty_tuple(self):
        """Test empty tuple raises error"""
        with pytest.raises(ValueError, match="Key tuple cannot be empty"):
            normalize_key_input(())
    
    def test_invalid_type(self):
        """Test invalid type raises error"""
        with pytest.raises(TypeError, match="Key input must be string, list, or tuple"):
            normalize_key_input(123)


class TestNormalizeByInput:
    """Test normalize_by_input() function"""
    
    def test_single_column_string(self):
        """Test single column as string"""
        result = normalize_by_input('age')
        assert result == 'age'
    
    def test_single_column_list_error(self):
        """Test single column as list raises error"""
        with pytest.raises(ValueError, match="by parameter does not accept lists"):
            normalize_by_input(['age'])
    
    def test_multiple_columns_tuple(self):
        """Test multiple columns as tuple"""
        result = normalize_by_input(('salary', 'age'))
        assert result == ('salary', 'age')
    
    def test_multiple_columns_list_error(self):
        """Test multiple columns as list raises error"""
        with pytest.raises(ValueError, match="by parameter does not accept lists"):
            normalize_by_input(['salary', 'age'])


class TestNormalizeExpressionInput:
    """Test normalize_expression_input() function"""
    
    def test_single_expression_string(self):
        """Test single expression as string"""
        result = normalize_expression_input('price * quantity')
        assert result == 'price * quantity'
    
    def test_multiple_expressions_list(self):
        """Test multiple expressions as list"""
        result = normalize_expression_input(['a + b', 'a * b'])
        assert result == ['a + b', 'a * b']
    
    def test_single_expression_list(self):
        """Test single expression as list (kept as list)"""
        result = normalize_expression_input(['price * quantity'])
        assert result == ['price * quantity']
    
    def test_none_input(self):
        """Test None input"""
        result = normalize_expression_input(None)
        assert result is None
    
    def test_empty_list(self):
        """Test empty list raises error"""
        with pytest.raises(ValueError, match="Expression list cannot be empty"):
            normalize_expression_input([])
    
    def test_invalid_type(self):
        """Test invalid type raises error"""
        with pytest.raises(TypeError, match="Expression input must be string or list"):
            normalize_expression_input(123)


class TestNormalizeAsInput:
    """Test normalize_as_input() function"""
    
    def test_single_name_string(self):
        """Test single name as string"""
        result = normalize_as_input('total')
        assert result == 'total'
    
    def test_multiple_names_list(self):
        """Test multiple names as list"""
        result = normalize_as_input(['sum', 'product'])
        assert result == ['sum', 'product']
    
    def test_sort_order_string(self):
        """Test sort order as string"""
        result = normalize_as_input('desc')
        assert result == 'desc'
    
    def test_none_input(self):
        """Test None input"""
        result = normalize_as_input(None)
        assert result is None
    
    def test_empty_list(self):
        """Test empty list raises error"""
        with pytest.raises(ValueError, match="As list cannot be empty"):
            normalize_as_input([])
    
    def test_invalid_type(self):
        """Test invalid type raises error"""
        with pytest.raises(TypeError, match="As input must be string or list"):
            normalize_as_input(123)


class TestValidateExpressionAsMatch:
    """Test validate_expression_as_match() function"""
    
    def test_matching_single(self):
        """Test matching single expression and name"""
        assert validate_expression_as_match('a + b', 'sum') is True
    
    def test_matching_multiple(self):
        """Test matching multiple expressions and names"""
        assert validate_expression_as_match(
            ['a + b', 'a * b'],
            ['sum', 'product']
        ) is True
    
    def test_mismatched_lengths(self):
        """Test mismatched lengths raises error"""
        with pytest.raises(ValueError, match="Number of expressions .* must match"):
            validate_expression_as_match(
                ['a + b', 'a * b'],
                ['sum']
            )
    
    def test_none_expression(self):
        """Test None expression"""
        assert validate_expression_as_match(None, 'sum') is True
    
    def test_none_as(self):
        """Test None as_"""
        assert validate_expression_as_match('a + b', None) is True
    
    def test_both_none(self):
        """Test both None"""
        assert validate_expression_as_match(None, None) is True


class TestIntegrationScenarios:
    """Test realistic integration scenarios"""
    
    def test_add_to_single_column(self):
        """Test add.to() with single column"""
        # User can pass 'name' or ['name']
        assert normalize_column_input('name') == 'name'
        assert normalize_column_input(['name']) == 'name'
    
    def test_add_to_multiple_columns(self):
        """Test add.to() with multiple columns"""
        # User must pass ['name', 'city']
        result = normalize_column_input(['name', 'city'])
        assert result == ['name', 'city']
    
    def test_add_to_single_key(self):
        """Test add.to() with single key"""
        # User can pass 'customer_id' or ['customer_id']
        assert normalize_key_input('customer_id') == 'customer_id'
        assert normalize_key_input(['customer_id']) == 'customer_id'
    
    def test_add_to_multiple_keys(self):
        """Test add.to() with multiple keys"""
        # User must pass ('customer_id', 'date')
        result = normalize_key_input(('customer_id', 'date'))
        assert result == ('customer_id', 'date')
    
    def test_transform_sort_single(self):
        """Test add.transform('@sort') with single column"""
        # User can pass 'age' only (list not allowed)
        assert normalize_by_input('age') == 'age'
    
    def test_transform_sort_multiple(self):
        """Test add.transform('@sort') with multiple columns"""
        # User must pass ('salary', 'age')
        result = normalize_by_input(('salary', 'age'))
        assert result == ('salary', 'age')
    
    def test_transform_sort_list_error(self):
        """Test add.transform('@sort') with list raises error"""
        # Lists not allowed for by parameter
        with pytest.raises(ValueError, match="by parameter does not accept lists"):
            normalize_by_input(['age'])
    
    def test_transform_calc_single(self):
        """Test add.transform('@calc') with single expression"""
        expr = normalize_expression_input('price * quantity')
        as_val = normalize_as_input('total')
        assert validate_expression_as_match(expr, as_val) is True
    
    def test_transform_calc_multiple(self):
        """Test add.transform('@calc') with multiple expressions"""
        expr = normalize_expression_input(['a + b', 'a * b'])
        as_val = normalize_as_input(['sum', 'product'])
        assert validate_expression_as_match(expr, as_val) is True


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

