APP_NAME = "music-dragon"
APP_DISPLAY_NAME = "MusicDragon"
APP_ORGANIZATION_NAME = "Docheinstein"
APP_VERSION = "0.17"

UNKNOWN_ARTIST = "Unknown Artist"
UNKNOWN_ALBUM = "Unknown Album"