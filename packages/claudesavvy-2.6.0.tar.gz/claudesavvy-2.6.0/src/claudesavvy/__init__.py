"""ClaudeSavvy - Web-based usage monitoring tool for Claude Code."""

__version__ = "2.6.0"
__author__ = "Allan Napier"
__description__ = "Web-based usage monitoring tool for Claude Code"
