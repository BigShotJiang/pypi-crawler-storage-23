"""Web interface for Claude Monitor."""
