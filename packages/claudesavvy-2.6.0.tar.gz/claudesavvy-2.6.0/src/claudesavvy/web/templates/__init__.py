"""Templates for Claude Monitor web interface."""
