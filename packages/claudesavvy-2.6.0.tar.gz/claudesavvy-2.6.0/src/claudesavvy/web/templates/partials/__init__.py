"""Partial templates for Claude Monitor."""
