"""Page templates for Claude Monitor."""
