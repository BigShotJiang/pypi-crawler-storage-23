"""API routes for Claude Monitor."""
