from .filtertermsearch import FilterTermSearch
from .test import BrProcessorTestView
from .compensations import KillCompensationsViewSet
from .battlereports import BattleReportViewSet
from .brfilters import BrFiltersViewSet

filters_view = FilterTermSearch().as_view()
tests_view = BrProcessorTestView().as_view()

compensations = KillCompensationsViewSet
battlereports = BattleReportViewSet
filters = BrFiltersViewSet