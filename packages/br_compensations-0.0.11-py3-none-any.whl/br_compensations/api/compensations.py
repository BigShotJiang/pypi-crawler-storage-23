from rest_framework import viewsets
from ..models import KillCompensation
from .serializers import KillCompensationSrializer
from rest_framework.response import Response
from ..permissions import HasCompensationsPluginAccess

class KillCompensationsViewSet(viewsets.ModelViewSet):
    queryset = KillCompensation.objects.all()
    serializer_class = KillCompensationSrializer
    permission_classes = [HasCompensationsPluginAccess]
    
    def get_queryset(self):
        """Оптимизация запросов"""
        return super().get_queryset()
    
    def partial_update(self, request, pk=None, *args, **kwargs):
        if pk:
            compense = KillCompensation.objects.get(killmail_id = pk)
            data = request.data
            if data['status'] == 'C':
                compense.status = KillCompensation.STATUS_COMPLETE
            elif data['status'] == 'R':
                compense.status = KillCompensation.STATUS_REJECT
            elif data['status'] == 'N':
                compense.status = KillCompensation.STATUS_NEW
            compense.comment = data['comment']
            compense.save()
            return Response(status=200,data=pk)
        return Response(status=404)