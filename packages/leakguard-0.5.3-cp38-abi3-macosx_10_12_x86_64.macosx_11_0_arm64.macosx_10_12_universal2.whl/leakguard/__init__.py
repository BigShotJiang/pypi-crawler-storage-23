from .leakguard import *

__doc__ = leakguard.__doc__
if hasattr(leakguard, "__all__"):
    __all__ = leakguard.__all__