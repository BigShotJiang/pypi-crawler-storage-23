# deep_consultation

Deep consultation Learning Tools

## Install from PIP

```bash
pip install --upgrade deep-consultation
```

## More information

More information can be found in [doc](https://github.com/trucomanx/DeepConsultation/tree/main/doc)

## License

This project is licensed under the GPLv3 License.
