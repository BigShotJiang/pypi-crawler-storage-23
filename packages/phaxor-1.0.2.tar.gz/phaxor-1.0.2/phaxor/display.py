"""
Phaxor — Rich Jupyter Notebook Display
Renders engineering results as styled HTML tables in Jupyter notebooks.
"""


def display_result(calculator_type: str, name: str, inputs: dict, result: dict | None):
    """
    Display a styled HTML table of results in Jupyter notebooks.
    Falls back silently if not in a Jupyter environment.
    """
    try:
        from IPython.display import display, HTML
    except ImportError:
        return  # Not in Jupyter

    if result is None:
        display(HTML(f"""
            <div style="padding:16px;background:#1a1b26;border:1px solid #ef4444;border-radius:12px;
                        font-family:system-ui;color:#f87171;">
                ⚠️ <strong>{name}</strong> — Invalid inputs. Check your parameters.
            </div>
        """))
        return

    # Filter out complex nested data for clean display
    display_items = {}
    for k, v in result.items():
        if isinstance(v, (int, float)):
            display_items[k] = f"{v:,.6g}"
        elif isinstance(v, str):
            display_items[k] = v
        elif isinstance(v, bool):
            display_items[k] = '✅ Yes' if v else '❌ No'

    rows_html = ''.join(
        f"""<tr>
            <td style="padding:8px 12px;border-bottom:1px solid #2f334d;font-weight:600;color:#7aa2f7;
                        font-family:monospace;font-size:13px;">{k}</td>
            <td style="padding:8px 12px;border-bottom:1px solid #2f334d;font-size:13px;">{v}</td>
        </tr>"""
        for k, v in display_items.items()
    )

    html = f"""
    <div style="font-family:'Inter',system-ui,sans-serif;max-width:600px;margin:12px 0;">
        <div style="background:#1a1b26;border:1px solid #2f334d;border-radius:12px;overflow:hidden;">
            <div style="padding:14px 16px;background:linear-gradient(135deg,#22d3ee22,#a855f722);
                        display:flex;align-items:center;gap:8px;">
                <div style="width:8px;height:8px;border-radius:50%;background:#22d3ee;"></div>
                <strong style="color:#c0caf5;font-size:15px;">{name}</strong>
                <span style="margin-left:auto;font-size:10px;color:#565f89;">Phaxor v1.0</span>
            </div>
            <table style="width:100%;border-collapse:collapse;color:#c0caf5;">
                {rows_html}
            </table>
        </div>
    </div>
    """
    display(HTML(html))
