"""Phaxor — Hardness Conversion Engine (Python port)"""

def solve_hardness_conversion(inputs: dict) -> dict | None:
    """Hardness Conversion Calculator (Approximate)."""
    val = float(inputs.get('value', 0))
    scale = inputs.get('scale', 'HB')
    
    if val <= 0:
        return None

    # Convert everything to Brinell (HB) first
    hb = 0.0

    if scale == 'HB':
        hb = val
    elif scale == 'HRC':
        # Valid > 20 HRC
        if val < 20:
            return None
        hb = 76.6 + 7.39 * val + 0.0426 * val * val
    elif scale == 'HV':
        hb = val * 0.95
    elif scale == 'HRB':
        hb = -34.5 + 1.465 * val
        if hb <= 0:
            return None
    else:
        return None

    if hb <= 0:
        return None

    # Convert HB to others
    
    # HB to HRC (valid > 240 HB)
    hrc = float('nan')
    if hb >= 240:
        hrc = -2.81 + 0.0785 * hb + 0.0000267 * hb * hb
    
    # HB to HV
    hv = hb / 0.95

    # HB to HRB (valid < 240 HB approx)
    hrb = float('nan')
    if hb < 250:
        hrb = (hb + 34.5) / 1.465
        if hrb > 105 or hrb < 0:
            hrb = float('nan')

    # UTS (MPa) ≈ 3.45 * HB (steel)
    uts = hb * 3.45

    return {
        'HB': int(round(hb)),
        'HRC': round(hrc, 1) if not (hrc != hrc) else None, # Handle NaN for JSON safety
        'HV': int(round(hv)),
        'HRB': int(round(hrb)) if not (hrb != hrb) else None,
        'UTS': int(round(uts))
    }
