"""Phaxor — Beam Deflection Engine (Python port)"""
import math

def solve_beam_deflection(inputs: dict) -> dict:
    """
    Calculate beam deflection using closed-form solutions.
    """
    beam_type = inputs.get('beamType', 'simply-supported')
    load_type = inputs.get('loadType', 'point-center')
    P = float(inputs.get('P', 0))
    w = float(inputs.get('w', 0))
    L = float(inputs.get('L', 0))
    a = float(inputs.get('a', 0))
    E = float(inputs.get('E', 200000)) # MPa
    I_val = float(inputs.get('I', 0)) # mm^4
    steps = int(inputs.get('steps', 100))
    
    EI = E * I_val
    
    if EI == 0 or L == 0:
        return {'error': "Invalid parameters: EI or L is zero"}
        
    data = []
    max_deflection = 0
    max_moment = 0
    max_shear = 0
    max_slope = 0
    
    for i in range(steps + 1):
        x = (L / steps) * i
        defl = 0
        mom = 0
        shear = 0
        
        if beam_type == 'cantilever':
            if load_type == 'point-tip':
                defl = P * x * x * (3 * L - x) / (6 * EI)
                mom = P * (L - x)
                shear = -P
            elif load_type == 'point-custom':
                if x <= a:
                    defl = P * x * x * (3 * a - x) / (6 * EI)
                    mom = P * (a - x)
                    shear = -P
                else:
                    defl = P * a * a * (3 * x - a) / (6 * EI)
                    mom = 0
                    shear = 0
            elif load_type == 'udl':
                defl = w * x * x * (6 * L * L - 4 * L * x + x * x) / (24 * EI)
                mom = w * (L - x) * (L - x) / 2
                shear = -w * (L - x)
            elif load_type == 'triangular':
                defl = w * x * x * (10 * L * L * L - 10 * L * L * x + 5 * L * x * x - x * x * x) / (120 * EI * L)
                mom = w * (L - x) * (L - x) * (L - x) / (6 * L)
                shear = -w * (L - x) * (L - x) / (2 * L)
                
        elif beam_type == 'simply-supported':
            if load_type == 'point-center':
                halfL = L / 2
                if x <= halfL:
                    defl = P * x * (3 * L * L - 4 * x * x) / (48 * EI)
                    mom = P * x / 2
                    shear = P / 2
                else:
                    defl = P * (L - x) * (3 * L * L - 4 * (L - x) * (L - x)) / (48 * EI)
                    mom = P * (L - x) / 2
                    shear = -P / 2
            elif load_type == 'point-custom':
                b = L - a
                if x <= a:
                    defl = P * b * x * (L * L - b * b - x * x) / (6 * EI * L)
                    mom = P * b * x / L
                    shear = P * b / L
                else:
                    defl = P * a * (L - x) * (2 * L * x - x * x - a * a) / (6 * EI * L)
                    mom = P * a * (L - x) / L
                    shear = -P * a / L
            elif load_type == 'udl':
                defl = w * x * (L * L * L - 2 * L * x * x + x * x * x) / (24 * EI)
                mom = w * x * (L - x) / 2
                shear = w * (L / 2 - x)
            elif load_type == 'triangular':
                defl = w * x * (7 * L * L * L * L - 10 * L * L * x * x + 3 * x * x * x * x) / (360 * EI * L)
                mom = w * x * (L * L - x * x) / (6 * L)
                shear = w * (L * L - 3 * x * x) / (6 * L)
        
        elif beam_type == 'fixed-fixed':
            if load_type == 'point-center':
                halfL = L / 2
                if x <= halfL:
                    defl = P * x * x * (3 * L - 4 * x) / (48 * EI)
                    mom = P * L / 8 - P * x / 2
                    shear = P / 2
                else:
                    defl = P * (L - x) * (L - x) * (3 * L - 4 * (L - x)) / (48 * EI)
                    mom = -P * L / 8 + P * (L - x) / 2
                    shear = -P / 2
            elif load_type == 'udl':
                defl = w * x * x * (L - x) * (L - x) / (24 * EI)
                mom = w * (L * x - x * x) / 2 - w * L * L / 12
                shear = w * (L / 2 - x)
        
        elif beam_type == 'propped-cantilever':
            if load_type == 'point-center':
                R_prop = 5 * P / 16
                halfL = L / 2
                if x <= halfL:
                     defl = (R_prop * x * (L * L - x * x) / (6 * EI * L) * L - P * x * x * (3 * halfL - x) / (6 * EI))
                else:
                     defl = R_prop * (L - x) * (2 * L * x - x * x) / (6 * EI)
                
                mom = R_prop * x - (P * (x - halfL) if x > halfL else 0)
                shear = R_prop - (P if x > halfL else 0)
            elif load_type == 'udl':
                R = 3 * w * L / 8
                defl = (w * x * x * (6 * L * L - 4 * L * x + x * x) / (24 * EI)) - (R * x * (L * L - x * x)) / (6 * EI * L) * L
                defl = abs(defl) * 0.3
                mom = R * x - w * x * x / 2
                shear = R - w * x

        abs_defl = abs(defl)
        data.append({'x': x, 'deflection': -abs_defl, 'moment': mom, 'shear': shear})
        if abs_defl > max_deflection: max_deflection = abs_defl
        if abs(mom) > max_moment: max_moment = abs(mom)
        if abs(shear) > max_shear: max_shear = abs(shear)
    
    # Slopes
    if beam_type == 'cantilever':
        if load_type == 'point-tip': max_slope = P * L * L / (2 * EI)
        elif load_type == 'udl': max_slope = w * L * L * L / (6 * EI)
        else: max_slope = P * L * L / (2 * EI)
    elif beam_type == 'simply-supported':
        if load_type == 'point-center': max_slope = P * L * L / (16 * EI)
        elif load_type == 'udl': max_slope = w * L * L * L / (24 * EI)
        else: max_slope = P * L * L / (16 * EI)
    else:
        max_slope = max_deflection / (L / 4) if L > 0 else 0
        
    stiffness = (P if 'point' in load_type else w * L) / max_deflection if max_deflection > 0 else 0
    
    return {
        'result': {
            'data': data,
            'maxDeflection': max_deflection,
            'maxMoment': max_moment,
            'maxShear': max_shear,
            'maxSlope': max_slope,
            'stiffness': stiffness
        }
    }
