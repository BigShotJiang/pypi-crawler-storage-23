"""Phaxor — Steel Weight Engine (Python port)"""
import math

def calc_cross_area(shape: str, dims: dict) -> float:
    if shape == 'round-bar':
        d = dims.get('d', 0) / 1000
        return math.pi * d * d / 4
    elif shape == 'square-bar':
        s = dims.get('s', 0) / 1000
        return s * s
    elif shape == 'hex-bar':
        af = dims.get('af', 0) / 1000
        return (3 * math.sqrt(3) / 2) * (af / 2)**2
    elif shape == 'flat-bar':
        w = dims.get('w', 0) / 1000
        t = dims.get('t', 0) / 1000
        return w * t
    elif shape == 'sheet':
        sw = dims.get('sw', 0) / 1000
        st = dims.get('st', 0) / 1000
        return sw * st
    elif shape == 'hollow-pipe':
        od = dims.get('od', 0) / 1000
        id_val = dims.get('id', 0) / 1000
        return math.pi * (od * od - id_val * id_val) / 4
    elif shape == 'round-tube-rect':
        ow = dims.get('ow', 0) / 1000
        oh = dims.get('oh', 0) / 1000
        tw = dims.get('tw', 0) / 1000
        return ow * oh - (ow - 2 * tw) * (oh - 2 * tw)
    elif shape == 'angle':
        la = dims.get('la', 0) / 1000
        lb = dims.get('lb', 0) / 1000
        lt = dims.get('lt', 0) / 1000
        return (la + lb - lt) * lt
    elif shape == 'channel':
        cw = dims.get('cw', 0) / 1000
        ch = dims.get('ch', 0) / 1000
        cft = dims.get('cft', 0) / 1000
        cwt = dims.get('cwt', 0) / 1000
        return 2 * cw * cft + (ch - 2 * cft) * cwt
    elif shape == 'i-beam':
        bf = dims.get('bf', 0) / 1000
        tf = dims.get('tf', 0) / 1000
        hw = dims.get('hw', 0) / 1000
        tww = dims.get('tww', 0) / 1000
        return 2 * bf * tf + hw * tww
    elif shape == 'tee':
        tbf = dims.get('tbf', 0) / 1000
        ttf = dims.get('ttf', 0) / 1000
        th = dims.get('th', 0) / 1000
        ttw = dims.get('ttw', 0) / 1000
        return tbf * ttf + th * ttw
    return 0

def solve_steel_weight(inputs: dict) -> dict:
    items = inputs.get('items', [])
    rows = []
    
    for item in items:
        shape = item.get('shape')
        dims = item.get('dims', {})
        length = float(item.get('length', 0))
        qty = float(item.get('qty', 0))
        density = float(item.get('density', 7850))
        
        is_sheet = shape == 'sheet'
        
        if is_sheet:
            # For sheet, logic is different in TS engine I wrote: 
            # volPerPiece = sw * sl * st
            sw = dims.get('sw', 0) / 1000
            sl = dims.get('sl', 0) / 1000
            st = dims.get('st', 0) / 1000
            vol_per_piece = sw * sl * st
        else:
            area = calc_cross_area(shape, dims)
            vol_per_piece = area * length
            
        total_vol = vol_per_piece * qty
        total_weight = total_vol * density
        unit_weight = vol_per_piece * density
        
        per_meter = 0
        if is_sheet:
            per_meter = unit_weight # Not defined for sheet really per meter of what? TS used unitWeight.
        else:
            per_meter = calc_cross_area(shape, dims) * density
            
        rows.append({
            'id': item.get('id'),
            'shape': shape,
            'totalWeight': total_weight,
            'unitWeight': unit_weight,
            'totalVol': total_vol,
            'perMeter': per_meter
        })
        
    total_weight = sum(r['totalWeight'] for r in rows)
    total_volume = sum(r['totalVol'] for r in rows)
    
    return {
        'result': {
            'rows': rows,
            'totalWeight': total_weight,
            'totalVolume': total_volume
        }
    }
