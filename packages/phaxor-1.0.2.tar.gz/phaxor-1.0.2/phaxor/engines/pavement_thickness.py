"""Phaxor — Pavement Thickness Engine (Python port)"""
import math

def solve_pavement_thickness(inputs: dict) -> dict | None:
    """Pavement Thickness Calculator."""
    p_type = inputs.get('type', 'flexible')
    cbr = float(inputs.get('cbr', 4))
    A = float(inputs.get('A', 0))
    r = float(inputs.get('r', 5))
    n = float(inputs.get('n', 15))
    vdf = float(inputs.get('VDF', 4.5))
    ldf = float(inputs.get('LDF', 0.75))
    flex_str = float(inputs.get('flexStr', 4.5))
    k_val = float(inputs.get('k', 55))

    if A <= 0 or n <= 0:
        return None

    r_dec = r / 100.0
    nd = A * 365
    cumulative = (nd / r_dec) * ((1 + r_dec) ** n - 1)
    cumulative_msa = (cumulative * vdf * ldf) / 1e6

    total_required = 0
    layers = []
    flexural_check = None

    if p_type == 'flexible':
        if cbr < 2: total_required = 660
        elif cbr < 3: total_required = 580
        elif cbr < 4: total_required = 520
        elif cbr < 5: total_required = 480
        elif cbr < 7: total_required = 440
        elif cbr < 10: total_required = 400
        elif cbr < 15: total_required = 360
        elif cbr < 25: total_required = 320
        else: total_required = 280

        if cumulative_msa > 150: total_required += 60
        elif cumulative_msa > 50: total_required += 40
        elif cumulative_msa > 10: total_required += 20
        elif cumulative_msa < 2: total_required -= 30

        bituminous = 140 if cumulative_msa > 20 else (100 if cumulative_msa > 5 else 75)
        wbm = max(150, total_required * 0.3)
        gsb = max(100, total_required - bituminous - wbm)

        final_bit = max(bituminous, 50)
        final_wbm = max(wbm, 100)
        final_gsb = max(gsb, 100)
        
        total_required = final_bit + final_wbm + final_gsb
        
        layers.append({'name': 'Bituminous Surfacing', 'thickness': int(final_bit), 'color': '#1f2937'})
        layers.append({'name': 'WBM/WMM Base', 'thickness': int(final_wbm), 'color': '#6b7280'})
        layers.append({'name': 'Granular Sub-base', 'thickness': int(final_gsb), 'color': '#d97706'})

    else:
        # Rigid
        slab_thick = 250
        if cumulative_msa < 5: slab_thick = 200
        elif cumulative_msa < 20: slab_thick = 230
        elif cumulative_msa < 50: slab_thick = 260
        elif cumulative_msa < 150: slab_thick = 280
        else: slab_thick = 300

        if k_val < 40: slab_thick += 20
        if k_val < 25: slab_thick += 20

        dlc = 150
        gsb = 150

        total_required = slab_thick + dlc + gsb
        
        layers.append({'name': 'PQC Slab', 'thickness': int(slab_thick), 'color': '#64748b'})
        layers.append({'name': 'DLC Sub-base', 'thickness': dlc, 'color': '#9ca3af'})
        layers.append({'name': 'GSB', 'thickness': gsb, 'color': '#d97706'})

        P = 80
        sigma = ((3 * P * 1000) / (slab_thick * slab_thick)) * 0.04
        flexural_check = "OK" if sigma < flex_str else "Review needed"

    return {
        'cumulativeMSA': float(f"{cumulative_msa:.2f}"),
        'totalRequired': int(total_required),
        'layers': layers,
        'flexuralCheck': flexural_check
    }
