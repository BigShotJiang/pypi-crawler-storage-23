"""Phaxor — Heat Transfer Engine (Python port)"""

import math

SIGMA = 5.670374419e-8  # Stefan-Boltzmann constant

MATERIALS = {
    'concrete':    {'name': 'Concrete',              'k': 0.8},
    'brick':       {'name': 'Brick',                 'k': 0.72},
    'wood-pine':   {'name': 'Pine Wood',             'k': 0.12},
    'wood-oak':    {'name': 'Oak Wood',              'k': 0.17},
    'steel':       {'name': 'Carbon Steel',          'k': 50},
    'stainless':   {'name': 'Stainless Steel',       'k': 16},
    'aluminum':    {'name': 'Aluminum',              'k': 205},
    'copper':      {'name': 'Copper',                'k': 385},
    'glass':       {'name': 'Glass',                 'k': 1.0},
    'fiberglass':  {'name': 'Fiberglass Insulation', 'k': 0.04},
    'styrofoam':   {'name': 'Styrofoam (EPS)',       'k': 0.033},
    'rockwool':    {'name': 'Rock Wool',             'k': 0.045},
    'plywood':     {'name': 'Plywood',               'k': 0.13},
    'gypsum':      {'name': 'Gypsum Board',          'k': 0.17},
    'air-gap':     {'name': 'Air Gap (still)',       'k': 0.025},
}


def solve_heat_transfer(inputs: dict) -> dict | None:
    """Compute heat transfer for conduction, convection, radiation, or composite wall."""
    Th = inputs.get('tempHot', 0)
    Tc = inputs.get('tempCold', 0)
    A = inputs.get('area', 0)
    mode = inputs.get('mode', 'conduction')
    dT = abs(Th - Tc)

    if A == 0 or dT == 0:
        return None

    Q = 0
    R_total = 0
    q = 0
    temp_profile = []
    layer_data = []

    if mode == 'conduction':
        k = inputs.get('k', 1)
        L = inputs.get('thickness', 0.01)
        R_total = L / (k * A)
        Q = dT / R_total
        q = Q / A
        temp_profile = [{'x': 0, 'T': Th}, {'x': L, 'T': Tc}]
        layer_data = [{'material': inputs.get('material', 'custom'), 'thickness': L, 'k': k, 'R': R_total, 'dT': dT}]

    elif mode == 'convection':
        h = inputs.get('h', 1)
        R_total = 1 / (h * A)
        Q = h * A * dT
        q = Q / A

    elif mode == 'radiation':
        eps = inputs.get('emissivity', 0.9)
        ThK = Th + 273.15
        TcK = Tc + 273.15
        Q = eps * SIGMA * A * (ThK**4 - TcK**4)
        q = Q / A
        R_total = dT / Q if Q > 0 else 0

    elif mode == 'composite':
        hi = inputs.get('hInside', 8.3)
        ho = inputs.get('hOutside', 23)
        Ri = 1 / (hi * A)
        Ro = 1 / (ho * A)
        Rcond = 0

        for layer in inputs.get('layers', []):
            R = layer['thickness'] / (layer['k'] * A)
            Rcond += R
            layer_data.append({'material': layer.get('material', ''), 'thickness': layer['thickness'],
                             'k': layer['k'], 'R': R, 'dT': 0})

        R_total = Ri + Rcond + Ro
        Q = dT / R_total
        q = Q / A

        current_T = Th
        temp_profile.append({'x': 0, 'T': current_T})
        dTi = Q * Ri
        current_T -= dTi
        acc_x = 0
        for ld in layer_data:
            temp_profile.append({'x': acc_x, 'T': current_T})
            drop = Q * ld['R']
            ld['dT'] = drop
            current_T -= drop
            acc_x += ld['thickness']
            temp_profile.append({'x': acc_x, 'T': current_T})

    daily_kwh = (Q * 24) / 1000
    U = 1 / (R_total * A) if R_total > 0 else 0

    return {
        'Q': Q, 'q': q, 'R_total': R_total, 'U': U, 'dT': dT,
        'tempProfile': temp_profile, 'layerData': layer_data,
        'dailyKWh': daily_kwh,
        'monthlyKWh': daily_kwh * 30,
        'yearlyKWh': daily_kwh * 365,
        'yearlyEnergyCost': daily_kwh * 365 * 0.12,
    }
