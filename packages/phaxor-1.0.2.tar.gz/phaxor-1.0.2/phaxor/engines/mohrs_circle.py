"""Phaxor — Mohr's Circle Engine (Python port)"""

import math


def solve_mohrs_circle(inputs: dict) -> dict:
    """Compute Mohr's Circle for 2D plane stress."""
    sx = inputs.get('sigmaX', 0)
    sy = inputs.get('sigmaY', 0)
    txy = inputs.get('tauXY', 0)
    theta_deg = inputs.get('theta', 0)

    center = (sx + sy) / 2
    radius = math.sqrt(((sx - sy) / 2) ** 2 + txy ** 2)

    sigma1 = center + radius
    sigma2 = center - radius
    tau_max = radius
    theta_p = math.degrees(math.atan2(2 * txy, sx - sy) / 2)
    theta_s = theta_p + 45

    theta_rad = math.radians(theta_deg)
    sigma_xp = center + ((sx - sy) / 2) * math.cos(2 * theta_rad) + txy * math.sin(2 * theta_rad)
    sigma_yp = center - ((sx - sy) / 2) * math.cos(2 * theta_rad) - txy * math.sin(2 * theta_rad)
    tau_xyp = -((sx - sy) / 2) * math.sin(2 * theta_rad) + txy * math.cos(2 * theta_rad)

    von_mises = math.sqrt(sigma1 ** 2 - sigma1 * sigma2 + sigma2 ** 2)

    if sigma1 > 0 and sigma2 > 0:
        stress_type = 'Biaxial Tension'
    elif sigma1 < 0 and sigma2 < 0:
        stress_type = 'Biaxial Compression'
    elif sigma1 == 0 or sigma2 == 0:
        stress_type = 'Uniaxial'
    else:
        stress_type = 'Mixed (Tension + Compression)'

    return {
        'center': center, 'radius': radius,
        'sigma1': sigma1, 'sigma2': sigma2,
        'tauMax': tau_max, 'thetaP': theta_p, 'thetaS': theta_s,
        'sigmaAvg': center,
        'sigmaXp': sigma_xp, 'sigmaYp': sigma_yp, 'tauXYp': tau_xyp,
        'vonMises': von_mises, 'stressType': stress_type,
    }
