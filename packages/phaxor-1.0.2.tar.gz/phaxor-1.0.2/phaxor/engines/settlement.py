import math

def get_time_factor(U):
    if U <= 0.6:
        return (math.pi / 4) * U**2
    return -0.933 * math.log10(1 - U) - 0.085

def solve_settlement(inputs):
    try:
        CcV = float(inputs.get('Cc', 0))
        e0V = float(inputs.get('e0', 0))
        CvV = float(inputs.get('Cv', 0))
        EV = float(inputs.get('E', 0))
        muV = float(inputs.get('mu', 0))
        HV = float(inputs.get('H', 0))
        dpV = float(inputs.get('deltaP', 0))
        s0V = float(inputs.get('sigma0', 0))
        BV = float(inputs.get('B', 0))
        drainage = inputs.get('drainage', 'two')

        if HV == 0 or dpV == 0:
            return {'error': 'Layer thickness (H) and stress increase (deltaP) are required'}

        Hdr = HV / 2 if drainage == 'two' else HV

        If = 1.0
        SiMM = 0
        if EV > 0 and BV > 0:
            deltaP_MPa = dpV / 1000
            SiMM = (deltaP_MPa * BV * (1 - muV**2) * If) / EV * 1000

        ScMM = 0
        if CcV > 0 and s0V > 0:
            ScMM = (CcV * HV / (1 + e0V)) * math.log10((s0V + dpV) / s0V) * 1000

        totalMM = SiMM + ScMM

        timeData = []
        if CvV > 0 and ScMM > 0:
            Uvalues = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99]
            for U in Uvalues:
                Tv = get_time_factor(U)
                t = (Tv * Hdr**2) / CvV
                timeData.append({'time': float(f'{t:.2f}'), 'settlement': float(f'{U * ScMM:.1f}'), 'U': int(U * 100)})

        t50 = (get_time_factor(0.5) * Hdr**2) / CvV if CvV > 0 else 0
        t90 = (get_time_factor(0.9) * Hdr**2) / CvV if CvV > 0 else 0

        return {
            'result': {
                'SiMM': SiMM, 'ScMM': ScMM, 'totalMM': totalMM,
                'timeData': timeData, 't50': t50, 't90': t90,
                'Hdr': Hdr, 'allowable': 25,
                'isImmediate': CcV == 0
            }
        }
    except Exception as e:
        return {'error': str(e)}
