"""Phaxor — Hardness Conversion Engine (Python port)"""
import math

def solve_hardness_conversion(inputs: dict) -> dict | None:
    """Hardness Conversion Calculator."""
    val = float(inputs.get('value', 0))
    scale = inputs.get('scale', 'HB')

    if val <= 0:
        return None

    hb = 0.0

    if scale == 'HB':
        hb = val
    elif scale == 'HRC':
        if val < 20: hb = float('nan')
        else: hb = 76.6 + 7.39 * val + 0.0426 * val * val
    elif scale == 'HV':
        hb = val * 0.95
    elif scale == 'HRB':
        hb = -34.5 + 1.465 * val
    else:
        hb = val

    if math.isnan(hb) or hb <= 0:
        return None

    # HRC
    hrc = float('nan')
    if hb >= 240:
        hrc = -2.81 + 0.0785 * hb + 0.0000267 * hb * hb
    
    # HV
    hv = hb * 1.05

    # HRB
    hrb = float('nan')
    if hb < 240: # Rough upper limit for HRB validity
        hrb = (hb + 34.5) / 1.465
        if hrb > 100 or hrb < 0: hrb = float('nan')
    
    # UTS
    uts = hb * 3.45

    return {
        'HB': float(f"{hb:.0f}"),
        'HRC': float(f"{hrc:.1f}") if not math.isnan(hrc) else None,
        'HV': float(f"{hv:.0f}"),
        'HRB': float(f"{hrb:.0f}") if not math.isnan(hrb) else None,
        'UTS': float(f"{uts:.0f}")
    }
