"""Phaxor — COP Engine (Python port)"""

def solve_cop(inputs: dict) -> dict | None:
    """COP / HVAC Calculator."""
    mode = inputs.get('mode', 'cooling')
    qc = float(inputs.get('outputPower', 0))
    w = float(inputs.get('inputPower', 0))
    tc = float(inputs.get('Tc', 0))
    th = float(inputs.get('Th', 0))

    if w <= 0 or qc <= 0:
        return None

    # COP
    if mode == 'cooling':
        cop = qc / w
    else:
        cop = (qc + w) / w

    eer = cop * 3.412
    seer = eer * 1.1

    # Carnot
    tck = tc + 273.15
    thk = th + 273.15
    
    carnot_cop = 0.0
    if abs(thk - tck) > 0.1:
        if mode == 'cooling':
            carnot_cop = tck / (thk - tck)
        else:
            carnot_cop = thk / (thk - tck)
    else:
        carnot_cop = 999.0

    second_law_eff = (cop / carnot_cop) * 100 if carnot_cop > 0 else 0

    qh = qc + w
    tons = qc / 3517.0

    return {
        'cop': float(f"{cop:.2f}"),
        'eer': float(f"{eer:.2f}"),
        'seer': float(f"{seer:.2f}"),
        'carnotCOP': float(f"{carnot_cop:.2f}"),
        'secondLawEff': float(f"{second_law_eff:.2f}"),
        'Qc': qc,
        'Qh': qh,
        'W': w,
        'tons': float(f"{tons:.3f}")
    }
