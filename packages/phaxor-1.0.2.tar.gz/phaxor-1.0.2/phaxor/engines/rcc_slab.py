import math

def solve_rcc_slab(inputs):
    try:
        lx = float(inputs.get('Lx', 0))
        ly = float(inputs.get('Ly', 0))
        depth = float(inputs.get('D', 0))
        ll = float(inputs.get('liveLoad', 0))
        ff = float(inputs.get('floorFinish', 0))
        fck = float(inputs.get('fck', 20))
        fy = float(inputs.get('fy', 415))
        barDia = float(inputs.get('barDia', 10))
        cover = float(inputs.get('cc', 20))

        if lx == 0 or ly == 0 or depth == 0 or fck == 0 or fy == 0:
            return {'error': 'Invalid input parameters'}

        ratio = ly / lx
        slabType = 'one-way' if ratio > 2 else 'two-way'

        d = depth - cover - barDia / 2
        if d <= 0:
            return {'error': 'Effective depth is non-positive'}

        # Loads (kN/m²)
        selfWeight = 25 * depth / 1000
        deadLoad = selfWeight + ff
        totalLoad = deadLoad + ll
        factoredLoad = 1.5 * totalLoad

        MuX = 0
        MuY = 0

        # IS 456 Table 26 coefficients (simplified)
        MOMENT_COEFFS = [
            {'axPos': 0.035, 'axNeg': 0.047, 'ayPos': 0.024, 'ayNeg': 0.032}, # 1.0
            {'axPos': 0.043, 'axNeg': 0.057, 'ayPos': 0.024, 'ayNeg': 0.032}, # 1.1
            {'axPos': 0.049, 'axNeg': 0.064, 'ayPos': 0.024, 'ayNeg': 0.032}, # 1.2
            {'axPos': 0.055, 'axNeg': 0.071, 'ayPos': 0.024, 'ayNeg': 0.032}, # 1.3
            {'axPos': 0.060, 'axNeg': 0.076, 'ayPos': 0.024, 'ayNeg': 0.032}, # 1.4
            {'axPos': 0.064, 'axNeg': 0.080, 'ayPos': 0.024, 'ayNeg': 0.032}, # 1.5
        ]

        if slabType == 'one-way':
            # One-way: Mu = wu * lx² / 8
            MuX = factoredLoad * (lx / 1000)**2 / 8
            MuY = 0
        else:
            # Two-way
            rIdx = min(int((ratio - 1.0) * 10), 5)
            rIdx = max(0, rIdx)
            coeffs = MOMENT_COEFFS[rIdx]
            MuX = coeffs['axPos'] * factoredLoad * (lx / 1000)**2
            MuY = coeffs['ayPos'] * factoredLoad * (lx / 1000)**2

        # Ast calculation
        b = 1000
        
        def calc_ast(Mu_Nmm, deff):
            term = 1 - (4.598 * Mu_Nmm) / (fck * b * deff * deff)
            if term < 0:
                return -1
            return (0.5 * fck / fy) * (1 - math.sqrt(term)) * b * deff

        AstX = calc_ast(MuX * 1e6, d)
        dY = d - barDia
        AstY = calc_ast(MuY * 1e6, dY) if slabType == 'two-way' else 0

        AstMin = (0.0015 if fy <= 250 else 0.0012) * b * depth
        if AstX != -1 and AstX < AstMin: AstX = AstMin
        if slabType == 'two-way' and AstY != -1 and AstY < AstMin: AstY = AstMin

        maxSpacing = min(3 * d, 300)
        areaOneBar = math.pi * barDia**2 / 4

        spacingX = 0
        spacingY = 0
        AstXProv = 0
        AstYProv = 0

        if AstX > 0:
            spacingX = min((areaOneBar / AstX) * 1000, maxSpacing)
            spacingX = math.floor(spacingX / 5) * 5
            AstXProv = (areaOneBar / spacingX) * 1000 if spacingX > 0 else 0

        if AstY > 0:
            spacingY = min((areaOneBar / AstY) * 1000, maxSpacing)
            spacingY = math.floor(spacingY / 5) * 5
            AstYProv = (areaOneBar / spacingY) * 1000 if spacingY > 0 else 0

        # Deflection
        ldActual = lx / d
        ldBasic = 20
        ldMax = ldBasic * 1.4
        deflOk = ldActual <= ldMax

        # Distribution
        AstDist = AstMin
        spacingDist = math.floor(((areaOneBar / AstDist) * 1000) / 5) * 5

        sectionOk = AstX >= 0 and (slabType == 'one-way' or AstY >= 0)

        return {
            'result': {
                'slabType': slabType,
                'ratio': ratio,
                'd': d,
                'dY': dY,
                'selfWeight': selfWeight,
                'deadLoad': deadLoad,
                'totalLoad': totalLoad,
                'factoredLoad': factoredLoad,
                'MuX': MuX,
                'MuY': MuY,
                'AstX': AstX,
                'AstY': AstY,
                'AstXProv': AstXProv,
                'AstYProv': AstYProv,
                'spacingX': spacingX,
                'spacingY': spacingY,
                'AstMin': AstMin,
                'maxSpacing': maxSpacing,
                'ldActual': ldActual,
                'ldMax': ldMax,
                'deflOk': deflOk,
                'AstDist': AstDist,
                'spacingDist': spacingDist,
                'sectionOk': sectionOk
            }
        }
    except Exception as e:
        return {'error': str(e)}
