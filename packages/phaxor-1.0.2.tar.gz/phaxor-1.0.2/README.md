# 🔬 Phaxor — Engineering Calculator Library

**Embeddable engineering calculations for JavaScript and Python.**

## Install

```bash
pip install phaxor
```

## Quick Start

```python
import phaxor

# Ideal Gas Law
result = phaxor.compute('ideal-gas', {
    'solveFor': 'pressure',
    'volume': 0.02241,
    'moles': 1,
    'temperature': 273.15,
    'gas': 'air'
})
print(f"Pressure = {result['P']:.0f} Pa")  # 101325 Pa

# Ohm's Law
result = phaxor.compute('ohms-law', {
    'solveFor': 'I',
    'voltage': 12,
    'resistance': 100
})
print(f"Current = {result['I']} A")  # 0.12 A

# Unit Conversion
km = phaxor.convert('length', 1, 'mi', 'km')
print(f"1 mile = {km:.6f} km")  # 1.609344 km

# Mohr's Circle
result = phaxor.compute('mohrs-circle', {
    'sigmaX': 80,
    'sigmaY': -40,
    'tauXY': 30,
    'theta': 25
})
print(f"σ₁ = {result['sigma1']:.1f} MPa")

# List all calculators
for calc in phaxor.list_calculators():
    print(f"  {calc['id']:20s} {calc['name']}")
```

## Available Calculators (All 74 Engines)

| ID | Name | Category |
|----|------|----------|
| `arrhenius` | Arrhenius | Chemical |
| `cstr` | CSTR Design | Chemical |
| `chem-equilibrium` | Chem Equilibrium | Chemical |
| `distillation` | Distillation | Chemical |
| `gibbs` | Gibbs | Chemical |
| `pfr` | PFR Design | Chemical |
| `packed-bed` | Packed Bed | Chemical |
| `stoichiometry` | Stoichiometry | Chemical |
| `vle` | VLE / Phase Equilibrium | Chemical |
| `battery-ups` | Battery Ups | Electrical |
| `cable-sizing` | Cable Sizing | Electrical |
| `circuit-breaker` | Circuit Breaker | Electrical |
| `dc-motor` | DC Motor | Electrical |
| `earthing` | Earthing | Electrical |
| `electrical-efficiency` | Electrical Efficiency | Electrical |
| `energy-consumption` | Energy Consumption | Electrical |
| `impedance` | Impedance | Electrical |
| `induction-motor` | Induction Motor | Electrical |
| `ohms-law` | Ohm's Law | Electrical |
| `power` | Power | Electrical |
| `pf-correction` | Power Factor Correction | Electrical |
| `rectifier` | Rectifier | Electrical |
| `resonance` | Resonance | Electrical |
| `short-circuit` | Short Circuit | Electrical |
| `solar-sizing` | Solar Sizing | Electrical |
| `transformer` | Transformer | Electrical |
| `geometry` | Geometry | General |
| `matrix` | Matrix | General |
| `unit-converter` | Unit Converter | General |
| `open-channel` | Open Channel Flow | Hydraulics |
| `pavement-thickness` | Pavement Thickness | Hydraulics |
| `sight-distance` | Sight Distance | Hydraulics |
| `weir-orifice` | Weir & Orifice | Hydraulics |
| `apf` | Atomic Packing Factor | Materials |
| `corrosion` | Corrosion | Materials |
| `fatigue-life` | Fatigue Life | Materials |
| `hardness-conversion` | Hardness Conversion | Materials |
| `rule-of-mixtures` | Rule of Mixtures | Materials |
| `beam` | Beam | Mechanical |
| `bearing-life` | Bearing Life | Mechanical |
| `belt-drive` | Belt Drive | Mechanical |
| `bolt-analysis` | Bolt Analysis | Mechanical |
| `cop` | Coefficient of Performance | Mechanical |
| `flywheel` | Flywheel | Mechanical |
| `gear-ratio` | Gear Ratio | Mechanical |
| `heat-exchanger` | Heat Exchanger | Mechanical |
| `heat-transfer` | Heat Transfer | Mechanical |
| `ideal-gas` | Ideal Gas Law | Mechanical |
| `pipe-flow` | Pipe Flow | Mechanical |
| `pressure-force` | Pressure Force | Mechanical |
| `pump-power` | Pump Power | Mechanical |
| `rankine-cycle` | Rankine Cycle | Mechanical |
| `shaft-design` | Shaft Design | Mechanical |
| `spring-design` | Spring Design | Mechanical |
| `torque-power` | Torque Power | Mechanical |
| `vibration` | Vibration | Mechanical |
| `weld-strength` | Weld Strength | Mechanical |
| `beam-deflection` | Beam Deflection | Structural |
| `bearing-capacity` | Bearing Capacity | Structural |
| `column-buckling` | Column Buckling | Structural |
| `concrete-volume` | Concrete Volume | Structural |
| `development-length` | Development Length | Structural |
| `earth-pressure` | Earth Pressure | Structural |
| `failure-theory` | Failure Theory | Structural |
| `isolated-footing` | Isolated Footing | Structural |
| `mohrs-circle` | Mohr's Circle | Structural |
| `rcc-beam` | RCC Beam Design | Structural |
| `rcc-column` | RCC Column Design | Structural |
| `rcc-slab` | RCC Slab Design | Structural |
| `reinforcement-qty` | Reinforcement Qty | Structural |
| `settlement` | Settlement | Structural |
| `soil-properties` | Soil Properties | Structural |
| `steel-weight` | Steel Weight | Structural |
| `stress-strain` | Stress Strain | Structural |

## Pipe Flow (Detailed Model)

```python
import phaxor

# Pressure-driven solve using NPS + Schedule diameter lookup
result = phaxor.compute('pipe-flow', {
    'solveMode': 'known-pressures',
    'nps': '4',
    'schedule': '40',
    'length': 120,
    'roughness': 0.000045,
    'minorLossK': 6.5,
    'elevationChange': 5,
    'inletPressure': 220,   # kPa gauge
    'outletPressure': 0,    # kPa gauge
    'density': 998,
    'viscosity': 0.001002
})

print(f"Q = {result['flowRate']*3600:.2f} m3/h")
print(f"ID source = {result['diameterSource']}")
print(f"Delta P = {result['pressureDeltaKPa']:.2f} kPa")
```

The `pipe-flow` engine now supports:
- `known-flow` and `known-pressures` boundary modes
- Flow input by volumetric flow, mass flow, or velocity
- Minor loss (`K`) and elevation/pump head terms
- Pipe sizing by direct diameter or `nps + schedule`
- Extended outputs (major/minor loss split, power estimates, turbulence initialization fields)

## Jupyter Notebooks

In Jupyter, calling `phaxor.compute()` automatically renders a styled HTML table:

```python
import phaxor

# This renders a beautiful HTML table in Jupyter!
phaxor.compute('ideal-gas', {
    'solveFor': 'pressure',
    'volume': 0.02241,
    'moles': 1,
    'temperature': 273.15,
})
```

## API

```python
phaxor.compute(calculator_type, inputs)  # Run any calculator
phaxor.convert(category, value, from_unit, to_unit)  # Unit conversion
phaxor.list_calculators()  # List all available calculators
```

## License

MIT
