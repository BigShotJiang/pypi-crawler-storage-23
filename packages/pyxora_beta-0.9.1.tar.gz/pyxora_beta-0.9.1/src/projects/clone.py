from .path import get_path, valid_project, create_path
import os.path
import subprocess
import tempfile
import shutil


def clone(args):
    """Create a new project from a git repository URL."""
    source = args.source
    cmd = ["git", "clone", source]
    with tempfile.TemporaryDirectory() as temp_dir:
        try:
            subprocess.run(
                cmd,
                check=True,
                cwd=temp_dir,
                stdout=subprocess.DEVNULL,  # suppress output
            )
        except subprocess.CalledProcessError as e:
            print(f"cloning failed with exit code {e.returncode}")
            return

        name = source.rstrip("/").split("/")[-1].replace('.git', '')
        if valid_project(name):
            print(f"project `{name}` already exists!")
            return

        create_path(name)
        path = get_path(name)
        repo_clone_path = os.path.join(temp_dir, name)
        shutil.copytree(repo_clone_path, path, dirs_exist_ok=True)
        print(f"path: {path}")
        print(f"project '{name}' created successfully!")

        return path
