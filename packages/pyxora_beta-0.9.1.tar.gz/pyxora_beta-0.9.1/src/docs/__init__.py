import warnings

warnings.filterwarnings("ignore")

from .local import local
from .build import build_docs
from .online import online
