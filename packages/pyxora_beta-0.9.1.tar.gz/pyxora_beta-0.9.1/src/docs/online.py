import webbrowser


def online(*args, **kwargs):
    webbrowser.open("https://antonispylos.github.io/pyxora-beta/")
