import json
from typing import Annotated

import typer
import uvicorn
from rich import print as rprint

from progtc.server.config import server_config

app = typer.Typer(
    name="progtc",
    help="progtc CLI",
    add_completion=True,
)


@app.callback()
def callback() -> None:
    """Progtc - programmatic tool calling"""


ARTWORK = """
[bright_cyan]
    ██████╗ ██████╗  ██████╗  ██████╗ ████████╗ ██████╗
    ██╔══██╗██╔══██╗██╔═══██╗██╔════╝ ╚══██╔══╝██╔════╝
    ██████╔╝██████╔╝██║   ██║██║  ███╗   ██║   ██║     
    ██╔═══╝ ██╔══██╗██║   ██║██║   ██║   ██║   ██║     
    ██║     ██║  ██║╚██████╔╝╚██████╔╝   ██║   ╚██████╗
    ╚═╝     ╚═╝  ╚═╝ ╚═════╝  ╚═════╝    ╚═╝    ╚═════╝
                                               by capsa[/bright_cyan]
[dim]───────────────────────────────────────────────────────────[/dim]
    [bright_white]Come build agents with us: https://capsa.ai/careers[/bright_white]
[dim]───────────────────────────────────────────────────────────[/dim]
"""


def _init_sentry(sentry_options: str) -> None:
    try:
        import sentry_sdk
    except ImportError as e:
        rprint(
            "[red]sentry-sdk is not installed. "
            "Install it with: pip install progtc\\[server-sentry][/red]"
        )
        raise typer.Exit(1) from e
    try:
        sentry_kwargs = json.loads(sentry_options)
    except json.JSONDecodeError as e:
        rprint(
            "[red]Invalid JSON passed to --sentry-options. "
            "Please pass a valid JSON object.[/red]"
        )
        raise typer.Exit(1) from e
    try:
        sentry_sdk.init(**sentry_kwargs)
    except Exception as e:
        rprint(
            "[red]Error initializing sentry-sdk. "
            "Please check the sentry-sdk documentation for more information.[/red]\n"
            f"{e}"
        )
        raise typer.Exit(1) from e


@app.command()
def serve(
    host: Annotated[str, typer.Option(help="Host to bind to")] = "127.0.0.1",
    port: Annotated[int, typer.Option(help="Port to bind to")] = 8000,
    api_key: Annotated[
        str | None,
        typer.Option(
            help=(
                "API key for authentication (can also be set via "
                "PROGTC_API_KEY env var)"
            ),
            envvar="PROGTC_API_KEY",
        ),
    ] = None,
    tool_call_timeout: Annotated[
        float,
        typer.Option(help="Timeout for tool calls in seconds"),
    ] = 10.0,
    code_execution_timeout: Annotated[
        float,
        typer.Option(help="Timeout for code execution in seconds"),
    ] = 30.0,
    sentry_options: Annotated[
        str | None,
        typer.Option(
            help=(
                "JSON object of kwargs passed to sentry_sdk.init(). "
                "Requires progtc[server-sentry]."
            ),
        ),
    ] = None,
) -> None:
    if api_key:
        server_config.api_key = api_key
    server_config.tool_call_timeout = tool_call_timeout
    server_config.code_execution_timeout = code_execution_timeout

    if sentry_options:
        _init_sentry(sentry_options)

    rprint(ARTWORK)

    uvicorn.run(
        "progtc.server.api:app",
        host=host,
        port=port,
    )


def main() -> None:
    app()


if __name__ == "__main__":
    main()
