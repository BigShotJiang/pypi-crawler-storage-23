"""Public detector API modules."""

from __future__ import annotations

__all__ = ["train", "evaluate", "infer", "data", "cli"]
