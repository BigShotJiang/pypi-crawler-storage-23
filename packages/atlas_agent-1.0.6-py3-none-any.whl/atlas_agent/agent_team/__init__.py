"""Agent tooling modules (tools + dispatcher + shared utilities)."""
