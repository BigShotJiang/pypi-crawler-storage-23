"""
Atlas agent (wrapper package)

CLI for generating, validating, previewing, exporting animations and for
controlling the GUI via gRPC.

Usage: python -m atlas_agent --help
"""

__version__ = "0.1.0"
