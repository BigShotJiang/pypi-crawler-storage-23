"""The package for epymorph's built-in IPMs, MMs, and GEOs."""
