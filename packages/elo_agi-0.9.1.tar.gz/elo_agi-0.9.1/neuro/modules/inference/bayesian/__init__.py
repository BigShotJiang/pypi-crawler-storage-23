# Bayesian inference components
