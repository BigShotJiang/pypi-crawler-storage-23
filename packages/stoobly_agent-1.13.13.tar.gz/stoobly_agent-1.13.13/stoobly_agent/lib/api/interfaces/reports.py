from typing import TypedDict

class ReportShowResponse(TypedDict):
  key: str
