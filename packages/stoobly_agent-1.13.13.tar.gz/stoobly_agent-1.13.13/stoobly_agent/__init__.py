COMMAND = 'stoobly-agent'
VERSION = '1.13.13'
