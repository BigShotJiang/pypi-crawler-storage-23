"""Python API client for tldfyi.com."""

__version__ = "0.1.0"
