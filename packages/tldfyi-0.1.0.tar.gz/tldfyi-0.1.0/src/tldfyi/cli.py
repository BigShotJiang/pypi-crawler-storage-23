"""Command-line interface for tldfyi."""

from __future__ import annotations

import json

import typer

from tldfyi.api import TLDFYI

app = typer.Typer(help="TLDFYI — TLD registry and domain extensions API client.")


@app.command()
def search(query: str) -> None:
    """Search tldfyi.com."""
    with TLDFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
