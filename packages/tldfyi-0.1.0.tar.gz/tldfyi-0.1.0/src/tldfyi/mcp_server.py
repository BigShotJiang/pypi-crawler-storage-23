"""MCP server for tldfyi."""

from __future__ import annotations

from typing import Any

from mcp.server.fastmcp import FastMCP

from tldfyi.api import TLDFYI

mcp = FastMCP("tldfyi")


@mcp.tool()
def search_tldfyi(query: str) -> dict[str, Any]:
    """Search tldfyi.com for content matching the query."""
    with TLDFYI() as api:
        return api.search(query)
