# tldfyi

TLD registry and domain extensions API client — [tldfyi.com](https://tldfyi.com)

## Install

```bash
pip install tldfyi
```

## Quick Start

```python
from tldfyi.api import TLDFYI

with TLDFYI() as api:
    results = api.search("com")
    print(results)
```

## License

MIT
