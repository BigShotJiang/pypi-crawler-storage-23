from typing import Deque

SourceCode = Deque[str]
