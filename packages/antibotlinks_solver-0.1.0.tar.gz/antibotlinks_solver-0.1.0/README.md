# antibotlinks-solver

captcha solver for antibotlinks challenges  
(Shadow removal + Noise filtering + OCR + Fuzzy order matching)

![antibotlinks](https://github.com/user-attachments/assets/770c9357-dcab-4a62-8db3-516755d1e725)

## Requirements
- Ollama running with `glm-ocr` model

## Installation

```bash
pip install antibotlinks-solver
```

## Quick Usage Example

```python
from antibotlinks_solver import AntibotSolver

solver = AntibotSolver()

# Input: base64 data URLs of the images (main + 4 puzzle pieces)
# Example format: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUg..."

result = solver.solve(main_b64, a_b64, b_b64, c_b64, d_b64)

print("Click order:", result)
# Possible output: ['d', 'c', 'a', 'b']
```
