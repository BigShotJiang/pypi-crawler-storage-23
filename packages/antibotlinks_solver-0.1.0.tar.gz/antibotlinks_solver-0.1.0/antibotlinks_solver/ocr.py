import re
import ollama

class OCR:
    def __init__(self, model_name="glm-ocr"):
        self.model_name = model_name

    def clean_text(self, raw_text, is_main=False):
        text = re.sub(r'[^\x20-\x7E]', '@', raw_text)
        text = text.lower()

        replace_dict = {
            "0": "o",
            "1": "l",
            "3": "e",
            "5": "s",
            "@": "a",
            "!": "i",
            "+": "t",
            "$": "s",
            "'": "",
        }
        for old, new in replace_dict.items():
            text = text.replace(old, new)

        if not is_main:
            text = text.replace(' ', '')
            return text

        text = text.replace(';', ' ')
        text = text.replace(',', ' ')
        text = re.sub(r'\s+', ' ', text).strip()
        return text.split()

    def extract(self, image_base64, is_main=False):
        response = ollama.chat(
            model=self.model_name,
            keep_alive=-1,
            messages=[
                {
                    "role": "user",
                    "content": "Text Recognition:",
                    "images": [image_base64]
                }
            ],
            options={
                "temperature": 0.0,
                "num_ctx": 4096,
            }
        )

        raw_text = response['message']['content'].strip()

        return self.clean_text(raw_text, is_main)