from thefuzz import process

class OrderFinder:
    def __init__(self):
        pass

    def find_order(self, main_list, a, b, c, d):
        variables = [('a', a), ('b', b), ('c', c), ('d', d)]
        
        ordered = []
        for name, value in variables:
            if not value or not isinstance(value, str):
                continue
                
            best_match, score = process.extractOne(value, main_list)
            
            index = main_list.index(best_match)
            ordered.append((index, name))
        
        ordered.sort(key=lambda x: x[0])
        
        final_order = [name for _, name in ordered]
        
        return final_order