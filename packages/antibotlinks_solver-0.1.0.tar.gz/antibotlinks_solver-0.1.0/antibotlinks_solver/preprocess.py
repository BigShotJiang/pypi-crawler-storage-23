import cv2
import base64
import numpy as np
from sklearn.cluster import KMeans


class Preprocessor:
    def __init__(self, config=None):
        self.config = config or {}
        self.n_clusters = self.config.get('n_clusters', 3)
        self.tolerance_percent = self.config.get('tolerance_percent', 10)
        self.max_noise_area = self.config.get('max_noise_area', 3)
        self.connectivity = self.config.get('connectivity', 4)


    def remove_shadow(self, image):
        bgr = image[..., :3]
        alpha = image[..., 3]

        mask = alpha > 0
        pixels = bgr[mask]

        pixels = np.float32(pixels)

        # KMeans
        kmeans = KMeans(n_clusters=self.n_clusters, random_state=42, n_init=10)
        kmeans.fit(pixels)

        colors = kmeans.cluster_centers_
        labels = kmeans.labels_

        counts = np.bincount(labels)

        sorted_idx = np.argsort(-counts)

        brightness_values = [np.mean(c) for c in colors]

        shadow_index = np.argmax(brightness_values)

        shadow_color = colors[shadow_index]

        target_color = np.array(shadow_color, dtype=np.float32)   # BGR

        # tolerance in percentage (e.g. 10%)
        max_distance = (self.tolerance_percent / 100) * 441.67          # ≈ √(255²×3)

        # Calculate the Euclidean distance of each pixel to the target color
        diff = image[..., :3].astype(np.float32) - target_color
        dist = np.sqrt(np.sum(diff * diff, axis=2))

        # Mask: pixels whose distance is less than max_distance
        mask = dist < max_distance

        # Remove Color → Make Transparent (Alpha = 0)
        without_shadow = image.copy()
        without_shadow[mask] = [0, 0, 0, 0]   # B,G,R,A

        return without_shadow


    def remove_noise(self, image):
        alpha = image[:, :, 3].copy()

        binary = (alpha > 25).astype(np.uint8)

        num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=self.connectivity)

        without_noise = image.copy()
        for i in range(1, num_labels):
            if stats[i, cv2.CC_STAT_AREA] <= self.max_noise_area:
                without_noise[labels == i, 3] = 0
        
        return without_noise


    def process(self, image_src):
        image_base64 = image_src.split(',')[1]
        img_bytes = base64.b64decode(image_base64)
        nparr = np.frombuffer(img_bytes, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_UNCHANGED)

        without_shadow = self.remove_shadow(image)
        without_noise  = self.remove_noise(without_shadow)

        bgr = without_noise[:, :, :3]
        alpha = without_noise[:, :, 3] / 255.0

        white_bg = np.ones_like(bgr, dtype=np.uint8) * 255

        # blend
        blended = (bgr * alpha[..., None] + white_bg * (1 - alpha[..., None])).astype(np.uint8)
        blended_gray = cv2.cvtColor(blended, cv2.COLOR_BGR2GRAY)

        _, buffer = cv2.imencode('.png', blended_gray)
        image_base64 = base64.b64encode(buffer).decode('utf-8')

        return image_base64