from .preprocess import Preprocessor
from .ocr import OCR
from .order import OrderFinder

class AntibotSolver:
    def __init__(self):
        self.preprocessor = Preprocessor()
        self.ocr          = OCR()
        self.order_finder = OrderFinder()

    def solve(self, main, a, b, c, d):
        main_b64 = self.preprocessor.process(main)
        a_b64    = self.preprocessor.process(a)
        b_b64    = self.preprocessor.process(b)
        c_b64    = self.preprocessor.process(c)
        d_b64    = self.preprocessor.process(d)

        main_list = self.ocr.extract(main_b64, True)
        a_clean   = self.ocr.extract(a_b64, False)
        b_clean   = self.ocr.extract(b_b64, False)
        c_clean   = self.ocr.extract(c_b64, False)
        d_clean   = self.ocr.extract(d_b64, False)

        return self.order_finder.find_order(main_list, a_clean, b_clean, c_clean, d_clean)