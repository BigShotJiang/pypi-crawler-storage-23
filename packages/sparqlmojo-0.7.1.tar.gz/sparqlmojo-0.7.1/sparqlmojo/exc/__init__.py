"""
SPARQLMojo exceptions package.

This package contains the custom exception hierarchy for SPARQLMojo ORM.
"""

from .exceptions import (
    SPARQLMojoError,
    ConfigurationError,
    ValidationError,
    ModelError,
    FieldError,
    UnknownFieldError,
    RequiredFieldError,
    SessionError,
    ConnectionError,
    QueryError,
    SPARQLSyntaxError,
    IRIError,
)

__all__ = [
    "SPARQLMojoError",
    "ConfigurationError",
    "ValidationError",
    "ModelError",
    "FieldError",
    "UnknownFieldError",
    "RequiredFieldError",
    "SessionError",
    "ConnectionError",
    "QueryError",
    "SPARQLSyntaxError",
    "IRIError",
]
