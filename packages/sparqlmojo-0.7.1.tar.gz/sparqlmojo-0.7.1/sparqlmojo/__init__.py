"""
SPARQLMojo - A minimal SQLAlchemy-like ORM for SPARQL endpoints.

Top-level package exposing Model, Field types, Session, and Query components.
"""

from importlib.metadata import PackageNotFoundError, version

from .engine import Session
from .exc import (
    ConfigurationError,
    ConnectionError,
    FieldError,
    IRIError,
    ModelError,
    QueryError,
    RequiredFieldError,
    SPARQLMojoError,
    SessionError,
    SPARQLSyntaxError,
    UnknownFieldError,
    ValidationError,
)
from .orm.security import (
    InvalidIRIError,
    InvalidOperatorError,
    SPARQLInjectionError,
    SPARQLSecurityError,
)
from .orm import (
    Condition,
    IRI,
    IRIField,
    IRIList,
    LangLiteral,
    LangString,
    LangStringList,
    Literal,
    LiteralField,
    LiteralList,
    Model,
    MultiLangString,
    ObjectPropertyField,
    PropertyPath,
    Query,
    RDF_TYPE,
    RDFFieldInfo,
    SPARQLCompiler,
    SubjectField,
    TypedLiteral,
    TypedLiteralList,
    XSD,
    XSD_BOOLEAN,
    XSD_DATE,
    XSD_DATETIME,
    XSD_DECIMAL,
    XSD_DOUBLE,
    XSD_FLOAT,
    XSD_INTEGER,
    XSD_STRING,
    is_collection_field,
)


def _get_version() -> str:
    """Get package version from installed package metadata.

    Version is set in pyproject.toml and can be updated via `poetry version`.
    When package is not installed, returns development fallback.
    """
    try:
        return version("sparqlmojo")
    except PackageNotFoundError:
        return "0.0.0.dev0"


__version__: str = _get_version()
__author__: str = "oliver"
__license__: str = "MIT"

__all__ = [
    "__version__",
    "__author__",
    "__license__",
    # Exceptions
    "SPARQLMojoError",
    "ConfigurationError",
    "ValidationError",
    "ModelError",
    "FieldError",
    "UnknownFieldError",
    "RequiredFieldError",
    "SessionError",
    "ConnectionError",
    "QueryError",
    "SPARQLSyntaxError",
    "IRIError",
    # Security Exceptions
    "SPARQLSecurityError",
    "SPARQLInjectionError",
    "InvalidIRIError",
    "InvalidOperatorError",
    # ORM Components
    "Model",
    "RDFFieldInfo",
    "LiteralField",
    "IRIField",
    "ObjectPropertyField",
    "SubjectField",
    "RDF_TYPE",
    "LangString",
    "MultiLangString",
    "PropertyPath",
    "Session",
    "SPARQLCompiler",
    "Query",
    "Condition",
    # Value types (RDF objects)
    "IRI",
    "Literal",
    "LangLiteral",
    "TypedLiteral",
    # Collection field types
    "LiteralList",
    "LangStringList",
    "IRIList",
    "TypedLiteralList",
    "is_collection_field",
    # XSD datatype enum and constants
    "XSD",
    "XSD_STRING",
    "XSD_INTEGER",
    "XSD_DECIMAL",
    "XSD_FLOAT",
    "XSD_DOUBLE",
    "XSD_BOOLEAN",
    "XSD_DATE",
    "XSD_DATETIME",
]
