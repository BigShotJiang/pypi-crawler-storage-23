"""
ORM layer for SPARQLMojo.

Provides declarative models and query compilation.
"""

from .compiler import Condition, Query, SPARQLCompiler
from .filtering import (
    CollectionContainsExpression,
    CollectionFieldFilter,
    FieldFilter,
    FilterExpression,
    FilterLike,
    FilterOperator,
    LogicalExpression,
    LogicalOperator,
    StringExpression,
    StringFunctionWrapper,
    and_,
    not_,
    or_,
)
from .model import (
    IRIField,
    IRIList,
    LangString,
    LangStringList,
    LiteralField,
    LiteralList,
    Model,
    MultiLangString,
    ObjectPropertyField,
    PropertyPath,
    RDF_TYPE,
    RDFFieldInfo,
    SubjectField,
    TypedLiteralList,
    XSD,
    XSD_BOOLEAN,
    XSD_DATE,
    XSD_DATETIME,
    XSD_DECIMAL,
    XSD_DOUBLE,
    XSD_FLOAT,
    XSD_INTEGER,
    XSD_STRING,
    is_collection_field,
)
from .values import IRI, LangLiteral, Literal, TypedLiteral

__all__ = [
    "Model",
    "RDFFieldInfo",
    "LiteralField",
    "IRIField",
    "ObjectPropertyField",
    "SubjectField",
    "RDF_TYPE",
    "LangString",
    "MultiLangString",
    # Value types (RDF objects)
    "IRI",
    "Literal",
    "LangLiteral",
    "TypedLiteral",
    # Collection field types
    "LiteralList",
    "LangStringList",
    "IRIList",
    "TypedLiteralList",
    "is_collection_field",
    # XSD datatype enum and constants
    "XSD",
    "XSD_STRING",
    "XSD_INTEGER",
    "XSD_DECIMAL",
    "XSD_FLOAT",
    "XSD_DOUBLE",
    "XSD_BOOLEAN",
    "XSD_DATE",
    "XSD_DATETIME",
    # Query and compilation
    "Query",
    "Condition",
    "PropertyPath",
    "SPARQLCompiler",
    # Filtering
    "CollectionContainsExpression",
    "CollectionFieldFilter",
    "FilterExpression",
    "FilterLike",
    "FilterOperator",
    "LogicalExpression",
    "LogicalOperator",
    "StringExpression",
    "StringFunctionWrapper",
    "FieldFilter",
    "and_",
    "or_",
    "not_",
]
