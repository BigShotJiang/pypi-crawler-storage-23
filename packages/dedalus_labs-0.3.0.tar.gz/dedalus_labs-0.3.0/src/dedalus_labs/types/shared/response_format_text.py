# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["ResponseFormatText"]


class ResponseFormatText(BaseModel):
    """Default response format. Used to generate text responses.

    Fields:
    - type (required): Literal["text"]
    """

    type: Literal["text"]
    """The type of response format being defined. Always `text`."""
