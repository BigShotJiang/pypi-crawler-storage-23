# Chat completions structured outputs tests
