# Test fixtures for chat completions
