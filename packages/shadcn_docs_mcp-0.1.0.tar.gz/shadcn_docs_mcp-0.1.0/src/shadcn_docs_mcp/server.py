"""shadcn/ui documentation MCP server.

Two tools:
  shadcn_contents — table of contents (llms.txt) with relative links
  shadcn_page     — fetch a single doc page by relative path
"""

from __future__ import annotations

import re

import httpx
from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, ConfigDict, Field

BASE_URL = "https://ui.shadcn.com"

# Matches full shadcn URLs under /docs, optionally ending with .md
_HOST_RE = re.compile(
    r"https://ui\.shadcn\.com(/docs[^\s\)\]\"']*?)(?:\.md)?(?=[\s\)\]\"']|$)"
)

mcp = FastMCP(
    "shadcn_docs_mcp",
    instructions=(
        "shadcn/ui documentation server. "
        "Use shadcn_contents first to get the table of contents — "
        "it lists all available pages as relative paths like /docs/components/button. "
        "Then use shadcn_page with any path to read the full page. "
        "Pages contain component API references, install commands, code examples, "
        "and usage patterns for 50+ React components built with Tailwind CSS and Radix UI. "
        "Categories: installation, components (form, layout, overlay, feedback, display), "
        "theming, dark mode, forms (React Hook Form / TanStack Form), registry, and more."
    ),
)


def _to_relative(text: str) -> str:
    """Replace absolute ui.shadcn.com/docs/... URLs with relative /docs/... paths."""
    return _HOST_RE.sub(r"\1", text)


async def _fetch(url: str) -> str:
    """GET a URL and return the response body as text."""
    async with httpx.AsyncClient(follow_redirects=True, timeout=30.0) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        return resp.text


# ── Tools ────────────────────────────────────────────────────────────────────


@mcp.tool(
    name="shadcn_contents",
    annotations={
        "title": "shadcn/ui Table of Contents",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def shadcn_contents() -> str:
    """List all available shadcn/ui documentation pages.

    Returns the full table of contents from llms.txt organized by category:
    Overview, Installation, Components (Form & Input, Layout & Navigation,
    Overlays & Dialogs, Feedback & Status, Display & Media, Misc),
    Dark Mode, Forms, Monorepo, Tailwind v4, Registry, and more.

    Each entry is a markdown link with a relative path like /docs/components/button.
    Pass any path to shadcn_page to read the full page content.

    Call this first to discover what documentation is available.

    Returns:
        str: Markdown document with categorized links to all doc pages.
    """
    try:
        text = await _fetch(f"{BASE_URL}/llms.txt")
        return _to_relative(text)
    except httpx.HTTPStatusError as e:
        return f"Error: HTTP {e.response.status_code} fetching llms.txt"
    except httpx.TimeoutException:
        return "Error: Timed out fetching llms.txt. Try again."


class PageInput(BaseModel):
    """Input for shadcn_page."""

    model_config = ConfigDict(str_strip_whitespace=True)

    path: str = Field(
        ...,
        description=(
            "Relative doc path as shown in shadcn_contents output. "
            "Must start with /docs/. "
            "Examples: /docs/components/button, /docs/installation/next, "
            "/docs/theming, /docs/forms/react-hook-form"
        ),
        min_length=2,
        max_length=200,
    )


@mcp.tool(
    name="shadcn_page",
    annotations={
        "title": "shadcn/ui Doc Page",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def shadcn_page(params: PageInput) -> str:
    """Fetch a single shadcn/ui documentation page by its relative path.

    Downloads the raw markdown for the given path.  The returned content
    typically includes: frontmatter (title, description), installation
    commands, import examples, code samples for every variant, an API
    reference table, and links to related components.

    All absolute ui.shadcn.com links in the content are shortened to
    relative /docs/... paths so you can follow them with another
    shadcn_page call.

    Args:
        params (PageInput): Validated input containing:
            - path (str): Relative path starting with /docs/,
              e.g. /docs/components/button

    Returns:
        str: Full markdown content of the page with relative links.

    Errors:
        - "Error: Not found" if the page does not exist — use shadcn_contents
          to verify valid paths.
        - "Error: path must start with /docs" for invalid path format.
    """
    path = params.path.rstrip("/")
    if not path.startswith("/docs"):
        return f"Error: path must start with /docs — got '{path}'"

    url = f"{BASE_URL}{path}.md"
    try:
        text = await _fetch(url)
        return _to_relative(text)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return f"Error: Not found — {path}.md. Check path with shadcn_contents."
        return f"Error: HTTP {e.response.status_code} fetching {path}.md"
    except httpx.TimeoutException:
        return f"Error: Timed out fetching {path}.md. Try again."


# ── Entrypoint ───────────────────────────────────────────────────────────────


def main() -> None:
    """Run the MCP server (stdio transport)."""
    mcp.run()


if __name__ == "__main__":
    main()
