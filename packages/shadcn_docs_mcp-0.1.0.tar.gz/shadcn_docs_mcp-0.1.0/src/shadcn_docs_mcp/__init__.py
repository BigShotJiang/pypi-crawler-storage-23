"""MCP server for browsing shadcn/ui documentation."""

from shadcn_docs_mcp.server import main

__all__ = ["main"]
