# shadcn-docs-mcp

MCP server for browsing [shadcn/ui](https://ui.shadcn.com) documentation.

## Tools

| Tool | Description |
|------|-------------|
| `shadcn_contents` | Fetch the table of contents (`llms.txt`) with relative links |
| `shadcn_page` | Fetch a doc page by relative path (e.g. `/docs/components/button`) |

All absolute `ui.shadcn.com` URLs are converted to relative `/docs/...` paths.

## Install

```bash
uv sync
```

## Usage with Claude Code

### uvx (no install needed)

```bash
claude mcp add shadcn-docs -- uvx shadcn-docs-mcp
```

### From local checkout

```bash
claude mcp add shadcn-docs -- uv run --directory /path/to/shadcn-docs-mcp shadcn-docs-mcp
```

### .mcp.json

```json
{
  "mcpServers": {
    "shadcn-docs": {
      "type": "stdio",
      "command": "uvx",
      "args": ["shadcn-docs-mcp"]
    }
  }
}
```

## Development

```bash
uv sync
uv run shadcn-docs-mcp
```

Test with MCP Inspector:

```bash
npx @modelcontextprotocol/inspector uv run shadcn-docs-mcp
```
