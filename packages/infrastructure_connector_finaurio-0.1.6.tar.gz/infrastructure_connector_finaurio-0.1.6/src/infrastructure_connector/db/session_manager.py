# src/db/session_manager.py
from typing import Generator
from sqlalchemy.orm import Session
from infrastructure_connector.db.sqlalchemy_setup import get_session

def get_db_session() -> Generator[Session, None, None]:
    """Générateur pour obtenir une session SQLAlchemy."""
    session = get_session()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()