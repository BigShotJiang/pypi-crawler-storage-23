# src/infrastructure_connector/version.py
__version__ = "0.1.5"
__schema_version__ = __version__