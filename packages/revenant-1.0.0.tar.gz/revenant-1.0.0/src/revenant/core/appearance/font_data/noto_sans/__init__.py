# SPDX-License-Identifier: Apache-2.0
"""Noto Sans subset font data."""
