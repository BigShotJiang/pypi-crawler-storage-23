# SPDX-License-Identifier: Apache-2.0
"""GHEA Mariam subset font data."""
