# SPDX-License-Identifier: Apache-2.0
"""Bundled font data for PDF signature appearances.

Each subdirectory contains a subset TTF and generated metrics module for one font.
"""
