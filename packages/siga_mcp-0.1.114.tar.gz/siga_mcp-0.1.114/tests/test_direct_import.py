"""
Teste de importação direta para verificar o tratamento de erro.
"""

import asyncio
import sys
import os

# Adicionar diretório pai
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from siga_mcp.tools.os import editar_os_sistemas
from dotenv import load_dotenv

load_dotenv()


async def main():
    print("--- INICIANDO TESTE ---")

    # Executa a função
    resultado = await editar_os_sistemas(
        codigo_os="201969",
        data_solicitacao="11/11/2025 10:00:00",
        assunto="Teste Debug",
        descricao="Teste Debug",
        responsavel="24142",
        responsavel_atual="24142",
        matSolicitante="24142",
        criada_por="24142",
        # usuario_atual="24142" # O código pega de MATRICULA_USUARIO_ATUAL
    )

    print("\n--- RESULTADO ---")
    print(resultado)
    print("-----------------")


if __name__ == "__main__":
    asyncio.run(main())
