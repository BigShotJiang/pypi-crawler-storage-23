import asyncio
import sys
import os

# Adicionar o diretório pai ao path para importar o módulo siga_mcp
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from siga_mcp.tools.os import editar_os_sistemas

# Carrega ambiente
from dotenv import load_dotenv

load_dotenv()


async def main() -> str:
    """
    Teste da função editar_os_sistemas com JSON fornecido pelo usuário.
    """

    print("\n" + "*" * 50)
    print("TESTE DA FUNÇÃO editar_os_sistemas (DADOS USUÁRIO)")
    print("*" * 50 + "\n")

    # Parâmetros fornecidos pelo usuário
    # {
    #   "assunto": "teste",
    #   "codigo_os": 203036,
    #   "data_solicitacao": "10/02/2026 11:10",
    #   "descricao": "testando criação os pelo SIGA IA",
    #   "responsavel": "24142",
    #   "responsavel_atual": "25962",
    #   "criada_por": "24142",
    #   "matSolicitante": "24142",
    #   "tipo": "Implementação",
    #   "sistema": "Sistemas AVA",
    #   "equipe": "Equipe AVA",
    #   "linguagem": "PHP",
    #   "projeto": "Operação AVA",
    #   "status": "Em Atendimento",
    #   "origem": "Teams"
    # }

    resultado = await editar_os_sistemas(
        codigo_os=203036,
        data_solicitacao="10/02/2026 11:10:00",
        assunto="teste",
        descricao="testando criação os pelo SIGA IA",
        responsavel="24142",
        responsavel_atual="25962",
        criada_por="24142",
        matSolicitante="24142",
        tipo="Implementação",
        sistema="Sistemas AVA",
        equipe="Equipe AVA",
        linguagem="PHP",
        projeto="Operação AVA",
        status="Em Atendimento",
        origem="Teams",
    )

    print("\n[DEBUG] Resultado da função:")
    print("-" * 50)
    print(resultado)
    print("-" * 50)

    return resultado


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print("\nFIM")
