from textwrap import dedent


def docs() -> str:
    return dedent("""\
                Função que atualiza a memória do agente para lembrar qual é a jornada de trabalho do colaborador.
                """)
