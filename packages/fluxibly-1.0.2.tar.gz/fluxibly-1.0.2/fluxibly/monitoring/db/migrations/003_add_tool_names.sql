-- Migration 003: Add tool_names JSONB column to agent and LLM detail tables.
-- Stores the list of tool names/schemas sent to the LLM for each call.

ALTER TABLE monitoring.agent_call_details
    ADD COLUMN IF NOT EXISTS tool_names JSONB;

ALTER TABLE monitoring.llm_call_details
    ADD COLUMN IF NOT EXISTS tool_names JSONB;
