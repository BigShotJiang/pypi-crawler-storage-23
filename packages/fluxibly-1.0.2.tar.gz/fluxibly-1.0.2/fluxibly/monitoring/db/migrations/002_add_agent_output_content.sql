-- Add output_content JSONB column to agent_call_details
-- Stores the full structured LLMResponse from agent forward() calls.

ALTER TABLE monitoring.agent_call_details
    ADD COLUMN IF NOT EXISTS output_content JSONB;
