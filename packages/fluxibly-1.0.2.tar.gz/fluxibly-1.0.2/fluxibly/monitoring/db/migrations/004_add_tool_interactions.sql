-- Migration 004: Add tool_interactions column to agent_call_details
-- Stores the full list of tool call/result interactions from the agent loop

ALTER TABLE monitoring.agent_call_details
    ADD COLUMN IF NOT EXISTS tool_interactions JSONB;
