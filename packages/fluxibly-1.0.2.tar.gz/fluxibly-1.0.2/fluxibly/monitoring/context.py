"""Trace and span context for monitoring.

Immutable context objects propagated through the Agent/LLM call chain.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass(frozen=True)
class TraceContext:
    """Immutable context for a trace, propagated through the call chain."""

    trace_id: str
    service_name: str
    environment: str
    tags: dict[str, str] = field(default_factory=dict)
    created_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )


@dataclass(frozen=True)
class SpanContext:
    """Immutable context for a span."""

    span_id: str
    trace_id: str
    parent_span_id: str | None
    span_type: str  # 'agent' | 'llm' | 'tool'
    component_class: str
    component_name: str
    depth: int
    sequence_number: int = 0
    started_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
