"""Monitoring Dashboard for Fluxibly.

Provides a FastAPI-based web dashboard for inspecting
Agent/LLM telemetry data stored in PostgreSQL.
"""

from fluxibly.monitoring.dashboard.app import create_app

__all__ = ["create_app"]
