"""Monitoring module for Fluxibly.

Provides full observability into Agent and LLM interactions:
- MonitoringConfig: Configuration for data collection
- MonitoringCollector: Core instrumentation (trace/span management)
- AsyncDBWriter: Batched async database writes
- Dashboard: FastAPI web dashboard for inspection and analytics
"""

from fluxibly.monitoring.config import MonitoringConfig

__all__ = [
    "MonitoringConfig",
]
