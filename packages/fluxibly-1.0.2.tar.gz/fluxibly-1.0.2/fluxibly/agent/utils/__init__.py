"""Agent utilities — reusable helpers for agent implementations."""
