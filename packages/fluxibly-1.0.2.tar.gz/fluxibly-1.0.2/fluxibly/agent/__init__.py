"""Agent module for Fluxibly.

Public API:
- BaseAgent: Abstract base class for custom agent implementations
- SimpleAgent: The standard agent with tool calling, handoffs, and skills
- AgentTemplate: Copy-and-customize starting point for building new agents
- AgentConfig: Configuration model for agents
- AgentResponse: Standardized response from agent forward() calls
- HandoffConfig: Configuration for handoff targets
- Runner, RunnerResult: Top-level execution loop with session management
- create_agent, register_agent: Agent registry and factory
"""

from fluxibly.agent.agent_template import AgentTemplate
from fluxibly.agent.base import (
    AgentConfig,
    AgentResponse,
    BaseAgent,
    HandoffConfig,
)
from fluxibly.agent.multimodal_agent import MultimodalAgent
from fluxibly.agent.registry import create_agent, register_agent
from fluxibly.agent.runner import Runner, RunnerResult
from fluxibly.agent.simple_agent import SimpleAgent

__all__ = [
    "AgentConfig",
    "AgentResponse",
    "AgentTemplate",
    "BaseAgent",
    "HandoffConfig",
    "MultimodalAgent",
    "Runner",
    "RunnerResult",
    "SimpleAgent",
    "create_agent",
    "register_agent",
]
