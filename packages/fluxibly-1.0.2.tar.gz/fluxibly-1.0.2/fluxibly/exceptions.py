"""Custom exception hierarchy for Fluxibly.

All Fluxibly exceptions inherit from FluxiblyError.
"""


class FluxiblyError(Exception):
    """Base exception for all Fluxibly errors."""


class ConfigurationError(FluxiblyError):
    """Configuration loading or validation error."""


class LLMError(FluxiblyError):
    """LLM-related error."""


class LLMRetryExhaustedError(LLMError):
    """All retries exhausted for LLM call."""


class LLMEmptyResponseError(LLMError):
    """LLM returned empty response."""


class LLMPrepareError(LLMError):
    """Error during LLM prepare()."""


class UnsupportedContentTypeError(LLMError):
    """Provider does not support the given content type."""


class ToolError(FluxiblyError):
    """Tool execution error."""


class MCPError(ToolError):
    """MCP-related error."""


class MCPConnectionError(MCPError):
    """Failed to connect to MCP server."""


class MCPToolNotFoundError(MCPError):
    """MCP tool not found."""


class SandboxError(ToolError):
    """Sandbox execution error."""


class SandboxTimeoutError(SandboxError):
    """Sandboxed command timed out."""


class AgentError(FluxiblyError):
    """Agent-related error."""


class MonitoringError(FluxiblyError):
    """Monitoring-related error."""


class MonitoringDBError(MonitoringError):
    """Monitoring database connection or write error."""
