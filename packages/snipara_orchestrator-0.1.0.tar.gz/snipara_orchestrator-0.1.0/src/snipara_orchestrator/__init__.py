"""
Snipara Orchestrator - Production-first validation for AI agents.

Uses Snipara for context, implements validation gates locally.

Install: pip install snipara-orchestrator
CLI: snipara-orchestrator --help
"""

from snipara_orchestrator.models import (
    Task,
    TaskStatus,
    Proof,
    ValidationCriteria,
    DriftReport,
)
from snipara_orchestrator.orchestrator import Orchestrator
from snipara_orchestrator.gates.gatekeeper import Gatekeeper
from snipara_orchestrator.integrations.snipara import SniparaClient

__version__ = "0.1.0"

__all__ = [
    "Orchestrator",
    "Gatekeeper",
    "SniparaClient",
    "Task",
    "TaskStatus",
    "Proof",
    "ValidationCriteria",
    "DriftReport",
]
