"""CLI for the agentic orchestrator."""

import asyncio
import json
import os
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from snipara_orchestrator.models import LiveCheck, OrchestratorConfig, Task, ValidationCriteria
from snipara_orchestrator.orchestrator import Orchestrator

app = typer.Typer(
    name="agentic",
    help="Production-first agentic orchestrator with Snipara integration.",
    add_completion=False,
)

console = Console()


def get_config() -> OrchestratorConfig:
    """Load configuration from environment or config file."""
    config_path = Path.cwd() / ".agentic.json"

    if config_path.exists():
        with open(config_path) as f:
            data = json.load(f)
            return OrchestratorConfig(**data)

    # Load from environment
    api_key = os.environ.get("SNIPARA_API_KEY")
    project = os.environ.get("SNIPARA_PROJECT")
    prod_url = os.environ.get("PROD_URL")
    repo_path = os.environ.get("REPO_PATH", str(Path.cwd()))

    if not all([api_key, project, prod_url]):
        console.print("[red]Missing configuration.[/red]")
        console.print("Set environment variables or create .agentic.json:")
        console.print("  SNIPARA_API_KEY, SNIPARA_PROJECT, PROD_URL")
        raise typer.Exit(1)

    return OrchestratorConfig(
        snipara_api_key=api_key,  # type: ignore
        snipara_project=project,  # type: ignore
        prod_url=prod_url,  # type: ignore
        repo_path=repo_path,
    )


@app.command()
def init(
    project: str = typer.Option(None, "--project", "-p", help="Snipara project slug"),
    prod_url: str = typer.Option(None, "--prod-url", "-u", help="Production URL"),
):
    """Initialize configuration file."""
    config_path = Path.cwd() / ".agentic.json"

    if config_path.exists():
        overwrite = typer.confirm("Configuration already exists. Overwrite?")
        if not overwrite:
            raise typer.Exit(0)

    api_key = os.environ.get("SNIPARA_API_KEY") or typer.prompt(
        "Snipara API key", hide_input=True
    )
    project = project or typer.prompt("Snipara project slug")
    prod_url = prod_url or typer.prompt("Production URL (e.g., https://api.example.com)")

    config = {
        "snipara_api_key": api_key,
        "snipara_project": project,
        "prod_url": prod_url,
        "repo_path": str(Path.cwd()),
        "test_user": "test@example.com",
        "fail_fast_on_drift": True,
        "auto_remember": True,
        "verbose": True,
    }

    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)

    console.print(f"[green]Created {config_path}[/green]")
    console.print("[yellow]Remember to add .agentic.json to .gitignore![/yellow]")


@app.command()
def run(
    title: str = typer.Argument(..., help="Task title"),
    description: str = typer.Option("", "--description", "-d", help="Task description"),
    tests: Optional[list[str]] = typer.Option(None, "--test", "-t", help="Local test commands"),
    endpoints: Optional[list[str]] = typer.Option(None, "--endpoint", "-e", help="Live check URLs"),
    required_proofs: int = typer.Option(3, "--required-proofs", "-r", help="Minimum required proofs"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Quiet mode"),
):
    """Run a validation task."""
    config = get_config()
    config.verbose = not quiet

    # Build criteria
    criteria = ValidationCriteria(
        local_tests=list(tests) if tests else ["pnpm test", "pnpm lint"],
        live_checks=[LiveCheck(url=url) for url in (endpoints or [])],
        required_proofs=required_proofs,
    )

    task = Task(
        id=title.lower().replace(" ", "-"),
        title=title,
        description=description or title,
        criteria=criteria,
    )

    async def execute():
        orchestrator = Orchestrator(config)
        await orchestrator.initialize()
        result = await orchestrator.execute_task(task)
        return result

    result = asyncio.run(execute())

    # Exit with appropriate code
    if result.status.value in ("done", "prod_ok"):
        raise typer.Exit(0)
    else:
        raise typer.Exit(1)


@app.command()
def check_drift(
    routes: Optional[list[str]] = typer.Option(None, "--route", "-r", help="Routes to check"),
    check_schema: bool = typer.Option(True, "--schema/--no-schema", help="Check schema drift"),
    check_health: bool = typer.Option(True, "--health/--no-health", help="Check health endpoints"),
):
    """Check for environment drift."""
    from snipara_orchestrator.drift_detector import DriftDetector
    from snipara_orchestrator.executor import Executor

    config = get_config()

    async def check():
        executor = Executor(working_dir=config.repo_path)
        detector = DriftDetector(
            prod_url=config.prod_url,
            repo_path=config.repo_path,
            executor=executor,
        )

        report = await detector.full_drift_check(
            routes=list(routes) if routes else None,
            check_schema=check_schema,
            check_health=check_health,
        )

        return report

    report = asyncio.run(check())

    if report.has_drift:
        console.print(Panel(
            "\n".join(f"• {issue}" for issue in report.issues),
            title="[red]Drift Detected[/red]",
            border_style="red",
        ))
        console.print("\n[bold]Recommendations:[/bold]")
        for rec in report.recommendations:
            console.print(f"  → {rec}")
        raise typer.Exit(1)
    else:
        console.print("[green]No drift detected[/green]")
        raise typer.Exit(0)


@app.command()
def validate(
    url: str = typer.Argument(..., help="URL to validate"),
    method: str = typer.Option("GET", "--method", "-m", help="HTTP method"),
    expected: int = typer.Option(200, "--expected", "-e", help="Expected status code"),
    user: str = typer.Option("test@example.com", "--user", "-u", help="Test user"),
):
    """Validate a single endpoint."""
    from snipara_orchestrator.models import LiveCheck, Proof
    from snipara_orchestrator.validator import Validator

    async def validate_endpoint():
        validator = Validator(test_user=user)
        check = LiveCheck(url=url, method=method, expected_status=expected)
        proof = await validator.run_live_check(check)
        return proof

    proof = asyncio.run(validate_endpoint())

    if proof.passed:
        console.print(f"[green]✓ {url}[/green]")
        console.print(f"  Status: {proof.response_code}")
        raise typer.Exit(0)
    else:
        console.print(f"[red]✗ {url}[/red]")
        console.print(f"  Error: {proof.error_message}")
        raise typer.Exit(1)


@app.command()
def recall(
    query: str = typer.Argument(..., help="Query for memories"),
    limit: int = typer.Option(5, "--limit", "-l", help="Maximum memories to return"),
    type_filter: Optional[str] = typer.Option(None, "--type", "-t", help="Filter by type"),
):
    """Recall memories from Snipara."""
    from snipara_orchestrator.integrations.snipara import SniparaClient

    config = get_config()

    async def do_recall():
        client = SniparaClient(
            api_key=config.snipara_api_key,
            project_slug=config.snipara_project,
        )
        return await client.recall(query, limit=limit, type=type_filter)

    result = asyncio.run(do_recall())

    memories = result.get("memories", [])

    if not memories:
        console.print("[yellow]No memories found[/yellow]")
        raise typer.Exit(0)

    table = Table(title=f"Memories for: {query}")
    table.add_column("Type", style="cyan")
    table.add_column("Content")
    table.add_column("Score", justify="right")

    for mem in memories:
        table.add_row(
            mem.get("type", "unknown"),
            mem.get("content", "")[:60] + "...",
            f"{mem.get('relevance_score', 0):.2f}",
        )

    console.print(table)


@app.command()
def remember(
    content: str = typer.Argument(..., help="Content to remember"),
    type_: str = typer.Option("decision", "--type", "-t", help="Memory type"),
    category: str = typer.Option("orchestrator", "--category", "-c", help="Category"),
    ttl: int = typer.Option(30, "--ttl", help="Days until expiration"),
):
    """Store a memory in Snipara."""
    from snipara_orchestrator.integrations.snipara import SniparaClient

    config = get_config()

    async def do_remember():
        client = SniparaClient(
            api_key=config.snipara_api_key,
            project_slug=config.snipara_project,
        )
        return await client.remember(content, type=type_, category=category, ttl_days=ttl)

    result = asyncio.run(do_remember())

    console.print(f"[green]Stored memory: {result.get('memory_id', 'unknown')}[/green]")


@app.command()
def status():
    """Show orchestrator status and configuration."""
    try:
        config = get_config()

        console.print(Panel(
            f"[bold]Project:[/bold] {config.snipara_project}\n"
            f"[bold]Prod URL:[/bold] {config.prod_url}\n"
            f"[bold]Repo Path:[/bold] {config.repo_path}\n"
            f"[bold]Test User:[/bold] {config.test_user}\n"
            f"[bold]Fail Fast on Drift:[/bold] {config.fail_fast_on_drift}\n"
            f"[bold]Auto Remember:[/bold] {config.auto_remember}",
            title="Orchestrator Configuration",
            border_style="blue",
        ))

    except typer.Exit:
        console.print("[red]No configuration found[/red]")
        console.print("Run `agentic init` to create configuration")


if __name__ == "__main__":
    app()
