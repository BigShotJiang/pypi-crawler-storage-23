"""Integrations with external services."""

from snipara_orchestrator.integrations.snipara import SniparaClient

__all__ = ["SniparaClient"]
