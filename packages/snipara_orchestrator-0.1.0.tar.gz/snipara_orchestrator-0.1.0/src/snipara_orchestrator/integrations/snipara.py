"""Snipara MCP client for context and memory."""

from typing import Any, Optional

import httpx


class SniparaClient:
    """
    Wrapper for Snipara MCP tools.

    Provides context optimization, memory persistence, and swarm coordination.
    """

    def __init__(
        self,
        api_key: str,
        project_slug: str,
        base_url: str = "https://api.snipara.com",
        timeout: float = 60.0,
    ):
        self.base_url = f"{base_url}/mcp/{project_slug}"
        self.headers = {"X-API-Key": api_key, "Content-Type": "application/json"}
        self.timeout = timeout
        self._request_id = 0

    async def _call_tool(self, tool: str, args: dict[str, Any]) -> dict[str, Any]:
        """Make an MCP tool call."""
        self._request_id += 1

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                self.base_url,
                headers=self.headers,
                json={
                    "jsonrpc": "2.0",
                    "id": self._request_id,
                    "method": "tools/call",
                    "params": {"name": tool, "arguments": args},
                },
            )
            response.raise_for_status()
            result = response.json()

            if "error" in result:
                raise SniparaError(result["error"].get("message", "Unknown error"))

            return result.get("result", {})

    # === CONTEXT TOOLS ===

    async def query_context(
        self,
        query: str,
        max_tokens: int = 6000,
        search_mode: str = "hybrid",
    ) -> dict[str, Any]:
        """
        Get relevant documentation context.

        Args:
            query: The question or topic to search for
            max_tokens: Maximum tokens to return
            search_mode: "keyword", "semantic", or "hybrid"

        Returns:
            Ranked sections with relevance scores
        """
        return await self._call_tool(
            "rlm_context_query",
            {
                "query": query,
                "max_tokens": max_tokens,
                "search_mode": search_mode,
            },
        )

    async def ask(self, question: str) -> dict[str, Any]:
        """Quick query with default token budget."""
        return await self._call_tool("rlm_ask", {"query": question})

    async def search(self, pattern: str, max_results: int = 20) -> dict[str, Any]:
        """Search documentation with regex pattern."""
        return await self._call_tool(
            "rlm_search",
            {"pattern": pattern, "max_results": max_results},
        )

    async def get_deployment_docs(self) -> dict[str, Any]:
        """Get deployment-specific documentation."""
        return await self.query_context(
            query="deployment checklist production validation live checks",
            max_tokens=4000,
        )

    # === MEMORY TOOLS ===

    async def remember(
        self,
        content: str,
        type: str = "decision",
        category: str = "orchestrator",
        ttl_days: int = 30,
    ) -> dict[str, Any]:
        """
        Store a memory for later recall.

        Args:
            content: The memory content
            type: "fact", "decision", "learning", "preference", "todo", "context"
            category: Category for grouping
            ttl_days: Days until expiration
        """
        return await self._call_tool(
            "rlm_remember",
            {
                "text": content,
                "type": type,
                "category": category,
                "ttl_days": ttl_days,
            },
        )

    async def recall(
        self,
        query: str,
        limit: int = 5,
        type: Optional[str] = None,
        category: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        Recall relevant memories.

        Args:
            query: Search query for semantic matching
            limit: Maximum memories to return
            type: Filter by memory type
            category: Filter by category
        """
        args: dict[str, Any] = {"query": query, "limit": limit}
        if type:
            args["type"] = type
        if category:
            args["category"] = category
        return await self._call_tool("rlm_recall", args)

    async def list_memories(
        self,
        limit: int = 20,
        type: Optional[str] = None,
        category: Optional[str] = None,
    ) -> dict[str, Any]:
        """List memories with optional filters."""
        args: dict[str, Any] = {"limit": limit}
        if type:
            args["type"] = type
        if category:
            args["category"] = category
        return await self._call_tool("rlm_memories", args)

    # === SWARM TOOLS ===

    async def create_swarm(
        self,
        name: str,
        description: str,
        max_agents: int = 10,
    ) -> dict[str, Any]:
        """Create a swarm for multi-agent coordination."""
        return await self._call_tool(
            "rlm_swarm_create",
            {
                "name": name,
                "description": description,
                "max_agents": max_agents,
            },
        )

    async def join_swarm(
        self,
        swarm_id: str,
        agent_id: str,
        role: str = "worker",
        capabilities: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """Join an existing swarm."""
        return await self._call_tool(
            "rlm_swarm_join",
            {
                "swarm_id": swarm_id,
                "agent_id": agent_id,
                "role": role,
                "capabilities": capabilities or [],
            },
        )

    async def create_task(
        self,
        swarm_id: str,
        agent_id: str,
        title: str,
        description: str = "",
        priority: int = 0,
        depends_on: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """Create a task in the swarm queue."""
        return await self._call_tool(
            "rlm_task_create",
            {
                "swarm_id": swarm_id,
                "agent_id": agent_id,
                "title": title,
                "description": description,
                "priority": priority,
                "depends_on": depends_on or [],
            },
        )

    async def complete_task(
        self,
        swarm_id: str,
        agent_id: str,
        task_id: str,
        success: bool,
        result: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Complete a task with result."""
        return await self._call_tool(
            "rlm_task_complete",
            {
                "swarm_id": swarm_id,
                "agent_id": agent_id,
                "task_id": task_id,
                "success": success,
                "result": result or {},
            },
        )

    async def set_state(
        self,
        swarm_id: str,
        agent_id: str,
        key: str,
        value: Any,
    ) -> dict[str, Any]:
        """Store shared state in the swarm."""
        return await self._call_tool(
            "rlm_state_set",
            {
                "swarm_id": swarm_id,
                "agent_id": agent_id,
                "key": key,
                "value": value,
            },
        )

    async def get_state(self, swarm_id: str, key: str) -> dict[str, Any]:
        """Get shared state from the swarm."""
        return await self._call_tool(
            "rlm_state_get",
            {"swarm_id": swarm_id, "key": key},
        )

    async def broadcast(
        self,
        swarm_id: str,
        agent_id: str,
        event_type: str,
        payload: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Broadcast an event to all swarm agents."""
        return await self._call_tool(
            "rlm_broadcast",
            {
                "swarm_id": swarm_id,
                "agent_id": agent_id,
                "event_type": event_type,
                "payload": payload or {},
            },
        )

    # === UTILITY TOOLS ===

    async def stats(self) -> dict[str, Any]:
        """Get project statistics."""
        return await self._call_tool("rlm_stats", {})

    async def inject_context(self, context: str, append: bool = False) -> dict[str, Any]:
        """Inject session context for subsequent queries."""
        return await self._call_tool(
            "rlm_inject",
            {"context": context, "append": append},
        )

    async def clear_context(self) -> dict[str, Any]:
        """Clear session context."""
        return await self._call_tool("rlm_clear_context", {})


class SniparaError(Exception):
    """Error from Snipara API."""

    pass
