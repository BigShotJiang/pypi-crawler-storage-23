"""Data models for the agentic orchestrator."""

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class TaskStatus(str, Enum):
    """Task lifecycle states."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    LOCAL_OK = "local_ok"
    LOCAL_FAIL = "local_fail"
    VALIDATING = "validating"
    PROD_OK = "prod_ok"
    PROD_FAIL = "prod_fail"
    ENV_DRIFT = "env_drift"
    DONE = "done"


class Proof(BaseModel):
    """Standard proof of validation."""

    endpoint: str
    user_tested: str
    result: str  # "pass" | "fail"
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    response_code: Optional[int] = None
    response_body: Optional[dict[str, Any]] = None
    screenshot_path: Optional[str] = None
    error_message: Optional[str] = None

    @property
    def passed(self) -> bool:
        """Check if proof passed."""
        return self.result == "pass"


class LiveCheck(BaseModel):
    """Configuration for a live endpoint check."""

    url: str
    method: str = "GET"
    expected_status: int = 200
    headers: dict[str, str] = Field(default_factory=dict)
    body: Optional[dict[str, Any]] = None
    timeout: float = 30.0


class ValidationCriteria(BaseModel):
    """Validation criteria for a task."""

    local_tests: list[str] = Field(default_factory=list)
    live_checks: list[LiveCheck] = Field(default_factory=list)
    ui_tests: list[str] = Field(default_factory=list)
    required_proofs: int = 3

    def total_checks(self) -> int:
        """Total number of validation checks."""
        return len(self.live_checks) + len(self.ui_tests)


class Task(BaseModel):
    """Task with state and proofs."""

    id: str
    title: str
    description: str
    status: TaskStatus = TaskStatus.PENDING
    criteria: ValidationCriteria = Field(default_factory=ValidationCriteria)
    proofs: list[Proof] = Field(default_factory=list)
    swarm_task_id: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    error: Optional[str] = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    def passing_proofs(self) -> list[Proof]:
        """Get all passing proofs."""
        return [p for p in self.proofs if p.passed]

    def failing_proofs(self) -> list[Proof]:
        """Get all failing proofs."""
        return [p for p in self.proofs if not p.passed]

    def has_minimum_proofs(self) -> bool:
        """Check if minimum passing proofs are met."""
        return len(self.passing_proofs()) >= self.criteria.required_proofs

    def all_proofs_pass(self) -> bool:
        """Check if all proofs pass."""
        return len(self.proofs) > 0 and all(p.passed for p in self.proofs)


class DriftReport(BaseModel):
    """Report of environment drift detection."""

    has_drift: bool
    issues: list[str] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)
    checked_at: datetime = Field(default_factory=datetime.utcnow)

    def summary(self) -> str:
        """Get a summary of the drift report."""
        if not self.has_drift:
            return "No drift detected"
        return f"{len(self.issues)} issues found: {', '.join(self.issues[:3])}"


class CutoverCheck(BaseModel):
    """A single check in the cutover checklist."""

    name: str
    description: str
    check: LiveCheck
    required: bool = True


class CutoverChecklist(BaseModel):
    """Auto-generated cutover checklist."""

    task_id: str
    generated_at: datetime = Field(default_factory=datetime.utcnow)
    generated_by: str
    checks: list[CutoverCheck] = Field(default_factory=list)
    context_from_snipara: list[dict[str, Any]] = Field(default_factory=list)


class OrchestratorConfig(BaseModel):
    """Configuration for the orchestrator."""

    snipara_api_key: str
    snipara_project: str
    prod_url: str
    repo_path: str
    test_user: str = "test@example.com"
    gatekeeper_id: str = "orchestrator-gatekeeper"
    fail_fast_on_drift: bool = True
    auto_remember: bool = True
    verbose: bool = True
