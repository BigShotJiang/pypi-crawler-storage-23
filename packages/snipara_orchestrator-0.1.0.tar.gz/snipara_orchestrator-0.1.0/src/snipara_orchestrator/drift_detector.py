"""Drift detector for environment and schema drift detection."""

import asyncio
from datetime import datetime
from typing import Optional
from urllib.parse import urlparse

import httpx

from snipara_orchestrator.executor import Executor
from snipara_orchestrator.models import DriftReport


class DriftDetector:
    """
    Detects drift between repository and production environment.

    Implements fail-fast on drift pattern:
    - Route drift: API endpoints that differ between repo and prod
    - Schema drift: Database schema differences
    - Config drift: Environment configuration differences
    """

    def __init__(
        self,
        prod_url: str,
        repo_path: str,
        executor: Optional[Executor] = None,
    ):
        self.prod_url = prod_url.rstrip("/")
        self.repo_path = repo_path
        self.executor = executor or Executor(working_dir=repo_path)

    async def check_endpoint_accessible(self, endpoint: str) -> tuple[bool, Optional[int]]:
        """
        Check if an endpoint is accessible in production.

        Returns:
            Tuple of (is_accessible, status_code)
        """
        url = f"{self.prod_url}{endpoint}"

        async with httpx.AsyncClient(timeout=10.0) as client:
            try:
                response = await client.get(url)
                return True, response.status_code
            except Exception:
                return False, None

    async def check_route_drift(self, routes: list[str]) -> DriftReport:
        """
        Check for drift in API routes.

        Args:
            routes: List of route paths to check (e.g., ["/api/users", "/api/auth"])

        Returns:
            DriftReport with issues and recommendations
        """
        issues: list[str] = []
        recommendations: list[str] = []

        checks = []
        for route in routes:
            checks.append(self._check_single_route(route))

        results = await asyncio.gather(*checks)

        for route, (accessible, status) in zip(routes, results):
            if not accessible:
                issues.append(f"Route {route} not accessible in prod")
                recommendations.append(f"Verify deployment of route {route}")
            elif status == 404:
                issues.append(f"Route {route} returns 404 in prod")
                recommendations.append(f"Check if {route} exists in repo and redeploy")
            elif status and status >= 500:
                issues.append(f"Route {route} returns {status} (server error)")
                recommendations.append(f"Check logs for {route} errors")

        return DriftReport(
            has_drift=len(issues) > 0,
            issues=issues,
            recommendations=recommendations,
            checked_at=datetime.utcnow(),
        )

    async def _check_single_route(self, route: str) -> tuple[bool, Optional[int]]:
        """Check a single route."""
        return await self.check_endpoint_accessible(route)

    async def check_schema_drift(self) -> DriftReport:
        """
        Check for database schema drift using Prisma.

        Returns:
            DriftReport with schema issues
        """
        issues: list[str] = []
        recommendations: list[str] = []

        # Try to detect schema differences
        result = await self.executor.run_command(
            "npx prisma db pull --print",
            timeout=60.0,
        )

        if not result.success:
            if "error" in result.stderr.lower():
                issues.append(f"Schema drift check failed: {result.stderr[:200]}")
                recommendations.append("Verify DATABASE_URL and run prisma db push")

        # Check for pending migrations
        migration_result = await self.executor.run_command(
            "npx prisma migrate status",
            timeout=30.0,
        )

        if "pending" in migration_result.stdout.lower():
            issues.append("Pending migrations detected")
            recommendations.append("Run prisma migrate deploy to apply pending migrations")

        return DriftReport(
            has_drift=len(issues) > 0,
            issues=issues,
            recommendations=recommendations,
            checked_at=datetime.utcnow(),
        )

    async def check_health_endpoints(self) -> DriftReport:
        """
        Check standard health endpoints.

        Returns:
            DriftReport with health check issues
        """
        issues: list[str] = []
        recommendations: list[str] = []

        health_endpoints = ["/health", "/ready", "/healthz", "/api/health"]

        for endpoint in health_endpoints:
            accessible, status = await self.check_endpoint_accessible(endpoint)
            if accessible and status == 200:
                # Found a working health endpoint
                break
        else:
            issues.append("No health endpoint responding with 200")
            recommendations.append("Verify deployment and check /health or /ready endpoints")

        return DriftReport(
            has_drift=len(issues) > 0,
            issues=issues,
            recommendations=recommendations,
            checked_at=datetime.utcnow(),
        )

    async def check_version_drift(self) -> DriftReport:
        """
        Check if deployed version matches repository.

        Returns:
            DriftReport with version drift issues
        """
        issues: list[str] = []
        recommendations: list[str] = []

        # Try to get version from prod
        async with httpx.AsyncClient(timeout=10.0) as client:
            try:
                # Common version endpoints
                for endpoint in ["/version", "/api/version", "/_version"]:
                    response = await client.get(f"{self.prod_url}{endpoint}")
                    if response.status_code == 200:
                        prod_version = response.text.strip()

                        # Get local version (from package.json or pyproject.toml)
                        local_result = await self.executor.run_command(
                            "git rev-parse --short HEAD",
                            timeout=5.0,
                        )
                        local_version = local_result.stdout.strip()

                        if prod_version != local_version:
                            issues.append(
                                f"Version drift: prod={prod_version}, local={local_version}"
                            )
                            recommendations.append("Deploy latest version to production")
                        break
            except Exception:
                pass  # Version check is optional

        return DriftReport(
            has_drift=len(issues) > 0,
            issues=issues,
            recommendations=recommendations,
            checked_at=datetime.utcnow(),
        )

    async def full_drift_check(
        self,
        routes: Optional[list[str]] = None,
        check_schema: bool = True,
        check_health: bool = True,
        check_version: bool = False,
    ) -> DriftReport:
        """
        Perform a comprehensive drift check.

        Args:
            routes: List of routes to check (optional)
            check_schema: Whether to check schema drift
            check_health: Whether to check health endpoints
            check_version: Whether to check version drift

        Returns:
            Combined DriftReport
        """
        all_issues: list[str] = []
        all_recommendations: list[str] = []

        checks = []

        if routes:
            checks.append(self.check_route_drift(routes))

        if check_schema:
            checks.append(self.check_schema_drift())

        if check_health:
            checks.append(self.check_health_endpoints())

        if check_version:
            checks.append(self.check_version_drift())

        if checks:
            results = await asyncio.gather(*checks)

            for report in results:
                all_issues.extend(report.issues)
                all_recommendations.extend(report.recommendations)

        return DriftReport(
            has_drift=len(all_issues) > 0,
            issues=all_issues,
            recommendations=all_recommendations,
            checked_at=datetime.utcnow(),
        )

    def extract_routes_from_checks(self, prod_url: str, checks: list[dict]) -> list[str]:
        """
        Extract route paths from live check configurations.

        Args:
            prod_url: Production base URL
            checks: List of live check dicts

        Returns:
            List of route paths
        """
        routes = []
        for check in checks:
            url = check.get("url", "")
            if url.startswith(prod_url):
                route = url[len(prod_url) :]
                routes.append(route)
            elif url.startswith("/"):
                routes.append(url)
            else:
                parsed = urlparse(url)
                routes.append(parsed.path)
        return routes
