"""Gatekeeper - Single authority for validation decisions."""

from datetime import datetime
from typing import Any, Optional

from snipara_orchestrator.drift_detector import DriftDetector
from snipara_orchestrator.integrations.snipara import SniparaClient
from snipara_orchestrator.models import (
    CutoverCheck,
    CutoverChecklist,
    LiveCheck,
    Proof,
    Task,
    TaskStatus,
)
from snipara_orchestrator.validator import Validator


class GateResult:
    """Result of a gate check."""

    def __init__(
        self,
        passed: bool,
        message: str,
        details: Optional[dict[str, Any]] = None,
    ):
        self.passed = passed
        self.message = message
        self.details = details or {}

    def __bool__(self) -> bool:
        return self.passed

    def __repr__(self) -> str:
        status = "PASS" if self.passed else "FAIL"
        return f"GateResult({status}: {self.message})"


class Gatekeeper:
    """
    Single gatekeeper - the sole authority for validation decisions.

    No other agent can approve transitions to PROD_OK.
    Implements the "single gatekeeper" pattern.
    """

    def __init__(
        self,
        snipara: SniparaClient,
        validator: Validator,
        drift_detector: DriftDetector,
        gatekeeper_id: str = "orchestrator-gatekeeper",
        fail_fast_on_drift: bool = True,
        auto_remember: bool = True,
    ):
        self.snipara = snipara
        self.validator = validator
        self.drift_detector = drift_detector
        self.gatekeeper_id = gatekeeper_id
        self.fail_fast_on_drift = fail_fast_on_drift
        self.auto_remember = auto_remember

    async def gate_local_to_validation(self, task: Task) -> GateResult:
        """
        Gate 1: LOCAL_OK → VALIDATING

        Checks:
        - Task is in LOCAL_OK status
        - No environment drift (if fail_fast_on_drift enabled)

        Args:
            task: Task to check

        Returns:
            GateResult with pass/fail and message
        """
        # Check current status
        if task.status != TaskStatus.LOCAL_OK:
            return GateResult(
                passed=False,
                message=f"Task must be LOCAL_OK, currently {task.status.value}",
            )

        # Check for environment drift
        if self.fail_fast_on_drift:
            routes = [
                check.url.replace(self.drift_detector.prod_url, "")
                for check in task.criteria.live_checks
            ]

            drift = await self.drift_detector.full_drift_check(
                routes=routes if routes else None,
                check_health=True,
            )

            if drift.has_drift:
                task.status = TaskStatus.ENV_DRIFT
                task.error = "\n".join(drift.issues)

                if self.auto_remember:
                    await self.snipara.remember(
                        content=f"ENV_DRIFT detected for task {task.id}: {drift.issues}",
                        type="learning",
                        category="drift",
                    )

                return GateResult(
                    passed=False,
                    message=f"ENV_DRIFT detected",
                    details={
                        "issues": drift.issues,
                        "recommendations": drift.recommendations,
                    },
                )

        return GateResult(
            passed=True,
            message="OK to proceed to validation",
        )

    async def gate_validation_to_prod(self, task: Task) -> GateResult:
        """
        Gate 2: VALIDATING → PROD_OK

        Checks:
        - Task is in VALIDATING status
        - Minimum required proofs are met
        - All proofs pass

        Args:
            task: Task to validate

        Returns:
            GateResult with pass/fail and message
        """
        # Check current status
        if task.status != TaskStatus.VALIDATING:
            return GateResult(
                passed=False,
                message=f"Task must be VALIDATING, currently {task.status.value}",
            )

        # Collect proofs if not already collected
        if not task.proofs:
            proofs = await self.validator.validate_task(task)
            task.proofs.extend(proofs)

        # Check minimum proofs
        passing_count = len([p for p in task.proofs if p.passed])
        required = task.criteria.required_proofs

        if passing_count < required:
            task.status = TaskStatus.PROD_FAIL
            return GateResult(
                passed=False,
                message=f"Insufficient proofs: {passing_count}/{required}",
                details={
                    "passing": passing_count,
                    "required": required,
                    "failing": [p.endpoint for p in task.proofs if not p.passed],
                },
            )

        # Check all pass
        failing = [p for p in task.proofs if not p.passed]
        if failing:
            task.status = TaskStatus.PROD_FAIL
            return GateResult(
                passed=False,
                message=f"Failed proofs: {len(failing)}",
                details={
                    "failing_endpoints": [p.endpoint for p in failing],
                    "errors": [p.error_message for p in failing if p.error_message],
                },
            )

        # All checks pass - PROD_OK
        task.status = TaskStatus.PROD_OK
        task.completed_at = datetime.utcnow()

        if self.auto_remember:
            await self.snipara.remember(
                content=f"Task {task.id} validated for prod by {self.gatekeeper_id}. Proofs: {len(task.proofs)}",
                type="decision",
                category="validation",
            )

        return GateResult(
            passed=True,
            message=f"PROD_OK - All {len(task.proofs)} validations passed",
            details={
                "proofs_collected": len(task.proofs),
                "validated_by": self.gatekeeper_id,
                "completed_at": task.completed_at.isoformat(),
            },
        )

    async def generate_cutover_checklist(self, task: Task) -> CutoverChecklist:
        """
        Generate an automatic cutover checklist.

        Combines:
        - Standard health checks
        - Task-specific checks
        - Context from Snipara documentation

        Args:
            task: Task to generate checklist for

        Returns:
            CutoverChecklist with all checks
        """
        checks: list[CutoverCheck] = []

        # Standard health checks
        standard_checks = [
            CutoverCheck(
                name="health_check",
                description="Verify health endpoint responds 200",
                check=LiveCheck(
                    url=f"{self.drift_detector.prod_url}/health",
                    expected_status=200,
                ),
            ),
            CutoverCheck(
                name="ready_check",
                description="Verify ready endpoint (DB + services)",
                check=LiveCheck(
                    url=f"{self.drift_detector.prod_url}/ready",
                    expected_status=200,
                ),
            ),
            CutoverCheck(
                name="root_path",
                description="Verify root path is accessible",
                check=LiveCheck(
                    url=f"{self.drift_detector.prod_url}/",
                    expected_status=200,
                ),
                required=False,  # May redirect
            ),
        ]
        checks.extend(standard_checks)

        # Task-specific checks
        for i, live_check in enumerate(task.criteria.live_checks):
            checks.append(
                CutoverCheck(
                    name=f"task_check_{i+1}",
                    description=f"Verify {live_check.url}",
                    check=live_check,
                )
            )

        # Get context from Snipara
        context_sections: list[dict[str, Any]] = []
        try:
            docs = await self.snipara.get_deployment_docs()
            context_sections = docs.get("sections", [])[:3]
        except Exception:
            pass  # Context is optional

        return CutoverChecklist(
            task_id=task.id,
            generated_at=datetime.utcnow(),
            generated_by=self.gatekeeper_id,
            checks=checks,
            context_from_snipara=context_sections,
        )

    async def run_cutover_checklist(
        self,
        checklist: CutoverChecklist,
    ) -> tuple[bool, list[Proof]]:
        """
        Execute a cutover checklist.

        Args:
            checklist: Checklist to execute

        Returns:
            Tuple of (all_pass, proofs)
        """
        proofs: list[Proof] = []
        all_pass = True

        for check in checklist.checks:
            proof = await self.validator.run_live_check(check.check)
            # Prefix endpoint with check name for clarity
            proof.endpoint = f"{check.name}: {proof.endpoint}"
            proofs.append(proof)

            if not proof.passed and check.required:
                all_pass = False

        return all_pass, proofs

    async def full_validation_flow(self, task: Task) -> tuple[bool, str]:
        """
        Run the complete validation flow.

        LOCAL_OK → VALIDATING → PROD_OK

        Args:
            task: Task to validate

        Returns:
            Tuple of (success, message)
        """
        # Gate 1: LOCAL_OK → VALIDATING
        gate1 = await self.gate_local_to_validation(task)
        if not gate1:
            return False, gate1.message

        task.status = TaskStatus.VALIDATING

        # Generate and run cutover checklist
        checklist = await self.generate_cutover_checklist(task)
        all_pass, proofs = await self.run_cutover_checklist(checklist)
        task.proofs.extend(proofs)

        # Gate 2: VALIDATING → PROD_OK
        gate2 = await self.gate_validation_to_prod(task)
        if not gate2:
            return False, gate2.message

        return True, gate2.message
