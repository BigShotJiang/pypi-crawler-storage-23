"""Validator for collecting proofs from live checks and UI tests."""

import asyncio
from datetime import datetime
from typing import Any, Optional

import httpx

from snipara_orchestrator.executor import Executor
from snipara_orchestrator.models import LiveCheck, Proof, Task


class Validator:
    """
    Collects validation proofs from live checks and UI tests.

    Implements the "contrat de preuve minimal" pattern:
    - endpoint tested
    - user tested
    - result (pass/fail)
    """

    def __init__(
        self,
        test_user: str = "test@example.com",
        timeout: float = 30.0,
        executor: Optional[Executor] = None,
    ):
        self.test_user = test_user
        self.timeout = timeout
        self.executor = executor or Executor()

    async def run_live_check(self, check: LiveCheck) -> Proof:
        """
        Execute a live check on an endpoint.

        Args:
            check: LiveCheck configuration

        Returns:
            Proof with result
        """
        async with httpx.AsyncClient(timeout=check.timeout) as client:
            try:
                response = await client.request(
                    method=check.method,
                    url=check.url,
                    headers=check.headers,
                    json=check.body if check.body else None,
                )

                passed = response.status_code == check.expected_status

                # Try to parse JSON response
                response_body: Optional[dict[str, Any]] = None
                content_type = response.headers.get("content-type", "")
                if "application/json" in content_type:
                    try:
                        response_body = response.json()
                    except Exception:
                        pass

                return Proof(
                    endpoint=check.url,
                    user_tested=self.test_user,
                    result="pass" if passed else "fail",
                    timestamp=datetime.utcnow(),
                    response_code=response.status_code,
                    response_body=response_body,
                    error_message=None if passed else f"Expected {check.expected_status}, got {response.status_code}",
                )

            except httpx.TimeoutException:
                return Proof(
                    endpoint=check.url,
                    user_tested=self.test_user,
                    result="fail",
                    timestamp=datetime.utcnow(),
                    error_message=f"Request timed out after {check.timeout}s",
                )

            except httpx.ConnectError as e:
                return Proof(
                    endpoint=check.url,
                    user_tested=self.test_user,
                    result="fail",
                    timestamp=datetime.utcnow(),
                    error_message=f"Connection error: {str(e)}",
                )

            except Exception as e:
                return Proof(
                    endpoint=check.url,
                    user_tested=self.test_user,
                    result="fail",
                    timestamp=datetime.utcnow(),
                    error_message=str(e),
                )

    async def run_ui_test(self, spec: str) -> Proof:
        """
        Execute a Playwright UI test.

        Args:
            spec: Path to the Playwright test spec

        Returns:
            Proof with result
        """
        # Run Playwright test
        result = await self.executor.run_command(
            f"npx playwright test {spec} --reporter=json",
            timeout=120.0,
        )

        return Proof(
            endpoint=f"ui:{spec}",
            user_tested=self.test_user,
            result="pass" if result.success else "fail",
            timestamp=datetime.utcnow(),
            response_body={
                "stdout": result.stdout[:2000],
                "stderr": result.stderr[:2000],
                "duration_ms": result.duration_ms,
            },
            error_message=result.stderr[:500] if not result.success else None,
        )

    async def run_all_live_checks(
        self,
        checks: list[LiveCheck],
        parallel: bool = True,
    ) -> list[Proof]:
        """
        Run all live checks.

        Args:
            checks: List of checks to run
            parallel: Run checks in parallel

        Returns:
            List of proofs
        """
        if parallel:
            tasks = [self.run_live_check(check) for check in checks]
            return await asyncio.gather(*tasks)
        else:
            proofs = []
            for check in checks:
                proof = await self.run_live_check(check)
                proofs.append(proof)
            return proofs

    async def run_all_ui_tests(
        self,
        specs: list[str],
        parallel: bool = False,
    ) -> list[Proof]:
        """
        Run all UI tests.

        Args:
            specs: List of test specs to run
            parallel: Run tests in parallel (careful with resources)

        Returns:
            List of proofs
        """
        if parallel:
            tasks = [self.run_ui_test(spec) for spec in specs]
            return await asyncio.gather(*tasks)
        else:
            proofs = []
            for spec in specs:
                proof = await self.run_ui_test(spec)
                proofs.append(proof)
            return proofs

    async def validate_task(self, task: Task, parallel: bool = True) -> list[Proof]:
        """
        Collect all proofs for a task.

        Args:
            task: Task to validate
            parallel: Run checks in parallel

        Returns:
            List of all proofs
        """
        proofs: list[Proof] = []

        # Run live checks
        if task.criteria.live_checks:
            live_proofs = await self.run_all_live_checks(
                task.criteria.live_checks,
                parallel=parallel,
            )
            proofs.extend(live_proofs)

        # Run UI tests (usually sequential to avoid resource conflicts)
        if task.criteria.ui_tests:
            ui_proofs = await self.run_all_ui_tests(
                task.criteria.ui_tests,
                parallel=False,
            )
            proofs.extend(ui_proofs)

        return proofs

    def has_minimum_proofs(self, task: Task) -> bool:
        """Check if task has minimum required passing proofs."""
        passing = [p for p in task.proofs if p.passed]
        return len(passing) >= task.criteria.required_proofs

    def all_proofs_pass(self, task: Task) -> bool:
        """Check if all proofs pass."""
        return len(task.proofs) > 0 and all(p.passed for p in task.proofs)

    def generate_proof_summary(self, proofs: list[Proof]) -> dict[str, Any]:
        """Generate a summary of proofs."""
        passing = [p for p in proofs if p.passed]
        failing = [p for p in proofs if not p.passed]

        return {
            "total": len(proofs),
            "passing": len(passing),
            "failing": len(failing),
            "pass_rate": len(passing) / len(proofs) if proofs else 0,
            "failing_endpoints": [p.endpoint for p in failing],
            "all_pass": len(failing) == 0 and len(proofs) > 0,
        }
