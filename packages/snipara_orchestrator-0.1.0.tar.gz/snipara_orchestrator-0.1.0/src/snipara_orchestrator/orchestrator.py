"""Main orchestrator - coordinates the full task lifecycle."""

import asyncio
from datetime import datetime
from typing import Any, Optional

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from snipara_orchestrator.drift_detector import DriftDetector
from snipara_orchestrator.executor import Executor
from snipara_orchestrator.gates.gatekeeper import Gatekeeper
from snipara_orchestrator.integrations.snipara import SniparaClient
from snipara_orchestrator.models import OrchestratorConfig, Task, TaskStatus
from snipara_orchestrator.validator import Validator


class Orchestrator:
    """
    Main orchestrator - coordinates the full task lifecycle.

    Uses Snipara for context, implements validation gates locally.

    Lifecycle:
        PENDING → IN_PROGRESS → LOCAL_OK → VALIDATING → PROD_OK → DONE
                              ↓           ↓
                          LOCAL_FAIL   PROD_FAIL → ENV_DRIFT?
    """

    def __init__(self, config: OrchestratorConfig):
        self.config = config
        self.console = Console()

        # Initialize components
        self.snipara = SniparaClient(
            api_key=config.snipara_api_key,
            project_slug=config.snipara_project,
        )
        self.executor = Executor(working_dir=config.repo_path)
        self.validator = Validator(
            test_user=config.test_user,
            executor=self.executor,
        )
        self.drift_detector = DriftDetector(
            prod_url=config.prod_url,
            repo_path=config.repo_path,
            executor=self.executor,
        )
        self.gatekeeper = Gatekeeper(
            snipara=self.snipara,
            validator=self.validator,
            drift_detector=self.drift_detector,
            gatekeeper_id=config.gatekeeper_id,
            fail_fast_on_drift=config.fail_fast_on_drift,
            auto_remember=config.auto_remember,
        )

        # Swarm state
        self.swarm_id: Optional[str] = None
        self.agent_id = "orchestrator-main"

    async def initialize(self) -> None:
        """Initialize the orchestrator and recall previous context."""
        if self.config.verbose:
            self.console.print("\n[bold blue]Initializing Orchestrator...[/bold blue]")

        try:
            # Create swarm for this session
            result = await self.snipara.create_swarm(
                name=f"orchestrator-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}",
                description="Orchestrator validation session",
            )
            self.swarm_id = result.get("swarm_id")

            if self.config.verbose:
                self.console.print(f"  Created swarm: {self.swarm_id}")

            # Recall previous learnings
            memories = await self.snipara.recall(
                query="deployment validation drift failures",
                limit=5,
            )

            if memories.get("memories") and self.config.verbose:
                self.console.print(
                    f"  Recalled {len(memories['memories'])} relevant memories"
                )

        except Exception as e:
            if self.config.verbose:
                self.console.print(f"  [yellow]Warning: Could not initialize Snipara: {e}[/yellow]")

    async def execute_task(self, task: Task) -> Task:
        """
        Execute the complete lifecycle of a task.

        PENDING → IN_PROGRESS → LOCAL_OK → VALIDATING → PROD_OK → DONE

        Args:
            task: Task to execute

        Returns:
            Updated task with final status
        """
        if self.config.verbose:
            self._print_task_header(task)

        # === PHASE 1: Get context from Snipara ===
        await self._phase_get_context(task)

        # === PHASE 2: Execute local tests ===
        success = await self._phase_local_execution(task)
        if not success:
            return task

        # === PHASE 3: Gate check (LOCAL_OK → VALIDATING) ===
        success = await self._phase_gate_check(task)
        if not success:
            return task

        # === PHASE 4: Run cutover checklist ===
        await self._phase_cutover_checklist(task)

        # === PHASE 5: Final validation ===
        await self._phase_final_validation(task)

        # === Store final state ===
        await self._store_final_state(task)

        if self.config.verbose:
            self._print_task_result(task)

        return task

    async def _phase_get_context(self, task: Task) -> None:
        """Phase 1: Get context from Snipara."""
        if self.config.verbose:
            self.console.print("\n[bold]Phase 1: Getting context from Snipara...[/bold]")

        try:
            context = await self.snipara.query_context(task.description, max_tokens=6000)
            sections = context.get("sections", [])

            if self.config.verbose:
                self.console.print(f"  Got {len(sections)} relevant sections")

            task.metadata["context_sections"] = len(sections)

        except Exception as e:
            if self.config.verbose:
                self.console.print(f"  [yellow]Warning: Could not get context: {e}[/yellow]")

    async def _phase_local_execution(self, task: Task) -> bool:
        """Phase 2: Execute local tests."""
        if self.config.verbose:
            self.console.print("\n[bold]Phase 2: Executing local tests...[/bold]")

        task.status = TaskStatus.IN_PROGRESS

        # Run local tests
        passed, output = await self.executor.run_local_tests(task)

        if self.config.verbose:
            status = "[green]PASSED[/green]" if passed else "[red]FAILED[/red]"
            self.console.print(f"  Local tests: {status}")

            if not passed:
                self.console.print(f"  [dim]{output[:500]}[/dim]")

        if not passed:
            task.status = TaskStatus.LOCAL_FAIL
            task.error = output

            if self.config.auto_remember:
                await self.snipara.remember(
                    content=f"Task {task.id} failed local tests: {output[:500]}",
                    type="learning",
                    category="failures",
                )

            return False

        task.status = TaskStatus.LOCAL_OK

        if self.config.verbose:
            self.console.print("  Status: [green]LOCAL_OK[/green]")

        return True

    async def _phase_gate_check(self, task: Task) -> bool:
        """Phase 3: Gatekeeper check."""
        if self.config.verbose:
            self.console.print("\n[bold]Phase 3: Gatekeeper check...[/bold]")

        gate_result = await self.gatekeeper.gate_local_to_validation(task)

        if self.config.verbose:
            self.console.print(f"  Gate result: {gate_result.message}")

        if not gate_result:
            if task.status == TaskStatus.ENV_DRIFT:
                self.console.print("  [red]ENV_DRIFT detected - stopping execution[/red]")
                self.console.print(f"  Issues: {task.error}")
            return False

        task.status = TaskStatus.VALIDATING

        if self.config.verbose:
            self.console.print("  Status: [yellow]VALIDATING[/yellow]")

        return True

    async def _phase_cutover_checklist(self, task: Task) -> None:
        """Phase 4: Generate and run cutover checklist."""
        if self.config.verbose:
            self.console.print("\n[bold]Phase 4: Running cutover checklist...[/bold]")

        checklist = await self.gatekeeper.generate_cutover_checklist(task)

        if self.config.verbose:
            self.console.print(f"  Generated {len(checklist.checks)} checks")

        all_pass, proofs = await self.gatekeeper.run_cutover_checklist(checklist)
        task.proofs.extend(proofs)

        if self.config.verbose:
            for proof in proofs:
                status = "[green]✓[/green]" if proof.passed else "[red]✗[/red]"
                self.console.print(f"  {status} {proof.endpoint}")

    async def _phase_final_validation(self, task: Task) -> None:
        """Phase 5: Final validation."""
        if self.config.verbose:
            self.console.print("\n[bold]Phase 5: Final validation...[/bold]")

        gate_result = await self.gatekeeper.gate_validation_to_prod(task)

        if self.config.verbose:
            self.console.print(f"  Result: {gate_result.message}")

        if gate_result:
            task.status = TaskStatus.DONE

    async def _store_final_state(self, task: Task) -> None:
        """Store final state in swarm."""
        if self.swarm_id:
            try:
                await self.snipara.set_state(
                    self.swarm_id,
                    self.agent_id,
                    f"task_{task.id}_result",
                    {
                        "status": task.status.value,
                        "proofs": len(task.proofs),
                        "completed_at": task.completed_at.isoformat() if task.completed_at else None,
                    },
                )
            except Exception:
                pass  # Non-critical

    def _print_task_header(self, task: Task) -> None:
        """Print task header."""
        self.console.print()
        self.console.print(Panel(
            f"[bold]{task.title}[/bold]\n{task.description}",
            title="Starting Task",
            border_style="blue",
        ))

    def _print_task_result(self, task: Task) -> None:
        """Print task result."""
        self.console.print()

        if task.status == TaskStatus.DONE:
            self.console.print(Panel(
                f"[green]Task completed successfully![/green]\n"
                f"Proofs collected: {len(task.proofs)}\n"
                f"All proofs pass: {task.all_proofs_pass()}",
                title="Result",
                border_style="green",
            ))
        else:
            self.console.print(Panel(
                f"[red]Task failed[/red]\n"
                f"Status: {task.status.value}\n"
                f"Error: {task.error or 'Unknown'}",
                title="Result",
                border_style="red",
            ))

    async def run_batch(self, tasks: list[Task], parallel: bool = False) -> list[Task]:
        """
        Run multiple tasks.

        Args:
            tasks: List of tasks to execute
            parallel: Run tasks in parallel (careful with resources)

        Returns:
            List of executed tasks
        """
        if parallel:
            return await asyncio.gather(*[self.execute_task(t) for t in tasks])
        else:
            results = []
            for task in tasks:
                result = await self.execute_task(task)
                results.append(result)
            return results

    def print_summary(self, tasks: list[Task]) -> None:
        """Print a summary table of task results."""
        table = Table(title="Task Summary")
        table.add_column("Task ID", style="cyan")
        table.add_column("Title")
        table.add_column("Status")
        table.add_column("Proofs")

        for task in tasks:
            status_style = {
                TaskStatus.DONE: "green",
                TaskStatus.PROD_OK: "green",
                TaskStatus.LOCAL_OK: "yellow",
                TaskStatus.ENV_DRIFT: "red",
                TaskStatus.PROD_FAIL: "red",
                TaskStatus.LOCAL_FAIL: "red",
            }.get(task.status, "white")

            table.add_row(
                task.id,
                task.title[:30],
                f"[{status_style}]{task.status.value}[/{status_style}]",
                f"{len(task.passing_proofs())}/{len(task.proofs)}",
            )

        self.console.print(table)


async def create_orchestrator(
    snipara_api_key: str,
    snipara_project: str,
    prod_url: str,
    repo_path: str,
    test_user: str = "test@example.com",
    verbose: bool = True,
) -> Orchestrator:
    """
    Create and initialize an orchestrator.

    Args:
        snipara_api_key: Snipara API key
        snipara_project: Snipara project slug
        prod_url: Production URL
        repo_path: Path to repository
        test_user: Test user email
        verbose: Enable verbose output

    Returns:
        Initialized Orchestrator
    """
    config = OrchestratorConfig(
        snipara_api_key=snipara_api_key,
        snipara_project=snipara_project,
        prod_url=prod_url,
        repo_path=repo_path,
        test_user=test_user,
        verbose=verbose,
    )

    orchestrator = Orchestrator(config)
    await orchestrator.initialize()

    return orchestrator
