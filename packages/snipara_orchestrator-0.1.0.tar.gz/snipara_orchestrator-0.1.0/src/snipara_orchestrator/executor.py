"""Executor for running commands, tests, and deployments."""

import asyncio
import os
import shlex
from dataclasses import dataclass
from typing import Optional

from snipara_orchestrator.models import Task


@dataclass
class ExecutionResult:
    """Result of a command execution."""

    success: bool
    stdout: str
    stderr: str
    return_code: int
    command: str
    duration_ms: float


class Executor:
    """
    Executes commands, tests, and deployments.

    Handles local test execution and deployment commands.
    """

    def __init__(
        self,
        working_dir: Optional[str] = None,
        timeout: float = 300.0,
        env: Optional[dict[str, str]] = None,
    ):
        self.working_dir = working_dir or os.getcwd()
        self.timeout = timeout
        self.env = {**os.environ, **(env or {})}

    async def run_command(
        self,
        command: str,
        timeout: Optional[float] = None,
        cwd: Optional[str] = None,
    ) -> ExecutionResult:
        """
        Run a shell command asynchronously.

        Args:
            command: Shell command to execute
            timeout: Override default timeout
            cwd: Override working directory
        """
        import time

        start = time.monotonic()
        effective_timeout = timeout or self.timeout
        effective_cwd = cwd or self.working_dir

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=effective_cwd,
                env=self.env,
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(),
                    timeout=effective_timeout,
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                return ExecutionResult(
                    success=False,
                    stdout="",
                    stderr=f"Command timed out after {effective_timeout}s",
                    return_code=-1,
                    command=command,
                    duration_ms=(time.monotonic() - start) * 1000,
                )

            duration_ms = (time.monotonic() - start) * 1000

            return ExecutionResult(
                success=proc.returncode == 0,
                stdout=stdout.decode("utf-8", errors="replace"),
                stderr=stderr.decode("utf-8", errors="replace"),
                return_code=proc.returncode or 0,
                command=command,
                duration_ms=duration_ms,
            )

        except Exception as e:
            duration_ms = (time.monotonic() - start) * 1000
            return ExecutionResult(
                success=False,
                stdout="",
                stderr=str(e),
                return_code=-1,
                command=command,
                duration_ms=duration_ms,
            )

    async def run_local_tests(self, task: Task) -> tuple[bool, str]:
        """
        Run all local tests for a task.

        Returns:
            Tuple of (all_passed, detailed_output)
        """
        results: list[str] = []
        all_passed = True

        for test_cmd in task.criteria.local_tests:
            result = await self.run_command(test_cmd)

            if result.success:
                results.append(f"✅ {test_cmd}: passed ({result.duration_ms:.0f}ms)")
            else:
                all_passed = False
                error_summary = result.stderr[:500] if result.stderr else result.stdout[:500]
                results.append(f"❌ {test_cmd}: failed\n   {error_summary}")

        return all_passed, "\n".join(results)

    async def run_deployment(
        self,
        service: str,
        environment: str = "production",
        provider: str = "railway",
    ) -> ExecutionResult:
        """
        Run a deployment command.

        Args:
            service: Service name to deploy
            environment: Target environment
            provider: Deployment provider (railway, vercel, fly, etc.)
        """
        if provider == "railway":
            cmd = f"railway up -d -s {shlex.quote(service)} -e {shlex.quote(environment)}"
        elif provider == "vercel":
            env_flag = "--prod" if environment == "production" else ""
            cmd = f"vercel deploy {env_flag}"
        elif provider == "fly":
            cmd = f"fly deploy --app {shlex.quote(service)}"
        else:
            cmd = f"echo 'Unknown provider: {provider}'"

        return await self.run_command(cmd)

    async def check_prerequisites(self) -> dict[str, bool]:
        """Check if required tools are available."""
        tools = ["node", "npm", "git", "python"]
        results = {}

        for tool in tools:
            result = await self.run_command(f"which {tool}", timeout=5.0)
            results[tool] = result.success

        return results

    async def run_lint(self) -> ExecutionResult:
        """Run linting commands."""
        # Try common lint commands
        for cmd in ["pnpm lint", "npm run lint", "ruff check .", "eslint ."]:
            result = await self.run_command(cmd, timeout=120.0)
            if result.return_code != 127:  # Command found
                return result

        return ExecutionResult(
            success=False,
            stdout="",
            stderr="No lint command found",
            return_code=1,
            command="lint",
            duration_ms=0,
        )

    async def run_typecheck(self) -> ExecutionResult:
        """Run type checking."""
        for cmd in ["pnpm type-check", "npm run type-check", "tsc --noEmit", "mypy ."]:
            result = await self.run_command(cmd, timeout=120.0)
            if result.return_code != 127:
                return result

        return ExecutionResult(
            success=False,
            stdout="",
            stderr="No typecheck command found",
            return_code=1,
            command="typecheck",
            duration_ms=0,
        )

    async def run_build(self, skip_env_validation: bool = True) -> ExecutionResult:
        """Run build command."""
        env_prefix = "SKIP_ENV_VALIDATION=true " if skip_env_validation else ""

        for cmd in [f"{env_prefix}pnpm build", f"{env_prefix}npm run build", "python -m build"]:
            result = await self.run_command(cmd, timeout=300.0)
            if result.return_code != 127:
                return result

        return ExecutionResult(
            success=False,
            stdout="",
            stderr="No build command found",
            return_code=1,
            command="build",
            duration_ms=0,
        )
