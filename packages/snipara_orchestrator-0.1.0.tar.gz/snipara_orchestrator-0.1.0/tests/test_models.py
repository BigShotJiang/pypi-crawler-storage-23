"""Tests for data models."""

import pytest
from datetime import datetime

from snipara_orchestrator.models import (
    DriftReport,
    LiveCheck,
    Proof,
    Task,
    TaskStatus,
    ValidationCriteria,
)


class TestProof:
    """Tests for Proof model."""

    def test_passed_property_true(self):
        proof = Proof(
            endpoint="/health",
            user_tested="test@example.com",
            result="pass",
        )
        assert proof.passed is True

    def test_passed_property_false(self):
        proof = Proof(
            endpoint="/health",
            user_tested="test@example.com",
            result="fail",
        )
        assert proof.passed is False

    def test_proof_with_response(self):
        proof = Proof(
            endpoint="/api/users",
            user_tested="test@example.com",
            result="pass",
            response_code=200,
            response_body={"users": []},
        )
        assert proof.response_code == 200
        assert proof.response_body == {"users": []}


class TestLiveCheck:
    """Tests for LiveCheck model."""

    def test_default_values(self):
        check = LiveCheck(url="https://api.example.com/health")
        assert check.method == "GET"
        assert check.expected_status == 200
        assert check.timeout == 30.0

    def test_custom_values(self):
        check = LiveCheck(
            url="https://api.example.com/login",
            method="POST",
            expected_status=201,
            body={"email": "test@test.com"},
        )
        assert check.method == "POST"
        assert check.expected_status == 201
        assert check.body == {"email": "test@test.com"}


class TestValidationCriteria:
    """Tests for ValidationCriteria model."""

    def test_default_values(self):
        criteria = ValidationCriteria()
        assert criteria.local_tests == []
        assert criteria.live_checks == []
        assert criteria.required_proofs == 3

    def test_total_checks(self):
        criteria = ValidationCriteria(
            live_checks=[
                LiveCheck(url="https://api.example.com/health"),
                LiveCheck(url="https://api.example.com/ready"),
            ],
            ui_tests=["test1.spec.ts"],
        )
        assert criteria.total_checks() == 3


class TestTask:
    """Tests for Task model."""

    def test_initial_status(self):
        task = Task(
            id="test-task",
            title="Test Task",
            description="A test task",
        )
        assert task.status == TaskStatus.PENDING

    def test_passing_proofs(self):
        task = Task(
            id="test-task",
            title="Test Task",
            description="A test task",
            proofs=[
                Proof(endpoint="/a", user_tested="test@example.com", result="pass"),
                Proof(endpoint="/b", user_tested="test@example.com", result="fail"),
                Proof(endpoint="/c", user_tested="test@example.com", result="pass"),
            ],
        )
        assert len(task.passing_proofs()) == 2
        assert len(task.failing_proofs()) == 1

    def test_has_minimum_proofs(self):
        task = Task(
            id="test-task",
            title="Test Task",
            description="A test task",
            criteria=ValidationCriteria(required_proofs=2),
            proofs=[
                Proof(endpoint="/a", user_tested="test@example.com", result="pass"),
                Proof(endpoint="/b", user_tested="test@example.com", result="pass"),
            ],
        )
        assert task.has_minimum_proofs() is True

    def test_all_proofs_pass(self):
        task = Task(
            id="test-task",
            title="Test Task",
            description="A test task",
            proofs=[
                Proof(endpoint="/a", user_tested="test@example.com", result="pass"),
                Proof(endpoint="/b", user_tested="test@example.com", result="pass"),
            ],
        )
        assert task.all_proofs_pass() is True

        task.proofs.append(
            Proof(endpoint="/c", user_tested="test@example.com", result="fail")
        )
        assert task.all_proofs_pass() is False


class TestDriftReport:
    """Tests for DriftReport model."""

    def test_no_drift(self):
        report = DriftReport(has_drift=False)
        assert "No drift detected" in report.summary()

    def test_with_drift(self):
        report = DriftReport(
            has_drift=True,
            issues=["Route /api/users returns 404", "Schema drift detected"],
            recommendations=["Redeploy", "Run db push"],
        )
        assert report.has_drift is True
        assert "2 issues found" in report.summary()


class TestTaskStatus:
    """Tests for TaskStatus enum."""

    def test_status_values(self):
        assert TaskStatus.PENDING.value == "pending"
        assert TaskStatus.DONE.value == "done"
        assert TaskStatus.ENV_DRIFT.value == "env_drift"
