#!/usr/bin/env python3
"""
Multi-agent workflow example.

This example demonstrates:
1. Using Snipara swarms for multi-agent coordination
2. Creating tasks with dependencies
3. Shared state between agents
4. Memory persistence across sessions
"""

import asyncio
import os
from datetime import datetime

from snipara_orchestrator import Orchestrator, SniparaClient, Task, ValidationCriteria
from snipara_orchestrator.models import LiveCheck, OrchestratorConfig


async def coordinator_agent(snipara: SniparaClient, swarm_id: str):
    """
    Coordinator agent - creates and assigns tasks.
    """
    agent_id = "coordinator"

    # Join the swarm as coordinator
    await snipara.join_swarm(
        swarm_id=swarm_id,
        agent_id=agent_id,
        role="coordinator",
        capabilities=["planning", "assignment"],
    )

    # Create tasks for workers
    tasks = [
        ("Run unit tests", "Execute pytest and report results", 10),
        ("Run integration tests", "Execute integration test suite", 5),
        ("Check code coverage", "Verify coverage meets threshold", 3),
        ("Lint codebase", "Run ruff and fix issues", 2),
    ]

    task_ids = []
    for title, description, priority in tasks:
        result = await snipara.create_task(
            swarm_id=swarm_id,
            agent_id=agent_id,
            title=title,
            description=description,
            priority=priority,
        )
        task_ids.append(result.get("task_id"))
        print(f"  Created task: {title}")

    # Store task list in shared state
    await snipara.set_state(
        swarm_id=swarm_id,
        agent_id=agent_id,
        key="pending_tasks",
        value=task_ids,
    )

    # Broadcast that tasks are ready
    await snipara.broadcast(
        swarm_id=swarm_id,
        agent_id=agent_id,
        event_type="tasks_created",
        payload={"count": len(tasks)},
    )

    return task_ids


async def worker_agent(
    snipara: SniparaClient,
    orchestrator: Orchestrator,
    swarm_id: str,
    worker_id: str,
):
    """
    Worker agent - claims and executes tasks.
    """
    # Join the swarm as worker
    await snipara.join_swarm(
        swarm_id=swarm_id,
        agent_id=worker_id,
        role="worker",
        capabilities=["testing", "validation"],
    )

    # Claim a task
    # Note: In a real scenario, you'd use rlm_task_claim
    # Here we simulate by getting state

    print(f"  Worker {worker_id} ready for tasks")

    # Simulate working on a task
    await asyncio.sleep(1)

    # Store result in shared state
    await snipara.set_state(
        swarm_id=swarm_id,
        agent_id=worker_id,
        key=f"worker_{worker_id}_status",
        value={
            "status": "idle",
            "tasks_completed": 0,
            "last_active": datetime.utcnow().isoformat(),
        },
    )

    return True


async def main():
    # Configuration
    config = OrchestratorConfig(
        snipara_api_key=os.environ.get("SNIPARA_API_KEY", "rlm_your_api_key"),
        snipara_project=os.environ.get("SNIPARA_PROJECT", "my-project"),
        prod_url=os.environ.get("PROD_URL", "https://api.example.com"),
        repo_path=os.environ.get("REPO_PATH", os.getcwd()),
        verbose=True,
    )

    # Create Snipara client for swarm operations
    snipara = SniparaClient(
        api_key=config.snipara_api_key,
        project_slug=config.snipara_project,
    )

    # Create orchestrator for task execution
    orchestrator = Orchestrator(config)
    await orchestrator.initialize()

    print("\n" + "=" * 60)
    print("Multi-Agent Workflow Demo")
    print("=" * 60)

    # Recall previous session context
    print("\n1. Recalling previous context...")
    memories = await snipara.recall(
        query="deployment workflow progress",
        limit=3,
    )
    if memories.get("memories"):
        print(f"   Found {len(memories['memories'])} relevant memories")
        for mem in memories["memories"][:2]:
            print(f"   - {mem.get('content', '')[:50]}...")

    # Create a swarm for coordination
    print("\n2. Creating coordination swarm...")
    swarm_result = await snipara.create_swarm(
        name=f"deployment-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}",
        description="Multi-agent deployment coordination",
        max_agents=5,
    )
    swarm_id = swarm_result.get("swarm_id", "demo-swarm")
    print(f"   Swarm created: {swarm_id}")

    # Start coordinator
    print("\n3. Starting coordinator agent...")
    task_ids = await coordinator_agent(snipara, swarm_id)

    # Start workers
    print("\n4. Starting worker agents...")
    workers = ["worker-1", "worker-2"]
    await asyncio.gather(*[
        worker_agent(snipara, orchestrator, swarm_id, worker_id)
        for worker_id in workers
    ])

    # Run a validation task through orchestrator
    print("\n5. Running validation task...")
    task = Task(
        id="multi-agent-validation",
        title="Multi-Agent Validation",
        description="Validate deployment after multi-agent workflow",
        criteria=ValidationCriteria(
            local_tests=["echo 'simulated test'"],
            live_checks=[
                LiveCheck(
                    url=f"{config.prod_url}/health",
                    expected_status=200,
                ),
            ],
            required_proofs=1,
        ),
    )

    result = await orchestrator.execute_task(task)

    # Store session summary
    print("\n6. Storing session summary...")
    await snipara.remember(
        content=f"Multi-agent workflow completed. Tasks created: {len(task_ids)}, Workers: {len(workers)}, Final status: {result.status.value}",
        type="context",
        category="session",
        ttl_days=7,
    )

    print("\n" + "=" * 60)
    print(f"Workflow completed with status: {result.status.value}")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
