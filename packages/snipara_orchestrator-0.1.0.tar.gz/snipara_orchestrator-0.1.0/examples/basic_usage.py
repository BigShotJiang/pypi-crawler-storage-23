#!/usr/bin/env python3
"""
Basic usage example for the agentic orchestrator.

This example demonstrates:
1. Creating an orchestrator with Snipara integration
2. Defining a task with validation criteria
3. Running the full validation flow
4. Handling results and proofs
"""

import asyncio
import os

from snipara_orchestrator import (
    Orchestrator,
    Task,
    ValidationCriteria,
)
from snipara_orchestrator.models import LiveCheck, OrchestratorConfig


async def main():
    # Configuration
    config = OrchestratorConfig(
        snipara_api_key=os.environ.get("SNIPARA_API_KEY", "rlm_your_api_key"),
        snipara_project=os.environ.get("SNIPARA_PROJECT", "my-project"),
        prod_url=os.environ.get("PROD_URL", "https://api.example.com"),
        repo_path=os.environ.get("REPO_PATH", os.getcwd()),
        test_user="test@example.com",
        verbose=True,
    )

    # Create orchestrator
    orchestrator = Orchestrator(config)
    await orchestrator.initialize()

    # Define task with validation criteria
    task = Task(
        id="deploy-feature-auth",
        title="Deploy Authentication Feature",
        description="Deploy the new OAuth2 authentication feature to production",
        criteria=ValidationCriteria(
            # Local tests to run before deployment
            local_tests=[
                "pnpm test",
                "pnpm lint",
                "pnpm type-check",
            ],
            # Live endpoints to validate in production
            live_checks=[
                LiveCheck(
                    url="https://api.example.com/api/auth/health",
                    method="GET",
                    expected_status=200,
                ),
                LiveCheck(
                    url="https://api.example.com/api/auth/login",
                    method="POST",
                    expected_status=200,
                    body={"email": "test@test.com", "password": "testpass"},
                ),
                LiveCheck(
                    url="https://api.example.com/api/auth/session",
                    method="GET",
                    expected_status=200,
                ),
            ],
            # UI tests (Playwright specs)
            ui_tests=[
                "tests/e2e/auth.spec.ts",
            ],
            # Minimum proofs required to pass
            required_proofs=3,
        ),
    )

    # Execute the task
    result = await orchestrator.execute_task(task)

    # Handle result
    print(f"\n{'='*60}")
    print(f"Final Status: {result.status.value}")
    print(f"Proofs: {len(result.passing_proofs())}/{len(result.proofs)} passing")
    print(f"{'='*60}")

    if result.status.value == "done":
        print("\n✅ Task completed successfully!")
        return 0
    else:
        print(f"\n❌ Task failed: {result.error}")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    exit(exit_code)
