# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
"""beman-local-ci: Run Beman CI matrix locally via Docker."""

__version__ = "0.3.0"
