# beman-local-ci

Run Beman CI matrix locally via Docker.

## Installation

```bash
uv pip install -e .
```

## Usage

```bash
# Run all jobs for a repository
beman-local-ci -C /path/to/repo

# Run with filters
beman-local-ci -C /path/to/repo --compiler gcc --cxxversions c++26

# Dry run to see what would be executed
beman-local-ci -C /path/to/repo --dry-run

# Control parallelism
beman-local-ci -C /path/to/repo -j 8 -p 4
```

## Options

- `-C DIR`: Repository directory (default: current directory)
- `-j N`: Build parallelism (default: CPU count when `-p 1`, CPU count / 2 otherwise)
- `-p N`: Max parallel CI jobs (default: auto based on Docker memory, use `all` for unlimited)
- `--dry-run`: Print commands without executing
- `--verbose`: Show detailed output
- `--compiler C1,C2`: Filter by compiler (starts a new filter group)
- `--versions V1,V2`: Filter by compiler versions
- `--cxxversions V1,V2`: Filter by C++ standard versions
- `--stdlibs S1,S2`: Filter by standard libraries
- `--tests T1,T2`: Filter by test types

All filter dimensions are independent — omitted dimensions match all values.
Multiple `--compiler` flags create OR groups; dimensions within a group are ANDed.
