"""Version information for the KISS package."""

__version__ = "0.1.21"
