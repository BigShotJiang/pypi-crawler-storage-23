"""Routes for Claude Monitor web interface."""
