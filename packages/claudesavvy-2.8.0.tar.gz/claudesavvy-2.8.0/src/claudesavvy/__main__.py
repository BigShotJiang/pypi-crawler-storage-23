"""Main entry point for claudesavvy executable."""

from claudesavvy.cli import main

if __name__ == '__main__':
    main()
