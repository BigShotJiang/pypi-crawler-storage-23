"""OCLAWMA - OpenClaw Workflow Management Agent."""

__version__ = "0.2.0"
__author__ = "OpenClaw Team"
__description__ = "OpenClaw Workflow Management Agent"
