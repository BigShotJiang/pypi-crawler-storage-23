"""Tool registry and implementations for Oclawma.

This module provides the tool system for Oclawma, including:
- Tool registry for managing available tools
- Base tool classes and interfaces
- Built-in tools: exec, read, write
- Tool result formatting for LLM context

Example:
    >>> from oclawma.tools import get_tool, register_tool
    >>> from oclawma.tools import ExecTool, ReadTool, WriteTool

    >>> # Register built-in tools
    >>> register_tool(ExecTool())
    >>> register_tool(ReadTool())
    >>> register_tool(WriteTool())

    >>> # Execute a tool
    >>> import asyncio
    >>> result = asyncio.run(get_tool("exec").execute(command="echo hello"))
    >>> print(result.output)
"""

# Base classes and registry
from oclawma.tools.base import (
    BaseTool,
    ToolError,
    ToolExecutionError,
    ToolNotFoundError,
    ToolParameter,
    ToolRegistry,
    ToolResult,
    ToolSchema,
    ToolTimeoutError,
    ToolValidationError,
    get_default_registry,
    get_tool,
    list_all_tools,
    register_tool,
    set_default_registry,
)

# Built-in tools
from oclawma.tools.exec_tool import ExecTool
from oclawma.tools.read_tool import ReadTool
from oclawma.tools.write_tool import WriteTool

__all__ = [
    # Base classes
    "BaseTool",
    "ToolSchema",
    "ToolParameter",
    "ToolResult",
    # Exceptions
    "ToolError",
    "ToolExecutionError",
    "ToolValidationError",
    "ToolNotFoundError",
    "ToolTimeoutError",
    # Registry
    "ToolRegistry",
    "get_default_registry",
    "set_default_registry",
    "register_tool",
    "get_tool",
    "list_all_tools",
    # Built-in tools
    "ExecTool",
    "ReadTool",
    "WriteTool",
    # Factory functions
    "create_default_tools",
    "create_default_tools_with_safety",
    "create_default_tools_with_learning",
    "create_default_tools_with_safety_and_learning",
]


def create_default_tools() -> ToolRegistry:
    """Create a registry with all default tools registered.

    Returns:
        ToolRegistry with exec, read, and write tools
    """
    registry = ToolRegistry()
    registry.register(ExecTool(), category="filesystem")
    registry.register(ReadTool(), category="filesystem")
    registry.register(WriteTool(), category="filesystem")
    return registry


def create_default_tools_with_safety(safety_guard) -> ToolRegistry:
    """Create a registry with all default tools and safety integration.

    Args:
        safety_guard: SafetyGuard instance for risk analysis

    Returns:
        ToolRegistry with safety-aware tools
    """
    from oclawma.safety import SafetyGuard  # noqa: F401

    registry = ToolRegistry()
    registry.register(ExecTool(safety_guard=safety_guard), category="filesystem")
    registry.register(ReadTool(), category="filesystem")
    registry.register(WriteTool(), category="filesystem")
    return registry


def create_default_tools_with_learning(learner=None) -> ToolRegistry:
    """Create a registry with all default tools and learning integration.

    Args:
        learner: Optional ErrorPatternLearner instance

    Returns:
        ToolRegistry with learning-aware tools
    """
    from oclawma.learning.integration import wrap_tool_with_learning

    registry = ToolRegistry()
    registry.register(wrap_tool_with_learning(ExecTool(), learner), category="filesystem")
    registry.register(wrap_tool_with_learning(ReadTool(), learner), category="filesystem")
    registry.register(wrap_tool_with_learning(WriteTool(), learner), category="filesystem")
    return registry


def create_default_tools_with_safety_and_learning(safety_guard, learner=None) -> ToolRegistry:
    """Create a registry with safety and learning integration.

    Args:
        safety_guard: SafetyGuard instance for risk analysis
        learner: Optional ErrorPatternLearner instance

    Returns:
        ToolRegistry with safety and learning-aware tools
    """
    from oclawma.learning.integration import wrap_tool_with_learning

    registry = ToolRegistry()
    registry.register(
        wrap_tool_with_learning(ExecTool(safety_guard=safety_guard), learner), category="filesystem"
    )
    registry.register(wrap_tool_with_learning(ReadTool(), learner), category="filesystem")
    registry.register(wrap_tool_with_learning(WriteTool(), learner), category="filesystem")
    return registry
