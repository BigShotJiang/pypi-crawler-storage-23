"""Job queue module for Oclawma.

This module provides a persistent, SQLite-backed job queue with:
- ACID-compliant operations
- Automatic retry with exponential backoff
- Priority-based scheduling
- Delayed job execution
- Priority preemption (CRITICAL jobs can pause lower priority jobs)
- Priority inheritance for dependent jobs
- Dead Letter Queue for failed jobs
- Rate limiting per job type
- Optional payload encryption for sensitive data
- Cron-based recurring job scheduling
- Job cancellation and timeout enforcement
- Multi-tenant support with tenant isolation
- Maintenance window awareness - pauses during scheduled maintenance
"""

from __future__ import annotations

from oclawma.cache import CacheConfig, CacheKey, CacheStats, ResultCache
from oclawma.cancellation import (
    CancellationError,
    CancellationReason,
    CancellationToken,
    TimeoutConfig,
    TimeoutManager,
)
from oclawma.queue.batch import (
    BatchError,
    BatchJob,
    BatchManager,
    BatchNotFoundError,
    BatchProgress,
    BatchResult,
    BatchStatus,
)
from oclawma.queue.dag_integration import (
    DAGQueue,
    DAGQueueError,
    create_dag_from_jobs,
    dag_to_dict,
    dict_to_dag,
    execute_dag_with_queue,
)
from oclawma.queue.dlq import (
    DeadLetterQueue,
    DLQEntry,
    DLQError,
    DLQNotFoundError,
    DLQStats,
)
from oclawma.queue.models import Job, JobPriority, JobStats, JobStatus
from oclawma.queue.queue import JobQueue, JobQueueError
from oclawma.queue.scheduler import (
    get_due_jobs,
    process_due_jobs,
    reschedule_job,
    schedule_recurring_job,
)
from oclawma.queue.store import JobNotFoundError, JobStore, JobStoreError
from oclawma.ratelimit import RateLimitConfig, RateLimiter, RateLimitError, RateLimitInfo

__all__ = [
    # Cache
    "ResultCache",
    "CacheConfig",
    "CacheKey",
    "CacheStats",
    # Models
    "Job",
    "JobPriority",
    "JobStats",
    "JobStatus",
    # Queue
    "JobQueue",
    "JobQueueError",
    # Store
    "JobStore",
    "JobStoreError",
    "JobNotFoundError",
    # DLQ
    "DeadLetterQueue",
    "DLQEntry",
    "DLQStats",
    "DLQError",
    "DLQNotFoundError",
    # Cancellation & Timeouts
    "CancellationToken",
    "CancellationReason",
    "CancellationError",
    "TimeoutManager",
    "TimeoutConfig",
    # Rate Limiting
    "RateLimiter",
    "RateLimitConfig",
    "RateLimitInfo",
    "RateLimitError",
    # Scheduler
    "schedule_recurring_job",
    "reschedule_job",
    "get_due_jobs",
    "process_due_jobs",
    # Batch
    "BatchJob",
    "BatchManager",
    "BatchProgress",
    "BatchResult",
    "BatchStatus",
    "BatchError",
    "BatchNotFoundError",
    # DAG
    "DAGQueue",
    "DAGQueueError",
    "create_dag_from_jobs",
    "dag_to_dict",
    "dict_to_dag",
    "execute_dag_with_queue",
]
