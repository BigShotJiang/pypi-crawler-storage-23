"""Entry point for running oclawma as a module."""

from oclawma.cli import main

if __name__ == "__main__":
    main()
