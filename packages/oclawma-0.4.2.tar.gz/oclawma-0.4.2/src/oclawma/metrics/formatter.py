"""Prometheus metrics formatters."""

from __future__ import annotations

from oclawma.metrics.collector import MetricsCollector


def format_prometheus_metrics(collector: MetricsCollector) -> str:
    """Format metrics in Prometheus text exposition format.

    See: https://prometheus.io/docs/instrumenting/exposition_formats/

    Args:
        collector: Metrics collector with current values

    Returns:
        Prometheus-formatted metrics string
    """
    lines = []

    # Jobs processed counter
    lines.append("# HELP oclawma_jobs_processed_total Total number of jobs processed")
    lines.append("# TYPE oclawma_jobs_processed_total counter")
    lines.append(f"oclawma_jobs_processed_total {collector.jobs_processed}")

    # Jobs failed counter
    lines.append("# HELP oclawma_jobs_failed_total Total number of jobs that failed")
    lines.append("# TYPE oclawma_jobs_failed_total counter")
    lines.append(f"oclawma_jobs_failed_total {collector.jobs_failed}")

    # Jobs completed counter
    lines.append("# HELP oclawma_jobs_completed_total Total number of jobs completed successfully")
    lines.append("# TYPE oclawma_jobs_completed_total counter")
    lines.append(f"oclawma_jobs_completed_total {collector.jobs_completed}")

    # Scaling events counter
    lines.append("# HELP oclawma_scaling_events_total Total number of auto-scaling events")
    lines.append("# TYPE oclawma_scaling_events_total counter")
    lines.append(f"oclawma_scaling_events_total {collector.scaling_events}")

    # Queue depth gauge
    lines.append("# HELP oclawma_queue_depth Current number of pending jobs in the queue")
    lines.append("# TYPE oclawma_queue_depth gauge")
    lines.append(f"oclawma_queue_depth {collector.queue_depth}")

    # Worker count gauge
    lines.append("# HELP oclawma_worker_count Current number of workers")
    lines.append("# TYPE oclawma_worker_count gauge")
    lines.append(f"oclawma_worker_count {collector.worker_count}")

    # Jobs by status gauge
    lines.append("# HELP oclawma_jobs_by_status Number of jobs by status")
    lines.append("# TYPE oclawma_jobs_by_status gauge")
    for status, count in sorted(collector.jobs_by_status.items()):
        lines.append(f'oclawma_jobs_by_status{{status="{status}"}} {count}')
    if not collector.jobs_by_status:
        lines.append('oclawma_jobs_by_status{status="pending"} 0')

    # Duration histogram
    lines.append("# HELP oclawma_job_duration_seconds Job processing duration in seconds")
    lines.append("# TYPE oclawma_job_duration_seconds histogram")

    # Output buckets in order
    for bucket in sorted(collector.duration_buckets.keys()):
        bucket_label = "+Inf" if bucket == float("inf") else str(bucket)
        count = collector.duration_buckets[bucket]
        lines.append(f'oclawma_job_duration_seconds_bucket{{le="{bucket_label}"}} {count}')

    lines.append(f"oclawma_job_duration_seconds_sum {collector.duration_sum}")
    lines.append(f"oclawma_job_duration_seconds_count {collector.duration_count}")

    return "\n".join(lines)
