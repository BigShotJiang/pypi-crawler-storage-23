"""CLI entry point for OCLAWMA."""

from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path

import click

from oclawma import __version__
from oclawma.audit_cli import audit_cli
from oclawma.autoscale_cli import autoscale_cli
from oclawma.cache_cli import cache_cli
from oclawma.cli_ui import (
    ErrorHelper,
    accent,
    bullet,
    confirm_prompt,
    header,
    highlight,
    key_value,
    muted,
    print_error,
    print_info,
    print_success,
    print_warning,
    progress_spinner,
    subheader,
)
from oclawma.completion import completion_cli
from oclawma.config import DEFAULT_CONFIG_PATH, Config, ConfigurationError
from oclawma.config.cli import config_cli
from oclawma.config.utils import (
    create_provider_from_profile,
    create_provider_with_fallback,
    get_model_from_config,
    load_context_budget,
)
from oclawma.context.cli import compact_cli
from oclawma.costs_cli import costs_cli
from oclawma.health.cli import health_cli
from oclawma.learning.cli import learning_cli
from oclawma.logging_config import setup_logging
from oclawma.maintenance_cli import maintenance_cli
from oclawma.memory.cli import memory_cli
from oclawma.metrics.cli import metrics_cli
from oclawma.progress_cli import progress_cli
from oclawma.providers import AuthenticationError, KimiProvider
from oclawma.providers.fallback import FallbackProvider
from oclawma.providers.ollama import OllamaProvider
from oclawma.queue.batch_cli import batch_cli
from oclawma.queue.cancel_cli import cancel_cli, cancel_command
from oclawma.queue.cli import dlq_cli
from oclawma.safety import SafetyGuard
from oclawma.safety_cli import safety_cli
from oclawma.scheduler.cli import scheduler_cli
from oclawma.self_improvement.cli import self_improvement_cli
from oclawma.session.runner import InteractiveSession
from oclawma.shutdown import get_shutdown_manager
from oclawma.skills.cli import skill_cli, skills_cli
from oclawma.subagent.cli import spawn_cli
from oclawma.tenant_cli import tenant_cli
from oclawma.tools import create_default_tools_with_safety
from oclawma.web.cli import web_chat
from oclawma.webhooks.cli import webhooks_cli

# Shell completion setup - Click 8.x uses shell_complete
# The completion is automatically handled by Click when _OCLAWMA_COMPLETE env var is set


def create_provider(
    provider_type: str = "auto",
    base_url: str | None = None,
    model: str | None = None,
    config: Config | None = None,
) -> KimiProvider | OllamaProvider | FallbackProvider:
    """Create the appropriate provider based on configuration.

    Args:
        provider_type: Type of provider to create (ollama, kimi, auto, config).
        base_url: Optional base URL for the provider.
        model: Optional model name for context limit detection.
        config: Optional loaded configuration.

    Returns:
        Configured provider instance.

    Raises:
        AuthenticationError: If required API keys are missing.
        click.UsageError: If provider configuration is invalid.
    """
    # If using config-based provider selection
    if provider_type == "config" and config:
        try:
            if config.fallback.enabled:
                return create_provider_with_fallback(config)
            else:
                return create_provider_from_profile(config)
        except ConfigurationError as e:
            raise click.UsageError(str(e)) from e

    # Legacy provider creation (for backwards compatibility)
    if provider_type == "ollama":
        try:
            return OllamaProvider(base_url=base_url or "http://localhost:11434")
        except Exception as e:
            raise click.UsageError(
                ErrorHelper.connection_failed(
                    base_url or "http://localhost:11434",
                    "Make sure Ollama is running: ollama serve",
                )
            ) from e

    elif provider_type == "kimi":
        try:
            return KimiProvider()
        except AuthenticationError as e:
            raise click.UsageError(ErrorHelper.api_key_missing("Kimi", "KIMI_API_KEY")) from e

    elif provider_type == "auto":
        # Try to create a fallback provider with Ollama as primary and Kimi as fallback
        try:
            primary = OllamaProvider(base_url=base_url or "http://localhost:11434")
        except Exception as e:
            raise click.UsageError(f"Failed to create Ollama provider: {e}") from e

        # Check if Kimi is available for fallback
        kimi_api_key = os.environ.get("KIMI_API_KEY")
        if kimi_api_key:
            try:
                fallback = KimiProvider()
                return FallbackProvider(primary, fallback)
            except AuthenticationError:
                pass  # Fall through to just using primary

        # No fallback available, just use primary
        return primary

    else:
        raise click.UsageError(f"Unknown provider type: {provider_type}")


@click.group()
@click.version_option(
    version=__version__,
    prog_name="oclawma",
)
@click.option(
    "--log-level",
    type=click.Choice(["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], case_sensitive=False),
    default="INFO",
    help="Set the logging level",
    show_default=True,
)
@click.pass_context
def cli(ctx: click.Context, log_level: str) -> None:
    """OCLAWMA - OpenClaw Workflow Management Agent.

    A powerful, extensible AI agent framework with lazy-loaded skills,
    multi-provider LLM support, and intelligent context management.

    \b
    Quick Start:
        oclawma run                    # Start interactive session
        oclawma config init            # Initialize configuration
        oclawma skills search          # Browse available skills

    \b
    For shell completion:
        oclawma --install-completion   # Install shell completion
        oclawma --show-completion      # Show completion script
    """
    ctx.ensure_object(dict)
    # Configuration will be loaded lazily when needed
    ctx.obj["config"] = None

    # Setup logging
    setup_logging(level=log_level.upper())
    logger = logging.getLogger(__name__)
    logger.debug(f"Logging configured with level: {log_level}")


def get_config(ctx: click.Context) -> Config:
    """Get or load configuration."""
    if ctx.obj.get("config") is None:
        ctx.obj["config"] = Config.ensure_exists()
    return ctx.obj["config"]


# Add completion commands
cli.add_command(completion_cli)

# Add config commands
cli.add_command(config_cli)

# Add spawn commands
cli.add_command(spawn_cli)

# Add compact commands
cli.add_command(compact_cli)

# Add safety commands
cli.add_command(safety_cli)

# Add learning commands
cli.add_command(learning_cli)

# Add memory commands
cli.add_command(memory_cli)

# Add self-improvement commands
cli.add_command(self_improvement_cli)

# Add skills marketplace commands
cli.add_command(skills_cli)
cli.add_command(skill_cli)

# Add health commands
cli.add_command(health_cli)

# Add metrics commands
cli.add_command(metrics_cli)

# Add scheduler commands
cli.add_command(scheduler_cli)

# Add autoscale commands
cli.add_command(autoscale_cli)

# Add maintenance commands
cli.add_command(maintenance_cli)

# Add web chat commands
cli.add_command(web_chat)

# Add webhooks commands
cli.add_command(webhooks_cli)

# Add queue/DLQ commands
cli.add_command(cache_cli)
cli.add_command(dlq_cli)
cli.add_command(batch_cli)
cli.add_command(progress_cli)
cli.add_command(cancel_command)
cli.add_command(cancel_cli)

# Add costs commands
cli.add_command(costs_cli)

# Add audit commands
cli.add_command(audit_cli)

# Add tenant commands
cli.add_command(tenant_cli)


@cli.command()
def version() -> None:
    """Show the version and exit."""
    click.echo(f"{accent('OCLAWMA', bold=True)} version {highlight(__version__)}")


@cli.command()
@click.option(
    "--model",
    help="Model to use for the session (overrides config)",
    shell_complete=lambda ctx, param, incomplete: (
        [
            "llama3.2:latest",
            "qwen2.5:3b",
            "kimi-k2-5",
            "claude-3-5-sonnet",
        ]
        if incomplete
        else []
    ),
)
@click.option(
    "--base-url",
    help="Ollama base URL (overrides config)",
)
@click.option(
    "--provider",
    type=click.Choice(["auto", "ollama", "kimi", "config"], case_sensitive=False),
    default="config",
    help="Provider to use (config: use ~/.oclawma/config.yaml)",
    show_default=True,
)
@click.option(
    "--profile",
    help="Profile to use from config (overrides active profile)",
    shell_complete=lambda ctx, param, incomplete: (
        ["local", "cloud", "fallback"] if incomplete else []
    ),
)
@click.option(
    "--config-path",
    type=click.Path(exists=False),
    help="Path to config file (default: ~/.oclawma/config.yaml)",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Simulate commands without executing them",
)
@click.option(
    "--no-safety-confirm",
    is_flag=True,
    help="Disable confirmation prompts for risky operations",
)
@click.option(
    "--web",
    is_flag=True,
    help="Also start the web chat server alongside CLI",
)
@click.option(
    "--web-port",
    type=int,
    default=8080,
    help="Port for web chat server (when --web is used)",
    show_default=True,
)
@click.option(
    "--web-token",
    type=str,
    help="Auth token for web chat (random if not provided)",
)
@click.option(
    "--show-gpu",
    is_flag=True,
    help="Show GPU info and exit (for Ollama provider)",
)
@click.pass_context
def run(
    ctx: click.Context,
    model: str | None,
    base_url: str | None,
    provider: str,
    profile: str | None,
    config_path: str | None,
    dry_run: bool,
    no_safety_confirm: bool,
    web: bool,
    web_port: int,
    web_token: str | None,
    show_gpu: bool,
) -> None:
    """Start an interactive session with OCLAWMA.

    This starts a REPL-style interactive session where you can
    chat with the AI assistant and use tools to accomplish tasks.

    Examples:
        oclawma run                          # Use active profile from config
        oclawma run --profile cloud          # Use specific profile
        oclawma run --provider kimi          # Use Kimi directly
        oclawma run --model llama3.2:latest  # Override model
        oclawma run --dry-run                # Simulate without executing
        oclawma run --web                    # CLI + web chat together
        oclawma run --web --web-port 3000    # Custom web port
    """
    # Load configuration
    cfg_path = Path(config_path) if config_path else DEFAULT_CONFIG_PATH

    with progress_spinner("Loading configuration...") as update:
        try:
            update("Loading configuration...")
            config = Config.load(cfg_path) if cfg_path.exists() else Config.ensure_exists(cfg_path)
        except Exception as e:
            print_warning(f"Could not load config: {e}")
            config = Config()

    ctx.obj["config"] = config

    # Override profile if specified
    if profile:
        try:
            config.set_active_profile(profile)
            print_success(f"Using profile: {profile}")
        except ConfigurationError as err:
            available = list(config.profiles.keys()) if config.profiles else []
            print_error(ErrorHelper.profile_not_found(profile, available))
            raise click.Abort() from err

    # Load context budget from config
    budget = load_context_budget(config)

    # Create provider
    try:
        with progress_spinner("Initializing provider...") as update:
            update("Initializing provider...")
            if provider == "config":
                provider_instance = create_provider_with_fallback(config)
            else:
                provider_instance = create_provider(
                    provider_type=provider,
                    base_url=base_url,
                    model=model,
                    config=config if provider == "config" else None,
                )
    except click.UsageError:
        raise
    except AuthenticationError as err:
        print_error(ErrorHelper.api_key_missing("Provider", "API_KEY"))
        raise click.Abort() from err
    except Exception as e:
        print_error(f"Failed to create provider: {e}")
        raise click.Abort() from e

    # Determine effective model
    effective_model = model or get_model_from_config(config)

    # Show provider info
    click.echo()
    click.echo(header("SESSION CONFIGURATION", width=58))
    click.echo()

    if isinstance(provider_instance, FallbackProvider):
        print_success("Using fallback provider (local → cloud)")
        info_data = provider_instance.get_fallback_info()
        click.echo(key_value("Primary", info_data["primary_provider"]))
        click.echo(key_value("Fallback", info_data["fallback_provider"]))
    elif isinstance(provider_instance, KimiProvider):
        print_success("Using Kimi cloud provider")
    elif isinstance(provider_instance, OllamaProvider):
        print_success(f"Using Ollama provider at {provider_instance.base_url}")

    click.echo(key_value("Model", effective_model))

    # Show GPU info for Ollama if requested
    if show_gpu and isinstance(provider_instance, OllamaProvider):
        click.echo()
        click.echo(subheader("GPU INFORMATION"))

        import subprocess

        try:
            # Check if nvidia-smi is available
            result = subprocess.run(
                [
                    "nvidia-smi",
                    "--query-gpu=name,memory.total,memory.free,utilization.gpu",
                    "--format=csv,noheader",
                ],
                capture_output=True,
                text=True,
                check=False,
            )
            if result.returncode == 0:
                click.echo(key_value("NVIDIA GPU", "Detected"))
                for line in result.stdout.strip().split("\n"):
                    parts = [p.strip() for p in line.split(",")]
                    if len(parts) >= 4:
                        click.echo(f"  • {parts[0]}")
                        click.echo(f"    Memory: {parts[2]} / {parts[1]} free")
                        click.echo(f"    Utilization: {parts[3]}")
            else:
                click.echo(key_value("NVIDIA GPU", "Not detected"))
        except Exception as e:
            click.echo(key_value("GPU Check", f"Error: {e}"))

        # Check Ollama ps for loaded models
        try:
            result = subprocess.run(["ollama", "ps"], capture_output=True, text=True, check=False)
            if result.returncode == 0 and result.stdout.strip():
                click.echo()
                click.echo("Loaded Models:")
                for line in result.stdout.strip().split("\n")[1:]:  # Skip header
                    if line.strip():
                        click.echo(f"  {line}")
            else:
                click.echo()
                click.echo("No models currently loaded in Ollama")
        except Exception as e:
            click.echo(f"Could not check ollama ps: {e}")

        # Check Ollama version for CUDA support
        try:
            result = subprocess.run(
                ["ollama", "--version"], capture_output=True, text=True, check=False
            )
            if result.returncode == 0:
                click.echo()
                click.echo(f"Ollama: {result.stdout.strip()}")
        except Exception:
            pass

        click.echo()
        return  # Exit after showing GPU info

    # Start web server if requested
    web_process = None
    if web:
        import secrets
        import subprocess

        token = web_token or secrets.token_urlsafe(16)

        click.echo()
        click.echo(subheader("WEB CHAT SERVER"))
        click.echo(key_value("Port", str(web_port)))
        click.echo(key_value("Auth Token", highlight(token[:16] + "...")))
        click.echo()
        click.echo(f"  Local:   {accent(f'http://127.0.0.1:{web_port}')}")
        click.echo()

        # Start web server in background subprocess
        try:
            cmd = [
                "python",
                "-m",
                "uvicorn",
                "oclawma.web.server:create_app",
                "--host",
                "0.0.0.0",
                "--port",
                str(web_port),
                "--factory",
            ]

            # Set environment variable for auth token
            env = os.environ.copy()
            env["OCLAWMA_WEB_TOKEN"] = token

            web_process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                env=env,
            )

            # Wait a moment for server to start
            import time

            time.sleep(1)

            if web_process.poll() is None:
                print_success(f"Web server started on port {web_port}")
            else:
                print_error("Failed to start web server")
                web_process = None
        except Exception as e:
            print_error(f"Could not start web server: {e}")
            web_process = None

    # Show safety settings
    if dry_run:
        print_info("Dry-run mode: Commands will be simulated but not executed")
    if no_safety_confirm:
        print_warning("Safety confirmations disabled")

    click.echo()

    # Confirm start if safety is disabled
    if (
        no_safety_confirm
        and not dry_run
        and not confirm_prompt("Safety confirmations are disabled. Continue?")
    ):
        print_info("Session cancelled")
        return

    # Create safety guard
    safety_guard = SafetyGuard(
        dry_run=dry_run,
        require_confirmation=not no_safety_confirm,
    )

    # Create tool registry with safety integration
    tool_registry = create_default_tools_with_safety(safety_guard)

    # Create and run interactive session
    session = InteractiveSession(
        provider=provider_instance,
        model=effective_model,
        budget=budget,
        tool_registry=tool_registry,
    )

    # Register session with shutdown manager
    shutdown_manager = get_shutdown_manager()
    shutdown_manager.register_job(
        job_id=f"session-{id(session)}",
        job_type="interactive_session",
        metadata={"model": effective_model, "dry_run": dry_run},
    )

    try:
        # Run the async session
        asyncio.run(session.run())

        # Print summary
        session.print_summary()

    except KeyboardInterrupt:
        print_warning("\n\nSession interrupted. Goodbye!")
    except Exception as e:
        print_error(f"\nSession error: {e}")
        import traceback

        traceback.print_exc()
        raise click.ClickException(str(e)) from e
    finally:
        # Unregister session from shutdown manager
        shutdown_manager.unregister_job(
            job_id=f"session-{id(session)}",
            success=True,
        )

        # Stop web server if running
        if web_process is not None:
            web_process.terminate()
            try:
                web_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                web_process.kill()
            print_info("Web server stopped")


@cli.command(name="status")
@click.option(
    "--config-path",
    type=click.Path(exists=False),
    help="Path to config file",
)
@click.pass_context
def status_cmd(ctx: click.Context, config_path: str | None) -> None:
    """Show system status including context budget and config."""
    cfg_path = Path(config_path) if config_path else DEFAULT_CONFIG_PATH

    # Load configuration with progress
    with progress_spinner("Loading configuration...") as _update:
        try:
            config = Config.ensure_exists(cfg_path)
        except Exception as e:
            print_warning(f"Could not load config: {e}")
            config = Config()

        budget = load_context_budget(config)

    click.echo(header("SYSTEM STATUS", width=58))
    click.echo()

    # Config info
    click.echo(subheader("CONFIGURATION"))
    click.echo(key_value("Config file", str(cfg_path)))
    click.echo(key_value("Active profile", config.active_profile))
    profile = config.get_active_profile()
    click.echo(key_value("Provider", profile.provider))
    click.echo(key_value("Model", profile.model))
    click.echo()

    # Budget visualization
    click.echo(subheader("CONTEXT BUDGET"))
    click.echo(budget.visualize())
    click.echo()

    # Detailed stats
    status_info = budget.get_status()
    click.echo(key_value("Total Budget", f"{budget.total_budget:,} tokens"))
    click.echo(key_value("Used", f"{budget.used_tokens:,} tokens"))
    click.echo(key_value("Remaining", f"{budget.remaining_tokens:,} tokens"))
    click.echo(key_value("Usage", f"{budget.usage_percent:.1f}%"))
    click.echo()

    # Threshold indicators
    click.echo(subheader("THRESHOLDS"))
    warning_pct = (budget.warning_threshold / budget.total_budget) * 100
    critical_pct = (budget.critical_threshold / budget.total_budget) * 100
    click.echo(key_value("Warning", f"{budget.warning_threshold:,} tokens ({warning_pct:.0f}%)"))
    click.echo(key_value("Critical", f"{budget.critical_threshold:,} tokens ({critical_pct:.0f}%)"))
    click.echo(key_value("Maximum", f"{budget.total_budget:,} tokens (100%)"))
    click.echo()

    # Current status message
    if status_info.warning_message:
        click.echo(subheader("STATUS"))
        if status_info.is_critical:
            print_warning(status_info.warning_message)
        elif status_info.is_warning:
            print_info(status_info.warning_message)
        else:
            print_success(status_info.warning_message)
        click.echo()

    # Tips
    click.echo(subheader("COMMANDS"))
    click.echo(f"  {bullet('/compact  - Summarize conversation to free tokens')}")
    click.echo(f"  {bullet('/clear    - Clear attachments and non-essential context')}")
    click.echo(f"  {bullet('/reset    - Start fresh session')}")
    click.echo()
    click.echo(f"  {muted('oclawma config show    - View full configuration')}")
    click.echo(f"  {muted('oclawma config edit    - Edit configuration file')}")
    click.echo(f"  {muted('oclawma safety audit   - View safety audit log')}")


@cli.command(name="doctor")
@click.option(
    "--fix",
    is_flag=True,
    help="Attempt to fix common issues automatically",
)
def doctor_cmd(fix: bool) -> None:
    """Check system health and diagnose common issues.

    Performs various checks to ensure OCLAWMA is properly configured
    and can connect to required services.
    """

    click.echo(header("SYSTEM DOCTOR", width=58))
    click.echo()

    issues_found = 0
    fixes_applied = 0

    # Check Python version
    click.echo(subheader("Python Environment"))
    import sys

    version = sys.version_info
    if version.major == 3 and version.minor >= 9:
        print_success(f"Python {version.major}.{version.minor}.{version.micro}")
    else:
        print_warning(f"Python {version.major}.{version.minor}.{version.micro} (3.9+ recommended)")
        issues_found += 1

    # Check config file
    click.echo()
    click.echo(subheader("Configuration"))
    if DEFAULT_CONFIG_PATH.exists():
        print_success(f"Config file exists: {DEFAULT_CONFIG_PATH}")
    else:
        print_warning(f"Config file not found: {DEFAULT_CONFIG_PATH}")
        if fix:
            try:
                Config.ensure_exists()
                print_success("Created default configuration")
                fixes_applied += 1
            except Exception as e:
                print_error(f"Failed to create config: {e}")
        issues_found += 1

    # Check Ollama
    click.echo()
    click.echo(subheader("Ollama Service"))
    try:
        provider = OllamaProvider()
        # Try a simple request
        import asyncio

        async def test_ollama():
            try:
                from oclawma.providers.base import CompletionRequest, Message

                await provider.complete(
                    CompletionRequest(messages=[Message(role="user", content="hi")], model="")
                )
                return True
            except Exception:
                return False

        if asyncio.run(test_ollama()):
            print_success("Ollama is running and accessible")
        else:
            print_warning("Ollama is running but returned an error")
            issues_found += 1
    except Exception as e:
        print_warning(f"Ollama is not accessible: {e}")
        if fix:
            print_info("Try starting Ollama: ollama serve")
        issues_found += 1

    # Check API keys
    click.echo()
    click.echo(subheader("API Keys"))
    kimi_key = os.environ.get("KIMI_API_KEY")
    if kimi_key:
        masked = kimi_key[:8] + "..." + kimi_key[-4:] if len(kimi_key) > 12 else "***"
        print_success(f"KIMI_API_KEY is set ({masked})")
    else:
        print_info("KIMI_API_KEY not set (only needed for cloud provider)")

    # Check skills directory
    click.echo()
    click.echo(subheader("Skills"))
    skills_dir = Path.home() / ".oclawma" / "skills"
    if skills_dir.exists():
        skill_count = len(list(skills_dir.iterdir()))
        print_success(f"Skills directory exists ({skill_count} items)")
    else:
        print_info("Skills directory not created yet")
        if fix:
            skills_dir.mkdir(parents=True, exist_ok=True)
            print_success("Created skills directory")
            fixes_applied += 1

    # Summary
    click.echo()
    click.echo(header("DIAGNOSIS SUMMARY", width=58))
    if issues_found == 0:
        print_success("All checks passed! System is healthy.")
    else:
        print_warning(f"Found {issues_found} issue(s)")
        if fix and fixes_applied > 0:
            print_success(f"Applied {fixes_applied} automatic fix(es)")
        print_info("Run without --fix to see details, or with --fix to auto-fix")


@cli.command(name="shutdown-status")
def shutdown_status() -> None:
    """Show shutdown manager status."""
    shutdown_manager = get_shutdown_manager()
    status = shutdown_manager.get_status()

    click.echo(header("SHUTDOWN MANAGER STATUS", width=58))
    click.echo()

    state_color = {
        "running": "green",
        "shutdown_requested": "yellow",
        "shutting_down": "red",
        "shutdown_complete": "cyan",
    }.get(status["state"], "white")

    click.echo(key_value("State", click.style(status["state"], fg=state_color)))
    click.echo(key_value("Shutting Down", str(status["is_shutting_down"])))
    click.echo()

    click.echo(subheader("JOBS"))
    click.echo(key_value("Active", str(status["active_jobs"])))
    click.echo(key_value("Pending", str(status["pending_jobs"])))
    click.echo(key_value("Completed", str(status["completed_jobs"])))
    click.echo()

    click.echo(subheader("CONFIGURATION"))
    click.echo(key_value("Timeout", f"{status['timeout_seconds']}s"))
    click.echo(key_value("State File", status["state_file"] or "None"))
    click.echo(key_value("Signal Handlers", str(status["signal_handlers_installed"])))


def main() -> None:
    """Main entry point for the CLI."""
    # Initialize shutdown manager and install signal handlers
    shutdown_manager = get_shutdown_manager()
    shutdown_manager.install_signal_handlers()

    try:
        cli()
    finally:
        # Clean up signal handlers
        shutdown_manager.uninstall_signal_handlers()


if __name__ == "__main__":
    main()
