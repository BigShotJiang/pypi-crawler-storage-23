"""OCLAWMA Skill: Example

An example skill demonstrating the OCLAWMA skill packaging format.
This skill provides basic greeting and echo functionality.

Installation:
    pip install oclawma-skill-example

Usage:
    from oclawma.skills import SkillRegistry

    registry = SkillRegistry()
    # Skill is automatically discovered via entry points

    result = await registry.execute_tool("example", "greet", name="Alice")
    print(result)  # {'success': True, 'output': 'Hello, Alice!'}

For more information, see SKILL.md in the package root.
"""

from .skill import ExampleSkill

__version__ = "1.0.0"
__all__ = ["ExampleSkill"]
