"""OCLAWMA Skill: GitHub

Official GitHub skill for OCLAWMA providing comprehensive repository
management, pull request operations, issue tracking, release management,
and GitHub Actions workflow monitoring.
"""

from oclawma_skill_github.skill import GitHubSkill

__version__ = "1.0.0"
__all__ = ["GitHubSkill"]
