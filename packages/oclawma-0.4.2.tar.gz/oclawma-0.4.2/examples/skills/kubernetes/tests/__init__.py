"""Tests for the Kubernetes skill."""
