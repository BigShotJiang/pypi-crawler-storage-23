"""OCLAWMA Skill: Kubernetes

Official Kubernetes skill for OCLAWMA providing comprehensive cluster
management capabilities including kubectl operations, pod log retrieval,
deployment management, and Helm chart support.

Installation:
    pip install oclawma-skill-kubernetes

Usage:
    from oclawma.skills import SkillRegistry

    registry = SkillRegistry()
    # Skill is automatically discovered via entry points

    # List pods
    result = await registry.execute_tool("kubernetes", "get_pods")

    # Get logs
    result = await registry.execute_tool(
        "kubernetes", "get_logs",
        pod="my-app", tail=100
    )

For more information, see SKILL.md in the package root.
"""

from .skill import KubernetesSkill

__version__ = "1.0.0"
__all__ = ["KubernetesSkill"]
