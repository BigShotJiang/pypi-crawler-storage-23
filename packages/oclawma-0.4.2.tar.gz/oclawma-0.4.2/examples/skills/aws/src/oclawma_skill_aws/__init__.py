"""OCLAWMA Skill: AWS

Official AWS skill for OCLAWMA providing comprehensive cloud resource
management capabilities including EC2, S3, Lambda, CloudWatch, IAM, RDS,
and Route53 operations.

Installation:
    pip install oclawma-skill-aws

Usage:
    from oclawma.skills import SkillRegistry

    registry = SkillRegistry()
    # Skill is automatically discovered via entry points

    # List EC2 instances
    result = await registry.execute_tool("aws", "ec2_list_instances")

    # List S3 buckets
    result = await registry.execute_tool("aws", "s3_list_buckets")

For more information, see SKILL.md in the package root.
"""

from .skill import AwsSkill

__version__ = "1.0.0"
__all__ = ["AwsSkill"]
