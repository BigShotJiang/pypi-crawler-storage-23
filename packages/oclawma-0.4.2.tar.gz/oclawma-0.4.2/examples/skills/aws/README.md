# OCLAWMA Skill: AWS

Official AWS skill for OCLAWMA providing comprehensive cloud resource management capabilities.

## Features

- **EC2 Management** - List, start, stop, and describe instances
- **S3 Operations** - List buckets, upload/download objects, manage files
- **Lambda Functions** - List, invoke functions, get logs
- **CloudWatch** - Get metrics and logs
- **IAM** - List users and roles
- **RDS** - List database instances
- **Route53** - List hosted zones
- **STS** - Get caller identity

## Quick Start

```python
from oclawma.skills import SkillRegistry

# Create registry (skill auto-discovered via entry points)
registry = SkillRegistry()

# List EC2 instances
result = await registry.execute_tool(
    "aws", "ec2_list_instances",
    region="us-east-1"
)

# List S3 buckets
result = await registry.execute_tool("aws", "s3_list_buckets")

# List objects in bucket
result = await registry.execute_tool(
    "aws", "s3_list_objects",
    bucket="my-bucket",
    prefix="data/"
)

# Invoke Lambda function
result = await registry.execute_tool(
    "aws", "lambda_invoke",
    function_name="my-function",
    payload={"key": "value"}
)

# Get current identity
result = await registry.execute_tool("aws", "sts_get_caller_identity")
```

## Installation

```bash
pip install oclawma-skill-aws
```

### Prerequisites

- **AWS CLI** - Installed and configured, OR
- **IAM credentials** - Set via environment variables or ~/.aws/credentials

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `AWS_ACCESS_KEY_ID` | - | AWS access key |
| `AWS_SECRET_ACCESS_KEY` | - | AWS secret key |
| `AWS_SESSION_TOKEN` | - | AWS session token (optional) |
| `AWS_DEFAULT_REGION` | `us-east-1` | Default AWS region |

### AWS Credentials File

Alternatively, configure credentials in `~/.aws/credentials`:

```ini
[default]
aws_access_key_id = YOUR_KEY
aws_secret_access_key = YOUR_SECRET
```

And `~/.aws/config`:

```ini
[default]
region = us-east-1
```

## Documentation

See [SKILL.md](SKILL.md) for detailed documentation on all available tools.

## Development

```bash
# Clone
git clone https://github.com/openclaw/oclawma-skill-aws.git
cd oclawma-skill-aws

# Setup
python -m venv venv
source venv/bin/activate
pip install -e ".[dev]"

# Test
pytest

# Lint
black src tests
ruff check src tests
mypy src
```

## License

MIT License - see [LICENSE](LICENSE) file.
