"""Tests for the AWS skill."""
