"""Tests for the Docker skill."""
