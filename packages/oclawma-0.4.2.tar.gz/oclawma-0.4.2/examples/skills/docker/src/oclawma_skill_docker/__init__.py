"""OCLAWMA Skill: Docker

Official Docker skill for OCLAWMA providing comprehensive container
management capabilities including image operations, container lifecycle,
network and volume management, and Docker Compose support.

Installation:
    pip install oclawma-skill-docker

Usage:
    from oclawma.skills import SkillRegistry

    registry = SkillRegistry()
    # Skill is automatically discovered via entry points

    # List running containers
    result = await registry.execute_tool("docker", "ps")

    # Run a new container
    result = await registry.execute_tool(
        "docker", "run",
        image="nginx:latest",
        name="my-nginx",
        ports=["8080:80"],
        detach=True
    )

For more information, see SKILL.md in the package root.
"""

from .skill import DockerSkill

__version__ = "1.0.0"
__all__ = ["DockerSkill"]
