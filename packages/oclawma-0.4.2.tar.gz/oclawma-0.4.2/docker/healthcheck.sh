#!/bin/bash
# Oclawma Health Check Script
# Returns 0 if healthy, 1 if unhealthy

# Check if oclawma CLI is available
if ! command -v oclawma &> /dev/null; then
    echo "ERROR: oclawma command not found"
    exit 1
fi

# Check if oclawma can execute and return version
if ! oclawma --version &> /dev/null; then
    echo "ERROR: oclawma --version failed"
    exit 1
fi

# Check if data directory is writable
if [ ! -w "/app/data" ]; then
    echo "ERROR: /app/data is not writable"
    exit 1
fi

echo "Health check passed"
exit 0
