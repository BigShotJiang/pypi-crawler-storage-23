"""Tests for OCLAWMA package."""

from oclawma import __author__, __description__, __version__


class TestPackage:
    """Test package metadata."""

    def test_version(self) -> None:
        """Test version is defined."""
        assert isinstance(__version__, str)
        assert __version__ == "0.2.0"

    def test_author(self) -> None:
        """Test author is defined."""
        assert isinstance(__author__, str)
        assert __author__ == "OpenClaw Team"

    def test_description(self) -> None:
        """Test description is defined."""
        assert isinstance(__description__, str)
        assert "Workflow Management Agent" in __description__
