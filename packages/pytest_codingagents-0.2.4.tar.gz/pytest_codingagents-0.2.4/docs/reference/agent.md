# CopilotAgent

::: pytest_codingagents.copilot.agent.CopilotAgent
    options:
      show_source: false
      members:
        - from_copilot_config
        - build_session_config
