# API Reference

::: pytest_codingagents.CopilotAgent
    options:
      show_source: false

::: pytest_codingagents.CopilotResult
    options:
      show_source: false

::: pytest_aitest.execution.optimizer.optimize_instruction
    options:
      show_source: false

::: pytest_aitest.execution.optimizer.InstructionSuggestion
    options:
      show_source: false

## IDE Personas

::: pytest_codingagents.Persona
    options:
      show_source: false

::: pytest_codingagents.VSCodePersona
    options:
      show_source: false

::: pytest_codingagents.CopilotCLIPersona
    options:
      show_source: false

::: pytest_codingagents.ClaudeCodePersona
    options:
      show_source: false

::: pytest_codingagents.HeadlessPersona
    options:
      show_source: false
