"""Exceptions for spicedb-embedded."""


class SpiceDBError(Exception):
    """Raised when SpiceDB operations fail."""
