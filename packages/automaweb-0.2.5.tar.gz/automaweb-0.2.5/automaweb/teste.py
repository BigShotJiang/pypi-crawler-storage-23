import automaweb
import time

cookies = True

nav = automaweb.Navegador(navegador="firefox")
nav.abrir_driver()
nav.abrir_url("https://portal.ifood.com.br/login")
if cookies:
    nav.salvar_cookies(r"C:\Users\joao braga\Downloads\cookies_iFood.json")
    nav.fechar_driver()

else:
    nav.carregar_cookies(r"C:\Users\joao braga\Downloads\cookies_iFood.json")
    nav.recarregar_driver()
    time.sleep(50)
