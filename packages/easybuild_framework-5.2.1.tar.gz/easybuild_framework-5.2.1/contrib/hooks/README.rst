Example implementations of EasyBuild hooks
=================================

.. image:: https://easybuilders.github.io/easybuild/images/easybuild_logo_small.png
   :align: center

EasyBuild website: https://easybuilders.github.io/easybuild/
docs: https://easybuild.readthedocs.io

This directory contain examples of implementations of EasyBuild hooks
used at various sites, along with a couple of small examples with
explanations.

See https://easybuild.readthedocs.io/en/latest/Hooks.html for
documentation on hooks in EasyBuild.
