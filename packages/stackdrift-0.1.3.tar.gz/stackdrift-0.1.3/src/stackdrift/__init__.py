"""stackdrift - CloudFormation drift detector."""

__version__ = "0.1.3"
