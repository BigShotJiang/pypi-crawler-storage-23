"""Allow running as `python -m specwright.cron.sync_status`."""

from .sync_status import main

main()
