"""Handle issues events — stub for future reverse sync."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


async def on_issues(client, payload: dict) -> None:
    """Handle an issues event (stub for future reverse sync).

    Args:
        client: GitHubClient instance.
        payload: The webhook payload.
    """
    action = payload.get("action", "")
    issue_number = payload.get("issue", {}).get("number", "?")
    logger.info(
        "Issue event: action=%s issue=#%s (reverse sync not yet implemented)", action, issue_number
    )
