---
title: "ADR-NNNN: Untitled Decision"
type: adr
status: draft
owner: ""
team: ""
review_status: draft
tags: []
depends_on: []
created: ""
updated: ""
---

# ADR-NNNN: Untitled Decision

## 1. Context

What is the issue that we're seeing that is motivating this decision or change?

## 2. Decision

What is the change that we're proposing and/or doing?

## 3. Consequences

What becomes easier or more difficult to do because of this change?

## 4. Status

Proposed / Accepted / Deprecated / Superseded
