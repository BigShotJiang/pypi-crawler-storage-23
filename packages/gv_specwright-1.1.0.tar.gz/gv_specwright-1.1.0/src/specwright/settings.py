"""Application settings loaded from environment variables."""

from __future__ import annotations

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Specwright application configuration via environment variables."""

    # GitHub App
    gh_app_id: str = ""
    gh_private_key: str = ""
    gh_webhook_secret: str = ""
    gh_installation_id: str = ""

    # Anthropic
    anthropic_api_key: str = ""

    # Jira (optional)
    jira_host: str = ""
    jira_email: str = ""
    jira_api_token: str = ""

    # Linear (optional)
    linear_api_key: str = ""

    # GitHub token for ticket sync (optional)
    github_token: str = ""
    github_owner: str = ""
    github_repo: str = ""

    # Database (optional — app works without it)
    database_url: str = ""

    # Google Cloud / Vertex AI (optional — embedding service)
    google_cloud_project: str = ""
    google_cloud_location: str = "us-central1"
    gcp_service_account_key: str = ""

    # Auth0 (optional — gates /app/* when configured)
    auth0_domain: str = ""
    auth0_client_id: str = ""
    auth0_client_secret: str = ""
    auth0_audience: str = ""

    # Auth0 Device Authorization (CLI auth — may use a separate Native app)
    auth0_device_client_id: str = ""

    # Platform URL (used by CLI to know where to connect)
    platform_url: str = "https://specwright.gernerventures.com"

    @property
    def auth0_enabled(self) -> bool:
        return bool(self.auth0_domain and self.auth0_client_id and self.auth0_client_secret)

    @property
    def auth0_orgs_enabled(self) -> bool:
        """True when Auth0 Organizations mode is active (audience must be set)."""
        return self.auth0_enabled and bool(self.auth0_audience)

    # GitHub OAuth (for web editor — user-level repo access)
    github_oauth_client_id: str = ""
    github_oauth_client_secret: str = ""

    @property
    def github_oauth_enabled(self) -> bool:
        return bool(self.github_oauth_client_id and self.github_oauth_client_secret)

    # PostHog analytics
    posthog_key: str = ""
    posthog_host: str = "https://us.i.posthog.com"

    # PostHog logs via OpenTelemetry (opt-in)
    posthog_logs_enabled: bool = False
    posthog_logs_min_level: str = "WARNING"

    # Server
    port: int = 3000
    log_level: str = "info"
    webhook_path: str = "/webhook"

    # MCP
    mcp_api_key: str | None = None

    # Web UI
    web_org: str = "Gerner-Ventures"
    web_admin_logins: str = ""  # Comma-separated GitHub logins granted specs:admin in the SPA
    cache_ttl_seconds: int = 300

    model_config = {"env_prefix": "", "case_sensitive": False}
