"""MCP server — exposes spec search and retrieval to coding agents."""

from __future__ import annotations
