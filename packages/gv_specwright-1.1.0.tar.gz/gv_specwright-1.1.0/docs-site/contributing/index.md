# Contributing

Thank you for your interest in contributing to Specwright. This section covers everything you need to get started.

## Quick Links

- [Development Setup](./development) — Get a local dev environment running
- [Testing](./testing) — Test strategy and how to run tests
- [Code Style](./code-style) — Linting, formatting, and conventions
