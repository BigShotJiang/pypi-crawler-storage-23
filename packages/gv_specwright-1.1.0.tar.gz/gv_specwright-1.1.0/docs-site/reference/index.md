# Reference

Detailed reference documentation for Specwright's interfaces and formats.

## Tools & Interfaces

- [CLI](./cli) — Command-line interface reference
- [MCP Tools](./mcp) — MCP server tools for coding agents
- [Claude Code Skills](./skills) — Specwright plugin commands for Claude Code
- [REST API](./api) — HTTP API endpoints

## Formats & Schemas

- [Spec Format](./spec-format) — Markdown spec file format specification
- [SPECWRIGHT.yaml](./config) — Configuration file schema reference
