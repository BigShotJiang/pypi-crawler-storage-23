<script setup>
import DefaultTheme from "vitepress/theme";
import { onMounted, watch } from "vue";
import { useRoute } from "vitepress";

const { Layout } = DefaultTheme;
const route = useRoute();
const MAIN_SITE = "https://specwright.gernerventures.com";

function patchLogoLink() {
  const link = document.querySelector(".VPNavBarTitle a");
  if (link && link.getAttribute("href") !== MAIN_SITE) {
    link.setAttribute("href", MAIN_SITE);
  }
  const mobileLink = document.querySelector(".VPNavBarHamburger + a, .VPNavScreenMenuLink a[href='/docs/']");
  if (mobileLink) {
    mobileLink.setAttribute("href", MAIN_SITE);
  }
}

onMounted(() => {
  patchLogoLink();
  watch(
    () => route.path,
    () => requestAnimationFrame(patchLogoLink),
  );
});
</script>

<template>
  <Layout />
</template>
