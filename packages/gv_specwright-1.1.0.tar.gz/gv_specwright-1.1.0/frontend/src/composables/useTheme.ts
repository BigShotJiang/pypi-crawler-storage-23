import { useThemeStore } from '@/stores/theme'
import { storeToRefs } from 'pinia'

export function useTheme() {
  const store = useThemeStore()
  const { mode, isDark, label } = storeToRefs(store)
  return { mode, isDark, label, cycle: store.cycle }
}
