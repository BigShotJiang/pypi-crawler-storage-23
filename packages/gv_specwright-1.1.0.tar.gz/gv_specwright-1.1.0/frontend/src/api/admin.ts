import { get, post } from './client'
import type { IndexingOverview } from './types'

export function fetchIndexingOverview(): Promise<IndexingOverview> {
  return get<IndexingOverview>('/app/admin/api/indexing')
}

export function triggerReindex(installationId: number): Promise<{ ok: boolean }> {
  return post<{ ok: boolean }>(`/app/admin/api/reindex/${installationId}`)
}
