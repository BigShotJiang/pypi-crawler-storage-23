import { get } from './client'
import type { ProfileResponse } from './types'

export function fetchProfile(org: string): Promise<ProfileResponse> {
  return get<ProfileResponse>(`/app/${org}/api/profile`)
}
