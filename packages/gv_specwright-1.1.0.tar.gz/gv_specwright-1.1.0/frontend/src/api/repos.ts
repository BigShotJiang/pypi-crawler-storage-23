import { get } from './client'
import type { RepoSummary } from './types'

export function fetchRepo(org: string, owner: string, repo: string): Promise<RepoSummary> {
  return get<RepoSummary>(`/app/${org}/api/repos/${owner}/${repo}`)
}
