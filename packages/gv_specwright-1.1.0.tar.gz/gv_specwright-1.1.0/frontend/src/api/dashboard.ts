import { get } from './client'
import type { FacetCounts, OrgOverview } from './types'

export function fetchDashboard(org: string): Promise<OrgOverview> {
  return get<OrgOverview>(`/app/${org}/api/dashboard`)
}

export function fetchFacets(org: string): Promise<FacetCounts> {
  return get<FacetCounts>(`/app/${org}/api/facets`)
}
