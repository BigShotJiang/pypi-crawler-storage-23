import { get } from './client'
import type { SpecDetail } from './types'

export function fetchSpec(org: string, owner: string, repo: string, path: string): Promise<SpecDetail> {
  return get<SpecDetail>(`/app/${org}/api/specs/${owner}/${repo}/${path}`)
}
