import { get } from './client'
import type { CoverageApiResponse } from './types'

export function fetchCoverage(org: string, repo?: string, team?: string, days?: number): Promise<CoverageApiResponse> {
  const query = new URLSearchParams()
  if (repo) query.set('repo', repo)
  if (team) query.set('team', team)
  if (days) query.set('days', String(days))
  return get<CoverageApiResponse>(`/app/${org}/api/coverage?${query}`)
}
