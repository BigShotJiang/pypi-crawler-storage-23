<script setup lang="ts">
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const auth = useAuthStore()
const router = useRouter()

function switchOrg(event: Event) {
  const target = event.target as HTMLSelectElement
  router.push(`/app/${target.value}/`)
}
</script>

<template>
  <select
    :value="auth.org"
    class="bg-surface-light dark:bg-[#0a0f1a] border border-border-light dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-md px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-accent-500 focus:border-transparent"
    @change="switchOrg"
  >
    <option v-for="o in auth.orgs" :key="o" :value="o" :selected="o === auth.org">{{ o }}</option>
  </select>
</template>
