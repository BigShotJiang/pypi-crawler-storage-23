/// <reference types="vite/client" />

declare module '*.vue' {
  import type { DefineComponent } from 'vue'
  const component: DefineComponent<object, object, unknown>
  export default component
}

interface SpecwrightSession {
  user: {
    sub: string
    email: string
    name: string
    picture: string
    org_login: string
  } | null
  org: string
  orgs: string[]
  permissions: string[]
  github_user: {
    login: string
    name: string
  } | null
  posthog_key: string
  posthog_host: string
  auth_enabled: boolean
}

interface Window {
  __SPECWRIGHT__?: SpecwrightSession
}
