# CHANGELOG

<!-- version list -->

## v1.1.0 (2026-02-28)

### Documentation

- Update install commands to use gv-specwright package name
  ([`8536e8b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/8536e8bdd3261f6cf2a68ed4be41d2ce92008064))

### Features

- **docs-site**: Logo links to main site + gradient wordmark
  ([`7e55c6b`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/7e55c6ba18aee0b5569382afcc14793850cf4b13))


## v1.0.3 (2026-02-28)

### Bug Fixes

- Add AUTH0_DEVICE_CLIENT_ID to deploy K8s secret
  ([#116](https://github.com/Gerner-Ventures/gv-exp-specwright/pull/116),
  [`fc8b3a8`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/fc8b3a8c21b14a4e9e0cfa21d1942c826976a7c7))


## v1.0.2 (2026-02-28)

### Bug Fixes

- Rename PyPI package to gv-specwright (specwright was taken)
  ([`44e3af3`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/44e3af3397bb8c4deba4da6f4a11edf89edf3433))


## v1.0.1 (2026-02-28)

### Bug Fixes

- Use version tag for pypi-publish action (Docker-based, SHA pinning unsupported)
  ([`b48f730`](https://github.com/Gerner-Ventures/gv-exp-specwright/commit/b48f730f7f8d066135010f9ff72b8cb1e55e3df9))


## v1.0.0 (2026-02-28)

- Initial Release
