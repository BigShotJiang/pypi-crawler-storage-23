"""Compatibility re-export for the routing proxy server."""

from cascadeflow.proxy.server import ProxyConfig, RoutingProxy

__all__ = ["ProxyConfig", "RoutingProxy"]
