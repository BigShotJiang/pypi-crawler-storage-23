"""SkillFortify CLI package — command-line interface for skill supply chain security."""
