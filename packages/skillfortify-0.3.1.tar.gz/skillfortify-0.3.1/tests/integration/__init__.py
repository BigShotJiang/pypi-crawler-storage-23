"""Integration tests for the SkillFortify analysis pipeline."""
