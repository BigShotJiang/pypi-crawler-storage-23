"""
执行shell
"""

from .run import run_shell, run_shell_list

__all__ = ["run_shell", "run_shell_list"]
