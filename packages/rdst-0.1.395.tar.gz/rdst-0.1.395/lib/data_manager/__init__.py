# DataManager module
from .data_manager import DataManager