Search the web for up-to-date information beyond your knowledge cutoff. Returns title, URL, and snippet for each result. Domain filtering is supported to include or block specific websites.

