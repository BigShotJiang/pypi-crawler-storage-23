import os
import hashlib
import numpy as np
import pandas as pd

class NipahExamGenerator:
    def __init__(self, salt="NIPAH_EXAM_2026"):
        self.salt = salt
        
    # =========================
    # Utility: seed ต่อ student
    # =========================
    def _seed_from_student_id(self, student_id: str) -> int:
        s = (self.salt + "|" + student_id).encode("utf-8")
        h = hashlib.sha256(s).hexdigest()
        return int(h[:8], 16) # เอา 8 hex ตัวแรกเป็น seed

    # =========================
    # สร้างข้อมูล Nipah Risk
    # =========================
    def _generate_nipah_dataset(self, n: int, rng: np.random.Generator, include_label: bool = True) -> pd.DataFrame:
        # Demographic
        age = rng.integers(6, 19, size=n)  # โฟกัสนักเรียน (6-18)
        grade = np.clip((age - 5), 1, 12)  # ประมาณชั้นเรียน
        sex = rng.choice(["M", "F"], size=n, p=[0.49, 0.51])
    
        # Exposure / behavior
        contacts_7d = rng.poisson(10, size=n).clip(0, 60)  # การพบปะในโรงเรียน
        close_contact_case = rng.binomial(1, p=np.clip(contacts_7d / 50, 0.03, 0.60))
    
        # Context risk (พื้นที่/กิจกรรมเสี่ยง)
        district_risk = rng.choice(["low", "medium", "high"], size=n, p=[0.55, 0.35, 0.10])
    
        # Animal / food exposure (สมมติปัจจัยเสี่ยงแบบง่ายสำหรับเด็ก)
        fruit_exposure = rng.binomial(1, p=np.clip(0.08 + 0.10*(district_risk=="high"), 0.05, 0.30))
        bat_area_visit = rng.binomial(1, p=np.clip(0.03 + 0.08*(district_risk!="low"), 0.02, 0.20))
    
        # Symptoms (ทำให้ง่ายต่อเด็ก แต่ยังคงความสมจริง)
        fever = rng.binomial(1, p=np.clip(0.05 + 0.22*close_contact_case + 0.10*fruit_exposure, 0.02, 0.65))
        cough = rng.binomial(1, p=np.clip(0.06 + 0.18*close_contact_case, 0.02, 0.60))
        headache = rng.binomial(1, p=np.clip(0.07 + 0.12*close_contact_case, 0.02, 0.55))
        confusion = rng.binomial(1, p=np.clip(0.01 + 0.06*close_contact_case + 0.08*bat_area_visit, 0.01, 0.25))  # อาการทางสมอง (simplified)
        symptom_days = rng.integers(0, 8, size=n)
    
        # Screening (สมมติ)
        screening = rng.choice(["not_tested", "negative", "positive"], size=n, p=[0.65, 0.30, 0.05])
    
        # =========================
        # สร้าง score เพื่อจัดกลุ่ม
        # =========================
        district_bonus = pd.Series(district_risk).map({"low": 0.0, "medium": 0.7, "high": 1.3}).to_numpy()
        symptom_score = fever*1.4 + cough*1.0 + headache*0.8 + confusion*2.2
        exposure_score = (0.10*contacts_7d) + (1.6*close_contact_case) + (1.2*fruit_exposure) + (1.4*bat_area_visit) + district_bonus
        test_bonus = (screening == "positive")*2.0 - (screening == "negative")*0.8
    
        score = -4.8 + 0.55*symptom_score + 0.50*exposure_score + test_bonus + rng.normal(0, 0.8, size=n)
    
        # 4 กลุ่ม: ปลอดภัย / เฝ้าระวัง / เสี่ยง / ผู้ติดเชื้อ
        y = np.zeros(n, dtype=int)
        y[score > -0.8] = 1
        y[score >  1.0] = 2
        y[score >  2.3] = 3
    
        label_map = {
            0: "กลุ่มปลอดภัย",
            1: "กลุ่มเฝ้าระวัง",
            2: "กลุ่มเสี่ยง",
            3: "กลุ่มผู้ติดเชื้อ",
        }
    
        df = pd.DataFrame({
            "record_id": [f"R{100000+i}" for i in range(n)],
            "age": age,
            "grade": grade,
            "sex": sex,
            "contacts_last7d": contacts_7d,
            "close_contact_case": close_contact_case,
            "district_risk": district_risk,
            "fruit_exposure": fruit_exposure,
            "bat_area_visit": bat_area_visit,
            "fever": fever,
            "cough": cough,
            "headache": headache,
            "confusion": confusion,
            "symptom_days": symptom_days,
            "screening_result": screening,
        })
    
        # ใส่ missing เล็กน้อยเพื่อให้ได้ฝึก preprocess
        for col, p in [("screening_result", 0.02), ("symptom_days", 0.02)]:
            mask = rng.random(n) < p
            df.loc[mask, col] = np.nan
    
        if include_label:
            df["risk_group"] = pd.Series(y).map(label_map)
        return df

    # =========================
    # สร้างไฟล์ต่อคน (1:1)
    # =========================
    def create_files(
        self,
        student_ids,
        out_dir="nipah_exam_datasets",
        n_train=800,
        n_test=250,
    ):
        
        os.makedirs(out_dir, exist_ok=True)

        for sid in student_ids:
            seed = self._seed_from_student_id(sid)
            rng = np.random.default_rng(seed)
    
            train_df = self._generate_nipah_dataset(n_train, rng, include_label=True)
            test_df = self._generate_nipah_dataset(n_test, rng, include_label=False)
    
            train_path = os.path.join(out_dir, f"{sid}_train.csv")
            test_path  = os.path.join(out_dir, f"{sid}_test.csv")
    
            train_df.to_csv(train_path, index=False)
            test_df.to_csv(test_path, index=False)
    
            print(f"[OK] {sid}: train={train_df.shape} test={test_df.shape} -> {out_dir}/")