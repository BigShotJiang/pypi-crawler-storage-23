import re

from user_scanner.core.orchestrator import status_validate
from user_scanner.core.result import Result


def validate_mastodon(user: str) -> Result:
    if not (3 <= len(user) <= 30):
        return Result.error("Length must be 3-30 characters")

    if not re.match(r"^[a-zA-Z0-9_-]+$", user):
        return Result.error(
            "Usernames can only contain letters, numbers, underscores and hyphens"
        )

    if not re.match(r"^[a-zA-Z0-9].*[a-zA-Z0-9]$", user):
        return Result.error("Username must start and end with a letter or number")

    url = f"https://mastodon.social/api/v1/accounts/lookup?acct={user}"
    show_url = "https://mastodon.social"

    return status_validate(
        url, available=404, taken=200, show_url=show_url, follow_redirects=True
    )
