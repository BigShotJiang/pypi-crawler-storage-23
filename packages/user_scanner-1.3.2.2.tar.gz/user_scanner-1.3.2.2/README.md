# User Scanner

![User Scanner Logo](https://github.com/user-attachments/assets/49ec8d24-665b-4115-8525-01a8d0ca2ef4)
<p align="center">
  <img src="https://img.shields.io/badge/Version-1.3.2.2-blueviolet?style=for-the-badge&logo=github" />
  <img src="https://img.shields.io/github/issues/kaifcodec/user-scanner?style=for-the-badge&logo=github" />
  <img src="https://img.shields.io/badge/Tested%20on-Termux-black?style=for-the-badge&logo=termux" />
  <img src="https://img.shields.io/badge/Tested%20on-Windows-cyan?style=for-the-badge&logo=Windows" />
  <img src="https://img.shields.io/badge/Tested%20on-Linux-black?style=for-the-badge&logo=Linux" />
  <img src="https://img.shields.io/pypi/dm/user-scanner?style=for-the-badge" />
</p>

---

A powerful *Email OSINT tool* that checks if a specific email is registered on various sites, combined with *username scanning* for OSINT or branding — 2-in-1 tool.  

Perfect for fast, accurate username and email OSINT

Also perfect for finding a **unique username** across GitHub, Twitter, Reddit, Instagram, and more, all in a single command.  

## Features

- ✅ Email & username OSINT: check email registrations and username availability across social, developer, creator, and other platforms  
- ✅ Dual-mode usage: works as an email scanner, username scanner, or username-only tool  
- ✅ Clear results: `Registered` / `Not Registered` for emails and `Not Found` / `Found` / `Error` for usernames with precise failure reasons  
- ✅ Fully modular architecture for easy addition of new platform modules  
- ✅ Bulk scanning support for usernames and emails via input files  
- ✅ Wildcard-based username permutations with automatic variation generation  
- ✅ Multiple output formats: console, **JSON**, and **CSV**, with file export support  
- ✅ Proxy support with rotation and pre-scan proxy validation  
- ✅ Smart auto-update system with interactive upgrade prompts via PyPI  

## Virtual Environment (optional but recommended)

```bash
# create venv
python -m venv .venv
````
## Activate venv
```bash
# Linux / macOS
source .venv/bin/activate

# Windows (PowerShell)
.venv\Scripts\Activate.ps1
```
## Installation
```bash
# upgrade pip
python -m pip install --upgrade pip

# install
pip install user-scanner
```
---
### Important Flags

See [Important flags](docs/FLAGS.md) here and use the tool powerfully


## Usage

### Basic username/email scan

Scan a single email or username across **all** available modules/platforms:

```bash
user-scanner -e johndoe@gmail.com   # single email scanning 
user-scanner -u johndoe             # single username scanning 
```
### Verbose mode 

Use `-v` flag to show the url of the sites being checked
```bash
user-scanner -v -e johndoe@gmail.com -c dev
```
Output:
```sh
  ...
  [✔] Huggingface [https://huggingface.co] (johndoe@gmail.com): Registered
  [✔] Envato [https://account.envato.com] (johndoe@gmail.com): Registered
  [✔] Replit [https://replit.com] (johndoe@gmail.com): Registered
  [✔] Xda [https://xda-developers.com] (johndoe@gmail.com): Registered
  ...
```

### Selective scanning

Scan only specific categories or single modules:

```bash
user-scanner -u johndoe -c dev                # developer platforms only
user-scanner -e johndoe@gmail.com -m github   # only GitHub
```

### Bulk email/username scanning

Scan multiple emails/usernames from a file (one email/username per line):
- Can also be combined with categories or modules using `-c` , `-m` and other flags

```bash
user-scanner -ef emails.txt     # bulk email scan
user-scanner -uf usernames.txt  # bulk username scan
```
---
### Library mode for email_scan
Only available for `user-scanner>=1.2.0`

See full usage (eg. category checks, full scan) guide [library usage](docs/USAGE.md)

- Email scan example (single module):

```python

import asyncio
from user_scanner.core import engine
from user_scanner.email_scan.dev import github

async def main():
    # Engine detects 'email_scan' path -> returns "Registered" status
    result = await engine.check(github, "test@gmail.com")
    json_data = result.to_json() # returns JSON output
    csv_data = result.to_csv()   # returns CSV output
    print(json_data)             # prints the json data

asyncio.run(main())

```
Output:

```json

{
        "email": "test@gmail.com",
        "category": "Dev",
        "site_name": "Github",
        "status": "Registered",
        "url": "https://github.com",
        "reason": ""
}
```
---


### Using Proxies

Validate proxies before scanning (tests each proxy against google.com):

```bash
user-scanner -u johndoe -P proxies.txt --validate-proxies # recommended
```

This will:
1. Filter out non-working proxies
2. Save working proxies to `validated_proxies.txt`
3. Use only validated proxies for scanning

### Screenshots:
**Note**: Screenshots might be outdated

---
<img width="1076" height="1150" alt="1000174715" src="https://github.com/user-attachments/assets/c5432f75-0dd4-4c19-a900-3093ef56e5ca" />

---
<img width="1080" height="1020" alt="1000174716" src="https://github.com/user-attachments/assets/c1469146-423d-463e-8a29-2a7c3e27c13e" />


---
## ❤️ Support the project

If this project helps you, consider supporting its development:

**BTC (SegWit):** `bc1q0dzkuav8lq9lwu7gc457vwlda4utfcr5hpv7ka`


---
## Contributing

Modules are organized under `user_scanner/`:

```
user_scanner/
├── email_scan/       # Currently in development
│   ├── social/       # Social email scan modules (Instagram, Mastodon, X, etc.)
|   ├── adult/        # Adult sites 
|    ...
├── user_scan/
│   ├── dev/          # Developer platforms (GitHub, GitLab, npm, etc.)
│   ├── social/       # Social platforms (Twitter/X, Reddit, Instagram, Discord, etc.)
│   ├── creator/      # Creator platforms (Hashnode, Dev.to, Medium, Patreon, etc.)
│   ├── community/    # Community platforms (forums, StackOverflow, HackerNews, etc.)
│   ├── gaming/       # Gaming sites (chess.com, Lichess, Roblox, Minecraft, etc.)
    ...
```

See detailed [Contributing guidelines](CONTRIBUTING.md)

---

## Dependencies: 
- [httpx](https://pypi.org/project/httpx/)
- [colorama](https://pypi.org/project/colorama/)

---

## License

This project is licensed under the **MIT License**. See [LICENSE](LICENSE) for details.

---

## ⚠️ Disclaimer

This tool is provided for **educational purposes** and **authorized security research** only.

- **User Responsibility:** Users are solely responsible for ensuring their usage complies with all applicable laws and the Terms of Service (ToS) of any third-party providers.
- **Methodology:** The tool interacts only with **publicly accessible, unauthenticated web endpoints**. It does not bypass authentication, security controls, or access private user data.
- **No Profiling:** This software performs only basic **yes/no availability checks**. It does not collect, store, aggregate, or analyze user data, behavior, or identities.
- **Limitation of Liability:** The software is provided **“as is”**, without warranty of any kind. The developers assume no liability for misuse or any resulting damage or legal consequences.

---

## 🛠️ Troubleshooting

Some sites may return **403 Forbidden** or **connection timeout** errors, especially if they are blocked in your region (this is common with some adult sites).

- If a site is blocked in your region, use a VPN and select a region where you know the site is accessible.
- Then run the tool again.

These issues are caused by regional or network restrictions, not by the tool itself. If it still fails, report the error by opening an issue.
