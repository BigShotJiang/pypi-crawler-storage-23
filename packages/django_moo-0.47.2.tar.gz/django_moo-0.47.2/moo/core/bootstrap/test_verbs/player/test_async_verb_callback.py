#!moo verb test-async-verb-callback --on "player class" --dspec this

# pylint: disable=return-outside-function,undefined-variable

print(args[0])  # pylint: disable=undefined-variable  # type: ignore
