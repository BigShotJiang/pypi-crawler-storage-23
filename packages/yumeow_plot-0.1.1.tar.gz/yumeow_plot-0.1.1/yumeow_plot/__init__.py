from .figure import get_fig, merge_axes
from .layout import calculate_size, get_side_rect, get_margin_rect
from .utils import load_zh_font
