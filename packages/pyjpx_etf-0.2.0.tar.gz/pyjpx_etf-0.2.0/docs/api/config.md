# Config

::: pyjpx_etf.config
    options:
      show_root_heading: true

::: pyjpx_etf.config.Config
