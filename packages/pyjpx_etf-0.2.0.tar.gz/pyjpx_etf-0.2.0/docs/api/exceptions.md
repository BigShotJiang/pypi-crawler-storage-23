# Exceptions

::: pyjpx_etf.PyJPXETFError

::: pyjpx_etf.ETFNotFoundError

::: pyjpx_etf.FetchError

::: pyjpx_etf.ParseError
