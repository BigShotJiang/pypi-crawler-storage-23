"""Configuration models — project config, Foundry connection, framework settings.

SPEC-001 §3.1–3.3, SPEC-006: ProjectConfig, ProjectMeta, FoundryConnection.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# ── Enums ──


class UseCase(str, Enum):
    """Agent use case classification."""

    RAG = "rag"
    AGENT = "agent"
    MULTI_AGENT = "multi-agent"


class Framework(str, Enum):
    """Supported agent frameworks."""

    SEMANTIC_KERNEL = "semantic-kernel"
    AUTOGEN = "autogen"
    AGENT_SERVICE = "agent-service"
    CUSTOM = "custom"


class CredentialType(str, Enum):
    """Azure credential selection."""

    DEFAULT = "default"
    MANAGED_IDENTITY = "managed_identity"
    CLI = "cli"


# ── Config Sections ──


class ProjectMeta(BaseModel):
    """Project identity and classification (SPEC-001 §3.2)."""

    name: str = Field(..., pattern=r"^[a-z0-9][a-z0-9._-]{0,62}$")
    description: str = ""
    version: str = "0.1.0"
    tags: dict[str, str] = Field(default_factory=dict)


class RateLimitConfig(BaseModel):
    """Foundry API rate limiting (SPEC-006 §3)."""

    requests_per_second: int = Field(default=10, ge=1, le=100)
    burst: int = Field(default=20, ge=1, le=200)
    retry_on_429: bool = True
    max_retries: int = Field(default=3, ge=0, le=10)
    retry_delay_seconds: int = Field(default=5, ge=1, le=60)


class FoundryConnection(BaseModel):
    """Azure AI Foundry project connection (SPEC-001 §3.3).

    The YAML field ``foundry.project_connection`` maps to ``connection_string``.
    """

    project_connection: str = Field(
        ..., description="Foundry project connection string or ${ENV_VAR}"
    )
    credential: CredentialType = CredentialType.DEFAULT
    rate_limit: RateLimitConfig = Field(default_factory=RateLimitConfig)


class AgentConfig(BaseModel):
    """Agent configuration (SPEC-006 §3)."""

    framework: Framework
    use_case: UseCase
    entry_point: str = Field(..., description="Agent entry point (file path or URL)")
    timeout_seconds: int = Field(default=120, ge=1, le=3600)
    max_concurrency: int = Field(default=5, ge=1, le=100)


class SemanticKernelConfig(BaseModel):
    """SK-specific framework config (SPEC-006 §4)."""

    kernel_var: str = "kernel"
    capture_plugins: bool = True
    capture_planner_steps: bool = True
    service_id: str | None = None
    settings_override: dict[str, Any] = Field(default_factory=dict)


class AutoGenConfig(BaseModel):
    """AutoGen-specific framework config (SPEC-006 §4)."""

    team_var: str = "team"
    capture_agent_messages: bool = True
    conversation_turn_eval: bool = False
    max_turns: int | None = None


class AgentServiceConfig(BaseModel):
    """Agent Service-specific framework config (SPEC-006 §4)."""

    agent_id: str | None = None
    project_connection: str | None = None
    replay_threads: bool = False
    capture_file_search: bool = True
    capture_code_interpreter: bool = True


class CustomFrameworkConfig(BaseModel):
    """Custom framework config (SPEC-006 §4)."""

    function_name: str | None = None
    response_format: str = "string"  # "string" | "agentoutput" | "json"


class FrameworkConfig(BaseModel):
    """Framework-specific settings — only the matching section is read (SPEC-006 §4)."""

    semantic_kernel: SemanticKernelConfig | None = None
    autogen: AutoGenConfig | None = None
    agent_service: AgentServiceConfig | None = None
    custom: CustomFrameworkConfig | None = None


class DatasetRef(BaseModel):
    """Dataset registration in config (SPEC-001 §3.6)."""

    name: str
    path: str
    format: str = "jsonl"  # "jsonl" | "csv" | "json"
    description: str = ""


class DatasetsConfig(BaseModel):
    """Datasets section in agentops.yaml (SPEC-006 §5)."""

    default: str | None = None
    entries: list[DatasetRef] = Field(default_factory=list)


class EvaluatorDef(BaseModel):
    """Evaluator definition within a bundle (SPEC-006 §6)."""

    name: str
    type: str = "foundry"  # "foundry" | "custom" | "composite"
    threshold: float | None = None
    weight: float = 1.0
    module: str | None = None  # For custom evaluators
    class_name: str | None = Field(default=None, alias="class")
    config: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class CustomBundleDef(BaseModel):
    """User-defined bundle in agentops.yaml (SPEC-006 §6)."""

    name: str
    description: str = ""
    evaluators: list[EvaluatorDef]


class BundlesConfig(BaseModel):
    """Bundles section in agentops.yaml (SPEC-006 §6)."""

    default: str = "rag_quality"
    custom: list[CustomBundleDef] = Field(default_factory=list)


class RunsConfig(BaseModel):
    """Runs section in agentops.yaml (SPEC-006 §7)."""

    output_dir: str = "agentops/runs"
    keep_last: int = Field(default=50, ge=0)
    auto_report: bool = True
    report_format: str = "markdown"  # "markdown" | "json" | "html"
    fail_on_threshold: bool = False


class CustomAdapterDef(BaseModel):
    """Custom adapter registration (SPEC-006 §8)."""

    name: str
    module: str
    class_name: str = Field(..., alias="class")

    model_config = {"populate_by_name": True}


class AdaptersConfig(BaseModel):
    """Adapters section in agentops.yaml (SPEC-006 §8)."""

    custom: list[CustomAdapterDef] = Field(default_factory=list)


class LoggingConfig(BaseModel):
    """Logging section in agentops.yaml (SPEC-006 §9)."""

    level: str = "info"  # "debug" | "info" | "warning" | "error"
    file: str | None = None
    format: str = "text"  # "text" | "json"


# ── Root Config ──


class ProjectConfig(BaseModel):
    """Root configuration — deserialized from agentops.yaml (SPEC-001 §3.1, SPEC-006 §3).

    This is the single source of truth for a project's settings.
    """

    schema_version: str = "1.0"
    project: ProjectMeta
    foundry: FoundryConnection
    agent: AgentConfig
    framework_config: FrameworkConfig | None = None
    datasets: DatasetsConfig = Field(default_factory=DatasetsConfig)
    bundles: BundlesConfig = Field(default_factory=BundlesConfig)
    runs: RunsConfig = Field(default_factory=RunsConfig)
    adapters: AdaptersConfig = Field(default_factory=AdaptersConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
