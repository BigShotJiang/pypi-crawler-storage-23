"""Bundle and evaluator reference models.

SPEC-001 §3.4–3.5: BundleConfig, EvaluatorRef, EvaluatorType.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from agentops_toolkit.models.config import UseCase


class EvaluatorType(str, Enum):
    """Source of an evaluator."""

    FOUNDRY = "foundry"
    CUSTOM = "custom"
    COMPOSITE = "composite"


class EvaluatorRef(BaseModel):
    """Reference to a specific evaluator with its configuration (SPEC-001 §3.5)."""

    name: str
    type: EvaluatorType = EvaluatorType.FOUNDRY
    params: dict[str, Any] = Field(default_factory=dict)
    weight: float = Field(default=1.0, ge=0.0)
    column_mapping: dict[str, str] = Field(default_factory=dict)


class BundleConfig(BaseModel):
    """Evaluation bundle — a curated set of evaluators (SPEC-001 §3.4).

    Built-in bundles are shipped with AgentOps and marked ``builtin=True``.
    Users can create custom bundles via ``agentops bundle create``.
    """

    name: str
    description: str = ""
    use_case: UseCase | None = None
    evaluators: list[EvaluatorRef] = Field(default_factory=list)
    thresholds: dict[str, float] = Field(default_factory=dict)
    tags: list[str] = Field(default_factory=list)
    builtin: bool = False
