"""Observability data models (Phase 2).

SPEC-007 §8: TraceSpan, ContinuousEvalResult, MonitoringSnapshot.
"""
