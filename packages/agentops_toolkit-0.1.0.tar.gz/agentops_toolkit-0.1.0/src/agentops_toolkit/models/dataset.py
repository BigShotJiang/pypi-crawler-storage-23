"""Dataset models — entries, tool calls, conversation turns.

SPEC-001 §3.6–3.9: DatasetConfig, DatasetEntry, ToolCall, ConversationTurn.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class DataFormat(str, Enum):
    """Supported dataset file formats."""

    JSONL = "jsonl"
    CSV = "csv"
    JSON = "json"


class ToolCall(BaseModel):
    """A tool/function call made by an agent (SPEC-001 §3.8)."""

    id: str
    name: str
    arguments: dict[str, Any] = Field(default_factory=dict)
    result: Any | None = None
    timestamp: datetime | None = None
    duration_ms: float | None = None


class ConversationTurn(BaseModel):
    """One turn in a multi-agent conversation (SPEC-001 §3.9)."""

    turn_index: int
    agent_name: str
    role: str  # "user" | "assistant" | "system" | "tool"
    content: str
    tool_calls: list[ToolCall] | None = None
    timestamp: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class DatasetEntry(BaseModel):
    """One row of evaluation data (SPEC-001 §3.7).

    The ``query`` field is always required. Other fields are optional
    and depend on the use case and evaluator requirements.
    """

    id: str = ""
    query: str
    context: str | list[str] | None = None
    response: str | None = None
    ground_truth: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    tool_calls: list[ToolCall] | None = None
    conversation_turns: list[ConversationTurn] | None = None
