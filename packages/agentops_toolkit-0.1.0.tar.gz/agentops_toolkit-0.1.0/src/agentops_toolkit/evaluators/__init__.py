"""Evaluators — built-in and custom evaluator implementations.

SPEC-003 §3: BaseEvaluator, FoundryEvaluatorWrapper, CustomEvaluator.
SPEC-008 §5: IQ-specific evaluators (Phase 2).
"""
