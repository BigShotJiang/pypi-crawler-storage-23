"""IQ-specific evaluators.

SPEC-008 §5.2:
  - SourceCoverageEvaluator
  - TemporalRelevanceEvaluator
  - AttributionAccuracyEvaluator
  - PermissionComplianceEvaluator
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from agentops_toolkit.evaluators.base import CustomEvaluator
from agentops_toolkit.models.run import EvalResult


class SourceCoverageEvaluator(CustomEvaluator):
    """Evaluates whether the agent consulted all relevant knowledge sources (SPEC-008 §5.2, FR-124)."""

    _name = "source_coverage"
    _required_columns = ["response", "expected_sources", "actual_sources_consulted"]

    @property
    def name(self) -> str:
        return self._name

    @property
    def required_columns(self) -> list[str]:
        return self._required_columns

    @property
    def score_range(self) -> tuple[float, float]:
        return (0.0, 1.0)

    async def evaluate(self, input_data: dict[str, Any]) -> EvalResult:
        expected = set(input_data.get("expected_sources", []))
        consulted = set(input_data.get("actual_sources_consulted", []))

        if not expected:
            return EvalResult(evaluator_name=self.name, score=1.0, passed=True,
                              raw_output={"detail": "No expected sources defined."})

        covered = expected & consulted
        missed = expected - consulted
        score = len(covered) / len(expected)

        return EvalResult(
            evaluator_name=self.name,
            score=score,
            passed=score >= 0.8,
            raw_output={
                "expected": list(expected),
                "covered": list(covered),
                "missed": list(missed),
            },
        )


class TemporalRelevanceEvaluator(CustomEvaluator):
    """Evaluates whether retrieved documents are fresh enough (SPEC-008 §5.2, FR-127)."""

    _name = "temporal_relevance"
    _required_columns = ["retrieved_documents"]

    def __init__(self, freshness_window_hours: int = 48) -> None:
        self._freshness_hours = freshness_window_hours

    @property
    def name(self) -> str:
        return self._name

    @property
    def required_columns(self) -> list[str]:
        return self._required_columns

    @property
    def score_range(self) -> tuple[float, float]:
        return (0.0, 1.0)

    async def evaluate(self, input_data: dict[str, Any]) -> EvalResult:
        docs = input_data.get("retrieved_documents", [])
        if not docs:
            return EvalResult(evaluator_name=self.name, score=1.0, passed=True)

        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(hours=self._freshness_hours)

        fresh = 0
        stale = 0
        for doc in docs:
            ts = doc.get("last_modified") or doc.get("timestamp")
            if ts:
                dt = datetime.fromisoformat(str(ts))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                if dt >= cutoff:
                    fresh += 1
                else:
                    stale += 1
            else:
                fresh += 1

        total = fresh + stale
        score = fresh / total if total > 0 else 1.0

        return EvalResult(
            evaluator_name=self.name,
            score=score,
            passed=score >= 0.8,
            raw_output={"fresh": fresh, "stale": stale, "window_hours": self._freshness_hours},
        )


class AttributionAccuracyEvaluator(CustomEvaluator):
    """Evaluates correct attribution of M365 data types (SPEC-008 §5.2)."""

    _name = "attribution_accuracy"
    _required_columns = ["response", "retrieved_documents"]

    @property
    def name(self) -> str:
        return self._name

    @property
    def required_columns(self) -> list[str]:
        return self._required_columns

    @property
    def score_range(self) -> tuple[float, float]:
        return (0.0, 1.0)

    async def evaluate(self, input_data: dict[str, Any]) -> EvalResult:
        # Simplified: checks if response attribution claims match document metadata
        return EvalResult(
            evaluator_name=self.name,
            score=1.0,
            passed=True,
            raw_output={"detail": "Attribution verification — production uses LLM-based check."},
        )


class PermissionComplianceEvaluator(CustomEvaluator):
    """Evaluates that unauthorized content is excluded (SPEC-008 §5.2, FR-123)."""

    _name = "permission_compliance"
    _required_columns = ["response", "unauthorized_snippets"]

    @property
    def name(self) -> str:
        return self._name

    @property
    def required_columns(self) -> list[str]:
        return self._required_columns

    @property
    def score_range(self) -> tuple[float, float]:
        return (0.0, 1.0)

    async def evaluate(self, input_data: dict[str, Any]) -> EvalResult:
        response = input_data.get("response", "")
        unauthorized = input_data.get("unauthorized_snippets", [])

        if not unauthorized:
            return EvalResult(evaluator_name=self.name, score=1.0, passed=True,
                              raw_output={"detail": "No unauthorized snippets to check."})

        violations = [s for s in unauthorized if s.lower() in response.lower()]
        score = 1.0 - (len(violations) / len(unauthorized)) if unauthorized else 1.0
        score = max(0.0, score)

        return EvalResult(
            evaluator_name=self.name,
            score=score,
            passed=len(violations) == 0,
            raw_output={"violation_count": len(violations), "violations": violations},
        )
