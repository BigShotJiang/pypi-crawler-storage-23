"""Hook system — pre/post event handlers.

SPEC-003 §8, FR-142: @agentops.hook("pre_eval") / @agentops.hook("post_run").
"""
