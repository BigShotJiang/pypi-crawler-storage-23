"""Python API — programmatic client.

SPEC-003 §6, FR-140–FR-142: AgentOpsClient with run(), evaluate(), compare().
"""
