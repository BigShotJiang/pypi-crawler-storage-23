"""FoundrySDKClient — default evaluation backend using azure-ai-evaluation SDK.

SPEC-003 §1.1: Implements FoundryClient protocol.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


# ── Foundry evaluator name → SDK class mapping ──

_EVALUATOR_MAP: dict[str, str] = {
    "groundedness": "GroundednessEvaluator",
    "relevance": "RelevanceEvaluator",
    "coherence": "CoherenceEvaluator",
    "fluency": "FluencyEvaluator",
    "similarity": "SimilarityEvaluator",
    "f1_score": "F1ScoreEvaluator",
    "hate_unfairness": "HateUnfairnessEvaluator",
    "sexual": "SexualEvaluator",
    "violence": "ViolenceEvaluator",
    "self_harm": "SelfHarmEvaluator",
    "protected_material": "ProtectedMaterialEvaluator",
    "jailbreak": "JailbreakEvaluator",
}


def _get_evaluator_class(name: str) -> Any:
    """Dynamically import a Foundry evaluator class by name."""
    class_name = _EVALUATOR_MAP.get(name)
    if class_name is None:
        raise ValueError(
            f"Unknown Foundry evaluator: '{name}'. "
            f"Available: {', '.join(sorted(_EVALUATOR_MAP.keys()))}"
        )
    try:
        import azure.ai.evaluation as eval_module

        return getattr(eval_module, class_name)
    except (ImportError, AttributeError) as e:
        raise ImportError(
            f"Cannot import {class_name} from azure.ai.evaluation. "
            "Ensure azure-ai-evaluation is installed."
        ) from e


class FoundrySDKClient:
    """Default FoundryClient implementation using azure-ai-evaluation SDK.

    SPEC-003 §1.1: Wraps all Foundry SDK calls behind the FoundryClient interface
    so breaking changes are absorbed here, not scattered across the codebase.
    """

    def __init__(
        self,
        project_connection: str,
        credential: Any | None = None,
    ) -> None:
        self._project_connection = project_connection
        self._credential = credential

    def _get_credential(self) -> Any:
        if self._credential:
            return self._credential
        from azure.identity import DefaultAzureCredential

        return DefaultAzureCredential()

    def build_evaluators(
        self,
        evaluator_names: list[str],
        model_config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Build a dict of evaluator instances keyed by name.

        Args:
            evaluator_names: List of Foundry evaluator names (e.g. ["groundedness", "relevance"])
            model_config: Optional model config for LLM-as-judge evaluators
        """
        evaluators: dict[str, Any] = {}
        for name in evaluator_names:
            cls = _get_evaluator_class(name)
            if model_config:
                evaluators[name] = cls(model_config=model_config)
            else:
                evaluators[name] = cls()
        return evaluators

    async def evaluate(
        self,
        evaluators: dict[str, Any],
        data: dict[str, Any],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run evaluators against input data via azure.ai.evaluation.evaluate().

        This is the core SDK call. Returns the raw Foundry result dict.
        """
        from azure.ai.evaluation import evaluate as foundry_evaluate

        result = foundry_evaluate(
            evaluators=evaluators,
            data=data,
            azure_ai_project=self._project_connection,
            **kwargs,
        )
        return dict(result) if result else {}

    async def evaluate_single(
        self,
        evaluator_name: str,
        input_data: dict[str, Any],
        model_config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Evaluate a single entry with a single evaluator.

        Simpler interface for per-entry evaluation.
        """
        cls = _get_evaluator_class(evaluator_name)
        evaluator = cls(model_config=model_config) if model_config else cls()

        # Call the evaluator directly (synchronous in the SDK)
        result = evaluator(**input_data)
        return dict(result) if result else {}

    async def check_connectivity(self) -> bool:
        """Verify Foundry credentials and project reachability."""
        try:
            credential = self._get_credential()
            # Attempt to get a token — validates credentials
            credential.get_token("https://management.azure.com/.default")
            return True
        except Exception:
            logger.warning("Foundry connectivity check failed", exc_info=True)
            return False
