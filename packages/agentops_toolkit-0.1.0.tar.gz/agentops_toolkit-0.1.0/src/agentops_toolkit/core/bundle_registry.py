"""Bundle registry — loads built-in and user-defined bundles.

SPEC-001 §3.4, SPEC-003 §3: Resolves bundle names to BundleConfig objects.
"""

from __future__ import annotations

from importlib import resources
from pathlib import Path
from typing import TYPE_CHECKING

from ruamel.yaml import YAML

from agentops_toolkit.models.bundle import BundleConfig, EvaluatorRef
from agentops_toolkit.models.config import UseCase

if TYPE_CHECKING:
    from agentops_toolkit.models.config import BundlesConfig

_yaml = YAML(typ="safe")

# ── Built-in bundle cache ──

_BUILTIN_CACHE: dict[str, BundleConfig] | None = None


def _parse_bundle(data: dict) -> BundleConfig:
    """Parse a raw YAML dict into a BundleConfig."""
    evaluators = [
        EvaluatorRef(**ev) if isinstance(ev, dict) else EvaluatorRef(name=ev)
        for ev in data.get("evaluators", [])
    ]
    use_case_raw = data.get("use_case")
    use_case = UseCase(use_case_raw) if use_case_raw else None

    return BundleConfig(
        name=data["name"],
        description=data.get("description", ""),
        use_case=use_case,
        evaluators=evaluators,
        thresholds=data.get("thresholds", {}),
        tags=data.get("tags", []),
        builtin=data.get("builtin", False),
    )


def _load_builtins() -> dict[str, BundleConfig]:
    """Load all built-in bundle YAML files from the bundles/ package directory."""
    global _BUILTIN_CACHE
    if _BUILTIN_CACHE is not None:
        return _BUILTIN_CACHE

    bundles: dict[str, BundleConfig] = {}

    bundle_dir = resources.files("agentops_toolkit") / "bundles"
    for item in bundle_dir.iterdir():
        if hasattr(item, "name") and item.name.endswith(".yaml"):
            text = item.read_text(encoding="utf-8")
            data = _yaml.load(text)
            if data and isinstance(data, dict) and "name" in data:
                bundle = _parse_bundle(data)
                bundles[bundle.name] = bundle

    _BUILTIN_CACHE = bundles
    return bundles


class BundleRegistry:
    """Registry of available bundles — built-in + user-defined.

    Usage::

        registry = BundleRegistry()
        bundle = registry.get("rag_quality")
        all_bundles = registry.list_all()
    """

    def __init__(self, user_bundles: BundlesConfig | None = None) -> None:
        self._builtins = _load_builtins()
        self._user: dict[str, BundleConfig] = {}

        if user_bundles:
            for custom in user_bundles.custom:
                evaluators = [
                    EvaluatorRef(name=ev.name, type=ev.type, weight=ev.weight)  # type: ignore[arg-type]
                    for ev in custom.evaluators
                ]
                self._user[custom.name] = BundleConfig(
                    name=custom.name,
                    description=custom.description,
                    evaluators=evaluators,
                    builtin=False,
                )

    def get(self, name: str) -> BundleConfig:
        """Resolve a bundle name to a BundleConfig.

        Raises:
            KeyError: If the bundle name is not found.
        """
        if name in self._user:
            return self._user[name]
        if name in self._builtins:
            return self._builtins[name]
        available = sorted(self.list_names())
        raise KeyError(
            f"Bundle '{name}' not found. Available: {', '.join(available)}"
        )

    def list_all(self, use_case: UseCase | str | None = None) -> list[BundleConfig]:
        """Return all bundles, optionally filtered by use case."""
        all_bundles = {**self._builtins, **self._user}
        bundles = list(all_bundles.values())

        if use_case:
            uc = UseCase(use_case) if isinstance(use_case, str) else use_case
            bundles = [b for b in bundles if b.use_case is None or b.use_case == uc]

        return sorted(bundles, key=lambda b: (not b.builtin, b.name))

    def list_names(self) -> list[str]:
        """Return sorted list of all bundle names."""
        return sorted({*self._builtins.keys(), *self._user.keys()})

    @property
    def builtin_count(self) -> int:
        return len(self._builtins)
