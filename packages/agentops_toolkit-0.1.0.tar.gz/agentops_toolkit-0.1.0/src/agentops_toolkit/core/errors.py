"""Structured error handling for AgentOps.

SPEC-002 §5: Error code taxonomy with ranges per category.
NFR-020: All errors include code, description, and actionable hint.
"""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel

console = Console(stderr=True)

# ── Error code ranges (SPEC-002 §5) ──
# 1–9:   General CLI
# 10–19: Configuration
# 20–29: Dataset
# 30–39: Agent / Run
# 40–49: Evaluation
# 50–59: Authentication
# 60–69: Framework Adapter


class AgentOpsError(Exception):
    """Base error with structured code, message, and hint."""

    def __init__(self, code: int, message: str, hint: str = "") -> None:
        self.code = code
        self.message = message
        self.hint = hint
        super().__init__(message)

    def display(self) -> None:
        """Print a rich-formatted error to stderr."""
        code_label = f"AGENTOPS_E_{self.code:02d}"
        body = f"[red]✗[/red] Error [{code_label}]\n  {self.message}"
        if self.hint:
            body += f"\n\n  [dim]Hint: {self.hint}[/dim]"
        console.print(Panel(body, border_style="red", title="Error"))


# ── Specific error classes ──


class ConfigNotFoundError(AgentOpsError):
    def __init__(self, path: str = "") -> None:
        super().__init__(
            code=10,
            message=f"Configuration file not found{f': {path}' if path else ''}.",
            hint="Run 'agentops init' to create agentops.yaml.",
        )


class ConfigParseError(AgentOpsError):
    def __init__(self, detail: str = "") -> None:
        super().__init__(
            code=11,
            message=f"Failed to parse configuration: {detail}",
            hint="Check agentops.yaml syntax. Run 'agentops config validate'.",
        )


class DatasetNotFoundError(AgentOpsError):
    def __init__(self, path: str = "") -> None:
        super().__init__(
            code=20,
            message=f"Dataset not found: {path}",
            hint="Check the path or run 'agentops dataset list'.",
        )


class DatasetParseError(AgentOpsError):
    def __init__(self, detail: str = "", line: int | None = None) -> None:
        loc = f" on line {line}" if line else ""
        super().__init__(
            code=22,
            message=f"Failed to parse dataset{loc}: {detail}",
            hint="Run 'agentops dataset validate <name>' for detailed diagnostics.",
        )


class AgentNotFoundError(AgentOpsError):
    def __init__(self, entry_point: str = "") -> None:
        super().__init__(
            code=30,
            message=f"Agent entry point not found: {entry_point}",
            hint="Check agent.entry_point in agentops.yaml.",
        )


class EvaluationError(AgentOpsError):
    def __init__(self, detail: str = "") -> None:
        super().__init__(
            code=40,
            message=f"Evaluation failed: {detail}",
            hint="Check Foundry connectivity and evaluator configuration.",
        )


class AuthError(AgentOpsError):
    def __init__(self, detail: str = "") -> None:
        super().__init__(
            code=50,
            message=f"Authentication failed: {detail}",
            hint="Run 'az login' or set AZURE_CLIENT_ID/SECRET/TENANT_ID.",
        )


class BundleNotFoundError(AgentOpsError):
    def __init__(self, name: str = "", available: list[str] | None = None) -> None:
        avail = f" Available: {', '.join(available)}" if available else ""
        super().__init__(
            code=41,
            message=f"Bundle not found: '{name}'.{avail}",
            hint="Run 'agentops bundle list' to see available bundles.",
        )
