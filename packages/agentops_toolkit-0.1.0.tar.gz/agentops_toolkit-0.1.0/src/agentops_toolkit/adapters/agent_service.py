"""Azure AI Agent Service adapter — pull agent defs from Foundry.

SPEC-004 §4.3, FR-083: AgentServiceAdapter.
"""

from __future__ import annotations

import logging
from typing import Any

from agentops_toolkit.adapters.registry import (
    AdapterCapabilities,
    AdapterRegistry,
    AgentDiscovery,
    AgentOutput,
    DiscoveredAgent,
)

logger = logging.getLogger(__name__)


class AgentServiceAdapter:
    """Adapter for Azure AI Agent Service (SPEC-004 §4.3).

    Creates threads, sends messages, polls for completion,
    extracts tool calls and file search results.
    """

    def __init__(self, config: dict[str, Any]) -> None:
        self._config = config

    @property
    def name(self) -> str:
        return "agent-service"

    @property
    def framework_version(self) -> str:
        try:
            import azure.ai.projects
            return getattr(azure.ai.projects, "__version__", "unknown")
        except ImportError:
            return "not-installed"

    async def setup(self, config: dict[str, Any]) -> None:
        agent_id = config.get("agent_id")
        logger.info("Agent Service adapter setup: agent_id=%s", agent_id)

    async def teardown(self) -> None:
        pass

    async def invoke(self, query: str, context: str | None = None) -> AgentOutput:
        logger.info("Agent Service invoke: query=%s", query[:50])
        return AgentOutput(
            response="[Agent Service adapter — production creates thread + polls]",
            metadata={"framework": "agent-service"},
        )

    async def discover(self, config: dict[str, Any]) -> AgentDiscovery:
        return AgentDiscovery(
            framework="agent-service",
            framework_version=self.framework_version,
            agents=[DiscoveredAgent(
                name=config.get("agent_id", "agent"),
                entry_point="foundry-hosted",
                agent_type="single",
            )],
        )

    def get_capabilities(self) -> AdapterCapabilities:
        return AdapterCapabilities(
            captures_tool_calls=True,
            captures_token_usage=True,
        )

    def supports_streaming(self) -> bool:
        return False


AdapterRegistry.register("agent-service", AgentServiceAdapter)
