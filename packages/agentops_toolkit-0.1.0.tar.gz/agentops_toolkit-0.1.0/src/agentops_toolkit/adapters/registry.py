"""Adapter protocol and registry.

SPEC-004 §2–3: FrameworkAdapter protocol, AdapterRegistry with auto-detection.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


# ── Supporting types ──


class AdapterCapabilities(BaseModel):
    """What an adapter can capture (SPEC-004 §2)."""

    captures_response: bool = True
    captures_tool_calls: bool = False
    captures_conversation_turns: bool = False
    captures_planner_steps: bool = False
    captures_token_usage: bool = False
    supports_streaming: bool = False


class DiscoveredAgent(BaseModel):
    """A detected agent entry point (SPEC-004 §2)."""

    name: str
    entry_point: str
    agent_type: str = "single"  # "single" | "multi-agent" | "rag"
    tools: list[str] = Field(default_factory=list)
    plugins: list[str] = Field(default_factory=list)


class AgentDiscovery(BaseModel):
    """Results of agent discovery in a project (SPEC-004 §2)."""

    agents: list[DiscoveredAgent] = Field(default_factory=list)
    framework: str = ""
    framework_version: str = ""
    warnings: list[str] = Field(default_factory=list)


class AgentOutput(BaseModel):
    """Captured output from an agent invocation (SPEC-003 §2)."""

    response: str
    tool_calls: list[Any] | None = None
    conversation_turns: list[Any] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


# ── Protocol ──


@runtime_checkable
class FrameworkAdapter(Protocol):
    """Protocol that all framework adapters must satisfy (SPEC-004 §2)."""

    @property
    def name(self) -> str: ...

    @property
    def framework_version(self) -> str: ...

    async def setup(self, config: dict[str, Any]) -> None: ...

    async def teardown(self) -> None: ...

    async def invoke(self, query: str, context: str | None = None) -> AgentOutput: ...

    async def discover(self, config: dict[str, Any]) -> AgentDiscovery: ...

    def get_capabilities(self) -> AdapterCapabilities: ...

    def supports_streaming(self) -> bool: ...


# ── Registry ──


# Package name → adapter name detection map
_DETECTION_MAP: dict[str, str] = {
    "semantic_kernel": "semantic-kernel",
    "semantic-kernel": "semantic-kernel",
    "autogen": "autogen",
    "autogen-agentchat": "autogen",
    "pyautogen": "autogen",
    "azure-ai-projects": "agent-service",
    "azure.ai.projects": "agent-service",
}


class AdapterRegistry:
    """Registry for framework adapters with auto-detection (SPEC-004 §3).

    Usage::

        registry = AdapterRegistry()
        detected = registry.auto_detect(Path("."))
        adapter = registry.get("semantic-kernel", config={})
    """

    _adapters: dict[str, type] = {}

    @classmethod
    def register(cls, name: str, adapter_class: type) -> None:
        """Register an adapter class by name."""
        cls._adapters[name] = adapter_class
        logger.debug("Adapter registered: %s", name)

    @classmethod
    def get(cls, name: str, config: dict[str, Any] | None = None) -> Any:
        """Resolve an adapter by name.

        Raises:
            KeyError: If the adapter is not registered.
        """
        if name not in cls._adapters:
            available = sorted(cls._adapters.keys()) or ["(none registered)"]
            raise KeyError(
                f"Adapter '{name}' not found. Available: {', '.join(available)}"
            )
        return cls._adapters[name](config or {})

    @classmethod
    def list_registered(cls) -> list[str]:
        """Return sorted list of registered adapter names."""
        return sorted(cls._adapters.keys())

    @classmethod
    def auto_detect(cls, project_root: Path) -> str | None:
        """Scan project dependencies to detect which framework is in use (SPEC-004 §3, FR-085).

        Checks in order:
          1. pyproject.toml
          2. requirements.txt
          3. setup.cfg
        """
        files_to_check = ["pyproject.toml", "requirements.txt", "setup.cfg"]

        for fname in files_to_check:
            fpath = project_root / fname
            if fpath.exists():
                content = fpath.read_text(encoding="utf-8").lower()
                for package, adapter_name in _DETECTION_MAP.items():
                    if package.lower() in content:
                        logger.info("Auto-detected framework: %s (from %s)", adapter_name, fname)
                        return adapter_name

        logger.debug("No framework detected in %s", project_root)
        return None
