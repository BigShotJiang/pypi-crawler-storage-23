"""AutoGen adapter — hook ConversableAgent message streams.

SPEC-004 §4.2, FR-082: AutoGenAdapter.
"""

from __future__ import annotations

import logging
from typing import Any

from agentops_toolkit.adapters.registry import (
    AdapterCapabilities,
    AdapterRegistry,
    AgentDiscovery,
    AgentOutput,
    DiscoveredAgent,
)

logger = logging.getLogger(__name__)


class AutoGenAdapter:
    """Adapter for AutoGen multi-agent systems (SPEC-004 §4.2).

    Hooks into ConversableAgent message streams, captures inter-agent
    messages as ConversationTurn objects.
    """

    def __init__(self, config: dict[str, Any]) -> None:
        self._config = config
        self._captured_turns: list[dict] = []

    @property
    def name(self) -> str:
        return "autogen"

    @property
    def framework_version(self) -> str:
        try:
            import autogen
            return getattr(autogen, "__version__", "unknown")
        except ImportError:
            return "not-installed"

    async def setup(self, config: dict[str, Any]) -> None:
        entry_point = config.get("entry_point", "")
        logger.info("AutoGen adapter setup: entry=%s", entry_point)

    async def teardown(self) -> None:
        self._captured_turns.clear()

    async def invoke(self, query: str, context: str | None = None) -> AgentOutput:
        logger.info("AutoGen invoke: query=%s", query[:50])
        return AgentOutput(
            response="[AutoGen adapter — production implementation calls team.run()]",
            conversation_turns=self._captured_turns or None,
            metadata={"framework": "autogen"},
        )

    async def discover(self, config: dict[str, Any]) -> AgentDiscovery:
        return AgentDiscovery(
            framework="autogen",
            framework_version=self.framework_version,
            agents=[DiscoveredAgent(
                name="team",
                entry_point=config.get("entry_point", ""),
                agent_type="multi-agent",
            )],
        )

    def get_capabilities(self) -> AdapterCapabilities:
        return AdapterCapabilities(
            captures_tool_calls=True,
            captures_conversation_turns=True,
        )

    def supports_streaming(self) -> bool:
        return False


AdapterRegistry.register("autogen", AutoGenAdapter)
