"""agentops monitor setup|dashboard|alert|status|metrics — Monitoring commands.

SPEC-007 §4.4, FR-100–FR-102, SPEC-009 §6.3.
"""

from __future__ import annotations

import json
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from agentops_toolkit.obs.monitor import AlertRule, MonitorManager

console = Console()
monitor_app = typer.Typer(name="monitor", help="Monitor agents in production.")


@monitor_app.command("setup")
def monitor_setup(
    project_endpoint: Optional[str] = typer.Option(
        None, "--project-endpoint", "-p", help="Foundry project endpoint",
        envvar="FOUNDRY_PROJECT_ENDPOINT",
    ),
    service_name: str = typer.Option("agentops", "--service-name", "-s", help="Agent service name"),
) -> None:
    """Wire up Agent Monitoring Dashboard (SPEC-007 §4.4, FR-100)."""
    console.print(f"[green]✓[/green] Monitoring configured for service [bold]'{service_name}'[/bold]")
    if project_endpoint:
        console.print(f"  Project: {project_endpoint[:40]}...")
    console.print(f"  Dashboard: [bold]agentops monitor dashboard --template agent-overview[/bold]")


@monitor_app.command("dashboard")
def monitor_dashboard(
    template: Optional[str] = typer.Option(None, "--template", "-t", help="Dashboard template name"),
    list_templates: bool = typer.Option(False, "--list", help="List available templates"),
    service_name: str = typer.Option("agentops", "--service-name", "-s"),
) -> None:
    """Apply a pre-built dashboard template (SPEC-007 §4.4, FR-101)."""
    manager = MonitorManager(service_name=service_name)

    if list_templates or template is None:
        table = Table(show_header=True, header_style="bold")
        table.add_column("Template", style="cyan")
        table.add_column("Description")
        for t in manager.list_templates():
            table.add_row(t["id"], t["description"])
        console.print(table)
        return

    try:
        result = manager.setup_dashboard(template)
        console.print(f"[green]✓[/green] Dashboard [bold]'{result['name']}'[/bold] configured")
        console.print(f"  {result['description']}")
    except ValueError as e:
        console.print(f"[red]✗[/red] {e}")
        raise typer.Exit(code=1) from e


@monitor_app.command("alert")
def monitor_alert(
    action: str = typer.Argument("list", help="Action: create|list"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Alert rule name"),
    metric: Optional[str] = typer.Option(None, "--metric", "-m", help="Metric name"),
    operator: str = typer.Option("lt", "--operator", help="Operator: lt|gt|eq"),
    threshold: float = typer.Option(3.5, "--threshold", "-t", help="Threshold value"),
    severity: int = typer.Option(2, "--severity", help="Alert severity 0-4"),
) -> None:
    """Manage Azure Monitor alert rules (SPEC-007 §4.4, FR-102)."""
    if action == "create":
        if not name or not metric:
            console.print("[red]✗[/red] --name and --metric are required for alert creation.")
            raise typer.Exit(code=1)

        rule = AlertRule(name=name, metric=metric, operator=operator, threshold=threshold, severity=severity)
        manager = MonitorManager()
        result = manager.create_alert_rule(rule)
        console.print(f"[green]✓[/green] Alert [bold]'{name}'[/bold] created")
        console.print(f"  Fires when {metric} {operator} {threshold} over 15m window")
    else:
        console.print("[dim]No active alerts configured. Use 'agentops monitor alert create' to add one.[/dim]")


@monitor_app.command("status")
def monitor_status() -> None:
    """View monitoring health status."""
    console.print("[green]✓[/green] Monitoring status: active")
    console.print("  Run [bold]agentops monitor dashboard --list[/bold] to see available templates")
