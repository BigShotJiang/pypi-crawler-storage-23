"""agentops eval run|entry — Evaluation commands.

SPEC-002 §3.11–3.12, FR-040–FR-049.
Phase 2: --continuous (SPEC-007 §5), --red-team (SPEC-007 §5.4),
         migrate (SPEC-007 §9), cicd (SPEC-007 §6), --via mcp (SPEC-009 §6.2).
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from agentops_toolkit.core.config_loader import ConfigError, load_config

console = Console()
eval_app = typer.Typer(name="eval", help="Run evaluations on agent outputs.")


@eval_app.command("run")
def eval_run(
    run_id: str = typer.Argument(
        "latest",
        help="Run ID to evaluate, or 'latest' for most recent. "
        "In Sprint 1, pass a dataset path directly.",
    ),
    bundle: Optional[str] = typer.Option(None, "--bundle", "-b", help="Override bundle"),
    dataset: Optional[str] = typer.Option(None, "--dataset", "-d", help="Dataset path (JSONL)"),
    config: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table|json"),
) -> None:
    """Evaluate agent outputs against a bundle of evaluators (SPEC-002 §3.11).

    Sprint 1: Evaluates a pre-populated JSONL dataset (agent responses included)
    against the specified bundle's Foundry evaluators.
    """
    from agentops_toolkit.core.pipeline import run_evaluation

    # Resolve config
    try:
        cfg = load_config(config)
    except ConfigError:
        # If no config, use defaults
        cfg = None

    # Resolve dataset path
    dataset_path: str | None = dataset
    if dataset_path is None and cfg:
        # Find default dataset from config
        default_name = cfg.datasets.default
        if default_name:
            for ds in cfg.datasets.entries:
                if ds.name == default_name:
                    dataset_path = ds.path
                    break

    if dataset_path is None:
        console.print("[red]✗[/red] No dataset specified. Use --dataset <path> or configure in agentops.yaml")
        raise typer.Exit(code=2)

    if not Path(dataset_path).exists():
        console.print(f"[red]✗[/red] Dataset not found: {dataset_path}")
        raise typer.Exit(code=2)

    # Resolve bundle
    bundle_name = bundle or (cfg.bundles.default if cfg else "rag_quality")
    project_connection = cfg.foundry.project_connection if cfg else ""
    output_dir = cfg.runs.output_dir if cfg else "agentops/runs"

    # Run evaluation
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task(
            f"Evaluating with bundle '{bundle_name}'...", total=None
        )

        try:
            run = asyncio.run(
                run_evaluation(
                    dataset_path=dataset_path,
                    bundle_name=bundle_name,
                    output_dir=output_dir,
                    project_connection=project_connection,
                )
            )
        except KeyError as e:
            console.print(f"[red]✗[/red] {e}")
            raise typer.Exit(code=1) from e
        except Exception as e:
            console.print(f"[red]✗[/red] Evaluation failed: {e}")
            raise typer.Exit(code=11) from e

    summary = run.summary
    if summary is None:
        console.print("[red]✗[/red] Evaluation produced no results.")
        raise typer.Exit(code=1)

    # JSON output
    if format == "json":
        console.print_json(run.model_dump_json(indent=2))
        return

    # Rich table output
    console.print()
    console.print(
        Panel(
            f"[green]✓[/green] Run [bold]'{run.name}'[/bold] completed ({run.id})\n"
            f"\n"
            f"  {summary.successful_entries}/{summary.total_entries} entries successful "
            f"({summary.total_entries - summary.successful_entries - summary.skipped_entries} errors, "
            f"{summary.skipped_entries} skipped)",
            title="[bold]AgentOps Evaluation[/bold]",
            border_style="green",
        )
    )

    # Evaluator scores table
    if summary.evaluator_scores:
        table = Table(show_header=True, header_style="bold")
        table.add_column("Evaluator", style="cyan")
        table.add_column("Mean", justify="right")
        table.add_column("Median", justify="right")
        table.add_column("Min", justify="right")
        table.add_column("Max", justify="right")
        table.add_column("Pass Rate", justify="right")

        for name, es in sorted(summary.evaluator_scores.items()):
            pass_str = f"{es.pass_rate:.0%}" if es.pass_rate is not None else "—"
            pass_color = "green" if es.pass_rate and es.pass_rate >= 0.9 else (
                "yellow" if es.pass_rate and es.pass_rate >= 0.7 else "red"
            ) if es.pass_rate is not None else ""
            table.add_row(
                name,
                f"{es.mean_score:.2f}",
                f"{es.median_score:.1f}",
                f"{es.min_score:.1f}",
                f"{es.max_score:.1f}",
                f"[{pass_color}]{pass_str}[/{pass_color}]" if pass_color else pass_str,
            )

        console.print()
        console.print(table)

    # Summary line
    console.print()
    agg = f"{summary.aggregate_score:.2f}" if summary.aggregate_score else "—"
    pr = f"{summary.pass_rate:.0%}" if summary.pass_rate is not None else "—"
    console.print(f"  Aggregate score: [bold]{agg}[/bold]")
    console.print(f"  Overall pass rate: [bold]{pr}[/bold]")
    console.print(f"  Duration: {summary.total_duration_ms:.0f}ms")
    console.print()
    console.print(f"  Full report: [bold]agentops report show {run.id}[/bold]")
    console.print()

    # Exit code based on threshold (FR-054)
    if cfg and cfg.runs.fail_on_threshold:
        any_below = any(
            er.passed is False
            for entry in run.entries
            for er in entry.eval_results
        )
        if any_below:
            raise typer.Exit(code=1)
