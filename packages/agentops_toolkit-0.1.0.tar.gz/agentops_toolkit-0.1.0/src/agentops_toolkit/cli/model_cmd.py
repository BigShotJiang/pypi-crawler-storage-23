"""agentops model list|recommend|benchmark|quota|deploy|retire — Model lifecycle via MCP.

SPEC-009 §6.1, FR-130–FR-132.
"""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

console = Console()
model_app = typer.Typer(name="model", help="Model lifecycle management via Foundry MCP Server.")


@model_app.command("list")
def model_list(
    capability: Optional[str] = typer.Option(None, "--capability", help="Filter by capability: chat|embeddings|vision"),
    provider: Optional[str] = typer.Option(None, "--provider", help="Filter by provider: OpenAI|Microsoft|Meta"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table|json"),
) -> None:
    """List available models in the Foundry catalog (SPEC-009 §6.1, FR-130)."""
    # In production, calls model_catalog_list via MCPClient
    # For now, show a placeholder with the command structure
    console.print("[dim]Model catalog requires Foundry MCP Server connection.[/dim]")
    console.print("[dim]Set foundry_mcp.url in agentops.yaml or use --project-endpoint.[/dim]")
    console.print()
    console.print("Usage: agentops model list [--capability chat] [--provider OpenAI]")


@model_app.command("recommend")
def model_recommend(
    current: str = typer.Option(..., "--current", help="Current model name"),
) -> None:
    """Get model switch recommendations (SPEC-009 §6.1, FR-131)."""
    console.print(f"[dim]Fetching recommendations for '{current}' from Foundry MCP Server...[/dim]")
    console.print("[dim]Requires foundry_mcp.url configuration.[/dim]")


@model_app.command("benchmark")
def model_benchmark(
    from_model: str = typer.Option(..., "--from", help="Model A"),
    to_model: str = typer.Option(..., "--to", help="Model B"),
) -> None:
    """Compare benchmarks between two models (SPEC-009 §6.1)."""
    console.print(f"[dim]Comparing benchmarks: {from_model} vs {to_model}...[/dim]")
    console.print("[dim]Requires foundry_mcp.url configuration.[/dim]")


@model_app.command("quota")
def model_quota(
    model: Optional[str] = typer.Option(None, "--model", help="Model to check quota for"),
) -> None:
    """Check TPM/RPM quota headroom (SPEC-009 §6.1)."""
    console.print("[dim]Checking quota from Foundry MCP Server...[/dim]")
    console.print("[dim]Requires foundry_mcp.url configuration.[/dim]")


@model_app.command("deploy")
def model_deploy(
    model: str = typer.Option(..., "--model", help="Model ID to deploy"),
    deployment_name: Optional[str] = typer.Option(None, "--deployment-name", help="Deployment name"),
    confirm: bool = typer.Option(False, "--confirm", help="Skip confirmation prompt"),
) -> None:
    """Deploy a model to the Foundry project (SPEC-009 §6.1, FR-132)."""
    if not confirm:
        console.print(f"[yellow]⚠[/yellow] About to deploy model '{model}'. Use --confirm to proceed.")
        raise typer.Exit(code=0)
    console.print(f"[dim]Deploying {model}...[/dim]")


@model_app.command("retire")
def model_retire(
    deployment: str = typer.Option(..., "--deployment", help="Deployment name to retire"),
    confirm: bool = typer.Option(False, "--confirm", help="Skip confirmation prompt"),
) -> None:
    """Remove a model deployment (SPEC-009 §6.1, FR-132)."""
    if not confirm:
        console.print(f"[yellow]⚠[/yellow] About to retire deployment '{deployment}'. Use --confirm to proceed.")
        raise typer.Exit(code=0)
    console.print(f"[dim]Retiring {deployment}...[/dim]")
