"""agentops init — Project scaffolding.

SPEC-002 §3.1, FR-001–FR-007.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from ruamel.yaml import YAML

from agentops_toolkit.models.config import Framework, UseCase

console = Console()
_yaml = YAML()
_yaml.default_flow_style = False

init_app = typer.Typer(name="init", invoke_without_command=True)

# ── Default bundle for each use case ──

_DEFAULT_BUNDLE: dict[UseCase, str] = {
    UseCase.RAG: "rag_quality",
    UseCase.AGENT: "agent_quality",
    UseCase.MULTI_AGENT: "multi_agent_quality",
}

# ── Sample dataset ──

_SAMPLE_DATASET = [
    {
        "id": "001",
        "query": "What is the refund policy?",
        "context": "Our refund policy allows returns within 30 days of purchase for a full refund.",
        "ground_truth": "You can return items within 30 days for a full refund.",
    },
    {
        "id": "002",
        "query": "How do I reset my password?",
        "context": "To reset your password, go to Settings > Security and click Reset Password.",
        "ground_truth": "Go to Settings > Security and click Reset Password.",
    },
    {
        "id": "003",
        "query": "What payment methods do you accept?",
        "context": "We accept Visa, MasterCard, American Express, PayPal, and bank transfers.",
        "ground_truth": "We accept Visa, MasterCard, American Express, PayPal, and bank transfers.",
    },
]


def _detect_framework(project_root: Path) -> Framework | None:
    """Auto-detect agent framework from project dependencies (SPEC-004 §3)."""
    detection_map = {
        "semantic-kernel": Framework.SEMANTIC_KERNEL,
        "semantic_kernel": Framework.SEMANTIC_KERNEL,
        "autogen": Framework.AUTOGEN,
        "autogen-agentchat": Framework.AUTOGEN,
        "azure-ai-projects": Framework.AGENT_SERVICE,
    }

    files_to_check = ["pyproject.toml", "requirements.txt", "setup.cfg"]
    for fname in files_to_check:
        fpath = project_root / fname
        if fpath.exists():
            content = fpath.read_text(encoding="utf-8").lower()
            for pkg, fw in detection_map.items():
                if pkg in content:
                    return fw
    return None


def _generate_config(
    project_name: str,
    use_case: UseCase,
    framework: Framework,
    entry_point: str,
) -> dict:
    """Generate the agentops.yaml content as a dict."""
    return {
        "schema_version": "1.0",
        "project": {"name": project_name},
        "foundry": {"project_connection": "${FOUNDRY_CONNECTION}"},
        "agent": {
            "framework": framework.value,
            "use_case": use_case.value,
            "entry_point": entry_point,
        },
        "bundles": {"default": _DEFAULT_BUNDLE.get(use_case, "rag_quality")},
        "datasets": {
            "default": "golden_set",
            "entries": [
                {
                    "name": "golden_set",
                    "path": "agentops/datasets/golden_set.jsonl",
                    "format": "jsonl",
                    "description": "Sample golden dataset — replace with your test data",
                }
            ],
        },
    }


def _write_sample_dataset(datasets_dir: Path) -> None:
    """Write sample golden dataset JSONL."""
    import json

    dataset_path = datasets_dir / "golden_set.jsonl"
    with open(dataset_path, "w", encoding="utf-8") as f:
        for entry in _SAMPLE_DATASET:
            f.write(json.dumps(entry) + "\n")


@init_app.callback(invoke_without_command=True)
def init(
    use_case: Optional[UseCase] = typer.Option(
        None, "--use-case", "-u", help="Agent use case: rag, agent, multi-agent"
    ),
    framework: Optional[Framework] = typer.Option(
        None, "--framework", "-f", help="Agent framework"
    ),
    entry_point: str = typer.Option(
        "src/agent.py", "--entry-point", "-e", help="Agent entry point file"
    ),
    force: bool = typer.Option(False, "--force", help="Overwrite existing agentops.yaml"),
    no_interactive: bool = typer.Option(
        False, "--no-interactive", help="Skip prompts; fail if required values missing"
    ),
) -> None:
    """Initialize AgentOps in the current project directory."""
    project_root = Path.cwd()
    config_path = project_root / "agentops.yaml"

    # Check existing config
    if config_path.exists() and not force:
        console.print(
            "[red]✗[/red] agentops.yaml already exists. Use --force to overwrite."
        )
        raise typer.Exit(code=1)

    # Auto-detect framework
    detected_framework = _detect_framework(project_root)
    if framework is None:
        framework = detected_framework
    framework_label = ""
    if framework is None:
        if no_interactive:
            console.print(
                "[red]✗[/red] Could not auto-detect framework. "
                "Use --framework to specify one."
            )
            raise typer.Exit(code=3)
        framework = Framework.CUSTOM
        framework_label = "custom"
    else:
        framework_label = framework.value
        if detected_framework and framework == detected_framework:
            framework_label += " (auto-detected)"

    # Use case
    if use_case is None:
        if no_interactive:
            console.print(
                "[red]✗[/red] --use-case is required in --no-interactive mode."
            )
            raise typer.Exit(code=2)
        use_case = UseCase.RAG  # Default

    # Derive project name from directory
    project_name = project_root.name.lower().replace(" ", "-")
    # Sanitize to match CFG-002 pattern
    import re
    project_name = re.sub(r"[^a-z0-9._-]", "-", project_name)
    if not project_name or not project_name[0].isalnum():
        project_name = "my-agent"

    # Create directories
    dirs = [
        project_root / "agentops" / "bundles",
        project_root / "agentops" / "datasets",
        project_root / "agentops" / "runs",
        project_root / "agentops" / "reports",
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)

    # Write agentops.yaml
    config_data = _generate_config(project_name, use_case, framework, entry_point)
    with open(config_path, "w", encoding="utf-8") as f:
        _yaml.dump(config_data, f)

    # Write sample dataset
    _write_sample_dataset(project_root / "agentops" / "datasets")

    # Print success
    bundle_name = _DEFAULT_BUNDLE.get(use_case, "rag_quality")
    from agentops_toolkit.core.bundle_registry import BundleRegistry

    registry = BundleRegistry()
    bundle = registry.get(bundle_name)
    evaluator_count = len(bundle.evaluators)

    console.print()
    console.print(
        Panel(
            f"[green]✓[/green] AgentOps initialized for project [bold]'{project_name}'[/bold]\n"
            f"  Use case:  {use_case.value}\n"
            f"  Framework: {framework_label}\n"
            f"  Bundle:    {bundle_name} ({evaluator_count} evaluators)",
            title="[bold]AgentOps[/bold]",
            border_style="green",
        )
    )
    console.print()
    console.print("  [dim]Next steps:[/dim]")
    console.print("    1. Add your test data to agentops/datasets/golden_set.jsonl")
    console.print("    2. Set FOUNDRY_CONNECTION environment variable")
    console.print("    3. Run: [bold]agentops run start[/bold]")
    console.print("    4. View results: [bold]agentops report show latest[/bold]")
    console.print()
