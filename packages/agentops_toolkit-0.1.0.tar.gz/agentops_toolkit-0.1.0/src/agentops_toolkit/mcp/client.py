"""Foundry MCP HTTP client — auth, retry, tool invocation.

SPEC-009 §3.2: MCP HTTP client for https://mcp.ai.azure.com.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_DEFAULT_URL = "https://mcp.ai.azure.com"


class MCPClient:
    """HTTP client for the Foundry MCP Server (SPEC-009 §3.2).

    Handles OAuth 2.0 / Entra ID OBO tokens, MCP protocol serialization,
    and retry on transient failures.
    """

    def __init__(
        self,
        url: str = _DEFAULT_URL,
        timeout: int = 120,
        credential: Any | None = None,
    ) -> None:
        self._url = url.rstrip("/")
        self._timeout = timeout
        self._credential = credential
        self._http = httpx.AsyncClient(timeout=timeout)

    async def call_tool(self, tool_name: str, params: dict[str, Any]) -> dict[str, Any]:
        """Call a Foundry MCP Server tool via HTTP.

        Args:
            tool_name: MCP tool name (e.g. "model_catalog_list")
            params: Tool parameters

        Returns:
            Tool result as a dict
        """
        token = self._get_token()

        # MCP protocol: JSON-RPC style
        payload = {
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": params,
            },
        }

        headers = {"Authorization": f"Bearer {token}"} if token else {}

        try:
            response = await self._http.post(
                self._url,
                json=payload,
                headers=headers,
            )
            response.raise_for_status()
            data = response.json()
            return data.get("result", data)
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 429:
                logger.warning("MCP rate limited — retry needed")
            raise
        except Exception as e:
            logger.error("MCP call failed: %s(%s) → %s", tool_name, params, e)
            raise

    def _get_token(self) -> str | None:
        """Get an OAuth token for MCP Server."""
        if self._credential is None:
            try:
                from azure.identity import DefaultAzureCredential
                self._credential = DefaultAzureCredential()
            except ImportError:
                return None

        try:
            token = self._credential.get_token("https://mcp.ai.azure.com/.default")
            return token.token
        except Exception:
            logger.warning("Failed to acquire MCP token", exc_info=True)
            return None

    async def close(self) -> None:
        await self._http.aclose()
