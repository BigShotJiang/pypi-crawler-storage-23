"""GibsGraph KG Builder package."""

from gibsgraph.kg_builder.builder import KGBuilder

__all__ = ["KGBuilder"]
