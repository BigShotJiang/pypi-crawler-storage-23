"""GibsGraph GNN package."""

from gibsgraph.gnn.g_retriever import GRetriever

__all__ = ["GRetriever"]
