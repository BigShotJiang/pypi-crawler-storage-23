"""GibsGraph core package."""
