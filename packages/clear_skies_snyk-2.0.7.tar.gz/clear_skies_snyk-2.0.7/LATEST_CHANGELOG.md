## [2.0.7] - 2026-02-23

### Fixed
- Set correct headers

