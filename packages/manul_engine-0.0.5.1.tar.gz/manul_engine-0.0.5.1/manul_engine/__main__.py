# manul_engine/__main__.py
"""Entry point for `python -m manul_engine`."""

from manul_engine.cli import sync_main

sync_main()
