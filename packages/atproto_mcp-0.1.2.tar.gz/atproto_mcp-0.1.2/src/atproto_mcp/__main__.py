"""Allow running as python -m atproto_mcp."""

from atproto_mcp.server import main

main()
