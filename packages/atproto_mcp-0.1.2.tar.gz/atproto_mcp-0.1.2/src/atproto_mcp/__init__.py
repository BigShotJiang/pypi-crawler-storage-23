"""MCP server for AT Protocol documentation and knowledge base."""

__version__ = "0.1.0"
