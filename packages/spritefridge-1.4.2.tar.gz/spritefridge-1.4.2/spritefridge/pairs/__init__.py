from .pairs import main as make_pairs
from .cli import add_pairs