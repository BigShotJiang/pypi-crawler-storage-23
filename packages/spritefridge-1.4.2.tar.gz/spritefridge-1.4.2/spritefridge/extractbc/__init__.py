from .extractbc import main as extract_barcodes
from .cli import add_extractbc
