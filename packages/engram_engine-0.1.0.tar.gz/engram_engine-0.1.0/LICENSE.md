# PS-CSE Research & Academic Use License

**Version 1.0 — February 2026**

Copyright © 2026 Justin Arndt. All rights reserved.

## 1. Definitions

- **"Software"** means all source code, documentation, figures, benchmark results, and associated materials in this repository.
- **"Patent Rights"** means U.S. Provisional Patent Application No. 63/989,566, filed February 24, 2026, covering the Persistent Systolic Continuous State Engine (PS-CSE) architecture, and any continuations, divisionals, or foreign equivalents thereof.
- **"Research Use"** means use solely for non-commercial academic research, education, personal experimentation, or peer-reviewed publication.
- **"Commercial Use"** means any use intended for or directed toward commercial advantage or monetary compensation.

## 2. Grant of Rights

Subject to the terms of this License, the copyright holder grants you a non-exclusive, non-transferable, revocable license to use, copy, modify, and distribute the Software solely for Research Use.

## 3. Restrictions

You may NOT:
- Use the Software or any derivative work for Commercial Use without a separate commercial license
- Sublicense, sell, or offer the Software as a hosted service
- Remove or alter any patent notices, copyright notices, or license terms
- Represent the Software as your own work

## 4. Patent Notice

The methods, systems, and architectures described in this Software are the subject of a pending patent application. Nothing in this License grants any rights under the Patent Rights for Commercial Use.

## 5. Contact for Commercial Licensing

**Justin Arndt**
Email: justinarndt05@gmail.com

## 6. Disclaimer

THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY.
