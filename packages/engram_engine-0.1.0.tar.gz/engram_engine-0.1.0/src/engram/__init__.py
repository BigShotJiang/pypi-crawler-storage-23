"""
Engram — Persistent Systolic Continuous State Engine

A post-transformer inference engine that eliminates the Von Neumann
Memory Wall and Host-Dispatch Wall.

Core components:
    HolographicTorus     — O(1) state memory on a toroidal lattice
    HolographicAttention — Drop-in MHA replacement via systolic convolutions
    HolographicBlock     — Transformer block with holographic attention + FFN
    HolographicLM        — Complete language model

Usage:
    from engram import HolographicLM

    model = HolographicLM()
    output = model(input_ids)
"""

from .torus import HolographicTorus
from .attention import HolographicAttention, HolographicBlock
from .model import HolographicLM
from .engram import SystolicEngramCache
from .cartridge import save_cartridge, load_cartridge, inspect_cartridge

try:
    from .auto_model import AutoHolographicModel, HolographicConfig
    _HAS_AUTO = True
except ImportError:
    _HAS_AUTO = False

__all__ = [
    "HolographicTorus",
    "HolographicAttention",
    "HolographicBlock",
    "HolographicLM",
    "SystolicEngramCache",
    "save_cartridge",
    "load_cartridge",
    "inspect_cartridge",
]
if _HAS_AUTO:
    __all__ += ["AutoHolographicModel", "HolographicConfig"]

__version__ = "0.1.0"
__author__ = "Justin Arndt"
