"""
Engram Holographic Language Model

A complete language model built on the Engram architecture. Uses
HolographicAttention blocks instead of standard Multi-Head Attention.

Architecture:
    Token Embedding + Position Encoding
    → N × HolographicBlock (Holographic Attention + FFN)
    → LM Head (logits)

Key properties:
    - O(1) memory: context length is theoretically infinite
    - Dense systolic compute: saturates Tensor Cores / MXU
    - No KV cache: no OOM failures at any sequence length

Patent: U.S. Provisional Patent Application No. 63/989,566, filed February 24, 2026
Author: Justin Arndt
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math

from .attention import HolographicBlock


class HolographicLM(nn.Module):
    """
    Holographic Language Model — a transformer-scale LM using Engram.

    Default config (~30M params) is designed to train on a single
    RTX 4060 Laptop GPU (8GB VRAM) in under 1 hour.

    Args:
        vocab_size:   Vocabulary size
        d_model:      Model/embedding dimension
        n_layers:     Number of HolographicBlocks
        channels:     Torus channels per layer (like attention heads)
        grid_l:       Torus grid rows
        grid_m:       Torus grid columns
        ffn_dim:      FFN intermediate dimension
        max_seq_len:  Maximum training sequence length (for position encoding)
        dropout:      Dropout rate
    """

    def __init__(
        self,
        vocab_size: int = 50257,  # GPT-2 tokenizer
        d_model: int = 512,
        n_layers: int = 6,
        channels: int = 8,
        grid_l: int = 32,
        grid_m: int = 32,
        ffn_dim: int = 2048,
        max_seq_len: int = 2048,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.d_model = d_model
        self.vocab_size = vocab_size
        self.n_layers = n_layers

        # Token + positional embeddings
        self.token_emb = nn.Embedding(vocab_size, d_model)
        self.pos_emb = nn.Embedding(max_seq_len, d_model)
        self.emb_dropout = nn.Dropout(dropout)

        # Holographic blocks (replace standard transformer layers)
        self.blocks = nn.ModuleList([
            HolographicBlock(
                d_model=d_model,
                channels=channels,
                grid_l=grid_l,
                grid_m=grid_m,
                ffn_dim=ffn_dim,
                dropout=dropout,
            )
            for _ in range(n_layers)
        ])

        # Output head
        self.ln_f = nn.LayerNorm(d_model)
        self.lm_head = nn.Linear(d_model, vocab_size, bias=False)

        # Weight tying (embedding ↔ output)
        self.lm_head.weight = self.token_emb.weight

        # Initialize weights
        self.apply(self._init_weights)

        # Report
        n_params = sum(p.numel() for p in self.parameters())
        print(f"HolographicLM: {n_params:,} parameters ({n_params/1e6:.1f}M)")
        self._report_torus_memory()

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
        elif isinstance(module, nn.LayerNorm):
            torch.nn.init.ones_(module.weight)
            torch.nn.init.zeros_(module.bias)

    def _report_torus_memory(self):
        """Print the total fixed memory footprint of all tori."""
        total = sum(
            block.attention.torus.memory_bytes()
            for block in self.blocks
        )
        print(f"  Torus state: {total / (1024*1024):.2f} MB fixed (O(1) — never grows)")
        print(f"  Torus config: {self.blocks[0].attention.torus}")

    def reset_state(self, batch_size: int = 1):
        """Reset all torus states for a new sequence."""
        for block in self.blocks:
            block.reset_state(batch_size)

    def forward(
        self,
        input_ids: torch.Tensor,
        targets: torch.Tensor = None,
    ) -> dict:
        """
        Forward pass.

        Args:
            input_ids: [batch, seq_len] token indices
            targets:   [batch, seq_len] target token indices (for training)

        Returns:
            dict with 'logits' and optionally 'loss'
        """
        B, T = input_ids.shape
        device = input_ids.device

        # Embeddings
        positions = torch.arange(T, device=device).unsqueeze(0).expand(B, -1)
        positions = positions.clamp(max=self.pos_emb.num_embeddings - 1)

        x = self.token_emb(input_ids) + self.pos_emb(positions)
        x = self.emb_dropout(x)

        # Holographic blocks
        for block in self.blocks:
            x = block(x)

        # LM head
        x = self.ln_f(x)
        logits = self.lm_head(x)  # [B, T, vocab_size]

        result = {"logits": logits}

        if targets is not None:
            loss = F.cross_entropy(
                logits.view(-1, self.vocab_size),
                targets.view(-1),
                ignore_index=-100,
            )
            result["loss"] = loss

        return result

    @torch.no_grad()
    def generate(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 200,
        temperature: float = 0.8,
        top_k: int = 50,
    ) -> torch.Tensor:
        """
        Autoregressive text generation with O(1) memory.

        Unlike standard transformers, this does NOT build a KV cache.
        Memory stays constant regardless of generation length.
        """
        self.eval()
        B = input_ids.shape[0]
        self.reset_state(B)

        generated = input_ids.clone()

        # Process prompt through torus (builds holographic state)
        _ = self(input_ids)

        # Generate new tokens one at a time
        for _ in range(max_new_tokens):
            # Only feed the last token — state is in the torus
            last_token = generated[:, -1:].clone()

            # Get logits for next token
            out = self(last_token)
            logits = out["logits"][:, -1, :] / temperature

            # Top-k filtering
            if top_k > 0:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = -float("inf")

            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            generated = torch.cat([generated, next_token], dim=1)

        return generated

    def count_parameters(self) -> dict:
        """Breakdown of parameter counts by component."""
        emb = sum(p.numel() for p in self.token_emb.parameters())
        emb += sum(p.numel() for p in self.pos_emb.parameters())

        blocks = sum(p.numel() for p in self.blocks.parameters())
        head = 0  # Weight-tied with embedding

        return {
            "embeddings": emb,
            "blocks": blocks,
            "lm_head": head,
            "total": emb + blocks + head,
        }
