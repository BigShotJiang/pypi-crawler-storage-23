"""
Engram Knowledge Cartridge Format (.cart)
==========================================

A portable binary format for serializing Engram memory states.
Uses safetensors for the tensor payload and JSON for metadata.

A .cart file is a safetensors file with extra metadata keys:
    - engram_name: str
    - engram_author: str
    - engram_version: str
    - engram_token_count: str
    - engram_d_model: str
    - engram_channels: str
    - engram_grid_l: str
    - engram_grid_m: str
    - engram_etching_rate: str
    - engram_created_at: str

Usage:
    from engram.cartridge import save_cartridge, load_cartridge, inspect_cartridge

    save_cartridge(engram, "my_codebase.cart", name="Linux Kernel")
    engram = load_cartridge("my_codebase.cart")
    meta = inspect_cartridge("my_codebase.cart")

Author: Justin Arndt
Patent: U.S. Provisional Patent Application No. 63/989,566
"""

import torch
from safetensors.torch import save_file, load_file
from datetime import datetime, timezone
from typing import Optional
import json
import os


def save_cartridge(
    engram,
    path: str,
    name: str = "unnamed",
    author: str = "unknown",
    token_count: int = 0,
    version: str = "1.0",
):
    """
    Save an Engram's memory state to a portable .cart file.

    Args:
        engram: SystolicEngramCache instance
        path: Output file path (should end in .cart)
        name: Human-readable name for this cartridge
        author: Creator name
        token_count: Number of tokens etched into the engram
        version: Cartridge format version
    """
    # Metadata stored as safetensors metadata (must be str values)
    metadata = {
        "engram_name": name,
        "engram_author": author,
        "engram_version": version,
        "engram_token_count": str(token_count),
        "engram_d_model": str(engram.d_model),
        "engram_channels": str(engram.channels),
        "engram_grid_l": str(engram.grid_l),
        "engram_grid_m": str(engram.grid_m),
        "engram_etching_rate": str(engram.etching_rate),
        "engram_created_at": datetime.now(timezone.utc).isoformat(),
        "engram_format": "cart-v1",
    }

    # Tensors to serialize
    tensors = {
        "W_engram": engram.W_engram.cpu().float(),
        "liquid_torus": engram.liquid_torus.cpu().float(),
    }

    # Save as safetensors (fast, safe, no pickle)
    save_file(tensors, path, metadata=metadata)


def load_cartridge(path: str, device: str = None):
    """
    Load a .cart file and return a fresh SystolicEngramCache with the
    stored memory state.

    Args:
        path: Path to .cart file
        device: Target device ('cuda', 'cpu', or None for auto)

    Returns:
        SystolicEngramCache with loaded W_engram and liquid_torus
    """
    from engram.engram import SystolicEngramCache

    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"

    # Load metadata to reconstruct the config
    meta = inspect_cartridge(path)

    # Reconstruct the engram with the same config
    engram = SystolicEngramCache(
        d_model=int(meta.get("d_model", 512)),
        channels=int(meta.get("channels", 8)),
        grid_l=int(meta.get("grid_l", 64)),
        grid_m=int(meta.get("grid_m", 64)),
        etching_rate=float(meta.get("etching_rate", 0.01)),
    ).to(device)

    # Load the tensors
    tensors = load_file(path, device=device)

    # Inject into the engram
    engram.W_engram = tensors["W_engram"].to(torch.bfloat16)
    if "liquid_torus" in tensors:
        engram.liquid_torus = tensors["liquid_torus"].to(torch.bfloat16)

    return engram


def inspect_cartridge(path: str) -> dict:
    """
    Read cartridge metadata without loading the full tensor payload.

    Returns a flat dict with keys like 'name', 'author', 'd_model', etc.
    """
    from safetensors import safe_open

    result = {}
    with safe_open(path, framework="pt") as f:
        raw_meta = f.metadata()
        if raw_meta:
            for k, v in raw_meta.items():
                # Strip engram_ prefix for clean output
                clean_key = k.replace("engram_", "") if k.startswith("engram_") else k
                result[clean_key] = v

    # Add file size
    result["file_size_mb"] = f"{os.path.getsize(path) / (1024 * 1024):.2f}"

    return result
