"""
Engram Holographic Torus — O(1) State Memory

The core data structure of the Persistent Systolic Continuous State Engine.
Replaces all growing memory structures (KV caches, adjacency lists) with a
fixed-size 2D tensor on a bivariate toroidal lattice with periodic boundary
conditions.

Memory is strictly O(1): it never grows regardless of sequence length,
graph size, or time horizon. A 256×256 torus in bfloat16 consumes ~128 KB
per channel — pinned permanently in GPU SRAM.

Patent: U.S. Provisional Patent Application No. 63/989,566, filed February 24, 2026
Author: Justin Arndt
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class HolographicTorus(nn.Module):
    """
    O(1) Holographic State Memory on a Bivariate Toroidal Lattice.

    Instead of maintaining a KV cache that grows at O(N) per token,
    the torus maintains a fixed-size 2D state tensor with periodic
    boundary conditions. New information is absorbed in-place via
    an IIR temporal inertia filter — memory never expands.

    Args:
        channels:  Number of state channels (analogous to attention heads)
        grid_l:    Rows of the toroidal grid
        grid_m:    Columns of the toroidal grid
        inertia:   Base IIR filter strength (how much history to retain)
        disorder:  Scale of per-element inertia disorder (breaks symmetry)
        n_shifts:  Number of shift kernels (routing diversity)
    """

    def __init__(
        self,
        channels: int = 16,
        grid_l: int = 256,
        grid_m: int = 256,
        inertia: float = 0.92,
        disorder: float = 0.06,
        n_shifts: int = 4,
    ):
        super().__init__()
        self.channels = channels
        self.grid_l = grid_l
        self.grid_m = grid_m
        self.n_shifts = n_shifts

        # The O(1) state — fixed size, never grows
        self.register_buffer(
            "state",
            torch.zeros(1, channels, grid_l, grid_m, dtype=torch.bfloat16),
        )

        # Disordered IIR inertia tensor — breaks trapping-set symmetry
        # Each spatial position has a slightly different retention coefficient
        inertia_base = torch.full(
            (1, channels, grid_l, grid_m), inertia, dtype=torch.float32
        )
        noise = torch.empty_like(inertia_base).uniform_(-disorder, disorder)
        self.register_buffer("inertia_tensor", (inertia_base + noise).clamp(0.01, 0.99).to(torch.bfloat16))

        # Systolic shift kernels — one-hot convolution filters that route data
        # across the torus via dense MXU operations (no Scatter/Gather)
        self._build_shift_kernels(n_shifts)

    def _build_shift_kernels(self, n_shifts: int):
        """
        Build one-hot depthwise convolution kernels that implement
        topological routing on the torus via dense systolic operations.

        Each kernel shifts the state by a different (dy, dx) displacement,
        encoding connectivity patterns as compile-time constants.
        """
        # Fibonacci-like offsets for maximum spatial coverage
        shifts = [(0, 1), (1, 0), (1, 1), (2, 1), (1, 2), (3, 1), (1, 3), (2, 3)][:n_shifts]

        kernel_size = 5  # Accommodates shifts up to ±2
        center = kernel_size // 2

        # Shape: [channels * n_shifts, 1, kernel_size, kernel_size]
        kernel = torch.zeros(
            self.channels * n_shifts, 1, kernel_size, kernel_size,
            dtype=torch.bfloat16
        )
        for i, (dy, dx) in enumerate(shifts):
            for c in range(self.channels):
                idx = i * self.channels + c
                kernel[idx, 0, center + dy, center + dx] = 1.0

        self.register_buffer("shift_kernel", kernel)
        self.shift_groups = self.channels  # Depthwise per shift

    def reset_state(self, batch_size: int = 1):
        """Zero the holographic state. O(1) operation."""
        self.state = torch.zeros(
            batch_size, self.channels, self.grid_l, self.grid_m,
            dtype=torch.bfloat16, device=self.state.device,
        )

    def convolve_systolic(self, state: torch.Tensor) -> torch.Tensor:
        """
        Execute dense systolic convolutions on the torus.

        This replaces ALL sparse data routing (Scatter/Gather/Attention KV lookup)
        with dense 2D circular convolutions that saturate the MXU/Tensor Cores.

        The circular padding implements the toroidal topology: data wrapping off
        any edge seamlessly enters the opposite edge.
        """
        pad = self.shift_kernel.shape[-1] // 2

        # Circular padding = toroidal wrap-around
        padded = F.pad(state, (pad, pad, pad, pad), mode="circular")

        # Expand state for multi-shift depthwise conv
        # [B, C, H, W] → [B, C*n_shifts, H, W] via repeat
        state_expanded = state.repeat(1, self.n_shifts, 1, 1)
        padded_expanded = F.pad(state_expanded, (pad, pad, pad, pad), mode="circular")

        # Dense systolic convolution — runs on Tensor Cores at maximum utilization
        shifted = F.conv2d(
            padded_expanded,
            self.shift_kernel,
            padding=0,
            groups=self.channels * self.n_shifts,
        )

        # Aggregate multi-shift messages via mean (branchless reduction)
        B, _, H, W = shifted.shape
        shifted = shifted.view(B, self.n_shifts, self.channels, H, W).mean(dim=1)

        return shifted

    def absorb(self, incoming: torch.Tensor) -> torch.Tensor:
        """
        Absorb new data into the holographic state via IIR temporal inertia.

        State_new = α · State_shifted + (1 - α) · incoming

        This is the O(1) update: two element-wise multiplications and one
        addition. Zero matrix inversions. Zero growing buffers. The disordered
        α tensor breaks symmetric oscillation modes organically.
        """
        # Phase D: Systolic convolution routes historical context
        shifted = self.convolve_systolic(self.state)

        # Phase E: IIR in-place absorption (the holographic interference)
        self.state = (shifted * self.inertia_tensor) + (incoming * (1.0 - self.inertia_tensor))

        return self.state

    def forward(self, spatial_token: torch.Tensor) -> torch.Tensor:
        """
        Full torus cycle: absorb projected spatial token, return updated state.

        Args:
            spatial_token: Tensor of shape [B, channels, grid_l, grid_m]

        Returns:
            Updated holographic state (same shape)
        """
        return self.absorb(spatial_token)

    @torch.no_grad()
    def memory_bytes(self) -> int:
        """Report exact memory footprint. This number NEVER changes."""
        return self.state.nelement() * self.state.element_size()

    def __repr__(self) -> str:
        mb = self.memory_bytes() / (1024 * 1024)
        return (
            f"HolographicTorus("
            f"channels={self.channels}, "
            f"grid={self.grid_l}×{self.grid_m}, "
            f"memory={mb:.2f} MB fixed, "
            f"shifts={self.n_shifts})"
        )
