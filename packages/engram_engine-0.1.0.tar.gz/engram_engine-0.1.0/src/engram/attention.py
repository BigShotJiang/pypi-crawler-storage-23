"""
Engram Holographic Attention — Transformer Attention Replacement

Replaces standard Multi-Head Attention (Q·K^T softmax → V) with
systolic torus convolutions. Instead of maintaining a KV cache that
grows at O(N) per token, the holographic attention layer projects
inputs onto a fixed-size toroidal lattice and routes information
via dense 2D circular convolutions.

Key differences from standard attention:
- Memory: O(1) fixed vs O(N) growing KV cache
- Compute: Dense systolic conv (saturates MXU) vs sparse attention (starves MXU)
- Branching: Zero (all tensor ops) vs softmax + masking

Patent: U.S. Provisional Patent Application No. 63/989,566, filed February 24, 2026
Author: Justin Arndt
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math

from .torus import HolographicTorus


class HolographicAttention(nn.Module):
    """
    Holographic Attention — replaces Multi-Head Attention with systolic
    torus convolutions.

    The input token embedding is projected onto a 2D toroidal lattice
    (the "holographic projection"), convolved with the persistent state
    via dense systolic operations, and read back out to produce the
    attention output. The torus state absorbs context via an IIR filter,
    creating a non-destructive interference pattern that encodes
    the entire history in O(1) memory.

    Args:
        d_model:    Model dimension (embedding size)
        channels:   Number of torus channels (like attention heads)
        grid_l:     Torus grid rows
        grid_m:     Torus grid columns
        inertia:    IIR retention strength
        dropout:    Output dropout rate
    """

    def __init__(
        self,
        d_model: int = 768,
        channels: int = 12,
        grid_l: int = 64,
        grid_m: int = 64,
        inertia: float = 0.92,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.d_model = d_model
        self.channels = channels
        self.grid_l = grid_l
        self.grid_m = grid_m
        self.torus_dim = channels * grid_l * grid_m

        # The holographic torus — O(1) persistent state
        self.torus = HolographicTorus(
            channels=channels,
            grid_l=grid_l,
            grid_m=grid_m,
            inertia=inertia,
            n_shifts=4,
        )

        # Phase C: Holographic Projection (1D → 2D torus)
        # Projects the d_model embedding into a spatial pattern on the torus
        self.project_in = nn.Linear(d_model, self.torus_dim)

        # Phase F: Readout Projection (2D torus → 1D)
        # Reads the updated holographic state back to embedding space
        self.project_out = nn.Linear(self.torus_dim, d_model)

        # Layer norm for stability
        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

        # Gate for residual blending (learned)
        self.gate = nn.Linear(d_model, d_model)

    def reset_state(self, batch_size: int = 1):
        """Reset the torus state for a new sequence."""
        self.torus.reset_state(batch_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Holographic attention forward pass.

        Args:
            x: Input tensor of shape [batch, seq_len, d_model]

        Returns:
            Output tensor of shape [batch, seq_len, d_model]
        """
        B, T, D = x.shape
        outputs = []

        for t in range(T):
            token = x[:, t, :]  # [B, D]

            # Phase C: Holographic Projection — 1D embedding → 2D spatial pattern
            spatial = self.project_in(token)  # [B, channels * grid_l * grid_m]
            spatial = spatial.view(B, self.channels, self.grid_l, self.grid_m)
            spatial = spatial.to(torch.bfloat16)

            # Phases D + E: Systolic convolution + IIR absorption
            # This replaces the entire Q·K^T·softmax·V pipeline
            updated_state = self.torus(spatial)  # [B, C, H, W]

            # Phase F: Readout Projection — 2D torus → 1D embedding
            flat = updated_state.flatten(1).float()  # [B, channels * grid_l * grid_m]
            out = self.project_out(flat)  # [B, D]

            outputs.append(out)

        output = torch.stack(outputs, dim=1)  # [B, T, D]

        # Gated residual connection
        gate_weight = torch.sigmoid(self.gate(x))
        output = gate_weight * output + (1 - gate_weight) * x
        output = self.norm(output)
        output = self.dropout(output)

        return output


class HolographicBlock(nn.Module):
    """
    A single transformer-style block using Holographic Attention + FFN.

    Replaces the standard:
        x → MultiHeadAttention(x) + x → FFN(x) + x

    With:
        x → HolographicAttention(x) + x → FFN(x) + x

    The attention mechanism uses O(1) memory instead of O(N).
    """

    def __init__(
        self,
        d_model: int = 768,
        channels: int = 12,
        grid_l: int = 64,
        grid_m: int = 64,
        ffn_dim: int = 3072,
        dropout: float = 0.1,
    ):
        super().__init__()

        # Holographic Attention (replaces Multi-Head Attention)
        self.attention = HolographicAttention(
            d_model=d_model,
            channels=channels,
            grid_l=grid_l,
            grid_m=grid_m,
            dropout=dropout,
        )

        # Standard FFN (unchanged from transformers)
        self.ffn = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, ffn_dim),
            nn.GELU(),
            nn.Linear(ffn_dim, d_model),
            nn.Dropout(dropout),
        )

        self.norm = nn.LayerNorm(d_model)

    def reset_state(self, batch_size: int = 1):
        self.attention.reset_state(batch_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Holographic attention + residual
        x = x + self.attention(x)

        # FFN + residual
        x = x + self.ffn(self.norm(x))

        return x
