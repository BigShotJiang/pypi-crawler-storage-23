"""
Engram AutoHolographicModel — HuggingFace PreTrainedModel Wrapper
==================================================================

Drop-in integration with the HuggingFace ecosystem. Wraps HolographicLM
in a PreTrainedModel-compatible interface so users can use Engram with
existing HF pipelines, tokenizers, and training utilities.

Usage:
    from engram.auto_model import AutoHolographicModel, HolographicConfig

    config = HolographicConfig(d_model=512, n_layers=6)
    model = AutoHolographicModel(config)

    # Use with any HF tokenizer
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained("gpt2")

    inputs = tokenizer("Hello world", return_tensors="pt")
    outputs = model(**inputs)
    logits = outputs.logits

Author: Justin Arndt
Patent: U.S. Provisional Patent Application No. 63/989,566
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from dataclasses import dataclass, field, asdict
from typing import Optional, Tuple

try:
    from transformers import PreTrainedModel, PretrainedConfig
    from transformers.modeling_outputs import CausalLMOutputWithPast
    HAS_TRANSFORMERS = True
except ImportError:
    HAS_TRANSFORMERS = False
    # Fallback stubs for environments without transformers
    PreTrainedModel = nn.Module
    PretrainedConfig = object
    CausalLMOutputWithPast = None

from .attention import HolographicBlock


# ──────────────────────────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────────────────────────
class HolographicConfig(PretrainedConfig if HAS_TRANSFORMERS else object):
    """Configuration for AutoHolographicModel."""

    model_type = "holographic"

    def __init__(
        self,
        vocab_size: int = 50257,
        d_model: int = 512,
        n_layers: int = 6,
        channels: int = 8,
        grid_l: int = 32,
        grid_m: int = 32,
        ffn_dim: int = 2048,
        max_seq_len: int = 2048,
        dropout: float = 0.1,
        etching_rate: float = 0.01,
        **kwargs,
    ):
        self.vocab_size = vocab_size
        self.d_model = d_model
        self.n_layers = n_layers
        self.channels = channels
        self.grid_l = grid_l
        self.grid_m = grid_m
        self.ffn_dim = ffn_dim
        self.max_seq_len = max_seq_len
        self.dropout = dropout
        self.etching_rate = etching_rate

        if HAS_TRANSFORMERS:
            super().__init__(**kwargs)


# ──────────────────────────────────────────────────────────────────
# The Model
# ──────────────────────────────────────────────────────────────────
class AutoHolographicModel(PreTrainedModel):
    """
    HuggingFace-compatible Holographic Language Model.

    Drop-in replacement for any CausalLM in the HF ecosystem.
    Uses O(1) toroidal holographic attention instead of the O(N) KV cache.

    Compatible with:
        - transformers.Trainer
        - transformers.pipeline("text-generation", ...)
        - AutoTokenizer (use any GPT-2 compatible tokenizer)
        - .save_pretrained() / .from_pretrained()

    Usage:
        config = HolographicConfig(d_model=512, n_layers=6)
        model = AutoHolographicModel(config)
        outputs = model(input_ids=input_ids)
        logits = outputs.logits
    """

    config_class = HolographicConfig if HAS_TRANSFORMERS else None
    supports_gradient_checkpointing = False

    def __init__(self, config):
        if HAS_TRANSFORMERS:
            super().__init__(config)
        else:
            super().__init__()
            self.config = config

        self.d_model = config.d_model
        self.vocab_size = config.vocab_size

        # Token + positional embeddings
        self.token_emb = nn.Embedding(config.vocab_size, config.d_model)
        self.pos_emb = nn.Embedding(config.max_seq_len, config.d_model)
        self.emb_dropout = nn.Dropout(config.dropout)

        # Holographic blocks (O(1) memory per block)
        self.blocks = nn.ModuleList([
            HolographicBlock(
                d_model=config.d_model,
                channels=config.channels,
                grid_l=config.grid_l,
                grid_m=config.grid_m,
                ffn_dim=config.ffn_dim,
                dropout=config.dropout,
            )
            for _ in range(config.n_layers)
        ])

        # Output head
        self.ln_f = nn.LayerNorm(config.d_model)
        self.lm_head = nn.Linear(config.d_model, config.vocab_size, bias=False)

        # Weight tying
        self.lm_head.weight = self.token_emb.weight

        # Initialize
        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
        elif isinstance(module, nn.LayerNorm):
            nn.init.ones_(module.weight)
            nn.init.zeros_(module.bias)

    def reset_state(self, batch_size: int = 1):
        """Reset all torus states for a new sequence."""
        for block in self.blocks:
            block.reset_state(batch_size)

    def get_input_embeddings(self):
        return self.token_emb

    def set_input_embeddings(self, value):
        self.token_emb = value

    def get_output_embeddings(self):
        return self.lm_head

    def set_output_embeddings(self, new_embeddings):
        self.lm_head = new_embeddings

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.LongTensor] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        return_dict: Optional[bool] = True,
        **kwargs,
    ):
        """
        HuggingFace-compatible forward pass.

        Args:
            input_ids:     [B, T] token indices
            attention_mask: [B, T] attention mask (accepted but ignored —
                           Engram uses continuous state, not sparse attention)
            labels:        [B, T] target tokens for loss computation
            inputs_embeds: [B, T, D] pre-computed embeddings (alternative to input_ids)
            return_dict:   Whether to return a CausalLMOutputWithPast

        Returns:
            CausalLMOutputWithPast with .logits and optionally .loss
        """
        if inputs_embeds is not None:
            x = inputs_embeds
            B, T, _ = x.shape
        elif input_ids is not None:
            B, T = input_ids.shape
            device = input_ids.device
            positions = torch.arange(T, device=device).unsqueeze(0).expand(B, -1)
            positions = positions.clamp(max=self.pos_emb.num_embeddings - 1)
            x = self.token_emb(input_ids) + self.pos_emb(positions)
        else:
            raise ValueError("Either input_ids or inputs_embeds must be provided")

        x = self.emb_dropout(x)

        # Route through holographic blocks (O(1) per block)
        for block in self.blocks:
            x = block(x)

        x = self.ln_f(x)
        logits = self.lm_head(x)

        # Compute loss if labels provided
        loss = None
        if labels is not None:
            loss = F.cross_entropy(
                logits.view(-1, self.vocab_size),
                labels.view(-1),
                ignore_index=-100,
            )

        if CausalLMOutputWithPast is not None and return_dict:
            return CausalLMOutputWithPast(
                loss=loss,
                logits=logits,
                past_key_values=None,  # No KV cache — O(1) memory!
            )
        else:
            result = {"logits": logits}
            if loss is not None:
                result["loss"] = loss
            return result

    @torch.no_grad()
    def generate(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 200,
        temperature: float = 0.8,
        top_k: int = 50,
        **kwargs,
    ) -> torch.Tensor:
        """
        Autoregressive generation with O(1) memory.

        No KV cache. Memory stays constant regardless of generation length.
        """
        self.eval()
        B = input_ids.shape[0]
        self.reset_state(B)

        generated = input_ids.clone()

        # Process prompt
        _ = self(input_ids)

        for _ in range(max_new_tokens):
            last_token = generated[:, -1:]
            out = self(last_token)

            if isinstance(out, dict):
                next_logits = out["logits"][:, -1, :] / temperature
            else:
                next_logits = out.logits[:, -1, :] / temperature

            if top_k > 0:
                v, _ = torch.topk(next_logits, min(top_k, next_logits.size(-1)))
                next_logits[next_logits < v[:, [-1]]] = -float("inf")

            probs = F.softmax(next_logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            generated = torch.cat([generated, next_token], dim=1)

        return generated

    def memory_report(self) -> str:
        """Report O(1) memory usage across all layers."""
        total_bytes = sum(
            block.attention.torus.memory_bytes()
            for block in self.blocks
        )
        return (
            f"AutoHolographicModel(\n"
            f"  Layers: {len(self.blocks)}\n"
            f"  d_model: {self.d_model}\n"
            f"  Total O(1) memory: {total_bytes / 1e6:.2f} MB\n"
            f"  Memory growth: O(1) — never increases\n"
            f")"
        )
