"""
Engram Swarm-Chat Server — OpenAI-Compatible FastAPI Backend
=============================================================

An OpenAI-compatible streaming API server for the Engram Hive Mind.
Multiple clients can chat with a swarm of agents that share a single
Engram in VRAM. Knowledge is shared telepathically via tensor resonance.

Endpoints:
    POST /v1/chat/completions  — OpenAI-compatible chat (streaming + non-streaming)
    POST /v1/engram/save       — Save current engram to .cart cartridge
    POST /v1/engram/load       — Load a .cart cartridge
    GET  /v1/engram/status     — Engram memory report + active agent count
    GET  /health               — Health check

Usage:
    engram serve                        # Start the server (port 8000)
    engram serve --port 3000            # Custom port

    # Then use any OpenAI-compatible client:
    curl http://localhost:8000/v1/chat/completions \\
        -H "Content-Type: application/json" \\
        -d '{"model": "engram-hive", "messages": [{"role": "user", "content": "Hello"}]}'

Author: Justin Arndt
Patent: U.S. Provisional Patent Application No. 63/989,566
"""

import torch
import torch.nn.functional as F
import json
import time
import uuid
import os
import sys
from typing import Optional, List
from dataclasses import dataclass

_repo = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(_repo, "src"))

try:
    from fastapi import FastAPI, HTTPException
    from fastapi.responses import StreamingResponse, JSONResponse
    from pydantic import BaseModel, Field
    import uvicorn
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False

from engram.engram import SystolicEngramCache


# ──────────────────────────────────────────────────────────────────
# Pydantic Models (OpenAI-compatible schema)
# ──────────────────────────────────────────────────────────────────
if HAS_FASTAPI:

    class ChatMessage(BaseModel):
        role: str = "user"
        content: str = ""

    class ChatRequest(BaseModel):
        model: str = "engram-hive"
        messages: List[ChatMessage] = []
        temperature: float = 0.8
        max_tokens: int = 128
        stream: bool = False

    class CartridgeRequest(BaseModel):
        path: str = "engram.cart"

    # ──────────────────────────────────────────────────────────────
    # The Hive Mind Server
    # ──────────────────────────────────────────────────────────────
    def create_app(
        d_model: int = 512,
        channels: int = 8,
        grid_l: int = 32,
        grid_m: int = 32,
    ) -> FastAPI:
        """Create the FastAPI application with a shared Hive Mind."""

        app = FastAPI(
            title="Engram Swarm-Chat Server",
            description="OpenAI-compatible API backed by O(1) Holographic Engram Memory",
            version="0.1.0",
        )

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        torus_volume = channels * grid_l * grid_m

        # The shared Hive Mind — one Engram for all connections
        hive = SystolicEngramCache(
            d_model=d_model,
            channels=channels,
            grid_l=grid_l,
            grid_m=grid_m,
            etching_rate=0.05,
        ).to(device)

        active_sessions = {}

        @app.get("/health")
        async def health():
            return {"status": "ok", "device": str(device), "model": "engram-hive"}

        @app.get("/v1/engram/status")
        async def engram_status():
            """Return current Engram memory stats."""
            mem = hive.memory_bytes()
            engram_norm = hive.W_engram.float().norm().item()
            return {
                "d_model": d_model,
                "torus_volume": torus_volume,
                "memory_bytes": mem,
                "memory_mb": round(mem / 1e6, 2),
                "engram_norm": round(engram_norm, 4),
                "active_sessions": len(active_sessions),
                "memory_growth": "O(1) — never increases",
            }

        @app.post("/v1/engram/save")
        async def save_engram(req: CartridgeRequest):
            """Save the current Hive Mind to a .cart cartridge."""
            from engram.cartridge import save_cartridge
            try:
                save_cartridge(hive, req.path, name="hive-mind-live")
                size_mb = os.path.getsize(req.path) / (1024 * 1024)
                return {"status": "saved", "path": req.path, "size_mb": round(size_mb, 2)}
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @app.post("/v1/engram/load")
        async def load_engram(req: CartridgeRequest):
            """Load a .cart cartridge into the Hive Mind."""
            from engram.cartridge import load_cartridge
            try:
                loaded = load_cartridge(req.path, device=str(device))
                hive.W_engram = loaded.W_engram
                hive.liquid_torus = loaded.liquid_torus
                return {"status": "loaded", "path": req.path}
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @app.post("/v1/chat/completions")
        async def chat_completions(req: ChatRequest):
            """
            OpenAI-compatible chat completions endpoint.

            In this demo, the Engram processes the message embedding
            and returns a resonance-based response. In production,
            this would be connected to a full HolographicLM.
            """
            # Extract the latest user message
            user_msg = ""
            for m in req.messages:
                if m.role == "user":
                    user_msg = m.content

            if not user_msg:
                raise HTTPException(400, "No user message found")

            # Create a session-specific agent (shares the Hive Mind engram)
            session_id = str(uuid.uuid4())[:8]
            active_sessions[session_id] = time.time()

            # Hash the message into an embedding (demo mode)
            # In production, this would come from a tokenizer + embedding layer
            torch.manual_seed(hash(user_msg) % 2**32)
            msg_embedding = torch.randn(1, torus_volume, device=device)

            # Process through the Hive Mind
            output = hive(msg_embedding, reward=1.0)

            # Generate a response description based on engram resonance
            engram_energy = output["engram"].float().norm().item()
            liquid_energy = output["liquid"].float().norm().item()

            response_text = (
                f"[Engram Hive Mind | Session {session_id}]\n"
                f"Engram resonance: {engram_energy:.4f} | "
                f"Liquid state: {liquid_energy:.4f}\n\n"
                f"Your message has been etched into the shared Engram crystal. "
                f"All {len(active_sessions)} connected agents now share this knowledge "
                f"via tensor resonance. Memory remains at O(1): "
                f"{hive.memory_bytes() / 1e6:.2f} MB regardless of history length."
            )

            # Clean up old sessions (>5 min)
            cutoff = time.time() - 300
            expired = [k for k, v in active_sessions.items() if v < cutoff]
            for k in expired:
                del active_sessions[k]

            # Build OpenAI-compatible response
            completion_id = f"chatcmpl-{uuid.uuid4().hex[:12]}"
            timestamp = int(time.time())

            if req.stream:
                # Streaming response (SSE)
                async def generate_stream():
                    for i, chunk in enumerate(response_text.split(" ")):
                        data = {
                            "id": completion_id,
                            "object": "chat.completion.chunk",
                            "created": timestamp,
                            "model": "engram-hive",
                            "choices": [{
                                "index": 0,
                                "delta": {"content": chunk + " "},
                                "finish_reason": None,
                            }],
                        }
                        yield f"data: {json.dumps(data)}\n\n"
                    # Final chunk
                    yield f"data: {json.dumps({'id': completion_id, 'object': 'chat.completion.chunk', 'created': timestamp, 'model': 'engram-hive', 'choices': [{'index': 0, 'delta': {}, 'finish_reason': 'stop'}]})}\n\n"
                    yield "data: [DONE]\n\n"

                return StreamingResponse(
                    generate_stream(),
                    media_type="text/event-stream",
                )

            else:
                return {
                    "id": completion_id,
                    "object": "chat.completion",
                    "created": timestamp,
                    "model": "engram-hive",
                    "choices": [{
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": response_text,
                        },
                        "finish_reason": "stop",
                    }],
                    "usage": {
                        "prompt_tokens": len(user_msg.split()),
                        "completion_tokens": len(response_text.split()),
                        "total_tokens": len(user_msg.split()) + len(response_text.split()),
                    },
                    "engram_telemetry": {
                        "engram_energy": round(engram_energy, 4),
                        "liquid_energy": round(liquid_energy, 4),
                        "memory_mb": round(hive.memory_bytes() / 1e6, 2),
                        "active_sessions": len(active_sessions),
                    },
                }

        return app


def serve(host: str = "0.0.0.0", port: int = 8000):
    """Launch the Swarm-Chat server."""
    if not HAS_FASTAPI:
        print("Error: FastAPI not installed. Run: pip install fastapi uvicorn")
        sys.exit(1)

    application = create_app()
    print(f"\n🧠 Engram Swarm-Chat Server starting on http://{host}:{port}")
    print(f"   OpenAI-compatible endpoint: http://{host}:{port}/v1/chat/completions")
    print(f"   Engram status:              http://{host}:{port}/v1/engram/status")
    print(f"   Health check:               http://{host}:{port}/health\n")
    uvicorn.run(application, host=host, port=port)


if __name__ == "__main__":
    serve()
