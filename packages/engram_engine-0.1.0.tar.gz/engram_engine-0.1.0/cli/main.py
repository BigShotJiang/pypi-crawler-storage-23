"""
Engram CLI — Holographic Swarm Engine Command Line Interface
=============================================================

The unified entrypoint for Engram. Run benchmarks, inject knowledge
cartridges, launch hive mind swarms, and perform Transformer lobotomies
— all from your terminal with beautiful Rich formatting.

Usage:
    engram run swarm          # Multi-agent telepathic weight sharing
    engram run recall         # Needle-in-a-haystack benchmark
    engram run memory-wall    # The OOM benchmark
    engram run kung-fu        # Swarm RL: "I Know Kung Fu"
    engram run lobotomy       # Surgical Transformer attention replacement
    engram run cartridge      # Knowledge cartridge save/load demo
    engram save out.cart      # Save engram to portable cartridge
    engram inject in.cart     # Load a knowledge cartridge
    engram inspect in.cart    # View cartridge metadata
    engram info               # Print architecture & memory report

Author: Justin Arndt
Patent: U.S. Provisional Patent Application No. 63/989,566
"""

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import print as rprint
import sys
import os
import importlib
import subprocess

app = typer.Typer(
    name="engram",
    help="🧠 Engram: Persistent Systolic Continuous State Engine — Holographic Swarm OS",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
console = Console()

# ──────────────────────────────────────────────────────────────────
# Utility: find repo root
# ──────────────────────────────────────────────────────────────────
def _repo_root():
    """Find the repository root (where pyproject.toml lives)."""
    d = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if os.path.exists(os.path.join(d, "pyproject.toml")):
        return d
    # fallback
    return os.getcwd()


def _run_script(script_path: str, label: str):
    """Run a demo/benchmark script as a subprocess with Rich formatting."""
    root = _repo_root()
    full_path = os.path.join(root, script_path)
    if not os.path.exists(full_path):
        console.print(f"[red]Error:[/red] Script not found: {full_path}")
        raise typer.Exit(1)

    console.print(Panel(
        f"[bold cyan]{label}[/bold cyan]\n[dim]{script_path}[/dim]",
        border_style="bright_cyan",
        expand=False,
    ))

    result = subprocess.run(
        [sys.executable, full_path],
        cwd=root,
        env={**os.environ, "PYTHONPATH": os.path.join(root, "src")},
    )
    if result.returncode != 0:
        console.print(f"\n[red]Script exited with code {result.returncode}[/red]")
        raise typer.Exit(result.returncode)


# ──────────────────────────────────────────────────────────────────
# engram run <demo>
# ──────────────────────────────────────────────────────────────────
run_app = typer.Typer(
    help="🚀 Run demos and benchmarks",
    no_args_is_help=True,
)
app.add_typer(run_app, name="run")

DEMOS = {
    "swarm": ("demo/hive_mind.py", "🐝 Hive Mind: Multi-Agent Telepathic Weight Sharing"),
    "recall": ("benchmarks/long_context_recall.py", "🎯 Needle-in-a-Haystack: Shannon Entropy Wall"),
    "memory-wall": ("benchmarks/memory_wall.py", "💥 The Von Neumann Memory Wall"),
    "kung-fu": ("demo/swarm_rl.py", "🥋 Swarm RL: \"I Know Kung Fu\""),
    "lobotomy": ("demo/lobotomy.py", "🏥 The Lobotomy: Transformer Attention Grafting"),
    "cartridge": ("demo/knowledge_cartridge.py", "💾 Knowledge Cartridges: Zero-FLOP Context"),
    "generate": ("demo/generate.py", "✨ Text Generation Demo"),
    "hybrid": ("benchmarks/hybrid_inference.py", "🔀 Hybrid GPT-2 Inference"),
    "perplexity": ("benchmarks/perplexity.py", "📊 Perplexity Benchmark"),
}


@run_app.command("swarm")
def run_swarm():
    """🐝 Launch the multi-agent Hive Mind demo."""
    _run_script(*DEMOS["swarm"])

@run_app.command("recall")
def run_recall():
    """🎯 Run the needle-in-a-haystack recall benchmark."""
    _run_script(*DEMOS["recall"])

@run_app.command("memory-wall")
def run_memory_wall():
    """💥 Run the Von Neumann Memory Wall OOM benchmark."""
    _run_script(*DEMOS["memory-wall"])

@run_app.command("kung-fu")
def run_kung_fu():
    """🥋 Run the Swarm RL "I Know Kung Fu" demo."""
    _run_script(*DEMOS["kung-fu"])

@run_app.command("lobotomy")
def run_lobotomy():
    """🏥 Surgically replace Transformer attention with O(1) Engram."""
    _run_script(*DEMOS["lobotomy"])

@run_app.command("cartridge")
def run_cartridge():
    """💾 Run the Knowledge Cartridge save/load demo."""
    _run_script(*DEMOS["cartridge"])

@run_app.command("generate")
def run_generate():
    """✨ Run the text generation demo."""
    _run_script(*DEMOS["generate"])

@run_app.command("hybrid")
def run_hybrid():
    """🔀 Run the hybrid GPT-2 inference benchmark."""
    _run_script(*DEMOS["hybrid"])

@run_app.command("perplexity")
def run_perplexity():
    """📊 Run the perplexity benchmark."""
    _run_script(*DEMOS["perplexity"])


# ──────────────────────────────────────────────────────────────────
# engram info
# ──────────────────────────────────────────────────────────────────
@app.command()
def info():
    """📊 Print Engram architecture and memory report."""
    try:
        from engram.engram import SystolicEngramCache
        import torch

        console.print(Panel(
            "[bold bright_cyan]🧠 Engram: Persistent Systolic Continuous State Engine[/bold bright_cyan]\n"
            "[dim]Holographic Swarm OS — O(1) Memory, Infinite Context[/dim]",
            border_style="bright_cyan",
            expand=False,
        ))

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Default config
        engram = SystolicEngramCache(
            d_model=512, channels=8, grid_l=64, grid_m=64
        ).to(device)

        table = Table(title="Systolic Engram Cache — Default Configuration")
        table.add_column("Component", style="cyan")
        table.add_column("Shape", style="green")
        table.add_column("Size", style="yellow", justify="right")

        torus_bytes = engram.liquid_torus.nelement() * engram.liquid_torus.element_size()
        engram_bytes = engram.W_engram.nelement() * engram.W_engram.element_size()

        table.add_row(
            "Liquid Torus (Working Memory)",
            str(list(engram.liquid_torus.shape)),
            f"{torus_bytes / 1024:.1f} KB",
        )
        table.add_row(
            "Crystalline Engram (Long-Term)",
            str(list(engram.W_engram.shape)),
            f"{engram_bytes / 1e6:.2f} MB",
        )
        table.add_row(
            "Total O(1) Memory",
            "—",
            f"{(torus_bytes + engram_bytes) / 1e6:.2f} MB",
        )
        console.print(table)

        # Architecture summary
        arch = Table(title="Architecture")
        arch.add_column("Feature", style="cyan")
        arch.add_column("Value", style="green")
        arch.add_row("d_model", str(engram.d_model))
        arch.add_row("Torus Channels", str(engram.channels))
        arch.add_row("Grid (L × M)", f"{engram.grid_l} × {engram.grid_m}")
        arch.add_row("Torus Volume", f"{engram.torus_volume:,}")
        arch.add_row("Device", str(device))
        arch.add_row("Memory Growth", "O(1) — never increases")
        console.print(arch)

    except ImportError as e:
        console.print(f"[red]Error:[/red] {e}")
        console.print("[dim]Run `pip install -e .` to install engram[/dim]")
        raise typer.Exit(1)


# ──────────────────────────────────────────────────────────────────
# engram save <output.cart>
# ──────────────────────────────────────────────────────────────────
@app.command()
def save(
    output: str = typer.Argument(..., help="Output cartridge file path (.cart)"),
    tokens: int = typer.Option(100, help="Number of random tokens to etch (demo mode)"),
):
    """💾 Save an Engram to a portable Knowledge Cartridge (.cart) file."""
    from engram.cartridge import save_cartridge
    from engram.engram import SystolicEngramCache
    import torch

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    with console.status("[bold cyan]Initializing Engram...", spinner="dots"):
        engram = SystolicEngramCache(
            d_model=512, channels=8, grid_l=32, grid_m=32,
            etching_rate=0.05,
        ).to(device)

    torus_vol = engram.channels * engram.grid_l * engram.grid_m
    console.print(f"[cyan]Etching {tokens} tokens into Engram...[/cyan]")

    torch.manual_seed(42)
    for i in range(tokens):
        tok = torch.randn(1, torus_vol, device=device)
        engram(tok, reward=1.0)

    save_cartridge(engram, output, name=f"demo-{tokens}tok", author="engram-cli")
    size_mb = os.path.getsize(output) / (1024 * 1024)
    console.print(Panel(
        f"[bold green]✅ Saved![/bold green]\n"
        f"[dim]File: {output}\n"
        f"Size: {size_mb:.2f} MB\n"
        f"Tokens etched: {tokens}[/dim]",
        border_style="green",
        expand=False,
    ))


# ──────────────────────────────────────────────────────────────────
# engram inject <input.cart>
# ──────────────────────────────────────────────────────────────────
@app.command()
def inject(
    cartridge_file: str = typer.Argument(..., help="Cartridge file to load (.cart)"),
):
    """🔌 Load a Knowledge Cartridge into a fresh Engram model."""
    from engram.cartridge import load_cartridge, inspect_cartridge

    if not os.path.exists(cartridge_file):
        console.print(f"[red]Error:[/red] File not found: {cartridge_file}")
        raise typer.Exit(1)

    meta = inspect_cartridge(cartridge_file)
    console.print(Panel(
        f"[bold cyan]Loading Cartridge[/bold cyan]\n"
        f"[dim]Name: {meta.get('name', 'unknown')}\n"
        f"Author: {meta.get('author', 'unknown')}\n"
        f"Tokens: {meta.get('token_count', '?')}[/dim]",
        border_style="cyan",
        expand=False,
    ))

    engram = load_cartridge(cartridge_file)
    console.print(f"[bold green]✅ Cartridge loaded![/bold green]")
    console.print(f"[dim]{engram.memory_report()}[/dim]")


# ──────────────────────────────────────────────────────────────────
# engram inspect <file.cart>
# ──────────────────────────────────────────────────────────────────
@app.command()
def inspect(
    cartridge_file: str = typer.Argument(..., help="Cartridge file to inspect (.cart)"),
):
    """🔍 View metadata of a Knowledge Cartridge without loading tensors."""
    from engram.cartridge import inspect_cartridge

    if not os.path.exists(cartridge_file):
        console.print(f"[red]Error:[/red] File not found: {cartridge_file}")
        raise typer.Exit(1)

    meta = inspect_cartridge(cartridge_file)

    table = Table(title=f"Cartridge: {cartridge_file}")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="green")

    for k, v in meta.items():
        table.add_row(str(k), str(v))

    console.print(table)


# ──────────────────────────────────────────────────────────────────
# engram serve
# ──────────────────────────────────────────────────────────────────
@app.command()
def serve(
    host: str = typer.Option("0.0.0.0", help="Host to bind to"),
    port: int = typer.Option(8000, help="Port to listen on"),
):
    """🌐 Launch the Swarm-Chat FastAPI server (OpenAI-compatible)."""
    console.print(Panel(
        "[bold bright_cyan]🌐 Engram Swarm-Chat Server[/bold bright_cyan]\n"
        "[dim]OpenAI-compatible API backed by O(1) Holographic Engram[/dim]",
        border_style="bright_cyan",
        expand=False,
    ))

    try:
        from server.swarm_chat import serve as _serve
        _serve(host=host, port=port)
    except ImportError:
        console.print("[red]Error:[/red] FastAPI not installed.")
        console.print("[dim]Run: pip install -e '.[server]'[/dim]")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
