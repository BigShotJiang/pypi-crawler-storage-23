# Third-party packages
import numpy as np

# Internal modules
from detquantlib.converters.definitions import EnergyUnits
from detquantlib.converters.helpers import convert_unit_same_cat

# Specify functions to expose
__all__ = ["convert_price", "flag_cents"]


def convert_price(
    price_in: float | np.ndarray,
    currency_in: str,
    unit_in: str,
    currency_out: str,
    unit_out: str,
    commodity_category: str,
) -> float | np.ndarray:
    """
    Converts a price from a given currency and volume unit to another.

    Args:
        price_in: Price
        currency_in: Currency of input price
        unit_in: Volume unit of current price
        currency_out: Currency of output price
        unit_out: Volume unit of output price
        commodity_category: Commodity category

    Returns:
        Converted price

    Raises:
        ValueError: Raises an error if the commodity category is not supported.
        ValueError: Raises an error if the currency conversion is not supported.
    """
    # Split currency and cents indicator
    currency_pre_in, is_cent_in = flag_cents(currency_in)
    currency_pre_out, is_cent_out = flag_cents(currency_out)

    # Get unit converters
    match commodity_category.lower():
        case "energy":
            conversions = EnergyUnits.CONVERSIONS
        case _:
            raise ValueError(f"Commodity category '{commodity_category}' is not supported.")

    # 1. Convert price based on currency
    if currency_pre_in.lower() != currency_pre_out.lower():
        raise ValueError(
            f"Price conversion from currency prefix '{currency_pre_in}' to currency prefix "
            f"'{currency_pre_out}' is not supported."
        )

    # 2. Convert price based on units
    unit_factor = convert_unit_same_cat(
        conversions=conversions, value_in=1, unit_in=unit_in, unit_out=unit_out
    )
    price_out = price_in / unit_factor

    # 3. Convert price based on cents indicators
    if is_cent_in and not is_cent_out:
        price_out /= 100
    elif not is_cent_in and is_cent_out:
        price_out *= 100

    return price_out


def flag_cents(currency_str: str) -> (str, bool):
    """
    Checks if the input currency is expressed in cents or not.

    Args:
        currency_str: Currency string (e.g. "EUR", "EUR_CENTS")

    Returns:
        tuple:
            - Currency, excluding cents flag (e.g. "EUR")
            - Cents flag, given as Boolean

    Raises:
        ValueError: Raises an error if the suffix of the currency string is not recognized.
        ValueError: Raises an error if the currency string could not be parsed.
    """
    # Split currency and cents flag
    currency_list = currency_str.split("_")

    currency = currency_list[0]
    if len(currency_list) == 1:
        is_cent = False
    elif len(currency_list) == 2:
        if currency_list[1].lower() == "cents":
            is_cent = True
        else:
            raise ValueError(
                f"Suffix '{currency_list[1]}' of currency string '{currency_str}' not recognized "
                f"as valid cents indicator."
            )
    else:
        raise ValueError(
            f"Currency string '{currency_str}' could not be parsed into currency and cents "
            f"indicator."
        )

    return currency, is_cent
