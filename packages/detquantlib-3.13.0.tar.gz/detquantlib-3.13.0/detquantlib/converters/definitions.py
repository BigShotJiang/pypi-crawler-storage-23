class PowerUnits:
    """A class that contains hard-coded information about power units."""

    CONVERSIONS = [
        {"unit": "W", "value_in_base_unit": 1},
        {"unit": "kW", "value_in_base_unit": 1e3},
        {"unit": "MW", "value_in_base_unit": 1e6},
        {"unit": "GW", "value_in_base_unit": 1e9},
        {"unit": "TW", "value_in_base_unit": 1e12},
        {"unit": "MJ/s", "value_in_base_unit": 1e6},
    ]


class EnergyUnits:
    """A class that contains hard-coded information about energy units."""

    CONVERSIONS = [
        {"unit": "Wh", "value_in_base_unit": 1},
        {"unit": "kWh", "value_in_base_unit": 1e3},
        {"unit": "MWh", "value_in_base_unit": 1e6},
        {"unit": "GWh", "value_in_base_unit": 1e9},
        {"unit": "TWh", "value_in_base_unit": 1e12},
        {"unit": "MJ", "value_in_base_unit": 1e6 / 3600},
    ]
