# Python built-in packages
import math
from datetime import datetime, time
from typing import Literal

# Third-party packages
import pandas as pd
from dateutil.relativedelta import *

# Internal modules
from detquantlib.dates import calc_months_diff, count_nr_hours
from detquantlib.utils import list_to_str

# Specify functions to expose
__all__ = [
    "convert_delivery_start_date_to_maturity",
    "convert_maturity_to_delivery_start_date",
    "tenor_to_pd_offset_alias",
    "tenor_to_nr_hours",
]


def tenor_to_pd_offset_alias(tenor: str) -> str:
    """A short helper function mapping a product tenor to the corresponding pandas offset alias."""
    tenor = tenor.upper()
    mapper = dict(QUARTERHOUR="15min", HALFHOUR="30min", HOUR="h", DAY="D", WEEK="W")
    if tenor not in mapper.keys():
        tenors_str = list_to_str(list(mapper.keys()))
        raise ValueError(f"Input tenor '{tenor}' is not supported. Accepted values: {tenors_str}.")
    return mapper[tenor]


def tenor_to_nr_hours(
    tenor: str, delivery_start: datetime = None, delivery_end: datetime = None
) -> float:
    """
    Counts the number of hours in a given tenor.

    Args:
        tenor: Tenor
        delivery_start: Delivery start date (only used if tenor > 1 hour, to account for DST
            switches)
        delivery_end: Delivery end date (only used if tenor > 1 hour, to account for DST switches)

    Returns:
        Number of hours in tenor

    Raises:
        ValueError: Raises an error if the tenor delivery period is flexible and delivery dates
            are not provided.
        ValueError: Raises an error if he input tenor is not supported.
    """
    tenor = tenor.upper()
    if tenor == "QUARTERHOUR":
        nr_hours = 0.25
    elif tenor == "HALFHOUR":
        nr_hours = 0.5
    elif tenor == "HOUR":
        nr_hours = 1.0
    elif tenor in ["DAY", "WEEK", "WEEKEND", "MONTH", "QUARTER", "YEAR"]:
        if delivery_start and delivery_end:
            nr_hours = count_nr_hours(delivery_start, delivery_end)
        else:
            raise ValueError(
                f"Missing input(s) 'delivery_start' and/or 'delivery_end'. They must be provided "
                f"for tenor '{tenor}', to account for DST switches and leap years."
            )
    else:
        raise ValueError(f"Input tenor '{tenor}' is not supported.")
    return nr_hours


def convert_delivery_start_date_to_maturity(
    trading_date: datetime,
    delivery_start_date: datetime,
    product: Literal["day", "weekend", "week", "month", "quarter", "year"],
) -> int:
    """
    Calculates the number of maturities between the input trading date and the input delivery
    date, based on the input product type.

    Args:
        trading_date: Trading date
        delivery_start_date: Delivery start date
        product: Product type (e.g. "month", "quarter", "year")

    Returns:
        Product maturity

    Raises:
        ValueError: Raises an error when the input product type is not recognized
    """
    # Make input product string lower case only
    product = product.lower()

    # Set trading date and delivery date to midnight
    trading_date = datetime.combine(trading_date, time())
    delivery_start_date = datetime.combine(delivery_start_date, time())

    if product == "day":
        maturity = (delivery_start_date - trading_date).days

    elif product == "week":
        maturity = math.ceil((delivery_start_date - trading_date).days / 7)

    elif product == "weekend":
        maturity = math.ceil((delivery_start_date - trading_date).days / 7)

    elif product == "month":
        maturity = calc_months_diff(
            start_date=trading_date,
            end_date=delivery_start_date,
            diff_method="month",
        )

    elif product == "quarter":
        trading_quarter_start_date = convert_maturity_to_delivery_start_date(
            trading_date=trading_date, maturity=0, product="quarter"
        )

        delivery_quarter_start_date = convert_maturity_to_delivery_start_date(
            trading_date=delivery_start_date, maturity=0, product="quarter"
        )

        months_diff = calc_months_diff(
            start_date=trading_quarter_start_date,
            end_date=delivery_quarter_start_date,
            diff_method="month",
        )
        maturity = months_diff / 3

    elif product == "year":
        maturity = delivery_start_date.year - trading_date.year

    else:
        raise ValueError("Invalid input product name.")

    return maturity


def convert_maturity_to_delivery_start_date(
    trading_date: datetime,
    maturity: int,
    product: Literal["month", "quarter", "year"],
) -> datetime:
    """
    Calculates the delivery start date of the input product, based on the input trading date
    and input maturity.

    Args:
        trading_date: Trading date
        maturity: Product maturity
        product: Product type (e.g. "month", "quarter", "year")

    Returns:
        Delivery start date

    Raises:
        ValueError: Raises an error when the input product type is not recognized
    """

    # Make input product string lower case only
    product = product.lower()

    if product == "month":
        month_start_date = datetime(trading_date.year, trading_date.month, 1)
        delivery_start_date = month_start_date + relativedelta(months=maturity)

    elif product == "quarter":
        quarter = pd.Timestamp(trading_date).quarter
        year_start_date = datetime(trading_date.year, 1, 1)
        quarter_start_date = year_start_date + relativedelta(months=((quarter - 1) * 3))
        delivery_start_date = quarter_start_date + relativedelta(months=(maturity * 3))

    elif product == "year":
        year_start_date = datetime(trading_date.year, 1, 1)
        delivery_start_date = year_start_date + relativedelta(years=maturity)

    else:
        raise ValueError("Invalid input product name.")

    return delivery_start_date
