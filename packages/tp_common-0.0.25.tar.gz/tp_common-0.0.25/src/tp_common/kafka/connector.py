from __future__ import annotations

import logging
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse

from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
from confluent_kafka import Consumer, KafkaError, Producer


class KafkaConnectionError(ValueError):
    """Недостаточно данных в URL для подключения к Kafka."""


class KafkaConnector:
    """Подключение к Kafka по URL: plaintext://user:pass@host:9094?security_protocol=&sasl_mechanism=..."""

    DEFAULT_SCHEME = "plaintext"
    DEFAULT_PORT = 9092
    DEFAULT_SASL_MECHANISM = "SCRAM-SHA-256"

    def __init__(
        self,
        url: str,
        *,
        rdkafka_log_level: int = 0,
        logger: logging.Logger | None = None,
    ) -> None:
        """
        url: URL подключения (plaintext://user:pass@host:9094?security_protocol=&sasl_mechanism=...).
        rdkafka_log_level: Уровень логов librdkafka (0=выкл, 1=critical, 2=error, 3=warning, 4=notice, 5=info, 6=debug, 7=trace).
            По умолчанию None — логи rdkafka не переопределяются.
        logger: Если задан, логи rdkafka перенаправляются в этот логгер (через log_cb), а не в stderr.
            Уровень сообщений можно дополнительно фильтровать через logger.setLevel().
        """
        self._parse_url(url)
        self.rdkafka_log_level = rdkafka_log_level
        self._logger = logger

    def set_logger(self, logger: logging.Logger | None) -> None:
        """Устанавливает логгер для log_cb и error_cb при создании consumer/producer."""
        self._logger = logger

    def get_consumer(
        self,
        group_id: str,
        auto_offset_reset: str = "earliest",
        enable_auto_commit: bool = False,
        session_timeout_ms: int = 30_000,
        max_poll_interval_ms: int = 300_000,
        overrides: dict[str, Any] | None = None,
    ) -> Consumer:
        """
        Создаёт Kafka Consumer с параметрами коннектора и переданными опциями.

        group_id: Идентификатор consumer group.
        auto_offset_reset: Откуда начать читать при отсутствии offset ("earliest" или "latest").
        enable_auto_commit: Включить ли авто-коммит offset.
        session_timeout_ms: Таймаут сессии (мс).
        max_poll_interval_ms: Макс. интервал между вызовами poll (мс).
        overrides: Дополнительные или переопределяющие настройки для конфига consumer.
        """
        cfg: dict[str, Any] = {
            "bootstrap.servers": self.bootstrap_servers,
            "group.id": group_id,
            "auto.offset.reset": auto_offset_reset,
            "enable.auto.commit": enable_auto_commit,
            "session.timeout.ms": session_timeout_ms,
            "max.poll.interval.ms": max_poll_interval_ms,
        }
        self._apply_common_config(cfg, overrides)
        return Consumer(cfg)

    def get_producer(
        self,
        acks: str = "all",
        produce_retries: int = 3,
        retry_backoff_ms: int = 100,
        overrides: dict[str, Any] | None = None,
    ) -> Producer:
        """
        Создаёт Kafka Producer с параметрами коннектора и переданными опциями.

        acks: Уровень подтверждения записи ("all", "1", "0").
        produce_retries: Число повторов при ошибке отправки.
        retry_backoff_ms: Задержка между повторами (мс).
        overrides: Дополнительные или переопределяющие настройки для конфига producer.
        """
        cfg: dict[str, Any] = {
            "bootstrap.servers": self.bootstrap_servers,
            "acks": acks,
            "retries": produce_retries,
            "retry.backoff.ms": retry_backoff_ms,
        }
        self._apply_common_config(cfg, overrides)
        return Producer(cfg)

    def _get_aiokafka_common_kwargs(self) -> dict[str, Any]:
        """Общие параметры подключения для aiokafka (consumer и producer) в стиле aiokafka (snake_case)."""
        kwargs: dict[str, Any] = {
            "bootstrap_servers": self.bootstrap_servers,
            "security_protocol": self.security_protocol or "PLAINTEXT",
        }
        if self.security_protocol and "SASL" in self.security_protocol:
            if self.sasl_mechanism is not None:
                kwargs["sasl_mechanism"] = self.sasl_mechanism
            if self.sasl_username is not None:
                kwargs["sasl_plain_username"] = self.sasl_username
            if self.sasl_password is not None:
                kwargs["sasl_plain_password"] = self.sasl_password
        return kwargs

    def get_consumer_config(
        self,
        group_id: str,
        *,
        auto_offset_reset: str = "earliest",
        enable_auto_commit: bool = False,
        session_timeout_ms: int = 30_000,
        max_poll_interval_ms: int = 300_000,
        overrides: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Возвращает словарь конфигурации для AIOKafkaConsumer (ключи в стиле aiokafka: snake_case).

        Не создаёт confluent-клиентов. Используется для async consumer или для передачи в AIOKafkaConsumer(**config).
        """
        cfg: dict[str, Any] = {
            **self._get_aiokafka_common_kwargs(),
            "group_id": group_id,
            "auto_offset_reset": auto_offset_reset,
            "enable_auto_commit": enable_auto_commit,
            "session_timeout_ms": session_timeout_ms,
            "max_poll_interval_ms": max_poll_interval_ms,
        }
        if overrides:
            cfg.update(overrides)
        return cfg

    def get_producer_config(
        self,
        *,
        acks: str = "all",
        retry_backoff_ms: int = 100,
        overrides: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Возвращает словарь конфигурации для AIOKafkaProducer (ключи в стиле aiokafka: snake_case).

        Не создаёт confluent-клиентов.
        """
        cfg: dict[str, Any] = {
            **self._get_aiokafka_common_kwargs(),
            "acks": acks,
            "retry_backoff_ms": retry_backoff_ms,
        }
        if overrides:
            cfg.update(overrides)
        return cfg

    def get_async_consumer(
        self,
        group_id: str,
        *,
        auto_offset_reset: str = "earliest",
        enable_auto_commit: bool = False,
        session_timeout_ms: int = 30_000,
        max_poll_interval_ms: int = 300_000,
        overrides: dict[str, Any] | None = None,
    ) -> AIOKafkaConsumer:
        """
        Создаёт и возвращает AIOKafkaConsumer. start() не вызывается — запуск в сервисе.
        """
        return AIOKafkaConsumer(
            **self.get_consumer_config(
                group_id,
                auto_offset_reset=auto_offset_reset,
                enable_auto_commit=enable_auto_commit,
                session_timeout_ms=session_timeout_ms,
                max_poll_interval_ms=max_poll_interval_ms,
                overrides=overrides,
            )
        )

    def get_async_producer(
        self,
        *,
        acks: str = "all",
        retry_backoff_ms: int = 100,
        overrides: dict[str, Any] | None = None,
    ) -> AIOKafkaProducer:
        """Создаёт и возвращает AIOKafkaProducer."""
        return AIOKafkaProducer(
            **self.get_producer_config(
                acks=acks,
                retry_backoff_ms=retry_backoff_ms,
                overrides=overrides,
            )
        )

    def _parse_url(self, url: str) -> None:
        """
        Разбирает URL и записывает параметры подключения в self.

        Формат: plaintext://user:pass@host:9094?security_protocol=&sasl_mechanism=PLAIN
        Схема задаёт тип: plaintext, sasl_plaintext, ssl, sasl_ssl.
        Query может переопределить security_protocol и sasl_mechanism.

        Выбрасывает KafkaConnectionError, если не хватает минимальных данных.
        """
        if "://" not in url:
            url = f"{self.DEFAULT_SCHEME}://{url}"
        self._url = url
        parsed = urlparse(url)
        host = (parsed.hostname or "").strip()
        port = parsed.port if parsed.port is not None else self.DEFAULT_PORT

        # urlparse в ряде версий даёт пустой netloc/hostname при схеме с подчёркиванием — берём из URL
        authority = self._authority_from_url(url)
        used_authority_for_host = False
        if not host and authority:
            host, port = self._parse_netloc_host_port(authority)
            used_authority_for_host = True
        if not host:
            raise KafkaConnectionError(f"В URL отсутствует хост: {url!r}")
        if port <= 0 or port > 65535:
            raise KafkaConnectionError(f"Недопустимый порт в URL: {port}")

        self.bootstrap_servers = f"{host}:{port}"
        self.sasl_username = unquote(parsed.username) if parsed.username else None
        self.sasl_password = unquote(parsed.password) if parsed.password else None
        if (self.sasl_username is None or self.sasl_password is None) and authority:
            user, passwd = self._parse_userinfo_from_authority(authority)
            if self.sasl_username is None:
                self.sasl_username = user
            if self.sasl_password is None:
                self.sasl_password = passwd

        scheme = (parsed.scheme or "").lower()
        if "://" in url and (not scheme or used_authority_for_host):
            scheme = url.split("://", 1)[0].lower()
        if scheme in ("sasl_plaintext", "sasl_ssl") and not (
            self.sasl_username and self.sasl_password
        ):
            raise KafkaConnectionError(
                f"Для схемы {scheme!r} в URL должны быть указаны user и password: {url!r}"
            )

        if scheme == "sasl_plaintext":
            security_from_scheme = "SASL_PLAINTEXT"
        elif scheme == "ssl":
            security_from_scheme = "SSL"
        elif scheme == "sasl_ssl":
            security_from_scheme = "SASL_SSL"
        else:
            security_from_scheme = "PLAINTEXT"

        query = parse_qs(parsed.query, keep_blank_values=True)
        security_from_query = self._first_query_param(query, "security_protocol")
        raw_security = (
            security_from_query.strip().upper() or security_from_scheme
            if security_from_query is not None
            else security_from_scheme
        )
        self.security_protocol = raw_security

        # SASL mechanism устанавливаем только для SASL-протоколов
        if "SASL" in self.security_protocol:
            raw_sasl = (
                self._first_query_param(query, "sasl_mechanism")
                or self.DEFAULT_SASL_MECHANISM
            )
            self.sasl_mechanism = raw_sasl.strip().upper() if raw_sasl else None

    def _apply_common_config(
        self, cfg: dict[str, Any], overrides: dict[str, Any] | None = None
    ) -> None:
        if self.security_protocol is not None:
            cfg["security.protocol"] = self.security_protocol

        if self.rdkafka_log_level is not None:
            cfg["log_level"] = self.rdkafka_log_level

        if self._logger is not None and (
            self.rdkafka_log_level is None or self.rdkafka_log_level > 0
        ):
            cfg["log_cb"] = self._make_log_cb()

        # Ошибки подключения/SASL приходят асинхронно в error_cb, а не в log_cb; без error_cb при log_level=0 их не видно
        cfg["error_cb"] = self._make_error_cb()

        # SASL параметры применяем только для SASL-протоколов
        if self.security_protocol and "SASL" in self.security_protocol:
            if self.sasl_mechanism is not None:
                cfg["sasl.mechanism"] = self.sasl_mechanism
            if self.sasl_username is not None:
                cfg["sasl.username"] = self.sasl_username
            if self.sasl_password is not None:
                cfg["sasl.password"] = self.sasl_password

        if overrides:
            cfg.update(overrides)

    def _make_log_cb(self) -> Any:
        """Возвращает callback для log_cb: перенаправляет логи rdkafka в self._logger."""
        log = self._logger if self._logger is not None else logging.getLogger(__name__)

        def log_cb(level: int, fac: str, buf: str) -> None:
            # Уровни librdkafka: 0=emerg, 1=alert, 2=crit, 3=err, 4=warning, 5=notice, 6=info, 7=debug
            msg = f"[{fac}] {buf}" if fac else buf
            if level <= 3:
                log.error("%s", msg)
            elif level == 4:
                log.warning("%s", msg)
            elif level <= 6:
                log.info("%s", msg)
            else:
                log.debug("%s", msg)

        return log_cb

    def _make_error_cb(self) -> Any:
        """Возвращает callback для error_cb: логирует ошибки rdkafka (подключение, SASL и т.д.)."""
        log = self._logger if self._logger is not None else logging.getLogger(__name__)

        def error_cb(err: KafkaError) -> None:
            # Ошибки подключения, SASL и т.д. приходят сюда асинхронно
            code = (
                err.code()
                if callable(getattr(err, "code", None))
                else getattr(err, "code", None)
            )
            msg = str(err) if err else repr(code)
            log.error("Kafka error: %s (code=%s)", msg, code)

        return error_cb

    @staticmethod
    def _authority_from_url(url: str) -> str:
        """Часть URL после «://» до первого «/» или «?» (user:pass@host:port или host:port)."""
        idx = url.find("://")
        if idx < 0:
            return ""
        rest = url[idx + 3 :]
        for sep in ("/", "?"):
            p = rest.find(sep)
            if p >= 0:
                rest = rest[:p]
        return rest.strip()

    @staticmethod
    def _parse_userinfo_from_authority(authority: str) -> tuple[str | None, str | None]:
        """Из authority вида user:pass@host:port возвращает (username, password) или (None, None)."""
        at = authority.rfind("@")
        if at < 0:
            return (None, None)
        userinfo = authority[:at]
        if ":" not in userinfo:
            return (unquote(userinfo) if userinfo else None, None)
        colon = userinfo.find(":")
        return (unquote(userinfo[:colon]), unquote(userinfo[colon + 1 :]))

    @staticmethod
    def _parse_netloc_host_port(netloc: str) -> tuple[str, int]:
        """
        Извлекает host и port из netloc (например user:pass@192.168.81.61:9094).
        Возвращает (host, port); порт по умолчанию 9092.
        """
        # Часть после последнего @ — host:port (или host)
        at_idx = netloc.rfind("@")
        host_port = netloc[at_idx + 1 :] if at_idx >= 0 else netloc
        host_port = host_port.strip()
        if not host_port:
            return ("", KafkaConnector.DEFAULT_PORT)
        # Порт: после последнего ":" (учёт IPv6 [::1]:9094)
        if host_port.endswith("]"):
            # IPv6 без порта: [::1]
            return (host_port, KafkaConnector.DEFAULT_PORT)
        colon_port = host_port.rfind(":")
        if colon_port <= 0:
            return (host_port, KafkaConnector.DEFAULT_PORT)
        maybe_port = host_port[colon_port + 1 :]
        if maybe_port.isdigit():
            return (host_port[:colon_port].strip(), int(maybe_port))
        return (host_port, KafkaConnector.DEFAULT_PORT)

    @staticmethod
    def _first_query_param(params: dict[str, list[str]], key: str) -> str | None:
        values = params.get(key)
        if not values:
            return None
        raw = values[0]
        return unquote(raw) if raw else None
