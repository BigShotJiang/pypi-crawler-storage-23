from __future__ import annotations

import argparse
from pathlib import Path

from . import sync_ci_cd_configs


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Синхронизация CI/CD-конфигов (ruff, mypy, pyright, pre-commit) "
            "и dev-зависимостей Poetry из tp-common в целевой проект."
        ),
    )
    parser.add_argument(
        "-t",
        "--target",
        type=Path,
        default=Path("."),
        help=(
            "Корень целевого проекта, в который нужно подтянуть конфиги. "
            "По умолчанию — текущая директория."
        ),
    )

    args = parser.parse_args()
    sync_ci_cd_configs(args.target)


if __name__ == "__main__":
    main()
