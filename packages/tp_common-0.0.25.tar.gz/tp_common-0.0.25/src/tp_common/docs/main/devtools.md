## tp_common.devtools

Инструменты для подтягивания общих CI/CD-конфигураций из `tp-common`
в другие Python-проекты.

### Что делает скрипт

- **Копирует конфиги** из репозитория `tp-common` в целевой проект:
  - `ruff.toml`
  - `mypy.ini`
  - `pyrightconfig.json`
  - `.pre-commit-config.yaml`
- **Синхронизирует dev-зависимости** в `pyproject.toml` целевого проекта
  в секции `[tool.poetry.group.dev.dependencies]`, выравнивая версии с `tp-common`:
  - `ruff`
  - `pre-commit`
  - `pylint`
  - `mypy`
  - `pyright`
  - `black`

Версии берутся из `pyproject.toml` репозитория `tp-common`.

### Использование в CI/CD

1. **Убедиться, что репозиторий `tp-common` доступен** в пайплайне:
   - как git-сабмодуль;
   - или как отдельный checkout рядом с проектом.
2. **Запустить скрипт из корня целевого проекта**, указав путь к нему:

```bash
python -m tp_common.devtools --target .
```

или (эквивалентно для текущей директории):

```bash
python -m tp_common.devtools
```

Скрипт ожидает, что:

- в корне `tp-common` есть файлы:
  - `pyproject.toml`
  - `ruff.toml`
  - `mypy.ini`
  - `pyrightconfig.json`
  - `.pre-commit-config.yaml`
- в целевом проекте существует `pyproject.toml`.

### Поведение при обновлениях

- **Конфигурационные файлы** в целевом проекте будут **перезаписаны**
  актуальными версиями из `tp-common`.
- В секции `[tool.poetry.group.dev.dependencies]`:
  - для ключей `ruff`, `pre-commit`, `pylint`, `mypy`, `pyright`, `black`
    строки будут **обновлены** до версий из `tp-common`;
  - если секции не было — она будет **добавлена**;
  - остальные dev-зависимости (если есть) **сохраняются как есть**.

