"""Онлайновые (интеграционные) тесты для BaseEvent — с реальным Kafka.

Запуск:
  pytest -m online -v
  KAFKA_URL=... pytest -m online -v

Без KAFKA_URL тесты пропускаются (skip).

PyCharm: если видите "Ran 0 tests" / "Empty suite" — включите pytest как раннер:
  Settings → Tools → Python Integrated Tools → Testing → Default test runner = pytest
"""

from __future__ import annotations

import json
import logging
from datetime import datetime

import pytest

from tp_common.event_service.service import event_type_mapping_for
from tp_common.event_service.tests.conftest import (
    User,
    UserEvent,
    UserEventMessage,
    UserEventService,
)
from tp_common.kafka.connector import KafkaConnector

pytestmark = pytest.mark.online


# --- Топик и конфигурация ---


def test_topic_name(user_event_service: UserEventService) -> None:
    """Имя топика формируется как events.{SERVICE_NAME}.public.{EVENT_GROUP}."""
    assert user_event_service._topic() == "events.postgres.public.users"


# --- Подписка и контекст ---


def test_subscription_context_subscribes_and_closes(
    user_event_service: UserEventService,
) -> None:
    """Контекст subscription() подписывается при входе, отписывается и закрывает при выходе."""
    assert user_event_service._consumer is None
    with user_event_service.subscription():
        assert user_event_service._consumer is not None
    assert user_event_service._consumer is None
    assert user_event_service._producer is None


def test_sub_unsub(user_event_service: UserEventService) -> None:
    """sub() создаёт consumer и подписывается, unsub() отписывается."""
    user_event_service.sub()
    assert user_event_service._consumer is not None
    user_event_service.unsub()
    user_event_service.close()
    assert user_event_service._consumer is None


def test_close_cleans_consumer_and_producer(
    user_event_service: UserEventService,
) -> None:
    """close() обнуляет consumer и producer."""
    user_event_service.sub()
    user_event_service._get_producer()
    assert user_event_service._consumer is not None
    assert user_event_service._producer is not None
    user_event_service.close()
    assert user_event_service._consumer is None
    assert user_event_service._producer is None


# --- Парсинг сообщений (без Kafka) ---


def test_message_from_value_dict(user_event_service: UserEventService) -> None:
    """message_from_value принимает dict и возвращает типизированное сообщение."""
    now = datetime(2025, 2, 6, 12, 0, 0).isoformat()
    payload = {
        "before": None,
        "after": {
            "id": 1,
            "name": "Test",
            "description": None,
            "is_active": True,
            "created_at": now,
            "updated_at": now,
        },
        "event": "create",
    }
    msg = user_event_service.message_from_value(payload)
    assert isinstance(msg, user_event_service.MESSAGE_CLASS)
    assert msg.event == UserEvent.CREATE
    assert msg.before is None
    assert msg.after is not None
    assert msg.after.id == 1
    assert msg.after.name == "Test"


def test_message_from_value_bytes(user_event_service: UserEventService) -> None:
    """message_from_value принимает bytes (JSON) и возвращает типизированное сообщение."""
    now = datetime(2025, 2, 6, 12, 0, 0).isoformat()
    payload = {
        "before": None,
        "after": {
            "id": 2,
            "name": "Bytes",
            "description": None,
            "is_active": False,
            "created_at": now,
            "updated_at": None,
        },
        "event": "c",
    }
    value = json.dumps(payload).encode("utf-8")
    msg = user_event_service.message_from_value(value)
    assert msg.event == UserEvent.CREATE
    assert msg.after is not None
    assert msg.after.id == 2
    assert msg.after.name == "Bytes"


# --- Фильтр subscribe_to ---


def test_should_process_event_no_filter(user_event_service: UserEventService) -> None:
    """Без subscribe_to любое событие подходит."""
    assert user_event_service._should_process_event(UserEvent.CREATE) is True
    assert user_event_service._should_process_event(UserEvent.UPDATE) is True
    assert user_event_service._should_process_event(UserEvent.CHANGE_NAME) is True


def test_should_process_event_with_filter(
    user_event_service_subscribe_create: UserEventService,
) -> None:
    """С subscribe_to=[CREATE] только CREATE подходит."""
    svc = user_event_service_subscribe_create
    assert svc._should_process_event(UserEvent.CREATE) is True
    assert svc._should_process_event(UserEvent.UPDATE) is False
    assert svc._should_process_event(UserEvent.CHANGE_NAME) is False
    assert svc._should_process_event(None) is False


# --- Маппинг типов событий ---


def test_event_type_mapping_for() -> None:
    """event_type_mapping_for возвращает базовые типы и значения enum."""
    mapping = event_type_mapping_for(UserEvent)
    assert mapping["c"] == "create"
    assert mapping["u"] == "update"
    assert mapping["create"] == "create"
    assert mapping["change_name"] == "change_name"


# --- Publish + Pop (реальный Kafka) ---


def test_publish_then_pop_same_service(
    user_event_service: UserEventService,
) -> None:
    """Публикация сообщения и чтение его же сервисом (другой consumer group читает топик)."""
    now = datetime(2025, 2, 6, 12, 0, 0)
    message = UserEventMessage(
        before=None,
        after=User(
            id=100,
            name="OnlineTest",
            description=None,
            is_active=True,
            created_at=now,
            updated_at=now,
        ),
        event=UserEvent.CREATE,
    )
    # Сначала публикуем
    user_event_service.publish(message, flush_timeout=3.0)
    # Подписываемся и читаем одно сообщение (можем получить наше или другое из топика)
    with user_event_service.subscription():
        with user_event_service.pop(timeout=5.0) as received:
            # В онлайне можем получить любое сообщение из топика; проверяем хотя бы тип
            if received is not None:
                assert isinstance(received, user_event_service.MESSAGE_CLASS)
                assert received.event in (
                    UserEvent.CREATE,
                    UserEvent.UPDATE,
                    UserEvent.DELETE,
                    UserEvent.CHANGE_NAME,
                )


def test_pop_context_returns_message_or_none(
    user_event_service: UserEventService,
) -> None:
    """Контекст pop() возвращает сообщение или None при таймауте."""
    with user_event_service.subscription():
        with user_event_service.pop(timeout=3.0) as msg:
            # За 2 сек может прийти сообщение или нет
            assert msg is None or isinstance(msg, user_event_service.MESSAGE_CLASS)


# --- Валидация коннектора/consumer_group ---


def test_get_consumer_requires_consumer_group(
    kafka_connector: KafkaConnector,
    event_service_logger: logging.Logger,
) -> None:
    """_get_consumer() без consumer_group поднимает ValueError."""
    svc = UserEventService(
        connector=kafka_connector,
        log=event_service_logger,
        consumer_group="",
    )
    with pytest.raises(ValueError, match="consumer_group должен быть непустой"):
        svc._get_consumer()
