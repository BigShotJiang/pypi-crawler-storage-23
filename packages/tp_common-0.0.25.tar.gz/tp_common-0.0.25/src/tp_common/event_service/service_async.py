import asyncio
import enum
import inspect
import logging
from collections.abc import AsyncGenerator, Awaitable, Callable
from contextlib import asynccontextmanager, suppress
from typing import Any, ClassVar, Literal, TypeVar, cast

from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
from pydantic import ValidationError

from tp_common.decorators.decorator_retry_async import retry_async
from tp_common.event_service.exceptions import EventMessageParseError
from tp_common.event_service.message_transformer import EventMessageTransformer
from tp_common.event_service.schemas import BaseEventMessage
from tp_common.kafka.connector import KafkaConnector

logger = logging.getLogger(__name__)

MessageT = TypeVar("MessageT", bound=BaseEventMessage)
EventEnumT = TypeVar("EventEnumT", bound=enum.Enum)

BASE_EVENT_TYPE_MAPPING: dict[str, str] = {
    "c": "create",
    "u": "update",
    "d": "delete",
    "r": "snapshot",
    "create": "create",
    "update": "update",
    "delete": "delete",
    "snapshot": "snapshot",
}


def event_type_mapping_for(enum_cls: type[enum.Enum]) -> dict[str, str]:
    """
    Маппинг для преобразования строки в член enum в сервисе.
    Базовые ключи (c, u, d, r, create, ...) + все значения enum_cls (для своих типов вроде change_name).
    """
    mapping = dict(BASE_EVENT_TYPE_MAPPING)
    for member in enum_cls:
        v = member.value if isinstance(member.value, str) else str(member.value)
        mapping[v.lower()] = v
    return mapping


class _AsyncPopMessage:
    """Async контекст: при входе — pop(); при успешном выходе — commit()."""

    __slots__ = ("_event", "_timeout", "_message")

    def __init__(self, event: "BaseEventAsync[Any, Any]", timeout: float) -> None:
        self._event = event
        self._timeout = timeout
        self._message: Any = None

    async def __aenter__(self) -> Any:
        self._message = await self._event._pop(timeout=self._timeout)
        return self._message

    async def __aexit__(
        self, exc_type: Any, exc_val: Any, exc_tb: Any
    ) -> Literal[False]:
        if exc_type is None and self._message is not None:
            await self._event._commit()
        return False


class BaseEventAsync[MessageT: BaseEventMessage, EventEnumT: enum.Enum]:
    SERVICE_NAME: ClassVar[str]
    EVENT_GROUP: ClassVar[enum.Enum]
    MESSAGE_CLASS: ClassVar[type[BaseEventMessage]]
    EVENT_TYPE_CLASS: ClassVar[type[enum.Enum]]

    _REQUIRED_EVENT_TYPES: ClassVar[dict[str, str]] = {
        "CREATE": "create",
        "UPDATE": "update",
        "DELETE": "delete",
    }

    def __init__(
        self,
        connector: KafkaConnector,
        log: logging.Logger,
        consumer_group: str | None = None,
        subscribe_to: list[EventEnumT] | None = None,
        retry_enabled: bool = True,
        schema_alert_interval_seconds: float = 600,
        schema_alert_callback: (
            Callable[[str], None] | Callable[[str], Awaitable[None]] | None
        ) = None,
    ) -> None:
        """Инициализация асинхронного сервиса событий с подключением к Kafka.

        subscribe_to: если задан — из топика возвращаются только сообщения с типами
            из этого списка (например [UserEvent.CREATE, UserEvent.UPDATE]).
            Остальные сообщения коммитятся и пропускаются.
        retry_enabled: при True - повтор при ошибках Kafka/сети.
        schema_alert_interval_seconds: интервал повторных Critical-алертов при несовпадении схем (по умолчанию 10 мин).
        schema_alert_callback: опциональный callback при алерте (может быть sync или async).
        """
        self.connector = connector
        self.consumer_group = consumer_group
        self.subscribe_to = subscribe_to

        self._consumer: AIOKafkaConsumer | None = None
        self._producer: AIOKafkaProducer | None = None

        self._is_auto_commit: bool = False
        self._last_message: Any | None = None

        self._retry_enabled = retry_enabled
        self._schema_alert_interval_seconds = schema_alert_interval_seconds
        self._schema_alert_callback = schema_alert_callback

        self.logger = log

        self._message_transformer = EventMessageTransformer(
            message_class=cast(type[MessageT], self.__class__.MESSAGE_CLASS),
            event_type_class=cast(type[EventEnumT], self.__class__.EVENT_TYPE_CLASS),
            logger=self.logger,
            service_name=self.__class__.__name__,
        )

    @property
    def retry_enabled(self) -> bool:
        return self._retry_enabled

    # --- Consumer / подписка ---

    def enable_auto_commit(self) -> None:
        """Включает автоматический commit после каждого прочитанного сообщения."""
        self._is_auto_commit = True

    def _topic(self) -> str:
        """Возвращает имя топика для данного сервиса и группы событий."""
        return f"events.{self.SERVICE_NAME}.public.{self.EVENT_GROUP.value}"

    @retry_async(
        error_message="Ошибка подписки на топик: {e}",
        start_message="Подписка на топик Kafka",
    )
    async def sub(self) -> None:
        """Подписывается на топик и запускает consumer (с ретраями, если retry_enabled)."""
        consumer = await self._get_consumer()
        consumer.subscribe([self._topic()])
        await consumer.start()

    async def unsub(self) -> None:
        """Отписывается от топика и останавливает consumer (корректный выход из группы)."""
        if self._consumer is not None:
            with suppress(Exception):
                await self._consumer.stop()

    async def close(self) -> None:
        """Закрывает consumer и producer, освобождает соединения."""
        self._last_message = None
        if self._consumer is not None:
            with suppress(Exception):
                await self._consumer.stop()
            self._consumer = None
        if self._producer is not None:
            with suppress(Exception):
                await self._producer.stop()
            self._producer = None

    @asynccontextmanager
    async def subscription(self) -> AsyncGenerator[None]:
        """Async контекст: при входе — подписка, при выходе — отписка и закрытие соединения."""
        await self.sub()
        try:
            yield
        finally:
            await self.unsub()
            await self.close()

    @retry_async(
        start_message="Commit последнего сообщения в Kafka",
        error_message="Ошибка commit в Kafka: {e}",
    )
    async def _commit(self) -> None:
        """Коммитит последнее прочитанное сообщение в Kafka (с ретраями, если retry_enabled)."""
        if self._last_message and self._consumer:
            await self._consumer.commit()

    @retry_async(error_message="Ошибка commit в Kafka: {e}")
    async def _commit_silent(self) -> None:
        """Коммитит без лога старта — для пропущенных по фильтру сообщений и auto_commit."""
        if self._last_message and self._consumer:
            await self._consumer.commit()

    def pop(self, timeout: float = 60) -> "_AsyncPopMessage":
        """Async контекст: при входе — чтение одного сообщения; при успешном выходе — commit()."""
        return _AsyncPopMessage(self, timeout)

    async def publish(
        self,
        message: MessageT,
    ) -> None:
        """Отправляет сообщение в топик.
        При retry_enabled повторяет отправку при ошибках доставки/Kafka.

        Note: В async версии flush происходит автоматически в send_and_wait.
        """
        value = message.model_dump_json().encode("utf-8")
        topic = self._topic()

        producer = await self._get_producer()
        try:
            await producer.send_and_wait(topic, value=value)
            self.logger.debug("Kafka delivered: topic=%s", topic)
        except Exception as e:
            self.logger.error("Kafka delivery error: %s", e)
            raise

    @retry_async(
        start_message="Чтение сообщения из Kafka",
        error_message="Ошибка при чтении из Kafka: {e}",
    )
    async def _pop(self, timeout: float = 60) -> MessageT | None:
        """Читает одно сообщение из топика, удовлетворяющее фильтру.
        Если сообщение не подходит по фильтру — коммитит и читает следующее.
        При ошибке парсинга — останавливает обработку.
        """
        consumer = await self._get_consumer()

        while True:
            try:
                # Получаем сообщение с таймаутом
                msg = await asyncio.wait_for(consumer.getone(), timeout=timeout)
            except TimeoutError:
                continue
            except Exception as e:
                self.logger.warning("Ошибка Kafka при чтении: %s", e)
                continue

            if msg.value is None:
                self.logger.warning("Получено сообщение с пустым value")
                continue

            self._last_message = msg

            if self._is_auto_commit:
                self.logger.debug("_is_auto_commit")
                await self._commit_silent()

            try:
                raw = self._message_transformer.value_to_raw_payload(msg.value)
            except (ValidationError, TypeError, EventMessageParseError):
                self.logger.critical(
                    "Ошибка парсинга сообщения. Останавливаем обработку.",
                    exc_info=True,
                )
                await self.unsub()
                await self.close()
                await self.run_schema_mismatch_alert_loop()
                return None

            event_str = (raw.event or "").strip().lower()
            if event_str in ("r", "snapshot"):
                await self._commit_silent()
                continue

            try:
                parsed = self._message_transformer.build_message(raw)
            except (ValidationError, TypeError, EventMessageParseError):
                self.logger.critical(
                    "Ошибка парсинга сообщения. Останавливаем обработку.",
                    exc_info=True,
                )
                await self.unsub()
                await self.close()
                await self.run_schema_mismatch_alert_loop()
                return None

            if self._should_process_event(parsed.event):
                return parsed

            # Сообщение не подходит по фильтру — коммитим и читаем следующее
            await self._commit_silent()

    # --- Парсинг и сборка сообщений (делегирование в EventMessageTransformer) ---

    def message_from_value(self, value: bytes | str | dict[str, Any]) -> MessageT:
        """Полный пайплайн: value → RawEventPayload → MessageT; при ошибке валидации — исключение."""
        return self._message_transformer.message_from_value(value)

    async def handle_schema_mismatch(self, exc: Exception | None = None) -> None:
        """
        Вызвать при несовпадении схем (ValidationError/TypeError из парсинга).
        Логирует Critical, отписывается, закрывает соединения, затем каждые
        schema_alert_interval_seconds логирует Critical и вызывает schema_alert_callback.
        """
        self.logger.critical(
            "Несовпадение схем. Останавливаем обработку.%s",
            "" if exc is None else f" {exc!s}",
            exc_info=exc is not None,
        )
        await self.unsub()
        await self.close()
        await self.run_schema_mismatch_alert_loop()

    async def run_schema_mismatch_alert_loop(self) -> None:
        """
        После остановки из-за несовпадения схем: каждые schema_alert_interval_seconds
        логирует Critical и вызывает schema_alert_callback (если задан).
        Поддерживает как sync, так и async callback.
        """
        msg = (
            "Схема сообщений не соответствует ожидаемой. "
            "Обработка событий остановлена. Требуется обновление схемы/развёртывание сервиса."
        )
        while True:
            self.logger.critical(msg)
            if self._schema_alert_callback:
                try:
                    if inspect.iscoroutinefunction(self._schema_alert_callback):
                        await self._schema_alert_callback(msg)
                    else:
                        self._schema_alert_callback(msg)
                except Exception as e:
                    self.logger.exception("Ошибка вызова alert_callback: %s", e)
            await asyncio.sleep(self._schema_alert_interval_seconds)

    def _should_process_event(
        self,
        event: EventEnumT | None,
        subscribe_to: list[EventEnumT] | None = None,
    ) -> bool:
        """Проверяет, нужно ли обрабатывать событие по фильтру subscribe_to."""
        effective_subscribe_to = (
            subscribe_to if subscribe_to is not None else self.subscribe_to
        )
        if effective_subscribe_to is None:
            return True
        if event is None:
            return False
        return event in set(effective_subscribe_to)

    # --- Внутренние (Kafka-коннекторы) ---

    async def _get_consumer(self) -> AIOKafkaConsumer:
        """Возвращает async consumer; при первом вызове создаёт через connector."""
        if self.connector is None:
            raise ValueError("connector не задан, невозможно создать consumer")

        if not self.consumer_group or not str(self.consumer_group).strip():
            raise ValueError(
                "consumer_group должен быть непустой строкой для создания consumer"
            )

        if self._consumer is None:
            self.connector.set_logger(self.logger)
            self._consumer = self.connector.get_async_consumer(
                group_id=self.consumer_group
            )
        return self._consumer

    async def _get_producer(self) -> AIOKafkaProducer:
        """Возвращает async producer; при первом вызове создаёт и запускает через connector."""
        if self._producer is None:
            self.connector.set_logger(self.logger)
            self._producer = self.connector.get_async_producer()
            await self._producer.start()
        return self._producer

    # --- Валидация наследников ---

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Проверяет наличие SERVICE_NAME, EVENT_GROUP, MESSAGE_CLASS, EVENT_TYPE_CLASS и обязательных полей."""
        super().__init_subclass__(**kwargs)

        # Проверка наличия обязательных атрибутов
        if not hasattr(cls, "SERVICE_NAME") or not isinstance(
            getattr(cls, "SERVICE_NAME", None), str
        ):
            raise TypeError(
                f"{cls.__name__} должен определить SERVICE_NAME (непустая строка)"
            )

        service_name = cls.SERVICE_NAME
        if not service_name or not service_name.strip():
            raise TypeError(
                f"{cls.__name__}.SERVICE_NAME не должен быть пустой строкой"
            )

        if not hasattr(cls, "EVENT_GROUP"):
            raise TypeError(f"{cls.__name__} должен определить EVENT_GROUP")

        if not hasattr(cls, "MESSAGE_CLASS"):
            raise TypeError(f"{cls.__name__} должен определить MESSAGE_CLASS")

        if not hasattr(cls, "EVENT_TYPE_CLASS"):
            raise TypeError(f"{cls.__name__} должен определить EVENT_TYPE_CLASS")

        # Проверка, что EVENT_TYPE_CLASS содержит обязательные поля create/update/delete
        event_type_cls = cls.EVENT_TYPE_CLASS
        if not isinstance(event_type_cls, type) or not issubclass(
            event_type_cls, enum.Enum
        ):
            raise TypeError(
                f"{cls.__name__}.EVENT_TYPE_CLASS должен быть подклассом enum.Enum"
            )
        for name, expected_value in BaseEventAsync._REQUIRED_EVENT_TYPES.items():
            if not hasattr(event_type_cls, name):
                raise TypeError(
                    f"{cls.__name__}.EVENT_TYPE_CLASS должен содержать поле {name}"
                )
            member = getattr(event_type_cls, name)
            actual_value = member.value if hasattr(member, "value") else member
            if actual_value != expected_value:
                raise TypeError(
                    f"{cls.__name__}.EVENT_TYPE_CLASS.{name} должен быть равен "
                    f"{expected_value!r}, получено {actual_value!r}"
                )
