import asyncio
from datetime import date, datetime
from enum import Enum

from pydantic import BaseModel

from tp_common.event_service.schemas import BaseEventMessage
from tp_common.event_service.service_async import BaseEventAsync
from tp_common.kafka.connector import KafkaConnector
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger

log_factory = TpLogger(env=EnvironmentType.LOCAL)


def get_kafka() -> KafkaConnector:
    """Коннектор без логгера; BaseEventAsync при создании consumer/producer вызовет connector.set_logger(self.logger)."""
    return KafkaConnector("sasl_plaintext://user:user1122@@192.168.81.61:9094")


class EventGroup(str, Enum):
    USERS = "users"


class UserEvent(str, Enum):
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"

    CHANGE_NAME = "change_name"


class User(BaseModel):
    id: int
    name: str
    description: str | None = None
    is_active: bool
    created_at: datetime
    updated_at: datetime | None = None
    start_date: date | None = None


class UserEventMessage(BaseEventMessage[User, UserEvent]):
    """Сообщение события пользователя. id и name подставляются из after автоматически."""

    id: int | None = None
    name: str | None = None


class UserEventService(BaseEventAsync[UserEventMessage, UserEvent]):
    """Асинхронный дескриптор события пользователей."""

    SERVICE_NAME = "postgres"
    EVENT_GROUP = EventGroup.USERS
    MESSAGE_CLASS = UserEventMessage
    EVENT_TYPE_CLASS = UserEvent


logger = log_factory.get_logger("api_service_async")

# subscribe_to: только эти типы событий обрабатываются; остальные коммитятся и пропускаются
event = UserEventService(
    connector=get_kafka(),
    consumer_group="worker_format_C",
    log=logger,
)


async def send_and_verify_one() -> None:
    """
    Отправляет одно сообщение в топик и сразу читает его обратно для проверки.
    Удобно для ручной проверки: публикация → pop() → проверка id/name из after.
    """
    now = datetime.now()
    sent = UserEventMessage(
        before=None,
        after=User(
            id=999,
            name="TestSendAndRead",
            description=None,
            is_active=True,
            created_at=now,
            updated_at=now,
        ),
        event=UserEvent.CREATE,
    )
    async with event.subscription():
        await event.publish(sent)
        logger.debug("Отправлено: id=%s name=%s", sent.id, sent.name)
        # Читаем следующее сообщение (таймаут 15 сек); может прийти наше или другое
        # async with event.pop(timeout=15) as received:
        #     if received is None:
        #         logger.warning("Таймаут чтения, сообщение не получено")
        #         return
        #     logger.debug("Прочитано: event=%s id=%s name=%s", received.event, received.id, received.name)
        #     assert sent.after is not None  # только что создали с after=User(...)
        #     if received.id == sent.after.id and received.name == sent.after.name:
        #         logger.info("OK: сообщение совпадает (id=%s, name=%s)", received.id, received.name)
        #     else:
        #         logger.info(
        #             "Прочитано другое сообщение (ожидали id=%s name=%s)",
        #             sent.after.id,
        #             sent.after.name,
        #         )


async def main() -> None:
    """
    Async цикл: async with subscription() — подписка/отписка; async with pop() as message — чтение.
    Несовпадение схем обрабатывается внутри BaseEventAsync: остановка, затем каждые 10 мин Critical.
    """
    while True:
        logger.debug("Получаю сообщения")

        # event.enable_auto_commit()

        try:
            async with event.subscription():
                while True:
                    async with event.pop() as message:
                        logger.debug("Event: %s", message.event)
                        logger.debug("Before: %s", message.before)
                        logger.debug("After: %s", message.after)
                        logger.debug(
                            "Поля из after: id=%s name=%s", message.id, message.name
                        )

        except Exception as e:
            logger.exception("Ошибка в цикле событий: %s", e)


if __name__ == "__main__":
    # Один раз отправить сообщение и прочитать для проверки:
    asyncio.run(send_and_verify_one())
    asyncio.run(main())
