"""
Tests for byteforge-telegram library.
"""
