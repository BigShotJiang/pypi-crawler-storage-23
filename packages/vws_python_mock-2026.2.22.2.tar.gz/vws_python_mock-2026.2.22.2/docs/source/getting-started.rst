Getting started
---------------

Mocking calls made to Vuforia with Python ``requests``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. include:: basic-example.rst

Mocking calls made to Vuforia with Python ``httpx``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. include:: httpx-example.rst
