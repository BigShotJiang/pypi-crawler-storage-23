"""A mock implementation of Vuforia Web Services."""

import pytest

pytest.register_assert_rewrite("tests.mock_vws.utils")
