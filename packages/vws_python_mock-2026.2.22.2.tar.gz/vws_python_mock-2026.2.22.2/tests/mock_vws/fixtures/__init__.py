"""Common fixtures."""
