"""Tests for ``vws``."""
