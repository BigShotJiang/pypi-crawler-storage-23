# sage_setup: distribution = sagemath-modules
from sage.coding.source_coding.huffman import Huffman
