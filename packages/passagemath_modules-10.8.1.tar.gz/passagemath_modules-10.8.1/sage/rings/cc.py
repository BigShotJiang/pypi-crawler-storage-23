# sage_setup: distribution = sagemath-modules
from sage.rings.complex_mpfr import ComplexField

CC = ComplexField()
