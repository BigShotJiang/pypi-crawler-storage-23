# sage_setup: distribution = sagemath-modules
"""
Whether or not computations are provably correct by default
"""

# proof = False
proof = True
