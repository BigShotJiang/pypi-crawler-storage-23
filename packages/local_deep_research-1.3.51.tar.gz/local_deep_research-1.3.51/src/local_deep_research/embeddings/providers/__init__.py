"""Embedding provider implementations."""

from .base import BaseEmbeddingProvider

__all__ = ["BaseEmbeddingProvider"]
