"""Project-wide constants for Local Deep Research."""

from enum import StrEnum

from .__version__ import __version__

# Honest, identifying User-Agent for APIs that prefer/require identification
# (e.g., academic APIs like arXiv, PubMed, OpenAlex)
USER_AGENT = (
    f"Local-Deep-Research/{__version__} "
    "(Academic Research Tool; https://github.com/LearningCircuit/local-deep-research)"
)

# Browser-like User-Agent for sites that may block bot requests
# Use sparingly and only when necessary
BROWSER_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)


# --- Research status values ---
class ResearchStatus(StrEnum):
    """Status values for research records.

    Uses StrEnum so values compare equal to plain strings,
    e.g. ``ResearchStatus.COMPLETED == "completed"`` is True.

    Lifecycle::

        [*] ─┬─► QUEUED ─┬─► IN_PROGRESS ─┬─► COMPLETED
             │            │                ├─► FAILED
             │            └─► SUSPENDED    └─► SUSPENDED
             │   (concurrency limit)  (terminated while queued)
             │
             └─► IN_PROGRESS (slots available, skips queue)

    Notes:
        - PENDING is declared as a model default but no creation path
          actually sets it.  All routes use QUEUED or IN_PROGRESS.
        - ERROR is checked as a terminal state but never set by current
          code.  It predates FAILED and exists for backward compatibility
          with older database records.
        - CANCELLED is not used by the research workflow.  It is used by
          the benchmark subsystem (BenchmarkStatus, BenchmarkTaskStatus).
    """

    # --- Active lifecycle states ---
    PENDING = "pending"  # Model default; never set by any creation path
    QUEUED = "queued"  # Waiting for a worker slot
    IN_PROGRESS = "in_progress"  # Worker actively executing

    # --- Terminal states ---
    COMPLETED = "completed"  # Finished successfully
    SUSPENDED = "suspended"  # User terminated the research
    FAILED = "failed"  # Unrecoverable error during execution

    # --- Legacy / compatibility ---
    ERROR = "error"  # Never set; predates FAILED
    CANCELLED = "cancelled"  # Unused by research; for benchmarks


# --- Rate limiting defaults ---
RATE_LIMIT_WINDOW_SECONDS = 60
DEFAULT_RATE_LIMIT = 60  # requests per window

# --- Snippet / truncation lengths ---
SNIPPET_LENGTH_SHORT = 250
SNIPPET_LENGTH_LONG = 500
