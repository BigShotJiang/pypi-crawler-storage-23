class Pig:
    def __init__(self,name,serial_number):
        self.name = name
        self.age = 1
        self.serial_number = serial_number
        print(f"猪{self.name}诞生了")
    def age_add(self):
        self.age += 1
        print(f"猪的年龄为：{self.age}")

        return self.age
    def display(self):
        print(f"猪的名字：{self.name},猪的年龄：{self.age},猪的编号:{self.serial_number}")
    def modify(self,modify_name,modify_serial_number):
        try:
            if modify_name and modify_serial_number == None:
                whether_to_input = input("猪的名字或猪的年龄未输入，是否输入：(y/n):")
                if whether_to_input == "y":
                    if modify_name == None:
                        modify_name = input("请输入猪的名字：")
                        self.name =  modify_name
                    if modify_serial_number == None:
                        modify_serial_number = input("请输入猪的编号：")

                        self.serial_number = modify_serial_number
                else:
                    print("好的，不修改")

            print(f"猪的名字:{self.name},猪的编号:{self.serial_number}")
        except:
            print("出现问题")
    def pig_play(self,play_content):
        print(f"猪{self.name}玩了{play_content}")
    def pig_sleep(self,sleep_time):
        print(f"猪{self.name}睡了{sleep_time}小时")
    def pig_eat(self,food,food_time,quantity_of_food):
        print(f"猪{self.name}吃了{food}，吃了{food_time}小时,吃了{quantity_of_food}克食物")
    def pig_squeal(self,the_number_of_pig_calls):
        print(f"猪{self.name}叫了{the_number_of_pig_calls}次")

class pigs_squeal_endlessly(Pig):
    def pigs_squeal_endlessly(self):
        a = 1
        try:
            while True:
                print(f"猪{self.name}叫了{a}次")
                a += 1
        except KeyboardInterrupt:
            print(f"猪{self.name}叫了{a}次")
