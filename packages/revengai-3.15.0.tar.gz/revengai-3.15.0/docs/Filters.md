# Filters


## Enum

* `OFFICIAL_ONLY` (value: `'official_only'`)

* `USER_ONLY` (value: `'user_only'`)

* `TEAM_ONLY` (value: `'team_only'`)

* `PUBLIC_ONLY` (value: `'public_only'`)

* `HIDE_EMPTY` (value: `'hide_empty'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


