#!/usr/bin/env python3
import anime_downloader
anime_downloader.main()