"""Test suite for anime_downloader package."""
