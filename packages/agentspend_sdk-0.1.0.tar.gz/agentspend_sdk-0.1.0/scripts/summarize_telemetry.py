"""Summarize AgentSpend JSONL telemetry into ROI-oriented metrics.

Usage:
    uv run --no-sync python scripts/summarize_telemetry.py agent_telemetry.jsonl
"""

from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: python scripts/summarize_telemetry.py <telemetry_jsonl_path>")
        return 1

    path = Path(sys.argv[1])
    if not path.exists():
        print(f"File not found: {path}")
        return 1

    events = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    if not events:
        print("No valid telemetry events found.")
        return 0

    total = len(events)
    ok_events = [e for e in events if e.get("outcome") == "ok"]
    error_events = [e for e in events if e.get("outcome") != "ok"]

    total_cost = sum(float(e.get("cost_usd", 0.0)) for e in ok_events)
    total_prompt_tokens = sum(int(e.get("prompt_tokens", 0)) for e in ok_events)
    total_completion_tokens = sum(int(e.get("completion_tokens", 0)) for e in ok_events)
    loop_events = sum(1 for e in events if bool(e.get("loop_detected", False)))
    fallback_events = sum(1 for e in ok_events if len(e.get("fallbacks_tried", [])) > 0)
    fallback_rate = (fallback_events / len(ok_events) * 100) if ok_events else 0.0

    latency_by_step: dict[str, list[float]] = defaultdict(list)
    cost_by_step: dict[str, float] = defaultdict(float)
    count_by_step: dict[str, int] = defaultdict(int)
    model_counts: dict[str, int] = defaultdict(int)

    for event in ok_events:
        step = str(event.get("step", "unknown"))
        latency = float(event.get("latency_ms", 0.0))
        cost = float(event.get("cost_usd", 0.0))
        model = str(event.get("model_used", "unknown"))

        latency_by_step[step].append(latency)
        cost_by_step[step] += cost
        count_by_step[step] += 1
        model_counts[model] += 1

    print("=== AgentSpend Telemetry Summary ===")
    print(f"Source file: {path}")
    print()
    print(f"Total events: {total}")
    print(f"Successful events: {len(ok_events)}")
    print(f"Error events: {len(error_events)}")
    print(f"Total cost (ok events): ${total_cost:.6f}")
    print(f"Total tokens: {total_prompt_tokens + total_completion_tokens}")
    print(f"  Prompt tokens: {total_prompt_tokens}")
    print(f"  Completion tokens: {total_completion_tokens}")
    print(f"Loop-flagged events: {loop_events}")
    print(f"Fallback usage rate: {fallback_rate:.2f}% ({fallback_events}/{len(ok_events) or 1})")
    print()

    print("Cost by step:")
    for step in sorted(cost_by_step.keys()):
        count = count_by_step[step]
        avg = cost_by_step[step] / count if count else 0.0
        print(f"  - {step}: total=${cost_by_step[step]:.6f}, avg=${avg:.6f}, calls={count}")
    print()

    print("Latency by step:")
    for step in sorted(latency_by_step.keys()):
        values = latency_by_step[step]
        avg = sum(values) / len(values) if values else 0.0
        p95_idx = max(int(len(values) * 0.95) - 1, 0)
        p95 = sorted(values)[p95_idx] if values else 0.0
        print(f"  - {step}: avg={avg:.1f}ms, p95={p95:.1f}ms, calls={len(values)}")
    print()

    print("Model utilization:")
    for model, count in sorted(model_counts.items(), key=lambda x: x[1], reverse=True):
        pct = count / len(ok_events) * 100 if ok_events else 0.0
        print(f"  - {model}: {count} calls ({pct:.1f}%)")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
