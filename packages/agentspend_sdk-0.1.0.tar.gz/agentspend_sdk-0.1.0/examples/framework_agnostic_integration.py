"""Framework-agnostic AgentSpend integration example.

This demonstrates how to plug AgentSpend into a generic agent loop:
1) classify/select step type
2) route model call via AgentSpend
3) execute step logic
4) feed explicit success/failure back to adaptive routing

Run:
    uv run --no-sync python examples/framework_agnostic_integration.py
"""

from __future__ import annotations

from dataclasses import dataclass

from token_aud.agent import AdaptiveRouter, AgentSpend
from token_aud.agent.telemetry import CallbackSink, TelemetryEmitter


@dataclass
class AgentStep:
    name: str
    prompt: str
    expected_keyword: str


def evaluate_step_success(response_text: str, expected_keyword: str) -> bool:
    """Toy success evaluator for demo purposes."""
    return expected_keyword.lower() in response_text.lower()


def main() -> None:
    adaptive = AdaptiveRouter(min_samples=3, confidence_threshold=0.8)
    telemetry = TelemetryEmitter(
        sinks=[
            CallbackSink(
                lambda e: print(
                    f"[telemetry] step={e.step} model={e.model_used} "
                    f"cost=${e.cost_usd:.6f} outcome={e.outcome}"
                )
            ),
        ]
    )
    sdk = AgentSpend.default(adaptive=adaptive, telemetry=telemetry)

    steps = [
        AgentStep(
            name="plan",
            prompt="Create a concise plan to build a FastAPI service.",
            expected_keyword="plan",
        ),
        AgentStep(
            name="reason",
            prompt="Compare Flask vs FastAPI for production APIs.",
            expected_keyword="fastapi",
        ),
        AgentStep(
            name="tool",
            prompt="Generate a JSON schema for a User with id and email.",
            expected_keyword="schema",
        ),
        AgentStep(
            name="verify",
            prompt="Check this code for issues: def add(a,b): return a+b+1",
            expected_keyword="issue",
        ),
    ]

    print("=== Framework-Agnostic Integration Demo ===")
    for idx, step in enumerate(steps):
        print(f"\nStep {idx}: {step.name}")
        result = sdk.route_call(
            step=step.name,
            messages=[{"role": "user", "content": step.prompt}],
            custom_labels={"workflow": "framework-agnostic-demo"},
        )
        success = evaluate_step_success(result.content, step.expected_keyword)
        print(f"  model_used={result.model_used}")
        print(f"  step_cost=${result.cost_usd:.6f}")
        print(f"  success={success}")
        print(f"  preview={result.content[:100].strip()}...")

        # Explicit success feedback (in addition to default runtime signals).
        if sdk.adaptive:
            sdk.adaptive.record_outcome(
                step=step.name,
                model=result.model_used,
                success=success,
                cost=result.cost_usd,
                latency_ms=result.latency_ms,
            )

    print("\n=== Adaptive Stats Snapshot ===")
    if sdk.adaptive:
        stats = sdk.adaptive.get_stats()
        for step_name, model_stats in stats.items():
            print(f"{step_name}: {model_stats}")

    telemetry.flush()
    telemetry.close()


if __name__ == "__main__":
    main()
