"""AgentSpend — demo with a custom YAML policy and loop guard.

Shows how to:
1. Load a custom routing policy
2. Trigger loop detection with repeated messages
3. Observe escalation and hard-stop behavior

Run:
    uv run python examples/custom_policy_demo.py
"""

from token_aud.agent import AgentSpend
from token_aud.agent.telemetry import CallbackSink, TelemetryEmitter


def main() -> None:
    policy_dict = {
        "version": 1,
        "name": "loop-test",
        "globals": {
            "default_model": "gpt-4o-mini",
            "max_cost_per_run_usd": 0.50,
            "fail_open": True,
        },
        "models": {
            "gpt-4o-mini": {"provider": "openai", "cost_tier": "low", "latency_tier": "low"},
            "gpt-4o": {"provider": "openai", "cost_tier": "medium", "latency_tier": "medium"},
        },
        "steps": {
            "generic": {
                "default_model": "gpt-4o-mini",
                "allowed_models": ["gpt-4o-mini"],
                "fallback_chain": ["gpt-4o"],
            },
        },
        "loop_guard": {
            "enabled": True,
            "similarity_threshold": 0.90,
            "repeated_turn_limit": 2,
            "on_trigger": {
                "action": "escalate",
                "escalate_to": "gpt-4o",
                "hard_stop_after": 2,
            },
        },
    }

    telemetry = TelemetryEmitter(sinks=[
        CallbackSink(lambda e: print(
            f"  [{e.outcome}] model={e.model_used} cost=${e.cost_usd:.6f} "
            f"loop={e.loop_detected} reason={e.reason}"
        )),
    ])

    agent = AgentSpend.from_dict(policy_dict, telemetry=telemetry)

    repeated_msg = [{"role": "user", "content": "What is 2+2?"}]

    for i in range(6):
        print(f"\n=== Turn {i} ===")
        try:
            result = agent.route_call(messages=repeated_msg)
            print(f"  Response: {result.content[:80]}")
        except RuntimeError as exc:
            print(f"  HARD STOP: {exc}")
            break

    print(f"\nTotal cost: ${agent.run_cost_usd:.6f}")


if __name__ == "__main__":
    main()
