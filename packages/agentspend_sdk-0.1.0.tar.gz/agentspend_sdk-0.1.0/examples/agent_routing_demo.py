"""AgentSpend SDK demo — simulates an agent loop with dynamic model routing.

Run:
    uv run python examples/agent_routing_demo.py

Requires at least OPENAI_API_KEY in .env (or TOKEN_AUD_OPENAI_API_KEY).
"""

from token_aud.agent import AgentSpend
from token_aud.agent.telemetry import CallbackSink, JsonlSink, TelemetryEmitter


def main() -> None:
    telemetry = TelemetryEmitter(sinks=[
        JsonlSink("agent_telemetry.jsonl"),
        CallbackSink(lambda e: print(f"  [telemetry] {e.step}: {e.model_used} ${e.cost_usd:.6f} {e.latency_ms:.0f}ms")),
    ])

    agent = AgentSpend.default(telemetry=telemetry)

    print(f"Policy: {agent.policy.name}")
    print(f"Budget cap: ${agent.policy.globals.max_cost_per_run_usd}")
    print()

    steps = [
        ("plan", "Break down how to build a REST API in Python into clear steps."),
        ("reason", "Compare Flask vs FastAPI for a production REST API. Consider performance, typing, and async support."),
        ("tool", "Generate a JSON schema for a User resource with fields: id, name, email, created_at."),
        ("draft", "Write a complete FastAPI endpoint for creating a new user with input validation."),
        ("verify", "Check this code for bugs: def add(a, b): return a + b + 1"),
        ("summarize", "Summarize the key decisions made in this API design session."),
    ]

    for step_name, prompt in steps:
        print(f"--- Step: {step_name} ---")
        print(f"  Prompt: {prompt[:80]}...")
        try:
            result = agent.route_call(
                step=step_name,
                messages=[{"role": "user", "content": prompt}],
            )
            print(f"  Model: {result.model_used}")
            print(f"  Cost: ${result.cost_usd:.6f}")
            print(f"  Latency: {result.latency_ms:.0f}ms")
            print(f"  Response: {result.content[:120]}...")
            print(f"  Fallbacks tried: {result.fallbacks_tried or 'none'}")
        except RuntimeError as exc:
            print(f"  ERROR: {exc}")
        print()

    print(f"Total run cost: ${agent.run_cost_usd:.6f}")
    print(f"Turns completed: {agent.turn_index}")

    telemetry.flush()
    telemetry.close()
    print("\nTelemetry written to agent_telemetry.jsonl")


if __name__ == "__main__":
    main()
