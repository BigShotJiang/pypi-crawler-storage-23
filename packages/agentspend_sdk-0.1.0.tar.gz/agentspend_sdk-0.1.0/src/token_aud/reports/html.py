"""HTML report generator — self-contained file for sharing with stakeholders."""

from datetime import datetime
from decimal import Decimal
from pathlib import Path

from token_aud.models.schemas import SavingsReport


# Status display for HTML
STATUS_HTML = {
    "switch_recommended": ('<span class="badge switch">SWITCH</span>', "switch"),
    "premium_required": ('<span class="badge keep">KEEP</span>', "keep"),
    "already_optimal": ('<span class="badge optimal">OPTIMAL</span>', "optimal"),
    "not_audited": ('<span class="badge na">N/A</span>', "na"),
}


def generate_html(report: SavingsReport, output_path: Path) -> Path:
    """Generate a self-contained HTML savings report.

    Args:
        report: The SavingsReport to render.
        output_path: Where to write the HTML file.

    Returns:
        The path to the generated file.
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)
    html = _render(report)
    output_path.write_text(html)
    return output_path


def _render(report: SavingsReport) -> str:
    """Render the full HTML document."""
    annual_savings = report.total_potential_savings * 12
    generated_at = datetime.now().strftime("%B %d, %Y at %H:%M")

    # Build model rows
    model_rows = ""
    for rec in report.model_recommendations:
        badge_html, row_class = STATUS_HTML.get(rec.status, ("?", ""))
        switch_to = rec.recommended_model or "—"
        score = f"{rec.avg_quality_score:.2f}" if rec.audits_run > 0 else "—"
        safe_pct = f"{rec.safe_switch_rate:.0%}" if rec.audits_run > 0 else "—"
        savings = f"${rec.projected_savings:,.2f}" if rec.projected_savings > 0 else "—"
        confidence = f"{rec.confidence:.0%}" if rec.audits_run > 0 else "—"
        savings_class = "savings-positive" if rec.projected_savings > 0 else ""

        model_rows += f"""
            <tr class="row-{row_class}">
                <td class="model-name">{rec.current_model}</td>
                <td>{rec.provider}</td>
                <td class="num">{rec.entry_count:,}</td>
                <td class="num">${rec.current_spend:,.2f}</td>
                <td class="status">{badge_html}</td>
                <td>{switch_to}</td>
                <td class="num">{score}</td>
                <td class="num">{safe_pct}</td>
                <td class="num {savings_class}">{savings}</td>
                <td class="num">{confidence}</td>
            </tr>"""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>token-aud Savings Report</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f8f9fa; color: #1a1a2e; line-height: 1.6;
            max-width: 1100px; margin: 0 auto; padding: 40px 24px;
        }}
        h1 {{ font-size: 28px; font-weight: 700; margin-bottom: 4px; }}
        .subtitle {{ color: #6b7280; font-size: 14px; margin-bottom: 32px; }}

        /* Summary cards */
        .summary {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 32px; }}
        .card {{
            background: white; border-radius: 12px; padding: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
        }}
        .card .label {{ font-size: 13px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; }}
        .card .value {{ font-size: 28px; font-weight: 700; margin-top: 4px; }}
        .card .value.green {{ color: #059669; }}
        .card .value.blue {{ color: #2563eb; }}

        /* Annual callout */
        .annual {{
            background: linear-gradient(135deg, #059669, #10b981);
            color: white; border-radius: 12px; padding: 24px; text-align: center;
            margin-bottom: 32px; box-shadow: 0 4px 12px rgba(5,150,105,0.3);
        }}
        .annual .amount {{ font-size: 36px; font-weight: 800; }}
        .annual .label {{ font-size: 14px; opacity: 0.9; margin-top: 4px; }}

        /* Table */
        .table-wrap {{
            background: white; border-radius: 12px; overflow: hidden;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08); margin-bottom: 32px;
        }}
        table {{ width: 100%; border-collapse: collapse; font-size: 14px; }}
        th {{
            background: #f9fafb; padding: 12px 16px; text-align: left;
            font-weight: 600; color: #374151; border-bottom: 2px solid #e5e7eb;
        }}
        td {{ padding: 12px 16px; border-bottom: 1px solid #f3f4f6; }}
        .num {{ text-align: right; font-variant-numeric: tabular-nums; }}
        .model-name {{ font-weight: 600; }}
        .savings-positive {{ color: #059669; font-weight: 700; }}

        /* Status badges */
        .badge {{
            display: inline-block; padding: 2px 10px; border-radius: 20px;
            font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;
        }}
        .badge.switch {{ background: #d1fae5; color: #065f46; }}
        .badge.keep {{ background: #fef3c7; color: #92400e; }}
        .badge.optimal {{ background: #dbeafe; color: #1e40af; }}
        .badge.na {{ background: #f3f4f6; color: #6b7280; }}

        /* Row highlights */
        tr.row-switch td {{ background: #f0fdf4; }}

        /* Methodology */
        .methodology {{
            background: white; border-radius: 12px; padding: 24px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08); font-size: 14px; color: #4b5563;
        }}
        .methodology h2 {{ font-size: 18px; color: #1a1a2e; margin-bottom: 12px; }}
        .methodology ul {{ padding-left: 20px; }}
        .methodology li {{ margin-bottom: 8px; }}

        @media print {{
            body {{ padding: 20px; }}
            .annual {{ box-shadow: none; border: 2px solid #059669; }}
            .card, .table-wrap, .methodology {{ box-shadow: none; border: 1px solid #e5e7eb; }}
        }}
    </style>
</head>
<body>
    <h1>token-aud Savings Report</h1>
    <div class="subtitle">Generated {generated_at}</div>

    <div class="summary">
        <div class="card">
            <div class="label">Total Entries</div>
            <div class="value">{report.total_entries:,}</div>
        </div>
        <div class="card">
            <div class="label">Total Spend</div>
            <div class="value">${report.total_actual_cost:,.2f}</div>
        </div>
        <div class="card">
            <div class="label">Potential Savings</div>
            <div class="value green">${report.total_potential_savings:,.2f}</div>
        </div>
        <div class="card">
            <div class="label">Savings Rate</div>
            <div class="value blue">{report.savings_percentage:.1f}%</div>
        </div>
    </div>

    <div class="annual">
        <div class="amount">${annual_savings:,.2f}</div>
        <div class="label">Projected Annual Savings</div>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Model</th>
                    <th>Provider</th>
                    <th class="num">Entries</th>
                    <th class="num">Spend</th>
                    <th>Status</th>
                    <th>Switch To</th>
                    <th class="num">Score</th>
                    <th class="num">Safe %</th>
                    <th class="num">Savings</th>
                    <th class="num">Conf.</th>
                </tr>
            </thead>
            <tbody>{model_rows}
            </tbody>
        </table>
    </div>

    <div class="methodology">
        <h2>Methodology</h2>
        <ul>
            <li><strong>Sampling:</strong> {report.total_audited} of {report.total_entries} entries
                were selected for audit using cost-weighted stratified sampling, prioritizing
                high-spend models with available cheaper alternatives.</li>
            <li><strong>Student-Teacher-Judge:</strong> Each sampled entry was re-run on a cheaper
                model (Student). An independent LLM (Judge) compared the original and cheaper
                outputs, scoring quality on accuracy, relevance, and clarity.</li>
            <li><strong>Threshold:</strong> A quality score of 0.80 or above indicates the cheaper
                model is an acceptable replacement. Entries scoring below this are marked
                "premium required."</li>
            <li><strong>Projection:</strong> Savings are extrapolated from the audited sample to
                the full dataset using the safe-to-switch rate. Confidence reflects sample
                coverage — higher sample ratios yield more reliable projections.</li>
            <li><strong>Audit cost:</strong> This analysis was conducted using low-cost models
                for the Student and Judge calls, keeping the audit cost minimal relative to
                the identified savings.</li>
        </ul>
    </div>

    <div class="subtitle" style="margin-top: 24px; text-align: center;">
        Powered by token-aud &mdash; AI Cost Optimization
    </div>
</body>
</html>"""
