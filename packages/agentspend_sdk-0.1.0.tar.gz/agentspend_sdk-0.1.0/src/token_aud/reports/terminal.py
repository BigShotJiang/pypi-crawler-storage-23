"""Rich terminal report — instant visual feedback after an analysis run."""

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from token_aud.models.schemas import SavingsReport


# Status display mapping
STATUS_DISPLAY = {
    "switch_recommended": ("SWITCH", "bold green"),
    "premium_required": ("KEEP", "bold yellow"),
    "already_optimal": ("OPTIMAL", "bold cyan"),
    "not_audited": ("N/A", "dim"),
}


def print_report(report: SavingsReport, console: Console | None = None) -> None:
    """Print a SavingsReport to the terminal using Rich formatting."""
    if console is None:
        console = Console()

    # --- Header panel ---
    annual_savings = report.total_potential_savings * 12
    header_lines = [
        f"[bold]Total Entries:[/bold]  {report.total_entries:,}        "
        f"[bold]Total Spend:[/bold]  ${report.total_actual_cost:,.2f}        "
        f"[bold]Confidence:[/bold]  {report.confidence_level:.0%}",
        f"[bold]Audited:[/bold]       {report.total_audited:,}         "
        f"[bold]Savings:[/bold]      ${report.total_potential_savings:,.2f} "
        f"({report.savings_percentage:.1f}%)",
    ]
    console.print()
    console.print(
        Panel(
            "\n".join(header_lines),
            title="[bold]token-aud Savings Report[/bold]",
            border_style="blue",
            padding=(1, 2),
        )
    )

    # --- Model recommendations table ---
    table = Table(
        show_header=True,
        header_style="bold",
        border_style="dim",
        pad_edge=True,
        expand=True,
    )
    table.add_column("Model", style="bold", min_width=20)
    table.add_column("Provider", min_width=10)
    table.add_column("Entries", justify="right", min_width=8)
    table.add_column("Spend", justify="right", min_width=10)
    table.add_column("Status", justify="center", min_width=10)
    table.add_column("Switch To", min_width=16)
    table.add_column("Score", justify="right", min_width=7)
    table.add_column("Safe %", justify="right", min_width=7)
    table.add_column("Savings", justify="right", min_width=10)
    table.add_column("Conf.", justify="right", min_width=6)

    for rec in report.model_recommendations:
        label, style = STATUS_DISPLAY.get(rec.status, ("?", ""))

        status_text = Text(label, style=style)

        switch_to = rec.recommended_model or "—"
        score = f"{rec.avg_quality_score:.2f}" if rec.audits_run > 0 else "—"
        safe_pct = f"{rec.safe_switch_rate:.0%}" if rec.audits_run > 0 else "—"
        savings = f"${rec.projected_savings:,.2f}" if rec.projected_savings > 0 else "—"
        confidence = f"{rec.confidence:.0%}" if rec.audits_run > 0 else "—"

        # Color the savings column green if there are savings
        if rec.projected_savings > 0:
            savings_text = Text(savings, style="bold green")
        else:
            savings_text = Text(savings, style="dim")

        table.add_row(
            rec.current_model,
            rec.provider,
            f"{rec.entry_count:,}",
            f"${rec.current_spend:,.2f}",
            status_text,
            switch_to,
            score,
            safe_pct,
            savings_text,
            confidence,
        )

    console.print()
    console.print(table)

    # --- Bottom line ---
    console.print()
    if report.total_potential_savings > 0:
        console.print(
            Panel(
                f"[bold green]Projected annual savings: "
                f"${annual_savings:,.2f}[/bold green]",
                border_style="green",
                padding=(0, 2),
            )
        )
    else:
        console.print(
            Panel(
                "[bold cyan]Your model usage is already optimized. "
                "No savings opportunities found.[/bold cyan]",
                border_style="cyan",
                padding=(0, 2),
            )
        )

    console.print()
