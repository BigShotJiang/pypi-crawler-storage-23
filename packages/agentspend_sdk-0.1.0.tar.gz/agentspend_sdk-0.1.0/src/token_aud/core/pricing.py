"""Pricing engine — model cost lookup, calculation, and cheaper alternative mapping.

Usage:
    from token_aud.core.pricing import PricingEngine

    engine = PricingEngine()  # loads default pricing.json
    cost = engine.calculate_cost("gpt-4o", prompt_tokens=500, completion_tokens=200)
    alt = engine.get_cheaper_alternative("gpt-4o")  # -> "gpt-4o-mini"
    hypo = engine.calculate_cost(alt, prompt_tokens=500, completion_tokens=200)
    savings = cost - hypo
"""

import json
from decimal import Decimal
from importlib import resources
from pathlib import Path

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Data model for a single model's pricing
# ---------------------------------------------------------------------------
class ModelPricing(BaseModel):
    """Pricing entry for one LLM model."""

    model: str
    provider: str
    input_cost_per_token: Decimal = Field(description="Cost per single input token in USD")
    output_cost_per_token: Decimal = Field(description="Cost per single output token in USD")
    aliases: list[str] = Field(default_factory=list)
    cheaper_alternative: str | None = None


# ---------------------------------------------------------------------------
# The pricing engine
# ---------------------------------------------------------------------------
class PricingEngine:
    """Loads pricing data and provides cost calculation + model lookup."""

    def __init__(self, pricing_path: Path | None = None) -> None:
        self._models: dict[str, ModelPricing] = {}
        self._alias_map: dict[str, str] = {}  # alias -> canonical model name
        self._load(pricing_path)

    # --- Public API ---

    def calculate_cost(
        self,
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
    ) -> Decimal:
        """Calculate the cost for a request given model and token counts.

        Returns Decimal("0") if the model is unknown.
        """
        pricing = self.get_pricing(model)
        if pricing is None:
            return Decimal("0")

        input_cost = Decimal(prompt_tokens) * pricing.input_cost_per_token
        output_cost = Decimal(completion_tokens) * pricing.output_cost_per_token
        total = input_cost + output_cost
        return total.quantize(Decimal("0.000001"))  # Round to 6 decimal places

    def get_pricing(self, model: str) -> ModelPricing | None:
        """Look up pricing for a model. Tries exact match, then aliases."""
        canonical = self._resolve(model)
        if canonical is None:
            return None
        return self._models.get(canonical)

    def get_cheaper_alternative(self, model: str) -> str | None:
        """Return the recommended cheaper model, or None if already the cheapest."""
        pricing = self.get_pricing(model)
        if pricing is None:
            return None
        return pricing.cheaper_alternative

    def list_models(self) -> list[str]:
        """Return all known canonical model names."""
        return sorted(self._models.keys())

    def is_known(self, model: str) -> bool:
        """Check if a model name (or alias) is in the pricing database."""
        return self._resolve(model) is not None

    # --- Loading ---

    def _load(self, pricing_path: Path | None) -> None:
        """Load pricing data from JSON file."""
        if pricing_path is not None:
            raw = json.loads(pricing_path.read_text())
        else:
            raw = self._load_default()

        for entry in raw["models"]:
            pricing = ModelPricing(
                model=entry["model"],
                provider=entry["provider"],
                input_cost_per_token=Decimal(str(entry["input_cost_per_million"])) / Decimal("1000000"),
                output_cost_per_token=Decimal(str(entry["output_cost_per_million"])) / Decimal("1000000"),
                aliases=entry.get("aliases", []),
                cheaper_alternative=entry.get("cheaper_alternative"),
            )

            # Register canonical name
            self._models[pricing.model] = pricing

            # Register aliases
            for alias in pricing.aliases:
                self._alias_map[alias.lower()] = pricing.model

    def _load_default(self) -> dict:
        """Load the built-in pricing.json from the package data."""
        data_files = resources.files("token_aud.data")
        pricing_file = data_files.joinpath("pricing.json")
        return json.loads(pricing_file.read_text())

    # --- Resolution ---

    def _resolve(self, model: str) -> str | None:
        """Resolve a model name or alias to its canonical name."""
        # Exact match on canonical name
        if model in self._models:
            return model

        # Try lowercase alias lookup
        lower = model.lower()
        if lower in self._alias_map:
            return self._alias_map[lower]

        # Try lowercase match on canonical names
        for canonical in self._models:
            if canonical.lower() == lower:
                return canonical

        return None
