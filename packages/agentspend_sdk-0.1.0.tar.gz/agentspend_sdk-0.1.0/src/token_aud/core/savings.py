"""Savings calculator — aggregates audit results into per-model recommendations.

Takes raw AuditResults and projects savings across the full dataset.
Includes ALL models in the report — audited, skipped, and already-optimal.

Usage:
    from token_aud.core.savings import calculate_savings

    report = calculate_savings(
        entries=all_log_entries,
        audit_results=batch.results,
        pricing_engine=engine,
        quality_threshold=0.8,
    )
"""

import math
from collections import defaultdict
from decimal import Decimal

from token_aud.core.pricing import PricingEngine
from token_aud.models.schemas import (
    AuditResult,
    LogEntry,
    ModelRecommendation,
    SavingsReport,
)


def calculate_savings(
    entries: list[LogEntry],
    audit_results: list[AuditResult],
    pricing_engine: PricingEngine,
    quality_threshold: float = 0.8,
) -> SavingsReport:
    """Build a complete SavingsReport from log entries and audit results.

    Args:
        entries: ALL log entries (not just sampled ones).
        audit_results: Results from the auditor pipeline.
        pricing_engine: For cost lookups and cheaper alternatives.
        quality_threshold: Score threshold for "safe to switch".

    Returns:
        A SavingsReport covering 100% of spend across all models.
    """

    # --- Group entries by model ---
    entries_by_model: dict[str, list[LogEntry]] = defaultdict(list)
    for entry in entries:
        entries_by_model[entry.model].append(entry)

    # --- Group audit results by the original model (via log_entry lookup) ---
    entry_lookup: dict[str, LogEntry] = {str(e.id): e for e in entries}
    audits_by_model: dict[str, list[AuditResult]] = defaultdict(list)
    for audit in audit_results:
        original_entry = entry_lookup.get(str(audit.log_entry_id))
        if original_entry:
            audits_by_model[original_entry.model].append(audit)

    # --- Build recommendations for each model ---
    recommendations: list[ModelRecommendation] = []
    total_projected_savings = Decimal("0")

    for model, model_entries in entries_by_model.items():
        model_audits = audits_by_model.get(model, [])
        rec = _build_recommendation(
            model=model,
            entries=model_entries,
            audits=model_audits,
            pricing_engine=pricing_engine,
            quality_threshold=quality_threshold,
        )
        recommendations.append(rec)
        total_projected_savings += rec.projected_savings

    # --- Sort: highest savings first, then already-optimal at the end ---
    status_order = {
        "switch_recommended": 0,
        "premium_required": 1,
        "not_audited": 2,
        "already_optimal": 3,
    }
    recommendations.sort(
        key=lambda r: (status_order.get(r.status, 9), -r.projected_savings)
    )

    # --- Aggregate totals ---
    total_actual_cost = sum((e.actual_cost for e in entries), Decimal("0"))
    # Fill in zero-cost entries using pricing engine
    if total_actual_cost == 0:
        total_actual_cost = sum(
            (pricing_engine.calculate_cost(e.model, e.prompt_tokens, e.completion_tokens)
             for e in entries),
            Decimal("0"),
        )

    savings_pct = (
        float(total_projected_savings / total_actual_cost * 100)
        if total_actual_cost > 0
        else 0.0
    )

    # Overall confidence: weighted average by spend
    total_spend = sum(r.current_spend for r in recommendations) or Decimal("1")
    overall_confidence = sum(
        float(r.current_spend / total_spend) * r.confidence
        for r in recommendations
    )

    return SavingsReport(
        total_entries=len(entries),
        total_audited=len(audit_results),
        total_actual_cost=total_actual_cost,
        total_potential_savings=total_projected_savings,
        savings_percentage=round(savings_pct, 2),
        model_recommendations=recommendations,
        confidence_level=round(overall_confidence, 3),
    )


# ---------------------------------------------------------------------------
# Per-model recommendation builder
# ---------------------------------------------------------------------------
def _build_recommendation(
    model: str,
    entries: list[LogEntry],
    audits: list[AuditResult],
    pricing_engine: PricingEngine,
    quality_threshold: float,
) -> ModelRecommendation:
    """Build a ModelRecommendation for one model."""

    pricing = pricing_engine.get_pricing(model)
    provider = pricing.provider if pricing else "unknown"
    cheaper_alt = pricing_engine.get_cheaper_alternative(model)

    # Total spend for this model
    model_spend = sum((e.actual_cost for e in entries), Decimal("0"))
    if model_spend == 0:
        model_spend = sum(
            (pricing_engine.calculate_cost(e.model, e.prompt_tokens, e.completion_tokens)
             for e in entries),
            Decimal("0"),
        )

    # --- Case 1: Already the cheapest model ---
    if cheaper_alt is None:
        return ModelRecommendation(
            current_model=model,
            provider=provider,
            current_spend=model_spend,
            entry_count=len(entries),
            status="already_optimal",
            recommended_model=None,
            projected_savings=Decimal("0"),
            audits_run=0,
            avg_quality_score=0.0,
            safe_switch_rate=0.0,
            confidence=1.0,  # We're 100% confident there's nothing cheaper
        )

    # --- Case 2: Has a cheaper alternative but wasn't audited ---
    if len(audits) == 0:
        return ModelRecommendation(
            current_model=model,
            provider=provider,
            current_spend=model_spend,
            entry_count=len(entries),
            status="not_audited",
            recommended_model=cheaper_alt,
            projected_savings=Decimal("0"),
            audits_run=0,
            avg_quality_score=0.0,
            safe_switch_rate=0.0,
            confidence=0.0,
        )

    # --- Case 3: Audited — calculate from results ---
    safe_audits = [a for a in audits if a.is_safe_to_switch]
    safe_rate = len(safe_audits) / len(audits)
    avg_score = sum(a.quality_score for a in audits) / len(audits)

    # Project savings across ALL entries for this model
    projected_savings = _project_savings(
        safe_rate=safe_rate,
        audits=audits,
        total_entries=len(entries),
        model_spend=model_spend,
        pricing_engine=pricing_engine,
        model=model,
        cheaper_alt=cheaper_alt,
    )

    # Determine status
    if safe_rate >= 0.5:
        status = "switch_recommended"
    else:
        status = "premium_required"

    # Confidence based on sample coverage
    confidence = _calculate_confidence(
        sample_size=len(audits),
        population_size=len(entries),
    )

    return ModelRecommendation(
        current_model=model,
        provider=provider,
        current_spend=model_spend,
        entry_count=len(entries),
        status=status,
        recommended_model=cheaper_alt,
        projected_savings=projected_savings,
        audits_run=len(audits),
        avg_quality_score=round(avg_score, 3),
        safe_switch_rate=round(safe_rate, 3),
        confidence=round(confidence, 3),
    )


# ---------------------------------------------------------------------------
# Savings projection
# ---------------------------------------------------------------------------
def _project_savings(
    safe_rate: float,
    audits: list[AuditResult],
    total_entries: int,
    model_spend: Decimal,
    pricing_engine: PricingEngine,
    model: str,
    cheaper_alt: str,
) -> Decimal:
    """Project savings from a sample to the full population for one model.

    Logic:
    1. From audits, get the average savings per safe-to-switch entry.
    2. Apply safe_rate to total entries to estimate how many would be switchable.
    3. Multiply to get projected total savings.
    """
    safe_audits = [a for a in audits if a.is_safe_to_switch]

    if not safe_audits:
        return Decimal("0")

    # Average savings per entry that's safe to switch
    avg_savings_per_entry = sum(
        (a.potential_savings for a in safe_audits), Decimal("0")
    ) / len(safe_audits)

    # Estimated number of switchable entries in the full population
    estimated_switchable = int(total_entries * safe_rate)

    projected = avg_savings_per_entry * estimated_switchable
    return projected.quantize(Decimal("0.000001"))


# ---------------------------------------------------------------------------
# Confidence calculation
# ---------------------------------------------------------------------------
def _calculate_confidence(sample_size: int, population_size: int) -> float:
    """Calculate confidence level based on sample size vs population.

    Uses a simplified finite population correction factor.
    Higher sample ratios = higher confidence.
    """
    if population_size == 0:
        return 0.0
    if sample_size >= population_size:
        return 1.0

    ratio = sample_size / population_size

    # Finite population correction: how much of the population we've covered
    # At 5% sample: ~0.6 confidence
    # At 10% sample: ~0.7 confidence
    # At 30% sample: ~0.85 confidence
    # At 50%+ sample: ~0.95+ confidence
    #
    # Formula: 1 - sqrt((1 - ratio) / sample_size)
    # Clamped to [0, 1]
    if sample_size < 2:
        return max(0.1, ratio)

    confidence = 1.0 - math.sqrt((1.0 - ratio) / sample_size)
    return max(0.0, min(1.0, confidence))
