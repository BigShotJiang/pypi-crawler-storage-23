"""Cost-weighted stratified sampler for the audit pipeline.

Selects which LogEntries get audited based on where the money is.
Prioritizes expensive models with known cheaper alternatives.

Usage:
    from token_aud.core.sampler import Sampler

    sampler = Sampler(pricing_engine=engine)
    result = sampler.select(entries, max_audits=200)
    print(result.summary)
    for entry in result.selected:
        # send to audit pipeline
"""

import random
from collections import defaultdict
from dataclasses import dataclass, field
from decimal import Decimal

from token_aud.core.pricing import PricingEngine
from token_aud.models.schemas import LogEntry


# ---------------------------------------------------------------------------
# SampleResult: what the sampler returns
# ---------------------------------------------------------------------------
@dataclass
class ModelAllocation:
    """How many audits were allocated to one model."""

    model: str
    cheaper_alternative: str
    total_entries: int
    total_spend: Decimal
    spend_share: float  # fraction of total eligible spend
    allocated_audits: int
    selected_entries: list[LogEntry] = field(default_factory=list)


@dataclass
class SampleResult:
    """The output of the sampling process."""

    selected: list[LogEntry] = field(default_factory=list)
    allocations: list[ModelAllocation] = field(default_factory=list)

    # Filtering stats
    total_input: int = 0
    skipped_no_prompt: int = 0
    skipped_no_alternative: int = 0
    skipped_unknown_model: int = 0
    eligible_count: int = 0
    max_budget: int = 0

    @property
    def total_selected(self) -> int:
        return len(self.selected)

    @property
    def summary(self) -> str:
        """Human-readable sampling summary."""
        lines = [
            "Sampling summary:",
            f"  Total input entries:     {self.total_input:,}",
            f"  Skipped (no prompt):     {self.skipped_no_prompt:,}",
            f"  Skipped (already cheap): {self.skipped_no_alternative:,}",
            f"  Skipped (unknown model): {self.skipped_unknown_model:,}",
            f"  Eligible for audit:      {self.eligible_count:,}",
            f"  Audit budget:            {self.max_budget:,}",
            f"  Selected for audit:      {self.total_selected:,}",
            "",
            "  Allocation by model:",
        ]
        for alloc in sorted(self.allocations, key=lambda a: a.total_spend, reverse=True):
            lines.append(
                f"    {alloc.model:<25} {alloc.allocated_audits:>4} audits  "
                f"({alloc.spend_share:>5.1%} of spend)  "
                f"-> test with {alloc.cheaper_alternative}"
            )
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# The Sampler
# ---------------------------------------------------------------------------
class Sampler:
    """Cost-weighted stratified sampler.

    1. Filters out entries without prompt text
    2. Filters out entries where the model is already the cheapest
    3. Groups by model
    4. Allocates audit budget proportional to spend per model
    5. Randomly samples within each group
    """

    def __init__(self, pricing_engine: PricingEngine) -> None:
        self._pricing = pricing_engine

    def select(
        self,
        entries: list[LogEntry],
        max_audits: int = 200,
        seed: int | None = None,
        strategy: str = "cost_weighted",
    ) -> SampleResult:
        """Select entries for auditing.

        Args:
            entries: All parsed log entries.
            max_audits: Maximum number of entries to audit.
            seed: Random seed for reproducibility. None = non-deterministic.
            strategy: "cost_weighted", "stratified", or "random".
        """
        rng = random.Random(seed)

        result = SampleResult(total_input=len(entries), max_budget=max_audits)

        # --- Phase 1: Filter ---
        eligible: dict[str, list[LogEntry]] = defaultdict(list)

        for entry in entries:
            # Must have prompt text for the audit pipeline
            if not entry.prompt_text:
                result.skipped_no_prompt += 1
                continue

            # Must be a known model
            if not self._pricing.is_known(entry.model):
                result.skipped_unknown_model += 1
                continue

            # Must have a cheaper alternative
            alt = self._pricing.get_cheaper_alternative(entry.model)
            if alt is None:
                result.skipped_no_alternative += 1
                continue

            eligible[entry.model].append(entry)

        result.eligible_count = sum(len(v) for v in eligible.values())

        if result.eligible_count == 0:
            return result

        # --- Phase 2: Allocate budget ---
        if strategy == "random":
            result.selected, result.allocations = self._random_sample(
                eligible, max_audits, rng
            )
        elif strategy == "stratified":
            result.selected, result.allocations = self._stratified_sample(
                eligible, max_audits, rng
            )
        else:  # cost_weighted (default)
            result.selected, result.allocations = self._cost_weighted_sample(
                eligible, max_audits, rng
            )

        return result

    # --- Strategy: Cost-Weighted Stratified ---

    def _cost_weighted_sample(
        self,
        groups: dict[str, list[LogEntry]],
        max_audits: int,
        rng: random.Random,
    ) -> tuple[list[LogEntry], list[ModelAllocation]]:
        """Allocate budget proportional to total spend per model."""

        # Calculate total spend per model
        model_spend: dict[str, Decimal] = {}
        for model, entries in groups.items():
            model_spend[model] = sum(e.actual_cost for e in entries)
            # If cost is 0 (not provided), estimate from pricing engine
            if model_spend[model] == 0:
                model_spend[model] = sum(
                    self._pricing.calculate_cost(e.model, e.prompt_tokens, e.completion_tokens)
                    for e in entries
                )

        total_spend = sum(model_spend.values())
        if total_spend == 0:
            # Fallback to equal distribution if all costs are 0
            return self._stratified_sample(groups, max_audits, rng)

        # Allocate audits proportional to spend
        allocations: list[ModelAllocation] = []
        selected: list[LogEntry] = []
        remaining_budget = max_audits

        # Sort by spend descending — highest spenders get allocated first
        sorted_models = sorted(model_spend.keys(), key=lambda m: model_spend[m], reverse=True)

        for i, model in enumerate(sorted_models):
            entries = groups[model]
            spend = model_spend[model]
            spend_share = float(spend / total_spend)
            alt = self._pricing.get_cheaper_alternative(model) or ""

            # Calculate proportional allocation
            if i == len(sorted_models) - 1:
                # Last model gets whatever's left (avoids rounding errors)
                alloc_count = remaining_budget
            else:
                alloc_count = max(1, round(max_audits * spend_share))
                alloc_count = min(alloc_count, remaining_budget)

            # Can't sample more than we have
            alloc_count = min(alloc_count, len(entries))

            # Sample randomly within this model group
            sampled = rng.sample(entries, alloc_count)
            selected.extend(sampled)
            remaining_budget -= alloc_count

            allocations.append(
                ModelAllocation(
                    model=model,
                    cheaper_alternative=alt,
                    total_entries=len(entries),
                    total_spend=spend,
                    spend_share=spend_share,
                    allocated_audits=alloc_count,
                    selected_entries=sampled,
                )
            )

            if remaining_budget <= 0:
                break

        return selected, allocations

    # --- Strategy: Stratified (equal per model) ---

    def _stratified_sample(
        self,
        groups: dict[str, list[LogEntry]],
        max_audits: int,
        rng: random.Random,
    ) -> tuple[list[LogEntry], list[ModelAllocation]]:
        """Equal number of audits per model group."""

        num_groups = len(groups)
        per_group = max(1, max_audits // num_groups)

        allocations: list[ModelAllocation] = []
        selected: list[LogEntry] = []
        total_eligible = sum(len(v) for v in groups.values())

        for model, entries in groups.items():
            alt = self._pricing.get_cheaper_alternative(model) or ""
            alloc_count = min(per_group, len(entries))
            sampled = rng.sample(entries, alloc_count)
            selected.extend(sampled)

            spend = sum(e.actual_cost for e in entries)
            allocations.append(
                ModelAllocation(
                    model=model,
                    cheaper_alternative=alt,
                    total_entries=len(entries),
                    total_spend=spend,
                    spend_share=len(entries) / total_eligible if total_eligible else 0,
                    allocated_audits=alloc_count,
                    selected_entries=sampled,
                )
            )

        return selected, allocations

    # --- Strategy: Simple Random ---

    def _random_sample(
        self,
        groups: dict[str, list[LogEntry]],
        max_audits: int,
        rng: random.Random,
    ) -> tuple[list[LogEntry], list[ModelAllocation]]:
        """Flat random sampling across all eligible entries."""

        # Flatten all eligible entries
        all_entries = [e for entries in groups.values() for e in entries]
        sample_count = min(max_audits, len(all_entries))
        sampled = rng.sample(all_entries, sample_count)

        # Build allocations for reporting (group the sampled entries back by model)
        model_groups: dict[str, list[LogEntry]] = defaultdict(list)
        for entry in sampled:
            model_groups[entry.model].append(entry)

        total_eligible = len(all_entries)
        allocations: list[ModelAllocation] = []
        for model, selected_entries in model_groups.items():
            original_entries = groups.get(model, [])
            alt = self._pricing.get_cheaper_alternative(model) or ""
            spend = sum(e.actual_cost for e in original_entries)

            allocations.append(
                ModelAllocation(
                    model=model,
                    cheaper_alternative=alt,
                    total_entries=len(original_entries),
                    total_spend=spend,
                    spend_share=len(original_entries) / total_eligible if total_eligible else 0,
                    allocated_audits=len(selected_entries),
                    selected_entries=selected_entries,
                )
            )

        return sampled, allocations
