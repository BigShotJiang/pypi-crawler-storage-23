"""Judge module — compares teacher vs student outputs and scores quality.

The judge is an LLM that evaluates whether a cheaper model's response is
an acceptable replacement for an expensive model's response.

Usage:
    from token_aud.core.judge import judge_quality

    verdict = judge_quality(
        prompt="Explain Docker",
        teacher_response="Docker containers are...",
        student_response="Docker is a tool that...",
        judge_model="gpt-4o-mini",
    )
    print(verdict.score, verdict.reasoning)
"""

import json
import re
from dataclasses import dataclass

import litellm


# ---------------------------------------------------------------------------
# Judge prompt template
# ---------------------------------------------------------------------------
JUDGE_SYSTEM_PROMPT = """You are an expert quality evaluator for AI model outputs.

You will be given:
1. A USER PROMPT that was sent to an AI model
2. RESPONSE A — the output from the original (expensive) model
3. RESPONSE B — the output from a cheaper alternative model

Your job is to evaluate whether Response B is an acceptable replacement for Response A.

Evaluate on these criteria:
- Accuracy: Is the information in Response B correct and complete?
- Relevance: Does Response B fully address the user's request?
- Quality: Is Response B clear, well-structured, and professional?
- No regressions: Does Response B miss anything important that Response A included?

Return your evaluation as JSON and nothing else:
{
    "score": <float between 0.0 and 1.0>,
    "reasoning": "<2-3 sentence explanation>",
    "criteria": {
        "accuracy": <float between 0.0 and 1.0>,
        "relevance": <float between 0.0 and 1.0>,
        "quality": <float between 0.0 and 1.0>
    }
}

Scoring guide:
- 1.0: Response B is equal to or better than Response A
- 0.9: Minor differences that don't affect usefulness
- 0.8: Acceptable replacement — good enough for most use cases
- 0.7: Noticeable quality drop but still functional
- 0.5: Significant quality gap — important information missing
- Below 0.5: Unacceptable — the expensive model is clearly needed"""


def _build_judge_prompt(
    user_prompt: str,
    teacher_response: str,
    student_response: str,
) -> str:
    """Build the user message for the judge call."""
    return f"""## USER PROMPT
{user_prompt}

## RESPONSE A (Original — Expensive Model)
{teacher_response}

## RESPONSE B (Alternative — Cheaper Model)
{student_response}

Evaluate Response B as a replacement for Response A. Return JSON only."""


# ---------------------------------------------------------------------------
# Judge verdict (parsed output)
# ---------------------------------------------------------------------------
@dataclass
class JudgeVerdict:
    """Parsed result from the judge LLM."""

    score: float  # 0.0 to 1.0
    reasoning: str
    accuracy: float
    relevance: float
    quality: float
    raw_response: str  # The full judge response for debugging


# ---------------------------------------------------------------------------
# Call the judge
# ---------------------------------------------------------------------------
def judge_quality(
    prompt: str,
    teacher_response: str,
    student_response: str,
    judge_model: str = "gpt-4o-mini",
) -> JudgeVerdict:
    """Send teacher + student outputs to a judge LLM and get a quality score.

    Args:
        prompt: The original user prompt.
        teacher_response: The expensive model's response.
        student_response: The cheaper model's response.
        judge_model: Which model to use as the judge.

    Returns:
        JudgeVerdict with score, reasoning, and per-criteria breakdown.
    """
    user_message = _build_judge_prompt(prompt, teacher_response, student_response)

    response = litellm.completion(
        model=judge_model,
        messages=[
            {"role": "system", "content": JUDGE_SYSTEM_PROMPT},
            {"role": "user", "content": user_message},
        ],
        temperature=0.0,  # Deterministic judging
        max_tokens=500,
    )

    raw = response.choices[0].message.content or ""
    return _parse_verdict(raw)


# ---------------------------------------------------------------------------
# Parse the judge's response
# ---------------------------------------------------------------------------
def _parse_verdict(raw: str) -> JudgeVerdict:
    """Parse the judge LLM's response into a JudgeVerdict.

    Tries JSON first, then regex fallback, then defaults.
    """
    # Try 1: Clean JSON parse
    try:
        data = json.loads(raw.strip())
        return _verdict_from_dict(data, raw)
    except (json.JSONDecodeError, KeyError, TypeError):
        pass

    # Try 2: Extract JSON from markdown code block (```json ... ```)
    json_match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", raw, re.DOTALL)
    if json_match:
        try:
            data = json.loads(json_match.group(1))
            return _verdict_from_dict(data, raw)
        except (json.JSONDecodeError, KeyError, TypeError):
            pass

    # Try 3: Find any JSON-like object in the response
    brace_match = re.search(r"\{.*\}", raw, re.DOTALL)
    if brace_match:
        try:
            data = json.loads(brace_match.group(0))
            return _verdict_from_dict(data, raw)
        except (json.JSONDecodeError, KeyError, TypeError):
            pass

    # Try 4: Regex for just the score
    score_match = re.search(r'"score"\s*:\s*([\d.]+)', raw)
    if score_match:
        score = _clamp(float(score_match.group(1)))
        return JudgeVerdict(
            score=score,
            reasoning="(Could not fully parse judge response)",
            accuracy=score,
            relevance=score,
            quality=score,
            raw_response=raw,
        )

    # Fallback: unparseable — return 0.0 (conservative)
    return JudgeVerdict(
        score=0.0,
        reasoning="(Judge response could not be parsed)",
        accuracy=0.0,
        relevance=0.0,
        quality=0.0,
        raw_response=raw,
    )


def _verdict_from_dict(data: dict, raw: str) -> JudgeVerdict:
    """Build a JudgeVerdict from a parsed JSON dict."""
    criteria = data.get("criteria", {})
    return JudgeVerdict(
        score=_clamp(float(data["score"])),
        reasoning=str(data.get("reasoning", "")),
        accuracy=_clamp(float(criteria.get("accuracy", data["score"]))),
        relevance=_clamp(float(criteria.get("relevance", data["score"]))),
        quality=_clamp(float(criteria.get("quality", data["score"]))),
        raw_response=raw,
    )


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    """Clamp a value to [low, high]."""
    return max(low, min(high, value))
