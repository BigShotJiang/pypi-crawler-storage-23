"""Auditor — orchestrates the Student-Teacher-Judge pipeline.

Takes sampled LogEntries, runs each through:
1. Student call (cheaper model, same prompt)
2. Judge call (compare teacher vs student)
3. Score + build AuditResult

Uses ThreadPoolExecutor for concurrent API calls with configurable parallelism.

Usage:
    from token_aud.core.auditor import Auditor

    auditor = Auditor(pricing_engine=engine)
    results = auditor.run(selected_entries, progress_callback=print)
"""

from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from decimal import Decimal
import json
from pathlib import Path
import time

import litellm

from token_aud.core.judge import JudgeVerdict, judge_quality
from token_aud.core.pricing import PricingEngine
from token_aud.models.schemas import AuditResult, LogEntry

DEBUG_LOG_PATH = Path("/Users/shyqyridogjani/Documents/projects/token-aud/.cursor/debug-4ad833.log")
DEBUG_SESSION_ID = "4ad833"


def _debug_log(run_id: str, hypothesis_id: str, location: str, message: str, data: dict) -> None:
    payload = {
        "sessionId": DEBUG_SESSION_ID,
        "runId": run_id,
        "hypothesisId": hypothesis_id,
        "location": location,
        "message": message,
        "data": data,
        "timestamp": int(time.time() * 1000),
    }
    with DEBUG_LOG_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(payload, ensure_ascii=True) + "\n")


# ---------------------------------------------------------------------------
# Audit batch result
# ---------------------------------------------------------------------------
@dataclass
class AuditError:
    """A single failed audit with context."""

    log_entry_id: str
    model: str
    error: str


@dataclass
class AuditBatchResult:
    """Result of running audits on a batch of entries."""

    results: list[AuditResult] = field(default_factory=list)
    errors: list[AuditError] = field(default_factory=list)
    total_student_cost: Decimal = Decimal("0")
    total_judge_cost: Decimal = Decimal("0")

    @property
    def total_audit_cost(self) -> Decimal:
        return self.total_student_cost + self.total_judge_cost

    @property
    def success_count(self) -> int:
        return len(self.results)

    @property
    def error_count(self) -> int:
        return len(self.errors)

    @property
    def safe_to_switch_count(self) -> int:
        return sum(1 for r in self.results if r.is_safe_to_switch)

    @property
    def total_potential_savings(self) -> Decimal:
        return sum(
            (r.potential_savings for r in self.results if r.is_safe_to_switch),
            Decimal("0"),
        )


# ---------------------------------------------------------------------------
# The Auditor
# ---------------------------------------------------------------------------
class Auditor:
    """Runs the Student-Teacher-Judge audit pipeline."""

    def __init__(
        self,
        pricing_engine: PricingEngine,
        judge_model: str = "claude-haiku-4-5",
        quality_threshold: float = 0.8,
        max_workers: int = 10,
    ) -> None:
        self._pricing = pricing_engine
        self._judge_model = judge_model
        self._quality_threshold = quality_threshold
        self._max_workers = max_workers

    def run(
        self,
        entries: list[LogEntry],
        progress_callback: Callable[[int, int], None] | None = None,
    ) -> AuditBatchResult:
        """Run the audit pipeline on a batch of sampled entries.

        Args:
            entries: LogEntries selected by the sampler (must have prompt_text).
            progress_callback: Called with (completed_count, total_count) after each audit.

        Returns:
            AuditBatchResult with all results, errors, and cost totals.
        """
        batch = AuditBatchResult()
        total = len(entries)
        run_id = f"auditor-run-{int(time.time())}"

        # region agent log
        _debug_log(
            run_id=run_id,
            hypothesis_id="H0",
            location="auditor.py:run:start",
            message="Audit run started",
            data={"total_entries": total, "judge_model": self._judge_model, "max_workers": self._max_workers},
        )
        # endregion

        if total == 0:
            return batch

        completed = 0

        with ThreadPoolExecutor(max_workers=self._max_workers) as pool:
            futures = {
                pool.submit(self._audit_one, entry): entry
                for entry in entries
            }

            for future in as_completed(futures):
                entry = futures[future]
                completed += 1

                try:
                    result, student_cost, judge_cost = future.result()
                    batch.results.append(result)
                    batch.total_student_cost += student_cost
                    batch.total_judge_cost += judge_cost
                except Exception as exc:
                    # region agent log
                    _debug_log(
                        run_id=run_id,
                        hypothesis_id="H4",
                        location="auditor.py:run:future-exception",
                        message="Audit future failed",
                        data={
                            "entry_model": entry.model,
                            "entry_id": str(entry.id),
                            "error_type": type(exc).__name__,
                            "error": str(exc),
                        },
                    )
                    # endregion
                    batch.errors.append(
                        AuditError(
                            log_entry_id=str(entry.id),
                            model=entry.model,
                            error=str(exc),
                        )
                    )

                if progress_callback:
                    progress_callback(completed, total)

        return batch

    def _audit_one(
        self, entry: LogEntry
    ) -> tuple[AuditResult, Decimal, Decimal]:
        """Audit a single LogEntry. Returns (AuditResult, student_cost, judge_cost).

        Raises on failure so the caller can handle it.
        """
        # --- Determine the student model ---
        student_model = self._pricing.get_cheaper_alternative(entry.model)
        run_id = f"audit-one-{entry.id}"
        student_call_model = self._litellm_model_id(student_model)
        judge_call_model = self._litellm_model_id(self._judge_model)

        # region agent log
        _debug_log(
            run_id=run_id,
            hypothesis_id="H1",
            location="auditor.py:_audit_one:student-selection",
            message="Selected student model",
            data={
                "teacher_model": entry.model,
                "student_model": student_model,
                "student_call_model": student_call_model,
                "judge_call_model": judge_call_model,
                "provider": entry.provider,
            },
        )
        # endregion
        if student_model is None:
            raise ValueError(f"No cheaper alternative for {entry.model}")

        if not entry.prompt_text:
            raise ValueError("LogEntry has no prompt_text — cannot audit")

        teacher_response = entry.response_text or ""

        # --- Step 1: Student call ---
        try:
            student_response_obj = litellm.completion(
                model=student_call_model,
                messages=[{"role": "user", "content": entry.prompt_text}],
                temperature=0.0,
                max_tokens=2000,
            )
        except Exception as exc:
            # region agent log
            _debug_log(
                run_id=run_id,
                hypothesis_id="H2",
                location="auditor.py:_audit_one:student-call",
                message="Student call failed",
                data={
                    "student_model": student_model,
                    "student_call_model": student_call_model,
                    "teacher_model": entry.model,
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                },
            )
            # endregion
            raise

        student_text = student_response_obj.choices[0].message.content or ""
        student_usage = student_response_obj.usage
        student_prompt_tokens = student_usage.prompt_tokens or 0
        student_completion_tokens = student_usage.completion_tokens or 0
        student_cost = self._pricing.calculate_cost(
            student_model, student_prompt_tokens, student_completion_tokens
        )

        # --- Step 2: Judge call ---
        try:
            verdict: JudgeVerdict = judge_quality(
                prompt=entry.prompt_text,
                teacher_response=teacher_response,
                student_response=student_text,
                judge_model=judge_call_model,
            )
        except Exception as exc:
            # region agent log
            _debug_log(
                run_id=run_id,
                hypothesis_id="H3",
                location="auditor.py:_audit_one:judge-call",
                message="Judge call failed",
                data={
                    "judge_model": self._judge_model,
                    "judge_call_model": judge_call_model,
                    "student_model": student_model,
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                },
            )
            # endregion
            raise

        # Estimate judge cost (the judge prompt includes both responses)
        # Approximate: prompt_tokens ~ len(prompt + teacher + student) / 4
        judge_input_estimate = (
            len(entry.prompt_text) + len(teacher_response) + len(student_text)
        ) // 4
        judge_output_estimate = 200  # JSON response is ~200 tokens
        judge_cost = self._pricing.calculate_cost(
            self._judge_model, judge_input_estimate, judge_output_estimate
        )

        # --- Step 3: Build AuditResult ---
        is_safe = verdict.score >= self._quality_threshold
        potential_savings = entry.actual_cost - student_cost if is_safe else Decimal("0")

        audit_result = AuditResult(
            log_entry_id=entry.id,
            student_model=student_model,
            student_response=student_text,
            student_prompt_tokens=student_prompt_tokens,
            student_completion_tokens=student_completion_tokens,
            student_cost=student_cost,
            judge_model=self._judge_model,
            quality_score=verdict.score,
            judge_reasoning=verdict.reasoning,
            is_safe_to_switch=is_safe,
            potential_savings=potential_savings,
        )

        return audit_result, student_cost, judge_cost

    def _litellm_model_id(self, model: str | None) -> str:
        """Normalize model name for LiteLLM provider routing."""
        if not model:
            return ""
        if "/" in model:
            return model
        pricing = self._pricing.get_pricing(model)
        if pricing is None:
            return model
        if pricing.provider == "openai":
            return model
        return f"{pricing.provider}/{model}"
