"""Run the token-aud API server."""

import uvicorn


def main() -> None:
    uvicorn.run(
        "token_aud.api.app:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )
