"""FastAPI application for token-aud — Phase 2 dashboard backend."""

from pathlib import Path
from tempfile import NamedTemporaryFile

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from token_aud.config import settings
from token_aud.core.auditor import Auditor
from token_aud.core.pricing import PricingEngine
from token_aud.core.sampler import Sampler
from token_aud.core.savings import calculate_savings
from token_aud.models.schemas import SavingsReport
from token_aud.parsers.base import ColumnMapping, parse_file


def _resolve_mapping(provider: str | None, mapping_json: str | None) -> ColumnMapping:
    """Resolve column mapping from provider preset or custom JSON."""
    if mapping_json and mapping_json.strip():
        import json
        raw = json.loads(mapping_json)
        return ColumnMapping(**raw)

    if provider == "openai":
        from token_aud.parsers.openai import OPENAI_FULL_LOG_MAPPING
        return OPENAI_FULL_LOG_MAPPING
    if provider == "anthropic":
        from token_aud.parsers.anthropic import ANTHROPIC_FULL_LOG_MAPPING
        return ANTHROPIC_FULL_LOG_MAPPING

    return ColumnMapping(
        timestamp="timestamp",
        model="model",
        prompt_tokens="prompt_tokens",
        completion_tokens="completion_tokens",
        cost="cost",
        prompt_text="prompt",
        response_text="response",
    )


app = FastAPI(
    title="token-aud API",
    description="AI cost optimization — analyze LLM spending and find savings.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "service": "token-aud"}


@app.get("/api/models")
def list_models() -> list[dict]:
    """Return all known models with pricing info."""
    engine = PricingEngine()
    result = []
    for name in engine.list_models():
        p = engine.get_pricing(name)
        if p is None:
            continue
        result.append({
            "model": p.model,
            "provider": p.provider,
            "input_cost_per_million": float(p.input_cost_per_token * 1_000_000),
            "output_cost_per_million": float(p.output_cost_per_token * 1_000_000),
            "cheaper_alternative": p.cheaper_alternative,
        })
    return result


@app.post("/api/analyze", response_model=SavingsReport)
async def analyze(
    file: UploadFile = File(...),
    provider: str | None = Form(None),
    mapping: str | None = Form(None),
    max_audits: int = Form(settings.max_audit_count),
    strategy: str = Form(settings.sampling_strategy),
    seed: int | None = Form(None),
    dry_run: bool = Form(True),
    quality_threshold: float = Form(settings.quality_threshold),
    judge_model: str = Form(settings.default_judge_model),
    workers: int = Form(10),
) -> SavingsReport:
    """Upload a usage CSV/JSONL, run the audit pipeline, return savings report."""
    if not file.filename or not file.filename.lower().endswith((".csv", ".jsonl")):
        raise HTTPException(400, "File must be CSV or JSONL")

    content = await file.read()
    suffix = ".csv" if file.filename.lower().endswith(".csv") else ".jsonl"

    with NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(content)
        tmp_path = Path(tmp.name)

    try:
        col_mapping = _resolve_mapping(provider, mapping)
        parse_result = parse_file(tmp_path, col_mapping)
    finally:
        tmp_path.unlink(missing_ok=True)

    if parse_result.success_count == 0:
        raise HTTPException(
            400,
            f"No entries parsed. Errors: {parse_result.errors[:5]}" if parse_result.errors else "Check column mapping.",
        )

    pricing = PricingEngine()

    for entry in parse_result.entries:
        if entry.actual_cost == 0:
            entry.actual_cost = pricing.calculate_cost(
                entry.model, entry.prompt_tokens, entry.completion_tokens
            )

    sampler = Sampler(pricing_engine=pricing)
    sample_result = sampler.select(
        parse_result.entries,
        max_audits=max_audits,
        seed=seed,
        strategy=strategy,
    )

    if dry_run or sample_result.total_selected == 0:
        return calculate_savings(
            parse_result.entries, [], pricing, quality_threshold
        )

    auditor = Auditor(
        pricing_engine=pricing,
        judge_model=judge_model,
        quality_threshold=quality_threshold,
        max_workers=workers,
    )
    batch = auditor.run(sample_result.selected)

    return calculate_savings(
        parse_result.entries, batch.results, pricing, quality_threshold
    )
