"""CLI command: token-aud configure — show and manage settings."""

from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.table import Table

from token_aud.config import settings
from token_aud.core.pricing import PricingEngine

console = Console()


def configure(
    show_models: Annotated[
        bool,
        typer.Option("--models", help="List all known models and their pricing"),
    ] = False,
    show_settings: Annotated[
        bool,
        typer.Option("--settings", help="Show current configuration"),
    ] = False,
) -> None:
    """Show configuration and available models.

    Examples:

        token-aud configure --settings

        token-aud configure --models
    """
    if not show_models and not show_settings:
        # Default: show settings
        show_settings = True

    if show_settings:
        _print_settings()

    if show_models:
        _print_models()


def _print_settings() -> None:
    """Display current settings."""
    console.print("\n[bold]Current Configuration[/bold]\n")

    table = Table(show_header=True, header_style="bold", border_style="dim")
    table.add_column("Setting", min_width=25)
    table.add_column("Value", min_width=30)
    table.add_column("Source", min_width=10)

    rows = [
        ("Sampling strategy", settings.sampling_strategy, "config"),
        ("Max audit count", str(settings.max_audit_count), "config"),
        ("Quality threshold", str(settings.quality_threshold), "config"),
        ("Sampling seed", str(settings.sampling_seed or "random"), "config"),
        ("Default student model", settings.default_student_model, "config"),
        ("Default judge model", settings.default_judge_model, "config"),
        ("Database path", str(settings.db_path), "config"),
        ("Output directory", str(settings.output_dir), "config"),
        ("OpenAI API key", _mask_key(settings.openai_api_key), "env"),
        ("Anthropic API key", _mask_key(settings.anthropic_api_key), "env"),
        ("Google API key", _mask_key(settings.google_api_key), "env"),
    ]

    for name, value, source in rows:
        table.add_row(name, value, source)

    console.print(table)
    console.print(
        "\n[dim]Set values via environment variables (TOKEN_AUD_ prefix) or .env file.[/dim]\n"
    )


def _print_models() -> None:
    """Display all known models with pricing."""
    console.print("\n[bold]Known Models & Pricing[/bold]\n")

    engine = PricingEngine()

    table = Table(show_header=True, header_style="bold", border_style="dim")
    table.add_column("Model", min_width=22)
    table.add_column("Provider", min_width=10)
    table.add_column("Input $/1M", justify="right", min_width=10)
    table.add_column("Output $/1M", justify="right", min_width=10)
    table.add_column("Cheaper Alt.", min_width=20)

    for model_name in engine.list_models():
        p = engine.get_pricing(model_name)
        if p is None:
            continue
        alt = p.cheaper_alternative or "[dim]— cheapest[/dim]"
        input_per_m = p.input_cost_per_token * 1_000_000
        output_per_m = p.output_cost_per_token * 1_000_000

        table.add_row(
            p.model,
            p.provider,
            f"${input_per_m:,.2f}",
            f"${output_per_m:,.2f}",
            alt,
        )

    console.print(table)
    console.print(f"\n[dim]{len(engine.list_models())} models loaded.[/dim]\n")


def _mask_key(key: str) -> str:
    """Mask an API key for display."""
    if not key:
        return "[yellow]not set[/yellow]"
    return key[:8] + "..." + key[-4:]
