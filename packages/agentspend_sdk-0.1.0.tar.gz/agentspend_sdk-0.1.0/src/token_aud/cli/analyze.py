"""CLI command: token-aud analyze — the full pipeline in one command.

Parses a usage file, samples entries, runs the Student-Teacher-Judge audit,
calculates savings, and prints the terminal report.
"""

from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn

from token_aud.config import settings
from token_aud.core.auditor import Auditor
from token_aud.core.pricing import PricingEngine
from token_aud.core.sampler import Sampler
from token_aud.core.savings import calculate_savings
from token_aud.parsers.base import ColumnMapping, parse_file
from token_aud.reports.html import generate_html
from token_aud.reports.terminal import print_report

console = Console()


def analyze(
    file: Annotated[Path, typer.Argument(help="Path to CSV or JSONL usage log file")],
    # --- Provider presets ---
    provider: Annotated[
        Optional[str],
        typer.Option("--provider", "-p", help="Provider preset: 'openai' or 'anthropic'"),
    ] = None,
    # --- Generic mapping ---
    mapping: Annotated[
        Optional[Path],
        typer.Option("--mapping", "-m", help="Path to column mapping JSON file"),
    ] = None,
    # --- Sampling ---
    max_audits: Annotated[
        int,
        typer.Option("--max-audits", help="Maximum number of entries to audit"),
    ] = settings.max_audit_count,
    strategy: Annotated[
        str,
        typer.Option("--strategy", help="Sampling strategy: 'cost_weighted', 'stratified', 'random'"),
    ] = settings.sampling_strategy,
    seed: Annotated[
        Optional[int],
        typer.Option("--seed", help="Random seed for reproducible sampling"),
    ] = settings.sampling_seed,
    # --- Audit ---
    judge_model: Annotated[
        str,
        typer.Option("--judge-model", help="Model to use as the quality judge"),
    ] = settings.default_judge_model,
    threshold: Annotated[
        float,
        typer.Option("--threshold", help="Quality score threshold for safe-to-switch (0.0-1.0)"),
    ] = settings.quality_threshold,
    workers: Annotated[
        int,
        typer.Option("--workers", help="Number of concurrent audit workers"),
    ] = 10,
    # --- Output ---
    html: Annotated[
        Optional[Path],
        typer.Option("--html", help="Also generate an HTML report at this path"),
    ] = None,
    # --- Dry run ---
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Parse and sample only — don't call LLM APIs"),
    ] = False,
) -> None:
    """Analyze LLM usage data and find cost savings.

    Runs the full pipeline: parse → sample → audit → report.

    Examples:

        token-aud analyze usage.csv --mapping my_columns.json

        token-aud analyze openai_export.csv --provider openai --dry-run

        token-aud analyze logs.csv -m mapping.json --max-audits 50 --html report.html
    """
    pricing = PricingEngine()

    # --- Step 1: Parse ---
    console.print(f"\n[bold]Step 1/4:[/bold] Parsing [cyan]{file.name}[/cyan]...")
    col_mapping = _resolve_mapping(provider, mapping)
    parse_result = parse_file(file, col_mapping)

    if parse_result.success_count == 0:
        console.print("[bold red]No entries parsed. Check your file and column mapping.[/bold red]")
        raise typer.Exit(1)

    console.print(
        f"  Parsed [green]{parse_result.success_count:,}[/green] entries "
        f"({parse_result.error_count} errors). "
        f"Prompt text: {'[green]yes[/green]' if parse_result.has_prompt_text else '[yellow]no[/yellow]'}"
    )

    # --- Step 2: Sample ---
    console.print(f"\n[bold]Step 2/4:[/bold] Sampling (strategy: [cyan]{strategy}[/cyan])...")
    sampler = Sampler(pricing_engine=pricing)
    sample_result = sampler.select(
        parse_result.entries,
        max_audits=max_audits,
        seed=seed,
        strategy=strategy,
    )

    console.print(f"  Selected [green]{sample_result.total_selected:,}[/green] entries for audit")
    console.print(f"  Skipped: {sample_result.skipped_no_prompt:,} (no prompt), "
                  f"{sample_result.skipped_no_alternative:,} (already cheapest), "
                  f"{sample_result.skipped_unknown_model:,} (unknown model)")

    if sample_result.total_selected == 0 and not dry_run:
        console.print(
            "\n[yellow]No entries eligible for auditing. "
            "This may be because no entries have prompt text or all models are already optimal.[/yellow]"
        )
        # Still generate a cost-only report
        report = calculate_savings(parse_result.entries, [], pricing, threshold)
        print_report(report, console)
        if html:
            generate_html(report, html)
            console.print(f"  HTML report: [cyan]{html}[/cyan]")
        raise typer.Exit(0)

    # --- Step 3: Audit ---
    if dry_run:
        console.print(f"\n[bold]Step 3/4:[/bold] [yellow]Skipped (dry run)[/yellow]")
        console.print(f"\n[bold]Step 4/4:[/bold] Generating cost-only report...")
        report = calculate_savings(parse_result.entries, [], pricing, threshold)
    else:
        console.print(
            f"\n[bold]Step 3/4:[/bold] Auditing {sample_result.total_selected} entries "
            f"({workers} workers)..."
        )

        auditor = Auditor(
            pricing_engine=pricing,
            judge_model=judge_model,
            quality_threshold=threshold,
            max_workers=workers,
        )

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Auditing...", total=sample_result.total_selected)

            def on_progress(done: int, total: int) -> None:
                progress.update(task, completed=done)

            batch = auditor.run(sample_result.selected, progress_callback=on_progress)

        console.print(
            f"  Completed: [green]{batch.success_count}[/green] OK, "
            f"[red]{batch.error_count}[/red] errors"
        )
        console.print(
            f"  Audit cost: [dim]~${batch.total_audit_cost:,.4f}[/dim]"
        )

        # --- Step 4: Report ---
        console.print(f"\n[bold]Step 4/4:[/bold] Generating savings report...")
        report = calculate_savings(
            parse_result.entries, batch.results, pricing, threshold
        )

    # Terminal report
    print_report(report, console)

    # HTML report
    if html:
        generate_html(report, html)
        console.print(f"  HTML report saved to: [cyan]{html}[/cyan]\n")


# ---------------------------------------------------------------------------
# Mapping resolution
# ---------------------------------------------------------------------------
def _resolve_mapping(provider: str | None, mapping_path: Path | None) -> ColumnMapping:
    """Resolve the column mapping from provider preset or custom mapping file."""
    if mapping_path:
        import json
        raw = json.loads(mapping_path.read_text())
        return ColumnMapping(**raw)

    if provider == "openai":
        from token_aud.parsers.openai import OPENAI_FULL_LOG_MAPPING
        return OPENAI_FULL_LOG_MAPPING
    if provider == "anthropic":
        from token_aud.parsers.anthropic import ANTHROPIC_FULL_LOG_MAPPING
        return ANTHROPIC_FULL_LOG_MAPPING

    # Default: assume common column names
    return ColumnMapping(
        timestamp="timestamp",
        model="model",
        prompt_tokens="prompt_tokens",
        completion_tokens="completion_tokens",
        cost="cost",
        prompt_text="prompt",
        response_text="response",
    )
