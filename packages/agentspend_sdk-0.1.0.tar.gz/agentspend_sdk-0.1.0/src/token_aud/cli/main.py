"""CLI entry point for token-aud."""

import typer
from rich.console import Console

from token_aud.cli.analyze import analyze
from token_aud.cli.configure import configure

app = typer.Typer(
    name="token-aud",
    help="AI cost optimization — analyze LLM spending and find savings.",
    no_args_is_help=True,
)
console = Console()

# Register commands
app.command(name="analyze", help="Analyze usage data and find cost savings")(analyze)
app.command(name="configure", help="Show configuration and available models")(configure)


@app.command()
def hello() -> None:
    """Verify token-aud is installed and working."""
    console.print("[bold green]token-aud is ready.[/bold green]")
