"""SQLAlchemy ORM models — database tables for token-aud."""

import uuid
from datetime import datetime
from decimal import Decimal

from sqlalchemy import JSON, Boolean, DateTime, Float, Integer, Numeric, String, Text, Uuid
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    """Base class for all ORM models."""


# ---------------------------------------------------------------------------
# LogEntry table
# ---------------------------------------------------------------------------
class LogEntryRow(Base):
    __tablename__ = "log_entries"

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    timestamp: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    model: Mapped[str] = mapped_column(String(100), nullable=False)
    provider: Mapped[str] = mapped_column(String(50), nullable=False)
    prompt_tokens: Mapped[int] = mapped_column(Integer, nullable=False)
    completion_tokens: Mapped[int] = mapped_column(Integer, nullable=False)
    total_tokens: Mapped[int] = mapped_column(Integer, nullable=False)
    actual_cost: Mapped[Decimal] = mapped_column(Numeric(12, 6), nullable=False)
    prompt_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    response_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    metadata_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    # Relationship: one LogEntry can have zero or one AuditResult
    audit: Mapped["AuditResultRow | None"] = relationship(back_populates="log_entry")


# ---------------------------------------------------------------------------
# AuditResult table
# ---------------------------------------------------------------------------
class AuditResultRow(Base):
    __tablename__ = "audit_results"

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    log_entry_id: Mapped[uuid.UUID] = mapped_column(
        Uuid, nullable=False, unique=True
    )
    student_model: Mapped[str] = mapped_column(String(100), nullable=False)
    student_response: Mapped[str] = mapped_column(Text, nullable=False)
    student_prompt_tokens: Mapped[int] = mapped_column(Integer, nullable=False)
    student_completion_tokens: Mapped[int] = mapped_column(Integer, nullable=False)
    student_cost: Mapped[Decimal] = mapped_column(Numeric(12, 6), nullable=False)
    judge_model: Mapped[str] = mapped_column(String(100), nullable=False)
    quality_score: Mapped[float] = mapped_column(Float, nullable=False)
    judge_reasoning: Mapped[str] = mapped_column(Text, nullable=False)
    is_safe_to_switch: Mapped[bool] = mapped_column(Boolean, nullable=False)
    potential_savings: Mapped[Decimal] = mapped_column(Numeric(12, 6), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)

    # Relationship back to LogEntry
    log_entry: Mapped["LogEntryRow"] = relationship(back_populates="audit")


# ---------------------------------------------------------------------------
# SavingsReport table
# ---------------------------------------------------------------------------
class SavingsReportRow(Base):
    __tablename__ = "savings_reports"

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    total_entries: Mapped[int] = mapped_column(Integer, nullable=False)
    total_audited: Mapped[int] = mapped_column(Integer, nullable=False)
    total_actual_cost: Mapped[Decimal] = mapped_column(Numeric(12, 6), nullable=False)
    total_potential_savings: Mapped[Decimal] = mapped_column(Numeric(12, 6), nullable=False)
    savings_percentage: Mapped[float] = mapped_column(Float, nullable=False)
    model_recommendations: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    confidence_level: Mapped[float] = mapped_column(Float, nullable=False)
