"""Pydantic models — the core data shapes for token-aud."""

from datetime import datetime
from decimal import Decimal
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# LogEntry: A single LLM API call from the user's historical data
# ---------------------------------------------------------------------------
class LogEntry(BaseModel):
    """One row of usage data — what did you spend?"""

    id: UUID = Field(default_factory=uuid4)
    timestamp: datetime
    model: str = Field(description="Model name, e.g. 'gpt-4o', 'claude-3.5-sonnet'")
    provider: str = Field(description="Provider name, e.g. 'openai', 'anthropic'")
    prompt_tokens: int = Field(ge=0)
    completion_tokens: int = Field(ge=0)
    total_tokens: int = Field(ge=0)
    actual_cost: Decimal = Field(ge=0, decimal_places=6)
    prompt_text: str | None = Field(default=None, description="The prompt (needed for auditing)")
    response_text: str | None = Field(
        default=None, description="The response (needed for judging)"
    )
    metadata: dict | None = Field(
        default=None, description="Flexible field: department, api_key label, tags, etc."
    )


# ---------------------------------------------------------------------------
# AuditResult: The Student-Teacher-Judge comparison for one LogEntry
# ---------------------------------------------------------------------------
class AuditResult(BaseModel):
    """Could you have spent less? Result of auditing one log entry."""

    id: UUID = Field(default_factory=uuid4)
    log_entry_id: UUID = Field(description="FK to the LogEntry that was audited")
    student_model: str = Field(description="The cheaper model tested, e.g. 'gpt-4o-mini'")
    student_response: str = Field(description="What the cheaper model returned")
    student_prompt_tokens: int = Field(ge=0)
    student_completion_tokens: int = Field(ge=0)
    student_cost: Decimal = Field(ge=0, decimal_places=6)
    judge_model: str = Field(description="The model that scored quality")
    quality_score: float = Field(ge=0.0, le=1.0, description="Judge's quality rating 0.0–1.0")
    judge_reasoning: str = Field(description="Why the judge gave that score")
    is_safe_to_switch: bool = Field(description="True if quality_score >= threshold")
    potential_savings: Decimal = Field(
        description="actual_cost - student_cost (positive = money saved)"
    )
    created_at: datetime = Field(default_factory=datetime.now)


# ---------------------------------------------------------------------------
# ModelRecommendation: Per-model breakdown inside a SavingsReport
# ---------------------------------------------------------------------------
class ModelRecommendation(BaseModel):
    """Savings breakdown for one specific model."""

    current_model: str
    provider: str
    current_spend: Decimal
    entry_count: int = Field(description="Total log entries for this model")
    status: str = Field(
        description="'switch_recommended', 'premium_required', 'already_optimal', 'not_audited'"
    )
    recommended_model: str | None = None
    projected_savings: Decimal = Decimal("0")
    audits_run: int = 0
    avg_quality_score: float = 0.0
    safe_switch_rate: float = Field(
        default=0.0, ge=0.0, le=1.0,
        description="Fraction of audits that passed the quality threshold",
    )
    confidence: float = Field(
        default=0.0, ge=0.0, le=1.0,
        description="Confidence in this recommendation based on sample size",
    )


# ---------------------------------------------------------------------------
# SavingsReport: The executive summary — one per analysis run
# ---------------------------------------------------------------------------
class SavingsReport(BaseModel):
    """Here's the executive summary. Aggregation across many audits."""

    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=datetime.now)
    total_entries: int = Field(ge=0, description="How many log entries were analyzed")
    total_audited: int = Field(ge=0, description="How many were sampled for audit")
    total_actual_cost: Decimal = Field(ge=0)
    total_potential_savings: Decimal = Field(ge=0)
    savings_percentage: float = Field(ge=0.0, description="potential / actual * 100")
    model_recommendations: list[ModelRecommendation] = Field(default_factory=list)
    confidence_level: float = Field(
        ge=0.0, le=1.0, description="Statistical confidence based on sample size"
    )
