"""Configuration for token-aud — reads from environment variables and .env files."""

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """All token-aud settings. Override via environment variables or .env file."""

    model_config = SettingsConfigDict(
        env_prefix="TOKEN_AUD_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- Database ---
    db_path: Path = Path.home() / ".token-aud" / "token_aud.db"

    # --- Sampling ---
    audit_sample_rate: float = 0.05  # Fallback rate for simple random sampling
    max_audit_count: int = 200  # Hard cap on total audits per run
    sampling_strategy: str = "cost_weighted"  # "random", "stratified", or "cost_weighted"
    sampling_seed: int | None = None  # Set for reproducible sampling (None = random)
    quality_threshold: float = 0.8  # Score >= 0.8 means "safe to switch"

    # --- LLM API Keys (for the Student and Judge calls) ---
    openai_api_key: str = ""
    anthropic_api_key: str = ""
    google_api_key: str = ""

    # --- Default models for the audit pipeline ---
    default_student_model: str = "gpt-4o-mini"
    default_judge_model: str = "gpt-4o-mini"

    # --- Output ---
    output_dir: Path = Path.cwd() / "reports_output"


# Singleton instance — import this wherever you need settings
settings = Settings()
