"""OpenAI usage export parser — preset column mapping.

OpenAI billing dashboard exports CSVs with these columns:
    timestamp, model, operation, prompt_tokens, completion_tokens, total_tokens, cost

Note: billing exports do NOT include prompt/response text.
For full audit capability, users need to provide logs with prompt text.
"""

from pathlib import Path

from token_aud.parsers.base import ColumnMapping, ParseResult, parse_file

# OpenAI billing dashboard export mapping
OPENAI_MAPPING = ColumnMapping(
    timestamp="timestamp",
    model="model",
    provider=None,
    provider_value="openai",
    prompt_tokens="prompt_tokens",
    completion_tokens="completion_tokens",
    total_tokens="total_tokens",
    cost="cost",
    prompt_text=None,
    response_text=None,
)

# OpenAI full log mapping (for users who log their own traffic)
OPENAI_FULL_LOG_MAPPING = ColumnMapping(
    timestamp="timestamp",
    model="model",
    provider=None,
    provider_value="openai",
    prompt_tokens="prompt_tokens",
    completion_tokens="completion_tokens",
    total_tokens="total_tokens",
    cost="cost",
    prompt_text="prompt",
    response_text="response",
)


def parse_openai_export(path: Path) -> ParseResult:
    """Parse an OpenAI billing dashboard CSV export."""
    return parse_file(path, OPENAI_MAPPING)


def parse_openai_full_log(path: Path) -> ParseResult:
    """Parse a full OpenAI log file (with prompt and response text)."""
    return parse_file(path, OPENAI_FULL_LOG_MAPPING)
