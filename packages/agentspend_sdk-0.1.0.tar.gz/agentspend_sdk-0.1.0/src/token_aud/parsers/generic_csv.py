"""Generic CSV/JSONL parser — user provides their own column mapping.

This is the PRIMARY parser for users with custom logging setups. The user
provides a JSON mapping file that tells us which columns correspond to which
fields in their data.

Example mapping file (mapping.json):
{
    "timestamp": "created_at",
    "model": "model_name",
    "prompt_tokens": "input_tokens",
    "completion_tokens": "output_tokens",
    "cost": "total_usd",
    "prompt_text": "user_message",
    "response_text": "assistant_message"
}
"""

import json
from pathlib import Path

from token_aud.parsers.base import ColumnMapping, ParseResult, parse_file


def load_mapping(mapping_path: Path) -> ColumnMapping:
    """Load a ColumnMapping from a JSON file.

    The JSON file should have keys matching ColumnMapping field names,
    with values being the actual column names in the user's CSV/JSONL.
    """
    raw = json.loads(mapping_path.read_text())
    return ColumnMapping(**raw)


def parse_generic(data_path: Path, mapping_path: Path) -> ParseResult:
    """Parse a CSV/JSONL file using a user-provided column mapping JSON file."""
    mapping = load_mapping(mapping_path)
    return parse_file(data_path, mapping)


def parse_with_mapping(data_path: Path, mapping: ColumnMapping) -> ParseResult:
    """Parse a CSV/JSONL file using a ColumnMapping object directly."""
    return parse_file(data_path, mapping)
