"""Anthropic usage export parser — preset column mapping.

Anthropic console exports use slightly different column names:
    date, model, input_tokens, output_tokens, total_cost

Note: billing exports do NOT include prompt/response text.
For full audit capability, users need to provide logs with prompt text.
"""

from pathlib import Path

from token_aud.parsers.base import ColumnMapping, ParseResult, parse_file

# Anthropic billing dashboard export mapping
ANTHROPIC_MAPPING = ColumnMapping(
    timestamp="date",
    model="model",
    provider=None,
    provider_value="anthropic",
    prompt_tokens="input_tokens",
    completion_tokens="output_tokens",
    total_tokens=None,  # Computed from input + output
    cost="total_cost",
    prompt_text=None,
    response_text=None,
)

# Anthropic full log mapping (for users who log their own traffic)
ANTHROPIC_FULL_LOG_MAPPING = ColumnMapping(
    timestamp="timestamp",
    model="model",
    provider=None,
    provider_value="anthropic",
    prompt_tokens="input_tokens",
    completion_tokens="output_tokens",
    total_tokens=None,
    cost="total_cost",
    prompt_text="prompt",
    response_text="response",
)


def parse_anthropic_export(path: Path) -> ParseResult:
    """Parse an Anthropic console billing CSV export."""
    return parse_file(path, ANTHROPIC_MAPPING)


def parse_anthropic_full_log(path: Path) -> ParseResult:
    """Parse a full Anthropic log file (with prompt and response text)."""
    return parse_file(path, ANTHROPIC_FULL_LOG_MAPPING)
