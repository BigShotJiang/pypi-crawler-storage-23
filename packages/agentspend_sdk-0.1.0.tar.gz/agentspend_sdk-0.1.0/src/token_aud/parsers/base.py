"""Base parser: ColumnMapping model + the shared parsing engine.

Every parser (OpenAI preset, Anthropic preset, generic CSV) produces a
ColumnMapping, then calls `parse_dataframe()` to turn rows into LogEntry objects.
"""

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

import pandas as pd
from pydantic import BaseModel, Field

from token_aud.models.schemas import LogEntry


# ---------------------------------------------------------------------------
# ColumnMapping: tells the parser which CSV column maps to which LogEntry field
# ---------------------------------------------------------------------------
class ColumnMapping(BaseModel):
    """Maps CSV/JSONL column names to LogEntry fields."""

    timestamp: str = Field(description="Column name for the timestamp")
    model: str = Field(description="Column name for the model name")
    provider: str | None = Field(
        default=None,
        description="Column name for provider, or None if hardcoded",
    )
    provider_value: str | None = Field(
        default=None,
        description="Hardcoded provider value (used when provider column is None)",
    )
    prompt_tokens: str = Field(description="Column name for input/prompt token count")
    completion_tokens: str = Field(description="Column name for output/completion token count")
    total_tokens: str | None = Field(
        default=None,
        description="Column name for total tokens (if None, computed from prompt + completion)",
    )
    cost: str | None = Field(
        default=None,
        description="Column name for cost (if None, will be calculated from pricing DB)",
    )
    prompt_text: str | None = Field(
        default=None,
        description="Column name for the prompt text (required for audit pipeline)",
    )
    response_text: str | None = Field(
        default=None,
        description="Column name for the response text (required for audit pipeline)",
    )
    timestamp_format: str | None = Field(
        default=None,
        description="strftime format string, e.g. '%Y-%m-%d %H:%M:%S'. None = auto-detect.",
    )


# ---------------------------------------------------------------------------
# ParseResult: what the parser returns
# ---------------------------------------------------------------------------
@dataclass
class ParseResult:
    """Result of parsing a usage file."""

    entries: list[LogEntry] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    total_rows: int = 0
    has_prompt_text: bool = False

    @property
    def success_count(self) -> int:
        return len(self.entries)

    @property
    def error_count(self) -> int:
        return len(self.errors)


# ---------------------------------------------------------------------------
# Core parsing engine
# ---------------------------------------------------------------------------
def read_file(path: Path) -> pd.DataFrame:
    """Read a CSV or JSONL file into a DataFrame."""
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in (".jsonl", ".json"):
        return pd.read_json(path, lines=suffix == ".jsonl")
    raise ValueError(f"Unsupported file format: {suffix}. Use .csv, .json, or .jsonl")


def parse_dataframe(df: pd.DataFrame, mapping: ColumnMapping) -> ParseResult:
    """Apply a ColumnMapping to a DataFrame and produce LogEntry objects.

    Bad rows are skipped and logged as errors — one bad row never crashes the parse.
    """
    result = ParseResult(total_rows=len(df))
    result.has_prompt_text = mapping.prompt_text is not None and mapping.prompt_text in df.columns

    for row_idx, row in df.iterrows():
        try:
            entry = _row_to_entry(row, mapping, row_num=int(row_idx) + 1)
            result.entries.append(entry)
        except Exception as exc:
            result.errors.append(f"Row {int(row_idx) + 1}: {exc}")

    return result


def parse_file(path: Path, mapping: ColumnMapping) -> ParseResult:
    """Read a file and parse it using the given column mapping."""
    df = read_file(path)
    return parse_dataframe(df, mapping)


# ---------------------------------------------------------------------------
# Internal: convert one DataFrame row to a LogEntry
# ---------------------------------------------------------------------------
def _row_to_entry(row: pd.Series, mapping: ColumnMapping, row_num: int) -> LogEntry:
    """Convert a single row to a LogEntry. Raises on bad data."""

    # --- Timestamp ---
    raw_ts = row[mapping.timestamp]
    if mapping.timestamp_format:
        timestamp = datetime.strptime(str(raw_ts), mapping.timestamp_format)
    else:
        timestamp = pd.to_datetime(raw_ts).to_pydatetime()

    # --- Model ---
    model = str(row[mapping.model]).strip()
    if not model:
        raise ValueError("model is empty")

    # --- Provider ---
    if mapping.provider and mapping.provider in row.index:
        provider = str(row[mapping.provider]).strip()
    elif mapping.provider_value:
        provider = mapping.provider_value
    else:
        # Infer provider from model name
        provider = _infer_provider(model)

    # --- Tokens ---
    prompt_tokens = int(row[mapping.prompt_tokens])
    completion_tokens = int(row[mapping.completion_tokens])

    if mapping.total_tokens and mapping.total_tokens in row.index:
        total_tokens = int(row[mapping.total_tokens])
    else:
        total_tokens = prompt_tokens + completion_tokens

    # --- Cost (optional — will be filled by pricing engine later if missing) ---
    if mapping.cost and mapping.cost in row.index and pd.notna(row[mapping.cost]):
        try:
            actual_cost = Decimal(str(row[mapping.cost]))
        except InvalidOperation:
            actual_cost = Decimal("0")
    else:
        actual_cost = Decimal("0")  # Placeholder — pricing engine fills this

    # --- Prompt and response text (optional) ---
    prompt_text = None
    if mapping.prompt_text and mapping.prompt_text in row.index and pd.notna(row[mapping.prompt_text]):
        prompt_text = str(row[mapping.prompt_text])

    response_text = None
    if mapping.response_text and mapping.response_text in row.index and pd.notna(row[mapping.response_text]):
        response_text = str(row[mapping.response_text])

    return LogEntry(
        timestamp=timestamp,
        model=model,
        provider=provider,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=total_tokens,
        actual_cost=actual_cost,
        prompt_text=prompt_text,
        response_text=response_text,
    )


def _infer_provider(model: str) -> str:
    """Best-effort provider inference from model name."""
    model_lower = model.lower()
    if any(tag in model_lower for tag in ("gpt", "o1", "o3", "o4", "davinci", "chatgpt")):
        return "openai"
    if any(tag in model_lower for tag in ("claude", "haiku", "sonnet", "opus")):
        return "anthropic"
    if any(tag in model_lower for tag in ("gemini", "palm", "gemma")):
        return "google"
    if any(tag in model_lower for tag in ("llama", "mistral", "mixtral", "codellama")):
        return "meta"
    if any(tag in model_lower for tag in ("deepseek",)):
        return "deepseek"
    if any(tag in model_lower for tag in ("kimi", "moonshot")):
        return "moonshot"
    return "unknown"
