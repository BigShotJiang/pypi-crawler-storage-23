"""AgentSpend SDK — agent-native dynamic model routing.

Public API:
    from token_aud.agent import AgentSpend, RoutingPolicy, RouteContext

    agent = AgentSpend.from_yaml("routing_policy.yaml")
    result = agent.route_call(step="plan", messages=[...])
"""

from token_aud.agent.adaptive import AdaptiveRouter, AdaptiveSuggestion
from token_aud.agent.loop_guard import LoopGuard
from token_aud.agent.policy import RoutingPolicy, StepType
from token_aud.agent.router import RouteContext, RouteDecision, decide_model
from token_aud.agent.runtime import AgentSpend, RouteResult
from token_aud.agent.step_classifier import classify_step
from token_aud.agent.telemetry import (
    CallbackSink,
    HttpSink,
    JsonlSink,
    TelemetryEmitter,
    TelemetryEvent,
)

__all__ = [
    "AdaptiveRouter",
    "AdaptiveSuggestion",
    "AgentSpend",
    "CallbackSink",
    "HttpSink",
    "JsonlSink",
    "LoopGuard",
    "RouteContext",
    "RouteDecision",
    "RouteResult",
    "RoutingPolicy",
    "StepType",
    "TelemetryEmitter",
    "TelemetryEvent",
    "classify_step",
    "decide_model",
]
