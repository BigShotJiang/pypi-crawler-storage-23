"""Deterministic model router — selects the best model for a given step + context.

Pure function with no side effects. Takes a RoutingPolicy and context, returns
a RouteDecision. The runtime wrapper (runtime.py) handles execution + fallbacks.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from token_aud.agent.policy import (
    RoutingPolicy,
    RoutingRule,
    StepPolicy,
    StepType,
)
from token_aud.core.pricing import PricingEngine


@dataclass
class RouteContext:
    """Runtime context supplied by the caller for each routing decision."""

    step: StepType
    run_remaining_budget_usd: float | None = None
    estimated_tokens: int = 500
    turn_index: int = 0
    loop_detected: bool = False
    custom_labels: dict[str, str] = field(default_factory=dict)


@dataclass
class RouteDecision:
    """What the router decided and why."""

    selected_model: str
    fallback_chain: list[str]
    reason: str
    step: StepType
    estimated_cost_usd: float = 0.0
    budget_remaining_usd: float | None = None


def decide_model(
    *,
    policy: RoutingPolicy,
    pricing: PricingEngine,
    ctx: RouteContext,
) -> RouteDecision:
    """Deterministic model selection.

    Priority order:
    1. Dynamic routing rules (highest priority first)
    2. Loop guard escalation
    3. Budget guard (if remaining budget is too low for the default model)
    4. Step-specific policy
    5. Global default
    """
    step_policy = policy.steps.get(ctx.step)
    global_default = policy.globals.default_model

    # --- 1. Dynamic routing rules ---
    rule_match = _evaluate_rules(policy.routing_rules, ctx)
    if rule_match is not None:
        fallback = step_policy.fallback_chain if step_policy else []
        est = _estimate_cost(rule_match, ctx.estimated_tokens, pricing)
        return RouteDecision(
            selected_model=rule_match,
            fallback_chain=list(fallback),
            reason=f"Matched dynamic routing rule",
            step=ctx.step,
            estimated_cost_usd=est,
            budget_remaining_usd=ctx.run_remaining_budget_usd,
        )

    # --- 2. Loop guard escalation ---
    if ctx.loop_detected and policy.loop_guard.enabled:
        escalate_to = policy.loop_guard.on_trigger.escalate_to or global_default
        est = _estimate_cost(escalate_to, ctx.estimated_tokens, pricing)
        return RouteDecision(
            selected_model=escalate_to,
            fallback_chain=[global_default] if escalate_to != global_default else [],
            reason="Loop detected — escalated to stronger model",
            step=ctx.step,
            estimated_cost_usd=est,
            budget_remaining_usd=ctx.run_remaining_budget_usd,
        )

    # --- 3/4. Step policy or global default ---
    if step_policy:
        candidate = step_policy.default_model
        fallback = list(step_policy.fallback_chain)
    else:
        candidate = global_default
        fallback = []

    # --- 3a. Budget guard ---
    if ctx.run_remaining_budget_usd is not None:
        candidate, fallback, reason = _budget_guard(
            candidate, fallback, ctx, pricing, policy
        )
        if reason:
            est = _estimate_cost(candidate, ctx.estimated_tokens, pricing)
            return RouteDecision(
                selected_model=candidate,
                fallback_chain=fallback,
                reason=reason,
                step=ctx.step,
                estimated_cost_usd=est,
                budget_remaining_usd=ctx.run_remaining_budget_usd,
            )

    # --- 3b. Per-call cost cap ---
    per_call_cap = (
        step_policy.max_cost_per_call_usd
        if step_policy and step_policy.max_cost_per_call_usd
        else policy.globals.max_cost_per_call_usd
    )
    if per_call_cap is not None:
        est = _estimate_cost(candidate, ctx.estimated_tokens, pricing)
        if est > per_call_cap:
            cheaper = _find_cheaper_within_cap(
                fallback + [global_default], ctx.estimated_tokens, per_call_cap, pricing
            )
            if cheaper:
                est = _estimate_cost(cheaper, ctx.estimated_tokens, pricing)
                return RouteDecision(
                    selected_model=cheaper,
                    fallback_chain=[m for m in fallback if m != cheaper],
                    reason=f"Default model exceeds per-call cap ${per_call_cap}; downgraded",
                    step=ctx.step,
                    estimated_cost_usd=est,
                    budget_remaining_usd=ctx.run_remaining_budget_usd,
                )

    est = _estimate_cost(candidate, ctx.estimated_tokens, pricing)
    return RouteDecision(
        selected_model=candidate,
        fallback_chain=fallback,
        reason="Step policy default" if step_policy else "Global default",
        step=ctx.step,
        estimated_cost_usd=est,
        budget_remaining_usd=ctx.run_remaining_budget_usd,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _evaluate_rules(rules: list[RoutingRule], ctx: RouteContext) -> str | None:
    """Evaluate routing rules against context. Returns model name or None."""
    sorted_rules = sorted(rules, key=lambda r: r.priority, reverse=True)
    for rule in sorted_rules:
        if _rule_matches(rule, ctx) and rule.then_model:
            return rule.then_model
    return None


def _rule_matches(rule: RoutingRule, ctx: RouteContext) -> bool:
    """Check if all conditions on a rule are satisfied by the context."""
    ctx_dict = {
        "step": ctx.step.value,
        "turn_index": ctx.turn_index,
        "loop_detected": ctx.loop_detected,
        "run_remaining_budget_usd": ctx.run_remaining_budget_usd,
        **ctx.custom_labels,
    }
    for cond in rule.conditions:
        actual = ctx_dict.get(cond.field)
        if actual is None:
            return False
        if not _eval_op(actual, cond.operator, cond.value):
            return False
    return True


def _eval_op(actual: object, operator: str, expected: object) -> bool:
    """Evaluate a single condition operator."""
    if operator == "eq":
        return actual == expected
    if operator == "in":
        return actual in expected if isinstance(expected, (list, tuple, set)) else False
    try:
        a, e = float(actual), float(expected)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return False
    if operator == "gt":
        return a > e
    if operator == "lt":
        return a < e
    if operator == "gte":
        return a >= e
    if operator == "lte":
        return a <= e
    return False


def _estimate_cost(model: str, estimated_tokens: int, pricing: PricingEngine) -> float:
    """Rough cost estimate: assume 50/50 prompt/completion split."""
    half = estimated_tokens // 2
    cost = pricing.calculate_cost(model, half, estimated_tokens - half)
    return float(cost)


def _budget_guard(
    candidate: str,
    fallback: list[str],
    ctx: RouteContext,
    pricing: PricingEngine,
    policy: RoutingPolicy,
) -> tuple[str, list[str], str]:
    """Downgrade model if estimated cost would blow the remaining budget.

    Returns (model, fallback_chain, reason). reason is empty string if no change.
    """
    remaining = ctx.run_remaining_budget_usd
    if remaining is None:
        return candidate, fallback, ""

    est = _estimate_cost(candidate, ctx.estimated_tokens, pricing)
    if est <= remaining:
        return candidate, fallback, ""

    for fb_model in fallback + [policy.globals.default_model]:
        fb_est = _estimate_cost(fb_model, ctx.estimated_tokens, pricing)
        if fb_est <= remaining:
            return (
                fb_model,
                [m for m in fallback if m != fb_model],
                f"Budget guard: {candidate} est ${est:.4f} > remaining ${remaining:.4f}; downgraded to {fb_model}",
            )

    return (
        candidate,
        fallback,
        f"Budget guard: all models exceed remaining ${remaining:.4f}; keeping {candidate} (fail-open)",
    )


def _find_cheaper_within_cap(
    candidates: list[str],
    estimated_tokens: int,
    cap: float,
    pricing: PricingEngine,
) -> str | None:
    """Find the first candidate whose estimated cost is within the per-call cap."""
    for model in candidates:
        est = _estimate_cost(model, estimated_tokens, pricing)
        if est <= cap:
            return model
    return None
