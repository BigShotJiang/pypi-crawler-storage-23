"""AgentSpend runtime — the main entry point for agent-routed LLM calls.

Usage:
    from token_aud.agent import AgentSpend

    agent = AgentSpend.from_yaml("routing_policy.yaml")
    result = agent.route_call(step="plan", messages=[{"role": "user", "content": "..."}])
    print(result.content, result.model_used, result.cost_usd)
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path

import litellm

from token_aud.agent.adaptive import AdaptiveRouter
from token_aud.agent.loop_guard import LoopGuard
from token_aud.agent.policy import RoutingPolicy, StepType
from token_aud.agent.router import RouteContext, RouteDecision, decide_model
from token_aud.agent.step_classifier import classify_step
from token_aud.agent.telemetry import TelemetryEmitter, TelemetryEvent
from token_aud.core.pricing import PricingEngine


@dataclass
class RouteResult:
    """The output of a routed LLM call."""

    content: str
    model_used: str
    fallbacks_tried: list[str] = field(default_factory=list)
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_usd: float = 0.0
    latency_ms: float = 0.0
    step: StepType = StepType.generic
    decision: RouteDecision | None = None


class AgentSpend:
    """Main SDK class — wraps routing, execution, fallback, telemetry, and loop guard."""

    def __init__(
        self,
        policy: RoutingPolicy,
        pricing: PricingEngine | None = None,
        telemetry: TelemetryEmitter | None = None,
        enable_telemetry: bool = True,
        adaptive: AdaptiveRouter | None = None,
    ) -> None:
        self._policy = policy
        self._pricing = pricing or PricingEngine()
        self._loop_guard = LoopGuard(policy.loop_guard)
        self._telemetry = telemetry
        self._enable_telemetry = enable_telemetry
        self._adaptive = adaptive
        self._run_cost_usd: float = 0.0
        self._turn_index: int = 0

    # --- Constructors ---

    @classmethod
    def from_yaml(
        cls,
        path: str | Path,
        pricing: PricingEngine | None = None,
        **kwargs,
    ) -> AgentSpend:
        policy = RoutingPolicy.from_yaml(path)
        return cls(policy=policy, pricing=pricing, **kwargs)

    @classmethod
    def from_dict(
        cls,
        data: dict,
        pricing: PricingEngine | None = None,
        **kwargs,
    ) -> AgentSpend:
        policy = RoutingPolicy.from_dict(data)
        return cls(policy=policy, pricing=pricing, **kwargs)

    @classmethod
    def default(cls, **kwargs) -> AgentSpend:
        """Load the built-in default routing policy."""
        data_files = resources.files("token_aud.data")
        yaml_file = data_files.joinpath("default_routing_policy.yaml")
        return cls.from_yaml(str(yaml_file), **kwargs)

    # --- Public API ---

    @property
    def policy(self) -> RoutingPolicy:
        return self._policy

    @property
    def adaptive(self) -> AdaptiveRouter | None:
        return self._adaptive

    @property
    def run_cost_usd(self) -> float:
        return self._run_cost_usd

    @property
    def turn_index(self) -> int:
        return self._turn_index

    def reset_run(self) -> None:
        """Reset per-run state (cost accumulator, turn index, loop guard)."""
        self._run_cost_usd = 0.0
        self._turn_index = 0
        self._loop_guard.reset()

    # Default system prompt injected when caller provides none.
    # Keeps responses focused and avoids verbose markdown output that inflates cost.
    _DEFAULT_SYSTEM_PROMPT = (
        "You are a precise, efficient assistant. "
        "Be concise and direct. Avoid unnecessary markdown headers, bullet forests, "
        "or restating the question. Answer the task only."
    )

    def route_call(
        self,
        messages: list[dict[str, str]],
        step: str | StepType | None = None,
        estimated_tokens: int = 500,
        custom_labels: dict[str, str] | None = None,
        inject_system_prompt: bool = True,
        **litellm_kwargs,
    ) -> RouteResult:
        """Route an LLM call: classify step, pick model, execute with fallbacks.

        Args:
            messages: OpenAI-format message list.
            step: Explicit step type, or None to auto-classify.
            estimated_tokens: Rough token estimate for cost projection.
            custom_labels: Extra key-value pairs for routing rule evaluation.
            inject_system_prompt: If True and no system message exists, prepend
                a concise default system prompt to reduce verbose output and cost.
            **litellm_kwargs: Extra args forwarded to litellm.completion().

        Returns:
            RouteResult with the LLM response, cost, and metadata.
        """
        if inject_system_prompt and not any(m.get("role") == "system" for m in messages):
            messages = [{"role": "system", "content": self._DEFAULT_SYSTEM_PROMPT}] + messages

        step_type = self._resolve_step(step, messages)

        loop_detected = self._loop_guard.check(messages)

        if loop_detected and self._loop_guard.should_hard_stop:
            raise RuntimeError(
                f"AgentSpend hard stop: loop detected after "
                f"{self._loop_guard.escalation_count} escalations "
                f"(turn {self._turn_index}). Halting to prevent runaway cost."
            )
        if loop_detected:
            self._loop_guard.record_escalation()

        budget_max = self._policy.globals.max_cost_per_run_usd
        remaining_budget = (
            (budget_max - self._run_cost_usd) if budget_max is not None else None
        )

        ctx = RouteContext(
            step=step_type,
            run_remaining_budget_usd=remaining_budget,
            estimated_tokens=estimated_tokens,
            turn_index=self._turn_index,
            loop_detected=loop_detected,
            custom_labels=custom_labels or {},
        )

        decision = decide_model(
            policy=self._policy,
            pricing=self._pricing,
            ctx=ctx,
        )

        if self._adaptive and self._adaptive.enabled and not loop_detected:
            suggestion = self._adaptive.suggest(
                step=step_type.value,
                current_model=decision.selected_model,
            )
            if suggestion.suggested_model:
                decision = RouteDecision(
                    selected_model=suggestion.suggested_model,
                    fallback_chain=[decision.selected_model] + decision.fallback_chain,
                    reason=f"Adaptive: {suggestion.reason}",
                    step=decision.step,
                    estimated_cost_usd=decision.estimated_cost_usd,
                    budget_remaining_usd=decision.budget_remaining_usd,
                )

        result = self._execute_with_fallback(
            decision=decision,
            messages=messages,
            step_type=step_type,
            **litellm_kwargs,
        )

        self._run_cost_usd += result.cost_usd
        self._turn_index += 1

        if self._adaptive:
            self._adaptive.record_outcome(
                step=step_type.value,
                model=result.model_used,
                success=len(result.fallbacks_tried) == 0,
                cost=result.cost_usd,
                latency_ms=result.latency_ms,
            )

        if self._enable_telemetry and self._telemetry:
            event = TelemetryEvent(
                step=step_type.value,
                model_selected=decision.selected_model,
                model_used=result.model_used,
                fallbacks_tried=result.fallbacks_tried,
                prompt_tokens=result.prompt_tokens,
                completion_tokens=result.completion_tokens,
                cost_usd=result.cost_usd,
                latency_ms=result.latency_ms,
                turn_index=self._turn_index - 1,
                loop_detected=loop_detected,
                reason=decision.reason,
                outcome="ok",
            )
            self._telemetry.emit(event)

        return result

    # --- Internals ---

    def _resolve_step(
        self, step: str | StepType | None, messages: list[dict[str, str]]
    ) -> StepType:
        if step is None:
            return classify_step(messages)
        if isinstance(step, StepType):
            return step
        try:
            return StepType(step)
        except ValueError:
            return StepType.generic

    def _execute_with_fallback(
        self,
        decision: RouteDecision,
        messages: list[dict[str, str]],
        step_type: StepType,
        **litellm_kwargs,
    ) -> RouteResult:
        """Try the selected model, then walk the fallback chain on failure."""
        models_to_try = [decision.selected_model] + decision.fallback_chain
        fallbacks_tried: list[str] = []
        last_error: Exception | None = None

        for model in models_to_try:
            litellm_id = self._litellm_model_id(model)
            t0 = time.perf_counter()
            try:
                response = litellm.completion(
                    model=litellm_id,
                    messages=messages,
                    **litellm_kwargs,
                )
                latency_ms = (time.perf_counter() - t0) * 1000

                usage = response.usage
                prompt_tokens = usage.prompt_tokens or 0
                completion_tokens = usage.completion_tokens or 0
                cost = float(
                    self._pricing.calculate_cost(model, prompt_tokens, completion_tokens)
                )

                return RouteResult(
                    content=response.choices[0].message.content or "",
                    model_used=model,
                    fallbacks_tried=fallbacks_tried,
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    cost_usd=cost,
                    latency_ms=latency_ms,
                    step=step_type,
                    decision=decision,
                )

            except Exception as exc:
                last_error = exc
                fallbacks_tried.append(model)
                if self._enable_telemetry and self._telemetry:
                    event = TelemetryEvent(
                        step=step_type.value,
                        model_selected=decision.selected_model,
                        model_used=model,
                        fallbacks_tried=list(fallbacks_tried),
                        cost_usd=0.0,
                        latency_ms=(time.perf_counter() - t0) * 1000,
                        turn_index=self._turn_index,
                        loop_detected=False,
                        reason=f"Fallback: {type(exc).__name__}: {exc}",
                        outcome="error",
                    )
                    self._telemetry.emit(event)

        if self._policy.globals.fail_open:
            fallback_model = self._policy.globals.default_model
            litellm_id = self._litellm_model_id(fallback_model)
            t0 = time.perf_counter()
            try:
                response = litellm.completion(
                    model=litellm_id,
                    messages=messages,
                    **litellm_kwargs,
                )
                latency_ms = (time.perf_counter() - t0) * 1000
                usage = response.usage
                prompt_tokens = usage.prompt_tokens or 0
                completion_tokens = usage.completion_tokens or 0
                cost = float(
                    self._pricing.calculate_cost(
                        fallback_model, prompt_tokens, completion_tokens
                    )
                )
                return RouteResult(
                    content=response.choices[0].message.content or "",
                    model_used=fallback_model,
                    fallbacks_tried=fallbacks_tried,
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    cost_usd=cost,
                    latency_ms=latency_ms,
                    step=step_type,
                    decision=decision,
                )
            except Exception:
                pass

        raise RuntimeError(
            f"All models failed for step '{step_type.value}'. "
            f"Tried: {models_to_try}. Last error: {last_error}"
        )

    def _litellm_model_id(self, model: str) -> str:
        """Normalize model name for LiteLLM provider routing (reuses auditor pattern)."""
        if "/" in model:
            return model
        pricing = self._pricing.get_pricing(model)
        if pricing is None:
            return model
        if pricing.provider == "openai":
            return model
        return f"{pricing.provider}/{model}"
