"""Loop guard — detects agent loops from repeated similar messages.

Tracks recent message fingerprints per session. When consecutive turns
have high textual similarity or identical content, signals a loop so the
router can escalate or halt.

Budget guard logic lives in router.py (it's part of the routing decision).
This module focuses on turn-level repetition detection.
"""

from __future__ import annotations

from collections import deque
from difflib import SequenceMatcher

from token_aud.agent.policy import LoopGuardAction, LoopGuardConfig


class LoopGuard:
    """Stateful loop detector for an agent run."""

    def __init__(self, config: LoopGuardConfig) -> None:
        self._config = config
        self._recent_fingerprints: deque[str] = deque(
            maxlen=config.repeated_turn_limit + 2
        )
        self._consecutive_similar: int = 0
        self._escalation_count: int = 0

    def reset(self) -> None:
        """Clear all state between runs."""
        self._recent_fingerprints.clear()
        self._consecutive_similar = 0
        self._escalation_count = 0

    def check(self, messages: list[dict[str, str]]) -> bool:
        """Check if the current turn looks like a loop.

        Args:
            messages: The message list about to be sent to the LLM.

        Returns:
            True if a loop is detected.
        """
        if not self._config.enabled:
            return False

        fingerprint = self._fingerprint(messages)
        if not fingerprint:
            return False

        is_similar = self._is_similar_to_recent(fingerprint)
        self._recent_fingerprints.append(fingerprint)

        if is_similar:
            self._consecutive_similar += 1
        else:
            self._consecutive_similar = 0

        if self._consecutive_similar >= self._config.repeated_turn_limit:
            return True

        return False

    def record_escalation(self) -> None:
        """Record that the router escalated due to a loop detection."""
        self._escalation_count += 1

    @property
    def should_hard_stop(self) -> bool:
        """True if escalation count exceeds the hard_stop_after threshold."""
        limit = self._config.on_trigger.hard_stop_after
        return self._escalation_count >= limit

    @property
    def action(self) -> LoopGuardAction:
        return self._config.on_trigger.action

    @property
    def escalation_count(self) -> int:
        return self._escalation_count

    # --- Internals ---

    def _fingerprint(self, messages: list[dict[str, str]]) -> str:
        """Extract a comparable fingerprint from the last message."""
        if not messages:
            return ""
        for msg in reversed(messages):
            content = msg.get("content", "")
            if content:
                return content.strip()[:500]
        return ""

    def _is_similar_to_recent(self, fingerprint: str) -> bool:
        """Check if the fingerprint is similar to any recent one."""
        threshold = self._config.similarity_threshold
        for recent in self._recent_fingerprints:
            ratio = SequenceMatcher(None, fingerprint, recent).ratio()
            if ratio >= threshold:
                return True
        return False
