"""Step classifier — infers an agent step type from message content.

Uses keyword heuristics to classify LLM calls into step categories without
requiring the caller to explicitly tag every call. Callers can always override
by passing step_type directly to route_call().
"""

from __future__ import annotations

import re

from token_aud.agent.policy import StepType

_STEP_PATTERNS: list[tuple[StepType, re.Pattern[str]]] = [
    (StepType.plan, re.compile(
        r"\b(plan\w*|outline|strategy|approach|steps? to|break.*down|decompos\w*)\b", re.I
    )),
    (StepType.reason, re.compile(
        r"\b(reason\w*|think\w*|analyz\w*|evaluat\w*|consider\w*|reflect\w*|weigh\w*|assess\w*|deduc\w*)\b", re.I
    )),
    (StepType.tool, re.compile(
        r"\b(tool|function.?call|api.?call|execute\w*|run.?command|invoke\w*|search\w*|query|fetch\w*)\b", re.I
    )),
    (StepType.verify, re.compile(
        r"\b(verify\w*|check\w*|validat\w*|confirm\w*|assert\w*|test\w*|ensure\w*|correct\w*)\b", re.I
    )),
    (StepType.draft, re.compile(
        r"\b(draft\w*|write\w*|compos\w*|generat\w*|creat\w*|produc\w*|author\w*|output\w*)\b", re.I
    )),
    (StepType.summarize, re.compile(
        r"\b(summar\w*|recap|conclusion|tldr|overview|digest|synopsis)\b", re.I
    )),
]


def classify_step(messages: list[dict[str, str]]) -> StepType:
    """Infer the step type from the last user/system message.

    Scans the last message for keyword patterns and returns the first match.
    Falls back to StepType.generic if no pattern matches.
    """
    text = _extract_last_content(messages)
    if not text:
        return StepType.generic

    for step_type, pattern in _STEP_PATTERNS:
        if pattern.search(text):
            return step_type

    return StepType.generic


def _extract_last_content(messages: list[dict[str, str]]) -> str:
    """Pull out the content from the last message in the conversation."""
    if not messages:
        return ""
    for msg in reversed(messages):
        content = msg.get("content", "")
        if content:
            return content
    return ""
