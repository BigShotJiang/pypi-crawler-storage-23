"""Telemetry — event schema and sinks for routing observability.

Every routed call produces a TelemetryEvent. Events are emitted to one or more
sinks: JSONL file (default), HTTP endpoint, or custom callback.

Usage:
    from token_aud.agent.telemetry import TelemetryEmitter, JsonlSink

    emitter = TelemetryEmitter(sinks=[JsonlSink("agent_telemetry.jsonl")])
    emitter.emit(event)
    emitter.flush()
"""

from __future__ import annotations

import json
import time
from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen


@dataclass
class TelemetryEvent:
    """One routing event emitted per LLM call."""

    step: str
    model_selected: str
    model_used: str
    fallbacks_tried: list[str] = field(default_factory=list)
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_usd: float = 0.0
    latency_ms: float = 0.0
    turn_index: int = 0
    loop_detected: bool = False
    reason: str = ""
    outcome: str = "ok"
    error_message: str | None = None
    timestamp_ms: int = field(default_factory=lambda: int(time.time() * 1000))
    custom_labels: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class TelemetrySink(ABC):
    """Abstract base for telemetry sinks."""

    @abstractmethod
    def write(self, event: TelemetryEvent) -> None: ...

    def flush(self) -> None:
        pass

    def close(self) -> None:
        pass


class JsonlSink(TelemetrySink):
    """Append events as newline-delimited JSON to a local file."""

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._file = self._path.open("a", encoding="utf-8")

    def write(self, event: TelemetryEvent) -> None:
        self._file.write(json.dumps(event.to_dict(), ensure_ascii=False) + "\n")

    def flush(self) -> None:
        self._file.flush()

    def close(self) -> None:
        self._file.close()


class HttpSink(TelemetrySink):
    """POST events as JSON to an HTTP endpoint (fire-and-forget)."""

    def __init__(
        self,
        url: str,
        headers: dict[str, str] | None = None,
        timeout_s: float = 5.0,
    ) -> None:
        self._url = url
        self._headers = headers or {"Content-Type": "application/json"}
        self._timeout = timeout_s
        self._buffer: list[TelemetryEvent] = []

    def write(self, event: TelemetryEvent) -> None:
        self._buffer.append(event)
        if len(self._buffer) >= 10:
            self.flush()

    def flush(self) -> None:
        if not self._buffer:
            return
        payload = json.dumps(
            [e.to_dict() for e in self._buffer], ensure_ascii=False
        ).encode("utf-8")
        self._buffer.clear()
        try:
            req = Request(self._url, data=payload, headers=self._headers, method="POST")
            urlopen(req, timeout=self._timeout)
        except Exception:
            pass

    def close(self) -> None:
        self.flush()


class CallbackSink(TelemetrySink):
    """Pass each event to a user-supplied callback function."""

    def __init__(self, callback: Callable[[TelemetryEvent], None]) -> None:
        self._callback = callback

    def write(self, event: TelemetryEvent) -> None:
        self._callback(event)


class TelemetryEmitter:
    """Fan-out emitter that distributes events to multiple sinks."""

    def __init__(self, sinks: list[TelemetrySink] | None = None) -> None:
        self._sinks: list[TelemetrySink] = sinks or []

    def add_sink(self, sink: TelemetrySink) -> None:
        self._sinks.append(sink)

    def emit(self, event: TelemetryEvent) -> None:
        for sink in self._sinks:
            try:
                sink.write(event)
            except Exception:
                pass

    def flush(self) -> None:
        for sink in self._sinks:
            try:
                sink.flush()
            except Exception:
                pass

    def close(self) -> None:
        for sink in self._sinks:
            try:
                sink.close()
            except Exception:
                pass
