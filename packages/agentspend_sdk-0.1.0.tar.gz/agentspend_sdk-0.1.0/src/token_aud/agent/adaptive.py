"""Adaptive routing — learns from telemetry outcomes to adjust model selection.

This module provides an optional layer on top of the deterministic router.
It tracks per-step success rates and costs, then suggests cheaper models
when confidence is high enough.

Key design constraints:
- Deterministic mode is always the default and the safe fallback.
- Adaptive mode requires a minimum sample size before overriding.
- A rollback switch instantly disables adaptation.
- All state is local and serializable (no external DB needed).

Usage:
    from token_aud.agent.adaptive import AdaptiveRouter

    adaptive = AdaptiveRouter(min_samples=20, confidence_threshold=0.85)
    adaptive.record_outcome(step="plan", model="gpt-4o-mini", success=True, cost=0.001)
    suggestion = adaptive.suggest(step="plan", current_model="gpt-4o")
"""

from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ModelStats:
    """Accumulated statistics for a model on a specific step type."""

    total_calls: int = 0
    success_count: int = 0
    total_cost: float = 0.0
    total_latency_ms: float = 0.0

    @property
    def success_rate(self) -> float:
        if self.total_calls == 0:
            return 0.0
        return self.success_count / self.total_calls

    @property
    def avg_cost(self) -> float:
        if self.total_calls == 0:
            return 0.0
        return self.total_cost / self.total_calls

    @property
    def avg_latency_ms(self) -> float:
        if self.total_calls == 0:
            return 0.0
        return self.total_latency_ms / self.total_calls


@dataclass
class AdaptiveSuggestion:
    """A suggestion from the adaptive router."""

    suggested_model: str | None
    reason: str
    confidence: float
    stats: ModelStats | None = None


class AdaptiveRouter:
    """Learns from outcomes to suggest cheaper models per step type.

    This is opt-in and sits alongside the deterministic router. It does not
    replace it — the runtime checks this for suggestions before falling back
    to the deterministic path.
    """

    def __init__(
        self,
        min_samples: int = 20,
        confidence_threshold: float = 0.85,
        enabled: bool = True,
    ) -> None:
        self._min_samples = min_samples
        self._confidence_threshold = confidence_threshold
        self._enabled = enabled
        self._stats: dict[str, dict[str, ModelStats]] = defaultdict(
            lambda: defaultdict(ModelStats)
        )

    @property
    def enabled(self) -> bool:
        return self._enabled

    def enable(self) -> None:
        self._enabled = True

    def disable(self) -> None:
        """Rollback switch — immediately disables adaptive suggestions."""
        self._enabled = False

    def record_outcome(
        self,
        step: str,
        model: str,
        success: bool,
        cost: float = 0.0,
        latency_ms: float = 0.0,
    ) -> None:
        """Record the outcome of a routed call for learning."""
        stats = self._stats[step][model]
        stats.total_calls += 1
        if success:
            stats.success_count += 1
        stats.total_cost += cost
        stats.total_latency_ms += latency_ms

    def suggest(
        self,
        step: str,
        current_model: str,
        candidate_models: list[str] | None = None,
    ) -> AdaptiveSuggestion:
        """Suggest a potentially cheaper model based on historical success rates.

        Returns a suggestion only if:
        1. Adaptive routing is enabled
        2. There's enough data (>= min_samples) for the candidate
        3. The candidate's success rate >= confidence_threshold
        4. The candidate is cheaper on average than the current model
        """
        if not self._enabled:
            return AdaptiveSuggestion(
                suggested_model=None,
                reason="Adaptive routing disabled",
                confidence=0.0,
            )

        step_stats = self._stats.get(step, {})
        current_stats = step_stats.get(current_model)

        if candidate_models is None:
            candidate_models = [m for m in step_stats if m != current_model]

        best: AdaptiveSuggestion | None = None

        for candidate in candidate_models:
            cand_stats = step_stats.get(candidate)
            if cand_stats is None or cand_stats.total_calls < self._min_samples:
                continue

            if cand_stats.success_rate < self._confidence_threshold:
                continue

            if current_stats and cand_stats.avg_cost >= current_stats.avg_cost:
                continue

            suggestion = AdaptiveSuggestion(
                suggested_model=candidate,
                reason=(
                    f"{candidate} has {cand_stats.success_rate:.0%} success rate "
                    f"over {cand_stats.total_calls} calls at ${cand_stats.avg_cost:.6f}/call avg"
                ),
                confidence=cand_stats.success_rate,
                stats=cand_stats,
            )

            if best is None or (cand_stats.avg_cost < (best.stats.avg_cost if best.stats else float("inf"))):
                best = suggestion

        if best is not None:
            return best

        return AdaptiveSuggestion(
            suggested_model=None,
            reason="No confident cheaper alternative found",
            confidence=0.0,
        )

    def get_stats(self, step: str | None = None) -> dict:
        """Return stats as a plain dict for inspection or serialization."""
        if step:
            return {
                model: {
                    "total_calls": s.total_calls,
                    "success_rate": s.success_rate,
                    "avg_cost": s.avg_cost,
                    "avg_latency_ms": s.avg_latency_ms,
                }
                for model, s in self._stats.get(step, {}).items()
            }
        return {
            step_name: {
                model: {
                    "total_calls": s.total_calls,
                    "success_rate": s.success_rate,
                    "avg_cost": s.avg_cost,
                    "avg_latency_ms": s.avg_latency_ms,
                }
                for model, s in models.items()
            }
            for step_name, models in self._stats.items()
        }

    def save(self, path: str | Path) -> None:
        """Persist stats to a JSON file."""
        raw: dict = {}
        for step_name, models in self._stats.items():
            raw[step_name] = {}
            for model, s in models.items():
                raw[step_name][model] = {
                    "total_calls": s.total_calls,
                    "success_count": s.success_count,
                    "total_cost": s.total_cost,
                    "total_latency_ms": s.total_latency_ms,
                }
        Path(path).write_text(json.dumps(raw, indent=2))

    def load(self, path: str | Path) -> None:
        """Load stats from a previously saved JSON file."""
        p = Path(path)
        if not p.exists():
            return
        raw = json.loads(p.read_text())
        for step_name, models in raw.items():
            for model, data in models.items():
                stats = self._stats[step_name][model]
                stats.total_calls = data["total_calls"]
                stats.success_count = data["success_count"]
                stats.total_cost = data["total_cost"]
                stats.total_latency_ms = data.get("total_latency_ms", 0.0)
