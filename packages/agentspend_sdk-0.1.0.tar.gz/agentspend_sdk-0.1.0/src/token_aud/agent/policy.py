"""Routing policy schema — Pydantic models that validate a routing_policy.yaml.

A RoutingPolicy defines:
- Global defaults (budget caps, quality floor, default model)
- Per-model specs (provider, cost/latency tier)
- Per-step policies (default model, allowed models, fallback chain, cost/latency limits)
- Loop guard configuration
- Optional dynamic routing rules
"""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field, model_validator


class StepType(str, Enum):
    """Canonical agent step categories."""

    plan = "plan"
    reason = "reason"
    tool = "tool"
    verify = "verify"
    draft = "draft"
    summarize = "summarize"
    generic = "generic"


class CostTier(str, Enum):
    low = "low"
    medium = "medium"
    high = "high"


class LatencyTier(str, Enum):
    low = "low"
    medium = "medium"
    high = "high"


class GlobalConfig(BaseModel):
    default_model: str = "gpt-4o-mini"
    max_cost_per_run_usd: float | None = None
    max_cost_per_call_usd: float | None = None
    quality_floor: float = 0.7
    fail_open: bool = True


class ModelSpec(BaseModel):
    provider: str
    cost_tier: CostTier = CostTier.medium
    latency_tier: LatencyTier = LatencyTier.medium


class StepPolicy(BaseModel):
    default_model: str
    allowed_models: list[str] = Field(default_factory=list)
    fallback_chain: list[str] = Field(default_factory=list)
    max_cost_per_call_usd: float | None = None
    max_latency_ms: float | None = None
    quality_floor: float | None = None


class LoopGuardAction(str, Enum):
    escalate = "escalate"
    hard_stop = "hard_stop"
    fallback = "fallback"


class LoopGuardTrigger(BaseModel):
    action: LoopGuardAction = LoopGuardAction.escalate
    escalate_to: str | None = None
    hard_stop_after: int = 2


class LoopGuardConfig(BaseModel):
    enabled: bool = True
    similarity_threshold: float = 0.95
    repeated_turn_limit: int = 3
    on_trigger: LoopGuardTrigger = Field(default_factory=LoopGuardTrigger)


class RoutingRuleCondition(BaseModel):
    field: str
    operator: Literal["eq", "gt", "lt", "gte", "lte", "in"]
    value: Any


class RoutingRule(BaseModel):
    name: str
    conditions: list[RoutingRuleCondition] = Field(default_factory=list)
    then_model: str | None = None
    then_action: str | None = None
    priority: int = 0


class RoutingPolicy(BaseModel):
    """Top-level routing policy loaded from YAML."""

    version: int = 1
    name: str = "default"
    description: str | None = None
    globals: GlobalConfig = Field(default_factory=GlobalConfig)
    models: dict[str, ModelSpec] = Field(default_factory=dict)
    steps: dict[StepType, StepPolicy] = Field(default_factory=dict)
    loop_guard: LoopGuardConfig = Field(default_factory=LoopGuardConfig)
    routing_rules: list[RoutingRule] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_model_references(self) -> RoutingPolicy:
        known = set(self.models.keys())
        if not known:
            return self

        for step_type, step_policy in self.steps.items():
            if step_policy.default_model not in known:
                raise ValueError(
                    f"Step '{step_type.value}' references unknown model "
                    f"'{step_policy.default_model}'. Known: {sorted(known)}"
                )
            for m in step_policy.allowed_models:
                if m not in known:
                    raise ValueError(
                        f"Step '{step_type.value}' allowed_models references "
                        f"unknown model '{m}'. Known: {sorted(known)}"
                    )
            for m in step_policy.fallback_chain:
                if m not in known:
                    raise ValueError(
                        f"Step '{step_type.value}' fallback_chain references "
                        f"unknown model '{m}'. Known: {sorted(known)}"
                    )

        if self.loop_guard.on_trigger.escalate_to:
            if self.loop_guard.on_trigger.escalate_to not in known:
                raise ValueError(
                    f"loop_guard.on_trigger.escalate_to references unknown "
                    f"model '{self.loop_guard.on_trigger.escalate_to}'. Known: {sorted(known)}"
                )

        for rule in self.routing_rules:
            if rule.then_model and rule.then_model not in known:
                raise ValueError(
                    f"Routing rule '{rule.name}' references unknown model "
                    f"'{rule.then_model}'. Known: {sorted(known)}"
                )

        return self

    @classmethod
    def from_yaml(cls, path: str | Path) -> RoutingPolicy:
        """Load and validate a routing policy from a YAML file."""
        raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
        return cls.model_validate(raw)

    @classmethod
    def from_dict(cls, data: dict) -> RoutingPolicy:
        """Load and validate a routing policy from a dict."""
        return cls.model_validate(data)
