"""token-aud: AI cost optimization through model benchmarking."""

__version__ = "0.1.0"
