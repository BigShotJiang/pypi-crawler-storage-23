"""Database session management for token-aud."""

from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from token_aud.models.db import Base

# Default SQLite database location: ~/.token-aud/token_aud.db
DEFAULT_DB_DIR = Path.home() / ".token-aud"
DEFAULT_DB_PATH = DEFAULT_DB_DIR / "token_aud.db"


def get_engine(db_path: Path = DEFAULT_DB_PATH):
    """Create a SQLAlchemy engine for the given database path."""
    db_path.parent.mkdir(parents=True, exist_ok=True)
    return create_engine(f"sqlite:///{db_path}", echo=False)


def init_db(db_path: Path = DEFAULT_DB_PATH) -> None:
    """Create all tables if they don't exist."""
    engine = get_engine(db_path)
    Base.metadata.create_all(engine)


def get_session(db_path: Path = DEFAULT_DB_PATH) -> Session:
    """Get a new database session."""
    engine = get_engine(db_path)
    factory = sessionmaker(bind=engine)
    return factory()
