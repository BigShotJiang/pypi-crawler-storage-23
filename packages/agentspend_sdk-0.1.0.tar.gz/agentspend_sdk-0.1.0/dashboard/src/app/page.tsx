"use client";

import { useState, useCallback } from "react";

// ── Types matching the Python SavingsReport ──────────────────────────────

interface ModelRecommendation {
  current_model: string;
  provider: string;
  current_spend: string;
  entry_count: number;
  status: string;
  recommended_model: string | null;
  projected_savings: string;
  audits_run: number;
  avg_quality_score: number;
  safe_switch_rate: number;
  confidence: number;
}

interface SavingsReport {
  id: string;
  created_at: string;
  total_entries: number;
  total_audited: number;
  total_actual_cost: string;
  total_potential_savings: string;
  savings_percentage: number;
  model_recommendations: ModelRecommendation[];
  confidence_level: number;
}

// ── Status badge ─────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    switch_recommended:
      "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
    premium_required:
      "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
    already_optimal:
      "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
    not_audited:
      "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400",
  };

  const labels: Record<string, string> = {
    switch_recommended: "Switch",
    premium_required: "Keep",
    already_optimal: "Optimal",
    not_audited: "N/A",
  };

  return (
    <span
      className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-medium ${styles[status] ?? styles.not_audited}`}
    >
      {labels[status] ?? status}
    </span>
  );
}

// ── Upload form ──────────────────────────────────────────────────────────

function UploadForm({
  onReport,
}: {
  onReport: (r: SavingsReport) => void;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [provider, setProvider] = useState("");
  const [dryRun, setDryRun] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const dropped = e.dataTransfer.files[0];
    if (dropped) setFile(dropped);
  }, []);

  const submit = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);

    const form = new FormData();
    form.append("file", file);
    if (provider) form.append("provider", provider);
    form.append("dry_run", String(dryRun));

    try {
      const res = await fetch("/api/analyze", { method: "POST", body: form });
      if (!res.ok) {
        const body = await res.json().catch(() => null);
        throw new Error(body?.detail ?? `Server error ${res.status}`);
      }
      const report: SavingsReport = await res.json();
      onReport(report);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rounded-xl border border-border bg-card p-6">
      <h2 className="mb-4 text-xl font-semibold">Analyze Usage Data</h2>

      {/* Drop zone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        className={`mb-4 flex min-h-[120px] cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed transition-colors ${
          dragOver
            ? "border-accent bg-accent/5"
            : "border-border hover:border-accent/50"
        }`}
        onClick={() => document.getElementById("file-input")?.click()}
      >
        <input
          id="file-input"
          type="file"
          accept=".csv,.jsonl"
          className="hidden"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
        />
        {file ? (
          <p className="text-sm font-medium">{file.name}</p>
        ) : (
          <>
            <p className="text-sm text-muted">
              Drop a CSV or JSONL file here, or click to browse
            </p>
          </>
        )}
      </div>

      {/* Options row */}
      <div className="mb-4 flex flex-wrap items-center gap-4">
        <label className="flex items-center gap-2 text-sm">
          <span className="text-muted">Provider:</span>
          <select
            value={provider}
            onChange={(e) => setProvider(e.target.value)}
            className="rounded-md border border-border bg-background px-2 py-1 text-sm"
          >
            <option value="">Auto-detect</option>
            <option value="openai">OpenAI</option>
            <option value="anthropic">Anthropic</option>
          </select>
        </label>

        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={dryRun}
            onChange={(e) => setDryRun(e.target.checked)}
            className="rounded"
          />
          <span>Dry run</span>
          <span className="text-muted">(no API calls)</span>
        </label>
      </div>

      {error && (
        <p className="mb-4 rounded-md bg-red-50 px-3 py-2 text-sm text-red-700 dark:bg-red-900/20 dark:text-red-400">
          {error}
        </p>
      )}

      <button
        onClick={submit}
        disabled={!file || loading}
        className="rounded-lg bg-accent px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-accent-light disabled:opacity-50"
      >
        {loading ? "Analyzing..." : "Run Analysis"}
      </button>
    </div>
  );
}

// ── Report view ──────────────────────────────────────────────────────────

function ReportView({ report }: { report: SavingsReport }) {
  const cost = parseFloat(report.total_actual_cost);
  const savings = parseFloat(report.total_potential_savings);
  const annual = savings * 12;

  return (
    <div className="space-y-6">
      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <Card label="Total Spend" value={`$${cost.toFixed(2)}`} />
        <Card label="Entries" value={report.total_entries.toLocaleString()} />
        <Card
          label="Projected Savings"
          value={`$${savings.toFixed(2)}`}
          accent={savings > 0}
        />
        <Card label="Savings %" value={`${report.savings_percentage.toFixed(1)}%`} accent={report.savings_percentage > 0} />
      </div>

      {/* Annual callout */}
      {annual > 0 && (
        <div className="rounded-lg bg-green-50 px-5 py-4 text-center dark:bg-green-900/20">
          <p className="text-sm text-green-700 dark:text-green-400">
            Estimated annual savings
          </p>
          <p className="text-3xl font-bold text-green-700 dark:text-green-300">
            ${annual.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </p>
        </div>
      )}

      {/* Model table */}
      <div className="overflow-x-auto rounded-xl border border-border">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-border bg-zinc-50 dark:bg-zinc-900">
            <tr>
              <th className="px-4 py-3 font-medium">Model</th>
              <th className="px-4 py-3 font-medium">Provider</th>
              <th className="px-4 py-3 text-right font-medium">Entries</th>
              <th className="px-4 py-3 text-right font-medium">Spend</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Switch To</th>
              <th className="px-4 py-3 text-right font-medium">Savings</th>
              <th className="px-4 py-3 text-right font-medium">Quality</th>
            </tr>
          </thead>
          <tbody>
            {report.model_recommendations.map((rec) => (
              <tr
                key={rec.current_model}
                className="border-b border-border last:border-0"
              >
                <td className="px-4 py-3 font-mono text-sm">
                  {rec.current_model}
                </td>
                <td className="px-4 py-3 text-muted">{rec.provider}</td>
                <td className="px-4 py-3 text-right">{rec.entry_count}</td>
                <td className="px-4 py-3 text-right">
                  ${parseFloat(rec.current_spend).toFixed(2)}
                </td>
                <td className="px-4 py-3">
                  <StatusBadge status={rec.status} />
                </td>
                <td className="px-4 py-3 font-mono text-sm text-muted">
                  {rec.recommended_model ?? "—"}
                </td>
                <td className="px-4 py-3 text-right">
                  {parseFloat(rec.projected_savings) > 0 ? (
                    <span className="text-green-600 dark:text-green-400">
                      ${parseFloat(rec.projected_savings).toFixed(2)}
                    </span>
                  ) : (
                    "—"
                  )}
                </td>
                <td className="px-4 py-3 text-right">
                  {rec.audits_run > 0
                    ? `${(rec.avg_quality_score * 100).toFixed(0)}%`
                    : "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="text-center text-xs text-muted">
        Report generated {new Date(report.created_at).toLocaleString()} — Confidence{" "}
        {(report.confidence_level * 100).toFixed(0)}%
      </p>
    </div>
  );
}

function Card({
  label,
  value,
  accent = false,
}: {
  label: string;
  value: string;
  accent?: boolean;
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <p className="text-xs text-muted">{label}</p>
      <p
        className={`mt-1 text-2xl font-semibold ${accent ? "text-green-600 dark:text-green-400" : ""}`}
      >
        {value}
      </p>
    </div>
  );
}

// ── Page ─────────────────────────────────────────────────────────────────

export default function Home() {
  const [report, setReport] = useState<SavingsReport | null>(null);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold">Savings Dashboard</h1>
        <p className="mt-1 text-muted">
          Upload your LLM usage data to discover cost savings opportunities.
        </p>
      </div>

      <UploadForm onReport={setReport} />

      {report && <ReportView report={report} />}
    </div>
  );
}
