"""Tests for the step classifier."""

import pytest

from token_aud.agent.step_classifier import classify_step
from token_aud.agent.policy import StepType


class TestClassifyStep:
    @pytest.mark.parametrize(
        "text, expected",
        [
            ("Break this task down into steps", StepType.plan),
            ("Let me plan the approach", StepType.plan),
            ("Outline the strategy", StepType.plan),
            ("Think carefully about the trade-offs", StepType.reason),
            ("Let me analyze this problem", StepType.reason),
            ("Evaluate the options", StepType.reason),
            ("Call the search API", StepType.tool),
            ("Execute the function call", StepType.tool),
            ("Fetch the data from the endpoint", StepType.tool),
            ("Verify the output is correct", StepType.verify),
            ("Check this code for bugs", StepType.verify),
            ("Validate the schema", StepType.verify),
            ("Write a blog post about Python", StepType.draft),
            ("Draft the email response", StepType.draft),
            ("Generate the configuration file", StepType.draft),
            ("Summarize what we discussed", StepType.summarize),
            ("Give me a recap", StepType.summarize),
            ("Provide an overview of the findings", StepType.summarize),
        ],
    )
    def test_classification(self, text: str, expected: StepType):
        result = classify_step([{"role": "user", "content": text}])
        assert result == expected, f"Expected {expected.value} for '{text}', got {result.value}"

    def test_empty_messages_returns_generic(self):
        assert classify_step([]) == StepType.generic

    def test_no_content_returns_generic(self):
        assert classify_step([{"role": "user", "content": ""}]) == StepType.generic

    def test_unrecognized_text_returns_generic(self):
        assert classify_step([{"role": "user", "content": "Hello world"}]) == StepType.generic

    def test_uses_last_message(self):
        messages = [
            {"role": "user", "content": "Plan the approach"},
            {"role": "assistant", "content": "Here is the plan..."},
            {"role": "user", "content": "Now verify the code"},
        ]
        result = classify_step(messages)
        assert result == StepType.verify
