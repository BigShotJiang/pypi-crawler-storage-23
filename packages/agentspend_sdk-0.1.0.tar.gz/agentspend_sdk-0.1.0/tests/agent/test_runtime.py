"""Tests for the AgentSpend runtime with mocked LiteLLM calls."""

from unittest.mock import MagicMock, patch

import pytest

from token_aud.agent.policy import (
    GlobalConfig,
    LoopGuardConfig,
    ModelSpec,
    RoutingPolicy,
    StepPolicy,
    StepType,
)
from token_aud.agent.runtime import AgentSpend, RouteResult
from token_aud.agent.telemetry import CallbackSink, TelemetryEmitter


def _mock_completion_response(content="Hello!", prompt_tokens=50, completion_tokens=100):
    """Build a mock LiteLLM completion response."""
    mock = MagicMock()
    mock.choices = [MagicMock()]
    mock.choices[0].message.content = content
    mock.usage.prompt_tokens = prompt_tokens
    mock.usage.completion_tokens = completion_tokens
    return mock


@pytest.fixture
def simple_policy() -> RoutingPolicy:
    return RoutingPolicy(
        name="test",
        globals=GlobalConfig(
            default_model="gpt-4o-mini",
            max_cost_per_run_usd=1.0,
            fail_open=True,
        ),
        models={
            "gpt-4o-mini": ModelSpec(provider="openai", cost_tier="low", latency_tier="low"),
            "gpt-4o": ModelSpec(provider="openai", cost_tier="medium", latency_tier="medium"),
        },
        steps={
            StepType.plan: StepPolicy(
                default_model="gpt-4o-mini",
                fallback_chain=["gpt-4o"],
            ),
            StepType.generic: StepPolicy(
                default_model="gpt-4o-mini",
                fallback_chain=["gpt-4o"],
            ),
        },
        loop_guard=LoopGuardConfig(
            enabled=True,
            similarity_threshold=0.9,
            repeated_turn_limit=2,
            on_trigger={"action": "escalate", "escalate_to": "gpt-4o", "hard_stop_after": 2},
        ),
    )


class TestRouteCall:
    @patch("token_aud.agent.runtime.litellm")
    def test_basic_route(self, mock_litellm, simple_policy):
        mock_litellm.completion.return_value = _mock_completion_response("Test output")
        agent = AgentSpend(simple_policy, enable_telemetry=False)

        result = agent.route_call(
            step="plan",
            messages=[{"role": "user", "content": "Plan the approach"}],
        )

        assert isinstance(result, RouteResult)
        assert result.content == "Test output"
        assert result.model_used == "gpt-4o-mini"
        assert result.cost_usd >= 0
        assert result.latency_ms >= 0
        assert result.step == StepType.plan
        mock_litellm.completion.assert_called_once()

    @patch("token_aud.agent.runtime.litellm")
    def test_auto_classification(self, mock_litellm, simple_policy):
        mock_litellm.completion.return_value = _mock_completion_response()
        agent = AgentSpend(simple_policy, enable_telemetry=False)

        result = agent.route_call(
            messages=[{"role": "user", "content": "Plan the approach for building an API"}],
        )
        assert result.step == StepType.plan

    @patch("token_aud.agent.runtime.litellm")
    def test_cost_accumulates(self, mock_litellm, simple_policy):
        mock_litellm.completion.return_value = _mock_completion_response()
        agent = AgentSpend(simple_policy, enable_telemetry=False)

        agent.route_call(messages=[{"role": "user", "content": "Plan step"}], step="plan")
        agent.route_call(messages=[{"role": "user", "content": "Another step"}], step="plan")

        assert agent.run_cost_usd > 0
        assert agent.turn_index == 2

    @patch("token_aud.agent.runtime.litellm")
    def test_reset_run(self, mock_litellm, simple_policy):
        mock_litellm.completion.return_value = _mock_completion_response()
        agent = AgentSpend(simple_policy, enable_telemetry=False)

        agent.route_call(messages=[{"role": "user", "content": "test"}], step="plan")
        assert agent.turn_index == 1

        agent.reset_run()
        assert agent.turn_index == 0
        assert agent.run_cost_usd == 0.0


class TestFallback:
    @patch("token_aud.agent.runtime.litellm")
    def test_fallback_on_failure(self, mock_litellm, simple_policy):
        mock_litellm.completion.side_effect = [
            RuntimeError("Model unavailable"),
            _mock_completion_response("Fallback response"),
        ]
        agent = AgentSpend(simple_policy, enable_telemetry=False)

        result = agent.route_call(
            step="plan",
            messages=[{"role": "user", "content": "test"}],
        )
        assert result.content == "Fallback response"
        assert result.model_used == "gpt-4o"
        assert "gpt-4o-mini" in result.fallbacks_tried

    @patch("token_aud.agent.runtime.litellm")
    def test_all_models_fail_raises(self, mock_litellm):
        policy = RoutingPolicy(
            name="test",
            globals=GlobalConfig(default_model="gpt-4o-mini", fail_open=False),
            models={"gpt-4o-mini": ModelSpec(provider="openai")},
            steps={StepType.plan: StepPolicy(default_model="gpt-4o-mini", fallback_chain=[])},
        )
        mock_litellm.completion.side_effect = RuntimeError("all fail")
        agent = AgentSpend(policy, enable_telemetry=False)

        with pytest.raises(RuntimeError, match="All models failed"):
            agent.route_call(step="plan", messages=[{"role": "user", "content": "test"}])


class TestLoopGuardIntegration:
    @patch("token_aud.agent.runtime.litellm")
    def test_hard_stop_on_persistent_loop(self, mock_litellm, simple_policy):
        mock_litellm.completion.return_value = _mock_completion_response()
        agent = AgentSpend(simple_policy, enable_telemetry=False)

        msg = [{"role": "user", "content": "What is 2+2?"}]

        results = []
        with pytest.raises(RuntimeError, match="hard stop"):
            for _ in range(10):
                results.append(agent.route_call(messages=msg))

        assert len(results) >= 2


class TestTelemetryIntegration:
    @patch("token_aud.agent.runtime.litellm")
    def test_telemetry_emitted(self, mock_litellm, simple_policy):
        mock_litellm.completion.return_value = _mock_completion_response()
        received = []
        telemetry = TelemetryEmitter(sinks=[CallbackSink(lambda e: received.append(e))])
        agent = AgentSpend(simple_policy, telemetry=telemetry, enable_telemetry=True)

        agent.route_call(step="plan", messages=[{"role": "user", "content": "test"}])

        assert len(received) == 1
        assert received[0].step == "plan"
        assert received[0].outcome == "ok"
        assert received[0].model_used == "gpt-4o-mini"


class TestDefaultConstructor:
    def test_default_loads(self):
        agent = AgentSpend.default(enable_telemetry=False)
        assert agent.policy.name == "default"
        assert len(agent.policy.models) > 0
