"""Tests for the RoutingPolicy schema, YAML loading, and validation."""

import tempfile
from pathlib import Path

import pytest
import yaml

from token_aud.agent.policy import (
    GlobalConfig,
    LoopGuardConfig,
    ModelSpec,
    RoutingPolicy,
    StepPolicy,
    StepType,
)


class TestRoutingPolicyValidation:
    def test_minimal_policy(self):
        policy = RoutingPolicy(name="test", models={}, steps={})
        assert policy.name == "test"
        assert policy.version == 1
        assert policy.globals.default_model == "gpt-4o-mini"
        assert policy.loop_guard.enabled is True

    def test_full_policy(self):
        policy = RoutingPolicy(
            name="full",
            models={
                "gpt-4o-mini": ModelSpec(provider="openai", cost_tier="low", latency_tier="low"),
                "gpt-4o": ModelSpec(provider="openai", cost_tier="medium", latency_tier="medium"),
            },
            steps={
                StepType.plan: StepPolicy(
                    default_model="gpt-4o-mini",
                    allowed_models=["gpt-4o-mini"],
                    fallback_chain=["gpt-4o"],
                ),
            },
            loop_guard=LoopGuardConfig(
                enabled=True,
                on_trigger={"action": "escalate", "escalate_to": "gpt-4o"},
            ),
        )
        assert len(policy.models) == 2
        assert StepType.plan in policy.steps

    def test_unknown_model_in_step_raises(self):
        with pytest.raises(ValueError, match="unknown model"):
            RoutingPolicy(
                name="bad",
                models={"gpt-4o-mini": ModelSpec(provider="openai")},
                steps={
                    StepType.plan: StepPolicy(
                        default_model="nonexistent-model",
                    ),
                },
            )

    def test_unknown_model_in_fallback_raises(self):
        with pytest.raises(ValueError, match="unknown model"):
            RoutingPolicy(
                name="bad",
                models={"gpt-4o-mini": ModelSpec(provider="openai")},
                steps={
                    StepType.plan: StepPolicy(
                        default_model="gpt-4o-mini",
                        fallback_chain=["nonexistent-model"],
                    ),
                },
            )

    def test_unknown_escalation_model_raises(self):
        with pytest.raises(ValueError, match="unknown model"):
            RoutingPolicy(
                name="bad",
                models={"gpt-4o-mini": ModelSpec(provider="openai")},
                steps={},
                loop_guard=LoopGuardConfig(
                    on_trigger={"action": "escalate", "escalate_to": "nonexistent"},
                ),
            )

    def test_empty_models_skips_validation(self):
        policy = RoutingPolicy(
            name="empty",
            models={},
            steps={StepType.plan: StepPolicy(default_model="whatever")},
        )
        assert policy.steps[StepType.plan].default_model == "whatever"


class TestYamlLoading:
    def test_from_yaml_file(self, tmp_path: Path):
        data = {
            "version": 1,
            "name": "yaml-test",
            "models": {
                "gpt-4o-mini": {"provider": "openai", "cost_tier": "low", "latency_tier": "low"},
            },
            "steps": {
                "plan": {
                    "default_model": "gpt-4o-mini",
                    "allowed_models": ["gpt-4o-mini"],
                },
            },
        }
        yaml_path = tmp_path / "policy.yaml"
        yaml_path.write_text(yaml.dump(data))

        policy = RoutingPolicy.from_yaml(yaml_path)
        assert policy.name == "yaml-test"
        assert "gpt-4o-mini" in policy.models

    def test_from_dict(self):
        data = {
            "name": "dict-test",
            "models": {
                "gpt-4o-mini": {"provider": "openai"},
            },
            "steps": {},
        }
        policy = RoutingPolicy.from_dict(data)
        assert policy.name == "dict-test"

    def test_default_policy_loads(self):
        """The built-in default_routing_policy.yaml should load without errors."""
        from importlib import resources

        data_files = resources.files("token_aud.data")
        yaml_file = data_files.joinpath("default_routing_policy.yaml")
        policy = RoutingPolicy.from_yaml(str(yaml_file))
        assert policy.name == "default"
        assert len(policy.models) > 0
        assert len(policy.steps) > 0
