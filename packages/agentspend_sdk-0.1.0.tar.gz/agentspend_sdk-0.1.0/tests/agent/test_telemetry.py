"""Tests for telemetry event schema and sinks."""

import json
from pathlib import Path

import pytest

from token_aud.agent.telemetry import (
    CallbackSink,
    JsonlSink,
    TelemetryEmitter,
    TelemetryEvent,
)


@pytest.fixture
def sample_event() -> TelemetryEvent:
    return TelemetryEvent(
        step="plan",
        model_selected="gpt-4o-mini",
        model_used="gpt-4o-mini",
        prompt_tokens=100,
        completion_tokens=200,
        cost_usd=0.000150,
        latency_ms=450.0,
        turn_index=0,
        reason="Step policy default",
        outcome="ok",
    )


class TestTelemetryEvent:
    def test_to_dict(self, sample_event):
        d = sample_event.to_dict()
        assert d["step"] == "plan"
        assert d["model_selected"] == "gpt-4o-mini"
        assert d["cost_usd"] == 0.000150
        assert isinstance(d["timestamp_ms"], int)

    def test_defaults(self):
        event = TelemetryEvent(
            step="generic",
            model_selected="gpt-4o-mini",
            model_used="gpt-4o-mini",
        )
        assert event.fallbacks_tried == []
        assert event.outcome == "ok"
        assert event.error_message is None


class TestJsonlSink:
    def test_writes_jsonl(self, tmp_path: Path, sample_event):
        path = tmp_path / "events.jsonl"
        sink = JsonlSink(path)
        sink.write(sample_event)
        sink.flush()
        sink.close()

        lines = path.read_text().strip().split("\n")
        assert len(lines) == 1
        data = json.loads(lines[0])
        assert data["step"] == "plan"
        assert data["model_used"] == "gpt-4o-mini"

    def test_multiple_writes(self, tmp_path: Path, sample_event):
        path = tmp_path / "events.jsonl"
        sink = JsonlSink(path)
        for _ in range(5):
            sink.write(sample_event)
        sink.flush()
        sink.close()

        lines = path.read_text().strip().split("\n")
        assert len(lines) == 5


class TestCallbackSink:
    def test_callback_called(self, sample_event):
        received = []
        sink = CallbackSink(lambda e: received.append(e))
        sink.write(sample_event)
        assert len(received) == 1
        assert received[0].step == "plan"


class TestTelemetryEmitter:
    def test_fanout_to_multiple_sinks(self, tmp_path: Path, sample_event):
        received = []
        path = tmp_path / "events.jsonl"
        emitter = TelemetryEmitter(sinks=[
            JsonlSink(path),
            CallbackSink(lambda e: received.append(e)),
        ])
        emitter.emit(sample_event)
        emitter.flush()
        emitter.close()

        assert len(received) == 1
        lines = path.read_text().strip().split("\n")
        assert len(lines) == 1

    def test_sink_error_does_not_propagate(self, sample_event):
        def bad_sink_write(e):
            raise RuntimeError("boom")

        emitter = TelemetryEmitter(sinks=[CallbackSink(bad_sink_write)])
        emitter.emit(sample_event)
