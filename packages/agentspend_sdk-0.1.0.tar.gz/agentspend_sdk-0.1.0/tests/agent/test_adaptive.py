"""Tests for the adaptive routing module."""

import json
from pathlib import Path

import pytest

from token_aud.agent.adaptive import AdaptiveRouter, AdaptiveSuggestion


@pytest.fixture
def router() -> AdaptiveRouter:
    return AdaptiveRouter(min_samples=5, confidence_threshold=0.80)


class TestRecordOutcome:
    def test_records_success(self, router):
        router.record_outcome(step="plan", model="gpt-4o-mini", success=True, cost=0.001)
        stats = router.get_stats("plan")
        assert stats["gpt-4o-mini"]["total_calls"] == 1
        assert stats["gpt-4o-mini"]["success_rate"] == 1.0

    def test_records_failure(self, router):
        router.record_outcome(step="plan", model="gpt-4o-mini", success=False, cost=0.001)
        stats = router.get_stats("plan")
        assert stats["gpt-4o-mini"]["success_rate"] == 0.0

    def test_accumulates(self, router):
        for _ in range(8):
            router.record_outcome(step="plan", model="gpt-4o-mini", success=True, cost=0.001)
        for _ in range(2):
            router.record_outcome(step="plan", model="gpt-4o-mini", success=False, cost=0.001)
        stats = router.get_stats("plan")
        assert stats["gpt-4o-mini"]["total_calls"] == 10
        assert stats["gpt-4o-mini"]["success_rate"] == 0.8


class TestSuggest:
    def test_suggests_cheaper_model_with_high_confidence(self, router):
        for _ in range(10):
            router.record_outcome(step="plan", model="gpt-4o", success=True, cost=0.01)
        for _ in range(10):
            router.record_outcome(step="plan", model="gpt-4o-mini", success=True, cost=0.001)

        suggestion = router.suggest(step="plan", current_model="gpt-4o")
        assert suggestion.suggested_model == "gpt-4o-mini"
        assert suggestion.confidence >= 0.8

    def test_no_suggestion_below_min_samples(self, router):
        for _ in range(3):
            router.record_outcome(step="plan", model="gpt-4o-mini", success=True, cost=0.001)
        suggestion = router.suggest(step="plan", current_model="gpt-4o")
        assert suggestion.suggested_model is None

    def test_no_suggestion_below_confidence_threshold(self, router):
        for _ in range(4):
            router.record_outcome(step="plan", model="gpt-4o-mini", success=True, cost=0.001)
        for _ in range(4):
            router.record_outcome(step="plan", model="gpt-4o-mini", success=False, cost=0.001)
        suggestion = router.suggest(step="plan", current_model="gpt-4o")
        assert suggestion.suggested_model is None

    def test_no_suggestion_when_disabled(self, router):
        for _ in range(10):
            router.record_outcome(step="plan", model="gpt-4o-mini", success=True, cost=0.001)
        router.disable()
        suggestion = router.suggest(step="plan", current_model="gpt-4o")
        assert suggestion.suggested_model is None
        assert "disabled" in suggestion.reason.lower()

    def test_no_suggestion_when_candidate_is_more_expensive(self, router):
        for _ in range(10):
            router.record_outcome(step="plan", model="gpt-4o", success=True, cost=0.001)
        for _ in range(10):
            router.record_outcome(step="plan", model="gpt-4o-mini", success=True, cost=0.01)
        suggestion = router.suggest(step="plan", current_model="gpt-4o")
        assert suggestion.suggested_model is None


class TestRollbackSwitch:
    def test_disable_enable(self, router):
        assert router.enabled is True
        router.disable()
        assert router.enabled is False
        router.enable()
        assert router.enabled is True


class TestPersistence:
    def test_save_and_load(self, router, tmp_path: Path):
        for _ in range(5):
            router.record_outcome(step="plan", model="gpt-4o-mini", success=True, cost=0.001)

        save_path = tmp_path / "stats.json"
        router.save(save_path)

        new_router = AdaptiveRouter(min_samples=5, confidence_threshold=0.80)
        new_router.load(save_path)

        stats = new_router.get_stats("plan")
        assert stats["gpt-4o-mini"]["total_calls"] == 5
        assert stats["gpt-4o-mini"]["success_rate"] == 1.0

    def test_load_nonexistent_file(self, router, tmp_path: Path):
        router.load(tmp_path / "nonexistent.json")
        assert router.get_stats() == {}

    def test_saved_format_is_json(self, router, tmp_path: Path):
        router.record_outcome(step="plan", model="gpt-4o-mini", success=True, cost=0.001)
        save_path = tmp_path / "stats.json"
        router.save(save_path)

        data = json.loads(save_path.read_text())
        assert "plan" in data
        assert "gpt-4o-mini" in data["plan"]
