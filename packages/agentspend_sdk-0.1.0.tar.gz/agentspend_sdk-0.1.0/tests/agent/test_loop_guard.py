"""Tests for the loop guard."""

import pytest

from token_aud.agent.loop_guard import LoopGuard
from token_aud.agent.policy import LoopGuardConfig


@pytest.fixture
def config() -> LoopGuardConfig:
    return LoopGuardConfig(
        enabled=True,
        similarity_threshold=0.9,
        repeated_turn_limit=2,
        on_trigger={"action": "escalate", "escalate_to": "gpt-4o", "hard_stop_after": 2},
    )


class TestLoopDetection:
    def test_no_loop_on_first_turn(self, config):
        guard = LoopGuard(config)
        msg = [{"role": "user", "content": "What is 2+2?"}]
        assert guard.check(msg) is False

    def test_loop_after_repeated_turns(self, config):
        guard = LoopGuard(config)
        msg = [{"role": "user", "content": "What is 2+2?"}]
        guard.check(msg)
        guard.check(msg)
        assert guard.check(msg) is True

    def test_no_loop_with_varied_messages(self, config):
        guard = LoopGuard(config)
        prompts = [
            "What is the capital of France?",
            "Explain quantum computing in simple terms",
            "Write a Python function to sort a list",
            "How does photosynthesis work?",
            "Tell me about the history of jazz music",
            "What are the best practices for REST API design?",
            "Describe the water cycle in detail",
            "How do neural networks learn from data?",
            "What is the difference between TCP and UDP?",
            "Explain the concept of recursion with an example",
        ]
        for prompt in prompts:
            msg = [{"role": "user", "content": prompt}]
            assert guard.check(msg) is False

    def test_disabled_guard_never_detects(self):
        config = LoopGuardConfig(enabled=False)
        guard = LoopGuard(config)
        msg = [{"role": "user", "content": "Same message"}]
        for _ in range(10):
            assert guard.check(msg) is False


class TestHardStop:
    def test_hard_stop_after_escalations(self, config):
        guard = LoopGuard(config)
        assert guard.should_hard_stop is False
        guard.record_escalation()
        assert guard.should_hard_stop is False
        guard.record_escalation()
        assert guard.should_hard_stop is True

    def test_escalation_count_tracks(self, config):
        guard = LoopGuard(config)
        assert guard.escalation_count == 0
        guard.record_escalation()
        assert guard.escalation_count == 1


class TestReset:
    def test_reset_clears_state(self, config):
        guard = LoopGuard(config)
        msg = [{"role": "user", "content": "Same message"}]
        guard.check(msg)
        guard.check(msg)
        guard.record_escalation()
        guard.record_escalation()

        guard.reset()

        assert guard.escalation_count == 0
        assert guard.should_hard_stop is False
        assert guard.check(msg) is False
