"""Tests for the deterministic model router."""

import pytest

from token_aud.agent.policy import (
    GlobalConfig,
    LoopGuardConfig,
    ModelSpec,
    RoutingPolicy,
    RoutingRule,
    RoutingRuleCondition,
    StepPolicy,
    StepType,
)
from token_aud.agent.router import RouteContext, RouteDecision, decide_model
from token_aud.core.pricing import PricingEngine


@pytest.fixture
def pricing() -> PricingEngine:
    return PricingEngine()


@pytest.fixture
def basic_policy() -> RoutingPolicy:
    return RoutingPolicy(
        name="test",
        globals=GlobalConfig(
            default_model="gpt-4o-mini",
            max_cost_per_run_usd=1.0,
            max_cost_per_call_usd=0.05,
        ),
        models={
            "gpt-4o-mini": ModelSpec(provider="openai", cost_tier="low", latency_tier="low"),
            "gpt-4o": ModelSpec(provider="openai", cost_tier="medium", latency_tier="medium"),
            "gpt-4": ModelSpec(provider="openai", cost_tier="high", latency_tier="high"),
        },
        steps={
            StepType.plan: StepPolicy(
                default_model="gpt-4o-mini",
                allowed_models=["gpt-4o-mini"],
                fallback_chain=["gpt-4o"],
                max_cost_per_call_usd=0.002,
            ),
            StepType.reason: StepPolicy(
                default_model="gpt-4o",
                allowed_models=["gpt-4o", "gpt-4"],
                fallback_chain=["gpt-4o-mini"],
            ),
            StepType.generic: StepPolicy(
                default_model="gpt-4o-mini",
                fallback_chain=["gpt-4o"],
            ),
        },
        loop_guard=LoopGuardConfig(
            enabled=True,
            on_trigger={"action": "escalate", "escalate_to": "gpt-4o"},
        ),
    )


class TestStepPolicySelection:
    def test_plan_uses_cheap_model(self, basic_policy, pricing):
        ctx = RouteContext(step=StepType.plan, estimated_tokens=500)
        decision = decide_model(policy=basic_policy, pricing=pricing, ctx=ctx)
        assert decision.selected_model == "gpt-4o-mini"
        assert decision.reason == "Step policy default"

    def test_reason_uses_stronger_model(self, basic_policy, pricing):
        ctx = RouteContext(step=StepType.reason, estimated_tokens=500)
        decision = decide_model(policy=basic_policy, pricing=pricing, ctx=ctx)
        assert decision.selected_model == "gpt-4o"

    def test_unknown_step_uses_global_default(self, pricing):
        policy = RoutingPolicy(
            name="test",
            models={"gpt-4o-mini": ModelSpec(provider="openai")},
            steps={},
        )
        ctx = RouteContext(step=StepType.verify, estimated_tokens=500)
        decision = decide_model(policy=policy, pricing=pricing, ctx=ctx)
        assert decision.selected_model == "gpt-4o-mini"
        assert "Global default" in decision.reason


class TestFallbackChain:
    def test_fallback_chain_populated(self, basic_policy, pricing):
        ctx = RouteContext(step=StepType.plan, estimated_tokens=500)
        decision = decide_model(policy=basic_policy, pricing=pricing, ctx=ctx)
        assert decision.fallback_chain == ["gpt-4o"]

    def test_empty_fallback_chain(self, pricing):
        policy = RoutingPolicy(
            name="test",
            models={"gpt-4o-mini": ModelSpec(provider="openai")},
            steps={
                StepType.plan: StepPolicy(
                    default_model="gpt-4o-mini",
                    fallback_chain=[],
                ),
            },
        )
        ctx = RouteContext(step=StepType.plan, estimated_tokens=500)
        decision = decide_model(policy=policy, pricing=pricing, ctx=ctx)
        assert decision.fallback_chain == []


class TestLoopEscalation:
    def test_loop_detected_escalates(self, basic_policy, pricing):
        ctx = RouteContext(step=StepType.generic, loop_detected=True, estimated_tokens=500)
        decision = decide_model(policy=basic_policy, pricing=pricing, ctx=ctx)
        assert decision.selected_model == "gpt-4o"
        assert "Loop detected" in decision.reason

    def test_no_loop_no_escalation(self, basic_policy, pricing):
        ctx = RouteContext(step=StepType.generic, loop_detected=False, estimated_tokens=500)
        decision = decide_model(policy=basic_policy, pricing=pricing, ctx=ctx)
        assert decision.selected_model == "gpt-4o-mini"


class TestBudgetGuard:
    def test_low_budget_triggers_downgrade(self, basic_policy, pricing):
        ctx = RouteContext(
            step=StepType.reason,
            run_remaining_budget_usd=0.0001,
            estimated_tokens=500,
        )
        decision = decide_model(policy=basic_policy, pricing=pricing, ctx=ctx)
        assert "Budget guard" in decision.reason

    def test_sufficient_budget_no_downgrade(self, basic_policy, pricing):
        ctx = RouteContext(
            step=StepType.reason,
            run_remaining_budget_usd=10.0,
            estimated_tokens=500,
        )
        decision = decide_model(policy=basic_policy, pricing=pricing, ctx=ctx)
        assert decision.selected_model == "gpt-4o"
        assert "Budget guard" not in decision.reason

    def test_no_budget_set_uses_default(self, basic_policy, pricing):
        ctx = RouteContext(
            step=StepType.reason,
            run_remaining_budget_usd=None,
            estimated_tokens=500,
        )
        decision = decide_model(policy=basic_policy, pricing=pricing, ctx=ctx)
        assert decision.selected_model == "gpt-4o"


class TestDynamicRules:
    def test_rule_overrides_step_policy(self, pricing):
        policy = RoutingPolicy(
            name="test",
            models={
                "gpt-4o-mini": ModelSpec(provider="openai"),
                "gpt-4o": ModelSpec(provider="openai"),
                "gpt-4": ModelSpec(provider="openai"),
            },
            steps={
                StepType.plan: StepPolicy(default_model="gpt-4o-mini"),
            },
            routing_rules=[
                RoutingRule(
                    name="force-gpt4-on-turn-5",
                    conditions=[
                        RoutingRuleCondition(field="turn_index", operator="gte", value=5),
                    ],
                    then_model="gpt-4",
                    priority=10,
                ),
            ],
        )
        ctx = RouteContext(step=StepType.plan, turn_index=5, estimated_tokens=500)
        decision = decide_model(policy=policy, pricing=pricing, ctx=ctx)
        assert decision.selected_model == "gpt-4"
        assert "dynamic routing rule" in decision.reason.lower()

    def test_unmatched_rule_falls_through(self, pricing):
        policy = RoutingPolicy(
            name="test",
            models={
                "gpt-4o-mini": ModelSpec(provider="openai"),
                "gpt-4": ModelSpec(provider="openai"),
            },
            steps={
                StepType.plan: StepPolicy(default_model="gpt-4o-mini"),
            },
            routing_rules=[
                RoutingRule(
                    name="never-match",
                    conditions=[
                        RoutingRuleCondition(field="turn_index", operator="gte", value=999),
                    ],
                    then_model="gpt-4",
                ),
            ],
        )
        ctx = RouteContext(step=StepType.plan, turn_index=0, estimated_tokens=500)
        decision = decide_model(policy=policy, pricing=pricing, ctx=ctx)
        assert decision.selected_model == "gpt-4o-mini"


class TestCostEstimation:
    def test_estimated_cost_populated(self, basic_policy, pricing):
        ctx = RouteContext(step=StepType.plan, estimated_tokens=1000)
        decision = decide_model(policy=basic_policy, pricing=pricing, ctx=ctx)
        assert decision.estimated_cost_usd > 0

    def test_step_type_preserved(self, basic_policy, pricing):
        ctx = RouteContext(step=StepType.draft, estimated_tokens=500)
        decision = decide_model(policy=basic_policy, pricing=pricing, ctx=ctx)
        assert decision.step == StepType.draft
