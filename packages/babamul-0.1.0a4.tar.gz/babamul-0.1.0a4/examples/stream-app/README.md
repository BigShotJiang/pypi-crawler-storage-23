# Babamul example stream reading app

To run the app, first copy `.env.example` to `.env`,
replace your Babamul Kafka credentials, then call:

```sh
uv run main.py
```
