"""Router + Playbooks example for PenguiFlow.

Demonstrates the idiomatic pattern for routing messages to different playbooks
using built-in routers and call_playbook.
"""

__all__ = []
