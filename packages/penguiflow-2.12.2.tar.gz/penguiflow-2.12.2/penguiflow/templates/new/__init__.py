"""Project scaffolding templates for `penguiflow new`."""
