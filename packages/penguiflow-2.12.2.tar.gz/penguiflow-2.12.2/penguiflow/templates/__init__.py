"""Embedded templates for PenguiFlow CLI."""
