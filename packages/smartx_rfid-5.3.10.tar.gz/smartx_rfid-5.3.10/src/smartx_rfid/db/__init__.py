from ._main import DatabaseManager

_DATABASE_URL_MYSQL = "mysql+pymysql://root:admin@localhost:3306/smtx"
_DATABASE_URL_SQLITE = "sqlite:///smtx.db"
_DATABASE_URL_POSTGRESQL = "postgresql+psycopg2://app_user:app_password@localhost:5432/smtx"
