from core.email.manager import EmailManager
from core.email.types import EmailDispatchRequest, EmailMessage, EmailSendResult, MountedTemplate

__all__ = [
    "EmailDispatchRequest",
    "EmailManager",
    "EmailMessage",
    "EmailSendResult",
    "MountedTemplate",
]
