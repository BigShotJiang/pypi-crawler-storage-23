# Email templates are mounted into core/email/mounted_templates.py via CLI commands.
