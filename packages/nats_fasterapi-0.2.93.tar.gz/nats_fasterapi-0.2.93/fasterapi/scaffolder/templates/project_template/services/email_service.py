from core.email.manager import EmailManager
from core.email.types import EmailDispatchRequest, EmailSendResult

__all__ = ["EmailDispatchRequest", "EmailManager", "EmailSendResult"]
