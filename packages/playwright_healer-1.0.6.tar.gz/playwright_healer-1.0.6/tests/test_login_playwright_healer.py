"""Login tests using playwright-healer for self‑healing locators.

These tests mirror the flows in test_login.py but rely on the
playwright-healer pytest plugin and its ``healing_page`` fixture
instead of the competitor's autoheal-locator integration.
"""

import pytest


@pytest.mark.login
@pytest.mark.asyncio
async def test_successful_login_with_playwright_healer(healing_page):
    """Valid credentials should lead to a success message."""

    # Navigate and perform login using healing_page
    await healing_page.goto("https://the-internet.herokuapp.com/login")

    await healing_page.fill(
        "#username",
        "Username input field on login page",
        value="tomsmith",
    )
    await healing_page.fill(
        "#password",
        "Password input field on login page",
        value="SuperSecretPassword!",
    )
    await healing_page.click(
        "button[type='submit']",
        "Login submit button",
    )

    # Verify success flash is present
    assert await healing_page.is_present(
        ".flash.success",
        "Success flash message",
    ), "Success message should be visible after valid login"


@pytest.mark.login
@pytest.mark.asyncio
async def test_invalid_login_with_playwright_healer(healing_page):
    """Invalid credentials should show an error message."""

    await healing_page.goto("https://the-internet.herokuapp.com/login")

    await healing_page.fill(
        "#username",
        "Username input field on login page",
        value="invalid",
    )
    await healing_page.fill(
        "#password",
        "Password input field on login page",
        value="wrongpassword",
    )
    await healing_page.click(
        "button[type='submit']",
        "Login submit button",
    )

    # Verify error flash is present
    assert await healing_page.is_present(
        ".flash.error",
        "Error flash message",
    ), "Error message should be visible after invalid login"


@pytest.mark.login
@pytest.mark.healing
@pytest.mark.asyncio
async def test_login_with_broken_selector_playwright_healer(healing_page):
    """Demonstrate playwright-healer fixing a broken username selector."""

    await healing_page.goto("https://the-internet.herokuapp.com/login")

    # Intentionally broken selector (typo) for username: healer should repair it
    await healing_page.fill(
        "#userid",  # Wrong - should be #username
        "Username input field on login page",
        value="tomsmith",
    )

    # Continue with correct selectors
    await healing_page.fill(
        "#password",
        "Password input field",
        value="SuperSecretPassword!",
    )
    await healing_page.click(
        "button[type='submit']",
        "Login button",
    )

    # Verify success flash is present
    assert await healing_page.is_present(
        ".flash.success",
        "Success message",
    ), "Success message should be visible after healed login flow"
