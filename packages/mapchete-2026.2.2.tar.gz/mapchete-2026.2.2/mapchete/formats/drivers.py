"""
Entry point where all drivers get registered.

If you want to implement a new driver, register your module to
``mapchete.formats.drivers`` (see ``pyproject.toml``).
"""
