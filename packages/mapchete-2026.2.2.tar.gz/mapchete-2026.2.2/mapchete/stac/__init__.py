from __future__ import annotations

import logging

from mapchete.stac.tiled_assets import STACTA

logger = logging.getLogger(__name__)

__all__ = ["STACTA"]
