import torch

def b_stratified_indices(y, samples, seed=0):
    """
    分层随机采样：按照 y 的类别分布比例，从 全部样本中抽取 samples 个样本的索引 idx
    (避免类别不平衡)

    参数：
    - y: shape = [N]，每个样本的 label（最好是离散整数标签）
    - samples: 要抽取的总样本数

    返回：
    - idx: Tensor, shape = [samples]，抽样得到的样本索引（已打乱）
    """
    # 1) 防止 samples 超过样本总数
    samples = min(samples, y.numel())

    # 2) 构造随机数生成器，并固定随机种子（可复现）
    g = torch.Generator(device=y.device)
    g.manual_seed(seed)

    # 3) 统计每个类别有哪些，以及每类样本数量 counts
    # classes: [C]，counts: [C]
    classes, counts = torch.unique(y, return_counts=True)

    # 4) 按“原始类别占比”分配每个类别要抽多少个样本
    # k: [C]，k_i ≈ counts_i / sum(counts) * n
    k = torch.floor(counts.float() / counts.sum() * samples).long()

    # 5) 由于 floor 向下取整，k 的总和可能小于 n，需要把剩余的 remain 补回去
    remain = samples - k.sum()
    if remain > 0:
        # 把剩余名额优先分配给样本数更多的类别（简单且稳定的补齐策略）
        order = torch.argsort(counts, descending=True)
        k[order[:remain]] += 1

    # 6) 对每个类别分别随机抽取 k_i 个索引
    idx_all = []
    for c, kc in zip(classes, k):
        if kc.item() == 0:
            # 这个类分配到 0 个就跳过
            continue

        # 找到当前类别 c 的所有样本索引
        idx_c = torch.where(y == c)[0]

        # 在该类别内部打乱，并取前 kc 个（不放回抽样）
        pick = idx_c[torch.randperm(idx_c.numel(), generator=g, device=y.device)[:kc]]
        idx_all.append(pick)

    # 7) 拼接所有类别的索引，得到总共 n 个索引
    idx = torch.cat(idx_all)

    # 8) 再整体打乱一次，避免输出是“按类别块状排列”的顺序
    idx = idx[torch.randperm(idx.numel(), generator=g, device=y.device)]

    return idx

if __name__ == '__main__':
    torch.manual_seed(0)

    # 1) 构造一个不均衡标签：0类 5000，1类 2000，2类 500，3类 50
    y = torch.tensor([0] * 5000 + [1] * 2000 + [2] * 500 + [3] * 50, dtype=torch.long)

    # 2) 设定抽样数
    samples = 800
    idx = b_stratified_indices(y, samples=samples, seed=42)

    # 3) 基本检查
    print("=== Basic Check ===")
    print("Total N:", y.numel())
    print("Sampled:", idx.numel())
    print("Unique idx:", idx.unique().numel())  # replacement=False，所以应等于 samples（或接近）
    print("Idx min/max:", idx.min().item(), idx.max().item())


    # 4) 统计原始分布 vs 抽样分布
    def dist_count(y_):
        cls, cnt = torch.unique(y_, return_counts=True)
        # 方便打印：按类别从小到大排序
        order = torch.argsort(cls)
        return cls[order], cnt[order]


    cls0, cnt0 = dist_count(y)
    cls1, cnt1 = dist_count(y[idx])

    print("\n=== Distribution Compare ===")
    print("Original counts:")
    for c, k in zip(cls0.tolist(), cnt0.tolist()):
        print(f"  class {c}: {k} ({k / y.numel():.4f})")

    print("\nSampled counts:")
    for c, k in zip(cls1.tolist(), cnt1.tolist()):
        print(f"  class {c}: {k} ({k / samples:.4f})")

    # 5) 检查抽样后的顺序是否被打乱（不是按类别块状排列）
    print("\n=== First 30 sampled labels (should look mixed) ===")
    print(y[idx][:30].tolist())