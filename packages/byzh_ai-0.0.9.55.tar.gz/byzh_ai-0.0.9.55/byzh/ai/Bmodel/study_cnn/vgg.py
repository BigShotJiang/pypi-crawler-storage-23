import torch
import torch.nn as nn
import torch.nn.functional as F

from byzh.ai.Butils import b_get_params

# -----------------------------
# VGG 各版本的“配置表”
# 用数字表示输出通道数，用 'M' 表示 MaxPool
# -----------------------------
cfgs = {
    # VGG11: 8个conv + 3个linear（论文叫 11 层）
    "VGG11": [
        64, "M",
        128, "M",
        256, 256, "M",
        512, 512, "M",
        512, 512, "M"
    ],
    # VGG13: 10个conv
    "VGG13": [
        64, 64, "M",
        128, 128, "M",
        256, 256, "M",
        512, 512, "M",
        512, 512, "M"
    ],
    # VGG16: 13个conv（最常用）
    "VGG16": [
        64, 64, "M",
        128, 128, "M",
        256, 256, 256, "M",
        512, 512, 512, "M",
        512, 512, 512, "M"
    ],
    # VGG19: 16个conv
    "VGG19": [
        64, 64, "M",
        128, 128, "M",
        256, 256, 256, 256, "M",
        512, 512, 512, 512, "M",
        512, 512, 512, 512, "M"
    ],
}


def make_vgg_features(cfg, use_bn=False):
    """
    根据 cfg 列表构建 VGG 的卷积特征提取部分 features
    - cfg: cfgs["VGG16"] 这种列表
    - use_bn: 是否在每个卷积后加 BN（原论文中 无BN）
    """
    layers = []
    in_channels = 3  # 输入 RGB 三通道

    for v in cfg:
        if v == "M":
            # 最大池化：把 H,W 各减半
            layers.append(nn.MaxPool2d(kernel_size=2, stride=2))
        else:
            # 3×3 卷积（VGG 固定用 3×3，padding=1 -> 保持尺寸不变）
            conv = nn.Conv2d(in_channels, v, kernel_size=3, padding=1)

            if use_bn:
                layers.extend([conv, nn.BatchNorm2d(v), nn.ReLU()])
            else:
                layers.extend([conv, nn.ReLU()])

            in_channels = v

    return nn.Sequential(*layers)

class B_VGG11_Paper(nn.Module):
    """
    VGG11：features + classifier

    input shape: (N, 3, 224, 224)
    """
    def __init__(self, num_classes=1000, use_bn=False):
        super().__init__()

        # 卷积特征提取部分
        self.features = make_vgg_features(cfgs["VGG11"], use_bn=use_bn)

        # 自适应池化到 7×7
        self.avgpool = nn.AdaptiveAvgPool2d((7, 7))

        # 分类头
        self.classifier = nn.Sequential(
            nn.Linear(512 * 7 * 7, 4096),
            nn.ReLU(),
            nn.Dropout(p=0.5),

            nn.Linear(4096, 4096),
            nn.ReLU(),
            nn.Dropout(p=0.5),

            nn.Linear(4096, num_classes),
        )

    def forward(self, x):
        x = self.features(x)      # N, 512, 7, 7（对 224 输入来说）
        x = self.avgpool(x)       # 强制变成 N, 512, 7, 7（更稳）
        x = torch.flatten(x, 1)   # N, 512*7*7
        x = self.classifier(x)    # N, num_classes
        return x

class B_VGG13_Paper(nn.Module):
    """
    VGG13：features + classifier

    input shape: (N, 3, 224, 224)
    """
    def __init__(self, num_classes=1000, use_bn=False):
        super().__init__()

        # 卷积特征提取部分
        self.features = make_vgg_features(cfgs["VGG13"], use_bn=use_bn)

        # 自适应池化到 7×7
        self.avgpool = nn.AdaptiveAvgPool2d((7, 7))

        # 分类头
        self.classifier = nn.Sequential(
            nn.Linear(512 * 7 * 7, 4096),
            nn.ReLU(),
            nn.Dropout(p=0.5),

            nn.Linear(4096, 4096),
            nn.ReLU(),
            nn.Dropout(p=0.5),

            nn.Linear(4096, num_classes),
        )

    def forward(self, x):
        x = self.features(x)      # N, 512, 7, 7（对 224 输入来说）
        x = self.avgpool(x)       # 强制变成 N, 512, 7, 7（更稳）
        x = torch.flatten(x, 1)   # N, 512*7*7
        x = self.classifier(x)    # N, num_classes
        return x

class B_VGG16_Paper(nn.Module):
    """
    VGG16：features + classifier

    input shape: (N, 3, 224, 224)
    """
    def __init__(self, num_classes=1000, use_bn=False):
        super().__init__()

        # 卷积特征提取部分
        self.features = make_vgg_features(cfgs["VGG16"], use_bn=use_bn)

        # 自适应池化到 7×7
        self.avgpool = nn.AdaptiveAvgPool2d((7, 7))

        # 分类头
        self.classifier = nn.Sequential(
            nn.Linear(512 * 7 * 7, 4096),
            nn.ReLU(),
            nn.Dropout(p=0.5),

            nn.Linear(4096, 4096),
            nn.ReLU(),
            nn.Dropout(p=0.5),

            nn.Linear(4096, num_classes),
        )

    def forward(self, x):
        x = self.features(x)      # N, 512, 7, 7（对 224 输入来说）
        x = self.avgpool(x)       # 强制变成 N, 512, 7, 7（更稳）
        x = torch.flatten(x, 1)   # N, 512*7*7
        x = self.classifier(x)    # N, num_classes
        return x

class B_VGG19_Paper(nn.Module):
    """
    VGG19：features + classifier

    input shape: (N, 3, 224, 224)
    """
    def __init__(self, num_classes=1000, use_bn=False):
        super().__init__()

        # 卷积特征提取部分
        self.features = make_vgg_features(cfgs["VGG19"], use_bn=use_bn)

        # 自适应池化到 7×7
        self.avgpool = nn.AdaptiveAvgPool2d((7, 7))

        # 分类头
        self.classifier = nn.Sequential(
            nn.Linear(512 * 7 * 7, 4096),
            nn.ReLU(),
            nn.Dropout(p=0.5),

            nn.Linear(4096, 4096),
            nn.ReLU(),
            nn.Dropout(p=0.5),

            nn.Linear(4096, num_classes),
        )

    def forward(self, x):
        x = self.features(x)      # N, 512, 7, 7（对 224 输入来说）
        x = self.avgpool(x)       # 强制变成 N, 512, 7, 7（更稳）
        x = torch.flatten(x, 1)   # N, 512*7*7
        x = self.classifier(x)    # N, num_classes
        return x


if __name__ == "__main__":
    # 测试 VGG11 输入输出
    model = B_VGG11_Paper(num_classes=1000)
    x = torch.randn(2, 3, 224, 224)
    y = model(x)
    print("VGG16 输出形状:", y.shape)  # torch.Size([2, 1000])
    print(f"参数量: {b_get_params(model)}")  # 132_863_336

    # 测试 VGG13 输入输出
    model = B_VGG13_Paper(num_classes=1000)
    x = torch.randn(2, 3, 224, 224)
    y = model(x)
    print("VGG16 输出形状:", y.shape)  # torch.Size([2, 1000])
    print(f"参数量: {b_get_params(model)}")  # 133_047_848

    # 测试 VGG16 输入输出
    model = B_VGG16_Paper(num_classes=1000)
    x = torch.randn(2, 3, 224, 224)
    y = model(x)
    print("VGG16 输出形状:", y.shape)  # torch.Size([2, 1000])
    print(f"参数量: {b_get_params(model)}")  # 138_357_544

    # 测试 VGG19 输入输出
    model = B_VGG19_Paper(num_classes=1000)
    x = torch.randn(2, 3, 224, 224)
    y = model(x)
    print("VGG16 输出形状:", y.shape)  # torch.Size([2, 1000])
    print(f"参数量: {b_get_params(model)}")  # 143_667_240