import torch
import torch.nn as nn
import torch.nn.functional as F

from byzh.ai.Butils import b_get_params

class B_AlexNet_Paper(nn.Module):
    """
    input shape: (N, 3, 224, 224)
    """
    def __init__(self, num_classes=1000):
        super().__init__()
        # =========
        # 特征提取部分
        # =========
        self.conv1 = nn.Conv2d(3, 96, kernel_size=11, stride=4)
        self.relu1 = nn.ReLU(inplace=True)
        self.lrn1 = nn.LocalResponseNorm(size=5, alpha=1e-4, beta=0.75, k=2.0)
        self.pool1 = nn.MaxPool2d(kernel_size=3, stride=2)

        self.conv2 = nn.Conv2d(96, 256, kernel_size=5, padding=2)
        self.relu2 = nn.ReLU(inplace=True)
        self.lrn2 = nn.LocalResponseNorm(size=5, alpha=1e-4, beta=0.75, k=2.0)
        self.pool2 = nn.MaxPool2d(kernel_size=3, stride=2)

        self.conv3 = nn.Conv2d(256, 384, kernel_size=3, padding=1)
        self.relu3 = nn.ReLU(inplace=True)

        self.conv4 = nn.Conv2d(384, 384, kernel_size=3, padding=1)
        self.relu4 = nn.ReLU(inplace=True)

        self.conv5 = nn.Conv2d(384, 256, kernel_size=3, padding=1)
        self.relu5 = nn.ReLU(inplace=True)
        self.pool3 = nn.MaxPool2d(kernel_size=3, stride=2)

        # =========
        # 分类器部分
        # 256*6*6 对齐 227×227 输入
        # =========
        self.classifier = nn.Sequential(
            nn.Dropout(p=0.5), # 仅在model.train()训练时才启用
            nn.Linear(256 * 6 * 6, 4096),
            nn.ReLU(inplace=True),

            nn.Dropout(p=0.5), # 仅在model.train()训练时才启用
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),

            nn.Linear(4096, num_classes),
        )

    def forward(self, x):
        # =========
        # 1) 输入尺寸对齐：224 -> 227
        # =========
        if x.shape[-2:] == (224, 224):
            x = F.pad(x, (1, 2, 1, 2), mode="constant", value=0.0)

        # =========
        # 2) Conv1 -> ReLU -> LRN -> Pool
        # =========
        x = self.conv1(x) # (N, 96, 55, 55)
        x = self.relu1(x)
        x = self.lrn1(x)
        x = self.pool1(x) # (N, 96, 27, 27)

        # =========
        # 3) Conv2 -> ReLU -> LRN -> Pool
        # =========
        x = self.conv2(x) # (N, 256, 27, 27)
        x = self.relu2(x)
        x = self.lrn2(x)
        x = self.pool2(x) # (N, 256, 13, 13)

        # =========
        # 4) Conv3 -> ReLU
        # =========
        x = self.conv3(x) # (N, 384, 13, 13)
        x = self.relu3(x)

        # =========
        # 5) Conv4 -> ReLU
        # =========
        x = self.conv4(x) # (N, 384, 13, 13)
        x = self.relu4(x)

        # =========
        # 6) Conv5 -> ReLU -> Pool
        # =========
        x = self.conv5(x) # (N, 256, 13, 13)
        x = self.relu5(x)
        x = self.pool3(x) # (N, 256, 6, 6)

        # =========
        # 7) Flatten + classifier
        # =========
        x = x.flatten(1) # (N, 256*6*6)
        x = self.classifier(x)

        return x


if __name__ == '__main__':
    net = B_AlexNet_Paper(num_classes=1000)
    a = torch.randn(50, 3, 224, 224)
    result = net(a)
    print(result.shape)
    print(f"参数量: {b_get_params(net)}") # 62_378_344