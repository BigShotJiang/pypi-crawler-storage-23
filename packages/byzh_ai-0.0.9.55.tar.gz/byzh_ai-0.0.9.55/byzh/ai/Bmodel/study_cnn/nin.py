import torch
import torch.nn as nn
import torch.nn.functional as F

from byzh.ai.Butils import b_get_params

class MLPConv(nn.Module):
    """
    NiN 的核心模块：MLPConv（“卷积里的小网络”）
    结构：卷积(k×k) + ReLU  ->  1×1卷积 + ReLU  ->  1×1卷积 + ReLU

    直观理解：
    - 第一个 k×k 卷积负责提取局部空间特征（看邻域）
    - 后面两层 1×1 卷积相当于对“通道维”做 MLP（增强通道间非线性组合能力）
    """
    def __init__(self, in_ch, out_ch, k, s=1, padding=0):
        super().__init__()
        self.net = nn.Sequential(
            # 空间卷积：提取局部空间模式
            nn.Conv2d(in_ch, out_ch, kernel_size=k, stride=s, padding=padding, bias=True),
            nn.ReLU(inplace=True),

            # 1×1 卷积：等价于对每个像素位置的通道向量做一次“全连接”
            nn.Conv2d(out_ch, out_ch, kernel_size=1, stride=1, padding=0, bias=True),
            nn.ReLU(inplace=True),

            # 1×1 卷积：进一步增强非线性表达（模拟更深的 MLP）
            nn.Conv2d(out_ch, out_ch, kernel_size=1, stride=1, padding=0, bias=True),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.net(x)


class B_NiN_Paper_CIFAR(nn.Module):
    """
    CIFAR 版本（输入 32×32）的 NiN
    论文风格要点：
    - 多个 MLPConv 堆叠
    - 中间用 pooling 下采样
    - 用 Dropout 抑制过拟合
    - 最后用 1×1 conv 输出类别通道 + 全局平均池化(GAP) 代替全连接

    input shape: (N, 3, 224, 224)
    """
    def __init__(self, num_classes=10, dropout_p=0.5):
        super().__init__()

        # -------------------------
        # Block 1
        # 输入: 32×32
        # conv(5,pad2) 后仍是 32×32
        # maxpool(3, stride=2) -> 15×15（因为 (32-3)/2 + 1 = 15）
        # -------------------------
        self.block1 = nn.Sequential(
            MLPConv(3, 192, k=5, s=1, padding=2),
            nn.MaxPool2d(kernel_size=3, stride=2),
            nn.Dropout(p=dropout_p),
        )

        # -------------------------
        # Block 2
        # 输入: 15×15
        # conv(5,pad2) 后仍是 15×15
        # avgpool(3, stride=2) -> 7×7（因为 (15-3)/2 + 1 = 7）
        # -------------------------
        self.block2 = nn.Sequential(
            MLPConv(192, 192, k=5, s=1, padding=2),
            nn.AvgPool2d(kernel_size=3, stride=2),
            nn.Dropout(p=dropout_p),
        )

        # -------------------------
        # Block 3
        # 输入: 7×7
        # conv(3,pad1) 后仍是 7×7
        # 通常最后一个大块可以不再下采样（直接为分类头服务）
        # -------------------------
        self.block3 = nn.Sequential(
            MLPConv(192, 192, k=3, s=1, padding=1),
            nn.Dropout(p=dropout_p),
        )

        # -------------------------
        # 分类头：
        # 1×1 conv 把通道数映射到 num_classes
        # 然后用 GAP 把 H×W 平均成 1×1
        # 相当于“无参数全连接”，显著减少参数并缓解过拟合
        # -------------------------
        self.classifier = nn.Conv2d(192, num_classes, kernel_size=1, stride=1, padding=0, bias=True)

    def forward(self, x):
        x = self.block1(x)
        x = self.block2(x)
        x = self.block3(x)

        # 输出：N, num_classes, H, W
        x = self.classifier(x)

        # 全局平均池化：把每个类别通道在空间维度做平均 -> N, num_classes, 1, 1
        x = F.adaptive_avg_pool2d(x, 1)

        # 拉平为 N, num_classes
        x = x.view(x.size(0), -1)
        return x


class B_NiN_Paper_ImageNet(nn.Module):
    """
    ImageNet 版本（输入 224×224）的 NiN（常见复现形态）
    主要变化：
    - 开头用更大的卷积核 + 更大的 stride，快速扩大感受野并降分辨率
    - 通道数整体更大
    - 同样保留：MLPConv + Dropout + 最终 1×1 conv + GAP

    input shape: (N, 3, 224, 224)
    """
    def __init__(self, num_classes=1000, dropout_p=0.5):
        super().__init__()

        self.features = nn.Sequential(
            # -------------------------
            # Stem：快速降采样
            # 224×224 -> conv(11, stride=4, pad=2) -> 55×55
            # 55×55 -> maxpool(3, stride=2) -> 27×27
            # -------------------------
            MLPConv(3, 96, k=11, s=4, padding=2),
            nn.MaxPool2d(3, stride=2),
            nn.Dropout(p=dropout_p),

            # -------------------------
            # 27×27 -> MLPConv(5,pad2) -> 27×27
            # 27×27 -> maxpool(3, stride=2) -> 13×13
            # -------------------------
            MLPConv(96, 256, k=5, s=1, padding=2),
            nn.MaxPool2d(3, stride=2),
            nn.Dropout(p=dropout_p),

            # -------------------------
            # 13×13 -> MLPConv(3,pad1) -> 13×13
            # 13×13 -> maxpool(3, stride=2) -> 6×6
            # -------------------------
            MLPConv(256, 384, k=3, s=1, padding=1),
            nn.MaxPool2d(3, stride=2),
            nn.Dropout(p=dropout_p),

            # -------------------------
            # 6×6 -> MLPConv(3,pad1) -> 6×6
            # 这里不再 pool，直接交给分类头 + GAP
            # -------------------------
            MLPConv(384, 1024, k=3, s=1, padding=1),
            nn.Dropout(p=dropout_p),
        )

        # 分类头：通道映射到类别数
        self.classifier = nn.Conv2d(
            in_channels=1024, out_channels=num_classes,
            kernel_size=1, stride=1, padding=0, bias=True
        )

    def forward(self, x):
        x = self.features(x)

        # N, num_classes, H, W
        x = self.classifier(x)

        # GAP：N, num_classes, 1, 1
        x = F.adaptive_avg_pool2d(x, 1)

        # N, num_classes
        return x.flatten(1)


if __name__ == "__main__":
    # -------------------------
    # CIFAR 测试：输入 32×32
    # -------------------------
    model = B_NiN_Paper_CIFAR(num_classes=10)
    x = torch.randn(4, 3, 32, 32)
    y = model(x)
    print(y.shape)  # 期望输出: torch.Size([4, 10])
    print(f"参数量: {b_get_params(model)}")  # 1_492_618

    # -------------------------
    # ImageNet 测试：输入 224×224
    # -------------------------
    model = B_NiN_Paper_ImageNet(num_classes=1000)
    x = torch.randn(2, 3, 224, 224)
    y = model(x)
    print(y.shape)  # 期望输出: torch.Size([2, 1000])
    print(f"参数量: {b_get_params(model)}")  # 8_644_776
