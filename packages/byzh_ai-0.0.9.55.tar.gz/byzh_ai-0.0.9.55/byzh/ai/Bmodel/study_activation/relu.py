import numpy as np
import matplotlib.pyplot as plt

# 定义ReLU函数
def relu(x):
    """ReLU激活函数：f(x) = max(0, x)"""
    return np.maximum(0, x)

# 定义ReLU函数的导数
def relu_derivative(x):
    """ReLU导数：
    当x > 0时，f'(x) = 1；
    当x <= 0时，f'(x) = 0；
    注意：x=0处导数在数学上无定义，工程上通常定义为0或1，这里取0
    """
    # 创建和x形状相同的数组，初始值为0
    derivative = np.zeros_like(x)
    # 将x>0的位置的导数设为1
    derivative[x > 0] = 1
    return derivative

# 设置画布大小为(12, 4)
plt.figure(figsize=(12, 4))

# 生成x轴数据（范围-10到10，取1000个点，让曲线更平滑）
x = np.linspace(-10, 10, 1000)

# 绘制第一个子图：ReLU函数（左边）
plt.subplot(1, 2, 1)  # 1行2列，第1个位置
plt.plot(x, relu(x), color='blue', linewidth=2)

# 添加ReLU的关键辅助线
plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)  # y=0水平线
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)  # x=0垂直线
# 标注关键坐标点(0, 0)
plt.scatter(0, 0, color='red', s=30, zorder=5)  # 突出原点
plt.annotate('(0, 0)', xy=(0, 0), xytext=(1, -0.7),
             arrowprops=dict(arrowstyle='->', color='red'))

plt.title('ReLU', fontsize=12)
plt.xlabel('x')
plt.ylabel('relu(x)')
plt.grid(True, alpha=0.3)  # 添加网格，增强可读性
plt.ylim(-1, 10)  # 限定y轴范围，突出ReLU的特性
plt.xlim(-10, 10)

# 绘制第二个子图：ReLU导数（右边）
plt.subplot(1, 2, 2)  # 1行2列，第2个位置
plt.plot(x, relu_derivative(x), color='red', linewidth=2)

# 添加导数的关键辅助线
plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)  # y=0水平线
plt.axhline(y=1, color='gray', linestyle=':', alpha=0.8)  # 导数为1的参考线
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)  # x=0垂直线
# 标注关键特征：x>0时导数为1，x<=0时导数为0
plt.annotate('derivative=1 (x>0)', xy=(5, 1), xytext=(1, 0.8),
             arrowprops=dict(arrowstyle='->', color='blue'))
plt.annotate('derivative=0 (x≤0)', xy=(-5, 0), xytext=(-9, 0.2),
             arrowprops=dict(arrowstyle='->', color='blue'))

plt.title('ReLU Derivative', fontsize=12)
plt.xlabel('x')
plt.ylabel("relu'(x)")
plt.grid(True, alpha=0.3)
plt.ylim(-0.1, 1.1)  # 限定y轴范围，突出导数的二值特性
plt.xlim(-10, 10)

# 调整子图间距，避免标题/标签重叠
plt.tight_layout()

# 显示图像
# plt.show()
plt.savefig('./relu.png', dpi=300)