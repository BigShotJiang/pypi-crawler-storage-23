import numpy as np
import matplotlib.pyplot as plt

# 定义sigmoid函数
def sigmoid(x):
    """sigmoid激活函数：f(x) = 1 / (1 + e^(-x))"""
    return 1 / (1 + np.exp(-x))

# 定义sigmoid函数的导数
def sigmoid_derivative(x):
    """sigmoid导数：f'(x) = f(x) * (1 - f(x))"""
    s = sigmoid(x)
    return s * (1 - s)

# 设置画布大小为(12, 4)
plt.figure(figsize=(12, 4))

# 生成x轴数据（范围-10到10，取1000个点，让曲线更平滑）
x = np.linspace(-10, 10, 1000)

# 绘制第一个子图：sigmoid函数（左边）
plt.subplot(1, 2, 1)  # 1行2列，第1个位置
plt.plot(x, sigmoid(x), color='blue', linewidth=2)

# 添加sigmoid的关键辅助线
plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)  # y=0水平线
plt.axhline(y=1, color='black', linestyle='--', alpha=0.5)  # y=1水平线
plt.axhline(y=0.5, color='gray', linestyle=':', alpha=0.8)  # y=0.5参考线（sigmoid中点）
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)  # x=0垂直线
# 标注关键坐标点(0, 0.5)
plt.scatter(0, 0.5, color='red', s=30, zorder=5)  # 突出中点
plt.annotate('(0, 0.5)', xy=(0, 0.5), xytext=(1.2, 0.6),
             arrowprops=dict(arrowstyle='->', color='red'))

plt.title('Sigmoid', fontsize=12)
plt.xlabel('x')
plt.ylabel('sigmoid(x)')
plt.grid(True, alpha=0.3)  # 添加网格，增强可读性
plt.ylim(-0.1, 1.1)  # 限定y轴范围，突出sigmoid的0-1特性

# 绘制第二个子图：sigmoid导数（右边）
plt.subplot(1, 2, 2)  # 1行2列，第2个位置
plt.plot(x, sigmoid_derivative(x), color='red', linewidth=2)

# 添加导数的关键辅助线
plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)  # y=0水平线
plt.axhline(y=0.25, color='gray', linestyle=':', alpha=0.8)  # 导数峰值线（0.25）
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)  # x=0垂直线
# 标注关键坐标点(0, 0.25)
plt.scatter(0, 0.25, color='blue', s=30, zorder=5)  # 突出峰值点
plt.annotate('(0, 0.25)', xy=(0, 0.25), xytext=(1.2, 0.2),
             arrowprops=dict(arrowstyle='->', color='blue'))

plt.title('Sigmoid Derivative', fontsize=12)
plt.xlabel('x')
plt.ylabel("sigmoid'(x)")
plt.grid(True, alpha=0.3)
plt.ylim(-0.05, 0.3)  # 限定y轴范围，突出导数的峰值特性

# 调整子图间距，避免标题/标签重叠
plt.tight_layout()

# 显示图像
# plt.show()
plt.savefig('./sigmoid.png', dpi=300)