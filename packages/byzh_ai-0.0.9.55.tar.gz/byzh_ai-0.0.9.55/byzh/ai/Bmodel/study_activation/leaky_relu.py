import numpy as np
import matplotlib.pyplot as plt

# -------------------------
# Leaky ReLU
# -------------------------
def leaky_relu(x, alpha=0.1):
    """Leaky ReLU: f(x)=x if x>=0 else alpha*x"""
    return np.where(x >= 0, x, alpha * x)

def leaky_relu_derivative(x, alpha=0.1):
    """Derivative of Leaky ReLU"""
    return np.where(x >= 0, 1.0, alpha)

plt.figure(figsize=(12, 4))

x = np.linspace(-10, 10, 1000)
alpha = 0.1

# (1) function
plt.subplot(1, 2, 1)
plt.plot(x, leaky_relu(x, alpha=alpha), color='blue', linewidth=2)

plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)

plt.scatter(0, 0, color='red', s=30, zorder=5)
plt.annotate('(0, 0)', xy=(0, 0), xytext=(1.2, 1.2),
             arrowprops=dict(arrowstyle='->', color='red'))

plt.title(f'Leaky ReLU (alpha={alpha})', fontsize=12)
plt.xlabel('x')
plt.ylabel('leaky_relu(x)')
plt.grid(True, alpha=0.3)

# (2) derivative
plt.subplot(1, 2, 2)
plt.plot(x, leaky_relu_derivative(x, alpha=alpha), color='red', linewidth=2)

plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)
plt.axhline(y=1, color='gray', linestyle=':', alpha=0.8)
plt.axhline(y=alpha, color='gray', linestyle=':', alpha=0.8)
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)

plt.scatter(0, 1.0, color='blue', s=30, zorder=5)
plt.annotate('(0, 1)', xy=(0, 1.0), xytext=(1.2, 1.05),
             arrowprops=dict(arrowstyle='->', color='blue'))

plt.scatter(0, alpha, color='blue', s=30, zorder=5)
plt.annotate(f'(0, {alpha})', xy=(0, alpha), xytext=(1.2, alpha + 0.05),
             arrowprops=dict(arrowstyle='->', color='blue'))

plt.title('Leaky ReLU Derivative', fontsize=12)
plt.xlabel('x')
plt.ylabel("d/dx leaky_relu(x)")
plt.grid(True, alpha=0.3)
plt.ylim(-0.1, 1.2)

plt.tight_layout()

# plt.show()
plt.savefig('./leaky_relu.png', dpi=300)