import numpy as np
import matplotlib.pyplot as plt

# 定义LeNet中的缩放tanh函数
def lenet_tanh(x):
    """LeNet使用的缩放tanh激活函数：f(x) = 1.7159 * tanh((2/3) * x)
    该函数将标准tanh的输出范围[-1,1]缩放为[-1.7159, 1.7159]"""
    scale_factor = 2/3
    amplitude = 1.7159
    return amplitude * np.tanh(scale_factor * x)

# 定义LeNet tanh函数的导数
def lenet_tanh_derivative(x):
    """LeNet tanh导数：
    f'(x) = 1.7159 * (2/3) * [1 - tanh²((2/3)*x)]
    推导：链式法则 -> 外层导数(1.7159) * 内层导数(tanh'(2x/3)*2/3)"""
    scale_factor = 2/3
    amplitude = 1.7159
    t = np.tanh(scale_factor * x)
    return amplitude * scale_factor * (1 - t**2)

# 设置画布大小为(12, 4)
plt.figure(figsize=(12, 4))

# 生成x轴数据（范围-10到10，取1000个点，让曲线更平滑）
x = np.linspace(-10, 10, 1000)

# 绘制第一个子图：LeNet tanh函数（左边）
plt.subplot(1, 2, 1)  # 1行2列，第1个位置
plt.plot(x, lenet_tanh(x), color='blue', linewidth=2)

# 添加LeNet tanh的关键辅助线
plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)  # y=0水平线
plt.axhline(y=1.7159, color='black', linestyle='--', alpha=0.5)   # 上边界线
plt.axhline(y=-1.7159, color='black', linestyle='--', alpha=0.5)  # 下边界线
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)        # x=0垂直线
# 标注关键坐标点(0, 0)
plt.scatter(0, 0, color='red', s=30, zorder=5)  # 突出原点
plt.annotate('(0, 0)', xy=(0, 0), xytext=(1, 0.8),
             arrowprops=dict(arrowstyle='->', color='red'))

plt.title('LeNet Scaled Tanh', fontsize=12)
plt.xlabel('x')
plt.ylabel('1.7159 * tanh(2x/3)')
plt.grid(True, alpha=0.3)  # 添加网格，增强可读性
plt.ylim(-1.8, 1.8)        # 限定y轴范围，突出[-1.7159, 1.7159]特性

# 绘制第二个子图：LeNet tanh导数（右边）
plt.subplot(1, 2, 2)  # 1行2列，第2个位置
plt.plot(x, lenet_tanh_derivative(x), color='red', linewidth=2)

# 计算导数峰值（x=0时）：1.7159 * (2/3) = 1.143933...
deriv_peak = 1.7159 * (2/3)
# 添加导数的关键辅助线
plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)        # y=0水平线
plt.axhline(y=deriv_peak, color='gray', linestyle=':', alpha=0.8) # 导数峰值线
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)        # x=0垂直线
# 标注关键坐标点(0, 导数峰值)
plt.scatter(0, deriv_peak, color='blue', s=30, zorder=5)  # 突出峰值点
plt.annotate(f'(0, {deriv_peak:.4f})', xy=(0, deriv_peak), xytext=(1, 0.9),
             arrowprops=dict(arrowstyle='->', color='blue'))

plt.title('LeNet Scaled Tanh Derivative', fontsize=12)
plt.xlabel('x')
plt.ylabel("d/dx [1.7159 * tanh(2x/3)]")
plt.grid(True, alpha=0.3)
plt.ylim(-0.1, 1.2)  # 限定y轴范围，突出导数的峰值特性

# 调整子图间距，避免标题/标签重叠
plt.tight_layout()

# 显示图像
# plt.show()
plt.savefig('./tanh_lenet5.png', dpi=300)