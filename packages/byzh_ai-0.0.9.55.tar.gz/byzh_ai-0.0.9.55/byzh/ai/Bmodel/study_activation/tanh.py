import numpy as np
import matplotlib.pyplot as plt

# 定义tanh函数
def tanh(x):
    """tanh激活函数：f(x) = (e^x - e^(-x)) / (e^x + e^(-x))
    等价于 np.tanh(x)，这里手动实现便于理解原理"""
    return (np.exp(x) - np.exp(-x)) / (np.exp(x) + np.exp(-x))

# 定义tanh函数的导数
def tanh_derivative(x):
    """tanh导数：f'(x) = 1 - [f(x)]²"""
    t = tanh(x)
    return 1 - t**2

# 设置画布大小为(12, 4)
plt.figure(figsize=(12, 4))

# 生成x轴数据（范围-10到10，取1000个点，让曲线更平滑）
x = np.linspace(-10, 10, 1000)

# 绘制第一个子图：tanh函数（左边）
plt.subplot(1, 2, 1)  # 1行2列，第1个位置
plt.plot(x, tanh(x), color='blue', linewidth=2)

# 添加tanh的关键辅助线
plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)  # y=0水平线
plt.axhline(y=1, color='black', linestyle='--', alpha=0.5)   # y=1上边界线
plt.axhline(y=-1, color='black', linestyle='--', alpha=0.5)  # y=-1下边界线
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)   # x=0垂直线
# 标注关键坐标点(0, 0)
plt.scatter(0, 0, color='red', s=30, zorder=5)  # 突出原点
plt.annotate('(0, 0)', xy=(0, 0), xytext=(1, 0.5),
             arrowprops=dict(arrowstyle='->', color='red'))

plt.title('Tanh', fontsize=12)
plt.xlabel('x')
plt.ylabel('tanh(x)')
plt.grid(True, alpha=0.3)  # 添加网格，增强可读性
plt.ylim(-1.1, 1.1)        # 限定y轴范围，突出tanh的[-1,1]特性

# 绘制第二个子图：tanh导数（右边）
plt.subplot(1, 2, 2)  # 1行2列，第2个位置
plt.plot(x, tanh_derivative(x), color='red', linewidth=2)

# 添加导数的关键辅助线
plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)   # y=0水平线
plt.axhline(y=1, color='gray', linestyle=':', alpha=0.8)     # 导数峰值线（1）
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)   # x=0垂直线
# 标注关键坐标点(0, 1)
plt.scatter(0, 1, color='blue', s=30, zorder=5)  # 突出峰值点
plt.annotate('(0, 1)', xy=(0, 1), xytext=(1, 0.8),
             arrowprops=dict(arrowstyle='->', color='blue'))

plt.title('Tanh Derivative', fontsize=12)
plt.xlabel('x')
plt.ylabel("tanh'(x)")
plt.grid(True, alpha=0.3)
plt.ylim(-0.1, 1.1)  # 限定y轴范围，突出导数的峰值特性

# 调整子图间距，避免标题/标签重叠
plt.tight_layout()

# 显示图像
# plt.show()
plt.savefig('./tanh.png', dpi=300)