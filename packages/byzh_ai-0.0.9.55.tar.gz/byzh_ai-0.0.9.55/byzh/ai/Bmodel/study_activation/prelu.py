import numpy as np
import matplotlib.pyplot as plt

# -------------------------
# PReLU (Parametric ReLU)
# -------------------------
def prelu(x, a=0.25):
    """PReLU: f(x)=x if x>=0 else a*x (a is learnable in practice)"""
    return np.where(x >= 0, x, a * x)

def prelu_derivative(x, a=0.25):
    """Derivative of PReLU"""
    return np.where(x >= 0, 1.0, a)

plt.figure(figsize=(12, 4))

x = np.linspace(-10, 10, 1000)
a = 0.25  # 这里固定一个值，用于画图展示（训练时通常是可学习参数）

# (1) function
plt.subplot(1, 2, 1)
plt.plot(x, prelu(x, a=a), color='blue', linewidth=2)

plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)

plt.scatter(0, 0, color='red', s=30, zorder=5)
plt.annotate('(0, 0)', xy=(0, 0), xytext=(1.2, 1.2),
             arrowprops=dict(arrowstyle='->', color='red'))

plt.title(f'PReLU (a={a})', fontsize=12)
plt.xlabel('x')
plt.ylabel('prelu(x)')
plt.grid(True, alpha=0.3)

# (2) derivative
plt.subplot(1, 2, 2)
plt.plot(x, prelu_derivative(x, a=a), color='red', linewidth=2)

plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)
plt.axhline(y=1, color='gray', linestyle=':', alpha=0.8)
plt.axhline(y=a, color='gray', linestyle=':', alpha=0.8)
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)

plt.scatter(0, 1.0, color='blue', s=30, zorder=5)
plt.annotate('(0, 1)', xy=(0, 1.0), xytext=(1.2, 1.05),
             arrowprops=dict(arrowstyle='->', color='blue'))

plt.scatter(0, a, color='blue', s=30, zorder=5)
plt.annotate(f'(0, {a})', xy=(0, a), xytext=(1.2, a + 0.05),
             arrowprops=dict(arrowstyle='->', color='blue'))

plt.title('PReLU Derivative', fontsize=12)
plt.xlabel('x')
plt.ylabel("d/dx prelu(x)")
plt.grid(True, alpha=0.3)
plt.ylim(-0.1, 1.2)

plt.tight_layout()

# plt.show()
plt.savefig('./prelu.png', dpi=300)