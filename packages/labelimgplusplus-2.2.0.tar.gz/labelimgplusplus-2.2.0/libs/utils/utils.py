from math import sqrt
from libs.utils.ustr import ustr
import hashlib
import re
import sys

try:
    from PyQt5.QtGui import QIcon, QColor, QPainter, QPixmap
    from PyQt5.QtCore import QRegExp, QSize
    from PyQt5.QtWidgets import QPushButton, QAction, QMenu, QWidget
    QT5 = True
except ImportError:
    from PyQt4.QtGui import QIcon, QColor, QPushButton, QAction, QMenu, QWidget, QRegExpValidator
    from PyQt4.QtCore import QRegExp
    QT5 = False

# QRegExpValidator location differs between Qt versions
if QT5:
    from PyQt5.QtGui import QRegExpValidator
else:
    pass  # Already imported above for PyQt4


def new_icon(icon):
    return QIcon(':/' + icon)


def themed_icon(icon_name, theme):
    """Create a theme-aware icon, recoloring dark pixels for dark mode.

    Uses QPainter CompositionMode_SourceIn to replace all opaque pixels
    with the theme's text color while preserving alpha transparency.

    Args:
        icon_name: Icon resource name (e.g., 'format_yolo').
        theme: Theme enum value from libs.utils.styles.

    Returns:
        QIcon recolored for the given theme.
    """
    from libs.utils.styles import Theme, get_theme_colors, hex_to_qcolor

    base_icon = QIcon(':/' + icon_name)
    if theme == Theme.LIGHT:
        return base_icon

    text_color = hex_to_qcolor(get_theme_colors(theme)['text'])

    # Resource-loaded icons often report empty availableSizes(),
    # so request a reasonable default size to get the actual pixmap.
    pixmap = base_icon.pixmap(QSize(128, 128))
    if pixmap.isNull():
        return base_icon

    painter = QPainter(pixmap)
    painter.setCompositionMode(QPainter.CompositionMode_SourceIn)
    painter.fillRect(pixmap.rect(), text_color)
    painter.end()

    recolored = QIcon()
    recolored.addPixmap(pixmap)
    return recolored


def new_button(text, icon=None, slot=None):
    b = QPushButton(text)
    if icon is not None:
        b.setIcon(new_icon(icon))
    if slot is not None:
        b.clicked.connect(slot)
    return b


def new_action(parent, text, slot=None, shortcut=None, icon=None,
               tip=None, checkable=False, enabled=True):
    """Create a new action and assign callbacks, shortcuts, etc."""
    a = QAction(text, parent)
    if icon is not None:
        a.setIcon(new_icon(icon))
    if shortcut is not None:
        if isinstance(shortcut, (list, tuple)):
            a.setShortcuts(shortcut)
        else:
            a.setShortcut(shortcut)
    if tip is not None:
        a.setToolTip(tip)
        a.setStatusTip(tip)
    if slot is not None:
        a.triggered.connect(slot)
    if checkable:
        a.setCheckable(True)
    a.setEnabled(enabled)
    return a


def add_actions(widget, actions):
    for action in actions:
        if action is None:
            widget.addSeparator()
        elif isinstance(action, QMenu):
            widget.addMenu(action)
        elif isinstance(action, QWidget):
            widget.addWidget(action)
        else:
            widget.addAction(action)


def label_validator():
    return QRegExpValidator(QRegExp(r'^[^ \t].+'), None)


class Struct(object):

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


def distance(p):
    return sqrt(p.x() * p.x() + p.y() * p.y())


def format_shortcut(text):
    mod, key = text.split('+', 1)
    return '<b>%s</b>+<b>%s</b>' % (mod, key)


def generate_color_by_text(text):
    s = ustr(text)
    hash_code = int(hashlib.sha256(s.encode('utf-8')).hexdigest(), 16)
    r = int((hash_code / 255) % 255)
    g = int((hash_code / 65025) % 255)
    b = int((hash_code / 16581375) % 255)
    return QColor(r, g, b, 100)


def have_qstring():
    """p3/qt5 get rid of QString wrapper as py3 has native unicode str type"""
    return not (sys.version_info.major >= 3 or QT_VERSION_STR.startswith('5.'))


def util_qt_strlistclass():
    return QStringList if have_qstring() else list


def natural_sort(list, key=lambda s:s):
    """
    Sort the list into natural alphanumeric order.
    """
    def get_alphanum_key_func(key):
        convert = lambda text: int(text) if text.isdigit() else text
        return lambda s: [convert(c) for c in re.split('([0-9]+)', key(s))]
    sort_key = get_alphanum_key_func(key)
    list.sort(key=sort_key)


# QT4 has a trimmed method, in QT5 this is called strip
if QT5:
    def trimmed(text):
        return text.strip()
else:
    def trimmed(text):
        return text.trimmed()
