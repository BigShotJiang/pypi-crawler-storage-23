import random

POP_SIZE = 6
CHROM_LEN = 5
GENERATIONS = 10
MUT_RATE = 0.1

population = [[random.randint(0, 1) for _ in range(CHROM_LEN)]
              for _ in range(POP_SIZE)]

def binary_to_decimal(chrom):
    return int("".join(map(str, chrom)), 2)

for gen in range(GENERATIONS):

    values = [binary_to_decimal(c) for c in population]
    fitness = [x * x for x in values]

    best = max(fitness)
    idx = fitness.index(best)

    print(f"Generation {gen+1}: Best x = {values[idx]}, Fitness = {best}")

    total_fit = sum(fitness)
    probs = [f / total_fit for f in fitness]

    new_population = []

    while len(new_population) < POP_SIZE:
        p1 = population[random.choices(range(POP_SIZE), probs)[0]]
        p2 = population[random.choices(range(POP_SIZE), probs)[0]]

        cp = random.randint(1, CHROM_LEN - 1)

        child1 = p1[:cp] + p2[cp:]
        child2 = p2[:cp] + p1[cp:]

        new_population.extend([child1, child2])

    for i in range(POP_SIZE):
        for j in range(CHROM_LEN):
            if random.random() < MUT_RATE:
                new_population[i][j] ^= 1

    population = new_population[:POP_SIZE]