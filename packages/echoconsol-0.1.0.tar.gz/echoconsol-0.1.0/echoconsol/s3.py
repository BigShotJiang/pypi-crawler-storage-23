clc;
clear;
close all;

figure;

% Triangular Membership Function
x1 = 0:1:10;
y1 = trimf(x1, [1 3 5]);
subplot(3,1,1);
plot(x1, y1, 'LineWidth', 2);
title('Triangular Membership Function');
grid on;

% Trapezoidal Membership Function
x2 = 0:1:10;
y2 = trapmf(x2, [1 3 5 7]);
subplot(3,1,2);
plot(x2, y2, 'LineWidth', 2);
title('Trapezoidal Membership Function');
grid on;

% Bell-Shaped Membership Function
x3 = 0:0.2:10;
y3 = gbellmf(x3, [3 5 7]);
subplot(3,1,3);
plot(x3, y3, 'LineWidth', 2);
title('Bell-Shaped Membership Function');
grid on;