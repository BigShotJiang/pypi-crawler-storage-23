Quality: {not good, satisfying, delightful}
Service: {poor, average, good}
