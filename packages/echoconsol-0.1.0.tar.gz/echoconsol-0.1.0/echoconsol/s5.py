# INPUTS 

Temperature: {Freeze, Cool, Warm and Hot}
Cloud Cover: {Sunny, Partly Cloudy and Overcast}

#rules

Sunny (Cover) and Warm (Temp) -> Fast (Speed) 
Cloudy (Cover) and Cool (Temp) -> Slow (Speed)