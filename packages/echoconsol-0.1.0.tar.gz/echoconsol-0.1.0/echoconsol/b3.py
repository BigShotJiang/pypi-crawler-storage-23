echo "hello hadoop hello mapreduce" > wc_input.txt
hdfs dfs -mkdir -p /wordcount_input
hdfs dfs -put -f wc_input.txt /wordcount_input/
hdfs dfs -ls /

hadoop jar $HADOOP_HOME/share/hadoop/mapreduce/hadoop-mapreduce-examples-*.jar wordcount -D mapreduce.job.reduces=2 /wordcount_input /wordcount/output_2reducer

hdfs dfs -ls /wordcount/output_2reducer
hdfs dfs -cat /wordcount/output_2reducer/part-r-*