hdfs --daemon start namenode
hdfs --daemon start datanode
yarn --daemon start resourcemanager
yarn --daemon start nodemanager

jps

hadoop version

hdfs dfs -ls /

hdfs dfs -mkdir /data

echo "Hello Hadoop" > local.txt

hdfs dfs -put local.txt /data/

hdfs dfs -ls /data

hdfs dfs -get /data/local.txt

ls

hdfs dfs -cat /data/local.txt

hdfs dfs -tail /data/local.txt

hdfs dfs -cp /data/local.txt /data/local_copy.txt

hdfs dfs -ls /data

hdfs dfs -mv /data/local_copy.txt /data/local_renamed.txt

hdfs dfs -ls /data

hdfs dfs -rm /data/local_renamed.txt

hdfs dfs -ls /data

hdfs dfs -rm -r /data

hdfs dfs -ls /