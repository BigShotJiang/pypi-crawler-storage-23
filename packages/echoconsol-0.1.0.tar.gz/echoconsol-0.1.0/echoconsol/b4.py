# Run this
nano run_maponly.sh


#then
echo "hello hadoop hello mapreduce" > wc_input.txt
echo "mapper only job example in hadoop" >> wc_input.txt

hdfs dfs -mkdir -p /wordcount1/input
hdfs dfs -put -f wc_input.txt /wordcount1/input/

hdfs dfs -rm -r -f /wordcount1/output_maponly

hadoop jar $HADOOP_HOME/share/hadoop/mapreduce/hadoop-mapreduce-examples-*.jar wordcount -D mapreduce.job.reduces=0 /wordcount1/input /wordcount1/output_maponly

hdfs dfs -ls /wordcount1/output_maponly
hdfs dfs -cat /wordcount1/output_maponly/part-m-*