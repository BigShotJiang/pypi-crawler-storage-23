clc;
clear;

u = input('Enter the membership values of first fuzzy set: ');
v = input('Enter the membership values of second fuzzy set: ');

if length(u) ~= length(v)
    error('Both fuzzy sets must have the same number of elements');
end

w = max(u, v);
p = min(u, v);
q1 = 1 - u;
q2 = 1 - v;

x1 = 1 - w;
x2 = min(q1, q2);

y1 = 1 - p;
y2 = max(q1, q2);

disp('Union of two fuzzy sets');
disp(w);

disp('Intersection of two fuzzy sets');
disp(p);

disp('Complement of first fuzzy set');
disp(q1);

disp('Complement of second fuzzy set');
disp(q2);

disp('De-Morgan''s Law Verification');

disp('1) (A U B)'' = A'' ∩ B''');
disp('LHS:');
disp(x1);
disp('RHS:');
disp(x2);

disp('2) (A ∩ B)'' = A'' U B''');
disp('LHS:');
disp(y1);
disp('RHS:');
disp(y2);