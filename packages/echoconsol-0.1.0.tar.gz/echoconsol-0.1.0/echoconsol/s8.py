sclc;
clear;

x = [ 1 1 -1 -1;
      1 -1 1 -1 ];

t = [1 -1 -1 -1];

w = [0 0];
b = 0;

alpha = input('Enter Learning rate = ');

con = 1;
epoch = 0;

while con
    con = 0;
    for i = 1:4
        
        yin = b + x(1,i)*w(1) + x(2,i)*w(2);
        
        if yin >= 0
            y = 1;
        else
            y = -1;
        end
        
        if y ~= t(i)
            con = 1;
            for j = 1:2
                w(j) = w(j) + alpha * t(i) * x(j,i);
            end
            b = b + alpha * t(i);
        end
        
    end
    epoch = epoch + 1;
end

disp('Perceptron for AND Function');
disp('Final Weight Matrix');
disp(w);
disp('Final Bias');
disp(b);
disp('Total Epochs');
disp(epoch);