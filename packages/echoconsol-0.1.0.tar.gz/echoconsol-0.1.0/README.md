# echoconsol

A lightweight personal Python utility package designed to organize modular components for experimentation and structured development.

## Installation

```bash
pip install echoconsol
```

## Features

- Clean modular architecture
- Organized file structure
- Lightweight and dependency-free
- Compatible with Python 3.8+

## Publish to PyPI

1. Build artifacts:

```bash
python -m build
```

2. Create `%USERPROFILE%\\.pypirc` (not inside this repo):

```ini
[distutils]
index-servers =
	pypi

[pypi]
repository = https://upload.pypi.org/legacy/
username = __token__
password = ${PYPI_TOKEN}
```

3. Set token in your shell and upload:

```powershell
$env:PYPI_TOKEN = "pypi-<YOUR_NEW_TOKEN>"
python -m twine upload -r pypi dist/*
```

4. Clear the token from the session after upload:

```powershell
Remove-Item Env:PYPI_TOKEN
```

## License

MIT

