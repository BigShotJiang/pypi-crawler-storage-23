from abc import ABC,abstractmethod
from typing import List, Dict
import torch
import torch.nn as nn

class Encoder(ABC,nn.Module):
    def __init__(self):
        super().__init__()

    @abstractmethod
    def forward(self,x:torch.Tensor) -> Dict[str, torch.Tensor]:
        """Return dict of feature maps
        {
            "stage1": torch.Tensor,
            "stage2": torch.Tensor,
            "stage3": torch.Tensor,
            "stage4": torch.Tensor,
            "bottleneck": torch.Tensor
        }
        """
        pass

    @property
    @abstractmethod
    def out_channels(self) -> List[int]:
        """List of channel dimensions for [stage1, stage2, stage3, stage4, bottleneck]."""
        pass