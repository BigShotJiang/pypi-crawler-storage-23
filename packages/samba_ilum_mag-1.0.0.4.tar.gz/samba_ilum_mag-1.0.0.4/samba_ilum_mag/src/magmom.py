# SAMBA_ilum Copyright (C) 2025-2026
# GNU GPL-3.0 license


import os


# -----------------------------------------------------
# Checking the presence ofnOUTCAR file: ---------------
# -----------------------------------------------------

try:
    f = open('OUTCAR')
    f.close()
    n_outcar = 1
except:
    print('')
    print('... Missing OUTCAR file ...') 

#---------------------------
outcar = open('OUTCAR', "r")
#---------------------------

#----------------------------------------------------------------------
# Obtaining the number of k-points (nk), bands (nb) and ions (ni): ----
#----------------------------------------------------------------------

palavra = 'Dimension'

for line in outcar:   
    if palavra in line: 
       break

VTemp = outcar.readline().split()
# nk = int(VTemp[3])
# nb = int(VTemp[14])

VTemp = outcar.readline().split()
ni = int(VTemp[11])


#-----------------------------------------------------------------------
# Check if the calculation was performed with or without SO coupling: --
#-----------------------------------------------------------------------

palavra = 'ICHARG'

for line in outcar:   
    if palavra in line: 
       break

VTemp = outcar.readline().split()
ispin = int(VTemp[2])

VTemp = outcar.readline().split()
lnoncollinear = VTemp[2]

VTemp = outcar.readline().split()
lsorbit = VTemp[2]

if (lnoncollinear == "F"): LNC = 1
if (lnoncollinear == "T"): LNC = 2
if (lsorbit == "F"): SO = 1
if (lsorbit == "T"): SO = 2

#-------------
outcar.close()
#-------------

#-----------------------------------------------------------------------
# searching for the Magnetic Moment values in the OUTCAR file: ---------
#-----------------------------------------------------------------------

stage = 0
targets = ["(x)", "(y)", "(z)"]
line_x = line_y = line_z = 0

with open('OUTCAR', 'r') as f:
    for i, line in enumerate(f, 1):
        if stage == 0 and "reached" in line: stage = 1
        elif stage == 1 and all(w in line for w in ["free", "energy", "TOTEN"]): stage = 2
        elif stage == 2 and "magnetization" in line:
            #---------------------------- 
            if "(x)" in line: line_x = i
            if "(y)" in line: line_y = i
            if "(z)" in line: line_z = i
            #---------------------------- 
            for axis in targets[:]:
                if axis in line: targets.remove(axis)
            if not targets: break

if (ispin == 2 and LNC == 1):

   #========================= Magnetic Moment (X) ========================= 
   outcar = open('OUTCAR', "r");  mmoments = []
   #---------------------------------------------------
   for i in range(line_x +3): VTemp = outcar.readline()
   for i in range(ni):
       VTemp = outcar.readline().split()
       mmoments.append(float(VTemp[-1]))
   #------------------------------------
   sum_mmoments_x = sum(mmoments)
   for i in range(2): VTemp = outcar.readline().split()
   mmoment_tot_x = float(VTemp[-1])
   #-------------
   outcar.close()
   #-----------------
   mmoments_check = 1
   if not mmoments: mmoments_check = 0
   if (mmoments_check == 1):
      #----------------------------------
      magmom = open('magmom.txt', "w")
      #============
      magmom.write(f'MAGMOM = ')
      for i in range (ni): magmom.write(f'{mmoments[i]} ')
      magmom.write(f'\n')
      #============
      magmom.write(f'------------------------ \n')
      #============
      for i in range (ni):
          if ((i+1) < 10):                    magmom.write(f'{i+1}   {mmoments[i]:8.4f} \n')
          if ((i+1) >= 10 and (i+1) < 100):   magmom.write(f'{i+1}  {mmoments[i]:8.4f} \n')
          if ((i+1) >= 100 and (i+1) < 1000): magmom.write(f'{i+1} {mmoments[i]:8.4f} \n')
      #-----------------------------------------------------------------------------------
      magmom.close()
      #-------------

if (LNC == 2):

   #========================= Magnetic Moment (X) ========================= 
   outcar = open('OUTCAR', "r");  mmoments_x = []
   #---------------------------------------------------
   for i in range(line_x +3): VTemp = outcar.readline()
   for i in range(ni):
       VTemp = outcar.readline().split()
       mmoments_x.append(float(VTemp[-1]))
   #------------------------------------
   sum_mmoments_x = sum(mmoments_x)
   for i in range(2): VTemp = outcar.readline().split()
   mmoment_tot_x = float(VTemp[-1])

   #========================= Magnetic Moment (Y) ========================= 
   palavra = 'magnetization';  mmoments_y = [] 
   #------------------------------------------
   for line in outcar:  
       if palavra in line: 
          break
   #-------------------------------------------
   for i in range(3): VTemp = outcar.readline()
   for i in range(ni):
       VTemp = outcar.readline().split()
       mmoments_y.append(float(VTemp[-1]))
   #------------------------------------
   sum_mmoments_y = sum(mmoments_y)
   for i in range(2): VTemp = outcar.readline().split()
   mmoment_tot_y = float(VTemp[-1])

   #========================= Magnetic Moment (Z) ========================= 
   palavra = 'magnetization';  mmoments_z = [] 
   #------------------------------------------
   for line in outcar:  
       if palavra in line: 
          break
   #-------------------------------------------
   for i in range(3): VTemp = outcar.readline()
   for i in range(ni):
       VTemp = outcar.readline().split()
       mmoments_z.append(float(VTemp[-1]))
   #------------------------------------
   sum_mmoments_z = sum(mmoments_z)
   for i in range(2): VTemp = outcar.readline().split()
   mmoment_tot_z = float(VTemp[-1])
   #-------------
   outcar.close()
   #-------------
   mmoments = []    
   for i in range(ni): mmoments.append([float(mmoments_x[i]), float(mmoments_y[i]), float(mmoments_z[i])])
   #---------------------
   mmoments_xyz_check = 1
   if not mmoments: mmoments_xyz_check = 0
   #--------------------------------------
   if (mmoments_xyz_check == 1):
      #-------------------------------
      magmom = open('magmom.txt', "w")
      #============
      magmom.write(f'MAGMOM = ')
      for i in range (ni): magmom.write(f'{mmoments_x[i]} {mmoments_y[i]} {mmoments_z[i]} ')
      magmom.write(f'\n')
      #============
      magmom.write(f'------------------------ \n')
      #============
      for i in range (ni):
          if ((i+1) < 10):                    magmom.write(f'{i+1}   {mmoments_x[i]:8.4f} {mmoments_y[i]:8.4f} {mmoments_z[i]:8.4f} \n')
          if ((i+1) >= 10 and (i+1) < 100):   magmom.write(f'{i+1}  {mmoments_x[i]:8.4f} {mmoments_y[i]:8.4f} {mmoments_z[i]:8.4f} \n')
          if ((i+1) >= 100 and (i+1) < 1000): magmom.write(f'{i+1} {mmoments_x[i]:8.4f} {mmoments_y[i]:8.4f} {mmoments_z[i]:8.4f} \n')
      #-------------------------------------------------------------------------------------------------------------------------------
      magmom.close()
      #-------------
