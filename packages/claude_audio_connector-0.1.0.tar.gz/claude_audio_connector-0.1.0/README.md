# Claude Audio

Talk to Claude Code with your voice.

## Install

```bash
uv pip install claude-audio-connector
```

## Setup

**1. Get API keys:**

- [Sarvam](https://sarvam.ai) (speech-to-text)
- [Cartesia](https://cartesia.ai) (text-to-speech)

**2. Set environment variables** (add to your shell profile or project `.env`):

```bash
export SARVAM_API_KEY=your_sarvam_key
export CARTESIA_API_KEY=your_cartesia_key
```

**3. Grant microphone permission** to your terminal app in System Settings > Privacy & Security > Microphone.

**4. Scaffold the slash command** in any project you want voice in:

```bash
cd your-project
claude-audio-init
```

This creates `.claude/commands/audio.md`.

## Usage

Open Claude Code and type:

```
/audio
```

Speak your request. Claude completes the task, speaks a summary back, then listens for your next command. The loop continues until you press Escape.

Say **"Hey Claude"** while Claude is working to interrupt and redirect.

## API Keys

| Service | Purpose | Sign up |
|---------|---------|---------|
| Sarvam  | STT     | [sarvam.ai](https://sarvam.ai) |
| Cartesia | TTS    | [cartesia.ai](https://cartesia.ai) |

## License

MIT
