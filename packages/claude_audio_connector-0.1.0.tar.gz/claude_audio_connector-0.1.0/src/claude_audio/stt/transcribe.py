from __future__ import annotations

import asyncio
import io
import tempfile
import wave

_client = None


def _get_client(api_key: str):
    global _client
    if _client is None:
        from sarvamai import SarvamAI
        _client = SarvamAI(api_subscription_key=api_key)
    return _client


async def transcribe_pcm(pcm: bytes, cfg, max_wait: float) -> str:
    if not pcm:
        return ""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _transcribe_sync, pcm, cfg)


async def transcribe_chunks(chunks: list[bytes], cfg) -> str:
    if not chunks:
        return ""
    return await transcribe_pcm(b"".join(chunks), cfg, cfg.stt.streaming_max_wait_ms / 1000)


def _transcribe_sync(pcm: bytes, cfg) -> str:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(cfg.stt.sample_rate)
        wf.writeframes(pcm)

    with tempfile.NamedTemporaryFile(suffix=".wav") as tmp:
        tmp.write(buf.getvalue())
        tmp.flush()
        with open(tmp.name, "rb") as f:
            client = _get_client(cfg.stt.api_key)
            result = client.speech_to_text.transcribe(
                file=f,
                model=cfg.stt.model,
                language_code=cfg.stt.language,
            )

    transcript = getattr(result, "transcript", "") or ""
    return transcript.strip()
