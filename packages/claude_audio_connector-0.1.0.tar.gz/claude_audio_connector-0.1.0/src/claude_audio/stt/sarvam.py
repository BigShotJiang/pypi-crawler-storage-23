from __future__ import annotations

import asyncio
import base64
import io
import threading
import wave
from sarvamai import AsyncSarvamAI


def pcm_to_wav_b64(pcm: bytes, sample_rate: int) -> str:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm)
    return base64.b64encode(buf.getvalue()).decode()


async def send_audio_loop(ws, buf: list[bytes], buf_lock: threading.Lock, sr: int, stop_event: asyncio.Event, interval: float) -> None:
    while not stop_event.is_set():
        await asyncio.sleep(interval)
        with buf_lock:
            if not buf:
                continue
            frames = buf[:]
            buf.clear()
        try:
            await ws.transcribe(
                audio=pcm_to_wav_b64(b"".join(frames), sr),
                encoding="audio/wav",
                sample_rate=sr,
            )
        except Exception:
            return


async def open_stream(cfg) -> AsyncSarvamAI:
    return AsyncSarvamAI(api_subscription_key=cfg.api_key)
