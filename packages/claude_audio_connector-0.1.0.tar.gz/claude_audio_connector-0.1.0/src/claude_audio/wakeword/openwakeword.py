from __future__ import annotations

import queue
import threading
import time
from dataclasses import dataclass
from typing import Callable

try:
    from openwakeword.model import Model
except Exception:
    Model = None


@dataclass(frozen=True)
class WakewordConfig:
    enabled: bool
    engine: str
    phrases: list[str]
    threshold: float
    model_paths: list[str]
    frame_ms: int
    cooldown_ms: int
    sample_rate: int


class WakewordListener:
    def __init__(self, cfg: WakewordConfig, on_detect: Callable[[], None]) -> None:
        self._cfg = cfg
        self._on_detect = on_detect
        self._queue: queue.Queue[bytes] = queue.Queue(maxsize=4)
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._last_trigger = 0.0
        self._model = None

        if not cfg.enabled:
            return
        if cfg.engine.lower() != "openwakeword":
            return
        if Model is None:
            return
        if cfg.sample_rate != 16000:
            return
        try:
            kwargs = {}
            if cfg.model_paths:
                kwargs["wakeword_models"] = cfg.model_paths
            self._model = Model(**kwargs)
        except Exception:
            self._model = None

    @property
    def enabled(self) -> bool:
        return self._model is not None

    def start(self) -> None:
        if not self.enabled:
            return
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def close(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=0.5)

    def submit(self, frame: bytes) -> None:
        if not self.enabled:
            return
        try:
            self._queue.put_nowait(frame)
        except queue.Full:
            try:
                _ = self._queue.get_nowait()
            except queue.Empty:
                pass
            try:
                self._queue.put_nowait(frame)
            except queue.Full:
                pass

    def _run(self) -> None:
        if not self._model:
            return
        frame_bytes = int(self._cfg.sample_rate * (self._cfg.frame_ms / 1000.0) * 2)
        buf = bytearray()
        while not self._stop.is_set():
            try:
                chunk = self._queue.get(timeout=0.1)
            except queue.Empty:
                continue
            buf.extend(chunk)
            while len(buf) >= frame_bytes:
                frame = bytes(buf[:frame_bytes])
                del buf[:frame_bytes]
                if self._detect(frame):
                    self._on_detect()

    def _detect(self, frame: bytes) -> bool:
        if not self._model:
            return False
        now = time.monotonic()
        if (now - self._last_trigger) * 1000 < self._cfg.cooldown_ms:
            return False
        scores = self._model.predict(frame)
        for score in scores.values():
            if score >= self._cfg.threshold:
                self._last_trigger = now
                return True
        return False
