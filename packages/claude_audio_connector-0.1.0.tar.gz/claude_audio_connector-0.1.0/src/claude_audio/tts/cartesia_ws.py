from __future__ import annotations

import asyncio
import base64
import json
import threading
import uuid
from typing import Optional

import sounddevice as sd


class CartesiaWsClient:
    def __init__(self, cfg) -> None:
        self._cfg = cfg
        self._ws = None
        self._lock = asyncio.Lock()
        self._keepalive: asyncio.Task | None = None

    async def speak(self, text: str, stop_event: threading.Event) -> bool:
        if not self._cfg.api_key or not text:
            return False
        async with self._lock:
            await self._connect()
            if not self._ws:
                return False

            context_id = uuid.uuid4().hex
            await self._ws.send(json.dumps(self._request_payload(text, context_id)))

            cancelled = False
            drop_audio = False

            with sd.RawOutputStream(
                samplerate=self._cfg.sample_rate,
                channels=1,
                dtype="int16",
            ) as stream:
                while True:
                    try:
                        raw = await self._ws.recv()
                    except Exception:
                        return True

                    if stop_event.is_set() and not cancelled:
                        await self._send_cancel(context_id)
                        cancelled = True
                        drop_audio = True

                    msg = _safe_json(raw)
                    if not msg:
                        continue

                    if msg.get("context_id") != context_id:
                        continue

                    if msg.get("type") == "chunk":
                        if not drop_audio and msg.get("data"):
                            stream.write(base64.b64decode(msg["data"]))
                        continue

                    if msg.get("type") == "done" or msg.get("done") is True:
                        break

                    if msg.get("type") == "error":
                        return True

            return True

    async def close(self) -> None:
        if self._keepalive:
            self._keepalive.cancel()
            self._keepalive = None
        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass
            self._ws = None

    async def _connect(self) -> None:
        if self._ws and not self._ws.closed:
            return
        try:
            import websockets
        except Exception:
            return
        params = {
            "api_key": self._cfg.api_key,
            "cartesia_version": self._cfg.ws_version,
        }
        url = "wss://api.cartesia.ai/tts/websocket?" + _encode_params(params)
        try:
            self._ws = await websockets.connect(url, ping_interval=None, max_size=None)
        except Exception:
            self._ws = None
            return

        if self._keepalive is None or self._keepalive.done():
            self._keepalive = asyncio.create_task(self._keepalive_loop())

    async def _keepalive_loop(self) -> None:
        if not self._ws:
            return
        while self._ws and not self._ws.closed:
            await asyncio.sleep(max(5, int(self._cfg.ws_keepalive_sec)))
            try:
                pong = await self._ws.ping()
                await asyncio.wait_for(pong, timeout=5)
            except Exception:
                try:
                    await self._ws.close()
                except Exception:
                    pass
                self._ws = None
                return

    async def _send_cancel(self, context_id: str) -> None:
        if not self._ws:
            return
        payload = {"context_id": context_id, "cancel": True}
        try:
            await self._ws.send(json.dumps(payload))
        except Exception:
            pass

    def _request_payload(self, text: str, context_id: str) -> dict:
        return {
            "model_id": self._cfg.model_id,
            "transcript": text,
            "continue": False,
            "voice": {"mode": "id", "id": self._cfg.voice_id},
            "output_format": {
                "container": "raw",
                "encoding": "pcm_s16le",
                "sample_rate": self._cfg.sample_rate,
            },
            "speed": _speed_value(self._cfg.speed),
            "language": "en",
            "context_id": context_id,
        }


def _speed_value(name: str) -> float:
    speed_map = {"slowest": -1.0, "slow": -0.5, "normal": 0.0, "fast": 0.25, "fastest": 0.5}
    return speed_map.get(name, 0.25)


def _encode_params(params: dict) -> str:
    from urllib.parse import urlencode

    return urlencode(params)


def _safe_json(raw: str) -> Optional[dict]:
    try:
        return json.loads(raw)
    except Exception:
        return None
