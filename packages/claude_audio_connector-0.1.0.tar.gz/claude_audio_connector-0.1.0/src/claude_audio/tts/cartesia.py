from __future__ import annotations

import base64
import threading
from typing import Iterable

import sounddevice as sd

_SPEED_MAP = {
    "slowest": -1.0,
    "slow": -0.5,
    "normal": 0.0,
    "fast": 0.25,
    "fastest": 0.5,
}

_client_cache = {}


class CartesiaSpeaker:
    def __init__(self, cfg) -> None:
        self._cfg = cfg
        self._stop = threading.Event()
        self._lock = threading.Lock()

    def _get_client(self):
        key = self._cfg.api_key
        if key not in _client_cache:
            from cartesia import Cartesia
            _client_cache[key] = Cartesia(api_key=key)
        return _client_cache[key]

    def stop(self) -> None:
        self._stop.set()

    def _tts_params(self) -> dict:
        return dict(
            model_id=self._cfg.model_id,
            voice={"mode": "id", "id": self._cfg.voice_id},
            output_format={"container": "raw", "encoding": "pcm_s16le", "sample_rate": self._cfg.sample_rate},
            speed=_SPEED_MAP.get(self._cfg.speed, 0.25),
            language="en",
        )

    def speak(self, text: str) -> None:
        text = (text or "").strip()
        if not self._cfg.api_key or not text:
            return
        with self._lock:
            self._stop.clear()
            with sd.RawOutputStream(samplerate=self._cfg.sample_rate, channels=1, dtype="int16") as stream:
                for event in self._get_client().tts.sse(transcript=text, **self._tts_params()):
                    if self._stop.is_set():
                        break
                    if hasattr(event, "audio") and event.audio:
                        try:
                            raw = event.audio
                            raw += "=" * (-len(raw) % 4)
                            data = base64.b64decode(raw)
                            aligned = data[:len(data) - len(data) % 2]
                            if aligned:
                                stream.write(aligned)
                        except Exception:
                            pass

    async def speak_async(self, text: str) -> None:
        import asyncio
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self.speak, text)
