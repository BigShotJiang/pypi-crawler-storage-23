from __future__ import annotations

import asyncio
import os
import shlex
import signal
from dataclasses import dataclass


@dataclass(frozen=True)
class RunnerConfig:
    enabled: bool
    cmd: str
    prompt_timeout_ms: int
    kill_timeout_ms: int


class Runner:
    def __init__(self, cfg: RunnerConfig, tts_fn) -> None:
        self._cfg = cfg
        self._tts_fn = tts_fn
        self._proc: asyncio.subprocess.Process | None = None
        self._reader_task: asyncio.Task | None = None
        self._tts_task: asyncio.Task | None = None
        self._tts_queue: asyncio.Queue[str] = asyncio.Queue()
        self._lock = asyncio.Lock()

    async def start(self, prompt: str) -> None:
        if not self._cfg.enabled:
            return
        async with self._lock:
            await self._stop_locked()
            cmd = self._build_cmd(prompt)
            self._proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                start_new_session=True,
            )
            if "{prompt}" not in self._cfg.cmd:
                assert self._proc.stdin is not None
                self._proc.stdin.write((prompt + "\n").encode("utf-8"))
                await self._proc.stdin.drain()
                self._proc.stdin.close()
            self._tts_task = asyncio.create_task(self._tts_worker())
            self._reader_task = asyncio.create_task(self._read_output())

    async def stop(self) -> None:
        async with self._lock:
            await self._stop_locked()

    async def _stop_locked(self) -> None:
        if not self._proc:
            return
        proc = self._proc
        self._proc = None

        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGINT)
        except Exception:
            try:
                proc.send_signal(signal.SIGINT)
            except Exception:
                pass

        try:
            await asyncio.wait_for(proc.wait(), timeout=self._cfg.kill_timeout_ms / 1000)
        except asyncio.TimeoutError:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
            try:
                await asyncio.wait_for(proc.wait(), timeout=self._cfg.kill_timeout_ms / 1000)
            except asyncio.TimeoutError:
                pass

        await self._stop_tasks()

    async def _stop_tasks(self) -> None:
        if self._reader_task:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except BaseException:
                pass
            self._reader_task = None
        if self._tts_task:
            self._tts_task.cancel()
            try:
                await self._tts_task
            except BaseException:
                pass
            self._tts_task = None
        while not self._tts_queue.empty():
            try:
                self._tts_queue.get_nowait()
            except asyncio.QueueEmpty:
                break

    def _build_cmd(self, prompt: str) -> list[str]:
        if "{prompt}" in self._cfg.cmd:
            cmd_str = self._cfg.cmd.format(prompt=prompt)
        else:
            cmd_str = self._cfg.cmd
        return shlex.split(cmd_str)

    async def _tts_worker(self) -> None:
        while True:
            text = await self._tts_queue.get()
            if text:
                await self._tts_fn(text)

    async def _read_output(self) -> None:
        assert self._proc and self._proc.stdout
        buf = ""
        while True:
            chunk = await self._proc.stdout.read(256)
            if not chunk:
                break
            buf += chunk.decode("utf-8", errors="replace")
            speak, buf = _split_speakable(buf)
            for part in speak:
                await self._tts_queue.put(part)
        if buf.strip():
            await self._tts_queue.put(buf.strip())
        try:
            await self._proc.wait()
        except Exception:
            pass


def _split_speakable(text: str) -> tuple[list[str], str]:
    parts: list[str] = []
    buf = text
    while True:
        idx = _find_break(buf)
        if idx == -1:
            break
        part = buf[:idx].strip()
        if part:
            parts.append(part)
        buf = buf[idx:].lstrip()
    if len(buf) > 240:
        parts.append(buf[:240].strip())
        buf = buf[240:]
    return parts, buf


def _find_break(text: str) -> int:
    for i, ch in enumerate(text):
        if ch in ".?!\n":
            return i + 1
    return -1
