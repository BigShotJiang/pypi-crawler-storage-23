from __future__ import annotations

import asyncio
import os
import re
import signal
import sys
import threading
import time
import warnings

import sounddevice as sd
from sarvamai import AsyncSarvamAI

from ..audio.devices import resolve_input_device
from ..config import load_config, load_env_from_args
from ..ipc.server import IpcServer
from ..stt.sarvam import send_audio_loop
from ..tts.cartesia import CartesiaSpeaker
from ..wakeword.openwakeword import WakewordConfig, WakewordListener
from .interrupt import InterruptController, InterruptConfig
from .runner import Runner, RunnerConfig

warnings.filterwarnings("ignore", category=DeprecationWarning)

WAKE_RE = re.compile(
    r"^(?:hey|a|ok|okay)\s+(?:claude|cloud|klaude|klaud|claud|lord|clod|clade)[,.:!?\s]*",
    re.IGNORECASE,
)
STOP_PHRASES = {"stop listening", "no audio", "stop audio", "exit audio"}

BATCH_INTERVAL = 0.08


def _build_wake_regex(phrases: list[str]) -> re.Pattern:
    if not phrases:
        return WAKE_RE
    if phrases == ["hey claude"]:
        return WAKE_RE
    parts = []
    for phrase in phrases:
        phrase = phrase.strip()
        if not phrase:
            continue
        tokens = [re.escape(tok) for tok in phrase.split()]
        parts.append(r"\s+".join(tokens))
    if not parts:
        return WAKE_RE
    return re.compile(rf"^(?:{'|'.join(parts)})[,.:!?\s]*", re.IGNORECASE)


def _set_status(path: str, status: str) -> None:
    try:
        with open(path, "w") as f:
            f.write(status)
    except OSError:
        pass


def _write_interrupt(path: str, msg: str) -> None:
    try:
        with open(path, "w") as f:
            f.write(msg)
    except OSError:
        pass


async def _streaming_loop(cfg, ipc: IpcServer, runner: Runner, speaker: CartesiaSpeaker, interrupt: InterruptController) -> None:
    loop = asyncio.get_running_loop()
    buf: list[bytes] = []
    buf_lock = threading.Lock()
    sr = cfg.stt.sample_rate
    dev_id = resolve_input_device(cfg.audio.input_device)
    wake_re = _build_wake_regex(cfg.wake.phrases)
    pending_wake = False
    last_candidate = ""
    last_change = 0.0
    prefetched = False
    active_prompt = ""

    def on_hotword() -> None:
        def _set() -> None:
            nonlocal pending_wake
            pending_wake = True
            asyncio.create_task(handle_interrupt())
        loop.call_soon_threadsafe(_set)

    def mic_cb(indata, frames, time_info, status):
        frame = bytes(indata)
        with buf_lock:
            buf.append(frame)
        hotword.submit(frame)

    async def handle_interrupt(voice_msg: str | None = None) -> None:
        nonlocal last_candidate, prefetched
        if cfg.tts.barge_in:
            speaker.stop()
        if voice_msg:
            _write_interrupt(cfg.daemon.interrupt_path, voice_msg)
        interrupt.trigger()
        await runner.stop()
        await ipc.publish("INTERRUPT")
        last_candidate = ""
        prefetched = False

    async def handle_prompt(prompt: str, prefetch: bool) -> None:
        nonlocal active_prompt
        if not prompt:
            return
        if prefetch and prompt == active_prompt:
            return
        if not prefetch:
            await handle_interrupt(prompt)
        else:
            await runner.stop()
        if cfg.runner.enabled:
            await runner.start(prompt)
        if not prefetch:
            await ipc.publish(prompt)
        active_prompt = prompt
        _set_status(cfg.daemon.status_path, "thinking")

    hotword = WakewordListener(
        WakewordConfig(
            enabled=cfg.wake.enabled,
            engine=cfg.wake.engine,
            phrases=cfg.wake.phrases,
            threshold=cfg.wake.threshold,
            model_paths=cfg.wake.model_paths,
            frame_ms=cfg.wake.frame_ms,
            cooldown_ms=cfg.wake.cooldown_ms,
            sample_rate=cfg.stt.sample_rate,
        ),
        on_hotword,
    )
    hotword.start()

    client = AsyncSarvamAI(api_subscription_key=cfg.stt.api_key)

    async with client.speech_to_text_streaming.connect(
        model=cfg.stt.model,
        mode="transcribe",
        language_code=cfg.stt.language,
        high_vad_sensitivity="true" if cfg.stt.high_vad else "false",
        vad_signals="true",
    ) as ws:
        with sd.RawInputStream(
            samplerate=sr,
            channels=1,
            dtype="int16",
            blocksize=cfg.audio.blocksize,
            callback=mic_cb,
            device=dev_id,
        ):
            stop_event = asyncio.Event()
            sender = asyncio.create_task(send_audio_loop(ws, buf, buf_lock, sr, stop_event, BATCH_INTERVAL))

            try:
                async for msg in ws:
                    msg_type = str(getattr(msg, "type", ""))
                    data = getattr(msg, "data", None)

                    if msg_type == "events":
                        sig = getattr(data, "signal_type", "") if data else ""
                        if sig == "START_SPEECH":
                            _set_status(cfg.daemon.status_path, "recording")
                        elif sig == "END_SPEECH":
                            _set_status(cfg.daemon.status_path, "processing")
                            if last_candidate:
                                if prefetched and last_candidate == active_prompt:
                                    last_candidate = ""
                                    prefetched = False
                                    continue
                                await handle_prompt(last_candidate, prefetch=False)
                                last_candidate = ""
                                prefetched = False

                    elif msg_type == "data":
                        text = (getattr(data, "transcript", "") or "").strip()
                        if not text or text == "<nospeech>":
                            _set_status(cfg.daemon.status_path, "idle")
                            continue

                        if text.lower().strip() in STOP_PHRASES:
                            await ipc.publish("STOP_LISTENING")
                            return

                        candidate = ""
                        if pending_wake:
                            candidate = wake_re.sub("", text).strip()
                            if not candidate:
                                _set_status(cfg.daemon.status_path, "idle")
                                continue
                            pending_wake = False
                        else:
                            match = wake_re.match(text)
                            if match:
                                candidate = text[match.end():].strip()
                                if not candidate:
                                    pending_wake = True
                                    _set_status(cfg.daemon.status_path, "idle")
                                    continue

                        if candidate:
                            now = time.monotonic()
                            if candidate != last_candidate:
                                last_candidate = candidate
                                last_change = now
                                prefetched = False
                            elif (
                                cfg.runner.enabled
                                and cfg.stt.prefetch_enabled
                                and not prefetched
                                and (now - last_change) * 1000 >= cfg.stt.partial_stability_ms
                            ):
                                await handle_prompt(candidate, prefetch=True)
                                prefetched = True
                            _set_status(cfg.daemon.status_path, "heard")
                        else:
                            _set_status(cfg.daemon.status_path, "idle")
            finally:
                stop_event.set()
                sender.cancel()
                try:
                    await sender
                except asyncio.CancelledError:
                    pass
                hotword.close()


async def run_daemon() -> None:
    cfg = load_config()

    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, stop_event.set)
        except NotImplementedError:
            signal.signal(sig, lambda *_: stop_event.set())

    speaker = CartesiaSpeaker(cfg.tts)
    runner = Runner(
        RunnerConfig(
            cfg.runner.enabled,
            cfg.runner.cmd,
            cfg.runner.prompt_timeout_ms,
            cfg.runner.kill_timeout_ms,
        ),
        speaker.speak_async,
    )
    interrupt = InterruptController(
        InterruptConfig(
            enabled=cfg.interrupt.enabled,
            signal=cfg.interrupt.signal,
            pid=cfg.interrupt.pid,
            pid_file=cfg.interrupt.pid_file,
            command=cfg.interrupt.command,
            cooldown_ms=cfg.interrupt.cooldown_ms,
        )
    )

    async def tts_fn(text: str) -> None:
        await speaker.speak_async(text)

    async def interrupt_fn() -> None:
        speaker.stop()
        interrupt.trigger()
        await runner.stop()
        await ipc.publish("INTERRUPT")

    async def prompt_fn(text: str) -> None:
        speaker.stop()
        interrupt.trigger()
        await runner.stop()
        if cfg.runner.enabled:
            await runner.start(text)
        await ipc.publish(text)
        _set_status(cfg.daemon.status_path, "thinking")

    ipc = IpcServer(cfg.daemon.socket, tts_fn=tts_fn, interrupt_fn=interrupt_fn, prompt_fn=prompt_fn)
    await ipc.start()

    with open(cfg.daemon.pid_path, "w") as f:
        f.write(str(os.getpid()))

    backoff = 0.5

    try:
        while not stop_event.is_set():
            _set_status(cfg.daemon.status_path, "idle")
            try:
                await _streaming_loop(cfg, ipc, runner, speaker, interrupt)
                backoff = 0.5
            except Exception:
                _set_status(cfg.daemon.status_path, "error")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 15)
    finally:
        await ipc.close()
        await runner.stop()
        for path in (cfg.daemon.pid_path, cfg.daemon.status_path, cfg.daemon.interrupt_path):
            try:
                os.remove(path)
            except OSError:
                pass


def main() -> None:
    load_env_from_args(sys.argv[1:])
    try:
        asyncio.run(run_daemon())
    except KeyboardInterrupt:
        return


if __name__ == "__main__":
    main()
