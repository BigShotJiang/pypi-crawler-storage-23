from __future__ import annotations

import os
import shlex
import signal
import subprocess
import time
from dataclasses import dataclass


@dataclass(frozen=True)
class InterruptConfig:
    enabled: bool
    signal: int
    pid: int | None
    pid_file: str | None
    command: str | None
    cooldown_ms: int


class InterruptController:
    def __init__(self, cfg: InterruptConfig) -> None:
        self._cfg = cfg
        self._last = 0.0

    def trigger(self) -> bool:
        if not self._cfg.enabled:
            return False
        now = time.monotonic()
        if (now - self._last) * 1000 < self._cfg.cooldown_ms:
            return False
        self._last = now

        if self._cfg.command:
            return self._run_command(self._cfg.command)

        pid = self._cfg.pid or self._read_pid(self._cfg.pid_file)
        if not pid:
            return False
        try:
            pgid = os.getpgid(pid)
            os.killpg(pgid, self._cfg.signal)
            time.sleep(0.05)
            os.killpg(pgid, self._cfg.signal)
            return True
        except OSError:
            try:
                os.kill(pid, self._cfg.signal)
                return True
            except OSError:
                return False

    def _read_pid(self, path: str | None) -> int | None:
        if not path:
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = f.read().strip()
        except OSError:
            return None
        if raw.isdigit():
            return int(raw)
        return None

    def _run_command(self, command: str) -> bool:
        try:
            subprocess.Popen(shlex.split(command))
            return True
        except Exception:
            return False
