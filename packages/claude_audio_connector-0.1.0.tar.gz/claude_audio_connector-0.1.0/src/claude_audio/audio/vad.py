from __future__ import annotations

import warnings
from array import array
from dataclasses import dataclass

with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    try:
        import webrtcvad
    except Exception:
        webrtcvad = None


@dataclass(frozen=True)
class VadConfig:
    sample_rate: int
    blocksize: int
    enabled: bool
    mode: int
    energy_threshold: float
    noise_ms: int
    noise_multiplier: float


class VoiceActivityDetector:
    def __init__(self, cfg: VadConfig) -> None:
        self._cfg = cfg
        self._vad = None
        self._noise_floor = cfg.energy_threshold
        self._noise_samples = 0
        self._noise_frames = max(1, int(cfg.noise_ms / self._frame_ms))

        if cfg.enabled and webrtcvad is not None:
            if self._frame_ms in {10, 20, 30} and cfg.sample_rate in {8000, 16000, 32000, 48000}:
                self._vad = webrtcvad.Vad(int(cfg.mode))

    @property
    def _frame_ms(self) -> int:
        return int(1000 * self._cfg.blocksize / self._cfg.sample_rate)

    def is_speech(self, frame: bytes) -> bool:
        energy = self._pcm_energy(frame)

        if self._noise_samples < self._noise_frames:
            self._noise_floor = ((self._noise_floor * self._noise_samples) + energy) / (self._noise_samples + 1)
            self._noise_samples += 1
            return False

        threshold = max(self._cfg.energy_threshold, self._noise_floor * self._cfg.noise_multiplier)
        if energy < threshold:
            self._noise_floor = (self._noise_floor * 0.98) + (energy * 0.02)
            return False

        if self._vad:
            return bool(self._vad.is_speech(frame, self._cfg.sample_rate))
        return True

    def _pcm_energy(self, frame: bytes) -> float:
        samples = array("h")
        samples.frombytes(frame)
        if not samples:
            return 0.0
        total = 0.0
        for s in samples:
            total += abs(s)
        return (total / len(samples)) / 32768.0
