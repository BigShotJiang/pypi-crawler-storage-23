from __future__ import annotations

import sounddevice as sd


def resolve_input_device(name: str | None) -> int | None:
    if name is None:
        return None
    if name.isdigit():
        return int(name)
    for i, d in enumerate(sd.query_devices()):
        if d.get("max_input_channels", 0) > 0 and name.lower() in d.get("name", "").lower():
            return i
    return None
