from __future__ import annotations

import asyncio
import queue
import time
from collections import deque
from dataclasses import dataclass
from typing import Callable, Deque

import sounddevice as sd

from .devices import resolve_input_device
from .vad import VadConfig, VoiceActivityDetector


@dataclass(frozen=True)
class CaptureConfig:
    sample_rate: int
    blocksize: int
    queue_ms: int
    pre_roll_ms: int
    silence_hold_ms: int
    no_speech_timeout: float
    max_utterance_sec: float
    vad: VadConfig


async def record_utterance(
    cfg: CaptureConfig,
    device: str | None = None,
    on_chunk: Callable[[bytes], None] | None = None,
    status_cb: Callable[[str], None] | None = None,
) -> list[bytes]:
    maxsize = max(1, int(cfg.queue_ms / (1000 * cfg.blocksize / cfg.sample_rate)))
    q: queue.Queue[bytes] = queue.Queue(maxsize=maxsize)
    vad = VoiceActivityDetector(cfg.vad)
    pre_roll: Deque[bytes] = deque()
    pre_roll_frames = max(1, int(cfg.pre_roll_ms / (1000 * cfg.blocksize / cfg.sample_rate)))
    hold_frames = max(1, int(cfg.silence_hold_ms / (1000 * cfg.blocksize / cfg.sample_rate)))

    def cb(indata, frames, time_info, status):
        frame = bytes(indata)
        try:
            q.put_nowait(frame)
        except queue.Full:
            try:
                q.get_nowait()
            except queue.Empty:
                pass
            try:
                q.put_nowait(frame)
            except queue.Full:
                pass

    frame_ms = 1000 * cfg.blocksize / cfg.sample_rate
    start_confirm_frames = max(3, int(200 / frame_ms))
    min_record_frames = max(1, int(1000 / frame_ms))

    dev_id = resolve_input_device(device)
    loop = asyncio.get_running_loop()
    frames_out: list[bytes] = []
    started = False
    speech_streak = 0
    silence = 0
    t_start = time.monotonic()

    with sd.RawInputStream(
        samplerate=cfg.sample_rate,
        channels=1,
        dtype="int16",
        blocksize=cfg.blocksize,
        device=dev_id,
        callback=cb,
    ):
        while True:
            elapsed = time.monotonic() - t_start
            if not started and elapsed > cfg.no_speech_timeout:
                return []
            if elapsed > cfg.max_utterance_sec:
                break

            try:
                frame = await loop.run_in_executor(None, lambda: q.get(timeout=0.5))
            except queue.Empty:
                continue

            if not started:
                pre_roll.append(frame)
                while len(pre_roll) > pre_roll_frames:
                    pre_roll.popleft()
                if vad.is_speech(frame):
                    speech_streak += 1
                else:
                    speech_streak = 0
                if speech_streak >= start_confirm_frames:
                    started = True
                    if status_cb:
                        status_cb("recording")
                    for f in pre_roll:
                        frames_out.append(f)
                        if on_chunk:
                            on_chunk(f)
                    pre_roll.clear()
                continue

            frames_out.append(frame)
            if on_chunk:
                on_chunk(frame)

            if vad.is_speech(frame):
                silence = 0
            else:
                silence += 1
                if len(frames_out) >= min_record_frames and silence >= hold_frames:
                    break

    if status_cb:
        status_cb("processing")
    return frames_out
