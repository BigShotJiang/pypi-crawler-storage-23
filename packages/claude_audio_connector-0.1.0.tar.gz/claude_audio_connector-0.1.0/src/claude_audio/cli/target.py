import os
import subprocess
import sys

from ..config import load_env_from_args
from ..runtime import runtime_path


def _find_claude_ancestor() -> int | None:
    pid = os.getpid()
    while pid > 1:
        pid = _ppid(pid)
        if pid is None or pid <= 1:
            break
        name = _comm(pid)
        if name and name.startswith("claude"):
            return pid
    return None


def _ppid(pid: int) -> int | None:
    try:
        r = subprocess.run(["ps", "-o", "ppid=", "-p", str(pid)], capture_output=True, text=True, check=False)
        return int(r.stdout.strip())
    except (ValueError, OSError):
        return None


def _comm(pid: int) -> str | None:
    try:
        r = subprocess.run(["ps", "-o", "comm=", "-p", str(pid)], capture_output=True, text=True, check=False)
        return os.path.basename(r.stdout.strip())
    except OSError:
        return None


def main() -> None:
    load_env_from_args(sys.argv[1:])
    pid = None
    if len(sys.argv) > 1:
        try:
            pid = int(sys.argv[1])
        except ValueError:
            pid = None

    if pid is None:
        pid = _find_claude_ancestor()

    if pid is None:
        pid = os.getppid()
        sys.stderr.write(f"(could not find claude ancestor, using parent {pid})\n")

    path = runtime_path("target_pid")
    with open(path, "w", encoding="utf-8") as f:
        f.write(str(pid))

    name = _comm(pid) or "unknown"
    try:
        pgid = os.getpgid(pid)
        print(f"Interrupt target: PID {pid} ({name}, pgid {pgid})")
    except OSError:
        print(f"Interrupt target: PID {pid} ({name})")


if __name__ == "__main__":
    main()
