import asyncio
import sys

from ..config import load_env_from_args
from ..ipc.client import interrupt_via_daemon
from ..runtime import socket_path


def main() -> None:
    load_env_from_args(sys.argv[1:])
    ok = asyncio.run(interrupt_via_daemon(socket_path()))
    if not ok:
        sys.stderr.write("(voice daemon not running)\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
