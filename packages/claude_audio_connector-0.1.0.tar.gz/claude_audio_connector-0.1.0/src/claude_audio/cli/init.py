from __future__ import annotations

import sys
from pathlib import Path

AUDIO_COMMAND = """\
Voice conversation mode.

```
$PROMPT = $(claude-audio-capture 2>/dev/null)
```

Rules:
1. COMPLETE the entire task from the voice prompt. Do all the work — read files, write code, run commands, everything needed. Do NOT listen for more input until the task is fully done.
2. Once the task is complete, run `claude-audio-speak "<brief summary of what you did>"`.
3. Then run `claude-audio-capture 2>/dev/null` (timeout 600s) to get the next voice command.
4. Repeat. Never stop looping.
5. If a tool is blocked with "Voice interrupt", run `claude-audio-capture 2>/dev/null` to hear the new instruction.

$PROMPT
"""


def main() -> None:
    target = Path.cwd()
    if len(sys.argv) > 1 and sys.argv[1] not in ("--help", "-h"):
        target = Path(sys.argv[1]).resolve()

    commands_dir = target / ".claude" / "commands"
    audio_path = commands_dir / "audio.md"

    if audio_path.exists():
        print(f"Already exists: {audio_path}")
        return

    commands_dir.mkdir(parents=True, exist_ok=True)
    audio_path.write_text(AUDIO_COMMAND)
    print(f"Created {audio_path}")
    print("Open Claude Code in this project and type /audio to start talking.")


if __name__ == "__main__":
    main()
