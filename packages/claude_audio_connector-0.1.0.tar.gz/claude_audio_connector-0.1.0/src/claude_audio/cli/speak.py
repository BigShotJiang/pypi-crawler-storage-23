import asyncio
import sys

from ..config import load_tts_config, load_env_from_args
from ..ipc.client import speak_via_daemon
from ..runtime import socket_path
from ..tts.cartesia import CartesiaSpeaker


def _play_direct(text: str) -> None:
    cfg = load_tts_config()
    speaker = CartesiaSpeaker(cfg)
    speaker.speak(text)


def main() -> None:
    load_env_from_args(sys.argv[1:])
    text = " ".join(sys.argv[1:]).strip()
    if not text:
        text = sys.stdin.read().strip()
    if not text:
        return

    sent = asyncio.run(speak_via_daemon(text, socket_path()))
    if not sent:
        _play_direct(text)


if __name__ == "__main__":
    main()
