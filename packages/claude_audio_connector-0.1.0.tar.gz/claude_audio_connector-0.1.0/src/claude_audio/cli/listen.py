import asyncio
import re
import sys

from ..audio.capture import CaptureConfig, record_utterance
from ..audio.vad import VadConfig
from ..config import load_config, load_env_from_args
from ..stt.transcribe import transcribe_chunks

WAKE_RE = re.compile(
    r"^(?:hey|a|ok|okay)\s+(?:claude|cloud|klaude|klaud|claud|lord|clod|clade)[,.:!?\s]*",
    re.IGNORECASE,
)
STOP_PHRASES = {"stop listening", "no audio", "stop audio", "exit audio"}


async def listen_once(cfg) -> str | None:
    vad_cfg = VadConfig(
        sample_rate=cfg.audio.sample_rate,
        blocksize=cfg.audio.blocksize,
        enabled=cfg.vad.enabled,
        mode=cfg.vad.mode,
        energy_threshold=cfg.vad.threshold,
        noise_ms=cfg.vad.noise_ms,
        noise_multiplier=cfg.vad.noise_multiplier,
    )
    cap_cfg = CaptureConfig(
        sample_rate=cfg.audio.sample_rate,
        blocksize=cfg.audio.blocksize,
        queue_ms=cfg.audio.queue_ms,
        pre_roll_ms=cfg.vad.preroll_ms,
        silence_hold_ms=cfg.vad.hold_ms,
        no_speech_timeout=cfg.vad.no_speech_timeout,
        max_utterance_sec=cfg.vad.max_utterance_sec,
        vad=vad_cfg,
    )

    while True:
        chunks = await record_utterance(
            cap_cfg,
            device=cfg.audio.input_device,
            on_chunk=None,
            status_cb=None,
        )
        text = await transcribe_chunks(chunks, cfg)

        if not text:
            sys.stderr.write("(noise, ignoring)\n")
            sys.stderr.flush()
            continue

        sys.stderr.write(f"Heard: {text}\n")
        sys.stderr.flush()

        if text.lower().strip() in STOP_PHRASES:
            return ""

        match = WAKE_RE.match(text)
        if match:
            prompt = text[match.end():].strip()
            if prompt:
                return prompt
            sys.stderr.write("(wake word only, waiting)\n")
            sys.stderr.flush()


def main() -> None:
    load_env_from_args(sys.argv[1:])
    cfg = load_config()

    sys.stderr.write("Listening for wake word...\n")
    sys.stderr.flush()

    try:
        text = asyncio.run(listen_once(cfg))
    except KeyboardInterrupt:
        return

    if text:
        sys.stderr.write(f"Prompt: {text}\n")
        sys.stderr.flush()
        sys.stdout.write(text + "\n")
    elif text == "":
        sys.stdout.write("STOP_LISTENING\n")


if __name__ == "__main__":
    main()
