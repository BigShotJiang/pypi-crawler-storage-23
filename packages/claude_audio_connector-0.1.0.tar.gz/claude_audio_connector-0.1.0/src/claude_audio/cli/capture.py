import asyncio
import os
import re
import signal
import subprocess
import sys

from ..audio.capture import CaptureConfig, record_utterance
from ..audio.vad import VadConfig
from ..config import load_config, load_env_from_args
from ..runtime import runtime_path
from ..stt.transcribe import transcribe_chunks

WAKE_RE = re.compile(
    r"^(?:hey|a|ok|okay)\s+(?:claude|cloud|klaude|klaud|claud|lord|clod|clade)[,.:!?\s]*",
    re.IGNORECASE,
)


def _out(msg: str) -> None:
    sys.stdout.write(msg + "\n")
    sys.stdout.flush()


def _kill_mic_monitor() -> None:
    pid_path = runtime_path("mic_monitor_pid")
    try:
        with open(pid_path) as f:
            pid = int(f.read().strip())
        os.kill(pid, signal.SIGTERM)
    except (OSError, ValueError):
        pass
    try:
        os.remove(pid_path)
    except OSError:
        pass


def _start_mic_monitor() -> None:
    subprocess.Popen(
        [sys.executable, "-m", "claude_audio.cli.mic_monitor"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )


async def _capture_loop(cfg) -> str:
    vad_cfg = VadConfig(
        sample_rate=cfg.audio.sample_rate,
        blocksize=cfg.audio.blocksize,
        enabled=cfg.vad.enabled,
        mode=cfg.vad.mode,
        energy_threshold=cfg.vad.threshold,
        noise_ms=cfg.vad.noise_ms,
        noise_multiplier=cfg.vad.noise_multiplier,
    )
    cap_cfg = CaptureConfig(
        sample_rate=cfg.audio.sample_rate,
        blocksize=cfg.audio.blocksize,
        queue_ms=cfg.audio.queue_ms,
        pre_roll_ms=cfg.vad.preroll_ms,
        silence_hold_ms=cfg.vad.hold_ms,
        no_speech_timeout=cfg.vad.no_speech_timeout,
        max_utterance_sec=cfg.vad.max_utterance_sec,
        vad=vad_cfg,
    )

    _out("Listening...")

    while True:
        chunks = await record_utterance(
            cap_cfg, device=cfg.audio.input_device,
        )
        if not chunks:
            continue

        text = await transcribe_chunks(chunks, cfg)
        if text and text.strip() and text.strip() != "<nospeech>":
            return text.strip()


def main() -> None:
    sys.stdout.reconfigure(line_buffering=True)
    load_env_from_args(sys.argv[1:])
    cfg = load_config()

    _kill_mic_monitor()
    try:
        os.remove(runtime_path("voice_interrupt"))
    except OSError:
        pass

    try:
        text = asyncio.run(_capture_loop(cfg))
    except KeyboardInterrupt:
        _start_mic_monitor()
        return

    _start_mic_monitor()

    match = WAKE_RE.match(text)
    if match:
        text = text[match.end():].strip() or text

    _out(text)


if __name__ == "__main__":
    main()
