import os
import sys

from ..config import load_env_from_args
from ..runtime import runtime_path


def main() -> None:
    load_env_from_args(sys.argv[1:])
    status_path = runtime_path("status")
    if not os.path.exists(status_path):
        sys.stderr.write("(no status file)\n")
        sys.exit(1)
    try:
        with open(status_path, "r") as f:
            status = f.read().strip()
    except OSError:
        sys.stderr.write("(failed to read status)\n")
        sys.exit(1)
    print(status)


if __name__ == "__main__":
    main()
