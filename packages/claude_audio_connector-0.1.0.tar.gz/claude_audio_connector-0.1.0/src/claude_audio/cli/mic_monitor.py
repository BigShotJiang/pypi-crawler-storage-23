import io
import os
import queue
import re
import signal
import sys
import tempfile
import time
import wave

import sounddevice as sd

from ..audio.devices import resolve_input_device
from ..audio.vad import VadConfig, VoiceActivityDetector
from ..config import load_config, load_env_from_args
from ..runtime import runtime_path

WAKE_RE = re.compile(
    r"(?:hey|a|ok|okay)\s+(?:claude|cloud|klaude|klaud|claud|lord|clod|clade)",
    re.IGNORECASE,
)


def _transcribe_clip(pcm: bytes, cfg) -> str:
    from sarvamai import SarvamAI

    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(cfg.audio.sample_rate)
        wf.writeframes(pcm)

    with tempfile.NamedTemporaryFile(suffix=".wav") as tmp:
        tmp.write(buf.getvalue())
        tmp.flush()
        with open(tmp.name, "rb") as f:
            client = SarvamAI(api_subscription_key=cfg.stt.api_key)
            result = client.speech_to_text.transcribe(
                file=f, model=cfg.stt.model, language_code=cfg.stt.language,
            )
    return (getattr(result, "transcript", "") or "").strip()


def main() -> None:
    sys.stdout.reconfigure(line_buffering=True)
    load_env_from_args(sys.argv[1:])
    cfg = load_config()

    interrupt_path = runtime_path("voice_interrupt")
    pid_path = runtime_path("mic_monitor_pid")

    vad_cfg = VadConfig(
        sample_rate=cfg.audio.sample_rate,
        blocksize=cfg.audio.blocksize,
        enabled=cfg.vad.enabled,
        mode=cfg.vad.mode,
        energy_threshold=cfg.vad.threshold,
        noise_ms=cfg.vad.noise_ms,
        noise_multiplier=cfg.vad.noise_multiplier,
    )
    vad = VoiceActivityDetector(vad_cfg)
    frame_ms = 1000 * cfg.audio.blocksize / cfg.audio.sample_rate
    confirm_frames = max(3, int(200 / frame_ms))
    record_frames = max(1, int(1500 / frame_ms))

    q: queue.Queue[bytes] = queue.Queue(maxsize=200)

    def cb(indata, frames, time_info, status):
        try:
            q.put_nowait(bytes(indata))
        except queue.Full:
            pass

    with open(pid_path, "w") as f:
        f.write(str(os.getpid()))

    stop = False

    def handle_sig(*_):
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, handle_sig)
    signal.signal(signal.SIGINT, handle_sig)

    dev_id = resolve_input_device(cfg.audio.input_device)
    stream = sd.RawInputStream(
        samplerate=cfg.audio.sample_rate, channels=1, dtype="int16",
        blocksize=cfg.audio.blocksize, device=dev_id, callback=cb,
    )
    stream.start()

    speech_streak = 0
    cooldown_until = time.monotonic() + 2.0

    while not stop:
        try:
            frame = q.get(timeout=0.5)
        except queue.Empty:
            continue

        now = time.monotonic()
        if now < cooldown_until:
            continue

        if vad.is_speech(frame):
            speech_streak += 1
        else:
            speech_streak = 0

        if speech_streak < confirm_frames:
            continue

        clip_frames = [frame]
        deadline = time.monotonic() + record_frames * frame_ms / 1000
        while time.monotonic() < deadline and not stop:
            try:
                clip_frames.append(q.get(timeout=0.1))
            except queue.Empty:
                break

        pcm = b"".join(clip_frames)
        try:
            text = _transcribe_clip(pcm, cfg)
        except Exception:
            text = ""

        speech_streak = 0

        if text and WAKE_RE.search(text):
            try:
                with open(interrupt_path, "w") as f:
                    f.write(text)
            except OSError:
                pass
            cooldown_until = time.monotonic() + 5.0
        else:
            cooldown_until = time.monotonic() + 2.0

    stream.stop()
    stream.close()
    try:
        os.remove(pid_path)
    except OSError:
        pass


if __name__ == "__main__":
    main()
