import os
import signal
import subprocess
import sys
import time

from ..config import load_env_from_args
from ..runtime import runtime_path, socket_path


PID_PATH = runtime_path("pid")
STATUS_PATH = runtime_path("status")


def _daemon_alive() -> bool:
    if not os.path.exists(PID_PATH):
        return False
    try:
        with open(PID_PATH) as f:
            pid = int(f.read().strip())
        os.kill(pid, 0)
        return True
    except (OSError, ValueError):
        return False


def _ensure_daemon() -> None:
    if _daemon_alive():
        sys.stderr.write("\033[2mVoice daemon already running.\033[0m\n")
        return

    from .start import _kill_all_daemons

    _kill_all_daemons()
    time.sleep(0.2)

    for f in (PID_PATH, STATUS_PATH, runtime_path("target_pid"), runtime_path("voice_interrupt"), socket_path()):
        try:
            os.remove(f)
        except OSError:
            pass

    subprocess.Popen(
        [sys.executable, "-m", "claude_audio.orchestration.daemon"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )

    for _ in range(30):
        if os.path.exists(PID_PATH):
            sys.stderr.write("\033[2mVoice daemon started.\033[0m\n")
            return
        time.sleep(0.2)

    sys.stderr.write("Failed to start voice daemon.\n")
    sys.exit(1)


def _set_target() -> None:
    from .target import _find_claude_ancestor, _comm

    pid = _find_claude_ancestor() or os.getppid()
    path = runtime_path("target_pid")
    with open(path, "w", encoding="utf-8") as f:
        f.write(str(pid))

    name = _comm(pid) or "unknown"
    sys.stderr.write(f"\033[2mInterrupt target: {pid} ({name})\033[0m\n")


def _wait_for_prompt() -> str | None:
    from .wait import main as wait_main
    wait_main()


def main() -> None:
    load_env_from_args(sys.argv[1:])
    _ensure_daemon()
    _set_target()
    sys.stderr.write("\033[2mListening...\033[0m\n")
    sys.stderr.flush()
    _wait_for_prompt()


if __name__ == "__main__":
    main()
