import os
import signal
import subprocess
import time
import sys

from ..config import load_env_from_args
from ..runtime import runtime_path, socket_path

FILES = (
    runtime_path("pid"),
    runtime_path("status"),
    runtime_path("target_pid"),
    runtime_path("voice_interrupt"),
    socket_path(),
)


def _kill_all(sig: int = signal.SIGTERM) -> list[int]:
    pids = []
    for pattern in ("claude_audio.orchestration.daemon", "claude_audio_connector.daemon"):
        try:
            result = subprocess.run(
                ["pgrep", "-f", pattern],
                capture_output=True,
                text=True,
                check=False,
            )
            for line in result.stdout.strip().splitlines():
                pid = int(line.strip())
                if pid == os.getpid():
                    continue
                try:
                    os.kill(pid, sig)
                    pids.append(pid)
                except (OSError, ValueError):
                    pass
        except Exception:
            pass
    return pids


def main() -> None:
    load_env_from_args(sys.argv[1:])
    pids = _kill_all(signal.SIGTERM)
    if pids:
        time.sleep(0.5)
        _kill_all(signal.SIGKILL)

    for f in FILES:
        try:
            os.remove(f)
        except OSError:
            pass

    print("Voice mode off.")


if __name__ == "__main__":
    main()
