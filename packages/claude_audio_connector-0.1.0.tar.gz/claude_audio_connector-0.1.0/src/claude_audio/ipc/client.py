from __future__ import annotations

import asyncio

from .protocol import format_message, Message
from ..runtime import socket_path


async def _send(msg: Message, path: str | None = None, timeout: float = 5) -> str | None:
    sock = path or socket_path()
    try:
        reader, writer = await asyncio.open_unix_connection(sock)
    except OSError:
        return None

    writer.write((format_message(msg) + "\n").encode("utf-8"))
    await writer.drain()

    try:
        data = await asyncio.wait_for(reader.readline(), timeout=timeout)
    except (OSError, asyncio.TimeoutError):
        data = b""

    writer.close()
    return data.decode("utf-8").strip() if data else None


async def wait_for_message(path: str | None = None) -> str | None:
    sock = path or socket_path()
    try:
        reader, writer = await asyncio.open_unix_connection(sock)
    except OSError:
        return None

    writer.write(b"WAIT\n")
    await writer.drain()

    try:
        data = await reader.readline()
    except OSError:
        data = b""

    writer.close()
    return data.decode("utf-8").strip() if data else None


async def speak_via_daemon(text: str, path: str | None = None) -> bool:
    result = await _send(Message("SPEAK", text), path=path, timeout=60)
    return result == "OK"


async def interrupt_via_daemon(path: str | None = None) -> bool:
    result = await _send(Message("INTERRUPT"), path=path, timeout=5)
    return result == "OK"


async def prompt_via_daemon(text: str, path: str | None = None) -> bool:
    result = await _send(Message("PROMPT", text), path=path, timeout=5)
    return result == "OK"
