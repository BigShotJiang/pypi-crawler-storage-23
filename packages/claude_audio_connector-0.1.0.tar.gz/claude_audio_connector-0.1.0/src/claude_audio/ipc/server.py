from __future__ import annotations

import asyncio
import os
from typing import Awaitable, Callable

from .protocol import Message, parse_line
from ..runtime import socket_path


class IpcServer:
    def __init__(
        self,
        path: str | None = None,
        tts_fn: Callable[[str], Awaitable[None]] | None = None,
        interrupt_fn: Callable[[], Awaitable[None]] | None = None,
        prompt_fn: Callable[[str], Awaitable[None]] | None = None,
    ) -> None:
        self._path = path or socket_path()
        self._tts_fn = tts_fn
        self._interrupt_fn = interrupt_fn
        self._prompt_fn = prompt_fn
        self._server: asyncio.AbstractServer | None = None
        self._waiter: asyncio.StreamWriter | None = None
        self._waiter_ready = asyncio.Event()
        self._lock = asyncio.Lock()
        self._pending_event: str | None = None

    async def start(self) -> None:
        try:
            if os.path.exists(self._path):
                os.remove(self._path)
        except OSError:
            pass
        self._server = await asyncio.start_unix_server(self._handle, path=self._path)

    async def close(self) -> None:
        if self._server:
            self._server.close()
            await self._server.wait_closed()
        async with self._lock:
            if self._waiter:
                self._waiter.close()
                self._waiter = None
        try:
            if os.path.exists(self._path):
                os.remove(self._path)
        except OSError:
            pass

    async def _handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            line = await asyncio.wait_for(reader.readline(), timeout=5)
        except (OSError, asyncio.TimeoutError):
            writer.close()
            return

        msg = parse_line(line.decode("utf-8", errors="replace"))

        if msg.kind == "WAIT":
            reply: str | None = None
            async with self._lock:
                if self._pending_event:
                    reply = self._pending_event
                    self._pending_event = None
                else:
                    if self._waiter:
                        self._waiter.close()
                    self._waiter = writer
                    self._waiter_ready.set()
            if reply is not None:
                try:
                    writer.write(reply.encode("utf-8") + b"\n")
                    await writer.drain()
                except OSError:
                    pass
                writer.close()

        elif msg.kind == "SPEAK" and msg.payload:
            if self._tts_fn:
                try:
                    await self._tts_fn(msg.payload)
                except Exception:
                    pass
            try:
                writer.write(b"OK\n")
                await writer.drain()
            except OSError:
                pass
            writer.close()

        elif msg.kind == "INTERRUPT":
            if self._interrupt_fn:
                try:
                    await self._interrupt_fn()
                except Exception:
                    pass
            try:
                writer.write(b"OK\n")
                await writer.drain()
            except OSError:
                pass
            writer.close()

        elif msg.kind == "PROMPT" and msg.payload:
            if self._prompt_fn:
                try:
                    await self._prompt_fn(msg.payload)
                except Exception:
                    pass
            try:
                writer.write(b"OK\n")
                await writer.drain()
            except OSError:
                pass
            writer.close()

        else:
            writer.close()

    @property
    def has_waiter(self) -> bool:
        return self._waiter is not None

    async def wait_for_waiter(self, stop_event: asyncio.Event) -> None:
        while not self.has_waiter and not stop_event.is_set():
            self._waiter_ready.clear()
            try:
                await asyncio.wait_for(self._waiter_ready.wait(), timeout=0.5)
            except asyncio.TimeoutError:
                pass

    async def send(self, text: str) -> bool:
        async with self._lock:
            if not self._waiter:
                return False
            writer = self._waiter
            self._waiter = None

        try:
            writer.write(text.encode("utf-8") + b"\n")
            await writer.drain()
        finally:
            writer.close()
        return True

    async def publish(self, text: str) -> None:
        writer: asyncio.StreamWriter | None = None
        async with self._lock:
            if self._waiter:
                writer = self._waiter
                self._waiter = None
            else:
                self._pending_event = text
                return
        try:
            writer.write(text.encode("utf-8") + b"\n")
            await writer.drain()
        finally:
            writer.close()
