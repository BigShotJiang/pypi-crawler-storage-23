from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Message:
    kind: str
    payload: str | None = None


def parse_line(line: str) -> Message:
    raw = line.strip()
    if not raw:
        return Message("EMPTY", None)
    if ":" in raw:
        kind, payload = raw.split(":", 1)
        return Message(kind.strip().upper(), payload)
    return Message(raw.strip().upper(), None)


def format_message(msg: Message) -> str:
    if msg.payload is None:
        return f"{msg.kind}"
    return f"{msg.kind}:{msg.payload}"
