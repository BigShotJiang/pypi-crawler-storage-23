from __future__ import annotations

from dataclasses import dataclass
import os
import signal
from pathlib import Path

from .runtime import socket_path, runtime_path


def _env_str(name: str, default: str) -> str:
    return os.getenv(name, default)


def _env_int(name: str, default: int) -> int:
    return int(os.getenv(name, str(default)))


def _env_float(name: str, default: float) -> float:
    return float(os.getenv(name, str(default)))


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


def _env_list(name: str, default: list[str]) -> list[str]:
    raw = os.getenv(name)
    if raw is None:
        return default
    parts = [p.strip() for p in raw.replace("|", ",").split(",")]
    return [p for p in parts if p]


def _env_signal(name: str, default: int) -> int:
    raw = os.getenv(name)
    if not raw:
        return default
    raw = raw.strip().upper()
    if raw.isdigit():
        return int(raw)
    if not raw.startswith("SIG"):
        raw = f"SIG{raw}"
    return int(getattr(signal, raw, default))


def load_env_file(path: str, override: bool = False) -> None:
    file_path = Path(path).expanduser()
    if not file_path.exists():
        return
    for raw in file_path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and (override or key not in os.environ):
            os.environ[key] = value


def load_env_from_args(argv: list[str]) -> None:
    path = None
    override = False
    if "--config" in argv:
        idx = argv.index("--config")
        if idx + 1 >= len(argv):
            raise SystemExit("--config requires a path")
        path = argv[idx + 1]
        override = True
    if not path:
        path = os.getenv("CLAUDE_AUDIO_ENV") or ".env"
    load_env_file(path, override=override)


@dataclass(frozen=True)
class AudioConfig:
    sample_rate: int
    blocksize: int
    queue_ms: int
    input_device: str | None
    mic_gain: float


@dataclass(frozen=True)
class VadSettings:
    enabled: bool
    mode: int
    threshold: float
    preroll_ms: int
    hold_ms: int
    noise_ms: int
    noise_multiplier: float
    no_speech_timeout: float
    max_utterance_sec: float


@dataclass(frozen=True)
class SttConfig:
    api_key: str
    model: str
    language: str
    sample_rate: int
    codec: str
    streaming: bool
    streaming_max_wait_ms: int
    high_vad: bool
    partial_stability_ms: int
    prefetch_enabled: bool


@dataclass(frozen=True)
class TtsConfig:
    api_key: str
    model_id: str
    voice_id: str
    speed: str
    sample_rate: int
    barge_in: bool
    ws_enabled: bool
    ws_keepalive_sec: int
    context_cancel_ms: int
    ws_version: str


@dataclass(frozen=True)
class WakewordConfig:
    enabled: bool
    phrases: list[str]
    engine: str
    threshold: float
    model_paths: list[str]
    frame_ms: int
    cooldown_ms: int


@dataclass(frozen=True)
class InterruptConfig:
    enabled: bool
    signal: int
    pid: int | None
    pid_file: str | None
    command: str | None
    cooldown_ms: int
    kill_timeout_ms: int


@dataclass(frozen=True)
class RunnerConfig:
    enabled: bool
    cmd: str
    prompt_timeout_ms: int
    kill_timeout_ms: int


@dataclass(frozen=True)
class DaemonConfig:
    socket: str
    status_path: str
    pid_path: str
    interrupt_path: str


@dataclass(frozen=True)
class Config:
    audio: AudioConfig
    vad: VadSettings
    stt: SttConfig
    tts: TtsConfig
    wake: WakewordConfig
    interrupt: InterruptConfig
    runner: RunnerConfig
    daemon: DaemonConfig


def load_config() -> Config:
    api_key = os.getenv("SARVAM_API_KEY", "").strip()
    if not api_key:
        raise SystemExit("SARVAM_API_KEY is required")

    return Config(
        audio=AudioConfig(
            sample_rate=_env_int("SARVAM_STT_SAMPLE_RATE", 16000),
            blocksize=_env_int("AUDIO_BLOCKSIZE", 320),
            queue_ms=_env_int("AUDIO_QUEUE_MS", 2000),
            input_device=os.getenv("SARVAM_INPUT_DEVICE") or None,
            mic_gain=_env_float("MIC_GAIN", 1.0),
        ),
        vad=VadSettings(
            enabled=_env_bool("LOCAL_VAD", True),
            mode=_env_int("LOCAL_VAD_MODE", 2),
            threshold=_env_float("LOCAL_VAD_THRESHOLD", 0.003),
            preroll_ms=_env_int("LOCAL_VAD_PREROLL_MS", 500),
            hold_ms=_env_int("LOCAL_VAD_HOLD_MS", 800),
            noise_ms=_env_int("LOCAL_VAD_NOISE_MS", 100),
            noise_multiplier=_env_float("LOCAL_VAD_MULTIPLIER", 3.0),
            no_speech_timeout=_env_float("NO_SPEECH_TIMEOUT", 300.0),
            max_utterance_sec=_env_float("MAX_UTTERANCE_SEC", 20.0),
        ),
        stt=SttConfig(
            api_key=api_key,
            model=_env_str("SARVAM_STT_MODEL", "saaras:v3"),
            language=_env_str("SARVAM_STT_LANGUAGE", "en-IN"),
            sample_rate=_env_int("SARVAM_STT_SAMPLE_RATE", 16000),
            codec=_env_str("SARVAM_STT_CODEC", "pcm_s16le").lower(),
            streaming=_env_bool("SARVAM_STT_STREAMING", True),
            streaming_max_wait_ms=_env_int("SARVAM_STT_STREAMING_MAX_WAIT_MS", 1500),
            high_vad=_env_bool("SARVAM_STT_HIGH_VAD", True),
            partial_stability_ms=_env_int("STT_PARTIAL_STABILITY_MS", 300),
            prefetch_enabled=_env_bool("STT_PREFETCH_ENABLED", True),
        ),
        tts=TtsConfig(
            api_key=_env_str("CARTESIA_API_KEY", ""),
            model_id=_env_str("TTS_MODEL", "sonic-2"),
            voice_id=_env_str("CARTESIA_VOICE_ID", "e07c00bc-4134-4eae-9ea4-1a55fb45746b"),
            speed=_env_str("TTS_SPEED", "fast"),
            sample_rate=_env_int("TTS_SAMPLE_RATE", 24000),
            barge_in=_env_bool("TTS_BARGE_IN", True),
            ws_enabled=_env_bool("TTS_WS_ENABLED", False),
            ws_keepalive_sec=_env_int("TTS_WS_KEEPALIVE_SEC", 30),
            context_cancel_ms=_env_int("TTS_CONTEXT_CANCEL_MS", 200),
            ws_version=_env_str("TTS_WS_VERSION", "2024-11-13"),
        ),
        wake=WakewordConfig(
            enabled=_env_bool("WAKEWORD_ENABLED", True),
            phrases=_env_list("WAKEWORD_PHRASES", ["hey claude"]),
            engine=_env_str("WAKEWORD_ENGINE", "openwakeword"),
            threshold=_env_float("WAKEWORD_THRESHOLD", 0.5),
            model_paths=_env_list("WAKEWORD_MODEL_PATHS", []),
            frame_ms=_env_int("WAKEWORD_FRAME_MS", 80),
            cooldown_ms=_env_int("WAKEWORD_COOLDOWN_MS", 1000),
        ),
        interrupt=InterruptConfig(
            enabled=_env_bool("INTERRUPT_ENABLED", True),
            signal=_env_signal("INTERRUPT_SIGNAL", int(signal.SIGINT)),
            pid=_env_int("INTERRUPT_PID", 0) or None,
            pid_file=_env_str("INTERRUPT_PID_FILE", runtime_path("target_pid")),
            command=_env_str("INTERRUPT_COMMAND", "") or None,
            cooldown_ms=_env_int("INTERRUPT_COOLDOWN_MS", 300),
            kill_timeout_ms=_env_int("INTERRUPT_KILL_TIMEOUT_MS", 400),
        ),
        runner=RunnerConfig(
            enabled=_env_bool("RUNNER_ENABLED", True),
            cmd=_env_str("RUNNER_CMD", "claude"),
            prompt_timeout_ms=_env_int("RUNNER_PROMPT_TIMEOUT_MS", 8000),
            kill_timeout_ms=_env_int("INTERRUPT_KILL_TIMEOUT_MS", 400),
        ),
        daemon=DaemonConfig(
            socket=socket_path(),
            status_path=runtime_path("status"),
            pid_path=runtime_path("pid"),
            interrupt_path=runtime_path("voice_interrupt"),
        ),
    )


def load_tts_config() -> TtsConfig:
    return TtsConfig(
        api_key=_env_str("CARTESIA_API_KEY", ""),
        model_id=_env_str("TTS_MODEL", "sonic-2"),
        voice_id=_env_str("CARTESIA_VOICE_ID", "e07c00bc-4134-4eae-9ea4-1a55fb45746b"),
        speed=_env_str("TTS_SPEED", "fast"),
        sample_rate=_env_int("TTS_SAMPLE_RATE", 24000),
        barge_in=_env_bool("TTS_BARGE_IN", True),
        ws_enabled=_env_bool("TTS_WS_ENABLED", False),
        ws_keepalive_sec=_env_int("TTS_WS_KEEPALIVE_SEC", 30),
        context_cancel_ms=_env_int("TTS_CONTEXT_CANCEL_MS", 200),
        ws_version=_env_str("TTS_WS_VERSION", "2024-11-13"),
    )
