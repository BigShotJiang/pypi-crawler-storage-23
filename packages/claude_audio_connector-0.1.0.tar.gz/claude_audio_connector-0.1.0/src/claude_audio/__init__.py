"""Core package for low-latency Claude voice."""
