# zena/errors/__init__.py
"""Project-specific exception types."""


class QSysError(Exception):
    """Base class for zena errors."""

    pass


class ValidationError(QSysError):
    """Raised for invalid user input (indices, arity, params)."""

    pass


class TranspileError(QSysError):
    """Raised by transpiler passes."""

    pass


class BackendError(QSysError):
    """Raised by backends when they fail."""

    pass


class ExecutionError(QSysError):
    """Raised by the runtime/engine during execution."""

    pass
