"""Result module for quantum computation results.

Matches Qiskit's ``qiskit/result/`` structure.
"""
from ..providers.result import Result

__all__ = ["Result"]
