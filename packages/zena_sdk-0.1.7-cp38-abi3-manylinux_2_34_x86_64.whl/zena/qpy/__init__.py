"""
QPY serialization for Zena quantum circuits.

Save and load QuantumCircuit objects to/from binary files,
matching IBM Qiskit's ``qpy.dump`` / ``qpy.load`` API.

Usage::

    from zena import qpy

    # Save a circuit
    with open("my_circuit.qpy", "wb") as f:
        qpy.dump(qc, f)

    # Save multiple circuits
    with open("circuits.qpy", "wb") as f:
        qpy.dump([qc1, qc2], f)

    # Load circuits (always returns a list)
    with open("my_circuit.qpy", "rb") as f:
        circuits = qpy.load(f)
    qc = circuits[0]

The binary format (ZPY v1) stores:

    Header (magic + version + circuit count)
    For each circuit:
        Circuit header (n_qubits, n_clbits, name length, instruction count)
        Register info
        Instructions (gate name, qubit indices, params)
"""

from __future__ import annotations

import io
import json
import struct
from typing import BinaryIO, List, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from ..circuit.quantum_circuit import QuantumCircuit

__all__ = ["dump", "load"]

# ─── Binary format constants ────────────────────────────────────────
MAGIC = b"ZENAPY"          # 6 bytes
FORMAT_VERSION = 1          # uint16
# Header: MAGIC(6) + version(2) + num_circuits(4) = 12 bytes
HEADER_FMT = "<6sHI"       # magic, version, num_circuits
HEADER_SIZE = struct.calcsize(HEADER_FMT)

# Per-circuit header:
# n_qubits(4) + n_clbits(4) + name_len(2) + num_regs(2) + num_instructions(4) = 16 bytes
CIRCUIT_HEADER_FMT = "<IIHHI"
CIRCUIT_HEADER_SIZE = struct.calcsize(CIRCUIT_HEADER_FMT)

# Register entry: type(1,'q'/'c') + size(4) + name_len(2)
REG_HEADER_FMT = "<cIH"
REG_HEADER_SIZE = struct.calcsize(REG_HEADER_FMT)

# Instruction entry:
# name_len(2) + num_qubits(2) + num_clbits(2) + num_params(2)
INST_HEADER_FMT = "<HHHH"
INST_HEADER_SIZE = struct.calcsize(INST_HEADER_FMT)

# Param types
PARAM_FLOAT = 0     # 8-byte double
PARAM_PARAMETER = 1 # named symbolic parameter (length-prefixed string)
PARAM_EXPR = 2      # parameter expression (JSON-serialized)


def dump(
    circuits: Union["QuantumCircuit", List["QuantumCircuit"]],
    file: BinaryIO,
) -> None:
    """
    Serialize one or more QuantumCircuit objects to a binary file.

    Args:
        circuits: A single QuantumCircuit or a list of QuantumCircuits.
        file: A writable binary file object (opened with ``"wb"``).

    Example::

        from zena import QuantumCircuit, qpy

        qc = QuantumCircuit(2)
        qc.h(0)
        qc.cx(0, 1)

        with open("bell.qpy", "wb") as f:
            qpy.dump(qc, f)
    """
    from ..circuit.quantum_circuit import QuantumCircuit as QC

    if isinstance(circuits, QC):
        circuits = [circuits]

    # Write file header
    file.write(struct.pack(HEADER_FMT, MAGIC, FORMAT_VERSION, len(circuits)))

    for qc in circuits:
        _dump_circuit(qc, file)


def load(file: BinaryIO) -> List["QuantumCircuit"]:
    """
    Deserialize QuantumCircuit objects from a binary file.

    Always returns a **list** of circuits, even if only one was saved.

    Args:
        file: A readable binary file object (opened with ``"rb"``).

    Returns:
        List[QuantumCircuit]: The deserialized circuits.

    Example::

        from zena import qpy

        with open("bell.qpy", "rb") as f:
            circuits = qpy.load(f)
        qc = circuits[0]
        print(qc.draw())
    """
    # Read file header
    header_data = file.read(HEADER_SIZE)
    if len(header_data) < HEADER_SIZE:
        raise ValueError("Truncated QPY file: header too short")
    magic, version, num_circuits = struct.unpack(HEADER_FMT, header_data)

    if magic != MAGIC:
        raise ValueError(
            f"Not a Zena QPY file. Expected magic {MAGIC!r}, got {magic!r}"
        )
    if version > FORMAT_VERSION:
        raise ValueError(
            f"QPY version {version} is not supported. "
            f"Maximum supported version is {FORMAT_VERSION}."
        )

    circuits = []
    for _ in range(num_circuits):
        circuits.append(_load_circuit(file))

    return circuits


# ─── Internal serialization ─────────────────────────────────────────

def _dump_circuit(qc: "QuantumCircuit", file: BinaryIO) -> None:
    """Serialize a single circuit."""
    from ..circuit.parameter import Parameter, ParameterExpression

    name_bytes = (qc.name or "").encode("utf-8")

    # Collect registers
    regs = []
    for qreg in qc.qregs:
        regs.append((b"q", qreg.size, qreg.name))
    for creg in qc.cregs:
        regs.append((b"c", creg.size, creg.name))

    # Circuit header
    file.write(struct.pack(
        CIRCUIT_HEADER_FMT,
        qc.n_qubits,
        qc.n_clbits,
        len(name_bytes),
        len(regs),
        len(qc._instructions),
    ))

    # Circuit name
    file.write(name_bytes)

    # Registers
    for reg_type, reg_size, reg_name in regs:
        rname_bytes = reg_name.encode("utf-8")
        file.write(struct.pack(REG_HEADER_FMT, reg_type, reg_size, len(rname_bytes)))
        file.write(rname_bytes)

    # Instructions
    for inst in qc._instructions:
        _dump_instruction(inst, file)


def _dump_instruction(inst, file: BinaryIO) -> None:
    """Serialize a single instruction."""
    from ..circuit.parameter import Parameter, ParameterExpression

    name_bytes = inst.name.encode("utf-8")
    qubits = inst.qubits or ()
    clbits = getattr(inst, "clbits", None) or ()
    params = getattr(inst, "params", None) or ()

    file.write(struct.pack(
        INST_HEADER_FMT,
        len(name_bytes),
        len(qubits),
        len(clbits),
        len(params),
    ))

    # Gate name
    file.write(name_bytes)

    # Qubit indices (each uint32)
    for q in qubits:
        file.write(struct.pack("<I", q))

    # Clbit indices (each uint32)
    for c in clbits:
        file.write(struct.pack("<I", c))

    # Parameters
    for p in params:
        if isinstance(p, Parameter):
            # Symbolic parameter: type + name
            pname = p.name.encode("utf-8")
            file.write(struct.pack("<BH", PARAM_PARAMETER, len(pname)))
            file.write(pname)
        elif isinstance(p, ParameterExpression):
            # Expression: serialize as JSON
            expr_data = json.dumps({
                "type": "expr",
                "repr": str(p),
                "params": [pp.name for pp in p.parameters],
            }).encode("utf-8")
            file.write(struct.pack("<BI", PARAM_EXPR, len(expr_data)))
            file.write(expr_data)
        else:
            # Numeric value
            file.write(struct.pack("<Bd", PARAM_FLOAT, float(p)))


def _load_circuit(file: BinaryIO) -> "QuantumCircuit":
    """Deserialize a single circuit."""
    from ..circuit.quantum_circuit import QuantumCircuit
    from ..circuit.register import QuantumRegister, ClassicalRegister
    from ..ir.types import Instruction as IRInstruction

    # Circuit header
    ch_data = file.read(CIRCUIT_HEADER_SIZE)
    if len(ch_data) < CIRCUIT_HEADER_SIZE:
        raise ValueError("Truncated QPY: circuit header too short")
    n_qubits, n_clbits, name_len, num_regs, num_insts = struct.unpack(
        CIRCUIT_HEADER_FMT, ch_data
    )

    # Name
    name = file.read(name_len).decode("utf-8") if name_len > 0 else None

    # Registers
    qregs = []
    cregs = []
    for _ in range(num_regs):
        rh_data = file.read(REG_HEADER_SIZE)
        reg_type, reg_size, rname_len = struct.unpack(REG_HEADER_FMT, rh_data)
        reg_name = file.read(rname_len).decode("utf-8")
        if reg_type == b"q":
            qregs.append(QuantumRegister(reg_size, reg_name))
        else:
            cregs.append(ClassicalRegister(reg_size, reg_name))

    # Build circuit from registers
    if qregs or cregs:
        qc = QuantumCircuit(*qregs, *cregs, name=name)
    else:
        qc = QuantumCircuit(n_qubits, n_clbits, name=name)

    # Instructions
    for _ in range(num_insts):
        inst = _load_instruction(file)
        qc._instructions.append(inst)

    return qc


def _load_instruction(file: BinaryIO):
    """Deserialize a single instruction."""
    from ..circuit.parameter import Parameter
    from ..ir.types import Instruction as IRInstruction

    ih_data = file.read(INST_HEADER_SIZE)
    if len(ih_data) < INST_HEADER_SIZE:
        raise ValueError("Truncated QPY: instruction header too short")
    name_len, num_qubits, num_clbits, num_params = struct.unpack(
        INST_HEADER_FMT, ih_data
    )

    # Name
    gate_name = file.read(name_len).decode("utf-8")

    # Qubits
    qubits = tuple(
        struct.unpack("<I", file.read(4))[0] for _ in range(num_qubits)
    )

    # Clbits
    clbits = tuple(
        struct.unpack("<I", file.read(4))[0] for _ in range(num_clbits)
    ) if num_clbits > 0 else None

    # Params
    params = []
    for _ in range(num_params):
        ptype = struct.unpack("<B", file.read(1))[0]
        if ptype == PARAM_FLOAT:
            val = struct.unpack("<d", file.read(8))[0]
            params.append(val)
        elif ptype == PARAM_PARAMETER:
            pname_len = struct.unpack("<H", file.read(2))[0]
            pname = file.read(pname_len).decode("utf-8")
            params.append(Parameter(pname))
        elif ptype == PARAM_EXPR:
            expr_len = struct.unpack("<I", file.read(4))[0]
            expr_data = json.loads(file.read(expr_len).decode("utf-8"))
            # Reconstruct as a Parameter (simplified)
            if expr_data.get("params"):
                params.append(Parameter(expr_data["params"][0]))
            else:
                params.append(0.0)
        else:
            raise ValueError(f"Unknown parameter type: {ptype}")

    return IRInstruction(
        name=gate_name,
        qubits=qubits,
        clbits=clbits,
        params=tuple(params) if params else (),
    )
