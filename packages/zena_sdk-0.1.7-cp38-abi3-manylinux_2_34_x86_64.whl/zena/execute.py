"""
Execute function - IBM Qiskit compatible.

This module provides the execute() function for running quantum circuits
on backends, following IBM Qiskit's pattern.
"""

from typing import Union, List, Optional
from .circuit.quantum_circuit import QuantumCircuit
from .providers.backend import BackendV2
from .providers.job import Job


def execute(
    experiments: Union[QuantumCircuit, List[QuantumCircuit]],
    backend: Optional[BackendV2] = None,
    shots: int = 1024,
    optimization_level: int = 1,
    **kwargs
) -> Job:
    """
    Execute quantum circuit(s) on a backend (IBM Qiskit compatible).
    
    This function transpiles and executes one or more quantum circuits on
    a specified backend. If no backend is provided, it defaults to the
    statevector simulator.
    
    Args:
        experiments: Single circuit or list of circuits to execute
        backend: Backend to execute on. If None, uses default statevector simulator
        shots: Number of shots for measurement (default: 1024)
        optimization_level: Transpiler optimization level 0-3 (default: 1)
        **kwargs: Additional backend-specific execution options
        
    Returns:
        Job: A job object containing the execution results
        
    Example:
        >>> from zena import QuantumCircuit, execute
        >>> from zena.providers import BasicProvider
        >>> 
        >>> qc = QuantumCircuit(2)
        >>> qc.h(0)
        >>> qc.cx(0, 1)
        >>> qc.measure_all()
        >>> 
        >>> provider = BasicProvider()
        >>> backend = provider.get_backend('statevector_simulator')
        >>> job = execute(qc, backend=backend, shots=1024)
        >>> result = job.result()
        >>> print(result.get_counts())
        
    Note:
        This function is compatible with IBM Qiskit's execute() pattern.
    """
    
    # Import here to avoid circular dependencies
    from .providers.basic_provider import BasicProvider
    from .transpiler import transpile
    
    # Default to statevector simulator if no backend provided
    if backend is None:
        from .providers.aer import Aer
        backend = Aer.get_backend("statevector_simulator")
    
    # Ensure experiments is a list
    is_single = not isinstance(experiments, list)
    if is_single:
        experiments = [experiments]
    
    # Transpile circuits for the backend
    try:
        from .transpiler.passes import PassConfig
        config = PassConfig() # Default config
        
        # Mapping optimization_level to config if needed (simplified for now)
        transpiled_circuits = []
        for qc in experiments:
            t_qc = transpile(qc, backend=backend, config=config)
            transpiled_circuits.append(t_qc)
            
    except Exception as e:
        # Fallback: use circuits as-is if transpile fails
        print(f"Warning: Transpilation failed ({e}). Using circuits as-is.")
        transpiled_circuits = experiments
    
    # Ensure transpiled_circuits is a list
    if not isinstance(transpiled_circuits, list):
        transpiled_circuits = [transpiled_circuits]
    
    # Execute on backend
    # For now, execute single circuit (batch execution enhancement for later)
    if len(transpiled_circuits) > 1:
        # TODO: Implement batch execution properly
        # For now, execute first circuit only
        print("Warning: Batch execution not fully supported yet. Executing first circuit only.")
        circuit = transpiled_circuits[0]
    else:
        circuit = transpiled_circuits[0]
    
    # Run on backend
    job = backend.run(circuit, shots=shots, **kwargs)
    
    return job


def execute_batch(
    experiments: List[QuantumCircuit],
    backend: Optional[BackendV2] = None,
    shots: int = 1024,
    **kwargs
) -> List[Job]:
    """
    Execute multiple circuits as separate jobs.
    
    This is a convenience function for executing multiple circuits
    when you want separate job objects for each.
    
    Args:
        experiments: List of circuits to execute
        backend: Backend to execute on
        shots: Number of shots per circuit
        **kwargs: Additional execution options
        
    Returns:
        List of Job objects, one per circuit
    """
    jobs = []
    for circuit in experiments:
        job = execute(circuit, backend=backend, shots=shots, **kwargs)
        jobs.append(job)
    return jobs
