"""
Statevector-based Estimator primitive.

Computes exact expectation values of observables (SparsePauliOp)
against quantum circuits, matching Qiskit's ``StatevectorEstimator``
interface.

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/specify-observables-pauli

Example::

    from zena.circuit import QuantumCircuit
    from zena.quantum_info import SparsePauliOp
    from zena.primitives import StatevectorEstimator

    qc = QuantumCircuit(2)
    qc.h(0)
    qc.cx(0, 1)

    obs = SparsePauliOp.from_list([("ZZ", 1.0), ("XX", 0.5)])
    estimator = StatevectorEstimator()
    result = estimator.run([(qc, obs)])
    print(result[0].data.evs)
"""

from __future__ import annotations

import numpy as np
from typing import List, Sequence, Tuple, Union, Optional


class EstimatorResult:
    """Container for a single estimation result.

    Attributes:
        data: Object containing the expectation values.
        metadata: Dict of additional information.
    """

    def __init__(self, evs, stds=None, metadata=None):
        self.data = _EstimatorData(evs, stds)
        self.metadata = metadata or {}


class _EstimatorData:
    """Internal data holder for EstimatorResult."""

    def __init__(self, evs, stds=None):
        self.evs = np.atleast_1d(np.asarray(evs, dtype=float))
        if stds is not None:
            self.stds = np.atleast_1d(np.asarray(stds, dtype=float))
        else:
            self.stds = np.zeros_like(self.evs)


class StatevectorEstimator:
    """Exact statevector-based estimator of expectation values.

    This is a local, noiseless estimator that computes
    ``<ψ|O|ψ>`` exactly via statevector simulation.

    It matches the interface of Qiskit's ``StatevectorEstimator``.

    Example::

        from zena.circuit import QuantumCircuit
        from zena.quantum_info import SparsePauliOp
        from zena.primitives import StatevectorEstimator

        qc = QuantumCircuit(2)
        qc.h(0)
        qc.cx(0, 1)

        H = SparsePauliOp.from_list([("ZZ", 1), ("XX", 0.5)])
        estimator = StatevectorEstimator()
        result = estimator.run([(qc, H)])
        print(result[0].data.evs)   # expectation value
    """

    def run(
        self,
        pubs: Sequence[Tuple],
        precision: Optional[float] = None,
    ) -> List[EstimatorResult]:
        """Run estimation for one or more PUBs (Primitive Unified Blocs).

        Each PUB is a tuple of ``(circuit, observable)`` or
        ``(circuit, observable, parameter_values)``.

        Args:
            pubs: List of (circuit, observable[, params]) tuples.
            precision: Not used for statevector (exact).

        Returns:
            List[EstimatorResult]: One result per PUB.
        """
        results = []
        for pub in pubs:
            if len(pub) == 2:
                circuit, observable = pub
            elif len(pub) == 3:
                circuit, observable, _params = pub
            else:
                raise ValueError(f"PUB must have 2 or 3 elements, got {len(pub)}")

            ev = self._compute_expectation(circuit, observable)
            results.append(EstimatorResult(evs=ev, stds=0.0))

        return results

    def _compute_expectation(self, circuit, observable) -> float:
        """Compute <ψ|O|ψ> exactly.

        Args:
            circuit: A QuantumCircuit.
            observable: A SparsePauliOp.

        Returns:
            float: The expectation value.
        """
        from zena.quantum_info import Operator

        # Get the statevector by simulating the circuit
        statevector = self._get_statevector(circuit)

        # Compute <ψ|O|ψ> = ψ† @ O_matrix @ ψ
        O_matrix = observable.to_matrix()
        ev = (statevector.conj() @ O_matrix @ statevector).real

        return float(ev)

    def _get_statevector(self, circuit) -> np.ndarray:
        """Simulate a circuit and return the statevector.

        Uses the circuit's operator representation to compute
        U|0⟩.
        """
        from zena.quantum_info import Operator

        n = circuit.n_qubits
        # |0...0⟩
        state = np.zeros(2**n, dtype=complex)
        state[0] = 1.0

        # Apply unitary
        U = Operator(circuit).data
        return U @ state


__all__ = ["StatevectorEstimator", "EstimatorResult"]
