"""Primitives module for Sampler and Estimator.

Matches Qiskit's ``qiskit/primitives/`` structure.

Classes:
    StatevectorEstimator  - Exact statevector-based expectation values
    EstimatorResult       - Container for estimation results

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/specify-observables-pauli
"""

from .estimator import StatevectorEstimator, EstimatorResult

__all__ = ["StatevectorEstimator", "EstimatorResult"]
