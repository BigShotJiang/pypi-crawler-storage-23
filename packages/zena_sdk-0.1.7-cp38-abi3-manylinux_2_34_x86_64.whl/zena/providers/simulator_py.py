import numpy as np
import random
from typing import List, Dict, Any, Optional

class PyStatevectorSimulator:
    def __init__(self, n_qubits: int, seed: Optional[int] = None):
        if n_qubits > 20: 
            raise ValueError(f"Too many qubits for Python simulator: {n_qubits}")
        self.n_qubits = n_qubits
        self.size = 1 << n_qubits
        self.state = np.zeros(self.size, dtype=np.complex128)
        self.state[0] = 1.0 + 0.0j
        
        self.seed = seed
        if seed is not None:
            np.random.seed(seed)
        
        # Precompute index array for vectorization fallback
        self._all = np.arange(self.size, dtype=np.int32)

    def measure(self, shots: int) -> Dict[str, int]:
        probs = np.abs(self.state)**2
        total = np.sum(probs)
        if total > 0: probs /= total
        
        counts = {}
        if shots > 0:
            indices = np.random.choice(self.size, size=shots, p=probs)
            for idx in indices:
                # Big Endian (q_n-1 ... q0)
                b_str = format(idx, f'0{self.n_qubits}b')
                counts[b_str] = counts.get(b_str, 0) + 1
        return counts

    # --- Gates (Loop Implementation for Small N Accuracy) ---

    def x(self, q: int):
        mask = 1 << q
        # Use loop for safety
        for i in range(self.size):
            if (i & mask) == 0:
                j = i | mask
                self.state[i], self.state[j] = self.state[j], self.state[i]

    def y(self, q: int):
        mask = 1 << q
        for i in range(self.size):
            if (i & mask) == 0:
                j = i | mask
                ai = self.state[i]
                aj = self.state[j]
                self.state[i] = -1j * aj
                self.state[j] = 1j * ai

    def z(self, q: int):
        # Diagonal - fast vectorization safe
        mask = 1 << q
        indices = (self._all & mask) != 0
        self.state[indices] *= -1.0

    def h(self, q: int):
        mask = 1 << q
        s = 1.0 / np.sqrt(2)
        for i in range(self.size):
            if (i & mask) == 0:
                j = i | mask
                a = self.state[i]
                b = self.state[j]
                self.state[i] = (a + b) * s
                self.state[j] = (a - b) * s

    def cx(self, c: int, t: int):
        if c == t: raise ValueError("c==t")
        cmask = 1 << c
        tmask = 1 << t
        for i in range(self.size):
            if (i & cmask) != 0 and (i & tmask) == 0:
                j = i | tmask
                self.state[i], self.state[j] = self.state[j], self.state[i]

    def cy(self, c: int, t: int):
        cmask = 1 << c
        tmask = 1 << t
        for i in range(self.size):
            if (i & cmask) != 0 and (i & tmask) == 0:
                j = i | tmask
                ai = self.state[i]
                aj = self.state[j]
                self.state[i] = -1j * aj
                self.state[j] = 1j * ai

    def cz(self, c: int, t: int):
        mask = (1 << c) | (1 << t)
        indices = (self._all & mask) == mask
        self.state[indices] *= -1.0

    def cp(self, c: int, t: int, theta: float):
        mask = (1 << c) | (1 << t)
        indices = (self._all & mask) == mask
        self.state[indices] *= np.exp(1j * theta)
        
    def ccx(self, c1: int, c2: int, t: int):
        mask = (1 << c1) | (1 << c2)
        tmask = 1 << t
        for i in range(self.size):
            if (i & mask) == mask and (i & tmask) == 0:
                j = i | tmask
                self.state[i], self.state[j] = self.state[j], self.state[i]

    def swap(self, q1: int, q2: int):
        if q1 == q2: return
        m1, m2 = 1<<q1, 1<<q2
        for i in range(self.size):
            # Swap if bits differ: (i&m1)==0 and (i&m2)!=0
            if (i & m1) == 0 and (i & m2) != 0:
                j = i ^ (m1 | m2)
                self.state[i], self.state[j] = self.state[j], self.state[i]

    # --- Parameterized Gates (Vectorized/Matrix OK) ---
    # RX/RY use local 2x2 mixing.
    def rx(self, q: int, theta: float):
        # We can use loop to be consistent
        mask = 1 << q
        c = np.cos(theta/2)
        s = np.sin(theta/2)
        u00, u01 = c, -1j*s
        u10, u11 = -1j*s, c
        for i in range(self.size):
            if (i & mask) == 0:
                j = i | mask
                ai = self.state[i]
                aj = self.state[j]
                self.state[i] = u00*ai + u01*aj
                self.state[j] = u10*ai + u11*aj

    def ry(self, q: int, theta: float):
        mask = 1 << q
        c = np.cos(theta/2)
        s = np.sin(theta/2)
        u00, u01 = c, -s
        u10, u11 = s, c
        for i in range(self.size):
            if (i & mask) == 0:
                j = i | mask
                ai = self.state[i]
                aj = self.state[j]
                self.state[i] = u00*ai + u01*aj
                self.state[j] = u10*ai + u11*aj

    def sx(self, q: int):
        mask = 1 << q
        u00 = 0.5 * (1+1j)
        u01 = 0.5 * (1-1j)
        u10 = u01
        u11 = u00
        for i in range(self.size):
            if (i & mask) == 0:
                j = i | mask
                ai = self.state[i]
                aj = self.state[j]
                self.state[i] = u00*ai + u01*aj
                self.state[j] = u10*ai + u11*aj

    # --- Phase Gates ---
    def s(self, q: int):
        self._phase(q, 1j)
    def sdg(self, q: int):
        self._phase(q, -1j)
    def t(self, q: int):
        self._phase(q, np.exp(1j * np.pi / 4))
    def tdg(self, q: int):
        self._phase(q, np.exp(-1j * np.pi / 4))
    def rz(self, q: int, theta: float):
        self._phase_diag(q, np.exp(-0.5j * theta), np.exp(0.5j * theta))
        
    def _phase(self, q: int, p1: complex):
        mask = 1 << q
        indices = (self._all & mask) != 0
        self.state[indices] *= p1

    def _phase_diag(self, q: int, p0: complex, p1: complex):
        mask = 1 << q
        idx0 = (self._all & mask) == 0
        idx1 = (self._all & mask) != 0
        self.state[idx0] *= p0
        self.state[idx1] *= p1
