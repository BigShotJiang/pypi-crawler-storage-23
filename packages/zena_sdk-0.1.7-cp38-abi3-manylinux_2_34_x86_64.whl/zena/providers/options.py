"""
Options class for configuring backend execution parameters.

Following IBM Qiskit's Options pattern.
"""

from typing import Any, Dict, Callable, Tuple, Optional


class Options:
    """
    Options class for backend execution configuration.
    
    This class allows backends to define user-configurable options
    with validation and default values, following IBM Qiskit's pattern.
    
    Example:
        >>> options = Options(shots=1024, memory=False)
        >>> options.shots = 2048
        >>> options.set_validator("shots", (1, 4096))
    """
    
    def __init__(self, **kwargs):
        """
        Initialize options with keyword arguments.
        
        Args:
            **kwargs: Option names and their default values
        """
        self._data = {}
        self._validators = {}
        
        for key, value in kwargs.items():
            self._data[key] = value
    
    def __getattr__(self, name: str) -> Any:
        """Get an option value."""
        if name.startswith('_'):
            return object.__getattribute__(self, name)
        
        if name in self._data:
            return self._data[name]
        raise AttributeError(f"Options object has no attribute '{name}'")
    
    def __setattr__(self, name: str, value: Any):
        """Set an option value with validation."""
        if name.startswith('_'):
            object.__setattr__(self, name, value)
            return
        
        # Validate if validator exists
        if name in self._validators:
            validator = self._validators[name]
            if not self._validate(value, validator):
                raise ValueError(
                    f"Invalid value {value} for option '{name}'. "
                    f"Must satisfy: {validator}"
                )
        
        self._data[name] = value
    
    def _validate(self, value: Any, validator: Any) -> bool:
        """
        Validate a value against a validator.
        
        Args:
            value: Value to validate
            validator: Can be a tuple (min, max), a type, or a callable
            
        Returns:
            True if valid, False otherwise
        """
        if isinstance(validator, tuple) and len(validator) == 2:
            # Range validator (min, max)
            min_val, max_val = validator
            return min_val <= value <= max_val
        elif isinstance(validator, type):
            # Type validator
            return isinstance(value, validator)
        elif callable(validator):
            # Custom callable validator
            return validator(value)
        return True
    
    def set_validator(self, name: str, validator: Any):
        """
        Set a validator for an option.
        
        Args:
            name: Option name
            validator: Tuple (min, max), type, or callable validator
            
        Example:
            >>> options.set_validator("shots", (1, 4096))
            >>> options.set_validator("memory", bool)
        """
        self._validators[name] = validator
    
    def get(self, name: str, default: Any = None) -> Any:
        """
        Get an option value with a default.
        
        Args:
            name: Option name
            default: Default value if option doesn't exist
            
        Returns:
            Option value or default
        """
        return self._data.get(name, default)
    
    def update_options(self, **kwargs):
        """
        Update multiple options at once.
        
        Args:
            **kwargs: Options to update
        """
        for key, value in kwargs.items():
            setattr(self, key, value)
    
    def __repr__(self) -> str:
        """String representation of options."""
        items = ', '.join(f'{k}={v!r}' for k, v in self._data.items())
        return f"Options({items})"
