"""
Job status enumeration and Job classes.

Following IBM Qiskit's Job interface.
"""

from enum import Enum
from abc import ABC, abstractmethod
from typing import Any, Optional
from .exceptions import JobError


class JobStatus(Enum):
    """Enumeration of job states following IBM Qiskit."""
    
    INITIALIZING = "job is being initialized"
    QUEUED = "job is queued"
    VALIDATING = "job is being validated"
    RUNNING = "job is actively running"
    CANCELLED = "job has been cancelled"
    DONE = "job has successfully run"
    ERROR = "job has failed"
    
    def __repr__(self):
        return f"<JobStatus.{self.name}: '{self.value}'>"


class Job(ABC):
    """
    Abstract base class for jobs.
    
    This is the abstract interface for jobs returned from backend.run().
    Follows IBM Qiskit's Job pattern.
    """
    
    def __init__(self, backend, job_id: str):
        """
        Initialize a Job.
        
        Args:
            backend: Backend that executes this job
            job_id: Unique identifier for this job
        """
        self._backend = backend
        self._job_id = job_id
    
    @abstractmethod
    def result(self, timeout: Optional[float] = None):
        """
        Return the result of the job.
        
        Args:
            timeout: Maximum time to wait for result in seconds
            
        Returns:
            Result object
            
        Raises:
            JobError: If the job failed
            JobTimeoutError: If timeout is reached
        """
        pass
    
    @abstractmethod
    def status(self) -> JobStatus:
        """
        Return the status of the job.
        
        Returns:
            Current job status
        """
        pass
    
    @abstractmethod
    def submit(self):
        """Submit the job to the backend for execution."""
        pass
    
    def backend(self):
        """Return the backend where this job was executed."""
        return self._backend
    
    def job_id(self) -> str:
        """Return the unique job ID."""
        return self._job_id
    
    def cancel(self):
        """
        Attempt to cancel the job.
        
        Returns:
            True if cancellation was successful, False otherwise
        """
        return False


class JobV1(Job):
    """
    Concrete implementation of Job interface (Version 1).
    
    This is a synchronous job implementation suitable for local simulators.
    Follows IBM Qiskit's JobV1 pattern.
    """
    
    def __init__(self, backend, job_id: str, result_data: Optional[Any] = None):
        """
        Initialize a JobV1.
        
        Args:
            backend: Backend that executes this job
            job_id: Unique identifier for this job
            result_data: Pre-computed result data (for synchronous execution)
        """
        super().__init__(backend, job_id)
        self._result_data = result_data
        self._status = JobStatus.INITIALIZING
        
        if result_data is not None:
            self._status = JobStatus.DONE
    
    def submit(self):
        """
        Submit the job.
        
        For synchronous execution, this is a no-op since
        the job is already complete upon creation.
        """
        if self._status == JobStatus.INITIALIZING:
            self._status = JobStatus.QUEUED
    
    def result(self, timeout: Optional[float] = None):
        """
        Return the result of the job.
        
        For synchronous jobs, the result is immediately available.
        
        Args:
            timeout: Ignored for synchronous jobs
            
        Returns:
            Result object
            
        Raises:
            JobError: If the job failed
        """
        if self._status == JobStatus.ERROR:
            raise JobError("Job execution failed")
        
        return self._result_data
    
    def status(self) -> JobStatus:
        """Return the current status of the job."""
        return self._status
    
    def _set_status(self, status: JobStatus):
        """Internal method to update job status."""
        self._status = status
    
    def _set_result(self, result_data: Any):
        """Internal method to set result data."""
        self._result_data = result_data
        self._status = JobStatus.DONE
