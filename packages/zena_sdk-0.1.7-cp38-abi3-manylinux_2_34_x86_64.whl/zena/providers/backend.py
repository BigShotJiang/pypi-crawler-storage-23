"""
Backend abstract base classes following IBM Qiskit's BackendV2 interface.
"""

from abc import ABC, abstractmethod
from typing import Optional, Union, List
from .options import Options
from .job import Job


class Backend(ABC):
    """
    Abstract base class for backends (legacy interface).
    
    This is the legacy backend interface. New backends should use BackendV2.
    """
    
    @abstractmethod
    def run(self, circuit, **kwargs):
        """
        Run a circuit on the backend.
        
        Args:
            circuit: Quantum circuit to execute
            **kwargs: Additional execution options
            
        Returns:
            Job object
        """
        pass
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Backend name."""
        pass


class BackendV2(ABC):
    """
    Abstract base class for backends (Version 2).
    
    This is the current standard backend interface following IBM Qiskit's
    BackendV2 architecture. All new backends should inherit from this class.
    
    Required attributes and methods:
        - target: Property providing Target object for transpiler
        - max_circuits: Property defining max circuits per batch
        - run(): Method to execute circuits
        - _default_options(): Class method to define default options
    
    Example:
        >>> class MyBackend(BackendV2):
        ...     @property
        ...     def target(self):
        ...         return self._target
        ...     
        ...     @property
        ...     def max_circuits(self):
        ...         return 100
        ...     
        ...     @classmethod
        ...     def _default_options(cls):
        ...         return Options(shots=1024)
        ...     
        ...     def run(self, circuits, **kwargs):
        ...         # Execute circuits
        ...         return job
    """
    
    def __init__(self, name: Optional[str] = None, description: Optional[str] = None,
                 online_date: Optional[str] = None, backend_version: Optional[str] = None):
        """
        Initialize a BackendV2.
        
        Args:
            name: Backend name
            description: Backend description
            online_date: Date backend came online
            backend_version: Backend version string
        """
        self._name = name
        self._description = description
        self._online_date = online_date
        self._backend_version = backend_version or "1.0.0"
        
        # Initialize options using _default_options()
        self._options = self._default_options()
    
    @property
    @abstractmethod
    def target(self):
        """
        A Target object for the backend.
        
        Returns:
            Target: Backend target providing instruction set,
                   coupling map, and timing information
        """
        pass
    
    @property
    @abstractmethod
    def max_circuits(self) -> Optional[int]:
        """
        Maximum number of circuits the backend can handle in a single job.
        
        Returns:
            int or None: Maximum circuits per job, or None if unlimited
        """
        pass
    
    @classmethod
    @abstractmethod
    def _default_options(cls) -> Options:
        """
        Return default options for the backend.
        
        This class method should return an Options instance with
        default values for all user-configurable parameters.
        
        Returns:
            Options: Default backend options
            
        Example:
            >>> @classmethod
            >>> def _default_options(cls):
            ...     return Options(shots=1024, memory=False)
        """
        pass
    
    @abstractmethod
    def run(self, circuits, **kwargs) -> Job:
        """
        Execute a circuit or list of circuits on the backend.
        
        Args:
            circuits: QuantumCircuit or list of QuantumCircuit objects
            **kwargs: Additional run options (overrides defaults)
            
        Returns:
            Job: Job object for tracking execution
            
        Example:
            >>> job = backend.run(circuit, shots=2048)
            >>> result = job.result()
        """
        pass
    
    @property
    def name(self) -> str:
        """Backend name."""
        return self._name or self.__class__.__name__
    
    @property
    def description(self) -> str:
        """Backend description."""
        return self._description or ""
    
    @property
    def online_date(self) -> Optional[str]:
        """Date the backend came online."""
        return self._online_date
    
    @property
    def backend_version(self) -> str:
        """Backend version."""
        return self._backend_version
    
    @property
    def options(self) -> Options:
        """
        Return the current options for the backend.
        
        Users can modify these options:
            >>> backend.options.shots = 2048
        """
        return self._options
    
    def set_options(self, **fields):
        """
        Set the options for the backend.
        
        Args:
            **fields: Options to update
            
        Example:
            >>> backend.set_options(shots=2048, memory=True)
        """
        self._options.update_options(**fields)
    
    def __repr__(self) -> str:
        """String representation of the backend."""
        return f"<{self.__class__.__name__}('{self.name}')>"
