"""
Qiskit-compatible provider interface for ZENA quantum backends.

This module provides the provider infrastructure for managing and accessing
quantum backends, following IBM Qiskit's BackendV2 architecture.
"""

from .backend import Backend, BackendV2
from .job import Job, JobV1, JobStatus
from .options import Options
from .result import Result, ExperimentResult
from .exceptions import (
    QiskitBackendNotFoundError,
    JobError,
    JobTimeoutError,
)
from .provider import Provider
from .basic_provider import BasicProvider
from .aer import Aer

__all__ = [
    # Abstract base classes
    "Backend",
    "BackendV2",
    "Job",
    "JobV1",
    "JobStatus",
    "Options",
    "Provider",
    # Data classes
    "Result",
    "ExperimentResult",
    # Concrete implementations
    "BasicProvider",
    "Aer",
    # Exceptions
    "QiskitBackendNotFoundError",
    "JobError",
    "JobTimeoutError",
]
