"""
Custom exceptions for the providers module.

Following IBM Qiskit's exception hierarchy.
"""

from ..errors import ValidationError


class QiskitBackendNotFoundError(ValidationError):
    """Exception raised when a requested backend is not found."""
    pass


class JobError(ValidationError):
    """Base exception for errors raised by Jobs."""
    pass


class JobTimeoutError(JobError):
    """Exception raised when a job times out."""
    pass
