"""
Provider abstract base class following IBM Qiskit's interface.
"""

from abc import ABC, abstractmethod
from typing import List
from .backend import Backend, BackendV2


class Provider(ABC):
    """
    Abstract base class for Providers.
    
    A Provider manages access to a collection of backends. It provides
    methods to discover and retrieve available backends.
    
    This follows IBM Qiskit's Provider interface exactly.
    
    Example:
        >>> provider = BasicProvider()
        >>> backends = provider.backends()
        >>> backend = provider.get_backend('statevector_simulator')
    """
    
    @abstractmethod
    def backends(self, name: str = None, **kwargs) -> List[Backend]:
        """
        Return all backends accessible via this provider.
        
        Args:
            name: Optional backend name filter
            **kwargs: Additional filters (e.g., operational=True)
            
        Returns:
            List of matching Backend objects
            
        Example:
            >>> all_backends = provider.backends()
            >>> sim_backends = provider.backends(name='simulator')
        """
        pass
    
    @abstractmethod
    def get_backend(self, name: str = None, **kwargs) -> Backend:
        """
        Return a single backend matching the specified  name.
        
        Args:
            name: Backend name
            **kwargs: Additional selection criteria
            
        Returns:
            Backend object
            
        Raises:
            QiskitBackendNotFoundError: If backend not found
            
        Example:
            >>> backend = provider.get_backend('statevector_simulator')
        """
        pass
    
    def __repr__(self) -> str:
        """String representation of the provider."""
        return f"<{self.__class__.__name__}>"
