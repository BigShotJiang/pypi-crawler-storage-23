"""
BasicProvider - Local simulation provider following IBM Qiskit pattern.
"""

import uuid
from typing import List, Optional, Union
from .provider import Provider
from .backend import BackendV2
from .job import JobV1
from .options import Options
from .exceptions import QiskitBackendNotFoundError


class BasicSimulator(BackendV2):
    """
    Local statevector simulator backend.
    
    This is a basic quantum circuit simulator that maintains the full
    statevector, following IBM Qiskit's BasicSimulator pattern.
    """
    
    def __init__(self):
        """Initialize the statevector simulator."""
        super().__init__(
            name="statevector_simulator",
            description="Statevector simulation of quantum circuits",
            backend_version="1.0.0"
        )
        
        # Create target
        from ..target import Target
        self._target = Target(
            n_qubits=32,  # Theoretical limit for ~8GB RAM
            basis_gates=[
                "id", "x", "y", "z", "h",
                "s", "sdg", "t", "tdg", "sx", "sxdg",
                "rx", "ry", "rz",
                "cx", "cy", "cz", "swap", "ccx",
                "crx", "cry", "crz",
                "barrier", "measure", "reset"
            ],
            coupling_map=None  # All-to-all connectivity for simulator
        )
    
    @property
    def target(self):
        """Return the backend target."""
        return self._target
    
    @property
    def max_circuits(self) -> Optional[int]:
        """Maximum circuits per job (unlimited for simulator)."""
        return None
    
    @classmethod
    def _default_options(cls) -> Options:
        """
        Return default options for the simulator.
        
        Returns:
            Options with default values
        """
        options = Options(shots=1024, memory=False, seed_simulator=None)
        # Set validators
        options.set_validator("shots", (1, 100000))
        options.set_validator("memory", bool)
        return options
    
    def run(self, circuits, **kwargs) -> JobV1:
        """
        Execute circuits on the statevector simulator.
        
        Args:
            circuits: QuantumCircuit or list of QuantumCircuit objects
            **kwargs: Execution options (shots, seed_simulator, etc.)
            
        Returns:
            JobV1 object containing results
        """
        from ..runtime.execute import execute
        
        # Handle single circuit or list
        if not isinstance(circuits, list):
            circuits = [circuits]
        
        # Merge options
        run_options = {
            'shots': kwargs.get('shots', self.options.shots),
            'memory': kwargs.get('memory', self.options.memory),
            'seed_simulator': kwargs.get('seed_simulator', self.options.seed_simulator),
        }
        
        # Execute all circuits
        results = []
        for circuit in circuits:
            result = execute(circuit, backend=self, **run_options)
            results.append(result)
        
        # Create result object
        from .result import Result
        result_obj = Result(
            backend_name=self.name,
            backend_version=self.backend_version,
            results=results,
            success=True
        )
        
        # Create and return job
        job_id = str(uuid.uuid4())
        job = JobV1(self, job_id, result_obj)
        
        return job


class BasicProvider(Provider):
    """
    Provider for local simulation backends.
    
    This provider gives access to local simulators, following
    IBM Qiskit's BasicProvider pattern.
    
    Example:
        >>> from zena.providers import BasicProvider
        >>> provider = BasicProvider()
        >>> backend = provider.get_backend('statevector_simulator')
        >>> job = backend.run(circuit, shots=1024)
        >>> result = job.result()
    """
    
    def __init__(self):
        """Initialize the BasicProvider with available backends."""
        super().__init__()
        self._backends = {
            "statevector_simulator": BasicSimulator(),
        }
    
    def backends(self, name: str = None, **kwargs) -> List[BackendV2]:
        """
        Return all available backends from this provider.
        
        Args:
            name: Optional backend name filter
            **kwargs: Additional filters
            
        Returns:
            List of Backend objects
        """
        if name:
            # Filter by name
            matching = [b for n, b in self._backends.items() if name in n]
            return matching
        
        return list(self._backends.values())
    
    def get_backend(self, name: str = None, **kwargs) -> BackendV2:
        """
        Return a backend by name.
        
        Args:
            name: Backend name (default: 'statevector_simulator')
            **kwargs: Additional selection criteria
            
        Returns:
            Backend object
            
        Raises:
            QiskitBackendNotFoundError: If backend not found
        """
        if name is None:
            name = "statevector_simulator"
        
        if name in self._backends:
            return self._backends[name]
        
        raise QiskitBackendNotFoundError(
            f"Backend '{name}' not found. Available backends: "
            f"{list(self._backends.keys())}"
        )
    
    def __repr__(self) -> str:
        """String representation."""
        return f"<BasicProvider(backends={list(self._backends.keys())})>"
