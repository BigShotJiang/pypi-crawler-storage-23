"""
Result class for storing backend execution results.

Following IBM Qiskit's Result interface.
"""

from typing import Dict, List, Any, Optional
import numpy as np


class ExperimentResult:
    """
    Result data for a single circuit execution.
    
    Attributes:
        shots: Number of shots executed
        success: Whether execution was successful
        data: Measurement results and statevector data
    """
    
    def __init__(self, counts: Dict[str, int], statevector: Optional[List] = None,
                 shots: int = 1024, success: bool = True):
        """
        Initialize an experiment result.
        
        Args:
            counts: Measurement outcome counts
            statevector: Final statevector (if available)
            shots: Number of shots
            success: Execution success status
        """
        self.shots = shots
        self.success = success
        self.data = {
            'counts': counts
        }
        if statevector is not None:
            self.data['statevector'] = statevector


class Result:
    """
    Result object for backend execution.
    
    This class stores the results from backend execution, including
    measurement counts and statevector data. Follows IBM Qiskit's
    Result interface.
    
    Example:
        >>> result = job.result()
        >>> counts = result.get_counts()
        >>> print(counts)
        {'00': 512, '11': 512}
    """
    
    def __init__(self, backend_name: str, backend_version: str,
                 results: List[Any], success: bool = True,
                 job_id: Optional[str] = None):
        """
        Initialize a Result.
        
        Args:
            backend_name: Name of the backend
            backend_version: Backend version string
            results: List of experiment results
            success: Overall success status
            job_id: Associated job ID
        """
        self.backend_name = backend_name
        self.backend_version = backend_version
        self.results = results  # List of ExperimentResult or raw dicts
        self.success = success
        self.job_id = job_id
    
    def get_counts(self, experiment: int = 0) -> Dict[str, int]:
        """
        Get measurement counts for a specific experiment.
        
        Args:
            experiment: Experiment index (default: 0)
            
        Returns:
            Dictionary mapping outcome strings to counts
            
        Example:
            >>> counts = result.get_counts()
            >>> print(counts['00'])
            512
        """
        if experiment >= len(self.results):
            raise IndexError(f"Experiment {experiment} out of range")
        
        exp_result = self.results[experiment]
        
        # Handle both ExperimentResult objects and raw dicts
        if isinstance(exp_result, ExperimentResult):
            return exp_result.data.get('counts', {})
        elif isinstance(exp_result, dict):
            return exp_result.get('counts', {})
        
        return {}
    
    def get_statevector(self, experiment: int = 0) -> Optional[np.ndarray]:
        """
        Get statevector for a specific experiment.
        
        Args:
            experiment: Experiment index (default: 0)
            
        Returns:
            Statevector as numpy array, or None if not available
        """
        if experiment >= len(self.results):
            raise IndexError(f"Experiment {experiment} out of range")
        
        exp_result = self.results[experiment]
        
        # Handle both ExperimentResult objects and raw dicts
        if isinstance(exp_result, ExperimentResult):
            sv = exp_result.data.get('statevector')
        elif isinstance(exp_result, dict):
            sv = exp_result.get('statevector')
        else:
            return None
        
        if sv is not None:
            return np.array(sv)
        return None
    
    def get_memory(self, experiment: int = 0) -> Optional[List[str]]:
        """
        Get individual shot measurement outcomes.
        
        Args:
            experiment: Experiment index (default: 0)
            
        Returns:
            List of measurement outcomes, or None if not available
        """
        if experiment >= len(self.results):
            raise IndexError(f"Experiment {experiment} out of range")
        
        exp_result = self.results[experiment]
        
        if isinstance(exp_result, ExperimentResult):
            return exp_result.data.get('memory')
        elif isinstance(exp_result, dict):
            return exp_result.get('memory')
        
        return None
    
    def data(self, experiment: int = 0) -> Dict[str, Any]:
        """
        Get all data for a specific experiment.
        
        Args:
            experiment: Experiment index (default: 0)
            
        Returns:
            Dictionary containing all result data
        """
        if experiment >= len(self.results):
            raise IndexError(f"Experiment {experiment} out of range")
        
        exp_result = self.results[experiment]
        
        if isinstance(exp_result, ExperimentResult):
            return exp_result.data
        elif isinstance(exp_result, dict):
            return exp_result
        
        return {}
    
    def __repr__(self) -> str:
        """String representation of the result."""
        status = "SUCCESS" if self.success else "FAILED"
        return (f"Result(backend_name='{self.backend_name}', "
                f"experiments={len(self.results)}, status={status})")
