from __future__ import annotations
from typing import List, Optional
from .provider import Provider
from .rust_backend import RustStatevectorSimulator

class AerProvider(Provider):
    """
    Provider for high-performance simulation backends.
    """
    
    def __init__(self):
        super().__init__()
        self._backends = {
            "statevector_simulator": RustStatevectorSimulator(),
        }
    
    def backends(self, name: str = None, **kwargs) -> List[RustStatevectorSimulator]:
        if name:
            return [b for n, b in self._backends.items() if name in n]
        return list(self._backends.values())
    
    def get_backend(self, name: str = None, **kwargs) -> RustStatevectorSimulator:
        if name is None or name == "statevector_simulator":
            return self._backends["statevector_simulator"]
        raise ValueError(f"Backend {name} not found in Aer")

Aer = AerProvider()
