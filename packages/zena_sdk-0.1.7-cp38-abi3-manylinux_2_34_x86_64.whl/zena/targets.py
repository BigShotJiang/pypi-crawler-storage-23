# zena/backends.py - FINAL VERSION
from __future__ import annotations

from .target import Target


def line_target(n_qubits: int) -> Target:
    edges = [(i, i + 1) for i in range(n_qubits - 1)]
    edges += [(i + 1, i) for i in range(n_qubits - 1)]
    return Target(
        n_qubits=n_qubits,
        name=f"line-{n_qubits}",
        basis_gates=["rz", "sx", "x", "cx", "measure"],
        coupling_map=edges,
    )


def ring_target(n_qubits: int) -> Target:
    edges = [(i, (i + 1) % n_qubits) for i in range(n_qubits)]
    edges += [((i + 1) % n_qubits, i) for i in range(n_qubits)]
    return Target(
        n_qubits=n_qubits,
        name=f"ring-{n_qubits}",
        basis_gates=["rz", "sx", "x", "cx", "measure"],
        coupling_map=edges,
    )


def heavy_hex_target() -> Target:
    edges = [
        (0, 1),
        (1, 0),
        (1, 2),
        (2, 1),
        (2, 3),
        (3, 2),
        (3, 4),
        (4, 3),
        (4, 5),
        (5, 4),
        (5, 6),
        (6, 5),
        (0, 6),
        (6, 0),
        (1, 6),
        (6, 1),
        (3, 5),
        (5, 3),
    ]
    return Target(
        n_qubits=7,
        name="heavy-hex-7",
        basis_gates=["rz", "sx", "x", "cx", "measure"],
        coupling_map=edges,
    )


BUILTIN_TARGETS = {
    "line_5": line_target(5),
    "line_16": line_target(16),
    "ring_8": ring_target(8),
    "heavy_hex_7": heavy_hex_target(),
}


# IBM Heron QPU target (with fractional gate support)
def heron_target(n_qubits=156):
    """Create a target mimicking IBM Heron processor capabilities.

    The Heron processor supports fractional gates (RX, RZZ) for
    more efficient circuit execution.

    Args:
        n_qubits: Number of qubits (default 156 for ibm_torino).

    Returns:
        Target with fractional gate support enabled.
    """
    edges = [(i, i + 1) for i in range(n_qubits - 1)]
    edges += [(i + 1, i) for i in range(n_qubits - 1)]
    return Target(
        n_qubits=n_qubits,
        name="heron-" + str(n_qubits),
        basis_gates=["rx", "rzz", "rz", "id", "measure"],
        coupling_map=edges,
        use_fractional_gates=True,
    )

BUILTIN_TARGETS["heron-156"] = heron_target(156)
BUILTIN_TARGETS["heron-5"] = heron_target(5)
