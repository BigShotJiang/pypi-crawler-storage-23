from __future__ import annotations
from typing import Any, Dict
from zena.circuit.quantum_circuit import QuantumCircuit
from zena.errors import ValidationError
from zena.providers.simulator_py import PyStatevectorSimulator

# --- helper: try to call the transpiler / pass manager if available --- #
from importlib import import_module

def _maybe_run_transpiler(qc: QuantumCircuit, backend: Any) -> QuantumCircuit:
    try:
        transpiler = import_module("zena.transpiler")
    except Exception:
        return qc

    candidates = ("run_pass_manager", "pass_manager", "apply_passes", "transpile")
    for name in candidates:
        fn = getattr(transpiler, name, None)
        if not callable(fn):
            continue
        try:
            return fn(qc, backend=backend)
        except TypeError:
            pass
        try:
            return fn(qc, backend)
        except TypeError:
            pass
        try:
            return fn(qc)
        except Exception:
            pass
    return qc

def _validate_circuit_indices(circuit: QuantumCircuit) -> None:
    n_q = circuit.n_qubits
    n_c = circuit.n_clbits
    for instr in circuit.instructions:
        for q in instr.qubits or ():
            if not isinstance(q, int): raise ValidationError(f"qubit index must be int")
            if q < 0 or q >= n_q: raise ValidationError(f"invalid qubit index {q}")
        for c in getattr(instr, "clbits", ()) or ():
            if not isinstance(c, int): raise ValidationError(f"clbit index must be int")
            if c < 0 or c >= n_c: raise ValidationError(f"invalid clbit index {c}")

def execute(
    circuit: QuantumCircuit,
    backend: Any = None,
    shots: int = 1024,
    seed: int | None = None,
    use_transpiler: bool = True,
    **kwargs,
) -> Dict[str, Any]:
    """Execute circuit on the local Python statevector simulator."""
    
    if backend is not None:
        pass 

    # Force disable transpiler to ensure physics correctness (bypass experimental transpiler)
    use_transpiler = False
    
    if use_transpiler:
        circuit = _maybe_run_transpiler(circuit, backend)

    _validate_circuit_indices(circuit)
    
    # Handle seed from kwargs if provided (common in BasicSimulator)
    if seed is None:
        seed = kwargs.get('seed_simulator')

    sim = PyStatevectorSimulator(circuit.n_qubits, seed=seed)

    # Apply instructions
    for instr in circuit.instructions:
        op = instr.name.lower()
        qubits = instr.qubits
        if qubits is None: qubits = []
        params = instr.params or []

        try:
            if op == "rz": sim.rz(qubits[0], params[0])
            elif op == "sx": sim.sx(qubits[0])
            elif op == "x": sim.x(qubits[0])
            elif op == "y": sim.y(qubits[0])
            elif op == "z": sim.z(qubits[0])
            elif op == "h": sim.h(qubits[0])
            elif op == "s": sim.s(qubits[0])
            elif op == "sdg": sim.sdg(qubits[0])
            elif op == "t": sim.t(qubits[0])
            elif op == "tdg": sim.tdg(qubits[0])
            elif op == "rx": sim.rx(qubits[0], params[0])
            elif op == "ry": sim.ry(qubits[0], params[0])
            
            # Two Qubit
            elif op == "cx": sim.cx(qubits[0], qubits[1])
            elif op == "cy": sim.cy(qubits[0], qubits[1])
            elif op == "cz": sim.cz(qubits[0], qubits[1])
            elif op == "swap": sim.swap(qubits[0], qubits[1])
            elif op == "cp": sim.cp(qubits[0], qubits[1], params[0])
            
            # Three Qubit
            elif op == "ccx": sim.ccx(qubits[0], qubits[1], qubits[2])
            
            # Decompositions
            elif op == "crz":
                c, t = qubits
                theta = params[0]
                sim.rz(t, theta / 2.0)
                sim.cx(c, t)
                sim.rz(t, -theta / 2.0)
                sim.cx(c, t)
                
        except Exception as e:
            raise RuntimeError(f"Failed to execute operation {op}: {e}")

    result: Dict[str, Any] = {"shots": shots, "seed": seed}
    if backend is not None:
        result["backend_id"] = getattr(backend, "id", "local_sim")

    if shots is not None and shots > 0:
        raw_counts = sim.measure(shots)
        
        # Apply measurement mapping logic to match IBM/Qiskit output format
        # If circuit has explicit 'measure', map qubit bits to classical bits
        meas_ops = [] # List of (q, c)
        for instr in circuit.instructions:
            if instr.name == 'measure':
                clbits = getattr(instr, 'clbits', [])
                if clbits:
                    meas_ops.append((instr.qubits[0], clbits[0]))
        
        if meas_ops:
            counts = {}
            n_c = getattr(circuit, 'n_clbits', 0)
            n_q = circuit.n_qubits
            
            for r_key, r_val in raw_counts.items():
                # r_key is Big Endian full state (q_{N-1} ... q_0)
                # qubit q is at index N-1-q in r_key
                c_val = 0
                for q, c in meas_ops:
                    idx = n_q - 1 - q
                    if 0 <= idx < len(r_key):
                        if r_key[idx] == '1':
                            c_val |= (1 << c)
                            
                c_str = format(c_val, f'0{n_c}b')
                counts[c_str] = counts.get(c_str, 0) + r_val
            
            result["counts"] = counts
        else:
            # If no measures, return raw full state
            result["counts"] = raw_counts
            
    else:
        result["statevector"] = sim.state

    return result
