"""
OpenQASM 2 exporter — converts QuantumCircuit objects to QASM 2 text.

Mirrors Qiskit's ``qiskit.qasm2.dumps`` and ``qiskit.qasm2.dump``.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import IO, Optional, Union

from .exceptions import QASM2ExportError

# Gates that are defined in qelib1.inc (no separate definition needed)
_QELIB1_GATES = {
    "u3", "u2", "u1", "cx", "id", "u",
    "x", "y", "z", "h", "s", "sdg", "t", "tdg",
    "rx", "ry", "rz", "sx", "sxdg",
    "cz", "cy", "swap", "ch",
    "ccx", "cswap",
    "crx", "cry", "crz", "cu1", "cu3",
    "rxx", "rzz", "p", "cp",
}

# Gate name aliases: Zena internal name -> QASM 2 name
_GATE_ALIASES = {
    "cnot": "cx",
    "toffoli": "ccx",
    "fredkin": "cswap",
}


def _format_params(params) -> str:
    """Format gate parameters for QASM 2 output."""
    if not params:
        return ""
    formatted = []
    import math
    for p in params:
        if isinstance(p, float):
            # Check for pi multiples
            if abs(p - math.pi) < 1e-15:
                formatted.append("pi")
            elif abs(p + math.pi) < 1e-15:
                formatted.append("-pi")
            elif abs(p - math.pi / 2) < 1e-15:
                formatted.append("pi/2")
            elif abs(p - math.pi / 4) < 1e-15:
                formatted.append("pi/4")
            elif abs(p) < 1e-15:
                formatted.append("0")
            else:
                formatted.append(f"{p:.15g}")
        else:
            formatted.append(str(p))
    return "(" + ",".join(formatted) + ")"


def _get_reg_label(index: int, regs) -> str:
    """Convert a global qubit/clbit index to 'regname[idx]' form."""
    offset = 0
    for reg in regs:
        if index < offset + reg.size:
            return f"{reg.name}[{index - offset}]"
        offset += reg.size
    return f"q[{index}]"


def dumps(circuit) -> str:
    """Export a QuantumCircuit to an OpenQASM 2 string.

    Args:
        circuit: The QuantumCircuit to export.

    Returns:
        The OpenQASM 2 representation as a string.

    Example::

        from zena import QuantumCircuit
        from zena.qasm2 import dumps

        qc = QuantumCircuit(2, 2)
        qc.h(0)
        qc.cx(0, 1)
        qc.measure([0, 1], [0, 1])
        print(dumps(qc))
    """
    lines = []
    lines.append("OPENQASM 2.0;")
    lines.append('include "qelib1.inc";')

    # Quantum register declarations
    if circuit._qregs:
        for reg in circuit._qregs:
            lines.append(f"qreg {reg.name}[{reg.size}];")
    else:
        if circuit.n_qubits > 0:
            lines.append(f"qreg q[{circuit.n_qubits}];")

    # Classical register declarations
    if circuit._cregs:
        for reg in circuit._cregs:
            lines.append(f"creg {reg.name}[{reg.size}];")
    else:
        if circuit.n_clbits > 0:
            lines.append(f"creg c[{circuit.n_clbits}];")

    # Instructions
    for inst in circuit._instructions:
        name = _GATE_ALIASES.get(inst.name, inst.name)

        if name == "barrier":
            if inst.qubits:
                qubit_labels = ", ".join(
                    _get_reg_label(q, circuit._qregs) if circuit._qregs
                    else f"q[{q}]"
                    for q in inst.qubits
                )
                lines.append(f"barrier {qubit_labels};")
            else:
                lines.append("barrier;")
            continue

        if name == "measure":
            q_label = (
                _get_reg_label(inst.qubits[0], circuit._qregs)
                if circuit._qregs else f"q[{inst.qubits[0]}]"
            )
            c_label = (
                _get_reg_label(inst.clbits[0], circuit._cregs)
                if circuit._cregs else f"c[{inst.clbits[0]}]"
            )
            lines.append(f"measure {q_label} -> {c_label};")
            continue

        if name == "reset":
            q_label = (
                _get_reg_label(inst.qubits[0], circuit._qregs)
                if circuit._qregs else f"q[{inst.qubits[0]}]"
            )
            lines.append(f"reset {q_label};")
            continue

        # Regular gate
        params_str = _format_params(inst.params)
        qubit_labels = ", ".join(
            _get_reg_label(q, circuit._qregs) if circuit._qregs
            else f"q[{q}]"
            for q in inst.qubits
        )
        lines.append(f"{name}{params_str} {qubit_labels};")

    return "\n".join(lines) + "\n"


def dump(circuit, filename: Union[str, os.PathLike, IO]) -> None:
    """Export a QuantumCircuit to an OpenQASM 2 file.

    Args:
        circuit: The QuantumCircuit to export.
        filename: Path to the output file, or an open file handle.

    Example::

        from zena import QuantumCircuit
        from zena.qasm2 import dump

        qc = QuantumCircuit(2, 2)
        qc.h(0)
        qc.cx(0, 1)
        dump(qc, "my_circuit.qasm")
    """
    program = dumps(circuit)
    if hasattr(filename, "write"):
        filename.write(program)
    else:
        Path(filename).write_text(program, encoding="utf-8")
