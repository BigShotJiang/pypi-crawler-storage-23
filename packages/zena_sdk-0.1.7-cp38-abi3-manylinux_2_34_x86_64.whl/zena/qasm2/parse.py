"""
OpenQASM 2 parser — converts QASM 2 text into QuantumCircuit objects.

This module implements a pure-Python parser for OpenQASM 2.0 programs,
following the specification in https://arxiv.org/abs/1707.03429.

Mirrors Qiskit's ``qiskit.qasm2.loads`` and ``qiskit.qasm2.load``.
"""
from __future__ import annotations

import math
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Optional, Sequence, Tuple, Union

from .exceptions import QASM2ParseError

# ---------------------------------------------------------------------------
# Standard gate library (qelib1.inc)
# ---------------------------------------------------------------------------

# The qelib1.inc gates as defined in the original OpenQASM 2 paper.
# Format:  name -> (num_params, num_qubits)
QELIB1_GATES = {
    "u3": (3, 1), "u2": (2, 1), "u1": (1, 1),
    "cx": (0, 2), "id": (0, 1),
    "u": (3, 1),
    "x": (0, 1), "y": (0, 1), "z": (0, 1),
    "h": (0, 1), "s": (0, 1), "sdg": (0, 1),
    "t": (0, 1), "tdg": (0, 1),
    "rx": (1, 1), "ry": (1, 1), "rz": (1, 1),
    "sx": (0, 1), "sxdg": (0, 1),
    "cz": (0, 2), "cy": (0, 2), "swap": (0, 2),
    "ch": (0, 2),
    "ccx": (0, 3), "cswap": (0, 3),
    "crx": (1, 2), "cry": (1, 2), "crz": (1, 2),
    "cu1": (1, 2), "cu3": (3, 2),
    "rxx": (1, 2), "rzz": (1, 2),
    "p": (1, 1), "cp": (1, 2),
}

# Legacy gates that Qiskit's old exporter treated as built-in.
LEGACY_EXTRA_GATES = {
    "rxx": (1, 2), "rzz": (1, 2),
    "rccx": (0, 3), "rc3x": (0, 4), "c3x": (0, 4), "c3sqrtx": (0, 4),
    "c4x": (0, 5),
}


# ---------------------------------------------------------------------------
# CustomInstruction / CustomClassical
# ---------------------------------------------------------------------------

@dataclass
class CustomInstruction:
    """Link an OpenQASM 2 gate name with a Python constructor.

    Args:
        name:        Gate name as it appears in the QASM program.
        num_params:  Number of angle parameters.
        num_qubits:  Number of qubits the gate acts on.
        constructor: Python callable ``constructor(*params)`` that builds the gate.
        builtin:     If True, the gate does not need an explicit ``gate`` definition.

    Example::

        from zena.qasm2 import CustomInstruction, loads

        ci = CustomInstruction("my_gate", 2, 1, MyGate, builtin=True)
        circuit = loads(program, custom_instructions=[ci])
    """
    name: str
    num_params: int
    num_qubits: int
    constructor: Any = None
    builtin: bool = False


@dataclass
class CustomClassical:
    """Define a custom classical function for OpenQASM 2 gate parameters.

    Args:
        name:     Function name as it appears in the QASM program.
        num_args: Number of floating-point arguments.
        callable: Python callable implementing the function.

    Example::

        import math
        from zena.qasm2 import CustomClassical, loads

        cc = CustomClassical("arctan", 2, math.atan2)
        circuit = loads(program, custom_classical=[cc])
    """
    name: str
    num_args: int
    callable: Callable


# Qiskit-compatible legacy instructions
LEGACY_CUSTOM_INSTRUCTIONS = [
    CustomInstruction(name, nparams, nqubits, None, builtin=True)
    for name, (nparams, nqubits) in LEGACY_EXTRA_GATES.items()
]


# ---------------------------------------------------------------------------
# Tokenizer
# ---------------------------------------------------------------------------

_TOKEN_PATTERNS = [
    ("COMMENT",    r"//[^\n]*"),
    ("REAL",       r"\d+\.\d*([eE][+-]?\d+)?|\d+[eE][+-]?\d+"),
    ("INT",        r"\d+"),
    ("STRING",     r'"[^"]*"'),
    ("IDENT",      r"[a-zA-Z_][a-zA-Z0-9_]*"),
    ("LBRACKET",   r"\["),
    ("RBRACKET",   r"\]"),
    ("LBRACE",     r"\{"),
    ("RBRACE",     r"\}"),
    ("LPAREN",     r"\("),
    ("RPAREN",     r"\)"),
    ("SEMICOLON",  r";"),
    ("COMMA",      r","),
    ("ARROW",      r"->"),
    ("EQUALS",     r"=="),
    ("OP",         r"[+\-*/=]"),
    ("NEWLINE",    r"\n"),
    ("WHITESPACE", r"[ \t\r]+"),
]

_TOKEN_RE = re.compile("|".join(
    f"(?P<{name}>{pattern})" for name, pattern in _TOKEN_PATTERNS
))


def _tokenize(source: str):
    """Yield (type, value, line) tokens from QASM source."""
    line = 1
    for m in _TOKEN_RE.finditer(source):
        kind = m.lastgroup
        val = m.group()
        if kind == "NEWLINE":
            line += 1
            continue
        if kind in ("WHITESPACE", "COMMENT"):
            continue
        yield (kind, val, line)


# ---------------------------------------------------------------------------
# Expression evaluator (for gate parameters)
# ---------------------------------------------------------------------------

def _eval_expr(tokens, pos, custom_classical=None):
    """Parse and evaluate a simple arithmetic expression.

    Returns (value, new_pos).  Handles +, -, *, /, pi, sin, cos, tan, exp, ln, sqrt,
    and custom classical functions.
    """
    if custom_classical is None:
        custom_classical = {}
    return _parse_add_sub(tokens, pos, custom_classical)


def _parse_add_sub(tokens, pos, cc):
    left, pos = _parse_mul_div(tokens, pos, cc)
    while pos < len(tokens) and tokens[pos][0] == "OP" and tokens[pos][1] in ("+", "-"):
        op = tokens[pos][1]
        pos += 1
        right, pos = _parse_mul_div(tokens, pos, cc)
        left = left + right if op == "+" else left - right
    return left, pos


def _parse_mul_div(tokens, pos, cc):
    left, pos = _parse_unary(tokens, pos, cc)
    while pos < len(tokens) and tokens[pos][0] == "OP" and tokens[pos][1] in ("*", "/"):
        op = tokens[pos][1]
        pos += 1
        right, pos = _parse_unary(tokens, pos, cc)
        left = left * right if op == "*" else left / right
    return left, pos


def _parse_unary(tokens, pos, cc):
    if pos < len(tokens) and tokens[pos][0] == "OP" and tokens[pos][1] == "-":
        pos += 1
        val, pos = _parse_atom(tokens, pos, cc)
        return -val, pos
    return _parse_atom(tokens, pos, cc)


_BUILTIN_FUNCS = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "exp": math.exp, "ln": math.log, "sqrt": math.sqrt,
    "acos": math.acos, "asin": math.asin, "atan": math.atan,
}


def _parse_atom(tokens, pos, cc):
    if pos >= len(tokens):
        raise QASM2ParseError("Unexpected end of expression")

    kind, val, line = tokens[pos]

    # Number
    if kind in ("REAL", "INT"):
        pos += 1
        return float(val), pos

    # Parenthesized expression
    if kind == "LPAREN":
        pos += 1  # skip (
        result, pos = _parse_add_sub(tokens, pos, cc)
        if pos < len(tokens) and tokens[pos][0] == "RPAREN":
            pos += 1
        return result, pos

    # Identifier
    if kind == "IDENT":
        if val == "pi":
            return math.pi, pos + 1

        # Built-in functions
        if val in _BUILTIN_FUNCS:
            pos += 1
            if pos < len(tokens) and tokens[pos][0] == "LPAREN":
                pos += 1
                arg, pos = _parse_add_sub(tokens, pos, cc)
                if pos < len(tokens) and tokens[pos][0] == "RPAREN":
                    pos += 1
                return _BUILTIN_FUNCS[val](arg), pos

        # Custom classical functions
        if val in cc:
            func_info = cc[val]
            pos += 1
            if pos < len(tokens) and tokens[pos][0] == "LPAREN":
                pos += 1
                args = []
                for i in range(func_info.num_args):
                    if i > 0:
                        if pos < len(tokens) and tokens[pos][0] == "COMMA":
                            pos += 1
                    arg_val, pos = _parse_add_sub(tokens, pos, cc)
                    args.append(arg_val)
                if pos < len(tokens) and tokens[pos][0] == "RPAREN":
                    pos += 1
                return func_info.callable(*args), pos

        # Gate parameter name (for gate definitions) — treat as 0
        return 0.0, pos + 1

    raise QASM2ParseError(f"Unexpected token in expression: {val!r} at line {line}")


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def _parse_params(tokens, pos, custom_classical):
    """Parse a parenthesized parameter list. Returns ([params], new_pos)."""
    params = []
    if pos < len(tokens) and tokens[pos][0] == "LPAREN":
        pos += 1  # skip (
        while pos < len(tokens) and tokens[pos][0] != "RPAREN":
            val, pos = _eval_expr(tokens, pos, custom_classical)
            params.append(val)
            if pos < len(tokens) and tokens[pos][0] == "COMMA":
                pos += 1
        if pos < len(tokens) and tokens[pos][0] == "RPAREN":
            pos += 1  # skip )
    return params, pos


def _parse_qubit_list(tokens, pos, qregs):
    """Parse a comma-separated list of qubit references. Returns ([indices], new_pos)."""
    qubits = []
    while pos < len(tokens) and tokens[pos][0] not in ("SEMICOLON", "ARROW"):
        if tokens[pos][0] == "IDENT":
            reg_name = tokens[pos][1]
            pos += 1
            if pos < len(tokens) and tokens[pos][0] == "LBRACKET":
                pos += 1  # skip [
                idx = int(tokens[pos][1])
                pos += 1  # skip number
                pos += 1  # skip ]
                # Resolve to global qubit index
                offset = 0
                for rname, rsize in qregs:
                    if rname == reg_name:
                        qubits.append(offset + idx)
                        break
                    offset += rsize
            else:
                # Whole register
                offset = 0
                for rname, rsize in qregs:
                    if rname == reg_name:
                        for i in range(rsize):
                            qubits.append(offset + i)
                        break
                    offset += rsize
        if pos < len(tokens) and tokens[pos][0] == "COMMA":
            pos += 1
        elif pos < len(tokens) and tokens[pos][0] not in ("SEMICOLON", "ARROW", "IDENT"):
            break
    return qubits, pos


def _parse_clbit_list(tokens, pos, cregs):
    """Parse a comma-separated list of classical bit references. Returns ([indices], new_pos)."""
    clbits = []
    while pos < len(tokens) and tokens[pos][0] != "SEMICOLON":
        if tokens[pos][0] == "IDENT":
            reg_name = tokens[pos][1]
            pos += 1
            if pos < len(tokens) and tokens[pos][0] == "LBRACKET":
                pos += 1
                idx = int(tokens[pos][1])
                pos += 1
                pos += 1
                offset = 0
                for rname, rsize in cregs:
                    if rname == reg_name:
                        clbits.append(offset + idx)
                        break
                    offset += rsize
            else:
                offset = 0
                for rname, rsize in cregs:
                    if rname == reg_name:
                        for i in range(rsize):
                            clbits.append(offset + i)
                        break
                    offset += rsize
        if pos < len(tokens) and tokens[pos][0] == "COMMA":
            pos += 1
        elif pos < len(tokens) and tokens[pos][0] not in ("SEMICOLON", "IDENT"):
            break
    return clbits, pos


def loads(
    program: str,
    *,
    include_path: Iterable[Union[str, os.PathLike]] = (".",),
    custom_instructions: Iterable[CustomInstruction] = (),
    custom_classical: Iterable[CustomClassical] = (),
    strict: bool = False,
) -> "QuantumCircuit":
    """Parse an OpenQASM 2 program from a string into a QuantumCircuit.

    Args:
        program: The OpenQASM 2 program as a string.
        include_path: Directories to search for ``include`` files.
        custom_instructions: Custom gate constructors to use during parsing.
        custom_classical: Custom classical functions for gate parameters.
        strict: If True, enforce strict OpenQASM 2 compliance.

    Returns:
        A QuantumCircuit representing the parsed program.

    Example::

        import zena.qasm2

        program = '''
        OPENQASM 2.0;
        include "qelib1.inc";
        qreg q[2];
        creg c[2];
        h q[0];
        cx q[0], q[1];
        measure q -> c;
        '''
        circuit = zena.qasm2.loads(program)
    """
    from ..circuit.quantum_circuit import QuantumCircuit
    from ..ir.types import Instruction

    # Build lookup tables for custom instructions/classical functions
    custom_map = {}
    for ci in custom_instructions:
        custom_map[ci.name] = ci
    cc_map = {}
    for cc in custom_classical:
        cc_map[cc.name] = cc

    # Built-in gate registry (starts with qelib1.inc gates)
    known_gates = dict(QELIB1_GATES)
    for ci in custom_instructions:
        if ci.builtin:
            known_gates[ci.name] = (ci.num_params, ci.num_qubits)

    # Tokenize
    tokens = list(_tokenize(program))
    pos = 0

    # State
    qregs = []  # [(name, size), ...]
    cregs = []
    total_qubits = 0
    total_clbits = 0
    instructions = []
    circuit_name = None

    def _skip_semicolon():
        nonlocal pos
        while pos < len(tokens) and tokens[pos][0] == "SEMICOLON":
            pos += 1

    while pos < len(tokens):
        kind, val, line = tokens[pos]

        # Version header: OPENQASM 2.0;
        if kind == "IDENT" and val == "OPENQASM":
            pos += 1
            # Skip version number
            while pos < len(tokens) and tokens[pos][0] != "SEMICOLON":
                pos += 1
            _skip_semicolon()
            continue

        # Include statement
        if kind == "IDENT" and val == "include":
            pos += 1
            # Skip the filename string
            if pos < len(tokens) and tokens[pos][0] == "STRING":
                filename = tokens[pos][1].strip('"')
                pos += 1
            _skip_semicolon()
            # We handle qelib1.inc and stdgates.inc as built-in
            continue

        # Quantum register declaration
        if kind == "IDENT" and val == "qreg":
            pos += 1
            reg_name = tokens[pos][1]
            pos += 1  # skip name
            pos += 1  # skip [
            reg_size = int(tokens[pos][1])
            pos += 1  # skip number
            pos += 1  # skip ]
            qregs.append((reg_name, reg_size))
            total_qubits += reg_size
            _skip_semicolon()
            continue

        # Classical register declaration
        if kind == "IDENT" and val == "creg":
            pos += 1
            reg_name = tokens[pos][1]
            pos += 1
            pos += 1  # skip [
            reg_size = int(tokens[pos][1])
            pos += 1
            pos += 1  # skip ]
            cregs.append((reg_name, reg_size))
            total_clbits += reg_size
            _skip_semicolon()
            continue

        # Gate definition (skip body — we use known/custom gates)
        if kind == "IDENT" and val == "gate":
            pos += 1
            gate_name = tokens[pos][1]
            pos += 1
            # Count parameters
            nparams = 0
            if pos < len(tokens) and tokens[pos][0] == "LPAREN":
                pos += 1
                while pos < len(tokens) and tokens[pos][0] != "RPAREN":
                    if tokens[pos][0] == "IDENT":
                        nparams += 1
                    pos += 1
                pos += 1  # skip )
            # Count qubits
            nqubits = 0
            while pos < len(tokens) and tokens[pos][0] != "LBRACE":
                if tokens[pos][0] == "IDENT":
                    nqubits += 1
                pos += 1
            # Skip body
            depth = 0
            while pos < len(tokens):
                if tokens[pos][0] == "LBRACE":
                    depth += 1
                elif tokens[pos][0] == "RBRACE":
                    depth -= 1
                    if depth == 0:
                        pos += 1
                        break
                pos += 1
            # Register this gate
            if gate_name not in known_gates:
                known_gates[gate_name] = (nparams, nqubits)
            continue

        # Opaque gate
        if kind == "IDENT" and val == "opaque":
            pos += 1
            while pos < len(tokens) and tokens[pos][0] != "SEMICOLON":
                pos += 1
            _skip_semicolon()
            continue

        # Barrier
        if kind == "IDENT" and val == "barrier":
            pos += 1
            qubits, pos = _parse_qubit_list(tokens, pos, qregs)
            instructions.append(Instruction(
                name="barrier",
                qubits=tuple(qubits),
                clbits=(),
                params=(),
            ))
            _skip_semicolon()
            continue

        # Measure
        if kind == "IDENT" and val == "measure":
            pos += 1
            qubits, pos = _parse_qubit_list(tokens, pos, qregs)
            # Expect ->
            if pos < len(tokens) and tokens[pos][0] == "ARROW":
                pos += 1
            clbits, pos = _parse_clbit_list(tokens, pos, cregs)
            for q, c in zip(qubits, clbits):
                instructions.append(Instruction(
                    name="measure",
                    qubits=(q,),
                    clbits=(c,),
                    params=(),
                ))
            _skip_semicolon()
            continue

        # Reset
        if kind == "IDENT" and val == "reset":
            pos += 1
            qubits, pos = _parse_qubit_list(tokens, pos, qregs)
            for q in qubits:
                instructions.append(Instruction(
                    name="reset",
                    qubits=(q,),
                    clbits=(),
                    params=(),
                ))
            _skip_semicolon()
            continue

        # If statement: if(creg==val) gate args;
        if kind == "IDENT" and val == "if":
            pos += 1
            # Expect (
            if pos < len(tokens) and tokens[pos][0] == "LPAREN":
                pos += 1
            # Parse condition
            cond_reg = tokens[pos][1]
            pos += 1
            # Expect ==
            if pos < len(tokens) and tokens[pos][0] == "EQUALS":
                pos += 1  # skip ==
            cond_val = int(tokens[pos][1])
            pos += 1
            # Expect )
            if pos < len(tokens) and tokens[pos][0] == "RPAREN":
                pos += 1
            # Parse the conditional gate instruction
            gate_name = tokens[pos][1]
            pos += 1
            params, pos = _parse_params(tokens, pos, cc_map)
            qubits, pos = _parse_qubit_list(tokens, pos, qregs)
            instructions.append(Instruction(
                name=gate_name,
                qubits=tuple(qubits),
                clbits=(),
                params=tuple(params),
                condition=(cond_reg, cond_val),
            ))
            _skip_semicolon()
            continue

        # Gate instruction
        if kind == "IDENT" and val in known_gates:
            gate_name = val
            pos += 1
            params, pos = _parse_params(tokens, pos, cc_map)
            qubits, pos = _parse_qubit_list(tokens, pos, qregs)
            instructions.append(Instruction(
                name=gate_name,
                qubits=tuple(qubits),
                clbits=(),
                params=tuple(params),
            ))
            _skip_semicolon()
            continue

        # Custom gate from custom_instructions
        if kind == "IDENT" and val in custom_map:
            gate_name = val
            pos += 1
            params, pos = _parse_params(tokens, pos, cc_map)
            qubits, pos = _parse_qubit_list(tokens, pos, qregs)
            instructions.append(Instruction(
                name=gate_name,
                qubits=tuple(qubits),
                clbits=(),
                params=tuple(params),
            ))
            _skip_semicolon()
            continue

        # Unknown gate (treat as custom)
        if kind == "IDENT":
            gate_name = val
            pos += 1
            params, pos = _parse_params(tokens, pos, cc_map)
            qubits, pos = _parse_qubit_list(tokens, pos, qregs)
            if qubits:
                instructions.append(Instruction(
                    name=gate_name,
                    qubits=tuple(qubits),
                    clbits=(),
                    params=tuple(params),
                ))
            _skip_semicolon()
            continue

        # Skip empty semicolons and other tokens
        pos += 1

    # Build QuantumCircuit
    qc = QuantumCircuit(total_qubits, total_clbits, name=circuit_name)
    qc._instructions = instructions

    # Restore register names
    from ..circuit.register import QuantumRegister, ClassicalRegister
    qc._qregs = [QuantumRegister(sz, name) for name, sz in qregs]
    qc._cregs = [ClassicalRegister(sz, name) for name, sz in cregs]

    return qc


def load(
    filename: Union[str, os.PathLike],
    *,
    include_path: Iterable[Union[str, os.PathLike]] = (".",),
    include_input_directory: Optional[str] = "append",
    custom_instructions: Iterable[CustomInstruction] = (),
    custom_classical: Iterable[CustomClassical] = (),
    strict: bool = False,
) -> "QuantumCircuit":
    """Parse an OpenQASM 2 program from a file into a QuantumCircuit.

    Args:
        filename: Path to the OpenQASM 2 file.
        include_path: Directories to search for ``include`` files.
        include_input_directory: Whether to add the input file's directory
            to include_path ('append', 'prepend', or None).
        custom_instructions: Custom gate constructors for parsing.
        custom_classical: Custom classical functions for gate parameters.
        strict: If True, enforce strict OpenQASM 2 compliance.

    Returns:
        A QuantumCircuit representing the parsed program.

    Example::

        import zena.qasm2
        circuit = zena.qasm2.load("myfile.qasm")
    """
    path = Path(filename)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    program = path.read_text(encoding="utf-8")
    return loads(
        program,
        include_path=include_path,
        custom_instructions=custom_instructions,
        custom_classical=custom_classical,
        strict=strict,
    )
