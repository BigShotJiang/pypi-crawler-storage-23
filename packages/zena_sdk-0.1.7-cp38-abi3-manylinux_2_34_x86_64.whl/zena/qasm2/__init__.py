"""
OpenQASM 2 interoperability for the Zena SDK.

Provides functions to import and export quantum circuits in OpenQASM 2 format,
matching Qiskit's ``qiskit.qasm2`` API.

Functions:
    loads(program)      Parse OpenQASM 2 from a string → QuantumCircuit
    load(filename)      Parse OpenQASM 2 from a file → QuantumCircuit
    dumps(circuit)      Export QuantumCircuit → OpenQASM 2 string
    dump(circuit, file) Export QuantumCircuit → OpenQASM 2 file

Classes:
    CustomInstruction   Link OpenQASM 2 gate names with Zena gate classes
    CustomClassical     Define custom classical functions for gate parameters
    QASM2Error          Base exception for QASM 2 errors
    QASM2ParseError     Exception for QASM 2 parse errors
    QASM2ExportError    Exception for QASM 2 export errors

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/interoperate-qiskit-qasm2
    https://quantum.cloud.ibm.com/docs/api/qiskit/qasm2
"""
from .parse import loads, load, CustomInstruction, CustomClassical, LEGACY_CUSTOM_INSTRUCTIONS
from .export import dumps, dump
from .exceptions import QASM2Error, QASM2ParseError, QASM2ExportError

__all__ = [
    "loads", "load", "dumps", "dump",
    "CustomInstruction", "CustomClassical",
    "LEGACY_CUSTOM_INSTRUCTIONS",
    "QASM2Error", "QASM2ParseError", "QASM2ExportError",
]
