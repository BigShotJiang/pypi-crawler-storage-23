"""Exceptions for OpenQASM 2 operations."""


class QASM2Error(Exception):
    """Base exception for OpenQASM 2 errors."""
    pass


class QASM2ParseError(QASM2Error):
    """Exception raised when parsing OpenQASM 2 fails."""
    pass


class QASM2ExportError(QASM2Error):
    """Exception raised when exporting to OpenQASM 2 fails."""
    pass
