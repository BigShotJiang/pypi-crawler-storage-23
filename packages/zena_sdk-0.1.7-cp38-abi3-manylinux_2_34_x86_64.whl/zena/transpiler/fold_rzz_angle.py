"""
FoldRzzAngle transpiler pass.

Folds RZZ gate angles into the valid hardware range (0, pi/2].
On IBM Heron QPUs, the fractional RZZ gate only supports angles in (0, pi/2].
This pass transforms RZZ gates with out-of-range angles into equivalent circuits.

Follows Qiskit's qiskit_ibm_runtime.transpiler.passes.FoldRzzAngle.
"""
from __future__ import annotations
import math
from typing import List, Optional


class FoldRzzAngle:
    """Transpiler pass that folds RZZ gate angles into range (0, pi/2].

    The RZZ gate on IBM Heron QPUs only supports angles theta in (0, pi/2].
    For angles outside this range, equivalent circuit transformations are applied:

    Rules:
    - RZZ(0): removed entirely (identity)
    - RZZ(theta) where theta < 0: RZZ(-theta) with Z gates on both qubits
    - RZZ(theta) where theta > pi/2: fold using periodicity/symmetry

    Usage::

        from zena.transpiler.passes import FoldRzzAngle

        pass_ = FoldRzzAngle()
        new_instructions = pass_.run(circuit._instructions)
    """

    RANGE_MIN = 0.0
    RANGE_MAX = math.pi / 2

    def __init__(self):
        pass

    @staticmethod
    def _normalize_angle(theta):
        """Normalize angle to the range (0, pi/2].

        Returns (normalized_theta, needs_z_correction, is_identity).
        """
        from ..circuit.parameter import Parameter, ParameterExpression

        # Skip symbolic parameters -- cannot fold at transpile time
        if isinstance(theta, (Parameter, ParameterExpression)):
            return theta, False, False

        theta = float(theta)

        # Reduce to (-pi, pi]
        theta = theta % (2 * math.pi)
        if theta > math.pi:
            theta -= 2 * math.pi

        needs_z = False

        # If negative, negate and mark for Z-correction on both qubits
        if theta < 0:
            theta = -theta
            needs_z = True

        # If zero, it is identity
        if abs(theta) < 1e-15:
            return 0.0, False, True

        # If > pi/2, fold using: RZZ(pi - theta) = Z_0 Z_1 RZZ(theta)
        while theta > math.pi / 2 + 1e-10:
            theta = math.pi - theta
            needs_z = not needs_z
            if theta < -1e-10:
                theta = -theta
                needs_z = not needs_z

        # Final identity check
        if abs(theta) < 1e-15:
            return 0.0, needs_z, True

        return theta, needs_z, False

    def fold_instruction(self, inst):
        """Fold a single RZZ instruction.

        Args:
            inst: An Instruction with name 'rzz'.

        Returns:
            List of replacement instructions.
        """
        from ..ir.types import Instruction

        if inst.name != "rzz":
            return [inst]

        if not inst.params or len(inst.params) == 0:
            return [inst]

        theta = inst.params[0]
        normalized, needs_z, is_identity = self._normalize_angle(theta)

        result = []

        if is_identity:
            # RZZ(0) is identity, remove it
            return result

        if needs_z:
            # Add Z gates on both qubits before the RZZ
            q0 = inst.qubits[0]
            q1 = inst.qubits[1]
            result.append(Instruction(name="z", qubits=(q0,)))
            result.append(Instruction(name="z", qubits=(q1,)))

        # Add the folded RZZ gate
        result.append(Instruction(
            name="rzz",
            qubits=inst.qubits,
            clbits=inst.clbits if inst.clbits else (),
            params=(normalized,)
        ))

        return result

    def run(self, instructions):
        """Run the pass on a list of instructions.

        Args:
            instructions: List of Instruction objects.

        Returns:
            New list of Instruction objects with RZZ angles folded.
        """
        new_instructions = []
        for inst in instructions:
            new_instructions.extend(self.fold_instruction(inst))
        return new_instructions

    def __repr__(self):
        return "FoldRzzAngle()"
