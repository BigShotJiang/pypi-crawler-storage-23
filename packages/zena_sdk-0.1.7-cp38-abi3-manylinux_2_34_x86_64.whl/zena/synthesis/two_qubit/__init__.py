"""
Two-qubit unitary synthesis.

Matches Qiskit's ``qiskit.synthesis.two_qubit`` module.

Classes:
    TwoQubitBasisDecomposer - Decompose 2-qubit unitaries into CX + 1q gates

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/synthesize-unitary-operators
"""
from .two_qubit_decompose import TwoQubitBasisDecomposer

__all__ = ["TwoQubitBasisDecomposer"]
