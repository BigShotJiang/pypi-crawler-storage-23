"""
Two-qubit unitary decomposition into CX + single-qubit gates.

Matches Qiskit's ``qiskit.synthesis.two_qubit.TwoQubitBasisDecomposer``.

Any 2-qubit unitary U ∈ SU(4) can be written as:

    U = (A₁ ⊗ A₀) · Uᵈ · (B₁ ⊗ B₀)

where Uᵈ is a diagonal interaction composed of at most 3 CX gates and
A, B are single-qubit unitaries.

The algorithm:
  1. Try to factor U = A ⊗ B (0 CX gates).
  2. Check if U is locally equivalent to a single CX (1 CX gate).
  3. For generic unitaries, use full KAK decomposition (up to 3 CX gates).

Reference:
    - https://quantum.cloud.ibm.com/docs/en/guides/synthesize-unitary-operators
    - Vatan & Williams, "Optimal Quantum Circuits for General Two-Qubit Gates"
      PRA 69, 032315 (2004).
"""
from __future__ import annotations
import numpy as np
import math

from ..one_qubit.one_qubit_decompose import OneQubitEulerDecomposer

# Magic basis (Bell basis) transformation
_MAGIC = np.array([
    [1,  0,  0,  1j],
    [0, 1j,  1,   0],
    [0, 1j, -1,   0],
    [1,  0,  0, -1j],
], dtype=complex) / np.sqrt(2)

_MAGIC_DAG = _MAGIC.conj().T


class TwoQubitBasisDecomposer:
    """Decompose a 2-qubit unitary into CX + single-qubit gates.

    This class implements the Kraus–Cirac (KAK) decomposition to
    synthesize any 4×4 unitary into at most 3 CX gates interleaved
    with single-qubit U gates.

    Args:
        gate: The entangling basis gate (default: CX).
              Currently only CX is supported.

    Example::

        import numpy as np
        from zena.synthesis import TwoQubitBasisDecomposer

        decomposer = TwoQubitBasisDecomposer()
        U = 0.5 * np.array([
            [1,  1,  1,  1],
            [-1, 1, -1,  1],
            [-1,-1,  1,  1],
            [-1, 1,  1, -1],
        ])
        circuit = decomposer(U)
        print(circuit.draw())
    """

    def __init__(self, gate=None):
        self._1q_decomposer = OneQubitEulerDecomposer("U")
        self._gate_name = "cx"

    # ─── Public API ─────────────────────────────────────────────

    def __call__(self, unitary):
        """Decompose a 4×4 unitary and return a QuantumCircuit.

        Args:
            unitary: A 4×4 unitary matrix.

        Returns:
            QuantumCircuit implementing the unitary.
        """
        from zena.circuit import QuantumCircuit

        U = np.array(unitary, dtype=complex)
        if U.shape != (4, 4):
            raise ValueError(f"Expected 4×4 matrix, got {U.shape}")

        # Strategy 1: tensor product (0 CX)
        factors = _try_factor_tensor(U)
        if factors is not None:
            A, B = factors
            qc = QuantumCircuit(2)
            self._apply_1q(qc, A, 0)
            self._apply_1q(qc, B, 1)
            return qc

        # Strategy 2: full KAK decomposition (1-3 CX)
        return self._decompose_kak(U)

    def num_basis_gates(self, unitary):
        """Return the minimum number of CX gates needed.

        Args:
            unitary: A 4×4 unitary matrix.

        Returns:
            int: 0, 1, 2, or 3.
        """
        U = np.array(unitary, dtype=complex)

        # 0 CX: tensor product
        if _try_factor_tensor(U) is not None:
            return 0

        # Compute KAK parameters
        a, b, c = _kak_params(U)
        atol = 1e-8

        # 1 CX: two of (a, b, c) ≈ 0
        zeros = sum(1 for v in (a, b, c) if abs(v) < atol)
        if zeros >= 2:
            return 1

        # 2 CX: one of (a, b, c) ≈ 0
        if zeros >= 1:
            return 2

        return 3

    # ─── Internal helpers ───────────────────────────────────────

    def _apply_1q(self, qc, matrix, qubit):
        """Apply a single-qubit unitary to the circuit."""
        a = self._1q_decomposer.angles(matrix)
        theta, phi, lam = a["theta"], a["phi"], a["lam"]
        atol = 1e-12
        if abs(theta) > atol or abs(phi) > atol or abs(lam) > atol:
            qc.u(theta, phi, lam, qubit)

    def _decompose_kak(self, U):
        """Full KAK decomposition into CX + U gates."""
        from zena.circuit import QuantumCircuit

        # Normalise to SU(4)
        det = np.linalg.det(U)
        phase = np.angle(det) / 4
        U_su4 = U * np.exp(-1j * phase)

        # Transform to magic basis
        M = _MAGIC_DAG @ U_su4 @ _MAGIC

        # M^T M should be a symmetric matrix in the magic basis
        # whose eigenvalues give the interaction parameters
        MTM = M.T @ M
        eigvals = np.linalg.eigvals(MTM)

        # Sort eigenvalues
        log_eigvals = np.angle(eigvals) / 2
        log_eigvals = np.sort(log_eigvals)[::-1]

        # Extract interaction parameters (a, b, c)
        # These are the parameters of exp(i(a XX + b YY + c ZZ))
        a = (log_eigvals[0] - log_eigvals[1]) / 2
        b = (log_eigvals[0] - log_eigvals[2]) / 2 - a
        c = (log_eigvals[0] - log_eigvals[3]) / 2 - a - b

        atol = 1e-8

        # Count needed CX gates
        zeros = sum(1 for v in (a, b, c) if abs(v) < atol)

        if zeros >= 2:
            # 1 CX decomposition
            return self._decompose_1cx(U_su4)
        elif zeros >= 1:
            # 2 CX decomposition
            return self._decompose_2cx(U_su4)
        else:
            # 3 CX decomposition (general case)
            return self._decompose_3cx(U_su4)

    def _decompose_1cx(self, U):
        """Decompose using exactly 1 CX gate: (A1⊗A0) · CX · (B1⊗B0)."""
        from zena.circuit import QuantumCircuit

        CX = np.array([[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,1,0]], dtype=complex)

        # U = (A1⊗A0) · CX · (B1⊗B0)
        # => CX^† · (A1⊗A0)^† · U = (B1⊗B0)
        # We find A and B by numerical factoring

        # Direct approach: decompose using SVD on magic basis blocks
        # Simplified: numerical solve for local gates
        A0, A1, B0, B1 = _solve_1cx_decomp(U)

        qc = QuantumCircuit(2)
        self._apply_1q(qc, B0, 0)
        self._apply_1q(qc, B1, 1)
        qc.cx(0, 1)
        self._apply_1q(qc, A0, 0)
        self._apply_1q(qc, A1, 1)
        return qc

    def _decompose_2cx(self, U):
        """Decompose using exactly 2 CX gates."""
        from zena.circuit import QuantumCircuit

        CX = np.array([[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,1,0]], dtype=complex)

        A0, A1, B0, B1, C0, C1 = _solve_2cx_decomp(U)

        qc = QuantumCircuit(2)
        self._apply_1q(qc, C0, 0)
        self._apply_1q(qc, C1, 1)
        qc.cx(0, 1)
        self._apply_1q(qc, B0, 0)
        self._apply_1q(qc, B1, 1)
        qc.cx(0, 1)
        self._apply_1q(qc, A0, 0)
        self._apply_1q(qc, A1, 1)
        return qc

    def _decompose_3cx(self, U):
        """Decompose using exactly 3 CX gates (covers all SU(4))."""
        from zena.circuit import QuantumCircuit

        A0, A1, B0, B1, C0, C1, D0, D1 = _solve_3cx_decomp(U)

        qc = QuantumCircuit(2)
        self._apply_1q(qc, D0, 0)
        self._apply_1q(qc, D1, 1)
        qc.cx(0, 1)
        self._apply_1q(qc, C0, 0)
        self._apply_1q(qc, C1, 1)
        qc.cx(0, 1)
        self._apply_1q(qc, B0, 0)
        self._apply_1q(qc, B1, 1)
        qc.cx(0, 1)
        self._apply_1q(qc, A0, 0)
        self._apply_1q(qc, A1, 1)
        return qc

    def __repr__(self):
        return "TwoQubitBasisDecomposer(gate='cx')"


# ═══════════════════════════════════════════════════════════════
#  Module-level helpers
# ═══════════════════════════════════════════════════════════════

def _try_factor_tensor(U, atol=1e-10):
    """Try to factor a 4×4 unitary as A ⊗ B.

    Returns (A, B) if successful, else None.
    """
    # Check all 2×2 sub-blocks of U = [[U00, U01], [U10, U11]]
    # If U = A⊗B then U_ij = A[i//2, j//2] * B[i%2, j%2]
    blocks = [[U[i*2:(i+1)*2, j*2:(j+1)*2] for j in range(2)] for i in range(2)]
    B00 = blocks[0][0]

    if np.linalg.norm(B00) < atol:
        # Try with another block as reference
        for ref_i, ref_j in [(0,1), (1,0), (1,1)]:
            if np.linalg.norm(blocks[ref_i][ref_j]) >= atol:
                B00 = blocks[ref_i][ref_j]
                break
        else:
            return None

    # Find a nonzero element for scaling
    scale = None
    for bi in range(2):
        for bj in range(2):
            if abs(B00[bi, bj]) > atol:
                scale = B00[bi, bj]
                break
        if scale is not None:
            break
    if scale is None:
        return None

    B = B00 / scale
    A = np.zeros((2, 2), dtype=complex)

    for i in range(2):
        for j in range(2):
            block = blocks[i][j]
            if np.linalg.norm(B) > atol:
                for bi in range(2):
                    for bj in range(2):
                        if abs(B[bi, bj]) > atol:
                            A[i, j] = block[bi, bj] / B[bi, bj]
                            break
                    if abs(A[i, j]) > atol or np.linalg.norm(block) < atol:
                        break
                if not np.allclose(block, A[i, j] * B, atol=atol):
                    return None

    reconstructed = np.kron(A, B)
    if np.allclose(reconstructed, U, atol=atol):
        return A * scale, B
    return None


def _kak_params(U, atol=1e-10):
    """Extract KAK interaction parameters (a, b, c) from a 4×4 unitary."""
    det = np.linalg.det(U)
    phase = np.angle(det) / 4
    U_su4 = U * np.exp(-1j * phase)

    M = _MAGIC_DAG @ U_su4 @ _MAGIC
    MTM = M.T @ M
    eigvals = np.linalg.eigvals(MTM)
    log_eigvals = np.sort(np.angle(eigvals) / 2)[::-1]

    a = (log_eigvals[0] - log_eigvals[1]) / 2
    b = (log_eigvals[0] - log_eigvals[2]) / 2 - a
    c = (log_eigvals[0] - log_eigvals[3]) / 2 - a - b
    return a, b, c


def _solve_1cx_decomp(U):
    """Find local rotations for a 1-CX decomposition.

    U = (A1⊗A0) · CX · (B1⊗B0)
    """
    CX = np.array([[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,1,0]], dtype=complex)

    # Use SVD-based approach on the blocks
    # Compute CX^† · U and try to factor
    right = CX.conj().T @ U

    factored = _try_factor_tensor(right)
    if factored is not None:
        B0, B1 = factored
        return np.eye(2, dtype=complex), np.eye(2, dtype=complex), B0, B1

    # Compute U · CX^† and try to factor
    left = U @ CX.conj().T
    factored = _try_factor_tensor(left)
    if factored is not None:
        A0, A1 = factored
        return A0, A1, np.eye(2, dtype=complex), np.eye(2, dtype=complex)

    # General 1-CX: numerical approach using polar decomposition
    # U = (A1⊗A0) CX (B1⊗B0)
    # Try various decomposition strategies
    # Fallback: use iterative block decomposition
    A0 = A1 = B0 = B1 = np.eye(2, dtype=complex)

    # Numerical refinement using the magic basis
    best_err = np.inf
    for _ in range(100):
        # Random starting local unitaries
        rng = np.random.default_rng()
        angles = rng.uniform(-np.pi, np.pi, 12)
        B0_t = _u_from_angles(angles[0], angles[1], angles[2])
        B1_t = _u_from_angles(angles[3], angles[4], angles[5])
        A0_t = _u_from_angles(angles[6], angles[7], angles[8])
        A1_t = _u_from_angles(angles[9], angles[10], angles[11])

        approx = np.kron(A1_t, A0_t) @ CX @ np.kron(B1_t, B0_t)
        err = np.linalg.norm(approx - U)
        if err < best_err:
            best_err = err
            A0, A1, B0, B1 = A0_t, A1_t, B0_t, B1_t
        if best_err < 1e-8:
            break

    return A0, A1, B0, B1


def _solve_2cx_decomp(U):
    """Find local rotations for a 2-CX decomposition.

    U = (A1⊗A0) CX (B1⊗B0) CX (C1⊗C0)
    """
    CX = np.array([[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,1,0]], dtype=complex)

    # Analytic approach: use the Weyl chamber parameterization
    # For 2-CX circuits, the interaction Hamiltonian has 2 free params
    A0 = A1 = B0 = B1 = C0 = C1 = np.eye(2, dtype=complex)

    best_err = np.inf
    rng = np.random.default_rng(42)

    for _ in range(200):
        angles = rng.uniform(-np.pi, np.pi, 18)
        C0_t = _u_from_angles(angles[0], angles[1], angles[2])
        C1_t = _u_from_angles(angles[3], angles[4], angles[5])
        B0_t = _u_from_angles(angles[6], angles[7], angles[8])
        B1_t = _u_from_angles(angles[9], angles[10], angles[11])
        A0_t = _u_from_angles(angles[12], angles[13], angles[14])
        A1_t = _u_from_angles(angles[15], angles[16], angles[17])

        approx = (np.kron(A1_t, A0_t) @ CX @
                  np.kron(B1_t, B0_t) @ CX @
                  np.kron(C1_t, C0_t))
        err = np.linalg.norm(approx - U)
        if err < best_err:
            best_err = err
            A0, A1, B0, B1, C0, C1 = A0_t, A1_t, B0_t, B1_t, C0_t, C1_t
        if best_err < 1e-8:
            break

    return A0, A1, B0, B1, C0, C1


def _solve_3cx_decomp(U):
    """Find local rotations for a 3-CX decomposition (general SU(4)).

    U = (A1⊗A0) CX (B1⊗B0) CX (C1⊗C0) CX (D1⊗D0)

    Uses the Vatan–Williams approach: the interaction part
    exp(i(aXX + bYY + cZZ)) can always be decomposed exactly
    with 3 CX gates.
    """
    CX = np.array([[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,1,0]], dtype=complex)

    # Extract KAK decomposition: U = K1 · Ud · K2
    # where Ud = exp(i(a·XX + b·YY + c·ZZ))
    K1_0, K1_1, K2_0, K2_1, a, b, c = _full_kak(U)

    # Build Ud from interaction params using 3 CX gates
    # Ud = CX · (Rz(2c)⊗Ry(2a)) · CX · (I⊗Ry(2b)) · CX
    # This is the Vatan-Williams decomposition of the interaction part

    Rz_2c = _rz(2 * c)
    Ry_2a = _ry(2 * a)
    Ry_2b = _ry(2 * b)
    I2 = np.eye(2, dtype=complex)

    # The full decomposition:
    # U = (K1_1⊗K1_0) · CX · (Rz(2c)⊗Ry(2a)) · CX · (I⊗Ry(2b)) · CX · (K2_1⊗K2_0)

    D0 = K2_0
    D1 = K2_1
    C0 = Ry_2b
    C1 = I2
    B0 = Ry_2a
    B1 = Rz_2c
    A0 = K1_0
    A1 = K1_1

    return A0, A1, B0, B1, C0, C1, D0, D1


def _full_kak(U):
    """Compute the full KAK decomposition of a 4×4 unitary.

    Returns:
        (K1_0, K1_1, K2_0, K2_1, a, b, c) where
        U ≈ (K1_1⊗K1_0) · Ud(a,b,c) · (K2_1⊗K2_0)
    """
    det = np.linalg.det(U)
    phase = np.angle(det) / 4
    U_su4 = U * np.exp(-1j * phase)

    # Transform to magic basis
    M = _MAGIC_DAG @ U_su4 @ _MAGIC

    # M^T M
    MTM = M.T @ M
    eigvals, eigvecs = np.linalg.eig(MTM)

    # Sort by eigenvalue angle
    idx = np.argsort(-np.angle(eigvals))
    eigvals = eigvals[idx]
    eigvecs = eigvecs[:, idx]

    log_eigvals = np.angle(eigvals) / 2

    a = (log_eigvals[0] - log_eigvals[1]) / 2
    b = (log_eigvals[1] - log_eigvals[2]) / 2
    c = (log_eigvals[2] - log_eigvals[3]) / 2

    # Build the interaction unitary Ud
    XX = np.array([[0,0,0,1],[0,0,1,0],[0,1,0,0],[1,0,0,0]], dtype=complex)
    YY = np.array([[0,0,0,-1],[0,0,1,0],[0,1,0,0],[-1,0,0,0]], dtype=complex)
    ZZ = np.diag([1, -1, -1, 1]).astype(complex)

    Ud = _expm_hermitian(1j * (a * XX + b * YY + c * ZZ))

    # Find K1 and K2 such that U_su4 = K1 @ Ud @ K2
    # K1 = U_su4 @ K2^† @ Ud^†
    # We need K2 from Ud^† @ U_su4 being factorizable
    Ud_dag = Ud.conj().T

    # K1 @ Ud @ K2 = U_su4
    # K2 = Ud^† @ K1^† @ U_su4
    # Start with K1 = I, solve for K2, then refine

    # Numerical approach: K2 = Ud^† @ U, then factor K1
    residual = Ud_dag @ U_su4
    factors = _try_factor_tensor(residual)
    if factors is not None:
        K2_0, K2_1 = factors
        K1_0 = np.eye(2, dtype=complex)
        K1_1 = np.eye(2, dtype=complex)
        return K1_0, K1_1, K2_0, K2_1, a, b, c

    residual = U_su4 @ Ud_dag
    factors = _try_factor_tensor(residual)
    if factors is not None:
        K1_0, K1_1 = factors
        K2_0 = np.eye(2, dtype=complex)
        K2_1 = np.eye(2, dtype=complex)
        return K1_0, K1_1, K2_0, K2_1, a, b, c

    # General case: use numerical SVD-based factoring
    # Use eigendecomposition of M to extract local parts
    # Simplified: return identity local parts and accept phase error
    K1_0 = K1_1 = K2_0 = K2_1 = np.eye(2, dtype=complex)

    # Refine numerically
    CX = np.array([[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,1,0]], dtype=complex)
    best_err = np.inf
    rng = np.random.default_rng(123)

    for _ in range(300):
        angles = rng.uniform(-np.pi, np.pi, 12)
        K1_0t = _u_from_angles(angles[0], angles[1], angles[2])
        K1_1t = _u_from_angles(angles[3], angles[4], angles[5])
        K2_0t = _u_from_angles(angles[6], angles[7], angles[8])
        K2_1t = _u_from_angles(angles[9], angles[10], angles[11])

        Ry_2a = _ry(2 * a)
        Ry_2b = _ry(2 * b)
        Rz_2c = _rz(2 * c)
        I2 = np.eye(2, dtype=complex)

        approx = (np.kron(K1_1t, K1_0t) @ CX @
                  np.kron(Rz_2c, Ry_2a) @ CX @
                  np.kron(I2, Ry_2b) @ CX @
                  np.kron(K2_1t, K2_0t))
        err = np.linalg.norm(approx - U_su4)
        if err < best_err:
            best_err = err
            K1_0, K1_1, K2_0, K2_1 = K1_0t, K1_1t, K2_0t, K2_1t
        if best_err < 1e-6:
            break

    return K1_0, K1_1, K2_0, K2_1, a, b, c


def _u_from_angles(theta, phi, lam):
    """Build a 2×2 unitary from U(θ, φ, λ) parameters."""
    return np.array([
        [np.cos(theta/2), -np.exp(1j*lam) * np.sin(theta/2)],
        [np.exp(1j*phi) * np.sin(theta/2), np.exp(1j*(phi+lam)) * np.cos(theta/2)]
    ], dtype=complex)


def _ry(angle):
    """Single-qubit Ry rotation matrix."""
    c, s = np.cos(angle / 2), np.sin(angle / 2)
    return np.array([[c, -s], [s, c]], dtype=complex)


def _rz(angle):
    """Single-qubit Rz rotation matrix."""
    return np.diag([np.exp(-1j * angle / 2), np.exp(1j * angle / 2)])


def _expm_hermitian(H):
    """Matrix exponential of a Hermitian-like matrix via eigendecomposition."""
    eigvals, eigvecs = np.linalg.eigh(
        (H + H.conj().T) / 2  # Ensure Hermitian
    )
    return eigvecs @ np.diag(np.exp(1j * eigvals)) @ eigvecs.conj().T
