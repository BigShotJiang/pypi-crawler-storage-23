"""
Decompose single-qubit unitaries via Euler angle rotations.

Matches Qiskit's ``qiskit.synthesis.one_qubit.OneQubitEulerDecomposer``.

Supported decomposition bases:

    ======  =============================================
    Basis   Decomposition
    ======  =============================================
    ZYZ     Rz(φ) · Ry(θ) · Rz(λ)
    ZXZ     Rz(φ) · Rx(θ) · Rz(λ)
    XYX     Rx(φ) · Ry(θ) · Rx(λ)
    U3      U3(θ, φ, λ)
    U       U(θ, φ, λ)
    ======  =============================================

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/synthesize-unitary-operators
"""
from __future__ import annotations
import numpy as np
import math


# ─── Supported basis → gate names mapping ──────────────────────
ONE_QUBIT_EULER_BASIS_GATES = {
    "U3":  ["u3"],
    "U":   ["u"],
    "ZYZ": ["rz", "ry"],
    "ZXZ": ["rz", "rx"],
    "XYX": ["rx", "ry"],
    "PSX": ["p", "sx"],
    "ZSX": ["rz", "sx"],
}

DEFAULT_ATOL = 1e-12


class OneQubitEulerDecomposer:
    r"""Decompose a single-qubit unitary into Euler angle rotations.

    The resulting decomposition is parameterised by three Euler rotation
    angles :math:`(\theta, \phi, \lambda)` and a global phase
    :math:`\gamma`.

    Args:
        basis: The decomposition basis. Supported values:
               ``'ZYZ'``, ``'ZXZ'``, ``'XYX'``, ``'U3'``, ``'U'``,
               ``'PSX'``, ``'ZSX'``.
               Default: ``'U3'``.

    Example::

        import numpy as np
        from zena.synthesis import OneQubitEulerDecomposer

        decomposer = OneQubitEulerDecomposer("ZYZ")
        H = np.array([[1, 1], [1, -1]]) / np.sqrt(2)
        circuit = decomposer(H)
        print(circuit.draw())
    """

    def __init__(self, basis: str = "U3"):
        if basis not in ONE_QUBIT_EULER_BASIS_GATES:
            raise ValueError(
                f"Unknown basis '{basis}'. Supported: "
                f"{list(ONE_QUBIT_EULER_BASIS_GATES)}"
            )
        self.basis = basis

    # ─── Core decomposition ─────────────────────────────────────

    def angles(self, unitary) -> dict:
        """Return the Euler angles for a 2×2 unitary.

        Returns:
            dict with keys ``theta``, ``phi``, ``lam``, ``phase``.
        """
        U = np.array(unitary, dtype=complex)
        if U.shape != (2, 2):
            raise ValueError(f"Expected 2×2 matrix, got shape {U.shape}")

        # Extract global phase and normalise to SU(2)
        det = np.linalg.det(U)
        phase = float(np.angle(det) / 2)
        U_su2 = U * np.exp(-1j * phase)

        # ZYZ decomposition:
        #   U = e^{iγ} Rz(φ) Ry(θ) Rz(λ)
        #     = e^{iγ} [[cos(θ/2) e^{-i(φ+λ)/2}, -sin(θ/2) e^{-i(φ-λ)/2}],
        #               [sin(θ/2) e^{ i(φ-λ)/2},  cos(θ/2) e^{ i(φ+λ)/2}]]

        coeff = min(abs(U_su2[0, 0]), 1.0)
        theta = 2.0 * np.arccos(coeff)

        if abs(np.sin(theta / 2)) < DEFAULT_ATOL:
            # θ ≈ 0 → U ≈ Rz(φ+λ)
            phi_plus_lam = -2.0 * np.angle(U_su2[0, 0])
            phi = phi_plus_lam
            lam = 0.0
        elif abs(np.cos(theta / 2)) < DEFAULT_ATOL:
            # θ ≈ π
            phi_minus_lam = 2.0 * np.angle(U_su2[1, 0])
            phi = phi_minus_lam
            lam = 0.0
        else:
            phi_plus_lam = -2.0 * np.angle(U_su2[0, 0])
            phi_minus_lam = 2.0 * np.angle(U_su2[1, 0])
            phi = (phi_plus_lam + phi_minus_lam) / 2
            lam = (phi_plus_lam - phi_minus_lam) / 2

        return {
            "theta": float(theta),
            "phi":   float(phi),
            "lam":   float(lam),
            "phase": float(phase),
        }

    def angles_and_phase(self, unitary):
        """Return ``(theta, phi, lam, phase)`` tuple."""
        a = self.angles(unitary)
        return a["theta"], a["phi"], a["lam"], a["phase"]

    # ─── Build a QuantumCircuit ─────────────────────────────────

    def __call__(self, unitary):
        """Decompose a 2×2 unitary and return apython
        :class:`~zena.circuit.QuantumCircuit`.

        Args:
            unitary: A 2×2 unitary matrix.

        Returns:
            QuantumCircuit: A 1-qubit circuit implementing the unitary.
        """
        from zena.circuit import QuantumCircuit

        a = self.angles(unitary)
        theta, phi, lam = a["theta"], a["phi"], a["lam"]

        qc = QuantumCircuit(1)
        qc._global_phase = a["phase"]

        if self.basis in ("U3", "U"):
            # Single U gate
            if abs(theta) > DEFAULT_ATOL or abs(phi) > DEFAULT_ATOL or abs(lam) > DEFAULT_ATOL:
                qc.u(theta, phi, lam, 0)

        elif self.basis == "ZYZ":
            if abs(lam) > DEFAULT_ATOL:
                qc.rz(lam, 0)
            if abs(theta) > DEFAULT_ATOL:
                qc.ry(theta, 0)
            if abs(phi) > DEFAULT_ATOL:
                qc.rz(phi, 0)

        elif self.basis == "ZXZ":
            if abs(lam) > DEFAULT_ATOL:
                qc.rz(lam, 0)
            if abs(theta) > DEFAULT_ATOL:
                qc.rx(theta, 0)
            if abs(phi) > DEFAULT_ATOL:
                qc.rz(phi, 0)

        elif self.basis == "XYX":
            if abs(lam) > DEFAULT_ATOL:
                qc.rx(lam, 0)
            if abs(theta) > DEFAULT_ATOL:
                qc.ry(theta, 0)
            if abs(phi) > DEFAULT_ATOL:
                qc.rx(phi, 0)

        elif self.basis == "PSX":
            # P(lam) · SX · P(theta + pi) · SX · P(phi + pi)
            if abs(lam) > DEFAULT_ATOL:
                qc.p(lam, 0)
            if abs(theta) > DEFAULT_ATOL or True:
                qc.sx(0)
                qc.p(theta + math.pi, 0)
                qc.sx(0)
            if abs(phi) > DEFAULT_ATOL:
                qc.p(phi + math.pi, 0)

        elif self.basis == "ZSX":
            if abs(lam) > DEFAULT_ATOL:
                qc.rz(lam, 0)
            if abs(theta) > DEFAULT_ATOL:
                qc.sx(0)
                qc.rz(theta + math.pi, 0)
                qc.sx(0)
            if abs(phi) > DEFAULT_ATOL:
                qc.rz(phi, 0)

        return qc

    def __repr__(self):
        return f"OneQubitEulerDecomposer(basis='{self.basis}')"
