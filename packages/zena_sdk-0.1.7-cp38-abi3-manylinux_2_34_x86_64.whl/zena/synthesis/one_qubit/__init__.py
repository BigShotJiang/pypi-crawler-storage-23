"""
Single-qubit unitary synthesis.

Matches Qiskit's ``qiskit.synthesis.one_qubit`` module.

Classes:
    OneQubitEulerDecomposer - Decompose 1-qubit unitaries into Euler rotations

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/synthesize-unitary-operators
"""
from .one_qubit_decompose import OneQubitEulerDecomposer

__all__ = ["OneQubitEulerDecomposer"]
