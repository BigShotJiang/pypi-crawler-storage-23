"""Synthesis module for quantum circuits.

Decomposes unitary matrices into quantum gate sequences.
Matches Qiskit's ``qiskit/synthesis/`` top-level package structure.

Sub-modules:
    one_qubit/  - Single-qubit unitary synthesis
    two_qubit/  - Two-qubit unitary synthesis
    unitary/    - General unitary synthesis

Classes:
    UnitaryGate              - Gate defined by an arbitrary unitary matrix
    OneQubitEulerDecomposer  - Euler decomposition of 1-qubit unitaries
    TwoQubitBasisDecomposer  - KAK decomposition of 2-qubit unitaries

Functions:
    decompose_single_qubit           - ZYZ angles for a 2×2 unitary
    decompose_two_qubit_cx_count     - CX count estimate for a 4×4 unitary
    synthesize_unitary               - Synthesize any unitary to gate list

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/synthesize-unitary-operators
"""
from .unitary_synthesis import (
    UnitaryGate,
    decompose_single_qubit,
    decompose_two_qubit_cx_count,
    synthesize_unitary,
)
from .one_qubit import OneQubitEulerDecomposer
from .two_qubit import TwoQubitBasisDecomposer

__all__ = [
    "UnitaryGate",
    "decompose_single_qubit",
    "decompose_two_qubit_cx_count",
    "synthesize_unitary",
    "OneQubitEulerDecomposer",
    "TwoQubitBasisDecomposer",
]
