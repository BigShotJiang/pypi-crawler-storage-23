"""Exceptions for Zena SDK.

Matches Qiskit's ``qiskit/exceptions.py`` top-level structure.
"""
from .errors import ValidationError


class ZenaError(Exception):
    """Base class for errors raised by the Zena SDK."""
    pass


class QiskitError(ZenaError):
    """Alias for Qiskit-compatible error handling."""
    pass


__all__ = ["ZenaError", "QiskitError", "ValidationError"]
