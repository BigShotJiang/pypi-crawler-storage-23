"""
OpenQASM 3 exporter — converts QuantumCircuit objects to QASM 3 text.

Mirrors Qiskit's ``qiskit.qasm3.dumps`` and ``qiskit.qasm3.dump``.
"""
from __future__ import annotations

import math
import os
from pathlib import Path
from typing import IO, Optional, Sequence, Union

from .exceptions import QASM3ExportError


def _format_params(params) -> str:
    """Format gate parameters for QASM 3 output."""
    if not params:
        return ""
    formatted = []
    for p in params:
        if isinstance(p, float):
            if abs(p - math.pi) < 1e-15:
                formatted.append("pi")
            elif abs(p + math.pi) < 1e-15:
                formatted.append("-pi")
            elif abs(p - math.pi / 2) < 1e-15:
                formatted.append("pi/2")
            elif abs(p - math.pi / 4) < 1e-15:
                formatted.append("pi/4")
            elif abs(p) < 1e-15:
                formatted.append("0")
            else:
                formatted.append(f"{p:.15g}")
        else:
            formatted.append(str(p))
    return "(" + ", ".join(formatted) + ")"


def _get_qubit_label(index: int, qregs) -> str:
    """Convert a global qubit index to 'regname[idx]' form."""
    offset = 0
    for reg in qregs:
        if index < offset + reg.size:
            return f"{reg.name}[{index - offset}]"
        offset += reg.size
    return f"q[{index}]"


def _get_clbit_label(index: int, cregs) -> str:
    """Convert a global clbit index to 'regname[idx]' form."""
    offset = 0
    for reg in cregs:
        if index < offset + reg.size:
            return f"{reg.name}[{index - offset}]"
        offset += reg.size
    return f"c[{index}]"


def dumps(
    circuit,
    *,
    includes: Optional[Sequence[str]] = None,
    basis_gates: Optional[Sequence[str]] = None,
    indent: str = "  ",
) -> str:
    """Export a QuantumCircuit to an OpenQASM 3 string.

    Args:
        circuit: The QuantumCircuit to export.
        includes: List of include files (default: ["stdgates.inc"]).
        basis_gates: Basis gates to define (default: ["U"]).
        indent: Indentation string for nested blocks.

    Returns:
        The OpenQASM 3 representation as a string.

    Example::

        from zena import QuantumCircuit
        from zena.qasm3 import dumps

        qc = QuantumCircuit(2)
        qc.h(0)
        qc.cx(0, 1)
        qc.measure_all()
        print(dumps(qc))
    """
    if includes is None:
        includes = ["stdgates.inc"]

    lines = []
    lines.append("OPENQASM 3.0;")

    # Include files
    for inc in includes:
        lines.append(f'include "{inc}";')

    # Classical register declarations (bits come first in QASM 3)
    if circuit._cregs:
        for reg in circuit._cregs:
            lines.append(f"bit[{reg.size}] {reg.name};")
    elif circuit.n_clbits > 0:
        lines.append(f"bit[{circuit.n_clbits}] meas;")

    # Quantum register declarations
    if circuit._qregs:
        for reg in circuit._qregs:
            lines.append(f"qubit[{reg.size}] {reg.name};")
    elif circuit.n_qubits > 0:
        lines.append(f"qubit[{circuit.n_qubits}] q;")

    # Instructions
    for inst in circuit._instructions:
        name = inst.name

        # Gate name aliases
        if name == "cnot":
            name = "cx"

        if name == "barrier":
            if inst.qubits:
                qubit_labels = ", ".join(
                    _get_qubit_label(q, circuit._qregs) if circuit._qregs
                    else f"q[{q}]"
                    for q in inst.qubits
                )
                lines.append(f"barrier {qubit_labels};")
            else:
                lines.append("barrier;")
            continue

        if name == "measure":
            q_label = (
                _get_qubit_label(inst.qubits[0], circuit._qregs)
                if circuit._qregs else f"q[{inst.qubits[0]}]"
            )
            if inst.clbits:
                c_label = (
                    _get_clbit_label(inst.clbits[0], circuit._cregs)
                    if circuit._cregs else f"meas[{inst.clbits[0]}]"
                )
                lines.append(f"{c_label} = measure {q_label};")
            else:
                lines.append(f"measure {q_label};")
            continue

        if name == "reset":
            q_label = (
                _get_qubit_label(inst.qubits[0], circuit._qregs)
                if circuit._qregs else f"q[{inst.qubits[0]}]"
            )
            lines.append(f"reset {q_label};")
            continue

        # Control flow (serialized as comments for structural awareness)
        if name in ("if_else", "for_loop", "while_loop", "switch_case"):
            lines.append(f"// {name} block (see circuit object for details)")
            continue

        # Regular gate
        params_str = _format_params(inst.params)
        qubit_labels = ", ".join(
            _get_qubit_label(q, circuit._qregs) if circuit._qregs
            else f"q[{q}]"
            for q in inst.qubits
        )
        lines.append(f"{name}{params_str} {qubit_labels};")

    return "\n".join(lines) + "\n"


def dump(
    circuit,
    file: Union[str, os.PathLike, IO],
    **kwargs,
) -> None:
    """Export a QuantumCircuit to an OpenQASM 3 file.

    Args:
        circuit: The QuantumCircuit to export.
        file: Path to the output file, or an open file handle.

    Example::

        from zena import QuantumCircuit
        from zena.qasm3 import dump

        qc = QuantumCircuit(2)
        qc.h(0)
        qc.cx(0, 1)
        qc.measure_all()
        with open("my_file.qasm", "w") as f:
            dump(qc, f)
    """
    program = dumps(circuit, **kwargs)
    if hasattr(file, "write"):
        file.write(program)
    else:
        Path(file).write_text(program, encoding="utf-8")
