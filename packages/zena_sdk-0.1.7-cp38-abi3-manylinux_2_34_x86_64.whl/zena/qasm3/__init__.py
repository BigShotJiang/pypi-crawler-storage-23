"""
OpenQASM 3 interoperability for the Zena SDK.

Provides functions to import and export quantum circuits in OpenQASM 3 format,
matching Qiskit's ``qiskit.qasm3`` API.

Functions:
    loads(program)      Parse OpenQASM 3 from a string → QuantumCircuit
    load(filename)      Parse OpenQASM 3 from a file → QuantumCircuit
    dumps(circuit)      Export QuantumCircuit → OpenQASM 3 string
    dump(circuit, file) Export QuantumCircuit → OpenQASM 3 file

Classes:
    QASM3Error          Base exception for QASM 3 errors
    QASM3ImportError    Exception for QASM 3 import errors
    QASM3ExportError    Exception for QASM 3 export errors

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/interoperate-qiskit-qasm3
    https://openqasm.com/
"""
from .parse import loads, load
from .export import dumps, dump
from .exceptions import QASM3Error, QASM3ImportError, QASM3ExportError

__all__ = [
    "loads", "load", "dumps", "dump",
    "QASM3Error", "QASM3ImportError", "QASM3ExportError",
]
