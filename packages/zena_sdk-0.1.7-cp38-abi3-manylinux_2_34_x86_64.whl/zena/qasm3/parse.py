"""
OpenQASM 3 parser — converts QASM 3 text into QuantumCircuit objects.

This module implements a pure-Python parser for a subset of OpenQASM 3
programs, following the specification at https://openqasm.com/.

Mirrors Qiskit's ``qiskit.qasm3.loads`` and ``qiskit.qasm3.load``.

Supported features:
  - Version header: ``OPENQASM 3.0;`` or ``OPENQASM 3;``
  - Include: ``include "stdgates.inc";``
  - Qubit declarations: ``qubit[n] q;``
  - Bit declarations: ``bit[n] c;``
  - Standard gates (from stdgates.inc)
  - Measurements: ``c = measure q;`` and ``measure q -> c;`` and ``c[i] = measure q[i];``
  - Barrier, reset
  - Classical if/else (basic form)
  - For loops (basic form)
  - While loops (basic form)
  - Gate definitions
  - Const declarations
  - Input/output declarations (parsed but stored as metadata)
"""
from __future__ import annotations

import math
import os
import re
from pathlib import Path
from typing import Any, Iterable, Optional, Union

from .exceptions import QASM3ImportError

# Standard gates from stdgates.inc
# https://openqasm.com/language/standard_library.html
STDGATES = {
    "id": (0, 1), "x": (0, 1), "y": (0, 1), "z": (0, 1),
    "h": (0, 1), "s": (0, 1), "sdg": (0, 1),
    "t": (0, 1), "tdg": (0, 1),
    "sx": (0, 1), "sxdg": (0, 1),
    "rx": (1, 1), "ry": (1, 1), "rz": (1, 1),
    "cx": (0, 2), "cnot": (0, 2), "cy": (0, 2), "cz": (0, 2),
    "cp": (1, 2), "swap": (0, 2), "ccx": (0, 3),
    "crx": (1, 2), "cry": (1, 2), "crz": (1, 2),
    "ch": (0, 2), "cswap": (0, 3),
    "rxx": (1, 2), "ryy": (1, 2), "rzz": (1, 2),
    "u1": (1, 1), "u2": (2, 1), "u3": (3, 1), "u": (3, 1),
    "p": (1, 1),
    "U": (3, 1),
}

# ---------------------------------------------------------------------------
# Tokenizer (compatible with QASM 3 syntax)
# ---------------------------------------------------------------------------

_TOKEN_PATTERNS = [
    ("COMMENT_LINE",  r"//[^\n]*"),
    ("COMMENT_BLOCK", r"/\*[\s\S]*?\*/"),
    ("REAL",          r"\d+\.\d*([eE][+-]?\d+)?|\d+[eE][+-]?\d+"),
    ("INT",           r"\d+"),
    ("STRING",        r'"[^"]*"'),
    ("HARDWARE_Q",    r"\$\d+"),
    ("ARROW",         r"->"),
    ("EQUALS",        r"=="),
    ("ASSIGN",        r"="),
    ("IDENT",         r"[a-zA-Z_][a-zA-Z0-9_]*"),
    ("LBRACKET",      r"\["),
    ("RBRACKET",      r"\]"),
    ("LBRACE",        r"\{"),
    ("RBRACE",        r"\}"),
    ("LPAREN",        r"\("),
    ("RPAREN",        r"\)"),
    ("SEMICOLON",     r";"),
    ("COMMA",         r","),
    ("COLON",         r":"),
    ("AT",            r"@"),
    ("OP",            r"[+\-*/]"),
    ("NEWLINE",       r"\n"),
    ("WHITESPACE",    r"[ \t\r]+"),
]

_TOKEN_RE = re.compile("|".join(
    f"(?P<{name}>{pattern})" for name, pattern in _TOKEN_PATTERNS
))


def _tokenize(source: str):
    """Yield (type, value, line) tokens from QASM 3 source."""
    line = 1
    for m in _TOKEN_RE.finditer(source):
        kind = m.lastgroup
        val = m.group()
        if kind == "NEWLINE":
            line += val.count("\n")
            continue
        if kind in ("WHITESPACE", "COMMENT_LINE", "COMMENT_BLOCK"):
            if kind == "COMMENT_BLOCK":
                line += val.count("\n")
            continue
        yield (kind, val, line)


# ---------------------------------------------------------------------------
# Expression evaluator
# ---------------------------------------------------------------------------

def _eval_expr(tokens, pos):
    """Parse arithmetic expression. Returns (value, pos)."""
    return _add_sub(tokens, pos)


def _add_sub(tokens, pos):
    left, pos = _mul_div(tokens, pos)
    while pos < len(tokens) and tokens[pos][0] == "OP" and tokens[pos][1] in ("+", "-"):
        op = tokens[pos][1]
        pos += 1
        right, pos = _mul_div(tokens, pos)
        left = left + right if op == "+" else left - right
    return left, pos


def _mul_div(tokens, pos):
    left, pos = _unary(tokens, pos)
    while pos < len(tokens) and tokens[pos][0] == "OP" and tokens[pos][1] in ("*", "/"):
        op = tokens[pos][1]
        pos += 1
        right, pos = _unary(tokens, pos)
        left = left * right if op == "*" else left / right
    return left, pos


def _unary(tokens, pos):
    if pos < len(tokens) and tokens[pos][0] == "OP" and tokens[pos][1] == "-":
        pos += 1
        val, pos = _atom(tokens, pos)
        return -val, pos
    return _atom(tokens, pos)


_BUILTINS = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "exp": math.exp, "ln": math.log, "sqrt": math.sqrt,
    "acos": math.acos, "asin": math.asin, "atan": math.atan,
    "ceiling": math.ceil, "floor": math.floor,
    "mod": lambda a, b: a % b,
}


def _atom(tokens, pos):
    if pos >= len(tokens):
        raise QASM3ImportError("Unexpected end of expression")

    kind, val, line = tokens[pos]

    if kind in ("REAL", "INT"):
        return float(val), pos + 1

    if kind == "LPAREN":
        pos += 1
        result, pos = _add_sub(tokens, pos)
        if pos < len(tokens) and tokens[pos][0] == "RPAREN":
            pos += 1
        return result, pos

    if kind == "IDENT":
        if val == "pi" or val == "π":
            return math.pi, pos + 1
        if val == "tau" or val == "τ":
            return math.tau, pos + 1
        if val == "euler" or val == "ℇ":
            return math.e, pos + 1

        if val in _BUILTINS:
            func = _BUILTINS[val]
            pos += 1
            if pos < len(tokens) and tokens[pos][0] == "LPAREN":
                pos += 1
                arg, pos = _add_sub(tokens, pos)
                if pos < len(tokens) and tokens[pos][0] == "RPAREN":
                    pos += 1
                return func(arg), pos

        # Unknown identifier, treat as 0
        return 0.0, pos + 1

    raise QASM3ImportError(f"Unexpected token in expression: {val!r} at line {line}")


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def _parse_params(tokens, pos):
    """Parse parenthesized parameter list. Returns ([params], pos)."""
    params = []
    if pos < len(tokens) and tokens[pos][0] == "LPAREN":
        pos += 1
        while pos < len(tokens) and tokens[pos][0] != "RPAREN":
            val, pos = _eval_expr(tokens, pos)
            params.append(val)
            if pos < len(tokens) and tokens[pos][0] == "COMMA":
                pos += 1
        if pos < len(tokens) and tokens[pos][0] == "RPAREN":
            pos += 1
    return params, pos


def _parse_qubit_ref(tokens, pos, qregs):
    """Parse a qubit reference like q[0], q, or $0. Returns ([indices], pos)."""
    qubits = []

    if tokens[pos][0] == "HARDWARE_Q":
        # $N hardware qubit
        idx = int(tokens[pos][1][1:])
        qubits.append(idx)
        return qubits, pos + 1

    if tokens[pos][0] != "IDENT":
        return qubits, pos

    reg_name = tokens[pos][1]
    pos += 1

    if pos < len(tokens) and tokens[pos][0] == "LBRACKET":
        pos += 1  # skip [
        # Could be single index or a range/set
        if pos < len(tokens) and tokens[pos][0] == "LBRACE":
            # Set: {0, 1, 2}
            pos += 1
            while pos < len(tokens) and tokens[pos][0] != "RBRACE":
                if tokens[pos][0] == "INT":
                    idx = int(tokens[pos][1])
                    offset = 0
                    for rname, rsize in qregs:
                        if rname == reg_name:
                            qubits.append(offset + idx)
                            break
                        offset += rsize
                pos += 1
            pos += 1  # skip }
        else:
            # Single index or range
            start_idx = int(tokens[pos][1])
            pos += 1
            if pos < len(tokens) and tokens[pos][0] == "COLON":
                # Range: [start:end]
                pos += 1
                end_idx = int(tokens[pos][1])
                pos += 1
                offset = 0
                for rname, rsize in qregs:
                    if rname == reg_name:
                        for i in range(start_idx, end_idx):
                            qubits.append(offset + i)
                        break
                    offset += rsize
            else:
                offset = 0
                for rname, rsize in qregs:
                    if rname == reg_name:
                        qubits.append(offset + start_idx)
                        break
                    offset += rsize
        if pos < len(tokens) and tokens[pos][0] == "RBRACKET":
            pos += 1  # skip ]

        # Handle chained indexing: q[{1,2}][0]
        if pos < len(tokens) and tokens[pos][0] == "LBRACKET":
            pos += 1
            chain_idx = int(tokens[pos][1])
            pos += 1
            if pos < len(tokens) and tokens[pos][0] == "RBRACKET":
                pos += 1
            if chain_idx < len(qubits):
                qubits = [qubits[chain_idx]]
    else:
        # Whole register
        offset = 0
        for rname, rsize in qregs:
            if rname == reg_name:
                for i in range(rsize):
                    qubits.append(offset + i)
                break
            offset += rsize

    return qubits, pos


def _parse_qubit_list(tokens, pos, qregs):
    """Parse comma-separated qubit references. Returns ([indices], pos)."""
    qubits = []
    while pos < len(tokens) and tokens[pos][0] not in ("SEMICOLON", "ARROW", "LBRACE", "ASSIGN"):
        refs, pos = _parse_qubit_ref(tokens, pos, qregs)
        qubits.extend(refs)
        if pos < len(tokens) and tokens[pos][0] == "COMMA":
            pos += 1
        elif pos < len(tokens) and tokens[pos][0] not in ("SEMICOLON", "ARROW", "IDENT", "HARDWARE_Q", "LBRACE", "ASSIGN"):
            break
    return qubits, pos


def _skip_block(tokens, pos):
    """Skip a brace-delimited block. Returns pos after }."""
    if pos < len(tokens) and tokens[pos][0] == "LBRACE":
        depth = 1
        pos += 1
        while pos < len(tokens) and depth > 0:
            if tokens[pos][0] == "LBRACE":
                depth += 1
            elif tokens[pos][0] == "RBRACE":
                depth -= 1
            pos += 1
    return pos


def loads(program: str) -> "QuantumCircuit":
    """Parse an OpenQASM 3 program from a string into a QuantumCircuit.

    Args:
        program: The OpenQASM 3 program as a string.

    Returns:
        A QuantumCircuit representing the parsed program.

    Example::

        import zena.qasm3

        program = '''
        OPENQASM 3.0;
        include "stdgates.inc";
        qubit[2] q;
        bit[2] c;
        h q[0];
        cx q[0], q[1];
        c = measure q;
        '''
        circuit = zena.qasm3.loads(program)
    """
    from ..circuit.quantum_circuit import QuantumCircuit
    from ..ir.types import Instruction

    known_gates = dict(STDGATES)
    tokens = list(_tokenize(program))
    pos = 0

    # State
    qregs = []   # [(name, size), ...]
    cregs = []
    total_qubits = 0
    total_clbits = 0
    instructions = []
    constants = {}
    inputs = {}
    outputs = {}
    aliases = {}

    def _skip_semicolon():
        nonlocal pos
        while pos < len(tokens) and tokens[pos][0] == "SEMICOLON":
            pos += 1

    while pos < len(tokens):
        kind, val, line = tokens[pos]

        # Version header
        if kind == "IDENT" and val == "OPENQASM":
            pos += 1
            while pos < len(tokens) and tokens[pos][0] != "SEMICOLON":
                pos += 1
            _skip_semicolon()
            continue

        # Include
        if kind == "IDENT" and val == "include":
            pos += 1
            if pos < len(tokens) and tokens[pos][0] == "STRING":
                pos += 1
            _skip_semicolon()
            continue

        # Qubit declaration: qubit[n] name; or qubit name;
        if kind == "IDENT" and val == "qubit":
            pos += 1
            reg_size = 1
            if pos < len(tokens) and tokens[pos][0] == "LBRACKET":
                pos += 1
                reg_size = int(tokens[pos][1])
                pos += 1
                pos += 1  # skip ]
            reg_name = tokens[pos][1]
            pos += 1
            qregs.append((reg_name, reg_size))
            total_qubits += reg_size
            _skip_semicolon()
            continue

        # Bit declaration: bit[n] name; or bit name;
        if kind == "IDENT" and val == "bit":
            pos += 1
            reg_size = 1
            if pos < len(tokens) and tokens[pos][0] == "LBRACKET":
                pos += 1
                reg_size = int(tokens[pos][1])
                pos += 1
                pos += 1  # skip ]
            reg_name = tokens[pos][1]
            pos += 1
            cregs.append((reg_name, reg_size))
            total_clbits += reg_size
            _skip_semicolon()
            continue

        # Const declaration: const type value = expr;
        if kind == "IDENT" and val == "const":
            pos += 1
            # Skip type
            while pos < len(tokens) and tokens[pos][0] not in ("IDENT",) or tokens[pos][1] in ("int", "float", "uint", "bool"):
                pos += 1
            const_name = tokens[pos][1]
            pos += 1
            if pos < len(tokens) and tokens[pos][0] == "ASSIGN":
                pos += 1
                const_val, pos = _eval_expr(tokens, pos)
                constants[const_name] = const_val
            _skip_semicolon()
            continue

        # Input declaration: input type name;
        if kind == "IDENT" and val == "input":
            pos += 1
            input_type = ""
            while pos < len(tokens) and tokens[pos][0] == "IDENT":
                input_type = tokens[pos][1]
                pos += 1
                if pos < len(tokens) and tokens[pos][0] == "LBRACKET":
                    pos += 1
                    while pos < len(tokens) and tokens[pos][0] != "RBRACKET":
                        pos += 1
                    pos += 1  # skip ]
            _skip_semicolon()
            continue

        # Output declaration: output type name;
        if kind == "IDENT" and val == "output":
            pos += 1
            while pos < len(tokens) and tokens[pos][0] != "SEMICOLON":
                pos += 1
            _skip_semicolon()
            continue

        # Let alias: let name = q[0:2];
        if kind == "IDENT" and val == "let":
            pos += 1
            alias_name = tokens[pos][1]
            pos += 1
            if pos < len(tokens) and tokens[pos][0] == "ASSIGN":
                pos += 1
                alias_qubits, pos = _parse_qubit_ref(tokens, pos, qregs)
                aliases[alias_name] = alias_qubits
            _skip_semicolon()
            continue

        # Gate definition: gate name(params) qubits { ... }
        if kind == "IDENT" and val == "gate":
            pos += 1
            gate_name = tokens[pos][1]
            pos += 1
            nparams = 0
            if pos < len(tokens) and tokens[pos][0] == "LPAREN":
                pos += 1
                while pos < len(tokens) and tokens[pos][0] != "RPAREN":
                    if tokens[pos][0] == "IDENT":
                        nparams += 1
                    pos += 1
                pos += 1  # skip )
            nqubits = 0
            while pos < len(tokens) and tokens[pos][0] != "LBRACE":
                if tokens[pos][0] == "IDENT":
                    nqubits += 1
                pos += 1
            pos = _skip_block(tokens, pos)
            if gate_name not in known_gates:
                known_gates[gate_name] = (nparams, nqubits)
            continue

        # Barrier
        if kind == "IDENT" and val == "barrier":
            pos += 1
            qubits, pos = _parse_qubit_list(tokens, pos, qregs)
            instructions.append(Instruction(
                name="barrier",
                qubits=tuple(qubits),
                clbits=(),
                params=(),
            ))
            _skip_semicolon()
            continue

        # Reset
        if kind == "IDENT" and val == "reset":
            pos += 1
            qubits, pos = _parse_qubit_list(tokens, pos, qregs)
            for q in qubits:
                instructions.append(Instruction(
                    name="reset",
                    qubits=(q,),
                    clbits=(),
                    params=(),
                ))
            _skip_semicolon()
            continue

        # Measure (QASM 3 style: bit = measure qubit;)
        if kind == "IDENT" and val == "measure":
            pos += 1
            qubits, pos = _parse_qubit_list(tokens, pos, qregs)
            # Check for -> (QASM 2 style in QASM 3)
            if pos < len(tokens) and tokens[pos][0] == "ARROW":
                pos += 1
                # Parse classical bits
                clbits = []
                while pos < len(tokens) and tokens[pos][0] != "SEMICOLON":
                    if tokens[pos][0] == "IDENT":
                        c_name = tokens[pos][1]
                        pos += 1
                        if pos < len(tokens) and tokens[pos][0] == "LBRACKET":
                            pos += 1
                            c_idx = int(tokens[pos][1])
                            pos += 1
                            pos += 1  # skip ]
                            c_offset = 0
                            for rname, rsize in cregs:
                                if rname == c_name:
                                    clbits.append(c_offset + c_idx)
                                    break
                                c_offset += rsize
                        else:
                            c_offset = 0
                            for rname, rsize in cregs:
                                if rname == c_name:
                                    for i in range(rsize):
                                        clbits.append(c_offset + i)
                                    break
                                c_offset += rsize
                    if pos < len(tokens) and tokens[pos][0] == "COMMA":
                        pos += 1
                    elif pos < len(tokens) and tokens[pos][0] != "IDENT":
                        break
                for q, c in zip(qubits, clbits):
                    instructions.append(Instruction(
                        name="measure", qubits=(q,), clbits=(c,), params=(),
                    ))
            else:
                # Standalone measure: measure q; (result discarded or handled by assignment)
                for q in qubits:
                    instructions.append(Instruction(
                        name="measure", qubits=(q,), clbits=(), params=(),
                    ))
            _skip_semicolon()
            continue

        # If statement: if (condition) { ... } else { ... }
        if kind == "IDENT" and val == "if":
            pos += 1
            # Skip condition — store as instruction
            if pos < len(tokens) and tokens[pos][0] == "LPAREN":
                pos += 1
                cond_depth = 1
                while pos < len(tokens) and cond_depth > 0:
                    if tokens[pos][0] == "LPAREN":
                        cond_depth += 1
                    elif tokens[pos][0] == "RPAREN":
                        cond_depth -= 1
                    pos += 1
            # Skip body
            pos = _skip_block(tokens, pos)
            # Check for else
            if pos < len(tokens) and tokens[pos][0] == "IDENT" and tokens[pos][1] == "else":
                pos += 1
                pos = _skip_block(tokens, pos)
            # Record as if_else instruction
            instructions.append(Instruction(
                name="if_else", qubits=(), clbits=(), params=(),
            ))
            continue

        # For loop: for int k in [0:n-1] { ... }
        if kind == "IDENT" and val == "for":
            pos += 1
            while pos < len(tokens) and tokens[pos][0] != "LBRACE":
                pos += 1
            pos = _skip_block(tokens, pos)
            instructions.append(Instruction(
                name="for_loop", qubits=(), clbits=(), params=(),
            ))
            continue

        # While loop: while (cond) { ... }
        if kind == "IDENT" and val == "while":
            pos += 1
            if pos < len(tokens) and tokens[pos][0] == "LPAREN":
                pos += 1
                cond_depth = 1
                while pos < len(tokens) and cond_depth > 0:
                    if tokens[pos][0] == "LPAREN":
                        cond_depth += 1
                    elif tokens[pos][0] == "RPAREN":
                        cond_depth -= 1
                    pos += 1
            pos = _skip_block(tokens, pos)
            instructions.append(Instruction(
                name="while_loop", qubits=(), clbits=(), params=(),
            ))
            continue

        # Assignment: name[idx] = measure q[idx]; or name = measure q;
        if kind == "IDENT" and pos + 1 < len(tokens):
            # Peek ahead for assignment
            save_pos = pos
            potential_name = val
            pos += 1
            # Check for indexing
            clbit_indices = []
            if pos < len(tokens) and tokens[pos][0] == "LBRACKET":
                pos += 1
                c_idx = int(tokens[pos][1])
                pos += 1
                pos += 1  # skip ]
                c_offset = 0
                for rname, rsize in cregs:
                    if rname == potential_name:
                        clbit_indices.append(c_offset + c_idx)
                        break
                    c_offset += rsize
            elif potential_name in [rname for rname, _ in cregs]:
                c_offset = 0
                for rname, rsize in cregs:
                    if rname == potential_name:
                        for i in range(rsize):
                            clbit_indices.append(c_offset + i)
                        break
                    c_offset += rsize

            if pos < len(tokens) and tokens[pos][0] == "ASSIGN":
                pos += 1  # skip =
                if pos < len(tokens) and tokens[pos][0] == "IDENT" and tokens[pos][1] == "measure":
                    pos += 1
                    qubits, pos = _parse_qubit_list(tokens, pos, qregs)
                    for q, c in zip(qubits, clbit_indices or range(len(qubits))):
                        instructions.append(Instruction(
                            name="measure", qubits=(q,), clbits=(c,), params=(),
                        ))
                    _skip_semicolon()
                    continue
                else:
                    # Other assignment, skip to semicolon
                    while pos < len(tokens) and tokens[pos][0] != "SEMICOLON":
                        pos += 1
                    _skip_semicolon()
                    continue

            # Not an assignment — might be a gate
            pos = save_pos

        # Gate application or gate modifier
        if kind == "IDENT" and val in ("ctrl", "negctrl", "inv", "pow"):
            # Gate modifier — skip @, then parse gate
            pos += 1
            if pos < len(tokens) and tokens[pos][0] == "AT":
                pos += 1
            # Recurse to parse modified gate
            continue

        # Standard or custom gate instruction
        if kind == "IDENT":
            gate_name = val

            # Check aliases
            if gate_name in aliases:
                # Using an alias as a qubit in another gate call
                # This is handled by look-ahead; continue
                pass

            if gate_name in known_gates or gate_name == "gphase":
                pos += 1
                params, pos = _parse_params(tokens, pos)

                if gate_name == "gphase":
                    # Global phase — skip
                    _skip_semicolon()
                    continue

                qubits, pos = _parse_qubit_list(tokens, pos, qregs)

                # Resolve alias references
                resolved_qubits = []
                for q in qubits:
                    resolved_qubits.append(q)

                instructions.append(Instruction(
                    name=gate_name if gate_name != "cnot" else "cx",
                    qubits=tuple(resolved_qubits),
                    clbits=(),
                    params=tuple(params),
                ))
                _skip_semicolon()
                continue

            # Unknown identifier — try to skip
            pos += 1
            # If followed by qubit args, parse them
            if pos < len(tokens) and tokens[pos][0] in ("LPAREN", "IDENT", "HARDWARE_Q"):
                params, pos = _parse_params(tokens, pos)
                qubits, pos = _parse_qubit_list(tokens, pos, qregs)
                if qubits:
                    instructions.append(Instruction(
                        name=gate_name,
                        qubits=tuple(qubits),
                        clbits=(),
                        params=tuple(params),
                    ))
            _skip_semicolon()
            continue

        # Skip unknown tokens
        pos += 1

    # Build QuantumCircuit
    qc = QuantumCircuit(total_qubits, total_clbits)
    qc._instructions = instructions

    from ..circuit.register import QuantumRegister, ClassicalRegister
    qc._qregs = [QuantumRegister(sz, name) for name, sz in qregs]
    qc._cregs = [ClassicalRegister(sz, name) for name, sz in cregs]

    return qc


def load(filename: Union[str, os.PathLike]) -> "QuantumCircuit":
    """Parse an OpenQASM 3 program from a file into a QuantumCircuit.

    Args:
        filename: Path to the OpenQASM 3 file.

    Returns:
        A QuantumCircuit representing the parsed program.
    """
    path = Path(filename)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")
    program = path.read_text(encoding="utf-8")
    return loads(program)
