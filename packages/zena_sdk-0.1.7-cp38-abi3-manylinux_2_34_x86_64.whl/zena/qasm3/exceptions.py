"""Exceptions for OpenQASM 3 operations."""


class QASM3Error(Exception):
    """Base exception for OpenQASM 3 errors."""
    pass


class QASM3ImportError(QASM3Error):
    """Exception raised when importing OpenQASM 3 fails."""
    pass


class QASM3ExportError(QASM3Error):
    """Exception raised when exporting to OpenQASM 3 fails."""
    pass
