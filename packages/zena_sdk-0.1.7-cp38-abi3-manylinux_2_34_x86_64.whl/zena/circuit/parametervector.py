"""Parameter vector for batched symbolic parameters.

Re-exports from parameter.py for Qiskit-compatible import paths.
Matches Qiskit's ``qiskit/circuit/parametervector.py``.
"""
from .parameter import ParameterVector

__all__ = ["ParameterVector"]
