"""
Circuit Library - IBM Qiskit Compatible

This module provides a collection of well-known quantum circuits and gates,
following IBM Qiskit's circuit.library structure.

Categories:
- Standard Gates: Common quantum gates (H, X, Y, Z, RX, RY, RZ, etc.)
- Generalized Gates: Custom and composite gates
- Particular Circuits: Bell states, GHZ, QFT, etc.
- N-local Circuits: Variational ansatze (TwoLocal, RealAmplitudes, EfficientSU2, etc.)
- Data Encoding: Feature maps for quantum ML (ZFeatureMap, ZZFeatureMap, etc.)
- Time Evolution: Hamiltonian simulation (PauliEvolutionGate, HamiltonianGate, etc.)
- Arithmetic: Adders, multipliers, comparators for quantum arithmetic
"""

# Standard gates (1-qubit)
from .standard_gates import (
    HGate,
    XGate,
    YGate,
    ZGate,
    IGate,
    SGate,
    SdgGate,
    TGate,
    TdgGate,
    SXGate,
    SXdgGate,
    RXGate,
    RYGate,
    RZGate,
    RGate,
    PhaseGate,
    UGate,
)

# Standard gates (2-qubit)
from .standard_gates import (
    CXGate,
    CYGate,
    CZGate,
    SwapGate,
    CHGate,
)

# Parametric 2-qubit gates
from .standard_gates import (
    CPhaseGate,
    CRXGate,
    CRYGate,
    CRZGate,
    RXXGate,
    RYYGate,
    RZZGate,
    RZXGate,
)

# Standard gates (3-qubit)
from .standard_gates import (
    CCXGate,
    CSwapGate,
    get_standard_gate_name_mapping,  # Function to get gate mapping
)

# Particular quantum circuits
from .particular_circuits import (
    BellState,
    GHZState,
    QFT,
    WState,
)

# N-local circuits (variational algorithms)
from .n_local import (
    NLocal,
    TwoLocal,
    RealAmplitudes,
    EfficientSU2,
    ExcitationPreserving,
    n_local,
)

# Data encoding circuits (quantum machine learning)
from .data_encoding import (
    ZFeatureMap,
    ZZFeatureMap,
    PauliFeatureMap,
    StatePreparation,
    AmplitudeEmbedding,
    AngleEmbedding,
    IQP,
)

# Time-evolution circuits (quantum simulation)
from .time_evolution import (
    SparsePauliOp,
    PauliEvolutionGate,
    HamiltonianGate,
    TrotterQRTE,
    pauli_evolution,
)

# Arithmetic circuits
from .arithmetic import (
    ModularAdderGate,
    HalfAdderGate,
    FullAdderGate,
    DraperQFTAdder,
    CDKMRippleCarryAdder,
    VBERippleCarryAdder,
    MultiplierGate,
    HRSCumulativeMultiplier,
    RGQFTMultiplier,
    IntegerComparator,
    WeightedAdder,
    ExactReciprocal,
    AndGate,
    OrGate,
    BitwiseXorGate,
    LinearPauliRotations,
)

# Benchmarking and complexity-theory circuits
from .benchmarking import (
    QuantumVolume,
    GraphState,
    IQPCircuit,
    GroverOperator,
    FourierChecking,
)


# Fractional gates (IBM Heron QPU)
from .fractional_gates import (
    FractionalRXGate,
    FractionalRZZGate,
    _create_ising_circuit,
    CONVENTIONAL_BASIS_GATES,
    FRACTIONAL_BASIS_GATES,
    HERON_CONVENTIONAL_GATES,
    HERON_FRACTIONAL_GATES,
)

__all__ = [
    # 1-qubit standard gates
    "HGate",
    "XGate",
    "YGate",
    "ZGate",
    "IGate",
    "SGate",
    "SdgGate",
    "TGate",
    "TdgGate",
    "SXGate",
    "SXdgGate",
    "RXGate",
    "RYGate",
    "RZGate",
    "RGate",
    "PhaseGate",
    "UGate",
    # 2-qubit standard gates
    "CXGate",
    "CYGate",
    "CZGate",
    "SwapGate",
    "CHGate",
    # Parametric 2-qubit gates
    "CPhaseGate",
    "CRXGate",
    "CRYGate",
    "CRZGate",
    "RXXGate",
    "RYYGate",
    "RZZGate",
    "RZXGate",
    # 3-qubit standard gates
    "CCXGate",
    "CSwapGate",
    # Functions
    "get_standard_gate_name_mapping",
    # Particular circuits
    "BellState",
    "GHZState",
    "QFT",
    "WState",
    # N-local circuits
    "NLocal",
    "TwoLocal",
    "RealAmplitudes",
    "EfficientSU2",
    "ExcitationPreserving",
    "n_local",
    # Data encoding circuits
    "ZFeatureMap",
    "ZZFeatureMap",
    "PauliFeatureMap",
    "StatePreparation",
    "AmplitudeEmbedding",
    "AngleEmbedding",
    "IQP",
    # Time-evolution circuits
    "SparsePauliOp",
    "PauliEvolutionGate",
    "HamiltonianGate",
    "TrotterQRTE",
    "pauli_evolution",
    # Arithmetic circuits - Adders
    "ModularAdderGate",
    "HalfAdderGate",
    "FullAdderGate",
    "DraperQFTAdder",
    "CDKMRippleCarryAdder",
    "VBERippleCarryAdder",
    # Arithmetic circuits - Multipliers
    "MultiplierGate",
    "HRSCumulativeMultiplier",
    "RGQFTMultiplier",
    # Arithmetic circuits - Other
    "IntegerComparator",
    "WeightedAdder",
    "ExactReciprocal",
    # Boolean logic
    "AndGate",
    "OrGate",
    "BitwiseXorGate",
    # Functional rotations
    "LinearPauliRotations",
    # Benchmarking and complexity
    "QuantumVolume",
    "GraphState",
    "IQPCircuit",
    "GroverOperator",
    "FourierChecking",
    # Fractional gates (Heron QPU)
    "FractionalRXGate",
    "FractionalRZZGate",
    "_create_ising_circuit",
    "CONVENTIONAL_BASIS_GATES",
    "FRACTIONAL_BASIS_GATES",
    "HERON_CONVENTIONAL_GATES",
    "HERON_FRACTIONAL_GATES",
]
