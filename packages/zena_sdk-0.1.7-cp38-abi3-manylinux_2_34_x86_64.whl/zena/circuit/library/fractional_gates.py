"""
Fractional Gates for IBM Heron QPUs.

This module provides fractional gate implementations for direct hardware
execution on IBM Quantum Heron processors. Fractional gates allow execution
of arbitrary-angle rotations directly, avoiding costly decomposition into
basis gates.

Supported fractional gates:
- FractionalRX(theta): Arbitrary-angle X rotation
- FractionalRZZ(theta): Arbitrary-angle ZZ interaction (0 < theta <= pi/2)

Reference: https://quantum.cloud.ibm.com/docs/en/guides/fractional-gates
"""
from __future__ import annotations
import math
import numpy as np
from typing import Optional, List
from .standard_gates import Gate


class FractionalRXGate(Gate):
    """Fractional RX gate for direct hardware execution.

    On IBM Heron QPUs with fractional gate support, this gate executes
    an arbitrary-angle X rotation directly, avoiding decomposition into
    RZ and SX gates. This can reduce circuit duration and error by up
    to a factor of two.

    The matrix representation is identical to RXGate:

        RX(theta) = [[cos(t/2), -i*sin(t/2)],
                      [-i*sin(t/2), cos(t/2)]]

    The difference is at the hardware level: conventional gates decompose
    RX(theta) into multiple SX and RZ gates, while fractional RX executes
    the rotation in a single pulse.

    Args:
        theta: Rotation angle in radians. Any angle is supported.
        label: Optional label for the gate.

    Example::

        from zena.circuit import QuantumCircuit
        from zena.circuit.library import FractionalRXGate

        qc = QuantumCircuit(1)
        qc.append(FractionalRXGate(0.1), [0])
    """

    def __init__(self, theta: float, label: Optional[str] = None):
        super().__init__("frx", 1, [theta])
        self.theta = theta
        self.label = label

    def to_matrix(self) -> np.ndarray:
        t = float(self.theta)
        return np.array([
            [math.cos(t / 2), -1j * math.sin(t / 2)],
            [-1j * math.sin(t / 2), math.cos(t / 2)]
        ], dtype=complex)

    def __repr__(self):
        return "FractionalRXGate(theta=" + str(self.theta) + ")"


class FractionalRZZGate(Gate):
    """Fractional RZZ gate for direct hardware execution.

    On IBM Heron QPUs with fractional gate support, this gate executes
    an arbitrary-angle ZZ rotation directly, avoiding decomposition into
    multiple CZ gates and single-qubit gates.

    **Angle constraint**: Only angles in the range (0, pi/2] can be
    executed on hardware. The FoldRzzAngle transpiler pass handles
    out-of-range angles automatically.

    Matrix:
        RZZ(theta) = diag(e^(-i*t/2), e^(i*t/2), e^(i*t/2), e^(-i*t/2))

    Args:
        theta: Rotation angle in radians. Must be in (0, pi/2] for hardware.
        label: Optional label for the gate.

    Example::

        from zena.circuit import QuantumCircuit
        from zena.circuit.library import FractionalRZZGate

        qc = QuantumCircuit(2)
        qc.append(FractionalRZZGate(0.1), [0, 1])

    Note:
        For parameterized circuits with Parameter objects, the transpiler
        assumes the angle will be within range at runtime. Out-of-range
        values will cause the job to fail.
    """

    ANGLE_MIN = 0.0
    ANGLE_MAX = math.pi / 2

    def __init__(self, theta: float, label: Optional[str] = None):
        super().__init__("frzz", 2, [theta])
        self.theta = theta
        self.label = label

    def validate_angle(self) -> bool:
        """Check if theta is in the valid hardware range (0, pi/2]."""
        from ...circuit.parameter import Parameter, ParameterExpression
        if isinstance(self.theta, (Parameter, ParameterExpression)):
            return True  # Cannot validate symbolic params
        t = float(self.theta)
        return self.ANGLE_MIN < t <= self.ANGLE_MAX + 1e-10

    def to_matrix(self) -> np.ndarray:
        t = float(self.theta)
        e_m = np.exp(-1j * t / 2)
        e_p = np.exp(1j * t / 2)
        return np.diag([e_m, e_p, e_p, e_m]).astype(complex)

    def __repr__(self):
        return "FractionalRZZGate(theta=" + str(self.theta) + ")"


def _create_ising_circuit(num_qubits, num_time_steps, rx_angle, rzz_angle):
    """Create an Ising chain circuit using fractional gates.

    This is the example from IBM's fractional gates documentation.
    The circuit alternates between RX rotation layers and RZZ interaction
    layers to simulate the time evolution of an Ising chain.

    Args:
        num_qubits: Number of qubits in the chain.
        num_time_steps: Number of Trotter steps.
        rx_angle: Angle for RX rotations.
        rzz_angle: Angle for RZZ interactions.

    Returns:
        A QuantumCircuit implementing the Ising chain evolution.

    Example::

        from zena.circuit.library.fractional_gates import _create_ising_circuit
        qc = _create_ising_circuit(5, 3, 0.1, 0.1)
        print(qc.draw())
    """
    from ...circuit.quantum_circuit import QuantumCircuit

    qc = QuantumCircuit(num_qubits, name="ising_chain")

    for step in range(num_time_steps):
        # RX layer on all qubits
        for q in range(num_qubits):
            qc.rx(rx_angle, q)

        # 1st RZZ layer: odd-even pairs
        for q in range(1, num_qubits - 1, 2):
            qc.rzz(rzz_angle, q, q + 1)

        # 2nd RZZ layer: even-odd pairs
        for q in range(0, num_qubits - 1, 2):
            qc.rzz(rzz_angle, q, q + 1)

        qc.barrier()

    return qc


# Conventional (non-fractional) basis gates for IBM QPUs
CONVENTIONAL_BASIS_GATES = ["cz", "x", "rz", "sx", "id"]

# Fractional basis gates for IBM Heron QPUs
FRACTIONAL_BASIS_GATES = ["rx", "rzz", "rz", "id"]

# Heron processor targets
HERON_CONVENTIONAL_GATES = ["cz", "x", "rz", "sx", "id", "measure"]
HERON_FRACTIONAL_GATES = ["rx", "rzz", "rz", "id", "measure"]
