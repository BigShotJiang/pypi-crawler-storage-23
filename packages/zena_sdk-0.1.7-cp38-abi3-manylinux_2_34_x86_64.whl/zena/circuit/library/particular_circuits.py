"""
Particular quantum circuits following IBM Qiskit's circuit library pattern.

This module provides well-known quantum circuits like Bell states, GHZ, QFT, etc.
"""

from typing import Optional
from ..quantum_circuit import QuantumCircuit


class BellState(QuantumCircuit):
    """
    Bell state circuit (IBM Qiskit compatible).
    
    Creates one of the four Bell states (maximally entangled 2-qubit states):
    - |Φ+⟩ = (|00⟩ + |11⟩) / √2  (state=0, default)
    - |Φ-⟩ = (|00⟩ - |11⟩) / √2  (state=1)
    - |Ψ+⟩ = (|01⟩ + |10⟩) / √2  (state=2)
    - |Ψ-⟩ = (|01⟩ - |10⟩) / √2  (state=3)
    
    Example:
        >>> bell = BellState()  # Creates |Φ+⟩
        >>> print(bell.draw())
    """
    
    def __init__(self, state: int = 0):
        """
        Initialize a Bell state circuit.
        
        Args:
            state: Which Bell state to create (0-3)
                  0: |Φ+⟩, 1: |Φ-⟩, 2: |Ψ+⟩, 3: |Ψ-⟩
        """
        if not 0 <= state <= 3:
            raise ValueError("Bell state must be 0, 1, 2, or 3")
        
        super().__init__(2, name=f"Bell{state}")
        
        # Base state |Φ+⟩
        self.h(0)
        self.cx(0, 1)
        
        # Modify for other states
        if state in [1, 3]:  # Phase flip for Φ- and Ψ-
            self.z(0)
        if state in [2, 3]:  # Bit flip for Ψ+ and Ψ-
            self.x(1)


class GHZState(QuantumCircuit):
    """
    Greenberger-Horne-Zeilinger (GHZ) state circuit (IBM Qiskit compatible).
    
    Creates the GHZ state: |GHZ⟩ = (|000...0⟩ + |111...1⟩) / √2
    
    This is a maximally entangled state for n qubits, generalizing the Bell state.
    
    Example:
        >>> ghz = GHZState(3)  # 3-qubit GHZ state
        >>> print(ghz.draw())
    """
    
    def __init__(self, num_qubits: int):
        """
        Initialize a GHZ state circuit.
        
        Args:
            num_qubits: Number of qubits (must be >= 2)
        """
        if num_qubits < 2:
            raise ValueError("GHZ state requires at least 2 qubits")
        
        super().__init__(num_qubits, name=f"GHZ{num_qubits}")
        
        # Create GHZ state
        self.h(0)  # Create superposition on first qubit
        for i in range(num_qubits - 1):
            self.cx(i, i + 1)  # Entangle all qubits


class QFT(QuantumCircuit):
    """
    Quantum Fourier Transform circuit (IBM Qiskit compatible).
    
    The QFT on n qubits transforms the computational basis states as:
    |j⟩ → (1/√N) Σ exp(2πijk/N) |k⟩
    
    where N = 2^n.
    
    The QFT is a key component in many quantum algorithms including
    Shor's algorithm and quantum phase estimation.
    
    Example:
        >>> qft = QFT(3)  # 3-qubit QFT
        >>> print(qft.draw())
    """
    
    def __init__(self, num_qubits: int, approximation_degree: int = 0,
                 do_swaps: bool = True, inverse: bool = False):
        """
        Initialize a QFT circuit.
        
        Args:
            num_qubits: Number of qubits
            approximation_degree: Degree of approximation (0 = exact)
            do_swaps: Whether to include final SWAP gates
            inverse: Whether to create inverse QFT
        """
        if num_qubits < 1:
            raise ValueError("QFT requires at least 1 qubit")
        
        name = f"{'IQFT' if inverse else 'QFT'}{num_qubits}"
        super().__init__(num_qubits, name=name)
        
        # Build QFT circuit
        self._build_qft(num_qubits, approximation_degree, do_swaps, inverse)
    
    def _build_qft(self, n: int, approx: int, swaps: bool, inverse: bool):
        """
        Build the QFT circuit.
        
        Args:
            n: Number of qubits
            approx: Approximation degree
            swaps: Include swaps
            inverse: Create inverse QFT
        """
        import numpy as np
        
        if not inverse:
            # Forward QFT
            for i in range(n):
                # Hadamard on qubit i
                self.h(i)
                
                # Controlled rotations
                for j in range(i + 1, n):
                    if approx == 0 or (j - i) <= (n - approx):
                        k = j - i + 1
                        angle = 2 * np.pi / (2 ** k)
                        self._add_controlled_phase(j, i, angle)
            
            # Final swaps to reverse qubit order
            if swaps:
                for i in range(n // 2):
                    self.swap(i, n - i - 1)
        else:
            # Inverse QFT (reverse operations)
            if swaps:
                for i in range(n // 2):
                    self.swap(i, n - i - 1)
            
            for i in range(n - 1, -1, -1):
                for j in range(n - 1, i, -1):
                    if approx == 0 or (j - i) <= (n - approx):
                        k = j - i + 1
                        angle = -2 * np.pi / (2 ** k)
                        self._add_controlled_phase(j, i, angle)
                
                self.h(i)
    
    def _add_controlled_phase(self, control: int, target: int, angle: float):
        """
        Add a controlled phase rotation.
        
        This is a helper for QFT construction.
        
        Args:
            control: Control qubit
            target: Target qubit
            angle: Phase angle
        """
        # For now, decompose as CZ with phase gates
        # In a full implementation, this would be a native CP gate
        import numpy as np
        self.rz(angle / 2, target)
        self.cx(control, target)
        self.rz(-angle / 2, target)
        self.cx(control, target)
        self.rz(angle / 2, control)


class WState(QuantumCircuit):
    """
    W-state circuit (IBM Qiskit compatible).
    
    Creates the W state on n qubits:
    |W⟩ = (|100...0⟩ + |010...0⟩ + ... + |000...1⟩) / √n
    
    The W state is another important multipartite entangled state.
    
    Example:
        >>> w = WState(3)  # 3-qubit W state
        >>> print(w.draw())
    """
    
    def __init__(self, num_qubits: int):
        """
        Initialize a W state circuit.
        
        Args:
            num_qubits: Number of qubits (must be >= 2)
        """
        if num_qubits < 2:
            raise ValueError("W state requires at least 2 qubits")
        
        super().__init__(num_qubits, name=f"W{num_qubits}")
        
        # Create W state using recursive structure
        self._build_w_state(num_qubits)
    
    def _build_w_state(self, n: int):
        """
        Build W state circuit.
        
        Args:
            n: Number of qubits
        """
        import numpy as np
        
        if n == 2:
            # Base case: |W2⟩ = (|01⟩ + |10⟩) / √2
            self.ry(np.pi / 2, 0)
            self.cx(0, 1)
            self.x(0)
        else:
            # Recursive case
            theta = 2 * np.arcsin(np.sqrt(1 / n))
            self.ry(theta, 0)
            
            # Recursively create W_{n-1} on remaining qubits
            # This is a simplified version - full implementation would use
            # more sophisticated decomposition
            for i in range(1, n):
                angle = 2 * np.arcsin(np.sqrt(1 / (n - i + 1)))
                self.ry(angle, i)
                if i < n - 1:
                    self.cx(i, i + 1)
