"""
Data-encoding circuits for quantum machine learning.

This module provides circuits that encode classical data into quantum states,
following IBM Qiskit's pattern. These are essential for:
- Quantum Machine Learning (QML)
- Variational Quantum Classifiers
- Quantum Kernel Methods
- Quantum Feature Maps

Reference: Qiskit's qiskit.circuit.library.data_preparation
"""

from typing import List, Optional, Union, Callable, Sequence
import numpy as np
from ...quantum_circuit import QuantumCircuit


class ZFeatureMap(QuantumCircuit):
    """
    Z-rotation feature map (IBM Qiskit compatible).
    
    Encodes classical data using only Z-rotations (RZ gates).
    This is the simplest feature map and creates separable states.
    
    The encoding is: |ψ(x)⟩ = ⊗_i H RZ(x_i) |0⟩
    
    For reps > 1, the circuit applies multiple layers of the encoding.
    
    Example:
        >>> from zena.circuit.library import ZFeatureMap
        >>> qc = ZFeatureMap(feature_dimension=3, reps=2)
        >>> bound = qc.bind_parameters([0.1, 0.2, 0.3])
    """
    
    def __init__(
        self,
        feature_dimension: int,
        reps: int = 2,
        data_map_func: Optional[Callable[[float], float]] = None,
        parameter_prefix: str = 'x',
        insert_barriers: bool = False,
        name: Optional[str] = None
    ):
        """
        Initialize a ZFeatureMap.
        
        Args:
            feature_dimension: Number of features (= number of qubits)
            reps: Number of repetitions of the encoding circuit
            data_map_func: Function to transform data before encoding
                          Default is identity: f(x) = x
            parameter_prefix: Prefix for parameter names
            insert_barriers: Whether to insert barriers between reps
            name: Circuit name
        """
        if feature_dimension < 1:
            raise ValueError("feature_dimension must be at least 1")
        
        super().__init__(feature_dimension, name=name or f"ZFeatureMap({feature_dimension})")
        
        self.feature_dimension = feature_dimension
        self.reps = reps
        self.data_map_func = data_map_func or (lambda x: x)
        self._parameter_prefix = parameter_prefix
        self._parameters = []
        self._insert_barriers = insert_barriers
        
        # Build the circuit
        self._build_circuit()
    
    def _build_circuit(self):
        """Build the ZFeatureMap circuit."""
        for rep in range(self.reps):
            # Add Hadamard layer
            for i in range(self.feature_dimension):
                self.h(i)
            
            # Add Z-rotation layer (placeholder parameters)
            for i in range(self.feature_dimension):
                param_name = f"{self._parameter_prefix}[{i}]"
                self._parameters.append(param_name)
                # Use placeholder value 0.0 - will be bound later
                self.rz(0.0, i)
            
            if self._insert_barriers and rep < self.reps - 1:
                self.barrier()
    
    @property
    def parameters(self) -> List[str]:
        """Return parameter names."""
        return self._parameters[:self.feature_dimension]  # Only unique params
    
    @property
    def num_parameters(self) -> int:
        """Return number of unique parameters."""
        return self.feature_dimension
    
    def bind_parameters(self, values: Union[List[float], np.ndarray]) -> 'QuantumCircuit':
        """
        Bind parameter values to create a concrete circuit.
        
        Args:
            values: Feature values to encode (length = feature_dimension)
            
        Returns:
            New circuit with bound parameters
        """
        if len(values) != self.feature_dimension:
            raise ValueError(f"Expected {self.feature_dimension} values, got {len(values)}")
        
        # Apply data map function
        mapped_values = [self.data_map_func(v) for v in values]
        
        # Create new circuit with bound values
        bound = QuantumCircuit(self.feature_dimension, name=f"{self.name}_bound")
        
        for rep in range(self.reps):
            for i in range(self.feature_dimension):
                bound.h(i)
            for i in range(self.feature_dimension):
                bound.rz(mapped_values[i], i)
            if self._insert_barriers and rep < self.reps - 1:
                bound.barrier()
        
        return bound


class ZZFeatureMap(QuantumCircuit):
    """
    ZZ-rotation feature map (IBM Qiskit compatible).
    
    Encodes classical data using Z-rotations and ZZ entangling rotations.
    This creates entangled feature states and is more expressive than ZFeatureMap.
    
    The first-order encoding: RZ(x_i)
    The second-order encoding: RZZ((π - x_i)(π - x_j))
    
    This is the default feature map for many QML applications due to its
    proven expressibility and trainability.
    
    Example:
        >>> from zena.circuit.library import ZZFeatureMap
        >>> qc = ZZFeatureMap(feature_dimension=3, reps=2)
        >>> bound = qc.bind_parameters([0.1, 0.2, 0.3])
    """
    
    def __init__(
        self,
        feature_dimension: int,
        reps: int = 2,
        entanglement: str = 'full',
        data_map_func: Optional[Callable[[float], float]] = None,
        parameter_prefix: str = 'x',
        insert_barriers: bool = False,
        name: Optional[str] = None
    ):
        """
        Initialize a ZZFeatureMap.
        
        Args:
            feature_dimension: Number of features (= number of qubits)
            reps: Number of repetitions
            entanglement: Entanglement pattern ('full', 'linear', 'circular')
            data_map_func: Function to transform data
                          Default: f(x) = x for single, f(x,y) = (π-x)(π-y) for pairs
            parameter_prefix: Prefix for parameter names
            insert_barriers: Whether to insert barriers
            name: Circuit name
        """
        if feature_dimension < 1:
            raise ValueError("feature_dimension must be at least 1")
        
        super().__init__(feature_dimension, name=name or f"ZZFeatureMap({feature_dimension})")
        
        self.feature_dimension = feature_dimension
        self.reps = reps
        self.entanglement = entanglement
        self.data_map_func = data_map_func
        self._parameter_prefix = parameter_prefix
        self._parameters = []
        self._insert_barriers = insert_barriers
        
        self._build_circuit()
    
    def _get_entanglement_pairs(self) -> List[tuple]:
        """Get qubit pairs based on entanglement pattern."""
        n = self.feature_dimension
        pairs = []
        
        if self.entanglement == 'full':
            for i in range(n):
                for j in range(i + 1, n):
                    pairs.append((i, j))
        elif self.entanglement == 'linear':
            for i in range(n - 1):
                pairs.append((i, i + 1))
        elif self.entanglement == 'circular':
            for i in range(n - 1):
                pairs.append((i, i + 1))
            if n > 2:
                pairs.append((n - 1, 0))
        else:
            raise ValueError(f"Unknown entanglement pattern: {self.entanglement}")
        
        return pairs
    
    def _build_circuit(self):
        """Build the ZZFeatureMap circuit."""
        pairs = self._get_entanglement_pairs()
        
        for rep in range(self.reps):
            # Hadamard layer
            for i in range(self.feature_dimension):
                self.h(i)
            
            # First-order Z encoding (Z-rotations on each qubit)
            for i in range(self.feature_dimension):
                param_name = f"{self._parameter_prefix}[{i}]"
                if param_name not in self._parameters:
                    self._parameters.append(param_name)
                # Placeholder - will be bound
                self.rz(0.0, i)
            
            # Second-order ZZ encoding (entangling rotations)
            for i, j in pairs:
                # ZZ rotation: CNOT - RZ - CNOT pattern
                # The rotation angle will be (π - x_i)(π - x_j)
                self.cx(i, j)
                self.rz(0.0, j)  # Placeholder
                self.cx(i, j)
            
            if self._insert_barriers and rep < self.reps - 1:
                self.barrier()
    
    @property
    def parameters(self) -> List[str]:
        """Return parameter names."""
        return self._parameters[:self.feature_dimension]
    
    @property
    def num_parameters(self) -> int:
        """Return number of unique parameters."""
        return self.feature_dimension
    
    def _default_pair_map(self, x: float, y: float) -> float:
        """Default data map for pairs: (π - x)(π - y)."""
        return (np.pi - x) * (np.pi - y)
    
    def bind_parameters(self, values: Union[List[float], np.ndarray]) -> 'QuantumCircuit':
        """
        Bind parameter values to create a concrete circuit.
        
        Args:
            values: Feature values to encode
            
        Returns:
            New circuit with bound parameters
        """
        if len(values) != self.feature_dimension:
            raise ValueError(f"Expected {self.feature_dimension} values, got {len(values)}")
        
        bound = QuantumCircuit(self.feature_dimension, name=f"{self.name}_bound")
        pairs = self._get_entanglement_pairs()
        
        for rep in range(self.reps):
            # Hadamard layer
            for i in range(self.feature_dimension):
                bound.h(i)
            
            # First-order Z encoding
            for i in range(self.feature_dimension):
                if self.data_map_func:
                    angle = self.data_map_func(values[i])
                else:
                    angle = 2 * values[i]  # Standard scaling
                bound.rz(angle, i)
            
            # Second-order ZZ encoding
            for i, j in pairs:
                pair_angle = self._default_pair_map(values[i], values[j])
                bound.cx(i, j)
                bound.rz(2 * pair_angle, j)  # Factor of 2 for ZZ convention
                bound.cx(i, j)
            
            if self._insert_barriers and rep < self.reps - 1:
                bound.barrier()
        
        return bound


class PauliFeatureMap(QuantumCircuit):
    """
    Pauli feature map (IBM Qiskit compatible).
    
    A general feature map using arbitrary Pauli rotations.
    This is the most flexible encoding and subsumes Z and ZZ feature maps.
    
    The circuit applies layers of Pauli rotations determined by the paulis parameter.
    For example, paulis=['Z', 'ZZ'] gives the ZZFeatureMap.
    
    Example:
        >>> from zena.circuit.library import PauliFeatureMap
        >>> qc = PauliFeatureMap(feature_dimension=3, paulis=['Z', 'ZZ', 'ZZZ'])
    """
    
    def __init__(
        self,
        feature_dimension: int,
        reps: int = 2,
        paulis: Optional[List[str]] = None,
        entanglement: str = 'full',
        data_map_func: Optional[Callable] = None,
        parameter_prefix: str = 'x',
        insert_barriers: bool = False,
        name: Optional[str] = None
    ):
        """
        Initialize a PauliFeatureMap.
        
        Args:
            feature_dimension: Number of features (= number of qubits)
            reps: Number of repetitions
            paulis: List of Pauli strings (e.g., ['Z', 'ZZ'])
                   Default: ['Z', 'ZZ'] for second-order encoding
            entanglement: Entanglement pattern for multi-qubit Paulis
            data_map_func: Function to transform data
            parameter_prefix: Prefix for parameter names
            insert_barriers: Whether to insert barriers
            name: Circuit name
        """
        if feature_dimension < 1:
            raise ValueError("feature_dimension must be at least 1")
        
        super().__init__(feature_dimension, name=name or f"PauliFeatureMap({feature_dimension})")
        
        self.feature_dimension = feature_dimension
        self.reps = reps
        self.paulis = paulis or ['Z', 'ZZ']
        self.entanglement = entanglement
        self.data_map_func = data_map_func
        self._parameter_prefix = parameter_prefix
        self._parameters = []
        self._insert_barriers = insert_barriers
        
        self._build_circuit()
    
    def _get_pauli_indices(self, pauli: str) -> List[tuple]:
        """Get qubit indices for a Pauli string."""
        n = self.feature_dimension
        order = len(pauli)  # Number of qubits involved
        
        indices = []
        if order == 1:
            # Single-qubit Paulis
            indices = [(i,) for i in range(n)]
        elif order == 2:
            # Two-qubit Paulis
            if self.entanglement == 'full':
                for i in range(n):
                    for j in range(i + 1, n):
                        indices.append((i, j))
            elif self.entanglement == 'linear':
                for i in range(n - 1):
                    indices.append((i, i + 1))
            elif self.entanglement == 'circular':
                for i in range(n - 1):
                    indices.append((i, i + 1))
                if n > 2:
                    indices.append((n - 1, 0))
        elif order == 3:
            # Three-qubit Paulis
            if self.entanglement == 'full':
                for i in range(n):
                    for j in range(i + 1, n):
                        for k in range(j + 1, n):
                            indices.append((i, j, k))
            elif self.entanglement == 'linear':
                for i in range(n - 2):
                    indices.append((i, i + 1, i + 2))
        
        return indices
    
    def _apply_pauli_evolution(self, pauli: str, qubits: tuple, angle: float):
        """
        Apply Pauli string evolution gate.
        
        For ZZ...Z: CNOT ladder -> RZ -> CNOT ladder
        """
        n = len(qubits)
        
        if n == 1:
            # Single-qubit Pauli
            q = qubits[0]
            if pauli == 'Z':
                self.rz(angle, q)
            elif pauli == 'X':
                self.rx(angle, q)
            elif pauli == 'Y':
                self.ry(angle, q)
        elif n >= 2:
            # Multi-qubit Pauli (ZZ...Z pattern)
            # CNOT ladder
            for i in range(n - 1):
                self.cx(qubits[i], qubits[i + 1])
            # RZ on last qubit
            self.rz(angle, qubits[-1])
            # Reverse CNOT ladder
            for i in range(n - 2, -1, -1):
                self.cx(qubits[i], qubits[i + 1])
    
    def _build_circuit(self):
        """Build the PauliFeatureMap circuit."""
        for i in range(self.feature_dimension):
            param_name = f"{self._parameter_prefix}[{i}]"
            if param_name not in self._parameters:
                self._parameters.append(param_name)
        
        for rep in range(self.reps):
            # Hadamard layer
            for i in range(self.feature_dimension):
                self.h(i)
            
            # Apply each Pauli layer
            for pauli in self.paulis:
                indices = self._get_pauli_indices(pauli)
                for qubits in indices:
                    self._apply_pauli_evolution(pauli, qubits, 0.0)  # Placeholder
            
            if self._insert_barriers and rep < self.reps - 1:
                self.barrier()
    
    @property
    def parameters(self) -> List[str]:
        """Return parameter names."""
        return self._parameters
    
    @property
    def num_parameters(self) -> int:
        """Return number of unique parameters."""
        return self.feature_dimension
    
    def _compute_pauli_angle(self, pauli: str, values: List[float], indices: tuple) -> float:
        """Compute rotation angle for a Pauli term."""
        order = len(pauli)
        
        if order == 1:
            return 2 * values[indices[0]]
        else:
            # Product of (π - x_i) for all qubits
            angle = 1.0
            for idx in indices:
                angle *= (np.pi - values[idx])
            return 2 * angle
    
    def bind_parameters(self, values: Union[List[float], np.ndarray]) -> 'QuantumCircuit':
        """
        Bind parameter values to create a concrete circuit.
        
        Args:
            values: Feature values to encode
            
        Returns:
            New circuit with bound parameters
        """
        if len(values) != self.feature_dimension:
            raise ValueError(f"Expected {self.feature_dimension} values, got {len(values)}")
        
        bound = QuantumCircuit(self.feature_dimension, name=f"{self.name}_bound")
        
        for rep in range(self.reps):
            # Hadamard layer
            for i in range(self.feature_dimension):
                bound.h(i)
            
            # Apply each Pauli layer with bound values
            for pauli in self.paulis:
                indices_list = self._get_pauli_indices(pauli)
                for indices in indices_list:
                    angle = self._compute_pauli_angle(pauli, list(values), indices)
                    self._apply_bound_pauli(bound, pauli, indices, angle)
            
            if self._insert_barriers and rep < self.reps - 1:
                bound.barrier()
        
        return bound
    
    def _apply_bound_pauli(self, circuit: 'QuantumCircuit', pauli: str, 
                           qubits: tuple, angle: float):
        """Apply Pauli evolution with bound angle."""
        n = len(qubits)
        
        if n == 1:
            q = qubits[0]
            if pauli == 'Z':
                circuit.rz(angle, q)
            elif pauli == 'X':
                circuit.rx(angle, q)
            elif pauli == 'Y':
                circuit.ry(angle, q)
        elif n >= 2:
            for i in range(n - 1):
                circuit.cx(qubits[i], qubits[i + 1])
            circuit.rz(angle, qubits[-1])
            for i in range(n - 2, -1, -1):
                circuit.cx(qubits[i], qubits[i + 1])


class StatePreparation(QuantumCircuit):
    """
    State preparation circuit (IBM Qiskit compatible).
    
    Prepares an arbitrary quantum state from a classical amplitude vector.
    Uses the recursive decomposition algorithm.
    
    This is useful for:
    - Amplitude encoding of data
    - Preparing initial states for VQE
    - Quantum sampling
    
    Example:
        >>> from zena.circuit.library import StatePreparation
        >>> amplitudes = [0.5, 0.5, 0.5, 0.5]  # |++⟩ state
        >>> qc = StatePreparation(amplitudes)
    """
    
    def __init__(
        self,
        params: Union[List[float], List[complex], np.ndarray],
        num_qubits: Optional[int] = None,
        normalize: bool = True,
        label: Optional[str] = None,
        name: Optional[str] = None
    ):
        """
        Initialize a StatePreparation circuit.
        
        Args:
            params: Amplitude vector (real or complex)
                   Length must be 2^n for some n
            num_qubits: Number of qubits (inferred from params if not given)
            normalize: Whether to normalize the state vector
            label: Label for the gate
            name: Circuit name
        """
        params = np.array(params, dtype=complex)
        
        # Validate and determine number of qubits
        n = int(np.ceil(np.log2(len(params))))
        expected_len = 2 ** n
        
        if len(params) < expected_len:
            # Pad with zeros
            params = np.concatenate([params, np.zeros(expected_len - len(params))])
        
        if num_qubits is None:
            num_qubits = n
        
        if 2 ** num_qubits != len(params):
            raise ValueError(f"params length {len(params)} != 2^{num_qubits}")
        
        # Normalize if requested
        if normalize:
            norm = np.linalg.norm(params)
            if norm > 1e-10:
                params = params / norm
        
        super().__init__(num_qubits, name=name or f"StatePrep({num_qubits})")
        
        self._params = params
        self._amplitudes = params
        self._label = label
        
        # Build the circuit
        self._build_circuit()
    
    @property
    def amplitudes(self) -> np.ndarray:
        """Return the target amplitudes."""
        return self._amplitudes
    
    def _build_circuit(self):
        """Build the state preparation circuit using recursive decomposition."""
        n = self.n_qubits
        
        if n == 0:
            return
        
        if n == 1:
            # Single qubit - just use RY and RZ
            self._prepare_single_qubit(self._params)
        else:
            # Multi-qubit - use recursive decomposition
            self._prepare_multi_qubit(self._params, list(range(n)))
    
    def _prepare_single_qubit(self, amplitudes: np.ndarray):
        """Prepare a single-qubit state."""
        a, b = amplitudes[0], amplitudes[1]
        
        # Calculate rotation angles
        # |ψ⟩ = cos(θ/2)|0⟩ + e^{iφ}sin(θ/2)|1⟩
        
        r0 = np.abs(a)
        r1 = np.abs(b)
        theta = 2 * np.arctan2(r1, r0) if r0 > 1e-10 else np.pi
        
        # Global phase and relative phase
        if r0 > 1e-10:
            phi = np.angle(b) - np.angle(a) if r1 > 1e-10 else 0
        else:
            phi = 0
        
        # Apply rotations
        if np.abs(theta) > 1e-10:
            self.ry(theta, 0)
        if np.abs(phi) > 1e-10:
            self.rz(phi, 0)
    
    def _prepare_multi_qubit(self, amplitudes: np.ndarray, qubits: List[int]):
        """Prepare a multi-qubit state using recursive decomposition."""
        n = len(qubits)
        
        if n == 1:
            # Base case - single qubit
            a, b = amplitudes[0], amplitudes[1]
            r0, r1 = np.abs(a), np.abs(b)
            theta = 2 * np.arctan2(r1, r0) if r0 > 1e-10 else np.pi
            
            if np.abs(theta) > 1e-10:
                self.ry(theta, qubits[0])
            
            phi = np.angle(b) - np.angle(a) if (r0 > 1e-10 and r1 > 1e-10) else 0
            if np.abs(phi) > 1e-10:
                self.rz(phi, qubits[0])
            return
        
        # Split amplitudes into two halves
        half = len(amplitudes) // 2
        amp0 = amplitudes[:half]  # Amplitudes when top qubit is |0⟩
        amp1 = amplitudes[half:]  # Amplitudes when top qubit is |1⟩
        
        # Compute norms
        norm0 = np.linalg.norm(amp0)
        norm1 = np.linalg.norm(amp1)
        
        # Rotation angle for top qubit
        theta = 2 * np.arctan2(norm1, norm0) if norm0 > 1e-10 else np.pi
        
        # Apply RY on top qubit
        if np.abs(theta) > 1e-10:
            self.ry(theta, qubits[0])
        
        # Normalize sub-amplitudes
        if norm0 > 1e-10:
            amp0 = amp0 / norm0
        if norm1 > 1e-10:
            amp1 = amp1 / norm1
        
        # Recursively prepare remaining qubits controlled on top qubit
        # Simplified: apply to remaining qubits (not fully controlled)
        remaining_qubits = qubits[1:]
        
        if n == 2:
            # Two-qubit case - handle directly
            self._prepare_two_qubit_sub(amp0, amp1, qubits)
        else:
            # For larger circuits, use simplified decomposition
            # Full implementation would use multiplexed rotations
            self._prepare_multi_qubit_simplified(amplitudes, qubits)
    
    def _prepare_two_qubit_sub(self, amp0: np.ndarray, amp1: np.ndarray, 
                                qubits: List[int]):
        """Prepare two-qubit state using controlled rotations."""
        # When q0=|0⟩, prepare amp0 on q1
        # When q0=|1⟩, prepare amp1 on q1
        
        # Compute angles for both cases
        r0_0, r0_1 = np.abs(amp0[0]), np.abs(amp0[1])
        r1_0, r1_1 = np.abs(amp1[0]), np.abs(amp1[1])
        
        theta0 = 2 * np.arctan2(r0_1, r0_0) if r0_0 > 1e-10 else np.pi
        theta1 = 2 * np.arctan2(r1_1, r1_0) if r1_0 > 1e-10 else np.pi
        
        # Average and difference
        avg = (theta0 + theta1) / 2
        diff = (theta1 - theta0) / 2
        
        # Apply: RY(avg) on q1, then CRY(diff) controlled by q0
        if np.abs(avg) > 1e-10:
            self.ry(avg, qubits[1])
        if np.abs(diff) > 1e-10:
            # Controlled-RY decomposition: CNOT-RY(-diff/2)-CNOT-RY(diff/2)
            self.cx(qubits[0], qubits[1])
            self.ry(-diff, qubits[1])
            self.cx(qubits[0], qubits[1])
    
    def _prepare_multi_qubit_simplified(self, amplitudes: np.ndarray, 
                                         qubits: List[int]):
        """Simplified multi-qubit state preparation."""
        # Use Möttönen decomposition approximation
        # For now, use a simplified approach with RY rotations and CNOTs
        
        n = len(qubits)
        
        # Apply RY rotations based on amplitude magnitudes
        for i, q in enumerate(qubits):
            # Compute effective angle from amplitudes
            step = 2 ** (n - i - 1)
            sum_high = sum(np.abs(amplitudes[j]) ** 2 
                          for j in range(len(amplitudes)) if (j // step) % 2 == 1)
            sum_low = sum(np.abs(amplitudes[j]) ** 2 
                         for j in range(len(amplitudes)) if (j // step) % 2 == 0)
            
            if sum_low > 1e-10:
                theta = 2 * np.arctan2(np.sqrt(sum_high), np.sqrt(sum_low))
                if np.abs(theta) > 1e-10:
                    self.ry(theta, q)
        
        # Add entangling gates for correlations
        for i in range(n - 1):
            self.cx(qubits[i], qubits[i + 1])


class AmplitudeEmbedding(StatePreparation):
    """
    Amplitude embedding circuit (IBM Qiskit compatible).
    
    Encodes classical data into the amplitudes of a quantum state.
    This is an alias for StatePreparation, commonly used in QML.
    
    Features:
    - Exponential compression: n classical values → log2(n) qubits
    - Normalized automatically
    
    Example:
        >>> from zena.circuit.library import AmplitudeEmbedding
        >>> data = [0.5, 0.5, 0.5, 0.5]  # 4 values → 2 qubits
        >>> qc = AmplitudeEmbedding(data)
    """
    
    def __init__(
        self,
        features: Union[List[float], np.ndarray],
        num_qubits: Optional[int] = None,
        normalize: bool = True,
        name: Optional[str] = None
    ):
        """
        Initialize AmplitudeEmbedding.
        
        Args:
            features: Classical data to encode
            num_qubits: Number of qubits (inferred if not given)
            normalize: Whether to normalize the feature vector
            name: Circuit name
        """
        super().__init__(
            params=features,
            num_qubits=num_qubits,
            normalize=normalize,
            name=name or "AmplitudeEmbedding"
        )


class AngleEmbedding(QuantumCircuit):
    """
    Angle embedding circuit (IBM Qiskit compatible).
    
    Encodes classical data into rotation angles of quantum gates.
    Each feature is encoded as RY(x_i) rotation (default) or RX/RZ.
    
    This gives linear encoding: n features → n qubits.
    
    Example:
        >>> from zena.circuit.library import AngleEmbedding
        >>> data = [0.1, 0.2, 0.3]  # 3 values → 3 qubits
        >>> qc = AngleEmbedding(features=data)
    """
    
    def __init__(
        self,
        num_features: Optional[int] = None,
        features: Optional[Union[List[float], np.ndarray]] = None,
        rotation: str = 'Y',
        name: Optional[str] = None
    ):
        """
        Initialize AngleEmbedding.
        
        Args:
            num_features: Number of features (required if features not given)
            features: Feature values to encode (optional, can bind later)
            rotation: Rotation axis ('X', 'Y', or 'Z')
            name: Circuit name
        """
        if features is not None:
            features = np.array(features)
            num_features = len(features)
        elif num_features is None:
            raise ValueError("Must provide either features or num_features")
        
        super().__init__(num_features, name=name or f"AngleEmbedding({num_features})")
        
        self.num_features = num_features
        self.rotation = rotation.upper()
        self._features = features
        self._parameters = [f"x[{i}]" for i in range(num_features)]
        
        if features is not None:
            self._build_with_features(features)
        else:
            self._build_parametric()
    
    def _build_with_features(self, features: np.ndarray):
        """Build circuit with bound features."""
        for i, f in enumerate(features):
            if self.rotation == 'Y':
                self.ry(f, i)
            elif self.rotation == 'X':
                self.rx(f, i)
            elif self.rotation == 'Z':
                self.rz(f, i)
    
    def _build_parametric(self):
        """Build parametric circuit (placeholders)."""
        for i in range(self.num_features):
            if self.rotation == 'Y':
                self.ry(0.0, i)
            elif self.rotation == 'X':
                self.rx(0.0, i)
            elif self.rotation == 'Z':
                self.rz(0.0, i)
    
    @property
    def parameters(self) -> List[str]:
        """Return parameter names."""
        return self._parameters
    
    def bind_parameters(self, features: Union[List[float], np.ndarray]) -> 'QuantumCircuit':
        """Bind feature values."""
        return AngleEmbedding(features=features, rotation=self.rotation, 
                              name=f"{self.name}_bound")


class IQP(QuantumCircuit):
    """
    Instantaneous Quantum Polynomial circuit (IBM Qiskit compatible).
    
    A circuit consisting of Hadamard gates and diagonal gates.
    IQP circuits are believed to be hard to simulate classically.
    
    Structure:
    - Layer of Hadamards
    - Diagonal unitary (Z rotations + CZ gates)
    - Layer of Hadamards
    
    Example:
        >>> from zena.circuit.library import IQP
        >>> qc = IQP(num_qubits=3, interactions=[[0,1], [1,2]])
    """
    
    def __init__(
        self,
        num_qubits: int,
        interactions: Optional[List[List[int]]] = None,
        name: Optional[str] = None
    ):
        """
        Initialize IQP circuit.
        
        Args:
            num_qubits: Number of qubits
            interactions: List of qubit pairs to entangle
                         Default: all pairs (complete graph)
            name: Circuit name
        """
        super().__init__(num_qubits, name=name or f"IQP({num_qubits})")
        
        if interactions is None:
            # Default: complete graph
            interactions = [[i, j] for i in range(num_qubits) 
                           for j in range(i + 1, num_qubits)]
        
        self.interactions = interactions
        self._build_circuit()
    
    def _build_circuit(self):
        """Build the IQP circuit."""
        n = self.n_qubits
        
        # Initial Hadamard layer
        for i in range(n):
            self.h(i)
        
        # Diagonal layer: Z rotations and CZ gates
        for i in range(n):
            self.rz(np.pi / 4, i)  # T gates as example
        
        for i, j in self.interactions:
            self.cz(i, j)
        
        # Final Hadamard layer
        for i in range(n):
            self.h(i)
