"""
Benchmarking and complexity-theory circuits.

This module provides circuits used for hardware benchmarking (e.g., Quantum Volume)
and studying quantum complexity (e.g., IQP, Grover's).

Categories:
- Benchmarking: QuantumVolume
- Complexity: IQPCircuit, GraphState, GroverOperator, FourierChecking
"""

from typing import List, Optional, Union, Any
import numpy as np
from ..quantum_circuit import QuantumCircuit


class QuantumVolume(QuantumCircuit):
    """
    Quantum Volume circuit (IBM Qiskit compatible).

    Quantum Volume is a metric for the performance of a quantum computer.
    It consists of layers of random permutations and random 2-qubit unitaries.

    Reference: Cross et al., "Validating quantum computers with square quantum
    volume circuits" (2019)

    Example:
        >>> from zena.circuit.library import QuantumVolume
        >>> qv = QuantumVolume(4)  # 4-bit quantum volume circuit
    """

    def __init__(
        self,
        num_qubits: int,
        depth: Optional[int] = None,
        seed: Optional[int] = None,
        name: Optional[str] = None
    ):
        """
        Initialize a Quantum Volume circuit.

        Args:
            num_qubits: Number of qubits.
            depth: Number of layers (default: num_qubits).
            seed: Random seed for reproducibility.
            name: Optional name.
        """
        self._num_qubits = num_qubits
        self._depth = depth or num_qubits
        self._seed = seed
        
        circuit_name = name or f"QuantumVolume({num_qubits})"
        super().__init__(num_qubits, name=circuit_name)
        
        self._build_circuit()

    def _build_circuit(self):
        """Build the Quantum Volume circuit."""
        rng = np.random.RandomState(self._seed)
        n = self.n_qubits
        
        # Qiskit QV uses layers of randomized SU(4) gates on permutations
        for _ in range(self._depth):
            perm = rng.permutation(n)
            
            # Apply random SU(4) gates to pairs of qubits in the permutation
            for i in range(0, n - 1, 2):
                q1, q2 = int(perm[i]), int(perm[i+1])
                # In a real implementation we would generate a random 4x1 unitary
                self._apply_random_2q_unitary(q1, q2, rng)

    def _apply_random_2q_unitary(self, q1: int, q2: int, rng):
        """
        Apply a random 2-qubit unitary.
        
        Mock implementation using a randomized sequence of standard gates.
        """
        # A simple randomized block roughly representing an SU(4) element
        for q in [q1, q2]:
            self.rx(rng.uniform(0, 2*np.pi), q)
            self.ry(rng.uniform(0, 2*np.pi), q)
            self.rz(rng.uniform(0, 2*np.pi), q)
        
        self.cx(q1, q2)
        
        for q in [q1, q2]:
            self.rx(rng.uniform(0, 2*np.pi), q)
            self.ry(rng.uniform(0, 2*np.pi), q)
            self.rz(rng.uniform(0, 2*np.pi), q)


class GraphState(QuantumCircuit):
    """
    Graph state circuit (IBM Qiskit compatible).

    Prepares a graph state defined by an adjacency matrix or list of edges.
    A graph state is prepared by:
    1. Initializing all qubits in |+> state.
    2. Applying a CZ gate for every edge in the graph.

    Example:
        >>> from zena.circuit.library import GraphState
        >>> adjacency = [[0, 1, 0], [1, 0, 1], [0, 1, 0]]
        >>> gs = GraphState(adjacency)
    """

    def __init__(
        self,
        adjacency_matrix: Union[np.ndarray, List[List[int]]],
        name: Optional[str] = None
    ):
        """
        Initialize a GraphState circuit.

        Args:
            adjacency_matrix: Square matrix or adjacency list representing the graph.
            name: Optional name.
        """
        adj = np.asarray(adjacency_matrix)
        if adj.ndim != 2 or adj.shape[0] != adj.shape[1]:
            raise ValueError("Adjacency matrix must be square.")
        
        self._adj = adj
        n = adj.shape[0]
        
        circuit_name = name or f"GraphState({n})"
        super().__init__(n, name=circuit_name)
        
        self._build_circuit()

    def _build_circuit(self):
        """Build the graph state circuit."""
        n = self.n_qubits
        
        # Step 1: Initialize to |+>^n
        for i in range(n):
            self.h(i)
        
        # Step 2: Apply CZ for each edge
        for i in range(n):
            for j in range(i + 1, n):
                if self._adj[i, j]:
                    self.cz(i, j)


class IQPCircuit(QuantumCircuit):
    """
    Instantaneous Quantum Polynomial (IQP) circuit (IBM Qiskit compatible).

    IQP circuits are believed to be hard to simulate classically.
    They consist of:
    1. A layer of Hadamard gates.
    2. A diagonal circuit (often made of RZ and RZZ gates).
    3. Another layer of Hadamard gates.

    Reference: Bremner et al., "Classical simulation of joint measurements of 
    non-commuting quantum Hamiltonians" (2010)

    Example:
        >>> from zena.circuit.library import IQPCircuit
        >>> interactions = [[0, 0, 0.1], [1, 1, 0.2], [0, 1, 0.5]]
        >>> iqp = IQPCircuit(interactions)
    """

    def __init__(
        self,
        interactions: List[List[float]],
        num_qubits: Optional[int] = None,
        name: Optional[str] = None
    ):
        """
        Initialize an IQPCircuit.

        Args:
            interactions: List of [q1, q2, angle]. 
                        If q1 == q2, it's a single-qubit RZ(angle).
            num_qubits: Number of qubits (inferred if None).
            name: Optional name.
        """
        # Determine num_qubits
        max_q = 0
        for interaction in interactions:
            max_q = max(max_q, int(interaction[0]), int(interaction[1]))
        
        n = (num_qubits if num_qubits is not None else max_q + 1)
        self._interactions = interactions
        
        circuit_name = name or f"IQP({n})"
        super().__init__(n, name=circuit_name)
        
        self._build_circuit()

    def _build_circuit(self):
        """Build the IQP circuit."""
        n = self.n_qubits
        
        # Step 1: First layer of Hadamards
        for i in range(n):
            self.h(i)
        
        # Step 2: Diagonal unitary (JZ and JZZ)
        for q1, q2, angle in self._interactions:
            self._apply_interaction(int(q1), int(q2), angle)
        
        # Step 3: Second layer of Hadamards
        for i in range(n):
            self.h(i)

    def _apply_interaction(self, q1: int, q2: int, angle: float):
        """Apply RZ or RZZ based on interaction type."""
        if q1 == q2:
            self.rz(angle, q1)
        else:
            self.rzz(angle, q1, q2)


class GroverOperator(QuantumCircuit):
    """
    Grover Operator circuit (IBM Qiskit compatible).

    Implements the Grover iteration G = D * O, where O is the oracle
    and D is the diffusion operator (reflection about |+>^n).

    Example:
        >>> from zena.circuit.library import GroverOperator, AndGate
        >>> oracle = AndGate(2)
        >>> grover = GroverOperator(oracle)
    """

    def __init__(
        self,
        oracle: QuantumCircuit,
        zero_reflection: Optional[QuantumCircuit] = None,
        name: Optional[str] = None
    ):
        """
        Initialize a GroverOperator.

        Args:
            oracle: The oracle circuit (must flip phase of marked states).
            zero_reflection: Optional custom reflection about |0>^n.
            name: Optional name.
        """
        self._oracle = oracle
        n = oracle.n_qubits
        
        circuit_name = name or f"GroverOperator({n})"
        super().__init__(n, name=circuit_name)
        
        self._build_circuit()

    def _build_circuit(self):
        """Build the Grover operator."""
        n = self.n_qubits
        
        # 1. Apply Oracle
        self.compose(self._oracle, inplace=True)
        
        # 2. Apply Diffusion (H * Reflection_0 * H)
        for i in range(n):
            self.h(i)
        
        # Reflection about |0>
        # Implemented as X * Multi-Controlled Z * X
        for i in range(n):
            self.x(i)
        
        # Multi-controlled Z (simplified representation)
        if n == 1:
            self.z(0)
        elif n == 2:
            self.cz(0, 1)
        else:
            # Placeholder for higher order MCZ
            self.h(n - 1)
            self.ccx(0, 1, n - 1)
            self.h(n - 1)
            
        for i in range(n):
            self.x(i)
            
        for i in range(n):
            self.h(i)


class FourierChecking(QuantumCircuit):
    """
    Fourier Checking circuit (IBM Qiskit compatible).

    Used for the Fourier Checking problem, which is to decide if a 
    boolean function f is "close" to its Fourier transform.

    Reference: Aaronson, "BQP and the Polynomial Hierarchy" (2010)

    Example:
        >>> from zena.circuit.library import FourierChecking
        >>> f = [1, -1, 1, 1]
        >>> g = [1, 1, -1, 1]
        >>> fc = FourierChecking(f, g)
    """

    def __init__(
        self,
        f: List[int],
        g: List[int],
        name: Optional[str] = None
    ):
        """
        Initialize a FourierChecking circuit.

        Args:
            f: Values of function f (+1 or -1) on inputs. Length 2^n.
            g: Values of function g (+1 or -1) on inputs. Length 2^n.
            name: Optional name.
        """
        n = int(np.log2(len(f)))
        if 2**n != len(f) or 2**n != len(g):
            raise ValueError("Input lists must have length 2^n.")
            
        self._f = f
        self._g = g
        
        circuit_name = name or f"FourierChecking({n})"
        super().__init__(n, name=circuit_name)
        
        self._build_circuit()

    def _build_circuit(self):
        """Build the Fourier Checking circuit."""
        n = self.n_qubits
        
        # 1. Start in |+>^n
        for i in range(n):
            self.h(i)
        
        # 2. Apply oracle for f (diagonal phase)
        # Mockup: In a real run, this would be a sequence of gates
        # representing function f. Here we represent the intent.
        
        # 3. Apply QFT
        from .particular_circuits import QFT
        self.compose(QFT(n), inplace=True)
        
        # 4. Apply oracle for g
        
        # 5. Inverse QFT
        self.compose(QFT(n, inverse=True), inplace=True)
