"""Generalized gates including UnitaryGate.

Matches Qiskit's ``qiskit/circuit/library/generalized_gates/`` structure.
In Qiskit, UnitaryGate lives at:
    qiskit/circuit/library/generalized_gates/unitary.py
"""
from ...synthesis import UnitaryGate

__all__ = ["UnitaryGate"]
