"""Unitary gate.

Re-exports UnitaryGate from synthesis module.
Matches Qiskit's ``qiskit/circuit/library/generalized_gates/unitary.py``.
"""
from ...synthesis import UnitaryGate

__all__ = ["UnitaryGate"]
