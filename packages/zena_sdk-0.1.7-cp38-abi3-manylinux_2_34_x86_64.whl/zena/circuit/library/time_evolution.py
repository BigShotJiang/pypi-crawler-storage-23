"""
Time-evolution circuits for quantum simulation.

This module provides circuits that simulate a quantum state evolving in time,
following IBM Qiskit's circuit.library pattern.

Time-evolution circuits are fundamental building blocks for:
- Quantum simulation of physical systems (e.g., heat transfer, phase transitions)
- Chemistry wave functions (unitary coupled-cluster trial states)
- QAOA (Quantum Approximate Optimization Algorithm)
- Variational Quantum Eigensolver (VQE)

Reference: Qiskit's qiskit.circuit.library.PauliEvolutionGate
"""

from typing import List, Optional, Union, Dict, Tuple
import numpy as np
from ..quantum_circuit import QuantumCircuit


class SparsePauliOp:
    """
    Sparse representation of a sum of Pauli operators (IBM Qiskit compatible).

    Represents a Hamiltonian as a weighted sum of Pauli strings:
        H = Σ_i c_i * P_i

    where P_i are Pauli strings (e.g., "ZZI", "IXX") and c_i are complex coefficients.

    Example:
        >>> from zena.circuit.library.time_evolution import SparsePauliOp
        >>> # Ising model Hamiltonian: H = ZZ + ZZ
        >>> hamiltonian = SparsePauliOp(["ZZI", "IZZ"])
        >>> print(hamiltonian)
        SparsePauliOp(['ZZI', 'IZZ'], coeffs=[1.+0.j, 1.+0.j])

        >>> # With custom coefficients
        >>> hamiltonian = SparsePauliOp(["ZZ", "XX", "YY"], coeffs=[1.0, 0.5, 0.5])
    """

    VALID_PAULIS = {'I', 'X', 'Y', 'Z'}

    def __init__(
        self,
        data: Union[List[str], str],
        coeffs: Optional[Union[List[complex], np.ndarray]] = None,
    ):
        """
        Initialize a SparsePauliOp.

        Args:
            data: Pauli string(s), e.g., ["ZZI", "IZZ"] or "ZZ"
            coeffs: Complex coefficients for each Pauli term.
                    Defaults to all 1.0 if not specified.

        Raises:
            ValueError: If Pauli strings have inconsistent lengths or invalid characters.
        """
        if isinstance(data, str):
            data = [data]

        self._labels = list(data)

        # Validate Pauli strings
        if not self._labels:
            raise ValueError("At least one Pauli string is required")

        self._num_qubits = len(self._labels[0])
        for label in self._labels:
            if len(label) != self._num_qubits:
                raise ValueError(
                    f"All Pauli strings must have the same length. "
                    f"Expected {self._num_qubits}, got {len(label)} for '{label}'"
                )
            for ch in label:
                if ch.upper() not in self.VALID_PAULIS:
                    raise ValueError(
                        f"Invalid Pauli character '{ch}' in string '{label}'. "
                        f"Valid characters: I, X, Y, Z"
                    )

        # Set coefficients
        if coeffs is None:
            self._coeffs = np.ones(len(self._labels), dtype=complex)
        else:
            self._coeffs = np.asarray(coeffs, dtype=complex)
            if len(self._coeffs) != len(self._labels):
                raise ValueError(
                    f"Number of coefficients ({len(self._coeffs)}) must match "
                    f"number of Pauli strings ({len(self._labels)})"
                )

    @property
    def labels(self) -> List[str]:
        """Return the Pauli string labels."""
        return list(self._labels)

    @property
    def coeffs(self) -> np.ndarray:
        """Return the coefficients."""
        return self._coeffs.copy()

    @property
    def num_qubits(self) -> int:
        """Return the number of qubits."""
        return self._num_qubits

    @property
    def num_terms(self) -> int:
        """Return the number of Pauli terms."""
        return len(self._labels)

    def group_commuting(self) -> List['SparsePauliOp']:
        """
        Group commuting Pauli terms together.

        Returns:
            List of SparsePauliOp, each containing mutually commuting terms.
        """
        # Simple grouping: each term in its own group for now
        # A proper implementation would use graph coloring
        groups = []
        used = set()

        for i, label_i in enumerate(self._labels):
            if i in used:
                continue
            group_labels = [label_i]
            group_coeffs = [self._coeffs[i]]
            used.add(i)

            for j in range(i + 1, len(self._labels)):
                if j in used:
                    continue
                if self._commutes(label_i, self._labels[j]):
                    group_labels.append(self._labels[j])
                    group_coeffs.append(self._coeffs[j])
                    used.add(j)

            groups.append(SparsePauliOp(group_labels, group_coeffs))

        return groups

    @staticmethod
    def _commutes(pauli1: str, pauli2: str) -> bool:
        """
        Check if two Pauli strings commute.

        Two Pauli strings commute if and only if they anti-commute on
        an even number of qubit positions.
        """
        anticommute_count = 0
        for p1, p2 in zip(pauli1, pauli2):
            if p1 == 'I' or p2 == 'I' or p1 == p2:
                continue
            anticommute_count += 1
        return anticommute_count % 2 == 0

    def __repr__(self) -> str:
        return f"SparsePauliOp({self._labels}, coeffs={self._coeffs})"

    def __str__(self) -> str:
        terms = []
        for label, coeff in zip(self._labels, self._coeffs):
            if coeff == 1.0:
                terms.append(label)
            else:
                terms.append(f"{coeff}*{label}")
        return " + ".join(terms)

    def __add__(self, other: 'SparsePauliOp') -> 'SparsePauliOp':
        """Add two SparsePauliOp operators."""
        if self._num_qubits != other._num_qubits:
            raise ValueError("Cannot add operators with different numbers of qubits")
        labels = self._labels + other._labels
        coeffs = np.concatenate([self._coeffs, other._coeffs])
        return SparsePauliOp(labels, coeffs)

    def __mul__(self, scalar: complex) -> 'SparsePauliOp':
        """Multiply by a scalar."""
        return SparsePauliOp(self._labels, self._coeffs * scalar)

    def __rmul__(self, scalar: complex) -> 'SparsePauliOp':
        """Right multiply by a scalar."""
        return self.__mul__(scalar)


class PauliEvolutionGate:
    """
    Pauli evolution gate (IBM Qiskit compatible).

    Implements time evolution under a Pauli Hamiltonian:
        U(t) = exp(-i * H * t)

    where H is a sum of Pauli operators (SparsePauliOp).

    The gate is decomposed using product formulas (Trotter-Suzuki decomposition).

    Example:
        >>> from zena.circuit.library.time_evolution import PauliEvolutionGate, SparsePauliOp
        >>> from zena.circuit.quantum_circuit import QuantumCircuit
        >>>
        >>> # Create a Hamiltonian: H = ZZI + IZZ (Ising chain)
        >>> hamiltonian = SparsePauliOp(["ZZI", "IZZ"])
        >>> evolution = PauliEvolutionGate(hamiltonian, time=1.0)
        >>>
        >>> # Create circuit and apply evolution
        >>> qc = QuantumCircuit(3)
        >>> qc.h(1)  # Initial state
        >>> evolution.apply_to_circuit(qc)
        >>> print(qc.draw())
    """

    def __init__(
        self,
        operator: SparsePauliOp,
        time: float = 1.0,
        label: Optional[str] = None,
        synthesis: Optional[str] = None,
        reps: int = 1,
    ):
        """
        Initialize a PauliEvolutionGate.

        Args:
            operator: The Hamiltonian (SparsePauliOp) to evolve under.
            time: Evolution time. Default is 1.0.
            label: Optional label for the gate.
            synthesis: Synthesis method. Options:
                       - 'trotter' (default): First-order Trotter
                       - 'suzuki': Second-order Suzuki-Trotter
                       - 'qdrift': QDrift randomized compilation
            reps: Number of Trotter steps (higher = more accurate).
        """
        if not isinstance(operator, SparsePauliOp):
            raise TypeError(f"operator must be SparsePauliOp, got {type(operator)}")

        self._operator = operator
        self._time = time
        self._label = label or "PauliEvolution"
        self._synthesis = synthesis or 'trotter'
        self._reps = reps
        self._num_qubits = operator.num_qubits

    @property
    def operator(self) -> SparsePauliOp:
        """Return the Hamiltonian operator."""
        return self._operator

    @property
    def time(self) -> float:
        """Return the evolution time."""
        return self._time

    @property
    def num_qubits(self) -> int:
        """Return the number of qubits."""
        return self._num_qubits

    @property
    def n_qubits(self) -> int:
        """Alias for num_qubits, for consistency with QuantumCircuit."""
        return self._num_qubits

    @property
    def name(self) -> str:
        """Return the gate name."""
        return self._label

    @property
    def params(self) -> list:
        """Return gate parameters."""
        return [self._time]

    def apply_to_circuit(self, circuit: QuantumCircuit, qubits: Optional[List[int]] = None):
        """
        Apply the evolution gate to a quantum circuit.

        This decomposes the evolution into native gates using the specified
        synthesis method (Trotter-Suzuki decomposition).

        Args:
            circuit: The quantum circuit to apply evolution to.
            qubits: Optional qubit indices. If None, uses 0..num_qubits-1.
        """
        if qubits is None:
            qubits = list(range(self._num_qubits))

        if len(qubits) != self._num_qubits:
            raise ValueError(
                f"Expected {self._num_qubits} qubits, got {len(qubits)}"
            )

        if self._synthesis == 'trotter':
            self._first_order_trotter(circuit, qubits)
        elif self._synthesis == 'suzuki':
            self._second_order_suzuki(circuit, qubits)
        elif self._synthesis == 'qdrift':
            self._qdrift(circuit, qubits)
        else:
            raise ValueError(f"Unknown synthesis method: {self._synthesis}")

    def _first_order_trotter(self, circuit: QuantumCircuit, qubits: List[int]):
        """
        First-order Trotter decomposition.

        exp(-i*H*t) ≈ [Π_k exp(-i*c_k*P_k*t/r)]^r

        where r is the number of repetitions (Trotter steps).
        """
        dt = self._time / self._reps

        for _ in range(self._reps):
            for label, coeff in zip(self._operator.labels, self._operator.coeffs):
                angle = 2.0 * coeff.real * dt  # Factor of 2 from exp(-i*θ/2*P)
                self._apply_pauli_rotation(circuit, label, angle, qubits)

    def _second_order_suzuki(self, circuit: QuantumCircuit, qubits: List[int]):
        """
        Second-order Suzuki-Trotter decomposition.

        S2(t) = [Π_k exp(-i*c_k*P_k*t/2r)] * [Π_k' exp(-i*c_k'*P_k'*t/2r)]^†

        This gives O(t³/r²) error vs O(t²/r) for first-order.
        """
        dt = self._time / self._reps
        labels = self._operator.labels
        coeffs = self._operator.coeffs

        for _ in range(self._reps):
            # Forward sweep with half time step
            for label, coeff in zip(labels, coeffs):
                angle = coeff.real * dt  # Half the angle
                self._apply_pauli_rotation(circuit, label, angle, qubits)

            # Backward sweep with half time step
            for label, coeff in zip(reversed(labels), reversed(coeffs)):
                angle = coeff.real * dt
                self._apply_pauli_rotation(circuit, label, angle, qubits)

    def _qdrift(self, circuit: QuantumCircuit, qubits: List[int]):
        """
        QDrift randomized compilation.

        Randomly samples Pauli terms proportionally to their coefficient
        magnitudes, applying single-term evolutions.
        """
        labels = self._operator.labels
        coeffs = self._operator.coeffs

        # Compute probabilities from magnitudes
        magnitudes = np.abs(coeffs)
        total_magnitude = np.sum(magnitudes)

        if total_magnitude < 1e-15:
            return  # Nothing to evolve

        probabilities = magnitudes / total_magnitude

        # Number of random samples
        n_samples = self._reps * len(labels)
        dt_per_sample = 2.0 * total_magnitude * self._time / n_samples

        rng = np.random.RandomState(42)  # Deterministic for reproducibility

        for _ in range(n_samples):
            idx = rng.choice(len(labels), p=probabilities)
            sign = 1.0 if coeffs[idx].real >= 0 else -1.0
            self._apply_pauli_rotation(circuit, labels[idx], sign * dt_per_sample, qubits)

    def _apply_pauli_rotation(
        self,
        circuit: QuantumCircuit,
        pauli_label: str,
        angle: float,
        qubits: List[int]
    ):
        """
        Apply exp(-i * angle/2 * P) for a single Pauli string P.

        Decomposition:
        1. Change basis from Pauli eigenbasis to Z basis
        2. Apply CNOT ladder to compute parity
        3. Apply RZ rotation
        4. Undo CNOT ladder
        5. Undo basis change

        Args:
            circuit: Target quantum circuit.
            pauli_label: Pauli string (e.g., "ZZI", "XYZ").
            angle: Rotation angle.
            qubits: Qubit indices to apply to.
        """
        if abs(angle) < 1e-15:
            return  # Skip identity-like rotations

        # Identify non-identity positions
        # Qiskit convention: rightmost character = qubit 0
        active_qubits = []
        pauli_types = []

        for i, pauli_char in enumerate(reversed(pauli_label)):
            if pauli_char.upper() != 'I':
                active_qubits.append(qubits[i])
                pauli_types.append(pauli_char.upper())

        if not active_qubits:
            return  # All identity, nothing to do

        # Step 1: Basis change (X -> H, Y -> SdgH)
        for qubit, ptype in zip(active_qubits, pauli_types):
            if ptype == 'X':
                circuit.h(qubit)
            elif ptype == 'Y':
                circuit.sdg(qubit)
                circuit.h(qubit)

        # Step 2: CNOT ladder (compute parity into last active qubit)
        for i in range(len(active_qubits) - 1):
            circuit.cx(active_qubits[i], active_qubits[i + 1])

        # Step 3: RZ rotation on the last active qubit
        circuit.rz(angle, active_qubits[-1])

        # Step 4: Reverse CNOT ladder
        for i in range(len(active_qubits) - 2, -1, -1):
            circuit.cx(active_qubits[i], active_qubits[i + 1])

        # Step 5: Undo basis change
        for qubit, ptype in zip(active_qubits, pauli_types):
            if ptype == 'X':
                circuit.h(qubit)
            elif ptype == 'Y':
                circuit.h(qubit)
                circuit.s(qubit)

    def to_circuit(self, qubits: Optional[List[int]] = None) -> QuantumCircuit:
        """
        Convert the evolution gate to a quantum circuit.

        Args:
            qubits: Optional qubit mapping.

        Returns:
            QuantumCircuit with the evolution decomposed into native gates.
        """
        circuit = QuantumCircuit(self._num_qubits, name=self._label)
        self.apply_to_circuit(circuit, qubits)
        return circuit


class HamiltonianGate:
    """
    Hamiltonian simulation gate (IBM Qiskit compatible).

    Implements time evolution under an arbitrary Hamiltonian matrix:
        U(t) = exp(-i * H * t)

    Unlike PauliEvolutionGate, this accepts a full Hamiltonian matrix
    and uses matrix exponentiation directly.

    Example:
        >>> from zena.circuit.library.time_evolution import HamiltonianGate
        >>> import numpy as np
        >>>
        >>> # Single-qubit Hamiltonian: σ_x
        >>> sigma_x = np.array([[0, 1], [1, 0]])
        >>> gate = HamiltonianGate(sigma_x, time=np.pi/2)
        >>> print(gate)
        HamiltonianGate(2x2, t=1.5707963267948966)
    """

    def __init__(
        self,
        data: np.ndarray,
        time: float = 1.0,
        label: Optional[str] = None,
    ):
        """
        Initialize a HamiltonianGate.

        Args:
            data: Hermitian matrix representing the Hamiltonian.
                  Must be a square matrix with dimension 2^n for n qubits.
            time: Evolution time.
            label: Optional label for the gate.

        Raises:
            ValueError: If data is not a valid Hermitian matrix.
        """
        data = np.asarray(data, dtype=complex)

        if data.ndim != 2 or data.shape[0] != data.shape[1]:
            raise ValueError("Hamiltonian must be a square matrix")

        dim = data.shape[0]
        num_qubits = int(np.log2(dim))
        if 2 ** num_qubits != dim:
            raise ValueError(
                f"Matrix dimension ({dim}) must be a power of 2"
            )

        # Verify Hermiticity
        if not np.allclose(data, data.conj().T, atol=1e-10):
            raise ValueError("Hamiltonian matrix must be Hermitian (H = H†)")

        self._data = data
        self._time = time
        self._label = label or "Hamiltonian"
        self._num_qubits = num_qubits

    @property
    def hamiltonian(self) -> np.ndarray:
        """Return the Hamiltonian matrix."""
        return self._data.copy()

    @property
    def time(self) -> float:
        """Return the evolution time."""
        return self._time

    @property
    def num_qubits(self) -> int:
        """Return the number of qubits."""
        return self._num_qubits

    @property
    def name(self) -> str:
        """Return the gate name."""
        return self._label

    @property
    def params(self) -> list:
        """Return gate parameters."""
        return [self._time]

    def to_matrix(self) -> np.ndarray:
        """
        Compute the unitary matrix U = exp(-i*H*t).

        Returns:
            Unitary matrix as numpy array.
        """
        return _matrix_exp(-1j * self._data * self._time)

    def __repr__(self) -> str:
        dim = self._data.shape[0]
        return f"HamiltonianGate({dim}x{dim}, t={self._time})"

    def __str__(self) -> str:
        return self.__repr__()


class TrotterQRTE:
    """
    Trotterized Quantum Real Time Evolution (IBM Qiskit compatible).

    Simulates real-time evolution of a quantum state under a Hamiltonian
    using Trotter-Suzuki product formulas.

    This is the high-level interface for time evolution, combining:
    - SparsePauliOp (Hamiltonian description)
    - PauliEvolutionGate (gate implementation)
    - Trotter-Suzuki decomposition (synthesis)

    Example:
        >>> from zena.circuit.library.time_evolution import TrotterQRTE, SparsePauliOp
        >>>
        >>> hamiltonian = SparsePauliOp(["ZZ", "XX"], coeffs=[1.0, 0.5])
        >>> trotter = TrotterQRTE(num_timesteps=10)
        >>> circuit = trotter.evolve(hamiltonian, time=1.0, num_qubits=2)
    """

    def __init__(
        self,
        product_formula: str = 'trotter',
        num_timesteps: int = 1,
    ):
        """
        Initialize TrotterQRTE.

        Args:
            product_formula: Product formula to use:
                - 'trotter': First-order Trotter (Lie-Trotter)
                - 'suzuki': Second-order Suzuki-Trotter
                - 'qdrift': QDrift randomized
            num_timesteps: Number of Trotter steps.
        """
        self._product_formula = product_formula
        self._num_timesteps = num_timesteps

    def evolve(
        self,
        hamiltonian: SparsePauliOp,
        time: float = 1.0,
        num_qubits: Optional[int] = None,
        initial_state: Optional[QuantumCircuit] = None,
    ) -> QuantumCircuit:
        """
        Evolve a quantum state under the given Hamiltonian.

        Args:
            hamiltonian: The Hamiltonian (SparsePauliOp).
            time: Total evolution time.
            num_qubits: Number of qubits (inferred from hamiltonian if None).
            initial_state: Optional initial state circuit.

        Returns:
            QuantumCircuit implementing the time evolution.
        """
        if num_qubits is None:
            num_qubits = hamiltonian.num_qubits

        # Create evolution gate
        evolution = PauliEvolutionGate(
            operator=hamiltonian,
            time=time,
            synthesis=self._product_formula,
            reps=self._num_timesteps,
        )

        # Build circuit
        circuit = QuantumCircuit(num_qubits, name="TrotterQRTE")

        # Apply initial state
        if initial_state is not None:
            circuit.compose(initial_state, inplace=True)

        # Apply evolution
        evolution.apply_to_circuit(circuit)

        return circuit


# ─────────────────────────────────────────────────────────────
# Utility Functions
# ─────────────────────────────────────────────────────────────

def _matrix_exp(matrix: np.ndarray) -> np.ndarray:
    """
    Compute the matrix exponential exp(A) using eigendecomposition.

    For Hermitian matrices, this is exact and numerically stable.

    Args:
        matrix: Square matrix to exponentiate.

    Returns:
        Matrix exponential as numpy array.
    """
    eigenvalues, eigenvectors = np.linalg.eigh(
        (matrix + matrix.conj().T) / 2  # Ensure Hermiticity
    )
    return eigenvectors @ np.diag(np.exp(eigenvalues)) @ eigenvectors.conj().T


def pauli_evolution(
    hamiltonian: Union[SparsePauliOp, List[str]],
    time: float = 1.0,
    num_qubits: Optional[int] = None,
    reps: int = 1,
    synthesis: str = 'trotter',
    coeffs: Optional[List[float]] = None,
) -> QuantumCircuit:
    """
    Create a Pauli evolution circuit (functional API).

    Convenience function matching Qiskit's functional pattern.

    Args:
        hamiltonian: SparsePauliOp or list of Pauli strings.
        time: Evolution time.
        num_qubits: Number of qubits (inferred if None).
        reps: Number of Trotter steps.
        synthesis: Synthesis method ('trotter', 'suzuki', 'qdrift').
        coeffs: Coefficients for Pauli strings (if hamiltonian is a list).

    Returns:
        QuantumCircuit implementing the evolution.

    Example:
        >>> from zena.circuit.library.time_evolution import pauli_evolution
        >>> circuit = pauli_evolution(["ZZI", "IZZ"], time=1.0)
        >>> print(circuit.draw())
    """
    if isinstance(hamiltonian, list):
        hamiltonian = SparsePauliOp(hamiltonian, coeffs=coeffs)

    gate = PauliEvolutionGate(
        operator=hamiltonian,
        time=time,
        synthesis=synthesis,
        reps=reps,
    )

    return gate.to_circuit()
