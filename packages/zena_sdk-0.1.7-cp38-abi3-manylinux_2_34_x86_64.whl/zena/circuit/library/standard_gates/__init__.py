"""
Standard quantum gates following IBM Qiskit's Gate class pattern.

Each gate is a class that can be instantiated and applied to a QuantumCircuit.
This matches IBM Qiskit's circuit.library.standard_gates structure.
"""

import numpy as np
from typing import Optional


class Gate:
    """
    Base class for quantum gates (IBM Qiskit compatible).
    
    Attributes:
        name: Gate name
        num_qubits: Number of qubits the gate acts on
        params: List of gate parameters
        label: Optional descriptive label
    """
    
    def __init__(self, name: str, num_qubits: int, params: list, label: Optional[str] = None):
        """
        Initialize a Gate.
        
        Args:
            name: Gate name
            num_qubits: Number of qubits
            params: Parameter list
            label: Optional label
        """
        self.name = name
        self.num_qubits = num_qubits
        self.params = params
        self.label = label
    
    def __repr__(self) -> str:
        """String representation."""
        param_str = ', '.join(str(p) for p in self.params) if self.params else ''
        return f"{self.__class__.__name__}({param_str})"


# ============================================================================
# 1-Qubit Standard Gates
# ============================================================================

class HGate(Gate):
    """Hadamard gate (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize Hadamard gate."""
        super().__init__("h", 1, [], label)


class XGate(Gate):
    """Pauli-X (NOT) gate (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize X gate."""
        super().__init__("x", 1, [], label)


class YGate(Gate):
    """Pauli-Y gate (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize Y gate."""
        super().__init__("y", 1, [], label)


class ZGate(Gate):
    """Pauli-Z gate (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize Z gate."""
        super().__init__("z", 1, [], label)


class IGate(Gate):
    """Identity gate (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize identity gate."""
        super().__init__("id", 1, [], label)


class SGate(Gate):
    """S gate (sqrt(Z)) (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize S gate."""
        super().__init__("s", 1, [], label)


class SdgGate(Gate):
    """S-dagger gate (inverse S) (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize Sdg gate."""
        super().__init__("sdg", 1, [], label)


class TGate(Gate):
    """T gate (sqrt(S)) (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize T gate."""
        super().__init__("t", 1, [], label)


class TdgGate(Gate):
    """T-dagger gate (inverse T) (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize Tdg gate."""
        super().__init__("tdg", 1, [], label)


class SXGate(Gate):
    """sqrt(X) gate - IBM hardware standard (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize SX gate."""
        super().__init__("sx", 1, [], label)


class SXdgGate(Gate):
    """Inverse sqrt(X) gate (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize SXdg gate."""
        super().__init__("sxdg", 1, [], label)


# ============================================================================
# Parametric 1-Qubit Gates
# ============================================================================

class RXGate(Gate):
    """Rotation around X-axis (IBM Qiskit compatible)."""
    
    def __init__(self, theta: float, label: Optional[str] = None):
        """
        Initialize RX gate.
        
        Args:
            theta: Rotation angle in radians
            label: Optional label
        """
        super().__init__("rx", 1, [theta], label)
        self.theta = theta


class RYGate(Gate):
    """Rotation around Y-axis (IBM Qiskit compatible)."""
    
    def __init__(self, theta: float, label: Optional[str] = None):
        """
        Initialize RY gate.
        
        Args:
            theta: Rotation angle in radians
            label: Optional label
        """
        super().__init__("ry", 1, [theta], label)
        self.theta = theta


class RZGate(Gate):
    """Rotation around Z-axis (IBM Qiskit compatible)."""
    
    def __init__(self, theta: float, label: Optional[str] = None):
        """
        Initialize RZ gate.
        
        Args:
            theta: Rotation angle in radians
            label: Optional label
        """
        super().__init__("rz", 1, [theta], label)
        self.theta = theta


class PhaseGate(Gate):
    """Phase gate (IBM Qiskit compatible)."""
    
    def __init__(self, theta: float, label: Optional[str] = None):
        """
        Initialize Phase gate.
        
        Args:
            theta: Phase angle in radians
            label: Optional label
        """
        super().__init__("p", 1, [theta], label)
        self.theta = theta


class UGate(Gate):
    """
    Generic single-qubit rotation gate (IBM Qiskit compatible).
    
    U(θ, φ, λ) = RZ(φ) RY(θ) RZ(λ)
    """
    
    def __init__(self, theta: float, phi: float, lam: float, label: Optional[str] = None):
        """
        Initialize U gate.
        
        Args:
            theta: Rotation angle θ
            phi: Rotation angle φ
            lam: Rotation angle λ
            label: Optional label
        """
        super().__init__("u", 1, [theta, phi, lam], label)
        self.theta = theta
        self.phi = phi
        self.lam = lam


class RGate(Gate):
    """
    Generic rotation gate (IBM Qiskit compatible).
    
    R(θ, φ) = RZ(φ) RY(θ) RZ(-φ)
    """
    
    def __init__(self, theta: float, phi: float, label: Optional[str] = None):
        """
        Initialize R gate.
        
        Args:
            theta: Polar angle θ
            phi: Azimuthal angle φ
            label: Optional label
        """
        super().__init__("r", 1, [theta, phi], label)
        self.theta = theta
        self.phi = phi


# ============================================================================
# 2-Qubit Standard Gates
# ============================================================================

class CXGate(Gate):
    """Controlled-X (CNOT) gate (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize CX gate."""
        super().__init__("cx", 2, [], label)


class CYGate(Gate):
    """Controlled-Y gate (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize CY gate."""
        super().__init__("cy", 2, [], label)


class CZGate(Gate):
    """Controlled-Z gate (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize CZ gate."""
        super().__init__("cz", 2, [], label)


class SwapGate(Gate):
    """SWAP gate (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize SWAP gate."""
        super().__init__("swap", 2, [], label)


class CHGate(Gate):
    """Controlled-Hadamard gate (IBM Qiskit compatible)."""
    
    def __init__(self, label: Optional[str] = None):
        """Initialize CH gate."""
        super().__init__("ch", 2, [], label)


# ============================================================================
# Parametric 2-Qubit Gates
# ============================================================================

class CPhaseGate(Gate):
    """
    Controlled-Phase gate (IBM Qiskit compatible).
    
    Applies a phase rotation on the target qubit conditioned on the control qubit.
    """
    
    def __init__(self, theta: float, label: Optional[str] = None):
        """
        Initialize CPhase gate.
        
        Args:
            theta: Phase angle in radians
            label: Optional label
        """
        super().__init__("cp", 2, [theta], label)
        self.theta = theta


class CRXGate(Gate):
    """
    Controlled-RX gate (IBM Qiskit compatible).
    
    Applies RX rotation on target qubit conditioned on control qubit.
    """
    
    def __init__(self, theta: float, label: Optional[str] = None):
        """
        Initialize CRX gate.
        
        Args:
            theta: Rotation angle in radians
            label: Optional label
        """
        super().__init__("crx", 2, [theta], label)
        self.theta = theta


class CRYGate(Gate):
    """
    Controlled-RY gate (IBM Qiskit compatible).
    
    Applies RY rotation on target qubit conditioned on control qubit.
    """
    
    def __init__(self, theta: float, label: Optional[str] = None):
        """
        Initialize CRY gate.
        
        Args:
            theta: Rotation angle in radians
            label: Optional label
        """
        super().__init__("cry", 2, [theta], label)
        self.theta = theta


class CRZGate(Gate):
    """
    Controlled-RZ gate (IBM Qiskit compatible).
    
    Applies RZ rotation on target qubit conditioned on control qubit.
    """
    
    def __init__(self, theta: float, label: Optional[str] = None):
        """
        Initialize CRZ gate.
        
        Args:
            theta: Rotation angle in radians
            label: Optional label
        """
        super().__init__("crz", 2, [theta], label)
        self.theta = theta


class RXXGate(Gate):
    """
    Two-qubit XX rotation gate (IBM Qiskit compatible).
    
    RXX(θ) = exp(-iθ X⊗X / 2)
    Commonly used in quantum simulation and VQE algorithms.
    """
    
    def __init__(self, theta: float, label: Optional[str] = None):
        """
        Initialize RXX gate.
        
        Args:
            theta: Rotation angle in radians
            label: Optional label
        """
        super().__init__("rxx", 2, [theta], label)
        self.theta = theta



class RYYGate(Gate):
    """
    Two-qubit YY rotation gate (IBM Qiskit compatible).
    
    RYY(θ) = exp(-iθ Y⊗Y / 2)
    """
    
    def __init__(self, theta: float, label: Optional[str] = None):
        """
        Initialize RYY gate.
        
        Args:
            theta: Rotation angle in radians
            label: Optional label
        """
        super().__init__("ryy", 2, [theta], label)
        self.theta = theta


class RZZGate(Gate):
    """
    Two-qubit ZZ rotation gate (IBM Qiskit compatible).
    
    RZZ(θ) = exp(-iθ Z⊗Z / 2)
    """
    
    def __init__(self, theta: float, label: Optional[str] = None):
        """
        Initialize RZZ gate.
        
        Args:
            theta: Rotation angle in radians
            label: Optional label
        """
        super().__init__("rzz", 2, [theta], label)
        self.theta = theta


class RZXGate(Gate):
    """
    Two-qubit ZX rotation gate (IBM Qiskit compatible).
    
    RZX(θ) = exp(-iθ Z⊗X / 2)
    """
    
    def __init__(self, theta: float, label: Optional[str] = None):
        """
        Initialize RZX gate.
        
        Args:
            theta: Rotation angle in radians
            label: Optional label
        """
        super().__init__("rzx", 2, [theta], label)
        self.theta = theta


# ============================================================================
# 3-Qubit Standard Gates
# ============================================================================

class CCXGate(Gate):
    """
    Toffoli gate (controlled-controlled-X) (IBM Qiskit compatible).
    
    The Toffoli gate is a 3-qubit gate that flips the third qubit
    if and only if the first two qubits are both |1⟩.
    Essential for quantum computing and reversible logic.
    """
    
    def __init__(self, label: Optional[str] = None):
        """Initialize CCX (Toffoli) gate."""
        super().__init__("ccx", 3, [], label)


class CSwapGate(Gate):
    """
    Fredkin gate (controlled-SWAP) (IBM Qiskit compatible).
    
    The Fredkin gate is a 3-qubit gate that swaps the second and third
    qubits if and only if the first qubit (control) is |1⟩.
    """
    
    def __init__(self, label: Optional[str] = None):
        """Initialize CSWAP (Fredkin) gate."""
        super().__init__("cswap", 3, [], label)


# ============================================================================
# Gate Name Mapping (IBM Qiskit compatible)
# ============================================================================

def get_standard_gate_name_mapping():
    """
    Return a dictionary mapping gate names to gate classes.
    
    This function matches IBM Qiskit's get_standard_gate_name_mapping().
    
    Returns:
        dict: Mapping from gate name strings to Gate classes
        
    Example:
        >>> from zena.circuit.library import get_standard_gate_name_mapping
        >>> gate_map = get_standard_gate_name_mapping()
        >>> cx_gate = gate_map['cx']()
        >>> print(cx_gate)
        CXGate()
    """
    return {
        # 1-qubit gates
        "h": HGate,
        "x": XGate,
        "y": YGate,
        "z": ZGate,
        "id": IGate,
        "s": SGate,
        "sdg": SdgGate,
        "t": TGate,
        "tdg": TdgGate,
        "sx": SXGate,
        "sxdg": SXdgGate,
        "rx": RXGate,
        "ry": RYGate,
        "rz": RZGate,
        "r": RGate,
        "p": PhaseGate,
        "u": UGate,
        # 2-qubit gates
        "cx": CXGate,
        "cy": CYGate,
        "cz": CZGate,
        "swap": SwapGate,
        "ch": CHGate,
        # Parametric 2-qubit gates
        "cp": CPhaseGate,
        "crx": CRXGate,
        "cry": CRYGate,
        "crz": CRZGate,
        "rxx": RXXGate,
        "ryy": RYYGate,
        "rzz": RZZGate,
        "rzx": RZXGate,
        # 3-qubit gates
        "ccx": CCXGate,
        "cswap": CSwapGate,
    }
