"""
N-local circuits for variational quantum algorithms.

This module provides parameterized circuits that alternate between
rotation layers and entanglement layers, following IBM Qiskit's pattern.

These circuits are widely used in:
- Variational Quantum Eigensolver (VQE)
- Quantum Approximate Optimization Algorithm (QAOA)
- Quantum Machine Learning
"""

from typing import List, Optional, Union, Sequence
import numpy as np
from ...quantum_circuit import QuantumCircuit


class NLocal(QuantumCircuit):
    """
    N-local circuit (IBM Qiskit compatible).
    
    An N-local circuit alternates rotation layers with entanglement layers.
    Each layer can be customized with different gate types and patterns.
    
    Structure:
        [Initial Layer] - [Rotation] - [Entanglement] - [Rotation] - [Entanglement] - ...
    
    Example:
        >>> from zena.circuit.library import NLocal
        >>> circuit = NLocal(3, rotation_blocks=['ry'], entanglement_blocks=['cx'], reps=2)
        >>> print(circuit.draw())
    """
    
    def __init__(
        self,
        num_qubits: int,
        rotation_blocks: Optional[List[str]] = None,
        entanglement_blocks: Optional[List[str]] = None,
        entanglement: str = 'full',
        reps: int = 1,
        skip_final_rotation_layer: bool = False,
        skip_unentangled_qubits: bool = False,
        initial_state: Optional[QuantumCircuit] = None,
        parameter_prefix: str = 'θ',
        insert_barriers: bool = False,
        name: Optional[str] = None
    ):
        """
        Initialize an N-local circuit.
        
        Args:
            num_qubits: Number of qubits
            rotation_blocks: List of gate names for rotation layers (e.g., ['ry', 'rz'])
            entanglement_blocks: List of gate names for entanglement (e.g., ['cx', 'cz'])
            entanglement: Entanglement pattern ('full', 'linear', 'circular', 'sca')
            reps: Number of repetitions of rotation + entanglement layers
            skip_final_rotation_layer: If True, skip the last rotation layer
            skip_unentangled_qubits: If True, skip qubits not in entanglement
            initial_state: Optional initial state circuit
            parameter_prefix: Prefix for parameter names
            insert_barriers: If True, insert barriers between layers
            name: Circuit name
        """
        circuit_name = name or f"NLocal({num_qubits})"
        super().__init__(num_qubits, name=circuit_name)
        
        self._num_qubits = num_qubits
        self._rotation_blocks = rotation_blocks or ['ry']
        self._entanglement_blocks = entanglement_blocks or ['cx']
        self._entanglement = entanglement
        self._reps = reps
        self._skip_final_rotation_layer = skip_final_rotation_layer
        self._parameter_prefix = parameter_prefix
        self._insert_barriers = insert_barriers
        self._parameter_count = 0
        
        # Store parameters for later binding
        self._parameters = []
        
        # Build the circuit
        self._build_circuit(initial_state)
    
    @property
    def parameters(self) -> List[float]:
        """Return the list of parameters."""
        return self._parameters
    
    @property
    def num_parameters(self) -> int:
        """Return the number of parameters."""
        return len(self._parameters)
    
    def _build_circuit(self, initial_state: Optional[QuantumCircuit] = None):
        """Build the N-local circuit structure."""
        # Add initial state if provided
        if initial_state is not None:
            self.compose(initial_state, inplace=True)
        
        # Build layers
        for rep in range(self._reps):
            # Rotation layer
            self._add_rotation_layer()
            
            if self._insert_barriers:
                self.barrier()
            
            # Entanglement layer
            self._add_entanglement_layer()
            
            if self._insert_barriers:
                self.barrier()
        
        # Final rotation layer
        if not self._skip_final_rotation_layer:
            self._add_rotation_layer()
    
    def _add_rotation_layer(self):
        """Add a rotation layer to all qubits."""
        for qubit in range(self._num_qubits):
            for gate_name in self._rotation_blocks:
                param = self._get_next_parameter()
                self._apply_rotation_gate(gate_name, qubit, param)
    
    def _add_entanglement_layer(self):
        """Add an entanglement layer based on the entanglement pattern."""
        pairs = self._get_entanglement_pairs()
        
        for gate_name in self._entanglement_blocks:
            for pair in pairs:
                self._apply_entanglement_gate(gate_name, pair)
    
    def _get_entanglement_pairs(self) -> List[tuple]:
        """Get qubit pairs based on entanglement pattern."""
        n = self._num_qubits
        
        if self._entanglement == 'full':
            # All-to-all connectivity
            pairs = []
            for i in range(n):
                for j in range(i + 1, n):
                    pairs.append((i, j))
            return pairs
        
        elif self._entanglement == 'linear':
            # Linear chain: (0,1), (1,2), (2,3), ...
            return [(i, i + 1) for i in range(n - 1)]
        
        elif self._entanglement == 'circular':
            # Circular: linear + (n-1, 0)
            pairs = [(i, i + 1) for i in range(n - 1)]
            if n > 2:
                pairs.append((n - 1, 0))
            return pairs
        
        elif self._entanglement == 'sca':
            # Shifted Circular Alternating
            pairs = []
            for i in range(n - 1):
                pairs.append((i, i + 1))
            return pairs
        
        elif self._entanglement == 'reverse_linear':
            # Reverse linear: (n-2, n-1), (n-3, n-2), ...
            return [(i + 1, i) for i in range(n - 2, -1, -1)]
        
        else:
            # Default to linear
            return [(i, i + 1) for i in range(n - 1)]
    
    def _get_next_parameter(self) -> float:
        """Get the next parameter (placeholder value)."""
        param_value = 0.0  # Default value, can be bound later
        self._parameters.append(param_value)
        self._parameter_count += 1
        return param_value
    
    def _apply_rotation_gate(self, gate_name: str, qubit: int, param: float):
        """Apply a rotation gate."""
        gate_name = gate_name.lower()
        
        if gate_name == 'rx':
            self.rx(param, qubit)
        elif gate_name == 'ry':
            self.ry(param, qubit)
        elif gate_name == 'rz':
            self.rz(param, qubit)
        elif gate_name == 'h':
            self.h(qubit)
        elif gate_name == 'x':
            self.x(qubit)
        elif gate_name == 'y':
            self.y(qubit)
        elif gate_name == 'z':
            self.z(qubit)
        else:
            # Default to RY
            self.ry(param, qubit)
    
    def _apply_entanglement_gate(self, gate_name: str, pair: tuple):
        """Apply an entanglement gate."""
        gate_name = gate_name.lower()
        control, target = pair
        
        if gate_name == 'cx' or gate_name == 'cnot':
            self.cx(control, target)
        elif gate_name == 'cz':
            self.cz(control, target)
        elif gate_name == 'cy':
            self.cy(control, target)
        elif gate_name == 'swap':
            self.swap(control, target)
        elif gate_name == 'crx':
            param = self._get_next_parameter()
            self.crx(param, control, target)
        elif gate_name == 'cry':
            param = self._get_next_parameter()
            self.cry(param, control, target)
        elif gate_name == 'crz':
            param = self._get_next_parameter()
            self.crz(param, control, target)
        else:
            # Default to CX
            self.cx(control, target)
    
    def assign_parameters(self, values: Union[List[float], dict]) -> 'NLocal':
        """
        Assign parameter values to create a bound circuit.
        
        Args:
            values: List of parameter values or dict mapping parameter index to value
            
        Returns:
            New circuit with bound parameters
        """
        if isinstance(values, dict):
            # Convert dict to list
            param_values = [values.get(i, 0.0) for i in range(len(self._parameters))]
        else:
            param_values = list(values)
        
        # Create a new circuit with bound parameters
        bound_circuit = QuantumCircuit(self._num_qubits, name=f"{self.name}_bound")
        
        # Rebuild with actual parameter values
        param_idx = 0
        
        for rep in range(self._reps):
            # Rotation layer
            for qubit in range(self._num_qubits):
                for gate_name in self._rotation_blocks:
                    if param_idx < len(param_values):
                        value = param_values[param_idx]
                        param_idx += 1
                        self._apply_bound_rotation(bound_circuit, gate_name, qubit, value)
            
            # Entanglement layer
            pairs = self._get_entanglement_pairs()
            for gate_name in self._entanglement_blocks:
                for pair in pairs:
                    if gate_name.lower() in ['crx', 'cry', 'crz']:
                        if param_idx < len(param_values):
                            value = param_values[param_idx]
                            param_idx += 1
                            self._apply_bound_entanglement(bound_circuit, gate_name, pair, value)
                    else:
                        self._apply_bound_entanglement(bound_circuit, gate_name, pair, 0)
        
        # Final rotation layer
        if not self._skip_final_rotation_layer:
            for qubit in range(self._num_qubits):
                for gate_name in self._rotation_blocks:
                    if param_idx < len(param_values):
                        value = param_values[param_idx]
                        param_idx += 1
                        self._apply_bound_rotation(bound_circuit, gate_name, qubit, value)
        
        return bound_circuit
    
    def _apply_bound_rotation(self, circuit: QuantumCircuit, gate_name: str, qubit: int, value: float):
        """Apply rotation with bound value."""
        gate_name = gate_name.lower()
        if gate_name == 'rx':
            circuit.rx(value, qubit)
        elif gate_name == 'ry':
            circuit.ry(value, qubit)
        elif gate_name == 'rz':
            circuit.rz(value, qubit)
        elif gate_name == 'h':
            circuit.h(qubit)
        else:
            circuit.ry(value, qubit)
    
    def _apply_bound_entanglement(self, circuit: QuantumCircuit, gate_name: str, pair: tuple, value: float):
        """Apply entanglement with bound value."""
        gate_name = gate_name.lower()
        control, target = pair
        if gate_name in ['cx', 'cnot']:
            circuit.cx(control, target)
        elif gate_name == 'cz':
            circuit.cz(control, target)
        elif gate_name == 'crx':
            circuit.crx(value, control, target)
        elif gate_name == 'cry':
            circuit.cry(value, control, target)
        elif gate_name == 'crz':
            circuit.crz(value, control, target)
        else:
            circuit.cx(control, target)


class TwoLocal(NLocal):
    """
    Two-local circuit (IBM Qiskit compatible).
    
    A special case of N-local where entanglement blocks are two-qubit gates.
    This is the most commonly used variational circuit structure.
    
    Example:
        >>> from zena.circuit.library import TwoLocal
        >>> circuit = TwoLocal(3, 'ry', 'cx', entanglement='linear', reps=2)
        >>> print(circuit.draw())
    """
    
    def __init__(
        self,
        num_qubits: int,
        rotation_blocks: Union[str, List[str]] = 'ry',
        entanglement_blocks: Union[str, List[str]] = 'cx',
        entanglement: str = 'full',
        reps: int = 3,
        skip_final_rotation_layer: bool = False,
        insert_barriers: bool = False,
        name: Optional[str] = None
    ):
        """
        Initialize a TwoLocal circuit.
        
        Args:
            num_qubits: Number of qubits
            rotation_blocks: Single-qubit rotation gates (str or list)
            entanglement_blocks: Two-qubit entanglement gates (str or list)
            entanglement: Pattern ('full', 'linear', 'circular')
            reps: Number of repetitions
            skip_final_rotation_layer: Skip final rotation layer
            insert_barriers: Insert barriers between layers
            name: Circuit name
        """
        # Convert string to list
        if isinstance(rotation_blocks, str):
            rotation_blocks = [rotation_blocks]
        if isinstance(entanglement_blocks, str):
            entanglement_blocks = [entanglement_blocks]
        
        super().__init__(
            num_qubits=num_qubits,
            rotation_blocks=rotation_blocks,
            entanglement_blocks=entanglement_blocks,
            entanglement=entanglement,
            reps=reps,
            skip_final_rotation_layer=skip_final_rotation_layer,
            insert_barriers=insert_barriers,
            name=name or f"TwoLocal({num_qubits})"
        )


class RealAmplitudes(TwoLocal):
    """
    RealAmplitudes circuit (IBM Qiskit compatible).
    
    A hardware-efficient ansatz with only real amplitudes.
    Uses RY rotations and CX entanglement.
    
    This is a popular choice for VQE because:
    - Real-valued wavefunctions (no complex phases)
    - Hardware-efficient for superconducting qubits
    
    Example:
        >>> from zena.circuit.library import RealAmplitudes
        >>> circuit = RealAmplitudes(3, reps=2)
        >>> print(circuit.draw())
    """
    
    def __init__(
        self,
        num_qubits: int,
        entanglement: str = 'full',
        reps: int = 3,
        skip_final_rotation_layer: bool = False,
        insert_barriers: bool = False,
        name: Optional[str] = None
    ):
        """
        Initialize a RealAmplitudes circuit.
        
        Args:
            num_qubits: Number of qubits
            entanglement: Pattern ('full', 'linear', 'circular')
            reps: Number of repetitions
            skip_final_rotation_layer: Skip final rotation layer
            insert_barriers: Insert barriers between layers
            name: Circuit name
        """
        super().__init__(
            num_qubits=num_qubits,
            rotation_blocks='ry',
            entanglement_blocks='cx',
            entanglement=entanglement,
            reps=reps,
            skip_final_rotation_layer=skip_final_rotation_layer,
            insert_barriers=insert_barriers,
            name=name or f"RealAmplitudes({num_qubits})"
        )


class EfficientSU2(TwoLocal):
    """
    EfficientSU2 circuit (IBM Qiskit compatible).
    
    A hardware-efficient ansatz that can represent arbitrary SU(2) rotations.
    Uses RY and RZ rotations with CX entanglement.
    
    This circuit can prepare any single-qubit state and is widely used
    in variational algorithms.
    
    Example:
        >>> from zena.circuit.library import EfficientSU2
        >>> circuit = EfficientSU2(3, reps=2)
        >>> print(circuit.draw())
    """
    
    def __init__(
        self,
        num_qubits: int,
        entanglement: str = 'full',
        reps: int = 3,
        skip_final_rotation_layer: bool = False,
        insert_barriers: bool = False,
        name: Optional[str] = None
    ):
        """
        Initialize an EfficientSU2 circuit.
        
        Args:
            num_qubits: Number of qubits
            entanglement: Pattern ('full', 'linear', 'circular')
            reps: Number of repetitions
            skip_final_rotation_layer: Skip final rotation layer
            insert_barriers: Insert barriers between layers
            name: Circuit name
        """
        super().__init__(
            num_qubits=num_qubits,
            rotation_blocks=['ry', 'rz'],
            entanglement_blocks='cx',
            entanglement=entanglement,
            reps=reps,
            skip_final_rotation_layer=skip_final_rotation_layer,
            insert_barriers=insert_barriers,
            name=name or f"EfficientSU2({num_qubits})"
        )


class ExcitationPreserving(TwoLocal):
    """
    ExcitationPreserving circuit (IBM Qiskit compatible).
    
    A circuit that preserves the number of excitations (1s in the bitstring).
    Uses RZ rotations and RXX+RYY entanglement pattern.
    
    Useful for problems with particle number conservation like:
    - Molecular simulations
    - Fermionic systems
    
    Example:
        >>> from zena.circuit.library import ExcitationPreserving
        >>> circuit = ExcitationPreserving(3, reps=2)
        >>> print(circuit.draw())
    """
    
    def __init__(
        self,
        num_qubits: int,
        entanglement: str = 'full',
        reps: int = 3,
        skip_final_rotation_layer: bool = False,
        insert_barriers: bool = False,
        name: Optional[str] = None
    ):
        """
        Initialize an ExcitationPreserving circuit.
        
        Args:
            num_qubits: Number of qubits
            entanglement: Pattern ('full', 'linear', 'circular')
            reps: Number of repetitions
            skip_final_rotation_layer: Skip final rotation layer
            insert_barriers: Insert barriers between layers
            name: Circuit name
        """
        super().__init__(
            num_qubits=num_qubits,
            rotation_blocks='rz',
            entanglement_blocks='cx',  # Simplified; full impl uses RXX+RYY
            entanglement=entanglement,
            reps=reps,
            skip_final_rotation_layer=skip_final_rotation_layer,
            insert_barriers=insert_barriers,
            name=name or f"ExcitationPreserving({num_qubits})"
        )


# Convenience function matching Qiskit's functional API
def n_local(
    num_qubits: int,
    rotation_blocks: Union[str, List[str]] = 'ry',
    entanglement_blocks: Union[str, List[str]] = 'cx',
    entanglement: str = 'full',
    reps: int = 1
) -> NLocal:
    """
    Create an N-local circuit (functional API).
    
    This matches Qiskit's functional API for n_local circuits.
    
    Args:
        num_qubits: Number of qubits
        rotation_blocks: Rotation gate(s)
        entanglement_blocks: Entanglement gate(s)
        entanglement: Entanglement pattern
        reps: Number of repetitions
        
    Returns:
        NLocal circuit
        
    Example:
        >>> from zena.circuit.library import n_local
        >>> circuit = n_local(3, 'rx', 'cz')
    """
    if isinstance(rotation_blocks, str):
        rotation_blocks = [rotation_blocks]
    if isinstance(entanglement_blocks, str):
        entanglement_blocks = [entanglement_blocks]
    
    return NLocal(
        num_qubits=num_qubits,
        rotation_blocks=rotation_blocks,
        entanglement_blocks=entanglement_blocks,
        entanglement=entanglement,
        reps=reps
    )
