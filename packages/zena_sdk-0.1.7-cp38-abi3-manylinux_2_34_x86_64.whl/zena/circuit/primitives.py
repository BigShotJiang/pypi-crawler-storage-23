from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple, List, Any


class Qubit:
    def __init__(self, register=None, index=0):
        self._register = register
        self._index = index

    @property
    def register(self):
        return self._register

    @property
    def index(self):
        return self._index

    def __repr__(self):
        if self._register is not None:
            reg_name = getattr(self._register, "name", "q")
            reg_size = getattr(self._register, "size", "?")
            return "<Qubit register=(" + str(reg_size) + ', \"' + str(reg_name) + '\"), index=' + str(self._index) + ">"
        return "<Qubit index=" + str(self._index) + ">"

    def __eq__(self, other):
        if isinstance(other, Qubit):
            return self._register is other._register and self._index == other._index
        return NotImplemented

    def __hash__(self):
        return hash((id(self._register), self._index))


class Clbit:
    def __init__(self, register=None, index=0):
        self._register = register
        self._index = index

    @property
    def register(self):
        return self._register

    @property
    def index(self):
        return self._index

    def __repr__(self):
        if self._register is not None:
            reg_name = getattr(self._register, "name", "c")
            reg_size = getattr(self._register, "size", "?")
            return "<Clbit register=(" + str(reg_size) + ', \"' + str(reg_name) + '\"), index=' + str(self._index) + ">"
        return "<Clbit index=" + str(self._index) + ">"

    def __eq__(self, other):
        if isinstance(other, Clbit):
            return self._register is other._register and self._index == other._index
        return NotImplemented

    def __hash__(self):
        return hash((id(self._register), self._index))


@dataclass
class BitData:
    index: int
    registers: List[Tuple[Any, int]]


@dataclass
class CircuitInstruction:
    operation: Any
    qubits: Tuple[Qubit, ...]
    clbits: Tuple[Clbit, ...] = ()

    def __repr__(self):
        op_name = getattr(self.operation, "name", str(self.operation))
        num_q = getattr(self.operation, "num_qubits", len(self.qubits))
        num_c = getattr(self.operation, "num_clbits", len(self.clbits))
        params = getattr(self.operation, "params", [])
        return ("CircuitInstruction(operation=Instruction(name='" + op_name +
                "', num_qubits=" + str(num_q) +
                ", num_clbits=" + str(num_c) +
                ", params=" + str(list(params)) +
                "), qubits=" + str(self.qubits) +
                ", clbits=" + str(self.clbits) + ")")


@dataclass
class InstructionWrapper:
    name: str
    num_qubits: int
    num_clbits: int
    params: tuple = ()
    definition: Any = None

    def __repr__(self):
        return ("Instruction(name='" + self.name +
                "', num_qubits=" + str(self.num_qubits) +
                ", num_clbits=" + str(self.num_clbits) +
                ", params=" + str(list(self.params)) + ")")
