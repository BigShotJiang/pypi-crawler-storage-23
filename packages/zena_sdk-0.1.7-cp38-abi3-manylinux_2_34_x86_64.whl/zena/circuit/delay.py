"""Delay instruction.

Represents a delay (idle) operation on a qubit.
Matches Qiskit's ``qiskit/circuit/delay.py`` structure.
"""
from __future__ import annotations


class Delay:
    """Delay instruction (idle operation).

    Inserts a timing delay on a qubit. Can use a concrete
    duration (in dt) or a symbolic Stretch for deferred
    resolution.

    Args:
        duration: Duration in dt units, or a Stretch/Duration object.
        unit: Time unit (default 'dt').

    Example::

        from zena.circuit.delay import Delay
        qc.append(Delay(100), [0])
    """

    def __init__(self, duration, unit="dt"):
        self.name = "delay"
        self.num_qubits = 1
        self.num_clbits = 0
        self.duration = duration
        self.unit = unit
        self.params = [duration]

    def __repr__(self):
        return "Delay(duration={}, unit={})".format(self.duration, self.unit)
