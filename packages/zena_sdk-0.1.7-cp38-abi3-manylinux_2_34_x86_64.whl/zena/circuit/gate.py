"""Gate base class for quantum circuit operations.

Matches Qiskit's ``qiskit/circuit/gate.py`` structure.
"""
from __future__ import annotations


class Gate:
    """Base class for quantum gates.

    A gate is a unitary operation on one or more qubits.

    Args:
        name: Gate name string.
        num_qubits: Number of qubits the gate acts on.
        params: Gate parameters (e.g., rotation angles).
        label: Optional display label.
    """

    def __init__(self, name, num_qubits, params=None, label=None):
        self.name = name
        self.num_qubits = num_qubits
        self.num_clbits = 0
        self.params = params or []
        self.label = label or name

    def __repr__(self):
        if self.params:
            return "{}({})".format(self.name, ", ".join(str(p) for p in self.params))
        return "{}()".format(self.name)
