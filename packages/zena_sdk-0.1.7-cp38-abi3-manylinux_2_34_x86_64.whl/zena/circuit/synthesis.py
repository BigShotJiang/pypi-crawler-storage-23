"""Backward-compatible re-export. Use zena.synthesis instead."""
from ..synthesis import (
    UnitaryGate,
    decompose_single_qubit,
    synthesize_unitary,
    OneQubitEulerDecomposer,
    TwoQubitBasisDecomposer,
)

