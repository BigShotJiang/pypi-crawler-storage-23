"""Duration utilities for quantum circuits.

Matches Qiskit's ``qiskit/circuit/duration.py`` structure.
"""
from __future__ import annotations


class Duration:
    """Concrete time duration in dt (device time) units.

    Represents a fixed timing value used with delay operations
    and stretch expressions.

    Args:
        value: Duration in dt units (must be non-negative).

    Example::

        from zena.circuit.duration import Duration
        d = Duration(100)
        print(d.dt)  # 100
    """

    def __init__(self, value):
        if not isinstance(value, (int, float)):
            raise TypeError("Duration value must be numeric, got " + str(type(value)))
        if value < 0:
            raise ValueError("Duration must be non-negative, got " + str(value))
        self._value = value

    @property
    def dt(self):
        return self._value

    def __repr__(self):
        return "Duration({}dt)".format(self._value)

    def __eq__(self, other):
        if isinstance(other, Duration):
            return self._value == other._value
        return NotImplemented

    def __hash__(self):
        return hash(("Duration", self._value))
