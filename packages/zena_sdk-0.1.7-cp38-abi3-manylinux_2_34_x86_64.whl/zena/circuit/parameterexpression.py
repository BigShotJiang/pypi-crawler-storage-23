"""Parameter expression for symbolic circuit parameters.

Re-exports from parameter.py for Qiskit-compatible import paths.
Matches Qiskit's ``qiskit/circuit/parameterexpression.py``.
"""
from .parameter import ParameterExpression

__all__ = ["ParameterExpression"]
