"""Instruction class for quantum circuit operations.

Matches Qiskit's ``qiskit/circuit/instruction.py`` structure.
"""
from __future__ import annotations


class Instruction:
    """Base class for all circuit instructions.

    An instruction is a general operation (gate, measurement,
    barrier, etc.) that can be added to a quantum circuit.

    Args:
        name: Instruction name.
        num_qubits: Number of qubits.
        num_clbits: Number of classical bits.
        params: Instruction parameters.
    """

    def __init__(self, name, num_qubits=0, num_clbits=0, params=None, label=None):
        self.name = name
        self.num_qubits = num_qubits
        self.num_clbits = num_clbits
        self.params = params or []
        self.label = label

    def __repr__(self):
        return "Instruction({}, qubits={}, clbits={})".format(
            self.name, self.num_qubits, self.num_clbits
        )
