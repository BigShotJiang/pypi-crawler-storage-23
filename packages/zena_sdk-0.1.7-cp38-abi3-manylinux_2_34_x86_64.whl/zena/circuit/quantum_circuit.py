# zena/circuit/quantum_circuit.py
from __future__ import annotations
from typing import List, Dict, Optional, Union, Any, Set
from copy import deepcopy

from ..ir.types import Instruction
from ..errors import ValidationError
from .primitives import Qubit, Clbit, CircuitInstruction, BitData, InstructionWrapper


class QuantumCircuit:
    """A quantum circuit composed of qubits, classical bits, and instructions."""

    def __init__(self, *regs, name=None, **kwargs):
        from .register import QuantumRegister, ClassicalRegister

        n_qubits = 0
        n_clbits = 0
        self._qregs = []
        self._cregs = []

        if len(regs) > 0:
            first = regs[0]
            if isinstance(first, int):
                n_qubits = first
                if len(regs) > 1 and isinstance(regs[1], int):
                    n_clbits = regs[1]
                if n_qubits > 0:
                    self._qregs.append(QuantumRegister(n_qubits, "q"))
                if n_clbits > 0:
                    self._cregs.append(ClassicalRegister(n_clbits, "c"))
            else:
                for reg in regs:
                    if isinstance(reg, QuantumRegister):
                        self._qregs.append(reg)
                        n_qubits += reg.size
                    elif isinstance(reg, ClassicalRegister):
                        self._cregs.append(reg)
                        n_clbits += reg.size

        if "n_qubits" in kwargs:
            n_qubits = kwargs["n_qubits"]
        if "n_clbits" in kwargs:
            n_clbits = kwargs["n_clbits"]

        if n_qubits < 0:
            raise ValidationError("n_qubits must be a non-negative integer")
        if n_clbits < 0:
            raise ValidationError("n_clbits must be a non-negative integer")

        self.n_qubits = n_qubits
        self.n_clbits = n_clbits
        self.name = name
        self._instructions = []
        self._qubit_objects = []
        self._clbit_objects = []
        self._build_bit_objects()
        self._parameter_table = {}

    def _build_bit_objects(self):
        from .register import QuantumRegister, ClassicalRegister
        self._qubit_objects = []
        self._clbit_objects = []
        if self._qregs:
            for qreg in self._qregs:
                for i in range(qreg.size):
                    self._qubit_objects.append(Qubit(register=qreg, index=i))
        else:
            for i in range(self.n_qubits):
                self._qubit_objects.append(Qubit(index=i))
        if self._cregs:
            for creg in self._cregs:
                for i in range(creg.size):
                    self._clbit_objects.append(Clbit(register=creg, index=i))
        else:
            for i in range(self.n_clbits):
                self._clbit_objects.append(Clbit(index=i))

    # Properties
    @property
    def qubits(self):
        return list(self._qubit_objects)

    @property
    def clbits(self):
        return list(self._clbit_objects)

    @property
    def qregs(self):
        return list(self._qregs)

    @property
    def cregs(self):
        return list(self._cregs)

    @property
    def num_qubits(self):
        return self.n_qubits

    @property
    def num_clbits(self):
        return self.n_clbits

    @property
    def instructions(self):
        return list(self._instructions)

    @property
    def data(self):
        result = []
        for inst in self._instructions:
            qubit_tuple = tuple(
                self._qubit_objects[q] if q < len(self._qubit_objects) else Qubit(index=q)
                for q in inst.qubits
            )
            clbit_tuple = ()
            if inst.clbits:
                clbit_tuple = tuple(
                    self._clbit_objects[c] if c < len(self._clbit_objects) else Clbit(index=c)
                    for c in inst.clbits
                )
            operation = InstructionWrapper(
                name=inst.name,
                num_qubits=len(inst.qubits),
                num_clbits=len(inst.clbits) if inst.clbits else 0,
                params=inst.params,
            )
            result.append(CircuitInstruction(operation=operation, qubits=qubit_tuple, clbits=clbit_tuple))
        return result

    @property
    def parameters(self):
        from .parameter import Parameter, ParameterExpression, ParameterView
        params = set()
        for inst in self._instructions:
            for p in inst.params:
                if isinstance(p, Parameter):
                    params.add(p)
                elif isinstance(p, ParameterExpression):
                    params.update(p.parameters)
        return ParameterView(sorted(params, key=lambda x: x.name))

    @property
    def num_parameters(self):
        return len(self.parameters)

    # Core methods
    def find_bit(self, bit):
        if isinstance(bit, tuple) and len(bit) == 2:
            register, local_idx = bit
            from .register import QuantumRegister, ClassicalRegister
            if isinstance(register, QuantumRegister):
                global_idx = 0
                for qreg in self._qregs:
                    if qreg is register:
                        return BitData(index=global_idx + local_idx, registers=[(register, local_idx)])
                    global_idx += qreg.size
            elif isinstance(register, ClassicalRegister):
                global_idx = 0
                for creg in self._cregs:
                    if creg is register:
                        return BitData(index=global_idx + local_idx, registers=[(register, local_idx)])
                    global_idx += creg.size
        if isinstance(bit, Qubit):
            for i, q in enumerate(self._qubit_objects):
                if q == bit:
                    regs = []
                    if bit.register is not None:
                        regs = [(bit.register, bit.index)]
                    return BitData(index=i, registers=regs)
        if isinstance(bit, Clbit):
            for i, c in enumerate(self._clbit_objects):
                if c == bit:
                    regs = []
                    if bit.register is not None:
                        regs = [(bit.register, bit.index)]
                    return BitData(index=i, registers=regs)
        raise ValidationError("Bit not found in this circuit")

    def depth(self):
        if not self._instructions:
            return 0
        qubit_depths = [0] * self.n_qubits
        for inst in self._instructions:
            if inst.name == "barrier":
                continue
            involved = list(inst.qubits)
            if not involved:
                continue
            max_depth = max(qubit_depths[q] for q in involved if q < self.n_qubits)
            new_depth = max_depth + 1
            for q in involved:
                if q < self.n_qubits:
                    qubit_depths[q] = new_depth
        return max(qubit_depths) if qubit_depths else 0

    def size(self):
        return sum(1 for inst in self._instructions if inst.name not in ("barrier",))

    def width(self):
        return self.n_qubits + self.n_clbits

    def num_nonlocal_gates(self):
        return sum(1 for inst in self._instructions if len(inst.qubits) > 1 and inst.name != "barrier")

    def copy(self, name=None):
        new_qc = deepcopy(self)
        if name is not None:
            new_qc.name = name
        return new_qc

    def copy_empty_like(self, name=None):
        """Return an empty circuit with the same structure but no instructions."""
        new_qc = QuantumCircuit(self.n_qubits, self.n_clbits,
                                name=name or self.name)
        return new_qc

    def reverse_bits(self):
        """Return a new circuit with qubit labels reversed (k -> n-1-k)."""
        from ..ir.types import Instruction as IRInstruction
        n = self.n_qubits
        new_qc = QuantumCircuit(n, self.n_clbits, name=self.name)
        for inst in self._instructions:
            new_qubits = tuple(n - 1 - q for q in inst.qubits)
            new_clbits = getattr(inst, "clbits", ())
            new_qc._instructions.append(IRInstruction(
                name=inst.name,
                qubits=new_qubits,
                clbits=new_clbits,
                params=getattr(inst, "params", []),
            ))
        return new_qc

    def append(self, gate, qargs, cargs=None):
        from .parameter import Parameter, ParameterExpression
        name = getattr(gate, "name", None)
        params = getattr(gate, "params", [])
        if name is None:
            raise ValidationError("append expects a Gate object with a .name attribute")
        if not isinstance(qargs, (list, tuple)):
            qargs = [qargs]
        qubits = tuple(qargs)
        self._check_qubits(*qubits)
        if hasattr(gate, "num_qubits"):
            if len(qubits) != gate.num_qubits:
                raise ValidationError("Gate " + name + " expects " + str(gate.num_qubits) + " qubits, got " + str(len(qubits)))
        clbits_tuple = ()
        if cargs:
            if not isinstance(cargs, (list, tuple)):
                cargs = [cargs]
            clbits_tuple = tuple(cargs)
        self._instructions.append(Instruction(name=name, qubits=qubits, clbits=clbits_tuple, params=tuple(params)))
        return self

    def compose(self, other, qubits=None, clbits=None, inplace=False):
        dest = self if inplace else self.copy()
        if qubits is None:
            qubits = list(range(other.n_qubits))
        if len(qubits) != other.n_qubits:
            raise ValidationError("Expected " + str(other.n_qubits) + " qubits for composition, got " + str(len(qubits)))
        for inst in other._instructions:
            new_qubits = tuple(qubits[q] for q in inst.qubits)
            new_clbits = inst.clbits
            if clbits and inst.clbits:
                new_clbits = tuple(clbits[c] for c in inst.clbits)
            dest._instructions.append(Instruction(name=inst.name, qubits=new_qubits, clbits=new_clbits, params=inst.params))
        return dest

    def to_instruction(self, label=None):
        inst_name = label or self.name or "circuit"
        return InstructionWrapper(name=inst_name, num_qubits=self.n_qubits, num_clbits=self.n_clbits, params=(), definition=self.copy())

    def to_gate(self, label=None):
        return CircuitGate(name=label or self.name or "unitary", num_qubits=self.n_qubits, params=[], definition=self.copy())

    def decompose(self, reps=1):
        """Decompose high-level gates into basis gates.

        Replaces ``unitary`` instructions with synthesized gate sequences
        (U + CX) via the ZYZ / KAK decomposition, matching the behaviour
        described in the IBM docs:

            https://quantum.cloud.ibm.com/docs/en/guides/synthesize-unitary-operators

        Args:
            reps: Number of decomposition passes (default 1).

        Returns:
            A new QuantumCircuit with unitary gates expanded.

        Example::

            from zena.quantum_info import Operator
            U = Operator(qc)
            better = QuantumCircuit(2)
            better.unitary(U, range(2))
            better.decompose().draw()
        """
        import numpy as np
        from ..synthesis import synthesize_unitary

        result = QuantumCircuit(self.n_qubits, self.n_clbits, name=self.name)

        for inst in self._instructions:
            if inst.name == "unitary" and inst.params:
                matrix = np.array(inst.params[0], dtype=complex)
                qubits = inst.qubits
                num_q = int(round(np.log2(matrix.shape[0])))

                # Synthesize into basis gates
                gates = synthesize_unitary(matrix)

                for gate_name, gate_qubits, gate_params in gates:
                    if gate_name == "unitary":
                        # Could not be further decomposed — keep as-is
                        mapped_qubits = tuple(qubits[q] for q in gate_qubits)
                        result._instructions.append(
                            Instruction(
                                name="unitary",
                                qubits=mapped_qubits,
                                clbits=(),
                                params=gate_params,
                            )
                        )
                    elif gate_name == "u":
                        mapped_q = qubits[gate_qubits[0]]
                        result._instructions.append(
                            Instruction(
                                name="u",
                                qubits=(mapped_q,),
                                clbits=(),
                                params=gate_params,
                            )
                        )
                    elif gate_name == "cx":
                        mapped_ctrl = qubits[gate_qubits[0]]
                        mapped_targ = qubits[gate_qubits[1]]
                        result._instructions.append(
                            Instruction(
                                name="cx",
                                qubits=(mapped_ctrl, mapped_targ),
                                clbits=(),
                                params=(),
                            )
                        )
                    else:
                        mapped_qubits = tuple(qubits[q] for q in gate_qubits)
                        result._instructions.append(
                            Instruction(
                                name=gate_name,
                                qubits=mapped_qubits,
                                clbits=(),
                                params=gate_params,
                            )
                        )
            else:
                result._instructions.append(inst)

        # Additional passes if reps > 1
        if reps > 1:
            return result.decompose(reps - 1)

        return result

    # Measurement methods
    def measure(self, q, c):
        if isinstance(q, (list, tuple, range)):
            qubits_list = list(q)
            clbits_list = list(c) if isinstance(c, (list, tuple, range)) else [c]
            if len(qubits_list) != len(clbits_list):
                raise ValidationError("Number of qubits != number of classical bits")
            for qi, ci in zip(qubits_list, clbits_list):
                self._check_qubits(qi)
                self._check_clbits(ci)
                self._instructions.append(Instruction(name="measure", qubits=(qi,), clbits=(ci,)))
        else:
            self._check_qubits(q)
            self._check_clbits(c)
            self._instructions.append(Instruction(name="measure", qubits=(q,), clbits=(c,)))
        return self

    def measure_all(self, add_bits=True):
        if add_bits and self.n_clbits < self.n_qubits:
            self.n_clbits = self.n_qubits
            from .register import ClassicalRegister
            self._cregs = [ClassicalRegister(self.n_clbits, "meas")]
            self._clbit_objects = [Clbit(register=self._cregs[0], index=i) for i in range(self.n_clbits)]
        self.barrier()
        for i in range(self.n_qubits):
            self._instructions.append(Instruction(name="measure", qubits=(i,), clbits=(i,)))
        return self

    def measure_active(self, inplace=True):
        dest = self if inplace else self.copy()
        active_qubits = set()
        for inst in dest._instructions:
            if inst.name not in ("barrier", "measure"):
                for q in inst.qubits:
                    active_qubits.add(q)
        active_sorted = sorted(active_qubits)
        if not active_sorted:
            return dest
        needed = len(active_sorted)
        if dest.n_clbits < needed:
            dest.n_clbits = needed
            from .register import ClassicalRegister
            dest._cregs = [ClassicalRegister(needed, "meas")]
            dest._clbit_objects = [Clbit(register=dest._cregs[0], index=i) for i in range(needed)]
        dest.barrier()
        for idx, q in enumerate(active_sorted):
            dest._instructions.append(Instruction(name="measure", qubits=(q,), clbits=(idx,)))
        return dest


    # =========================================================================
    # Classical feedforward and control flow (Dynamic Circuits)
    # =========================================================================

    def if_test(self, condition, label=None):
        """Conditionally apply operations based on a classical value.

        Returns a context manager that captures instructions for the
        conditional block. The context manager yields an else-context
        that can be used to define an else block.

        Args:
            condition: Either:
                - A tuple (clbit_or_register, value): Execute the block
                  if the classical bit/register equals the given value.
                - An Expr object: Execute the block if the expression
                  evaluates to True (non-zero).
            label: Optional label for the conditional block.

        Returns:
            A context manager (_IfContext). Use as:

                with qc.if_test((clbit, 1)) as else_:
                    qc.x(0)        # Executed if clbit == 1
                with else_:
                    qc.h(0)        # Executed if clbit != 1

        Note:
            - Nested conditionals are NOT allowed.
            - Reset or measurements inside conditionals are NOT supported.
            - for, while, and switch are NOT supported.
            - Operand must be 32 or fewer bits.
        """
        from .controlflow import _IfContext
        return _IfContext(self, condition)

    def for_loop(self, indexset, loop_parameter=None, label=None):
        """Create a for-loop over a sequence of integer values.

        Returns a context manager that captures the loop body. The loop
        parameter (if provided) represents the iteration variable.

        Args:
            indexset: Iterable of integer values to iterate over.
            loop_parameter: Optional Parameter for the iteration variable.
            label: Optional label for the loop.

        Returns:
            A context manager (_ForLoopContext). Use as::

                with qc.for_loop(range(5)) as i:
                    qc.rx(0.1, 0)

        Note:
            This is NOT yet supported by IBM Quantum Runtime.
            It is provided for API completeness with Qiskit SDK.
        """
        from .controlflow import _ForLoopContext
        return _ForLoopContext(self, indexset, loop_parameter)

    def while_loop(self, condition, label=None):
        """Create a while-loop that repeats until condition is False.

        Returns a context manager that captures the loop body.

        Args:
            condition: Tuple (clbit_or_register, value) or Expr object.
            label: Optional label for the loop.

        Returns:
            A context manager (_WhileLoopContext). Use as::

                with qc.while_loop((clbit, 0)):
                    qc.h(0)
                    qc.measure(0, 0)

        Note:
            This is NOT yet supported by IBM Quantum Runtime.
            It is provided for API completeness with Qiskit SDK.
        """
        from .controlflow import _WhileLoopContext
        return _WhileLoopContext(self, condition)

    def switch(self, target, label=None):
        """Create a switch/case block on a classical value.

        Returns a context manager with a callable ``case`` interface.

        Args:
            target: Classical bit, register, or Expr to switch on.
            label: Optional label for the switch.

        Returns:
            A context manager (_SwitchContext). Use as::

                with qc.switch(clbit) as case:
                    with case(0):
                        qc.x(0)
                    with case(1):
                        qc.h(0)

        Note:
            This is NOT yet supported by IBM Quantum Runtime.
            It is provided for API completeness with Qiskit SDK.
        """
        from .controlflow import _SwitchContext
        return _SwitchContext(self, target)

    # Parameter support
    def assign_parameters(self, parameters=None, inplace=False, **kwargs):
        from .parameter import Parameter, ParameterExpression, ParameterVector
        dest = self if inplace else self.copy()
        if parameters is None:
            return dest
        if isinstance(parameters, (list, tuple)):
            param_list = list(dest.parameters)
            if len(parameters) != len(param_list):
                raise ValidationError("Expected " + str(len(param_list)) + " parameter values, got " + str(len(parameters)))
            param_dict = dict(zip(param_list, parameters))
        elif isinstance(parameters, ParameterVector):
            param_list = list(dest.parameters)
            param_dict = dict(zip(param_list, parameters.params))
        else:
            param_dict = parameters
        new_instructions = []
        for inst in dest._instructions:
            new_params = []
            changed = False
            for p in inst.params:
                if isinstance(p, Parameter) and p in param_dict:
                    val = param_dict[p]
                    if isinstance(val, Parameter):
                        new_params.append(val)
                    else:
                        new_params.append(float(val))
                    changed = True
                elif isinstance(p, ParameterExpression):
                    bound = p.bind(param_dict)
                    new_params.append(bound)
                    changed = True
                else:
                    new_params.append(p)
            if changed:
                new_instructions.append(Instruction(name=inst.name, qubits=inst.qubits, clbits=inst.clbits, params=tuple(new_params)))
            else:
                new_instructions.append(inst)
        dest._instructions = new_instructions
        return dest

    # Validation

    # =========================================================================
    # Stretch / Deferred timing resolution
    # =========================================================================

    def add_stretch(self, name):
        """Declare a stretch variable for deferred timing resolution.

        A stretch represents a symbolic timing variable whose concrete
        value is resolved at compile time, after the exact duration of
        calibrated gates is known. The compiler minimizes the stretch
        duration subject to timing constraints.

        Args:
            name: A unique name for this stretch variable.

        Returns:
            Stretch: A symbolic stretch object that can be used as a
                     delay duration or in stretch expressions.

        Example::

            s = circuit.add_stretch("s")
            circuit.delay(s, qubit)
            circuit.delay(expr.mul(s, 2), qubit)

        Note:
            - At most one stretch per qubit set between barriers.
            - A stretch cannot span multiple barrier regions.
            - Expressions limited to form X*stretch + Y.
        """
        from .stretch import Stretch

        s = Stretch(name)
        if not hasattr(self, '_stretches'):
            self._stretches = {}
        if name in self._stretches:
            raise ValueError("Stretch '{}' already exists in this circuit".format(name))
        self._stretches[name] = s
        return s

    @property
    def stretches(self):
        """Return all stretch variables declared on this circuit."""
        if not hasattr(self, '_stretches'):
            self._stretches = {}
        return dict(self._stretches)

    def delay(self, duration, qarg, unit="dt"):
        """Insert a delay instruction on one or more qubits.

        A delay represents idle time on a qubit. The duration can be:
        - An integer or float (concrete delay in dt units).
        - A Stretch variable (deferred resolution at compile time).
        - A StretchExpr (e.g., expr.mul(s, 2)).
        - A Duration object.

        Args:
            duration: The delay duration. Can be a number, Stretch,
                      StretchExpr, or Duration.
            qarg: Qubit index or list of qubit indices.
            unit: Time unit (default "dt").

        Returns:
            This circuit (for chaining).

        Example::

            circuit.delay(100, 0)
            s = circuit.add_stretch("s")
            circuit.delay(s, 1)
            circuit.delay(expr.mul(s, 2), 1)
        """
        from .stretch import Stretch, StretchExpr, Duration as Dur

        # Normalize qarg to list
        if isinstance(qarg, int):
            qubits_list = [qarg]
        elif isinstance(qarg, (list, tuple)):
            qubits_list = list(qarg)
        else:
            qubits_list = [qarg]

        for q in qubits_list:
            self._check_qubits(q)

        # Determine the duration param
        if isinstance(duration, (Stretch, StretchExpr)):
            dur_param = duration
        elif isinstance(duration, Dur):
            dur_param = duration.value
        elif isinstance(duration, (int, float)):
            dur_param = duration
        else:
            dur_param = duration

        for q in qubits_list:
            self._instructions.append(
                Instruction(
                    name="delay",
                    qubits=(q,),
                    clbits=(),
                    params=(dur_param, unit),
                )
            )
        return self


    # =========================================================================
    # Unitary synthesis
    # =========================================================================

    def unitary(self, obj, qubits, label=None):
        """Apply an arbitrary unitary matrix to qubits.

        Synthesizes the given unitary matrix into a gate sequence and
        applies it to the specified qubits.

        Args:
            obj: A unitary matrix (numpy array or nested list),
                 an Operator, or a UnitaryGate.
            qubits: Qubit indices to apply the unitary to.
                    Can be int, list, range, or circuit.qubits.
            label: Optional label.

        Returns:
            This circuit (for chaining).

        Example::

            import numpy as np
            U = 0.5 * np.array([
                [1, 1, 1, 1],
                [-1, 1, -1, 1],
                [-1, -1, 1, 1],
                [-1, 1, 1, -1]
            ])
            qc = QuantumCircuit(2)
            qc.unitary(U, [0, 1])
        """
        import numpy as np

        # Handle Operator objects
        if hasattr(obj, 'data') and hasattr(obj, 'num_qubits'):
            matrix = np.array(obj.data, dtype=complex)
        elif hasattr(obj, '_data'):
            matrix = np.array(obj._data, dtype=complex)
        else:
            matrix = np.array(obj, dtype=complex)

        # Normalize qubit args
        if isinstance(qubits, int):
            qubits_list = [qubits]
        elif isinstance(qubits, range):
            qubits_list = list(qubits)
        elif isinstance(qubits, (list, tuple)):
            # Handle Qubit objects
            resolved = []
            for q in qubits:
                if isinstance(q, int):
                    resolved.append(q)
                elif hasattr(q, 'index'):
                    resolved.append(q.index)
                else:
                    resolved.append(int(q))
            qubits_list = resolved
        else:
            qubits_list = list(range(self.n_qubits))

        for q in qubits_list:
            self._check_qubits(q)

        num_qubits = int(np.log2(matrix.shape[0]))
        if len(qubits_list) != num_qubits:
            from ..errors import ValidationError
            raise ValidationError(
                "Unitary acts on {} qubits but {} qubits given".format(
                    num_qubits, len(qubits_list)))

        self._instructions.append(
            Instruction(
                name="unitary",
                qubits=tuple(qubits_list),
                clbits=(),
                params=(matrix,),
            )
        )
        return self

    def _check_qubits(self, *qs):
        for q in qs:
            if not isinstance(q, int):
                raise ValidationError("qubit index must be int, got " + str(type(q)))
            if q < 0:
                raise ValidationError("qubit index must be non-negative, got " + str(q))

    def _check_clbits(self, *cs):
        for c in cs:
            if not isinstance(c, int):
                raise ValidationError("classical bit index must be int, got " + str(type(c)))
            if c < 0:
                raise ValidationError("classical bit index must be non-negative, got " + str(c))

    # Drawing
    def draw(self, mode: str = "text", reverse_bits: bool = False, **kwargs) -> str:
        if mode not in ("text", "mpl"):
            raise ValueError("Unsupported draw mode: " + mode)
        from ..visualization.text_drawer import draw_ascii
        if reverse_bits:
            from ..ir.types import Instruction as IRInstruction
            n = self.n_qubits
            remapped = []
            for inst in self._instructions:
                new_qubits = tuple(n - 1 - q for q in inst.qubits)
                remapped.append(IRInstruction(
                    name=inst.name,
                    qubits=new_qubits,
                    clbits=getattr(inst, "clbits", ()),
                    params=getattr(inst, "params", []),
                ))
            return draw_ascii(n, remapped)

        return draw_ascii(self.n_qubits, self._instructions)

    def __repr__(self):
        name_str = ", name='" + self.name + "'" if self.name else ""
        return "QuantumCircuit(" + str(self.n_qubits) + ", " + str(self.n_clbits) + name_str + ")"

    def __len__(self):
        return len(self._instructions)

    # Gate builders
    def id(self, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="id", qubits=(q,)))
        return self

    def h(self, q):
        self._check_qubits(q)
        self._instructions.append(Instruction("h", (q,), ()))
        return self

    def x(self, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="x", qubits=(q,)))
        return self

    def y(self, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="y", qubits=(q,)))
        return self

    def z(self, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="z", qubits=(q,)))
        return self

    def s(self, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="s", qubits=(q,)))
        return self

    def sdg(self, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="sdg", qubits=(q,)))
        return self

    def t(self, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="t", qubits=(q,)))
        return self

    def tdg(self, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="tdg", qubits=(q,)))
        return self

    def sx(self, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="sx", qubits=(q,)))
        return self

    def sxdg(self, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="sxdg", qubits=(q,)))
        return self

    def rx(self, theta, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="rx", qubits=(q,), params=(theta,)))
        return self

    def ry(self, theta, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="ry", qubits=(q,), params=(theta,)))
        return self

    def rz(self, theta, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="rz", qubits=(q,), params=(theta,)))
        return self

    def p(self, theta, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="p", qubits=(q,), params=(theta,)))
        return self

    def u(self, theta, phi, lam, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="u", qubits=(q,), params=(theta, phi, lam)))
        return self

    def r(self, theta, phi, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="r", qubits=(q,), params=(theta, phi)))
        return self

    def cx(self, control, target):
        if control == target:
            raise ValidationError("control and target must differ")
        self._check_qubits(control, target)
        self._instructions.append(Instruction(name="cx", qubits=(control, target)))
        return self

    def cy(self, control, target):
        if control == target:
            raise ValidationError("control and target must differ")
        self._check_qubits(control, target)
        self._instructions.append(Instruction(name="cy", qubits=(control, target)))
        return self

    def cz(self, control, target):
        if control == target:
            raise ValidationError("control and target must differ")
        self._check_qubits(control, target)
        self._instructions.append(Instruction(name="cz", qubits=(control, target)))
        return self

    def ch(self, control, target):
        if control == target:
            raise ValidationError("control and target must differ")
        self._check_qubits(control, target)
        self._instructions.append(Instruction(name="ch", qubits=(control, target)))
        return self

    def swap(self, q1, q2):
        if q1 == q2:
            raise ValidationError("swap qubits must differ")
        self._check_qubits(q1, q2)
        self._instructions.append(Instruction(name="swap", qubits=(q1, q2)))
        return self

    def cp(self, theta, control, target):
        self._check_qubits(control, target)
        self._instructions.append(Instruction(name="cp", qubits=(control, target), params=(theta,)))
        return self

    def crx(self, theta, control, target):
        if control == target:
            raise ValidationError("control and target must differ")
        self._check_qubits(control, target)
        self._instructions.append(Instruction(name="crx", qubits=(control, target), params=(theta,)))
        return self

    def cry(self, theta, control, target):
        if control == target:
            raise ValidationError("control and target must differ")
        self._check_qubits(control, target)
        self._instructions.append(Instruction(name="cry", qubits=(control, target), params=(theta,)))
        return self

    def crz(self, theta, control, target):
        if control == target:
            raise ValidationError("control and target must differ")
        self._check_qubits(control, target)
        self._instructions.append(Instruction(name="crz", qubits=(control, target), params=(theta,)))
        return self

    def rxx(self, theta, q1, q2):
        self._check_qubits(q1, q2)
        self._instructions.append(Instruction(name="rxx", qubits=(q1, q2), params=(theta,)))
        return self

    def ryy(self, theta, q1, q2):
        self._check_qubits(q1, q2)
        self._instructions.append(Instruction(name="ryy", qubits=(q1, q2), params=(theta,)))
        return self

    def rzz(self, theta, q1, q2):
        self._check_qubits(q1, q2)
        self._instructions.append(Instruction(name="rzz", qubits=(q1, q2), params=(theta,)))
        return self

    def rzx(self, theta, q1, q2):
        self._check_qubits(q1, q2)
        self._instructions.append(Instruction(name="rzx", qubits=(q1, q2), params=(theta,)))
        return self

    def ccx(self, control1, control2, target):
        if len({control1, control2, target}) != 3:
            raise ValidationError("ccx qubits must be unique")
        self._check_qubits(control1, control2, target)
        self._instructions.append(Instruction(name="ccx", qubits=(control1, control2, target)))
        return self

    def cswap(self, control, q1, q2):
        if len({control, q1, q2}) != 3:
            raise ValidationError("cswap qubits must be unique")
        self._check_qubits(control, q1, q2)
        self._instructions.append(Instruction(name="cswap", qubits=(control, q1, q2)))
        return self

    def barrier(self, *qargs):
        if not qargs:
            qargs = tuple(range(self.n_qubits))
        self._check_qubits(*qargs)
        self._instructions.append(Instruction(name="barrier", qubits=qargs))
        return self

    def reset(self, q):
        self._check_qubits(q)
        self._instructions.append(Instruction(name="reset", qubits=(q,)))
        return self

    def initialize(self, state, qubits=None):
        if qubits is None:
            qubits = list(range(self.n_qubits))
        if isinstance(qubits, int):
            qubits = [qubits]
        for q in qubits:
            self._check_qubits(q)
        self._instructions.append(Instruction(name="initialize", qubits=tuple(qubits), params=(state,)))
        return self


class CircuitGate:
    """A Gate created from a QuantumCircuit via to_gate()."""

    def __init__(self, name, num_qubits, params=None, definition=None):
        self.name = name
        self.num_qubits = num_qubits
        self.params = params or []
        self.definition = definition

    def control(self, num_ctrl_qubits=1, label=None):
        new_name = label or ("c_" + self.name)
        return CircuitGate(name=new_name, num_qubits=self.num_qubits + num_ctrl_qubits, params=self.params, definition=self.definition)

    def __repr__(self):
        return f"CircuitGate({self.name}, {self.num_qubits}q)"

        return "Gate(name='" + self.name + "', num_qubits=" + str(self.num_qubits) + ")"
