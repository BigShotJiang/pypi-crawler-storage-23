"""
Stretch and Duration types for deferred timing resolution.

The OpenQASM 3 `stretch` type lets you specify relative timing of
operations instead of absolute timing. The concrete value of a stretch
is resolved at compile time, after the exact duration of calibrated
gates is known.

Key concepts:
  - A Stretch is a symbolic timing variable that the compiler resolves.
  - A Duration represents a concrete time value (in ``dt`` units).
  - Stretch expressions (X*stretch + Y) define how delays scale.

Reference:
  https://quantum.cloud.ibm.com/docs/en/guides/stretch

Example::

    s = circuit.add_stretch("s")
    circuit.delay(s, q1)                    # delay by s
    circuit.delay(expr.mul(s, 2), q1)       # delay by 2*s
    circuit.delay(expr.add(s, Duration.dt(3)), q1)  # delay by s + 3dt
"""
from __future__ import annotations
from typing import Union, Optional


class Duration:
    """Represents a concrete time duration in dt (device time) units.

    IBM Quantum backends define ``dt`` as the fundamental time unit
    (typically ~0.222 ns on IBM hardware). Duration objects are used
    as constants in stretch expressions.

    Args:
        value: The duration in dt units. Must be non-negative.
        unit: The time unit (default "dt").

    Example::

        d = Duration.dt(100)   # 100 dt
        d = Duration(50)       # 50 dt (shorthand)
    """

    def __init__(self, value: Union[int, float], unit: str = "dt"):
        if not isinstance(value, (int, float)):
            raise TypeError(f"Duration value must be numeric, got {type(value)}")
        self.value = value
        self.unit = unit

    @classmethod
    def dt(cls, value: Union[int, float]) -> "Duration":
        """Create a Duration in dt units.

        Args:
            value: Number of dt units.

        Returns:
            Duration object.

        Example::

            d = Duration.dt(100)
        """
        return cls(value, "dt")

    def __repr__(self):
        return f"Duration({self.value}{self.unit})"

    def __eq__(self, other):
        if isinstance(other, Duration):
            return self.value == other.value and self.unit == other.unit
        if isinstance(other, (int, float)):
            return self.value == other
        return NotImplemented

    def __hash__(self):
        return hash((self.value, self.unit))

    def __float__(self):
        return float(self.value)

    def __int__(self):
        return int(self.value)


class Stretch:
    """A symbolic stretch variable for deferred timing resolution.

    Stretch variables represent unknowns whose concrete value is resolved
    at compile time. The compiler minimizes the stretch duration subject
    to timing constraints on one or more qubits.

    Stretch is created via ``QuantumCircuit.add_stretch("name")``.

    Args:
        name: A unique name for this stretch variable.

    Example::

        s = circuit.add_stretch("s")
        circuit.delay(s, qubit)
    """

    def __init__(self, name: str):
        if not isinstance(name, str) or not name:
            raise ValueError("Stretch name must be a non-empty string")
        self.name = name

    def __repr__(self):
        return f"Stretch(\"{self.name}\")"

    def __eq__(self, other):
        if isinstance(other, Stretch):
            return self.name == other.name
        return NotImplemented

    def __hash__(self):
        return hash(("Stretch", self.name))


class StretchExpr:
    """Base class for stretch timing expressions.

    Stretch expressions are limited to the form ``X * stretch + Y``
    where X and Y are numeric constants. This matches the hardware
    constraints of IBM Quantum backends.
    """
    pass


class StretchMul(StretchExpr):
    """Multiplication of a stretch by a scalar.

    Represents: ``scalar * stretch``

    Args:
        stretch: The stretch variable or expression.
        scalar: The numeric multiplier.
    """

    def __init__(self, stretch, scalar: Union[int, float]):
        self.stretch = stretch
        self.scalar = scalar

    def __repr__(self):
        return f"({self.scalar} * {self.stretch!r})"


class StretchAdd(StretchExpr):
    """Addition of a stretch expression and a constant.

    Represents: ``stretch_expr + constant``

    Args:
        left: Left operand (stretch or expression).
        right: Right operand (stretch, Duration, or numeric).
    """

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def __repr__(self):
        return f"({self.left!r} + {self.right!r})"


class StretchDiv(StretchExpr):
    """Division of a stretch by a scalar.

    Represents: ``stretch / scalar``

    Args:
        stretch: The stretch variable or expression.
        scalar: The numeric divisor.
    """

    def __init__(self, stretch, scalar: Union[int, float]):
        if scalar == 0:
            raise ValueError("Cannot divide stretch by zero")
        self.stretch = stretch
        self.scalar = scalar

    def __repr__(self):
        return f"({self.stretch!r} / {self.scalar})"
