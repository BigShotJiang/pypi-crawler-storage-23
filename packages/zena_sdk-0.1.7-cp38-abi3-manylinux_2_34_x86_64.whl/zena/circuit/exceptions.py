"""Exceptions for quantum circuit operations.

Matches Qiskit's ``qiskit/circuit/exceptions.py`` structure.
"""


class CircuitError(Exception):
    """Base class for errors raised by circuit operations."""
    pass
