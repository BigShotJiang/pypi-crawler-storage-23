"""
Measurement instruction classes.

This module provides:
  - ``Measure`` -- Standard terminal measurement instruction.
  - ``MidCircuitMeasure`` -- Mid-circuit measurement optimized for IBM QPUs.
  - ``Reset`` -- A reset instruction to return a qubit to |0>.

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/measure-qubits

Example::

    from zena.circuit import QuantumCircuit
    from zena.circuit.measure import Measure, MidCircuitMeasure

    # Using Measure class
    qc = QuantumCircuit(3, 1)
    qc.x([0, 1])
    qc.append(Measure(), [0], [0])   # measure qubit 0 into clbit 0

    # Using MidCircuitMeasure
    qc = QuantumCircuit(2, 2)
    qc.x(0)
    qc.append(MidCircuitMeasure(), [0], [0])
    qc.h(0)  # continue computation after mid-circuit measurement
    qc.append(Measure(), [0], [0])   # terminal measurement
"""
from __future__ import annotations
from typing import Optional


class Measure:
    """Standard measurement instruction.

    Measures a qubit in the computational (Z) basis and stores the
    result in a classical bit. A measurement yields 0 or 1 depending
    on the overlap with the Pauli-Z eigenstates |0> and |1>.

    This class can be used with ``QuantumCircuit.append()`` as an
    alternative to calling ``QuantumCircuit.measure()`` directly.

    Args:
        label: Optional label for the measurement.

    Attributes:
        name: The instruction name ("measure").
        num_qubits: Number of qubits (always 1).
        num_clbits: Number of classical bits (always 1).

    Example::

        from zena.circuit.measure import Measure
        qc.append(Measure(), [0], [0])   # measure qubit 0 -> clbit 0
    """

    def __init__(self, label: Optional[str] = None):
        self.name = "measure"
        self.num_qubits = 1
        self.num_clbits = 1
        self.params = []
        self.label = label

    def __repr__(self):
        if self.label:
            return "Measure(label='{}')".format(self.label)
        return "Measure()"

    def __eq__(self, other):
        return isinstance(other, Measure)

    def __hash__(self):
        return hash("Measure")


class MidCircuitMeasure:
    """Mid-circuit measurement instruction optimized for IBM QPUs.

    Unlike terminal measurements, mid-circuit measurements must
    consider instruction duration and tuning. The ``MidCircuitMeasure``
    instruction maps to the ``measure_2`` instruction on backends
    that support it.

    Mid-circuit measurements are a key component of dynamic circuits.
    They enable classical feedforward, where the result of a measurement
    determines which operations to apply next.

    Args:
        label: Optional label for the measurement.

    Attributes:
        name: The instruction name ("mid_circuit_measure" / maps to "measure_2").
        num_qubits: Number of qubits (always 1).
        num_clbits: Number of classical bits (always 1).

    Note:
        - Not all backends support ``measure_2``. Use
          ``service.backends(filters=lambda b: "measure_2" in b.supported_instructions)``
          to find compatible backends.
        - ``MidCircuitMeasure`` adds less overhead than ``Measure``
          when used mid-circuit because it is specifically tuned for
          non-terminal measurement scenarios.
        - While ``QuantumCircuit.measure`` can also be used mid-circuit,
          ``MidCircuitMeasure`` is typically the better choice.

    Example::

        from zena.circuit.measure import MidCircuitMeasure

        circ = QuantumCircuit(2, 2)
        circ.x(0)
        circ.append(MidCircuitMeasure(), [0], [0])
        # Continue computation on qubit 0
        circ.h(0)
    """

    def __init__(self, label: Optional[str] = None):
        self.name = "mid_circuit_measure"
        self.num_qubits = 1
        self.num_clbits = 1
        self.params = []
        self.label = label
        # Backend instruction name
        self._backend_name = "measure_2"

    @property
    def backend_instruction(self):
        """Return the backend instruction name this maps to."""
        return self._backend_name

    def __repr__(self):
        if self.label:
            return "MidCircuitMeasure(label='{}')".format(self.label)
        return "MidCircuitMeasure()"

    def __eq__(self, other):
        return isinstance(other, MidCircuitMeasure)

    def __hash__(self):
        return hash("MidCircuitMeasure")


class Reset:
    """Reset instruction to return a qubit to |0>.

    A reset operation collapses the qubit state to |0>, regardless
    of its current state. This is commonly used after mid-circuit
    measurements to reuse qubits.

    Args:
        label: Optional label.

    Example::

        from zena.circuit.measure import Reset

        qc.measure(0, 0)
        qc.append(Reset(), [0])   # Reset qubit 0 to |0>
    """

    def __init__(self, label: Optional[str] = None):
        self.name = "reset"
        self.num_qubits = 1
        self.num_clbits = 0
        self.params = []
        self.label = label

    def __repr__(self):
        return "Reset()"

    def __eq__(self, other):
        return isinstance(other, Reset)

    def __hash__(self):
        return hash("Reset")
