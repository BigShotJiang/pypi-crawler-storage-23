"""
Classical expressions for dynamic circuits.

This module provides a representation of runtime operations on classical
values during circuit execution. These expressions are used as conditions
in if_test() statements for classical feedforward.

Mirrors Qiskit's qiskit.circuit.classical.expr module.

Example::

    from zena.circuit.classical import expr

    # Lift a clbit to a Value expression
    val = expr.lift(cr[0])

    # Build XOR parity expression
    parity = expr.bit_xor(cr[1], val)

    # Use in if_test
    with qc.if_test(parity):
        qc.x(0)
"""
from __future__ import annotations
from typing import Any, Optional, Union


class Expr:
    """Base class for all classical expressions.

    Expressions form a tree structure that represents classical
    computations to be performed at circuit runtime.
    """

    def __eq__(self, other):
        if type(self) != type(other):
            return False
        return self.__dict__ == other.__dict__

    def __hash__(self):
        return id(self)

    def __repr__(self):
        return f"{self.__class__.__name__}()"


class Value(Expr):
    """A lifted classical value (bit or register) as an expression node.

    This wraps a Clbit, ClassicalRegister, or integer value into
    an expression that can be used in boolean logic operations.

    Args:
        val: The classical value to wrap. Can be a Clbit,
             ClassicalRegister, (register, index) tuple, or int.

    Example::

        from zena.circuit.classical import expr
        val = expr.lift(cr[0])  # Returns Value(cr[0])
    """

    def __init__(self, val: Any):
        self.val = val

    def __repr__(self):
        return f"Value({self.val!r})"

    def __eq__(self, other):
        if not isinstance(other, Value):
            return False
        return self.val == other.val

    def __hash__(self):
        return hash(("Value", id(self.val)))


class Var(Expr):
    """A variable reference in a classical expression.

    References a classical register or bit by name.

    Args:
        register: The classical register.
        index: Optional bit index within the register.
    """

    def __init__(self, register, index: Optional[int] = None):
        self.register = register
        self.index = index

    def __repr__(self):
        if self.index is not None:
            return f"Var({self.register!r}[{self.index}])"
        return f"Var({self.register!r})"


class BitXor(Expr):
    """Bitwise XOR of two classical expressions.

    Args:
        left: Left operand expression.
        right: Right operand expression.
    """

    def __init__(self, left: Expr, right: Expr):
        self.left = left
        self.right = right

    def __repr__(self):
        return f"BitXor({self.left!r}, {self.right!r})"


class BitAnd(Expr):
    """Bitwise AND of two classical expressions.

    Args:
        left: Left operand expression.
        right: Right operand expression.
    """

    def __init__(self, left: Expr, right: Expr):
        self.left = left
        self.right = right

    def __repr__(self):
        return f"BitAnd({self.left!r}, {self.right!r})"


class BitOr(Expr):
    """Bitwise OR of two classical expressions.

    Args:
        left: Left operand expression.
        right: Right operand expression.
    """

    def __init__(self, left: Expr, right: Expr):
        self.left = left
        self.right = right

    def __repr__(self):
        return f"BitOr({self.left!r}, {self.right!r})"


class BitNot(Expr):
    """Bitwise NOT of a classical expression.

    Args:
        operand: The expression to negate.
    """

    def __init__(self, operand: Expr):
        self.operand = operand

    def __repr__(self):
        return f"BitNot({self.operand!r})"


class Equal(Expr):
    """Equality comparison between two classical values.

    Args:
        left: Left operand.
        right: Right operand.
    """

    def __init__(self, left: Expr, right: Expr):
        self.left = left
        self.right = right

    def __repr__(self):
        return f"Equal({self.left!r}, {self.right!r})"


# =========================================================================
# Function-style API (matching Qiskit's expr module)
# =========================================================================

def lift(val: Any) -> Value:
    """Lift a Python object into a classical expression Value node.

    This converts a Clbit, ClassicalRegister, (register, index) tuple,
    or raw integer into a Value expression that can be used in boolean
    logic operations.

    Args:
        val: The value to lift. Can be:
            - A Clbit or ClassicalRegister object
            - A (register, index) tuple (from register[i])
            - An integer value

    Returns:
        Value: An expression node wrapping the value.

    Example::

        from zena.circuit.classical import expr
        val = expr.lift(cr[0])   # Lift a register bit
        val = expr.lift(1)       # Lift an integer
    """
    if isinstance(val, Expr):
        return val  # Already an expression
    return Value(val)


def bit_xor(left: Any, right: Any) -> BitXor:
    """Compute the bitwise XOR of two classical expressions.

    Args:
        left: Left operand (auto-lifted if not an Expr).
        right: Right operand (auto-lifted if not an Expr).

    Returns:
        BitXor expression node.

    Example::

        parity = expr.bit_xor(cr[0], cr[1])
    """
    if not isinstance(left, Expr):
        left = lift(left)
    if not isinstance(right, Expr):
        right = lift(right)
    return BitXor(left, right)


def bit_and(left: Any, right: Any) -> BitAnd:
    """Compute the bitwise AND of two classical expressions.

    Args:
        left: Left operand (auto-lifted if not an Expr).
        right: Right operand (auto-lifted if not an Expr).

    Returns:
        BitAnd expression node.
    """
    if not isinstance(left, Expr):
        left = lift(left)
    if not isinstance(right, Expr):
        right = lift(right)
    return BitAnd(left, right)


def bit_or(left: Any, right: Any) -> BitOr:
    """Compute the bitwise OR of two classical expressions.

    Args:
        left: Left operand (auto-lifted if not an Expr).
        right: Right operand (auto-lifted if not an Expr).

    Returns:
        BitOr expression node.
    """
    if not isinstance(left, Expr):
        left = lift(left)
    if not isinstance(right, Expr):
        right = lift(right)
    return BitOr(left, right)


def bit_not(operand: Any) -> BitNot:
    """Compute the bitwise NOT of a classical expression.

    Args:
        operand: The expression to negate (auto-lifted if not an Expr).

    Returns:
        BitNot expression node.
    """
    if not isinstance(operand, Expr):
        operand = lift(operand)
    return BitNot(operand)


# =========================================================================
# Stretch arithmetic expressions (for deferred timing)
# =========================================================================

def mul(left, right):
    """Multiply a stretch variable by a scalar, or two values.

    Used to scale stretch durations in delay instructions.

    Args:
        left: A Stretch, StretchExpr, or numeric value.
        right: A Stretch, StretchExpr, or numeric value.

    Returns:
        A StretchMul expression.

    Example::

        s = circuit.add_stretch("s")
        circuit.delay(expr.mul(s, 2), qubit)  # delay by 2*s
    """
    from ..stretch import Stretch, StretchExpr, StretchMul

    # Determine which is the stretch and which is the scalar
    if isinstance(left, (Stretch, StretchExpr)):
        return StretchMul(left, right)
    elif isinstance(right, (Stretch, StretchExpr)):
        return StretchMul(right, left)
    else:
        # Both numeric: return product
        return float(left) * float(right)


def add(left, right):
    """Add a stretch expression and a constant or Duration.

    Used to offset stretch durations in delay instructions.

    Args:
        left: A Stretch, StretchExpr, Duration, or numeric.
        right: A Stretch, StretchExpr, Duration, or numeric.

    Returns:
        A StretchAdd expression.

    Example::

        from zena.circuit.stretch import Duration
        s = circuit.add_stretch("s")
        circuit.delay(expr.add(expr.mul(s, 2), Duration.dt(3)), qubit)
    """
    from ..stretch import Stretch, StretchExpr, StretchAdd

    if isinstance(left, (Stretch, StretchExpr)) or isinstance(right, (Stretch, StretchExpr)):
        return StretchAdd(left, right)
    else:
        # Both numeric/Duration - just add values
        lv = float(left) if not hasattr(left, 'value') else left.value
        rv = float(right) if not hasattr(right, 'value') else right.value
        return lv + rv


def div(left, right):
    """Divide a stretch variable by a scalar.

    Args:
        left: A Stretch or StretchExpr.
        right: A numeric divisor.

    Returns:
        A StretchDiv expression.

    Example::

        s = circuit.add_stretch("s")
        circuit.delay(expr.div(s, 2), qubit)  # delay by s/2
    """
    from ..stretch import Stretch, StretchExpr, StretchDiv

    if isinstance(left, (Stretch, StretchExpr)):
        return StretchDiv(left, right)
    else:
        return float(left) / float(right)

