"""
Control flow operations for dynamic circuits.

This module provides the IfElseOp and related classes for implementing
classical feedforward in quantum circuits. These match Qiskit's
dynamic circuit capabilities.

An IfElseOp represents a conditional block: if a classical condition
is met, one set of instructions (true_body) is executed; otherwise
an optional else_body is executed.

Reference: https://quantum.cloud.ibm.com/docs/en/guides/classical-feedforward-and-control-flow
"""
from __future__ import annotations
from typing import Any, Optional, Tuple, List, Union


class IfElseOp:
    """Operation representing a classical if/else conditional.

    Stores the condition and the true/false circuit bodies.

    Args:
        condition: A tuple (clbit_or_register, value) specifying the
                   classical condition, or an Expr object.
        true_body: QuantumCircuit to execute if condition is met.
        false_body: Optional QuantumCircuit to execute otherwise.
        label: Optional label.

    Example::

        op = IfElseOp(
            condition=(clbit, 1),
            true_body=true_circuit,
            false_body=false_circuit,
        )
    """

    def __init__(self, condition: Any, true_body=None, false_body=None, label=None):
        self.name = "if_else"
        self.condition = condition
        self.true_body = true_body
        self.false_body = false_body
        self.label = label

    @property
    def params(self):
        """Return the sub-circuits as params (for IR compatibility)."""
        result = []
        if self.true_body is not None:
            result.append(self.true_body)
        if self.false_body is not None:
            result.append(self.false_body)
        return result

    @property
    def num_qubits(self):
        if self.true_body is not None:
            return self.true_body.n_qubits
        return 0

    @property
    def num_clbits(self):
        if self.true_body is not None:
            return self.true_body.n_clbits
        return 0

    def __repr__(self):
        has_else = self.false_body is not None
        return f"IfElseOp(condition={self.condition!r}, has_else={has_else})"


class _IfContext:
    """Context manager for building the if-block of an if_test.

    Used internally by QuantumCircuit.if_test(). When entering the
    with block, the parent circuit's _instructions are redirected to
    a temporary sub-circuit. On exit, the IfElseOp is appended to the
    parent, or an _ElseContext is returned for chaining an else block.

    Usage::

        with qc.if_test((clbit, 1)) as else_:
            qc.x(0)
        with else_:
            qc.h(0)
    """

    def __init__(self, circuit, condition):
        self._parent = circuit
        self._condition = condition
        self._saved_instructions = None
        self._true_body = None
        self._false_body = None
        self._else_ctx = None

    def __enter__(self):
        # Save current instructions
        self._saved_instructions = list(self._parent._instructions)
        # Create the else context handle (returned to the user)
        self._else_ctx = _ElseContext(self)
        return self._else_ctx

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self._parent._instructions = self._saved_instructions
            return False

        # Capture instructions added during the if-block
        new_instructions = self._parent._instructions[len(self._saved_instructions):]

        # Restore parent to pre-if state
        self._parent._instructions = list(self._saved_instructions)

        # Build the true_body sub-circuit
        from ..quantum_circuit import QuantumCircuit
        true_body = QuantumCircuit(
            self._parent.n_qubits, self._parent.n_clbits,
            name="if_true"
        )
        true_body._instructions = list(new_instructions)
        self._true_body = true_body

        # Store so the else context can access it
        self._else_ctx._if_ctx = self

        # Add the if-only IfElseOp immediately.
        # If an else block follows, it will replace this.
        self._append_op(false_body=None)
        return False

    def _append_op(self, false_body=None):
        """Append the IfElseOp to the parent circuit."""
        from ...ir.types import Instruction

        op = IfElseOp(
            condition=self._condition,
            true_body=self._true_body,
            false_body=false_body,
        )
        self._parent._instructions.append(
            Instruction(
                name="if_else",
                qubits=tuple(range(self._parent.n_qubits)),
                clbits=tuple(range(self._parent.n_clbits)),
                params=(op,),
            )
        )


class _ElseContext:
    """Context manager for the else-block of an if_test.

    Returned by the if_test context. When used as a context manager,
    it captures the else-block instructions and updates the IfElseOp.

    Usage::

        with qc.if_test((clbit, 1)) as else_:
            qc.x(0)
        with else_:
            qc.h(0)
    """

    def __init__(self, if_ctx):
        self._if_ctx = if_ctx

    def __enter__(self):
        # Remove the if-only IfElseOp that was appended
        parent = self._if_ctx._parent
        if parent._instructions and parent._instructions[-1].name == "if_else":
            parent._instructions.pop()

        # Save current state for capturing else instructions
        self._saved_instructions = list(parent._instructions)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        parent = self._if_ctx._parent

        if exc_type is not None:
            parent._instructions = self._saved_instructions
            return False

        # Capture else body
        new_instructions = parent._instructions[len(self._saved_instructions):]
        parent._instructions = list(self._saved_instructions)

        from ..quantum_circuit import QuantumCircuit
        false_body = QuantumCircuit(
            parent.n_qubits, parent.n_clbits,
            name="if_false"
        )
        false_body._instructions = list(new_instructions)

        # Append final IfElseOp with both bodies
        self._if_ctx._append_op(false_body=false_body)
        return False
