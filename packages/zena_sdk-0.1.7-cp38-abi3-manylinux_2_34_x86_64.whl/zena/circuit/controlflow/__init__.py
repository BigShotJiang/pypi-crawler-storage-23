"""Control flow operations for quantum circuits.

Qiskit-compatible structure:
    qiskit/circuit/controlflow/
        __init__.py
        if_else.py
        for_loop.py
        while_loop.py
        switch_case.py

Note:
    IBM Quantum Runtime currently only supports ``if_test`` (IfElseOp).
    The other control flow operations are provided for SDK completeness.

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/classical-feedforward-and-control-flow
"""
from .if_else import IfElseOp, _IfContext, _ElseContext
from .for_loop import ForLoopOp, _ForLoopContext
from .while_loop import WhileLoopOp, _WhileLoopContext
from .switch_case import SwitchCaseOp, CASE_DEFAULT, _SwitchContext, _CaseContext

# Names of all known control-flow operations (mirrors Qiskit)
CONTROL_FLOW_OP_NAMES = frozenset(("for_loop", "while_loop", "if_else", "switch_case"))

__all__ = [
    "IfElseOp", "_IfContext", "_ElseContext",
    "ForLoopOp", "_ForLoopContext",
    "WhileLoopOp", "_WhileLoopContext",
    "SwitchCaseOp", "CASE_DEFAULT", "_SwitchContext", "_CaseContext",
    "CONTROL_FLOW_OP_NAMES",
]
