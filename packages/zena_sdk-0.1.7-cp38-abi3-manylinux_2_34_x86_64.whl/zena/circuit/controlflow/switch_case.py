"""
SwitchCaseOp control flow operation.

Represents a switch/case statement that executes one of several
branch circuits depending on the value of a classical condition.

Mirrors Qiskit's ``qiskit.circuit.controlflow.switch_case.SwitchCaseOp``.

Note:
    This is not yet supported by IBM Quantum Runtime. It is provided
    for API completeness with Qiskit SDK.

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/classical-feedforward-and-control-flow
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple


# Sentinel for the default case
CASE_DEFAULT = object()


class SwitchCaseOp:
    """Operation representing a switch/case within a circuit.

    Args:
        target: Classical bit, register, or Expr to switch on.
        cases: List of (value, QuantumCircuit) pairs.
        label: Optional label.

    Example::

        from zena.circuit import QuantumCircuit
        from zena.circuit.controlflow import CASE_DEFAULT

        qc = QuantumCircuit(2, 2)
        qc.measure(0, 0)
        with qc.switch(qc.clbits[0]) as case:
            with case(0):
                qc.x(1)
            with case(1):
                qc.h(1)
            with case(case.DEFAULT):
                pass
    """

    def __init__(self, target=None, cases=None, label=None):
        self.name = "switch_case"
        self.target = target
        self.cases = cases or []
        self.label = label

    @property
    def params(self):
        result = []
        for _val, body in self.cases:
            if body is not None:
                result.append(body)
        return result

    @property
    def num_qubits(self):
        if self.cases:
            return self.cases[0][1].n_qubits
        return 0

    @property
    def num_clbits(self):
        if self.cases:
            return self.cases[0][1].n_clbits
        return 0

    def __repr__(self):
        return f"SwitchCaseOp(target={self.target!r}, num_cases={len(self.cases)})"


class _SwitchContext:
    """Context manager for building a switch/case block.

    Usage::

        with qc.switch(clbit) as case:
            with case(0):
                qc.x(0)
            with case(1):
                qc.h(0)
    """

    DEFAULT = CASE_DEFAULT

    def __init__(self, circuit, target):
        self._parent = circuit
        self._target = target
        self._cases = []
        self._saved_instructions = None

    def __enter__(self):
        self._saved_instructions = list(self._parent._instructions)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self._parent._instructions = self._saved_instructions
            return False

        # Restore parent to pre-switch state
        self._parent._instructions = list(self._saved_instructions)

        from ...ir.types import Instruction
        op = SwitchCaseOp(
            target=self._target,
            cases=list(self._cases),
        )
        self._parent._instructions.append(
            Instruction(
                name="switch_case",
                qubits=tuple(range(self._parent.n_qubits)),
                clbits=tuple(range(self._parent.n_clbits)),
                params=(op,),
            )
        )
        return False

    def __call__(self, value):
        """Return a context manager for a specific case value."""
        return _CaseContext(self, value)


class _CaseContext:
    """Context manager for a single case within a switch block."""

    def __init__(self, switch_ctx, value):
        self._switch = switch_ctx
        self._value = value
        self._saved_instructions = None

    def __enter__(self):
        self._saved_instructions = list(self._switch._parent._instructions)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        parent = self._switch._parent

        if exc_type is not None:
            parent._instructions = self._saved_instructions
            return False

        new_instructions = parent._instructions[len(self._saved_instructions):]
        parent._instructions = list(self._saved_instructions)

        from ..quantum_circuit import QuantumCircuit
        body = QuantumCircuit(
            parent.n_qubits, parent.n_clbits,
            name=f"case_{self._value}"
        )
        body._instructions = list(new_instructions)

        self._switch._cases.append((self._value, body))
        return False
