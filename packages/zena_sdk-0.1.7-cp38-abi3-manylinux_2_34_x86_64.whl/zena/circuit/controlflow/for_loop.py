"""
ForLoopOp control flow operation.

Represents a for-loop that iterates the ``body`` circuit over a sequence
of integer values, parameterized by a ``loop_parameter``.

Mirrors Qiskit's ``qiskit.circuit.controlflow.for_loop.ForLoopOp``.

Note:
    This is not yet supported by IBM Quantum Runtime. It is provided
    for API completeness with Qiskit SDK.

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/classical-feedforward-and-control-flow
"""
from __future__ import annotations
from typing import Any, Optional, Tuple, Sequence


class ForLoopOp:
    """Operation representing a classical for-loop within a circuit.

    Args:
        indexset: Sequence of integer values to iterate over.
        loop_parameter: Parameter used inside the body for the current iteration.
        body: QuantumCircuit to execute each iteration.
        label: Optional label.

    Example::

        from zena.circuit import QuantumCircuit

        qc = QuantumCircuit(2, 2)
        with qc.for_loop(range(5)) as i:
            qc.rx(i * 0.1, 0)
    """

    def __init__(self, indexset, loop_parameter=None, body=None, label=None):
        self.name = "for_loop"
        self.indexset = indexset
        self.loop_parameter = loop_parameter
        self.body = body
        self.label = label

    @property
    def params(self):
        result = []
        if self.body is not None:
            result.append(self.body)
        return result

    @property
    def num_qubits(self):
        if self.body is not None:
            return self.body.n_qubits
        return 0

    @property
    def num_clbits(self):
        if self.body is not None:
            return self.body.n_clbits
        return 0

    def __repr__(self):
        return f"ForLoopOp(indexset={self.indexset!r})"


class _ForLoopContext:
    """Context manager for building the body of a for_loop.

    Usage::

        with qc.for_loop(range(5)) as i:
            qc.rx(i * 0.1, 0)
    """

    def __init__(self, circuit, indexset, loop_parameter=None):
        self._parent = circuit
        self._indexset = indexset
        self._loop_parameter = loop_parameter
        self._saved_instructions = None

    def __enter__(self):
        self._saved_instructions = list(self._parent._instructions)
        # Return the loop parameter (for use as iteration variable)
        return self._loop_parameter

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self._parent._instructions = self._saved_instructions
            return False

        new_instructions = self._parent._instructions[len(self._saved_instructions):]
        self._parent._instructions = list(self._saved_instructions)

        from ..quantum_circuit import QuantumCircuit
        body = QuantumCircuit(
            self._parent.n_qubits, self._parent.n_clbits,
            name="for_body"
        )
        body._instructions = list(new_instructions)

        from ...ir.types import Instruction
        op = ForLoopOp(
            indexset=self._indexset,
            loop_parameter=self._loop_parameter,
            body=body,
        )
        self._parent._instructions.append(
            Instruction(
                name="for_loop",
                qubits=tuple(range(self._parent.n_qubits)),
                clbits=tuple(range(self._parent.n_clbits)),
                params=(op,),
            )
        )
        return False
