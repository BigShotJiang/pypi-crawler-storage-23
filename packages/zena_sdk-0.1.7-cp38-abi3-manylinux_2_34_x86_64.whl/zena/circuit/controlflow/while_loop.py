"""
WhileLoopOp control flow operation.

Represents a while-loop that repeats ``body`` until ``condition``
evaluates to False.

Mirrors Qiskit's ``qiskit.circuit.controlflow.while_loop.WhileLoopOp``.

Note:
    This is not yet supported by IBM Quantum Runtime. It is provided
    for API completeness with Qiskit SDK.

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/classical-feedforward-and-control-flow
"""
from __future__ import annotations
from typing import Any, Optional


class WhileLoopOp:
    """Operation representing a classical while-loop within a circuit.

    Args:
        condition: Tuple ``(clbit_or_register, value)`` or Expr object.
        body: QuantumCircuit to execute while condition is true.
        label: Optional label.

    Example::

        from zena.circuit import QuantumCircuit

        qc = QuantumCircuit(1, 1)
        with qc.while_loop((qc.clbits[0], 0)):
            qc.h(0)
            qc.measure(0, 0)
    """

    def __init__(self, condition, body=None, label=None):
        self.name = "while_loop"
        self.condition = condition
        self.body = body
        self.label = label

    @property
    def params(self):
        result = []
        if self.body is not None:
            result.append(self.body)
        return result

    @property
    def num_qubits(self):
        if self.body is not None:
            return self.body.n_qubits
        return 0

    @property
    def num_clbits(self):
        if self.body is not None:
            return self.body.n_clbits
        return 0

    def __repr__(self):
        return f"WhileLoopOp(condition={self.condition!r})"


class _WhileLoopContext:
    """Context manager for building the body of a while_loop.

    Usage::

        with qc.while_loop((clbit, 0)):
            qc.h(0)
            qc.measure(0, 0)
    """

    def __init__(self, circuit, condition):
        self._parent = circuit
        self._condition = condition
        self._saved_instructions = None

    def __enter__(self):
        self._saved_instructions = list(self._parent._instructions)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self._parent._instructions = self._saved_instructions
            return False

        new_instructions = self._parent._instructions[len(self._saved_instructions):]
        self._parent._instructions = list(self._saved_instructions)

        from ..quantum_circuit import QuantumCircuit
        body = QuantumCircuit(
            self._parent.n_qubits, self._parent.n_clbits,
            name="while_body"
        )
        body._instructions = list(new_instructions)

        from ...ir.types import Instruction
        op = WhileLoopOp(
            condition=self._condition,
            body=body,
        )
        self._parent._instructions.append(
            Instruction(
                name="while_loop",
                qubits=tuple(range(self._parent.n_qubits)),
                clbits=tuple(range(self._parent.n_clbits)),
                params=(op,),
            )
        )
        return False
