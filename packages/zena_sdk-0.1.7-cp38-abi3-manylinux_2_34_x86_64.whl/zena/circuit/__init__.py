# circuit package
# zena/circuit/__init__.py
"""zena.circuit package exports."""

from .quantum_circuit import QuantumCircuit, CircuitGate
from .register import Register, QuantumRegister, ClassicalRegister
from .primitives import Qubit, Clbit, CircuitInstruction, BitData
from .parameter import Parameter, ParameterVector, ParameterExpression, ParameterView
from . import library

__all__ = [
    "QuantumCircuit", "CircuitGate",
    "QuantumRegister", "ClassicalRegister", "Register",
    "Qubit", "Clbit", "CircuitInstruction", "BitData",
    "Parameter", "ParameterVector", "ParameterExpression", "ParameterView",
    "library",
]

# Control flow (dynamic circuits)
from .controlflow import IfElseOp

# Classical expressions
from .classical import expr

# Stretch / deferred timing
from .stretch import Stretch, Duration

# Measurement instructions
from .measure import Measure, MidCircuitMeasure, Reset

# Unitary synthesis
from .synthesis import UnitaryGate, decompose_single_qubit, synthesize_unitary

# Qiskit-compatible separate file imports
from .delay import Delay
from .gate import Gate
from .instruction import Instruction as InstructionBase
from .exceptions import CircuitError
from .controlflow import IfElseOp
from .duration import Duration
