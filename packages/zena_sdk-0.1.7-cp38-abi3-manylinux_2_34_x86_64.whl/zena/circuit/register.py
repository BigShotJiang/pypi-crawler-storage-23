"""
Quantum and Classical Register classes.

This module provides the base Register class and specialized
QuantumRegister and ClassicalRegister classes for managing
qubits and classical bits in quantum circuits.
"""
from __future__ import annotations
from typing import Optional


class Register:
    """
    Base class for quantum and classical registers.
    
    A register is a collection of bits (quantum or classical) that can be
    referenced as a unit in quantum circuits.
    """
    
    def __init__(self, size: int, name: Optional[str] = None):
        """
        Initialize a register.
        
        Args:
            size: Number of bits in the register (must be positive)
            name: Optional name for the register
            
        Raises:
            ValueError: If size is not positive
        """
        if not isinstance(size, int) or size <= 0:
            raise ValueError("Register size must be a positive integer")
        self.size = size
        self.name = name
        
    def __len__(self) -> int:
        """Return the size of the register."""
        return self.size
        
    def __repr__(self) -> str:
        """Return string representation of the register."""
        return f"{self.__class__.__name__}({self.size}, '{self.name}')"
    
    def __getitem__(self, key: int):
        """
        Get a bit from the register by index.
        
        Args:
            key: Index of the bit (0-indexed)
            
        Returns:
            Tuple of (register, index) for use in circuit operations
        """
        if not isinstance(key, int):
            raise TypeError("Register index must be an integer")
        if key < 0 or key >= self.size:
            raise IndexError(f"Index {key} out of range for register of size {self.size}")
        return (self, key)


class QuantumRegister(Register):
    """
    Quantum register - a collection of qubits.
    
    Example:
        >>> qr = QuantumRegister(5, 'q')
        >>> print(qr)
        QuantumRegister(5, 'q')
        >>> print(len(qr))
        5
    """
    
    def __init__(self, size: int, name: Optional[str] = "q"):
        """
        Initialize a quantum register.
        
        Args:
            size: Number of qubits in the register
            name: Name for the register (default: 'q')
        """
        super().__init__(size, name)


class ClassicalRegister(Register):
    """
    Classical register - a collection of classical bits.
    
    Example:
        >>> cr = ClassicalRegister(5, 'c')
        >>> print(cr)
        ClassicalRegister(5, 'c')
        >>> print(len(cr))
        5
    """
    
    def __init__(self, size: int, name: Optional[str] = "c"):
        """
        Initialize a classical register.
        
        Args:
            size: Number of classical bits in the register
            name: Name for the register (default: 'c')
        """
        super().__init__(size, name)
