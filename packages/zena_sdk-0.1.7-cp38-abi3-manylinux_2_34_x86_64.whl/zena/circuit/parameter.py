from __future__ import annotations
from typing import Optional, Dict, Union, List, Set
import uuid


class Parameter:
    def __init__(self, name, uuid_val=None):
        self._name = name
        self._uuid = uuid_val or str(uuid.uuid4())

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, new_name):
        self._name = new_name

    @property
    def uuid(self):
        return self._uuid

    def __repr__(self):
        return "Parameter(" + self._name + ")"

    def __str__(self):
        return self._name

    def __hash__(self):
        return hash(self._uuid)

    def __eq__(self, other):
        if isinstance(other, Parameter):
            return self._uuid == other._uuid
        return NotImplemented

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    def __add__(self, other):
        extra = {other: 1.0} if isinstance(other, Parameter) else {}
        const = other if not isinstance(other, Parameter) else 0.0
        return ParameterExpression({self: 1.0}, const, _extra_params=extra)

    def __radd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):
        extra = {other: -1.0} if isinstance(other, Parameter) else {}
        const = -other if not isinstance(other, Parameter) else 0.0
        return ParameterExpression({self: 1.0}, const, _extra_params=extra)

    def __rsub__(self, other):
        extra = {other: 1.0} if isinstance(other, Parameter) else {}
        const = other if not isinstance(other, Parameter) else 0.0
        return ParameterExpression({self: -1.0}, const, _extra_params=extra)

    def __mul__(self, other):
        if isinstance(other, (int, float)):
            return ParameterExpression({self: float(other)}, 0.0)
        return NotImplemented

    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):
        if isinstance(other, (int, float)):
            return ParameterExpression({self: 1.0 / float(other)}, 0.0)
        return NotImplemented

    def __neg__(self):
        return ParameterExpression({self: -1.0}, 0.0)

    def is_parameter(self):
        return True


class ParameterExpression:
    def __init__(self, coefficients, constant=0.0, _extra_params=None):
        self._coefficients = dict(coefficients)
        if _extra_params:
            for p, c in _extra_params.items():
                self._coefficients[p] = self._coefficients.get(p, 0.0) + c
        self._constant = constant

    @property
    def parameters(self):
        return set(self._coefficients.keys())

    def bind(self, parameter_values):
        result = self._constant
        remaining = {}
        for param, coeff in self._coefficients.items():
            if param in parameter_values:
                result += coeff * parameter_values[param]
            else:
                remaining[param] = coeff
        if remaining:
            return ParameterExpression(remaining, result)
        return result

    def __repr__(self):
        parts = []
        for param, coeff in self._coefficients.items():
            if coeff == 1.0:
                parts.append(str(param))
            elif coeff == -1.0:
                parts.append("-" + str(param))
            else:
                parts.append(str(coeff) + "*" + str(param))
        if self._constant != 0.0:
            parts.append(str(self._constant))
        return " + ".join(parts) if parts else "0"

    def is_parameter(self):
        return True


class ParameterVector:
    def __init__(self, name, length):
        self._name = name
        self._length = length
        self._params = []
        for i in range(length):
            self._params.append(Parameter(name + "[" + str(i) + "]"))

    @property
    def name(self):
        return self._name

    def __len__(self):
        return self._length

    def __getitem__(self, key):
        if isinstance(key, slice):
            return self._params[key]
        if key < 0 or key >= self._length:
            raise IndexError("Index out of range")
        return self._params[key]

    def __iter__(self):
        return iter(self._params)

    def __repr__(self):
        return "ParameterVector(name=" + self._name + ", length=" + str(self._length) + ")"

    @property
    def params(self):
        return list(self._params)


class ParameterView:
    def __init__(self, parameters):
        self._parameters = list(parameters)

    def __len__(self):
        return len(self._parameters)

    def __iter__(self):
        return iter(self._parameters)

    def __getitem__(self, key):
        return self._parameters[key]

    def __contains__(self, item):
        return item in self._parameters

    def __repr__(self):
        params_str = ", ".join(repr(p) for p in self._parameters)
        return "ParameterView([" + params_str + "])"

    def __bool__(self):
        return len(self._parameters) > 0
