from __future__ import annotations

from .circuit.quantum_circuit import QuantumCircuit
from .circuit.register import QuantumRegister, ClassicalRegister
from .circuit.parameter import Parameter, ParameterVector, ParameterExpression
from .circuit.primitives import Qubit, Clbit
from .errors import ValidationError
from .execute import execute

from .io import export_text, import_text, export_json, import_json
from .ir.from_payload import circuit_from_payload
from .target import Target
from .targets import BUILTIN_TARGETS
from .providers import BasicProvider, Aer

from . import qpy
from . import qasm2
from . import qasm3

__version__ = "0.1.7"

__all__ = [
    "QuantumCircuit", "QuantumRegister", "ClassicalRegister",
    "Parameter", "ParameterVector", "ParameterExpression",
    "Qubit", "Clbit", "ValidationError", "execute",
    "export_text", "import_text", "export_json", "import_json",
    "circuit_from_payload", "Target", "BUILTIN_TARGETS", "BasicProvider", "Aer",
    "qpy", "qasm2", "qasm3",
]

def engine_version():
    return "0.3.0"
from .circuit.controlflow import IfElseOp
from .circuit.stretch import Stretch, Duration
from .circuit.measure import Measure, MidCircuitMeasure, Reset
from .quantum_info import Operator
from .circuit.synthesis import UnitaryGate

