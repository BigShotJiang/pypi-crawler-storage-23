"""
Histogram plotting utilities for quantum measurement results.

This module provides functions for visualizing measurement counts
from quantum circuit simulations.
"""
from typing import Dict, Optional


def plot_histogram(data: Dict[str, int], title: Optional[str] = None) -> None:
    """
    Plot a histogram of measurement counts to the console.
    
    Displays measurement results as a text-based bar chart showing
    the count and percentage for each measured state.
    
    Args:
        data: Dictionary mapping bitstrings to counts
              (e.g., {'00': 500, '01': 250, '10': 150, '11': 100})
        title: Optional title for the histogram
        
    Example:
        >>> counts = {'00': 512, '11': 512}
        >>> plot_histogram(counts, "Bell State Measurement")
        
        --- Bell State Measurement ---
        00    | ████████████████████ |  512 ( 50.0%)
        11    | ████████████████████ |  512 ( 50.0%)
        ---------------------------------------------
    """
    if title:
        print(f"\n--- {title} ---")
    else:
        print("\n--- Histogram ---")
        
    if not data:
        print("Empty data.")
        return

    max_val = max(data.values())
    total = sum(data.values())
    
    # Sort keys for consistent display (binary order)
    for key in sorted(data.keys()):
        val = data[key]
        percentage = (val / total) * 100
        bar_length = int((val / max_val) * 20)
        bar = "█" * bar_length
        print(f"{key:5s} | {bar:<20} | {val:4d} ({percentage:>5.1f}%)")
    print("-" * 45)


def plot_histogram_mpl(data: Dict[str, int], title: Optional[str] = None,
                       figsize: tuple = (10, 6)):
    """
    Plot a histogram using matplotlib (if available).
    
    Args:
        data: Dictionary mapping bitstrings to counts
        title: Optional title for the plot
        figsize: Figure size as (width, height) in inches
        
    Raises:
        ImportError: If matplotlib is not installed
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError(
            "matplotlib is required for graphical plotting. "
            "Install it with: pip install matplotlib"
        )
    
    states = sorted(data.keys())
    counts = [data[k] for k in states]
    
    plt.figure(figsize=figsize)
    plt.bar(states, counts, color='#0f62fe', edgecolor='#001d6c')
    plt.xlabel('State', fontsize=12)
    plt.ylabel('Counts', fontsize=12)
    plt.title(title or 'Measurement Results', fontsize=14, fontweight='bold')
    plt.xticks(rotation=45 if len(states) > 8 else 0)
    plt.grid(axis='y', alpha=0.3)
    plt.tight_layout()
    plt.show()
