from __future__ import annotations
from typing import List, Dict, Set
from ..ir.types import Instruction

def draw_ascii(n_qubits: int, instructions: List[Instruction]) -> str:
    """Render circuit matching Qiskit's text drawer exactly with gate scheduling."""
    if not instructions:
        return "Empty Circuit"

    # Find number of classical bits
    max_c = -1
    for inst in instructions:
        if inst.clbits:
            max_c = max(max_c, max(inst.clbits))
    n_clbits = max_c + 1 if max_c >= 0 else 0
    
    # STEP 1: Schedule gates into time moments
    # Each moment contains gates that can execute in parallel
    # NOTE: Measurements are NOT grouped - each gets its own column
    moments = []  # List of lists of instructions
    qubit_time = [0] * n_qubits  # Next available time for each qubit
    global_time = 0  # Track global time for sequential measurements
    
    for inst in instructions:
        name = inst.name.lower()
        qubits = inst.qubits if inst.qubits else list(range(n_qubits))
        
        # Measurements get their own column (not grouped with other measurements)
        if name == 'measure':
            # Use max of qubit time and global time (ensures sequential measurements)
            earliest = max(max(qubit_time[q] for q in qubits) if qubits else 0, global_time)
            while len(moments) <= earliest:
                moments.append([])
            moments[earliest].append(inst)
            for q in qubits:
                qubit_time[q] = earliest + 1
            global_time = earliest + 1  # Advance global time
        else:
            # Find earliest time this instruction can execute
            earliest = max(qubit_time[q] for q in qubits) if qubits else len(moments)
            
            # Extend moments if needed
            while len(moments) <= earliest:
                moments.append([])
            
            moments[earliest].append(inst)
            
            # Update qubit availability
            for q in qubits:
                qubit_time[q] = earliest + 1
    
    # STEP 2: Build columns for each moment
    cols = []
    for moment in moments:
        # Determine column width based on gates in this moment
        w = 5  # Default width
        has_barrier = False
        has_measure = False
        
        for inst in moment:
            name = inst.name.lower()
            lbl = name.upper()
            if name in ['rx', 'ry', 'rz', 'u', 'p']:
                lbl = f"{name.upper()}({inst.params[0]:.2g})" if inst.params else name.upper()
            
            if name == 'barrier':
                has_barrier = True
            elif name == 'measure':
                has_measure = True
            elif len(lbl) > 3:
                w = max(w, len(lbl) + 2)
        
        if has_barrier:
            w = 1
        elif has_measure:
            w = 3
            
        col = {'w': w, 'q': {}, 'has_barrier': has_barrier, 'has_measure': has_measure, 'clbits': []}
        
        # Build qubit data for each instruction in this moment
        for inst in moment:
            name = inst.name.lower()
            qubits = inst.qubits
            params = inst.params or []
            clbits = getattr(inst, "clbits", [])
            
            if clbits:
                col['clbits'].extend(clbits)
            
            lbl = name.upper()
            if name in ['rx', 'ry', 'rz', 'u', 'p']:
                lbl = f"{name.upper()}({params[0]:.2g})" if params else name.upper()
            
            if name == 'barrier':
                for q in (qubits if qubits else range(n_qubits)):
                    col['q'][q] = ("░", "░", "░")
                    
            elif name == 'measure':
                for q in qubits:
                    col['q'][q] = ("┌─┐", "┤M├", "└╥┘")
                    
            elif len(qubits) == 1:
                q = qubits[0]
                fill = "─" * (w - 2)
                inner = lbl.center(w - 2)
                col['q'][q] = (f"┌{fill}┐", f"┤{inner}├", f"└{fill}┘")
                
            elif name in ['cx', 'cnot', 'ccx', 'mcx', 'mct']:
                ctrls = qubits[:-1]
                tgt = qubits[-1]
                minq, maxq = min(qubits), max(qubits)
                
                for c in ctrls:
                    t = " " * w if c == minq else "│".center(w)
                    m = "─■─".center(w, "─")
                    b = " " * w if c == maxq else "│".center(w)
                    col['q'][c] = (t, m, b)
                
                fill = "─" * (w - 2)
                has_above = any(c < tgt for c in ctrls)
                cen = (w - 2) // 2
                tfill = "─" * cen + "┴" + "─" * (w - 3 - cen) if has_above else fill
                col['q'][tgt] = (f"┌{tfill}┐", f"┤ X ├", f"└{fill}┘")
                
                for q in range(minq, maxq + 1):
                    if q not in col['q']:
                        col['q'][q] = ("│".center(w), "─┼─".center(w, "─"), "│".center(w))
                        
            elif name == 'cz':
                minq, maxq = min(qubits), max(qubits)
                for q in qubits:
                    t = " " * w if q == minq else "│".center(w)
                    m = "─■─".center(w, "─")
                    b = " " * w if q == maxq else "│".center(w)
                    col['q'][q] = (t, m, b)
                for q in range(minq + 1, maxq):
                    if q not in col['q']:
                        col['q'][q] = ("│".center(w), "─┼─".center(w, "─"), "│".center(w))
                        
            elif name == 'swap':
                minq, maxq = min(qubits), max(qubits)
                for q in qubits:
                    t = " " * w if q == minq else "│".center(w)
                    m = "─x─".center(w, "─")
                    b = " " * w if q == maxq else "│".center(w)
                    col['q'][q] = (t, m, b)
                for q in range(minq + 1, maxq):
                    if q not in col['q']:
                        col['q'][q] = ("│".center(w), "─┼─".center(w, "─"), "│".center(w))
            else:
                for q in qubits:
                    fill = "─" * (w - 2)
                    inner = lbl[:w-2].center(w - 2)
                    col['q'][q] = (f"┌{fill}┐", f"┤{inner}├", f"└{fill}┘")
                    
        cols.append(col)
    
    # STEP 3: Build output with Qiskit-style shared borders
    lw = len(f"q_{n_qubits-1}: ")
    result = []
    
    for q in range(n_qubits):
        # Border line - merge prev bottom with current top
        bline = ""
        for col in cols:
            w = col['w']
            prev = col['q'].get(q-1) if q > 0 else None
            curr = col['q'].get(q)
            
            if q == 0:
                bline += curr[0] if curr else " " * w
            else:
                if prev and curr:
                    # Both have gates - merge
                    pbot = prev[2]
                    ctop = curr[0]
                    merged = ""
                    for i in range(min(w, len(pbot), len(ctop))):
                        p, c = pbot[i], ctop[i]
                        if p == "└" and c == "┌":
                            merged += "├"
                        elif p == "┘" and c == "┐":
                            merged += "┤"
                        elif p == "─" and c == "─":
                            merged += "─"
                        elif p == "╥" or c == "╥":
                            merged += "╥"
                        elif p == "┴" or c == "┴":
                            merged += "┴"
                        elif p == "│" or c == "│":
                            merged += "│"
                        elif p == "░" or c == "░":
                            merged += "░"
                        elif p == "║" or c == "║":
                            merged += "║"
                        elif p == " " and c == " ":
                            merged += " "
                        else:
                            merged += c if c != " " else p
                    bline += merged.ljust(w)[:w]
                elif prev:
                    bline += prev[2][:w].ljust(w)
                elif curr:
                    bline += curr[0][:w].ljust(w)
                else:
                    bline += " " * w
        result.append(" " * lw + bline)
        
        # Content line
        cline = ""
        for col in cols:
            w = col['w']
            if q in col['q']:
                cline += col['q'][q][1]
            else:
                cline += "─" * w
        result.append(f"q_{q}: ".ljust(lw) + cline)
    
    # Last qubit bottom border
    bline = ""
    for col in cols:
        w = col['w']
        lastq = n_qubits - 1
        if lastq in col['q']:
            bline += col['q'][lastq][2]
        else:
            bline += " " * w
    result.append(" " * lw + bline)
    
    # Classical line
    cline = ""
    iline = ""
    for col in cols:
        w = col['w']
        if col['has_measure'] and col['clbits']:
            cline += "═╩═"[:w]
            for cb in col['clbits']:
                iline += str(cb).center(w)
                break  # Only first clbit for this column
        else:
            cline += "═" * w
            iline += " " * w
            
    # Format: "c: N/═══..." like Qiskit
    prefix = f"c: {n_clbits}/"  
    cline = prefix + cline
    result.append(cline)
    result.append(" " * len(prefix) + iline)
    
    return "\n".join(line.rstrip() for line in result)
