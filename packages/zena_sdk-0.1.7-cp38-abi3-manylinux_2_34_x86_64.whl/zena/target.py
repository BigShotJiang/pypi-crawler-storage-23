# zena/target.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional
import json
from pathlib import Path


@dataclass(frozen=True)
class Target:
    """Represents a quantum hardware target with its capabilities.

    Attributes:
        n_qubits: Number of qubits on the target.
        basis_gates: List of supported gate names.
        coupling_map: Directed edges (control, target) for two-qubit gates.
        name: Target name (e.g., 'ibm_torino').
        durations: Optional gate durations in nanoseconds.
        error_rates: Optional gate error rates.
        use_fractional_gates: Whether fractional gate support is enabled.
            When True, the target supports direct RX(theta) and RZZ(theta)
            execution on Heron QPUs.
    """
    n_qubits: int
    basis_gates: List[str]
    coupling_map: List[Tuple[int, int]]
    name: str = ""
    durations: Optional[Dict[str, float]] = None
    error_rates: Optional[Dict[str, float]] = None
    use_fractional_gates: bool = False

    @property
    def fractional_basis_gates(self):
        """Return basis gates including fractional gates if enabled."""
        if self.use_fractional_gates:
            return ["rx", "rzz", "rz", "id", "measure"]
        return list(self.basis_gates)

    @property
    def has_fractional_rx(self):
        """Whether fractional RX is available."""
        return self.use_fractional_gates or "frx" in self.basis_gates

    @property
    def has_fractional_rzz(self):
        """Whether fractional RZZ is available."""
        return self.use_fractional_gates or "frzz" in self.basis_gates

    def with_fractional_gates(self, enabled=True):
        """Return a new Target with fractional gates enabled/disabled.

        This mirrors Qiskit's service.backend('ibm_torino', use_fractional_gates=True).

        Args:
            enabled: Whether to enable fractional gates.

        Returns:
            New Target with updated fractional gate support.
        """
        if enabled:
            new_basis = ["rx", "rzz", "rz", "id", "measure"]
        else:
            new_basis = list(self.basis_gates)

        return Target(
            n_qubits=self.n_qubits,
            basis_gates=new_basis,
            coupling_map=self.coupling_map,
            name=self.name,
            durations=self.durations,
            error_rates=self.error_rates,
            use_fractional_gates=enabled,
        )

    def to_dict(self) -> dict:
        return {
            "name": self.name or str(self.n_qubits) + "q-generic",
            "n_qubits": self.n_qubits,
            "basis_gates": self.basis_gates,
            "coupling_map": self.coupling_map,
            "durations": self.durations,
            "error_rates": self.error_rates,
            "use_fractional_gates": self.use_fractional_gates,
        }

    def to_json(self, path) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), indent=2))

    @staticmethod
    def from_json(path) -> "Target":
        data = json.loads(Path(path).read_text())
        return Target(
            n_qubits=data["n_qubits"],
            basis_gates=data["basis_gates"],
            coupling_map=data["coupling_map"],
            name=data.get("name", ""),
            durations=data.get("durations"),
            error_rates=data.get("error_rates"),
            use_fractional_gates=data.get("use_fractional_gates", False),
        )

    def __str__(self) -> str:
        frac_str = " [fractional]" if self.use_fractional_gates else ""
        return "Target(" + (self.name or "unnamed") + ", " + str(self.n_qubits) + " qubits, " + str(len(self.coupling_map)) + " edges" + frac_str + ")"
