"""
Quantum information measures for operators.

Provides ``process_fidelity`` for comparing two quantum operators/channels.

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/operator-class#process-fidelity
"""
from __future__ import annotations
import numpy as np


def process_fidelity(op_a, op_b=None, require_cp=True):
    """Return the process fidelity between two unitary operators.

    The process fidelity between two unitary operators *U* and *V* is

    .. math::

        F_{pro}(U, V) = \\frac{|\\text{Tr}(U^\\dagger V)|^2}{d^2}

    where *d* is the dimension of the operators.

    For equal operators that differ only by a global phase, the process
    fidelity is 1.0.

    Args:
        op_a: First operator (Operator, matrix, or array-like).
        op_b: Second operator.  If ``None``, computes the fidelity
              with the identity operator.
        require_cp: If True (default), raise an error when the input
                    operators are not valid quantum channels
                    (i.e., not unitary).

    Returns:
        float: The process fidelity in [0, 1].

    Raises:
        ValueError: If ``require_cp`` is True and an input is not unitary.

    Example::

        from zena.quantum_info import Operator, Pauli, process_fidelity

        op_a = Operator(Pauli("X"))
        op_b = np.exp(1j * 0.5) * Operator(Pauli("X"))

        print(process_fidelity(op_a, op_b))  # 1.0
    """
    from .operator import Operator as OperatorClass

    # Coerce inputs
    if not isinstance(op_a, OperatorClass):
        op_a = OperatorClass(op_a)

    d = op_a.data.shape[0]

    if op_b is None:
        op_b = OperatorClass(np.eye(d, dtype=complex))
    elif not isinstance(op_b, OperatorClass):
        op_b = OperatorClass(op_b)

    # Validate unitarity when required
    if require_cp:
        if not op_a.is_unitary():
            raise ValueError(
                "process_fidelity requires unitary inputs when "
                "require_cp=True. Input op_a is not unitary."
            )
        if not op_b.is_unitary():
            raise ValueError(
                "process_fidelity requires unitary inputs when "
                "require_cp=True. Input op_b is not unitary."
            )

    if op_a.data.shape != op_b.data.shape:
        raise ValueError(
            f"Input operators have different dimensions: "
            f"{op_a.data.shape} vs {op_b.data.shape}"
        )

    # F = |Tr(A^dag B)|^2 / d^2
    product = op_a.data.conj().T @ op_b.data
    trace = np.trace(product)
    fidelity = float(np.abs(trace) ** 2) / (d ** 2)
    return fidelity
