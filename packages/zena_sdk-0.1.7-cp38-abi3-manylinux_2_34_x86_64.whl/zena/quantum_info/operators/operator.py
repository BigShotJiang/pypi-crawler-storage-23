"""
Operator class for unitary matrix representation.

The Operator class computes and stores the unitary matrix that
represents a quantum circuit. It can be used to:
  - Extract the unitary of a circuit for analysis.
  - Re-synthesize circuits for optimization.
  - Verify circuit equivalence by comparing unitary matrices.

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/synthesize-unitary-operators

Example::

    from zena.circuit import QuantumCircuit
    from zena.quantum_info import Operator

    qc = QuantumCircuit(2)
    qc.h(0)
    qc.cx(0, 1)

    op = Operator(qc)
    print(op.data)       # 4x4 unitary matrix
    print(op.dim)        # (4, 4)
    print(op.num_qubits) # 2
"""
from __future__ import annotations
import numpy as np
from typing import Union, Optional
import math


# =========================================================================
# Standard gate matrices
# =========================================================================
_I = np.eye(2, dtype=complex)
_X = np.array([[0, 1], [1, 0]], dtype=complex)
_Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
_Z = np.array([[1, 0], [0, -1]], dtype=complex)
_H = np.array([[1, 1], [1, -1]], dtype=complex) / np.sqrt(2)
_S = np.array([[1, 0], [0, 1j]], dtype=complex)
_SDG = np.array([[1, 0], [0, -1j]], dtype=complex)
_T = np.array([[1, 0], [0, np.exp(1j * np.pi / 4)]], dtype=complex)
_TDG = np.array([[1, 0], [0, np.exp(-1j * np.pi / 4)]], dtype=complex)
_SX = 0.5 * np.array([[1 + 1j, 1 - 1j], [1 - 1j, 1 + 1j]], dtype=complex)
_SXDG = 0.5 * np.array([[1 - 1j, 1 + 1j], [1 + 1j, 1 - 1j]], dtype=complex)


def _rx(theta):
    c = np.cos(theta / 2)
    s = np.sin(theta / 2)
    return np.array([[c, -1j * s], [-1j * s, c]], dtype=complex)


def _ry(theta):
    c = np.cos(theta / 2)
    s = np.sin(theta / 2)
    return np.array([[c, -s], [s, c]], dtype=complex)


def _rz(lam):
    return np.array([[np.exp(-1j * lam / 2), 0],
                     [0, np.exp(1j * lam / 2)]], dtype=complex)


def _p(lam):
    return np.array([[1, 0], [0, np.exp(1j * lam)]], dtype=complex)


def _u(theta, phi, lam):
    c = np.cos(theta / 2)
    s = np.sin(theta / 2)
    return np.array([
        [c, -np.exp(1j * lam) * s],
        [np.exp(1j * phi) * s, np.exp(1j * (phi + lam)) * c]
    ], dtype=complex)


def _get_gate_matrix(name, params=()):
    """Return the unitary matrix for a named gate."""
    if name == "id" or name == "i":
        return _I.copy()
    elif name == "x":
        return _X.copy()
    elif name == "y":
        return _Y.copy()
    elif name == "z":
        return _Z.copy()
    elif name == "h":
        return _H.copy()
    elif name == "s":
        return _S.copy()
    elif name == "sdg":
        return _SDG.copy()
    elif name == "t":
        return _T.copy()
    elif name == "tdg":
        return _TDG.copy()
    elif name == "sx":
        return _SX.copy()
    elif name == "sxdg":
        return _SXDG.copy()
    elif name == "rx":
        return _rx(float(params[0]))
    elif name == "ry":
        return _ry(float(params[0]))
    elif name == "rz":
        return _rz(float(params[0]))
    elif name == "p":
        return _p(float(params[0]))
    elif name == "u" or name == "u3":
        return _u(float(params[0]), float(params[1]), float(params[2]))
    elif name == "unitary":
        # Custom unitary - stored in params[0]
        return np.array(params[0], dtype=complex)
    else:
        return None


def _controlled_gate(control, target, gate_matrix, n_qubits):
    """Build a controlled gate matrix for arbitrary single-qubit gate."""
    dim = 2 ** n_qubits
    result = np.eye(dim, dtype=complex)
    for i in range(dim):
        for j in range(dim):
            # Check if control bit is 1
            if (i >> (n_qubits - 1 - control)) & 1 == 1 and \
               (j >> (n_qubits - 1 - control)) & 1 == 1:
                # Extract target bit values
                i_target = (i >> (n_qubits - 1 - target)) & 1
                j_target = (j >> (n_qubits - 1 - target)) & 1
                # Check all other bits are the same
                i_rest = i & ~(1 << (n_qubits - 1 - target))
                j_rest = j & ~(1 << (n_qubits - 1 - target))
                if i_rest == j_rest:
                    result[i, j] = gate_matrix[i_target, j_target]
                else:
                    result[i, j] = 0
    return result


def _swap_matrix(q0, q1, n_qubits):
    """Build a SWAP gate matrix."""
    dim = 2 ** n_qubits
    result = np.zeros((dim, dim), dtype=complex)
    for i in range(dim):
        # Swap bits q0 and q1
        b0 = (i >> (n_qubits - 1 - q0)) & 1
        b1 = (i >> (n_qubits - 1 - q1)) & 1
        j = i
        # Clear both bits
        j &= ~(1 << (n_qubits - 1 - q0))
        j &= ~(1 << (n_qubits - 1 - q1))
        # Set swapped bits
        j |= b1 << (n_qubits - 1 - q0)
        j |= b0 << (n_qubits - 1 - q1)
        result[j, i] = 1
    return result


def _embed_single(gate_matrix, qubit, n_qubits):
    """Embed a single-qubit gate into the full n-qubit space."""
    matrices = []
    for i in range(n_qubits):
        if i == qubit:
            matrices.append(gate_matrix)
        else:
            matrices.append(_I)
    result = matrices[0]
    for m in matrices[1:]:
        result = np.kron(result, m)
    return result


class Operator:
    """Unitary matrix representation of a quantum circuit or matrix.

    Computes and stores the unitary matrix that implements a quantum
    circuit or operator. This is useful for:

    - Verifying circuit correctness
    - Re-synthesizing circuits for optimization
    - Analyzing quantum operations
    - Combining operators via tensor product, composition, and linear combinations

    The Operator class matches IBM Qiskit's ``qiskit.quantum_info.Operator`` API.

    Args:
        data: Either:
            - A QuantumCircuit to compute the unitary of.
            - A numpy array representing a unitary matrix.
            - A Pauli object.
            - A Gate object (any object with a ``to_matrix()`` method).
            - Another Operator (copy).

    Attributes:
        data: The operator matrix as a numpy ndarray.
        dim: Tuple of (rows, cols).
        num_qubits: Number of qubits.
        input_dims: Subsystem input dimensions.
        output_dims: Subsystem output dimensions.

    Reference:
        https://quantum.cloud.ibm.com/docs/en/guides/operator-class

    Example::

        from zena.quantum_info import Operator, Pauli

        # From a Pauli
        op = Operator(Pauli("XX"))
        print(op)

        # From a QuantumCircuit
        from zena.circuit import QuantumCircuit
        qc = QuantumCircuit(2)
        qc.h(0)
        qc.cx(0, 1)
        op = Operator(qc)
        print(op.is_unitary())  # True
    """

    def __init__(self, data):
        from .pauli import Pauli as PauliClass

        if isinstance(data, Operator):
            self._data = data._data.copy()
            self._num_qubits = data._num_qubits
        elif isinstance(data, PauliClass):
            # Initialize from Pauli object
            self._data = data.to_matrix()
            self._num_qubits = data.num_qubits
        elif isinstance(data, np.ndarray):
            self._data = np.array(data, dtype=complex)
            n = data.shape[0]
            self._num_qubits = int(round(np.log2(n)))
        elif hasattr(data, '_instructions'):
            # It's a QuantumCircuit
            self._num_qubits = data.n_qubits
            self._data = self._compute_unitary(data)
        elif hasattr(data, 'to_matrix'):
            # Gate or Instruction with to_matrix method
            mat = data.to_matrix()
            self._data = np.array(mat, dtype=complex)
            n = self._data.shape[0]
            self._num_qubits = int(round(np.log2(n)))
        else:
            arr = np.array(data, dtype=complex)
            self._data = arr
            n = arr.shape[0]
            self._num_qubits = int(round(np.log2(n)))

    def _compute_unitary(self, circuit):
        """Compute the unitary matrix of a quantum circuit."""
        n = circuit.n_qubits
        dim = 2 ** n
        result = np.eye(dim, dtype=complex)

        for inst in circuit._instructions:
            name = inst.name
            qubits = inst.qubits
            params = inst.params

            if name in ("barrier", "measure", "reset", "delay",
                        "if_else", "mid_circuit_measure"):
                continue  # Skip non-unitary instructions

            gate_mat = _get_gate_matrix(name, params)

            if gate_mat is not None and len(qubits) == 1:
                # Single-qubit gate
                full_mat = _embed_single(gate_mat, qubits[0], n)
                result = full_mat @ result

            elif name in ("cx", "cnot") and len(qubits) == 2:
                mat = _controlled_gate(qubits[0], qubits[1], _X, n)
                result = mat @ result

            elif name == "cy" and len(qubits) == 2:
                mat = _controlled_gate(qubits[0], qubits[1], _Y, n)
                result = mat @ result

            elif name == "cz" and len(qubits) == 2:
                mat = _controlled_gate(qubits[0], qubits[1], _Z, n)
                result = mat @ result

            elif name == "ch" and len(qubits) == 2:
                mat = _controlled_gate(qubits[0], qubits[1], _H, n)
                result = mat @ result

            elif name in ("swap",) and len(qubits) == 2:
                mat = _swap_matrix(qubits[0], qubits[1], n)
                result = mat @ result

            elif name == "ccx" and len(qubits) == 3:
                # Toffoli: controlled-controlled-X
                dim = 2 ** n
                mat = np.eye(dim, dtype=complex)
                for i in range(dim):
                    c0 = (i >> (n - 1 - qubits[0])) & 1
                    c1 = (i >> (n - 1 - qubits[1])) & 1
                    if c0 == 1 and c1 == 1:
                        # Flip target bit
                        j = i ^ (1 << (n - 1 - qubits[2]))
                        mat[i, i] = 0
                        mat[j, j] = 0
                        mat[i, j] = 1
                        mat[j, i] = 1
                result = mat @ result

            elif name == "unitary" and len(params) > 0:
                gate_matrix = np.array(params[0], dtype=complex)
                gate_n = int(np.log2(gate_matrix.shape[0]))
                if gate_n == 1:
                    full_mat = _embed_single(gate_matrix, qubits[0], n)
                    result = full_mat @ result
                elif gate_n == len(qubits):
                    full_mat = _embed_multi_qubit(gate_matrix, list(qubits), n)
                    result = full_mat @ result

            elif gate_mat is not None and len(qubits) == 2:
                full_mat = _embed_multi_qubit(gate_mat, list(qubits), n)
                result = full_mat @ result

        return result

    # ─── Properties ─────────────────────────────────────────────

    @property
    def data(self):
        """Return the operator matrix as a numpy array."""
        return self._data

    @property
    def dim(self):
        """Return the dimensions (rows, cols) of the matrix."""
        return self._data.shape

    @property
    def num_qubits(self):
        """Return the number of qubits."""
        return self._num_qubits

    @property
    def input_dims(self):
        """Return the input subsystem dimensions as a tuple of 2s.

        Example::

            op = Operator(np.eye(4))
            print(op.input_dims)  # (2, 2)
        """
        return tuple(2 for _ in range(self._num_qubits))

    @property
    def output_dims(self):
        """Return the output subsystem dimensions as a tuple of 2s.

        Example::

            op = Operator(np.eye(4))
            print(op.output_dims)  # (2, 2)
        """
        return tuple(2 for _ in range(self._num_qubits))

    # ─── Unitary / equivalence checks ───────────────────────────

    def is_unitary(self, atol=1e-10):
        """Check if the operator is unitary (U^dag U = I).

        Args:
            atol: Absolute tolerance for comparison.

        Returns:
            True if the matrix is unitary within tolerance.
        """
        product = self._data.conj().T @ self._data
        return np.allclose(product, np.eye(product.shape[0]), atol=atol)

    def equiv(self, other, atol=1e-10):
        """Check if two operators are equivalent up to global phase.

        Two unitary operators that differ only by a global phase are
        considered equivalent by this method, unlike ``__eq__``.

        Args:
            other: Another Operator or matrix.
            atol: Absolute tolerance.

        Returns:
            True if operators are equivalent up to global phase.

        Example::

            op_a = Operator(Pauli("X"))
            op_b = np.exp(1j * 0.5) * Operator(Pauli("X"))
            print(op_a.equiv(op_b))  # True
            print(op_a == op_b)      # False
        """
        other_data = self._coerce_other(other)

        if self._data.shape != other_data.shape:
            return False

        # Check if A = e^(i*phi) * B for some phase phi
        for i in range(self._data.shape[0]):
            for j in range(self._data.shape[1]):
                if abs(self._data[i, j]) > atol and abs(other_data[i, j]) > atol:
                    phase = self._data[i, j] / other_data[i, j]
                    adjusted = other_data * phase
                    return np.allclose(self._data, adjusted, atol=atol)

        return np.allclose(self._data, other_data, atol=atol)

    # ─── Adjoint ────────────────────────────────────────────────

    def adjoint(self):
        """Return the adjoint (conjugate transpose) of the operator.

        Returns:
            New Operator representing ``self^dagger``.
        """
        return Operator(self._data.conj().T)

    # ─── Composition ────────────────────────────────────────────

    def compose(self, other, qargs=None, front=False):
        """Compose this operator with another.

        ``A.compose(B)`` returns the operator with matrix ``B . A``
        (i.e., B applied after A).

        ``A.compose(B, front=True)`` returns ``A . B``
        (i.e., B applied before A).

        ``A.compose(B, qargs=[0, 2])`` composes a smaller operator B
        on subsystems [0, 2] of the larger operator A.

        Args:
            other: Another Operator, matrix, or implicitly convertible object.
            qargs: Optional list of subsystem indices to compose on.
            front: If True, compose in the reverse order (``self @ other``).

        Returns:
            New Operator representing the composition.

        Example::

            A = Operator(Pauli("X"))
            B = Operator(Pauli("Z"))

            # B . A  (B after A)
            A.compose(B)

            # A . B  (A after B)
            A.compose(B, front=True)

            # Compose B on qubit 0 of a 3-qubit identity
            op = Operator(np.eye(8))
            op.compose(Operator(Pauli("XZ")), qargs=[0, 2])
        """
        other_data = self._coerce_other(other)

        if qargs is None:
            # Full composition
            if front:
                return Operator(self._data @ other_data)
            else:
                return Operator(other_data @ self._data)
        else:
            # Subsystem composition
            n = self._num_qubits
            other_n = int(round(np.log2(other_data.shape[0])))

            if len(qargs) != other_n:
                raise ValueError(
                    f"Number of qargs ({len(qargs)}) does not match "
                    f"other operator qubits ({other_n})"
                )

            # Embed the smaller operator into the full space
            embedded = _embed_multi_qubit(other_data, list(qargs), n)

            if front:
                return Operator(self._data @ embedded)
            else:
                return Operator(embedded @ self._data)

    # ─── Tensor product / expansion ─────────────────────────────

    def tensor(self, other):
        """Tensor product with another operator: ``self ⊗ other``.

        For single-qubit operators A and B, ``A.tensor(B)`` gives
        a 2-qubit operator with B on subsystem 0 and A on subsystem 1.

        Args:
            other: Another Operator or implicitly convertible object.

        Returns:
            New Operator representing ``self ⊗ other``.

        Example::

            A = Operator(Pauli("X"))
            B = Operator(Pauli("Z"))
            result = A.tensor(B)  # X ⊗ Z
        """
        other_data = self._coerce_other(other)
        return Operator(np.kron(self._data, other_data))

    def expand(self, other):
        """Reverse-order tensor product: ``other ⊗ self``.

        For single-qubit operators A and B, ``A.expand(B)`` gives
        a 2-qubit operator with A on subsystem 0 and B on subsystem 1.

        Args:
            other: Another Operator or implicitly convertible object.

        Returns:
            New Operator representing ``other ⊗ self``.

        Example::

            A = Operator(Pauli("X"))
            B = Operator(Pauli("Z"))
            result = A.expand(B)  # Z ⊗ X
        """
        other_data = self._coerce_other(other)
        return Operator(np.kron(other_data, self._data))

    # ─── Linear combinations ────────────────────────────────────

    def __add__(self, other):
        """Add two operators element-wise.

        Note: Adding two unitary operators generally gives a non-unitary operator.

        Example::

            XX = Operator(Pauli("XX"))
            YY = Operator(Pauli("YY"))
            result = XX + YY
        """
        other_data = self._coerce_other(other)
        return Operator(self._data + other_data)

    def __sub__(self, other):
        """Subtract two operators element-wise."""
        other_data = self._coerce_other(other)
        return Operator(self._data - other_data)

    def __mul__(self, scalar):
        """Multiply operator by a scalar.

        Example::

            op = Operator(Pauli("X"))
            result = 0.5 * op
        """
        return Operator(self._data * scalar)

    def __rmul__(self, scalar):
        """Right-multiply operator by a scalar."""
        return Operator(scalar * self._data)

    def __neg__(self):
        """Negate the operator."""
        return Operator(-self._data)

    def __truediv__(self, scalar):
        """Divide operator by a scalar."""
        return Operator(self._data / scalar)

    # ─── Power ──────────────────────────────────────────────────

    def power(self, n):
        """Return the n-th matrix power of the operator.

        Args:
            n: The exponent (non-negative integer).

        Returns:
            New Operator representing ``self^n``.

        Example::

            op = Operator(Pauli("X"))
            print(op.power(2))  # Identity (X^2 = I)
        """
        if n == 0:
            return Operator(np.eye(self._data.shape[0], dtype=complex))
        result = np.linalg.matrix_power(self._data, n)
        return Operator(result)

    def __pow__(self, n):
        return self.power(n)

    # ─── Comparison ─────────────────────────────────────────────

    def __matmul__(self, other):
        return self.compose(other)

    def __eq__(self, other):
        """Check approximate equality (element-wise, no global phase tolerance).

        Example::

            Operator(Pauli("X")) == Operator(Pauli("X"))  # True
            Operator(Pauli("X")) == np.exp(1j * 0.5) * Operator(Pauli("X"))  # False
        """
        if isinstance(other, Operator):
            return np.allclose(self._data, other._data)
        return NotImplemented

    # ─── Transpose / Conjugate ──────────────────────────────────

    def transpose(self):
        """Return the transpose of the operator."""
        return Operator(self._data.T)

    def conjugate(self):
        """Return the complex conjugate of the operator."""
        return Operator(self._data.conj())

    # ─── Copy ───────────────────────────────────────────────────

    def copy(self):
        """Return a deep copy of this operator."""
        return Operator(self._data.copy())

    # ─── Display ────────────────────────────────────────────────

    def __repr__(self):
        """Qiskit-style repr with matrix, input_dims, output_dims."""
        mat_str = np.array2string(
            self._data, separator=", ",
            formatter={'complex_kind': lambda x: f"{x}"}
        )
        return (
            f"Operator({mat_str},\n"
            f"         input_dims={self.input_dims}, "
            f"output_dims={self.output_dims})"
        )

    def __str__(self):
        return self.__repr__()

    # ─── Helpers ────────────────────────────────────────────────

    @staticmethod
    def _coerce_other(other):
        """Convert other to a numpy matrix, supporting implicit conversion."""
        if isinstance(other, Operator):
            return other._data
        # Check for Pauli
        try:
            from .pauli import Pauli as PauliClass
            if isinstance(other, PauliClass):
                return other.to_matrix()
        except ImportError:
            pass
        # Check for to_matrix method (Gate, Instruction)
        if hasattr(other, 'to_matrix'):
            return np.array(other.to_matrix(), dtype=complex)
        return np.array(other, dtype=complex)


def _embed_multi_qubit(gate_matrix, qubits, n_qubits):
    """Embed a multi-qubit gate into the full n-qubit Hilbert space."""
    dim = 2 ** n_qubits
    gate_dim = gate_matrix.shape[0]
    gate_n = int(np.log2(gate_dim))
    result = np.zeros((dim, dim), dtype=complex)

    for i in range(dim):
        for j in range(dim):
            # Extract the bits corresponding to the gate qubits
            i_gate = 0
            j_gate = 0
            for k, q in enumerate(qubits):
                i_gate |= ((i >> (n_qubits - 1 - q)) & 1) << (gate_n - 1 - k)
                j_gate |= ((j >> (n_qubits - 1 - q)) & 1) << (gate_n - 1 - k)

            # Check remaining bits are the same
            i_rest = i
            j_rest = j
            for q in qubits:
                i_rest &= ~(1 << (n_qubits - 1 - q))
                j_rest &= ~(1 << (n_qubits - 1 - q))

            if i_rest == j_rest:
                result[i, j] = gate_matrix[i_gate, j_gate]

    return result
