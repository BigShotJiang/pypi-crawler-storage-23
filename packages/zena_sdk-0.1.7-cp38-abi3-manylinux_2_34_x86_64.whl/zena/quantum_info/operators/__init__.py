"""Operator classes for quantum information.

Matches Qiskit's ``qiskit/quantum_info/operators/`` structure.

Classes:
    Operator        - Dense matrix operator
    Pauli           - Single Pauli string with phase
    SparsePauliOp   - Linear combination of Pauli strings

Functions:
    process_fidelity - Process fidelity between operators
"""
from .operator import Operator
from .pauli import Pauli
from .sparse_pauli_op import SparsePauliOp
from .measures import process_fidelity

__all__ = ["Operator", "Pauli", "SparsePauliOp", "process_fidelity"]

