"""
Pauli operator class.

Represents a single Pauli string with an optional phase coefficient
from the set {+1, i, -1, -i}.

Matches Qiskit's ``qiskit.quantum_info.Pauli`` API.

Example::

    from zena.quantum_info import Pauli

    p = Pauli("XYZ")
    print(p.dim)         # (8, 8)
    print(p.to_matrix()) # 8x8 complex matrix
"""

from __future__ import annotations

import numpy as np
from functools import reduce
from typing import List, Optional, Tuple

__all__ = ["Pauli"]

# Single-qubit Pauli matrices
_I = np.eye(2, dtype=complex)
_X = np.array([[0, 1], [1, 0]], dtype=complex)
_Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
_Z = np.array([[1, 0], [0, -1]], dtype=complex)
_PAULI_MATS = {"I": _I, "X": _X, "Y": _Y, "Z": _Z}

# Phase map: phase_index -> complex coefficient
# phase=0 -> 1, phase=1 -> i, phase=2 -> -1, phase=3 -> -i
_PHASE_COEFFS = {0: 1+0j, 1: 1j, 2: -1+0j, 3: -1j}
_PHASE_LABELS = {0: "", 1: "i", 2: "-", 3: "-i"}


class Pauli:
    """
    N-qubit Pauli operator.

    A Pauli string is a tensor product of single-qubit Pauli matrices
    (I, X, Y, Z) with an optional phase from {+1, i, -1, -i}.

    Args:
        data: A string like ``"XYZ"`` or ``"iXX"`` or ``"-iZZ"``.
              Phase prefixes: ``""`` (+1), ``"i"`` (+i), ``"-"`` (-1), ``"-i"`` (-i).

    Example::

        p = Pauli("XZ")
        print(p)           # Pauli('XZ')
        print(p.dim)       # (4, 4)
        print(p.phase)     # 0
        print(p.to_matrix())
    """

    def __init__(self, data):
        if isinstance(data, Pauli):
            self._label = data._label
            self._phase = data._phase
            return

        if isinstance(data, str):
            label, phase = self._parse_label(data)
            self._label = label   # e.g. "XYZ" (no phase prefix)
            self._phase = phase   # 0,1,2,3
        else:
            raise TypeError(f"Pauli expects a string, got {type(data)}")

    @staticmethod
    def _parse_label(s: str) -> Tuple[str, int]:
        """Parse a Pauli string, extracting phase prefix."""
        s = s.strip()
        if s.startswith("-i"):
            label = s[2:]
            phase = 3    # -i
        elif s.startswith("i"):
            label = s[1:]
            phase = 1    # +i
        elif s.startswith("-"):
            label = s[1:]
            phase = 2    # -1
        elif s.startswith("+"):
            label = s[1:]
            phase = 0    # +1
        else:
            label = s
            phase = 0    # +1

        # Validate remaining chars
        for ch in label:
            if ch not in "IXYZ":
                raise ValueError(f"Invalid Pauli character: '{ch}'")

        return label, phase

    @property
    def label(self) -> str:
        """Return the Pauli string label (without phase prefix)."""
        return self._label

    @property
    def phase(self) -> int:
        """Return the phase index: 0 -> +1, 1 -> -i, 2 -> -1, 3 -> +i."""
        return self._phase

    @property
    def num_qubits(self) -> int:
        """Return the number of qubits."""
        return len(self._label)

    @property
    def dim(self) -> Tuple[int, int]:
        """Return the matrix dimensions ``(2^n, 2^n)``."""
        d = 2 ** self.num_qubits
        return (d, d)

    def to_label(self) -> str:
        """Return the full label including phase prefix."""
        prefix = _PHASE_LABELS[self._phase]
        return prefix + self._label

    def to_matrix(self) -> np.ndarray:
        """
        Return the dense matrix representation.

        Returns:
            numpy.ndarray: A ``2^n x 2^n`` complex matrix.
        """
        mats = [_PAULI_MATS[ch] for ch in self._label]
        result = reduce(np.kron, mats)
        coeff = _PHASE_COEFFS[self._phase]
        return coeff * result

    def adjoint(self) -> "Pauli":
        """Return the adjoint (Hermitian conjugate)."""
        # Pauli matrices are Hermitian, so adjoint only changes phase
        # (phase coeff)* => conjugate of phase
        conj_phase = {0: 0, 1: 3, 2: 2, 3: 1}
        new = Pauli(self._label)
        new._phase = conj_phase[self._phase]
        return new

    def commutes(self, other: "Pauli") -> bool:
        """
        Check if this Pauli commutes with another.

        Two Paulis commute if they differ on an even number of
        positions (excluding I).
        """
        if not isinstance(other, Pauli):
            raise TypeError("Expected a Pauli object")
        if self.num_qubits != other.num_qubits:
            raise ValueError("Paulis must have the same number of qubits")

        anticommute_count = 0
        for a, b in zip(self._label, other._label):
            if a != "I" and b != "I" and a != b:
                anticommute_count += 1
        return anticommute_count % 2 == 0

    def anticommutes(self, other: "Pauli") -> bool:
        """Check if this Pauli anticommutes with another."""
        return not self.commutes(other)

    def compose(self, other: "Pauli") -> "Pauli":
        """
        Compose (multiply) with another Pauli: ``self @ other``.

        Returns a new Pauli representing the product.
        """
        if not isinstance(other, Pauli):
            raise TypeError("Expected a Pauli object")
        if self.num_qubits != other.num_qubits:
            raise ValueError("Paulis must have the same number of qubits")

        # Compute the matrix product via Pauli algebra
        # P_a * P_b => phase * P_c
        new_label = []
        extra_phase = 0  # accumulated phase in units of i

        for a, b in zip(self._label, other._label):
            prod_label, prod_phase = _pauli_multiply(a, b)
            new_label.append(prod_label)
            extra_phase += prod_phase

        total_phase = (self._phase + other._phase + extra_phase) % 4
        result = Pauli("".join(new_label))
        result._phase = total_phase
        return result

    def dot(self, other: "Pauli") -> "Pauli":
        """Compute dot product (same as compose for Paulis)."""
        return self.compose(other)

    def tensor(self, other: "Pauli") -> "Pauli":
        """Tensor product: self ⊗ other.

        Returns a new Pauli on ``self.num_qubits + other.num_qubits``
        qubits.

        Example::

            Pauli("X").tensor(Pauli("Z"))  # Pauli('XZ')
        """
        if not isinstance(other, Pauli):
            other = Pauli(other)
        new = Pauli(self._label + other._label)
        new._phase = (self._phase + other._phase) % 4
        return new

    def expand(self, other: "Pauli") -> "Pauli":
        """Reverse-order tensor product: other ⊗ self.

        Example::

            Pauli("X").expand(Pauli("Z"))  # Pauli('ZX')
        """
        if not isinstance(other, Pauli):
            other = Pauli(other)
        return other.tensor(self)

    def evolve(self, other, frame="h"):
        """Evolve this Pauli by another operator.

        Compute :math:`O^\\dagger P O` (Heisenberg picture, default)
        or :math:`O P O^\\dagger` (Schrödinger picture).

        Args:
            other: An Operator, QuantumCircuit, or gate-like object.
            frame: ``'h'`` for Heisenberg (default), ``'s'`` for Schrödinger.

        Returns:
            Operator: The evolved operator (dense matrix form).

        Example::

            from zena.quantum_info import Pauli, Operator
            from zena.circuit import QuantumCircuit

            qc = QuantumCircuit(1)
            qc.h(0)
            evolved = Pauli("Z").evolve(qc)
        """
        from .operator import Operator as Op

        P = Op(self.to_matrix())

        if isinstance(other, Op):
            O = other
        elif hasattr(other, "_instructions"):
            O = Op(other)
        else:
            O = Op(np.array(other, dtype=complex))

        if frame == "h":
            # Heisenberg: O† P O
            return O.adjoint().compose(P).compose(O)
        else:
            # Schrödinger: O P O†
            return O.compose(P).compose(O.adjoint())

    def inverse(self) -> "Pauli":
        """Return the inverse (same as adjoint for Paulis)."""
        return self.adjoint()

    def copy(self) -> "Pauli":
        """Return a copy of this Pauli."""
        new = Pauli(self._label)
        new._phase = self._phase
        return new

    def to_instruction(self):
        """Convert this Pauli to a circuit instruction.

        Returns a QuantumCircuit implementing this Pauli operator
        using standard gates (X, Y, Z, I).

        Returns:
            QuantumCircuit: A circuit implementing this Pauli.

        Example::

            qc = Pauli("XYZ").to_instruction()
        """
        from zena.circuit import QuantumCircuit

        n = self.num_qubits
        qc = QuantumCircuit(n)

        for i, ch in enumerate(self._label):
            if ch == "X":
                qc.x(i)
            elif ch == "Y":
                qc.y(i)
            elif ch == "Z":
                qc.z(i)
            # I = no gate needed

        return qc

    def __matmul__(self, other):
        return self.compose(other)

    def __repr__(self) -> str:
        return f"Pauli('{self.to_label()}')"

    def __str__(self) -> str:
        return self.to_label()

    def __eq__(self, other) -> bool:
        if isinstance(other, Pauli):
            return self._label == other._label and self._phase == other._phase
        return NotImplemented

    def __hash__(self):
        return hash((self._label, self._phase))


def _pauli_multiply(a: str, b: str):
    """
    Multiply two single-qubit Pauli operators.

    Returns (result_label, phase_increment) where phase is in units of i.
    """
    if a == "I":
        return b, 0
    if b == "I":
        return a, 0
    if a == b:
        return "I", 0

    # Non-trivial products:
    # X*Y = iZ,  Y*X = -iZ
    # Y*Z = iX,  Z*Y = -iX
    # Z*X = iY,  X*Z = -iY
    products = {
        ("X", "Y"): ("Z", 1),   # +i
        ("Y", "X"): ("Z", 3),   # -i
        ("Y", "Z"): ("X", 1),
        ("Z", "Y"): ("X", 3),
        ("Z", "X"): ("Y", 1),
        ("X", "Z"): ("Y", 3),
    }
    return products[(a, b)]
