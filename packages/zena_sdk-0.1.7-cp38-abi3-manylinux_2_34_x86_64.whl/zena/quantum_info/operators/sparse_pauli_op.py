"""
SparsePauliOp - Sparse representation of a sum of Pauli strings.

Represents a general quantum operator as a linear combination of
Pauli strings, matching IBM Qiskit's SparsePauliOp API.

Example::

    from zena.quantum_info import SparsePauliOp

    op = SparsePauliOp.from_list([("XX", 1.0), ("YY", -1.0), ("ZZ", 0.5)])
    print(op)
    print(op.to_matrix())
"""

from __future__ import annotations

import numpy as np
from typing import List, Optional, Sequence, Tuple, Union
from .pauli import Pauli

__all__ = ["SparsePauliOp"]


class SparsePauliOp:
    """
    A sparse representation of a sum of weighted Pauli strings.

    This class is the primary way to represent quantum observables
    (Hamiltonians) for variational algorithms.

    Attributes:
        paulis: List of Pauli string labels.
        coeffs: Complex coefficient for each Pauli string.
        num_qubits: Number of qubits.
    """

    def __init__(
        self,
        data: Union[str, List[str], "SparsePauliOp"],
        coeffs: Optional[Union[List, np.ndarray]] = None,
        *,
        num_qubits: Optional[int] = None,
    ):
        """
        Initialize a SparsePauliOp.

        Args:
            data: Can be:
                - A single Pauli string (e.g. ``"XYZ"``).
                - A list of Pauli strings (e.g. ``["XX", "YY", "ZZ"]``).
                - Another SparsePauliOp (copy).
            coeffs: Coefficients for each Pauli string. Defaults to all 1.0.
            num_qubits: Number of qubits. Inferred from data if not given.

        Example::

            op = SparsePauliOp(["XX", "YY", "ZZ"], coeffs=[1.0, -1.0, 0.5])
        """
        if isinstance(data, SparsePauliOp):
            self._labels = list(data._labels)
            self._coeffs = data._coeffs.copy()
            self._num_qubits = data._num_qubits
            return

        if isinstance(data, str):
            data = [data]

        self._labels = list(data)

        if coeffs is None:
            self._coeffs = np.ones(len(self._labels), dtype=complex)
        else:
            self._coeffs = np.array(coeffs, dtype=complex)

        if len(self._coeffs) != len(self._labels):
            raise ValueError(
                f"Number of coefficients ({len(self._coeffs)}) does not match "
                f"number of Pauli strings ({len(self._labels)})"
            )

        if num_qubits is not None:
            self._num_qubits = num_qubits
        elif self._labels:
            self._num_qubits = len(self._labels[0])
        else:
            self._num_qubits = 0

        # Validate all labels have same length
        for lbl in self._labels:
            if len(lbl) != self._num_qubits:
                raise ValueError(
                    f"Pauli string '{lbl}' has {len(lbl)} qubits, "
                    f"expected {self._num_qubits}"
                )
            for ch in lbl:
                if ch not in "IXYZ":
                    raise ValueError(f"Invalid Pauli character: '{ch}'")

    # ─── Factory methods ────────────────────────────────────────

    @classmethod
    def from_list(
        cls,
        obj: List[Tuple[str, complex]],
        *,
        num_qubits: Optional[int] = None,
    ) -> "SparsePauliOp":
        """
        Create from a list of ``(pauli_string, coefficient)`` pairs.

        Args:
            obj: List of (label, coeff) tuples.
            num_qubits: Number of qubits (inferred if not given).

        Example::

            op = SparsePauliOp.from_list([("XX", 1.0), ("YY", -1.0)])
        """
        labels = [item[0] for item in obj]
        coeffs = [item[1] for item in obj]
        return cls(labels, coeffs=coeffs, num_qubits=num_qubits)

    @classmethod
    def from_sparse_list(
        cls,
        obj: List[Tuple[str, List[int], complex]],
        *,
        num_qubits: int,
    ) -> "SparsePauliOp":
        """
        Create from a sparse list of ``(pauli_str, qubit_indices, coeff)`` triplets.

        Each triplet specifies a Pauli string, the qubit indices it acts on,
        and its coefficient. Qubits not mentioned get identity (I).

        Args:
            obj: List of (pauli_string, qubit_indices, coefficient) tuples.
            num_qubits: Total number of qubits.

        Example::

            op = SparsePauliOp.from_sparse_list(
                [("ZX", [1, 4], 1.0), ("YY", [0, 3], -1+1j)],
                num_qubits=5
            )
        """
        labels = []
        coeffs = []
        for pauli_str, qubit_indices, coeff in obj:
            if len(pauli_str) != len(qubit_indices):
                raise ValueError(
                    f"Pauli string '{pauli_str}' length {len(pauli_str)} "
                    f"doesn't match qubit indices length {len(qubit_indices)}"
                )
            # Build full label with I on unspecified qubits
            full = ["I"] * num_qubits
            for ch, qi in zip(pauli_str, qubit_indices):
                # Qiskit convention: qubit index maps to position from the RIGHT
                # in the label string (label is big-endian: q_{n-1} ... q_0)
                pos = num_qubits - 1 - qi
                full[pos] = ch
            labels.append("".join(full))
            coeffs.append(coeff)
        return cls(labels, coeffs=coeffs, num_qubits=num_qubits)

    @classmethod
    def from_operator(cls, op) -> "SparsePauliOp":
        """
        Create a SparsePauliOp from a dense Operator via Pauli decomposition.

        Args:
            op: An Operator object.
        """
        from .operator import Operator as Op
        if isinstance(op, Op):
            matrix = op.data
        else:
            matrix = np.array(op, dtype=complex)

        n = int(np.log2(matrix.shape[0]))
        dim = 2 ** n

        labels = []
        coeffs = []

        # Decompose: coeff_P = Tr(P @ rho) / 2^n
        for idx in range(4 ** n):
            label = _index_to_pauli_label(idx, n)
            p = Pauli(label)
            pmat = p.to_matrix()
            coeff = np.trace(pmat @ matrix) / dim
            if abs(coeff) > 1e-15:
                labels.append(label)
                coeffs.append(coeff)

        return cls(labels, coeffs=coeffs, num_qubits=n)

    # ─── Properties ─────────────────────────────────────────────

    @property
    def paulis(self) -> List[str]:
        """Return the list of Pauli string labels."""
        return list(self._labels)

    @property
    def coeffs(self) -> np.ndarray:
        """Return the array of coefficients."""
        return self._coeffs.copy()

    @property
    def num_qubits(self) -> int:
        """Return the number of qubits."""
        return self._num_qubits

    @property
    def size(self) -> int:
        """Return the number of terms."""
        return len(self._labels)

    # ─── Core methods ───────────────────────────────────────────

    def to_matrix(self) -> np.ndarray:
        """
        Convert to a dense matrix.

        Returns:
            numpy.ndarray: The full ``2^n x 2^n`` complex matrix.
        """
        dim = 2 ** self._num_qubits
        result = np.zeros((dim, dim), dtype=complex)
        for label, coeff in zip(self._labels, self._coeffs):
            p = Pauli(label)
            result += coeff * p.to_matrix()
        return result

    def to_list(self) -> List[Tuple[str, complex]]:
        """Return as a list of (label, coefficient) tuples."""
        return list(zip(self._labels, self._coeffs.tolist()))

    def adjoint(self) -> "SparsePauliOp":
        """Return the adjoint (Hermitian conjugate)."""
        # Pauli matrices are Hermitian, so adjoint just conjugates coefficients
        return SparsePauliOp(
            list(self._labels),
            coeffs=self._coeffs.conj(),
            num_qubits=self._num_qubits,
        )

    def simplify(self, atol: float = 1e-15) -> "SparsePauliOp":
        """
        Combine duplicate Pauli terms and remove near-zero terms.

        Returns:
            A new simplified SparsePauliOp.
        """
        combined = {}
        for label, coeff in zip(self._labels, self._coeffs):
            combined[label] = combined.get(label, 0) + coeff

        labels = []
        coeffs = []
        for label, coeff in combined.items():
            if abs(coeff) > atol:
                labels.append(label)
                coeffs.append(coeff)

        if not labels:
            # Return zero operator
            labels = ["I" * self._num_qubits]
            coeffs = [0.0]

        return SparsePauliOp(labels, coeffs=coeffs, num_qubits=self._num_qubits)

    def tensor(self, other: "SparsePauliOp") -> "SparsePauliOp":
        """
        Tensor product with another SparsePauliOp.

        Returns:
            New SparsePauliOp on ``self.num_qubits + other.num_qubits`` qubits.
        """
        labels = []
        coeffs = []
        for l1, c1 in zip(self._labels, self._coeffs):
            for l2, c2 in zip(other._labels, other._coeffs):
                labels.append(l1 + l2)
                coeffs.append(c1 * c2)
        return SparsePauliOp(
            labels, coeffs=coeffs,
            num_qubits=self._num_qubits + other._num_qubits,
        )

    def compose(self, other: "SparsePauliOp") -> "SparsePauliOp":
        """
        Operator composition (matrix multiplication): ``self @ other``.

        Returns:
            New SparsePauliOp representing the product.
        """
        if self._num_qubits != other._num_qubits:
            raise ValueError("Cannot compose operators with different qubit counts")

        labels = []
        coeffs = []
        for l1, c1 in zip(self._labels, self._coeffs):
            for l2, c2 in zip(other._labels, other._coeffs):
                p1 = Pauli(l1)
                p2 = Pauli(l2)
                prod = p1.compose(p2)
                from .pauli import _PHASE_COEFFS
                phase_coeff = _PHASE_COEFFS[prod.phase]
                labels.append(prod.label)
                coeffs.append(c1 * c2 * phase_coeff)

        result = SparsePauliOp(labels, coeffs=coeffs, num_qubits=self._num_qubits)
        return result.simplify()

    # ─── Arithmetic ─────────────────────────────────────────────

    def __add__(self, other: "SparsePauliOp") -> "SparsePauliOp":
        if not isinstance(other, SparsePauliOp):
            return NotImplemented
        if self._num_qubits != other._num_qubits:
            raise ValueError("Cannot add operators with different qubit counts")
        labels = list(self._labels) + list(other._labels)
        coeffs = np.concatenate([self._coeffs, other._coeffs])
        return SparsePauliOp(labels, coeffs=coeffs, num_qubits=self._num_qubits)

    def __sub__(self, other: "SparsePauliOp") -> "SparsePauliOp":
        if not isinstance(other, SparsePauliOp):
            return NotImplemented
        return self + (-1 * other)

    def __mul__(self, scalar) -> "SparsePauliOp":
        return SparsePauliOp(
            list(self._labels),
            coeffs=self._coeffs * scalar,
            num_qubits=self._num_qubits,
        )

    def __rmul__(self, scalar) -> "SparsePauliOp":
        return self.__mul__(scalar)

    def __matmul__(self, other: "SparsePauliOp") -> "SparsePauliOp":
        return self.compose(other)

    def __neg__(self) -> "SparsePauliOp":
        return self * (-1)

    # ─── Observable helpers ──────────────────────────────────────

    def group_commuting(self, qubit_wise: bool = False) -> list:
        """Group commuting Pauli terms for simultaneous measurement.

        Terms that commute can be measured together, reducing the
        number of circuit evaluations.

        Args:
            qubit_wise: If ``True``, group terms that commute on every
                qubit individually (stricter, but always safe).
                If ``False``, use general commutativity.

        Returns:
            List[SparsePauliOp]: Groups of mutually commuting terms.

        Example::

            H = SparsePauliOp.from_list([
                ("ZZ", 1), ("XX", 0.5), ("YY", 0.5), ("ZI", -0.3)
            ])
            groups = H.group_commuting()
        """
        remaining = list(range(len(self._labels)))
        groups = []

        while remaining:
            group_indices = [remaining.pop(0)]

            i = 0
            while i < len(remaining):
                idx = remaining[i]
                candidate = Pauli(self._labels[idx])
                # Check if candidate commutes with all in current group
                commutes_all = True
                for gi in group_indices:
                    existing = Pauli(self._labels[gi])
                    if qubit_wise:
                        # Qubit-wise: every qubit position must commute
                        for a, b in zip(candidate.label, existing.label):
                            if a != "I" and b != "I" and a != b:
                                commutes_all = False
                                break
                    else:
                        if not candidate.commutes(existing):
                            commutes_all = False
                    if not commutes_all:
                        break

                if commutes_all:
                    group_indices.append(remaining.pop(i))
                else:
                    i += 1

            labels = [self._labels[gi] for gi in group_indices]
            coeffs = [self._coeffs[gi] for gi in group_indices]
            groups.append(SparsePauliOp(labels, coeffs=coeffs, num_qubits=self._num_qubits))

        return groups

    def apply_layout(self, layout, num_qubits=None):
        """Map this operator to a physical qubit layout.

        Args:
            layout: A list mapping virtual qubit i → physical qubit
                    ``layout[i]``. For example, ``[2, 0]`` maps qubit 0
                    to physical qubit 2 and qubit 1 to physical qubit 0.
            num_qubits: Total number of physical qubits. Defaults to
                        ``max(layout) + 1``.

        Returns:
            SparsePauliOp: On ``num_qubits`` physical qubits.

        Example::

            op = SparsePauliOp.from_list([("XZ", 1.0)])
            mapped = op.apply_layout([3, 1], num_qubits=5)
        """
        if num_qubits is None:
            num_qubits = max(layout) + 1

        new_labels = []
        for label in self._labels:
            full = ["I"] * num_qubits
            for vq, ch in enumerate(reversed(label)):
                pq = layout[vq]
                full[num_qubits - 1 - pq] = ch
            new_labels.append("".join(full))

        return SparsePauliOp(
            new_labels,
            coeffs=self._coeffs.copy(),
            num_qubits=num_qubits,
        )

    def is_hermitian(self, atol: float = 1e-10) -> bool:
        """Check if this operator is Hermitian (a valid observable).

        An operator is Hermitian if all Pauli coefficients are real
        (since Pauli matrices are Hermitian).

        Args:
            atol: Tolerance for imaginary parts.

        Returns:
            bool: ``True`` if Hermitian.
        """
        simplified = self.simplify()
        return all(abs(c.imag) < atol for c in simplified._coeffs)

    def copy(self) -> "SparsePauliOp":
        """Return a copy of this SparsePauliOp."""
        return SparsePauliOp(
            list(self._labels),
            coeffs=self._coeffs.copy(),
            num_qubits=self._num_qubits,
        )

    # ─── Display ────────────────────────────────────────────────

    def __repr__(self) -> str:
        labels_str = str(self._labels)
        coeffs_str = np.array2string(self._coeffs, separator=", ")
        return f"SparsePauliOp({labels_str},\n              coeffs={coeffs_str})"

    def __str__(self) -> str:
        return self.__repr__()

    def __len__(self) -> int:
        return len(self._labels)

    def __eq__(self, other) -> bool:
        if isinstance(other, SparsePauliOp):
            s1 = self.simplify()
            s2 = other.simplify()
            return (
                sorted(zip(s1._labels, s1._coeffs.tolist()))
                == sorted(zip(s2._labels, s2._coeffs.tolist()))
            )
        return NotImplemented


def _index_to_pauli_label(idx: int, n: int) -> str:
    """Convert an integer index to an n-qubit Pauli label."""
    chars = "IXYZ"
    label = []
    for _ in range(n):
        label.append(chars[idx % 4])
        idx //= 4
    return "".join(reversed(label))
