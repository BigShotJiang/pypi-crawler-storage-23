"""
Quantum information module.

Provides tools for working with quantum states and operators,
matching Qiskit's ``qiskit.quantum_info`` module.

Classes:
    Operator        - Dense matrix representation of quantum operators
    Pauli           - Single Pauli string with optional phase
    SparsePauliOp   - Linear combination of Pauli strings (observables)

Functions:
    process_fidelity - Process fidelity between unitary operators

Reference:
    https://quantum.cloud.ibm.com/docs/en/guides/operators-overview
"""
from .operator import Operator
from .operators import Pauli, SparsePauliOp, process_fidelity

__all__ = ["Operator", "Pauli", "SparsePauliOp", "process_fidelity"]

