.. py:currentmodule:: rubin_scheduler.scheduler

.. _fbs-api-utils:

Utils
^^^^^^

.. automodule:: rubin_scheduler.scheduler.utils
    :imported-members:
    :members:
    :show-inheritance:

