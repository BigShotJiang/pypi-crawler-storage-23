_instruments = ("boto3 >= 1.28.57",)
_supports_metrics = False
