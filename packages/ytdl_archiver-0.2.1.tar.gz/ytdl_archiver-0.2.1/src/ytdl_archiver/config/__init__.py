"""Configuration module for ytdl-archiver."""
