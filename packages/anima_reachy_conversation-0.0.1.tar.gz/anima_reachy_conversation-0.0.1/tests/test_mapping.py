# tests/test_mapping.py
import pytest
from anima_reachy_conversation import EmotionalMapper, ANCHORS

def test_neutral_mapping():
    mapper = EmotionalMapper()
    neutral = (0.5, 0.5, 0.5, 0.5, 0.5)
    
    target = mapper.map(neutral)
    
    # Neutral should be CLOSE to zero, but RBF blending means
    # nearby anchors contribute slightly
    assert abs(target.head_z) < 0.005  # Within 5mm
    assert abs(target.head_pitch) < 0.05  # Within ~3 degrees
    assert 0.8 < target.antenna_amplitude_mult < 1.2  # Close to 1.0
    
    # Should be dominated by neutral anchor
    nearest = mapper.get_nearest_anchors(neutral, k=1)
    assert nearest[0][0] == "neutral"
    assert nearest[0][1] > 0.5  # Neutral has majority weight

def test_sad_mapping():
    mapper = EmotionalMapper()
    sad = (0.1, 0.2, 0.3, 0.6, 0.55)  # Exact sadness anchor
    
    target = mapper.map(sad)
    
    # Should droop and slow antennas
    assert target.head_z < -0.01  # Droop down
    assert target.head_pitch > 0.2  # Look down
    assert target.antenna_amplitude_mult < 0.5  # Minimal sway
    assert target.attack_time > 0.3  # Slow arrival
    
    # Sadness should dominate (but with sigma=0.25, not exclusively)
    nearest = mapper.get_nearest_anchors(sad, k=1)
    assert nearest[0][0] == "sadness"
    assert nearest[0][1] > 0.6  # Good weight (not perfect due to RBF spread)

def test_nearest_anchors():
    mapper = EmotionalMapper()
    sad_ish = (0.3, 0.4, 0.4, 0.6, 0.6)
    
    nearest = mapper.get_nearest_anchors(sad_ish, k=3)
    
    # Should have sadness as top contributor
    assert len(nearest) == 3
    
    # Top anchor should be sadness or boredom (both nearby)
    assert nearest[0][0] in ['sadness', 'boredom', 'neutral', 'anxiety']
    
    # Weights of top 3 should be substantial but not necessarily sum to 1.0
    # (because other anchors also contribute small amounts)
    total_weight = sum(w for _, w in nearest)
    assert total_weight > 0.5  # Top 3 have majority influence

def test_joy_mapping():
    mapper = EmotionalMapper()
    joy = (0.9, 0.85, 0.8, 0.7, 0.8)  # Exact joy anchor
    
    target = mapper.map(joy)
    
    # Should lift and animate
    assert target.head_z > 0.005  # Lift up
    assert target.head_pitch < -0.1  # Look up
    assert target.antenna_amplitude_mult > 2.0  # Big sway
    assert target.antenna_frequency_mult > 3.0  # Fast
    assert target.attack_time <= 0.21  # Quick arrival (with RBF tolerance)

def test_sigma_affects_blending():
    """Test that sigma parameter controls blend smoothness."""
    sharp_mapper = EmotionalMapper(sigma=0.15)
    soft_mapper = EmotionalMapper(sigma=0.5)
    
    # Test at a point between neutral and sad
    mid_point = (0.3, 0.35, 0.4, 0.55, 0.525)
    
    sharp_nearest = sharp_mapper.get_nearest_anchors(mid_point, k=2)
    soft_nearest = soft_mapper.get_nearest_anchors(mid_point, k=2)
    
    # Sharp should have more concentrated weight on top anchor
    # Soft should distribute weight more evenly
    sharp_top_weight = sharp_nearest[0][1]
    soft_top_weight = soft_nearest[0][1]
    
    assert sharp_top_weight > soft_top_weight  # Sharp = more concentrated

def test_all_anchors_accessible():
    """Verify all 9 anchors can be reached."""
    mapper = EmotionalMapper()
    
    anchor_names = [a.name for a in ANCHORS]
    assert len(anchor_names) == 9
    
    expected = [
        "neutral", "joy", "sadness", "anger", 
        "anxiety", "calm", "pride", "curiosity", "boredom"
    ]
    
    for name in expected:
        assert name in anchor_names

def test_motion_target_has_all_fields():
    """Verify MotionTarget contains all expected DOFs."""
    mapper = EmotionalMapper()
    target = mapper.map((0.5, 0.5, 0.5, 0.5, 0.5))
    
    # Check all 7 DOF exist
    assert hasattr(target, 'head_x')
    assert hasattr(target, 'head_y')
    assert hasattr(target, 'head_z')
    assert hasattr(target, 'head_roll')
    assert hasattr(target, 'head_pitch')
    assert hasattr(target, 'head_yaw')
    assert hasattr(target, 'body_yaw')
    
    # Check antenna params
    assert hasattr(target, 'antenna_left_base')
    assert hasattr(target, 'antenna_right_base')
    assert hasattr(target, 'antenna_amplitude_mult')
    assert hasattr(target, 'antenna_frequency_mult')
    
    # Check temporal
    assert hasattr(target, 'attack_time')
    assert hasattr(target, 'release_time')

def test_extreme_values_dont_crash():
    """Ensure mapper handles edge cases gracefully."""
    mapper = EmotionalMapper()
    
    # All zeros
    target = mapper.map((0.0, 0.0, 0.0, 0.0, 0.0))
    assert target is not None
    
    # All ones
    target = mapper.map((1.0, 1.0, 1.0, 1.0, 1.0))
    assert target is not None
    
    # Mixed extremes
    target = mapper.map((0.0, 1.0, 0.0, 1.0, 0.0))
    assert target is not None
