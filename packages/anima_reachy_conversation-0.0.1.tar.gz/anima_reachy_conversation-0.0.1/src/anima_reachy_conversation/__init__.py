"""Emotional expression mapping for Reachy Mini conversation app.

Maps VADCC emotional state to physical robot movement using anchor-based
RBF interpolation with body-specific temporal dynamics.

Usage:
    from anima import Anima, Config
    from anima_reachy_conversation import MovementAdapter
    
    anima = Anima(Config())
    adapter = MovementAdapter(movement_manager)
    anima.subscribe(adapter.update)
"""

from .anchors import EmotionalAnchor, ANCHORS
from .mapping import EmotionalMapper, MotionTarget
from .temporal import BodyTemporal
from .adapter import MovementAdapter

__version__ = "0.1.0"

__all__ = [
    "EmotionalAnchor",
    "ANCHORS",
    "EmotionalMapper",
    "MotionTarget",
    "BodyTemporal",
    "MovementAdapter",
]
