# anchors.py
from dataclasses import dataclass
from typing import Tuple

@dataclass
class EmotionalAnchor:
    """A recorded emotional pose for Reachy Mini.
    
    Full expressiveness:
    - 7-DOF pose (head x/y/z, roll/pitch/yaw, body_yaw)
    - Antenna base position (left/right angles in radians)
    - Antenna breathing modulation (amplitude/frequency multipliers)
    - Body-specific temporal response (attack/release)
    """
    name: str
    vadcc: Tuple[float, float, float, float, float]  # (V, A, D, Cx, Ch)
    
    # Head position (meters)
    head_x: float = 0.0
    head_y: float = 0.0
    head_z: float = 0.0
    
    # Head orientation (radians)
    head_roll: float = 0.0
    head_pitch: float = 0.0
    head_yaw: float = 0.0
    
    # Body orientation (radians)
    body_yaw: float = 0.0
    
    # Antenna base position (radians) - where antennas rest
    antenna_left_base: float = 0.0
    antenna_right_base: float = 0.0
    
    # Antenna breathing modulation (multipliers)
    antenna_amplitude_mult: float = 1.0
    antenna_frequency_mult: float = 1.0
    
    # Body-specific temporal response
    attack_time: float = 0.2    # How fast to physically move into this pose
    release_time: float = 0.6   # How long to physically hold/decay from this pose


# Complete baseline with educated guesses for all DOFs
ANCHORS = [
    EmotionalAnchor(
        name="neutral",
        vadcc=(0.5, 0.5, 0.5, 0.5, 0.5),
        # Everything at zero/1.0 (neutral baseline)
        antenna_amplitude_mult=1.0,
        antenna_frequency_mult=1.0,
    ),
    
    EmotionalAnchor(
        name="joy",
        vadcc=(0.9, 0.85, 0.8, 0.7, 0.8),
        head_z=0.01,              # Lift up
        head_pitch=-0.2,          # Look up
        antenna_left_base=0.1,    # Antennas up/alert
        antenna_right_base=0.1,
        antenna_amplitude_mult=2.75,   # Big sway
        antenna_frequency_mult=4.4,    # Fast movement
        attack_time=0.15,         # Joy arrives quickly!
        release_time=0.4,
    ),
    
    EmotionalAnchor(
        name="sadness",
        vadcc=(0.1, 0.2, 0.3, 0.6, 0.55),
        head_z=-0.015,            # Droop down
        head_pitch=0.3,           # Look down
        head_yaw=0.05,            # Slight turn away (avoidance)
        antenna_left_base=-0.15,  # Antennas droop
        antenna_right_base=-0.15,
        antenna_amplitude_mult=0.375,  # Minimal sway
        antenna_frequency_mult=0.24,   # Very slow
        attack_time=0.4,          # Sadness creeps in slowly
        release_time=1.2,         # Lingers heavily
    ),
    
    EmotionalAnchor(
        name="anger",
        vadcc=(0.1, 0.9, 0.9, 0.8, 0.9),
        head_y=0.01,              # Push forward (confrontational)
        head_pitch=-0.1,          # Slight up (assertive)
        body_yaw=0.0,             # Face directly forward
        antenna_left_base=0.05,   # Alert but tense
        antenna_right_base=0.05,
        antenna_amplitude_mult=0.75,
        antenna_frequency_mult=3.6,    # Fast, sharp
        attack_time=0.1,          # Anger snaps FAST
        release_time=0.8,
    ),
    
    EmotionalAnchor(
        name="anxiety",
        vadcc=(0.2, 0.85, 0.4, 0.85, 0.85),
        head_z=-0.01,
        head_pitch=0.05,
        head_yaw=-0.08,           # Nervous glance away
        antenna_left_base=0.08,   # Asymmetric (agitated)
        antenna_right_base=-0.03,
        antenna_amplitude_mult=0.625,
        antenna_frequency_mult=5.6,    # Jittery, fast
        attack_time=0.12,         # Quick onset
        release_time=0.5,
    ),
    
    EmotionalAnchor(
        name="calm",
        vadcc=(0.7, 0.2, 0.4, 0.6, 0.6),
        head_z=0.005,
        head_pitch=0.0,
        antenna_left_base=0.0,    # Relaxed, neutral
        antenna_right_base=0.0,
        antenna_amplitude_mult=1.25,
        antenna_frequency_mult=0.5,    # Slow, peaceful
        attack_time=0.6,          # Arrives slowly
        release_time=1.0,         # Fades slowly
    ),
    
    EmotionalAnchor(
        name="pride",
        vadcc=(0.85, 0.65, 0.85, 0.65, 0.65),
        head_z=0.015,             # Head up high
        head_pitch=-0.3,          # Strong upward tilt
        body_yaw=0.0,             # Face forward confidently
        antenna_left_base=0.12,   # Antennas up proud
        antenna_right_base=0.12,
        antenna_amplitude_mult=2.25,
        antenna_frequency_mult=1.6,
        attack_time=0.3,
        release_time=0.5,
    ),
    
    EmotionalAnchor(
        name="curiosity",
        vadcc=(0.7, 0.75, 0.4, 0.8, 0.75),
        head_z=0.005,
        head_pitch=-0.05,         # Slight up (interested)
        head_yaw=0.1,             # Turn toward (peering)
        antenna_left_base=0.15,   # One antenna higher (alert asymmetry)
        antenna_right_base=0.05,
        antenna_amplitude_mult=1.75,
        antenna_frequency_mult=3.2,
        attack_time=0.15,         # Quick alert
        release_time=0.4,
    ),
    
    EmotionalAnchor(
        name="boredom",
        vadcc=(0.35, 0.15, 0.5, 0.6, 0.55),
        head_z=-0.01,
        head_pitch=0.15,          # Looking down/away
        head_yaw=-0.12,           # Turn away (disengaged)
        antenna_left_base=-0.08,  # Drooped
        antenna_right_base=-0.08,
        antenna_amplitude_mult=0.5,
        antenna_frequency_mult=0.3,    # Very slow
        attack_time=0.8,          # Slow decline into boredom
        release_time=0.7,
    ),
]
