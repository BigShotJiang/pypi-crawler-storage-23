# temporal.py
import time
from dataclasses import dataclass
from .mapping import MotionTarget

@dataclass
class BodyState:
    """Physical body state with transition tracking."""
    current: MotionTarget
    target: MotionTarget
    transition_start: float = 0.0
    last_update: float = 0.0


class BodyTemporal:
    """Manages body-specific physical timing.
    
    Key insight: What the robot FEELS (Anima) ≠ What it SHOWS (body).
    
    - Attack time: How fast to physically move into emotional pose
    - Release time: How long to physically hold/decay from pose
    
    Example: Sadness arrives
      1. Anima feels sad immediately
      2. Body slowly moves into sad pose (attack=0.4s)
      3. Body holds sad pose deeply (release=1.2s)
      4. Even as Anima recovers, body lingers in sadness
      5. Eventually decays back to Anima's current state
    """
    
    def __init__(self, neutral_target: MotionTarget):
        now = time.monotonic()
        self.state = BodyState(
            current=neutral_target,
            target=neutral_target,
            last_update=now,
        )
    
    def update(self, target: MotionTarget, dt: float) -> MotionTarget:
        """Apply body-specific timing to motion target.
        
        Args:
            target: Desired motion from Anima's current emotional state
            dt: Delta time (seconds)
            
        Returns:
            Actual motion to physically display
        """
        now = time.monotonic()
        
        # Detect target change (new emotional surge)
        if self._target_changed_significantly(target, self.state.target):
            # Start new transition using this emotion's attack time
            self.state.target = target
            self.state.transition_start = now
        
        # Compute transition progress
        elapsed = now - self.state.transition_start
        duration = self.state.target.attack_time
        
        if duration > 0:
            progress = min(1.0, elapsed / duration)
        else:
            progress = 1.0
        
        # Interpolate current → target
        self.state.current = self._blend_targets(
            self.state.current,
            self.state.target,
            progress,
        )
        
        return self.state.current
    
    @staticmethod
    def _target_changed_significantly(a: MotionTarget, b: MotionTarget) -> bool:
        """Check if new target warrants a transition."""
        # Use position + primary orientation as change detection
        pos_change = (
            abs(a.head_x - b.head_x) > 0.002
            or abs(a.head_y - b.head_y) > 0.002
            or abs(a.head_z - b.head_z) > 0.002
        )
        
        orient_change = (
            abs(a.head_pitch - b.head_pitch) > 0.02
            or abs(a.head_yaw - b.head_yaw) > 0.02
        )
        
        return pos_change or orient_change
    
    @staticmethod
    def _blend_targets(a: MotionTarget, b: MotionTarget, alpha: float) -> MotionTarget:
        """Linear interpolation between motion targets."""
        return MotionTarget(
            head_x=a.head_x * (1 - alpha) + b.head_x * alpha,
            head_y=a.head_y * (1 - alpha) + b.head_y * alpha,
            head_z=a.head_z * (1 - alpha) + b.head_z * alpha,
            head_roll=a.head_roll * (1 - alpha) + b.head_roll * alpha,
            head_pitch=a.head_pitch * (1 - alpha) + b.head_pitch * alpha,
            head_yaw=a.head_yaw * (1 - alpha) + b.head_yaw * alpha,
            body_yaw=a.body_yaw * (1 - alpha) + b.body_yaw * alpha,
            antenna_left_base=a.antenna_left_base * (1 - alpha) + b.antenna_left_base * alpha,
            antenna_right_base=a.antenna_right_base * (1 - alpha) + b.antenna_right_base * alpha,
            antenna_amplitude_mult=a.antenna_amplitude_mult * (1 - alpha) + b.antenna_amplitude_mult * alpha,
            antenna_frequency_mult=a.antenna_frequency_mult * (1 - alpha) + b.antenna_frequency_mult * alpha,
            attack_time=b.attack_time,
            release_time=b.release_time,
        )
