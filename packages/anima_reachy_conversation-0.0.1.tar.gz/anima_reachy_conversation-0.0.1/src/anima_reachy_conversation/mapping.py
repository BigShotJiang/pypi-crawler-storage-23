# mapping.py
from dataclasses import dataclass
from typing import List, Tuple
import math
from .anchors import EmotionalAnchor, ANCHORS

@dataclass
class MotionTarget:
    """Complete motion target with all expressiveness parameters."""
    # Head position (meters)
    head_x: float
    head_y: float
    head_z: float
    
    # Head orientation (radians)
    head_roll: float
    head_pitch: float
    head_yaw: float
    
    # Body orientation (radians)
    body_yaw: float
    
    # Antenna base position (radians)
    antenna_left_base: float
    antenna_right_base: float
    
    # Antenna breathing modulation (multipliers)
    antenna_amplitude_mult: float
    antenna_frequency_mult: float
    
    # Body-specific temporal response
    attack_time: float
    release_time: float


class EmotionalMapper:
    """RBF-based VADCC → motion mapping.
    
    Blends nearby emotional anchors to produce smooth motion targets.
    Sigma controls blend smoothness (0.15=sharp, 0.25=medium, 0.5=soft).
    """
    
    def __init__(
        self,
        anchors: List[EmotionalAnchor] = None,
        sigma: float = 0.25,
    ):
        self.anchors = anchors or ANCHORS
        self.sigma = sigma
    
    def map(self, vadcc: Tuple[float, float, float, float, float]) -> MotionTarget:
        """Map VADCC to blended motion target."""
        weights = self._compute_rbf_weights(vadcc)
        
        return MotionTarget(
            # Head position
            head_x=sum(w * a.head_x for w, a in zip(weights, self.anchors)),
            head_y=sum(w * a.head_y for w, a in zip(weights, self.anchors)),
            head_z=sum(w * a.head_z for w, a in zip(weights, self.anchors)),
            
            # Head orientation
            head_roll=sum(w * a.head_roll for w, a in zip(weights, self.anchors)),
            head_pitch=sum(w * a.head_pitch for w, a in zip(weights, self.anchors)),
            head_yaw=sum(w * a.head_yaw for w, a in zip(weights, self.anchors)),
            
            # Body orientation
            body_yaw=sum(w * a.body_yaw for w, a in zip(weights, self.anchors)),
            
            # Antenna base position
            antenna_left_base=sum(w * a.antenna_left_base for w, a in zip(weights, self.anchors)),
            antenna_right_base=sum(w * a.antenna_right_base for w, a in zip(weights, self.anchors)),
            
            # Antenna breathing modulation
            antenna_amplitude_mult=sum(w * a.antenna_amplitude_mult for w, a in zip(weights, self.anchors)),
            antenna_frequency_mult=sum(w * a.antenna_frequency_mult for w, a in zip(weights, self.anchors)),
            
            # Temporal response
            attack_time=sum(w * a.attack_time for w, a in zip(weights, self.anchors)),
            release_time=sum(w * a.release_time for w, a in zip(weights, self.anchors)),
        )
    
    def _compute_rbf_weights(self, vadcc: Tuple[float, float, float, float, float]) -> List[float]:
        """Compute normalized RBF weights (Gaussian kernel)."""
        weights = []
        for anchor in self.anchors:
            dist_sq = sum((vadcc[i] - anchor.vadcc[i]) ** 2 for i in range(5))
            weight = math.exp(-dist_sq / (2 * self.sigma ** 2))
            weights.append(weight)
        
        total = sum(weights)
        if total < 1e-8:
            return [1.0 / len(weights)] * len(weights)
        
        return [w / total for w in weights]
    
    def get_nearest_anchors(
        self,
        vadcc: Tuple[float, float, float, float, float],
        k: int = 3,
    ) -> List[Tuple[str, float]]:
        """Debug: see which anchors influence this state.
        
        Example:
            >>> mapper.get_nearest_anchors((0.3, 0.4, 0.4, 0.6, 0.6))
            [('sadness', 0.58), ('boredom', 0.27), ('neutral', 0.15)]
        """
        weights = self._compute_rbf_weights(vadcc)
        pairs = [(a.name, w) for a, w in zip(self.anchors, weights)]
        pairs.sort(key=lambda x: x[1], reverse=True)
        return pairs[:k]
