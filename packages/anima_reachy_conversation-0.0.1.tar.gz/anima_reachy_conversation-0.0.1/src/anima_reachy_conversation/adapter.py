# adapter.py
import time
from typing import Tuple
from .mapping import EmotionalMapper
from .temporal import BodyTemporal

class MovementAdapter:
    """Bridge anima → MovementManager.
    
    Responsibilities:
    - Map VADCC → physical motion (via RBF anchors)
    - Apply body-specific timing (attack/release)
    - Provide antenna parameters (base position + breathing modulation)
    """
    
    def __init__(
        self,
        movement_manager,
        base_antenna_amplitude: float = 15.0,  # Conversation app's base
        base_antenna_frequency: float = 0.5,
        sigma: float = 0.25,  # RBF smoothness control
    ):
        self.movement_manager = movement_manager
        self.mapper = EmotionalMapper(sigma=sigma)
        
        # Base antenna breathing (conversation app defines)
        self.base_antenna_amplitude = base_antenna_amplitude
        self.base_antenna_frequency = base_antenna_frequency
        
        # Body temporal layer
        neutral = self.mapper.map((0.5, 0.5, 0.5, 0.5, 0.5))
        self.temporal = BodyTemporal(neutral)
        
        # Timing
        self.last_update = time.monotonic()
        
        # Cache
        self._current_motion = neutral
    
    def update(self, vadcc: Tuple[float, float, float, float, float]) -> None:
        """Receive VADCC from Anima, apply to robot."""
        now = time.monotonic()
        dt = now - self.last_update
        self.last_update = now
        
        # 1. Map VADCC → target motion (RBF blend)
        target = self.mapper.map(vadcc)
        
        # 2. Apply body-specific timing
        motion = self.temporal.update(target, dt)
        self._current_motion = motion
        
        # 3. Send to MovementManager
        # Full 7-DOF offsets
        offsets = (
            motion.head_x,
            motion.head_y,
            motion.head_z,
            motion.head_roll,
            motion.head_pitch,
            motion.head_yaw,
            motion.body_yaw,
        )
        self.movement_manager.set_emotional_offsets(offsets)
    
    def get_antenna_params(self) -> Tuple[float, float, float, float]:
        """For BreathingMove: base angles + breathing modulation.
        
        Returns:
            (left_base_rad, right_base_rad, amplitude_deg, frequency_hz)
        """
        motion = self._current_motion
        
        return (
            motion.antenna_left_base,
            motion.antenna_right_base,
            self.base_antenna_amplitude * motion.antenna_amplitude_mult,
            self.base_antenna_frequency * motion.antenna_frequency_mult,
        )
