# Anima behavior manifold for the Reachy Mini Conversation App  

Keeping this sparse as I expect that most people will come to this through related examples, but if use cases come up I'll update accordingly. 

See [ANIMA](https://github.com/brainwavecollective/anima-engine) for more info.
