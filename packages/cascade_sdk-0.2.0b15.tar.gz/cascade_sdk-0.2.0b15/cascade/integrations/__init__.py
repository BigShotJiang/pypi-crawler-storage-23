"""
Cascade SDK - Agent Framework Integrations

Auto-instrument popular agent frameworks with one function call.
Each integration translates the framework's native events into
Cascade spans so traces appear in the dashboard automatically.

Usage::

    from cascade import init_tracing
    from cascade.integrations import instrument_langgraph

    init_tracing(project="my_app")
    instrument_langgraph()
    # ... existing framework code unchanged ...
"""

from cascade.integrations.langgraph import instrument_langgraph
from cascade.integrations.openai_agents import instrument_openai_agents
from cascade.integrations.claude_agents import instrument_claude_agents

__all__ = [
    "instrument_langgraph",
    "instrument_openai_agents",
    "instrument_claude_agents",
]
