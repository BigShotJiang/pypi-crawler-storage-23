"""
Cascade SDK - LangGraph / LangChain Auto-Instrumentation

Automatically traces all LangGraph agent executions, LLM calls,
tool calls, and chain runs with zero code changes.

Usage::

    from cascade import init_tracing
    from cascade.integrations import instrument_langgraph

    init_tracing(project="my_langgraph_app")
    instrument_langgraph()

    # Existing LangGraph code -- no changes needed
    app = graph.compile()
    result = app.invoke({"messages": [...]})
"""

import logging
import json
from typing import Any, Dict, List, Optional, Union
from uuid import UUID

from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode, SpanKind

from cascade.tracing import get_tracer, get_current_agent

logger = logging.getLogger(__name__)

_instrumented = False


def instrument_langgraph() -> None:
    """
    Auto-instrument LangGraph/LangChain with Cascade tracing.

    Call this once after ``init_tracing()`` and before running any
    LangGraph code. All subsequent agent invocations will be traced
    automatically.

    Requires: ``pip install langgraph langchain-core``

    Raises:
        ImportError: If langchain-core is not installed.
    """
    global _instrumented
    if _instrumented:
        logger.debug("LangGraph already instrumented, skipping")
        return

    try:
        from langchain_core.callbacks import BaseCallbackHandler
        from langchain_core.callbacks.manager import CallbackManager
    except ImportError:
        raise ImportError(
            "LangGraph/LangChain not found. Install with: "
            "pip install langgraph langchain-core"
        )

    handler = CascadeLangChainHandler()

    # Patch the default callback manager to include our handler
    # so every LangChain/LangGraph invocation is traced automatically.
    try:
        from langchain_core.callbacks.manager import (
            CallbackManager,
            AsyncCallbackManager,
        )

        _original_configure = CallbackManager.configure
        _original_async_configure = AsyncCallbackManager.configure

        @classmethod  # type: ignore[misc]
        def patched_configure(cls, *args, **kwargs):
            manager = _original_configure.__func__(cls, *args, **kwargs)
            # Add our handler if not already present
            if not any(isinstance(h, CascadeLangChainHandler) for h in manager.handlers):
                manager.add_handler(handler)
            return manager

        @classmethod  # type: ignore[misc]
        def patched_async_configure(cls, *args, **kwargs):
            manager = _original_async_configure.__func__(cls, *args, **kwargs)
            if not any(isinstance(h, CascadeLangChainHandler) for h in manager.handlers):
                manager.add_handler(handler)
            return manager

        CallbackManager.configure = patched_configure
        AsyncCallbackManager.configure = patched_async_configure

    except Exception as e:
        logger.warning(f"Could not auto-patch CallbackManager: {e}")
        logger.info(
            "Pass the handler manually: "
            "app.invoke(..., config={'callbacks': [CascadeLangChainHandler()]})"
        )

    _instrumented = True
    logger.info("Cascade: LangGraph/LangChain auto-instrumentation enabled")


def _safe_str(value: Any, max_len: int = 4000) -> str:
    """Safely convert a value to a truncated string."""
    try:
        if isinstance(value, str):
            s = value
        elif isinstance(value, dict) or isinstance(value, list):
            s = json.dumps(value, default=str, ensure_ascii=False)
        else:
            s = str(value)
        return s[:max_len] if len(s) > max_len else s
    except Exception:
        return "<unserializable>"


class CascadeLangChainHandler:
    """
    LangChain BaseCallbackHandler that translates events into Cascade spans.

    Supports both sync and async callbacks. Maintains a stack of active
    spans keyed by LangChain's run_id so nested calls are properly parented.
    """

    def __init__(self):
        # run_id -> (span, token) mapping for context management
        self._spans: Dict[str, Any] = {}

        # Import BaseCallbackHandler at init time (already validated)
        from langchain_core.callbacks import BaseCallbackHandler

        # Dynamically inherit so isinstance checks pass
        self.__class__ = type(
            "CascadeLangChainHandler",
            (BaseCallbackHandler,),
            {k: v for k, v in CascadeLangChainHandler.__dict__.items() if not k.startswith("__")},
        )

    @property
    def always_verbose(self) -> bool:
        return True

    @property
    def raise_error(self) -> bool:
        return False

    # ------------------------------------------------------------------
    # Chain (Agent / Graph node / Runnable)
    # ------------------------------------------------------------------

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        try:
            tracer = get_tracer()
            if not tracer:
                return

            serialized = serialized or {}
            name = serialized.get("name") or (serialized.get("id", ["Unknown"]) or ["Unknown"])[-1]
            if name == "Unknown":
                name = kwargs.get("name", name)
            name_lower = name.lower()

            is_agent = "agent" in name_lower or (tags and "agent" in tags)
            span_type = "agent" if is_agent else "function"

            span = tracer.start_span(name, kind=SpanKind.INTERNAL)
            span.set_attribute("cascade.span_type", span_type)

            if is_agent:
                span.set_attribute("cascade.agent_name", name)
            if span_type == "function":
                span.set_attribute("function.name", name)
                span.set_attribute("function.input", _safe_str(inputs))

            self._spans[str(run_id)] = {
                "span": span,
                "ctx_token": trace.context_api.attach(trace.set_span_in_context(span)),
                "name": name,
                "type": span_type,
            }
        except Exception as e:
            logger.debug(f"Cascade: on_chain_start tracing failed: {e}")

    def on_chain_end(
        self,
        outputs: Dict[str, Any],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        try:
            entry = self._spans.pop(str(run_id), None)
            if not entry:
                return
            span = entry["span"]
            if entry["type"] == "function":
                span.set_attribute("function.output", _safe_str(outputs))
            span.set_status(Status(StatusCode.OK))
            span.end()
            if entry.get("ctx_token"):
                trace.context_api.detach(entry["ctx_token"])
        except Exception as e:
            logger.debug(f"Cascade: on_chain_end tracing failed: {e}")

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        try:
            entry = self._spans.pop(str(run_id), None)
            if not entry:
                return
            span = entry["span"]
            span.set_status(Status(StatusCode.ERROR, str(error)))
            span.record_exception(error)
            span.end()
            if entry.get("ctx_token"):
                trace.context_api.detach(entry["ctx_token"])
        except Exception as e:
            logger.debug(f"Cascade: on_chain_error tracing failed: {e}")

    # ------------------------------------------------------------------
    # LLM
    # ------------------------------------------------------------------

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            tracer = get_tracer()
            if not tracer:
                return

            serialized = serialized or {}
            model = serialized.get("kwargs", {}).get("model_name") or (serialized.get("id", ["unknown"]) or ["unknown"])[-1]
            name = f"llm.{model}"

            span = tracer.start_span(name, kind=SpanKind.INTERNAL)
            span.set_attribute("cascade.span_type", "llm")
            span.set_attribute("llm.model", model)
            span.set_attribute("llm.provider", (serialized.get("id", ["unknown"]) or ["unknown"])[0])

            prompt_text = "\n".join(prompts) if prompts else ""
            span.set_attribute("llm.prompt", _safe_str(prompt_text))

            current_agent = get_current_agent()
            if current_agent:
                span.set_attribute("cascade.agent_name", current_agent)

            self._spans[str(run_id)] = {
                "span": span,
                "ctx_token": trace.context_api.attach(trace.set_span_in_context(span)),
                "name": name,
                "type": "llm",
            }
        except Exception as e:
            logger.debug(f"Cascade: on_llm_start tracing failed: {e}")

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[Any]],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            tracer = get_tracer()
            if not tracer:
                return

            serialized = serialized or {}
            model = (
                serialized.get("kwargs", {}).get("model_name")
                or serialized.get("kwargs", {}).get("model")
                or (serialized.get("id", ["unknown"]) or ["unknown"])[-1]
            )
            name = f"llm.{model}"

            span = tracer.start_span(name, kind=SpanKind.INTERNAL)
            span.set_attribute("cascade.span_type", "llm")
            span.set_attribute("llm.model", model)

            id_parts = serialized.get("id", [])
            provider = "unknown"
            for part in id_parts:
                if "openai" in str(part).lower():
                    provider = "openai"
                    break
                elif "anthropic" in str(part).lower():
                    provider = "anthropic"
                    break
            span.set_attribute("llm.provider", provider)

            prompt_parts = []
            for msg_list in messages:
                for msg in msg_list:
                    role = getattr(msg, "type", "unknown")
                    content = getattr(msg, "content", str(msg))
                    prompt_parts.append(f"[{role}] {content}")
            span.set_attribute("llm.prompt", _safe_str("\n".join(prompt_parts)))

            current_agent = get_current_agent()
            if current_agent:
                span.set_attribute("cascade.agent_name", current_agent)

            self._spans[str(run_id)] = {
                "span": span,
                "ctx_token": trace.context_api.attach(trace.set_span_in_context(span)),
                "name": name,
                "type": "llm",
            }
        except Exception as e:
            logger.debug(f"Cascade: on_chat_model_start tracing failed: {e}")

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        try:
            entry = self._spans.pop(str(run_id), None)
            if not entry:
                return
            span = entry["span"]

            try:
                generations = response.generations
                if generations and generations[0]:
                    gen = generations[0][0]
                    completion = getattr(gen, "text", "") or str(getattr(gen, "message", {}).get("content", ""))
                    span.set_attribute("llm.completion", _safe_str(completion))

                usage = getattr(response, "llm_output", {}) or {}
                token_usage = usage.get("token_usage", {})
                if token_usage:
                    span.set_attribute("llm.input_tokens", token_usage.get("prompt_tokens", 0))
                    span.set_attribute("llm.output_tokens", token_usage.get("completion_tokens", 0))
                    span.set_attribute("llm.total_tokens", token_usage.get("total_tokens", 0))
            except Exception as e:
                logger.debug(f"Error extracting LLM response: {e}")

            span.set_status(Status(StatusCode.OK))
            span.end()
            if entry.get("ctx_token"):
                trace.context_api.detach(entry["ctx_token"])
        except Exception as e:
            logger.debug(f"Cascade: on_llm_end tracing failed: {e}")

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        try:
            entry = self._spans.pop(str(run_id), None)
            if not entry:
                return
            span = entry["span"]
            span.set_status(Status(StatusCode.ERROR, str(error)))
            span.record_exception(error)
            span.end()
            if entry.get("ctx_token"):
                trace.context_api.detach(entry["ctx_token"])
        except Exception as e:
            logger.debug(f"Cascade: on_llm_error tracing failed: {e}")

    # ------------------------------------------------------------------
    # Tool
    # ------------------------------------------------------------------

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            tracer = get_tracer()
            if not tracer:
                return

            serialized = serialized or {}
            tool_name = serialized.get("name") or (serialized.get("id", ["unknown"]) or ["unknown"])[-1]

            span = tracer.start_span(tool_name, kind=SpanKind.INTERNAL)
            span.set_attribute("cascade.span_type", "tool")
            span.set_attribute("tool.name", tool_name)
            span.set_attribute("tool.input", _safe_str(input_str))

            if serialized.get("description"):
                span.set_attribute("tool.description", serialized["description"][:200])

            current_agent = get_current_agent()
            if current_agent:
                span.set_attribute("cascade.agent_name", current_agent)

            self._spans[str(run_id)] = {
                "span": span,
                "ctx_token": trace.context_api.attach(trace.set_span_in_context(span)),
                "name": tool_name,
                "type": "tool",
            }
        except Exception as e:
            logger.debug(f"Cascade: on_tool_start tracing failed: {e}")

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        try:
            entry = self._spans.pop(str(run_id), None)
            if not entry:
                return
            span = entry["span"]
            span.set_attribute("tool.output", _safe_str(output))
            span.set_status(Status(StatusCode.OK))
            span.end()
            if entry.get("ctx_token"):
                trace.context_api.detach(entry["ctx_token"])
        except Exception as e:
            logger.debug(f"Cascade: on_tool_end tracing failed: {e}")

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        try:
            entry = self._spans.pop(str(run_id), None)
            if not entry:
                return
            span = entry["span"]
            span.set_attribute("tool.error", str(error))
            span.set_status(Status(StatusCode.ERROR, str(error)))
            span.record_exception(error)
            span.end()
            if entry.get("ctx_token"):
                trace.context_api.detach(entry["ctx_token"])
        except Exception as e:
            logger.debug(f"Cascade: on_tool_error tracing failed: {e}")

    # ------------------------------------------------------------------
    # Retriever (maps to tool spans)
    # ------------------------------------------------------------------

    def on_retriever_start(
        self,
        serialized: Dict[str, Any],
        query: str,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        try:
            tracer = get_tracer()
            if not tracer:
                return

            serialized = serialized or {}
            name = serialized.get("name", "retriever")
            span = tracer.start_span(name, kind=SpanKind.INTERNAL)
            span.set_attribute("cascade.span_type", "tool")
            span.set_attribute("tool.name", name)
            span.set_attribute("tool.input", _safe_str(query))

            self._spans[str(run_id)] = {
                "span": span,
                "ctx_token": trace.context_api.attach(trace.set_span_in_context(span)),
                "name": name,
                "type": "tool",
            }
        except Exception as e:
            logger.debug(f"Cascade: on_retriever_start tracing failed: {e}")

    def on_retriever_end(
        self,
        documents: List[Any],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        try:
            entry = self._spans.pop(str(run_id), None)
            if not entry:
                return
            span = entry["span"]
            doc_texts = []
            for doc in documents[:10]:
                content = getattr(doc, "page_content", str(doc))
                doc_texts.append(content[:500])
            span.set_attribute("tool.output", _safe_str("\n---\n".join(doc_texts)))
            span.set_status(Status(StatusCode.OK))
            span.end()
            if entry.get("ctx_token"):
                trace.context_api.detach(entry["ctx_token"])
        except Exception as e:
            logger.debug(f"Cascade: on_retriever_end tracing failed: {e}")
