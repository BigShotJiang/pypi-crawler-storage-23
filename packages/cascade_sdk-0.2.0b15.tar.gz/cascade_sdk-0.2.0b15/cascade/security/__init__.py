"""
Cascade Security Shield SDK

Provides prompt injection detection for AI agents.
Fire-and-forget — adds zero latency to your application.

Usage:
    from cascade.security import CascadeShield

    shield = CascadeShield(api_key="csk_live_...")
    
    # After your agent responds to the user:
    shield.detect(user_input, response_text=agent_response)
"""

from cascade.security.client import CascadeShield, ShieldResult

__all__ = ["CascadeShield", "ShieldResult"]

