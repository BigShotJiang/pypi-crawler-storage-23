from click.testing import CliRunner

from cascade.cli.main import cli


def test_cli_info_outputs_basic_text():
    runner = CliRunner()
    res = runner.invoke(cli, ["info"])
    assert res.exit_code == 0
    assert "Cascade SDK" in res.output
    assert "CASCADE_API_KEY" in res.output
