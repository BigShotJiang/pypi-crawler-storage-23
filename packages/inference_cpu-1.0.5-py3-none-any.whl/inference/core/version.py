__version__ = "1.0.5"


if __name__ == "__main__":
    print(__version__)
