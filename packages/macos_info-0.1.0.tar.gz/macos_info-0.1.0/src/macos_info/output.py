"""Output formatting and ASCII logo."""
from colorama import init, Fore, Style
from macos_info.system_info import get_all_info

init(autoreset=True, strip=False)

class OutputFormatter:
    ASCII_LOGO = [
"                   .o.",
"                .OMMM",
"               OMMM0,",
"       lodo:] [oollodolaab",
"    cKMMMMMMMMNWMMMMMMMMMM0:",
"  .KMMMMMMMMMMMMMMMMMMMMMWd.",
"  XMMMMMMMMMMMMMMMMMMMMMMMX.",
"  MMMMMMMMMMMMMMMMMMMMMM:",
" MMMMMMMMMMMMMMMMMMMMMMMMX.",
" kMMMMMMMMMMMMMMMMMMMMMMMMWd",
"  .XMMMMMMMMMMMMMMMMMMMMMMMMK",
"    kMMMMMMMMMMMMMMMMMMMMMMd",
"     ;KMMMMMMMWXXWMMMMMMMk.",
"       xMMMMMMM   MMMMMMx",
    ]

    def __init__(self, use_color=False):
        self.use_color = use_color  # 不使用

    def _colorize(self, text, color):
        if not self.use_color:
            return text
        return f"{color}{text}{Style.RESET_ALL}"

    def print_info(self, use_macports=False):
        """输出整体信息"""
        info = get_all_info(use_macports=use_macports)
        logo_width = max(len(line) for line in self.ASCII_LOGO)
        info_items = list(info.items())
        logo_lines = self.ASCII_LOGO

        for i, line in enumerate(logo_lines):
            if i == 0:
                print(line)
            elif i < len(info_items) + 1:
                key, value = info_items[i-1]
                colored_key = self._colorize(f"{key}:", Fore.GREEN)
                print(f"{line:<{logo_width}}  {colored_key} {value}")  # 将变量 line 的内容左对齐（<），总宽度由变量 logo_width 动态指定; 如果 line 长度不足 logo_width，会在右侧补空格，确保两栏对齐。
            else:
                print(self._colorize(line, Fore.WHITE))
