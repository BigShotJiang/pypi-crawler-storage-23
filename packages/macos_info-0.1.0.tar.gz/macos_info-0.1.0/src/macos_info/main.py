"""Entry point for macos-info."""
from macos_info.cli import cli

def main():
    cli()
