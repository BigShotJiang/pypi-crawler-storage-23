"""macos-info: Display macOS system information."""
__version__ = "0.1.0"
