"""CLI definition using Click."""
import click
from macos_info.output import OutputFormatter


def print_version(ctx, param, value):
    if value:
        click.echo("0.1.0")
        ctx.exit()


def print_help(ctx, param, value):
    if value:
        click.echo(ctx.get_help())
        ctx.exit()


@click.command()
@click.option('-v', '--version', is_flag=True, callback=print_version, expose_value=False, is_eager=True)
@click.option('-h', '--help', is_flag=True, callback=print_help, expose_value=False, is_eager=True)
@click.option('-m', '--macports', is_flag=True, help='Use MacPorts for package count')
def cli(macports):
    """Display macOS system information."""
    formatter = OutputFormatter()
    formatter.print_info(use_macports=macports)
