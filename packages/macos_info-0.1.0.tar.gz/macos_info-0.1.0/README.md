# macos-info

A macOS system information display tool inspired by archey-osx.

## Installation

```bash
pip install -e .
```

## Usage

```bash
macos-info --help
```

## Options

- `-m, --macports`: Use MacPorts for package count
- `-v, --version`
- `-h, --help`
