from .decorator import animate

__all__ = ['animate']