"""Shopline API 数据模型 - bearerAuth"""

from pydantic import BaseModel


class bearerAuth(BaseModel):
    pass
