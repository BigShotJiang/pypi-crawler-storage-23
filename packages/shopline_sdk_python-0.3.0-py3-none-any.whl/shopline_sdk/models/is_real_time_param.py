"""Shopline API 数据模型 - isRealTimeParam"""

from pydantic import BaseModel


class isRealTimeParam(BaseModel):
    """Whether to use real time data 是否使用實時數據"""
    pass
