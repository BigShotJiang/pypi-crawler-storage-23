"""Shopline API 数据模型 - endDateParam"""

from pydantic import BaseModel


class endDateParam(BaseModel):
    """Ending date of the analytics 分析的完結日期"""
    pass
