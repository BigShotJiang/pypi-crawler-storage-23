"""Shopline API 数据模型 - MemberPointRules"""

from pydantic import BaseModel


# 导入相关模型


class MemberPointRules(BaseModel):
    pass
