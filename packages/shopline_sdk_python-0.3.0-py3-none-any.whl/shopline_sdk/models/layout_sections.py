"""Shopline API 数据模型 - LayoutSections"""

from pydantic import BaseModel


# 导入相关模型


class LayoutSections(BaseModel):
    pass
