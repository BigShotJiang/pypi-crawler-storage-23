# sqldump-engine

A Python library and CLI tool to query SQL dump files (MySQL, PostgreSQL) directly using SQL, without requiring a running database server.

Powered by **DuckDB** and **sqlglot**.

## Features

- **Multi-dialect Support**: Handles MySQL and PostgreSQL dumps.
- **Smart Transpilation**: Converts dialect-specific DDL (like `AUTO_INCREMENT` or `SERIAL`) to DuckDB-compatible SQL.
- **High Performance**: Uses DuckDB's columnar engine for fast queries.
- **PostgreSQL COPY Support**: Efficiently handles bulk data exported via the `COPY` command.
- **CLI Interface**: Query dumps directly from your terminal.

## Installation

```bash
pip install -e .
```

## Usage

### CLI

```bash
# Query a MySQL dump
sqldump-engine query --dump tests/sample_mysql.sql "SELECT * FROM users"

# Query a PostgreSQL dump
sqldump-engine query --dump tests/sample_postgres.sql --dialect postgres "SELECT * FROM users"
```

### Python Library

```python
from sqldump_engine import SqlDumpEngine

engine = SqlDumpEngine()
engine.load_dump("path/to/dump.sql", dialect="mysql")

# Get results as a Pandas DataFrame
df = engine.fetch_df("SELECT username, email FROM users WHERE id > 10")
print(df)
```

## Limitations

- **Complex DDL**: Views, triggers, and stored procedures are currently ignored.
- **Dialect Parity**: While most standard types are mapped, esoteric vendor-specific types might fallback to `TEXT`.
- **Large multi-row INSERTs**: Very large `INSERT` statements in MySQL (many megabytes) are supported but might hit memory limits depending on the environment.
