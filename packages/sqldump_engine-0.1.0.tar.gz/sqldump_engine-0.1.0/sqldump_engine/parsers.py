import re
from typing import Generator, Tuple
import sqlglot
from sqlglot import transpile

class BaseParser:
    def parse(self, file_path: str) -> Generator[Tuple[str, any], None, None]:
        """Yields (type, data) tuples from the dump file."""
        raise NotImplementedError

class MySQLParser(BaseParser):
    def parse(self, file_path: str) -> Generator[Tuple[str, any], None, None]:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            current_stmt = []
            for line in f:
                # Remove comments
                clean_line = re.sub(r"--.*", "", line).strip()
                if not clean_line or clean_line.startswith("/*"):
                    continue
                
                current_stmt.append(clean_line)
                
                if clean_line.endswith(";"):
                    stmt = " ".join(current_stmt).strip()
                    current_stmt = []
                    
                    if stmt.upper().startswith("CREATE TABLE"):
                        yield "ddl", stmt
                    elif stmt.upper().startswith("INSERT INTO"):
                        yield "dml", stmt

class PostgresParser(BaseParser):
    def parse(self, file_path: str) -> Generator[Tuple[str, any], None, None]:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            current_stmt = []
            in_copy = False
            copy_stmt = ""
            copy_data = []

            for line in f:
                if in_copy:
                    if line.strip() == "\\.":
                        in_copy = False
                        yield "copy", (copy_stmt, "".join(copy_data))
                        copy_data = []
                        continue
                    copy_data.append(line)
                    continue

                # Remove comments
                clean_line = re.sub(r"--.*", "", line).strip()
                if not clean_line or clean_line.startswith("/*"):
                    continue
                
                current_stmt.append(clean_line)
                
                if clean_line.endswith(";"):
                    stmt = " ".join(current_stmt).strip()
                    current_stmt = []
                    
                    if stmt.upper().startswith("COPY"):
                        in_copy = True
                        copy_stmt = stmt
                    elif stmt.upper().startswith("CREATE TABLE"):
                        yield "ddl", stmt
                    elif stmt.upper().startswith("INSERT INTO"):
                        yield "dml", stmt
                    elif stmt.upper().startswith("CREATE TYPE"):
                        yield "ddl", stmt

def transpile_to_duckdb(sql: str, read_dialect: str) -> str:
    """Uses sqlglot to transpile SQL to DuckDB dialect."""
    try:
        if read_dialect == "mysql":
            sql = re.sub(r"INT\s+NOT\s+NULL\s+AUTO_INCREMENT", "INTEGER PRIMARY KEY", sql, flags=re.IGNORECASE)
            sql = re.sub(r"INT\s+AUTO_INCREMENT", "INTEGER PRIMARY KEY", sql, flags=re.IGNORECASE)
            sql = re.sub(r",\s*PRIMARY\s+KEY\s*\(.*?\)", "", sql, flags=re.IGNORECASE)
            sql = re.sub(r"ENGINE\s*=\s*\w+", "", sql, flags=re.IGNORECASE)
            sql = re.sub(r"CHARACTER SET\s*=\s*\w+", "", sql, flags=re.IGNORECASE)
            sql = re.sub(r"COLLATE\s*=\s*[\w_]+", "", sql, flags=re.IGNORECASE)
        
        if read_dialect == "postgres":
            sql = re.sub(r"\bSERIAL\s+PRIMARY\s+KEY\b", "INTEGER PRIMARY KEY", sql, flags=re.IGNORECASE)
            sql = re.sub(r"\bSERIAL\b", "INTEGER", sql, flags=re.IGNORECASE)

        transpiled = transpile(sql, read=read_dialect, write="duckdb")[0]
        return transpiled
    except Exception as e:
        print(f"Warning: Failed to transpile statement: {e}")
        return sql
