import duckdb
import os
import re


class SqlDumpEngine:
    def __init__(self, db_path: str = ":memory:"):
        self.conn = duckdb.connect(db_path)

    def load_dump(self, dump_path: str, dialect: str = "mysql"):
        """Loads a SQL dump into the DuckDB instance."""
        if not os.path.exists(dump_path):
            raise FileNotFoundError(f"Dump file not found: {dump_path}")

        from .parsers import MySQLParser, PostgresParser, transpile_to_duckdb

        if dialect == "mysql":
            parser = MySQLParser()
        elif dialect == "postgres":
            parser = PostgresParser()
        else:
            raise NotImplementedError(f"Dialect {dialect} not supported yet.")

        for stmt_type, data in parser.parse(dump_path):
            if stmt_type == "copy":
                copy_stmt, copy_data_str = data
                # DuckDB doesn't support the interactive COPY FROM STDIN format directly
                # as a single statement. We'll shim it by writing to a temp file or
                # using the read_csv function.
                table_match = re.search(r"COPY\s+(\w+)", copy_stmt, re.I)
                if table_match:
                    table_name = table_match.group(1)
                    # Simple approach: save copy data to a temp file and use DuckDB's COPY
                    import tempfile
                    with tempfile.NamedTemporaryFile(mode='w', delete=False) as tmp:
                        tmp.write(copy_data_str)
                        tmp_path = tmp.name

                    try:
                        self.conn.execute(f"COPY {table_name} FROM '{tmp_path}' (DELIMITER '\t', NULL '\\N')")
                    finally:
                        if os.path.exists(tmp_path):
                            os.remove(tmp_path)
                continue

            sql = data
            duckdb_sql = transpile_to_duckdb(sql, read_dialect=dialect)

            try:
                # If it's a CREATE TABLE with an auto-incrementing column, we might need to shim it
                if "PRIMARY KEY" in duckdb_sql.upper() and stmt_type == "ddl":
                    # Extract table name to create a sequence
                    match = re.search(r"CREATE\s+TABLE\s+(\w+)", duckdb_sql, re.I)
                    if match:
                        table_name = match.group(1)
                        seq_name = f"seq_{table_name}_id"
                        try:
                            self.conn.execute(f"CREATE SEQUENCE IF NOT EXISTS {seq_name}")
                            duckdb_sql = re.sub(
                                r"INT\s+PRIMARY\s+KEY|INTEGER\s+PRIMARY\s+KEY",
                                f"INTEGER PRIMARY KEY DEFAULT nextval('{seq_name}')",
                                duckdb_sql,
                                flags=re.I
                            )
                        except:
                            pass

                self.conn.execute(duckdb_sql)
            except Exception as e:
                print(f"Error executing statement: {e}")
                print(f"Statement: {duckdb_sql[:100]}...")

    def query(self, sql_query: str):
        """Executes a query and returns a DuckDB result object."""
        return self.conn.execute(sql_query)

    def fetch_df(self, sql_query: str):
        """Executes a query and returns a pandas DataFrame."""
        return self.query(sql_query).df()

    def fetch_all(self, sql_query: str):
        """Executes a query and returns a list of tuples."""
        return self.query(sql_query).fetchall()
