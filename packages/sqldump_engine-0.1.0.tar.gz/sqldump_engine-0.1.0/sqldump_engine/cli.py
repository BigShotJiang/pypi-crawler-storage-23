import click
from rich.console import Console
from rich.table import Table
from .core import SqlDumpEngine

console = Console()

@click.group()
def main():
    """SQL Dump Query Engine - Query SQL dumps without a server."""
    pass

@main.command()
@click.option("--dump", required=True, type=click.Path(exists=True), help="Path to the SQL dump file.")
@click.option("--dialect", default="mysql", type=click.Choice(["mysql", "postgres"]), help="SQL dialect of the dump.")
@click.argument("query")
def query(dump, dialect, query):
    """Execute a SQL query against a dump file."""
    try:
        engine = SqlDumpEngine()
        console.print(f"[yellow]Loading {dialect} dump from {dump}...[/yellow]")
        engine.load_dump(dump, dialect=dialect)
        
        results = engine.fetch_df(query)
        
        if results.empty:
            console.print("[blue]No results found.[/blue]")
            return

        table = Table(show_header=True, header_style="bold magenta")
        for col in results.columns:
            table.add_column(str(col))
        
        for _, row in results.iterrows():
            table.add_row(*[str(val) for val in row])
        
        console.print(table)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")

if __name__ == "__main__":
    main()
