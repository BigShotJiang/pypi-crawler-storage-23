from sqldump_engine import SqlDumpEngine
import os

def test_postgres_loading():
    engine = SqlDumpEngine()
    dump_path = os.path.join(os.path.dirname(__file__), "sample_postgres.sql")
    
    print(f"Loading dump: {dump_path}")
    engine.load_dump(dump_path, dialect="postgres")
    
    # Query users
    users_df = engine.fetch_df("SELECT * FROM users")
    print("\nUsers Table (from COPY):")
    print(users_df)
    assert len(users_df) == 2
    assert users_df.iloc[0]['username'] == 'alice'

    # Query posts
    posts_df = engine.fetch_df("SELECT * FROM posts")
    print("\nPosts Table (from INSERT):")
    print(posts_df)
    assert len(posts_df) == 2

if __name__ == "__main__":
    try:
        test_postgres_loading()
        print("\nTest Passed!")
    except Exception as e:
        print(f"\nTest Failed: {e}")
        import traceback
        traceback.print_exc()
