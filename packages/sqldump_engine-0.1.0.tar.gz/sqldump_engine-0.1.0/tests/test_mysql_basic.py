from sqldump_engine import SqlDumpEngine
import os

def test_mysql_loading():
    engine = SqlDumpEngine()
    dump_path = os.path.join(os.path.dirname(__file__), "sample_mysql.sql")
    
    print(f"Loading dump: {dump_path}")
    engine.load_dump(dump_path, dialect="mysql")
    
    # Query users
    users_df = engine.fetch_df("SELECT * FROM users")
    print("\nUsers Table:")
    print(users_df)
    assert len(users_df) == 2
    assert users_df.iloc[0]['username'] == 'alice'

    # Query posts with join
    joined_df = engine.fetch_df("""
        SELECT u.username, p.title 
        FROM users u 
        JOIN posts p ON u.id = p.user_id
    """)
    print("\nJoined Table:")
    print(joined_df)
    assert len(joined_df) == 3

if __name__ == "__main__":
    try:
        test_mysql_loading()
        print("\nTest Passed!")
    except Exception as e:
        print(f"\nTest Failed: {e}")
        import traceback
        traceback.print_exc()
