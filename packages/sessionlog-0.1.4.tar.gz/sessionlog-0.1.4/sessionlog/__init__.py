"""sessionlog — real-time ingestion for AI coding agent sessions."""

__version__ = "0.1.3"
