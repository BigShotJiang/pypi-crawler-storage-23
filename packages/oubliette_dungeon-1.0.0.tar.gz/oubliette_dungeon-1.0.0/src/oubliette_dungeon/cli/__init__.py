"""oubliette_dungeon.cli - Command-line interface."""
