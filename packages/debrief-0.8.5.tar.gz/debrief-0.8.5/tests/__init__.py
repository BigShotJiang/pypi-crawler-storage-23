"""Tests for the debrief package."""
