"""ATG Python SDK unit tests."""

import json
import time
import unittest
from http.server import HTTPServer, BaseHTTPRequestHandler
from threading import Thread
from unittest.mock import patch

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from ats_sdk import ATSClient, ATSError, CheckResult, QuotaInfo


class MockHandler(BaseHTTPRequestHandler):
    """HTTP handler that can be configured per test."""
    response_queue = []
    request_log = []

    def log_message(self, format, *args):
        pass  # suppress log output

    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode() if content_length else ''
        self.__class__.request_log.append({
            'method': 'POST', 'path': self.path, 'body': body, 'headers': dict(self.headers),
        })

        if self.path == '/api/v1/handshake':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({'hmac_secret': 'test-secret-key'}).encode())
            return

        self._handle_response()

    def do_GET(self):
        self.__class__.request_log.append({
            'method': 'GET', 'path': self.path, 'body': '', 'headers': dict(self.headers),
        })
        self._handle_response()

    def _handle_response(self):
        if self.__class__.response_queue:
            resp = self.__class__.response_queue.pop(0)
        else:
            resp = {'status': 200, 'body': {}}
        self.send_response(resp['status'])
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(resp['body']).encode())


class ATGTestCase(unittest.TestCase):
    """Base test case with HTTP server setup."""

    @classmethod
    def setUpClass(cls):
        cls.server = HTTPServer(('127.0.0.1', 0), MockHandler)
        cls.port = cls.server.server_address[1]
        cls.base_url = f'http://localhost:{cls.port}'
        cls.thread = Thread(target=cls.server.serve_forever)
        cls.thread.daemon = True
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def setUp(self):
        MockHandler.response_queue = []
        MockHandler.request_log = []

    def _client(self, max_retries=3, retry_delay=0.01):
        return ATSClient(
            api_key='ats_sk_test123',
            base_url=self.base_url,
            timeout=5,
            max_retries=max_retries,
            retry_delay=retry_delay,
        )


class TestCheckAllowed(ATGTestCase):
    def test_check_returns_allowed(self):
        MockHandler.response_queue = [
            {'status': 200, 'body': {
                'status': 'ALLOWED', 'reason': 'all rules passed',
                'rules_evaluated': 5, 'latency_ms': 1.2,
                'audit_hash': 'abc123', 'request_id': 'req-001',
                'timestamp': '2026-01-01T00:00:00Z',
            }},
        ]
        client = self._client()
        result = client.check(agent_id='bot-1', action='TRANSFER', amount=100.0)
        self.assertIsInstance(result, CheckResult)
        self.assertTrue(result.allowed)
        self.assertEqual(result.status, 'ALLOWED')
        self.assertEqual(result.rules_evaluated, 5)
        self.assertEqual(result.audit_hash, 'abc123')

        # Verify HMAC headers were sent (Python's http.server title-cases headers)
        check_req = [r for r in MockHandler.request_log if r['path'] == '/check'][0]
        headers_lower = {k.lower(): v for k, v in check_req['headers'].items()}
        self.assertIn('x-api-key', headers_lower)
        self.assertIn('x-ats-timestamp', headers_lower)
        self.assertIn('x-ats-signature', headers_lower)


class TestCheckBlocked(ATGTestCase):
    def test_check_returns_blocked(self):
        MockHandler.response_queue = [
            {'status': 200, 'body': {'status': 'BLOCKED', 'reason': 'rate limit exceeded'}},
        ]
        client = self._client()
        result = client.check(agent_id='bot-1', action='TRANSFER', amount=999999.0)
        self.assertFalse(result.allowed)
        self.assertEqual(result.status, 'BLOCKED')


class TestRetryOn503(ATGTestCase):
    def test_retries_on_503_then_succeeds(self):
        MockHandler.response_queue = [
            {'status': 503, 'body': {'error': 'unavailable', 'message': 'service unavailable'}},
            {'status': 503, 'body': {'error': 'unavailable', 'message': 'service unavailable'}},
            {'status': 200, 'body': {'status': 'ALLOWED'}},
        ]
        client = self._client(retry_delay=0.01)
        result = client.check(agent_id='bot-1', action='TRANSFER', amount=50.0)
        self.assertTrue(result.allowed)
        check_reqs = [r for r in MockHandler.request_log if r['path'] == '/check']
        self.assertEqual(len(check_reqs), 3)


class TestMaxRetries(ATGTestCase):
    def test_max_retries_exhausted(self):
        MockHandler.response_queue = [
            {'status': 500, 'body': {'error': 'internal', 'message': 'server error'}},
            {'status': 500, 'body': {'error': 'internal', 'message': 'server error'}},
            {'status': 500, 'body': {'error': 'internal', 'message': 'server error'}},
        ]
        client = self._client(max_retries=2, retry_delay=0.01)
        with self.assertRaises(ATSError) as ctx:
            client.check(agent_id='bot-1', action='TRANSFER', amount=50.0)
        self.assertEqual(ctx.exception.status_code, 500)
        # max_retries=2 → 3 total attempts (1 initial + 2 retries)
        check_reqs = [r for r in MockHandler.request_log if r['path'] == '/check']
        self.assertEqual(len(check_reqs), 3)


class TestNoRetryOn400(ATGTestCase):
    def test_no_retry_on_client_error(self):
        MockHandler.response_queue = [
            {'status': 400, 'body': {'error': 'bad_request', 'message': 'invalid input'}},
        ]
        client = self._client(retry_delay=0.01)
        with self.assertRaises(ATSError):
            client.check(agent_id='bot-1', action='TRANSFER', amount=-1.0)
        check_reqs = [r for r in MockHandler.request_log if r['path'] == '/check']
        self.assertEqual(len(check_reqs), 1)


class TestRetryOn429(ATGTestCase):
    def test_retries_on_rate_limit(self):
        MockHandler.response_queue = [
            {'status': 429, 'body': {'error': 'rate_limited', 'message': 'too many requests'}},
            {'status': 200, 'body': {'status': 'ALLOWED'}},
        ]
        client = self._client(retry_delay=0.01)
        result = client.check(agent_id='bot-1', action='TRANSFER', amount=50.0)
        self.assertTrue(result.allowed)


class TestGetQuota(ATGTestCase):
    def test_get_quota(self):
        MockHandler.response_queue = [
            {'status': 200, 'body': {
                'used': 42, 'limit': 100000, 'remaining': 99958,
                'usage_percent': 0.042, 'month': '2026-02', 'tier': 'PRO',
            }},
        ]
        client = self._client()
        info = client.get_quota('bot-1')
        self.assertIsInstance(info, QuotaInfo)
        self.assertEqual(info.tier, 'PRO')
        self.assertEqual(info.used, 42)
        self.assertEqual(info.remaining, 99958)


class TestVerifyChain(ATGTestCase):
    def test_verify_chain(self):
        MockHandler.response_queue = [
            {'status': 200, 'body': {
                'chain_valid': True, 'entries_verified': 150,
                'genesis_hash': 'genesis123', 'latest_hash': 'latest456',
                'verified_at': '2026-02-25T12:00:00Z',
            }},
        ]
        client = self._client()
        result = client.verify_chain('2026-01-01', '2026-02-01')
        self.assertTrue(result['chain_valid'])
        self.assertEqual(result['entries_verified'], 150)


class TestInvalidAPIKey(unittest.TestCase):
    def test_invalid_api_key(self):
        with self.assertRaises(ATSError):
            ATSClient(api_key='invalid_key', auto_handshake=False)


if __name__ == '__main__':
    unittest.main()
