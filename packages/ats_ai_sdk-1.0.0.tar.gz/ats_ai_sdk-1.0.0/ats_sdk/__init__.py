"""ATS Python SDK — Agent Transfer Shield client library.

Usage:
    from ats_sdk import ATSClient

    client = ATSClient(api_key="ats_sk_...")
    result = client.check(agent_id="bot-1", action="TRANSFER", amount=500.0)
    if result.allowed:
        execute_transfer()
    else:
        log_blocked(result.reason)
"""

import hashlib
import hmac
import json
import ssl
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Optional
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError


__version__ = "1.2.0"

DEFAULT_BASE_URL = "https://ats-ai.ch"
DEFAULT_TIMEOUT = 5  # seconds
DEFAULT_MAX_RETRIES = 3
DEFAULT_RETRY_DELAY = 0.5  # seconds

# C-FE-02 FIX: Explicit TLS context with certificate verification enabled.
# Prevents MITM attacks even if system CA bundle is misconfigured or absent.
_TLS_CONTEXT = ssl.create_default_context()
_TLS_CONTEXT.check_hostname = True
_TLS_CONTEXT.verify_mode = ssl.CERT_REQUIRED
_TLS_CONTEXT.minimum_version = ssl.TLSVersion.TLSv1_2


@dataclass
class CheckResult:
    """Result of a transaction compliance check."""
    allowed: bool
    status: str
    reason: str
    rules_evaluated: int
    latency_ms: float
    audit_hash: str
    request_id: str
    timestamp: str
    raw: Dict[str, Any]


@dataclass
class QuotaInfo:
    """Current quota usage."""
    used: int
    limit: int
    remaining: int
    usage_percent: float
    month: str
    tier: str


class ATSError(Exception):
    """Base exception for ATG SDK errors."""
    def __init__(self, message: str, status_code: int = 0, error_code: str = ""):
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code


class ATSClient:
    """ATS API client with HMAC authentication.

    Args:
        api_key: Your ATS API key (ats_sk_...).
        base_url: API base URL (default: https://ats-ai.ch).
        timeout: Request timeout in seconds (default: 5).
        auto_handshake: Automatically perform HMAC handshake (default: True).
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        auto_handshake: bool = True,
        max_retries: int = DEFAULT_MAX_RETRIES,
        retry_delay: float = DEFAULT_RETRY_DELAY,
    ):
        if not api_key or not api_key.startswith("ats_"):
            raise ATSError("Invalid API key format. Must start with 'ats_'.")
        # C-FE-02 FIX: Enforce HTTPS for all API communication
        if not base_url.startswith("https://") and not base_url.startswith("http://localhost"):
            raise ATSError("base_url must use HTTPS (except localhost for development).")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self._hmac_secret: Optional[str] = None
        self._hmac_expires: float = 0

        if auto_handshake:
            self.handshake()

    def handshake(self) -> None:
        """Exchange API key for HMAC signing secret."""
        data = self._request("POST", "/api/v1/handshake", {"api_key": self.api_key}, auth=False)
        self._hmac_secret = data["hmac_secret"]
        self._hmac_expires = time.time() + 3600 * 24 * 7  # 7 days default

    def check(
        self,
        agent_id: str,
        action: str,
        amount: float,
        currency: str = "CHF",
        recipient: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> CheckResult:
        """Check a transaction for compliance.

        Args:
            agent_id: Unique identifier for the AI agent.
            action: Transaction type (TRANSFER, PAYMENT, etc.).
            amount: Transaction amount.
            currency: Currency code (default: CHF).
            recipient: Recipient identifier (IBAN, account, etc.).
            metadata: Additional key-value pairs for audit context.

        Returns:
            CheckResult with allowed/blocked status and audit hash.
        """
        self._ensure_hmac()
        payload = {
            "agent_id": agent_id,
            "action": action,
            "amount": amount,
            "currency": currency,
        }
        if recipient:
            payload["recipient"] = recipient
        if metadata:
            payload["metadata"] = metadata

        data = self._retry_request("POST", "/check", payload)
        return CheckResult(
            allowed=data.get("status") == "ALLOWED",
            status=data.get("status", "UNKNOWN"),
            reason=data.get("reason", ""),
            rules_evaluated=data.get("rules_evaluated", 0),
            latency_ms=data.get("latency_ms", 0.0),
            audit_hash=data.get("audit_hash", ""),
            request_id=data.get("request_id", ""),
            timestamp=data.get("timestamp", ""),
            raw=data,
        )

    def get_quota(self, agent_id: str = "default") -> QuotaInfo:
        """Get current quota usage."""
        self._ensure_hmac()
        data = self._retry_request("GET", f"/api/v1/dashboard/quota?agent_id={agent_id}")
        return QuotaInfo(
            used=data.get("used", 0),
            limit=data.get("limit", 0),
            remaining=data.get("remaining", 0),
            usage_percent=data.get("usage_percent", 0.0),
            month=data.get("month", ""),
            tier=data.get("tier", "FREE"),
        )

    def get_stats(self) -> Dict[str, Any]:
        """Get dashboard statistics."""
        self._ensure_hmac()
        return self._retry_request("GET", "/api/v1/dashboard/stats")

    def verify_chain(self, from_date: str, to_date: str) -> Dict[str, Any]:
        """Verify audit hash chain integrity.

        Args:
            from_date: Start date (YYYY-MM-DD).
            to_date: End date (YYYY-MM-DD).

        Returns:
            Dict with chain_valid, entries_verified, genesis_hash, latest_hash, etc.
        """
        self._ensure_hmac()
        return self._retry_request("GET", f"/api/v1/report/verify-chain?from={from_date}&to={to_date}")

    def _retry_request(self, method: str, path: str, body: Optional[dict] = None, auth: bool = True) -> dict:
        """Execute request with exponential backoff retry for 5xx/429 errors."""
        import random
        last_err = None
        for attempt in range(self.max_retries + 1):
            try:
                return self._request(method, path, body, auth)
            except ATSError as e:
                last_err = e
                if 0 < e.status_code < 500 and e.status_code != 429:
                    raise
                if attempt < self.max_retries:
                    jitter = 0.75 + random.random() * 0.5
                    delay = min(self.retry_delay * (2 ** attempt) * jitter, 10.0)
                    time.sleep(delay)
            except Exception as e:
                last_err = e
                if attempt < self.max_retries:
                    jitter = 0.75 + random.random() * 0.5
                    delay = min(self.retry_delay * (2 ** attempt) * jitter, 10.0)
                    time.sleep(delay)
        raise last_err

    # --- Internal ---

    def _ensure_hmac(self):
        if not self._hmac_secret or time.time() > self._hmac_expires:
            self.handshake()

    # K-SDK-04 FIX: Sign with timestamp:body and return separate timestamp + signature
    def _sign(self, body: str) -> tuple:
        ts = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
        message = f"{ts}:{body}"
        sig = hmac.new(
            self._hmac_secret.encode(),
            message.encode(),
            hashlib.sha256,
        ).hexdigest()
        return ts, sig

    def _request(self, method: str, path: str, body: Optional[dict] = None, auth: bool = True) -> dict:
        url = f"{self.base_url}{path}"
        data = json.dumps(body).encode() if body else None

        headers = {
            "Content-Type": "application/json",
            "User-Agent": f"ats-python/{__version__}",
            "Accept": "application/json",
        }

        # K-SDK-04 FIX: Send 3 separate headers instead of Authorization header
        if auth and self._hmac_secret:
            ts, sig = self._sign(data.decode() if data else "")
            headers["X-API-Key"] = self.api_key
            headers["X-ATS-Timestamp"] = ts
            headers["X-ATS-Signature"] = sig
        elif not auth:
            headers["X-API-Key"] = self.api_key

        req = Request(url, data=data, headers=headers, method=method)

        MAX_RESPONSE_SIZE = 1 << 20  # 1MB
        try:
            # C-FE-02 FIX: Pass explicit TLS context for certificate verification
            with urlopen(req, timeout=self.timeout, context=_TLS_CONTEXT) as resp:
                data = resp.read(MAX_RESPONSE_SIZE + 1)
                if len(data) > MAX_RESPONSE_SIZE:
                    raise ATSError("Response too large", status_code=resp.status)
                return json.loads(data)
        except HTTPError as e:
            status_code = e.code
            body_text = e.read().decode() if e.fp else ""
            try:
                err = json.loads(body_text)
                raise ATSError(
                    err.get("message", err.get("error", str(e))),
                    status_code=status_code,
                    error_code=err.get("error", ""),
                )
            except ATSError:
                raise
            except json.JSONDecodeError:
                raise ATSError(body_text or str(e), status_code=status_code)
        except URLError as e:
            raise ATSError(f"Connection failed: {e.reason}") from e
