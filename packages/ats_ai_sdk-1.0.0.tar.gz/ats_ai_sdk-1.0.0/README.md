# ats-ai-sdk — ATS SDK for Python

Official Python client for [ATS (Agent Transfer Shield)](https://ats-ai.ch) — compliance and audit trail enforcement for AI agent financial transactions.

## Installation

```bash
pip install ats-ai-sdk
```

## Quick Start

```python
from ats_sdk import ATSClient

client = ATSClient(api_key="ats_sk_your_key_here")

result = client.check(
    agent_id="trading-bot-01",
    action="TRANSFER",
    amount=1500.00,
    currency="CHF",
)

print(result.status)  # "ALLOWED" or "BLOCKED"
print(result.reason)
```

## Requirements

- Python 3.9+
- ATS API key (get one at [ats-ai.ch/onboarding](https://ats-ai.ch/onboarding))

## License

MIT — see [LICENSE](LICENSE)
