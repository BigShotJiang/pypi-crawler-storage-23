The ``mesh`` folder contains configuration files for the default priors assumed for ``mesh`` objects.

These model components reconstruct a galaxy's emission using a rectangular grid, Delaunay triangulation or Voronoi mesh.