class LightProfileOperated:
    pass
