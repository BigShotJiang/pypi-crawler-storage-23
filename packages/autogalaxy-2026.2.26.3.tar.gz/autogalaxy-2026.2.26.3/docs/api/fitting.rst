=======
Fitting
=======

Fitting
-------

For fitting a model consisting of one or more galaxies to a dataset.

.. currentmodule:: autogalaxy

.. autosummary::
   :toctree: _autosummary
   :template: custom-class-template.rst
   :recursive:

   FitImaging
   FitInterferometer