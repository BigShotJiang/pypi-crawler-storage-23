# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import SecuredLinkExtractor

class HDPlayerSystem(SecuredLinkExtractor):
    name     = "HDPlayerSystem"
    main_url = "https://hdplayersystem.com"
