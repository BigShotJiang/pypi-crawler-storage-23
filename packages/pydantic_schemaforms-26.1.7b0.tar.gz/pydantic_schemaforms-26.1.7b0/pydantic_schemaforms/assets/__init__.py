"""Packaged HTML/CSS/JS assets.

This package is the canonical place for vendored third-party assets and any built-in
front-end helpers required by pydantic-schemaforms.

Design rule: default rendering must not depend on external CDNs.
"""
