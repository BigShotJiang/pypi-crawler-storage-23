from documente_shared.application.payloads import camel_to_snake_key, camel_to_snake


def test_camel_to_snake_simple():
    assert camel_to_snake_key("firstName") == "first_name"
    assert camel_to_snake_key("lastName") == "last_name"
    assert camel_to_snake_key("userID") == "user_id"
    assert camel_to_snake_key("HTMLParser") == "html_parser"

def test_camel_to_snake_flat_dict():
    data = {"firstName": "Juan", "lastName": "Perez"}
    expected = {"first_name": "Juan", "last_name": "Perez"}
    assert camel_to_snake(data) == expected

def test_camel_to_snake_nested_dict():
    data = {
        "userName": "juan123",
        "userProfile": {
            "phoneNumber": "123456",
            "addressLine": "Street 1"
        }
    }
    expected = {
        "user_name": "juan123",
        "user_profile": {
            "phone_number": "123456",
            "address_line": "Street 1"
        }
    }
    assert camel_to_snake(data) == expected

def test_camel_to_snake_list_of_dicts():
    data = [
        {"userName": "juan"},
        {"userName": "maria"}
    ]
    expected = [
        {"user_name": "juan"},
        {"user_name": "maria"}
    ]
    assert camel_to_snake(data) == expected