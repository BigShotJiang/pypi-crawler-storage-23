from unittest.mock import Mock

from expects import expect, equal, be_a

from documente_shared.domain.entities.processing_record import ProcessingRecord
from documente_shared.infrastructure.repositories.http_processing_record import (
    HttpProcessingRecordRepository,
)


def test_persist_posts_processing_record():
    # Arrange
    instance = ProcessingRecord(
        document_digest="0e4b13a1e...18aad2141b8",
        tenant_slug="BDP",
        document_type="PROCESSING_CASE_ITEM",
        processed_pages=20,
    )
    response = Mock()
    response.status_code = 201
    response.json.return_value = {
        "data": {
            "documentDigest": "0e4b13a1e...18aad2141b8",
            "tenantSlug": "BDP",
            "documentType": "PROCESSING_CASE_ITEM",
            "processedPages": 20,
        }
    }
    session = Mock()
    session.headers = {}
    session.post.return_value = response

    repository = HttpProcessingRecordRepository(
        api_url="https://api.local",
        api_key="test-key",
        session=session,
    )

    # Act
    result = repository.persist(instance)

    # Assert
    session.post.assert_called_once_with(
        url="https://api.local/v1/processing/records/",
        json=instance.to_payload,
    )
    expect(result).to(be_a(ProcessingRecord))
    expect(result.document_digest).to(equal("0e4b13a1e...18aad2141b8"))
    expect(result.tenant_slug).to(equal("BDP"))
    expect(result.document_type).to(equal("PROCESSING_CASE_ITEM"))
    expect(result.processed_pages).to(equal(20))
