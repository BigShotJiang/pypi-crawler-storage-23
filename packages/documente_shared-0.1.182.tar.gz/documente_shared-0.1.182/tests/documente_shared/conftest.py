import base64
import pytest

from documente_shared.domain.entities.in_memory_document import InMemoryDocument


@pytest.fixture
def document_base64() -> str:
    return (
        "JVBERi0xLjcKJYGBgYEKCjYgMCBvYmoKPDwKL0ZpbHRlciAvRmxhdGVEZWNvZGUKL0xlbmd0aCAzOAo+PgpzdHJlYW0KeJwr5DJQMFAwtTTVMz"
        "FRsDAx1LM0UihK5QrX4srjCuQCAF0PBgoKZW5kc3RyZWFtCmVuZG9iagoKNyAwIG9iago8PAovVHlwZSAvWE9iamVjdAovU3VidHlwZSAvRm9y"
        "bQovRm9ybVR5cGUgMQovQkJveCBbIDAgMCA1OTUuNDQgODQxLjkyIF0KL01hdHJpeCBbIDEgMCAwIDEgMCAwIF0KL1Jlc291cmNlcyA8PAovRm"
        "9udCA8PAo+PgovWE9iamVjdCA8PAo+PgovRXh0R1N0YXRlIDw8Cj4+Cj4+Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCi9MZW5ndGggNDIKPj4Kc3Ry"
        "ZWFtCnicK+TiKuQyUDBQMLU01TMxUbAwMdSzNFIoSuUK1+LK4wrkAiEAiY4G/gplbmRzdHJlYW0KZW5kb2JqCgo5IDAgb2JqCjw8Ci9GaWx0ZX"
        "IgL0ZsYXRlRGVjb2RlCi9MZW5ndGggMTkzCj4+CnN0cmVhbQp4nKXNwYrCQAwG4HueIueFjunMdJLA4kEURPZQdV5gth0Li1VUfH/r7mGFehET"
        "8kMI4TtBiTT0Xzb9a+tk0X/nts1t3e7q1OWCScULsSjOj7AGwtjACWYR6Pfn3MFkm65NXqbDNh0uq7rY5O66T+dC2dsgtgqCpcO4g3t+PYhigx"
        "Gn/4Wxh08iKoexU4w/ED9gEV9j7fAsVKmEp6wV43xAVjFe3dh279jKFfmglvipXQUzHJGZTOl5bPuRfQMrk2osCmVuZHN0cmVhbQplbmRvYmoK"
        "CjEwIDAgb2JqCjw8Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCi9MZW5ndGggNTQ5Cj4+CnN0cmVhbQp4nCspKk1lYGNwYGBiUMhITUxhgIAcIDbLAA"
        "pA+YuAWCUnPxnGPwbEErmJFQVQ/j0gVkjPqUyD8v8xMDA2ZOSWVEC4THVAQoSBEUgyMrItUfT7HM9v85VBm/kFSPbq3286IPqa5qbnf8R+v+Au"
        "YBcAcjmAbgLrYGBg6fh3gIGBe8cfsf+e3AVgUWTACqUjgHgHED8BarIAuQCskpWRmUET4gywaSAxB7jOlP8dzC3MBQzMwFDgZOBh4GdgEBdUFO"
        "RkVORkFIQQKcwK/woY7f62MMYByRSmmn+H/i1itKtgfvFHgkmWceY/u3/pzEZ/ljLOZDz05xzjTLBNVv8/Mz5m0mUQZZADmqikZmpiZm6irMSu"
        "bmZsJCYqqKyuzKZuZG7KxygqInbTLXL++gLfMJX89IQYbw7mOBuXwNYCU94gj4h4kU4re/eyzH+bHP08PWYIOJnraIN9AfQr4yumuwzcDAzGps"
        "aCyqZm5saCxqIRi5uibd0m+zApWwkq/833Absl5v9nJnNmGQYBBimgl5XUldmVgUrZwS4RATrDzBTkMkExRu8Ab2YOz2jmiKCMwq5C1/B+pwBH"
        "XlcLZplbSb5T69vn+5Qmn/T+99gSaL8x0H8Pwf4DmgjynbGROLuashIb0D/GRubibIxG+RNm5oZ56puZeyXEertaq3vzzmhpnu1ga1gaG1dkZu"
        "vKwACM/xQmEwYrJm2GCKYshhjGvwzGAG5IjV0KZW5kc3RyZWFtCmVuZG9iagoKMTMgMCBvYmoKPDwKL0ZpbHRlciAvRmxhdGVEZWNvZGUKL0xl"
        "bmd0aCAyMzkKPj4Kc3RyZWFtCnicXVC7asQwEOz1FVteikNn+0hlBOHSuMiDOPkAWVo5glgSa7nw30cPc4EsSGJ2dlbD8NvwPDgbgb+TVyNGMN"
        "ZpwtVvpBAmnK1jTQvaqnigcqtFBsaTeNzXiMvgjIe+ZwD8I9FrpB1OT9pP+JB7b6SRrJvh9HUbS2fcQvjBBV2ECxMCNJq07kWGV7kg8CI9Dzrx"
        "Nu7npPqb+NwDQltwUy0pr3ENUiFJNyPrL6lEb1IJhk7/o69VNBn1LakMNwLS89iIgtqCugN1lWsrulbUlb3HhvxDTuPuXm1EyXiJrDjOXq3De6"
        "rBh6zK5xd7hHg3CmVuZHN0cmVhbQplbmRvYmoKCjE0IDAgb2JqCjw8Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCi9MZW5ndGggMjQ0Cj4+CnN0cmVh"
        "bQp4nCspKk1lYGNwYGBiUMhITUxhgIAcIDbLAApA+YuAWCUnPxnGPwbEHLmJFQVQ/jkgVkjPqUyD8t8BcURGbkkFhMvoBiRYGBhBTAbHdXWGkv"
        "H8Nl8ZtJlfgGSv/v1zCERf09zM90f693PuQnZBkPlAN0F0MLDU/3vEwMC944/0/93chWBRZADjR0DUM5YwaIL5TGA5kJgDVAUrQ8r/DuYW5gIG"
        "ZqCvORl4GPgZGMQFFQU5GRU5GQUhRAqzwr8CRru/LYxxQDKFqebfoX+LGO0qmF/8kWCSZZz5z+5fOrPRn6WMMxkP/TnHOJOBAeiPFADMnkBTCm"
        "VuZHN0cmVhbQplbmRvYmoKCjE3IDAgb2JqCjw8Ci9GaWx0ZXIgL0ZsYXRlRGVjb2RlCi9MZW5ndGggMjE3Cj4+CnN0cmVhbQp4nF1Qy47DIAy8"
        "8xU+toeKtOco0qq95NCHmt0PIGBSpMYghxzy9wsk6kprCWR7ZvAYeW4vLbkI8sFedxjBOjKMk59ZI/Q4OBLHExin41aVW48qCJnE3TJFHFuyHu"
        "paAMhngqfIC+y+jO9xn3t3NsiOBtj9nLvS6eYQ3jgiRahE04BBm567qnBTI4Is0kNrEu7ickiqP8b3EhBOpT6ulrQ3OAWlkRUNKOoqRVPbFI1A"
        "Mv/gahX1Vr8Ui0zY0kzNa31s6Jk5OSi7l9F5qCP8fE/wIavy+QVV1G2fCmVuZHN0cmVhbQplbmRvYmoKCjE4IDAgb2JqCjw8Ci9GaWx0ZXIgL0"
        "ZsYXRlRGVjb2RlCi9MZW5ndGggMTAKPj4Kc3RyZWFtCnicK+QCAADuAHwKZW5kc3RyZWFtCmVuZG9iagoKMTkgMCBvYmoKPDwKL0ZpbHRlciAv"
        "RmxhdGVEZWNvZGUKL0xlbmd0aCAxMAo+PgpzdHJlYW0KeJwL5AIAAK4AXAplbmRzdHJlYW0KZW5kb2JqCgoyMCAwIG9iago8PAovRmlsdGVyIC"
        "9GbGF0ZURlY29kZQovVHlwZSAvT2JqU3RtCi9OIDEwCi9GaXJzdCA2NAovTGVuZ3RoIDc0NAo+PgpzdHJlYW0KeJzVVVFv2jAQfs+vuMf2gcY2"
        "iWNPVSUoZGVTV1TYVq3qgyEuywQOSoxU/v3uElhbFco6qQ8THNi+O/t833dnDgwERBG0IVEQQcwUxCAjDQoSzYHTVyrgAng7kcBj4JLRD3DF23"
        "B6GoTj9dJCODQzWwXh5zyr4Ba9GVzDXRCeFyvngQdnZ8Gj7bnxZl7MgsYJOBlvLYZlka2mtoTTtJ+mjCWMMRmhSJQeSsyYwDWhcIySRBvBtaTN"
        "WLuDurQRiYtSN/raFn0lOos+/qOtTJs9a1vaj6P0m/NEb3Nu2viLfbHosyC8LLKe8RaOeh8EE20KhDPe5urHMaagtMYX/9eF6pjzwu291TM808"
        "L5IBytJr6e0iILwq6pLGkgHBlE9MK4kXHVp2Hr2s5Wc1O2kjgRQdh30yLL3QzCQWadz/26dRGEPVtNrcuM87QFUQopuOHUuPjqcnSyyMmn1Hlj"
        "MLbM759Eo6KYvSEauSOa5GU0xHDieWmpDGp9eG2rYlVOkflkV0dFgz1Z0kkkpBKxpPqs/fcYEokUi7WSBww10iaSWrBkY4gRhzdXk1922kTSX0"
        "xsltlsmN1T/K2EaRUpligNf64Y9h/8x5EnfqALLtDapc1y0y0eMEEMP7GOT7C3qIifaEG56jhX1OmrO4Pztkmm3uayO7c2e8V/XOaL/eoXNCDY"
        "ynyJxdek+YtZ2ANsTOdmVkHU2Hebs1pYRYJ+IwVCC+yGCtskhjPANpZPO242t4Dc6RBJPDVMtqWMh1Zb4OzcLC9sPvu51d5sZjgcebv4RgM6Mc"
        "3nFlstO0jr80GPVkiHUeNsXHwc9C7N8pG4f12B6D1aVxjGwN0XNQFQn1e+XMNRJysmFpvYVZlhvWBdHG23P6Zolsu5XdA1WY3/86TT61Hz8DsV"
        "DEos8YWJ8X3h+MowDXf/ANrOqt2JmtZJDZom0DSBpl8DLeZPQBNKPgeNtAdAi94NtJ13fj/U4kfUbrcY/QbkOzqVCmVuZHN0cmVhbQplbmRvYm"
        "oKCjIxIDAgb2JqCjw8Ci9TaXplIDIyCi9Sb290IDIgMCBSCi9JbmZvIDMgMCBSCi9GaWx0ZXIgL0ZsYXRlRGVjb2RlCi9UeXBlIC9YUmVmCi9M"
        "ZW5ndGggNzkKL1cgWyAxIDIgMiBdCi9JbmRleCBbIDAgMjIgXQo+PgpzdHJlYW0KeJwlybkNgEAQQ1F72FMiIKAdMrpCogFSSOmRCpaxJnmSvw"
        "GMYVgBQWFiEolYAOKMN5OXT3tiFlGZk7eyRWuisx7e2is+p+/OfAM/vKwIHgplbmRzdHJlYW0KZW5kb2JqCgpzdGFydHhyZWYKMzIyMAolJUVP"
        "Rg=="
    )


@pytest.fixture
def document_filename() -> str:
    return "test_document.pdf"


@pytest.fixture
def document_bytes(document_base64: str) -> bytes:
    return base64.b64decode(document_base64)


@pytest.fixture
def in_memory_document(
    document_base64: str,
    document_filename: str,
    document_bytes: bytes,
) -> InMemoryDocument:
    return InMemoryDocument(
        file_path=document_filename,
        file_base64=document_base64,
        file_bytes=document_bytes,
    )