import os
import boto3

from datetime import datetime
from decimal import Decimal
from uuid import uuid4

from documente_shared.domain.entities.document import DocumentProcessing
from documente_shared.domain.entities.in_memory_document import InMemoryDocument
from documente_shared.domain.entities.processing_case import ProcessingCase
from documente_shared.domain.entities.processing_case_item import ProcessingCaseItem
from documente_shared.domain.enums.common import ProcessingStatus
from documente_shared.domain.enums.document import DocumentProcessingStatus, DocumentProcessingCategory
from documente_shared.domain.enums.processing_case import ProcessingCaseType, ProcessingDocumentType
from documente_shared.infrastructure.repositories.dynamo_document import DynamoDocumentProcessingRepository
from documente_shared.infrastructure.repositories.dynamo_processing_case import DynamoProcessingCaseRepository
from documente_shared.infrastructure.repositories.dynamo_processing_case_item import DynamoProcessingCaseItemRepository
from documente_shared.infrastructure.s3_bucket import S3Bucket

from documente_shared.application.exceptions import initialize_sentry, track_exceptions

initialize_sentry(
    dsn=os.getenv("SENTRY_DSN"),
    environment=os.getenv("STAGE", "dev")
)


document_repository = DynamoDocumentProcessingRepository(
    table_name='document-processing-table-dev',
)
case_repository = DynamoProcessingCaseRepository(
    table_name='processing-case-dev',
)
case_item_repository = DynamoProcessingCaseItemRepository(
    table_name='processing-case-item-dev',
)

s3_bucket = S3Bucket(
    bucket_name='documente-assets-bucket-dev',
)

document = DocumentProcessing(
    digest=str(uuid4()),
    status=DocumentProcessingStatus.PENDING,
    file_path='raw-images/CC-standard.tif',
    processed_csv_path='raw-images/CC-standard.csv',
    processed_xlsx_path='raw-images/CC-standard.xlsx',
    category=DocumentProcessingCategory.CIRCULAR,
    processing_time=Decimal(100.0),
    enqueued_at=datetime.now(),
    started_at=datetime.now(),
    failed_at=datetime.now(),
    completed_at=datetime.now(),
)

prcessing_case = ProcessingCase(
    uuid=str(uuid4()),
    name='prcessing_case',
    tenant_slug='tenant_slug',
    status=ProcessingStatus.PENDING,
    case_type=ProcessingCaseType.BCP_MICROCREDITO,
    enqueued_at=datetime.now(),
    started_at=datetime.now(),
    failed_at=datetime.now(),
    completed_at=datetime.now(),
)

prcessing_case_item = ProcessingCaseItem(
    uuid=str(uuid4()),
    case_id=str(uuid4()),
    status=ProcessingStatus.PENDING,
    digest=str(uuid4()),
    name=str(uuid4()),
    document_type=ProcessingDocumentType.NIT,
    document=InMemoryDocument(
        file_path='raw-images/case_item.txt',
        file_bytes=b'file_bytes',
    ),
    started_at=datetime.now(),
    failed_at=datetime.now(),
    completed_at=datetime.now(),
)


def call_repository():
    document.digest = '11002299338844775566'
    document.status = DocumentProcessingStatus.PENDING
    document_repository.persist(document)

    # repository.remove(instance)


def call_case_repository():
    case_repository.persist(prcessing_case)
    case_item_repository.persist(prcessing_case_item)


call_case_repository()


def call_s3_bucket():
    # https://documente-process-bucket-dev.s3.us-east-1.amazonaws.com/raw-images/CC-standard.tif
    file_instance = s3_bucket.get_bytes(document.file_path)
    print(f'file_instance: {file_instance}')
    processed_csv_file = s3_bucket.get_bytes(document.processed_csv_path)
    print(f'processed_csv_file: {processed_csv_file}')


# call_repository()
# call_s3_bucket()

def fetch_instance():
    digest = 'b183b987eb2b314de6ac662a5e5ead71be48b0da5020bdafa7588f4a340b95c1'
    created_instance = document_repository.find(digest=digest)
    existing_file = s3_bucket.get(created_instance.file_key)


def filter_status():
    instances = document_repository.filter(
        statuses=[
            DocumentProcessingStatus.PENDING,
            DocumentProcessingStatus.ENQUEUED,
            DocumentProcessingStatus.PROCESSING,
            DocumentProcessingStatus.IN_REVIEW
        ],
    )
    print(f'instances: {len(instances)}')


# filter_status()


def call_metric():
    cloudwatch = boto3.client('cloudwatch')
    count = 0
    cloudwatch.put_metric_data(
        Namespace='documente-core/dev',
        MetricData=[{
            'MetricName': 'desired-count',
            'Value': count,
            'Unit': 'Count',
        }]
    )
    print(f'Metric sent: {count}')


@track_exceptions
def faulty_function():
    raise RuntimeError("Error desde el decorador en test")

# faulty_function()


def reenqueue():
    documents = document_repository.filter(
        statuses=[DocumentProcessingStatus.FAILED],
    )
    for document in documents:
        document.status = DocumentProcessingStatus.PENDING
        document.failed_reason = None
        document_repository.persist(document)


# reenqueue()