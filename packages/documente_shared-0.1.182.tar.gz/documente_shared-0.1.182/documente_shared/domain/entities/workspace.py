from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field

from documente_shared.application.time_utils import get_datetime_from_data
from documente_shared.domain.entities.document_type import DocumentType
from documente_shared.domain.helpers.values import optional_datetime_str



class Workspace(BaseModel):
    uuid: UUID
    name: str
    tenant_id: UUID | None = Field(default=None)
    tenant_slug: str | None = Field(default=None)
    is_archived: bool = False
    is_main: bool = False
    metadata: dict | None = Field(default_factory=dict)
    created_at: datetime | None = Field(default=None)
    updated_at: datetime | None = Field(default=None)
    document_types: list[DocumentType] | None = Field(default_factory=list)


    @property
    def to_persist_dict(self) -> dict:
        return {
            "tenant_id": self.tenant_id,
            "name": self.name,
            "is_archived": self.is_archived,
            "is_main": self.is_main,
            "metadata": self.metadata or {},
        }

    @property
    def to_dict(self) -> dict:
        return {
            "uuid": str(self.uuid),
            "name": self.name,
            "tenant_id": self.tenant_id,
            "tenant_slug": self.tenant_slug,
            "is_archived": self.is_archived,
            "is_main": self.is_main,
            "metadata": self.metadata,
            "created_at": optional_datetime_str(self.created_at),
            "updated_at": optional_datetime_str(self.updated_at),
            "document_types": [dt.to_dict for dt in self.document_types] if self.document_types else [],
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'Workspace':
        document_types = data.get('document_types', [])
        return cls(
            uuid=data.get('uuid'),
            name=data.get('name'),
            tenant_id=data.get('tenant_id'),
            tenant_slug=data.get('tenant_slug'),
            is_archived=data.get('is_archived', False),
            is_main=data.get('is_main', False),
            metadata=data.get('metadata', {}),
            created_at=get_datetime_from_data(input_datetime=data.get('created_at')),
            updated_at=get_datetime_from_data(input_datetime=data.get('updated_at')),
            document_types=[
                DocumentType.from_dict(dt) 
                for dt in document_types 
            ],   
        )
