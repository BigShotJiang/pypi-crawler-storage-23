from uuid import UUID

from pydantic import Field

from documente_shared.application.query_params import QueryParams
from documente_shared.domain.helpers.dicts import filter_none_values
from documente_shared.domain.helpers.values import optional_str
from documente_shared.domain.pagination.entities import ListFilters


class WorkspaceDocumentPageFilters(ListFilters):
    workspace_document_id: UUID | None = Field(default=None)

    @property
    def to_params(self) -> dict:
        return filter_none_values({
            **super().to_dict,
            "workspace_document_id": optional_str(self.workspace_document_id),
        })

    @classmethod
    def from_params(cls, params: QueryParams) -> "WorkspaceDocumentPageFilters":
        return cls(
            cursor=params.get("cursor", None),
            limit=params.get_int(key="limit", default=None),
            workspace_document_id=params.get_uuid(key="workspace_document_id", default=None),
        )
