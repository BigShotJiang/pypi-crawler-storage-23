"""Framework integrations — import explicitly to activate."""
