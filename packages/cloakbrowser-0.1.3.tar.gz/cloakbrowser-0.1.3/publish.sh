#!/usr/bin/env bash
# Publish cloakbrowser to PyPI
# Usage: ./publish.sh
set -euo pipefail

cd "$(dirname "$0")"

echo "==> Cleaning old builds..."
rm -rf dist/ build/ *.egg-info

echo "==> Building..."
python -m build

echo "==> Uploading to PyPI..."
python -m twine upload dist/* \
  --username __token__ \
  --password "${PYPI_TOKEN:?Set PYPI_TOKEN env var}"

echo "==> Done! Published $(python -c 'from cloakbrowser._version import __version__; print(__version__)')"
