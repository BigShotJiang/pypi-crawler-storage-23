"""Services for objects across the software."""
