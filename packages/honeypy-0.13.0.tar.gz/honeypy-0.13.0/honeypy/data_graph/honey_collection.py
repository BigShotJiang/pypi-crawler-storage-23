"""Collection node for honey files.

This module provides HoneyCollection, a container node that represents a
collection of HoneyFile[T] instances stored under a filesystem location. The
collection is parameterized by the "point" type T exposed by its files.

The collection class is designed to be flexible, and its existence is a semantic
courtesy (it suffices, in fact, that it is a subtype of `HoneyCollection`)
Practically a collection can be represented as a single folder, or a collection of
folders with files findable by helpers in the class as well as the `location` property

The collection is responsible for locating/instantiating HoneyFile children and
can be loaded lazily (via the `load` mechanism on HoneyNode).
"""

from typing import (
    Any,
    Generic,
    LiteralString,
    Mapping,
    TypeVar,
)

from honeypy.data_graph.honey_file import HoneyFile
from honeypy.data_graph.meta.honey_node import HoneyNode
from honeypy.data_graph.meta.node_type import NodeType

F = TypeVar("F", bound=HoneyFile, covariant=True)
M = TypeVar("M", bound=Mapping[str, Any])
L = TypeVar("L", bound=LiteralString)


class HoneyCollection(Generic[L, M, F], HoneyNode[L, M, F]):
    """A collection of HoneyFile nodes."""

    NODE_TYPE = NodeType.COLLECTION
