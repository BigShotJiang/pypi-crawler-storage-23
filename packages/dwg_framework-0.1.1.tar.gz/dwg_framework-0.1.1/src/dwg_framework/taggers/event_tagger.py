from .gen_taggers.gen_tagger import tag_gens
from .lep_taggers import tag_ele_quality, tag_lpte_quality, tag_muon_quality
import numpy as np
import awkward as ak

####################################################################
# functions that take the lepton collections and add useful fields from the tagger functions

def tag_qual(events, is_UL, is_mc=False):
    
    """
    Returns events with new lepton quality fields and combined Leptons collection.
    Set is_mc=True to also tag gen-level information.
    """
    
    if is_mc:
        events = tag_gens(events)

    tagged_electrons = tag_ele_quality(events.Electron, is_UL)
    tagged_low_pt_electrons = tag_lpte_quality(events.LowPtElectron, is_UL)
    tagged_muons = tag_muon_quality(events.Muon)

    events = ak.with_field(events, tagged_electrons, "Electron")
    events = ak.with_field(events, tagged_low_pt_electrons, "LowPtElectron")
    events = ak.with_field(events, tagged_muons, "Muon")

    leptons = ak.concatenate([
        tagged_electrons,
        tagged_low_pt_electrons,
        tagged_muons
    ], axis=1)

    combined_electrons = ak.concatenate([
        tagged_electrons[tagged_electrons.pt >= 7],
        tagged_low_pt_electrons[tagged_low_pt_electrons.pt < 7]
    ], axis=1)

    leptons = ak.with_name(leptons, "PtEtaPhiMCandidate")
    combined_electrons = ak.with_name(combined_electrons, "PtEtaPhiMCandidate")

    events = ak.with_field(events, leptons, "Leptons")
    events = ak.with_field(events, combined_electrons, "combined_Electron")

    return events