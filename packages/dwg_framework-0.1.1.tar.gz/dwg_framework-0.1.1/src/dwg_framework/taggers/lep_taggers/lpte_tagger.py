from .common import global_tight_sip3d
import numpy as np
import awkward as ak

def tag_lpte_quality(lpte, is_UL=False): #use on raw lpte collection

    """
    Add 'isGold', 'isSilver', 'isBronze' boolean field to events.LowPtElectron based on cuts.
    Add 'qual_tag' integer field to events.LowPtElectron, binary numbers
    """
    
    # define variables
    abs_eta   = np.abs(lpte.eta)
    sip3d     = _lpte_sip3d(lpte)
    lpte = ak.with_field(lpte, sip3d, 'sip3d') #literally add our sip3d to lpte array
    abs_dxy   = np.abs(lpte.dxy)
    abs_dz    = np.abs(lpte.dz)
    pt        = lpte.pt
    miniIsoPt = lpte.miniPFRelIso_all * pt

    if is_UL == False:
        central_eta_ID = (
            ((abs_eta >= 0.8) & (abs_eta < 1.442) & (lpte.ID >= 3)) |
            ((abs_eta < 0.8) & (lpte.ID >= 2.3))
        )

        baseline_ID_requirement = 1.5

    if is_UL == True:
        central_eta_ID = (
        ((pt < 4) &
        (((abs_eta >= 0.8) & (abs_eta < 1.442) & (lpte.ID >= 3)) |
        ((abs_eta < 0.8) & (lpte.ID >= 2.6)))) |
        ((pt >= 4) &
        (((abs_eta >= 0.8) & (abs_eta < 1.442) & (lpte.ID >= 3.2)) |
        ((abs_eta < 0.8) & (lpte.ID >= 2.8))))
        )

        baseline_ID_requirement = 2

    

    # --- Baseline selection ---
    baseline_mask = (
        ((pt >= 2) & (pt < 7))
        & (abs_eta < 1.4442)
        & (sip3d < 6)
        & (abs_dxy < 0.05)
        & (abs_dz  < 0.1)
        & (miniIsoPt < (20 + 300/pt))
        & (lpte.convVeto == 1)
        & (lpte.lostHits == 0)
        & (lpte.ID >= baseline_ID_requirement)
    )

    # --- Quality tags ---

    gold_silver_mask = (
        baseline_mask
        & (miniIsoPt <= 4)
        & central_eta_ID
    )
    
    gold_mask = (
        gold_silver_mask
        & (sip3d < global_tight_sip3d)
    )

    silver_mask = (
        gold_silver_mask
        & (sip3d >= global_tight_sip3d)
    )

    bronze_mask = baseline_mask & ~gold_silver_mask

    lpte = ak.with_field(lpte, ~baseline_mask, 'isFail')
    lpte = ak.with_field(lpte, baseline_mask, 'isBaseline')
    lpte = ak.with_field(lpte, gold_mask, 'isGold')
    lpte = ak.with_field(lpte, silver_mask, 'isSilver')
    lpte = ak.with_field(lpte, bronze_mask, 'isBronze')

    
    
    #qual_tag = ak.full_like(lpte.pt, -1, dtype=int)
    #qual_tag = ak.where(lpte.isBronze, 1, qual_tag)
    #qual_tag = ak.where(lpte.isSilver, 10, qual_tag)
    #qual_tag = ak.where(lpte.isGold, 100, qual_tag)
    
    #lpte = ak.with_field(lpte, qual_tag, "qual_tag")



    ### New masks here!!

    tight_ID = (
        baseline_mask
        & central_eta_ID
    )

    tight_SIP3D = (
        baseline_mask
        & (sip3d < global_tight_sip3d)
    )

    tight_ISO = (
        baseline_mask
        
        & (miniIsoPt <= 4)
    )

    lpte = ak.with_field(lpte, tight_ID, 'tight_ID')
    lpte = ak.with_field(lpte, tight_SIP3D, 'tight_SIP3D')
    lpte = ak.with_field(lpte, tight_ISO, 'tight_ISO')

    #qual_tag = ak.where(lpte.tight_ID, 20, qual_tag)
    #qual_tag = ak.where(lpte.tight_SIP3D, 200, qual_tag)
    #qual_tag = ak.where(lpte.tight_ISO, 2000, qual_tag)
    
    #lpte = ak.with_field(lpte, qual_tag, "qual_tag")

    return lpte

def _lpte_sip3d(lpte):
     
    #approximation or rough calculation based on what Suyash did years ago
    #NOT SIP3D by any means, this is a "SIP3D-like" variable we constructed
    
    dxy = lpte.dxy
    dz = lpte.dz
    dxy_err = lpte.dxyErr
    dz_err = lpte.dzErr
    
    sigma_xy = dxy/dxy_err
    sigma_z = dz/dz_err
    
    SIP3D = np.sqrt(sigma_xy**2 + sigma_z**2)
    
    return SIP3D