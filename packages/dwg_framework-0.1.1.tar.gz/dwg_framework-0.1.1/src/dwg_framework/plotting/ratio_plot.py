import matplotlib.pyplot as plt
import mplhep
import numpy as np
import os
from matplotlib.lines import Line2D

def make_1d_ratio_hist(
    hist1,
    hist2,
    title,
    residual_type = "subtraction",
    savefig=False,
    save_name="test",
    plot_directory="plots",
    log_scale=False
):

    fig, axes = plt.subplots(2, 1, figsize=(25, 12), gridspec_kw={'height_ratios': [3, 1]}, sharex=True)

    return axes