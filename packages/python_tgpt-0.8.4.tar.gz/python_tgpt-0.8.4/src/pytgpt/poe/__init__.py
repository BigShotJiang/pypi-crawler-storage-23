from .main import POE
from .main import default_model

__info__ = "Interact with Poe LLM provider"

__all__ = [
    "POE",
    "default_model",
]
