from pytgpt.console import API

API.run()
