from .main import AUTO
from .main import AsyncAUTO

__info__ = "Interact with working tgpt-based providers"

__all__ = ["AUTO", "AsyncAUTO"]
