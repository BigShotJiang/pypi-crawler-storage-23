class AllProvidersFailure(Exception):
    """None of the providers generated response successfully"""

    pass
