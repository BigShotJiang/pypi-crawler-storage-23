from .main import GPT4ALL

__info__ = "Interact with offline models"

__all__ = [
    "GPT4ALL",
]
