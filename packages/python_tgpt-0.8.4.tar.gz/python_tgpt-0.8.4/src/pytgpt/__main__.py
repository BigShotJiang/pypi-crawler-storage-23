from pytgpt.console import main

main()
