"""A simple database API and result mapping library."""

from dinao.__version__ import __version__  # noqa: F401
