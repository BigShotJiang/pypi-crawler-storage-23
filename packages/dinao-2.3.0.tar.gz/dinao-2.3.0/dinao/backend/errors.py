"""Defines common errors raised from database backend code."""


class UnsupportedBackendError(Exception):
    """Raised when an unsupported backend is specified."""

    pass


class ConfigurationError(Exception):
    """Raised when there is a backend configuration connection error."""

    pass


class BackendNotInstalledError(Exception):
    """Raised when a backend engine is not installed."""

    pass


class ConnectionPoolClosed(Exception):
    """Raised when a connection pool is closed."""

    pass


class AsyncPoolRequiredError(Exception):
    """Raised when an async binder is given a sync pool."""

    pass
