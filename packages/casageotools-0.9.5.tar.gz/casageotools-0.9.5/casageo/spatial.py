import argparse
import contextlib
import dataclasses
import math
import os
import sys
from collections.abc import Sequence
from dataclasses import KW_ONLY, dataclass
from datetime import datetime
from types import SimpleNamespace
from typing import Any, cast

from geopandas import GeoDataFrame
from pandas import DataFrame, concat
from shapely import (
    MultiLineString,
    MultiPolygon,
    Point,
)

from casageo.tools import _consts, _util
from casageo.tools._apiclient.new.api.isoline import calculate_isolines
from casageo.tools._apiclient.new.api.routing import calculate_routes
from casageo.tools._apiclient.new.models import (
    Avoid,
    Exclude,
    IsolinesRange,
    Return,
    RouterMode,
    RoutingMode,
    Traffic,
    TrafficMode,
    Units,
)
from casageo.tools._apiclient.new.types import UNSET
from casageo.tools._client import CasaGeoClient
from casageo.tools._errors import CasaGeoError
from casageo.tools._types import CasaGeoResult


def _position_point(data: dict | None) -> Point | None:
    if data is None:
        return None
    try:
        if (elv := data.get("elv")) is not None:
            return Point(data["lng"], data["lat"], elv)
        return Point(data["lng"], data["lat"])
    except KeyError:
        # FIXME: Raise warning here.
        return None


class IsolinesResult(CasaGeoResult):
    """
    Represents the result of a CasaGeoSpatial.isolines() query.
    """

    @staticmethod
    def _geometry(isoline: dict) -> MultiPolygon | None:
        try:
            polygons = isoline["polygons"]
        except KeyError:
            return None

        return MultiPolygon([
            (
                _util.flexpolyline_points(outer),
                [
                    _util.flexpolyline_points(inner)
                    for inner in polygon.get("inner", ())
                ],
            )
            for polygon in polygons
            if (outer := polygon.get("outer")) is not None
        ])

    @staticmethod
    def _range_type(isoline: dict) -> str | None:
        try:
            return isoline["range"]["type"]
        except KeyError:
            return None

    @staticmethod
    def _range_value(isoline: dict) -> float | None:
        try:
            value = float(isoline["range"]["value"])
        except KeyError:
            return None

        # We interpret range_values as minutes, while HERE interprets them as seconds.
        if IsolinesResult._range_type(isoline) == "time":
            value /= 60

        return value

    def dataframe(
        self,
        id_: Any | None = None,
        *,
        departure_info: bool = False,
        arrival_info: bool = False,
        error_info: bool = False,
    ) -> GeoDataFrame:
        """
        Return the result as a GeoDataFrame.

        The dataframe will contain the following columns:

        - *id* (Any): Fixed identifier added to each row. Can be
          overridden using the ``id_`` parameter.
        - *subid* (int): Numeric index of the result value starting from zero.
        - *geometry* (MultiPolygon): A MultiPolygon representing the isoline’s geometry.
        - *rangetype* (str): String representing the type of the distance value.
        - *rangevalue* (float): The distance value represented by this range.
        - *timestamp* (datetime): Timestamp of when this result was created.

        When ``departure_info`` is ``True``, the dataframe also contains the
        columns below. If the direction of the query was not ``"outgoing"``, all
        these values will be null.

        - *departure_time* (datetime): Timestamp representing the expected
          departure time.
        - *departure_placename* (str): Name of the departure location.
        - *departure_position* (Point): Resolved position of the departure
          location used for route calculation.
        - *departure_displayposition* (Point): Position of a map marker
          referring to the departure location.
        - *departure_queryposition* (Point): The original position provided
          in the request.

        When ``arrival_info`` is ``True``, the dataframe also contains the
        columns below. If the direction of the query was not ``"incoming"``, all
        these values will be null.

        - *arrival_time* (datetime): Timestamp representing the expected
          arrival time.
        - *arrival_placename* (str): Name of the arrival location.
        - *arrival_position* (Point): Resolved position of the arrival
          location used for route calculation.
        - *arrival_displayposition* (Point): Position of a map marker
          referring to the arrival location.
        - *arrival_queryposition* (Point): The original position provided
          in the request.

        When ``error_info`` is ``True``, the dataframe also contains the
        following columns:

        - *error_code* (int): Error code indicating the type of error that occurred.
        - *error_message* (str): Human-readable error message describing the error.

        Args:
            id_: Fixed identifier to be added to each row. Defaults to 1.
            departure_info: Include additional info about the departure
                time and location.
            arrival_info: Include additional info about the arrival
                time and location.
            error_info: Include error information in the result.

        Returns:
            GeoDataFrame: The list of computed isolines as a GeoDataFrame.
        """
        # - *names*: String descriptor of an isoline, generated from 'range_type' and 'range_value'.

        if id_ is None:
            id_ = 1

        data: list[dict] = []
        for index, isoline in enumerate(self._data.get("isolines", [{}])):
            data.append(row := {})

            if True:
                # fmt: off
                row["id"]               = id_
                row["subid"]            = index
                row["geometry"]         = self._geometry(isoline)
                row["rangetype"]        = self._range_type(isoline)
                row["rangevalue"]       = self._range_value(isoline)
                row["timestamp"]        = self._timestamp
                # fmt: on

        if not data:
            return GeoDataFrame()

        # TODO: When elevation is returned, the CRS should be different (EPSG:4979 ?).
        df = GeoDataFrame(data, geometry="geometry", crs="EPSG:4326")

        if departure_info:
            departure = self.departure_info() or {}
            # fmt: off
            df["departure_time"]            = departure.get("time")
            df["departure_placename"]       = departure.get("placename")
            df["departure_position"]        = departure.get("position")
            df["departure_displayposition"] = departure.get("displayposition")
            df["departure_queryposition"]   = departure.get("queryposition")
            # fmt: on

        if arrival_info:
            arrival = self.arrival_info() or {}
            # fmt: off
            df["arrival_time"]              = arrival.get("time")
            df["arrival_placename"]         = arrival.get("placename")
            df["arrival_position"]          = arrival.get("position")
            df["arrival_displayposition"]   = arrival.get("displayposition")
            df["arrival_queryposition"]     = arrival.get("queryposition")
            # fmt: on

        if error_info:
            err = self.error()
            # fmt: off
            df["error_code"]                = int(err is not None)  # FIXME
            df["error_message"]             = str(err) if err else None
            # fmt: on

        return df

    def has_departure_info(self) -> bool:
        """Return ``True`` if the API response includes departure information."""
        return "departure" in self._data

    def departure_info(self) -> dict | None:
        """
        Return departure information, if available.

        Departure information includes the following values, all of which can be
        ``None``:

        - *time* (datetime): Timestamp representing the expected departure time.
        - *placename* (str): Name of the departure location.
        - *position* (Point): Resolved position of the departure location used
          for route calculation.
        - *displayposition* (Point): Position of a map marker referring to the
          departure location.
        - *queryposition* (Point): The original departure position specified in
          the request.

        Returns:
            dict | None: Departure information as a ``dict``, or ``None`` if no
            departure information is available.
        """
        try:
            departure = self._data["departure"]
            place = departure["place"]
        except KeyError:
            return None
        return {
            "time": _util.fromisoformat_or_null(departure.get("time")),
            "placename": place.get("name"),
            "position": _position_point(place.get("location")),
            "displayposition": _position_point(place.get("displayLocation")),
            "queryposition": _position_point(place.get("originalLocation")),
        }

    def has_arrival_info(self) -> bool:
        """Return ``True`` if the API response includes arrival information."""
        return "arrival" in self._data

    def arrival_info(self) -> dict | None:
        """
        Return arrival information, if available.

        Arrival information includes the following values, all of which can be
        ``None``:

        - *time* (datetime): Timestamp representing the expected arrival time.
        - *placename* (str): Name of the arrival location.
        - *position* (Point): Resolved position of the arrival location used
          for route calculation.
        - *displayposition* (Point): Position of a map marker referring to the
          arrival location.
        - *queryposition* (Point): The original arrival position specified in
          the request.

        Returns:
            dict | None: Arrival information as a ``dict``, or ``None`` if no
            arrival information is available.
        """
        try:
            arrival = self._data["arrival"]
            place = arrival["place"]
        except KeyError:
            return None
        return {
            "time": _util.fromisoformat_or_null(arrival.get("time")),
            "placename": place.get("name"),
            "position": _position_point(place.get("location")),
            "displayposition": _position_point(place.get("displayLocation")),
            "queryposition": _position_point(place.get("originalLocation")),
        }


class RoutesResult(CasaGeoResult):
    """
    Represents the result of a CasaGeoSpatial.routes() query.
    """

    @staticmethod
    def _geometry(route: dict) -> MultiLineString | None:
        try:
            return MultiLineString([
                _util.flexpolyline_points(section["polyline"])
                for section in route["sections"]
            ])
        except KeyError:
            return None

    @staticmethod
    def _length(route: dict) -> float:
        return sum(
            section.get("summary", {}).get("length", math.nan)
            for section in route.get("sections", [])
        )

    @staticmethod
    def _duration(route: dict) -> float:
        duration_seconds = sum(
            section.get("summary", {}).get("duration", math.nan)
            for section in route.get("sections", [])
        )
        return duration_seconds / 60.0

    def dataframe(
        self,
        id_: Any | None = None,
        *,
        departure_info: bool = False,
        arrival_info: bool = False,
        error_info: bool = False,
    ) -> GeoDataFrame:
        """
        Return the result as a GeoDataFrame.

        The dataframe will contain the following columns:

        - *id* (Any): Fixed identifier added to each row. Can be
          overridden using the ``id_`` parameter.
        - *subid* (int): Numeric index of the result value starting from zero.
        - *geometry* (MultiLineString): Geometry of the route by sections.
        - *length* (float): Total length of the route in meters.
        - *duration* (float): Total duration of the route in minutes.
        - *timestamp* (datetime): Timestamp of when this result was created.

        When ``departure_info`` is ``True``, the dataframe also contains the
        following columns:

        - *departure_time* (datetime): Timestamp representing the expected
          departure time.
        - *departure_placename* (str): Name of the departure location.
        - *departure_position* (Point): Resolved position of the departure
          location used for route calculation.
        - *departure_displayposition* (Point): Position of a map marker
          referring to the departure location.
        - *departure_queryposition* (Point): The original departure position
          specified in the request.

        When ``arrival_info`` is ``True``, the dataframe also contains the
        following columns:

        - *arrival_time* (datetime): Timestamp representing the expected arrival
          time.
        - *arrival_placename* (str): Name of the arrival location.
        - *arrival_position* (Point): Resolved position of the arrival location
          used for route calculation.
        - *arrival_displayposition* (Point): Position of a map marker referring
          to the arrival location.
        - *arrival_queryposition* (Point): The original arrival position
          specified in the request.

        When ``error_info`` is ``True``, the dataframe also contains the
        following columns:

        - *error_code* (int): Error code indicating the type of error that occurred.
        - *error_message* (str): Human-readable error message describing the error.

        Args:
            id_: Fixed identifier to be added to each row. Defaults to 1.
            departure_info: Include additional info about the departure
                time and location of each route.
            arrival_info: Include additional info about the arrival
                time and location of each route.
            error_info: Include error information in the result.

        Returns:
            GeoDataFrame: The list of computed routes as a GeoDataFrame.
        """

        if id_ is None:
            id_ = 1

        data: list[dict] = []
        for index, route in enumerate(self._data.get("routes", [{}])):
            data.append(row := {})

            if True:
                # fmt: off
                row["id"]                           = id_
                row["subid"]                        = index
                row["geometry"]                     = self._geometry(route)
                row["length"]                       = self._length(route)
                row["duration"]                     = self._duration(route)
                row["timestamp"]                    = self._timestamp
                # fmt: on

            if departure_info:
                departure = self.departure_info(index) or {}
                # fmt: off
                row["departure_time"]               = departure.get("time")
                row["departure_placename"]          = departure.get("placename")
                row["departure_position"]           = departure.get("position")
                row["departure_displayposition"]    = departure.get("displayposition")
                row["departure_queryposition"]      = departure.get("queryposition")
                # fmt: on

            if arrival_info:
                arrival = self.arrival_info(index) or {}
                # fmt: off
                row["arrival_time"]                 = arrival.get("time")
                row["arrival_placename"]            = arrival.get("placename")
                row["arrival_position"]             = arrival.get("position")
                row["arrival_displayposition"]      = arrival.get("displayposition")
                row["arrival_queryposition"]        = arrival.get("queryposition")
                # fmt: on

        if not data:
            return GeoDataFrame()

        # TODO: When elevation is returned, the CRS should be different (EPSG:4979 ?).
        df = GeoDataFrame(data, geometry="geometry", crs="EPSG:4326")

        if error_info:
            err = self.error()
            # fmt: off
            df["error_code"]        = int(err is not None)  # FIXME
            df["error_message"]     = str(err) if err else None
            # fmt: on

        return df

    def departure_info(self, route: int, section: int = 0) -> dict | None:
        """
        Returns departure information for a specific route or section.

        Departure information includes the following values, all of which can be
        ``None``:

        - *time* (datetime): Timestamp representing the expected departure time.
        - *placename* (str): Name of the departure location.
        - *position* (Point): Resolved position of the departure location used
          for route calculation.
        - *displayposition* (Point): Position of a map marker referring to the
          departure location.
        - *queryposition* (Point): The original departure position specified in
          the request.

        Args:
            route: Index of the route in the result list.
            section: Index of the section within the route, defaults to the
                first section.

        Returns:
            dict | None: Departure information as a ``dict``, or ``None`` if no
            such information exists for the specified route and section.
        """
        try:
            departure = self._data["routes"][route]["sections"][section]["departure"]
            place = departure["place"]
        except (KeyError, IndexError):
            return None
        return {
            "time": _util.fromisoformat_or_null(departure.get("time")),
            "placename": place.get("name"),
            "position": _position_point(place.get("location")),
            "displayposition": _position_point(place.get("displayLocation")),
            "queryposition": _position_point(place.get("originalLocation")),
        }

    def arrival_info(self, route: int, section: int = -1) -> dict | None:
        """
        Returns arrival information for a specific route or section.

        Arrival information includes the following values, all of which can be
        ``None``:

        - *time* (datetime): Timestamp representing the expected arrival time.
        - *placename* (str): Name of the arrival location.
        - *position* (Point): Resolved position of the arrival location used
          for route calculation.
        - *displayposition* (Point): Position of a map marker referring to the
          arrival location.
        - *queryposition* (Point): The original arrival position specified in
          the request.

        Args:
            route: Index of the route in the result list.
            section: Index of the section within the route, defaults to the
                last section.

        Returns:
            dict | None: Arrival information as a ``dict``, or ``None`` if no
            such information exists for the specified route and section.
        """
        try:
            arrival = self._data["routes"][route]["sections"][section]["arrival"]
            place = arrival["place"]
        except (KeyError, IndexError):
            return None
        return {
            "time": _util.fromisoformat_or_null(arrival.get("time")),
            "placename": place.get("name"),
            "position": _position_point(place.get("location")),
            "displayposition": _position_point(place.get("displayLocation")),
            "queryposition": _position_point(place.get("originalLocation")),
        }


@dataclass
class CasaGeoSpatial:
    """
    Provides spatial calculations such as routing and isolines.

    Attributes:
        client:
            The client object authorizing these queries.

        language:
            The preferred language for the response.

            This must be a valid IETF BCP47 language tag, such as "en-US", or a
            comma-separated list of such tags in order of preference.

        unit_system:
            The system of units to use for localized quantities, either
            ``"metric"`` or ``"imperial"``.

        transport_mode:
            The mode of transport to use for routing, e.g. ``"car"``.

            The following modes are available:

            - ``"car"``
            - ``"pedestrian"``
            - ``"bicycle"``

        routing_mode:
            Whether to prefer ``"fast"`` or ``"short"`` routes.

        direction:
            The direction of travel for isolines, either ``"outgoing"`` or
            ``"incoming"``.

        departure_time:
            The date and time of departure for time-dependent routing. This
            value is only used when ``direction`` is ``"outgoing"``.

        arrival_time:
            The date and time of arrival for time-dependent routing. This
            value is only used when ``direction`` is ``"incoming"``.

        traffic:
            Whether to consider traffic data during routing.

            When using this feature, you should also specify either
            ``departure_time`` or ``arrival_time``, depending on ``direction``,
            to get meaningful and reproducible results.

        avoid_features:
            Route features to avoid during routing, e.g. ``("ferry", "tollRoad")``.

            The following features are currently supported:

            - ``"carShuttleTrain"``
            - ``"controlledAccessHighway"``
            - ``"dirtRoad"``
            - ``"ferry"``
            - ``"seasonalClosure"``
            - ``"tollRoad"``
            - ``"tunnel"``

        exclude_countries:
            Countries to exclude from routing, e.g. ``("USA", "DEU")``.

            Countries must be specified by their ISO 3166-1 alpha-3 country
            codes.
    """

    client: CasaGeoClient
    _: KW_ONLY
    language: str | None = None
    unit_system: str | None = None
    transport_mode: str = "car"
    routing_mode: str = "fast"
    direction: str = "outgoing"
    departure_time: datetime | None = None
    arrival_time: datetime | None = None
    traffic: bool = False
    avoid_features: Sequence[str] = ()
    exclude_countries: Sequence[str] = ()

    def __post_init__(self) -> None:
        # Check that self.client is not a string, because the beta version of
        # this class took the license key as the first parameter.
        if not isinstance(self.client, CasaGeoClient):
            raise TypeError("client must be a CasaGeoClient instance")
        if self.language is None:
            self.language = self.client.preferred_language
        if self.unit_system is None:
            self.unit_system = self.client.preferred_unit_system

    def _assign_from_object(self, obj):
        # FIXME: Type checks!
        for field in dataclasses.fields(self):
            if field.kw_only:
                with contextlib.suppress(AttributeError):
                    setattr(self, field.name, getattr(obj, field.name))

    def _validate(self) -> None:
        if self.language is not None:
            if not self.language:
                raise ValueError("language must not be empty")
            for tag in self.language.split(","):
                _util.validate_ietf_bcp47_language_tag(tag)

        if self.unit_system is not None:
            if self.unit_system not in _consts.UNIT_SYSTEMS:
                raise ValueError(
                    f"unit_system must be one of {_consts.UNIT_SYSTEMS}, got {self.unit_system!r}"
                )

        if self.transport_mode not in _consts.TRANSPORT_MODES:
            raise ValueError(
                f"transport_mode must be one of {_consts.TRANSPORT_MODES}, got {self.transport_mode!r}"
            )

        if self.routing_mode not in _consts.ROUTING_MODES:
            raise ValueError(
                f"routing_mode must be one of {_consts.ROUTING_MODES}, got {self.routing_mode!r}"
            )

        if self.direction not in _consts.DIRECTION_TYPES:
            raise ValueError(
                f"direction must be one of {_consts.DIRECTION_TYPES}, got {self.direction!r}"
            )

        for feature in self.avoid_features:
            if feature not in _consts.AVOIDABLE_FEATURES:
                raise ValueError(
                    f"avoid_features may only contain {_consts.AVOIDABLE_FEATURES}, got {feature!r}"
                )

        for country in self.exclude_countries:
            _util.validate_iso3166_alpha3_country_code(country)

    def _departure(self) -> str | None:
        if self.direction != "outgoing":
            return None
        if self.departure_time is None:
            return "any"
        return self.departure_time.isoformat()

    def _arrival(self) -> str | None:
        if self.direction != "incoming":
            return None
        if self.arrival_time is None:
            return "any"
        return self.arrival_time.isoformat()

    # https://www.here.com/docs/bundle/isoline-routing-api-developer-guide-v8/page/README.html
    # https://www.here.com/docs/bundle/isoline-routing-api-v8-api-reference/page/index.html
    @IsolinesResult.wrap_errors()
    def isolines(
        self,
        position: Point,
        ranges: Sequence[float],
        *,
        range_type: str = "time",
    ) -> IsolinesResult:
        """
        Calculate isolines around ``position``.

        Args:
            position:
                The center point of the isolines.
            ranges:
                The distances (in meters) or durations (in minutes) for which to
                calculate isolines.
            range_type:
                The type of range to calculate. Must be one of ``"time"`` or
                ``"distance"``.

        Returns:
            IsolinesResult: The result of the isoline calculation.
        """

        self._validate()

        if not position.is_valid:
            raise ValueError("position must be a valid 2D point")

        if range_type not in _consts.RANGE_TYPES:
            raise ValueError(
                f"range_type must be one of {_consts.RANGE_TYPES}, got {range_type!r}"
            )

        # We interpret time values as minutes, while HERE interprets them as seconds.
        if range_type == "time":
            ranges = [x * 60 for x in ranges]

        point_str = _util.point_to_latlng(position)
        departure = self.departure_time or UNSET
        arrival = self.arrival_time or UNSET

        response = calculate_isolines.sync_detailed(
            client=self.client._client,
            range_=IsolinesRange(
                type_=range_type,
                values=",".join(str(int(x)) for x in ranges),
            ),
            origin=(point_str if self.direction == "outgoing" else UNSET),
            destination=(point_str if self.direction == "incoming" else UNSET),
            departure_time=(departure if self.direction == "outgoing" else UNSET),
            arrival_time=(arrival if self.direction == "incoming" else UNSET),
            transport_mode=RouterMode(self.transport_mode),
            routing_mode=RoutingMode(self.routing_mode),
            avoid=Avoid(
                features=",".join(self.avoid_features)
                if self.avoid_features
                else UNSET,
            ),
            exclude=Exclude(
                countries=",".join(self.exclude_countries)
                if self.exclude_countries
                else UNSET
            ),
            traffic=Traffic(
                mode=TrafficMode.DEFAULT if self.traffic else TrafficMode.DISABLED
            ),
        )

        return IsolinesResult.from_response(response)

    def isolines_batch(
        self,
        request_df: DataFrame,
        *,
        departure_info: bool = False,
        arrival_info: bool = False,
    ) -> GeoDataFrame:
        # NOTE: Raising an exception is permitted here!

        if not (info := self.client.account_info()):
            raise CasaGeoError(
                "Could not retrieve account information for bulk cost calculation"
            ) from info.error()

        operation_count = request_df["ranges"].map(len).sum()
        if info.credits() < (operation_count * _consts.ISOLINES_COST):
            raise CasaGeoError(
                f"Insufficient credits to calculate {operation_count} isolines"
            )

        results: list[GeoDataFrame] = []

        for row in request_df.itertuples():
            self._assign_from_object(row)

            # FIXME: Type checks!
            rdf = self.isolines(
                cast(Any, row.position),
                cast(Any, row.ranges),
                range_type=getattr(row, "range_type", "time"),
            ).dataframe(
                id_=getattr(row, "id", row.Index),
                departure_info=departure_info,
                arrival_info=arrival_info,
                error_info=True,
            )

            results.append(rdf)

        return cast(GeoDataFrame, concat(results, ignore_index=True))

    # https://www.here.com/docs/bundle/routing-api-developer-guide-v8/page/README.html
    # https://www.here.com/docs/bundle/routing-api-v8-api-reference/page/index.html
    @RoutesResult.wrap_errors()
    def routes(
        self,
        origin: Point,
        destination: Point,
        *,
        alternatives: int = 0,
    ) -> RoutesResult:
        """
        Calculate routes from ``origin`` to ``destination``.

        Args:
            origin: The starting point of the route.
            destination: The destination point of the route.
            alternatives: The number of alternate routes to calculate.

        Returns:
            RoutesResult: The result of the route calculation.
        """

        self._validate()

        if not origin.is_valid:
            raise ValueError("origin must be a valid 2D point")

        if not destination.is_valid:
            raise ValueError("destination must be a valid 2D point")

        if not 0 <= alternatives <= 6:
            raise ValueError(
                "Number of alternate routes must be between 0 and 6 inclusive"
            )

        # NOTE: Due to API client limitations, we can’t support departureTime=any and
        #       arrivalTime=any everywhere, so we choose to not support it at all.
        departure = self.departure_time.isoformat() if self.departure_time else UNSET
        arrival = self.arrival_time or UNSET

        response = calculate_routes.sync_detailed(
            client=self.client._client,
            origin=_util.point_to_latlng(origin),
            destination=_util.point_to_latlng(destination),
            alternatives=alternatives,
            departure_time=(departure if self.direction == "outgoing" else UNSET),
            arrival_time=(arrival if self.direction == "incoming" else UNSET),
            transport_mode=RouterMode(self.transport_mode),
            routing_mode=RoutingMode(self.routing_mode),
            avoid=Avoid(
                features=",".join(self.avoid_features)
                if self.avoid_features
                else UNSET,
            ),
            exclude=Exclude(
                countries=",".join(self.exclude_countries)
                if self.exclude_countries
                else UNSET
            ),
            traffic=Traffic(
                mode=TrafficMode.DEFAULT if self.traffic else TrafficMode.DISABLED
            ),
            # HACK: Workaround for https://github.com/openapi-generators/openapi-python-client/issues/197
            lang=([self.language] if self.language is not None else UNSET),
            units=Units(self.unit_system) if self.unit_system is not None else UNSET,
            # HACK: Workaround for https://github.com/openapi-generators/openapi-python-client/issues/197
            return_=[SimpleNamespace(value=f"{Return.SUMMARY},{Return.POLYLINE}")],  # type: ignore
        )

        return RoutesResult.from_response(response)

    def routes_batch(
        self,
        request_df: DataFrame,
        *,
        departure_info: bool = False,
        arrival_info: bool = False,
    ) -> GeoDataFrame:
        # NOTE: Raising an exception is permitted here!

        if not (info := self.client.account_info()):
            raise CasaGeoError(
                "Could not retrieve account information for bulk cost calculation"
            ) from info.error()

        operation_count = 0
        operation_cost = 0

        for row in request_df.itertuples():
            opcount = 1 + getattr(row, "alternatives", 0)
            opcost = _consts.ROUTING_COST_BY_TRANSPORT_MODE[
                getattr(row, "transport_mode", self.transport_mode)
            ]
            operation_count += opcount
            operation_cost += opcount * opcost

        if info.credits() < operation_cost:
            raise CasaGeoError(
                f"Insufficient credits to calculate {operation_count} routes"
            )

        results: list[GeoDataFrame] = []

        for row in request_df.itertuples():
            self._assign_from_object(row)

            # FIXME: Type checks!
            rdf = self.routes(
                cast(Any, row.origin),
                cast(Any, row.destination),
                alternatives=getattr(row, "alternatives", 0),
            ).dataframe(
                id_=getattr(row, "id", row.Index),
                departure_info=departure_info,
                arrival_info=arrival_info,
                error_info=True,
            )

            results.append(rdf)

        return cast(GeoDataFrame, concat(results, ignore_index=True))


def _isolines_command(spatial: CasaGeoSpatial, options: argparse.Namespace) -> None:
    result = spatial.isolines(
        origin=options.origin,
        destination=options.destination,
        ranges=options.ranges,
        range_type=options.range_type,
    ) or sys.exit(1)
    result.dataframe(
        id_=options.with_id,
        departure_info=options.with_departure_info,
        arrival_info=options.with_arrival_info,
    ).to_csv(sys.stdout, sep=";", index=False)


def _routes_command(spatial: CasaGeoSpatial, options: argparse.Namespace) -> None:
    result = spatial.routes(
        origin=options.origin,
        destination=options.destination,
        alternatives=options.alternatives,
    ) or sys.exit(1)
    result.dataframe(
        id_=options.with_id,
        departure_info=options.with_departure_info,
        arrival_info=options.with_arrival_info,
    ).to_csv(sys.stdout, sep=";", index=False)


def _main(args: Sequence[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        description="Provides spatial calculations such as routing and isolines.",
        allow_abbrev=False,
    )
    subparsers = parser.add_subparsers(
        title="subcommands",
        required=True,
        metavar="COMMAND",
    )

    # Subcommand Parent Parser

    parent_parser = argparse.ArgumentParser(add_help=False, conflict_handler="resolve")
    common_params = parent_parser.add_argument_group(title="common parameters")
    common_params.add_argument(
        "--language",
        type=_util.cli_ietf_bcp47_language_tag,
        help="the preferred language for the response",
    )
    common_params.add_argument(
        "--unit-system",
        choices=_consts.UNIT_SYSTEMS,
        help="the system of units to use for localized quantities",
    )
    common_params.add_argument(
        "--transport-mode",
        default=_consts.TRANSPORT_MODES[0],
        choices=_consts.TRANSPORT_MODES,
        help="the mode of transport used for routing",
    )
    common_params.add_argument(
        "--routing-mode",
        default=_consts.ROUTING_MODES[0],
        choices=_consts.ROUTING_MODES,
        help="whether to prefer 'fast' or 'short' routes",
    )
    common_params.add_argument(
        "--direction",
        default="outgoing",
        choices=["outgoing", "incoming"],
        help="the direction of travel for isolines",
    )
    common_params.add_argument(
        "--departure-time",
        type=_util.cli_datetime,
        help="the date and time of departure for time-dependent routing",
    )
    common_params.add_argument(
        "--arrival-time",
        type=_util.cli_datetime,
        help="the date and time of arrival for time-dependent routing",
    )
    common_params.add_argument(
        "--traffic",
        action="store_true",
        help="consider traffic data during routing",
    )
    common_params.add_argument(
        "--avoid-features",
        default=[],
        type=_util.cli_avoidable_feature_list,
        help="route features to avoid during routing",
    )
    common_params.add_argument(
        "--exclude-countries",
        default=[],
        type=_util.cli_iso3166_alpha3_country_code_list,
        help="countries to exclude from routing",
    )

    # Isolines Subcommand

    isolines_parser = subparsers.add_parser(
        "isolines",
        help="calculate isolines for a given location and time/distance",
        description="Calculate isolines around a location.",
        parents=[parent_parser],
        allow_abbrev=False,
    )
    isolines_parser.set_defaults(command=_isolines_command)

    isolines_params = isolines_parser.add_argument_group(title="isolines parameters")
    isolines_params.add_argument(
        "position",
        type=_util.cli_latlong_point,
        help="the location for which to calculate isolines",
    )
    isolines_params.add_argument(
        "ranges",
        nargs="+",
        type=float,
        help="the ranges for which to calculate isolines",
    )
    isolines_params.add_argument(
        "--range-type",
        default="time",
        choices=["time", "distance"],
        help="the type of range to calculate isolines for (time in minutes or distance in meters)",
    )

    isolines_dfparams = isolines_parser.add_argument_group(title="dataframe parameters")
    isolines_dfparams.add_argument(
        "--with-id",
        help="sets the value of the 'id' column",
        metavar="ID",
    )
    isolines_dfparams.add_argument(
        "--with-departure-info",
        action="store_true",
        help="include departure information in the results",
    )
    isolines_dfparams.add_argument(
        "--with-arrival-info",
        action="store_true",
        help="include arrival information in the results",
    )

    # Routes Subcommand

    routes_parser = subparsers.add_parser(
        "routes",
        help="calculate routes between two locations",
        description="Calculate routes between an origin and a destination.",
        parents=[parent_parser],
        allow_abbrev=False,
    )
    routes_parser.set_defaults(command=_routes_command)

    routes_params = routes_parser.add_argument_group(title="routes parameters")
    routes_params.add_argument(
        "origin",
        type=_util.cli_latlong_point,
        help="the starting point for the route",
    )
    routes_params.add_argument(
        "destination",
        type=_util.cli_latlong_point,
        help="the destination point for the route",
    )
    routes_params.add_argument(
        "--alternatives",
        default=0,
        type=_util.cli_non_negative_int,
        help="number of alternate routes to calculate",
    )

    routes_dfparams = routes_parser.add_argument_group(title="dataframe parameters")
    routes_dfparams.add_argument(
        "--with-id",
        help="sets the value of the 'id' column",
        metavar="ID",
    )
    routes_dfparams.add_argument(
        "--with-departure-info",
        action="store_true",
        help="include departure information in the results",
    )
    routes_dfparams.add_argument(
        "--with-arrival-info",
        action="store_true",
        help="include arrival information in the results",
    )

    # Main Function Body

    options = parser.parse_args(args)
    api_key = os.getenv("CASAGEOTOOLS_API_KEY") or sys.exit(
        "Please specify an API key in the environment variable CASAGEOTOOLS_API_KEY"
    )

    spatial = CasaGeoSpatial(
        CasaGeoClient(api_key),
        language=options.language,
        unit_system=options.unit_system,
        transport_mode=options.transport_mode,
        routing_mode=options.routing_mode,
        direction=options.direction,
        departure_time=options.departure_time,
        arrival_time=options.arrival_time,
        traffic=options.traffic,
        avoid_features=options.avoid_features,
        exclude_countries=options.exclude_countries,
    )

    options.command(spatial, options)


if __name__ == "__main__":
    try:
        _main()
    except Exception as e:
        sys.exit(f"{e.__class__.__name__}: {e}")
