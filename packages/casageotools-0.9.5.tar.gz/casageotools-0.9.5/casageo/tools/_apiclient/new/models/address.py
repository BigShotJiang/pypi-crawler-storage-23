from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="Address")


@_attrs_define
class Address:
    """
    Attributes:
        block (str | Unset): Name of block.
        building (str | Unset): Name of building.
        city (str | Unset): The name of the primary locality of the place. For example: "Bad Oyenhausen"
        country_code (str | Unset): A three-letter country code. For example: "DEU"
        country_name (str | Unset): The localised country name. For example: "Deutschland"
        county (str | Unset): A division of a state; typically, a secondary-level administrative division of a country
            or equivalent.
        county_code (str | Unset): A county code or county name abbreviation – country specific. For example, for Italy
            it is the province abbreviation: "RM" for Rome.
        district (str | Unset): A division of city; typically an administrative unit within a larger city or a customary
            name of a city's neighborhood. For example: "Bad Oyenhausen"
        house_number (str | Unset): House number. For example: "4"
        label (str | Unset): Assembled address value built out of the address components according to the regional
            postal rules.
            These are the same rules for all endpoints. It may not include all the input terms. For example:
            "Schulstraße 4, 32547 Bad Oeynhausen, Germany"
        postal_code (str | Unset): An alphanumeric string included in a postal address to facilitate mail sorting, such
            as post code, postcode, or ZIP code. For example: "32547"
        state (str | Unset): The state division of a country. For example: "North Rhine-Westphalia"
        state_code (str | Unset): A state code or state name abbreviation – country specific. For example, in the United
            States it is the two letter state abbreviation: "CA" for California.
        street (str | Unset): Name of street. For example: "Schulstrasse"
        streets (list[str] | Unset): Names of streets in case of intersection result. For example:
            ["Friedrichstraße","Unter den Linden"]
        subblock (str | Unset): Name of sub-block.
        subdistrict (str | Unset): A subdivision of a district. For example: "Minden-Lübbecke"
        unit (str | Unset): Secondary unit information. It may include building, floor (level), and suite (unit)
            details. This field is returned by Geocode, (Multi) Reverse Geocode and Lookup endpoints only.
    """

    block: str | Unset = UNSET
    building: str | Unset = UNSET
    city: str | Unset = UNSET
    country_code: str | Unset = UNSET
    country_name: str | Unset = UNSET
    county: str | Unset = UNSET
    county_code: str | Unset = UNSET
    district: str | Unset = UNSET
    house_number: str | Unset = UNSET
    label: str | Unset = UNSET
    postal_code: str | Unset = UNSET
    state: str | Unset = UNSET
    state_code: str | Unset = UNSET
    street: str | Unset = UNSET
    streets: list[str] | Unset = UNSET
    subblock: str | Unset = UNSET
    subdistrict: str | Unset = UNSET
    unit: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        block = self.block

        building = self.building

        city = self.city

        country_code = self.country_code

        country_name = self.country_name

        county = self.county

        county_code = self.county_code

        district = self.district

        house_number = self.house_number

        label = self.label

        postal_code = self.postal_code

        state = self.state

        state_code = self.state_code

        street = self.street

        streets: list[str] | Unset = UNSET
        if not isinstance(self.streets, Unset):
            streets = self.streets

        subblock = self.subblock

        subdistrict = self.subdistrict

        unit = self.unit

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if block is not UNSET:
            field_dict["block"] = block
        if building is not UNSET:
            field_dict["building"] = building
        if city is not UNSET:
            field_dict["city"] = city
        if country_code is not UNSET:
            field_dict["countryCode"] = country_code
        if country_name is not UNSET:
            field_dict["countryName"] = country_name
        if county is not UNSET:
            field_dict["county"] = county
        if county_code is not UNSET:
            field_dict["countyCode"] = county_code
        if district is not UNSET:
            field_dict["district"] = district
        if house_number is not UNSET:
            field_dict["houseNumber"] = house_number
        if label is not UNSET:
            field_dict["label"] = label
        if postal_code is not UNSET:
            field_dict["postalCode"] = postal_code
        if state is not UNSET:
            field_dict["state"] = state
        if state_code is not UNSET:
            field_dict["stateCode"] = state_code
        if street is not UNSET:
            field_dict["street"] = street
        if streets is not UNSET:
            field_dict["streets"] = streets
        if subblock is not UNSET:
            field_dict["subblock"] = subblock
        if subdistrict is not UNSET:
            field_dict["subdistrict"] = subdistrict
        if unit is not UNSET:
            field_dict["unit"] = unit

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        block = d.pop("block", UNSET)

        building = d.pop("building", UNSET)

        city = d.pop("city", UNSET)

        country_code = d.pop("countryCode", UNSET)

        country_name = d.pop("countryName", UNSET)

        county = d.pop("county", UNSET)

        county_code = d.pop("countyCode", UNSET)

        district = d.pop("district", UNSET)

        house_number = d.pop("houseNumber", UNSET)

        label = d.pop("label", UNSET)

        postal_code = d.pop("postalCode", UNSET)

        state = d.pop("state", UNSET)

        state_code = d.pop("stateCode", UNSET)

        street = d.pop("street", UNSET)

        streets = cast(list[str], d.pop("streets", UNSET))

        subblock = d.pop("subblock", UNSET)

        subdistrict = d.pop("subdistrict", UNSET)

        unit = d.pop("unit", UNSET)

        address = cls(
            block=block,
            building=building,
            city=city,
            country_code=country_code,
            country_name=country_name,
            county=county,
            county_code=county_code,
            district=district,
            house_number=house_number,
            label=label,
            postal_code=postal_code,
            state=state,
            state_code=state_code,
            street=street,
            streets=streets,
            subblock=subblock,
            subdistrict=subdistrict,
            unit=unit,
        )

        address.additional_properties = d
        return address

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
