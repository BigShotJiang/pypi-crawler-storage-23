from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ErrorResponse")


@_attrs_define
class ErrorResponse:
    """
    Attributes:
        correlation_id (str): Auto-generated ID univocally identifying this request
        request_id (str): Request identifier provided by the user
        status (int): The HTTP status code
        title (str): Human-readable error description
        action (str | Unset): Human-readable action for the user
        cause (str | Unset): Human-readable explanation for the error
        code (str | Unset): Error code
    """

    correlation_id: str
    request_id: str
    status: int
    title: str
    action: str | Unset = UNSET
    cause: str | Unset = UNSET
    code: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        correlation_id = self.correlation_id

        request_id = self.request_id

        status = self.status

        title = self.title

        action = self.action

        cause = self.cause

        code = self.code

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "correlationId": correlation_id,
            "requestId": request_id,
            "status": status,
            "title": title,
        })
        if action is not UNSET:
            field_dict["action"] = action
        if cause is not UNSET:
            field_dict["cause"] = cause
        if code is not UNSET:
            field_dict["code"] = code

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        correlation_id = d.pop("correlationId")

        request_id = d.pop("requestId")

        status = d.pop("status")

        title = d.pop("title")

        action = d.pop("action", UNSET)

        cause = d.pop("cause", UNSET)

        code = d.pop("code", UNSET)

        error_response = cls(
            correlation_id=correlation_id,
            request_id=request_id,
            status=status,
            title=title,
            action=action,
            cause=cause,
            code=code,
        )

        error_response.additional_properties = d
        return error_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
