from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="EvAvailabilityConnector")


@_attrs_define
class EvAvailabilityConnector:
    """
    Attributes:
        cpo_id (str | Unset): CPO ID of the connector.
        id (str | Unset): HERE ID of the connector.
        max_power_level (float | Unset): Maximum charge power of connector in kilowatts.
        type_id (str | Unset): Connector type ID. For more information on the current connector types,
            see [resource-type-connector-types.html](https://www.here.com/docs/bundle/ev-charge-points-api-developer-
            guide/page/topics/resource-type-connector-types.html)
    """

    cpo_id: str | Unset = UNSET
    id: str | Unset = UNSET
    max_power_level: float | Unset = UNSET
    type_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        cpo_id = self.cpo_id

        id = self.id

        max_power_level = self.max_power_level

        type_id = self.type_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if cpo_id is not UNSET:
            field_dict["cpoId"] = cpo_id
        if id is not UNSET:
            field_dict["id"] = id
        if max_power_level is not UNSET:
            field_dict["maxPowerLevel"] = max_power_level
        if type_id is not UNSET:
            field_dict["typeId"] = type_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        cpo_id = d.pop("cpoId", UNSET)

        id = d.pop("id", UNSET)

        max_power_level = d.pop("maxPowerLevel", UNSET)

        type_id = d.pop("typeId", UNSET)

        ev_availability_connector = cls(
            cpo_id=cpo_id,
            id=id,
            max_power_level=max_power_level,
            type_id=type_id,
        )

        ev_availability_connector.additional_properties = d
        return ev_availability_connector

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
