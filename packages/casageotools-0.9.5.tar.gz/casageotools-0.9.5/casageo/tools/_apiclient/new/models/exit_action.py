from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.exit_action_action import ExitActionAction
from ..models.turn_action_direction import TurnActionDirection
from ..models.turn_action_severity import TurnActionSeverity
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.exit_info import ExitInfo
    from ..models.localized_string import LocalizedString
    from ..models.road_info import RoadInfo
    from ..models.signpost_info import SignpostInfo


T = TypeVar("T", bound="ExitAction")


@_attrs_define
class ExitAction:
    """An action to leave a highway or roundabout.

    * `exit`: exit maneuver, such as "Take the left exit to"
    * `roundaboutExit`: roundabout exit maneuver, such as "Take the third exit of the roundabout onto"

        Attributes:
            action (ExitActionAction): The type of the action.

                **NOTE:** The list of possible actions may be extended in the future. The client application should handle such
                a case gracefully.
            duration (int): Duration in seconds. Example: 198.
            current_road (RoadInfo | Unset): Road information attached to an offset action Example: {'fennstrasse': {'name':
                [{'language': 'de', 'value': 'Fennstraße'}], 'number': [{'language': 'de', 'value': 'B96'}], 'toward':
                [{'language': 'de', 'value': 'Reinickendorf'}], 'type': 'street'}}.
            direction (TurnActionDirection | Unset): Direction of the turn. `middle` is only used by the `keep` action.
            exit_ (int | Unset): Which exit to take next. Default: 1.
            exit_sign (ExitInfo | Unset): Exit information attached to an offset action Example: {'exit': {'number':
                [{'language': 'de', 'value': '15'}]}}.
            instruction (str | Unset): Description of the action (e.g. Turn left onto Minna St.).
            intersection_name (list[LocalizedString] | Unset): Name of the intersection where the turn takes place, if
                available.
            length (int | Unset): Distance in meters. Example: 189.
            next_road (RoadInfo | Unset): Road information attached to an offset action Example: {'fennstrasse': {'name':
                [{'language': 'de', 'value': 'Fennstraße'}], 'number': [{'language': 'de', 'value': 'B96'}], 'toward':
                [{'language': 'de', 'value': 'Reinickendorf'}], 'type': 'street'}}.
            offset (int | Unset): Offset of a coordinate in the section's polyline.
            roundabout_angle (float | Unset): The degree measure of the arc traversed from the roundabout entrance to the
                exit of the maneuver.

                Available only for exit roundabout actions. Positive values indicate an exit angle
                for a right-hand side driving roundabout and negative values indicate an exit angle
                for a left-hand side driving roundabout.
                 Example: 204.83.
            severity (TurnActionSeverity | Unset): Tightness of the turn. Optional in the `turn` action, unused by other
                actions.

                * `light`: indicates making a light turn
                * `quite`: indicates making a regular turn
                * `heavy`: indicates making a heavy turn
            signpost (SignpostInfo | Unset): Signpost information attached to an offset action.
                 Example: {'$ref': '#/components/examples/routeResponseManeuverSignpostInfoExample'}.
            turn_angle (float | Unset): The angle of the turn expressed in degrees.

                It is available only for turn-by-turn actions. A positive number indicates a clockwise angle.
                 Example: -132.28.
    """

    action: ExitActionAction
    duration: int
    current_road: RoadInfo | Unset = UNSET
    direction: TurnActionDirection | Unset = UNSET
    exit_: int | Unset = 1
    exit_sign: ExitInfo | Unset = UNSET
    instruction: str | Unset = UNSET
    intersection_name: list[LocalizedString] | Unset = UNSET
    length: int | Unset = UNSET
    next_road: RoadInfo | Unset = UNSET
    offset: int | Unset = UNSET
    roundabout_angle: float | Unset = UNSET
    severity: TurnActionSeverity | Unset = UNSET
    signpost: SignpostInfo | Unset = UNSET
    turn_angle: float | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        action = self.action.value

        duration = self.duration

        current_road: dict[str, Any] | Unset = UNSET
        if not isinstance(self.current_road, Unset):
            current_road = self.current_road.to_dict()

        direction: str | Unset = UNSET
        if not isinstance(self.direction, Unset):
            direction = self.direction.value

        exit_ = self.exit_

        exit_sign: dict[str, Any] | Unset = UNSET
        if not isinstance(self.exit_sign, Unset):
            exit_sign = self.exit_sign.to_dict()

        instruction = self.instruction

        intersection_name: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.intersection_name, Unset):
            intersection_name = []
            for intersection_name_item_data in self.intersection_name:
                intersection_name_item = intersection_name_item_data.to_dict()
                intersection_name.append(intersection_name_item)

        length = self.length

        next_road: dict[str, Any] | Unset = UNSET
        if not isinstance(self.next_road, Unset):
            next_road = self.next_road.to_dict()

        offset = self.offset

        roundabout_angle = self.roundabout_angle

        severity: str | Unset = UNSET
        if not isinstance(self.severity, Unset):
            severity = self.severity.value

        signpost: dict[str, Any] | Unset = UNSET
        if not isinstance(self.signpost, Unset):
            signpost = self.signpost.to_dict()

        turn_angle = self.turn_angle

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "action": action,
            "duration": duration,
        })
        if current_road is not UNSET:
            field_dict["currentRoad"] = current_road
        if direction is not UNSET:
            field_dict["direction"] = direction
        if exit_ is not UNSET:
            field_dict["exit"] = exit_
        if exit_sign is not UNSET:
            field_dict["exitSign"] = exit_sign
        if instruction is not UNSET:
            field_dict["instruction"] = instruction
        if intersection_name is not UNSET:
            field_dict["intersectionName"] = intersection_name
        if length is not UNSET:
            field_dict["length"] = length
        if next_road is not UNSET:
            field_dict["nextRoad"] = next_road
        if offset is not UNSET:
            field_dict["offset"] = offset
        if roundabout_angle is not UNSET:
            field_dict["roundaboutAngle"] = roundabout_angle
        if severity is not UNSET:
            field_dict["severity"] = severity
        if signpost is not UNSET:
            field_dict["signpost"] = signpost
        if turn_angle is not UNSET:
            field_dict["turnAngle"] = turn_angle

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.exit_info import ExitInfo
        from ..models.localized_string import LocalizedString
        from ..models.road_info import RoadInfo
        from ..models.signpost_info import SignpostInfo

        d = dict(src_dict)
        action = ExitActionAction(d.pop("action"))

        duration = d.pop("duration")

        _current_road = d.pop("currentRoad", UNSET)
        current_road: RoadInfo | Unset
        if isinstance(_current_road, Unset):
            current_road = UNSET
        else:
            current_road = RoadInfo.from_dict(_current_road)

        _direction = d.pop("direction", UNSET)
        direction: TurnActionDirection | Unset
        if isinstance(_direction, Unset):
            direction = UNSET
        else:
            direction = TurnActionDirection(_direction)

        exit_ = d.pop("exit", UNSET)

        _exit_sign = d.pop("exitSign", UNSET)
        exit_sign: ExitInfo | Unset
        if isinstance(_exit_sign, Unset):
            exit_sign = UNSET
        else:
            exit_sign = ExitInfo.from_dict(_exit_sign)

        instruction = d.pop("instruction", UNSET)

        _intersection_name = d.pop("intersectionName", UNSET)
        intersection_name: list[LocalizedString] | Unset = UNSET
        if _intersection_name is not UNSET:
            intersection_name = []
            for intersection_name_item_data in _intersection_name:
                intersection_name_item = LocalizedString.from_dict(
                    intersection_name_item_data
                )

                intersection_name.append(intersection_name_item)

        length = d.pop("length", UNSET)

        _next_road = d.pop("nextRoad", UNSET)
        next_road: RoadInfo | Unset
        if isinstance(_next_road, Unset):
            next_road = UNSET
        else:
            next_road = RoadInfo.from_dict(_next_road)

        offset = d.pop("offset", UNSET)

        roundabout_angle = d.pop("roundaboutAngle", UNSET)

        _severity = d.pop("severity", UNSET)
        severity: TurnActionSeverity | Unset
        if isinstance(_severity, Unset):
            severity = UNSET
        else:
            severity = TurnActionSeverity(_severity)

        _signpost = d.pop("signpost", UNSET)
        signpost: SignpostInfo | Unset
        if isinstance(_signpost, Unset):
            signpost = UNSET
        else:
            signpost = SignpostInfo.from_dict(_signpost)

        turn_angle = d.pop("turnAngle", UNSET)

        exit_action = cls(
            action=action,
            duration=duration,
            current_road=current_road,
            direction=direction,
            exit_=exit_,
            exit_sign=exit_sign,
            instruction=instruction,
            intersection_name=intersection_name,
            length=length,
            next_road=next_road,
            offset=offset,
            roundabout_angle=roundabout_angle,
            severity=severity,
            signpost=signpost,
            turn_angle=turn_angle,
        )

        exit_action.additional_properties = d
        return exit_action

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
