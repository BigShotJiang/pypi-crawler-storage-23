from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.fare_pass_validity_period import FarePassValidityPeriod


T = TypeVar("T", bound="FarePass")


@_attrs_define
class FarePass:
    """Specifies whether this `Fare` is a multi-travel pass, and its characteristics

    Attributes:
        return_journey (bool | Unset): This pass includes the fare for the return journey.
        senior_pass (bool | Unset): This pass is valid only if presented by a senior person.
        transfers (int | Unset): Indicates if transfers are permitted with this pass, and if so, how many.
        travels (int | Unset): This pass allows for the specified number of travels.
        validity_period (FarePassValidityPeriod | Unset): Specifies a temporal validity period for a pass
    """

    return_journey: bool | Unset = UNSET
    senior_pass: bool | Unset = UNSET
    transfers: int | Unset = UNSET
    travels: int | Unset = UNSET
    validity_period: FarePassValidityPeriod | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return_journey = self.return_journey

        senior_pass = self.senior_pass

        transfers = self.transfers

        travels = self.travels

        validity_period: dict[str, Any] | Unset = UNSET
        if not isinstance(self.validity_period, Unset):
            validity_period = self.validity_period.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if return_journey is not UNSET:
            field_dict["returnJourney"] = return_journey
        if senior_pass is not UNSET:
            field_dict["seniorPass"] = senior_pass
        if transfers is not UNSET:
            field_dict["transfers"] = transfers
        if travels is not UNSET:
            field_dict["travels"] = travels
        if validity_period is not UNSET:
            field_dict["validityPeriod"] = validity_period

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.fare_pass_validity_period import FarePassValidityPeriod

        d = dict(src_dict)
        return_journey = d.pop("returnJourney", UNSET)

        senior_pass = d.pop("seniorPass", UNSET)

        transfers = d.pop("transfers", UNSET)

        travels = d.pop("travels", UNSET)

        _validity_period = d.pop("validityPeriod", UNSET)
        validity_period: FarePassValidityPeriod | Unset
        if isinstance(_validity_period, Unset):
            validity_period = UNSET
        else:
            validity_period = FarePassValidityPeriod.from_dict(_validity_period)

        fare_pass = cls(
            return_journey=return_journey,
            senior_pass=senior_pass,
            transfers=transfers,
            travels=travels,
            validity_period=validity_period,
        )

        fare_pass.additional_properties = d
        return fare_pass

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
