import sys

from . import _main

try:
    _main()
except Exception as e:
    sys.exit(f"{e.__class__.__name__}: {e}")
