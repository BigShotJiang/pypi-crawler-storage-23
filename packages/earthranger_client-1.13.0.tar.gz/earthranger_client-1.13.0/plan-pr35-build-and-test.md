# Plan: Build and test PR #35 (user/EULA endpoints) with uv only

## Goal
Pull the PR branch, build a wheel with **uv** (no hatch), and run the new account/user/EULA tests.

## PR #35 summary
- **Branch:** `ERA-12676/accounts-users-eula`
- **Adds:** `get_users()`, `get_user(id)`, `patch_user(id, data)`, `get_user_profiles(id)`, `get_eula()`, `accept_eula()` on both `ERClient` and `AsyncERClient`
- **New tests:** `tests/async_client/test_accounts.py`, `tests/sync_client/test_accounts.py`

---

## Steps (uv only, gh CLI)

### 1. Check out the PR branch
```bash
cd /Users/joshuak/Projects/er-client
gh pr checkout 35 --repo PADAS/er-client
```
*(Or use `git checkout ERA-12676/accounts-users-eula` if the branch is already fetched.)*

### 2. Sync with remote (optional)
```bash
git pull origin ERA-12676/accounts-users-eula
```

### 3. Install dev deps and build the wheel with uv
You can keep the existing **hatchling** build-backend in `pyproject.toml`; uv will use it under the hood. No need to change to another backend.

- **Install project + dev/test deps (so tests run):**
  ```bash
  uv sync --all-groups
  ```
  This uses the existing `[dependency-groups] dev` and optional `test` deps.

- **Build the wheel:**
  ```bash
  uv build --wheel -o dist
  ```
  This runs the PEP 517 build (hatchling) in an isolated env; you never need to run `hatch` yourself.

### 4. Run the new tests (and optionally full suite)
- **Only the new account tests:**
  ```bash
  uv run pytest tests/async_client/test_accounts.py tests/sync_client/test_accounts.py -v
  ```
- **Full test suite (as in PR’s test plan):**
  ```bash
  uv run pytest -q
  ```

### 5. (Optional) Install the built wheel in another env
```bash
uv pip install dist/earthranger_client-*.whl
# or in a fresh venv:
# uv venv /tmp/er-test && source /tmp/er-test/bin/activate && uv pip install dist/earthranger_client-*.whl
```

---

## One-liner summary
```bash
gh pr checkout 35 --repo PADAS/er-client && uv sync --all-groups && uv build --wheel -o dist && uv run pytest tests/async_client/test_accounts.py tests/sync_client/test_accounts.py -v
```

---

## Notes
- **Hatch vs uv:** Keeping `hatchling` as the build-backend is fine; `uv build` invokes it via PEP 517. You don’t need the `hatch` CLI or `[tool.hatch.envs]` for building or testing if you use `uv sync` and `uv run pytest`.
- **Wheel output:** `dist/` will contain e.g. `earthranger_client-<version>-py3-none-any.whl`.
- If you later want to remove hatch entirely from the config, you could switch the build-backend to `uv.core` (or another backend), but it’s not required for “use only uv” in your workflow.
