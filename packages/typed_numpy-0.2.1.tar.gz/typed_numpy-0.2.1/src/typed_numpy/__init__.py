"""
Typed NumPy
=======
"""
# src/typed_numpy/__init__.py

import numpy

__all__ = [
    "numpy",
]
