from delft.sequenceLabelling.wrapper import Sequence
