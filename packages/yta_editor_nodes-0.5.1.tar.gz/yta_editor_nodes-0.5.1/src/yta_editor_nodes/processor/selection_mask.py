from yta_editor_nodes.processor.base import _NodeProcessor
from typing import Union


class SelectionMaskNodeProcessor(_NodeProcessor):
    """
    Class to use a mask selection (from which we will
    determine if the pixel must be applied or not) to
    apply the processed input over the original one.

    If the selection mask is completely full, the
    result will be the processed input.

    Mandatory inputs:
    - `original_input`
    - `processed_input`
    - `selection_mask_input`

    Optional inputs:
    - `None`

    Parameters:
    - `factor`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """
    
    mandatory_inputs = ['original_input', 'processed_input', 'selection_mask_input']
    optional_inputs = []
    parameters_specifications = []

    def __init__(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        super().__init__(
            opengl_context = opengl_context
        )

    def _instantiate_cpu_and_gpu_processors(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        """
        *For internal use only*

        Instantiate the CPU and GPU procesors and return 
        them in that order.

        This method must be implemented by each class.
        """
        from yta_editor_nodes_cpu.processor.selection_mask import SelectionMaskNodeProcessorCPU
        from yta_editor_nodes_gpu.processor.selection_mask import SelectionMaskNodeProcessorGPU

        node_cpu = SelectionMaskNodeProcessorCPU()
        node_gpu = SelectionMaskNodeProcessorGPU(
            opengl_context = opengl_context
        )

        return node_cpu, node_gpu