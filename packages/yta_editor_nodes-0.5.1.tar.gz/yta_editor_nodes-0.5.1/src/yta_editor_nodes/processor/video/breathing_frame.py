from yta_editor_nodes.processor.video.base import _VideoNodeProcessor
from yta_editor_parameters.specifications import ParameterSpecification
from typing import Union


class BreathingFrameVideoNodeProcessor(_VideoNodeProcessor):
    """
    The frame but as if it was breathing.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`
    
    Parameters:
    - `*zoom`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'zoom',
            type = float,
            is_required = True,
            default = 0.05,
            min = 0.001,
            max = 1.0
        )
    ]

    def __init__(
        self,
        opengl_context: 'moderngl.Context'
    ):
        super().__init__(
            opengl_context = opengl_context
        )

    def _instantiate_cpu_and_gpu_processors(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        """
        *For internal use only*

        Instantiate the CPU and GPU procesors and return 
        them in that order.

        This method must be implemented by each class.
        """
        from yta_editor_nodes_gpu.processor.video.breathing_frame import BreathingFrameVideoNodeProcessorGPU

        node_cpu = None
        node_gpu = BreathingFrameVideoNodeProcessorGPU(
            opengl_context = opengl_context
        )

        return node_cpu, node_gpu