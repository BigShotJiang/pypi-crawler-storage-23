from yta_editor_nodes.processor.video.transitions.base import _TransitionProcessor
from yta_editor_parameters.specifications import ParameterSpecification
from typing import Union


class CircleOpeningTransitionProcessor(_TransitionProcessor):
    """
    A transition between the frames of 2 videos in
    which the frames are mixed by generating a circle
    that grows from the middle to end fitting the 
    whole screen.

    Class that is capable of doing some processing on
    an input by using the GPU or the CPU.

    Mandatory inputs:
    - `first_input`
    - `second_input`

    Optional inputs:
    - `None`
      
    Parameters:
    - `*border_smoothness`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['first_input', 'second_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'border_smoothness',
            type = float,
            is_required = True,
            default = 0.02,
            min = 0.001,
            max = 1.0
        )
    ]

    def __init__(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        super().__init__(
            opengl_context = opengl_context
        )

    def _instantiate_cpu_and_gpu_processors(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        """
        *For internal use only*

        Instantiate the CPU and GPU processors and return 
        them in that order.
        """
        from yta_editor_nodes_gpu.processor.video.transitions.circle_opening import CircleOpeningTransitionNodeProcessorGPU

        node_cpu = None
        node_gpu = CircleOpeningTransitionNodeProcessorGPU(
            opengl_context = opengl_context
        )

        return node_cpu, node_gpu