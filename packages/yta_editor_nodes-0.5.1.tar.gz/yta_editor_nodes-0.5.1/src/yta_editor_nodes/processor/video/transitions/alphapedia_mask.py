from yta_editor_nodes.processor.video.transitions.base import _TransitionProcessor
from typing import Union


class AlphaPediaMaskTransitionProcessor(_TransitionProcessor):
    """
    A transition made by using a custom mask to
    join the 2 videos. This mask is specifically
    obtained from the AlphaPediaYT channel in which
    we upload specific masking videos.

    Both videos will be placed occupying the whole
    scene, just overlapping by using the transition
    video mask, but not moving the frame through 
    the screen like other classes do (like the
    FallingBars).

    Class that is capable of doing some processing on
    an input by using the GPU or the CPU.

    Mandatory inputs:
    - `first_input`
    - `second_input`
    - `mask_input`

    Optional inputs:
    - `None`

      
    Parameters:
    - `None`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['first_input', 'second_input', 'mask_input']
    optional_inputs = []
    parameters_specifications = []

    def _instantiate_cpu_and_gpu_processors(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        """
        *For internal use only*

        Instantiate the CPU and GPU processors and return 
        them in that order.
        """
        from yta_editor_nodes_gpu.processor.video.transitions.alphapedia_mask import AlphaPediaMaskTransitionNodeProcessorGPU

        node_cpu = None
        node_gpu = AlphaPediaMaskTransitionNodeProcessorGPU(
            opengl_context = opengl_context,
        )

        return node_cpu, node_gpu