from yta_editor_nodes.processor.base import _NodeProcessor
from yta_editor_parameters.specifications import ParameterSpecification
from typing import Union


class TransparencyNodeProcessor(_NodeProcessor):
    """
    The node to modify the input provided and
    changes the alpha transparency by using CPU or
    GPU.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`
    
    Parameters:
    - `*transparency`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'transparency',
            type = float,
            is_required = True,
            default = 1.0,
            min = 0.0,
            max = 1.0
        )
    ]

    def __init__(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        super().__init__(
            opengl_context = opengl_context
        )

    def _instantiate_cpu_and_gpu_processors(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        """
        *For internal use only*

        Instantiate the CPU and GPU procesors and return 
        them in that order.

        This method must be implemented by each class.
        """
        from yta_editor_nodes_cpu.processor.transparency import TransparencyNodeProcessorCPU
        from yta_editor_nodes_gpu.processor.transparency import TransparencyNodeProcessorGPU

        node_cpu = TransparencyNodeProcessorCPU()
        node_gpu = TransparencyNodeProcessorGPU(
            opengl_context = opengl_context
        )

        return node_cpu, node_gpu