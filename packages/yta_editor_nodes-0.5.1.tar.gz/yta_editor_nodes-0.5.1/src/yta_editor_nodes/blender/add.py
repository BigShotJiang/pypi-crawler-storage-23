from yta_editor_nodes.blender.base import _Blender
from yta_editor_parameters.specifications import ParameterSpecification
from typing import Union


class AddBlender(_Blender):
    """
    The most common blender used in video edition.

    This blender will increase the brightness by
    combining the colors of the base and the overlay
    inputs, using the overlay as much as the 
    `strength` parameter is indicating.

    Mandatory inputs:
    - `base_input`
    - `overlay_input`

    Optional inputs:
    - `None`

    Parameters:
    - `*mix_weight`
    - `*strength`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input', 'overlay_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'mix_weight',
            type = float,
            is_required = True,
            default = 1.0,
            min = 0.01,
            max = 1.0
        ),
        ParameterSpecification(
            name = 'strength',
            type = float,
            is_required = True,
            default = 1.0,
            min = 0.01,
            max = 1.0
        )
    ]

    def __init__(
        self,
        opengl_context: Union['moderngl.Context', None],
    ):
        super().__init__(
            opengl_context = opengl_context
        )

    def _instantiate_cpu_and_gpu_blenders(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        """
        *For internal use only*

        Instantiate the CPU and GPU blenders and return 
        them in that order.

        This method must be implemented by each class.
        """
        from yta_editor_nodes_cpu.blender.add import AddBlenderCPU
        from yta_editor_nodes_gpu.blender.add import AddBlenderGPU

        node_cpu = AddBlenderCPU()
        node_gpu = AddBlenderGPU(
            opengl_context = opengl_context
        )

        return node_cpu, node_gpu