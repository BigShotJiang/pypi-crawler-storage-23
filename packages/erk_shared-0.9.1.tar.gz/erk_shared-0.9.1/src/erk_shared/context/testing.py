"""Test factories for creating ErkContext instances.

This module provides factory functions for creating test contexts with
fake implementations. These are used by both erk and erk-kits tests.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from erk_shared.context.context import ErkContext
from erk_shared.context.types import GlobalConfig, LoadedConfig, RepoContext

if TYPE_CHECKING:
    from erk.artifacts.paths import ErkPackageInfo
from erk_shared.core.fakes import (
    FakeCodespaceRegistry,
    FakeObjectiveListService,
    FakePlanListService,
    FakePromptExecutor,
    FakeScriptWriter,
)
from erk_shared.core.prompt_executor import PromptExecutor
from erk_shared.gateway.agent_docs.abc import AgentDocs
from erk_shared.gateway.agent_launcher.abc import AgentLauncher
from erk_shared.gateway.claude_installation.abc import ClaudeInstallation
from erk_shared.gateway.codespace.abc import Codespace
from erk_shared.gateway.git.abc import Git
from erk_shared.gateway.github.abc import GitHub
from erk_shared.gateway.github.issues.abc import GitHubIssues
from erk_shared.gateway.github.types import GitHubRepoId, RepoInfo
from erk_shared.gateway.github_admin.abc import GitHubAdmin
from erk_shared.gateway.graphite.abc import Graphite
from erk_shared.gateway.graphite.branch_ops.abc import GraphiteBranchOps
from erk_shared.gateway.graphite.disabled import GraphiteDisabled
from erk_shared.plan_store.backend import PlanBackend
from erk_shared.plan_store.planned_pr import PlannedPRBackend


def context_for_test(
    *,
    github_issues: GitHubIssues | None = None,
    git: Git | None = None,
    github: GitHub | None = None,
    github_admin: GitHubAdmin | None = None,
    graphite: Graphite | None = None,
    claude_installation: ClaudeInstallation | None = None,
    agent_launcher: AgentLauncher | None = None,
    agent_docs: AgentDocs | None = None,
    prompt_executor: PromptExecutor | None = None,
    codespace: Codespace | None = None,
    plan_store: PlanBackend | None = None,
    local_config: LoadedConfig | None = None,
    debug: bool = False,
    repo_root: Path | None = None,
    cwd: Path | None = None,
    repo_info: RepoInfo | None = None,
    package_info: ErkPackageInfo | None = None,
) -> ErkContext:
    """Create test context with optional pre-configured implementations.

    Provides full control over all context parameters with sensible test defaults
    for any unspecified values. Uses fakes by default to avoid subprocess calls.

    This is the factory function for creating test contexts in tests.
    It creates an ErkContext with fake implementations for all services.

    Plan backend defaults to PlannedPRBackend unless explicitly overridden.

    Args:
        github_issues: Optional GitHubIssues implementation. If None, creates FakeGitHubIssues.
        git: Optional Git implementation. If None, creates FakeGit.
        github: Optional GitHub implementation. If None, creates FakeGitHub.
        graphite: Optional Graphite implementation. If None, creates FakeGraphite.
        claude_installation: Optional ClaudeInstallation. If None, creates FakeClaudeInstallation.
        agent_launcher: Optional AgentLauncher. If None, creates FakeAgentLauncher.
        agent_docs: Optional AgentDocs. If None, creates FakeAgentDocs.
        prompt_executor: Optional PromptExecutor. If None, creates FakePromptExecutor.
        codespace: Optional Codespace. If None, creates FakeCodespace.
        plan_store: Optional PlanBackend. If None, creates PlannedPRBackend.
        local_config: Optional LoadedConfig. If None, uses LoadedConfig.test().
        debug: Whether to enable debug mode (default False).
        repo_root: Repository root path (defaults to Path("/fake/repo"))
        cwd: Current working directory (defaults to Path("/fake/worktree"))
        repo_info: Optional RepoInfo (owner/name). If None, repo_info will be None in context.

    Returns:
        ErkContext configured with provided values and test defaults

    Example:
        >>> from erk_shared.gateway.github.issues import FakeGitHubIssues
        >>> from erk_shared.gateway.git.fake import FakeGit
        >>> github = FakeGitHubIssues()
        >>> git_ops = FakeGit()
        >>> ctx = context_for_test(github_issues=github, git=git_ops, debug=True)
    """
    from erk_shared.gateway.agent_docs.fake import FakeAgentDocs
    from erk_shared.gateway.agent_launcher.fake import FakeAgentLauncher
    from erk_shared.gateway.claude_installation.fake import FakeClaudeInstallation
    from erk_shared.gateway.codespace.fake import FakeCodespace
    from erk_shared.gateway.completion.fake import FakeCompletion
    from erk_shared.gateway.console.fake import FakeConsole
    from erk_shared.gateway.erk_installation.fake import FakeErkInstallation
    from erk_shared.gateway.git.fake import FakeGit
    from erk_shared.gateway.github.fake import FakeGitHub
    from erk_shared.gateway.github.issues.fake import FakeGitHubIssues
    from erk_shared.gateway.github_admin.fake import FakeGitHubAdmin
    from erk_shared.gateway.graphite.branch_ops.fake import FakeGraphiteBranchOps
    from erk_shared.gateway.graphite.fake import FakeGraphite
    from erk_shared.gateway.http.fake import FakeHttpClient
    from erk_shared.gateway.shell.fake import FakeShell
    from erk_shared.gateway.time.fake import FakeTime

    # Resolve defaults - create issues first since it's composed into github
    resolved_issues: GitHubIssues = (
        github_issues if github_issues is not None else FakeGitHubIssues()
    )
    resolved_git: Git = git if git is not None else FakeGit()
    # Compose github with issues
    # If github is provided, use it as-is (caller wires issues via FakeGitHub constructor)
    if github is None:
        resolved_github: GitHub = FakeGitHub(issues_gateway=resolved_issues)
    else:
        resolved_github = github
    resolved_graphite: Graphite = graphite if graphite is not None else FakeGraphite()

    if isinstance(resolved_graphite, GraphiteDisabled):
        resolved_graphite_branch_ops: GraphiteBranchOps | None = None
    elif isinstance(resolved_graphite, FakeGraphite):
        resolved_graphite_branch_ops = resolved_graphite.create_linked_branch_ops()
    else:
        resolved_graphite_branch_ops = FakeGraphiteBranchOps()
    resolved_repo_root: Path = repo_root if repo_root is not None else Path("/fake/repo")
    resolved_claude_installation: ClaudeInstallation = (
        claude_installation
        if claude_installation is not None
        else FakeClaudeInstallation.for_test()
    )
    resolved_prompt_executor: PromptExecutor = (
        prompt_executor if prompt_executor is not None else FakePromptExecutor()
    )
    resolved_agent_launcher: AgentLauncher = (
        agent_launcher if agent_launcher is not None else FakeAgentLauncher()
    )
    resolved_agent_docs: AgentDocs = (
        agent_docs if agent_docs is not None else FakeAgentDocs(files={}, has_docs_dir=True)
    )
    resolved_codespace: Codespace = codespace if codespace is not None else FakeCodespace()
    resolved_cwd: Path = cwd if cwd is not None else Path("/fake/worktree")

    # Create repo context
    repo_dir = Path("/fake/erk/repos") / resolved_repo_root.name
    github_repo_id: GitHubRepoId | None = None
    if repo_info is not None:
        github_repo_id = GitHubRepoId(owner=repo_info.owner, repo=repo_info.name)
    repo = RepoContext(
        root=resolved_repo_root,
        repo_name=resolved_repo_root.name,
        repo_dir=repo_dir,
        worktrees_dir=repo_dir / "worktrees",
        pool_json_path=repo_dir / "pool.json",
        github=github_repo_id,
    )

    fake_time = FakeTime()
    fake_console = FakeConsole(
        is_interactive=True,
        is_stdout_tty=None,
        is_stderr_tty=None,
        confirm_responses=None,
    )

    resolved_local_config = local_config if local_config is not None else LoadedConfig.test()

    # Resolve plan_store: explicit > PlannedPRBackend default
    resolved_plan_store: PlanBackend
    if plan_store is not None:
        resolved_plan_store = plan_store
    else:
        resolved_plan_store = PlannedPRBackend(resolved_github, resolved_issues, time=FakeTime())

    return ErkContext(
        git=resolved_git,
        github=resolved_github,
        github_admin=github_admin if github_admin is not None else FakeGitHubAdmin(),
        claude_installation=resolved_claude_installation,
        prompt_executor=resolved_prompt_executor,
        graphite=resolved_graphite,
        graphite_branch_ops=resolved_graphite_branch_ops,
        console=fake_console,
        time=fake_time,
        erk_installation=FakeErkInstallation(),
        agent_docs=resolved_agent_docs,
        plan_store=resolved_plan_store,
        shell=FakeShell(),
        completion=FakeCompletion(),
        codespace=resolved_codespace,
        agent_launcher=resolved_agent_launcher,
        script_writer=FakeScriptWriter(),
        codespace_registry=FakeCodespaceRegistry(),
        plan_list_service=FakePlanListService(),
        objective_list_service=FakeObjectiveListService(data=None),
        cwd=resolved_cwd,
        repo=repo,
        repo_info=repo_info,
        global_config=GlobalConfig.test(
            erk_root=Path("/fake/erk"),
        ),
        local_config=resolved_local_config,
        package_info=package_info,
        http_client=FakeHttpClient(),
        dry_run=False,
        debug=debug,
    )
