"""Legacy fake implementations have been removed.

This module previously contained FakeGitHubGtKitOps, which has been
consolidated into the unified FakeGitHub from erk_shared.gateway.github.fake.

Tests should use FakeGitHub from erk_shared.gateway.github for all GitHub operations.
"""
