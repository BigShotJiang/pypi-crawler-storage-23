"""GitHub integration utilities.

Import from submodules:
- abc: GitHub
- types: PRInfo, PRMergeability, PRState, PullRequestInfo, WorkflowRun
- metadata: types, schemas, core (metadata block API)
- parsing: _parse_github_pr_url
- issues: GitHubIssues, RealGitHubIssues, FakeGitHubIssues, etc.
- real: RealGitHub
"""
