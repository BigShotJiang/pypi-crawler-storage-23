"""Enterprise security: RBAC, scoped tokens, policies, and audit export."""
