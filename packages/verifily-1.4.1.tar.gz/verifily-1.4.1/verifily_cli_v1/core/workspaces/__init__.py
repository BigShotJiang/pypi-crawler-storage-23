"""Workspaces: multi-tenant org/project/key management with JSON file store."""
