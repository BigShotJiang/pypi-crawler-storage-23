# src/ImageStego/obfuscation/__init__.py

"""
obfuscation 模块：提供各种图像混淆方法
"""

## 图片相关
# 像素级随机置换
from .pixel_scramble import (
    obfuscate as pixel_obfuscate,
    deobfuscate as pixel_deobfuscate,
)

# 块级随机置换
from .block_scramble import (
    obfuscate as block_obfuscate,
    deobfuscate as block_deobfuscate,
)

# ArnoldCat
from .arnold_cat_map import (
    obfuscate as arnold_cat_obfuscate,
    deobfuscate as arnold_cat_deobfuscate,
)

#BakerMap
from .bakers_map import (
    obfuscate as bakers_obfuscate,
    deobfuscate as bakers_deobfuscate,
)

#HenonMap
from .henon_map import (
    obfuscate as henon_obfuscate,
    deobfuscate as henon_deobfuscate,
)

## 视频相关
#gif
from .gif_scramble import (
    obfuscate as obfuscate_gif,
    deobfuscate as deobfuscate_gif,
)

#mp4
from .mp4_scramble import (
    obfuscate as obfuscate_mp4,
    deobfuscate as deobfuscate_mp4,
)

# 可以加一个方便的 __all__，控制 from obfuscation import * 的行为
__all__ = [
    "pixel_obfuscate",
    "pixel_deobfuscate",
    "block_obfuscate",
    "block_deobfuscate",
    "arnold_cat_obfuscate",
    "arnold_cat_deobfuscate",
    "bakers_obfuscate",
    "bakers_deobfuscate",
    "henon_obfuscate",
    "henon_deobfuscate",
    "obfuscate_gif",
    "deobfuscate_gif",
    "obfuscate_mp4",
    "deobfuscate_mp4",
]