# ImageStego
ImageStego may be a versatile multimedia processing tool, it features an intuitive web interface built with PyWebIO
## Features

- **Image Obfuscation**  
  Multiple scrambling algorithms to distort images:
  - Pixel Scramble
  - Block Scramble
  - Arnold Cat Map
  - Baker's Map
  - Henon Map

- **GIF Obfuscation**  
  Frame‑wise scrambling of animated GIFs

- **MP4 Obfuscation**  
  Video‑level scrambling using frame permutation.

- **Image Steganography (LSB)**  
  Hide secret messages inside PNG/JPG/BMP images:

## Installation
```bash
pip install imagestego
```
## Quick Start
Launch the GUI
After installation, simply run:
```bash
image-stego-gui
```
The web interface will open automatically in your default browser.

## Use in Python Code
You can also import the modules directly in your Python scripts:
```python
from ImageStego.obfuscation import *
from ImageStego.steganography import *
```