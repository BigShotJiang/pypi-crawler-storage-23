"""Gateway mode — HTTP bridge and operation dispatch."""
from __future__ import annotations
