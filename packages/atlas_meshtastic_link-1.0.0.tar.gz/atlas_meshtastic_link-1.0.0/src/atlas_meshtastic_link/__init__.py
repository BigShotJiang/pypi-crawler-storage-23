"""Atlas Meshtastic Link — dual-mode gateway/asset link over Meshtastic radios."""
from __future__ import annotations

__version__ = "0.1.0"

from atlas_meshtastic_link._link import run

__all__ = ["run", "__version__"]
