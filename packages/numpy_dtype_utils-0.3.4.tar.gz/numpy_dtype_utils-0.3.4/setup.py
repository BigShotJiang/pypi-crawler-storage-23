from setuptools import setup, find_packages

setup(
    name="numpy-dtype-utils",
    version="0.3.4",
    author="Takumi Sekiguchi",
    author_email="[EMAIL_ADDRESS]",
    description="Advanced data type handling, gaze estimation, and dataset utilities for NumPy.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/numpy-dtype-utils",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering",
    ],
    python_requires='>=3.8',
    install_requires=[
        "numpy",
        "pandas",
        "scipy",
        "matplotlib",
        "seaborn",
        "scikit-learn",
        "torch",
        "fastapi",
        "uvicorn",
        "Pillow",
        "pydantic",
        "streamlit",
    ],
    extras_require={
        "test": ["pytest"],
    },
    package_data={
        "numpy_dtype_utils": ["docs/CHEATSHEET.md"],
    },
)

