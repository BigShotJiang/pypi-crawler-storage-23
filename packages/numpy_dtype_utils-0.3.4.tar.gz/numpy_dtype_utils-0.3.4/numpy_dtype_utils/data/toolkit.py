"""
=============================================================================
COMPETITION DATA TOOLKIT — All-in-one data science Swiss Army knife
=============================================================================
Everything you might need at a competition in ONE file:

  1. FORMAT DETECTION & SMART LOADING (csv, json, mat, npz, hdf5, parquet, images)
  2. QUICK EDA — instant statistics, shape, types, missing values summary
  3. DATA CLEANING — NaN/Inf/outliers/duplicates with multiple strategies
  4. FEATURE ENGINEERING — encoding, binning, interactions, time features
  5. TRANSFORMATIONS — normalization, standardization, log, box-cox, power
  6. DISTRIBUTION ANALYSIS — fit distributions, test normality, detect type
  7. CORRELATION & MULTICOLLINEARITY — VIF, pair detection, drop suggestions
  8. DIMENSIONALITY REDUCTION — PCA, t-SNE wrappers
  9. SPLITTING STRATEGIES — stratified, grouped, time-based, LOPO
  10. EVALUATION METRICS — regression, classification, gaze-specific
  11. PLOTTING HELPERS — one-liners for common plots
  12. IMAGE PREPROCESSING — resize, normalize, augment for CV tasks
  13. EXPORT UTILITIES — save to any format, generate report text

Usage:
    from numpy_dtype_utils.data.toolkit import *

    # Quick EDA
    quick_eda(df)

    # Clean everything in one call
    df_clean = auto_clean(df)

    # Full analysis pipeline
    run_full_analysis(df_clean, save_dir="./plots")
=============================================================================
"""

import os
import warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  1. FORMAT DETECTION & SMART LOADING                                    ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def smart_load(path: str, **kwargs) -> pd.DataFrame:
    """
    Automatically detect file format and load into a DataFrame.
    Works with: csv, tsv, json, xlsx, parquet, feather, mat, npz, npy, hdf5.

    Args:
        path: file or directory path
        **kwargs: passed to the underlying loader

    Returns:
        pd.DataFrame

    Examples:
        df = smart_load("data.csv")
        df = smart_load("data.json")
        df = smart_load("experiment.mat")
        df = smart_load("folder_of_csvs/")
    """
    # If it's a directory, load all CSVs inside
    if os.path.isdir(path):
        return _load_directory(path, **kwargs)

    ext = os.path.splitext(path)[1].lower()

    loaders = {
        ".csv":     lambda: pd.read_csv(path, **kwargs),
        ".tsv":     lambda: pd.read_csv(path, sep="\t", **kwargs),
        ".json":    lambda: pd.read_json(path, **kwargs),
        ".jsonl":   lambda: pd.read_json(path, lines=True, **kwargs),
        ".xlsx":    lambda: pd.read_excel(path, **kwargs),
        ".xls":     lambda: pd.read_excel(path, **kwargs),
        ".parquet": lambda: pd.read_parquet(path, **kwargs),
        ".feather": lambda: pd.read_feather(path, **kwargs),
        ".mat":     lambda: _load_mat_to_df(path),
        ".npz":     lambda: _load_npz_to_df(path),
        ".npy":     lambda: pd.DataFrame(np.load(path, allow_pickle=True)),
        ".h5":      lambda: _load_hdf5_to_df(path),
        ".hdf5":    lambda: _load_hdf5_to_df(path),
        ".pkl":     lambda: pd.read_pickle(path, **kwargs),
        ".pickle":  lambda: pd.read_pickle(path, **kwargs),
    }

    if ext not in loaders:
        raise ValueError(
            f"Unknown format: '{ext}'. Supported: {list(loaders.keys())}"
        )

    df = loaders[ext]()
    print(f"✓ Loaded {path} → {df.shape[0]} rows × {df.shape[1]} cols")
    return df


def _load_directory(dir_path: str, pattern: str = "*.csv", **kwargs) -> pd.DataFrame:
    """Load all matching files from a directory into one DataFrame."""
    import glob
    files = sorted(glob.glob(os.path.join(dir_path, "**", pattern), recursive=True))
    if not files:
        raise FileNotFoundError(f"No files matching '{pattern}' in {dir_path}")
    frames = []
    for f in files:
        frames.append(pd.read_csv(f, **kwargs))
    combined = pd.concat(frames, ignore_index=True)
    print(f"✓ Loaded {len(files)} files from {dir_path} → {combined.shape}")
    return combined


def _load_mat_to_df(path: str) -> pd.DataFrame:
    """Convert .mat file to DataFrame (best effort)."""
    from scipy.io import loadmat
    mat = loadmat(path, squeeze_me=True)
    clean = {k: v for k, v in mat.items() if not k.startswith("__")}

    # Try to find the largest 2D array
    best_key, best_arr = None, None
    for k, v in clean.items():
        if isinstance(v, np.ndarray) and v.ndim == 2:
            if best_arr is None or v.size > best_arr.size:
                best_key, best_arr = k, v

    if best_arr is not None:
        return pd.DataFrame(best_arr,
                            columns=[f"{best_key}_{i}" for i in range(best_arr.shape[1])])

    # Fallback: flatten everything into columns
    flat = {}
    for k, v in clean.items():
        if isinstance(v, np.ndarray) and v.ndim == 1:
            flat[k] = v
    if flat:
        min_len = min(len(v) for v in flat.values())
        return pd.DataFrame({k: v[:min_len] for k, v in flat.items()})

    raise ValueError(f"Cannot auto-convert {path} to DataFrame. Keys: {list(clean.keys())}")


def _load_npz_to_df(path: str) -> pd.DataFrame:
    """Convert .npz file to DataFrame."""
    data = np.load(path, allow_pickle=True)
    # Try common key patterns
    for key in ["X", "data", "features", "X_train"]:
        if key in data and data[key].ndim == 2:
            return pd.DataFrame(data[key],
                                columns=[f"f{i}" for i in range(data[key].shape[1])])
    # Use the first 2D array found
    for key in data.keys():
        if data[key].ndim == 2:
            return pd.DataFrame(data[key],
                                columns=[f"{key}_{i}" for i in range(data[key].shape[1])])
    raise ValueError(f"No 2D arrays found in {path}. Keys: {list(data.keys())}")


def _load_hdf5_to_df(path: str) -> pd.DataFrame:
    """Convert HDF5 to DataFrame."""
    try:
        return pd.read_hdf(path)
    except Exception:
        import h5py
        with h5py.File(path, "r") as f:
            arrays = {}
            def _collect(name, obj):
                if hasattr(obj, "shape") and len(obj.shape) <= 2:
                    arrays[name] = np.array(obj)
            f.visititems(_collect)

        if not arrays:
            raise ValueError(f"No datasets found in {path}")
        # Pick largest
        key = max(arrays, key=lambda k: arrays[k].size)
        arr = arrays[key]
        if arr.ndim == 1:
            return pd.DataFrame({key: arr})
        return pd.DataFrame(arr, columns=[f"{key}_{i}" for i in range(arr.shape[1])])


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  2. QUICK EDA — Instant overview                                        ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def quick_eda(df: pd.DataFrame, top_n: int = 20) -> dict:
    """
    Print a comprehensive instant overview of any DataFrame.
    Run this FIRST on any new dataset to understand what you have.

    Returns a dict with all computed stats for programmatic use.

    Example:
        stats = quick_eda(df)
    """
    numeric = df.select_dtypes(include=[np.number])
    non_numeric = df.select_dtypes(exclude=[np.number])

    print(f"\n{'═'*70}")
    print(f"  QUICK EDA — {df.shape[0]:,} rows × {df.shape[1]} columns")
    print(f"{'═'*70}")

    # Shape and memory
    mem_mb = df.memory_usage(deep=True).sum() / 1024**2
    print(f"\n  Memory usage: {mem_mb:.2f} MB")
    print(f"  Numeric cols: {len(numeric.columns)}")
    print(f"  Non-numeric cols: {len(non_numeric.columns)}")

    # Missing values
    missing = df.isnull().sum()
    missing_pct = (missing / len(df) * 100).round(2)
    has_missing = missing[missing > 0]
    print(f"\n  Missing values: {has_missing.sum()} total in {len(has_missing)} columns")
    if len(has_missing) > 0:
        for col in has_missing.index[:top_n]:
            print(f"    {col}: {has_missing[col]:,} ({missing_pct[col]:.1f}%)")

    # Duplicates
    dup_count = df.duplicated().sum()
    print(f"\n  Duplicate rows: {dup_count} ({dup_count/len(df)*100:.1f}%)")

    # Numeric columns summary
    if len(numeric.columns) > 0:
        print(f"\n  NUMERIC COLUMNS:")
        print(f"  {'Column':<25} {'dtype':<10} {'min':>12} {'max':>12} {'mean':>12} {'std':>12} {'zeros':>6}")
        print(f"  {'─'*89}")
        for col in numeric.columns[:top_n]:
            s = numeric[col]
            zeros = (s == 0).sum()
            print(f"  {col:<25} {str(s.dtype):<10} {s.min():>12.4f} {s.max():>12.4f} "
                  f"{s.mean():>12.4f} {s.std():>12.4f} {zeros:>6}")

    # Non-numeric columns summary
    if len(non_numeric.columns) > 0:
        print(f"\n  NON-NUMERIC COLUMNS:")
        print(f"  {'Column':<25} {'dtype':<10} {'unique':>8} {'top value':<30} {'freq':>6}")
        print(f"  {'─'*85}")
        for col in non_numeric.columns[:top_n]:
            s = non_numeric[col]
            top_val = s.mode().iloc[0] if len(s.mode()) > 0 else "N/A"
            top_freq = (s == top_val).sum() if top_val != "N/A" else 0
            print(f"  {col:<25} {str(s.dtype):<10} {s.nunique():>8} "
                  f"{str(top_val)[:30]:<30} {top_freq:>6}")

    # Constant columns (useless)
    const_cols = [c for c in df.columns if df[c].nunique() <= 1]
    if const_cols:
        print(f"\n  ⚠ CONSTANT COLUMNS (drop these!): {const_cols}")

    # High cardinality (potential IDs)
    high_card = [c for c in non_numeric.columns if df[c].nunique() > len(df) * 0.9]
    if high_card:
        print(f"  ⚠ HIGH CARDINALITY (possible IDs): {high_card}")

    print(f"\n{'═'*70}")

    return {
        "shape": df.shape,
        "memory_mb": mem_mb,
        "numeric_cols": list(numeric.columns),
        "non_numeric_cols": list(non_numeric.columns),
        "missing": missing.to_dict(),
        "duplicates": dup_count,
        "constant_cols": const_cols,
    }


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  3. DATA CLEANING — Multiple strategies                                 ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def auto_clean(df: pd.DataFrame,
               drop_metadata: bool = True,
               nan_strategy: str = "drop",
               outlier_method: str = "iqr",
               outlier_factor: float = 1.5,
               verbose: bool = True) -> pd.DataFrame:
    """
    All-in-one cleaning pipeline with configurable strategies.

    Args:
        df: input DataFrame
        drop_metadata: if True, drops non-numeric columns
        nan_strategy: how to handle NaN:
            'drop'   — remove rows (default, safest)
            'mean'   — fill with column mean
            'median' — fill with column median
            'zero'   — fill with 0
            'ffill'  — forward fill (for time-series)
        outlier_method: how to remove outliers:
            'iqr'    — IQR method (default, robust)
            'zscore' — Z-score method (assumes normality)
            'none'   — don't remove outliers
        outlier_factor: IQR multiplier (1.5 standard, 3.0 conservative)
        verbose: print stats

    Returns:
        cleaned DataFrame
    """
    if verbose:
        print(f"\n{'─'*50}")
        print(f"CLEANING: {df.shape[0]:,} rows × {df.shape[1]} cols")

    df = df.copy()
    initial = len(df)

    # 1. Drop non-numeric metadata
    if drop_metadata:
        non_num = df.select_dtypes(exclude=[np.number]).columns.tolist()
        if non_num:
            df = df.drop(columns=non_num)
            if verbose:
                print(f"  Dropped metadata: {non_num}")

    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()

    # 2. Handle NaN
    nan_before = df[numeric_cols].isna().sum().sum()
    if nan_strategy == "drop":
        df = df.dropna(subset=numeric_cols)
    elif nan_strategy == "mean":
        df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean())
    elif nan_strategy == "median":
        df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].median())
    elif nan_strategy == "zero":
        df[numeric_cols] = df[numeric_cols].fillna(0)
    elif nan_strategy == "ffill":
        df[numeric_cols] = df[numeric_cols].fillna(method="ffill").fillna(method="bfill")
    if verbose:
        print(f"  NaN handled ({nan_strategy}): {nan_before} values")

    # 3. Handle Inf
    inf_mask = np.isinf(df[numeric_cols]).any(axis=1)
    inf_count = inf_mask.sum()
    df = df[~inf_mask]
    if verbose:
        print(f"  Inf removed: {inf_count}")

    # 4. Outliers
    if outlier_method == "iqr":
        Q1 = df[numeric_cols].quantile(0.25)
        Q3 = df[numeric_cols].quantile(0.75)
        IQR = Q3 - Q1
        mask = ~((df[numeric_cols] < (Q1 - outlier_factor * IQR)) |
                 (df[numeric_cols] > (Q3 + outlier_factor * IQR))).any(axis=1)
        outlier_count = (~mask).sum()
        df = df[mask]
        if verbose:
            print(f"  Outliers (IQR×{outlier_factor}): {outlier_count}")
    elif outlier_method == "zscore":
        from scipy import stats as sp_stats
        z = np.abs(sp_stats.zscore(df[numeric_cols]))
        mask = (z < 3).all(axis=1)
        outlier_count = (~mask).sum()
        df = df[mask]
        if verbose:
            print(f"  Outliers (Z>3): {outlier_count}")

    # 5. Duplicates
    dup_count = df.duplicated().sum()
    df = df.drop_duplicates()
    if verbose:
        print(f"  Duplicates: {dup_count}")

    df = df.reset_index(drop=True)
    removed = initial - len(df)
    if verbose:
        print(f"  Result: {len(df):,} rows ({removed:,} removed, {removed/initial*100:.1f}%)")
        print(f"{'─'*50}")

    return df


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  4. FEATURE ENGINEERING                                                 ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def encode_categoricals(df: pd.DataFrame,
                        method: str = "label",
                        columns: list = None) -> pd.DataFrame:
    """
    Encode categorical (non-numeric) columns.

    Args:
        df: input DataFrame
        method:
            'label'   — LabelEncoder (0, 1, 2, ...) — for ordinal or tree models
            'onehot'  — OneHotEncoder (dummy columns) — for linear/NN models
            'target'  — Target encoding (requires target column)
        columns: specific columns to encode (default: all non-numeric)

    Returns:
        DataFrame with encoded columns
    """
    df = df.copy()

    if columns is None:
        columns = df.select_dtypes(exclude=[np.number]).columns.tolist()

    if not columns:
        print("No categorical columns to encode.")
        return df

    if method == "label":
        from sklearn.preprocessing import LabelEncoder
        for col in columns:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].astype(str))
            print(f"  LabelEncoded '{col}': {le.classes_[:5]}{'...' if len(le.classes_) > 5 else ''}")

    elif method == "onehot":
        df = pd.get_dummies(df, columns=columns, drop_first=True)
        print(f"  OneHot: {len(columns)} cols → {len(df.columns)} total cols")

    return df


def add_interaction_features(df: pd.DataFrame,
                             columns: list = None,
                             operations: list = None) -> pd.DataFrame:
    """
    Create interaction features between numeric columns.
    Useful when you suspect multiplicative or ratio relationships.

    Args:
        columns: which columns to combine (default: all numeric)
        operations: list of operations ('multiply', 'ratio', 'diff', 'sum')
    """
    df = df.copy()
    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns.tolist()
    if operations is None:
        operations = ["multiply", "ratio"]

    new_cols = 0
    for i, col_a in enumerate(columns):
        for col_b in columns[i+1:]:
            if "multiply" in operations:
                df[f"{col_a}_x_{col_b}"] = df[col_a] * df[col_b]
                new_cols += 1
            if "ratio" in operations:
                df[f"{col_a}_div_{col_b}"] = df[col_a] / (df[col_b] + 1e-8)
                new_cols += 1
            if "diff" in operations:
                df[f"{col_a}_minus_{col_b}"] = df[col_a] - df[col_b]
                new_cols += 1
            if "sum" in operations:
                df[f"{col_a}_plus_{col_b}"] = df[col_a] + df[col_b]
                new_cols += 1

    print(f"  Added {new_cols} interaction features → {len(df.columns)} total cols")
    return df


def add_polynomial_features(df: pd.DataFrame,
                             columns: list = None,
                             degree: int = 2) -> pd.DataFrame:
    """
    Add polynomial features (x², x³, etc.).
    Good for capturing non-linear patterns with linear models.
    """
    df = df.copy()
    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns.tolist()

    for col in columns:
        for d in range(2, degree + 1):
            df[f"{col}_pow{d}"] = df[col] ** d

    print(f"  Added polynomial features (degree={degree}) for {len(columns)} columns")
    return df


def add_statistical_features(df: pd.DataFrame,
                              columns: list = None) -> pd.DataFrame:
    """
    Add row-wise statistical features (mean, std, min, max, range)
    across the specified columns. Very useful for tabular competitions.
    """
    df = df.copy()
    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns.tolist()

    subset = df[columns]
    df["row_mean"] = subset.mean(axis=1)
    df["row_std"] = subset.std(axis=1)
    df["row_min"] = subset.min(axis=1)
    df["row_max"] = subset.max(axis=1)
    df["row_range"] = df["row_max"] - df["row_min"]
    df["row_median"] = subset.median(axis=1)

    print(f"  Added 6 row-wise statistical features")
    return df


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  5. TRANSFORMATIONS                                                     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def normalize(df: pd.DataFrame, method: str = "standard",
              columns: list = None) -> tuple:
    """
    Normalize/standardize numeric columns.

    Args:
        method:
            'standard'  — zero mean, unit variance (Z-score) — MOST COMMON for NN/SVM
            'minmax'    — scale to [0, 1] range
            'robust'    — uses median and IQR, resistant to outliers
            'maxabs'    — scale to [-1, 1] by dividing by max abs value
        columns: columns to scale (default: all numeric)

    Returns:
        (transformed_df, scaler) — keep the scaler for inverse transform!

    Example:
        df_scaled, scaler = normalize(df, method='standard')
        # Later: original = scaler.inverse_transform(df_scaled[columns].values)
    """
    from sklearn.preprocessing import (StandardScaler, MinMaxScaler,
                                        RobustScaler, MaxAbsScaler)
    df = df.copy()
    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns.tolist()

    scalers = {
        "standard": StandardScaler(),
        "minmax": MinMaxScaler(),
        "robust": RobustScaler(),
        "maxabs": MaxAbsScaler(),
    }

    scaler = scalers.get(method)
    if scaler is None:
        raise ValueError(f"Unknown method: {method}. Use: {list(scalers.keys())}")

    df[columns] = scaler.fit_transform(df[columns])
    print(f"  Applied {method} scaling to {len(columns)} columns")
    return df, scaler


def apply_transforms(df: pd.DataFrame, columns: list = None,
                     transforms: list = None) -> pd.DataFrame:
    """
    Apply mathematical transforms to fix skewed distributions.

    Args:
        transforms: list of transforms to try:
            'log'     — log(x+1), good for right-skewed data
            'sqrt'    — sqrt(x), mild right-skew correction
            'boxcox'  — Box-Cox (automatically finds best power transform)
            'yeo'     — Yeo-Johnson (works with negative values too!)

    Example:
        df = apply_transforms(df, columns=['price', 'area'], transforms=['log', 'sqrt'])
    """
    df = df.copy()
    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns.tolist()
    if transforms is None:
        transforms = ["log"]

    for col in columns:
        for t in transforms:
            if t == "log":
                min_val = df[col].min()
                shift = abs(min_val) + 1 if min_val <= 0 else 0
                df[f"{col}_log"] = np.log1p(df[col] + shift)
            elif t == "sqrt":
                min_val = df[col].min()
                shift = abs(min_val) if min_val < 0 else 0
                df[f"{col}_sqrt"] = np.sqrt(df[col] + shift)
            elif t == "boxcox":
                from scipy.stats import boxcox
                data = df[col].values
                if (data > 0).all():
                    transformed, lam = boxcox(data)
                    df[f"{col}_boxcox"] = transformed
                    print(f"    Box-Cox '{col}': λ={lam:.3f}")
            elif t == "yeo":
                from sklearn.preprocessing import PowerTransformer
                pt = PowerTransformer(method="yeo-johnson")
                df[f"{col}_yeo"] = pt.fit_transform(df[[col]])

    print(f"  Applied {transforms} to {len(columns)} columns")
    return df


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  6. DISTRIBUTION ANALYSIS                                               ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def analyze_distributions(df: pd.DataFrame,
                          columns: list = None,
                          sample_size: int = 5000) -> dict:
    """
    Determine the distribution type of each numeric column.

    For each column:
      - Runs Shapiro-Wilk normality test
      - Computes skewness and kurtosis
      - Attempts to fit common distributions (norm, laplace, uniform, expon)
      - Returns the best-fit distribution name

    Args:
        sample_size: max rows for Shapiro-Wilk test (speed limit)

    Returns:
        dict of {column: {type, skewness, kurtosis, shapiro_p, best_fit, ...}}
    """
    from scipy import stats as sp_stats

    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns.tolist()

    results = {}

    print(f"\n{'─'*70}")
    print(f"  DISTRIBUTION ANALYSIS")
    print(f"  {'Column':<20} {'Type':<25} {'Skew':>8} {'Kurt':>8} {'Shapiro-p':>10} {'Best fit':<12}")
    print(f"  {'─'*83}")

    for col in columns:
        data = df[col].dropna().values

        # Shapiro-Wilk test
        sample = data[:sample_size] if len(data) > sample_size else data
        try:
            _, shapiro_p = sp_stats.shapiro(sample)
        except Exception:
            shapiro_p = 0.0

        skew = float(sp_stats.skew(data))
        kurt = float(sp_stats.kurtosis(data))

        # Determine type by statistics
        if shapiro_p > 0.05:
            dist_type = "Normal"
        elif kurt < -0.8:
            dist_type = "Uniform (flat)"
        elif abs(skew) > 1.0:
            dist_type = f"Skewed {'right' if skew > 0 else 'left'}"
        elif abs(skew) > 0.4:
            dist_type = f"Moderately skewed {'R' if skew > 0 else 'L'}"
        elif kurt > 1.0:
            dist_type = "Leptokurtic (peaked)"
        elif abs(skew) < 0.3 and abs(kurt) < 0.5:
            dist_type = "Near-normal"
        else:
            dist_type = "Non-standard"

        # Fit common distributions via KS test
        best_fit_name = "unknown"
        best_p = 0
        for dist in [sp_stats.norm, sp_stats.laplace, sp_stats.uniform, sp_stats.expon]:
            try:
                params = dist.fit(data)
                _, ks_p = sp_stats.kstest(data, dist.name, args=params)
                if ks_p > best_p:
                    best_p = ks_p
                    best_fit_name = dist.name
            except Exception:
                continue

        results[col] = {
            "type": dist_type,
            "skewness": round(skew, 4),
            "kurtosis": round(kurt, 4),
            "shapiro_p": round(shapiro_p, 6),
            "best_fit": best_fit_name,
            "best_fit_p": round(best_p, 6),
            "is_normal": shapiro_p > 0.05,
        }

        print(f"  {col:<20} {dist_type:<25} {skew:>8.3f} {kurt:>8.3f} {shapiro_p:>10.6f} {best_fit_name:<12}")

    print(f"{'─'*70}")
    return results


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  7. CORRELATION & MULTICOLLINEARITY                                     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def find_high_correlations(df: pd.DataFrame,
                           threshold: float = 0.8,
                           columns: list = None) -> list:
    """
    Find pairs of highly correlated features.
    These might be redundant — consider dropping one from each pair.

    Returns:
        list of (col_a, col_b, correlation_value) sorted by abs(correlation)
    """
    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns.tolist()

    corr = df[columns].corr()
    pairs = []

    for i in range(len(columns)):
        for j in range(i + 1, len(columns)):
            r = corr.iloc[i, j]
            if abs(r) >= threshold:
                pairs.append((columns[i], columns[j], round(r, 4)))

    pairs.sort(key=lambda x: abs(x[2]), reverse=True)

    if pairs:
        print(f"\n  High correlations (|r| ≥ {threshold}):")
        for a, b, r in pairs:
            print(f"    {a} ↔ {b}: r = {r}")
    else:
        print(f"  No pairs with |r| ≥ {threshold}")

    return pairs


def compute_vif(df: pd.DataFrame, columns: list = None) -> pd.DataFrame:
    """
    Compute Variance Inflation Factor for multicollinearity detection.
    VIF > 5 means moderate multicollinearity.
    VIF > 10 means severe — consider dropping the feature.

    Returns:
        DataFrame with columns ['feature', 'vif']
    """
    from sklearn.linear_model import LinearRegression

    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns.tolist()

    X = df[columns].values
    vifs = []

    for i in range(X.shape[1]):
        y_i = X[:, i]
        X_others = np.delete(X, i, axis=1)

        if X_others.shape[1] == 0:
            vifs.append(1.0)
            continue

        model = LinearRegression().fit(X_others, y_i)
        r2 = model.score(X_others, y_i)
        vif = 1.0 / (1.0 - r2 + 1e-10)
        vifs.append(round(vif, 2))

    result = pd.DataFrame({"feature": columns, "vif": vifs})
    result = result.sort_values("vif", ascending=False).reset_index(drop=True)

    print(f"\n  VIF Analysis:")
    for _, row in result.iterrows():
        flag = " ⚠ HIGH" if row["vif"] > 5 else ""
        print(f"    {row['feature']:<25} VIF = {row['vif']:>8.2f}{flag}")

    return result


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  8. DIMENSIONALITY REDUCTION                                            ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def run_pca(df: pd.DataFrame, n_components: int = None,
            variance_threshold: float = 0.95,
            columns: list = None) -> tuple:
    """
    Run PCA with automatic component selection.

    Args:
        n_components: exact number of components (overrides variance_threshold)
        variance_threshold: keep components until this cumulative variance is reached

    Returns:
        (transformed_df, pca_object, explained_variance_ratios)
    """
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler

    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns.tolist()

    X = StandardScaler().fit_transform(df[columns].values)

    # First, fit full PCA to determine optimal components
    if n_components is None:
        pca_full = PCA().fit(X)
        cumvar = np.cumsum(pca_full.explained_variance_ratio_)
        n_components = int(np.argmax(cumvar >= variance_threshold) + 1)
        n_components = max(1, n_components)
        print(f"  PCA: {len(columns)} features → {n_components} components "
              f"({cumvar[n_components-1]*100:.1f}% variance)")

    pca = PCA(n_components=n_components)
    X_pca = pca.fit_transform(X)

    pca_df = pd.DataFrame(X_pca,
                           columns=[f"PC{i+1}" for i in range(n_components)],
                           index=df.index)

    print(f"  Explained variance: {pca.explained_variance_ratio_.round(4)}")
    return pca_df, pca, pca.explained_variance_ratio_


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  9. SPLITTING STRATEGIES                                                ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def smart_split(X, y, method: str = "random", test_size: float = 0.2,
                groups=None, **kwargs):
    """
    Universal train/test splitting with multiple strategies.

    Args:
        method:
            'random'     — simple random split (default)
            'stratified' — maintain class distribution (for classification)
            'grouped'    — keep groups together (e.g., same participant)
            'time'       — first N% for train, rest for test (time-series)

    Returns:
        (X_train, X_test, y_train, y_test)
    """
    from sklearn.model_selection import train_test_split, GroupShuffleSplit

    X = np.array(X) if not isinstance(X, np.ndarray) else X
    y = np.array(y) if not isinstance(y, np.ndarray) else y

    if method == "random":
        return train_test_split(X, y, test_size=test_size, random_state=42)

    elif method == "stratified":
        return train_test_split(X, y, test_size=test_size, random_state=42,
                                stratify=y)

    elif method == "grouped":
        if groups is None:
            raise ValueError("groups array required for 'grouped' splitting")
        gss = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=42)
        train_idx, test_idx = next(gss.split(X, y, groups))
        return X[train_idx], X[test_idx], y[train_idx], y[test_idx]

    elif method == "time":
        split_idx = int(len(X) * (1 - test_size))
        return X[:split_idx], X[split_idx:], y[:split_idx], y[split_idx:]

    else:
        raise ValueError(f"Unknown method: {method}")


def leave_one_participant_out(X, y, participants):
    """
    Leave-One-Participant-Out cross-validation generator.
    Yields (X_train, X_test, y_train, y_test, test_participant) for each participant.

    Args:
        X: feature array
        y: target array
        participants: array of participant IDs for each sample

    Example:
        for X_tr, X_te, y_tr, y_te, pid in leave_one_participant_out(X, y, pids):
            model.fit(X_tr, y_tr)
            score = model.score(X_te, y_te)
            print(f"Participant {pid}: score={score:.4f}")
    """
    X = np.array(X)
    y = np.array(y)
    participants = np.array(participants)

    for pid in np.unique(participants):
        test_mask = participants == pid
        train_mask = ~test_mask
        yield X[train_mask], X[test_mask], y[train_mask], y[test_mask], pid


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  10. EVALUATION METRICS                                                 ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def evaluate_regression(y_true, y_pred, verbose: bool = True) -> dict:
    """
    All standard regression metrics in one call.

    Returns: dict with mse, rmse, mae, r2, mape
    """
    from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

    y_true = np.array(y_true)
    y_pred = np.array(y_pred)

    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)

    # MAPE (avoid division by zero)
    mask = y_true != 0
    mape = np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100 if mask.any() else 0

    result = {"mse": mse, "rmse": rmse, "mae": mae, "r2": r2, "mape": mape}

    if verbose:
        print(f"\n  Regression metrics:")
        print(f"    MSE:  {mse:.6f}")
        print(f"    RMSE: {rmse:.6f}")
        print(f"    MAE:  {mae:.6f}")
        print(f"    R²:   {r2:.6f}")
        print(f"    MAPE: {mape:.2f}%")

    return result


def evaluate_classification(y_true, y_pred, verbose: bool = True) -> dict:
    """
    All standard classification metrics in one call.

    Returns: dict with accuracy, precision, recall, f1
    """
    from sklearn.metrics import (accuracy_score, precision_score,
                                  recall_score, f1_score, confusion_matrix)

    y_true = np.array(y_true)
    y_pred = np.array(y_pred)

    n_classes = len(np.unique(y_true))
    avg = "binary" if n_classes == 2 else "macro"

    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, average=avg, zero_division=0)
    rec = recall_score(y_true, y_pred, average=avg, zero_division=0)
    f1 = f1_score(y_true, y_pred, average=avg, zero_division=0)
    cm = confusion_matrix(y_true, y_pred)

    result = {"accuracy": acc, "precision": prec, "recall": rec, "f1": f1,
              "confusion_matrix": cm}

    if verbose:
        print(f"\n  Classification metrics ({avg}):")
        print(f"    Accuracy:  {acc:.4f}")
        print(f"    Precision: {prec:.4f}")
        print(f"    Recall:    {rec:.4f}")
        print(f"    F1-score:  {f1:.4f}")
        print(f"    Confusion matrix:\n{cm}")

    return result


def angular_error_metric(pred: np.ndarray, target: np.ndarray) -> float:
    """
    Mean angular error in DEGREES — the standard gaze estimation metric.
    Works with both 2D angles and 3D vectors.
    """
    pred = np.atleast_2d(pred)
    target = np.atleast_2d(target)

    pred_n = pred / (np.linalg.norm(pred, axis=1, keepdims=True) + 1e-8)
    target_n = target / (np.linalg.norm(target, axis=1, keepdims=True) + 1e-8)

    cos_sim = np.clip(np.sum(pred_n * target_n, axis=1), -1.0, 1.0)
    return float(np.degrees(np.arccos(cos_sim)).mean())


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  11. PLOTTING HELPERS — One-liners for common plots                     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def plot_correlation_heatmap(df: pd.DataFrame, save_path: str = None,
                              columns: list = None, figsize: tuple = (10, 8)):
    """Correlation matrix heatmap — one-liner."""
    import matplotlib.pyplot as plt
    import seaborn as sns

    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns.tolist()

    corr = df[columns].corr()
    plt.figure(figsize=figsize)
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm",
                center=0, square=True, linewidths=0.5)
    plt.title("Correlation Matrix", fontsize=14, fontweight="bold")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.show()
    return corr


def plot_distributions_grid(df: pd.DataFrame, save_path: str = None,
                             columns: list = None, figsize: tuple = None):
    """Histogram grid for all numeric columns — one-liner."""
    import matplotlib.pyplot as plt

    if columns is None:
        columns = df.select_dtypes(include=[np.number]).columns.tolist()

    n = len(columns)
    ncols = min(3, n)
    nrows = (n + ncols - 1) // ncols
    if figsize is None:
        figsize = (5 * ncols, 4 * nrows)

    fig, axes = plt.subplots(nrows, ncols, figsize=figsize)
    if n == 1:
        axes = [axes]
    else:
        axes = axes.flatten()

    for i, col in enumerate(columns):
        axes[i].hist(df[col].dropna(), bins=50, alpha=0.7, color="steelblue",
                     edgecolor="white")
        axes[i].set_title(col, fontweight="bold")
        axes[i].grid(True, alpha=0.3)

    for i in range(n, len(axes)):
        axes[i].set_visible(False)

    plt.suptitle("Feature Distributions", fontsize=14, fontweight="bold")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.show()


def plot_scatter_pairs(df: pd.DataFrame, save_path: str = None,
                        pairs: list = None, sample: int = 5000):
    """Scatter plots for specified pairs — one-liner."""
    import matplotlib.pyplot as plt

    if pairs is None:
        cols = df.select_dtypes(include=[np.number]).columns.tolist()
        pairs = [(cols[i], cols[j]) for i in range(min(3, len(cols)))
                  for j in range(i+1, min(4, len(cols)))]

    n = len(pairs)
    ncols = min(3, n)
    nrows = (n + ncols - 1) // ncols

    fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 4 * nrows))
    if n == 1:
        axes = [axes]
    else:
        axes = np.array(axes).flatten()

    df_s = df.sample(min(sample, len(df)), random_state=42)

    for i, (x, y) in enumerate(pairs):
        if i < len(axes):
            axes[i].scatter(df_s[x], df_s[y], alpha=0.3, s=5, color="steelblue")
            r = df_s[x].corr(df_s[y])
            axes[i].set_title(f"{x} vs {y} (r={r:.2f})", fontweight="bold")
            axes[i].set_xlabel(x)
            axes[i].set_ylabel(y)
            axes[i].grid(True, alpha=0.3)

    for i in range(n, len(axes)):
        axes[i].set_visible(False)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.show()


def plot_training_curves(train_losses: list, val_losses: list,
                          save_path: str = None):
    """Plot train vs validation loss curves — one-liner."""
    import matplotlib.pyplot as plt

    epochs = range(1, len(train_losses) + 1)
    plt.figure(figsize=(8, 4))
    plt.plot(epochs, train_losses, label="Train", linewidth=2)
    plt.plot(epochs, val_losses, label="Validation", linewidth=2, linestyle="--")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("Training vs Validation Loss")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=300)
    plt.show()


def plot_predicted_vs_actual(y_true, y_pred, label: str = "",
                              save_path: str = None):
    """Predicted vs actual scatter plot with diagonal — one-liner."""
    import matplotlib.pyplot as plt

    y_true = np.array(y_true).flatten()
    y_pred = np.array(y_pred).flatten()

    plt.figure(figsize=(6, 6))
    plt.scatter(y_true, y_pred, alpha=0.3, s=5, color="steelblue")
    lo, hi = min(y_true.min(), y_pred.min()), max(y_true.max(), y_pred.max())
    plt.plot([lo, hi], [lo, hi], "r--", linewidth=2, label="Perfect")
    plt.xlabel("Actual")
    plt.ylabel("Predicted")
    plt.title(f"Predicted vs Actual {label}")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=300)
    plt.show()


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  12. IMAGE PREPROCESSING FOR CV TASKS                                   ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def load_images_from_folder(folder: str, target_size: tuple = (64, 64),
                             grayscale: bool = False, max_images: int = None,
                             normalize_pixels: bool = True) -> np.ndarray:
    """
    Load images from a folder into a NumPy array.

    Args:
        folder: path to image folder
        target_size: (height, width) to resize all images to
        grayscale: convert to grayscale
        max_images: limit number of images loaded
        normalize_pixels: divide by 255 to get [0, 1]

    Returns:
        np.ndarray of shape (N, H, W) for grayscale or (N, H, W, 3) for color
    """
    from PIL import Image

    extensions = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".webp"}
    files = sorted([f for f in os.listdir(folder)
                    if os.path.splitext(f)[1].lower() in extensions])

    if max_images:
        files = files[:max_images]

    images = []
    for f in files:
        img = Image.open(os.path.join(folder, f))
        if grayscale:
            img = img.convert("L")
        else:
            img = img.convert("RGB")
        img = img.resize((target_size[1], target_size[0]))  # PIL uses (W, H)
        images.append(np.array(img, dtype=np.float32))

    arr = np.array(images)
    if normalize_pixels:
        arr = arr / 255.0

    print(f"  Loaded {len(images)} images → shape {arr.shape}")
    return arr


def augment_batch(images: np.ndarray, flips: bool = True,
                   noise: bool = True, brightness: bool = True) -> np.ndarray:
    """
    Simple data augmentation on a batch of images (NumPy).
    No extra libraries needed.

    Args:
        images: (N, H, W) or (N, H, W, C)
        flips: random horizontal flips
        noise: add Gaussian noise
        brightness: random brightness adjustment

    Returns:
        augmented images array (same shape, 2x the size)
    """
    augmented = [images.copy()]

    if flips:
        flipped = images[:, :, ::-1].copy()  # horizontal flip
        augmented.append(flipped)

    if noise:
        noisy = images + np.random.normal(0, 0.02, images.shape).astype(np.float32)
        noisy = np.clip(noisy, 0, 1)
        augmented.append(noisy)

    if brightness:
        factor = np.random.uniform(0.8, 1.2, (len(images), 1, 1))
        if images.ndim == 4:
            factor = factor[..., np.newaxis]
        bright = np.clip(images * factor, 0, 1).astype(np.float32)
        augmented.append(bright)

    result = np.concatenate(augmented, axis=0)
    print(f"  Augmented: {len(images)} → {len(result)} images")
    return result


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  13. EXPORT UTILITIES                                                   ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def save_to_format(df: pd.DataFrame, path: str, fmt: str = "csv"):
    """
    Save DataFrame to any format.

    Args:
        fmt: 'csv', 'json', 'parquet', 'feather', 'excel', 'npz', 'pickle'
    """
    savers = {
        "csv":     lambda: df.to_csv(path, index=False),
        "json":    lambda: df.to_json(path, orient="records", indent=2),
        "parquet": lambda: df.to_parquet(path, index=False),
        "feather": lambda: df.to_feather(path),
        "excel":   lambda: df.to_excel(path, index=False),
        "npz":     lambda: np.savez(path, data=df.values, columns=df.columns.values),
        "pickle":  lambda: df.to_pickle(path),
    }
    if fmt not in savers:
        raise ValueError(f"Unknown format: {fmt}. Choose from {list(savers.keys())}")
    savers[fmt]()
    print(f"  Saved to {path} ({fmt})")


def generate_report_text(df: pd.DataFrame, dist_results: dict = None,
                          corr_pairs: list = None) -> str:
    """
    Generate a template analysis report based on computed statistics.
    Copy-paste this into your report document!

    Returns:
        Multi-line report string
    """
    numeric = df.select_dtypes(include=[np.number])
    n_rows, n_cols = df.shape

    report = []
    report.append("=" * 60)
    report.append("DATASET ANALYSIS REPORT")
    report.append("=" * 60)
    report.append("")
    report.append("1. DATASET OVERVIEW")
    report.append(f"   Records: {n_rows:,}")
    report.append(f"   Features: {n_cols}")
    report.append(f"   Numeric features: {len(numeric.columns)}")
    report.append(f"   Memory: {df.memory_usage(deep=True).sum()/1024**2:.2f} MB")
    report.append(f"   Missing values: {df.isnull().sum().sum()}")
    report.append(f"   Duplicates: {df.duplicated().sum()}")
    report.append("")

    report.append("2. FEATURE STATISTICS")
    for col in numeric.columns:
        s = numeric[col]
        report.append(f"   {col}:")
        report.append(f"     Range: [{s.min():.4f}, {s.max():.4f}]")
        report.append(f"     Mean: {s.mean():.4f}, Std: {s.std():.4f}")

    if dist_results:
        report.append("")
        report.append("3. DISTRIBUTION TYPES")
        for col, info in dist_results.items():
            report.append(f"   {col}: {info['type']} "
                          f"(skew={info['skewness']:.3f}, kurt={info['kurtosis']:.3f}, "
                          f"best fit: {info['best_fit']})")

    if corr_pairs:
        report.append("")
        report.append("4. HIGH CORRELATIONS")
        for a, b, r in corr_pairs:
            report.append(f"   {a} ↔ {b}: r = {r}")

    report.append("")
    report.append("=" * 60)

    text = "\n".join(report)
    print(text)
    return text


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  CONVENIENCE: Run the entire pipeline in one call                       ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

def run_full_analysis(df: pd.DataFrame, save_dir: str = ".",
                       target_cols: list = None):
    """
    Run the COMPLETE analysis pipeline on any dataset:
      1. Quick EDA
      2. Clean data
      3. Correlation analysis + heatmap
      4. Distribution analysis + histograms
      5. Scatter plots
      6. VIF multicollinearity check
      7. Generate report text

    Args:
        df: raw DataFrame
        save_dir: where to save plots
        target_cols: columns that are the prediction target

    Returns:
        dict with all results (cleaned_df, distributions, correlations, report)
    """
    os.makedirs(save_dir, exist_ok=True)

    print("\n" + "█" * 70)
    print("  FULL ANALYSIS PIPELINE")
    print("█" * 70)

    # 1. EDA
    eda = quick_eda(df)

    # 2. Clean
    df_clean = auto_clean(df)

    # 3. Correlations
    corr_pairs = find_high_correlations(df_clean, threshold=0.7)
    plot_correlation_heatmap(df_clean,
                              save_path=os.path.join(save_dir, "correlation_matrix.png"))

    # 4. Distributions
    dist_results = analyze_distributions(df_clean)
    plot_distributions_grid(df_clean,
                             save_path=os.path.join(save_dir, "distributions.png"))

    # 5. Scatter plots
    plot_scatter_pairs(df_clean,
                        save_path=os.path.join(save_dir, "scatter_plots.png"))

    # 6. VIF
    vif = compute_vif(df_clean)

    # 7. Report
    report = generate_report_text(df_clean, dist_results, corr_pairs)

    # Save report
    report_path = os.path.join(save_dir, "analysis_report.txt")
    with open(report_path, "w") as f:
        f.write(report)
    print(f"\n  Report saved to: {report_path}")

    print("\n" + "█" * 70)
    print("  PIPELINE COMPLETE")
    print("█" * 70 + "\n")

    return {
        "cleaned_df": df_clean,
        "eda": eda,
        "distributions": dist_results,
        "high_correlations": corr_pairs,
        "vif": vif,
        "report": report,
    }


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║  __all__ — what you get with `from toolkit import *`                    ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

__all__ = [
    # Loading
    "smart_load",
    # EDA
    "quick_eda",
    # Cleaning
    "auto_clean",
    # Feature engineering
    "encode_categoricals", "add_interaction_features",
    "add_polynomial_features", "add_statistical_features",
    # Transformations
    "normalize", "apply_transforms",
    # Distribution analysis
    "analyze_distributions",
    # Correlation & multicollinearity
    "find_high_correlations", "compute_vif",
    # Dimensionality reduction
    "run_pca",
    # Splitting
    "smart_split", "leave_one_participant_out",
    # Metrics
    "evaluate_regression", "evaluate_classification", "angular_error_metric",
    # Plotting
    "plot_correlation_heatmap", "plot_distributions_grid",
    "plot_scatter_pairs", "plot_training_curves", "plot_predicted_vs_actual",
    # Images
    "load_images_from_folder", "augment_batch",
    # Export
    "save_to_format", "generate_report_text",
    # Pipeline
    "run_full_analysis",
]
