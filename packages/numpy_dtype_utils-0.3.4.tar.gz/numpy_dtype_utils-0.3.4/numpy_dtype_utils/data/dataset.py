"""
Класс Dataset для работы с данными MPIIGaze.

Пример использования:
    dataset = Dataset("dunno/data/MPIIGaze/Data/Normalized")
    dataset.load(max_participants=5, max_days=3)
    print(dataset.info())
    df = dataset.to_dataframe()
"""

import os
from scipy.io import loadmat
import numpy as np
import pandas as pd


class Dataset:
    """
    Класс для загрузки и работы с данными MPIIGaze.
    
    Атрибуты:
        data_path: путь к папке с данными
        records: список всех записей (словари)
        participants: список участников
        is_loaded: флаг, что данные загружены
    """
    
    def __init__(self, data_path: str):
        """
        Инициализация датасета.
        
        Args:
            data_path: путь к папке Normalized (например "dunno/data/MPIIGaze/Data/Normalized")
        """
        self.data_path = data_path
        self.records = []           # Все записи
        self.participants = []       # Список участников
        self.is_loaded = False       # Флаг загрузки
        
        # Проверяем существование пути
        if not os.path.exists(data_path):
            raise FileNotFoundError(f"Путь не найден: {data_path}")
    
    # =========================================================================
    # ЗАГРУЗКА ДАННЫХ
    # =========================================================================
    
    def load(self, max_participants: int = None, max_days: int = None, verbose: bool = True):
        """
        Загрузка данных из .mat файлов.
        
        Args:
            max_participants: максимум участников для загрузки (None = все)
            max_days: максимум дней на участника (None = все)
            verbose: печатать прогресс загрузки
            
        Returns:
            self (для цепочки вызовов)
        """
        if verbose:
            print("Загрузка данных MPIIGaze...")
            print("-" * 50)
        
        # Получаем список участников
        self.participants = sorted([
            d for d in os.listdir(self.data_path)
            if os.path.isdir(os.path.join(self.data_path, d))
        ])
        
        if max_participants:
            self.participants = self.participants[:max_participants]
        
        if verbose:
            print(f"Участников: {len(self.participants)}")
        
        # Загружаем данные каждого участника
        self.records = []
        
        for participant in self.participants:
            participant_path = os.path.join(self.data_path, participant)
            mat_files = sorted([
                f for f in os.listdir(participant_path) 
                if f.endswith('.mat')
            ])
            
            if max_days:
                mat_files = mat_files[:max_days]
            
            participant_records = 0
            
            for mat_file in mat_files:
                file_path = os.path.join(participant_path, mat_file)
                day = mat_file.replace('.mat', '')
                
                # Загружаем и парсим .mat файл
                new_records = self._load_mat_file(file_path, participant, day)
                self.records.extend(new_records)
                participant_records += len(new_records)
            
            if verbose:
                print(f"  {participant}: {len(mat_files)} дней, {participant_records} записей")
        
        self.is_loaded = True
        
        if verbose:
            print("-" * 50)
            print(f"Всего загружено: {len(self.records)} записей")
        
        return self
    
    def _load_mat_file(self, file_path: str, participant: str, day: str) -> list:
        """
        Загрузка одного .mat файла.
        
        Args:
            file_path: путь к файлу
            participant: ID участника
            day: день записи
            
        Returns:
            список записей (словарей)
        """
        try:
            mat_data = loadmat(file_path)
            data = mat_data['data']
            records = []
            
            # Обрабатываем правый и левый глаз
            for eye in ['right', 'left']:
                eye_data = data[eye][0, 0]
                
                gaze = eye_data['gaze'][0, 0]   # (N, 3)
                pose = eye_data['pose'][0, 0]   # (N, 3)
                
                for i in range(len(gaze)):
                    record = {
                        'participant': participant,
                        'day': day,
                        'eye': eye,
                        # Направление взгляда
                        'gaze_x': gaze[i, 0],
                        'gaze_y': gaze[i, 1],
                        'gaze_z': gaze[i, 2],
                        # Поза головы
                        'head_pose_x': pose[i, 0],
                        'head_pose_y': pose[i, 1],
                        'head_pose_z': pose[i, 2],
                    }
                    records.append(record)
            
            return records
            
        except Exception as e:
            print(f"Ошибка загрузки {file_path}: {e}")
            return []
    
    # =========================================================================
    # ПРЕОБРАЗОВАНИЕ ДАННЫХ
    # =========================================================================
    
    def to_dataframe(self) -> pd.DataFrame:
        """
        Преобразование в pandas DataFrame.
        
        Returns:
            DataFrame со всеми записями
        """
        if not self.is_loaded:
            raise RuntimeError("Данные не загружены! Сначала вызовите load()")
        
        return pd.DataFrame(self.records)
    
    def to_numpy(self, columns: list = None) -> np.ndarray:
        """
        Преобразование в numpy array.
        
        Args:
            columns: список столбцов (по умолчанию числовые)
            
        Returns:
            numpy array
        """
        df = self.to_dataframe()
        
        if columns is None:
            columns = ['gaze_x', 'gaze_y', 'gaze_z', 
                       'head_pose_x', 'head_pose_y', 'head_pose_z']
        
        return df[columns].values
    
    # =========================================================================
    # ИНФОРМАЦИЯ О ДАННЫХ
    # =========================================================================
    
    def info(self) -> str:
        """
        Получить информацию о датасете.
        
        Returns:
            строка с информацией
        """
        if not self.is_loaded:
            return "Данные не загружены. Вызовите load() для загрузки."
        
        df = self.to_dataframe()
        
        info_text = f"""
{'='*60}
ИНФОРМАЦИЯ О ДАТАСЕТЕ MPIIGaze
{'='*60}
Путь: {self.data_path}
Участников: {len(self.participants)}
Всего записей: {len(self.records)}
Записей на участника: ~{len(self.records) // len(self.participants)}

Столбцы:
{list(df.columns)}

Статистика числовых признаков:
{df.describe().round(4).to_string()}
{'='*60}
        """
        return info_text
    
    def __len__(self) -> int:
        """Количество записей."""
        return len(self.records)
    
    def __repr__(self) -> str:
        """Представление объекта."""
        status = "загружен" if self.is_loaded else "не загружен"
        return f"Dataset(path='{self.data_path}', записей={len(self.records)}, статус={status})"
    
    # =========================================================================
    # ФИЛЬТРАЦИЯ ДАННЫХ
    # =========================================================================
    
    def filter_by_participant(self, participant_id: str) -> pd.DataFrame:
        """
        Получить данные одного участника.
        
        Args:
            participant_id: ID участника (например 'p00')
            
        Returns:
            DataFrame с данными участника
        """
        df = self.to_dataframe()
        if 'participant' not in df.columns:
            print("Предупреждение: столбец 'participant' был удален при очистке.")
            return pd.DataFrame()
        return df[df['participant'] == participant_id]
    
    def filter_by_eye(self, eye: str) -> pd.DataFrame:
        """
        Получить данные одного глаза.
        
        Args:
            eye: 'left' или 'right'
            
        Returns:
            DataFrame с данными
        """
        df = self.to_dataframe()
        if 'eye' not in df.columns:
            print("Предупреждение: столбец 'eye' был удален при очистке.")
            return pd.DataFrame()
        return df[df['eye'] == eye]
    
    def get_numeric_columns(self) -> list:
        """Список числовых столбцов."""
        return ['gaze_x', 'gaze_y', 'gaze_z', 
                'head_pose_x', 'head_pose_y', 'head_pose_z']
    
    # =========================================================================
    # ОЧИСТКА ДАННЫХ
    # =========================================================================
    
    def clean(self, drop_metadata: bool = True, remove_outliers: bool = True, verbose: bool = True):
        """
        Очистка данных от дубликатов, пустых значений, выбросов и нерелевантных метаданных.
        
        Выполняет:
        1. Удаление нерелевантных столбцов (participant, day, eye)
        2. Удаление записей с пустыми значениями (NaN)
        3. Удаление записей с бесконечными значениями (inf)
        4. Удаление выбросов методом IQR (межквартильный размах)
        5. Удаление полных дубликатов
        
        Args:
            drop_metadata: если True, удаляет столбцы с метаданными
            remove_outliers: если True, удаляет выбросы методом IQR
            verbose: печатать статистику очистки
            
        Returns:
            self (для цепочки вызовов)
        """
        if not self.is_loaded:
            raise RuntimeError("Данные не загружены! Сначала вызовите load()")
        
        initial_count = len(self.records)
        
        if verbose:
            print("Очистка данных...")
            print("-" * 50)
            print(f"Записей до очистки: {initial_count}")
        
        # Преобразуем в DataFrame для удобной очистки
        df = pd.DataFrame(self.records)
        
        # 0. Удаление метаданных (если требуется)
        if drop_metadata:
            cols_to_drop = ['participant', 'day', 'eye']
            existing_cols = [c for c in cols_to_drop if c in df.columns]
            df = df.drop(columns=existing_cols)
            if verbose:
                print(f"  Удалены метаданные: {existing_cols}")

        numeric_cols = self.get_numeric_columns()
        
        # 1. Удаление пустых значений (NaN)
        nan_count = df[numeric_cols].isna().any(axis=1).sum()
        df = df.dropna(subset=numeric_cols)
        
        if verbose:
            print(f"  Удалено NaN: {nan_count}")
        
        # 2. Удаление бесконечных значений (inf)
        inf_mask = np.isinf(df[numeric_cols]).any(axis=1)
        inf_count = inf_mask.sum()
        df = df[~inf_mask]
        
        if verbose:
            print(f"  Удалено inf: {inf_count}")
        
        # 3. Удаление выбросов методом IQR (межквартильный размах)
        if remove_outliers:
            Q1 = df[numeric_cols].quantile(0.25)
            Q3 = df[numeric_cols].quantile(0.75)
            IQR = Q3 - Q1
            
            # Маска для "нормальных" данных (не выбросов)
            outlier_mask = ~((df[numeric_cols] < (Q1 - 1.5 * IQR)) | 
                             (df[numeric_cols] > (Q3 + 1.5 * IQR))).any(axis=1)
            
            outlier_count = (~outlier_mask).sum()
            df = df[outlier_mask]
            
            if verbose:
                print(f"  Удалено выбросов (IQR): {outlier_count}")
        
        # 4. Удаление дубликатов
        dup_count = df.duplicated().sum()
        df = df.drop_duplicates()
        
        if verbose:
            print(f"  Удалено дубликатов: {dup_count}")
        
        # Обновляем records
        self.records = df.to_dict('records')
        
        final_count = len(self.records)
        removed_total = initial_count - final_count
        
        if verbose:
            print("-" * 50)
            print(f"Записей после очистки: {final_count}")
            print(f"Всего удалено: {removed_total} ({removed_total/initial_count*100:.1f}%)")
        
        return self
    
    # =========================================================================
    # ВИЗУАЛИЗАЦИЯ И АНАЛИЗ
    # =========================================================================
    
    def plot_correlation_matrix(self, figsize=(10, 8), cmap='coolwarm', annot=True, save_path=None):
        """
        Построение корреляционной матрицы для числовых признаков.
        
        Args:
            figsize: размер фигуры (ширина, высота)
            cmap: цветовая схема ('coolwarm', 'RdBu_r', 'viridis' и т.д.)
            annot: показывать ли значения корреляций на графике
            save_path: путь для сохранения графика (если None, не сохраняет)
            
        Returns:
            correlation_matrix: DataFrame с корреляциями
        """
        import matplotlib.pyplot as plt
        import seaborn as sns
        
        if not self.is_loaded:
            raise RuntimeError("Данные не загружены! Сначала вызовите load()")
        
        # Получаем DataFrame и числовые столбцы
        df = self.to_dataframe()
        numeric_cols = self.get_numeric_columns()
        
        # Вычисляем корреляционную матрицу
        corr = df[numeric_cols].corr()
        
        # Создаем график
        plt.figure(figsize=figsize)
        sns.heatmap(
            corr, 
            annot=annot, 
            cmap=cmap, 
            center=0,
            fmt='.3f',
            square=True,
            linewidths=0.5,
            cbar_kws={'label': 'Коэффициент корреляции'}
        )
        plt.title('Корреляционная матрица признаков MPIIGaze', fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        # Сохраняем, если указан путь
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"График сохранен: {save_path}")
        
        plt.show()
        
        return corr
    
    def plot_scatter_matrix(self, sample_size=10000, figsize=(15, 10), save_path=None):
        """
        Построение диаграмм рассеяния для ключевых пар признаков.
        
        Создает 6 графиков scatter plot для анализа взаимосвязей между:
        - gaze и head_pose по разным осям
        
        Args:
            sample_size: количество точек для отображения (для скорости)
            figsize: размер фигуры (ширина, высота)
            save_path: путь для сохранения графика (если None, не сохраняет)
            
        Returns:
            None
        """
        import matplotlib.pyplot as plt
        import seaborn as sns
        
        if not self.is_loaded:
            raise RuntimeError("Данные не загружены! Сначала вызовите load()")
        
        # Получаем DataFrame
        df = self.to_dataframe()
        
        # Берем выборку для скорости отрисовки
        if len(df) > sample_size:
            df_sample = df.sample(sample_size, random_state=42)
        else:
            df_sample = df
        
        # Определяем пары для scatter plots
        pairs = [
            ('gaze_x', 'gaze_y', 'Взгляд: X vs Y'),
            ('gaze_y', 'gaze_z', 'Взгляд: Y vs Z'),
            ('head_pose_x', 'head_pose_y', 'Поза головы: X vs Y'),
            ('gaze_x', 'head_pose_x', 'Взгляд X vs Поза головы X'),
            ('gaze_y', 'head_pose_y', 'Взгляд Y vs Поза головы Y'),
            ('gaze_z', 'head_pose_z', 'Взгляд Z vs Поза головы Z')
        ]
        
        # Создаем сетку графиков 2x3
        fig, axes = plt.subplots(2, 3, figsize=figsize)
        axes = axes.flatten()
        
        for idx, (x_col, y_col, title) in enumerate(pairs):
            sns.scatterplot(
                x=x_col, 
                y=y_col, 
                data=df_sample, 
                ax=axes[idx],
                alpha=0.5,
                s=10,
                color='steelblue'
            )
            axes[idx].set_title(title, fontweight='bold')
            axes[idx].set_xlabel(x_col)
            axes[idx].set_ylabel(y_col)
            axes[idx].grid(True, alpha=0.3)
            
            # Добавляем линию тренда
            import numpy as np
            z = np.polyfit(df_sample[x_col], df_sample[y_col], 1)
            p = np.poly1d(z)
            x_line = np.linspace(df_sample[x_col].min(), df_sample[x_col].max(), 100)
            axes[idx].plot(x_line, p(x_line), "r--", linewidth=2, alpha=0.8, label='Тренд')
            
            # Показываем корреляцию
            corr = df_sample[x_col].corr(df_sample[y_col])
            axes[idx].text(
                0.05, 0.95, 
                f'r = {corr:.3f}',
                transform=axes[idx].transAxes,
                fontsize=10,
                verticalalignment='top',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5)
            )
        
        plt.suptitle(f'Диаграммы рассеяния признаков MPIIGaze (n={len(df_sample)})', 
                     fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        # Сохраняем, если указан путь
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"График сохранен: {save_path}")
        
        plt.show()
    
    def cluster_gaze(self, n_clusters=3, sample_size=50000, figsize=(12, 5), save_path=None):
        """
        Кластеризация координат взгляда (gaze_x, gaze_y) методом KMeans.
        
        Args:
            n_clusters: количество кластеров
            sample_size: размер выборки для кластеризации
            figsize: размер фигуры
            save_path: путь для сохранения графика
            
        Returns:
            dict: результаты кластеризации (labels, centers, inertia)
        """
        from sklearn.cluster import KMeans
        import matplotlib.pyplot as plt
        
        if not self.is_loaded:
            raise RuntimeError("Данные не загружены! Сначала вызовите load()")
        
        df = self.to_dataframe()
        gaze_features = ['gaze_x', 'gaze_y']
        
        # Берем выборку если данных много
        if len(df) > sample_size:
            df_sample = df.sample(sample_size, random_state=42)
        else:
            df_sample = df
        
        X = df_sample[gaze_features].values
        
        # Кластеризация
        print(f"Кластеризация gaze_x, gaze_y (n_clusters={n_clusters})...")
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        labels = kmeans.fit_predict(X)
        
        # Результаты
        print(f"  Инерция: {kmeans.inertia_:.2f}")
        print(f"  Центры кластеров:")
        for i, center in enumerate(kmeans.cluster_centers_):
            count = (labels == i).sum()
            print(f"    Кластер {i}: центр=({center[0]:.4f}, {center[1]:.4f}), точек={count}")
        
        # Визуализация
        fig, axes = plt.subplots(1, 2, figsize=figsize)
        
        # График 1: Кластеры
        scatter = axes[0].scatter(X[:, 0], X[:, 1], c=labels, cmap='viridis', 
                                  alpha=0.5, s=10)
        axes[0].scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], 
                        c='red', marker='X', s=200, edgecolors='black', linewidths=2,
                        label='Центроиды')
        axes[0].set_xlabel('gaze_x')
        axes[0].set_ylabel('gaze_y')
        axes[0].set_title(f'Кластеризация взгляда (K={n_clusters})', fontweight='bold')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        plt.colorbar(scatter, ax=axes[0], label='Кластер')
        
        # График 2: Метод локтя для выбора оптимального K
        inertias = []
        K_range = range(2, 11)
        for k in K_range:
            km = KMeans(n_clusters=k, random_state=42, n_init=10)
            km.fit(X)
            inertias.append(km.inertia_)
        
        axes[1].plot(K_range, inertias, 'bo-', linewidth=2, markersize=8)
        axes[1].axvline(x=n_clusters, color='r', linestyle='--', label=f'Выбрано K={n_clusters}')
        axes[1].set_xlabel('Количество кластеров (K)')
        axes[1].set_ylabel('Инерция')
        axes[1].set_title('Метод локтя', fontweight='bold')
        axes[1].legend()
        axes[1].grid(True, alpha=0.3)
        
        plt.suptitle('Кластерный анализ направления взгляда', fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"График сохранен: {save_path}")
        
        plt.show()
        
        return {
            'labels': labels,
            'centers': kmeans.cluster_centers_,
            'inertia': kmeans.inertia_,
            'n_clusters': n_clusters
        }
    
    def plot_distributions(self, figsize=(15, 10), save_path=None):
        """
        Анализ распределений всех числовых признаков.
        
        Строит гистограммы с наложением нормального распределения
        и выполняет тест Шапиро-Уилка для проверки нормальности.
        
        Args:
            figsize: размер фигуры
            save_path: путь для сохранения графика
            
        Returns:
            dict: результаты тестов нормальности для каждого признака
        """
        import matplotlib.pyplot as plt
        import seaborn as sns
        from scipy import stats
        
        if not self.is_loaded:
            raise RuntimeError("Данные не загружены! Сначала вызовите load()")
        
        df = self.to_dataframe()
        numeric_cols = self.get_numeric_columns()
        
        # Создаем сетку 2x3 для 6 признаков
        fig, axes = plt.subplots(2, 3, figsize=figsize)
        axes = axes.flatten()
        
        results = {}
        
        print("Анализ распределений признаков:")
        print("=" * 70)
        
        for idx, col in enumerate(numeric_cols):
            data = df[col].dropna()
            
            # Тест Шапиро-Уилка (на выборке до 5000 точек для скорости)
            sample = data.sample(min(5000, len(data)), random_state=42)
            stat, p_value = stats.shapiro(sample)
            
            # Вычисляем статистики
            skewness = stats.skew(data)
            kurtosis = stats.kurtosis(data)
            
            # Определяем тип распределения
            if p_value > 0.05:
                dist_type = "Нормальное"
            elif abs(skewness) > 1:
                dist_type = "Скошенное" + (" (вправо)" if skewness > 0 else " (влево)")
            elif kurtosis > 1:
                dist_type = "Островершинное"
            elif kurtosis < -1:
                dist_type = "Плосковершинное"
            else:
                dist_type = "Близко к нормальному"
            
            results[col] = {
                'shapiro_stat': stat,
                'shapiro_p': p_value,
                'skewness': skewness,
                'kurtosis': kurtosis,
                'distribution_type': dist_type,
                'is_normal': p_value > 0.05
            }
            
            # Строим гистограмму
            sns.histplot(data, bins=50, kde=True, ax=axes[idx], color='steelblue', stat='density')
            
            # Накладываем нормальное распределение
            mu, sigma = data.mean(), data.std()
            x = np.linspace(data.min(), data.max(), 100)
            axes[idx].plot(x, stats.norm.pdf(x, mu, sigma), 'r--', linewidth=2, label='Норм. распр.')
            
            # Оформление
            axes[idx].set_title(f'{col}\n{dist_type}', fontweight='bold', fontsize=10)
            axes[idx].set_xlabel(col)
            axes[idx].set_ylabel('Плотность')
            axes[idx].legend()
            axes[idx].grid(True, alpha=0.3)
            
            # Добавляем текст со статистиками
            text = f'μ={mu:.3f}\nσ={sigma:.3f}\np={p_value:.4f}\nskew={skewness:.2f}'
            axes[idx].text(0.02, 0.98, text, transform=axes[idx].transAxes,
                          fontsize=8, verticalalignment='top',
                          bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.7))
            
            # Выводим результаты
            print(f"\n{col}:")
            print(f"  Тип: {dist_type}")
            print(f"  Среднее: {mu:.4f}, Ст.откл: {sigma:.4f}")
            print(f"  Асимметрия: {skewness:.4f}, Эксцесс: {kurtosis:.4f}")
            print(f"  Shapiro-Wilk: stat={stat:.4f}, p={p_value:.4f} {'✓ Норм.' if p_value > 0.05 else '✗ Не норм.'}")
        
        plt.suptitle('Анализ распределений признаков MPIIGaze', fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"\nГрафик сохранен: {save_path}")
        
        plt.show()
        
        print("=" * 70)
        
        return results


# =============================================================================
# ПРИМЕР ИСПОЛЬЗОВАНИЯ
# =============================================================================

# if __name__ == "__main__":
    # Создаём датасет
    # dataset = Dataset("dunno/data/MPIIGaze/Data/Normalized")
    
    # Загружаем данные (5 дней на участника)
    # dataset.load(max_days=5)
    
    # Очищаем данные (удаляем метаданные, NaN, inf, выбросы, дубликаты)
    # dataset.clean(remove_outliers=False)
    
    # Выводим информацию
    # print(dataset.info())
    
    # Получаем DataFrame
    # df = dataset.to_dataframe()
    # print("\nПервые 5 записей очищенного датасета (без метаданных):")
    # print(df.head())
    
    # Визуализация корреляционной матрицы
    # dataset.plot_correlation_matrix(figsize=(12, 10), annot=True, save_path='./correlation_matrix.png')
    
    # Диаграммы рассеяния
    # dataset.plot_scatter_matrix(save_path='scatter_plots.png')
    
    # Кластеризация направления взгляда
    # result = dataset.cluster_gaze(n_clusters=3, save_path='gaze_clusters.png')
    
    # Анализ распределений признаков
    # dist_results = dataset.plot_distributions(save_path='distributions.png')
    
    # Получаем numpy array для дальнейшего анализа
    # df_model = df[numeric_cols]
    # X = df_model.to_numpy()
    # print(f"\nNumpy array shape: {X.shape}")