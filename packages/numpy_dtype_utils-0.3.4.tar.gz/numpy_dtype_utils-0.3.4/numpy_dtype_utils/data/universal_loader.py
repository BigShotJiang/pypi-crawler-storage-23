"""
=============================================================================
UNIVERSAL GAZE DATASET LOADER & ANALYZER
=============================================================================
This file is a TEMPLATE / CHEAT SHEET for loading, cleaning, and analyzing
ANY gaze estimation dataset you might encounter at a competition.

PROBLEM: You trained on MPIIGaze (.mat files, 6 numeric features), but the
competition dataset could be ANYTHING:
  - CSV / TSV files
  - .mat (MATLAB) files
  - .npz / .npy (NumPy) files
  - .h5 / .hdf5 (HDF5) files
  - Image folders + labels file
  - JSON / XML annotations
  - Parquet / Feather (columnar formats)

This file shows you HOW TO ADAPT your pipeline for each case.
=============================================================================
"""

import os
import numpy as np
import pandas as pd


# =============================================================================
# STEP 0: DETECT WHAT FORMAT THE DATASET IS
# =============================================================================
# Run this FIRST to understand what you're dealing with.

def detect_dataset_format(data_path: str) -> dict:
    """
    Scans the dataset directory and reports what file types are present.
    This helps you decide WHICH loader function to use.
    
    Usage:
        info = detect_dataset_format("path/to/dataset")
        print(info)
    """
    
    result = {
        "path": data_path,
        "total_files": 0,
        "extensions": {},       # {'.csv': 5, '.mat': 15, ...}
        "subdirectories": [],   # ['p00', 'p01', ...]
        "sample_files": [],     # first 10 files for quick inspection
    }
    
    for root, dirs, files in os.walk(data_path):
        # Track subdirectories (only top-level)
        if root == data_path:
            result["subdirectories"] = sorted(dirs)
        
        for f in files:
            result["total_files"] += 1
            ext = os.path.splitext(f)[1].lower()
            result["extensions"][ext] = result["extensions"].get(ext, 0) + 1
            
            if len(result["sample_files"]) < 10:
                result["sample_files"].append(os.path.join(root, f))
    
    return result


# =============================================================================
# STEP 1: LOADER FUNCTIONS — one for each format
# =============================================================================
# Pick the one that matches your dataset. Each returns a pd.DataFrame.


# --------------- CASE 1: CSV / TSV files ---------------
# Most common format at competitions. Simple and fast.
# Examples: GazeCapture, OpenFace outputs, custom datasets
#
# WHAT TO LOOK FOR:
#   - Files ending in .csv or .tsv
#   - First row is usually column headers
#   - Columns might be: x, y, z, pitch, yaw, roll, etc.

def load_csv(file_path: str, separator: str = ",") -> pd.DataFrame:
    """
    Load a single CSV/TSV file.
    
    ADAPT:
      - If the file has NO header row, add: header=None
      - If separator is tab, use: separator='\\t'
      - If separator is semicolon (European Excel), use: separator=';'
      - If encoding is not UTF-8, add: encoding='latin-1' or 'cp1251'
    """
    df = pd.read_csv(file_path, sep=separator)
    
    # TIP: Print columns immediately to understand the structure
    print(f"Columns: {list(df.columns)}")
    print(f"Shape: {df.shape}")
    print(f"Dtypes:\n{df.dtypes}")
    
    return df


def load_multiple_csv(data_path: str, pattern: str = "*.csv") -> pd.DataFrame:
    """
    Load ALL CSV files from a directory into one DataFrame.
    Useful when data is split per participant or per session.
    
    ADAPT:
      - Change pattern to '*.tsv' for tab-separated files
      - Add participant ID from filename if not in the data itself
    """
    import glob
    
    all_files = sorted(glob.glob(os.path.join(data_path, "**", pattern), recursive=True))
    print(f"Found {len(all_files)} files matching '{pattern}'")
    
    frames = []
    for f in all_files:
        df = pd.read_csv(f)
        
        # OPTIONAL: extract participant ID from the file path
        # Example: if path is "data/p00/session1.csv", extract "p00"
        # parts = f.split(os.sep)
        # df['participant'] = parts[-2]  # second-to-last folder name
        
        frames.append(df)
    
    combined = pd.concat(frames, ignore_index=True)
    print(f"Combined shape: {combined.shape}")
    return combined


# --------------- CASE 2: MATLAB .mat files ---------------
# Used by: MPIIGaze, MPIIFaceGaze, UT Multiview, Columbia
#
# WHAT TO LOOK FOR:
#   - Files ending in .mat
#   - Usually organized in folders per participant (p00/, p01/, ...)
#   - Data is stored in nested structures / arrays

def load_mat(file_path: str) -> dict:
    """
    Load a single .mat file.
    
    IMPORTANT: .mat files come in TWO versions:
      - v5 (MATLAB <7.3): use scipy.io.loadmat
      - v7.3 (HDF5-based): use h5py
    
    If scipy.io.loadmat throws an error, switch to h5py!
    """
    try:
        # Try scipy first (works for most .mat files)
        from scipy.io import loadmat
        data = loadmat(file_path, squeeze_me=True)
        
        # Remove MATLAB metadata keys (they start with '__')
        data = {k: v for k, v in data.items() if not k.startswith('__')}
        
        print(f"Keys in .mat file: {list(data.keys())}")
        for k, v in data.items():
            if isinstance(v, np.ndarray):
                print(f"  '{k}': shape={v.shape}, dtype={v.dtype}")
            else:
                print(f"  '{k}': type={type(v)}")
        
        return data
    
    except NotImplementedError:
        # This means it's a v7.3 file — use h5py
        import h5py
        print("Detected MATLAB v7.3 format, using h5py...")
        
        data = {}
        with h5py.File(file_path, 'r') as f:
            for key in f.keys():
                data[key] = np.array(f[key])
                print(f"  '{key}': shape={data[key].shape}, dtype={data[key].dtype}")
        
        return data


# EXAMPLE: How MPIIGaze .mat files are structured:
#
#   loadmat("p00/day01.mat") returns:
#   {
#       'data': array of shape (N, 2) — [left_eye_data, right_eye_data],
#       'gaze': array of shape (N, 3) — [gaze_x, gaze_y, gaze_z],
#       'head': array of shape (N, 3) — [head_x, head_y, head_z],
#       ...
#   }
#
# For a DIFFERENT dataset, the keys will be different!
# Always print keys first, then figure out what each one means.


# --------------- CASE 3: NumPy .npz / .npy files ---------------
# Used by: preprocessed datasets, Kaggle competitions
#
# WHAT TO LOOK FOR:
#   - .npy = single array
#   - .npz = dictionary of arrays (like a zip of .npy files)

def load_npz(file_path: str) -> dict:
    """
    Load a .npz file (multiple arrays).
    
    Common structure:
      data['X_train']  — input features
      data['y_train']  — target labels
      data['X_test']   — test features
    """
    data = np.load(file_path, allow_pickle=True)
    
    print(f"Arrays in .npz file: {list(data.keys())}")
    for key in data.keys():
        arr = data[key]
        print(f"  '{key}': shape={arr.shape}, dtype={arr.dtype}")
    
    return dict(data)


def load_npy(file_path: str) -> np.ndarray:
    """Load a single .npy array."""
    arr = np.load(file_path, allow_pickle=True)
    print(f"Array shape: {arr.shape}, dtype: {arr.dtype}")
    return arr


# --------------- CASE 4: HDF5 files ---------------
# Used by: large-scale datasets, GazeCapture, some Kaggle datasets
#
# WHAT TO LOOK FOR:
#   - .h5 or .hdf5 extension
#   - Hierarchical structure (like folders inside a file)

def load_hdf5(file_path: str) -> dict:
    """
    Load an HDF5 file.
    Requires: pip install h5py
    """
    import h5py
    
    data = {}
    with h5py.File(file_path, 'r') as f:
        # Print the full tree structure
        def print_tree(name, obj):
            if isinstance(obj, h5py.Dataset):
                print(f"  Dataset: '{name}', shape={obj.shape}, dtype={obj.dtype}")
                data[name] = np.array(obj)
            else:
                print(f"  Group: '{name}'")
        
        f.visititems(print_tree)
    
    return data


# --------------- CASE 5: Image folder + labels ---------------
# Used by: GazeCapture, RT-Gene, EVE dataset
#
# WHAT TO LOOK FOR:
#   - Folder full of .jpg / .png images
#   - A separate .csv or .json file with labels
#   - Images might be: full face, eye crops, or head crops

def load_image_dataset(image_dir: str, labels_file: str) -> pd.DataFrame:
    """
    Load an image-based dataset.
    Returns a DataFrame with image paths + their labels.
    
    ADAPT:
      - Change the label file reader (csv, json, xml)
      - Change the image extension filter
    """
    # Load labels
    if labels_file.endswith('.csv'):
        labels_df = pd.read_csv(labels_file)
    elif labels_file.endswith('.json'):
        import json
        with open(labels_file) as f:
            labels_df = pd.DataFrame(json.load(f))
    else:
        raise ValueError(f"Unknown label format: {labels_file}")
    
    print(f"Labels shape: {labels_df.shape}")
    print(f"Labels columns: {list(labels_df.columns)}")
    
    # List all images
    image_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff'}
    images = []
    for f in sorted(os.listdir(image_dir)):
        if os.path.splitext(f)[1].lower() in image_extensions:
            images.append(os.path.join(image_dir, f))
    
    print(f"Found {len(images)} images")
    
    # IMPORTANT: You need to figure out how images map to labels!
    # Common patterns:
    #   1. Label file has a column 'image_name' or 'filename'
    #   2. Images are numbered 0001.jpg, 0002.jpg... matching row order
    #   3. Image name encodes the label (rare)
    
    return labels_df


# =============================================================================
# STEP 2: UNIVERSAL CLEANING PIPELINE
# =============================================================================
# This works on ANY DataFrame regardless of what loader you used.

def universal_clean(df: pd.DataFrame, verbose: bool = True) -> pd.DataFrame:
    """
    Universal data cleaning pipeline.
    Works with any dataset — just pass a DataFrame.
    
    Steps:
      1. Identify and separate numeric vs non-numeric columns
      2. Remove non-numeric metadata columns
      3. Handle missing values (NaN)
      4. Handle infinite values (Inf)
      5. Remove outliers using IQR method
      6. Remove duplicates
    
    Returns: cleaned DataFrame with only numeric columns.
    """
    
    if verbose:
        print(f"\n{'='*60}")
        print(f"CLEANING PIPELINE")
        print(f"{'='*60}")
        print(f"Input shape: {df.shape}")
    
    # --- Step 1: Separate numeric and non-numeric columns ---
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    non_numeric_cols = df.select_dtypes(exclude=[np.number]).columns.tolist()
    
    if verbose:
        print(f"\nNumeric columns ({len(numeric_cols)}): {numeric_cols}")
        print(f"Non-numeric columns ({len(non_numeric_cols)}): {non_numeric_cols}")
    
    # --- Step 2: Remove non-numeric columns ---
    # These are metadata (participant ID, session, eye side, etc.)
    # They are useful for grouping but NOT for model training.
    #
    # ADAPT: If you need to KEEP some non-numeric columns (e.g., for
    # stratified splitting), save them before dropping:
    #   metadata = df[non_numeric_cols].copy()
    
    if non_numeric_cols:
        if verbose:
            print(f"\nDropping non-numeric columns: {non_numeric_cols}")
        df = df[numeric_cols].copy()
    
    # --- Step 3: Handle NaN (missing values) ---
    nan_count = df.isna().sum().sum()
    if verbose:
        print(f"\nNaN values found: {nan_count}")
    
    if nan_count > 0:
        # OPTION A: Drop rows with any NaN (simplest, use when <5% missing)
        rows_before = len(df)
        df = df.dropna()
        if verbose:
            print(f"  Dropped {rows_before - len(df)} rows with NaN")
        
        # OPTION B: Fill NaN with column mean (use when 5-20% missing)
        # df = df.fillna(df.mean())
        
        # OPTION C: Fill NaN with median (better for skewed distributions)
        # df = df.fillna(df.median())
        
        # OPTION D: Forward/backward fill (for time-series data)
        # df = df.fillna(method='ffill').fillna(method='bfill')
    
    # --- Step 4: Handle Inf values ---
    inf_mask = np.isinf(df.values)
    inf_count = inf_mask.sum()
    if verbose:
        print(f"Inf values found: {inf_count}")
    
    if inf_count > 0:
        df = df.replace([np.inf, -np.inf], np.nan).dropna()
        if verbose:
            print(f"  Replaced Inf with NaN and dropped. New shape: {df.shape}")
    
    # --- Step 5: Remove outliers (IQR method) ---
    # IQR = Interquartile Range = Q3 - Q1
    # Outlier = any value < Q1 - 1.5*IQR  or  > Q3 + 1.5*IQR
    #
    # ADAPT: Change the multiplier (1.5) to be more or less aggressive:
    #   - 1.5 = standard (removes ~5-15% of data typically)
    #   - 3.0 = conservative (removes only extreme outliers)
    #   - 1.0 = aggressive (removes more data)
    
    rows_before = len(df)
    IQR_MULTIPLIER = 1.5  # <-- CHANGE THIS if needed
    
    Q1 = df.quantile(0.25)
    Q3 = df.quantile(0.75)
    IQR = Q3 - Q1
    
    lower = Q1 - IQR_MULTIPLIER * IQR
    upper = Q3 + IQR_MULTIPLIER * IQR
    
    # Keep only rows where ALL columns are within bounds
    mask = ((df >= lower) & (df <= upper)).all(axis=1)
    df = df[mask]
    
    if verbose:
        print(f"Outliers removed: {rows_before - len(df)}")
    
    # --- Step 6: Remove duplicates ---
    rows_before = len(df)
    df = df.drop_duplicates()
    if verbose:
        print(f"Duplicates removed: {rows_before - len(df)}")
        print(f"\nFinal shape: {df.shape}")
        print(f"{'='*60}")
    
    return df.reset_index(drop=True)


# =============================================================================
# STEP 3: UNIVERSAL ANALYSIS
# =============================================================================
# Run these on your cleaned DataFrame to generate all required plots.

def universal_analysis(df: pd.DataFrame, save_dir: str = "."):
    """
    Runs ALL analyses in one call:
      1. Correlation matrix
      2. Scatter plots (top correlated pairs)
      3. Distribution histograms with type detection
      4. K-Means clustering
      5. Basic statistics summary
    
    ADAPT: Change the number of scatter pairs, cluster count, etc.
    """
    import matplotlib.pyplot as plt
    from scipy import stats
    
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    n_cols = len(numeric_cols)
    
    print(f"\n{'='*60}")
    print(f"ANALYSIS: {len(df)} records, {n_cols} features")
    print(f"Features: {numeric_cols}")
    print(f"{'='*60}")
    
    # --- 1. CORRELATION MATRIX ---
    print("\n[1/4] Correlation matrix...")
    corr = df[numeric_cols].corr()
    
    fig, ax = plt.subplots(figsize=(max(8, n_cols), max(6, n_cols - 1)))
    im = ax.imshow(corr, cmap='RdBu_r', vmin=-1, vmax=1)
    
    ax.set_xticks(range(n_cols))
    ax.set_yticks(range(n_cols))
    ax.set_xticklabels(numeric_cols, rotation=45, ha='right')
    ax.set_yticklabels(numeric_cols)
    
    # Add correlation values as text
    for i in range(n_cols):
        for j in range(n_cols):
            ax.text(j, i, f'{corr.iloc[i, j]:.2f}',
                    ha='center', va='center', fontsize=8)
    
    plt.colorbar(im)
    plt.title('Correlation Matrix')
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, 'correlation_matrix.png'), dpi=300)
    plt.close()
    
    # --- 2. SCATTER PLOTS (top correlated pairs) ---
    print("[2/4] Scatter plots...")
    
    # Find top 4 most correlated pairs (excluding diagonal)
    pairs = []
    for i in range(n_cols):
        for j in range(i + 1, n_cols):
            pairs.append((numeric_cols[i], numeric_cols[j], abs(corr.iloc[i, j])))
    pairs.sort(key=lambda x: x[2], reverse=True)
    top_pairs = pairs[:4]  # ADAPT: change number of pairs
    
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    axes = axes.flatten()
    
    for idx, (col_a, col_b, r) in enumerate(top_pairs):
        axes[idx].scatter(df[col_a], df[col_b], alpha=0.3, s=3)
        axes[idx].set_xlabel(col_a)
        axes[idx].set_ylabel(col_b)
        axes[idx].set_title(f'{col_a} vs {col_b} (r={r:.2f})')
    
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, 'scatter_plots.png'), dpi=300)
    plt.close()
    
    # --- 3. DISTRIBUTIONS ---
    print("[3/4] Distributions...")
    
    # Calculate grid size dynamically based on number of features
    n_rows_plot = (n_cols + 2) // 3  # ceil(n_cols / 3)
    fig, axes = plt.subplots(n_rows_plot, 3, figsize=(12, 4 * n_rows_plot))
    axes = axes.flatten() if n_cols > 3 else [axes] if n_cols == 1 else axes.flatten()
    
    for i, col in enumerate(numeric_cols):
        data = df[col]
        axes[i].hist(data, bins=50, density=True, alpha=0.7)
        
        skew = stats.skew(data)
        kurt = stats.kurtosis(data)
        
        # Distribution type detection
        # ADAPT: tweak thresholds for your data
        if kurt < -0.8:
            dist_type = "Uniform (flat)"
        elif abs(skew) > 0.4:
            dist_type = "Skewed " + ("right" if skew > 0 else "left")
        elif kurt > 0.5:
            dist_type = "Leptokurtic (peaked)"
        elif abs(skew) < 0.3 and abs(kurt) < 0.5:
            dist_type = "Near-normal"
        else:
            dist_type = "Moderately asymmetric"
        
        axes[i].set_title(f'{col}\n{dist_type}\nskew={skew:.2f}, kurt={kurt:.2f}',
                          fontsize=9)
    
    # Hide unused subplots
    for i in range(n_cols, len(axes)):
        axes[i].set_visible(False)
    
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, 'distributions.png'), dpi=300)
    plt.close()
    
    # --- 4. CLUSTERING ---
    print("[4/4] Clustering...")
    
    # Pick first 2 numeric columns for 2D visualization
    # ADAPT: change which columns to cluster on
    if n_cols >= 2:
        from sklearn.cluster import KMeans
        
        cluster_cols = numeric_cols[:2]  # <-- CHANGE to your target columns
        X = df[cluster_cols].values
        
        km = KMeans(n_clusters=4, random_state=42, n_init=10)
        labels = km.fit_predict(X)
        
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.scatter(X[:, 0], X[:, 1], c=labels, cmap='tab10', alpha=0.4, s=5)
        ax.scatter(km.cluster_centers_[:, 0], km.cluster_centers_[:, 1],
                   c='black', marker='X', s=200, zorder=5, label='Centers')
        ax.set_xlabel(cluster_cols[0])
        ax.set_ylabel(cluster_cols[1])
        ax.set_title('K-Means clustering (k=4)')
        ax.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'clusters.png'), dpi=300)
        plt.close()
    
    # --- SUMMARY STATS ---
    print(f"\n{df.describe().to_string()}")
    print(f"\nAll plots saved to: {save_dir}")


# =============================================================================
# STEP 4: PREPARE DATA FOR NEURAL NETWORK
# =============================================================================

def prepare_for_training(df: pd.DataFrame,
                         target_cols: list = None,
                         test_size: float = 0.2,
                         scale: bool = True):
    """
    Converts a cleaned DataFrame into train/test arrays ready for PyTorch.
    
    Args:
        df: cleaned DataFrame (only numeric columns)
        target_cols: which columns are the TARGET (what to predict).
                     If None, you'll need to set this manually!
        test_size: fraction of data for testing (0.2 = 20%)
        scale: whether to standardize features (recommended for NN)
    
    Returns:
        dict with X_train, X_test, y_train, y_test, and scaler
    
    ADAPT:
      - Change target_cols to match YOUR dataset's target variable
      - For gaze: target is usually ['gaze_x', 'gaze_y'] or ['pitch', 'yaw']
      - For classification: target might be ['label'] or ['class']
    """
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler
    
    if target_cols is None:
        print("WARNING: target_cols not specified!")
        print(f"Available columns: {list(df.columns)}")
        print("Set target_cols to the columns you want to PREDICT.")
        print("Example: target_cols=['gaze_x', 'gaze_y']")
        return None
    
    # Separate features (X) and target (y)
    feature_cols = [c for c in df.columns if c not in target_cols]
    
    X = df[feature_cols].values
    y = df[target_cols].values
    
    print(f"Features ({len(feature_cols)}): {feature_cols}")
    print(f"Targets  ({len(target_cols)}): {target_cols}")
    print(f"X shape: {X.shape}, y shape: {y.shape}")
    
    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42
    )
    
    # Scale features
    scaler = None
    if scale:
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)  # IMPORTANT: use transform, NOT fit_transform!
        print("Applied StandardScaler to features")
    
    print(f"Train: {X_train.shape[0]} samples")
    print(f"Test:  {X_test.shape[0]} samples")
    
    return {
        'X_train': X_train,
        'X_test': X_test,
        'y_train': y_train,
        'y_test': y_test,
        'scaler': scaler,
        'feature_cols': feature_cols,
        'target_cols': target_cols,
    }


# =============================================================================
# QUICK REFERENCE: COMMON GAZE DATASET FORMATS
# =============================================================================
#
# DATASET          FORMAT      FEATURES                          TARGET
# --------         ------      --------                          ------
# MPIIGaze         .mat        head_pose (3), eye_image          gaze vector (3)
# MPIIFaceGaze     .mat        face_image, head_pose             gaze vector (3)
# GazeCapture      .h5/imgs    face_img, eye_imgs, face_grid     gaze point (x, y) in cm
# Columbia         .mat        head_pose (3)                     gaze angles (2)
# UT Multiview     .mat        head_pose, eye_image              gaze vector (3)
# ETH-XGaze        .h5         face_image, head_pose             gaze angles (2)
# RT-Gene          imgs+csv    face_img, eye_imgs                gaze angles (2)
# Tobii output     .csv        timestamp, x, y, pupil_size       gaze_x, gaze_y
# EyeLink          .asc/.csv   timestamp, x, y, pupil            gaze coordinates
#
# KEY DIFFERENCES:
#   - Some datasets give gaze as a 3D VECTOR (x, y, z) — your MPIIGaze case
#   - Some give gaze as 2 ANGLES (pitch, yaw) in radians
#   - Some give gaze as SCREEN COORDINATES (pixel x, pixel y)
#   - The conversion between these is straightforward (see below)


# =============================================================================
# BONUS: ANGLE <-> VECTOR CONVERSIONS
# =============================================================================

def vector_to_angles(gaze_vector: np.ndarray) -> np.ndarray:
    """
    Convert 3D gaze vector [x, y, z] to 2 angles [pitch, yaw] in radians.
    
    Use when: your dataset has 3D vectors but you want angular error metrics.
    """
    x, y, z = gaze_vector[..., 0], gaze_vector[..., 1], gaze_vector[..., 2]
    pitch = np.arcsin(-y)
    yaw = np.arctan2(-x, -z)
    return np.stack([pitch, yaw], axis=-1)


def angles_to_vector(angles: np.ndarray) -> np.ndarray:
    """
    Convert 2 angles [pitch, yaw] in radians to 3D gaze vector [x, y, z].
    
    Use when: your dataset has angles but your model expects 3D vectors.
    """
    pitch, yaw = angles[..., 0], angles[..., 1]
    x = -np.cos(pitch) * np.sin(yaw)
    y = -np.sin(pitch)
    z = -np.cos(pitch) * np.cos(yaw)
    return np.stack([x, y, z], axis=-1)


def angular_error(pred: np.ndarray, target: np.ndarray) -> float:
    """
    Compute mean angular error in DEGREES between predicted and target vectors.
    This is the standard metric for gaze estimation evaluation.
    """
    # Normalize to unit vectors
    pred_norm = pred / np.linalg.norm(pred, axis=-1, keepdims=True)
    target_norm = target / np.linalg.norm(target, axis=-1, keepdims=True)
    
    # Dot product -> angle
    cos_sim = np.sum(pred_norm * target_norm, axis=-1)
    cos_sim = np.clip(cos_sim, -1.0, 1.0)  # numerical safety
    
    angles_rad = np.arccos(cos_sim)
    angles_deg = np.degrees(angles_rad)
    
    return float(np.mean(angles_deg))


# =============================================================================
# USAGE EXAMPLE
# =============================================================================

if __name__ == "__main__":
    # ---- SCENARIO 1: You get a folder of CSV files ----
    # info = detect_dataset_format("path/to/new/dataset")
    # print(info)
    # df = load_csv("path/to/data.csv")
    # df = universal_clean(df)
    # universal_analysis(df)
    # result = prepare_for_training(df, target_cols=['gaze_x', 'gaze_y'])
    
    # ---- SCENARIO 2: You get MPIIGaze-like .mat files ----
    # (This is what your moduleone.py already does)
    # data = load_mat("path/to/p00/day01.mat")
    
    # ---- SCENARIO 3: You get a single big .npz file ----
    # data = load_npz("path/to/dataset.npz")
    # df = pd.DataFrame(data['features'], columns=['f1', 'f2', ...])
    
    # ---- SCENARIO 4: You get images + labels ----
    # df = load_image_dataset("path/to/images/", "path/to/labels.csv")
    # NOTE: for image datasets, you don't clean the labels table the same way.
    # Instead, you build a PyTorch Dataset class that loads images on-the-fly.
    
    print("This is a template file. Uncomment the scenario that matches your dataset.")
    print("Run detect_dataset_format() first to understand what you're working with.")
