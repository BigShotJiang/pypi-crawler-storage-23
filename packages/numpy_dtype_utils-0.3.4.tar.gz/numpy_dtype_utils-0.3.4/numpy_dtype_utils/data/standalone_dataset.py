
import os
from scipy.io import loadmat
import numpy as np 
import pandas as pd

class Dataset:
    """
    класс для работы с датасетом.
    имеет функции загрузки, инициализации, очистки и анализа посредством построенния различных диаграмм и тп.
    """
    def __init__(self, data_path):
        self.data_path = data_path
        self.records = []
        self.participants = []
        self.is_loaded = False

        if not os.path.exists(data_path):
            raise FileNotFoundError(f"Data path {data_path} does not exist")
    

    def load_data(self, max_participants: int = None, max_days: int = None, verbose: bool = True):
        if verbose:
            print("loading...")
            print("/" * 30)
        
        self.participants = sorted([
            d for d in os.listdir(self.data_path)
            if os.path.isdir(os.path.join(self.data_path, d))
        ])

        if max_participants:
            self.participants = self.participants[:max_participants]

        if verbose:
            print(f'participants: {len(self.participants)}')

        self.records = []

        for participant in self.participants:
            parti_path = os.path.join(self.data_path, participant)
            max_files = sorted([
                f for f in os.listdir(parti_path)
                if f.endswith(".mat")
            ])

            if max_days:
                max_files = max_files[:max_days]
            
            parti_records = 0

            for mat_file in max_files:
                file_path = os.path.join(parti_path, mat_file)
                day = mat_file.replace('.mat', '')

                new_records = self._load_mat_file(file_path, participant, day)
                self.records.extend(new_records)
                parti_records += len(new_records)

        self.is_loaded = True

        if verbose:
            print("/" * 30)
            print(f'total: {len(self.records)} records' )

        
        return self

    def _load_mat_file(self, file_path: str, participant: str, day: str) -> list:
        try:
            mat_data = loadmat(file_path)
            data = mat_data['data']
            records = []

            for eye in ['right', 'left']:
                eye_data = data[eye][0, 0]

                gaze = eye_data['gaze'][0, 0]
                pose = eye_data['pose'][0, 0]

                for i in range(len(gaze)):
                    record = {
                        'participant': participant,
                        'day': day,
                        'eye': eye,

                        'gaze_x': gaze[i, 0],
                        'gaze_y': gaze[i, 1],
                        'gaze_z': gaze[i, 2],

                        'head_pose_x': pose[i, 0],
                        'head_pose_y': pose[i, 1],
                        'head_pose_z': pose[i, 2],
                    }
                    records.append(record)

                return records
                
        except Exception as e:
            print(f'error loading {file_path}: {e}')
            return []

    def to_dataframe(self) -> pd.DataFrame:
        if not self.is_loaded:
            raise RuntimeError("Данные не загружены! Сначала вызовите load()")
        
        return pd.DataFrame(self.records)

    def to_numpy(self, columns: list = None) -> np.ndarray:
        df = self.to_dataframe()
        
        if columns is None:
            columns = ['gaze_x', 'gaze_y', 'gaze_z', 
                       'head_pose_x', 'head_pose_y', 'head_pose_z']
        
        return df[columns].values

    def get_numeric_columns(self) -> list:
        """Список числовых столбцов."""
        return ['gaze_x', 'gaze_y', 'gaze_z', 
                'head_pose_x', 'head_pose_y', 'head_pose_z']

    
    def info(self) -> str:
        """
        Получить информацию о датасете.
        
        Returns:
            строка с информацией
        """
        if not self.is_loaded:
            return "Данные не загружены. Вызовите load() для загрузки."
        
        df = self.to_dataframe()
        
        info_text = f"""
{'='*60}
ИНФОРМАЦИЯ О ДАТАСЕТЕ MPIIGaze
{'='*60}
Путь: {self.data_path}
Участников: {len(self.participants)}
Всего записей: {len(self.records)}
Записей на участника: ~{len(self.records) // len(self.participants)}

Столбцы:
{list(df.columns)}

Статистика числовых признаков:
{df.describe().round(4).to_string()}
{'='*60}
        """
        return info_text
    
    def __len__(self) -> int:
        """Количество записей."""
        return len(self.records)
    
    def __repr__(self) -> str:
        """Представление объекта."""
        status = "загружен" if self.is_loaded else "не загружен"
        return f"Dataset(path='{self.data_path}', записей={len(self.records)}, статус={status})"


    def clean(self):
        if not self.is_loaded:
            raise RuntimeError('data not loaded')
        
        initial_count = len(self.records)

        print('data cleaning..')
        print('/' * 30)
        print (f'records before cleaning: {initial_count}')

        df = self.to_dataframe()

        cols_to_drop = ['participant', 'day', 'eye']
        existing_cols = [c for c in cols_to_drop if c in df.columns]
        df = df.drop(columns=existing_cols)
        print('deleted meta: ', existing_cols)

        numeric_cols = self.get_numeric_columns()

        nan_count = df[numeric_cols].isna().any(axis=1).sum()
        df = df.dropna(subset=numeric_cols)

        print("deleted nan: ", nan_count)

        inf_mask = np.isinf(df[numeric_cols]).any(axis=1)
        inf_count = inf_mask.sum()
        df = df[~inf_mask]

        print("deleted inf: ", inf_count)


        Q1 = df[numeric_cols].quantile(0.25)
        Q3 = df[numeric_cols].quantile(0.75)
        IQR = Q3 - Q1

        outlier_mask = ~((df[numeric_cols] < (Q1 - 1.5 * IQR)) |
                         (df[numeric_cols] > (Q3 + 1.5 * IQR))).any(axis=1)

        outlier_count = (~outlier_mask).sum()
        df = df[outlier_mask]

        print('outlier deleted: ', outlier_count)

        dup_count = df.duplicated().sum()
        df = df.drop_duplicates()

        print('dublicates deleted: ', dup_count)

        self.records = df.to_dict('records')

        return self


    def plot_correlation_matrix(self):
        import matplotlib.pyplot as plt 
        import seaborn as sns

        df = self.to_dataframe()
        numeric_cols = self.get_numeric_columns()
        corr = df[numeric_cols].corr()

        plt.figure(figsize=(8,6))
        sns.heatmap(corr, annot=True, fmt='.2f', cmap='coolwarm', center=0)
        plt.title('correlation matrix')
        plt.tight_layout()
        plt.savefig('./correlation_matrix.png', dpi=300, bbox_inches='tight')

        return corr


    def plot_scatter(self, sample_size=5000):
        import matplotlib.pyplot as plt

        df = self.to_dataframe()

        # Берем выборку чтобы не было каши из 30к точек
        if len(df) > sample_size:
            df = df.sample(sample_size, random_state=42)

        pairs = [
            ('gaze_y', 'gaze_z'),
            ('head_pose_x', 'head_pose_z'),
            ('head_pose_y', 'head_pose_z'),
            ('gaze_x', 'head_pose_y'),
        ]

        fig, axes = plt.subplots(2, 2, figsize=(10, 8))
        axes = axes.flatten()

        for i, (x, y) in enumerate(pairs):
            axes[i].scatter(df[x], df[y], alpha=0.3, s=5)
            axes[i].set_xlabel(x)
            axes[i].set_ylabel(y)
            axes[i].set_title(f'{x} vs {y}')
            axes[i].grid(True, alpha=0.3)

        plt.tight_layout()
        plt.savefig('./scatter_plots.png', dpi=300)


    def plot_distributions(self):
        import matplotlib.pyplot as plt
        from scipy import stats

        df = self.to_dataframe()
        numeric_cols = self.get_numeric_columns()

        fig, axes = plt.subplots(2, 3, figsize=(12, 8))
        axes = axes.flatten()

        for i, col in enumerate(numeric_cols):
            data = df[col]

            # Гистограмма
            axes[i].hist(data, bins=50, density=True, alpha=0.7)
            axes[i].set_title(col)
            axes[i].set_xlabel(col)

            # Тест Шапиро-Уилка (на выборке — он не любит > 5000 точек)
            sample = data.sample(min(5000, len(data)), random_state=42)
            stat, p = stats.shapiro(sample)

            # Асимметрия и эксцесс
            skew = stats.skew(data)
            kurt = stats.kurtosis(data)

            # Определяем тип
            if kurt < -0.8:
                dist_type = "Равномерное (плоское)"
            elif abs(skew) > 0.4:
                dist_type = "Скошенное" + (" вправо" if skew > 0 else " влево")
            elif kurt > 0.5:
                dist_type = "Островершинное"
            elif abs(skew) < 0.3 and abs(kurt) < 0.5:
                dist_type = "Близко к нормальному"
            else:
                dist_type = "Умеренно асимметричное"
            axes[i].set_title(f'{col}\n{dist_type}\nskew={skew:.2f}, kurt={kurt:.2f}')

        plt.tight_layout()
        plt.savefig('./distributions.png', dpi=300)


    def plot_clusters(self):
        import matplotlib.pyplot as plt
        from sklearn.cluster import KMeans

        df = self.to_dataframe()
        X = df[['gaze_x', 'gaze_y']].values

        km = KMeans(n_clusters=4, random_state=42, n_init=10)
        labels = km.fit_predict(X)

        fig, ax = plt.subplots(figsize=(8, 6))

        ax.scatter(X[:, 0], X[:, 1], c=labels, cmap='tab10', alpha=0.4, s=5)
        ax.scatter(km.cluster_centers_[:, 0], km.cluster_centers_[:, 1],
                   c='black', marker='X', s=200, zorder=5, label='Центры')
        ax.set_xlabel('gaze_x')
        ax.set_ylabel('gaze_y')
        ax.set_title('K-Means кластеризация (k=4)')
        ax.legend()

        plt.tight_layout()
        plt.savefig('./clusters.png', dpi=300)
        print(f"Кластеры: 4, размеры: {dict(zip(*np.unique(labels, return_counts=True)))}")




        



        



        

if __name__ == "__main__":
    dataset = Dataset('dunno/data/MPIIGaze/Data/Normalized')

    dataset.load_data(max_days=6).clean()

    print(dataset.info())

    df = dataset.to_dataframe()
    print("\nПервые 5 записей очищенного датасета (без метаданных):")
    print(df.head())

    # dataset.plot_correlation_matrix()
    """
    Матрица показывает, что все 6 признаков несут уникальную информацию 
    (нет пар с корреляцией > 0.9, которые можно было бы выкинуть как дублирующие). 
    Самая интересная зависимость — gaze_y и gaze_z, 
    что объясняется геометрией единичного вектора направления взгляда.
    """
    # dataset.plot_scatter()
    """
    Диаграммы рассеяния показали, что связи между признаками преимущественно нелинейные. 
    Особенно это касается компонент вектора взгляда (gaze_y — gaze_z), 
    связанных геометрическим ограничением единичного вектора. 
    Признаки позы головы демонстрируют кластерную структуру, 
    обусловленную индивидуальными особенностями участников. 
    Это означает, что для моделирования предпочтительны методы, 
    способные улавливать нелинейные зависимости (например, нейронные сети).
    """

    # dataset.plot_distributions()

    # dataset.plot_clusters()
    """
    K-Means кластеризация с k=4 разбила пространство направлений взгляда 
    на 4 приблизительно равные зоны (≈7000–7500 точек в каждой), 
    соответствующие квадрантам экрана. Кластеры получились равномерными по размеру, 
    что подтверждает непрерывный характер пространства взглядов: 
    люди смотрят равномерно по всей области экрана, а не концентрируются в отдельных точках.
    """

    













"""
Выводы о влиянии данных на обучение модели
1. Структура признаков
После очистки данных осталось 6 числовых признаков (3 компоненты вектора взгляда + 3 компоненты позы головы) и 28 989 записей. Все нетиповые и метаданные-поля (
participant
, day, 
eye
) были удалены. Пропусков и дубликатов нет, удалено 5 228 выбросов (15.3%).

Влияние на модель: Датасет чистый и готов к обучению. Отсутствие пропусков исключает необходимость импутации. Размер выборки (~29 тыс.) достаточен для обучения нейронной сети.

2. Корреляция и мультиколлинеарность
Матрица корреляции показала, что ни одна пара признаков не имеет корреляции > 0.9, значит дублирующих признаков нет. Наибольшая корреляция — gaze_y и gaze_z (0.75), обусловленная геометрическим ограничением единичного вектора (x² + y² + z² = 1).

Влияние на модель: Все 6 признаков несут уникальную информацию — удалять нечего. Однако gaze_z частично избыточен, т.к. вычисляется из gaze_x и gaze_y. Модель сама «поймёт» эту связь, но при необходимости сокращения размерности gaze_z — первый кандидат на удаление.

3. Нелинейность связей
Диаграммы рассеяния выявили преимущественно нелинейные зависимости: параболическую связь gaze_y — gaze_z, V-образную связь head_pose_x — head_pose_z, кластерную структуру по участникам в позе головы.

Влияние на модель: Линейные модели (линейная регрессия, SVM с линейным ядром) будут работать плохо. Предпочтительны методы, способные улавливать нелинейные зависимости: нейронные сети, градиентный бустинг (XGBoost), SVM с RBF-ядром.

4. Распределения признаков
gaze_x, gaze_y — равномерные (плоские), kurt ≈ -1.05
gaze_z — скошенное вправо, skew = 0.53
head_pose_x — скошенное влево, skew = -0.62
head_pose_y — близко к нормальному, skew = 0.13
head_pose_z — скошенное вправо, skew = 0.54
Влияние на модель: Ненормальность распределений означает, что стандартизация (z-score) предпочтительнее нормализации (min-max). Для моделей, чувствительных к масштабу (нейронные сети, SVM), обязательно применять StandardScaler. Древесные модели (Random Forest, XGBoost) к масштабу нечувствительны.

5. Кластерный анализ
K-Means с k=4 разбил пространство взглядов на 4 равные зоны (~7000 точек каждая). Отсутствие чёткого «локтя» подтверждает, что данные представляют непрерывное облако, а не дискретные классы.

Влияние на модель: Задача предсказания направления взгляда — это задача регрессии (предсказание непрерывных углов), а не классификации. Попытка свести её к классификации по зонам приведёт к потере точности. Функция потерь должна быть непрерывной (MSE, MAE или угловая ошибка).
"""






"""
Описание подхода обработки данных
Обработка данных выполнялась в следующем порядке:

Этап 1: Загрузка
Данные загружены из .mat файлов (формат MATLAB) для 15 участников. Из каждого файла извлечены 3 компоненты вектора взгляда и 3 компоненты позы головы, а также метаданные (ID участника, день записи, глаз).

Этап 2: Удаление нерелевантных признаков
Удалены нетиповые (нечисловые) поля, не влияющие на обучение:

participant
 — идентификатор участника (строка)
day — день записи (строка)
eye
 — левый/правый глаз (строка)
Этап 3: Очистка
NaN: обнаружено и удалено — 0
Inf: обнаружено и удалено — 0
Выбросы: удалено 5 228 записей (15.3%) методом IQR (межквартильный размах × 1.5)
Дубликаты: обнаружено и удалено — 0
Этап 4: Анализ
Корреляционный анализ — выявлена связь gaze_y–gaze_z (0.75), остальные пары < 0.6
Диаграммы рассеяния — обнаружены нелинейные зависимости
Анализ распределений — определён тип каждого признака по skewness/kurtosis
Кластерный анализ (K-Means) — подтверждён непрерывный характер данных

"""