"""
numpy_dtype_utils — Advanced data type handling, gaze estimation, and dataset utilities.

Subpackages:
    core  — dtype casting, inspection, compatibility (cast.py, inspect.py)
    data  — dataset loading, cleaning, analysis (dataset.py, universal_loader.py)
    ml    — CNN model, training, API, GUI (moduletwo.py, api.py, gui.py)
    docs  — CHEATSHEET.md and other reference materials
"""

# ── core ──
from .core import (
    safe_cast, promote, to_structured_array,
    get_dtype_info, describe_structured_dtype, is_compatible,
)

# ── data ──
from .data import (
    Dataset, StandaloneDataset,
    detect_dataset_format, universal_clean, universal_analysis,
    prepare_for_training,
    load_csv, load_multiple_csv, load_mat,
    load_npz, load_npy, load_hdf5, load_image_dataset,
    vector_to_angles, angles_to_vector, angular_error,
)

# ── data.toolkit ──
from .data import (
    smart_load, quick_eda, auto_clean,
    encode_categoricals, add_interaction_features,
    add_polynomial_features, add_statistical_features,
    normalize, apply_transforms, analyze_distributions,
    find_high_correlations, compute_vif, run_pca,
    smart_split, leave_one_participant_out,
    evaluate_regression, evaluate_classification, angular_error_metric,
    plot_correlation_heatmap, plot_distributions_grid,
    plot_scatter_pairs, plot_training_curves, plot_predicted_vs_actual,
    load_images_from_folder, augment_batch,
    save_to_format, generate_report_text, run_full_analysis,
)

# ── ml ──
from .ml import (
    GazeCNN, GazeDataset, load_data, train_model,
    hypersearch, plot_curves, plot_final_curve, plot_predictions,
)

# NOTE: ml.api and ml.gui load model weights on import.
# Import them explicitly when needed:
#   from numpy_dtype_utils.ml.api import app, predict_gaze
#   from numpy_dtype_utils.ml.gui import predict, draw_arrow

__all__ = [
    # core
    "safe_cast", "promote", "to_structured_array",
    "get_dtype_info", "describe_structured_dtype", "is_compatible",
    # data
    "Dataset", "StandaloneDataset",
    "detect_dataset_format", "universal_clean", "universal_analysis",
    "prepare_for_training",
    "load_csv", "load_multiple_csv", "load_mat",
    "load_npz", "load_npy", "load_hdf5", "load_image_dataset",
    "vector_to_angles", "angles_to_vector", "angular_error",
    # data.toolkit
    "smart_load", "quick_eda", "auto_clean",
    "encode_categoricals", "add_interaction_features",
    "add_polynomial_features", "add_statistical_features",
    "normalize", "apply_transforms", "analyze_distributions",
    "find_high_correlations", "compute_vif", "run_pca",
    "smart_split", "leave_one_participant_out",
    "evaluate_regression", "evaluate_classification", "angular_error_metric",
    "plot_correlation_heatmap", "plot_distributions_grid",
    "plot_scatter_pairs", "plot_training_curves", "plot_predicted_vs_actual",
    "load_images_from_folder", "augment_batch",
    "save_to_format", "generate_report_text", "run_full_analysis",
    # ml
    "GazeCNN", "GazeDataset", "load_data", "train_model",
    "hypersearch", "plot_curves", "plot_final_curve", "plot_predictions",
]
