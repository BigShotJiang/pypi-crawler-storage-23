import numpy as np

def get_dtype_info(dtype):
    """
    Get detailed information about a numpy dtype.
    
    Args:
        dtype: A numpy dtype object or convertible representation.
        
    Returns:
        dict: A dictionary containing size, alignment, kind, and char code.
    """
    dt = np.dtype(dtype)
    return {
        "name": dt.name,
        "itemsize": dt.itemsize,
        "alignment": dt.alignment,
        "kind": dt.kind,
        "char": dt.char,
        "byteorder": dt.byteorder,
        "is_structured": dt.names is not None
    }

def describe_structured_dtype(dtype):
    """
    Returns a human-readable description of a structured dtype.
    
    Args:
        dtype: A numpy dtype.
        
    Returns:
        list: List of (field_name, field_dtype, offset) tuples.
    """
    dt = np.dtype(dtype)
    if dt.names is None:
        return []
    
    description = []
    for name in dt.names:
        field_dt, offset = dt.fields[name][:2]
        description.append({
            "name": name,
            "dtype": str(field_dt),
            "offset": offset,
            "base_type": field_dt.base.name
        })
    return description

def is_compatible(dtype1, dtype2):
    """
    Check if two dtypes are cast-compatible safely.
    """
    return np.can_cast(dtype1, dtype2, casting='safe')
