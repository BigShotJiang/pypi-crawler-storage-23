"""Core dtype utilities: casting, inspection, compatibility checks."""

from .cast import safe_cast, promote, to_structured_array
from .inspect import get_dtype_info, describe_structured_dtype, is_compatible

__all__ = [
    "safe_cast",
    "promote",
    "to_structured_array",
    "get_dtype_info",
    "describe_structured_dtype",
    "is_compatible",
]
