import numpy as np

def safe_cast(array, target_dtype):
    """
    Safely cast array to target dtype, ensuring no loss of precision.
    
    Args:
        array: Input numpy array.
        target_dtype: Target numpy dtype.
        
    Returns:
        np.ndarray: Casted array.
        
    Raises:
        ValueError: If safe casting is not possible.
    """
    if not np.can_cast(array.dtype, target_dtype, casting='safe'):
        raise ValueError(f"Cannot simply cast {array.dtype} to {target_dtype} without loss of precision")
    return array.astype(target_dtype)

def promote(dtype1, dtype2):
    """
    Find the common dtype that both dtypes can be safely cast to.
    
    Args:
        dtype1: First dtype.
        dtype2: Second dtype.
        
    Returns:
        np.dtype: The promoted dtype.
    """
    return np.promote_types(dtype1, dtype2)

def to_structured_array(dict_list):
    """
    Convert a list of dictionaries to a structured numpy array.
    """
    if not dict_list:
        return np.array([])
    
    # Infer schema from first element
    first = dict_list[0]
    dtype = []
    for k, v in first.items():
        if isinstance(v, str):
            dtype.append((k, 'U50'))
        elif isinstance(v, float):
            dtype.append((k, 'f8'))
        elif isinstance(v, int):
            dtype.append((k, 'i8'))
        else:
            dtype.append((k, 'O'))
            
    arr = np.zeros(len(dict_list), dtype=dtype)
    for i, d in enumerate(dict_list):
        for k in dtype:
            name = k[0]
            if name in d:
                arr[i][name] = d[name]
    return arr
