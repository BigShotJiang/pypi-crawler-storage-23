"""Machine learning: CNN model, training, API, and GUI."""

from .moduletwo import (
    GazeCNN,
    GazeDataset,
    load_data,
    train as train_model,
    hypersearch,
    plot_curves,
    plot_final_curve,
    plot_predictions,
)

# NOTE: api.py and gui.py load model weights at import time.
# Import them directly when needed:
#   from numpy_dtype_utils.ml.api import app, predict_gaze
#   from numpy_dtype_utils.ml.gui import predict, draw_arrow

__all__ = [
    "GazeCNN",
    "GazeDataset",
    "load_data",
    "train_model",
    "hypersearch",
    "plot_curves",
    "plot_final_curve",
    "plot_predictions",
]
