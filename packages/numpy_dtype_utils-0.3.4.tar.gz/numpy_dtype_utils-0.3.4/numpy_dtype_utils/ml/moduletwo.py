"""
Модуль 2: CNN для оценки направления взгляда
=============================================
Вход:  изображение глаза (36x60) + поза головы (3 числа)
Выход: направление взгляда (gaze_x, gaze_y)

Стек: PyTorch, scikit-learn, NumPy, scipy, matplotlib
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error
from scipy.io import loadmat


# ──────────────────────────────────────────────
# 1. ЗАГРУЗКА ДАННЫХ
# ──────────────────────────────────────────────

def load_data(data_path):
    """Читает все .mat файлы и возвращает три массива."""
    images, poses, gazes = [], [], []

    for participant in sorted(os.listdir(data_path)):
        p_path = os.path.join(data_path, participant)
        if not os.path.isdir(p_path):
            continue

        for mat_file in sorted(os.listdir(p_path)):
            if not mat_file.endswith('.mat'):
                continue

            mat = loadmat(os.path.join(p_path, mat_file))['data']

            for eye in ['right', 'left']:
                d = mat[eye][0, 0]
                images.append(d['image'][0, 0])          # (N, 36, 60) uint8
                poses.append(d['pose'][0, 0])             # (N, 3)
                gazes.append(d['gaze'][0, 0][:, :2])     # (N, 2)  — только x, y

    images = np.concatenate(images).astype(np.float32) / 255.0  # нормировка [0, 1]
    poses  = np.concatenate(poses).astype(np.float32)
    gazes  = np.concatenate(gazes).astype(np.float32)

    print(f"Загружено: {len(images)} записей")
    print(f"  images: {images.shape}, poses: {poses.shape}, gazes: {gazes.shape}")
    return images, poses, gazes


# ──────────────────────────────────────────────
# 2. DATASET
# ──────────────────────────────────────────────

class GazeDataset(Dataset):
    def __init__(self, images, poses, gazes):
        # unsqueeze(1) — добавляем канал: (N,36,60) → (N,1,36,60)
        self.images = torch.tensor(images).unsqueeze(1)
        self.poses  = torch.tensor(poses)
        self.gazes  = torch.tensor(gazes)

    def __len__(self):
        return len(self.images)

    def __getitem__(self, i):
        return self.images[i], self.poses[i], self.gazes[i]


# ──────────────────────────────────────────────
# 3. АРХИТЕКТУРА CNN
# ──────────────────────────────────────────────

class GazeCNN(nn.Module):
    """
    CNN-ветка обрабатывает изображение глаза и извлекает признаки
    (положение зрачка, форма радужки).
    MLP-ветка обрабатывает позу головы.
    Два вектора признаков объединяются и дают (gaze_x, gaze_y).
    """
    def __init__(self):
        super().__init__()

        # Свёрточная часть: 1×36×60 → 128×2×5
        self.cnn = nn.Sequential(
            nn.Conv2d(1, 32, 3),  nn.ReLU(), nn.MaxPool2d(2),  # → 32×17×29
            nn.Conv2d(32, 64, 3), nn.ReLU(), nn.MaxPool2d(2),  # → 64×7×13
            nn.Conv2d(64, 128, 3),nn.ReLU(), nn.MaxPool2d(2),  # → 128×2×5
        )
        self.cnn_head = nn.Sequential(
            nn.Flatten(),
            nn.Linear(128 * 2 * 5, 256), nn.ReLU(), nn.Dropout(0.3),
        )

        # Поза головы: 3 → 64
        self.pose_head = nn.Sequential(
            nn.Linear(3, 64), nn.ReLU(),
        )

        # Слияние: 256+64 → 128 → 2
        self.out = nn.Sequential(
            nn.Linear(320, 128), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(128, 2),
        )

        # Инициализация весов
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, nonlinearity='relu')
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, img, pose):
        x = torch.cat([self.cnn_head(self.cnn(img)),
                        self.pose_head(pose)], dim=1)
        return self.out(x)


# ──────────────────────────────────────────────
# 4. ОБУЧЕНИЕ
# ──────────────────────────────────────────────

def train(model, train_dl, val_dl, epochs=50, lr=5e-4, device='cpu', save='best_gaze_cnn.pth'):
    model = model.to(device)
    opt   = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, patience=5, factor=0.5)

    best_loss = float('inf')
    history = {'train': [], 'val': []}

    for ep in range(1, epochs + 1):
        # train
        model.train()
        t_losses = []
        for img, pose, gaze in train_dl:
            img, pose, gaze = img.to(device), pose.to(device), gaze.to(device)
            opt.zero_grad()
            loss = loss_fn(model(img, pose), gaze)
            loss.backward()
            opt.step()
            t_losses.append(loss.item())

        # val
        model.eval()
        v_losses = []
        with torch.no_grad():
            for img, pose, gaze in val_dl:
                img, pose, gaze = img.to(device), pose.to(device), gaze.to(device)
                v_losses.append(loss_fn(model(img, pose), gaze).item())

        t_loss = np.mean(t_losses)
        v_loss = np.mean(v_losses)
        history['train'].append(t_loss)
        history['val'].append(v_loss)
        sched.step(v_loss)

        if v_loss < best_loss:
            best_loss = v_loss
            torch.save(model.state_dict(), save)

        if ep % 5 == 0 or ep == 1:
            print(f"Epoch {ep:3d}/{epochs}  train={t_loss:.5f}  val={v_loss:.5f}  lr={opt.param_groups[0]['lr']:.0e}")

    model.load_state_dict(torch.load(save, weights_only=True))
    print(f"\nВеса сохранены: {save}  (best val={best_loss:.5f})")
    return history


# ──────────────────────────────────────────────
# 5. ПОДБОР ГИПЕРПАРАМЕТРОВ
# ──────────────────────────────────────────────

def hypersearch(train_ds, val_ds, device):
    """Перебор 3 конфигураций по 20 эпох, возвращает лучшую."""
    configs = [
        dict(lr=1e-3, batch=128,  label='baseline'),
        dict(lr=5e-4, batch=128,  label='lower_lr'),   # ← обычно лучшая
        dict(lr=1e-3, batch=256,  label='large_batch'),
    ]
    results = []

    for cfg in configs:
        print(f"\n── {cfg['label']} ──")
        tr = DataLoader(train_ds, cfg['batch'], shuffle=True)
        vl = DataLoader(val_ds,   cfg['batch'], shuffle=False)
        m  = GazeCNN()
        h  = train(m, tr, vl, epochs=2, lr=cfg['lr'], device=device,
                   save=f"model_{cfg['label']}.pth")
        results.append({**cfg, 'val_loss': min(h['val']), 'history': h})

    print("\n── Результаты ──")
    for r in results:
        print(f"  {r['label']:12s}  lr={r['lr']:.0e}  batch={r['batch']}  val={r['val_loss']:.5f}")

    best = min(results, key=lambda r: r['val_loss'])
    print(f"\nЛучшая: {best['label']}  (val={best['val_loss']:.5f})")
    return results, best


# ──────────────────────────────────────────────
# 6. ВИЗУАЛИЗАЦИЯ
# ──────────────────────────────────────────────

def plot_curves(results):
    fig, axes = plt.subplots(1, len(results), figsize=(6 * len(results), 4))
    if len(results) == 1:
        axes = [axes]
    for ax, r in zip(axes, results):
        ep = range(1, len(r['history']['train']) + 1)
        ax.plot(ep, r['history']['train'], label='Train')
        ax.plot(ep, r['history']['val'],   label='Val', linestyle='--')
        ax.set_title(f"{r['label']}  lr={r['lr']}")
        ax.set_xlabel('Эпоха'); ax.set_ylabel('MSE Loss')
        ax.legend(); ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig('training_curves.png', dpi=200)
    print("training_curves.png сохранён")


def plot_final_curve(history):
    ep = range(1, len(history['train']) + 1)
    plt.figure(figsize=(8, 4))
    plt.plot(ep, history['train'], label='Train')
    plt.plot(ep, history['val'],   label='Val', linestyle='--')
    plt.xlabel('Эпоха'); plt.ylabel('MSE Loss')
    plt.title('Финальная модель: Train vs Val Loss')
    plt.legend(); plt.grid(alpha=0.3); plt.tight_layout()
    plt.savefig('final_training_curve.png', dpi=200)
    print("final_training_curve.png сохранён")


def plot_predictions(model, val_ds, device):
    model.eval()
    dl = DataLoader(val_ds, batch_size=1024, shuffle=False)
    preds, targets = [], []
    with torch.no_grad():
        for img, pose, gaze in dl:
            p = model(img.to(device), pose.to(device)).cpu().numpy()
            preds.append(p); targets.append(gaze.numpy())

    pred   = np.concatenate(preds)
    actual = np.concatenate(targets)

    # Угловая ошибка
    pn = pred   / (np.linalg.norm(pred,   axis=1, keepdims=True) + 1e-8)
    an = actual / (np.linalg.norm(actual, axis=1, keepdims=True) + 1e-8)
    ang = np.degrees(np.arccos(np.clip((pn * an).sum(1), -1, 1)))

    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    for i, (ax, label, color) in enumerate(zip(
            axes[:2], ['gaze_x', 'gaze_y'], ['steelblue', 'orange'])):
        ax.scatter(actual[:, i], pred[:, i], alpha=0.1, s=2, color=color)
        lo, hi = actual[:, i].min(), actual[:, i].max()
        ax.plot([lo, hi], [lo, hi], 'r--')
        ax.set_title(f'{label}: Predicted vs Actual')
        ax.set_xlabel('Реальное'); ax.set_ylabel('Предсказанное')
        ax.grid(alpha=0.3)

    axes[2].hist(ang, bins=50, color='steelblue', edgecolor='white')
    axes[2].axvline(ang.mean(), color='red', linestyle='--',
                    label=f'Mean = {ang.mean():.2f}°')
    axes[2].set_title('Угловая ошибка')
    axes[2].set_xlabel('Градусы'); axes[2].legend(); axes[2].grid(alpha=0.3)

    plt.suptitle(f'CNN | Mean Angular Error = {ang.mean():.2f}°')
    plt.tight_layout()
    plt.savefig('predictions.png', dpi=200)

    print(f"\nMSE: {mean_squared_error(actual, pred):.5f}")
    print(f"MAE: {mean_absolute_error(actual, pred):.5f}")
    print(f"Mean Angular Error: {ang.mean():.2f}°")


# ──────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────

if __name__ == '__main__':
    DATA_PATH = 'dunno/data/MPIIGaze/Data/Normalized'
    DEVICE    = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Device: {DEVICE}\n")

    # 1. Данные
    images, poses, gazes = load_data(DATA_PATH)

    # Нормировка позы
    scaler = StandardScaler()
    poses  = scaler.fit_transform(poses).astype(np.float32)

    # Split
    idx = np.arange(len(images))
    tr_idx, val_idx = train_test_split(idx, test_size=0.2, random_state=42)
    train_ds = GazeDataset(images[tr_idx], poses[tr_idx], gazes[tr_idx])
    val_ds   = GazeDataset(images[val_idx], poses[val_idx], gazes[val_idx])
    print(f"Train: {len(train_ds)}  Val: {len(val_ds)}\n")

    # 2. Подбор гиперпараметров
    results, best = hypersearch(train_ds, val_ds, DEVICE)
    plot_curves(results)

    # 3. Финальное обучение
    print("\n── Финальное обучение (50 эпох) ──")
    final_model = GazeCNN()
    tr_dl  = DataLoader(train_ds, best['batch'], shuffle=True)
    val_dl = DataLoader(val_ds,   best['batch'], shuffle=False)
    history = train(final_model, tr_dl, val_dl,
                    epochs=5, lr=best['lr'], device=DEVICE,
                    save='best_gaze_cnn.pth')

    # 4. Визуализация
    plot_final_curve(history)
    plot_predictions(final_model, val_ds, DEVICE)

    print("\nГотово. Файлы: best_gaze_cnn.pth, training_curves.png, predictions.png, final_training_curve.png")
