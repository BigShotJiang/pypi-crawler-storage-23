"""
Streamlit GUI для распознавания направления взгляда.
Запуск:  streamlit run gui.py
"""

import io
import math
import numpy as np
import torch
import torch.nn as nn
import streamlit as st
from PIL import Image, ImageDraw


# ── Модель (копия из moduletwo) ──

class GazeCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv2d(1, 32, 3), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 3), nn.ReLU(), nn.MaxPool2d(2),
        )
        self.cnn_fc  = nn.Sequential(nn.Flatten(), nn.Linear(128*2*5, 256), nn.ReLU(), nn.Dropout(0.3))
        self.pose_fc = nn.Sequential(nn.Linear(3, 64), nn.ReLU())
        self.fusion  = nn.Sequential(nn.Linear(320, 128), nn.ReLU(), nn.Dropout(0.3), nn.Linear(128, 2))

    def forward(self, img, pose):
        x = torch.cat([self.cnn_fc(self.cnn(img)), self.pose_fc(pose)], dim=1)
        return self.fusion(x)


@st.cache_resource
def load_model():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    m = GazeCNN().to(device)
    m.load_state_dict(torch.load("best_gaze_cnn.pth", map_location=device, weights_only=True))
    m.eval()
    return m, device


def predict(img_pil, pose_x, pose_y, pose_z):
    model, device = load_model()
    img = img_pil.convert("L").resize((60, 36))
    arr = np.array(img, dtype=np.float32) / 255.0
    t_img  = torch.tensor(arr).unsqueeze(0).unsqueeze(0).to(device)
    t_pose = torch.tensor([[pose_x, pose_y, pose_z]], dtype=torch.float32).to(device)
    with torch.no_grad():
        out = model(t_img, t_pose)
    return float(out[0, 0]), float(out[0, 1])


def draw_arrow(img_pil, gx, gy):
    img = img_pil.convert("RGB").resize((300, 180))
    draw = ImageDraw.Draw(img)
    cx, cy = img.width // 2, img.height // 2
    length = 100
    ex, ey = cx + int(gx * length), cy + int(gy * length)
    draw.line([(cx, cy), (ex, ey)], fill=(255, 50, 50), width=3)
    draw.ellipse([cx-4, cy-4, cx+4, cy+4], fill=(255, 255, 0))
    draw.ellipse([ex-5, ey-5, ex+5, ey+5], fill=(255, 50, 50))
    draw.text((5, 5), f"gaze: ({gx:.3f}, {gy:.3f})", fill=(255, 255, 255))
    return img


# ── Интерфейс ──

st.set_page_config(page_title="Gaze Estimation", layout="centered")
st.title("👁️ Распознавание направления взгляда")
st.caption("Загрузите изображение глаза и укажите позу головы")

uploaded = st.file_uploader("Изображение глаза", type=["png", "jpg", "jpeg", "bmp"])

st.subheader("Поза головы")
col1, col2, col3 = st.columns(3)
pose_x = col1.slider("pose_x", -1.0, 1.0, 0.0, 0.01)
pose_y = col2.slider("pose_y", -1.0, 1.0, 0.0, 0.01)
pose_z = col3.slider("pose_z", -1.0, 1.0, 0.0, 0.01)

if uploaded:
    img = Image.open(uploaded)
    st.image(img, caption="Загруженное изображение", width=300)

    if st.button("🔍 Распознать взгляд", type="primary"):
        gx, gy = predict(img, pose_x, pose_y, pose_z)

        yaw   = math.degrees(math.atan2(gx, -math.sqrt(max(0, 1 - gx**2 - gy**2))))
        pitch = math.degrees(math.atan2(gy, -math.sqrt(max(0, 1 - gx**2 - gy**2))))

        st.subheader("Результат")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("gaze_x", f"{gx:.4f}")
        c2.metric("gaze_y", f"{gy:.4f}")
        c3.metric("yaw°",   f"{yaw:.1f}")
        c4.metric("pitch°", f"{pitch:.1f}")

        viz = draw_arrow(img, gx, gy)
        st.image(viz, caption="Визуализация направления взгляда", width=400)
