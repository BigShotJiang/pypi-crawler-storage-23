"""
API для оценки направления взгляда
===================================
Запуск:
    python api.py
    # или
    uvicorn api:app --reload

Документация (Swagger):
    http://127.0.0.1:8000/docs

Эндпоинты:
    POST /predict   — возвращает gaze_x, gaze_y, угловые координаты
    POST /visualize — возвращает PNG-изображение с вектором взгляда
"""

import io
import math
import numpy as np
import torch
import torch.nn as nn
from PIL import Image, ImageDraw
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import Response
from pydantic import BaseModel


# ──────────────────────────────────────────────
# МОДЕЛЬ (копия из moduletwo.py)
# ──────────────────────────────────────────────

class GazeCNN(nn.Module):
    """
    CNN для оценки направления взгляда.

    Принимает:
        img  — тензор (1, 1, 36, 60), grayscale, значения [0, 1]
        pose — тензор (1, 3), нормированная поза головы

    Возвращает:
        тензор (1, 2) — предсказанные gaze_x и gaze_y
    """
    def __init__(self):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv2d(1, 32, 3),  nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 3),nn.ReLU(), nn.MaxPool2d(2),
        )
        # Имена слоёв должны точно совпадать с теми, что были при сохранении весов
        self.cnn_fc   = nn.Sequential(nn.Flatten(), nn.Linear(128*2*5, 256), nn.ReLU(), nn.Dropout(0.3))
        self.pose_fc  = nn.Sequential(nn.Linear(3, 64), nn.ReLU())
        self.fusion   = nn.Sequential(nn.Linear(320, 128), nn.ReLU(), nn.Dropout(0.3), nn.Linear(128, 2))

    def forward(self, img, pose):
        x = torch.cat([self.cnn_fc(self.cnn(img)), self.pose_fc(pose)], dim=1)
        return self.fusion(x)


# ──────────────────────────────────────────────
# ЗАГРУЗКА ВЕСОВ ПРИ СТАРТЕ
# ──────────────────────────────────────────────

WEIGHTS_PATH = "best_gaze_cnn.pth"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

model = GazeCNN().to(DEVICE)
model.load_state_dict(torch.load(WEIGHTS_PATH, map_location=DEVICE, weights_only=True))
model.eval()

print(f"Модель загружена: {WEIGHTS_PATH}  |  device: {DEVICE}")


# ──────────────────────────────────────────────
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ──────────────────────────────────────────────

def preprocess_image(raw_bytes: bytes) -> torch.Tensor:
    """
    Принимает сырые байты изображения глаза.
    Конвертирует в grayscale, ресайзит до 60×36, нормирует [0,1].
    Возвращает тензор (1, 1, 36, 60).
    """
    img = Image.open(io.BytesIO(raw_bytes)).convert("L")  # grayscale
    img = img.resize((60, 36))                             # ширина=60, высота=36
    arr = np.array(img, dtype=np.float32) / 255.0         # нормировка
    return torch.tensor(arr).unsqueeze(0).unsqueeze(0).to(DEVICE)  # (1,1,36,60)


def predict_gaze(img_tensor: torch.Tensor, pose: list[float]) -> tuple[float, float]:
    """
    Выполняет инференс модели.

    Args:
        img_tensor: тензор изображения (1, 1, 36, 60)
        pose:       список из 3 чисел [pose_x, pose_y, pose_z]

    Returns:
        (gaze_x, gaze_y) — компоненты вектора взгляда
    """
    pose_tensor = torch.tensor([pose], dtype=torch.float32).to(DEVICE)
    with torch.no_grad():
        output = model(img_tensor, pose_tensor)
    gx, gy = float(output[0, 0]), float(output[0, 1])
    return gx, gy


def gaze_to_angles(gx: float, gy: float) -> tuple[float, float]:
    """
    Конвертирует вектор взгляда (gx, gy) в углы в градусах.

    yaw  — горизонтальный угол (влево/вправо)
    pitch— вертикальный угол   (вверх/вниз)
    """
    yaw   = math.degrees(math.atan2(gx, -math.sqrt(max(0, 1 - gx**2 - gy**2))))
    pitch = math.degrees(math.atan2(gy, -math.sqrt(max(0, 1 - gx**2 - gy**2))))
    return round(yaw, 3), round(pitch, 3)


def draw_gaze_arrow(raw_bytes: bytes, gx: float, gy: float) -> bytes:
    """
    Рисует стрелку направления взгляда поверх изображения глаза.

    Стрелка начинается из центра изображения и направлена по вектору (gx, gy).
    Красная стрелка — предсказанное направление взгляда.

    Returns:
        PNG-изображение в байтах
    """
    # Увеличиваем картинку для наглядности
    img = Image.open(io.BytesIO(raw_bytes)).convert("RGB")
    img = img.resize((300, 180))
    draw = ImageDraw.Draw(img)

    cx, cy = img.width // 2, img.height // 2  # центр
    length = 100  # длина стрелки в пикселях

    # Переводим вектор взгляда в пиксельные координаты
    # gx: вправо положительный → dx вправо
    # gy: вниз положительный  → dy вниз
    ex = cx + int(gx * length)
    ey = cy + int(gy * length)

    # Рисуем линию и точку на конце
    draw.line([(cx, cy), (ex, ey)], fill=(255, 50, 50), width=3)
    draw.ellipse([cx-4, cy-4, cx+4, cy+4], fill=(255, 255, 0))  # начало — жёлтое
    draw.ellipse([ex-5, ey-5, ex+5, ey+5], fill=(255, 50, 50))  # конец — красное

    # Подпись
    draw.text((5, 5), f"gaze: ({gx:.3f}, {gy:.3f})", fill=(255, 255, 255))

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


# ──────────────────────────────────────────────
# FASTAPI APP
# ──────────────────────────────────────────────

app = FastAPI(
    title="Gaze Estimation API",
    description="API для оценки направления взгляда по изображению глаза и позе головы",
    version="1.0.0",
)


# ── Схемы ответов ──

class PredictResponse(BaseModel):
    """Результат распознавания взгляда."""
    gaze_x:  float  # горизонтальная компонента вектора взгляда
    gaze_y:  float  # вертикальная компонента вектора взгляда
    yaw_deg: float  # горизонтальный угол в градусах (влево/вправо)
    pitch_deg: float  # вертикальный угол в градусах (вверх/вниз)


# ── Эндпоинты ──

@app.get("/", summary="Статус сервиса")
def root():
    """Проверка работоспособности API."""
    return {"status": "ok", "device": DEVICE, "model": WEIGHTS_PATH}


@app.post(
    "/predict",
    response_model=PredictResponse,
    summary="Распознать направление взгляда",
    description="""
Принимает:
- **eye_image** — изображение глаза (JPG/PNG, любой размер — будет ресайзнут до 60×36)
- **pose_x, pose_y, pose_z** — поза головы (числа от -1 до 1)

Возвращает:
- **gaze_x, gaze_y** — компоненты вектора взгляда
- **yaw_deg, pitch_deg** — направление взгляда в градусах
""",
)
async def predict(
    eye_image: UploadFile = File(..., description="Изображение глаза (PNG/JPG)"),
    pose_x: float = Form(0.0, description="Поза головы X"),
    pose_y: float = Form(0.0, description="Поза головы Y"),
    pose_z: float = Form(0.0, description="Поза головы Z"),
):
    img_bytes  = await eye_image.read()
    img_tensor = preprocess_image(img_bytes)

    gx, gy = predict_gaze(img_tensor, [pose_x, pose_y, pose_z])
    yaw, pitch = gaze_to_angles(gx, gy)

    return PredictResponse(gaze_x=gx, gaze_y=gy, yaw_deg=yaw, pitch_deg=pitch)


@app.post(
    "/visualize",
    response_class=Response,
    summary="Визуализировать направление взгляда",
    description="""
Принимает те же параметры что и /predict.

Возвращает PNG-изображение: исходная картинка глаза + стрелка направления взгляда.

Красная стрелка указывает предсказанное направление взгляда.
Жёлтая точка — центр (начало вектора).
""",
)
async def visualize(
    eye_image: UploadFile = File(..., description="Изображение глаза (PNG/JPG)"),
    pose_x: float = Form(0.0, description="Поза головы X"),
    pose_y: float = Form(0.0, description="Поза головы Y"),
    pose_z: float = Form(0.0, description="Поза головы Z"),
):
    img_bytes  = await eye_image.read()
    img_tensor = preprocess_image(img_bytes)

    gx, gy = predict_gaze(img_tensor, [pose_x, pose_y, pose_z])

    png_bytes = draw_gaze_arrow(img_bytes, gx, gy)

    return Response(content=png_bytes, media_type="image/png")


# ──────────────────────────────────────────────
# ЗАПУСК
# ──────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api:app", host="0.0.0.0", port=8000, reload=False)
