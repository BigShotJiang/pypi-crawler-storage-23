# ============================================================================
# COMPREHENSIVE TECHNICAL CHEAT SHEET
# Competition Module: Gaze Estimation with MPIIGaze Dataset
# ============================================================================
# This document covers ALL evaluation criteria from the scoring rubric.
# It provides explanations, code snippets, sample conclusions, and tips
# for achieving maximum scores in every sub-criterion.
# ============================================================================

---

# TABLE OF CONTENTS

1. [Module A — Data Analysis & Preprocessing](#module-a--data-analysis--preprocessing)
   - 1.1 [Data Cleaning](#11-data-cleaning)
   - 1.2 [Correlation Matrix](#12-correlation-matrix)
   - 1.3 [Scatter Plots & Conclusions](#13-scatter-plots--conclusions)
   - 1.4 [Clustering & Conclusions](#14-clustering--conclusions)
   - 1.5 [Outlier Removal](#15-outlier-removal)
   - 1.6 [Conclusions About Data Impact on Model Training](#16-conclusions-about-data-impact-on-model-training)
2. [Module A — Determining Data Nature](#module-a--determining-data-nature)
   - 2.1 [Dataset Description](#21-dataset-description)
   - 2.2 [Data Processing Approach Description](#22-data-processing-approach-description)
   - 2.3 [Key Attributes](#23-key-attributes)
   - 2.4 [Distribution Identification (6 Features)](#24-distribution-identification-6-features)
3. [Module B — ML Model Development](#module-b--ml-model-development)
   - 3.1 [Data Import for Training](#31-data-import-for-training)
   - 3.2 [Architecture Selection & Justification](#32-architecture-selection--justification)
   - 3.3 [Model Implementation & Training](#33-model-implementation--training)
   - 3.4 [Optimization & Hyperparameter Tuning](#34-optimization--hyperparameter-tuning)
4. [Module B — API Development](#module-b--api-development)
   - 4.1 [Gaze Recognition Function](#41-gaze-recognition-function)
   - 4.2 [Gaze Visualization Function](#42-gaze-visualization-function)
   - 4.3 [Code Standards & Comments](#43-code-standards--comments)
5. [Module B — Interface Implementation](#module-b--interface-implementation)
6. [Module C — Testing](#module-c--testing)
   - 6.1 [Project Deployment](#61-project-deployment)
   - 6.2 [Unit Tests](#62-unit-tests)
7. [Report Writing Guide](#report-writing-guide)
8. [Universal Tips & Tricks](#universal-tips--tricks)

---

# MODULE A — DATA ANALYSIS & PREPROCESSING

## 1.1 Data Cleaning

**Criterion:** Dataset is cleaned correctly — handle empty values, non-standard fields,
duplicates, and irrelevant features.

### What To Do

```python
from numpy_dtype_utils import Dataset

dataset = Dataset("path/to/MPIIGaze/Data/Normalized")
dataset.load(max_participants=15, max_days=None)

# The clean() method handles everything:
dataset.clean(drop_metadata=True, remove_outliers=True, verbose=True)
```

### The 5 Cleaning Steps (in order)

| Step | What | Why | Method |
|------|------|-----|--------|
| 1 | Drop metadata columns (`participant`, `day`, `eye`) | Irrelevant for model training — categorical IDs add noise | `df.drop(columns=[...])` |
| 2 | Remove NaN rows | Missing sensor readings corrupt training | `df.dropna(subset=numeric_cols)` |
| 3 | Remove Inf values | Infinite values from division errors break gradients | `np.isinf()` mask |
| 4 | Remove outliers via IQR | Extreme values skew model weights | Q1 - 1.5*IQR to Q3 + 1.5*IQR |
| 5 | Remove duplicates | Redundant samples bias the model | `df.drop_duplicates()` |

### Sample Conclusion to Write

> "The dataset was cleaned in 5 stages. Metadata columns (participant, day, eye) were
> removed as they are categorical identifiers irrelevant for gaze angle regression.
> NaN and Inf values were removed (X records). Outliers were detected using the IQR
> method with a 1.5x multiplier, removing Y records (Z%). Duplicates accounted for
> W records. Final cleaned dataset: N records with 6 numeric features."

### Tips
- **Always print before/after counts** — judges want to see how much data was removed
- **Justify WHY each step** — e.g., "metadata removed because participant IDs would
  cause the model to memorize identity rather than learn gaze patterns"
- **IQR multiplier 1.5** is the standard; mention this explicitly


---

## 1.2 Correlation Matrix

**Criterion:** Correlation matrix is built AND clearly shows dependencies in data.

### How To Build

```python
corr = dataset.plot_correlation_matrix(
    figsize=(12, 10),
    cmap='coolwarm',   # Best colormap for showing positive/negative
    annot=True,        # MUST show numeric values
    save_path='correlation_matrix.png'
)
print(corr)
```

### What To Write In Conclusions

Look at the output matrix and describe:

| Correlation Value | Interpretation | Example |
|-------------------|----------------|---------|
| r > 0.7 | Strong positive | "gaze_x and head_pose_x show strong positive correlation (r=0.82), indicating head position directly influences horizontal gaze direction" |
| 0.3 < r < 0.7 | Moderate | "Moderate correlation between gaze_y and head_pose_y (r=0.45) suggests partial dependency" |
| -0.3 < r < 0.3 | Weak/None | "gaze_z and head_pose_x show negligible correlation (r=0.02), confirming independence" |
| r < -0.7 | Strong negative | "Strong inverse relationship detected..." |

### Sample Conclusion

> "The correlation matrix reveals that same-axis gaze and head_pose features correlate
> moderately to strongly (gaze_x↔head_pose_x: r≈0.8), confirming that head orientation
> is a significant predictor of gaze direction. Cross-axis correlations are weak (r<0.1),
> indicating axis independence. No multicollinearity issues detected between input features
> designated for the model. This supports using all 6 features without dimensionality
> reduction."

### Tips
- Use `annot=True` and `fmt='.3f'` — judges need to see exact values
- Use `coolwarm` or `RdBu_r` colormap — clearly distinguishes positive from negative
- Set `center=0` so the color scale is symmetric


---

## 1.3 Scatter Plots & Conclusions

**Criterion:** Scatter diagrams are built AND correct conclusions are drawn from them.

### How To Build

```python
dataset.plot_scatter_matrix(sample_size=10000, save_path='scatter_plots.png')
```

### What To Look For In Each Plot

| Pattern | What It Means | Sample Conclusion |
|---------|---------------|-------------------|
| Linear cloud (diagonal) | Linear relationship | "Clear linear trend between gaze_x and head_pose_x (r=0.82). A linear regression model could capture this relationship." |
| Circular/blob | No relationship | "No visible pattern between gaze_z and head_pose_x, confirming statistical independence." |
| Clusters/groups | Distinct sub-populations | "Two visible clusters in gaze_x vs gaze_y suggest left-eye and right-eye data may form distinct distributions." |
| Fan shape | Heteroscedasticity | "Variance increases with gaze_y magnitude, suggesting heteroscedastic behavior. Consider variance-stabilizing transforms." |
| Curved pattern | Non-linear relationship | "Non-linear relationship observed; polynomial or neural network models are preferred over linear regression." |

### Sample Conclusion

> "Scatter analysis of 6 feature pairs reveals:
> 1) gaze_x vs head_pose_x: strong linear positive trend (r=0.82), head position
>    directly predicts horizontal gaze.
> 2) gaze_y vs head_pose_y: moderate positive trend (r=0.45), vertical gaze is
>    partially explained by head tilt.
> 3) gaze_x vs gaze_y: elliptical distribution centered near origin, suggesting
>    uniform gaze coverage in the dataset.
> These findings confirm that head pose features are valuable predictors and should
> be included as model inputs alongside eye images."


---

## 1.4 Clustering & Conclusions

**Criterion:** Clustering is performed AND correct conclusions are drawn.

### How To Build

```python
result = dataset.cluster_gaze(n_clusters=3, save_path='gaze_clusters.png')
```

### What The Method Does
1. **KMeans clustering** on `gaze_x, gaze_y`
2. **Elbow method plot** to justify optimal K
3. Returns labels, centers, inertia

### What To Write

> "KMeans clustering with K=3 identified three distinct gaze regions:
> - Cluster 0 (center: -0.12, 0.05): left-looking gaze, N1 samples
> - Cluster 1 (center: 0.01, -0.03): center-looking gaze, N2 samples
> - Cluster 2 (center: 0.15, 0.08): right-looking gaze, N3 samples
>
> The elbow method plot shows diminishing returns after K=3, confirming 3 as optimal.
> The clustering reveals that gaze directions naturally form spatial groups, which could
> inform a classification approach or be used for stratified sampling during training."

### Tips
- **Always show the elbow plot** — it justifies your choice of K
- **Report cluster sizes** — imbalanced clusters suggest data bias
- **Connect to model training** — e.g., "stratified sampling ensures each gaze region
  is represented in train/test splits"


---

## 1.5 Outlier Removal

**Criterion:** Outliers are correctly removed.

### The IQR Method (already in `dataset.clean()`)

```python
Q1 = df[numeric_cols].quantile(0.25)
Q3 = df[numeric_cols].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
# Keep only data within bounds
mask = ~((df[numeric_cols] < lower_bound) | (df[numeric_cols] > upper_bound)).any(axis=1)
df_clean = df[mask]
```

### Sample Conclusion

> "Outliers were detected using the Interquartile Range (IQR) method with a standard
> multiplier of 1.5. For each of the 6 numeric features, data points falling below
> Q1-1.5×IQR or above Q3+1.5×IQR were flagged. A total of X outlier records were
> removed (Y% of data). The IQR method was chosen over Z-score because the data
> distributions are not strictly normal, making IQR more robust."


---

## 1.6 Conclusions About Data Impact on Model Training

**Criterion:** Present conclusions about how the data affects model training.

### Template Conclusion

> "**Data Impact Analysis:**
> 1. **Feature Relevance:** All 6 numeric features (gaze_x/y/z, head_pose_x/y/z) are
>    relevant for gaze estimation. Head pose features serve as contextual input.
> 2. **Data Volume:** After cleaning, N records remain — sufficient for training a CNN.
> 3. **Feature Correlations:** Moderate correlation between same-axis gaze/head_pose
>    confirms that head pose carries predictive signal without being redundant.
> 4. **Cluster Structure:** Three natural gaze clusters suggest the model must learn
>    to handle distinct gaze regions. Stratified splitting is recommended.
> 5. **Distribution Shape:** Near-normal distributions with slight skewness indicate
>    standardization (zero-mean, unit-variance) is appropriate for preprocessing.
> 6. **Outlier Impact:** Removing IQR outliers reduces noise that could destabilize
>    gradient descent, especially in early training epochs."


---

# MODULE A — DETERMINING DATA NATURE

## 2.1 Dataset Description

**Criterion:** Description of the final dataset is present.

### What To Include

```
Dataset: MPIIGaze (Normalized subset)
Source: Max Planck Institute for Informatics
Participants: 15 (p00–p14)
Total records after cleaning: ~200,000 (varies)
Features: 6 numeric
  - gaze_x, gaze_y, gaze_z: 3D gaze direction vector (normalized)
  - head_pose_x, head_pose_y, head_pose_z: 3D head rotation angles (radians)
Data types: All float64
Target variable: gaze_x, gaze_y (2D gaze angles for regression)
Input features for model: head_pose_x, head_pose_y, head_pose_z + eye images
Missing values: 0 (after cleaning)
Outliers: Removed via IQR method
```

## 2.2 Data Processing Approach Description

**Criterion (scored 0-3):** Description of the processing approach.

### For Maximum Score (3/3), Include:

1. **Why this approach** — "IQR was chosen over Z-score because..."
2. **Step-by-step pipeline** — cleaning → analysis → feature selection → normalization
3. **Tools used** — pandas, numpy, scipy, sklearn, matplotlib, seaborn
4. **Validation of each step** — "after removing NaN, we verified no remaining null values"
5. **Rationale for feature selection** — "metadata columns removed because..."

## 2.3 Key Attributes

**Criterion:** Main dataset attributes are identified.

List each feature with:

| Feature | Type | Range | Unit | Role |
|---------|------|-------|------|------|
| gaze_x | float64 | [-0.5, 0.5] | radians | Target (horizontal angle) |
| gaze_y | float64 | [-0.4, 0.3] | radians | Target (vertical angle) |
| gaze_z | float64 | [-1.0, -0.8] | normalized | Depth component |
| head_pose_x | float64 | [-0.3, 0.3] | radians | Input feature |
| head_pose_y | float64 | [-0.3, 0.3] | radians | Input feature |
| head_pose_z | float64 | [-0.2, 0.2] | radians | Input feature |


## 2.4 Distribution Identification (6 Features)

**Criterion:** Correctly identify the distribution of ALL 6 features.

### How To Determine Distribution Type

```python
dist_results = dataset.plot_distributions(save_path='distributions.png')
```

### Decision Logic

```
if shapiro_p > 0.05:
    → "Normal distribution"
elif |skewness| > 1:
    → "Skewed distribution" (right if skew > 0, left if skew < 0)
elif kurtosis > 1:
    → "Leptokurtic (heavy-tailed)"
elif kurtosis < -1:
    → "Platykurtic (light-tailed)"
else:
    → "Approximately normal" or fit other distributions
```

### Advanced: Fitting Multiple Distributions

```python
from scipy import stats

distributions = [stats.norm, stats.laplace, stats.t, stats.cauchy, stats.uniform]

for dist in distributions:
    params = dist.fit(data)
    ks_stat, ks_p = stats.kstest(data, dist.name, args=params)
    print(f"{dist.name}: KS={ks_stat:.4f}, p={ks_p:.4f}")
# Pick the distribution with the highest p-value (best fit)
```

### Sample Conclusion For Each Feature

> "**gaze_x:** Shapiro-Wilk test yields p<0.001, rejecting normality. Skewness=0.15
> (approximately symmetric), kurtosis=1.8 (leptokurtic — heavier tails than normal).
> Best fit: Laplace distribution (KS p=0.12). This heavy-tailed behavior means the
> model may encounter more extreme gaze angles than a normal distribution would predict."

### Common Distribution Types You Will Encounter

| Distribution | Key Indicators | Typical For |
|-------------|----------------|-------------|
| Normal | skew≈0, kurtosis≈0, Shapiro p>0.05 | Well-centered measurements |
| Laplace | skew≈0, kurtosis>0, sharp peak | Gaze angles (common in MPIIGaze) |
| Uniform | kurtosis≈-1.2, flat histogram | Evenly distributed features |
| Skew-normal | skew≠0, one tail longer | Head pose angles |
| Bimodal | Two visible peaks | Left/right eye mixed data |


---

# MODULE B — ML MODEL DEVELOPMENT

## 3.1 Data Import for Training

**Criterion:** Data + labels import fully and without errors.

```python
import torch
from torch.utils.data import Dataset as TorchDataset, DataLoader

class GazeDataset(TorchDataset):
    """PyTorch dataset for gaze estimation."""

    def __init__(self, eye_images, head_poses, gaze_labels):
        # eye_images: (N, 1, 36, 60) — grayscale normalized eye patches
        # head_poses: (N, 3) — head_pose_x, head_pose_y, head_pose_z
        # gaze_labels: (N, 2) — gaze_x, gaze_y (target angles)
        self.eye_images = torch.FloatTensor(eye_images)
        self.head_poses = torch.FloatTensor(head_poses)
        self.gaze_labels = torch.FloatTensor(gaze_labels)

    def __len__(self):
        return len(self.gaze_labels)

    def __getitem__(self, idx):
        return self.eye_images[idx], self.head_poses[idx], self.gaze_labels[idx]

# Usage
train_loader = DataLoader(train_dataset, batch_size=256, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=256, shuffle=False)
```

### Tips
- **Wrap in try/except** and print success message — proves "no errors during import"
- **Print shapes** after loading: `print(f"Images: {X.shape}, Labels: {y.shape}")`
- **Verify label completeness**: `assert not np.isnan(y).any()`


## 3.2 Architecture Selection & Justification

**Criterion:** Architecture justification is provided, objective, and well-supported.
Minus 75% if justification is not objective and correct!

### Recommended Architecture: CNN + Head Pose MLP

```
Input: Eye Image (1×36×60) ──→ CNN Branch ──→ FC(256)──┐
                                                        ├──→ FC(128) → FC(2) → (pitch, yaw)
Input: Head Pose (3) ─────────→ FC(64) ──→ FC(64) ──┘
```

### Justification Template (CRITICAL — write this carefully)

> "**Architecture: Multi-input CNN with Head Pose Fusion**
>
> **Why CNN for eye images:**
> - CNNs excel at spatial feature extraction from image data (LeCun et al., 1998)
> - Convolutional layers detect local features (iris edges, pupil position) that
>   are invariant to small translations
> - The 36×60 input size is small enough for a lightweight CNN (3-4 conv layers)
>
> **Why separate head pose branch:**
> - Head pose is a 3D vector, not spatial data — applying convolutions would be
>   inappropriate
> - A small MLP (2 fully connected layers) is sufficient to encode head rotation
> - Late fusion (concatenation before final FC layers) allows each modality to
>   develop independent representations before combining
>
> **Why NOT alternatives:**
> - Pure MLP on flattened images: loses spatial structure, requires too many parameters
> - Transformer: excessive for 36×60 images, requires more data than available
> - Random Forest/SVM: cannot process raw image pixels effectively
>
> **Parameter choices:**
> - Batch size 256: balances GPU memory utilization and gradient noise
> - Adam optimizer (lr=1e-4): adaptive learning rate handles varying gradient scales
> - Angular loss: directly optimizes the metric we care about (angle error in degrees)"


## 3.3 Model Implementation & Training

**Criterion:** Model is implemented per chosen architecture, trained successfully,
and passes 9/10 test cases. Minimal library stack (minus 0.5 per unnecessary library).

### Minimal Required Stack

```
torch          — model definition and training
numpy          — array operations
scipy          — .mat file loading
pandas         — data manipulation
matplotlib     — visualization
scikit-learn   — preprocessing (StandardScaler), metrics
```

**DO NOT include** libraries you don't actually use. Every `import` must be justified.

### Training Loop Template

```python
best_val_loss = float('inf')
for epoch in range(num_epochs):
    model.train()
    train_loss = 0
    for images, poses, labels in train_loader:
        optimizer.zero_grad()
        predictions = model(images.to(device), poses.to(device))
        loss = criterion(predictions, labels.to(device))
        loss.backward()
        optimizer.step()
        train_loss += loss.item()

    # Validation
    model.eval()
    val_loss = 0
    with torch.no_grad():
        for images, poses, labels in val_loader:
            predictions = model(images.to(device), poses.to(device))
            loss = criterion(predictions, labels.to(device))
            val_loss += loss.item()

    # Save best weights
    if val_loss < best_val_loss:
        best_val_loss = val_loss
        torch.save(model.state_dict(), 'best_model.pth')
        print(f"Epoch {epoch}: New best model saved (val_loss={val_loss:.4f})")
```

### Model Quality Visualization (scored 0-3)

For maximum score, show:
1. **Training vs Validation loss curves** (proves convergence, no overfitting)
2. **Predicted vs Actual scatter plot** (visual accuracy check)
3. **Error distribution histogram** (should be centered near 0)
4. **Sample predictions on test images** (qualitative assessment)


## 3.4 Optimization & Hyperparameter Tuning

**Criterion:** Comparison plots, hyperparameter search, weights saved to file.

### Training/Validation Comparison Plot

```python
plt.figure(figsize=(10, 5))
plt.plot(train_losses, label='Train Loss')
plt.plot(val_losses, label='Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.title('Training vs Validation Loss')
plt.savefig('training_curves.png', dpi=300)
```

### Hyperparameter Search

```python
# Grid search example
param_grid = {
    'learning_rate': [1e-3, 1e-4, 1e-5],
    'batch_size': [64, 128, 256],
    'dropout': [0.2, 0.3, 0.5]
}

results = []
for lr in param_grid['learning_rate']:
    for bs in param_grid['batch_size']:
        for dr in param_grid['dropout']:
            model = GazeCNN(dropout=dr)
            val_loss = train_and_evaluate(model, lr=lr, batch_size=bs)
            results.append({'lr': lr, 'bs': bs, 'dropout': dr, 'val_loss': val_loss})

best = min(results, key=lambda x: x['val_loss'])
print(f"Best params: lr={best['lr']}, bs={best['bs']}, dropout={best['dropout']}")
```

### Saving Weights

```python
# Save optimal weights
torch.save(model.state_dict(), 'best_gaze_model.pth')

# Load for inference
model.load_state_dict(torch.load('best_gaze_model.pth'))
model.eval()
```


---

# MODULE B — API DEVELOPMENT

## 4.1 Gaze Recognition Function

**Criterion:** Working gaze recognition function + documented (minus 0.75 for bad docs).

```python
def predict_gaze(eye_image: np.ndarray, head_pose: np.ndarray,
                 model_path: str = 'best_gaze_model.pth') -> dict:
    """
    Predict gaze direction from an eye image and head pose.

    This function loads the trained CNN model and performs inference
    to estimate the 2D gaze direction (pitch and yaw angles).

    Args:
        eye_image (np.ndarray): Grayscale eye image, shape (36, 60),
            normalized to [0, 1] range. Must be a single-channel image
            cropped and normalized according to MPIIGaze preprocessing.
        head_pose (np.ndarray): Head rotation vector, shape (3,),
            containing [rotation_x, rotation_y, rotation_z] in radians.
            Should be normalized using the fitted StandardScaler.
        model_path (str): Path to the saved model weights file (.pth).
            Default: 'best_gaze_model.pth'.

    Returns:
        dict: A dictionary containing:
            - 'pitch' (float): Vertical gaze angle in radians.
            - 'yaw' (float): Horizontal gaze angle in radians.
            - 'vector' (np.ndarray): 3D gaze direction unit vector.

    Raises:
        FileNotFoundError: If model_path does not exist.
        ValueError: If input shapes are incorrect.

    Example:
        >>> result = predict_gaze(eye_img, head_pose)
        >>> print(f"Pitch: {result['pitch']:.3f}, Yaw: {result['yaw']:.3f}")
    """
    # Implementation...
```

## 4.2 Gaze Visualization Function

```python
def visualize_gaze(image: np.ndarray, gaze_pitch: float, gaze_yaw: float,
                   eye_position: tuple = None, arrow_length: int = 100,
                   color: tuple = (0, 255, 0)) -> np.ndarray:
    """
    Draw a gaze direction arrow on a face/eye image.

    Converts predicted gaze angles (pitch, yaw) into a 2D arrow
    overlay on the input image, originating from the eye position.

    Args:
        image (np.ndarray): Input BGR image, shape (H, W, 3).
        gaze_pitch (float): Vertical gaze angle in radians (positive = up).
        gaze_yaw (float): Horizontal gaze angle in radians (positive = right).
        eye_position (tuple, optional): (x, y) pixel coordinates of the eye
            center. If None, uses image center. Default: None.
        arrow_length (int): Length of the gaze arrow in pixels. Default: 100.
        color (tuple): BGR color of the arrow. Default: green (0, 255, 0).

    Returns:
        np.ndarray: Image with gaze arrow drawn, same shape as input.

    Example:
        >>> result_img = visualize_gaze(frame, pitch=0.1, yaw=-0.2)
        >>> cv2.imshow('Gaze', result_img)
    """
    # Implementation using cv2.arrowedLine...
```

## 4.3 Code Standards & Comments

**Criterion (scored 0-3):** Code meets standards and is covered with comments.

### For Maximum Score (3/3):

1. **Every function** has a Google-style docstring (Args, Returns, Raises, Example)
2. **Every class** has a class-level docstring explaining purpose and attributes
3. **Inline comments** for non-obvious logic (aim for 75%+ coverage)
4. **Type hints** on all function signatures
5. **PEP 8** compliance (line length, naming conventions, spacing)

```python
# GOOD: Comment explains WHY, not WHAT
# Use IQR instead of Z-score because distributions are non-normal
outlier_mask = ~((df < lower) | (df > upper)).any(axis=1)

# BAD: Comment restates code
# Remove outliers
outlier_mask = ~((df < lower) | (df > upper)).any(axis=1)
```


---

# MODULE B — INTERFACE IMPLEMENTATION

**Criterion:** GUI is implemented and provides ALL expected functionality.
Minus 0.5 per missing feature.

### Expected Functionality Checklist

- [ ] Load/select eye image or camera input
- [ ] Display gaze prediction results (angles)
- [ ] Visualize gaze direction on image (arrow overlay)
- [ ] Real-time webcam mode (if applicable)
- [ ] Display model confidence/error metrics
- [ ] Settings/configuration panel

### Implementation Options

| Framework | Pros | Cons |
|-----------|------|------|
| **Tkinter** | Built-in, no extra deps | Basic look |
| **PyQt5** | Professional UI | Extra dependency |
| **Streamlit** | Fast to build, web-based | Requires browser |
| **Gradio** | ML-focused, easy | Limited customization |


---

# MODULE C — TESTING

## 6.1 Project Deployment

**Criterion:** Project deploys successfully per provided instructions.

### Create `README_DEPLOY.md`:

```markdown
## Prerequisites
- Python 3.8+
- pip

## Installation
1. Clone the repository
2. pip install -r requirements.txt
3. Download model weights: best_gaze_model.pth

## Running
python main.py
```

## 6.2 Unit Tests

**Criterion:** At least 4 unit tests, all pass, follow automation patterns, meet
industry standards. Minus 0.5 per missing test. Minus 0.25 per absent requirement.

### Minimum 4 Tests Structure

```python
import unittest
import numpy as np

class TestDataCleaning(unittest.TestCase):
    """Test 1: Data cleaning pipeline produces valid output."""

    def test_no_nan_after_clean(self):
        dataset = Dataset("test_data_path")
        dataset.load()
        dataset.clean()
        df = dataset.to_dataframe()
        self.assertFalse(df.isnull().any().any(),
                         "DataFrame should have no NaN after cleaning")

    def test_no_duplicates_after_clean(self):
        dataset = Dataset("test_data_path")
        dataset.load()
        dataset.clean()
        df = dataset.to_dataframe()
        self.assertEqual(df.duplicated().sum(), 0,
                         "DataFrame should have no duplicates after cleaning")


class TestModelPrediction(unittest.TestCase):
    """Test 2: Model produces valid predictions."""

    def test_output_shape(self):
        model = GazeCNN()
        model.load_state_dict(torch.load('best_gaze_model.pth'))
        dummy_img = torch.randn(1, 1, 36, 60)
        dummy_pose = torch.randn(1, 3)
        output = model(dummy_img, dummy_pose)
        self.assertEqual(output.shape, (1, 2),
                         "Model output should be (batch, 2) for pitch and yaw")

    def test_output_range(self):
        """Predictions should be within physically plausible range."""
        # Gaze angles typically in [-pi/2, pi/2]
        output = model(dummy_img, dummy_pose)
        self.assertTrue((output.abs() < np.pi/2).all(),
                        "Predictions should be within [-pi/2, pi/2]")


class TestAPIFunctions(unittest.TestCase):
    """Test 3: API functions work correctly."""

    def test_predict_gaze_returns_dict(self):
        result = predict_gaze(test_image, test_pose)
        self.assertIsInstance(result, dict)
        self.assertIn('pitch', result)
        self.assertIn('yaw', result)

    def test_visualize_returns_image(self):
        result = visualize_gaze(test_image, 0.1, -0.2)
        self.assertEqual(result.shape, test_image.shape)


class TestDataImport(unittest.TestCase):
    """Test 4: Data import works without errors."""

    def test_load_dataset(self):
        dataset = Dataset("path/to/data")
        dataset.load(max_participants=1, max_days=1)
        self.assertTrue(dataset.is_loaded)
        self.assertGreater(len(dataset), 0)

if __name__ == '__main__':
    unittest.main()
```

### Test Patterns Checklist
- [x] **AAA pattern**: Arrange → Act → Assert
- [x] **Descriptive names**: `test_no_nan_after_clean`, not `test1`
- [x] **Assertion messages**: Every assert has a human-readable message
- [x] **Independence**: Each test works standalone
- [x] **Edge cases**: Test empty input, wrong shapes, missing files


---

# REPORT WRITING GUIDE

**Criterion (scored 0-3 in EACH module):** Report is professional and covers the module.

### Report Structure For Maximum Score (3/3)

```
1. Introduction
   - Task description
   - Goals and objectives

2. Tools and Technologies
   - Python 3.x, PyTorch, NumPy, pandas, etc.
   - Justification for each tool

3. Data Analysis (Module A)
   - Dataset description
   - Cleaning steps and results
   - Correlation analysis with matrix screenshot
   - Scatter plot analysis with conclusions
   - Clustering with elbow plot and interpretation
   - Distribution analysis for all 6 features
   - Impact on model training

4. Model Development (Module B)
   - Architecture description and justification
   - Training procedure
   - Hyperparameter tuning results
   - Performance metrics and curves
   - API function descriptions

5. Testing (Module C)
   - Test scenarios
   - Test results
   - Deployment instructions

6. Conclusions
   - Summary of achieved results
   - Possible improvements

7. References
```

### Tips For Report
- **Include ALL screenshots** — correlation matrix, scatter plots, clusters,
  distributions, training curves, test results
- **Number your figures** — "Figure 1: Correlation matrix of MPIIGaze features"
- **Tables for numeric results** — easier to evaluate than inline text
- **Be specific** — "accuracy improved from 7.2° to 4.8° mean angular error"
  is better than "accuracy improved significantly"


---

# UNIVERSAL TIPS & TRICKS

## How To Survive When You Don't Know What To Write

| Situation | What To Do |
|-----------|------------|
| Don't know the distribution type | Run Shapiro-Wilk test. If p<0.05, it's NOT normal. Then check skewness: >1 = skewed right, <-1 = skewed left. Otherwise say "approximately normal with leptokurtic tendency" |
| Correlation is weak everywhere | Write: "Low inter-feature correlations indicate that each feature captures independent information, reducing multicollinearity risk and supporting the use of all features in the model." |
| Clustering looks bad | Use a different K. Show the elbow plot and pick the K at the "bend." Write: "While clusters are not sharply separated, this is expected for continuous gaze data. The clustering reveals general directional tendencies." |
| Model accuracy is low | Report honestly, then add: "Further improvements could include: deeper architecture, data augmentation, learning rate scheduling, or ensemble methods." |
| Don't know which distribution | Fit multiple with scipy.stats. The one with highest KS p-value wins. If nothing fits well: "The distribution does not conform to standard parametric families; a kernel density estimate (KDE) provides the best empirical fit." |

## File Checklist

Make sure ALL these files exist (minus 0.3-0.5 per missing file):

- [ ] Source code files (model, dataset, API)
- [ ] Trained model weights (.pth file)
- [ ] Requirements file (requirements.txt or setup.py)
- [ ] README / deployment instructions
- [ ] Report document
- [ ] Test files
- [ ] Saved plots/figures

## Golden Rules

1. **Always print counts** — before/after cleaning, train/val split sizes, etc.
2. **Always save plots** — use `save_path` parameter, judges may not run your code
3. **Always justify decisions** — "IQR was chosen because..." not just "we used IQR"
4. **Comment your code** — 75%+ coverage for max score
5. **Keep imports minimal** — every unused library costs 0.5 points
6. **Save model weights** — `torch.save(model.state_dict(), 'best_model.pth')`
7. **Write docstrings** — Google-style, with Args/Returns/Raises/Example
8. **Test everything** — at least 4 tests, AAA pattern, descriptive names
9. **Use `verbose=True`** — visible progress output proves your code works
10. **Screenshots in report** — every plot, every metric, every result

---
# END OF CHEAT SHEET
