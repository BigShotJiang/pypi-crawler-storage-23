"""
Модульные тесты для оценки качества CNN-модели оценки направления взгляда.

4 тестовых сценария:
    1. test_model_loads          — модель загружается без ошибок
    2. test_output_shape         — выход модели (gaze_x, gaze_y)
    3. test_angular_error        — средняя угловая ошибка < 15°
    4. test_prediction_range     — предсказания в допустимом диапазоне

Запуск:
    pytest tests/test_model.py -v
"""

import os
import sys
import numpy as np
import torch
import pytest
from scipy.io import loadmat

# Путь к корню проекта
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from numpy_dtype_utils.ml.moduletwo import GazeCNN


# ── Фикстуры ──

WEIGHTS_PATH = os.path.join(ROOT, "best_gaze_cnn.pth")
DATA_PATH    = os.path.join(ROOT, "dunno/data/MPIIGaze/Data/Normalized")
DEVICE       = "cuda" if torch.cuda.is_available() else "cpu"


@pytest.fixture(scope="module")
def model():
    """Загружает обученную модель один раз для всех тестов."""
    m = GazeCNN().to(DEVICE)
    m.load_state_dict(torch.load(WEIGHTS_PATH, map_location=DEVICE, weights_only=True))
    m.eval()
    return m


@pytest.fixture(scope="module")
def test_batch():
    """
    Загружает небольшой батч реальных данных из датасета (100 сэмплов)
    для проверки качества модели.
    """
    mat = loadmat(os.path.join(DATA_PATH, "p00", "day01.mat"))
    data = mat["data"]

    imgs  = data["right"][0, 0]["image"][0, 0][:100].astype(np.float32) / 255.0
    poses = data["right"][0, 0]["pose"][0, 0][:100].astype(np.float32)
    gazes = data["right"][0, 0]["gaze"][0, 0][:100, :2].astype(np.float32)

    t_img  = torch.tensor(imgs).unsqueeze(1).to(DEVICE)   # (100, 1, 36, 60)
    t_pose = torch.tensor(poses).to(DEVICE)                # (100, 3)
    t_gaze = torch.tensor(gazes).to(DEVICE)                # (100, 2)

    return t_img, t_pose, t_gaze


# ── Тесты ──

def test_model_loads(model):
    """
    Тест 1: Модель загружается без ошибок.

    Проверяет:
        - файл весов существует
        - state_dict загружается в архитектуру GazeCNN
        - модель в режиме eval (inference)
        - количество параметров > 0
    """
    assert os.path.exists(WEIGHTS_PATH), f"Файл весов не найден: {WEIGHTS_PATH}"
    assert not model.training, "Модель должна быть в eval() режиме"

    n_params = sum(p.numel() for p in model.parameters())
    assert n_params > 0, "У модели 0 параметров"
    print(f"  Параметров: {n_params:,}")


def test_output_shape(model, test_batch):
    """
    Тест 2: Выход модели имеет правильную форму (N, 2).

    Проверяет:
        - при входе батча (N, 1, 36, 60) + (N, 3)
          модель возвращает тензор (N, 2)
        - выход содержит конечные числа (нет NaN, Inf)
    """
    t_img, t_pose, _ = test_batch

    with torch.no_grad():
        output = model(t_img, t_pose)

    assert output.shape == (100, 2), f"Ожидалось (100, 2), получено {output.shape}"
    assert torch.isfinite(output).all(), "Выход содержит NaN или Inf"
    print(f"  Shape: {output.shape}, all finite: True")


def test_angular_error(model, test_batch):
    """
    Тест 3: Средняя угловая ошибка модели < 15°.

    Методика:
        - берём 100 реальных сэмплов из p00/day01
        - сравниваем предсказания с ground-truth
        - считаем угловую ошибку через arccos(cos_similarity)
        - проверяем что mean angular error < 15°

    Порог 15° выбран как разумный для CNN на MPIIGaze
    (SOTA модели достигают ~5°, наша ~7.6°).
    """
    t_img, t_pose, t_gaze = test_batch

    with torch.no_grad():
        pred = model(t_img, t_pose).cpu().numpy()
    actual = t_gaze.cpu().numpy()

    # Cosine similarity → angular error
    pred_n   = pred   / (np.linalg.norm(pred,   axis=1, keepdims=True) + 1e-8)
    actual_n = actual / (np.linalg.norm(actual, axis=1, keepdims=True) + 1e-8)
    cos_sim  = np.clip((pred_n * actual_n).sum(axis=1), -1.0, 1.0)
    ang_err  = np.degrees(np.arccos(cos_sim))

    mean_err = float(ang_err.mean())
    print(f"  Mean Angular Error: {mean_err:.2f}°")

    assert mean_err < 15.0, f"Ошибка {mean_err:.2f}° превышает порог 15°"


def test_prediction_range(model, test_batch):
    """
    Тест 4: Предсказания находятся в допустимом диапазоне.

    В датасете MPIIGaze значения gaze_x и gaze_y лежат примерно
    в диапазоне [-0.6, 0.6]. Модель не должна выдавать значения
    за пределами [-1.0, 1.0] — иначе это ошибка.

    Проверяет:
        - |gaze_x| < 1.0 для всех предсказаний
        - |gaze_y| < 1.0 для всех предсказаний
    """
    t_img, t_pose, _ = test_batch

    with torch.no_grad():
        pred = model(t_img, t_pose).cpu().numpy()

    gx_range = (pred[:, 0].min(), pred[:, 0].max())
    gy_range = (pred[:, 1].min(), pred[:, 1].max())
    print(f"  gaze_x range: [{gx_range[0]:.4f}, {gx_range[1]:.4f}]")
    print(f"  gaze_y range: [{gy_range[0]:.4f}, {gy_range[1]:.4f}]")

    assert np.all(np.abs(pred[:, 0]) < 1.0), f"gaze_x вне диапазона: {gx_range}"
    assert np.all(np.abs(pred[:, 1]) < 1.0), f"gaze_y вне диапазона: {gy_range}"
