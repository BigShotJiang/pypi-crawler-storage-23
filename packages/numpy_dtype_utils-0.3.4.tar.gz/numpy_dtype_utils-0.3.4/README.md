# numpy-dtype-utils

Advanced data type handling and dataset utilities for NumPy.

## Features

- **Efficient Data Loading**: Optimized loading for structured datasets.
- **DType Inspection**: utilities to analyze numpy dtypes (inspect.py).
- **Safe Type Casting**: Robust type conversion and promotion helpers (cast.py).
- **Data Cleaning Pipelines**: Streamlined handling of missing values, outliers, and duplicates.
- **Visualization Tools**: Integrated plotting for correlation matrices and distributions.
- **Clustering Support**: K-means clustering for spatial data analysis.

## Installation

```bash
pip install numpy-dtype-utils
```

## Usage

```python
from numpy_dtype_utils import Dataset, get_dtype_info, safe_cast
import numpy as np

# --- Dataset Utility ---
# Initialize dataset loader
dataset = Dataset("/path/to/data")

# Load and clean data
dataset.load(max_days=5).clean(remove_outliers=True)

# Visualize distributions
dataset.plot_distributions()

# --- Type Inspection ---
dt_info = get_dtype_info('float32')
print(dt_info)  # {'name': 'float32', 'itemsize': 4, ...}

# --- Safe Casting ---
arr = np.array([1, 2, 3], dtype='int32')
casted = safe_cast(arr, 'float64')
```

## License

MIT
