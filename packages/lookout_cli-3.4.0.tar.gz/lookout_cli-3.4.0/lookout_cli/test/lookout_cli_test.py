def test_lookout_cli():
    # TODO: Add tests
    assert True is True
