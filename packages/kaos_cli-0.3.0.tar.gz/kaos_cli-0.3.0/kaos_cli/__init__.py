"""KAOS CLI - CLI for K8s Agent Orchestration System."""

__version__ = "0.1.0"
