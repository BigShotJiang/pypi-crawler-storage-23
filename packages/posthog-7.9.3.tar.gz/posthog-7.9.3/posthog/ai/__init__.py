from posthog.ai.prompts import Prompts

__all__ = ["Prompts"]
