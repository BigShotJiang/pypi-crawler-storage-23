====================================================================================================================
 passagemath: Convex polyhedra in arbitrary dimension, mixed integer linear optimization
====================================================================================================================

`passagemath <https://github.com/passagemath/passagemath>`__ is open
source mathematical software in Python, released under the GNU General
Public Licence GPLv2+.

It is a fork of `SageMath <https://www.sagemath.org/>`__, which has been
developed 2005-2026 under the motto “Creating a Viable Open Source
Alternative to Magma, Maple, Mathematica, and MATLAB”.

The passagemath fork uses the motto "Creating a Free Passage Between the
Scientific Python Ecosystem and Mathematical Software Communities."
It was created in October 2024 with the following goals:

-  providing modularized installation with pip from binary wheels,
   - this major project was started in May 2020 in the Sage codebase and completed in passagemath 10.5.29 (May 2025),

-  establishing first-class membership in the scientific Python
   ecosystem,

-  giving `clear attribution of upstream
   projects <https://groups.google.com/g/sage-devel/c/6HO1HEtL1Fs/m/G002rPGpAAAJ>`__,

-  providing independently usable Python interfaces to upstream
   libraries,

-  offering `platform portability and integration testing
   services <https://github.com/passagemath/passagemath/issues/704>`__
   to upstream projects,

-  inviting collaborations with upstream projects,

-  `building a professional, respectful, inclusive
   community <https://groups.google.com/g/sage-devel/c/xBzaINHWwUQ>`__,

-  `empowering Sage users to participate in the scientific Python ecosystem
   <https://github.com/passagemath/passagemath/issues/248>`__ by publishing packages,

-  developing a port to WebAssembly (`Pyodide <https://pyodide.org/en/stable/>`__, emscripten-forge) for
   serverless deployment with Javascript,

-  developing a native Windows port
   - passagemath 10.6.1 (July 2025) published the first pip-installable wheel packages for native Windows on x86_64,
   - passagemath packages became available in the [MSYS2 software distribution](https://packages.msys2.org/search?t=pkg&q=passagemath) in November 2025.

Moreover, the passagemath project:

-  provides a stable, frequently updated version of the Sage distribution,
-  integrates additional mathematical software, notably Macaulay2, a full set of GAP packages,
   and the Combinatorial Matrix Recognition library,
-  curates a library of Sage user packages.

`Full documentation <https://passagemath.org/docs/latest/html/en/index.html>`__ is
available online.

passagemath attempts to support and provides binary wheels suitable for
all major Linux distributions and recent versions of macOS.

Binary wheels for native Windows (x86_64, ARM) are are available for a subset of
the passagemath distributions. Use of the full functionality of passagemath
on Windows currently requires the use of Windows Subsystem for Linux (WSL)
or virtualization.

The supported Python versions in the passagemath-10.8.x series are 3.11.x-3.14.x;
the passagemath-10.6.x series (EOL 2026-10) still supports Python 3.10.x.


About this pip-installable distribution package
-----------------------------------------------

This pip-installable distribution ``passagemath-polyhedra`` is a distribution of a part of the Sage Library.  It provides a small subset of the modules of the Sage library ("sagelib", `passagemath-standard`), sufficient for computations with convex polyhedra in arbitrary dimension (in exact rational arithmetic), and linear and mixed integer linear optimization (in floating point arithmetic).


What is included
----------------

* `Combinatorial and Discrete Geometry <https://passagemath.org/docs/latest/html/en/reference/discrete_geometry/index.html>`_: Polyhedra, lattice polyhedra, lattice points in polyhedra, triangulations, fans, polyhedral complexes, hyperplane arrrangements

* `Parma Polyhedra Library (PPL) backends for rational polyhedra <https://passagemath.org/docs/latest/html/en/reference/discrete_geometry/sage/geometry/polyhedron/backend_ppl.html>`_, `lattice polygons <https://passagemath.org/docs/latest/html/en/reference/discrete_geometry/sage/geometry/polyhedron/ppl_lattice_polygon.html>`_, `lattice polytopes <https://passagemath.org/docs/latest/html/en/reference/discrete_geometry/sage/geometry/polyhedron/ppl_lattice_polytope.html>`_; via `pplpy <https://passagemath.org/docs/latest/html/en/reference/spkg/pplpy.html#spkg-pplpy>`_

* `Python backend for polyhedra over general ordered fields <https://passagemath.org/docs/latest/html/en/reference/discrete_geometry/sage/geometry/polyhedron/backend_field.html>`_

* `Linear, Mixed Integer Linear, and Semidefinite Optimization frontends <https://passagemath.org/docs/latest/html/en/reference/numerical/index.html#numerical-optimization>`_

* `GNU Linear Programming Kit (GLPK) backend for large-scale linear and mixed integer linear optimization (floating point arithmetic) <https://passagemath.org/docs/latest/html/en/reference/numerical/sage/numerical/backends/glpk_backend.html>`_

* `Interactive Simplex Method <https://passagemath.org/docs/latest/html/en/reference/numerical/sage/numerical/interactive_simplex_method.html>`_

* see https://github.com/passagemath/passagemath/blob/main/pkgs/sagemath-polyhedra/MANIFEST.in


Examples
--------

A quick way to try it out interactively::

    $ pipx run --pip-args="--prefer-binary" --spec "passagemath-polyhedra[test]" ipython

    In [1]: from passagemath_polyhedra import *

    In [2]: P = Polyhedron(ieqs=[[0, 1, 0, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0, 0], [0, 0, 0, 1, 0, 0, 0], [0, 0, 0, 0, 1, 0, 0], [0, 0, 0, 0, 0, 1, 0], [0, 0, 0, 0, 0, 0, 1], [0, 0, 1, -1, -1, 1, 0], [0, 0, -1, 1, -1, 1, 0]], eqns=[[-31, 1, 1, 1, 1, 1, 1]]); P
    Out[2]: A 5-dimensional polyhedron in QQ^6 defined as the convex hull of 7 vertices

    In [3]: P.Vrepresentation()
    Out[4]:
    (A vertex at (31, 0, 0, 0, 0, 0),
     A vertex at (0, 0, 0, 0, 0, 31),
     A vertex at (0, 0, 0, 0, 31, 0),
     A vertex at (0, 0, 31/2, 0, 31/2, 0),
     A vertex at (0, 31/2, 31/2, 0, 0, 0),
     A vertex at (0, 31/2, 0, 0, 31/2, 0),
     A vertex at (0, 0, 0, 31/2, 31/2, 0))


Available as extras, from other distributions
---------------------------------------------

Additional features
~~~~~~~~~~~~~~~~~~~

``pip install "passagemath-polyhedra[graphs]"``
 Face lattices, combinatorial polyhedra, graph-theoretic constructions

 ::

    $ pipx run --pip-args="--prefer-binary" --spec "passagemath-polyhedra[graphs,test]" ipython

    In [1]: from passagemath_polyhedra import *

    In [2]: c5_10 = Polyhedron(vertices = [[i, i**2, i**3, i**4, i**5] for i in range(1, 11)]); c5_10
    Out[2]: A 5-dimensional polyhedron in ZZ^5 defined as the convex hull of 10 vertices

    In [3]: c5_10_fl = c5_10.face_lattice(); [len(x) for x in c5_10_fl.level_sets()]
    Out[3]: [1, 10, 45, 100, 105, 42, 1]

``pip install "passagemath-polyhedra[graphs,groups]"``
 Constructing symmetric polyhedra, computing automorphisms, lattice point counting modulo group actions

 ::

    $ pipx run --pip-args="--prefer-binary" --spec "passagemath-polyhedra[graphs,groups,test]" ipython

    In [1]: from passagemath_polyhedra import *

    In [2]: P24 = polytopes.twenty_four_cell(); P24
    Out[2]: A 4-dimensional polyhedron in QQ^4 defined as the convex hull of 24 vertices

    In [3]: AutP24 = P24.restricted_automorphism_group(); AutP24.order()
    Out[3]: 1152

``pip install "passagemath-polyhedra[toric]"``
 `Toric varieties <https://passagemath.org/docs/latest/html/en/reference/schemes/index.html#toric-varieties>`_

 ::

    $ pipx run --pip-args="--prefer-binary" --spec "passagemath-polyhedra[graphs,toric,test]" ipython

    In [1]: from passagemath_polyhedra import *

    In [2]: TV3 = ToricVariety(NormalFan(lattice_polytope.cross_polytope(3))); TV3
    Out[2]: 3-d toric variety covered by 6 affine patches

    In [3]: TV3.is_orbifold()
    Out[3]: False

``pip install "passagemath-polyhedra[latte]"``
 Installs `LattE integrale <https://passagemath.org/docs/latest/html/en/reference/spkg/latte_int.html#spkg-latte-int>`_
 for lattice point counting and volume computation using generating function techniques.

 ::

   $ pipx run --pip-args="--prefer-binary" --spec "passagemath-polyhedra[latte,test]" ipython

   In [1]: from passagemath_polyhedra import *

   In [2]: P = polytopes.cube()

   In [3]: P.integral_points_count()
   Out[3]:
   27

   In [4]: (1000000000*P).integral_points_count(verbose=True)
   This is LattE integrale...
   ...
   Total time:...
   Out[4]:
   8000000012000000006000000001


Additional backends for polyhedral computations
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

``pip install "passagemath-polyhedra[normaliz]"``
 `Normaliz <https://passagemath.org/docs/latest/html/en/reference/spkg/normaliz.html#spkg-normaliz>`_, via `PyNormaliz <https://passagemath.org/docs/latest/html/en/reference/spkg/pynormaliz.html#spkg-pynormaliz>`_,
 provides very fast computations in particular for polyhedra with data in algebraic number fields.

 ::

    $ pipx run --pip-args="--prefer-binary" --spec "passagemath-polyhedra[normaliz,test]" ipython

    In [1]: from passagemath_polyhedra import *

    In [2]: gap_norm = polytopes.grand_antiprism(backend='normaliz'); gap_norm

    In [3]: gap_norm.f_vector()

``pip install "passagemath-polyhedra[cddlib]"``
 cddlib provides support for computations with polyhedra in floating-point arithmetic.

 ::

    $ pipx run --pip-args="--prefer-binary" --spec "passagemath-polyhedra[cddlib,test]" ipython

    In [1]: from passagemath_polyhedra import *

    In [2]: P1 = polytopes.regular_polygon(5, exact=False); P1
    Out[2]: A 2-dimensional polyhedron in RDF^2 defined as the convex hull of 5 vertices

``pip install "passagemath-polyhedra[lrslib]"``
 `lrslib <https://passagemath.org/docs/latest/html/en/reference/spkg/lrslib.html#spkg-lrslib>`_
 can be used for polytope volume computations and for enumerating Nash equilibria.

 ::

    $ pipx run --pip-args="--prefer-binary" --spec "passagemath-polyhedra[flint,lrslib,test]" ipython

    In [1]: from passagemath_polyhedra import *

    In [2]: A = matrix([[2, 1], [1, 5/2]]); B = matrix([[-1, 3], [2, 1]])

    In [3]: g = NormalFormGame([A, B]); g.obtain_nash(algorithm='lrs')
    Out[3]: [[(1/5, 4/5), (3/5, 2/5)]]

``pip install "passagemath-polyhedra[polymake]"``
 `Polymake <https://passagemath.org/docs/latest/html/en/reference/spkg/polymake.html#spkg-polymake>`_, via passagemath-polymake


Optional backends for optimization
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

``pip install "passagemath-polyhedra[cbc]"``
 `COIN/OR CBC <https://passagemath.org/docs/latest/html/en/reference/spkg/cbc.html#spkg-cbc>`_ Mixed Integer Linear Optimization solver,
 via `passagemath-coin-or-cbc <https://passagemath.org/docs/latest/html/en/reference/spkg/sage_numerical_backends_coin.html#spkg-sage-numerical-backends-coin>`_

``pip install "passagemath-polyhedra[cplex]"``
 CPLEX Mixed Integer Optimization solver (proprietary; requires licensed installation),
 via `passagemath-cplex <https://passagemath.org/docs/latest/html/en/reference/spkg/sage_numerical_backends_cplex.html#spkg-sage-numerical-backends-cplex>`_

``pip install "passagemath-polyhedra[cvxpy]"``
 `CVXPy <https://passagemath.org/docs/latest/html/en/reference/spkg/cvxpy.html#spkg-cvxpy>`_ as middle-end for `various backends <https://www.cvxpy.org/install/>`_

``pip install "passagemath-polyhedra[gurobi]"``
 Gurobi Mixed Integer Optimization solver (proprietary; requires licensed installation), via `passagemath-gurobi <https://passagemath.org/docs/latest/html/en/reference/spkg/sage_numerical_backends_gurobi.html#spkg-sage-numerical-backends-gurobi>`_

``pip install "passagemath-polyhedra[highs]"``
 HiGHS

``pip install "passagemath-polyhedra[scip]"``
 `SCIP <https://passagemath.org/docs/latest/html/en/reference/spkg/scip.html#spkg-scip>`_ Mixed Integer Optimization solver,
 via `PySCIPOpt <https://passagemath.org/docs/latest/html/en/reference/spkg/pyscipopt.html#spkg-pyscipopt>`_


Development
-----------

::

    $ git clone --origin passagemath https://github.com/passagemath/passagemath.git
    $ cd passagemath
    passagemath $ ./bootstrap
    passagemath $ python3 -m venv polyhedra-venv
    passagemath $ source polyhedra-venv/bin/activate
    (polyhedra-venv) passagemath $ pip install -v -e pkgs/sagemath-polyhedra
