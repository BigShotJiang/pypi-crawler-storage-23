"""
NEPSE CLI - Stock Market & IPO Automation Tool

A command-line tool for:
- Viewing NEPSE market data (indices, stocks, IPOs)
- Automating Meroshare IPO applications
- Managing family member credentials
- Portfolio tracking

Usage:
    python main.py   # Start interactive CLI
    nepse            # If installed via pip
    nepse portfolio  # Direct command (no interactive mode)

Author: NEPSE CLI Team
"""

import sys
import shlex
from prompt_toolkit.patch_stdout import patch_stdout
from prompt_toolkit.formatted_text import FormattedText

# Import utilities
from nepse.utils.browser import ensure_playwright_browsers

# Import core functionality
from nepse.core.auth import test_login_for_member
from nepse.core.portfolio import get_portfolio_for_member
from nepse.core.ipo import (
    apply_ipo, 
    apply_ipo_for_all_members,
    apply_ipo_fast,
    apply_ipo_for_all_members_fast
)
from nepse.core.ipo_result import cmd_check_result

# Import services
from nepse.services.market import (
    cmd_ipo,
    cmd_nepse,
    cmd_subidx,
    cmd_mktsum,
    cmd_topgl,
    cmd_stonk,
    get_dp_list,
    # New commands
    cmd_52week,
    cmd_near52,
    cmd_holidays,
    cmd_floor,
    cmd_brokers,
    cmd_signals,
    cmd_announce,
    cmd_profile,
    cmd_fundamental,
    cmd_depth,
    cmd_sectors,
    cmd_bsum
)

# Import UI components
from nepse.ui.console import print_logo
from nepse.ui.member_ui import (
    add_family_member,
    list_family_members,
    edit_family_member,
    delete_family_member,
    manage_family_members,
    select_family_member
)
from nepse.ui.cli import (
    get_command_metadata,
    create_prompt_session,
    execute_interactive_command,
    display_command_palette,
    COMMAND_CATEGORY_ORDER,
    LEGACY_SHORTCUTS
)


def execute_direct_command(args):
    """Execute a command directly without interactive mode."""
    import shlex
    
    # Ensure Playwright browsers are available
    ensure_playwright_browsers()
    
    # Get command metadata
    command_metadata = get_command_metadata()
    
    # Build execution context (same as interactive mode)
    context = {
        # IPO functions
        'apply_ipo': apply_ipo,
        'apply_all': apply_ipo_for_all_members,
        'apply_ipo_fast': apply_ipo_fast,
        'apply_all_fast': apply_ipo_for_all_members_fast,
        'cmd_result': cmd_check_result,
        
        # Member management
        'add_member': add_family_member,
        'list_members': list_family_members,
        'edit_member': edit_family_member,
        'delete_member': delete_family_member,
        'manage_members': manage_family_members,
        'select_member': select_family_member,
        
        # Core operations
        'portfolio': get_portfolio_for_member,
        'login': test_login_for_member,
        'dp_list': get_dp_list,
        
        # Market Data
        'cmd_ipo': cmd_ipo,
        'cmd_nepse': cmd_nepse,
        'cmd_subidx': cmd_subidx,
        'cmd_mktsum': cmd_mktsum,
        'cmd_topgl': cmd_topgl,
        'cmd_stonk': cmd_stonk,
        
        # New Market Data
        'cmd_52week': cmd_52week,
        'cmd_near52': cmd_near52,
        'cmd_holidays': cmd_holidays,
        'cmd_floor': cmd_floor,
        
        # Trading Info
        'cmd_brokers': cmd_brokers,
        'cmd_signals': cmd_signals,
        'cmd_announce': cmd_announce,
        'cmd_sectors': cmd_sectors,
        'cmd_bsum': cmd_bsum,
        
        # Stock Analysis
        'cmd_profile': cmd_profile,
        'cmd_fundamental': cmd_fundamental,
        'cmd_depth': cmd_depth,
        'metadata': command_metadata,
        'category_order': COMMAND_CATEGORY_ORDER
    }
    
    # Parse command and arguments
    command = args[0]
    cmd_args = args[1:] if len(args) > 1 else []
    
    # Execute command
    try:
        handled = execute_interactive_command(command, cmd_args, context)
        if not handled:
            print(f"Unknown command: {command}")
            print("\nAvailable commands:")
            print("  portfolio [--member NAME]  - View portfolio")
            print("  ipo [list]                 - View IPO data")
            print("  nepse                      - NEPSE index")
            print("  stonk SYMBOL               - Stock info")
            print("  members                    - List members")
            print("  help                       - Show all commands")
            print("\nOr run 'nepse' with no args for interactive mode")
            sys.exit(1)
    except Exception as e:
        print(f"Error executing command: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


def main():
    """Main entry point for the NEPSE CLI."""
    # Ensure Playwright browsers are available
    ensure_playwright_browsers()
    
    # Get command metadata and create session
    command_metadata = get_command_metadata()
    session = create_prompt_session(command_metadata)

    # Print logo before entering patch_stdout context
    print_logo()
    print("\nType '/' to search commands, 'help' for hints, and 'exit' to quit.\n")

    # Build execution context with all function references
    context = {
        # IPO functions
        'apply_ipo': apply_ipo,
        'apply_all': apply_ipo_for_all_members,
        'apply_ipo_fast': apply_ipo_fast,
        'apply_all_fast': apply_ipo_for_all_members_fast,
        'cmd_result': cmd_check_result,
        
        # Member management
        'add_member': add_family_member,
        'list_members': list_family_members,
        'edit_member': edit_family_member,
        'delete_member': delete_family_member,
        'manage_members': manage_family_members,
        'select_member': select_family_member,
        
        # Core operations
        'portfolio': get_portfolio_for_member,
        'login': test_login_for_member,
        'dp_list': get_dp_list,
        
        # Market Data
        'cmd_ipo': cmd_ipo,
        'cmd_nepse': cmd_nepse,
        'cmd_subidx': cmd_subidx,
        'cmd_mktsum': cmd_mktsum,
        'cmd_topgl': cmd_topgl,
        'cmd_stonk': cmd_stonk,
        
        # New Market Data
        'cmd_52week': cmd_52week,
        'cmd_near52': cmd_near52,
        'cmd_holidays': cmd_holidays,
        'cmd_floor': cmd_floor,
        
        # Trading Info
        'cmd_brokers': cmd_brokers,
        'cmd_signals': cmd_signals,
        'cmd_announce': cmd_announce,
        'cmd_sectors': cmd_sectors,
        'cmd_bsum': cmd_bsum,
        
        # Stock Analysis
        'cmd_profile': cmd_profile,
        'cmd_fundamental': cmd_fundamental,
        'cmd_depth': cmd_depth,
        'metadata': command_metadata,
        'category_order': COMMAND_CATEGORY_ORDER
    }

    # Start REPL loop
    while True:
        try:
            # Patch stdout ONLY while prompting, so Rich output renders normally.
            with patch_stdout():
                text = session.prompt("> ")

            # Handle empty input
            if not text.strip():
                continue

            # Parse command and arguments using shlex for proper quoting
            try:
                parts = shlex.split(text)
            except ValueError:
                print("Error parsing command. Mismatched quotes?")
                continue

            command = parts[0]
            args = parts[1:]

            # Check for exit commands before executing
            if command.lower() in {"exit", "quit"}:
                break

            # Execute command (do NOT run under patch_stdout)
            handled = execute_interactive_command(command, args, context)
            if not handled:
                print(f"Unknown command: {command}")
                # Hints
                if command in LEGACY_SHORTCUTS:
                    print(f"Did you mean '{LEGACY_SHORTCUTS[command]}'?")

        except KeyboardInterrupt:
            continue
        except EOFError:
            break
        except Exception as e:
            print(f"An error occurred: {e}")
            import traceback
            traceback.print_exc()

    print("Goodbye!")


if __name__ == "__main__":
    main()
