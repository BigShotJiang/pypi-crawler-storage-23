"""
UI modules for NEPSE CLI
"""
