"""
IPO Result Module.
Handles fetching and displaying IPO result data.
Optimized to use single-login session and find common IPOs.
"""

import json
import time
from typing import Dict, List, Optional, Tuple
import requests
from tenacity import retry, stop_after_attempt, wait_fixed

from rich.table import Table
from rich.panel import Panel
from rich import box
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TaskID

from ..utils.formatting import format_rupees, format_number
from ..config import load_family_members
from ..ui.console import console

# ==========================================
# Constants
# ==========================================
USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0"
MS_API_BASE = "https://webbackend.cdsc.com.np/api"

# Avoid indefinite hangs on slow/unresponsive endpoints.
# Tuple form: (connect_timeout_seconds, read_timeout_seconds)
REQUEST_TIMEOUT = (10, 30)

BASE_HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Content-Type": "application/json",
    "Origin": "https://meroshare.cdsc.com.np",
    "Connection": "keep-alive",
    "Referer": "https://meroshare.cdsc.com.np/",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-site",
    "Pragma": "no-cache",
    "Cache-Control": "no-cache",
}


# ==========================================
# Errors
# ==========================================
class LocalException(Exception):
    """Local exception for IPO result operations."""
    def __init__(self, message: str):
        self.message = message
    
    def __str__(self):
        return self.message


class GlobalError(Exception):
    """Global error for critical failures."""
    def __init__(self, message: str):
        self.message = message
    
    def __str__(self):
        return self.message


# ==========================================
# IPO Result Models
# ==========================================
class IPOResultEntry:
    """Represents an IPO result for a single account."""
    
    def __init__(self, account_name: str, alloted: Optional[bool], quantity: int = 0, 
                 company_name: str = "", scrip: str = ""):
        self.account_name = account_name
        self.alloted = alloted
        self.quantity = quantity
        self.company_name = company_name
        self.scrip = scrip
    
    def to_json(self):
        return {
            "account_name": self.account_name,
            "alloted": self.alloted,
            "quantity": self.quantity,
            "company_name": self.company_name,
            "scrip": self.scrip,
        }


# ==========================================
# Helper Functions
# ==========================================
def fetch_capital_id(dpid_code: str) -> int:
    """
    Fetch Capital ID from DPID Code (e.g. '10900' -> 190).
    """
    console.print(f'[cyan]🔍 Looking up Capital ID for DPID:[/cyan] {dpid_code}')
    
    try:
        response = requests.get(
            f"{MS_API_BASE}/meroShare/capital/",
            headers=BASE_HEADERS,
            timeout=REQUEST_TIMEOUT,
        )
        if response.status_code == 200:
            capitals = response.json()
            for cap in capitals:
                if cap.get('code') == str(dpid_code):
                    console.print(f"[green]✓ Found Capital:[/green] {cap.get('name')} (ID: {cap.get('id')})")
                    return cap.get('id')
    except requests.exceptions.Timeout:
        console.print("[red]✗ Capital lookup timed out. Try again.[/red]")
    except requests.exceptions.RequestException as e:
        console.print(f"[red]✗ Error fetching capitals:[/red] {e}")
    
    raise GlobalError(f"Could not find Capital ID for DPID {dpid_code}")


def fetch_capital_id_silent(dpid_code: str) -> int:
    """
    Fetch Capital ID from DPID Code (e.g. '10900' -> 190) - Silent version for progress bars.
    """
    try:
        response = requests.get(
            f"{MS_API_BASE}/meroShare/capital/",
            headers=BASE_HEADERS,
            timeout=REQUEST_TIMEOUT,
        )
        if response.status_code == 200:
            capitals = response.json()
            for cap in capitals:
                if cap.get('code') == str(dpid_code):
                    return cap.get('id')
    except:
        pass
    
    raise GlobalError(f"Could not find Capital ID for DPID {dpid_code}")


# ==========================================
# Account Class
# ==========================================
class Account:
    """Handles Meroshare account operations for IPO result checking."""
    
    def __init__(self, username: str, password: str, dpid_code: str, capital_id: int):
        self.username = username
        self.password = password
        self.dpid_code = dpid_code
        self.capital_id = capital_id
        
        self.dmat = None
        self.name = None
        self.auth_token = None

        self.__session = requests.Session()
        self.__session.headers.update(BASE_HEADERS)

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2), reraise=True)
    def login(self) -> str:
        """Perform login and get auth token."""
        data = {
            "clientId": str(self.capital_id),
            "username": self.username,
            "password": self.password,
        }

        headers = BASE_HEADERS.copy()
        headers["Authorization"] = "null"
        headers["Content-Type"] = "application/json"

        with console.status("[bold green]Logging in...", spinner="dots"):
            login_req = requests.post(
                f"{MS_API_BASE}/meroShare/auth/",
                json=data,
                headers=headers,
                timeout=REQUEST_TIMEOUT,
            )
            
            if login_req.status_code != 200:
                raise LocalException(f"Login failed with status {login_req.status_code}")

            self.auth_token = login_req.headers.get("Authorization")
            self.__session.headers.update({"Authorization": self.auth_token})
        
        console.print('[bold green]✓ Login successful[/bold green]')
        return self.auth_token

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2), reraise=True)
    def fetch_own_details(self):
        """Fetch user details to get Demat number and name."""
        console.print('[cyan]👤 Fetching account details...[/cyan]')
        
        headers = BASE_HEADERS.copy()
        headers["Authorization"] = self.auth_token
        
        response = requests.get(
            f"{MS_API_BASE}/meroShare/ownDetail/",
            headers=headers,
            timeout=REQUEST_TIMEOUT,
        )

        if response.status_code == 200:
            data = response.json()
            self.dmat = data.get('demat')
            self.name = data.get('name')
            console.print(f'[green]✓ Account:[/green] {self.name}')
            console.print(f'[green]✓ Demat:[/green] {self.dmat}')
            return data
        else:
            raise LocalException(f"Failed to fetch own details: {response.status_code}")

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2), reraise=True)
    def fetch_application_reports(self) -> List[Dict]:
        """Fetch application reports to see applied IPOs."""
        headers = BASE_HEADERS.copy()
        headers["Authorization"] = self.auth_token
        headers["Content-Type"] = "application/json"

        data = {
            "filterFieldParams": [
                {
                    "key": "companyShare.companyIssue.companyISIN.script",
                    "alias": "Scrip",
                },
                {
                    "key": "companyShare.companyIssue.companyISIN.company.name",
                    "alias": "Company Name",
                },
            ],
            "page": 1,
            "size": 200,
            "searchRoleViewConstants": "VIEW_APPLICANT_FORM_COMPLETE",
            "filterDateParams": [
                {
                    "key": "appliedDate",
                    "condition": "",
                    "alias": "",
                    "value": "",
                },
                {
                    "key": "appliedDate",
                    "condition": "",
                    "alias": "",
                    "value": "",
                },
            ],
        }

        console.print('[cyan]📝 Fetching your IPO applications...[/cyan]')
        recent_applied_req = requests.post(
            f"{MS_API_BASE}/meroShare/applicantForm/active/search/",
            json=data,
            headers=headers,
            timeout=REQUEST_TIMEOUT,
        )

        if recent_applied_req.status_code != 200:
            raise LocalException(f"Application reports request failed: {recent_applied_req.status_code}")

        return recent_applied_req.json().get("object", [])

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2), reraise=True)
    def fetch_application_status(self, form_id: int) -> Dict:
        """Fetch detailed application status for a specific form."""
        headers = BASE_HEADERS.copy()
        headers["Authorization"] = self.auth_token

        with console.status("[bold green]Fetching application status...", spinner="dots"):
            details_req = requests.get(
                f"{MS_API_BASE}/meroShare/applicantForm/report/detail/{form_id}",
                headers=headers,
                timeout=REQUEST_TIMEOUT,
            )

        if details_req.status_code != 200:
            raise LocalException(f"Application status request failed: {details_req.status_code}")

        return details_req.json()

    def logout(self):
        """Logout from the session."""
        if self.auth_token:
            try:
                headers = BASE_HEADERS.copy()
                headers["Authorization"] = self.auth_token
                requests.get(
                    f"{MS_API_BASE}/meroShare/auth/logout/",
                    headers=headers,
                    timeout=REQUEST_TIMEOUT,
                )
                self.auth_token = None
            except:
                pass

    # Silent versions for progress bar UI
    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2), reraise=True)
    def login_silent(self) -> str:
        """Perform login and get auth token - Silent version."""
        data = {
            "clientId": str(self.capital_id),
            "username": self.username,
            "password": self.password,
        }

        headers = BASE_HEADERS.copy()
        headers["Authorization"] = "null"
        headers["Content-Type"] = "application/json"

        login_req = requests.post(
            f"{MS_API_BASE}/meroShare/auth/",
            json=data,
            headers=headers,
            timeout=REQUEST_TIMEOUT,
        )
        
        if login_req.status_code != 200:
            raise LocalException(f"Login failed with status {login_req.status_code}")

        self.auth_token = login_req.headers.get("Authorization")
        self.__session.headers.update({"Authorization": self.auth_token})
        
        return self.auth_token

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2), reraise=True)
    def fetch_own_details_silent(self):
        """Fetch user details to get Demat number and name - Silent version."""
        headers = BASE_HEADERS.copy()
        headers["Authorization"] = self.auth_token
        
        response = requests.get(
            f"{MS_API_BASE}/meroShare/ownDetail/",
            headers=headers,
            timeout=REQUEST_TIMEOUT,
        )

        if response.status_code == 200:
            data = response.json()
            self.dmat = data.get('demat')
            self.name = data.get('name')
            return data
        else:
            raise LocalException(f"Failed to fetch own details: {response.status_code}")

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(2), reraise=True)
    def fetch_application_reports_silent(self) -> List[Dict]:
        """Fetch application reports to see applied IPOs - Silent version."""
        headers = BASE_HEADERS.copy()
        headers["Authorization"] = self.auth_token
        headers["Content-Type"] = "application/json"

        data = {
            "filterFieldParams": [
                {
                    "key": "companyShare.companyIssue.companyISIN.script",
                    "alias": "Scrip",
                },
                {
                    "key": "companyShare.companyIssue.companyISIN.company.name",
                    "alias": "Company Name",
                },
            ],
            "page": 1,
            "size": 200,
            "searchRoleViewConstants": "VIEW_APPLICANT_FORM_COMPLETE",
            "filterDateParams": [
                {
                    "key": "appliedDate",
                    "condition": "",
                    "alias": "",
                    "value": "",
                },
                {
                    "key": "appliedDate",
                    "condition": "",
                    "alias": "",
                    "value": "",
                },
            ],
        }

        recent_applied_req = requests.post(
            f"{MS_API_BASE}/meroShare/applicantForm/active/search/",
            json=data,
            headers=headers,
            timeout=REQUEST_TIMEOUT,
        )

        if recent_applied_req.status_code != 200:
            raise LocalException(f"Application reports request failed: {recent_applied_req.status_code}")

        return recent_applied_req.json().get("object", [])


# ==========================================
# Display Functions
# ==========================================
def display_member_applications(applications: List[Dict]) -> Optional[int]:
    """Display member's IPO applications and let them select one."""
    if not applications:
        console.print("[yellow]⚠ No IPO applications found for this account[/yellow]")
        return None
    
    table = Table(
        title="📋 Your IPO Applications",
        box=box.ROUNDED,
        header_style="bold cyan",
        expand=True,
    )
    
    table.add_column("#", style="dim", width=4, justify="center")
    table.add_column("Scrip", style="bold magenta", width=12)
    table.add_column("Company Name", style="white")
    table.add_column("Status", style="cyan", width=20)
    
    for idx, app in enumerate(applications, 1):
        table.add_row(
            str(idx),
            app.get("scrip", ""),
            app.get("companyName", ""),
            app.get("statusName", ""),
        )
    
    console.print(table)
    console.print(f"\n[dim]Found {len(applications)} IPO applications[/dim]\n")
    
    try:
        choice = console.input("[cyan]Select IPO number to check result:[/cyan] ").strip()
        
        if not choice:
            return None
        
        idx = int(choice) - 1
        if 0 <= idx < len(applications):
            return applications[idx].get("companyShareId")
        else:
            console.print("[red]Invalid selection[/red]")
            return None
    except (ValueError, KeyboardInterrupt):
        console.print("\n[yellow]Cancelled[/yellow]")
        return None


def display_ipo_results(results: List[IPOResultEntry], company_name: str = "") -> None:
    """Display IPO results in a Rich table."""
    title = f"🎉 IPO Result: {company_name}" if company_name else "🎉 IPO Results"
    
    table = Table(
        title=title,
        box=box.ROUNDED,
        header_style="bold cyan",
        expand=True,
        show_lines=True
    )
    
    table.add_column("#", style="dim", width=4, justify="center")
    table.add_column("Account Name", style="bold white")
    table.add_column("Alloted", justify="center", style="bold")
    table.add_column("Quantity", justify="right", style="cyan")
    
    alloted_count = 0
    total_quantity = 0
    
    for idx, result in enumerate(results, 1):
        if result.alloted is None:
            status = "[dim]N/A[/dim]"
            quantity_str = "[dim]-[/dim]"
        elif result.alloted:
            status = "[bold green]✓ Yes[/bold green]"
            quantity_str = f"[green]{result.quantity}[/green]"
            alloted_count += 1
            total_quantity += result.quantity
        else:
            status = "[bold red]✗ No[/bold red]"
            quantity_str = "[dim]0[/dim]"
        
        table.add_row(
            str(idx),
            result.account_name,
            status,
            quantity_str
        )
    
    table.add_section()
    table.add_row(
        "",
        f"[bold]Summary[/bold]",
        f"[bold]{alloted_count}/{len(results)} accounts alloted[/bold]",
        f"[bold green]{total_quantity} shares[/bold green]",
        style="bold bright_white"
    )
    
    console.print()
    console.print(table)
    console.print()





# ==========================================
# Core Functions
# ==========================================
def get_member_applications(member: Dict, keep_session: bool = False, progress: Progress = None, task_id: TaskID = None) -> Tuple:
    """
    Login and fetch member's IPO applications.
    Args:
        member: Member dict
        keep_session: Return active account object
        progress: Rich Progress instance for loading bar
        task_id: Task ID for progress updates
    Returns:
        applications list (if keep_session=False)
        (applications, account) (if keep_session=True)
    """
    try:
        dp_value = member.get('dp_value', '')
        dpid_code = member.get('dpid_code')
        
        if not dpid_code and dp_value:
            import re
            match = re.search(r'\((\d+)\)', dp_value)
            if match:
                dpid_code = match.group(1)
            elif dp_value.isdigit():
                dpid_code = dp_value
        
        if not dpid_code:
            if progress is not None and task_id is not None:
                progress.update(task_id, description=f"[red]✗ {member['name']}: No DPID[/red]", advance=1)
            else:
                console.print(f"[red]✗ Could not determine DPID code for {member['name']}[/red]")
            return (None, None) if keep_session else None
        
        # Update progress: Looking up Capital
        if progress is not None and task_id is not None:
            progress.update(task_id, description=f"[cyan]{member['name']}: Looking up Capital...[/cyan]")
        
        capital_id = fetch_capital_id_silent(dpid_code)
        
        account = Account(
            username=member['username'],
            password=member['password'],
            dpid_code=dpid_code,
            capital_id=capital_id
        )
        
        # Update progress: Logging in
        if progress is not None and task_id is not None:
            progress.update(task_id, description=f"[cyan]{member['name']}: Logging in...[/cyan]")
        
        account.login_silent()
        time.sleep(0.5)
        
        # Update progress: Fetching account details
        if progress is not None and task_id is not None:
            progress.update(task_id, description=f"[cyan]{member['name']}: Fetching account...[/cyan]")
        
        account.fetch_own_details_silent()
        time.sleep(0.5)
        
        # Update progress: Fetching applications
        if progress is not None and task_id is not None:
            progress.update(task_id, description=f"[cyan]{member['name']}: Fetching applications...[/cyan]")
        
        applications = account.fetch_application_reports_silent()
        
        if not applications:
            if progress is not None and task_id is not None:
                progress.update(task_id, description=f"[yellow]{member['name']}: No applications[/yellow]", advance=1)
            else:
                console.print(f"[yellow]  ⚠ No applications found for {member['name']}[/yellow]")
            if not keep_session:
                account.logout()
            return ([], account) if keep_session else []
        
        # Update progress: Success
        if progress is not None and task_id is not None:
            progress.update(task_id, description=f"[green]✓ {member['name']}[/green]", advance=1)
        else:
            console.print(f"[green]  ✓ Found {len(applications)} applications for {member['name']}[/green]")
        
        if not keep_session:
            account.logout()
            return applications
        else:
            return (applications, account)
        
    except Exception as e:
        if progress is not None and task_id is not None:
            progress.update(task_id, description=f"[red]✗ {member['name']}: Error[/red]", advance=1)
        else:
            console.print(f"[red]  ✗ Error for {member['name']}: {e}[/red]")
        return (None, None) if keep_session else None


def check_ipo_result_for_member(member: Dict, company_share_id: int = None) -> Optional[IPOResultEntry]:
    """Check IPO result for a single member."""
    # Similar logic to before, but we can reuse get_member_applications
    try:
        applications, account = get_member_applications(member, keep_session=True)
        
        if not applications or not account:
            return None
            
        if company_share_id is None:
            # Interactive selection
            company_share_id = display_member_applications(applications)
            if company_share_id is None:
                account.logout()
                return None
        
        # Find application
        target_app = None
        for app in applications:
            if app.get("companyShareId") == company_share_id:
                target_app = app
                break
        
        if not target_app:
            console.print(f"[red]✗ No application found for Company Share ID {company_share_id}[/red]")
            account.logout()
            return None
            
        # Check detailed status
        console.print(f"\n[cyan]Checking result for {target_app.get('companyName')}...[/cyan]")
        status = account.fetch_application_status(target_app.get('applicantFormId'))
        
        status_name = status.get("statusName", "")
        alloted = None
        quantity = 0
        
        if status_name == "Alloted":
            alloted = True
            quantity = status.get("receivedKitta", 0)
        elif status_name in ["Not Alloted", "Rejected"]:
            alloted = False
            quantity = 0
        
        result = IPOResultEntry(
            account_name=member['name'],
            alloted=alloted,
            quantity=quantity,
            company_name=target_app.get('companyName', ''),
            scrip=target_app.get('scrip', '')
        )
        
        account.logout()
        return result
        
    except Exception as e:
        console.print(f"[red]⚠ Error: {e}[/red]")
        return None


def find_common_ipos(members: List[Dict]) -> Tuple[Optional[int], Optional[List[Dict]]]:
    """
    Find IPO applications common to ALL members.
    Returns (company_share_id, all_member_data) where data has active sessions.
    """
    import concurrent.futures
    
    console.print(f"\n[bold cyan]{'='*70}[/bold cyan]")
    console.print(f"[bold white]Finding Common IPO Applications Across {len(members)} Members[/bold white]")
    console.print(f"[bold cyan]{'='*70}[/bold cyan]\n")
    
    all_member_data = [] # [{'member': m, 'applications': apps, 'account': account}]
    
    try:
        # 1. Parallel Login and fetch with individual progress bars
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=None),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
            transient=False
        ) as progress:
            
            # Map futures to members so we can track which is which
            future_to_member = {}
            
            with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                # Create a task for each member
                for member in members:
                    # total=1 means it will be complete when advance=1 is called at the end
                    task_id = progress.add_task(f"[cyan]{member['name']}[/cyan]", total=1)
                    
                    # Submit the task to the pool
                    future = executor.submit(
                        get_member_applications, 
                        member=member, 
                        keep_session=True, 
                        progress=progress, 
                        task_id=task_id
                    )
                    future_to_member[future] = member
                
                # Wait for all to complete
                for future in concurrent.futures.as_completed(future_to_member):
                    member = future_to_member[future]
                    result = future.result()
                    
                    if result:
                        apps, account = result
                        if apps is not None:
                            all_member_data.append({
                                'member': member,
                                'applications': apps,
                                'account': account
                            })
            
        # Check if we got data for everyone
        if len(all_member_data) != len(members):
            console.print(f"\n[yellow]⚠ Only retrieved data for {len(all_member_data)}/{len(members)} members.[/yellow]")
            # If any critically failed (returned None), we might have issues.
            # get_member_applications returns None on total failure.
            # If so, we should probably abort or ask to proceed. 
            # For "common IPOs", we need All.
            if len(all_member_data) < len(members):
                 console.print("[red]Cannot find common IPOs because some members failed.[/red]")
                 for data in all_member_data:
                    if data['account']: data['account'].logout()
                 return None, None

        console.print(f"\n[cyan]✓ All applications fetched successfully![/cyan]")
        console.print(f"[cyan]Analyzing common applications...[/cyan]\n")
        
        # 2. Find common IPOs
        if not all_member_data:
            return None, None
            
        first_member_apps = all_member_data[0]['applications']
        if not first_member_apps:
            console.print("[yellow]No applications for first member[/yellow]")
             # Cleanup
            for data in all_member_data:
                if data['account']: data['account'].logout()
            return None, None

        common_ipos = {}
        for app in first_member_apps:
            company_share_id = app.get('companyShareId')
            
            # Check others
            is_common = True
            for member_data in all_member_data[1:]:
                found = any(a.get('companyShareId') == company_share_id for a in member_data['applications'])
                if not found:
                    is_common = False
                    break
            
            if is_common:
                common_ipos[company_share_id] = {
                    'companyShareId': company_share_id,
                    'scrip': app.get('scrip'),
                    'companyName': app.get('companyName'),
                    'appliedBy': len(members)
                }
        
        if not common_ipos:
            console.print("[yellow]⚠ No common IPO applications found.[/yellow]")
            # Cleanup
            for data in all_member_data:
                if data['account']: data['account'].logout()
            return None, None
            
        # 3. Display common IPOs
        table = Table(title="📊 Common IPO Applications", box=box.ROUNDED, header_style="bold cyan", expand=True)
        table.add_column("#", style="dim", width=4, justify="center")
        table.add_column("Scrip", style="bold magenta")
        table.add_column("Company Name", style="white")
        table.add_column("Applied By", style="green", justify="center")
        
        common_list = list(common_ipos.values())
        for idx, ipo in enumerate(common_list, 1):
            table.add_row(str(idx), ipo['scrip'], ipo['companyName'], f"✓ All {ipo['appliedBy']}")
        
        console.print(table)
        
        # 4. Select
        try:
            choice = console.input("[cyan]Select IPO number to check results:[/cyan] ").strip()
            if not choice:
                 # Cleanup
                for data in all_member_data:
                    if data['account']: data['account'].logout()
                return None, None
            
            idx = int(choice) - 1
            if 0 <= idx < len(common_list):
                selected = common_list[idx]
                console.print(f"\n[green]✓ Selected: {selected['companyName']}[/green]")
                return selected['companyShareId'], all_member_data
            else:
                console.print("[red]Invalid selection[/red]")
                 # Cleanup
                for data in all_member_data:
                    if data['account']: data['account'].logout()
                return None, None
        except:
             # Cleanup
            for data in all_member_data:
                if data['account']: data['account'].logout()
            return None, None

    except Exception as e:
        console.print(f"[red]Error in logic: {e}[/red]")
         # Cleanup
        for data in all_member_data:
            if data['account']: 
                try: data['account'].logout() 
                except: pass
        return None, None


def _check_member_result_task(data: Dict, company_share_id: int, company_name: str) -> Optional[IPOResultEntry]:
    """Helper function to check result for a single member in a thread."""
    try:
        member_name = data['member']['name']
        account = data['account']
        apps = data['applications']
        
        # Find target app
        target_app = next((a for a in apps if a.get('companyShareId') == company_share_id), None)
        
        result = None
        if target_app:
            status = account.fetch_application_status(target_app.get('applicantFormId'))
            
            status_name = status.get("statusName", "")
            alloted = None
            quantity = 0
            
            if status_name == "Alloted":
                alloted = True
                quantity = status.get("receivedKitta", 0)
            elif status_name in ["Not Alloted", "Rejected"]:
                alloted = False
            
            result = IPOResultEntry(
                account_name=member_name,
                alloted=alloted,
                quantity=quantity,
                company_name=company_name,
                scrip=target_app.get('scrip', '')
            )
        
        # Logout immediately after checking this member
        account.logout()
        return result
    except Exception:
        # Ensure logout on error
        if data.get('account'):
            try: data['account'].logout()
            except: pass
        return None


def check_common_ipo_result(members: List[Dict]):
    """
    Orchestrate the common IPO check flow:
    1. Login all members & cache apps
    2. Find common IPO & Select
    3. Check results using cached sessions
    4. Logout
    """
    import concurrent.futures

    company_share_id, active_data = find_common_ipos(members)
    
    if not company_share_id or not active_data:
        return
    
    # Get company name for reporting
    company_name = ""
    for app in active_data[0]['applications']:
        if app.get('companyShareId') == company_share_id:
            company_name = app.get('companyName')
            break
            
    # Check results
    console.print(f"\n[bold cyan]Checking results for all {len(members)} members...[/bold cyan]")
    
    results = []
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
            transient=True
        ) as progress:
            task = progress.add_task("[cyan]Checking ALL results...[/cyan]", total=len(active_data))
            
            with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                futures = []
                for data in active_data:
                    future = executor.submit(_check_member_result_task, data, company_share_id, company_name)
                    futures.append(future)
                
                for future in concurrent.futures.as_completed(futures):
                    res = future.result()
                    if res:
                        results.append(res)
                    progress.advance(task)

        # Final Display
        if results:
            # Sort results to match original member order if possible, or just by name
            # A simple sort by name is usually good enough
            results.sort(key=lambda x: x.account_name)
            display_ipo_results(results, company_name)

    except Exception as e:
        console.print(f"[red]Error during result check: {e}[/red]")
        # Ensure logout
        for data in active_data:
            if data['account']:
                try: data['account'].logout()
                except: pass


# ==========================================
# CLI Command Handler
# ==========================================
def cmd_check_result(member_name: str = None, all_members: bool = False):
    """
    Command handler for checking IPO results.
    
    Args:
        member_name: Specific member name to check
        all_members: If True, checks common IPOs for all members
    """
    from ..config import load_family_members, get_member_by_name
    from ..ui.member_ui import select_family_member, select_members_for_ipo
    
    config = load_family_members()
    members = config.get('members', [])
    
    if not members:
        console.print("[red]No family members found. Use 'add' to add a member.[/red]")
        return

    if all_members:
        # Interactive selection of members for result check
        console.print()
        selected_members = select_members_for_ipo(members)
        
        if not selected_members:
            return
        
        # Show selected members
        console.print()
        table = Table(
            title="✓ Selected Members for IPO Result Check",
            box=box.ROUNDED,
            header_style="bold green",
            border_style="green"
        )
        table.add_column("No.", justify="right", style="cyan")
        table.add_column("Name", style="bold white")
        
        for idx, member in enumerate(selected_members, 1):
            table.add_row(
                str(idx),
                member['name']
            )
        
        console.print(table)
        console.print()
        
        # Check common IPOs for selected members
        check_common_ipo_result(selected_members)
        return

    # If member specified, check only for them
    if member_name:
        member = get_member_by_name(member_name)
        if not member:
            console.print(f"[red]Member '{member_name}' not found.[/red]")
            return
        result = check_ipo_result_for_member(member)
        if result:
            display_ipo_results([result], result.company_name)
        return

    # Interactive Menu
    console.print("\n[bold magenta]IPO Result Checker[/bold magenta]")
    console.print("\n[cyan]Options:[/cyan]")
    console.print("  1. Check for single member")
    console.print("  2. Check common IPO for [bold]SELECTED[/bold] members")
    
    try:
        choice = console.input("\n[cyan]Choice (1/2):[/cyan] ").strip()
        
        if choice == "2":
            # Interactive selection of members for result check
            console.print()
            selected_members = select_members_for_ipo(members)
            
            if not selected_members:
                return
            
            # Show selected members
            console.print()
            table = Table(
                title="✓ Selected Members for IPO Result Check",
                box=box.ROUNDED,
                header_style="bold green",
                border_style="green"
            )
            table.add_column("No.", justify="right", style="cyan")
            table.add_column("Name", style="bold white")
            
            for idx, member in enumerate(selected_members, 1):
                table.add_row(
                    str(idx),
                    member['name']
                )
            
            console.print(table)
            console.print()
            
            check_common_ipo_result(selected_members)
        elif choice == "1":
            member = select_family_member()
            if member:
                result = check_ipo_result_for_member(member)
                if result:
                    display_ipo_results([result], result.company_name)
        else:
            console.print("[yellow]Invalid Choice[/yellow]")
            
    except (ValueError, KeyboardInterrupt):
        console.print("\n[yellow]Cancelled[/yellow]")
