# Greenstream Config

This contains files for reading/writing configuration classes for Greenstream.

## Release

Run the `Release` action on github.

**IT IS PUBLISHED PUBLICLY TO PYPI**