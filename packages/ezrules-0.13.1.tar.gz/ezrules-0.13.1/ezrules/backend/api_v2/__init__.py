"""
FastAPI v2 API module for ezrules.

This module contains the new FastAPI-based API endpoints that will
eventually replace the Flask-based endpoints.
"""
