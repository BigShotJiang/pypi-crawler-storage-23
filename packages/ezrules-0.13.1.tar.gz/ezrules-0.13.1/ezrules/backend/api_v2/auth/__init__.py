"""Authentication module for FastAPI API."""
