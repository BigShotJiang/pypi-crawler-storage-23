# keyof

[![PyPI version](https://img.shields.io/pypi/v/py-keyof.svg)](https://pypi.org/project/py-keyof/)
[![Python versions](https://img.shields.io/pypi/pyversions/py-keyof.svg)](https://pypi.org/project/py-keyof/)
[![License](https://img.shields.io/pypi/l/py-keyof.svg)](https://github.com/eyusd/keyof/blob/main/LICENSE)
[![CI](https://github.com/eyusd/keyof/actions/workflows/ci.yml/badge.svg)](https://github.com/eyusd/keyof/actions/workflows/ci.yml)
[![Coverage](https://img.shields.io/codecov/c/github/eyusd/keyof)](https://codecov.io/gh/eyusd/keyof)

**Type-safe property path navigation for Python.**

`keyof` brings TypeScript's `keyof` concept to Python. A `KeyOf[T]` object captures a typed path through an object's attributes, validated statically by Pylance/Pyright via a selector lambda.

## Features

- 🔒 **Type-safe**: Full static type checking with Pylance/Pyright/mypy
- 🎯 **Zero runtime dependencies** (only `typing-extensions`)
- 📦 **Lightweight**: Single file, ~300 lines of code
- 🔄 **Multiple serialization formats**: dot, POSIX, bracket, JSONPath, XPath
- 🏗️ **Works with everything**: dataclasses, Pydantic, NamedTuple, dicts, and more
- ⚡ **Immutable**: Thread-safe by design

## Installation

```bash
pip install py-keyof
```

## Quick Start

```python
from dataclasses import dataclass
from keyof import KeyOf

@dataclass
class Address:
    city: str
    zipcode: int

@dataclass
class User:
    name: str
    address: Address

# Create a type-safe path
city_path: KeyOf[User] = KeyOf(lambda u: u.address.city)

# Use it to extract values
user = User(name="Alice", address=Address(city="London", zipcode=12345))
city_path.from_(user)  # → "London"

# Serialize to various formats
str(city_path)           # → "address.city"
city_path.to_jsonpath()  # → "$.address.city"
city_path.to_bracket()   # → "['address']['city']"
```

## Why keyof?

In large codebases, referencing nested properties by string paths is error-prone:

```python
# ❌ Fragile: No IDE support, typos go unnoticed, refactoring breaks silently
user_data.get("adress.city")  # Typo! And you won't know until runtime
```

With `keyof`, the path is validated at type-check time:

```python
# ✅ Type-safe: IDE autocomplete, typos caught immediately, refactoring-friendly
KeyOf(lambda u: u.adress.city)  # Pylance/Pyright error: "adress" doesn't exist
```

## Usage

### Basic Value Access

```python
from keyof import KeyOf

path = KeyOf(lambda u: u.address.city)

# Get value (raises AttributeError if path doesn't exist)
city = path.from_(user)

# Get value with default
city = path.from_(user, default="Unknown")
```

### Working with Dicts and Lists

```python
data = {
    "users": [
        {"name": "Alice", "score": 100},
        {"name": "Bob", "score": 85}
    ]
}

# Access nested dict/list structures
path = KeyOf(lambda d: d["users"][0]["name"])
path.from_(data)  # → "Alice"
```

### Path Introspection

```python
path = KeyOf(lambda u: u.address.city)

path.parts   # → ("address", "city")
path.depth   # → 2
path.root    # → "address"
path.leaf    # → "city"
len(path)    # → 2

# Get parent path
parent = path.parent()  # → KeyOf representing "address"
```

### Serialization Formats

```python
path = KeyOf(lambda u: u.address.city)

path.to_dot()      # → "address.city"
path.to_posix()    # → "address/city"
path.to_bracket()  # → "['address']['city']"
path.to_jsonpath() # → "$.address.city"
path.to_xpath()    # → "/address/city"
path.to_jmespath() # → "address.city"

# Custom format
path.format("{root} -> {leaf}")  # → "address -> city"
```

### Comparison and Hashing

```python
p1 = KeyOf(lambda u: u.name)
p2 = KeyOf(lambda u: u.name)

p1 == p2           # → True
p1 == "name"       # → True (compares dot notation)
hash(p1) == hash(p2)  # → True (can be used in sets/dicts)

# Sorting
paths = [KeyOf(lambda u: u.name), KeyOf(lambda u: u.id)]
sorted(paths)  # Sorts lexicographically by path
```

## Type Annotations

`KeyOf` supports an optional return type parameter:

```python
# Without return type (returns Any)
path: KeyOf[User] = KeyOf(lambda u: u.address.city)

# With return type
path: KeyOf[User, str] = KeyOf(lambda u: u.address.city)
city: str = path.from_(user)  # Type checker knows this is str
```

## API Reference

### `KeyOf[T, R]`

| Method/Property | Description |
|-----------------|-------------|
| `from_(obj, default=...)` | Extract value at this path from `obj` |
| `parts` | Tuple of path segments |
| `depth` | Number of segments |
| `root` | First segment |
| `leaf` | Last segment |
| `parent()` | New KeyOf for parent path |
| `to_dot()` | `"a.b.c"` |
| `to_posix()` | `"a/b/c"` |
| `to_bracket()` | `"['a']['b']['c']"` |
| `to_jsonpath()` | `"$.a.b.c"` |
| `to_xpath()` | `"/a/b/c"` |
| `to_jmespath()` | `"a.b.c"` |
| `format(template)` | Custom formatting |

## Development

```bash
# Clone the repository
git clone https://github.com/eyusd/keyof.git
cd keyof

# Install development dependencies
pip install -e ".[dev,test]"

# Run tests
pytest

# Run tests with coverage
pytest --cov=keyof --cov-report=term-missing

# Run type checking
mypy src/keyof

# Run linting
ruff check src tests
ruff format src tests
```

## Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## License

MIT License - see [LICENSE](LICENSE) for details.
