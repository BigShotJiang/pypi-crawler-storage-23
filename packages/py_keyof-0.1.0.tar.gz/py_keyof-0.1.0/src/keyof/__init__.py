"""
keyof - Type-safe property path navigation for Python.

A ``KeyOf[T]`` object captures a typed path through an object's attributes,
validated statically by Pylance/Pyright via a selector lambda.
"""

from .keyof import KeyOf, __version__

__all__ = ["KeyOf", "__version__"]
