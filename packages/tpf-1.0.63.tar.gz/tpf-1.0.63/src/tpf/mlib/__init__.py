"""
方法直接放tpf的__init__方法中
除以下两个
python基础方法，
data集获取方法 
"""

# from tpf.mlib.copod import COPODModel
from tpf.mlib.models import MLib

# from tpf.mlib.func import ModelPre
# from tpf.mlib.func import model_evaluate

# from tpf.mlib.onnx import save_onnx_ml,run_onnx_ml 

from tpf.mlib.modeltrain import ModelTrain 
from tpf.mlib.modelpre import ModelPre
from tpf.mlib.modeleval import ModelEval


