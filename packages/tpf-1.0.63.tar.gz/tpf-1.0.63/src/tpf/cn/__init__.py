"""
超级大脑


"""

from .link import Think
from .funcs import get_function_by_name
