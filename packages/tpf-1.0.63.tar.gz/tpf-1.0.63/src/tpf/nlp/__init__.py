from tpf.nlp.embedding import ClsIndexEmbed

# from tpf.nlp.text import TextDeal 
