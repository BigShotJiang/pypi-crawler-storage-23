
from tpf.conf.common import CommonConfig
from tpf.conf.common import ParamConfig
pc = ParamConfig()