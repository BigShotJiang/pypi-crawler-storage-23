from logging import (
    Logger,
)

from fluidattacks_timedoctor_sdk.auth import (
    AuthToken,
)
from fluidattacks_timedoctor_sdk.core import (
    ApiClient,
)

from . import (
    _computer_activity,
    _get_companies,
    _get_projects,
    _get_users,
    _worklog,
)


def new_api_client(log: Logger, token: AuthToken) -> ApiClient:
    return ApiClient(
        get_token_companies_id=_get_companies.get_token_companies(log, token),
        get_users_id=lambda c: _get_users.get_users(log, token, c),
        get_projects_id=lambda c: _get_projects.get_projects(log, token, c),
        get_activity=lambda c, u, d: _computer_activity.get_activity(
            log, token, c, u, d
        ),
        get_worklogs=lambda c, u, d: _worklog.get_worklog(log, token, c, u, d),
    )
