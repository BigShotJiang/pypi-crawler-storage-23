"""Platform-specific Gasoline binary for linux-x64."""

__version__ = "0.7.9"
