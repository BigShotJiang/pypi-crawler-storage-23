# gasoline-agentic-browser-linux-x64

Platform-specific binary package for Gasoline Agentic Browser Devtool MCP (linux-x64).

This package is automatically installed as a dependency when you run:

```bash
pip install gasoline-agentic-browser
```

You do not need to install this package directly.

For more information, see the main [gasoline-agentic-browser](https://pypi.org/project/gasoline-agentic-browser/) package.
