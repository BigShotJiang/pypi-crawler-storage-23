"""Snapshot testing for AI outputs."""

from vigil.snapshots.manager import snapshot, SnapshotManager

__all__ = ["snapshot", "SnapshotManager"]
