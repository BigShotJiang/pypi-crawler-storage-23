import mvulib
import matlab
import numpy as np
import time
from sklearn.metrics.pairwise import pairwise_distances
from scipy.sparse import csr_matrix

class Mvu:
    def __init__(self, n_neighbors=5, angles=2, mode=0, factor=1e-04, \
                 eps=1e-08, bigeps=1e-03, maxiter=150, \
                 distance=False, verbose=True):
        self.n_neighbors=n_neighbors
        self.angles=angles
        self.mode=mode
        self.factor=factor
        self.eps=eps
        self.bigeps=bigeps
        self.maxiter=maxiter
        self.distance=distance
        self.verbose=verbose

    def fit(self, X):
        if self.verbose:
            print(f"{'='*32} MVU {'='*32}\n")
            
        start=time.time()
        
        n=X.shape[0]
        self.n_samples=n
        
        DD=X
        self.n_features=None
        if not self.distance:
            DD=pairwise_distances(X)**2
            self.n_features=X.shape[1]

        if self.verbose:
            print(f"Parameters:\nn_samples={self.n_samples}\n"+\
                  f"n_features={self.n_features}\n"+\
                  f"n_neighbors={self.n_neighbors}\n"+\
                  f"angles={self.angles}\nmode={self.mode}\n"+\
                  f"factor={self.factor}\neps={self.eps}\n"+\
                  f"bigeps={self.bigeps}\n"+\
                  f"maxiter={self.maxiter}\n")

        def double(value):
            return matlab.double(np.array([value]).astype(np.float64),\
                                 size=(1,1))
            
        DD=np.ascontiguousarray(DD.astype(np.float64))
        DD=matlab.double(DD, size=DD.shape)
        k=double(self.n_neighbors)
        varargin=[\
            "angles", double(self.angles), \
            "mode", double(self.mode),\
            "factor", double(self.factor), \
            "eps", double(self.eps), \
            "bigeps", double(self.bigeps), \
            "maxiter", double(self.maxiter) \
            ]
        
        if self.verbose:
            print("Solving problem...\n")
            
        lib=mvulib.initialize()
        Y, details=lib.mvu(DD, k, *varargin, nargout=2)
        lib.terminate()
        
        rInd=np.array(details["rAdj"]).flatten()-1
        cInd=np.array(details["cAdj"]).flatten()-1
        self.adjacency_matrix=csr_matrix(\
            (np.repeat(1, len(rInd)), (rInd, cInd)), shape=(n, n), dtype="int")
        self.kernel=np.array(details["K"])
        self.eigenvalues=np.array(details["eigvals"]).flatten()
        self.cost=details["cost"]
        self.n_constraints=int(details["nconstr"])
        self.iter=int(details["iter"])
        self.numerr=int(details["numerr"])
        self.pinf=int(details["pinf"])
        self.dinf=int(details["dinf"])
        self.feasratio=details["feasratio"]
        self.rgap=details["rgap"]
        self.pres=details["pres"]
        self.dres=details["dres"]
        self._Y=np.array(Y)
        
        self.CONST=None
        if not self.mode:
            self.CONST=details["CONST"]
        
        self.n_components=None
        self.embedding=None
        self.reconstruction_error=None
        self.reconstruction_error_rel=None

        finish=time.time()
        time_taken=round(finish-start, 2)

        if self.verbose:
            print(f"Solver exited with status:\n"+\
                  f"numerr={self.numerr}\npinf={self.pinf}\n"+\
                  f"dinf={self.dinf}\nfeasratio={self.feasratio}\n")
            print(f"Execution took {time_taken} seconds.\n")
            print(f"{'='*69}")

        return self

    def transform(self, p):
        if self._Y is None:
            raise Exception("Call Mvu.fit() before calling transform!")
        self.embedding=self._Y[:, 0:p]
        self.n_components=p
        cost=np.sum(self.eigenvalues[p:]**2)
        self.reconstruction_error=np.sqrt(cost)
        self.reconstruction_error_rel=self.reconstruction_error/\
                                       np.sqrt(cost+np.sum(self.eigenvalues[:p]**2))
        return self.embedding

    def fit_transform(self, X, p):
        return self.fit(X).transform(p)

    def summary(self):
        print(f"Solver Summary:\nn_constraints={self.n_constraints}\n"+\
              f"iter={self.iter}\nnumerr={self.numerr}\n"+\
              f"pinf={self.pinf}\ndinf={self.dinf}\n"+\
              f"feasratio={self.feasratio}\nrgap={self.rgap}\n"+\
              f"pres={self.pres}\ndres={self.dres}\n")
        print(f"Mvu Summary:\n"+\
              f"cost={self.cost}\nn_components={self.n_components}\n"+\
              f"reconstruction_error={self.reconstruction_error}\n"+\
              f"reconstruction_error_rel={self.reconstruction_error_rel}")

