"""
Pydantic models for the lys core framework.
"""
from lys.core.models.configs import PubSubConfig

__all__ = [
    "PubSubConfig",
]