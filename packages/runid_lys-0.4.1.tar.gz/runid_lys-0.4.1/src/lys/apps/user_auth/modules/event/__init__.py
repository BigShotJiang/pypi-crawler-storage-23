"""
Event module for coordinating emails and notifications.
"""