from datetime import datetime
from typing import Optional

import strawberry
from sqlalchemy import select, Select

from lys.apps.base.modules.log.nodes import LogNode
from lys.core.contexts import Info
from lys.core.graphql.connection import lys_connection
from lys.core.graphql.registries import register_query
from lys.core.graphql.types import Query
from lys.core.utils.validators import validate_search_input


@register_query()
@strawberry.type
class LogQuery(Query):
    @lys_connection(
        ensure_type=LogNode,
        is_licenced=False,
        description="Search system logs by date range (start_date, end_date) and file name. For debugging and monitoring.",
        options={"generate_tool": False}
    )
    async def all_logs(
        self,
        info: Info,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        file_name: Optional[str] = None,
    ) -> Select:
        entity_type = info.context.app_manager.get_entity("log")

        stmt = select(entity_type).order_by(entity_type.created_at.desc())

        if start_date is not None:
            stmt = stmt.where(entity_type.created_at >= start_date)

        if end_date is not None:
            stmt = stmt.where(entity_type.created_at <= end_date)

        file_name = validate_search_input(file_name)
        if file_name is not None:
            stmt = stmt.where(entity_type.file_name.ilike(f"%{file_name}%"))

        return stmt