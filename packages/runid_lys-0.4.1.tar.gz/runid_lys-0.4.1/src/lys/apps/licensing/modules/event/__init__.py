"""
Event module for licensing app.

Extends the base EventService with licensing-specific events.
"""