"""
Webservice module for licensing app.
"""