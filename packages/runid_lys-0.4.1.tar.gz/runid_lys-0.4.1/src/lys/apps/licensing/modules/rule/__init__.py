"""
Rule module for license rule definitions and validation.
"""