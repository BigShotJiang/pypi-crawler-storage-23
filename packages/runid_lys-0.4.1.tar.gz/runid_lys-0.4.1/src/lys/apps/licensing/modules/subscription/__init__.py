"""
Subscription module for managing client subscriptions to license plans.
"""