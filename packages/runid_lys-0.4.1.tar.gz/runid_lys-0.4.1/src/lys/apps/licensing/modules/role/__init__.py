"""
Role module for licensing-specific role definitions.
"""