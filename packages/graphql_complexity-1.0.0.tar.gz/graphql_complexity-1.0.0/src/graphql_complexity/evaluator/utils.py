from __future__ import annotations

from typing import TYPE_CHECKING, Any

from graphql import (
    VariableNode,
    get_named_type,
    is_introspection_type,
)

if TYPE_CHECKING:
    from graphql import DirectiveNode, FieldNode


def get_node_argument_value(node: FieldNode | DirectiveNode, arg_name: str, variables: dict[str, Any]) -> Any:
    """Returns the value of the argument given by parameter."""
    arg = next((arg for arg in node.arguments if arg.name.value == arg_name), None)
    if not arg:
        raise ValueError(f"Value for {arg_name!r} not found in {node.name.value!r} arguments")

    if isinstance(arg.value, VariableNode):
        return variables.get(arg.value.name.value)

    return arg.value.value


def is_meta_type(type_, node) -> bool:
    """Return True if the field is a GraphQL meta field (__typename or introspection).

    Two cheap short-circuit checks run before the more expensive get_named_type /
    is_introspection_type calls:
      1. Exact match on "__typename" — the most common meta field.
      2. Prefix check on "__" — all meta fields share this prefix, so anything
         else can be rejected immediately without touching the type system.
    """
    name = node.name.value
    if name == "__typename":
        return True
    if not name.startswith("__"):
        return False

    unwrapped_type = get_named_type(type_)
    return unwrapped_type is not None and is_introspection_type(unwrapped_type)
