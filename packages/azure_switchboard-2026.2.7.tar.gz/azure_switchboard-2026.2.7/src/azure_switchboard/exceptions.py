class SwitchboardError(Exception):
    """Non-retriable switchboard/domain error."""
