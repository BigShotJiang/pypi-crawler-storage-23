# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
from __future__ import annotations

from onnxscript.rewriter.onnx_fusions._onnx_fusions import fuse

__all__ = [
    "fuse",
]
