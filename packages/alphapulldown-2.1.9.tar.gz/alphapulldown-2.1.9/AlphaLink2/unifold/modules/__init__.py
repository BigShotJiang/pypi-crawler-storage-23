"""Modules of Uni-Fold models."""

from unicore.utils import (
    set_jit_fusion_options,
)

set_jit_fusion_options()