"""Tests for TodoStore."""

from datetime import datetime
from pathlib import Path

import pytest

from folderbot.todo_store import TodoItem, TodoStore, EFFORT_LEVELS, STATUSES


@pytest.fixture
def db_path(tmp_path: Path) -> Path:
    return tmp_path / "test.db"


@pytest.fixture
def store(db_path: Path) -> TodoStore:
    return TodoStore(db_path)


class TestTodoStoreInit:
    """Tests for TodoStore initialization."""

    def test_creates_db_file(self, db_path: Path) -> None:
        TodoStore(db_path)
        assert db_path.exists()

    def test_creates_parent_dirs(self, tmp_path: Path) -> None:
        db_path = tmp_path / "nested" / "dir" / "test.db"
        TodoStore(db_path)
        assert db_path.exists()

    def test_reuses_existing_db(self, db_path: Path) -> None:
        store1 = TodoStore(db_path)
        store1.add(user_id=1, title="Test")
        store2 = TodoStore(db_path)
        items = store2.list(user_id=1)
        assert len(items) == 1


class TestTodoItem:
    """Tests for TodoItem dataclass."""

    def test_frozen(self) -> None:
        item = TodoItem(
            id=1,
            user_id=1,
            title="Test",
            description="",
            status="todo",
            effort="medium",
            tags=[],
            created_at="2026-01-01T00:00:00",
            updated_at="2026-01-01T00:00:00",
            completed_at=None,
        )
        with pytest.raises(AttributeError):
            item.title = "changed"  # type: ignore[misc]


class TestConstants:
    """Tests for module constants."""

    def test_effort_levels(self) -> None:
        assert EFFORT_LEVELS == ("tiny", "small", "medium", "large", "epic")

    def test_statuses(self) -> None:
        assert STATUSES == ("todo", "in_progress", "done")


class TestTodoAdd:
    """Tests for adding todos."""

    def test_add_minimal(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Buy groceries")
        assert item.id == 1
        assert item.user_id == 1
        assert item.title == "Buy groceries"
        assert item.description == ""
        assert item.status == "todo"
        assert item.effort == "medium"
        assert item.tags == []
        assert item.completed_at is None

    def test_add_with_all_fields(self, store: TodoStore) -> None:
        item = store.add(
            user_id=1,
            title="Write report",
            description="Quarterly sales report for Q1",
            effort="large",
            tags=["work", "urgent"],
        )
        assert item.title == "Write report"
        assert item.description == "Quarterly sales report for Q1"
        assert item.effort == "large"
        assert item.tags == ["work", "urgent"]

    def test_add_auto_increments_id(self, store: TodoStore) -> None:
        item1 = store.add(user_id=1, title="First")
        item2 = store.add(user_id=1, title="Second")
        assert item2.id == item1.id + 1

    def test_add_sets_timestamps(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Test")
        # Should be valid ISO format
        datetime.fromisoformat(item.created_at)
        datetime.fromisoformat(item.updated_at)
        assert item.created_at == item.updated_at

    def test_add_invalid_effort(self, store: TodoStore) -> None:
        with pytest.raises(ValueError, match="effort"):
            store.add(user_id=1, title="Test", effort="invalid")

    def test_add_different_users(self, store: TodoStore) -> None:
        store.add(user_id=1, title="User 1 task")
        store.add(user_id=2, title="User 2 task")
        assert len(store.list(user_id=1)) == 1
        assert len(store.list(user_id=2)) == 1


class TestTodoGet:
    """Tests for getting a single todo."""

    def test_get_existing(self, store: TodoStore) -> None:
        added = store.add(user_id=1, title="Test")
        fetched = store.get(todo_id=added.id, user_id=1)
        assert fetched is not None
        assert fetched.id == added.id
        assert fetched.title == "Test"

    def test_get_nonexistent(self, store: TodoStore) -> None:
        result = store.get(todo_id=999, user_id=1)
        assert result is None

    def test_get_wrong_user(self, store: TodoStore) -> None:
        added = store.add(user_id=1, title="Test")
        result = store.get(todo_id=added.id, user_id=2)
        assert result is None


class TestTodoList:
    """Tests for listing todos."""

    def test_list_empty(self, store: TodoStore) -> None:
        assert store.list(user_id=1) == []

    def test_list_all(self, store: TodoStore) -> None:
        store.add(user_id=1, title="First")
        store.add(user_id=1, title="Second")
        items = store.list(user_id=1)
        assert len(items) == 2

    def test_list_excludes_other_users(self, store: TodoStore) -> None:
        store.add(user_id=1, title="Mine")
        store.add(user_id=2, title="Theirs")
        items = store.list(user_id=1)
        assert len(items) == 1
        assert items[0].title == "Mine"

    def test_list_filter_by_status(self, store: TodoStore) -> None:
        store.add(user_id=1, title="Todo item")
        item2 = store.add(user_id=1, title="In progress item")
        store.update(todo_id=item2.id, user_id=1, status="in_progress")
        items = store.list(user_id=1, status="todo")
        assert len(items) == 1
        assert items[0].title == "Todo item"

    def test_list_filter_by_effort(self, store: TodoStore) -> None:
        store.add(user_id=1, title="Tiny task", effort="tiny")
        store.add(user_id=1, title="Small task", effort="small")
        store.add(user_id=1, title="Large task", effort="large")
        # max_effort="small" should return tiny + small
        items = store.list(user_id=1, max_effort="small")
        assert len(items) == 2
        titles = {i.title for i in items}
        assert titles == {"Tiny task", "Small task"}

    def test_list_filter_by_tag(self, store: TodoStore) -> None:
        store.add(user_id=1, title="Work task", tags=["work"])
        store.add(user_id=1, title="Home task", tags=["home"])
        store.add(user_id=1, title="Both", tags=["work", "home"])
        items = store.list(user_id=1, tag="work")
        assert len(items) == 2
        titles = {i.title for i in items}
        assert titles == {"Work task", "Both"}

    def test_list_filter_by_search(self, store: TodoStore) -> None:
        store.add(user_id=1, title="Buy groceries")
        store.add(user_id=1, title="Write report", description="Include grocery data")
        store.add(user_id=1, title="Clean house")
        items = store.list(user_id=1, search="grocer")
        assert len(items) == 2

    def test_list_combined_filters(self, store: TodoStore) -> None:
        store.add(user_id=1, title="Quick work task", effort="tiny", tags=["work"])
        store.add(user_id=1, title="Big work task", effort="epic", tags=["work"])
        store.add(user_id=1, title="Quick home task", effort="tiny", tags=["home"])
        items = store.list(user_id=1, max_effort="small", tag="work")
        assert len(items) == 1
        assert items[0].title == "Quick work task"

    def test_list_excludes_done_by_default(self, store: TodoStore) -> None:
        store.add(user_id=1, title="Active")
        done_item = store.add(user_id=1, title="Done")
        store.update(todo_id=done_item.id, user_id=1, status="done")
        items = store.list(user_id=1)
        assert len(items) == 1
        assert items[0].title == "Active"

    def test_list_include_done(self, store: TodoStore) -> None:
        store.add(user_id=1, title="Active")
        done_item = store.add(user_id=1, title="Done")
        store.update(todo_id=done_item.id, user_id=1, status="done")
        items = store.list(user_id=1, include_done=True)
        assert len(items) == 2

    def test_list_only_done(self, store: TodoStore) -> None:
        store.add(user_id=1, title="Active")
        done_item = store.add(user_id=1, title="Done")
        store.update(todo_id=done_item.id, user_id=1, status="done")
        items = store.list(user_id=1, status="done")
        assert len(items) == 1
        assert items[0].title == "Done"

    def test_list_ordered_by_created_at(self, store: TodoStore) -> None:
        store.add(user_id=1, title="First")
        store.add(user_id=1, title="Second")
        store.add(user_id=1, title="Third")
        items = store.list(user_id=1)
        assert [i.title for i in items] == ["First", "Second", "Third"]


class TestTodoUpdate:
    """Tests for updating todos."""

    def test_update_title(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Old title")
        updated = store.update(todo_id=item.id, user_id=1, title="New title")
        assert updated is not None
        assert updated.title == "New title"

    def test_update_status_to_in_progress(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Test")
        updated = store.update(todo_id=item.id, user_id=1, status="in_progress")
        assert updated is not None
        assert updated.status == "in_progress"
        assert updated.completed_at is None

    def test_update_status_to_done_sets_completed_at(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Test")
        updated = store.update(todo_id=item.id, user_id=1, status="done")
        assert updated is not None
        assert updated.status == "done"
        assert updated.completed_at is not None
        datetime.fromisoformat(updated.completed_at)

    def test_update_status_from_done_to_todo_clears_completed(
        self, store: TodoStore
    ) -> None:
        item = store.add(user_id=1, title="Test")
        store.update(todo_id=item.id, user_id=1, status="done")
        updated = store.update(todo_id=item.id, user_id=1, status="todo")
        assert updated is not None
        assert updated.status == "todo"
        assert updated.completed_at is None

    def test_update_effort(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Test")
        updated = store.update(todo_id=item.id, user_id=1, effort="epic")
        assert updated is not None
        assert updated.effort == "epic"

    def test_update_tags(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Test")
        updated = store.update(todo_id=item.id, user_id=1, tags=["work", "urgent"])
        assert updated is not None
        assert updated.tags == ["work", "urgent"]

    def test_update_description(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Test")
        updated = store.update(
            todo_id=item.id, user_id=1, description="New description"
        )
        assert updated is not None
        assert updated.description == "New description"

    def test_update_bumps_updated_at(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Test")
        import time

        time.sleep(0.01)
        updated = store.update(todo_id=item.id, user_id=1, title="Changed")
        assert updated is not None
        assert updated.updated_at >= item.updated_at

    def test_update_nonexistent(self, store: TodoStore) -> None:
        result = store.update(todo_id=999, user_id=1, title="Nope")
        assert result is None

    def test_update_wrong_user(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Test")
        result = store.update(todo_id=item.id, user_id=2, title="Nope")
        assert result is None

    def test_update_invalid_status(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Test")
        with pytest.raises(ValueError, match="status"):
            store.update(todo_id=item.id, user_id=1, status="invalid")

    def test_update_invalid_effort(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Test")
        with pytest.raises(ValueError, match="effort"):
            store.update(todo_id=item.id, user_id=1, effort="invalid")


class TestTodoRemove:
    """Tests for removing todos."""

    def test_remove_existing(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Test")
        assert store.remove(todo_id=item.id, user_id=1) is True
        assert store.get(todo_id=item.id, user_id=1) is None

    def test_remove_nonexistent(self, store: TodoStore) -> None:
        assert store.remove(todo_id=999, user_id=1) is False

    def test_remove_wrong_user(self, store: TodoStore) -> None:
        item = store.add(user_id=1, title="Test")
        assert store.remove(todo_id=item.id, user_id=2) is False
        # Item should still exist for user 1
        assert store.get(todo_id=item.id, user_id=1) is not None


class TestTodoStats:
    """Tests for todo statistics."""

    def test_stats_empty(self, store: TodoStore) -> None:
        stats = store.stats(user_id=1)
        assert stats == {"todo": 0, "in_progress": 0, "done": 0, "total": 0}

    def test_stats_counts(self, store: TodoStore) -> None:
        store.add(user_id=1, title="Task 1")
        store.add(user_id=1, title="Task 2")
        item3 = store.add(user_id=1, title="Task 3")
        store.update(todo_id=item3.id, user_id=1, status="in_progress")
        item4 = store.add(user_id=1, title="Task 4")
        store.update(todo_id=item4.id, user_id=1, status="done")
        stats = store.stats(user_id=1)
        assert stats == {"todo": 2, "in_progress": 1, "done": 1, "total": 4}

    def test_stats_per_user(self, store: TodoStore) -> None:
        store.add(user_id=1, title="User 1")
        store.add(user_id=2, title="User 2")
        store.add(user_id=2, title="User 2b")
        stats1 = store.stats(user_id=1)
        stats2 = store.stats(user_id=2)
        assert stats1["total"] == 1
        assert stats2["total"] == 2
