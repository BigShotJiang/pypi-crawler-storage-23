"""Prompt metadata for the system prompt."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date, datetime, timezone
from pathlib import Path


def get_install_time() -> datetime:
    """Get the time folderbot was last installed/upgraded.

    Uses the modification time of the package directory, which is updated
    on every ``pip install``.
    """
    import folderbot

    pkg_path = Path(folderbot.__file__).parent
    return datetime.fromtimestamp(pkg_path.stat().st_mtime, tz=timezone.utc)


@dataclass(frozen=True)
class PromptMetadata:
    """All dynamic metadata injected into the system prompt template."""

    current_date: str
    version: str
    last_upgraded: str
    user_name: str
    confirmation_tools_section: str

    @classmethod
    def build(
        cls,
        user_name: str,
        confirmation_tools: list[str],
    ) -> PromptMetadata:
        """Construct metadata from current state."""
        from . import __version__

        confirmation_section = ""
        if confirmation_tools:
            tools_list = ", ".join(confirmation_tools)
            confirmation_section = (
                f"- EXCEPTION: Before using these tools, use ask_user with "
                f'input_type="confirm" to get user confirmation: {tools_list}\n'
            )

        install_time = get_install_time()

        return cls(
            current_date=date.today().strftime("%A, %B %d, %Y"),
            version=__version__,
            last_upgraded=install_time.strftime("%B %d, %Y at %H:%M UTC"),
            user_name=user_name,
            confirmation_tools_section=confirmation_section,
        )

    def format_dict(self) -> dict[str, str]:
        """Return a dict suitable for ``template.format(**meta.format_dict())``."""
        return asdict(self)  # type: ignore[return-value]
