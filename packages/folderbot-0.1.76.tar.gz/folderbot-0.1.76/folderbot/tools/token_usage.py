"""Token usage reporting tool."""

from datetime import datetime, timedelta

from pydantic import BaseModel, Field

from ..bot import BotContext
from .base import ToolResult
from .registry import folder_bot


class GetTokenUsageRequest(BaseModel, frozen=True):
    """Request to get token usage summary."""

    period: str = Field(
        default="week",
        description="Time period: 'today', 'week', or 'month'.",
    )


def _period_to_since(period: str) -> str:
    """Convert a period name to an ISO datetime string."""
    now = datetime.now()
    if period == "today":
        since = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "month":
        since = now - timedelta(days=30)
    else:  # default to week
        since = now - timedelta(days=7)
    return since.isoformat()


@folder_bot.tool(
    name="get_token_usage",
    request_type=GetTokenUsageRequest,
    response_type=ToolResult,
)
async def get_token_usage(
    request: GetTokenUsageRequest, context: BotContext | None = None
) -> ToolResult:
    """Get a summary of token usage for the current user.

    Shows total input and output tokens consumed over the requested
    time period. Use this when the user asks about their API usage,
    cost, or consumption.
    """
    if context is None:
        return ToolResult(content="Token usage not available.", is_error=True)

    session_manager = context.services.get("session")
    if session_manager is None:
        return ToolResult(content="Token usage not available.", is_error=True)

    since = _period_to_since(request.period)
    records = session_manager.get_token_usage(user_id=context.user_id, since=since)

    if not records:
        return ToolResult(
            content=f"No token usage recorded for the last {request.period}."
        )

    total_input = sum(r.input_tokens for r in records)
    total_output = sum(r.output_tokens for r in records)
    total = total_input + total_output

    lines = [
        f"Token usage ({request.period}):",
        f"  Input tokens:  {total_input:,}",
        f"  Output tokens: {total_output:,}",
        f"  Total tokens:  {total:,}",
        f"  API calls:     {len(records)}",
    ]
    return ToolResult(content="\n".join(lines))
