"""Calendar event management tools."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import BaseModel, Field

from ..calendar_store import CalendarStore
from .base import ToolResult
from .registry import folder_bot

if TYPE_CHECKING:
    from ..bot import BotContext
    from ..calendar_store import CalendarEvent


def _get_store(context: BotContext | None) -> CalendarStore | None:
    """Extract CalendarStore from context services."""
    if context is None:
        return None
    return context.services.get("calendar")


def _format_event(event: CalendarEvent) -> str:
    """Format a single event for display."""
    status_icons = {
        "scheduled": "\U0001f4c5",
        "cancelled": "\u274c",
        "completed": "\u2705",
    }
    icon = status_icons.get(event.status, "\U0001f4c5")
    parts = [f"{icon} #{event.id} {event.title}"]

    # Time info
    start = event.start_time[:16].replace("T", " ")
    end = event.end_time[:16].replace("T", " ")
    parts.append(f"    {start} \u2192 {end}")

    if event.description:
        parts.append(f"    {event.description}")

    details: list[str] = []
    if event.location:
        details.append(f"location: {event.location}")
    if event.tags:
        details.append(f"tags: {', '.join(event.tags)}")
    if event.recurrence:
        details.append(f"repeats: {event.recurrence}")
    if event.reminders:
        details.append(f"reminders: {', '.join(event.reminders)}")
    if event.status != "scheduled":
        details.append(f"status: {event.status}")
    if details:
        parts.append(f"    ({'; '.join(details)})")
    return "\n".join(parts)


# --- Request Models ---


class AddEventRequest(BaseModel, frozen=True):
    """Request to add a new calendar event."""

    title: str = Field(description="Event title")
    start_time: str = Field(
        description="Start time in ISO 8601 format (e.g. 2026-02-20T14:00:00+00:00)"
    )
    end_time: str = Field(
        description="End time in ISO 8601 format (e.g. 2026-02-20T15:00:00+00:00)"
    )
    description: str = Field(default="", description="Event description")
    location: str = Field(default="", description="Event location")
    tags: list[str] = Field(
        default_factory=list,
        description="Tags for categorization (e.g. work, personal, meeting)",
    )
    reminders: list[str] = Field(
        default_factory=list,
        description="Reminders: '15m_before', '1h_before', '1d_before', 'at_event'",
    )
    recurrence: str = Field(
        default="",
        description="Recurrence: '', 'daily', 'weekly', 'monthly', 'yearly'",
    )


class ListEventsRequest(BaseModel, frozen=True):
    """Request to list calendar events with optional filters."""

    days_ahead: int = Field(
        default=30,
        description="Number of days ahead to look (default 30)",
    )
    tag: str | None = Field(default=None, description="Filter by tag")
    search: str | None = Field(
        default=None, description="Search in title and description"
    )
    include_cancelled: bool = Field(
        default=False, description="Include cancelled events"
    )


class UpcomingEventsRequest(BaseModel, frozen=True):
    """Request for upcoming events."""

    days_ahead: int = Field(default=7, description="Number of days ahead (default 7)")
    limit: int = Field(default=10, description="Maximum number of events to return")


class UpdateEventRequest(BaseModel, frozen=True):
    """Request to update an existing event."""

    event_id: int = Field(description="ID of the event to update")
    title: str | None = Field(default=None, description="New title")
    description: str | None = Field(default=None, description="New description")
    start_time: str | None = Field(
        default=None, description="New start time (ISO 8601)"
    )
    end_time: str | None = Field(default=None, description="New end time (ISO 8601)")
    location: str | None = Field(default=None, description="New location")
    tags: list[str] | None = Field(default=None, description="New tags list")
    reminders: list[str] | None = Field(default=None, description="New reminders list")
    status: str | None = Field(
        default=None,
        description="New status: 'scheduled', 'cancelled', 'completed'",
    )
    recurrence: str | None = Field(default=None, description="New recurrence pattern")


class DeleteEventRequest(BaseModel, frozen=True):
    """Request to delete a calendar event."""

    event_id: int = Field(description="ID of the event to delete")


# --- Tool Functions ---


@folder_bot.tool(
    name="calendar_add",
    request_type=AddEventRequest,
    response_type=ToolResult,
)
async def calendar_add(
    request: AddEventRequest, _context: BotContext | None = None
) -> ToolResult:
    """Add a new calendar event.

    Use this when the user wants to schedule a meeting, appointment,
    reminder, or any time-based event. Parse natural language dates
    into ISO 8601 format.
    """
    store = _get_store(_context)
    if store is None:
        return ToolResult(
            content="Calendar not available: service not configured.",
            is_error=True,
        )
    try:
        event = store.add(
            user_id=_context.user_id if _context else 0,
            title=request.title,
            start_time=request.start_time,
            end_time=request.end_time,
            description=request.description,
            location=request.location,
            tags=request.tags if request.tags else None,
            reminders=request.reminders if request.reminders else None,
            recurrence=request.recurrence,
        )
        return ToolResult(content=f"Added event #{event.id}:\n{_format_event(event)}")
    except ValueError as e:
        return ToolResult(content=f"Error adding event: {e}", is_error=True)


@folder_bot.tool(
    name="calendar_list",
    request_type=ListEventsRequest,
    response_type=ToolResult,
)
async def calendar_list(
    request: ListEventsRequest, _context: BotContext | None = None
) -> ToolResult:
    """List calendar events with optional filters.

    Use this to show the user's schedule. Supports filtering by tag,
    text search, and date range. By default shows next 30 days.
    """
    store = _get_store(_context)
    if store is None:
        return ToolResult(
            content="Calendar not available: service not configured.",
            is_error=True,
        )
    user_id = _context.user_id if _context else 0
    events = store.list_events(
        user_id=user_id,
        tag=request.tag,
        search=request.search,
        include_cancelled=request.include_cancelled,
    )
    if not events:
        return ToolResult(content="No events found.")

    formatted = "\n\n".join(_format_event(e) for e in events)
    stats = store.stats(user_id)
    summary = (
        f"--- {stats['scheduled']} scheduled, "
        f"{stats['completed']} completed, "
        f"{stats['cancelled']} cancelled "
        f"({stats['total']} total) ---"
    )
    return ToolResult(content=f"{formatted}\n\n{summary}")


@folder_bot.tool(
    name="calendar_upcoming",
    request_type=UpcomingEventsRequest,
    response_type=ToolResult,
)
async def calendar_upcoming(
    request: UpcomingEventsRequest, _context: BotContext | None = None
) -> ToolResult:
    """Show upcoming events in the near future.

    Use this for "what's coming up?", "what's on my calendar?",
    or "what do I have this week?" type queries.
    """
    store = _get_store(_context)
    if store is None:
        return ToolResult(
            content="Calendar not available: service not configured.",
            is_error=True,
        )
    events = store.upcoming(
        user_id=_context.user_id if _context else 0,
        days_ahead=request.days_ahead,
        limit=request.limit,
    )
    if not events:
        return ToolResult(
            content=f"No upcoming events in the next {request.days_ahead} days."
        )

    formatted = "\n\n".join(_format_event(e) for e in events)
    return ToolResult(content=f"Upcoming events ({len(events)}):\n\n{formatted}")


@folder_bot.tool(
    name="calendar_update",
    request_type=UpdateEventRequest,
    response_type=ToolResult,
)
async def calendar_update(
    request: UpdateEventRequest, _context: BotContext | None = None
) -> ToolResult:
    """Update an existing calendar event.

    Use this to reschedule, change details, or mark events as
    completed or cancelled.
    """
    store = _get_store(_context)
    if store is None:
        return ToolResult(
            content="Calendar not available: service not configured.",
            is_error=True,
        )
    try:
        updated = store.update(
            event_id=request.event_id,
            user_id=_context.user_id if _context else 0,
            title=request.title,
            description=request.description,
            start_time=request.start_time,
            end_time=request.end_time,
            location=request.location,
            tags=request.tags,
            reminders=request.reminders,
            status=request.status,
            recurrence=request.recurrence,
        )
    except ValueError as e:
        return ToolResult(content=f"Error updating event: {e}", is_error=True)

    if updated is None:
        return ToolResult(
            content=f"Event #{request.event_id} not found.", is_error=True
        )
    return ToolResult(content=f"Updated event #{updated.id}:\n{_format_event(updated)}")


@folder_bot.tool(
    name="calendar_delete",
    request_type=DeleteEventRequest,
    response_type=ToolResult,
)
async def calendar_delete(
    request: DeleteEventRequest, _context: BotContext | None = None
) -> ToolResult:
    """Delete a calendar event permanently.

    Use this when the user wants to remove an event entirely.
    Consider using calendar_update with status='cancelled' instead
    if the user just wants to cancel it.
    """
    store = _get_store(_context)
    if store is None:
        return ToolResult(
            content="Calendar not available: service not configured.",
            is_error=True,
        )
    removed = store.remove(
        event_id=request.event_id,
        user_id=_context.user_id if _context else 0,
    )
    if not removed:
        return ToolResult(
            content=f"Event #{request.event_id} not found.", is_error=True
        )
    return ToolResult(content=f"Deleted event #{request.event_id}.")
