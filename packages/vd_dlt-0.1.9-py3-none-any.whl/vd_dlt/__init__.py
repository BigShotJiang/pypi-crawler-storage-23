"""
vd-dlt: Core DLT Ingestion Framework

Provides:
- Config resolution (4-level hierarchy)
- Credential resolution (Key Vault integration)
- Pipeline execution
- Observability (logging, sync history)
- Schema validation
"""

__version__ = "0.1.1"

from .config_resolver import ConfigResolver, resolve_resource_config
from .credential_resolver import CredentialResolver, resolve_credentials
from .pipeline_runner import PipelineRunner, run_source
from .observability import setup_logging, SyncHistoryTracker, SyncRecord, ResourceResult
from .schema_validator import ValidationError, validate_all

__all__ = [
    "ConfigResolver",
    "resolve_resource_config",
    "CredentialResolver",
    "resolve_credentials",
    "PipelineRunner",
    "run_source",
    "setup_logging",
    "SyncHistoryTracker",
    "SyncRecord",
    "ResourceResult",
    "ValidationError",
    "validate_all",
]
