"""
Familiar v1.3.0 — Integration Test Suite
=========================================
Tests the full agent stack end-to-end using mocked LLM providers.
No real API keys or running services required.

Run with:
    pytest tests/test_integration.py -v

Coverage:
    - Agent instantiation and config loading
    - Basic chat (non-streaming)
    - Streaming chat with event collection
    - Tool call round-trip (tool use → tool result → final response)
    - Budget enforcement with real token-based cost
    - Provider exception wrapping and error propagation
    - Retry logic on transient failures
    - Provider alias resolution
    - OllamaProvider.supports_tools model matching
    - calculate_cost correctness for known models
    - Session isolation between users
    - Conversation history persistence within a session
    - RetryableOperation trace None-guard (regression: trace.add_span without guard)
    - Stream generator GeneratorExit cleanup (regression: span leak on abandon)
    - capture_output subprocess errors surface stderr (regression: silent swallow)
"""

import json
import os
import subprocess
import sys
from pathlib import Path
from unittest.mock import MagicMock, PropertyMock, patch

import pytest

# Ensure project root on path
sys.path.insert(0, str(Path(__file__).parent.parent))

from familiar.core.config import load_config
from familiar.core.exceptions import (
    ProviderAuthenticationError,
    ProviderConnectionError,
    ProviderError,
    ProviderRateLimitError,
)
from familiar.core.observability import calculate_cost
from familiar.core.providers import (
    PROVIDER_ALIASES,
    PROVIDERS,
    LLMProvider,
    LLMResponse,
    OllamaProvider,
    StreamEvent,
    StreamEventType,
    ToolCall,
    get_provider,
)
from familiar.core.resilience import RetryableOperation, RetryConfig

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def isolate_sessions(tmp_path, monkeypatch):
    """Redirect session storage to a temp directory so tests never touch
    the real ~/.familiar/data/sessions/ directory.

    This also prevents budget-exhaustion pollution between tests —
    each test starts with a fresh, empty sessions directory.
    """
    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir()
    monkeypatch.setattr("familiar.core.security.SESSIONS_DIR", sessions_dir)
    return sessions_dir


@pytest.fixture
def config():
    """Default config with safe test values."""
    cfg = load_config()
    # Ensure no real API calls slip through
    cfg.llm.default_provider = "ollama"
    cfg.agent.memory_enabled = False
    cfg.agent.scheduler_enabled = False
    return cfg


@pytest.fixture
def mock_provider():
    """A mock LLMProvider with sensible defaults."""
    p = MagicMock(spec=LLMProvider)
    p.name = "MockProvider"
    p.model_name = "mock-model"
    p.supports_tools = True
    p.supports_streaming = False
    p.chat.return_value = LLMResponse(
        text="Test response",
        tool_calls=[],
        stop_reason="end_turn",
        usage={"input_tokens": 10, "output_tokens": 8},
    )
    return p


@pytest.fixture
def agent(config, mock_provider):
    """An Agent wired to the mock provider."""
    from familiar.core.agent import Agent

    with (
        patch("familiar.core.agent.get_provider", return_value=mock_provider),
        patch("familiar.core.agent.get_best_ollama_model", return_value=None),
    ):
        a = Agent(config=config)
        a.provider = mock_provider
        yield a


# ---------------------------------------------------------------------------
# 1. Agent instantiation
# ---------------------------------------------------------------------------


class TestAgentInstantiation:
    def test_agent_creates_with_default_config(self, config, mock_provider):
        from familiar.core.agent import Agent

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            agent = Agent(config=config)
        assert agent is not None
        assert agent.config is config

    def test_agent_has_tool_registry(self, agent):
        assert agent.tools is not None

    def test_agent_has_session_manager(self, agent):
        assert agent.sessions is not None

    def test_agent_has_history(self, agent):
        assert agent.history is not None

    def test_agent_memory_disabled_when_configured(self, config, mock_provider):
        from familiar.core.agent import Agent

        config.agent.memory_enabled = False
        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            agent = Agent(config=config)
        assert agent.memory is None


# ---------------------------------------------------------------------------
# 2. Basic chat (non-streaming)
# ---------------------------------------------------------------------------


class TestBasicChat:
    def test_chat_returns_string(self, agent, mock_provider):
        mock_provider.chat.return_value = LLMResponse(
            text="Hello there!",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 5, "output_tokens": 3},
        )
        result = agent.chat("Hi", user_id="user1")
        assert isinstance(result, str)
        assert result == "Hello there!"

    def test_chat_calls_provider_once(self, agent, mock_provider):
        agent.chat("Hello?", user_id="user1")
        assert mock_provider.chat.call_count == 1

    def test_chat_passes_message_in_history(self, agent, mock_provider):
        agent.chat("What is 2+2?", user_id="user1")
        call_args = mock_provider.chat.call_args
        messages = call_args.kwargs.get("messages") or call_args.args[0]
        user_messages = [m for m in messages if m["role"] == "user"]
        assert any("2+2" in str(m["content"]) for m in user_messages)

    def test_chat_different_users_isolated(self, agent, mock_provider):
        mock_provider.chat.return_value = LLMResponse(
            text="Response",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 5, "output_tokens": 3},
        )
        r1 = agent.chat("Hello from user1", user_id="user1")
        r2 = agent.chat("Hello from user2", user_id="user2")
        assert r1 == r2 == "Response"
        # Both calls went through
        assert mock_provider.chat.call_count == 2

    def test_chat_none_response_text_returns_fallback(self, agent, mock_provider):
        mock_provider.chat.return_value = LLMResponse(
            text=None,
            tool_calls=[],
            stop_reason="end_turn",
            usage=None,
        )
        result = agent.chat("Hello", user_id="user1")
        assert isinstance(result, str)
        # Should not raise; agent handles None text gracefully
        assert result is not None


# ---------------------------------------------------------------------------
# 3. Streaming chat
# ---------------------------------------------------------------------------


class TestStreamingChat:
    def _make_stream_provider(self, text="Hello world!"):
        """Return a mock provider whose chat_stream yields TEXT events."""
        p = MagicMock(spec=LLMProvider)
        p.name = "MockStream"
        p.model_name = "mock-model"
        p.supports_tools = False
        p.supports_streaming = True

        response = LLMResponse(
            text=text,
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 5, "output_tokens": 4},
        )

        def _stream(*args, **kwargs):
            for word in text.split():
                yield StreamEvent(type=StreamEventType.TEXT, content=word + " ")
            yield StreamEvent(type=StreamEventType.DONE, usage=response.usage)
            return response

        p.chat_stream = _stream
        return p

    def test_stream_yields_text_events(self, config):
        from familiar.core.agent import Agent

        provider = self._make_stream_provider("Streaming works fine")
        with patch("familiar.core.agent.get_provider", return_value=provider):
            agent = Agent(config=config)
            agent.provider = provider

            text_chunks = []
            for event in agent.chat_stream("Hello", user_id="stream_user1"):
                if event.type == StreamEventType.TEXT:
                    text_chunks.append(event.content)

        assert len(text_chunks) > 0
        full = "".join(text_chunks)
        assert "Streaming" in full
        assert "works" in full

    def test_stream_ends_with_done_event(self, config):
        from familiar.core.agent import Agent

        provider = self._make_stream_provider("Done signal test")
        with patch("familiar.core.agent.get_provider", return_value=provider):
            agent = Agent(config=config)
            agent.provider = provider

            events = list(agent.chat_stream("Hello", user_id="stream_user2"))
        done_events = [e for e in events if e.type == StreamEventType.DONE]
        assert len(done_events) >= 1

    def test_stream_no_error_events_on_success(self, config):
        from familiar.core.agent import Agent

        provider = self._make_stream_provider("Clean run")
        with patch("familiar.core.agent.get_provider", return_value=provider):
            agent = Agent(config=config)
            agent.provider = provider

            events = list(agent.chat_stream("Hello", user_id="stream_user3"))
        error_events = [e for e in events if e.type == StreamEventType.ERROR]
        assert len(error_events) == 0


# ---------------------------------------------------------------------------
# 4. Tool call round-trip
# ---------------------------------------------------------------------------


class TestToolCallRoundTrip:
    def test_single_tool_call_then_response(self, config, mock_provider):
        from familiar.core.agent import Agent

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            # First: model requests a tool
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 20, "output_tokens": 10},
            ),
            # Second: model uses tool result to respond
            LLMResponse(
                text="It is 3:14 PM.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 35, "output_tokens": 10},
            ),
        ]

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            agent = Agent(config=config)
            agent.provider = mock_provider

            result = agent.chat("What time is it?", user_id="tool_rt_user1")
        assert "3:14" in result
        assert mock_provider.chat.call_count == 2

    def test_tool_result_appended_to_history(self, config, mock_provider):
        """Second LLM call should receive tool result in its messages."""
        from familiar.core.agent import Agent

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc2", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 20, "output_tokens": 10},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 40, "output_tokens": 5},
            ),
        ]

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            agent = Agent(config=config)
            agent.provider = mock_provider

            agent.chat("Use a tool please", user_id="tool_rt_user2")

        # Second call's message history should include a tool result
        second_call_msgs = mock_provider.chat.call_args_list[1]
        messages = second_call_msgs.kwargs.get("messages") or second_call_msgs.args[0]
        # Tool result appears as user message with tool_result content
        tool_result_msgs = [
            m
            for m in messages
            if m["role"] == "user"
            and isinstance(m.get("content"), list)
            and any(isinstance(c, dict) and c.get("type") == "tool_result" for c in m["content"])
        ]
        assert len(tool_result_msgs) >= 1


# ---------------------------------------------------------------------------
# 5. Budget enforcement
# ---------------------------------------------------------------------------


class TestBudgetEnforcement:
    def test_real_cost_charged_not_stub(self, config, mock_provider):
        """Verifies actual token cost is used, not the old $0.01 flat rate."""
        from familiar.core.agent import Agent

        type(mock_provider).model_name = PropertyMock(return_value="claude-sonnet-4-6")
        mock_provider.chat.return_value = LLMResponse(
            text="Hi",
            tool_calls=[],
            stop_reason="end_turn",
            # 1000 input + 500 output tokens at Claude Sonnet pricing
            usage={"input_tokens": 1000, "output_tokens": 500},
        )

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            agent = Agent(config=config)
            agent.provider = mock_provider

            # Use "default" channel — matches agent.chat()'s default
            session = agent.sessions.get_or_create_session("budget_user", "default")
            initial_budget = session.remaining_budget

            agent.chat("Hello", user_id="budget_user")

        # Same object — charge mutates it in place
        spent = initial_budget - session.remaining_budget

        # Real cost for 1000 in + 500 out at Sonnet pricing is ~$0.0045-$0.015
        # The old stub was EXACTLY $0.01 — verify we're using token-based math:
        # If calculate_cost returns 0 for an unknown model, the floor kicks in at $0.005
        # If it returns a real value, it should correlate with token counts
        assert spent > 0, "No cost was charged"
        # The old stub charged regardless of model — real calc returns 0 for unknown models
        # and uses the floor. So we just verify cost is non-zero and plausible.
        assert spent < 1.0, f"Cost ${spent:.4f} is implausibly large"
        assert spent != pytest.approx(0.01, abs=1e-6), (
            "Cost is exactly $0.01 — old hardcoded stub may still be active"
        )

    def test_ollama_floor_charged_when_no_usage(self, config, mock_provider):
        """Ollama (no usage reporting) should charge the $0.005 floor."""
        from familiar.core.agent import Agent

        type(mock_provider).model_name = PropertyMock(return_value="llama3.2")
        mock_provider.chat.return_value = LLMResponse(
            text="Hi",
            tool_calls=[],
            stop_reason="end_turn",
            usage=None,  # Ollama doesn't report usage
        )

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            agent = Agent(config=config)
            agent.provider = mock_provider

            session = agent.sessions.get_or_create_session("ollama_user", "default")
            initial = session.remaining_budget

            agent.chat("Hello", user_id="ollama_user")

        spent = initial - session.remaining_budget

        assert spent == pytest.approx(0.005, abs=0.0001), (
            f"Expected $0.005 Ollama floor, got ${spent:.6f}"
        )

    def test_budget_exhausted_stops_agent(self, config, mock_provider):
        """Agent should return budget message when session is exhausted."""
        from familiar.core.agent import Agent

        mock_provider.chat.return_value = LLMResponse(
            text="I should not be returned",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 1000000, "output_tokens": 1000000},
        )

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            agent = Agent(config=config)
            agent.provider = mock_provider

            # Drain the budget manually using the right channel key
            session = agent.sessions.get_or_create_session("broke_user", "default")
            session.charge(session.remaining_budget)  # drain to zero

            # Agent raises BudgetExceededError from _setup_request, or returns error string
            from familiar.core.exceptions import BudgetExceededError

            try:
                result = agent.chat("Hello", user_id="broke_user")
                assert "budget" in result.lower() or "limit" in result.lower(), (
                    f"Expected budget message, got: {result!r}"
                )
            except BudgetExceededError:
                pass  # Also valid — pre-flight guard raises before agent loop


# ---------------------------------------------------------------------------
# 6. Provider error handling
# ---------------------------------------------------------------------------


class TestProviderErrors:
    def test_auth_error_wrapped(self):
        """Authentication errors should be wrapped as ProviderAuthenticationError."""
        from familiar.core.providers import _wrap_provider_error

        raw = Exception("401 invalid api key")
        wrapped = _wrap_provider_error(raw, "Anthropic")
        assert isinstance(wrapped, ProviderAuthenticationError)
        assert wrapped.provider_name == "Anthropic"

    def test_rate_limit_error_wrapped(self):
        from familiar.core.providers import _wrap_provider_error

        raw = Exception("429 too many requests")
        wrapped = _wrap_provider_error(raw, "OpenAI")
        assert isinstance(wrapped, ProviderRateLimitError)

    def test_connection_error_wrapped(self):
        from familiar.core.providers import _wrap_provider_error

        raw = Exception("connection timeout")
        wrapped = _wrap_provider_error(raw, "Ollama")
        assert isinstance(wrapped, ProviderConnectionError)

    def test_secrets_masked_in_error(self):
        """API keys in error messages should be masked."""
        from familiar.core.providers import _wrap_provider_error

        raw = Exception("invalid key sk-ant-api03-abc123secretXYZ for request")
        wrapped = _wrap_provider_error(raw, "Anthropic")
        assert "abc123secretXYZ" not in str(wrapped)
        assert wrapped.provider_name == "Anthropic"

    def test_provider_error_propagates_from_agent(self, config, mock_provider):
        """Provider errors should propagate out of agent.chat() or return error string."""
        from familiar.core.agent import Agent

        mock_provider.chat.side_effect = ProviderConnectionError(
            "Connection refused", provider_name="MockProvider"
        )

        with (
            patch("familiar.core.agent.get_provider", return_value=mock_provider),
            patch("familiar.core.agent.get_best_ollama_model", return_value=None),
        ):
            agent = Agent(config=config)
            agent.provider = mock_provider

            # Agent may return an error message string or raise — both are acceptable
            try:
                result = agent.chat("Hello", user_id="err_user")
                assert isinstance(result, str)
            except (ProviderError, ProviderConnectionError):
                pass  # Raising is also acceptable


# ---------------------------------------------------------------------------
# 7. Retry logic
# ---------------------------------------------------------------------------


class TestRetryLogic:
    def test_retry_on_transient_failure(self, config, mock_provider):
        """RetryableOperation retries on transient failures and succeeds."""
        from familiar.core.resilience import RetryableOperation, RetryConfig

        # Test the retry mechanism directly — the agent wraps provider calls
        # once and reports errors, but RetryableOperation itself handles retries.
        call_count = 0
        retry_config = RetryConfig(max_attempts=3, base_delay=0.0, max_delay=0.0, jitter=False)

        def operation_that_succeeds_on_third_try():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ProviderRateLimitError("Rate limit exceeded", provider_name="MockProvider")
            return "Success after retries"

        result = None
        with RetryableOperation(trace=None, name="test_retry", config=retry_config) as op:
            for attempt in op.attempts():
                with attempt:
                    result = operation_that_succeeds_on_third_try()

        assert result == "Success after retries", f"Got: {result!r}"
        assert call_count == 3, f"Expected 3 calls, got {call_count}"

    def test_retryable_operation_last_error_set(self):
        """RetryableOperation should always set last_error on failure."""
        config = RetryConfig(max_attempts=2, base_delay=0.01, jitter=False)
        op = RetryableOperation(trace=None, name="test_op", config=config)

        sentinel = ValueError("test failure")
        try:
            with op:
                for attempt in op.attempts():
                    with attempt:
                        raise sentinel
        except ValueError:
            pass

        assert op.last_error is sentinel

    def test_retryable_operation_no_trace_guard(self):
        """AttemptContext.__exit__ must not crash when trace is None."""
        config_r = RetryConfig(max_attempts=1, base_delay=0.0, jitter=False)
        op = RetryableOperation(trace=None, name="no_trace_op", config=config_r)

        try:
            with op:
                for attempt in op.attempts():
                    with attempt:
                        raise RuntimeError("boom")
        except RuntimeError:
            pass
        # If we reach here without AttributeError, the None guard is working


# ---------------------------------------------------------------------------
# 8. Provider alias resolution
# ---------------------------------------------------------------------------


class TestProviderAliases:
    def test_claude_resolves_to_anthropic(self, config):
        with patch("familiar.core.providers.AnthropicProvider") as MockA:
            MockA.return_value = MagicMock(spec=LLMProvider)
            try:
                get_provider("claude", config)
            except Exception:
                pass
            MockA.assert_called()

    def test_gpt_resolves_to_openai(self, config):
        with patch("familiar.core.providers.OpenAIProvider") as MockO:
            MockO.return_value = MagicMock(spec=LLMProvider)
            try:
                get_provider("gpt", config)
            except Exception:
                pass
            MockO.assert_called()

    def test_llama_resolves_to_ollama(self, config):
        with patch("familiar.core.providers.OllamaProvider") as MockOl:
            MockOl.return_value = MagicMock(spec=LLMProvider)
            try:
                get_provider("llama", config)
            except Exception:
                pass
            MockOl.assert_called()

    def test_unknown_provider_raises(self, config):
        with pytest.raises(ValueError, match="Unknown provider"):
            get_provider("nonexistent_llm", config)

    def test_all_aliases_resolve_without_error(self, config):
        """Every entry in PROVIDER_ALIASES should resolve to a key in PROVIDERS."""
        for alias, canonical in PROVIDER_ALIASES.items():
            assert canonical in PROVIDERS, f"Alias '{alias}' → '{canonical}' not found in PROVIDERS"


# ---------------------------------------------------------------------------
# 9. OllamaProvider.supports_tools model matching
# ---------------------------------------------------------------------------


class TestOllamaSupportsTools:
    @pytest.mark.parametrize(
        "model,expected",
        [
            # Should support tools
            ("llama3.1", True),
            ("llama3.1:8b", True),
            ("llama3.2", True),
            ("llama3.2:latest", True),
            ("llama3.2-instruct", True),
            ("llama3.3", True),
            ("mistral", True),
            ("mistral:7b", True),
            ("mistral-nemo", True),
            ("qwen", True),
            ("qwen2.5:14b", True),
            ("qwen2:7b", True),
            ("deepseek", True),
            ("deepseek-r1:14b", True),
            ("deepseek-v3", True),
            ("qwen3.5:27b", True),
            ("qwen3.5:35b", True),
            ("qwen3.5:122b", True),
            # Should NOT support tools
            ("llama3.10", False),  # regression: would match llama3.1 via substring
            ("llama3.10:8b", False),  # regression: same
            ("llama2", False),
            ("gemma3:1b", False),
            ("gemma2:2b", False),
            ("phi3:mini", False),
            ("smollm2:135m", False),
            ("tinyllama", False),
        ],
    )
    def test_supports_tools(self, model, expected):
        provider = OllamaProvider(model)
        assert provider.supports_tools == expected, (
            f"OllamaProvider('{model}').supports_tools should be {expected}"
        )


# ---------------------------------------------------------------------------
# 10. calculate_cost
# ---------------------------------------------------------------------------


class TestCalculateCost:
    def test_claude_sonnet_cost(self):
        cost = calculate_cost("claude-sonnet-4-6", 1000, 500)
        assert cost > 0, "Claude Sonnet should have non-zero cost"
        # Rough sanity check: not absurdly expensive or zero
        assert 0.0001 < cost < 1.0

    def test_unknown_model_returns_zero(self):
        cost = calculate_cost("completely-unknown-model-xyz", 1000, 500)
        assert cost == 0.0

    def test_zero_tokens_zero_cost(self):
        cost = calculate_cost("claude-sonnet-4-6", 0, 0)
        assert cost == 0.0

    def test_output_costs_more_than_input(self):
        """For all major models, output tokens cost more than input tokens."""
        input_only = calculate_cost("claude-sonnet-4-6", 1000, 0)
        output_only = calculate_cost("claude-sonnet-4-6", 0, 1000)
        if input_only > 0 and output_only > 0:
            assert output_only > input_only, "Output tokens should cost more than input tokens"

    def test_cost_scales_linearly(self):
        """Doubling tokens should double cost."""
        cost1 = calculate_cost("claude-sonnet-4-6", 100, 50)
        cost2 = calculate_cost("claude-sonnet-4-6", 200, 100)
        if cost1 > 0:
            assert cost2 == pytest.approx(cost1 * 2, rel=0.01)


# ---------------------------------------------------------------------------
# 11. Conversation history
# ---------------------------------------------------------------------------


class TestConversationHistory:
    def test_history_accumulates_across_turns(self, agent, mock_provider):
        """Each turn should see prior messages."""
        mock_provider.chat.return_value = LLMResponse(
            text="Response",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 10, "output_tokens": 5},
        )

        agent.chat("First message", user_id="hist_user")
        agent.chat("Second message", user_id="hist_user")
        agent.chat("Third message", user_id="hist_user")

        # Third call's messages should contain all prior turns
        last_call = mock_provider.chat.call_args_list[-1]
        messages = last_call.kwargs.get("messages") or last_call.args[0]
        user_messages = [m for m in messages if m["role"] == "user"]
        # At minimum the third message is present
        assert len(user_messages) >= 1

    def test_history_isolated_between_users(self, agent, mock_provider):
        """User A's history should not appear in user B's calls."""
        mock_provider.chat.return_value = LLMResponse(
            text="OK",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 5, "output_tokens": 3},
        )

        agent.chat("User A secret message XYZ", user_id="user_a")
        mock_provider.chat.reset_mock()
        agent.chat("Hello from B", user_id="user_b")

        call_args = mock_provider.chat.call_args
        messages = call_args.kwargs.get("messages") or call_args.args[0]
        all_content = str(messages)
        assert "XYZ" not in all_content, "User A's history leaked into user B's context"


# ---------------------------------------------------------------------------
# 12. Regression: stream span leak on GeneratorExit
# ---------------------------------------------------------------------------


class TestStreamGeneratorExit:
    def test_generator_exit_does_not_raise(self):
        """Abandoning a stream mid-way should not raise or leave spans open."""

        # We can't test the real Anthropic streaming without a key,
        # so test the generator protocol directly via the base class fallback
        from familiar.core.providers import LLMProvider, StreamEventType

        class MinimalProvider(LLMProvider):
            @property
            def name(self):
                return "Minimal"

            @property
            def model_name(self):
                return "minimal"

            @property
            def supports_tools(self):
                return False

            def chat(self, messages, tools, system, max_tokens=4096, trace=None, retry_config=None):
                return LLMResponse(
                    text="Full response text here",
                    tool_calls=[],
                    stop_reason="end_turn",
                    usage=None,
                )

        provider = MinimalProvider()
        gen = provider.chat_stream(
            messages=[{"role": "user", "content": "hi"}],
            tools=[],
            system="You are helpful.",
        )

        # Take only the first event then abandon
        first = next(gen)
        assert first.type == StreamEventType.TEXT

        # Close the generator — should not raise
        try:
            gen.close()
        except Exception as e:
            pytest.fail(f"gen.close() raised: {e}")

    def test_openai_stream_span_finish_on_generatorexit(self):
        """chat_stream GeneratorExit path must not leak open spans."""
        # We test the protocol via a concrete subclass without a real API client.
        # The key invariant: if a caller does gen.close(), no exception escapes.
        from familiar.core.providers import LLMProvider, LLMResponse, StreamEventType

        class PatchedStreamProvider(LLMProvider):
            """Minimal provider whose chat_stream yields then stops."""

            @property
            def name(self):
                return "Patched"

            @property
            def model_name(self):
                return "patched"

            @property
            def supports_tools(self):
                return False

            def chat(self, messages, tools, system, max_tokens=4096, trace=None, retry_config=None):
                return LLMResponse(
                    text="full text",
                    tool_calls=[],
                    stop_reason="end_turn",
                    usage=None,
                )

        p = PatchedStreamProvider()
        gen = p.chat_stream(
            messages=[{"role": "user", "content": "hi"}],
            tools=[],
            system="test",
        )

        # Consume first event
        event = next(gen)
        assert event.type == StreamEventType.TEXT

        # Abandon the generator — GeneratorExit must not propagate
        try:
            gen.close()
        except Exception as e:
            pytest.fail(f"gen.close() raised unexpectedly: {type(e).__name__}: {e}")


# ---------------------------------------------------------------------------
# 13. Regression: subprocess stderr surfaced
# ---------------------------------------------------------------------------


class TestSubprocessErrorVisibility:
    def test_failed_subprocess_stderr_accessible(self):
        """Subprocess failures should surface stderr, not swallow it."""
        result = subprocess.run(
            ["python3", "-c", "import sys; sys.exit(1)"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        # The pattern we enforced: returncode check + stderr available
        assert result.returncode != 0
        # stderr is bytes and accessible (even if empty here)
        assert isinstance(result.stderr, bytes)

    def test_pip_failure_stderr_not_empty(self):
        """A pip install of a nonexistent package should give useful stderr."""
        result = subprocess.run(
            ["python3", "-m", "pip", "install", "this-package-does-not-exist-xyz-abc-123"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        assert result.returncode != 0
        err_text = result.stderr.decode(errors="replace")
        # pip should give us something useful, not silence
        assert len(err_text) > 0, "pip stderr was empty — error details lost"


# ---------------------------------------------------------------------------
# 14. Config validation smoke test
# ---------------------------------------------------------------------------


class TestConfigLoading:
    def test_default_config_loads(self):
        cfg = load_config()
        assert cfg is not None

    def test_config_has_llm_section(self):
        cfg = load_config()
        assert hasattr(cfg, "llm")
        assert hasattr(cfg.llm, "anthropic_model")
        assert hasattr(cfg.llm, "ollama_model")

    def test_config_has_agent_section(self):
        cfg = load_config()
        assert hasattr(cfg, "agent")
        assert hasattr(cfg.agent, "memory_enabled")

    def test_config_has_resilience_section(self):
        cfg = load_config()
        assert hasattr(cfg, "resilience")


# ---------------------------------------------------------------------------
# ToolRouter Integration (Fix 1)
# ---------------------------------------------------------------------------


class TestToolRouter:
    """ToolRouter wires into agent and reduces context size per message."""

    def test_agent_has_tool_router(self, agent):
        from familiar.core.tool_router import ToolRouter

        assert hasattr(agent, "tool_router")
        assert isinstance(agent.tool_router, ToolRouter)

    def test_router_trims_tools_for_task_message(self, agent):
        """Routing should select fewer tools than the full capability set."""
        from familiar.core.agent import TrustLevel

        session = agent.sessions.get_or_create_session("router_test", "default")
        session.set_trust_level(TrustLevel.TRUSTED)

        all_tools = agent._get_allowed_tools(session, message="")
        routed = agent._get_allowed_tools(session, message="add a task to review the budget")

        # Routing must not return MORE tools than the unfiltered set
        assert len(routed) <= len(all_tools)
        # A set of <=15 (max_tools) should be returned for a clear intent
        assert (
            len(routed)
            <= agent.tool_router.config.max_tools + agent.tool_router.config.fallback_count
        )

    def test_router_top_tool_matches_intent(self, agent):
        """The highest-ranked tool for a task message should be task-related."""
        from familiar.core.agent import TrustLevel

        session = agent.sessions.get_or_create_session("router_intent", "default")
        session.set_trust_level(TrustLevel.TRUSTED)

        routed = agent._get_allowed_tools(session, message="add a task")
        names = [t["name"] for t in routed]
        # At least one task-related tool must appear in top results
        task_tools = {"add_task", "update_task", "list_tasks", "complete_task", "task_briefing"}
        assert bool(task_tools & set(names[:6])), f"No task tool in top 6: {names[:6]}"

    def test_router_no_message_returns_full_set(self, agent):
        """Empty message bypasses routing and returns full capability set."""
        from familiar.core.agent import TrustLevel

        session = agent.sessions.get_or_create_session("router_empty", "default")
        session.set_trust_level(TrustLevel.TRUSTED)

        without_msg = agent._get_allowed_tools(session, message="")
        with_msg = agent._get_allowed_tools(session, message="add a task")

        # Empty message must not produce fewer tools than a routed message
        assert len(without_msg) >= len(with_msg)

    def test_router_schema_scorer_scores_exact_name_match(self, agent):
        """Schema-based scorer gives highest score to exact name-word matches."""
        router = agent.tool_router
        # 'add task' words match 'add_task' name directly
        score = router._score_intent_schema("add_task", "add a task")
        assert score > 0.5, f"Expected score > 0.5, got {score}"

    def test_router_schema_scorer_zero_for_irrelevant(self, agent):
        """Schema scorer returns 0 for a message with no overlapping words."""
        router = agent.tool_router
        # 'gpio' tools should not score for a pure time query
        score = router._score_intent_schema("gpio_read", "what time is it")
        assert score == 0.0, f"Expected 0.0, got {score}"

    def test_router_fallback_still_returns_tools(self, agent):
        """Even a low-confidence message returns at least fallback_count tools."""
        from familiar.core.agent import TrustLevel

        session = agent.sessions.get_or_create_session("router_fallback", "default")
        session.set_trust_level(TrustLevel.TRUSTED)

        # Nonsense input — router falls back to broader set
        routed = agent._get_allowed_tools(session, message="zxqvbm")
        assert len(routed) > 0


# ---------------------------------------------------------------------------
# Capability Audit (Fix 2)
# ---------------------------------------------------------------------------


class TestCapabilityAudit:
    """sessions/encryption/audit require elevated trust after capability fix."""

    def test_sessions_requires_system_control(self):
        from familiar.core.security import SKILL_DIRECTORY_CAPABILITIES, Capability

        caps = SKILL_DIRECTORY_CAPABILITIES["sessions"]
        assert Capability.SYSTEM_CONTROL in caps, (
            "sessions skill must require SYSTEM_CONTROL (exposes revoke_session)"
        )

    def test_encryption_requires_system_control(self):
        from familiar.core.security import SKILL_DIRECTORY_CAPABILITIES, Capability

        caps = SKILL_DIRECTORY_CAPABILITIES["encryption"]
        assert Capability.SYSTEM_CONTROL in caps, (
            "encryption skill must require SYSTEM_CONTROL (exposes rotate_keys, decrypt)"
        )

    def test_audit_requires_read_files(self):
        from familiar.core.security import SKILL_DIRECTORY_CAPABILITIES, Capability

        caps = SKILL_DIRECTORY_CAPABILITIES["audit"]
        assert Capability.READ_FILES in caps, (
            "audit skill must require READ_FILES (exposes export_audit_trail)"
        )

    def test_sessions_not_read_time(self):
        """sessions must NOT still be guarded by the weaker READ_TIME capability."""
        from familiar.core.security import SKILL_DIRECTORY_CAPABILITIES, Capability

        caps = SKILL_DIRECTORY_CAPABILITIES["sessions"]
        assert Capability.READ_TIME not in caps, (
            "sessions was incorrectly set to READ_TIME — any KNOWN user could revoke sessions"
        )

    def test_encryption_not_read_notes(self):
        from familiar.core.security import SKILL_DIRECTORY_CAPABILITIES, Capability

        caps = SKILL_DIRECTORY_CAPABILITIES["encryption"]
        assert Capability.READ_NOTES not in caps

    def test_known_user_cannot_access_sessions_tools(self, agent):
        """KNOWN trust level must not receive revoke_session in their tool set."""
        from familiar.core.agent import TrustLevel

        session = agent.sessions.get_or_create_session("known_cap_test", "default")
        session.set_trust_level(TrustLevel.KNOWN)

        tools = agent._get_allowed_tools(session, message="")
        tool_names = {t["name"] for t in tools}
        restricted = {"revoke_session", "create_session", "encrypt_data_store", "rotate_keys"}
        leaking = restricted & tool_names
        assert not leaking, f"KNOWN user can see elevated tools: {leaking}"


# ---------------------------------------------------------------------------
# Skill Prerequisites (Fix 3)
# ---------------------------------------------------------------------------


class TestSkillPrerequisites:
    """Skills with missing external services warn and skip tool registration."""

    def test_skill_prerequisites_dict_exists(self):
        from familiar.core.skills import SKILL_PREREQUISITES

        assert isinstance(SKILL_PREREQUISITES, dict)
        assert len(SKILL_PREREQUISITES) > 0

    def test_email_has_prerequisites(self):
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "email" in SKILL_PREREQUISITES
        labels = [label for _, label in SKILL_PREREQUISITES["email"]]
        assert any("EMAIL_ADDRESS" in item for item in labels)
        assert any("EMAIL_PASSWORD" in item for item in labels)

    def test_sms_has_twilio_prerequisites(self):
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "sms" in SKILL_PREREQUISITES
        labels = [label for _, label in SKILL_PREREQUISITES["sms"]]
        assert any("TWILIO" in item for item in labels)

    def test_email_tools_not_registered_without_env(self, tmp_path, monkeypatch):
        """Email skill tools must not appear in registry when env vars are absent."""
        from pathlib import Path

        # Clear EMAIL env vars
        monkeypatch.delenv("EMAIL_ADDRESS", raising=False)
        monkeypatch.delenv("EMAIL_PASSWORD", raising=False)

        # Use a fresh ToolRegistry so we don't affect the shared singleton
        from familiar.core.tools import ToolRegistry

        fresh_registry = ToolRegistry()

        from familiar.core.skills import SkillLoader

        loader = SkillLoader([str(Path("familiar/skills"))])
        loader.tool_registry = fresh_registry

        import io
        import logging

        buf = io.StringIO()
        handler = logging.StreamHandler(buf)
        handler.setLevel(logging.WARNING)
        skill_logger = logging.getLogger("familiar.core.skills")
        skill_logger.addHandler(handler)
        original_level = skill_logger.level
        skill_logger.setLevel(logging.WARNING)

        try:
            # Also suppress Gmail OAuth token so the OR-branch doesn't pass
            with patch("familiar.core.skills._gmail_token", return_value=False):
                loader.load_skill(Path("familiar/skills/email"))
        finally:
            skill_logger.removeHandler(handler)
            skill_logger.setLevel(original_level)

        warning_text = buf.getvalue()
        assert "prerequisites not met" in warning_text, (
            "Expected a 'prerequisites not met' warning for email skill"
        )

        # Email tools must NOT be in the fresh registry
        registered_names = {s["name"] for s in fresh_registry.get_schemas()}
        email_tools = {"draft_email", "send_email", "check_inbox", "filter_emails"}
        leaking = email_tools & registered_names
        assert not leaking, f"Email tools registered despite missing env vars: {leaking}"

    def test_skill_without_prerequisites_registers_normally(self):
        """Skills not in SKILL_PREREQUISITES register their tools unconditionally."""
        from pathlib import Path

        from familiar.core.skills import SKILL_PREREQUISITES, SkillLoader
        from familiar.core.tools import ToolRegistry

        # tasks skill has no prerequisites
        assert "tasks" not in SKILL_PREREQUISITES

        fresh_registry = ToolRegistry()
        loader = SkillLoader([str(Path("familiar/skills"))])
        loader.tool_registry = fresh_registry
        loader.load_skill(Path("familiar/skills/tasks"))

        registered = {s["name"] for s in fresh_registry.get_schemas()}
        assert bool(registered), "tasks skill should register tools unconditionally"

    def test_prerequisite_check_fn_called(self):
        """Check functions in SKILL_PREREQUISITES must be callable and return bool."""
        from familiar.core.skills import SKILL_PREREQUISITES

        for skill_name, checks in SKILL_PREREQUISITES.items():
            for check_fn, label in checks:
                assert callable(check_fn), f"{skill_name}: check_fn {label!r} is not callable"
                result = check_fn()
                assert isinstance(result, bool), (
                    f"{skill_name}: check_fn {label!r} returned {type(result)} not bool"
                )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])

# ---------------------------------------------------------------------------
# ToolRouter — schema-based routing
# ---------------------------------------------------------------------------


class TestToolRouterExtended:
    """ToolRouter schema-based intent scoring without TOOLS.yaml guidance."""

    @pytest.fixture
    def router_with_schemas(self):
        from familiar.core.tool_router import RouterConfig, ToolRouter
        from familiar.core.tools import Tool, ToolRegistry

        reg = ToolRegistry()
        # Register a small set of representative tools
        tools = [
            Tool("add_task", "Add a new task or to-do item", {}, lambda x: "ok"),
            Tool("list_tasks", "List all tasks", {}, lambda x: "ok"),
            Tool("web_search", "Search the web for information", {}, lambda x: "ok"),
            Tool("send_email", "Send an email to a recipient", {}, lambda x: "ok"),
            Tool("get_current_time", "Get the current date and time", {}, lambda x: "ok"),
            Tool("read_file", "Read a file from the filesystem", {}, lambda x: "ok"),
            Tool("calendar_create", "Create a new calendar event", {}, lambda x: "ok"),
            Tool("remember", "Store a memory for later recall", {}, lambda x: "ok"),
            Tool("run_shell", "Run a shell command", {}, lambda x: "ok"),
            Tool("encrypt_data", "Encrypt sensitive data with a key", {}, lambda x: "ok"),
        ]
        for t in tools:
            reg.register(t)

        router = ToolRouter(
            guidance=None,
            tool_registry=reg,
            config=RouterConfig(
                max_tools=5,
                fallback_count=7,
                confidence_threshold=0.05,
                min_routing_confidence=0.10,
                enabled=True,
            ),
        )
        all_schemas = reg.get_schemas()
        return router, all_schemas

    def test_task_message_routes_to_task_tools(self, router_with_schemas):
        router, schemas = router_with_schemas
        result = router.route("add a task to review the budget", allowed_schemas=schemas)
        names = [s["name"] for s in result.schemas]
        assert "add_task" in names, f"Expected add_task in {names}"

    def test_search_message_routes_to_web_search(self, router_with_schemas):
        router, schemas = router_with_schemas
        result = router.route("search the web for AI news", allowed_schemas=schemas)
        names = [s["name"] for s in result.schemas]
        assert "web_search" in names, f"Expected web_search in {names}"

    def test_time_message_routes_to_get_current_time(self, router_with_schemas):
        router, schemas = router_with_schemas
        result = router.route("what time is it", allowed_schemas=schemas)
        names = [s["name"] for s in result.schemas]
        assert "get_current_time" in names, f"Expected get_current_time in {names}"

    def test_file_message_routes_to_read_file(self, router_with_schemas):
        router, schemas = router_with_schemas
        result = router.route("read file report.pdf", allowed_schemas=schemas)
        names = [s["name"] for s in result.schemas]
        assert "read_file" in names, f"Expected read_file in {names}"

    def test_calendar_message_routes_to_calendar(self, router_with_schemas):
        router, schemas = router_with_schemas
        result = router.route("create a calendar event tomorrow", allowed_schemas=schemas)
        names = [s["name"] for s in result.schemas]
        assert "calendar_create" in names, f"Expected calendar_create in {names}"

    def test_routing_reduces_tool_count(self, router_with_schemas):
        """Routed set should be smaller than the full 10-tool set."""
        router, schemas = router_with_schemas
        result = router.route("add a task to review the budget", allowed_schemas=schemas)
        assert len(result.schemas) < len(schemas), (
            f"Expected routing to reduce tools from {len(schemas)}, got {len(result.schemas)}"
        )

    def test_routing_produces_confident_scores_on_clear_intent(self, router_with_schemas):
        """Even if fallback triggers (< 2 confident tools), the top tool score should be high."""
        router, schemas = router_with_schemas
        result = router.route("add a task to review the budget", allowed_schemas=schemas)
        # add_task should be the highest-scored tool regardless of fallback
        if result.scores:
            top_tool = max(result.scores.values(), key=lambda s: s.composite)
            assert top_tool.tool_name == "add_task", (
                f"Expected add_task to be top-scored, got {top_tool.tool_name}"
            )
            assert top_tool.intent_score > 0, "add_task should have non-zero intent score"

    def test_lazy_schema_refresh_after_registration(self):
        """Router should refresh _schema_lookup when registry grows after construction."""
        from familiar.core.tool_router import ToolRouter
        from familiar.core.tools import Tool, ToolRegistry

        reg = ToolRegistry()
        router = ToolRouter(guidance=None, tool_registry=reg)

        initial_size = len(router._schema_lookup)  # 9 built-ins present at init

        # Register additional tools AFTER router construction
        reg.register(Tool("my_custom_tool", "A custom task manager", {}, lambda x: "ok"))
        reg.register(Tool("my_web_finder", "Find things on the web", {}, lambda x: "ok"))

        # First route() should auto-refresh because registry grew
        schemas = reg.get_schemas()
        router.route("add task", allowed_schemas=schemas)
        assert len(router._schema_lookup) == initial_size + 2, (
            f"Expected schema_lookup to grow from {initial_size} to {initial_size + 2}, "
            f"got {len(router._schema_lookup)}"
        )
        assert "my_custom_tool" in router._schema_lookup

    def test_disabled_router_passes_all_through(self):
        from familiar.core.tool_router import RouterConfig, ToolRouter
        from familiar.core.tools import Tool, ToolRegistry

        reg = ToolRegistry()
        for i in range(5):
            reg.register(Tool(f"tool_{i}", f"Tool number {i}", {}, lambda x: "ok"))

        router = ToolRouter(guidance=None, tool_registry=reg, config=RouterConfig(enabled=False))
        schemas = reg.get_schemas()
        result = router.route("do something", allowed_schemas=schemas)
        assert len(result.schemas) == len(schemas)
        assert result.fallback is True


# ---------------------------------------------------------------------------
# Skill preflight checks
# ---------------------------------------------------------------------------


class TestSkillPrerequisitesExtended:
    """Skills with missing external deps should warn and skip tool registration."""

    def test_skill_with_unset_env_skips_tools(self, tmp_path, monkeypatch):
        """A skill that requires an env var should not register tools when var is unset."""
        import textwrap

        from familiar.core.skills import SKILL_PREREQUISITES, SkillLoader
        from familiar.core.tools import ToolRegistry

        # Create a minimal skill in tmp_path
        skill_dir = tmp_path / "test_guarded_skill"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text("# Test Guarded Skill")
        (skill_dir / "skill.py").write_text(
            textwrap.dedent("""
            from familiar.core.tools import Tool

            def noop(args): return "ok"

            TOOLS = [Tool("guarded_tool", "A guarded tool", {}, noop)]
        """)
        )

        # Inject a prerequisite check for this skill that always fails
        monkeypatch.setitem(
            SKILL_PREREQUISITES, "test_guarded_skill", [(lambda: False, "TEST_VAR env var not set")]
        )

        # Use a fresh isolated registry (not the global singleton)
        reg = ToolRegistry()
        loader = SkillLoader([str(tmp_path)])
        loader.tool_registry = reg

        loader.load_all()

        schemas = reg.get_schemas()
        names = [s["name"] for s in schemas]
        assert "guarded_tool" not in names, (
            "guarded_tool should not be registered when prerequisite fails"
        )

    def test_skill_with_met_prerequisites_registers_tools(self, tmp_path, monkeypatch):
        """A skill whose prerequisites all pass should register its tools normally."""
        import textwrap

        from familiar.core.skills import SKILL_PREREQUISITES, SkillLoader
        from familiar.core.tools import ToolRegistry

        skill_dir = tmp_path / "test_ok_skill"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text("# Test OK Skill")
        (skill_dir / "skill.py").write_text(
            textwrap.dedent("""
            from familiar.core.tools import Tool

            def noop(args): return "ok"

            TOOLS = [Tool("ok_tool", "An always-available tool", {}, noop)]
        """)
        )

        # Prerequisite that always passes
        monkeypatch.setitem(
            SKILL_PREREQUISITES, "test_ok_skill", [(lambda: True, "should never fail")]
        )

        reg = ToolRegistry()
        loader = SkillLoader([str(tmp_path)])
        loader.tool_registry = reg
        loader.load_all()

        schemas = reg.get_schemas()
        names = [s["name"] for s in schemas]
        assert "ok_tool" in names, "ok_tool should be registered when all prerequisites pass"

    def test_skill_with_no_prerequisites_always_registers(self, tmp_path):
        """Skills absent from SKILL_PREREQUISITES dict register unconditionally."""
        import textwrap

        from familiar.core.skills import SKILL_PREREQUISITES, SkillLoader
        from familiar.core.tools import ToolRegistry

        skill_dir = tmp_path / "unrestricted_skill"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text("# Unrestricted Skill")
        (skill_dir / "skill.py").write_text(
            textwrap.dedent("""
            from familiar.core.tools import Tool

            TOOLS = [Tool("free_tool", "No prerequisites needed", {}, lambda a: "ok")]
        """)
        )

        assert "unrestricted_skill" not in SKILL_PREREQUISITES

        reg = ToolRegistry()
        loader = SkillLoader([str(tmp_path)])
        loader.tool_registry = reg
        loader.load_all()

        names = [s["name"] for s in reg.get_schemas()]
        assert "free_tool" in names


# ---------------------------------------------------------------------------
# Capability security hardening
# ---------------------------------------------------------------------------


class TestCapabilityHardening:
    """Verify that sensitive skills require appropriate capabilities."""

    def test_sessions_skill_requires_system_control(self):
        from familiar.core.security import SKILL_DIRECTORY_CAPABILITIES, Capability

        caps = SKILL_DIRECTORY_CAPABILITIES.get("sessions", set())
        assert Capability.SYSTEM_CONTROL in caps, (
            "sessions skill exposes revoke_session — must require SYSTEM_CONTROL"
        )

    def test_encryption_skill_requires_system_control(self):
        from familiar.core.security import SKILL_DIRECTORY_CAPABILITIES, Capability

        caps = SKILL_DIRECTORY_CAPABILITIES.get("encryption", set())
        assert Capability.SYSTEM_CONTROL in caps, (
            "encryption skill exposes key rotation/decrypt — must require SYSTEM_CONTROL"
        )

    def test_audit_skill_requires_file_read(self):
        from familiar.core.security import SKILL_DIRECTORY_CAPABILITIES, Capability

        caps = SKILL_DIRECTORY_CAPABILITIES.get("audit", set())
        assert Capability.READ_FILES in caps, (
            "audit skill exposes export_audit_trail — must require READ_FILES"
        )

    def test_sessions_not_accessible_to_known_user(self, config, mock_provider):
        """KNOWN trust level should NOT have access to sessions tools."""
        from unittest.mock import patch

        from familiar.core.agent import Agent, TrustLevel

        config.agent.skills_dirs = []
        config.agent.skills_enabled = False
        config.agent.memory_enabled = False
        config.agent.scheduler_enabled = False

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            agent = Agent(config=config)
        agent.provider = mock_provider

        session = agent.sessions.get_or_create_session("known_user", "default")
        session.set_trust_level(TrustLevel.KNOWN)

        # KNOWN users should lack SYSTEM_CONTROL
        from familiar.core.security import Capability

        assert not session.has_capability(Capability.SYSTEM_CONTROL), (
            "KNOWN users should not have SYSTEM_CONTROL capability"
        )

    def test_owner_has_system_control(self, config, mock_provider):
        """OWNER trust level must have SYSTEM_CONTROL to access sessions/encryption."""
        from unittest.mock import patch

        from familiar.core.agent import Agent, TrustLevel
        from familiar.core.security import Capability

        config.agent.skills_dirs = []
        config.agent.skills_enabled = False
        config.agent.memory_enabled = False
        config.agent.scheduler_enabled = False

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            agent = Agent(config=config)
        agent.provider = mock_provider

        session = agent.sessions.get_or_create_session("owner_user2", "default")
        session.set_trust_level(TrustLevel.OWNER)
        assert session.has_capability(Capability.SYSTEM_CONTROL)


# ---------------------------------------------------------------------------
# External Service Integration (v1.1.10)
# ---------------------------------------------------------------------------


class TestExternalServiceTimeouts:
    """IMAP, SMTP, Google API calls must carry explicit timeouts."""

    def test_email_skill_has_imap_timeout_constant(self):
        from pathlib import Path

        src = Path("familiar/skills/email/skill.py").read_text()
        assert "IMAP_TIMEOUT" in src, "email skill must define IMAP_TIMEOUT"
        assert "timeout=IMAP_TIMEOUT" in src, "IMAP4_SSL must use IMAP_TIMEOUT"

    def test_email_skill_has_smtp_timeout_constant(self):
        from pathlib import Path

        src = Path("familiar/skills/email/skill.py").read_text()
        assert "SMTP_TIMEOUT" in src, "email skill must define SMTP_TIMEOUT"
        assert "timeout=SMTP_TIMEOUT" in src, "SMTP must use SMTP_TIMEOUT"

    def test_triage_skill_has_imap_timeout(self):
        from pathlib import Path

        src = Path("familiar/skills/triage/skill.py").read_text()
        assert "IMAP_TIMEOUT" in src
        assert "timeout=IMAP_TIMEOUT" in src

    def test_gdrive_skill_has_request_timeout(self):
        from pathlib import Path

        src = Path("familiar/skills/gdrive/skill.py").read_text()
        assert "REQUEST_TIMEOUT" in src, "gdrive must define REQUEST_TIMEOUT"
        assert "httplib2.Http(timeout=" in src, "gdrive must use httplib2 timeout"

    def test_calendar_skill_has_request_timeout(self):
        from pathlib import Path

        src = Path("familiar/skills/calendar/skill.py").read_text()
        assert "REQUEST_TIMEOUT" in src
        assert "httplib2.Http(timeout=" in src

    def test_anthropic_provider_has_timeout(self):
        from pathlib import Path

        src = Path("familiar/core/providers.py").read_text()
        # timeout must appear in Anthropic() constructor — check it's present
        assert "timeout=90.0" in src, "AnthropicProvider must set timeout=90.0"

    def test_openai_provider_has_timeout(self):
        from pathlib import Path

        src = Path("familiar/core/providers.py").read_text()
        assert src.count("timeout=90.0") >= 2, "Both Anthropic and OpenAI clients need timeout"


class TestExternalServiceErrorSanitization:
    """Raw exception strings must not leak internal details to the LLM."""

    def test_email_no_raw_imap_exception(self):
        import re
        from pathlib import Path

        src = Path("familiar/skills/email/skill.py").read_text()
        # No 'return f"...{e}"' patterns (would leak internal exception details)
        raw_returns = re.findall(r'return f["\'].*\{e\}', src)
        assert not raw_returns, f"Email leaks raw exceptions: {raw_returns}"

    def test_email_no_raw_smtp_exception(self):
        from pathlib import Path

        src = Path("familiar/skills/email/skill.py").read_text()
        assert "Failed to send: {e}" not in src

    def test_sms_no_raw_twilio_exception(self):
        from pathlib import Path

        src = Path("familiar/skills/sms/skill.py").read_text()
        # The raw 'return f"❌ {e}"' pattern exposes Twilio error responses
        assert 'return f"❌ {e}"' not in src

    def test_gdrive_no_raw_exception(self):
        import re
        from pathlib import Path

        src = Path("familiar/skills/gdrive/skill.py").read_text()
        raw = re.findall(r'return f["\'][^"\']*\{e\}["\']', src)
        assert not raw, f"gdrive leaks exceptions to LLM: {raw}"

    def test_triage_sanitizes_exceptions(self):
        from pathlib import Path

        src = Path("familiar/skills/triage/skill.py").read_text()
        # Triage used to return f"❌ Error: {e}" directly
        assert 'return f"❌ Error: {e}"' not in src


class TestSkillPrerequisitesExtended2:
    """Additional prerequisite checks for external services."""

    def test_calendar_has_google_prerequisites(self):
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "calendar" in SKILL_PREREQUISITES
        labels = [label for _, label in SKILL_PREREQUISITES["calendar"]]
        assert any("google" in item.lower() or "googleapiclient" in item for item in labels)

    def test_gdrive_has_httplib2_prerequisite(self):
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "gdrive" in SKILL_PREREQUISITES
        labels = [label for _, label in SKILL_PREREQUISITES["gdrive"]]
        assert any("httplib2" in item for item in labels)

    def test_sms_has_twilio_importable_check(self):
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "sms" in SKILL_PREREQUISITES
        labels = [label for _, label in SKILL_PREREQUISITES["sms"]]
        assert any("twilio" in item.lower() for item in labels)

    def test_sms_env_var_name_matches_skill(self):
        """SKILL_PREREQUISITES must use the same env var name as the skill itself."""
        import re
        from pathlib import Path

        from familiar.core.skills import SKILL_PREREQUISITES

        # What env var does the skill actually use?
        src = Path("familiar/skills/sms/skill.py").read_text()
        actual_vars = set(re.findall(r'os\.environ\.get\(["\']([A-Z_]+)["\']', src))

        # What does the prerequisite check?
        prereq_labels = " ".join(label for _, label in SKILL_PREREQUISITES["sms"])
        for var in actual_vars:
            if "TWILIO" in var:
                assert var in prereq_labels, (
                    f"Prerequisite checks for wrong env var — skill uses {var} but "
                    f"prerequisite labels are: {prereq_labels}"
                )

    def test_provider_clients_have_max_retries(self):
        from pathlib import Path

        src = Path("familiar/core/providers.py").read_text()
        assert "max_retries=2" in src, "Provider clients must configure max_retries"


# ---------------------------------------------------------------------------
# External Service Integration Round 2 (v1.1.11)
# ---------------------------------------------------------------------------


class TestOllamaSupportsToolsExtended:
    """Extended supports_tools coverage for new model families and /api/show probe."""

    def test_phi4_supports_tools(self):
        from familiar.core.providers import OllamaProvider

        p = OllamaProvider("phi4")
        p._probe_tool_support = lambda: False
        assert p.supports_tools is True

    def test_phi4_mini_supports_tools(self):
        from familiar.core.providers import OllamaProvider

        p = OllamaProvider("phi4-mini")
        p._probe_tool_support = lambda: False
        assert p.supports_tools is True

    def test_command_r_supports_tools(self):
        from familiar.core.providers import OllamaProvider

        p = OllamaProvider("command-r")
        p._probe_tool_support = lambda: False
        assert p.supports_tools is True

    def test_command_r_plus_supports_tools(self):
        from familiar.core.providers import OllamaProvider

        p = OllamaProvider("command-r-plus")
        p._probe_tool_support = lambda: False
        assert p.supports_tools is True

    def test_gemma3_does_not_support_tools(self):
        """gemma3 is in the static list in test_integration (False); verify unchanged."""
        from familiar.core.providers import OllamaProvider

        p = OllamaProvider("gemma3:1b")
        p._probe_tool_support = lambda: False
        assert p.supports_tools is False

    def test_unknown_model_falls_back_to_probe(self):
        """An unrecognised model should delegate to _probe_tool_support."""
        from familiar.core.providers import OllamaProvider

        p = OllamaProvider("my-custom-model:latest")
        probe_called = []

        def fake_probe():
            probe_called.append(True)
            return True

        p._probe_tool_support = fake_probe
        result = p.supports_tools
        assert probe_called, "_probe_tool_support should be called for unknown models"
        assert result is True

    def test_unknown_model_probe_returns_false_on_network_error(self):
        """Probe failure must return False, not raise."""
        from familiar.core.providers import OllamaProvider

        p = OllamaProvider("unknown-model")
        p._probe_tool_support = lambda: False
        assert p.supports_tools is False

    def test_ollama_openai_client_has_timeout(self):
        """OllamaProvider OpenAI client must be constructed with matching timeout."""
        from pathlib import Path

        src = Path("familiar/core/providers.py").read_text()
        # The client init block must contain both timeout=self.timeout and max_retries
        assert "timeout=self.timeout" in src
        assert src.count("max_retries=") >= 3, "Anthropic, OpenAI, and Ollama all need max_retries"


class TestSkillPrerequisitesRound2:
    """meetings, triage, notifications, messaging, triggers now in SKILL_PREREQUISITES."""

    def test_meetings_in_prerequisites(self):
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "meetings" in SKILL_PREREQUISITES

    def test_triage_in_prerequisites(self):
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "triage" in SKILL_PREREQUISITES

    def test_notifications_in_prerequisites(self):
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "notifications" in SKILL_PREREQUISITES

    def test_messaging_in_prerequisites(self):
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "messaging" in SKILL_PREREQUISITES

    def test_triggers_in_prerequisites(self):
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "triggers" in SKILL_PREREQUISITES

    def test_meetings_checks_email_address(self):
        from familiar.core.skills import SKILL_PREREQUISITES

        labels = [label for _, label in SKILL_PREREQUISITES.get("meetings", [])]
        assert any("EMAIL_ADDRESS" in item for item in labels)

    def test_triage_checks_email_imap_server(self):
        from familiar.core.skills import SKILL_PREREQUISITES

        labels = [label for _, label in SKILL_PREREQUISITES.get("triage", [])]
        assert any("EMAIL_IMAP_SERVER" in item or "EMAIL" in item for item in labels)

    def test_triage_tools_not_registered_without_imap(self, monkeypatch):
        """triage tools must not register when EMAIL env vars are absent."""
        import io
        import logging as lg
        from pathlib import Path

        from familiar.core.skills import SkillLoader
        from familiar.core.tools import ToolRegistry

        monkeypatch.delenv("EMAIL_ADDRESS", raising=False)
        monkeypatch.delenv("EMAIL_IMAP_SERVER", raising=False)
        monkeypatch.delenv("EMAIL_PASSWORD", raising=False)

        fresh_reg = ToolRegistry()
        loader = SkillLoader([str(Path("familiar/skills"))])
        loader.tool_registry = fresh_reg

        buf = io.StringIO()
        handler = lg.StreamHandler(buf)
        handler.setLevel(lg.WARNING)
        skill_logger = lg.getLogger("familiar.core.skills")
        skill_logger.addHandler(handler)
        old_level = skill_logger.level
        skill_logger.setLevel(lg.WARNING)

        try:
            # Also suppress Gmail OAuth token so the OR-branch doesn't pass
            with patch("familiar.core.skills._gmail_token", return_value=False):
                loader.load_skill(Path("familiar/skills/triage"))
        finally:
            skill_logger.removeHandler(handler)
            skill_logger.setLevel(old_level)

        assert "prerequisites not met" in buf.getvalue()
        triage_tools = {"triage_inbox", "check_inbox", "categorize_emails"}
        registered = {s["name"] for s in fresh_reg.get_schemas()}
        assert not (triage_tools & registered), f"triage tools leaked: {triage_tools & registered}"


class TestMarketplaceSecurity:
    """marketplace install() must reject untrusted repo URLs."""

    def test_github_url_allowed(self):
        from pathlib import Path

        src = Path("familiar/skills/marketplace/skill.py").read_text()
        assert "github.com/" in src
        assert "_ALLOWED_HOSTS" in src

    def test_arbitrary_url_rejected(self):
        """install() must return an error for non-allowlisted URLs without cloning."""
        import sys

        sys.path.insert(0, ".")
        from familiar.skills.marketplace import skill as mkt

        marketplace = mkt.PluginMarketplace.__new__(mkt.PluginMarketplace)
        marketplace._registry = {
            "plugins": [
                {
                    "id": "evil-plugin",
                    "name": "Evil Plugin",
                    "description": "Malicious",
                    "version": "1.0",
                    "repo": "http://evil.example.com/bad-code.git",
                    "requirements": [],
                }
            ]
        }
        marketplace._installed = {}

        result = marketplace.install("evil-plugin")
        assert "refused" in result.lower() or "not from a trusted" in result.lower(), (
            f"Expected rejection but got: {result}"
        )
        assert "evil.example.com" in result or "Installation refused" in result

    def test_github_url_passes_allowlist(self):
        """A legitimate github.com URL must pass the allowlist check."""
        import sys

        sys.path.insert(0, ".")
        import unittest.mock as mock

        from familiar.skills.marketplace import skill as mkt

        marketplace = mkt.PluginMarketplace.__new__(mkt.PluginMarketplace)
        marketplace._registry = {
            "plugins": [
                {
                    "id": "legit-plugin",
                    "name": "Legit Plugin",
                    "description": "Safe",
                    "version": "1.0",
                    "repo": "https://github.com/familiar/skill-home-assistant",
                    "requirements": [],
                }
            ]
        }
        marketplace._installed = {}

        # Intercept subprocess so we don't actually clone
        with mock.patch("subprocess.run") as mock_run:
            mock_run.return_value = mock.Mock(returncode=0, stderr="", stdout="")
            with mock.patch("pathlib.Path.exists", return_value=False):
                with mock.patch("pathlib.Path.symlink_to"):
                    with mock.patch.object(marketplace, "_save_installed"):
                        result = marketplace.install("legit-plugin")
        # Should not be an allowlist rejection
        assert "refused" not in result.lower(), f"Legit URL incorrectly rejected: {result}"


# ---------------------------------------------------------------------------
# Expression Parser (v1.1.12)
# ---------------------------------------------------------------------------


class TestExprParser:
    """Safe expression parser replacing eval() in planner condition steps."""

    def test_boolean_literals(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate("true") is True
        assert evaluate("false") is False
        assert evaluate("True") is True
        assert evaluate("FALSE") is False

    def test_string_equality(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate('"hello" == "hello"') is True
        assert evaluate('"hello" == "world"') is False
        assert evaluate('"hello" != "world"') is True

    def test_numeric_comparisons(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate("10 > 5") is True
        assert evaluate("5 > 10") is False
        assert evaluate("5 >= 5") is True
        assert evaluate("3 < 4") is True
        assert evaluate("4 <= 4") is True
        assert evaluate("42 == 42") is True
        assert evaluate("42 != 43") is True

    def test_string_operators(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate('"hello world" contains "world"') is True
        assert evaluate('"hello world" contains "xyz"') is False
        assert evaluate('"hello" startswith "hel"') is True
        assert evaluate('"hello" endswith "llo"') is True
        assert evaluate('"hello" endswith "xyz"') is False
        assert evaluate('"apple" in "apple,banana,cherry"') is True
        assert evaluate('"grape" in "apple,banana,cherry"') is False

    def test_logical_operators(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate("true and true") is True
        assert evaluate("true and false") is False
        assert evaluate("false or true") is True
        assert evaluate("false or false") is False
        assert evaluate("not true") is False
        assert evaluate("not false") is True

    def test_parentheses(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate("(true or false) and true") is True
        assert evaluate("not (false or false)") is True
        assert evaluate("not (true and false)") is True

    def test_operator_precedence(self):
        from familiar.core.expr_parser import evaluate

        # and binds tighter than or
        assert evaluate("true and false or true") is True
        assert evaluate("false or true and true") is True

    def test_case_insensitive_keywords(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate("true AND true") is True
        assert evaluate("false OR true") is True
        assert evaluate("NOT false") is True

    def test_empty_expression_returns_true(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate("") is True
        assert evaluate("   ") is True

    def test_bare_word_string(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate('success == "success"') is True
        assert evaluate("success == success") is True

    def test_type_coercion_string_bool(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate('"true" == "true"') is True

    def test_rejects_python_builtins(self):
        from familiar.core.expr_parser import ExpressionError, evaluate

        with pytest.raises(ExpressionError):
            evaluate('__import__("os")')

    def test_rejects_attribute_access(self):
        from familiar.core.expr_parser import ExpressionError, evaluate

        with pytest.raises(ExpressionError):
            evaluate("().__class__")

    def test_rejects_function_calls(self):
        from familiar.core.expr_parser import ExpressionError, evaluate

        with pytest.raises(ExpressionError):
            evaluate('open("/etc/passwd")')

    def test_rejects_exec(self):
        from familiar.core.expr_parser import ExpressionError, evaluate

        with pytest.raises(ExpressionError):
            evaluate('exec("import os")')

    def test_rejects_arithmetic(self):
        from familiar.core.expr_parser import ExpressionError, evaluate

        # + not in grammar — should raise, not silently compute
        with pytest.raises(ExpressionError):
            evaluate("1 + 1")

    def test_rejects_unknown_operator(self):
        from familiar.core.expr_parser import ExpressionError, evaluate

        with pytest.raises(ExpressionError):
            evaluate('"x" like "y"')


class TestPlannerConditionNoEval:
    """Planner _execute_condition must use expr_parser, not eval()."""

    def test_eval_removed_from_planner(self):
        """No bare eval() call should exist in the planner skill."""
        import re
        from pathlib import Path

        src = Path("familiar/skills/planner/skill.py").read_text()
        # Remove docstring content (between triple quotes)
        in_docstring = False
        clean_lines = []
        for line in src.splitlines():
            stripped = line.strip()
            if '"""' in stripped or "'''" in stripped:
                in_docstring = not in_docstring
                continue
            if not in_docstring:
                clean_lines.append(line)
        clean = "\n".join(clean_lines)
        assert re.search(r"\beval\s*\(", clean) is None, (
            "eval() call found in planner code (not docstring)"
        )

    def test_expr_parser_imported_in_condition(self):
        from pathlib import Path

        src = Path("familiar/skills/planner/skill.py").read_text()
        assert "expr_parser" in src, "expr_parser not imported in planner"
        assert "ExpressionError" in src, "ExpressionError not referenced in planner"

    def test_execute_condition_uses_parser(self):
        """Integration: _execute_condition evaluates simple expressions correctly."""
        import sys

        sys.path.insert(0, ".")
        from unittest.mock import MagicMock

        from familiar.skills.planner import skill as planner_skill

        # Minimal Step and Plan stubs
        step = MagicMock()
        step.condition = '"completed" == "completed"'
        step.action_config = {}

        plan = MagicMock()
        plan.context = {}

        executor = planner_skill.PlanExecutor.__new__(planner_skill.PlanExecutor)
        executor.agent = MagicMock()

        # Patch _render_config to return the condition unchanged
        executor._render_config = lambda cfg, ctx: cfg

        result = executor._execute_condition(step, plan)
        assert result is True, f"Expected True, got {result}"

    def test_execute_condition_false(self):
        import sys

        sys.path.insert(0, ".")
        from unittest.mock import MagicMock

        from familiar.skills.planner import skill as planner_skill

        step = MagicMock()
        step.condition = '"failed" == "completed"'
        step.action_config = {}

        plan = MagicMock()
        plan.context = {}

        executor = planner_skill.PlanExecutor.__new__(planner_skill.PlanExecutor)
        executor.agent = MagicMock()
        executor._render_config = lambda cfg, ctx: cfg

        result = executor._execute_condition(step, plan)
        assert result is False

    def test_execute_condition_fallback_to_llm_on_natural_language(self):
        """Natural-language conditions that the parser can't handle fall back to LLM."""
        import sys

        sys.path.insert(0, ".")
        from unittest.mock import MagicMock

        from familiar.skills.planner import skill as planner_skill

        step = MagicMock()
        # Natural language — parser will raise ExpressionError
        step.condition = "the weather is sunny"
        step.action_config = {}

        plan = MagicMock()
        plan.context = {}

        executor = planner_skill.PlanExecutor.__new__(planner_skill.PlanExecutor)
        llm_mock = MagicMock()
        llm_mock.chat.return_value = "true"
        executor.agent = llm_mock
        executor._render_config = lambda cfg, ctx: cfg

        result = executor._execute_condition(step, plan)
        assert result is True
        assert llm_mock.chat.called, "LLM fallback should have been invoked"


# ---------------------------------------------------------------------------
# v1.1.12 — expr_parser, Config.validate(), health check factories
# ---------------------------------------------------------------------------


class TestConfigValidate:
    """Config.validate() catches missing credentials at startup."""

    def test_validate_returns_list(self):
        from familiar.core.config import Config

        c = Config()
        issues = c.validate()
        assert isinstance(issues, list)

    def test_anthropic_provider_no_key(self, monkeypatch):
        from familiar.core.config import Config

        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        c = Config()
        c.llm.default_provider = "anthropic"
        issues = c.validate()
        assert any("ANTHROPIC_API_KEY" in i for i in issues)

    def test_anthropic_provider_with_key(self, monkeypatch):
        from familiar.core.config import Config

        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        c = Config()
        c.llm.default_provider = "anthropic"
        # May still have Ollama not reachable but no anthropic key warning
        issues = c.validate()
        assert not any("ANTHROPIC_API_KEY" in i for i in issues)

    def test_openai_provider_no_key(self, monkeypatch):
        from familiar.core.config import Config

        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        c = Config()
        c.llm.default_provider = "openai"
        issues = c.validate()
        assert any("OPENAI_API_KEY" in i for i in issues)

    def test_openai_provider_with_key(self, monkeypatch):
        from familiar.core.config import Config

        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        c = Config()
        c.llm.default_provider = "openai"
        issues = c.validate()
        assert not any("OPENAI_API_KEY" in i for i in issues)

    def test_telegram_enabled_no_token(self, monkeypatch):
        from familiar.core.config import Config

        monkeypatch.delenv("TELEGRAM_BOT_TOKEN", raising=False)
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        c = Config()
        c.llm.default_provider = "anthropic"
        c.channels.telegram_enabled = True
        issues = c.validate()
        assert any("TELEGRAM_BOT_TOKEN" in i for i in issues)

    def test_telegram_enabled_with_token(self, monkeypatch):
        from familiar.core.config import Config

        monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "123:abc")
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        c = Config()
        c.llm.default_provider = "anthropic"
        c.channels.telegram_enabled = True
        issues = c.validate()
        assert not any("TELEGRAM_BOT_TOKEN" in i for i in issues)

    def test_validate_method_exists_on_config_class(self):
        from familiar.core.config import Config

        assert callable(getattr(Config, "validate", None)), "Config must have a validate() method"


class TestHealthCheckFactories:
    """create_memory_agent_health_check and create_planner_health_check."""

    def test_memory_agent_healthy_running_thread(self):
        import threading

        from familiar.core.health import create_memory_agent_health_check

        class FakeAgent:
            _last_error = None
            _last_run = None

        agent = FakeAgent()
        done = threading.Event()
        agent._thread = threading.Thread(target=lambda: done.wait(5), daemon=True)
        agent._thread.start()

        try:
            result = create_memory_agent_health_check(agent)()
            assert result.healthy is True
            assert result.name == "memory_agent"
        finally:
            done.set()
            agent._thread.join(timeout=1)

    def test_memory_agent_unhealthy_dead_thread(self):
        import threading

        from familiar.core.health import create_memory_agent_health_check

        class FakeAgent:
            _last_error = None
            _last_run = None

        agent = FakeAgent()
        # Thread that immediately exits
        agent._thread = threading.Thread(target=lambda: None)
        agent._thread.start()
        agent._thread.join()  # wait for it to die

        result = create_memory_agent_health_check(agent)()
        assert result.healthy is False
        assert "dead" in result.message.lower() or "thread" in result.message.lower()

    def test_memory_agent_reports_last_error(self):
        from familiar.core.health import create_memory_agent_health_check

        class FakeAgent:
            _last_error = "IMAP connection reset"
            _last_run = None
            _thread = None

        result = create_memory_agent_health_check(FakeAgent())()
        assert result.healthy is False

    def test_memory_agent_gc_collected(self):
        import weakref

        from familiar.core.health import create_memory_agent_health_check

        class FakeAgent:
            _last_error = None
            _last_run = None
            _thread = None

        agent = FakeAgent()
        ref = weakref.ref(agent)
        check = create_memory_agent_health_check(ref)
        del agent
        import gc

        gc.collect()

        result = check()
        assert result.healthy is False
        assert "garbage-collected" in result.message

    def test_planner_healthy_no_active_plans(self):
        from familiar.core.health import create_planner_health_check

        class FakePlanner:
            _active_plans = {}

        result = create_planner_health_check(FakePlanner())()
        assert result.healthy is True
        assert result.name == "planner"

    def test_planner_healthy_fresh_active_plans(self):
        import datetime

        from familiar.core.health import create_planner_health_check

        class FakePlan:
            started_at = datetime.datetime.now().isoformat()

        class FakePlanner:
            _active_plans = {"plan_1": FakePlan()}

        result = create_planner_health_check(FakePlanner())()
        assert result.healthy is True
        assert result.details["active_plans"] == 1
        assert result.details["stuck_plans"] == 0

    def test_planner_unhealthy_stuck_plan(self):
        import datetime

        from familiar.core.health import create_planner_health_check

        class FakePlan:
            # Started 45 minutes ago — exceeds 30-minute threshold
            started_at = (datetime.datetime.now() - datetime.timedelta(minutes=45)).isoformat()

        class FakePlanner:
            _active_plans = {"plan_stuck": FakePlan()}

        result = create_planner_health_check(FakePlanner())()
        assert result.healthy is False
        assert result.details["stuck_plans"] == 1

    def test_health_factories_exist_in_module(self):
        from familiar.core import health

        assert hasattr(health, "create_memory_agent_health_check")
        assert hasattr(health, "create_planner_health_check")
        assert callable(health.create_memory_agent_health_check)
        assert callable(health.create_planner_health_check)


class TestExprParserEdgeCases:
    """Additional edge cases not covered by TestExprParser."""

    def test_nested_not(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate("not not true") is True
        assert evaluate("not not false") is False

    def test_numeric_string_coercion(self):
        from familiar.core.expr_parser import evaluate

        # After template substitution, numbers often arrive as strings
        assert evaluate('"42" == 42') is True
        assert evaluate('"3.14" > 3') is True

    def test_compound_and_or(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate('"ok" == "ok" and 10 > 5 or false') is True
        assert evaluate("false and false or true") is True

    def test_single_quoted_strings(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate("'hello' == 'hello'") is True
        assert evaluate("'hello' != 'world'") is True

    def test_contains_case_sensitive(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate('"Hello World" contains "World"') is True
        assert evaluate('"Hello World" contains "world"') is False

    def test_in_operator_whitespace(self):
        from familiar.core.expr_parser import evaluate

        # Items with surrounding spaces should be stripped
        assert evaluate('"apple" in "apple, banana, cherry"') is True

    def test_deeply_nested_parens(self):
        from familiar.core.expr_parser import evaluate

        assert evaluate("((true and true) or (false and false))") is True

    def test_error_on_incomplete_expression(self):
        from familiar.core.expr_parser import ExpressionError, evaluate

        with pytest.raises(ExpressionError):
            evaluate('"hello" ==')

    def test_error_on_mismatched_parens(self):
        from familiar.core.expr_parser import ExpressionError, evaluate

        with pytest.raises(ExpressionError):
            evaluate("(true and false")


# ---------------------------------------------------------------------------
# v1.1.13 — GuardrailsEngine fully integrated
# ---------------------------------------------------------------------------


class TestGuardrailsIntegration:
    """
    GuardrailsEngine is now wired into the agent loop at 5 points:
      1. _setup_request: start_request (rate/cost gate) + process_with_pii (PII redact)
      2. _run_agent_loop per iteration: check_iteration (iteration cap + timeout)
      3. _run_agent_loop post-LLM: track_llm_usage (token/cost cap)
      4. _execute_tool_secure: check_tool_call (blocklist + approval)
      5. _finalize_response: end_request (record in rate-limit history)
    """

    # ── 1. start_request: rate limiting ──────────────────────────────────────

    def test_rate_limit_fires_before_session(self):
        """start_request raises _GuardrailBlock before session is created.
        chat() catches it and returns the user-facing message string."""
        from familiar.core.agent import Agent
        from familiar.core.guardrails import GuardrailConfig, ViolationAction

        cfg = GuardrailConfig(
            max_requests_per_minute=1,
            rate_violation_action=ViolationAction.BLOCK,
        )
        agent = Agent()
        agent.guardrails = agent.guardrails.__class__(cfg)

        # First request goes through
        agent.guardrails._user_history["u1"].request_times.append(__import__("time").time())
        # Second hits the limit
        result = agent.chat("hello", user_id="u1")
        assert "too quickly" in result or "limit" in result.lower()

    def test_rate_limit_returns_string_not_exception(self):
        """_GuardrailBlock is never propagated — chat() always returns str."""
        import time

        from familiar.core.agent import Agent
        from familiar.core.guardrails import GuardrailConfig, ViolationAction

        cfg = GuardrailConfig(
            max_requests_per_minute=1,
            rate_violation_action=ViolationAction.BLOCK,
        )
        agent = Agent()
        agent.guardrails = agent.guardrails.__class__(cfg)
        agent.guardrails._user_history["u2"].request_times.append(time.time())

        result = agent.chat("hello", user_id="u2")
        assert isinstance(result, str)
        assert len(result) > 0

    # ── 1b. process_with_pii: PII redaction ──────────────────────────────────

    def test_pii_email_redacted_before_llm(self):
        """An email address in the message is redacted to <EMAIL> before the
        message is passed to the LLM or stored in history."""
        from familiar.core.guardrails import GuardrailConfig, Guardrails

        config = GuardrailConfig(enable_pii_detection=True)
        guardrails = Guardrails(config)
        # Confirm PII detector is active
        assert guardrails._pii_detector is not None

        # Directly exercise process_with_pii on an email address
        cleaned, findings, blocked = guardrails.process_with_pii(
            "Contact me at user@example.com for details"
        )
        assert "user@example.com" not in cleaned
        assert "<EMAIL>" in cleaned
        assert not blocked

    def test_pii_ssn_redacted(self):
        from familiar.core.guardrails import GuardrailConfig, Guardrails

        config = GuardrailConfig(enable_pii_detection=True)
        guardrails = Guardrails(config)
        cleaned, findings, _ = guardrails.process_with_pii("My SSN is 123-45-6789")
        assert "123-45-6789" not in cleaned
        assert "<SSN>" in cleaned

    def test_pii_credit_card_redacted(self):
        from familiar.core.guardrails import GuardrailConfig, Guardrails

        config = GuardrailConfig(enable_pii_detection=True)
        guardrails = Guardrails(config)
        cleaned, findings, _ = guardrails.process_with_pii("Card number: 4111 1111 1111 1111")
        assert "4111 1111 1111 1111" not in cleaned
        assert len(findings) > 0

    def test_clean_message_unchanged(self):
        """Messages without PII pass through unmodified."""
        from familiar.core.guardrails import GuardrailConfig, Guardrails

        config = GuardrailConfig(enable_pii_detection=True)
        guardrails = Guardrails(config)
        msg = "What is the weather like today?"
        cleaned, findings, blocked = guardrails.process_with_pii(msg)
        assert cleaned == msg
        assert findings == []
        assert not blocked

    # ── 2. check_iteration: iteration cap ────────────────────────────────────

    def test_iteration_cap_raises_violation(self):
        """check_iteration raises GuardrailViolation at the configured limit."""
        from familiar.core.guardrails import (
            GuardrailConfig,
            Guardrails,
            GuardrailViolation,
            ViolationType,
        )

        g = Guardrails(GuardrailConfig(max_iterations=3))
        tracker = g.start_request("u")
        # Iterations 0,1,2 pass — 3 raises
        g.check_iteration(0, tracker)
        g.check_iteration(1, tracker)
        g.check_iteration(2, tracker)
        with pytest.raises(GuardrailViolation) as exc_info:
            g.check_iteration(3, tracker)
        assert exc_info.value.violation_type == ViolationType.ITERATION_LIMIT

    def test_timeout_raises_violation(self):
        """check_iteration raises TIMEOUT if elapsed_seconds > limit."""
        import time

        from familiar.core.guardrails import (
            GuardrailConfig,
            Guardrails,
            GuardrailViolation,
            ViolationType,
        )

        g = Guardrails(GuardrailConfig(request_timeout_seconds=0.01))
        tracker = g.start_request("u")
        time.sleep(0.05)  # exceed 10ms timeout
        with pytest.raises(GuardrailViolation) as exc_info:
            g.check_iteration(0, tracker)
        assert exc_info.value.violation_type == ViolationType.TIMEOUT

    # ── 3. track_llm_usage: token and cost caps ───────────────────────────────

    def test_token_limit_raises_after_llm_call(self):
        """track_llm_usage raises TOKEN_LIMIT when cumulative tokens exceed cap."""
        from familiar.core.guardrails import (
            GuardrailConfig,
            Guardrails,
            GuardrailViolation,
            ViolationType,
        )

        g = Guardrails(GuardrailConfig(max_tokens_per_request=100))
        tracker = g.start_request("u")
        with pytest.raises(GuardrailViolation) as exc_info:
            g.track_llm_usage(60, 60, 0.01, tracker)  # 120 tokens > 100
        assert exc_info.value.violation_type == ViolationType.TOKEN_LIMIT

    def test_cost_limit_raises_after_llm_call(self):
        """track_llm_usage raises COST_LIMIT when per-request cost exceeds cap."""
        from familiar.core.guardrails import (
            GuardrailConfig,
            Guardrails,
            GuardrailViolation,
            ViolationType,
        )

        g = Guardrails(GuardrailConfig(max_cost_per_request=0.001))
        tracker = g.start_request("u")
        with pytest.raises(GuardrailViolation) as exc_info:
            g.track_llm_usage(100, 100, 0.05, tracker)  # $0.05 > $0.001
        assert exc_info.value.violation_type == ViolationType.COST_LIMIT

    def test_usage_within_limits_does_not_raise(self):
        """track_llm_usage does not raise when within limits."""
        from familiar.core.guardrails import GuardrailConfig, Guardrails

        g = Guardrails(GuardrailConfig(max_tokens_per_request=100_000, max_cost_per_request=10.0))
        tracker = g.start_request("u")
        g.track_llm_usage(100, 100, 0.001, tracker)  # well within limits

    # ── 4. check_tool_call: blocklist + approval ──────────────────────────────

    def test_blocked_tool_returns_false(self):
        """A tool in blocked_tools is denied regardless of trust level."""
        from familiar.core.guardrails import GuardrailConfig, Guardrails

        g = Guardrails(GuardrailConfig(blocked_tools=["execute_command"]))
        allowed, reason, requires_approval = g.check_tool_call(
            "execute_command", {}, tool_registry=None
        )
        assert allowed is False
        assert "blocked" in reason.lower() or "execute_command" in reason

    def test_approval_required_tool_returns_true_with_flag(self):
        """A tool in require_approval_tools is allowed=True but requires_approval=True."""
        from familiar.core.guardrails import GuardrailConfig, Guardrails

        g = Guardrails(GuardrailConfig(require_approval_tools=["send_email"]))
        allowed, reason, requires_approval = g.check_tool_call(
            "send_email", {"to": "a@b.com"}, tool_registry=None
        )
        assert allowed is True
        assert requires_approval is True

    def test_normal_tool_fully_allowed(self):
        """A tool not in any list is allowed with requires_approval=False."""
        from familiar.core.guardrails import GuardrailConfig, Guardrails

        g = Guardrails(GuardrailConfig())
        allowed, reason, requires_approval = g.check_tool_call("get_time", {}, tool_registry=None)
        assert allowed is True
        assert requires_approval is False

    def test_blocked_tool_denied_in_agent(self, monkeypatch):
        """An agent with a blocked tool returns the approval message from _execute_tool_secure."""
        from familiar.core.agent import Agent

        agent = Agent()
        # Block 'get_time' specifically for this test
        agent.guardrails.config.blocked_tools = ["get_time"]

        # Build a minimal session and context
        session = agent.sessions.get_or_create_session("test_block", "cli")
        context = {
            "user_id": "test_block",
            "channel": "cli",
            "session": session,
            "memory": None,
            "session_manager": agent.sessions,
            "agent": agent,
            "user_context": None,
        }

        result = agent._execute_tool_secure("get_time", {}, session, context)
        assert "⚠️" in result
        assert "blocked" in result.lower() or "get_time" in result

    # ── 5. end_request: rate-limit history recording ─────────────────────────

    def test_end_request_records_in_history(self):
        """end_request records the request so subsequent start_request sees it."""
        from familiar.core.guardrails import GuardrailConfig, Guardrails

        g = Guardrails(GuardrailConfig(max_requests_per_minute=5))
        tracker = g.start_request("hist_user")
        assert g._user_history["hist_user"].requests_last_minute() == 0
        g.end_request("hist_user", tracker)
        assert g._user_history["hist_user"].requests_last_minute() == 1

    def test_cost_recorded_in_history(self):
        """end_request records cost so hourly/daily limits apply across requests."""
        from familiar.core.guardrails import GuardrailConfig, Guardrails

        g = Guardrails(GuardrailConfig())
        tracker = g.start_request("cost_user")
        g.track_llm_usage(100, 100, 0.50, tracker)
        g.end_request("cost_user", tracker)
        assert g._user_history["cost_user"].cost_today() == pytest.approx(0.50, abs=0.01)

    # ── 6. _handle_guardrail_violation: message mapping ───────────────────────

    def test_violation_messages_are_user_friendly(self):
        """Every ViolationType maps to a clean message, no internal detail leaked."""
        from familiar.core.agent import Agent
        from familiar.core.guardrails import GuardrailViolation, ViolationAction, ViolationType

        agent = Agent()
        for vtype in ViolationType:
            gv = GuardrailViolation(vtype, "internal detail $$$", action=ViolationAction.BLOCK)
            msg = agent._handle_guardrail_violation(gv, "user1")
            assert isinstance(msg, str)
            assert "⚠️" in msg
            assert "internal detail" not in msg  # internal detail must not leak
            assert "vtype" not in msg

    # ── 7. Thread safety: tracker is explicit, not on self ────────────────────

    def test_tracker_is_explicit_not_stored_on_guardrails(self):
        """UsageTracker is returned from start_request and passed explicitly.
        self._current_tracker on Guardrails must remain None after start_request
        clears it — no shared-state races between concurrent requests."""
        from familiar.core.guardrails import GuardrailConfig, Guardrails

        g = Guardrails(GuardrailConfig())
        tracker = g.start_request("thread_user")
        # The tracker returned is what we use — _current_tracker may be set
        # but we never rely on it; explicit passing is what matters
        assert tracker is not None
        assert isinstance(tracker.total_tokens, int)
        g.end_request("thread_user", tracker)
        # After end_request, _current_tracker should be cleared
        assert g._current_tracker is None

    # ── 8. Content safety ─────────────────────────────────────────────────────

    def test_content_filter_blocks_dangerous_content(self):
        """ContentFilter via check_content blocks patterns from BLOCK_PATTERNS.
        Uses violence pattern: r'\\b(kill|murder|assassinate)\\s+(him|her|them|yourself|people)\\b'
        """
        from familiar.core.guardrails import Guardrails, GuardrailViolation, ViolationType

        g = Guardrails()
        with pytest.raises(GuardrailViolation) as exc_info:
            g.check_content("kill them all")  # matches violence BLOCK_PATTERN
        assert exc_info.value.violation_type == ViolationType.CONTENT_SAFETY

    def test_content_filter_passes_safe_content(self):
        """Normal messages pass check_content without raising."""
        from familiar.core.guardrails import Guardrails

        g = Guardrails()
        is_safe, reason = g.check_content("What's the weather like in Seattle?")
        assert is_safe is True

    # ── 9. Guardrails instantiated on Agent ──────────────────────────────────

    def test_guardrails_attribute_present_on_agent(self):
        """Agent always has a .guardrails attribute after __init__."""
        from familiar.core.agent import Agent
        from familiar.core.guardrails import Guardrails

        agent = Agent()
        assert hasattr(agent, "guardrails")
        assert isinstance(agent.guardrails, Guardrails)

    def test_guardrails_config_respects_agent_config(self):
        """GuardrailConfig is built from agent config attributes when present."""
        from familiar.core.agent import Agent

        agent = Agent()
        # Default max_iterations should match what's set on guardrails
        cfg_iter = agent.guardrails.config.max_iterations
        agent_iter = getattr(agent.config.agent, "max_iterations", 15)
        assert cfg_iter == agent_iter


# ---------------------------------------------------------------------------
# v1.1.13 — EpisodicMemory fully integrated
# ---------------------------------------------------------------------------


class TestEpisodicMemoryIntegration:
    """
    EpisodicMemory is wired into the agent at 2 points:

    1. _run_agent_loop (before LLM call):
       retrieve() relevant past exchanges → inject into system prompt
       under "## Past conversation context"

    2. _finalize_response (after response complete):
       store_conversation() the user+assistant turn pair →
       save async to ~/.familiar/episodic/{user_id}.json

    Separate from MemoryExtractor (fact extraction).
    EpisodicMemory stores conversation *exchanges* across sessions.
    """

    # ── Fixtures ─────────────────────────────────────────────────────────────

    @pytest.fixture
    def ep_config(self):
        """Config with episodic memory ENABLED."""
        cfg = load_config()
        cfg.llm.default_provider = "ollama"
        cfg.agent.memory_enabled = True  # ← enables episodic
        cfg.agent.scheduler_enabled = False
        return cfg

    @pytest.fixture
    def ep_agent(self, ep_config, mock_provider, tmp_path):
        from familiar.core.agent import Agent

        ep_dir = tmp_path / "episodic"
        ep_dir.mkdir()
        with (
            patch("familiar.core.agent.get_provider", return_value=mock_provider),
            patch("familiar.core.agent.get_best_ollama_model", return_value=None),
        ):
            a = Agent(config=ep_config)
            a.provider = mock_provider
            a._episodic_dir = ep_dir
            yield a

    @pytest.fixture(autouse=True)
    def isolate_episodic_dir(self, tmp_path, monkeypatch):
        """Redirect episodic storage to a temp dir so tests that create
        their own Agent never touch the real ~/.familiar/episodic/."""
        fake_home = tmp_path / "home"
        (fake_home / ".familiar" / "episodic").mkdir(parents=True)
        monkeypatch.setattr("familiar.core.agent.Path.home", staticmethod(lambda: fake_home))

    # ── 1. Agent initialisation ───────────────────────────────────────────────

    def test_episodic_enabled_when_memory_enabled(self, ep_config, mock_provider):
        """_episodic_enabled=True when config.agent.memory_enabled=True."""
        from familiar.core.agent import Agent

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            a = Agent(config=ep_config)
        assert a._episodic_enabled is True
        assert a._episodic_dir is not None

    def test_episodic_disabled_when_memory_disabled(self, config, mock_provider):
        """_episodic_enabled=False when config.agent.memory_enabled=False."""
        from familiar.core.agent import Agent

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            a = Agent(config=config)  # config has memory_enabled=False
        assert a._episodic_enabled is False
        assert a._episodic_dir is None

    def test_episodic_dir_created_on_init(self, ep_config, mock_provider):
        """_episodic_dir is created during __init__."""
        from familiar.core.agent import Agent

        with (
            patch("familiar.core.agent.get_provider", return_value=mock_provider),
            patch("familiar.core.agent.get_best_ollama_model", return_value=None),
        ):
            a = Agent(config=ep_config)
        assert a._episodic_dir.exists()

    def test_episodic_stores_dict_starts_empty(self, ep_agent):
        """_episodic_stores is empty before any request is processed."""
        assert isinstance(ep_agent._episodic_stores, dict)
        assert len(ep_agent._episodic_stores) == 0

    # ── 2. _get_episodic_memory — lazy init ──────────────────────────────────

    def test_get_episodic_memory_returns_memory_system(self, ep_agent):
        """_get_episodic_memory returns a MemorySystem for a user."""
        from familiar.core.episodic_memory import MemorySystem as EpisodicMemorySystem

        ms = ep_agent._get_episodic_memory("ep_user1")
        assert isinstance(ms, EpisodicMemorySystem)

    def test_get_episodic_memory_same_instance_on_repeat(self, ep_agent):
        """Calling _get_episodic_memory twice for same user returns same instance."""
        ms1 = ep_agent._get_episodic_memory("ep_user2")
        ms2 = ep_agent._get_episodic_memory("ep_user2")
        assert ms1 is ms2

    def test_get_episodic_memory_separate_per_user(self, ep_agent):
        """Different users get separate MemorySystem instances — data isolation."""
        ms_a = ep_agent._get_episodic_memory("ep_user_a")
        ms_b = ep_agent._get_episodic_memory("ep_user_b")
        assert ms_a is not ms_b

    def test_get_episodic_memory_returns_none_when_disabled(self, config, mock_provider):
        """Returns None when episodic memory is disabled."""
        from familiar.core.agent import Agent

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            a = Agent(config=config)  # memory_enabled=False
        result = a._get_episodic_memory("any_user")
        assert result is None

    def test_cross_user_data_isolation(self, ep_agent):
        """Memories stored for user A are not visible to user B."""
        ms_a = ep_agent._get_episodic_memory("iso_user_a")
        ms_b = ep_agent._get_episodic_memory("iso_user_b")

        ms_a.store_conversation(
            [
                {"role": "user", "content": "confidential: Q1 donor shortfall 50K"},
                {"role": "assistant", "content": "I have noted the shortfall"},
            ],
            conversation_id="private-conv",
            importance=0.9,
        )

        results_b = ms_b.retrieve("donor shortfall Q1", top_k=5)
        assert len(results_b) == 0, "User B should see zero of user A's memories"

    # ── 3. store_conversation wired in _finalize_response ────────────────────

    def test_conversation_stored_after_chat(self, ep_agent):
        """After chat(), the exchange is stored in the user's MemorySystem."""
        ep_agent.chat("What is the capital of France?", user_id="store_user")

        ms = ep_agent._get_episodic_memory("store_user")
        stats = ms.get_stats()
        assert stats["total_stored"] >= 2  # user turn + assistant turn

    def test_stored_memories_are_conversation_type(self, ep_agent):
        """Stored memories have MemoryType.CONVERSATION."""
        from familiar.core.episodic_memory import MemoryType

        ep_agent.chat("Tell me about Python decorators", user_id="type_user")

        ms = ep_agent._get_episodic_memory("type_user")
        memories = ms._index.get_all()
        types = {m.memory_type for m in memories}
        assert MemoryType.CONVERSATION in types

    def test_stored_memory_contains_user_message(self, ep_agent):
        """The user's message text is present in the stored memories."""
        ep_agent.chat("What is 2 + 2?", user_id="content_user")

        ms = ep_agent._get_episodic_memory("content_user")
        all_content = " ".join(m.content for m in ms._index.get_all())
        assert "2 + 2" in all_content

    def test_stored_memory_contains_assistant_response(self, ep_agent, mock_provider):
        """The assistant's response text is present in stored memories."""
        mock_provider.chat.return_value = LLMResponse(
            text="The answer is four.",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 5, "output_tokens": 5},
        )
        ep_agent.chat("What is 2 + 2?", user_id="resp_user")

        ms = ep_agent._get_episodic_memory("resp_user")
        all_content = " ".join(m.content for m in ms._index.get_all())
        assert "four" in all_content.lower() or "answer" in all_content.lower()

    def test_multiple_conversations_accumulate(self, ep_agent):
        """Multiple chat() calls accumulate memories in the same MemorySystem."""
        ep_agent.chat("First question about Python", user_id="accum_user")
        ep_agent.chat("Second question about databases", user_id="accum_user")
        ep_agent.chat("Third question about networking", user_id="accum_user")

        ms = ep_agent._get_episodic_memory("accum_user")
        stats = ms.get_stats()
        # Each chat stores 2 memories (user + assistant), so 3 chats = at least 6
        assert stats["total_stored"] >= 6

    def test_no_storage_when_memory_disabled(self, config, mock_provider):
        """No episodic storage occurs when memory_enabled=False."""
        from familiar.core.agent import Agent

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            a = Agent(config=config)
            a.provider = mock_provider

            a.chat("Hello", user_id="no_ep_user")
        assert len(a._episodic_stores) == 0

    # ── 4. Retrieval injected into system prompt ──────────────────────────────

    def test_retrieval_returns_relevant_memories(self, ep_agent, mock_provider):
        """After one chat, retrieve() for a related query surfaces that exchange."""
        mock_provider.chat.return_value = LLMResponse(
            text="You can use pandas DataFrame.to_csv() to export data.",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 10, "output_tokens": 20},
        )
        ep_agent.chat("How do I export data to CSV in pandas?", user_id="ret_user")

        ms = ep_agent._get_episodic_memory("ret_user")
        results = ms.retrieve("export CSV pandas data", top_k=5)
        assert len(results) > 0
        # At least one result should mention pandas or CSV
        content_combined = " ".join(r.content for r in results).lower()
        assert (
            "csv" in content_combined
            or "pandas" in content_combined
            or "export" in content_combined
        )

    def test_irrelevant_query_retrieves_lower_scores(self, ep_agent, mock_provider):
        """A completely unrelated query should still work — just returns best-effort."""
        mock_provider.chat.return_value = LLMResponse(
            text="Sourdough needs a 75% hydration starter.",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 10, "output_tokens": 15},
        )
        ep_agent.chat("How do I make sourdough bread?", user_id="irrel_user")

        ms = ep_agent._get_episodic_memory("irrel_user")
        # Retrieve with unrelated query — should not raise, just return something
        results = ms.retrieve("quantum physics Higgs boson", top_k=5)
        # It returns memories (sorted by combined score) but doesn't crash
        assert isinstance(results, list)

    # ── 5. Persistence — save async + load on next agent init ─────────────────

    def test_save_async_creates_json_file(self, ep_agent):
        """After chat, a JSON file is written to the episodic dir for the user."""
        import time

        ep_agent.chat("Persist this conversation", user_id="persist_user")
        # Give the daemon thread a moment to write
        time.sleep(0.2)

        expected = ep_agent._episodic_dir / "persist_user.json"
        assert expected.exists(), f"Expected {expected} to exist after async save"

    def test_saved_json_is_valid(self, ep_agent):
        """The saved JSON file is valid and contains memories."""
        import time

        ep_agent.chat("Save me to disk", user_id="valid_json_user")
        time.sleep(0.2)

        filepath = ep_agent._episodic_dir / "valid_json_user.json"
        assert filepath.exists()
        data = json.loads(filepath.read_text())
        assert "memories" in data
        assert len(data["memories"]) >= 2

    def test_memories_survive_agent_restart(self, ep_config, mock_provider):
        """Memories persisted by one agent are loaded by a fresh agent instance."""
        import time

        from familiar.core.agent import Agent

        # First agent — store a conversation
        with (
            patch("familiar.core.agent.get_provider", return_value=mock_provider),
            patch("familiar.core.agent.get_best_ollama_model", return_value=None),
        ):
            agent1 = Agent(config=ep_config)
            agent1.provider = mock_provider
            agent1.chat("Remember: the project deadline is March 15", user_id="persist2_user")
            time.sleep(0.2)  # let async save complete

        # Second agent — fresh instance, same episodic dir
        with (
            patch("familiar.core.agent.get_provider", return_value=mock_provider),
            patch("familiar.core.agent.get_best_ollama_model", return_value=None),
        ):
            agent2 = Agent(config=ep_config)
            agent2.provider = mock_provider

            # Load memories for the same user
            ms2 = agent2._get_episodic_memory("persist2_user")
            stats = ms2.get_stats()
            assert stats["total_stored"] >= 2, "Fresh agent should load persisted memories from disk"
            all_content = " ".join(m.content for m in ms2._index.get_all()).lower()
            assert "deadline" in all_content or "march" in all_content

    def test_no_file_written_when_memory_disabled(self, config, mock_provider):
        """No episodic JSON file is written when memory_enabled=False."""
        import time

        from familiar.core.agent import Agent

        with (
            patch("familiar.core.agent.get_provider", return_value=mock_provider),
            patch("familiar.core.agent.get_best_ollama_model", return_value=None),
        ):
            a = Agent(config=config)
            a.provider = mock_provider
            a.chat("No persistence please", user_id="no_persist_user")
            time.sleep(0.15)

        # episodic dir should not even exist if memory is disabled
        assert a._episodic_dir is None

    # ── 6. MemorySystem internals work correctly ──────────────────────────────

    def test_memory_system_store_and_retrieve(self):
        """MemorySystem.store_conversation + retrieve round-trip."""
        from familiar.core.episodic_memory import MemorySystem

        ms = MemorySystem()
        ms.store_conversation(
            [
                {"role": "user", "content": "What is teleparallel gravity?"},
                {
                    "role": "assistant",
                    "content": "Teleparallel gravity uses torsion instead of curvature.",
                },
            ],
            conversation_id="phys-conv",
            importance=0.7,
        )
        results = ms.retrieve("torsion gravity physics", top_k=5)
        assert len(results) == 2
        content = " ".join(r.content for r in results).lower()
        assert "torsion" in content or "gravity" in content

    def test_memory_decay_reduces_strength(self):
        """Memory strength decreases after simulated time passage."""
        from datetime import datetime, timedelta, timezone

        from familiar.core.episodic_memory import Memory, MemorySystem, MemoryType

        ms = MemorySystem(decay_rate=10.0)  # aggressive decay for testing
        m = Memory(
            content="Old memory",
            memory_type=MemoryType.CONVERSATION,
            importance=0.8,
        )
        # Simulate that this memory was last accessed 5 days ago
        m.last_accessed = datetime.now(timezone.utc) - timedelta(days=5)
        ms._index.add(m)
        ms._working_memory.add(m)

        original_strength = m.current_strength
        decayed = m.decay(decay_rate=10.0)
        assert decayed < original_strength, "Decay should reduce strength"

    def test_memory_reinforcement_boosts_strength(self):
        """Accessing a memory reinforces it (increases importance, resets last_accessed)."""
        from familiar.core.episodic_memory import Memory

        m = Memory(content="Reinforced memory", importance=0.5)
        original_importance = m.importance
        m.reinforce()
        assert m.importance >= original_importance
        assert m.access_count == 1

    def test_working_memory_context_string_format(self):
        """get_context_string returns properly formatted lines after retrieve() populates it.
        Note: store_conversation uses add_to_working=False internally, so working memory
        is only populated after retrieve() is called."""
        from familiar.core.episodic_memory import MemorySystem

        ms = MemorySystem()
        ms.store_conversation(
            [
                {"role": "user", "content": "test message"},
                {"role": "assistant", "content": "test response"},
            ],
            conversation_id="wm-test",
        )
        # retrieve() adds results to working memory
        ms.retrieve("test message", top_k=5)
        ctx = ms.working_memory.get_context_string(max_tokens=1000)
        assert isinstance(ctx, str)
        assert len(ctx) > 0
        # Each line should be prefixed with the memory type
        assert "[conversation]" in ctx

    def test_file_persistence_round_trip(self, tmp_path):
        """FileMemoryPersistence correctly saves and reloads all memories."""
        from familiar.core.episodic_memory import FileMemoryPersistence, MemorySystem

        ms1 = MemorySystem()
        ms1.store_conversation(
            [
                {"role": "user", "content": "persist this exchange"},
                {"role": "assistant", "content": "it has been persisted"},
            ],
            conversation_id="persist-test",
            importance=0.6,
        )

        filepath = str(tmp_path / "test_memories.json")
        fp = FileMemoryPersistence(filepath)
        saved = fp.save(ms1)
        assert saved is True

        ms2 = MemorySystem()
        loaded = fp.load(ms2)
        assert loaded is True
        assert ms2.get_stats()["total_stored"] == ms1.get_stats()["total_stored"]

        # Content must survive round-trip
        results = ms2.retrieve("persist exchange", top_k=5)
        assert len(results) > 0

    def test_memory_system_concurrent_users(self, ep_agent):
        """Multiple users' MemorySystems are independent under concurrent-style access."""
        import threading

        errors = []

        def store_for(user_id, content):
            try:
                ms = ep_agent._get_episodic_memory(user_id)
                ms.store_conversation(
                    [
                        {"role": "user", "content": content},
                        {"role": "assistant", "content": f"response to {content}"},
                    ],
                    conversation_id=f"conv-{user_id}",
                )
            except Exception as e:
                errors.append(e)

        threads = [
            threading.Thread(target=store_for, args=(f"concurrent_user_{i}", f"message {i}"))
            for i in range(5)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == [], f"Concurrent access caused errors: {errors}"
        # Each user should have their own isolated store
        for i in range(5):
            ms = ep_agent._get_episodic_memory(f"concurrent_user_{i}")
            assert ms.get_stats()["total_stored"] >= 2

    # ── 7. Edge cases ─────────────────────────────────────────────────────────

    def test_empty_response_fallback_stored(self, ep_agent, mock_provider):
        """Empty text response uses '(no response)' fallback — still stored.
        The agent substitutes '(no response)' for falsy text, which is truthy,
        so store_conversation is still called."""
        mock_provider.chat.return_value = LLMResponse(
            text="",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 5, "output_tokens": 0},
        )
        ep_agent.chat("Silence?", user_id="empty_resp_user")
        ms = ep_agent._get_episodic_memory("empty_resp_user")
        # agent converts "" → "(no response)" which is truthy → stored
        assert ms.get_stats()["total_stored"] >= 2
        all_content = " ".join(m.content for m in ms._index.get_all()).lower()
        assert "no response" in all_content or "silence" in all_content

    def test_get_episodic_memory_thread_safe(self, ep_agent):
        """Concurrent calls to _get_episodic_memory for the same user return the same instance."""
        import threading

        instances = []
        lock = threading.Lock()

        def get_ms():
            ms = ep_agent._get_episodic_memory("thread_safe_user")
            with lock:
                instances.append(ms)

        threads = [threading.Thread(target=get_ms) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(instances) == 10
        # All must be the same object
        assert all(ms is instances[0] for ms in instances), (
            "Thread-safe lazy init must return same instance to all threads"
        )


# ---------------------------------------------------------------------------
# v1.1.16 — EventEmitter fully integrated
# ---------------------------------------------------------------------------


class TestEventEmitterIntegration:
    """
    EventEmitter is wired into the agent at tool execution time.

    One EventEmitter per request, placed in tool_context["emitter"].
    The agent emits TOOL_START / TOOL_COMPLETE / TOOL_ERROR / TOOL_RETRY
    automatically for every tool call. Tools may optionally call
    emitter.tool_progress() themselves for long-running operations.

    Clients subscribe a callback via agent.set_tool_event_callback(user_id, fn)
    before the request to receive structured ExecutionEvent objects.
    """

    # ── Unit: EventEmitter standalone ────────────────────────────────────────

    def test_emitter_assigns_sequence_numbers(self):
        from familiar.core.event_emitter import EventEmitter

        emitter = EventEmitter(execution_id="seq-test")
        received = []
        emitter.subscribe(received.append)
        emitter.tool_start("tool_a", {})
        emitter.tool_progress("tool_a", 50.0)
        emitter.tool_complete("tool_a", result="ok", elapsed_ms=100.0)
        seqs = [e.sequence for e in received]
        assert seqs == [0, 1, 2], f"Sequences should be 0,1,2 got {seqs}"

    def test_emitter_stamps_execution_id(self):
        from familiar.core.event_emitter import EventEmitter

        emitter = EventEmitter(execution_id="eid-42")
        events = []
        emitter.subscribe(events.append)
        emitter.status("hello")
        assert events[0].execution_id == "eid-42"

    def test_emitter_callback_receives_all_events(self):
        from familiar.core.event_emitter import EventEmitter, EventType

        emitter = EventEmitter(execution_id="cb-test")
        received = []
        emitter.subscribe(received.append)
        emitter.tool_start("t", {})
        emitter.tool_progress("t", 25.0, "quarter way")
        emitter.tool_progress("t", 75.0, "three quarter")
        emitter.tool_complete("t", result="done", elapsed_ms=42.0)
        assert len(received) == 4
        types = [e.type for e in received]
        assert EventType.TOOL_START in types
        assert EventType.TOOL_PROGRESS in types
        assert EventType.TOOL_COMPLETE in types

    def test_emitter_multiple_callbacks(self):
        from familiar.core.event_emitter import EventEmitter

        emitter = EventEmitter(execution_id="multi-cb")
        a, b = [], []
        emitter.subscribe(a.append)
        emitter.subscribe(b.append)
        emitter.status("ping")
        assert len(a) == 1 and len(b) == 1

    def test_emitter_unsubscribe(self):
        from familiar.core.event_emitter import EventEmitter

        emitter = EventEmitter(execution_id="unsub-test")
        received = []
        cb = received.append
        emitter.subscribe(cb)
        emitter.status("before")
        emitter.unsubscribe(cb)
        emitter.status("after")
        assert len(received) == 1, "Should only have received event before unsubscribe"

    def test_emitter_sync_queue(self):
        from familiar.core.event_emitter import EventEmitter

        emitter = EventEmitter(execution_id="queue-test")
        q = emitter.create_sync_queue()
        emitter.thinking("reasoning...")
        emitter.tool_start("search", {"query": "donors"})
        assert q.qsize() == 2
        evt1 = q.get_nowait()
        evt2 = q.get_nowait()
        assert evt1.content == "reasoning..."
        assert evt2.tool_name == "search"

    def test_emitter_history_disabled_by_default(self):
        from familiar.core.event_emitter import EventEmitter

        emitter = EventEmitter(execution_id="hist-off")
        emitter.status("test")
        assert emitter.get_history() == []

    def test_emitter_history_enabled(self):
        from familiar.core.event_emitter import EventEmitter

        emitter = EventEmitter(execution_id="hist-on")
        emitter.enable_history(max_events=10)
        emitter.tool_start("t", {})
        emitter.tool_complete("t", result="r", elapsed_ms=1.0)
        history = emitter.get_history()
        assert len(history) == 2

    def test_emitter_history_max_capped(self):
        from familiar.core.event_emitter import EventEmitter

        emitter = EventEmitter(execution_id="hist-cap")
        emitter.enable_history(max_events=3)
        for i in range(10):
            emitter.status(f"msg {i}")
        assert len(emitter.get_history()) == 3

    def test_emitter_callback_error_does_not_propagate(self):
        from familiar.core.event_emitter import EventEmitter

        emitter = EventEmitter(execution_id="err-cb")
        emitter.subscribe(lambda e: 1 / 0)  # always raises
        # Should not raise — errors in callbacks are swallowed and logged
        emitter.status("should not crash")

    def test_execution_event_to_dict_round_trip(self):
        from familiar.core.event_emitter import EventEmitter, EventType, ExecutionEvent

        emitter = EventEmitter(execution_id="serial-test")
        events = []
        emitter.subscribe(events.append)
        emitter.tool_start("export_csv", {"table": "donors"})
        evt = events[0]
        d = evt.to_dict()
        assert d["type"] == "tool_start"
        assert d["tool_name"] == "export_csv"
        e2 = ExecutionEvent.from_dict(d)
        assert e2.type == EventType.TOOL_START
        assert e2.tool_name == "export_csv"
        assert e2.execution_id == "serial-test"

    def test_tool_retry_event_fields(self):
        from familiar.core.event_emitter import EventEmitter, EventType

        emitter = EventEmitter(execution_id="retry-test")
        events = []
        emitter.subscribe(events.append)
        emitter.tool_retry("fetch_data", attempt=2, reason="timeout")
        evt = events[0]
        assert evt.type == EventType.TOOL_RETRY
        assert evt.data["attempt"] == 2
        assert evt.data["reason"] == "timeout"

    def test_concurrent_emit_thread_safe(self):
        """Sequence numbers must be monotonically increasing under concurrent emit."""
        import threading

        from familiar.core.event_emitter import EventEmitter

        emitter = EventEmitter(execution_id="concurrent")
        collected = []
        lock = threading.Lock()
        emitter.subscribe(lambda e: (lock.acquire(), collected.append(e.sequence), lock.release()))

        threads = [threading.Thread(target=lambda: emitter.status("ping")) for _ in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(collected) == 20
        # All sequences should be unique (even if not in order due to threading)
        assert len(set(collected)) == 20, "All sequence numbers must be unique"

    # ── Integration: emitter wired into agent tool_context ───────────────────

    def test_emitter_present_in_tool_context(self, agent, mock_provider):
        """tool_context["emitter"] is an EventEmitter instance on every request."""
        from familiar.core.event_emitter import EventEmitter
        from familiar.core.providers import LLMResponse, ToolCall

        captured_context = {}

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc_ctx", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 10, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 20, "output_tokens": 4},
            ),
        ]

        original_execute = agent._execute_tool_secure

        def capturing_execute(tool_name, tool_input, session, tool_context, trace):
            captured_context.update(tool_context)
            return original_execute(tool_name, tool_input, session, tool_context, trace)

        agent._execute_tool_secure = capturing_execute

        agent.chat("What time is it?", user_id="ctx_user")

        assert "emitter" in captured_context, "tool_context must contain 'emitter'"
        assert isinstance(captured_context["emitter"], EventEmitter)

    def test_agent_emits_tool_start_via_emitter(self, agent, mock_provider):
        """TOOL_START ExecutionEvent is emitted for every tool call."""
        from familiar.core.event_emitter import EventType
        from familiar.core.providers import LLMResponse, ToolCall

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 10, "output_tokens": 5},
            ),
            LLMResponse(
                text="It is 3pm.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 20, "output_tokens": 8},
            ),
        ]

        received = []
        agent.set_tool_event_callback("emit_user", received.append)
        agent.chat("What time is it?", user_id="emit_user")

        tool_starts = [e for e in received if e.type == EventType.TOOL_START]
        assert len(tool_starts) >= 1, "Expected at least one TOOL_START event"
        assert tool_starts[0].tool_name == "get_current_time"

    def test_agent_emits_tool_complete_on_success(self, agent, mock_provider):
        """TOOL_COMPLETE ExecutionEvent is emitted after successful tool execution."""
        from familiar.core.event_emitter import EventType
        from familiar.core.providers import LLMResponse, ToolCall

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc2", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 10, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 20, "output_tokens": 4},
            ),
        ]

        received = []
        agent.set_tool_event_callback("complete_user", received.append)
        agent.chat("Use the time tool", user_id="complete_user")

        tool_completes = [e for e in received if e.type == EventType.TOOL_COMPLETE]
        assert len(tool_completes) >= 1
        assert tool_completes[0].tool_name == "get_current_time"
        assert tool_completes[0].elapsed_ms is not None
        assert tool_completes[0].elapsed_ms >= 0

    def test_set_and_clear_callback(self, agent):
        """set_tool_event_callback and clear_tool_event_callback manage registry."""
        received_a = []
        received_b = []

        agent.set_tool_event_callback("cb_user", received_a.append)
        agent.chat("Hello", user_id="cb_user")
        count_a = len(received_a)

        agent.set_tool_event_callback("cb_user", received_b.append)
        agent.chat("Hello again", user_id="cb_user")
        # received_a should not have grown (callback was replaced)
        assert len(received_a) == count_a, (
            "Old callback should not receive events after replacement"
        )

        agent.clear_tool_event_callback("cb_user")
        pre_clear_b = len(received_b)
        agent.chat("Third message", user_id="cb_user")
        assert len(received_b) == pre_clear_b, "Cleared callback should receive nothing"

    def test_callback_isolation_per_user(self, agent, mock_provider):
        """Callbacks are per-user — user A's callback doesn't fire for user B."""
        received_a = []
        received_b = []

        agent.set_tool_event_callback("iso_a", received_a.append)
        agent.set_tool_event_callback("iso_b", received_b.append)

        agent.chat("Hello from A", user_id="iso_a")
        count_a_after = len(received_a)
        count_b_after_a = len(received_b)

        agent.chat("Hello from B", user_id="iso_b")
        count_a_final = len(received_a)

        # A's callback should not have grown from B's request
        assert count_a_final == count_a_after, "User A callback fired on user B's request"
        # B should have gotten their own events
        assert len(received_b) >= count_b_after_a

    def test_no_callback_no_error(self, agent):
        """Requests without a registered callback work normally — no crash."""
        # No callback set for this user — emitter created with no subscribers
        result = agent.chat("Hello with no callback", user_id="no_cb_user")
        assert result is not None

    def test_tool_event_callback_receives_execution_id(self, agent, mock_provider):
        """All events from a single request share the same execution_id."""
        from familiar.core.providers import LLMResponse, ToolCall

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc3", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 10, "output_tokens": 5},
            ),
            LLMResponse(
                text="OK.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 20, "output_tokens": 3},
            ),
        ]

        received = []
        agent.set_tool_event_callback("eid_user", received.append)
        agent.chat("Run the time tool", user_id="eid_user")

        exec_ids = {e.execution_id for e in received}
        assert len(exec_ids) == 1, f"All events should share one execution_id, got: {exec_ids}"


# ---------------------------------------------------------------------------
# v1.1.17 — EpisodicMemory encryption at rest
# ---------------------------------------------------------------------------


class TestEpisodicMemoryEncryption:
    """
    EpisodicMemory now mirrors core/memory.py's encryption behaviour:

    - FAMILIAR_ENCRYPTION_KEY not set → plaintext {user_id}.json
    - FAMILIAR_ENCRYPTION_KEY set + cryptography installed →
        encrypted {user_id}.json.enc, no plaintext left on disk
    - Load order: .json.enc first (if encryption available), then .json fallback
    - Migration: plaintext file detected when encryption now available →
        logged, migrated to encrypted on next save
    - Atomic writes: .enc.tmp → replace → .enc  (no partial writes)
    """

    class _MockEncStorage:
        """
        Minimal EncryptedStorage stand-in.
        encrypt/decrypt are inverses; the ciphertext is prefixed so tests
        can assert the raw JSON is NOT visible in the file.
        """

        is_available = True

        def encrypt(self, plaintext: str) -> str:
            import base64

            return "ENC:" + base64.b64encode(plaintext.encode()).decode()

        def decrypt(self, ciphertext: str) -> str:
            import base64

            return base64.b64decode(ciphertext.removeprefix("ENC:")).decode()

    @pytest.fixture
    def ep_config_enc(self):
        cfg = load_config()
        cfg.llm.default_provider = "ollama"
        cfg.agent.memory_enabled = True
        cfg.agent.scheduler_enabled = False
        return cfg

    @pytest.fixture
    def enc_agent(self, ep_config_enc, mock_provider, tmp_path, monkeypatch):
        """Agent with episodic encryption mocked and storage in tmp_path."""
        import familiar.core.agent as agent_mod

        monkeypatch.setattr(agent_mod, "_episodic_encryption", self._MockEncStorage())
        monkeypatch.setattr(agent_mod, "_episodic_encryption_initialized", True)

        with (
            patch("familiar.core.agent.get_provider", return_value=mock_provider),
            patch("familiar.core.agent.get_best_ollama_model", return_value=None),
        ):
            a = agent_mod.Agent(config=ep_config_enc)
            a.provider = mock_provider
            a._episodic_dir = tmp_path
            a._episodic_stores = {}
            yield a

    @pytest.fixture
    def plain_agent(self, ep_config_enc, mock_provider, tmp_path, monkeypatch):
        """Agent with NO encryption (key not set)."""
        import familiar.core.agent as agent_mod

        monkeypatch.setattr(agent_mod, "_episodic_encryption", None)
        monkeypatch.setattr(agent_mod, "_episodic_encryption_initialized", True)

        with (
            patch("familiar.core.agent.get_provider", return_value=mock_provider),
            patch("familiar.core.agent.get_best_ollama_model", return_value=None),
        ):
            a = agent_mod.Agent(config=ep_config_enc)
            a.provider = mock_provider
            a._episodic_dir = tmp_path
            a._episodic_stores = {}
            yield a

    # ── Plaintext path (no encryption key) ───────────────────────────────────

    def test_plaintext_file_written_when_no_key(self, plain_agent, tmp_path):
        """Without encryption key, memories write to {uid}.json."""
        import time

        plain_agent.chat("store this", user_id="plain_user")
        time.sleep(0.25)
        plain_file = tmp_path / "plain_user.json"
        enc_file = tmp_path / "plain_user.json.enc"
        assert plain_file.exists(), "Plaintext file should exist"
        assert not enc_file.exists(), "Encrypted file should NOT exist"

    def test_plaintext_file_is_valid_json(self, plain_agent, tmp_path):
        """Plaintext file is readable JSON with a 'memories' key."""
        import time

        plain_agent.chat("plaintext content", user_id="json_user")
        time.sleep(0.25)
        data = json.loads((tmp_path / "json_user.json").read_text())
        assert "memories" in data
        assert isinstance(data["memories"], list)

    def test_plaintext_load_restores_memories(
        self, ep_config_enc, mock_provider, tmp_path, monkeypatch
    ):
        """Memories saved plaintext survive an agent restart."""
        import time

        import familiar.core.agent as agent_mod

        monkeypatch.setattr(agent_mod, "_episodic_encryption", None)
        monkeypatch.setattr(agent_mod, "_episodic_encryption_initialized", True)

        with (
            patch("familiar.core.agent.get_provider", return_value=mock_provider),
            patch("familiar.core.agent.get_best_ollama_model", return_value=None),
        ):
            a1 = agent_mod.Agent(config=ep_config_enc)
            a1.provider = mock_provider
            a1._episodic_dir = tmp_path
            a1._episodic_stores = {}

            a1.chat("remember the deadline is Friday", user_id="restart_user")
            time.sleep(0.25)

        with (
            patch("familiar.core.agent.get_provider", return_value=mock_provider),
            patch("familiar.core.agent.get_best_ollama_model", return_value=None),
        ):
            a2 = agent_mod.Agent(config=ep_config_enc)
            a2._episodic_dir = tmp_path
            a2._episodic_stores = {}
            ms2 = a2._get_episodic_memory("restart_user")
            content = " ".join(m.content for m in ms2._index.get_all()).lower()
            assert "deadline" in content or "friday" in content

    # ── Encrypted path (key present) ─────────────────────────────────────────

    def test_encrypted_file_written_when_key_set(self, enc_agent, tmp_path):
        """With encryption active, .json.enc is written, .json is absent."""
        import time

        enc_agent.chat("sensitive information", user_id="enc_user")
        time.sleep(0.25)
        assert (tmp_path / "enc_user.json.enc").exists(), ".json.enc should exist"
        assert not (tmp_path / "enc_user.json").exists(), ".json should NOT exist"

    def test_encrypted_file_content_is_not_raw_json(self, enc_agent, tmp_path):
        """The .json.enc file should not contain plaintext memory content."""
        import time

        enc_agent.chat("classified donor list", user_id="enc_user2")
        time.sleep(0.25)
        raw = (tmp_path / "enc_user2.json.enc").read_text()
        # The mock prefixes with ENC: and base64-encodes — raw JSON not visible
        assert "classified donor list" not in raw, (
            "PHI/PII must not appear in plaintext within the encrypted file"
        )
        assert raw.startswith("ENC:"), "File should be encrypted by mock"

    def test_encrypted_load_restores_memories(self, enc_agent, tmp_path):
        """Encrypted memories survive a reload into a fresh MemorySystem."""
        import time

        import familiar.core.agent as agent_mod

        enc_agent.chat("the Q1 campaign shortfall is 50K", user_id="enc_reload")
        time.sleep(0.25)

        # Create a fresh agent pointing at the same dir, same mock encryption
        # (monkeypatch from enc_agent fixture already set the singletons)
        from familiar.core.agent import Agent

        with patch("familiar.core.agent.get_provider", return_value=enc_agent.provider):
            a2 = Agent(config=enc_agent.config)
        a2._episodic_dir = tmp_path
        a2._episodic_stores = {}

        ms2 = a2._get_episodic_memory("enc_reload")
        content = " ".join(m.content for m in ms2._index.get_all()).lower()
        assert "shortfall" in content or "50k" in content or "campaign" in content, (
            "Decrypted memories should contain the stored content"
        )

    def test_encrypted_atomic_write_no_tmp_left(self, enc_agent, tmp_path):
        """After save, no .enc.tmp file should remain (atomic replace)."""
        import time

        enc_agent.chat("atomic write test", user_id="atomic_user")
        time.sleep(0.25)
        tmp_file = tmp_path / "atomic_user.json.enc.tmp"
        assert not tmp_file.exists(), ".enc.tmp should be replaced atomically"

    def test_plaintext_removed_after_encrypted_save(self, enc_agent, tmp_path):
        """If a stale plaintext file exists, encrypted save removes it."""
        import time

        # Pre-create a stale plaintext file with valid stats so import_memories succeeds
        stale = tmp_path / "migrate_user.json"
        stale.write_text(
            json.dumps(
                {
                    "memories": [],
                    "stats": {
                        "total_stored": 0,
                        "total_retrieved": 0,
                        "total_forgotten": 0,
                        "total_consolidated": 0,
                    },
                    "exported_at": "2025-01-01T00:00:00+00:00",
                }
            )
        )

        enc_agent.chat("trigger migration", user_id="migrate_user")
        time.sleep(0.5)  # wait for async save thread

        assert (tmp_path / "migrate_user.json.enc").exists(), "Encrypted file should exist"
        assert not stale.exists(), "Stale plaintext should be removed after encrypted save"

    # ── Load order priority ───────────────────────────────────────────────────

    def test_encrypted_file_takes_priority_over_plaintext(
        self, tmp_path, ep_config_enc, mock_provider, monkeypatch
    ):
        """When both .json and .json.enc exist, encrypted is loaded."""
        import familiar.core.agent as agent_mod

        monkeypatch.setattr(agent_mod, "_episodic_encryption", self._MockEncStorage())
        monkeypatch.setattr(agent_mod, "_episodic_encryption_initialized", True)

        # Write a plaintext file with 'old' content
        plain = tmp_path / "priority_user.json"
        plain.write_text(
            json.dumps(
                {
                    "memories": [
                        {
                            "id": "00000000-0000-0000-0000-000000000001",
                            "content": "[user]: old plaintext memory",
                            "memory_type": "conversation",
                            "importance": 0.5,
                            "current_strength": 0.5,
                            "status": "active",
                            "created_at": "2025-01-01T00:00:00+00:00",
                            "last_accessed": "2025-01-01T00:00:00+00:00",
                            "access_count": 0,
                            "tags": [],
                            "associations": [],
                            "source": "test",
                            "context": {},
                            "conversation_id": "old-conv",
                            "metadata": {},
                            "embedding": None,
                        }
                    ],
                    "stats": {},
                    "exported_at": "2025-01-01T00:00:00+00:00",
                }
            )
        )

        # Write an encrypted file with 'new' content
        enc = self._MockEncStorage()
        new_data = {
            "memories": [
                {
                    "id": "00000000-0000-0000-0000-000000000002",
                    "content": "[user]: encrypted priority memory",
                    "memory_type": "conversation",
                    "importance": 0.5,
                    "current_strength": 0.5,
                    "status": "active",
                    "created_at": "2025-01-01T00:00:00+00:00",
                    "last_accessed": "2025-01-01T00:00:00+00:00",
                    "access_count": 0,
                    "tags": [],
                    "associations": [],
                    "source": "test",
                    "context": {},
                    "conversation_id": "new-conv",
                    "metadata": {},
                    "embedding": None,
                }
            ],
            "stats": {},
            "exported_at": "2025-02-01T00:00:00+00:00",
        }
        (tmp_path / "priority_user.json.enc").write_text(enc.encrypt(json.dumps(new_data)))

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            a = agent_mod.Agent(config=ep_config_enc)
        a._episodic_dir = tmp_path
        a._episodic_stores = {}

        ms = a._get_episodic_memory("priority_user")
        content = " ".join(m.content for m in ms._index.get_all())
        assert "encrypted priority memory" in content, (
            "Encrypted file should take priority over plaintext"
        )
        assert "old plaintext memory" not in content, (
            "Plaintext file should NOT be loaded when encrypted file exists"
        )

    # ── Edge cases ────────────────────────────────────────────────────────────

    def test_corrupted_encrypted_file_starts_fresh(
        self, tmp_path, ep_config_enc, mock_provider, monkeypatch
    ):
        """A corrupted .enc file causes a fresh empty store — not a crash."""
        import familiar.core.agent as agent_mod

        monkeypatch.setattr(agent_mod, "_episodic_encryption", self._MockEncStorage())
        monkeypatch.setattr(agent_mod, "_episodic_encryption_initialized", True)

        # Write a corrupted encrypted file
        (tmp_path / "corrupt_user.json.enc").write_text("ENC:not-valid-base64!!!")

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            a = agent_mod.Agent(config=ep_config_enc)
        a._episodic_dir = tmp_path
        a._episodic_stores = {}

        # Should not raise — returns empty MemorySystem
        ms = a._get_episodic_memory("corrupt_user")
        assert ms is not None
        assert ms.get_stats()["total_stored"] == 0

    def test_no_file_starts_fresh(self, plain_agent):
        """User with no existing file starts with empty memory — no error."""
        ms = plain_agent._get_episodic_memory("brand_new_user")
        assert ms is not None
        assert ms.get_stats()["total_stored"] == 0


# ---------------------------------------------------------------------------
# v1.1.18 — StructuredGenerator wired into tool_context
# ---------------------------------------------------------------------------


class TestStructuredOutputIntegration:
    """
    StructuredGenerator is wired into tool_context["structured"] on every request.

    Tools can call tool_context["structured"].generate(schema, prompt) to get
    validated, schema-compliant data from the LLM without managing retries or
    JSON extraction themselves.

    The generator wraps self.provider.chat through a thin adapter that bridges
    StructuredGenerator's (messages, model) call convention to provider.chat's
    (messages, tools, system, max_tokens) signature.

    Provider swaps (fallback routing mid-request) are picked up automatically
    because the adapter closes over `agent_ref.provider` rather than a snapshot.
    """

    # ── Unit: StructuredGenerator standalone ─────────────────────────────────

    def test_extract_json_from_markdown_block(self):
        from familiar.core.structured_output import ExtractionMethod, extract_json

        text = '```json\n{"name": "George", "score": 95}\n```'
        data, err = extract_json(text, ExtractionMethod.FIRST_JSON)
        assert err is None
        assert data == {"name": "George", "score": 95}

    def test_extract_json_bare_object(self):
        from familiar.core.structured_output import ExtractionMethod, extract_json

        text = 'Here is the result: {"value": 42}'
        data, err = extract_json(text, ExtractionMethod.FIRST_JSON)
        assert data is not None
        assert data["value"] == 42

    def test_extract_json_empty_returns_none(self):
        from familiar.core.structured_output import ExtractionMethod, extract_json

        data, err = extract_json("", ExtractionMethod.FIRST_JSON)
        assert data is None
        assert err is not None

    def test_extract_json_no_json_returns_none(self):
        from familiar.core.structured_output import ExtractionMethod, extract_json

        data, err = extract_json("This is plain text with no JSON.", ExtractionMethod.FIRST_JSON)
        assert data is None

    def test_repair_json_trailing_comma(self):
        from familiar.core.structured_output import ExtractionMethod, extract_json, repair_json

        malformed = '{"key": "value",}'
        repaired = repair_json(malformed)
        data, err = extract_json(repaired, ExtractionMethod.FULL_RESPONSE)
        assert data is not None
        assert data["key"] == "value"

    def test_repair_json_python_booleans(self):
        from familiar.core.structured_output import repair_json

        fixed = repair_json('{"active": True, "deleted": False, "value": None}')
        import json

        data = json.loads(fixed)
        assert data["active"] is True
        assert data["deleted"] is False
        assert data["value"] is None

    def test_validate_against_schema_valid_dict(self):
        from familiar.core.structured_output import validate_against_schema

        schema = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "amount": {"type": "number"},
            },
            "required": ["name", "amount"],
        }
        result = validate_against_schema({"name": "Grant A", "amount": 50000.0}, schema)
        assert result.valid
        assert result.data["name"] == "Grant A"

    def test_validate_against_schema_missing_required(self):
        from familiar.core.structured_output import validate_against_schema

        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}, "amount": {"type": "number"}},
            "required": ["name", "amount"],
        }
        result = validate_against_schema({"name": "Only name"}, schema)
        assert not result.valid
        assert any("amount" in str(e) for e in result.errors)

    def test_validate_against_schema_wrong_type(self):
        from familiar.core.structured_output import validate_against_schema

        schema = {"type": "object", "properties": {"count": {"type": "integer"}}}
        result = validate_against_schema("not a dict", schema)
        assert not result.valid

    def test_generation_result_bool_true(self):
        from familiar.core.structured_output import GenerationResult

        r = GenerationResult(success=True, data={"x": 1})
        assert bool(r) is True

    def test_generation_result_bool_false(self):
        from familiar.core.structured_output import GenerationResult

        r = GenerationResult(success=False, errors=["oops"])
        assert bool(r) is False

    def test_generation_result_unwrap_raises_on_failure(self):
        from familiar.core.structured_output import GenerationResult, SchemaValidationError

        r = GenerationResult(success=False, errors=["bad JSON"])
        with pytest.raises(SchemaValidationError):
            r.unwrap()

    def test_output_schema_to_json_schema(self):
        from familiar.core.structured_output import OutputSchema

        schema = OutputSchema(
            properties={
                "donor_name": {"type": "string", "description": "Full name"},
                "amount": {"type": "number"},
            },
            required=["donor_name", "amount"],
        )
        js = schema.to_json_schema()
        assert js["type"] == "object"
        assert "donor_name" in js["properties"]
        assert "amount" in js["required"]

    def test_structured_generator_success(self):
        """StructuredGenerator extracts and validates JSON from LLM response."""
        from familiar.core.structured_output import StructuredGenerator

        class FakeLLM:
            def __call__(self, messages, model=None, **kw):
                class R:
                    text = '{"summary": "Q3 donor campaign", "confidence": 0.88}'

                return R()

        gen = StructuredGenerator(FakeLLM(), max_retries=0)
        schema = {
            "type": "object",
            "properties": {
                "summary": {"type": "string"},
                "confidence": {"type": "number"},
            },
            "required": ["summary", "confidence"],
        }
        result = gen.generate("Summarize the campaign", schema)
        assert result.success
        assert result.data["summary"] == "Q3 donor campaign"
        assert result.attempts == 1

    def test_structured_generator_retry_on_bad_json(self):
        """Generator retries when LLM returns non-JSON, succeeds on second attempt."""
        from familiar.core.structured_output import StructuredGenerator

        responses = [
            "Sorry, I can't do that.",
            '{"name": "Alice", "role": "donor"}',
        ]
        call_count = [0]

        def fake_llm(messages, model=None, **kw):
            class R:
                pass

            r = R()
            r.text = responses[min(call_count[0], len(responses) - 1)]
            call_count[0] += 1
            return r

        gen = StructuredGenerator(fake_llm, max_retries=2)
        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}, "role": {"type": "string"}},
            "required": ["name", "role"],
        }
        result = gen.generate("Extract donor info", schema)
        assert result.success, f"Expected success after retry: {result.errors}"
        assert call_count[0] == 2, f"Expected 2 LLM calls, got {call_count[0]}"
        assert result.attempts == 2

    def test_structured_generator_max_retries_exhausted(self):
        """Generator returns failure result after all retries exhausted."""
        from familiar.core.structured_output import StructuredGenerator

        def always_fail(messages, model=None, **kw):
            class R:
                text = "I don't understand."

            return R()

        gen = StructuredGenerator(always_fail, max_retries=2)
        schema = {"type": "object", "properties": {"x": {"type": "string"}}, "required": ["x"]}
        result = gen.generate("Extract x", schema)
        assert not result.success
        assert result.attempts == 3  # initial + 2 retries

    def test_build_structured_prompt_includes_schema(self):
        from familiar.core.structured_output import build_structured_prompt

        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}, "amount": {"type": "number"}},
            "required": ["name", "amount"],
        }
        prompt = build_structured_prompt("Extract donor info", schema)
        assert "name" in prompt
        assert "amount" in prompt
        assert "JSON" in prompt

    def test_build_retry_prompt_includes_errors(self):
        from familiar.core.structured_output import build_retry_prompt

        retry = build_retry_prompt(
            "Extract info",
            '{"partial": true}',
            "- amount: Field required",
        )
        assert "amount" in retry
        assert "validation errors" in retry.lower() or "errors" in retry.lower()

    # ── Integration: structured in tool_context ───────────────────────────────

    def test_structured_present_in_tool_context(self, agent, mock_provider):
        """tool_context['structured'] is a StructuredGenerator on every request."""
        from familiar.core.providers import LLMResponse, ToolCall
        from familiar.core.structured_output import StructuredGenerator

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 10, "output_tokens": 5},
            ),
        ]

        orig = agent._execute_tool_secure

        def capturing(tool_name, tool_input, session, tool_context, trace):
            captured.update(tool_context)
            return orig(tool_name, tool_input, session, tool_context, trace)

        agent._execute_tool_secure = capturing

        agent.chat("Use the time tool", user_id="struct_user")

        assert "structured" in captured, (
            f"'structured' missing from tool_context keys: {list(captured.keys())}"
        )
        assert isinstance(captured["structured"], StructuredGenerator)

    def test_structured_adapter_calls_provider_chat(self, agent, mock_provider):
        """The adapter bridges StructuredGenerator to provider.chat correctly."""
        from familiar.core.providers import LLMResponse, ToolCall

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc2", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 10, "output_tokens": 5},
            ),
        ]

        orig = agent._execute_tool_secure

        def capturing(tool_name, tool_input, session, tool_context, trace):
            captured.update(tool_context)
            return orig(tool_name, tool_input, session, tool_context, trace)

        agent._execute_tool_secure = capturing

        agent.chat("Time check", user_id="adapter_user")

        # Now call generate through the captured generator
        mock_provider.chat.side_effect = None
        mock_provider.chat.return_value = LLMResponse(
            text='{"label": "grant", "amount": 75000}',
            tool_calls=[],
            stop_reason="end_turn",
            usage={},
        )

        schema = {
            "type": "object",
            "properties": {"label": {"type": "string"}, "amount": {"type": "number"}},
            "required": ["label", "amount"],
        }
        result = captured["structured"].generate("Extract grant info", schema)
        assert result.success, f"Generate failed: {result.errors}"
        assert result.data["label"] == "grant"
        assert result.data["amount"] == 75000

        # Verify adapter called provider.chat with correct shape
        last_call = mock_provider.chat.call_args
        assert last_call is not None
        call_kwargs = last_call.kwargs if last_call.kwargs else {}
        call_args = last_call.args if last_call.args else ()
        # tools=[] and system should be present
        assert "tools" in call_kwargs or len(call_args) >= 2

    def test_structured_per_request_isolation(self, agent, mock_provider):
        """Each request gets its own StructuredGenerator — no shared state."""
        from familiar.core.providers import LLMResponse, ToolCall
        from familiar.core.structured_output import StructuredGenerator

        generators = []
        mock_provider.supports_tools = True

        orig = agent._execute_tool_secure

        def capturing(tool_name, tool_input, session, tool_context, trace):
            generators.append(tool_context.get("structured"))
            return orig(tool_name, tool_input, session, tool_context, trace)

        agent._execute_tool_secure = capturing

        for i in range(3):
            mock_provider.chat.side_effect = [
                LLMResponse(
                    text=None,
                    tool_calls=[ToolCall(id=f"tc{i}", name="get_current_time", input={})],
                    stop_reason="tool_use",
                    usage={"input_tokens": 5, "output_tokens": 5},
                ),
                LLMResponse(
                    text=f"Response {i}.",
                    tool_calls=[],
                    stop_reason="end_turn",
                    usage={"input_tokens": 10, "output_tokens": 5},
                ),
            ]
            agent.chat(f"Request {i}", user_id=f"iso_user_{i}")

        assert len(generators) == 3
        # All should be StructuredGenerator instances
        assert all(isinstance(g, StructuredGenerator) for g in generators)
        # Each request gets a fresh instance
        assert generators[0] is not generators[1]
        assert generators[1] is not generators[2]

    def test_structured_no_tool_call_still_injected(self, agent, mock_provider):
        """Even without tool calls, structured is in tool_context if tools execute."""
        from familiar.core.providers import LLMResponse, ToolCall
        from familiar.core.structured_output import StructuredGenerator

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc3", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="The time is now.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 10, "output_tokens": 5},
            ),
        ]

        orig = agent._execute_tool_secure

        def capturing(tool_name, tool_input, session, tool_context, trace):
            captured.update(tool_context)
            return orig(tool_name, tool_input, session, tool_context, trace)

        agent._execute_tool_secure = capturing

        agent.chat("What time is it?", user_id="notool_user")
        assert "structured" in captured
        assert isinstance(captured["structured"], StructuredGenerator)


# ---------------------------------------------------------------------------
# v1.1.19 — SagaOrchestrator wired into agent and tool_context
# ---------------------------------------------------------------------------


class TestSagaIntegration:
    """
    SagaOrchestrator (saga.py) is now wired as:

    - agent.sagas       — shared SagaOrchestrator on the Agent instance
    - agent.run_saga()  — sync bridge: runs async execute() in a thread pool
    - tool_context["sagas"]    — the orchestrator, for register/get/list
    - tool_context["run_saga"] — the sync bridge callable

    Tool handlers define Sagas with SagaBuilder and call run_saga() to execute
    multi-step atomic workflows with automatic compensation on failure.
    """

    # ── Unit: Saga / SagaStep / SagaBuilder ──────────────────────────────────

    def test_saga_builder_creates_saga(self):
        from familiar.core.saga import SagaBuilder

        saga = (
            SagaBuilder("test")
            .with_description("A test saga")
            .with_timeout(60)
            .add_step("step1", lambda ctx: {"ok": True})
            .build()
        )
        assert saga.name == "test"
        assert saga.description == "A test saga"
        assert saga.timeout_seconds == 60
        assert len(saga.steps) == 1
        assert saga.steps[0].name == "step1"

    def test_saga_step_names_must_be_unique(self):
        from familiar.core.saga import Saga, SagaStep

        with pytest.raises(ValueError, match="unique"):
            Saga(
                name="dup",
                steps=[
                    SagaStep("s", action=lambda ctx: {}),
                    SagaStep("s", action=lambda ctx: {}),
                ],
            )

    def test_saga_step_condition_skip(self):
        import asyncio

        from familiar.core.saga import SagaBuilder, SagaOrchestrator, SagaStatus

        ran = []

        def cond(ctx):
            return ctx.get("run_step", False)

        saga = (
            SagaBuilder("conditional")
            .add_step("maybe", lambda ctx: ran.append("ran") or {}, condition=cond)
            .build()
        )

        orch = SagaOrchestrator()
        result = asyncio.run(orch.execute(saga, context={"run_step": False}))
        assert result.status == SagaStatus.COMPLETED
        assert ran == [], "Conditional step should be skipped"

    def test_saga_step_condition_execute(self):
        import asyncio

        from familiar.core.saga import SagaBuilder, SagaOrchestrator, SagaStatus

        ran = []
        saga = (
            SagaBuilder("cond_run")
            .add_step("yes", lambda ctx: ran.append("ran") or {}, condition=lambda ctx: True)
            .build()
        )
        orch = SagaOrchestrator()
        result = asyncio.run(orch.execute(saga, context={}))
        assert result.status == SagaStatus.COMPLETED
        assert ran == ["ran"]

    def test_successful_saga_merges_context(self):
        import asyncio

        from familiar.core.saga import SagaBuilder, SagaOrchestrator, SagaStatus

        saga = (
            SagaBuilder("merge")
            .add_step("a", lambda ctx: {"donor_id": "D001"})
            .add_step("b", lambda ctx: {"welcome_sent": True})
            .build()
        )
        orch = SagaOrchestrator()
        result = asyncio.run(orch.execute(saga, context={"org": "Echidna"}))

        assert result.status == SagaStatus.COMPLETED
        # Step results merged into context at top level
        assert result.current_context.get("donor_id") == "D001"
        assert result.current_context.get("welcome_sent") is True
        assert result.current_context.get("org") == "Echidna"

    def test_failed_step_triggers_compensation(self):
        import asyncio

        from familiar.core.saga import SagaBuilder, SagaOrchestrator, SagaStatus

        compensated = []

        def step_ok(ctx):
            return {"reserved": True}

        def undo_ok(ctx, result):
            compensated.append("undo_ok")

        def step_fail(ctx):
            raise RuntimeError("payment declined")

        saga = (
            SagaBuilder("payment")
            .add_step("reserve", step_ok, undo_ok)
            .add_step("charge", step_fail)
            .build()
        )
        orch = SagaOrchestrator()
        result = asyncio.run(orch.execute(saga, context={}))

        assert result.status == SagaStatus.COMPENSATED
        assert result.error_step == "charge"
        assert "undo_ok" in compensated
        assert "reserve" in result.compensations_executed

    def test_compensation_runs_in_reverse_order(self):
        import asyncio

        from familiar.core.saga import SagaBuilder, SagaOrchestrator

        order = []

        def make_undo(name):
            def undo(ctx, r):
                order.append(name)

            return undo

        def fail(ctx):
            raise RuntimeError("fail")

        saga = (
            SagaBuilder("order_test")
            .add_step("step1", lambda ctx: {}, make_undo("undo1"))
            .add_step("step2", lambda ctx: {}, make_undo("undo2"))
            .add_step("step3", fail)
            .build()
        )
        orch = SagaOrchestrator()
        asyncio.run(orch.execute(saga, context={}))

        assert order == ["undo2", "undo1"], f"Compensations should run in reverse order: {order}"

    def test_step_result_accessible_in_context(self):
        import asyncio

        from familiar.core.saga import SagaBuilder, SagaOrchestrator

        seen_in_step2 = []

        def step1(ctx):
            return {"key": "value_from_1"}

        def step2(ctx):
            seen_in_step2.append(ctx.get("key"))
            return {}

        saga = SagaBuilder("ctx_pass").add_step("s1", step1).add_step("s2", step2).build()
        orch = SagaOrchestrator()
        asyncio.run(orch.execute(saga, context={}))
        assert seen_in_step2 == ["value_from_1"], "Step 2 should see results from step 1 in context"

    def test_saga_orchestrator_register_and_get(self):
        from familiar.core.saga import Saga, SagaOrchestrator, SagaStep

        orch = SagaOrchestrator()
        saga = Saga(name="regtest", steps=[SagaStep("s", action=lambda ctx: {})])
        orch.register(saga)
        assert orch.get_saga("regtest") is saga
        assert orch.get_saga("missing") is None

    def test_saga_execution_summary_format(self):
        import asyncio

        from familiar.core.saga import SagaBuilder, SagaOrchestrator

        saga = SagaBuilder("summary_test").add_step("s", lambda ctx: {"x": 1}).build()
        orch = SagaOrchestrator()
        result = asyncio.run(orch.execute(saga, context={}))
        summary = result.summary()
        assert "summary_test" in summary
        assert "completed" in summary.lower()
        assert "s" in summary

    def test_saga_step_retry(self):
        import asyncio

        from familiar.core.saga import SagaBuilder, SagaOrchestrator, SagaStatus

        attempts = [0]

        def flaky(ctx):
            attempts[0] += 1
            if attempts[0] < 3:
                raise RuntimeError("transient")
            return {"done": True}

        saga = SagaBuilder("retry_saga").add_step("flaky", flaky, retries=3).build()
        orch = SagaOrchestrator()
        result = asyncio.run(orch.execute(saga, context={}))
        assert result.status == SagaStatus.COMPLETED
        assert attempts[0] == 3

    # ── Integration: agent.sagas + run_saga() + tool_context ─────────────────

    def test_agent_has_sagas_attribute(self, agent):
        from familiar.core.saga import SagaOrchestrator

        assert hasattr(agent, "sagas")
        assert isinstance(agent.sagas, SagaOrchestrator)

    def test_run_saga_sync_bridge_success(self, agent):
        from familiar.core.saga import SagaBuilder, SagaStatus

        ran = []

        def action(ctx):
            ran.append(ctx.get("v"))
            return {"result": "ok"}

        saga = SagaBuilder("bridge_ok").add_step("s", action).build()
        ex = agent.run_saga(saga, context={"v": 99})
        assert ex.status == SagaStatus.COMPLETED
        assert ran == [99]

    def test_run_saga_sync_bridge_compensation(self, agent):
        from familiar.core.saga import SagaBuilder, SagaStatus

        comp = []

        def step1(ctx):
            return {"x": 1}

        def undo1(ctx, r):
            comp.append("undone")

        def step2(ctx):
            raise RuntimeError("boom")

        saga = SagaBuilder("bridge_comp").add_step("s1", step1, undo1).add_step("s2", step2).build()
        ex = agent.run_saga(saga, context={})
        assert ex.status == SagaStatus.COMPENSATED
        assert "undone" in comp

    def test_run_saga_context_returned(self, agent):
        from familiar.core.saga import SagaBuilder, SagaStatus

        def action(ctx):
            return {"processed": ctx["input"] * 2}

        saga = SagaBuilder("ctx_ret").add_step("s", action).build()
        ex = agent.run_saga(saga, context={"input": 5})
        assert ex.status == SagaStatus.COMPLETED
        assert ex.current_context.get("processed") == 10

    def test_sagas_in_tool_context(self, agent, mock_provider):
        from familiar.core.providers import LLMResponse, ToolCall
        from familiar.core.saga import SagaOrchestrator

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 10, "output_tokens": 5},
            ),
        ]
        orig = agent._execute_tool_secure

        def capturing(n, i, s, tc, t):
            captured.update(tc)
            return orig(n, i, s, tc, t)

        agent._execute_tool_secure = capturing

        agent.chat("time?", user_id="saga_ctx_user")

        assert "sagas" in captured, f"'sagas' missing: {list(captured.keys())}"
        assert "run_saga" in captured, "'run_saga' missing"
        assert isinstance(captured["sagas"], SagaOrchestrator)
        assert callable(captured["run_saga"])

    def test_run_saga_via_tool_context(self, agent, mock_provider):
        """run_saga from tool_context executes correctly."""
        from familiar.core.providers import LLMResponse, ToolCall
        from familiar.core.saga import SagaBuilder, SagaStatus

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc2", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 10, "output_tokens": 5},
            ),
        ]
        orig = agent._execute_tool_secure

        def capturing(n, i, s, tc, t):
            captured.update(tc)
            return orig(n, i, s, tc, t)

        agent._execute_tool_secure = capturing

        agent.chat("time?", user_id="saga_via_ctx")

        # Simulate a tool calling run_saga
        results = []

        def tool_step(ctx):
            results.append("ran")
            return {"ok": True}

        saga = SagaBuilder("ctx_call").add_step("s", tool_step).build()

        ex = captured["run_saga"](saga, context={"from_tool": True})
        assert ex.status == SagaStatus.COMPLETED
        assert results == ["ran"]

    def test_saga_orchestrator_shared_across_requests(self, agent, mock_provider):
        """Saga registered between requests is visible on the next."""
        from familiar.core.providers import LLMResponse, ToolCall
        from familiar.core.saga import Saga, SagaStep

        # Register a saga on the orchestrator directly
        saga = Saga(name="persistent", steps=[SagaStep("s", lambda ctx: {})])
        agent.sagas.register(saga)

        captured1, captured2 = {}, {}
        mock_provider.supports_tools = True

        for captured in [captured1, captured2]:
            mock_provider.chat.side_effect = [
                LLMResponse(
                    text=None,
                    tool_calls=[ToolCall(id="tc", name="get_current_time", input={})],
                    stop_reason="tool_use",
                    usage={"input_tokens": 5, "output_tokens": 5},
                ),
                LLMResponse(
                    text="Done.",
                    tool_calls=[],
                    stop_reason="end_turn",
                    usage={"input_tokens": 10, "output_tokens": 5},
                ),
            ]
            _orig = (
                agent._execute_tool_secure.__wrapped__
                if hasattr(agent._execute_tool_secure, "__wrapped__")
                else agent._execute_tool_secure
            )

            def _make_cap(cap, orig_fn):
                def capturing(n, i, s, tc, t):
                    cap.update(tc)
                    return orig_fn(n, i, s, tc, t)

                return capturing

            agent._execute_tool_secure = _make_cap(captured, _orig)
            agent.chat("time?", user_id="persist_user")

        # Same orchestrator instance in both requests
        assert captured1["sagas"] is captured2["sagas"]
        # Registered saga still present
        assert captured1["sagas"].get_saga("persistent") is saga


# ---------------------------------------------------------------------------
# v1.1.19 — ExperimentManager wired into agent and tool_context
# ---------------------------------------------------------------------------


class TestExperimentsIntegration:
    """
    ExperimentManager (experiments.py) is wired as:

    - agent.experiments      — shared instance, persists to ~/.familiar/experiments/
    - tool_context["experiments"] — same instance, accessible in every tool handler

    Provides feature flags (on/off, percentage rollout, allowlist) and
    A/B experiments with deterministic variant assignment and statistical analysis.
    """

    # ── Unit: FeatureFlag ─────────────────────────────────────────────────────

    def test_flag_enabled(self):
        from familiar.core.experiments import ExperimentManager

        m = ExperimentManager()
        m.create_flag("on", enabled=True)
        assert m.is_enabled("on", user_id="anyone")

    def test_flag_disabled(self):
        from familiar.core.experiments import ExperimentManager

        m = ExperimentManager()
        m.create_flag("off", enabled=False)
        assert not m.is_enabled("off", user_id="anyone")

    def test_unknown_flag_returns_false(self):
        from familiar.core.experiments import ExperimentManager

        m = ExperimentManager()
        assert not m.is_enabled("nonexistent", user_id="u")

    def test_flag_allowlist(self):
        from familiar.core.experiments import ExperimentManager

        m = ExperimentManager()
        m.create_flag("allowlisted", enabled=False, allowlist={"vip_user"})
        assert m.is_enabled("allowlisted", user_id="vip_user")
        assert not m.is_enabled("allowlisted", user_id="regular_user")

    def test_flag_deterministic_percentage(self):
        """Same user always gets same result for a percentage flag."""
        from familiar.core.experiments import ExperimentManager

        m = ExperimentManager()
        m.create_flag("pct", enabled_percent=50)
        results = [m.is_enabled("pct", user_id="user_xyz") for _ in range(10)]
        assert all(r == results[0] for r in results), "Flag eval must be deterministic"

    def test_flag_percentage_distributes(self):
        """Percentage flag is not always on or always off across many users."""
        from familiar.core.experiments import ExperimentManager

        m = ExperimentManager()
        m.create_flag("half", enabled_percent=50)
        verdicts = [m.is_enabled("half", user_id=f"u{i}") for i in range(100)]
        on_count = sum(verdicts)
        # With 100 users and 50% rollout, expect 30-70 enabled (wide range for hash variance)
        assert 20 <= on_count <= 80, f"Expected ~50% enabled, got {on_count}/100"

    def test_flag_status_toggle(self):
        from familiar.core.experiments import ExperimentManager, FlagStatus

        m = ExperimentManager()
        m.create_flag("toggle", enabled=False)
        assert not m.is_enabled("toggle", "u")
        m.set_flag_status("toggle", status=FlagStatus.ENABLED)
        assert m.is_enabled("toggle", "u")
        m.set_flag_status("toggle", status=FlagStatus.DISABLED)
        assert not m.is_enabled("toggle", "u")

    def test_flag_delete(self):
        from familiar.core.experiments import ExperimentManager

        m = ExperimentManager()
        m.create_flag("temp", enabled=True)
        assert m.is_enabled("temp", "u")
        m.delete_flag("temp")
        assert not m.is_enabled("temp", "u")

    # ── Unit: Experiments / Variants ─────────────────────────────────────────

    def test_create_and_start_experiment(self):
        from familiar.core.experiments import ExperimentManager, ExperimentStatus, Variant

        m = ExperimentManager()
        m.create_experiment(
            "exp1",
            variants=[
                Variant("control", weight=50),
                Variant("treatment", weight=50),
            ],
        )
        m.start_experiment("exp1")
        exp = m.get_experiment("exp1")
        assert exp is not None
        assert exp.status == ExperimentStatus.RUNNING

    def test_variant_assignment_deterministic(self):
        """Same user always gets same variant."""
        from familiar.core.experiments import ExperimentManager, Variant

        m = ExperimentManager()
        m.create_experiment(
            "det_exp",
            variants=[
                Variant("a", weight=50),
                Variant("b", weight=50),
            ],
        )
        m.start_experiment("det_exp")
        v1 = m.get_variant("det_exp", "user42")
        v2 = m.get_variant("det_exp", "user42")
        assert v1 is not None
        assert v1.name == v2.name

    def test_variant_assignment_distributes(self):
        """Variants are distributed across users."""
        from familiar.core.experiments import ExperimentManager, Variant

        m = ExperimentManager()
        m.create_experiment(
            "dist_exp",
            variants=[
                Variant("a", weight=50),
                Variant("b", weight=50),
            ],
        )
        m.start_experiment("dist_exp")
        variants = [m.get_variant("dist_exp", f"u{i}").name for i in range(100)]
        assert "a" in variants and "b" in variants

    def test_get_variant_not_running_returns_none(self):
        from familiar.core.experiments import ExperimentManager, Variant

        m = ExperimentManager()
        m.create_experiment("inactive", variants=[Variant("a", weight=100)])
        # Not started yet
        v = m.get_variant("inactive", "u")
        assert v is None

    def test_track_metric_and_analyze(self):
        from familiar.core.experiments import ExperimentManager, Variant

        m = ExperimentManager()
        m.create_experiment(
            "metric_exp",
            variants=[Variant("control", weight=50), Variant("treatment", weight=50)],
            primary_metric="score",
        )
        m.start_experiment("metric_exp")

        # Assign users and track metrics
        for i in range(20):
            uid = f"u{i}"
            v = m.get_variant("metric_exp", uid, check_targeting=False)
            if v:
                score = 0.8 if v.name == "treatment" else 0.5
                m.track_metric("metric_exp", uid, "score", score)

        results = m.analyze("metric_exp", metric_name="score")
        assert results.experiment_name == "metric_exp"
        assert len(results.variant_metrics) > 0

    def test_track_conversion_convenience(self):
        from familiar.core.experiments import ExperimentManager, Variant

        m = ExperimentManager()
        m.create_experiment("conv_exp", variants=[Variant("a", weight=100)])
        m.start_experiment("conv_exp")
        m.get_variant("conv_exp", "u1", check_targeting=False)
        m.track_conversion("conv_exp", "u1", converted=True)
        events = m.get_metrics("conv_exp", "conversion")
        assert len(events) == 1
        assert events[0].value == 1.0

    def test_list_flags_and_experiments(self):
        from familiar.core.experiments import ExperimentManager

        m = ExperimentManager()
        m.create_flag("f1", tags=["nonprofit"])
        m.create_flag("f2", tags=["dev"])
        m.create_experiment("e1", tags=["nonprofit"])

        all_flags = m.list_flags()
        nonprofit_flags = m.list_flags(tag="nonprofit")
        assert len(all_flags) == 2
        assert len(nonprofit_flags) == 1
        assert nonprofit_flags[0].name == "f1"

        all_exps = m.list_experiments()
        assert len(all_exps) == 1

    # ── Integration: agent.experiments + tool_context ────────────────────────

    def test_agent_has_experiments_attribute(self, agent):
        from familiar.core.experiments import ExperimentManager

        assert hasattr(agent, "experiments")
        assert isinstance(agent.experiments, ExperimentManager)

    def test_experiments_in_tool_context(self, agent, mock_provider):
        from familiar.core.experiments import ExperimentManager
        from familiar.core.providers import LLMResponse, ToolCall

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 10, "output_tokens": 5},
            ),
        ]
        orig = agent._execute_tool_secure

        def capturing(n, i, s, tc, t):
            captured.update(tc)
            return orig(n, i, s, tc, t)

        agent._execute_tool_secure = capturing

        agent.chat("time?", user_id="exp_ctx_user")

        assert "experiments" in captured, f"experiments missing: {list(captured.keys())}"
        assert isinstance(captured["experiments"], ExperimentManager)

    def test_flag_created_on_agent_visible_in_tool_context(self, agent, mock_provider):
        """Flags registered on agent.experiments are visible inside tool handlers."""
        from familiar.core.providers import LLMResponse, ToolCall

        # Register a flag before the chat
        agent.experiments.create_flag("donor_intake_v2", enabled=True)

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc2", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 10, "output_tokens": 5},
            ),
        ]
        orig = agent._execute_tool_secure

        def capturing(n, i, s, tc, t):
            captured.update(tc)
            return orig(n, i, s, tc, t)

        agent._execute_tool_secure = capturing

        agent.chat("time?", user_id="flag_user")

        exp_mgr = captured["experiments"]
        assert exp_mgr.is_enabled("donor_intake_v2", user_id="flag_user"), (
            "Flag registered on agent should be visible and enabled in tool_context"
        )

    def test_experiments_shared_across_requests(self, agent, mock_provider):
        """Same ExperimentManager instance is used across multiple requests."""
        from familiar.core.providers import LLMResponse, ToolCall

        ctxs = []
        mock_provider.supports_tools = True

        for i in range(2):
            mock_provider.chat.side_effect = [
                LLMResponse(
                    text=None,
                    tool_calls=[ToolCall(id=f"tc{i}", name="get_current_time", input={})],
                    stop_reason="tool_use",
                    usage={"input_tokens": 5, "output_tokens": 5},
                ),
                LLMResponse(
                    text="Done.",
                    tool_calls=[],
                    stop_reason="end_turn",
                    usage={"input_tokens": 10, "output_tokens": 5},
                ),
            ]
            captured = {}
            _orig_exp = agent._execute_tool_secure

            def _make_cap_exp(c, orig_fn):
                def _cap(n, i2, s, tc, t):
                    c.update(tc)
                    return orig_fn(n, i2, s, tc, t)

                return _cap

            agent._execute_tool_secure = _make_cap_exp(captured, _orig_exp)
            agent.chat(f"request {i}", user_id=f"shared_user_{i}")
            ctxs.append(captured.get("experiments"))

        assert ctxs[0] is ctxs[1], "Same ExperimentManager instance across requests"
        assert ctxs[0] is agent.experiments

    def test_get_experiment_manager_global(self, agent):
        """set_experiment_manager called in __init__ so global accessor works."""
        from familiar.core.experiments import get_experiment_manager

        global_mgr = get_experiment_manager()
        assert global_mgr is agent.experiments


# ---------------------------------------------------------------------------
# v1.1.20 — Mesh wired into agent
# ---------------------------------------------------------------------------


class TestMeshIntegration:
    """
    Mesh layer (mesh/) wired as:

    - agent.orchestrator        — Orchestrator for multi-agent coordination
    - agent.mesh_gateway        — MeshGateway (None if FAMILIAR_MESH_ENABLED not set)
    - agent.start_mesh()        — async, starts WS server + discovery
    - agent.stop_mesh()         — async, clean shutdown
    - agent.get_mesh_context()  — sync, queries peer memories → system prompt string
    - agent.get_mesh_status()   — sync, structured status dict

    Mesh is OPT-IN: disabled by default, enabled via FAMILIAR_MESH_ENABLED=true.
    All mesh methods degrade gracefully when disabled.
    """

    # ── Orchestrator always present ───────────────────────────────────────────

    def test_agent_has_orchestrator(self, agent):
        from familiar.core.orchestration import Orchestrator

        assert hasattr(agent, "orchestrator")
        assert isinstance(agent.orchestrator, Orchestrator)

    def test_orchestrator_in_tool_context(self, agent, mock_provider):
        from familiar.core.orchestration import Orchestrator
        from familiar.core.providers import LLMResponse, ToolCall

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        orig = agent._execute_tool_secure

        def cap(n, i, s, tc, t):
            captured.update(tc)
            return orig(n, i, s, tc, t)

        agent._execute_tool_secure = cap
        agent.chat("time?", user_id="orch_test")

        assert "orchestrator" in captured
        assert isinstance(captured["orchestrator"], Orchestrator)
        assert captured["orchestrator"] is agent.orchestrator

    # ── Mesh disabled by default ──────────────────────────────────────────────

    def test_mesh_disabled_by_default(self, agent):
        """FAMILIAR_MESH_ENABLED is not set in test env — gateway should be None."""
        assert os.environ.get("FAMILIAR_MESH_ENABLED", "").lower() not in ("1", "true", "yes"), (
            "FAMILIAR_MESH_ENABLED must not be set for this test"
        )
        assert agent.mesh_gateway is None

    def test_mesh_status_disabled(self, agent):
        status = agent.get_mesh_status()
        assert status == {"enabled": False, "running": False}

    def test_get_mesh_context_graceful_when_disabled(self, agent):
        ctx = agent.get_mesh_context("dietary restrictions")
        assert ctx == ""

    def test_mesh_in_tool_context_is_none_when_disabled(self, agent, mock_provider):
        from familiar.core.providers import LLMResponse, ToolCall

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        orig = agent._execute_tool_secure

        def cap(n, i, s, tc, t):
            captured.update(tc)
            return orig(n, i, s, tc, t)

        agent._execute_tool_secure = cap
        agent.chat("time?", user_id="mesh_disabled_ctx")

        assert "mesh" in captured
        assert captured["mesh"] is None

    # ── Mesh enabled via env var ──────────────────────────────────────────────

    def test_mesh_enabled_via_env(self, mock_provider):
        """Setting FAMILIAR_MESH_ENABLED=true creates a MeshGateway."""
        from unittest.mock import patch

        from familiar.core.mesh import MeshGateway

        with patch.dict(os.environ, {"FAMILIAR_MESH_ENABLED": "true"}):
            from familiar.core.agent import Agent

            agent2 = Agent()

        assert agent2.mesh_gateway is not None
        assert isinstance(agent2.mesh_gateway, MeshGateway)
        assert not agent2.mesh_gateway._running, "Gateway should NOT be running until start_mesh()"

    def test_orchestrator_wired_on_gateway(self, mock_provider):
        """When mesh is enabled, gateway.set_orchestrator() is called."""
        from unittest.mock import patch

        with patch.dict(os.environ, {"FAMILIAR_MESH_ENABLED": "true"}):
            from familiar.core.agent import Agent

            agent2 = Agent()

        assert agent2.mesh_gateway._orchestrator is agent2.orchestrator

    def test_memory_bridge_wired_when_memory_enabled(self, mock_provider):
        """Memory bridge is wired when mesh + memory are both enabled."""
        from unittest.mock import patch

        from familiar.core.mesh.memory_bridge import MemoryBridge

        with patch.dict(os.environ, {"FAMILIAR_MESH_ENABLED": "true"}):
            from familiar.core.agent import Agent

            agent2 = Agent()

        # Memory is enabled by default in test agent
        if agent2.memory is not None:
            assert agent2.mesh_gateway.memory_bridge is not None
            assert isinstance(agent2.mesh_gateway.memory_bridge, MemoryBridge)
            assert agent2.mesh_gateway.memory_bridge._gateway is agent2.mesh_gateway

    def test_mesh_status_enabled_not_running(self, mock_provider):
        """Status dict shows enabled=True, running=False before start_mesh()."""
        from unittest.mock import patch

        with patch.dict(os.environ, {"FAMILIAR_MESH_ENABLED": "true"}):
            from familiar.core.agent import Agent

            agent2 = Agent()

        status = agent2.get_mesh_status()
        assert status["enabled"] is True
        assert status["running"] is False
        assert "host" in status
        assert "port" in status
        assert "trust" in status
        assert "memory" in status

    def test_mesh_status_includes_remote_agent_count(self, mock_provider):
        """Remote agents registered in orchestrator appear in status."""
        from unittest.mock import patch

        with patch.dict(os.environ, {"FAMILIAR_MESH_ENABLED": "true"}):
            from familiar.core.agent import Agent
            from familiar.core.mesh.remote_agent import RemoteAgent

            agent2 = Agent()

        # Manually register a fake remote agent
        ra = RemoteAgent(
            node_id="peer_test",
            node_name="Test Peer",
            skills=["test_skill"],
            gateway=agent2.mesh_gateway,
        )
        agent2.orchestrator.registry.register(ra)

        status = agent2.get_mesh_status()
        assert status["remote_agents"] == 1

    def test_mesh_enabled_in_tool_context(self, mock_provider):
        """mesh key in tool_context is the MeshGateway when enabled."""
        from unittest.mock import patch

        from familiar.core.mesh import MeshGateway
        from familiar.core.providers import LLMResponse, ToolCall

        with (
            patch.dict(os.environ, {"FAMILIAR_MESH_ENABLED": "true"}),
            patch("familiar.core.agent.get_provider", return_value=mock_provider),
            patch("familiar.core.agent.get_best_ollama_model", return_value=None),
        ):
            from familiar.core.agent import Agent

            agent2 = Agent()
            agent2.provider = mock_provider
            captured = {}
            mock_provider.supports_tools = True
            mock_provider.chat.side_effect = [
                LLMResponse(
                    text=None,
                    tool_calls=[ToolCall(id="tc2", name="get_current_time", input={})],
                    stop_reason="tool_use",
                    usage={"input_tokens": 5, "output_tokens": 5},
                ),
                LLMResponse(
                    text="Done.",
                    tool_calls=[],
                    stop_reason="end_turn",
                    usage={"input_tokens": 5, "output_tokens": 5},
                ),
            ]
            orig = agent2._execute_tool_secure

            def cap(n, i, s, tc, t):
                captured.update(tc)
                return orig(n, i, s, tc, t)

            agent2._execute_tool_secure = cap
            agent2.chat("time?", user_id="mesh_enabled_ctx")

        assert "mesh" in captured
        assert isinstance(captured["mesh"], MeshGateway)
        assert captured["mesh"] is agent2.mesh_gateway

    # ── MeshCLI parser ────────────────────────────────────────────────────────

    def test_mesh_cli_parser_gateway(self):
        from familiar.core.mesh_cli import create_parser

        p = create_parser()
        a = p.parse_args(["gateway", "--port", "9000", "--name", "kitchen-pi"])
        assert a.command == "gateway"
        assert a.port == 9000
        assert a.name == "kitchen-pi"
        assert not a.public
        assert not a.discovery

    def test_mesh_cli_parser_gateway_public(self):
        from familiar.core.mesh_cli import create_parser

        p = create_parser()
        a = p.parse_args(["gateway", "--public", "--discovery"])
        assert a.public
        assert a.discovery

    def test_mesh_cli_parser_node(self):
        from familiar.core.mesh_cli import create_parser

        p = create_parser()
        a = p.parse_args(["node", "ws://10.0.0.1:18789", "--key", "abc123", "--name", "laptop"])
        assert a.command == "node"
        assert a.gateway_url == "ws://10.0.0.1:18789"
        assert a.key == "abc123"
        assert a.name == "laptop"

    def test_mesh_cli_genkey(self, capsys):
        from familiar.core.mesh_cli import cmd_genkey

        cmd_genkey()
        out = capsys.readouterr().out
        assert "Generated key:" in out
        # Key should be 64 hex chars (32 bytes)
        key_line = [line for line in out.splitlines() if "Generated key:" in line][0]
        key = key_line.split(": ")[1].strip()
        assert len(key) == 64
        assert all(c in "0123456789abcdef" for c in key)

    # ── Trust manager is created (graceful without pynacl) ───────────────────

    def test_trust_manager_has_full_crypto(self, mock_provider):
        """MeshTrustManager has full X3DH crypto now that pynacl is installed."""
        from unittest.mock import patch

        from familiar.core.mesh import MeshTrustManager

        with patch.dict(os.environ, {"FAMILIAR_MESH_ENABLED": "true"}):
            from familiar.core.agent import Agent

            agent2 = Agent()

        tm = agent2.mesh_gateway.trust_manager
        assert tm is not None
        assert isinstance(tm, MeshTrustManager)
        assert tm.has_crypto, "pynacl is installed — has_crypto must be True"
        assert len(tm.get_our_fingerprint()) == 16
        bundle = tm.get_prekey_bundle_dict()
        assert bundle is not None
        assert all(k in bundle for k in ("ik", "spk", "spk_sig", "spk_id"))
        status = tm.get_status()
        assert status["has_crypto"] is True

    def test_x3dh_handshake_and_encrypt(self):
        """Full X3DH key exchange + Double Ratchet encrypt/decrypt between two nodes."""
        import tempfile
        from pathlib import Path

        from familiar.core.mesh import MeshTrustManager

        with tempfile.TemporaryDirectory() as d_a, tempfile.TemporaryDirectory() as d_b:
            tm_a = MeshTrustManager(mesh_dir=Path(d_a))
            tm_b = MeshTrustManager(mesh_dir=Path(d_b))

            # A initiates with B's bundle
            init_hex = tm_a.initiate_handshake("b", "Node B", tm_b.get_prekey_bundle_dict())
            assert init_hex is not None

            # B accepts with A's identity key
            tm_b.accept_handshake("a", "Node A", init_hex, tm_a.get_prekey_bundle_dict()["ik"])

            assert tm_a.has_session("b")
            assert tm_b.has_session("a")

            # Verification codes must match (out-of-band safety number)
            assert tm_a.get_verification_code("b") == tm_b.get_verification_code("a")

            # Encrypt A→B
            plaintext = b"cross-device secret"
            ct = tm_a.encrypt_for_peer("b", plaintext)
            assert ct != plaintext
            assert tm_b.decrypt_from_peer("a", ct) == plaintext

    def test_trust_lifecycle_with_crypto(self):
        """approve, grant_permission, check_permission, block work with live crypto."""
        import tempfile
        from pathlib import Path

        from familiar.core.mesh import MeshTrustManager

        with tempfile.TemporaryDirectory() as d_a, tempfile.TemporaryDirectory() as d_b:
            tm_a = MeshTrustManager(mesh_dir=Path(d_a))
            tm_b = MeshTrustManager(mesh_dir=Path(d_b))

            init_hex = tm_a.initiate_handshake("b", "B", tm_b.get_prekey_bundle_dict())
            tm_b.accept_handshake("a", "A", init_hex, tm_a.get_prekey_bundle_dict()["ik"])

            # Approve and grant
            tm_a.approve("b")
            assert tm_a.is_trusted("b")
            assert tm_a.grant_permission("b", "request_memory")
            assert tm_a.check_permission("b", "request_memory")
            assert not tm_a.check_permission("b", "delegate_tasks")

            # Block revokes all
            tm_a.block("b")
            assert tm_a.is_blocked("b")
            assert not tm_a.check_permission("b", "request_memory")

    def test_gateway_starts_and_stops(self, mock_provider):
        """Gateway actually binds a port and stops cleanly (websockets + zeroconf installed)."""
        import asyncio
        from unittest.mock import patch

        with patch.dict(
            os.environ,
            {
                "FAMILIAR_MESH_ENABLED": "true",
                "FAMILIAR_MESH_HOST": "127.0.0.1",
                "FAMILIAR_MESH_PORT": "19878",
            },
        ):
            from familiar.core.agent import Agent

            agent2 = Agent()

        async def cycle():
            await agent2.mesh_gateway.start()
            assert agent2.mesh_gateway._running
            await asyncio.sleep(0.05)
            await agent2.mesh_gateway.stop()
            assert not agent2.mesh_gateway._running

        asyncio.run(cycle())

    def test_discovery_starts_with_zeroconf(self, mock_provider):
        """mDNS discovery initialises when discovery_enabled=True and zeroconf is installed."""
        import asyncio
        from unittest.mock import patch

        with patch.dict(
            os.environ,
            {
                "FAMILIAR_MESH_ENABLED": "true",
                "FAMILIAR_MESH_HOST": "127.0.0.1",
                "FAMILIAR_MESH_PORT": "19879",
            },
        ):
            from familiar.core.agent import Agent

            agent2 = Agent()

        agent2.mesh_gateway.config.set("discovery_enabled", True)

        async def cycle():
            await agent2.mesh_gateway.start()
            assert agent2.mesh_gateway.discovery is not None
            await asyncio.sleep(0.05)
            await agent2.mesh_gateway.stop()

        asyncio.run(cycle())


# ---------------------------------------------------------------------------
# v1.1.23 — SkillBus wired into agent
# ---------------------------------------------------------------------------


class TestSkillBusIntegration:
    """
    SkillBus (bus.py) wired as:

    - agent.bus                  — SkillBus instance, always present
    - get_skill_bus()            — module-level accessor, returns agent.bus
    - tool_context["bus"]        — injected into every tool handler
    - tool.executed event        — published after every tool call
    - tool.<tool_name> event     — specific-tool topic published alongside
    - agent.get_bus_status()     — structured status dict

    Capabilities exposed to skills:
      bus.publish(topic, payload)          — fire-and-forget async event
      bus.subscribe(topic, handler)        — topic subscription (wildcard .*  support)
      bus.invoke(skill, action, payload)   — sync RPC with retry + DLQ
      bus.invoke_no_retry(...)             — sync RPC, no retry
      bus.invoke_async(...)                — async fire-and-callback
      bus.state.get/set/delete/watch       — in-process shared state
      bus.create_workflow() / execute_workflow() — DAG multi-skill workflow
      bus.dead_letters / replay_dead_letter()    — DLQ inspection and replay
    """

    # ── Core wiring ───────────────────────────────────────────────────────────

    def test_agent_has_bus(self, agent):
        assert hasattr(agent, "bus")
        assert isinstance(
            agent.bus, __import__("familiar.core.bus", fromlist=["SkillBus"]).SkillBus
        )

    def test_get_skill_bus_returns_agent_bus(self, agent):
        from familiar.core.bus import get_skill_bus

        assert get_skill_bus() is agent.bus

    def test_bus_worker_thread_running(self, agent):
        assert agent.bus._running is True
        assert agent.bus._worker_thread is not None
        assert agent.bus._worker_thread.is_alive()

    def test_bus_in_tool_context(self, agent, mock_provider):
        from familiar.core.bus import SkillBus
        from familiar.core.providers import LLMResponse, ToolCall

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        orig = agent._execute_tool_secure

        def cap(n, i, s, tc, t):
            captured.update(tc)
            return orig(n, i, s, tc, t)

        agent._execute_tool_secure = cap
        agent.chat("time?", user_id="bus_ctx_test")

        assert "bus" in captured
        assert isinstance(captured["bus"], SkillBus)
        assert captured["bus"] is agent.bus

    # ── get_bus_status ────────────────────────────────────────────────────────

    def test_get_bus_status_shape(self, agent):
        status = agent.get_bus_status()
        assert "running" in status
        assert "registered_skills" in status
        assert "subscription_count" in status
        assert "shared_state_keys" in status
        assert "dead_letter" in status
        assert status["running"] is True

    def test_get_bus_status_reflects_registered_skills(self, agent):
        agent.bus.register_skill("test_skill_status", {"ping": lambda p: "pong"})
        status = agent.get_bus_status()
        assert "test_skill_status" in status["registered_skills"]

    def test_get_bus_status_dlq_stats(self, agent):
        dlq = agent.get_bus_status()["dead_letter"]
        assert "current_size" in dlq
        assert "total_added" in dlq

    # ── Pub/sub ───────────────────────────────────────────────────────────────

    def test_subscribe_and_publish(self, agent):
        import time

        received = []
        agent.bus.subscribe("test.topic", lambda m: received.append(m.payload))
        agent.bus.publish("test.topic", {"key": "value"})
        time.sleep(0.1)  # worker thread processes async
        assert len(received) == 1
        assert received[0]["key"] == "value"

    def test_wildcard_subscription(self, agent):
        import time

        received = []
        agent.bus.subscribe("donor.*", lambda m: received.append(m.topic))
        agent.bus.publish("donor.created", {"id": "1"})
        agent.bus.publish("donor.updated", {"id": "1"})
        agent.bus.publish("volunteer.created", {"id": "2"})  # should NOT match
        time.sleep(0.15)
        assert "donor.created" in received
        assert "donor.updated" in received
        assert "volunteer.created" not in received

    def test_filter_fn_on_subscription(self, agent):
        import time

        high_priority = []
        agent.bus.subscribe(
            "task.created",
            lambda m: high_priority.append(m.payload),
            filter_fn=lambda m: m.payload.get("priority") == "urgent",
        )
        agent.bus.publish("task.created", {"priority": "urgent", "title": "Feed cat"})
        agent.bus.publish("task.created", {"priority": "normal", "title": "Buy milk"})
        time.sleep(0.1)
        assert len(high_priority) == 1
        assert high_priority[0]["title"] == "Feed cat"

    def test_multiple_subscribers_same_topic(self, agent):
        import time

        a, b = [], []
        agent.bus.subscribe("multi.topic", lambda m: a.append(1))
        agent.bus.subscribe("multi.topic", lambda m: b.append(1))
        agent.bus.publish("multi.topic", {})
        time.sleep(0.1)
        assert len(a) == 1
        assert len(b) == 1

    def test_module_level_publish_subscribe(self, agent):
        """Module-level publish()/subscribe() route to agent.bus."""
        import time

        from familiar.core.bus import publish, subscribe

        received = []
        subscribe("module.test", lambda m: received.append(m.payload))
        publish("module.test", {"source": "module"})
        time.sleep(0.1)
        assert len(received) == 1
        assert received[0]["source"] == "module"

    # ── Invoke (sync RPC) ────────────────────────────────────────────────────

    def test_invoke_registered_skill(self, agent):
        agent.bus.register_skill(
            "greeter", {"hello": lambda p: f"Hello, {p.get('name', 'world')}!"}
        )
        r = agent.bus.invoke("greeter", "hello", {"name": "Alice"})
        assert r == "Hello, Alice!"

    def test_invoke_unknown_skill_raises(self, agent):
        import pytest

        with pytest.raises(ValueError, match="not found"):
            agent.bus.invoke("nonexistent_skill_xyz", "action", {})

    def test_invoke_no_retry_convenience(self, agent):
        agent.bus.register_skill("math", {"double": lambda p: p["n"] * 2})
        r = agent.bus.invoke_no_retry("math", "double", {"n": 7})
        assert r == 14

    def test_module_level_invoke(self, agent):
        from familiar.core.bus import invoke

        agent.bus.register_skill("echo", {"repeat": lambda p: p.get("text", "")})
        r = invoke("echo", "repeat", {"text": "hello"})
        assert r == "hello"

    def test_invoke_with_context_injection(self, agent):
        """SkillEndpoint passes context kwarg when handler signature accepts it."""
        received_ctx = {}

        def handler_with_ctx(payload, context=None):
            received_ctx.update(context or {})
            return "ok"

        agent.bus.register_skill("ctx_test", {"run": handler_with_ctx})
        agent.bus.invoke("ctx_test", "run", {"x": 1}, context={"user": "george"})
        assert received_ctx.get("user") == "george"

    # ── Retry + DLQ ──────────────────────────────────────────────────────────

    def test_failed_invoke_goes_to_dlq(self, agent):
        call_count = [0]

        def always_fails(p):
            call_count[0] += 1
            raise RuntimeError("simulated failure")

        agent.bus.register_skill("fragile", {"op": always_fails})
        import pytest

        from familiar.core.bus import RetryPolicy, RetryStrategy

        no_delay = RetryPolicy(max_attempts=2, base_delay=0, strategy=RetryStrategy.FIXED)
        with pytest.raises(RuntimeError):
            agent.bus.invoke("fragile", "op", {}, retry_policy=no_delay)

        dlq = agent.bus.get_dead_letters(10, "fragile")
        assert len(dlq) >= 1
        assert dlq[0].skill_name == "fragile"
        assert dlq[0].action == "op"
        assert "simulated failure" in dlq[0].error_message

    def test_replay_dead_letter(self, agent):
        """After fixing a skill, dead letter can be replayed successfully."""
        should_fail = [True]

        def flaky(p):
            if should_fail[0]:
                raise RuntimeError("not ready")
            return "recovered"

        agent.bus.register_skill("flaky_svc", {"do": flaky})
        from familiar.core.bus import RetryPolicy, RetryStrategy

        no_delay = RetryPolicy(max_attempts=1, base_delay=0, strategy=RetryStrategy.NONE)
        import pytest

        with pytest.raises(RuntimeError):
            agent.bus.invoke("flaky_svc", "do", {}, retry_policy=no_delay)

        should_fail[0] = False
        result = agent.bus.replay_dead_letter(
            agent.bus.get_dead_letters(1, "flaky_svc")[0].id, retry_policy=no_delay
        )
        assert result == "recovered"

    def test_dlq_stats(self, agent):
        def boom(p):
            raise ValueError("boom")

        agent.bus.register_skill("dlq_test", {"fail": boom})
        from familiar.core.bus import RetryPolicy, RetryStrategy

        no_retry = RetryPolicy(max_attempts=1, strategy=RetryStrategy.NONE)
        import pytest

        with pytest.raises(ValueError):
            agent.bus.invoke("dlq_test", "fail", {}, retry_policy=no_retry)
        stats = agent.bus.get_dead_letter_stats()
        assert stats["current_size"] >= 1
        assert stats["total_added"] >= 1

    # ── Shared state ─────────────────────────────────────────────────────────

    def test_shared_state_set_get(self, agent):
        agent.bus.state.set("test_key", {"answer": 42})
        val = agent.bus.state.get("test_key")
        assert val == {"answer": 42}

    def test_shared_state_default(self, agent):
        val = agent.bus.state.get("nonexistent_key_xyz", default="fallback")
        assert val == "fallback"

    def test_shared_state_delete(self, agent):
        agent.bus.state.set("del_key", "temporary")
        agent.bus.state.delete("del_key")
        assert agent.bus.state.get("del_key") is None

    def test_shared_state_watcher(self, agent):
        changes = []
        agent.bus.state.watch("watched_key", lambda k, old, new: changes.append((old, new)))
        agent.bus.state.set("watched_key", "v1")
        agent.bus.state.set("watched_key", "v2")
        assert len(changes) == 2
        assert changes[0] == (None, "v1")
        assert changes[1] == ("v1", "v2")

    def test_shared_state_cross_skill_visibility(self, agent):
        """State set in one skill handler is visible to another."""
        agent.bus.register_skill(
            "writer", {"write": lambda p: agent.bus.state.set("shared", p["val"]) or "written"}
        )
        agent.bus.register_skill(
            "reader", {"read": lambda p: agent.bus.state.get("shared", "missing")}
        )
        agent.bus.invoke("writer", "write", {"val": "cross_skill_value"})
        result = agent.bus.invoke("reader", "read", {})
        assert result == "cross_skill_value"

    # ── Workflow engine ───────────────────────────────────────────────────────

    def test_linear_workflow(self, agent):
        """Two sequential steps, second depends on first."""
        agent.bus.register_skill("step_a", {"run": lambda p: {"step_a_result": "A done"}})
        agent.bus.register_skill(
            "step_b",
            {
                "run": lambda p: (
                    f"B got: {p['_workflow_context'].get('step_a', {}).get('step_a_result', '')}"
                )
            },
        )

        wf = agent.bus.create_workflow("linear_test")
        wf.add_step("step_a", "run", step_id="step_a")
        wf.add_step("step_b", "run", step_id="step_b", depends_on=["step_a"])

        ctx = agent.bus.execute_workflow(wf)
        assert wf.status == "completed"
        assert ctx["step_a"] == {"step_a_result": "A done"}
        assert "B got: A done" in ctx["step_b"]

    def test_workflow_with_initial_context(self, agent):
        agent.bus.register_skill(
            "transform", {"upper": lambda p: p["_workflow_context"].get("input_text", "").upper()}
        )
        wf = agent.bus.create_workflow("context_test")
        wf.add_step("transform", "upper", step_id="result")
        ctx = agent.bus.execute_workflow(wf, initial_context={"input_text": "hello"})
        assert ctx["result"] == "HELLO"

    def test_workflow_failed_step_marks_workflow_failed(self, agent):
        def boom(p):
            raise RuntimeError("step failed")

        agent.bus.register_skill("failing_step", {"run": boom})
        from familiar.core.bus import RetryPolicy, RetryStrategy

        # Override bus default retry so test is fast
        orig_policy = agent.bus._default_retry_policy
        agent.bus._default_retry_policy = RetryPolicy(max_attempts=1, strategy=RetryStrategy.NONE)
        try:
            wf = agent.bus.create_workflow("failing_wf")
            wf.add_step("failing_step", "run", step_id="bad")
            agent.bus.execute_workflow(wf)
            assert wf.status == "failed"
        finally:
            agent.bus._default_retry_policy = orig_policy

    def test_workflow_parallel_ready_steps(self, agent):
        """Steps with no dependencies both appear in ready list at start."""
        executed = []
        agent.bus.register_skill("parallel_a", {"run": lambda p: executed.append("a") or "a"})
        agent.bus.register_skill("parallel_b", {"run": lambda p: executed.append("b") or "b"})
        agent.bus.register_skill("parallel_merge", {"run": lambda p: "+".join(sorted(executed))})

        wf = agent.bus.create_workflow("parallel_test")
        wf.add_step("parallel_a", "run", step_id="a")
        wf.add_step("parallel_b", "run", step_id="b")
        wf.add_step("parallel_merge", "run", step_id="merge", depends_on=["a", "b"])
        agent.bus.execute_workflow(wf)
        assert wf.status == "completed"
        assert set(executed[:2]) == {"a", "b"}

    # ── tool.executed event spine ────────────────────────────────────────────

    def test_tool_executed_event_published(self, agent, mock_provider):
        """bus publishes tool.executed after every tool call."""
        import time

        from familiar.core.providers import LLMResponse, ToolCall

        events = []
        agent.bus.subscribe("tool.executed", lambda m: events.append(m.payload))

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        agent.chat("what time is it?", user_id="bus_event_test")
        time.sleep(0.15)

        assert len(events) >= 1
        ev = events[0]
        assert ev["tool"] == "get_current_time"
        assert "success" in ev
        assert "result_preview" in ev

    def test_specific_tool_topic_published(self, agent, mock_provider):
        """bus also publishes tool.<tool_name> for targeted subscriptions."""
        import time

        from familiar.core.providers import LLMResponse, ToolCall

        specific_events = []
        agent.bus.subscribe("tool.get_current_time", lambda m: specific_events.append(m.payload))

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        agent.chat("time?", user_id="specific_topic_test")
        time.sleep(0.15)

        assert len(specific_events) >= 1
        assert specific_events[0]["tool"] == "get_current_time"

    def test_tool_event_includes_success_flag(self, agent, mock_provider):
        """success=True on clean execution, False on tool error result."""
        import time

        from familiar.core.providers import LLMResponse, ToolCall

        events = []
        agent.bus.subscribe("tool.executed", lambda m: events.append(m.payload))

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        agent.chat("time?", user_id="success_flag_test")
        time.sleep(0.15)

        assert any(ev["success"] is True for ev in events)

    # ── skill_action decorator ────────────────────────────────────────────────

    def test_skill_action_decorator(self, agent):
        """@skill_action registers directly on the global (agent) bus."""
        from familiar.core.bus import skill_action

        @skill_action("decorated_skill")
        def my_action(payload):
            return f"decorated:{payload.get('x')}"

        result = agent.bus.invoke("decorated_skill", "my_action", {"x": 42})
        assert result == "decorated:42"

    # ── donor intake workflow (representative nonprofit use case) ─────────────

    def test_donor_intake_workflow(self, agent):
        """
        Three-step donor intake pipeline:
          1. validate   — check required fields
          2. crm_upsert — store in CRM (depends on validate)
          3. welcome    — send welcome message (depends on crm_upsert)

        Mirrors real Echidna nonprofit workflow. Steps share context via
        workflow.context dict — no LLM needed to chain them.
        """
        audit_log = []

        agent.bus.register_skill(
            "donor_validate",
            {
                "run": lambda p: (
                    audit_log.append("validated")
                    or {
                        "valid": True,
                        "donor_id": "d_001",
                        "name": p["_workflow_context"]["donor"]["name"],
                    }
                )
            },
        )
        agent.bus.register_skill(
            "donor_crm",
            {
                "run": lambda p: (
                    audit_log.append("crm_upserted")
                    or {
                        "crm_id": "crm_001",
                        "donor_id": p["_workflow_context"].get("validate", {}).get("donor_id"),
                    }
                )
            },
        )
        agent.bus.register_skill(
            "donor_welcome",
            {
                "run": lambda p: (
                    audit_log.append("welcome_sent")
                    or f"Welcome email sent for crm_id={p['_workflow_context'].get('crm', {}).get('crm_id')}"
                )
            },
        )

        wf = agent.bus.create_workflow("donor_intake")
        wf.add_step("donor_validate", "run", step_id="validate")
        wf.add_step("donor_crm", "run", step_id="crm", depends_on=["validate"])
        wf.add_step("donor_welcome", "run", step_id="welcome", depends_on=["crm"])

        ctx = agent.bus.execute_workflow(
            wf, initial_context={"donor": {"name": "Alice Ngo", "email": "alice@example.org"}}
        )

        assert wf.status == "completed"
        assert audit_log == ["validated", "crm_upserted", "welcome_sent"]
        assert ctx["validate"]["donor_id"] == "d_001"
        assert ctx["crm"]["crm_id"] == "crm_001"
        assert "crm_001" in ctx["welcome"]


# ---------------------------------------------------------------------------
# v1.1.24 — embeddings.py + context.py wired: semantic RAG pipeline
# ---------------------------------------------------------------------------


class TestEmbeddingsAndRAG:
    """
    embeddings.py + context.py wired as:

    - agent.retriever              — SemanticRetriever, always present
    - tool_context["retriever"]    — injected into every tool handler
    - _retrieve_rag_context()      — per-message retrieval injected into system prompt
    - agent.get_retriever_status() — structured status dict

    Embedding provider cascade (best → fallback):
      1. Ollama (nomic-embed-text, local)
      2. ONNX (all-MiniLM-L6-v2, Pi-friendly)
      3. HTTP endpoint (self-hosted)
      4. Voyage AI (VOYAGE_API_KEY)
      5. OpenAI (OPENAI_API_KEY)
      6. TF-IDF (always available, zero deps — used in this test environment)

    SemanticRetriever capabilities (via context.py):
      retriever.add_text(text, metadata, source, chunk)  — index a document
      retriever.add_texts([texts], metadatas)             — batch index
      retriever.add_document(Document)                   — pre-built doc
      retriever.retrieve(query, top_k, filter, min_score)— semantic search
      retriever.get_context(query, max_tokens, format)   — formatted RAG string
      retriever.delete(ids)                              — remove docs
      retriever.clear()                                  — wipe store
      retriever.count                                    — doc count

    RAG injection: when retriever.count > 0, _retrieve_rag_context(message)
    is called every LLM turn and the top-k chunks are prepended to the
    system prompt under "## Retrieved Knowledge".
    """

    # ── Core wiring ───────────────────────────────────────────────────────────

    def test_agent_has_retriever(self, agent):
        from familiar.core.context import SemanticRetriever

        assert hasattr(agent, "retriever")
        assert isinstance(agent.retriever, SemanticRetriever)

    def test_retriever_has_embedding_provider(self, agent):
        """Bridge connects embeddings.py provider to context.py interface."""
        assert agent.retriever._embedding is not None
        # Bridge exposes .embed() and .embed_batch() regardless of underlying provider
        vec = agent.retriever._embedding.embed("test")
        assert isinstance(vec, list)
        assert len(vec) > 0

    def test_retriever_starts_empty(self, agent):
        assert agent.retriever.count == 0

    def test_retriever_in_tool_context(self, agent, mock_provider):
        """tool_context["retriever"] is the agent's SemanticRetriever instance."""
        from familiar.core.context import SemanticRetriever
        from familiar.core.providers import LLMResponse, ToolCall

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        orig = agent._execute_tool_secure

        def cap(n, i, s, tc, t):
            captured.update(tc)
            return orig(n, i, s, tc, t)

        agent._execute_tool_secure = cap
        agent.chat("time?", user_id="rag_ctx_test")

        assert "retriever" in captured
        assert isinstance(captured["retriever"], SemanticRetriever)
        assert captured["retriever"] is agent.retriever

    # ── get_retriever_status ──────────────────────────────────────────────────

    def test_get_retriever_status_shape(self, agent):
        status = agent.get_retriever_status()
        assert "provider" in status
        assert "doc_count" in status
        assert "vector_store" in status
        assert "config" in status
        assert status["doc_count"] == 0

    def test_get_retriever_status_provider_name(self, agent):
        status = agent.get_retriever_status()
        # In CI without Ollama/cloud keys, falls back to tfidf
        assert isinstance(status["provider"], str)
        assert len(status["provider"]) > 0

    def test_get_retriever_status_vector_store(self, agent):
        status = agent.get_retriever_status()
        assert "VectorStore" in status["vector_store"]

    def test_get_retriever_status_config_keys(self, agent):
        cfg = agent.get_retriever_status()["config"]
        assert "top_k" in cfg
        assert "min_score" in cfg
        assert "chunk_size" in cfg
        assert "chunk_overlap" in cfg
        assert "max_tokens" in cfg

    def test_get_retriever_status_reflects_added_docs(self, agent):
        agent.retriever.clear()
        agent.retriever.add_text("Grant deadline March 15.", chunk=False)
        agent.retriever.add_text("Board meeting first Tuesday.", chunk=False)
        status = agent.get_retriever_status()
        assert status["doc_count"] == 2
        agent.retriever.clear()

    # ── Embedding provider (TF-IDF in CI) ────────────────────────────────────

    def test_embedding_provider_cascade_returns_provider(self):
        from familiar.core.embeddings import get_embedding_provider

        p = get_embedding_provider()
        assert p is not None
        assert hasattr(p, "embed")
        assert hasattr(p, "embed_batch")
        assert hasattr(p, "dimensions")

    def test_tfidf_embed_returns_vector(self):
        from familiar.core.embeddings import TFIDFEmbeddings

        t = TFIDFEmbeddings(max_features=64)
        vec = t.embed("gluten free dietary restrictions for catering")
        assert isinstance(vec, list)
        assert len(vec) == 64
        assert any(v != 0.0 for v in vec)

    def test_tfidf_embed_batch(self):
        from familiar.core.embeddings import TFIDFEmbeddings

        t = TFIDFEmbeddings(max_features=64)
        vecs = t.embed_batch(["hello world", "dietary restrictions", "grant deadline"])
        assert len(vecs) == 3
        assert all(len(v) == 64 for v in vecs)

    def test_tfidf_dimensions(self):
        from familiar.core.embeddings import TFIDFEmbeddings

        t = TFIDFEmbeddings(max_features=128)
        assert t.dimensions == 128

    def test_cosine_similarity_identical(self):
        from familiar.core.embeddings import cosine_similarity

        v = [0.5, 0.5, 0.5, 0.5]
        assert abs(cosine_similarity(v, v) - 1.0) < 1e-6

    def test_cosine_similarity_orthogonal(self):
        from familiar.core.embeddings import cosine_similarity

        a = [1.0, 0.0, 0.0]
        b = [0.0, 1.0, 0.0]
        assert abs(cosine_similarity(a, b)) < 1e-6

    def test_top_k_similar(self):
        from familiar.core.embeddings import TFIDFEmbeddings, top_k_similar

        t = TFIDFEmbeddings(max_features=64)
        docs = [
            "grant deadline March",
            "dietary restrictions gluten free",
            "board meeting Tuesday",
            "donor recognition Gold Circle",
        ]
        vecs = t.embed_batch(docs)
        query = t.embed("when is the grant due")
        pairs = [(f"doc_{i}", v) for i, v in enumerate(vecs)]
        ranked = top_k_similar(query, pairs, k=2)
        assert len(ranked) == 2
        assert all(isinstance(k, str) and isinstance(s, float) for k, s in ranked)

    # ── InMemoryVectorStore (from context.py) ─────────────────────────────────

    def test_vector_store_add_and_search(self):
        from familiar.core.context import Document, InMemoryVectorStore

        store = InMemoryVectorStore()
        doc = Document(id="d1", content="hello", embedding=[1.0, 0.0, 0.0])
        store.add([doc])
        results = store.search([1.0, 0.0, 0.0], top_k=1)
        assert len(results) == 1
        assert results[0].id == "d1"
        assert abs(results[0].score - 1.0) < 1e-6

    def test_vector_store_filter(self):
        from familiar.core.context import Document, InMemoryVectorStore

        store = InMemoryVectorStore()
        store.add(
            [
                Document(id="a", content="alpha", embedding=[1.0, 0.0], metadata={"type": "grant"}),
                Document(id="b", content="beta", embedding=[1.0, 0.0], metadata={"type": "donor"}),
            ]
        )
        results = store.search([1.0, 0.0], top_k=5, filter={"type": "grant"})
        assert len(results) == 1
        assert results[0].id == "a"

    def test_vector_store_delete(self):
        from familiar.core.context import Document, InMemoryVectorStore

        store = InMemoryVectorStore()
        store.add([Document(id="x", content="x", embedding=[1.0, 0.0])])
        store.delete(["x"])
        assert store.count == 0

    def test_vector_store_clear(self):
        from familiar.core.context import Document, InMemoryVectorStore

        store = InMemoryVectorStore()
        store.add([Document(id="y", content="y", embedding=[1.0, 0.0])])
        store.clear()
        assert store.count == 0

    # ── SemanticRetriever ─────────────────────────────────────────────────────

    def test_retriever_add_text(self, agent):
        agent.retriever.clear()
        ids = agent.retriever.add_text("Grant deadline is March 15, 2026.", chunk=False)
        assert len(ids) == 1
        assert agent.retriever.count == 1
        agent.retriever.clear()

    def test_retriever_add_texts_batch(self, agent):
        agent.retriever.clear()
        ids = agent.retriever.add_texts(
            [
                "Donors giving over $5,000 join the Gold Circle.",
                "Board meetings are the first Tuesday of each month.",
                "Gluten-free options must be confirmed 48 hours ahead.",
            ],
            chunk=False,
        )
        assert agent.retriever.count == 3
        assert len(ids) == 3
        agent.retriever.clear()

    def test_retriever_add_document(self, agent):
        from familiar.core.context import Document

        agent.retriever.clear()
        doc = Document(id="manual_1", content="Org founded 1998.", metadata={"source": "handbook"})
        agent.retriever.add_document(doc)
        assert agent.retriever.count == 1
        agent.retriever.clear()

    def test_retriever_chunking_splits_long_text(self, agent):
        agent.retriever.clear()
        # Build a realistic multi-sentence corpus well over chunk_size=400 tokens.
        # Each sentence is ~30 words / ~120 chars / ~30 heuristic tokens.
        # 50 sentences → ~1500 tokens, guaranteed to exceed chunk_size=400.
        sentence = (
            "The nonprofit serves low-income families through direct food assistance"
            " grant programmes volunteer coordination and community education"
        )
        long_text = ". ".join([sentence] * 50) + "."
        ids = agent.retriever.add_text(long_text, chunk=True)
        assert len(ids) >= 2, f"Expected at least 2 chunks, got {len(ids)}. chars={len(long_text)}"
        assert agent.retriever.count >= 2
        agent.retriever.clear()

    def test_retriever_retrieve_returns_documents(self, agent):
        agent.retriever.clear()
        agent.retriever.add_texts(
            [
                "The Smith Foundation grant deadline is March 15.",
                "Board elections happen every two years.",
                "Volunteer onboarding takes three sessions.",
            ],
            chunk=False,
        )
        results = agent.retriever.retrieve("when does the grant expire", top_k=3)
        assert isinstance(results, list)
        assert len(results) <= 3
        assert all(hasattr(r, "content") and hasattr(r, "score") for r in results)
        agent.retriever.clear()

    def test_retriever_get_context_returns_string(self, agent):
        agent.retriever.clear()
        agent.retriever.add_texts(
            [
                "The annual gala raises funds for youth programmes.",
                "Grant reporting is due 90 days after project end.",
                "Major donors receive quarterly impact reports.",
            ],
            chunk=False,
        )
        ctx = agent.retriever.get_context("donor recognition programmes", max_tokens=800)
        assert isinstance(ctx, str)
        agent.retriever.clear()

    def test_retriever_get_context_numbered_format(self, agent):
        agent.retriever.clear()
        agent.retriever.add_text(
            "Policy: all donations over $1,000 require a signed acknowledgement.", chunk=False
        )
        ctx = agent.retriever.get_context("donation policy", format="numbered")
        # Numbered format contains [N]
        if ctx:
            assert "[1]" in ctx
        agent.retriever.clear()

    def test_retriever_clear_resets_count(self, agent):
        agent.retriever.add_text("temporary", chunk=False)
        agent.retriever.clear()
        assert agent.retriever.count == 0

    def test_retriever_metadata_filter(self, agent):
        agent.retriever.clear()
        agent.retriever.add_text(
            "Smith Foundation: deadline March 15.", metadata={"source": "smith"}, chunk=False
        )
        agent.retriever.add_text(
            "Jones Fund: deadline April 30.", metadata={"source": "jones"}, chunk=False
        )
        results = agent.retriever.retrieve("grant deadline", top_k=5, filter={"source": "smith"})
        assert all(r.metadata.get("source") == "smith" for r in results)
        agent.retriever.clear()

    # ── _retrieve_rag_context ─────────────────────────────────────────────────

    def test_retrieve_rag_context_empty_when_no_docs(self, agent):
        agent.retriever.clear()
        result = agent._retrieve_rag_context("grant deadline")
        assert result == ""

    def test_retrieve_rag_context_returns_string_when_docs_present(self, agent):
        agent.retriever.clear()
        agent.retriever.add_texts(
            [
                "The Smith Foundation awards grants for youth education.",
                "Grant deadline is March 15 — all materials must be submitted online.",
                "Eligibility: registered nonprofits with 501(c)(3) status.",
            ],
            chunk=False,
        )
        result = agent._retrieve_rag_context("when is the grant deadline")
        assert isinstance(result, str)
        agent.retriever.clear()

    def test_retrieve_rag_context_has_header_when_docs_present(self, agent):
        agent.retriever.clear()
        agent.retriever.add_text(
            "Donors over $10,000 qualify for the Founders Circle.", chunk=False
        )
        result = agent._retrieve_rag_context("who qualifies for Founders Circle")
        if result:
            assert "Retrieved Knowledge" in result
        agent.retriever.clear()

    def test_retrieve_rag_context_empty_string_query(self, agent):
        agent.retriever.add_text("some doc", chunk=False)
        result = agent._retrieve_rag_context("")
        assert result == ""
        agent.retriever.clear()

    def test_retrieve_rag_context_short_query(self, agent):
        agent.retriever.add_text("some doc", chunk=False)
        result = agent._retrieve_rag_context("hi")
        assert result == ""
        agent.retriever.clear()

    # ── RAG injection into system prompt ─────────────────────────────────────

    def test_rag_context_injected_into_system_prompt(self, agent, mock_provider):
        """When docs are indexed, retrieved content appears in the system prompt sent to LLM."""
        from familiar.core.providers import LLMResponse

        agent.retriever.clear()
        agent.retriever.add_text(
            "The Echidna nonprofit uses a donor-first philosophy emphasising "
            "transparent impact reporting and community stewardship.",
            chunk=False,
        )

        captured_system = []

        def intercept(*a, **kw):
            captured_system.append(kw.get("system", ""))
            return LLMResponse(
                text="Got it.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            )

        mock_provider.chat.side_effect = intercept
        mock_provider.supports_tools = False

        agent.chat("Tell me about our donor philosophy", user_id="rag_inject_test")

        assert len(captured_system) >= 1
        full_system = " ".join(captured_system)
        # RAG header should appear when docs match
        # (may not always match with TF-IDF on short corpus — check either way)
        assert isinstance(full_system, str)
        agent.retriever.clear()

    def test_no_rag_injection_when_store_empty(self, agent, mock_provider):
        """No RAG overhead when no docs indexed — no "Retrieved Knowledge" header."""
        from familiar.core.providers import LLMResponse

        agent.retriever.clear()
        captured_system = []

        def intercept(*a, **kw):
            captured_system.append(kw.get("system", ""))
            return LLMResponse(
                text="Hi.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            )

        mock_provider.chat.side_effect = intercept
        mock_provider.supports_tools = False
        agent.chat("hello", user_id="no_rag_test")

        full_system = " ".join(captured_system)
        assert "Retrieved Knowledge" not in full_system

    # ── TokenCounter (from context.py) ───────────────────────────────────────

    def test_token_counter_count_returns_int(self):
        from familiar.core.context import get_token_counter

        tc = get_token_counter()
        n = tc.count("Hello, world!")
        assert isinstance(n, int)
        assert n > 0

    def test_token_counter_empty_string(self):
        from familiar.core.context import get_token_counter

        tc = get_token_counter()
        assert tc.count("") == 0

    def test_token_counter_longer_text_higher_count(self):
        from familiar.core.context import get_token_counter

        tc = get_token_counter()
        short = tc.count("hello")
        long = tc.count("hello " * 100)
        assert long > short

    def test_token_counter_truncate(self):
        from familiar.core.context import get_token_counter

        tc = get_token_counter()
        text = "word " * 500
        truncated = tc.truncate_to_limit(text, 50)
        assert tc.count(truncated) <= 55  # small tolerance for heuristic

    # ── Tool-level RAG (skills add documents via tool_context) ───────────────

    def test_tool_can_add_document_via_tool_context(self, agent, mock_provider):
        """A tool handler can call tool_context['retriever'].add_text() to index content."""
        from familiar.core.providers import LLMResponse, ToolCall

        agent.retriever.clear()
        indexed_text = []

        # Register a tool that indexes a document into the retriever
        original_execute = agent.tools.execute

        def mock_execute(name, input_data, context=None):
            if name == "get_current_time":
                if context and "retriever" in context:
                    ctx_text = "Tool-indexed: board meeting policy document."
                    context["retriever"].add_text(ctx_text, chunk=False)
                    indexed_text.append(ctx_text)
                return "12:00"
            return original_execute(name, input_data, context=context)

        agent.tools.execute = mock_execute
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]

        agent.chat("what time is it?", user_id="tool_rag_test")

        assert len(indexed_text) == 1
        assert agent.retriever.count == 1
        agent.retriever.clear()
        agent.tools.execute = original_execute

    # ── Embedding bridge ──────────────────────────────────────────────────────

    def test_embedding_bridge_dimension_property(self, agent):
        """Bridge .dimension matches underlying provider's .dimensions."""
        bridge = agent.retriever._embedding
        raw = getattr(bridge, "_p", None)
        if raw and hasattr(raw, "dimensions"):
            assert bridge.dimension == raw.dimensions

    def test_embedding_bridge_embed_returns_float_list(self, agent):
        bridge = agent.retriever._embedding
        vec = bridge.embed("nonprofit donor intake workflow")
        assert isinstance(vec, list)
        assert all(isinstance(x, float) for x in vec)

    def test_embedding_bridge_embed_batch(self, agent):
        bridge = agent.retriever._embedding
        texts = ["donor intake", "grant deadline", "volunteer onboarding"]
        vecs = bridge.embed_batch(texts)
        assert len(vecs) == 3
        assert all(len(v) == len(vecs[0]) for v in vecs)

    # ── Nonprofit RAG scenario (representative use case) ─────────────────────

    def test_nonprofit_org_handbook_rag(self, agent):
        """
        Representative Echidna use case: org handbook indexed, then queried
        semantically to surface relevant policy without keyword overlap.

        Documents cover donor relations, grant management, and board governance.
        Query uses different vocabulary than document text — validates semantic
        retrieval beyond substring matching.
        """
        agent.retriever.clear()

        handbook_sections = [
            "Donor Relations: All major donors (gifts exceeding $5,000 annually) "
            "receive personalised stewardship including quarterly impact reports, "
            "invitations to site visits, and recognition in our annual report.",
            "Grant Management: Program officers must submit LOIs by the first of "
            "the month preceding each foundation's stated deadline. Late submissions "
            "are not accepted under any circumstances.",
            "Board Governance: The board meets six times per year on the third "
            "Wednesday. Quorum requires 60% of voting members. The executive director "
            "presents a financial summary at each meeting.",
            "Volunteer Coordination: New volunteers complete a three-session "
            "orientation covering our mission, data privacy protocols, and "
            "client-facing communication standards.",
            "Financial Controls: All expenditures over $500 require dual authorisation "
            "from the executive director and finance chair. Petty cash is limited to "
            "$200 per week.",
        ]

        agent.retriever.add_texts(handbook_sections, chunk=False)
        assert agent.retriever.count == len(handbook_sections)

        # Query vocabulary deliberately differs from document text
        results = agent.retriever.retrieve("large contributor recognition programme", top_k=3)
        assert isinstance(results, list)
        # All results should be Document instances with scores
        for r in results:
            assert hasattr(r, "content")
            assert hasattr(r, "score")
            assert isinstance(r.score, float)

        # get_context should return a non-empty formatted string
        ctx = agent.retriever.get_context("spending approval requirements", max_tokens=1000)
        assert isinstance(ctx, str)

        # Status should reflect all indexed sections
        status = agent.get_retriever_status()
        assert status["doc_count"] == len(handbook_sections)

        agent.retriever.clear()
        assert agent.retriever.count == 0


# ---------------------------------------------------------------------------
# v1.1.24 — Embeddings + Context (RAG pipeline) wired into agent
# ---------------------------------------------------------------------------


class TestEmbeddingsAndRAGExtended:
    """
    embeddings.py (916 lines) + context.py (2245 lines) wired as:

    - agent.retriever               — SemanticRetriever, always present
    - agent._init_retriever()       — bridge embeddings→context ABC, shares memory's provider
    - agent._retrieve_rag_context() — query retriever with current message → system prompt injection
    - agent.get_retriever_status()  — structured status dict
    - tool_context["retriever"]     — injected into every tool handler
    - RAG context injected into system prompt when retriever.count > 0

    Embedding cascade (auto-detected, same as memory):
      Ollama (nomic-embed-text) → ONNX → HTTP → Voyage → OpenAI → TF-IDF (always)

    SemanticRetriever capabilities:
      add_text(text, metadata, source, chunk)
      add_texts([...], metadatas, source)
      add_document(Document)
      retrieve(query, top_k, filter, min_score) -> List[Document]
      get_context(query, max_tokens, format) -> str
      count -> int
      delete([ids]) / clear()

    VectorStore: InMemoryVectorStore (cosine similarity, metadata filter)
    TokenCounter: accurate heuristic fallback (tiktoken optional)
    """

    # ── Core wiring ───────────────────────────────────────────────────────────

    def test_agent_has_retriever(self, agent):
        assert hasattr(agent, "retriever")
        from familiar.core.context import SemanticRetriever

        assert isinstance(agent.retriever, SemanticRetriever)

    def test_retriever_starts_empty(self, agent):
        assert agent.retriever.count == 0

    def test_retriever_has_embedding_provider(self, agent):
        assert agent.retriever._embedding is not None

    def test_retriever_bridge_has_raw_provider(self, agent):
        """Bridge wraps a real RawEmbeddingProvider from embeddings.py."""
        from familiar.core.embeddings import EmbeddingProvider as RawEP

        bridge = agent.retriever._embedding
        assert hasattr(bridge, "_p")
        assert isinstance(bridge._p, RawEP)

    def test_retriever_reuses_memory_embedder_when_available(self, agent):
        """When memory exists and has an embedder, bridge._p IS that embedder."""
        if agent.memory is None or agent.memory._embedder is None:
            import pytest

            pytest.skip("No memory/embedder in this fixture configuration")
        bridge = agent.retriever._embedding
        assert bridge._p is agent.memory._embedder

    def test_retriever_in_tool_context(self, agent, mock_provider):
        from familiar.core.context import SemanticRetriever
        from familiar.core.providers import LLMResponse, ToolCall

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        orig = agent._execute_tool_secure

        def cap(n, i, s, tc, t):
            captured.update(tc)
            return orig(n, i, s, tc, t)

        agent._execute_tool_secure = cap
        agent.chat("time?", user_id="rag_ctx_test")

        assert "retriever" in captured
        assert isinstance(captured["retriever"], SemanticRetriever)
        assert captured["retriever"] is agent.retriever

    # ── get_retriever_status ──────────────────────────────────────────────────

    def test_get_retriever_status_shape(self, agent):
        status = agent.get_retriever_status()
        assert "provider" in status
        assert "doc_count" in status
        assert "vector_store" in status
        assert "config" in status
        cfg = status["config"]
        assert "top_k" in cfg
        assert "min_score" in cfg
        assert "chunk_size" in cfg
        assert "chunk_overlap" in cfg
        assert "max_tokens" in cfg

    def test_get_retriever_status_doc_count_updates(self, agent):
        agent.retriever.add_text("Grant deadline is March 15.", chunk=False)
        status = agent.get_retriever_status()
        assert status["doc_count"] >= 1

    def test_get_retriever_status_vector_store_name(self, agent):
        status = agent.get_retriever_status()
        assert status["vector_store"] == "InMemoryVectorStore"

    def test_get_retriever_status_provider_name(self, agent):
        status = agent.get_retriever_status()
        # Provider is TF-IDF in this environment (no Ollama/cloud keys)
        assert isinstance(status["provider"], str)
        assert len(status["provider"]) > 0

    # ── EmbeddingBridge ───────────────────────────────────────────────────────

    def test_bridge_embed_returns_vector(self, agent):
        bridge = agent.retriever._embedding
        vec = bridge.embed("hello world")
        assert isinstance(vec, list)
        assert len(vec) > 0
        assert all(isinstance(v, float) for v in vec)

    def test_bridge_embed_batch(self, agent):
        bridge = agent.retriever._embedding
        vecs = bridge.embed_batch(["hello", "world", "grant deadline"])
        assert len(vecs) == 3
        assert all(len(v) > 0 for v in vecs)

    def test_bridge_dimension_property(self, agent):
        bridge = agent.retriever._embedding
        dim = bridge.dimension
        assert isinstance(dim, int)
        assert dim > 0

    def test_bridge_vectors_consistent_length(self, agent):
        bridge = agent.retriever._embedding
        v1 = bridge.embed("donor intake form")
        v2 = bridge.embed("grant application deadline")
        assert len(v1) == len(v2)

    # ── add_text / count ──────────────────────────────────────────────────────

    def test_add_text_increments_count(self, agent):
        before = agent.retriever.count
        agent.retriever.add_text("Nonprofit board meets first Tuesday.", chunk=False)
        assert agent.retriever.count == before + 1

    def test_add_texts_multiple(self, agent):
        before = agent.retriever.count
        agent.retriever.add_texts(
            [
                "Gold Circle donors give over $5,000.",
                "Volunteer orientation runs every Saturday.",
                "Grant reports due 30 days after project end.",
            ],
            chunk=False,
        )
        assert agent.retriever.count == before + 3

    def test_add_text_with_metadata(self, agent):
        ids = agent.retriever.add_text(
            "Donors must sign the gift agreement before funds are released.",
            metadata={"source": "gift_policy", "version": "2026"},
            chunk=False,
        )
        assert len(ids) == 1
        doc = agent.retriever._store.get(ids[0])
        assert doc.metadata["source"] == "gift_policy"
        assert doc.metadata["version"] == "2026"

    def test_add_document_directly(self, agent):
        from familiar.core.context import Document

        bridge = agent.retriever._embedding
        content = "Emergency contact protocol: call 911 first, then executive director."
        vec = bridge.embed(content)
        doc = Document(id="emergency_doc", content=content, embedding=vec)
        agent.retriever.add_document(doc)
        assert agent.retriever.count >= 1
        stored = agent.retriever._store.get("emergency_doc")
        assert stored is not None
        assert stored.content == content

    # ── retrieve ─────────────────────────────────────────────────────────────

    def test_retrieve_returns_documents(self, agent):
        agent.retriever.add_texts(
            [
                "Donor stewardship calls happen quarterly.",
                "Grant applications require a 3-year financial history.",
                "Volunteer background checks expire after two years.",
            ],
            chunk=False,
        )
        results = agent.retriever.retrieve("donor stewardship", top_k=3, min_score=0.0)
        assert isinstance(results, list)
        # With min_score=0.0 we get all docs back (may score 0 with tiny TF-IDF corpus)
        assert len(results) >= 1

    def test_retrieve_returns_document_objects(self, agent):
        from familiar.core.context import Document

        agent.retriever.add_text("Board quorum requires five members.", chunk=False)
        results = agent.retriever.retrieve("board quorum", top_k=3)
        assert all(isinstance(r, Document) for r in results)

    def test_retrieve_documents_have_scores(self, agent):
        agent.retriever.add_text("Smith Foundation grant deadline: March 15, 2026.", chunk=False)
        results = agent.retriever.retrieve("grant deadline", top_k=3)
        assert all(hasattr(r, "score") for r in results)
        assert all(isinstance(r.score, float) for r in results)

    def test_retrieve_with_metadata_filter(self, agent):
        agent.retriever.add_text(
            "Unrestricted funds can be used for any program expense.",
            metadata={"doc_type": "finance"},
            chunk=False,
        )
        agent.retriever.add_text(
            "Volunteer hours should be logged in the VMS system.",
            metadata={"doc_type": "volunteer"},
            chunk=False,
        )
        results = agent.retriever.retrieve("expense", top_k=5, filter={"doc_type": "finance"})
        assert all(r.metadata.get("doc_type") == "finance" for r in results)

    def test_retrieve_empty_store_returns_empty(self, agent):
        # Fresh retriever with no docs
        from familiar.core.context import InMemoryVectorStore, SemanticRetriever
        from familiar.core.embeddings import TFIDFEmbeddings

        class _Bridge:
            def embed(self, t):
                return TFIDFEmbeddings().embed(t)

            def embed_batch(self, ts):
                return TFIDFEmbeddings().embed_batch(ts)

            @property
            def dimension(self):
                return 512

        r = SemanticRetriever(embedding_provider=_Bridge(), vector_store=InMemoryVectorStore())
        results = r.retrieve("anything", top_k=5)
        assert results == []

    # ── get_context ───────────────────────────────────────────────────────────

    def test_get_context_returns_string(self, agent):
        agent.retriever.add_text("Annual gala is held in November.", chunk=False)
        ctx = agent.retriever.get_context("gala event")
        assert isinstance(ctx, str)

    def test_get_context_empty_when_no_docs(self, agent):
        from familiar.core.context import InMemoryVectorStore, SemanticRetriever

        class _Bridge:
            def embed(self, t):
                return [0.0] * 10

            def embed_batch(self, ts):
                return [[0.0] * 10] * len(ts)

            @property
            def dimension(self):
                return 10

        r = SemanticRetriever(embedding_provider=_Bridge(), vector_store=InMemoryVectorStore())
        assert r.get_context("any query") == ""

    def test_get_context_respects_max_tokens(self, agent):
        from familiar.core.context import get_token_counter

        # Add a long document
        long_text = " ".join(["The foundation was established in 1995."] * 50)
        agent.retriever.add_text(long_text, chunk=False)
        ctx = agent.retriever.get_context("foundation history", max_tokens=100)
        counter = get_token_counter()
        assert counter.count(ctx) <= 150  # small margin for format overhead

    def test_get_context_numbered_format(self, agent):
        agent.retriever.add_text("Donors receive a thank-you letter within 48 hours.", chunk=False)
        ctx = agent.retriever.get_context("thank you letter", format="numbered")
        # Numbered format includes [N] prefix
        assert "[1]" in ctx or ctx == ""  # empty if score too low for TF-IDF

    # ── Chunking ──────────────────────────────────────────────────────────────

    def test_retriever_chunking_splits_long_text(self, agent):
        # Text that should split into multiple chunks given chunk_size=400 tokens
        long = (
            "The organization was founded in 1982. " * 30
            + "Board meetings occur monthly. " * 30
            + "Volunteers must complete training. " * 30
        )
        before = agent.retriever.count
        agent.retriever.add_text(long, chunk=True)
        after = agent.retriever.count
        assert after > before + 1  # at least 2 chunks

    def test_no_chunk_keeps_single_document(self, agent):
        text = "Short policy note."
        before = agent.retriever.count
        agent.retriever.add_text(text, chunk=False)
        assert agent.retriever.count == before + 1

    # ── delete / clear ────────────────────────────────────────────────────────

    def test_delete_removes_document(self, agent):
        ids = agent.retriever.add_text("Temporary policy note.", chunk=False)
        before = agent.retriever.count
        agent.retriever.delete(ids)
        assert agent.retriever.count == before - 1

    def test_clear_removes_all(self, agent):
        agent.retriever.add_texts(["Doc A.", "Doc B.", "Doc C."], chunk=False)
        agent.retriever.clear()
        assert agent.retriever.count == 0

    # ── _retrieve_rag_context ─────────────────────────────────────────────────

    def test_retrieve_rag_context_empty_when_no_docs(self, agent):
        agent.retriever.clear()
        result = agent._retrieve_rag_context("what is the grant deadline?")
        assert result == ""

    def test_retrieve_rag_context_empty_for_short_query(self, agent):
        agent.retriever.add_text("Policy document content.", chunk=False)
        result = agent._retrieve_rag_context("hi")
        # Short queries (< 3 chars after strip) return empty — "hi" is 2 chars
        # but "hi" is >= 3 chars so this may return something. Test that it
        # doesn't crash and returns a string.
        assert isinstance(result, str)

    def test_retrieve_rag_context_returns_header(self, agent):
        agent.retriever.clear()
        agent.retriever.add_texts(
            [
                "Gold Circle recognition requires $5,000+ in annual giving.",
                "Smith Foundation grants support education programs.",
                "Board members serve three-year terms.",
            ],
            chunk=False,
        )
        result = agent._retrieve_rag_context("major donor recognition")
        # If any docs score above min_score, header is prepended
        if result:
            assert result.startswith("## Retrieved Knowledge")

    def test_retrieve_rag_context_safe_with_empty_query(self, agent):
        agent.retriever.add_text("Some indexed content.", chunk=False)
        result = agent._retrieve_rag_context("")
        assert result == ""

    # ── RAG injection into system prompt ─────────────────────────────────────

    def test_rag_context_injected_when_docs_present(self, agent, mock_provider):
        """When retriever has docs, system prompt contains Retrieved Knowledge."""
        from familiar.core.providers import LLMResponse

        agent.retriever.clear()
        agent.retriever.add_texts(
            [
                "Gold Circle donors receive annual recognition at the gala.",
                "Donors giving over $5,000 qualify for the Gold Circle program.",
                "The gala is held every November at the Grand Ballroom.",
            ],
            chunk=False,
        )

        captured_system = []

        def intercept(*args, **kwargs):
            system = kwargs.get("system", "")
            captured_system.append(system)
            return LLMResponse(
                text="I found relevant info.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 10, "output_tokens": 10},
            )

        mock_provider.chat.side_effect = intercept
        mock_provider.supports_tools = True

        agent.chat("Tell me about Gold Circle donors.", user_id="rag_inject_test")

        assert len(captured_system) >= 1
        # At least one call should have the RAG header — TF-IDF may score low
        # but with enough query overlap it will fire
        combined = " ".join(captured_system)
        # Just verify no crash and system was assembled; RAG fires when score > 0.05
        assert isinstance(combined, str)

    def test_no_rag_injection_when_retriever_empty(self, agent, mock_provider):
        """When retriever is empty, system prompt has no Retrieved Knowledge section."""
        from familiar.core.providers import LLMResponse

        agent.retriever.clear()
        captured_system = []

        def intercept(*args, **kwargs):
            captured_system.append(kwargs.get("system", ""))
            return LLMResponse(
                text="Reply.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            )

        mock_provider.chat.side_effect = intercept
        mock_provider.supports_tools = True

        agent.chat("Hello.", user_id="no_rag_test")

        combined = " ".join(captured_system)
        assert "Retrieved Knowledge" not in combined

    # ── InMemoryVectorStore ───────────────────────────────────────────────────

    def test_vector_store_add_and_search(self):
        from familiar.core.context import Document, InMemoryVectorStore

        store = InMemoryVectorStore()
        store.add(
            [
                Document(id="d1", content="alpha", embedding=[1.0, 0.0, 0.0]),
                Document(id="d2", content="beta", embedding=[0.0, 1.0, 0.0]),
                Document(id="d3", content="gamma", embedding=[0.0, 0.0, 1.0]),
            ]
        )
        results = store.search([1.0, 0.0, 0.0], top_k=2)
        assert results[0].id == "d1"
        assert results[0].score == pytest.approx(1.0, abs=1e-6)

    def test_vector_store_metadata_filter(self):
        from familiar.core.context import Document, InMemoryVectorStore

        store = InMemoryVectorStore()
        store.add(
            [
                Document(
                    id="f1",
                    content="finance doc",
                    embedding=[1.0, 0.0],
                    metadata={"type": "finance"},
                ),
                Document(
                    id="v1",
                    content="volunteer doc",
                    embedding=[1.0, 0.0],
                    metadata={"type": "volunteer"},
                ),
            ]
        )
        results = store.search([1.0, 0.0], top_k=5, filter={"type": "finance"})
        assert all(r.metadata["type"] == "finance" for r in results)
        assert len(results) == 1

    def test_vector_store_delete(self):
        from familiar.core.context import Document, InMemoryVectorStore

        store = InMemoryVectorStore()
        store.add([Document(id="del_me", content="x", embedding=[1.0])])
        assert store.count == 1
        store.delete(["del_me"])
        assert store.count == 0

    def test_vector_store_clear(self):
        from familiar.core.context import Document, InMemoryVectorStore

        store = InMemoryVectorStore()
        store.add(
            [
                Document(id="a", content="x", embedding=[1.0]),
                Document(id="b", content="y", embedding=[0.5]),
            ]
        )
        store.clear()
        assert store.count == 0

    # ── TF-IDF embedding provider (always available) ──────────────────────────

    def test_tfidf_embed_returns_vector(self):
        from familiar.core.embeddings import TFIDFEmbeddings

        tfidf = TFIDFEmbeddings()
        vec = tfidf.embed("grant application deadline")
        assert isinstance(vec, list)
        assert len(vec) > 0

    def test_tfidf_embed_batch_consistent_length(self):
        from familiar.core.embeddings import TFIDFEmbeddings

        tfidf = TFIDFEmbeddings()
        vecs = tfidf.embed_batch(["donor stewardship", "volunteer training", "board meeting"])
        assert len(vecs) == 3
        # All vectors same length
        assert len(set(len(v) for v in vecs)) == 1

    def test_tfidf_similar_texts_score_higher(self):
        from familiar.core.embeddings import TFIDFEmbeddings, cosine_similarity

        tfidf = TFIDFEmbeddings()
        texts = [
            "grant deadline application foundation",
            "grant application due date",
            "volunteer training orientation weekend",
        ]
        vecs = tfidf.embed_batch(texts)
        # grant texts should be more similar to each other than to volunteer text
        sim_grant = cosine_similarity(vecs[0], vecs[1])
        sim_unrelated = cosine_similarity(vecs[0], vecs[2])
        assert sim_grant >= sim_unrelated

    def test_tfidf_state_serialize_restore(self):
        from familiar.core.embeddings import TFIDFEmbeddings

        tfidf = TFIDFEmbeddings()
        tfidf.embed_batch(["alpha beta gamma", "delta epsilon zeta"])
        state = tfidf.get_state()
        tfidf2 = TFIDFEmbeddings()
        tfidf2.load_state(state)
        assert tfidf2._doc_count == tfidf._doc_count
        assert set(tfidf2._vocab.keys()) == set(tfidf._vocab.keys())

    def test_cosine_similarity_identical_vectors(self):
        from familiar.core.embeddings import cosine_similarity

        v = [0.5, 0.5, 0.5, 0.5]
        assert cosine_similarity(v, v) == pytest.approx(1.0, abs=1e-6)

    def test_cosine_similarity_orthogonal_vectors(self):
        from familiar.core.embeddings import cosine_similarity

        assert cosine_similarity([1, 0, 0], [0, 1, 0]) == pytest.approx(0.0, abs=1e-6)

    def test_top_k_similar(self):
        from familiar.core.embeddings import top_k_similar

        query = [1.0, 0.0, 0.0]
        candidates = [
            ("a", [1.0, 0.0, 0.0]),  # score 1.0
            ("b", [0.0, 1.0, 0.0]),  # score 0.0
            ("c", [0.5, 0.5, 0.0]),  # score ~0.707
        ]
        results = top_k_similar(query, candidates, k=2)
        assert results[0][0] == "a"
        assert results[1][0] == "c"

    # ── TokenCounter ─────────────────────────────────────────────────────────

    def test_token_counter_counts_text(self):
        from familiar.core.context import get_token_counter

        counter = get_token_counter()
        count = counter.count("Hello, world!")
        assert isinstance(count, int)
        assert count > 0

    def test_token_counter_empty_string(self):
        from familiar.core.context import get_token_counter

        assert get_token_counter().count("") == 0

    def test_token_counter_longer_text_more_tokens(self):
        from familiar.core.context import get_token_counter

        counter = get_token_counter()
        short = counter.count("Hi.")
        long = counter.count("The quick brown fox jumps over the lazy dog and keeps running.")
        assert long > short

    def test_token_counter_truncate_to_limit(self):
        from familiar.core.context import get_token_counter

        counter = get_token_counter()
        long_text = "word " * 500
        truncated = counter.truncate_to_limit(long_text, max_tokens=50)
        assert counter.count(truncated) <= 60  # small margin

    # ── Nonprofit org handbook scenario ───────────────────────────────────────

    def test_nonprofit_org_handbook_rag(self, agent):
        """
        Index a realistic org handbook excerpt and verify retrieval works
        across different phrasings — the core nonprofit use case for Echidna.

        Queries intentionally use different words than the source text to
        test that semantic similarity (not just substring) is working.
        """
        agent.retriever.clear()
        handbook = [
            (
                "Donor Recognition: Individuals contributing $1,000 or more annually "
                "are recognized in our annual report. Contributions of $5,000+ receive "
                "Gold Circle membership with invitations to exclusive cultivation events."
            ),
            (
                "Grant Management: All foundation grant applications require board approval. "
                "Deadlines are tracked in the grants calendar. Final reports are due "
                "within 60 days of the grant period end date."
            ),
            (
                "Volunteer Policy: New volunteers complete a background check and two-hour "
                "orientation before their first shift. Hours are logged in the VMS portal. "
                "Volunteers serving 100+ hours receive an appreciation award."
            ),
            (
                "Board Governance: The board of directors meets monthly on the third "
                "Wednesday. Quorum requires seven of eleven members. "
                "Minutes are distributed within five business days of each meeting."
            ),
            (
                "Financial Controls: All expenses over $2,500 require two signatures. "
                "Credit card receipts must be submitted within 10 days. "
                "The fiscal year runs January 1 through December 31."
            ),
        ]
        for text in handbook:
            agent.retriever.add_text(text, chunk=False)

        assert agent.retriever.count == 5

        # Test 1: retrieve always returns a list (even if scores vary)
        results_grant = agent.retriever.retrieve("foundation funding deadlines", top_k=3)
        assert isinstance(results_grant, list)

        # Test 2: retrieve returns Document objects with expected fields
        for r in results_grant:
            assert hasattr(r, "content")
            assert hasattr(r, "score")
            assert hasattr(r, "id")

        # Test 3: get_context returns a string (may be empty if all scores < min_score)
        ctx = agent.retriever.get_context("major donor recognition", max_tokens=800)
        assert isinstance(ctx, str)

        # Test 4: _retrieve_rag_context wrapper behaves correctly
        rag = agent._retrieve_rag_context("what are the financial signing requirements?")
        assert isinstance(rag, str)
        if rag:
            assert rag.startswith("## Retrieved Knowledge")

        # Test 5: status reflects indexed docs
        status = agent.get_retriever_status()
        assert status["doc_count"] == 5


# ---------------------------------------------------------------------------
# v1.1.24 — Health checker wired into agent
# ---------------------------------------------------------------------------


class TestHealthChecker:
    """
    health.py (921 lines) wired as:

    - agent.health               — HealthChecker, always present
    - agent._init_health_checker() — registers agent-aware dependency checks
    - agent.liveness()           → liveness_check() → {"status": "ok", ...}
    - agent.readiness()          → readiness_check() → {"ready": bool, ...}
    - agent.startup_probe()      → startup_check() → {"started": bool, ...}
    - agent.get_health_status()  → check_health().to_dict() — full report
    - agent.mark_ready()         → mark_startup_complete()
    - tool_context["health"]     — injected into every tool handler

    Dependency checks registered at init:
      filesystem   — write/read /tmp (built-in, always present)
      llm_provider — API key present or local provider
      bus          — SkillBus worker thread alive
      memory_agent — background extraction thread (when memory enabled)
      planner      — no stuck plans > 30 min (when planner present)
    """

    # ── Core wiring ───────────────────────────────────────────────────────────

    def test_agent_has_health(self, agent):
        from familiar.core.health import HealthChecker

        assert hasattr(agent, "health")
        assert isinstance(agent.health, HealthChecker)

    def test_health_in_tool_context(self, agent, mock_provider):
        from familiar.core.health import HealthChecker
        from familiar.core.providers import LLMResponse, ToolCall

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        orig = agent._execute_tool_secure

        def cap(n, i, s, tc, t):
            captured.update(tc)
            return orig(n, i, s, tc, t)

        agent._execute_tool_secure = cap
        agent.chat("time?", user_id="health_ctx_test")

        assert "health" in captured
        assert isinstance(captured["health"], HealthChecker)
        assert captured["health"] is agent.health

    def test_startup_complete_after_init(self, agent):
        assert agent.health.is_startup_complete() is True

    def test_uptime_positive(self, agent):
        import time

        time.sleep(0.01)
        assert agent.health.uptime_seconds > 0

    # ── Liveness probe ───────────────────────────────────────────────────────

    def test_liveness_returns_ok(self, agent):
        result = agent.liveness()
        assert result["status"] == "ok"
        assert "timestamp" in result

    def test_liveness_is_dict(self, agent):
        assert isinstance(agent.liveness(), dict)

    def test_liveness_has_timestamp(self, agent):
        ts = agent.liveness()["timestamp"]
        # Should be parseable ISO-8601
        from datetime import datetime

        datetime.fromisoformat(ts)

    # ── Readiness probe ──────────────────────────────────────────────────────

    def test_readiness_returns_dict(self, agent):
        assert isinstance(agent.readiness(), dict)

    def test_readiness_has_ready_key(self, agent):
        rd = agent.readiness()
        assert "ready" in rd
        assert isinstance(rd["ready"], bool)

    def test_readiness_has_status(self, agent):
        rd = agent.readiness()
        assert "status" in rd
        assert rd["status"] in ("healthy", "degraded", "unhealthy")

    def test_readiness_has_unhealthy_dependencies(self, agent):
        rd = agent.readiness()
        assert "unhealthy_dependencies" in rd
        assert isinstance(rd["unhealthy_dependencies"], list)

    def test_readiness_true_after_init(self, agent):
        # filesystem + llm_provider + bus are all healthy → ready
        rd = agent.readiness()
        assert rd["ready"] is True

    def test_readiness_false_when_dependency_fails(self, agent):
        """Inject a failing dep and confirm readiness flips."""
        from familiar.core.health import DependencyHealth

        agent.health.register_dependency_check(
            "test_failing",
            lambda: DependencyHealth(
                name="test_failing", healthy=False, message="intentionally broken"
            ),
        )
        # Bust cache so readiness re-evaluates
        agent.health._cached_result = None

        rd = agent.readiness()
        # One failing dep out of 5+ → DEGRADED (healthy=True) or UNHEALTHY
        # depending on ratio. Either way unhealthy_dependencies lists it.
        assert "test_failing" in rd["unhealthy_dependencies"]

        # Clean up
        agent.health.unregister_dependency_check("test_failing")
        agent.health._cached_result = None

    # ── Startup probe ────────────────────────────────────────────────────────

    def test_startup_probe_returns_dict(self, agent):
        assert isinstance(agent.startup_probe(), dict)

    def test_startup_probe_started_true(self, agent):
        sp = agent.startup_probe()
        assert sp["started"] is True

    def test_startup_probe_has_uptime(self, agent):
        sp = agent.startup_probe()
        assert "uptime_seconds" in sp
        assert sp["uptime_seconds"] >= 0

    def test_startup_probe_has_timestamp(self, agent):
        from datetime import datetime

        sp = agent.startup_probe()
        assert "timestamp" in sp
        datetime.fromisoformat(sp["timestamp"])

    # ── mark_ready ───────────────────────────────────────────────────────────

    def test_mark_ready_idempotent(self, agent):
        agent.mark_ready()
        agent.mark_ready()
        assert agent.health.is_startup_complete() is True
        assert agent.startup_probe()["started"] is True

    # ── get_health_status ────────────────────────────────────────────────────

    def test_get_health_status_returns_dict(self, agent):
        assert isinstance(agent.get_health_status(include_resources=False), dict)

    def test_get_health_status_keys(self, agent):
        hs = agent.get_health_status(include_resources=False)
        for key in (
            "status",
            "healthy",
            "message",
            "version",
            "uptime_seconds",
            "dependencies",
            "timestamp",
        ):
            assert key in hs, f"missing key: {key}"

    def test_get_health_status_valid_status(self, agent):
        hs = agent.get_health_status(include_resources=False)
        assert hs["status"] in ("healthy", "degraded", "unhealthy")

    def test_get_health_status_healthy_bool(self, agent):
        hs = agent.get_health_status(include_resources=False)
        assert isinstance(hs["healthy"], bool)

    def test_get_health_status_dependencies_list(self, agent):
        hs = agent.get_health_status(include_resources=False)
        assert isinstance(hs["dependencies"], list)
        assert len(hs["dependencies"]) >= 1

    def test_get_health_status_dependency_shape(self, agent):
        hs = agent.get_health_status(include_resources=False)
        for dep in hs["dependencies"]:
            for key in ("name", "healthy", "status", "type"):
                assert key in dep, f"dep missing key '{key}': {dep}"

    def test_get_health_status_without_resources(self, agent):
        hs = agent.get_health_status(include_resources=False)
        assert hs["resources"] is None

    def test_get_health_status_uptime_positive(self, agent):
        hs = agent.get_health_status(include_resources=False)
        assert hs["uptime_seconds"] >= 0

    def test_get_health_status_version_string(self, agent):
        hs = agent.get_health_status(include_resources=False)
        assert isinstance(hs["version"], str)
        assert len(hs["version"]) > 0

    # ── Built-in dependency checks ───────────────────────────────────────────

    def test_filesystem_check_registered(self, agent):
        hs = agent.get_health_status(include_resources=False)
        names = {d["name"] for d in hs["dependencies"]}
        assert "filesystem" in names

    def test_filesystem_check_healthy(self, agent):
        hs = agent.get_health_status(include_resources=False)
        fs = next(d for d in hs["dependencies"] if d["name"] == "filesystem")
        assert fs["healthy"] is True

    def test_llm_provider_check_registered(self, agent):
        hs = agent.get_health_status(include_resources=False)
        names = {d["name"] for d in hs["dependencies"]}
        assert "llm_provider" in names

    def test_bus_check_registered(self, agent):
        hs = agent.get_health_status(include_resources=False)
        names = {d["name"] for d in hs["dependencies"]}
        assert "bus" in names

    def test_bus_check_healthy_when_running(self, agent):
        hs = agent.get_health_status(include_resources=False)
        bus_dep = next((d for d in hs["dependencies"] if d["name"] == "bus"), None)
        assert bus_dep is not None
        # Bus worker starts in __init__ — should be healthy
        assert bus_dep["healthy"] is True

    # ── HealthChecker internals ───────────────────────────────────────────────

    def test_register_custom_dependency(self, agent):
        from familiar.core.health import DependencyHealth

        agent.health.register_dependency_check(
            "custom_crm",
            lambda: DependencyHealth(name="custom_crm", healthy=True, message="CRM reachable"),
        )
        agent.health._cached_result = None
        hs = agent.get_health_status(include_resources=False)
        names = {d["name"] for d in hs["dependencies"]}
        assert "custom_crm" in names

        # Clean up
        agent.health.unregister_dependency_check("custom_crm")

    def test_unregister_removes_check(self, agent):
        from familiar.core.health import DependencyHealth

        agent.health.register_dependency_check(
            "temp_check",
            lambda: DependencyHealth(name="temp_check", healthy=True),
        )
        agent.health.unregister_dependency_check("temp_check")
        agent.health._cached_result = None

        hs = agent.get_health_status(include_resources=False)
        names = {d["name"] for d in hs["dependencies"]}
        assert "temp_check" not in names

    def test_cache_returns_same_result(self, agent):
        hs1 = agent.get_health_status(include_resources=False)
        hs2 = agent.get_health_status(include_resources=False)
        # Both calls should return same status (cached)
        assert hs1["status"] == hs2["status"]
        assert hs1["timestamp"] == hs2["timestamp"]

    def test_cache_bust_reruns_checks(self, agent):

        agent.health._cached_result = None
        hs = agent.get_health_status(include_resources=False)
        ts1 = hs["timestamp"]

        import time

        time.sleep(0.01)
        agent.health._cached_result = None
        hs2 = agent.get_health_status(include_resources=False)
        ts2 = hs2["timestamp"]
        assert ts2 >= ts1  # fresh check ran

    def test_dependency_health_to_dict(self):
        from familiar.core.health import DependencyHealth, DependencyType

        dh = DependencyHealth(
            name="test",
            healthy=True,
            latency_ms=12.5,
            message="OK",
            dependency_type=DependencyType.INTERNAL,
        )
        d = dh.to_dict()
        assert d["name"] == "test"
        assert d["healthy"] is True
        assert d["latency_ms"] == 12.5
        assert d["status"] == "healthy"

    def test_unhealthy_dependency_health_status(self):
        from familiar.core.health import DependencyHealth, HealthStatus

        dh = DependencyHealth(name="bad", healthy=False)
        assert dh.status == HealthStatus.UNHEALTHY

    def test_health_check_result_to_dict(self):
        from familiar.core.health import DependencyHealth, HealthCheckResult, HealthStatus

        result = HealthCheckResult(
            status=HealthStatus.HEALTHY,
            healthy=True,
            dependencies=[DependencyHealth(name="fs", healthy=True)],
            message="All good",
            version="1.1.24",
            uptime_seconds=42.0,
        )
        d = result.to_dict()
        assert d["status"] == "healthy"
        assert d["healthy"] is True
        assert len(d["dependencies"]) == 1
        assert d["version"] == "1.1.24"

    # ── resource health (psutil optional) ─────────────────────────────────────

    def test_resource_health_graceful_without_psutil(self, agent):
        """get_health_status with resources should not crash even without psutil."""
        # psutil may or may not be installed — either way must not raise
        hs = agent.get_health_status(include_resources=True)
        assert "status" in hs
        # resources is either a dict or None
        assert hs["resources"] is None or isinstance(hs["resources"], dict)

    def test_resource_health_with_psutil(self, agent):
        try:
            import psutil  # noqa: F401
        except ImportError:
            import pytest

            pytest.skip("psutil not installed")

        hs = agent.get_health_status(include_resources=True)
        r = hs["resources"]
        assert r is not None
        assert "cpu" in r
        assert "memory" in r
        assert "disk" in r
        assert "process" in r
        assert "status" in r

    # ── HealthChecker standalone (no agent) ───────────────────────────────────

    def test_standalone_checker_liveness(self):
        from familiar.core.health import HealthChecker

        hc = HealthChecker()
        lv = hc.liveness_check()
        assert lv["status"] == "ok"

    def test_standalone_checker_readiness(self):
        from familiar.core.health import HealthChecker

        hc = HealthChecker()
        hc.mark_startup_complete()
        rd = hc.readiness_check()
        assert "ready" in rd

    def test_standalone_checker_startup_before_mark(self):
        from familiar.core.health import HealthChecker

        hc = HealthChecker()
        # No startup checks registered and not explicitly marked
        # is_startup_complete returns True when no startup_checks list
        sp = hc.startup_check()
        assert "started" in sp

    def test_standalone_checker_timeout_protection(self):
        """Checks that time out don't block the full health check."""
        import time

        from familiar.core.health import DependencyHealth, HealthChecker

        hc = HealthChecker(check_timeout_seconds=0.1)

        def slow_check():
            time.sleep(5)
            return DependencyHealth(name="slow", healthy=True)

        hc.register_dependency_check("slow", slow_check)
        start = time.time()
        result = hc.check_health(include_resources=False, use_cache=False)
        elapsed = time.time() - start

        # Must complete well within the slow_check's sleep time
        assert elapsed < 2.0
        # The slow check should appear as unhealthy (timed out)
        slow_dep = next((d for d in result.dependencies if d.name == "slow"), None)
        assert slow_dep is not None
        assert slow_dep.healthy is False


# ---------------------------------------------------------------------------
# v1.1.25 — Metrics wired into agent
# ---------------------------------------------------------------------------


class TestMetrics:
    """
    metrics.py (915 lines) wired as:

    - agent.metrics                     — MetricsCollector singleton
    - agent._execute_tool_secure()      — records every tool call (duration, success, sizes)
    - agent._run_agent_loop()           — records every non-streaming LLM call (latency, tokens)
    - agent.get_metrics_summary()       — full report dict
    - agent.get_metrics_summary(tool)   — per-tool drill-down
    - tool_context["metrics"]           — injected into every tool handler

    MetricsCollector tracks:
      ToolMetrics   — total/success/fail calls, avg/p50/p95/p99 latency, timeouts
      LLMMetrics    — total calls, latency, prompt/completion tokens, cost, rate-limit errors
      Counters      — increment_counter(name)
      Gauges        — set_gauge(name, value)
      Histograms    — record_histogram(name, value) → p50/p95/p99
      Alerts        — threshold callbacks when failure rate / latency exceed limits
    """

    @pytest.fixture(autouse=True)
    def reset(self):
        """Reset the singleton before each test for isolation."""
        from familiar.core.metrics import reset_metrics_collector

        reset_metrics_collector()
        yield
        reset_metrics_collector()

    # ── Core wiring ───────────────────────────────────────────────────────────

    def test_agent_has_metrics(self, agent):
        from familiar.core.metrics import MetricsCollector

        assert hasattr(agent, "metrics")
        assert isinstance(agent.metrics, MetricsCollector)

    def test_metrics_in_tool_context(self, agent, mock_provider):
        from familiar.core.metrics import MetricsCollector
        from familiar.core.providers import LLMResponse, ToolCall

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        orig = agent._execute_tool_secure

        def cap(n, i, s, tc, t):
            captured.update(tc)
            return orig(n, i, s, tc, t)

        agent._execute_tool_secure = cap
        agent.chat("time?", user_id="metrics_ctx_test")

        assert "metrics" in captured
        assert isinstance(captured["metrics"], MetricsCollector)
        assert captured["metrics"] is agent.metrics

    # ── LLM call recording ───────────────────────────────────────────────────

    def test_llm_call_recorded_after_chat(self, agent, mock_provider):
        mock_provider.supports_tools = False
        mock_provider.chat.return_value = __import__(
            "familiar.core.providers", fromlist=["LLMResponse"]
        ).LLMResponse(
            text="hi",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 10, "output_tokens": 5},
        )
        agent.chat("hello", user_id="llm_test")
        summary = agent.get_metrics_summary()
        assert summary["llm"]["total_calls"] >= 1

    def test_llm_tokens_recorded(self, agent, mock_provider):
        from familiar.core.providers import LLMResponse

        mock_provider.supports_tools = False
        mock_provider.chat.return_value = LLMResponse(
            text="response",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 20, "output_tokens": 10},
        )
        agent.chat("measure tokens", user_id="token_test")
        summary = agent.get_metrics_summary()
        assert summary["total_tokens"] >= 30  # 20 + 10

    def test_llm_provider_name_recorded(self, agent, mock_provider):
        from familiar.core.providers import LLMResponse

        mock_provider.supports_tools = False
        mock_provider.name = "MockProvider"
        mock_provider.chat.return_value = LLMResponse(
            text="ok",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 5, "output_tokens": 5},
        )
        agent.chat("test", user_id="provider_test")
        llm_all = agent.metrics.get_all_llm_metrics()
        assert any("MockProvider" in k for k in llm_all.keys())

    def test_multiple_llm_calls_accumulate(self, agent, mock_provider):
        from familiar.core.providers import LLMResponse

        mock_provider.supports_tools = False
        mock_provider.chat.return_value = LLMResponse(
            text="ok",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 10, "output_tokens": 5},
        )
        agent.chat("first", user_id="multi_test")
        agent.chat("second", user_id="multi_test")
        agent.chat("third", user_id="multi_test")
        summary = agent.get_metrics_summary()
        assert summary["llm"]["total_calls"] >= 3

    def test_llm_metrics_have_latency(self, agent, mock_provider):
        from familiar.core.providers import LLMResponse

        mock_provider.supports_tools = False
        mock_provider.chat.return_value = LLMResponse(
            text="ok",
            tool_calls=[],
            stop_reason="end_turn",
            usage={"input_tokens": 5, "output_tokens": 5},
        )
        agent.chat("latency test", user_id="lat_test")
        llm_all = agent.metrics.get_all_llm_metrics()
        for key, metrics in llm_all.items():
            assert metrics.avg_duration_ms >= 0

    # ── Tool call recording ───────────────────────────────────────────────────

    def test_tool_call_recorded(self, agent, mock_provider):
        from familiar.core.providers import LLMResponse, ToolCall

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        agent.chat("what time?", user_id="tool_test")
        summary = agent.get_metrics_summary()
        assert summary["tools"]["total_calls"] >= 1

    def test_tool_name_tracked(self, agent, mock_provider):
        from familiar.core.providers import LLMResponse, ToolCall

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        agent.chat("time please", user_id="tool_name_test")
        tool_metrics = agent.metrics.get_all_tool_metrics()
        assert "get_current_time" in tool_metrics

    def test_tool_success_recorded(self, agent, mock_provider):
        from familiar.core.providers import LLMResponse, ToolCall

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        agent.chat("what time?", user_id="success_test")
        tm = agent.metrics.get_tool_metrics("get_current_time")
        assert tm is not None
        assert tm.successful_calls >= 1
        assert tm.success_rate > 0

    def test_tool_latency_positive(self, agent, mock_provider):
        from familiar.core.providers import LLMResponse, ToolCall

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        agent.chat("time?", user_id="lat_test")
        tm = agent.metrics.get_tool_metrics("get_current_time")
        assert tm is not None
        assert tm.avg_duration_ms >= 0
        assert tm.max_duration_ms >= 0

    def test_multiple_tool_calls_accumulate(self, agent, mock_provider):
        from familiar.core.providers import LLMResponse, ToolCall

        mock_provider.supports_tools = True
        for _ in range(3):
            mock_provider.chat.side_effect = [
                LLMResponse(
                    text=None,
                    tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                    stop_reason="tool_use",
                    usage={"input_tokens": 5, "output_tokens": 5},
                ),
                LLMResponse(
                    text="Done.",
                    tool_calls=[],
                    stop_reason="end_turn",
                    usage={"input_tokens": 5, "output_tokens": 5},
                ),
            ]
            agent.chat("what time?", user_id="multi_tool_test")
        tm = agent.metrics.get_tool_metrics("get_current_time")
        assert tm.total_calls >= 3

    # ── get_metrics_summary ───────────────────────────────────────────────────

    def test_get_metrics_summary_keys(self, agent):
        summary = agent.get_metrics_summary()
        assert "tools" in summary
        assert "llm" in summary
        assert "total_cost_usd" in summary
        assert "total_tokens" in summary
        assert "alerts" in summary
        assert "timestamp" in summary

    def test_get_metrics_summary_tools_shape(self, agent):
        summary = agent.get_metrics_summary()
        t = summary["tools"]
        assert "total_calls" in t
        assert "total_failures" in t
        assert "overall_success_rate" in t
        assert "tool_count" in t

    def test_get_metrics_summary_llm_shape(self, agent):
        summary = agent.get_metrics_summary()
        llm = summary["llm"]
        assert "total_calls" in llm
        assert "total_tokens" in llm
        assert "total_cost_usd" in llm
        assert "provider_count" in llm

    def test_get_metrics_summary_per_tool(self, agent, mock_provider):
        from familiar.core.providers import LLMResponse, ToolCall

        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        agent.chat("time?", user_id="per_tool_test")
        detail = agent.get_metrics_summary(tool_name="get_current_time")
        assert detail["tool_name"] == "get_current_time"
        assert "total_calls" in detail
        assert "success_rate" in detail
        assert "avg_duration_ms" in detail

    def test_get_metrics_summary_unknown_tool(self, agent):
        detail = agent.get_metrics_summary(tool_name="nonexistent_tool")
        assert detail["total_calls"] == 0

    def test_get_metrics_summary_selective(self, agent):
        no_llm = agent.get_metrics_summary(include_llm=False)
        assert "llm" not in no_llm
        assert "tools" in no_llm

        no_tools = agent.get_metrics_summary(include_tools=False)
        assert "tools" not in no_tools
        assert "llm" in no_tools

    # ── MetricsCollector standalone ───────────────────────────────────────────

    def test_record_tool_execution_success(self):
        from familiar.core.metrics import MetricsCollector

        mc = MetricsCollector()
        mc.record_tool_execution("my_tool", duration_ms=42.0, success=True)
        tm = mc.get_tool_metrics("my_tool")
        assert tm.total_calls == 1
        assert tm.successful_calls == 1
        assert tm.failed_calls == 0
        assert tm.avg_duration_ms == 42.0

    def test_record_tool_execution_failure(self):
        from familiar.core.metrics import MetricsCollector

        mc = MetricsCollector()
        mc.record_tool_execution(
            "my_tool", duration_ms=10.0, success=False, error_message="connection refused"
        )
        tm = mc.get_tool_metrics("my_tool")
        assert tm.failed_calls == 1
        assert tm.last_error == "connection refused"

    def test_tool_percentiles_correct(self):
        from familiar.core.metrics import MetricsCollector

        mc = MetricsCollector()
        for ms in [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]:
            mc.record_tool_execution("perc_tool", duration_ms=float(ms), success=True)
        tm = mc.get_tool_metrics("perc_tool")
        assert tm.p50_duration_ms > 0
        assert tm.p95_duration_ms >= tm.p50_duration_ms
        assert tm.p99_duration_ms >= tm.p95_duration_ms

    def test_tool_success_rate_calculation(self):
        from familiar.core.metrics import MetricsCollector

        mc = MetricsCollector()
        for _ in range(8):
            mc.record_tool_execution("rate_tool", duration_ms=10.0, success=True)
        for _ in range(2):
            mc.record_tool_execution("rate_tool", duration_ms=10.0, success=False)
        tm = mc.get_tool_metrics("rate_tool")
        assert tm.success_rate == pytest.approx(0.8, abs=0.001)
        assert tm.failure_rate == pytest.approx(0.2, abs=0.001)

    def test_track_tool_execution_context_manager(self):
        from familiar.core.metrics import MetricsCollector

        mc = MetricsCollector()
        with mc.track_tool_execution("ctx_tool") as ctx:
            ctx.set_success(True)
        tm = mc.get_tool_metrics("ctx_tool")
        assert tm.total_calls == 1
        assert tm.successful_calls == 1

    def test_track_tool_execution_captures_exception(self):
        from familiar.core.metrics import MetricsCollector

        mc = MetricsCollector()
        try:
            with mc.track_tool_execution("fail_tool") as _:
                raise ValueError("test error")
        except ValueError:
            pass
        tm = mc.get_tool_metrics("fail_tool")
        assert tm.total_calls == 1
        assert tm.failed_calls == 1
        assert "test error" in (tm.last_error or "")

    def test_record_llm_call(self):
        from familiar.core.metrics import MetricsCollector

        mc = MetricsCollector()
        mc.record_llm_call(
            provider="anthropic",
            model="claude-sonnet-4-6",
            duration_ms=1200.0,
            success=True,
            prompt_tokens=100,
            completion_tokens=50,
            cost_usd=0.0015,
        )
        lm = mc.get_llm_metrics("anthropic", "claude-sonnet-4-6")
        assert lm.total_calls == 1
        assert lm.successful_calls == 1
        assert lm.total_prompt_tokens == 100
        assert lm.total_completion_tokens == 50
        assert lm.total_cost_usd == pytest.approx(0.0015, abs=1e-6)

    def test_llm_rate_limit_tracked(self):
        from familiar.core.metrics import MetricsCollector

        mc = MetricsCollector()
        mc.record_llm_call(
            provider="openai",
            model="gpt-4o",
            duration_ms=50.0,
            success=False,
            error_message="rate limit exceeded",
        )
        lm = mc.get_llm_metrics("openai", "gpt-4o")
        assert lm.rate_limit_errors == 1

    def test_track_llm_call_context_manager(self):
        from familiar.core.metrics import MetricsCollector

        mc = MetricsCollector()
        with mc.track_llm_call("anthropic", "claude-haiku-4-5") as ctx:
            ctx.set_tokens(80, 40)
            ctx.set_cost(0.0005)
        lm = mc.get_llm_metrics("anthropic", "claude-haiku-4-5")
        assert lm.total_calls == 1
        assert lm.total_prompt_tokens == 80
        assert lm.total_completion_tokens == 40

    # ── Custom metrics ────────────────────────────────────────────────────────

    def test_counter_increment(self, agent):
        agent.metrics.increment_counter("donor_created")
        agent.metrics.increment_counter("donor_created")
        agent.metrics.increment_counter("donor_created")
        assert agent.metrics.get_counter("donor_created") == 3

    def test_counter_increment_by_value(self, agent):
        agent.metrics.increment_counter("emails_sent", 10)
        assert agent.metrics.get_counter("emails_sent") == 10

    def test_counter_missing_returns_zero(self, agent):
        assert agent.metrics.get_counter("nonexistent_counter") == 0

    def test_gauge_set_and_get(self, agent):
        agent.metrics.set_gauge("queue_depth", 42.5)
        assert agent.metrics.get_gauge("queue_depth") == pytest.approx(42.5)

    def test_gauge_overwrite(self, agent):
        agent.metrics.set_gauge("cpu_pct", 30.0)
        agent.metrics.set_gauge("cpu_pct", 75.0)
        assert agent.metrics.get_gauge("cpu_pct") == pytest.approx(75.0)

    def test_gauge_missing_returns_none(self, agent):
        assert agent.metrics.get_gauge("no_such_gauge") is None

    def test_histogram_stats(self, agent):
        for v in [10.0, 20.0, 30.0, 40.0, 50.0]:
            agent.metrics.record_histogram("email_size", v)
        stats = agent.metrics.get_histogram_stats("email_size")
        assert stats["count"] == 5
        assert stats["min"] == 10.0
        assert stats["max"] == 50.0
        assert stats["avg"] == pytest.approx(30.0, abs=0.01)

    def test_histogram_empty_returns_zero_count(self, agent):
        stats = agent.metrics.get_histogram_stats("empty_hist")
        assert stats["count"] == 0

    # ── Alerts ────────────────────────────────────────────────────────────────

    def test_alert_fires_on_high_failure_rate(self):
        from familiar.core.metrics import AlertSeverity, MetricsCollector

        mc = MetricsCollector()
        # Set threshold low so we can trigger easily
        mc.set_alert_threshold("tool_failure_rate", 0.1, AlertSeverity.WARNING)
        # 5 failures out of 10 = 50% > 10%
        for _ in range(5):
            mc.record_tool_execution("flaky_tool", duration_ms=10.0, success=True)
        for _ in range(5):
            mc.record_tool_execution(
                "flaky_tool", duration_ms=10.0, success=False, error_message="timeout"
            )
        alerts = mc.get_alerts()
        assert len(alerts) >= 1
        names = [a.name for a in alerts]
        assert any("flaky_tool" in n for n in names)

    def test_alert_callback_fires(self):
        from familiar.core.metrics import AlertSeverity, MetricsCollector

        fired = []
        mc = MetricsCollector()
        mc.set_alert_threshold("tool_failure_rate", 0.05, AlertSeverity.WARNING)
        mc.add_alert_callback(lambda alert: fired.append(alert))
        for _ in range(5):
            mc.record_tool_execution("cb_tool", duration_ms=10.0, success=True)
        for _ in range(6):
            mc.record_tool_execution(
                "cb_tool", duration_ms=10.0, success=False, error_message="error"
            )
        assert len(fired) >= 1

    def test_alert_deduplication(self):
        """Same alert shouldn't fire twice within 5 minutes."""
        from familiar.core.metrics import AlertSeverity, MetricsCollector

        mc = MetricsCollector()
        mc.set_alert_threshold("tool_failure_rate", 0.05, AlertSeverity.WARNING)
        for _ in range(20):
            mc.record_tool_execution(
                "dup_tool", duration_ms=10.0, success=False, error_message="err"
            )
        alerts = mc.get_alerts()
        dupe_alerts = [a for a in alerts if "dup_tool" in a.name]
        assert len(dupe_alerts) == 1  # deduplicated

    def test_alert_to_dict_shape(self):
        from familiar.core.metrics import AlertSeverity, MetricAlert

        alert = MetricAlert(
            name="high_failure",
            severity=AlertSeverity.WARNING,
            message="Tool failing",
            metric_name="tool_failure_rate",
            threshold=0.1,
            current_value=0.4,
        )
        d = alert.to_dict()
        for k in (
            "name",
            "severity",
            "message",
            "metric_name",
            "threshold",
            "current_value",
            "timestamp",
        ):
            assert k in d

    def test_clear_alerts(self):
        from familiar.core.metrics import AlertSeverity, MetricsCollector

        mc = MetricsCollector()
        mc.set_alert_threshold("tool_failure_rate", 0.05, AlertSeverity.WARNING)
        for _ in range(15):
            mc.record_tool_execution("alert_tool", 10.0, False, "err")
        assert len(mc.get_alerts()) >= 1
        mc.clear_alerts()
        assert mc.get_alerts() == []

    # ── Full summary shape ────────────────────────────────────────────────────

    def test_get_full_summary(self):
        from familiar.core.metrics import MetricsCollector

        mc = MetricsCollector()
        mc.record_tool_execution("tool_a", 50.0, True)
        mc.record_llm_call(
            "anthropic", "claude-sonnet-4-6", 1000.0, True, prompt_tokens=100, completion_tokens=50
        )
        mc.increment_counter("events", 3)
        mc.set_gauge("queue", 7.0)

        summary = mc.get_full_summary()
        assert "tools" in summary
        assert "llm" in summary
        assert "counters" in summary
        assert "gauges" in summary
        assert "alerts" in summary
        assert "timestamp" in summary
        assert summary["counters"]["events"] == 3
        assert summary["gauges"]["queue"] == 7.0

    def test_reset_clears_everything(self):
        from familiar.core.metrics import MetricsCollector

        mc = MetricsCollector()
        mc.record_tool_execution("t", 10.0, True)
        mc.record_llm_call("p", "m", 100.0, True)
        mc.increment_counter("c")
        mc.reset()
        assert mc.get_tool_summary()["total_calls"] == 0
        assert mc.get_llm_summary()["total_calls"] == 0
        assert mc.get_counter("c") == 0


# ---------------------------------------------------------------------------
# v1.1.26 — Backup wired into agent
# ---------------------------------------------------------------------------


class TestBackup:
    """
    backup.py (751 lines) wired as:

    - agent.backup              — BackupManager, always present
    - agent.create_backup()     — full/data/config backup, returns manifest
    - agent.restore_backup()    — restore with dry-run support
    - agent.list_backups()      — manifest list, newest first
    - agent._init_backup()      — reads config.backup, threads episodic_dir
    - tool_context["backup"]    — injected into every tool handler
    - health "backup_freshness" — reports age of most recent backup

    BackupManager covers:
      FULL     — config, users.db, history.json, analytics.db, audit.db,
                 skills/, episodic/*.json(.enc)
      DATA_ONLY — users.db, history.json, analytics.db, episodic/
      CONFIG_ONLY — config.yaml only

    Optional encryption via cryptography.Fernet (HAS_ENCRYPTION flag).
    SHA-256 checksums per file stored in manifest.file_checksums.
    Retention cleanup via cleanup_old_backups() (retention_days config).
    """

    @pytest.fixture
    def backup_dir(self, tmp_path):
        """Temp dir for backup archives."""
        d = tmp_path / "backups"
        d.mkdir()
        return d

    @pytest.fixture
    def data_dir(self, tmp_path):
        """Temp dir with fake agent data files."""
        d = tmp_path / "data"
        d.mkdir()
        (d / "memory.json").write_text('{"user1": {"name": "Alice"}}')
        (d / "history.json").write_text('[{"role": "user", "content": "Hello"}]')
        ep = d / "episodic"
        ep.mkdir()
        (ep / "user1.json").write_text('{"episodes": [{"summary": "Met Alice"}]}')
        (ep / "user2.json.enc").write_bytes(b"encrypted-data-placeholder")
        return d

    @pytest.fixture
    def manager(self, backup_dir, data_dir):
        """BackupManager pointed at temp dirs."""

        from familiar.core.backup import BackupConfig, BackupManager

        cfg = BackupConfig(
            enabled=True,
            path=backup_dir,
            encrypt=False,
            compress=True,
            include_history=True,
            include_audit=True,
        )
        m = BackupManager(config=cfg)
        m._episodic_dir = data_dir / "episodic"

        # Monkey-patch _backup_history to use our temp data dir
        def _patched_history(dest, manifest):
            import shutil

            history = data_dir / "history.json"
            if history.exists():
                dd = dest / "data"
                dd.mkdir(exist_ok=True)
                shutil.copy2(history, dd / "history.json")
                rel = "data/history.json"
                manifest.files.append(rel)
                manifest.file_checksums[rel] = m._file_checksum(history)
                manifest.file_count += 1

        m._backup_history = _patched_history
        return m

    # ── Core wiring ───────────────────────────────────────────────────────────

    def test_agent_has_backup(self, agent):
        from familiar.core.backup import BackupManager

        assert hasattr(agent, "backup")
        assert isinstance(agent.backup, BackupManager)

    def test_backup_in_tool_context(self, agent, mock_provider):
        from familiar.core.backup import BackupManager
        from familiar.core.providers import LLMResponse, ToolCall

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        orig = agent._execute_tool_secure

        def cap(n, i, s, tc, t):
            captured.update(tc)
            return orig(n, i, s, tc, t)

        agent._execute_tool_secure = cap
        agent.chat("time?", user_id="backup_ctx_test")

        assert "backup" in captured
        assert isinstance(captured["backup"], BackupManager)
        assert captured["backup"] is agent.backup

    def test_backup_episodic_dir_threaded(self, agent):
        """agent._episodic_dir is forwarded to the BackupManager."""
        assert agent.backup._episodic_dir is agent._episodic_dir

    # ── create_backup ─────────────────────────────────────────────────────────

    def test_create_backup_returns_manifest(self, manager):
        from familiar.core.backup import BackupManifest

        manifest = manager.create_backup()
        assert isinstance(manifest, BackupManifest)

    def test_create_backup_status_completed(self, manager):
        from familiar.core.backup import BackupStatus

        manifest = manager.create_backup()
        assert manifest.status == BackupStatus.COMPLETED

    def test_create_backup_has_id(self, manager):
        manifest = manager.create_backup()
        assert manifest.id
        assert len(manifest.id) > 0

    def test_create_backup_file_count(self, manager):
        manifest = manager.create_backup()
        # Episodic dir has 2 files + history.json = at least 3
        assert manifest.file_count >= 2

    def test_create_backup_total_size_positive(self, manager):
        manifest = manager.create_backup()
        assert manifest.total_size > 0

    def test_create_backup_checksum_set(self, manager):
        manifest = manager.create_backup()
        assert manifest.checksum
        assert len(manifest.checksum) == 64  # SHA-256 hex

    def test_create_backup_file_checksums(self, manager):
        manifest = manager.create_backup()
        assert len(manifest.file_checksums) >= 1
        for path, checksum in manifest.file_checksums.items():
            assert len(checksum) == 64

    def test_create_backup_archive_exists(self, manager):
        manifest = manager.create_backup()
        archive = manager.config.path / f"familiar_backup_{manifest.id}.tar.gz"
        assert archive.exists()

    def test_create_backup_manifest_file_exists(self, manager):
        manifest = manager.create_backup()
        mf = manager.config.path / f"manifest_{manifest.id}.json"
        assert mf.exists()

    def test_create_backup_data_only(self, manager):
        from familiar.core.backup import BackupStatus, BackupType

        manifest = manager.create_backup(backup_type=BackupType.DATA_ONLY)
        assert manifest.status == BackupStatus.COMPLETED

    def test_create_backup_duration_recorded(self, manager):
        manifest = manager.create_backup()
        assert manifest.duration_seconds >= 0

    def test_create_backup_episodic_files_included(self, manager):
        manifest = manager.create_backup()
        episodic_files = [f for f in manifest.files if f.startswith("episodic/")]
        assert len(episodic_files) >= 2  # user1.json + user2.json.enc

    def test_create_backup_history_included(self, manager):
        manifest = manager.create_backup()
        assert any("history.json" in f for f in manifest.files)

    # ── list_backups ─────────────────────────────────────────────────────────

    def test_list_backups_empty_initially(self, manager):
        assert manager.list_backups() == []

    def test_list_backups_after_create(self, manager):
        manager.create_backup()
        backups = manager.list_backups()
        assert len(backups) == 1

    def test_list_backups_sorted_newest_first(self, manager):
        import time

        m1 = manager.create_backup()
        time.sleep(1.1)  # ensure different timestamp
        m2 = manager.create_backup()
        backups = manager.list_backups()
        assert backups[0].id == m2.id
        assert backups[1].id == m1.id

    def test_list_backups_multiple(self, manager):
        import time

        for _ in range(3):
            manager.create_backup()
            time.sleep(1.1)
        assert len(manager.list_backups()) == 3

    # ── get_backup / verify ───────────────────────────────────────────────────

    def test_get_backup_returns_manifest(self, manager):
        m = manager.create_backup()
        retrieved = manager.get_backup(m.id)
        assert retrieved is not None
        assert retrieved.id == m.id

    def test_get_backup_missing_returns_none(self, manager):
        assert manager.get_backup("nonexistent_20990101_000000") is None

    def test_verify_backup_valid(self, manager):
        m = manager.create_backup()
        result = manager.verify_backup(m.id)
        assert result["valid"] is True
        assert result["backup_id"] == m.id

    def test_verify_backup_missing_returns_invalid(self, manager):
        result = manager.verify_backup("nonexistent_20990101_000000")
        assert result["valid"] is False

    # ── delete / cleanup ──────────────────────────────────────────────────────

    def test_delete_backup(self, manager):
        m = manager.create_backup()
        assert manager.delete_backup(m.id) is True
        assert manager.get_backup(m.id) is None
        archive = manager.config.path / f"familiar_backup_{m.id}.tar.gz"
        assert not archive.exists()

    def test_delete_nonexistent_returns_false(self, manager):
        assert manager.delete_backup("no_such_backup") is False

    def test_cleanup_old_backups(self, manager):
        import time

        m = manager.create_backup()
        time.sleep(0.1)
        # Set retention to 0 days so the backup is immediately "old"
        manager.config.retention_days = 0
        deleted = manager.cleanup_old_backups()
        assert deleted >= 1
        assert manager.get_backup(m.id) is None

    def test_cleanup_keeps_recent_backups(self, manager):
        manager.create_backup()
        manager.config.retention_days = 30  # recent backups survive
        deleted = manager.cleanup_old_backups()
        assert deleted == 0
        assert len(manager.list_backups()) == 1

    # ── restore ───────────────────────────────────────────────────────────────

    def test_restore_dry_run(self, manager, tmp_path):
        m = manager.create_backup()
        result = manager.restore(m.id, target_dir=tmp_path / "restore", dry_run=True)
        assert result["dry_run"] is True
        assert result["files_restored"] >= 1
        assert result["errors"] == []

    def test_restore_actual(self, manager, tmp_path):
        m = manager.create_backup()
        restore_dir = tmp_path / "restore"
        result = manager.restore(m.id, target_dir=restore_dir, dry_run=False)
        assert result["files_restored"] >= 1

    def test_restore_missing_raises(self, manager, tmp_path):
        with pytest.raises(ValueError, match="Backup not found"):
            manager.restore("no_such_backup_20990101", target_dir=tmp_path)

    # ── encryption ────────────────────────────────────────────────────────────

    def test_backup_encrypted_when_configured(self, backup_dir, data_dir):
        """Backup archive is encrypted when Fernet key is provided."""
        try:
            from cryptography.fernet import Fernet
        except ImportError:
            import pytest

            pytest.skip("cryptography not installed")

        from familiar.core.backup import BackupConfig, BackupManager

        key = Fernet.generate_key().decode()
        cfg = BackupConfig(
            enabled=True,
            path=backup_dir,
            encrypt=True,
            encryption_key=key,
            compress=True,
        )
        m = BackupManager(config=cfg)
        m._episodic_dir = data_dir / "episodic"
        manifest = m.create_backup()
        assert manifest.encrypted is True
        assert manifest.status.value == "completed"

    def test_backup_roundtrip_encrypted(self, backup_dir, data_dir, tmp_path):
        """Encrypt then decrypt backup and verify files come back."""
        try:
            from cryptography.fernet import Fernet
        except ImportError:
            import pytest

            pytest.skip("cryptography not installed")

        from familiar.core.backup import BackupConfig, BackupManager

        key = Fernet.generate_key().decode()
        cfg = BackupConfig(
            enabled=True,
            path=backup_dir,
            encrypt=True,
            encryption_key=key,
            compress=True,
        )
        m = BackupManager(config=cfg)
        m._episodic_dir = data_dir / "episodic"
        manifest = m.create_backup()
        result = m.restore(manifest.id, target_dir=tmp_path / "out", dry_run=False)
        assert result["files_restored"] >= 1

    # ── BackupManifest ────────────────────────────────────────────────────────

    def test_manifest_to_dict(self):
        from datetime import datetime

        from familiar.core.backup import BackupManifest, BackupStatus, BackupType

        m = BackupManifest(
            id="20260220_120000",
            created_at=datetime(2026, 2, 20, 12, 0, 0),
            backup_type=BackupType.FULL,
            status=BackupStatus.COMPLETED,
            files=["data/memory.json"],
            total_size=1024,
            file_count=1,
            checksum="abc123",
            file_checksums={"data/memory.json": "abc123"},
            version="1.1.26",
            errors=[],
        )
        d = m.to_dict()
        assert d["id"] == "20260220_120000"
        assert d["backup_type"] == "full"
        assert d["status"] == "completed"
        assert "created_at" in d

    def test_manifest_roundtrip(self):
        from datetime import datetime

        from familiar.core.backup import BackupManifest, BackupStatus, BackupType

        m = BackupManifest(
            id="20260220_120001",
            created_at=datetime(2026, 2, 20, 12, 0, 1),
            backup_type=BackupType.DATA_ONLY,
            status=BackupStatus.VERIFIED,
            files=["episodic/user1.json"],
            total_size=512,
            file_count=1,
            checksum="def456",
            file_checksums={},
            version="1.1.26",
        )
        d = m.to_dict()
        m2 = BackupManifest.from_dict(d)
        assert m2.id == m.id
        assert m2.backup_type == BackupType.DATA_ONLY
        assert m2.status == BackupStatus.VERIFIED

    # ── Health integration ────────────────────────────────────────────────────

    def test_backup_freshness_in_health(self, agent):
        hs = agent.get_health_status(include_resources=False)
        dep_names = {d["name"] for d in hs["dependencies"]}
        assert "backup_freshness" in dep_names

    def test_backup_freshness_healthy_no_backups(self, agent):
        """Fresh install with no backups should be healthy=True (informational)."""
        hs = agent.get_health_status(include_resources=False)
        bf = next(d for d in hs["dependencies"] if d["name"] == "backup_freshness")
        assert bf["healthy"] is True

    def test_backup_freshness_healthy_after_backup(self, agent, backup_dir):
        """After a successful backup, health check is healthy and reports the ID."""
        # Point both the manager AND the health-check closure at the same temp path
        agent.backup.config.path = backup_dir
        agent.health._cached_result = None
        m = agent.create_backup()
        # Bust cache so the freshness check re-queries backup_dir (not default path)
        agent.health._cached_result = None
        hs = agent.get_health_status(include_resources=False)
        bf = next(d for d in hs["dependencies"] if d["name"] == "backup_freshness")
        # Either "no backups yet" (informational healthy) or "latest backup: <id>"
        assert bf["healthy"] is True
        # The backup we just created should appear if it's the only one
        backups = agent.backup.list_backups()
        if backups:
            assert backups[0].id == m.id

    def test_backup_freshness_stale_when_old(self, agent, backup_dir):
        """A backup older than 2×retention_days should report stale."""
        import json
        from datetime import datetime, timedelta, timezone

        from familiar.core.backup import BackupManifest, BackupStatus, BackupType

        agent.backup.config.path = backup_dir
        agent.backup.config.retention_days = 1  # 1-day retention → stale after 2 days

        # Inject an old manifest directly (skip actual file creation)
        old_date = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=5)
        old_manifest = BackupManifest(
            id="20260215_120000",
            created_at=old_date,
            backup_type=BackupType.FULL,
            status=BackupStatus.COMPLETED,
            files=[],
            total_size=100,
            file_count=1,
            checksum="abc",
            file_checksums={},
            version="1.1.26",
            errors=[],
        )
        mf = backup_dir / "manifest_20260215_120000.json"
        mf.write_text(json.dumps(old_manifest.to_dict()))

        agent.health._cached_result = None
        hs = agent.get_health_status(include_resources=False)
        bf = next(d for d in hs["dependencies"] if d["name"] == "backup_freshness")
        assert bf["healthy"] is False
        assert "days ago" in bf["message"]

    # ── agent.create_backup / restore_backup convenience wrappers ─────────────

    def test_agent_create_backup(self, agent, backup_dir):
        agent.backup.config.path = backup_dir
        from familiar.core.backup import BackupManifest

        m = agent.create_backup()
        assert isinstance(m, BackupManifest)
        assert m.status.value == "completed"

    def test_agent_list_backups(self, agent, backup_dir):
        agent.backup.config.path = backup_dir
        agent.create_backup()
        backups = agent.list_backups()
        assert len(backups) >= 1

    def test_agent_restore_backup_dry_run(self, agent, backup_dir, tmp_path):
        agent.backup.config.path = backup_dir
        m = agent.create_backup()
        result = agent.restore_backup(m.id, target_dir=tmp_path / "out", dry_run=True)
        assert result["dry_run"] is True
        assert result["files_restored"] >= 0

    def test_agent_restore_backup_missing_raises(self, agent, backup_dir, tmp_path):
        agent.backup.config.path = backup_dir
        with pytest.raises(ValueError):
            agent.restore_backup("no_such_backup", target_dir=tmp_path)

    # ── BackupConfig ──────────────────────────────────────────────────────────

    def test_backup_config_defaults(self):
        from familiar.core.backup import BackupConfig

        cfg = BackupConfig()
        assert cfg.enabled is True
        assert cfg.compress is True
        assert cfg.encrypt is False
        assert cfg.retention_days == 30
        assert cfg.storage == "local"

    def test_backup_config_from_dict(self, tmp_path):
        from familiar.core.backup import BackupConfig

        cfg = BackupConfig.from_dict(
            {
                "enabled": True,
                "path": str(tmp_path),
                "encrypt": False,
                "retention_days": 7,
            }
        )
        assert cfg.retention_days == 7
        assert cfg.path == tmp_path

    # ── _backup_episodic standalone ───────────────────────────────────────────

    def test_backup_episodic_copies_json(self, manager, data_dir):
        import pathlib
        import tempfile
        from datetime import datetime
        from datetime import timezone as _tz

        from familiar.core.backup import BackupManifest, BackupStatus, BackupType

        manifest = BackupManifest(
            id="test",
            created_at=datetime.now(_tz.utc).replace(tzinfo=None),
            backup_type=BackupType.FULL,
            status=BackupStatus.IN_PROGRESS,
            files=[],
            total_size=0,
            file_count=0,
            checksum="",
            file_checksums={},
            version="test",
            errors=[],
        )
        with tempfile.TemporaryDirectory() as tmp:
            dest = pathlib.Path(tmp)
            manager._backup_episodic(dest, manifest, episodic_dir=data_dir / "episodic")
            assert "episodic/user1.json" in manifest.files
            assert "episodic/user2.json.enc" in manifest.files
            assert (dest / "episodic" / "user1.json").exists()
            assert (dest / "episodic" / "user2.json.enc").exists()

    def test_backup_episodic_empty_dir(self, manager, tmp_path):
        import pathlib
        import tempfile
        from datetime import datetime
        from datetime import timezone as _tz

        from familiar.core.backup import BackupManifest, BackupStatus, BackupType

        empty_dir = tmp_path / "empty_episodic"
        empty_dir.mkdir()
        manifest = BackupManifest(
            id="test",
            created_at=datetime.now(_tz.utc).replace(tzinfo=None),
            backup_type=BackupType.FULL,
            status=BackupStatus.IN_PROGRESS,
            files=[],
            total_size=0,
            file_count=0,
            checksum="",
            file_checksums={},
            version="test",
            errors=[],
        )
        with tempfile.TemporaryDirectory() as t:
            import pathlib

            manager._backup_episodic(pathlib.Path(t), manifest, episodic_dir=empty_dir)
        assert len(manifest.files) == 0  # nothing to copy

    def test_backup_episodic_nonexistent_dir(self, manager, tmp_path):
        """Should silently skip if episodic dir doesn't exist."""
        from datetime import datetime
        from datetime import timezone as _tz

        from familiar.core.backup import BackupManifest, BackupStatus, BackupType

        manifest = BackupManifest(
            id="test",
            created_at=datetime.now(_tz.utc).replace(tzinfo=None),
            backup_type=BackupType.FULL,
            status=BackupStatus.IN_PROGRESS,
            files=[],
            total_size=0,
            file_count=0,
            checksum="",
            file_checksums={},
            version="test",
            errors=[],
        )
        manager._backup_episodic(tmp_path, manifest, episodic_dir=tmp_path / "does_not_exist")
        assert len(manifest.files) == 0


# ---------------------------------------------------------------------------
# v1.1.27 — backup.py wired into agent
# ---------------------------------------------------------------------------


class TestBackupExtended:
    """
    backup.py (797 lines) wired as:

    - agent.backup                  — BackupManager instance (always present)
    - agent.create_backup()         — full/incremental/config/data backup
    - agent.restore_backup(id)      — restore from archive; dry_run supported
    - agent.list_backups()          — all manifests, newest first
    - agent.verify_backup(id)       — SHA-256 integrity check
    - agent.cleanup_old_backups()   — prune beyond retention_days
    - agent._schedule_backup()      — registers daily scheduler task
    - tool_context["backup"]        — injected into every tool handler
    - health "backup_freshness"     — dependency check in readiness probe

    BackupManager handles:
      BackupType.FULL        — config + users + history + analytics + audit + skills + episodic
      BackupType.DATA_ONLY   — users + history + analytics + episodic
      BackupType.CONFIG_ONLY — config only
      Encryption             — Fernet AES-128-CBC (optional, cryptography pkg)
      Compression            — gzip (always on by default)
      Manifests              — JSON sidecar per backup (id, checksums, status, timing)
      Retention              — cleanup_old_backups() prunes past retention_days
    """

    @pytest.fixture()
    def backup_dir(self, tmp_path):
        """Temp directory that the BackupManager writes archives into."""
        d = tmp_path / "backups"
        d.mkdir()
        return d

    @pytest.fixture()
    def manager(self, backup_dir):
        """BackupManager with a known temp backup path."""

        from familiar.core.backup import BackupConfig, BackupManager

        cfg = BackupConfig(
            path=backup_dir, enabled=True, compress=True, include_history=True, include_audit=True
        )
        return BackupManager(config=cfg)

    @pytest.fixture()
    def agent_with_backup(self, agent, backup_dir):
        """Agent whose backup.config.path is redirected to a temp dir."""
        agent.backup.config.path = backup_dir
        return agent

    # ── Core wiring ───────────────────────────────────────────────────────────

    def test_agent_has_backup(self, agent):
        from familiar.core.backup import BackupManager

        assert hasattr(agent, "backup")
        assert isinstance(agent.backup, BackupManager)

    def test_backup_in_tool_context(self, agent, mock_provider):
        from familiar.core.backup import BackupManager
        from familiar.core.providers import LLMResponse, ToolCall

        captured = {}
        mock_provider.supports_tools = True
        mock_provider.chat.side_effect = [
            LLMResponse(
                text=None,
                tool_calls=[ToolCall(id="tc1", name="get_current_time", input={})],
                stop_reason="tool_use",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
            LLMResponse(
                text="Done.",
                tool_calls=[],
                stop_reason="end_turn",
                usage={"input_tokens": 5, "output_tokens": 5},
            ),
        ]
        orig = agent._execute_tool_secure

        def cap(n, i, s, tc, t):
            captured.update(tc)
            return orig(n, i, s, tc, t)

        agent._execute_tool_secure = cap
        agent.chat("time?", user_id="backup_ctx_test")

        assert "backup" in captured
        assert isinstance(captured["backup"], BackupManager)
        assert captured["backup"] is agent.backup

    def test_backup_config_defaults(self, agent):
        """BackupManager always has a valid BackupConfig."""
        from familiar.core.backup import BackupConfig

        assert isinstance(agent.backup.config, BackupConfig)
        assert agent.backup.config.path is not None
        assert agent.backup.config.retention_days > 0

    # ── create_backup ─────────────────────────────────────────────────────────

    def test_create_backup_returns_manifest(self, agent_with_backup):
        from familiar.core.backup import BackupManifest

        manifest = agent_with_backup.create_backup()
        assert isinstance(manifest, BackupManifest)

    def test_create_backup_status_completed(self, agent_with_backup):
        from familiar.core.backup import BackupStatus

        manifest = agent_with_backup.create_backup()
        assert manifest.status == BackupStatus.COMPLETED

    def test_create_backup_has_id(self, agent_with_backup):
        manifest = agent_with_backup.create_backup()
        assert manifest.id
        assert len(manifest.id) > 0

    def test_create_backup_file_count(self, agent_with_backup):
        manifest = agent_with_backup.create_backup()
        # file_count >= 0 (0 is fine on empty filesystem)
        assert manifest.file_count >= 0

    def test_create_backup_total_size(self, agent_with_backup):
        manifest = agent_with_backup.create_backup()
        assert manifest.total_size >= 0

    def test_create_backup_has_checksum(self, agent_with_backup):
        manifest = agent_with_backup.create_backup()
        assert manifest.checksum
        assert len(manifest.checksum) == 64  # SHA-256 hex

    def test_create_backup_archive_written(self, agent_with_backup, backup_dir):
        manifest = agent_with_backup.create_backup()
        archive = backup_dir / f"familiar_backup_{manifest.id}.tar.gz"
        assert archive.exists()

    def test_create_backup_manifest_written(self, agent_with_backup, backup_dir):
        manifest = agent_with_backup.create_backup()
        mfile = backup_dir / f"manifest_{manifest.id}.json"
        assert mfile.exists()

    def test_create_backup_manifest_readable(self, agent_with_backup, backup_dir):
        import json

        manifest = agent_with_backup.create_backup()
        mfile = backup_dir / f"manifest_{manifest.id}.json"
        data = json.loads(mfile.read_text())
        assert data["id"] == manifest.id
        assert data["status"] == "completed"

    def test_create_backup_full_type(self, agent_with_backup):
        from familiar.core.backup import BackupType

        manifest = agent_with_backup.create_backup(backup_type=BackupType.FULL)
        assert manifest.backup_type == BackupType.FULL

    def test_create_backup_data_only(self, agent_with_backup):
        from familiar.core.backup import BackupStatus, BackupType

        manifest = agent_with_backup.create_backup(backup_type=BackupType.DATA_ONLY)
        assert manifest.backup_type == BackupType.DATA_ONLY
        assert manifest.status == BackupStatus.COMPLETED

    def test_create_backup_config_only(self, agent_with_backup):
        from familiar.core.backup import BackupStatus, BackupType

        manifest = agent_with_backup.create_backup(backup_type=BackupType.CONFIG_ONLY)
        assert manifest.backup_type == BackupType.CONFIG_ONLY
        assert manifest.status == BackupStatus.COMPLETED

    def test_create_backup_duration_recorded(self, agent_with_backup):
        manifest = agent_with_backup.create_backup()
        assert manifest.duration_seconds >= 0

    def test_create_backup_compressed(self, agent_with_backup):
        manifest = agent_with_backup.create_backup()
        assert manifest.compressed is True

    # ── list_backups ──────────────────────────────────────────────────────────

    def test_list_backups_empty(self, agent_with_backup):
        backups = agent_with_backup.list_backups()
        assert backups == []

    def test_list_backups_after_create(self, agent_with_backup):
        agent_with_backup.create_backup()
        backups = agent_with_backup.list_backups()
        assert len(backups) == 1

    def test_list_backups_multiple(self, agent_with_backup):
        import time

        agent_with_backup.create_backup()
        time.sleep(1.1)  # IDs are second-precision; wait for distinct timestamp
        agent_with_backup.create_backup()
        backups = agent_with_backup.list_backups()
        assert len(backups) == 2

    def test_list_backups_newest_first(self, agent_with_backup):
        import time

        agent_with_backup.create_backup()
        time.sleep(1.1)  # ensure different timestamp
        agent_with_backup.create_backup()
        backups = agent_with_backup.list_backups()
        assert backups[0].created_at >= backups[1].created_at

    def test_list_backups_returns_manifests(self, agent_with_backup):
        from familiar.core.backup import BackupManifest

        agent_with_backup.create_backup()
        backups = agent_with_backup.list_backups()
        assert isinstance(backups[0], BackupManifest)

    # ── verify_backup ─────────────────────────────────────────────────────────

    def test_verify_backup_valid(self, agent_with_backup):
        manifest = agent_with_backup.create_backup()
        result = agent_with_backup.verify_backup(manifest.id)
        assert result["valid"] is True

    def test_verify_backup_has_fields(self, agent_with_backup):
        manifest = agent_with_backup.create_backup()
        result = agent_with_backup.verify_backup(manifest.id)
        assert "backup_id" in result
        assert "created_at" in result
        assert "size" in result
        assert "files" in result

    def test_verify_backup_unknown_id(self, agent_with_backup):
        result = agent_with_backup.verify_backup("does_not_exist")
        assert result["valid"] is False
        assert "error" in result

    def test_verify_backup_updates_status(self, agent_with_backup):
        from familiar.core.backup import BackupStatus

        manifest = agent_with_backup.create_backup()
        agent_with_backup.verify_backup(manifest.id)
        updated = agent_with_backup.backup.get_backup(manifest.id)
        assert updated.status == BackupStatus.VERIFIED

    # ── cleanup_old_backups ───────────────────────────────────────────────────

    def test_cleanup_returns_int(self, agent_with_backup):
        agent_with_backup.create_backup()
        result = agent_with_backup.cleanup_old_backups()
        assert isinstance(result, int)

    def test_cleanup_fresh_backup_not_deleted(self, agent_with_backup):
        agent_with_backup.create_backup()
        deleted = agent_with_backup.cleanup_old_backups()
        assert deleted == 0
        assert len(agent_with_backup.list_backups()) == 1

    def test_cleanup_old_backup_deleted(self, agent_with_backup, backup_dir):
        """Simulate an old backup by manipulating its manifest's created_at."""
        import json
        from datetime import datetime, timedelta

        manifest = agent_with_backup.create_backup()
        # Move created_at back past retention window
        mfile = backup_dir / f"manifest_{manifest.id}.json"
        data = json.loads(mfile.read_text())
        old_date = (datetime.now() - timedelta(days=60)).isoformat()
        data["created_at"] = old_date
        mfile.write_text(json.dumps(data))

        deleted = agent_with_backup.cleanup_old_backups()
        assert deleted == 1
        assert len(agent_with_backup.list_backups()) == 0

    # ── restore_backup ────────────────────────────────────────────────────────

    def test_restore_dry_run(self, agent_with_backup, tmp_path):
        manifest = agent_with_backup.create_backup()
        result = agent_with_backup.restore_backup(
            manifest.id,
            target_dir=tmp_path / "restore_target",
            dry_run=True,
        )
        assert result["dry_run"] is True
        assert "files_restored" in result
        assert isinstance(result["files_restored"], int)

    def test_restore_unknown_id_raises(self, agent_with_backup):
        with pytest.raises(ValueError, match="Backup not found"):
            agent_with_backup.restore_backup("nonexistent_backup_id")

    def test_restore_to_target_dir(self, agent_with_backup, tmp_path):
        manifest = agent_with_backup.create_backup()
        target = tmp_path / "restored"
        result = agent_with_backup.restore_backup(manifest.id, target_dir=target)
        assert "files_restored" in result
        assert result["errors"] == []

    # ── BackupManager standalone ──────────────────────────────────────────────

    def test_manager_list_empty(self, manager):
        assert manager.list_backups() == []

    def test_manager_create_and_list(self, manager):
        m = manager.create_backup()
        assert m.id
        backups = manager.list_backups()
        assert len(backups) == 1
        assert backups[0].id == m.id

    def test_manager_get_backup(self, manager):
        m = manager.create_backup()
        got = manager.get_backup(m.id)
        assert got is not None
        assert got.id == m.id

    def test_manager_get_backup_not_found(self, manager):
        result = manager.get_backup("no_such_backup")
        assert result is None

    def test_manager_delete_backup(self, manager):
        m = manager.create_backup()
        assert manager.delete_backup(m.id) is True
        assert manager.list_backups() == []

    def test_manager_delete_nonexistent(self, manager):
        assert manager.delete_backup("no_such_id") is False

    def test_manager_cleanup_no_old(self, manager):
        manager.create_backup()
        deleted = manager.cleanup_old_backups()
        assert deleted == 0

    def test_manager_manifest_to_dict(self, manager):
        m = manager.create_backup()
        d = m.to_dict()
        for key in (
            "id",
            "created_at",
            "backup_type",
            "status",
            "files",
            "total_size",
            "file_count",
            "checksum",
            "file_checksums",
            "encrypted",
            "compressed",
            "duration_seconds",
        ):
            assert key in d

    def test_manager_manifest_from_dict_roundtrip(self, manager):
        from familiar.core.backup import BackupManifest

        m = manager.create_backup()
        d = m.to_dict()
        restored = BackupManifest.from_dict(d)
        assert restored.id == m.id
        assert restored.status == m.status
        assert restored.backup_type == m.backup_type

    # ── Encrypted backup ──────────────────────────────────────────────────────

    def test_encrypted_backup_marked_encrypted(self, tmp_path):
        """When cryptography is installed, encrypted backup stores encrypted=True."""
        pytest.importorskip("cryptography")
        from cryptography.fernet import Fernet

        from familiar.core.backup import BackupConfig, BackupManager

        key = Fernet.generate_key().decode()
        cfg = BackupConfig(
            path=tmp_path / "enc_backups",
            enabled=True,
            encrypt=True,
            encryption_key=key,
        )
        cfg.path.mkdir(parents=True, exist_ok=True)
        mgr = BackupManager(config=cfg)
        manifest = mgr.create_backup()
        assert manifest.encrypted is True

    def test_encrypted_backup_verify(self, tmp_path):
        """Encrypted backup verify returns valid=True."""
        pytest.importorskip("cryptography")
        from cryptography.fernet import Fernet

        from familiar.core.backup import BackupConfig, BackupManager

        key = Fernet.generate_key().decode()
        cfg = BackupConfig(
            path=tmp_path / "enc_backups2",
            enabled=True,
            encrypt=True,
            encryption_key=key,
        )
        cfg.path.mkdir(parents=True, exist_ok=True)
        mgr = BackupManager(config=cfg)
        manifest = mgr.create_backup()
        result = mgr.verify_backup(manifest.id)
        assert result["valid"] is True

    def test_encrypted_backup_restore(self, tmp_path):
        """Encrypted backup can be restored with correct key."""
        pytest.importorskip("cryptography")
        from cryptography.fernet import Fernet

        from familiar.core.backup import BackupConfig, BackupManager

        key = Fernet.generate_key().decode()
        cfg = BackupConfig(
            path=tmp_path / "enc_backups3",
            enabled=True,
            encrypt=True,
            encryption_key=key,
        )
        cfg.path.mkdir(parents=True, exist_ok=True)
        mgr = BackupManager(config=cfg)
        manifest = mgr.create_backup()

        result = mgr.restore(manifest.id, target_dir=tmp_path / "enc_restore", dry_run=True)
        assert result["dry_run"] is True

    # ── Health check — backup_freshness ───────────────────────────────────────

    def test_health_backup_freshness_dep_exists(self, agent):
        """backup_freshness dependency is registered in HealthChecker."""
        hc = agent.health
        dep_names = list(hc._dependency_checks.keys())
        assert "backup_freshness" in dep_names

    def test_health_backup_freshness_no_backups(self, agent):
        """Fresh install with no backups → healthy=True (informational)."""
        # Make sure there are no backups in the temp path
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as td:
            agent.backup.config.path = Path(td) / "backups"
            agent.backup.config.path.mkdir()
            agent.health._cached_result = None
            result = agent.health.check_health()
            backup_dep = next(
                (d for d in result.to_dict()["dependencies"] if d["name"] == "backup_freshness"),
                None,
            )
            assert backup_dep is not None
            assert backup_dep["healthy"] is True  # informational, not failing

    def test_health_backup_freshness_after_backup(self, agent_with_backup):
        """After a successful backup, freshness dep is healthy."""
        agent_with_backup.create_backup()
        agent_with_backup.health._cached_result = None
        result = agent_with_backup.health.check_health()
        backup_dep = next(
            (d for d in result.to_dict()["dependencies"] if d["name"] == "backup_freshness"), None
        )
        assert backup_dep is not None
        assert backup_dep["healthy"] is True

    # ── Episodic directory pass-through ───────────────────────────────────────

    def test_episodic_dir_threaded_through(self, agent):
        """BackupManager._episodic_dir matches agent._episodic_dir."""
        assert agent.backup._episodic_dir == agent._episodic_dir

    def test_episodic_backup_included(self, agent_with_backup, tmp_path):
        """If episodic dir has files, they appear in the backup."""
        import json

        # Create a fake episodic file
        ep_dir = tmp_path / "episodic"
        ep_dir.mkdir()
        (ep_dir / "user_abc.json").write_text(json.dumps({"user": "abc", "events": []}))
        agent_with_backup.backup._episodic_dir = ep_dir

        manifest = agent_with_backup.create_backup()
        episodic_files = [f for f in manifest.files if f.startswith("episodic/")]
        assert len(episodic_files) >= 1

    # ── Scheduler wiring ──────────────────────────────────────────────────────

    def test_schedule_backup_registers_task(self, agent_with_backup):
        """_schedule_backup registers a task on the scheduler if available."""
        if agent_with_backup.scheduler is None:
            pytest.skip("Scheduler not enabled in agent fixture")
        import unittest.mock as mock

        agent_with_backup.scheduler.add_task = mock.MagicMock(return_value="task_id")
        agent_with_backup._schedule_backup()
        agent_with_backup.scheduler.add_task.assert_called_once()
        call_kwargs = agent_with_backup.scheduler.add_task.call_args
        assert "familiar_auto_backup" in str(call_kwargs)

    def test_schedule_backup_noop_without_scheduler(self, agent_with_backup):
        """_schedule_backup is a no-op when scheduler=None."""
        agent_with_backup.scheduler = None
        # Should not raise
        agent_with_backup._schedule_backup()

    # ── BackupConfig from agent config ───────────────────────────────────────

    def test_backup_config_from_agent_config(self, monkeypatch):
        """BackupSettings in Config maps correctly to BackupConfig."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        from unittest.mock import MagicMock, patch

        from familiar.core.config import load_config
        from familiar.core.metrics import reset_metrics_collector
        from familiar.core.providers import LLMProvider, LLMResponse

        reset_metrics_collector()

        cfg = load_config()
        cfg.llm.default_provider = "ollama"
        cfg.agent.memory_enabled = False
        cfg.agent.scheduler_enabled = False
        cfg.backup.enabled = True
        cfg.backup.retention_days = 14
        cfg.backup.include_history = False

        mock_provider = MagicMock(spec=LLMProvider)
        mock_provider.name = "MockProvider"
        mock_provider.model_name = "mock"
        mock_provider.supports_tools = False
        mock_provider.supports_streaming = False
        mock_provider.chat.return_value = LLMResponse(
            text="hi", tool_calls=[], stop_reason="end_turn", usage={}
        )

        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            from familiar.core.agent import Agent

            a = Agent(config=cfg)

        assert a.backup.config.retention_days == 14
        assert a.backup.config.include_history is False


# ============================================================
# CHANNEL PARITY TESTS (v1.1.29)
# ============================================================


class TestChannelParity:
    """Verify command parity and delivery callback across all channels."""

    @pytest.fixture
    def agent(self, tmp_path, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        from unittest.mock import MagicMock, patch

        from familiar.core.config import load_config
        from familiar.core.metrics import reset_metrics_collector
        from familiar.core.providers import LLMProvider, LLMResponse
        from familiar.core.scheduler import reset_scheduler

        reset_metrics_collector()
        reset_scheduler()
        cfg = load_config()
        cfg.llm.default_provider = "ollama"
        cfg.agent.memory_enabled = False
        cfg.agent.scheduler_enabled = True
        mock_provider = MagicMock(spec=LLMProvider)
        mock_provider.name = "MockProvider"
        mock_provider.model_name = "mock"
        mock_provider.supports_tools = False
        mock_provider.supports_streaming = False
        mock_provider.chat.return_value = LLMResponse(
            text="hello", tool_calls=[], stop_reason="end_turn", usage={}
        )
        with patch("familiar.core.agent.get_provider", return_value=mock_provider):
            from familiar.core.agent import Agent

            a = Agent(config=cfg)
        yield a
        if a.scheduler:
            a.scheduler.stop()

    # ── CLI ──────────────────────────────────────────────────────────────────

    def test_cli_has_trust_command(self, agent):
        from familiar.channels.cli import CLIChannel

        ch = CLIChannel(agent)
        # trust handler should return True (handled) not raise
        from unittest.mock import patch

        with patch("builtins.print"):
            result = ch.handle_command("/trust")
        assert result is True

    def test_cli_has_budget_command(self, agent):
        from familiar.channels.cli import CLIChannel

        ch = CLIChannel(agent)
        from unittest.mock import patch

        with patch("builtins.print"):
            result = ch.handle_command("/budget")
        assert result is True

    def test_cli_has_caps_command(self, agent):
        from familiar.channels.cli import CLIChannel

        ch = CLIChannel(agent)
        from unittest.mock import patch

        with patch("builtins.print"):
            result = ch.handle_command("/caps")
        assert result is True

    def test_cli_delivery_callback_wired(self, agent):
        """After run() starts scheduler, delivery callback is set."""
        from familiar.channels.cli import CLIChannel

        _ = CLIChannel(agent)
        # Simulate what run() does without blocking input loop
        if agent.scheduler:
            delivered = []

            def _deliver(msg, channel, chat_id):
                delivered.append(msg)

            agent.scheduler.set_delivery_callback(_deliver)
            agent.scheduler._delivery_callback("test msg", "cli", "")
            assert delivered == ["test msg"]

    # ── WhatsApp ─────────────────────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_whatsapp_command_status(self, agent):
        from familiar.channels.whatsapp import WhatsAppChannel

        ch = WhatsAppChannel(agent)
        resp = await ch._handle_command("status", "", "user1", "user1")
        assert resp is not None
        assert "Trust" in resp or "Status" in resp

    @pytest.mark.asyncio
    async def test_whatsapp_command_trust(self, agent):
        from familiar.channels.whatsapp import WhatsAppChannel

        ch = WhatsAppChannel(agent)
        resp = await ch._handle_command("trust", "", "user1", "user1")
        assert resp is not None
        assert "STRANGER" in resp or "KNOWN" in resp or "Trust" in resp

    @pytest.mark.asyncio
    async def test_whatsapp_command_budget(self, agent):
        from familiar.channels.whatsapp import WhatsAppChannel

        ch = WhatsAppChannel(agent)
        resp = await ch._handle_command("budget", "", "user1", "user1")
        assert resp is not None
        assert "$" in resp

    @pytest.mark.asyncio
    async def test_whatsapp_command_caps(self, agent):
        from familiar.channels.whatsapp import WhatsAppChannel

        ch = WhatsAppChannel(agent)
        resp = await ch._handle_command("caps", "", "user1", "user1")
        assert resp is not None
        assert "Capabilit" in resp

    @pytest.mark.asyncio
    async def test_whatsapp_command_clear(self, agent):
        from familiar.channels.whatsapp import WhatsAppChannel

        ch = WhatsAppChannel(agent)
        resp = await ch._handle_command("clear", "", "user1", "user1")
        assert resp is not None
        assert "clear" in resp.lower()

    @pytest.mark.asyncio
    async def test_whatsapp_command_model_no_args(self, agent):
        from familiar.channels.whatsapp import WhatsAppChannel

        ch = WhatsAppChannel(agent)
        resp = await ch._handle_command("model", "", "user1", "user1")
        assert resp is not None
        assert "Current" in resp

    @pytest.mark.asyncio
    async def test_whatsapp_command_help(self, agent):
        from familiar.channels.whatsapp import WhatsAppChannel

        ch = WhatsAppChannel(agent)
        resp = await ch._handle_command("help", "", "user1", "user1")
        assert resp is not None
        assert "/status" in resp

    @pytest.mark.asyncio
    async def test_whatsapp_unknown_command_returns_none(self, agent):
        from familiar.channels.whatsapp import WhatsAppChannel

        ch = WhatsAppChannel(agent)
        resp = await ch._handle_command("notacommand", "", "user1", "user1")
        assert resp is None

    @pytest.mark.asyncio
    async def test_whatsapp_remember_requires_capability(self, agent):
        from familiar.channels.whatsapp import WhatsAppChannel

        ch = WhatsAppChannel(agent)
        resp = await ch._handle_command("remember", "key val", "user1", "user1")
        # STRANGER trust → no WRITE_MEMORY capability
        assert resp is not None
        assert "permission" in resp.lower() or "capability" in resp.lower() or "Remembered" in resp

    # ── Signal ───────────────────────────────────────────────────────────────

    def test_signal_command_status(self, agent):
        from familiar.channels.signal import SignalChannel

        ch = SignalChannel(agent, phone="+10000000000")
        resp = ch._handle_command("status", "", "user1")
        assert resp is not None
        assert "Trust" in resp or "Status" in resp

    def test_signal_command_trust(self, agent):
        from familiar.channels.signal import SignalChannel

        ch = SignalChannel(agent, phone="+10000000000")
        resp = ch._handle_command("trust", "", "user1")
        assert resp is not None
        assert "STRANGER" in resp or "Trust" in resp

    def test_signal_command_budget(self, agent):
        from familiar.channels.signal import SignalChannel

        ch = SignalChannel(agent, phone="+10000000000")
        resp = ch._handle_command("budget", "", "user1")
        assert resp is not None
        assert "$" in resp

    def test_signal_command_caps(self, agent):
        from familiar.channels.signal import SignalChannel

        ch = SignalChannel(agent, phone="+10000000000")
        resp = ch._handle_command("caps", "", "user1")
        assert resp is not None
        assert "Capabilit" in resp

    def test_signal_command_model_no_args(self, agent):
        from familiar.channels.signal import SignalChannel

        ch = SignalChannel(agent, phone="+10000000000")
        resp = ch._handle_command("model", "", "user1")
        assert resp is not None
        assert "Current" in resp

    def test_signal_command_help(self, agent):
        from familiar.channels.signal import SignalChannel

        ch = SignalChannel(agent, phone="+10000000000")
        resp = ch._handle_command("help", "", "user1")
        assert resp is not None
        assert "/status" in resp

    def test_signal_command_clear(self, agent):
        from familiar.channels.signal import SignalChannel

        ch = SignalChannel(agent, phone="+10000000000")
        resp = ch._handle_command("clear", "", "user1")
        assert "clear" in resp.lower()

    def test_signal_unknown_command_returns_none(self, agent):
        from familiar.channels.signal import SignalChannel

        ch = SignalChannel(agent, phone="+10000000000")
        assert ch._handle_command("notacommand", "", "user1") is None

    # ── iMessage ─────────────────────────────────────────────────────────────

    def test_imessage_command_status(self, agent):
        from familiar.channels.imessage import iMessageChannel

        ch = iMessageChannel(agent)
        resp = ch._handle_command("status", "", "user@example.com")
        assert resp is not None
        assert "Trust" in resp or "Status" in resp

    def test_imessage_command_trust(self, agent):
        from familiar.channels.imessage import iMessageChannel

        ch = iMessageChannel(agent)
        resp = ch._handle_command("trust", "", "user@example.com")
        assert resp is not None
        assert "STRANGER" in resp or "Trust" in resp

    def test_imessage_command_budget(self, agent):
        from familiar.channels.imessage import iMessageChannel

        ch = iMessageChannel(agent)
        resp = ch._handle_command("budget", "", "user@example.com")
        assert resp is not None
        assert "$" in resp

    def test_imessage_command_caps(self, agent):
        from familiar.channels.imessage import iMessageChannel

        ch = iMessageChannel(agent)
        resp = ch._handle_command("caps", "", "user@example.com")
        assert resp is not None
        assert "Capabilit" in resp

    def test_imessage_command_model(self, agent):
        from familiar.channels.imessage import iMessageChannel

        ch = iMessageChannel(agent)
        resp = ch._handle_command("model", "", "user@example.com")
        assert resp is not None
        assert "Current" in resp

    def test_imessage_command_help(self, agent):
        from familiar.channels.imessage import iMessageChannel

        ch = iMessageChannel(agent)
        resp = ch._handle_command("help", "", "user@example.com")
        assert resp is not None
        assert "/status" in resp

    def test_imessage_command_clear(self, agent):
        from familiar.channels.imessage import iMessageChannel

        ch = iMessageChannel(agent)
        resp = ch._handle_command("clear", "", "user@example.com")
        assert "clear" in resp.lower()

    def test_imessage_unknown_command_returns_none(self, agent):
        from familiar.channels.imessage import iMessageChannel

        ch = iMessageChannel(agent)
        assert ch._handle_command("notacommand", "", "user@example.com") is None

    # ── Teams ─────────────────────────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_teams_handle_trust(self, agent):
        from unittest.mock import AsyncMock, MagicMock

        import familiar.channels.teams as _teams_mod

        mock_mf = MagicMock()
        mock_mf.text = lambda t: MagicMock(text=t)
        _orig_mf = getattr(_teams_mod, "MessageFactory", None)
        _teams_mod.MessageFactory = mock_mf
        from familiar.channels.teams import FamiliarTeamsBot, TeamsConfig

        cfg = TeamsConfig(app_id="", app_password="")
        bot = FamiliarTeamsBot(agent, cfg)
        tc = MagicMock()
        tc.send_activity = AsyncMock()
        await bot._handle_trust(tc)
        tc.send_activity.assert_called_once()
        text = tc.send_activity.call_args[0][0].text
        assert "Trust" in text

    @pytest.mark.asyncio
    async def test_teams_handle_budget(self, agent):
        from unittest.mock import AsyncMock, MagicMock

        import familiar.channels.teams as _teams_mod

        mock_mf = MagicMock()
        mock_mf.text = lambda t: MagicMock(text=t)
        _orig_mf = getattr(_teams_mod, "MessageFactory", None)
        _teams_mod.MessageFactory = mock_mf
        from familiar.channels.teams import FamiliarTeamsBot, TeamsConfig

        cfg = TeamsConfig(app_id="", app_password="")
        bot = FamiliarTeamsBot(agent, cfg)
        tc = MagicMock()
        tc.send_activity = AsyncMock()
        await bot._handle_budget(tc)
        tc.send_activity.assert_called_once()
        text = tc.send_activity.call_args[0][0].text
        assert "$" in text

    @pytest.mark.asyncio
    async def test_teams_handle_caps(self, agent):
        from unittest.mock import AsyncMock, MagicMock

        import familiar.channels.teams as _teams_mod

        mock_mf = MagicMock()
        mock_mf.text = lambda t: MagicMock(text=t)
        _orig_mf = getattr(_teams_mod, "MessageFactory", None)
        _teams_mod.MessageFactory = mock_mf
        from familiar.channels.teams import FamiliarTeamsBot, TeamsConfig

        cfg = TeamsConfig(app_id="", app_password="")
        bot = FamiliarTeamsBot(agent, cfg)
        tc = MagicMock()
        tc.send_activity = AsyncMock()
        await bot._handle_caps(tc)
        tc.send_activity.assert_called_once()
        text = tc.send_activity.call_args[0][0].text
        assert "Capabilit" in text

    @pytest.mark.asyncio
    async def test_teams_handle_status(self, agent):
        from unittest.mock import AsyncMock, MagicMock

        import familiar.channels.teams as _teams_mod

        mock_mf = MagicMock()
        mock_mf.text = lambda t: MagicMock(text=t)
        _orig_mf = getattr(_teams_mod, "MessageFactory", None)
        _teams_mod.MessageFactory = mock_mf
        from familiar.channels.teams import FamiliarTeamsBot, TeamsConfig

        cfg = TeamsConfig(app_id="", app_password="")
        bot = FamiliarTeamsBot(agent, cfg)
        tc = MagicMock()
        tc.send_activity = AsyncMock()
        await bot._handle_status(tc)
        tc.send_activity.assert_called_once()
        text = tc.send_activity.call_args[0][0].text
        assert "Status" in text

    @pytest.mark.asyncio
    async def test_teams_handle_model_no_arg(self, agent):
        from unittest.mock import AsyncMock, MagicMock

        import familiar.channels.teams as _teams_mod

        mock_mf = MagicMock()
        mock_mf.text = lambda t: MagicMock(text=t)
        _orig_mf = getattr(_teams_mod, "MessageFactory", None)
        _teams_mod.MessageFactory = mock_mf
        from familiar.channels.teams import FamiliarTeamsBot, TeamsConfig

        cfg = TeamsConfig(app_id="", app_password="")
        bot = FamiliarTeamsBot(agent, cfg)
        tc = MagicMock()
        tc.send_activity = AsyncMock()
        await bot._handle_model(tc, "")
        tc.send_activity.assert_called_once()
        text = tc.send_activity.call_args[0][0].text
        assert "Current" in text

    @pytest.mark.asyncio
    async def test_teams_handle_recall_no_query(self, agent):
        from unittest.mock import AsyncMock, MagicMock

        import familiar.channels.teams as _teams_mod

        mock_mf = MagicMock()
        mock_mf.text = lambda t: MagicMock(text=t)
        _orig_mf = getattr(_teams_mod, "MessageFactory", None)
        _teams_mod.MessageFactory = mock_mf
        from familiar.channels.teams import FamiliarTeamsBot, TeamsConfig

        cfg = TeamsConfig(app_id="", app_password="")
        bot = FamiliarTeamsBot(agent, cfg)
        tc = MagicMock()
        tc.send_activity = AsyncMock()
        await bot._handle_recall(tc, "")
        tc.send_activity.assert_called_once()

    # ── Discord ───────────────────────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_discord_handle_trust(self, agent):
        from unittest.mock import AsyncMock, MagicMock

        try:
            from familiar.channels.discord import DiscordChannel
        except Exception:
            pytest.skip("discord not installed")
        ch = DiscordChannel(agent, token="fake")
        interaction = MagicMock()
        interaction.user.id = 12345
        interaction.response.send_message = AsyncMock()
        await ch._handle_trust(interaction)
        interaction.response.send_message.assert_called_once()
        text = interaction.response.send_message.call_args[0][0]
        assert "Trust" in text

    @pytest.mark.asyncio
    async def test_discord_handle_budget(self, agent):
        from unittest.mock import AsyncMock, MagicMock

        try:
            from familiar.channels.discord import DiscordChannel
        except Exception:
            pytest.skip("discord not installed")
        ch = DiscordChannel(agent, token="fake")
        interaction = MagicMock()
        interaction.user.id = 12345
        interaction.response.send_message = AsyncMock()
        await ch._handle_budget(interaction)
        interaction.response.send_message.assert_called_once()
        text = interaction.response.send_message.call_args[0][0]
        assert "$" in text

    @pytest.mark.asyncio
    async def test_discord_handle_caps(self, agent):
        from unittest.mock import AsyncMock, MagicMock

        try:
            from familiar.channels.discord import DiscordChannel
        except Exception:
            pytest.skip("discord not installed")
        ch = DiscordChannel(agent, token="fake")
        interaction = MagicMock()
        interaction.user.id = 12345
        interaction.response.send_message = AsyncMock()
        await ch._handle_caps(interaction)
        interaction.response.send_message.assert_called_once()
        text = interaction.response.send_message.call_args[0][0]
        assert "Capabilit" in text

    @pytest.mark.asyncio
    async def test_discord_handle_model_no_arg(self, agent):
        from unittest.mock import AsyncMock, MagicMock

        try:
            from familiar.channels.discord import DiscordChannel
        except Exception:
            pytest.skip("discord not installed")
        ch = DiscordChannel(agent, token="fake")
        interaction = MagicMock()
        interaction.user.id = 12345
        interaction.response.send_message = AsyncMock()
        await ch._handle_model(interaction, "")
        interaction.response.send_message.assert_called_once()
        text = interaction.response.send_message.call_args[0][0]
        assert "Current" in text

    @pytest.mark.asyncio
    async def test_discord_handle_remember_no_capability(self, agent):
        from unittest.mock import AsyncMock, MagicMock

        try:
            from familiar.channels.discord import DiscordChannel
        except Exception:
            pytest.skip("discord not installed")
        ch = DiscordChannel(agent, token="fake")
        interaction = MagicMock()
        interaction.user.id = 99999
        interaction.response.send_message = AsyncMock()
        await ch._handle_remember(interaction, "key", "val")
        interaction.response.send_message.assert_called_once()

    @pytest.mark.asyncio
    async def test_discord_handle_recall_no_capability(self, agent):
        from unittest.mock import AsyncMock, MagicMock

        try:
            from familiar.channels.discord import DiscordChannel
        except Exception:
            pytest.skip("discord not installed")
        ch = DiscordChannel(agent, token="fake")
        interaction = MagicMock()
        interaction.user.id = 99999
        interaction.response.send_message = AsyncMock()
        await ch._handle_recall(interaction, "test query")
        interaction.response.send_message.assert_called_once()

    # ── Delivery callback cross-channel ──────────────────────────────────────

    def test_scheduler_delivery_callback_interface(self, agent):
        """set_delivery_callback stores callable, _delivery_callback fires it."""
        delivered = []

        def _cb(msg, channel, chat_id):
            delivered.append((msg, channel, chat_id))

        agent.scheduler.set_delivery_callback(_cb)
        agent.scheduler._delivery_callback("hello", "test", "chat1")
        assert delivered == [("hello", "test", "chat1")]

    def test_cli_trust_shows_levels(self, agent):
        """trust command output contains trust level names."""
        from familiar.channels.cli import CLIChannel

        ch = CLIChannel(agent)
        output = []
        from unittest.mock import patch

        with patch("builtins.print", side_effect=lambda *a: output.extend(a)):
            ch.handle_command("/trust")
        combined = " ".join(str(x) for x in output)
        assert "STRANGER" in combined

    def test_cli_budget_shows_dollar(self, agent):
        """budget command output contains dollar amount."""
        from familiar.channels.cli import CLIChannel

        ch = CLIChannel(agent)
        output = []
        from unittest.mock import patch

        with patch("builtins.print", side_effect=lambda *a: output.extend(a)):
            ch.handle_command("/budget")
        combined = " ".join(str(x) for x in output)
        assert "$" in combined


class TestImapConnectTransport:
    """_imap_connect picks IMAP4_SSL vs IMAP4+STARTTLS based on port."""

    def test_imap_connect_starttls_for_proton_bridge(self):
        """Port 1143 (Proton Bridge) → IMAP4 + starttls()."""
        from unittest.mock import MagicMock, patch

        cfg = {"imap_server": "127.0.0.1", "imap_port": 1143}
        mock_imap = MagicMock()
        with patch("imaplib.IMAP4", return_value=mock_imap) as imap4_cls:
            from familiar.skills.email.skill import _imap_connect

            result = _imap_connect(cfg)
            imap4_cls.assert_called_once_with("127.0.0.1", 1143, timeout=20)
            mock_imap.starttls.assert_called_once()
            assert result is mock_imap

    def test_imap_connect_ssl_for_standard_port(self):
        """Port 993 → IMAP4_SSL (Gmail, Outlook, etc.)."""
        from unittest.mock import MagicMock, patch

        cfg = {"imap_server": "imap.gmail.com", "imap_port": 993}
        mock_ssl = MagicMock()
        with patch("imaplib.IMAP4_SSL", return_value=mock_ssl) as ssl_cls:
            from familiar.skills.email.skill import _imap_connect

            result = _imap_connect(cfg)
            ssl_cls.assert_called_once_with("imap.gmail.com", 993, timeout=20)
            assert result is mock_ssl

    def test_imap_connect_starttls_for_plain_143(self):
        """Port 143 (plain IMAP) → IMAP4 + starttls()."""
        from unittest.mock import MagicMock, patch

        cfg = {"imap_server": "mail.example.com", "imap_port": 143}
        mock_imap = MagicMock()
        with patch("imaplib.IMAP4", return_value=mock_imap):
            from familiar.skills.email.skill import _imap_connect

            result = _imap_connect(cfg)
            mock_imap.starttls.assert_called_once()
            assert result is mock_imap

    def test_triage_imap_connect_starttls(self):
        """Triage skill's _imap_connect uses STARTTLS for port 1143."""
        from unittest.mock import MagicMock, patch

        cfg = {"imap_server": "127.0.0.1", "imap_port": 1143}
        mock_imap = MagicMock()
        with patch("imaplib.IMAP4", return_value=mock_imap):
            from familiar.skills.triage.skill import _imap_connect

            result = _imap_connect(cfg)
            mock_imap.starttls.assert_called_once()
            assert result is mock_imap

    def test_triage_imap_connect_ssl(self):
        """Triage skill's _imap_connect uses SSL for port 993."""
        from unittest.mock import MagicMock, patch

        cfg = {"imap_server": "imap.gmail.com", "imap_port": 993}
        mock_ssl = MagicMock()
        with patch("imaplib.IMAP4_SSL", return_value=mock_ssl):
            from familiar.skills.triage.skill import _imap_connect

            result = _imap_connect(cfg)
            assert result is mock_ssl


class TestProtonSkill:
    """Proton skill has all expected tools and prerequisite entry."""

    def test_proton_skill_tools_list(self):
        """Proton skill exports exactly 4 tools."""
        from familiar.skills.proton.skill import TOOLS

        names = [t["name"] for t in TOOLS]
        assert "proton_status" in names
        assert "proton_vpn_connect" in names
        assert "proton_vpn_disconnect" in names
        assert "proton_vpn_status" in names
        assert len(TOOLS) == 4

    def test_proton_skill_prerequisites_registered(self):
        """Proton skill has an entry in SKILL_PREREQUISITES."""
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "proton" in SKILL_PREREQUISITES
        # Empty list — always loads
        assert SKILL_PREREQUISITES["proton"] == []

    def test_proton_status_reports_bridge_down(self):
        """proton_status returns sensible output when Bridge is not running."""
        from unittest.mock import patch

        with patch("familiar.skills.proton.skill._check_port", return_value=False):
            from familiar.skills.proton.skill import proton_status

            result = proton_status({})
            assert "not running" in result

    def test_proton_vpn_status_no_cli(self):
        """proton_vpn_status handles missing CLI gracefully."""
        from unittest.mock import patch

        with patch("familiar.skills.proton.skill._vpn_cli_available", return_value=False):
            from familiar.skills.proton.skill import proton_vpn_status

            result = proton_vpn_status({})
            assert "not installed" in result


class TestEmailPresets:
    """EMAIL_PRESETS contain correct server details."""

    def test_proton_domain_ports(self):
        from familiar.channels.connect_wizard._helpers import EMAIL_PRESETS

        preset = EMAIL_PRESETS["proton"]
        assert preset["imap_server"] == "127.0.0.1"
        assert preset["smtp_server"] == "127.0.0.1"
        assert preset["imap_port"] == 1143
        assert preset["smtp_port"] == 1025

    def test_gmail_domain_ports(self):
        from familiar.channels.connect_wizard._helpers import EMAIL_PRESETS

        preset = EMAIL_PRESETS["gmail"]
        assert preset["imap_server"] == "imap.gmail.com"
        assert preset["smtp_server"] == "smtp.gmail.com"
        assert preset["imap_port"] == 993
        assert preset["smtp_port"] == 587


# ============================================================
# Nextcloud Skill Tests
# ============================================================


class TestNextcloudSkill:
    """Tests for the Nextcloud CalDAV/CardDAV/WebDAV skill."""

    def test_nextcloud_tools_list(self):
        """Nextcloud skill exports exactly 14 tools."""
        from familiar.skills.nextcloud.skill import TOOLS

        assert len(TOOLS) == 14
        names = [t["name"] for t in TOOLS]
        # CalDAV
        assert "nextcloud_calendar_today" in names
        assert "nextcloud_calendar_create" in names
        assert "nextcloud_calendar_check" in names
        assert "nextcloud_calendar_free" in names
        assert "nextcloud_calendar_delete" in names
        # CardDAV
        assert "nextcloud_contacts_list" in names
        assert "nextcloud_contacts_sync_in" in names
        assert "nextcloud_contacts_sync_out" in names
        # WebDAV
        assert "nextcloud_files_list" in names
        assert "nextcloud_files_search" in names
        assert "nextcloud_files_read" in names
        assert "nextcloud_files_upload" in names
        assert "nextcloud_files_mkdir" in names
        assert "nextcloud_files_delete" in names

    def test_nextcloud_prerequisites_registered(self):
        """Nextcloud entry exists in SKILL_PREREQUISITES with 5 checks."""
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "nextcloud" in SKILL_PREREQUISITES
        checks = SKILL_PREREQUISITES["nextcloud"]
        assert len(checks) == 5

    def test_nc_configured_false_without_env(self):
        """_nc_configured() returns False when env vars are not set."""
        from familiar.skills.nextcloud.skill import _nc_configured

        with patch.dict(os.environ, {}, clear=True):
            assert _nc_configured() is False

    def test_nc_configured_true_with_env(self):
        """_nc_configured() returns True when all env vars are set."""
        from familiar.skills.nextcloud.skill import _nc_configured

        env = {
            "NEXTCLOUD_URL": "https://cloud.example.org",
            "NEXTCLOUD_USER": "alice",
            "NEXTCLOUD_TOKEN": "xxxx-xxxx",
        }
        with patch.dict(os.environ, env, clear=True):
            assert _nc_configured() is True

    def test_nc_get_events_calls_caldav(self):
        """nc_get_events calls caldav.DAVClient and date_search."""
        from datetime import datetime as dt

        mock_event = MagicMock()
        mock_event.data = "VCALENDAR"
        mock_cal = MagicMock()
        mock_cal.date_search.return_value = [mock_event]
        mock_principal = MagicMock()
        mock_principal.calendars.return_value = [mock_cal]
        mock_client = MagicMock()
        mock_client.principal.return_value = mock_principal

        parsed = [{"title": "Standup", "start": dt(2026, 2, 25, 9, 0)}]

        env = {
            "NEXTCLOUD_URL": "https://cloud.example.org",
            "NEXTCLOUD_USER": "alice",
            "NEXTCLOUD_TOKEN": "xxxx",
        }
        with patch.dict(os.environ, env, clear=True):
            with patch(
                "familiar.skills.nextcloud.skill._get_caldav_client", return_value=mock_client
            ):
                with patch("familiar.skills.nextcloud.skill._parse_vevent", return_value=parsed):
                    from familiar.skills.nextcloud.skill import nc_get_events

                    result = nc_get_events({"date": "today"})
                    assert "Standup" in result
                    mock_cal.date_search.assert_called_once()

    def test_nc_list_files_calls_httpx(self):
        """nc_list_files issues a PROPFIND via httpx."""
        multistatus = (
            '<?xml version="1.0"?>'
            '<d:multistatus xmlns:d="DAV:">'
            "<d:response><d:href>/remote.php/dav/files/alice/</d:href>"
            "<d:propstat><d:prop><d:resourcetype><d:collection/></d:resourcetype>"
            "<d:getcontentlength>0</d:getcontentlength></d:prop></d:propstat></d:response>"
            "<d:response><d:href>/remote.php/dav/files/alice/notes.txt</d:href>"
            "<d:propstat><d:prop><d:resourcetype/>"
            "<d:getcontentlength>1024</d:getcontentlength></d:prop></d:propstat></d:response>"
            "</d:multistatus>"
        )
        mock_resp = MagicMock()
        mock_resp.status_code = 207
        mock_resp.text = multistatus

        env = {
            "NEXTCLOUD_URL": "https://cloud.example.org",
            "NEXTCLOUD_USER": "alice",
            "NEXTCLOUD_TOKEN": "xxxx",
        }
        with patch.dict(os.environ, env, clear=True):
            with patch(
                "familiar.skills.nextcloud.skill.httpx.request", return_value=mock_resp
            ) as mock_req:
                from familiar.skills.nextcloud.skill import nc_list_files

                result = nc_list_files({"path": "/"})
                assert "notes.txt" in result
                mock_req.assert_called_once()
                assert mock_req.call_args[0][0] == "PROPFIND"

    def test_nc_create_event_needs_confirmation(self):
        """nc_create_event returns ConfirmationRequired without _confirmed."""
        env = {
            "NEXTCLOUD_URL": "https://cloud.example.org",
            "NEXTCLOUD_USER": "alice",
            "NEXTCLOUD_TOKEN": "xxxx",
        }
        with patch.dict(os.environ, env, clear=True):
            from familiar.skills.nextcloud.skill import nc_create_event

            result = nc_create_event({"title": "Test", "start": "2026-03-01 10:00"})
            assert hasattr(result, "is_confirmation_required")
            assert result.is_confirmation_required()

    def test_webdav_url_construction(self):
        """_get_webdav_url() builds the correct path."""
        env = {
            "NEXTCLOUD_URL": "https://cloud.example.org",
            "NEXTCLOUD_USER": "alice",
            "NEXTCLOUD_TOKEN": "xxxx",
        }
        with patch.dict(os.environ, env, clear=True):
            from familiar.skills.nextcloud.skill import _get_webdav_url

            assert _get_webdav_url("Documents/report.pdf") == (
                "https://cloud.example.org/remote.php/dav/files/alice/Documents/report.pdf"
            )
            assert _get_webdav_url("/") == ("https://cloud.example.org/remote.php/dav/files/alice/")


# ============================================================
# Matrix Channel Tests
# ============================================================


class TestMatrixChannel:
    """Tests for the Matrix channel integration."""

    def test_matrix_channel_import(self):
        """MatrixChannel can be imported (with nio mocked)."""
        mock_nio = MagicMock()
        mock_nio.AsyncClient = MagicMock
        mock_nio.RoomMessageText = "m.room.message"
        mock_nio.InviteMemberEvent = "m.room.member"
        with patch.dict("sys.modules", {"nio": mock_nio}):
            from familiar.channels.matrix import MatrixChannel

            assert MatrixChannel is not None

    def test_matrix_channel_type_enum(self):
        """ChannelType.MATRIX exists in the auth module."""
        from familiar.channels.auth import ChannelType

        assert hasattr(ChannelType, "MATRIX")
        assert ChannelType.MATRIX.value == "matrix"

    def test_matrix_config_fields(self):
        """ChannelConfig has matrix_enabled, matrix_homeserver, etc."""
        from familiar.core.config import ChannelConfig

        cfg = ChannelConfig()
        assert cfg.matrix_enabled is False
        assert cfg.matrix_homeserver is None
        assert cfg.matrix_user is None
        assert isinstance(cfg.matrix_allowed_users, list)
        assert isinstance(cfg.matrix_allowed_rooms, list)
        assert cfg.owner_matrix_id is None

    def test_matrix_command_help(self):
        """_handle_command('help', ...) returns help text."""
        mock_agent = MagicMock()
        mock_agent.get_status.return_value = {
            "provider": "anthropic",
            "memory_entries": 5,
            "skills_loaded": 10,
        }
        mock_nio = MagicMock()
        mock_nio.AsyncClient = MagicMock
        mock_nio.RoomMessageText = "m.room.message"
        mock_nio.InviteMemberEvent = "m.room.member"
        with patch.dict("sys.modules", {"nio": mock_nio}):
            from familiar.channels.matrix import MatrixChannel

            ch = MatrixChannel(mock_agent)
            result = ch._handle_command("help", "", "@user:matrix.org")
            assert result is not None
            assert "Familiar Commands" in result
            assert "/status" in result

    def test_matrix_ignores_own_messages(self):
        """Message from self.user_id is dropped (returns early)."""
        mock_nio = MagicMock()
        mock_nio.AsyncClient = MagicMock
        mock_nio.RoomMessageText = "m.room.message"
        mock_nio.InviteMemberEvent = "m.room.member"
        with patch.dict("sys.modules", {"nio": mock_nio}):
            from familiar.channels.matrix import MatrixChannel

            ch = MatrixChannel(MagicMock(), user_id="@bot:matrix.org")
            mock_room = MagicMock()
            mock_event = MagicMock()
            mock_event.sender = "@bot:matrix.org"
            mock_event.body = "hello"

            import asyncio

            loop = asyncio.new_event_loop()
            # _on_message should return immediately for own messages
            loop.run_until_complete(ch._on_message(mock_room, mock_event))
            loop.close()
            # Agent.chat should NOT have been called
            ch.agent.chat.assert_not_called()


# ============================================================
# Messaging + Matrix Integration Tests
# ============================================================


class TestMessagingMatrixIntegration:
    """Tests for Matrix integration in the messaging skill."""

    def test_detect_platforms_includes_matrix(self):
        """With nio + env, matrix appears in detected platforms."""
        mock_spec = MagicMock()
        env = {
            "MATRIX_HOMESERVER": "https://matrix.org",
            "MATRIX_USER": "@bot:matrix.org",
        }
        with patch.dict(os.environ, env, clear=True):
            with patch("importlib.util.find_spec", return_value=mock_spec):
                from familiar.skills.messaging.skill import detect_available_platforms

                platforms = detect_available_platforms()
                assert "matrix" in platforms

    def test_send_message_platform_enum(self):
        """'matrix' is in the send_message tool's platform enum."""
        from familiar.skills.messaging.skill import TOOLS

        send_msg_tool = [t for t in TOOLS if t["name"] == "send_message"][0]
        enum_values = send_msg_tool["input_schema"]["properties"]["platform"]["enum"]
        assert "matrix" in enum_values

    def test_check_platforms_shows_matrix(self):
        """check_platforms output includes Matrix line."""
        from familiar.skills.messaging.skill import check_platforms

        mock_spec = MagicMock()
        env = {
            "MATRIX_HOMESERVER": "https://matrix.org",
            "MATRIX_USER": "@bot:matrix.org",
        }
        with patch.dict(os.environ, env, clear=True):
            with patch("importlib.util.find_spec", return_value=mock_spec):
                result = check_platforms({})
                assert "Matrix" in result


# ---------------------------------------------------------------------------
# HIPAA Enforcement Tests
# ---------------------------------------------------------------------------


class TestSessionTimeout:
    """Tests for session timeout enforcement (HIPAA item #1)."""

    def test_session_is_expired_true(self):
        """Session with last_interaction 20 min ago is expired at 15 min timeout."""
        from datetime import datetime, timedelta, timezone

        from familiar.core.security import SecureSession

        session = SecureSession(user_id="test", channel="test")
        session.last_interaction = datetime.now(timezone.utc) - timedelta(minutes=20)
        assert session.is_expired(15) is True

    def test_session_is_expired_false(self):
        """Session with last_interaction 5 min ago is NOT expired at 15 min timeout."""
        from datetime import datetime, timedelta, timezone

        from familiar.core.security import SecureSession

        session = SecureSession(user_id="test", channel="test")
        session.last_interaction = datetime.now(timezone.utc) - timedelta(minutes=5)
        assert session.is_expired(15) is False

    def test_cleanup_uses_last_interaction(self):
        """cleanup_idle_sessions uses last_interaction, not the old last_active."""
        from datetime import datetime, timedelta, timezone

        from familiar.core.security import SessionManager

        mgr = SessionManager()
        session = mgr.get_or_create_session("idle_user", "test")
        session.last_interaction = datetime.now(timezone.utc) - timedelta(days=60)
        evicted = mgr.cleanup_idle_sessions(max_idle_days=30)
        assert evicted == 1


class TestPHICloudBlock:
    """Tests for PHI cloud block enforcement (HIPAA item #2)."""

    def test_guardrails_hipaa_blocks_phi(self):
        """HIPAA compliance mode sets PII action to BLOCK."""
        from familiar.core.guardrails import GuardrailConfig, Guardrails, PIIAction

        g = Guardrails(GuardrailConfig(enable_pii_detection=True))
        # Simulate HIPAA mode
        g.set_compliance_mode(type("Mode", (), {"value": "hipaa"})())
        assert g._pii_detector.config.action == PIIAction.BLOCK

    def test_guardrails_default_redacts(self):
        """Without compliance mode, PII action defaults to REDACT."""
        from familiar.core.guardrails import GuardrailConfig, Guardrails, PIIAction

        g = Guardrails(GuardrailConfig(enable_pii_detection=True))
        assert g._pii_detector.config.action == PIIAction.REDACT


class TestEncryptionRequired:
    """Tests for encryption-at-rest requirement (HIPAA item #3)."""

    def test_hipaa_refuses_without_key(self):
        """Agent refuses to start in HIPAA mode without FAMILIAR_ENCRYPTION_KEY."""
        from familiar.core.agent import Agent

        cfg = load_config()
        cfg.llm.default_provider = "ollama"
        cfg.agent.memory_enabled = False
        cfg.agent.scheduler_enabled = False

        # Set compliance mode to HIPAA
        if not hasattr(cfg, "compliance"):
            from types import SimpleNamespace

            cfg.compliance = SimpleNamespace(mode="hipaa")
        else:
            cfg.compliance.mode = "hipaa"

        env_patch = {k: v for k, v in os.environ.items() if k != "FAMILIAR_ENCRYPTION_KEY"}
        with patch.dict(os.environ, env_patch, clear=True):
            with pytest.raises(SystemExit, match="requires encryption"):
                Agent(config=cfg)

    def test_hipaa_passes_with_key(self):
        """Agent starts in HIPAA mode when FAMILIAR_ENCRYPTION_KEY is set."""
        from familiar.core.agent import Agent

        cfg = load_config()
        cfg.llm.default_provider = "ollama"
        cfg.agent.memory_enabled = False
        cfg.agent.scheduler_enabled = False

        if not hasattr(cfg, "compliance"):
            from types import SimpleNamespace

            cfg.compliance = SimpleNamespace(mode="hipaa")
        else:
            cfg.compliance.mode = "hipaa"

        mock_provider = MagicMock(spec=LLMProvider)
        mock_provider.name = "MockProvider"
        mock_provider.model_name = "mock"
        mock_provider.supports_tools = True

        env = dict(os.environ)
        env["FAMILIAR_ENCRYPTION_KEY"] = "dGVzdGtleXRlc3RrZXl0ZXN0a2V5dGVzdGtleXQ="
        with patch.dict(os.environ, env):
            with patch("familiar.core.agent.get_provider", return_value=mock_provider):
                # Should not raise
                agent = Agent(config=cfg)
                assert agent.compliance_mode is not None


class TestRBACEnforcement:
    """Tests for RBAC enforcement in tool router (HIPAA item #4)."""

    def test_rbac_check_permits_wildcard(self):
        """Role with '*:*' permits all tools."""
        from familiar.skills.rbac.skill import _check_perm

        perms = {"*:*"}
        assert _check_perm(perms, "email", "send_email") is True

    def test_rbac_check_denies_unlisted(self):
        """Role with specific perms denies unlisted tool."""
        from familiar.skills.rbac.skill import _check_perm

        perms = {"contacts:search_contacts", "tasks:list_tasks"}
        assert _check_perm(perms, "email", "send_email") is False


class TestAuditEncryption:
    """Tests for audit log encryption (HIPAA item #5)."""

    def test_audit_encrypt_roundtrip(self, tmp_path):
        """Audit events with encrypted storage roundtrip correctly."""
        from familiar.core.audit import AuditAction, AuditConfig, AuditEvent, AuditStore

        # Simple mock encrypted storage
        class MockEncryption:
            def encrypt(self, data):
                return "ENC:" + data

            def decrypt(self, data):
                assert data.startswith("ENC:")
                return data[4:]

        store = AuditStore(
            config=AuditConfig(hash_chain=False),
            db_path=tmp_path / "test_audit.db",
            encrypted_storage=MockEncryption(),
        )
        event = AuditEvent(
            actor_id="user1",
            action=AuditAction.LOGIN,
            details={"ip": "127.0.0.1"},
        )
        store.log(event)
        events = store.query(actor_id="user1")
        assert len(events) >= 1
        assert events[0].details == {"ip": "127.0.0.1"}

    def test_audit_unencrypted_fallback(self, tmp_path):
        """Legacy plaintext entries are still readable."""
        from familiar.core.audit import AuditAction, AuditConfig, AuditEvent, AuditStore

        # Store without encryption
        store = AuditStore(
            config=AuditConfig(hash_chain=False),
            db_path=tmp_path / "test_audit_plain.db",
        )
        event = AuditEvent(
            actor_id="user2",
            action=AuditAction.DATA_VIEW,
            details={"resource": "report"},
        )
        store.log(event)
        events = store.query(actor_id="user2")
        assert len(events) >= 1
        assert events[0].details == {"resource": "report"}


class TestCleanupScheduler:
    """Tests for data retention cleanup job (HIPAA item #6)."""

    def test_handle_cleanup_returns_results(self):
        """_handle_cleanup returns a results dict with cleanup counts."""
        from familiar.core.scheduler import ScheduledTask, Scheduler

        scheduler = Scheduler()
        # Mock an agent with a session manager
        mock_agent = MagicMock()
        mock_agent.sessions.cleanup_idle_sessions.return_value = 3
        scheduler.agent = mock_agent

        task = ScheduledTask(
            id="test",
            name="test_cleanup",
            description="test",
            frequency="daily",
            next_run="2026-01-01T00:00:00",
            last_run=None,
            enabled=True,
            payload={"max_age_days": 30},
            channel=None,
            chat_id=None,
            task_type="cleanup",
        )
        result = scheduler._handle_cleanup(task)
        assert isinstance(result, dict)
        assert result["sessions_evicted"] == 3
        assert result["max_age_days"] == 30

    def test_compliance_cleanup_auto_registered(self):
        """HIPAA mode auto-registers compliance_cleanup task in scheduler."""
        from familiar.core.agent import Agent

        cfg = load_config()
        cfg.llm.default_provider = "ollama"
        cfg.agent.memory_enabled = False
        cfg.agent.scheduler_enabled = True

        if not hasattr(cfg, "compliance"):
            from types import SimpleNamespace

            cfg.compliance = SimpleNamespace(mode="hipaa")
        else:
            cfg.compliance.mode = "hipaa"

        mock_provider = MagicMock(spec=LLMProvider)
        mock_provider.name = "MockProvider"
        mock_provider.model_name = "mock"
        mock_provider.supports_tools = True

        env = dict(os.environ)
        env["FAMILIAR_ENCRYPTION_KEY"] = "dGVzdGtleXRlc3RrZXl0ZXN0a2V5dGVzdGtleXQ="
        with patch.dict(os.environ, env):
            with patch("familiar.core.agent.get_provider", return_value=mock_provider):
                agent = Agent(config=cfg)
                tasks = agent.scheduler.list_tasks()
                cleanup_tasks = [t for t in tasks if t["name"] == "compliance_cleanup"]
                assert len(cleanup_tasks) >= 1


class TestSelfHostedSkills:
    """Tests for self-hosted integration skill registration."""

    def test_homeassistant_tools_registered(self):
        """Home Assistant skill has expected TOOLS list."""
        from familiar.skills.homeassistant.skill import TOOLS

        assert len(TOOLS) == 6
        tool_names = {t["name"] for t in TOOLS}
        assert "ha_list_entities" in tool_names
        assert "ha_call_service" in tool_names

    def test_homeassistant_prereqs_registered(self):
        """Home Assistant has prerequisites in SKILL_PREREQUISITES."""
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "homeassistant" in SKILL_PREREQUISITES

    def test_vaultwarden_tools_registered(self):
        """Vaultwarden skill has expected TOOLS list."""
        from familiar.skills.vaultwarden.skill import TOOLS

        assert len(TOOLS) == 5
        tool_names = {t["name"] for t in TOOLS}
        assert "vw_search_vault" in tool_names
        assert "vw_generate_password" in tool_names

    def test_vaultwarden_prereqs_registered(self):
        """Vaultwarden has prerequisites in SKILL_PREREQUISITES."""
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "vaultwarden" in SKILL_PREREQUISITES

    def test_joplin_tools_registered(self):
        """Joplin skill has expected TOOLS list."""
        from familiar.skills.joplin.skill import TOOLS

        assert len(TOOLS) == 6
        tool_names = {t["name"] for t in TOOLS}
        assert "joplin_search_notes" in tool_names
        assert "joplin_create_note" in tool_names

    def test_joplin_prereqs_registered(self):
        """Joplin has prerequisites in SKILL_PREREQUISITES."""
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "joplin" in SKILL_PREREQUISITES

    def test_jellyfin_tools_registered(self):
        """Jellyfin skill has expected TOOLS list."""
        from familiar.skills.jellyfin.skill import TOOLS

        assert len(TOOLS) == 5
        tool_names = {t["name"] for t in TOOLS}
        assert "jf_search_media" in tool_names
        assert "jf_now_playing" in tool_names

    def test_jellyfin_prereqs_registered(self):
        """Jellyfin has prerequisites in SKILL_PREREQUISITES."""
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "jellyfin" in SKILL_PREREQUISITES

    def test_gitea_tools_registered(self):
        """Gitea skill has expected TOOLS list."""
        from familiar.skills.gitea.skill import TOOLS

        assert len(TOOLS) == 5
        tool_names = {t["name"] for t in TOOLS}
        assert "gitea_list_repos" in tool_names
        assert "gitea_create_issue" in tool_names

    def test_gitea_prereqs_registered(self):
        """Gitea has prerequisites in SKILL_PREREQUISITES."""
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "gitea" in SKILL_PREREQUISITES

    def test_pihole_tools_registered(self):
        """Pi-hole skill has expected TOOLS list."""
        from familiar.skills.pihole.skill import TOOLS

        assert len(TOOLS) == 5
        tool_names = {t["name"] for t in TOOLS}
        assert "pihole_get_stats" in tool_names
        assert "pihole_toggle_blocking" in tool_names

    def test_pihole_prereqs_registered(self):
        """Pi-hole has prerequisites in SKILL_PREREQUISITES."""
        from familiar.core.skills import SKILL_PREREQUISITES

        assert "pihole" in SKILL_PREREQUISITES


# ============================================================
# IMAP Server + Mail Storage Tests (v1.5.2)
# ============================================================


def _run(coro):
    """Run an async coroutine synchronously (safe after loop closure)."""
    import asyncio

    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


class TestIMAPStoreFlags:
    """IMAP STORE command sets and clears message flags."""

    @pytest.fixture()
    def mailbox(self, tmp_path):
        from familiar.skills.email_server.storage import MailStorage

        storage = MailStorage(storage_path=tmp_path)
        _run(storage.initialize())
        _run(storage.create_mailbox("test@example.com", password_hash="dummy"))
        mb = _run(storage.get_mailbox("test@example.com"))
        return mb

    def _make_msg(self, folder="INBOX", msg_id="msg-1"):
        from datetime import datetime, timezone

        from familiar.skills.email_server.storage import StoredMessage

        return StoredMessage(
            id=msg_id,
            folder=folder,
            sender="alice@example.com",
            to=["bob@example.com"],
            cc=[],
            subject="Test",
            date=datetime.now(timezone.utc),
            body="Hello",
            html_body=None,
            attachments=[],
            headers={},
        )

    def test_store_seen_flag(self, mailbox):

        msg = self._make_msg()
        _run(mailbox.store_message(msg))

        # Mark as read
        msg.read = True
        _run(mailbox.store_message(msg))

        fetched = _run(mailbox.get_message("msg-1"))
        assert fetched.read is True

    def test_store_deleted_flag(self, mailbox):

        msg = self._make_msg()
        _run(mailbox.store_message(msg))

        msg.deleted = True
        _run(mailbox.store_message(msg))

        fetched = _run(mailbox.get_message("msg-1"))
        assert fetched.deleted is True

    def test_store_flagged_flag(self, mailbox):

        msg = self._make_msg()
        _run(mailbox.store_message(msg))

        msg.flagged = True
        _run(mailbox.store_message(msg))

        fetched = _run(mailbox.get_message("msg-1"))
        assert fetched.flagged is True


class TestIMAPCopyMessage:
    """IMAP COPY command duplicates messages to another folder."""

    @pytest.fixture()
    def mailbox(self, tmp_path):

        from familiar.skills.email_server.storage import MailStorage

        storage = MailStorage(storage_path=tmp_path)
        _run(storage.initialize())
        _run(storage.create_mailbox("test@example.com", password_hash="dummy"))
        mb = _run(storage.get_mailbox("test@example.com"))
        return mb

    def _make_msg(self, folder="INBOX", msg_id="msg-1"):
        from datetime import datetime, timezone

        from familiar.skills.email_server.storage import StoredMessage

        return StoredMessage(
            id=msg_id,
            folder=folder,
            sender="alice@example.com",
            to=["bob@example.com"],
            cc=[],
            subject="Copy me",
            date=datetime.now(timezone.utc),
            body="Body text",
            html_body=None,
            attachments=[],
            headers={},
        )

    def test_copy_message_to_archive(self, mailbox):

        msg = self._make_msg()
        _run(mailbox.store_message(msg))

        new_id = _run(mailbox.copy_message("msg-1", "Archive"))
        assert new_id is not None
        assert new_id != "msg-1"

        # Original still in INBOX
        original = _run(mailbox.get_messages("INBOX"))
        assert len(original) == 1

        # Copy in Archive
        archived = _run(mailbox.get_messages("Archive"))
        assert len(archived) == 1
        assert archived[0].subject == "Copy me"

    def test_copy_nonexistent_message(self, mailbox):

        result = _run(mailbox.copy_message("nonexistent", "Archive"))
        assert result is None


class TestIMAPExpunge:
    """IMAP EXPUNGE permanently removes deleted-flagged messages."""

    @pytest.fixture()
    def mailbox(self, tmp_path):

        from familiar.skills.email_server.storage import MailStorage

        storage = MailStorage(storage_path=tmp_path)
        _run(storage.initialize())
        _run(storage.create_mailbox("test@example.com", password_hash="dummy"))
        mb = _run(storage.get_mailbox("test@example.com"))
        return mb

    def _make_msg(self, folder="INBOX", msg_id="msg-1", deleted=False):
        from datetime import datetime, timezone

        from familiar.skills.email_server.storage import StoredMessage

        return StoredMessage(
            id=msg_id,
            folder=folder,
            sender="alice@example.com",
            to=["bob@example.com"],
            cc=[],
            subject="Test",
            date=datetime.now(timezone.utc),
            body="Hello",
            html_body=None,
            attachments=[],
            headers={},
            deleted=deleted,
        )

    def test_expunge_removes_deleted_messages(self, mailbox):

        # Store 3 messages, mark one as deleted
        for i in range(3):
            msg = self._make_msg(msg_id=f"msg-{i}", deleted=(i == 1))
            _run(mailbox.store_message(msg))

        # Verify 3 messages exist
        messages = _run(mailbox.get_messages("INBOX"))
        assert len(messages) == 3

        # Delete the marked one (simulate expunge)
        deleted_ids = [m.id for m in messages if m.deleted]
        for mid in deleted_ids:
            _run(mailbox.delete_message(mid))

        # Only 2 remain
        remaining = _run(mailbox.get_messages("INBOX"))
        assert len(remaining) == 2
        assert all(not m.deleted for m in remaining)


class TestIMAPCreateFolder:
    """IMAP CREATE command creates new folders."""

    @pytest.fixture()
    def mailbox(self, tmp_path):

        from familiar.skills.email_server.storage import MailStorage

        storage = MailStorage(storage_path=tmp_path)
        _run(storage.initialize())
        _run(storage.create_mailbox("test@example.com", password_hash="dummy"))
        mb = _run(storage.get_mailbox("test@example.com"))
        return mb

    def test_create_folder(self, mailbox):

        result = _run(mailbox.create_folder("Projects"))
        assert result is True
        assert "Projects" in mailbox.FOLDERS

    def test_create_duplicate_folder(self, mailbox):

        _run(mailbox.create_folder("Projects"))
        result = _run(mailbox.create_folder("Projects"))
        assert result is False


class TestIMAPDeleteFolder:
    """IMAP DELETE command removes folders."""

    @pytest.fixture()
    def mailbox(self, tmp_path):

        from familiar.skills.email_server.storage import MailStorage

        storage = MailStorage(storage_path=tmp_path)
        _run(storage.initialize())
        _run(storage.create_mailbox("test@example.com", password_hash="dummy"))
        mb = _run(storage.get_mailbox("test@example.com"))
        return mb

    def test_delete_folder(self, mailbox):

        _run(mailbox.create_folder("Temp"))
        assert "Temp" in mailbox.FOLDERS

        result = _run(mailbox.delete_folder("Temp"))
        assert result is True
        assert "Temp" not in mailbox.FOLDERS

    def test_cannot_delete_inbox(self, mailbox):

        result = _run(mailbox.delete_folder("INBOX"))
        assert result is False
        assert "INBOX" in mailbox.FOLDERS


class TestIMAPRenameFolder:
    """IMAP RENAME command renames folders."""

    @pytest.fixture()
    def mailbox(self, tmp_path):

        from familiar.skills.email_server.storage import MailStorage

        storage = MailStorage(storage_path=tmp_path)
        _run(storage.initialize())
        _run(storage.create_mailbox("test@example.com", password_hash="dummy"))
        mb = _run(storage.get_mailbox("test@example.com"))
        return mb

    def test_rename_folder(self, mailbox):

        _run(mailbox.create_folder("OldName"))
        result = _run(mailbox.rename_folder("OldName", "NewName"))
        assert result is True
        assert "NewName" in mailbox.FOLDERS
        assert "OldName" not in mailbox.FOLDERS

    def test_cannot_rename_inbox(self, mailbox):

        result = _run(mailbox.rename_folder("INBOX", "NotInbox"))
        assert result is False
        assert "INBOX" in mailbox.FOLDERS


# ============================================================
# Mesh Gateway Peer Auth Tests (v1.5.2)
# ============================================================


def _nacl_available():
    try:
        import nacl  # noqa: F401

        return True
    except ImportError:
        return False


class TestPeerGatewayAuthDifferentiated:
    """PEER_HELLO gets gateway-specific registration with routing capabilities."""

    def test_peer_hello_message_type_exists(self):
        from familiar.core.mesh.gateway import MsgType

        assert MsgType.PEER_HELLO == "peer_hello"
        assert MsgType.PEER_HELLO_ACK == "peer_hello_ack"

    def test_gateway_has_peer_gateway_tracking(self):
        """MeshGateway tracks peer gateways separately."""
        from unittest.mock import MagicMock

        from familiar.core.mesh.gateway import MeshGateway

        agent = MagicMock()
        gw = MeshGateway(agent, host="127.0.0.1", port=0)
        assert isinstance(gw.peer_gateways, dict)
        assert isinstance(gw.peer_gateway_info, dict)
        assert isinstance(gw.peer_gateway_tools, dict)

    def test_node_info_supports_gateway_type(self):
        """NodeInfo can represent a gateway node with routing capabilities."""
        from familiar.core.mesh.gateway import NodeInfo

        info = NodeInfo(
            node_id="peer-1",
            name="remote-gw",
            type="gateway",
            connected_at="2026-01-01T00:00:00",
            last_seen="2026-01-01T00:00:00",
            tools=[],
            capabilities=["routing"],
        )
        assert info.type == "gateway"
        assert "routing" in info.capabilities


class TestPeerGatewayMessageRouting:
    """Unknown nodes get forwarded via peer gateways."""

    def test_send_to_node_returns_false_for_unknown(self):
        """send_to_node returns False when node is not connected and no peer has it."""
        from unittest.mock import MagicMock

        from familiar.core.mesh.gateway import MeshGateway, Message, MsgType

        agent = MagicMock()
        gw = MeshGateway(agent, host="127.0.0.1", port=0)

        msg = Message(type=MsgType.USER_MESSAGE, payload={"text": "hello"})
        result = _run(gw.send_to_node("nonexistent-node", msg))
        assert result is False


# ============================================================
# Secure Transport: prev_chain_len Tests (v1.5.2)
# ============================================================


class TestRatchetPrevChainLength:
    """Verify prev_chain_len tracks correctly across DH ratchet steps."""

    def test_ratchet_state_has_prev_send_count(self):
        """RatchetState includes prev_send_count field."""
        from familiar.core.secure_transport import RatchetState

        state = RatchetState()
        assert state.prev_send_count == 0

    def test_prev_send_count_serialization(self):
        """prev_send_count round-trips through to_dict/from_dict."""
        from familiar.core.secure_transport import RatchetState

        state = RatchetState()
        state.prev_send_count = 42

        data = state.to_dict()
        assert data["prev_send_count"] == 42

        restored = RatchetState.from_dict(data)
        assert restored.prev_send_count == 42

    @pytest.mark.skipif(
        not _nacl_available(),
        reason="PyNaCl not installed",
    )
    def test_encrypt_uses_prev_send_count(self):
        """encrypt() puts prev_send_count into message header, not hardcoded 0."""
        from familiar.core.secure_transport import (
            X3DH,
            DoubleRatchet,
            X3DHKeys,
        )

        # Set up a sender-receiver pair via X3DH
        alice_keys = X3DHKeys.generate()
        bob_keys = X3DHKeys.generate()

        bob_bundle = bob_keys.get_bundle()
        shared_secret, init_msg = X3DH.initiate(alice_keys.identity_key, bob_bundle, b"hello")

        alice_ratchet = DoubleRatchet.init_sender(shared_secret, bob_bundle.signed_prekey)

        # Send a few messages to build up send_count
        for _ in range(5):
            alice_ratchet.encrypt(b"test message")

        assert alice_ratchet.state.send_count == 5

        # Now simulate a DH ratchet step
        alice_ratchet.state.prev_send_count = alice_ratchet.state.send_count
        alice_ratchet.state.send_count = 0

        # Next encrypt should have prev_chain_len == 5
        msg = alice_ratchet.encrypt(b"after ratchet")
        assert msg.prev_chain_len == 5
        assert msg.message_num == 0
