# Pi-hole / AdGuard Home

Monitor and control your DNS-level ad blocker.

## Usage

Use this skill when the user asks about DNS blocking, ad blocking statistics, query logs, or wants to enable/disable blocking. Works with both Pi-hole and AdGuard Home.

## Examples

- "How many ads were blocked today?"
- "Is Pi-hole blocking right now?"
- "Show me the top blocked domains"
- "What DNS queries happened recently?"
- "Disable blocking for 5 minutes"
- "Show me Pi-hole stats"

## Important

- **Stats vs Status**: `pihole_get_stats` returns aggregate numbers (queries, blocked count, percentages). `pihole_get_status` returns whether blocking is currently enabled or disabled. Use the right one.
- Toggling blocking affects the entire network — always confirm with the user.
- Query logs can be large; use the `count` parameter to limit results.

## Disambiguation

- This is **NOT** for VPN — use Proton (`proton_*`) for VPN control.
- This is **NOT** for firewall rules — Pi-hole only handles DNS-level blocking.
- This is **NOT** for network speed tests or connectivity diagnostics.

## Setup

Set `PIHOLE_URL` and `PIHOLE_TOKEN` environment variables. Optionally set `PIHOLE_TYPE` to `adguard` for AdGuard Home (defaults to `pihole`).

## Tools

- `pihole_get_stats` — Get blocking statistics summary (total queries, blocked count, percentage)
- `pihole_top_queries` — Show top queries and blocked domains
- `pihole_toggle_blocking` — Enable or disable blocking (requires confirmation)
- `pihole_get_status` — Check if blocking is enabled or disabled
- `pihole_query_log` — View recent DNS queries
