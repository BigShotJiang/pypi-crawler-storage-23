# Vaultwarden / Bitwarden

Manage your password vault via Bitwarden-compatible API.

## Setup
Set `VAULTWARDEN_URL` and `VAULTWARDEN_TOKEN` environment variables.

## Tools
- `vw_search_vault` — Search vault items by name or URI
- `vw_get_password` — Retrieve a specific vault item (requires confirmation)
- `vw_generate_password` — Generate a random password (local, no API call)
- `vw_create_entry` — Create a new vault entry (requires confirmation)
- `vw_list_folders` — List vault folders/collections
