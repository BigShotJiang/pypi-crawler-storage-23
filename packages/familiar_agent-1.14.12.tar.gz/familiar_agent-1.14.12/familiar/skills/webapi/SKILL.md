# Web API Skill - Argus, the All-Seeing

*Argus Panoptes was the hundred-eyed giant who could see everything at once. He watches all the endpoints of the web and brings back what you seek.*

Make HTTP requests to external APIs and web services.

## Usage

Use this skill when the user wants to:
- Fetch data from web APIs
- Check weather, news, or other online services
- Interact with webhooks or REST APIs

## Tools

- `fetch_url`: Fetch content from a URL
- `fetch_json_api`: Call a JSON API and parse response
- `post_webhook`: Send data to a webhook
