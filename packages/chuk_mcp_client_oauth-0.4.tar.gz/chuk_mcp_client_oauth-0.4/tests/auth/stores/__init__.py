"""Tests for auth storage backends."""
