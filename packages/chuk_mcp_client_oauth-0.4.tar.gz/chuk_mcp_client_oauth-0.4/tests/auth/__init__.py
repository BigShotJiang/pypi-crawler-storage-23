"""Tests for authentication and token management."""
