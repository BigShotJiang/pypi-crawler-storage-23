"""Tests for mpak SDK."""
