# nw-troubleshooter-reviewer

Use for review and critique tasks - Risk analysis and failure mode review specialist. Runs on Haiku for cost efficiency.

**Wave:** Other
**Model:** haiku
**Max turns:** 30
**Tools:** Read, Glob, Grep, Task

## Skills

- [review-criteria](../../../nWave/skills/troubleshooter-reviewer/review-criteria.md) — Review dimensions and scoring for root cause analysis quality assessment
