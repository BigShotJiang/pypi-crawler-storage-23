# nw-researcher-reviewer

Use for review and critique tasks - Research quality and evidence review specialist. Runs on Haiku for cost efficiency.

**Wave:** Other
**Model:** haiku
**Max turns:** 20
**Tools:** Read, Glob, Grep, Task

## Commands

- [`/nw:document`](../commands/index.md)

## Skills

- [critique-dimensions](../../../nWave/skills/researcher-reviewer/critique-dimensions.md) — Critique dimensions and scoring for research document reviews
