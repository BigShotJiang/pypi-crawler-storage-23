"""Update module for nWave safe update functionality."""
