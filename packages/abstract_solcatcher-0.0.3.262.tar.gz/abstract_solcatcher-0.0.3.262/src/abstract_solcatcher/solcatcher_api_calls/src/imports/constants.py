from .utils import *
DOMAIN = "https://solcatcher.io"
API_PREFIX = 'api'
ENDPOINTS_PREFIX = "endpoints"
API_URL = join_url(DOMAIN,API_PREFIX)
ENDPOINTS_URL = join_url(API_URL,ENDPOINTS_PREFIX)
