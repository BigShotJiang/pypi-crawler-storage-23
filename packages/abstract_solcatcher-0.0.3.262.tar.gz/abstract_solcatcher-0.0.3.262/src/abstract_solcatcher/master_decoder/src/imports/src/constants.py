SOL_LAMPORTS = 1_000_000_000  # 10^9
SOL_DECIMALS = 9
PUMPFUN_TOKEN_DECIMALS = 6  # All pump.fun tokens use 6 decimals
