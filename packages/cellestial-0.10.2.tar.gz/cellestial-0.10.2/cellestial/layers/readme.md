# Layers

Layers should be added to `PlotSpec` in the the following format

```python
plot + layer_function()
```


## Layers to Add

- arrow_axis()
- ondata_legend()
- interactive()