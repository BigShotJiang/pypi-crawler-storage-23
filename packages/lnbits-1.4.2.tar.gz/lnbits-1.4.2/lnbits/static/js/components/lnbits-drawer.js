window.app.component('lnbits-drawer', {
  template: '#lnbits-drawer',
  mixins: [window.windowMixin]
})
