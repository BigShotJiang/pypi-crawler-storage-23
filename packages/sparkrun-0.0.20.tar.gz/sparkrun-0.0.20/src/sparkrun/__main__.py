"""Allow running sparkrun as: python -m sparkrun"""

from sparkrun.cli import main

main()
