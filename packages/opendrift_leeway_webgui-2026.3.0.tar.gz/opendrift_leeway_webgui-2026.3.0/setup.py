#!/usr/bin/env python3
"""Setup.py"""

from setuptools import setup

setup()
