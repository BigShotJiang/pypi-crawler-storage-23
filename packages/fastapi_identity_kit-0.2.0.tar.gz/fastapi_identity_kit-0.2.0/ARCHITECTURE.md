# Architecture - FastAPI Identity Provider

## System Overview

The FastAPI Identity Provider is a production-grade OAuth2/OpenID Connect identity provider built with security-first principles. The architecture follows defense-in-depth patterns with multiple security layers, scalable design, and comprehensive monitoring.

## High-Level Architecture

### Option 1: With Load Balancer (Production)

```mermaid
graph TB
    subgraph "Client Layer"
        A[Web Applications]
        B[Mobile Applications]
        C[SPAs]
        D[Third-party Services]
    end
    
    subgraph "Edge Security"
        E[CDN / WAF]
        F[Load Balancer]
        G[SSL Termination]
    end
    
    subgraph "Web Server Layer"
        H[Nginx Reverse Proxy]
    end
    
    subgraph "Application Layer"
        I[FastAPI Application]
        J[Security Middleware]
        K[Rate Limiting]
    end
    
    subgraph "Service Layer"
        L[Authentication Service]
        M[Authorization Service]
        N[Token Service]
        O[MFA Service]
        P[Risk Engine]
    end
    
    subgraph "Data Layer"
        Q[PostgreSQL Database]
        R[Redis Cache]
        S[Vault Secret Store]
        T[Encrypted Storage]
    end
    
    A --> E
    B --> E
    C --> E
    D --> E
    
    E --> F
    F --> G
    G --> H
    H --> J
    J --> K
    J --> I
    
    I --> L
    I --> M
    I --> N
    I --> O
    I --> P
    
    L --> Q
    M --> Q
    N --> Q
    O --> R
    P --> R
    
    N --> S
    L --> S
```

### Option 2: Direct Deployment (Simple/Development)

```mermaid
graph TB
    subgraph "Client Layer"
        A[Web Applications]
        B[Mobile Applications]
        C[SPAs]
        D[Third-party Services]
    end
    
    subgraph "Application Layer"
        I[FastAPI Application]
        J[Security Middleware]
        K[Rate Limiting]
        L[HTTPS Enforcement]
    end
    
    subgraph "Service Layer"
        M[Authentication Service]
        N[Authorization Service]
        O[Token Service]
        P[MFA Service]
        Q[Risk Engine]
    end
    
    subgraph "Data Layer"
        R[PostgreSQL Database]
        S[Redis Cache]
        T[Vault Secret Store]
        U[Encrypted Storage]
    end
    
    A --> I
    B --> I
    C --> I
    D --> I
    
    I --> J
    J --> K
    J --> L
    J --> I
    
    I --> M
    I --> N
    I --> O
    I --> P
    I --> Q
    
    M --> R
    N --> R
    O --> R
    P --> S
    Q --> S
    
    O --> T
    M --> T
```

## Component Architecture

### 1. Edge Security Layer

#### CDN / Web Application Firewall
- **Purpose**: DDoS protection, content filtering, geographic distribution
- **Technologies**: Cloudflare, AWS CloudFront, or Akamai
- **Security Features**: Rate limiting, IP reputation, bot detection

#### Load Balancer
- **Purpose**: Traffic distribution, health checks, failover
- **Technologies**: HAProxy, AWS ALB, or Nginx
- **Security Features**: SSL termination, health monitoring

#### SSL/TLS Termination
- **Purpose**: Encryption management, certificate handling
- **Standards**: TLS 1.3, strong cipher suites
- **Security Features**: HSTS, certificate pinning, OCSP stapling

### 2. Web Server Layer (Optional)

#### Nginx Reverse Proxy (Optional for Production)
```nginx
# Security Configuration (Optional)
server {
    listen 443 ssl http2;
    server_name identity.example.com;
    
    # SSL Configuration
    ssl_certificate /etc/ssl/cert.pem;
    ssl_certificate_key /etc/ssl/key.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-SHA384;
    
    # Security Headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload";
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header Content-Security-Policy "default-src 'self'";
    
    # Rate Limiting
    limit_req_zone $binary_remote_addr zone=auth:10m rate=10r/m;
    limit_req_zone $binary_remote_addr zone=token:10m rate=20r/m;
    
    location / {
        proxy_pass http://app:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Apply rate limiting to auth endpoints
        location /oauth/authorize {
            limit_req zone=auth burst=5 nodelay;
            proxy_pass http://localhost:8000;
        }
        
        location /oauth/token {
            limit_req zone=token burst=10 nodelay;
            proxy_pass http://localhost:8000;
        }
    }

    # HTTP to HTTPS Redirect
    server {
        listen 80;
        server_name identity.example.com;
        return 301 https://$server_name$request_uri;
    }
}
```

### 3. Application Layer

#### FastAPI Application Structure
```
fastapi_identity_kit/
├── config/                 # Configuration management
│   ├── settings.py         # Environment-based settings
│   └── secret_manager.py   # Secret management
├── shared_security/         # Security components
│   ├── jwt_engine.py       # JWT signing/verification
│   ├── key_manager.py      # Key rotation and storage
│   ├── middleware.py        # Security middleware
│   ├── https_middleware.py # HTTPS enforcement
│   ├── key_rotation.py     # Automated key rotation
│   ├── database_encryption.py # Data encryption
│   ├── error_handling.py   # Security error handling
│   └── crypto_utils.py    # Cryptographic utilities
├── identity_server/         # OAuth2/OIDC core
│   ├── router.py           # OAuth2 endpoints
│   ├── token_service.py    # Token management
│   ├── client_service.py   # Client authentication
│   └── models.py          # Database models
├── identity_core/          # User management
│   ├── password_service.py # Password hashing
│   ├── models.py          # User models
│   └── recovery.py        # Account recovery
├── authorization/          # RBAC system
│   ├── rbac.py            # Role-based access control
│   └── models.py          # Permission models
├── mfa/                   # Multi-factor auth
│   ├── totp.py            # TOTP implementation
│   ├── redis_lockout.py   # MFA lockout
│   └── backup_codes.py    # Backup codes
├── risk_engine/            # Risk analysis
│   ├── analyzer.py         # Risk scoring
│   └── models.py          # Risk models
└── audit/                 # Audit logging
    ├── service.py          # Audit service
    └── models.py          # Audit models
```

#### Security Middleware Stack
```python
# Middleware Order (outermost first)
1. HTTPSEnforcementMiddleware     # HTTPS enforcement
2. SecurityHeadersMiddleware       # Security headers
3. RateLimitMiddleware           # Rate limiting
4. RequestLoggingMiddleware       # Security logging
5. CORSMiddleware              # CORS policy
6. ErrorHandlingMiddleware       # Security error handling
```

### 4. Service Layer Architecture

#### Authentication Service
```mermaid
graph LR
    A[Client Request] --> B[Input Validation]
    B --> C[Rate Limit Check]
    C --> D[User Authentication]
    D --> E[MFA Verification]
    E --> F[Session Creation]
    F --> G[Audit Logging]
    G --> H[Response]
```

#### Authorization Service (RBAC)
```mermaid
graph TB
    A[User Request] --> B[Tenant Validation]
    B --> C[Role Lookup]
    C --> D[Permission Resolution]
    D --> E[Access Decision]
    E --> F[Audit Logging]
    F --> G[Allow/Deny Response]
```

#### Token Service
```mermaid
graph LR
    A[Token Request] --> B[Client Authentication]
    B --> C[PKCE Validation]
    C --> D[Authorization Code Exchange]
    D --> E[Token Generation]
    E --> F[Key Signing]
    F --> G[Token Response]
    
    H[Refresh Request] --> I[Token Validation]
    I --> J[Replay Detection]
    J --> K[Token Rotation]
    K --> L[New Token Issuance]
```

### 5. Data Layer Architecture

#### Database Schema
```sql
-- Core Tables
users                    -- User accounts and profiles
sessions                 -- User sessions and device tracking
oauth_clients            -- OAuth2 client applications
authorization_codes      -- One-time authorization codes
refresh_tokens          -- Refresh token families
roles                   -- RBAC roles
permissions             -- System permissions
user_roles             -- User-role assignments
role_permissions        -- Role-permission mappings
mfa_configurations      -- MFA setup and backup codes
security_events         -- Security audit log
login_history           -- Authentication attempts
device_identities      -- Device fingerprinting
```

#### Encryption Strategy
```mermaid
graph TB
    A[Application Data] --> B[Column Selection]
    B --> C[Encryption Service]
    C --> D[Fernet Encryption]
    D --> E[Encrypted Storage]
    E --> F[Database]
    
    G[Key Rotation] --> H[New Encryption Key]
    H --> C
    
    I[Data Access] --> J[Decryption Service]
    J --> K[Fernet Decryption]
    K --> L[Original Data]
```

#### Caching Strategy
```mermaid
graph LR
    A[User Permissions] --> B[Redis Cache]
    C[Client Configuration] --> B
    D[Key Metadata] --> B
    E[Rate Limit Counters] --> B
    F[Session Data] --> B
    
    B --> G[TTL: 5 minutes]
    B --> H[TTL: 1 hour]
    B --> I[TTL: 24 hours]
```

## Security Architecture

### Defense in Depth Layers

```mermaid
graph TB
    subgraph "Layer 7: Application"
        A[Input Validation]
        B[Authentication]
        C[Authorization]
        D[Session Management]
    end
    
    subgraph "Layer 6: Presentation"
        E[HTTPS Enforcement]
        F[Security Headers]
        G[CORS Policy]
        H[CSRF Protection]
    end
    
    subgraph "Layer 5: Session"
        I[Secure Cookies]
        J[Session Encryption]
        K[Device Fingerprinting]
        L[Concurrent Session Limits]
    end
    
    subgraph "Layer 4: Transport"
        M[TLS 1.3]
        N[Certificate Validation]
        O[HSTS Enforcement]
        P[Perfect Forward Secrecy]
    end
    
    subgraph "Layer 3: Network"
        Q[Firewall Rules]
        R[DDoS Protection]
        S[Network Segmentation]
        T[Intrusion Detection]
    end
    
    subgraph "Layer 2: Data Link"
        U[Database Encryption]
        V[Secret Management]
        W[Backup Encryption]
        X[Audit Logging]
    end
    
    subgraph "Layer 1: Physical"
        Y[Access Controls]
        Z[Environmental Security]
        AA[Hardware Security Modules]
    end
```

## Data Flow Security

### OAuth2 Authorization Code Flow
```mermaid
sequenceDiagram
    participant C as Client
    participant U as User
    participant A as Auth Server
    participant D as Database
    participant V as Vault
    
    C->>A: GET /oauth/authorize
    Note over A: Validate client, redirect_uri
    A->>U: Redirect to login page
    U->>A: POST credentials
    A->>D: Validate user
    D-->>A: User data
    A->>V: Get encryption key
    V-->>A: Encryption key
    A->>D: Store authorization code
    D-->>A: Code stored
    A->>C: Redirect with code
    
    C->>A: POST /oauth/token
    Note over A: Validate PKCE verifier
    A->>D: Exchange code for tokens
    D-->>A: User session data
    A->>V: Get signing key
    V-->>A: Signing key
    A->>A: Sign JWT tokens
    A->>C: Return tokens
```

### Token Refresh Flow
```mermaid
sequenceDiagram
    participant C as Client
    participant A as Auth Server
    participant D as Database
    participant R as Redis
    
    C->>A: POST /oauth/token (refresh_token)
    A->>R: Check rate limit
    R-->>A: Rate limit OK
    A->>D: Validate refresh token
    D-->>A: Token data
    A->>A: Check replay protection
    Note over A: Atomic transaction
    A->>D: Mark old token used
    A->>D: Create new token
    A->>A: Sign new token
    A->>C: Return new tokens
```

## Scalability Architecture

### Horizontal Scaling
```mermaid
graph TB
    subgraph "Load Balancer Tier"
        LB[Load Balancer]
    end
    
    subgraph "Application Tier"
        APP1[FastAPI Instance 1]
        APP2[FastAPI Instance 2]
        APP3[FastAPI Instance N]
    end
    
    subgraph "Cache Tier"
        REDIS1[Redis Master]
        REDIS2[Redis Replica 1]
        REDIS3[Redis Replica N]
    end
    
    subgraph "Database Tier"
        DB1[PostgreSQL Master]
        DB2[PostgreSQL Replica 1]
        DB3[PostgreSQL Replica N]
    end
    
    LB --> APP1
    LB --> APP2
    LB --> APP3
    
    APP1 --> REDIS1
    APP2 --> REDIS1
    APP3 --> REDIS1
    
    REDIS2 --> REDIS1
    REDIS3 --> REDIS1
    
    APP1 --> DB1
    APP2 --> DB1
    APP3 --> DB1
    
    DB2 --> DB1
    DB3 --> DB1
```

### Caching Strategy
- **L1 Cache**: Application memory (frequently accessed data)
- **L2 Cache**: Redis cluster (shared session data)
- **L3 Cache**: Database query cache (expensive queries)
- **Cache Invalidation**: TTL-based and event-driven invalidation

## Monitoring Architecture

### Security Monitoring
```mermaid
graph TB
    subgraph "Application Metrics"
        A[Authentication Events]
        B[Authorization Failures]
        C[Token Operations]
        D[MFA Attempts]
    end
    
    subgraph "Infrastructure Metrics"
        E[Rate Limit Hits]
        F[SSL Certificate Status]
        G[Database Performance]
        H[Redis Performance]
    end
    
    subgraph "Business Metrics"
        I[Active Users]
        J[Token Issuance Rate]
        K[Client Usage]
        L[Error Rates]
    end
    
    subgraph "Alerting"
        M[Prometheus]
        N[Grafana]
        O[AlertManager]
        P[PagerDuty]
    end
    
    A --> M
    B --> M
    C --> M
    D --> M
    
    E --> M
    F --> M
    G --> M
    H --> M
    
    I --> M
    J --> M
    K --> M
    L --> M
    
    M --> N
    M --> O
    O --> P
```

### Log Management
```mermaid
graph LR
    A[Application Logs] --> B[Fluentd]
    C[Security Logs] --> B
    D[Access Logs] --> B
    E[Audit Logs] --> B
    
    B --> F[Elasticsearch]
    F --> G[Kibana]
    
    H[Log Retention] --> I[S3 Storage]
    J[Log Archive] --> I
```

## Deployment Architecture

### Option 1: Direct Deployment (No Docker)
```bash
# Install with uv (recommended)
uv add fastapi-identity-kit

# Or with pip (alternative)
pip install fastapi-identity-kit

# Run with uvicorn (development)
uvicorn main:app --host 0.0.0.0 --port 8000 --ssl-keyfile key.pem --ssl-certfile cert.pem

# Or with gunicorn (production)
uv add gunicorn
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000 --keyfile key.pem --certfile cert.pem
```

### Option 2: Docker Containerization
#### Container Orchestration
```yaml
# Docker Compose Structure (Direct Deployment)
version: '3.8'
services:
  app:
    build: .
    ports: ["8000:8000"]  # Direct FastAPI access
    environment:
      - ENVIRONMENT=production
      - DATABASE_URL=postgresql://postgres:password@db:5432/identity
      - REDIS_URL=redis://redis:6379/0
      - ENFORCE_HTTPS=true  # Built-in HTTPS enforcement
    depends_on: [db, redis, vault]
    deploy:
      replicas: 3
  
  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=identity
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=password
    volumes: ["postgres_data:/var/lib/postgresql/data"]
  
  redis:
    image: redis:7-alpine
    command: redis-server --requirepass ${REDIS_PASSWORD}
    volumes: ["redis_data:/data"]
  
  vault:
    image: vault:1.15
    environment:
      - VAULT_ADDR=http://0.0.0.0:8200
      - VAULT_TOKEN=${VAULT_TOKEN}
    volumes: ["vault_data:/vault/file"]

# Optional: With Nginx Reverse Proxy
version: '3.8'
services:
  nginx:
    image: nginx:alpine
    ports: ["443:443", "80:80"]
    volumes: ["./nginx.conf:/etc/nginx"]
    depends_on: [app]
  
  app:
    build: .
    ports: []  # No direct port exposure
    environment:
      - ENVIRONMENT=production
      - DATABASE_URL=postgresql://postgres:password@db:5432/identity
      - REDIS_URL=redis://redis:6379/0
    depends_on: [db, redis, vault]
    deploy:
      replicas: 3
  
  # ... other services same as above
```

### Option 3: Cloud Native Deployment
```bash
# Serverless deployment (AWS Lambda, Vercel, etc.)
# Package as a serverless function with API Gateway

# PaaS deployment (Heroku, Render, Railway)
# Deploy directly from Git with environment variables

# Cloud VM deployment (AWS EC2, DigitalOcean, etc.)
# Direct Python deployment with systemd service
```

### Kubernetes Deployment
```yaml
# Kubernetes Resources
apiVersion: apps/v1
kind: Deployment
metadata:
  name: identity-provider
spec:
  replicas: 3
  selector:
    matchLabels:
      app: identity-provider
  template:
    metadata:
      labels:
        app: identity-provider
    spec:
      containers:
      - name: identity-provider
        image: identity-provider:latest
        ports:
        - containerPort: 8000
        env:
        - name: ENVIRONMENT
          value: "production"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: db-secret
              key: url
        - name: REDIS_URL
          valueFrom:
            secretKeyRef:
              name: redis-secret
              key: url
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
```

## Security Controls Summary

| Control Category | Implementation | Status |
|-----------------|----------------|--------|
| Authentication | OAuth2 + OIDC + MFA | ✅ Complete |
| Authorization | RBAC + Tenant Isolation | ✅ Complete |
| Data Protection | Encryption + Key Rotation | ✅ Complete |
| Network Security | HTTPS + HSTS + WAF | ✅ Complete |
| Monitoring | Metrics + Logging + Alerting | ✅ Complete |
| Incident Response | Automated + Manual Procedures | ✅ Complete |

This architecture provides enterprise-grade security, scalability, and maintainability for the FastAPI Identity Provider.
