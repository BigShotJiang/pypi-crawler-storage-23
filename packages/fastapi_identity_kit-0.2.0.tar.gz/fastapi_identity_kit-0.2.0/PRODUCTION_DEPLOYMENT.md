# Production Deployment Guide - FastAPI Identity Provider

## Overview

This guide provides comprehensive instructions for deploying the security-hardened FastAPI identity provider to production environments with all enterprise-grade security features enabled.

## 🔒 Production Security Features

### ✅ Implemented Security Hardening

1. **HTTPS Enforcement**
   - Automatic HTTP to HTTPS redirection
   - HSTS with configurable max-age and preload
   - Certificate validation and monitoring

2. **Environment-Based Configuration**
   - Separate configs for dev/staging/production
   - Environment-specific security policies
   - Configuration validation on startup

3. **Key Rotation Support**
   - Automated JWT signing key rotation
   - Configurable rotation policies
   - Audit logging for key changes

4. **Encryption Key Rotation**
   - Master encryption key rotation
   - Secure key derivation with PBKDF2
   - Migration support for encrypted data

5. **Database Encryption**
   - Column-level encryption for sensitive data
   - Automatic key rotation migration
   - Integrity verification

6. **Secret Management Integration**
   - Support for multiple secret providers
   - HashiCorp Vault integration
   - AWS Secrets Manager integration
   - Environment variable fallback

## 🚀 Deployment Architecture

### Deployment Options

#### Option 1: Direct Python Deployment (Simple)
```bash
# Install with uv (recommended)
uv add fastapi-identity-kit

# Or with pip (alternative)
pip install fastapi-identity-kit

# Run with uvicorn (development)
uvicorn main:app --host 0.0.0.0 --port 8000 --ssl-keyfile key.pem --ssl-certfile cert.pem

# Run with gunicorn (production)
uv add gunicorn
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000 --keyfile key.pem --certfile cert.pem
```

**Note**: `uv` is the recommended package manager for this project. It provides faster installation times and better dependency resolution. However, `pip` is also supported for environments where `uv` is not available.

#### Option 2: Docker Containerization (Recommended for Production)
```dockerfile
# Production Dockerfile
FROM python:3.11-slim

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# Install uv for faster package management
RUN pip install uv

# Set working directory
WORKDIR /app

# Copy requirements
COPY requirements.txt .
RUN uv pip install --no-cache -r requirements.txt

# Copy application
COPY . .

# Create non-root user
RUN useradd --create-home --shell /bin/bash app
RUN chown -R app:app /app
USER app

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1

# Expose port
EXPOSE 8000

# Run application
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

#### Option 3: Cloud Native Deployment
- **Serverless**: AWS Lambda, Vercel, Railway with API Gateway
- **PaaS**: Heroku, Render, DigitalOcean App Platform
- **Cloud VM**: AWS EC2, Google Cloud Compute, DigitalOcean Droplets

### Production Stack (Optional Components)

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Client Apps   │    │   Web Server   │    │   Application   │
│   (Browser/Mobile)│────│   (Nginx)      │────│   (FastAPI)    │
│                 │    │   (Optional)   │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                       │
                       ┌─────────────────┐    ┌─────────────────┐
                       │   Database      │    │   External      │
                       │   (PostgreSQL)  │    │   Services      │
                       │   Encrypted     │    │   (Vault,      │
                       │   at Rest       │    │    IdPs)        │
                       └─────────────────┘    └─────────────────┘
                                │                        │
                       ┌─────────────────┐    ┌─────────────────┐
                       │   Secret Store  │    │   Monitoring    │
                       │   (Vault/AWS)  │    │   (Prometheus)  │
                       └─────────────────┘    └─────────────────┘
```

## 📋 Environment Configuration

### Production Environment Variables

Create `.env.production` file:

```bash
# Environment
ENVIRONMENT=production
DEBUG=false

# HTTPS Configuration
ENFORCE_HTTPS=true
HSTS_MAX_AGE=31536000
HSTS_INCLUDE_SUBDOMAINS=true
HSTS_PRELOAD=true

# JWT Configuration
JWT_ALGORITHM=RS256
JWT_ACCESS_TOKEN_EXPIRE_MINUTES=15
JWT_REFRESH_TOKEN_EXPIRE_DAYS=30
JWT_ISSUER=https://identity.yourdomain.com

# Key Rotation
KEY_ROTATION_DAYS=90
KEY_RETENTION_DAYS=180

# Database (PostgreSQL with SSL)
DATABASE_URL=postgresql+asyncpg://user:password@db.yourdomain.com:5432/identity?ssl=require&sslcert=/path/to/client-cert.pem&sslkey=/path/to/client-key.pem&sslrootcert=/path/to/ca-cert.pem
DATABASE_SSL_MODE=require
DATABASE_POOL_SIZE=20

# Redis (Cluster with Auth)
REDIS_URL=redis://:password@redis-cluster.yourdomain.com:6379/0
REDIS_PASSWORD=your-redis-password
REDIS_SSL=true

# Rate Limiting
RATE_LIMIT_GLOBAL_REQUESTS=1000
RATE_LIMIT_GLOBAL_WINDOW=3600
RATE_LIMIT_AUTH_REQUESTS=10
RATE_LIMIT_AUTH_WINDOW=300

# MFA Security
MFA_LOCKOUT_MAX_ATTEMPTS=5
MFA_LOCKOUT_BASE_MINUTES=15
MFA_LOCKOUT_MAX_MINUTES=1440

# CORS
CORS_ORIGINS=https://app.yourdomain.com,https://admin.yourdomain.com
CORS_ALLOW_CREDENTIALS=true

# Secret Management
SECRET_PROVIDER=vault
VAULT_URL=https://vault.yourdomain.com:8200
VAULT_TOKEN=your-vault-token

# Security Headers
CSP_ENABLED=true
CSP_REPORT_ONLY=false

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=json
SECURITY_LOG_FILE=/var/log/identity/security.log
AUDIT_LOG_FILE=/var/log/identity/audit.log
LOG_SENSITIVE_DATA=false
```

### Secret Management Setup

#### Option 1: HashiCorp Vault

```bash
# Install Vault
wget https://releases.hashicorp.com/vault/1.15.0/vault_1.15.0_linux_amd64.zip
unzip vault_1.15.0_linux_amd64.zip
sudo mv vault /usr/local/bin/

# Configure Vault
export VAULT_ADDR='https://vault.yourdomain.com:8200'
export VAULT_TOKEN='your-vault-token'

# Store secrets
vault kv put secret/identity/ENCRYPTION_KEY value="$(openssl rand -base64 32)"
vault kv put secret/identity/JWT_SIGNING_KEY value="$(openssl rand -base64 64)"
vault kv put secret/identity/DATABASE_PASSWORD value="your-db-password"
```

#### Option 2: AWS Secrets Manager

```bash
# Install AWS CLI
pip install awscli

# Configure AWS
aws configure

# Store secrets
aws secretsmanager create-secret \
    --name identity/ENCRYPTION_KEY \
    --secret-string "$(openssl rand -base64 32)" \
    --description "Identity provider encryption key"

aws secretsmanager create-secret \
    --name identity/DATABASE_PASSWORD \
    --secret-string "your-db-password" \
    --description "Identity provider database password"
```

## 🔧 Application Configuration

### Main Application File

Create `main.py`:

```python
import asyncio
from fastapi_identity_kit.app_factory import create_production_app
from fastapi_identity_kit.identity_server.router import router
from fastapi_identity_kit.identity_server.token_service import TokenService
from fastapi_identity_kit.shared_security.jwt_engine import JWTEngine

async def create_app():
    """Create production application."""
    app = await create_production_app()
    
    # Configure JWT engine
    jwt_engine = JWTEngine(
        key_manager=app.state.key_manager,
        issuer="https://identity.yourdomain.com"
    )
    
    # Configure token service
    token_service = TokenService(
        jwt_engine=jwt_engine,
        active_kid=app.state.key_manager._public_keys.keys().__iter__().__next__()
    )
    
    # Add router with dependencies
    from fastapi import Depends
    from sqlalchemy.ext.asyncio import AsyncSession
    
    async def get_db_session():
        # Your database session dependency
        pass
    
    async def get_token_service():
        return token_service
    
    async def get_key_manager():
        return app.state.key_manager
    
    async def get_current_user():
        # Your user authentication dependency
        pass
    
    async def get_client_auth_service():
        # Your client auth service dependency
        pass
    
    # Include router with dependencies
    app.include_router(
        router,
        dependencies=[
            Depends(get_db_session),
            Depends(get_token_service),
            Depends(get_key_manager),
            Depends(get_current_user),
            Depends(get_client_auth_service)
        ]
    )
    
    return app

# Create application instance
app = asyncio.run(create_app())

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        ssl_keyfile="/path/to/ssl/key.pem",
        ssl_certfile="/path/to/ssl/cert.pem",
        log_level="info"
    )
```

## 🐳 Docker Deployment

### Production Dockerfile

```dockerfile
FROM python:3.11-slim

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# Set working directory
WORKDIR /app

# Copy requirements
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Create non-root user
RUN useradd --create-home --shell /bin/bash app
RUN chown -R app:app /app
USER app

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1

# Expose port
EXPOSE 8000

# Run application
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Docker Compose

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "8000:8000"
    environment:
      - ENVIRONMENT=production
      - DATABASE_URL=postgresql+asyncpg://postgres:password@db:5432/identity?ssl=require
      - REDIS_URL=redis://:password@redis:6379/0
      - SECRET_PROVIDER=vault
      - VAULT_URL=http://vault:8200
      - VAULT_TOKEN=your-vault-token
    depends_on:
      - db
      - redis
      - vault
    volumes:
      - ./logs:/app/logs
    restart: unless-stopped

  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=identity
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./ssl:/var/lib/postgresql/ssl
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    command: redis-server --requirepass your-redis-password --tls-port 6380 --port 0 --tls-cert-file /tls/redis.crt --tls-key-file /tls/redis.key
    volumes:
      - redis_data:/data
      - ./tls:/tls
    restart: unless-stopped

  vault:
    image: vault:1.15
    environment:
      - VAULT_ADDR=http://0.0.0.0:8200
      - VAULT_TOKEN=your-vault-token
    command: vault server -config=/vault/config/vault.hcl
    volumes:
      - vault_data:/vault/file
      - ./vault/config:/vault/config
    restart: unless-stopped

volumes:
  postgres_data:
  redis_data:
  vault_data:
```

## 🔒 SSL/TLS Configuration

### Nginx Configuration

```nginx
server {
    listen 443 ssl http2;
    server_name identity.yourdomain.com;

    # SSL Configuration
    ssl_certificate /path/to/fullchain.pem;
    ssl_certificate_key /path/to/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;

    # Security Headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
    add_header X-Frame-Options DENY always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Rate Limiting
    limit_req_zone $binary_remote_addr zone=auth:10m rate=10r/m;
    limit_req_zone $binary_remote_addr zone=token:10m rate=20r/m;

    # Application Proxy
    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Apply rate limiting to auth endpoints
        location /oauth/authorize {
            limit_req zone=auth burst=5 nodelay;
            proxy_pass http://localhost:8000;
        }
        
        location /oauth/token {
            limit_req zone=token burst=10 nodelay;
            proxy_pass http://localhost:8000;
        }
    }

    # HTTP to HTTPS Redirect
    server {
        listen 80;
        server_name identity.yourdomain.com;
        return 301 https://$server_name$request_uri;
    }
}
```

## 📊 Monitoring and Logging

### Prometheus Metrics

```python
# Add to main.py
from prometheus_client import Counter, Histogram, Gauge, generate_latest

# Metrics
REQUEST_COUNT = Counter('identity_requests_total', 'Total requests', ['method', 'endpoint'])
REQUEST_DURATION = Histogram('identity_request_duration_seconds', 'Request duration')
ACTIVE_KEYS = Gauge('identity_active_keys', 'Number of active keys')
ENCRYPTION_OPERATIONS = Counter('identity_encryption_operations_total', 'Encryption operations', ['operation'])

@app.middleware("http")
async def metrics_middleware(request: Request, call_next):
    start_time = time.time()
    
    response = await call_next(request)
    
    # Record metrics
    REQUEST_COUNT.labels(method=request.method, endpoint=request.url.path).inc()
    REQUEST_DURATION.observe(time.time() - start_time)
    
    return response

@app.get("/metrics")
async def metrics():
    return Response(generate_latest(), media_type="text/plain")
```

### Log Rotation

```bash
# Configure logrotate
sudo cat > /etc/logrotate.d/identity << EOF
/var/log/identity/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 app app
    postrotate
        systemctl reload identity
    endscript
}
EOF
```

## 🔍 Security Validation

### Pre-deployment Checklist

- [ ] Environment variables configured and validated
- [ ] SSL certificates installed and valid
- [ ] Database SSL connectivity verified
- [ ] Redis authentication configured
- [ ] Secret manager accessible
- [ ] Key rotation policies configured
- [ ] Rate limiting tested
- [ ] Security headers validated
- [ ] CORS policies configured
- [ ] Monitoring endpoints accessible
- [ ] Backup procedures tested
- [ ] Incident response plan ready

### Security Testing

```bash
# Test HTTPS enforcement
curl -I http://identity.yourdomain.com/oauth/authorize
# Should return 301 redirect to HTTPS

# Test HSTS
curl -I https://identity.yourdomain.com/oauth/authorize
# Should include Strict-Transport-Security header

# Test security headers
curl -I https://identity.yourdomain.com/health
# Should include all security headers

# Test rate limiting
for i in {1..15}; do
    curl -X POST https://identity.yourdomain.com/oauth/token \
         -d "grant_type=client_credentials&client_id=test"
done
# Should return 429 after limit exceeded
```

## 🚨 Incident Response

### Security Incident Response Plan

1. **Detection**
   - Monitor security logs in real-time
   - Set up alerts for critical events
   - Use SIEM integration for correlation

2. **Containment**
   - Rotate all signing keys immediately
   - Revoke all active sessions
   - Enable enhanced monitoring

3. **Eradication**
   - Patch vulnerabilities
   - Update security configurations
   - Review access logs

4. **Recovery**
   - Restore from secure backups
   - Verify system integrity
   - Monitor for recurrence

### Emergency Procedures

```bash
# Emergency key rotation
curl -X POST https://identity.yourdomain.com/admin/emergency-rotate-keys \
     -H "Authorization: Bearer admin-token"

# Force logout all users
curl -X POST https://identity.yourdomain.com/admin/emergency-logout \
     -H "Authorization: Bearer admin-token"

# Enable maintenance mode
curl -X POST https://identity.yourdomain.com/admin/maintenance \
     -H "Authorization: Bearer admin-token"
```

## 📈 Performance Optimization

### Database Optimization

```sql
-- Create indexes for performance
CREATE INDEX CONCURRENTLY idx_authorization_codes_user_id ON authorization_codes(user_id);
CREATE INDEX CONCURRENTLY idx_authorization_codes_expires_at ON authorization_codes(expires_at);
CREATE INDEX CONCURRENTLY idx_refresh_tokens_family_id ON refresh_tokens(family_id);
CREATE INDEX CONCURRENTLY idx_refresh_tokens_session_id ON refresh_tokens(session_id);

-- Partition large tables
CREATE TABLE authorization_codes_y2024m01 PARTITION OF authorization_codes
FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');
```

### Caching Strategy

```python
# Redis caching for frequently accessed data
CACHE_KEYS = {
    'user_permissions': 'user:permissions:{user_id}:{tenant_id}',
    'client_config': 'client:config:{client_id}',
    'key_metadata': 'keys:metadata:{kid}'
}

async def get_cached_user_permissions(user_id: str, tenant_id: str):
    cache_key = CACHE_KEYS['user_permissions'].format(
        user_id=user_id, tenant_id=tenant_id
    )
    
    # Try cache first
    cached = await redis_client.get(cache_key)
    if cached:
        return json.loads(cached)
    
    # Fetch from database
    permissions = await rbac_service.get_user_permissions(user_id, tenant_id)
    
    # Cache for 5 minutes
    await redis_client.setex(cache_key, 300, json.dumps(permissions))
    
    return permissions
```

This comprehensive production deployment guide ensures your FastAPI identity provider meets enterprise security standards with full HTTPS enforcement, key rotation, encryption, and secret management capabilities.
