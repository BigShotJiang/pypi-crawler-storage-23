#!/usr/bin/env python3
"""
Security analysis script for CI/CD pipeline
"""

import json
import os
import sys

def analyze_security():
    results = {
        'high_risks': [],
        'medium_risks': [],
        'low_risks': [],
        'info_items': [],
        'status': 'pass'
    }
    
    # Analyze Bandit results
    if os.path.exists('security-gate-reports/bandit-report.json'):
        with open('security-gate-reports/bandit-report.json') as f:
            bandit = json.load(f)
            for issue in bandit.get('results', []):
                if issue.get('issue_severity') == 'HIGH':
                    results['high_risks'].append(f'Bandit: {issue["test_name"]} - {issue["issue_text"]}')
                elif issue.get('issue_severity') == 'MEDIUM':
                    results['medium_risks'].append(f'Bandit: {issue["test_name"]} - {issue["issue_text"]}')
    
    # Analyze Safety results
    if os.path.exists('security-gate-reports/safety-report.json'):
        with open('security-gate-reports/safety-report.json') as f:
            safety = json.load(f)
            for vuln in safety.get('vulnerabilities', []):
                if vuln.get('advisory', {}).get('vulnerability') == 'high':
                    results['high_risks'].append(f'Safety: {vuln["advisory"]["vulnerability"]} - {vuln["advisory"]["id"]}')
                elif vuln.get('advisory', {}).get('vulnerability') == 'medium':
                    results['medium_risks'].append(f'Safety: {vuln["advisory"]["vulnerability"]} - {vuln["advisory"]["id"]}')
    
    # Analyze Semgrep results
    if os.path.exists('security-gate-reports/semgrep-report.json'):
        with open('security-gate-reports/semgrep-report.json') as f:
            semgrep = json.load(f)
            for finding in semgrep.get('results', []):
                if 'metadata' in finding and finding['metadata'].get('impact') == 'HIGH':
                    results['high_risks'].append(f'Semgrep: {finding["message"]}')
    
    # Analyze Trivy results
    if os.path.exists('security-gate-reports/trivy-report.json'):
        with open('security-gate-reports/trivy-report.json') as f:
            trivy = json.load(f)
            for vuln in trivy.get('Results', []):
                if vuln.get('Severity') in ['HIGH', 'CRITICAL']:
                    results['high_risks'].append(f'Trivy: {vuln["Title"]}')
    
    # Determine status
    if results['high_risks']:
        results['status'] = 'fail'
    elif results['medium_risks']:
        results['status'] = 'warning'
    
    # Output results
    print(json.dumps(results, indent=2))
    
    # Exit with appropriate code
    if results['status'] == 'fail':
        sys.exit(1)
    elif results['status'] == 'warning':
        sys.exit(2)
    else:
        sys.exit(0)

if __name__ == '__main__':
    analyze_security()
