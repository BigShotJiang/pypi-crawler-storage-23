import pytest
import pytest_asyncio
import httpx
from unittest.mock import patch, AsyncMock
from typing import Dict, Any
from fastapi_identity_kit.external_providers.base import BaseOAuthProvider, NormalizedProfile, ProviderException

class DummyProvider(BaseOAuthProvider):
    name = "dummy"
    authorize_url = "https://dummy.auth.com/auth"
    token_url = "https://dummy.auth.com/token"
    userinfo_url = "https://dummy.auth.com/userinfo"
    default_scopes = ["scope1", "scope2"]

    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        return NormalizedProfile(
            id=str(data.get("sub", "")),
            email=data.get("email", ""),
            name=data.get("name")
        )

def test_get_authorization_url():
    provider = DummyProvider("client123", "secret123", "https://app.com/callback")
    url = provider.get_authorization_url(
        state="state123",
        code_challenge="challenge123",
        nonce="nonce123"
    )
    assert "https://dummy.auth.com/auth" in url
    assert "client_id=client123" in url
    assert "redirect_uri=https%3A%2F%2Fapp.com%2Fcallback" in url
    assert "state=state123" in url
    assert "code_challenge=challenge123" in url
    assert "code_challenge_method=S256" in url
    assert "nonce=nonce123" in url
    assert "scope=scope1+scope2" in url

@pytest.mark.asyncio
async def test_exchange_code():
    provider = DummyProvider("client123", "secret123", "https://app.com/callback")
    
    mock_resp = AsyncMock() # This acts as Response
    mock_resp.status_code = 200
    mock_resp.json = lambda: {"access_token": "token123", "token_type": "Bearer"}
    mock_resp.text = '{"access_token": "token123", "token_type": "Bearer"}'
    
    with patch("httpx.AsyncClient.post", return_value=mock_resp) as mock_post:
        result = await provider.exchange_code("code123", "verifier123")
        assert result["access_token"] == "token123"
        mock_post.assert_called_once()
        
        # Check payload
        call_args = mock_post.call_args
        assert call_args[1]["data"]["code"] == "code123"
        assert call_args[1]["data"]["code_verifier"] == "verifier123"
        assert call_args[1]["data"]["client_secret"] == "secret123"

@pytest.mark.asyncio
async def test_exchange_code_failure():
    provider = DummyProvider("client123", "secret123", "https://app.com/callback")
    
    mock_resp = AsyncMock()
    mock_resp.status_code = 400
    mock_resp.text = "invalid_grant"
    
    with patch("httpx.AsyncClient.post", return_value=mock_resp):
        with pytest.raises(ProviderException, match="Token exchange failed: invalid_grant"):
            await provider.exchange_code("bad_code", "verifier123")

@pytest.mark.asyncio
async def test_fetch_user_info():
    provider = DummyProvider("client123", "secret123", "https://app.com/callback")
    
    mock_resp = AsyncMock()
    mock_resp.status_code = 200
    mock_resp.json = lambda: {"sub": "123", "email": "test@test.com", "name": "Test User"}
    
    with patch("httpx.AsyncClient.get", return_value=mock_resp) as mock_get:
        data = await provider.fetch_user_info("token123")
        assert data["sub"] == "123"
        
        # Check normalization
        profile = provider.normalize_profile(data)
        assert profile.id == "123"
        assert profile.email == "test@test.com"
        assert profile.name == "Test User"
        assert profile.email_verified is False
