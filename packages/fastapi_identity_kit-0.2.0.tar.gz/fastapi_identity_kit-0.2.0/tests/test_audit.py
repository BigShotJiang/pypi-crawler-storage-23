import json
import logging
import pytest
import pytest_asyncio
import uuid
import hashlib
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from fastapi_identity_kit.identity_core.models import Base, User
from fastapi_identity_kit.audit.models import AuditEvent
from fastapi_identity_kit.audit.service import AuditService
from fastapi_identity_kit.audit.logger import SIEMJsonFormatter

TEST_DB_URL = "sqlite+aiosqlite:///:memory:"

@pytest_asyncio.fixture
async def async_session():
    engine = create_async_engine(TEST_DB_URL, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        
    async_session_maker = async_sessionmaker(engine, expire_on_commit=False)
    async with async_session_maker() as session:
        yield session

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


def test_siem_json_formatter():
    formatter = SIEMJsonFormatter()
    record = logging.LogRecord(
        name="test_logger",
        level=logging.INFO,
        pathname="path.py",
        lineno=10,
        msg="Test event",
        args=(),
        exc_info=None
    )
    
    # Inject our contextual payload matching standard Python log execution
    setattr(record, "audit_context", {"audit_event": {"category": "AUTH", "action": "TEST"}})
    
    output = formatter.format(record)
    parsed = json.loads(output)
    
    assert "timestamp" in parsed
    assert parsed["level"] == "INFO"
    assert parsed["logger"] == "test_logger"
    assert parsed["message"] == "Test event"
    assert "audit_event" in parsed
    assert parsed["audit_event"]["category"] == "AUTH"


@pytest.mark.asyncio
async def test_audit_service_chaining(async_session: AsyncSession):
    audit_svc = AuditService()
    
    # Emulate routing standard out away so we don't spam test console
    audit_svc.logger.setLevel(logging.CRITICAL + 10)
    
    user_id = uuid.uuid4()
    
    # Event 1
    event_1 = await audit_svc.log_event(
        db_session=async_session,
        category="AUTH",
        action="LOGIN_SUCCESS",
        actor_id=user_id,
        ip_address="192.168.1.1",
        payload={"method": "password"}
    )
    await async_session.commit()
    
    assert event_1.signature is not None
    assert event_1.signature != "GENESIS"
    
    sig_1 = event_1.signature

    # Event 2
    payload_2 = {"granted_role": "Admin"}
    event_2 = await audit_svc.log_event(
        db_session=async_session,
        category="POLICY",
        action="ROLE_GRANTED",
        actor_id=user_id,
        target_id=str(uuid.uuid4()),
        payload=payload_2
    )
    await async_session.commit()
    
    sig_2 = event_2.signature
    assert sig_1 != sig_2
    
    # Manually reproduce signature calculation logic from Event 2 to prove chain works
    payload_str = json.dumps(payload_2, sort_keys=True)
    hash_test = hashlib.sha256(f"{sig_1}|{payload_str}".encode()).hexdigest()
    
    assert hash_test == sig_2
