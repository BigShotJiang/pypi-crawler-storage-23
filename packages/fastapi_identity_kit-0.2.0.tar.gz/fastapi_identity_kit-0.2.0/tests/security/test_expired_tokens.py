import pytest
import asyncio
import aiohttp
import json
import time
import jwt
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List

class ExpiredTokenTests:
    """Comprehensive tests for expired token handling and edge cases."""
    
    BASE_URL = "http://localhost:8000"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_expired_access_token(self):
        """Test behavior with expired access tokens."""
        
        async with aiohttp.ClientSession() as session:
            # Create expired access token
            expired_time = datetime.now(timezone.utc) - timedelta(hours=1)
            payload = {
                "sub": "test-user",
                "exp": int(expired_time.timestamp()),
                "iat": int(expired_time.timestamp()),
                "iss": "https://identity.example.com",
                "aud": "test-client"
            }
            
            # Sign with test key
            expired_token = jwt.encode(payload, algorithm="RS256", key="test-key")
            
            headers = {"Authorization": f"Bearer {expired_token}"}
            
            async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp:
                # Should reject expired token
                assert resp.status == 401, "Expired access token should be rejected"
                
                # Check error response
                error_data = await resp.json()
                assert "error" in error_data, "Should return error object"
                assert error_data["error"] in ["invalid_token", "token_expired"], "Should return token expired error"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_expired_refresh_token(self):
        """Test behavior with expired refresh tokens."""
        
        async with aiohttp.ClientSession() as session:
            # Create expired refresh token (simulated)
            expired_refresh_token = "expired_refresh_token_12345"
            
            data = {
                "grant_type": "refresh_token",
                "refresh_token": expired_refresh_token,
                "client_id": "test-client"
            }
            
            async with session.post(f"{self.BASE_URL}/oauth/token", data=data) as resp:
                # Should reject expired refresh token
                assert resp.status == 400, "Expired refresh token should be rejected"
                
                error_data = await resp.json()
                assert "error" in error_data, "Should return error object"
                assert error_data["error"] in ["invalid_grant", "invalid_token"], "Should return invalid grant error"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_not_yet_valid_token(self):
        """Test token with future issued time (nbf)."""
        
        async with aiohttp.ClientSession() as session:
            # Create token valid in future
            future_time = datetime.now(timezone.utc) + timedelta(hours=1)
            payload = {
                "sub": "test-user",
                "exp": int((future_time + timedelta(hours=1)).timestamp()),
                "nbf": int(future_time.timestamp()),
                "iat": int(future_time.timestamp()),
                "iss": "https://identity.example.com",
                "aud": "test-client"
            }
            
            future_token = jwt.encode(payload, algorithm="RS256", key="test-key")
            
            headers = {"Authorization": f"Bearer {future_token}"}
            
            async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp:
                # Should reject token not yet valid
                assert resp.status == 401, "Future valid token should be rejected"
                
                error_data = await resp.json()
                assert "error" in error_data, "Should return error object"
                assert error_data["error"] in ["invalid_token", "token_not_yet_valid"], "Should return not yet valid error"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_token_clock_skew(self):
        """Test token validation with clock skew scenarios."""
        
        async with aiohttp.ClientSession() as session:
            # Test tokens with small clock skew tolerance
            skew_time = datetime.now(timezone.utc) - timedelta(seconds=30)  # 30 seconds ago
            payload = {
                "sub": "test-user",
                "exp": int((datetime.now(timezone.utc) + timedelta(minutes=14)).timestamp()),  # 14 minutes from now
                "iat": int(skew_time.timestamp()),
                "iss": "https://identity.example.com",
                "aud": "test-client"
            }
            
            skewed_token = jwt.encode(payload, algorithm="RS256", key="test-key")
            
            headers = {"Authorization": f"Bearer {skewed_token}"}
            
            async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp:
                # Should handle clock skew appropriately
                # Most systems allow some skew (usually 1-5 minutes)
                # 30 seconds should be acceptable, but implementation-dependent
                assert resp.status in [200, 401], f"Clock skew handling: {resp.status}"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_expiration_edge_cases(self):
        """Test various token expiration edge cases."""
        
        async with aiohttp.ClientSession() as session:
            edge_cases = [
                # Token expiring exactly now
                {
                    "name": "expiring_now",
                    "exp": int(datetime.now(timezone.utc).timestamp()),
                    "should_reject": True
                },
                # Token expiring in 1 second
                {
                    "name": "expiring_soon",
                    "exp": int((datetime.now(timezone.utc) + timedelta(seconds=1)).timestamp()),
                    "should_reject": False  # Should still be valid
                },
                # Token with very large exp (far future)
                {
                    "name": "far_future",
                    "exp": 9999999999,  # Year 2286
                    "should_reject": True
                },
                # Token with negative exp
                {
                    "name": "negative_exp",
                    "exp": -1,
                    "should_reject": True
                },
                # Token with zero exp
                {
                    "name": "zero_exp",
                    "exp": 0,
                    "should_reject": True
                },
                # Token with exp as string (invalid)
                {
                    "name": "string_exp",
                    "exp": "invalid",
                    "should_reject": True
                }
            ]
            
            for case in edge_cases:
                payload = {
                    "sub": "test-user",
                    "iat": int(datetime.now(timezone.utc).timestamp()),
                    "iss": "https://identity.example.com",
                    "aud": "test-client"
                }
                payload["exp"] = case["exp"]
                
                try:
                    token = jwt.encode(payload, algorithm="RS256", key="test-key")
                    headers = {"Authorization": f"Bearer {token}"}
                    
                    async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp:
                        if case["should_reject"]:
                            assert resp.status == 401, f"Edge case {case['name']} should be rejected"
                        else:
                            assert resp.status in [200, 401], f"Edge case {case['name']} handling: {resp.status}"
                            
                except Exception:
                    # Invalid tokens should fail encoding
                    assert case["should_reject"], f"Edge case {case['name']} should fail encoding"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_authorization_code_expiration(self):
        """Test expired authorization codes."""
        
        async with aiohttp.ClientSession() as session:
            # Simulate expired authorization code
            expired_code = "expired_auth_code_12345"
            
            data = {
                "grant_type": "authorization_code",
                "code": expired_code,
                "redirect_uri": "https://client.example.com/callback",
                "client_id": "test-client",
                "code_verifier": "test_verifier_1234567890123456789012345678901234567890123456789012"  # Valid PKCE verifier
            }
            
            async with session.post(f"{self.BASE_URL}/oauth/token", data=data) as resp:
                # Should reject expired authorization code
                assert resp.status == 400, "Expired authorization code should be rejected"
                
                error_data = await resp.json()
                assert "error" in error_data, "Should return error object"
                assert error_data["error"] in ["invalid_grant", "invalid_code"], "Should return invalid grant error"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_session_expiration(self):
        """Test expired user sessions."""
        
        async with aiohttp.ClientSession() as session:
            # Test with expired session cookie
            expired_session = "expired_session_12345"
            
            headers = {"Cookie": f"session_id={expired_session}"}
            
            async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp:
                # Should reject expired session
                assert resp.status in [401, 403], "Expired session should be rejected"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_token_replay_after_expiration(self):
        """Test replay attacks with expired tokens."""
        
        async with aiohttp.ClientSession() as session:
            # Create token that expired 5 minutes ago
            expired_time = datetime.now(timezone.utc) - timedelta(minutes=5)
            payload = {
                "sub": "test-user",
                "exp": int(expired_time.timestamp()),
                "iat": int(expired_time.timestamp()),
                "iss": "https://identity.example.com",
                "aud": "test-client"
            }
            
            expired_token = jwt.encode(payload, algorithm="RS256", key="test-key")
            headers = {"Authorization": f"Bearer {expired_token}"}
            
            # First request
            async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp1:
                assert resp1.status == 401, "First request with expired token should be rejected"
            
            # Second request (replay attempt)
            async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp2:
                assert resp2.status == 401, "Replay of expired token should be rejected"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_concurrent_expiration_handling(self):
        """Test concurrent requests with expiring tokens."""
        
        async with aiohttp.ClientSession() as session:
            # Create token that expires in 10 seconds
            expire_time = datetime.now(timezone.utc) + timedelta(seconds=10)
            payload = {
                "sub": "test-user",
                "exp": int(expire_time.timestamp()),
                "iat": int(datetime.now(timezone.utc).timestamp()),
                "iss": "https://identity.example.com",
                "aud": "test-client"
            }
            
            soon_to_expire_token = jwt.encode(payload, algorithm="RS256", key="test-key")
            headers = {"Authorization": f"Bearer {soon_to_expire_token}"}
            
            # Make concurrent requests
            tasks = []
            for i in range(5):
                task = session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers)
                tasks.append(task)
            
            # Wait for token to expire
            await asyncio.sleep(12)
            
            # Execute all requests concurrently
            responses = await asyncio.gather(*tasks, return_exceptions=True)
            
            # All should be rejected after expiration
            for i, resp in enumerate(responses):
                if not isinstance(resp, Exception):
                    assert resp.status == 401, f"Concurrent request {i} after expiration should be rejected"

class TokenExpirationMonitoring:
    """Monitor token expiration behavior and edge cases."""
    
    def __init__(self):
        self.expiration_test_results = []
    
    async def run_expiration_tests(self):
        """Run comprehensive expiration tests."""
        test_methods = [
            self.test_access_token_expiration,
            self.test_refresh_token_expiration,
            self.test_boundary_conditions,
            self.test_implementation_edge_cases
        ]
        
        for method in test_methods:
            try:
                await method()
            except Exception as e:
                self.expiration_test_results.append({
                    "test": method.__name__,
                    "status": "error",
                    "error": str(e)
                })
    
    async def test_access_token_expiration(self):
        """Test various access token expiration scenarios."""
        scenarios = [
            {"name": "expired_1min", "offset": -60, "expected": "reject"},
            {"name": "expired_1sec", "offset": -1, "expected": "reject"},
            {"name": "expires_1sec", "offset": 1, "expected": "accept"},
            {"name": "expires_30sec", "offset": 30, "expected": "accept"},
        ]
        
        for scenario in scenarios:
            result = await self._test_token_expiration_scenario(scenario)
            self.expiration_test_results.append(result)
    
    async def test_refresh_token_expiration(self):
        """Test refresh token expiration handling."""
        scenarios = [
            {"name": "refresh_expired", "age_hours": 25, "expected": "reject"},
            {"name": "refresh_valid", "age_hours": 1, "expected": "accept"},
            {"name": "refresh_boundary", "age_hours": 30, "expected": "reject"},
        ]
        
        for scenario in scenarios:
            result = await self._test_refresh_token_scenario(scenario)
            self.expiration_test_results.append(result)
    
    async def test_boundary_conditions(self):
        """Test boundary conditions for token expiration."""
        boundary_tests = [
            {"name": "exp_zero", "exp": 0, "expected": "reject"},
            {"name": "exp_negative", "exp": -1, "expected": "reject"},
            {"name": "exp_max_int", "exp": 2**31-1, "expected": "reject"},
            {"name": "no_exp_claim", "exp": None, "expected": "reject"},
        ]
        
        for test in boundary_tests:
            result = await self._test_boundary_condition(test)
            self.expiration_test_results.append(result)
    
    async def test_implementation_edge_cases(self):
        """Test implementation-specific edge cases."""
        edge_cases = [
            {"name": "malformed_jwt", "token": "invalid.jwt.token", "expected": "reject"},
            {"name": "empty_token", "token": "", "expected": "reject"},
            {"name": "none_token", "token": None, "expected": "reject"},
            {"name": "b64_only", "token": "eyJhbGciOiJSUzI1NiIs", "expected": "reject"},
        ]
        
        for case in edge_cases:
            result = await self._test_implementation_edge_case(case)
            self.expiration_test_results.append(result)
    
    async def _test_token_expiration_scenario(self, scenario):
        """Test a specific token expiration scenario."""
        # Implementation would depend on your test setup
        return {"scenario": scenario["name"], "status": "tested"}
    
    async def _test_refresh_token_scenario(self, scenario):
        """Test a specific refresh token scenario."""
        # Implementation would depend on your test setup
        return {"scenario": scenario["name"], "status": "tested"}
    
    async def _test_boundary_condition(self, test):
        """Test a boundary condition."""
        # Implementation would depend on your test setup
        return {"test": test["name"], "status": "tested"}
    
    async def _test_implementation_edge_case(self, case):
        """Test an implementation edge case."""
        # Implementation would depend on your test setup
        return {"test": case["name"], "status": "tested"}

if __name__ == "__main__":
    # Run standalone expiration tests
    monitor = TokenExpirationMonitoring()
    asyncio.run(monitor.run_expiration_tests())
