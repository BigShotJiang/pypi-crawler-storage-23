import pytest
import asyncio
import aiohttp
import json
import time
from hypothesis import given, strategies as st
from typing import Dict, Any
import jwt
import secrets
import string

class TokenFuzzingTests:
    """Comprehensive token fuzzing tests to identify JWT vulnerabilities."""
    
    BASE_URL = "http://localhost:8000"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_jwt_algorithm_fuzzing(self):
        """Test JWT algorithm confusion attacks."""
        
        async with aiohttp.ClientSession() as session:
            # Test invalid algorithms
            invalid_algorithms = ["none", "HS256", "HS384", "HS512"]
            
            for algorithm in invalid_algorithms:
                # Create malicious JWT with none algorithm
                if algorithm == "none":
                    payload = {"sub": "test-user", "exp": int(time.time()) + 3600}
                    malicious_token = jwt.encode(payload, algorithm="none", headers={"alg": "none"})
                else:
                    # Create JWT with HMAC algorithm (should be rejected)
                    payload = {"sub": "test-user", "exp": int(time.time()) + 3600}
                    secret_key = "fake-secret-key"
                    malicious_token = jwt.encode(payload, secret_key, algorithm=algorithm)
                
                # Test token acceptance
                headers = {"Authorization": f"Bearer {malicious_token}"}
                
                async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp:
                    # Should reject invalid algorithms
                    assert resp.status in [401, 403], f"Algorithm {algorithm} should be rejected"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_jwt_payload_manipulation(self):
        """Test JWT payload manipulation attacks."""
        
        async with aiohttp.ClientSession() as session:
            # Create valid token first
            valid_payload = {
                "sub": "test-user",
                "exp": int(time.time()) + 3600,
                "iat": int(time.time()),
                "iss": "https://identity.example.com"
            }
            
            # Test with manipulated claims
            manipulations = [
                {"sub": "admin"},  # Privilege escalation
                {"exp": 9999999999},  # Never expires
                {"iat": 0},  # Invalid issued time
                {"iss": "malicious-issuer"},  # Wrong issuer
                {"aud": "different-client"},  # Wrong audience
                {"scope": "admin read write delete"},  # Elevated scope
            ]
            
            for manipulation in manipulations:
                payload = valid_payload.copy()
                payload.update(manipulation)
                
                # Create token with RSA key (this would be signed with test key)
                # In real test, you'd use the actual server's public key to create valid tokens
                test_token = jwt.encode(payload, algorithm="RS256", key="test-key")
                
                headers = {"Authorization": f"Bearer {test_token}"}
                
                async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp:
                    # Should reject manipulated claims
                    assert resp.status in [401, 403], f"Manipulated payload should be rejected: {manipulation}"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_jwt_header_manipulation(self):
        """Test JWT header manipulation attacks."""
        
        async with aiohttp.ClientSession() as session:
            # Test missing kid
            payload = {"sub": "test-user", "exp": int(time.time()) + 3600}
            token_no_kid = jwt.encode(payload, algorithm="RS256", key="test-key", headers={"alg": "RS256"})
            
            # Test invalid kid
            token_invalid_kid = jwt.encode(payload, algorithm="RS256", key="test-key", headers={"alg": "RS256", "kid": "invalid-kid"})
            
            # Test multiple algorithms
            token_multiple_alg = jwt.encode(payload, algorithm="RS256", key="test-key", headers={"alg": "RS256", "alg": "none"})
            
            test_tokens = [
                ("no-kid", token_no_kid),
                ("invalid-kid", token_invalid_kid),
                ("multiple-alg", token_multiple_alg)
            ]
            
            for test_name, token in test_tokens:
                headers = {"Authorization": f"Bearer {token}"}
                
                async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp:
                    # Should reject header manipulation
                    assert resp.status in [401, 403], f"Header manipulation {test_name} should be rejected"
    
    @given(st.text(min_size=1, max_size=1000))
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_jwt_token_injection(self, token_string):
        """Test JWT token injection attacks using property-based testing."""
        
        async with aiohttp.ClientSession() as session:
            # Test various injection payloads
            injection_payloads = [
                token_string,  # Raw injection
                f"{token_string}.admin",  # Path traversal
                f"{token_string}../../etc/passwd",  # File inclusion
                f"<script>alert('xss')</script>",  # XSS
                f"' OR '1'='1",  # SQL injection
                "{{7*7}}",  # Template injection
                f"{token_string}\x00",  # Null byte injection
            ]
            
            for payload in injection_payloads:
                headers = {"Authorization": f"Bearer {payload}"}
                
                async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp:
                    # Should reject injection attempts
                    assert resp.status in [400, 401, 403], f"Injection payload should be rejected"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_jwt_timing_attacks(self):
        """Test JWT timing attacks."""
        
        async with aiohttp.ClientSession() as session:
            # Create tokens with slight variations to test timing
            base_payload = {"sub": "test-user", "exp": int(time.time()) + 3600}
            
            # Test multiple similar tokens
            tokens = []
            for i in range(10):
                payload = base_payload.copy()
                payload["jti"] = f"test-{i}"  # JWT ID
                token = jwt.encode(payload, algorithm="RS256", key="test-key")
                tokens.append(token)
            
            # Send requests concurrently to test timing differences
            tasks = []
            for token in tokens:
                headers = {"Authorization": f"Bearer {token}"}
                task = session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers)
                tasks.append(task)
            
            # Measure response times
            start_time = time.time()
            responses = await asyncio.gather(*tasks, return_exceptions=True)
            end_time = time.time()
            
            # Analyze timing patterns
            response_times = []
            for i, resp in enumerate(responses):
                if not isinstance(resp, Exception):
                    response_times.append(end_time - start_time)
            
            # Check for significant timing differences (potential side-channel)
            if len(response_times) > 1:
                avg_time = sum(response_times) / len(response_times)
                for i, resp_time in enumerate(response_times):
                    deviation = abs(resp_time - avg_time)
                    # Allow some variance but flag large differences
                    assert deviation < 0.1, f"Significant timing difference detected for token {i}"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_jwt_unicode_attacks(self):
        """Test Unicode and encoding attacks on JWT."""
        
        async with aiohttp.ClientSession() as session:
            # Test various Unicode payloads
            unicode_payloads = [
                {"sub": "test\u0000user"},  # Null byte injection
                {"sub": "test\ufeffuser"},  # BOM injection
                {"sub": "test\ud83d\ude00user"},  # RTL override
                {"sub": "test\u202euser"},  # Overlong encoding
                {"sub": "test%75%73%74user"},  # URL encoding
            ]
            
            for payload in unicode_payloads:
                token = jwt.encode(payload, algorithm="RS256", key="test-key")
                headers = {"Authorization": f"Bearer {token}"}
                
                async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp:
                    # Should handle Unicode safely
                    assert resp.status in [200, 401, 400], f"Unicode payload handling: {resp.status}"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_jwt_algorithm_confusion(self):
        """Test JWT algorithm confusion attacks."""
        
        async with aiohttp.ClientSession() as session:
            # Create token with RSA key but claim HMAC algorithm
            payload = {"sub": "test-user", "exp": int(time.time()) + 3600}
            
            # Sign with RSA but claim HMAC
            rsa_token = jwt.encode(payload, algorithm="RS256", key="test-rsa-key")
            
            # Modify header to claim HMAC algorithm
            try:
                # Decode to modify header
                decoded = jwt.decode(rsa_token, options={"verify_signature": False})
                header = jwt.get_unverified_header(rsa_token)
                
                # Change algorithm to HMAC
                malicious_header = header.copy()
                malicious_header["alg"] = "HS256"
                
                # Re-encode with malicious header
                parts = rsa_token.split('.')
                malicious_token = f"{parts[0]}.{parts[1]}.{parts[2]}"  # Keep original signature
                
                headers = {"Authorization": f"Bearer {malicious_token}"}
                
                async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp:
                    # Should reject algorithm confusion
                    assert resp.status in [401, 403], "Algorithm confusion attack should be rejected"
                    
            except Exception:
                # If token manipulation fails, that's also good
                pass
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_jwt_key_substitution(self):
        """Test JWT key substitution attacks."""
        
        async with aiohttp.ClientSession() as session:
            # Test with different key sizes and types
            key_tests = [
                ("weak-rsa-512", 512),  # Weak RSA key
                ("weak-rsa-1024", 1024),  # Weak RSA key
                ("ec-p256", "P-256"),  # Different curve
                ("ec-p384", "P-384"),  # Different curve
            ]
            
            for key_name, key_param in key_tests:
                try:
                    if isinstance(key_param, int):
                        # RSA key with specified bits
                        from cryptography.hazmat.primitives.asymmetric import rsa
                        private_key = rsa.generate_private_key(
                            public_exponent=65537,
                            key_size=key_param,
                        )
                    else:
                        # EC key with specified curve
                        from cryptography.hazmat.primitives.asymmetric import ec
                        curves = {"P-256": ec.SECP256R1(), "P-384": ec.SECP384R1()}
                        private_key = ec.generate_private_key(curves[key_param])
                    
                    payload = {"sub": "test-user", "exp": int(time.time()) + 3600}
                    token = jwt.encode(payload, private_key, algorithm="RS256")
                    
                    headers = {"Authorization": f"Bearer {token}"}
                    
                    async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers) as resp:
                        # Should handle different key types appropriately
                        assert resp.status in [200, 401, 403], f"Key type {key_name} handling: {resp.status}"
                        
                except Exception as e:
                    # Key generation failures are expected for some configurations
                    pass

class TokenEntropyAnalysis:
    """Analyze token entropy and randomness."""
    
    def test_token_entropy(self, token: str) -> Dict[str, Any]:
        """Analyze the entropy of a JWT token."""
        try:
            # Get the signature part
            parts = token.split('.')
            if len(parts) != 3:
                return {"error": "Invalid JWT format"}
            
            signature = parts[2]
            
            # Calculate entropy
            import math
            from collections import Counter
            
            # Character frequency analysis
            char_counts = Counter(signature)
            entropy = 0
            for count in char_counts.values():
                probability = count / len(signature)
                entropy -= probability * math.log2(probability)
            
            # Check for patterns
            has_repeating_patterns = len(set(signature)) < len(signature) * 0.8
            
            # Check for common weak patterns
            weak_patterns = ["AAAA", "////", "0000", "1111"]
            has_weak_patterns = any(pattern in signature for pattern in weak_patterns)
            
            return {
                "token_length": len(token),
                "signature_length": len(signature),
                "entropy": entropy,
                "max_entropy": len(signature) * math.log2(256),  # Maximum possible entropy
                "entropy_ratio": entropy / (len(signature) * math.log2(256)),
                "has_repeating_patterns": has_repeating_patterns,
                "has_weak_patterns": has_weak_patterns,
                "is_weak": entropy < 3.0 or has_weak_patterns
            }
            
        except Exception as e:
            return {"error": f"Analysis failed: {e}"}

@pytest.mark.security
def test_token_entropy_analysis():
    """Test token entropy analysis."""
    
    # Test with various token types
    test_tokens = [
        # High entropy token (good)
        "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiZXhwIjoxNzA0MDAwMDAsImlhdCI6MTcwNDAwMDAwMCwiaXNzIjoiaHR0cHM6Ly9pZGVudGl0eS5leGFtcGxlLmNvbSIsImF1ZCI6ImNsaWVudCJ9.fQ",
        
        # Low entropy token (bad)
        "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiZXhwIjoxNzA0MDAwMDAsImlhdCI6MTcwNDAwMDAwMCwiaXNzIjoiaHR0cHM6Ly9pZGVudGl0eS5leGFtcGxlLmNvbSIsImF1ZCI6ImNsaWVudCJ9.AAAA",
        
        # Repeating pattern token (bad)
        "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiZXhwIjoxNzA0MDAwMDAsImlhdCI6MTcwNDAwMDAwMCwiaXNzIjoiaHR0cHM6Ly9pZGVudGl0eS5leGFtcGxlLmNvbSIsImF1ZCI6ImNsaWVudCJ9.//////////////////////",
    ]
    
    analyzer = TokenEntropyAnalysis()
    
    for i, token in enumerate(test_tokens):
        result = analyzer.test_token_entropy(token)
        
        if i == 0:  # High entropy token
            assert result["entropy_ratio"] > 0.7, "High entropy token should have good entropy ratio"
            assert not result["is_weak"], "High entropy token should not be weak"
        else:  # Low entropy tokens
            assert result["entropy_ratio"] < 0.5, "Low entropy token should have poor entropy ratio"
            assert result["is_weak"], "Low entropy token should be detected as weak"

if __name__ == "__main__":
    # Run standalone entropy analysis
    import sys
    if len(sys.argv) > 1:
        analyzer = TokenEntropyAnalysis()
        result = analyzer.test_token_entropy(sys.argv[1])
        print(json.dumps(result, indent=2))
