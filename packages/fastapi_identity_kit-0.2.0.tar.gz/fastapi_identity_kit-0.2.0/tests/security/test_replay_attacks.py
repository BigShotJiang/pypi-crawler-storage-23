import pytest
import asyncio
import aiohttp
import json
import time
import jwt
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List
import hashlib
import secrets

class ReplayAttackTests:
    """Comprehensive tests for replay attack prevention."""
    
    BASE_URL = "http://localhost:8000"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_refresh_token_replay_attack(self):
        """Test refresh token replay attack prevention."""
        
        async with aiohttp.ClientSession() as session:
            # First, obtain a valid refresh token
            # In a real test, you'd go through the full OAuth2 flow
            # For this test, we'll simulate a valid refresh token
            valid_refresh_token = "valid_refresh_token_12345"
            
            # Use the refresh token first time
            data = {
                "grant_type": "refresh_token",
                "refresh_token": valid_refresh_token,
                "client_id": "test-client"
            }
            
            async with session.post(f"{self.BASE_URL}/oauth/token", data=data) as resp1:
                assert resp1.status == 200, "First refresh token use should succeed"
                token_data = await resp1.json()
                new_refresh_token = token_data.get("refresh_token")
            
            # Try to use the same refresh token again (replay attack)
            data["refresh_token"] = valid_refresh_token
            
            async with session.post(f"{self.BASE_URL}/oauth/token", data=data) as resp2:
                # Should reject replayed refresh token
                assert resp2.status == 400, "Replayed refresh token should be rejected"
                
                error_data = await resp2.json()
                assert "error" in error_data, "Should return error object"
                assert error_data["error"] in ["invalid_grant", "replay_detected"], "Should return replay error"
            
            # Try with the new refresh token (should work)
            data["refresh_token"] = new_refresh_token
            
            async with session.post(f"{self.BASE_URL}/oauth/token", data=data) as resp3:
                assert resp3.status == 200, "New refresh token should work"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_authorization_code_replay_attack(self):
        """Test authorization code replay attack prevention."""
        
        async with aiohttp.ClientSession() as session:
            # Simulate a valid authorization code
            valid_auth_code = "valid_auth_code_12345"
            
            # Use the authorization code first time
            data = {
                "grant_type": "authorization_code",
                "code": valid_auth_code,
                "redirect_uri": "https://client.example.com/callback",
                "client_id": "test-client",
                "code_verifier": "test_verifier_1234567890123456789012345678901234567890123456789012"
            }
            
            async with session.post(f"{self.BASE_URL}/oauth/token", data=data) as resp1:
                # First use should succeed (if code exists in database)
                # In real implementation, this would be rejected if code doesn't exist
                pass
            
            # Try to use the same authorization code again (replay attack)
            async with session.post(f"{self.BASE_URL}/oauth/token", data=data) as resp2:
                # Should reject replayed authorization code
                assert resp2.status == 400, "Replayed authorization code should be rejected"
                
                error_data = await resp2.json()
                assert "error" in error_data, "Should return error object"
                assert error_data["error"] in ["invalid_grant", "invalid_code"], "Should return invalid code error"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_concurrent_refresh_token_replay(self):
        """Test concurrent replay attacks on refresh tokens."""
        
        async with aiohttp.ClientSession() as session:
            valid_refresh_token = "valid_concurrent_token_12345"
            
            # Create multiple concurrent requests with the same refresh token
            data = {
                "grant_type": "refresh_token",
                "refresh_token": valid_refresh_token,
                "client_id": "test-client"
            }
            
            # Make 5 concurrent requests
            tasks = []
            for i in range(5):
                task = session.post(f"{self.BASE_URL}/oauth/token", data=data)
                tasks.append(task)
            
            responses = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Analyze responses
            success_count = 0
            rejection_count = 0
            
            for resp in responses:
                if isinstance(resp, Exception):
                    rejection_count += 1
                elif resp.status == 200:
                    success_count += 1
                else:
                    rejection_count += 1
            
            # At most one should succeed due to replay protection
            assert success_count <= 1, f"Concurrent replay: at most one request should succeed, got {success_count}"
            assert rejection_count >= 4, f"Concurrent replay: at least 4 should be rejected, got {rejection_count}"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_timing_based_replay_attack(self):
        """Test timing-based replay attack detection."""
        
        async with aiohttp.ClientSession() as session:
            valid_refresh_token = "valid_timing_token_12345"
            
            # Make two requests with the same token
            data = {
                "grant_type": "refresh_token",
                "refresh_token": valid_refresh_token,
                "client_id": "test-client"
            }
            
            # First request
            start_time1 = time.time()
            async with session.post(f"{self.BASE_URL}/oauth/token", data=data) as resp1:
                end_time1 = time.time()
                response1 = await resp1.json() if resp1.status == 200 else None
            
            # Second request (very close timing)
            await asyncio.sleep(0.01)  # 10ms delay
            start_time2 = time.time()
            async with session.post(f"{self.BASE_URL}/oauth/token", data=data) as resp2:
                end_time2 = time.time()
                response2 = await resp2.json() if resp2.status == 200 else None
            
            # Analyze timing and responses
            time_diff = abs(start_time2 - start_time1)
            
            if resp1.status == 200 and resp2.status == 400:
                # Expected behavior: first succeeds, second rejected
                assert time_diff < 1.0, "Second request should be made quickly"
            elif resp1.status == 400 and resp2.status == 400:
                # Both rejected - good replay protection
                pass
            else:
                # Any other behavior needs investigation
                pytest.fail(f"Unexpected replay protection behavior: {resp1.status}, {resp2.status}")
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_cross_client_replay_attack(self):
        """Test replay attack across different clients."""
        
        async with aiohttp.ClientSession() as session:
            # Get token for client A
            data_client_a = {
                "grant_type": "client_credentials",
                "client_id": "client-a",
                "client_secret": "secret-a"
            }
            
            async with session.post(f"{self.BASE_URL}/oauth/token", data=data_client_a) as resp_a:
                if resp_a.status == 200:
                    token_data = await resp_a.json()
                    access_token = token_data.get("access_token")
                    
                    # Try to use the same token with client B
                    headers = {"Authorization": f"Bearer {access_token}"}
                    data_client_b = {
                        "grant_type": "client_credentials",
                        "client_id": "client-b",
                        "client_secret": "secret-b"
                    }
                    
                    async with session.post(f"{self.BASE_URL}/oauth/token", data=data_client_b) as resp_b:
                        # Should reject cross-client token usage
                        assert resp_b.status in [401, 403], "Cross-client token reuse should be rejected"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_session_replay_attack(self):
        """Test session replay attack prevention."""
        
        async with aiohttp.ClientSession() as session:
            # Simulate a valid session ID
            valid_session_id = "valid_session_12345"
            
            # Make request with valid session
            headers1 = {"Cookie": f"session_id={valid_session_id}"}
            
            async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers1) as resp1:
                # First request might succeed
                pass
            
            # Try to use the same session ID from different IP
            headers2 = {
                "Cookie": f"session_id={valid_session_id}",
                "X-Forwarded-For": "192.168.1.100"  # Different IP
            }
            
            async with session.get(f"{self.BASE_URL}/oauth/userinfo", headers=headers2) as resp2:
                # Should detect session replay from different IP
                assert resp2.status in [401, 403], "Session replay from different IP should be rejected"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_replay_with_modified_parameters(self):
        """Test replay attacks with parameter modifications."""
        
        async with aiohttp.ClientSession() as session:
            valid_refresh_token = "valid_modified_token_12345"
            
            # Original request
            original_data = {
                "grant_type": "refresh_token",
                "refresh_token": valid_refresh_token,
                "client_id": "test-client"
            }
            
            async with session.post(f"{self.BASE_URL}/oauth/token", data=original_data) as resp1:
                pass
            
            # Modified requests (attempting to bypass replay detection)
            modifications = [
                {"name": "extra_whitespace", "refresh_token": f" {valid_refresh_token} "},
                {"name": "case_variation", "refresh_token": valid_refresh_token.upper()},
                {"name": "url_encoding", "refresh_token": f"valid_refresh_token%2012345"},
                {"name": "null_bytes", "refresh_token": valid_refresh_token + "\x00\x00"},
            ]
            
            for modification in modifications:
                modified_data = original_data.copy()
                modified_data["refresh_token"] = modification["refresh_token"]
                
                async with session.post(f"{self.BASE_URL}/oauth/token", data=modified_data) as resp:
                    # Should reject modified parameters
                    assert resp.status in [400, 401], f"Modified parameter {modification['name']} should be rejected"
    
    @pytest.mark.asyncio
    @pytest.mark.security
    async def test_replay_attack_logging(self):
        """Test that replay attacks are properly logged."""
        
        async with aiohttp.ClientSession() as session:
            # Make a replay attack request
            data = {
                "grant_type": "refresh_token",
                "refresh_token": "replay_test_token_12345",
                "client_id": "test-client"
            }
            
            # First request (might succeed if token is valid)
            async with session.post(f"{self.BASE_URL}/oauth/token", data=data) as resp1:
                pass
            
            # Second request (replay)
            async with session.post(f"{self.BASE_URL}/oauth/token", data=data) as resp2:
                pass
            
            # Check security logs (this would require access to log system)
            # In a real test environment, you'd verify that:
            # 1. The replay attempt was logged
            # 2. The log contains relevant details (IP, user agent, timestamp)
            # 3. Security team was notified (if configured)
            
            # For this test, we'll just verify the request was rejected
            assert resp2.status in [400, 401], "Replay attack should be rejected"

class ReplayAttackSimulation:
    """Simulate various replay attack scenarios."""
    
    def __init__(self):
        self.attack_results = []
    
    async def simulate_token_family_replay(self, family_size: int = 5):
        """Simulate replay attack on a token family."""
        
        async with aiohttp.ClientSession() as session:
            # Simulate obtaining tokens in a family
            tokens = [f"family_token_{i}" for i in range(family_size)]
            
            # Use tokens sequentially to simulate rotation
            for i, token in enumerate(tokens):
                data = {
                    "grant_type": "refresh_token",
                    "refresh_token": token,
                    "client_id": "test-client"
                }
                
                async with session.post(f"{self.BASE_URL}/oauth/token", data=data) as resp:
                    result = {
                        "token_index": i,
                        "status": resp.status,
                        "timestamp": datetime.now(timezone.utc).isoformat()
                    }
                    
                    if resp.status == 200:
                        token_data = await resp.json()
                        result["new_token"] = token_data.get("refresh_token")
                    
                    self.attack_results.append(result)
                
                # Small delay between requests
                await asyncio.sleep(0.1)
            
            # Try to replay all tokens in the family
            for i, token in enumerate(tokens):
                data = {
                    "grant_type": "refresh_token",
                    "refresh_token": token,
                    "client_id": "test-client"
                }
                
                async with session.post(f"{self.BASE_URL}/oauth/token", data=data) as resp:
                    result = {
                        "token_index": i,
                        "replay_attempt": True,
                        "status": resp.status,
                        "timestamp": datetime.now(timezone.utc).isoformat()
                    }
                    
                    self.attack_results.append(result)
        
        return self.attack_results
    
    def analyze_replay_protection(self):
        """Analyze the effectiveness of replay protection."""
        
        if not self.attack_results:
            return {"error": "No attack results to analyze"}
        
        # Separate original and replay attempts
        original_attempts = [r for r in self.attack_results if not r.get("replay_attempt")]
        replay_attempts = [r for r in self.attack_results if r.get("replay_attempt")]
        
        analysis = {
            "total_original_attempts": len(original_attempts),
            "total_replay_attempts": len(replay_attempts),
            "original_success_rate": len([r for r in original_attempts if r["status"] == 200]) / len(original_attempts) if original_attempts else 0,
            "replay_success_rate": len([r for r in replay_attempts if r["status"] == 200]) / len(replay_attempts) if replay_attempts else 0,
            "protection_effective": len([r for r in replay_attempts if r["status"] in [400, 401]]) == len(replay_attempts)
        }
        
        return analysis

@pytest.mark.security
def test_replay_protection_effectiveness():
    """Test the overall effectiveness of replay protection."""
    
    simulator = ReplayAttackSimulation()
    
    # Run simulation
    asyncio.run(simulator.simulate_token_family_replay(3))
    
    # Analyze results
    analysis = simulator.analyze_replay_protection()
    
    # Verify protection is effective
    assert analysis["protection_effective"], "Replay protection should be effective"
    assert analysis["replay_success_rate"] == 0.0, "Replay success rate should be 0%"
    
    print(f"Replay protection analysis: {json.dumps(analysis, indent=2)}")

if __name__ == "__main__":
    # Run standalone replay attack simulation
    simulator = ReplayAttackSimulation()
    results = asyncio.run(simulator.simulate_token_family_replay(5))
    analysis = simulator.analyze_replay_protection()
    
    print("Replay Attack Simulation Results:")
    print(json.dumps(results, indent=2))
    print("\nProtection Analysis:")
    print(json.dumps(analysis, indent=2))
