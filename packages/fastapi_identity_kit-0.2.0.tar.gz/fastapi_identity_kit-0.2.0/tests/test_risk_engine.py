import pytest
import pytest_asyncio
import uuid
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from fastapi_identity_kit.identity_core.models import Base, User
from fastapi_identity_kit.risk_engine.models import LoginHistory, DeviceIdentity, SecurityEvent
from fastapi_identity_kit.risk_engine.analyzer import RiskAnalyzer
from fastapi_identity_kit.risk_engine.lockout import AccountLockoutService

TEST_DB_URL = "sqlite+aiosqlite:///:memory:"

@pytest_asyncio.fixture
async def async_session():
    engine = create_async_engine(TEST_DB_URL, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        
    async_session_maker = async_sessionmaker(engine, expire_on_commit=False)
    async with async_session_maker() as session:
        yield session

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()

@pytest_asyncio.fixture
async def user(async_session: AsyncSession):
    u = User(email="risk_test@example.com")
    async_session.add(u)
    await async_session.commit()
    return u

@pytest.fixture
def lockout_service():
    return AccountLockoutService(lockout_threshold=3, lockout_duration_minutes=1)


@pytest.mark.asyncio
async def test_risk_analyzer_new_ip_new_device(async_session: AsyncSession, user: User):
    ip = "192.168.1.1"
    ua = "Mozilla/5.0"
    
    # First time login = highly risky
    is_risky, reason = await RiskAnalyzer.evaluate_login_risk(
        db_session=async_session,
        user_id=user.id,
        ip_address=ip,
        user_agent=ua
    )
    
    assert is_risky is True
    assert "NEW_IP_ADDRESS" in reason
    assert "NEW_DEVICE_FINGERPRINT" in reason
    
    # Verify the device identity was logged but not trusted
    await async_session.commit()
    from sqlalchemy.future import select
    device_res = await async_session.execute(select(DeviceIdentity).where(DeviceIdentity.user_id == user.id))
    dev = device_res.scalars().first()
    assert dev is not None
    assert dev.is_trusted is False
    
    # Verify Security Event created
    evt_res = await async_session.execute(select(SecurityEvent).where(SecurityEvent.user_id == user.id))
    evt = evt_res.scalars().first()
    assert evt is not None
    assert evt.event_type == "HIGH_RISK_LOGIN"


@pytest.mark.asyncio
async def test_risk_analyzer_trusted_context(async_session: AsyncSession, user: User):
    ip = "10.0.0.5"
    ua = "Chrome/110"
    
    # Seed historical data (Pretend user has been here before and trusted the device)
    fingerprint = RiskAnalyzer.generate_fingerprint(ua, ip)
    dev = DeviceIdentity(user_id=user.id, fingerprint_hash=fingerprint, is_trusted=True)
    hist = LoginHistory(user_id=user.id, ip_address=ip, user_agent=ua, is_success=True)
    async_session.add_all([dev, hist])
    await async_session.commit()
    
    # Evaluate risk now
    is_risky, reason = await RiskAnalyzer.evaluate_login_risk(
        db_session=async_session,
        user_id=user.id,
        ip_address=ip,
        user_agent=ua
    )
    
    # Should be low risk
    assert is_risky is False
    assert reason == ""


@pytest.mark.asyncio
async def test_account_lockout(async_session: AsyncSession, user: User, lockout_service: AccountLockoutService):
    ip = "8.8.8.8"
    
    # Ensure starting clean
    assert await lockout_service.is_account_locked(user.id) is False
    
    # Fail 2 times
    await lockout_service.record_failed_login(async_session, user.id, ip)
    await lockout_service.record_failed_login(async_session, user.id, ip)
    assert await lockout_service.is_account_locked(user.id) is False
    
    # 3rd time is the threshold
    await lockout_service.record_failed_login(async_session, user.id, ip)
    
    assert await lockout_service.is_account_locked(user.id) is True
    
    # Check that a security event was logged
    from sqlalchemy.future import select
    res = await async_session.execute(
        select(SecurityEvent)
        .where(SecurityEvent.user_id == user.id, SecurityEvent.event_type == "ACCOUNT_LOCKED_BRUTE_FORCE")
    )
    evt = res.scalars().first()
    assert evt is not None
    assert evt.severity == "CRITICAL"
