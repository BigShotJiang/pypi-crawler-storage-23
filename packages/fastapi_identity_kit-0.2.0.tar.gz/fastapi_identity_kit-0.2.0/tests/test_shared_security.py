import pytest
import time
import base64
import hashlib
from datetime import datetime, timezone, timedelta
from typing import Dict, Any

from fastapi_identity_kit.shared_security import (
    generate_opaque_token,
    hash_token,
    constant_time_compare,
    KeyManager,
    JWTEngine,
    PKCEVerifier,
    StateManager,
    NonceManager,
    JWKValidator
)


def test_crypto_utils():
    # Test token generation
    token = generate_opaque_token(32)
    assert len(token) > 32 # urlsafe b64 encoding makes it longer
    
    # Test hashing
    hashed = hash_token(token)
    assert len(hashed) == 64 # SHA-256 hex digest length
    assert hash_token(token) == hashed # deterministic
    
    # Test constant time compare
    assert constant_time_compare("secret_string", "secret_string") is True
    assert constant_time_compare("secret_string", "wrong_string") is False


def test_pkce_verifier():
    # Valid S256 generated offline
    # Verifier: "a_very_long_secure_random_string_used_as_the_verifier_123"
    verifier = "a_very_long_secure_random_string_used_as_the_verifier_123"
    hash_digest = hashlib.sha256(verifier.encode('ascii')).digest()
    challenge = base64.urlsafe_b64encode(hash_digest).decode('ascii').rstrip('=')
    
    assert PKCEVerifier.verify_s256(challenge, verifier) is True
    assert PKCEVerifier.verify_s256(challenge, "wrong_verifier") is False
    assert PKCEVerifier.verify_s256("wrong_challenge", verifier) is False


def test_state_and_nonce_manager():
    state1 = StateManager.generate_state()
    state2 = StateManager.generate_state()
    assert state1 != state2
    assert StateManager.validate_state(state1, state1) is True
    assert StateManager.validate_state(state1, state2) is False

    nonce = NonceManager.generate_nonce()
    assert NonceManager.validate_nonce_with_token(nonce, nonce) is True
    assert NonceManager.validate_nonce_with_token(nonce, "tampered") is False


def test_key_manager():
    km = KeyManager()
    
    # RSA Key
    kid_rsa = km.generate_rsa_key("rsa-key-1")
    assert kid_rsa == "rsa-key-1"
    jwk_rsa = km.export_jwk("rsa-key-1")
    assert jwk_rsa["kty"] == "RSA"
    assert "n" in jwk_rsa and "e" in jwk_rsa
    
    # EC Key
    kid_ec = km.generate_ec_key("ec-key-1")
    assert kid_ec == "ec-key-1"
    jwk_ec = km.export_jwk("ec-key-1")
    assert jwk_ec["kty"] == "EC"
    assert jwk_ec["crv"] == "P-256"
    assert "x" in jwk_ec and "y" in jwk_ec

    jwks = km.export_jwks()
    assert len(jwks["keys"]) == 2


def test_jwt_engine_and_jwk_validator():
    km = KeyManager()
    kid = km.generate_rsa_key("test-key")
    
    issuer = "https://identity.local"
    engine = JWTEngine(km, issuer=issuer)
    
    now = datetime.now(timezone.utc)
    payload = {
        "sub": "user-123",
        "aud": "client-app",
        "iat": int(now.timestamp()),
        "nbf": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=5)).timestamp())
    }
    
    # Sign with engine
    token = engine.sign(payload, kid="test-key", alg="RS256")
    
    # Verify with engine
    decoded = engine.verify(token, audience="client-app")
    assert decoded["sub"] == "user-123"
    
    # Should fail if wrong audience
    with pytest.raises(ValueError):
        engine.verify(token, audience="wrong-app")
    
    # Now test JWKValidator
    jwks = km.export_jwks()
    validator = JWKValidator(jwks)
    
    decoded_validator = validator.verify_token(token, audience="client-app", issuer=issuer)
    assert decoded_validator["sub"] == "user-123"
    
    # Modifying the token to simulate tampering
    parts = token.split(".")
    tampered_token = f"{parts[0]}.{parts[1]}.badsignature"
    with pytest.raises(ValueError, match="Token validation failed: Signature verification failed"):
        validator.verify_token(tampered_token, audience="client-app", issuer=issuer)
