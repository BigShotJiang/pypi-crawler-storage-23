import pytest
import pytest_asyncio
import pyotp
import base64
from cryptography.fernet import Fernet
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from fastapi_identity_kit.identity_core.models import Base, User
from fastapi_identity_kit.mfa import TOTPService, BackupCodeService, LockoutService
from fastapi_identity_kit.mfa.models import MFAConfiguration, BackupCode

TEST_DB_URL = "sqlite+aiosqlite:///:memory:"

@pytest_asyncio.fixture
async def async_session():
    engine = create_async_engine(TEST_DB_URL, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        
    async_session_maker = async_sessionmaker(engine, expire_on_commit=False)
    async with async_session_maker() as session:
        yield session

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest_asyncio.fixture
async def user(async_session: AsyncSession):
    u = User(email="mfa_test@example.com")
    async_session.add(u)
    await async_session.commit()
    return u

@pytest.fixture
def totp_service():
    key = Fernet.generate_key()
    return TOTPService(encryption_key=key, issuer_name="TestKit")

@pytest.fixture
def lockout_service():
    # Strict lockout for testing: 3 attempts max
    return LockoutService(max_attempts=3, lockout_minutes=1)


@pytest.mark.asyncio
async def test_totp_enroll_and_verify(async_session: AsyncSession, user: User, totp_service: TOTPService):
    uid = user.id
    
    # 1. Generate Secret
    raw_secret, uri = await totp_service.generate_secret(async_session, uid, user.email)
    
    assert raw_secret is not None
    assert "otpauth://" in uri
    assert "TestKit" in uri
    
    # 2. Assert it's disabled initially
    from sqlalchemy.future import select
    res = await async_session.execute(select(MFAConfiguration).where(MFAConfiguration.user_id == user.id))
    config = res.scalars().first()
    assert config is not None
    assert config.is_enabled is False
    assert config.encrypted_secret is not None # At-rest encryption active
    
    # 3. Generate correct code and verify
    totp = pyotp.TOTP(raw_secret)
    valid_code = totp.now()
    
    success = await totp_service.verify_and_enable(async_session, uid, valid_code)
    assert success is True
    
    # 4. Check DB updated to enabled
    await async_session.refresh(config)
    assert config.is_enabled is True
    
    # 5. Bad code rejection
    is_valid = await totp_service.verify_code(async_session, uid, "000000")
    assert is_valid is False


@pytest.mark.asyncio
async def test_mfa_lockout_policy(async_session: AsyncSession, user: User, totp_service: TOTPService, lockout_service: LockoutService):
    uid = user.id
    await totp_service.generate_secret(async_session, uid, user.email)
    
    # Cause 3 failures
    for _ in range(3):
        assert await totp_service.verify_code(async_session, uid, "000000", lockout_service) is False
        
    # 4th failure triggers Lockout ValueError
    with pytest.raises(ValueError, match="MFA temporarily locked"):
        await totp_service.verify_code(async_session, uid, "111111", lockout_service)


@pytest.mark.asyncio
async def test_backup_codes(async_session: AsyncSession, user: User):
    uid = user.id
    
    # Generate backup codes
    codes = await BackupCodeService.generate_codes(async_session, uid, count=5)
    
    assert len(codes) == 5
    first_code = codes[0]
    
    # Consume correctly
    success = await BackupCodeService.consume_code(async_session, uid, first_code)
    assert success is True
    
    # Replay/already used test
    fail = await BackupCodeService.consume_code(async_session, uid, first_code)
    assert fail is False
    
    # Invalid code
    assert await BackupCodeService.consume_code(async_session, uid, "INVALIDXYZ") is False
