import pytest
import pytest_asyncio
import asyncio
from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from fastapi_identity_kit.identity_core import (
    Base, User, IdentityLink, 
    PasswordService, AccountLinkingService, RecoveryService
)
from datetime import datetime, timezone, timedelta

# In-memory SQLite for testing SQLAlchemy models
TEST_DB_URL = "sqlite+aiosqlite:///:memory:"

@pytest_asyncio.fixture
async def async_session() -> AsyncGenerator[AsyncSession, None]:
    engine = create_async_engine(TEST_DB_URL, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        
    async_session_maker = async_sessionmaker(engine, expire_on_commit=False)
    async with async_session_maker() as session:
        yield session

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest.mark.asyncio
async def test_user_creation_and_linking(async_session):
    # 1. Create a basic local user
    ps = PasswordService()
    hashed = ps.hash("SecureP@ssw0rd123!")
    
    new_user = User(email="test@example.com", password_hash=hashed, is_verified=False)
    async_session.add(new_user)
    await async_session.commit()
    
    # Verify retrieval
    user = await AccountLinkingService.get_user_by_email(async_session, "test@example.com")
    assert user is not None
    assert user.is_verified is False
    
    # 2. Try linking an unverified external provider -> Should fail via our ValueError rule
    with pytest.raises(ValueError, match="Risk of account takeover"):
        await AccountLinkingService.link_external_identity(
            async_session, user, "google", "sub123", is_email_verified=False
        )
        
    # 3. Link a verified external provider -> Should succeed and verify user
    link = await AccountLinkingService.link_external_identity(
        async_session, user, "google", "sub123", is_email_verified=True
    )
    
    assert link.provider_name == "google"
    assert link.user_id == user.id
    assert user.is_verified is True # Auto-verified through trusted provider


def test_password_service():
    ps = PasswordService(time_cost=1, memory_cost=8192) # Reduced parameters strictly for faster tests
    
    # Test strict policy validation
    assert ps.validate_policy("short") is False
    assert ps.validate_policy("NoSpecialChar123") is False
    assert ps.validate_policy("nouppercaseinthispass!!1") is False
    assert ps.validate_policy("Valid123!@#Secure") is True
    
    # Test hashing and verifying
    raw_pass = "Valid123!@#Secure"
    p_hash = ps.hash(raw_pass)
    assert ps.verify(p_hash, raw_pass) is True
    assert ps.verify(p_hash, "wrong-password") is False


def test_recovery_service():
    # Password Reset
    raw_token, hashed_token, exp = RecoveryService.generate_recovery_token()
    assert RecoveryService.validate_token(raw_token, hashed_token, exp) is True
    
    # Expired token test
    expired_time = datetime.now(timezone.utc) - timedelta(minutes=5)
    assert RecoveryService.validate_token(raw_token, hashed_token, expired_time) is False
    
    # Tampered token
    assert RecoveryService.validate_token("tampered_tokenabc", hashed_token, exp) is False

    # Verify email tokens
    e_raw, e_hash, e_exp = RecoveryService.generate_verification_token()
    assert RecoveryService.validate_token(e_raw, e_hash, e_exp) is True
