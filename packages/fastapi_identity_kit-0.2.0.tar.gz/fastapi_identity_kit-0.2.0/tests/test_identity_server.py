import pytest
import pytest_asyncio
import uuid
from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from fastapi import FastAPI
from fastapi.testclient import TestClient
from datetime import datetime, timezone, timedelta
import hashlib
import base64

from fastapi_identity_kit.identity_core.models import Base, User, Session
from fastapi_identity_kit.identity_server.models import AuthorizationCode, RefreshToken
from fastapi_identity_kit.shared_security import KeyManager, JWTEngine
from fastapi_identity_kit.identity_server import TokenService

TEST_DB_URL = "sqlite+aiosqlite:///:memory:"

@pytest_asyncio.fixture
async def async_session() -> AsyncGenerator[AsyncSession, None]:
    engine = create_async_engine(TEST_DB_URL, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        
    async_session_maker = async_sessionmaker(engine, expire_on_commit=False)
    async with async_session_maker() as session:
        yield session

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest_asyncio.fixture
async def setup_data(async_session: AsyncSession):
    user = User(email="test_server@example.com")
    async_session.add(user)
    await async_session.commit()
    
    session = Session(user_id=user.id, client_id="test_client", ip_address="127.0.0.1")
    async_session.add(session)
    await async_session.commit()
    
    return user, session


@pytest.fixture
def token_service():
    km = KeyManager()
    kid = km.generate_rsa_key("server-key-1")
    engine = JWTEngine(km, "https://issuer.local")
    return TokenService(engine, active_kid=kid)


@pytest.mark.asyncio
async def test_authorization_code_flow(async_session: AsyncSession, setup_data, token_service: TokenService):
    user, auth_session = setup_data
    client_id = "test_client"
    redirect_uri = "https://app.example.com/callback"
    
    # 1. Setup PKCE
    verifier = "super_secret_high_entropy_verifier_string_123456"
    digest = hashlib.sha256(verifier.encode('ascii')).digest()
    challenge = base64.urlsafe_b64encode(digest).decode('ascii').rstrip('=')
    
    # 2. Authorize -> Get Code
    code = await token_service.create_authorization_code(
        async_session,
        user_id=user.id,
        auth_session_id=auth_session.id,
        client_id=client_id,
        redirect_uri=redirect_uri,
        code_challenge=challenge,
        scope="openid profile",
        nonce="nonce123"
    )
    
    assert code is not None
    
    # 3. Exchange Code -> Fail due to bad PKCE verifier
    with pytest.raises(ValueError, match="PKCE verification failed"):
        await token_service.exchange_code_for_tokens(
            async_session, code, client_id, redirect_uri, "wrong_verifier"
        )
        
    # Wait, the code was deleted because it's single use! Let's verify that.
    with pytest.raises(ValueError, match="Invalid or expired authorization code."):
        await token_service.exchange_code_for_tokens(
            async_session, code, client_id, redirect_uri, verifier
        )
        
    # 4. Try again successfully
    code2 = await token_service.create_authorization_code(
        async_session, user.id, auth_session.id, client_id, redirect_uri, challenge, "openid"
    )
    
    tokens = await token_service.exchange_code_for_tokens(
        async_session, code2, client_id, redirect_uri, verifier
    )
    
    assert "access_token" in tokens
    assert "refresh_token" in tokens
    assert "id_token" in tokens # We requested openid
    
    # 5. Refresh token rotation
    old_refresh = tokens["refresh_token"]
    
    new_tokens = await token_service.refresh_tokens(
        async_session, old_refresh, client_id
    )
    
    assert "access_token" in new_tokens
    assert "refresh_token" in new_tokens
    assert new_tokens["refresh_token"] != old_refresh
    
    # 6. Replay attack detection! Try using the OLD refresh token again
    with pytest.raises(ValueError, match="Replay attack detected"):
        await token_service.refresh_tokens(async_session, old_refresh, client_id)
        
    # Verify session was revoked as a result
    await async_session.refresh(auth_session)
    assert auth_session.revoked_at is not None
