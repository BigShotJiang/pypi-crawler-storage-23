import uuid
import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from fastapi import Request, HTTPException
from unittest.mock import MagicMock
from fastapi_identity_kit.identity_core.models import Base, User
from fastapi_identity_kit.authorization.models import Tenant, Role, Permission, RolePermission, UserRole
from fastapi_identity_kit.authorization.rbac import RBACService
from fastapi_identity_kit.authorization.dependencies import RequirePermission

TEST_DB_URL = "sqlite+aiosqlite:///:memory:"

@pytest_asyncio.fixture
async def async_session():
    engine = create_async_engine(TEST_DB_URL, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        
    async_session_maker = async_sessionmaker(engine, expire_on_commit=False)
    async with async_session_maker() as session:
        yield session

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest.mark.asyncio
async def test_hierarchical_rbac(async_session: AsyncSession):
    # Setup Tenant & User
    tenant = Tenant(name="Acme Corp")
    user = User(email="employee@acme.com")
    
    # Setup Permissions
    view_perm = Permission(name="files:read")
    edit_perm = Permission(name="files:write")
    delete_perm = Permission(name="files:delete")
    
    async_session.add_all([tenant, user, view_perm, edit_perm, delete_perm])
    await async_session.commit()
    
    # Setup Hierarchy: Viewer <- Editor <- Admin
    role_viewer = Role(tenant_id=tenant.id, name="Viewer")
    async_session.add(role_viewer)
    await async_session.commit()
    
    role_editor = Role(tenant_id=tenant.id, name="Editor", parent_id=role_viewer.id)
    async_session.add(role_editor)
    await async_session.commit()
    
    role_admin = Role(tenant_id=tenant.id, name="Admin", parent_id=role_editor.id)
    async_session.add(role_admin)
    await async_session.commit()
    
    # Bind Permissions
    async_session.add(RolePermission(role_id=role_viewer.id, permission_id=view_perm.id))
    async_session.add(RolePermission(role_id=role_editor.id, permission_id=edit_perm.id))
    async_session.add(RolePermission(role_id=role_admin.id, permission_id=delete_perm.id))
    
    # Assign User only to 'Editor' role
    async_session.add(UserRole(user_id=user.id, role_id=role_editor.id))
    await async_session.commit()

    # Verify RBAC Engine
    permissions = await RBACService.get_user_permissions(async_session, user.id, tenant.id)
    
    assert "files:read" in permissions    # Inherited from Viewer
    assert "files:write" in permissions   # Direct from Editor
    assert "files:delete" not in permissions # Does not hold Admin
    
    assert await RBACService.has_permission(async_session, user.id, tenant.id, "files:read") is True
    assert await RBACService.has_permission(async_session, user.id, tenant.id, "files:delete") is False


@pytest.mark.asyncio
async def test_fastapi_dependency(async_session: AsyncSession):
    tenant = Tenant(name="Test Org")
    user = User(email="u@example.com")
    
    perm_read = Permission(name="users:read")
    async_session.add_all([tenant, user, perm_read])
    await async_session.commit()
    
    # Add dependency enforcer targeting users:read
    enforcer = RequirePermission("users:read")
    
    # Mock FastAPI dependencies
    mock_request = MagicMock(spec=Request)
    mock_request.url.path = "/api/v1/users"

    # Test 1: Without Permission (Deny & Throw 403)
    with pytest.raises(HTTPException) as exc_info:
        await enforcer(
            request=mock_request,
            db_session=async_session,
            user_id=user.id,
            tenant_id=tenant.id
        )
    assert exc_info.value.status_code == 403
    
    # Test 2: Grant Permission and Verify Access
    role = Role(tenant_id=tenant.id, name="Staff")
    async_session.add(role)
    await async_session.commit()
    
    async_session.add(RolePermission(role_id=role.id, permission_id=perm_read.id))
    async_session.add(UserRole(user_id=user.id, role_id=role.id))
    await async_session.commit()
    
    result = await enforcer(
        request=mock_request,
        db_session=async_session,
        user_id=user.id,
        tenant_id=tenant.id
    )
    assert result is True
