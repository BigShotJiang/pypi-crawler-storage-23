# Usage Guide - FastAPI Identity Provider

This guide shows how to use the FastAPI Identity Provider as a package in your projects.

## 🚀 Quick Start

### Installation

```bash
# Install with uv (recommended)
uv add fastapi-identity-kit

# Or with pip
pip install fastapi-identity-kit
```

### Basic Usage

```python
from fastapi import FastAPI
from fastapi_identity_kit import create_identity_app, IdentityConfig

# Create FastAPI app with identity provider
app = create_identity_app(
    database_url="postgresql://user:password@localhost/identity",
    redis_url="redis://localhost:6379/0",
    secret_key="your-secret-key"
)

# Or with custom configuration
config = IdentityConfig(
    database_url="postgresql://user:password@localhost/identity",
    redis_url="redis://localhost:6379/0",
    secret_key="your-secret-key",
    enforce_https=True,
    jwt_expiry_minutes=60,
    refresh_token_days=30
)

app = create_identity_app(config=config)
```

## 📋 Integration Options

### Option 1: Standalone Identity Server

```python
# main.py
from fastapi_identity_kit import create_identity_app, IdentityConfig

config = IdentityConfig(
    database_url="postgresql://user:password@localhost/identity",
    redis_url="redis://localhost:6379/0",
    secret_key="your-secret-key",
    enforce_https=True
)

app = create_identity_app(config=config)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

### Option 2: Add to Existing FastAPI App

```python
from fastapi import FastAPI
from fastapi_identity_kit import add_identity_provider, IdentityConfig

app = FastAPI(title="My Application")

# Add identity provider to existing app
identity_config = IdentityConfig(
    database_url="postgresql://user:password@localhost/identity",
    redis_url="redis://localhost:6379/0",
    secret_key="your-secret-key"
)

identity_app = add_identity_provider(app, config=identity_config)

@app.get("/")
async def root():
    return {"message": "My Application with Identity"}

@app.get("/protected")
async def protected():
    return {"message": "This is a protected endpoint"}
```

### Option 3: Custom Integration

```python
from fastapi import FastAPI
from fastapi_identity_kit.identity_server.router import identity_router
from fastapi_identity_kit.config.settings import get_settings
from fastapi_identity_kit.shared_security.database import get_db_session

app = FastAPI()

# Configure settings
settings = get_settings()

# Add identity routes
app.include_router(identity_router, prefix="/oauth", tags=["oauth"])

# Add your custom routes
@app.get("/")
async def root():
    return {"message": "Custom Application"}

@app.get("/users/me")
async def get_current_user():
    # Your custom user logic here
    pass
```

## 🔧 Configuration

### Environment Variables

```bash
# Database
DATABASE_URL=postgresql://user:password@localhost/identity
REDIS_URL=redis://localhost:6379/0

# Security
SECRET_KEY=your-super-secret-key
ENFORCE_HTTPS=true
JWT_EXPIRY_MINUTES=60
REFRESH_TOKEN_DAYS=30

# Secret Management
SECRET_PROVIDER=environment  # or vault, aws
VAULT_URL=https://vault.example.com
VAULT_TOKEN=your-vault-token

# MFA
MFA_ISSUER=MyApp
TOTP_DIGITS=6

# Rate Limiting
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=3600
```

### Configuration Object

```python
from fastapi_identity_kit import IdentityConfig

config = IdentityConfig(
    # Database Configuration
    database_url="postgresql://user:password@localhost/identity",
    redis_url="redis://localhost:6379/0",
    
    # Security Configuration
    secret_key="your-secret-key",
    enforce_https=True,
    jwt_expiry_minutes=60,
    refresh_token_days=30,
    
    # MFA Configuration
    mfa_issuer="MyApp",
    totp_digits=6,
    totp_valid_window=1,
    
    # Rate Limiting
    rate_limit_requests=100,
    rate_limit_window=3600,
    
    # Secret Management
    secret_provider="environment",
    vault_url="https://vault.example.com",
    vault_token="your-vault-token",
    
    # Key Rotation
    key_rotation_enabled=True,
    key_rotation_interval_hours=24,
    
    # Database Encryption
    database_encryption_enabled=True,
    encryption_key_rotation_hours=168,
)
```

## 🔐 OAuth2/OIDC Endpoints

Once integrated, your application will have these endpoints:

### OAuth2 Endpoints
```
POST   /oauth/authorize          # Authorization endpoint
POST   /oauth/token             # Token endpoint
POST   /oauth/revoke            # Token revocation
POST   /oauth/introspect        # Token introspection
```

### OpenID Connect Endpoints
```
GET    /.well-known/openid-configuration  # OIDC discovery
GET    /.well-known/jwks.json             # JWKS endpoint
GET    /oauth/userinfo                    # User information
```

### Management Endpoints
```
POST   /auth/login              # Login endpoint
POST   /auth/logout             # Logout endpoint
POST   /auth/register           # User registration
POST   /auth/mfa/setup          # MFA setup
POST   /auth/mfa/verify         # MFA verification
```

## 📱 Client Integration

### JavaScript/TypeScript Example

```typescript
// OAuth2 Authorization Code Flow
class OAuth2Client {
    private clientId = 'your-client-id';
    private redirectUri = 'https://your-app.com/callback';
    private authUrl = 'https://identity.example.com/oauth/authorize';
    private tokenUrl = 'https://identity.example.com/oauth/token';

    async authorize() {
        const params = new URLSearchParams({
            response_type: 'code',
            client_id: this.clientId,
            redirect_uri: this.redirectUri,
            scope: 'openid profile email',
            state: this.generateState(),
            code_challenge: this.generateCodeChallenge(),
            code_challenge_method: 'S256'
        });

        window.location.href = `${this.authUrl}?${params}`;
    }

    async exchangeCodeForToken(code: string, codeVerifier: string) {
        const response = await fetch(this.tokenUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                grant_type: 'authorization_code',
                code,
                client_id: this.clientId,
                redirect_uri: this.redirectUri,
                code_verifier: codeVerifier
            })
        });

        return await response.json();
    }

    private generateState(): string {
        return Math.random().toString(36).substring(2, 15);
    }

    private generateCodeChallenge(): string {
        const verifier = this.generateCodeVerifier();
        const encoder = new TextEncoder();
        const data = encoder.encode(verifier);
        return crypto.subtle.digest('SHA-256', data).then(buffer => {
            return btoa(String.fromCharCode(...new Uint8Array(buffer)))
                .replace(/\+/g, '-')
                .replace(/\//g, '_')
                .replace(/=/g, '');
        });
    }

    private generateCodeVerifier(): string {
        const array = new Uint8Array(32);
        crypto.getRandomValues(array);
        return btoa(String.fromCharCode(...array))
            .replace(/\+/g, '-')
            .replace(/\//g, '_')
            .replace(/=/g, '');
    }
}
```

### Python Client Example

```python
import requests
from urllib.parse import urlencode

class OAuth2Client:
    def __init__(self, client_id, redirect_uri, auth_url, token_url):
        self.client_id = client_id
        self.redirect_uri = redirect_uri
        self.auth_url = auth_url
        self.token_url = token_url

    def get_authorization_url(self, state=None, code_challenge=None):
        params = {
            'response_type': 'code',
            'client_id': self.client_id,
            'redirect_uri': self.redirect_uri,
            'scope': 'openid profile email',
            'state': state or self._generate_state(),
        }
        
        if code_challenge:
            params.update({
                'code_challenge': code_challenge,
                'code_challenge_method': 'S256'
            })
        
        return f"{self.auth_url}?{urlencode(params)}"

    def exchange_code_for_token(self, code, code_verifier=None):
        data = {
            'grant_type': 'authorization_code',
            'code': code,
            'client_id': self.client_id,
            'redirect_uri': self.redirect_uri,
        }
        
        if code_verifier:
            data['code_verifier'] = code_verifier

        response = requests.post(self.token_url, data=data)
        response.raise_for_status()
        return response.json()

    def refresh_token(self, refresh_token):
        data = {
            'grant_type': 'refresh_token',
            'refresh_token': refresh_token,
            'client_id': self.client_id,
        }

        response = requests.post(self.token_url, data=data)
        response.raise_for_status()
        return response.json()

    def _generate_state(self):
        import secrets
        return secrets.token_urlsafe(16)
```

## 🏗️ Deployment Examples

### Docker Compose

```yaml
version: '3.8'
services:
  app:
    image: your-app:latest
    ports: ["8000:8000"]
    environment:
      - DATABASE_URL=postgresql://postgres:password@db:5432/identity
      - REDIS_URL=redis://redis:6379/0
      - SECRET_KEY=${SECRET_KEY}
      - ENFORCE_HTTPS=true
    depends_on: [db, redis]

  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=identity
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=password
    volumes: ["postgres_data:/var/lib/postgresql/data"]

  redis:
    image: redis:7-alpine
    volumes: ["redis_data:/data"]

volumes:
  postgres_data:
  redis_data:
```

### Kubernetes

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: identity-app
spec:
  replicas: 3
  selector:
    matchLabels:
      app: identity-app
  template:
    metadata:
      labels:
        app: identity-app
    spec:
      containers:
      - name: app
        image: your-app:latest
        ports:
        - containerPort: 8000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: database-url
        - name: SECRET_KEY
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: secret-key
---
apiVersion: v1
kind: Service
metadata:
  name: identity-service
spec:
  selector:
    app: identity-app
  ports:
  - port: 80
    targetPort: 8000
  type: LoadBalancer
```

## 🧪 Testing

### Unit Tests

```python
import pytest
from fastapi.testclient import TestClient
from fastapi_identity_kit import create_identity_app, IdentityConfig

@pytest.fixture
def app():
    config = IdentityConfig(
        database_url="sqlite:///:memory:",
        redis_url="redis://localhost:6379/1",
        secret_key="test-secret"
    )
    return create_identity_app(config=config)

@pytest.fixture
def client(app):
    return TestClient(app)

def test_health_check(client):
    response = client.get("/health")
    assert response.status_code == 200

def test_oidc_discovery(client):
    response = client.get("/.well-known/openid-configuration")
    assert response.status_code == 200
    data = response.json()
    assert "issuer" in data
    assert "authorization_endpoint" in data
```

### Integration Tests

```python
import pytest
from fastapi.testclient import TestClient
from fastapi_identity_kit import create_identity_app, IdentityConfig

@pytest.fixture(scope="function")
def test_app():
    # Use test database
    config = IdentityConfig(
        database_url="postgresql://test:test@localhost:5432/identity_test",
        redis_url="redis://localhost:6379/2",
        secret_key="test-secret"
    )
    return create_identity_app(config=config)

def test_oauth2_flow(test_app):
    client = TestClient(test_app)
    
    # Test authorization endpoint
    response = client.post("/oauth/authorize", data={
        "response_type": "code",
        "client_id": "test-client",
        "redirect_uri": "https://test.com/callback",
        "scope": "openid profile"
    })
    assert response.status_code in [200, 302]
    
    # Test token endpoint
    # ... continue with full flow testing
```

## 🔧 Customization

### Custom User Model

```python
from fastapi_identity_kit.identity_core.models import User
from sqlalchemy import Column, String

class CustomUser(User):
    custom_field = Column(String(100))
    
    def __repr__(self):
        return f"CustomUser(id={self.id}, email={self.email})"
```

### Custom Authentication Logic

```python
from fastapi_identity_kit.identity_core.auth_service import AuthService

class CustomAuthService(AuthService):
    async def authenticate_user(self, username: str, password: str):
        # Add your custom authentication logic
        user = await self.get_user_by_username(username)
        
        # Custom validation logic
        if user and self.verify_password(password, user.password_hash):
            # Add custom business logic
            if not user.is_active:
                raise ValueError("User is not active")
            
            return user
        
        return None
```

### Custom Middleware

```python
from fastapi_identity_kit.shared_security.middleware import SecurityMiddleware
from fastapi import Request, Response

class CustomSecurityMiddleware(SecurityMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Add custom security logic
        if self.is_blocked_ip(request.client.host):
            return Response("Blocked", status_code=403)
        
        response = await call_next(request)
        
        # Add custom headers
        response.headers["X-Custom-Security"] = "enabled"
        
        return response

# Use in your app
app.middleware("http")(CustomSecurityMiddleware)
```

## 📚 Advanced Usage

### Multi-Tenant Support

```python
from fastapi_identity_kit import IdentityConfig

config = IdentityConfig(
    database_url="postgresql://user:password@localhost/identity",
    redis_url="redis://localhost:6379/0",
    secret_key="your-secret-key",
    multi_tenant_enabled=True,
    tenant_strategy="subdomain"  # or "header", "path"
)
```

### Custom Claims

```python
from fastapi_identity_kit.identity_server.token_service import TokenService

class CustomTokenService(TokenService):
    async def create_id_token(self, user, client_id, nonce=None):
        # Add custom claims
        claims = await super().create_id_token(user, client_id, nonce)
        
        # Custom business claims
        claims["custom_role"] = await self.get_user_role(user)
        claims["department"] = await self.get_user_department(user)
        claims["permissions"] = await self.get_user_permissions(user)
        
        return claims
```

### External Identity Providers

```python
from fastapi_identity_kit.identity_core.external_auth import ExternalAuthProvider

class SSOProvider(ExternalAuthProvider):
    async def authenticate(self, token: str):
        # Validate external token
        user_info = await self.validate_external_token(token)
        
        # Create or update local user
        user = await self.get_or_create_user(user_info)
        
        return user
```

## 🚀 Production Checklist

- [ ] Configure production database and Redis
- [ ] Set up SSL certificates
- [ ] Configure environment variables
- [ ] Set up monitoring and logging
- [ ] Configure rate limiting
- [ ] Set up backup and recovery
- [ ] Configure secret management
- [ ] Set up health checks
- [ ] Configure load balancing (if needed)
- [ ] Test all OAuth2/OIDC flows
- [ ] Set up security monitoring
- [ ] Configure key rotation
- [ ] Test MFA functionality

## 📞 Support

- **Documentation**: [Full API docs](https://fastapi-identity-kit.readthedocs.io/)
- **Issues**: [GitHub Issues](https://github.com/your-repo/fastapi-identity-kit/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-repo/fastapi-identity-kit/discussions)
- **Security**: Report security issues to security@example.com
