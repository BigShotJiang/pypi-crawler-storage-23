import os
import sys

# ensure .env doesn't exist
if os.path.exists(".env"):
    os.rename(".env", ".env.bak")

try:
    from fastapi.testclient import TestClient
    from fastapi_identity_kit.app_factory import create_identity_app
    
    app = create_identity_app()
    client = TestClient(app)
    
    print("Testing Root Redirect...")
    response = client.get("/", follow_redirects=False)
    assert response.status_code == 307
    assert "/setup/" in response.headers["location"]
    
    print("Testing Setup UI...")
    response = client.get("/setup/")
    assert response.status_code == 200
    assert b"Identity Kit" in response.content
    
    print("Testing Setup API...")
    test_data = {
        "database_url": "sqlite:///./test.db",
        "secret_key": "test_secret_key_1234567890",
        "redis_enabled": False,
        "enforce_https": False,
        "mfa_enabled": False
    }
    response = client.post("/setup/api/configure", json=test_data)
    assert response.status_code == 200
    assert response.json()["status"] == "success"
    
    print("Verifying .env generation...")
    assert os.path.exists(".env")
    with open(".env") as f:
        content = f.read()
        assert "SECRET_KEY=test_secret_key" in content
        
    print("SUCCESS: Setup Wizard logic verified.")
    
finally:
    if os.path.exists(".env.bak"):
        if os.path.exists(".env"):
            os.remove(".env")
        os.rename(".env.bak", ".env")
    elif os.path.exists(".env"):
        os.remove(".env")
