"use client";

import { useState } from "react";

export default function SetupWizard() {
  const [formData, setFormData] = useState({
    database_url: "sqlite:///./identity.db",
    secret_key: "",
    redis_enabled: false,
    redis_url: "redis://localhost:6379",
    enforce_https: true,
    mfa_enabled: false,
  });
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  const generateSecret = () => {
    // Basic fallback generation for client side
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    const secret = Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
    setFormData({ ...formData, secret_key: secret });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("loading");
    setMessage("");

    if (!formData.secret_key) {
      setStatus("error");
      setMessage("Secret Key is required.");
      return;
    }

    try {
      const res = await fetch("/setup/api/configure", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (res.ok) {
        setStatus("success");
        setMessage(data.message || "Configuration saved. Please restart the backend.");
      } else {
        setStatus("error");
        setMessage(data.error || "An error occurred.");
      }
    } catch (err: any) {
      setStatus("error");
      setMessage(err.message || "Network error. Make sure the backend is running.");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-8">
      <div className="max-w-2xl w-full">
        <header className="mb-16 text-center">
          <h1 className="text-4xl font-light tracking-widest uppercase mb-4">Identity Kit</h1>
          <p className="text-sm text-gray-500 uppercase tracking-widest">Initial Setup Configuration</p>
        </header>

        <form onSubmit={handleSubmit} className="space-y-12">
          {/* Database Configuration */}
          <section className="space-y-6">
            <h2 className="text-sm font-semibold uppercase tracking-widest border-b border-[var(--border)] pb-2">1. Data Storage</h2>

            <div className="space-y-2">
              <label className="block text-xs uppercase tracking-wider text-gray-500">Database URL</label>
              <input
                type="text"
                className="w-full p-4 text-sm"
                value={formData.database_url}
                onChange={(e) => setFormData({ ...formData, database_url: e.target.value })}
                placeholder="postgresql://user:password@localhost/identity"
              />
              <p className="text-xs text-gray-400">Default is SQLite for local development.</p>
            </div>
          </section>

          {/* Security Configuration */}
          <section className="space-y-6">
            <h2 className="text-sm font-semibold uppercase tracking-widest border-b border-[var(--border)] pb-2">2. Security</h2>

            <div className="space-y-2">
              <label className="block text-xs uppercase tracking-wider text-gray-500 flex justify-between">
                <span>Secret Key</span>
                <button type="button" onClick={generateSecret} className="text-xs border-none underline px-0 py-0 bg-transparent hover:bg-transparent text-[var(--foreground)]">Generate</button>
              </label>
              <input
                type="password"
                className="w-full p-4 text-sm"
                value={formData.secret_key}
                onChange={(e) => setFormData({ ...formData, secret_key: e.target.value })}
                placeholder="Enter a highly secure random string"
              />
            </div>

            <div className="flex items-center space-x-3 mt-4">
              <input
                type="checkbox"
                id="enforceList"
                className="w-4 h-4 accent-black"
                checked={formData.enforce_https}
                onChange={(e) => setFormData({ ...formData, enforce_https: e.target.checked })}
              />
              <label htmlFor="enforceList" className="text-sm">Enforce HTTPS (Recommended for Production)</label>
            </div>

            <div className="flex items-center space-x-3 mt-4">
              <input
                type="checkbox"
                id="mfaList"
                className="w-4 h-4 accent-black"
                checked={formData.mfa_enabled}
                onChange={(e) => setFormData({ ...formData, mfa_enabled: e.target.checked })}
              />
              <label htmlFor="mfaList" className="text-sm">Enable Multi-Factor Authentication (MFA)</label>
            </div>
          </section>

          {/* Redis Configuration */}
          <section className="space-y-6">
            <h2 className="text-sm font-semibold uppercase tracking-widest border-b border-[var(--border)] pb-2">3. Redis (Optional)</h2>
            <p className="text-xs text-gray-500">Enable Redis for distributed rate limiting and state management.</p>

            <div className="flex items-center space-x-3 mb-6">
              <input
                type="checkbox"
                id="redisList"
                className="w-4 h-4 accent-black"
                checked={formData.redis_enabled}
                onChange={(e) => setFormData({ ...formData, redis_enabled: e.target.checked })}
              />
              <label htmlFor="redisList" className="text-sm font-medium">Enable Redis Backend</label>
            </div>

            {formData.redis_enabled && (
              <div className="space-y-2 animate-in fade-in slide-in-from-top-2 duration-300">
                <label className="block text-xs uppercase tracking-wider text-gray-500">Redis URL</label>
                <input
                  type="text"
                  className="w-full p-4 text-sm"
                  value={formData.redis_url}
                  onChange={(e) => setFormData({ ...formData, redis_url: e.target.value })}
                  placeholder="redis://localhost:6379"
                />
              </div>
            )}
          </section>

          {/* Submission and Feedback */}
          <div className="pt-8">
            <button
              type="submit"
              disabled={status === "loading"}
              className="w-full py-5 text-sm uppercase tracking-widest font-semibold disabled:opacity-50"
            >
              {status === "loading" ? "Configuring..." : "Initialize Identity Provider"}
            </button>

            {message && (
              <div className={`mt-6 p-4 text-center text-sm border ${status === "success" ? "border-green-500 text-green-600" : "border-red-500 text-red-600"}`}>
                {message}
              </div>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
