import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",
  basePath: "/setup",
  trailingSlash: true,
};

export default nextConfig;
