import os
import secrets
from typing import Optional, Dict, Any, List
from pydantic import BaseSettings, Field, validator
from enum import Enum

class Environment(str, Enum):
    DEVELOPMENT = "development"
    TESTING = "testing"
    STAGING = "staging"
    PRODUCTION = "production"

class SecuritySettings(BaseSettings):
    """Production-grade security configuration with environment-based separation."""
    
    # Environment
    environment: Environment = Field(
        default=Environment.DEVELOPMENT,
        env="ENVIRONMENT"
    )
    
    debug: bool = Field(
        default=False,
        env="DEBUG"
    )
    
    # HTTPS and HSTS
    enforce_https: bool = Field(
        default=True,
        env="ENFORCE_HTTPS"
    )
    
    hsts_max_age: int = Field(
        default=31536000,  # 1 year
        env="HSTS_MAX_AGE"
    )
    
    hsts_include_subdomains: bool = Field(
        default=True,
        env="HSTS_INCLUDE_SUBDOMAINS"
    )
    
    hsts_preload: bool = Field(
        default=True,
        env="HSTS_PRELOAD"
    )
    
    # JWT Configuration
    jwt_algorithm: str = Field(
        default="RS256",
        env="JWT_ALGORITHM"
    )
    
    jwt_access_token_expire_minutes: int = Field(
        default=15,
        env="JWT_ACCESS_TOKEN_EXPIRE_MINUTES"
    )
    
    jwt_refresh_token_expire_days: int = Field(
        default=30,
        env="JWT_REFRESH_TOKEN_EXPIRE_DAYS"
    )
    
    jwt_issuer: str = Field(
        default="https://identity.example.com",
        env="JWT_ISSUER"
    )
    
    # Key Rotation
    key_rotation_days: int = Field(
        default=90,
        env="KEY_ROTATION_DAYS"
    )
    
    key_retention_days: int = Field(
        default=180,
        env="KEY_RETENTION_DAYS"
    )
    
    # Encryption
    encryption_key: str = Field(
        default="",
        env="ENCRYPTION_KEY",
        min_length=44  # Fernet key length
    )
    
    # Database
    database_url: str = Field(
        default="sqlite:///./identity.db",
        env="DATABASE_URL"
    )
    
    database_ssl_mode: str = Field(
        default="require",
        env="DATABASE_SSL_MODE"
    )
    
    database_pool_size: int = Field(
        default=20,
        env="DATABASE_POOL_SIZE"
    )
    
    # Redis
    redis_enabled: bool = Field(
        default=False,
        env="REDIS_ENABLED"
    )
    
    redis_url: Optional[str] = Field(
        default="redis://localhost:6379",
        env="REDIS_URL"
    )
    
    redis_password: Optional[str] = Field(
        default=None,
        env="REDIS_PASSWORD"
    )
    
    redis_ssl: bool = Field(
        default=False,
        env="REDIS_SSL"
    )
    
    # Rate Limiting
    rate_limit_global_requests: int = Field(
        default=1000,
        env="RATE_LIMIT_GLOBAL_REQUESTS"
    )
    
    rate_limit_global_window: int = Field(
        default=3600,
        env="RATE_LIMIT_GLOBAL_WINDOW"
    )
    
    rate_limit_auth_requests: int = Field(
        default=10,
        env="RATE_LIMIT_AUTH_REQUESTS"
    )
    
    rate_limit_auth_window: int = Field(
        default=300,
        env="RATE_LIMIT_AUTH_WINDOW"
    )
    
    # MFA
    mfa_lockout_max_attempts: int = Field(
        default=5,
        env="MFA_LOCKOUT_MAX_ATTEMPTS"
    )
    
    mfa_lockout_base_minutes: int = Field(
        default=15,
        env="MFA_LOCKOUT_BASE_MINUTES"
    )
    
    mfa_lockout_max_minutes: int = Field(
        default=1440,  # 24 hours
        env="MFA_LOCKOUT_MAX_MINUTES"
    )
    
    # CORS
    cors_origins: List[str] = Field(
        default=[],
        env="CORS_ORIGINS"
    )
    
    cors_allow_credentials: bool = Field(
        default=False,
        env="CORS_ALLOW_CREDENTIALS"
    )
    
    # Secret Management
    secret_provider: str = Field(
        default="environment",
        env="SECRET_PROVIDER"
    )
    
    vault_url: Optional[str] = Field(
        default=None,
        env="VAULT_URL"
    )
    
    vault_token: Optional[str] = Field(
        default=None,
        env="VAULT_TOKEN"
    )
    
    # Security Headers
    csp_enabled: bool = Field(
        default=True,
        env="CSP_ENABLED"
    )
    
    csp_report_only: bool = Field(
        default=False,
        env="CSP_REPORT_ONLY"
    )
    
    @validator("encryption_key")
    def validate_encryption_key(cls, v):
        if not v:
            if os.getenv("ENVIRONMENT") == "production":
                raise ValueError("ENCRYPTION_KEY must be set in production")
            # Generate key for non-production
            return secrets.token_urlsafe(32)
        return v
    
    @validator("database_url")
    def validate_database_url(cls, v):
        if os.getenv("ENVIRONMENT") == "production":
            if not v.startswith(("postgresql://", "mysql://")):
                raise ValueError("Production must use PostgreSQL or MySQL")
            if "ssl=" not in v and v.startswith("postgresql"):
                raise ValueError("Production database must use SSL")
        return v
    
    @validator("cors_origins", pre=True)
    def parse_cors_origins(cls, v):
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",")]
        return v
    
    @property
    def is_production(self) -> bool:
        return self.environment == Environment.PRODUCTION
    
    @property
    def is_development(self) -> bool:
        return self.environment == Environment.DEVELOPMENT
    
    def get_cors_origins(self) -> List[str]:
        """Get CORS origins based on environment."""
        if self.is_development:
            return ["http://localhost:3000", "http://localhost:8000"]
        return self.cors_origins
    
    def get_database_config(self) -> Dict[str, Any]:
        """Get database configuration with SSL settings."""
        config = {"url": self.database_url}
        
        if self.is_production and self.database_url.startswith("postgresql"):
            ssl_config = {
                "ssl": {
                    "sslmode": self.database_ssl_mode,
                    "sslcert": os.getenv("DATABASE_SSL_CERT"),
                    "sslkey": os.getenv("DATABASE_SSL_KEY"),
                    "sslrootcert": os.getenv("DATABASE_SSL_ROOT_CERT"),
                }
            }
            config.update(ssl_config)
        
        return config
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False

class LoggingSettings(BaseSettings):
    """Logging configuration with security considerations."""
    
    log_level: str = Field(
        default="INFO",
        env="LOG_LEVEL"
    )
    
    log_format: str = Field(
        default="json",
        env="LOG_FORMAT"
    )
    
    security_log_file: str = Field(
        default="logs/security.log",
        env="SECURITY_LOG_FILE"
    )
    
    audit_log_file: str = Field(
        default="logs/audit.log",
        env="AUDIT_LOG_FILE"
    )
    
    log_sensitive_data: bool = Field(
        default=False,
        env="LOG_SENSITIVE_DATA"
    )
    
    @validator("log_level")
    def validate_log_level(cls, v):
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in valid_levels:
            raise ValueError(f"Log level must be one of {valid_levels}")
        return v.upper()

# Global settings instances
security_settings = SecuritySettings()
logging_settings = LoggingSettings()

def get_settings() -> SecuritySettings:
    """Get global security settings."""
    return security_settings
