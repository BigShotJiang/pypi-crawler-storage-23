import os
import secrets
import json
import logging
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any
from cryptography.fernet import Fernet
import base64
import hashlib

# Try to import vault libraries
try:
    import hvac
    VAULT_AVAILABLE = True
except ImportError:
    VAULT_AVAILABLE = False

# Try to import AWS Secrets Manager
try:
    import boto3
    AWS_AVAILABLE = True
except ImportError:
    AWS_AVAILABLE = False

class SecretProvider(ABC):
    """Abstract base class for secret providers."""
    
    @abstractmethod
    async def get_secret(self, key: str) -> Optional[str]:
        """Retrieve a secret by key."""
        pass
    
    @abstractmethod
    async def store_secret(self, key: str, value: str) -> bool:
        """Store a secret by key."""
        pass
    
    @abstractmethod
    async def delete_secret(self, key: str) -> bool:
        """Delete a secret by key."""
        pass

class EnvironmentSecretProvider(SecretProvider):
    """Environment variable-based secret provider."""
    
    def __init__(self, prefix: str = "IDENTITY_"):
        self.prefix = prefix
        self.logger = logging.getLogger(__name__)
    
    async def get_secret(self, key: str) -> Optional[str]:
        """Get secret from environment variable."""
        env_key = f"{self.prefix}{key.upper()}"
        value = os.getenv(env_key)
        
        if value is None:
            self.logger.warning(f"Environment variable {env_key} not found")
        
        return value
    
    async def store_secret(self, key: str, value: str) -> bool:
        """Store secret in environment (not recommended for production)."""
        env_key = f"{self.prefix}{key.upper()}"
        os.environ[env_key] = value
        self.logger.info(f"Stored secret in environment: {env_key}")
        return True
    
    async def delete_secret(self, key: str) -> bool:
        """Delete secret from environment."""
        env_key = f"{self.prefix}{key.upper()}"
        if env_key in os.environ:
            del os.environ[env_key]
            self.logger.info(f"Deleted environment variable: {env_key}")
            return True
        return False

class VaultSecretProvider(SecretProvider):
    """HashiCorp Vault secret provider."""
    
    def __init__(self, vault_url: str, vault_token: str, mount_point: str = "secret"):
        if not VAULT_AVAILABLE:
            raise ImportError("hvac library is required for Vault integration")
        
        self.vault_url = vault_url
        self.vault_token = vault_token
        self.mount_point = mount_point
        self.client = hvac.Client(
            url=vault_url,
            token=vault_token
        )
        self.logger = logging.getLogger(__name__)
        
        # Test connection
        try:
            self.client.auth.token.lookup_self()
            self.logger.info("Vault connection established")
        except Exception as e:
            self.logger.error(f"Failed to connect to Vault: {e}")
            raise
    
    async def get_secret(self, key: str) -> Optional[str]:
        """Get secret from Vault."""
        try:
            secret_path = f"{self.mount_point}/identity/{key}"
            response = self.client.secrets.kv.v2.read_secret_version(
                path=secret_path
            )
            
            if response and 'data' in response and 'data' in response['data']:
                return response['data']['data'].get('value')
            
            return None
            
        except Exception as e:
            self.logger.error(f"Failed to get secret {key} from Vault: {e}")
            return None
    
    async def store_secret(self, key: str, value: str) -> bool:
        """Store secret in Vault."""
        try:
            secret_path = f"{self.mount_point}/identity/{key}"
            self.client.secrets.kv.v2.create_or_update_secret(
                path=secret_path,
                secret=dict(value=value)
            )
            self.logger.info(f"Stored secret in Vault: {key}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to store secret {key} in Vault: {e}")
            return False
    
    async def delete_secret(self, key: str) -> bool:
        """Delete secret from Vault."""
        try:
            secret_path = f"{self.mount_point}/identity/{key}"
            self.client.secrets.kv.v2.delete_metadata_and_all_versions(
                path=secret_path
            )
            self.logger.info(f"Deleted secret from Vault: {key}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to delete secret {key} from Vault: {e}")
            return False

class AWSSecretProvider(SecretProvider):
    """AWS Secrets Manager secret provider."""
    
    def __init__(self, region_name: str = "us-east-1"):
        if not AWS_AVAILABLE:
            raise ImportError("boto3 library is required for AWS Secrets Manager")
        
        self.region_name = region_name
        self.client = boto3.client('secretsmanager', region_name=region_name)
        self.logger = logging.getLogger(__name__)
    
    async def get_secret(self, key: str) -> Optional[str]:
        """Get secret from AWS Secrets Manager."""
        try:
            secret_name = f"identity/{key}"
            response = self.client.get_secret_value(SecretId=secret_name)
            
            if 'SecretString' in response:
                return response['SecretString']
            
            return None
            
        except Exception as e:
            self.logger.error(f"Failed to get secret {key} from AWS: {e}")
            return None
    
    async def store_secret(self, key: str, value: str) -> bool:
        """Store secret in AWS Secrets Manager."""
        try:
            secret_name = f"identity/{key}"
            self.client.create_secret(
                Name=secret_name,
                SecretString=value,
                Description=f"Identity provider secret: {key}"
            )
            self.logger.info(f"Stored secret in AWS: {key}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to store secret {key} in AWS: {e}")
            return False
    
    async def delete_secret(self, key: str) -> bool:
        """Delete secret from AWS Secrets Manager."""
        try:
            secret_name = f"identity/{key}"
            self.client.delete_secret(SecretId=secret_name, ForceDeleteWithoutRecovery=True)
            self.logger.info(f"Deleted secret from AWS: {key}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to delete secret {key} from AWS: {e}")
            return False

class SecretManager:
    """Production-grade secret management with multiple provider support."""
    
    def __init__(self, provider_type: str = "environment", **kwargs):
        self.provider_type = provider_type
        self.logger = logging.getLogger(__name__)
        
        # Initialize provider based on type
        if provider_type == "environment":
            self.provider = EnvironmentSecretProvider(**kwargs)
        elif provider_type == "vault":
            self.provider = VaultSecretProvider(**kwargs)
        elif provider_type == "aws":
            self.provider = AWSSecretProvider(**kwargs)
        else:
            raise ValueError(f"Unsupported secret provider: {provider_type}")
        
        self.logger.info(f"Initialized secret provider: {provider_type}")
    
    async def get_encryption_key(self) -> bytes:
        """Get or generate encryption key."""
        key = await self.provider.get_secret("ENCRYPTION_KEY")
        
        if not key:
            # Generate new key
            key = secrets.token_urlsafe(32)
            await self.provider.store_secret("ENCRYPTION_KEY", key)
            self.logger.info("Generated new encryption key")
        
        # Ensure proper Fernet key format
        if len(key) != 44:  # Fernet base64 key length
            # Hash and encode to proper length
            key_hash = hashlib.sha256(key.encode()).digest()
            key = base64.urlsafe_b64encode(key_hash).decode()
        
        return key.encode()
    
    async def get_jwt_signing_key(self) -> Optional[str]:
        """Get JWT signing key."""
        return await self.provider.get_secret("JWT_SIGNING_KEY")
    
    async def store_jwt_signing_key(self, key: str) -> bool:
        """Store JWT signing key."""
        return await self.provider.store_secret("JWT_SIGNING_KEY", key)
    
    async def get_database_password(self) -> Optional[str]:
        """Get database password."""
        return await self.provider.get_secret("DATABASE_PASSWORD")
    
    async def get_redis_password(self) -> Optional[str]:
        """Get Redis password."""
        return await self.provider.get_secret("REDIS_PASSWORD")
    
    async def rotate_secrets(self) -> Dict[str, bool]:
        """Rotate critical secrets."""
        results = {}
        
        # Rotate encryption key
        try:
            new_key = secrets.token_urlsafe(32)
            results["encryption_key"] = await self.provider.store_secret("ENCRYPTION_KEY", new_key)
        except Exception as e:
            self.logger.error(f"Failed to rotate encryption key: {e}")
            results["encryption_key"] = False
        
        return results
    
    async def audit_secrets(self) -> Dict[str, Any]:
        """Audit secret access and configuration."""
        audit_info = {
            "provider_type": self.provider_type,
            "timestamp": secrets.token_hex(16),
            "secrets_configured": []
        }
        
        # Check critical secrets
        critical_secrets = [
            "ENCRYPTION_KEY",
            "JWT_SIGNING_KEY",
            "DATABASE_PASSWORD"
        ]
        
        for secret_key in critical_secrets:
            try:
                value = await self.provider.get_secret(secret_key)
                if value:
                    audit_info["secrets_configured"].append(secret_key)
            except Exception as e:
                self.logger.error(f"Error checking secret {secret_key}: {e}")
        
        return audit_info

# Global secret manager instance
_secret_manager: Optional[SecretManager] = None

def get_secret_manager() -> SecretManager:
    """Get global secret manager instance."""
    global _secret_manager
    if _secret_manager is None:
        from .settings import security_settings
        
        # Initialize based on configuration
        if security_settings.secret_provider == "vault":
            _secret_manager = SecretManager(
                "vault",
                vault_url=security_settings.vault_url,
                vault_token=security_settings.vault_token
            )
        elif security_settings.secret_provider == "aws":
            _secret_manager = SecretManager("aws")
        else:
            _secret_manager = SecretManager("environment")
    
    return _secret_manager
