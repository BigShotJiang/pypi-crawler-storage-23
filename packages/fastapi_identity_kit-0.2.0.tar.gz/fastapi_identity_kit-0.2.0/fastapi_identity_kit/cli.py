#!/usr/bin/env python3
"""
FastAPI Identity Kit CLI - Interactive setup and configuration generator
"""

import os
import sys
import secrets
import json
from pathlib import Path
from typing import Dict, Any, Optional
import click
from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.table import Table
from rich.panel import Panel
from rich import print as rprint

console = Console()

@click.group()
@click.version_option()
def cli():
    """FastAPI Identity Kit CLI - Interactive setup and configuration"""
    pass

@cli.command()
@click.option('--output', '-o', default='identity_config.py', help='Output file for generated configuration')
@click.option('--force', '-f', is_flag=True, help='Overwrite existing files')
def init(output: str, force: bool):
    """Interactive setup for FastAPI Identity Provider"""
    
    console.print(Panel.fit(
        "[bold blue]FastAPI Identity Kit Setup[/bold blue]\n"
        "This wizard will help you configure your identity provider",
        title="Welcome"
    ))
    
    # Check if file exists
    if os.path.exists(output) and not force:
        if not Confirm.ask(f"File '{output}' already exists. Overwrite?"):
            console.print("[yellow]Setup cancelled.[/yellow]")
            return
    
    # Collect configuration
    config = collect_configuration()
    
    # Generate configuration file
    generate_config_file(config, output)
    
    # Generate main application file
    generate_main_file(config)
    
    # Generate requirements
    generate_requirements(config)
    
    # Generate Docker files (optional)
    if config.get('docker', {}).get('enabled'):
        generate_docker_files(config)
    
    # Print summary
    print_summary(config, output)

def collect_configuration() -> Dict[str, Any]:
    """Collect configuration from user interactively"""
    config = {}
    
    # Basic Configuration
    console.print("\n[bold]🔧 Basic Configuration[/bold]")
    config['app_name'] = Prompt.ask("Application name", default="My Identity Provider")
    config['secret_key'] = Prompt.ask("Secret key", default=secrets.token_urlsafe(32))
    
    # Database Configuration
    console.print("\n[bold]🗄️ Database Configuration[/bold]")
    db_type = Prompt.ask("Database type", choices=["postgresql", "sqlite", "mysql"], default="postgresql")
    
    if db_type == "sqlite":
        config['database_url'] = "sqlite:///./identity.db"
        config['redis_enabled'] = False
    else:
        host = Prompt.ask("Database host", default="localhost")
        port = Prompt.ask("Database port", default="5432")
        name = Prompt.ask("Database name", default="identity")
        user = Prompt.ask("Database user", default="postgres")
        password = Prompt.ask("Database password", password=True)
        
        config['database_url'] = f"{db_type}://{user}:{password}@{host}:{port}/{name}"
        
        # Redis Configuration (optional)
        console.print("\n[bold]🔴 Redis Configuration (Optional)[/bold]")
        config['redis_enabled'] = Confirm.ask("Enable Redis for caching and sessions?", default=True)
        
        if config['redis_enabled']:
            redis_host = Prompt.ask("Redis host", default="localhost")
            redis_port = Prompt.ask("Redis port", default="6379")
            redis_password = Prompt.ask("Redis password", password=True, default="")
            
            if redis_password:
                config['redis_url'] = f"redis://:{redis_password}@{redis_host}:{redis_port}/0"
            else:
                config['redis_url'] = f"redis://{redis_host}:{redis_port}/0"
    
    # Security Configuration
    console.print("\n[bold]🔒 Security Configuration[/bold]")
    config['enforce_https'] = Confirm.ask("Enforce HTTPS in production?", default=True)
    config['jwt_expiry_minutes'] = int(Prompt.ask("JWT expiry (minutes)", default="60"))
    config['refresh_token_days'] = int(Prompt.ask("Refresh token expiry (days)", default="30"))
    
    # MFA Configuration
    console.print("\n[bold]🔐 Multi-Factor Authentication[/bold]")
    config['mfa_enabled'] = Confirm.ask("Enable MFA (TOTP)?", default=True)
    if config['mfa_enabled']:
        config['mfa_issuer'] = Prompt.ask("MFA issuer name", default=config['app_name'])
    
    # Rate Limiting
    console.print("\n[bold]⚡ Rate Limiting[/bold]")
    config['rate_limiting_enabled'] = Confirm.ask("Enable rate limiting?", default=True)
    if config['rate_limiting_enabled']:
        config['rate_limit_requests'] = int(Prompt.ask("Requests per window", default="100"))
        config['rate_limit_window'] = int(Prompt.ask("Window (seconds)", default="3600"))
    
    # Secret Management
    console.print("\n[bold]🗝️ Secret Management[/bold]")
    config['secret_provider'] = Prompt.ask(
        "Secret provider", 
        choices=["environment", "vault", "aws"], 
        default="environment"
    )
    
    if config['secret_provider'] == "vault":
        config['vault_url'] = Prompt.ask("Vault URL", default="https://vault.example.com")
        config['vault_token'] = Prompt.ask("Vault token", password=True)
    elif config['secret_provider'] == "aws":
        config['aws_region'] = Prompt.ask("AWS region", default="us-east-1")
    
    # Key Rotation
    console.print("\n[bold]🔄 Key Rotation[/bold]")
    config['key_rotation_enabled'] = Confirm.ask("Enable automatic key rotation?", default=True)
    if config['key_rotation_enabled']:
        config['key_rotation_hours'] = int(Prompt.ask("Rotation interval (hours)", default="24"))
    
    # Database Encryption
    console.print("\n[bold]🔐 Database Encryption[/bold]")
    config['db_encryption_enabled'] = Confirm.ask("Enable database encryption?", default=True)
    if config['db_encryption_enabled']:
        config['encryption_key'] = Prompt.ask("Encryption key", default=secrets.token_urlsafe(32))
    
    # Docker Configuration
    console.print("\n[bold]🐳 Docker Configuration[/bold]")
    config['docker'] = {}
    config['docker']['enabled'] = Confirm.ask("Generate Docker files?", default=True)
    if config['docker']['enabled']:
        config['docker']['nginx'] = Confirm.ask("Include Nginx reverse proxy?", default=False)
    
    return config

def generate_config_file(config: Dict[str, Any], output: str):
    """Generate the configuration file"""
    
    config_content = f'''"""
FastAPI Identity Provider Configuration
Generated by FastAPI Identity Kit CLI
"""

# Configuration
config = {{
    # Basic Configuration
    "app_name": "{config['app_name']}",
    "secret_key": "{config['secret_key']}",
    
    # Database Configuration
    "database_url": "{config['database_url']}",
'''
    
    if config.get('redis_enabled'):
        config_content += f'''    "redis_url": "{config['redis_url']}",
    "redis_enabled": True,
'''
    else:
        config_content += '''    "redis_enabled": False,
    "redis_url": None,
'''
    
    config_content += f'''
    # Security Configuration
    "enforce_https": {config['enforce_https'].lower()},
    "jwt_expiry_minutes": {config['jwt_expiry_minutes']},
    "refresh_token_days": {config['refresh_token_days']},
'''
    
    if config.get('mfa_enabled'):
        config_content += f'''    
    # MFA Configuration
    "mfa_enabled": True,
    "mfa_issuer": "{config['mfa_issuer']}",
'''
    
    if config.get('rate_limiting_enabled'):
        config_content += f'''    
    # Rate Limiting
    "rate_limiting_enabled": True,
    "rate_limit_requests": {config['rate_limit_requests']},
    "rate_limit_window": {config['rate_limit_window']},
'''
    
    config_content += f'''    
    # Secret Management
    "secret_provider": "{config['secret_provider']}",
'''
    
    if config['secret_provider'] == 'vault':
        config_content += f'''    "vault_url": "{config['vault_url']}",
    "vault_token": "{config['vault_token']}",
'''
    elif config['secret_provider'] == 'aws':
        config_content += f'''    "aws_region": "{config['aws_region']}",
'''
    
    if config.get('key_rotation_enabled'):
        config_content += f'''    
    # Key Rotation
    "key_rotation_enabled": True,
    "key_rotation_interval_hours": {config['key_rotation_hours']},
'''
    
    if config.get('db_encryption_enabled'):
        config_content += f'''    
    # Database Encryption
    "database_encryption_enabled": True,
    "encryption_key": "{config['encryption_key']}",
'''
    
    config_content += '''
}

# Environment variables for production
import os

# Override with environment variables in production
if os.getenv("ENVIRONMENT") == "production":
    config["database_url"] = os.getenv("DATABASE_URL", config["database_url"])
    config["secret_key"] = os.getenv("SECRET_KEY", config["secret_key"])
    if config.get("redis_url"):
        config["redis_url"] = os.getenv("REDIS_URL", config["redis_url"])
'''
    
    # Write configuration file
    with open(output, 'w') as f:
        f.write(config_content)
    
    console.print(f"[green]✓[/green] Configuration saved to {output}")

def generate_main_file(config: Dict[str, Any]):
    """Generate the main application file"""
    
    main_content = f'''"""
Main application file for FastAPI Identity Provider
Generated by FastAPI Identity Kit CLI
"""

from fastapi import FastAPI
from fastapi_identity_kit.app_factory import create_identity_app
import config

# Create the identity provider application
app = create_identity_app(config=config)

# Add custom routes if needed
@app.get("/")
async def root():
    return {{
        "message": "Welcome to {config['app_name']}",
        "version": "1.0.0",
        "endpoints": {{
            "oauth": "/oauth",
            "auth": "/auth",
            "health": "/health",
            "openid_configuration": "/.well-known/openid-configuration"
        }}
    }}

@app.get("/health")
async def health_check():
    return {{
        "status": "healthy",
        "app": "{config['app_name']}"
    }}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
'''
    
    with open('main.py', 'w') as f:
        f.write(main_content)
    
    console.print("[green]✓[/green] Main application file created: main.py")

def generate_requirements(config: Dict[str, Any]):
    """Generate requirements.txt file"""
    
    requirements = [
        "fastapi-identity-kit",
        "uvicorn[standard]",
        "python-multipart",
    ]
    
    # Add database-specific requirements
    if "postgresql" in config['database_url']:
        requirements.append("psycopg2-binary")
    elif "mysql" in config['database_url']:
        requirements.append("mysqlclient")
    
    # Add Redis if enabled
    if config.get('redis_enabled'):
        requirements.append("redis")
    
    # Add secret management dependencies
    if config['secret_provider'] == 'vault':
        requirements.append("hvac")
    elif config['secret_provider'] == 'aws':
        requirements.append("boto3")
    
    # Add MFA dependencies
    if config.get('mfa_enabled'):
        requirements.append("pyotp")
        requirements.append("qrcode[pil]")
    
    # Add rate limiting dependencies
    if config.get('rate_limiting_enabled'):
        requirements.append("slowapi")
    
    with open('requirements.txt', 'w') as f:
        f.write('\n'.join(requirements))
    
    console.print("[green]✓[/green] Requirements file created: requirements.txt")

def generate_docker_files(config: Dict[str, Any]):
    """Generate Docker configuration files"""
    
    # Dockerfile
    dockerfile_content = f'''FROM python:3.11-slim

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    gcc \\
    libpq-dev \\
    && rm -rf /var/lib/apt/lists/*

# Install uv for faster package management
RUN pip install uv

# Set working directory
WORKDIR /app

# Copy requirements
COPY requirements.txt .
RUN uv pip install --no-cache -r requirements.txt

# Copy application
COPY . .

# Create non-root user
RUN useradd --create-home --shell /bin/bash app
RUN chown -R app:app /app
USER app

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \\
    CMD curl -f http://localhost:8000/health || exit 1

# Expose port
EXPOSE 8000

# Run application
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
'''
    
    with open('Dockerfile', 'w') as f:
        f.write(dockerfile_content)
    
    # docker-compose.yml
    compose_content = f'''version: '3.8'

services:
  app:
    build: .
    ports: ["8000:8000"]
    environment:
      - ENVIRONMENT=production
      - DATABASE_URL={config['database_url']}'''
    
    if config.get('redis_enabled'):
        compose_content += f'''
      - REDIS_URL={config['redis_url']}'''
    
    compose_content += '''
      - SECRET_KEY=${SECRET_KEY}
    depends_on:'''
    
    if "postgresql" in config['database_url']:
        compose_content += '''
      - db'''
    
    if config.get('redis_enabled'):
        compose_content += '''
      - redis'''
    
    if "postgresql" in config['database_url']:
        compose_content += '''

  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=identity
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=${DB_PASSWORD}
    volumes: ["postgres_data:/var/lib/postgresql/data"]
'''
    
    if config.get('redis_enabled'):
        compose_content += '''
  redis:
    image: redis:7-alpine
    volumes: ["redis_data:/data"]
'''
    
    if "postgresql" in config['database_url']:
        compose_content += '''
volumes:
  postgres_data:'''
    
    if config.get('redis_enabled'):
        compose_content += '''
  redis_data:'''
    
    with open('docker-compose.yml', 'w') as f:
        f.write(compose_content)
    
    # .env.example
    env_content = f'''# Environment Variables
SECRET_KEY={config['secret_key']}
DATABASE_URL={config['database_url']}'''
    
    if config.get('redis_enabled'):
        env_content += f'''
REDIS_URL={config['redis_url']}'''
    
    env_content += '''
ENVIRONMENT=production'''
    
    if "postgresql" in config['database_url']:
        env_content += '''
DB_PASSWORD=your_secure_password'''
    
    with open('.env.example', 'w') as f:
        f.write(env_content)
    
    console.print("[green]✓[/green] Docker files created: Dockerfile, docker-compose.yml, .env.example")

def print_summary(config: Dict[str, Any], output_file: str):
    """Print setup summary"""
    
    console.print("\n" + "="*60)
    console.print("[bold green]🎉 Setup Complete![/bold green]")
    console.print("="*60)
    
    # Create summary table
    table = Table(title="Configuration Summary")
    table.add_column("Setting", style="cyan")
    table.add_column("Value", style="green")
    
    table.add_row("App Name", config['app_name'])
    table.add_row("Database", config['database_url'].split('://')[0].upper())
    table.add_row("Redis", "Enabled" if config.get('redis_enabled') else "Disabled")
    table.add_row("MFA", "Enabled" if config.get('mfa_enabled') else "Disabled")
    table.add_row("Rate Limiting", "Enabled" if config.get('rate_limiting_enabled') else "Disabled")
    table.add_row("Key Rotation", "Enabled" if config.get('key_rotation_enabled') else "Disabled")
    table.add_row("DB Encryption", "Enabled" if config.get('db_encryption_enabled') else "Disabled")
    table.add_row("Secret Provider", config['secret_provider'])
    
    console.print(table)
    
    # Next steps
    console.print("\n[bold]🚀 Next Steps:[/bold]")
    console.print("1. Review the generated configuration files")
    console.print("2. Install dependencies:")
    console.print("   [cyan]uv add -r requirements.txt[/cyan]")
    console.print("3. Set up your database")
    console.print("4. Run the application:")
    console.print("   [cyan]uvicorn main:app --reload[/cyan]")
    console.print("5. Visit http://localhost:8000 to get started")
    
    if config.get('docker', {}).get('enabled'):
        console.print("\n[bold]🐳 Docker Usage:[/bold]")
        console.print("1. Copy .env.example to .env and update values")
        console.print("2. Run with Docker Compose:")
        console.print("   [cyan]docker-compose up -d[/cyan]")
    
    console.print(f"\n[bold]📁 Generated Files:[/bold]")
    console.print(f"• {output_file} - Main configuration")
    console.print("• main.py - Application entry point")
    console.print("• requirements.txt - Python dependencies")
    
    if config.get('docker', {}).get('enabled'):
        console.print("• Dockerfile - Container configuration")
        console.print("• docker-compose.yml - Multi-container setup")
        console.print("• .env.example - Environment variables template")

@cli.command()
def doctor():
    """Check system requirements and dependencies"""
    
    console.print("[bold]🔍 System Check[/bold]\n")
    
    # Check Python version
    import sys
    python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    console.print(f"Python: {python_version}")
    
    if sys.version_info < (3, 11):
        console.print("[red]❌ Python 3.11+ required[/red]")
    else:
        console.print("[green]✓ Python version OK[/green]")
    
    # Check uv
    try:
        import subprocess
        result = subprocess.run(['uv', '--version'], capture_output=True, text=True)
        if result.returncode == 0:
            console.print(f"uv: {result.stdout.strip()}")
            console.print("[green]✓ uv installed[/green]")
        else:
            console.print("[yellow]⚠ uv not found (pip will be used)[/yellow]")
    except FileNotFoundError:
        console.print("[yellow]⚠ uv not found (pip will be used)[/yellow]")
    
    # Check database connectivity
    console.print("\n[bold]Database Connectivity:[/bold]")
    console.print("[yellow]⚠ Run 'uvicorn main:app' to test database connectivity[/yellow]")

if __name__ == "__main__":
    cli()
