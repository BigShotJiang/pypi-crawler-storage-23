import uuid
import logging
from typing import Callable
from fastapi import Request, HTTPException, status, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from .rbac import RBACService

# Configure basic audit logger
audit_logger = logging.getLogger("identity_audit")

# Simulated database dependency for the template
async def get_db_session() -> AsyncSession:
    raise NotImplementedError("Implement db session injection")

# Simulated User extraction dependency
async def get_current_user_id(request: Request) -> uuid.UUID:
    """Should extract user_id from the validated JWT token."""
    raise NotImplementedError("Implement user extraction")

# Simulated Tenant extraction dependency
async def get_tenant_id(request: Request) -> uuid.UUID:
    """Should extract tenant_id from JWT or X-Tenant-ID header."""
    raise NotImplementedError("Implement tenant extraction")


class RequirePermission:
    """
    FastAPI Route Dependency for enforcing granular RBAC rules.
    Automatically handles audit logging on authorization denials.
    
    Usage:
    @router.get("/users")
    async def list_users(auth=Depends(RequirePermission("users:read"))):
        ...
    """
    
    def __init__(self, required_permission: str):
        self.required_permission = required_permission

    async def __call__(
        self,
        request: Request,
        db_session: AsyncSession = Depends(get_db_session),
        user_id: uuid.UUID = Depends(get_current_user_id),
        tenant_id: uuid.UUID = Depends(get_tenant_id)
    ):
        
        # 1. Resolve Authorization
        is_authorized = await RBACService.has_permission(
            db_session, user_id=user_id, tenant_id=tenant_id, required_permission=self.required_permission
        )
        
        # 2. Audit and Enforce
        if not is_authorized:
            audit_logger.warning(
                f"AUDIT_AUTHZ_FAILURE: User {user_id} denied access to {request.url.path} "
                f"in Tenant {tenant_id}. Missing permission: {self.required_permission}"
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient permissions to perform this action."
            )
            
        # Optional: Audit success on highly privileged routes can be added here
        return True
