import uuid
from typing import Set, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from .models import Role, Permission, RolePermission, UserRole

class RBACService:
    """
    Engine for resolving and validating a user's absolute permission set, flattening any role hierarchies.
    """
    
    @staticmethod
    async def get_user_roles(db_session: AsyncSession, user_id: uuid.UUID, tenant_id: uuid.UUID) -> List[Role]:
        """Fetches all explicit roles assigned to a user in a given tenant.
        CRITICAL: Validates that user belongs to the tenant.
        """
        # First validate user belongs to tenant
        from fastapi_identity_kit.identity_core.models import UserTenant
        
        user_tenant_result = await db_session.execute(
            select(UserTenant).where(
                UserTenant.user_id == user_id,
                UserTenant.tenant_id == tenant_id
            )
        )
        user_tenant = user_tenant_result.scalars().first()
        
        if not user_tenant:
            # User doesn't belong to this tenant
            return []
        
        result = await db_session.execute(
            select(Role)
            .join(UserRole, UserRole.role_id == Role.id)
            .where(
                UserRole.user_id == user_id, 
                Role.tenant_id == tenant_id,
                Role.is_active == True  # Only active roles
            )
        )
        return list(result.scalars().all())

    @staticmethod
    async def get_role_hierarchy(db_session: AsyncSession, starting_role_ids: List[uuid.UUID]) -> Set[uuid.UUID]:
        """
        Recursively resolves all role IDs a user effectively holds via parent relationships.
        (e.g., Admin -> Manager -> User)
        """
        resolved_roles = set(starting_role_ids)
        queue = list(starting_role_ids)
        
        while queue:
            current_id = queue.pop(0)
            # Find any roles where the parent is the current_id
            # Wait, standard inheritance: A 'Manager' role inherits 'User'. 
            # So if user has Manager, they also get User's permissions. 
            # Therefore, we traverse UP the tree (getting the parent).
            
            result = await db_session.execute(select(Role.parent_id).where(Role.id == current_id))
            parent_id = result.scalar()
            
            if parent_id and parent_id not in resolved_roles:
                resolved_roles.add(parent_id)
                queue.append(parent_id)
                
        return resolved_roles

    @staticmethod
    async def get_user_permissions(db_session: AsyncSession, user_id: uuid.UUID, tenant_id: uuid.UUID) -> Set[str]:
        """
        Returns a flat set of all permission strings (e.g., {'users:read', 'billing:write'}) 
        granted to the user in the specified tenant context.
        """
        explicit_roles = await RBACService.get_user_roles(db_session, user_id, tenant_id)
        if not explicit_roles:
            return set()
            
        role_ids = [r.id for r in explicit_roles]
        all_role_ids = await RBACService.get_role_hierarchy(db_session, role_ids)
        
        # Fetch bound permissions
        result = await db_session.execute(
            select(Permission.name)
            .join(RolePermission, RolePermission.permission_id == Permission.id)
            .where(RolePermission.role_id.in_(all_role_ids))
        )
        
        return set(result.scalars().all())

    @staticmethod
    async def has_permission(db_session: AsyncSession, user_id: uuid.UUID, tenant_id: uuid.UUID, required_permission: str) -> bool:
        """
        Single-shot check answering if a user has a specific granular permission.
        Includes tenant isolation validation.
        """
        # First validate user belongs to tenant
        from fastapi_identity_kit.identity_core.models import UserTenant
        
        user_tenant_result = await db_session.execute(
            select(UserTenant).where(
                UserTenant.user_id == user_id,
                UserTenant.tenant_id == tenant_id
            )
        )
        user_tenant = user_tenant_result.scalars().first()
        
        if not user_tenant:
            # User doesn't belong to this tenant - deny access
            return False
        
        permissions = await RBACService.get_user_permissions(db_session, user_id, tenant_id)
        return required_permission in permissions
