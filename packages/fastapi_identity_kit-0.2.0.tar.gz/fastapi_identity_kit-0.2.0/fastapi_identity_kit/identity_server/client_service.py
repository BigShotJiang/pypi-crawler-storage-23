import secrets
import hashlib
import hmac
from typing import Optional, Tuple
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from fastapi import HTTPException, status
from .client_models import OAuthClient
from fastapi_identity_kit.shared_security import constant_time_compare

class ClientAuthService:
    """
    Handles OAuth2 client authentication and validation.
    Supports client_secret_basic and client_secret_post methods.
    """
    
    @staticmethod
    def generate_client_credentials() -> Tuple[str, str]:
        """
        Generates secure client credentials.
        Returns (client_id, client_secret)
        """
        client_id = secrets.token_urlsafe(32)
        client_secret = secrets.token_urlsafe(64)
        return client_id, client_secret
    
    @staticmethod
    def hash_client_secret(client_secret: str) -> str:
        """Hashes client secret for secure storage."""
        return hashlib.sha256(client_secret.encode('utf-8')).hexdigest()
    
    @staticmethod
    async def authenticate_client(
        db_session: AsyncSession,
        client_id: str,
        client_secret: Optional[str] = None,
        auth_method: str = "client_secret_post"
    ) -> OAuthClient:
        """
        Authenticates an OAuth2 client.
        Raises HTTPException if authentication fails.
        """
        # Fetch client
        result = await db_session.execute(
            select(OAuthClient).where(
                OAuthClient.client_id == client_id,
                OAuthClient.is_active == True
            )
        )
        client = result.scalars().first()
        
        if not client:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={"error": "invalid_client", "error_description": "Client not found or inactive"}
            )
        
        # Validate authentication method
        if auth_method not in ["client_secret_basic", "client_secret_post", "none"]:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={"error": "invalid_client", "error_description": "Unsupported authentication method"}
            )
        
        # Skip secret validation for 'none' method (public clients)
        if auth_method != "none":
            if not client_secret:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail={"error": "invalid_client", "error_description": "Client secret required"}
                )
            
            # Verify client secret
            expected_hash = client.client_secret_hash
            actual_hash = hashlib.sha256(client_secret.encode('utf-8')).hexdigest()
            
            if not hmac.compare_digest(expected_hash, actual_hash):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail={"error": "invalid_client", "error_description": "Invalid client credentials"}
                )
        
        return client
    
    @staticmethod
    async def validate_redirect_uri(
        db_session: AsyncSession,
        client_id: str,
        redirect_uri: str
    ) -> bool:
        """
        Validates that the redirect URI is registered for the client.
        Implements exact match and fragment validation per RFC 6749.
        """
        result = await db_session.execute(
            select(OAuthClient.redirect_uris).where(
                OAuthClient.client_id == client_id,
                OAuthClient.is_active == True
            )
        )
        client = result.scalars().first()
        
        if not client:
            return False
        
        # Exact match validation
        if redirect_uri in client.redirect_uris:
            return True
        
        # Check for fragment manipulation (security measure)
        if '#' in redirect_uri:
            base_uri = redirect_uri.split('#')[0]
            if base_uri in client.redirect_uris:
                return True
        
        return False
    
    @staticmethod
    async def validate_grant_type(
        db_session: AsyncSession,
        client_id: str,
        grant_type: str
    ) -> bool:
        """Validates that the client is allowed to use the specified grant type."""
        result = await db_session.execute(
            select(OAuthClient.allowed_grant_types).where(
                OAuthClient.client_id == client_id,
                OAuthClient.is_active == True
            )
        )
        client = result.scalars().first()
        
        if not client:
            return False
        
        return grant_type in client.allowed_grant_types
