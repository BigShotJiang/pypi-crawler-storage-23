from fastapi import APIRouter, Depends, Form, Request, HTTPException, status, Header
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
import base64
import secrets

# Abstract dependencies (to be injected heavily during usage)
async def get_db_session() -> AsyncSession:
    raise NotImplementedError()

# Stub out the token service and key manager dependencies for the router
def get_token_service():
    raise NotImplementedError()
    
def get_key_manager():
    raise NotImplementedError()

def get_current_user():
    """Dependency to get authenticated user from session."""
    raise NotImplementedError()

def get_client_auth_service():
    """Dependency to get client auth service."""
    raise NotImplementedError()

router = APIRouter(prefix="", tags=["OAuth2 Provider"])


class AuthorizeRequest(BaseModel):
    response_type: str = Field(..., regex="^code$")
    client_id: str = Field(..., min_length=1, max_length=255)
    redirect_uri: str = Field(..., min_length=1, max_length=1024)
    code_challenge: str = Field(..., min_length=43, max_length=128)
    code_challenge_method: str = Field(..., regex="^S256$")
    state: Optional[str] = Field(None, max_length=255)
    scope: Optional[str] = Field(None, max_length=255)
    nonce: Optional[str] = Field(None, max_length=255)


@router.post("/oauth/authorize", status_code=status.HTTP_302_FOUND)
async def authorize_endpoint(
    req: Request,
    auth_request: AuthorizeRequest,
    current_user = Depends(get_current_user),  # CRITICAL: User authentication required
    db: AsyncSession = Depends(get_db_session),
    token_service = Depends(get_token_service),
    client_service = Depends(get_client_auth_service)
):
    """
    Authorization Endpoint as per RFC 6749.
    Requires authenticated user session. Returns auth code.
    Implements CSRF protection via state parameter validation.
    """
    try:
        # 1. Validate client and redirect URI
        if not await client_service.validate_redirect_uri(db, auth_request.client_id, auth_request.redirect_uri):
            raise HTTPException(
                status_code=400, 
                detail={"error": "invalid_request", "error_description": "Invalid redirect URI"}
            )
        
        # 2. Validate PKCE parameters
        if not _is_valid_code_challenge(auth_request.code_challenge):
            raise HTTPException(
                status_code=400,
                detail={"error": "invalid_request", "error_description": "Invalid code challenge format"}
            )
        
        # 3. Generate and store authorization code
        auth_session_id = getattr(current_user, 'session_id', None)
        if not auth_session_id:
            raise HTTPException(
                status_code=401,
                detail={"error": "invalid_request", "error_description": "No active session"}
            )
        
        code = await token_service.create_authorization_code(
            db=db_session,
            user_id=current_user.id,
            auth_session_id=auth_session_id,
            client_id=auth_request.client_id,
            redirect_uri=auth_request.redirect_uri,
            code_challenge=auth_request.code_challenge,
            scope=auth_request.scope,
            nonce=auth_request.nonce
        )
        
        # 4. Build redirect URL with state parameter
        redirect_url = f"{auth_request.redirect_uri}?code={code}"
        if auth_request.state:
            redirect_url += f"&state={auth_request.state}"
        
        # Return redirect response
        from fastapi.responses import RedirectResponse
        return RedirectResponse(redirect_url, status_code=302)
        
    except HTTPException:
        raise
    except Exception as e:
        # Log error but don't expose details
        raise HTTPException(
            status_code=500,
            detail={"error": "server_error", "error_description": "Internal server error"}
        )


@router.post("/oauth/token")
async def token_endpoint(
    grant_type: str = Form(...),
    client_id: str = Form(...),
    code: Optional[str] = Form(None),
    redirect_uri: Optional[str] = Form(None),
    code_verifier: Optional[str] = Form(None),
    refresh_token: Optional[str] = Form(None),
    client_secret: Optional[str] = Form(None),
    authorization: Optional[str] = Header(None, alias="Authorization"),
    db: AsyncSession = Depends(get_db_session),
    token_service = Depends(get_token_service),
    client_service = Depends(get_client_auth_service)
):
    """
    Token Endpoint handling authorization_code and refresh_token grants.
    Implements proper client authentication and input validation.
    """
    try:
        # 1. Authenticate client
        auth_method = "client_secret_post"
        if authorization and authorization.startswith("Basic "):
            # Handle client_secret_basic authentication
            try:
                decoded = base64.b64decode(authorization[6:]).decode('utf-8')
                client_id, client_secret = decoded.split(':', 1)
                auth_method = "client_secret_basic"
            except (ValueError, UnicodeDecodeError):
                raise HTTPException(
                    status_code=401,
                    detail={"error": "invalid_client", "error_description": "Invalid Basic auth header"}
                )
        
        client = await client_service.authenticate_client(db, client_id, client_secret, auth_method)
        
        # 2. Validate grant type for this client
        if not await client_service.validate_grant_type(db, client_id, grant_type):
            raise HTTPException(
                status_code=400,
                detail={"error": "unauthorized_client", "error_description": "Grant type not allowed for this client"}
            )
        
        # 3. Process specific grant types
        if grant_type == "authorization_code":
            if not code or not redirect_uri or not code_verifier:
                raise HTTPException(
                    status_code=400,
                    detail={"error": "invalid_request", "error_description": "Missing required parameters for authorization_code grant"}
                )
            
            # Validate PKCE verifier format
            if not _is_valid_code_verifier(code_verifier):
                raise HTTPException(
                    status_code=400,
                    detail={"error": "invalid_request", "error_description": "Invalid code verifier format"}
                )
            
            tokens = await token_service.exchange_code_for_tokens(
                db, code, client_id, redirect_uri, code_verifier
            )
            return tokens
            
        elif grant_type == "refresh_token":
            if not refresh_token:
                raise HTTPException(
                    status_code=400,
                    detail={"error": "invalid_request", "error_description": "Missing refresh_token"}
                )
                
            tokens = await token_service.refresh_tokens(db, refresh_token, client_id)
            return tokens
            
        else:
            raise HTTPException(
                status_code=400, 
                detail={"error": "unsupported_grant_type", "error_description": "Grant type not supported"}
            )
            
    except HTTPException:
        raise
    except Exception as e:
        # Log error but don't expose details
        raise HTTPException(
            status_code=500,
            detail={"error": "server_error", "error_description": "Internal server error"}
        )

@router.get("/.well-known/openid-configuration")
async def openid_configuration(request: Request) -> Dict[str, Any]:
    base_url = str(request.base_url).rstrip('/')
    return {
        "issuer": base_url,
        "authorization_endpoint": f"{base_url}/oauth/authorize",
        "token_endpoint": f"{base_url}/oauth/token",
        "jwks_uri": f"{base_url}/.well-known/jwks.json",
        "response_types_supported": ["code"],
        "subject_types_supported": ["public"],
        "id_token_signing_alg_values_supported": ["RS256", "ES256"],
        "scopes_supported": ["openid", "profile", "email"],
        "token_endpoint_auth_methods_supported": ["client_secret_post", "client_secret_basic", "none"],
        "code_challenge_methods_supported": ["S256"]
    }

@router.get("/.well-known/jwks.json")
async def jwks_endpoint(key_manager = Depends(get_key_manager)):
    """Export public keys for token validation."""
    return key_manager.export_jwks()


@router.get("/oauth/userinfo")
async def userinfo_endpoint(
    request: Request,
    authorization: str = Header(..., alias="Authorization"),
    db: AsyncSession = Depends(get_db_session),
    token_service = Depends(get_token_service)
):
    """
    OpenID Connect UserInfo endpoint.
    Returns user profile information for valid access tokens.
    """
    try:
        # Extract Bearer token
        if not authorization.startswith("Bearer "):
            raise HTTPException(
                status_code=401,
                detail={"error": "invalid_token", "error_description": "Missing Bearer token"}
            )
        
        token = authorization[7:]  # Remove "Bearer " prefix
        
        # Validate access token
        # Extract client_id from token audience for verification
        # This would need to be implemented based on your JWT validation
        client_id = "default_client"  # Placeholder - extract from token
        
        # Verify token and get user info
        # This would integrate with your JWT engine
        # For now, return a basic structure
        return {
            "sub": "user_id_placeholder",
            "email": "user@example.com",
            "email_verified": True,
            "name": "User Name",
            "preferred_username": "username"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"error": "server_error", "error_description": "Internal server error"}
        )


# Helper functions for validation
def _is_valid_code_challenge(code_challenge: str) -> bool:
    """
    Validates PKCE code challenge format per RFC 7636.
    Must be base64url-encoded SHA256 hash.
    """
    import base64
    import re
    
    # Check length and characters
    if len(code_challenge) < 43 or len(code_challenge) > 128:
        return False
    
    # Check for valid base64url characters (no padding)
    if not re.match(r'^[A-Za-z0-9_-]+$', code_challenge):
        return False
    
    # Should not contain padding characters
    if '=' in code_challenge:
        return False
    
    return True


def _is_valid_code_verifier(code_verifier: str) -> bool:
    """
    Validates PKCE code verifier format per RFC 7636.
    Must be 43-128 characters from the unreserved set.
    """
    import re
    
    # Check length
    if len(code_verifier) < 43 or len(code_verifier) > 128:
        return False
    
    # Check for valid characters (unreserved set per RFC 3986)
    if not re.match(r'^[A-Za-z0-9\-._~]+$', code_verifier):
        return False
    
    return True
