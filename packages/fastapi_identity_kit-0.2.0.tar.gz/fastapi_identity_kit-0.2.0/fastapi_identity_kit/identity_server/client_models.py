import uuid
from datetime import datetime, timezone
from typing import Optional, List
from sqlalchemy import String, Boolean, DateTime, ForeignKey, Text, ARRAY
from sqlalchemy.orm import Mapped, mapped_column, relationship
from fastapi_identity_kit.identity_core.models import Base
from sqlalchemy.sql import func

class OAuthClient(Base):
    """
    OAuth2 Client registration and authentication.
    Supports client_secret_basic and client_secret_post authentication methods.
    """
    __tablename__ = "oauth_clients"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    client_id: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    client_secret_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    
    client_name: Mapped[str] = mapped_column(String(255), nullable=False)
    client_uri: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # OAuth2 configuration
    redirect_uris: Mapped[List[str]] = mapped_column(ARRAY(String), nullable=False)
    allowed_grant_types: Mapped[List[str]] = mapped_column(ARRAY(String), default=["authorization_code", "refresh_token"])
    allowed_response_types: Mapped[List[str]] = mapped_column(ARRAY(String), default=["code"])
    
    # Authentication method
    token_endpoint_auth_method: Mapped[str] = mapped_column(String(50), default="client_secret_post")
    
    # OpenID Connect
    is_oidc: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # Security settings
    require_pkce: Mapped[bool] = mapped_column(Boolean, default=True)
    require_nonce: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # Rate limiting
    rate_limit_per_minute: Mapped[int] = mapped_column(default=60)
    
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), onupdate=func.now())
