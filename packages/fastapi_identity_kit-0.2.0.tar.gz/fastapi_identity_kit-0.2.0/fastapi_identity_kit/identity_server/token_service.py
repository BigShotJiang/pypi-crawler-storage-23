import uuid
from datetime import datetime, timezone, timedelta
from typing import Optional, Tuple
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from fastapi_identity_kit.shared_security import (
    generate_opaque_token, hash_token, JWTEngine, PKCEVerifier
)
from .models import AuthorizationCode, RefreshToken
from fastapi_identity_kit.identity_core.models import Session, User

class TokenService:
    """
    Handles internal Authorization Server token operations.
    Enforces PKCE, generates JWTs, and rotates refresh tokens.
    """
    
    def __init__(self, jwt_engine: JWTEngine, active_kid: str):
        self.jwt_engine = jwt_engine
        self.active_kid = active_kid

    async def create_authorization_code(
        self, 
        db_session: AsyncSession, 
        user_id: uuid.UUID, 
        auth_session_id: uuid.UUID,
        client_id: str, 
        redirect_uri: str, 
        code_challenge: str,
        scope: Optional[str] = None,
        nonce: Optional[str] = None
    ) -> str:
        """
        Generates and stores a new, short-lived authorization code.
        """
        raw_code = generate_opaque_token(32)
        code_hash = hash_token(raw_code)
        
        expires_at = datetime.now(timezone.utc) + timedelta(minutes=10)
        
        auth_code_record = AuthorizationCode(
            code_hash=code_hash,
            client_id=client_id,
            user_id=user_id,
            session_id=auth_session_id,
            redirect_uri=redirect_uri,
            scope=scope,
            code_challenge=code_challenge,
            nonce=nonce,
            expires_at=expires_at
        )
        db_session.add(auth_code_record)
        await db_session.commit()
        return raw_code

    async def exchange_code_for_tokens(
        self,
        db_session: AsyncSession,
        code: str,
        client_id: str,
        redirect_uri: str,
        code_verifier: str
    ) -> dict:
        """
        Exchanges an authorization code for access and refresh tokens.
        Strictly enforces PKCE and exact redirect URI matching.
        """
        c_hash = hash_token(code)
        result = await db_session.execute(
            select(AuthorizationCode).where(AuthorizationCode.code_hash == c_hash)
        )
        auth_code = result.scalars().first()
        
        if not auth_code:
            raise ValueError("Invalid or expired authorization code.")
            
        # 1. Single-use enforcement: Delete immediately regardless of outcome
        await db_session.delete(auth_code)
        await db_session.commit()
        
        # 2. Expiration Check
        # Coerce naive datetime to aware if necessary for comparison
        expires_at = auth_code.expires_at
        if expires_at.tzinfo is None:
             expires_at = expires_at.replace(tzinfo=timezone.utc)
             
        if datetime.now(timezone.utc) > expires_at:
            raise ValueError("Authorization code has expired.")
            
        # 3. Client and Redirect Validation
        if auth_code.client_id != client_id or auth_code.redirect_uri != redirect_uri:
             raise ValueError("Client or Redirect URI mismatch (Mix-up attack prevention).")
             
        # 4. PKCE Verification
        if not PKCEVerifier.verify_s256(auth_code.code_challenge, code_verifier):
             raise ValueError("PKCE verification failed.")
             
        # User session retrieval
        user_result = await db_session.execute(select(User).where(User.id == auth_code.user_id))
        user = user_result.scalars().first()
        
        # 5. Token Generation
        family_id = uuid.uuid4()
        refresh_raw, refresh_db = await self._issue_refresh_token(
            db_session, auth_code.session_id, family_id
        )
        
        access_token, id_token = self._issue_jwts(
            user, client_id, auth_code.scope, auth_code.nonce
        )
        
        response = {
            "access_token": access_token,
            "token_type": "Bearer",
            "expires_in": 900, # 15 min
            "refresh_token": refresh_raw
        }
        if id_token:
            response["id_token"] = id_token
            
        return response

    async def refresh_tokens(self, db_session: AsyncSession, refresh_token: str, client_id: str) -> dict:
        """
        Executes secure refresh token rotation with atomic transactions.
        Detects replays and revokes active sessions upon abuse.
        Preserves original scope from the token family.
        """
        r_hash = hash_token(refresh_token)
        
        # CRITICAL: Use atomic transaction to prevent race conditions
        async with db_session.begin():
            # Lock the refresh token row for this transaction
            result = await db_session.execute(
                select(RefreshToken).where(RefreshToken.token_hash == r_hash).with_for_update()
            )
            rt_record: Optional[RefreshToken] = result.scalars().first()
            
            if not rt_record:
                raise ValueError("Invalid refresh token.")
                
            # Replay Detection: Check if already used
            if rt_record.is_used:
                # Threat detected! Revoke family atomically
                await self._revoke_family_atomic(db_session, rt_record.family_id)
                raise ValueError("Replay attack detected. Token family revoked.")
                
            # Expiration Check
            exp_at = rt_record.expires_at
            if exp_at.tzinfo is None:
                 exp_at = exp_at.replace(tzinfo=timezone.utc)
                 
            if datetime.now(timezone.utc) > exp_at:
                raise ValueError("Refresh token expired.")
                
            # Validate session binding
            session_res = await db_session.execute(
                select(Session).where(Session.id == rt_record.session_id).with_for_update()
            )
            user_sess = session_res.scalars().first()
            if not user_sess or user_sess.revoked_at is not None or user_sess.client_id != client_id:
                 raise ValueError("Session invalid or mismatch.")
            
            # CRITICAL: Mark as used BEFORE issuing new token
            rt_record.is_used = True
            
            # Get original scope from the first token in this family
            original_scope = await self._get_family_scope(db_session, rt_record.family_id)
            
            # Issue new token in same family
            new_refresh_raw, _ = await self._issue_refresh_token_atomic(
                db_session, rt_record.session_id, rt_record.family_id
            )
            
            user_res = await db_session.execute(
                select(User).where(User.id == user_sess.user_id)
            )
            user = user_res.scalars().first()
            
            # Use preserved scope instead of None
            access_token, id_token = self._issue_jwts(
                user, client_id, scope=original_scope, nonce=None
            )
            
            # Transaction commits automatically here
        
        return {
            "access_token": access_token,
            "token_type": "Bearer",
            "expires_in": 900,
            "refresh_token": new_refresh_raw
        }

    async def _issue_refresh_token_atomic(self, db_session: AsyncSession, session_id: uuid.UUID, family_id: uuid.UUID) -> Tuple[str, RefreshToken]:
        """Issues refresh token within an existing transaction."""
        raw_rt = generate_opaque_token(48)
        rt_hash = hash_token(raw_rt)
        
        expires_at = datetime.now(timezone.utc) + timedelta(days=30)
        
        rt = RefreshToken(
            token_hash=rt_hash,
            family_id=family_id,
            session_id=session_id,
            expires_at=expires_at
        )
        db_session.add(rt)
        # Note: No commit here - handled by outer transaction
        return raw_rt, rt
    
    async def _get_family_scope(self, db_session: AsyncSession, family_id: uuid.UUID) -> Optional[str]:
        """Retrieves the original scope from the first token in the family."""
        # Find the authorization code that created this family
        result = await db_session.execute(
            select(AuthorizationCode.scope)
            .join(RefreshToken, AuthorizationCode.session_id == RefreshToken.session_id)
            .where(RefreshToken.family_id == family_id)
            .order_by(AuthorizationCode.created_at.asc())
            .limit(1)
        )
        return result.scalar()
    
    async def _revoke_family_atomic(self, db_session: AsyncSession, family_id: uuid.UUID):
        """Immediately invalidates a whole token family within an existing transaction."""
        # Find the session connected to this family
        res = await db_session.execute(
            select(RefreshToken.session_id).where(RefreshToken.family_id == family_id)
        )
        session_ids = [row[0] for row in res.fetchall()]
        
        if session_ids:
            # Revoke all sessions in this family
            sess_res = await db_session.execute(
                select(Session).where(Session.id.in_(session_ids)).with_for_update()
            )
            sessions = sess_res.scalars().all()
            for session in sessions:
                session.revoked_at = datetime.now(timezone.utc)
        
        # Note: No commit here - handled by outer transaction

    def _issue_jwts(self, user: User, client_id: str, scope: Optional[str], nonce: Optional[str]) -> Tuple[str, Optional[str]]:
        now = datetime.now(timezone.utc)
        
        # Base Access Token payload
        at_payload = {
            "sub": str(user.id),
            "aud": client_id,
            "iat": int(now.timestamp()),
            "nbf": int(now.timestamp()),
            "exp": int((now + timedelta(minutes=15)).timestamp()),
            "scope": scope or ""
        }
        access_token = self.jwt_engine.sign(at_payload, kid=self.active_kid)
        
        id_token = None
        if scope and "openid" in scope.split(" "):
             # Complete OIDC ID Token with required claims
             id_payload = {
                 "iss": self.jwt_engine.issuer,  # Issuer identifier
                 "sub": str(user.id),  # Subject identifier
                 "aud": client_id,  # Audience (client_id)
                 "exp": int((now + timedelta(minutes=15)).timestamp()),  # Expiration
                 "iat": int(now.timestamp()),  # Issued at
                 "auth_time": int(now.timestamp()),  # Time of authentication
                 "acr": "urn:mace:incommon:iap:bronze",  # Authentication Context Class Reference
             }
             
             # Add nonce if present (prevents replay attacks)
             if nonce:
                 id_payload["nonce"] = nonce
             
             # Add optional claims based on scope
             if "email" in scope.split(" ") and hasattr(user, 'email'):
                 id_payload["email"] = user.email
                 id_payload["email_verified"] = getattr(user, 'email_verified', True)
             
             if "profile" in scope.split(" "):
                 if hasattr(user, 'name'):
                     id_payload["name"] = user.name
                 if hasattr(user, 'preferred_username'):
                     id_payload["preferred_username"] = user.preferred_username
                 if hasattr(user, 'updated_at'):
                     id_payload["updated_at"] = int(user.updated_at.timestamp())
             
             id_token = self.jwt_engine.sign(id_payload, kid=self.active_kid)
             
        return access_token, id_token

    async def _revoke_family(self, db_session: AsyncSession, family_id: uuid.UUID):
        """Immediately invalidates a whole token family to protect user accounts."""
        # Find the session connected to this family
        res = await db_session.execute(select(RefreshToken).where(RefreshToken.family_id == family_id))
        tokens = res.scalars().all()
        if tokens:
            sess_id = tokens[0].session_id
            sess_res = await db_session.execute(select(Session).where(Session.id == sess_id))
            user_sess = sess_res.scalars().first()
            if user_sess:
                 user_sess.revoked_at = datetime.now(timezone.utc)
                 
        await db_session.commit()
