import uuid
from datetime import datetime
from typing import Optional, List
from sqlalchemy import String, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func
from fastapi_identity_kit.identity_core.models import Base, User, Session

class AuthorizationCode(Base):
    """
    Tracks issued OAuth2 authorization codes securely.
    Codes are single use (enforced by immediate deletion) and short lived (10 min).
    """
    __tablename__ = "authorization_codes"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    code_hash: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    
    client_id: Mapped[str] = mapped_column(String(255), nullable=False)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    session_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("sessions.id", ondelete="CASCADE"), nullable=False)
    
    redirect_uri: Mapped[str] = mapped_column(String(1024), nullable=False)
    scope: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    
    # PKCE tracking
    code_challenge: Mapped[str] = mapped_column(String(255), nullable=False)
    code_challenge_method: Mapped[str] = mapped_column(String(10), nullable=False, default="S256")
    
    nonce: Mapped[Optional[str]] = mapped_column(String(255), nullable=True) # For OIDC
    
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    user: Mapped["User"] = relationship("User", foreign_keys=[user_id])
    session: Mapped["Session"] = relationship("Session", foreign_keys=[session_id])


class RefreshToken(Base):
    """
    Manages OAuth2 Refresh Tokens.
    Implements Family tracking for rotation and replay detection.
    """
    __tablename__ = "refresh_tokens"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    token_hash: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    
    family_id: Mapped[uuid.UUID] = mapped_column(nullable=False, index=True) # Groups rotated tokens
    session_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("sessions.id", ondelete="CASCADE"), nullable=False, index=True)
    
    is_used: Mapped[bool] = mapped_column(Boolean, default=False)
    
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    issued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    
    session: Mapped["Session"] = relationship("Session", foreign_keys=[session_id])
