"""
Factory for creating FastAPI Identity Provider applications
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional

import os
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine, sessionmaker, AsyncSession

from .config.settings import get_settings, security_settings, logging_settings
from .config.secret_manager import SecretManager
from .shared_security.key_manager import KeyManager
from .shared_security.key_rotation import KeyRotationService
from .shared_security.database_encryption import DatabaseEncryptionService
from .shared_security.middleware import SecurityHeadersMiddleware, RateLimitMiddleware
from .shared_security.https_middleware import HTTPSMiddleware
from .identity_core.password_service import PasswordService
from .shared_security.jwt_engine import JWTEngine
from .shared_security.pkce import PKCEVerifier
from .identity_server.router import identity_router
from .identity_server.token_service import TokenService
from .mfa.redis_lockout import RedisLockoutService as LockoutService
from .mfa.totp import TOTPService
from .authorization.rbac import RBACService
from .risk_engine.analyzer import RiskAnalyzer
from .identity_core.models import Base

logger = logging.getLogger(__name__)

class ProductionAppFactory:
    """
    Factory for creating production-hardened FastAPI applications.
    Integrates all security features with environment-based configuration.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    async def create_identity_app(self, config: Optional[dict] = None) -> FastAPI:
        """Create a production-hardened FastAPI application with identity provider."""
        
        # Load configuration
        settings = get_settings()
        if config:
            # Override settings with provided config
            for key, value in config.items():
                if hasattr(settings, key):
                    setattr(settings, key, value)
        
        # Create FastAPI app
        app = FastAPI(
            title=getattr(settings, 'app_name', 'Identity Provider'),
            description="OAuth2/OpenID Connect Identity Provider",
            version="1.0.0",
            docs_url="/docs" if getattr(settings, 'environment', 'development') != "production" else None,
            redoc_url="/redoc" if getattr(settings, 'environment', 'development') != "production" else None,
        )
        
        # Add CORS middleware
        cors_origins = getattr(settings, 'cors_origins', None)
        if cors_origins:
            app.add_middleware(
                CORSMiddleware,
                allow_origins=cors_origins,
                allow_credentials=True,
                allow_methods=["*"],
                allow_headers=["*"],
            )
        
        # Add security headers middleware
        app.add_middleware(SecurityHeadersMiddleware)
        
        # Add HTTPS enforcement middleware
        if getattr(settings, 'enforce_https', True):
            app.add_middleware(HTTPSMiddleware)
        
        # Add rate limiting middleware
        if getattr(settings, 'rate_limiting_enabled', True):
            app.add_middleware(RateLimitMiddleware, redis_url=getattr(settings, 'redis_url', None))
        
        # Initialize Redis (optional)
        redis_client = None
        redis_enabled = getattr(settings, 'redis_enabled', True)
        redis_url = getattr(settings, 'redis_url', None)
        
        if redis_enabled and redis_url:
            try:
                import redis.asyncio as redis
                redis_client = redis.from_url(
                    redis_url,
                    password=getattr(settings, 'redis_password', None),
                    ssl=getattr(settings, 'redis_ssl', False),
                    decode_responses=True
                )
                logger.info("Redis connection established")
            except ImportError:
                logger.warning("Redis not available, some features will be disabled")
            except Exception as e:
                logger.error(f"Failed to connect to Redis: {e}")
        
        # Initialize database
        database_url = getattr(settings, 'database_url', 'sqlite:///./identity.db')
        engine = create_async_engine(
            database_url,
            pool_size=getattr(settings, 'database_pool_size', 20),
            echo=getattr(settings, 'environment', 'development') == "development"
        )
        
        async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
        
        # Initialize services
        secret_manager = SecretManager(getattr(settings, 'secret_provider', 'environment'), settings)
        key_manager = KeyManager(secret_manager)
        
        # Initialize identity services
        password_service = PasswordService()
        jwt_engine = JWTEngine(key_manager)
        pkce_verifier = PKCEVerifier()
        
        # Initialize MFA services (optional)
        totp_service = None
        lockout_service = None
        mfa_enabled = getattr(settings, 'mfa_enabled', True)
        
        if mfa_enabled:
            totp_service = TOTPService(
                encryption_key=getattr(settings, 'encryption_key', '').encode() or b'0'*32,
                issuer_name=getattr(settings, 'mfa_issuer', 'IdentityKit')
            )
            lockout_service = LockoutService(
                redis_url=getattr(settings, 'redis_url', '') or "redis://localhost:6379",
                max_attempts=getattr(settings, 'mfa_lockout_max_attempts', 5),
                base_lockout_minutes=getattr(settings, 'mfa_lockout_base_minutes', 15)
            )
        
        # Initialize authorization service
        rbac_service = RBACService(async_session)
        
        # Initialize risk engine (optional)
        risk_analyzer = RiskAnalyzer()
        
        # Initialize token service
        token_service = TokenService(
            jwt_engine=jwt_engine,
            pkce_verifier=pkce_verifier,
            async_session=async_session,
            redis_client=redis_client,
            settings=settings
        )
        
        
        # Add dependencies
        @app.dependency_overrides
        def get_db_session_override():
            async def get_db():
                async with async_session() as session:
                    try:
                        yield session
                    finally:
                        await session.close()
            return get_db
        
        @app.dependency_overrides
        def get_token_service_override():
            return lambda: token_service
        
        @app.dependency_overrides
        def get_key_manager_override():
            return lambda: key_manager
        
        @app.dependency_overrides
        def get_settings_override():
            return lambda: settings
        
        @app.dependency_overrides
        def get_redis_client_override():
            return lambda: redis_client
        
        # Add identity routes
        app.include_router(identity_router, prefix="/oauth", tags=["oauth"])
        
        # Add health check routes
        @app.get("/health")
        async def health_check():
            """Basic health check endpoint."""
            return {
                "status": "healthy",
                "timestamp": datetime.utcnow().isoformat(),
                "version": "1.0.0",
                "environment": getattr(settings, 'environment', 'development')
            }
        
        @app.get("/health/ready")
        async def readiness_check():
            """Readiness check with dependency validation."""
            checks = {
                "database": await self._check_database_health(engine),
                "redis": await self._check_redis_health(redis_client),
                "encryption": await self._check_encryption_health(secret_manager),
                "key_rotation": await self._check_key_rotation_health(key_manager)
            }
            
            all_healthy = all(check["healthy"] for check in checks.values())
            
            return {
                "status": "ready" if all_healthy else "not_ready",
                "checks": checks
            }
        
        @app.get("/security/status")
        async def security_status():
            """Security configuration status endpoint."""
            return {
                "https_enforced": getattr(settings, 'enforce_https', True),
                "hsts_enabled": getattr(settings, 'enforce_https', True),
                "rate_limiting_enabled": getattr(settings, 'rate_limiting_enabled', True),
                "encryption_enabled": secret_manager is not None,
                "key_rotation_enabled": key_manager is not None,
                "secret_provider": getattr(settings, 'secret_provider', 'environment'),
                "environment": getattr(settings, 'environment', 'development')
            }
        
        @app.get("/security/audit")
        async def security_audit():
            """Security audit information."""
            if getattr(settings, 'environment', 'development') != 'development':
                from fastapi import HTTPException
                raise HTTPException(status_code=404, detail="Not found")
            
            audit_info = {
                "secret_manager": await secret_manager.audit_secrets() if hasattr(secret_manager, 'audit_secrets') else {},
                "key_status": key_manager.get_all_keys_status() if hasattr(key_manager, 'get_all_keys_status') else {},
                "encryption_integrity": "enabled" if secret_manager else "disabled"
            }
            
            return audit_info
        
        # Add startup events
        @app.on_event("startup")
        async def startup_events():
            """Initialize services on startup."""
            logger.info(f"Starting {getattr(settings, 'app_name', 'Identity Provider')}")
            
            # Validate production configuration
            await self._validate_production_configuration(settings)
            
            # Run database migrations
            try:
                async with engine.begin() as conn:
                    await conn.run_sync(Base.metadata.create_all)
                logger.info("Database migrations completed")
            except Exception as e:
                logger.error(f"Database migration failed: {e}")
                raise
            
            logger.info("Identity provider started successfully")
        
        @app.on_event("shutdown")
        async def shutdown_events():
            """Cleanup on shutdown."""
            logger.info("Shutting down application")
            
            # Cleanup resources
            await self._cleanup_resources(redis_client, engine)
            
            logger.info("Application shutdown complete")
        
        return app
    
    async def _check_database_health(self, engine) -> dict:
        """Check database connectivity."""
        try:
            async with engine.begin() as conn:
                await conn.execute(text("SELECT 1"))
            return {"healthy": True, "message": "Database connection successful"}
        except Exception as e:
            return {"healthy": False, "message": f"Database error: {e}"}
    
    async def _check_redis_health(self, redis_client) -> dict:
        """Check Redis connectivity."""
        if not redis_client:
            return {"healthy": False, "message": "Redis not configured"}
        try:
            await redis_client.ping()
            return {"healthy": True, "message": "Redis connection successful"}
        except Exception as e:
            return {"healthy": False, "message": f"Redis error: {e}"}
    
    async def _check_encryption_health(self, secret_manager) -> dict:
        """Check encryption service health."""
        if not secret_manager:
            return {"healthy": False, "message": "Secret manager not initialized"}
        try:
            # Test secret retrieval
            await secret_manager.get_secret("health-check-test")
            return {"healthy": True, "message": "Secret manager operational"}
        except Exception as e:
            return {"healthy": False, "message": f"Secret manager error: {e}"}
    
    async def _check_key_rotation_health(self, key_manager) -> dict:
        """Check key manager health."""
        if not key_manager:
            return {"healthy": False, "message": "Key manager not initialized"}
        try:
            # Test key generation/retrieval
            keys = key_manager.get_all_keys()
            return {
                "healthy": True, 
                "message": "Key manager operational",
                "total_keys": len(keys)
            }
        except Exception as e:
            return {"healthy": False, "message": f"Key manager error: {e}"}
    
    async def _validate_production_configuration(self, settings):
        """Validate production configuration."""
        if getattr(settings, 'environment', 'development') == 'production':
            # Validate required production settings
            required_settings = [
                ("SECRET_KEY", getattr(settings, 'secret_key', None)),
                ("DATABASE_URL", getattr(settings, 'database_url', None)),
                ("ENFORCE_HTTPS", getattr(settings, 'enforce_https', True)),
            ]
            
            for setting_name, setting_value in required_settings:
                if not setting_value:
                    raise ValueError(f"Required production setting {setting_name} is not configured")
            
            # Validate HTTPS configuration
            if not getattr(settings, 'enforce_https', True):
                raise ValueError("HTTPS enforcement is required in production")
            
            # Validate database SSL for PostgreSQL
            db_url = getattr(settings, 'database_url', '')
            if 'postgresql' in db_url and 'ssl=' not in db_url.lower():
                raise ValueError("Database SSL is required in production")
            
            logger.info("Production configuration validation passed")
    
    async def _cleanup_resources(self, redis_client, engine):
        """Cleanup application resources."""
        try:
            # Close Redis connection
            if redis_client:
                await redis_client.close()
            
            # Close database connections
            await engine.dispose()
            
            logger.info("Resources cleanup completed")
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")
    
    async def _on_key_rotation(self, old_kid: str, new_kid: str, algorithm: str):
        """Callback for key rotation events."""
        logger.info(f"Key rotation completed: {old_kid} -> {new_kid} ({algorithm})")
        
        # Store rotation event in audit log
        try:
            import json
            event_data = {
                "event_type": "key_rotation",
                "old_kid": old_kid,
                "new_kid": new_kid,
                "algorithm": algorithm,
                "timestamp": datetime.utcnow().isoformat()
            }
            
            # This would be stored in your audit system
            logger.info(f"Key rotation event: {json.dumps(event_data)}")
        except Exception as e:
            logger.error(f"Failed to store key rotation event: {e}")

def is_configured() -> bool:
    """Check if the application is configured."""
    return os.path.exists(".env") or os.environ.get("SECRET_KEY") is not None

def setup_wizard_app(app: Optional[FastAPI] = None) -> FastAPI:
    """Configure app with Setup Wizard UI."""
    if app is None:
        app = FastAPI(title="Identity Kit Setup", description="Complete initial configuration.")
        
    from .setup_router import router as setup_router
    app.include_router(setup_router, prefix="/setup")
    
    static_dir = os.path.join(os.path.dirname(__file__), "dashboard", "out")
    
    if os.path.exists(static_dir):
        # Mount only _next static assets explicitly
        next_static = os.path.join(static_dir, "_next")
        if os.path.exists(next_static):
            app.mount("/setup/_next", StaticFiles(directory=next_static), name="next_static")
        
        @app.get("/setup/{full_path:path}")
        async def serve_setup_ui(full_path: str):
            index_path = os.path.join(static_dir, "index.html")
            if os.path.exists(index_path):
                with open(index_path, "r", encoding="utf-8") as f:
                    return HTMLResponse(content=f.read())
            return HTMLResponse(content="Setup UI is not built. Please run npm run build in dashboard directory.", status_code=404)
    else:
        @app.get("/setup/{full_path:path}")
        async def serve_setup_ui_missing(full_path: str):
            return HTMLResponse(content="Dashboard out directory not found.", status_code=404)

    @app.get("/{full_path:path}")
    async def redirect_to_setup(full_path: str, request: Request):
        if not request.url.path.startswith("/setup"):
            return RedirectResponse(url="/setup/")
        return JSONResponse({"status": "setup_required"})
        
    return app

# Simple standalone function for easier usage
def create_identity_app(config: Optional[dict] = None) -> FastAPI:
    """Create a FastAPI application with identity provider (Redis optional)."""
    if not is_configured():
        return setup_wizard_app()
        
    factory = ProductionAppFactory()
    return asyncio.run(factory.create_identity_app(config))

def add_identity_provider(app: FastAPI, config: Optional[dict] = None) -> FastAPI:
    """Add identity provider to existing FastAPI app."""
    if not is_configured():
        setup_wizard_app(app)
        return app
        
    factory = ProductionAppFactory()
    identity_app = asyncio.run(factory.create_identity_app(config))
    
    # Copy routes from identity app to main app
    for route in identity_app.routes:
        app.routes.append(route)
    
    # Copy middleware from identity app to main app
    for middleware in identity_app.user_middleware:
        app.user_middleware.append(middleware)
    
    return app
