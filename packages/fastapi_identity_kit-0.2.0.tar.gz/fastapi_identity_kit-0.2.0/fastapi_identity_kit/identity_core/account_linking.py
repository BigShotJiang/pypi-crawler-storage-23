from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from .models import User, IdentityLink

class AccountLinkingService:
    """
    Implements conflict resolution and external-to-local identity linking strategies.
    Supports secure matching based on verified emails.
    """

    @staticmethod
    async def get_user_by_email(session: AsyncSession, email: str) -> Optional[User]:
        result = await session.execute(select(User).where(User.email == email))
        return result.scalars().first()

    @staticmethod
    async def get_identity_link(session: AsyncSession, provider_name: str, subject_id: str) -> Optional[IdentityLink]:
        result = await session.execute(
            select(IdentityLink).where(
                IdentityLink.provider_name == provider_name,
                IdentityLink.provider_subject_id == subject_id
            )
        )
        return result.scalars().first()

    @staticmethod
    async def link_external_identity(
        session: AsyncSession,
        user: User, 
        provider_name: str, 
        subject_id: str,
        is_email_verified: bool = False
    ) -> IdentityLink:
        """
        Links a new external identity to an existing user account.
        Requires the external email to be verified to mitigate account takeover attacks.
        """
        if not is_email_verified and not user.is_verified:
            raise ValueError("Cannot link unverified external provider to unverified local account. Risk of account takeover.")

        # Check if the identity is already linked to someone else
        existing_link = await AccountLinkingService.get_identity_link(session, provider_name, subject_id)
        if existing_link:
            if existing_link.user_id != user.id:
                raise ValueError("Identity already linked to a different account.")
            return existing_link

        new_link = IdentityLink(
            user_id=user.id,
            provider_name=provider_name,
            provider_subject_id=subject_id
        )
        
        # If the provider says the email is verified, we can trust it and mark the user as verified.
        if is_email_verified and not user.is_verified:
            user.is_verified = True
            
        session.add(new_link)
        await session.commit()
        await session.refresh(new_link)
        
        return new_link
