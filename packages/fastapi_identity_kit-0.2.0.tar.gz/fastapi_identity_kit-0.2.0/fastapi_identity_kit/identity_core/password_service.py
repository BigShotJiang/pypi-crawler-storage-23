from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
import re

class PasswordService:
    """
    Production-grade password hashing utilizing Argon2id.
    Handles policy validation, hashing, and secure comparison.
    """
    def __init__(self, time_cost=2, memory_cost=65536, parallelism=2):
        self._hasher = PasswordHasher(
            time_cost=time_cost,
            memory_cost=memory_cost,
            parallelism=parallelism,
            hash_len=32,
            salt_len=16
        )

    def hash(self, password: str) -> str:
        """Hashes an incoming raw password."""
        return self._hasher.hash(password)

    def verify(self, password_hash: str, password: str) -> bool:
        """
        Safely verifies a password against a hash.
        Includes checking if the hash needs re-hashing (due to parameter changes).
        """
        try:
            return self._hasher.verify(password_hash, password)
        except VerifyMismatchError:
            return False

    def needs_rehash(self, password_hash: str) -> bool:
        """Checks if the existing hash was generated with older cost parameters."""
        return self._hasher.check_needs_rehash(password_hash)

    def validate_policy(self, password: str) -> bool:
        """
        Enforce strict minimum password rules.
        Requires Minimum 12 characters, at least one uppercase, lowercase, number, and special character.
        """
        if len(password) < 12:
            return False
            
        if not re.search(r'[A-Z]', password):
            return False
            
        if not re.search(r'[a-z]', password):
            return False
            
        if not re.search(r'[0-9]', password):
            return False
            
        if not re.search(r'[\W_]', password):
            return False
            
        return True
