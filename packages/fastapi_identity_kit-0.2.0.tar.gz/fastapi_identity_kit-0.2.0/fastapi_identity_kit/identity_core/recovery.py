from datetime import datetime, timezone, timedelta
from typing import Tuple
from fastapi_identity_kit.shared_security.crypto_utils import generate_opaque_token, hash_token, constant_time_compare

class RecoveryService:
    """
    Manages robust URL-safe token generation for password resets and email verification flows.
    Prevents database leak vulnerability by enforcing hashing of tokens prior to DB storage.
    """
    
    @staticmethod
    def generate_recovery_token() -> Tuple[str, str, datetime]:
        """
        Generates a high-entropy URL-safe token for sending to the user,
        and a hashed version to store in the database.
        Returns: (raw_token, hashed_token, expires_at)
        """
        raw_token = generate_opaque_token(32) # High entropy
        hashed = hash_token(raw_token)
        
        # Hard cap recovery tokens at 15 minutes of validity
        expires_at = datetime.now(timezone.utc) + timedelta(minutes=15)
        
        return raw_token, hashed, expires_at

    @staticmethod
    def generate_verification_token() -> Tuple[str, str, datetime]:
        """
        Generates a token for email verification. Similar security bounds to recovery.
        """
        raw_token = generate_opaque_token(32)
        hashed = hash_token(raw_token)
        
        # Email verifications can last slightly longer (e.g., 2 hours)
        expires_at = datetime.now(timezone.utc) + timedelta(hours=2)
        
        return raw_token, hashed, expires_at

    @staticmethod
    def validate_token(presented_raw_token: str, stored_hash: str, expires_at: datetime) -> bool:
        """
        Safely validates a presented raw token against its stored hash.
        Fails if expired or invalid.
        """
        if datetime.now(timezone.utc) > expires_at:
            return False
            
        calculated_hash = hash_token(presented_raw_token)
        return constant_time_compare(calculated_hash, stored_hash)
