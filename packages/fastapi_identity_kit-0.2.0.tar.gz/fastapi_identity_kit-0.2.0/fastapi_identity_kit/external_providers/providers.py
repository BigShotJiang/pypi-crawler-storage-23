from typing import Dict, Any, List
from .base import BaseOAuthProvider, NormalizedProfile

class GoogleProvider(BaseOAuthProvider):
    name = "google"
    authorize_url = "https://accounts.google.com/o/oauth2/v2/auth"
    token_url = "https://oauth2.googleapis.com/token"
    userinfo_url = "https://openidconnect.googleapis.com/v1/userinfo"
    default_scopes = ["openid", "email", "profile"]

    def get_custom_auth_params(self) -> Dict[str, str]:
        return {"prompt": "select_account"}

    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        return NormalizedProfile(
            id=str(data["sub"]),
            email=data["email"],
            email_verified=data.get("email_verified", False),
            name=data.get("name"),
            picture=data.get("picture"),
            raw_data=data
        )

class GitHubProvider(BaseOAuthProvider):
    name = "github"
    authorize_url = "https://github.com/login/oauth/authorize"
    token_url = "https://github.com/login/oauth/access_token"
    userinfo_url = "https://api.github.com/user"
    default_scopes = ["read:user", "user:email"]

    async def fetch_user_info(self, access_token: str) -> Dict[str, Any]:
        # GitHub requires a secondary call to fetch private emails securely
        base_info = await super().fetch_user_info(access_token)
        
        import httpx
        headers = {"Authorization": f"Bearer {access_token}", "Accept": "application/json"}
        async with httpx.AsyncClient() as client:
            resp = await client.get("https://api.github.com/user/emails", headers=headers)
            if resp.status_code == 200:
                 emails = resp.json()
                 primary = next((e for e in emails if e.get("primary")), None)
                 if primary:
                      base_info["email"] = primary["email"]
                      base_info["email_verified"] = primary["verified"]
        return base_info

    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        return NormalizedProfile(
            id=str(data["id"]),
            email=data.get("email", ""),
            email_verified=data.get("email_verified", False),
            name=data.get("name") or data.get("login"),
            picture=data.get("avatar_url"),
            raw_data=data
        )

class MicrosoftProvider(BaseOAuthProvider):
    name = "microsoft"
    authorize_url = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize"
    token_url = "https://login.microsoftonline.com/common/oauth2/v2.0/token"
    userinfo_url = "https://graph.microsoft.com/oidc/userinfo"
    default_scopes = ["openid", "email", "profile"]

    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        return NormalizedProfile(
            id=str(data["sub"]),
            email=data.get("email") or data.get("preferred_username", ""),
            email_verified=True, # Trusting MS Graph assertion for managed accounts
            name=data.get("name"),
            picture=data.get("picture"),
            raw_data=data
        )

class LinkedInProvider(BaseOAuthProvider):
    name = "linkedin"
    authorize_url = "https://www.linkedin.com/oauth/v2/authorization"
    token_url = "https://www.linkedin.com/oauth/v2/accessToken"
    userinfo_url = "https://api.linkedin.com/v2/userinfo"
    default_scopes = ["openid", "profile", "email"]

    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        return NormalizedProfile(
            id=str(data["sub"]),
            email=data.get("email", ""),
            email_verified=data.get("email_verified", False),
            name=data.get("name"),
            picture=data.get("picture"),
            raw_data=data
        )

class AppleProvider(BaseOAuthProvider):
    name = "apple"
    authorize_url = "https://appleid.apple.com/auth/authorize"
    token_url = "https://appleid.apple.com/auth/token"
    userinfo_url = "" # Apple sends data in ID token and POST payload instead
    default_scopes = ["name", "email"]
    
    def get_custom_auth_params(self) -> Dict[str, str]:
        return {"response_mode": "form_post"}

    # Exchanging code with Apple requires asymmetric JWT client_secret logic...
    # (Simplified for Phase 4 template demo)
    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        return NormalizedProfile(
            id=str(data["sub"]),
            email=data.get("email", ""),
            email_verified=data.get("email_verified", False) == "true",
            name=None, # Name is only sent once by Apple in raw form_post data
            picture=None,
            raw_data=data
        )

class RedditProvider(BaseOAuthProvider):
    name = "reddit"
    authorize_url = "https://www.reddit.com/api/v1/authorize"
    token_url = "https://www.reddit.com/api/v1/access_token"
    userinfo_url = "https://oauth.reddit.com/api/v1/me"
    default_scopes = ["identity"]

    async def exchange_code(self, code: str, code_verifier: str) -> Dict[str, Any]:
        import httpx
        payload = {"grant_type": "authorization_code", "redirect_uri": self.redirect_uri, "code": code}
        # Reddit requires Basic Auth
        async with httpx.AsyncClient() as client:
            resp = await client.post(self.token_url, data=payload, auth=(self.client_id, self.client_secret), headers={"User-Agent": "FastAPI Identity Kit/1.0"})
            resp.raise_for_status()
            return resp.json()

    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        return NormalizedProfile(
            id=data["id"],
            email="", # Reddit doesn't provide email easily without verified scope + conditions
            email_verified=False,
            name=data.get("name"),
            picture=data.get("icon_img"),
            raw_data=data
        )

class TwitterProvider(BaseOAuthProvider):
    name = "twitter"
    authorize_url = "https://twitter.com/i/oauth2/authorize"
    token_url = "https://api.twitter.com/2/oauth2/token"
    userinfo_url = "https://api.twitter.com/2/users/me"
    default_scopes = ["users.read", "tweet.read"]

    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        user_data = data.get("data", {})
        return NormalizedProfile(
            id=user_data.get("id", ""),
            email="", 
            email_verified=False,
            name=user_data.get("name") or user_data.get("username"),
            picture=user_data.get("profile_image_url"),
            raw_data=user_data
        )

class FigmaProvider(BaseOAuthProvider):
    name = "figma"
    authorize_url = "https://www.figma.com/oauth"
    token_url = "https://www.figma.com/api/oauth/token"
    userinfo_url = "https://api.figma.com/v1/me"
    default_scopes = ["files:read"]
    
    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        return NormalizedProfile(
            id=str(data.get("id", "")),
            email=data.get("email", ""),
            email_verified=True,
            name=data.get("handle"),
            picture=data.get("img_url"),
            raw_data=data
        )

class NotionProvider(BaseOAuthProvider):
    name = "notion"
    authorize_url = "https://api.notion.com/v1/oauth/authorize"
    token_url = "https://api.notion.com/v1/oauth/token"
    userinfo_url = "https://api.notion.com/v1/users/me" # Simplification for Notion Bot user
    default_scopes = []
    
    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        # Notion returns bot / user info inside token exchange directly sometimes
        return NormalizedProfile(id=data.get("owner", {}).get("user", {}).get("id", ""), email="", email_verified=False, name="", raw_data=data)

class PayPalProvider(BaseOAuthProvider):
    name = "paypal"
    authorize_url = "https://www.paypal.com/signin/authorize"
    token_url = "https://api-m.paypal.com/v1/oauth2/token"
    userinfo_url = "https://api-m.paypal.com/v1/identity/oauth2/userinfo"
    default_scopes = ["openid", "profile", "email"]
    
    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        return NormalizedProfile(id=data.get("user_id", ""), email=data.get("emails", [{}])[0].get("value", ""), email_verified=True, name=data.get("name"), raw_data=data)

class VercelProvider(BaseOAuthProvider):
    name = "vercel"
    authorize_url = "https://vercel.com/oauth/authorize"
    token_url = "https://api.vercel.com/v2/oauth/access_token"
    userinfo_url = "https://api.vercel.com/v2/user"
    default_scopes = []
    
    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        user = data.get("user", {})
        return NormalizedProfile(id=user.get("id", ""), email=user.get("email", ""), email_verified=True, name=user.get("name"), raw_data=user)

class HuggingFaceProvider(BaseOAuthProvider):
    name = "huggingface"
    authorize_url = "https://huggingface.co/oauth/authorize"
    token_url = "https://huggingface.co/oauth/token"
    userinfo_url = "https://huggingface.co/oauth/userinfo"
    default_scopes = ["openid", "profile"]
    
    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        return NormalizedProfile(id=str(data.get("sub", "")), email=data.get("email", ""), email_verified=data.get("email_verified", False), name=data.get("name") or data.get("preferred_username"), picture=data.get("picture"), raw_data=data)

class FacebookProvider(BaseOAuthProvider):
    name = "facebook"
    authorize_url = "https://www.facebook.com/v17.0/dialog/oauth"
    token_url = "https://graph.facebook.com/v17.0/oauth/access_token"
    userinfo_url = "https://graph.facebook.com/me?fields=id,name,email,picture"
    default_scopes = ["email", "public_profile"]
    
    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        pic = data.get("picture", {}).get("data", {}).get("url")
        return NormalizedProfile(id=data.get("id", ""), email=data.get("email", ""), email_verified=False, name=data.get("name"), picture=pic, raw_data=data)
