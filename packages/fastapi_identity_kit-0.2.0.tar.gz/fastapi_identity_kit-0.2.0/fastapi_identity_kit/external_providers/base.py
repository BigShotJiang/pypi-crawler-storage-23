import abc
import urllib.parse
from typing import Optional, Dict, Any, List
import httpx
from pydantic import BaseModel


class NormalizedProfile(BaseModel):
    """Unified user profile data across all external providers."""
    id: str
    email: str
    email_verified: bool = False
    name: Optional[str] = None
    picture: Optional[str] = None
    raw_data: Dict[str, Any] = {}


class ProviderException(Exception):
    """Raised for provider-level errors (network, parsing, rejection)."""
    pass


class BaseOAuthProvider(abc.ABC):
    """
    Abstract base class for Social Login and Custom Identity Providers.
    Secures state, PKCE, OIDC nonce, and token-handling uniformly.
    """
    
    name: str = "base"
    authorize_url: str = ""
    token_url: str = ""
    userinfo_url: str = ""
    default_scopes: List[str] = []
    
    def __init__(self, client_id: str, client_secret: str, redirect_uri: str):
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri

    def get_authorization_url(
        self, 
        state: str, 
        code_challenge: str, 
        nonce: Optional[str] = None, 
        scopes: Optional[List[str]] = None
    ) -> str:
        """Constructs an authorization URL securing it with PKCE and State."""
        requested_scopes = scopes if scopes else self.default_scopes
        
        params = {
            "client_id": self.client_id,
            "response_type": "code",
            "redirect_uri": self.redirect_uri,
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "scope": " ".join(requested_scopes)
        }
        if nonce:
            params["nonce"] = nonce
            
        custom_params = self.get_custom_auth_params()
        if custom_params:
            params.update(custom_params)
            
        return f"{self.authorize_url}?{urllib.parse.urlencode(params)}"

    def get_custom_auth_params(self) -> Dict[str, str]:
        """Override to add provider-specific params (like prompt=consent)."""
        return {}

    async def exchange_code(self, code: str, code_verifier: str) -> Dict[str, Any]:
        """Exchanges an authorization code for tokens, mitigating errors."""
        payload = {
            "grant_type": "authorization_code",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "redirect_uri": self.redirect_uri,
            "code": code,
            "code_verifier": code_verifier
        }
        
        headers = {
            "Accept": "application/json"
        }

        async with httpx.AsyncClient() as client:
            resp = await client.post(self.token_url, data=payload, headers=headers)
            
            if resp.status_code >= 400:
                raise ProviderException(f"Token exchange failed: {resp.text}")
                
            return resp.json()

    async def fetch_user_info(self, access_token: str) -> Dict[str, Any]:
        """Fetches the raw identity data from the provider's /userinfo or graph endpoint."""
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json"
        }
        
        async with httpx.AsyncClient() as client:
            resp = await client.get(self.userinfo_url, headers=headers)
            
            if resp.status_code >= 400:
                raise ProviderException(f"User info fetch failed: {resp.text}")
                
            return resp.json()

    @abc.abstractmethod
    def normalize_profile(self, data: Dict[str, Any]) -> NormalizedProfile:
        """Transforms provider-specific profile structures into the NormalizedProfile."""
        pass
