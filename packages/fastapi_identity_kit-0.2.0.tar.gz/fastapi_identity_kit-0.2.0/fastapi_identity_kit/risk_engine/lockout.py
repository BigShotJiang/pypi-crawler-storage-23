import uuid
from datetime import datetime, timezone, timedelta
from typing import Dict
from sqlalchemy.ext.asyncio import AsyncSession
from .models import SecurityEvent

# In-memory mapping holding bad actors. 
# In production, Redis is mandatory for persistent distributed tracking.
# Tracks failed attempts per IP and per User.
_failed_attempts: Dict[str, dict] = {}

class AccountLockoutService:
    """
    Acts as the final barrier preventing brute force attacks against User Identities.
    Tracks velocity of failed logins and suspends access temporarily.
    """
    
    def __init__(self, lockout_threshold: int = 5, lockout_duration_minutes: int = 30):
        self.lockout_threshold = lockout_threshold
        self.lockout_duration_minutes = lockout_duration_minutes

    async def is_account_locked(self, user_id: uuid.UUID) -> bool:
        """Returns True if the account is under an active security suspension."""
        key = f"user:{str(user_id)}"
        record = _failed_attempts.get(key)
        
        if record and record.get("locked_until"):
            if datetime.now(timezone.utc) < record["locked_until"]:
                return True
            else:
                # Lockout duration naturally expired
                del _failed_attempts[key]
                return False
                
        return False

    async def record_failed_login(self, db_session: AsyncSession, user_id: uuid.UUID, ip_address: str):
        """
        Increments failure counters. Triggers an immutable SecurityEvent if suspension occurs.
        """
        key = f"user:{str(user_id)}"
        
        if key not in _failed_attempts:
            _failed_attempts[key] = {"count": 0, "locked_until": None}
            
        _failed_attempts[key]["count"] += 1
        
        if _failed_attempts[key]["count"] >= self.lockout_threshold:
            # Trigger Lockout
            _failed_attempts[key]["locked_until"] = datetime.now(timezone.utc) + timedelta(minutes=self.lockout_duration_minutes)
            
            db_session.add(SecurityEvent(
                user_id=user_id,
                event_type="ACCOUNT_LOCKED_BRUTE_FORCE",
                severity="CRITICAL",
                ip_address=ip_address,
                details=f"Account suspended for {self.lockout_duration_minutes}m after {self.lockout_threshold} failures."
            ))
            await db_session.commit()

    async def clear_failures(self, user_id: uuid.UUID):
        """Upon a completely successful login, flushes counters to prevent permanent accumulation."""
        key = f"user:{str(user_id)}"
        if key in _failed_attempts:
            del _failed_attempts[key]
