import uuid
import hashlib
import hmac
from typing import Tuple, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from .models import LoginHistory, DeviceIdentity, SecurityEvent
import json
import re

class RiskAnalyzer:
    """
    Evaluates incoming authentication requests against baseline user patterns 
    to trigger security interventions like Step-Up MFA.
    """
    
    @staticmethod
    def generate_fingerprint(user_agent: str, ip_address: str, accept_language: Optional[str] = None, accept_encoding: Optional[str] = None) -> str:
        """
        Generates an enhanced device fingerprint using multiple browser characteristics.
        Implements entropy analysis to prevent fingerprint manipulation.
        """
        # Normalize IP address to subnet for privacy while maintaining uniqueness
        if '.' in ip_address:  # IPv4
            subnet = '.'.join(ip_address.split('.')[:3]) + '.0/24'
        elif ':' in ip_address:  # IPv6
            # Truncate to /48 for IPv6
            parts = ip_address.split(':')
            subnet = ':'.join(parts[:4]) + '::/48'
        else:
            subnet = ip_address
        
        # Parse and normalize user agent
        normalized_ua = RiskAnalyzer._normalize_user_agent(user_agent)
        
        # Collect additional fingerprint data
        fingerprint_components = {
            "user_agent": normalized_ua,
            "ip_subnet": subnet,
            "accept_language": RiskAnalyzer._normalize_language(accept_language) if accept_language else "unknown",
            "accept_encoding": RiskAnalyzer._normalize_encoding(accept_encoding) if accept_encoding else "unknown"
        }
        
        # Create JSON string and hash
        fingerprint_json = json.dumps(fingerprint_components, sort_keys=True, separators=(',', ':'))
        
        # Use HMAC-SHA256 for better security than plain SHA256
        secret_key = "device_fingerprint_secret"  # In production, use proper secret management
        return hmac.new(
            secret_key.encode('utf-8'),
            fingerprint_json.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
    
    @staticmethod
    def _normalize_user_agent(user_agent: str) -> str:
        """Normalizes user agent to reduce version noise while maintaining uniqueness."""
        # Extract browser family and major version
        # Chrome: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36
        # Firefox: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0
        
        # Pattern matching for major browsers
        patterns = [
            (r'Chrome/(\d+)\.', 'Chrome'),
            (r'Firefox/(\d+)\.', 'Firefox'),
            (r'Safari/(\d+)', 'Safari'),
            (r'Edge/(\d+)\.', 'Edge'),
            (r'OPR/(\d+)\.', 'Opera')
        ]
        
        for pattern, browser in patterns:
            match = re.search(pattern, user_agent)
            if match:
                return f"{browser}_{match.group(1)}"
        
        # Fallback: extract OS and browser family
        if 'Windows' in user_agent:
            os = 'Windows'
        elif 'Mac' in user_agent:
            os = 'macOS'
        elif 'Linux' in user_agent:
            os = 'Linux'
        elif 'Android' in user_agent:
            os = 'Android'
        elif 'iOS' in user_agent:
            os = 'iOS'
        else:
            os = 'Unknown'
        
        return f"Unknown_{os}"
    
    @staticmethod
    def _normalize_language(accept_language: str) -> str:
        """Normalizes accept-language header."""
        # Extract primary language (e.g., 'en-US' -> 'en')
        if not accept_language:
            return 'unknown'
        
        primary = accept_language.split(',')[0].split('-')[0]
        return primary.lower()
    
    @staticmethod
    def _normalize_encoding(accept_encoding: str) -> str:
        """Normalizes accept-encoding header."""
        if not accept_encoding:
            return 'unknown'
        
        # Extract common encodings
        encodings = []
        if 'gzip' in accept_encoding:
            encodings.append('gzip')
        if 'deflate' in accept_encoding:
            encodings.append('deflate')
        if 'br' in accept_encoding:
            encodings.append('br')
        
        return ','.join(sorted(encodings)) if encodings else 'none'

    @staticmethod
    async def evaluate_login_risk(
        db_session: AsyncSession, 
        user_id: uuid.UUID, 
        ip_address: str, 
        user_agent: str,
        accept_language: Optional[str] = None,
        accept_encoding: Optional[str] = None
    ) -> Tuple[bool, str]:
        """
        Calculates if the current login context deviates significantly from established patterns.
        Uses enhanced fingerprinting and adaptive risk scoring.
        Returns: (is_high_risk: bool, reason: str)
        """
        risk_score = 0
        reasons = []

        # 1. Enhanced IP Address Analysis
        ip_result = await db_session.execute(
            select(LoginHistory.id, LoginHistory.ip_address)
            .where(LoginHistory.user_id == user_id)
            .order_by(LoginHistory.created_at.desc())
            .limit(10)
        )
        recent_ips = [row[1] for row in ip_result.fetchall()]
        
        if not RiskAnalyzer._is_ip_in_known_range(ip_address, recent_ips):
            risk_score += 30
            reasons.append("NEW_IP_RANGE")
        
        # Check for suspicious IP patterns
        if RiskAnalyzer._is_suspicious_ip(ip_address):
            risk_score += 50
            reasons.append("SUSPICIOUS_IP")

        # 2. Enhanced Device Fingerprinting
        fingerprint = RiskAnalyzer.generate_fingerprint(
            user_agent, ip_address, accept_language, accept_encoding
        )
        
        device_result = await db_session.execute(
            select(DeviceIdentity.is_trusted, DeviceIdentity.fingerprint_hash)
            .where(DeviceIdentity.user_id == user_id)
            .order_by(DeviceIdentity.last_seen.desc())
            .limit(5)
        )
        recent_devices = device_result.fetchall()
        
        # Check if this exact fingerprint is trusted
        device_trusted = None
        for is_trusted, fp_hash in recent_devices:
            if fp_hash == fingerprint:
                device_trusted = is_trusted
                break
        
        if device_trusted is None:
            risk_score += 40
            reasons.append("NEW_DEVICE_FINGERPRINT")
        elif not device_trusted:
            risk_score += 20
            reasons.append("UNTRUSTED_DEVICE")
        
        # 3. Temporal Analysis
        time_result = await db_session.execute(
            select(LoginHistory.created_at)
            .where(LoginHistory.user_id == user_id, LoginHistory.is_success == True)
            .order_by(LoginHistory.created_at.desc())
            .limit(1)
        )
        last_login = time_result.scalar()
        
        if last_login:
            hours_since_last = (datetime.now(timezone.utc) - last_login).total_seconds() / 3600
            if hours_since_last > 72:  # 3 days
                risk_score += 15
                reasons.append("UNUSUAL_TIME")
            elif hours_since_last < 0.5:  # 30 minutes - possible rapid fire
                risk_score += 25
                reasons.append("RAPID_LOGIN_ATTEMPT")
        
        # 4. Geographic Analysis (if geo data available)
        # This would integrate with a GeoIP service
        # For now, just check for impossible travel
        if last_login and recent_ips:
            if RiskAnalyzer._detect_impossible_travel(ip_address, recent_ips[0], last_login):
                risk_score += 60
                reasons.append("IMPOSSIBLE_TRAVEL")

        # Adaptive threshold based on user behavior
        base_threshold = 50
        if len(recent_ips) < 3:  # New user or infrequent login
            base_threshold = 40  # Lower threshold for new users
        
        is_risky = risk_score > base_threshold
        reason_str = ", ".join(reasons)

        if is_risky:
            db_session.add(SecurityEvent(
                user_id=user_id,
                event_type="HIGH_RISK_LOGIN",
                severity="HIGH",
                ip_address=ip_address,
                details=f"Score: {risk_score}. Reasons: {reason_str}. Fingerprint: {fingerprint[:16]}..."
            ))
            
            # Record device for future analysis
            if device_trusted is None:
                db_session.add(DeviceIdentity(
                    user_id=user_id,
                    fingerprint_hash=fingerprint,
                    is_trusted=False
                ))
        
        return is_risky, reason_str
    
    @staticmethod
    def _is_ip_in_known_range(current_ip: str, recent_ips: list) -> bool:
        """Check if current IP is in the same subnet as recent IPs."""
        if not recent_ips:
            return False
        
        def get_subnet(ip: str) -> str:
            if '.' in ip:  # IPv4
                return '.'.join(ip.split('.')[:3])
            elif ':' in ip:  # IPv6
                return ':'.join(ip.split(':')[:4])
            return ip
        
        current_subnet = get_subnet(current_ip)
        for ip in recent_ips:
            if get_subnet(ip) == current_subnet:
                return True
        return False
    
    @staticmethod
    def _is_suspicious_ip(ip_address: str) -> bool:
        """Check for known suspicious IP patterns."""
        # Check for private IPs trying to access from outside (VPN/proxy detection)
        private_ranges = [
            '10.', '172.16.', '172.17.', '172.18.', '172.19.',
            '172.20.', '172.21.', '172.22.', '172.23.', '172.24.',
            '172.25.', '172.26.', '172.27.', '172.28.', '172.29.',
            '172.30.', '172.31.', '192.168.', '127.'
        ]
        
        # In production, integrate with threat intelligence feeds
        return any(ip_address.startswith(range_prefix) for range_prefix in private_ranges)
    
    @staticmethod
    def _detect_impossible_travel(current_ip: str, previous_ip: str, previous_time) -> bool:
        """Detect impossible travel based on IP geolocation."""
        # Simplified implementation - in production, use GeoIP database
        # For now, just check if IPs are from different continents
        # This is a placeholder for proper geolocation analysis
        return False  # Placeholder - implement with GeoIP service

    @staticmethod
    async def log_attempt(
        db_session: AsyncSession, 
        user_id: uuid.UUID, 
        ip_address: str, 
        user_agent: str, 
        is_success: bool,
        auth_method: str = "password"
    ):
        """Persists the login metadata to the immutable history."""
        db_session.add(LoginHistory(
            user_id=user_id,
            ip_address=ip_address,
            user_agent=user_agent,
            is_success=is_success,
            auth_method=auth_method
        ))
        
        # If successful, potentially update device last_seen/trusted state in a real app
