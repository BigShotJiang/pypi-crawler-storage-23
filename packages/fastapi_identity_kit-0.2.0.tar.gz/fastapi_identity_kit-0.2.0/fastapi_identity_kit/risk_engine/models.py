import uuid
from datetime import datetime
from typing import Optional
from sqlalchemy import String, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func
from fastapi_identity_kit.identity_core.models import Base, User

class LoginHistory(Base):
    """
    Append-only immutable log of authentication attempts.
    """
    __tablename__ = "login_history"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    ip_address: Mapped[str] = mapped_column(String(45), nullable=False, index=True) # Supports IPv6
    user_agent: Mapped[str] = mapped_column(String(512), nullable=True)
    is_success: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # E.g., 'password', 'mfa', 'google'
    auth_method: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), index=True)

    user: Mapped["User"] = relationship("User")


class DeviceIdentity(Base):
    """
    Stores recognized device fingerprints for a user.
    """
    __tablename__ = "device_identities"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Hashed structural blueprint (e.g., hash(User-Agent + Screen Size + IP Subnet))
    fingerprint_hash: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    
    # True if the user has explicitly trusted this device or completed MFA on it
    is_trusted: Mapped[bool] = mapped_column(Boolean, default=False)
    
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    user: Mapped["User"] = relationship("User")


class SecurityEvent(Base):
    """
    Immutable audit log for medium/high-risk anomalies and lockouts.
    """
    __tablename__ = "security_events"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    user_id: Mapped[Optional[uuid.UUID]] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    
    event_type: Mapped[str] = mapped_column(String(100), nullable=False, index=True) # e.g., 'BRUTE_FORCE_DETECTED', 'NEW_IP_LOGIN'
    severity: Mapped[str] = mapped_column(String(20), nullable=False) # 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL'
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    
    details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), index=True)

    user: Mapped[Optional["User"]] = relationship("User")
