import secrets
import hmac

class StateManager:
    """
    Generates and validates OAuth2 'state' parameters.
    Used for mitigating CSRF attacks during the authorization code flow.
    """

    @staticmethod
    def generate_state(entropy_bytes: int = 32) -> str:
        """Generate high-entropy random state."""
        return secrets.token_urlsafe(entropy_bytes)

    @staticmethod
    def validate_state(expected: str, received: str) -> bool:
        """Constant-time state equality check."""
        if not expected or not received:
            return False
            
        return hmac.compare_digest(expected, received)
