import secrets
import hmac

class NonceManager:
    """
    Manages OIDC 'nonce' values to prevent ID Token replay attacks.
    """

    @staticmethod
    def generate_nonce(entropy_bytes: int = 32) -> str:
        """Generate high-entropy unguessable nonce."""
        return secrets.token_urlsafe(entropy_bytes)

    @staticmethod
    def validate_nonce_with_token(expected_nonce: str, id_token_nonce: str) -> bool:
        """
        Validates that the nonce provided in the initial OIDC request
        matches the one baked into the ID Token exactly.
        """
        if not expected_nonce or not id_token_nonce:
            return False
        return hmac.compare_digest(expected_nonce, id_token_nonce)
