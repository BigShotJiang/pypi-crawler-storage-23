import asyncio
import logging
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass
import uuid
import json

from .key_manager import KeyManager
from ..config.secret_manager import get_secret_manager

@dataclass
class RotationPolicy:
    """Configuration for key rotation policies."""
    max_age_days: int = 90
    retention_days: int = 180
    warning_days: int = 7
    auto_rotate: bool = True
    require_approval: bool = False
    notification_webhook: Optional[str] = None

@dataclass
class KeyMetadata:
    """Metadata for rotated keys."""
    kid: str
    algorithm: str
    created_at: datetime
    rotated_at: Optional[datetime] = None
    status: str = "active"  # active, rotating, retired, expired
    usage_count: int = 0
    last_used: Optional[datetime] = None

class KeyRotationService:
    """
    Automated key rotation service with policy enforcement.
    Supports multiple key types and rotation strategies.
    """
    
    def __init__(
        self,
        key_manager: KeyManager,
        policy: RotationPolicy,
        rotation_callback: Optional[Callable] = None
    ):
        self.key_manager = key_manager
        self.policy = policy
        self.rotation_callback = rotation_callback
        self.logger = logging.getLogger(__name__)
        self._rotation_in_progress = False
        
        # Track key metadata
        self._key_metadata: Dict[str, KeyMetadata] = {}
    
    async def start_rotation_scheduler(self):
        """Start the background key rotation scheduler."""
        self.logger.info("Starting key rotation scheduler")
        
        while True:
            try:
                await self._check_and_rotate_keys()
                # Check every hour
                await asyncio.sleep(3600)
            except Exception as e:
                self.logger.error(f"Error in rotation scheduler: {e}")
                await asyncio.sleep(300)  # Wait 5 minutes on error
    
    async def _check_and_rotate_keys(self):
        """Check all keys and rotate if necessary."""
        if self._rotation_in_progress:
            self.logger.warning("Rotation already in progress, skipping")
            return
        
        try:
            self._rotation_in_progress = True
            await self._rotate_expired_keys()
            await self._warn_expiring_keys()
            await self._cleanup_old_keys()
        finally:
            self._rotation_in_progress = False
    
    async def _rotate_expired_keys(self):
        """Rotate keys that have exceeded their maximum age."""
        current_time = datetime.now(timezone.utc)
        cutoff_time = current_time - timedelta(days=self.policy.max_age_days)
        
        keys_to_rotate = []
        for kid, metadata in self._key_metadata.items():
            if (metadata.status == "active" and 
                metadata.created_at < cutoff_time):
                keys_to_rotate.append((kid, metadata))
        
        if not keys_to_rotate:
            return
        
        self.logger.info(f"Found {len(keys_to_rotate)} keys to rotate")
        
        for kid, metadata in keys_to_rotate:
            try:
                await self._rotate_single_key(kid, metadata)
            except Exception as e:
                self.logger.error(f"Failed to rotate key {kid}: {e}")
    
    async def _rotate_single_key(self, old_kid: str, metadata: KeyMetadata):
        """Rotate a single key."""
        self.logger.info(f"Rotating key: {old_kid}")
        
        # Update status
        metadata.status = "rotating"
        metadata.rotated_at = datetime.now(timezone.utc)
        
        # Generate new key based on algorithm
        if metadata.algorithm == "RS256":
            new_kid = self.key_manager.generate_rsa_key()
        elif metadata.algorithm == "ES256":
            new_kid = self.key_manager.generate_ec_key()
        else:
            raise ValueError(f"Unsupported algorithm: {metadata.algorithm}")
        
        # Update metadata
        new_metadata = KeyMetadata(
            kid=new_kid,
            algorithm=metadata.algorithm,
            created_at=datetime.now(timezone.utc),
            status="active"
        )
        
        self._key_metadata[new_kid] = new_metadata
        
        # Mark old key as retired
        metadata.status = "retired"
        
        # Store rotation event
        await self._store_rotation_event(old_kid, new_kid, metadata.algorithm)
        
        # Notify callback
        if self.rotation_callback:
            await self.rotation_callback(old_kid, new_kid, metadata.algorithm)
        
        self.logger.info(f"Successfully rotated key {old_kid} -> {new_kid}")
    
    async def _warn_expiring_keys(self):
        """Send warnings for keys that will expire soon."""
        current_time = datetime.now(timezone.utc)
        warning_cutoff = current_time + timedelta(days=self.policy.warning_days)
        
        expiring_keys = []
        for kid, metadata in self._key_metadata.items():
            if (metadata.status == "active" and 
                metadata.created_at < warning_cutoff):
                expiring_keys.append((kid, metadata))
        
        if not expiring_keys:
            return
        
        self.logger.warning(f"Found {len(expiring_keys)} keys expiring soon")
        
        for kid, metadata in expiring_keys:
            days_until_expiry = (metadata.created_at - current_time).days + self.policy.max_age_days
            await self._send_expiration_warning(kid, days_until_expiry)
    
    async def _cleanup_old_keys(self):
        """Clean up keys that have exceeded retention period."""
        current_time = datetime.now(timezone.utc)
        cleanup_cutoff = current_time - timedelta(days=self.policy.retention_days)
        
        keys_to_cleanup = []
        for kid, metadata in self._key_metadata.items():
            if (metadata.status == "retired" and 
                metadata.rotated_at and 
                metadata.rotated_at < cleanup_cutoff):
                keys_to_cleanup.append((kid, metadata))
        
        if not keys_to_cleanup:
            return
        
        self.logger.info(f"Cleaning up {len(keys_to_cleanup)} old keys")
        
        for kid, metadata in keys_to_cleanup:
            try:
                await self._cleanup_key(kid, metadata)
            except Exception as e:
                self.logger.error(f"Failed to cleanup key {kid}: {e}")
    
    async def _cleanup_key(self, kid: str, metadata: KeyMetadata):
        """Clean up an old key."""
        self.logger.info(f"Cleaning up key: {kid}")
        
        # Remove from key manager
        self.key_manager._private_keys.pop(kid, None)
        self.key_manager._public_keys.pop(kid, None)
        self.key_manager._key_metadata.pop(kid, None)
        
        # Remove from metadata
        del self._key_metadata[kid]
        
        # Store cleanup event
        await self._store_cleanup_event(kid, metadata.algorithm)
    
    async def _store_rotation_event(self, old_kid: str, new_kid: str, algorithm: str):
        """Store key rotation event for auditing."""
        try:
            secret_manager = get_secret_manager()
            
            event_data = {
                "event_type": "key_rotation",
                "old_kid": old_kid,
                "new_kid": new_kid,
                "algorithm": algorithm,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "policy": {
                    "max_age_days": self.policy.max_age_days,
                    "auto_rotate": self.policy.auto_rotate
                }
            }
            
            # Store in audit log
            await secret_manager.provider.store_secret(
                f"AUDIT_KEY_ROTATION_{datetime.now().isoformat()}",
                json.dumps(event_data)
            )
            
        except Exception as e:
            self.logger.error(f"Failed to store rotation event: {e}")
    
    async def _store_cleanup_event(self, kid: str, algorithm: str):
        """Store key cleanup event for auditing."""
        try:
            secret_manager = get_secret_manager()
            
            event_data = {
                "event_type": "key_cleanup",
                "kid": kid,
                "algorithm": algorithm,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "policy": {
                    "retention_days": self.policy.retention_days
                }
            }
            
            # Store in audit log
            await secret_manager.provider.store_secret(
                f"AUDIT_KEY_CLEANUP_{datetime.now().isoformat()}",
                json.dumps(event_data)
            )
            
        except Exception as e:
            self.logger.error(f"Failed to store cleanup event: {e}")
    
    async def _send_expiration_warning(self, kid: str, days_until_expiry: int):
        """Send expiration warning notification."""
        try:
            warning_data = {
                "event_type": "key_expiration_warning",
                "kid": kid,
                "days_until_expiry": days_until_expiry,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "policy": {
                    "max_age_days": self.policy.max_age_days,
                    "warning_days": self.policy.warning_days
                }
            }
            
            # Log warning
            self.logger.warning(
                f"Key {kid} expires in {days_until_expiry} days"
            )
            
            # Send webhook notification if configured
            if self.policy.notification_webhook:
                await self._send_webhook_notification(warning_data)
            
        except Exception as e:
            self.logger.error(f"Failed to send expiration warning: {e}")
    
    async def _send_webhook_notification(self, data: dict):
        """Send webhook notification for key events."""
        import aiohttp
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.policy.notification_webhook,
                    json=data,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    if response.status == 200:
                        self.logger.info("Webhook notification sent successfully")
                    else:
                        self.logger.error(
                            f"Webhook notification failed: {response.status}"
                        )
        except Exception as e:
            self.logger.error(f"Failed to send webhook notification: {e}")
    
    def register_key(self, kid: str, algorithm: str):
        """Register a new key for rotation tracking."""
        metadata = KeyMetadata(
            kid=kid,
            algorithm=algorithm,
            created_at=datetime.now(timezone.utc),
            status="active"
        )
        self._key_metadata[kid] = metadata
        self.logger.info(f"Registered key for rotation: {kid}")
    
    def get_key_status(self, kid: str) -> Optional[KeyMetadata]:
        """Get the status of a key."""
        return self._key_metadata.get(kid)
    
    def get_all_keys_status(self) -> Dict[str, KeyMetadata]:
        """Get status of all tracked keys."""
        return self._key_metadata.copy()
    
    async def force_rotate_key(self, kid: str) -> bool:
        """Force rotation of a specific key."""
        metadata = self._key_metadata.get(kid)
        if not metadata:
            self.logger.error(f"Key {kid} not found for rotation")
            return False
        
        if metadata.status != "active":
            self.logger.error(f"Key {kid} is not active, cannot rotate")
            return False
        
        try:
            await self._rotate_single_key(kid, metadata)
            return True
        except Exception as e:
            self.logger.error(f"Failed to force rotate key {kid}: {e}")
            return False
    
    async def emergency_rotate_all_keys(self) -> Dict[str, bool]:
        """Emergency rotation of all active keys."""
        self.logger.warning("Starting emergency key rotation")
        
        results = {}
        active_keys = [
            (kid, metadata) for kid, metadata in self._key_metadata.items()
            if metadata.status == "active"
        ]
        
        for kid, metadata in active_keys:
            try:
                await self._rotate_single_key(kid, metadata)
                results[kid] = True
            except Exception as e:
                self.logger.error(f"Failed to emergency rotate key {kid}: {e}")
                results[kid] = False
        
        self.logger.info(f"Emergency rotation completed: {sum(results.values())}/{len(results)} successful")
        return results

class EncryptionKeyRotationService:
    """
    Specialized service for encryption key rotation.
    """
    
    def __init__(self, secret_manager, policy: RotationPolicy):
        self.secret_manager = secret_manager
        self.policy = policy
        self.logger = logging.getLogger(__name__)
    
    async def rotate_encryption_key(self) -> bool:
        """Rotate the master encryption key."""
        try:
            self.logger.info("Starting encryption key rotation")
            
            # Generate new encryption key
            import secrets
            new_key = secrets.token_urlsafe(32)
            
            # Store new key
            success = await self.secret_manager.store_secret("ENCRYPTION_KEY", new_key)
            
            if success:
                # Store rotation event
                event_data = {
                    "event_type": "encryption_key_rotation",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "policy": self.policy.__dict__
                }
                
                await self.secret_manager.provider.store_secret(
                    f"AUDIT_ENCRYPTION_ROTATION_{datetime.now().isoformat()}",
                    json.dumps(event_data)
                )
                
                self.logger.info("Encryption key rotation completed successfully")
                return True
            else:
                self.logger.error("Failed to store new encryption key")
                return False
                
        except Exception as e:
            self.logger.error(f"Encryption key rotation failed: {e}")
            return False
