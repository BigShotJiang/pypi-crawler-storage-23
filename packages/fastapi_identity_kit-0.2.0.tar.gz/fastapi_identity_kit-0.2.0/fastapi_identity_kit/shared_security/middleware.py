from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
import time
import hashlib
import secrets
from typing import Dict, Optional, Callable
from collections import defaultdict, deque
import asyncio
import logging

# Try to import Redis for distributed rate limiting
try:
    import redis.asyncio as redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    logging.warning("Redis not available, falling back to in-memory rate limiting")

class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Production-grade rate limiting middleware with Redis support.
    Implements sliding window rate limiting with configurable endpoints.
    """
    
    def __init__(
        self,
        app,
        redis_url: str = "redis://localhost:6379",
        default_limits: Dict[str, int] = None,
        identifier_func: Optional[Callable] = None
    ):
        super().__init__(app)
        self.default_limits = default_limits or {
            "global": {"requests": 1000, "window": 3600},  # 1000 requests per hour globally
            "oauth/authorize": {"requests": 10, "window": 300},  # 10 auth requests per 5 minutes
            "oauth/token": {"requests": 20, "window": 300},  # 20 token requests per 5 minutes
            "oauth/userinfo": {"requests": 100, "window": 300},  # 100 userinfo requests per 5 minutes
        }
        
        self.identifier_func = identifier_func or self._default_identifier
        
        if REDIS_AVAILABLE:
            self.redis_client = redis.from_url(redis_url, decode_responses=True)
        else:
            self.redis_client = None
            # In-memory fallback
            self._memory_store: Dict[str, deque] = defaultdict(deque)
            self._memory_timestamps: Dict[str, float] = {}
    
    def _default_identifier(self, request: Request) -> str:
        """Generate unique identifier for rate limiting."""
        # Use IP address as primary identifier
        client_ip = request.client.host
        
        # Add user agent for more granular limiting
        user_agent = request.headers.get("user-agent", "")
        
        # Create hash for consistent identifier
        identifier_data = f"{client_ip}:{user_agent}"
        return hashlib.sha256(identifier_data.encode()).hexdigest()[:16]
    
    def _get_limit_config(self, path: str) -> Dict[str, int]:
        """Get rate limit configuration for a specific path."""
        # Check for exact path match
        if path in self.default_limits:
            return self.default_limits[path]
        
        # Check for prefix matches
        for key, limit in self.default_limits.items():
            if key != "global" and path.startswith(key):
                return limit
        
        # Return global limit
        return self.default_limits.get("global", {"requests": 100, "window": 3600})
    
    async def dispatch(self, request: Request, call_next):
        # Skip rate limiting for health checks and static files
        if request.url.path in ["/health", "/metrics", "/favicon.ico"]:
            return await call_next(request)
        
        identifier = self.identifier_func(request)
        path = request.url.path.lstrip("/")
        limit_config = self._get_limit_config(path)
        
        # Check rate limit
        if await self._is_rate_limited(identifier, limit_config):
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={
                    "error": "rate_limit_exceeded",
                    "error_description": "Too many requests. Please try again later.",
                    "retry_after": limit_config.get("window", 60)
                },
                headers={
                    "Retry-After": str(limit_config.get("window", 60)),
                    "X-RateLimit-Limit": str(limit_config["requests"]),
                    "X-RateLimit-Window": str(limit_config["window"])
                }
            )
        
        # Process request
        response = await call_next(request)
        
        # Add rate limit headers
        remaining = await self._get_remaining_requests(identifier, limit_config)
        response.headers["X-RateLimit-Limit"] = str(limit_config["requests"])
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-RateLimit-Window"] = str(limit_config["window"])
        
        return response
    
    async def _is_rate_limited(self, identifier: str, limit_config: Dict[str, int]) -> bool:
        """Check if the identifier has exceeded rate limits."""
        if self.redis_client:
            return await self._is_rate_limited_redis(identifier, limit_config)
        else:
            return self._is_rate_limited_memory(identifier, limit_config)
    
    async def _is_rate_limited_redis(self, identifier: str, limit_config: Dict[str, int]) -> bool:
        """Check rate limit using Redis sliding window."""
        try:
            now = time.time()
            window = limit_config["window"]
            max_requests = limit_config["requests"]
            
            # Use Redis sorted set for sliding window
            key = f"rate_limit:{identifier}"
            
            # Remove old entries outside the window
            await self.redis_client.zremrangebyscore(key, 0, now - window)
            
            # Count current requests in window
            current_count = await self.redis_client.zcard(key)
            
            if current_count >= max_requests:
                return True
            
            # Add current request
            await self.redis_client.zadd(key, {str(now): now})
            await self.redis_client.expire(key, window)
            
            return False
            
        except Exception as e:
            logging.error(f"Redis rate limit error: {e}")
            # Fall back to memory storage on Redis failure
            return self._is_rate_limited_memory(identifier, limit_config)
    
    def _is_rate_limited_memory(self, identifier: str, limit_config: Dict[str, int]) -> bool:
        """Check rate limit using in-memory sliding window."""
        now = time.time()
        window = limit_config["window"]
        max_requests = limit_config["requests"]
        
        if identifier not in self._memory_store:
            self._memory_store[identifier] = deque()
        
        # Remove old entries outside the window
        while (self._memory_store[identifier] and 
               self._memory_store[identifier][0] < now - window):
            self._memory_store[identifier].popleft()
        
        # Check if limit exceeded
        if len(self._memory_store[identifier]) >= max_requests:
            return True
        
        # Add current request
        self._memory_store[identifier].append(now)
        return False
    
    async def _get_remaining_requests(self, identifier: str, limit_config: Dict[str, int]) -> int:
        """Get remaining requests for the identifier."""
        if self.redis_client:
            try:
                key = f"rate_limit:{identifier}"
                current_count = await self.redis_client.zcard(key)
                return max(0, limit_config["requests"] - current_count)
            except Exception:
                pass
        
        # Fallback to memory
        if identifier in self._memory_store:
            now = time.time()
            window = limit_config["window"]
            
            # Remove old entries
            while (self._memory_store[identifier] and 
                   self._memory_store[identifier][0] < now - window):
                self._memory_store[identifier].popleft()
            
            current_count = len(self._memory_store[identifier])
            return max(0, limit_config["requests"] - current_count)
        
        return limit_config["requests"]


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """
    Security headers middleware for OWASP compliance.
    """
    
    def __init__(self, app, custom_headers: Dict[str, str] = None):
        super().__init__(app)
        self.security_headers = {
            # Content Security Policy
            "Content-Security-Policy": (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data: https:; "
                "font-src 'self'; "
                "connect-src 'self'; "
                "frame-ancestors 'none'; "
                "base-uri 'self'; "
                "form-action 'self'"
            ),
            # Prevent clickjacking
            "X-Frame-Options": "DENY",
            # Prevent MIME type sniffing
            "X-Content-Type-Options": "nosniff",
            # Enable XSS protection
            "X-XSS-Protection": "1; mode=block",
            # Referrer policy
            "Referrer-Policy": "strict-origin-when-cross-origin",
            # HSTS (only in production with HTTPS)
            # "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload",
            # Permissions policy
            "Permissions-Policy": (
                "geolocation=(), microphone=(), camera=(), "
                "payment=(), usb=(), magnetometer=(), gyroscope=()"
            ),
            # Custom security headers
            "X-Content-Security-Policy": "default-src 'self'",
            "X-WebKit-CSP": "default-src 'self'",
        }
        
        # Add custom headers if provided
        if custom_headers:
            self.security_headers.update(custom_headers)
    
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        
        # Add security headers
        for header, value in self.security_headers.items():
            response.headers[header] = value
        
        # Add HSTS only for HTTPS requests
        if request.url.scheme == "https":
            response.headers["Strict-Transport-Security"] = (
                "max-age=31536000; includeSubDomains; preload"
            )
        
        # Remove server information
        response.headers["Server"] = "IdentityKit"
        
        return response


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """
    Security-focused request logging middleware.
    """
    
    def __init__(self, app, log_level: str = "INFO"):
        super().__init__(app)
        self.logger = logging.getLogger("security.requests")
        self.logger.setLevel(getattr(logging, log_level.upper()))
        
        # Create handler if not exists
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
    
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        
        # Get request details
        client_ip = request.client.host
        method = request.method
        path = request.url.path
        user_agent = request.headers.get("user-agent", "")
        referer = request.headers.get("referer", "")
        
        # Process request
        try:
            response = await call_next(request)
            status_code = response.status_code
            processing_time = time.time() - start_time
            
            # Log successful requests
            self.logger.info(
                f"{method} {path} - {status_code} - {client_ip} - "
                f"{processing_time:.3f}s - {user_agent[:50]}"
            )
            
            return response
            
        except Exception as e:
            processing_time = time.time() - start_time
            
            # Log errors
            self.logger.error(
                f"{method} {path} - ERROR - {client_ip} - "
                f"{processing_time:.3f}s - {str(e)} - {user_agent[:50]}"
            )
            
            # Re-raise the exception
            raise


class CORSMiddleware(BaseHTTPMiddleware):
    """
    CORS middleware with security-focused defaults.
    """
    
    def __init__(
        self,
        app,
        allowed_origins: list = None,
        allowed_methods: list = None,
        allowed_headers: list = None,
        allow_credentials: bool = False
    ):
        super().__init__(app)
        self.allowed_origins = allowed_origins or []
        self.allowed_methods = allowed_methods or ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
        self.allowed_headers = allowed_headers or [
            "Content-Type", "Authorization", "X-Requested-With"
        ]
        self.allow_credentials = allow_credentials
    
    async def dispatch(self, request: Request, call_next):
        origin = request.headers.get("origin")
        
        # Handle preflight requests
        if request.method == "OPTIONS":
            response = Response()
        else:
            response = await call_next(request)
        
        # Add CORS headers
        if origin and (not self.allowed_origins or origin in self.allowed_origins):
            response.headers["Access-Control-Allow-Origin"] = origin
            response.headers["Access-Control-Allow-Methods"] = ", ".join(self.allowed_methods)
            response.headers["Access-Control-Allow-Headers"] = ", ".join(self.allowed_headers)
            
            if self.allow_credentials:
                response.headers["Access-Control-Allow-Credentials"] = "true"
            
            response.headers["Access-Control-Max-Age"] = "86400"  # 24 hours
        
        return response
