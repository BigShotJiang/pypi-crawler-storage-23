import os
import logging
from typing import Optional, Dict, Any, Union
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend
import base64
import json
import hashlib
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

class DatabaseEncryptionService:
    """
    Production-grade database encryption service for sensitive data.
    Supports column-level encryption with key rotation.
    """
    
    def __init__(self, encryption_key: bytes, salt: Optional[bytes] = None):
        self.encryption_key = encryption_key
        self.salt = salt or os.urandom(16)
        self.logger = logging.getLogger(__name__)
        
        # Initialize Fernet for encryption
        self.fernet = Fernet(encryption_key)
        
        # Cache for encrypted columns to avoid double encryption
        self._encryption_cache: Dict[str, bool] = {}
    
    def encrypt_value(self, value: Union[str, bytes, Dict, Any]) -> str:
        """Encrypt a value for database storage."""
        if value is None:
            return None
        
        try:
            # Convert to JSON if complex type
            if isinstance(value, (dict, list)):
                value = json.dumps(value)
            elif not isinstance(value, (str, bytes)):
                value = str(value)
            
            # Encrypt
            if isinstance(value, str):
                value = value.encode('utf-8')
            
            encrypted_data = self.fernet.encrypt(value)
            
            # Return base64 encoded for safe database storage
            return base64.b64encode(encrypted_data).decode('utf-8')
            
        except Exception as e:
            self.logger.error(f"Failed to encrypt value: {e}")
            raise ValueError(f"Encryption failed: {e}")
    
    def decrypt_value(self, encrypted_value: str) -> Union[str, Dict, Any, None]:
        """Decrypt a value from database storage."""
        if encrypted_value is None:
            return None
        
        try:
            # Decode from base64
            encrypted_data = base64.b64decode(encrypted_value.encode('utf-8'))
            
            # Decrypt
            decrypted_data = self.fernet.decrypt(encrypted_data)
            
            # Try to parse as JSON first
            try:
                return json.loads(decrypted_data.decode('utf-8'))
            except (json.JSONDecodeError, UnicodeDecodeError):
                # Return as string if not valid JSON
                return decrypted_data.decode('utf-8')
                
        except Exception as e:
            self.logger.error(f"Failed to decrypt value: {e}")
            raise ValueError(f"Decryption failed: {e}")
    
    def is_encrypted_value(self, value: str) -> bool:
        """Check if a value appears to be encrypted."""
        if not value:
            return False
        
        # Check if value looks like base64 encoded data
        try:
            # Try to decode base64
            decoded = base64.b64decode(value)
            # Check if it's reasonable encrypted data length
            return len(decoded) > 32  # Fernet minimum
        except Exception:
            return False
    
    def rotate_encryption_key(self, new_key: bytes) -> Dict[str, Any]:
        """Rotate encryption key and return migration data."""
        try:
            self.logger.info("Starting encryption key rotation")
            
            # Create new encryptor with new key
            new_fernet = Fernet(new_key)
            
            # Store old key for migration
            old_fernet = self.fernet
            
            # Update current key
            self.encryption_key = new_key
            self.fernet = new_fernet
            
            migration_info = {
                "old_key_hash": hashlib.sha256(self.encryption_key).hexdigest()[:16],
                "new_key_hash": hashlib.sha256(new_key).hexdigest()[:16],
                "rotation_timestamp": datetime.now().isoformat(),
                "migration_required": True
            }
            
            self.logger.info("Encryption key rotation completed")
            return migration_info
            
        except Exception as e:
            self.logger.error(f"Encryption key rotation failed: {e}")
            raise ValueError(f"Key rotation failed: {e}")

class EncryptedColumn:
    """
    SQLAlchemy custom type for encrypted columns.
    """
    
    import sqlalchemy.types as types
    
    def __init__(self, *args, **kwargs):
        # Store original type arguments
        self.impl = types.Text(*args, **kwargs)
        self.encryption_service = None
    
    def load_dialect_impl(self, dialect):
        """Return the dialect-specific implementation."""
        return dialect.type_descriptor(types.TEXT)
    
    def process_bind_param(self, value, dialect):
        """Encrypt value before binding to database."""
        if self.encryption_service and value is not None:
            return self.encryption_service.encrypt_value(value)
        return value
    
    def process_result_value(self, value, dialect):
        """Decrypt value after retrieving from database."""
        if self.encryption_service and value is not None:
            return self.encryption_service.decrypt_value(value)
        return value

class DatabaseEncryptionManager:
    """
    Manages database encryption with automatic key rotation.
    """
    
    def __init__(self, db_session: AsyncSession, encryption_service: DatabaseEncryptionService):
        self.db_session = db_session
        self.encryption_service = encryption_service
        self.logger = logging.getLogger(__name__)
    
    async def encrypt_sensitive_columns(self, table_name: str, sensitive_columns: list):
        """Encrypt sensitive columns in a table."""
        try:
            # Build SQL to encrypt columns
            sql_statements = []
            
            for column in sensitive_columns:
                # Update statement to encrypt existing data
                sql = f"""
                    UPDATE {table_name} 
                    SET {column} = :encrypted_value 
                    WHERE {column} IS NOT NULL 
                    AND {column} NOT LIKE 'ENC:%'
                """
                sql_statements.append((sql, column))
            
            # Execute encryption statements
            for sql, column in sql_statements:
                # Get current values to encrypt
                result = await self.db_session.execute(
                    text(f"SELECT {column} FROM {table_name} WHERE {column} IS NOT NULL AND {column} NOT LIKE 'ENC:%'")
                )
                
                for row in result:
                    original_value = row[0]
                    if original_value and not self.encryption_service.is_encrypted_value(str(original_value)):
                        encrypted_value = self.encryption_service.encrypt_value(original_value)
                        
                        await self.db_session.execute(
                            text(sql),
                            {"encrypted_value": encrypted_value}
                        )
            
            await self.db_session.commit()
            self.logger.info(f"Encrypted sensitive columns for table {table_name}")
            
        except Exception as e:
            self.logger.error(f"Failed to encrypt columns for {table_name}: {e}")
            await self.db_session.rollback()
            raise
    
    async def migrate_encrypted_data(self, old_encryption_service: DatabaseEncryptionService):
        """Migrate data encrypted with old key to new key."""
        try:
            self.logger.info("Starting encrypted data migration")
            
            # Get all tables with encrypted data
            tables_query = """
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = 'public'
                AND table_name LIKE '%_encrypted'
            """
            
            result = await self.db_session.execute(text(tables_query))
            tables = [row[0] for row in result]
            
            migration_count = 0
            
            for table in tables:
                # Get table structure
                columns_query = f"""
                    SELECT column_name, data_type 
                    FROM information_schema.columns 
                    WHERE table_name = '{table}'
                """
                
                columns_result = await self.db_session.execute(text(columns_query))
                columns = [row[0] for row in columns_result if 'encrypted' in row[0]]
                
                for column in columns:
                    # Migrate each encrypted column
                    await self._migrate_column_data(table, column, old_encryption_service)
                    migration_count += 1
            
            await self.db_session.commit()
            self.logger.info(f"Migration completed: {migration_count} columns migrated")
            
        except Exception as e:
            self.logger.error(f"Data migration failed: {e}")
            await self.db_session.rollback()
            raise
    
    async def _migrate_column_data(self, table_name: str, column_name: str, old_encryption_service: DatabaseEncryptionService):
        """Migrate data in a specific column."""
        try:
            # Select all encrypted data
            select_sql = f"SELECT id, {column_name} FROM {table_name} WHERE {column_name} IS NOT NULL"
            result = await self.db_session.execute(text(select_sql))
            
            for row in result:
                record_id, encrypted_value = row
                
                # Decrypt with old key
                try:
                    decrypted_value = old_encryption_service.decrypt_value(encrypted_value)
                    
                    # Re-encrypt with new key
                    new_encrypted_value = self.encryption_service.encrypt_value(decrypted_value)
                    
                    # Update record
                    update_sql = f"UPDATE {table_name} SET {column_name} = :new_value WHERE id = :id"
                    await self.db_session.execute(
                        text(update_sql),
                        {"new_value": new_encrypted_value, "id": record_id}
                    )
                    
                except Exception as e:
                    self.logger.error(f"Failed to migrate record {record_id}: {e}")
                    continue
            
        except Exception as e:
            self.logger.error(f"Column migration failed for {table_name}.{column_name}: {e}")
            raise
    
    async def verify_encryption_integrity(self, table_name: str, column_name: str) -> Dict[str, Any]:
        """Verify encryption integrity for a column."""
        try:
            # Sample verification
            sample_query = f"""
                SELECT {column_name} FROM {table_name} 
                WHERE {column_name} IS NOT NULL 
                LIMIT 10
            """
            
            result = await self.db_session.execute(text(sample_query))
            samples = [row[0] for row in result]
            
            verification_results = {
                "total_samples": len(samples),
                "encrypted_count": 0,
                "decryption_failures": 0,
                "integrity_issues": []
            }
            
            for sample in samples:
                if self.encryption_service.is_encrypted_value(str(sample)):
                    verification_results["encrypted_count"] += 1
                    
                    try:
                        # Try to decrypt
                        self.encryption_service.decrypt_value(str(sample))
                    except Exception as e:
                        verification_results["decryption_failures"] += 1
                        verification_results["integrity_issues"].append(
                            f"Decryption failure: {e}"
                        )
            
            return verification_results
            
        except Exception as e:
            self.logger.error(f"Encryption integrity check failed: {e}")
            return {"error": str(e)}

# Utility functions for database encryption
def derive_encryption_key(password: str, salt: bytes, iterations: int = 100000) -> bytes:
    """Derive encryption key from password using PBKDF2."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=iterations,
        backend=default_backend()
    )
    return kdf.derive(password.encode())

def setup_database_encryption(app, encryption_key: bytes) -> DatabaseEncryptionService:
    """Setup database encryption for FastAPI application."""
    from sqlalchemy.ext.asyncio import create_async_engine
    from sqlalchemy.orm import sessionmaker
    
    # Create encryption service
    encryption_service = DatabaseEncryptionService(encryption_key)
    
    # Store in app state for access
    app.state.encryption_service = encryption_service
    
    return encryption_service
