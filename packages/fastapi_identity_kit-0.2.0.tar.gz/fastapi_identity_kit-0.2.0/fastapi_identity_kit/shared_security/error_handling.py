from fastapi import HTTPException, Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
import logging
import traceback
import uuid
from typing import Dict, Any, Optional, Union
from datetime import datetime, timezone
import json

class SecurityError(Exception):
    """Base class for security-related errors."""
    
    def __init__(
        self,
        message: str,
        error_code: str = "security_error",
        status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR,
        details: Optional[Dict[str, Any]] = None
    ):
        self.message = message
        self.error_code = error_code
        self.status_code = status_code
        self.details = details or {}
        super().__init__(self.message)

class AuthenticationError(SecurityError):
    """Authentication-related errors."""
    
    def __init__(self, message: str = "Authentication failed", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            message=message,
            error_code="authentication_failed",
            status_code=status.HTTP_401_UNAUTHORIZED,
            details=details
        )

class AuthorizationError(SecurityError):
    """Authorization-related errors."""
    
    def __init__(self, message: str = "Access denied", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            message=message,
            error_code="access_denied",
            status_code=status.HTTP_403_FORBIDDEN,
            details=details
        )

class TokenError(SecurityError):
    """Token-related errors."""
    
    def __init__(self, message: str = "Invalid token", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            message=message,
            error_code="invalid_token",
            status_code=status.HTTP_401_UNAUTHORIZED,
            details=details
        )

class RateLimitError(SecurityError):
    """Rate limiting errors."""
    
    def __init__(self, message: str = "Rate limit exceeded", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            message=message,
            error_code="rate_limit_exceeded",
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            details=details
        )

class ValidationError(SecurityError):
    """Validation errors."""
    
    def __init__(self, message: str = "Validation failed", details: Optional[Dict[str, Any]] = None):
        super().__init__(
            message=message,
            error_code="validation_failed",
            status_code=status.HTTP_400_BAD_REQUEST,
            details=details
        )

class SecurityErrorHandler:
    """
    Comprehensive security error handler with logging and monitoring.
    """
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        self.logger = logger or logging.getLogger("security.errors")
        self.logger.setLevel(logging.INFO)
        
        # Create handler if not exists
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
    
    def create_error_response(
        self,
        error: Union[SecurityError, Exception],
        request: Optional[Request] = None,
        include_traceback: bool = False
    ) -> JSONResponse:
        """Create standardized error response."""
        
        # Generate unique error ID for tracking
        error_id = str(uuid.uuid4())
        
        # Determine error details
        if isinstance(error, SecurityError):
            status_code = error.status_code
            error_code = error.error_code
            message = error.message
            details = error.details
        elif isinstance(error, HTTPException):
            status_code = error.status_code
            error_code = "http_error"
            message = error.detail
            details = {}
        elif isinstance(error, RequestValidationError):
            status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
            error_code = "validation_error"
            message = "Request validation failed"
            details = {"validation_errors": error.errors()}
        else:
            status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
            error_code = "internal_error"
            message = "An internal error occurred"
            details = {}
        
        # Log the error
        self._log_error(error, request, error_id, include_traceback)
        
        # Build error response
        error_response = {
            "error": error_code,
            "error_description": message,
            "error_id": error_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        
        # Add details if present (and safe to expose)
        if details:
            # Filter sensitive information
            safe_details = self._filter_sensitive_data(details)
            if safe_details:
                error_response["details"] = safe_details
        
        # Add request information for debugging (in development)
        if request and self._is_development():
            error_response["request_info"] = {
                "method": request.method,
                "path": request.url.path,
                "query_params": dict(request.query_params),
            }
        
        return JSONResponse(
            status_code=status_code,
            content=error_response,
            headers={
                "X-Error-ID": error_id,
                "X-Content-Type-Options": "nosniff"
            }
        )
    
    def _log_error(
        self,
        error: Exception,
        request: Optional[Request],
        error_id: str,
        include_traceback: bool
    ):
        """Log error with appropriate level and context."""
        
        # Build log context
        context = {
            "error_id": error_id,
            "error_type": type(error).__name__,
            "error_message": str(error)
        }
        
        if request:
            context.update({
                "method": request.method,
                "path": request.url.path,
                "client_ip": request.client.host if request.client else None,
                "user_agent": request.headers.get("user-agent", "")
            })
        
        # Determine log level based on error type
        if isinstance(error, (AuthenticationError, AuthorizationError)):
            log_level = logging.WARNING
        elif isinstance(error, (ValidationError, TokenError)):
            log_level = logging.INFO
        elif isinstance(error, RateLimitError):
            log_level = logging.INFO
        else:
            log_level = logging.ERROR
        
        # Log with appropriate level
        if log_level >= logging.ERROR:
            self.logger.error(
                f"Security error occurred: {error_id}",
                extra={"context": context},
                exc_info=include_traceback
            )
        else:
            self.logger.log(
                log_level,
                f"Security event: {error_id} - {context.get('error_type', 'Unknown')}",
                extra={"context": context}
            )
    
    def _filter_sensitive_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Filter out sensitive information from error details."""
        sensitive_keys = {
            'password', 'secret', 'token', 'key', 'authorization',
            'cookie', 'session', 'credential', 'auth'
        }
        
        def filter_dict(d: Dict[str, Any]) -> Dict[str, Any]:
            filtered = {}
            for key, value in d.items():
                key_lower = key.lower()
                if any(sensitive in key_lower for sensitive in sensitive_keys):
                    filtered[key] = "[REDACTED]"
                elif isinstance(value, dict):
                    filtered[key] = filter_dict(value)
                elif isinstance(value, list):
                    filtered[key] = [
                        filter_dict(item) if isinstance(item, dict) else item
                        for item in value
                    ]
                else:
                    filtered[key] = value
            return filtered
        
        return filter_dict(data)
    
    def _is_development(self) -> bool:
        """Check if running in development mode."""
        # In production, this should check environment variables
        import os
        return os.getenv("ENVIRONMENT", "development").lower() != "production"


def create_security_error_handler(app):
    """
    Create and register security error handlers for FastAPI app.
    """
    error_handler = SecurityErrorHandler()
    
    @app.exception_handler(SecurityError)
    async def security_error_handler(request: Request, exc: SecurityError):
        return error_handler.create_error_response(exc, request)
    
    @app.exception_handler(AuthenticationError)
    async def auth_error_handler(request: Request, exc: AuthenticationError):
        return error_handler.create_error_response(exc, request)
    
    @app.exception_handler(AuthorizationError)
    async def authz_error_handler(request: Request, exc: AuthorizationError):
        return error_handler.create_error_response(exc, request)
    
    @app.exception_handler(TokenError)
    async def token_error_handler(request: Request, exc: TokenError):
        return error_handler.create_error_response(exc, request)
    
    @app.exception_handler(RateLimitError)
    async def rate_limit_error_handler(request: Request, exc: RateLimitError):
        return error_handler.create_error_response(exc, request)
    
    @app.exception_handler(ValidationError)
    async def validation_error_handler(request: Request, exc: ValidationError):
        return error_handler.create_error_response(exc, request)
    
    @app.exception_handler(RequestValidationError)
    async def request_validation_error_handler(request: Request, exc: RequestValidationError):
        return error_handler.create_error_response(exc, request)
    
    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(request: Request, exc: StarletteHTTPException):
        return error_handler.create_error_response(exc, request)
    
    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        # Log full traceback for unexpected errors
        return error_handler.create_error_response(
            exc, request, include_traceback=True
        )
    
    return error_handler


# Utility functions for common error scenarios
def raise_auth_error(message: str = "Authentication required", details: Optional[Dict[str, Any]] = None):
    """Raise authentication error."""
    raise AuthenticationError(message, details)

def raise_authz_error(message: str = "Access denied", details: Optional[Dict[str, Any]] = None):
    """Raise authorization error."""
    raise AuthorizationError(message, details)

def raise_token_error(message: str = "Invalid token", details: Optional[Dict[str, Any]] = None):
    """Raise token error."""
    raise TokenError(message, details)

def raise_rate_limit_error(message: str = "Rate limit exceeded", details: Optional[Dict[str, Any]] = None):
    """Raise rate limit error."""
    raise RateLimitError(message, details)

def raise_validation_error(message: str = "Validation failed", details: Optional[Dict[str, Any]] = None):
    """Raise validation error."""
    raise ValidationError(message, details)
