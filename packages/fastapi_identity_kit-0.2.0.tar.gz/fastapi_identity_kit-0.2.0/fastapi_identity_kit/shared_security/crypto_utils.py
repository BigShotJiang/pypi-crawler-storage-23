import secrets
import hashlib
import hmac

def generate_opaque_token(entropy_bytes: int = 32) -> str:
    """
    Generates a high-entropy cryptographically secure opaque token (e.g., for refresh tokens).
    32 bytes = 256 bits of entropy.
    """
    return secrets.token_urlsafe(entropy_bytes)

def hash_token(token: str) -> str:
    """
    Hashes a token using SHA-256 for secure database storage.
    This prevents plaintext tokens from being exposed if the database is compromised.
    """
    return hashlib.sha256(token.encode('utf-8')).hexdigest()

def constant_time_compare(val1: str, val2: str) -> bool:
    """
    Safely compares two strings in constant time to mitigate timing attacks.
    """
    return hmac.compare_digest(val1.encode('utf-8'), val2.encode('utf-8'))
