import jwt
from typing import Dict, Any, List
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicNumbers
from cryptography.hazmat.primitives.asymmetric.ec import EllipticCurvePublicNumbers, SECP256R1
from cryptography.hazmat.backends import default_backend
import base64

class JWKValidator:
    """
    Validates incoming JWTs against a provided JWKS (remote or local).
    """

    @staticmethod
    def decode_base64url_uint(val: str) -> int:
        """Decodes a base64url encoded string into an integer."""
        val += '=' * (4 - (len(val) % 4)) if len(val) % 4 != 0 else ''
        return int.from_bytes(base64.urlsafe_b64decode(val), 'big')

    @staticmethod
    def jwk_to_public_key(jwk: Dict[str, Any]):
        """Converts a parsed JWK dictionary into a cryptography PublicKey."""
        kty = jwk.get("kty")
        if kty == "RSA":
            n = JWKValidator.decode_base64url_uint(jwk['n'])
            e = JWKValidator.decode_base64url_uint(jwk['e'])
            return RSAPublicNumbers(e, n).public_key(default_backend())
        elif kty == "EC" and jwk.get("crv") == "P-256":
            x = JWKValidator.decode_base64url_uint(jwk['x'])
            y = JWKValidator.decode_base64url_uint(jwk['y'])
            return EllipticCurvePublicNumbers(x, y, SECP256R1()).public_key(default_backend())
        else:
            raise ValueError(f"Unsupported key type: {kty}")

    def __init__(self, jwks: Dict[str, Any]):
        self.keys = {key["kid"]: self.jwk_to_public_key(key) for key in jwks.get("keys", [])}

    def verify_token(self, token: str, audience: str, issuer: str, algorithms: List[str] = ["RS256", "ES256"]) -> Dict[str, Any]:
        """Verifies a token strictly using the keys loaded from JWKS."""
        try:
            unverified_headers = jwt.get_unverified_header(token)
            kid = unverified_headers.get("kid")
            if not kid or kid not in self.keys:
                raise ValueError(f"Key ID '{kid}' not found in JWKS.")
            
            public_key = self.keys[kid]
            
            return jwt.decode(
                token,
                public_key,
                algorithms=algorithms,
                audience=audience,
                issuer=issuer,
                options={
                    "require": ["exp", "iat", "iss", "aud"]
                }
            )
        except jwt.PyJWTError as e:
            raise ValueError(f"Token validation failed: {str(e)}")
