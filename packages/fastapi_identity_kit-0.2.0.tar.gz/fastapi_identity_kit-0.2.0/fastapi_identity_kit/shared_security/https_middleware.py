from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import RedirectResponse
import logging
from typing import Optional
from urllib.parse import urlparse
import re

class HTTPSEnforcementMiddleware(BaseHTTPMiddleware):
    """
    Enforces HTTPS connections with configurable policies.
    Redirects HTTP to HTTPS and sets security headers.
    """
    
    def __init__(
        self,
        app,
        enforce_https: bool = True,
        hsts_max_age: int = 31536000,  # 1 year
        hsts_include_subdomains: bool = True,
        hsts_preload: bool = True,
        allowed_http_hosts: Optional[list] = None,
        https_port: int = 443,
        http_port: int = 80
    ):
        super().__init__(app)
        self.enforce_https = enforce_https
        self.hsts_max_age = hsts_max_age
        self.hsts_include_subdomains = hsts_include_subdomains
        self.hsts_preload = hsts_preload
        self.allowed_http_hosts = allowed_http_hosts or []
        self.https_port = https_port
        self.http_port = http_port
        self.logger = logging.getLogger(__name__)
    
    async def dispatch(self, request: Request, call_next):
        # Check if request is already HTTPS
        if self._is_https_request(request):
            response = await call_next(request)
            self._add_security_headers(response)
            return response
        
        # Check if HTTP is allowed for this host
        if self._is_http_allowed(request):
            response = await call_next(request)
            return response
        
        # Redirect to HTTPS
        return self._redirect_to_https(request)
    
    def _is_https_request(self, request: Request) -> bool:
        """Check if request is already using HTTPS."""
        # Check URL scheme
        if request.url.scheme == "https":
            return True
        
        # Check forwarded headers (for load balancers)
        forwarded_proto = request.headers.get("x-forwarded-proto", "").lower()
        if forwarded_proto == "https":
            return True
        
        # Check CloudFront header
        cloudfront_proto = request.headers.get("cloudfront-forwarded-proto", "").lower()
        if cloudfront_proto == "https":
            return True
        
        # Check standard HTTPS headers
        https_headers = [
            "x-forwarded-ssl",
            "x-arr-ssl",  # Azure
            "x-forwarded-ssl",  # Nginx
        ]
        
        for header in https_headers:
            if request.headers.get(header):
                return True
        
        return False
    
    def _is_http_allowed(self, request: Request) -> bool:
        """Check if HTTP is allowed for this host."""
        if not self.enforce_https:
            return True
        
        host = request.headers.get("host", "").split(":")[0]
        return host in self.allowed_http_hosts
    
    def _redirect_to_https(self, request: Request) -> RedirectResponse:
        """Create HTTPS redirect response."""
        # Build HTTPS URL
        url = request.url
        https_url = url.replace(scheme="https")
        
        # Handle port differences
        if self.https_port != 443:
            https_url = https_url.replace(port=self.https_port)
        
        self.logger.info(f"Redirecting HTTP to HTTPS: {url} -> {https_url}")
        
        return RedirectResponse(
            url=str(https_url),
            status_code=301  # Permanent redirect
        )
    
    def _add_security_headers(self, response: Response):
        """Add HTTPS-related security headers."""
        # HSTS header
        if self.enforce_https:
            hsts_value = f"max-age={self.hsts_max_age}"
            
            if self.hsts_include_subdomains:
                hsts_value += "; includeSubDomains"
            
            if self.hsts_preload:
                hsts_value += "; preload"
            
            response.headers["Strict-Transport-Security"] = hsts_value
        
        # Other HTTPS-related headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        
        # Referrer policy for HTTPS
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        
        # Remove server information
        response.headers["Server"] = "IdentityKit"

class CertificateValidator:
    """
    Validates SSL certificates and provides certificate information.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def validate_certificate(self, hostname: str, port: int = 443) -> dict:
        """Validate SSL certificate for a hostname."""
        try:
            import ssl
            import socket
            
            # Create SSL context
            context = ssl.create_default_context()
            
            # Connect and get certificate
            with socket.create_connection((hostname, port), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cert = ssock.getpeercert(binary_form=True)
                    cert_der = cert
            
            # Parse certificate
            from cryptography import x509
            from cryptography.hazmat.backends import default_backend
            
            cert_obj = x509.load_der_x509_certificate(cert_der, default_backend())
            
            # Extract certificate information
            cert_info = {
                "valid": True,
                "subject": cert_obj.subject.rfc4514_string(),
                "issuer": cert_obj.issuer.rfc4514_string(),
                "not_valid_before": cert_obj.not_valid_before.isoformat(),
                "not_valid_after": cert_obj.not_valid_after.isoformat(),
                "serial_number": str(cert_obj.serial_number),
                "signature_algorithm": cert_obj.signature_algorithm_oid._name,
                "version": cert_obj.version.name
            }
            
            # Check expiration
            import datetime
            now = datetime.datetime.utcnow()
            if now < cert_obj.not_valid_before:
                cert_info["valid"] = False
                cert_info["error"] = "Certificate not yet valid"
            elif now > cert_obj.not_valid_after:
                cert_info["valid"] = False
                cert_info["error"] = "Certificate expired"
            
            # Check hostname
            try:
                ssl.match_hostname(cert_obj, hostname)
            except ssl.CertificateError as e:
                cert_info["valid"] = False
                cert_info["error"] = f"Hostname mismatch: {e}"
            
            return cert_info
            
        except Exception as e:
            self.logger.error(f"Failed to validate certificate for {hostname}: {e}")
            return {
                "valid": False,
                "error": str(e)
            }
    
    def get_certificate_chain(self, hostname: str, port: int = 443) -> list:
        """Get the full certificate chain."""
        try:
            import ssl
            import socket
            
            context = ssl.create_default_context()
            
            with socket.create_connection((hostname, port), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    der_certs = ssock.getpeercert(binary_form=True, chain=True)
            
            from cryptography import x509
            from cryptography.hazmat.backends import default_backend
            
            chain = []
            for der_cert in der_certs:
                cert = x509.load_der_x509_certificate(der_cert, default_backend())
                chain.append({
                    "subject": cert.subject.rfc4514_string(),
                    "issuer": cert.issuer.rfc4514_string(),
                    "serial_number": str(cert.serial_number)
                })
            
            return chain
            
        except Exception as e:
            self.logger.error(f"Failed to get certificate chain for {hostname}: {e}")
            return []

class SecurityPolicyGenerator:
    """
    Generates security policies for HTTPS enforcement.
    """
    
    @staticmethod
    def generate_csp_policy(
        script_src: list = None,
        style_src: list = None,
        img_src: list = None,
        connect_src: list = None,
        font_src: list = None,
        media_src: list = None,
        object_src: list = None,
        child_src: list = None,
        frame_src: list = None,
        worker_src: list = None,
        manifest_src: list = None,
        upgrade_insecure_requests: bool = True
    ) -> str:
        """Generate Content Security Policy."""
        
        directives = {
            "default-src": ["'self'"],
            "script-src": script_src or ["'self'", "'unsafe-inline'"],
            "style-src": style_src or ["'self'", "'unsafe-inline'"],
            "img-src": img_src or ["'self'", "data:", "https:"],
            "connect-src": connect_src or ["'self'"],
            "font-src": font_src or ["'self'"],
            "media-src": media_src or ["'self'"],
            "object-src": object_src or ["'none'"],
            "child-src": child_src or ["'none'"],
            "frame-src": frame_src or ["'none'"],
            "worker-src": worker_src or ["'self'"],
            "manifest-src": manifest_src or ["'self'"],
            "base-uri": ["'self'"],
            "form-action": ["'self'"],
            "frame-ancestors": ["'none'"]
        }
        
        if upgrade_insecure_requests:
            directives["upgrade-insecure-requests"] = []
        
        # Build CSP string
        csp_parts = []
        for directive, sources in directives.items():
            if sources:
                csp_parts.append(f"{directive} {' '.join(sources)}")
        
        return "; ".join(csp_parts)
    
    @staticmethod
    def generate_permissions_policy(
        geolocation: str = "()",
        microphone: str = "()",
        camera: str = "()",
        payment: str = "()",
        usb: str = "()",
        magnetometer: str = "()",
        gyroscope: str = "()",
        accelerometer: str = "()",
        ambient_light_sensor: str = "()",
        autoplay: str = "self",
        encrypted_media: str = "self",
        fullscreen: str = "self",
        geolocation_self: str = "self"
    ) -> str:
        """Generate Permissions Policy."""
        
        permissions = {
            "geolocation": geolocation,
            "microphone": microphone,
            "camera": camera,
            "payment": payment,
            "usb": usb,
            "magnetometer": magnetometer,
            "gyroscope": gyroscope,
            "accelerometer": accelerometer,
            "ambient-light-sensor": ambient_light_sensor,
            "autoplay": autoplay,
            "encrypted-media": encrypted_media,
            "fullscreen": fullscreen,
            "geolocation": geolocation_self
        }
        
        # Build permissions policy string
        policy_parts = []
        for permission, value in permissions.items():
            policy_parts.append(f"{permission}={value}")
        
        return ", ".join(policy_parts)
