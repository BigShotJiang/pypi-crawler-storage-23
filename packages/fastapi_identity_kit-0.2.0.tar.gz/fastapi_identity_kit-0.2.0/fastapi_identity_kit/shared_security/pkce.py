import hashlib
import base64
import hmac
import re
from typing import Optional

class PKCEVerifier:
    """
    Handles PKCE (Proof Key for Code Exchange) validation as per RFC 7636.
    Only allows S256. 'plain' is strictly disallowed for security.
    Implements comprehensive input validation and timing attack protection.
    """
    
    # RFC 7636: code_verifier MUST be 43-128 characters
    MIN_CODE_VERIFIER_LENGTH = 43
    MAX_CODE_VERIFIER_LENGTH = 128
    
    # RFC 7636: code_challenge is base64url-encoded SHA256 hash
    # Should be 43 characters (256 bits = 43 base64url chars without padding)
    EXPECTED_CHALLENGE_LENGTH = 43
    
    # Unreserved characters per RFC 3986
    VALID_VERIFIER_PATTERN = re.compile(r'^[A-Za-z0-9\-._~]+$')
    
    # Base64url pattern (no padding)
    VALID_CHALLENGE_PATTERN = re.compile(r'^[A-Za-z0-9_-]+$')
    
    @staticmethod
    def validate_code_verifier(code_verifier: str) -> bool:
        """
        Validates code_verifier format per RFC 7636.
        Must be 43-128 characters from the unreserved set.
        """
        if not code_verifier:
            return False
        
        # Length validation
        if (len(code_verifier) < PKCEVerifier.MIN_CODE_VERIFIER_LENGTH or 
            len(code_verifier) > PKCEVerifier.MAX_CODE_VERIFIER_LENGTH):
            return False
        
        # Character validation (unreserved set per RFC 3986)
        if not PKCEVerifier.VALID_VERIFIER_PATTERN.match(code_verifier):
            return False
        
        # Entropy check (optional but recommended)
        # Ensure sufficient entropy to prevent brute force
        if len(set(code_verifier)) < 10:  # At least 10 unique characters
            return False
        
        return True
    
    @staticmethod
    def validate_code_challenge(code_challenge: str) -> bool:
        """
        Validates code_challenge format.
        Must be base64url-encoded without padding.
        """
        if not code_challenge:
            return False
        
        # Length validation (should be 43 for SHA256)
        if len(code_challenge) != PKCEVerifier.EXPECTED_CHALLENGE_LENGTH:
            return False
        
        # Character validation (base64url without padding)
        if not PKCEVerifier.VALID_CHALLENGE_PATTERN.match(code_challenge):
            return False
        
        # Should not contain padding characters
        if '=' in code_challenge:
            return False
        
        return True
    
    @staticmethod
    def verify_s256(code_challenge: str, code_verifier: str) -> bool:
        """
        Verifies an S256 PKCE challenge with comprehensive validation.
        Uses constant-time comparison to prevent timing attacks.
        """
        # Input validation first
        if not PKCEVerifier.validate_code_challenge(code_challenge):
            return False
            
        if not PKCEVerifier.validate_code_verifier(code_verifier):
            return False
        
        try:
            # Compute SHA256 hash of code_verifier
            hash_digest = hashlib.sha256(code_verifier.encode('ascii')).digest()
            
            # Create base64url encoded representation, removing padding
            expected_challenge = base64.urlsafe_b64encode(hash_digest).decode('ascii').rstrip('=')
            
            # Use constant-time comparison to prevent timing attacks
            return hmac.compare_digest(expected_challenge, code_challenge)
            
        except (UnicodeEncodeError, ValueError):
            # Handle encoding errors gracefully
            return False
