from typing import Dict, Any, Optional
from cryptography.hazmat.primitives.asymmetric import rsa, ec
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
from cryptography.fernet import Fernet
import base64
import uuid
import os
from datetime import datetime, timezone, timedelta
import secrets

class KeyManager:
    """
    Production-grade key manager with secure key storage and rotation.
    Separates signing and encryption keys, supports key rotation via Key IDs (kids).
    Implements encryption at rest for private keys.
    """

    def __init__(self, encryption_key: Optional[bytes] = None):
        self._private_keys = {}
        self._public_keys = {}
        self._key_metadata = {}  # Store creation time, algorithm, etc.
        
        # Initialize encryption for private keys
        if encryption_key:
            self._fernet = Fernet(encryption_key)
        else:
            # Generate a new encryption key if not provided
            # In production, this should come from a secure key vault
            self._fernet = Fernet(Fernet.generate_key())
            
    def _encrypt_private_key(self, private_key_bytes: bytes) -> bytes:
        """Encrypts private key bytes for secure storage."""
        return self._fernet.encrypt(private_key_bytes)
        
    def _decrypt_private_key(self, encrypted_key_bytes: bytes) -> bytes:
        """Decrypts private key bytes from storage."""
        return self._fernet.decrypt(encrypted_key_bytes)

    def generate_rsa_key(self, kid: Optional[str] = None, keysize: int = 2048) -> str:
        """Generates an RSA keypair for RS256 signing with secure storage."""
        if kid is None:
            kid = str(uuid.uuid4())
        
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=keysize,
            backend=default_backend()
        )
        
        # Serialize and encrypt private key
        private_key_bytes = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()  # We'll encrypt ourselves
        )
        
        encrypted_private_key = self._encrypt_private_key(private_key_bytes)
        
        # Store encrypted private key and public key
        self._private_keys[kid] = encrypted_private_key
        self._public_keys[kid] = private_key.public_key()
        
        # Store metadata for rotation
        self._key_metadata[kid] = {
            "algorithm": "RS256",
            "key_size": keysize,
            "created_at": datetime.now(timezone.utc),
            "is_active": True
        }
        
        return kid

    def generate_ec_key(self, kid: Optional[str] = None) -> str:
        """Generates an EC keypair for ES256 signing with secure storage."""
        if kid is None:
            kid = str(uuid.uuid4())

        private_key = ec.generate_private_key(
            ec.SECP256R1(),
            backend=default_backend()
        )
        
        # Serialize and encrypt private key
        private_key_bytes = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()  # We'll encrypt ourselves
        )
        
        encrypted_private_key = self._encrypt_private_key(private_key_bytes)
        
        # Store encrypted private key and public key
        self._private_keys[kid] = encrypted_private_key
        self._public_keys[kid] = private_key.public_key()
        
        # Store metadata for rotation
        self._key_metadata[kid] = {
            "algorithm": "ES256",
            "curve": "P-256",
            "created_at": datetime.now(timezone.utc),
            "is_active": True
        }
        
        return kid

    def get_private_key(self, kid: str):
        """Retrieves and decrypts private key."""
        encrypted_key = self._private_keys.get(kid)
        if not encrypted_key:
            return None
            
        try:
            private_key_bytes = self._decrypt_private_key(encrypted_key)
            private_key = serialization.load_pem_private_key(
                private_key_bytes,
                password=None,
                backend=default_backend()
            )
            return private_key
        except Exception:
            return None

    def get_public_key(self, kid: str):
        return self._public_keys.get(kid)
    
    def get_key_metadata(self, kid: str) -> Optional[Dict[str, Any]]:
        """Returns metadata for a key."""
        return self._key_metadata.get(kid)
    
    def rotate_keys(self, max_age_days: int = 90) -> Dict[str, str]:
        """
        Rotates keys older than max_age_days.
        Returns mapping of old_kid -> new_kid
        """
        rotation_map = {}
        cutoff_time = datetime.now(timezone.utc) - timedelta(days=max_age_days)
        
        for kid, metadata in list(self._key_metadata.items()):
            if metadata["created_at"] < cutoff_time and metadata["is_active"]:
                # Generate new key of same type
                if metadata["algorithm"] == "RS256":
                    new_kid = self.generate_rsa_key(keysize=metadata["key_size"])
                elif metadata["algorithm"] == "ES256":
                    new_kid = self.generate_ec_key()
                else:
                    continue
                    
                # Mark old key as inactive but keep it for validation
                self._key_metadata[kid]["is_active"] = False
                rotation_map[kid] = new_kid
                
        return rotation_map
    
    def cleanup_old_keys(self, grace_period_days: int = 30) -> int:
        """
        Removes keys that have been inactive for grace_period_days.
        Returns number of keys cleaned up.
        """
        cutoff_time = datetime.now(timezone.utc) - timedelta(days=grace_period_days)
        keys_to_remove = []
        
        for kid, metadata in self._key_metadata.items():
            if (not metadata["is_active"] and 
                metadata["created_at"] < cutoff_time):
                keys_to_remove.append(kid)
                
        for kid in keys_to_remove:
            self._private_keys.pop(kid, None)
            self._public_keys.pop(kid, None)
            self._key_metadata.pop(kid, None)
            
        return len(keys_to_remove)
    
    def export_jwk(self, kid: str) -> Dict[str, Any]:
        """Exports the public key in JSON Web Key (JWK) format."""
        pub_key = self.get_public_key(kid)
        if not pub_key:
            raise ValueError(f"No key found for kid: {kid}")
        
        if isinstance(pub_key, rsa.RSAPublicKey):
            numbers = pub_key.public_numbers()
            def _b64(val: int) -> str:
                byte_len = (val.bit_length() + 7) // 8
                return base64.urlsafe_b64encode(val.to_bytes(byte_len, 'big')).decode('utf-8').rstrip('=')
            
            return {
                "kty": "RSA",
                "kid": kid,
                "use": "sig",
                "alg": "RS256",
                "n": _b64(numbers.n),
                "e": _b64(numbers.e)
            }
            
        elif isinstance(pub_key, ec.EllipticCurvePublicKey):
            numbers = pub_key.public_numbers()
            def _b64(val: int) -> str:
                byte_len = 32
                return base64.urlsafe_b64encode(val.to_bytes(byte_len, 'big')).decode('utf-8').rstrip('=')
            
            return {
                "kty": "EC",
                "kid": kid,
                "crv": "P-256",
                "use": "sig",
                "x": _b64(numbers.x),
                "y": _b64(numbers.y)
            }
        else:
            raise ValueError("Unsupported key type.")

    def export_jwks(self) -> Dict[str, Any]:
        """Provides the full JWKS representation."""
        keys = []
        for kid in self._public_keys:
            keys.append(self.export_jwk(kid))
        return {"keys": keys}
