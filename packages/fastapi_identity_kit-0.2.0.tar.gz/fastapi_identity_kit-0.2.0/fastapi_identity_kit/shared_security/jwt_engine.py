import jwt
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone

from .key_manager import KeyManager

class JWTEngine:
    """
    Production-grade JWT Engine.
    Handles strict signing and verification (exp, iat, nbf, iss, aud).
    Supported algorithms: RS256, ES256.
    """
    
    ALLOWED_ALGORITHMS = ["RS256", "ES256"]

    def __init__(self, key_manager: KeyManager, issuer: str):
        self.key_manager = key_manager
        self.issuer = issuer

    def sign(self, payload: Dict[str, Any], kid: str, alg: str = "RS256") -> str:
        """
        Safely signs a JWT with the specified Key ID and algorithm.
        Ensures strict separation of signing vs encryption internally via key_manager.
        """
        if alg not in self.ALLOWED_ALGORITHMS:
            raise ValueError(f"Algorithm {alg} is not supported. Must be one of {self.ALLOWED_ALGORITHMS}")

        private_key = self.key_manager.get_private_key(kid)
        if not private_key:
            raise ValueError(f"Signing key not found for kid: {kid}")

        headers = {
            "kid": kid,
            "alg": alg
        }
        
        # Merge issuer to payload if not present
        if "iss" not in payload:
            payload["iss"] = self.issuer
            
        return jwt.encode(payload, private_key, algorithm=alg, headers=headers)

    def verify(self, token: str, audience: str, verify_options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Verifies a JWT. Strictly enforces safe constant-time checks inside PyJWT.
        Validates exp, iat, nbf automatically.
        """
        try:
            unverified_headers = jwt.get_unverified_header(token)
        except jwt.PyJWTError as e:
            raise ValueError(f"Invalid token headers: {e}")

        kid = unverified_headers.get("kid")
        if not kid:
            raise ValueError("Missing 'kid' in token header.")
        
        alg = unverified_headers.get("alg")
        if alg not in self.ALLOWED_ALGORITHMS:
            raise ValueError(f"Algorithm {alg} not allowed.")

        public_key = self.key_manager.get_public_key(kid)
        if not public_key:
            raise ValueError(f"Public key not found for kid: {kid}")

        options = {
            "verify_signature": True,
            "verify_exp": True,
            "verify_nbf": True,
            "verify_iat": True,
            "verify_iss": True,
            "verify_aud": True,
            "require": ["exp", "iat", "iss", "aud"]
        }
        if verify_options:
            options.update(verify_options)

        try:
            decoded = jwt.decode(
                token,
                public_key,
                algorithms=[alg],
                issuer=self.issuer,
                audience=audience,
                options=options
            )
            return decoded
        except jwt.PyJWTError as e:
            raise ValueError(f"Token validation failed: {str(e)}")
