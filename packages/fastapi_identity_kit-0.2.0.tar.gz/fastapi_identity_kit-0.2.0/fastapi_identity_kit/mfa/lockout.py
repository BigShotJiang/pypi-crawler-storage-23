from datetime import datetime, timezone, timedelta
from typing import Dict

# Simple in-memory rate limiter for Phase 5 demo. 
# In production, this would be Redis-backed.
_memory_store: Dict[str, dict] = {}

class LockoutService:
    """
    Sliding window rate limit / lockout service to protect 6-digit MFA codes from brute force.
    """
    
    def __init__(self, max_attempts: int = 5, lockout_minutes: int = 15):
        self.max_attempts = max_attempts
        self.lockout_minutes = lockout_minutes

    async def is_locked_out(self, db_session, user_id: str) -> bool:
        """Check if user is currently locked out of MFA."""
        user_str = str(user_id)
        if user_str not in _memory_store:
            return False
            
        record = _memory_store[user_str]
        
        # Check lockout expiration
        if record.get("locked_until"):
            if datetime.now(timezone.utc) < record["locked_until"]:
                return True
            else:
                # Lockout expired, reset automatically
                del _memory_store[user_str]
                return False
                
        return False

    async def record_failure(self, db_session, user_id: str):
        """Records a failed attempt. Locks out if threshold reached."""
        user_str = str(user_id)
        if user_str not in _memory_store:
            _memory_store[user_str] = {"attempts": 0, "locked_until": None}
            
        record = _memory_store[user_str]
        record["attempts"] += 1
        
        if record["attempts"] >= self.max_attempts:
            record["locked_until"] = datetime.now(timezone.utc) + timedelta(minutes=self.lockout_minutes)

    async def reset_failures(self, db_session, user_id: str):
        """Resets failures on a successful login."""
        user_str = str(user_id)
        if user_str in _memory_store:
            del _memory_store[user_str]
