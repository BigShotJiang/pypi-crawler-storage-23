from datetime import datetime, timezone, timedelta
from typing import Optional, Dict
import json
import asyncio
import logging

# Try to import redis, fall back to in-memory if not available
try:
    import redis.asyncio as redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    logging.warning("Redis not available, falling back to in-memory lockout storage")

class RedisLockoutService:
    """
    Production-grade lockout service using Redis for distributed environments.
    Implements sliding window rate limiting with exponential backoff.
    """
    
    def __init__(
        self, 
        redis_url: str = "redis://localhost:6379",
        max_attempts: int = 5, 
        base_lockout_minutes: int = 15,
        max_lockout_minutes: int = 1440  # 24 hours max
    ):
        self.max_attempts = max_attempts
        self.base_lockout_minutes = base_lockout_minutes
        self.max_lockout_minutes = max_lockout_minutes
        
        if REDIS_AVAILABLE:
            self.redis_client = redis.from_url(redis_url, decode_responses=True)
        else:
            self.redis_client = None
            self._memory_store: Dict[str, dict] = {}
            
    async def _get_redis_key(self, user_id: str) -> str:
        """Generates Redis key for user lockout data."""
        return f"lockout:mfa:{user_id}"
    
    async def _get_attempts_key(self, user_id: str) -> str:
        """Generates Redis key for attempt tracking."""
        return f"attempts:mfa:{user_id}"
    
    async def is_locked_out(self, db_session, user_id: str) -> bool:
        """Check if user is currently locked out of MFA."""
        if not self.redis_client:
            return await self._is_locked_out_memory(user_id)
        
        try:
            lockout_key = await self._get_redis_key(user_id)
            lockout_data = await self.redis_client.get(lockout_key)
            
            if not lockout_data:
                return False
            
            data = json.loads(lockout_data)
            locked_until = datetime.fromisoformat(data["locked_until"])
            
            if datetime.now(timezone.utc) < locked_until:
                return True
            else:
                # Lockout expired, clean up
                await self.redis_client.delete(lockout_key)
                await self.redis_client.delete(await self._get_attempts_key(user_id))
                return False
                
        except Exception as e:
            logging.error(f"Redis error checking lockout: {e}")
            # Fall back to memory storage on Redis failure
            return await self._is_locked_out_memory(user_id)
    
    async def record_failure(self, db_session, user_id: str):
        """Records a failed attempt with exponential backoff."""
        if not self.redis_client:
            return await self._record_failure_memory(user_id)
        
        try:
            attempts_key = await self._get_attempts_key(user_id)
            lockout_key = await self._get_redis_key(user_id)
            
            # Use Redis pipeline for atomic operations
            pipe = self.redis_client.pipeline()
            
            # Increment attempt counter with expiration
            pipe.incr(attempts_key)
            pipe.expire(attempts_key, 3600)  # 1 hour window
            
            results = await pipe.execute()
            current_attempts = int(results[0])
            
            if current_attempts >= self.max_attempts:
                # Calculate exponential backoff
                lockout_duration = min(
                    self.base_lockout_minutes * (2 ** (current_attempts - self.max_attempts)),
                    self.max_lockout_minutes
                )
                
                locked_until = datetime.now(timezone.utc) + timedelta(minutes=lockout_duration)
                
                lockout_data = {
                    "locked_until": locked_until.isoformat(),
                    "attempts": current_attempts,
                    "lockout_duration_minutes": lockout_duration
                }
                
                # Set lockout with expiration
                await self.redis_client.setex(
                    lockout_key,
                    lockout_duration * 60,  # Convert to seconds
                    json.dumps(lockout_data)
                )
                
        except Exception as e:
            logging.error(f"Redis error recording failure: {e}")
            # Fall back to memory storage on Redis failure
            await self._record_failure_memory(user_id)
    
    async def reset_failures(self, db_session, user_id: str):
        """Resets failures on a successful MFA verification."""
        if not self.redis_client:
            return self._reset_failures_memory(user_id)
        
        try:
            attempts_key = await self._get_attempts_key(user_id)
            lockout_key = await self._get_redis_key(user_id)
            
            # Delete both attempt counter and lockout
            pipe = self.redis_client.pipeline()
            pipe.delete(attempts_key)
            pipe.delete(lockout_key)
            await pipe.execute()
            
        except Exception as e:
            logging.error(f"Redis error resetting failures: {e}")
            # Fall back to memory storage on Redis failure
            self._reset_failures_memory(user_id)
    
    async def get_lockout_info(self, user_id: str) -> Optional[Dict]:
        """Returns lockout information for display to users."""
        if not self.redis_client:
            return self._get_lockout_info_memory(user_id)
        
        try:
            lockout_key = await self._get_redis_key(user_id)
            lockout_data = await self.redis_client.get(lockout_key)
            
            if not lockout_data:
                return None
            
            data = json.loads(lockout_data)
            locked_until = datetime.fromisoformat(data["locked_until"])
            remaining_seconds = int((locked_until - datetime.now(timezone.utc)).total_seconds())
            
            return {
                "locked_until": locked_until.isoformat(),
                "remaining_seconds": remaining_seconds,
                "attempts": data["attempts"],
                "lockout_duration_minutes": data["lockout_duration_minutes"]
            }
            
        except Exception as e:
            logging.error(f"Redis error getting lockout info: {e}")
            return self._get_lockout_info_memory(user_id)
    
    # Fallback in-memory methods for when Redis is not available
    async def _is_locked_out_memory(self, user_id: str) -> bool:
        user_str = str(user_id)
        if user_str not in self._memory_store:
            return False
            
        record = self._memory_store[user_str]
        
        if record.get("locked_until"):
            if datetime.now(timezone.utc) < record["locked_until"]:
                return True
            else:
                del self._memory_store[user_str]
                return False
                
        return False
    
    async def _record_failure_memory(self, user_id: str):
        user_str = str(user_id)
        if user_str not in self._memory_store:
            self._memory_store[user_str] = {"attempts": 0, "locked_until": None}
            
        record = self._memory_store[user_str]
        record["attempts"] += 1
        
        if record["attempts"] >= self.max_attempts:
            lockout_duration = min(
                self.base_lockout_minutes * (2 ** (record["attempts"] - self.max_attempts)),
                self.max_lockout_minutes
            )
            record["locked_until"] = datetime.now(timezone.utc) + timedelta(minutes=lockout_duration)
    
    def _reset_failures_memory(self, user_id: str):
        user_str = str(user_id)
        if user_str in self._memory_store:
            del self._memory_store[user_str]
    
    def _get_lockout_info_memory(self, user_id: str) -> Optional[Dict]:
        user_str = str(user_id)
        if user_str not in self._memory_store:
            return None
            
        record = self._memory_store[user_str]
        if not record.get("locked_until"):
            return None
            
        locked_until = record["locked_until"]
        if datetime.now(timezone.utc) >= locked_until:
            del self._memory_store[user_str]
            return None
            
        remaining_seconds = int((locked_until - datetime.now(timezone.utc)).total_seconds())
        
        return {
            "locked_until": locked_until.isoformat(),
            "remaining_seconds": remaining_seconds,
            "attempts": record["attempts"],
            "lockout_duration_minutes": (remaining_seconds // 60) + 1
        }
    
    async def cleanup_expired_entries(self):
        """Cleans up expired lockout entries (maintenance task)."""
        if not self.redis_client:
            # Redis handles TTL automatically
            return
        
        # For in-memory fallback, clean up expired entries
        current_time = datetime.now(timezone.utc)
        expired_keys = []
        
        for user_id, record in self._memory_store.items():
            if record.get("locked_until") and current_time >= record["locked_until"]:
                expired_keys.append(user_id)
        
        for key in expired_keys:
            del self._memory_store[key]
