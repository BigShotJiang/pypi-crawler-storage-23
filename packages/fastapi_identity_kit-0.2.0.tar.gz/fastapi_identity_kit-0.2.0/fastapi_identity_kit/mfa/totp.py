import pyotp
import base64
from typing import Tuple, Optional
from cryptography.fernet import Fernet
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from .models import MFAConfiguration
from .redis_lockout import RedisLockoutService

class TOTPService:
    """
    Handles TOTP (RFC 6238) secret generation, provisioning URIs, and code verification.
    Secrets are encrypted at rest.
    """
    
    def __init__(self, encryption_key: bytes, issuer_name: str = "IdentityKit"):
        """
        encryption_key: A url-safe base64-encoded 32-byte key for Fernet.
        """
        self.fernet = Fernet(encryption_key)
        self.issuer_name = issuer_name

    def encrypt_secret(self, raw_secret: str) -> str:
        return self.fernet.encrypt(raw_secret.encode('utf-8')).decode('utf-8')

    def decrypt_secret(self, encrypted_secret: str) -> str:
        return self.fernet.decrypt(encrypted_secret.encode('utf-8')).decode('utf-8')

    async def generate_secret(self, db_session: AsyncSession, user_id: str, email: str) -> Tuple[str, str]:
        """
        Generates a new Base32 secret and provisioning URI. 
        Stores it disabled until verified.
        """
        raw_secret = pyotp.random_base32()
        encrypted = self.encrypt_secret(raw_secret)
        
        # Upsert MFA config
        result = await db_session.execute(select(MFAConfiguration).where(MFAConfiguration.user_id == user_id))
        config = result.scalars().first()
        
        if config:
            config.encrypted_secret = encrypted
            config.is_enabled = False # Will be true once verified
        else:
            config = MFAConfiguration(
                user_id=user_id,
                encrypted_secret=encrypted,
                is_enabled=False
            )
            db_session.add(config)
            
        await db_session.commit()
        
        provision_uri = pyotp.totp.TOTP(raw_secret).provisioning_uri(
            name=email,
            issuer_name=self.issuer_name
        )
        
        return raw_secret, provision_uri

    async def verify_and_enable(self, db_session: AsyncSession, user_id: str, code: str) -> bool:
        """Verifies the code, and if valid, permanently enables MFA for the user."""
        is_valid = await self.verify_code(db_session, user_id, code)
        
        if is_valid:
            result = await db_session.execute(select(MFAConfiguration).where(MFAConfiguration.user_id == user_id))
            config = result.scalars().first()
            if config:
                config.is_enabled = True
                await db_session.commit()
                return True
                
        return False

    async def verify_code(self, db_session: AsyncSession, user_id: str, code: str, lockout_service: Optional[RedisLockoutService] = None) -> bool:
        """
        Verifies a 6-digit TOTP code.
        Integrates with the LockoutService to prevent brute force attacks.
        """
        if lockout_service and await lockout_service.is_locked_out(db_session, user_id):
            raise ValueError("MFA temporarily locked due to too many failed attempts.")
            
        result = await db_session.execute(select(MFAConfiguration).where(MFAConfiguration.user_id == user_id))
        config = result.scalars().first()
        
        if not config or not config.encrypted_secret:
            raise ValueError("MFA is not configured for this user.")
            
        raw_secret = self.decrypt_secret(config.encrypted_secret)
        totp = pyotp.TOTP(raw_secret)
        
        # Verify with reduced window for security (was 1, now 0)
        # This prevents replay attacks within the 30-second window
        is_valid = totp.verify(code, valid_window=0)
        
        if lockout_service:
            if not is_valid:
                await lockout_service.record_failure(db_session, user_id)
            else:
                await lockout_service.reset_failures(db_session, user_id)
                
        return is_valid
