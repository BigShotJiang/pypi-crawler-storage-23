import secrets
import string
from typing import List
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from .models import BackupCode
from fastapi_identity_kit.shared_security import hash_token

class BackupCodeService:
    """
    Generates and consumes single-use backup codes.
    Backup codes are stored completely hashed to mitigate DB leaks.
    """
    
    @staticmethod
    def _generate_random_code(length: int = 10) -> str:
        alphabet = string.ascii_uppercase + string.digits
        return ''.join(secrets.choice(alphabet) for _ in range(length))

    @staticmethod
    async def generate_codes(db_session: AsyncSession, user_id: str, count: int = 10) -> List[str]:
        """
        Generates new backup codes, deletes any existing unused ones, and returns the raw plain codes.
        (Only returns them once!)
        """
        # Purge existing unused codes to prevent buildup/leaks
        result = await db_session.execute(select(BackupCode).where(BackupCode.user_id == user_id, BackupCode.is_used == False))
        for old_code in result.scalars().all():
            await db_session.delete(old_code)
            
        raw_codes = []
        for _ in range(count):
            raw = BackupCodeService._generate_random_code()
            hashed = hash_token(raw)
            raw_codes.append(raw)
            
            new_code = BackupCode(user_id=user_id, code_hash=hashed)
            db_session.add(new_code)
            
        await db_session.commit()
        return raw_codes

    @staticmethod
    async def consume_code(db_session: AsyncSession, user_id: str, raw_code: str) -> bool:
        """
        Validates and burns a backup code.
        """
        hashed = hash_token(raw_code.upper())
        
        result = await db_session.execute(
            select(BackupCode).where(
                BackupCode.user_id == user_id,
                BackupCode.code_hash == hashed,
                BackupCode.is_used == False
            )
        )
        
        code_record = result.scalars().first()
        if code_record:
            code_record.is_used = True
            code_record.used_at = datetime.now(timezone.utc)
            await db_session.commit()
            return True
            
        return False
