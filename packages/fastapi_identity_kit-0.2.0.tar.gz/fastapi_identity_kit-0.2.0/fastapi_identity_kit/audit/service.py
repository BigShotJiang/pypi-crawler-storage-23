import json
import hashlib
import uuid
from typing import Optional, Any, Dict
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import desc

from .models import AuditEvent
from .logger import get_audit_logger

class AuditService:
    """
    Manages persistence of secure audit logs with rudimentary 
    cryptographic chaining for tamper-resistance.
    """
    
    def __init__(self):
        self.logger = get_audit_logger()
        self._last_signature_cache: Optional[str] = None

    async def _get_last_signature(self, db_session: AsyncSession) -> str:
        """Retrieves the cryptographic signature of the most recent audit row."""
        if self._last_signature_cache:
            return self._last_signature_cache
            
        result = await db_session.execute(
            select(AuditEvent.signature)
            .order_by(desc(AuditEvent.timestamp), desc(AuditEvent.id))
            .limit(1)
        )
        last_sig = result.scalar()
        
        # Genesis signature if table is completely empty
        return last_sig if last_sig else "GENESIS"

    def _compute_signature(self, previous_signature: str, payload_data: Dict[str, Any]) -> str:
        """
        Hashes the previous row's signature against the new payload 
        creating an unbreakable chain. Modifications to historic rows 
        will invalidate all subsequent signatures.
        """
        payload_str = json.dumps(payload_data, sort_keys=True)
        raw = f"{previous_signature}|{payload_str}"
        return hashlib.sha256(raw.encode()).hexdigest()

    async def log_event(
        self,
        db_session: AsyncSession,
        category: str,
        action: str,
        actor_id: Optional[uuid.UUID] = None,
        target_id: Optional[str] = None,
        ip_address: Optional[str] = None,
        payload: Optional[Dict[str, Any]] = None
    ) -> AuditEvent:
        """
        Creates an immutable record in the database, and concurrently 
        emits a structured JSON log to stdout for the SIEM.
        """
        # Ensure payload is at least an empty dict for hashing consistency
        safe_payload = payload or {}
        
        # 1. Cryptographic Chaining
        prev_sig = await self._get_last_signature(db_session)
        new_sig = self._compute_signature(prev_sig, safe_payload)
        self._last_signature_cache = new_sig # Overwrite cache
        
        # 2. Db Persistence
        event = AuditEvent(
            event_category=category,
            event_action=action,
            actor_id=actor_id,
            target_id=target_id,
            ip_address=ip_address,
            payload=safe_payload,
            signature=new_sig
        )
        
        db_session.add(event)
        # Assuming caller manages commit, or we can explicit commit here depending on strictness
        
        # 3. SIEM Emission
        audit_context = {
            "audit_event": {
                "category": category,
                "action": action,
                "actor_id": str(actor_id) if actor_id else None,
                "target_id": target_id,
                "ip_address": ip_address,
                "payload": safe_payload,
                "signature": new_sig
            }
        }
        
        # Emit as INFO level with standard messaging but full payload injected to format
        self.logger.info(f"Audit: [{category}] {action}", extra={"audit_context": audit_context})
        
        return event

# Global Singleton for simplicity (though Dependency Injection is better in FASTAPI)
audit_engine = AuditService()
