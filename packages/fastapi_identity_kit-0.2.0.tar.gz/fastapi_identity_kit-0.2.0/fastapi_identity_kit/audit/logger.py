import logging
import json
from datetime import datetime, timezone
from typing import Any, Dict

class SIEMJsonFormatter(logging.Formatter):
    """
    Formats Python logging records into structured JSON suitable for SIEM platforms
    (Splunk, ELK, Datadog).
    """
    
    def format(self, record: logging.LogRecord) -> str:
        log_obj: Dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage()
        }
        
        # Merge extra contextual attributes passed via `extra={...}` dictionary
        if hasattr(record, 'audit_context'):
            log_obj.update(record.audit_context) # type: ignore
            
        return json.dumps(log_obj)

def get_audit_logger(name: str = "identity_audit") -> logging.Logger:
    """
    Retrieves the configured logger outputting strict JSON to console.
    In production, this could also be appended to a file handler or network socket.
    """
    logger = logging.getLogger(name)
    
    # Prevent duplicate handlers if called multiple times in a lifecycle
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = SIEMJsonFormatter()
        handler.setFormatter(formatter)
        
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        
        # Do not propagate up to root logger, ensuring independent JSON formatting
        logger.propagate = False
        
    return logger
