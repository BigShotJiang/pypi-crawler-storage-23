import uuid
from typing import Optional, Any
from datetime import datetime, timezone
from sqlalchemy import String, DateTime, JSON, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func
from fastapi_identity_kit.identity_core.models import Base, User

class AuditEvent(Base):
    """
    Immutable representation of a security or administrative action.
    Fields align with SIEM standards (actor, action, target, context).
    """
    __tablename__ = "audit_events"

    # Core Identifiers
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), index=True)
    
    # Classification
    event_category: Mapped[str] = mapped_column(String(50), nullable=False, index=True) # e.g. 'AUTH', 'ADMIN', 'TOKEN', 'POLICY'
    event_action: Mapped[str] = mapped_column(String(100), nullable=False, index=True) # e.g. 'LOGIN_SUCCESS', 'ROLE_GRANTED'
    
    # Context
    actor_id: Mapped[Optional[uuid.UUID]] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    target_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True, index=True) # Can be a User ID, Role ID, Resource ID
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    
    # Flexible Payload Data
    payload: Mapped[Optional[dict[str, Any]]] = mapped_column(JSON, nullable=True)
    
    # Tamper-Resistance Checksum (Hash of previous signature + current payload string)
    signature: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    actor: Mapped[Optional["User"]] = relationship("User")
