# Multi-Factor Authentication (MFA) Standards

The Identity System requires robust Multi-Factor Authentication (MFA), prioritizing secure hardware-backed and phishing-resistant methodologies.

## WebAuthn Overview
We prioritize **WebAuthn (FIDO2)** for phishing-resistant MFA. This is the primary and recommended second factor.
- Hardware security keys (e.g., YubiKeys).
- Platform authenticators (Windows Hello, Apple Touch/Face ID, Android Biometrics).

## Enrollment and Device Management
- Users can enroll multiple authenticators to avoid lockout.
- Each registered credential MUST have a unique physical mapping, protecting against credential duplication.
- Re-authentication or an existing strong session is required before enrolling or modifying MFA devices.

## Authenticator Assurance Levels (AAL)
The system satisfies NIST Authenticator Assurance Level 2 (AAL2) broadly and provides capabilities for **AAL3** where cryptographic hardware (security keys) is strictly mandated by the relying party.

## Fallback / Legacy Mechanisms
- **TOTP:** Time-based One-Time Passwords (RFC 6238) using authenticator apps. Allowed as a fallback but not considered phishing-resistant.
- **Recovery Codes:** Cryptographically secure, single-use generated backup codes.
- SMS/Email OTP are highly discouraged and disabled by default due to vulnerability to SIM swapping and interception.
