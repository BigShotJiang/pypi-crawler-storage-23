# Threat Model for Identity Providers

Analyzing threats specific to our identity ecosystem using the STRIDE methodology.

## 1. Token Hijacking (Spoofing / Elevation of Privilege)
Tokens could be stolen from client-side storage, log files, or intercepted over the network.
*   **Mitigation:** 
    *   Strict use of short-lived Access Tokens (e.g., 5-15 mins).
    *   Secure Refresh Token Rotation with token family tracking.
    *   Future implementation of DPoP (Demonstrating Proof-of-Possession) or mTLS to bind tokens to the client.
    *   Require TLS 1.2+ exclusively for all traffic.

## 2. Replay Attacks (Spoofing)
Old requests/tokens might be intercepted and resent to impersonate a user.
*   **Mitigation:** 
    *   Strict use of `nonce` validation for OIDC ID Tokens.
    *   Validation of `jti` (JWT ID) checking for one-time tokens.

## 3. Cross-Site Request Forgery (CSRF)
Unauthorized commands transmitted from a trusted user session.
*   **Mitigation:** 
    *   Mandatory `state` parameter validation in all OAuth 2.0 authorization requests.
    *   `SameSite=Strict` or `SameSite=Lax` configuration for all session cookies.

## 4. Authorization Code Interception
Attacker intercepts the authorization code delivered to the callback URL.
*   **Mitigation:** 
    *   Strict PKCE (Proof Key for Code Exchange - RFC 7636) enforcement for all clients.

## 5. Information Disclosure (Tokens in URLs)
Leaking tokens via URL fragments or query parameters in logs and referrers.
*   **Mitigation:**
    *   Disallow OAuth Implicit Flow. Use Authorization Code flow where tokens are exchanged server-to-server.
