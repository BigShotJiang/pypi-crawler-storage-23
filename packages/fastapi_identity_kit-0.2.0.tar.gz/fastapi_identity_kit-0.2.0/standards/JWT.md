# JSON Web Token (JWT) Standards

All access tokens and ID tokens issued by the Identity Server are formatted as JSON Web Tokens.

## Core RFCs
- **RFC 7519:** JSON Web Token (JWT)
- **RFC 7515:** JSON Web Signature (JWS)
- **RFC 7517:** JSON Web Key (JWK)

## Signature Algorithms
We strictly enforce asymmetric cryptography for all token signatures:
- **Algorithms Allowed:** `RS256` or `ES256`.
- The `none` algorithm is explicitly and strictly rejected by all parsers.
- Symmetric algorithms (e.g., `HS256`) are forbidden for Access and ID Tokens to prevent secret sharing complexities.

## Key Rotation Policy
- Cryptographic keys MUST be rotated automatically every 30 to 90 days.
- Current valid public keys are published at the JWKS (JSON Web Key Set) endpoint.
- Tokens MUST be signed with a specific Key ID (`kid` header), which clients use to unambiguously select the correct public key for validation from the JWKS endpoint.

## Required Token Claims
- `iss` (Issuer) - Must strictly match the server's issuer URL.
- `aud` (Audience) - Must match the client ID or the target resource API.
- `exp` (Expiration Time) - Tokens must be short-lived (e.g., 5-15 minutes).
- `iat` (Issued At) - Timestamp of token issuance.
- `sub` (Subject) - The unique user identifier.
- `jti` (JWT ID) - Unique identifier for the token to prevent replay attacks.
