# OAuth 2.0 Standards

This document outlines the strict adherence to OAuth 2.0 standards for the Identity Server.

## Primary RFCs
*   **RFC 6749:** The OAuth 2.0 Authorization Framework
*   **RFC 7636:** Proof Key for Code Exchange by OAuth Public Clients (PKCE)
*   **RFC 6819:** OAuth 2.0 Threat Model and Security Considerations

## Supported Flows
Only the **Authorization Code Flow with PKCE (RFC 7636)** is permitted for both public and confidential clients. Implicit flow and Resource Owner Password Credentials (ROPC) are strictly forbidden to mitigate token interception and credential exposure risks.

## PKCE (Proof Key for Code Exchange)
All authorization requests MUST include a `code_challenge` and `code_challenge_method`.
*   The `code_challenge_method` MUST strictly be `S256`.
*   `plain` method is strictly disallowed.

## Redirect URI Validation Rules
Redirect URIs MUST be strict, exact string matches. 
*   No wildcards or pattern matching allowed.
*   HTTPS is strictly required for all redirect URIs (except custom scheme for mobile apps or `http://127.0.0.1` / `http://localhost` for local native development).

## Refresh Token Rotation
*   Refresh tokens MUST be rotated upon every single use.
*   When a refresh token is used, a new one is issued, and the old one is invalidated.
*   Detecting a reused refresh token MUST trigger immediate revocation of the entire token family (the current active Access Token and Refresh Token).
