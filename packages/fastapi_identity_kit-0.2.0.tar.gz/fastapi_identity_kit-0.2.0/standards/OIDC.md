# OpenID Connect Core 1.0 Standards

OpenID Connect (OIDC) is implemented as the identity layer on top of the OAuth 2.0 protocol.

## Core Setup
- **ID Tokens:** Must be issued as signed JSON Web Tokens (JWTs).
- **UserInfo Endpoint:** Required to fetch additional claims not included in the ID Token to keep the token size manageable.
- **Discovery Document:** Hosted strictly at `/.well-known/openid-configuration` to allow automatic client configuration.

## State and Nonce Validation
- **State (`state`):** Mandatory for mitigating Cross-Site Request Forgery (CSRF) attacks. It MUST be cryptographically secure and validated by the client upon callback.
- **Nonce (`nonce`):** Mandatory in the authorization request to mitigate replay attacks on the ID Token. The authorization server MUST include the exact `nonce` in the issued ID token, and the client MUST validate it.

## Subject Identifiers
The `sub` claim MUST be globally unique across the identity system, immutable, and properly formatted (typically a UUIDv4).

## Token Delivery
ID tokens are delivered securely via the back-channel (Token Endpoint) during the Authorization Code exchange, never via the front-channel (URL fragment).
