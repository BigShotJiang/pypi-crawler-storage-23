# Compliance and Standards Alignment

Our identity system aligns strictly with federal and industry standards to guarantee enterprise readiness.

## NIST SP 800-63B Guidelines
The architecture adheres to the **NIST Special Publication 800-63B: Digital Identity Guidelines - Authentication and Lifecycle Management**.

### 1. Identity Assurance Levels (IAL)
- **IAL1:** Supported by default (no rigorous identity proofing or biometric deduplication).
- **IAL2:** Architecture provides extensibility hooks to require external identity verification and document proofing providers prior to marking a user account as "verified".

### 2. Authenticator Assurance Levels (AAL)
- **AAL1:** Supported via typical password-based authentication (memorized secrets). Passwords must enforce NIST strength guidelines (length over complexity, checking against breached password lists).
- **AAL2:** Requires two different authentication factors. Supported via Password + TOTP or single-factor cryptographic devices.
- **AAL3:** Requires hardware-based cryptographic authenticators. Fully supported through WebAuthn integration with FIDO2 security keys, providing phishing resistance and cryptographic proof of authenticator binding.

### 3. Federation Assurance Levels (FAL)
- **FAL1:** Bearer assertions (standard OIDC with ID tokens).
- **FAL2/FAL3:** Achieved through OpenID Connect using signed ID tokens, strictly validated cryptographic trust via JWKS (JSON Web Key Sets), and an architecture prepared to support sender-constrained tokens (like DPoP/RFC 9449) in the future.
