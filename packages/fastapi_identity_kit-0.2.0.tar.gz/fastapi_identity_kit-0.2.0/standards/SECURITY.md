# Security & Secure Configuration Layer

This document outlines the shared security baseline for all identity core and external provider engines.

## Secure Refresh Token Management
- **Format:** Refresh tokens must be opaque (non-JWT), high-entropy randomized strings.
- **Rotation:** Strict rotation on every use.
- **Replay Detection:** If a previously used refresh token is presented, the system MUST assume a breach and immediately revoke the entire token family (the target token, the currently active tokens, and any derived access tokens).
- **Storage:** Stored primarily as hashed values in the database (similar to passwords) to mitigate database leak impacts.

## Redirect URI Safety
- Strict exact-match string validation for redirect URIs. Subdirectory matching or query parameter variability is rejected.
- No Open Redirect vulnerabilities. State and redirect validation occur before any 302 redirects.
- HTTPS is strictly required.

## API & Transport Security
- **In-Transit:** All communication MUST occur over TLS 1.2 or TLS 1.3.
- **Headers:** Strict HTTP Security Headers must be enforced (HSTS, CSP, X-Frame-Options, X-Content-Type-Options).
- **CORS:** Cross-Origin Resource Sharing must be strictly locked down to explicitly whitelisted client origins.

## Rate Limiting & Abuse Prevention
- Endpoints subject to public exposure (Token, Authorization, UserInfo, Password Reset) MUST have strict IP-based, user-based, and endpoint-specific rate limiting.
- Account lockout mechanisms triggered after consecutive failed login attempts to prevent brute-force attacks.
