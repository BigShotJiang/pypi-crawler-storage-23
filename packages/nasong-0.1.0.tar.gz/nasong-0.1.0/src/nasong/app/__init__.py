"""
The NaSong App package.

This package contains the core application entry points and components for the
NaSong Digital Audio Workstation (DAW) and live-coding environments.
"""
