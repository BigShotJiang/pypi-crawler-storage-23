from .synth import TrainableSawtoothSynth, TrainableSquareSynth, TrainableSineSynth
from .percussion import TrainableKick, TrainableSnare, TrainableHiHat
from .melodic import TrainablePlucked, TrainablePiano, TrainableBowed
from .atmospheric import TrainablePad
from .bass import TrainableBass
