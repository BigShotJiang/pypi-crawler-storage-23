"""Utilities for Cutesy."""
