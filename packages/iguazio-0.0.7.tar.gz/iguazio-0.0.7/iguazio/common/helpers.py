# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import time
import traceback
import typing
import os
import enum
import datetime

import iguazio
import iguazio.common.constants as constants
import iguazio.common.errors as errors


def create_linear_backoff(base=2, coefficient=2, stop_value=120) -> typing.Generator:
    """
    Create a generator of linear backoff.

    Args:
        base (int, optional): The starting value for the backoff. Defaults to 2.
        coefficient (int, optional): The increment for each step. Defaults to 2.
        stop_value (int, optional): The maximum value for the backoff. Defaults to 120.

    Returns:
        Generator: A generator yielding backoff intervals.
    """
    x = 0
    comparison = min if coefficient >= 0 else max

    while True:
        next_value = comparison(base + x * coefficient, stop_value)
        yield next_value
        x += 1


def retry_until_successful(
    backoff: typing.Union[int, float, typing.Generator],
    timeout: int,
    logger,
    verbose: bool,
    function,
    *args,
    **kwargs,
):
    """
    Runs function with given *args and **kwargs.

    Tries to run it until success or timeout reached.

    Args:
        backoff (Union[int, float, Generator]): Can either be a:
            1. Number (int / float) that will be used as interval.
            2. Generator of waiting intervals (support ``next()``).
        timeout (int): Pass None if timeout is not wanted, number of seconds if it is.
        logger: A logger so we can log the failures.
        verbose (bool): Whether to log the failure on each retry.
        function: Function to run.
        *args: Function args.
        **kwargs: Function kwargs.

    Returns:
        Any: Function result.

    Raises:
        Exception: If the function does not succeed within the timeout.
    """
    start_time = time.time()
    last_traceback = None
    last_exception = None
    function_name = function.__name__

    # Check if backoff is just a simple interval
    if isinstance(backoff, int) or isinstance(backoff, float):
        backoff = create_linear_backoff(base=backoff, coefficient=0)

    # If deadline was not provided or deadline not reached
    while timeout is None or time.time() < start_time + timeout:
        next_interval = next(backoff)
        try:
            results = function(*args, **kwargs)
            return results
        except errors.RetryUntilSuccessfulFatalError as exc:
            if logger is not None and verbose:
                logger.debug(
                    "Fatal error occurred while running, stop retrying",
                    function_name=function_name,
                    exc=exc,
                )
            # raise the exception that caused the fatal error (if exists) or the fatal error itself
            raise exc.caused_by_exc or exc

        except Exception as exc:
            if logger is not None and verbose:
                log_kwargs = {
                    "next_try_in": next_interval,
                    "function_name": function_name,
                }
                if isinstance(exc, errors.RetryUntilSuccessfulInProgressErrorMessage):
                    log_kwargs.update(exc.variables)

                logger.debug(
                    # sometimes the exception do not have a message, return the class name instead
                    str(exc) or repr(exc),
                    **log_kwargs,
                )

            last_exception = exc
            last_traceback = traceback.format_exc()

            # If next interval is within allowed time period - wait on interval, abort otherwise
            if timeout is None or time.time() + next_interval < start_time + timeout:
                time.sleep(next_interval)
            else:
                break

    if logger is not None:
        logger.warn(
            "Operation did not complete on time",
            function_name=function_name,
            timeout=timeout,
            exc=str(last_exception),
            tb=last_traceback,
        )

    raise errors.RetryTimeoutError(
        f"failed to execute command by the given deadline."
        f" last_exception: {last_exception},"
        f" function_name: {function.__name__},"
        f" timeout: {timeout}"
    ) from last_exception


def get_endpoint(endpoint, default_scheme=constants._Defaults.protocol_scheme.value):
    """
    Get the endpoint scheme and host.

    Args:
        endpoint (str): The endpoint to process.
        default_scheme (str, optional): The default scheme to use if not present.

    Returns:
        str: The processed endpoint with scheme and without trailing slash.
    """
    if not endpoint.startswith("http://") and not endpoint.startswith("https://"):
        endpoint = f"{default_scheme}://{endpoint}"

    return endpoint.rstrip("/")


def get_base_sdk_path():
    """
    Get the base SDK path.

    Returns:
        str: The absolute path to the iguazio package.
    """
    # from current path, get the parent until the iguazio folder and return the full path
    return os.path.dirname(os.path.abspath(iguazio.__file__))


def is_list_type(field_type: type) -> bool:
    """
    Check if the field type is a list or a typing.List.

    Args:
        field_type (type): The type to check.

    Returns:
        bool: True if the field type is a list or a typing.List, False otherwise.
    """
    list_types = [list, typing.List]
    return (
        (field_type in list_types)
        or hasattr(field_type, "__origin__")
        and field_type.__origin__ in list_types
    )


def is_dict_type(field_type: type) -> bool:
    """
    Check if the field type is a dict or a typing.Dict.

    Args:
        field_type (type): The type to check.

    Returns:
        bool: True if the field type is a dict or a typing.Dict, False otherwise.
    """
    dict_types = [dict, typing.Dict]
    return (
        (field_type in dict_types)
        or hasattr(field_type, "__origin__")
        and field_type.__origin__ in dict_types
    )


def is_enum_type(field_type: type) -> bool:
    """
    Check if the field type is an enum.

    Args:
        field_type (type): The type to check.

    Returns:
        bool: True if the field type is an enum, False otherwise.
    """
    return isinstance(field_type, type) and issubclass(field_type, enum.Enum)


def is_datetime_type(field_type: type) -> bool:
    """
    Check if the field type is datetime or a Union that includes datetime (Optional types are Unions with None).

    Args:
        field_type (type): The type to check.

    Returns:
        bool: True if the field type is datetime or a Union that includes datetime, False otherwise.
    """
    return field_type is datetime.datetime or (
        hasattr(field_type, "__origin__")
        and field_type.__origin__ is typing.Union
        and datetime.datetime in field_type.__args__
    )


def get_list_type_arg(field_type: type) -> typing.Optional[type]:
    """
    Get the type argument of a list type field.

    Args:
        field_type (type): The type to check.

    Returns:
        typing.Optional[type]: The type argument if the field type is a list or a typing.List, otherwise None.
    """
    field_type = _unwrap_optional_type(field_type)
    if (
        not is_list_type(field_type)
        or not hasattr(field_type, "__args__")
        or not field_type.__args__
    ):
        return None
    return field_type.__args__[0]


def get_dict_type_args(field_type: type) -> list[type]:
    """
    Get the type arguments of a dict type field.

    Args:
        field_type (type): The type to check.

    Returns:
        list[type]: A list of type arguments if the field type is a dict or a typing.Dict, otherwise an empty list.
    """
    field_type = _unwrap_optional_type(field_type)
    if (
        not is_dict_type(field_type)
        or not hasattr(field_type, "__args__")
        or len(field_type.__args__) < 2
    ):
        return []
    return field_type.__args__


def _unwrap_optional_type(field_type: type) -> type:
    """
    Unwrap Optional/Union types first
    If the field type is a Union, return the non-None type.
    If the field type is an Optional, return the type.
    Args:
        field_type (type): The type to unwrap.

    Returns:
        type: The unwrapped type.
    """
    # Unwrap Optional/Union types first
    if hasattr(field_type, "__origin__") and field_type.__origin__ is typing.Union:
        # Filter out NoneType from Union args to handle Optional
        non_none_types = [t for t in field_type.__args__ if t is not type(None)]
        # If there's exactly one non-None type, use it
        if len(non_none_types) == 1:
            field_type = non_none_types[0]
    return field_type
