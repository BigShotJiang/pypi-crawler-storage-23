# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import enum


class _Serialization:
    primitive_types = (int, float, bool, bytes, str, type(None))
    native_types = (int, float, bool, bytes, str, type(None), list, dict)


class _RequestHeaders(enum.StrEnum):
    # Header names
    content_type_header = "Content-Type"
    authorization_header = "Authorization"

    # Header values
    application_json_content = "application/json"

    @classmethod
    def all(cls):
        return [member for member in cls]

    @classmethod
    def default_headers(cls):
        return {
            cls.content_type_header: cls.application_json_content,
        }


class _EnvVars(enum.StrEnum):
    """
    Environment variables used for SDK configuration.
    """

    service_account_token_file = "IGUAZIO_SERVICE_ACCOUNT_TOKEN_FILE"


class _ErrorCodes(enum.StrEnum):
    pass


class _Defaults(enum.Enum):
    request_timeout: int = 60
    retries: int = 3
    log_level: str = "INFO"
    protocol_scheme: str = "https"

    # login flow
    local_auth_server_port: int = 8085
    local_auth_server_timeout: int = 3 * 60  # 3 minutes

    default_token_name: str = "default"
    default_token_file_path: str = "~/.igz.yml"
    default_service_account_token_file_path: str = (
        "/var/run/secrets/kubernetes.io/serviceaccount/token"
    )

    default_page_size: int = 10
