# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import enum
import typing

import iguazio.common.constants as constants
import iguazio.schemas.base.igz_schema as igz_schema


@igz_schema.igz_dataclass
class BaseMetadata(igz_schema.IGZSchema):
    """
    Metadata for Iguazio resources.
    This class extends IGZSchema and can be used to define common metadata attributes.

    Args:
        id (str): Unique identifier for the resource.
        resource_type (str, optional): Optional type of the resource, if applicable.
    """

    id: typing.Optional[str] = None
    resource_type: typing.Optional[str] = None


@igz_schema.igz_dataclass
class BaseSpec(igz_schema.IGZSchema):
    """
    Specification for Iguazio resources.

    This class extends IGZSchema and can be used to define common specification attributes.
    """

    pass


@igz_schema.igz_dataclass
class BaseStatus(igz_schema.IGZSchema):
    """
    Status for Iguazio resources.

    Args:
        ctx (str, optional): Context for the status, if applicable.
        status_code (int, optional): Status code for the operation, if applicable.
        error_message (str, optional): Error message if the operation failed.
        stack_trace (str, optional): Stack trace for debugging, if applicable.
        redirect_uri (str, optional): URI to redirect to, if applicable.
    """

    ctx: typing.Optional[str] = None
    status_code: typing.Optional[int] = None
    error_message: typing.Optional[str] = None
    stack_trace: typing.Optional[str] = None
    redirect_uri: typing.Optional[str] = None


class OrderByDirection(enum.Enum):
    """Order by direction for list operations (ORDER BY clause)."""

    UNSPECIFIED = "unspecified"
    ASC = "asc"
    DESC = "desc"


@igz_schema.igz_dataclass
class OrderBySpec(igz_schema.IGZSchema):
    """
    Specifies a single order by field and direction for list operations.

    Args:
        field (str): Field to order by (resource-specific, e.g., "created_at", "name").
        direction (OrderByDirection, optional): Order by direction. Defaults to OrderByDirection.DESC.
    """

    field: str = ""
    direction: OrderByDirection = OrderByDirection.DESC


@igz_schema.igz_dataclass
class BaseListStatus(BaseStatus):
    """
    Status for a list of Iguazio resources.

    Args:
        total (int): Total number of items in the list.
        ctx (str, optional): Context for the status, if applicable.
        status_code (int, optional): Status code for the operation, if applicable.
        error_message (str, optional): Error message if the operation failed.
        stack_trace (str, optional): Stack trace for debugging, if applicable.
        redirect_uri (str, optional): URI to redirect to, if applicable.
    """

    total: int = 0


@igz_schema.igz_dataclass
class PaginationRequest(igz_schema.IGZSchema):
    """
    Pagination request parameters for Iguazio APIs.

    Args:
        offset (int, optional): The starting point for the pagination, default is 0.
        limit (int, optional): The maximum number of items to return, default is 10.
    """

    offset: int = 0
    limit: int = constants._Defaults.default_page_size.value
