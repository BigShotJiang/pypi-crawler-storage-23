# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import dataclasses
import enum
import typing

import iguazio.schemas.base.igz_schema as igz_schema
import iguazio.schemas.v1.common.base as base


class MemberKind(enum.StrEnum):
    """
    Enum representing the kinds of members in Iguazio.
    """

    USER = "user"
    GROUP = "group"


@igz_schema.igz_dataclass
class Member(igz_schema.IGZSchema):
    """
    Represents a member (user or group) in Iguazio.
    This class extends IGZSchema and can be used to define member-specific attributes.

    Args:
        id (str): Unique identifier for the member.
        kind (MemberKind): Kind of the member (e.g., "user", "group").
    """

    id: str
    kind: MemberKind


@igz_schema.igz_dataclass
class PolicyMetadata(base.BaseMetadata):
    """
    Metadata for a policy in Iguazio.
    This class extends BaseMetadata and can be used to define policy-specific metadata attributes.

    Args:
        name (str): Name of the policy.
        id (str): Unique identifier for the resource.
        resource_type (str, optional): Optional type of the resource, if applicable.
    """

    name: str


@igz_schema.igz_dataclass
class PolicyActions(igz_schema.IGZSchema):
    """
    Actions that can be performed by a policy in Iguazio.
    This class is used to define a list of actions that a policy can allow on a specific resource.

    Args:
        actions (list[str]): List of actions that the policy allows.
    """

    actions: list[str] = dataclasses.field(default_factory=list)


@igz_schema.igz_dataclass
class PolicySpec(base.BaseSpec):
    """
    Specification for a policy in Iguazio.
    This class extends BaseSpec and can be used to define policy-specific specification attributes.

    Args:
        kind (str): Kind of the policy (e.g., "project", "system").
        display_name (str): Display name of the policy.
        project_name (str, optional): Name of the project to which the policy applies.
        permissions (dict[str, PolicyActions]): Dictionary mapping resource paths to PolicyActions.
        system_generated (bool, optional): Indicates if the policy is system-generated.
        version (int): Version of the policy.
    """

    kind: str
    display_name: str
    project_name: typing.Optional[str] = None
    permissions: dict[str, PolicyActions] = dataclasses.field(default_factory=dict)
    system_generated: typing.Optional[bool] = None
    version: int


@igz_schema.igz_dataclass
class PolicyStatus(base.BaseStatus):
    """
    Status for a policy in Iguazio.
    This class extends BaseStatus and can be used to define policy-specific status attributes.

    Args:
        assigned_members (list[Member], optional): List of member IDs (usernames or group IDs) assigned to the policy.
        ctx (str, optional): Context for the status, if applicable.
        status_code (int, optional): Status code for the operation, if applicable.
        error_message (str, optional): Error message if the operation failed.
        stack_trace (str, optional): Stack trace for debugging, if applicable.
        redirect_uri (str, optional): URI to redirect to, if applicable.
    """

    assigned_members: typing.Optional[list[Member]] = None


@igz_schema.igz_dataclass
class Policy(igz_schema.IGZSchema):
    """
    Policy represents a policy in Iguazio.
    This class extends IGZSchema and can be used to define policy-specific attributes.

    Args:
        metadata (PolicyMetadata): Metadata for the policy, including name and ID.
        spec (PolicySpec): Specification for the policy, including kind, display name, project name, permissions,
            system generation flag, and version.
        status (PolicyStatus): Status for the policy, including assigned users and groups.
        relationships (list[IGZSchema], optional): Optional list of relationships associated with the policy, if applicable.
    """

    metadata: PolicyMetadata = dataclasses.field(default_factory=PolicyMetadata)
    spec: PolicySpec = dataclasses.field(default_factory=PolicySpec)
    status: PolicyStatus = dataclasses.field(default_factory=PolicyStatus)
    relationships: typing.Optional[list[igz_schema.IGZSchema]] = None


@igz_schema.igz_dataclass
class PolicyListStatus(base.BaseListStatus):
    """
    Status for a list of policies in Iguazio.

    This class extends BaseListStatus and can be used to define policy-specific list status attributes.
    """

    pass


@igz_schema.igz_dataclass
class PolicyList(igz_schema.IGZSchema):
    """
    PolicyList represents a list of policies in Iguazio.

    This class extends IGZSchema and can be used to define policy-specific attributes.
    """

    items: list[Policy] = dataclasses.field(default_factory=list)
    status: PolicyListStatus = dataclasses.field(default_factory=PolicyListStatus)
    relationships: typing.Optional[list[igz_schema.IGZSchema]] = None


class PolicyListFormat(enum.Enum):
    """
    Enum representing the format options for policy lists.

    Attributes:
        minimal: Minimal format, returns basic policy information (default).
        full: Full format, returns complete policy information including detailed metadata.
    """

    minimal = 0
    full = 1


@igz_schema.igz_dataclass
class GetPolicyOptions(igz_schema.IGZSchema):
    """
    Options for retrieving a policy in Iguazio.
    This class extends IGZSchema and can be used to define options specific to policy retrieval.

    Args:
        include_members (bool, optional): Whether to include member information (assigned users and groups) in the response. Defaults to False.
    """

    include_members: bool = False


@igz_schema.igz_dataclass
class ListPoliciesOptions(base.PaginationRequest):
    """
    Options for listing policies in Iguazio.
    This class extends IGZSchema and can be used to define options specific to policy listing.

    Args:
        kind (str, optional): Filter policies by kind ("project" or "mgmt"). Defaults to None.
        name (str, optional): Filter policies by name. Defaults to None.
        project (str, optional): Filter policies by project name. Defaults to None.
        version (int, optional): Filter policies by version. Defaults to None.
        display_name (str, optional): Filter policies by display name. Defaults to None.
        system_generated (bool, optional): Filter policies by system generated flag. Defaults to None.
        format (PolicyListFormat): Format for the policy list response. Defaults to minimal.
        include_members (bool): Whether to include member information (assigned users and groups) in the response. Defaults to False.
        offset (int, optional): The starting point for the pagination, default is 0.
        limit (int, optional): The maximum number of items to return, default is 10.
    """

    kind: typing.Optional[str] = None
    name: typing.Optional[str] = None
    project: typing.Optional[str] = None
    version: typing.Optional[int] = None
    display_name: typing.Optional[str] = None
    system_generated: typing.Optional[bool] = None
    format: PolicyListFormat = PolicyListFormat.minimal
    include_members: bool = False


@igz_schema.igz_dataclass
class UpdateProjectOwnerOptions(igz_schema.IGZSchema):
    """
    Options for updating the owner of a project in Iguazio.
    This class extends IGZSchema and can be used to define options specific to updating project ownership.

    Args:
        owner (str): The username of the new project owner.
    """

    owner: str


@igz_schema.igz_dataclass
class UpdatePolicyMembersOptions(igz_schema.IGZSchema):
    """
    Options for updating the members (usernames and group IDs) assigned to a policy in Iguazio.
    This class extends IGZSchema and can be used to define options specific to updating policy membership.

    Args:
        members (list[str], optional): List of members (usernames and group IDs) to assign to the policy.
    """

    members: list[str] = dataclasses.field(default_factory=list)


@igz_schema.igz_dataclass
class AssignMemberMgmtPoliciesOptions(igz_schema.IGZSchema):
    """
    Options for assigning policies to a member (user or group) in Iguazio.
    This class extends IGZSchema and can be used to define options specific to policy assignment.

    Args:
        policy_ids (list[str]): List of policy IDs to assign to the member.
        policy_names (list[str]): List of policy names to assign to the member. Names will be resolved to IDs.
        override (bool): Whether to override the existing management policy assignments for the member. Defaults to False.
    """

    policy_ids: list[str] = dataclasses.field(default_factory=list)
    policy_names: list[str] = dataclasses.field(default_factory=list)
    override: bool = False


class ProjectRole(enum.StrEnum):
    """
    Enum representing the roles that can be assigned to a project.
    """

    OWNER = "owner"
    ADMIN = "admin"
    EDITOR = "editor"
    VIEWER = "viewer"

    @classmethod
    def from_str(cls, role: str) -> typing.Optional["ProjectRole"]:
        """
        Convert a string to a ProjectRole enum.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.set_project_role_members(
                project="myproject",
                role=iguazio.schemas.ProjectRole.from_str("editor"),
                options=iguazio.schemas.SetProjectRoleMembersOptionsV1(
                    users=["user1", "user2"],
                    groups=["group-id-1", "group-id-2"],
                ),
            )

        Args:
            role (str): The string to convert to a ProjectRole enum.

        Returns:
            ProjectRole: The ProjectRole enum, if found.
            None: If the string is not a valid ProjectRole.
        """
        if not role:
            return None
        role = role.lower()
        for r in cls:
            if r.value.lower() == role:
                return r
        return None

    @classmethod
    def role_for_policy_name(cls, policy_name: str) -> typing.Optional["ProjectRole"]:
        """
        Lookup role by policy name.

        Example usage::

            role = ProjectRole.role_for_policy_name("igz-project-editor")
            if role:
                print(role.value)
            else:
                print("Role not found")

        Args:
            policy_name (str): Name of the policy

        Returns:
            ProjectRole: The role for the policy name, if found.
        """
        policy_name_map = {f"igz-project-{role.value.lower()}": role for role in cls}
        return policy_name_map.get(policy_name.lower())


@igz_schema.igz_dataclass
class SetMemberProjectRoleOptions(igz_schema.IGZSchema):
    """
    Options for setting the role of a member (user or group) in a project in Iguazio.
    This class extends IGZSchema and can be used to define options specific to member project role assignment.

    Args:
        role (ProjectRole): The role to set the member for.
        override (bool): Whether to override the existing role assignment. Defaults to False.
    """

    role: ProjectRole
    override: bool = False


@igz_schema.igz_dataclass
class ProjectRoleMembers(igz_schema.IGZSchema):
    """
    Represents the members (users and groups) assigned to a specific project role.

    Args:
        users (list[str]): List of user IDs (usernames).
        groups (list[str]): List of group IDs.
    """

    users: list[str] = dataclasses.field(default_factory=list)
    groups: list[str] = dataclasses.field(default_factory=list)


@igz_schema.igz_dataclass
class ProjectMembership(igz_schema.IGZSchema):
    """
    Represents the membership of a project, organized by role.

    Args:
        owner (ProjectRoleMembers): Members with the owner role.
        admin (ProjectRoleMembers): Members with the admin role.
        editor (ProjectRoleMembers): Members with the editor role.
        viewer (ProjectRoleMembers): Members with the viewer role.
    """

    owner: ProjectRoleMembers = dataclasses.field(default_factory=ProjectRoleMembers)
    admin: ProjectRoleMembers = dataclasses.field(default_factory=ProjectRoleMembers)
    editor: ProjectRoleMembers = dataclasses.field(default_factory=ProjectRoleMembers)
    viewer: ProjectRoleMembers = dataclasses.field(default_factory=ProjectRoleMembers)

    # Implement len to return the number of roles with members
    def __len__(self) -> int:
        return sum(
            1
            for field in dataclasses.fields(self)
            if getattr(self, field.name).users or getattr(self, field.name).groups
        )


@igz_schema.igz_dataclass
class SetProjectMembershipOptions(igz_schema.IGZSchema):
    """
    Options for assigning users and groups to a project in Iguazio.
    This class extends IGZSchema and can be used to define options specific to project membership.

    Args:
        membership (dict[ProjectRole, list[str]]): The membership configuration for the project, mapping roles to lists of members (usernames and group IDs).
        override (bool): Whether to override existing members for all roles.
            When set to true, if a role isn't provided or its members are empty, the all assignments for this role will be removed from the project. Defaults to False.
    """

    membership: dict[ProjectRole, list[str]] = dataclasses.field(default_factory=dict)
    override: bool = False

    def to_dict(self) -> dict:
        result = super().to_dict()
        membership_dict = {}
        if self.membership:
            for role, members in self.membership.items():
                if members:
                    membership_dict[role.value] = {"values": members}
        result["membership"] = membership_dict
        return result


@igz_schema.igz_dataclass
class SetProjectRoleMembersOptions(igz_schema.IGZSchema):
    """
    Options for setting the members of a project for a specific role.
    This class extends IGZSchema and can be used to define options specific to setting the members of a project for a specific role.

    Args:
        members (list[str]): The list of members (usernames and group IDs) to set for the role.
        override (bool): Whether to override the existing members for the role. Defaults to False.
    """

    members: list[str] = dataclasses.field(default_factory=list)
    override: bool = False


@igz_schema.igz_dataclass
class ValidatePermissionsOptions(igz_schema.IGZSchema):
    """
    Options for validating permissions for a set of actions on resources.
    This class extends IGZSchema and can be used to define options specific to validating permissions.

    Args:
        action (str): The action to validate permissions for.
        resources (list[str]): The resources to validate permissions for.
    """

    action: str
    resources: list[str] = dataclasses.field(default_factory=list)


@igz_schema.igz_dataclass
class PermissionValidationResultStatus(base.BaseStatus):
    """
    Status for a permission validation result in Iguazio.
    This class extends BaseStatus and contains the result of a permission validation.

    Args:
        allowed (bool): Whether the permission is allowed.
        reason (str, optional): The reason for the permission decision.
        ctx (str, optional): Context for the status, if applicable.
        status_code (int, optional): Status code for the operation, if applicable.
        error_message (str, optional): Error message if the operation failed.
        stack_trace (str, optional): Stack trace for debugging, if applicable.
        redirect_uri (str, optional): URI to redirect to, if applicable.
    """

    allowed: bool = False
    reason: typing.Optional[str] = None


@igz_schema.igz_dataclass
class ValidatePermissionsResult(igz_schema.IGZSchema):
    """
    Result for validating permissions in Iguazio.
    This class corresponds to the PermissionValidationResult proto message.

    Args:
        metadata (BaseMetadata): Metadata for the permission validation result.
        spec (BaseSpec): Specification for the permission validation result.
        status (PermissionValidationResultStatus): Status containing the validation result.
        relationships (list[IGZSchema], optional): Optional list of relationships associated with the result.
    """

    metadata: base.BaseMetadata = dataclasses.field(default_factory=base.BaseMetadata)
    spec: base.BaseSpec = dataclasses.field(default_factory=base.BaseSpec)
    status: PermissionValidationResultStatus = dataclasses.field(
        default_factory=PermissionValidationResultStatus
    )
    relationships: typing.Optional[list[igz_schema.IGZSchema]] = None
