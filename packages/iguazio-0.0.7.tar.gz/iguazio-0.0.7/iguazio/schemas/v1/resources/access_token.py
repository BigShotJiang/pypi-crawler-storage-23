# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import dataclasses
import typing
import enum

import iguazio.schemas.base.igz_schema as igz_schema
import iguazio.schemas.v1.common.base as base


__override_docs_title__ = "Access Token"


@igz_schema.igz_dataclass
class AccessTokenMetadata(base.BaseMetadata):
    """
    Metadata for an access token in Iguazio.

    Args:
        session_id (str): Session ID associated with the access token.
        token_type (str): Type of the token (e.g., Bearer).
        issued_token_type (str): Type of the issued token.
        scope (str): Scope of the access token.
    """

    session_id: str
    token_type: str
    issued_token_type: str
    scope: str


@igz_schema.igz_dataclass
class AccessTokenSpec(base.BaseSpec):
    """
    Specification for an access token in Iguazio.

    Args:
        access_token (str): The access token string.
        id_token (str): The ID token string.
        refresh_token (str): The refresh token string.
    """

    access_token: str
    id_token: str
    refresh_token: str


@igz_schema.igz_dataclass
class AccessTokenStatus(base.BaseStatus):
    """
    Status for an access token in Iguazio.

    Args:
        expires_in (int): Time in seconds until the access token expires.
        refresh_expires_in (int): Time in seconds until the refresh token expires.
        not_before_policy (int): Time in seconds before the token becomes valid.
    """

    # Failed refresh entries can include only status_code/error_message.
    expires_in: typing.Optional[int] = None
    refresh_expires_in: typing.Optional[int] = None
    not_before_policy: typing.Optional[int] = None
    status_code: typing.Optional[int] = None
    error_message: str = ""


@igz_schema.igz_dataclass
class AccessToken(igz_schema.IGZSchema):
    """
    An access token in Iguazio.

    Args:
        metadata (AccessTokenMetadata): Metadata for the access token, encapsulated in AccessTokenMetadata.
        spec (AccessTokenSpec): Specification for the access token, encapsulated in AccessTokenSpec.
        status (AccessTokenStatus): Status of the access token, encapsulated in AccessTokenStatus.
        relationships (list, optional): Optional relationships associated with the access token.
    """

    # Failed refresh entries may include only status without metadata/spec.
    metadata: typing.Optional[AccessTokenMetadata] = None
    spec: typing.Optional[AccessTokenSpec] = None
    status: AccessTokenStatus = dataclasses.field(default_factory=AccessTokenStatus)
    relationships: typing.Optional[list] = None


@igz_schema.igz_dataclass
class RefreshAccessTokenOptions(igz_schema.IGZSchema):
    """
    Options for refreshing an access token.

    :param refresh_token: The refresh token string.
    :type refresh_token: str
    """

    refresh_token: str


@igz_schema.igz_dataclass
class RevokeOfflineTokenOptions(igz_schema.IGZSchema):
    """
    Options for revoking an offline token.

    :param token: The offline token string to be revoked.
    :type token: str
    """

    token: str


class RefreshAccessTokensMode(enum.Enum):
    """
    Enum representing the modes for refreshing access tokens.

    :cvar unspecified: Default mode, behavior is not explicitly defined.
    :cvar fail_fast: Fail immediately if any token refresh fails.
    :cvar continue_: Continue processing other tokens even if some refresh operations fail.
    """

    unspecified = 0
    fail_fast = 1
    continue_ = 2

    _ALIASES = {"continue": "continue_"}

    @classmethod
    def from_name(cls, name: str) -> "RefreshAccessTokensMode":
        # Accept "continue" (or "continue_") and return the member
        mapped = cls._ALIASES.get(name, name)
        return cls[mapped]

    def as_external_name(self) -> str:
        # For serialization/display
        if self is self.__class__.continue_:
            return "continue"
        return self.name


@igz_schema.igz_dataclass
class RefreshAccessTokensOptions(igz_schema.IGZSchema):
    """
    Options for refreshing multiple access tokens.

    :param refresh_tokens: A list of refresh token strings.
    :type refresh_tokens: list[str]
    :param mode: The mode for refreshing tokens, determining the behavior in case of errors.
    :type mode: RefreshAccessTokensMode
    """

    refresh_tokens: list[str]
    mode: RefreshAccessTokensMode = RefreshAccessTokensMode.unspecified


@igz_schema.igz_dataclass
class AccessTokenListStatus(igz_schema.IGZSchema):
    """
    Status for an access token list.

    :param status_code: The status code indicating the result of the operation.
    :type status_code: int
    :param error_message: The error message, if any, associated with the operation.
    :type error_message: str
    """

    status_code: int = 200
    error_message: str = ""


@igz_schema.igz_dataclass
class AccessTokenList(igz_schema.IGZSchema):
    """
    A list of access tokens.

    :param items: A list of access token objects.
    :type items: list[AccessToken]
    :param status: The status of the access token list.
    :type status: AccessTokenListStatus
    """

    items: list[AccessToken]
    status: AccessTokenListStatus = dataclasses.field(
        default_factory=AccessTokenListStatus
    )
