# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import dataclasses
import enum
import typing

import iguazio.schemas.base.igz_schema as igz_schema
import iguazio.schemas.v1.common.base as base


__override_docs_title__ = "SSO Provider"


@igz_schema.igz_dataclass
class SsoProviderMetadata(base.BaseMetadata):
    """
    Metadata for an SSO Provider in Iguazio.
    This class extends BaseMetadata and can be used to define user-specific metadata attributes.

    Args:
        alias (str): Alias of the SSO provider.
        id (str): Unique identifier for the resource.
        resource_type (str, optional): Optional type of the resource, if applicable.
    """

    alias: str


@igz_schema.igz_dataclass
class SsoProviderSpec(base.BaseSpec):
    """
    Specification for an SSO Provider in Iguazio.
    This class defines the configuration required for the SSO provider.

    Args:
        display_name (str): Display name of the SSO provider.
        provider_id (str): Unique identifier for the SSO provider.
        config (dict[str, str]): Configuration dictionary for the SSO provider.
    """

    display_name: str
    provider_id: str
    config: dict[str, str]


@igz_schema.igz_dataclass
class SsoProviderStatus(base.BaseStatus):
    """
    Status for an SSO Provider in Iguazio.
    This class can be used to define the status of the SSO provider, such as whether it is enabled or disabled.

    Args:
        enabled (bool): Indicates whether the SSO provider is enabled.
        ctx (str, optional): Context for the status, if applicable.
        status_code (int, optional): Status code for the operation, if applicable.
        error_message (str, optional): Error message if the operation failed.
        stack_trace (str, optional): Stack trace for debugging, if applicable.
        redirect_uri (str, optional): URI to redirect to, if applicable.
    """

    enabled: bool = True


@igz_schema.igz_dataclass
class SsoProvider(igz_schema.IGZSchema):
    """
    Represents an SSO Provider in Iguazio.
    This class combines metadata, specification, and status for the SSO provider.

    Args:
        metadata (SsoProviderMetadata): Metadata for the SSO provider, encapsulated in SsoProviderMetadata.
        spec (SsoProviderSpec): Specification for the SSO provider, encapsulated in SsoProviderSpec.
        status (SsoProviderStatus): Status of the SSO provider, encapsulated in SsoProviderStatus.
        relationships (list[igz_schema.IGZSchema], optional): Optional relationships associated with the SSO provider.
    """

    metadata: SsoProviderMetadata = dataclasses.field(
        default_factory=SsoProviderMetadata
    )
    spec: SsoProviderSpec = dataclasses.field(default_factory=SsoProviderSpec)
    status: SsoProviderStatus = dataclasses.field(default_factory=SsoProviderStatus)
    relationships: typing.Optional[list[igz_schema.IGZSchema]] = None


@igz_schema.igz_dataclass
class SsoProviderListStatus(base.BaseListStatus):
    """
    Status for a list of SSO Providers in Iguazio.
    This class can be used to define the status of the list operation, such as whether it was successful or not.

    Args:
        total (int): Total number of items in the list.
        ctx (str, optional): Context for the status, if applicable.
        status_code (int, optional): Status code for the operation, if applicable.
        error_message (str, optional): Error message if the operation failed.
        stack_trace (str, optional): Stack trace for debugging, if applicable.
        redirect_uri (str, optional): URI to redirect to, if applicable.
    """

    pass


@igz_schema.igz_dataclass
class SsoProviderList(igz_schema.IGZSchema):
    """
    Represents a list of SSO Providers in Iguazio.
    This class combines metadata, status, and a list of SSO providers.

    Args:
        items (typing.List[SsoProvider]): List of SSO providers.
        status (SsoProviderListStatus): Status of the list operation.
        relationships (typing.Optional[list[igz_schema.IGZSchema]]): Optional relationships associated with the
            SSO providers.
    """

    items: typing.List[SsoProvider] = dataclasses.field(default_factory=list)
    status: SsoProviderListStatus = dataclasses.field(
        default_factory=SsoProviderListStatus
    )
    relationships: typing.Optional[list[igz_schema.IGZSchema]] = None


class SsoProviderIdpType(enum.Enum):
    """
    Enum for Identity Provider types.
    This enum defines the supported identity provider types for SSO providers in Iguazio.

    Attributes:
        okta (str): Okta identity provider type.
        entra (str): Microsoft Entra identity provider type.
        github (str): GitHub identity provider type.
    """

    okta = "okta"
    entra = "entra"
    github = "github"


@igz_schema.igz_dataclass
class CreateSsoProviderOptions(igz_schema.IGZSchema):
    """
    Options for creating an SSO Provider in Iguazio.
    This class can be used to specify additional options when creating an SSO provider.

    Args:
        idp_type (SsoProviderIdpType): Type of the identity provider (e.g. SsoProviderIdpType.okta).
        alias (str): Alias for the SSO provider.
        display_name (str): Display name for the SSO provider.
        client_id (str): Client ID for the SSO provider.
        client_secret (str): Client secret for the SSO provider.
        discovery_endpoint (typing.Optional[str]): Discovery URL for the SSO provider, if applicable.
        create_email_mapper (bool): Whether to create an email mapper for the SSO provider, default is True.
    """

    idp_type: SsoProviderIdpType
    alias: str
    display_name: str
    client_id: str
    client_secret: str
    discovery_endpoint: typing.Optional[str] = None
    create_email_mapper: bool = True


@igz_schema.igz_dataclass
class ListSsoProvidersOptions(base.PaginationRequest):
    """
    Options for listing SSO Providers in Iguazio.
    This class can be used to specify additional options when listing SSO providers.

    Args:
        search_term (typing.Optional[str]): Search term to filter the SSO providers by name or alias.
        offset (int): The starting point for the pagination, default is 0.
        limit (int): The maximum number of items to return, default is 10.
    """

    search_term: typing.Optional[str] = None


@igz_schema.igz_dataclass
class UpdateSsoProviderOptions(igz_schema.IGZSchema):
    """
    Options for updating an SSO Provider in Iguazio.
    This class can be used to specify additional options when updating an SSO provider.

    Args:
        display_name (typing.Optional[str]): Display name for the SSO provider.
        client_id (typing.Optional[str]): Client ID for the SSO provider.
        client_secret (typing.Optional[str]): Client secret for the SSO provider.
        discovery_endpoint (typing.Optional[str]): Discovery URL for the SSO provider, if applicable.
    """

    display_name: typing.Optional[str] = None
    client_id: typing.Optional[str] = None
    client_secret: typing.Optional[str] = None
    discovery_endpoint: typing.Optional[str] = None
