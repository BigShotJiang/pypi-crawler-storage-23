# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import dataclasses
import typing

import iguazio.schemas.base.igz_schema as igz_schema
import iguazio.schemas.v1.common.base as base


__override_docs_title__ = "Group"


@igz_schema.igz_dataclass
class GroupMetadata(base.BaseMetadata):
    """
    Metadata for a user group in Iguazio.
    This class extends BaseMetadata and can be used to define group-specific metadata attributes.

    Args:
        path (str): Path of the group in the Iguazio system.
        parent_id (str, optional): Optional ID of the parent group, if this group is a sub-group.
        sub_group_count (int, optional): Optional count of sub-groups under this group, if applicable.
        id (str): Unique identifier for the resource.
        resource_type (str, optional): Optional type of the resource, if applicable.
    """

    path: str
    parent_id: typing.Optional[str] = None
    sub_group_count: typing.Optional[int] = None


@igz_schema.igz_dataclass
class GroupSpec(base.BaseSpec):
    """
    Specification for a user group in Iguazio.
    This class extends BaseSpec and can be used to define group-specific specification attributes.

    Args:
        name (str): Name of the group.
    """

    name: str


@igz_schema.igz_dataclass
class GroupStatus(base.BaseStatus):
    """
    Status for a user group in Iguazio.
    This class extends BaseStatus and can be used to define group-specific status attributes.

    Args:
        sub_group_ids (list[str], optional): List of IDs of sub-groups under this group, if applicable.
        member_ids (list[str], optional): List of IDs of members in this group, if applicable.
        ctx (str, optional): Context for the status, if applicable.
        status_code (int, optional): Status code for the operation, if applicable.
        error_message (str, optional): Error message if the operation failed.
        stack_trace (str, optional): Stack trace for debugging, if applicable.
        redirect_uri (str, optional): URI to redirect to, if applicable.
    """

    sub_group_ids: typing.Optional[list[str]] = None
    member_ids: typing.Optional[list[str]] = None


@igz_schema.igz_dataclass
class Group(igz_schema.IGZSchema):
    """
    Group represents a user group in Iguazio.
    This class extends IGZSchema and can be used to define group-specific attributes.

    Args:
        metadata (GroupMetadata): Metadata for the group, including path, parent ID, and sub-group count.
        spec (GroupSpec): Specification for the group, including the group name.
        status (GroupStatus): Status for the group, including sub-group IDs and member IDs.
        relationships (list[IGZSchema], optional): Optional list of relationships associated with the group, if applicable.
    """

    metadata: GroupMetadata = dataclasses.field(default_factory=GroupMetadata)
    spec: GroupSpec = dataclasses.field(default_factory=GroupSpec)
    status: GroupStatus = dataclasses.field(default_factory=GroupStatus)
    relationships: typing.Optional[list[igz_schema.IGZSchema]] = None


@igz_schema.igz_dataclass
class GroupListStatus(base.BaseListStatus):
    """
    Status for a list of groups in Iguazio.
    This class extends BaseListStatus and can be used to represent the status of a collection of User objects.

    Args:
        total (int): Total number of items in the list.
        ctx (str, optional): Context for the status, if applicable.
        status_code (int, optional): Status code for the operation, if applicable.
        error_message (str, optional): Error message if the operation failed.
        stack_trace (str, optional): Stack trace for debugging, if applicable.
        redirect_uri (str, optional): URI to redirect to, if applicable.
    """

    pass


@igz_schema.igz_dataclass
class GroupList(igz_schema.IGZSchema):
    """
    GroupList represents a list of user groups in Iguazio.
    This class extends IGZSchema and can be used to define group list-specific attributes.

    Args:
        items (list[Group]): List of Group objects representing the user groups.
        status (GroupListStatus): Status for the group list.
        relationships (list[IGZSchema], optional): List of relationships associated with the group list, if applicable.
    """

    items: list[Group] = dataclasses.field(default_factory=list)
    status: GroupListStatus = dataclasses.field(default_factory=GroupListStatus)
    relationships: typing.Optional[list[igz_schema.IGZSchema]] = None


@igz_schema.igz_dataclass
class CreateGroupOptions(igz_schema.IGZSchema):
    """
    CreateGroupOptions represents the options for creating a user group in Iguazio.
    This class extends IGZSchema and can be used to define options for group creation.

    Args:
        name (str): Name of the group to be created.
        parent_id (str, optional): Optional ID of the parent group, if this group is a sub-group.
        assignedPolicies (list[str], optional): Optional list of policy IDs to assign to the group upon creation.
    """

    name: str
    parent_id: typing.Optional[str] = None
    assigned_policies: typing.Optional[list[str]] = None


@igz_schema.igz_dataclass
class GetGroupOptions(igz_schema.IGZSchema):
    """
    GetGroupOptions represents the options for retrieving a user group in Iguazio.
    This class extends IGZSchema and can be used to define options for group retrieval.

    Args:
        include_sub_groups (bool, optional): Whether to include sub-groups in the response.
        include_members (bool, optional): Whether to include members in the response.
        include_policies (bool, optional): Whether to include management policies in the response.
    """

    include_sub_groups: bool = False
    include_members: bool = False
    include_policies: bool = False


@igz_schema.igz_dataclass
class ListGroupsOptions(GetGroupOptions, base.PaginationRequest):
    """
    ListGroupsOptions represents the options for listing user groups in Iguazio.
    This class extends GetGroupOptions and PaginationRequest, allowing for pagination and filtering.

    Args:
        include_sub_groups (bool, optional): Whether to include sub-groups in the response.
        include_members (bool, optional): Whether to include members in the response.
        include_policies (bool, optional): Whether to include management policies in the response.
        offset (int, optional): The starting point for the pagination, default is 0.
        limit (int, optional): The maximum number of items to return, default is 10.
    """

    pass


@igz_schema.igz_dataclass
class SearchGroupsOptions(GetGroupOptions, base.PaginationRequest):
    """
    SearchGroupsOptions represents the options for searching user groups in Iguazio.
    This class extends IGZSchema and can be used to define options for group search.

    Args:
        search_term (str): The term to search for in group names.
        exact_match (bool, optional): Whether to perform an exact match search on the group name.
        include_sub_groups (bool, optional): Whether to include sub-groups in the response.
        include_members (bool, optional): Whether to include members in the response.
        include_policies (bool, optional): Whether to include management policies in the response.
        offset (int, optional): The starting point for the pagination, default is 0.
        limit (int, optional): The maximum number of items to return, default is 10.
    """

    search_term: str = ""
    exact_match: bool = False


@igz_schema.igz_dataclass
class SearchGroupsMetadataOptions(base.PaginationRequest):
    """
    Options for searching group metadata in Iguazio.
    Returns lightweight group information (group ID and name).

    Args:
        search_term (str, optional): The term to search for in group names. Defaults to an empty string.
        exact_match (bool, optional): Whether to perform an exact match search. Defaults to False.
        offset (int, optional): The starting point for the pagination, default is 0.
        limit (int, optional): The maximum number of items to return, default is 10.
    """

    search_term: str = ""
    exact_match: bool = False


@igz_schema.igz_dataclass
class GroupMetadataInfo(igz_schema.IGZSchema):
    """
    Lightweight group metadata information.
    Contains only the essential fields needed for project membership management.

    Args:
        group_id (str): Unique identifier of the group.
        name (str): Name of the group.
    """

    group_id: str = ""
    name: str = ""


@igz_schema.igz_dataclass
class GroupMetadataInfoListStatus(base.BaseListStatus):
    """
    Status for a list of group metadata info in Iguazio.

    Args:
        total (int): Total number of items in the list.
    """

    pass


@igz_schema.igz_dataclass
class GroupMetadataInfoList(igz_schema.IGZSchema):
    """
    A list of group metadata info in Iguazio.

    Args:
        items (list[GroupMetadataInfo]): List of GroupMetadataInfo objects.
        status (GroupMetadataInfoListStatus): Status of the group metadata info list.
    """

    items: list[GroupMetadataInfo] = dataclasses.field(default_factory=list)
    status: GroupMetadataInfoListStatus = dataclasses.field(
        default_factory=GroupMetadataInfoListStatus
    )


@igz_schema.igz_dataclass
class RenameGroupOptions(igz_schema.IGZSchema):
    """
    RenameGroupOptions represents the options for renaming a user group in Iguazio.
    This class extends IGZSchema and can be used to define options for group renaming.

    Args:
        new_name (str): The new name for the group.
    """

    new_name: str


@igz_schema.igz_dataclass
class MoveGroupOptions(igz_schema.IGZSchema):
    """
    MoveGroupOptions represents the options for moving a user group in Iguazio.
    This class extends IGZSchema and can be used to define options for group movement.

    Args:
        new_parent_id (str): The ID of the new parent group to move this group under.
    """

    new_parent_id: str


@igz_schema.igz_dataclass
class AssignGroupMembersOptions(igz_schema.IGZSchema):
    """
    AssignGroupMembersOptions represents the options for assigning members to a user group in Iguazio.
    This class extends IGZSchema and can be used to define options for member assignment.

    Args:
        usernames (list[str]): List of usernames to assign to the group.
    """

    usernames: list[str] = dataclasses.field(default_factory=list)
