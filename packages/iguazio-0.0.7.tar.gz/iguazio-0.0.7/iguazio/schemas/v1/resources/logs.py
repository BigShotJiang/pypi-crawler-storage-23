# Copyright 2026 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import dataclasses
import datetime
import enum
import typing

import iguazio.schemas.base.igz_schema as igz_schema
import iguazio.schemas.v1.common.base as base


class BundleState(enum.Enum):
    """
    Represents the lifecycle state of a log bundle.

    Attributes:
        unspecified: Default value (protobuf best practice).
        running: Log bundle collection is in progress.
        failed: Log bundle collection has failed.
        aborting: Log bundle collection is being aborted.
        aborted: Log bundle collection was aborted.
        completed: Log bundle collection has completed successfully.
    """

    unspecified = "unspecified"
    running = "running"
    failed = "failed"
    aborting = "aborting"
    aborted = "aborted"
    completed = "completed"


@igz_schema.igz_dataclass
class LogBundleMetadata(base.BaseMetadata):
    """
    Metadata for a log bundle in Iguazio.
    This class extends BaseMetadata and can be used to define log bundle-specific metadata attributes.

    Args:
        id (str): Unique identifier for the log bundle.
    """

    pass


@igz_schema.igz_dataclass
class LogBundleSpec(base.BaseSpec):
    """
    Specification for a log bundle in Iguazio.
    This class extends BaseSpec and contains user-provided input when triggering a collection.

    Args:
        triggered_by (str, optional): Source of the trigger, e.g., "user_action" or "platform".
        reason (str, optional): Optional reason for triggering the collection (e.g., platform event type).
    """

    triggered_by: typing.Optional[str] = None
    reason: typing.Optional[str] = None


@igz_schema.igz_dataclass
class LogBundleStatus(base.BaseStatus):
    """
    Status for a log bundle in Iguazio.
    This class extends BaseStatus and contains server-set runtime state of a log bundle.

    Args:
        state (BundleState): Current lifecycle state of the log bundle. Defaults to
            BundleState.unspecified when not set by the server.
        created_at (datetime.datetime, optional): Timestamp when the collection started.
        finished_at (datetime.datetime, optional): Timestamp when the collection finished
        file_path (str, optional): File path of the log bundle (available only when completed).
    """

    state: BundleState = BundleState.unspecified
    created_at: typing.Optional[datetime.datetime] = None
    finished_at: typing.Optional[datetime.datetime] = None
    file_path: typing.Optional[str] = None


@igz_schema.igz_dataclass
class LogBundle(igz_schema.IGZSchema):
    """
    A log bundle in Iguazio.
    This class extends IGZSchema and can be used to represent a log bundle object with metadata, spec, and status.

    Args:
        metadata (LogBundleMetadata): Metadata for the log bundle, encapsulated in LogBundleMetadata.
        spec (LogBundleSpec): Specification for the log bundle, encapsulated in LogBundleSpec.
        status (LogBundleStatus): Status of the log bundle, encapsulated in LogBundleStatus.
    """

    metadata: LogBundleMetadata = dataclasses.field(default_factory=LogBundleMetadata)
    spec: LogBundleSpec = dataclasses.field(default_factory=LogBundleSpec)
    status: LogBundleStatus = dataclasses.field(default_factory=LogBundleStatus)


@igz_schema.igz_dataclass
class LogBundleListStatus(base.BaseStatus):
    """
    Status for a list of log bundles in Iguazio.
    This class extends BaseStatus and contains metadata about the list response.
    """

    pass


@igz_schema.igz_dataclass
class LogBundleList(igz_schema.IGZSchema):
    """
    A list of log bundles in Iguazio.
    This class extends IGZSchema and can be used to represent a collection of LogBundle objects along with their status.

    Args:
        items (list[LogBundle]): List of LogBundle objects.
        status (LogBundleListStatus): Status of the log bundle list, encapsulated in LogBundleListStatus.
    """

    items: list[LogBundle] = dataclasses.field(default_factory=list)
    status: LogBundleListStatus = dataclasses.field(default_factory=LogBundleListStatus)


@igz_schema.igz_dataclass
class ListLogBundlesOptions(igz_schema.IGZSchema):
    """
    Options for listing log bundles in Iguazio.

    When offset and limit are omitted, the backend uses its defaults (offset=0, limit=100).
    Maximum limit per request is 1,000.

    Args:
        state (BundleState, optional): Filter by bundle state.
        since (datetime.datetime, optional): Timestamp lower boundary (createdAt >= since).
        offset (int, optional): Starting index (0-based). Omit to use backend default (0).
        limit (int, optional): Maximum number of items to return. Omit to use backend default (100).
    """

    state: typing.Optional[BundleState] = None
    since: typing.Optional[datetime.datetime] = None
    offset: typing.Optional[int] = None
    limit: typing.Optional[int] = None


@igz_schema.igz_dataclass
class GetLogBundleOptions(igz_schema.IGZSchema):
    """
    Options for retrieving a specific log bundle in Iguazio.
    This class extends IGZSchema and can be used to define options specific to log bundle retrieval.

    Args:
        id (str): Log bundle ID.
    """

    id: str


@igz_schema.igz_dataclass
class DeleteLogBundleOptions(igz_schema.IGZSchema):
    """
    Options for deleting a log bundle in Iguazio.
    This class extends IGZSchema and can be used to define options specific to log bundle deletion.

    Args:
        id (str): Log bundle ID.
    """

    id: str
