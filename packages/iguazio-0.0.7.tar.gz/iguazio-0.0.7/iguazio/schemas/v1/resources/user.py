# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import dataclasses
import datetime
import enum
import typing

import iguazio.schemas.base.igz_schema as igz_schema
import iguazio.schemas.v1.common.base as base
import iguazio.schemas.validators as validators


@igz_schema.igz_dataclass
class UserMetadata(base.BaseMetadata):
    """
    Metadata for a user in Iguazio.
    This class extends BaseMetadata and can be used to define user-specific metadata attributes.

    Args:
        username (str): Username of the user.
        id (str): Unique identifier for the resource.
        resource_type (str, optional): Optional type of the resource, if applicable.
    """

    username: str


class GetSelfFormat(enum.Enum):
    """
    Enum representing the format options for GetSelf responses.

    Attributes:
        minimal: Minimal format, returns JWT-derived fields plus groups.
        full: Full format, returns complete user information.
    """

    minimal = 0
    full = 1


@igz_schema.igz_dataclass
class GetSelfOptions(igz_schema.IGZSchema):
    """
    Options for retrieving the authenticated user in Iguazio.
    This class extends IGZSchema and can be used to define options for GetSelf.

    Args:
        format (GetSelfFormat, optional): Response format. Defaults to minimal.
    """

    format: GetSelfFormat = GetSelfFormat.minimal


@igz_schema.igz_dataclass
class UserSpec(base.BaseSpec):
    """
    Specification for a user in Iguazio.
    This class extends BaseSpec and can be used to define user-specific specification attributes.

    Args:
        email (str, optional): Email address of the user.
        first_name (str, optional): First name of the user.
        last_name (str, optional): Last name of the user.
        unix_uid (int, optional): Unix user ID for the user.
    """

    email: typing.Optional[str] = dataclasses.field(
        default=None, metadata={"validator": validators.validate_email}
    )
    first_name: typing.Optional[str] = None
    last_name: typing.Optional[str] = None
    unix_uid: typing.Optional[int] = None


@igz_schema.igz_dataclass
class UserStatus(base.BaseStatus):
    """
    Status for a user in Iguazio.
    This class extends BaseStatus and can be used to define user-specific status attributes.

    Args:
        active (bool): Indicates if the user is currently active.
        created_at (datetime.datetime, optional): Timestamp when the user was created.
        last_login (datetime.datetime, optional): Timestamp of the user's last login.
        last_activity (datetime.datetime, optional): Timestamp of the user's last activity.
        group_ids (list[str], optional): List of group IDs the user belongs to.
        assigned_policies (list[str], optional): List of policy IDs assigned to the user.
        idps (list[str], optional): List of identity provider IDs associated with the user.
        ctx (str, optional): Context for the status, if applicable.
        status_code (int, optional): Status code for the operation, if applicable.
        error_message (str, optional): Error message if the operation failed.
        stack_trace (str, optional): Stack trace for debugging, if applicable.
        redirect_uri (str, optional): URI to redirect to, if applicable.
    """

    active: bool = True
    created_at: typing.Optional[datetime.datetime] = None
    last_login: typing.Optional[datetime.datetime] = None
    last_activity: typing.Optional[datetime.datetime] = None
    group_ids: typing.Optional[list[str]] = None
    assigned_policies: typing.Optional[list[str]] = None
    idps: typing.Optional[list[str]] = None


@igz_schema.igz_dataclass
class User(igz_schema.IGZSchema):
    """
    A user in Iguazio.
    This class extends IGZSchema and can be used to represent a user object with metadata, spec, status, and
    relationships.

    Args:
        metadata (UserMetadata): Metadata for the user, encapsulated in UserMetadata.
        spec (UserSpec): Specification for the user, encapsulated in UserSpec.
        status (UserStatus): Status of the user, encapsulated in UserStatus.
        relationships (list[IGZSchema], optional): Optional relationships associated with the user.
    """

    metadata: UserMetadata = dataclasses.field(default_factory=UserMetadata)
    spec: UserSpec = dataclasses.field(default_factory=UserSpec)
    status: UserStatus = dataclasses.field(default_factory=UserStatus)
    relationships: typing.Optional[list[igz_schema.IGZSchema]] = None


@igz_schema.igz_dataclass
class UserListStatus(base.BaseListStatus):
    """
    Status for a list of users in Iguazio.
    This class extends BaseListStatus and can be used to represent the status of a collection of User objects.

    Args:
        total (int): Total number of items in the list.
        ctx (str, optional): Context for the status, if applicable.
        status_code (int, optional): Status code for the operation, if applicable.
        error_message (str, optional): Error message if the operation failed.
        stack_trace (str, optional): Stack trace for debugging, if applicable.
        redirect_uri (str, optional): URI to redirect to, if applicable.
    """

    pass


@igz_schema.igz_dataclass
class UserList(igz_schema.IGZSchema):
    """
    A list of users in Iguazio.
    This class extends IGZSchema and can be used to represent a collection of User objects along with their status.

    Args:
        items (list[User]): List of User objects.
        status (UserListStatus): Status of the user list, encapsulated in UserListStatus.
        relationships (list[IGZSchema], optional): Optional relationships associated with the user list.
    """

    items: list[User] = dataclasses.field(default_factory=list)
    status: UserListStatus = dataclasses.field(default_factory=UserListStatus)
    relationships: typing.Optional[list[igz_schema.IGZSchema]] = None


@igz_schema.igz_dataclass
class CreateUserOptions(igz_schema.IGZSchema):
    """
    Options for creating a user in Iguazio.
    This class extends IGZSchema and can be used to define options specific to user creation.

    Args:
        username (str): Username for the new user.
        email (str): Email address for the new user, validated using validate_email.
        first_name (str): First name of the new user.
        last_name (str): Last name of the new user.
        active (bool, optional): Flag indicating if the user is active. Defaults to True.
        email_verified (bool, optional): Flag indicating if the user's email is verified. Defaults to None.
        group_ids (list[str], optional): List of group IDs to assign to the user. Defaults to None.
        assigned_policies (list[str], optional): List of policy IDs to assign to the user. Defaults to None.
        password (str, optional): Initial password for the user. If provided, the user can log in with this password.
            It is recommended to use this with force_password_reset=True so the user updates the password on first login.
            Defaults to None.
        force_password_reset (bool, optional): If True, the user will be required to change their password on first
            login. Defaults to None (True).
    """

    username: str
    email: str = dataclasses.field(metadata={"validator": validators.validate_email})
    first_name: str
    last_name: str
    active: bool = True
    email_verified: typing.Optional[bool] = None
    group_ids: typing.Optional[list[str]] = None
    assigned_policies: typing.Optional[list[str]] = None
    password: typing.Optional[str] = None
    force_password_reset: typing.Optional[bool] = None


@igz_schema.igz_dataclass
class GetUserOptions(igz_schema.IGZSchema):
    """
    Options for retrieving a user in Iguazio.
    This class extends IGZSchema and can be used to define options specific to user retrieval.

    Args:
        include_groups (bool, optional): Whether to include group information in the response. Defaults to False.
        include_policies (bool, optional): Whether to include management policies information in the response. Defaults to False.
        include_user_activity (bool, optional): Whether to include user activity information in the response.
            Defaults to False.
        include_idps (bool, optional): Whether to include identity provider information in the response.
            Defaults to False.
    """

    include_groups: bool = False
    include_policies: bool = False
    include_user_activity: bool = False
    include_idps: bool = False


@igz_schema.igz_dataclass
class ListUsersOptions(GetUserOptions, base.PaginationRequest):
    """
    Options for listing users in Iguazio.
    This class extends GetUserOptions and PaginationRequest, allowing for pagination and filtering of user lists.

    Args:
        include_groups (bool, optional): Whether to include group information in the response. Defaults to False.
        include_policies (bool, optional): Whether to include management policies information in the response. Defaults to False.
        include_user_activity (bool, optional): Whether to include user activity information in the response.
            Defaults to False.
        include_idps (bool, optional): Whether to include identity provider information in the response.
            Defaults to False.
        offset (int, optional): The starting point for the pagination, default is 0.
        limit (int, optional): The maximum number of items to return, default is 10.
    """

    pass


@igz_schema.igz_dataclass
class SearchUsersOptions(ListUsersOptions):
    """
    Options for searching users in Iguazio.
    This class extends ListUsersOptions and can be used to define search-specific options.

    Args:
        search_term (str, optional): The term to search for in user attributes. Defaults to an empty string.
        username (str, optional): Username to search for. Overrides search_term if provided.
        email (str, optional): Email to search for. Overrides search_term if provided.
        first_name (str, optional): First name to search for. Overrides search_term if provided.
        last_name (str, optional): Last name to search for. Overrides search_term if provided.
        exact_match (bool, optional): Whether to perform an exact match search. Defaults to False.
        include_groups (bool, optional): Whether to include group information in the response. Defaults to False.
        include_policies (bool, optional): Whether to include management policies information in the response. Defaults to False.
        include_user_activity (bool, optional): Whether to include user activity information in the response.
            Defaults to False.
        include_idps (bool, optional): Whether to include identity provider information in the response.
            Defaults to False.
        offset (int, optional): The starting point for the pagination, default is 0.
        limit (int, optional): The maximum number of items to return, default is 10.
    """

    search_term: str = ""

    # attribute search options override the search_term
    username: typing.Optional[str] = None
    email: typing.Optional[str] = None
    first_name: typing.Optional[str] = None
    last_name: typing.Optional[str] = None

    exact_match: bool = False


@igz_schema.igz_dataclass
class SearchUsersMetadataOptions(base.PaginationRequest):
    """
    Options for searching user metadata in Iguazio.
    Returns lightweight user information (username, email, first name, last name) for active users only.

    Args:
        search_term (str, optional): The term to search for in user attributes. Defaults to an empty string.
        username (str, optional): Username to search for. Overrides search_term if provided.
        email (str, optional): Email to search for. Overrides search_term if provided.
        first_name (str, optional): First name to search for. Overrides search_term if provided.
        last_name (str, optional): Last name to search for. Overrides search_term if provided.
        exact_match (bool, optional): Whether to perform an exact match search. Defaults to False.
        offset (int, optional): The starting point for the pagination, default is 0.
        limit (int, optional): The maximum number of items to return, default is 10.
    """

    search_term: str = ""

    # attribute search options override the search_term
    username: typing.Optional[str] = None
    email: typing.Optional[str] = None
    first_name: typing.Optional[str] = None
    last_name: typing.Optional[str] = None

    exact_match: bool = False


@igz_schema.igz_dataclass
class UserMetadataInfo(igz_schema.IGZSchema):
    """
    Lightweight user metadata information.
    Contains only the essential fields needed for project membership management.

    Args:
        username (str): Username of the user.
        email (str): Email address of the user.
        first_name (str): First name of the user.
        last_name (str): Last name of the user.
    """

    username: str = ""
    email: str = ""
    first_name: str = ""
    last_name: str = ""


@igz_schema.igz_dataclass
class UserMetadataInfoListStatus(base.BaseListStatus):
    """
    Status for a list of user metadata info in Iguazio.

    Args:
        total (int): Total number of items in the list.
    """

    pass


@igz_schema.igz_dataclass
class UserMetadataInfoList(igz_schema.IGZSchema):
    """
    A list of user metadata info in Iguazio.

    Args:
        items (list[UserMetadataInfo]): List of UserMetadataInfo objects.
        status (UserMetadataInfoListStatus): Status of the user metadata info list.
    """

    items: list[UserMetadataInfo] = dataclasses.field(default_factory=list)
    status: UserMetadataInfoListStatus = dataclasses.field(
        default_factory=UserMetadataInfoListStatus
    )


@igz_schema.igz_dataclass
class UpdateUserOptions(igz_schema.IGZSchema):
    """
    Options for updating a user in Iguazio.
    This class extends IGZSchema and can be used to define options specific to user updates.

    Args:
        username (str, optional): New username for the user.
        email (str, optional): New email address for the user, validated using validate_email.
        first_name (str, optional): New first name for the user.
        last_name (str, optional): New last name for the user.
        email_verified (bool, optional): Flag indicating if the user's email is verified. Defaults to None.
    """

    username: typing.Optional[str] = None
    email: typing.Optional[str] = None
    first_name: typing.Optional[str] = None
    last_name: typing.Optional[str] = None
    email_verified: typing.Optional[bool] = None


@igz_schema.igz_dataclass
class AssignUserGroupsOptions(igz_schema.IGZSchema):
    """
    Options for assigning groups to a user in Iguazio.
    This class extends IGZSchema and can be used to define options for group assignment.

    Args:
        group_ids (list[str]): List of group IDs to assign to the user.
    """

    group_ids: list[str] = dataclasses.field(default_factory=list)
