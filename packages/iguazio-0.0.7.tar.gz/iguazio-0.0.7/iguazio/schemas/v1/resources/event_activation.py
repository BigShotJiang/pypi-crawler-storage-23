# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import dataclasses
import datetime
import enum
import typing

import iguazio.schemas.base.igz_schema as igz_schema
import iguazio.schemas.v1.common.base as base


class Severity(enum.Enum):
    """Severity levels for events."""

    UNSPECIFIED = "unspecified"
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    MAJOR = "major"
    CRITICAL = "critical"


@igz_schema.igz_dataclass
class EventActivationSpec(base.BaseSpec):
    """
    Specification for an event activation. Also used as options for publishing an event.

    Example usage::

        options = iguazio.schemas.EventActivationSpec(
            config_name="user_login",
            source="api-service",
            details={"username": "john", "ip": "192.168.1.1"}
        )
        event = client.publish_event(options)

    For catalog events (config_name exists in the event catalog):
    - kind, class, and severity are taken from the catalog configuration
    - Any values passed for these fields are ignored

    For custom events (config_name not in catalog):
    - kind, class, and severity use passed values or defaults
    - Event is only persisted to DB, not published to queue

    Args:
        config_name (str): The event configuration name (e.g., "user_login").
        source (str): The source service that generated the event.
        kind (str, optional): The event kind ("audit" or "system").
        severity (Severity, optional): The severity level of the event.
        class_ (str, optional): The event class (e.g., "authentication").
        project_name (str, optional): The project scope (None for global events).
        entity_name (str, optional): The entity associated with the event.
        trace_id (str, optional): Trace ID for distributed tracing.
        details (dict, optional): Arbitrary JSON details/payload.
        description (str, optional): Event description from config. Populated automatically for catalog events.
    """

    config_name: str
    source: str = ""
    kind: str = ""
    severity: Severity = Severity.UNSPECIFIED
    class_: typing.Optional[str] = dataclasses.field(
        default=None, metadata={"json_key": "class"}
    )
    project_name: str = ""
    entity_name: str = ""
    trace_id: str = ""
    details: dict = dataclasses.field(default_factory=dict)
    description: str = ""


@igz_schema.igz_dataclass
class EventActivationMetadata(base.BaseMetadata):
    """
    Metadata for an event activation in Iguazio.
    This class extends BaseMetadata and can be used to define event activation-specific metadata attributes.

    Args:
        id (str): Unique identifier for the event activation.
        resource_type (str, optional): Optional type of the resource, if applicable.
    """


@igz_schema.igz_dataclass
class EventActivationStatus(base.BaseStatus):
    """
    Status for an event activation.

    Args:
        created_at (datetime.datetime, optional): Timestamp when the event was created.
        ctx (str, optional): Context for the status.
        status_code (int, optional): Status code for the operation.
        error_message (str, optional): Error message if the operation failed.
        stack_trace (str, optional): Stack trace for debugging.
        redirect_uri (str, optional): URI to redirect to.
    """

    created_at: typing.Optional[datetime.datetime] = None


@igz_schema.igz_dataclass
class GetEventActivationOptions(igz_schema.IGZSchema):
    """
    Options for getting a single event activation.

    Args:
        id (str): The unique identifier of the event activation.
    """

    id: str


@igz_schema.igz_dataclass
class EventActivation(igz_schema.IGZSchema):
    """
    An event activation in Iguazio.

    Args:
        metadata (EventActivationMetadata): Metadata for the event activation, including the activation ID.
        spec (EventActivationSpec): Specification for the event activation.
        status (EventActivationStatus, optional): Status of the event activation.
    """

    metadata: EventActivationMetadata = dataclasses.field(
        default_factory=EventActivationMetadata
    )
    spec: EventActivationSpec = dataclasses.field(default_factory=EventActivationSpec)
    status: EventActivationStatus = dataclasses.field(
        default_factory=EventActivationStatus
    )


@igz_schema.igz_dataclass
class ListEventActivationsOptions(igz_schema.IGZSchema):
    """
    Options for listing event activations.

    Args:
        kind (str, optional): Filter by event kind ("audit" or "system").
        mode (str, optional): Response mode ("minimal" or "full"). Minimal provides minimal data for UI, full returns everything. Defaults to "full".
        name (str, optional): Substring filter on configName. Use "~prefix" for substring match.
        offset (int, optional): Starting index (0-based). Defaults to 0.
        limit (int, optional): Maximum results to return. Defaults to 1000.
        since (datetime.datetime, optional): Timestamp upper boundary (createdAt <= since).
        until (datetime.datetime, optional): Timestamp lower boundary (createdAt >= until).
        severity (list[Severity], optional): Filter by severity (multi-value). Can specify multiple Severity enum values.
        class_ (list[str], optional): Filter by class (multi-value). Can specify multiple values.
        source (list[str], optional): Filter by source (multi-value). Can specify multiple values.
        project_name (str, optional): Filter by project name (exact match).
        entity_name (str, optional): Substring filter on entityName. Use "~prefix" for substring match.
        order_by (list[base.OrderBySpec], optional): List of order by specifications. Supports multi-column ordering (e.g., name ASC, created_at DESC). If empty, defaults to created_at DESC.
    """

    kind: str = ""
    mode: str = "full"
    name: str = ""
    offset: typing.Optional[int] = None
    limit: typing.Optional[int] = None
    since: typing.Optional[datetime.datetime] = None
    until: typing.Optional[datetime.datetime] = None
    severity: typing.Optional[list[Severity]] = None
    class_: typing.Optional[list[str]] = dataclasses.field(
        default=None, metadata={"json_key": "class"}
    )
    source: typing.Optional[list[str]] = None
    project_name: str = ""
    entity_name: str = ""
    order_by: typing.Optional[list[base.OrderBySpec]] = None


@igz_schema.igz_dataclass
class EventActivationListStatus(base.BaseListStatus):
    """
    Status for a list of event activations.
    """

    pass


@igz_schema.igz_dataclass
class EventActivationList(igz_schema.IGZSchema):
    """
    A list of event activations in Iguazio.

    Args:
        items (list[EventActivation]): List of event activations.
        status (EventActivationListStatus): Status of the list response.
    """

    items: typing.List[EventActivation] = dataclasses.field(default_factory=list)
    status: EventActivationListStatus = dataclasses.field(
        default_factory=EventActivationListStatus
    )


@igz_schema.igz_dataclass
class GetEventActivationsSummaryOptions(igz_schema.IGZSchema):
    """
    Options for getting event activations summary.

    Args:
        kind (str, optional): Filter by event kind ("audit" or "system").
    """

    kind: str = ""


@igz_schema.igz_dataclass
class EventActivationSummaryStatus(base.BaseStatus):
    """
    Status for event activation summary.

    Args:
        counters_by_severity (dict[str, int]): Counts of activations grouped by severity.
    """

    counters_by_severity: typing.Dict[str, int] = dataclasses.field(
        default_factory=dict
    )


@igz_schema.igz_dataclass
class EventActivationSummary(igz_schema.IGZSchema):
    """
    Event activation counts grouped by severity for the last 24 hours.

    Args:
        status (EventActivationSummaryStatus): Status containing counters_by_severity.
    """

    status: EventActivationSummaryStatus = dataclasses.field(
        default_factory=EventActivationSummaryStatus
    )
