# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import dataclasses
import typing

import iguazio.common.errors as errors
import iguazio.common.helpers as helpers


igz_dataclass = dataclasses.dataclass(
    kw_only=True,
    repr=False,
)


@igz_dataclass
class IGZSchema:
    """
    Base class for Iguazio schemas.

    This class provides a foundation for creating schemas with validation and serialization capabilities.
    It uses Python's dataclasses to define fields and their types, and it includes methods for validation,
    serialization, and representation.
    """

    def __repr__(self):
        return self._repr(indent_idx=0)

    def __post_init__(self):
        """
        Post-initialization method to validate the schema.

        This method is called automatically after the dataclass is initialized.
        """
        self.validate()

    def to_dict(self) -> dict:
        """
        Convert the schema to a dictionary representation.

        This method is useful for serialization and can be used to convert the schema
        to a format suitable for JSON or other serialization formats.

        Returns:
            dict: Dictionary representation of the schema.
        """
        # The serializer imports this module to perform serialization.
        # so we need to ensure that the import is done here to avoid circular imports.
        import iguazio.schemas.serializer

        try:
            return iguazio.schemas.serializer.serialize(self)
        except Exception as exc:
            raise errors.SerializationError(
                f"Failed to serialize schema {self.__class__.__name__}: {exc}"
            ) from exc

    def to_query_params(self) -> dict:
        """
        Convert the schema to query parameters suitable for URL encoding.

        For complex types (like lists of objects), this method JSON-encodes them
        as strings so they can be properly sent as URL query parameters.

        Returns:
            dict: Dictionary with query parameter values, where complex objects
                  are JSON-encoded as strings.
        """
        import json

        params = self.to_dict()

        # Encode complex array values as JSON strings
        encoded = {}
        for key, value in params.items():
            if isinstance(value, list) and value and isinstance(value[0], dict):
                # JSON-encode each dict in the list
                encoded[key] = [
                    json.dumps(item, separators=(",", ":")) for item in value
                ]
            else:
                encoded[key] = value

        return encoded

    def validate(self) -> None:
        """
        Validate the schema fields based on their types and custom validators.

        This method checks if each field is of the expected type and raises
        TypeError if the type does not match. It also checks for custom validators
        defined in the field metadata and calls them if they exist.
        It handles lists, dictionaries, typing.Optional and typing.Union with type arguments,
        ensuring that the values conform to the expected types.

        Raises:
            ValueError: If a field is None and has no default value.
            TypeError: If a field's value does not match the expected type.
        """
        for field in dataclasses.fields(self):
            value = getattr(self, field.name)
            if value is None and field.default is dataclasses.MISSING:
                raise ValueError(
                    f"Field '{field.name}' cannot be None and has no default value."
                )

            custom_validator = field.metadata.get("validator", None)
            if custom_validator:
                custom_validator(value)
            elif not self._validate_type_union(value, field.type):
                raise TypeError(
                    f"Field '{field.name}' has invalid type: {type(value)}, "
                    f"Expected: {repr(field.type)}."
                )

    def _validate_type_union(
        self,
        value: typing.Any,
        field_type: type,
    ) -> bool:
        """
        Validate if the value matches any type in a typing.Union.

        This method checks if the value is any of the types specified in the Union or
        is the field_type itself if not a Union.

        Args:
            value (Any): The value to validate.
            field_type (type): The expected type of the value, which can be a Union.

        Returns:
            bool: True if the value matches any of the types in the Union, False otherwise.
        """
        field_types = [field_type]
        if hasattr(field_type, "__origin__") and field_type.__origin__ is typing.Union:
            field_types = field_type.__args__

        return any(self._validate_type(value, field_type) for field_type in field_types)

    def _validate_type(
        self,
        value: typing.Any,
        field_type: type,
    ) -> bool:
        """
        Check if the value is of the expected type, handling special cases such as lists and dictionaries.

        Args:
            value (Any): The value to validate.
            field_type (type): The expected type of the value.

        Returns:
            bool: True if the value matches the expected type, False otherwise.
        """
        if helpers.is_list_type(field_type):
            return self._validate_list_type(value, field_type)
        elif helpers.is_dict_type(field_type):
            return self._validate_dict_type(value, field_type)

        return isinstance(value, field_type)

    def _validate_list_type(self, value: typing.Any, field_type: type) -> bool:
        """
        Validate if the value is a list or a typing.List.

        If value is None, the type is considered a NoneType and returns False.
        If the field_type is a simple list or typing.List without type arguments,
        it checks if the value is an instance of list.
        If the field_type is a list with type arguments, it checks if each item
        in the value list matches the specified type.

        Args:
            value (Any): The value to validate.
            field_type (type): The expected type of the value.

        Returns:
            bool: True if the value matches the expected type, False otherwise.
        """
        if value is None:
            return False

        if list_type := helpers.get_list_type_arg(field_type):
            return all([self._validate_type_union(item, list_type) for item in value])

        else:
            return isinstance(value, field_type)

    def _validate_dict_type(self, value: typing.Any, field_type: type) -> bool:
        """
        Validate if the value is a dictionary with keys and values of the specified types.

        If value is None, the type is considered a NoneType and returns False.
        If the field_type is a simple dict or typing.Dict without type arguments,
        it checks if the value is an instance of dict.
        If the field_type is a dict with type arguments, it checks if each key and value
        in the value dictionary matches the specified key and value types.

        Args:
            value (Any): The value to validate.
            field_type (type): The expected type of the value.

        Returns:
            bool: True if the value matches the expected type, False otherwise.
        """
        if value is None:
            return False

        if not hasattr(field_type, "__args__"):
            return isinstance(value, field_type)
        else:
            key_type, value_type = field_type.__args__
            return all(
                [
                    self._validate_type_union(key, key_type)
                    and self._validate_type_union(val, value_type)
                    for key, val in value.items()
                ]
            )

    def _repr(self, indent_idx: int = 0) -> str:
        """
        Generate a string representation of the schema with indentation.

        This method recursively formats the schema fields, handling nested schemas,
        lists, and dictionaries. It uses indentation to improve readability.

        Example:
            User(
                metadata=UserMetadata(
                    id='3747a0a7-9346-4e01-9f8d-597a4613ec36',
                    resource_type='user',
                    username='test-user'
                ),
                spec=UserSpec(
                    email='a@a.a',
                    first_name='q',
                    last_name='q'
                ),
                status=UserStatus(
                    ctx='832e437d-e67c-4236-b08f-8c95b00075d9',
                    status_code=200,
                    active=True,
                    created_at=datetime.datetime(2025, 7, 21, 6, 25, 49, 644000, tzinfo=datetime.timezone.utc)
                )
            )

        Args:
            indent_idx (int, optional): The current indentation level (default is 0).

        Returns:
            str: A formatted string representation of the schema.
        """
        indent = " " * 4 * indent_idx
        next_indent = " " * 4 * (indent_idx + 1)
        fields = []
        for field in dataclasses.fields(self):
            value = getattr(self, field.name)
            if not value:
                continue
            if isinstance(value, IGZSchema):
                value_str = value._repr(indent_idx + 1)
            elif isinstance(value, list):
                value_str = self._repr_list(value, indent_idx + 1)
            elif isinstance(value, dict):
                value_str = self._repr_dict(value, indent_idx + 1)
            else:
                value_str = repr(value)
            fields.append(f"{next_indent}{field.name}={value_str}")

        if not fields:
            return f"{self.__class__.__name__}()"

        return f"{self.__class__.__name__}(\n" + ",\n".join(fields) + f"\n{indent})"

    @staticmethod
    def _repr_list(value, indent_idx: int = 0) -> str:
        """
        Generate a string representation of a list with indentation.

        This method formats each item in the list, handling nested schemas and
        ensuring proper indentation for readability.

        Example:
            [
                'item1',
                'item2',
                'item3'
            ]

        Args:
            value (list): The list to represent.
            indent_idx (int, optional): The current indentation level (default is 0).

        Returns:
            str: A formatted string representation of the list.
        """
        indent = " " * 4 * indent_idx
        next_indent = " " * 4 * (indent_idx + 1)
        return (
            f"[\n{next_indent}"
            + f",\n{next_indent}".join(
                [
                    item._repr(indent_idx + 1)
                    if isinstance(item, IGZSchema)
                    else repr(item)
                    for item in value
                ]
            )
            + f"\n{indent}]"
        )

    @staticmethod
    def _repr_dict(value, indent_idx: int = 0) -> str:
        """
        Generate a string representation of a dictionary with indentation.

        This method formats each key-value pair in the dictionary, handling nested schemas
        and ensuring proper indentation for readability.

        Example:
            {
                'key1': 'value1',
                'key2': 'value2',
                'key3': {
                    'nested_key': 'nested_value'
                }
            }

        Args:
            value (dict): The dictionary to represent.
            indent_idx (int, optional): The current indentation level (default is 0).

        Returns:
            str: A formatted string representation of the dictionary.
        """
        indent = " " * 4 * indent_idx
        next_indent = " " * 4 * (indent_idx + 1)
        return (
            f"{{\n{next_indent}"
            + f",\n{next_indent}".join(
                [
                    f"{repr(key)}: {value._repr(indent_idx + 1) if isinstance(value, IGZSchema) else repr(value)}"
                    for key, value in value.items()
                ]
            )
            + f"\n{indent}}}"
        )
