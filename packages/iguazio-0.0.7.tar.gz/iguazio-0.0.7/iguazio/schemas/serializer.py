# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import dataclasses
import datetime
import enum
import importlib
import typing
import re

import inflection

import iguazio.common.constants
import iguazio.common.helpers as helpers
import iguazio.schemas.base.igz_schema as igz_schema

SUPPORTED_VERSIONS = [
    "v1",
]
DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%fZ"


def serialize(data: typing.Any) -> typing.Any:
    """
    Serialize data into a format suitable for JSON or other serialization formats.

    If the data is a primitive type, it will return the data as is.
    If the data is a datetime object, it will convert it to a string in ISO format.
    If the data is a list, it will serialize each item in the list.
    If the data is a dict, it will convert the keys to camelCase and serialize the values.
    If the data is an instance of IGZSchema, it will serialize its fields and relationships.
    If the data is not of a supported type, it will raise a TypeError.

    Args:
        data (Any): The data to serialize, which can be a primitive type, list, dict, or IGZSchema instance.

    Returns:
        Any: Serialized data in a format suitable for JSON or other serialization formats.

    Raises:
        TypeError: If the data is not of a supported type for serialization.
    """
    if isinstance(data, iguazio.common.constants._Serialization.primitive_types):
        return data
    if isinstance(data, datetime.datetime):
        return data.strftime(DATETIME_FORMAT)
    if isinstance(data, enum.Enum):
        return data.value
    if isinstance(data, list):
        return [serialize(item) for item in data]
    if isinstance(data, dict):
        return {
            inflection.camelize(key, False): serialize(value)
            for key, value in data.items()
        }
    if isinstance(data, igz_schema.IGZSchema):
        serialized_data = {}
        for field in dataclasses.fields(data):
            value = getattr(data, field.name)
            # if value is none and the field is optional, skip it
            if value is None and field.default is not dataclasses.MISSING:
                continue
            # Use json_key metadata if present, otherwise camelize the field name
            json_key = field.metadata.get("json_key")
            if json_key:
                output_name = json_key
            else:
                output_name = inflection.camelize(field.name, False)
            serialized_data[output_name] = serialize(value)
            if field.name == "relationships":
                for idx, relationship in enumerate(serialized_data[output_name]):
                    relationship["@type"] = _get_protobuf_any_type_string(value[idx])
        return serialized_data

    raise TypeError(f"Unsupported data type for serialization: {type(data)}")


def deserialize(
    data: typing.Any,
    schema: typing.Optional[typing.Type[igz_schema.IGZSchema]] = None,
) -> typing.Any:
    """
    Deserialize data into an instance of IGZSchema or a primitive type.

    If the data is a primitive type, it will return the data as is or convert it to a datetime object if the schema
    requires it.
    If the data is a list, it will deserialize each item in the list according to the schema.
    If the data is a dict, and the schema is provided or if the dict contains a protobuf Any type,
    it will deserialize the dict into an instance of the schema class. Otherwise, it will return a dict with
    deserialized values.

    Args:
        data (Any): The data to deserialize, which can be a primitive type, list, or dict.
        schema (Type[IGZSchema], optional): The schema class to deserialize the data into. If not provided, it will attempt to infer the schema
            from the data structure or protobuf Any type.

    Returns:
        Any: Deserialized data as an instance of IGZSchema or a primitive type.

    Raises:
        ValueError: If the protobuf Any type format is not recognized or the class cannot be found.
        ImportError: If the module cannot be imported from any supported version of iguazio.schemas.
    """
    if isinstance(data, iguazio.common.constants._Serialization.primitive_types):
        if (
            isinstance(data, str)
            and _is_optional_int_schema(schema)
            and _is_integer_string(data)
        ):
            return int(data)
        if helpers.is_datetime_type(schema) and isinstance(data, str):
            return datetime.datetime.fromisoformat(data)
        if (
            helpers.is_enum_type(schema)
            or schema in iguazio.common.constants._Serialization.primitive_types
        ):
            return schema(data)
        return data
    if isinstance(data, list):
        # If schema is a list type, deserialize each item in the list
        return [deserialize(item, helpers.get_list_type_arg(schema)) for item in data]
    if isinstance(data, dict):
        schema = _unwrap_optional_schema(schema)
        if protobuf_any_type := data.get("@type"):
            schema = _parse_protobuf_any_type(protobuf_any_type)

        if dict_args := helpers.get_dict_type_args(schema):
            value_type = dict_args[1]
            return {key: deserialize(value, value_type) for key, value in data.items()}

        # Plain dict without type arguments
        if not schema or helpers.is_dict_type(schema):
            return {key: deserialize(value) for key, value in data.items()}

        schema_attributes = {}
        for field in dataclasses.fields(schema):
            # Use json_key metadata if present, otherwise camelize the field name
            json_key = field.metadata.get("json_key")
            if json_key:
                lookup_name = json_key
            else:
                lookup_name = inflection.camelize(field.name, False)
            if lookup_name in data:
                schema_attributes[field.name] = deserialize(
                    data[lookup_name], field.type
                )

        return schema(**schema_attributes)


def _parse_protobuf_any_type(
    protobuf_any_type: str,
) -> typing.Type[igz_schema.IGZSchema]:
    """
    Parse a protobuf Any type string and return the corresponding IGZSchema class.

    The protobuf Any type string is expected to be in the format:
    "type.googleapis.com/{module_name}.{class_name}".
    If the format is not recognized, it raises a ValueError.

    Args:
        protobuf_any_type (str): The protobuf Any type string to parse.

    Returns:
        Type[IGZSchema]: The IGZSchema class corresponding to the protobuf Any type.

    Raises:
        ValueError: If the protobuf Any type format is not recognized or the class cannot be found.
        ImportError: If the module cannot be imported from any supported version of iguazio.schemas.
    """
    protobuf_type_regex = r"^type\.googleapis\.com/(.+)\.(.+)$"
    if protobuf_any_type.startswith("type.googleapis.com/"):
        match = re.match(protobuf_type_regex, protobuf_any_type)
        if match:
            module_name, class_name = match.groups()
            resource_module = _import_resource_module(
                inflection.underscore(module_name)
            )
            resource_class = getattr(resource_module, class_name, None)
            if not resource_class:
                raise ValueError(
                    f"Class '{class_name}' not found in module '{module_name}'"
                )
            return resource_class
    else:
        # Handle other formats or raise an error
        raise ValueError(f"Unsupported protobuf Any type format: {protobuf_any_type}")


def _get_protobuf_any_type_string(data: igz_schema.IGZSchema) -> str:
    """
    Generate a protobuf Any type string for the given IGZSchema instance.

    The string is in the format "type.googleapis.com/{module_name}.{class_name}".

    Args:
        data (IGZSchema): The IGZSchema instance for which to generate the protobuf Any type string.

    Returns:
        str: The protobuf Any type string.
    """
    module_name = data.__module__.split(".")[-1]
    class_name = data.__class__.__name__
    return f"type.googleapis.com/{module_name}.{class_name}"


def _import_resource_module(module_name: str) -> typing.Optional[typing.Any]:
    """
    Import the resource module from the supported versions of iguazio.schemas.

    It attempts to import the module in reverse order of supported versions.

    Args:
        module_name (str): The name of the module to import.

    Returns:
        Any: The imported module if found.

    Raises:
        ImportError: If the module cannot be found in any supported version.
    """
    for version in reversed(SUPPORTED_VERSIONS):
        try:
            return importlib.import_module(
                f"iguazio.schemas.{version}.resources.{module_name}"
            )
        except ModuleNotFoundError:
            continue

    raise ImportError(
        f"Module '{module_name}' not found in any version of iguazio.schemas"
    )


def _unwrap_optional_schema(schema: typing.Optional[type]) -> typing.Optional[type]:
    if schema is None:
        return None
    schema_args = typing.get_args(schema)
    if len(schema_args) == 2 and type(None) in schema_args:
        return next(arg for arg in schema_args if arg is not type(None))
    return schema


def _is_optional_int_schema(schema: typing.Optional[type]) -> bool:
    if schema is None:
        return False
    schema_args = typing.get_args(schema)
    return len(schema_args) == 2 and set(schema_args) == {int, type(None)}


def _is_integer_string(value: str) -> bool:
    try:
        int(value)
    except (ValueError, TypeError):
        return False
    return True
