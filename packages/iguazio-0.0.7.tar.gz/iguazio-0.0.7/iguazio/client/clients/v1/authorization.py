# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http
import typing

import httpx

import iguazio.client.clients.base

import iguazio.schemas.serializer
import iguazio.schemas.v1.resources.policy as policy_schema


class AuthorizationClientV1(iguazio.client.clients.base.BaseClient):
    """
    Client for interacting with the Iguazio authorization API v1.

    This client provides methods for managing user authorization, including creating, retrieving,
    listing, searching, updating policies.
    """

    def get_policy(
        self,
        policy_id: str,
        options: typing.Optional[policy_schema.GetPolicyOptions] = None,
    ) -> policy_schema.Policy:
        """
        Retrieve a policy by its ID.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            policy = client.get_policy("policy-id-123")

            # Or with options
            options = iguazio.schemas.GetPolicyOptionsV1(include_members=True)
            policy = client.get_policy("policy-id-123", options)

        Args:
            policy_id (str): The unique identifier of the policy to retrieve.
            options (iguazio.schemas.v1.resources.policy.GetPolicyOptions, optional): Optional parameters for retrieving the policy.

        Returns:
            iguazio.schemas.v1.resources.policy.Policy: A Policy instance containing the policy information.
        """
        serialized_options = options.to_dict() if options else None
        response = self._request(
            "get",
            f"/authorization/policies/{policy_id}",
            params=serialized_options,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(response, policy_schema.Policy)

    def list_policies(
        self, options: typing.Optional[policy_schema.ListPoliciesOptions] = None
    ) -> policy_schema.PolicyList:
        """
        List policies in the Iguazio system.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            policies = client.list_policies()

            # Or with options
            options = iguazio.schemas.ListPoliciesOptionsV1(
                kind="project",
                project="myproject",
                include_members=True,
                format=iguazio.schemas.PolicyListFormat.full,
            )
            policies = client.list_policies(options)

        Args:
            options (iguazio.schemas.v1.resources.policy.ListPoliciesOptions, optional): Options for listing policies.

        Returns:
            iguazio.schemas.v1.resources.policy.PolicyList: A PolicyList containing the list of policies.
        """
        serialized_options = options.to_dict() if options else None
        response = self._request(
            "get",
            "/authorization/policies",
            params=serialized_options,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, policy_schema.PolicyList
        )

    def update_policy_members(
        self, policy_id: str, options: policy_schema.UpdatePolicyMembersOptions
    ) -> None:
        """
        Update the members (users and groups) assigned to a policy in the Iguazio system.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            options = iguazio.schemas.UpdatePolicyMembersOptionsV1(
                users=["user1", "user2"],
                groups=["group-id-1", "group-id-2"]
            )
            client.update_policy_members("policy-id-123", options)

        Args:
            policy_id (str): The unique identifier of the policy whose membership should be updated.
            options (iguazio.schemas.v1.resources.policy.UpdatePolicyMembersOptions): Options for updating policy membership.
        """
        self._request(
            "put",
            f"/authorization/policies/{policy_id}/members",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK, http.HTTPStatus.CREATED],
        )

    def assign_member_mgmt_policies(
        self, member_id: str, options: policy_schema.AssignMemberMgmtPoliciesOptions
    ) -> None:
        """
        Assign management policies to a member (user or group) in the Iguazio system.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            options = iguazio.schemas.AssignMemberMgmtPoliciesOptionsV1(
                policy_ids=["policy-id-1", "policy-id-2"],
                override=True,
            )
            client.assign_member_mgmt_policies(member_id="username", options)

        Args:
            member_id (str): The ID of the member (username or group ID) to whom policies should be assigned.
            options (iguazio.schemas.v1.resources.policy.AssignMemberMgmtPoliciesOptions): Options for assigning management policies to a member.
        """
        self._request(
            "put",
            f"/authorization/members/{member_id}/policies",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK, http.HTTPStatus.CREATED],
        )

    ## PROJECT MEMBERSHIP

    def create_default_project_policies(self, project: str) -> None:
        """
        Create default policies for a project in the Iguazio system.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.create_default_project_policies(project="myproject")

        Args:
            project (str): The name of the project to create default policies for.
        """
        self._request(
            "post",
            "/authorization/projects/policies",
            json={"project": project},
            expected_status_codes=[http.HTTPStatus.CREATED],
        )

    def delete_project_policies(self, project: str) -> None:
        """
        Delete all policies for a project in the Iguazio system.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.delete_project_policies("myproject")

        Args:
            project (str): The name of the project whose policies should be deleted.
        """
        self._request(
            "delete",
            f"/authorization/projects/{project}/policies",
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def update_project_owner(
        self, project: str, options: policy_schema.UpdateProjectOwnerOptions
    ) -> None:
        """
        Update the owner of a project in the Iguazio system.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            options = iguazio.schemas.UpdateProjectOwnerOptionsV1(
                owner="new-project-owner-username"
            )
            client.update_project_owner("myproject", options)

        Args:
            project (str): The name of the project whose owner should be updated.
            options (iguazio.schemas.v1.resources.policy.UpdateProjectOwnerOptions): Options for updating project ownership.
        """
        self._request(
            "put",
            f"/authorization/projects/{project}/owner",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def get_project_policy_assignments(self, project: str) -> policy_schema.PolicyList:
        """
        Retrieve policy assignments for a specific project in the Iguazio system.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            project_policy_assignments = client.get_project_policy_assignments("myproject")

        Args:
            project (str): The name of the project whose policy assignments should be retrieved.

        Returns:
            iguazio.schemas.v1.resources.policy.PolicyList: A PolicyList containing the policy assignments for the project.
        """
        response = self._request(
            "get",
            f"/authorization/projects/{project}/policies",
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, policy_schema.PolicyList
        )

    def get_project_members(self, project: str) -> policy_schema.ProjectMembership:
        """
        Get the members of a project.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            project_members = client.get_project_members("myproject")

        Args:
            project (str): The name of the project whose members should be retrieved.

        Returns:
            iguazio.schemas.v1.resources.policy.ProjectMembership: An object containing the members of the project,
            organized by role.
        """
        policies = self.get_project_policy_assignments(project)
        result = policy_schema.ProjectMembership()
        for policy in policies.items:
            role = policy_schema.ProjectRole.role_for_policy_name(policy.metadata.name)
            if not role:
                continue

            role_members = getattr(result, role.value)
            if policy.status.assigned_members is not None:
                for member in policy.status.assigned_members:
                    if member.kind == policy_schema.MemberKind.USER:
                        role_members.users.append(member.id)
                    elif member.kind == policy_schema.MemberKind.GROUP:
                        role_members.groups.append(member.id)
        return result

    def get_project_role(
        self, member_id: str, project: str
    ) -> typing.Optional[policy_schema.ProjectRole]:
        """
        Get the effective role of a user in a project.
        This method will return the highest priority role that the user has in the project.
        It also considers the user's assigned groups and their roles in the project.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            role = client.get_project_role("username", "myproject")

        Args:
            member_id (str): The ID of the member (username or group ID) to get the role for.
            project (str): The name of the project to get the role for.

        Returns:
            iguazio.schemas.ProjectRole: The role of the user in the project.
        """
        return self._get_member_project_role(
            f"/authorization/projects/{project}/members/{member_id}",
            f"Member {member_id} not found in project {project}",
        )

    def set_member_project_role(
        self,
        member_id: str,
        project: str,
        options: policy_schema.SetMemberProjectRoleOptions,
    ) -> None:
        """
        Set the role of a user in a project.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.set_member_project_role(
                member_id=member_id,
                project=project,
                options=iguazio.schemas.SetMemberProjectRoleOptionsV1(
                    role=iguazio.schemas.ProjectRole.EDITOR,
                    override=False,
                )
            )

        Args:
            member_id (str): The ID of the member (username or group ID) to set the role for.
            project (str): The name of the project to set the role for.
            options (iguazio.schemas.v1.resources.policy.SetMemberProjectRoleOptions): The options for setting the user project role.

        Raises:
            ValueError: If the user already has a role in the project and override is False.
        """
        self._request(
            "put",
            f"/authorization/projects/{project}/members/{member_id}",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def set_project_role_members(
        self,
        project: str,
        role: policy_schema.ProjectRole,
        options: policy_schema.SetProjectRoleMembersOptions,
    ) -> None:
        """
        Set the membership of a project for a specific role.
        If override is True, this method will remove any existing members of the role before setting the new members.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.set_project_role_members(
                project="myproject",
                role=iguazio.schemas.ProjectRole.EDITOR,
                options=iguazio.schemas.SetProjectRoleMembersOptionsV1(
                    members=["user1", "group-id-1"],
                    override=True,
                ),
            )

        Args:
            project (str): The name of the project to set the membership for.
            role (iguazio.schemas.ProjectRole): The role to set the membership for.
            options (iguazio.schemas.v1.resources.policy.SetProjectRoleMembersOptions): The options for setting the project role membership.
        """
        self._request(
            "put",
            f"/authorization/projects/{project}/roles/{role.value}",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def set_project_membership(
        self, project: str, options: policy_schema.SetProjectMembershipOptions
    ) -> None:
        """
        Set the membership of a project for all roles at once.
        If override is True, this method will remove any existing members of the roles before setting the new members.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.set_project_membership(
                project="myproject",
                options=iguazio.schemas.SetProjectMembershipOptionsV1(
                    membership={
                        iguazio.schemas.ProjectRole.ADMIN: ["user1", "group-id-1"],
                        iguazio.schemas.ProjectRole.EDITOR: ["user2", "group-id-2"],
                        iguazio.schemas.ProjectRole.VIEWER: ["user3", "group-id-3"],
                    },
                    override=True,
                ),
            )

        Args:
            project (str): The name of the project to set the membership for.
            options (iguazio.schemas.v1.resources.policy.ProjectMembershipOptions): The options for setting the project membership.
        """
        self._request(
            "put",
            f"/authorization/projects/{project}/roles",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def remove_member_from_project(self, project: str, member_id: str) -> None:
        """
        Removes a member from a project.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.remove_member_from_project("myproject", "member-id")

        Args:
            project (str): The name of the project to remove the member from.
            member_id (str): The ID of the member (username or group ID) to remove from the project.
        """
        self._request(
            "delete",
            f"/authorization/projects/{project}/members/{member_id}",
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def validate_permissions(
        self, options: policy_schema.ValidatePermissionsOptions
    ) -> policy_schema.PermissionValidationResultStatus:
        """
        Validate permissions for a set of actions on resources.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            options = iguazio.schemas.ValidatePermissionsOptionsV1(
                action="read",
                resources=["projects/myproject/data"],
            )
            response = client.validate_permissions(options)

        Args:
            options (iguazio.schemas.v1.resources.policy.ValidatePermissionsOptions): The options for validating permissions.
        Raises:
            httpx.HTTPStatusError: If the request fails.
        """
        response = self._request(
            "post",
            "/authorization/permissions/validate",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        validation_result = iguazio.schemas.serializer.deserialize(
            response, policy_schema.ValidatePermissionsResult
        )
        return validation_result.status

    def trigger_permission_manifest_generation(self) -> None:
        """
        Trigger the generation of the permission manifest.
        Requires admin management permissions.
        """
        self._request(
            "post",
            "/authorization/permission-manifest/generate",
            expected_status_codes=[http.HTTPStatus.ACCEPTED],
        )

    def _get_member_project_role(
        self, url: str, not_found_message: str
    ) -> typing.Optional[policy_schema.ProjectRole]:
        try:
            response = self._request(
                "get",
                url,
                expected_status_codes=[http.HTTPStatus.OK],
            )
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == http.HTTPStatus.NOT_FOUND:
                raise ValueError(not_found_message) from exc
            raise
        role = response.get("role")
        if not role:
            raise ValueError(not_found_message)
        return policy_schema.ProjectRole.from_str(role)
