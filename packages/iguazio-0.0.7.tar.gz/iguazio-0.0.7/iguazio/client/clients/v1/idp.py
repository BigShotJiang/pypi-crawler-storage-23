# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http
import typing

import iguazio.client.clients.base

import iguazio.schemas.serializer
import iguazio.schemas.v1.resources.sso_provider as sso_provider_schema


class IdpClientV1(iguazio.client.clients.base.BaseClient):
    """
    Client for interacting with the Iguazio IDP API v1.
    This client provides methods to manage SSO providers and User Federations.
    """

    def create_sso_provider(
        self, options: sso_provider_schema.CreateSsoProviderOptions
    ) -> sso_provider_schema.SsoProvider:
        """
        Create a new SSO provider.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            options = iguazio.schemas.CreateSsoProviderOptions(
                idp_type=iguazio.schemas.SsoProviderIdpType.okta,
                alias="okta",
                display_name="Okta SSO",
                client_id="your-client-id",
                client_secret="your-client-secret",
                discovery_endpoint="https://your-okta-domain/.well-known/openid-configuration",
            )
            new_sso_provider = client.idp.create_sso_provider(options)

        Args:
            options (iguazio.schemas.v1.resources.sso_provider.CreateSsoProviderOptions): Options for creating the
                SSO provider.

        Returns:
            iguazio.schemas.v1.resources.sso_provider.SsoProvider: The created SSO provider.
        """
        response = self._request(
            "post",
            "/idp/sso-providers",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.CREATED],
        )
        return iguazio.schemas.serializer.deserialize(
            response, sso_provider_schema.SsoProvider
        )

    def get_sso_provider(self, alias: str) -> sso_provider_schema.SsoProvider:
        """
        Retrieve an SSO provider by its alias.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            sso_provider = client.idp.get_sso_provider(alias="okta")

        Args:
            alias (str): The alias of the SSO provider to retrieve.

        Returns:
            iguazio.schemas.v1.resources.sso_provider.SsoProvider: The SSO provider with the specified alias.
        """
        response = self._request(
            "get",
            f"/idp/sso-providers/{alias}",
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, sso_provider_schema.SsoProvider
        )

    def list_sso_providers(
        self,
        options: typing.Optional[sso_provider_schema.ListSsoProvidersOptions] = None,
    ) -> sso_provider_schema.SsoProviderList:
        """
        List all SSO providers.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            sso_providers = client.idp.list_sso_providers()

        Args:
            options (typing.Optional[iguazio.schemas.v1.resources.sso_provider.ListSsoProvidersOptions]):
                Options for filtering the list of SSO providers.

        Returns:
            iguazio.schemas.v1.resources.sso_provider.SsoProviderList: A list of SSO providers.
        """
        response = self._request(
            "get",
            "/idp/sso-providers",
            params=options.to_dict() if options else None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, sso_provider_schema.SsoProviderList
        )

    def update_sso_provider(
        self, alias: str, options: sso_provider_schema.UpdateSsoProviderOptions
    ) -> sso_provider_schema.SsoProvider:
        """
        Update an existing SSO provider.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            options = iguazio.schemas.UpdateSsoProviderOptions(
                display_name="Updated Okta SSO",
                client_id="your-new-client-id",
                client_secret="your-new-client-secret",
            )
            updated_sso_provider = client.idp.update_sso_provider(alias="okta", options=options)

        Args:
            alias (str): The alias of the SSO provider to update.
            options (iguazio.schemas.v1.resources.sso_provider.UpdateSsoProviderOptions): Options for updating the
                SSO provider.

        Returns:
            iguazio.schemas.v1.resources.sso_provider.SsoProvider: The updated SSO provider.
        """
        response = self._request(
            "put",
            f"/idp/sso-providers/{alias}",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, sso_provider_schema.SsoProvider
        )

    def create_sso_provider_email_mapper(self, alias: str) -> None:
        """
        Create an email mapper for an SSO provider.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.idp.create_sso_provider_email_mapper(alias="okta")

        Args:
            alias (str): The alias of the SSO provider for which to create the email mapper.
        """
        self._request(
            "post",
            f"/idp/sso-providers/{alias}/email-mapper",
            expected_status_codes=[http.HTTPStatus.CREATED],
        )

    def delete_sso_provider_email_mapper(self, alias: str) -> None:
        """
        Delete the email mapper for an SSO provider.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.idp.delete_sso_provider_email_mapper(alias="okta")

        Args:
            alias (str): The alias of the SSO provider for which to delete the email mapper.
        """
        self._request(
            "delete",
            f"/idp/sso-providers/{alias}/email-mapper",
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def delete_sso_provider(self, alias: str) -> None:
        """
        Delete an SSO provider by its alias.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.idp.delete_sso_provider(alias="okta")

        Args:
            alias (str): The alias of the SSO provider to delete.
        """
        self._request(
            "delete",
            f"/idp/sso-providers/{alias}",
            expected_status_codes=[http.HTTPStatus.OK],
        )
