# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import http

import iguazio.client.clients.base

import iguazio.schemas.serializer
import iguazio.schemas.v1.resources.user as user_schema
import iguazio.schemas.v1.resources.access_token as access_token_schema


class AuthenticationClientV1(iguazio.client.clients.base.BaseClient):
    """
    Client for interacting with the Iguazio authentication API v1.

    This client provides methods for user authentication.
    """

    def get_self(
        self, format: user_schema.GetSelfFormat = user_schema.GetSelfFormat.minimal
    ) -> user_schema.User:
        """
        Get the authenticated user's information.
        This method retrieves the details of the currently authenticated user.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            user = client.get_self(format=user_schema.GetSelfFormat.full)

        Args:
            format (iguazio.schemas.v1.resources.user.GetSelfFormat, optional): Response format.

        Returns:
            iguazio.schemas.v1.resources.user.User: An instance containing the user's information.
        """
        serialized_options = user_schema.GetSelfOptions(format=format).to_dict()
        response = self._request(
            "get", "/authentication/self", params=serialized_options
        )
        return iguazio.schemas.serializer.deserialize(response, user_schema.User)

    def logout(self) -> None:
        """
        Logout the current user's session.
        This method invalidates the current user's session on the server and clears the local Access Token (which may
        still be valid until its expiration time).
        Note this only works when logging in with `offline_access=False`. If using an offline token, this method won't
        do anything. To revoke offline tokens, use the `revoke_offline_token` method.

        Example usage::
            client = iguazio.Client(api_url="https://api.example.com")
            client.login(offline_access=False)
            client.logout()
        """
        self._request(
            "post",
            "/authentication/logout",
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self._api_client.clear_access_token()

    def refresh_access_token(
        self, options: access_token_schema.RefreshAccessTokenOptions
    ) -> access_token_schema.AccessToken:
        """
        Refresh the access token for the authenticated user.

        This method sends a request to the authentication API to refresh the access token using the provided options.

        Example usage::

            from iguazio.schemas import RefreshAccessTokenOptionsV1

            client = iguazio.Client(api_url="https://api.example.com")
            options = RefreshAccessTokenOptionsV1(refresh_token="my-refresh-token")
            new_token = client.refresh_access_token(options=options)

        Args:
            options (iguazio.schemas.v1.resources.access_token.RefreshAccessTokenOptions): Options containing the
                refresh token.

        Raises:
            ValueError: If the options are missing.

        Returns:
            iguazio.schemas.v1.resources.access_token.AccessToken: An instance containing the refreshed token and its
                metadata, specification, and status.
        """
        if not options:
            raise ValueError("Options must be provided for refreshing access token.")
        if not options.refresh_token:
            raise ValueError("Refresh token must be provided in options.")

        serialized_options = options.to_dict() if options else None
        response = self._request(
            "post",
            "/authentication/refresh-access-token",
            # When refreshing the access token, by definition we do not have an access token or the token is expired,
            # so we do not include it in the request or try to authenticate.
            authentication=False,
            json=serialized_options,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, access_token_schema.AccessToken
        )

    def refresh_access_tokens(
        self, options: access_token_schema.RefreshAccessTokensOptions
    ) -> access_token_schema.AccessTokenList:
        """
        Refresh multiple access tokens.

        Example usage::

            from iguazio.schemas import RefreshAccessTokensOptionsV1

            client = iguazio.Client(api_url="https://api.example.com")
            options = RefreshAccessTokensOptionsV1(refresh_tokens=["token1", "token2"])
            token_list = client.refresh_access_tokens(options=options)

        Args:
            options (iguazio.schemas.v1.resources.access_token.RefreshAccessTokensOptions): Options containing the
                refresh tokens and the mode for handling errors.

        Raises:
            ValueError: If the options or refresh tokens are missing.

        Returns:
            iguazio.schemas.v1.resources.access_token.AccessTokenList: List of access tokens and their statuses.
        """
        if not options:
            raise ValueError("Options must be provided for refreshing access tokens.")
        if not options.refresh_tokens:
            raise ValueError("At least one access token must be provided in options.")
        serialized_options = options.to_dict()
        response = self._request(
            "post",
            "/authentication/refresh-access-tokens",
            # When refreshing the access token, by definition we do not have an access token or the token is expired,
            # so we do not include it in the request or try to authenticate.
            authentication=False,
            json=serialized_options,
            expected_status_codes=[http.HTTPStatus.OK, http.HTTPStatus.MULTI_STATUS],
        )

        return iguazio.schemas.serializer.deserialize(
            response, access_token_schema.AccessTokenList
        )

    def revoke_offline_token(
        self, options: access_token_schema.RevokeOfflineTokenOptions
    ) -> None:
        """
        Revoke an offline token.

        Example usage::

            from iguazio.schemas import RevokeOfflineTokenOptionsV1

            client = iguazio.Client(api_url="https://api.example.com")
            options = RevokeOfflineTokenOptionsV1(token="your-offline-token")
            client.revoke_offline_token(options=options)

        Args:
            options (iguazio.schemas.v1.resources.access_token.RevokeOfflineTokenOptions): Options containing the
                offline token to be revoked.

        Raises:
            ValueError: If the options are missing.
        """
        if not options:
            raise ValueError("Options must be provided for revoking offline token.")
        if not options.token:
            raise ValueError("Token must be provided in options.")
        serialized_options = options.to_dict() if options else None
        self._request(
            "post",
            "/authentication/revoke-offline-token",
            json=serialized_options,
            expected_status_codes=[http.HTTPStatus.OK],
        )
