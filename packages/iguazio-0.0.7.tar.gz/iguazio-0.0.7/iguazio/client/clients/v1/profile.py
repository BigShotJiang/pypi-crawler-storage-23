# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http
import typing

import iguazio.client.clients.base

import iguazio.schemas.serializer
import iguazio.schemas.v1.resources.user as user_schema
import iguazio.schemas.v1.resources.usergroup as group_schema


class ProfileClientV1(iguazio.client.clients.base.BaseClient):
    """
    Client for interacting with the Iguazio profile API v1.

    This client provides methods for managing user profiles, including creating, retrieving,
    listing, searching, updating users and groups.
    """

    def create_user(self, options: user_schema.CreateUserOptions) -> user_schema.User:
        """
        Create a new user in the Iguazio system.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            options = iguazio.schemas.CreateUserOptions(
                username="newuser",
                email="email@example.com",
                first_name="first",
                last_name="Last",
                assignedPolicies=["policy1-id", "policy2-id"],
            )
            new_user = client.create_user(options)

        Args:
            options (iguazio.schemas.v1.resources.user.CreateUserOptions): Options for creating the user.

        Returns:
            iguazio.schemas.v1.resources.user.User: An instance containing the newly created user's information.
        """
        response = self._request(
            "post",
            "/profile/users",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.CREATED],
        )
        return iguazio.schemas.serializer.deserialize(response, user_schema.User)

    def get_user(
        self, username: str, options: typing.Optional[user_schema.GetUserOptions] = None
    ) -> user_schema.User:
        """
        Retrieve a user by their username.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            user = client.get_user("username")

        Args:
            username (str): The username of the user to retrieve.
            options (iguazio.schemas.v1.resources.user.GetUserOptions, optional): Optional parameters for retrieving the user.

        Returns:
            iguazio.schemas.v1.resources.user.User: An instance containing the user's information.
        """
        serialized_options = options.to_dict() if options else None
        response = self._request(
            "get", f"/profile/users/{username}", params=serialized_options
        )
        return iguazio.schemas.serializer.deserialize(response, user_schema.User)

    def list_users(
        self, options: typing.Optional[user_schema.ListUsersOptions] = None
    ) -> user_schema.UserList:
        """
        List all users in the Iguazio system.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            users = client.list_users()

        Args:
            options (iguazio.schemas.v1.resources.user.ListUsersOptions, optional): Optional parameters for listing users.

        Returns:
            iguazio.schemas.v1.resources.user.UserList: An instance containing a list of users.
        """
        serialized_options = options.to_dict() if options else None
        response = self._request("get", "/profile/users", params=serialized_options)
        return iguazio.schemas.serializer.deserialize(response, user_schema.UserList)

    def search_users(
        self, options: user_schema.SearchUsersOptions
    ) -> user_schema.UserList:
        """
        Search for users based on specified criteria.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            search_options = iguazio.schemas.SearchUsersOptions(
                search_term="search_term",
                limit=10,
                offset=0
            )
            users = client.search_users(search_options)

        Args:
            options (iguazio.schemas.v1.resources.user.SearchUsersOptions): Options for searching users.

        Returns:
            iguazio.schemas.v1.resources.user.UserList: An instance containing the search results.
        """
        response = self._request(
            "get", "/profile/search-users", params=options.to_dict()
        )
        return iguazio.schemas.serializer.deserialize(response, user_schema.UserList)

    def update_user(
        self, username: str, options: user_schema.UpdateUserOptions
    ) -> user_schema.User:
        """
        Update an existing user's information.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            update_options = iguazio.schemas.UpdateUserOptions(
                email="new@email.com",
                first_name="NewFirst",
            )
            updated_user = client.update_user("username", update_options)

        Args:
            username (str): The username of the user to update.
            options (iguazio.schemas.v1.resources.user.UpdateUserOptions): Options for updating the user.

        Returns:
            iguazio.schemas.v1.resources.user.User: An instance containing the updated user's information.
        """
        response = self._request(
            "put",
            f"/profile/users/{username}",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(response, user_schema.User)

    def assign_user_groups(
        self, username: str, options: user_schema.AssignUserGroupsOptions
    ) -> None:
        """
        Assign groups to a user.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            assign_options = iguazio.schemas.AssignUserGroupsOptions(
                groups=["group1-id", "group2-id"]
            )
            client.assign_user_groups("username", assign_options)

        Args:
            username (str): The username of the user to assign groups to.
            options (iguazio.schemas.v1.resources.user.AssignUserGroupsOptions): Options for assigning groups.
        """
        self._request(
            "post",
            f"/profile/users/{username}/assign-groups",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def enable_user(self, username: str) -> None:
        """
        Enable a user account.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.enable_user("username")

        Args:
            username (str): The username of the user to enable.
        """
        self._request(
            "post",
            f"/profile/users/{username}/enable",
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def disable_user(self, username: str) -> None:
        """
        Disable a user account.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.disable_user("username")

        Args:
            username (str): The username of the user to disable.
        """
        self._request(
            "post",
            f"/profile/users/{username}/disable",
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def delete_user(self, username: str) -> None:
        """
        Delete a user account.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.delete_user("username")

        Args:
            username (str): The username of the user to delete.
        """
        self._request(
            "delete",
            f"/profile/users/{username}",
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def create_group(
        self, options: group_schema.CreateGroupOptions
    ) -> group_schema.Group:
        """
        Create a new user group in the Iguazio system.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            options = iguazio.schemas.CreateGroupOptions(
                name="newgroup",
            )
            new_group = client.create_group(options)

        Args:
            options (iguazio.schemas.v1.resources.usergroup.CreateGroupOptions): Options for creating the group.

        Returns:
            iguazio.schemas.v1.resources.usergroup.Group: An instance containing the newly created group's information.
        """
        response = self._request(
            "post",
            "/profile/groups",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.CREATED],
        )
        return iguazio.schemas.serializer.deserialize(response, group_schema.Group)

    def get_group(
        self,
        group_id: str,
        options: typing.Optional[group_schema.GetGroupOptions] = None,
    ) -> group_schema.Group:
        """
        Retrieve a user group by its ID.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            group = client.get_group("group-id")

        Args:
            group_id (str): The ID of the group to retrieve.
            options (iguazio.schemas.v1.resources.usergroup.GetGroupOptions, optional): Optional parameters for retrieving the group.

        Returns:
            iguazio.schemas.v1.resources.usergroup.Group: An instance containing the group's information.
        """
        serialized_options = options.to_dict() if options else None
        response = self._request(
            "get", f"/profile/groups/{group_id}", params=serialized_options
        )
        return iguazio.schemas.serializer.deserialize(response, group_schema.Group)

    def list_groups(
        self, options: typing.Optional[group_schema.ListGroupsOptions] = None
    ) -> group_schema.GroupList:
        """
        List all user groups in the Iguazio system.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            groups = client.list_groups()

        Args:
            options (iguazio.schemas.v1.resources.usergroup.ListGroupsOptions, optional): Optional parameters for listing groups.

        Returns:
            iguazio.schemas.v1.resources.usergroup.GroupList: An instance containing a list of groups.
        """
        serialized_options = options.to_dict() if options else None
        response = self._request("get", "/profile/groups", params=serialized_options)
        return iguazio.schemas.serializer.deserialize(response, group_schema.GroupList)

    def search_groups(
        self, options: group_schema.SearchGroupsOptions
    ) -> group_schema.GroupList:
        """
        Search for user groups based on specified criteria.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            search_options = iguazio.schemas.SearchGroupsOptions(
                search_term="search_term",
                limit=10,
                offset=0
            )
            groups = client.search_groups(search_options)

        Args:
            options (iguazio.schemas.v1.resources.usergroup.SearchGroupsOptions): Options for searching groups.

        Returns:
            iguazio.schemas.v1.resources.usergroup.GroupList: An instance containing the search results.
        """
        response = self._request(
            "get", "/profile/search-groups", params=options.to_dict()
        )
        return iguazio.schemas.serializer.deserialize(response, group_schema.GroupList)

    def rename_group(
        self, group_id: str, options: group_schema.RenameGroupOptions
    ) -> group_schema.Group:
        """
        Rename an existing user group.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            rename_options = iguazio.schemas.RenameGroupOptions(
                new_name="new-group-name"
            )
            updated_group = client.rename_group("group-id", rename_options)

        Args:
            group_id (str): The ID of the group to rename.
            options (iguazio.schemas.v1.resources.usergroup.RenameGroupOptions): Options for renaming the group.

        Returns:
            iguazio.schemas.v1.resources.usergroup.Group: An instance containing the updated group's information.
        """
        response = self._request(
            "put",
            f"/profile/groups/{group_id}/rename",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(response, group_schema.Group)

    def move_group(
        self, group_id: str, options: group_schema.MoveGroupOptions
    ) -> group_schema.Group:
        """
        Move a user group to a different parent group.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            move_options = iguazio.schemas.MoveGroupOptions(
                new_parent_id="new-parent-group-id"
            )
            moved_group = client.move_group("group-id", move_options)

        Args:
            group_id (str): The ID of the group to move.
            options (iguazio.schemas.v1.resources.usergroup.MoveGroupOptions): Options for moving the group.

        Returns:
            iguazio.schemas.v1.resources.usergroup.Group: An instance containing the moved group's information.
        """
        response = self._request(
            "put",
            f"/profile/groups/{group_id}/move",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(response, group_schema.Group)

    def assign_group_members(
        self, group_id: str, options: group_schema.AssignGroupMembersOptions
    ) -> None:
        """
        Assign members to a user group.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            assign_options = iguazio.schemas.AssignGroupMembersOptions(
                usernames=["username1", "username2"]
            )
            client.assign_group_members("group-id", assign_options)

        Args:
            group_id (str): The ID of the group to assign members to.
            options (iguazio.schemas.v1.resources.usergroup.AssignGroupMembersOptions): Options for assigning members.
        """
        self._request(
            "post",
            f"/profile/groups/{group_id}/assign-members",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def search_users_metadata(
        self, options: user_schema.SearchUsersMetadataOptions = None
    ) -> typing.Optional[user_schema.UserMetadataInfoList]:
        """
        Search for user metadata based on specified criteria.
        Returns lightweight user information (username, email, first name, last name) for active users only.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            search_options = iguazio.schemas.SearchUsersMetadataOptions(
                search_term="search_term",
                limit=10,
                offset=0
            )
            users_metadata = client.search_users_metadata(search_options)

        Args:
            options (iguazio.schemas.v1.resources.user.SearchUsersMetadataOptions): Options for searching user metadata.

        Returns:
            iguazio.schemas.v1.resources.user.UserMetadataInfoList: An instance containing the search results.
        """
        serialized_options = options.to_dict() if options else None
        response = self._request(
            "get", "/profile/search-users-metadata", params=serialized_options
        )
        return iguazio.schemas.serializer.deserialize(
            response, user_schema.UserMetadataInfoList
        )

    def search_groups_metadata(
        self, options: group_schema.SearchGroupsMetadataOptions = None
    ) -> typing.Optional[group_schema.GroupMetadataInfoList]:
        """
        Search for group metadata based on specified criteria.
        Returns lightweight group information (group ID and name).

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            search_options = iguazio.schemas.SearchGroupsMetadataOptions(
                search_term="search_term",
                limit=10,
                offset=0
            )
            groups_metadata = client.search_groups_metadata(search_options)

        Args:
            options (iguazio.schemas.v1.resources.usergroup.SearchGroupsMetadataOptions): Options for searching group metadata.

        Returns:
            iguazio.schemas.v1.resources.usergroup.GroupMetadataInfoList: An instance containing the search results.
        """
        serialized_options = options.to_dict() if options else None
        response = self._request(
            "get", "/profile/search-groups-metadata", params=serialized_options
        )
        return iguazio.schemas.serializer.deserialize(
            response, group_schema.GroupMetadataInfoList
        )

    def delete_group(self, group_id: str) -> None:
        """
        Delete a user group.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            client.delete_group("group-id")

        Args:
            group_id (str): The ID of the group to delete.
        """
        self._request(
            "delete",
            f"/profile/groups/{group_id}",
            expected_status_codes=[http.HTTPStatus.OK],
        )
