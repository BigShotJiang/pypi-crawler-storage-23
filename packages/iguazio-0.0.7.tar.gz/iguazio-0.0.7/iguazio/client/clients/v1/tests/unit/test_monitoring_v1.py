# Copyright 2026 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http
import unittest
from unittest.mock import MagicMock

import iguazio.client.clients.v1.monitoring as monitoring_client
import iguazio.schemas.v1.resources.service_health as service_health_schema


class TestMonitoringClientV1(unittest.TestCase):
    def setUp(self):
        self.mock_api_client = MagicMock()
        self.client = monitoring_client.MonitoringClientV1(self.mock_api_client)

    def test_check_health(self):
        mock_response = {
            "items": [
                {
                    "spec": {
                        "name": "mlrun",
                        "group": "core",
                        "resource": "mlrun-api-chief",
                        "resourceKind": "Deployment",
                    },
                    "status": {
                        "statusCode": 200,
                        "state": "ready",
                        "lastChecked": "2026-01-15T10:30:00Z",
                    },
                },
            ],
            "status": {
                "ctx": "test-context-id",
                "statusCode": 200,
            },
        }
        self.mock_api_client.request.return_value = mock_response

        response = self.client.check_health()
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/monitoring/health",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertIsInstance(response, service_health_schema.ServiceHealthList)
        self.assertEqual(response.status.status_code, 200)
        self.assertEqual(response.status.ctx, "test-context-id")

        self.assertEqual(len(response.items), 1)
        service = response.items[0]
        self.assertEqual(service.spec.name, "mlrun")
        self.assertEqual(service.spec.group, "core")
        self.assertEqual(service.spec.resource, "mlrun-api-chief")
        self.assertEqual(service.spec.resource_kind, "Deployment")
        self.assertEqual(service.status.state, service_health_schema.ServiceState.ready)
        self.assertIsNotNone(service.status.last_checked)

    def test_check_health_multiple_services(self):
        mock_response = {
            "items": [
                {
                    "spec": {
                        "name": "orca",
                        "group": "infra",
                        "resource": "orca-api",
                        "resourceKind": "Deployment",
                    },
                    "status": {
                        "statusCode": 200,
                        "state": "ready",
                        "lastChecked": "2026-01-15T10:30:00Z",
                    },
                },
                {
                    "spec": {
                        "name": "mlrun",
                        "group": "core",
                        "resource": "mlrun-api-chief",
                        "resourceKind": "Deployment",
                    },
                    "status": {
                        "statusCode": 200,
                        "state": "unhealthy",
                        "lastChecked": "2026-01-15T10:30:00Z",
                        "errorDescription": "Pod CrashLoopBackOff",
                    },
                },
                {
                    "spec": {
                        "name": "jupyter",
                        "group": "app",
                    },
                    "status": {
                        "statusCode": 200,
                        "state": "unknown",
                    },
                },
            ],
            "status": {
                "statusCode": 200,
            },
        }
        self.mock_api_client.request.return_value = mock_response

        response = self.client.check_health()

        self.assertEqual(len(response.items), 3)

        orca = response.items[0]
        self.assertEqual(orca.spec.name, "orca")
        self.assertEqual(orca.spec.group, "infra")
        self.assertEqual(orca.status.state, service_health_schema.ServiceState.ready)

        mlrun = response.items[1]
        self.assertEqual(mlrun.spec.name, "mlrun")
        self.assertEqual(mlrun.spec.group, "core")
        self.assertEqual(
            mlrun.status.state, service_health_schema.ServiceState.unhealthy
        )
        self.assertEqual(mlrun.status.error_description, "Pod CrashLoopBackOff")

        jupyter = response.items[2]
        self.assertEqual(jupyter.spec.name, "jupyter")
        self.assertEqual(jupyter.spec.group, "app")
        self.assertEqual(
            jupyter.status.state, service_health_schema.ServiceState.unknown
        )
        self.assertIsNone(jupyter.spec.resource)
        self.assertIsNone(jupyter.spec.resource_kind)

    def test_check_health_unhealthy_service(self):
        mock_response = {
            "items": [
                {
                    "spec": {
                        "name": "nuclio",
                        "group": "core",
                        "resource": "nuclio-dashboard",
                        "resourceKind": "Deployment",
                    },
                    "status": {
                        "statusCode": 200,
                        "state": "unhealthy",
                        "lastChecked": "2026-01-15T10:30:00Z",
                        "errorDescription": "0/1 replicas available",
                    },
                },
            ],
            "status": {
                "statusCode": 200,
            },
        }
        self.mock_api_client.request.return_value = mock_response

        response = self.client.check_health()

        self.assertEqual(len(response.items), 1)
        service = response.items[0]
        self.assertEqual(
            service.status.state, service_health_schema.ServiceState.unhealthy
        )
        self.assertEqual(service.status.error_description, "0/1 replicas available")

    def test_check_health_empty_response(self):
        mock_response = {
            "items": [],
            "status": {
                "statusCode": 200,
            },
        }
        self.mock_api_client.request.return_value = mock_response

        response = self.client.check_health()
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/monitoring/health",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertIsInstance(response, service_health_schema.ServiceHealthList)
        self.assertEqual(len(response.items), 0)
        self.assertIsNotNone(response.status)
