# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http
import os
import tempfile
import unittest
from unittest.mock import MagicMock

import httpx

import iguazio.client.clients.v1.logs as logs_client
import iguazio.schemas.v1.resources.logs as logs_schema


class TestLogsClientV1(unittest.TestCase):
    def setUp(self):
        self.mock_api_client = MagicMock()
        self.client = logs_client.LogsClientV1(self.mock_api_client)

    def test_download_log_bundle_to_file_empty_bundle_id_raises(self):
        """Test that empty bundle_id raises ValueError."""
        with self.assertRaises(ValueError) as ctx:
            self.client.download_log_bundle_to_file("")
        self.assertIn("non-empty", str(ctx.exception))

        with self.assertRaises(ValueError) as ctx:
            self.client.download_log_bundle_to_file("   ")
        self.assertIn("non-empty", str(ctx.exception))

        self.mock_api_client.request.assert_not_called()

    def test_download_log_bundle_to_file(self):
        """Test downloading a log bundle writes to log-bundle-{id}.tar.gz and returns path."""
        bundle_id = "my-bundle-123"
        content = b"data"
        mock_response = MagicMock()
        mock_response.iter_bytes.return_value = iter([content])
        mock_response.close = MagicMock()
        self.mock_api_client.request.return_value = mock_response

        with tempfile.TemporaryDirectory() as tmpdir:
            prev_cwd = os.getcwd()
            try:
                os.chdir(tmpdir)
                path = self.client.download_log_bundle_to_file(bundle_id)
                # Use realpath to handle symlinks on macOS (/private/var vs /var)
                expected_path = os.path.realpath(
                    os.path.join(tmpdir, f"log-bundle-{bundle_id}.tar.gz")
                )
                self.assertEqual(os.path.realpath(path), expected_path)
                self.assertTrue(os.path.isfile(path))
                with open(path, "rb") as f:
                    self.assertEqual(f.read(), content)
            finally:
                os.chdir(prev_cwd)
        mock_response.close.assert_called_once()

    def test_download_log_bundle_to_file_with_path(self):
        """Test downloading with custom path returns that path."""
        bundle_id = "bundle-456"
        content = b"archive-data"
        mock_response = MagicMock()
        mock_response.iter_bytes.return_value = iter([content])
        mock_response.close = MagicMock()
        self.mock_api_client.request.return_value = mock_response

        with tempfile.NamedTemporaryFile(delete=False, suffix=".tar.gz") as f:
            custom_path = f.name
        self.addCleanup(lambda: os.remove(custom_path))

        path = self.client.download_log_bundle_to_file(bundle_id, custom_path)
        self.assertEqual(path, os.path.abspath(custom_path))
        with open(custom_path, "rb") as f:
            self.assertEqual(f.read(), content)
        mock_response.close.assert_called_once()

    def test_download_log_bundle_to_file_404_raises_with_custom_message(self):
        """Test that 404 raises HTTPStatusError with custom 'Log bundle not found' message."""
        bundle_id = "missing-bundle-id"
        mock_request = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = http.HTTPStatus.NOT_FOUND
        self.mock_api_client.request.side_effect = httpx.HTTPStatusError(
            "Not Found", request=mock_request, response=mock_response
        )

        with self.assertRaises(httpx.HTTPStatusError) as ctx:
            self.client.download_log_bundle_to_file(bundle_id)

        exc = ctx.exception
        self.assertIn("Log bundle not found", str(exc))
        self.assertIn(bundle_id, str(exc))
        self.assertIn("Check the bundle ID exists and is completed", str(exc))
        self.assertIs(exc.response, mock_response)

    def test_download_log_bundle_to_file_403_raises_with_custom_message(self):
        """Test that 403 raises HTTPStatusError with custom 'Permission denied' message."""
        bundle_id = "forbidden-bundle-id"
        mock_request = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = http.HTTPStatus.FORBIDDEN
        self.mock_api_client.request.side_effect = httpx.HTTPStatusError(
            "Forbidden", request=mock_request, response=mock_response
        )

        with self.assertRaises(httpx.HTTPStatusError) as ctx:
            self.client.download_log_bundle_to_file(bundle_id)

        exc = ctx.exception
        self.assertIn("Permission denied", str(exc))
        self.assertIn(bundle_id, str(exc))
        self.assertIs(exc.response, mock_response)

    def test_download_log_bundle_to_file_write_failure_raises_and_closes_response(self):
        """Test that write failure raises OSError with wrapped message and closes the stream."""
        bundle_id = "some-bundle-id"
        mock_response = MagicMock()
        mock_response.iter_bytes.return_value = iter([b"chunk"])
        mock_response.close = MagicMock()
        self.mock_api_client.request.return_value = mock_response

        # Pass a directory path so open(..., "wb") raises OSError (IsADirectoryError)
        with tempfile.TemporaryDirectory() as tmpdir:
            with self.assertRaises(OSError) as ctx:
                self.client.download_log_bundle_to_file(bundle_id, path=tmpdir)

            exc = ctx.exception
            self.assertIn("Failed to write log bundle to", str(exc))
            self.assertIn(tmpdir, str(exc))

        mock_response.close.assert_called_once()

    def test_list_log_bundles_default_params(self):
        """Test listing log bundles with default parameters omits pagination so backend defaults apply."""
        mock_response = {"items": [], "status": {}}
        self.mock_api_client.request.return_value = mock_response

        result = self.client.list_log_bundles()

        call_args = self.mock_api_client.request.call_args
        self.assertEqual(call_args[0], ("get", "/logs/bundles"))
        params = call_args[1].get("params", {})
        self.assertNotIn(
            "offset", params, "offset should be omitted to use backend default"
        )
        self.assertNotIn(
            "limit", params, "limit should be omitted to use backend default (100)"
        )
        self.assertIsNotNone(result)

    def test_list_log_bundles_with_filters(self):
        """Test listing log bundles with state and since filters."""
        from datetime import datetime, timezone

        # Mock response should match protobuf structure
        mock_response = {
            "items": [
                {
                    "metadata": {"base": {"id": "bundle-1"}},
                    "spec": {"base": {}, "triggeredBy": "user_action"},
                    "status": {"base": {}, "state": "completed"},
                }
            ],
            "status": {"base": {}},
        }
        self.mock_api_client.request.return_value = mock_response

        options = logs_schema.ListLogBundlesOptions(
            offset=10,
            limit=50,
            state=logs_schema.BundleState.completed,
            since=datetime(2024, 1, 1, tzinfo=timezone.utc),
        )
        result = self.client.list_log_bundles(options)

        # Verify request was called
        call_args = self.mock_api_client.request.call_args
        self.assertEqual(call_args[0], ("get", "/logs/bundles"))
        self.assertIsNotNone(result)
        self.assertEqual(len(result.items), 1)
        self.assertEqual(
            result.items[0].status.state, logs_schema.BundleState.completed
        )

    def test_list_log_bundles_with_pagination(self):
        """Test listing log bundles with pagination parameters."""
        mock_response = {"items": [], "status": {}}
        self.mock_api_client.request.return_value = mock_response

        options = logs_schema.ListLogBundlesOptions(offset=20, limit=10)
        result = self.client.list_log_bundles(options)

        # Verify request was called
        call_args = self.mock_api_client.request.call_args
        self.assertEqual(call_args[0], ("get", "/logs/bundles"))
        self.assertIsNotNone(result)

    def test_get_log_bundle_success(self):
        """Test getting a log bundle by ID."""
        bundle_id = "my-bundle-123"
        # Mock response should match protobuf structure
        mock_response = {
            "metadata": {"base": {"id": bundle_id}},
            "spec": {"base": {}, "triggeredBy": "user_action"},
            "status": {"base": {}, "state": "completed"},
        }
        self.mock_api_client.request.return_value = mock_response

        options = logs_schema.GetLogBundleOptions(id=bundle_id)
        result = self.client.get_log_bundle(options)

        self.mock_api_client.request.assert_called_once()
        call_args = self.mock_api_client.request.call_args
        self.assertEqual(call_args[0][0], "get")
        self.assertIn(bundle_id, call_args[0][1])
        self.assertIsNotNone(result)
        self.assertEqual(result.status.state, logs_schema.BundleState.completed)

    def test_get_log_bundle_404_raises(self):
        """Test that 404 raises HTTPStatusError."""
        bundle_id = "missing-bundle"
        mock_request = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = http.HTTPStatus.NOT_FOUND
        self.mock_api_client.request.side_effect = httpx.HTTPStatusError(
            "Not Found", request=mock_request, response=mock_response
        )

        options = logs_schema.GetLogBundleOptions(id=bundle_id)
        with self.assertRaises(httpx.HTTPStatusError):
            self.client.get_log_bundle(options)
