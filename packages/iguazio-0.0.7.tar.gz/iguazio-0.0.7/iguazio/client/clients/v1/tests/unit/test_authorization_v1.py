# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http
import unittest
from unittest.mock import MagicMock

import iguazio.client.clients.v1.authorization as authorization_client
import iguazio.schemas.v1.resources.policy as policy_schema
import iguazio.schemas.serializer as serializer


class TestAuthorizationClientV1(unittest.TestCase):
    def setUp(self):
        self.mock_api_client = MagicMock()
        self.client = authorization_client.AuthorizationClientV1(self.mock_api_client)

    def test_get_policy(self):
        policy_id = "policy-id-123"
        mock_response = {
            "metadata": {"id": policy_id, "name": "test-policy"},
            "spec": {"kind": "project", "displayName": "Test Policy", "version": 1},
            "status": {"assignedUsers": ["user1"], "assignedGroups": ["group1"]},
        }
        self.mock_api_client.request.return_value = mock_response

        policy = self.client.get_policy(policy_id)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            f"/authorization/policies/{policy_id}",
            version="v1",
            authentication=True,
            params=None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(policy.metadata.id, policy_id)
        self.assertEqual(policy.metadata.name, "test-policy")
        self.assertEqual(policy.spec.kind, "project")

    def test_get_policy_with_options(self):
        policy_id = "policy-id-123"
        mock_response = {
            "metadata": {"id": policy_id, "name": "test-policy"},
            "spec": {"kind": "project", "displayName": "Test Policy", "version": 1},
            "status": {"assignedUsers": ["user1"], "assignedGroups": ["group1"]},
        }
        self.mock_api_client.request.return_value = mock_response

        options = policy_schema.GetPolicyOptions(include_members=True)
        policy = self.client.get_policy(policy_id, options)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            f"/authorization/policies/{policy_id}",
            version="v1",
            authentication=True,
            params=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(policy.metadata.name, "test-policy")

    def test_list_policies(self):
        mock_response = {
            "items": [
                {
                    "metadata": {"id": "pid1", "name": "policy1"},
                    "spec": {
                        "kind": "project",
                        "displayName": "Policy 1",
                        "version": 1,
                    },
                    "status": {"assignedUsers": [], "assignedGroups": []},
                },
                {
                    "metadata": {"id": "pid2", "name": "policy2"},
                    "spec": {"kind": "mgmt", "displayName": "Policy 2", "version": 1},
                    "status": {"assignedUsers": ["user1"], "assignedGroups": []},
                },
            ],
            "status": {"total": 2},
        }
        self.mock_api_client.request.return_value = mock_response

        policy_list = self.client.list_policies()
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/authorization/policies",
            version="v1",
            authentication=True,
            params=None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(len(policy_list.items), 2)
        self.assertEqual(policy_list.items[0].metadata.name, "policy1")
        self.assertEqual(policy_list.items[1].spec.kind, "mgmt")
        self.assertEqual(policy_list.status.total, 2)

    def test_list_policies_with_options(self):
        options = policy_schema.ListPoliciesOptions(
            kind="project",
            include_members=True,
            format=policy_schema.PolicyListFormat.full,
        )
        mock_response = {
            "items": [
                {
                    "metadata": {"id": "pid1", "name": "project-policy"},
                    "spec": {
                        "kind": "project",
                        "displayName": "Project Policy",
                        "version": 1,
                    },
                    "status": {
                        "assignedUsers": ["user1"],
                        "assignedGroups": ["group1"],
                    },
                }
            ],
            "status": {"total": 1},
        }
        self.mock_api_client.request.return_value = mock_response

        policy_list = self.client.list_policies(options)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/authorization/policies",
            version="v1",
            authentication=True,
            params=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(len(policy_list.items), 1)
        self.assertEqual(policy_list.items[0].spec.kind, "project")

    def test_create_default_project_policies(self):
        project = "test-project"

        self.client.create_default_project_policies(project)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            "/authorization/projects/policies",
            version="v1",
            authentication=True,
            json={"project": project},
            expected_status_codes=[http.HTTPStatus.CREATED],
        )

    def test_delete_project_policies(self):
        project = "test-project"

        self.client.delete_project_policies(project)
        self.mock_api_client.request.assert_called_once_with(
            "delete",
            f"/authorization/projects/{project}/policies",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def test_update_project_owner(self):
        project = "test-project"
        options = policy_schema.UpdateProjectOwnerOptions(owner="new-owner")

        self.client.update_project_owner(project, options)
        self.mock_api_client.request.assert_called_once_with(
            "put",
            f"/authorization/projects/{project}/owner",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def test_update_policy_members(self):
        policy_id = "policy-id-123"
        options = policy_schema.UpdatePolicyMembersOptions(
            members=["user1", "user2", "group1", "group2"]
        )

        self.client.update_policy_members(policy_id, options)
        self.mock_api_client.request.assert_called_once_with(
            "put",
            f"/authorization/policies/{policy_id}/members",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK, http.HTTPStatus.CREATED],
        )

    def test_assign_member_mgmt_policies(self):
        member_id = "test-user"
        options = policy_schema.AssignMemberMgmtPoliciesOptions(
            policy_ids=["policy1", "policy2"]
        )

        self.client.assign_member_mgmt_policies(member_id, options)
        self.mock_api_client.request.assert_called_once_with(
            "put",
            f"/authorization/members/{member_id}/policies",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK, http.HTTPStatus.CREATED],
        )

    def test_get_project_policy_assignments(self):
        project = "test-project"
        mock_response = {
            "items": [
                {
                    "metadata": {"id": "pid1", "name": "project-admin-policy"},
                    "spec": {
                        "kind": "project",
                        "displayName": "Project Admin",
                        "projectName": project,
                        "version": 1,
                    },
                    "status": {"assignedMembers": [{"id": "admin", "kind": "user"}]},
                }
            ],
            "status": {"total": 1},
        }
        self.mock_api_client.request.return_value = mock_response

        policy_assignments = self.client.get_project_policy_assignments(project)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            f"/authorization/projects/{project}/policies",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(len(policy_assignments.items), 1)
        self.assertEqual(policy_assignments.items[0].spec.project_name, project)
        self.assertIn(
            "admin", policy_assignments.items[0].status.assigned_members[0].id
        )
        self.assertEqual(
            policy_assignments.items[0].status.assigned_members[0].kind,
            policy_schema.MemberKind.USER,
        )

    def test_get_project_members(self):
        project = "test-project"
        mock_response = {
            "items": [
                {
                    "metadata": {"id": "pid1", "name": "igz-project-admin"},
                    "spec": {
                        "kind": "project",
                        "displayName": "Admin",
                        "projectName": project,
                        "version": 1,
                    },
                    "status": {"assignedMembers": [{"id": "admin", "kind": "user"}]},
                }
            ],
            "status": {"total": 1},
        }
        self.mock_api_client.request.return_value = mock_response

        project_members = self.client.get_project_members(project)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            f"/authorization/projects/{project}/policies",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(len(project_members), 1)
        self.assertEqual(project_members.admin.users, ["admin"])

    def test_get_project_role(self):
        project = "test-project"
        member_id = "test-user"
        mock_response = {
            "project": project,
            "member_id": member_id,
            "role": "admin",
        }
        self.mock_api_client.request.return_value = mock_response
        role = self.client.get_project_role(member_id, project)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            f"/authorization/projects/{project}/members/{member_id}",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(role, policy_schema.ProjectRole.ADMIN)

    def test_set_member_project_role(self):
        project = "test-project"
        member_id = "test-user"
        options = policy_schema.SetMemberProjectRoleOptions(
            role=policy_schema.ProjectRole.ADMIN, override=True
        )
        self.client.set_member_project_role(member_id, project, options)
        self.mock_api_client.request.assert_called_once_with(
            "put",
            f"/authorization/projects/{project}/members/{member_id}",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def test_set_project_role_members(self):
        project = "test-project"
        role = policy_schema.ProjectRole.ADMIN
        options = policy_schema.SetProjectRoleMembersOptions(
            members=["test-user", "test-group"],
            override=True,
        )
        self.client.set_project_role_members(project, role, options)
        self.mock_api_client.request.assert_called_once_with(
            "put",
            f"/authorization/projects/{project}/roles/{role.value}",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def test_set_project_membership(self):
        project = "test-project"
        options = policy_schema.SetProjectMembershipOptions(override=True)
        options.membership[policy_schema.ProjectRole.ADMIN] = [
            "test-user-1",
            "test-group-id-1",
        ]
        options.membership[policy_schema.ProjectRole.EDITOR] = [
            "test-user-2",
            "test-group-id-2",
        ]

        self.client.set_project_membership(project, options)
        self.mock_api_client.request.assert_called_once_with(
            "put",
            f"/authorization/projects/{project}/roles",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )

        expected_membership = {
            "admin": {"values": ["test-user-1", "test-group-id-1"]},
            "editor": {"values": ["test-user-2", "test-group-id-2"]},
        }
        self.assertEqual(options.to_dict()["membership"], expected_membership)
        self.assertEqual(options.to_dict()["override"], True)

    def test_remove_member_from_project(self):
        project = "test-project"
        member_id = "test-user"
        self.client.remove_member_from_project(project, member_id)
        self.mock_api_client.request.assert_called_once_with(
            "delete",
            f"/authorization/projects/{project}/members/{member_id}",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def test_trigger_permission_manifest_generation(self):
        mock_response = {
            "status": {
                "ctx": "2e0c7fd3-41b0-4984-9994-5d9dbdaebc2c",
                "statusCode": 202,
            }
        }
        self.mock_api_client.request.return_value = mock_response
        self.client.trigger_permission_manifest_generation()
        self.mock_api_client.request.assert_called_once_with(
            "post",
            "/authorization/permission-manifest/generate",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.ACCEPTED],
        )
        self.assertEqual(
            self.mock_api_client.request.return_value["status"]["ctx"],
            "2e0c7fd3-41b0-4984-9994-5d9dbdaebc2c",
        )
        self.assertEqual(
            self.mock_api_client.request.return_value["status"]["statusCode"], 202
        )

    def test_deserialize_policy(self):
        mock_response = {
            "metadata": {
                "id": "feeaae02-4b35-4405-9a0e-560f7095ea04",
                "name": "igz-project-admin",
            },
            "spec": {
                "displayName": "Admin",
                "kind": "project",
                "permissions": {
                    "/mgmt/projects/new-project/policies/assignments": {
                        "actions": ["read", "list", "update"]
                    },
                    "/resources/projects/new-project": {"actions": [".*"]},
                    "/resources/projects/new-project/**": {"actions": [".*"]},
                },
                "projectName": "new-project",
                "version": 1,
            },
            "status": {
                "ctx": "2e0c7fd3-41b0-4984-9994-5d9dbdaebc2c",
                "statusCode": 200,
            },
        }
        policy = serializer.deserialize(mock_response, policy_schema.Policy)
        self.assertEqual(policy.metadata.id, "feeaae02-4b35-4405-9a0e-560f7095ea04")
        self.assertEqual(policy.metadata.name, "igz-project-admin")
        self.assertEqual(policy.spec.kind, "project")
        self.assertEqual(policy.spec.display_name, "Admin")
        self.assertEqual(policy.spec.version, 1)
        self.assertEqual(policy.status.ctx, "2e0c7fd3-41b0-4984-9994-5d9dbdaebc2c")
        self.assertEqual(policy.status.status_code, 200)

    def test_serialize_options(self):
        options = policy_schema.ListPoliciesOptions(
            kind="project",
            include_members=True,
            format=policy_schema.PolicyListFormat.full,
        )
        serialized_options = serializer.serialize(options)
        expected_options = {
            "kind": "project",
            "includeMembers": True,
            "format": 1,
            "offset": 0,
            "limit": 10,
        }
        self.assertEqual(serialized_options, expected_options)

    def test_validate_permissions_allowed(self):
        options = policy_schema.ValidatePermissionsOptions(
            action="read",
            resources=["projects/myproject/data"],
        )
        mock_response = {
            "metadata": {"id": "validation-id"},
            "spec": {},
            "status": {
                "allowed": True,
                "reason": "User has read permission on the resource",
            },
        }
        self.mock_api_client.request.return_value = mock_response

        result = self.client.validate_permissions(options)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            "/authorization/permissions/validate",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertIsInstance(result, policy_schema.PermissionValidationResultStatus)
        self.assertTrue(result.allowed)
        self.assertEqual(result.reason, "User has read permission on the resource")

    def test_validate_permissions_denied(self):
        options = policy_schema.ValidatePermissionsOptions(
            action="delete",
            resources=["projects/myproject/data"],
        )
        mock_response = {
            "metadata": {"id": "validation-id"},
            "spec": {},
            "status": {
                "allowed": False,
                "reason": "User does not have delete permission on the resource",
            },
        }
        self.mock_api_client.request.return_value = mock_response

        result = self.client.validate_permissions(options)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            "/authorization/permissions/validate",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertIsInstance(result, policy_schema.PermissionValidationResultStatus)
        self.assertFalse(result.allowed)
        self.assertEqual(
            result.reason, "User does not have delete permission on the resource"
        )
