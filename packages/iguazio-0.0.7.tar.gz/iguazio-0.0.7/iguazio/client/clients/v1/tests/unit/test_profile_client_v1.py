# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http
import unittest
from unittest.mock import MagicMock

import iguazio.client.clients.v1.profile as profile_client
import iguazio.schemas.v1.resources.user as user_schema
import iguazio.schemas.v1.resources.usergroup as group_schema


class TestProfileClientV1(unittest.TestCase):
    def setUp(self):
        self.mock_api_client = MagicMock()
        self.client = profile_client.ProfileClientV1(self.mock_api_client)

    def test_create_user(self):
        options = user_schema.CreateUserOptions(
            username="testuser",
            email="test@user.com",
            first_name="Test",
            last_name="User",
        )
        mock_response = {
            "metadata": {"id": "id1", "username": "testuser"},
            "spec": {"email": "test@user.com", "firstName": "Test", "lastName": "User"},
            "status": {"active": True},
        }
        self.mock_api_client.request.return_value = mock_response

        user = self.client.create_user(options)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            "/profile/users",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.CREATED],
        )
        self.assertEqual(user.metadata.username, "testuser")
        self.assertEqual(user.spec.email, "test@user.com")
        self.assertTrue(user.status.active)

    def test_create_user_with_password(self):
        options = user_schema.CreateUserOptions(
            username="testuser",
            email="test@user.com",
            first_name="Test",
            last_name="User",
            password="InitialP@ssw0rd!",
            force_password_reset=True,
        )
        mock_response = {
            "metadata": {"id": "id1", "username": "testuser"},
            "spec": {"email": "test@user.com", "firstName": "Test", "lastName": "User"},
            "status": {"active": True},
        }
        self.mock_api_client.request.return_value = mock_response

        user = self.client.create_user(options)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            "/profile/users",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.CREATED],
        )
        self.assertEqual(user.metadata.username, "testuser")
        # Verify password and force_password_reset are included in the request
        call_args = self.mock_api_client.request.call_args
        request_json = call_args.kwargs["json"]
        self.assertEqual(request_json["password"], "InitialP@ssw0rd!")
        self.assertTrue(request_json["forcePasswordReset"])

    def test_get_user(self):
        username = "testuser"
        mock_response = {
            "metadata": {"id": "id1", "username": username},
            "spec": {"email": "test@user.com"},
            "status": {"active": True},
        }
        self.mock_api_client.request.return_value = mock_response

        user = self.client.get_user(username)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            f"/profile/users/{username}",
            version="v1",
            authentication=True,
            params=None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(user.metadata.username, username)
        self.assertTrue(user.status.active)

    def test_list_users(self):
        mock_response = {
            "items": [
                {
                    "metadata": {"id": "id1", "username": "user1"},
                    "spec": {"email": "user1@e.com"},
                    "status": {"active": True},
                },
                {
                    "metadata": {"id": "id2", "username": "user2"},
                    "spec": {"email": "user2@e.com"},
                    "status": {"active": False},
                },
            ],
            "status": {"total": 2},
        }
        self.mock_api_client.request.return_value = mock_response

        user_list = self.client.list_users()
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/profile/users",
            version="v1",
            authentication=True,
            params=None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(len(user_list.items), 2)
        self.assertEqual(user_list.items[0].metadata.username, "user1")
        self.assertFalse(user_list.items[1].status.active)
        self.assertEqual(user_list.status.total, 2)

    def test_search_users(self):
        options = user_schema.SearchUsersOptions(search_term="test")
        mock_response = {
            "items": [
                {
                    "metadata": {"id": "id1", "username": "testuser"},
                    "spec": {"email": "test@user.com"},
                    "status": {"active": True},
                }
            ],
            "status": {"total": 1},
        }
        self.mock_api_client.request.return_value = mock_response

        user_list = self.client.search_users(options)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/profile/search-users",
            version="v1",
            authentication=True,
            params=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(len(user_list.items), 1)
        self.assertEqual(user_list.items[0].metadata.username, "testuser")

    def test_update_user(self):
        username = "testuser"
        options = user_schema.UpdateUserOptions(email="new@user.com")
        mock_response = {
            "metadata": {"id": "id1", "username": username},
            "spec": {"email": "new@user.com"},
            "status": {"active": True},
        }
        self.mock_api_client.request.return_value = mock_response

        user = self.client.update_user(username, options)
        self.mock_api_client.request.assert_called_once_with(
            "put",
            f"/profile/users/{username}",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(user.spec.email, "new@user.com")

    def test_assign_groups(self):
        username = "testuser"
        options = user_schema.AssignUserGroupsOptions(group_ids=["gid1", "gid2"])
        self.client.assign_user_groups(username, options)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            f"/profile/users/{username}/assign-groups",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def test_enable_user(self):
        username = "testuser"
        self.client.enable_user(username)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            f"/profile/users/{username}/enable",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def test_disable_user(self):
        username = "testuser"
        self.client.disable_user(username)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            f"/profile/users/{username}/disable",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )

    # --- Group CRUD tests ---

    def test_create_group(self):
        options = group_schema.CreateGroupOptions(name="testgroup", parent_id="parent1")
        mock_response = {
            "metadata": {
                "id": "gid1",
                "path": "/parent1/testgroup",
                "parentId": "parent1",
            },
            "spec": {"name": "testgroup"},
            "status": {"subGroupIds": [], "memberIds": []},
        }
        self.mock_api_client.request.return_value = mock_response

        group = self.client.create_group(options)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            "/profile/groups",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.CREATED],
        )
        self.assertEqual(group.metadata.id, "gid1")
        self.assertEqual(group.spec.name, "testgroup")
        self.assertEqual(group.metadata.parent_id, "parent1")

    def test_get_group(self):
        group_id = "gid1"
        mock_response = {
            "metadata": {"id": group_id, "path": "/parent1/testgroup"},
            "spec": {"name": "testgroup"},
            "status": {"subGroupIds": ["gid2"], "memberIds": ["uid1"]},
        }
        self.mock_api_client.request.return_value = mock_response

        group = self.client.get_group(group_id)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            f"/profile/groups/{group_id}",
            version="v1",
            authentication=True,
            params=None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(group.metadata.id, group_id)
        self.assertEqual(group.spec.name, "testgroup")
        self.assertIn("gid2", group.status.sub_group_ids)

    def test_list_groups(self):
        mock_response = {
            "items": [
                {
                    "metadata": {"id": "gid1", "path": "/g1"},
                    "spec": {"name": "g1"},
                    "status": {"subGroupIds": [], "memberIds": []},
                },
                {
                    "metadata": {"id": "gid2", "path": "/g2"},
                    "spec": {"name": "g2"},
                    "status": {"subGroupIds": [], "memberIds": []},
                },
            ],
            "status": {"total": 2},
        }
        self.mock_api_client.request.return_value = mock_response

        group_list = self.client.list_groups()
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/profile/groups",
            version="v1",
            authentication=True,
            params=None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(len(group_list.items), 2)
        self.assertEqual(group_list.items[0].spec.name, "g1")
        self.assertEqual(group_list.items[1].metadata.id, "gid2")

    def test_search_groups(self):
        options = group_schema.SearchGroupsOptions(search_term="test")
        mock_response = {
            "items": [
                {
                    "metadata": {"id": "gid1", "path": "/testgroup"},
                    "spec": {"name": "testgroup"},
                    "status": {"subGroupIds": [], "memberIds": []},
                }
            ],
            "status": {"total": 1},
        }
        self.mock_api_client.request.return_value = mock_response

        group_list = self.client.search_groups(options)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/profile/search-groups",
            version="v1",
            authentication=True,
            params=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(len(group_list.items), 1)
        self.assertEqual(group_list.items[0].spec.name, "testgroup")

    def test_rename_group(self):
        group_id = "gid1"
        options = group_schema.RenameGroupOptions(new_name="renamedgroup")
        mock_response = {
            "metadata": {"id": group_id, "path": "/renamedgroup"},
            "spec": {"name": "renamedgroup"},
            "status": {},
        }
        self.mock_api_client.request.return_value = mock_response

        group = self.client.rename_group(group_id, options)
        self.mock_api_client.request.assert_called_once_with(
            "put",
            f"/profile/groups/{group_id}/rename",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(group.spec.name, "renamedgroup")

    def test_move_group(self):
        group_id = "gid1"
        options = group_schema.MoveGroupOptions(new_parent_id="parent2")
        mock_response = {
            "metadata": {
                "id": group_id,
                "path": "/parent2/testgroup",
                "parentId": "parent2",
            },
            "spec": {"name": "testgroup"},
            "status": {},
        }
        self.mock_api_client.request.return_value = mock_response

        group = self.client.move_group(group_id, options)
        self.mock_api_client.request.assert_called_once_with(
            "put",
            f"/profile/groups/{group_id}/move",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(group.metadata.parent_id, "parent2")

    def test_assign_group_members(self):
        group_id = "gid1"
        options = group_schema.AssignGroupMembersOptions(usernames=["user1", "user2"])
        self.client.assign_group_members(group_id, options)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            f"/profile/groups/{group_id}/assign-members",
            version="v1",
            authentication=True,
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def test_search_users_metadata(self):
        options = user_schema.SearchUsersMetadataOptions(
            search_term="test", limit=10, offset=0
        )
        mock_response = {
            "items": [
                {
                    "username": "testuser",
                    "email": "test@user.com",
                    "firstName": "Test",
                    "lastName": "User",
                }
            ],
            "status": {"total": 1},
        }
        self.mock_api_client.request.return_value = mock_response

        result = self.client.search_users_metadata(options)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/profile/search-users-metadata",
            version="v1",
            authentication=True,
            params=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(len(result.items), 1)
        self.assertEqual(result.items[0].username, "testuser")
        self.assertEqual(result.items[0].email, "test@user.com")
        self.assertEqual(result.items[0].first_name, "Test")
        self.assertEqual(result.items[0].last_name, "User")
        self.assertEqual(result.status.total, 1)

    def test_search_groups_metadata(self):
        options = group_schema.SearchGroupsMetadataOptions(
            search_term="test", limit=10, offset=0
        )
        mock_response = {
            "items": [
                {
                    "groupId": "gid1",
                    "name": "testgroup",
                },
                {
                    "groupId": "gid2",
                    "name": "othergroup",
                },
            ],
            "status": {"total": 2},
        }
        self.mock_api_client.request.return_value = mock_response

        result = self.client.search_groups_metadata(options)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/profile/search-groups-metadata",
            version="v1",
            authentication=True,
            params=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(len(result.items), 2)
        self.assertEqual(result.items[0].group_id, "gid1")
        self.assertEqual(result.items[0].name, "testgroup")
        self.assertEqual(result.items[1].group_id, "gid2")
        self.assertEqual(result.items[1].name, "othergroup")
        self.assertEqual(result.status.total, 2)

    def test_delete_group(self):
        group_id = "gid1"
        self.client.delete_group(group_id)
        self.mock_api_client.request.assert_called_once_with(
            "delete",
            f"/profile/groups/{group_id}",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )
