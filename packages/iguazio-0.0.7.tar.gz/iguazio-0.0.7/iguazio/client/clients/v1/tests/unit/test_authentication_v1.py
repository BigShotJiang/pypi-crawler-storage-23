# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import http
import unittest
from unittest.mock import MagicMock

import iguazio.client.clients.v1.authentication as auth_client
import iguazio.schemas.v1.resources.access_token as access_token_schema
import iguazio.schemas.v1.resources.user as user_schema


class TestAuthenticationClientV1(unittest.TestCase):
    def setUp(self):
        self.mock_api_client = MagicMock()
        self.client = auth_client.AuthenticationClientV1(self.mock_api_client)

    def test_get_self(self):
        mock_response = {
            "metadata": {"id": "id1", "username": "selfuser"},
            "spec": {"email": "self@user.com"},
            "status": {"active": True},
        }
        self.mock_api_client.request.return_value = mock_response

        user = self.client.get_self()
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/authentication/self",
            version="v1",
            authentication=True,
            params=user_schema.GetSelfOptions(
                format=user_schema.GetSelfFormat.minimal
            ).to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(user.metadata.username, "selfuser")
        self.assertEqual(user.spec.email, "self@user.com")
        self.assertTrue(user.status.active)

    def test_get_self_with_options(self):
        mock_response = {
            "metadata": {"id": "id1", "username": "selfuser"},
            "spec": {"email": "self@user.com"},
            "status": {"active": True},
        }
        self.mock_api_client.request.return_value = mock_response

        user = self.client.get_self(format=user_schema.GetSelfFormat.full)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/authentication/self",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
            params={"format": user_schema.GetSelfFormat.full.value},
        )
        self.assertEqual(user.metadata.username, "selfuser")
        self.assertEqual(user.spec.email, "self@user.com")
        self.assertTrue(user.status.active)

    def test_refresh_access_token_success(self):
        mock_response = self._generate_token_json()
        self.mock_api_client.request.return_value = mock_response

        options = access_token_schema.RefreshAccessTokenOptions(
            refresh_token="valid-token"
        )
        token = self.client.refresh_access_token(options=options)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            "/authentication/refresh-access-token",
            version="v1",
            authentication=False,
            expected_status_codes=[http.HTTPStatus.OK],
            json={"refreshToken": "valid-token"},
        )

        self.assertEqual(token.metadata.id, "token123")
        self.assertEqual(token.metadata.session_id, "session123")
        self.assertEqual(token.metadata.token_type, "Bearer")
        self.assertEqual(token.metadata.issued_token_type, "JWT")
        self.assertEqual(token.spec.access_token, "new-access-token")
        self.assertEqual(token.status.expires_in, 3600)

    def test_refresh_access_token_missing_options(self):
        with self.assertRaises(ValueError) as ctx:
            self.client.refresh_access_token(options=None)
        self.assertEqual(
            str(ctx.exception),
            "Options must be provided for refreshing access token.",
        )
        with self.assertRaises(ValueError) as ctx:
            self.client.refresh_access_token(
                options=access_token_schema.RefreshAccessTokenOptions(refresh_token="")
            )
        self.assertEqual(
            str(ctx.exception),
            "Refresh token must be provided in options.",
        )

    def test_revoke_offline_token_success(self):
        self.mock_api_client.request.return_value = None

        options = access_token_schema.RevokeOfflineTokenOptions(
            token="offline-token-123"
        )
        self.client.revoke_offline_token(options=options)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            "/authentication/revoke-offline-token",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
            json={"token": "offline-token-123"},
        )

    def test_revoke_offline_token_missing_options(self):
        with self.assertRaises(ValueError) as ctx:
            self.client.revoke_offline_token(options=None)
        self.assertEqual(
            str(ctx.exception),
            "Options must be provided for revoking offline token.",
        )
        with self.assertRaises(ValueError) as ctx:
            self.client.revoke_offline_token(
                options=access_token_schema.RevokeOfflineTokenOptions(token="")
            )
        self.assertEqual(
            str(ctx.exception),
            "Token must be provided in options.",
        )

    def test_refresh_access_tokens(self):
        # Setup
        refresh_tokens = ["token1", "token2", "token3"]
        options = access_token_schema.RefreshAccessTokensOptions(
            refresh_tokens=refresh_tokens
        )

        correct_token = self._generate_token_json()
        incorrect_token = self._generate_token_json(
            status_code=http.HTTPStatus.UNAUTHORIZED, error_message="Invalid token"
        )
        mock_response = {
            "items": [
                correct_token,
                incorrect_token,
            ],
            "status": {"statusCode": 207, "errorMessage": "Partial success"},
        }
        self.mock_api_client.request.return_value = mock_response

        # Call the method
        token_list = self.client.refresh_access_tokens(
            options=options,
        )

        # Assertions
        assert isinstance(token_list, access_token_schema.AccessTokenList)
        assert len(token_list.items) == 2
        assert (
            token_list.items[0].spec.access_token
            == correct_token["spec"]["accessToken"]
        )
        assert token_list.items[0].status.status_code == http.HTTPStatus.OK
        assert token_list.items[1].status.status_code == http.HTTPStatus.UNAUTHORIZED
        self.mock_api_client.request.assert_called_once_with(
            "post",
            "/authentication/refresh-access-tokens",
            version="v1",
            authentication=False,
            expected_status_codes=[http.HTTPStatus.OK, http.HTTPStatus.MULTI_STATUS],
            json={"refreshTokens": refresh_tokens, "mode": 0},
        )

    def test_refresh_access_tokens_wrong_options(self):
        with self.assertRaises(ValueError):
            self.client.refresh_access_tokens(options=None)

        with self.assertRaises(ValueError):
            self.client.refresh_access_tokens(
                options=access_token_schema.RefreshAccessTokensOptions(
                    refresh_tokens=[]
                )
            )

    def test_refresh_access_tokens_all_successful(self):
        # Setup
        refresh_tokens = ["token1", "token2", "token3"]
        options = access_token_schema.RefreshAccessTokensOptions(
            refresh_tokens=refresh_tokens
        )

        # Mock response
        mock_response = {
            "items": [
                self._generate_token_json(),
                self._generate_token_json(),
                self._generate_token_json(),
            ],
            "status": {"statusCode": 200},
        }
        self.mock_api_client.request.return_value = mock_response

        # Call the method
        token_list = self.client.refresh_access_tokens(
            options=options,
        )

        # Assertions
        assert isinstance(token_list, access_token_schema.AccessTokenList)
        assert len(token_list.items) == 3
        for token in token_list.items:
            assert token.spec.access_token == "new-access-token"
        self.mock_api_client.request.assert_called_once_with(
            "post",
            "/authentication/refresh-access-tokens",
            version="v1",
            authentication=False,
            expected_status_codes=[http.HTTPStatus.OK, http.HTTPStatus.MULTI_STATUS],
            json={"refreshTokens": refresh_tokens, "mode": 0},
        )

    def test_refresh_access_tokens_all_failed(self):
        # Setup
        refresh_tokens = ["token1", "token2"]
        options = access_token_schema.RefreshAccessTokensOptions(
            refresh_tokens=refresh_tokens
        )

        failed_token1 = self._generate_token_json(
            status_code=http.HTTPStatus.UNAUTHORIZED, error_message="Invalid token"
        )
        failed_token2 = self._generate_token_json(
            status_code=http.HTTPStatus.UNAUTHORIZED, error_message="Invalid token"
        )
        mock_response = {
            "items": [failed_token1, failed_token2],
            "status": {"statusCode": 401, "errorMessage": "All failed"},
        }
        self.mock_api_client.request.return_value = mock_response

        token_list = self.client.refresh_access_tokens(options=options)
        assert isinstance(token_list, access_token_schema.AccessTokenList)
        assert len(token_list.items) == 2
        for token in token_list.items:
            assert token.status.status_code == http.HTTPStatus.UNAUTHORIZED

    def test_refresh_access_tokens_failed_item_without_expiry_fields(self):
        refresh_tokens = ["token1", "token2"]
        options = access_token_schema.RefreshAccessTokensOptions(
            refresh_tokens=refresh_tokens
        )

        successful_token = self._generate_token_json()
        failed_token = {
            "status": {
                "statusCode": http.HTTPStatus.UNAUTHORIZED,
                "errorMessage": "Invalid token",
            }
        }
        mock_response = {
            "items": [successful_token, failed_token],
            "status": {"statusCode": 207, "errorMessage": "Partial success"},
        }
        self.mock_api_client.request.return_value = mock_response

        token_list = self.client.refresh_access_tokens(options=options)

        assert isinstance(token_list, access_token_schema.AccessTokenList)
        assert len(token_list.items) == 2
        assert token_list.items[0].status.expires_in == 3600
        assert token_list.items[0].metadata is not None
        assert token_list.items[0].spec is not None
        assert token_list.items[1].status.status_code == http.HTTPStatus.UNAUTHORIZED
        assert token_list.items[1].status.error_message == "Invalid token"
        assert token_list.items[1].metadata is None
        assert token_list.items[1].spec is None
        assert token_list.items[1].status.expires_in is None
        assert token_list.items[1].status.refresh_expires_in is None

    @staticmethod
    def _generate_token_json(status_code=http.HTTPStatus.OK, error_message=None):
        return {
            "metadata": {
                "id": "token123",
                "sessionId": "session123",
                "tokenType": "Bearer",
                "issuedTokenType": "JWT",
                "scope": "read write",
            },
            "spec": {
                "accessToken": "new-access-token",
                "idToken": "new-id-token",
                "refreshToken": "new-refresh-token",
            },
            "status": {
                "expiresIn": 3600,
                "refreshExpiresIn": 7200,
                "notBeforePolicy": 0,
                "statusCode": status_code,
                "errorMessage": error_message,
            },
        }
