# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http

import iguazio.client.clients.base

import iguazio.schemas.serializer
import iguazio.schemas.v1.resources.system_info as system_info_schema


class InfoClientV1(iguazio.client.clients.base.BaseClient):
    """
    Client for interacting with the Iguazio info API v1.
    This client provides methods to retrieve system information.
    """

    def get_system_info(self) -> system_info_schema.SystemInfo:
        """
        Retrieve system information.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            system_info = client.get_system_info()

        Returns:
            iguazio.schemas.v1.resources.system_info.SystemInfo: The system information.
        """
        response = self._request(
            "get",
            "/info/system",
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, system_info_schema.SystemInfo
        )

    def keycloak_redirect_uri(self, alias: str) -> str:
        """
        Generate the Keycloak redirect URI for a given alias.

        Example usage::
            client = iguazio.Client(api_url="https://api.example.com")
            redirect_uri = client.keycloak_redirect_uri(alias="my-alias")

        Args:
            alias (str): The alias for which to generate the redirect URI.

        Returns:
            str: The Keycloak redirect URI.
        """
        system_info = self.get_system_info()
        keycloak_host_address = system_info.metadata.keycloak.host_address
        keycloak_realm = system_info.metadata.keycloak.realm
        return (
            f"{keycloak_host_address}/realms/{keycloak_realm}/broker/{alias}/endpoint"
        )
