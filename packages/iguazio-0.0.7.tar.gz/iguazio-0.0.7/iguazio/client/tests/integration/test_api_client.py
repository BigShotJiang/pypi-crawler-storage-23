# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import unittest

import iguazio.client
import tests.unit


class TestClient(tests.unit.BaseTestCase):
    @classmethod
    def setup_class(cls):
        super().setup_class()
        # TODO: Replace with actual base URL of the Iguazio API
        api_url = "None"
        cls.client = iguazio.client.APIClient(
            api_url=api_url,
            verify_ssl=False,
        )

    @unittest.skip("Skipping test_login_flow for manual testing")
    def test_get_self(self):
        for i in range(3):
            response = self.client.request(
                method="get",
                path="/api/v1/authentication/self",
            )
            assert response.status_code == 200
            response_json = response.json()
            assert "metadata" in response_json, (
                "Response should contain 'metadata' field"
            )
            assert "username" in response_json["metadata"], (
                "'metadata' should contain 'username' field"
            )
            assert "ctx" in response_json["status"], (
                "'status' should contain 'ctx' field"
            )
