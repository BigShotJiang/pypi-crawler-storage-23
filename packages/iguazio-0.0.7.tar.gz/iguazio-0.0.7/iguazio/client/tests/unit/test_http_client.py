# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import httpx
import pytest
from http import HTTPStatus

import iguazio.client.http
import tests.unit


class TestClient(tests.unit.BaseTestCase):
    @classmethod
    def setup_class(cls):
        super().setup_class()
        cls.http_client = iguazio.client.http._BaseHTTPClient(
            parent_logger=cls.logger,
            api_url="https://postman-echo.com",
        )

    @pytest.mark.parametrize(
        "path, method, expected_status, body",
        [
            ("get", "get", HTTPStatus.OK, None),
            ("post", "post", HTTPStatus.OK, {"key": "value"}),
            ("put", "put", HTTPStatus.OK, {"key": "value"}),
            ("delete", "delete", HTTPStatus.OK, None),
        ],
    )
    def test_http_methods(self, path, method, expected_status, body):
        response = self.http_client.send_request(
            method=method,
            path=path,
            error_message="Error",
            json=body,
            full_path=True,
        )
        assert response.status_code == expected_status
        if body:
            assert response.json()["json"] == body

    @pytest.mark.parametrize(
        "status_code",
        [
            HTTPStatus.UNAUTHORIZED,
            HTTPStatus.NOT_FOUND,
            HTTPStatus.INTERNAL_SERVER_ERROR,
            HTTPStatus.SERVICE_UNAVAILABLE,
        ],
    )
    def test_failures(self, status_code):
        with pytest.raises(httpx.HTTPStatusError):
            self.http_client.send_request(
                method="get",
                path=f"status/{status_code}",
                error_message="Error",
                full_path=True,
            )

    @pytest.mark.parametrize(
        "status_code,expected_status_codes,should_raise",
        [
            (HTTPStatus.CREATED, [HTTPStatus.CREATED], False),
            (HTTPStatus.CREATED, [HTTPStatus.OK], True),
            (HTTPStatus.OK, [HTTPStatus.OK, HTTPStatus.CREATED], False),
            (HTTPStatus.BAD_REQUEST, [HTTPStatus.OK], True),
        ],
    )
    def test_expected_status_codes(
        self, status_code, expected_status_codes, should_raise
    ):
        path = f"status/{status_code}"
        if should_raise:
            with pytest.raises(httpx.HTTPStatusError):
                self.http_client.send_request(
                    method="get",
                    path=path,
                    error_message="Error",
                    expected_status_codes=expected_status_codes,
                    full_path=True,
                )
        else:
            response = self.http_client.send_request(
                method="get",
                path=path,
                error_message="Error",
                expected_status_codes=expected_status_codes,
                full_path=True,
            )
            assert response.status_code == status_code

    @pytest.mark.parametrize(
        "status_code,ignore_status_codes,should_raise",
        [
            (HTTPStatus.NOT_FOUND, [HTTPStatus.NOT_FOUND], False),
            (HTTPStatus.BAD_REQUEST, [HTTPStatus.NOT_FOUND], True),
            (
                HTTPStatus.INTERNAL_SERVER_ERROR,
                [HTTPStatus.INTERNAL_SERVER_ERROR],
                False,
            ),
            (HTTPStatus.UNAUTHORIZED, [], True),
        ],
    )
    def test_ignore_status_codes(self, status_code, ignore_status_codes, should_raise):
        path = f"status/{status_code}"
        if should_raise:
            with pytest.raises(httpx.HTTPStatusError):
                self.http_client.send_request(
                    method="get",
                    path=path,
                    error_message="Error",
                    ignore_status_codes=ignore_status_codes,
                    full_path=True,
                )
        else:
            response = self.http_client.send_request(
                method="get",
                path=path,
                error_message="Error",
                ignore_status_codes=ignore_status_codes,
                full_path=True,
            )
            assert response.status_code == status_code
