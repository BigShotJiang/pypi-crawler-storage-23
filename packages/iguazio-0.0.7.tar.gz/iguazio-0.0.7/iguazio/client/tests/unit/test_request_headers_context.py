# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import concurrent.futures
import threading
import time
import unittest.mock

import pytest

import iguazio
import tests.unit


class TestRequestHeadersContext(tests.unit.BaseTestCase):
    def setup_method(self):
        with (
            unittest.mock.patch("httpx.Client"),
            unittest.mock.patch("httpx.HTTPTransport"),
        ):
            self.client = iguazio.Client(
                api_url="https://example.com",
                verify_ssl=False,
                use_token_file=False,
                auto_login=False,
            )

        self.api_client = self.client._api_client
        self.api_client._client.send_request = unittest.mock.MagicMock(
            return_value=unittest.mock.MagicMock(content=b"{}")
        )

    def test_with_headers_applies_and_nests(self):
        self.api_client._client.send_request.reset_mock()

        with self.client.with_headers({"X-Request-ID": "outer"}):
            # Request 0
            self.api_client.request(method="get", path="/foo", authentication=False)
            with self.client.with_headers({"X-Request-ID": "inner", "X-Debug": "1"}):
                # Request 1
                self.api_client.request(method="get", path="/bar", authentication=False)
            # Request 2
            self.api_client.request(method="get", path="/baz", authentication=False)

        # Request 3
        self.api_client.request(method="get", path="/nope", authentication=False)

        assert self._call_headers(0)["X-Request-ID"] == "outer"
        assert self._call_headers(1)["X-Request-ID"] == "inner"
        assert self._call_headers(1)["X-Debug"] == "1"
        assert self._call_headers(2)["X-Request-ID"] == "outer"
        assert "X-Request-ID" not in self._call_headers(3)

    def test_per_call_headers_override_context_headers(self):
        self.api_client._client.send_request.reset_mock()

        with self.client.with_headers({"X-Request-ID": "context"}):
            self.api_client.request(
                method="get",
                path="/foo",
                authentication=False,
                headers={"X-Request-ID": "per-call"},
            )

        assert self._call_headers()["X-Request-ID"] == "per-call"

    def test_auth_headers_override_other_headers(self):
        self.api_client._client.send_request.reset_mock()
        self.api_client._auth_client.enrich_auth_headers = unittest.mock.MagicMock(
            return_value={"Authorization": "Bearer token-from-auth"}
        )

        with self.client.with_headers({"Authorization": "Bearer token-from-context"}):
            self.api_client.request(
                method="get",
                path="/foo",
                authentication=True,
                headers={"Authorization": "Bearer token-from-per-call"},
            )

        assert self._call_headers()["Authorization"] == "Bearer token-from-auth"

    def test_with_headers_requires_dict(self):
        with pytest.raises(TypeError):
            with self.client.with_headers(["not", "a", "dict"]):  # type: ignore
                pass

    def test_with_headers_thread_isolation(self):
        """
        Verify that context headers are properly isolated between threads.

        Each thread sets its own unique header and makes a request. We verify that
        headers set in one thread do not leak to requests in other threads.
        """
        self.api_client._client.send_request.reset_mock()

        num_threads = 5
        barrier = threading.Barrier(num_threads)
        results = {}
        errors = []

        def thread_worker(thread_id: int):
            try:
                # Wait for all threads to be ready before setting headers
                barrier.wait()

                with self.client.with_headers({"X-Thread-ID": f"thread-{thread_id}"}):
                    # Small delay to increase chance of interleaving
                    time.sleep(0.01)
                    self.api_client.request(
                        method="get", path=f"/thread-{thread_id}", authentication=False
                    )

                    # Capture what headers were used for this thread's request
                    # by finding the call with this thread's path
                    for call in self.api_client._client.send_request.call_args_list:
                        if call.args[1] == f"/thread-{thread_id}":
                            results[thread_id] = call.kwargs.get("headers", {})
                            break
            except Exception as e:
                errors.append((thread_id, e))

        with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
            futures = [
                executor.submit(thread_worker, thread_id)
                for thread_id in range(num_threads)
            ]
            concurrent.futures.wait(futures)

        # Verify no errors occurred
        assert not errors, f"Thread errors: {errors}"

        # Verify each thread received its own header value
        for thread_id in range(num_threads):
            assert thread_id in results, f"Thread {thread_id} did not record results"
            assert results[thread_id].get("X-Thread-ID") == f"thread-{thread_id}", (
                f"Thread {thread_id} got wrong header: {results[thread_id]}"
            )

    def test_with_headers_no_leakage_after_thread_exits(self):
        """
        Verify that headers set in a thread do not leak after the thread exits.
        """
        self.api_client._client.send_request.reset_mock()

        def thread_with_headers():
            with self.client.with_headers({"X-Thread-Header": "from-thread"}):
                self.api_client.request(
                    method="get", path="/in-thread", authentication=False
                )

        # Run thread with headers
        thread = threading.Thread(target=thread_with_headers)
        thread.start()
        thread.join()

        # Make request in main thread without any context
        self.api_client.request(method="get", path="/main-thread", authentication=False)

        # Find the calls
        in_thread_headers = None
        main_thread_headers = None
        for call in self.api_client._client.send_request.call_args_list:
            if call.args[1] == "/in-thread":
                in_thread_headers = call.kwargs.get("headers", {})
            elif call.args[1] == "/main-thread":
                main_thread_headers = call.kwargs.get("headers", {})

        assert in_thread_headers is not None
        assert in_thread_headers.get("X-Thread-Header") == "from-thread"

        assert main_thread_headers is not None
        assert "X-Thread-Header" not in main_thread_headers

    def _call_headers(self, call_index: int = 0) -> dict:
        return self.api_client._client.send_request.call_args_list[
            call_index
        ].kwargs.get("headers", {})
