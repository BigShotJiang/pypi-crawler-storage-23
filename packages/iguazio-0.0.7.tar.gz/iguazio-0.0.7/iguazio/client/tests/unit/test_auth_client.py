# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import base64
import json
import os
import random
import time
import pytest
import unittest.mock

from contextlib import nullcontext as does_not_raise

import iguazio.client.auth
import iguazio.client.http
import iguazio.common.constants
import tests.unit


class TestAuthClient(tests.unit.BaseTestCase):
    class Constants:
        token_name = "test-token"
        token = "refresh-token"
        token_file = "test.igz.yml"

    def setup_method(self):
        self.base_url = "api.fake-domain.com"
        with (
            unittest.mock.patch("httpx.Client"),
            unittest.mock.patch("httpx.HTTPTransport"),
        ):
            self.auth_client = iguazio.client.auth._AuthClient(
                api_url=self.base_url,
                parent_logger=self.logger,
                http_client=iguazio.client.http._BaseHTTPClient(
                    parent_logger=self.logger,
                    api_url=self.base_url,
                    timeout=30,
                    retries=3,
                    verify=False,
                ),
                use_token_file=False,
            )

    def test_parse_access_token(self):
        # Generate fake token
        jwt_token = self._generate_token(expiration_seconds=3600)

        # inject it into the auth_client
        self.auth_client._access_token = jwt_token

        self.auth_client._parse_access_token()
        assert self.auth_client._access_token is not None, (
            "Access token should not be None after parsing"
        )
        assert self.auth_client._expires_at is not None, (
            "Expiration time should not be None after parsing"
        )
        assert self.auth_client._access_token_ttl is not None, (
            "Refresh token TTL should not be None after parsing"
        )
        assert self.auth_client._expires_at > time.time(), (
            "Expiration time should be in the future"
        )

    @unittest.mock.patch("iguazio.client.auth.base_client._BaseHTTPClient.post")
    def test_refresh_token(self, mock_request):
        # Generate fake token
        original_access_token = self._generate_token(expiration_seconds=3600)
        original_refresh_token = self._generate_token(expiration_seconds=3600)
        self.auth_client._access_token = original_access_token
        self.auth_client._refresh_token = original_refresh_token

        new_access_token = self._generate_token(expiration_seconds=3600)
        new_refresh_token = self._generate_token(expiration_seconds=3600)

        # Mock the post request
        mock_response = unittest.mock.MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "spec": {
                "accessToken": new_access_token,
                "refreshToken": new_refresh_token,
            }
        }
        mock_request.return_value = mock_response

        # Refresh the access token
        self.auth_client._refresh_access_token()

        assert self.auth_client.access_token == new_access_token, (
            "Access token should be updated after refresh"
        )
        assert self.auth_client.access_token != original_access_token, (
            "Access token should be different after refresh"
        )
        assert self.auth_client.refresh_token == new_refresh_token, (
            "Refresh token should be updated after refresh"
        )
        assert self.auth_client.refresh_token != original_refresh_token, (
            "Refresh token should be different after refresh"
        )

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    @unittest.mock.patch("yaml.safe_load")
    def test_load_token_file_strict_mode_success(
        self, mock_yaml_load, mock_open, mock_exists
    ):
        """Test that specific token_name loads that exact token in strict mode."""
        mock_exists.return_value = True
        mock_file = unittest.mock.MagicMock()
        mock_open.return_value.__enter__.return_value = mock_file
        mock_yaml_load.return_value = {
            "secretTokens": [
                {"name": self.Constants.token_name, "token": self.Constants.token}
            ]
        }

        with unittest.mock.patch.object(
            self.auth_client, "_refresh_access_token"
        ) as mock_refresh:
            self.auth_client._load_token_file(
                token_file_path=self.Constants.token_file,
                token_name=self.Constants.token_name,
            )
            mock_refresh.assert_called_once()
            assert self.auth_client._refresh_token == self.Constants.token
            assert self.auth_client._resolved_token_name == self.Constants.token_name

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    @unittest.mock.patch("yaml.safe_load")
    def test_load_token_file_strict_mode_token_not_found(
        self, mock_yaml_load, mock_open, mock_exists
    ):
        """Test that ValueError is raised when specific token_name is not found."""
        mock_exists.return_value = True
        mock_file = unittest.mock.MagicMock()
        mock_open.return_value.__enter__.return_value = mock_file
        mock_yaml_load.return_value = {
            "secretTokens": [{"name": "other-token", "token": "some-token"}]
        }

        with pytest.raises(ValueError, match="Token 'non-existent' not found"):
            self.auth_client._load_token_file(
                token_file_path=self.Constants.token_file,
                token_name="non-existent",
            )

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    @unittest.mock.patch("yaml.safe_load")
    def test_load_token_file_strict_mode_token_invalid(
        self, mock_yaml_load, mock_open, mock_exists
    ):
        """Test that RuntimeError is raised when specific token is invalid."""
        mock_exists.return_value = True
        mock_file = unittest.mock.MagicMock()
        mock_open.return_value.__enter__.return_value = mock_file
        mock_yaml_load.return_value = {
            "secretTokens": [
                {"name": self.Constants.token_name, "token": self.Constants.token}
            ]
        }

        with unittest.mock.patch.object(
            self.auth_client, "_refresh_access_token"
        ) as mock_refresh:
            mock_refresh.side_effect = Exception("Token invalid")

            with pytest.raises(
                RuntimeError, match=f"Token '{self.Constants.token_name}' is not valid"
            ):
                self.auth_client._load_token_file(
                    token_file_path=self.Constants.token_file,
                    token_name=self.Constants.token_name,
                )
            # Token should be cleared after failure
            assert self.auth_client._refresh_token is None

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    @unittest.mock.patch("yaml.safe_load")
    def test_load_token_file_strict_mode_token_empty(
        self, mock_yaml_load, mock_open, mock_exists
    ):
        """Test that ValueError is raised when specific token has empty value."""
        mock_exists.return_value = True
        mock_file = unittest.mock.MagicMock()
        mock_open.return_value.__enter__.return_value = mock_file
        mock_yaml_load.return_value = {
            "secretTokens": [
                {"name": self.Constants.token_name, "token": ""},
                {"name": "other-token", "token": "valid-token"},
            ]
        }

        with pytest.raises(
            ValueError, match=f"Token '{self.Constants.token_name}' has no value"
        ):
            self.auth_client._load_token_file(
                token_file_path=self.Constants.token_file,
                token_name=self.Constants.token_name,
            )

    @unittest.mock.patch("os.path.exists")
    def test_load_token_file_specific_file_not_found(self, mock_exists):
        """Test that FileNotFoundError is raised when a specific file path is provided but doesn't exist."""
        mock_exists.return_value = False

        # Should raise regardless of whether token_name is specified
        with pytest.raises(
            FileNotFoundError, match="Token file not found at specified path"
        ):
            self.auth_client._load_token_file(
                token_file_path=self.Constants.token_file,
                token_name=self.Constants.token_name,
            )

        with pytest.raises(
            FileNotFoundError, match="Token file not found at specified path"
        ):
            self.auth_client._load_token_file(
                token_file_path=self.Constants.token_file,
                token_name=None,  # Even without specific token, specific file path should error
            )

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    @unittest.mock.patch("yaml.safe_load")
    def test_load_token_file_uses_default_first(
        self, mock_yaml_load, mock_open, mock_exists
    ):
        """Test that token resolution checks 'default' token first."""
        mock_exists.return_value = True
        mock_file = unittest.mock.MagicMock()
        mock_open.return_value.__enter__.return_value = mock_file
        mock_yaml_load.return_value = {
            "secretTokens": [
                {"name": "zebra", "token": "token-z"},
                {"name": "default", "token": "token-default"},
                {"name": "alpha", "token": "token-a"},
            ]
        }

        with unittest.mock.patch.object(
            self.auth_client, "_refresh_access_token"
        ) as mock_refresh:
            self.auth_client._load_token_file(
                token_file_path=self.Constants.token_file,
                token_name=None,
            )
            # Should use only the default token
            mock_refresh.assert_called_once_with(suppress_errors=True)
            # Refresh token should be the default token value
            assert self.auth_client._refresh_token == "token-default"
            assert self.auth_client._resolved_token_name == "default"

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    @unittest.mock.patch("yaml.safe_load")
    def test_load_token_file_default_invalid_fails(
        self, mock_yaml_load, mock_open, mock_exists
    ):
        """Test that token resolution fails immediately when default token is invalid."""
        mock_exists.return_value = True
        mock_file = unittest.mock.MagicMock()
        mock_open.return_value.__enter__.return_value = mock_file
        mock_yaml_load.return_value = {
            "secretTokens": [
                {"name": "zebra", "token": "token-z"},
                {"name": "default", "token": "token-default"},
                {"name": "alpha", "token": "token-a"},
            ]
        }

        with unittest.mock.patch.object(
            self.auth_client, "_refresh_access_token"
        ) as mock_refresh:
            mock_refresh.side_effect = Exception("Token invalid")

            with pytest.raises(RuntimeError, match="Token 'default' is not valid"):
                self.auth_client._load_token_file(
                    token_file_path=self.Constants.token_file,
                    token_name=None,
                )
            # Token should be cleared after failure
            assert self.auth_client._refresh_token is None

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    @unittest.mock.patch("yaml.safe_load")
    def test_load_token_file_first_token_invalid(
        self, mock_yaml_load, mock_open, mock_exists
    ):
        """Test that token resolution fails when first token (no default) is invalid."""
        mock_exists.return_value = True
        mock_file = unittest.mock.MagicMock()
        mock_open.return_value.__enter__.return_value = mock_file
        mock_yaml_load.return_value = {
            "secretTokens": [
                {"name": "alpha", "token": "token-a"},
                {"name": "beta", "token": "token-b"},
            ]
        }

        with unittest.mock.patch.object(
            self.auth_client, "_refresh_access_token"
        ) as mock_refresh:
            mock_refresh.side_effect = Exception("Token invalid")

            with pytest.raises(RuntimeError, match="Token 'alpha' is not valid"):
                self.auth_client._load_token_file(
                    token_file_path=self.Constants.token_file,
                    token_name=None,
                )
            # Token should be cleared after failure
            assert self.auth_client._refresh_token is None

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    @unittest.mock.patch("yaml.safe_load")
    def test_load_token_file_duplicate_default_fails(
        self, mock_yaml_load, mock_open, mock_exists
    ):
        """Test that token resolution fails when multiple 'default' tokens exist."""
        mock_exists.return_value = True
        mock_file = unittest.mock.MagicMock()
        mock_open.return_value.__enter__.return_value = mock_file
        mock_yaml_load.return_value = {
            "secretTokens": [
                {"name": "default", "token": "token-1"},
                {"name": "default", "token": "token-2"},
                {"name": "alpha", "token": "token-a"},
            ]
        }

        with pytest.raises(RuntimeError, match="Found 2 entries for 'default' token"):
            self.auth_client._load_token_file(
                token_file_path=self.Constants.token_file,
                token_name=None,
            )

    @unittest.mock.patch("os.path.exists")
    def test_load_token_file_default_path_not_found(self, mock_exists):
        """Test that default path silently skips when file doesn't exist."""
        mock_exists.return_value = False

        # Should not raise or call open when using default path (token_file_path=None)
        with unittest.mock.patch("builtins.open") as mock_open:
            self.auth_client._load_token_file(
                token_file_path=None,  # Use default path
                token_name=None,
            )
            mock_open.assert_not_called()

        # Also should not raise when using default path with specific token name
        with unittest.mock.patch("builtins.open") as mock_open:
            self.auth_client._load_token_file(
                token_file_path=None,  # Use default path
                token_name="some-token",
            )
            mock_open.assert_not_called()

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    def test_load_service_account_token_file_success(self, mock_open, mock_exists):
        """Test that service account token file loads a valid token."""
        mock_exists.return_value = True
        token = self._generate_token()
        mock_open.return_value.__enter__.return_value.read.return_value = token

        self.auth_client._load_service_account_token_file(
            iguazio.common.constants._Defaults.default_service_account_token_file_path.value
        )

        assert self.auth_client.access_token == token
        assert self.auth_client.refresh_token is None

    @unittest.mock.patch("os.path.exists")
    def test_load_service_account_token_file_missing(self, mock_exists):
        """Test that missing service account token file raises FileNotFoundError."""
        mock_exists.return_value = False

        with pytest.raises(FileNotFoundError, match="Service account token file"):
            self.auth_client._load_service_account_token_file(
                iguazio.common.constants._Defaults.default_service_account_token_file_path.value
            )

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    def test_load_service_account_token_file_empty(self, mock_open, mock_exists):
        """Test that empty service account token file raises ValueError."""
        mock_exists.return_value = True
        mock_open.return_value.__enter__.return_value.read.return_value = "   "

        with pytest.raises(ValueError, match="Service account token file is empty"):
            self.auth_client._load_service_account_token_file(
                iguazio.common.constants._Defaults.default_service_account_token_file_path.value
            )

    @unittest.mock.patch.object(iguazio.client.auth._AuthClient, "_load_token_file")
    @unittest.mock.patch.object(
        iguazio.client.auth._AuthClient, "_load_service_account_token_file"
    )
    @unittest.mock.patch("httpx.Client")
    @unittest.mock.patch("httpx.HTTPTransport")
    def test_init_skips_service_account_check_with_use_token_file_true(
        self, mock_transport, mock_client, mock_load_sa_token, mock_load_token_file
    ):
        """Test that use_token_file skips service account auto-detection."""
        iguazio.client.auth._AuthClient(
            api_url=self.base_url,
            parent_logger=self.logger,
            http_client=iguazio.client.http._BaseHTTPClient(
                parent_logger=self.logger,
                api_url=self.base_url,
                timeout=30,
                retries=3,
                verify=False,
            ),
            use_token_file=True,
        )

        mock_load_sa_token.assert_not_called()
        mock_load_token_file.assert_called_once_with(
            token_file_path=None, token_name=None
        )

    @unittest.mock.patch.object(iguazio.client.auth._AuthClient, "_load_token_file")
    @unittest.mock.patch.object(
        iguazio.client.auth._AuthClient, "_load_service_account_token_file"
    )
    @unittest.mock.patch("httpx.Client")
    @unittest.mock.patch("httpx.HTTPTransport")
    def test_init_skips_service_account_check_with_use_token_file_true_and_token_name(
        self, mock_transport, mock_client, mock_load_sa_token, mock_load_token_file
    ):
        """Test that use_token_file skips service account auto-detection."""
        iguazio.client.auth._AuthClient(
            api_url=self.base_url,
            parent_logger=self.logger,
            http_client=iguazio.client.http._BaseHTTPClient(
                parent_logger=self.logger,
                api_url=self.base_url,
                timeout=30,
                retries=3,
                verify=False,
            ),
            use_token_file=True,
            token_name="named-token",
        )

        mock_load_sa_token.assert_not_called()
        mock_load_token_file.assert_called_once_with(
            token_file_path=None, token_name="named-token"
        )

    @unittest.mock.patch.object(
        iguazio.client.auth._AuthClient, "_load_service_account_token_file"
    )
    @unittest.mock.patch("httpx.Client")
    @unittest.mock.patch("httpx.HTTPTransport")
    @unittest.mock.patch("os.path.exists", return_value=True)
    def test_init_auto_detects_service_account_token(
        self, mock_exists, mock_transport, mock_client, mock_load_sa_token
    ):
        """Test that service account token is auto-detected when file exists."""
        iguazio.client.auth._AuthClient(
            api_url=self.base_url,
            parent_logger=self.logger,
            http_client=iguazio.client.http._BaseHTTPClient(
                parent_logger=self.logger,
                api_url=self.base_url,
                timeout=30,
                retries=3,
                verify=False,
            ),
            use_token_file=False,
        )

        mock_exists.assert_called_once()
        mock_load_sa_token.assert_called_once()

    @unittest.mock.patch.object(
        iguazio.client.auth._AuthClient, "_load_service_account_token_file"
    )
    def test_refresh_token_if_needed_service_account_reload(
        self, mock_load_service_account_token_file
    ):
        """Test that service account auth reloads token when refresh is needed."""
        self.auth_client._use_service_account_token = True
        with unittest.mock.patch.object(
            self.auth_client, "_access_token_needs_refresh", return_value=True
        ):
            self.auth_client._refresh_token_if_needed()

        mock_load_service_account_token_file.assert_called_once()

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    @unittest.mock.patch("yaml.safe_load")
    def test_load_token_file_empty_tokens(self, mock_yaml_load, mock_open, mock_exists):
        """Test that token resolution handles empty token list."""
        mock_exists.return_value = True
        mock_yaml_load.return_value = {"secretTokens": []}

        self.auth_client._load_token_file(
            token_file_path=self.Constants.token_file,
            token_name=None,
        )
        assert self.auth_client._refresh_token is None

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    @unittest.mock.patch("yaml.safe_load")
    def test_load_token_file_default_empty_fails(
        self, mock_yaml_load, mock_open, mock_exists
    ):
        """Test that token resolution fails when default token has empty value."""
        mock_exists.return_value = True
        mock_file = unittest.mock.MagicMock()
        mock_open.return_value.__enter__.return_value = mock_file
        mock_yaml_load.return_value = {
            "secretTokens": [
                {"name": "default", "token": ""},
                {"name": "alpha", "token": "token-a"},
            ]
        }

        with pytest.raises(RuntimeError, match="Resolved token 'default' has no value"):
            self.auth_client._load_token_file(
                token_file_path=self.Constants.token_file,
                token_name=None,
            )

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    @unittest.mock.patch("yaml.safe_load")
    def test_load_token_file_uses_first_when_no_default(
        self, mock_yaml_load, mock_open, mock_exists
    ):
        """Test that token resolution uses first token when no default exists."""
        mock_exists.return_value = True
        mock_file = unittest.mock.MagicMock()
        mock_open.return_value.__enter__.return_value = mock_file
        mock_yaml_load.return_value = {
            "secretTokens": [
                {"name": "alpha", "token": "token-a"},
                {"name": "beta", "token": "token-b"},
            ]
        }

        with unittest.mock.patch.object(
            self.auth_client, "_refresh_access_token"
        ) as mock_refresh:
            self.auth_client._load_token_file(
                token_file_path=self.Constants.token_file,
                token_name=None,
            )
            # Should use the first token (alpha)
            mock_refresh.assert_called_once_with(suppress_errors=True)
            assert self.auth_client._refresh_token == "token-a"
            assert self.auth_client._resolved_token_name == "alpha"

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    @unittest.mock.patch("yaml.safe_load")
    def test_create_or_update_token_file_new_file(
        self, mock_yaml_load, mock_open, mock_exists
    ):
        # Simulate file does not exist
        mock_exists.return_value = False
        # Set refresh token
        self.auth_client._refresh_token = self.Constants.token
        # Simulate file writing
        mock_file = unittest.mock.MagicMock()
        mock_open.return_value.__enter__.return_value = mock_file
        # Patch yaml.dump to just check call
        with unittest.mock.patch("yaml.dump") as mock_yaml_dump:
            self.auth_client._create_or_update_token_file(
                output_token_file=self.Constants.token_file,
                token_name=self.Constants.token_name,
            )
            mock_yaml_dump.assert_called()
            args, kwargs = mock_yaml_dump.call_args
            assert args[0]["secretTokens"][0]["name"] == self.Constants.token_name
            assert args[0]["secretTokens"][0]["token"] == self.Constants.token

    @unittest.mock.patch("os.path.exists")
    @unittest.mock.patch("builtins.open")
    @unittest.mock.patch("yaml.safe_load")
    def test_create_or_update_token_file_update_existing(
        self, mock_yaml_load, mock_open, mock_exists
    ):
        token_format = self.Constants.token + "{}"
        token_name_format = self.Constants.token_name + "{}"

        token_name_1 = token_name_format.format(1)
        token_name_2 = token_name_format.format(2)
        token_1 = token_format.format("old")
        token_2 = token_format.format("other")
        token_1_new = token_format.format("new")

        # Simulate file exists
        mock_exists.return_value = True
        # Simulate existing token file with a token to update
        mock_yaml_load.return_value = {
            "secretTokens": [
                {"name": token_name_1, "token": token_1},
                {"name": token_name_2, "token": token_2},
            ]
        }
        self.auth_client._refresh_token = token_1_new
        mock_file = unittest.mock.MagicMock()
        mock_open.return_value.__enter__.return_value = mock_file
        with unittest.mock.patch("yaml.dump") as mock_yaml_dump:
            self.auth_client._create_or_update_token_file(
                output_token_file=self.Constants.token_file, token_name=token_name_2
            )
            mock_yaml_dump.assert_called()
            args, kwargs = mock_yaml_dump.call_args
            tokens = args[0]["secretTokens"]
            assert tokens[0]["name"] == token_name_1 and tokens[0]["token"] == token_1
            assert (
                tokens[1]["name"] == token_name_2 and tokens[1]["token"] == token_1_new
            )

    def test_create_or_update_token_file_no_refresh_token(self):
        self.auth_client._refresh_token = None
        with pytest.raises(
            RuntimeError,
            match="Refresh token is not available, cannot create or update token file",
        ):
            self.auth_client._create_or_update_token_file(
                output_token_file=self.Constants.token_file,
                token_name=self.Constants.token_name,
            )

        # assert that the token file does not exist
        assert not os.path.exists(self.Constants.token_file)

    @pytest.mark.parametrize(
        "auto_login, valid_access_token, valid_refresh_token, expectation",
        [
            (True, True, True, does_not_raise()),
            (True, True, False, does_not_raise()),
            (True, False, True, does_not_raise()),
            (True, False, False, does_not_raise()),
            (False, True, True, does_not_raise()),
            (False, True, False, does_not_raise()),
            (
                False,
                False,
                True,
                does_not_raise(),
            ),
            (
                False,
                False,
                False,
                pytest.raises(RuntimeError),
            ),
        ],
    )
    @unittest.mock.patch.object(iguazio.client.auth._AuthClient, "login")
    @unittest.mock.patch.object(
        iguazio.client.auth._AuthClient, "_refresh_access_token"
    )
    def test_refresh_token_if_needed_with_auto_login(
        self,
        mock_refresh_access_token,
        mock_login,
        auto_login,
        valid_access_token,
        valid_refresh_token,
        expectation,
    ):
        client = iguazio.client.auth._AuthClient(
            api_url=self.base_url,
            parent_logger=self.logger,
            http_client=self.auth_client.http_client,
            use_token_file=False,
            auto_login=auto_login,
        )
        if valid_access_token:
            client._access_token = self._generate_token(expiration_seconds=3600)
            now = time.time()
            client._expires_at = now + 3600
            client._access_token_ttl = 3600
        else:
            client._access_token = None
            client._expires_at = None
            client._access_token_ttl = None

        if valid_refresh_token:
            client._refresh_token = self._generate_token(expiration_seconds=3600)

        with expectation:
            client._refresh_token_if_needed()

        if not valid_access_token and valid_refresh_token:
            mock_refresh_access_token.assert_called_once()

        if auto_login and not valid_access_token and not valid_refresh_token:
            mock_login.assert_called_once()
        else:
            mock_login.assert_not_called()

    @pytest.mark.parametrize("new_refresh_token", [None, "new-refresh-token"])
    @pytest.mark.parametrize("existing_refresh_token", [None, "existing-refresh-token"])
    @pytest.mark.parametrize("new_token_is_valid", [False, True])
    @pytest.mark.parametrize("access_token_exists", [False, True])
    def test_set_access_token_sets_token_and_parses(
        self,
        access_token_exists,
        new_token_is_valid,
        existing_refresh_token,
        new_refresh_token,
    ):
        # Setup pre-existing tokens
        existing_access_token = None
        self.auth_client._refresh_token = existing_refresh_token
        self.auth_client._access_token = None
        if access_token_exists:
            existing_access_token = self._generate_token(expiration_seconds=3600)
            self.auth_client._access_token = existing_access_token
            self.auth_client._parse_access_token()

        # Create new token to set (valid or invalid)
        new_access_token = "invalid.token"
        if new_token_is_valid:
            new_access_token = self._generate_token(expiration_seconds=1800)

        # If new token is invalid, we expect ValueError and no change to existing tokens
        expectation = (
            does_not_raise() if new_token_is_valid else pytest.raises(ValueError)
        )
        with expectation:
            self.auth_client.set_access_token(new_access_token, new_refresh_token)

        # We may only check the resolved headers if we have a valid token or a pre-existing one
        if new_token_is_valid or existing_access_token:
            with (
                unittest.mock.patch.object(
                    self.auth_client, "_refresh_token_if_needed"
                ) as mock_refresh_if_needed,
            ):
                request_headers = self.auth_client.enrich_auth_headers({})
                mock_refresh_if_needed.assert_called()

        if new_token_is_valid:
            # New valid token should be set and parsed
            assert self.auth_client.access_token == new_access_token
            assert self.auth_client.access_token != existing_access_token
            assert self.auth_client._expires_at is not None
            assert self.auth_client._access_token_ttl is not None
            assert request_headers["Authorization"] == f"Bearer {new_access_token}"
        elif existing_access_token:
            # Existing token should remain unchanged
            assert self.auth_client.access_token == existing_access_token
            assert request_headers["Authorization"] == f"Bearer {existing_access_token}"

        # Refresh token should be updated only if a new refresh token is provided and the new access token is valid
        expected_refresh_token = (
            new_refresh_token
            if new_token_is_valid and new_refresh_token
            else existing_refresh_token
        )
        assert self.auth_client.refresh_token == expected_refresh_token

    @staticmethod
    def _generate_token(expiration_seconds=3600):
        """Generates a fake JWT token"""

        def _b64encode(obj):
            return (
                base64.urlsafe_b64encode(json.dumps(obj).encode()).rstrip(b"=").decode()
            )

        header = {"alg": "HS256", "typ": "JWT"}
        now = int(time.time())
        sub = random.randint(1, 1000000)
        payload = {
            "sub": str(sub),
            "name": "John Doe",
            "iat": now,
            "exp": now + expiration_seconds,
        }

        jwt = f"{_b64encode(header)}.{_b64encode(payload)}.signature"
        return jwt

    @unittest.mock.patch("builtins.input")
    @unittest.mock.patch.object(
        iguazio.client.auth._AuthClient, "_create_or_update_token_file"
    )
    def test_login_manual_flow(self, mock_create_token_file, mock_input):
        # Setup
        mock_input.return_value = "test-code"

        # Mock http client
        self.auth_client.http_client = unittest.mock.MagicMock()

        # Create a dummy JWT for token response
        dummy_jwt = self._generate_token()

        token_response = {
            "spec": {
                "accessToken": dummy_jwt,
                "refreshToken": "refresh-token",
            }
        }

        # Mock http client response for login-callback
        mock_response = unittest.mock.MagicMock()
        mock_response.json.return_value = token_response
        mock_response.raise_for_status.return_value = None
        self.auth_client.http_client.get.return_value = mock_response

        # Execute
        self.auth_client.login(no_browser=True, offline_access=True)

        # Verify
        mock_input.assert_called_once()

        self.auth_client.http_client.get.assert_called_once()
        call_args = self.auth_client.http_client.get.call_args
        assert "login-callback-manual?code=test-code" in call_args[0][0]

        # Verify tokens are set
        assert self.auth_client.access_token == dummy_jwt
        assert self.auth_client.refresh_token == "refresh-token"

    @unittest.mock.patch("builtins.input")
    def test_login_manual_flow_failure_http_error(self, mock_input):
        # Setup
        mock_input.return_value = "test-code"
        self.auth_client.http_client = unittest.mock.MagicMock()
        self.auth_client.logger = unittest.mock.MagicMock()

        # Mock http client to raise an exception
        self.auth_client.http_client.get.side_effect = Exception("Connection error")

        # Execute
        self.auth_client.login(no_browser=True)

        # Verify
        self.auth_client.logger.error.assert_called_with(
            "Failed to authenticate", exc="Connection error"
        )
        assert self.auth_client.access_token is None

    @unittest.mock.patch("builtins.input")
    def test_login_manual_flow_failure_missing_tokens(self, mock_input):
        # Setup
        mock_input.return_value = "test-code"
        self.auth_client.http_client = unittest.mock.MagicMock()
        self.auth_client.logger = unittest.mock.MagicMock()

        # Mock http client response with missing tokens
        mock_response = unittest.mock.MagicMock()
        mock_response.json.return_value = {"spec": {}}  # Empty spec
        mock_response.raise_for_status.return_value = None
        self.auth_client.http_client.get.return_value = mock_response

        # Execute
        self.auth_client.login(no_browser=True)

        # Verify
        self.auth_client.logger.error.assert_called_with(
            "Failed to authenticate",
            exc="Failed to retrieve access token from response",
        )
        assert self.auth_client.access_token is None
