# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import sys


class HumanReadableFormatter(logging.Formatter):
    def __init__(self):
        super(HumanReadableFormatter, self).__init__()

    def format(self, record):
        # take last 30 chars of logger name, or full name if shorter
        logger_name = record.name[-30:]
        return "{0} {1:30} [{2}] {3}".format(
            self.formatTime(record, self.datefmt),
            logger_name,
            record.levelname.lower(),
            record.getMessage(),
        )


class ColorLoggerFormatter(logging.Formatter):
    RESET = "\033[0m"
    WHITE = 15
    COLOR_CODES = [
        165,  # Rose
        33,  # Blue
        45,  # Teal
        51,  # Cyan
        190,  # Light Yellow-Green
        220,  # Yellow
        208,  # Gold
        196,  # Red
    ]

    LOG_LEVEL_COLORS = {
        logging.DEBUG: 39,  # Light Blue
        logging.INFO: 82,  # Green
        logging.WARNING: 202,  # Orange
        logging.ERROR: 196,  # Red
        logging.CRITICAL: 201,  # Hot Pink
    }

    def __init__(self, fmt=None, datefmt=None):
        super().__init__(fmt=fmt, datefmt=datefmt)
        self.logger_color_map = {}

    def format(self, record):
        level_color = self._ansi_color(
            self.LOG_LEVEL_COLORS.get(record.levelno, self.WHITE)
        )
        record.levelname = f"{level_color}{record.levelname}{self.RESET}"

        name_color = self._get_color_for_logger(record.name)
        record.name = f"{name_color}{record.name}{self.RESET}"

        return super().format(record)

    @staticmethod
    def _ansi_color(code):
        return f"\033[38;5;{code}m"

    def _get_color_for_logger(self, name):
        if name not in self.logger_color_map:
            idx = len(self.logger_color_map) % len(self.COLOR_CODES)
            self.logger_color_map[name] = self._ansi_color(self.COLOR_CODES[idx])
        return self.logger_color_map[name]


class Logger(object):
    def __init__(self, level="DEBUG", logger_name=None, logger=None):
        self._logger = logger or logging.getLogger(
            "root" if not logger_name else logger_name
        )
        self.set_level(level)
        self._handlers = {}

    def set_handler(self, handler_name, file, formatter):
        # check if there's a handler by this name
        if handler_name in self._handlers:
            self._logger.removeHandler(self._handlers[handler_name])

        # create a stream handler from the file
        stream_handler = logging.StreamHandler(file)

        # set the formatter
        stream_handler.setFormatter(formatter)

        # add the handler to the logger
        self._logger.addHandler(stream_handler)

        # save as the named output
        self._handlers[handler_name] = stream_handler

    def set_level(self, level: str):
        self._logger.setLevel(logging.getLevelName(level))

    def get_level(self):
        return self._logger.getEffectiveLevel()

    def get_child(self, name):
        new_logger = Logger(
            logger_name=f"{self._logger.name}.{name}",
            level=logging.getLevelName(self._logger.level),
        )
        new_logger._handlers = self._handlers
        return new_logger

    def debug(self, message, *args, **kwargs):
        if kwargs:
            message = self._add_kw_args_to_message(message, kwargs)
        self._logger.debug(message, *args)

    def info(self, message, *args, **kwargs):
        if kwargs:
            message = self._add_kw_args_to_message(message, kwargs)
        self._logger.info(message, *args)

    def warn(self, message, *args, **kwargs):
        if kwargs:
            message = self._add_kw_args_to_message(message, kwargs)
        self._logger.warning(message, *args)

    def error(self, message, *args, **kwargs):
        if kwargs:
            message = self._add_kw_args_to_message(message, kwargs)
        self._logger.error(message, *args)

    @staticmethod
    def _add_kw_args_to_message(message, kw_args):
        return "{0}: {1}".format(message, kw_args) if kw_args else message


def create_logger(
    level="DEBUG", name="root", logger=None, log_format=None, colors=True
):
    _logger = Logger(level=level, logger_name=name, logger=logger)
    if not logger:
        formatter = HumanReadableFormatter()
        if colors:
            formatter = ColorLoggerFormatter(
                fmt=log_format or "> %(asctime)s [%(levelname)s] %(message)s"
            )
        _logger._logger.handlers.clear()
        _logger.set_handler("stdout", sys.stdout, formatter)
    if _logger._logger.name != name:
        return _logger.get_child(name)
    return _logger
