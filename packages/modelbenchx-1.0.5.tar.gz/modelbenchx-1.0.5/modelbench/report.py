import json
from datetime import datetime


def generate_markdown_report(results, filename="benchmark_report.md"):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = [
        "# ModelBench Performance Report\n",
        f"Generated on: {now}\n",
        "| Model | Avg Latency (ms) | Memory (MB) | Throughput (req/sec) |",
        "|-------|------------------|-------------|-----------------------|",
    ]

    for model_name, metrics in results.items():
        lines.append(
            f"| {model_name} | {metrics['avg_latency_ms']} | "
            f"{metrics['memory_usage_mb']} | "
            f"{metrics['throughput_req_per_sec']} |"
        )

    with open(filename, "w") as f:
        f.write("\n".join(lines))

    return filename


def export_json(results, filename="benchmark_report.json"):
    with open(filename, "w") as f:
        json.dump(results, f, indent=4)

    return filename