from .core import benchmark_model


def compare_models(models_dict, input_data, runs=100):
    results = {}

    for name, model_callable in models_dict.items():
        results[name] = benchmark_model(model_callable, input_data, runs=runs)

    # Sort by avg latency
    sorted_results = dict(
        sorted(results.items(), key=lambda x: x[1]["avg_latency_ms"])
    )

    return sorted_results