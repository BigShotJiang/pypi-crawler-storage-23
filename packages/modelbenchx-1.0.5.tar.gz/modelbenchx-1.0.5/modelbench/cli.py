import argparse
import pickle
from .core import benchmark_model


def main():
    parser = argparse.ArgumentParser(description="ModelBench CLI")
    parser.add_argument("--model", required=True, help="Path to pickled model")
    parser.add_argument("--input", required=True, help="Path to pickled input")
    parser.add_argument("--runs", type=int, default=100)

    args = parser.parse_args()

    with open(args.model, "rb") as f:
        model = pickle.load(f)

    with open(args.input, "rb") as f:
        input_data = pickle.load(f)

    results = benchmark_model(model.predict, input_data, runs=args.runs)

    print("Benchmark Results:")
    for k, v in results.items():
        print(f"{k}: {v}")