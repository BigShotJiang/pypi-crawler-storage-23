from .core import benchmark_model
from .compare import compare_models

__all__ = ["benchmark_model", "compare_models"]