# tests/test_core.py
import numpy as np
from modelbench import benchmark_model

def test_benchmark_returns_expected_keys():
    def dummy(x):
        return x

    result = benchmark_model(dummy, np.array([1]), runs=5)
    assert "avg_latency_ms" in result
    assert "throughput_req_per_sec" in result