import numpy as np
from modelbench import compare_models

def test_compare_models_returns_sorted_results():
    def fast(x): return x
    def slow(x):
        import time
        time.sleep(0.001)
        return x

    results = compare_models(
        {"fast": fast, "slow": slow},
        np.array([1]),
        runs=5
    )

    keys = list(results.keys())
    assert keys[0] == "fast"