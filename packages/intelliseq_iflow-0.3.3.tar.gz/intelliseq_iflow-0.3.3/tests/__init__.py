# CLI E2E tests
