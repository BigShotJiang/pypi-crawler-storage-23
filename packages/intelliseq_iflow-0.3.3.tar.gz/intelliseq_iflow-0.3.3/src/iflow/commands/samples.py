"""Sample commands for iFlow CLI."""

import asyncio
import json

import click

from iflow.api import APIError, MinerAPIClient
from iflow.config import require_project
from iflow.curl import miner_curl


@click.group()
def samples():
    """Manage samples (VCF columns)."""
    pass


@samples.command("list")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.option(
    "--sample-type",
    help="Filter by type (e.g., germline, somatic, ffpe, liquid_biopsy, or any custom type)",
)
@click.option("--limit", default=20, help="Maximum samples to display")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def list_samples(
    project: str | None,
    sample_type: str | None,
    limit: int,
    curl: bool,
):
    """List samples for a project.

    \b
    Examples:
      iflow samples list
      iflow samples list --sample-type germline
    """
    project_id = require_project(project)

    if curl:
        params: dict = {"limit": str(limit)}
        if sample_type:
            params["sample_type"] = sample_type
        print(miner_curl("GET", "/samples", project_id, params=params))
        return

    async def _list():
        client = MinerAPIClient()
        try:
            samples_list = await client.list_samples(
                project_id=project_id,
                sample_type=sample_type,
                limit=limit,
            )

            if not samples_list:
                click.echo("No samples found.")
                return

            click.echo(
                f"{'ID':<40} {'NAME':<25} {'TYPE':<15}"
            )
            click.echo("-" * 80)

            for s in samples_list:
                click.echo(
                    f"{s.id:<40} {s.name:<25} {s.sample_type:<15}"
                )

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_list())


# Model column keys that get promoted to top-level API fields
SAMPLE_MODEL_FIELDS = {
    "sample_type", "external_id", "barcode",
    "tissue", "collection_date", "notes",
}


def _parse_properties(properties: tuple[str, ...], model_fields: set[str]) -> tuple[dict, dict]:
    """Split --property key=value pairs into model fields and JSONB properties."""
    data: dict = {}
    props: dict = {}
    for kv in properties:
        if "=" not in kv:
            raise click.BadParameter(
                f"Invalid format: '{kv}'. Use key=value",
                param_hint="--property",
            )
        k, v = kv.split("=", 1)
        if k in model_fields:
            data[k] = v
        else:
            props[k] = v
    return data, props


@samples.command("create")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.option("--subject-id", required=True, help="Parent subject ID")
@click.option("-n", "--name", required=True, help="Sample name")
@click.option(
    "-P", "--property", "properties", multiple=True,
    help="Property key=value (repeatable). Model keys: sample_type, "
    "external_id, barcode, tissue, collection_date (YYYY-MM-DD), notes",
)
@click.option("--tag", "-t", multiple=True, help="Tag for the sample")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def create_sample(
    project: str | None,
    subject_id: str,
    name: str,
    properties: tuple[str, ...],
    tag: tuple[str, ...],
    curl: bool,
):
    """Create a new sample linked to a subject.

    \b
    All fields except --name and --subject-id are passed via --property/-P key=value:
      iflow samples create --subject-id SUBJ_ID -n "NA12878" -P sample_type=germline
      iflow samples create --subject-id SUBJ_ID -n "Tumor-001" -P sample_type=somatic \\
        -P tissue=lung -P specimen_type=FFPE -P specimen_id=SPEC-001

    \b
    Known model keys (stored as columns): sample_type, external_id,
    barcode, tissue, collection_date (YYYY-MM-DD), notes
    All dates use YYYY-MM-DD format (e.g., 2026-01-15).
    Other keys are stored in properties JSONB: specimen_id, specimen_type, sequencing_date, etc.
    """
    project_id = require_project(project)

    model_data, props = _parse_properties(properties, SAMPLE_MODEL_FIELDS)
    data: dict = {"subject_id": subject_id, "name": name, **model_data}
    if tag:
        data["tags"] = list(tag)
    if props:
        data["properties"] = props

    if curl:
        print(miner_curl("POST", "/samples", project_id, data=data))
        return

    async def _create():
        client = MinerAPIClient()
        try:
            sample = await client.create_sample(
                project_id=project_id,
                subject_id=subject_id,
                name=name,
                sample_type=model_data.get("sample_type", "unknown"),
                external_id=model_data.get("external_id"),
                barcode=model_data.get("barcode"),
                tissue=model_data.get("tissue"),
                notes=model_data.get("notes"),
                tags=list(tag) if tag else None,
                properties=props or None,
            )

            click.echo("Sample created successfully!")
            click.echo(f"  ID: {sample.id}")
            click.echo(f"  Name: {sample.name}")
            click.echo(f"  Type: {sample.sample_type}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_create())


@samples.command("get")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("sample_id")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def get_sample(project: str | None, sample_id: str, curl: bool):
    """Get details of a sample.

    SAMPLE_ID is the sample identifier.
    """
    project_id = require_project(project)

    if curl:
        print(miner_curl("GET", f"/samples/{sample_id}", project_id))
        return

    async def _get():
        client = MinerAPIClient()
        try:
            sample = await client.get_sample(project_id, sample_id)

            click.echo(f"Sample: {sample.name}")
            click.echo(f"  ID: {sample.id}")
            click.echo(f"  Subject ID: {sample.subject_id}")
            click.echo(f"  Type: {sample.sample_type}")

            if sample.external_id:
                click.echo(f"  External ID: {sample.external_id}")
            if sample.barcode:
                click.echo(f"  Barcode: {sample.barcode}")
            if sample.tissue:
                click.echo(f"  Tissue: {sample.tissue}")
            if sample.notes:
                click.echo(f"  Notes: {sample.notes}")
            if sample.created_at:
                click.echo(f"  Created: {sample.created_at}")
            if sample.tags:
                click.echo(f"  Tags: {', '.join(sample.tags)}")
            if sample.properties:
                click.echo("  Properties:")
                for k, v in sample.properties.items():
                    click.echo(f"    {k}: {v}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_get())


@samples.command("delete")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("sample_id")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
@click.confirmation_option(prompt="Are you sure you want to delete this sample?")
def delete_sample(project: str | None, sample_id: str, curl: bool):
    """Delete a sample.

    SAMPLE_ID is the sample identifier.
    """
    project_id = require_project(project)

    if curl:
        print(miner_curl("DELETE", f"/samples/{sample_id}", project_id))
        return

    async def _delete():
        client = MinerAPIClient()
        try:
            await client.delete_sample(project_id, sample_id)
            click.echo(f"Sample {sample_id} deleted.")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_delete())


@samples.command("sampleinfo")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("sample_id")
@click.option("--order-id", help="Order ID for additional context")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def get_sampleinfo(project: str | None, sample_id: str, order_id: str | None, curl: bool):
    """Generate sampleinfo JSON for pipeline submission.

    \b
    Returns flat dict of pipeline optional_inputs from subject + sample metadata.
    Output can be piped into iflow runs submit --input-json.

    \b
    Examples:
      iflow samples sampleinfo SAMPLE_ID
      iflow samples sampleinfo SAMPLE_ID --order-id ORDER_ID
      iflow runs submit --pipeline hereditary-mock \\
        --input-json "$(iflow samples sampleinfo SAMPLE_ID)"
    """
    project_id = require_project(project)

    if curl:
        params = {}
        if order_id:
            params["order_id"] = order_id
        print(miner_curl("GET", f"/samples/{sample_id}/sampleinfo", project_id, params=params))
        return

    async def _sampleinfo():
        client = MinerAPIClient()
        try:
            data = await client.get_sampleinfo(project_id, sample_id, order_id=order_id)
            click.echo(json.dumps(data, indent=2))
        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_sampleinfo())
