from __future__ import annotations

from .basic import MATH_BASIC_DECLARATIONS

__all__ = ["MATH_BASIC_DECLARATIONS"]
