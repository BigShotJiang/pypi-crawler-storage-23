from __future__ import annotations

from .core import STAT_CORE_DECLARATIONS

__all__ = ["STAT_CORE_DECLARATIONS"]
