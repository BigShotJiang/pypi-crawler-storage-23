from .main import main
import sys

sys.exit(main())
