"""
Django migrations for UniPay UZ.
"""
