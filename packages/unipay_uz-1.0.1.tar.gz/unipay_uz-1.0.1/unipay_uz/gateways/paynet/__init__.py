from unipay_uz.gateways.paynet.client import PaynetGateway

__all__ = ['PaynetGateway']
