"""
.. include:: ../../README.md
"""

from treeIDW.treeIDW import treeIDW
