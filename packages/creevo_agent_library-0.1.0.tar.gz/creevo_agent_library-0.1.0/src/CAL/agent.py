"""
Agent classes for CAL with OpenTelemetry tracing
"""
import os
import time
import sys
import json
import asyncio
import queue
from typing import List, Optional

from .logger import Logger
from .llm import LLM
from .tool import Tool
from .message import Message, MessageRole
from .content_blocks import ToolResultBlock, TextBlock, ToolUseBlock
from .memory import Memory

PROGRESS_PREFIX = "__AGENT_PROGRESS__"

def emit_progress(agent_name: str, event: str, message: str, detail: dict = None):
    """Emit a progress event to stdout for Node.js to capture and forward to frontend."""
    payload = {
        "agent_name": agent_name,
        "event": event,
        "message": message,
        "detail": detail or {},
        "timestamp": time.time(),
    }
    print(f"{PROGRESS_PREFIX}{json.dumps(payload)}", flush=True)


class Agent:
    """Agent class with custom tracing"""
    
    def __init__(
        self,
        llm: LLM,
        system_prompt: str,
        max_calls: int,
        max_tokens: int,
        memory: Memory,
        agent_name: str,
        tools: Optional[List[Tool]] = None,
        logger: Optional[Logger] = None,
    ):
        """
        Initialize the agent.
        
        Args:
            llm: The LLM instance to use for generating responses
            system_prompt: System prompt defining the agent's behavior
            max_calls: Maximum number of tool calls allowed per run
            max_tokens: Maximum tokens for LLM generation
            memory: Memory instance for conversation history (e.g., FullCompressionMemory)
            agent_name: Name identifier for the agent (used in logging)
            tools: Optional list of tools to register with the agent
            logger: Optional Logger instance for tracing and observability
        """
        self.llm = llm
        self.tools: List[Tool] = tools if tools is not None else []
        self.system_prompt = system_prompt
        self.max_calls = max_calls
        self.max_tokens = max_tokens
        self.memory = memory
        self.agent_name = agent_name
        self.logger = logger
        self._context_queue = queue.Queue()

        # Bind SubAgentTools to this agent for context access
        # We do the import here at runtime to avoid circular imports at module load time
        from .subagent import SubAgentTool
        for tool in self.tools:
            if isinstance(tool, SubAgentTool):
                tool.bind_parent(self)

        # Initialize logger metadata
        if self.logger:
            self.logger.log_metadata({
                "system_prompt": self.system_prompt,
                "agent_name": self.agent_name
            })
        
    def register_tool(self, tool: Tool):
        """
        Register a tool with the agent.
        
        Args:
            tool: The tool to register
        """
        self.tools.append(tool)
    
    @property
    def conversation_history(self) -> List[Message]:
        """Expose current conversation history."""
        return self.memory.get_history()
    
    
    def _history_json(self) -> str:
        """Return the serialized conversation history."""
        return self.memory.to_json()
    
    def _parse_tool_uses(self, message: Message) -> List[ToolUseBlock]:
        """
        Extract ToolUseBlocks from message content.
        
        Args:
            message: The message to parse
            
        Returns:
            List of ToolUseBlock objects
        """
        tool_uses = []
        if isinstance(message.content, list):
            for block in message.content:
                if isinstance(block, ToolUseBlock):
                    tool_uses.append(block)
        return tool_uses
    
    def _find_tool(self, name: str) -> Optional[Tool]:
        """
        Find a tool by name in the registry.
        Normalizes names by replacing hyphens with underscores for matching.
        
        Args:
            name: Name of the tool to find
            
        Returns:
            Tool instance or None if not found
        """
        normalized_name = name.replace('-', '_')
        for tool in self.tools:
            if tool.name.replace('-', '_') == normalized_name:
                return tool
        return None
    
    async def _execute_tools(self, tool_uses: List[ToolUseBlock]) -> List[ToolResultBlock]:
        """
        Execute tools and return results.
        Captures start/end times for each tool execution.
        """
        results = []
        for tool_use in tool_uses:
            tool = self._find_tool(tool_use.name)
            
            start_time = time.time_ns()
            
            if tool is None:
                result = ToolResultBlock(
                    tool_use_id=tool_use.id,
                    content=f"Error: Tool '{tool_use.name}' not found",
                    is_error=True,
                    name=tool_use.name
                )
            else:
                result = await tool.execute(tool_use_id=tool_use.id, **tool_use.input)
            
            end_time = time.time_ns()
            
            # Log tool response
            if self.logger:
                self.logger.log_tool_response(
                    tool_use, 
                    result,
                    start_time=start_time,
                    end_time=end_time
                )
                
            results.append(result)
        
        return results

    def _extract_final_output(self) -> str:
        """Helper to find the last meaningful output for the trace result. If no output is found, return an empty string."""
        # Check reverse history for the most recent relevant result
        for message in reversed(self.memory.get_history()):
            if message.role == MessageRole.USER and isinstance(message.content, list):
                for block in message.content:
                    if isinstance(block, ToolResultBlock) and block.metadata:
                        if "full_span_output" in block.metadata:
                            return block.metadata["full_span_output"]
                    
        return ""
    
    def _has_tool_calls(self, message: Message) -> bool:
        """Check if a message contains tool calls."""
        if message.role != MessageRole.ASSISTANT:
            return False
        if isinstance(message.content, str):
            return False
        return any(isinstance(block, ToolUseBlock) for block in message.content)
    
    def push_context(self, context: str) -> None:
        """Push additional context into the agent. Thread-safe.
        Injected as a USER message before the next LLM call."""
        self._context_queue.put(context)

    def _cleanup_incomplete_conversation(self):
        """
        Remove incomplete conversation sequences from memory.
        If the last message is an assistant message with tool calls,
        remove it since it's incomplete (no tool responses followed).
        """
        history = self.memory.get_history()
        if not history:
            return
        
        last_message = history[-1]
        if self._has_tool_calls(last_message):
            # Remove the incomplete assistant message with tool calls
            # This can happen if conversation history was saved mid-execution
            self.memory._messages.pop()
    
    
    async def run_async(self, user_prompt: str) -> Message:
        """
        Run the agent with the given user prompt (async version).
        Implements agentic loop: LLM -> Tool -> LLM -> ...
        """
        assert self.max_calls > 0, "max_calls must be positive"
        
        # Clean up any incomplete conversation sequences (e.g., from mid-execution saves)
        self._cleanup_incomplete_conversation()

        # Unified retry counter for all recoverable errors (LLM errors, malformed calls, no tool calls)
        max_retries = 10
        retries = 0
        error_streak = 0  # consecutive API errors, used for backoff delay calculation
        
        emit_progress(self.agent_name, "start", "Got your request, analyzing...")
        
        # Start Trace
        if self.logger:
            self.logger.start_trace("agent.run", user_prompt)

        # Add user message to conversation history
        user_message = Message(role=MessageRole.USER, content=[TextBlock(text=user_prompt)])
        self.memory.add_message(user_message)
        
        iteration = 0
        last_agent_message = None
        workflow_status = "completed_success"
        
        try:
            while iteration < self.max_calls:

                # Drain any externally pushed context.
                # Appends to the last message when it's already USER-role
                # (e.g. after tool results) to avoid consecutive USER messages
                # which violate Gemini's strict role alternation.
                pushed_blocks = []
                while True:
                    try:
                        pushed_blocks.append(TextBlock(text=self._context_queue.get_nowait()))
                    except queue.Empty:
                        break
                if pushed_blocks:
                    history = self.memory.get_history()
                    if history and history[-1].role == MessageRole.USER:
                        last_msg = self.memory._messages[-1]
                        if isinstance(last_msg.content, list):
                            last_msg.content.extend(pushed_blocks)
                        else:
                            last_msg.content = [TextBlock(text=last_msg.content)] + pushed_blocks
                    else:
                        self.memory.add_message(
                            Message(role=MessageRole.USER, content=pushed_blocks)
                        )

                # Step 1: Generate LLM response with Timing
                emit_progress(
                    self.agent_name,
                    "llm_start",
                    f"Step {iteration + 1}: Thinking...",
                    {"iteration": iteration}
                )
                llm_start_time = time.time_ns()
                
                # Attempt LLM call with retry on errors
                try:
                    agent_message = self.llm.generate_content(
                        self.system_prompt,
                        self.memory.get_history(),
                        self.tools,
                    )
                except Exception as e:
                    retries += 1
                    error_streak += 1
                    if retries < max_retries:
                        delay = min(2 ** (error_streak - 1), 60)
                        print(f"LLM error: {e}, retry {retries}/{max_retries} after {delay}s", file=sys.stderr)
                        await asyncio.sleep(delay)
                        continue
                    raise RuntimeError(f"LLM call failed after {max_retries} retries: {e}") from e
                
                llm_end_time = time.time_ns()
                last_agent_message = agent_message
                
                emit_progress(
                    self.agent_name,
                    "llm_end",
                    f"Step {iteration + 1}: Planning complete.",
                    {"iteration": iteration}
                )
                
                # Log LLM response
                if self.logger:
                    self.logger.log_llm_response(
                        agent_message,
                        iteration,
                        model=self.llm.name,
                        provider=self.llm.provider,
                        start_time=llm_start_time,
                        end_time=llm_end_time
                    )

                # Sync memory token count with actual LLM usage.
                # This ensures compression triggers based on real context size (including
                # system prompt and tool schemas), not just estimated message content tokens.
                if agent_message.usage and 'prompt_tokens' in agent_message.usage:
                    self.memory.sync_token_count_from_llm_usage(agent_message.usage['prompt_tokens'])

                # Check for error finish reasons before adding to history
                if hasattr(agent_message, 'metadata') and agent_message.metadata:
                    finish_reason = agent_message.metadata.get('finish_reason')
                    if finish_reason and 'MAX_TOKENS' in finish_reason:
                        self.memory.add_message(agent_message)
                        workflow_status = "completed_max_tokens"
                        print("Hit MAX_TOKENS, stopping agent loop", file=sys.stderr)
                        break
                    
                    # Handle MALFORMED_FUNCTION_CALL by retrying
                    if finish_reason and 'MALFORMED_FUNCTION_CALL' in finish_reason:
                        retries += 1
                        error_streak += 1
                        if retries < max_retries:
                            delay = min(2 ** (error_streak - 1), 60)
                            print(f"MALFORMED_FUNCTION_CALL detected, retry {retries}/{max_retries} after {delay}s", file=sys.stderr)
                            await asyncio.sleep(delay)
                            continue
                        self.memory.add_message(agent_message)
                        print("MALFORMED_FUNCTION_CALL: max retries reached, stopping", file=sys.stderr)
                        workflow_status = "error_malformed_function_call"
                        break
                

                # Successful LLM response — reset backoff streak
                error_streak = 0

                # Step 2: Add agent message to conversation history
                self.memory.add_message(agent_message)
                
                # Step 3: Parse tool uses
                tool_uses = self._parse_tool_uses(agent_message)
                
                # If no tools returned but stop hasn't been called, prompt the LLM to continue
                if not tool_uses:
                    retries += 1
                    if retries < max_retries:
                        print(f"No tool calls returned, prompting to continue ({retries}/{max_retries})", file=sys.stderr)
                        prompt_message = Message(
                            role=MessageRole.USER, 
                            content=[TextBlock(text="Continue with your task. You must use tool calls to make progress. When you are done, use the stop tool.")]
                        )
                        self.memory.add_message(prompt_message)
                        iteration += 1
                        continue
                    print("No tool calls after max prompts, stopping", file=sys.stderr)
                    workflow_status = "completed_no_tools"
                    break
                
                # Reset retries on successful tool use
                retries = 0
                
                emit_progress(
                    self.agent_name,
                    "tool_start",
                    f"Step {iteration + 1}: Running tools...",
                    {
                        "iteration": iteration,
                        "tools": [tu.name for tu in tool_uses],
                    }
                )
                
                # Step 4: Execute tools (Internal logic handles timing logging)
                tool_results = await self._execute_tools(tool_uses)
                
                emit_progress(
                    self.agent_name,
                    "tool_end",
                    f"Step {iteration + 1}: Tools complete.",
                    {
                        "iteration": iteration,
                        "tools": [tu.name for tu in tool_uses],
                    }
                )
                
                # Step 5: Check if stop was called
                stop_called = any(tu.name == "stop" for tu in tool_uses)
                
                # Step 6: Add results to history
                tool_message = Message(role=MessageRole.USER, content=tool_results)
                self.memory.add_message(tool_message)
                
                if stop_called:
                    workflow_status = "completed_stop"
                    break
                
                iteration += 1
                
            if iteration >= self.max_calls:
                workflow_status = "completed_max_iterations"
                
        except Exception as e:
            workflow_status = f"error: {str(e)}"
            raise e
        finally:
            status_msg = {
                "completed_success": "Almost done – finalizing...",
                "completed_no_tools": "Finished reasoning.",
                "completed_max_tokens": "Reached internal limit, finishing up...",
                "completed_max_iterations": "Finished maximum number of planning steps.",
                "completed_stop": "Task completed.",
                "error_malformed_function_call": "Encountered an error, finishing up...",
            }.get(workflow_status, "Wrapping up...")

            emit_progress(
                self.agent_name,
                "complete",
                status_msg,
                {"workflow_status": workflow_status}
            )
            
            # End Trace
            if self.logger:
                final_output = self._extract_final_output()
                
                # Fallback: if extractor failed but we have a message, try to stringify safely
                if not final_output and last_agent_message:
                     content = last_agent_message.content
                     if isinstance(content, list):
                         # Robust string extraction from blocks
                         parts = []
                         for x in content:
                             if hasattr(x, 'text'):
                                 parts.append(x.text)
                             else:
                                 parts.append(str(x))
                         final_output = " ".join(parts)
                     else:
                         final_output = str(content)

                self.logger.end_trace(
                    output=str(final_output),
                    metadata={
                        "status": workflow_status,
                        "total_iterations": iteration
                    }
                )

            # Discard any context pushed after the last drain so it doesn't
            # leak into a subsequent run_async call on the same agent.
            while not self._context_queue.empty():
                self._context_queue.get_nowait()

        # last_agent_message is guaranteed to be set since max_calls > 0
        return last_agent_message


    def run(self, user_prompt: str) -> Message:
        """
        Sync wrapper for run_async.
        Safely handles existing event loops to prevent RuntimeError.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            raise RuntimeError(
                "Agent.run() was called from a running event loop. "
                "Use 'await agent.run_async()' instead."
            )
        
        try:
            return asyncio.run(self.run_async(user_prompt))
        except Exception as e:
            raise RuntimeError(f"Agent execution failed: {e}") from e