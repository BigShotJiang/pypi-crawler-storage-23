"""Marketplace validators for ai-config."""
