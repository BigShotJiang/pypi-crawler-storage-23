"""Component validators for ai-config (skills, hooks, MCPs)."""
