---
name: nested-skill
description: A skill nested inside a category directory
allowed-tools:
  - Read
  - Glob
---

# Nested Skill

This skill demonstrates nested directory support.

## Features

- Lives inside a category directory
- Should be discovered by recursive parsing
- Has resources in a subdirectory
