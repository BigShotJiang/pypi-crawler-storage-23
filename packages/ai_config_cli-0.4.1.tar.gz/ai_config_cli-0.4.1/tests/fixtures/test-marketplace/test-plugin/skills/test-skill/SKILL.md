---
name: test-skill
description: A test skill for marketplace validation
---

# Test Skill

This is a fixture skill for marketplace validation.
