"""End-to-end tests for ai-config using Docker containers."""
