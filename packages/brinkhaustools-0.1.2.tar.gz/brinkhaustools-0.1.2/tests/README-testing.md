# Testing brinkhaustools

## How to run

```bash
# Activate venv
source .venv/bin/activate

# Run all tests (standard way)
python tests/run-tests.py

# Or directly with pytest
pytest tests/ -v --timeout=30
```

## What is tested

| Test file | Module | What it covers |
|-----------|--------|----------------|
| `test_diagnosis.py` | `SelfDiagnosisEngine` | Notify, deduplicate, clear, timeout, critical status, status format |
| `test_heartbeat.py` | `HeartbeatEngine` | Register, timeout detection, refresh, cancel, status reporting |
| `test_logging.py` | `LoggingHelper` | Ring buffer handler, log directory creation |
| `test_settings.py` | `Settings` | Get/set, dot notation, arrays, delete, move, reload, JSON, env vars, type compat |
| `test_shutdown.py` | `ShutdownHandler` | Trigger, delay, hooks, interruptible sleep, event property |
| `test_status.py` | `StatusEngine` | Register sources, collect, deduplication, refresh timing |
| `test_version.py` | `VersionInformation` | Load from file, defaults on missing, StatusSource interface |
| `test_fleet_client.py` | `FleetMonitorClient` | URL construction, slugify, heartbeat/diagnostics/status sending, connection callbacks, auth headers |
| `test_fleet_monitor.py` | `StatusMonitor` | Config reading, env overrides, diagnosis mapping, connection status |
| `test_fleet_integration.py` | Fleet end-to-end | Roundtrip tests (skipped without live fleetmanager) |

## Not yet tested

- `rest/server.py` (RestServer) — needs Flask test client

## Reports

`run-tests.py` produces:
- **Text output** to stdout (verbose, shows each test and result)
- **JUnit XML** at `tests/reports/junit.xml`

The `tests/reports/` directory is gitignored.

## CI

Tests run automatically on every push and merge request. See `.gitlab-ci.yml`.
