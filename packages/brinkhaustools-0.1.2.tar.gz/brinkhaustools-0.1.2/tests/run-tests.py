#!/usr/bin/env python3
"""Standard test runner for brinkhaustools.

Runs all tests with verbose text output and JUnit XML report.

Usage:
    python tests/run-tests.py
"""
import subprocess
import sys
import os

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPORT_DIR = os.path.join(REPO_ROOT, "tests", "reports")


def main():
    os.makedirs(REPORT_DIR, exist_ok=True)

    cmd = [
        sys.executable, "-m", "pytest",
        os.path.join(REPO_ROOT, "tests"),
        "-v",
        "--timeout=30",
        f"--junitxml={os.path.join(REPORT_DIR, 'junit.xml')}",
    ]
    # Forward any extra arguments (e.g. -k, --tb, -x)
    cmd.extend(sys.argv[1:])

    result = subprocess.run(cmd, cwd=REPO_ROOT)
    sys.exit(result.returncode)


if __name__ == "__main__":
    main()
