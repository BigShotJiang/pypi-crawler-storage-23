"""Tests for HeartbeatEngine."""

import time

from brinkhaustools.common.heartbeat import HeartbeatEngine


def test_register_and_ok():
    h = HeartbeatEngine(default_timeout_sec=10)
    h.register("worker-1")
    assert h.heartbeats_ok()


def test_timeout_detected():
    h = HeartbeatEngine(default_timeout_sec=0.1)
    h.register("worker-1")
    time.sleep(0.2)
    assert not h.heartbeats_ok()


def test_refresh_heartbeat():
    h = HeartbeatEngine(default_timeout_sec=0.2)
    h.register("worker-1")
    time.sleep(0.1)
    h.register("worker-1")  # Refresh
    time.sleep(0.1)
    assert h.heartbeats_ok()


def test_cancel():
    h = HeartbeatEngine(default_timeout_sec=0.1)
    h.register("worker-1")
    h.cancel("worker-1")
    time.sleep(0.2)
    assert h.heartbeats_ok()


def test_get_status():
    h = HeartbeatEngine(default_timeout_sec=300)
    h.register("worker-1")
    status = h.get_status()
    assert "Entry 1" in status
    assert "worker-1" in status["Entry 1"]


def test_get_name():
    h = HeartbeatEngine()
    assert h.get_name() == "Heartbeat manager"
