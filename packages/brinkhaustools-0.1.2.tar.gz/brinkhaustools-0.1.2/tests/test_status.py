"""Tests for StatusEngine and StatusSource."""

from brinkhaustools.common.status import StatusEngine, StatusSource


class DummySource(StatusSource):
    def __init__(self, name: str, value: str):
        super().__init__(refresh_time_sec=5)
        self._name = name
        self._value = value

    def get_status(self):
        return {"value": self._value}

    def get_name(self):
        return self._name


def test_register_and_collect():
    engine = StatusEngine()
    src = DummySource("test", "hello")
    engine.register_source(src)
    # Force the elapsed time so it collects
    src._elapsed_since_refresh = 100
    result = engine.collect()
    assert "test" in result
    assert result["test"]["value"] == "hello"


def test_get_last_status_empty():
    engine = StatusEngine()
    assert engine.get_last_status() == {}


def test_no_duplicate_sources():
    engine = StatusEngine()
    src = DummySource("a", "1")
    engine.register_source(src)
    engine.register_source(src)
    assert len(engine._sources) == 1


def test_collection_respects_refresh_time():
    engine = StatusEngine()
    src = DummySource("slow", "data")
    src._refresh_time_sec = 600  # Much larger than collection interval
    engine.register_source(src)
    # First collect increments elapsed by collection_interval (5-60),
    # which is still < 600, so source should be skipped
    engine.collect()
    assert "slow" not in engine.get_last_status()
