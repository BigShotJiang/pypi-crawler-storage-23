#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Production Multilingual TTS Normalizer
======================================

Supports: Vietnamese, English, Chinese, Japanese, Korean, French, German

Reuses:
- abbrev.py: 1,368 abbreviations across 7 languages  
- synth_normalizer_v2.py: All datetime/month/weekday definitions

Target: < 1ms per sentence on CPU (TTFA budget: 200ms)

Author: HATTO AI
"""

import re
import unicodedata
from typing import Dict, List, Tuple, Optional, Callable
from dataclasses import dataclass
from functools import lru_cache
import time

# =============================================================================
# IMPORT FROM EXISTING MODULES
# =============================================================================

# Import abbreviations from abbrev.py (structure: VI={}, EN={}, etc.)
try:
    try:
        # Package mode: relative import (pip install)
        from .abbrev import VI as ABBREV_VI, EN as ABBREV_EN, ZH as ABBREV_ZH
        from .abbrev import JA as ABBREV_JA, KO as ABBREV_KO, FR as ABBREV_FR, DE as ABBREV_DE
    except ImportError:
        # Standalone mode: both files in same folder
        from abbrev import VI as ABBREV_VI, EN as ABBREV_EN, ZH as ABBREV_ZH
        from abbrev import JA as ABBREV_JA, KO as ABBREV_KO, FR as ABBREV_FR, DE as ABBREV_DE
    
    ABBREV_DICT = {
        "vi": ABBREV_VI,
        "en": ABBREV_EN,
        "zh": ABBREV_ZH,
        "ja": ABBREV_JA,
        "ko": ABBREV_KO,
        "fr": ABBREV_FR,
        "de": ABBREV_DE,
    }
except ImportError:
    print("Warning: abbrev.py not found, abbreviations disabled")
    ABBREV_DICT = {}

# Complete fallback definitions for standalone operation
MONTHS = {
    "vi": ["tháng một", "tháng hai", "tháng ba", "tháng tư", "tháng năm", "tháng sáu",
           "tháng bảy", "tháng tám", "tháng chín", "tháng mười", "tháng mười một", "tháng mười hai"],
    "en": ["January", "February", "March", "April", "May", "June",
           "July", "August", "September", "October", "November", "December"],
    "zh": ["一月", "二月", "三月", "四月", "五月", "六月",
           "七月", "八月", "九月", "十月", "十一月", "十二月"],
    "ja": ["一月", "二月", "三月", "四月", "五月", "六月",
           "七月", "八月", "九月", "十月", "十一月", "十二月"],
    "ko": ["일월", "이월", "삼월", "사월", "오월", "유월",
           "칠월", "팔월", "구월", "시월", "십일월", "십이월"],
    "fr": ["janvier", "février", "mars", "avril", "mai", "juin",
           "juillet", "août", "septembre", "octobre", "novembre", "décembre"],
    "de": ["Januar", "Februar", "März", "April", "Mai", "Juni",
           "Juli", "August", "September", "Oktober", "November", "Dezember"],
}
MONTHS_SHORT = {
    "vi": ["Th1", "Th2", "Th3", "Th4", "Th5", "Th6", "Th7", "Th8", "Th9", "Th10", "Th11", "Th12"],
    "en": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    "zh": ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
    "ja": ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
    "ko": ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"],
    "fr": ["jan", "fév", "mar", "avr", "mai", "jun", "jul", "aoû", "sep", "oct", "nov", "déc"],
    "de": ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"],
}
WEEKDAYS = {
    "vi": ["thứ hai", "thứ ba", "thứ tư", "thứ năm", "thứ sáu", "thứ bảy", "chủ nhật"],
    "en": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    "zh": ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"],
    "ja": ["月曜日", "火曜日", "水曜日", "木曜日", "金曜日", "土曜日", "日曜日"],
    "ko": ["월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"],
    "fr": ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"],
    "de": ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"],
}
LUNAR_TERMS = {}
TIME_PERIODS = {
    "vi": {"sáng": (5, 11), "trưa": (11, 13), "chiều": (13, 18), "tối": (18, 22), "đêm": (22, 5)},
    "en": {"morning": (5, 12), "afternoon": (12, 17), "evening": (17, 21), "night": (21, 5)},
}
LONG_SENTENCE_CONNECTORS = {}


# =============================================================================
# NUMBER TO WORDS - ALL LANGUAGES
# =============================================================================

# Vietnamese
VI_ONES = ["", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín"]
VI_TENS = ["", "mười", "hai mươi", "ba mươi", "bốn mươi", "năm mươi",
           "sáu mươi", "bảy mươi", "tám mươi", "chín mươi"]

# English  
EN_ONES = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
           "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen",
           "seventeen", "eighteen", "nineteen"]
EN_TENS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]

# Chinese (Native characters - TTS reads Chinese directly)
ZH_DIGITS = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九"]

# Japanese (Native characters - TTS reads Japanese directly)
JA_DIGITS = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九"]

# Korean (Native Sino-Korean - TTS reads Korean directly)  
KO_DIGITS = ["영", "일", "이", "삼", "사", "오", "육", "칠", "팔", "구"]

# French
FR_ONES = ["", "un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf",
           "dix", "onze", "douze", "treize", "quatorze", "quinze", "seize"]
FR_TENS = ["", "dix", "vingt", "trente", "quarante", "cinquante", 
           "soixante", "soixante", "quatre-vingt", "quatre-vingt"]

# German
DE_ONES = ["", "eins", "zwei", "drei", "vier", "fünf", "sechs", "sieben", "acht", "neun"]
DE_TENS = ["", "zehn", "zwanzig", "dreißig", "vierzig", "fünfzig",
           "sechzig", "siebzig", "achtzig", "neunzig"]


def _vi_three_digits(n: int, leading: bool = False) -> str:
    """Convert 0-999 to Vietnamese."""
    if n == 0:
        return ""
    hundreds, remainder = divmod(n, 100)
    tens, ones = divmod(remainder, 10)
    
    parts = []
    if hundreds > 0:
        parts.append(f"{VI_ONES[hundreds]} trăm")
    
    if tens == 0 and ones > 0 and (hundreds > 0 or leading):
        parts.append(f"lẻ {VI_ONES[ones]}")
    elif tens == 1:
        if ones == 0:
            parts.append("mười")
        elif ones == 5:
            parts.append("mười lăm")
        else:
            parts.append(f"mười {VI_ONES[ones]}")
    elif tens > 1:
        if ones == 0:
            parts.append(VI_TENS[tens])
        elif ones == 1:
            parts.append(f"{VI_TENS[tens]} mốt")
        elif ones == 4:
            parts.append(f"{VI_TENS[tens]} tư")
        elif ones == 5:
            parts.append(f"{VI_TENS[tens]} lăm")
        else:
            parts.append(f"{VI_TENS[tens]} {VI_ONES[ones]}")
    elif ones > 0 and not leading:
        parts.append(VI_ONES[ones])
    
    return " ".join(parts)


@lru_cache(maxsize=50000)
def num_to_vietnamese(n: int) -> str:
    """Convert integer to Vietnamese words."""
    if n == 0:
        return "không"
    if n < 0:
        return f"âm {num_to_vietnamese(-n)}"
    if n >= 10**15:
        return str(n)
    
    if n < 1000:
        return _vi_three_digits(n)
    
    parts = []
    if n >= 10**9:  # Tỷ
        ty, n = divmod(n, 10**9)
        parts.append(f"{_vi_three_digits(ty)} tỷ")
    if n >= 10**6:  # Triệu
        trieu, n = divmod(n, 10**6)
        if trieu > 0:
            parts.append(f"{_vi_three_digits(trieu, bool(parts))} triệu")
    if n >= 1000:  # Nghìn
        nghin, n = divmod(n, 1000)
        if nghin > 0:
            parts.append(f"{_vi_three_digits(nghin, bool(parts))} nghìn")
    if n > 0:
        parts.append(_vi_three_digits(n, bool(parts)))
    
    return " ".join(parts)


@lru_cache(maxsize=50000)
def num_to_english(n: int) -> str:
    """Convert integer to English words."""
    if n == 0:
        return "zero"
    if n < 0:
        return f"minus {num_to_english(-n)}"
    if n < 20:
        return EN_ONES[n]
    if n < 100:
        tens, ones = divmod(n, 10)
        return f"{EN_TENS[tens]}-{EN_ONES[ones]}" if ones else EN_TENS[tens]
    if n < 1000:
        h, r = divmod(n, 100)
        return f"{EN_ONES[h]} hundred" + (f" and {num_to_english(r)}" if r else "")
    if n < 1000000:
        th, r = divmod(n, 1000)
        return f"{num_to_english(th)} thousand" + (f" {num_to_english(r)}" if r else "")
    if n < 10**9:
        m, r = divmod(n, 10**6)
        return f"{num_to_english(m)} million" + (f" {num_to_english(r)}" if r else "")
    if n < 10**12:
        b, r = divmod(n, 10**9)
        return f"{num_to_english(b)} billion" + (f" {num_to_english(r)}" if r else "")
    return str(n)


@lru_cache(maxsize=50000)
def num_to_chinese(n: int) -> str:
    """Convert integer to Chinese characters (NOT Pinyin - TTS reads Chinese)."""
    if n == 0:
        return "零"
    if n < 0:
        return f"负{num_to_chinese(-n)}"
    if n < 10:
        return ZH_DIGITS[n]
    if n < 100:
        tens, ones = divmod(n, 10)
        if tens == 1:
            result = "十"
        else:
            result = f"{ZH_DIGITS[tens]}十"
        if ones:
            result += ZH_DIGITS[ones]
        return result
    if n < 1000:
        h, r = divmod(n, 100)
        result = f"{ZH_DIGITS[h]}百"
        if r:
            if r < 10:
                result += f"零{ZH_DIGITS[r]}"
            else:
                result += num_to_chinese(r)
        return result
    if n < 10000:
        th, r = divmod(n, 1000)
        result = f"{ZH_DIGITS[th]}千"
        if r:
            if r < 100:
                result += f"零{num_to_chinese(r)}"
            else:
                result += num_to_chinese(r)
        return result
    if n < 100000000:  # < 1亿
        wan, r = divmod(n, 10000)
        result = f"{num_to_chinese(wan)}万"
        if r:
            if r < 1000:
                result += f"零{num_to_chinese(r)}"
            else:
                result += num_to_chinese(r)
        return result
    if n < 1000000000000:  # < 1兆
        yi, r = divmod(n, 100000000)
        result = f"{num_to_chinese(yi)}亿"
        if r:
            result += num_to_chinese(r)
        return result
    return str(n)


@lru_cache(maxsize=50000)
def num_to_japanese(n: int) -> str:
    """Convert integer to Japanese characters (NOT Romaji - TTS reads Japanese)."""
    if n == 0:
        return "零"
    if n < 0:
        return f"マイナス{num_to_japanese(-n)}"
    if n < 10:
        return JA_DIGITS[n]
    if n < 100:
        tens, ones = divmod(n, 10)
        if tens == 1:
            result = "十"
        else:
            result = f"{JA_DIGITS[tens]}十"
        if ones:
            result += JA_DIGITS[ones]
        return result
    if n < 1000:
        h, r = divmod(n, 100)
        if h == 1:
            result = "百"
        else:
            result = f"{JA_DIGITS[h]}百"
        if r:
            result += num_to_japanese(r)
        return result
    if n < 10000:
        th, r = divmod(n, 1000)
        if th == 1:
            result = "千"
        else:
            result = f"{JA_DIGITS[th]}千"
        if r:
            result += num_to_japanese(r)
        return result
    if n < 100000000:
        man, r = divmod(n, 10000)
        result = f"{num_to_japanese(man)}万"
        if r:
            result += num_to_japanese(r)
        return result
    return str(n)


@lru_cache(maxsize=50000)
def num_to_korean(n: int) -> str:
    """Convert integer to Korean Sino-Korean numerals."""
    if n == 0:
        return "영"
    if n < 0:
        return f"마이너스 {num_to_korean(-n)}"
    if n < 10:
        return KO_DIGITS[n]
    if n < 100:
        tens, ones = divmod(n, 10)
        if tens == 1:
            result = "십"
        else:
            result = f"{KO_DIGITS[tens]}십"
        if ones:
            result += KO_DIGITS[ones]
        return result
    if n < 1000:
        h, r = divmod(n, 100)
        if h == 1:
            result = "백"
        else:
            result = f"{KO_DIGITS[h]}백"
        if r:
            result += num_to_korean(r)
        return result
    if n < 10000:
        th, r = divmod(n, 1000)
        if th == 1:
            result = "천"
        else:
            result = f"{KO_DIGITS[th]}천"
        if r:
            result += num_to_korean(r)
        return result
    if n < 100000000:
        man, r = divmod(n, 10000)
        result = f"{num_to_korean(man)}만"
        if r:
            result += num_to_korean(r)
        return result
    return str(n)


@lru_cache(maxsize=50000)
def num_to_french(n: int) -> str:
    """Convert integer to French words."""
    if n == 0:
        return "zéro"
    if n < 0:
        return f"moins {num_to_french(-n)}"
    if n < 17:
        return FR_ONES[n]
    if n < 20:
        return f"dix-{FR_ONES[n-10]}"
    if n < 100:
        tens, ones = divmod(n, 10)
        if tens == 7:
            return f"soixante-{num_to_french(10 + ones)}"
        if tens == 9:
            return f"quatre-vingt-{num_to_french(10 + ones)}"
        if ones == 0:
            return FR_TENS[tens] + ("s" if tens == 8 else "")
        if ones == 1 and tens in [2, 3, 4, 5, 6]:
            return f"{FR_TENS[tens]} et un"
        return f"{FR_TENS[tens]}-{FR_ONES[ones]}"
    if n < 1000:
        h, r = divmod(n, 100)
        if h == 1:
            base = "cent"
        else:
            base = f"{FR_ONES[h]} cent"
        if r:
            return f"{base} {num_to_french(r)}"
        # Exact multiple of 100 (≥200) → add 's' (deux cents, cinq cents…)
        return base + ("s" if h > 1 else "")
    if n < 1000000:
        th, r = divmod(n, 1000)
        result = "mille" if th == 1 else f"{num_to_french(th)} mille"
        if r:
            result += f" {num_to_french(r)}"
        return result
    if n < 10**9:
        m, r = divmod(n, 10**6)
        result = f"{num_to_french(m)} million" + ("s" if m > 1 else "")
        if r:
            result += f" {num_to_french(r)}"
        return result
    return str(n)


@lru_cache(maxsize=50000)
def num_to_german(n: int) -> str:
    """Convert integer to German words."""
    if n == 0:
        return "null"
    if n < 0:
        return f"minus {num_to_german(-n)}"
    if n < 10:
        return DE_ONES[n]
    if n < 20:
        special = {10: "zehn", 11: "elf", 12: "zwölf", 16: "sechzehn", 17: "siebzehn"}
        if n in special:
            return special[n]
        return f"{DE_ONES[n % 10]}zehn"
    if n < 100:
        tens, ones = divmod(n, 10)
        if ones == 0:
            return DE_TENS[tens]
        if ones == 1:
            return f"einund{DE_TENS[tens]}"
        return f"{DE_ONES[ones]}und{DE_TENS[tens]}"
    if n < 1000:
        h, r = divmod(n, 100)
        result = f"{DE_ONES[h]}hundert" if h > 1 else "einhundert"
        if r:
            result += num_to_german(r)
        return result
    if n < 1000000:
        th, r = divmod(n, 1000)
        result = f"{num_to_german(th)}tausend" if th > 1 else "eintausend"
        if r:
            result += f" {num_to_german(r)}"
        return result
    if n < 10**9:
        m, r = divmod(n, 10**6)
        result = f"{num_to_german(m)} Million" + ("en" if m > 1 else "")
        if r:
            result += f" {num_to_german(r)}"
        return result
    return str(n)


def num_to_words(n: int, lang: str) -> str:
    """Convert number to words for any supported language."""
    converters = {
        "vi": num_to_vietnamese,
        "en": num_to_english,
        "zh": num_to_chinese,
        "ja": num_to_japanese,
        "ko": num_to_korean,
        "fr": num_to_french,
        "de": num_to_german,
    }
    return converters.get(lang, num_to_vietnamese)(n)


# =============================================================================
# CURRENCY & UNIT NAMES PER LANGUAGE
# =============================================================================

CURRENCY_NAMES = {
    "vi": {"$": "đô la", "€": "euro", "£": "bảng Anh", "¥": "yên", "₩": "won", "đ": "đồng", "VND": "đồng"},
    "en": {"$": "dollars", "€": "euros", "£": "pounds", "¥": "yen", "₩": "won"},
    "zh": {"$": "美元", "€": "欧元", "£": "英镑", "¥": "元", "₩": "韩元"},
    "ja": {"$": "ドル", "€": "ユーロ", "£": "ポンド", "¥": "円", "₩": "ウォン"},
    "ko": {"$": "달러", "€": "유로", "£": "파운드", "¥": "엔", "₩": "원"},
    "fr": {"$": "dollars", "€": "euros", "£": "livres", "¥": "yens", "₩": "wons"},
    "de": {"$": "Dollar", "€": "Euro", "£": "Pfund", "¥": "Yen", "₩": "Won"},
}

UNIT_NAMES = {
    "vi": {
        "km": "ki lô mét", "m": "mét", "cm": "xen ti mét", "mm": "mi li mét",
        "km/h": "ki lô mét trên giờ", "m/s": "mét trên giây",
        "kg": "ki lô gam", "g": "gam", "mg": "mi li gam",
        "l": "lít", "ml": "mi li lít",
        "m²": "mét vuông", "m2": "mét vuông", "m³": "mét khối", "m3": "mét khối",
        "°C": "độ C", "°F": "độ F",
        "ms": "mili giây", "s": "giây", "min": "phút", "h": "giờ",
        "%": "phần trăm",
    },
    "en": {
        "km": "kilometers", "m": "meters", "cm": "centimeters", "mm": "millimeters",
        "km/h": "kilometers per hour", "mph": "miles per hour", "m/s": "meters per second",
        "kg": "kilograms", "g": "grams", "mg": "milligrams", "lb": "pounds", "oz": "ounces",
        "l": "liters", "ml": "milliliters", "gal": "gallons",
        "m²": "square meters", "m2": "square meters", "ft²": "square feet", "sq ft": "square feet",
        "°C": "degrees Celsius", "°F": "degrees Fahrenheit",
        "ms": "milliseconds", "s": "seconds", "min": "minutes", "h": "hours",
        "%": "percent",
    },
    "zh": {
        "km": "公里", "m": "米", "cm": "厘米", "mm": "毫米",
        "km/h": "公里每小时", "m/s": "米每秒",
        "kg": "公斤", "g": "克", "mg": "毫克",
        "l": "升", "ml": "毫升",
        "m²": "平方米", "m2": "平方米",
        "°C": "摄氏度", "°F": "华氏度",
        "ms": "毫秒", "s": "秒", "min": "分钟", "h": "小时",
        "%": "百分之",
    },
    "ja": {
        "km": "キロメートル", "m": "メートル", "cm": "センチメートル",
        "km/h": "キロメートル毎時",
        "kg": "キログラム", "g": "グラム",
        "°C": "度",
        "ms": "ミリ秒", "s": "秒", "min": "分", "h": "時",
        "%": "パーセント",
    },
    "ko": {
        "km": "킬로미터", "m": "미터", "cm": "센티미터",
        "km/h": "킬로미터",
        "kg": "킬로그램", "g": "그램",
        "°C": "도",
        "ms": "밀리초", "s": "초", "min": "분", "h": "시",
        "%": "퍼센트",
    },
    "fr": {
        "km": "kilomètres", "m": "mètres",
        "km/h": "kilomètres par heure",
        "kg": "kilogrammes", "g": "grammes",
        "°C": "degrés Celsius",
        "ms": "millisecondes", "%": "pour cent",
    },
    "de": {
        "km": "Kilometer", "m": "Meter",
        "km/h": "Kilometer pro Stunde",
        "kg": "Kilogramm", "g": "Gramm",
        "°C": "Grad Celsius",
        "ms": "Millisekunden", "%": "Prozent",
    },
}

TIME_WORDS = {
    "vi": {"hour": "giờ", "minute": "phút", "second": "giây", "day": "ngày", "month": "tháng", "year": "năm"},
    "en": {"hour": "", "minute": "", "second": "", "day": "", "month": "", "year": ""},
    "zh": {"hour": "点", "minute": "分", "second": "秒", "day": "日", "month": "月", "year": "年"},
    "ja": {"hour": "時", "minute": "分", "second": "秒", "day": "日", "month": "月", "year": "年"},
    "ko": {"hour": "시", "minute": "분", "second": "초", "day": "일", "month": "월", "year": "년"},
    "fr": {"hour": "heures", "minute": "minutes", "second": "secondes", "day": "", "month": "", "year": ""},
    "de": {"hour": "Uhr", "minute": "Minuten", "second": "Sekunden", "day": "", "month": "", "year": ""},
}


# =============================================================================
# NORMALIZER RULE
# =============================================================================

@dataclass
class NormRule:
    """Normalization rule with precompiled pattern."""
    name: str
    pattern: re.Pattern
    replacer: Callable
    priority: int = 0


# =============================================================================
# MAIN NORMALIZER CLASS
# =============================================================================

class TTSNormalizer:
    """Production multilingual TTS normalizer. Target: <1ms per sentence."""
    
    SUPPORTED_LANGS = ["vi", "en", "zh", "ja", "ko", "fr", "de"]
    
    def __init__(self, lang: str = "vi"):
        if lang not in self.SUPPORTED_LANGS:
            raise ValueError(f"Unsupported language: {lang}. Supported: {self.SUPPORTED_LANGS}")
        
        self.lang = lang
        self.num_to_words = lambda n: num_to_words(n, lang)
        
        # Load abbreviations (skip for CJK - TTS handles native text)
        if lang in ['zh', 'ja', 'ko']:
            self.abbrevs = {}  # CJK TTS reads abbreviations natively
        else:
            self.abbrevs = ABBREV_DICT.get(lang, {})
        self._compile_abbrev_pattern()
        
        # Load language-specific data
        self.months = MONTHS.get(lang, MONTHS.get("en", []))
        self.months_short = MONTHS_SHORT.get(lang, MONTHS_SHORT.get("en", []))
        self.weekdays = WEEKDAYS.get(lang, WEEKDAYS.get("en", []))
        self.currencies = CURRENCY_NAMES.get(lang, CURRENCY_NAMES["en"])
        self.units = UNIT_NAMES.get(lang, UNIT_NAMES["en"])
        self.time_words = TIME_WORDS.get(lang, TIME_WORDS["en"])
        
        # Build rules
        self.rules = self._build_rules()
    
    def _compile_abbrev_pattern(self):
        """Compile abbreviation pattern for fast matching."""
        if not self.abbrevs:
            self.abbrev_pattern = None
            return
        
        # Symbols handled by dedicated rules - exclude from abbrev matching
        EXCLUDED_SYMBOLS = {'$', '€', '£', '¥', '₩', 'đ', '₫', '%', '°C', '°F', '&', '@', '#', '+', '-', '×', '÷', '=', '<', '>', '≤', '≥', '°'}
        
        # Filter abbreviations - only keep text-based ones
        filtered_abbrevs = [a for a in self.abbrevs.keys() if a not in EXCLUDED_SYMBOLS and len(a) > 1]
        
        if not filtered_abbrevs:
            self.abbrev_pattern = None
            return
        
        # Sort by length (longest first) for correct matching
        sorted_abbrevs = sorted(filtered_abbrevs, key=len, reverse=True)
        # Escape special regex chars
        escaped = [re.escape(a) for a in sorted_abbrevs]
        pattern = r'\b(' + '|'.join(escaped) + r')(?=\s|$|[,;:.!?])'
        self.abbrev_pattern = re.compile(pattern)
    
    def _build_rules(self) -> List[NormRule]:
        """Build language-specific normalization rules."""
        rules = []
        
        # =====================================================================
        # Priority 100: Keep-as-is patterns
        # =====================================================================
        
        # URLs
        rules.append(NormRule(
            name="url",
            pattern=re.compile(r'https?://[^\s]+', re.IGNORECASE),
            replacer=lambda m: m.group(0),
            priority=100,
        ))
        
        # Email
        rules.append(NormRule(
            name="email", 
            pattern=re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'),
            replacer=self._replace_email,
            priority=100,
        ))
        
        # =====================================================================
        # Priority 90: Currencies
        # =====================================================================
        
        # USD: $100, $1.5M, $500k
        rules.append(NormRule(
            name="usd",
            pattern=re.compile(r'\$\s*(\d+(?:,\d{3})*(?:\.\d+)?)(k|K|m|M|b|B)?'),
            replacer=self._replace_currency_usd,
            priority=90,
        ))
        
        # Euro: €100
        rules.append(NormRule(
            name="euro",
            pattern=re.compile(r'€\s*(\d+(?:,\d{3})*(?:\.\d+)?)(k|K|m|M|b|B)?'),
            replacer=self._replace_currency_euro,
            priority=90,
        ))
        
        # Yen/Yuan: ¥100, ￥100
        rules.append(NormRule(
            name="yen",
            pattern=re.compile(r'[¥￥]\s*(\d+(?:,\d{3})*(?:\.\d+)?)(k|K|m|M|b|B)?'),
            replacer=self._replace_currency_yen,
            priority=90,
        ))
        
        # Won: ₩100
        rules.append(NormRule(
            name="won",
            pattern=re.compile(r'₩\s*(\d+(?:,\d{3})*(?:\.\d+)?)(k|K|m|M|b|B)?'),
            replacer=self._replace_currency_won,
            priority=90,
        ))
        
        # VND: 100đ, 100 đồng, 100 VND
        if self.lang == "vi":
            rules.append(NormRule(
                name="vnd",
                pattern=re.compile(r'(\d+(?:,\d{3})*)\s*(đồng|VND|vnđ|đ)(?=\s|$|[,;:.!?])', re.IGNORECASE),
                replacer=lambda m: f"{self.num_to_words(int(m.group(1).replace(',', '')))} đồng",
                priority=90,
            ))
        
        # =====================================================================
        # Priority 85: Percentages
        # =====================================================================
        
        rules.append(NormRule(
            name="percent",
            pattern=re.compile(r'(\d+(?:[.,]\d+)?)\s*%'),
            replacer=self._replace_percent,
            priority=85,
        ))
        
        # =====================================================================
        # Priority 82: Fractions (before dates)
        # =====================================================================
        
        # Fraction followed by noun: 1/2 cái, 3/4 phần
        rules.append(NormRule(
            name="fraction",
            pattern=re.compile(r'(\d+)/(\d{1,2})(?=\s+[a-zA-ZÀ-ỹ\u3000-\u9fff\uac00-\ud7af])'),
            replacer=self._replace_fraction,
            priority=82,
        ))
        
        # =====================================================================
        # Priority 80: Dates
        # =====================================================================
        
        # Full date: d/m/y or m/d/y or y/m/d
        if self.lang in ["vi"]:
            # Vietnamese: d/m/y (case-insensitive "ngày" prefix)
            rules.append(NormRule(
                name="date_dmy",
                pattern=re.compile(r'(?:[Nn]gày\s*)?(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})'),
                replacer=self._replace_date_dmy,
                priority=80,
            ))
        elif self.lang in ["en"]:
            # English: m/d/y
            rules.append(NormRule(
                name="date_mdy",
                pattern=re.compile(r'(\d{1,2})[/\-](\d{1,2})[/\-](\d{4})'),
                replacer=self._replace_date_mdy,
                priority=80,
            ))
        elif self.lang in ["zh", "ja", "ko"]:
            # Asian: y/m/d or y年m月d日
            rules.append(NormRule(
                name="date_ymd",
                pattern=re.compile(r'(\d{4})[/\-年](\d{1,2})[/\-月](\d{1,2})日?'),
                replacer=self._replace_date_ymd,
                priority=80,
            ))
        elif self.lang == "fr":
            # French: d/m/y with optional "le" prefix
            rules.append(NormRule(
                name="date_dmy",
                pattern=re.compile(r'(?:[Ll]e\s+)?(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})'),
                replacer=self._replace_date_dmy,
                priority=80,
            ))
        elif self.lang == "de":
            # German: d.m.y with optional "am" prefix
            rules.append(NormRule(
                name="date_dmy",
                pattern=re.compile(r'(?:[Aa]m\s+)?(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})'),
                replacer=self._replace_date_dmy,
                priority=80,
            ))
        else:
            # Other European: d/m/y
            rules.append(NormRule(
                name="date_dmy",
                pattern=re.compile(r'(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})'),
                replacer=self._replace_date_dmy,
                priority=80,
            ))
        
        # Partial date without year (for Vietnamese with optional ngày prefix)
        if self.lang == "vi":
            rules.append(NormRule(
                name="date_partial",
                pattern=re.compile(r'(?:[Nn]gày\s*)?(\d{1,2})[/\-](\d{1,2})(?=\s|$|[,;:.!?])'),
                replacer=self._replace_date_partial,
                priority=79,
            ))
        else:
            rules.append(NormRule(
                name="date_partial",
                pattern=re.compile(r'(\d{1,2})[/\-](\d{1,2})(?=\s|$|[,;:.!?])'),
                replacer=self._replace_date_partial,
                priority=79,
            ))
        
        # =====================================================================
        # Priority 75: Time
        # =====================================================================
        
        # Full time: h:m:s.ms
        rules.append(NormRule(
            name="time_full",
            pattern=re.compile(r'(\d{1,2}):(\d{2}):(\d{2})(?:\.(\d+))?'),
            replacer=self._replace_time_full,
            priority=75,
        ))
        
        # Time with AM/PM
        rules.append(NormRule(
            name="time_ampm",
            pattern=re.compile(r'(\d{1,2}):(\d{2})\s*(AM|PM|am|pm|sáng|chiều|tối)'),
            replacer=self._replace_time_ampm,
            priority=74,
        ))
        
        # Simple time: h:m
        rules.append(NormRule(
            name="time_hm",
            pattern=re.compile(r'(\d{1,2}):(\d{2})(?!\d|:)'),
            replacer=self._replace_time_hm,
            priority=73,
        ))
        
        # Informal time: 5h30, 14h
        rules.append(NormRule(
            name="time_informal",
            pattern=re.compile(r'(\d{1,2})\s*[hH](?:\s*(\d{1,2}))?\s*(sáng|chiều|tối)?(?=\s|$|[,;:.!?])'),
            replacer=self._replace_time_informal,
            priority=72,
        ))
        
        # =====================================================================
        # Priority 70: Duration
        # =====================================================================
        
        # Duration: XhYmZs
        rules.append(NormRule(
            name="duration_hms",
            pattern=re.compile(r'(\d+)\s*[hH]\s*(\d+)\s*[mM]\s*(\d+)\s*[sS]'),
            replacer=self._replace_duration_hms,
            priority=70,
        ))
        
        # Duration: XhYm
        rules.append(NormRule(
            name="duration_hm",
            pattern=re.compile(r'(\d+)\s*[hH]\s*(\d+)\s*m(?:in)?(?=\s|$|[,;:.!?])'),
            replacer=self._replace_duration_hm,
            priority=70,
        ))
        
        # Milliseconds
        rules.append(NormRule(
            name="ms",
            pattern=re.compile(r'(\d+)\s*(ms|MS|millisecond|mili)'),
            replacer=lambda m: f"{self.num_to_words(int(m.group(1)))} {self.units.get('ms', 'ms')}",
            priority=70,
        ))
        
        # =====================================================================
        # Priority 65: Units
        # =====================================================================
        
        # Speed: km/h, mph
        rules.append(NormRule(
            name="speed",
            pattern=re.compile(r'(\d+(?:\.\d+)?)\s*(km/h|kmh|mph|m/s)', re.IGNORECASE),
            replacer=self._replace_unit,
            priority=65,
        ))
        
        # Area: m², sq ft
        rules.append(NormRule(
            name="area",
            pattern=re.compile(r'(\d+(?:\.\d+)?)\s*(m²|m2|ft²|sq\s*ft)', re.IGNORECASE),
            replacer=self._replace_unit,
            priority=65,
        ))
        
        # Distance: km, m, cm
        rules.append(NormRule(
            name="distance",
            pattern=re.compile(r'(\d+(?:\.\d+)?)\s*(km|cm|mm)(?![a-zA-Z/])'),
            replacer=self._replace_unit,
            priority=65,
        ))
        
        # Weight: kg, g, lb
        rules.append(NormRule(
            name="weight",
            pattern=re.compile(r'(\d+(?:\.\d+)?)\s*(kg|g|mg|lb|oz)(?![a-zA-Z])'),
            replacer=self._replace_unit,
            priority=65,
        ))
        
        # Temperature: °C, °F  (decimal: dot for EN/CJK, dot-or-comma for VI/DE/FR)
        rules.append(NormRule(
            name="temperature",
            pattern=re.compile(r'(\d+(?:[.,]\d+)?)\s*°\s*(C|F)'),
            replacer=self._replace_temperature,
            priority=65,
        ))
        
        # =====================================================================
        # Priority 50: Quarter
        # =====================================================================
        
        rules.append(NormRule(
            name="quarter",
            pattern=re.compile(r'\bQ([1-4])\b', re.IGNORECASE),
            replacer=self._replace_quarter,
            priority=50,
        ))
        
        # =====================================================================
        # Priority 48: Year with context word (must run BEFORE plain number)
        # "năm 2026", "year 2025", "Jahr 2024", "en 2025", "anno 2024"
        # → keep the context word, only convert the 4-digit year number
        # =====================================================================
        YEAR_CTX = {
            'vi': r'(?<!\w)(năm)\s+(\d{4})(?!\d)',
            'en': r'\b(year|in)\s+(\d{4})\b',
            'fr': r"\b(an|année|en)\s+(\d{4})\b",
            'de': r'\b(Jahr|im)\s+(\d{4})\b',
        }
        if self.lang in YEAR_CTX:
            _pat = re.compile(YEAR_CTX[self.lang], re.IGNORECASE)
            rules.append(NormRule(
                name='year_context',
                pattern=_pat,
                replacer=lambda m: f"{m.group(1)} {self.num_to_words(int(m.group(2)))}",
                priority=48,
            ))

        # =====================================================================
        # Priority 47: Thousand-separated integers
        # EN/ZH/JA/KO: 1,234  1,234,567   (comma = thousand separator)
        # VI/DE/FR:    1.234  1.234.567   (dot   = thousand separator)
        # FR also:     1 234  1 234 567   (nbsp/space = thousand separator)
        # =====================================================================
        if self.lang in ('en', 'zh', 'ja', 'ko'):
            # Comma-thousand: must NOT be followed by digits (avoid matching "1,23")
            rules.append(NormRule(
                name='number_thousand_comma',
                pattern=re.compile(r'\b(\d{1,3}(?:,\d{3})+)(?!\d|[.,]\d)'),
                replacer=lambda m: self.num_to_words(int(m.group(1).replace(',', ''))),
                priority=47,
            ))
        elif self.lang in ('vi', 'de', 'fr'):
            # Dot-thousand: groups of exactly 3 after first group
            rules.append(NormRule(
                name='number_thousand_dot',
                pattern=re.compile(r'\b(\d{1,3}(?:\.\d{3})+)(?!\d|[.,]\d)'),
                replacer=lambda m: self.num_to_words(int(m.group(1).replace('.', ''))),
                priority=47,
            ))
            if self.lang == 'fr':
                # Narrow-space or regular-space thousand separator: 1 234 or 1\u202f234
                rules.append(NormRule(
                    name='number_thousand_space',
                    pattern=re.compile(r'\b(\d{1,3}(?:[\u00a0\u202f ]\d{3})+)(?!\d)'),
                    replacer=lambda m: self.num_to_words(int(re.sub(r'[\u00a0\u202f ]', '', m.group(1)))),
                    priority=47,
                ))

        # =====================================================================
        # Priority 46: Decimal numbers (language-aware separator)
        # EN/ZH/JA/KO: dot decimal   6.7   1,234.56
        # VI/DE/FR:    comma decimal 6,7   1.234,56
        # Also handle "wrong" separator in mixed text (15.4% in VI)
        # =====================================================================
        if self.lang in ('en', 'zh', 'ja', 'ko'):
            # Dot decimal — may have comma-thousand prefix: 1,234.56 or bare 6.7
            rules.append(NormRule(
                name='decimal_dot',
                pattern=re.compile(r'\b(\d{1,3}(?:,\d{3})*)\.(\d+)\b'),
                replacer=self._replace_decimal,
                priority=46,
            ))
        elif self.lang in ('vi', 'de', 'fr'):
            # Comma decimal — may have dot-thousand prefix: 1.234,56 or bare 6,7
            # Use negative lookbehind so we don't greedily match inside larger patterns
            rules.append(NormRule(
                name='decimal_comma',
                pattern=re.compile(r'\b(\d{1,3}(?:\.\d{3})*),(\d+)\b'),
                replacer=self._replace_decimal_comma,
                priority=46,
            ))
            # Also accept dot decimal in VI/DE/FR mixed text (e.g. "15.4%" typed EN-style)
            rules.append(NormRule(
                name='decimal_dot_mixed',
                pattern=re.compile(r'\b(\d+)\.(\d+)\b'),
                replacer=self._replace_decimal,
                priority=45,
            ))

        # =====================================================================
        # Priority 40: Plain integers (fallback, after all special cases)
        # =====================================================================
        if self.lang in ('zh', 'ja', 'ko'):
            # CJK: no word boundaries
            rules.append(NormRule(
                name='number',
                pattern=re.compile(r'\d+'),
                replacer=lambda m: self.num_to_words(int(m.group(0))),
                priority=40,
            ))
        else:
            rules.append(NormRule(
                name='number',
                pattern=re.compile(r'\b(\d{1,15})\b'),
                replacer=lambda m: self.num_to_words(int(m.group(1))),
                priority=40,
            ))
        
        # Sort by priority (highest first)
        rules.sort(key=lambda r: -r.priority)
        return rules
    
    # =========================================================================
    # REPLACEMENT FUNCTIONS
    # =========================================================================
    
    def _parse_num(self, s: str) -> int:
        """Parse number string with commas."""
        return int(float(s.replace(",", "")))
    
    def _apply_suffix(self, amount: float, suffix: str) -> int:
        """Apply k/M/B suffix to amount."""
        if suffix:
            multipliers = {"k": 1000, "m": 1000000, "b": 1000000000}
            amount *= multipliers.get(suffix.lower(), 1)
        return int(amount)
    
    def _replace_email(self, m: re.Match) -> str:
        """Replace email with spoken form."""
        email = m.group(0)
        replacements = {
            "vi": {"@": " a còng ", ".": " chấm "},
            "en": {"@": " at ", ".": " dot "},
            "zh": {"@": " at ", ".": " diǎn "},
            "ja": {"@": " atto ", ".": " dotto "},
            "ko": {"@": " at ", ".": " jeom "},
            "fr": {"@": " arobase ", ".": " point "},
            "de": {"@": " at ", ".": " Punkt "},
        }
        r = replacements.get(self.lang, replacements["en"])
        for old, new in r.items():
            email = email.replace(old, new)
        return email
    
    def _replace_currency_usd(self, m: re.Match) -> str:
        amount = self._apply_suffix(float(m.group(1).replace(",", "")), m.group(2))
        num_word = self.num_to_words(amount)
        currency_word = self.currencies.get('$', 'dollars')
        # No space for CJK
        if self.lang in ['zh', 'ja', 'ko']:
            return f"{num_word}{currency_word}"
        return f"{num_word} {currency_word}"
    
    def _replace_currency_euro(self, m: re.Match) -> str:
        amount = self._apply_suffix(float(m.group(1).replace(",", "")), m.group(2))
        num_word = self.num_to_words(amount)
        currency_word = self.currencies.get('€', 'euros')
        if self.lang in ['zh', 'ja', 'ko']:
            return f"{num_word}{currency_word}"
        return f"{num_word} {currency_word}"
    
    def _replace_currency_yen(self, m: re.Match) -> str:
        amount = self._apply_suffix(float(m.group(1).replace(",", "")), m.group(2))
        num_word = self.num_to_words(amount)
        currency_word = self.currencies.get('¥', 'yen')
        if self.lang in ['zh', 'ja', 'ko']:
            return f"{num_word}{currency_word}"
        return f"{num_word} {currency_word}"
    
    def _replace_currency_won(self, m: re.Match) -> str:
        amount = self._apply_suffix(float(m.group(1).replace(",", "")), m.group(2))
        num_word = self.num_to_words(amount)
        currency_word = self.currencies.get('₩', 'won')
        if self.lang in ['zh', 'ja', 'ko']:
            return f"{num_word}{currency_word}"
        return f"{num_word} {currency_word}"
    
    def _replace_percent(self, m: re.Match) -> str:
        raw = m.group(1)
        unit_word = self.units.get('%', 'percent')

        # Detect decimal separator per language:
        # VI/DE/FR → comma is decimal (e.g. 3,5%)
        # EN/ZH/JA/KO → dot is decimal (e.g. 3.5%)
        # Mixed: someone may write 15.4% in VI text → treat dot as decimal too
        if self.lang in ('vi', 'de', 'fr'):
            # Primary: comma decimal  e.g. "3,5"
            if ',' in raw:
                whole_s, frac_s = raw.split(',', 1)
                num_word = self._fmt_decimal(whole_s, frac_s)
            elif '.' in raw:
                # Dot decimal written in VI/DE/FR text (common in mixed text)
                whole_s, frac_s = raw.split('.', 1)
                num_word = self._fmt_decimal(whole_s, frac_s)
            else:
                num_word = self.num_to_words(int(raw))
        else:
            # EN/ZH/JA/KO: dot decimal
            if '.' in raw:
                whole_s, frac_s = raw.split('.', 1)
                num_word = self._fmt_decimal(whole_s, frac_s)
            else:
                num_word = self.num_to_words(int(raw))

        # Chinese uses prefix format (百分之X), no space
        if self.lang == 'zh':
            return f"{unit_word}{num_word}"
        # Japanese/Korean use suffix, no space
        elif self.lang in ['ja', 'ko']:
            return f"{num_word}{unit_word}"
        else:
            return f"{num_word} {unit_word}"
    
    def _replace_fraction(self, m: re.Match) -> str:
        num, denom = int(m.group(1)), int(m.group(2))
        fraction_words = {
            "vi": f"{self.num_to_words(num)} phần {self.num_to_words(denom)}",
            "en": f"{self.num_to_words(num)} over {self.num_to_words(denom)}",
            "zh": f"{self.num_to_words(denom)}分之{self.num_to_words(num)}",  # 二分之一
            "ja": f"{self.num_to_words(denom)}分の{self.num_to_words(num)}",
            "ko": f"{self.num_to_words(denom)}분의 {self.num_to_words(num)}",
            "fr": f"{self.num_to_words(num)} sur {self.num_to_words(denom)}",
            "de": f"{self.num_to_words(num)} {self.num_to_words(denom)}tel",
        }
        return fraction_words.get(self.lang, fraction_words["en"])
    
    def _replace_date_dmy(self, m: re.Match) -> str:
        """Replace d/m/y date."""
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        tw = self.time_words
        
        if self.lang == "vi":
            return f"ngày {self.num_to_words(d)} tháng {self.num_to_words(mo)} năm {self.num_to_words(y)}"
        elif self.lang == "fr":
            month_name = self.months[mo-1] if 1 <= mo <= 12 else str(mo)
            return f"le {self.num_to_words(d)} {month_name} {self.num_to_words(y)}"
        elif self.lang == "de":
            month_name = self.months[mo-1] if 1 <= mo <= 12 else str(mo)
            return f"am {self.num_to_words(d)}. {month_name} {self.num_to_words(y)}"
        else:
            month_name = self.months[mo-1] if 1 <= mo <= 12 else str(mo)
            return f"{month_name} {d}, {self.num_to_words(y)}"
    
    def _replace_date_mdy(self, m: re.Match) -> str:
        """Replace m/d/y date (English)."""
        mo, d, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        month_name = self.months[mo-1] if 1 <= mo <= 12 else str(mo)
        
        # Ordinal for day
        if 10 <= d % 100 <= 20:
            suffix = "th"
        else:
            suffix = {1: "st", 2: "nd", 3: "rd"}.get(d % 10, "th")
        
        return f"{month_name} {d}{suffix}, {self.num_to_words(y)}"
    
    def _replace_date_ymd(self, m: re.Match) -> str:
        """Replace y/m/d date (Asian)."""
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        tw = self.time_words
        
        # CJK: no spaces between number and unit (年月日)
        if self.lang in ["zh", "ja", "ko"]:
            return f"{self.num_to_words(y)}{tw['year']}{self.num_to_words(mo)}{tw['month']}{self.num_to_words(d)}{tw['day']}"
        else:
            return f"{self.num_to_words(y)}-{self.num_to_words(mo)}-{self.num_to_words(d)}"
    
    def _replace_date_partial(self, m: re.Match) -> str:
        """Replace partial date d/m."""
        d, mo = int(m.group(1)), int(m.group(2))
        
        # Validate as date
        if not (1 <= mo <= 12 and 1 <= d <= 31):
            return m.group(0)  # Not a valid date
        
        if self.lang == "vi":
            return f"ngày {self.num_to_words(d)} tháng {self.num_to_words(mo)}"
        elif self.lang == "en":
            month_name = self.months[mo-1] if 1 <= mo <= 12 else str(mo)
            return f"{month_name} {d}"
        else:
            return f"{self.num_to_words(d)}/{self.num_to_words(mo)}"
    
    def _replace_time_full(self, m: re.Match) -> str:
        """Replace full time h:m:s."""
        h, mi, s = int(m.group(1)), int(m.group(2)), int(m.group(3))
        ms = m.group(4)
        tw = self.time_words
        
        if self.lang == "vi":
            result = f"{self.num_to_words(h)} giờ {self.num_to_words(mi)} phút {self.num_to_words(s)} giây"
            if ms:
                result += f" {self.num_to_words(int(ms))} mili giây"
        elif self.lang == "en":
            result = f"{self.num_to_words(h)} {self.num_to_words(mi)} {self.num_to_words(s)}"
        elif self.lang in ["zh", "ja", "ko"]:
            result = f"{self.num_to_words(h)}{tw['hour']}{self.num_to_words(mi)}{tw['minute']}{self.num_to_words(s)}{tw['second']}"
        else:
            result = f"{self.num_to_words(h)} {tw['hour']} {self.num_to_words(mi)} {tw['minute']} {self.num_to_words(s)} {tw['second']}"
        
        return result
    
    def _replace_time_ampm(self, m: re.Match) -> str:
        """Replace time with AM/PM."""
        h, mi = int(m.group(1)), int(m.group(2))
        period = m.group(3)
        
        period_map = {
            "vi": {"AM": "sáng", "PM": "chiều" if h < 6 else "tối", "sáng": "sáng", "chiều": "chiều", "tối": "tối"},
            "en": {"AM": "A M", "PM": "P M"},
            "zh": {"AM": "shàngwǔ", "PM": "xiàwǔ"},
            "ja": {"AM": "gozen", "PM": "gogo"},
            "ko": {"AM": "ojeon", "PM": "ohu"},
            "fr": {"AM": "du matin", "PM": "de l'après-midi"},
            "de": {"AM": "morgens", "PM": "nachmittags"},
        }
        
        pm = period_map.get(self.lang, period_map["en"])
        period_word = pm.get(period.upper(), pm.get(period, period))
        
        if self.lang == "vi":
            return f"{self.num_to_words(h)} giờ {self.num_to_words(mi)} phút {period_word}"
        elif self.lang == "en":
            return f"{self.num_to_words(h)} {self.num_to_words(mi)} {period_word}"
        else:
            return f"{self.num_to_words(h)}:{self.num_to_words(mi)} {period_word}"
    
    def _replace_time_hm(self, m: re.Match) -> str:
        """Replace simple time h:m."""
        h, mi = int(m.group(1)), int(m.group(2))
        tw = self.time_words
        
        if self.lang == "vi":
            return f"{self.num_to_words(h)} giờ {self.num_to_words(mi)} phút"
        elif self.lang == "en":
            return f"{self.num_to_words(h)} {self.num_to_words(mi)}"
        elif self.lang in ["zh", "ja", "ko"]:
            return f"{self.num_to_words(h)}{tw['hour']}{self.num_to_words(mi)}{tw['minute']}"
        elif self.lang == "fr":
            return f"{self.num_to_words(h)} heures {self.num_to_words(mi)}"
        elif self.lang == "de":
            return f"{self.num_to_words(h)} Uhr {self.num_to_words(mi)}"
        else:
            return f"{self.num_to_words(h)}:{self.num_to_words(mi)}"
    
    def _replace_time_informal(self, m: re.Match) -> str:
        """Replace informal time like 5h30."""
        h = int(m.group(1))
        mi = int(m.group(2)) if m.group(2) else 0
        period = m.group(3) or ""
        
        if self.lang == "vi":
            result = f"{self.num_to_words(h)} giờ"
            if mi:
                result += f" {self.num_to_words(mi)}"
            if period:
                result += f" {period}"
            return result
        else:
            if mi:
                return f"{self.num_to_words(h)}:{self.num_to_words(mi)}"
            return f"{self.num_to_words(h)} {self.time_words['hour']}"
    
    def _replace_duration_hms(self, m: re.Match) -> str:
        """Replace duration XhYmZs."""
        h, mi, s = int(m.group(1)), int(m.group(2)), int(m.group(3))
        
        if self.lang == "vi":
            return f"{self.num_to_words(h)} giờ {self.num_to_words(mi)} phút {self.num_to_words(s)} giây"
        elif self.lang == "en":
            return f"{self.num_to_words(h)} hours {self.num_to_words(mi)} minutes {self.num_to_words(s)} seconds"
        elif self.lang in ["zh", "ja", "ko"]:
            tw = self.time_words
            return f"{self.num_to_words(h)}{tw['hour']}{self.num_to_words(mi)}{tw['minute']}{self.num_to_words(s)}{tw['second']}"
        else:
            tw = self.time_words
            return f"{self.num_to_words(h)} {tw['hour']} {self.num_to_words(mi)} {tw['minute']} {self.num_to_words(s)} {tw['second']}"
    
    def _replace_duration_hm(self, m: re.Match) -> str:
        """Replace duration XhYm."""
        h, mi = int(m.group(1)), int(m.group(2))
        
        if self.lang == "vi":
            return f"{self.num_to_words(h)} giờ {self.num_to_words(mi)} phút"
        elif self.lang == "en":
            return f"{self.num_to_words(h)} hours {self.num_to_words(mi)} minutes"
        elif self.lang in ["zh", "ja", "ko"]:
            tw = self.time_words
            return f"{self.num_to_words(h)}{tw['hour']}{self.num_to_words(mi)}{tw['minute']}"
        else:
            tw = self.time_words
            return f"{self.num_to_words(h)} {tw['hour']} {self.num_to_words(mi)} {tw['minute']}"
    
    def _replace_unit(self, m: re.Match) -> str:
        """Replace number with unit, preserving decimal part."""
        raw = m.group(1)
        unit = m.group(2).lower().replace(' ', '')
        unit_name = self.units.get(unit, self.units.get(m.group(2), m.group(2)))

        if '.' in raw:
            whole_s, frac_s = raw.split('.', 1)
            num_word = self._fmt_decimal(whole_s, frac_s)
        elif ',' in raw and self.lang in ('vi', 'de', 'fr'):
            whole_s, frac_s = raw.split(',', 1)
            num_word = self._fmt_decimal(whole_s, frac_s)
        else:
            num_word = self.num_to_words(int(raw))

        if self.lang in ('zh', 'ja', 'ko'):
            return f"{num_word}{unit_name}"
        return f"{num_word} {unit_name}"
    
    def _replace_temperature(self, m: re.Match) -> str:
        """Replace temperature, preserving decimal."""
        raw = m.group(1)
        scale = m.group(2)
        unit_key = f"°{scale}"
        unit_name = self.units.get(unit_key, f"degrees {scale}")

        if ',' in raw and self.lang in ('vi', 'de', 'fr'):
            whole_s, frac_s = raw.split(',', 1)
            num_word = self._fmt_decimal(whole_s, frac_s)
        elif '.' in raw:
            whole_s, frac_s = raw.split('.', 1)
            num_word = self._fmt_decimal(whole_s, frac_s)
        else:
            num_word = self.num_to_words(int(raw))

        if self.lang in ('zh', 'ja', 'ko'):
            return f"{num_word}{unit_name}"
        return f"{num_word} {unit_name}"
    
    def _replace_quarter(self, m: re.Match) -> str:
        """Replace quarter Q1-Q4."""
        q = int(m.group(1))
        quarter_words = {
            "vi": f"quý {self.num_to_words(q)}",
            "en": f"quarter {self.num_to_words(q)}",
            "zh": f"dì {self.num_to_words(q)} jìdù",
            "ja": f"dai {self.num_to_words(q)} shihanki",
            "ko": f"je {self.num_to_words(q)} bungi",
            "fr": f"trimestre {self.num_to_words(q)}",
            "de": f"Quartal {self.num_to_words(q)}",
        }
        return quarter_words.get(self.lang, quarter_words["en"])
    
    def _fmt_decimal(self, whole_s: str, frac_s: str) -> str:
        """Core decimal formatter: whole part + language separator + digit-by-digit fraction.

        Handles thousand-separated whole parts too (strips . or , thousand seps before converting).
        """
        # Remove any thousand separators from whole part
        clean = whole_s.replace(',', '').replace('.', '').replace('\u00a0', '').replace(' ', '')
        whole_words = self.num_to_words(int(clean)) if clean else self.num_to_words(0)

        decimal_sep = {
            'vi': 'phẩy',    # 6,7  → sáu phẩy bảy
            'en': 'point',   # 6.7  → six point seven
            'zh': '点',      # 6.7  → 六点七
            'ja': '点',      # 6.7  → 六点七
            'ko': '점',      # 6.7  → 육점칠
            'fr': 'virgule', # 6,7  → six virgule sept
            'de': 'Komma',   # 6,7  → sechs Komma sieben
        }
        sep = decimal_sep.get(self.lang, 'point')

        # Fraction: speak each digit individually (15.4 → "... bốn", NOT "bốn mươi")
        frac_words = ' '.join(self.num_to_words(int(d)) for d in frac_s)

        if self.lang in ('zh', 'ja', 'ko'):
            return f"{whole_words}{sep}{frac_words}"
        return f"{whole_words} {sep} {frac_words}"

    def _replace_decimal(self, m: re.Match) -> str:
        """Replace dot-decimal number: 15.4 → fifteen point four."""
        return self._fmt_decimal(m.group(1), m.group(2))

    def _replace_decimal_comma(self, m: re.Match) -> str:
        """Replace comma-decimal number (VI/DE/FR): 15,4 → mười lăm phẩy bốn."""
        return self._fmt_decimal(m.group(1), m.group(2))
    
    # =========================================================================
    # MAIN NORMALIZE FUNCTION
    # =========================================================================
    
    def normalize(self, text: str, lower: bool = False, punc: bool = True) -> str:
        """Normalize text for TTS. Target: <1ms.
        
        Args:
            text: Input text to normalize
            lower: If True, convert output to lowercase
            punc: If True, add spacing around punctuation for TTS pauses
        """
        if not text:
            return text
        
        result = text
        
        # 1. Normalize unicode
        result = unicodedata.normalize("NFC", result)
        
        # 2. Apply abbreviation expansion FIRST (before any protection)
        if self.abbrev_pattern:
            result = self.abbrev_pattern.sub(
                lambda m: self.abbrevs.get(m.group(1), self.abbrevs.get(m.group(1).upper(), m.group(0))),
                result
            )
        
        # 3. Protect URLs, emails, and special tokens with placeholders
        protected = {}
        placeholder_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
        placeholder_id = 0
        
        def protect_match(m):
            nonlocal placeholder_id
            char_id = placeholder_chars[placeholder_id % len(placeholder_chars)]
            key = f"__PROT_{char_id}__"
            protected[key] = m.group(0)
            placeholder_id += 1
            return key
        
        # Protect URLs (including query strings, stop before trailing punctuation that's not part of URL)
        result = re.sub(r'https?://[^\s,;!\)\]]+', protect_match, result)
        # Protect emails
        result = re.sub(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', protect_match, result)
        # Protect emotion tokens: <...> and [...] 
        result = re.sub(r'<[^>]+>', protect_match, result)
        result = re.sub(r'\[[^\]]+\]', protect_match, result)
        
        # 4. Apply rules in priority order (skip URL/email rules since we protected them)
        for rule in self.rules:
            if rule.name in ('url', 'email'):
                continue  # Already handled
            result = rule.pattern.sub(rule.replacer, result)
        
        # 5. Punctuation spacing for TTS pauses (BEFORE restoring protected content)
        if punc:
            # Add space BEFORE punctuation (if not already there)
            result = re.sub(r'(?<!\s)([,;:!?।။—–])', r' \1', result)
            
            # Add space AFTER punctuation (if not already there)
            result = re.sub(r'([,;:!?।။—–])(?!\s)', r'\1 ', result)
            
            # Period: add space after if followed by:
            # - Uppercase letter (new sentence)
            # - Protected token placeholder (__PROT_)
            # - CJK characters
            result = re.sub(r'\.(?=[A-ZÀ-Ỹ\u3000-\u9fff\uac00-\ud7af]|__PROT_)', '. ', result)
        
        # 6. Restore protected content (AFTER punctuation spacing)
        for key, value in protected.items():
            result = result.replace(key, value)
        
        # 7. Cleanup multiple spaces
        result = re.sub(r'\s+', ' ', result).strip()
        
        return result.lower() if lower else result
    
    def benchmark(self, sentences: List[str], num_runs: int = 100) -> Dict:
        """Benchmark normalization speed."""
        import numpy as np
        times = []
        
        # Warmup
        for sent in sentences[:3]:
            _ = self.normalize(sent)
        
        # Benchmark
        for sent in sentences:
            for _ in range(num_runs):
                start = time.perf_counter()
                _ = self.normalize(sent)
                end = time.perf_counter()
                times.append((end - start) * 1000)
        
        return {
            "mean_ms": np.mean(times),
            "p50_ms": np.percentile(times, 50),
            "p95_ms": np.percentile(times, 95),
            "p99_ms": np.percentile(times, 99),
            "max_ms": np.max(times),
        }


# =============================================================================
# CLI
# =============================================================================

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Multilingual TTS Normalizer")
    parser.add_argument("--lang", default="vi", choices=TTSNormalizer.SUPPORTED_LANGS)
    parser.add_argument("--text", type=str, help="Text to normalize")
    parser.add_argument("--benchmark", action="store_true")
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()
    
    normalizer = TTSNormalizer(args.lang)
    
    if args.benchmark:
        test_sentences = {
            "vi": [
                "CEO có $100, tăng 50%",
                "Cuộc họp ngày 15/3/2024 lúc 14:30, có 50 người.",
                "Doanh thu Q3 đạt $1.5M, tăng 35% YoY. Chi phí $200K, ROI 150%.",
            ],
            "en": [
                "The CEO has $100, up 50%",
                "Meeting on 3/15/2024 at 2:30 PM with 50 people.",
                "Q3 revenue reached $1.5M, up 35% YoY. Costs $200K, ROI 150%.",
            ],
            "zh": [
                "CEO有$100，增长50%",
                "2024年3月15日14:30开会，50人参加。",
                "Q3收入$150万，同比增长35%。",
            ],
            "ja": [
                "CEOは$100を持っています、50%増加",
                "2024年3月15日14:30に会議、50人参加。",
            ],
            "ko": [
                "CEO는 $100, 50% 증가",
                "2024년 3월 15일 14:30 회의, 50명 참석.",
            ],
            "fr": [
                "Le PDG a $100, en hausse de 50%",
                "Réunion le 15/3/2024 à 14h30, 50 personnes.",
            ],
            "de": [
                "Der CEO hat $100, plus 50%",
                "Meeting am 15.3.2024 um 14:30, 50 Personen.",
            ],
        }
        
        sentences = test_sentences.get(args.lang, test_sentences["en"])
        results = normalizer.benchmark(sentences, num_runs=1000)
        
        print(f"\n{'='*50}")
        print(f"BENCHMARK: {args.lang.upper()}")
        print(f"{'='*50}")
        print(f"Mean:  {results['mean_ms']:.3f} ms")
        print(f"P50:   {results['p50_ms']:.3f} ms")
        print(f"P95:   {results['p95_ms']:.3f} ms")
        print(f"P99:   {results['p99_ms']:.3f} ms")
        print(f"Max:   {results['max_ms']:.3f} ms")
        print(f"{'='*50}")
        print("✅ PASS" if results['p95_ms'] < 1 else "⚠️ SLOW")
        
    elif args.text:
        print(f"Input:  {args.text}")
        print(f"Output: {normalizer.normalize(args.text)}")
        
    elif args.demo or True:
        # Demo all languages
        demos = {
            "vi": [
                "CEO có $100, tăng 50%",
                "Meeting ngày 15/3/2024 lúc 14:30",
                "Doanh thu Q3: $1.5M, tăng 35%",
                "Diện tích 100m², giá $50/m²",
                "Flight delay 2h30m, ETA 18:45",
                "1/2 cái bánh",
            ],
            "en": [
                "The CEO has $100, up 50%",
                "Meeting on 3/15/2024 at 2:30 PM",
                "Q3 revenue: $1.5M, up 35% YoY",
                "Area 100m², price $50/m²",
                "Flight delay 2h30m, ETA 6:45 PM",
            ],
            "zh": [
                "CEO有$100，增长50%",
                "2024年3月15日14:30开会",
                "Q3收入$150万，增长35%",
                "温度25°C，湿度80%",
            ],
            "ja": [
                "CEOは$100、50%増加",
                "2024年3月15日14:30会議",
                "Q3売上$150万、35%増",
            ],
            "ko": [
                "CEO는 $100, 50% 증가",
                "2024년 3월 15일 14:30 회의",
                "Q3 매출 $150만, 35% 증가",
            ],
            "fr": [
                "Le PDG a $100, +50%",
                "Réunion le 15/3/2024 à 14h30",
                "CA T3: $1.5M, +35%",
            ],
            "de": [
                "Der CEO hat $100, +50%",
                "Meeting am 15.3.2024 um 14:30",
                "Q3 Umsatz: $1.5M, +35%",
            ],
        }
        
        print("=" * 70)
        print("MULTILINGUAL TTS NORMALIZER DEMO")
        print("=" * 70)
        
        for lang in TTSNormalizer.SUPPORTED_LANGS:
            n = TTSNormalizer(lang)
            print(f"\n📌 {lang.upper()}")
            print("-" * 70)
            
            for text in demos.get(lang, demos["en"])[:3]:
                result = n.normalize(text)
                print(f"IN:  {text}")
                print(f"OUT: {result}")
                print()


if __name__ == "__main__":
    main()