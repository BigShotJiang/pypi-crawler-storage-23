# -*- coding: utf-8 -*-
"""
brighto_norm4tts — Production Multilingual TTS Text Normalizer
==============================================================
BrighTO Technology — HATTO AI

Supported languages: vi, en, zh, ja, ko, fr, de

Quick start
-----------
    from brighto_norm4tts import TTSNormalizer

    norm = TTSNormalizer("vi")
    print(norm.normalize("GDP tăng 15.4% năm 2026"))
    # → GDP tăng mười lăm phẩy bốn phần trăm năm hai nghìn hai mươi sáu

    # Or wildcard import
    from brighto_norm4tts import *
    norm = TTSNormalizer("en")
    norm.normalize("Revenue $1.5M, up 12.3%", lower=False, punc=False)
"""

from .normalizer import (
    TTSNormalizer,
    NormRule,
    # num_to_words helpers — available for power users
    num_to_words,
    num_to_vietnamese,
    num_to_english,
    num_to_chinese,
    num_to_japanese,
    num_to_korean,
    num_to_french,
    num_to_german,
)

__all__ = [
    "TTSNormalizer",
    "NormRule",
    "num_to_words",
    "num_to_vietnamese",
    "num_to_english",
    "num_to_chinese",
    "num_to_japanese",
    "num_to_korean",
    "num_to_french",
    "num_to_german",
]

__version__ = "1.0.0"
__author__ = "BrighTO Technology — HATTO AI"
__license__ = "Proprietary"
