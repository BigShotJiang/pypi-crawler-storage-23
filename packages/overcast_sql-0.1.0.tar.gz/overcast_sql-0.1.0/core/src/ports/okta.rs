use anyhow::Result;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use serde_json::Value;

pub trait JsonSupport {
    fn set_json(&mut self, json: Value);
}

fn get_json_field(json: &Value, key: &str) -> Value {
    json.get(key).cloned().unwrap_or(Value::Null)
}

fn set_link_json(link: &mut OktaLink, raw_link: Option<&Value>) {
    link.json = raw_link.cloned().unwrap_or(Value::Null);
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaUserResourceProfile {
    #[serde(rename = "firstName")]
    pub first_name: Option<String>,
    #[serde(rename = "lastName")]
    pub last_name: Option<String>,
    #[serde(rename = "mobilePhone")]
    pub mobile_phone: Option<String>,
    #[serde(rename = "secondEmail")]
    pub second_email: Option<String>,
    pub login: String,
    pub email: Option<String>,
    #[serde(skip)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug, Clone, Copy, PartialEq, Eq)]
pub enum OktaUserStatus {
    #[serde(rename = "ACTIVE")]
    Active,
    #[serde(rename = "SUSPENDED")]
    Suspended,
    #[serde(rename = "PROVISIONED")]
    Provisioned,
    #[serde(rename = "DEPROVISIONED")]
    Deprovisioned,
    #[serde(rename = "STAGED")]
    Staged,
}

impl std::fmt::Display for OktaUserStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            Self::Active => "ACTIVE",
            Self::Suspended => "SUSPENDED",
            Self::Provisioned => "PROVISIONED",
            Self::Deprovisioned => "DEPROVISIONED",
            Self::Staged => "STAGED",
        };
        write!(f, "{}", s)
    }
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaUserType {
    pub id: String,
    #[serde(skip)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaUserCredentialsProvider {
    #[serde(rename = "type")]
    pub provider_type: String,
    pub name: String,
    #[serde(skip)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaUserCredentials {
    pub provider: OktaUserCredentialsProvider,
    #[serde(skip)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaLink {
    pub href: String,
    pub method: Option<String>,
    #[serde(skip)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaUserLinks {
    pub suspend: Option<OktaLink>,
    pub schema: Option<OktaLink>,
    #[serde(rename = "resetPassword")]
    pub reset_password: Option<OktaLink>,
    pub reactivate: Option<OktaLink>,
    #[serde(rename = "self")]
    pub self_link: Option<OktaLink>,
    #[serde(rename = "resetFactors")]
    pub reset_factors: Option<OktaLink>,
    #[serde(rename = "type")]
    pub type_link: Option<OktaLink>,
    pub deactivate: Option<OktaLink>,
    #[serde(skip)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaUserResource {
    pub id: String,
    pub status: OktaUserStatus,
    pub created: Option<DateTime<Utc>>,
    pub activated: Option<DateTime<Utc>>,
    #[serde(rename = "statusChanged")]
    pub status_changed: Option<DateTime<Utc>>,
    #[serde(rename = "lastLogin")]
    pub last_login: Option<DateTime<Utc>>,
    #[serde(rename = "lastUpdated")]
    pub last_updated: Option<DateTime<Utc>>,
    #[serde(rename = "passwordChanged")]
    pub password_changed: Option<DateTime<Utc>>,
    #[serde(rename = "type")]
    pub user_type: Option<OktaUserType>,
    pub profile: OktaUserResourceProfile,
    pub credentials: Option<OktaUserCredentials>,
    #[serde(rename = "_links")]
    pub links: Option<OktaUserLinks>,
    #[serde(default)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaGroupMemberResource {
    pub id: String,
    pub status: OktaUserStatus,
    pub created: Option<DateTime<Utc>>,
    pub activated: Option<DateTime<Utc>>,
    #[serde(rename = "statusChanged")]
    pub status_changed: Option<DateTime<Utc>>,
    #[serde(rename = "lastLogin")]
    pub last_login: Option<DateTime<Utc>>,
    #[serde(rename = "lastUpdated")]
    pub last_updated: Option<DateTime<Utc>>,
    #[serde(rename = "passwordChanged")]
    pub password_changed: Option<DateTime<Utc>>,
    #[serde(rename = "type")]
    pub user_type: Option<OktaUserType>,
    pub profile: OktaUserResourceProfile,
    #[serde(default)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaGroupProfile {
    pub name: String,
    pub description: Option<String>,
    #[serde(skip)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaGroupResource {
    pub id: String,
    pub created: Option<DateTime<Utc>>,
    #[serde(rename = "lastUpdated")]
    pub last_updated: Option<DateTime<Utc>>,
    #[serde(rename = "lastMembershipUpdated")]
    pub last_membership_updated: Option<DateTime<Utc>>,
    #[serde(rename = "type")]
    pub group_type: Option<String>,
    #[serde(rename = "objectClass")]
    pub object_class: Option<Vec<String>>,
    pub profile: OktaGroupProfile,
    #[serde(default)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaFactorLinks {
    #[serde(rename = "verify")]
    pub verify: Option<OktaLink>,
    #[serde(rename = "self")]
    pub self_link: Option<OktaLink>,
    #[serde(skip)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaFactorProfile {
    pub phone_number: Option<String>,
    pub email: Option<String>,
    #[serde(skip)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaFactorResource {
    pub id: String,
    #[serde(rename = "factorType")]
    pub factor_type: String,
    pub provider: String,
    pub status: OktaUserStatus,
    pub profile: Option<OktaFactorProfile>,
    #[serde(rename = "_links")]
    pub links: Option<OktaFactorLinks>,
    #[serde(default)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug, Clone, Copy, PartialEq, Eq)]
pub enum OktaApplicationStatus {
    #[serde(rename = "ACTIVE")]
    Active,
    #[serde(rename = "INACTIVE")]
    Inactive,
    #[serde(rename = "DELETED")]
    Deleted,
}

impl std::fmt::Display for OktaApplicationStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            Self::Active => "ACTIVE",
            Self::Inactive => "INACTIVE",
            Self::Deleted => "DELETED",
        };
        write!(f, "{}", s)
    }
}

#[cfg_attr(test, mockall::automock)]
pub trait OktaPort: Send + Sync {
    fn get_user(&self, id: &str) -> Result<Option<OktaUserResource>>;
    fn list_users(&self) -> Result<Vec<OktaUserResource>>;
    fn list_users_with_filter(&self, filter: &str) -> Result<Vec<OktaUserResource>>;
    fn list_factors_for_user(&self, user_id: &str) -> Result<Vec<OktaFactorResource>>;
    fn get_group(&self, id: &str) -> Result<Option<OktaGroupResource>>;
    fn list_groups(&self) -> Result<Vec<OktaGroupResource>>;
    fn list_users_in_group(&self, group_id: &str) -> Result<Vec<OktaGroupMemberResource>>;
    fn list_groups_for_user(&self, user_id: &str) -> Result<Vec<OktaGroupResource>>;
    fn get_policy(&self, id: &str) -> Result<Option<OktaPolicyResource>>;
    fn list_policies(&self, policy_type: &str) -> Result<Vec<OktaPolicyResource>>;
    fn list_policy_rules(&self, policy_id: &str) -> Result<Vec<OktaPolicyRuleResource>>;
    fn get_policy_rule(
        &self,
        policy_id: &str,
        rule_id: &str,
    ) -> Result<Option<OktaPolicyRuleResource>>;
    fn list_app_groups(&self, app_id: &str) -> Result<Vec<OktaAppGroupResource>>;
    fn list_app_users(&self, app_id: &str) -> Result<Vec<OktaAppUserResource>>;
    fn list_applications(&self) -> Result<Vec<OktaApplicationResource>>;
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaApplicationResource {
    pub id: String,
    pub name: String,
    pub label: String,
    #[serde(rename = "signOnMode")]
    pub sign_on_mode: Option<String>,
    pub status: OktaApplicationStatus,
    pub created: Option<DateTime<Utc>>,
    #[serde(rename = "lastUpdated")]
    pub last_updated: Option<DateTime<Utc>>,
    pub credentials: Option<Value>,
    pub settings: Option<Value>,
    #[serde(rename = "_links")]
    pub links: Option<Value>,
    pub accessibility: Option<Value>,
    pub visibility: Option<Value>,
    pub features: Option<Value>,
    #[serde(default)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaAppUserResource {
    pub id: String,
    #[serde(rename = "externalId")]
    pub external_id: Option<String>,
    pub status: Option<String>,
    pub scope: Option<String>,
    pub created: Option<DateTime<Utc>>,
    #[serde(rename = "lastUpdated")]
    pub last_updated: Option<DateTime<Utc>>,
    #[serde(rename = "statusChanged")]
    pub status_changed: Option<DateTime<Utc>>,
    pub profile: Option<Value>,
    pub credentials: Option<Value>,
    #[serde(rename = "_links")]
    pub links: Option<Value>,
    #[serde(default)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaAppGroupResource {
    pub id: String,
    pub priority: Option<i64>,
    pub profile: Option<Value>,
    #[serde(rename = "_links")]
    pub links: Option<Value>,
    #[serde(default)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaPolicyResource {
    pub id: String,
    pub name: String,
    pub description: Option<String>,
    #[serde(rename = "type")]
    pub policy_type: String,
    pub status: String,
    pub priority: Option<i64>,
    pub system: Option<bool>,
    pub created: Option<DateTime<Utc>>,
    #[serde(rename = "lastUpdated")]
    pub last_updated: Option<DateTime<Utc>>,
    pub conditions: Option<Value>,
    pub settings: Option<Value>,
    #[serde(rename = "_links")]
    pub links: Option<Value>,
    #[serde(default)]
    pub json: Value,
}

#[derive(Deserialize, Serialize, Debug)]
pub struct OktaPolicyRuleResource {
    pub id: String,
    pub name: String,
    #[serde(rename = "type")]
    pub rule_type: String,
    pub status: String,
    pub priority: Option<i64>,
    pub system: Option<bool>,
    pub created: Option<DateTime<Utc>>,
    #[serde(rename = "lastUpdated")]
    pub last_updated: Option<DateTime<Utc>>,
    pub conditions: Option<Value>,
    pub actions: Option<Value>,
    #[serde(rename = "_links")]
    pub links: Option<Value>,
    #[serde(default)]
    pub json: Value,
}

impl JsonSupport for OktaUserResource {
    fn set_json(&mut self, json: Value) {
        self.json = json;
        self.profile.json = get_json_field(&self.json, "profile");
        if let Some(user_type) = self.user_type.as_mut() {
            user_type.json = get_json_field(&self.json, "type");
        }
        if let Some(credentials) = self.credentials.as_mut() {
            credentials.json = get_json_field(&self.json, "credentials");
            if let Some(provider_json) = credentials.json.get("provider") {
                credentials.provider.json = provider_json.clone();
            } else {
                credentials.provider.json = Value::Null;
            }
        }
        if let Some(links) = self.links.as_mut() {
            links.json = get_json_field(&self.json, "_links");
            if let Some(link) = links.suspend.as_mut() {
                set_link_json(link, links.json.get("suspend"));
            }
            if let Some(link) = links.schema.as_mut() {
                set_link_json(link, links.json.get("schema"));
            }
            if let Some(link) = links.reset_password.as_mut() {
                set_link_json(link, links.json.get("resetPassword"));
            }
            if let Some(link) = links.reactivate.as_mut() {
                set_link_json(link, links.json.get("reactivate"));
            }
            if let Some(link) = links.self_link.as_mut() {
                set_link_json(link, links.json.get("self"));
            }
            if let Some(link) = links.reset_factors.as_mut() {
                set_link_json(link, links.json.get("resetFactors"));
            }
            if let Some(link) = links.type_link.as_mut() {
                set_link_json(link, links.json.get("type"));
            }
            if let Some(link) = links.deactivate.as_mut() {
                set_link_json(link, links.json.get("deactivate"));
            }
        }
    }
}

impl JsonSupport for OktaGroupMemberResource {
    fn set_json(&mut self, json: Value) {
        self.json = json;
        self.profile.json = get_json_field(&self.json, "profile");
        if let Some(user_type) = self.user_type.as_mut() {
            user_type.json = get_json_field(&self.json, "type");
        }
    }
}

impl JsonSupport for OktaGroupResource {
    fn set_json(&mut self, json: Value) {
        self.json = json;
        self.profile.json = get_json_field(&self.json, "profile");
    }
}

impl JsonSupport for OktaFactorResource {
    fn set_json(&mut self, json: Value) {
        self.json = json;
        if let Some(profile) = self.profile.as_mut() {
            profile.json = get_json_field(&self.json, "profile");
        }
        if let Some(links) = self.links.as_mut() {
            links.json = get_json_field(&self.json, "_links");
            if let Some(link) = links.verify.as_mut() {
                set_link_json(link, links.json.get("verify"));
            }
            if let Some(link) = links.self_link.as_mut() {
                set_link_json(link, links.json.get("self"));
            }
        }
    }
}

impl JsonSupport for OktaApplicationResource {
    fn set_json(&mut self, json: Value) {
        self.json = json;
    }
}

impl JsonSupport for OktaAppUserResource {
    fn set_json(&mut self, json: Value) {
        self.json = json;
    }
}

impl JsonSupport for OktaAppGroupResource {
    fn set_json(&mut self, json: Value) {
        self.json = json;
    }
}

impl JsonSupport for OktaPolicyResource {
    fn set_json(&mut self, json: Value) {
        self.json = json;
    }
}

impl JsonSupport for OktaPolicyRuleResource {
    fn set_json(&mut self, json: Value) {
        self.json = json;
    }
}
