use std::ffi::c_int;
use std::marker::PhantomData;
use std::sync::Arc;

use crate::ports::okta::{OktaFactorResource, OktaPort};
use rusqlite::vtab;
use rusqlite::vtab::{
    Context, VTab, VTabConnection, VTabCursor, sqlite3_vtab, sqlite3_vtab_cursor,
};

#[derive(Debug)]
struct OktaUserFactorRow {
    user_id: String,
    factor_id: String,
    factor_type: String,
    provider: String,
    status: String,
    profile_phone_number: Option<String>,
    profile_email: Option<String>,
    json: String,
}

#[repr(C)]
pub struct OktaUserFactorsCursor<'vtab> {
    // Base class. Must be first.
    base: sqlite3_vtab_cursor,
    okta_port: Arc<dyn OktaPort>,
    rows: Vec<OktaUserFactorRow>,
    index: usize,
    phantom: PhantomData<&'vtab OktaUserFactorsVTab>,
}

unsafe impl VTabCursor for OktaUserFactorsCursor<'_> {
    fn filter(
        &mut self,
        _idx_num: c_int,
        _idx_str: Option<&str>,
        _args: &vtab::Filters<'_>,
    ) -> Result<(), rusqlite::Error> {
        // For now, enumerate all users and fetch factors per user.
        // We can add constraint-aware plans later similar to OktaUsers.
        let users = self
            .okta_port
            .list_users()
            .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?;

        let mut rows: Vec<OktaUserFactorRow> = Vec::new();

        for user in users.into_iter() {
            let user_id = user.id;
            let factors = self
                .okta_port
                .list_factors_for_user(&user_id)
                .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?;

            for factor in factors.into_iter() {
                rows.push(Self::build_row(&user_id, factor));
            }
        }

        self.rows = rows;
        self.index = 0;
        Ok(())
    }

    fn next(&mut self) -> Result<(), rusqlite::Error> {
        self.index += 1;
        Ok(())
    }

    fn eof(&self) -> bool {
        self.index >= self.rows.len()
    }

    fn column(&self, ctx: &mut Context, col: c_int) -> Result<(), rusqlite::Error> {
        let item = &self.rows[self.index];
        match col {
            0 => ctx.set_result(&item.user_id)?,
            1 => ctx.set_result(&item.factor_id)?,
            2 => ctx.set_result(&item.factor_type)?,
            3 => ctx.set_result(&item.provider)?,
            4 => ctx.set_result(&item.status)?,
            5 => ctx.set_result(&item.profile_phone_number)?,
            6 => ctx.set_result(&item.profile_email)?,
            7 => ctx.set_result(&item.json)?,
            _ => unreachable!(),
        };
        Ok(())
    }

    fn rowid(&self) -> Result<i64, rusqlite::Error> {
        Ok(self.index as i64)
    }
}

impl OktaUserFactorsCursor<'_> {
    fn build_row(user_id: &str, factor: OktaFactorResource) -> OktaUserFactorRow {
        let profile_phone_number = factor.profile.as_ref().and_then(|p| p.phone_number.clone());
        let profile_email = factor.profile.as_ref().and_then(|p| p.email.clone());
        let json = factor.json.to_string();

        OktaUserFactorRow {
            user_id: user_id.to_string(),
            factor_id: factor.id,
            factor_type: factor.factor_type,
            provider: factor.provider,
            status: factor.status.to_string(),
            profile_phone_number,
            profile_email,
            json,
        }
    }
}

#[repr(C)]
pub struct OktaUserFactorsVTab {
    // Base class. Must be first.
    base: sqlite3_vtab,
    okta_port: Arc<dyn OktaPort>,
}

unsafe impl<'vtab> VTab<'vtab> for OktaUserFactorsVTab {
    type Aux = Arc<dyn OktaPort>;
    type Cursor = OktaUserFactorsCursor<'vtab>;

    fn connect(
        _conn: &mut VTabConnection,
        aux: Option<&Self::Aux>,
        _args: &[&[u8]],
    ) -> rusqlite::Result<(String, Self)> {
        // SQLite expects a plain `CREATE TABLE` definition here,
        // not `CREATE VIRTUAL TABLE`.
        let create_sql = "CREATE TABLE x(\
            user_id TEXT,\
            factor_id TEXT,\
            factor_type TEXT,\
            provider TEXT,\
            status TEXT,\
            profile_phone_number TEXT,\
            profile_email TEXT,\
            json JSON\
        )"
        .to_string();

        let okta_port = aux
            .cloned()
            .expect("OktaPort must be provided as module aux data");

        let vtab = OktaUserFactorsVTab {
            base: sqlite3_vtab::default(),
            okta_port,
        };
        Ok((create_sql, vtab))
    }

    fn best_index(&self, _info: &mut vtab::IndexInfo) -> rusqlite::Result<()> {
        Ok(())
    }

    fn open(&'vtab mut self) -> rusqlite::Result<Self::Cursor> {
        Ok(OktaUserFactorsCursor {
            base: sqlite3_vtab_cursor::default(),
            okta_port: self.okta_port.clone(),
            rows: Vec::new(),
            index: 0,
            phantom: PhantomData,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ports::okta::{
        MockOktaPort, OktaFactorProfile, OktaFactorResource, OktaUserResource,
        OktaUserResourceProfile, OktaUserStatus,
    };
    use crate::tables::register_okta_tables;
    use rusqlite::Connection;
    fn create_mock_user(id: &str, login: &str) -> OktaUserResource {
        OktaUserResource {
            id: id.to_string(),
            status: OktaUserStatus::Active,
            created: None,
            activated: None,
            status_changed: None,
            last_login: None,
            last_updated: None,
            password_changed: None,
            user_type: None,
            profile: OktaUserResourceProfile {
                first_name: None,
                last_name: None,
                mobile_phone: None,
                second_email: None,
                login: login.to_string(),
                email: None,
                json: serde_json::Value::Null,
            },
            credentials: None,
            links: None,
            json: serde_json::Value::Null,
        }
    }

    fn create_mock_factor(id: &str, factor_type: &str) -> OktaFactorResource {
        OktaFactorResource {
            id: id.to_string(),
            factor_type: factor_type.to_string(),
            provider: "GOOGLE".to_string(),
            status: OktaUserStatus::Active,
            profile: Some(OktaFactorProfile {
                phone_number: None,
                email: Some("test@example.com".to_string()),
                json: serde_json::Value::Null,
            }),
            links: None,
            json: serde_json::Value::Null,
        }
    }

    #[test]
    fn test_okta_user_factors_vtab_full_scan() {
        let mut mock_port = MockOktaPort::new();

        mock_port
            .expect_list_users()
            .returning(|| Ok(vec![create_mock_user("user1", "user1@example.com")]));

        mock_port
            .expect_list_factors_for_user()
            .with(mockall::predicate::eq("user1"))
            .returning(|_| Ok(vec![create_mock_factor("factor1", "push")]));

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare("SELECT user_id, factor_id FROM okta_factors")
            .unwrap();
        let rows: Vec<(String, String)> = stmt
            .query_map([], |row| Ok((row.get(0)?, row.get(1)?)))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0], ("user1".to_string(), "factor1".to_string()));
    }
}
