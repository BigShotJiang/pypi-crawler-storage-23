use std::ffi::c_int;
use std::marker::PhantomData;
use std::sync::Arc;

use crate::ports::okta::{OktaGroupResource, OktaPort};
use rusqlite::vtab;
use rusqlite::vtab::{
    Context, IndexConstraintOp, IndexFlags, VTab, VTabConnection, VTabCursor, sqlite3_vtab,
    sqlite3_vtab_cursor,
};

#[derive(Debug)]
struct GroupMemberRow {
    group_id: String,
    group_name: Option<String>,
    user_id: String,
    user_login: String,
    user_status: String,
    user_email: Option<String>,
    json: String,
}

#[repr(C)]
pub struct OktaGroupMembersCursor<'vtab> {
    // Base class. Must be first.
    base: sqlite3_vtab_cursor,
    okta_port: Arc<dyn OktaPort>,
    rows: Vec<GroupMemberRow>,
    index: usize,
    phantom: PhantomData<&'vtab OktaGroupMembersVTab>,
}

unsafe impl VTabCursor for OktaGroupMembersCursor<'_> {
    fn filter(
        &mut self,
        idx_num: c_int,
        _idx_str: Option<&str>,
        args: &vtab::Filters<'_>,
    ) -> Result<(), rusqlite::Error> {
        // Only support group_id equality to mirror /groups/{id}/users.
        if idx_num != 1 || args.is_empty() {
            return Err(rusqlite::Error::ModuleError(
                "full scan disabled for table okta_group_members (GET /groups/{id}/users); filter by group_id".to_string(),
            ));
        }

        let group_id: String = args.get(0)?;
        let rows = self.fetch_for_group(&group_id)?;

        self.rows = rows;
        self.index = 0;
        Ok(())
    }

    fn next(&mut self) -> Result<(), rusqlite::Error> {
        self.index += 1;
        Ok(())
    }

    fn eof(&self) -> bool {
        self.index >= self.rows.len()
    }

    fn column(&self, ctx: &mut Context, col: c_int) -> Result<(), rusqlite::Error> {
        let item = &self.rows[self.index];
        match col {
            0 => ctx.set_result(&item.group_id)?,
            1 => ctx.set_result(&item.group_name)?,
            2 => ctx.set_result(&item.user_id)?,
            3 => ctx.set_result(&item.user_login)?,
            4 => ctx.set_result(&item.user_status)?,
            5 => ctx.set_result(&item.user_email)?,
            6 => ctx.set_result(&item.json)?,
            _ => unreachable!(),
        };
        Ok(())
    }

    fn rowid(&self) -> Result<i64, rusqlite::Error> {
        Ok(self.index as i64)
    }
}

impl OktaGroupMembersCursor<'_> {
    fn fetch_for_group(&self, group_id: &str) -> Result<Vec<GroupMemberRow>, rusqlite::Error> {
        let maybe_group = self
            .okta_port
            .get_group(group_id)
            .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?;

        let Some(group) = maybe_group else {
            return Ok(Vec::new());
        };

        self.expand_group(group)
    }

    fn expand_group(
        &self,
        group: OktaGroupResource,
    ) -> Result<Vec<GroupMemberRow>, rusqlite::Error> {
        let group_id = group.id.clone();
        let group_name = Some(group.profile.name.clone());

        let users = self
            .okta_port
            .list_users_in_group(&group_id)
            .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?;

        Ok(users
            .into_iter()
            .map(|user| {
                let json = user.json.to_string();
                GroupMemberRow {
                    group_id: group_id.clone(),
                    group_name: group_name.clone(),
                    user_id: user.id,
                    user_login: user.profile.login,
                    user_status: user.status.to_string(),
                    user_email: user.profile.email,
                    json,
                }
            })
            .collect())
    }
}

#[repr(C)]
pub struct OktaGroupMembersVTab {
    // Base class. Must be first.
    base: sqlite3_vtab,
    okta_port: Arc<dyn OktaPort>,
}

unsafe impl<'vtab> VTab<'vtab> for OktaGroupMembersVTab {
    type Aux = Arc<dyn OktaPort>;
    type Cursor = OktaGroupMembersCursor<'vtab>;

    fn connect(
        _conn: &mut VTabConnection,
        aux: Option<&Self::Aux>,
        _args: &[&[u8]],
    ) -> rusqlite::Result<(String, Self)> {
        // SQLite expects a plain `CREATE TABLE` definition here,
        // not `CREATE VIRTUAL TABLE`.
        let create_sql = "CREATE TABLE x(\
            group_id TEXT,\
            group_name TEXT,\
            user_id TEXT,\
            user_login TEXT,\
            user_status TEXT,\
            user_email TEXT,\
            json JSON\
        )"
        .to_string();

        let okta_port = aux
            .cloned()
            .expect("OktaPort must be provided as module aux data");

        let vtab = OktaGroupMembersVTab {
            base: sqlite3_vtab::default(),
            okta_port,
        };
        Ok((create_sql, vtab))
    }

    fn best_index(&self, info: &mut vtab::IndexInfo) -> rusqlite::Result<()> {
        let mut group_id_constraint: Option<usize> = None;

        for (i, constraint) in info.constraints().enumerate() {
            if !constraint.is_usable() {
                continue;
            }
            if constraint.operator() != IndexConstraintOp::SQLITE_INDEX_CONSTRAINT_EQ {
                continue;
            }

            if constraint.column() == 0 && group_id_constraint.is_none() {
                group_id_constraint = Some(i);
            }
        }

        if let Some(i) = group_id_constraint {
            let mut usage = info.constraint_usage(i);
            usage.set_argv_index(1);
            usage.set_omit(true);

            info.set_idx_num(1);
            info.set_idx_flags(IndexFlags::SQLITE_INDEX_SCAN_UNIQUE);
            info.set_estimated_cost(1.0);
            info.set_estimated_rows(100);
        } else {
            info.set_idx_num(0);
            info.set_estimated_cost(100_000_000.0);
        }

        Ok(())
    }

    fn open(&'vtab mut self) -> rusqlite::Result<Self::Cursor> {
        Ok(OktaGroupMembersCursor {
            base: sqlite3_vtab_cursor::default(),
            okta_port: self.okta_port.clone(),
            rows: Vec::new(),
            index: 0,
            phantom: PhantomData,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ports::okta::{
        MockOktaPort, OktaGroupMemberResource, OktaGroupProfile, OktaGroupResource,
        OktaUserResourceProfile, OktaUserStatus,
    };
    use crate::tables::register_okta_tables;
    use rusqlite::Connection;
    fn create_mock_group(id: &str, name: &str) -> OktaGroupResource {
        OktaGroupResource {
            id: id.to_string(),
            created: None,
            last_updated: None,
            last_membership_updated: None,
            group_type: Some("OKTA_GROUP".to_string()),
            object_class: None,
            profile: OktaGroupProfile {
                name: name.to_string(),
                description: None,
                json: serde_json::Value::Null,
            },
            json: serde_json::Value::Null,
        }
    }

    fn create_mock_member(
        id: &str,
        login: &str,
        status: OktaUserStatus,
    ) -> OktaGroupMemberResource {
        OktaGroupMemberResource {
            id: id.to_string(),
            status,
            created: None,
            activated: None,
            status_changed: None,
            last_login: None,
            last_updated: None,
            password_changed: None,
            user_type: None,
            profile: OktaUserResourceProfile {
                first_name: None,
                last_name: None,
                mobile_phone: None,
                second_email: None,
                login: login.to_string(),
                email: None,
                json: serde_json::Value::Null,
            },
            json: serde_json::Value::Null,
        }
    }

    #[test]
    fn test_okta_group_members_filter_by_group_id() {
        let mut mock_port = MockOktaPort::new();

        mock_port
            .expect_get_group()
            .with(mockall::predicate::eq("group123"))
            .returning(|_| Ok(Some(create_mock_group("group123", "Target Group"))));

        mock_port
            .expect_list_users_in_group()
            .with(mockall::predicate::eq("group123"))
            .returning(|_| {
                Ok(vec![
                    create_mock_member("user1", "user1@example.com", OktaUserStatus::Active),
                    create_mock_member("user2", "user2@example.com", OktaUserStatus::Active),
                ])
            });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare(
                "SELECT user_id, user_login FROM okta_group_members WHERE group_id = 'group123'",
            )
            .unwrap();

        let rows: Vec<(String, String)> = stmt
            .query_map([], |row| Ok((row.get(0)?, row.get(1)?)))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(rows.len(), 2);
        assert_eq!(
            rows[0],
            ("user1".to_string(), "user1@example.com".to_string())
        );
        assert_eq!(
            rows[1],
            ("user2".to_string(), "user2@example.com".to_string())
        );
    }

    #[test]
    fn test_okta_group_members_full_scan_fails() {
        let mock_port = MockOktaPort::new();
        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db.prepare("SELECT * FROM okta_group_members").unwrap();
        let mut rows = stmt.query([]).unwrap();
        let result = rows.next();

        assert!(result.is_err());
        let err = result.err().unwrap().to_string();
        assert!(err.contains("full scan disabled"));
    }
}
