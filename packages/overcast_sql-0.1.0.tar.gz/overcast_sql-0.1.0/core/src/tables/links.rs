use std::ffi::c_int;
use std::marker::PhantomData;
use std::sync::Arc;

use crate::ports::okta::{OktaLink, OktaPort};
use rusqlite::vtab;
use rusqlite::vtab::{
    Context, VTab, VTabConnection, VTabCursor, sqlite3_vtab, sqlite3_vtab_cursor,
};

#[derive(Debug)]
struct OktaUserLinkRow {
    user_id: String,
    rel: String,
    href: String,
    method: Option<String>,
    json: String,
}

#[repr(C)]
pub struct OktaUserLinksCursor<'vtab> {
    // Base class. Must be first.
    base: sqlite3_vtab_cursor,
    okta_port: Arc<dyn OktaPort>,
    rows: Vec<OktaUserLinkRow>,
    index: usize,
    phantom: PhantomData<&'vtab OktaUserLinksVTab>,
}

unsafe impl VTabCursor for OktaUserLinksCursor<'_> {
    fn filter(
        &mut self,
        _idx_num: c_int,
        _idx_str: Option<&str>,
        _args: &vtab::Filters<'_>,
    ) -> Result<(), rusqlite::Error> {
        let users = self
            .okta_port
            .list_users()
            .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?;

        let mut rows: Vec<OktaUserLinkRow> = Vec::new();

        fn push_link(
            rows: &mut Vec<OktaUserLinkRow>,
            user_id: &str,
            rel: &str,
            link: &OktaLink,
            user_json: &str,
        ) {
            rows.push(OktaUserLinkRow {
                user_id: user_id.to_string(),
                rel: rel.to_string(),
                href: link.href.clone(),
                method: link.method.clone(),
                json: user_json.to_string(),
            });
        }

        for user in users.into_iter() {
            let user_json = user.json.to_string();
            let user_id = user.id.clone();
            if let Some(links) = user.links {
                if let Some(link) = links.suspend.as_ref() {
                    push_link(&mut rows, &user_id, "suspend", link, &user_json);
                }
                if let Some(link) = links.schema.as_ref() {
                    push_link(&mut rows, &user_id, "schema", link, &user_json);
                }
                if let Some(link) = links.reset_password.as_ref() {
                    push_link(&mut rows, &user_id, "resetPassword", link, &user_json);
                }
                if let Some(link) = links.reactivate.as_ref() {
                    push_link(&mut rows, &user_id, "reactivate", link, &user_json);
                }
                if let Some(link) = links.self_link.as_ref() {
                    push_link(&mut rows, &user_id, "self", link, &user_json);
                }
                if let Some(link) = links.reset_factors.as_ref() {
                    push_link(&mut rows, &user_id, "resetFactors", link, &user_json);
                }
                if let Some(link) = links.type_link.as_ref() {
                    push_link(&mut rows, &user_id, "type", link, &user_json);
                }
                if let Some(link) = links.deactivate.as_ref() {
                    push_link(&mut rows, &user_id, "deactivate", link, &user_json);
                }
            }
        }

        self.rows = rows;
        self.index = 0;
        Ok(())
    }

    fn next(&mut self) -> Result<(), rusqlite::Error> {
        self.index += 1;
        Ok(())
    }

    fn eof(&self) -> bool {
        self.index >= self.rows.len()
    }

    fn column(&self, ctx: &mut Context, col: c_int) -> Result<(), rusqlite::Error> {
        let item = &self.rows[self.index];
        match col {
            0 => ctx.set_result(&item.user_id)?,
            1 => ctx.set_result(&item.rel)?,
            2 => ctx.set_result(&item.href)?,
            3 => ctx.set_result(&item.method)?,
            4 => ctx.set_result(&item.json)?,
            _ => unreachable!(),
        };
        Ok(())
    }

    fn rowid(&self) -> Result<i64, rusqlite::Error> {
        Ok(self.index as i64)
    }
}

#[repr(C)]
pub struct OktaUserLinksVTab {
    // Base class. Must be first.
    base: sqlite3_vtab,
    okta_port: Arc<dyn OktaPort>,
}

unsafe impl<'vtab> VTab<'vtab> for OktaUserLinksVTab {
    type Aux = Arc<dyn OktaPort>;
    type Cursor = OktaUserLinksCursor<'vtab>;

    fn connect(
        _conn: &mut VTabConnection,
        aux: Option<&Self::Aux>,
        _args: &[&[u8]],
    ) -> rusqlite::Result<(String, Self)> {
        // SQLite expects a plain `CREATE TABLE` definition here,
        // not `CREATE VIRTUAL TABLE`.
        let create_sql =
            "CREATE TABLE x(user_id TEXT, rel TEXT, href TEXT, method TEXT, json JSON)".to_string();

        let okta_port = aux
            .cloned()
            .expect("OktaPort must be provided as module aux data");

        let vtab = OktaUserLinksVTab {
            base: sqlite3_vtab::default(),
            okta_port,
        };
        Ok((create_sql, vtab))
    }

    fn best_index(&self, _info: &mut vtab::IndexInfo) -> rusqlite::Result<()> {
        Ok(())
    }

    fn open(&'vtab mut self) -> rusqlite::Result<Self::Cursor> {
        Ok(OktaUserLinksCursor {
            base: sqlite3_vtab_cursor::default(),
            okta_port: self.okta_port.clone(),
            rows: Vec::new(),
            index: 0,
            phantom: PhantomData,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ports::okta::{
        MockOktaPort, OktaLink, OktaUserLinks, OktaUserResource, OktaUserResourceProfile,
        OktaUserStatus,
    };
    use crate::tables::register_okta_tables;
    use rusqlite::Connection;
    #[test]
    fn test_okta_user_links_vtab_full_scan() {
        let mut mock_port = MockOktaPort::new();

        mock_port.expect_list_users().returning(|| {
            // Need to manually build because create_mock_user_with_links might have issues with some fields
            Ok(vec![OktaUserResource {
                id: "user1".to_string(),
                status: OktaUserStatus::Active,
                created: None,
                activated: None,
                status_changed: None,
                last_login: None,
                last_updated: None,
                password_changed: None,
                user_type: None,
                profile: OktaUserResourceProfile {
                    first_name: None,
                    last_name: None,
                    mobile_phone: None,
                    second_email: None,
                    login: "user1@example.com".to_string(),
                    email: None,
                    json: serde_json::Value::Null,
                },
                credentials: None,
                links: Some(OktaUserLinks {
                    self_link: Some(OktaLink {
                        href: "/api/v1/users/user1".to_string(),
                        method: None,
                        json: serde_json::Value::Null,
                    }),
                    suspend: None,
                    schema: None,
                    reset_password: None,
                    reactivate: None,
                    reset_factors: None,
                    type_link: None,
                    deactivate: None,
                    json: serde_json::Value::Null,
                }),
                json: serde_json::Value::Null,
            }])
        });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare("SELECT user_id, rel, href FROM okta_links")
            .unwrap();
        let rows: Vec<(String, String, String)> = stmt
            .query_map([], |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(rows.len(), 1);
        assert_eq!(
            rows[0],
            (
                "user1".to_string(),
                "self".to_string(),
                "/api/v1/users/user1".to_string()
            )
        );
    }
}
