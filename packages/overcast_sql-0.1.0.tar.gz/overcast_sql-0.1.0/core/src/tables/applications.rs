use std::ffi::c_int;
use std::marker::PhantomData;
use std::sync::Arc;

use rusqlite::vtab;
use rusqlite::vtab::{
    Context, VTab, VTabConnection, VTabCursor, sqlite3_vtab, sqlite3_vtab_cursor,
};
use serde_json;

use crate::ports::okta::{OktaApplicationResource, OktaPort};

pub(crate) fn extract_policy_id_from_links(links: &Option<serde_json::Value>) -> Option<String> {
    let links = links.as_ref()?;

    if let Some(id) = extract_policy_id_from_key(links, "accessPolicy") {
        return Some(id);
    }
    if let Some(id) = extract_policy_id_from_key(links, "policy") {
        return Some(id);
    }

    find_policy_id_in_value(links)
}

fn extract_policy_id_from_key(links: &serde_json::Value, key: &str) -> Option<String> {
    links.get(key).and_then(find_policy_id_in_value)
}

fn find_policy_id_in_value(value: &serde_json::Value) -> Option<String> {
    match value {
        serde_json::Value::Object(map) => {
            if let Some(serde_json::Value::String(href)) = map.get("href")
                && let Some(id) = policy_id_from_href(href)
            {
                return Some(id);
            }
            for entry in map.values() {
                if let Some(id) = find_policy_id_in_value(entry) {
                    return Some(id);
                }
            }
            None
        }
        serde_json::Value::Array(items) => {
            for entry in items {
                if let Some(id) = find_policy_id_in_value(entry) {
                    return Some(id);
                }
            }
            None
        }
        _ => None,
    }
}

fn policy_id_from_href(href: &str) -> Option<String> {
    let marker = "/policies/";
    let start = href.find(marker)?;
    let rest = &href[start + marker.len()..];
    let id = rest.split(['/', '?', '#']).next().unwrap_or("");
    if id.is_empty() {
        None
    } else {
        Some(id.to_string())
    }
}

#[repr(C)]
pub struct OktaApplicationsCursor<'vtab> {
    // Base class. Must be first.
    base: sqlite3_vtab_cursor,
    okta_port: Arc<dyn OktaPort>,
    rows: Vec<OktaApplicationResource>,
    index: usize,
    phantom: PhantomData<&'vtab OktaApplicationsVTab>,
}

unsafe impl VTabCursor for OktaApplicationsCursor<'_> {
    fn filter(
        &mut self,
        _idx_num: c_int,
        _idx_str: Option<&str>,
        _args: &vtab::Filters<'_>,
    ) -> Result<(), rusqlite::Error> {
        // Currently only full scan supported
        let apps = self
            .okta_port
            .list_applications()
            .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?;

        self.rows = apps;
        self.index = 0;
        Ok(())
    }

    fn next(&mut self) -> Result<(), rusqlite::Error> {
        self.index += 1;
        Ok(())
    }

    fn eof(&self) -> bool {
        self.index >= self.rows.len()
    }

    fn column(&self, ctx: &mut Context, col: c_int) -> Result<(), rusqlite::Error> {
        let item = &self.rows[self.index];
        match col {
            0 => ctx.set_result(&item.id)?,
            1 => ctx.set_result(&item.name)?,
            2 => ctx.set_result(&item.label)?,
            3 => {
                let val = item.sign_on_mode.clone();
                ctx.set_result(&val)?;
            }
            4 => ctx.set_result(&item.status.to_string())?,
            5 => {
                let value = item.created.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            6 => {
                let value = item.last_updated.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            7 => {
                let val = item.credentials.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            8 => {
                let val = item.settings.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            9 => {
                let val = item.links.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            10 => {
                let value = extract_policy_id_from_links(&item.links);
                ctx.set_result(&value)?;
            }
            11 => {
                let val = item.accessibility.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            12 => {
                let val = item.visibility.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            13 => {
                let val = item.features.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            14 => {
                let json = item.json.to_string();
                ctx.set_result(&json)?;
            }
            _ => unreachable!(),
        };
        Ok(())
    }

    fn rowid(&self) -> Result<i64, rusqlite::Error> {
        Ok(self.index as i64)
    }
}

#[repr(C)]
pub struct OktaApplicationsVTab {
    // Base class. Must be first.
    base: sqlite3_vtab,
    okta_port: Arc<dyn OktaPort>,
}

unsafe impl<'vtab> VTab<'vtab> for OktaApplicationsVTab {
    type Aux = Arc<dyn OktaPort>;
    type Cursor = OktaApplicationsCursor<'vtab>;

    fn connect(
        _conn: &mut VTabConnection,
        aux: Option<&Self::Aux>,
        _args: &[&[u8]],
    ) -> rusqlite::Result<(String, Self)> {
        let create_sql = "CREATE TABLE x(\
            id TEXT,\
            name TEXT,\
            label TEXT,\
            sign_on_mode TEXT,\
            status TEXT,\
            created TEXT,\
            last_updated TEXT,\
            credentials JSON,\
            settings JSON,\
            links JSON,\
            policy_id TEXT,\
            accessibility JSON,\
            visibility JSON,\
            features JSON,\
            json JSON\
        )"
        .to_string();

        let okta_port = aux
            .cloned()
            .expect("OktaPort must be provided as module aux data");

        let vtab = OktaApplicationsVTab {
            base: sqlite3_vtab::default(),
            okta_port,
        };
        Ok((create_sql, vtab))
    }

    fn best_index(&self, info: &mut vtab::IndexInfo) -> rusqlite::Result<()> {
        // No specific indexes implemented yet, cost is high to encourage using others if joined?
        // Actually, without params, it's just a scan.
        info.set_estimated_cost(1000.0);
        Ok(())
    }

    fn open(&'vtab mut self) -> rusqlite::Result<Self::Cursor> {
        Ok(OktaApplicationsCursor {
            base: sqlite3_vtab_cursor::default(),
            okta_port: self.okta_port.clone(),
            rows: Vec::new(),
            index: 0,
            phantom: PhantomData,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ports::okta::{MockOktaPort, OktaApplicationStatus};
    use crate::tables::register_okta_tables;
    use rusqlite::Connection;
    fn create_mock_app() -> OktaApplicationResource {
        OktaApplicationResource {
            id: "default_app".to_string(),
            name: "test_app".to_string(),
            label: "Default App".to_string(),
            sign_on_mode: Some("UNKNOWN".to_string()),
            status: OktaApplicationStatus::Active,
            created: None,
            last_updated: None,
            credentials: None,
            settings: None,
            links: None,
            accessibility: None,
            visibility: None,
            features: None,
            json: serde_json::Value::Null,
        }
    }

    fn create_mock_app_saml() -> OktaApplicationResource {
        let mut app = create_mock_app();
        app.sign_on_mode = Some("SAML_2_0".to_string());
        app
    }

    fn create_mock_app_oidc() -> OktaApplicationResource {
        let mut app = create_mock_app();
        app.sign_on_mode = Some("OPENID_CONNECT".to_string());
        app
    }

    fn create_mock_app_bookmark() -> OktaApplicationResource {
        let mut app = create_mock_app();
        app.sign_on_mode = Some("BOOKMARK".to_string());
        app
    }

    #[test]
    fn test_okta_applications_vtab() {
        let mut mock_port = MockOktaPort::new();
        mock_port.expect_list_applications().returning(|| {
            let mut oidc_app = create_mock_app_oidc();
            oidc_app.id = "app1".to_string();
            oidc_app.label = "OIDC App".to_string();

            let mut saml_app = create_mock_app_saml();
            saml_app.id = "app2".to_string();
            saml_app.label = "SAML App".to_string();
            saml_app.status = OktaApplicationStatus::Inactive;

            let mut bookmark_app = create_mock_app_bookmark();
            bookmark_app.id = "app3".to_string();
            bookmark_app.label = "Bookmark App".to_string();
            bookmark_app.status = OktaApplicationStatus::Deleted;

            Ok(vec![oidc_app, saml_app, bookmark_app])
        });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare("SELECT id, label, status, sign_on_mode FROM okta_applications ORDER BY id")
            .unwrap();
        let rows: Vec<(String, String, String, String)> = stmt
            .query_map([], |row| {
                Ok((row.get(0)?, row.get(1)?, row.get(2)?, row.get(3)?))
            })
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(rows.len(), 3);
        assert_eq!(
            rows[0],
            (
                "app1".to_string(),
                "OIDC App".to_string(),
                "ACTIVE".to_string(),
                "OPENID_CONNECT".to_string()
            )
        );
        assert_eq!(
            rows[1],
            (
                "app2".to_string(),
                "SAML App".to_string(),
                "INACTIVE".to_string(),
                "SAML_2_0".to_string()
            )
        );
        assert_eq!(
            rows[2],
            (
                "app3".to_string(),
                "Bookmark App".to_string(),
                "DELETED".to_string(),
                "BOOKMARK".to_string()
            )
        );
    }

    #[test]
    fn test_okta_applications_vtab_json_syntax() {
        let mut mock_port = MockOktaPort::new();
        mock_port.expect_list_applications().returning(|| {
            let mut app1 = create_mock_app();
            app1.id = "app1".to_string();
            app1.json = serde_json::json!({"custom_field": "value1"});

            let mut app2 = create_mock_app();
            app2.id = "app2".to_string();
            app2.json = serde_json::json!({"custom_field": "value2"});

            Ok(vec![app1, app2])
        });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        // Test ->> syntax for extraction (returns text/integer/etc stripping quotes)
        let mut stmt = db
            .prepare("SELECT id FROM okta_applications WHERE json ->> '$.custom_field' = 'value1'")
            .unwrap();

        let ids: Vec<String> = stmt
            .query_map([], |row| row.get(0))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(ids.len(), 1);
        assert_eq!(ids[0], "app1");
    }

    #[test]
    fn test_okta_applications_redirect_uris() {
        let mut mock_port = MockOktaPort::new();
        mock_port.expect_list_applications().returning(|| {
            let mut app1 = create_mock_app_oidc();
            app1.id = "app1".to_string();

            // Construct nested JSON for settings -> oauthClient -> redirect_uris
            app1.settings = Some(serde_json::json!({
                "oauthClient": {
                    "redirect_uris": [
                        "https://example.com/callback",
                        "https://localhost:8080/callback"
                    ]
                }
            }));

            Ok(vec![app1])
        });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        // 1. Query extracting the first redirect URI using arrow syntax on settings column
        let mut stmt = db
            .prepare("SELECT settings ->> '$.oauthClient.redirect_uris[0]' FROM okta_applications WHERE id = 'app1'")
            .unwrap();

        let uri: String = stmt.query_row([], |row| row.get(0)).unwrap();
        assert_eq!(uri, "https://example.com/callback");

        // 2. Query specific index
        let mut stmt = db
            .prepare("SELECT id FROM okta_applications WHERE settings ->> '$.oauthClient.redirect_uris[1]' = 'https://localhost:8080/callback'")
            .unwrap();

        let ids: Vec<String> = stmt
            .query_map([], |row| row.get(0))
            .unwrap()
            .map(|r| r.unwrap_or_else(|e| panic!("Row error: {}", e)))
            .collect();

        assert_eq!(ids.len(), 1);
        assert_eq!(ids[0], "app1");
    }

    #[test]
    fn test_okta_applications_policy_id_from_links() {
        let mut mock_port = MockOktaPort::new();
        mock_port.expect_list_applications().returning(|| {
            let mut app1 = create_mock_app_oidc();
            app1.id = "app1".to_string();
            app1.links = Some(serde_json::json!({
                "accessPolicy": {
                    "href": "https://example.okta.com/api/v1/policies/policy123"
                }
            }));

            Ok(vec![app1])
        });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let policy_id: Option<String> = db
            .query_row(
                "SELECT policy_id FROM okta_applications WHERE id = 'app1'",
                [],
                |row| row.get(0),
            )
            .unwrap();

        assert_eq!(policy_id, Some("policy123".to_string()));
    }
}
