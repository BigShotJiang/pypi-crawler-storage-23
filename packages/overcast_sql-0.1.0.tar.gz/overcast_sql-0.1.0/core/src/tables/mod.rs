use rusqlite::vtab::eponymous_only_module;
use rusqlite::{Connection, Result};
use std::sync::Arc;

use crate::ports::okta::OktaPort;
use crate::tables::app_groups::OktaAppGroupsVTab;
use crate::tables::app_users::OktaAppUsersVTab;
use crate::tables::applications::OktaApplicationsVTab;
use crate::tables::factors::OktaUserFactorsVTab;
use crate::tables::group_members::OktaGroupMembersVTab;
use crate::tables::groups::OktaGroupsVTab;
use crate::tables::links::OktaUserLinksVTab;
use crate::tables::policies::OktaPoliciesVTab;
use crate::tables::policy_apps::OktaPolicyAppsVTab;
use crate::tables::policy_rules::OktaPolicyRulesVTab;
use crate::tables::user_groups::OktaUserGroupsVTab;
use crate::tables::users::OktaUsersVTab;

pub mod app_groups;
pub mod app_users;
pub mod applications;
pub mod factors;
pub mod group_members;
pub mod groups;
pub mod links;
pub mod policies;
pub mod policy_apps;
pub mod policy_rules;
pub mod user_groups;
pub mod users;

pub fn register_okta_tables(conn: &Connection, okta_port: Arc<dyn OktaPort>) -> Result<()> {
    conn.create_module(
        "okta_users",
        eponymous_only_module::<OktaUsersVTab>(),
        Some(okta_port.clone()),
    )?;

    conn.create_module(
        "okta_factors",
        eponymous_only_module::<OktaUserFactorsVTab>(),
        Some(okta_port.clone()),
    )?;

    conn.create_module(
        "okta_groups",
        eponymous_only_module::<OktaGroupsVTab>(),
        Some(okta_port.clone()),
    )?;

    conn.create_module(
        "okta_group_members",
        eponymous_only_module::<OktaGroupMembersVTab>(),
        Some(okta_port.clone()),
    )?;

    conn.create_module(
        "okta_user_groups",
        eponymous_only_module::<OktaUserGroupsVTab>(),
        Some(okta_port.clone()),
    )?;

    conn.create_module(
        "okta_links",
        eponymous_only_module::<OktaUserLinksVTab>(),
        Some(okta_port.clone()),
    )?;

    conn.create_module(
        "okta_app_users",
        eponymous_only_module::<OktaAppUsersVTab>(),
        Some(okta_port.clone()),
    )?;

    conn.create_module(
        "okta_app_groups",
        eponymous_only_module::<OktaAppGroupsVTab>(),
        Some(okta_port.clone()),
    )?;

    conn.create_module(
        "okta_policies",
        eponymous_only_module::<OktaPoliciesVTab>(),
        Some(okta_port.clone()),
    )?;

    conn.create_module(
        "okta_policy_rules",
        eponymous_only_module::<OktaPolicyRulesVTab>(),
        Some(okta_port.clone()),
    )?;

    conn.create_module(
        "okta_policy_apps",
        eponymous_only_module::<OktaPolicyAppsVTab>(),
        Some(okta_port.clone()),
    )?;

    conn.create_module(
        "okta_applications",
        eponymous_only_module::<OktaApplicationsVTab>(),
        Some(okta_port),
    )?;

    Ok(())
}
