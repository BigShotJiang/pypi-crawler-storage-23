use std::ffi::c_int;
use std::marker::PhantomData;
use std::sync::Arc;

use crate::ports::okta::{OktaGroupResource, OktaPort};
use rusqlite::vtab;
use rusqlite::vtab::{
    Context, IndexConstraintOp, IndexFlags, VTab, VTabConnection, VTabCursor, sqlite3_vtab,
    sqlite3_vtab_cursor,
};

#[repr(C)]
pub struct OktaGroupsCursor<'vtab> {
    // Base class. Must be first.
    base: sqlite3_vtab_cursor,
    okta_port: Arc<dyn OktaPort>,
    rows: Vec<OktaGroupResource>,
    index: usize,
    phantom: PhantomData<&'vtab OktaGroupsVTab>,
}

unsafe impl VTabCursor for OktaGroupsCursor<'_> {
    fn filter(
        &mut self,
        idx_num: c_int,
        _idx_str: Option<&str>,
        args: &vtab::Filters<'_>,
    ) -> Result<(), rusqlite::Error> {
        let groups = match idx_num {
            1 => {
                if args.is_empty() {
                    Vec::new()
                } else {
                    let id: String = args.get(0)?;
                    match self
                        .okta_port
                        .get_group(&id)
                        .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?
                    {
                        Some(group) => vec![group],
                        None => Vec::new(),
                    }
                }
            }
            _ => self
                .okta_port
                .list_groups()
                .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?,
        };

        self.rows = groups;
        self.index = 0;
        Ok(())
    }

    fn next(&mut self) -> Result<(), rusqlite::Error> {
        self.index += 1;
        Ok(())
    }

    fn eof(&self) -> bool {
        self.index >= self.rows.len()
    }

    fn column(&self, ctx: &mut Context, col: c_int) -> Result<(), rusqlite::Error> {
        let item = &self.rows[self.index];
        match col {
            0 => ctx.set_result(&item.id)?,
            1 => ctx.set_result(&item.profile.name)?,
            2 => ctx.set_result(&item.profile.description)?,
            3 => {
                let value = item.created.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?
            }
            4 => {
                let value = item.last_updated.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?
            }
            5 => {
                let value = item
                    .last_membership_updated
                    .as_ref()
                    .map(|d| d.to_rfc3339());
                ctx.set_result(&value)?
            }
            6 => ctx.set_result(&item.group_type)?,
            7 => {
                let value = item.object_class.as_ref().map(|classes| classes.join(","));
                ctx.set_result(&value)?
            }
            8 => {
                let json = item.json.to_string();
                ctx.set_result(&json)?;
            }
            _ => unreachable!(),
        };
        Ok(())
    }

    fn rowid(&self) -> Result<i64, rusqlite::Error> {
        Ok(self.index as i64)
    }
}

#[repr(C)]
pub struct OktaGroupsVTab {
    // Base class. Must be first.
    base: sqlite3_vtab,
    okta_port: Arc<dyn OktaPort>,
}

unsafe impl<'vtab> VTab<'vtab> for OktaGroupsVTab {
    type Aux = Arc<dyn OktaPort>;
    type Cursor = OktaGroupsCursor<'vtab>;

    fn connect(
        _conn: &mut VTabConnection,
        aux: Option<&Self::Aux>,
        _args: &[&[u8]],
    ) -> rusqlite::Result<(String, Self)> {
        // SQLite expects a plain `CREATE TABLE` definition here,
        // not `CREATE VIRTUAL TABLE`.
        let create_sql = "CREATE TABLE x(\
            id TEXT,\
            name TEXT,\
            description TEXT,\
            created TEXT,\
            last_updated TEXT,\
            last_membership_updated TEXT,\
            group_type TEXT,\
            object_class TEXT,\
            json JSON\
        )"
        .to_string();

        let okta_port = aux
            .cloned()
            .expect("OktaPort must be provided as module aux data");

        let vtab = OktaGroupsVTab {
            base: sqlite3_vtab::default(),
            okta_port,
        };
        Ok((create_sql, vtab))
    }

    fn best_index(&self, info: &mut vtab::IndexInfo) -> rusqlite::Result<()> {
        let mut id_constraint: Option<usize> = None;

        for (i, constraint) in info.constraints().enumerate() {
            if !constraint.is_usable() {
                continue;
            }
            if constraint.operator() != IndexConstraintOp::SQLITE_INDEX_CONSTRAINT_EQ {
                continue;
            }

            if constraint.column() == 0 && id_constraint.is_none() {
                id_constraint = Some(i);
            }
        }

        if let Some(i) = id_constraint {
            let mut usage = info.constraint_usage(i);
            usage.set_argv_index(1);
            usage.set_omit(true);

            info.set_idx_num(1);
            info.set_idx_flags(IndexFlags::SQLITE_INDEX_SCAN_UNIQUE);
            info.set_estimated_cost(1.0);
            info.set_estimated_rows(1);
        } else {
            info.set_idx_num(0);
            info.set_estimated_cost(100_000.0);
        }

        Ok(())
    }

    fn open(&'vtab mut self) -> rusqlite::Result<Self::Cursor> {
        Ok(OktaGroupsCursor {
            base: sqlite3_vtab_cursor::default(),
            okta_port: self.okta_port.clone(),
            rows: Vec::new(),
            index: 0,
            phantom: PhantomData,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ports::okta::{MockOktaPort, OktaGroupProfile, OktaGroupResource};
    use crate::tables::register_okta_tables;
    use rusqlite::Connection;
    fn create_mock_group(id: &str, name: &str) -> OktaGroupResource {
        OktaGroupResource {
            id: id.to_string(),
            created: None,
            last_updated: None,
            last_membership_updated: None,
            group_type: Some("OKTA_GROUP".to_string()),
            object_class: None,
            profile: OktaGroupProfile {
                name: name.to_string(),
                description: None,
                json: serde_json::Value::Null,
            },
            json: serde_json::Value::Null,
        }
    }

    #[test]
    fn test_okta_groups_vtab_full_scan() {
        let mut mock_port = MockOktaPort::new();
        mock_port.expect_list_groups().returning(|| {
            Ok(vec![
                create_mock_group("group1", "Group 1"),
                create_mock_group("group2", "Group 2"),
            ])
        });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db.prepare("SELECT id, name FROM okta_groups").unwrap();
        let rows: Vec<(String, String)> = stmt
            .query_map([], |row| Ok((row.get(0)?, row.get(1)?)))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(rows.len(), 2);
        assert_eq!(rows[0], ("group1".to_string(), "Group 1".to_string()));
    }

    #[test]
    fn test_okta_groups_vtab_filter_by_id() {
        let mut mock_port = MockOktaPort::new();
        mock_port
            .expect_get_group()
            .with(mockall::predicate::eq("group123"))
            .returning(|_| Ok(Some(create_mock_group("group123", "Target Group"))));

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare("SELECT name FROM okta_groups WHERE id = 'group123'")
            .unwrap();
        let name: String = stmt.query_row([], |row| row.get(0)).unwrap();

        assert_eq!(name, "Target Group");
    }
}
