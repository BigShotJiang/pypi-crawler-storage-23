use std::collections::HashSet;
use std::ffi::c_int;
use std::marker::PhantomData;
use std::sync::Arc;

use crate::ports::okta::{OktaPolicyResource, OktaPort};
use rusqlite::vtab;
use rusqlite::vtab::{
    Context, IndexConstraintOp, VTab, VTabConnection, VTabCursor, sqlite3_vtab, sqlite3_vtab_cursor,
};

const DEFAULT_POLICY_TYPES: [&str; 2] = ["OKTA_SIGN_ON", "ACCESS_POLICY"];

#[repr(C)]
pub struct OktaPoliciesCursor<'vtab> {
    // Base class. Must be first.
    base: sqlite3_vtab_cursor,
    okta_port: Arc<dyn OktaPort>,
    rows: Vec<OktaPolicyResource>,
    index: usize,
    phantom: PhantomData<&'vtab OktaPoliciesVTab>,
}

unsafe impl VTabCursor for OktaPoliciesCursor<'_> {
    fn filter(
        &mut self,
        idx_num: c_int,
        _idx_str: Option<&str>,
        args: &vtab::Filters<'_>,
    ) -> Result<(), rusqlite::Error> {
        let policies = match idx_num {
            1 => {
                if args.is_empty() {
                    self.list_default_policies()?
                } else {
                    let policy_type: String = args.get(0)?;
                    self.list_policies_by_type(&policy_type)?
                }
            }
            _ => self.list_default_policies()?,
        };

        self.rows = policies;
        self.index = 0;
        Ok(())
    }

    fn next(&mut self) -> Result<(), rusqlite::Error> {
        self.index += 1;
        Ok(())
    }

    fn eof(&self) -> bool {
        self.index >= self.rows.len()
    }

    fn column(&self, ctx: &mut Context, col: c_int) -> Result<(), rusqlite::Error> {
        let item = &self.rows[self.index];
        match col {
            0 => ctx.set_result(&item.id)?,
            1 => ctx.set_result(&item.name)?,
            2 => ctx.set_result(&item.description)?,
            3 => ctx.set_result(&item.policy_type)?,
            4 => ctx.set_result(&item.status)?,
            5 => ctx.set_result(&item.priority)?,
            6 => ctx.set_result(&item.system)?,
            7 => {
                let value = item.created.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            8 => {
                let value = item.last_updated.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            9 => {
                let val = item.conditions.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            10 => {
                let val = item.settings.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            11 => {
                let val = item.links.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            12 => {
                let json = item.json.to_string();
                ctx.set_result(&json)?;
            }
            _ => unreachable!(),
        };
        Ok(())
    }

    fn rowid(&self) -> Result<i64, rusqlite::Error> {
        Ok(self.index as i64)
    }
}

impl OktaPoliciesCursor<'_> {
    fn list_policies_by_type(
        &self,
        policy_type: &str,
    ) -> Result<Vec<OktaPolicyResource>, rusqlite::Error> {
        self.okta_port
            .list_policies(policy_type)
            .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))
    }

    fn list_default_policies(&self) -> Result<Vec<OktaPolicyResource>, rusqlite::Error> {
        let mut results = Vec::new();
        let mut seen: HashSet<String> = HashSet::new();

        for policy_type in DEFAULT_POLICY_TYPES {
            let policies = self.list_policies_by_type(policy_type)?;
            for policy in policies {
                if seen.insert(policy.id.clone()) {
                    results.push(policy);
                }
            }
        }

        Ok(results)
    }
}

#[repr(C)]
pub struct OktaPoliciesVTab {
    // Base class. Must be first.
    base: sqlite3_vtab,
    okta_port: Arc<dyn OktaPort>,
}

unsafe impl<'vtab> VTab<'vtab> for OktaPoliciesVTab {
    type Aux = Arc<dyn OktaPort>;
    type Cursor = OktaPoliciesCursor<'vtab>;

    fn connect(
        _conn: &mut VTabConnection,
        aux: Option<&Self::Aux>,
        _args: &[&[u8]],
    ) -> rusqlite::Result<(String, Self)> {
        let create_sql = "CREATE TABLE x(\
            id TEXT,\
            name TEXT,\
            description TEXT,\
            type TEXT,\
            status TEXT,\
            priority INTEGER,\
            system BOOLEAN,\
            created TEXT,\
            last_updated TEXT,\
            conditions JSON,\
            settings JSON,\
            links JSON,\
            json JSON\
        )"
        .to_string();

        let okta_port = aux
            .cloned()
            .expect("OktaPort must be provided as module aux data");

        let vtab = OktaPoliciesVTab {
            base: sqlite3_vtab::default(),
            okta_port,
        };
        Ok((create_sql, vtab))
    }

    fn best_index(&self, info: &mut vtab::IndexInfo) -> rusqlite::Result<()> {
        let mut type_constraint: Option<usize> = None;

        for (i, constraint) in info.constraints().enumerate() {
            if !constraint.is_usable() {
                continue;
            }
            if constraint.operator() != IndexConstraintOp::SQLITE_INDEX_CONSTRAINT_EQ {
                continue;
            }

            if constraint.column() == 3 && type_constraint.is_none() {
                type_constraint = Some(i);
            }
        }

        if let Some(i) = type_constraint {
            let mut usage = info.constraint_usage(i);
            usage.set_argv_index(1);
            usage.set_omit(true);

            info.set_idx_num(1);
            info.set_estimated_cost(100.0);
            info.set_estimated_rows(1000);
        } else {
            info.set_idx_num(0);
            info.set_estimated_cost(1000.0);
        }
        Ok(())
    }

    fn open(&'vtab mut self) -> rusqlite::Result<Self::Cursor> {
        Ok(OktaPoliciesCursor {
            base: sqlite3_vtab_cursor::default(),
            okta_port: self.okta_port.clone(),
            rows: Vec::new(),
            index: 0,
            phantom: PhantomData,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ports::okta::MockOktaPort;
    use crate::tables::register_okta_tables;
    use rusqlite::Connection;
    fn create_mock_policy(id: &str, name: &str, policy_type: &str) -> OktaPolicyResource {
        OktaPolicyResource {
            id: id.to_string(),
            name: name.to_string(),
            description: None,
            policy_type: policy_type.to_string(),
            status: "ACTIVE".to_string(),
            priority: Some(1),
            system: Some(false),
            created: None,
            last_updated: None,
            conditions: None,
            settings: None,
            links: None,
            json: serde_json::Value::Null,
        }
    }

    #[test]
    fn test_okta_policies_vtab_full_scan() {
        let mut mock_port = MockOktaPort::new();
        mock_port
            .expect_list_policies()
            .times(DEFAULT_POLICY_TYPES.len())
            .returning(|policy_type| match policy_type {
                "OKTA_SIGN_ON" => {
                    let mut policy1 =
                        create_mock_policy("policy1", "Sign-on Policy", "OKTA_SIGN_ON");
                    policy1.priority = Some(1);
                    Ok(vec![policy1])
                }
                "ACCESS_POLICY" => {
                    let mut policy2 =
                        create_mock_policy("policy2", "Access Policy", "ACCESS_POLICY");
                    policy2.status = "INACTIVE".to_string();
                    policy2.priority = Some(2);
                    Ok(vec![policy2])
                }
                _ => Ok(Vec::new()),
            });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare("SELECT id, name, type, status FROM okta_policies ORDER BY id")
            .unwrap();
        let rows: Vec<(String, String, String, String)> = stmt
            .query_map([], |row| {
                Ok((row.get(0)?, row.get(1)?, row.get(2)?, row.get(3)?))
            })
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(rows.len(), 2);
        assert_eq!(
            rows[0],
            (
                "policy1".to_string(),
                "Sign-on Policy".to_string(),
                "OKTA_SIGN_ON".to_string(),
                "ACTIVE".to_string()
            )
        );
        assert_eq!(
            rows[1],
            (
                "policy2".to_string(),
                "Access Policy".to_string(),
                "ACCESS_POLICY".to_string(),
                "INACTIVE".to_string()
            )
        );
    }

    #[test]
    fn test_okta_policies_vtab_json_syntax() {
        let mut mock_port = MockOktaPort::new();
        mock_port
            .expect_list_policies()
            .times(DEFAULT_POLICY_TYPES.len())
            .returning(|policy_type| {
                if policy_type != "OKTA_SIGN_ON" {
                    return Ok(Vec::new());
                }

                let mut policy1 = create_mock_policy("policy1", "Policy 1", "OKTA_SIGN_ON");
                policy1.json = serde_json::json!({"custom_field": "value1"});

                let mut policy2 = create_mock_policy("policy2", "Policy 2", "OKTA_SIGN_ON");
                policy2.json = serde_json::json!({"custom_field": "value2"});

                Ok(vec![policy1, policy2])
            });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare("SELECT id FROM okta_policies WHERE json ->> '$.custom_field' = 'value1'")
            .unwrap();
        let ids: Vec<String> = stmt
            .query_map([], |row| row.get(0))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(ids, vec!["policy1".to_string()]);
    }
}
