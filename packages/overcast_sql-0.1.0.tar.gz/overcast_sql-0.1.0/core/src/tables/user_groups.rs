use std::ffi::c_int;
use std::marker::PhantomData;
use std::sync::Arc;

use crate::ports::okta::{OktaGroupResource, OktaPort, OktaUserResource};
use rusqlite::vtab;
use rusqlite::vtab::{
    Context, IndexConstraintOp, IndexFlags, VTab, VTabConnection, VTabCursor, sqlite3_vtab,
    sqlite3_vtab_cursor,
};

#[derive(Debug)]
struct UserGroupRow {
    user_id: String,
    user_login: String,
    user_status: String,
    user_email: Option<String>,
    group_id: String,
    group_name: String,
    group_type: Option<String>,
    json: String,
}

#[repr(C)]
pub struct OktaUserGroupsCursor<'vtab> {
    // Base class. Must be first.
    base: sqlite3_vtab_cursor,
    okta_port: Arc<dyn OktaPort>,
    rows: Vec<UserGroupRow>,
    index: usize,
    phantom: PhantomData<&'vtab OktaUserGroupsVTab>,
}

unsafe impl VTabCursor for OktaUserGroupsCursor<'_> {
    fn filter(
        &mut self,
        idx_num: c_int,
        _idx_str: Option<&str>,
        args: &vtab::Filters<'_>,
    ) -> Result<(), rusqlite::Error> {
        // Only support user_id equality to mirror /users/{id}/groups.
        if idx_num != 1 || args.is_empty() {
            return Err(rusqlite::Error::ModuleError(
                "full scan disabled for table okta_user_groups (GET /users/{id}/groups); filter by user_id".to_string(),
            ));
        }

        let user_id: String = args.get(0)?;
        let rows = self.fetch_for_user(&user_id)?;

        self.rows = rows;
        self.index = 0;
        Ok(())
    }

    fn next(&mut self) -> Result<(), rusqlite::Error> {
        self.index += 1;
        Ok(())
    }

    fn eof(&self) -> bool {
        self.index >= self.rows.len()
    }

    fn column(&self, ctx: &mut Context, col: c_int) -> Result<(), rusqlite::Error> {
        let item = &self.rows[self.index];
        match col {
            0 => ctx.set_result(&item.user_id)?,
            1 => ctx.set_result(&item.user_login)?,
            2 => ctx.set_result(&item.user_status)?,
            3 => ctx.set_result(&item.user_email)?,
            4 => ctx.set_result(&item.group_id)?,
            5 => ctx.set_result(&item.group_name)?,
            6 => ctx.set_result(&item.group_type)?,
            7 => ctx.set_result(&item.json)?,
            _ => unreachable!(),
        };
        Ok(())
    }

    fn rowid(&self) -> Result<i64, rusqlite::Error> {
        Ok(self.index as i64)
    }
}

impl OktaUserGroupsCursor<'_> {
    fn fetch_for_user(&self, user_id: &str) -> Result<Vec<UserGroupRow>, rusqlite::Error> {
        let maybe_user = self
            .okta_port
            .get_user(user_id)
            .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?;
        let Some(user) = maybe_user else {
            return Ok(Vec::new());
        };

        let groups = self
            .okta_port
            .list_groups_for_user(user_id)
            .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?;

        Ok(groups
            .into_iter()
            .map(|group| Self::build_row(&user, group))
            .collect())
    }

    fn build_row(user: &OktaUserResource, group: OktaGroupResource) -> UserGroupRow {
        let json = group.json.to_string();
        UserGroupRow {
            user_id: user.id.clone(),
            user_login: user.profile.login.clone(),
            user_status: user.status.to_string(),
            user_email: user.profile.email.clone(),
            group_id: group.id,
            group_name: group.profile.name,
            group_type: group.group_type,
            json,
        }
    }
}

#[repr(C)]
pub struct OktaUserGroupsVTab {
    // Base class. Must be first.
    base: sqlite3_vtab,
    okta_port: Arc<dyn OktaPort>,
}

unsafe impl<'vtab> VTab<'vtab> for OktaUserGroupsVTab {
    type Aux = Arc<dyn OktaPort>;
    type Cursor = OktaUserGroupsCursor<'vtab>;

    fn connect(
        _conn: &mut VTabConnection,
        aux: Option<&Self::Aux>,
        _args: &[&[u8]],
    ) -> rusqlite::Result<(String, Self)> {
        let create_sql = "CREATE TABLE x(\
            user_id TEXT,\
            user_login TEXT,\
            user_status TEXT,\
            user_email TEXT,\
            group_id TEXT,\
            group_name TEXT,\
            group_type TEXT,\
            json JSON\
        )"
        .to_string();

        let okta_port = aux
            .cloned()
            .expect("OktaPort must be provided as module aux data");

        let vtab = OktaUserGroupsVTab {
            base: sqlite3_vtab::default(),
            okta_port,
        };
        Ok((create_sql, vtab))
    }

    fn best_index(&self, info: &mut vtab::IndexInfo) -> rusqlite::Result<()> {
        let mut user_id_constraint: Option<usize> = None;

        for (i, constraint) in info.constraints().enumerate() {
            if !constraint.is_usable() {
                continue;
            }
            if constraint.operator() != IndexConstraintOp::SQLITE_INDEX_CONSTRAINT_EQ {
                continue;
            }

            if constraint.column() == 0 && user_id_constraint.is_none() {
                user_id_constraint = Some(i);
            }
        }

        if let Some(i) = user_id_constraint {
            let mut usage = info.constraint_usage(i);
            usage.set_argv_index(1);
            usage.set_omit(true);

            info.set_idx_num(1);
            info.set_idx_flags(IndexFlags::SQLITE_INDEX_SCAN_UNIQUE);
            info.set_estimated_cost(1.0);
            info.set_estimated_rows(100);
        } else {
            info.set_idx_num(0);
            info.set_estimated_cost(100_000_000.0);
        }

        Ok(())
    }

    fn open(&'vtab mut self) -> rusqlite::Result<Self::Cursor> {
        Ok(OktaUserGroupsCursor {
            base: sqlite3_vtab_cursor::default(),
            okta_port: self.okta_port.clone(),
            rows: Vec::new(),
            index: 0,
            phantom: PhantomData,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ports::okta::{
        MockOktaPort, OktaGroupProfile, OktaGroupResource, OktaUserResource,
        OktaUserResourceProfile, OktaUserStatus,
    };
    use crate::tables::register_okta_tables;
    use rusqlite::Connection;
    fn create_mock_user(id: &str, login: &str, status: OktaUserStatus) -> OktaUserResource {
        OktaUserResource {
            id: id.to_string(),
            status,
            created: None,
            activated: None,
            status_changed: None,
            last_login: None,
            last_updated: None,
            password_changed: None,
            user_type: None,
            profile: OktaUserResourceProfile {
                first_name: None,
                last_name: None,
                mobile_phone: None,
                second_email: None,
                login: login.to_string(),
                email: None,
                json: serde_json::Value::Null,
            },
            credentials: None,
            links: None,
            json: serde_json::Value::Null,
        }
    }

    fn create_mock_group(id: &str, name: &str) -> OktaGroupResource {
        OktaGroupResource {
            id: id.to_string(),
            created: None,
            last_updated: None,
            last_membership_updated: None,
            group_type: Some("OKTA_GROUP".to_string()),
            object_class: None,
            profile: OktaGroupProfile {
                name: name.to_string(),
                description: None,
                json: serde_json::Value::Null,
            },
            json: serde_json::Value::Null,
        }
    }

    #[test]
    fn test_okta_user_groups_filter_by_user_id() {
        let mut mock_port = MockOktaPort::new();

        mock_port
            .expect_get_user()
            .with(mockall::predicate::eq("user123"))
            .returning(|_| {
                Ok(Some(create_mock_user(
                    "user123",
                    "test@example.com",
                    OktaUserStatus::Active,
                )))
            });

        mock_port
            .expect_list_groups_for_user()
            .with(mockall::predicate::eq("user123"))
            .returning(|_| {
                Ok(vec![
                    create_mock_group("group1", "Group 1"),
                    create_mock_group("group2", "Group 2"),
                ])
            });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare("SELECT group_id, group_name FROM okta_user_groups WHERE user_id = 'user123'")
            .unwrap();

        let rows: Vec<(String, String)> = stmt
            .query_map([], |row| Ok((row.get(0)?, row.get(1)?)))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(rows.len(), 2);
        assert_eq!(rows[0], ("group1".to_string(), "Group 1".to_string()));
        assert_eq!(rows[1], ("group2".to_string(), "Group 2".to_string()));
    }

    #[test]
    fn test_okta_user_groups_user_not_found() {
        let mut mock_port = MockOktaPort::new();

        mock_port
            .expect_get_user()
            .with(mockall::predicate::eq("nonexistent"))
            .returning(|_| Ok(None));

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare("SELECT group_id FROM okta_user_groups WHERE user_id = 'nonexistent'")
            .unwrap();

        let rows: Vec<String> = stmt
            .query_map([], |row| row.get(0))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(rows.len(), 0);
    }

    #[test]
    fn test_okta_user_groups_full_scan_fails() {
        let mock_port = MockOktaPort::new();
        let db = Connection::open_in_memory().unwrap();
        crate::tables::register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db.prepare("SELECT * FROM okta_user_groups").unwrap();
        let mut rows = stmt.query([]).unwrap();
        let result = rows.next();

        assert!(result.is_err());
        let err = result.err().unwrap().to_string();
        assert!(err.contains("full scan disabled"));
    }
}
