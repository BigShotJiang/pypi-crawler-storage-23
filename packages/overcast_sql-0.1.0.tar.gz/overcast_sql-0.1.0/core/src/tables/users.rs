use std::ffi::c_int;
use std::marker::PhantomData;
use std::sync::Arc;

use rusqlite::vtab;
use rusqlite::vtab::{
    Context, IndexConstraintOp, IndexFlags, VTab, VTabConnection, VTabCursor, sqlite3_vtab,
    sqlite3_vtab_cursor,
};
use serde_json;

use crate::ports::okta::{OktaPort, OktaUserResource};

#[repr(C)]
pub struct OktaUsersCursor<'vtab> {
    // Base class. Must be first.
    base: sqlite3_vtab_cursor,
    okta_port: Arc<dyn OktaPort>,
    rows: Vec<OktaUserResource>,
    index: usize,
    phantom: PhantomData<&'vtab OktaUsersVTab>,
}

unsafe impl VTabCursor for OktaUsersCursor<'_> {
    fn filter(
        &mut self,
        idx_num: c_int,
        _idx_str: Option<&str>,
        args: &vtab::Filters<'_>,
    ) -> Result<(), rusqlite::Error> {
        let users = match idx_num {
            // 1 => optimized lookup by id
            1 => {
                if args.is_empty() {
                    Vec::new()
                } else {
                    let id: String = args.get(0)?;
                    match self
                        .okta_port
                        .get_user(&id)
                        .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?
                    {
                        Some(user) => vec![user],
                        None => Vec::new(),
                    }
                }
            }
            // 2 => filter by status using Okta API filters
            2 => {
                if args.is_empty() {
                    Vec::new()
                } else {
                    let status: String = args.get(0)?;
                    let filter = format!("status eq {}", serde_json::to_string(&status).unwrap());
                    self.okta_port
                        .list_users_with_filter(&filter)
                        .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?
                }
            }
            // 3 => filter by login using Okta API filters
            3 => {
                if args.is_empty() {
                    Vec::new()
                } else {
                    let login: String = args.get(0)?;
                    let filter = format!(
                        "profile.login eq {}",
                        serde_json::to_string(&login).unwrap()
                    );
                    self.okta_port
                        .list_users_with_filter(&filter)
                        .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?
                }
            }
            // Fallback: enumerate all users
            _ => self
                .okta_port
                .list_users()
                .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?,
        };

        self.rows = users;
        self.index = 0;
        Ok(())
    }

    fn next(&mut self) -> Result<(), rusqlite::Error> {
        self.index += 1;
        Ok(())
    }

    fn eof(&self) -> bool {
        self.index >= self.rows.len()
    }

    fn column(&self, ctx: &mut Context, col: c_int) -> Result<(), rusqlite::Error> {
        let item = &self.rows[self.index];
        match col {
            // Core identifiers / status
            0 => ctx.set_result(&item.id)?,
            1 => ctx.set_result(&item.status.to_string())?,
            2 => ctx.set_result(&item.profile.login)?,
            // Full profile as JSON
            3 => {
                let json = item.profile.json.to_string();
                ctx.set_result(&json)?;
            }
            // Timestamps as RFC3339 strings
            4 => {
                let value = item.created.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            5 => {
                let value = item.activated.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            6 => {
                let value = item.status_changed.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            7 => {
                let value = item.last_login.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            8 => {
                let value = item.last_updated.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            9 => {
                let value = item.password_changed.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            // Credentials provider
            10 => {
                let value = item
                    .credentials
                    .as_ref()
                    .map(|c| c.provider.provider_type.clone());
                ctx.set_result(&value)?;
            }
            11 => {
                let value = item.credentials.as_ref().map(|c| c.provider.name.clone());
                ctx.set_result(&value)?;
            }
            12 => {
                let json = item.json.to_string();
                ctx.set_result(&json)?;
            }
            _ => unreachable!(),
        };
        Ok(())
    }

    fn rowid(&self) -> Result<i64, rusqlite::Error> {
        Ok(self.index as i64)
    }
}

#[repr(C)]
pub struct OktaUsersVTab {
    // Base class. Must be first.
    base: sqlite3_vtab,
    okta_port: Arc<dyn OktaPort>,
}

unsafe impl<'vtab> VTab<'vtab> for OktaUsersVTab {
    type Aux = Arc<dyn OktaPort>;
    type Cursor = OktaUsersCursor<'vtab>;

    fn connect(
        _conn: &mut VTabConnection,
        aux: Option<&Self::Aux>,
        _args: &[&[u8]],
    ) -> rusqlite::Result<(String, Self)> {
        // SQLite expects a plain `CREATE TABLE` definition here,
        // not `CREATE VIRTUAL TABLE`.
        let create_sql = "CREATE TABLE x(\
            id TEXT,\
            status TEXT,\
            login TEXT,\
            profile JSON,\
            created TEXT,\
            activated TEXT,\
            status_changed TEXT,\
            last_login TEXT,\
            last_updated TEXT,\
            password_changed TEXT,\
            provider_type TEXT,\
            provider_name TEXT,\
            json JSON\
        )"
        .to_string();

        let okta_port = aux
            .cloned()
            .expect("OktaPort must be provided as module aux data");

        let vtab = OktaUsersVTab {
            base: sqlite3_vtab::default(),
            okta_port,
        };
        Ok((create_sql, vtab))
    }

    fn best_index(&self, info: &mut vtab::IndexInfo) -> rusqlite::Result<()> {
        // Prefer an equality constraint on id, then status, then login.
        let mut id_constraint: Option<usize> = None;
        let mut status_constraint: Option<usize> = None;
        let mut login_constraint: Option<usize> = None;

        for (i, constraint) in info.constraints().enumerate() {
            if !constraint.is_usable() {
                continue;
            }
            if constraint.operator() != IndexConstraintOp::SQLITE_INDEX_CONSTRAINT_EQ {
                continue;
            }

            match constraint.column() {
                // id
                0 => {
                    if id_constraint.is_none() {
                        id_constraint = Some(i);
                    }
                }
                // status
                1 => {
                    if status_constraint.is_none() {
                        status_constraint = Some(i);
                    }
                }
                // login
                2 => {
                    if login_constraint.is_none() {
                        login_constraint = Some(i);
                    }
                }
                _ => {}
            }
        }

        let idx_num = if let Some(i) = id_constraint {
            let mut usage = info.constraint_usage(i);
            usage.set_argv_index(1);
            usage.set_omit(true);

            info.set_idx_flags(IndexFlags::SQLITE_INDEX_SCAN_UNIQUE);
            info.set_estimated_cost(1.0);
            info.set_estimated_rows(1);
            1
        } else if let Some(i) = status_constraint {
            let mut usage = info.constraint_usage(i);
            usage.set_argv_index(1);
            usage.set_omit(true);

            info.set_estimated_cost(10.0);
            info.set_estimated_rows(10_000);
            2
        } else if let Some(i) = login_constraint {
            let mut usage = info.constraint_usage(i);
            usage.set_argv_index(1);
            usage.set_omit(true);

            info.set_estimated_cost(10.0);
            info.set_estimated_rows(10_000);
            3
        } else {
            // No usable constraints: full scan, make it expensive so planner
            // prefers constrained plans when available.
            info.set_estimated_cost(1_000_000.0);
            0
        };

        info.set_idx_num(idx_num);

        Ok(())
    }

    fn open(&'vtab mut self) -> rusqlite::Result<Self::Cursor> {
        Ok(OktaUsersCursor {
            base: sqlite3_vtab_cursor::default(),
            okta_port: self.okta_port.clone(),
            rows: Vec::new(),
            index: 0,
            phantom: PhantomData,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ports::okta::{
        MockOktaPort, OktaUserResource, OktaUserResourceProfile, OktaUserStatus,
    };
    use crate::tables::register_okta_tables;
    use rusqlite::Connection;
    fn create_mock_user(id: &str, login: &str, status: OktaUserStatus) -> OktaUserResource {
        OktaUserResource {
            id: id.to_string(),
            status,
            created: None,
            activated: None,
            status_changed: None,
            last_login: None,
            last_updated: None,
            password_changed: None,
            user_type: None,
            profile: OktaUserResourceProfile {
                first_name: None,
                last_name: None,
                mobile_phone: None,
                second_email: None,
                login: login.to_string(),
                email: None,
                json: serde_json::Value::Null,
            },
            credentials: None,
            links: None,
            json: serde_json::Value::Null,
        }
    }

    #[test]
    fn test_okta_users_vtab_full_scan() {
        let mut mock_port = MockOktaPort::new();
        mock_port.expect_list_users().returning(|| {
            Ok(vec![
                create_mock_user("1", "user1@example.com", OktaUserStatus::Active),
                create_mock_user("2", "user2@example.com", OktaUserStatus::Active),
            ])
        });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare("SELECT id, login, status FROM okta_users")
            .unwrap();
        let rows: Vec<(String, String, String)> = stmt
            .query_map([], |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(rows.len(), 2);
        assert_eq!(
            rows[0],
            (
                "1".to_string(),
                "user1@example.com".to_string(),
                "ACTIVE".to_string()
            )
        );
        assert_eq!(
            rows[1],
            (
                "2".to_string(),
                "user2@example.com".to_string(),
                "ACTIVE".to_string()
            )
        );
    }

    #[test]
    fn test_okta_users_vtab_filter_by_id() {
        let mut mock_port = MockOktaPort::new();
        mock_port
            .expect_get_user()
            .with(mockall::predicate::eq("123"))
            .returning(|_| {
                Ok(Some(create_mock_user(
                    "123",
                    "user123@example.com",
                    OktaUserStatus::Active,
                )))
            });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare("SELECT login FROM okta_users WHERE id = '123'")
            .unwrap();
        let login: String = stmt.query_row([], |row| row.get(0)).unwrap();

        assert_eq!(login, "user123@example.com");
    }

    #[test]
    fn test_okta_users_vtab_filter_by_status() {
        let mut mock_port = MockOktaPort::new();
        mock_port
            .expect_list_users_with_filter()
            .with(mockall::predicate::eq("status eq \"SUSPENDED\""))
            .returning(|_| {
                Ok(vec![create_mock_user(
                    "2",
                    "user2@example.com",
                    OktaUserStatus::Suspended,
                )])
            });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare("SELECT id FROM okta_users WHERE status = 'SUSPENDED'")
            .unwrap();
        let ids: Vec<String> = stmt
            .query_map([], |row| row.get(0))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(ids, vec!["2".to_string()]);
    }
}
