use std::ffi::c_int;
use std::marker::PhantomData;
use std::sync::Arc;

use crate::ports::okta::{OktaPolicyResource, OktaPolicyRuleResource, OktaPort};
use rusqlite::vtab;
use rusqlite::vtab::{
    Context, IndexConstraintOp, IndexFlags, VTab, VTabConnection, VTabCursor, sqlite3_vtab,
    sqlite3_vtab_cursor,
};

#[derive(Debug)]
struct PolicyRuleRow {
    policy_id: String,
    rule: OktaPolicyRuleResource,
}

#[repr(C)]
pub struct OktaPolicyRulesCursor<'vtab> {
    // Base class. Must be first.
    base: sqlite3_vtab_cursor,
    okta_port: Arc<dyn OktaPort>,
    rows: Vec<PolicyRuleRow>,
    index: usize,
    phantom: PhantomData<&'vtab OktaPolicyRulesVTab>,
}

unsafe impl VTabCursor for OktaPolicyRulesCursor<'_> {
    fn filter(
        &mut self,
        idx_num: c_int,
        _idx_str: Option<&str>,
        args: &vtab::Filters<'_>,
    ) -> Result<(), rusqlite::Error> {
        let rows = match idx_num {
            // policy_id equality to mirror /policies/{id}/rules.
            1 => {
                if args.is_empty() {
                    return Err(rusqlite::Error::ModuleError(
                        "full scan disabled for table okta_policy_rules (GET /policies/{id}/rules); filter by policy_id".to_string(),
                    ));
                }
                let policy_id: String = args.get(0)?;
                self.fetch_for_policy(&policy_id)?
            }
            // policy_id + rule id equality to mirror /policies/{id}/rules/{ruleId}
            2 => {
                if args.len() < 2 {
                    return Err(rusqlite::Error::ModuleError(
                        "full scan disabled for table okta_policy_rules (GET /policies/{id}/rules); filter by policy_id and id".to_string(),
                    ));
                }
                let policy_id: String = args.get(0)?;
                let rule_id: String = args.get(1)?;
                self.fetch_for_policy_rule(&policy_id, &rule_id)?
            }
            _ => {
                return Err(rusqlite::Error::ModuleError(
                    "full scan disabled for table okta_policy_rules (GET /policies/{id}/rules); filter by policy_id".to_string(),
                ));
            }
        };

        self.rows = rows;
        self.index = 0;
        Ok(())
    }

    fn next(&mut self) -> Result<(), rusqlite::Error> {
        self.index += 1;
        Ok(())
    }

    fn eof(&self) -> bool {
        self.index >= self.rows.len()
    }

    fn column(&self, ctx: &mut Context, col: c_int) -> Result<(), rusqlite::Error> {
        let item = &self.rows[self.index];
        match col {
            0 => ctx.set_result(&item.policy_id)?,
            1 => ctx.set_result(&item.rule.id)?,
            2 => ctx.set_result(&item.rule.name)?,
            3 => ctx.set_result(&item.rule.rule_type)?,
            4 => ctx.set_result(&item.rule.status)?,
            5 => ctx.set_result(&item.rule.priority)?,
            6 => ctx.set_result(&item.rule.system)?,
            7 => {
                let value = item.rule.created.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            8 => {
                let value = item.rule.last_updated.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            9 => {
                let val = item.rule.conditions.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            10 => {
                let val = item.rule.actions.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            11 => {
                let val = item.rule.links.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            12 => {
                let json = item.rule.json.to_string();
                ctx.set_result(&json)?;
            }
            _ => unreachable!(),
        };
        Ok(())
    }

    fn rowid(&self) -> Result<i64, rusqlite::Error> {
        Ok(self.index as i64)
    }
}

impl OktaPolicyRulesCursor<'_> {
    fn fetch_for_policy(&self, policy_id: &str) -> Result<Vec<PolicyRuleRow>, rusqlite::Error> {
        let maybe_policy = self
            .okta_port
            .get_policy(policy_id)
            .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?;

        let Some(policy) = maybe_policy else {
            return Ok(Vec::new());
        };

        self.expand_policy(policy)
    }

    fn expand_policy(
        &self,
        policy: OktaPolicyResource,
    ) -> Result<Vec<PolicyRuleRow>, rusqlite::Error> {
        let policy_id = policy.id.clone();

        let rules = self
            .okta_port
            .list_policy_rules(&policy_id)
            .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?;

        Ok(rules
            .into_iter()
            .map(|rule| PolicyRuleRow {
                policy_id: policy_id.clone(),
                rule,
            })
            .collect())
    }

    fn fetch_for_policy_rule(
        &self,
        policy_id: &str,
        rule_id: &str,
    ) -> Result<Vec<PolicyRuleRow>, rusqlite::Error> {
        let maybe_rule = self
            .okta_port
            .get_policy_rule(policy_id, rule_id)
            .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?;

        Ok(maybe_rule
            .map(|rule| PolicyRuleRow {
                policy_id: policy_id.to_string(),
                rule,
            })
            .into_iter()
            .collect())
    }
}

#[repr(C)]
pub struct OktaPolicyRulesVTab {
    // Base class. Must be first.
    base: sqlite3_vtab,
    okta_port: Arc<dyn OktaPort>,
}

unsafe impl<'vtab> VTab<'vtab> for OktaPolicyRulesVTab {
    type Aux = Arc<dyn OktaPort>;
    type Cursor = OktaPolicyRulesCursor<'vtab>;

    fn connect(
        _conn: &mut VTabConnection,
        aux: Option<&Self::Aux>,
        _args: &[&[u8]],
    ) -> rusqlite::Result<(String, Self)> {
        // SQLite expects a plain `CREATE TABLE` definition here,
        // not `CREATE VIRTUAL TABLE`.
        let create_sql = "CREATE TABLE x(\
            policy_id TEXT HIDDEN,\
            id TEXT,\
            name TEXT,\
            type TEXT,\
            status TEXT,\
            priority INTEGER,\
            system BOOLEAN,\
            created TEXT,\
            last_updated TEXT,\
            conditions JSON,\
            actions JSON,\
            links JSON,\
            json JSON\
        )"
        .to_string();

        let okta_port = aux
            .cloned()
            .expect("OktaPort must be provided as module aux data");

        let vtab = OktaPolicyRulesVTab {
            base: sqlite3_vtab::default(),
            okta_port,
        };
        Ok((create_sql, vtab))
    }

    fn best_index(&self, info: &mut vtab::IndexInfo) -> rusqlite::Result<()> {
        let mut policy_id_constraint: Option<usize> = None;
        let mut rule_id_constraint: Option<usize> = None;

        for (i, constraint) in info.constraints().enumerate() {
            if !constraint.is_usable() {
                continue;
            }
            if constraint.operator() != IndexConstraintOp::SQLITE_INDEX_CONSTRAINT_EQ {
                continue;
            }

            match constraint.column() {
                0 => {
                    if policy_id_constraint.is_none() {
                        policy_id_constraint = Some(i);
                    }
                }
                1 => {
                    if rule_id_constraint.is_none() {
                        rule_id_constraint = Some(i);
                    }
                }
                _ => {}
            }
        }

        if let Some(policy_id_idx) = policy_id_constraint {
            if let Some(rule_id_idx) = rule_id_constraint {
                let mut usage = info.constraint_usage(policy_id_idx);
                usage.set_argv_index(1);
                usage.set_omit(true);

                let mut usage = info.constraint_usage(rule_id_idx);
                usage.set_argv_index(2);
                usage.set_omit(true);

                info.set_idx_num(2);
                info.set_idx_flags(IndexFlags::SQLITE_INDEX_SCAN_UNIQUE);
                info.set_estimated_cost(1.0);
                info.set_estimated_rows(1);
            } else {
                let mut usage = info.constraint_usage(policy_id_idx);
                usage.set_argv_index(1);
                usage.set_omit(true);

                info.set_idx_num(1);
                info.set_idx_flags(IndexFlags::SQLITE_INDEX_SCAN_UNIQUE);
                info.set_estimated_cost(1.0);
                info.set_estimated_rows(100);
            }
        } else {
            info.set_idx_num(0);
            info.set_estimated_cost(100_000_000.0);
        }

        Ok(())
    }

    fn open(&'vtab mut self) -> rusqlite::Result<Self::Cursor> {
        Ok(OktaPolicyRulesCursor {
            base: sqlite3_vtab_cursor::default(),
            okta_port: self.okta_port.clone(),
            rows: Vec::new(),
            index: 0,
            phantom: PhantomData,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ports::okta::{MockOktaPort, OktaPolicyResource, OktaPolicyRuleResource};
    use crate::tables::register_okta_tables;
    use rusqlite::Connection;
    fn create_mock_policy(id: &str, name: &str) -> OktaPolicyResource {
        OktaPolicyResource {
            id: id.to_string(),
            name: name.to_string(),
            description: None,
            policy_type: "OKTA_SIGN_ON".to_string(),
            status: "ACTIVE".to_string(),
            priority: Some(1),
            system: Some(false),
            created: None,
            last_updated: None,
            conditions: None,
            settings: None,
            links: None,
            json: serde_json::Value::Null,
        }
    }

    fn create_mock_rule(id: &str, name: &str) -> OktaPolicyRuleResource {
        OktaPolicyRuleResource {
            id: id.to_string(),
            name: name.to_string(),
            rule_type: "SIGN_ON".to_string(),
            status: "ACTIVE".to_string(),
            priority: Some(1),
            system: Some(false),
            created: None,
            last_updated: None,
            conditions: None,
            actions: None,
            links: None,
            json: serde_json::Value::Null,
        }
    }

    #[test]
    fn test_okta_policy_rules_filter_by_policy_id() {
        let mut mock_port = MockOktaPort::new();

        mock_port
            .expect_get_policy()
            .with(mockall::predicate::eq("policy123"))
            .returning(|_| Ok(Some(create_mock_policy("policy123", "Target Policy"))));

        mock_port
            .expect_list_policy_rules()
            .with(mockall::predicate::eq("policy123"))
            .returning(|_| {
                let mut rule1 = create_mock_rule("rule1", "Rule 1");
                rule1.priority = Some(1);

                let mut rule2 = create_mock_rule("rule2", "Rule 2");
                rule2.status = "INACTIVE".to_string();
                rule2.priority = Some(2);

                Ok(vec![rule1, rule2])
            });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare(
                "SELECT id, name, status FROM okta_policy_rules WHERE policy_id = 'policy123' ORDER BY id",
            )
            .unwrap();

        let rows: Vec<(String, String, String)> = stmt
            .query_map([], |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(rows.len(), 2);
        assert_eq!(
            rows[0],
            (
                "rule1".to_string(),
                "Rule 1".to_string(),
                "ACTIVE".to_string()
            )
        );
        assert_eq!(
            rows[1],
            (
                "rule2".to_string(),
                "Rule 2".to_string(),
                "INACTIVE".to_string()
            )
        );
    }

    #[test]
    fn test_okta_policy_rules_filter_by_policy_id_and_id() {
        let mut mock_port = MockOktaPort::new();

        mock_port
            .expect_get_policy_rule()
            .with(
                mockall::predicate::eq("policy123"),
                mockall::predicate::eq("rule2"),
            )
            .returning(|_, _| Ok(Some(create_mock_rule("rule2", "Rule 2"))));

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare(
                "SELECT id, name, status FROM okta_policy_rules WHERE policy_id = 'policy123' AND id = 'rule2'",
            )
            .unwrap();

        let rows: Vec<(String, String, String)> = stmt
            .query_map([], |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(rows.len(), 1);
        assert_eq!(
            rows[0],
            (
                "rule2".to_string(),
                "Rule 2".to_string(),
                "ACTIVE".to_string()
            )
        );
    }

    #[test]
    fn test_okta_policy_rules_full_scan_fails() {
        let mock_port = MockOktaPort::new();
        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db.prepare("SELECT * FROM okta_policy_rules").unwrap();
        let mut rows = stmt.query([]).unwrap();
        let result = rows.next();

        assert!(result.is_err());
        let err = result.err().unwrap().to_string();
        assert!(err.contains("full scan disabled"));
    }
}
