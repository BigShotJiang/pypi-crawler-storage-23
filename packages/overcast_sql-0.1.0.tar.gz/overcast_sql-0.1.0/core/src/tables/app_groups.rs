use std::ffi::c_int;
use std::marker::PhantomData;
use std::sync::Arc;

use crate::ports::okta::{OktaAppGroupResource, OktaPort};
use rusqlite::vtab;
use rusqlite::vtab::{
    Context, IndexConstraintOp, IndexFlags, VTab, VTabConnection, VTabCursor, sqlite3_vtab,
    sqlite3_vtab_cursor,
};

#[derive(Debug)]
struct AppGroupRow {
    app_id: String,
    group: OktaAppGroupResource,
}

#[repr(C)]
pub struct OktaAppGroupsCursor<'vtab> {
    // Base class. Must be first.
    base: sqlite3_vtab_cursor,
    okta_port: Arc<dyn OktaPort>,
    rows: Vec<AppGroupRow>,
    index: usize,
    phantom: PhantomData<&'vtab OktaAppGroupsVTab>,
}

unsafe impl VTabCursor for OktaAppGroupsCursor<'_> {
    fn filter(
        &mut self,
        idx_num: c_int,
        _idx_str: Option<&str>,
        args: &vtab::Filters<'_>,
    ) -> Result<(), rusqlite::Error> {
        // Only support app_id equality to mirror /apps/{id}/groups.
        if idx_num != 1 || args.is_empty() {
            return Err(rusqlite::Error::ModuleError(
                "full scan disabled for table okta_app_groups (GET /apps/{id}/groups); filter by app_id".to_string(),
            ));
        }

        let app_id: String = args.get(0)?;
        let groups = self
            .okta_port
            .list_app_groups(&app_id)
            .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?;

        self.rows = groups
            .into_iter()
            .map(|group| AppGroupRow {
                app_id: app_id.clone(),
                group,
            })
            .collect();
        self.index = 0;
        Ok(())
    }

    fn next(&mut self) -> Result<(), rusqlite::Error> {
        self.index += 1;
        Ok(())
    }

    fn eof(&self) -> bool {
        self.index >= self.rows.len()
    }

    fn column(&self, ctx: &mut Context, col: c_int) -> Result<(), rusqlite::Error> {
        let item = &self.rows[self.index];
        match col {
            0 => ctx.set_result(&item.app_id)?,
            1 => ctx.set_result(&item.group.id)?,
            2 => ctx.set_result(&item.group.priority)?,
            3 => {
                let val = item.group.profile.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            4 => {
                let val = item.group.links.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            5 => {
                let json = item.group.json.to_string();
                ctx.set_result(&json)?;
            }
            _ => unreachable!(),
        };
        Ok(())
    }

    fn rowid(&self) -> Result<i64, rusqlite::Error> {
        Ok(self.index as i64)
    }
}

#[repr(C)]
pub struct OktaAppGroupsVTab {
    // Base class. Must be first.
    base: sqlite3_vtab,
    okta_port: Arc<dyn OktaPort>,
}

unsafe impl<'vtab> VTab<'vtab> for OktaAppGroupsVTab {
    type Aux = Arc<dyn OktaPort>;
    type Cursor = OktaAppGroupsCursor<'vtab>;

    fn connect(
        _conn: &mut VTabConnection,
        aux: Option<&Self::Aux>,
        _args: &[&[u8]],
    ) -> rusqlite::Result<(String, Self)> {
        // SQLite expects a plain `CREATE TABLE` definition here,
        // not `CREATE VIRTUAL TABLE`.
        let create_sql = "CREATE TABLE x(\
            app_id TEXT,\
            id TEXT,\
            priority INTEGER,\
            profile JSON,\
            links JSON,\
            json JSON\
        )"
        .to_string();

        let okta_port = aux
            .cloned()
            .expect("OktaPort must be provided as module aux data");

        let vtab = OktaAppGroupsVTab {
            base: sqlite3_vtab::default(),
            okta_port,
        };
        Ok((create_sql, vtab))
    }

    fn best_index(&self, info: &mut vtab::IndexInfo) -> rusqlite::Result<()> {
        let mut app_id_constraint: Option<usize> = None;

        for (i, constraint) in info.constraints().enumerate() {
            if !constraint.is_usable() {
                continue;
            }
            if constraint.operator() != IndexConstraintOp::SQLITE_INDEX_CONSTRAINT_EQ {
                continue;
            }

            if constraint.column() == 0 && app_id_constraint.is_none() {
                app_id_constraint = Some(i);
            }
        }

        if let Some(i) = app_id_constraint {
            let mut usage = info.constraint_usage(i);
            usage.set_argv_index(1);
            usage.set_omit(true);

            info.set_idx_num(1);
            info.set_idx_flags(IndexFlags::SQLITE_INDEX_SCAN_UNIQUE);
            info.set_estimated_cost(1.0);
            info.set_estimated_rows(100);
        } else {
            info.set_idx_num(0);
            info.set_estimated_cost(100_000_000.0);
        }

        Ok(())
    }

    fn open(&'vtab mut self) -> rusqlite::Result<Self::Cursor> {
        Ok(OktaAppGroupsCursor {
            base: sqlite3_vtab_cursor::default(),
            okta_port: self.okta_port.clone(),
            rows: Vec::new(),
            index: 0,
            phantom: PhantomData,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ports::okta::{MockOktaPort, OktaAppGroupResource};
    use crate::tables::register_okta_tables;
    use rusqlite::Connection;
    fn create_mock_app_group(id: &str, priority: i64) -> OktaAppGroupResource {
        OktaAppGroupResource {
            id: id.to_string(),
            priority: Some(priority),
            profile: Some(serde_json::json!({"name": format!("Group {}", id)})),
            links: None,
            json: serde_json::Value::Null,
        }
    }

    #[test]
    fn test_okta_app_groups_filter_by_app_id() {
        let mut mock_port = MockOktaPort::new();

        mock_port
            .expect_list_app_groups()
            .with(mockall::predicate::eq("app123"))
            .returning(|_| {
                Ok(vec![
                    create_mock_app_group("group1", 1),
                    create_mock_app_group("group2", 2),
                ])
            });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare(
                "SELECT app_id, id, priority FROM okta_app_groups WHERE app_id = 'app123' ORDER BY id",
            )
            .unwrap();

        let rows: Vec<(String, String, i64)> = stmt
            .query_map([], |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(rows.len(), 2);
        assert_eq!(rows[0], ("app123".to_string(), "group1".to_string(), 1));
        assert_eq!(rows[1], ("app123".to_string(), "group2".to_string(), 2));
    }

    #[test]
    fn test_okta_app_groups_full_scan_fails() {
        let mock_port = MockOktaPort::new();
        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db.prepare("SELECT * FROM okta_app_groups").unwrap();
        let mut rows = stmt.query([]).unwrap();
        let result = rows.next();

        assert!(result.is_err());
        let err = result.err().unwrap().to_string();
        assert!(err.contains("full scan disabled"));
    }
}
