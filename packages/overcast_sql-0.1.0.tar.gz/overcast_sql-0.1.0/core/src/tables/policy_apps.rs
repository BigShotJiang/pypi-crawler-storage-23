use std::ffi::c_int;
use std::marker::PhantomData;
use std::sync::Arc;

use crate::ports::okta::{OktaApplicationResource, OktaPort};
use crate::tables::applications::extract_policy_id_from_links;
use rusqlite::vtab;
use rusqlite::vtab::{
    Context, IndexConstraintOp, IndexFlags, VTab, VTabConnection, VTabCursor, sqlite3_vtab,
    sqlite3_vtab_cursor,
};

#[derive(Debug)]
struct PolicyAppRow {
    policy_id: String,
    app: OktaApplicationResource,
}

#[repr(C)]
pub struct OktaPolicyAppsCursor<'vtab> {
    // Base class. Must be first.
    base: sqlite3_vtab_cursor,
    okta_port: Arc<dyn OktaPort>,
    rows: Vec<PolicyAppRow>,
    index: usize,
    phantom: PhantomData<&'vtab OktaPolicyAppsVTab>,
}

unsafe impl VTabCursor for OktaPolicyAppsCursor<'_> {
    fn filter(
        &mut self,
        idx_num: c_int,
        _idx_str: Option<&str>,
        args: &vtab::Filters<'_>,
    ) -> Result<(), rusqlite::Error> {
        // Only support policy_id equality to mirror /policies/{id}/apps.
        if idx_num != 1 || args.is_empty() {
            return Err(rusqlite::Error::ModuleError(
                "full scan disabled for table okta_policy_apps (GET /policies/{id}/apps); filter by policy_id".to_string(),
            ));
        }

        let policy_id: String = args.get(0)?;
        let apps = self
            .okta_port
            .list_applications()
            .map_err(|e| rusqlite::Error::ModuleError(e.to_string()))?;

        self.rows = apps
            .into_iter()
            .filter_map(|app| {
                let app_policy_id = extract_policy_id_from_links(&app.links)?;
                if app_policy_id == policy_id {
                    Some(PolicyAppRow {
                        policy_id: app_policy_id,
                        app,
                    })
                } else {
                    None
                }
            })
            .collect();
        self.index = 0;
        Ok(())
    }

    fn next(&mut self) -> Result<(), rusqlite::Error> {
        self.index += 1;
        Ok(())
    }

    fn eof(&self) -> bool {
        self.index >= self.rows.len()
    }

    fn column(&self, ctx: &mut Context, col: c_int) -> Result<(), rusqlite::Error> {
        let item = &self.rows[self.index];
        match col {
            0 => ctx.set_result(&item.policy_id)?,
            1 => ctx.set_result(&item.app.id)?,
            2 => ctx.set_result(&item.app.name)?,
            3 => ctx.set_result(&item.app.label)?,
            4 => {
                let val = item.app.sign_on_mode.clone();
                ctx.set_result(&val)?;
            }
            5 => ctx.set_result(&item.app.status.to_string())?,
            6 => {
                let value = item.app.created.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            7 => {
                let value = item.app.last_updated.as_ref().map(|d| d.to_rfc3339());
                ctx.set_result(&value)?;
            }
            8 => {
                let val = item.app.credentials.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            9 => {
                let val = item.app.settings.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            10 => {
                let val = item.app.links.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            11 => {
                let val = item.app.accessibility.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            12 => {
                let val = item.app.visibility.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            13 => {
                let val = item.app.features.as_ref().map(|v| v.to_string());
                ctx.set_result(&val)?;
            }
            14 => {
                let json = item.app.json.to_string();
                ctx.set_result(&json)?;
            }
            _ => unreachable!(),
        };
        Ok(())
    }

    fn rowid(&self) -> Result<i64, rusqlite::Error> {
        Ok(self.index as i64)
    }
}

#[repr(C)]
pub struct OktaPolicyAppsVTab {
    // Base class. Must be first.
    base: sqlite3_vtab,
    okta_port: Arc<dyn OktaPort>,
}

unsafe impl<'vtab> VTab<'vtab> for OktaPolicyAppsVTab {
    type Aux = Arc<dyn OktaPort>;
    type Cursor = OktaPolicyAppsCursor<'vtab>;

    fn connect(
        _conn: &mut VTabConnection,
        aux: Option<&Self::Aux>,
        _args: &[&[u8]],
    ) -> rusqlite::Result<(String, Self)> {
        // SQLite expects a plain `CREATE TABLE` definition here,
        // not `CREATE VIRTUAL TABLE`.
        let create_sql = "CREATE TABLE x(\
            policy_id TEXT HIDDEN,\
            id TEXT,\
            name TEXT,\
            label TEXT,\
            sign_on_mode TEXT,\
            status TEXT,\
            created TEXT,\
            last_updated TEXT,\
            credentials JSON,\
            settings JSON,\
            links JSON,\
            accessibility JSON,\
            visibility JSON,\
            features JSON,\
            json JSON\
        )"
        .to_string();

        let okta_port = aux
            .cloned()
            .expect("OktaPort must be provided as module aux data");

        let vtab = OktaPolicyAppsVTab {
            base: sqlite3_vtab::default(),
            okta_port,
        };
        Ok((create_sql, vtab))
    }

    fn best_index(&self, info: &mut vtab::IndexInfo) -> rusqlite::Result<()> {
        let mut policy_id_constraint: Option<usize> = None;

        for (i, constraint) in info.constraints().enumerate() {
            if !constraint.is_usable() {
                continue;
            }
            if constraint.operator() != IndexConstraintOp::SQLITE_INDEX_CONSTRAINT_EQ {
                continue;
            }

            if constraint.column() == 0 && policy_id_constraint.is_none() {
                policy_id_constraint = Some(i);
            }
        }

        if let Some(i) = policy_id_constraint {
            let mut usage = info.constraint_usage(i);
            usage.set_argv_index(1);
            usage.set_omit(true);

            info.set_idx_num(1);
            info.set_idx_flags(IndexFlags::SQLITE_INDEX_SCAN_UNIQUE);
            info.set_estimated_cost(1.0);
            info.set_estimated_rows(100);
        } else {
            info.set_idx_num(0);
            info.set_estimated_cost(100_000_000.0);
        }

        Ok(())
    }

    fn open(&'vtab mut self) -> rusqlite::Result<Self::Cursor> {
        Ok(OktaPolicyAppsCursor {
            base: sqlite3_vtab_cursor::default(),
            okta_port: self.okta_port.clone(),
            rows: Vec::new(),
            index: 0,
            phantom: PhantomData,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ports::okta::{MockOktaPort, OktaApplicationStatus};
    use crate::tables::register_okta_tables;
    use rusqlite::Connection;
    fn create_mock_app(id: &str, policy_id: Option<&str>) -> OktaApplicationResource {
        let links = policy_id.map(|policy_id| {
            serde_json::json!({
                "accessPolicy": {
                    "href": format!("https://example.okta.com/api/v1/policies/{}", policy_id)
                }
            })
        });

        OktaApplicationResource {
            id: id.to_string(),
            name: format!("app_{}", id),
            label: format!("App {}", id),
            sign_on_mode: Some("UNKNOWN".to_string()),
            status: OktaApplicationStatus::Active,
            created: None,
            last_updated: None,
            credentials: None,
            settings: None,
            links,
            accessibility: None,
            visibility: None,
            features: None,
            json: serde_json::Value::Null,
        }
    }

    #[test]
    fn test_okta_policy_apps_filter_by_policy_id() {
        let mut mock_port = MockOktaPort::new();

        mock_port.expect_list_applications().returning(|| {
            Ok(vec![
                create_mock_app("app1", Some("policy123")),
                create_mock_app("app2", Some("policy456")),
                create_mock_app("app3", None),
            ])
        });

        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db
            .prepare(
                "SELECT policy_id, id, label FROM okta_policy_apps WHERE policy_id = 'policy123' ORDER BY id",
            )
            .unwrap();

        let rows: Vec<(String, String, String)> = stmt
            .query_map([], |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)))
            .unwrap()
            .map(|r| r.unwrap())
            .collect();

        assert_eq!(rows.len(), 1);
        assert_eq!(
            rows[0],
            (
                "policy123".to_string(),
                "app1".to_string(),
                "App app1".to_string()
            )
        );
    }

    #[test]
    fn test_okta_policy_apps_full_scan_fails() {
        let mock_port = MockOktaPort::new();
        let db = Connection::open_in_memory().unwrap();
        register_okta_tables(&db, Arc::new(mock_port)).unwrap();

        let mut stmt = db.prepare("SELECT * FROM okta_policy_apps").unwrap();
        let mut rows = stmt.query([]).unwrap();
        let result = rows.next();

        assert!(result.is_err());
        let err = result.err().unwrap().to_string();
        assert!(err.contains("full scan disabled"));
    }
}
