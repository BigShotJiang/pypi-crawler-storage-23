use crate::tests::integration::common::{first_text, setup_real_db};

#[test]
fn policy_rules_basic_query() {
    let db = setup_real_db().unwrap();
    let Some(policy_id) = first_text(&db, "SELECT id FROM okta_policies LIMIT 1") else {
        return;
    };

    let mut stmt = db
        .prepare("SELECT id, name FROM okta_policy_rules WHERE policy_id = ?1 LIMIT 1")
        .unwrap();

    let mut rows = stmt.query([policy_id]).unwrap();
    if let Some(row) = rows.next().unwrap() {
        let rule_id: String = row.get(0).unwrap();
        let name: String = row.get(1).unwrap();
        assert!(!rule_id.is_empty());
        assert!(!name.is_empty());
    }
}
