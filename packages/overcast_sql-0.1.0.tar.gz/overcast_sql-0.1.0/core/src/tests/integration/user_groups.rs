use crate::tests::integration::common::{first_text, setup_real_db};

#[test]
fn user_groups_basic_query() {
    let db = setup_real_db().unwrap();
    let Some(user_id) = first_text(&db, "SELECT id FROM okta_users LIMIT 1") else {
        return;
    };

    let mut stmt = db
        .prepare("SELECT group_id, group_name FROM okta_user_groups WHERE user_id = ?1 LIMIT 1")
        .unwrap();

    let mut rows = stmt.query([user_id]).unwrap();
    if let Some(row) = rows.next().unwrap() {
        let group_id: String = row.get(0).unwrap();
        let group_name: String = row.get(1).unwrap();
        assert!(!group_id.is_empty());
        assert!(!group_name.is_empty());
    }
}
