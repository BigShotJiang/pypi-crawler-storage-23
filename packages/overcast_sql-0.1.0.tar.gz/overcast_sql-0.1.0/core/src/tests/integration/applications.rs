#[cfg(test)]
mod tests {
    use crate::tests::integration::common::setup_real_db;

    #[test]
    fn applications_basic_query() {
        let db = setup_real_db().unwrap();
        let mut stmt = db
            .prepare("SELECT id, policy_id FROM okta_applications LIMIT 1")
            .unwrap();

        let mut rows = stmt.query([]).unwrap();
        if let Some(row) = rows.next().unwrap() {
            let id: String = row.get(0).unwrap();
            let policy_id: Option<String> = row.get(1).unwrap();
            assert!(!id.is_empty());
            if let Some(policy_id) = policy_id {
                assert!(!policy_id.is_empty());
            }
        }
    }
}
