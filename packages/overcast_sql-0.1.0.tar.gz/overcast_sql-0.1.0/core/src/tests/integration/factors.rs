#[cfg(test)]
mod tests {
    use crate::tests::integration::common::setup_real_db;

    #[test]
    fn factors_basic_query() {
        let db = setup_real_db().unwrap();
        let mut stmt = db
            .prepare("SELECT user_id, factor_id FROM okta_factors LIMIT 1")
            .unwrap();

        let mut rows = stmt.query([]).unwrap();
        if let Some(row) = rows.next().unwrap() {
            let user_id: String = row.get(0).unwrap();
            let factor_id: String = row.get(1).unwrap();
            assert!(!user_id.is_empty());
            assert!(!factor_id.is_empty());
        }
    }
}
