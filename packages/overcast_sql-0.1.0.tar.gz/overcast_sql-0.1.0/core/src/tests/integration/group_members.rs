use crate::tests::integration::common::{first_text, setup_real_db};

#[test]
fn group_members_basic_query() {
    let db = setup_real_db().unwrap();
    let Some(group_id) = first_text(&db, "SELECT id FROM okta_groups LIMIT 1") else {
        return;
    };

    let mut stmt = db
        .prepare("SELECT user_id, user_login FROM okta_group_members WHERE group_id = ?1 LIMIT 1")
        .unwrap();

    let mut rows = stmt.query([group_id]).unwrap();
    if let Some(row) = rows.next().unwrap() {
        let user_id: String = row.get(0).unwrap();
        let user_login: String = row.get(1).unwrap();
        assert!(!user_id.is_empty());
        assert!(!user_login.is_empty());
    }
}
