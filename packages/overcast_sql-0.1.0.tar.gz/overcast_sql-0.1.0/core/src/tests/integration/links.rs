use crate::tests::integration::common::setup_real_db;

#[test]
fn links_basic_query() {
    let db = setup_real_db().unwrap();
    let mut stmt = db
        .prepare("SELECT user_id, rel, href FROM okta_links LIMIT 1")
        .unwrap();

    let mut rows = stmt.query([]).unwrap();
    if let Some(row) = rows.next().unwrap() {
        let user_id: String = row.get(0).unwrap();
        let rel: String = row.get(1).unwrap();
        let href: String = row.get(2).unwrap();
        assert!(!user_id.is_empty());
        assert!(!rel.is_empty());
        assert!(!href.is_empty());
    }
}
