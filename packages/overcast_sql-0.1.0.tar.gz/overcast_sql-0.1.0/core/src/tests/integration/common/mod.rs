use std::sync::Arc;

use rusqlite::Connection;

use crate::okta_adapter::OktaAdapter;
use crate::okta_adapter::config::OktaConfig;
use crate::ports::okta::OktaPort;
use crate::tables::register_okta_tables;

#[cfg(test)]
pub fn setup_real_db() -> Option<Connection> {
    let okta_config = match OktaConfig::from_env() {
        Ok(config) => config,
        Err(err) => {
            eprintln!("skipping Okta integration tests: {}", err);
            return None;
        }
    };
    if okta_config.base_url.trim().is_empty() || okta_config.ssws_token.trim().is_empty() {
        eprintln!("skipping Okta integration tests: empty OKTA_BASE_URL or OKTA_SSWS_TOKEN");
        return None;
    }
    let okta_adapter = OktaAdapter::new(okta_config);
    let okta_port: Arc<dyn OktaPort> = Arc::new(okta_adapter);

    let db = Connection::open_in_memory().unwrap();
    register_okta_tables(&db, okta_port).unwrap();
    Some(db)
}

#[cfg(test)]
pub fn first_text(conn: &Connection, sql: &str) -> Option<String> {
    let mut stmt = conn.prepare(sql).ok()?;
    let mut rows = stmt.query([]).ok()?;
    let row = rows.next().ok()??;
    row.get::<_, String>(0).ok()
}
