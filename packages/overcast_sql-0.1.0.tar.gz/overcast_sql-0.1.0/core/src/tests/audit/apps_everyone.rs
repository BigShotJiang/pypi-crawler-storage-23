use crate::ports::okta::{
    MockOktaPort, OktaAppGroupResource, OktaApplicationResource, OktaApplicationStatus,
    OktaGroupProfile, OktaGroupResource,
};
use crate::tables::register_okta_tables;
use rusqlite::Connection;
use serde_json::json;
use std::sync::Arc;

fn create_mock_app(id: &str) -> OktaApplicationResource {
    OktaApplicationResource {
        id: id.to_string(),
        name: "".to_string(),
        label: "".to_string(),
        sign_on_mode: None,
        status: OktaApplicationStatus::Active,
        created: None,
        last_updated: None,
        credentials: None,
        settings: None,
        links: None,
        accessibility: None,
        visibility: None,
        features: None,
        json: json!(null),
    }
}

fn create_mock_group_with_name(id: &str, name: &str, group_type: &str) -> OktaGroupResource {
    OktaGroupResource {
        id: id.to_string(),
        created: None,
        last_updated: None,
        last_membership_updated: None,
        group_type: Some(group_type.to_string()),
        object_class: None,
        profile: OktaGroupProfile {
            name: name.to_string(),
            description: None,
            json: json!(null),
        },
        json: json!(null),
    }
}

fn create_mock_app_group(group_id: &str) -> OktaAppGroupResource {
    OktaAppGroupResource {
        id: group_id.to_string(),
        priority: None,
        profile: None,
        links: None,
        json: json!(null),
    }
}

#[test]
fn test_apps_everyone() -> rusqlite::Result<()> {
    let mut mock_port = MockOktaPort::new();

    mock_port.expect_list_applications().returning(|| {
        Ok(vec![
            create_mock_app("app1"),
            create_mock_app("app2"),
            create_mock_app("app3"),
        ])
    });

    mock_port.expect_list_groups().returning(|| {
        Ok(vec![
            create_mock_group_with_name("group_everyone", "Everyone", "BUILT_IN"),
            create_mock_group_with_name("group_admins", "Admins", "OKTA_GROUP"),
        ])
    });
    mock_port
        .expect_get_group()
        .with(mockall::predicate::eq("group_everyone"))
        .returning(|_| {
            Ok(Some(create_mock_group_with_name(
                "group_everyone",
                "Everyone",
                "BUILT_IN",
            )))
        });
    mock_port
        .expect_get_group()
        .with(mockall::predicate::eq("group_admins"))
        .returning(|_| {
            Ok(Some(create_mock_group_with_name(
                "group_admins",
                "Admins",
                "OKTA_GROUP",
            )))
        });

    mock_port
        .expect_list_app_groups()
        .with(mockall::predicate::eq("app1"))
        .returning(|_| Ok(vec![create_mock_app_group("group_everyone")]));

    mock_port
        .expect_list_app_groups()
        .with(mockall::predicate::eq("app2"))
        .returning(|_| Ok(vec![create_mock_app_group("group_admins")]));

    mock_port
        .expect_list_app_groups()
        .with(mockall::predicate::eq("app3"))
        .returning(|_| {
            Ok(vec![
                create_mock_app_group("group_admins"),
                create_mock_app_group("group_everyone"),
            ])
        });

    let db = Connection::open_in_memory()?;
    register_okta_tables(&db, Arc::new(mock_port))?;

    let rows: Vec<String> = db
        .prepare(
            "SELECT application.id AS app_id \
             FROM okta_applications application \
             JOIN okta_app_groups app_group ON app_group.app_id = application.id \
             JOIN okta_groups everyone_group ON everyone_group.id = app_group.id \
             WHERE everyone_group.name = 'Everyone' AND everyone_group.group_type = 'BUILT_IN'",
        )?
        .query_map([], |row| row.get("app_id"))?
        .collect::<Result<Vec<String>, _>>()?;

    assert_eq!(rows, vec!["app1".to_string(), "app3".to_string()]);
    Ok(())
}
