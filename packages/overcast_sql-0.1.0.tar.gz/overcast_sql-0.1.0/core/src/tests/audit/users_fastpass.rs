use crate::ports::okta::{
    MockOktaPort, OktaFactorProfile, OktaFactorResource, OktaUserResource, OktaUserResourceProfile,
    OktaUserStatus,
};
use crate::tables::register_okta_tables;
use rusqlite::Connection;
use serde_json::json;
use std::sync::Arc;

fn create_mock_user(id: &str, login: &str) -> OktaUserResource {
    OktaUserResource {
        id: id.to_string(),
        status: OktaUserStatus::Active,
        created: None,
        activated: None,
        status_changed: None,
        last_login: None,
        last_updated: None,
        password_changed: None,
        user_type: None,
        profile: OktaUserResourceProfile {
            first_name: None,
            last_name: None,
            mobile_phone: None,
            second_email: None,
            login: login.to_string(),
            email: None,
            json: json!(null),
        },
        credentials: None,
        links: None,
        json: json!(null),
    }
}

fn create_mock_factor(id: &str, factor_type: &str, provider: &str) -> OktaFactorResource {
    OktaFactorResource {
        id: id.to_string(),
        factor_type: factor_type.to_string(),
        provider: provider.to_string(),
        status: OktaUserStatus::Active,
        profile: Some(OktaFactorProfile {
            phone_number: None,
            email: None,
            json: json!(null),
        }),
        links: None,
        json: json!(null),
    }
}

#[test]
fn test_users_with_fastpass_factor() -> rusqlite::Result<()> {
    let mut mock_port = MockOktaPort::new();

    mock_port.expect_list_users().returning(|| {
        Ok(vec![
            create_mock_user("user1", "user1@example.com"),
            create_mock_user("user2", "user2@example.com"),
            create_mock_user("user3", "user3@example.com"),
        ])
    });

    mock_port
        .expect_get_user()
        .with(mockall::predicate::eq("user1"))
        .returning(|_| Ok(Some(create_mock_user("user1", "user1@example.com"))));

    mock_port
        .expect_get_user()
        .with(mockall::predicate::eq("user2"))
        .returning(|_| Ok(Some(create_mock_user("user2", "user2@example.com"))));

    mock_port
        .expect_get_user()
        .with(mockall::predicate::eq("user3"))
        .returning(|_| Ok(Some(create_mock_user("user3", "user3@example.com"))));

    mock_port
        .expect_list_factors_for_user()
        .with(mockall::predicate::eq("user1"))
        .returning(|_| Ok(vec![create_mock_factor("factor1", "signed_nonce", "OKTA")]));

    mock_port
        .expect_list_factors_for_user()
        .with(mockall::predicate::eq("user2"))
        .returning(|_| Ok(vec![create_mock_factor("factor2", "push", "OKTA")]));

    mock_port
        .expect_list_factors_for_user()
        .with(mockall::predicate::eq("user3"))
        .returning(|_| Ok(vec![create_mock_factor("factor3", "signed_nonce", "OKTA")]));

    let db = Connection::open_in_memory()?;
    register_okta_tables(&db, Arc::new(mock_port))?;

    let rows: Vec<String> = db
        .prepare(
            "SELECT u.id AS user_id \
             FROM okta_users u \
             JOIN okta_factors f ON f.user_id = u.id \
             WHERE f.factor_type = 'signed_nonce' AND f.provider = 'OKTA' \
             ORDER BY u.id",
        )?
        .query_map([], |row| row.get("user_id"))?
        .collect::<Result<Vec<String>, _>>()?;

    assert_eq!(rows, vec!["user1".to_string(), "user3".to_string()]);
    Ok(())
}
