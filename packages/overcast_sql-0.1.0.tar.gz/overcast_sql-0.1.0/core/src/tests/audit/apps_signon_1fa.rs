use crate::ports::okta::{
    MockOktaPort, OktaApplicationResource, OktaApplicationStatus, OktaPolicyResource,
    OktaPolicyRuleResource,
};
use crate::tables::register_okta_tables;
use rusqlite::Connection;
use serde_json::json;
use std::sync::Arc;

fn create_mock_app(id: &str, policy_id: Option<&str>) -> OktaApplicationResource {
    let links = policy_id.map(|policy_id| {
        serde_json::json!({
            "accessPolicy": {
                "href": format!("https://example.okta.com/api/v1/policies/{}", policy_id)
            }
        })
    });

    OktaApplicationResource {
        id: id.to_string(),
        name: format!("app_{}", id),
        label: format!("App {}", id),
        sign_on_mode: Some("OPENID_CONNECT".to_string()),
        status: OktaApplicationStatus::Active,
        created: None,
        last_updated: None,
        credentials: None,
        settings: None,
        links,
        accessibility: None,
        visibility: None,
        features: None,
        json: json!(null),
    }
}

fn create_mock_policy(id: &str, policy_type: &str) -> OktaPolicyResource {
    OktaPolicyResource {
        id: id.to_string(),
        name: format!("Policy {}", id),
        description: None,
        policy_type: policy_type.to_string(),
        status: "ACTIVE".to_string(),
        priority: Some(1),
        system: Some(false),
        created: None,
        last_updated: None,
        conditions: None,
        settings: None,
        links: None,
        json: json!(null),
    }
}

fn create_mock_rule(id: &str, factor_mode: &str) -> OktaPolicyRuleResource {
    OktaPolicyRuleResource {
        id: id.to_string(),
        name: format!("Rule {}", id),
        rule_type: "SIGN_ON".to_string(),
        status: "ACTIVE".to_string(),
        priority: Some(1),
        system: Some(false),
        created: None,
        last_updated: None,
        conditions: None,
        actions: Some(json!({
            "appSignOn": {
                "access": "ALLOW",
                "verificationMethod": {
                    "factorMode": factor_mode
                }
            }
        })),
        links: None,
        json: json!(null),
    }
}

#[test]
fn test_apps_with_sign_on_policy_1fa() -> rusqlite::Result<()> {
    let mut mock_port = MockOktaPort::new();

    mock_port.expect_list_policies().returning(|policy_type| {
        if policy_type == "OKTA_SIGN_ON" {
            return Ok(Vec::new());
        }

        Ok(vec![
            create_mock_policy("policy_1fa", "ACCESS_POLICY"),
            create_mock_policy("policy_2fa", "ACCESS_POLICY"),
        ])
    });

    mock_port
        .expect_list_policy_rules()
        .with(mockall::predicate::eq("policy_1fa"))
        .returning(|_| Ok(vec![create_mock_rule("rule_1fa", "1FA")]));

    mock_port
        .expect_list_policy_rules()
        .with(mockall::predicate::eq("policy_2fa"))
        .returning(|_| Ok(vec![create_mock_rule("rule_2fa", "2FA")]));

    mock_port
        .expect_get_policy()
        .with(mockall::predicate::eq("policy_1fa"))
        .returning(|_| Ok(Some(create_mock_policy("policy_1fa", "ACCESS_POLICY"))));

    mock_port
        .expect_get_policy()
        .with(mockall::predicate::eq("policy_2fa"))
        .returning(|_| Ok(Some(create_mock_policy("policy_2fa", "ACCESS_POLICY"))));

    mock_port.expect_list_applications().returning(|| {
        Ok(vec![
            create_mock_app("app1", Some("policy_1fa")),
            create_mock_app("app2", Some("policy_2fa")),
            create_mock_app("app3", None),
        ])
    });

    let db = Connection::open_in_memory()?;
    register_okta_tables(&db, Arc::new(mock_port))?;

    let rows: Vec<String> = db
        .prepare(
            "SELECT app.id AS app_id \
             FROM okta_applications app \
             JOIN okta_policies policy ON policy.id = app.policy_id \
             JOIN okta_policy_rules rule ON rule.policy_id = policy.id \
             WHERE policy.type = 'ACCESS_POLICY' \
               AND rule.actions ->> '$.appSignOn.verificationMethod.factorMode' = '1FA' \
             ORDER BY app.id",
        )?
        .query_map([], |row| row.get("app_id"))?
        .collect::<Result<Vec<String>, _>>()?;

    assert_eq!(rows, vec!["app1".to_string()]);
    Ok(())
}
