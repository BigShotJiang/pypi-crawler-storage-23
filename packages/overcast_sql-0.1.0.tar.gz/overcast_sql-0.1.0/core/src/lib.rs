pub mod okta_adapter;
pub mod ports;
pub mod tables;

use std::sync::Arc;

use anyhow::{Result, anyhow};
use rusqlite::Connection;
use rusqlite::types::Value;
use serde_json::{Map, Value as JsonValue};

use crate::okta_adapter::OktaAdapter;
use crate::okta_adapter::config::OktaConfig;
use crate::ports::okta::OktaPort;
use crate::tables::register_okta_tables;

#[cfg(test)]
pub mod tests;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum QueryFormat {
    Json,
    Jsonl,
    Table,
}

impl QueryFormat {
    pub fn parse(value: &str) -> Result<Self> {
        match value {
            "json" => Ok(Self::Json),
            "jsonl" => Ok(Self::Jsonl),
            "table" => Ok(Self::Table),
            _ => Err(anyhow!(
                "invalid format: {value} (use json, jsonl, or table)"
            )),
        }
    }
}

fn sqlite_value_to_json(value: Value) -> JsonValue {
    match value {
        Value::Null => JsonValue::Null,
        Value::Integer(integer) => JsonValue::from(integer),
        Value::Real(real) => JsonValue::from(real),
        Value::Text(text) => JsonValue::from(text),
        Value::Blob(blob) => {
            let mut hex = String::with_capacity(blob.len() * 2);
            for byte in blob {
                hex.push_str(&format!("{:02x}", byte));
            }
            JsonValue::from(hex)
        }
    }
}

fn row_to_json(columns: &[String], row: &rusqlite::Row) -> Result<JsonValue> {
    let mut obj = Map::new();
    for (idx, name) in columns.iter().enumerate() {
        let value: Value = row.get(idx)?;
        obj.insert(name.clone(), sqlite_value_to_json(value));
    }
    Ok(JsonValue::Object(obj))
}

#[derive(Clone)]
pub struct OvercastClient {
    okta_port: Arc<dyn OktaPort>,
}

impl OvercastClient {
    pub fn new(base_url: impl Into<String>, ssws_token: impl Into<String>) -> Result<Self> {
        let config = OktaConfig::new(base_url, ssws_token)?;
        Ok(Self::from_config(config))
    }

    pub fn from_config(config: OktaConfig) -> Self {
        let okta_adapter = OktaAdapter::new(config);
        let okta_port: Arc<dyn OktaPort> = Arc::new(okta_adapter);
        Self { okta_port }
    }

    pub fn from_env() -> Result<Self> {
        Ok(Self::from_config(OktaConfig::from_env()?))
    }

    pub fn query(&self, sql: &str, format: QueryFormat) -> Result<String> {
        run_sql_query_with_port(self.okta_port.clone(), sql, format)
    }
}

fn run_sql_query_with_port(
    okta_port: Arc<dyn OktaPort>,
    sql: &str,
    format: QueryFormat,
) -> Result<String> {
    let conn = Connection::open_in_memory()?;
    register_okta_tables(&conn, okta_port)?;

    let mut stmt = conn.prepare(sql)?;
    let columns: Vec<String> = stmt.column_names().iter().map(|s| s.to_string()).collect();
    let mut rows = stmt.query([])?;

    let payload = match format {
        QueryFormat::Json => {
            let mut out: Vec<JsonValue> = Vec::new();
            while let Some(row) = rows.next()? {
                out.push(row_to_json(&columns, row)?);
            }
            serde_json::to_string(&out)?
        }
        QueryFormat::Jsonl => {
            let mut lines: Vec<String> = Vec::new();
            while let Some(row) = rows.next()? {
                lines.push(serde_json::to_string(&row_to_json(&columns, row)?)?);
            }
            lines.join("\n")
        }
        QueryFormat::Table => {
            let mut all_rows: Vec<JsonValue> = Vec::new();
            while let Some(row) = rows.next()? {
                let mut values: Vec<JsonValue> = Vec::with_capacity(columns.len());
                for idx in 0..columns.len() {
                    let value: Value = row.get(idx)?;
                    values.push(sqlite_value_to_json(value));
                }
                all_rows.push(JsonValue::Array(values));
            }

            let mut obj = Map::new();
            obj.insert(
                "columns".to_string(),
                JsonValue::Array(columns.into_iter().map(JsonValue::from).collect()),
            );
            obj.insert("rows".to_string(), JsonValue::Array(all_rows));
            serde_json::to_string(&JsonValue::Object(obj))?
        }
    };

    Ok(payload)
}

pub fn run_sql_query(sql: &str, format: QueryFormat) -> Result<String> {
    OvercastClient::from_env()?.query(sql, format)
}
