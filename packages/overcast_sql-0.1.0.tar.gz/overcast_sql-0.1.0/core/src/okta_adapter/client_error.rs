use serde_json::Value;

fn extract_error_summary(response_body: &str) -> Option<String> {
    let trimmed = response_body.trim();
    if trimmed.is_empty() {
        return None;
    }

    let parsed: Value = serde_json::from_str(trimmed).ok()?;
    parsed
        .get("errorSummary")
        .and_then(|value| value.as_str())
        .map(str::trim)
        .filter(|summary| !summary.is_empty())
        .map(ToString::to_string)
}

pub fn format_http_error(
    status_code: u16,
    status_line: &str,
    url: &str,
    response_body: &str,
) -> String {
    let body_trimmed = response_body.trim();
    let detail = extract_error_summary(response_body).or_else(|| {
        if body_trimmed.is_empty() {
            None
        } else {
            Some(body_trimmed.lines().next().unwrap_or_default().to_string())
        }
    });

    let base = if status_code == 401 {
        format!("Okta API Unauthorized (401) for {}", url)
    } else {
        format!("Okta API request failed ({}) for {}", status_line, url)
    };

    if let Some(detail) = detail {
        format!("{}: {}", base, detail)
    } else {
        base
    }
}

#[cfg(test)]
mod tests {
    use super::format_http_error;

    #[test]
    fn format_http_error_for_unauthorized_is_explicit() {
        let message = format_http_error(
            401,
            "401 Unauthorized",
            "https://example.okta.com/api/v1/users",
            r#"{"errorSummary":"Authentication failed"}"#,
        );

        assert!(message.contains("Unauthorized (401)"));
        assert!(message.contains("Authentication failed"));
    }

    #[test]
    fn format_http_error_uses_plain_body_when_json_missing() {
        let message = format_http_error(
            403,
            "403 Forbidden",
            "https://example.okta.com/api/v1/users",
            "forbidden",
        );

        assert_eq!(
            message,
            "Okta API request failed (403 Forbidden) for https://example.okta.com/api/v1/users: forbidden"
        );
    }
}
