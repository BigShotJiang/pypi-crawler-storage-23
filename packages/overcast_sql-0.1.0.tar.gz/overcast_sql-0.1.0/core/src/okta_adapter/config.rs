use std::env;

use anyhow::{Context, Result, anyhow};

#[derive(Clone)]
pub struct OktaConfig {
    pub base_url: String,
    pub ssws_token: String,
}

impl OktaConfig {
    pub fn new(base_url: impl Into<String>, ssws_token: impl Into<String>) -> Result<Self> {
        let base_url = base_url.into();
        let ssws_token = ssws_token.into();

        if base_url.trim().is_empty() {
            return Err(anyhow!("base_url cannot be empty"));
        }

        if ssws_token.trim().is_empty() {
            return Err(anyhow!("ssws_token cannot be empty"));
        }

        Ok(Self {
            base_url,
            ssws_token,
        })
    }

    /// Load configuration from environment variables.
    /// Expected variables:
    /// - `OKTA_BASE_URL`
    /// - `OKTA_SSWS_TOKEN`
    pub fn from_env() -> Result<Self> {
        let base_url = env::var("OKTA_BASE_URL").context("missing OKTA_BASE_URL env var")?;
        let ssws_token = env::var("OKTA_SSWS_TOKEN").context("missing OKTA_SSWS_TOKEN env var")?;

        Self::new(base_url, ssws_token)
    }
}
