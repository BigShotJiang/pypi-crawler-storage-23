use std::path::Path;
use std::sync::Mutex;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use anyhow::{Context, Result};
use rusqlite::{Connection, OptionalExtension, params};

pub struct DiskCache {
    conn: Mutex<Connection>,
}

impl DiskCache {
    pub fn new(path: &Path) -> Result<Self> {
        let conn = Connection::open(path)
            .with_context(|| format!("failed to open cache database at {}", path.display()))?;

        // Use WAL for better concurrent read/write behavior.
        conn.pragma_update(None, "journal_mode", "WAL")
            .context("failed to enable WAL for cache")?;

        conn.execute_batch(
            "CREATE TABLE IF NOT EXISTS cache_entries (
                key TEXT PRIMARY KEY,
                value BLOB NOT NULL,
                fetched_at INTEGER NOT NULL
            );",
        )
        .context("failed to init cache schema")?;

        Ok(Self {
            conn: Mutex::new(conn),
        })
    }

    pub fn get(&self, key: &str, ttl: Duration) -> Result<Option<Vec<u8>>> {
        let cutoff = SystemTime::now()
            .checked_sub(ttl)
            .unwrap_or(SystemTime::UNIX_EPOCH);
        let cutoff_secs = cutoff
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs() as i64;

        let conn = self.conn.lock().unwrap();
        let row: Option<(Vec<u8>, i64)> = conn
            .query_row(
                "SELECT value, fetched_at FROM cache_entries WHERE key = ?1",
                params![key],
                |r| Ok((r.get(0)?, r.get(1)?)),
            )
            .optional()?;

        match row {
            Some((value, fetched_at)) if fetched_at >= cutoff_secs => Ok(Some(value)),
            _ => Ok(None),
        }
    }

    pub fn put(&self, key: &str, value: &[u8]) -> Result<()> {
        let fetched_at = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs() as i64;

        let conn = self.conn.lock().map_err(|error| {
            anyhow::anyhow!(
                "failed to acquire cache lock: {}",
                error.to_string().replace("\n", " ; ")
            )
        })?;
        conn.execute(
            "INSERT INTO cache_entries(key, value, fetched_at)
             VALUES(?1, ?2, ?3)
             ON CONFLICT(key) DO UPDATE SET value=excluded.value, fetched_at=excluded.fetched_at",
            params![key, value, fetched_at],
        )?;
        Ok(())
    }
}
