mod cache;
mod client;
mod client_error;
pub mod config;

use anyhow::Result;
use urlencoding::encode;

use crate::okta_adapter::client::OktaClient;
use crate::okta_adapter::config::OktaConfig;
use crate::ports::okta::{
    OktaAppGroupResource, OktaAppUserResource, OktaApplicationResource, OktaFactorResource,
    OktaGroupMemberResource, OktaGroupResource, OktaPolicyResource, OktaPolicyRuleResource,
    OktaPort, OktaUserResource,
};

#[derive(Clone)]
pub struct OktaAdapter {
    client: OktaClient,
}

impl OktaAdapter {
    pub fn new(okta_config: OktaConfig) -> Self {
        Self {
            client: OktaClient::new(okta_config),
        }
    }
}

impl OktaPort for OktaAdapter {
    fn get_user(&self, id: &str) -> Result<Option<OktaUserResource>> {
        let path = format!("/api/v1/users/{}", id);
        self.client.get_optional(&path)
    }

    fn list_users(&self) -> Result<Vec<OktaUserResource>> {
        let path = "/api/v1/users".to_string();
        self.client.get_paginated(&path)
    }

    fn list_users_with_filter(&self, filter: &str) -> Result<Vec<OktaUserResource>> {
        let encoded = encode(filter);
        let path = format!("/api/v1/users?filter={}", encoded);
        self.client.get_paginated(&path)
    }

    fn list_factors_for_user(&self, user_id: &str) -> Result<Vec<OktaFactorResource>> {
        let path = format!("/api/v1/users/{}/factors", user_id);
        self.client.get_paginated(&path)
    }

    fn get_group(&self, id: &str) -> Result<Option<OktaGroupResource>> {
        let path = format!("/api/v1/groups/{}", id);
        self.client.get_optional(&path)
    }

    fn list_groups(&self) -> Result<Vec<OktaGroupResource>> {
        let path = "/api/v1/groups".to_string();
        self.client.get_paginated(&path)
    }

    fn list_users_in_group(&self, group_id: &str) -> Result<Vec<OktaGroupMemberResource>> {
        let path = format!("/api/v1/groups/{}/users", group_id);
        self.client.get_paginated(&path)
    }

    fn list_groups_for_user(&self, user_id: &str) -> Result<Vec<OktaGroupResource>> {
        let path = format!("/api/v1/users/{}/groups", user_id);
        self.client.get_paginated(&path)
    }

    fn get_policy(&self, id: &str) -> Result<Option<OktaPolicyResource>> {
        let path = format!("/api/v1/policies/{}", id);
        self.client.get_optional(&path)
    }

    fn list_policies(&self, policy_type: &str) -> Result<Vec<OktaPolicyResource>> {
        let path = format!("/api/v1/policies?type={}", policy_type);
        self.client.get_paginated(&path)
    }

    fn list_policy_rules(&self, policy_id: &str) -> Result<Vec<OktaPolicyRuleResource>> {
        let path = format!("/api/v1/policies/{}/rules", policy_id);
        self.client.get_paginated(&path)
    }

    fn get_policy_rule(
        &self,
        policy_id: &str,
        rule_id: &str,
    ) -> Result<Option<OktaPolicyRuleResource>> {
        let path = format!("/api/v1/policies/{}/rules/{}", policy_id, rule_id);
        self.client.get_optional(&path)
    }

    fn list_app_groups(&self, app_id: &str) -> Result<Vec<OktaAppGroupResource>> {
        let path = format!("/api/v1/apps/{}/groups", app_id);
        self.client.get_paginated(&path)
    }

    fn list_app_users(&self, app_id: &str) -> Result<Vec<OktaAppUserResource>> {
        let path = format!("/api/v1/apps/{}/users", app_id);
        self.client.get_paginated(&path)
    }

    fn list_applications(&self) -> Result<Vec<OktaApplicationResource>> {
        let path = "/api/v1/apps".to_string();
        self.client.get_paginated(&path)
    }
}
