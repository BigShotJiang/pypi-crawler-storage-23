use std::env;
use std::path::Path;
use std::sync::Arc;
use std::thread::sleep;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use anyhow::Result;
use log::debug;
use serde::Serialize;
use serde::de::DeserializeOwned;
use serde_json::Value;

use crate::okta_adapter::cache::DiskCache;
use crate::okta_adapter::client_error::format_http_error;
use crate::okta_adapter::config::OktaConfig;
use crate::ports::okta::JsonSupport;

pub const OKTA_CACHE_TTL: Duration = Duration::from_hours(16);

#[derive(Clone)]
pub struct OktaClient {
    config: OktaConfig,
    agent: ureq::Agent,
    cache: Option<Arc<DiskCache>>,
    cache_ttl: Duration,
}

impl OktaClient {
    pub fn new(config: OktaConfig) -> Self {
        let agent = ureq::Agent::config_builder()
            .http_status_as_error(false)
            .build()
            .into();

        let cache_ttl = OKTA_CACHE_TTL;

        let cache = env::var("OKTA_CACHE_PATH").unwrap_or_else(|_| "okta_cache.sqlite".to_string());
        let cache = DiskCache::new(Path::new(&cache))
            .map(Arc::new)
            .map_err(|e| {
                eprintln!("cache disabled ({}). set OKTA_CACHE_PATH to fix", e);
                e
            })
            .ok();

        Self {
            config,
            agent,
            cache,
            cache_ttl,
        }
    }

    fn is_transient_status(code: u16) -> bool {
        matches!(code, 500 | 502 | 503 | 504)
    }

    fn retry_delay(attempt: u32) -> Duration {
        // Exponential backoff with a 1s floor and a modest cap.
        let capped = attempt.min(5);
        Duration::from_secs(1 << capped)
    }

    fn rate_limit_delay(mut header_lookup: impl FnMut(&str) -> Option<String>) -> Option<Duration> {
        // Okta returns `X-Rate-Limit-Reset` as a unix timestamp (seconds) for the next window.
        // Add a small leeway to account for clock skew and to avoid tight loops.
        const LEEWAY_SECS: u64 = 1;

        let reset_epoch_secs: u64 = header_lookup("X-Rate-Limit-Reset")?.parse().ok()?;

        let reset_instant =
            UNIX_EPOCH + Duration::from_secs(reset_epoch_secs.saturating_add(LEEWAY_SECS));
        let now = SystemTime::now();
        let wait_duration = reset_instant
            .duration_since(now)
            .unwrap_or_else(|_| Duration::from_secs(LEEWAY_SECS));

        Some(wait_duration.max(Duration::from_secs(LEEWAY_SECS)))
    }

    fn parse_next_link(link_header: Option<&str>) -> Option<String> {
        link_header.and_then(|raw| {
            raw.split(',').find_map(|part| {
                let part = part.trim();
                if part.contains("rel=\"next\"") {
                    let start = part.find('<')?;
                    let end = part.find('>')?;
                    return Some(part[start + 1..end].to_string());
                }
                None
            })
        })
    }

    fn get_json_with_retry(
        &self,
        url: &str,
        allow_not_found: bool,
    ) -> Result<Option<(Option<String>, Value)>> {
        let mut attempt: u32 = 0;

        loop {
            debug!("Okta API call: GET {}", url.replace("https://", ""));

            let request = self.agent.get(url).header(
                "Authorization",
                std::format!("SSWS {}", self.config.ssws_token),
            );

            let mut resp = request.call()?;

            let status = resp.status();
            let status_code = status.as_u16();

            if status_code == 404 && allow_not_found {
                return Ok(None);
            }

            if status_code == 429 {
                let delay = Self::rate_limit_delay(|name| {
                    resp.headers()
                        .get(name)
                        .and_then(|v| v.to_str().ok().map(|s| s.to_string()))
                })
                .unwrap_or_else(|| Self::retry_delay(attempt));
                attempt = attempt.saturating_add(1);
                sleep(delay);
                continue;
            }

            if Self::is_transient_status(status_code) {
                let delay = Self::retry_delay(attempt);
                attempt = attempt.saturating_add(1);
                sleep(delay);
                continue;
            }

            if !(200..300).contains(&status_code) {
                let response_body = resp.body_mut().read_to_string().unwrap_or_default();
                return Err(anyhow::anyhow!(format_http_error(
                    status_code,
                    &status.to_string(),
                    url,
                    &response_body
                )));
            }

            let link_header = {
                let mut combined: Option<String> = None;
                for value in resp.headers().get_all("Link").iter() {
                    if let Ok(text) = value.to_str() {
                        match &mut combined {
                            Some(existing) => {
                                existing.push_str(", ");
                                existing.push_str(text);
                            }
                            None => combined = Some(text.to_string()),
                        }
                    }
                }
                combined
            };
            let json_value: Value = resp.body_mut().read_json()?;
            return Ok(Some((link_header, json_value)));
        }
    }

    pub fn get_optional<T: DeserializeOwned + JsonSupport>(
        &self,
        url_path: &str,
    ) -> Result<Option<T>> {
        let url = format!("{}{}", self.config.base_url, url_path);
        match self.get_json_with_retry(&url, true)? {
            Some((_link, json)) => {
                let mut item: T = serde_json::from_value(json.clone())?;
                item.set_json(json);
                Ok(Some(item))
            }
            None => Ok(None),
        }
    }

    pub fn get_paginated<T: DeserializeOwned + Serialize + JsonSupport>(
        &self,
        url_path: &str,
    ) -> Result<Vec<T>> {
        let mut results: Vec<T> = Vec::new();
        let mut next_url = format!("{}{}", self.config.base_url, url_path);
        let cache_key = format!("{}{}", self.config.base_url, url_path);

        if let Some(cache) = &self.cache
            && let Ok(Some(bytes)) = cache.get(&cache_key, self.cache_ttl)
            && let Ok(cached) = serde_json::from_slice::<Vec<T>>(&bytes)
        {
            return Ok(cached);
        }

        loop {
            let (link_header, page_value) = match self.get_json_with_retry(&next_url, false)? {
                Some(payload) => payload,
                None => return Ok(results),
            };

            let page_items = match page_value {
                Value::Array(items) => items,
                _ => {
                    return Err(anyhow::anyhow!(
                        "unexpected Okta response type for {}",
                        next_url
                    ));
                }
            };

            for json in page_items {
                let mut item: T = serde_json::from_value(json.clone())?;
                item.set_json(json);
                results.push(item);
            }

            if let Some(next) = Self::parse_next_link(link_header.as_deref()) {
                next_url = if next.starts_with("http") {
                    next
                } else {
                    format!("{}{}", self.config.base_url, next)
                };
            } else {
                break;
            }
        }

        if let Some(cache) = &self.cache
            && let Ok(bytes) = serde_json::to_vec(&results)
        {
            let _ = cache.put(&cache_key, &bytes);
        }

        Ok(results)
    }
}

#[cfg(test)]
mod tests {
    use super::OktaClient;

    #[test]
    fn parse_next_link_returns_none_when_missing() {
        let header = Some(r#"<https://example.com/api/v1/users?limit=1>; rel="self""#);
        assert_eq!(OktaClient::parse_next_link(header), None);
        assert_eq!(OktaClient::parse_next_link(None), None);
    }

    #[test]
    fn parse_next_link_extracts_absolute_url() {
        let header = Some(
            r#"<https://example.com/api/v1/users?limit=1>; rel="self", <https://example.com/api/v1/users?after=abc&limit=1>; rel="next""#,
        );

        let next = OktaClient::parse_next_link(header);

        assert_eq!(
            next,
            Some("https://example.com/api/v1/users?after=abc&limit=1".to_string())
        );
    }

    #[test]
    fn parse_next_link_supports_relative_url() {
        let header = Some(r#"</api/v1/users?after=cursor&limit=1>; rel="next""#);

        let next = OktaClient::parse_next_link(header);

        assert_eq!(next, Some("/api/v1/users?after=cursor&limit=1".to_string()));
    }
}
