use log::info;
use rusqlite::Connection;
use rusqlite::types::Value;
use std::sync::Arc;

use overcast::okta_adapter::OktaAdapter;
use overcast::okta_adapter::config::OktaConfig;
use overcast::ports::okta::OktaPort;
use overcast::tables::register_okta_tables;

fn print_query_info<P: rusqlite::Params>(
    conn: &Connection,
    sql: &str,
    params: P,
) -> rusqlite::Result<()> {
    let mut stmt = conn.prepare(sql)?;
    let column_names: Vec<String> = stmt
        .column_names()
        .into_iter()
        .map(|s| s.to_owned())
        .collect();

    let mut rows = stmt.query(params)?;
    let column_count = column_names.len();
    while let Some(row) = rows.next()? {
        let values: Vec<rusqlite::types::Value> = (0..column_count)
            .map(|i| row.get(i))
            .collect::<rusqlite::Result<_>>()?;

        let mut string_to_display = String::new();
        for (name, value) in column_names.iter().zip(values.iter()) {
            string_to_display += &format!(
                "{}={} ",
                name,
                match value {
                    Value::Null => "null".to_string(),
                    Value::Integer(integer) => integer.to_string(),
                    Value::Real(real) => real.to_string(),
                    Value::Text(text) => text.to_string(),
                    Value::Blob(blob) => format!("{:?}", blob),
                }
            );
        }

        info!("{}", string_to_display);
    }

    Ok(())
}

fn main() -> anyhow::Result<()> {
    const AUDIT_LOG_LEVEL: &str = "info"; // "debug" or "info"
    let default_filter =
        env_logger::Env::default().default_filter_or(format!("log,overcast={AUDIT_LOG_LEVEL}"));
    env_logger::Builder::from_env(default_filter).init();

    let okta_config = OktaConfig::from_env()?;
    let okta_adapter = OktaAdapter::new(okta_config);
    let okta_port: Arc<dyn OktaPort> = Arc::new(okta_adapter);

    let conn = Connection::open_in_memory()?;
    register_okta_tables(&conn, okta_port)?;

    print_query_info(
        &conn,
        "SELECT id, name, type, status, priority FROM okta_policies",
        rusqlite::params![],
    )?;

    Ok(())
}
