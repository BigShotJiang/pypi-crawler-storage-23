use overcast::{OvercastClient, QueryFormat, run_sql_query};
use pyo3::exceptions::PyRuntimeError;
use pyo3::prelude::*;

fn parse_query_format(format: Option<&str>) -> PyResult<QueryFormat> {
    let normalized = format.unwrap_or("json");
    QueryFormat::parse(normalized)
        .map_err(|err| PyRuntimeError::new_err(format!("SQL query failed: {err}")))
}

#[pyclass(name = "Client")]
struct PyOvercastClient {
    inner: OvercastClient,
}

#[pymethods]
impl PyOvercastClient {
    #[new]
    fn new(base_url: &str, ssws_token: &str) -> PyResult<Self> {
        let inner = OvercastClient::new(base_url, ssws_token)
            .map_err(|err| PyRuntimeError::new_err(format!("Client init failed: {err}")))?;
        Ok(Self { inner })
    }

    fn run_query(&self, sql: &str, format: Option<&str>) -> PyResult<String> {
        let parsed_format = parse_query_format(format)?;
        self.inner
            .query(sql, parsed_format)
            .map_err(|err| PyRuntimeError::new_err(format!("SQL query failed: {err}")))
    }
}

#[pyfunction]
fn run_query(sql: &str, format: Option<&str>) -> PyResult<String> {
    let parsed_format = parse_query_format(format)?;

    run_sql_query(sql, parsed_format)
        .map_err(|err| PyRuntimeError::new_err(format!("SQL query failed: {err}")))
}

#[pymodule]
fn _overcast_sql(_py: Python<'_>, module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_class::<PyOvercastClient>()?;
    module.add_function(wrap_pyfunction!(run_query, module)?)?;
    Ok(())
}
