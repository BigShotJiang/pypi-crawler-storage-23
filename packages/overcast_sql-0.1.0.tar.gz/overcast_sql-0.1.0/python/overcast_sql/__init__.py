import json

from ._overcast_sql import Client as _NativeClient
from ._overcast_sql import run_query as _run_query


class OktaSqlError(Exception):
    """Error raised when the Rust overcast_sql query fails."""


def _normalize_format(format: str) -> tuple[str, str]:
    normalized_format = format.lower()
    if normalized_format == "pandas":
        return normalized_format, "table"
    return normalized_format, normalized_format


def _validate_cmd_format(cmd_format: str) -> None:
    if cmd_format not in {"json", "jsonl", "table"}:
        raise ValueError("Unsupported format. Use 'json', 'jsonl', 'table', or 'pandas'.")


def _decode_output(raw_output: str, normalized_format: str):
    if normalized_format == "json":
        return json.loads(raw_output)
    if normalized_format == "jsonl":
        return [json.loads(line) for line in raw_output.splitlines() if line.strip()]
    if normalized_format == "table":
        return json.loads(raw_output)
    if normalized_format == "pandas":
        data = json.loads(raw_output)
        try:
            import pandas as pd
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError(
                "pandas is required for format='pandas'. Install with `pip install pandas`."
            ) from exc
        return pd.DataFrame(data["rows"], columns=data["columns"])

    raise AssertionError("unreachable")


class Client:
    """Okta SQL client with explicit credentials."""

    def __init__(self, *, base_url: str, ssws_token: str):
        self._native = _NativeClient(base_url, ssws_token)

    def query(self, sql: str, *, format: str = "pandas"):
        normalized_format, cmd_format = _normalize_format(format)
        _validate_cmd_format(cmd_format)

        try:
            raw_output = self._native.run_query(sql, cmd_format)
        except Exception as exc:
            raise OktaSqlError(f"SQL query failed: {exc}") from exc

        return _decode_output(raw_output, normalized_format)


def query(sql: str, *, format: str = "pandas"):
    """Run a SQL query using environment-based credentials."""

    normalized_format, cmd_format = _normalize_format(format)
    _validate_cmd_format(cmd_format)

    try:
        raw_output = _run_query(sql, cmd_format)
    except Exception as exc:
        raise OktaSqlError(f"SQL query failed: {exc}") from exc

    return _decode_output(raw_output, normalized_format)
