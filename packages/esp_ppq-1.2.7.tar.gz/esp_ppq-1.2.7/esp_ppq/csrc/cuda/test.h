# include "common.cuh"

void dummy_pooling_v1(
    const Tensor source,
    Tensor dest,
    const float in_scale,
    const float out_scale
);

void dummy_pooling_v2(
    const Tensor source,
    Tensor dest,
    const float in_scale,
    const float out_scale
);

void dummy_pooling_v3(
    const Tensor source,
    Tensor dest,
    const float in_scale,
    const float out_scale
);
