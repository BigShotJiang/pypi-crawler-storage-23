from .agent import SingleRoomAgent
from meshagent.api.chan import Chan
from meshagent.api import RoomMessage, RoomClient
from meshagent.agents import AgentSessionContext
from meshagent.tools import (
    RemoteToolkit,
    FunctionTool,
    Toolkit,
    make_toolkits,
    ToolkitBuilder,
)
from .adapter import LLMAdapter
import asyncio
import contextlib
from typing import Optional
import json
from meshagent.tools import ToolContext
import logging

from pathlib import Path
from meshagent.agents.skills import to_prompt

logger = logging.getLogger("worker")


def _summarize_worker_message(*, message: object) -> str:
    if not isinstance(message, dict):
        return f"type={type(message).__name__}"

    keys = sorted(str(key) for key in message.keys())
    if len(keys) > 8:
        shown_keys = [*keys[:8], f"+{len(keys) - 8} more"]
    else:
        shown_keys = keys

    summary: list[str] = [f"keys={shown_keys}"]

    prompt_value = message.get("prompt")
    if isinstance(prompt_value, str):
        prompt_preview = " ".join(prompt_value.split())
        if len(prompt_preview) > 120:
            prompt_preview = f"{prompt_preview[:117]}..."
        summary.append(f"prompt={prompt_preview!r}")

    body_value = message.get("body")
    if isinstance(body_value, str):
        summary.append(f"body_len={len(body_value)}")

    return ", ".join(summary)


class SubmitWork(FunctionTool):
    def __init__(self, *, agent: "Worker", queue: str):
        self.queue = queue
        self.agent = agent
        super().__init__(
            name=f"queue_{agent.name}_task",
            title=f"Queue {agent.title} Task",
            description=f"Queues a new task to the worker -- {agent.description}",
            input_schema={
                "type": "object",
                "required": ["prompt"],
                "additionalProperties": False,
                "properties": {
                    "prompt": {
                        "type": "string",
                    },
                },
            },
        )

    async def execute(self, context: ToolContext, *, prompt: str):
        await context.room.queues.send(
            name=self.queue,
            message={
                "prompt": prompt,
            },
            create=True,
        )
        return None


class Worker(SingleRoomAgent):
    def __init__(
        self,
        *,
        queue: str,
        name=None,
        title=None,
        description=None,
        requires=None,
        llm_adapter: LLMAdapter,
        toolkits: Optional[list[Toolkit]] = None,
        rules: Optional[list[str]] = None,
        toolkit_name: Optional[str] = None,
        skill_dirs: Optional[list[str]] = None,
        supports_context: bool = True,
        annotations: Optional[list[str]] = None,
    ):
        super().__init__(
            name=name,
            title=title,
            description=description,
            requires=requires,
            annotations=annotations,
        )

        self._skill_dirs = skill_dirs

        self._queue = queue

        if toolkits is None:
            toolkits = []

        self._llm_adapter = llm_adapter

        self._message_channel = Chan[RoomMessage]()

        self._room: RoomClient | None = None
        self._toolkits = toolkits

        if rules is None:
            rules = []

        self._rules = rules
        self._done = False

        if toolkit_name is not None:
            logger.info(f"worker will start toolkit {toolkit_name}")
            self._worker_toolkit = RemoteToolkit(
                name=toolkit_name,
                tools=[
                    SubmitWork(queue=self._queue, agent=self),
                ],
            )
        else:
            self._worker_toolkit = None

        self.supports_context = supports_context

    async def preflight_start(self, *, room: RoomClient) -> None:
        del room

    async def start(self, *, room: RoomClient):
        self._done = False

        worker_toolkit_started = False
        room_agent_started = False
        try:
            if self._worker_toolkit is not None:
                await self._worker_toolkit.start(room=room)
                worker_toolkit_started = True

            await super().start(room=room)
            room_agent_started = True

            await self.preflight_start(room=room)

            self._main_task = asyncio.create_task(self.run(room=room))
        except Exception:
            self._done = True

            if room_agent_started:
                with contextlib.suppress(Exception):
                    await super().stop()

            if worker_toolkit_started and self._worker_toolkit is not None:
                with contextlib.suppress(Exception):
                    await self._worker_toolkit.stop()
            raise

    async def stop(self):
        self._done = True

        await asyncio.gather(self._main_task)

        if self._worker_toolkit is not None:
            await self._worker_toolkit.stop()

        await super().stop()

    async def get_rules(self):
        rules = [*self._rules]

        if self._skill_dirs is not None and len(self._skill_dirs) > 0:
            rules.append(
                "You have access to to following skills which follow the agentskills spec:"
            )
            rules.append(await to_prompt([*(Path(p) for p in self._skill_dirs)]))
            rules.append(
                "Use the shell or storage tool to find out more about skills and execute them when they are required"
            )

        return rules

    def get_prompt_for_message(self, *, message: dict) -> str:
        prompt = message.get("prompt")
        if prompt is None:
            logger.warning(
                "prompt property not found on worker message, inserting whole message into context"
            )
            prompt = json.dumps(message)

        return prompt

    async def append_message_context(
        self, *, message: dict, chat_context: AgentSessionContext
    ):
        if self.supports_context:
            caller_context_json = message.get("caller_context")
            if caller_context_json is not None:
                caller_context = AgentSessionContext.from_json(caller_context_json)

                chat_context.messages.extend(caller_context.messages)
                chat_context.previous_response_id = caller_context.previous_response_id

        prompt = self.get_prompt_for_message(message=message)

        chat_context.append_user_message(message=prompt)

    async def process_message(
        self,
        *,
        chat_context: AgentSessionContext,
        message: dict,
        toolkits: list[Toolkit],
    ):
        await self.append_message_context(message=message, chat_context=chat_context)

        return await self._llm_adapter.next(
            context=chat_context,
            room=self.room,
            toolkits=toolkits,
        )

    def get_toolkit_builders(self) -> list[ToolkitBuilder]:
        return []

    async def get_message_toolkits(self, *, message: dict) -> list[Toolkit]:
        toolkits = await self.get_required_toolkits(
            context=ToolContext(
                room=self.room,
                caller=self.room.local_participant,
                on_behalf_of=None,
            )
        )

        tool_providers = [*self.get_toolkit_builders()]

        model = message.get("model", self._llm_adapter.default_model())

        message_tools = message.get("tools")

        if message_tools is not None and len(message_tools) > 0:
            toolkits.extend(
                await make_toolkits(
                    room=self.room,
                    model=model,
                    providers=tool_providers,
                    tools=message_tools,
                )
            )
        return [*self._toolkits, *toolkits]

    def prepare_chat_context(self, *, chat_context: AgentSessionContext):
        pass

    async def init_session(self) -> AgentSessionContext:
        context = self._llm_adapter.create_session()
        context.append_rules(self._rules)
        return context

    async def run(self, *, room: RoomClient):
        backoff = 0
        while not self._done:
            try:
                message = await room.queues.receive(
                    name=self._queue, create=True, wait=True
                )

                backoff = 0
                if message is not None:
                    logger.info("received message on worker queue")
                    try:
                        session_context = await self.init_session()
                        async with session_context:
                            session_context.replace_rules(
                                rules=[
                                    *await self.get_rules(),
                                ]
                            )

                            toolkits = await self.get_message_toolkits(message=message)

                            self.prepare_chat_context(chat_context=session_context)

                            await self.process_message(
                                chat_context=session_context,
                                message=message,
                                toolkits=toolkits,
                            )

                    except Exception as e:
                        logger.error(
                            "Failed to process worker message: %s (%s)",
                            e,
                            _summarize_worker_message(message=message),
                            exc_info=e,
                        )

            except Exception as e:
                logger.error(
                    f"Worker error while receiving: {e}, will retry", exc_info=e
                )

                await asyncio.sleep(0.1 * pow(2, backoff))
                backoff = backoff + 1
