SEASONS = {"Season1": "Season 1", "Season2": "Season 2"}
PLATFORM = {
    0: "unknown",
    1: "pc",
    2: "ps4",
    3: "xboxone",
    4: "ps5",
    5: "xboxseries",
    6: "common",
    7: "steam",
}
STATS_PLATFORM = {
    1: "pc",
    3: "xboxone",
    2: "ps4",
    5: "xboxseries",
    4: "ps5",
    6: "common",
    7: "steam",
}
PLATFORM_REVERSE = {
    "unknown": 0,
    "pc": 1,
    "ps4": 2,
    "xboxone": 3,
    "ps5": 4,
    "xboxseries": 5,
    "common": 6,
    "steam": 7,
}
PLATFORM_FESL = {
    0: "pc",
    1: "pc",
    2: "ps4",
    3: "xboxone",
    4: "ps4",
    5: "xboxone",
    6: "pc",
    7: "pc",
}
STATS_PLATFORM_REVERSE = {
    "pc": 1,
    "xboxone": 3,
    "ps4": 2,
    "xboxseries": 5,
    "ps5": 4,
    "xbox": 5,
    "psn": 4,
    "steam": 7,
}
REGIONS = {
    "aws-hkg": "Asia",
    "aws-icn": "Asia",
    "aws-nrt": "Asia",
    "aws-sin": "Asia",
    "aws-iad": "North America",
    "aws-pdx": "North America",
    "aws-sjc": "North America",
    "aws-brz": "South America",
    "aws-fra": "Europe",
    "aws-lhr": "Europe",
    "aws-syd": "Oceania",
}
REGIONSLIST = {
    "asia": ["aws-hkg", "aws-icn", "aws-nrt", "aws-sin"],
    "nam": ["aws-iad", "aws-pdx", "aws-sjc"],
    "sam": ["aws-brz"],
    "eu": ["aws-fra", "aws-lhr"],
    "oc": ["aws-syd"],
    "all": [
        "aws-iad",
        "aws-pdx",
        "aws-sjc",
        "aws-brz",
        "aws-fra",
        "aws-lhr",
        "aws-hkg",
        "aws-icn",
        "aws-nrt",
        "aws-sin",
        "aws-syd",
    ],
}
SHORT_REGIONS = {
    "aws-hkg": "asia",
    "aws-icn": "asia",
    "aws-nrt": "asia",
    "aws-sin": "asia",
    "aws-iad": "nam",
    "aws-pdx": "nam",
    "aws-sjc": "nam",
    "aws-brz": "sam",
    "aws-fra": "eu",
    "aws-lhr": "eu",
    "aws-syd": "oc",
}
MAPS = {
    "MP_Abbasid": "Siege of Cairo",
    "MP_Aftermath": "Empire State",
    "MP_Badlands": "Blackwell Fields",
    "MP_Battery": "Iberian Offensive",
    "MP_Capstone": "Liberation Peak",
    "MP_Dumbo": "Manhattan Bridge",
    "MP_Eastwood": "Eastwood",
    "MP_FireStorm": "Operation Firestorm",
    "MP_Limestone": "Saints Quarter",
    "MP_Outskirts": "New Sobek City",
    "MP_Tungsten": "Mirak Valley",
    "MP_Portal_Sand": "Portal Sandbox",
    "MP_Contaminated": "Contaminated",
    "MP_Granite": "Fort Lyndon",
    "MP_Granite_MainStreet_Portal": "Downtown",
    "MP_Granite_MilitaryRnD_Portal": "Area 22B",
    "MP_Granite_Marina_Portal": "Marina",
    "MP_Granite_MilitaryStorage_Portal": "Redline Storage",
    "MP_Granite_ClubHouse_Portal": "Club House",
    "MP_Granite_TechCampus_Portal": "Tech Center",
}
TO_GAME_MAPS = {
    "siege of cairo": "MP_Abbasid",
    "empire state": "MP_Aftermath",
    "blackwell fields": "MP_Badlands",
    "iberian offensive": "MP_Battery",
    "liberation peak": "MP_Capstone",
    "manhattan bridge": "MP_Dumbo",
    "eastwood": "MP_Eastwood",
    "operation firestorm": "MP_FireStorm",
    "saints quarter": "MP_Limestone",
    "new sobek city": "MP_Outskirts",
    "mirak valley": "MP_Tungsten",
    "contaminated": "MP_Contaminated",
    "portal sandbox": "MP_Portal_Sand",
    "area 22b": "MP_Granite_MilitaryRnD_Portal",
    "downtown": "MP_Granite_MainStreet_Portal",
    "redline storage": "MP_Granite_MilitaryStorage_Portal",
    "club house": "MP_Granite_ClubHouse_Portal",
    "tech center": "MP_Granite_TechCampus_Portal",
}
MAP_TRANSLATION_IDS = {
    "MP_Abbasid": "ID_MP_LVL_ABBASID_NAME",
    "MP_Aftermath": "ID_MP_LVL_AFTERMATH_NAME",
    "MP_Badlands": "ID_MP_LVL_BADLANDS_NAME",
    "MP_Battery": "ID_MP_LVL_BATTERY_NAME",
    "MP_Capstone": "ID_MP_LVL_CAPSTONE_NAME",
    "MP_Dumbo": "ID_MP_LVL_DUMBO_NAME",
    "MP_Eastwood": "ID_MP_LVL_EASTWOOD_NAME",
    "MP_FireStorm": "ID_MP_LVL_FIRESTORM_NAME",
    "MP_Limestone": "ID_MP_LVL_LIMESTONE_NAME",
    "MP_Outskirts": "ID_MP_LVL_OUTSKIRTS_NAME",
    "MP_Tungsten": "ID_MP_LVL_TUNGSTEN_NAME",
    "MP_Contaminated": "ID_ARRIVAL_MAP_CONTAMINATED",
    "MP_Portal_Sand": "ID_ARRIVAL_MAP_PORTALSANDBOX",
    "MP_Granite": "ID_ARRIVAL_MAP_GRANITE",
    "MP_Granite_MainStreet_Portal": "ID_ARRIVAL_MAP_GRANITE_DOWNTOWN",
    "MP_Granite_MilitaryRnD_Portal": "ID_ARRIVAL_MAP_GRANITE_MILITARY_RND_N",
    "MP_Granite_MilitaryStorage_Portal": "ID_ARRIVAL_MAP_GRANITE_MILITARY_STORAGE_N",
    "MP_Granite_Marina_Portal": "ID_ARRIVAL_MAP_GRANITE_MARINA",
    "MP_Granite_ClubHouse_Portal": "ID_ARRIVAL_MAP_GRANITE_CLUB_HOUSE",
    "MP_Granite_TechCampus_Portal": "ID_ARRIVAL_MAP_GRANITE_TECH_CENTER",
}
MAP_PICTURES = {
    "MP_Abbasid": "https://cdn.gametools.network/maps/bf6/T_UI_Abbasid_Large_OPT-49a3761a.webp",
    "MP_Aftermath": "https://cdn.gametools.network/maps/bf6/T_UI_Aftermath_Large_OPT-bf883df1.webp",
    "MP_Badlands": "https://cdn.gametools.network/maps/bf6/T_UI_Badlands_Large_OPT-6885eb83.webp",
    "MP_Battery": "https://cdn.gametools.network/maps/bf6/T_UI_Battery_Large_OPT-034d4636.webp",
    "MP_Capstone": "https://cdn.gametools.network/maps/bf6/T_UI_Capstone_Large_OPT-2ccae694.webp",
    "MP_Eastwood": "https://cdn.gametools.network/maps/bf6/T_UI_Eastwood_Large_OPT-3bfa6a6f.webp",
    "MP_Dumbo": "https://cdn.gametools.network/maps/bf6/T_UI_Dumbo_Large_OPT-20de031f.webp",
    "MP_FireStorm": "https://cdn.gametools.network/maps/bf6/T_UI_Firestorm_Large_OPT-45d582ad.webp",
    "MP_Limestone": "https://cdn.gametools.network/maps/bf6/T_UI_Limestone_Large_OPT-c9160897.webp",
    "MP_Outskirts": "https://cdn.gametools.network/maps/bf6/T_UI_Outskirts_Large_OPT-bf08f756.webp",
    "MP_Tungsten": "https://cdn.gametools.network/maps/bf6/T_UI_Tungsten_Large_OPT-935da06b.webp",
    "MP_Contaminated": "https://cdn.gametools.network/maps/bf6/T_UI_Contaminated_Large_OPT-da1d04ef.webp",
    "MP_Portal_Sand": "https://cdn.gametools.network/maps/bf6/T_UI_Granite_Portal_07_Thumb_SML-b141ec28.jpg",
    "MP_Granite": "https://cdn.gametools.network/maps/bf6/Fort_Lyndon_BF6_REDSEC.webp",
    "MP_Granite_MainStreet_Portal": "https://cdn.gametools.network/maps/bf6/T_UI_Granite_Portal_01_Thumb_SML-c1924a54.jpg",
    "MP_Granite_Marina_Portal": "https://cdn.gametools.network/maps/bf6/T_UI_Granite_Portal_02_Thumb_SML-bacdb856.jpg",
    "MP_Granite_MilitaryRnD_Portal": "https://cdn.gametools.network/maps/bf6/T_UI_Granite_Portal_03_Thumb_SML-074dbb4f.jpg",
    "MP_Granite_MilitaryStorage_Portal": "https://cdn.gametools.network/maps/bf6/T_UI_Granite_Portal_04_Thumb_SML-e8d5744b.jpg",
    "MP_Granite_ClubHouse_Portal": "https://cdn.gametools.network/maps/bf6/T_UI_Granite_Portal_05_Thumb_SML-74ea7be7.webp",
    "MP_Granite_TechCampus_Portal": "https://cdn.gametools.network/maps/bf6/T_UI_Granite_Portal_06_Thumb_SML-80099ba6.webp",
}
SMALLMODES = {
    "Breakthrough0": "BT",
    "BreakthroughSmall0": "BS",
    "ConquestSmall0": "CQ",
    "ModBuilderCustom0": "CM",
    "Rush0": "RS",
    "Conquest0": "CL",
    "GraniteDuo0": "RD",
    "GraniteSquad0": "RQ",
    "GraniteGauntlet0": "RG",
}
MODES = {
    "Breakthrough0": "Breakthrough Large",
    "BreakthroughSmall0": "Breakthrough",
    "ConquestSmall0": "Conquest",
    "ModBuilderCustom0": "Custom",
    "Rush0": "Rush",
    "Conquest0": "Conquest large",
    "GraniteDuo0": "Redsec Duos",
    "GraniteSquad0": "Redsec Quads",
    "GraniteGauntlet0": "Redsec Gauntlet",
}
REDSEC_MODES = {
    "GraniteDuo0": "Duos",
    "GraniteSquad0": "Quads",
    "GraniteGauntlet0": "Gauntlet",
}
TO_GAME_MODES = {
    "breakthrough large": "Breakthrough0",
    "breakthrough": "BreakthroughSmall0",
    "conquest": "ConquestSmall0",
    "custom": "ModBuilderCustom0",
    "rush": "Rush0",
    "conquest large": "Conquest0",
    "redsec duos": "GraniteDuo0",
    "redsec quads": "GraniteSquad0",
    "redsec gauntlet": "GraniteGauntlet0",
}
STAT_MAPS = {
    "mpabbasid": {
        "mapName": "Siege of Cairo",
        "image": "https://cdn.gametools.network/maps/bf6/T_UI_Abbasid_Large_OPT-49a3761a.webp",
    },
    "mpaftermath": {
        "mapName": "Empire State",
        "image": "https://cdn.gametools.network/maps/bf6/T_UI_Aftermath_Large_OPT-bf883df1.webp",
    },
    "mpbattery": {
        "mapName": "Iberian Offensive",
        "image": "https://cdn.gametools.network/maps/bf6/T_UI_Battery_Large_OPT-034d4636.webp",
    },
    "mpcapstone": {
        "mapName": "Liberation Peak",
        "image": "https://cdn.gametools.network/maps/bf6/T_UI_Capstone_Large_OPT-2ccae694.webp",
    },
    "mpdumbo": {
        "mapName": "Manhattan Bridge",
        "image": "https://cdn.gametools.network/maps/bf6/T_UI_Dumbo_Large_OPT-20de031f.webp",
    },
    "mpfirestorm": {
        "mapName": "Operation Firestorm",
        "image": "https://cdn.gametools.network/maps/bf6/T_UI_Firestorm_Large_OPT-45d582ad.webp",
    },
    "mplimestone": {
        "mapName": "Saints Quarter",
        "image": "https://cdn.gametools.network/maps/bf6/T_UI_Limestone_Large_OPT-c9160897.webp",
    },
    "mpoutskirts": {
        "mapName": "New Sobek City",
        "image": "https://cdn.gametools.network/maps/bf6/T_UI_Outskirts_Large_OPT-bf08f756.webp",
    },
    "mptungsten": {
        "mapName": "Mirak Valley",
        "image": "https://cdn.gametools.network/maps/bf6/T_UI_Tungsten_Large_OPT-935da06b.webp",
    },
    "mpbadlands": {
        "mapName": "Blackwell Fields",
        "image": "https://cdn.gametools.network/maps/bf6/Battlefield_6_Blackwell_Fields.webp",
    },
    "ftpgranite": {
        "mapName": "REDSEC",
        "image": "https://cdn.gametools.network/maps/bf6/Battlefield_6_Redsec.webp",
    },
    "mpeastwood": {
        "mapName": "Eastwood",
        "image": "https://cdn.gametools.network/maps/bf6/T_UI_Eastwood_Large_OPT-3bfa6a6f.webp",
    },
    "mpcontaminated": {
        "mapName": "Contaminated",
        "image": "https://cdn.gametools.network/maps/bf6/T_UI_Contaminated_Large_OPT-da1d04ef.webp",
    },
}

STAT_GAMEMODE_SMALL = {
    "esc": {
        "gamemodeName": "Escalation",
        "image": "https://cdn.gametools.network/modes/bf6/escalation.svg",
        "altImage": "",
    },
    "tdm": {
        "gamemodeName": "Team deathmatch",
        "image": "https://cdn.gametools.network/modes/bf6/team_deathmatch.svg",
        "altImage": "",
    },
    "sdm": {
        "gamemodeName": "Squad deathmatch",
        "image": "https://cdn.gametools.network/modes/bf6/squad_deathmatch.svg",
        "altImage": "",
    },
    "dom": {
        "gamemodeName": "Domination",
        "image": "https://cdn.gametools.network/modes/bf6/domination.svg",
        "altImage": "",
    },
    "koth": {
        "gamemodeName": "King of the Hill",
        "image": "https://cdn.gametools.network/modes/bf6/king_of_the_hill.svg",
        "altImage": "",
    },
    "cq": {
        "gamemodeName": "Conquest",
        "image": "https://cdn.gametools.network/modes/bf6/conquest.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/conquest-framed.svg",
    },
    "graniteDuo": {
        "gamemodeName": "Redsec Duo",
        "image": "https://cdn.gametools.network/modes/bf6/battle_royale.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/battle_royale-framed.svg",
    },
    "brsquad": {
        "gamemodeName": "Redsec Squad",
        "image": "https://cdn.gametools.network/modes/bf6/battle_royale.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/battle_royale-framed.svg",
    },
    "rush": {
        "gamemodeName": "Rush",
        "image": "https://cdn.gametools.network/modes/bf6/rush.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/rush-framed.svg",
    },
    "bt": {
        "gamemodeName": "Breakthrough",
        "image": "https://cdn.gametools.network/modes/bf6/breakthrough.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/breakthrough-framed.svg",
    },
    "gntgauntlet": {
        "gamemodeName": "Gauntlet",
        "image": "https://cdn.gametools.network/modes/bf6/gauntlet.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/gauntlet-framed.svg",
    },
    "modbuilder0": {
        "gamemodeName": "Portal",
        "image": "https://cdn.gametools.network/modes/bf6/wrench-hammer.svg",
        "altImage": "",
    },
    "strike": {
        "gamemodeName": "Strikepoint",
        "image": "https://cdn.gametools.network/modes/bf6/strikepoint.svg",
        "altImage": "",
    },
    "official": {"gamemodeName": "Official", "image": "", "altImage": ""},
}
STAT_GAMEMODE_SMALL_CATEGORY = {
    "all": {"gamemodeName": "All", "image": "", "altImage": ""},
    "mp": {"gamemodeName": "Multiplayer", "image": "", "altImage": ""},
    "modbuilder": {
        "gamemodeName": "Portal",
        "image": "https://cdn.gametools.network/modes/bf6/wrench-hammer.svg",
        "altImage": "",
    },
    "granite": {
        "gamemodeName": "Redsec",
        "image": "https://cdn.gametools.network/modes/bf6/battle_royale.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/battle_royale-framed.svg",
    },
    "granitebr": {
        "gamemodeName": "Battle Royale",
        "image": "https://cdn.gametools.network/modes/bf6/battle_royale.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/battle_royale-framed.svg",
    },
}
STAT_GAMEMODE = {
    "MP_Escalation0": {
        "gamemodeName": "Escalation",
        "image": "https://cdn.gametools.network/modes/bf6/escalation.svg",
        "altImage": "",
    },
    "MP_TeamDM0": {
        "gamemodeName": "Team deathmatch",
        "image": "https://cdn.gametools.network/modes/bf6/team_deathmatch.svg",
        "altImage": "",
    },
    "GraniteGauntlet0": {
        "gamemodeName": "Gauntlet",
        "image": "https://cdn.gametools.network/modes/bf6/gauntlet.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/gauntlet-framed.svg",
    },
    "GraniteSquad0": {
        "gamemodeName": "Redsec Squad",
        "image": "https://cdn.gametools.network/modes/bf6/battle_royale.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/battle_royale-framed.svg",
    },
    "MP_KOTH0": {
        "gamemodeName": "King of the Hill",
        "image": "https://cdn.gametools.network/modes/bf6/king_of_the_hill.svg",
        "altImage": "",
    },
    "GraniteDuo0": {
        "gamemodeName": "Redsec Duo",
        "image": "https://cdn.gametools.network/modes/bf6/battle_royale.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/battle_royale-framed.svg",
    },
    "MP_Domination0": {
        "gamemodeName": "Domination",
        "image": "https://cdn.gametools.network/modes/bf6/domination.svg",
        "altImage": "",
    },
    "Conquest0": {
        "gamemodeName": "Conquest",
        "image": "https://cdn.gametools.network/modes/bf6/conquest.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/conquest-framed.svg",
    },
    "MP_SquadDM0": {
        "gamemodeName": "Squad deathmatch",
        "image": "https://cdn.gametools.network/modes/bf6/squad_deathmatch.svg",
        "altImage": "",
    },
    "Breakthrough0": {
        "gamemodeName": "Breakthrough",
        "image": "https://cdn.gametools.network/modes/bf6/breakthrough.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/breakthrough-framed.svg",
    },
    "Rush0": {
        "gamemodeName": "Rush",
        "image": "https://cdn.gametools.network/modes/bf6/rush.svg",
        "altImage": "https://cdn.gametools.network/modes/bf6/rush-framed.svg",
    },
    "ModBuilderCustom0": {
        "gamemodeName": "Portal",
        "image": "https://cdn.gametools.network/modes/bf6/wrench-hammer.svg",
        "altImage": "",
    },
}
CLASSES = {
    "assault": {
        "className": "Assault",
        "image": "https://cdn.gametools.network/classes/bf6/white/Assault.svg",
        "altImage": "https://cdn.gametools.network/classes/bf6/black/Assault.svg",
    },
    "engineer": {
        "className": "Engineer",
        "image": "https://cdn.gametools.network/classes/bf6/white/Engineer.svg",
        "altImage": "https://cdn.gametools.network/classes/bf6/black/Engineer.svg",
    },
    "support": {
        "className": "Support",
        "image": "https://cdn.gametools.network/classes/bf6/white/Support.svg",
        "altImage": "https://cdn.gametools.network/classes/bf6/black/Support.svg",
    },
    "recon": {
        "className": "Recon",
        "image": "https://cdn.gametools.network/classes/bf6/white/Recon.svg",
        "altImage": "https://cdn.gametools.network/classes/bf6/black/Recon.svg",
    },
}
VEHICLES = {
    "air_panthera": {
        "type": "Air Combat",
        "vehicleName": "Panthera KHT",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_MDV_Eurocopter_VSD0001-8003028d.webp",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_MDV_Eurocopter_VSD0001-8003028d.webp",
    },
    "air_m77efalchio": {
        "type": "Air Combat",
        "vehicleName": "M77E Falchion",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_MDV_AH64E_VSD0001-dd0a7df6.webp",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_MDV_AH64E_VSD0001-dd0a7df6.webp",
    },
    "sur_leoa4": {
        "type": "Ground Combat",
        "vehicleName": "Leo A4",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_MDV_Leopard_VSD0001-f8da51ee.webp",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_MDV_Leopard_VSD0001-f8da51ee.webp",
    },
    "sur_strf09a4": {
        "type": "Ground Combat",
        "vehicleName": "Strf 09 A4",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_CV90_VSD0001-acd942b6.webp",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_CV90_VSD0001-acd942b6.webp",
    },
    "sur_m1a2sepv3": {
        "type": "Ground Combat",
        "vehicleName": "M1A2 SEPv3",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_MDV_Abrams_VSD0001-5412a78d.webp",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_MDV_Abrams_VSD0001-5412a78d.webp",
    },
    "sur_cheetah1a2": {
        "type": "Ground Combat",
        "vehicleName": "Cheetah 1A2",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_MDV_Gepard_VSD0001-d796732f.webp",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_MDV_Gepard_VSD0001-d796732f.webp",
    },
    "sur_glider96": {
        "type": "Ground Combat",
        "vehicleName": "Glider 96",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_MDV_Flyer60_VSD0005-1569869f.webp",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_MDV_Flyer60_VSD0005-1569869f.webp",
    },
    "sur_bradley": {
        "type": "Ground Combat",
        "vehicleName": "M3A3 Bradley",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_OB_VEH_Tank_Bradley_VSD0001_Dressing-66f252ca.webp",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_OB_VEH_Tank_Bradley_VSD0001_Dressing-66f252ca.webp",
    },
    "air_su57": {
        "type": "Air Combat",
        "vehicleName": "Su-57",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_MDV_SU57_VSD0001-1b5aa5ee.webp",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_MDV_SU57_VSD0001-1b5aa5ee.webp",
    },
    "air_f61v": {
        "type": "Air Combat",
        "vehicleName": "F-61V",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_MDV_F16_VSD0001-5f951ec9.webp",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_MDV_F16_VSD0001-5f951ec9.webp",
    },
    "air_f39e": {
        "type": "Air Combat",
        "vehicleName": "F-39E",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_MDV_JAS39_VSD0001-9313d717.webp",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_MDV_JAS39_VSD0001-9313d717.webp",
    },
    "air_m77efalchion": {
        "type": "Air Combat",
        "vehicleName": "M77E Falchion",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_MDV_AH64E_VSD0001-dd0a7df6.webp",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_MDV_AH64E_VSD0001-dd0a7df6.webp",
    },
    "sur_vector": {
        "type": "Ground Transport",
        "vehicleName": "VECTOR",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_MDV_Vector_VSD0002-241efa80.webp",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_MDV_Vector_VSD0002-241efa80.webp",
    },
    "sur_travmark2": {
        "type": "Ground Transport",
        "vehicleName": "Traverser Mark 2",
        "image": "https://cdn.gametools.network/vehicles/bf6/T_UI_Marauder_VSD0001_Icon_25667539-c29e2338.png",
        "altImage": "https://cdn.gametools.network/vehicles/bf6/white/T_UI_Marauder_VSD0001_Icon_25667539-c29e2338.png",
    },
    "air_uh06": {"type": "Air Transport", "vehicleName": "UH-06", "image": ""},
    "air_mh47": {"type": "Air Transport", "vehicleName": "MH47 Chinook", "image": ""},
    "air_f97kes": {"type": "Air Combat", "vehicleName": "F-97 Kestrel", "image": ""},
    "sur_rhib": {
        "type": "Ground Transport",
        "vehicleName": "7.7m NSW RBHIB",
        "image": "",
    },
    "sur_ptv": {
        "type": "Ground Transport",
        "vehicleName": "Turfpro PTV Royal",
        "image": "",
    },
    "sur_quadbike": {
        "type": "Ground Transport",
        "vehicleName": "Rugged MV740",
        "image": "https://cdn.gametools.network/vehicles/bf6/U_VEH_Car_QuadBike-f25eae5e.webp",
    },
    "air_ah6litbird": {
        "type": "Air Combat",
        "vehicleName": "AH-6 Little Bird",
        "image": "",  # wrong image
    },
}
VEHICLE_GROUPS = {
    "air": {"groupName": "Air Combat"},
    "sur": {"groupName": "Ground Combat"},
}
WEAPONS = {
    "mg_l110": {
        "type": "Machine Guns",
        "weaponName": "L110",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_Minimi_PKG_Factory_MED-0e29fce7.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_Minimi_PKG_Factory_MED-0e29fce7.webp",
    },
    "smg_pw5a3": {
        "type": "SMG-PDWs",
        "weaponName": "PW5A3",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_MP5MLI_PKG_Factory_MED-2d1944b7.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_MP5MLI_PKG_Factory_MED-2d1944b7.webp",
    },
    "ar_m433": {
        "type": "Assault Rifles",
        "weaponName": "M433",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_HK433_PKG_Factory_MED-b06f02f7.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_HK433_PKG_Factory_MED-b06f02f7.webp",
    },
    "mg_rpkm": {
        "type": "Machine Guns",
        "weaponName": "RPKM",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_RPKM_PKG_Factory_MED-755b785f.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_RPKM_PKG_Factory_MED-755b785f.webp",
    },
    "sg_m87a1": {
        "type": "Shotguns",
        "weaponName": "M87A1",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_590A1_PKG_Factory_MED-4b387330.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_590A1_PKG_Factory_MED-4b387330.webp",
    },
    "pst_p18": {
        "type": "Pistols",
        "weaponName": "P18",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_M18_PKG_Factory_MED-88261bf8.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_M18_PKG_Factory_MED-88261bf8.webp",
    },
    "crb_x277": {
        "type": "Carbines",
        "weaponName": "M277",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_XM7_PKG_Factory_MED-26271094.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_XM7_PKG_Factory_MED-26271094.webp",
    },
    "ar_b36a4": {
        "type": "Assault Rifles",
        "weaponName": "B36A4",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_G36_PKG_Factory_MED-fb5466ec.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_G36_PKG_Factory_MED-fb5466ec.webp",
    },
    "ar_l85a3": {
        "type": "Assault Rifles",
        "weaponName": "L85A3",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_L85A3_PKG_Factory_MED-9bd0deaa.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_L85A3_PKG_Factory_MED-9bd0deaa.webp",
    },
    "snp_m2010": {
        "type": "Rifles",
        "weaponName": "M2010 ESR",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_M2010ESR_PKG_Factory_MED-f94fdae6.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_M2010ESR_PKG_Factory_MED-f94fdae6.webp",
    },
    "sg_m1014": {
        "type": "Shotguns",
        "weaponName": "M1014",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_M1014_PKG_Factory_MED-e011854a.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_M1014_PKG_Factory_MED-e011854a.webp",
    },
    "crb_ak205": {
        "type": "Carbines",
        "weaponName": "AK-205",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_AK205_PKG_Factory_MED-6d376081.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_AK205_PKG_Factory_MED-6d376081.webp",
    },
    "dmr_svk86": {
        "type": "DMRs",
        "weaponName": "SVK-8.6",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_SVCh_PKG_Factory_MED-bb06d385.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_SVCh_PKG_Factory_MED-bb06d385.webp",
    },
    "smg_sgx": {
        "type": "SMG-PDWs",
        "weaponName": "SGX",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_MPX_PKG_Factory_MED-e822f017.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_MPX_PKG_Factory_MED-e822f017.webp",
    },
    "dmr_lmr27": {
        "type": "DMRs",
        "weaponName": "LMR27",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_ARADMR_PKG_Factory_MED-dfe224de.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_ARADMR_PKG_Factory_MED-dfe224de.webp",
    },
    "crb_qbz192": {
        "type": "Carbines",
        "weaponName": "QBZ-192",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_QBZ192_PKG_Factory_MED-dc0a546b.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_QBZ192_PKG_Factory_MED-dc0a546b.webp",
    },
    "crb_m417a2": {
        "type": "Carbines",
        "weaponName": "M417 A2",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_HK417A2_PKG_Factory_MED-494ffe6e.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_HK417A2_PKG_Factory_MED-494ffe6e.webp",
    },
    "mg_drsiar": {
        "type": "Machine Guns",
        "weaponName": "DRS-IAR",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_M27IAR_PKG_Factory_MED-ae6675cd.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_M27IAR_PKG_Factory_MED-ae6675cd.webp",
    },
    "ar_kord6p67": {
        "type": "Assault Rifles",
        "weaponName": "KORD 6P67",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_6P67_PKG_Factory_MED-827b9414.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_6P67_PKG_Factory_MED-827b9414.webp",
    },
    "smg_usg90": {
        "type": "SMG-PDWs",
        "weaponName": "USG-90",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_P90_PKG_Factory_MED-2ab1db64.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_P90_PKG_Factory_MED-2ab1db64.webp",
    },
    "crb_m4a1": {
        "type": "Carbines",
        "weaponName": "M4A1",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_M4A1_PKG_Factory_MED-34529a82.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_M4A1_PKG_Factory_MED-34529a82.webp",
    },
    "mg_kts100mk8": {
        "type": "Machine Guns",
        "weaponName": "KTS100 MK8",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_Ultimax_PKG_Factory_MED-a8ebb482.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_Ultimax_PKG_Factory_MED-a8ebb482.webp",
    },
    "pst_m45a1": {
        "type": "Pistols",
        "weaponName": "M45A1",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_M45A1_PKG_Factory_MED-8c41691b.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_M45A1_PKG_Factory_MED-8c41691b.webp",
    },
    "smg_kv9": {
        "type": "SMG-PDWs",
        "weaponName": "KV9",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_Vector_PKG_Factory_MED-b5631ed7.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_Vector_PKG_Factory_MED-b5631ed7.webp",
    },
    "ar_sor556mk2": {
        "type": "Assault Rifles",
        "weaponName": "SOR-556 Mk2",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_SCARL_PKG_Factory_MED-b44467bb.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_SCARL_PKG_Factory_MED-b44467bb.webp",
    },
    "smg_pw7a2": {
        "type": "SMG-PDWs",
        "weaponName": "PW7A2",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_MP7A2_PKG_Factory_MED-406bc965.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_MP7A2_PKG_Factory_MED-406bc965.webp",
    },
    "mg_m123k": {
        "type": "Machine Guns",
        "weaponName": "M123K",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_MG4K_PKG_Factory_MED-cc064690.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_MG4K_PKG_Factory_MED-cc064690.webp",
    },
    "pst_m44": {
        "type": "Pistols",
        "weaponName": "M44",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_RagingHunter_PKG_Factory_MED-f9773307.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_RagingHunter_PKG_Factory_MED-f9773307.webp",
    },
    "mg_xm250": {
        "type": "Machine Guns",
        "weaponName": "M250",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_M250_PKG_Factory_MED-6e230a71.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_M250_PKG_Factory_MED-6e230a71.webp",
    },
    "smg_umg40": {
        "type": "SMG-PDWs",
        "weaponName": "UMG-40",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_UMP40_PKG_Factory_MED-22afa646.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_UMP40_PKG_Factory_MED-22afa646.webp",
    },
    "ar_tr7": {
        "type": "Assault Rifles",
        "weaponName": "TR-7",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_Tavor7_PKG_Factory_MED-e682f267.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_Tavor7_PKG_Factory_MED-e682f267.webp",
    },
    "smg_sl9": {
        "type": "SMG-PDWs",
        "weaponName": "SL9",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_APDW_PKG_Factory_MED-c4d1b829.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_APDW_PKG_Factory_MED-c4d1b829.webp",
    },
    "mg_m240l": {
        "type": "Machine Guns",
        "weaponName": "M240L",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_M240L_PKG_Factory_MED-1fa18e0c.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_M240L_PKG_Factory_MED-1fa18e0c.webp",
    },
    "smg_scw10": {
        "type": "SMG-PDWs",
        "weaponName": "SCW-10",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_APC10_PKG_Factory_MED-716a97fb.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_APC10_PKG_Factory_MED-716a97fb.webp",
    },
    "ar_nvo228e": {
        "type": "Assault Rifles",
        "weaponName": "NVO-228E",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_ACE32_PKG_Factory_MED-39a97220.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_ACE32_PKG_Factory_MED-39a97220.webp",
    },
    "mg_m60": {
        "type": "Machine Guns",
        "weaponName": "M/60",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_M60E6_PKG_Factory_MED-e600bb28.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_M60E6_PKG_Factory_MED-e600bb28.webp",
    },
    "snp_psr": {
        "type": "Rifles",
        "weaponName": "PSR",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_MRAD_PKG_Factory_MED-5035ce99.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_MRAD_PKG_Factory_MED-5035ce99.webp",
    },
    "dmr_svdm": {
        "type": "DMRs",
        "weaponName": "SVDM",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_SVDM_PKG_Factory_MED-b6c9aa50.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_SVDM_PKG_Factory_MED-b6c9aa50.webp",
    },
    "ar_ak4d": {
        "type": "Assault Rifles",
        "weaponName": "AK4D",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_G3A4_PKG_Factory_MED-0575cf00.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_G3A4_PKG_Factory_MED-0575cf00.webp",
    },
    "crb_sor300sc": {
        "type": "Carbines",
        "weaponName": "SOR-300SC",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_SCARSC_PKG_Factory_MED-7a6a50ff.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_SCARSC_PKG_Factory_MED-7a6a50ff.webp",
    },
    "crb_sg553r": {
        "type": "Carbines",
        "weaponName": "SG 553R",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_SIG553R_PKG_Factory_MED-afc2dfa8.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_SIG553R_PKG_Factory_MED-afc2dfa8.webp",
    },
    "crb_grtbc": {
        "type": "Carbines",
        "weaponName": "GRT-BC",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_MSBSGROTB_PKG_Factory_MED-25acf006.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_MSBSGROTB_PKG_Factory_MED-25acf006.webp",
    },
    "sg_185ksk": {
        "type": "Shotguns",
        "weaponName": "18.5KS-K",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_185KSK_PKG_Factory_MED-432c353f.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_MSBSGROTB_PKG_Factory_MED-25acf006.webp",
    },
    "pst_es57": {
        "type": "Pistols",
        "weaponName": "ES 5.7",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_FiveSeven_PKG_Factory_MED-c540cde7.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_FiveSeven_PKG_Factory_MED-c540cde7.webp",
    },
    "dmr_m39emr": {
        "type": "DMRs",
        "weaponName": "M39 EMR",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_M39EMR_PKG_Factory_MED-e17b5963.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_M39EMR_PKG_Factory_MED-e17b5963.webp",
    },
    "snp_sv98": {
        "type": "Rifles",
        "weaponName": "SV-98",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_SV98M_PKG_Factory_MED-c38f085a.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_SV98M_PKG_Factory_MED-c38f085a.webp",
    },
    "pst_m357trait": {
        "type": "Pistols",
        "weaponName": "M357 Trait",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_TRR8_PKG_Factory_MED-815434c3.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_TRR8_PKG_Factory_MED-815434c3.webp",
    },
    "pst_ggh22": {
        "type": "Pistols",
        "weaponName": "GGH-22",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_G22_PKG_Factory_MED-0faaf1e3.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_G22_PKG_Factory_MED-0faaf1e3.webp",
    },
    "snp_miniscout": {
        "type": "Rifles",
        "weaponName": "Mini Scout",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_MiniFix_PKG_Factory_MED-c8bab5ff.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_MiniFix_PKG_Factory_MED-c8bab5ff.webp",
    },
    "sg_db12": {
        "type": "Shotguns",
        "weaponName": "DB-12",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_DP12_PKG_Factory_MED-0335554d.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_DP12_PKG_Factory_MED-0335554d.webp",
    },
    "ar_vhsk2": {
        "type": "Assault Rifles",
        "weaponName": "VCR-2",
        "image": "https://cdn.gametools.network/weapons/bf6/T_UI_HK433_PKG_Factory_MED-39181b6c.webp",
        "altImage": "https://cdn.gametools.network/weapons/bf6/white/T_UI_HK433_PKG_Factory_MED-39181b6c.webp",
    },
    "dmr_msbsgrotc": {
        "type": "DMRs",
        "weaponName": "GRT-CPS",
        "image": "",
    },
    "mg_mg525btk": {
        "type": "Machine Guns",
        "weaponName": "M121 A2",
        "image": "",
    },
}
WEAPON_GROUPS = {
    "snp": {"groupName": "Rifles"},
    "crb": {"groupName": "Carbines"},
    "mg": {"groupName": "Machine Guns"},
    "sg": {"groupName": "Shotguns"},
    "ar": {"groupName": "Assault Rifles"},
    "smg": {"groupName": "SMG-PDWs"},
    "dmr": {"groupName": "DMRs"},
}
GADGETS = {
    "callin_airstrike": {
        "type": "Strike Packages",
        "gadgetName": "Air Strike",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_CALLINS_Airstrike_Thumb-638b4ee1.png",
    },
    "mpaps": {
        "type": "Deployable Gadgets",
        "gadgetName": "MP-APS",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_MPAPS_Icon-b735994d.png",
    },
    "gpdis": {
        "type": "Deployable Gadgets",
        "gadgetName": "GPDIS",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_EIDOS_Icon-2273a3ee.png",
    },
    "c4": {
        "type": "Explosives",
        "gadgetName": "C-4 Explosives",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_C4_Icon-330d6ee2.png",
    },
    "gl_he": {
        "type": "Grenade Launchers",
        "gadgetName": "M320A1 HE",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_M320_HE_Icon-83b61ed0.png",
    },
    "rl_ungui": {
        "type": "Launchers",
        "gadgetName": "RPG-7V2",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_RPG7v2_Icon-ce5453fd.png",
    },
    "rl_aimgui": {
        "type": "Launchers",
        "gadgetName": "M136 AT",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_AT4_Icon-beadb575.png",
    },
    "gren_frag": {
        "type": "Grenade",
        "gadgetName": "Frag Grenade",
        "image": "",
    },
    "mine_press": {
        "type": "Explosives",
        "gadgetName": "M15",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_AT_Mine_Icon-2288ec8e.png",
    },
    "gl_tb": {
        "type": "Grenade Launchers",
        "gadgetName": "M320A1 THRM",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_M320_Thermobaric_Icon-3f13c762.png",
    },
    "repair": {
        "type": "",
        "gadgetName": "Repair Tool",
        "image": "",
    },
    "gren_inc": {
        "type": "Grenade",
        "gadgetName": "Incendiary Grenade",
        "image": "",
    },
    "ladder": {
        "type": "",
        "gadgetName": "Assault Ladder",
        "image": "",
    },
    "sup_bag": {
        "type": "",
        "gadgetName": "Supply Bag",
        "image": "",
    },
    "deplocover": {
        "type": "",
        "gadgetName": "Deployable Cover",
        "image": "",
    },
    "gren_stun": {
        "type": "",
        "gadgetName": "Stun Grenade",
        "image": "",
    },
    "gren_smoke": {
        "type": "",
        "gadgetName": "Smoke Grenade",
        "image": "",
    },
    "gren_flash": {
        "type": "",
        "gadgetName": "Flash Grenade",
        "image": "",
    },
    "recondrone": {
        "type": "",
        "gadgetName": "Recon Drone",
        "image": "",
    },
    "laserdes": {
        "type": "",
        "gadgetName": "Laser Designator",
        "image": "",
    },
    "tugs": {
        "type": "",
        "gadgetName": "Motion Sensor",
        "image": "",
    },
    "rl_longra": {
        "type": "Launchers",
        "gadgetName": "MAS 148 Glaive",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_Javelin_Icon-a0ce2091.png",
    },
    "mine_ap": {
        "type": "Explosives",
        "gadgetName": "M18A1",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_Claymore_Icon-5c7f1590.png",
    },
    "adren": {
        "type": "",
        "gadgetName": "Adrenaline Injector",
        "image": "",
    },
    "mine_tws": {
        "type": "Explosives",
        "gadgetName": "M4A1 Slam",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_M4_SLAM_Icon-541f624c.png",
    },
    "eodbot": {
        "type": "",
        "gadgetName": "EOD Bot",
        "image": "",
    },
    "gl_breach": {
        "type": "Grenade Launchers",
        "gadgetName": "X95 BRE",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_Drill_Launcher_Icon-1e1481d9.png",
    },
    "mine_mosen": {
        "type": "Explosives",
        "gadgetName": "PTKM-1R",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_PTKM_1R_Icon-ceb07fc0.png",
    },
    "gren_mfrag": {
        "type": "",
        "gadgetName": "Mini Grenade",
        "image": "",
    },
    "rl_surtoair": {
        "type": "Launchers",
        "gadgetName": "SLM-93A",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_Stinger_Icon-d4590623.png",
    },
    "il_airburst": {
        "type": "Grenade Launchers",
        "gadgetName": "SICH G1 WP",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_Airburst_Incendiary_Launcher_Icon-da8af82a.png",
    },
    "vehsupcra": {
        "type": "",
        "gadgetName": "Supply Crate",
        "image": "",
    },
    "tknife": {
        "type": "",
        "gadgetName": "Throwing Knife",
        "image": "",
    },
    "msensor": {
        "type": "",
        "gadgetName": "Proximity Detector",
        "image": "",
    },
    "deployable": {
        "type": "",
        "gadgetName": "Deployable Cover",
        "image": "",
    },
    "deploymortar": {
        "type": "Class Gadgets",
        "gadgetName": "LWCMS",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_Deployable_Mortar_Icon-97b13652.png",
    },
    "deploybeacon": {
        "type": "Deployable Gadgets",
        "gadgetName": "QLINK 6",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_Spawn_Beacon_Icon-b6e67f1c.png",
    },
    "decoy": {
        "type": "",
        "gadgetName": "Sniper Decoy",
        "image": "",
    },
    "gl_smoke": {
        "type": "Grenade Launchers",
        "gadgetName": "M320A1 SMK",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_M320_Smoke_Icon-dfa762d9.png",
    },
    "callin_wpdrop": {
        "type": "Strike Packages",
        "gadgetName": "Weapon Drop",
        "image": "https://cdn.gametools.network/gadgets/bf6/U_Gadget_WeaponDrop_Granite-2c6c3b16.webp",
    },
    "callin_uav": {
        "type": "Strike Packages",
        "gadgetName": "UAV Overwatch",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_CALLINS_Uav_Thumb-fdf9a78e.png",
    },
    "callin_resupply": {
        "type": "Strike Packages",
        "gadgetName": "",
        "image": "",
    },
    "callin_antiveh": {
        "type": "Strike Packages",
        "gadgetName": "Anti-Vehicle Drop",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_CALLINS_SupAnti_Thumb-84fc98fc.png",
    },
    "callin_smoke": {
        "type": "Strike Packages",
        "gadgetName": "Smoke Screen",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_CALLINS_Smoke_Thumb-5d515d26.png",
    },
    "callin_artstrike": {
        "type": "Strike Packages",
        "gadgetName": "Artillery Strike",
        "image": "https://cdn.gametools.network/gadgets/bf6/T_UI_CALLINS_Artillery_Thumb-126cad71.png",
    },
    "rl_igla": {
        "type": "Class Gadgets",
        "gadgetName": "9K38 Igla",
        "image": "",
    },
    "gasmask": {
        "type": "",
        "gadgetName": "Gas mask",
        "image": "",
    },
}

GADGET_GROUPS = {
    "gl": {"groupName": "Grenade Launchers"},
    "mine": {"groupName": "Explosives"},
    "grenades": {"groupName": "Grenades"},
    "rl": {"groupName": "Launchers"},
    "il": {"groupName": "Grenade Launchers"},
    "callins": {"groupName": "Call-ins"},
}

RANK_IMAGES = {
    1: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_001_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_001_lg.png",
    },
    2: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_002_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_002_lg.png",
    },
    3: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_003_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_003_lg.png",
    },
    4: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_004_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_004_lg.png",
    },
    5: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_005_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_005_lg.png",
    },
    6: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_006_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_006_lg.png",
    },
    7: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_007_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_007_lg.png",
    },
    8: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_008_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_008_lg.png",
    },
    9: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_009_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_009_lg.png",
    },
    10: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_010_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_010_lg.png",
    },
    11: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_011_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_011_lg.png",
    },
    12: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_012_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_012_lg.png",
    },
    13: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_013_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_013_lg.png",
    },
    14: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_014_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_014_lg.png",
    },
    15: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_015_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_015_lg.png",
    },
    16: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_016_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_016_lg.png",
    },
    17: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_017_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_017_lg.png",
    },
    18: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_018_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_018_lg.png",
    },
    19: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_019_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_019_lg.png",
    },
    20: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_020_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_020_lg.png",
    },
    21: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_021_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_021_lg.png",
    },
    22: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_022_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_022_lg.png",
    },
    23: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_023_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_023_lg.png",
    },
    24: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_024_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_024_lg.png",
    },
    25: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_025_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_025_lg.png",
    },
    26: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_026_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_026_lg.png",
    },
    27: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_027_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_027_lg.png",
    },
    28: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_028_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_028_lg.png",
    },
    29: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_029_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_029_lg.png",
    },
    30: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_030_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_030_lg.png",
    },
    31: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_031_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_031_lg.png",
    },
    32: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_032_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_032_lg.png",
    },
    33: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_033_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_033_lg.png",
    },
    34: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_034_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_034_lg.png",
    },
    35: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_035_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_035_lg.png",
    },
    36: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_036_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_036_lg.png",
    },
    37: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_037_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_037_lg.png",
    },
    38: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_038_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_038_lg.png",
    },
    39: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_039_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_039_lg.png",
    },
    40: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_040_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_040_lg.png",
    },
    41: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_041_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_041_lg.png",
    },
    42: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_042_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_042_lg.png",
    },
    43: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_043_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_043_lg.png",
    },
    44: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_044_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_044_lg.png",
    },
    45: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_045_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_045_lg.png",
    },
    46: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_046_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_046_lg.png",
    },
    47: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_047_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_047_lg.png",
    },
    48: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_048_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_048_lg.png",
    },
    49: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_049_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_049_lg.png",
    },
    50: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_050_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_050_lg.png",
    },
    55: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_055_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_055_lg.png",
    },
    60: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_060_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_060_lg.png",
    },
    65: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_065_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_065_lg.png",
    },
    70: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_070_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_070_lg.png",
    },
    75: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_075_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_075_lg.png",
    },
    80: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_080_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_080_lg.png",
    },
    85: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_085_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_085_lg.png",
    },
    90: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_090_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_090_lg.png",
    },
    95: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_095_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_095_lg.png",
    },
    100: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_100_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_100_lg.png",
    },
    110: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_110_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_110_lg.png",
    },
    120: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_120_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_120_lg.png",
    },
    130: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_130_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_130_lg.png",
    },
    140: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_140_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_140_lg.png",
    },
    150: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_150_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_150_lg.png",
    },
    160: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_160_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_160_lg.png",
    },
    170: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_170_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_170_lg.png",
    },
    180: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_180_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_180_lg.png",
    },
    190: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_190_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_190_lg.png",
    },
    200: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_200_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_200_lg.png",
    },
    210: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_210_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_210_lg.png",
    },
    220: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_220_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_220_lg.png",
    },
    230: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_230_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_230_lg.png",
    },
    240: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_240_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_240_lg.png",
    },
    250: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_250_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_250_lg.png",
    },
    260: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_260_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_260_lg.png",
    },
    270: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_270_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_270_lg.png",
    },
    280: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_280_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_280_lg.png",
    },
    290: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_290_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_290_lg.png",
    },
    300: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_300_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_300_lg.png",
    },
    310: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_310_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_310_lg.png",
    },
    320: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_320_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_320_lg.png",
    },
    330: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_330_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_330_lg.png",
    },
    340: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_340_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_340_lg.png",
    },
    350: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_350_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_350_lg.png",
    },
    360: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_360_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_360_lg.png",
    },
    370: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_370_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_370_lg.png",
    },
    380: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_380_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_380_lg.png",
    },
    390: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_390_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_390_lg.png",
    },
    400: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_400_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_400_lg.png",
    },
    410: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_410_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_410_lg.png",
    },
    420: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_420_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_420_lg.png",
    },
    430: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_430_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_430_lg.png",
    },
    440: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_440_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_440_lg.png",
    },
    450: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_450_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_450_lg.png",
    },
    460: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_460_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_460_lg.png",
    },
    470: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_470_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_470_lg.png",
    },
    480: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_480_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_480_lg.png",
    },
    490: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_490_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_490_lg.png",
    },
    500: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_500_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_500_lg.png",
    },
    1000: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_1000_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_1000_lg.png",
    },
    1500: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_1500_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_1500_lg.png",
    },
    2000: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_2000_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_2000_lg.png",
    },
    2500: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_2500_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_2500_lg.png",
    },
    3000: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_3000_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_3000_lg.png",
    },
    3500: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_3500_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_3500_lg.png",
    },
    4000: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_4000_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_4000_lg.png",
    },
    4500: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_4500_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_4500_lg.png",
    },
    5000: {
        "small": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_5000_sm.png",
        "large": "https://cdn.gametools.network/ranks/bf6/t_ui_rank_5000_lg.png",
    },
}
