nested_large_key = r"""
{
  "jkra": [
    154,
    4472,
    [
      8567,
      false,
      363.84,
      5276,
      "ha",
      "rizkzs",
      93
    ],
    false
  ],
  "hh": 20.77,
  "mr": 973.217,
  "ihbe": [
    68,
    [
      true,
      {
        "lqe": [
          486.363,
          [
            true,
            {
              "mp": {
                "ory": "rj",
                "qnl": "tyfrju",
                "hf": None
              },
              "uooc": 7418,
              "xela": 20,
              "bt": 7014,
              "ia": 547,
              "szec": 68.73
            },
            None
          ],
          3622,
          "iwk",
          None
        ],
        "fepi": 19.954,
        "ivu": {
          "rmnd": 65.539,
          "bk": 98,
          "nc": "bdg",
          "dlb": {
            "hw": {
              "upzz": [
                true,
                {
                  "nwb": [
                    4259.47
                  ],
                  "nbt": "yl"
                },
                false,
                false,
                65,
                [
                  [
                    [],
                    629.149,
                    "lvynqh",
                    "hsk",
                    [],
                    2011.932,
                    true,
                    []
                  ],
                  None,
                  "ymbc",
                  None
                ],
                "aj",
                97.425,
                "hc",
                58
              ]
            },
            "jq": true,
            "bi": 3333,
            "hmf": "pl",
            "mrbj": [
              true,
              false
            ]
          }
        },
        "hfj": "lwk",
        "utdl": "aku",
        "alqb": [
          74,
          534.389,
          7235,
          [
            None,
            false,
            None
          ]
        ]
      },
      None,
      {
        "lbrx": {
          "vm": "ubdrbb"
        },
        "tie": "iok",
        "br": "ojro"
      },
      70.558,
      [
        {
          "mmo": None,
          "dryu": None
        }
      ]
    ],
    true,
    None,
    false,
    {
      "jqun": 98,
      "ivhq": [
        [
          [
            675.936,
            [
              520.15,
              1587.4,
              false
            ],
            "jt",
            true,
            {
              "bn": None,
              "ygn": "cve",
              "zhh": true,
              "aak": 9165,
              "skx": true,
              "qqsk": 662.28
            },
            {
              "eio": 9933.6,
              "agl": None,
              "pf": false,
              "kv": 5099.631,
              "no": None,
              "shly": 58
            },
            [
              None,
              [
                "uiundu",
                726.652,
                false,
                94.92,
                259.62,
                {
                  "ntqu": None,
                  "frv": None,
                  "rvop": "upefj",
                  "jvdp": {
                    "nhx": [],
                    "bxnu": {},
                    "gs": None,
                    "mqho": None,
                    "xp": 65,
                    "ujj": {}
                  },
                  "ts": false,
                  "kyuk": [
                    false,
                    58,
                    {},
                    "khqqif"
                  ]
                },
                167,
                true,
                "bhlej",
                53
              ],
              64,
              {
                "eans": "wgzfo",
                "zfgb": 431.67,
                "udy": [
                  {
                    "gnt": [],
                    "zeve": {}
                  },
                  {
                    "pg": {},
                    "vsuc": {},
                    "dw": 19,
                    "ffo": "uwsh",
                    "spk": "pjdyam",
                    "mc": [],
                    "wunb": {},
                    "qcze": 2271.15,
                    "mcqx": None
                  },
                  "qob"
                ],
                "wo": "zy"
              },
              {
                "dok": None,
                "ygk": None,
                "afdw": [
                  7848,
                  "ah",
                  None
                ],
                "foobar": 3.141592,
                "wnuo": {
                  "zpvi": {
                    "stw": true,
                    "bq": {},
                    "zord": true,
                    "omne": 3061.73,
                    "bnwm": "wuuyy",
                    "tuv": 7053,
                    "lepv": None,
                    "xap": 94.26
                  },
                  "nuv": false,
                  "hhza": 539.615,
                  "rqw": {
                    "dk": 2305,
                    "wibo": 7512.9,
                    "ytbc": 153,
                    "pokp": None,
                    "whzd": None,
                    "judg": [],
                    "zh": None
                  },
                  "bcnu": "ji",
                  "yhqu": None,
                  "gwc": true,
                  "smp": {
                    "fxpl": 75,
                    "gc": [],
                    "vx": 9352.895,
                    "fbzf": 4138.27,
                    "tiaq": 354.306,
                    "kmfb": {},
                    "fxhy": [],
                    "af": 94.46,
                    "wg": {},
                    "fb": None
                  }
                },
                "zvym": 2921,
                "hhlh": [
                  45,
                  214.345
                ],
                "vv": "gqjoz"
              },
              [
                "uxlu",
                None,
                "utl",
                64,
                [
                  2695
                ],
                [
                  false,
                  None,
                  [
                    "cfcrl",
                    [],
                    [],
                    562,
                    1654.9,
                    {},
                    None,
                    "sqzud",
                    934.6
                  ],
                  {
                    "hk": true,
                    "ed": "lodube",
                    "ye": "ziwddj",
                    "ps": None,
                    "ir": {},
                    "heh": false
                  },
                  true,
                  719,
                  50.56,
                  [
                    99,
                    6409,
                    None,
                    4886,
                    "esdtkt",
                    {},
                    None
                  ],
                  [
                    false,
                    "bkzqw"
                  ]
                ],
                None,
                6357
              ],
              {
                "asvv": 22.873,
                "vqm": {
                  "drmv": 68.12,
                  "tmf": 140.495,
                  "le": None,
                  "sanf": [
                    true,
                    [],
                    "vyawd",
                    false,
                    76.496,
                    [],
                    "sdfpr",
                    33.16,
                    "nrxy",
                    "antje"
                  ],
                  "yrkh": 662.426,
                  "vxj": true,
                  "sn": 314.382,
                  "eorg": None
                },
                "bavq": [
                  21.18,
                  8742.66,
                  {
                    "eq": "urnd"
                  },
                  56.63,
                  "fw",
                  [
                    {},
                    "pjtr",
                    None,
                    "apyemk",
                    [],
                    [],
                    false,
                    {}
                  ],
                  {
                    "ho": None,
                    "ir": 124,
                    "oevp": 159,
                    "xdrv": 6705,
                    "ff": [],
                    "sx": false
                  },
                  true,
                  None,
                  true
                ],
                "zw": "qjqaap",
                "hr": {
                  "xz": 32,
                  "mj": 8235.32,
                  "yrtv": None,
                  "jcz": "vnemxe",
                  "ywai": [
                    None,
                    564,
                    false,
                    "vbr",
                    54.741
                  ],
                  "vw": 82,
                  "wn": true,
                  "pav": true
                },
                "vxa": 881
              },
              "bgt",
              "vuzk",
              857
            ]
          ]
        ],
        None,
        None,
        {
          "xyzl": "nvfff"
        },
        true,
        13
      ],
      "npd": None,
      "ha": [
        [
          "du",
          [
            980,
            {
              "zdhd": [
                129.986,
                [
                  "liehns",
                  453,
                  {
                    "fuq": false,
                    "dxpn": {},
                    "hmpx": 49,
                    "zb": "gbpt",
                    "vdqc": None,
                    "ysjg": false,
                    "gug": 7990.66
                  },
                  "evek",
                  [
                    {}
                  ],
                  "dfywcu",
                  9686,
                  None
                ]
              ],
              "gpi": {
                "gt": {
                  "qe": 7460,
                  "nh": "nrn",
                  "czj": 66.609,
                  "jwd": true,
                  "rb": "azwwe",
                  "fj": {
                    "csn": true,
                    "foobar": 1.61803398875,
                    "hm": "efsgw",
                    "zn": "vbpizt",
                    "tjo": 138.15,
                    "teo": {},
                    "hecf": [],
                    "ls": false
                  }
                },
                "xlc": 7916,
                "jqst": 48.166,
                "zj": "ivctu"
              },
              "jl": 369.27,
              "mxkx": None,
              "sh": [
                true,
                373,
                false,
                "sdis",
                6217,
                {
                  "ernm": None,
                  "srbo": 90.798,
                  "py": 677,
                  "jgrq": None,
                  "zujl": None,
                  "odsm": {
                    "pfrd": None,
                    "kwz": "kfvjzb",
                    "ptkp": false,
                    "pu": None,
                    "xty": None,
                    "ntx": [],
                    "nq": 48.19,
                    "lpyx": []
                  },
                  "ff": None,
                  "rvi": [
                    "ych",
                    {},
                    72,
                    9379,
                    7897.383,
                    true,
                    {},
                    999.751,
                    false
                  ]
                },
                true
              ],
              "ghe": [
                24,
                {
                  "lpr": true,
                  "qrs": true
                },
                true,
                false,
                7951.94,
                true,
                2690.54,
                [
                  93,
                  None,
                  None,
                  "rlz",
                  true,
                  "ky",
                  true
                ]
              ],
              "vet": false,
              "olle": None
            },
            "jzm",
            true
          ],
          None,
          None,
          19.17,
          7145,
          "ipsmk"
        ],
        false,
        {
          "du": 6550.959,
          "sps": 8783.62,
          "nblr": {
            "dko": 9856.616,
            "lz": {
              "phng": "dj"
            },
            "zeu": 766,
            "tn": "dkr"
          },
          "xa": "trdw",
          "gn": 9875.687,
          "dl": None,
          "vuql": None
        },
        {
          "qpjo": None,
          "das": {
            "or": {
              "xfy": None,
              "xwvs": 4181.86,
              "yj": 206.325,
              "bsr": [
                "qrtsh"
              ],
              "wndm": {
                "ve": 56,
                "jyqa": true,
                "ca": None
              },
              "rpd": 9906,
              "ea": "dvzcyt"
            },
            "xwnn": 9272,
            "rpx": "zpr",
            "srzg": {
              "beo": 325.6,
              "sq": None,
              "yf": None,
              "nu": [
                377,
                "qda",
                true
              ],
              "sfz": "zjk"
            },
            "kh": "xnpj",
            "rk": None,
            "hzhn": [
              None
            ],
            "uio": 6249.12,
            "nxrv": 1931.635,
            "pd": None
          },
          "pxlc": true,
          "mjer": false,
          "hdev": "msr",
          "er": None
        },
        "ug",
        None,
        "yrfoix",
        503.89,
        563
      ],
      "tcy": 300,
      "me": 459.17,
      "tm": [
        134.761,
        "jcoels",
        None
      ],
      "iig": 945.57,
      "ad": "be"
    },
    "ltpdm",
    None,
    14.53
  ],
  "xi": "gxzzs",
  "zfpw": 1564.87,
  "ow": None,
  "tm": [
    46,
    876.85
  ],
  "xejv": None
}
"""  # noqa
