#  Copyright 2021, 2026 IBM Corporation
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#  http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import json

from abc import ABC, abstractmethod

import requests

from cpo.utils.operating_system import OperatingSystem


class DependencyVersion:
    def __init__(self, version: str):
        self._version = version
        self._version_without_prefix = version.removeprefix("v")

    @property
    def version(self) -> str:
        return self._version

    @property
    def version_without_prefix(self) -> str:
        return self._version_without_prefix


class AbstractDependencyManagerPlugIn(ABC):
    """Base class of all dependency manager plug-in classes"""

    @abstractmethod
    def download_dependency_version(self, version: str):
        """Downloads the given version of the dependency

        Parameters
        ----------
        version
            version of the dependency to be downloaded
        """

        pass

    @abstractmethod
    def get_dependency_alias(self) -> str:
        """Returns the alias of the dependency

        The alias is used as a key in ~/.cpo/binaries.json to store the version
        of the downloaded dependency.

        Example:

        {
            […]
            "ibmcloud": "1.2.3",
            […]
        }

        Returns
        -------
        str
            alias of the dependency
        """

        pass

    @abstractmethod
    def get_dependency_name(self) -> str:
        """Returns the dependency name

        Returns
        -------
        str
            dependency name
        """

        pass

    @abstractmethod
    def get_latest_dependency_version(self, github_access_token: str | None) -> DependencyVersion:
        """Returns the latest version of the dependency available at the
        official download location

        Parameters
        ----------
        github_access_token
            GitHub access token

        Returns
        -------
        DependencyVersion
            latest version of the dependency available at the official download
            location
        """

        pass

    def is_located_in_subdirectory(self) -> bool:
        """Returns whether the plug-in is located in a subdirectory

        The name of the subdirectory must equal the alias of the dependency.

        Returns
        -------
        bool
            True, if the plug-in is located in a subdirectory
        """

        return False

    @abstractmethod
    def is_operating_system_supported(self, operating_system: OperatingSystem) -> bool:
        pass

    def _get_latest_dependency_version_on_github(
        self, owner: str, repo: str, github_access_token: str | None
    ) -> DependencyVersion | None:
        """Returns the latest version of the dependency on GitHub

        This method parses the "name" key of the JSON document returned by the
        GitHub Releases API, which has the following structure:

        [
            {
                "url": […],
                "html_url": […],
                "assets_url": […],
                "upload_url": […],
                "tarball_url": […],
                "zipball_url": […],
                "id": […],
                "node_id": […],
                "tag_name": […],
                "target_commitish": […],
                "name": "v1.0.0",
                "body": […],
                "draft": […],
                "prerelease": […],
                "created_at": […],
                "published_at": […],
                "author": {
                    […]
                },
                "assets": [
                    […]
                ]
            },
            {
                […]
                "name": "v2.0.0",
                […]
            },
            […]
        ]

        GitHub Releases API: https://developer.github.com/v3/repos/releases/

        Parameters
        ----------
        github_access_token
            GitHub access token
        owner
            GitHub repository owner
        repo
            GitHub repository name

        Returns
        -------
        DependencyVersion | None
            latest version of the dependency or None if no release was found
        """

        headers = {}

        if github_access_token is not None:
            headers["Authorization"] = f"Bearer {github_access_token}"

        response = requests.get(f"https://api.github.com/repos/{owner}/{repo}/releases/latest", headers=headers)
        response.raise_for_status()

        response_json = json.loads(response.content)
        result: DependencyVersion | None = None

        if len(response_json) != 0:
            result = DependencyVersion(response_json["tag_name"])

        return result
