"""Asynchronous client for agent interactions."""

from __future__ import annotations

from typing import AsyncIterator

from blocks_agent._types import AgentOptions, Response
from blocks_agent._adapter import AgentAdapter


class AsyncAgentClient:
    """Async client — use with ``async with``."""

    def __init__(self, options: AgentOptions | None = None) -> None:
        self._options = options or AgentOptions()
        self._adapter: AgentAdapter | None = None

    # ── async context manager ───────────────────────────────────

    async def __aenter__(self) -> "AsyncAgentClient":
        self._adapter = AgentAdapter(self._options)
        await self._adapter.connect()
        return self

    async def __aexit__(self, *args: object) -> None:
        if self._adapter:
            await self._adapter.disconnect()
            self._adapter = None

    # ── public API ──────────────────────────────────────────────

    async def send(self, prompt: str) -> Response:
        """Send a prompt and await the complete response."""
        if self._adapter is None:
            raise RuntimeError("Client is not connected. Use as a context manager.")
        return await self._adapter.send(prompt)

    async def stream(self, prompt: str) -> AsyncIterator[Response]:
        """Send a prompt and yield incremental responses per ReAct turn."""
        if self._adapter is None:
            raise RuntimeError("Client is not connected. Use as a context manager.")
        async for response in self._adapter.stream(prompt):
            yield response
