#!/usr/bin/env python3
"""

This agent uses the ReAct pattern (Reason-Act-Observe) with proper LLM integration
and tool calling.
"""

import os
import json
import asyncio
import platform
import datetime
import re
import glob as glob_module
from contextlib import AsyncExitStack
from pathlib import Path
from typing import Dict, List, Any, Tuple, Optional
import anthropic
import jinja2
from mcp import ClientSession, StdioServerParameters, types as mcp_types
from mcp.client.stdio import stdio_client
from prompt_toolkit import PromptSession
from prompt_toolkit.key_binding import KeyBindings

PROMPTS_DIR = Path(__file__).parent / "prompts"
_jinja_env = jinja2.Environment(
    loader=jinja2.FileSystemLoader(str(PROMPTS_DIR)),
    keep_trailing_newline=False,
    trim_blocks=True,
    lstrip_blocks=True,
)


def _load_tool_description(name: str) -> str:
    return _jinja_env.get_template(f"tools/{name}.j2").render().strip()


TOOLS_SCHEMA = [
    {
        "name": "read_file",
        "description": _load_tool_description("read_file"),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "The path to the file to read"},
                "offset": {
                    "type": "integer",
                    "description": "Line number to start reading from (1-based). If omitted, reads from the beginning."
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of lines to read. If omitted, reads the entire file (up to 2000 lines)."
                }
            },
            "required": ["path"]
        }
    },
    {
        "name": "write_file",
        "description": _load_tool_description("write_file"),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "The path to the file to write"},
                "content": {"type": "string", "description": "The content to write to the file"}
            },
            "required": ["path", "content"]
        }
    },
    {
        "name": "edit_file",
        "description": _load_tool_description("edit_file"),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "The path to the file to edit"},
                "old_string": {"type": "string", "description": "The exact text to find and replace (must match exactly once)"},
                "new_string": {"type": "string", "description": "The text to replace it with (must be different from old_string)"}
            },
            "required": ["path", "old_string", "new_string"]
        }
    },
    {
        "name": "glob",
        "description": _load_tool_description("glob"),
        "input_schema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Glob pattern to match (e.g., '**/*.py', 'src/*.ts')"},
                "path": {
                    "type": "string",
                    "description": "Directory to search in. Defaults to the working directory if omitted."
                }
            },
            "required": ["pattern"]
        }
    },
    {
        "name": "grep",
        "description": _load_tool_description("grep"),
        "input_schema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Regex pattern to search for"},
                "path": {
                    "type": "string",
                    "description": "File or directory to search in. Defaults to the working directory."
                },
                "include": {
                    "type": "string",
                    "description": "Glob pattern to filter files (e.g., '*.py', '*.ts'). Only used when path is a directory."
                }
            },
            "required": ["pattern"]
        }
    },
    {
        "name": "list_directory",
        "description": _load_tool_description("list_directory"),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Directory path to list. Defaults to the working directory."
                }
            },
            "required": []
        }
    },
    {
        "name": "bash",
        "description": _load_tool_description("bash"),
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "The bash command to execute"},
                "description": {"type": "string", "description": "A brief description of what this command does (5-10 words)"}
            },
            "required": ["command"]
        }
    }
]


class MCPClientManager:
    def __init__(self):
        self.exit_stack = AsyncExitStack()
        self.sessions: Dict[str, ClientSession] = {}
        self.tool_to_session: Dict[str, Tuple[str, ClientSession]] = {}
        self.tool_schemas: List[Dict] = []

    async def connect_from_config(self, path: str = "mcp_servers.json"):
        if not os.path.exists(path):
            print(f"No MCP config found at {path}, using built-in tools only.")
            return
        with open(path, "r") as f:
            config = json.load(f)
        servers = config.get("mcpServers", {})
        if not servers:
            return
        for name, server_config in servers.items():
            try:
                await self._connect_server(name, server_config)
            except Exception as e:
                print(f"Warning: MCP server '{name}' failed to connect: {e}")

    async def _connect_server(self, name: str, config: Dict):
        command = config["command"]
        args = config.get("args", [])
        env = {**os.environ, **config.get("env", {})}
        params = StdioServerParameters(command=command, args=args, env=env)
        stdio_transport = await self.exit_stack.enter_async_context(stdio_client(params))
        read_stream, write_stream = stdio_transport
        session = await self.exit_stack.enter_async_context(ClientSession(read_stream, write_stream))
        await session.initialize()
        self.sessions[name] = session
        tools_result = await session.list_tools()
        for tool in tools_result.tools:
            schema = self._convert_tool_schema(tool, name)
            self.tool_schemas.append(schema)
            prefixed_name = f"{name}__{tool.name}"
            self.tool_to_session[prefixed_name] = (name, session)
        print(f"MCP server '{name}' connected ({len(tools_result.tools)} tools)")

    def _convert_tool_schema(self, tool: mcp_types.Tool, server_name: str) -> Dict:
        input_schema = tool.inputSchema if tool.inputSchema else {"type": "object", "properties": {}}
        return {
            "name": f"{server_name}__{tool.name}",
            "description": f"[MCP: {server_name}] {tool.description or ''}",
            "input_schema": input_schema,
        }

    def is_mcp_tool(self, name: str) -> bool:
        return name in self.tool_to_session

    async def call_tool(self, name: str, args: Dict) -> str:
        if name not in self.tool_to_session:
            return json.dumps({"error": f"Unknown MCP tool: {name}"})
        server_name, session = self.tool_to_session[name]
        original_name = name[len(server_name) + 2:]
        try:
            result = await session.call_tool(original_name, arguments=args)
            parts = []
            for block in result.content:
                if isinstance(block, mcp_types.TextContent):
                    parts.append(block.text)
                elif isinstance(block, mcp_types.ImageContent):
                    parts.append(f"[image: {block.mimeType}]")
                elif isinstance(block, mcp_types.EmbeddedResource):
                    parts.append(str(block.resource))
                else:
                    parts.append(str(block))
            return json.dumps({"success": True, "content": "\n".join(parts)})
        except Exception as e:
            return json.dumps({"error": f"MCP tool call failed: {e}"})

    async def cleanup(self):
        await self.exit_stack.aclose()


class AICodingAgent:
    """AI Coding Agent with ReAct pattern and tool calling."""
    
    def __init__(self, api_key: str, working_directory: str = ".",
                 history_file: str = "agent_history.json",
                 mcp_config_path: str = "mcp_servers.json",
                 sandbox: bool = True):
        self.client = anthropic.Anthropic(api_key=api_key)
        self.working_directory = Path(working_directory).resolve()
        self.history_file = history_file
        self.mcp_config_path = mcp_config_path
        self.sandbox = sandbox
        self.mcp: Optional[MCPClientManager] = None
        self.messages: List[Dict] = []

        # SDK-configurable attributes (set via AgentAdapter)
        self._model: str = "claude-opus-4-6"
        self._system_prompt_override: Optional[str] = None
        self._max_turns: int = 100
        self._quiet: bool = False
        self._allowed_tools: Optional[List[str]] = None

        self.load_history()

    async def initialize_mcp(self):
        self.mcp = MCPClientManager()
        await self.mcp.connect_from_config(self.mcp_config_path)
    
    def save_history(self):
        """Save conversation history."""
        if self.history_file is None:
            return
        try:
            with open(self.history_file, 'w') as f:
                json.dump(self.messages, f, indent=2)
        except Exception as e:
            if not self._quiet:
                print(f"Warning: Could not save history: {e}")

    def load_history(self):
        """Load conversation history."""
        if self.history_file is None:
            return
        try:
            if os.path.exists(self.history_file):
                with open(self.history_file, 'r') as f:
                    self.messages = json.load(f)
        except Exception:
            self.messages = []
    
    def add_message(self, role: str, content: str):
        """Add a message to conversation history."""
        self.messages.append({"role": role, "content": content})
        self.save_history()
    
    def _get_all_tools(self) -> List[Dict]:
        tools = list(TOOLS_SCHEMA)
        if self.mcp:
            tools.extend(self.mcp.tool_schemas)
        if self._allowed_tools:
            allowed = set(self._allowed_tools)
            tools = [t for t in tools if t["name"] in allowed]
        return tools

    def _build_system_prompt(self) -> str:
        """Build the system prompt with dynamic environment context."""
        if self._system_prompt_override is not None:
            return self._system_prompt_override
        is_git = (self.working_directory / ".git").exists()
        env_lines = [
            f"- Working directory: {self.working_directory}",
            f"- Platform: {platform.system()} {platform.release()}",
            f"- Date: {datetime.date.today().isoformat()}",
            f"- Git repository: {'yes' if is_git else 'no'}",
        ]
        template = _jinja_env.get_template("system.j2")
        return template.render(environment_context="\n".join(env_lines))

    async def _call_claude(self, messages: List[Dict]) -> Tuple[Any, Optional[str]]:
        """Call Claude API with messages.

        Returns the full response object (not just content) so callers can access stop_reason.
        """
        max_tokens = 32000
        try:
            with self.client.beta.messages.stream(
                model=self._model,
                max_tokens=max_tokens,
                system=self._build_system_prompt(),
                tools=self._get_all_tools(),
                messages=messages,
                thinking={"type": "adaptive"},
                betas=["interleaved-thinking-2025-05-14"],
            ) as stream:
                response = stream.get_final_message()
            return response, None
        except anthropic.APIError as e:
            return None, f"API Error: {str(e)}"
        except Exception as e:
            return None, f"Unexpected error calling Claude API: {str(e)}"
    
    def _parse_claude_response(self, content_blocks: Any) -> Tuple[List[str], List[Any]]:
        """Parse Claude's response into text and tool calls."""
        text_responses = []
        tool_uses = []
        
        for block in content_blocks:
            if block.type == "thinking":
                if not self._quiet:
                    print(f"💭 {block.thinking}")
            elif block.type == "redacted_thinking":
                if not self._quiet:
                    print("💭 [redacted thinking]")
            elif block.type == "text":
                text_responses.append(block.text)
                if not self._quiet:
                    print(f"🤖 {block.text}")
            elif block.type == "tool_use":
                tool_uses.append(block)
                if not self._quiet:
                    if block.name == "bash":
                        print(f"🔧 bash: {block.input.get('command', '')}")
                    else:
                        print(f"🔧 Tool call: {block.name}")

        return text_responses, tool_uses
    
    async def _execute_tool_calls(self, tool_uses: List[Any]) -> List[Dict]:
        """Execute tool calls and return results."""
        tool_results = []
        
        for tool_use in tool_uses:
            if not self._quiet:
                print(f"   Executing: {tool_use.name}")
            try:
                if self.mcp and self.mcp.is_mcp_tool(tool_use.name):
                    result_str = await self.mcp.call_tool(tool_use.name, tool_use.input)
                    result = json.loads(result_str)
                elif tool_use.name == "read_file":
                    result = await self._read_file(
                        tool_use.input.get("path", ""),
                        offset=tool_use.input.get("offset"),
                        limit=tool_use.input.get("limit")
                    )
                elif tool_use.name == "write_file":
                    result = await self._write_file(
                        tool_use.input.get("path", ""),
                        tool_use.input.get("content", "")
                    )
                elif tool_use.name == "edit_file":
                    result = await self._edit_file(
                        tool_use.input.get("path", ""),
                        tool_use.input.get("old_string", ""),
                        tool_use.input.get("new_string", "")
                    )
                elif tool_use.name == "glob":
                    result = await self._glob(
                        tool_use.input.get("pattern", ""),
                        tool_use.input.get("path")
                    )
                elif tool_use.name == "grep":
                    result = await self._grep(
                        tool_use.input.get("pattern", ""),
                        tool_use.input.get("path"),
                        tool_use.input.get("include")
                    )
                elif tool_use.name == "list_directory":
                    result = await self._list_directory(
                        tool_use.input.get("path")
                    )
                elif tool_use.name == "bash":
                    result = await self._bash(tool_use.input.get("command", ""))
                else:
                    result = {"error": f"Unknown tool: {tool_use.name}"}
            except Exception as e:
                result = {"error": f"Tool execution failed: {str(e)}"}
            
            # Log success/error briefly
            if not self._quiet:
                if "success" in result and result["success"]:
                    print(f"   ✅ Tool executed successfully")
                elif "error" in result:
                    print(f"   ❌ Error: {result['error']}")
            
            # Collect result for API
            tool_results.append({
                "tool_use_id": tool_use.id,
                "content": json.dumps(result)
            })
        
        return tool_results
    
    def _resolve_path(self, path: str) -> Tuple[Optional[Path], Optional[str]]:
        """Resolve a path relative to working directory and optionally check bounds."""
        resolved = (self.working_directory / path).resolve()
        if self.sandbox and not str(resolved).startswith(str(self.working_directory)):
            return None, "Access denied: path outside working directory"
        return resolved, None

    # Tool implementations
    async def _read_file(self, path: str, offset: Optional[int] = None,
                         limit: Optional[int] = None) -> Dict[str, Any]:
        """Read a file and return its contents with line numbers."""
        try:
            file_path, err = self._resolve_path(path)
            if err:
                return {"error": err}

            with open(file_path, 'r', encoding='utf-8') as f:
                all_lines = f.readlines()

            total_lines = len(all_lines)
            start = (offset - 1) if offset and offset >= 1 else 0
            end = (start + limit) if limit else min(start + 2000, total_lines)
            end = min(end, total_lines)
            selected = all_lines[start:end]

            numbered = []
            for i, line in enumerate(selected, start=start + 1):
                numbered.append(f"{i:>6}\t{line.rstrip()}")

            content = "\n".join(numbered)
            return {
                "success": True,
                "content": content,
                "path": str(file_path),
                "total_lines": total_lines,
                "lines_shown": f"{start + 1}-{end}"
            }
        except Exception as e:
            return {"error": f"Could not read file: {str(e)}"}
    
    async def _write_file(self, path: str, content: str) -> Dict[str, Any]:
        """Write content to a file."""
        try:
            file_path = (self.working_directory / path).resolve()
            if self.sandbox and not str(file_path).startswith(str(self.working_directory)):
                return {"error": "Access denied: path outside working directory"}
            
            # Create parent directories if needed
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return {"success": True, "message": f"File {path} written successfully"}
        except Exception as e:
            return {"error": f"Could not write file: {str(e)}"}
    
    async def _bash(self, command: str) -> Dict[str, Any]:
        """Execute a bash command."""
        MAX_OUTPUT = 30000
        try:
            process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self.working_directory)
            )
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(), timeout=120
                )
                stdout_str = stdout.decode("utf-8")
                stderr_str = stderr.decode("utf-8")
                if len(stdout_str) > MAX_OUTPUT:
                    stdout_str = stdout_str[:MAX_OUTPUT] + "\n... (truncated)"
                if len(stderr_str) > MAX_OUTPUT:
                    stderr_str = stderr_str[:MAX_OUTPUT] + "\n... (truncated)"
                return {
                    "success": process.returncode == 0,
                    "stdout": stdout_str,
                    "stderr": stderr_str,
                    "returncode": process.returncode
                }
            except asyncio.TimeoutError:
                process.kill()
                return {"error": "Command timed out after 120 seconds"}
        except Exception as e:
            return {"error": f"Could not execute command: {str(e)}"}
    
    async def _edit_file(self, path: str, old_string: str, new_string: str) -> Dict[str, Any]:
        """Edit a file by replacing an exact string match."""
        try:
            file_path, err = self._resolve_path(path)
            if err:
                return {"error": err}
            if not file_path.is_file():
                return {"error": f"File not found: {path}"}
            if old_string == new_string:
                return {"error": "old_string and new_string are identical"}

            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            count = content.count(old_string)
            if count == 0:
                return {"error": "old_string not found in file. Check for exact whitespace/indentation match."}
            if count > 1:
                return {"error": f"old_string matches {count} times. Provide more context to make it unique."}

            new_content = content.replace(old_string, new_string, 1)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            return {"success": True, "message": f"File {path} edited successfully"}
        except Exception as e:
            return {"error": f"Could not edit file: {str(e)}"}

    async def _glob(self, pattern: str, path: Optional[str] = None) -> Dict[str, Any]:
        """Find files matching a glob pattern."""
        MAX_RESULTS = 200
        try:
            search_dir = self.working_directory
            if path:
                resolved, err = self._resolve_path(path)
                if err:
                    return {"error": err}
                search_dir = resolved

            full_pattern = str(search_dir / pattern)
            matches = glob_module.glob(full_pattern, recursive=True)
            matches = [m for m in matches if os.path.isfile(m)]
            matches.sort(key=lambda p: os.path.getmtime(p), reverse=True)

            results = []
            for m in matches[:MAX_RESULTS]:
                try:
                    rel = os.path.relpath(m, str(self.working_directory))
                except ValueError:
                    rel = m
                results.append(rel)

            truncated = len(matches) > MAX_RESULTS
            return {
                "success": True,
                "files": results,
                "total": len(matches),
                "truncated": truncated
            }
        except Exception as e:
            return {"error": f"Glob failed: {str(e)}"}

    async def _grep(self, pattern: str, path: Optional[str] = None,
                    include: Optional[str] = None) -> Dict[str, Any]:
        """Search file contents using a regex pattern."""
        MAX_MATCHES = 200
        try:
            regex = re.compile(pattern)
        except re.error as e:
            return {"error": f"Invalid regex: {e}"}

        try:
            search_path = self.working_directory
            if path:
                resolved, err = self._resolve_path(path)
                if err:
                    return {"error": err}
                search_path = resolved

            matches = []

            if search_path.is_file():
                files_to_search = [search_path]
            else:
                file_pattern = include or "*"
                files_to_search = list(search_path.rglob(file_pattern))
                files_to_search = [f for f in files_to_search if f.is_file()]

            for fpath in files_to_search:
                if len(matches) >= MAX_MATCHES:
                    break
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                        for line_num, line in enumerate(f, 1):
                            if regex.search(line):
                                try:
                                    rel = os.path.relpath(str(fpath), str(self.working_directory))
                                except ValueError:
                                    rel = str(fpath)
                                matches.append({
                                    "file": rel,
                                    "line": line_num,
                                    "content": line.rstrip()[:500]
                                })
                                if len(matches) >= MAX_MATCHES:
                                    break
                except (OSError, UnicodeDecodeError):
                    continue

            return {
                "success": True,
                "matches": matches,
                "total": len(matches),
                "truncated": len(matches) >= MAX_MATCHES
            }
        except Exception as e:
            return {"error": f"Grep failed: {str(e)}"}

    async def _list_directory(self, path: Optional[str] = None) -> Dict[str, Any]:
        """List directory contents."""
        try:
            dir_path = self.working_directory
            if path:
                resolved, err = self._resolve_path(path)
                if err:
                    return {"error": err}
                dir_path = resolved

            if not dir_path.is_dir():
                return {"error": f"Not a directory: {path or '.'}"}

            entries = []
            for item in sorted(dir_path.iterdir()):
                try:
                    rel = os.path.relpath(str(item), str(self.working_directory))
                except ValueError:
                    rel = str(item)
                entries.append({
                    "name": item.name,
                    "path": rel,
                    "type": "directory" if item.is_dir() else "file"
                })
            return {"success": True, "entries": entries}
        except Exception as e:
            return {"error": f"Could not list directory: {str(e)}"}

    def build_messages_list(self, user_input: Optional[str] = None,
                           tool_results: Optional[List[Dict]] = None,
                           assistant_content: Optional[Any] = None,
                           max_history: int = 20) -> List[Dict]:
        """Build a clean messages list for the API call."""
        messages = []
        
        # Add conversation history (limited for context window)
        start_idx = max(0, len(self.messages) - max_history)
        
        for msg in self.messages[start_idx:]:
            if isinstance(msg, dict) and "role" in msg and "content" in msg:
                clean_msg = {"role": msg["role"], "content": msg["content"]}
                messages.append(clean_msg)
        
        # Add new user input if provided
        if user_input:
            messages.append({"role": "user", "content": user_input})
        
        # Add assistant content if provided (for tool use continuation)
        if assistant_content:
            messages.append({"role": "assistant", "content": assistant_content})
        
        # Add tool results as user message if provided
        if tool_results:
            messages.append({
                "role": "user",
                "content": [
                    {
                        "type": "tool_result",
                        "tool_use_id": tr["tool_use_id"],
                        "content": tr["content"]
                    }
                    for tr in tool_results
                ]
            })
        
        return messages
    
    async def react_loop(self, user_input: str) -> str:
        """Main ReAct loop: Reason-Act-Observe.

        Uses the model's stop_reason to determine when to exit the loop,
        following Anthropic's canonical ReAct pattern.
        """
        # Add user message to history
        self.add_message("user", user_input)

        # Build initial messages list
        messages = self.build_messages_list(user_input=user_input)

        # Track the last text response
        last_complete_response = None

        # Safety limit to prevent infinite loops
        safety_limit = self._max_turns
        iterations = 0

        while iterations < safety_limit:
            iterations += 1

            # REASON: Get Claude's response
            response, error = await self._call_claude(messages)

            if error:
                error_msg = f"Error: {error}"
                self.add_message("assistant", error_msg)
                return error_msg

            # Extract content and stop_reason from response
            content_blocks = response.content
            stop_reason = response.stop_reason

            # Parse response into text and tool uses
            text_responses, tool_uses = self._parse_claude_response(content_blocks)

            # Store the last complete text response
            if text_responses:
                last_complete_response = "\n".join(text_responses)

            # Handle based on stop_reason (canonical ReAct pattern)
            if stop_reason == "tool_use":
                # ACT: Execute tools and collect results
                tool_results = await self._execute_tool_calls(tool_uses)

                # OBSERVE: Append to messages for next iteration (accumulate context)
                messages.append({"role": "assistant", "content": content_blocks})
                messages.append({
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": tr["tool_use_id"],
                            "content": tr["content"]
                        }
                        for tr in tool_results
                    ]
                })
            elif stop_reason == "end_turn":
                break
            elif stop_reason == "max_tokens":
                if not self._quiet:
                    print("⚠️  Warning: Response was truncated due to max_tokens limit")
                break
            elif stop_reason == "refusal":
                if not self._quiet:
                    print("⚠️  Warning: Model refused to respond due to safety policy")
                break
            elif stop_reason == "stop_sequence":
                break
            else:
                break

        # Prepare final response
        if not last_complete_response:
            final_response = "I couldn't generate a response."
        elif iterations >= safety_limit:
            final_response = f"{last_complete_response}\n\n(Note: I reached my processing limit. You may want to break this down into smaller steps.)"
        else:
            final_response = last_complete_response

        # Save to history and return
        self.add_message("assistant", final_response)
        return final_response
    
    async def process_message(self, user_input: str) -> str:
        """Main entry point for processing user messages."""
        try:
            response = await self.react_loop(user_input)
            return response
        except Exception as e:
            error_msg = f"Unexpected error processing message: {str(e)}"
            self.add_message("assistant", error_msg)
            return error_msg

    # ── SDK helper methods ──────────────────────────────────────

    @staticmethod
    def _serialize_block(block: Any) -> dict:
        """Convert an Anthropic content-block object to a plain dict."""
        if isinstance(block, dict):
            return block
        if block.type == "text":
            return {"type": "text", "text": block.text}
        if block.type == "tool_use":
            return {
                "type": "tool_use",
                "id": getattr(block, "id", ""),
                "name": block.name,
                "input": block.input,
            }
        if block.type in ("thinking", "redacted_thinking"):
            return {"type": block.type, "thinking": getattr(block, "thinking", "")}
        return {"type": block.type}

    async def react_loop_structured(self, user_input: str) -> dict:
        """Full ReAct loop returning a structured result for the SDK.

        Delegates to :meth:`react_loop_streaming` and returns the final
        cumulative result, avoiding loop duplication.
        """
        result = {"messages": [], "text": "", "usage": {}, "stop_reason": None}
        async for result in self.react_loop_streaming(user_input):
            pass
        return result

    async def react_loop_streaming(self, user_input: str):
        """Async generator yielding a :class:`Response`-compatible dict after each ReAct turn.

        Each yielded dict contains the *cumulative* state so the caller always
        has a complete picture.

        Mirrors the full control flow of :meth:`react_loop` — including
        explicit stop-reason handling, empty-response fallback, and the
        safety-limit note — while additionally tracking SDK-typed messages
        and token usage.
        """
        from blocks_agent._types import (
            Message, TextBlock as SdkTextBlock,
            ToolUseBlock as SdkToolUseBlock, ToolResultBlock, ContentBlock as SdkContentBlock,
        )

        # Persist to history when enabled (mirrors react_loop)
        self.add_message("user", user_input)

        messages_api = self.build_messages_list(user_input=user_input)
        accumulated_messages: list[Message] = [Message(role="user", content=user_input)]
        total_usage: dict = {"input_tokens": 0, "output_tokens": 0}
        last_text = ""
        stop_reason = None

        iterations = 0
        while iterations < self._max_turns:
            iterations += 1

            # REASON: Get Claude's response
            response, error = await self._call_claude(messages_api)
            if error:
                error_msg = f"Error: {error}"
                self.add_message("assistant", error_msg)
                yield {
                    "messages": accumulated_messages,
                    "text": error_msg,
                    "usage": total_usage,
                    "stop_reason": "error",
                }
                return

            content_blocks = response.content
            stop_reason = response.stop_reason

            # Accumulate usage
            if hasattr(response, "usage") and response.usage:
                total_usage["input_tokens"] += getattr(response.usage, "input_tokens", 0)
                total_usage["output_tokens"] += getattr(response.usage, "output_tokens", 0)

            # Parse response into text and tool uses
            text_responses, tool_uses = self._parse_claude_response(content_blocks)
            if text_responses:
                last_text = "\n".join(text_responses)

            # Build SDK-level assistant message
            sdk_blocks: list[SdkContentBlock] = []
            for block in content_blocks:
                if block.type == "text":
                    sdk_blocks.append(SdkTextBlock(text=block.text))
                elif block.type == "tool_use":
                    sdk_blocks.append(SdkToolUseBlock(name=block.name, input=block.input))
            if sdk_blocks:
                accumulated_messages.append(Message(role="assistant", content=sdk_blocks))

            # Handle based on stop_reason (canonical ReAct pattern)
            if stop_reason == "tool_use":
                # ACT: Execute tools and collect results
                tool_results = await self._execute_tool_calls(tool_uses)

                # Record tool results as SDK messages
                result_blocks: list[SdkContentBlock] = []
                for tr in tool_results:
                    result_blocks.append(
                        ToolResultBlock(tool_use_id=tr["tool_use_id"], content=tr["content"])
                    )
                accumulated_messages.append(Message(role="user", content=result_blocks))

                # OBSERVE: Append to messages for next iteration
                messages_api.append({"role": "assistant", "content": content_blocks})
                messages_api.append({
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": tr["tool_use_id"],
                            "content": tr["content"],
                        }
                        for tr in tool_results
                    ],
                })

                # Yield incremental update after tool execution
                yield {
                    "messages": list(accumulated_messages),
                    "text": last_text,
                    "usage": dict(total_usage),
                    "stop_reason": stop_reason,
                }
            elif stop_reason == "end_turn":
                break
            elif stop_reason == "max_tokens":
                if not self._quiet:
                    print("⚠️  Warning: Response was truncated due to max_tokens limit")
                break
            elif stop_reason == "refusal":
                if not self._quiet:
                    print("⚠️  Warning: Model refused to respond due to safety policy")
                break
            elif stop_reason == "stop_sequence":
                break
            else:
                break

        # Prepare final text (mirrors react_loop)
        if not last_text:
            last_text = "I couldn't generate a response."
        elif iterations >= self._max_turns:
            last_text = f"{last_text}\n\n(Note: I reached my processing limit. You may want to break this down into smaller steps.)"

        # Persist to history
        self.add_message("assistant", last_text)

        # Final yield
        yield {
            "messages": list(accumulated_messages),
            "text": last_text,
            "usage": dict(total_usage),
            "stop_reason": stop_reason,
        }


def _build_prompt_session() -> PromptSession:
    """Build a prompt_toolkit session with multi-line support.

    - Enter submits the input
    - Shift+Enter or Alt+Enter inserts a newline
    - Pasting multi-line text (e.g. tracebacks) works seamlessly
    """
    bindings = KeyBindings()

    @bindings.add("enter")
    def _submit(event):
        event.current_buffer.validate_and_handle()

    @bindings.add("escape", "enter")
    def _newline(event):
        event.current_buffer.insert_text("\n")

    return PromptSession(
        multiline=True,
        key_bindings=bindings,
    )


async def main():
    """Main CLI interface."""
    print("🤖 AI Coding Agent (ReAct Pattern)")
    print("=" * 70)
    print("Type 'exit' or 'quit' to quit, 'clear' to clear history")
    print("Enter to send, Alt+Enter for new line, paste multi-line freely")
    print("=" * 70)

    # Get API key
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        api_key = input("Enter your Anthropic API key: ").strip()

    if not api_key:
        print("❌ API key required!")
        return

    # os.chddir to ./sandbox
    # os.chdir("./sandbox")

    # Initialize agent
    project_dir = Path(__file__).parent
    agent = AICodingAgent(
        api_key,
        mcp_config_path=str(project_dir / "mcp_servers.json"),
        history_file=str(project_dir / "agent_history.json"),
        sandbox=False,
    )
    await agent.initialize_mcp()

    session = _build_prompt_session()

    try:
        while True:
            try:
                user_input = await session.prompt_async("\n🧑 You: ")
                user_input = user_input.strip()

                if user_input.lower() in ['exit', 'quit']:
                    print("👋 Goodbye!")
                    break
                elif user_input.lower() == 'clear':
                    agent.messages = []
                    agent.save_history()
                    print("🧹 History cleared!")
                    continue
                elif not user_input:
                    continue

                print("\n🤖 Agent processing...")
                response = await agent.process_message(user_input)
                print(f"\n📋 Final Response: {response}")

            except KeyboardInterrupt:
                print("\n👋 Goodbye!")
                break
            except EOFError:
                print("\n👋 Goodbye!")
                break
            except Exception as e:
                print(f"\n❌ Error: {e}")
    finally:
        if agent.mcp:
            await agent.mcp.cleanup()


if __name__ == "__main__":
    asyncio.run(main())