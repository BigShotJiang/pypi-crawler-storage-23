"""Bridge between the SDK interface and AICodingAgent."""

from __future__ import annotations

import os
from pathlib import Path
from typing import AsyncIterator

from blocks_agent._types import AgentOptions, Response, Message
from blocks_agent._agent import AICodingAgent


class AgentAdapter:
    """Thin coordination layer: AgentOptions → AICodingAgent configuration."""

    def __init__(self, options: AgentOptions) -> None:
        self._options = options
        self._agent: AICodingAgent | None = None

    # ── lifecycle ────────────────────────────────────────────────

    async def connect(self) -> None:
        api_key = self._options.api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            raise RuntimeError(
                "No API key provided. Pass api_key in AgentOptions or set ANTHROPIC_API_KEY."
            )

        cwd = self._options.cwd or "."
        mcp_config = self._options.mcp_config_path or str(
            Path(__file__).resolve().parent.parent / "mcp_servers.json"
        )

        self._agent = AICodingAgent(
            api_key=api_key,
            working_directory=cwd,
            history_file=None,  # SDK mode — no file persistence
            mcp_config_path=mcp_config,
            sandbox=self._options.sandbox,
        )

        # Apply SDK overrides
        self._agent._quiet = True
        if self._options.model:
            self._agent._model = self._options.model
        if self._options.system_prompt is not None:
            self._agent._system_prompt_override = self._options.system_prompt
        if self._options.max_turns is not None:
            self._agent._max_turns = self._options.max_turns
        if self._options.allowed_tools:
            self._agent._allowed_tools = self._options.allowed_tools

        await self._agent.initialize_mcp()

    async def disconnect(self) -> None:
        if self._agent and self._agent.mcp:
            await self._agent.mcp.cleanup()
        self._agent = None

    # ── operations ──────────────────────────────────────────────

    def _ensure_connected(self) -> AICodingAgent:
        if self._agent is None:
            raise RuntimeError("Client is not connected. Use as a context manager.")
        return self._agent

    async def send(self, prompt: str) -> Response:
        agent = self._ensure_connected()
        result = await agent.react_loop_structured(prompt)
        return Response(
            messages=result["messages"],
            text=result["text"],
            usage=result["usage"],
            stop_reason=result.get("stop_reason"),
        )

    async def stream(self, prompt: str) -> AsyncIterator[Response]:
        agent = self._ensure_connected()
        async for result in agent.react_loop_streaming(prompt):
            yield Response(
                messages=result["messages"],
                text=result["text"],
                usage=result["usage"],
                stop_reason=result.get("stop_reason"),
            )
