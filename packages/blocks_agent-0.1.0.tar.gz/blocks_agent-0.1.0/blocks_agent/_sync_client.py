"""Synchronous client for agent interactions.

Uses a dedicated background thread with its own event loop so that MCP sessions
(which are bound to the loop that created them) survive across multiple calls.
"""

from __future__ import annotations

import asyncio
import threading
from typing import Iterator

from blocks_agent._types import AgentOptions, Response
from blocks_agent._adapter import AgentAdapter


class AgentClient:
    """Sync client — use with ``with``."""

    def __init__(self, options: AgentOptions | None = None) -> None:
        self._options = options or AgentOptions()
        self._adapter: AgentAdapter | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None

    # ── context manager ─────────────────────────────────────────

    def __enter__(self) -> "AgentClient":
        self._connect()
        return self

    def __exit__(self, *args: object) -> None:
        self._disconnect()

    # ── internal lifecycle ──────────────────────────────────────

    def _connect(self) -> None:
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(target=self._loop.run_forever, daemon=True)
        self._thread.start()

        self._adapter = AgentAdapter(self._options)
        future = asyncio.run_coroutine_threadsafe(self._adapter.connect(), self._loop)
        future.result(timeout=self._options.timeout)

    def _disconnect(self) -> None:
        if self._adapter and self._loop and self._loop.is_running():
            future = asyncio.run_coroutine_threadsafe(
                self._adapter.disconnect(), self._loop
            )
            try:
                future.result(timeout=10)
            except Exception:
                pass

        if self._loop:
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread:
            self._thread.join(timeout=5)

        self._adapter = None
        self._loop = None
        self._thread = None

    # ── public API ──────────────────────────────────────────────

    def send(self, prompt: str) -> Response:
        """Blocking send — waits for the complete response."""
        if self._adapter is None or self._loop is None:
            raise RuntimeError("Client is not connected. Use as a context manager.")
        future = asyncio.run_coroutine_threadsafe(
            self._adapter.send(prompt), self._loop
        )
        return future.result(timeout=self._options.timeout)

    def stream(self, prompt: str) -> Iterator[Response]:
        """Blocking streaming generator — yields after each ReAct turn."""
        if self._adapter is None or self._loop is None:
            raise RuntimeError("Client is not connected. Use as a context manager.")

        queue: asyncio.Queue[Response | None] = asyncio.Queue()

        async def _producer() -> None:
            try:
                async for response in self._adapter.stream(prompt):
                    await queue.put(response)
            finally:
                await queue.put(None)  # sentinel

        asyncio.run_coroutine_threadsafe(_producer(), self._loop)

        while True:
            # Block the calling thread until the next item is available.
            future = asyncio.run_coroutine_threadsafe(queue.get(), self._loop)
            item = future.result(timeout=self._options.timeout)
            if item is None:
                break
            yield item
