"""Public types for the blocks_agent package."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Union


@dataclass
class AgentOptions:
    """Simplified configuration for agent clients."""

    system_prompt: Optional[str] = None
    model: Optional[str] = None
    max_turns: Optional[int] = None
    allowed_tools: list[str] = field(default_factory=list)
    cwd: Optional[str] = None
    timeout: float = 60.0

    # Internal wiring — users rarely need to set these directly.
    api_key: Optional[str] = None
    mcp_config_path: Optional[str] = None
    sandbox: bool = True


# ── Content blocks ──────────────────────────────────────────────


@dataclass
class ContentBlock:
    """Base content block."""

    type: str  # "text", "tool_use", "tool_result"


@dataclass
class TextBlock(ContentBlock):
    """A text content block."""

    text: str = ""

    def __init__(self, text: str = "") -> None:
        super().__init__(type="text")
        self.text = text


@dataclass
class ToolUseBlock(ContentBlock):
    """A tool-use content block."""

    name: str = ""
    input: dict = field(default_factory=dict)

    def __init__(self, name: str = "", input: dict | None = None) -> None:
        super().__init__(type="tool_use")
        self.name = name
        self.input = input or {}


@dataclass
class ToolResultBlock(ContentBlock):
    """A tool-result content block."""

    tool_use_id: str = ""
    content: str = ""

    def __init__(self, tool_use_id: str = "", content: str = "") -> None:
        super().__init__(type="tool_result")
        self.tool_use_id = tool_use_id
        self.content = content


# ── Message ─────────────────────────────────────────────────────


@dataclass
class Message:
    """A single conversation message."""

    role: str  # "user", "assistant", "system"
    content: Union[str, list[ContentBlock]]


# ── Response ────────────────────────────────────────────────────


@dataclass
class Response:
    """Complete response from an agent interaction."""

    messages: list[Message] = field(default_factory=list)
    text: str = ""
    usage: dict = field(default_factory=dict)
    stop_reason: Optional[str] = None
