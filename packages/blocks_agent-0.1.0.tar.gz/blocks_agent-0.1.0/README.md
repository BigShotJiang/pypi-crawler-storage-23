# React Agent

An AI coding agent using the ReAct pattern (Reason-Act-Observe) with Claude and tool calling.

## Install

```bash
pip install blocks-agent
```

## Usage

```python
from blocks_agent import AgentClient, AgentOptions

with AgentClient(AgentOptions(system_prompt="You are a helpful assistant.")) as client:
    response = client.send("What files are in the current directory?")
    print(response.text)
```

### Async

```python
import asyncio
from blocks_agent import AsyncAgentClient, AgentOptions

async def main():
    async with AsyncAgentClient(AgentOptions()) as client:
        response = await client.send("Summarize this project.")
        print(response.text)

asyncio.run(main())
```

### Streaming

```python
from blocks_agent import AgentClient, AgentOptions

with AgentClient(AgentOptions()) as client:
    for update in client.stream("List all Python files, then count them."):
        print(f"[turn] {update.text[:120]}...")
        print(f"       stop_reason={update.stop_reason}")
```

## Configuration

```python
AgentOptions(
    system_prompt="...",       # Custom system prompt
    model="claude-opus-4-6",   # Model to use
    max_turns=100,             # Max ReAct iterations
    cwd="/path/to/project",    # Working directory
    api_key="sk-...",          # Or set ANTHROPIC_API_KEY env var
    sandbox=True,              # Restrict file access to cwd
)
```
