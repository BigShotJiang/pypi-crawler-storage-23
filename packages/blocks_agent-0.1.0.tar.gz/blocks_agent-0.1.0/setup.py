from setuptools import setup, find_packages

with open("requirements.txt") as f:
    requirements = f.read().splitlines()

setup(
    name="blocks_agent",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    package_data={"blocks_agent": ["prompts/**/*.j2"]},
    install_requires=requirements,
    description="AI coding agent with ReAct pattern and tool calling.",
    author="BlocksOrg",
    license="AGPL",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author_email="dev@blocks.team",
    url="https://github.com/BlocksOrg/react-agent",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: GNU Affero General Public License v3",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.9",
)
