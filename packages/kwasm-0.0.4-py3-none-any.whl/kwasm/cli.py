"""kwasm CLI — bundle and view GDS layouts."""

import typer
from pathlib import Path
from kwasm.embed import bundle as _bundle

app = typer.Typer()


@app.command()
def bundle(
    gds: str,
    output: str | None = None,
    lyp: str | None = None,
    lyrdb: str | None = None,
):
    """Bundle a GDS layout into a self-contained HTML file."""
    out = _bundle(gds, output=output, lyp=lyp, lyrdb=lyrdb)
    print(f"Bundled: {out} ({out.stat().st_size:,} bytes)")


@app.command()
def view(gds: str, lyp: str | None = None, lyrdb: str | None = None):
    """Bundle a GDS layout and open it in the default browser."""
    import tempfile
    import webbrowser

    tmp = Path(tempfile.mktemp(suffix=".html", prefix="kwasm_"))
    _bundle(gds, output=tmp, lyp=lyp, lyrdb=lyrdb)
    webbrowser.open(tmp.as_uri())
    print(f"Opened: {tmp}")


if __name__ == "__main__":
    app()
