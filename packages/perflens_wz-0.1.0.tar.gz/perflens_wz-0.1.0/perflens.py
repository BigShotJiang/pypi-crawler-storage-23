import time
import tracemalloc
from functools import wraps

def measure(func):
    """
    一个用于测量函数执行时间和峰值内存使用的装饰器。
    
    用法:
        @measure
        def my_function():
            ...
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        # 开启内存跟踪
        tracemalloc.start()
        # 记录开始时间
        start_time = time.perf_counter()

        # 执行原函数
        result = func(*args, **kwargs)

        # 获取内存使用情况 (当前内存, 峰值内存)
        current, peak = tracemalloc.get_traced_memory()
        # 停止内存跟踪
        tracemalloc.stop()
        # 记录结束时间
        end_time = time.perf_counter()

        # 计算耗时和内存 (转换为 MB)
        elapsed_time = end_time - start_time
        peak_memory_mb = peak / (1024 * 1024)

        # 打印格式化的结果
        print(f"🚀 [PerfLens] 函数 '{func.__name__}' 执行完毕:")
        print(f"   ⏱️  耗时: {elapsed_time:.4f} 秒")
        print(f"   💾 峰值内存: {peak_memory_mb:.4f} MB")
        
        return result
    return wrapper

# 下面是测试代码，你可以直接运行这个文件看看效果
if __name__ == "__main__":
    @measure
    def create_large_list():
        print("正在生成大列表...")
        return [i * 2 for i in range(5000000)]

    create_large_list()