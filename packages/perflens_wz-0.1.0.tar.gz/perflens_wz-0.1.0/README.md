PerfLens 🚀

PerfLens (性能放大镜) 是一个极简的 Python 库。它提供了一个优雅的装饰器，帮助你瞬间洞察函数的执行耗时和内存峰值占用。

为什么选择 PerfLens？

零依赖：只使用 Python 标准库，不污染你的环境。

极简 API：只需一行 @measure。

直观输出：直接在终端打印美观的性能报告。

快速开始

将 perflens.py 放入你的项目中，然后像这样使用：

from perflens import measure

@measure
def process_data():
    # 模拟一个吃内存和耗时的操作
    data = [x**2 for x in range(1000000)]
    return sum(data)

process_data()


输出示例：

🚀 [PerfLens] 函数 'process_data' 执行完毕:
   ⏱️  耗时: 0.1234 秒
   💾 峰值内存: 38.5123 MB
