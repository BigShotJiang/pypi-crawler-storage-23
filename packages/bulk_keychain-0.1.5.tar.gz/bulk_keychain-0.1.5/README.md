# bulk-keychain

A simple high perf signing lib for BULK txns - Python bindings.

## Installation

```bash
pip install bulk-keychain
```

## Quick Start

```python
from bulk_keychain import Keypair, Signer

# Generate a new keypair
keypair = Keypair()
print(f"Public key: {keypair.pubkey}")

# Or import from base58
# keypair = Keypair.from_base58("your-secret-key...")

# Create a signer
signer = Signer(keypair)

# Sign a limit order
signed = signer.sign({
    "type": "order",
    "symbol": "BTC-USD",
    "is_buy": True,
    "price": 100000.0,
    "size": 0.1,
    "order_type": {"type": "limit", "tif": "GTC"}
})

# Submit to API
import requests
response = requests.post(
    "https://api.bulk.exchange/api/v1/order",
    json={
        "actions": signed["actions"],
        "nonce": signed["nonce"],
        "account": signed["account"],
        "signer": signed["signer"],
        "signature": signed["signature"],
    }
)
```

## Order Types

### Limit Order

```python
{
    "type": "order",
    "symbol": "BTC-USD",
    "is_buy": True,
    "price": 100000.0,
    "size": 0.1,
    "order_type": {"type": "limit", "tif": "GTC"}  # GTC, IOC, or ALO
}
```

### Market Order

```python
{
    "type": "order",
    "symbol": "BTC-USD",
    "is_buy": True,
    "price": 0.0,
    "size": 0.1,
    "order_type": {"type": "market", "is_market": True, "trigger_px": 0.0}
}
```

### Cancel Order

```python
{
    "type": "cancel",
    "symbol": "BTC-USD",
    "order_id": "order-id-base58"
}
```

### Cancel All Orders

```python
{
    "type": "cancel_all",
    "symbols": ["BTC-USD"]  # or [] for all symbols
}
```

## Batch Signing

For high-frequency trading, sign many transactions in parallel:

```python
# Sign all at once - each order becomes one transaction
signed_txs = signer.sign_all(orders)
```

For multi-order atomic transactions, batch `order_ids` are optional:

```python
signer.set_compute_batch_order_ids(True)  # default False for max performance
grouped = signer.sign_group([entry_order, stop_loss, take_profit])
print(grouped.get("order_ids"))
```

## API Reference

### Keypair

```python
# Generate new keypair
keypair = Keypair()

# Import from base58
keypair = Keypair.from_base58("secret-key-base58")

# Import from bytes (32 or 64 bytes)
keypair = Keypair.from_bytes(bytes_data)

# Properties and methods
keypair.pubkey          # Public key as base58 string
keypair.to_base58()     # Full keypair as base58 (64 bytes)
keypair.to_bytes()      # Full keypair as bytes
keypair.secret_key()    # Secret key as bytes (32 bytes)
```

### Signer

```python
# Create signer
signer = Signer(keypair)
signer = Signer.from_base58("secret-key-base58")

# With nonce management 
signer = Signer.with_nonce_manager(keypair, "timestamp")     # Use timestamp
signer = Signer.with_nonce_manager(keypair, "counter")       # Use counter
signer = Signer.with_nonce_manager(keypair, "high_frequency") # Timestamp + counter

# Optional ID computation controls
signer.set_compute_order_id(True)            # default True
signer.set_compute_batch_order_ids(False)    # default False
signer.computes_order_id()
signer.computes_batch_order_ids()

# Sign operations
signed = signer.sign(order, nonce=None)
signed = signer.sign_group([order1, order2], nonce=None)
signed = signer.sign_faucet(nonce=None)
signed = signer.sign_agent_wallet(agent_pubkey, delete=False, nonce=None)
signed = signer.sign_user_settings(max_leverage=[("BTC-USD", 5.0)], nonce=None)
signed = signer.sign_oracle_prices([(1704067200000000000, "BTC-USD", 102500.0)], nonce=None)
signed = signer.sign_pyth_oracle([(1704067200000000000, 1, 10250000000000, -8)], nonce=None)
signed = signer.sign_whitelist_faucet(target_pubkey, whitelist=True, nonce=None)
signed_list = signer.sign_all(orders, base_nonce=None)
```

Tuple formats:
- `sign_oracle_prices`: `(timestamp, asset, price)`
- `sign_pyth_oracle`: `(timestamp, feed_index, price, exponent)`

### Utilities

```python
from bulk_keychain import random_hash, current_timestamp, validate_pubkey, validate_hash

# Generate random hash for client order IDs
client_id = random_hash()

# Get current timestamp in milliseconds
ts = current_timestamp()

# Validate base58 strings
is_valid = validate_pubkey("pubkey-base58")
is_valid = validate_hash("hash-base58")
```
