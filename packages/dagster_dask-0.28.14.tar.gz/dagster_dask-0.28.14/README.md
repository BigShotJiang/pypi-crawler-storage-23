# dagster-dask

The docs for `dagster-dask` can be found
[here](https://docs.dagster.io/integrations/libraries/dask/dagster-dask).
