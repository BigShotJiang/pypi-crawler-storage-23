from typing import Any


def human_friendly_bytes_size(size: int) -> str:
    """Convert a bytes size to a human friendly string using binary units."""
    if size < 1024:
        value, unit = f"{size}", "B"
    elif size < 1024 * 1024:
        value, unit = f"{size / 1024:.1f}", "KiB"
    elif size < 1024 * 1024 * 1024:
        value, unit = f"{size / (1024 * 1024):.1f}", "MiB"
    elif size < 1024 * 1024 * 1024 * 1024:
        value, unit = f"{size / (1024 * 1024 * 1024):.1f}", "GiB"
    else:
        value, unit = f"{size / (1024 * 1024 * 1024 * 1024):.1f}", "TiB"

    return f"{value.replace('.0', '')} {unit}"


def remove_none_values(data: dict[str, Any]) -> dict[str, Any]:
    """Remove None values from a dictionary."""
    return {k: v for k, v in data.items() if v is not None}
