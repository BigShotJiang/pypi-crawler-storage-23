"""PowerPoint utilities for Microsoft toolkits.

Implementation notes:
- Use raw httpx for /content endpoints (SDK doesn't stream well)
- Honor ARCADE_MICROSOFT_GRAPH_BASE_URL env var for URL construction
- Follow same patterns as word_utils.py
"""

import mimetypes
import os
import re
from dataclasses import dataclass
from enum import IntEnum
from io import BytesIO
from pathlib import Path
from typing import Any, cast
from urllib.parse import quote

import httpx
from arcade_mcp_server import Context
from arcade_mcp_server.exceptions import ToolExecutionError
from msgraph.generated.models.drive_item import DriveItem
from pptx import Presentation

from arcade_microsoft_utils.client import get_client
from arcade_microsoft_utils.drive_utils import (
    _ensure_download_size_under_limit as _ensure_download_size_under_limit_generic,
)
from arcade_microsoft_utils.exceptions import (
    ConflictError,
    DocumentLockedError,
    PresentationConversionError,
    SizeLimitExceededError,
    UnsupportedPresentationTypeError,
)

PPTX_MIME_TYPE = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
MAX_UPLOAD_BYTES = 4 * 1024 * 1024
_DEFAULT_MAX_DOWNLOAD_MB = 20
GRAPH_BASE_URL_DEFAULT = "https://graph.microsoft.com/v1.0"
_ALLOWED_CONFLICT_BEHAVIORS = {"fail", "rename", "replace"}


class SlideLayout(IntEnum):
    """Standard PowerPoint slide layouts (indices 0-10 in default template)."""

    TITLE = 0
    TITLE_AND_CONTENT = 1
    SECTION_HEADER = 2
    TWO_CONTENT = 3
    COMPARISON = 4
    TITLE_ONLY = 5
    BLANK = 6
    CONTENT_WITH_CAPTION = 7
    PICTURE_WITH_CAPTION = 8
    TITLE_AND_VERTICAL_TEXT = 9
    VERTICAL_TITLE_AND_TEXT = 10


# === URL Building ===


def _get_graph_base_url() -> str:
    """Get Graph API base URL, honoring env var override."""
    base_url = os.getenv("ARCADE_MICROSOFT_GRAPH_BASE_URL", GRAPH_BASE_URL_DEFAULT)
    return base_url.rstrip("/")


def _build_drive_base_url(drive_id: str | None) -> str:
    """Build Graph API base URL based on drive_id.

    - drive_id=None: returns /me/drive (OneDrive)
    - drive_id provided: returns /drives/{drive_id} (SharePoint)
    """
    base_url = _get_graph_base_url()
    if drive_id:
        return f"{base_url}/drives/{drive_id}"
    return f"{base_url}/me/drive"


def _build_item_url(item_id: str, drive_id: str | None = None) -> str:
    """Build URL for a specific drive item."""
    return f"{_build_drive_base_url(drive_id)}/items/{item_id}"


def _build_upload_url(
    title: str,
    folder_id: str | None,
    drive_id: str | None = None,
    conflict_behavior: str | None = None,
) -> str:
    """Build URL for uploading a presentation."""
    encoded_title = quote(title)
    base_url = _build_drive_base_url(drive_id)
    if folder_id:
        url = f"{base_url}/items/{folder_id}:/{encoded_title}:/content"
    else:
        url = f"{base_url}/root:/{encoded_title}:/content"

    normalized_conflict_behavior = _normalize_conflict_behavior(conflict_behavior)
    if normalized_conflict_behavior:
        encoded_behavior = quote(normalized_conflict_behavior, safe="")
        url = f"{url}?@microsoft.graph.conflictBehavior={encoded_behavior}"

    return url


# === Validation Helpers ===


def _normalize_pptx_title(title: str) -> str:
    """Normalize a presentation title to ensure it ends with .pptx."""
    normalized = title.strip()
    if not normalized:
        raise ToolExecutionError("Title is required.")

    while normalized.lower().endswith(".pptx"):
        normalized = normalized[:-5].strip()

    if not normalized:
        raise ToolExecutionError("Title is required.")

    return f"{normalized}.pptx"


def _normalize_conflict_behavior(conflict_behavior: str | None) -> str | None:
    """Normalize and validate conflict behavior parameter."""
    if conflict_behavior is None:
        return None
    normalized = conflict_behavior.strip().lower()
    if not normalized or normalized not in _ALLOWED_CONFLICT_BEHAVIORS:
        raise ToolExecutionError("conflict_behavior must be one of: fail, rename, replace.")
    return normalized


def _require_non_empty(value: str, label: str) -> str:
    """Validate that a string value is non-empty."""
    normalized = value.strip()
    if not normalized:
        raise ToolExecutionError(f"{label} is required.")
    return normalized


def _is_pptx_drive_item(item: DriveItem) -> bool:
    """Check if a drive item is a PowerPoint presentation."""
    if item.file and item.file.mime_type:
        return item.file.mime_type == PPTX_MIME_TYPE
    if item.name:
        return item.name.lower().endswith(".pptx")
    return False


def _describe_drive_item_file_type(item: DriveItem) -> str:
    """Get a human-readable description of a drive item's file type."""
    mime_type = None
    if item.file and item.file.mime_type:
        mime_type = item.file.mime_type
        extension = mimetypes.guess_extension(mime_type)
        if extension:
            return extension
        return mime_type

    if item.name:
        suffix = Path(item.name).suffix
        if suffix:
            return suffix.lower()

    return mime_type or "unknown"


def _ensure_pptx_drive_item(item: DriveItem) -> None:
    """Ensure a drive item is a PowerPoint presentation, raise if not."""
    if not _is_pptx_drive_item(item):
        raise UnsupportedPresentationTypeError(_describe_drive_item_file_type(item))


def _ensure_download_size_under_limit(item: DriveItem) -> None:
    """Check the drive item's reported size against the PowerPoint download limit.

    Configurable via ARCADE_PPTX_MAX_DOWNLOAD_MB (default: 20 MB).

    Raises DownloadSizeLimitExceededError if the file is too large to
    download and process in memory.
    """
    _ensure_download_size_under_limit_generic(
        item, env_var="ARCADE_PPTX_MAX_DOWNLOAD_MB", default_mb=_DEFAULT_MAX_DOWNLOAD_MB
    )


def _ensure_payload_under_limit(payload: bytes) -> None:
    """Ensure payload is below the 4MB simple upload limit."""
    if len(payload) >= MAX_UPLOAD_BYTES:
        raise SizeLimitExceededError()


# === Drive Item Operations ===


async def _get_presentation_drive_item(
    context: Context, item_id: str, drive_id: str | None = None
) -> DriveItem:
    """Get drive item metadata for a presentation (includes etag)."""
    client = get_client(context.get_auth_token_or_empty())
    if not drive_id:
        drive = await client.me.drive.get()
        if not drive or not drive.id:
            raise ToolExecutionError("Drive not found for the current user.")
        drive_id = cast(str, drive.id)

    response = await client.drives.by_drive_id(drive_id).items.by_drive_item_id(item_id).get()
    if not response:
        raise ToolExecutionError(
            "Drive or presentation not found. Verify the item_id and drive_id."
        )
    return cast(DriveItem, response)


# === Download/Upload (use raw httpx, not SDK) ===


async def _download_presentation_content(
    context: Context, item_id: str, drive_id: str | None = None
) -> bytes:
    """Download .pptx file content as bytes using raw httpx."""
    url = f"{_build_item_url(item_id, drive_id)}/content"
    async with httpx.AsyncClient(follow_redirects=True) as http_client:
        response = await http_client.get(
            url,
            headers={
                "Authorization": f"Bearer {context.get_auth_token_or_empty()}",
            },
        )
        response.raise_for_status()
    return response.content


async def _upload_presentation_content(
    context: Context, url: str, payload: bytes, etag: str | None = None
) -> dict[str, Any]:
    """Upload .pptx bytes using raw httpx. Uses If-Match with etag if provided."""
    headers = {
        "Authorization": f"Bearer {context.get_auth_token_or_empty()}",
        "Content-Type": PPTX_MIME_TYPE,
    }
    if etag:
        headers["If-Match"] = etag

    async with httpx.AsyncClient() as http_client:
        response = await http_client.put(
            url,
            headers=headers,
            content=payload,
        )
        if response.status_code == 423:
            raise DocumentLockedError()
        if response.status_code == 412:
            raise ConflictError()
        response.raise_for_status()
    return cast(dict[str, Any], response.json())


# === PPTX Manipulation (pure python-pptx, no network) ===


def _build_blank_pptx_bytes(title: str | None = None) -> bytes:
    """Create a new blank presentation with optional title slide.

    Args:
        title: Optional title for the first slide. If provided, creates a title slide.

    Returns:
        bytes: The presentation as bytes.
    """
    prs = Presentation()

    if title:
        # Add a title slide
        title_slide_layout = prs.slide_layouts[SlideLayout.TITLE]
        slide = prs.slides.add_slide(title_slide_layout)
        title_shape = slide.shapes.title
        if title_shape:
            title_shape.text = title

    buffer = BytesIO()
    prs.save(buffer)
    return buffer.getvalue()


# Placeholder types that represent text-bearing body/content areas.
# Used to find the body placeholder by type rather than by hardcoded index,
# which is more robust across templates where idx values may differ.
_BODY_PLACEHOLDER_TYPES: set[int] = set()


def _init_body_placeholder_types() -> set[int]:
    """Lazily initialise the set of placeholder types considered 'body'.

    Importing from ``pptx.enum.shapes`` at module level would fail type
    checking in packages that don't depend on python-pptx directly, so
    the import is deferred.
    """
    global _BODY_PLACEHOLDER_TYPES
    if not _BODY_PLACEHOLDER_TYPES:
        from pptx.enum.shapes import PP_PLACEHOLDER

        _BODY_PLACEHOLDER_TYPES = {
            int(PP_PLACEHOLDER.BODY),  # 2 — Section Header, Caption layouts, etc.
            int(PP_PLACEHOLDER.OBJECT),  # 7 — Title and Content, Two Content, etc.
            int(PP_PLACEHOLDER.SUBTITLE),  # 4 — Title Slide subtitle area
        }
    return _BODY_PLACEHOLDER_TYPES


def _find_body_placeholder(slide: Any) -> Any | None:
    """Find the first text-bearing body/content placeholder on a slide.

    Uses placeholder *type* (BODY, OBJECT, SUBTITLE) rather than a
    hardcoded index so that custom templates with non-standard placeholder
    indices are handled correctly.

    The title placeholder (type TITLE / CENTER_TITLE) is excluded because
    it is handled separately via ``slide.shapes.title``.
    """
    body_types = _init_body_placeholder_types()

    from pptx.enum.shapes import PP_PLACEHOLDER

    title_types = {int(PP_PLACEHOLDER.TITLE), int(PP_PLACEHOLDER.CENTER_TITLE)}

    for shape in slide.placeholders:
        ph_type = int(shape.placeholder_format.type)
        if ph_type in body_types and ph_type not in title_types and shape.has_text_frame:
            return shape
    return None


def _build_pptx_from_slides(
    title: str,
    slides: list[dict[str, str]],
) -> bytes:
    """Create a presentation from structured slide data.

    Args:
        title: Presentation title (used for the title slide).
        slides: List of slide dictionaries with 'title' and 'body' keys.

    Returns:
        bytes: The presentation as bytes.
    """
    prs = Presentation()

    # Add title slide
    title_slide_layout = prs.slide_layouts[SlideLayout.TITLE]
    title_slide = prs.slides.add_slide(title_slide_layout)
    title_shape = title_slide.shapes.title
    if title_shape:
        title_shape.text = title

    # Add content slides
    content_layout = prs.slide_layouts[SlideLayout.TITLE_AND_CONTENT]
    for slide_data in slides:
        slide = prs.slides.add_slide(content_layout)

        # Set slide title
        if slide.shapes.title and slide_data.get("title"):
            slide.shapes.title.text = slide_data["title"]

        # Set slide body content
        if slide_data.get("body"):
            body_placeholder = _find_body_placeholder(slide)
            if body_placeholder:
                body_placeholder.text = slide_data["body"]

    buffer = BytesIO()
    prs.save(buffer)
    return buffer.getvalue()


def _add_slide_to_pptx(
    content: bytes,
    slide_title: str | None = None,
    slide_body: str | None = None,
    layout: SlideLayout = SlideLayout.TITLE_AND_CONTENT,
) -> bytes:
    """Add a new slide to an existing presentation.

    Args:
        content: Existing presentation as bytes.
        slide_title: Optional title for the new slide.
        slide_body: Optional body content for the new slide.
        layout: Slide layout to use (default: TITLE_AND_CONTENT).

    Returns:
        bytes: The modified presentation as bytes.
    """
    prs = Presentation(BytesIO(content))

    # Get the layout (with fallback to first available if index out of range)
    try:
        slide_layout = prs.slide_layouts[layout]
    except IndexError:
        slide_layout = prs.slide_layouts[0]

    slide = prs.slides.add_slide(slide_layout)

    # Set title if the layout has a title placeholder and title is provided
    if slide.shapes.title and slide_title:
        slide.shapes.title.text = slide_title

    # Set body content if layout has a body placeholder and body is provided
    if slide_body:
        body_placeholder = _find_body_placeholder(slide)
        if body_placeholder:
            body_placeholder.text = slide_body

    buffer = BytesIO()
    prs.save(buffer)
    return buffer.getvalue()


def _add_two_content_slide_to_pptx(
    content: bytes,
    slide_title: str | None = None,
    left_body: str | None = None,
    right_body: str | None = None,
) -> bytes:
    """Add a TWO_CONTENT slide with left and right content areas.

    Args:
        content: Existing presentation as bytes.
        slide_title: Optional title for the new slide.
        left_body: Optional content for the left placeholder.
        right_body: Optional content for the right placeholder.

    Returns:
        bytes: The modified presentation as bytes.
    """
    prs = Presentation(BytesIO(content))

    # Get the TWO_CONTENT layout
    try:
        slide_layout = prs.slide_layouts[SlideLayout.TWO_CONTENT]
    except IndexError:
        # Fallback to TITLE_AND_CONTENT if TWO_CONTENT not available
        slide_layout = prs.slide_layouts[SlideLayout.TITLE_AND_CONTENT]

    slide = prs.slides.add_slide(slide_layout)

    # Set title if provided
    if slide.shapes.title and slide_title:
        slide.shapes.title.text = slide_title

    # Find left and right content placeholders.
    # Both are OBJECT type in the TWO_CONTENT layout, so we use index-based
    # lookup (idx 1 = left, idx 2 = right) to distinguish them.  This is
    # correct for the default template; custom templates may differ.
    left_placeholder = None
    right_placeholder = None

    for shape in slide.placeholders:
        idx = shape.placeholder_format.idx
        if idx == 1:
            left_placeholder = shape
        elif idx == 2:
            right_placeholder = shape

    # Set left content
    if left_placeholder and left_body:
        left_placeholder.text = left_body

    # Set right content
    if right_placeholder and right_body:
        right_placeholder.text = right_body

    buffer = BytesIO()
    prs.save(buffer)
    return buffer.getvalue()


# === Conversion ===


def _convert_pptx_to_markdown(content: bytes) -> str:
    """Convert .pptx bytes to markdown representation.

    Uses a "best effort" approach:
    - Tables: Full markdown table with all cell data
    - Charts: Markdown table with title, categories, series data
    - Images: [Image: {filename}] placeholder
    - SmartArt: [SmartArt diagram - content not extractable]
    - Video/Audio: [Video/Audio: {filename}] placeholder
    - Text: Full text with formatting preserved where possible

    Args:
        content: PowerPoint presentation as bytes.

    Returns:
        str: Markdown representation of the presentation.
    """
    try:
        prs = Presentation(BytesIO(content))
    except Exception as exc:
        raise PresentationConversionError() from exc

    markdown_parts: list[str] = []

    for slide_num, slide in enumerate(prs.slides, start=1):
        slide_parts: list[str] = []
        slide_title = ""

        # Extract title
        if slide.shapes.title and slide.shapes.title.text:
            slide_title = slide.shapes.title.text.strip()

        # Add slide header
        if slide_title:
            slide_parts.append(f"## Slide {slide_num}: {slide_title}")
        else:
            slide_parts.append(f"## Slide {slide_num}")

        slide_parts.append("")

        # Process shapes
        for shape in slide.shapes:
            shape_content = _convert_shape_to_markdown(shape)
            if shape_content:
                slide_parts.append(shape_content)

        markdown_parts.append("\n".join(slide_parts))

    return "\n\n---\n\n".join(markdown_parts)


def _convert_shape_to_markdown(shape: Any) -> str:
    """Convert a single shape to markdown."""
    parts: list[str] = []

    # Handle tables
    if shape.has_table:
        parts.append(_convert_table_to_markdown(shape.table))

    # Handle charts
    elif shape.has_chart:
        parts.append(_convert_chart_to_markdown(shape.chart))

    # Handle text frames (but skip title placeholders which are handled separately
    # as the slide header).  CENTER_TITLE is the title shape on "Title Slide"
    # layouts, so it must be excluded alongside the regular TITLE.
    elif shape.has_text_frame:
        from pptx.enum.shapes import PP_PLACEHOLDER

        _TITLE_TYPES = {int(PP_PLACEHOLDER.TITLE), int(PP_PLACEHOLDER.CENTER_TITLE)}
        is_title_placeholder = (
            hasattr(shape, "is_placeholder")
            and shape.is_placeholder
            and int(shape.placeholder_format.type) in _TITLE_TYPES
        )
        if not is_title_placeholder:
            text = _convert_text_frame_to_markdown(shape.text_frame)
            if text.strip():
                parts.append(text)

    # Handle pictures/images
    elif hasattr(shape, "image"):
        try:
            filename = getattr(shape.image, "filename", None) or f"image.{shape.image.ext}"
            parts.append(f"[Image: {filename}]")
        except Exception:
            parts.append("[Image: embedded image]")

    # Handle media (video/audio)
    elif hasattr(shape, "media_type"):
        media_type = getattr(shape, "media_type", "media")
        parts.append(f"[{media_type.capitalize()}: embedded media]")

    return "\n".join(parts)


def _convert_table_to_markdown(table: Any) -> str:
    """Convert a table to markdown format."""
    if not table.rows:
        return ""

    rows: list[list[str]] = []
    for row in table.rows:
        cells: list[str] = []
        for cell in row.cells:
            cell_text = cell.text.replace("|", "\\|").replace("\n", " ").strip()
            cells.append(cell_text)
        rows.append(cells)

    if not rows:
        return ""

    # Build markdown table
    md_lines: list[str] = []

    # Header row
    header = rows[0]
    md_lines.append("| " + " | ".join(header) + " |")

    # Separator
    md_lines.append("| " + " | ".join(["---"] * len(header)) + " |")

    # Data rows
    for row in rows[1:]:
        # Pad row if needed
        while len(row) < len(header):
            row.append("")
        md_lines.append("| " + " | ".join(row[: len(header)]) + " |")

    return "\n".join(md_lines)


def _convert_chart_to_markdown(chart: Any) -> str:
    """Convert a chart to markdown table format."""
    parts: list[str] = []

    # Get chart title if available
    if chart.has_title and chart.chart_title.has_text_frame:
        title_text = chart.chart_title.text_frame.text.strip()
        if title_text:
            parts.append(f"**Chart: {title_text}**")
            parts.append("")

    # Try to extract chart data
    try:
        if hasattr(chart, "plots") and chart.plots:
            plot = chart.plots[0]

            # Get categories
            categories = list(plot.categories) if hasattr(plot, "categories") else []

            if categories and hasattr(plot, "series"):
                # Build header: Category + series names
                series_list = list(plot.series)
                series_names = [s.name or f"Series {i + 1}" for i, s in enumerate(series_list)]
                header = ["Category", *series_names]

                parts.append("| " + " | ".join(header) + " |")
                parts.append("| " + " | ".join(["---"] * len(header)) + " |")

                # Build data rows
                for cat_idx, category in enumerate(categories):
                    row = [str(category)]
                    for series in series_list:
                        try:
                            values = list(series.values)
                            if cat_idx < len(values):
                                row.append(str(values[cat_idx]))
                            else:
                                row.append("")
                        except Exception:
                            row.append("")
                    parts.append("| " + " | ".join(row) + " |")
            else:
                parts.append("[Chart: data not extractable]")
        else:
            parts.append("[Chart: data not extractable]")
    except Exception:
        parts.append("[Chart: data not extractable]")

    return "\n".join(parts) if parts else "[Chart: embedded chart]"


def _has_bullet_xml(para: Any) -> bool:
    """Check whether a paragraph has an explicit bullet marker in its XML.

    Inspects the ``<a:pPr>`` element for ``<a:buChar>`` or ``<a:buAutoNum>``.
    Returns False when ``<a:buNone>`` is present (bullets explicitly suppressed)
    or when no bullet element exists.
    """
    try:
        from pptx.oxml.ns import qn

        pPr = para._p.find(qn("a:pPr"))
        if pPr is None:
            return False
        # Explicit "no bullet" wins
        if pPr.find(qn("a:buNone")) is not None:
            return False
        return pPr.find(qn("a:buChar")) is not None or pPr.find(qn("a:buAutoNum")) is not None
    except Exception:
        return False


def _has_no_bullet_xml(para: Any) -> bool:
    """Check whether a paragraph explicitly suppresses bullets via ``<a:buNone>``.

    Returns True only when ``<a:buNone>`` is present in the paragraph
    properties. Used to prevent the ``para.level > 0`` fallback from
    incorrectly treating indented-but-non-bullet text as a bullet.
    """
    try:
        from pptx.oxml.ns import qn

        pPr = para._p.find(qn("a:pPr"))
        if pPr is None:
            return False
        return pPr.find(qn("a:buNone")) is not None
    except Exception:
        return False


def _convert_text_frame_to_markdown(text_frame: Any) -> str:
    """Convert a text frame to markdown.

    Detects bullet paragraphs via XML inspection (``<a:buChar>`` /
    ``<a:buAutoNum>``), which works reliably at every indentation level
    including level 0.
    """
    paragraphs: list[str] = []

    for para in text_frame.paragraphs:
        para_text = ""
        for run in para.runs:
            text = run.text
            if not text:
                continue

            # Apply formatting
            if run.font.bold:
                text = f"**{text}**"
            if run.font.italic:
                text = f"*{text}*"
            if run.font.underline:
                text = f"<u>{text}</u>"

            para_text += text

        if para_text.strip():
            # Detect bullets: XML markers are authoritative.  Fall back to
            # level > 0 only when no explicit buNone suppresses it.
            is_bullet = _has_bullet_xml(para) or (para.level > 0 and not _has_no_bullet_xml(para))

            if is_bullet:
                indent = "  " * para.level
                para_text = f"{indent}- {para_text}"

            paragraphs.append(para_text)

    return "\n".join(paragraphs)


def _get_slide_count(content: bytes) -> int:
    """Get the number of slides in a presentation."""
    try:
        prs = Presentation(BytesIO(content))
        return len(prs.slides)
    except Exception:
        return 0


# =============================================================================
# Speaker Notes Functions
# =============================================================================


@dataclass
class _TextRun:
    """Represents a text run with formatting."""

    text: str
    bold: bool = False
    italic: bool = False
    underline: bool = False


@dataclass
class _ParsedParagraph:
    """A parsed markdown paragraph with level, bullet flag, and formatted runs."""

    level: int
    is_bullet: bool
    runs: list[_TextRun]


def _parse_markdown_line(line: str) -> list[_TextRun]:
    """Parse a single line of markdown into formatted text runs.

    Supports: **bold**, *italic*, __underline__ (using double underscore for underline).
    Falls back to plain text if parsing fails.
    """
    runs: list[_TextRun] = []

    # Pattern to match formatting: **bold**, *italic*, __underline__
    # We process in order: bold first, then underline, then italic
    pattern = re.compile(
        r"(\*\*(.+?)\*\*)"  # **bold**
        r"|(__(.+?)__)"  # __underline__
        r"|(\*(.+?)\*)"  # *italic*
        r"|([^*_]+)"  # plain text
    )

    for match in pattern.finditer(line):
        if match.group(2):  # **bold**
            runs.append(_TextRun(text=match.group(2), bold=True))
        elif match.group(4):  # __underline__
            runs.append(_TextRun(text=match.group(4), underline=True))
        elif match.group(6):  # *italic*
            runs.append(_TextRun(text=match.group(6), italic=True))
        elif match.group(7):  # plain text
            runs.append(_TextRun(text=match.group(7)))

    return runs if runs else [_TextRun(text=line)]


def _parse_markdown_to_paragraphs(
    markdown: str,
) -> list[_ParsedParagraph]:
    """Parse markdown text into paragraphs with formatting.

    Returns a list of ``_ParsedParagraph`` objects carrying indent level,
    a bullet flag, and formatted text runs.

    Level mapping:
        - ``- Bullet``       → level 0, is_bullet=True
        - ``  - Nested``     → level 1, is_bullet=True  (2 spaces per level)
        - ``Plain text``     → level 0, is_bullet=False
    """
    paragraphs: list[_ParsedParagraph] = []

    for line in markdown.split("\n"):
        if not line.strip():
            continue

        # Check for bullet points (- or *)
        bullet_match = re.match(r"^(\s*)([-*])\s+(.*)$", line)
        if bullet_match:
            indent = len(bullet_match.group(1))
            level = indent // 2  # 0 spaces → level 0, 2 spaces → level 1, etc.
            content = bullet_match.group(3)
            runs = _parse_markdown_line(content)
            paragraphs.append(_ParsedParagraph(level=level, is_bullet=True, runs=runs))
        else:
            # Regular paragraph (level 0)
            runs = _parse_markdown_line(line.strip())
            paragraphs.append(_ParsedParagraph(level=0, is_bullet=False, runs=runs))

    return paragraphs


def _apply_markdown_to_text_frame(text_frame: Any, markdown: str) -> None:
    """Apply markdown-formatted text to a PowerPoint text frame.

    Converts markdown to formatted runs with bold, italic, underline.
    Supports bullet points with explicit XML markers so that PowerPoint
    renders them correctly (including level-0 bullets).
    """
    from pptx.oxml.ns import qn

    # Clear existing content
    text_frame.clear()

    paragraphs = _parse_markdown_to_paragraphs(markdown)

    for i, pg in enumerate(paragraphs):
        para = text_frame.paragraphs[0] if i == 0 else text_frame.add_paragraph()

        # Set indentation level
        para.level = pg.level

        # Explicitly set or suppress bullet markers in the XML so that
        # PowerPoint renders bullets correctly at every level (including 0).
        pPr = para._p.get_or_add_pPr()
        # Remove any existing bullet elements to avoid conflicts
        for tag in (qn("a:buNone"), qn("a:buChar"), qn("a:buAutoNum")):
            existing = pPr.find(tag)
            if existing is not None:
                pPr.remove(existing)

        if pg.is_bullet:
            from lxml import etree

            bu = etree.SubElement(pPr, qn("a:buChar"))
            bu.set("char", "\u2022")  # bullet character •
        else:
            from lxml import etree

            etree.SubElement(pPr, qn("a:buNone"))

        # Add formatted runs
        for j, run_data in enumerate(pg.runs):
            if j == 0 and not para.runs:
                # Use existing run for first segment
                para.text = ""
            run = para.add_run()
            run.text = run_data.text
            run.font.bold = run_data.bold
            run.font.italic = run_data.italic
            run.font.underline = run_data.underline


def _get_slide_notes_as_markdown(content: bytes, slide_index: int) -> str:
    """Get speaker notes from a slide as markdown.

    Args:
        content: The presentation bytes.
        slide_index: 1-based slide index.

    Returns:
        The notes as markdown text, or empty string if no notes.

    Raises:
        ToolExecutionError: If slide_index is out of range.
    """
    prs = Presentation(BytesIO(content))
    slides = list(prs.slides)

    if slide_index < 1 or slide_index > len(slides):
        raise ToolExecutionError(
            f"Slide index {slide_index} is out of range. Presentation has {len(slides)} slides."
        )

    slide = slides[slide_index - 1]

    if not slide.has_notes_slide:
        return ""

    notes_slide = slide.notes_slide
    text_frame = notes_slide.notes_text_frame

    # Try to convert to markdown, fall back to plain text
    try:
        result: str = _convert_text_frame_to_markdown(text_frame)
    except Exception:
        # Fallback: extract plain text
        return str(text_frame.text) if text_frame.text else ""
    else:
        return result


def _set_slide_notes_from_markdown(content: bytes, slide_index: int, notes_markdown: str) -> bytes:
    """Set speaker notes on a slide from markdown.

    Args:
        content: The presentation bytes.
        slide_index: 1-based slide index.
        notes_markdown: The notes in markdown format.

    Returns:
        The modified presentation bytes.

    Raises:
        ToolExecutionError: If slide_index is out of range.
    """
    prs = Presentation(BytesIO(content))
    slides = list(prs.slides)

    if slide_index < 1 or slide_index > len(slides):
        raise ToolExecutionError(
            f"Slide index {slide_index} is out of range. Presentation has {len(slides)} slides."
        )

    slide = slides[slide_index - 1]
    notes_slide = slide.notes_slide  # Creates if doesn't exist
    text_frame = notes_slide.notes_text_frame

    # Try to apply markdown formatting, fall back to plain text
    try:
        _apply_markdown_to_text_frame(text_frame, notes_markdown)
    except Exception:
        # Fallback: set as plain text
        text_frame.text = notes_markdown

    # Save and return
    output = BytesIO()
    prs.save(output)
    return output.getvalue()


def _get_all_slide_notes_as_markdown(content: bytes) -> list[dict[str, Any]]:
    """Get speaker notes from all slides in a presentation.

    Args:
        content: The presentation bytes.

    Returns:
        A list of dicts with slide_index, has_notes, and notes (markdown) for each slide.
    """
    prs = Presentation(BytesIO(content))
    slides = list(prs.slides)
    results: list[dict[str, Any]] = []

    for i, slide in enumerate(slides, start=1):
        notes = ""
        has_notes = False

        if slide.has_notes_slide:
            notes_slide = slide.notes_slide
            text_frame = notes_slide.notes_text_frame

            try:
                notes = _convert_text_frame_to_markdown(text_frame)
            except Exception:
                # Fallback: extract plain text
                notes = text_frame.text if text_frame.text else ""

            has_notes = bool(notes.strip())

        results.append({
            "slide_index": i,
            "has_notes": has_notes,
            "notes": notes,
        })

    return results
