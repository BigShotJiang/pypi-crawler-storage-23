"""
Project package root.
"""