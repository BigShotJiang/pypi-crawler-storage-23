# Usage

To use SpatialCompassV in a project:

```python
import scomv
```
