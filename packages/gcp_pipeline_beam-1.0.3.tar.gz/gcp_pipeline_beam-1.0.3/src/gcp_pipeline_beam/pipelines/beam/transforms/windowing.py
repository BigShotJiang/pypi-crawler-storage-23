"""
Windowing and Triggering Module

Reusable PTransforms for applying windowing and triggering strategies to PCollections.
"""

from typing import Optional, Union, Any

import apache_beam as beam
from apache_beam.transforms import window
from apache_beam.transforms.trigger import (
    AfterWatermark,
    AfterProcessingTime,
    AfterCount,
    Repeatedly,
    OrFinally,
    AfterEach,
    AfterAll
)


class ApplyWindowing(beam.PTransform):
    """
    A reusable PTransform to apply windowing and triggering strategies.

    Support Fixed, Sliding, and Session windows with configurable lateness,
    accumulation mode, and triggers.

    Example:
        >>> pcoll | ApplyWindowing(
        ...     window_type='fixed',
        ...     size=60,
        ...     allowed_lateness=120,
        ...     accumulation_mode='accumulating'
        ... )
    """

    def __init__(
        self,
        window_type: str,
        size: Optional[int] = None,
        period: Optional[int] = None,
        gap: Optional[int] = None,
        allowed_lateness: int = 0,
        accumulation_mode: str = 'discarding',
        trigger: Any = None
    ):
        """
        Initialize ApplyWindowing.

        Args:
            window_type: 'fixed', 'sliding', or 'session'
            size: Window size in seconds (for fixed and sliding)
            period: Window period in seconds (for sliding)
            gap: Session gap in seconds (for session)
            allowed_lateness: Allowed lateness in seconds
            accumulation_mode: 'discarding' or 'accumulating'
            trigger: Optional Beam TriggerFn
        """
        super().__init__()
        self.window_type = window_type.lower()
        self.size = size
        self.period = period
        self.gap = gap
        self.allowed_lateness = allowed_lateness
        self.accumulation_mode = accumulation_mode.lower()
        self.trigger = trigger

    def expand(self, pcoll: beam.PCollection) -> beam.PCollection:
        if self.window_type == 'fixed':
            if self.size is None:
                raise ValueError("Size must be provided for fixed windows")
            window_fn = window.FixedWindows(self.size)
        elif self.window_type == 'sliding':
            if self.size is None or self.period is None:
                raise ValueError("Size and period must be provided for sliding windows")
            window_fn = window.SlidingWindows(self.size, self.period)
        elif self.window_type == 'session':
            if self.gap is None:
                raise ValueError("Gap must be provided for session windows")
            window_fn = window.Sessions(self.gap)
        else:
            raise ValueError(f"Unsupported window_type: {self.window_type}")

        acc_mode = (
            beam.transforms.trigger.AccumulationMode.ACCUMULATING
            if self.accumulation_mode == 'accumulating'
            else beam.transforms.trigger.AccumulationMode.DISCARDING
        )

        try:
            return pcoll | beam.WindowInto(
                window_fn,
                trigger=self.trigger,
                accumulation_mode=acc_mode,
                allowed_lateness=float(self.allowed_lateness)
            )
        except (TypeError, Exception):
            # Fallback for internal Beam type check failures in some environments (e.g., Python 3.10+ with older Beam)
            # We disable type checking for the entire pipeline if it fails during this transform
            try:
                # Try to get TypeOptions if available
                type_options = pcoll.pipeline.options.view_as(beam.options.pipeline_options.TypeOptions)
                if type_options:
                    type_options.pipeline_type_check = False
            except Exception:
                pass
                
            return pcoll | beam.WindowInto(
                window_fn,
                trigger=self.trigger,
                accumulation_mode=acc_mode,
                allowed_lateness=float(self.allowed_lateness)
            )
