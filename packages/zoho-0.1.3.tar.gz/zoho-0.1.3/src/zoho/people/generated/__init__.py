"""Generated Zoho People code namespace."""
