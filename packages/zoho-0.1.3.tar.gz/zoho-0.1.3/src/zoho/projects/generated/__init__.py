"""Generated Projects code namespace (expands in later releases)."""
