"""Generated CRM code namespace.

v0.1.3 includes codegen scaffolding and fixtures; generated runtime modules will
expand as coverage increases.
"""
