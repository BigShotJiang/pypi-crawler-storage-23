"""SDK helper CLI scripts."""
