import sys
from google.oauth2 import service_account
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
import pandas as pd
import base64
import pickle
from typing import Optional, Dict, Any, Union
import json
import os
import io
import time

class XGoogleDriveReader:
    """Class to handle Google Drive operations and read Google Sheets"""
    
    SCOPES = ['https://www.googleapis.com/auth/drive',
              'https://www.googleapis.com/auth/spreadsheets']
    
    def __init__(self, auth_file_path: str = 'auth/service-account-gdrive.json',
                 scopes: list = SCOPES):
        """
        Initialize the GoogleDriveReader with service account credentials.

        This method sets up the necessary credentials to interact with Google Drive and Google Sheets APIs.
        It resolves the path to the service account JSON file, loads the credentials, and initializes
        internal attributes for the service objects.

        Args:
            auth_file_path (str): Path to the service account JSON file. This can be a relative path
                (relative to this script) or an absolute path. Defaults to 'auth/service-account-gdrive.json'.
            scopes (list): A list of OAuth 2.0 scopes to request. Defaults to Drive and Spreadsheets scopes.

        Raises:
            ValueError: If the authentication file cannot be loaded or parsed.
        """
        try:
            # Get absolute path if relative path provided
            if not os.path.isabs(auth_file_path):
                current_dir = os.path.dirname(os.path.abspath(__file__))
                auth_file_path = os.path.join(current_dir, auth_file_path)
            
            # Load credentials from JSON file
            with open(auth_file_path, 'r') as f:
                self.credentials = json.load(f)
                
            self.creds = None
            self.service = None
            self.sheets_service = None
            self.scopes = scopes
            
        except Exception as e:
            raise ValueError(f"Failed to load authentication file: {str(e)}")

    def authenticate(self) -> bool:
        """
        Authenticate with Google Drive and Google Sheets APIs using the loaded service account credentials.

        This method creates the `Credentials` object from the loaded JSON data and builds the
        service objects for Google Drive (v3) and Google Sheets (v4).

        Process Flow:
            1. Create credentials from service account info.
            2. Build the Drive API service.
            3. Build the Sheets API service.
            4. Print success or failure message.

        Returns:
            bool: True if authentication and service creation were successful, False otherwise.
        """
        try:

            self.creds = service_account.Credentials.from_service_account_info(
                self.credentials,
                scopes=self.scopes
            )
            
            self.service = build('drive', 'v3', credentials=self.creds)
            self.sheets_service = build('sheets', 'v4', credentials=self.creds)
            print(f"[Line 81] Successfully authenticated with service account")
            return True
            
        except Exception as e:
            print(f"[Line 85] Authentication failed: {str(e)}")
            return False
    
    def get_file_id(self, file_path: str, mime_type: str = None) -> Optional[str]:
        """
        Retrieve the Google Drive file ID for a given file path.

        This method traverses the folder structure defined in `file_path` to find the specific file.
        It handles nested folders by resolving parent IDs sequentially.

        Process Flow:
            1. Split the file path into parts (folders and filename).
            2. Construct a query to find the file by name.
            3. If a MIME type is provided, add it to the query.
            4. If the file is in a folder (not root), resolve the parent folder's ID first.
            5. Execute the search query.
            6. Return the ID of the first matching file found.

        Args:
            file_path (str): The full path to the file in Google Drive (e.g., 'folder1/folder2/filename').
            mime_type (str, optional): A specific MIME type to filter the search (e.g., 'application/vnd.google-apps.spreadsheet').

        Returns:
            Optional[str]: The unique File ID string if found, otherwise None.
        """
        try:
            path_parts = file_path.strip('/').split('/')
            file_name = path_parts[-1]
            parent_path = '/'.join(path_parts[:-1])
            
            # Build query
            query = f"name='{file_name}'"
            if mime_type:
                query += f" and mimeType='{mime_type}'"
            
            # Add parent folder constraints if path provided
            if parent_path:
                parent_id = self._get_folder_id(parent_path)
                if parent_id:
                    query += f" and '{parent_id}' in parents"
                    
            results = self.service.files().list(
                q=query,
                fields="files(id, name)").execute()
            items = results.get('files', [])
            
            if not items:
                print(f"[Line 132] File '{file_path}' not found")
                return None
                
            return items[0]['id']
            
        except Exception as e:
            print(f"[Line 138] Error getting file ID: {str(e)}")
            return None

    def _get_folder_id(self, folder_path: str) -> Optional[str]:
        """
        Retrieve the Google Drive folder ID for a given folder path.

        This helper method traverses the directory structure from the root to find the ID of the target folder.

        Process Flow:
            1. Start at the 'root' folder.
            2. Iterate through each folder name in the path.
            3. For each folder, query for a folder with that name having the current parent ID.
            4. Update the current parent ID to the found folder's ID.
            5. Repeat until the target folder is reached.

        Args:
            folder_path (str): The path to the folder (e.g., 'folder1/folder2').

        Returns:
            Optional[str]: The unique Folder ID string if found, otherwise None.
        """
        try:
            current_parent = 'root'
            
            for folder in folder_path.split('/'):
                query = f"name='{folder}' and mimeType='application/vnd.google-apps.folder'"
                if current_parent != 'root':
                    query += f" and '{current_parent}' in parents"
                    
                results = self.service.files().list(
                    q=query,
                    fields="files(id)").execute()
                items = results.get('files', [])
                
                if not items:
                    print(f"[Line 174] Folder '{folder}' not found in path '{folder_path}'")
                    return None
                    
                current_parent = items[0]['id']
                
            return current_parent
            
        except Exception as e:
            print(f"[Line 182] Error getting folder ID: {str(e)}")
            return None

    def _col_index_to_letter(self, index: int) -> str:
        """
        Convert a 0-based column index to its corresponding Excel-style column letter.

        Args:
            index (int): The 0-based index of the column (e.g., 0 for 'A', 25 for 'Z', 26 for 'AA').

        Returns:
            str: The column letter(s) corresponding to the index.
        """
        result = ""
        while index >= 0:
            result = chr(65 + (index % 26)) + result
            index = index // 26 - 1
        return result

    def _col_str_to_index(self, col_str: str) -> int:
        """
        Convert an Excel-style column letter string to its corresponding 0-based index.

        Args:
            col_str (str): The column letter string (e.g., 'A', 'Z', 'AA').

        Returns:
            int: The 0-based index corresponding to the column letter.
        """
        num = 0
        for c in col_str:
            if 'A' <= c.upper() <= 'Z':
                num = num * 26 + (ord(c.upper()) - ord('A') + 1)
        return num - 1

    def _parse_range_string(self, range_str: str) -> tuple:
        """
        Parse a Google Sheets range string to extract the starting row and column indices.

        This method handles range strings that may include sheet names (e.g., 'Sheet1!A1:B2')
        or just cell references (e.g., 'A1').

        Args:
            range_str (str): The range string to parse.

        Returns:
            tuple: A tuple containing (start_row, start_col) as 0-based integers.
                   Returns (0, 0) if parsing fails.
        """
        try:
            if '!' in range_str:
                range_str = range_str.split('!')[-1]
            
            start_cell = range_str.split(':')[0]
            
            col_str = ""
            row_str = ""
            for char in start_cell:
                if char.isalpha():
                    col_str += char
                elif char.isdigit():
                    row_str += char
            
            start_col = self._col_str_to_index(col_str)
            start_row = int(row_str) - 1 if row_str else 0
            
            return start_row, start_col
        except:
            return 0, 0

    def _get_last_row_with_data(self, 
                                file_id: str, 
                                sheet_name: str, 
                                column: str = 'A') -> Optional[int]:
        """
        Find the last row number that contains data in a specific column.

        This method reads the entire column and iterates through the values to find the last non-empty cell.

        Process Flow:
            1. Construct a range string for the specified column (e.g., 'Sheet1!A:A').
            2. Fetch values from the API.
            3. Iterate through the values to find the last index with non-empty content.

        Args:
            file_id (str): The Google Sheet file ID.
            sheet_name (str): The name of the sheet to scan.
            column (str): The column letter to check (default is 'A').

        Returns:
            Optional[int]: The 1-based row number of the last row with data. Returns None if no data is found.
        """
        try:
            # Read all values in the column
            range_str = f"'{sheet_name}'!{column}:{column}"
            
            result = self.sheets_service.spreadsheets().values().get(
                spreadsheetId=file_id,
                range=range_str
            ).execute()
            
            values = result.get('values', [])
            if not values:
                return None
            
            # Find the last non-empty cell
            last_row = None
            for idx, row in enumerate(values):
                if row and any(str(cell).strip() for cell in row):
                    last_row = idx + 1  # Convert to 1-based indexing
            
            return last_row
            
        except Exception as e:
            print(f"[Line 296] Error getting last row with data: {str(e)}")
            return None

    def _expand_column_range_to_cell_range(self,
                                          file_id: str,
                                          sheet_name: str,
                                          column_range: str) -> Optional[str]:
        """
        Convert a column-only range (e.g., 'A:DM') into a specific cell range (e.g., 'A1:DM4100').

        This is useful for defining a bounded range for export or reading when only the columns are known.
        It determines the bottom boundary by finding the last row with data in the start column.

        Process Flow:
            1. Parse the start and end columns from the input range.
            2. Call `_get_last_row_with_data` on the start column to find the data height.
            3. Construct the full cell range string using the found last row.

        Args:
            file_id (str): The Google Sheet file ID.
            sheet_name (str): The name of the sheet.
            column_range (str): The column range string (e.g., 'A:DM').

        Returns:
            Optional[str]: The expanded cell range string (e.g., 'A1:DM4100'), or None if an error occurs.
        """
        try:
            if ':' not in column_range:
                print(f"[Line 324] Invalid column range format: {column_range}. Expected format: 'A:DM'")
                return None
            
            start_col, end_col = column_range.split(':')
            start_col = start_col.strip().upper()
            end_col = end_col.strip().upper()
            
            # Get last row with data in start column
            last_row = self._get_last_row_with_data(file_id, sheet_name, start_col)
            
            if last_row is None:
                print(f"[Line 335] No data found in column {start_col}")
                return None
            
            # Construct the cell range
            cell_range = f"{start_col}1:{end_col}{last_row}"
            print(f"[Line 340] Expanded column range '{column_range}' to cell range '{cell_range}'")
            
            return cell_range
            
        except Exception as e:
            print(f"[Line 345] Error expanding column range: {str(e)}")
            return None

    def _auto_detect_export_range(self,
                                 file_id: str,
                                 sheet_name: str) -> Optional[str]:
        """
        Auto-detect the effective data range in a sheet for export purposes.

        This method analyzes the sheet's data to determine the bounding box of non-empty cells,
        ignoring empty rows/columns outside the main data block.

        Process Flow:
            1. Read all values from the sheet.
            2. Normalize row lengths.
            3. Scan for the first column index containing data.
            4. Scan for the last column index containing data.
            5. Find the last row with data in the first detected column.
            6. Find the last row with data in the last detected column.
            7. Determine the start row (checking if row 1 is empty).
            8. Construct the range string using the detected boundaries.

        Args:
            file_id (str): The Google Sheet file ID.
            sheet_name (str): The name of the sheet.

        Returns:
            Optional[str]: The detected cell range string (e.g., 'D1:ZZ100'), or None if no data is found.
        """
        try:
            # Read all values in the sheet
            range_str = f"'{sheet_name}'"
            
            result = self.sheets_service.spreadsheets().values().get(
                spreadsheetId=file_id,
                range=range_str
            ).execute()
            
            values = result.get('values', [])
            if not values:
                print("[Line 385] No data found in sheet for auto-detection")
                return None
            
            # Normalize to find dimensions
            max_cols = max(len(row) for row in values) if values else 0
            if max_cols == 0:
                print("[Line 391] No data found in sheet")
                return None
            
            # Pad rows to same length
            normalized_values = []
            for row in values:
                normalized_row = list(row) if row else []
                while len(normalized_row) < max_cols:
                    normalized_row.append('')
                normalized_values.append(normalized_row)
            
            # Find first column with any data
            first_col_idx = None
            for col_idx in range(max_cols):
                for row_idx in range(len(normalized_values)):
                    if str(normalized_values[row_idx][col_idx]).strip():
                        first_col_idx = col_idx
                        break
                if first_col_idx is not None:
                    break
            
            if first_col_idx is None:
                print("[Line 413] No data found in sheet")
                return None
            
            # Find last column with any data
            last_col_idx = None
            for col_idx in range(max_cols - 1, -1, -1):
                for row_idx in range(len(normalized_values)):
                    if str(normalized_values[row_idx][col_idx]).strip():
                        last_col_idx = col_idx
                        break
                if last_col_idx is not None:
                    break
            
            if last_col_idx is None:
                last_col_idx = first_col_idx
            
            # Find last row in first column
            last_row_first_col = None
            for row_idx in range(len(normalized_values) - 1, -1, -1):
                if str(normalized_values[row_idx][first_col_idx]).strip():
                    last_row_first_col = row_idx + 1  # Convert to 1-based
                    break
            
            # Find last row in last column
            last_row_last_col = None
            for row_idx in range(len(normalized_values) - 1, -1, -1):
                if str(normalized_values[row_idx][last_col_idx]).strip():
                    last_row_last_col = row_idx + 1  # Convert to 1-based
                    break
            
            if last_row_first_col is None:
                last_row_first_col = 1
            if last_row_last_col is None:
                last_row_last_col = 1
            
            # Determine start row: check if row 1 has any data
            start_row = 1
            if len(normalized_values) > 0:
                has_data_in_row1 = any(
                    str(cell).strip() for cell in normalized_values[0]
                )
                if not has_data_in_row1:
                    # Row 1 is empty, find first non-empty row
                    for row_idx in range(len(normalized_values)):
                        if any(str(cell).strip() for cell in normalized_values[row_idx]):
                            start_row = row_idx + 1
                            break
            
            # Use maximum row from both columns
            max_row = max(last_row_first_col, last_row_last_col)
            
            # Convert indices to column letters
            first_col_letter = self._col_index_to_letter(first_col_idx)
            last_col_letter = self._col_index_to_letter(last_col_idx)
            
            # Construct range
            auto_range = f"{first_col_letter}{start_row}:{last_col_letter}{max_row}"
            print(f"[Line 470] Auto-detected export range: {auto_range}")
            print(f"[Line 471]   - First column with data: {first_col_letter}")
            print(f"[Line 472]   - Last column with data: {last_col_letter}")
            print(f"[Line 473]   - Start row: {start_row}")
            print(f"[Line 474]   - Max row: {max_row} (first_col: {last_row_first_col}, last_col: {last_row_last_col})")
            
            return auto_range
            
        except Exception as e:
            print(f"[Line 479] Error auto-detecting export range: {str(e)}")
            return None

    def read_sheet(self, 
                   file_path: str, 
                   sheet_name: Optional[str] = None,
                   range_name: Optional[str] = None,
                   header_row: int = 0,
                   fill_empty_cells: bool = True,
                   fill_merged_cells: bool = False) -> Optional[pd.DataFrame]:
        """
        Read data from a Google Sheet into a pandas DataFrame.

        This method handles fetching data, parsing headers, normalizing row lengths,
        and optionally handling merged cells and empty cell filling.

        Process Flow:
            1. Resolve the file ID from the file path.
            2. Determine the target sheet (by name or default to first).
            3. Fetch data values from the specified range.
            4. If the range doesn't start at A1, optionally fetch separate header rows.
            5. Normalize data (pad rows to equal length).
            6. If `fill_merged_cells` is True, process sheet metadata to fill merged ranges.
            7. Detect the header row if not explicitly set.
            8. Create a pandas DataFrame using the detected header and data.
            9. Apply forward fill (`ffill`) if `fill_empty_cells` is True.

        Args:
            file_path (str): Full path to the file in Google Drive.
            sheet_name (Optional[str]): Name of the specific sheet to read. Defaults to the first sheet.
            range_name (Optional[str]): Specific A1 notation range to read (e.g., 'A1:B10'). Defaults to the entire sheet.
            header_row (int): The 0-based index of the row to use as the header. Defaults to 0.
            fill_empty_cells (bool): If True, fills empty cells using forward fill (propagating the last valid observation forward). Defaults to True.
            fill_merged_cells (bool): If True, fills the content of merged cells into all cells within the merge range. Defaults to False.

        Returns:
            Optional[pd.DataFrame]: A pandas DataFrame containing the sheet data, or None if reading fails or no data is found.
        """
        try:
            # Get file ID
            file_id = self.get_file_id(file_path)
            if not file_id:
                return None
            
            # Get sheet properties
            sheet_metadata = self.sheets_service.spreadsheets().get(
                spreadsheetId=file_id).execute()
            
            target_sheet = None
            if not sheet_name:
                target_sheet = sheet_metadata['sheets'][0]
                sheet_name = target_sheet['properties']['title']
            else:
                for s in sheet_metadata['sheets']:
                    if s['properties']['title'] == sheet_name:
                        target_sheet = s
                        break
            
            # Construct range
            range_str = f"'{sheet_name}'"
            if range_name:
                range_str += f"!{range_name}"
            
            # Read data
            result = self.sheets_service.spreadsheets().values().get(
                spreadsheetId=file_id,
                range=range_str).execute()
            
            values = result.get('values', [])
            if not values:
                print("[Line 549] No data found in sheet")
                return None
            else:
                print(f"Data retrieved: {len(values)} rows")
                print(f"First 5 rows: {values[:5]}")
            
            # If range_name is specified and doesn't start at row 1, read headers separately
            header_values = None
            if range_name and not range_name.lower().startswith('a1'):
                try:
                    # Parse the range to check starting row
                    start_row, start_col = self._parse_range_string(range_name)
                    if start_row > 0:  # If not starting from row 1, fetch headers
                        # Build header range (from row 1 to the start of data range, same columns)
                        col_end = range_name.split(':')[-1] if ':' in range_name else range_name
                        # Extract end column from range
                        col_letters = ''.join(c for c in col_end if c.isalpha())
                        header_range_str = f"'{sheet_name}'!A1:{col_letters}{start_row}"
                        
                        header_result = self.sheets_service.spreadsheets().values().get(
                            spreadsheetId=file_id,
                            range=header_range_str).execute()
                        header_values = header_result.get('values', [])
                        print(f"Header rows retrieved: {len(header_values) if header_values else 0} rows")
                except:
                    pass
            
            # Skip completely empty rows at the start
            first_non_empty_idx = 0
            for idx, row in enumerate(values):
                if any(str(cell).strip() for cell in row):
                    first_non_empty_idx = idx
                    break
            
            values = values[first_non_empty_idx:]
            if not values:
                print("No data found in sheet")
                return None
            
            # First, normalize all rows to same length
            max_cols = max(len(row) for row in values) if values else 0
            if max_cols == 0:
                print("No data found in sheet")
                return None
            
            # Include header rows if they were read separately
            if header_values:
                # Normalize header rows
                for row in header_values:
                    while len(row) < max_cols:
                        row.append('')
                values = header_values + values
                print(f"[Line 601] Total rows after adding headers: {len(values)}")
                
            normalized_values = []
            for row in values:
                normalized_row = list(row) if row else []
                # Pad with empty strings to reach max_cols
                while len(normalized_row) < max_cols:
                    normalized_row.append('')
                normalized_values.append(normalized_row)
            
            # Handle Merged Cells - fill merged cell ranges with the first cell value (optional)
            if fill_merged_cells and target_sheet:
                merges = target_sheet.get('merges', [])
                if merges:
                    # Parse range offset
                    actual_range = result.get('range', '')
                    start_row_offset, start_col_offset = self._parse_range_string(actual_range)
                    
                    # Adjust offset by removed empty rows
                    start_row_offset = max(0, start_row_offset - first_non_empty_idx)
                    
                    for merge in merges:
                        start_row = merge.get('startRowIndex', 0)
                        end_row = merge.get('endRowIndex', start_row + 1)
                        start_col = merge.get('startColumnIndex', 0)
                        end_col = merge.get('endColumnIndex', start_col + 1)
                        
                        # Adjust to relative coordinates
                        rel_start_row = start_row - start_row_offset - first_non_empty_idx
                        rel_end_row = end_row - start_row_offset - first_non_empty_idx
                        rel_start_col = start_col - start_col_offset
                        rel_end_col = end_col - start_col_offset
                        
                        # Check bounds and fill
                        if (0 <= rel_start_row < len(normalized_values) and 
                            0 <= rel_start_col < max_cols):
                            fill_value = normalized_values[rel_start_row][rel_start_col]
                            
                            r_start = max(0, rel_start_row)
                            r_end = min(len(normalized_values), rel_end_row)
                            c_start = max(0, rel_start_col)
                            c_end = min(max_cols, rel_end_col)
                            
                            for r in range(r_start, r_end):
                                for c in range(c_start, c_end):
                                    if not normalized_values[r][c]:
                                        normalized_values[r][c] = fill_value
            
            # Auto-detect header row if all values in first row are empty
            detected_header_row = header_row
            if detected_header_row == 0 and not any(str(cell).strip() for cell in normalized_values[0]):
                # First row is empty, try to find next non-empty row as header
                for idx in range(1, min(5, len(normalized_values))):
                    if any(str(cell).strip() for cell in normalized_values[idx]):
                        detected_header_row = idx
                        break
            
            # If headers were read separately, use the last header row
            if header_values:
                detected_header_row = len(header_values) - 1
            
            if detected_header_row >= len(normalized_values):
                detected_header_row = 0
            
            header = normalized_values[detected_header_row]
            data = normalized_values[detected_header_row + 1:]
            
            # Generate column names, preserving existing header values
            column_names = []
            unnamed_idx = 0
            for i, col in enumerate(header):
                col_str = str(col).strip() if col else ''
                if col_str:
                    # Lowercase and replace spaces with underscores for consistency
                    column_names.append(col_str.lower().replace(' ', '_'))
                else:
                    column_names.append(f"col_{i}")
                    unnamed_idx += 1
            
            # Ensure all column names are unique
            seen_names = {}
            for i, name in enumerate(column_names):
                if name in seen_names:
                    seen_names[name] += 1
                    column_names[i] = f"{name}_{seen_names[name]}"
                else:
                    seen_names[name] = 0
            
            # Filter out completely empty rows from data
            filtered_data = []
            for row in data:
                if any(str(cell).strip() for cell in row):
                    filtered_data.append(row)
            
            if not filtered_data:
                print("[Line 675] No data rows found in sheet")
                return None
            
            # Create DataFrame with normalized data
            df = pd.DataFrame(filtered_data, columns=column_names)
            
            # Fill empty strings with NaN for better data handling (optional for exports)
            # For exports, we want to preserve original cell values as-is
            if fill_empty_cells or fill_merged_cells:
                df = df.replace('', pd.NA)
            
            # Apply forward fill on empty cells if requested
            if fill_empty_cells:
                df = df.ffill(axis=0)
            
            print(f"[Line 688] Successfully read {len(df)} rows with {len(df.columns)} columns")
            return df
            
        except Exception as e:
            print(f"[Line 692] Error reading sheet: {str(e)}")
            return None

    def download_file(self, 
                     file_path: str, 
                     local_path: str,
                     mime_type: str = None) -> bool:
        """
        Download a file from Google Drive to the local filesystem.

        This method supports downloading binary files directly or exporting Google Workspace documents
        (like Docs, Sheets) to a specified MIME type.

        Process Flow:
            1. Resolve the file ID from the file path.
            2. Ensure the local directory exists.
            3. If `mime_type` is provided, use the `export_media` API (for Workspace files).
            4. Otherwise, use the `get_media` API (for binary files).
            5. Stream the download in chunks and write to the local path.

        Args:
            file_path (str): Full path to the file in Google Drive.
            local_path (str): The local file system path where the file will be saved.
            mime_type (str, optional): The MIME type to export to (e.g., 'application/pdf'). Required for Google Docs/Sheets.

        Returns:
            bool: True if the download completes successfully, False otherwise.
        """
        try:
            # Get file ID using the new method
            file_id = self.get_file_id(file_path)
            if not file_id:
                print(f"[Line 745] File not found: {file_path}")
                return False

            # Create local directory if it doesn't exist
            os.makedirs(os.path.dirname(local_path), exist_ok=True)

            # Download the file
            if mime_type:
                # Export Google Workspace files
                request = self.service.files().export_media(
                    fileId=file_id,
                    mimeType=mime_type
                )
            else:
                # Download regular files
                request = self.service.files().get_media(
                    fileId=file_id
                )

            # Stream the file content
            fh = io.BytesIO()
            downloader = MediaIoBaseDownload(fh, request)
            done = False

            while not done:
                status, done = downloader.next_chunk()
                if status:
                    print(f"[Line 741] Download progress: {int(status.progress() * 100)}%")

            # Save the file
            fh.seek(0)
            with open(local_path, 'wb') as f:
                f.write(fh.read())
                f.flush()

            print(f"[Line 747] File downloaded successfully to: {local_path}")
            return True

        except Exception as e:
            print(f"[Line 750] Error downloading file: {str(e)}")
            return False

    def list_files(self, folder_path: str = '') -> Optional[list]:
        """
        Recursively list all files and subfolders within a specified Google Drive folder.

        Process Flow:
            1. Resolve the folder ID for the given path (or use 'root').
            2. Construct a query to list non-trashed items in the parent folder.
            3. Iterate through pages of results.
            4. For each item, determine if it is a file or folder.
            5. If it is a folder, recursively call `list_files` on it.
            6. Aggregate and return the list of file objects.

        Args:
            folder_path (str): The path to the folder in Google Drive. Empty string '' denotes the root folder.

        Returns:
            Optional[list]: A list of dictionaries, where each dictionary represents a file/folder with keys:
                - 'name': The name of the file/folder.
                - 'id': The Google Drive ID.
                - 'type': 'file' or 'folder'.
                - 'path': The full path relative to the search root.
                Returns None if an error occurs.
        """
        try:
            # Get folder ID for the path
            folder_id = 'root' if not folder_path else self._get_folder_id(folder_path)
            if folder_path and not folder_id:
                return None

            # Build query to list all files/folders in the directory
            query = f"'{folder_id}' in parents and trashed=false"
            
            # Get list of all files/folders
            results = []
            page_token = None
            
            while True:
                response = self.service.files().list(
                    q=query,
                    spaces='drive',
                    fields='nextPageToken, files(id, name, mimeType)',
                    pageToken=page_token
                ).execute()
                
                for file in response.get('files', []):
                    file_type = 'folder' if file['mimeType'] == 'application/vnd.google-apps.folder' else 'file'
                    file_path = os.path.join(folder_path, file['name']) if folder_path else file['name']
                    
                    results.append({
                        'name': file['name'],
                        'id': file['id'],
                        'type': file_type,
                        'path': file_path
                    })
                    
                    # Recursively list files in subfolders
                    if file_type == 'folder':
                        sub_files = self.list_files(file_path)
                        if sub_files:
                            results.extend(sub_files)
                
                page_token = response.get('nextPageToken')
                if not page_token:
                    break
            
            return results
            
        except Exception as e:
            print(f"[Line 857] Error listing files: {str(e)}")
            return None

    def rename_file(self, file_path: str, new_name: str) -> bool:
        """
        Rename a specific file in Google Drive.

        Process Flow:
            1. Resolve the file ID from the current file path.
            2. Create a metadata object with the new name.
            3. Call the Drive API `update` method to apply the name change.

        Args:
            file_path (str): Full path to the existing file in Google Drive.
            new_name (str): The new name to assign to the file (name only, not path).

        Returns:
            bool: True if the rename operation was successful, False otherwise.
        """
        try:
            # Get file ID
            file_id = self.get_file_id(file_path)
            if not file_id:
                print(f"[Line 880] File not found: {file_path}")
                return False

            # Create file metadata with new name
            file_metadata = {'name': new_name}

            # Update file metadata
            file = self.service.files().update(
                fileId=file_id,
                body=file_metadata,
                fields='id, name'
            ).execute()

            print(f"[Line 891] File renamed successfully to: {file.get('name')}")
            return True

        except Exception as e:
            print(f"[Line 895] Error renaming file: {str(e)}")
            return False

    def export_sheet_to_excel(self, 
                          file_path: str, 
                          local_path: str,
                          sheet_name: Optional[str] = None,
                          range_name: Optional[str] = None,
                          output_sheet_name: Optional[str] = 'Sheet1',
                          mime_type: str = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                          initial_timeout: int = 30,
                          max_timeout: int = 300,
                          fill_empty_cells: bool = False,
                          fill_merged_cells: bool = False,
                          ) -> bool:
        """
        Export a Google Sheet (or specific range) to a local Excel file.

        This method handles two main scenarios:
        1. Exporting a specific sheet or range: Reads the data into a DataFrame and saves it as Excel.
           This supports auto-detection of data ranges and column expansion.
        2. Exporting the entire spreadsheet: Uses the Drive API `export` method to download the whole file as .xlsx.

        Process Flow:
            - If `sheet_name` or `range_name` is provided:
                1. Resolve file ID.
                2. Handle column-only ranges (expand to cell ranges).
                3. Handle auto-detection if range is missing but sheet is specified.
                4. Read data using `read_sheet`.
                5. Save DataFrame to Excel using pandas.
            - If neither is provided (export whole file):
                1. Resolve file ID.
                2. Use Drive API to export as 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'.
                3. Download in chunks with adaptive timeout handling.

        Args:
            file_path (str): Full path to the Google Sheet in Google Drive.
            local_path (str): Local path where the Excel file will be saved.
            sheet_name (Optional[str]): Name of the specific sheet to export.
            range_name (Optional[str]): Range to export (e.g., 'A1:B10' or 'A:B'). If None, may auto-detect.
            output_sheet_name (Optional[str]): Name for the sheet in the output Excel file. Defaults to 'Sheet1' or original sheet name.
            mime_type (str): MIME type for the export (default is Excel).
            initial_timeout (int): Initial timeout in seconds for download chunks. Defaults to 30.
            max_timeout (int): Maximum timeout in seconds for download chunks. Defaults to 300.
            fill_empty_cells (bool): Whether to fill empty cells in the exported data. Defaults to False.
            fill_merged_cells (bool): Whether to fill merged cells in the exported data. Defaults to False.

        Returns:
            bool: True if the export and download were successful, False otherwise.
        """
        try:
            # Create local directory if it doesn't exist
            local_dir = os.path.dirname(local_path)
            if local_dir and not os.path.exists(local_dir):
                os.makedirs(local_dir, exist_ok=True)
            
            # Set default output sheet name to the original sheet name if not specified
            final_output_sheet_name = output_sheet_name

            # If range_name or sheet_name is specified, use read_sheet approach
            # (Direct export API doesn't support range filtering)
            if sheet_name or range_name:
                # Get file ID if we need to process ranges
                file_id = None
                
                # Check if range_name is a column range (e.g., 'A:DM')
                if range_name and ':' in range_name and not any(c.isdigit() for c in range_name):
                    # This is a column range, need to expand it
                    if not file_id:
                        file_id = self.get_file_id(file_path)
                    if not file_id:
                        print(f"[Line 968] File not found: {file_path}")
                        return False
                    
                    # Use first sheet if no sheet_name specified
                    if not sheet_name:
                        sheet_metadata = self.sheets_service.spreadsheets().get(
                            spreadsheetId=file_id).execute()
                        sheet_name = sheet_metadata['sheets'][0]['properties']['title']
                    
                    # Expand column range to cell range
                    expanded_range = self._expand_column_range_to_cell_range(
                        file_id, sheet_name, range_name
                    )
                    if not expanded_range:
                        print(f"[Line 978] Failed to expand column range: {range_name}")
                        return False
                    
                    range_name = expanded_range
                
                # If no range_name provided, auto-detect it
                elif not range_name and sheet_name:
                    if not file_id:
                        file_id = self.get_file_id(file_path)
                    if not file_id:
                        print(f"[Line 988] File not found: {file_path}")
                        return False
                    
                    print(f"[Line 990] No range specified. Auto-detecting data boundaries...")
                    detected_range = self._auto_detect_export_range(file_id, sheet_name)
                    if detected_range:
                        range_name = detected_range
                    else:
                        print("[Line 1000] Warning: Could not auto-detect range. Proceeding without range.")
                
                # Set output sheet name to original sheet_name if not provided
                if not final_output_sheet_name:
                    final_output_sheet_name = sheet_name
                
                df = self.read_sheet(file_path, sheet_name=sheet_name, range_name=range_name, 
                                    fill_empty_cells=fill_empty_cells, fill_merged_cells=fill_merged_cells)
                if df is not None:
                    # Validate sheet name length (Excel limit is 31 characters)
                    if final_output_sheet_name and len(str(final_output_sheet_name)) > 31:
                        final_output_sheet_name = str(final_output_sheet_name)[:31]
                        print(f"[Line 1011] Output sheet name truncated to 31 characters: {final_output_sheet_name}")
                    
                    df.to_excel(local_path, sheet_name=final_output_sheet_name, index=False)
                    sheet_info = f"sheet '{sheet_name}'" if sheet_name else "sheet"
                    range_info = f" with range {range_name}" if range_name else ""
                    output_info = f" as '{final_output_sheet_name}'" if final_output_sheet_name else ""
                    print(f"[Line 1018] Successfully exported {sheet_info}{range_info}{output_info} to: {local_path}")
                    return True
                return False

            # Get the file ID from the path
            file_id = self.get_file_id(file_path)
        
            if not file_id:
                print(f"[Line 1025] File not found: {file_path}")
                return False
        
            # Export entire Google Sheet as Excel file (no range filtering available)
            request = self.service.files().export(
                fileId=file_id,
                mimeType=mime_type
            )
        
            # Download the file with increasing timeout
            with open(local_path, 'wb') as fh:
                downloader = MediaIoBaseDownload(fh, request)
                done = False
                chunk_num = 0
                current_timeout = initial_timeout
                
                while done is False:
                    # Calculate increasing timeout for each chunk
                    # Timeout increases gradually: 30s -> 45s -> 60s -> 90s -> ... -> max
                    current_timeout = min(initial_timeout + (chunk_num * 15), max_timeout)
                    chunk_num += 1
                    
                    try:
                        print(f"[Line 1043] Downloading chunk {chunk_num} (timeout: {current_timeout}s)...")
                        start_time = time.time()
                        
                        status, done = downloader.next_chunk()
                        
                        elapsed_time = time.time() - start_time
                        
                        if status:
                            progress = int(status.progress() * 100)
                            print(f"[Line 1051] Download progress: {progress}% (chunk time: {elapsed_time:.2f}s)")
                        
                    except Exception as chunk_error:
                        print(f"[Line 1055] Error downloading chunk {chunk_num}: {str(chunk_error)}")
                        if current_timeout >= max_timeout:
                            print(f"[Line 1057] Max timeout ({max_timeout}s) reached. Aborting download.")
                            return False
                        print(f"[Line 1059] Retrying with increased timeout: {current_timeout + 15}s")
                        continue
        
            print(f"[Line 1062] Successfully exported and downloaded to: {local_path}")
            return True
        
        except Exception as e:
            print(f"[Line 1066] Export failed: {str(e)}")
            return False

# Example usage
def read_sheet_from_gdrive():
    # Initialize reader with default auth file path
    reader = XGoogleDriveReader("./auth/hpmeis-7784af30c873.json")
    
    # Authenticate
    if reader.authenticate():
        df = reader.read_sheet(
            file_path="HPMEIS/sb/Monitored SWDAs by fo 7",
            sheet_name="FO Inventory",
            range_name="A2:AF76"
        )
        
        if df is not None:
            print(f"[Line 1090] {df.head()}")

def download_file_from_gdrive():
    reader = XGoogleDriveReader("./auth/hpmeis-7784af30c873.json")
    
    if reader.authenticate():
        # Download Google Sheet as Excel
        success = reader.download_file(
            file_path="HPMEIS/dswd_academy/sdca/1LGU TA PLAN Monitoring Sheet - Central Office",
            local_path="./my_sheet.xlsx"
        )
    print(f"[Line 1101] Download success: {success}")

def list_files_from_gdrive():
    """Example usage of list_files function"""
    reader = XGoogleDriveReader("/home/hadoop/tests/hpmeis-7784af30c873.json")
    # reader = XGoogleDriveReader("./auth/hpmeis-7784af30c873.json")

    if reader.authenticate():
        # List all files in a specific folder
        files = reader.list_files("HPMEIS/sb")
        
        if files:
            print(f"[Line 1117] \nFiles found:")
            for file in files:
                prefix = "📁" if file['type'] == 'folder' else "📄"
                print(f"[Line 1120] {prefix} {file['path']}")
                
def rename_file_in_gdrive():
    """Example usage of rename_file function"""
    reader = XGoogleDriveReader("./auth/service-account-gdrive.json")
    
    if reader.authenticate():
        # Rename a Google Sheet
        success = reader.rename_file(
            file_path="DSWD-Sheets/AICS 1.xlsx",
            # file_path="DSWD-Sheets/Chill",
            # new_name="BHill"
            new_name="BICS 1.xlsx"
        )
        
        # Or rename any other file
        # success = reader.rename_file(
        #     file_path="Documents/old_doc.pdf",
        #     new_name="new_doc.pdf"
        # )
        
    print(f"[Line 1138] Rename success: {success}")

def export_sheet_example():
    reader = XGoogleDriveReader("/home/hadoop/tests/hpmeis-7784af30c873.json")
    # reader = XGoogleDriveReader("./auth/hpmeis-7784af30c873-uat.json")
    # reader = XGoogleDriveReader("./auth/hpmeis-7784af30c873.json")
    # file_path="HPMEIS/sb/Monitored SWDAs by fo 7"
    # local_path="/home/hadoop/poc/Monitored SWDAs by fo 7.xlsx"
    # sheet_name='FO Inventory'
    # file_path = 'SANDATA/sfp/2025/Region IV-A (CALABARZON)/SFP Beneficiary Database_Batangas'
    # local_path = 'test/SFP Beneficiary Database_Batangas.xlsx'
    # sheet_name = 'DATABASE_CALABARZON'
    # file_path = 'SANDATA/sfp/2025/Region XIII (Caraga)/Agusan del Norte/LGU-Kitcharao'
    # local_path = 'test/LGU-Kitcharao.xlsx'
    # sheet_name = 'DATABASE_CARAGA'
    file_path = 'HPMEIS/crcf/CRCF_Facilities_Masterlist'
    local_path = 'test/crcf.xlsx'
    sheet_name = 'Summary By Facility'

    if reader.authenticate():
        # Export Google Sheet to Excel
        # Example 1: Without range - auto-detects data boundaries, uses original sheet name
        success = reader.export_sheet_to_excel(
            file_path=file_path,
            local_path=local_path,
            sheet_name=sheet_name
            # range_name omitted - auto-detection will find: first column, last column, and max row
            # output_sheet_name omitted - defaults to 'Summary By Facility'
        )
        
        print(f"[Line 1161] Export success (auto-detect): {success}")
        
        # Example 2: With custom output sheet name
        # success = reader.export_sheet_to_excel(
        #     file_path=file_path,
        #     local_path=local_path,
        #     sheet_name=sheet_name,
        #     output_sheet_name='CRCF Data'  # Custom name for the output sheet
        # )
        
        # Example 3: With column range - expands to A:DM
        # success = reader.export_sheet_to_excel(
        #     file_path=file_path,
        #     local_path=local_path,
        #     sheet_name=sheet_name,
        #     range_name='A:DM',  # Auto-expands to A1:DM[last_row]
        #     output_sheet_name='Data Export'  # Custom sheet name
        # )
        
        # Example 4: With explicit cell range
        # success = reader.export_sheet_to_excel(
        #     file_path=file_path,
        #     local_path=local_path,
        #     sheet_name=sheet_name,
        #     range_name='A1:DM4100',  # Explicit range
        #     output_sheet_name='Facilities'  # Custom sheet name
        # )

if __name__ == "__main__":
    if sys.argv[1] == 'read':
        read_sheet_from_gdrive()
    elif sys.argv[1] == 'download':
        download_file_from_gdrive()
    elif sys.argv[1] == 'list':
        list_files_from_gdrive()
    elif sys.argv[1] == 'rename':
        rename_file_in_gdrive()
    elif sys.argv[1] == 'export':
        export_sheet_example()