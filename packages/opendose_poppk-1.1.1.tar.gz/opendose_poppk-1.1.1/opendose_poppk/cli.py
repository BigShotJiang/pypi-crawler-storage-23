from __future__ import annotations

import argparse
import json
import platform
import sys
from pathlib import Path

import numpy as np

from . import CovariateModel, MAPEstimator, PDModel, PKModel, PopulationSimulator
from .benchmark import benchmark_regimen_across_drugs, write_benchmark_csv
from .cohort import load_cohort_csv, simulate_cohort, summarize_cohort, write_cohort_template_csv
from .database import DrugDatabase, validate_drug_csv
from .dose_sweep import sweep_dose_response
from .dosing import recommend_dose_for_target_auc, recommend_dose_for_target_cmax
from .external_validation import (
    build_external_validation_table,
    load_external_validation_csv,
    summarize_external_validation,
    write_external_validation_template_csv,
)
from .population_fit import bootstrap_population_pk, fit_population_pk
from .poppk_mixed import eta_table_from_fit, fit_population_mixed_effects
from .project_report import build_project_report, render_project_report_markdown
from .release_tools import build_release_readiness_report, render_release_readiness_markdown
from .regimen import simulate_regimen, summarize_regimen, write_regimen_csv, write_regimen_plot
from .regimen_dosing import (
    recommend_regimen_dose_for_target_cmax,
    recommend_regimen_dose_for_target_trough,
    recommend_regimen_dose_for_target_window,
)
from .sensitivity import local_pk_sensitivity
from .tdm import load_tdm_csv, summarize_tdm, write_tdm_template_csv
from .tdm_fit import (
    build_tdm_prediction_table,
    fit_tdm_patients,
    summarize_fit_table,
    summarize_prediction_table,
)
from .tdm_mixed import fit_tdm_mixed_by_drug, summarize_tdm_mixed_fit
from .tdm_report import write_tdm_fit_markdown_report, write_tdm_prediction_plot
from .validation_report import build_validation_report, render_validation_report_markdown
from .web_app import build_web_app_payload, run_web_app_server, write_web_app_html


def _default_dataset() -> str:
    return str(Path("datasets") / "drugs_parameters.csv")


def _parse_csv_floats(values: str) -> np.ndarray:
    return np.array([float(v.strip()) for v in values.split(",") if v.strip() != ""], dtype=float)


def _print_json(data: dict) -> None:
    print(json.dumps(data, indent=2, sort_keys=True))


def cmd_list_drugs(args: argparse.Namespace) -> int:
    db = DrugDatabase(args.dataset)
    for name in db.list_drugs():
        print(name)
    return 0


def cmd_validate_dataset(args: argparse.Namespace) -> int:
    df, summary = validate_drug_csv(args.dataset)
    output_clean = None
    if args.output_clean:
        out = Path(args.output_clean)
        out.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(out, index=False)
        output_clean = str(out)
    _print_json(
        {
            "command": "validate-dataset",
            "input": str(args.dataset),
            "output_clean": output_clean,
            **summary,
        }
    )
    return 0


def cmd_simulate(args: argparse.Namespace) -> int:
    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    dose = args.dose if args.dose is not None else drug.dose

    pk = PKModel(**drug.pk_kwargs)
    pd = None
    if drug.has_pd and not args.no_pd:
        pd = PDModel(drug.EC50, drug.n_hill)

    sim = PopulationSimulator(pk=pk, pd=pd, covariate_model=CovariateModel(pk), dose=dose)
    result = sim.run(
        n_subjects=args.n_subjects,
        t_max=args.t_max,
        n_points=args.n_points,
        seed=args.seed,
    )

    t = result["t"]
    p5 = result["percentiles_pk"][5]
    p50 = result["percentiles_pk"][50]
    p95 = result["percentiles_pk"][95]

    if args.output:
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        header = "time,p5,p50,p95"
        data = np.column_stack([t, p5, p50, p95])
        np.savetxt(out, data, delimiter=",", header=header, comments="")

    _print_json(
        {
            "command": "simulate",
            "drug": drug.name,
            "dose": float(dose),
            "n_subjects": int(args.n_subjects),
            "t_max": float(args.t_max),
            "n_points": int(args.n_points),
            "median_cmax": float(np.max(p50)),
            "pi90_cmax_low": float(np.max(p5)),
            "pi90_cmax_high": float(np.max(p95)),
            "output": str(args.output) if args.output else None,
        }
    )
    return 0


def cmd_simulate_iv(args: argparse.Namespace) -> int:
    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    pk = PKModel(**drug.pk_kwargs)
    t = np.linspace(0.0, float(args.t_end), int(args.n_points))

    payload_extra = {"mode": args.mode}
    if args.mode == "bolus":
        dose = float(args.dose) if args.dose is not None else float(drug.dose)
        c = pk.concentration_iv_bolus(t, dose=dose)
        payload_extra["dose"] = dose
    else:
        if args.infusion_rate is None:
            raise ValueError("Provide --infusion-rate for infusion mode")
        if args.infusion_duration_h is None:
            raise ValueError("Provide --infusion-duration-h for infusion mode")
        rate = float(args.infusion_rate)
        duration = float(args.infusion_duration_h)
        start = float(args.infusion_start_h)
        c = pk.concentration_iv_infusion(t, rate=rate, duration_h=duration, start_h=start)
        payload_extra["infusion_rate"] = rate
        payload_extra["infusion_duration_h"] = duration
        payload_extra["infusion_start_h"] = start
        payload_extra["infusion_total_dose"] = float(rate * duration)

    output_csv = None
    if args.output_csv:
        out = Path(args.output_csv)
        out.parent.mkdir(parents=True, exist_ok=True)
        np.savetxt(out, np.column_stack([t, c]), delimiter=",", header="time_h,conc", comments="")
        output_csv = str(out)

    idx = int(np.nanargmax(c))
    _print_json(
        {
            "command": "simulate-iv",
            "drug": drug.name,
            "t_end": float(args.t_end),
            "n_points": int(args.n_points),
            "cmax": float(c[idx]),
            "tmax": float(t[idx]),
            "auc_0_tend": float(np.trapezoid(c, t)),
            "output_csv": output_csv,
            **payload_extra,
        }
    )
    return 0


def cmd_simulate_nonlinear(args: argparse.Namespace) -> int:
    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    dose = float(args.dose) if args.dose is not None else float(drug.dose)
    vmax = float(args.vmax)
    km = float(args.km)
    t = np.linspace(0.0, float(args.t_end), int(args.n_points))
    pk = PKModel(**drug.pk_kwargs)
    c = pk.concentration_nonlinear(t=t, D=dose, vmax=vmax, km=km)

    output_csv = None
    if args.output_csv:
        out = Path(args.output_csv)
        out.parent.mkdir(parents=True, exist_ok=True)
        np.savetxt(out, np.column_stack([t, c]), delimiter=",", header="time_h,conc", comments="")
        output_csv = str(out)

    idx = int(np.nanargmax(c))
    _print_json(
        {
            "command": "simulate-nonlinear",
            "drug": drug.name,
            "dose": dose,
            "vmax": vmax,
            "km": km,
            "t_end": float(args.t_end),
            "n_points": int(args.n_points),
            "cmax": float(c[idx]),
            "tmax": float(t[idx]),
            "auc_0_tend": float(np.trapezoid(c, t)),
            "output_csv": output_csv,
        }
    )
    return 0


def cmd_steady_state(args: argparse.Namespace) -> int:
    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    dose = float(args.dose) if args.dose is not None else float(drug.dose)
    interval_h = float(args.interval_h)
    n_doses = int(args.n_doses)
    n_points = int(args.n_points)
    pk = PKModel(**drug.pk_kwargs)

    metrics = pk.steady_state_metrics(D=dose, interval_h=interval_h, n_doses=n_doses, n_points=n_points)

    output_csv = None
    if args.output_csv:
        t_end = interval_h * n_doses
        t = np.linspace(0.0, float(t_end), int(n_points))
        c = pk.concentration_multiple_dose(t, D=dose, interval_h=interval_h, n_doses=n_doses)
        out = Path(args.output_csv)
        out.parent.mkdir(parents=True, exist_ok=True)
        np.savetxt(out, np.column_stack([t, c]), delimiter=",", header="time_h,conc", comments="")
        output_csv = str(out)

    _print_json(
        {
            "command": "steady-state",
            "drug": drug.name,
            "dose": dose,
            "output_csv": output_csv,
            **metrics,
        }
    )
    return 0


def cmd_simulate_cohort(args: argparse.Namespace) -> int:
    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    pk_template = PKModel(**drug.pk_kwargs)
    default_dose = float(args.dose) if args.dose is not None else float(drug.dose)
    df = load_cohort_csv(args.input)
    out_df = simulate_cohort(
        df=df,
        pk_template=pk_template,
        default_dose=default_dose,
        t_end=float(args.t_end),
        n_points=int(args.n_points),
        include_iiv=bool(args.include_iiv),
        seed=int(args.seed),
    )

    output_csv = None
    if args.output_csv:
        out = Path(args.output_csv)
        out.parent.mkdir(parents=True, exist_ok=True)
        out_df.to_csv(out, index=False)
        output_csv = str(out)

    _print_json(
        {
            "command": "simulate-cohort",
            "input": str(args.input),
            "drug": drug.name,
            "default_dose": default_dose,
            "include_iiv": bool(args.include_iiv),
            "seed": int(args.seed),
            "output_csv": output_csv,
            **summarize_cohort(out_df),
        }
    )
    return 0


def cmd_init_cohort_template(args: argparse.Namespace) -> int:
    path = write_cohort_template_csv(args.output)
    _print_json({"command": "init-cohort-template", "output": path})
    return 0


def cmd_sensitivity(args: argparse.Namespace) -> int:
    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    dose = args.dose if args.dose is not None else drug.dose
    pk = PKModel(**drug.pk_kwargs)

    res = local_pk_sensitivity(
        pk=pk,
        dose=float(dose),
        t_end=float(args.t_end),
        n_points=int(args.n_points),
        rel_step=float(args.rel_step),
    )

    output_csv = None
    if args.output_csv:
        import csv

        out = Path(args.output_csv)
        out.parent.mkdir(parents=True, exist_ok=True)
        fieldnames = [
            "parameter",
            "base_value",
            "minus_value",
            "plus_value",
            "cmax_minus",
            "cmax_plus",
            "auc_minus",
            "auc_plus",
            "sensitivity_cmax",
            "sensitivity_auc",
        ]
        with out.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(res["results"])
        output_csv = str(out)

    _print_json(
        {
            "command": "sensitivity",
            "drug": drug.name,
            "dose": float(dose),
            "output_csv": output_csv,
            **res,
        }
    )
    return 0


def cmd_dose_sweep(args: argparse.Namespace) -> int:
    doses = _parse_csv_floats(args.doses)
    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    pk = PKModel(**drug.pk_kwargs)

    res = sweep_dose_response(
        pk=pk,
        doses=doses,
        t_end=float(args.t_end),
        n_points=int(args.n_points),
    )

    output_csv = None
    if args.output_csv:
        import csv

        out = Path(args.output_csv)
        out.parent.mkdir(parents=True, exist_ok=True)
        with out.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["dose", "cmax", "auc"])
            writer.writeheader()
            writer.writerows(res["rows"])
        output_csv = str(out)

    _print_json(
        {
            "command": "dose-sweep",
            "drug": drug.name,
            "output_csv": output_csv,
            **res,
        }
    )
    return 0


def cmd_simulate_regimen(args: argparse.Namespace) -> int:
    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    dose = args.dose if args.dose is not None else drug.dose
    pk = PKModel(**drug.pk_kwargs)

    result = simulate_regimen(
        pk=pk,
        dose=float(dose),
        interval_h=float(args.interval_h),
        n_doses=int(args.n_doses),
        t_end=args.t_end,
        n_points=int(args.n_points),
    )

    csv_path = None
    if args.output_csv:
        csv_path = write_regimen_csv(result, args.output_csv)

    plot_path = None
    if args.plot_png:
        plot_path = write_regimen_plot(result, args.plot_png, title=f"Regimen - {drug.name}")

    _print_json(
        {
            "command": "simulate-regimen",
            "drug": drug.name,
            "output_csv": csv_path,
            "plot_png": plot_path,
            **summarize_regimen(result),
        }
    )
    return 0


def cmd_fit(args: argparse.Namespace) -> int:
    times = _parse_csv_floats(args.times)
    obs = _parse_csv_floats(args.obs)
    if times.shape[0] != obs.shape[0]:
        raise ValueError("times and obs must have the same length")
    if times.shape[0] == 0:
        raise ValueError("times and obs cannot be empty")

    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    dose = args.dose if args.dose is not None else drug.dose
    pk = PKModel(**drug.pk_kwargs)
    cov = CovariateModel(pk)
    est = MAPEstimator(pk=pk, covariate_model=cov, sigma_obs=args.sigma_obs)

    patient_covariates = {}
    if args.weight is not None:
        patient_covariates["weight"] = float(args.weight)
    if args.crcl is not None:
        patient_covariates["crcl"] = float(args.crcl)
    if args.age is not None:
        patient_covariates["age"] = float(args.age)

    res = est.fit(
        times=times,
        obs=obs,
        patient_covariates=patient_covariates,
        dose=dose,
        n_iter=args.n_iter,
    )
    _print_json(
        {
            "command": "fit",
            "drug": drug.name,
            "dose": float(dose),
            "converged": bool(res["converged"]),
            "obj_value": float(res["obj_value"]),
            "params_map": {k: float(v) for k, v in res["params_map"].items()},
            "eta_map": {k: float(v) for k, v in res["eta_map"].items()},
        }
    )
    return 0


def cmd_validate_tdm(args: argparse.Namespace) -> int:
    df = load_tdm_csv(
        args.input,
        time_unit=args.time_unit,
        conc_unit=args.conc_unit,
        dose_unit=args.dose_unit,
    )
    if args.output_clean:
        out = Path(args.output_clean)
        out.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(out, index=False)
    _print_json(
        {
            "command": "validate-tdm",
            "input": str(args.input),
            "output_clean": str(args.output_clean) if args.output_clean else None,
            **summarize_tdm(df),
        }
    )
    return 0


def cmd_fit_tdm(args: argparse.Namespace) -> int:
    df = load_tdm_csv(args.input)
    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    pk = PKModel(**drug.pk_kwargs)

    fit_df = fit_tdm_patients(df, pk=pk, sigma_obs=args.sigma_obs, n_iter=args.n_iter)

    if args.output:
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        fit_df.to_csv(out, index=False)

    pred_df = None
    pred_summary = {}
    predictions_csv = None
    plot_png = None
    if args.predictions_csv or args.plot_png:
        pred_df = build_tdm_prediction_table(df=df, fit_df=fit_df)
        if args.predictions_csv:
            pred_out = Path(args.predictions_csv)
            pred_out.parent.mkdir(parents=True, exist_ok=True)
            pred_df.to_csv(pred_out, index=False)
            predictions_csv = str(pred_out)
        if args.plot_png:
            plot_png = write_tdm_prediction_plot(pred_df, args.plot_png)
        pred_summary = summarize_prediction_table(pred_df)

    report_md = None
    if args.report_md:
        report_md = write_tdm_fit_markdown_report(fit_df=fit_df, drug_name=drug.name, output_path=args.report_md)

    _print_json(
        {
            "command": "fit-tdm",
            "input": str(args.input),
            "drug": drug.name,
            "sigma_obs": float(args.sigma_obs),
            "n_iter": int(args.n_iter),
            "output": str(args.output) if args.output else None,
            "predictions_csv": predictions_csv,
            "plot_png": plot_png,
            "report_md": report_md,
            **summarize_fit_table(fit_df),
            **pred_summary,
        }
    )
    return 0


def cmd_fit_population(args: argparse.Namespace) -> int:
    df = load_tdm_csv(args.input)
    init = None
    if args.init_F is not None or args.init_ka is not None or args.init_ke is not None or args.init_Vd is not None:
        init = {
            "F": args.init_F if args.init_F is not None else 0.8,
            "ka": args.init_ka if args.init_ka is not None else 1.8,
            "ke": args.init_ke if args.init_ke is not None else 0.28,
            "Vd": args.init_Vd if args.init_Vd is not None else 65.0,
        }

    fit = fit_population_pk(df=df, init=init, maxiter=args.maxiter)
    payload = {
        "command": "fit-population",
        "input": str(args.input),
        "maxiter": int(args.maxiter),
        "output_json": str(args.output_json) if args.output_json else None,
        **fit,
    }
    if args.bootstrap_n > 0:
        payload["bootstrap"] = bootstrap_population_pk(
            df=df,
            n_boot=args.bootstrap_n,
            seed=args.bootstrap_seed,
            init=init,
            maxiter=args.maxiter,
        )

    if args.output_json:
        out = Path(args.output_json)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")

    _print_json(payload)
    return 0


def cmd_fit_population_mixed(args: argparse.Namespace) -> int:
    df = load_tdm_csv(args.input)
    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    template_pk = PKModel(**drug.pk_kwargs)

    init_theta = {
        "ka": float(args.init_ka) if args.init_ka is not None else float(template_pk.ka),
        "ke": float(args.init_ke) if args.init_ke is not None else float(template_pk.ke),
        "Vd": float(args.init_Vd) if args.init_Vd is not None else float(template_pk.Vd),
    }
    init_omega = {
        "ka": float(args.omega_ka),
        "ke": float(args.omega_ke),
        "Vd": float(args.omega_vd),
    }

    fit = fit_population_mixed_effects(
        df=df,
        pk_template=template_pk,
        sigma_obs=float(args.sigma_obs),
        maxiter=int(args.maxiter),
        init_theta=init_theta,
        init_omega=init_omega,
    )

    eta_csv = None
    eta_df = eta_table_from_fit(fit)
    if args.eta_csv:
        out_eta = Path(args.eta_csv)
        out_eta.parent.mkdir(parents=True, exist_ok=True)
        eta_df.to_csv(out_eta, index=False)
        eta_csv = str(out_eta)

    payload = {
        "command": "fit-population-mixed",
        "input": str(args.input),
        "drug": drug.name,
        "maxiter": int(args.maxiter),
        "eta_csv": eta_csv,
        "output_json": str(args.output_json) if args.output_json else None,
        **fit,
    }

    if args.output_json:
        out = Path(args.output_json)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")

    _print_json(payload)
    return 0


def cmd_init_tdm_template(args: argparse.Namespace) -> int:
    path = write_tdm_template_csv(args.output, template_format=args.format)
    _print_json({"command": "init-tdm-template", "output": path, "format": args.format})
    return 0


def cmd_validate_external(args: argparse.Namespace) -> int:
    df = load_external_validation_csv(args.input)
    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    pk = PKModel(**drug.pk_kwargs)
    table = build_external_validation_table(df, pk=pk)
    summary = summarize_external_validation(table)

    predictions_csv = None
    if args.predictions_csv:
        out = Path(args.predictions_csv)
        out.parent.mkdir(parents=True, exist_ok=True)
        table.to_csv(out, index=False)
        predictions_csv = str(out)

    payload = {
        "command": "validate-external",
        "input": str(args.input),
        "drug": drug.name,
        "predictions_csv": predictions_csv,
        "output_json": str(args.output_json) if args.output_json else None,
        **summary,
    }
    if args.output_json:
        out = Path(args.output_json)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    _print_json(payload)
    return 0


def cmd_init_external_template(args: argparse.Namespace) -> int:
    path = write_external_validation_template_csv(args.output)
    _print_json({"command": "init-external-template", "output": path})
    return 0


def _run_web_app_server_mode(args: argparse.Namespace, dose: float | None) -> int:  # pragma: no cover
    if args.output_html:
        payload = build_web_app_payload(
            dataset=args.dataset,
            drug=args.drug,
            dose=dose,
            t_end=float(args.t_end),
            n_points=int(args.n_points),
        )
        write_web_app_html(payload, args.output_html)
    run_web_app_server(
        dataset=args.dataset,
        host=str(args.host),
        port=int(args.port),
        default_drug=str(args.drug),
        default_dose=dose,
        default_t_end=float(args.t_end),
        default_n_points=int(args.n_points),
    )
    return 0


def cmd_web_app(args: argparse.Namespace) -> int:
    dose = float(args.dose) if args.dose is not None else None
    if args.dry_run:
        payload = build_web_app_payload(
            dataset=args.dataset,
            drug=args.drug,
            dose=dose,
            t_end=float(args.t_end),
            n_points=int(args.n_points),
        )
        output_html = None
        if args.output_html:
            output_html = write_web_app_html(payload, args.output_html)
        _print_json(
            {
                "command": "web-app",
                "mode": "dry-run",
                "drug": payload["drug"],
                "dose": payload["dose"],
                "t_end": payload["t_end"],
                "n_points": payload["n_points"],
                "cmax": payload["cmax"],
                "tmax": payload["tmax"],
                "auc_0_tend": payload["auc_0_tend"],
                "available_drugs": int(len(payload.get("available_drugs", []))),
                "output_html": output_html,
                "host": str(args.host),
                "port": int(args.port),
            }
        )
        return 0

    return _run_web_app_server_mode(args=args, dose=dose)  # pragma: no cover


def cmd_run_tdm_workflow(args: argparse.Namespace) -> int:
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    df = load_tdm_csv(args.input)
    clean_csv = outdir / "tdm_clean.csv"
    df.to_csv(clean_csv, index=False)

    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    pk = PKModel(**drug.pk_kwargs)

    fit_df = fit_tdm_patients(df, pk=pk, sigma_obs=args.sigma_obs, n_iter=args.n_iter)
    fit_csv = outdir / "tdm_fit.csv"
    fit_df.to_csv(fit_csv, index=False)

    pred_df = build_tdm_prediction_table(df=df, fit_df=fit_df)
    pred_csv = outdir / "tdm_predictions.csv"
    pred_df.to_csv(pred_csv, index=False)
    pred_summary = summarize_prediction_table(pred_df)

    report_md = write_tdm_fit_markdown_report(fit_df=fit_df, drug_name=drug.name, output_path=outdir / "tdm_fit_report.md")
    plot_png = write_tdm_prediction_plot(pred_df=pred_df, output_path=outdir / "tdm_obs_vs_pred.png")

    pop_fit = fit_population_pk(df=df, maxiter=args.maxiter_pop)
    if args.bootstrap_n > 0:
        pop_fit["bootstrap"] = bootstrap_population_pk(
            df=df,
            n_boot=args.bootstrap_n,
            seed=args.bootstrap_seed,
            maxiter=args.maxiter_pop,
        )
    pop_json = outdir / "population_fit.json"
    pop_json.write_text(json.dumps(pop_fit, indent=2, sort_keys=True), encoding="utf-8")

    _print_json(
        {
            "command": "run-tdm-workflow",
            "input": str(args.input),
            "drug": drug.name,
            "outdir": str(outdir),
            "clean_csv": str(clean_csv),
            "fit_csv": str(fit_csv),
            "predictions_csv": str(pred_csv),
            "report_md": str(report_md),
            "plot_png": str(plot_png),
            "population_json": str(pop_json),
            **summarize_tdm(df),
            **summarize_fit_table(fit_df),
            **pred_summary,
        }
    )
    return 0


def cmd_benchmark_regimen(args: argparse.Namespace) -> int:
    df = benchmark_regimen_across_drugs(
        dataset=args.dataset,
        drugs=args.drugs,
        interval_h=args.interval_h,
        n_doses=args.n_doses,
        t_end=args.t_end,
        n_points=args.n_points,
        dose_override=args.dose_override,
    )
    output_csv = None
    if args.output_csv:
        output_csv = write_benchmark_csv(df, args.output_csv)

    top = df.iloc[0].to_dict() if not df.empty else None
    _print_json(
        {
            "command": "benchmark-regimen",
            "n_drugs": int(df.shape[0]),
            "interval_h": float(args.interval_h),
            "n_doses": int(args.n_doses),
            "output_csv": output_csv,
            "top_drug_by_cmax": top,
        }
    )
    return 0


def cmd_fit_tdm_mixed(args: argparse.Namespace) -> int:
    df = load_tdm_csv(args.input)
    fit_df = fit_tdm_mixed_by_drug(
        df=df,
        dataset=args.dataset,
        sigma_obs=args.sigma_obs,
        n_iter=args.n_iter,
    )

    output_csv = None
    if args.output:
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        fit_df.to_csv(out, index=False)
        output_csv = str(out)

    _print_json(
        {
            "command": "fit-tdm-mixed",
            "input": str(args.input),
            "output": output_csv,
            "sigma_obs": float(args.sigma_obs),
            "n_iter": int(args.n_iter),
            **summarize_tdm_mixed_fit(fit_df),
        }
    )
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    failures = []
    dataset_ok = False
    dataset_drugs = None
    try:
        db = DrugDatabase(args.dataset)
        dataset_drugs = len(db.list_drugs())
        dataset_ok = True
    except Exception as exc:
        failures.append(f"dataset: {exc}")

    pk_ok = False
    try:
        pk = PKModel()
        _ = pk.concentration([0.0, 1.0], D=1000.0)
        pk_ok = True
    except Exception as exc:
        failures.append(f"pk_smoke: {exc}")

    payload = {
        "command": "doctor",
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "dataset": str(args.dataset),
        "dataset_ok": dataset_ok,
        "dataset_drugs": dataset_drugs,
        "pk_smoke_ok": pk_ok,
        "failures": failures,
    }
    _print_json(payload)
    if args.strict and failures:
        return 1
    return 0


def cmd_project_report(args: argparse.Namespace) -> int:
    report = build_project_report(
        dataset=str(args.dataset),
        drug=str(args.drug),
        dose=args.dose,
        t_end=float(args.t_end),
        n_points=int(args.n_points),
        rel_step=float(args.rel_step),
    )
    output_md = None
    if args.output_md:
        out = Path(args.output_md)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(render_project_report_markdown(report), encoding="utf-8")
        output_md = str(out)

    payload = {
        "command": "project-report",
        "output_md": output_md,
        **report,
    }
    _print_json(payload)

    if args.strict and report["failures"]:
        return 1
    return 0


def cmd_validation_report(args: argparse.Namespace) -> int:
    report = build_validation_report(
        dataset=str(args.dataset),
        drug=str(args.drug),
        external_input=str(args.external_input) if args.external_input else None,
        n_subjects=int(args.n_subjects),
        t_end=float(args.t_end),
        n_points=int(args.n_points),
        seed=int(args.seed),
    )

    output_md = None
    if args.output_md:
        out = Path(args.output_md)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(render_validation_report_markdown(report), encoding="utf-8")
        output_md = str(out)

    output_json = None
    if args.output_json:
        out = Path(args.output_json)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
        output_json = str(out)

    payload = {
        "command": "validation-report",
        "output_md": output_md,
        "output_json": output_json,
        **report,
    }
    _print_json(payload)

    if args.strict and report["failures"]:
        return 1
    return 0


def cmd_release_readiness(args: argparse.Namespace) -> int:
    report = build_release_readiness_report(repo_root=str(args.repo_root))

    output_md = None
    if args.output_md:
        out = Path(args.output_md)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(render_release_readiness_markdown(report), encoding="utf-8")
        output_md = str(out)

    payload = {
        "command": "release-readiness",
        "output_md": output_md,
        **report,
    }
    _print_json(payload)
    if args.strict and report["failures"]:
        return 1
    return 0


def cmd_recommend_dose(args: argparse.Namespace) -> int:
    if args.target_cmax is None and args.target_auc is None:
        raise ValueError("Provide --target-cmax or --target-auc")
    if args.target_cmax is not None and args.target_auc is not None:
        raise ValueError("Use only one target mode at a time (--target-cmax or --target-auc)")

    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    base_pk = PKModel(**drug.pk_kwargs)

    cov_values = {}
    if args.weight is not None:
        cov_values["weight"] = float(args.weight)
    if args.crcl is not None:
        cov_values["crcl"] = float(args.crcl)
    if args.age is not None:
        cov_values["age"] = float(args.age)

    if cov_values:
        cov = CovariateModel(base_pk)
        params = cov.individualize(cov_values, sex=args.sex)
        pk = PKModel(**params)
    else:
        params = dict(drug.pk_kwargs)
        pk = base_pk

    if args.target_cmax is not None:
        rec = recommend_dose_for_target_cmax(
            pk=pk,
            target_cmax=float(args.target_cmax),
            t_end=float(args.t_end),
            n_points=int(args.n_points),
        )
    else:
        rec = recommend_dose_for_target_auc(pk=pk, target_auc=float(args.target_auc))

    payload = {
        "command": "recommend-dose",
        "drug": drug.name,
        "sex": args.sex,
        "covariates": cov_values,
        "pk_params_used": {k: float(v) for k, v in params.items()},
        **rec,
    }
    if args.output_json:
        out = Path(args.output_json)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    _print_json(payload)
    return 0


def cmd_recommend_regimen_dose(args: argparse.Namespace) -> int:
    if args.target_cmax is None and args.target_trough is None:
        raise ValueError("Provide --target-cmax or --target-trough")
    if args.target_cmax is not None and args.target_trough is not None:
        raise ValueError("Use only one target mode at a time (--target-cmax or --target-trough)")

    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    base_pk = PKModel(**drug.pk_kwargs)

    cov_values = {}
    if args.weight is not None:
        cov_values["weight"] = float(args.weight)
    if args.crcl is not None:
        cov_values["crcl"] = float(args.crcl)
    if args.age is not None:
        cov_values["age"] = float(args.age)

    if cov_values:
        cov = CovariateModel(base_pk)
        params = cov.individualize(cov_values, sex=args.sex)
        pk = PKModel(**params)
    else:
        params = dict(drug.pk_kwargs)
        pk = base_pk

    if args.target_cmax is not None:
        rec = recommend_regimen_dose_for_target_cmax(
            pk=pk,
            target_cmax=float(args.target_cmax),
            interval_h=float(args.interval_h),
            n_doses=int(args.n_doses),
            t_end=args.t_end,
            n_points=int(args.n_points),
        )
    else:
        rec = recommend_regimen_dose_for_target_trough(
            pk=pk,
            target_trough=float(args.target_trough),
            interval_h=float(args.interval_h),
            n_doses=int(args.n_doses),
            t_end=args.t_end,
            n_points=int(args.n_points),
        )

    payload = {
        "command": "recommend-regimen-dose",
        "drug": drug.name,
        "sex": args.sex,
        "covariates": cov_values,
        "pk_params_used": {k: float(v) for k, v in params.items()},
        **rec,
    }
    if args.output_json:
        out = Path(args.output_json)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    _print_json(payload)
    return 0


def cmd_recommend_regimen_window(args: argparse.Namespace) -> int:
    db = DrugDatabase(args.dataset)
    drug = db.get_drug(args.drug)
    base_pk = PKModel(**drug.pk_kwargs)

    cov_values = {}
    if args.weight is not None:
        cov_values["weight"] = float(args.weight)
    if args.crcl is not None:
        cov_values["crcl"] = float(args.crcl)
    if args.age is not None:
        cov_values["age"] = float(args.age)

    if cov_values:
        cov = CovariateModel(base_pk)
        params = cov.individualize(cov_values, sex=args.sex)
        pk = PKModel(**params)
    else:
        params = dict(drug.pk_kwargs)
        pk = base_pk

    rec = recommend_regimen_dose_for_target_window(
        pk=pk,
        target_trough_min=float(args.target_trough_min),
        target_cmax_max=float(args.target_cmax_max),
        interval_h=float(args.interval_h),
        n_doses=int(args.n_doses),
        t_end=args.t_end,
        n_points=int(args.n_points),
        strategy=args.strategy,
    )

    payload = {
        "command": "recommend-regimen-window",
        "drug": drug.name,
        "sex": args.sex,
        "covariates": cov_values,
        "pk_params_used": {k: float(v) for k, v in params.items()},
        **rec,
    }
    if args.output_json:
        out = Path(args.output_json)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    _print_json(payload)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="opendose", description="OpenDose-PopPK CLI")
    parser.add_argument(
        "--dataset",
        default=_default_dataset(),
        help="CSV dataset path (default: datasets/drugs_parameters.csv)",
    )

    sub = parser.add_subparsers(dest="command", required=True)

    p_list = sub.add_parser("list-drugs", help="List available drugs from dataset")
    p_list.set_defaults(func=cmd_list_drugs)

    p_dataset = sub.add_parser("validate-dataset", help="Validate drug-parameter dataset CSV")
    p_dataset.add_argument(
        "--output-clean",
        default=None,
        help="Optional output path for normalized dataset CSV",
    )
    p_dataset.set_defaults(func=cmd_validate_dataset)

    p_sim = sub.add_parser("simulate", help="Run population simulation for one drug")
    p_sim.add_argument("--drug", required=True, help="Drug name from dataset")
    p_sim.add_argument("--dose", type=float, default=None, help="Dose override")
    p_sim.add_argument("--n-subjects", type=int, default=1000, help="Population size")
    p_sim.add_argument("--t-max", type=float, default=24.0, help="Simulation horizon (hours)")
    p_sim.add_argument("--n-points", type=int, default=200, help="Number of points in profile")
    p_sim.add_argument("--seed", type=int, default=42, help="Random seed")
    p_sim.add_argument("--no-pd", action="store_true", help="Disable PD simulation")
    p_sim.add_argument("--output", default=None, help="Optional CSV output path for PK percentiles")
    p_sim.set_defaults(func=cmd_simulate)

    p_iv = sub.add_parser("simulate-iv", help="Simulate IV bolus or infusion profile")
    p_iv.add_argument("--drug", required=True, help="Drug name from dataset")
    p_iv.add_argument("--mode", choices=["bolus", "infusion"], default="bolus", help="IV input mode")
    p_iv.add_argument("--dose", type=float, default=None, help="Bolus dose (used in bolus mode)")
    p_iv.add_argument("--infusion-rate", type=float, default=None, help="Infusion rate in amount/h")
    p_iv.add_argument("--infusion-duration-h", type=float, default=None, help="Infusion duration in hours")
    p_iv.add_argument("--infusion-start-h", type=float, default=0.0, help="Infusion start time in hours")
    p_iv.add_argument("--t-end", type=float, default=24.0, help="Simulation horizon in hours")
    p_iv.add_argument("--n-points", type=int, default=400, help="Number of points in profile")
    p_iv.add_argument("--output-csv", default=None, help="Optional output CSV path")
    p_iv.set_defaults(func=cmd_simulate_iv)

    p_nl = sub.add_parser("simulate-nonlinear", help="Simulate one-compartment saturable elimination profile")
    p_nl.add_argument("--drug", required=True, help="Drug name from dataset")
    p_nl.add_argument("--dose", type=float, default=None, help="Dose override")
    p_nl.add_argument("--vmax", type=float, required=True, help="Maximum elimination rate (amount/h)")
    p_nl.add_argument("--km", type=float, required=True, help="Michaelis-Menten constant (amount/L)")
    p_nl.add_argument("--t-end", type=float, default=24.0, help="Simulation horizon in hours")
    p_nl.add_argument("--n-points", type=int, default=400, help="Number of points in profile")
    p_nl.add_argument("--output-csv", default=None, help="Optional output CSV path")
    p_nl.set_defaults(func=cmd_simulate_nonlinear)

    p_ss = sub.add_parser("steady-state", help="Estimate steady-state metrics from repeated dosing")
    p_ss.add_argument("--drug", required=True, help="Drug name from dataset")
    p_ss.add_argument("--dose", type=float, default=None, help="Dose override")
    p_ss.add_argument("--interval-h", type=float, required=True, help="Dose interval in hours")
    p_ss.add_argument("--n-doses", type=int, default=20, help="Number of doses to approximate steady-state")
    p_ss.add_argument("--n-points", type=int, default=4000, help="Number of points in profile")
    p_ss.add_argument("--output-csv", default=None, help="Optional output CSV path")
    p_ss.set_defaults(func=cmd_steady_state)

    p_cohort = sub.add_parser("simulate-cohort", help="Simulate PK metrics per patient from cohort CSV")
    p_cohort.add_argument("--input", required=True, help="Path to cohort CSV (requires patient_id column)")
    p_cohort.add_argument("--drug", required=True, help="Drug name from dataset")
    p_cohort.add_argument("--dose", type=float, default=None, help="Default dose if cohort row dose is missing")
    p_cohort.add_argument("--t-end", type=float, default=24.0, help="Simulation horizon in hours")
    p_cohort.add_argument("--n-points", type=int, default=400, help="Number of points in profile")
    p_cohort.add_argument("--include-iiv", action="store_true", help="Include inter-individual variability")
    p_cohort.add_argument("--seed", type=int, default=42, help="Random seed (used when --include-iiv)")
    p_cohort.add_argument("--output-csv", default=None, help="Optional output CSV path")
    p_cohort.set_defaults(func=cmd_simulate_cohort)

    p_cohort_template = sub.add_parser("init-cohort-template", help="Create an example cohort CSV template")
    p_cohort_template.add_argument("--output", required=True, help="Output CSV path")
    p_cohort_template.set_defaults(func=cmd_init_cohort_template)

    p_sens = sub.add_parser("sensitivity", help="Run local parameter sensitivity analysis (Cmax/AUC)")
    p_sens.add_argument("--drug", required=True, help="Drug name from dataset")
    p_sens.add_argument("--dose", type=float, default=None, help="Dose override")
    p_sens.add_argument("--t-end", type=float, default=24.0, help="Simulation horizon in hours")
    p_sens.add_argument("--n-points", type=int, default=400, help="Number of points in profile")
    p_sens.add_argument("--rel-step", type=float, default=0.10, help="Relative perturbation in (0,1)")
    p_sens.add_argument("--output-csv", default=None, help="Optional CSV output path for sensitivity table")
    p_sens.set_defaults(func=cmd_sensitivity)

    p_sweep = sub.add_parser("dose-sweep", help="Sweep multiple doses and compute Cmax/AUC response")
    p_sweep.add_argument("--drug", required=True, help="Drug name from dataset")
    p_sweep.add_argument("--doses", required=True, help="Comma-separated doses, e.g. 250,500,750,1000")
    p_sweep.add_argument("--t-end", type=float, default=24.0, help="Simulation horizon in hours")
    p_sweep.add_argument("--n-points", type=int, default=400, help="Number of points in profile")
    p_sweep.add_argument("--output-csv", default=None, help="Optional CSV output path for sweep results")
    p_sweep.set_defaults(func=cmd_dose_sweep)

    p_reg = sub.add_parser("simulate-regimen", help="Simulate repeated-dose regimen for one drug")
    p_reg.add_argument("--drug", required=True, help="Drug name from dataset")
    p_reg.add_argument("--dose", type=float, default=None, help="Dose override")
    p_reg.add_argument("--interval-h", type=float, required=True, help="Dose interval in hours")
    p_reg.add_argument("--n-doses", type=int, required=True, help="Number of scheduled doses")
    p_reg.add_argument("--t-end", type=float, default=None, help="Simulation horizon in hours")
    p_reg.add_argument("--n-points", type=int, default=400, help="Number of points in profile")
    p_reg.add_argument("--output-csv", default=None, help="Optional CSV output path")
    p_reg.add_argument("--plot-png", default=None, help="Optional regimen plot path")
    p_reg.set_defaults(func=cmd_simulate_regimen)

    p_fit = sub.add_parser("fit", help="Run MAP fit for one drug and observed concentrations")
    p_fit.add_argument("--drug", required=True, help="Drug name from dataset")
    p_fit.add_argument("--times", required=True, help="Comma-separated times (hours), e.g. 1,2,4,6")
    p_fit.add_argument("--obs", required=True, help="Comma-separated observations matching --times")
    p_fit.add_argument("--dose", type=float, default=None, help="Dose override")
    p_fit.add_argument("--sigma-obs", type=float, default=0.8, help="Observation noise sigma")
    p_fit.add_argument("--n-iter", type=int, default=3000, help="Maximum optimizer iterations")
    p_fit.add_argument("--weight", type=float, default=None, help="Patient weight (kg)")
    p_fit.add_argument("--crcl", type=float, default=None, help="Patient CrCl (mL/min)")
    p_fit.add_argument("--age", type=float, default=None, help="Patient age (years)")
    p_fit.set_defaults(func=cmd_fit)

    p_tdm = sub.add_parser("validate-tdm", help="Validate and summarize TDM CSV input")
    p_tdm.add_argument("--input", required=True, help="Path to TDM CSV")
    p_tdm.add_argument("--time-unit", default="h", help="Fallback time unit for numeric values (h|min|day)")
    p_tdm.add_argument(
        "--conc-unit",
        default="ug/mL",
        help="Fallback concentration unit for numeric values (e.g., ug/mL, mg/L, ng/mL)",
    )
    p_tdm.add_argument(
        "--dose-unit",
        default="mg",
        help="Fallback dose unit for numeric values (mg|g|ug|ng)",
    )
    p_tdm.add_argument("--output-clean", default=None, help="Optional path to save cleaned CSV")
    p_tdm.set_defaults(func=cmd_validate_tdm)

    p_fit_tdm = sub.add_parser("fit-tdm", help="Run MAP fit per patient from validated TDM CSV")
    p_fit_tdm.add_argument("--input", required=True, help="Path to TDM CSV")
    p_fit_tdm.add_argument("--drug", required=True, help="Drug name from dataset")
    p_fit_tdm.add_argument("--sigma-obs", type=float, default=0.8, help="Observation noise sigma")
    p_fit_tdm.add_argument("--n-iter", type=int, default=3000, help="Maximum optimizer iterations")
    p_fit_tdm.add_argument("--output", default=None, help="Optional CSV output path for patient fit table")
    p_fit_tdm.add_argument(
        "--predictions-csv",
        default=None,
        help="Optional CSV output path with per-observation predictions and residuals",
    )
    p_fit_tdm.add_argument("--plot-png", default=None, help="Optional observed-vs-predicted plot path")
    p_fit_tdm.add_argument("--report-md", default=None, help="Optional markdown summary report output path")
    p_fit_tdm.set_defaults(func=cmd_fit_tdm)

    p_fit_pop = sub.add_parser("fit-population", help="Naive pooled population PK fit from TDM CSV")
    p_fit_pop.add_argument("--input", required=True, help="Path to TDM CSV")
    p_fit_pop.add_argument("--maxiter", type=int, default=2000, help="Maximum optimizer iterations")
    p_fit_pop.add_argument("--init-F", type=float, default=None, help="Initial guess for F")
    p_fit_pop.add_argument("--init-ka", type=float, default=None, help="Initial guess for ka")
    p_fit_pop.add_argument("--init-ke", type=float, default=None, help="Initial guess for ke")
    p_fit_pop.add_argument("--init-Vd", type=float, default=None, help="Initial guess for Vd")
    p_fit_pop.add_argument("--bootstrap-n", type=int, default=0, help="Bootstrap replicates (0 disables)")
    p_fit_pop.add_argument("--bootstrap-seed", type=int, default=42, help="Bootstrap RNG seed")
    p_fit_pop.add_argument("--output-json", default=None, help="Optional JSON output path")
    p_fit_pop.set_defaults(func=cmd_fit_population)

    p_fit_pop_mixed = sub.add_parser("fit-population-mixed", help="Mixed-effects population PK fit from TDM CSV")
    p_fit_pop_mixed.add_argument("--input", required=True, help="Path to TDM CSV")
    p_fit_pop_mixed.add_argument("--drug", required=True, help="Drug name from dataset")
    p_fit_pop_mixed.add_argument("--sigma-obs", type=float, default=0.8, help="Observation noise sigma")
    p_fit_pop_mixed.add_argument("--maxiter", type=int, default=1200, help="Maximum optimizer iterations")
    p_fit_pop_mixed.add_argument("--init-ka", type=float, default=None, help="Initial guess for population ka")
    p_fit_pop_mixed.add_argument("--init-ke", type=float, default=None, help="Initial guess for population ke")
    p_fit_pop_mixed.add_argument("--init-Vd", type=float, default=None, help="Initial guess for population Vd")
    p_fit_pop_mixed.add_argument("--omega-ka", type=float, default=0.30, help="Initial random-effect std for ka")
    p_fit_pop_mixed.add_argument("--omega-ke", type=float, default=0.30, help="Initial random-effect std for ke")
    p_fit_pop_mixed.add_argument("--omega-vd", type=float, default=0.30, help="Initial random-effect std for Vd")
    p_fit_pop_mixed.add_argument("--eta-csv", default=None, help="Optional CSV output path for individual eta table")
    p_fit_pop_mixed.add_argument("--output-json", default=None, help="Optional JSON output path")
    p_fit_pop_mixed.set_defaults(func=cmd_fit_population_mixed)

    p_template = sub.add_parser("init-tdm-template", help="Create an empty TDM CSV template")
    p_template.add_argument("--output", required=True, help="Output CSV path")
    p_template.add_argument(
        "--format",
        choices=["basic", "clinical"],
        default="basic",
        help="Template format: basic canonical columns or clinical raw-data oriented columns",
    )
    p_template.set_defaults(func=cmd_init_tdm_template)

    p_ext = sub.add_parser(
        "validate-external",
        help="Run external validation against observed concentrations and optional reference predictions",
    )
    p_ext.add_argument("--input", required=True, help="Path to external validation CSV")
    p_ext.add_argument("--drug", required=True, help="Drug name from dataset")
    p_ext.add_argument("--predictions-csv", default=None, help="Optional output CSV for prediction table")
    p_ext.add_argument("--output-json", default=None, help="Optional JSON output path")
    p_ext.set_defaults(func=cmd_validate_external)

    p_ext_template = sub.add_parser("init-external-template", help="Create an external validation CSV template")
    p_ext_template.add_argument("--output", required=True, help="Output CSV path")
    p_ext_template.set_defaults(func=cmd_init_external_template)

    p_web = sub.add_parser("web-app", help="Run simple local web app baseline")
    p_web.add_argument("--drug", default="Paracetamol", help="Default drug shown in the web app")
    p_web.add_argument("--dose", type=float, default=None, help="Default dose; falls back to dataset dose when omitted")
    p_web.add_argument("--t-end", type=float, default=24.0, help="Default simulation horizon in hours")
    p_web.add_argument("--n-points", type=int, default=300, help="Default number of points in profile")
    p_web.add_argument("--host", default="127.0.0.1", help="Bind host for local server")
    p_web.add_argument("--port", type=int, default=8000, help="Bind port for local server")
    p_web.add_argument("--output-html", default=None, help="Optional path to write initial web app HTML")
    p_web.add_argument("--dry-run", action="store_true", help="Generate payload/HTML and exit without starting server")
    p_web.set_defaults(func=cmd_web_app)

    p_workflow = sub.add_parser("run-tdm-workflow", help="Run end-to-end TDM pipeline in one command")
    p_workflow.add_argument("--input", required=True, help="Path to TDM CSV")
    p_workflow.add_argument("--drug", required=True, help="Drug name from dataset")
    p_workflow.add_argument("--outdir", required=True, help="Output directory for all workflow artifacts")
    p_workflow.add_argument("--sigma-obs", type=float, default=0.8, help="Observation noise sigma for MAP fitting")
    p_workflow.add_argument("--n-iter", type=int, default=3000, help="Maximum iterations for patient MAP fitting")
    p_workflow.add_argument("--maxiter-pop", type=int, default=2000, help="Maximum iterations for population fit")
    p_workflow.add_argument("--bootstrap-n", type=int, default=0, help="Bootstrap replicates for population fit")
    p_workflow.add_argument("--bootstrap-seed", type=int, default=42, help="Bootstrap RNG seed")
    p_workflow.set_defaults(func=cmd_run_tdm_workflow)

    p_bench = sub.add_parser("benchmark-regimen", help="Compare repeated-dose regimen metrics across drugs")
    p_bench.add_argument("--drugs", default=None, help="Optional comma-separated drug list")
    p_bench.add_argument("--interval-h", type=float, default=12.0, help="Dose interval in hours")
    p_bench.add_argument("--n-doses", type=int, default=4, help="Number of scheduled doses")
    p_bench.add_argument("--t-end", type=float, default=None, help="Simulation horizon in hours")
    p_bench.add_argument("--n-points", type=int, default=400, help="Number of points in each profile")
    p_bench.add_argument("--dose-override", type=float, default=None, help="If set, use same dose for all drugs")
    p_bench.add_argument("--output-csv", default=None, help="Optional CSV output path for benchmark table")
    p_bench.set_defaults(func=cmd_benchmark_regimen)

    p_fit_tdm_mixed = sub.add_parser(
        "fit-tdm-mixed", help="Run MAP fit for mixed-drug TDM table (requires drug column)"
    )
    p_fit_tdm_mixed.add_argument("--input", required=True, help="Path to TDM CSV with drug column")
    p_fit_tdm_mixed.add_argument("--sigma-obs", type=float, default=0.8, help="Observation noise sigma")
    p_fit_tdm_mixed.add_argument("--n-iter", type=int, default=3000, help="Maximum optimizer iterations")
    p_fit_tdm_mixed.add_argument("--output", default=None, help="Optional output CSV path")
    p_fit_tdm_mixed.set_defaults(func=cmd_fit_tdm_mixed)

    p_doctor = sub.add_parser("doctor", help="Run local environment and dataset health checks")
    p_doctor.add_argument("--strict", action="store_true", help="Exit with code 1 if any check fails")
    p_doctor.set_defaults(func=cmd_doctor)

    p_report = sub.add_parser("project-report", help="Generate project health report (dataset + smoke + sensitivity)")
    p_report.add_argument("--drug", default="Paracetamol", help="Drug name for sensitivity analysis")
    p_report.add_argument("--dose", type=float, default=None, help="Dose override for sensitivity section")
    p_report.add_argument("--t-end", type=float, default=24.0, help="Time horizon for sensitivity section")
    p_report.add_argument("--n-points", type=int, default=400, help="Number of points for sensitivity section")
    p_report.add_argument("--rel-step", type=float, default=0.10, help="Relative perturbation in (0,1)")
    p_report.add_argument("--output-md", default=None, help="Optional markdown report output path")
    p_report.add_argument("--strict", action="store_true", help="Exit with code 1 if report contains failures")
    p_report.set_defaults(func=cmd_project_report)

    p_val_report = sub.add_parser(
        "validation-report",
        help="Generate reproducible scientific validation report (protocol, metrics, limitations)",
    )
    p_val_report.add_argument("--drug", default="Paracetamol", help="Drug name for internal validation metrics")
    p_val_report.add_argument("--external-input", default=None, help="Optional external validation CSV input")
    p_val_report.add_argument("--n-subjects", type=int, default=200, help="Population simulation size")
    p_val_report.add_argument("--t-end", type=float, default=24.0, help="Time horizon for simulation metrics")
    p_val_report.add_argument("--n-points", type=int, default=300, help="Number of points for simulation metrics")
    p_val_report.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")
    p_val_report.add_argument("--output-md", default=None, help="Optional markdown report output path")
    p_val_report.add_argument("--output-json", default=None, help="Optional JSON report output path")
    p_val_report.add_argument("--strict", action="store_true", help="Exit with code 1 if report contains failures")
    p_val_report.set_defaults(func=cmd_validation_report)

    p_release = sub.add_parser(
        "release-readiness",
        help="Check semver/version consistency and release assets readiness",
    )
    p_release.add_argument("--repo-root", default=".", help="Repository root path")
    p_release.add_argument("--output-md", default=None, help="Optional markdown output path")
    p_release.add_argument("--strict", action="store_true", help="Exit with code 1 if readiness checks fail")
    p_release.set_defaults(func=cmd_release_readiness)

    p_dose = sub.add_parser("recommend-dose", help="Recommend dose to hit target Cmax or AUC")
    p_dose.add_argument("--drug", required=True, help="Drug name from dataset")
    p_dose.add_argument("--target-cmax", type=float, default=None, help="Target Cmax")
    p_dose.add_argument("--target-auc", type=float, default=None, help="Target AUC")
    p_dose.add_argument("--t-end", type=float, default=24.0, help="Time horizon for Cmax search")
    p_dose.add_argument("--n-points", type=int, default=1000, help="Number of points for Cmax search")
    p_dose.add_argument("--weight", type=float, default=None, help="Patient weight (kg)")
    p_dose.add_argument("--crcl", type=float, default=None, help="Patient CrCl (mL/min)")
    p_dose.add_argument("--age", type=float, default=None, help="Patient age (years)")
    p_dose.add_argument("--sex", default="M", help="Patient sex (M/F), used with covariates")
    p_dose.add_argument("--output-json", default=None, help="Optional JSON output path")
    p_dose.set_defaults(func=cmd_recommend_dose)

    p_reg_dose = sub.add_parser(
        "recommend-regimen-dose", help="Recommend repeated-dose amount for target regimen Cmax or trough"
    )
    p_reg_dose.add_argument("--drug", required=True, help="Drug name from dataset")
    p_reg_dose.add_argument("--target-cmax", type=float, default=None, help="Target regimen Cmax")
    p_reg_dose.add_argument("--target-trough", type=float, default=None, help="Target regimen trough")
    p_reg_dose.add_argument("--interval-h", type=float, required=True, help="Dose interval in hours")
    p_reg_dose.add_argument("--n-doses", type=int, required=True, help="Number of scheduled doses")
    p_reg_dose.add_argument("--t-end", type=float, default=None, help="Simulation horizon in hours")
    p_reg_dose.add_argument("--n-points", type=int, default=1000, help="Number of points in regimen profile")
    p_reg_dose.add_argument("--weight", type=float, default=None, help="Patient weight (kg)")
    p_reg_dose.add_argument("--crcl", type=float, default=None, help="Patient CrCl (mL/min)")
    p_reg_dose.add_argument("--age", type=float, default=None, help="Patient age (years)")
    p_reg_dose.add_argument("--sex", default="M", help="Patient sex (M/F), used with covariates")
    p_reg_dose.add_argument("--output-json", default=None, help="Optional JSON output path")
    p_reg_dose.set_defaults(func=cmd_recommend_regimen_dose)

    p_reg_window = sub.add_parser(
        "recommend-regimen-window", help="Recommend repeated-dose amount for trough/Cmax therapeutic window"
    )
    p_reg_window.add_argument("--drug", required=True, help="Drug name from dataset")
    p_reg_window.add_argument("--target-trough-min", type=float, required=True, help="Minimum target trough")
    p_reg_window.add_argument("--target-cmax-max", type=float, required=True, help="Maximum target Cmax")
    p_reg_window.add_argument("--interval-h", type=float, required=True, help="Dose interval in hours")
    p_reg_window.add_argument("--n-doses", type=int, required=True, help="Number of scheduled doses")
    p_reg_window.add_argument("--t-end", type=float, default=None, help="Simulation horizon in hours")
    p_reg_window.add_argument("--n-points", type=int, default=1000, help="Number of points in regimen profile")
    p_reg_window.add_argument(
        "--strategy",
        choices=["trough_min", "midpoint"],
        default="trough_min",
        help="Dose selection strategy inside feasible window",
    )
    p_reg_window.add_argument("--weight", type=float, default=None, help="Patient weight (kg)")
    p_reg_window.add_argument("--crcl", type=float, default=None, help="Patient CrCl (mL/min)")
    p_reg_window.add_argument("--age", type=float, default=None, help="Patient age (years)")
    p_reg_window.add_argument("--sex", default="M", help="Patient sex (M/F), used with covariates")
    p_reg_window.add_argument("--output-json", default=None, help="Optional JSON output path")
    p_reg_window.set_defaults(func=cmd_recommend_regimen_window)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
