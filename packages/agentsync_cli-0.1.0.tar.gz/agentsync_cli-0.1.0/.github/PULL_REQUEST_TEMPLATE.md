## Summary

<!-- Brief description of the changes -->

## Changes

-

## Testing

- [ ] Tests pass (`pytest`)
- [ ] Linting passes (`ruff check src/ tests/`)
- [ ] Formatting passes (`ruff format --check src/ tests/`)

## Related Issues

<!-- Link to issues: Fixes #123, Closes #456 -->
