"""agentsync — Sync MCP server configs and rules across AI coding agents."""

__version__ = "0.1.0"
