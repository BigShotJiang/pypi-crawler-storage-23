from .core import MatchIt

from .datasets import load_lalonde

__version__ = "0.2.2"