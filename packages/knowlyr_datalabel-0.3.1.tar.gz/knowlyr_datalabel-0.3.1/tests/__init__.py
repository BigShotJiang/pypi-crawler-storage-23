"""DataLabel tests."""
