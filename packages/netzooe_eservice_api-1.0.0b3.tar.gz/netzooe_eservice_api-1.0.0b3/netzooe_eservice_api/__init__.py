from netzooe_eservice_api.version import __version__  # noqa: F401
