"""VoiceTerm PyPI launcher package."""

__all__ = ["__version__"]

__version__ = "1.0.97"
