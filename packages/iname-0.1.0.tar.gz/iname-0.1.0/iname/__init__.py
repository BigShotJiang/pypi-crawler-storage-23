"""iname — make filenames safe and consistent for the web."""

__version__ = "0.1.0"
