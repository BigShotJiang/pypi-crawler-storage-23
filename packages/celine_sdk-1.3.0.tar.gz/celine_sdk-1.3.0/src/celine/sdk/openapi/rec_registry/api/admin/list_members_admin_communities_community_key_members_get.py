from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.paginated_response_member_list_item import PaginatedResponseMemberListItem
from ...types import UNSET, Response, Unset


def _get_kwargs(
    community_key: str,
    *,
    role: None | str | Unset = UNSET,
    status: None | str | Unset = UNSET,
    area: None | str | Unset = UNSET,
    limit: int | Unset = 50,
    cursor: None | str | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_role: None | str | Unset
    if isinstance(role, Unset):
        json_role = UNSET
    else:
        json_role = role
    params["role"] = json_role

    json_status: None | str | Unset
    if isinstance(status, Unset):
        json_status = UNSET
    else:
        json_status = status
    params["status"] = json_status

    json_area: None | str | Unset
    if isinstance(area, Unset):
        json_area = UNSET
    else:
        json_area = area
    params["area"] = json_area

    params["limit"] = limit

    json_cursor: None | str | Unset
    if isinstance(cursor, Unset):
        json_cursor = UNSET
    else:
        json_cursor = cursor
    params["cursor"] = json_cursor

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/admin/communities/{community_key}/members".format(
            community_key=quote(str(community_key), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | PaginatedResponseMemberListItem | None:
    if response.status_code == 200:
        response_200 = PaginatedResponseMemberListItem.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | PaginatedResponseMemberListItem]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    community_key: str,
    *,
    client: AuthenticatedClient | Client,
    role: None | str | Unset = UNSET,
    status: None | str | Unset = UNSET,
    area: None | str | Unset = UNSET,
    limit: int | Unset = 50,
    cursor: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | PaginatedResponseMemberListItem]:
    """List Members

     List members of a community.

    Args:
        community_key (str):
        role (None | str | Unset): Filter by role
        status (None | str | Unset): Filter by status
        area (None | str | Unset): Filter by area
        limit (int | Unset):  Default: 50.
        cursor (None | str | Unset): Pagination cursor

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | PaginatedResponseMemberListItem]
    """

    kwargs = _get_kwargs(
        community_key=community_key,
        role=role,
        status=status,
        area=area,
        limit=limit,
        cursor=cursor,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    community_key: str,
    *,
    client: AuthenticatedClient | Client,
    role: None | str | Unset = UNSET,
    status: None | str | Unset = UNSET,
    area: None | str | Unset = UNSET,
    limit: int | Unset = 50,
    cursor: None | str | Unset = UNSET,
) -> HTTPValidationError | PaginatedResponseMemberListItem | None:
    """List Members

     List members of a community.

    Args:
        community_key (str):
        role (None | str | Unset): Filter by role
        status (None | str | Unset): Filter by status
        area (None | str | Unset): Filter by area
        limit (int | Unset):  Default: 50.
        cursor (None | str | Unset): Pagination cursor

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | PaginatedResponseMemberListItem
    """

    return sync_detailed(
        community_key=community_key,
        client=client,
        role=role,
        status=status,
        area=area,
        limit=limit,
        cursor=cursor,
    ).parsed


async def asyncio_detailed(
    community_key: str,
    *,
    client: AuthenticatedClient | Client,
    role: None | str | Unset = UNSET,
    status: None | str | Unset = UNSET,
    area: None | str | Unset = UNSET,
    limit: int | Unset = 50,
    cursor: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | PaginatedResponseMemberListItem]:
    """List Members

     List members of a community.

    Args:
        community_key (str):
        role (None | str | Unset): Filter by role
        status (None | str | Unset): Filter by status
        area (None | str | Unset): Filter by area
        limit (int | Unset):  Default: 50.
        cursor (None | str | Unset): Pagination cursor

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | PaginatedResponseMemberListItem]
    """

    kwargs = _get_kwargs(
        community_key=community_key,
        role=role,
        status=status,
        area=area,
        limit=limit,
        cursor=cursor,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    community_key: str,
    *,
    client: AuthenticatedClient | Client,
    role: None | str | Unset = UNSET,
    status: None | str | Unset = UNSET,
    area: None | str | Unset = UNSET,
    limit: int | Unset = 50,
    cursor: None | str | Unset = UNSET,
) -> HTTPValidationError | PaginatedResponseMemberListItem | None:
    """List Members

     List members of a community.

    Args:
        community_key (str):
        role (None | str | Unset): Filter by role
        status (None | str | Unset): Filter by status
        area (None | str | Unset): Filter by area
        limit (int | Unset):  Default: 50.
        cursor (None | str | Unset): Pagination cursor

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | PaginatedResponseMemberListItem
    """

    return (
        await asyncio_detailed(
            community_key=community_key,
            client=client,
            role=role,
            status=status,
            area=area,
            limit=limit,
            cursor=cursor,
        )
    ).parsed
