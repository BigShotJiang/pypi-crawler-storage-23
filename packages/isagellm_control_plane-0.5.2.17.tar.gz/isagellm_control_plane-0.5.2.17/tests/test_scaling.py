"""Tests for ScalingManager auto-scaling logic (#45, #57, #58)."""

from __future__ import annotations

import asyncio
from datetime import datetime, timedelta
from unittest.mock import MagicMock

import pytest

from sagellm_control.scaling import ScalingManager, ScalingRecommendation
from sagellm_control.types import EngineInfo, EngineState


def _make_engine(
    engine_id: str,
    active_requests: int = 0,
    queue_length: int = 0,
    state: EngineState = EngineState.READY,
) -> EngineInfo:
    e = EngineInfo(
        engine_id=engine_id,
        model_id="test-model",
        host="localhost",
        port=8000,
        state=state,
        active_requests=active_requests,
        queue_length=queue_length,
    )
    return e


def _make_cp(engines: list[EngineInfo]) -> MagicMock:
    """Build a minimal ControlPlaneManager mock."""
    cp = MagicMock()
    cp.list_engines.return_value = engines

    def get_engine(eid):
        for e in engines:
            if e.engine_id == eid:
                return e
        return None

    cp.get_engine.side_effect = get_engine
    cp.update_engine_state.return_value = True
    cp.unregister_engine.return_value = True
    return cp


class TestScalingManagerInit:
    def test_default_init(self):
        cp = _make_cp([])
        sm = ScalingManager(cp)
        assert sm is not None

    def test_custom_thresholds(self):
        cp = _make_cp([])
        sm = ScalingManager(cp, scale_up_load_threshold=0.8, scale_down_load_threshold=0.1)
        assert sm._up_threshold == 0.8
        assert sm._down_threshold == 0.1


class TestEvaluateNoEngines:
    def test_no_engines_recommends_scale_up(self):
        cp = _make_cp([])
        sm = ScalingManager(cp)
        rec = sm.evaluate()
        assert rec.action == "scale_up"
        assert rec.suggested_count >= 1

    def test_no_healthy_engines_recommends_scale_up(self):
        engines = [
            _make_engine("e1", state=EngineState.ERROR),
            _make_engine("e2", state=EngineState.STOPPED),
        ]
        cp = _make_cp(engines)
        sm = ScalingManager(cp)
        rec = sm.evaluate()
        assert rec.action == "scale_up"


class TestEvaluateScaleUp:
    def test_high_load_recommends_scale_up(self):
        # assumed_capacity_per_engine=10, load_ratio = 8/10 = 0.8 >= threshold 0.7
        engines = [_make_engine("e1", active_requests=8)]
        cp = _make_cp(engines)
        sm = ScalingManager(cp, scale_up_load_threshold=0.7)
        rec = sm.evaluate()
        assert rec.action == "scale_up"
        assert rec.suggested_count >= 1

    def test_scale_up_includes_metrics(self):
        engines = [_make_engine("e1", active_requests=9)]
        cp = _make_cp(engines)
        sm = ScalingManager(cp, scale_up_load_threshold=0.7)
        rec = sm.evaluate()
        assert "load_ratio" in rec.metrics
        assert "healthy_engines" in rec.metrics

    def test_scale_up_blocked_at_max_engines(self):
        engines = [_make_engine(f"e{i}", active_requests=9) for i in range(3)]
        cp = _make_cp(engines)
        sm = ScalingManager(cp, scale_up_load_threshold=0.7, max_engines=3)
        rec = sm.evaluate()
        # At max engines, no scale-up even with high load
        assert rec.action == "none"
        assert "max" in rec.reason.lower()

    def test_queue_length_contributes_to_load(self):
        engines = [_make_engine("e1", active_requests=0, queue_length=8)]
        cp = _make_cp(engines)
        sm = ScalingManager(cp, scale_up_load_threshold=0.7)
        rec = sm.evaluate()
        assert rec.action == "scale_up"


class TestEvaluateScaleDown:
    def test_low_load_recommends_scale_down(self):
        # 3 engines, each with 0 load → ratio 0 ≤ threshold 0.2
        engines = [
            _make_engine("e1", active_requests=0),
            _make_engine("e2", active_requests=0),
            _make_engine("e3", active_requests=0),
        ]
        cp = _make_cp(engines)
        sm = ScalingManager(cp, scale_down_load_threshold=0.2, min_engines=1)
        rec = sm.evaluate()
        assert rec.action == "scale_down"
        assert len(rec.candidate_engine_ids) >= 1
        # Never reduce below min_engines=1
        assert len(rec.candidate_engine_ids) <= 2

    def test_scale_down_respects_min_engines(self):
        engines = [_make_engine("e1", active_requests=0)]
        cp = _make_cp(engines)
        sm = ScalingManager(cp, scale_down_load_threshold=0.5, min_engines=1)
        rec = sm.evaluate()
        # Only 1 engine, cannot scale down below min
        assert rec.action in ("none", "scale_down")
        if rec.action == "scale_down":
            # Should keep at least min_engines
            assert len(rec.candidate_engine_ids) == 0

    def test_scale_down_candidate_is_least_loaded(self):
        engines = [
            _make_engine("light", active_requests=0),
            _make_engine("heavy", active_requests=1),
            _make_engine("medium", active_requests=0),
        ]
        cp = _make_cp(engines)
        sm = ScalingManager(cp, scale_down_load_threshold=0.5, min_engines=1)
        rec = sm.evaluate()
        if rec.action == "scale_down":
            # Least loaded engines nominated first
            assert "heavy" not in rec.candidate_engine_ids or len(rec.candidate_engine_ids) == 2


class TestEvaluateNormal:
    def test_normal_load_returns_none(self):
        # 1 engine, 5 active, capacity 10 → ratio 0.5 (between 0.2 and 0.7)
        engines = [_make_engine("e1", active_requests=5)]
        cp = _make_cp(engines)
        sm = ScalingManager(
            cp,
            scale_up_load_threshold=0.7,
            scale_down_load_threshold=0.2,
        )
        rec = sm.evaluate()
        assert rec.action == "none"


class TestScaleDownCooldown:
    def test_cooldown_prevents_immediate_scale_down(self):
        engines = [
            _make_engine("e1", active_requests=0),
            _make_engine("e2", active_requests=0),
        ]
        cp = _make_cp(engines)
        sm = ScalingManager(
            cp,
            scale_down_load_threshold=0.5,
            min_engines=1,
            scale_down_cooldown_s=3600.0,  # 1 hour cooldown
        )
        # Set a recent last_scale_down
        sm._last_scale_down = datetime.now() - timedelta(seconds=10)
        rec = sm.evaluate()
        # Cooldown should kick in
        assert rec.action == "none"
        assert "cooldown" in rec.reason.lower()


class TestScaleDownAsync:
    def test_scale_down_graceful(self):
        engines = [
            _make_engine("e1"),
            _make_engine("e2"),
        ]
        cp = _make_cp(engines)
        sm = ScalingManager(cp)

        stopped = asyncio.run(sm.scale_down(["e1"], graceful=True))
        assert "e1" in stopped
        cp.update_engine_state.assert_called_once_with("e1", EngineState.DRAINING)

    def test_scale_down_force(self):
        engines = [_make_engine("e1")]
        cp = _make_cp(engines)
        sm = ScalingManager(cp)

        stopped = asyncio.run(sm.scale_down(["e1"], graceful=False))
        assert "e1" in stopped
        cp.unregister_engine.assert_called_once_with("e1")

    def test_scale_down_unknown_engine(self):
        cp = _make_cp([])
        sm = ScalingManager(cp)
        stopped = asyncio.run(sm.scale_down(["nonexistent"]))
        assert stopped == []

    def test_scale_down_updates_cooldown_timestamp(self):
        engines = [_make_engine("e1")]
        cp = _make_cp(engines)
        sm = ScalingManager(cp)
        assert sm._last_scale_down is None
        asyncio.run(sm.scale_down(["e1"], graceful=False))
        assert sm._last_scale_down is not None


class TestScaleUpAsync:
    def test_scale_up_returns_empty_list(self):
        cp = _make_cp([])
        sm = ScalingManager(cp)
        result = asyncio.run(sm.scale_up("test-model", num_instances=2))
        assert result == []


class TestGetScalingRecommendations:
    def test_returns_dict(self):
        engines = [_make_engine("e1", active_requests=5)]
        cp = _make_cp(engines)
        sm = ScalingManager(cp)
        result = sm.get_scaling_recommendations()
        assert isinstance(result, dict)
        assert "action" in result
        assert "scale_up_suggested" in result
        assert "scale_down_suggested" in result
        assert "metrics" in result

    def test_scale_up_flag_set(self):
        engines = [_make_engine("e1", active_requests=9)]
        cp = _make_cp(engines)
        sm = ScalingManager(cp, scale_up_load_threshold=0.7)
        result = sm.get_scaling_recommendations()
        assert result["scale_up_suggested"] is True
        assert result["scale_down_suggested"] is False


class TestScalingRecommendation:
    def test_dataclass_defaults(self):
        rec = ScalingRecommendation(action="none", reason="test")
        assert rec.suggested_count == 0
        assert rec.candidate_engine_ids == []
        assert rec.metrics == {}
