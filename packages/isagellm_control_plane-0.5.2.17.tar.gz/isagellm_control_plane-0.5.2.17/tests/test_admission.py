"""Tests for AdmissionGuard and AdmissionDecision (issues #28 / #31).

Covers:
- Admission decisions under normal, queue-full, and KV-saturated conditions
- Metrics (admission_accepted, admission_rejected, admission_rate)
- Integration with ControlPlaneManager.schedule_request()
- Edge cases: no engines, reset, get_metrics
"""

from __future__ import annotations

import asyncio

import pytest

from sagellm_control import (
    AdmissionDecision,
    AdmissionGuard,
    ControlPlaneManager,
    EngineInfo,
    EngineState,
    RequestMetadata,
    RequestStatus,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _engine(
    engine_id: str,
    *,
    queue_length: int = 0,
    kv_usage: int = 0,
    kv_capacity: int = 10_000,
    state: EngineState = EngineState.READY,
) -> EngineInfo:
    return EngineInfo(
        engine_id=engine_id,
        model_id="test-model",
        host="localhost",
        port=8000,
        state=state,
        queue_length=queue_length,
        kv_cache_usage_bytes=kv_usage,
        kv_cache_capacity_bytes=kv_capacity,
    )


def _request(
    request_id: str = "req-1", prompt_tokens: int = 128, max_tokens: int = 64
) -> RequestMetadata:
    return RequestMetadata(
        request_id=request_id,
        model_id="test-model",
        prompt="hello world",
        prompt_tokens=prompt_tokens,
        max_tokens=max_tokens,
    )


# ---------------------------------------------------------------------------
# AdmissionDecision dataclass
# ---------------------------------------------------------------------------


class TestAdmissionDecision:
    def test_admitted(self) -> None:
        d = AdmissionDecision(accepted=True, reason="Admitted", estimated_kv_tokens=512)
        assert d.accepted is True
        assert d.estimated_kv_tokens == 512

    def test_rejected(self) -> None:
        d = AdmissionDecision(accepted=False, reason="Queue full")
        assert d.accepted is False

    def test_to_dict(self) -> None:
        d = AdmissionDecision(
            accepted=True, reason="ok", estimated_kv_tokens=1, decision_time_ms=0.5
        )
        out = d.to_dict()
        assert out["accepted"] is True
        assert out["estimated_kv_tokens"] == 1
        assert "decision_time_ms" in out


# ---------------------------------------------------------------------------
# AdmissionGuard construction
# ---------------------------------------------------------------------------


class TestAdmissionGuardInit:
    def test_defaults(self) -> None:
        g = AdmissionGuard()
        assert g._max_queue_depth == 200
        assert g._kv_cache_threshold == 0.90

    def test_custom_params(self) -> None:
        g = AdmissionGuard(max_queue_depth=50, kv_cache_threshold=0.75)
        assert g._max_queue_depth == 50
        assert g._kv_cache_threshold == 0.75

    def test_invalid_queue_depth(self) -> None:
        with pytest.raises(ValueError, match="max_queue_depth"):
            AdmissionGuard(max_queue_depth=0)

    def test_invalid_kv_threshold_zero(self) -> None:
        with pytest.raises(ValueError, match="kv_cache_threshold"):
            AdmissionGuard(kv_cache_threshold=0.0)

    def test_invalid_kv_threshold_over_one(self) -> None:
        with pytest.raises(ValueError, match="kv_cache_threshold"):
            AdmissionGuard(kv_cache_threshold=1.1)

    def test_kv_threshold_exactly_one_is_allowed(self) -> None:
        g = AdmissionGuard(kv_cache_threshold=1.0)
        assert g._kv_cache_threshold == 1.0


# ---------------------------------------------------------------------------
# Core check() logic
# ---------------------------------------------------------------------------


class TestAdmissionGuardCheck:
    def test_admit_healthy_engine_low_load(self) -> None:
        guard = AdmissionGuard()
        engines = [_engine("e1")]
        decision = guard.check(_request(), engines)
        assert decision.accepted is True
        assert decision.estimated_kv_tokens > 0

    def test_reject_no_engines(self) -> None:
        guard = AdmissionGuard()
        decision = guard.check(_request(), [])
        assert decision.accepted is False
        assert "No healthy" in decision.reason

    def test_reject_queue_depth_exceeded(self) -> None:
        guard = AdmissionGuard(max_queue_depth=5)
        # total queue = 6 >= limit
        engines = [_engine("e1", queue_length=3), _engine("e2", queue_length=3)]
        decision = guard.check(_request(), engines)
        assert decision.accepted is False
        assert "Queue depth" in decision.reason

    def test_admit_queue_depth_just_below_limit(self) -> None:
        guard = AdmissionGuard(max_queue_depth=6)
        engines = [_engine("e1", queue_length=3), _engine("e2", queue_length=2)]
        # total = 5 < 6
        decision = guard.check(_request(), engines)
        assert decision.accepted is True

    def test_reject_kv_cache_saturated(self) -> None:
        guard = AdmissionGuard(kv_cache_threshold=0.9)
        # KV utilisation = 9500/10000 = 0.95 >= 0.90
        engines = [_engine("e1", kv_usage=9_500, kv_capacity=10_000)]
        decision = guard.check(_request(), engines)
        assert decision.accepted is False
        assert "KV cache" in decision.reason

    def test_admit_kv_cache_just_below_threshold(self) -> None:
        guard = AdmissionGuard(kv_cache_threshold=0.9)
        # 0.89 < 0.90
        engines = [_engine("e1", kv_usage=8_900, kv_capacity=10_000)]
        decision = guard.check(_request(), engines)
        assert decision.accepted is True

    def test_engines_without_kv_capacity_ignored_in_kv_check(self) -> None:
        """Engines with kv_capacity=0 should not influence KV utilisation."""
        guard = AdmissionGuard(kv_cache_threshold=0.9)
        engines = [_engine("e1", kv_usage=0, kv_capacity=0)]
        decision = guard.check(_request(), engines)
        assert decision.accepted is True

    def test_kv_check_uses_average_across_engines(self) -> None:
        guard = AdmissionGuard(kv_cache_threshold=0.9)
        # avg = (0.5 + 0.5) / 2 = 0.5 < 0.9
        engines = [
            _engine("e1", kv_usage=5_000, kv_capacity=10_000),
            _engine("e2", kv_usage=5_000, kv_capacity=10_000),
        ]
        decision = guard.check(_request(), engines)
        assert decision.accepted is True

    def test_decision_time_ms_populated(self) -> None:
        guard = AdmissionGuard()
        decision = guard.check(_request(), [_engine("e1")])
        assert decision.decision_time_ms >= 0.0

    def test_estimated_kv_tokens_from_prompt_tokens(self) -> None:
        guard = AdmissionGuard()
        req = _request(prompt_tokens=200, max_tokens=100)
        decision = guard.check(req, [_engine("e1")])
        assert decision.estimated_kv_tokens == 300  # 200 + 100

    def test_estimated_kv_tokens_fallback_from_prompt_chars(self) -> None:
        guard = AdmissionGuard()
        req = RequestMetadata(
            request_id="r1",
            model_id="m",
            prompt="hello world",  # 11 chars => ~2 tokens at 0.25/char
            prompt_tokens=0,
            max_tokens=64,
        )
        decision = guard.check(req, [_engine("e1")])
        # 11 * 0.25 = 2 (int) + 64 = 66
        assert decision.estimated_kv_tokens == 66


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------


class TestAdmissionGuardMetrics:
    def test_initial_metrics_zero(self) -> None:
        g = AdmissionGuard()
        assert g.admission_accepted == 0
        assert g.admission_rejected == 0

    def test_metrics_increment_on_admit(self) -> None:
        g = AdmissionGuard()
        g.check(_request("r1"), [_engine("e1")])
        g.check(_request("r2"), [_engine("e1")])
        assert g.admission_accepted == 2
        assert g.admission_rejected == 0

    def test_metrics_increment_on_reject(self) -> None:
        g = AdmissionGuard()
        g.check(_request(), [])  # rejected: no engines
        assert g.admission_rejected == 1
        assert g.admission_accepted == 0

    def test_admission_rate_all_admitted(self) -> None:
        g = AdmissionGuard()
        g.check(_request("r1"), [_engine("e1")])
        g.check(_request("r2"), [_engine("e1")])
        assert g.admission_rate == 1.0

    def test_admission_rate_mixed(self) -> None:
        g = AdmissionGuard()
        g.check(_request("r1"), [_engine("e1")])  # admit
        g.check(_request("r2"), [])  # reject
        assert g.admission_rate == pytest.approx(0.5)

    def test_admission_rate_no_requests(self) -> None:
        g = AdmissionGuard()
        assert g.admission_rate == 0.0

    def test_get_metrics_dict(self) -> None:
        g = AdmissionGuard(max_queue_depth=100, kv_cache_threshold=0.8)
        g.check(_request(), [_engine("e1")])
        m = g.get_metrics()
        assert m["admission_accepted"] == 1
        assert m["admission_rejected"] == 0
        assert m["max_queue_depth"] == 100
        assert m["kv_cache_threshold"] == 0.8

    def test_reset_metrics(self) -> None:
        g = AdmissionGuard()
        g.check(_request("r1"), [_engine("e1")])
        g.check(_request("r2"), [])
        g.reset_metrics()
        assert g.admission_accepted == 0
        assert g.admission_rejected == 0


# ---------------------------------------------------------------------------
# Integration with ControlPlaneManager
# ---------------------------------------------------------------------------


class TestAdmissionGuardIntegration:
    """Integration: ControlPlaneManager with AdmissionGuard."""

    def _make_manager(self, guard: AdmissionGuard | None = None) -> ControlPlaneManager:
        return ControlPlaneManager(
            scheduling_policy="fifo",
            routing_strategy="round_robin",
            admission_guard=guard,
        )

    def _register_engine(self, manager: ControlPlaneManager, engine_id: str = "e1") -> None:
        manager.register_engine(
            engine_id=engine_id,
            model_id="test-model",
            host="localhost",
            port=8000,
            metadata={"pre_verified_healthy": True},
        )

    # --- no guard (existing behaviour unchanged) ---

    def test_no_guard_schedules_normally(self) -> None:
        manager = self._make_manager(guard=None)
        self._register_engine(manager)
        decision = asyncio.get_event_loop().run_until_complete(
            manager.schedule_request(
                request_id="r1",
                trace_id="t1",
                model_id="test-model",
                max_tokens=64,
            )
        )
        assert decision.status == RequestStatus.SCHEDULED

    # --- guard admits ---

    def test_guard_admits_request(self) -> None:
        guard = AdmissionGuard(max_queue_depth=100)
        manager = self._make_manager(guard=guard)
        self._register_engine(manager)
        decision = asyncio.get_event_loop().run_until_complete(
            manager.schedule_request(
                request_id="r1",
                trace_id="t1",
                model_id="test-model",
                max_tokens=64,
            )
        )
        assert decision.status == RequestStatus.SCHEDULED
        assert guard.admission_accepted == 1
        assert guard.admission_rejected == 0

    # --- guard rejects (queue full) ---

    def test_guard_rejects_when_queue_full(self) -> None:
        guard = AdmissionGuard(max_queue_depth=1)
        manager = self._make_manager(guard=guard)
        # Register engine with queue_length=1 so total=1 >= limit=1
        manager._engines["e1"] = _engine("e1", queue_length=1)
        manager._model_index["test-model"] = ["e1"]

        decision = asyncio.get_event_loop().run_until_complete(
            manager.schedule_request(
                request_id="r2",
                trace_id="t2",
                model_id="test-model",
            )
        )
        assert decision.status == RequestStatus.FAILED
        assert "Admission rejected" in decision.reason
        assert guard.admission_rejected == 1

    # --- guard rejects (KV saturated) ---

    def test_guard_rejects_when_kv_saturated(self) -> None:
        guard = AdmissionGuard(kv_cache_threshold=0.5)
        manager = self._make_manager(guard=guard)
        # Engine with 80% KV utilisation >> threshold 50%
        manager._engines["e1"] = _engine("e1", kv_usage=8_000, kv_capacity=10_000)
        manager._model_index["test-model"] = ["e1"]

        decision = asyncio.get_event_loop().run_until_complete(
            manager.schedule_request(
                request_id="r3",
                trace_id="t3",
                model_id="test-model",
            )
        )
        assert decision.status == RequestStatus.FAILED
        assert "Admission rejected" in decision.reason
        assert guard.admission_rejected == 1

    # --- no healthy engines (already handled before guard) ---

    def test_fails_before_guard_when_no_healthy_engines(self) -> None:
        guard = AdmissionGuard()
        manager = self._make_manager(guard=guard)
        # No engines registered
        decision = asyncio.get_event_loop().run_until_complete(
            manager.schedule_request(
                request_id="r4",
                trace_id="t4",
                model_id="test-model",
            )
        )
        assert decision.status == RequestStatus.FAILED
        # Guard counters NOT touched (rejected before guard is called)
        assert guard.admission_accepted == 0
        assert guard.admission_rejected == 0
