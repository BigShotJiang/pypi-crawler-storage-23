"""Unit tests for sageLLM Control Plane."""

from __future__ import annotations

import pytest

from sagellm_control import (
    ControlPlaneManager,
    EngineInfo,
    EngineState,
)


class TestEngineInfo:
    """Tests for EngineInfo dataclass."""

    def test_create_engine_info(self) -> None:
        """Test creating EngineInfo."""
        engine = EngineInfo(
            engine_id="engine-001",
            model_id="Qwen/Qwen2-7B",
            host="localhost",
            port=8000,
        )
        assert engine.engine_id == "engine-001"
        assert engine.model_id == "Qwen/Qwen2-7B"
        assert engine.state == EngineState.STARTING
        assert engine.endpoint == "http://localhost:8000"

    def test_engine_info_health_properties(self) -> None:
        """Test health-related properties."""
        engine = EngineInfo(
            engine_id="engine-001",
            model_id="test-model",
            host="localhost",
            port=8000,
            state=EngineState.READY,
        )
        assert engine.is_healthy is True
        assert engine.is_accepting_requests is True
        assert engine.is_terminal is False

        engine.state = EngineState.STOPPED
        assert engine.is_healthy is False
        assert engine.is_terminal is True

    def test_engine_info_to_dict(self) -> None:
        """Test serialization."""
        engine = EngineInfo(
            engine_id="engine-001",
            model_id="test-model",
            host="localhost",
            port=8000,
        )
        d = engine.to_dict()
        assert d["engine_id"] == "engine-001"
        assert d["model_id"] == "test-model"
        assert d["state"] == "STARTING"


class TestControlPlaneManager:
    """Tests for ControlPlaneManager."""

    def test_create_manager(self) -> None:
        """Test manager creation."""
        manager = ControlPlaneManager(
            scheduling_policy="fifo",
            routing_strategy="round_robin",
        )
        assert manager.engine_count == 0

    def test_register_and_list_engines(self) -> None:
        """Test engine registration and listing."""
        manager = ControlPlaneManager()
        manager.register_engine(
            engine_id="engine-001",
            model_id="test-model",
            host="localhost",
            port=8000,
        )
        assert manager.engine_count == 1

        engines = manager.list_engines()
        assert len(engines) == 1
        assert engines[0].engine_id == "engine-001"

    def test_update_engine_state(self) -> None:
        """Test engine state updates."""
        manager = ControlPlaneManager()
        manager.register_engine("engine-001", model_id="test-model", host="localhost", port=8000)

        result = manager.update_engine_state("engine-001", EngineState.READY)
        assert result is True

        engine = manager.get_engine("engine-001")
        assert engine is not None
        assert engine.state == EngineState.READY

    @pytest.mark.asyncio
    async def test_schedule_request(self) -> None:
        """Test request scheduling through manager."""
        manager = ControlPlaneManager()
        manager.register_engine("engine-001", model_id="test-model", host="localhost", port=8000)
        manager.update_engine_state("engine-001", EngineState.READY)

        decision = await manager.schedule_request(
            request_id="req-001",
            trace_id="trace-001",
            model_id="test-model",
        )
        assert decision.is_scheduled

    @pytest.mark.asyncio
    async def test_schedule_request_uses_load_aware_placement(self) -> None:
        """Routing strategy should drive final placement when policy is not KV-aware."""
        manager = ControlPlaneManager(
            scheduling_policy="fifo",
            routing_strategy="load_aware",
        )

        manager.register_engine("engine-a", model_id="test-model", host="localhost", port=8000)
        manager.register_engine("engine-b", model_id="test-model", host="localhost", port=8001)
        manager.update_engine_state("engine-a", EngineState.READY)
        manager.update_engine_state("engine-b", EngineState.READY)

        engine_a = manager.get_engine("engine-a")
        engine_b = manager.get_engine("engine-b")
        assert engine_a is not None
        assert engine_b is not None

        # Make engine-a look heavy despite lower active request count.
        engine_a.active_requests = 1
        engine_a.queue_length = 45
        engine_a.kv_cache_usage_bytes = 9_000
        engine_a.kv_cache_capacity_bytes = 10_000
        engine_a.gpu_utilization = 0.95

        engine_b.active_requests = 5
        engine_b.queue_length = 0
        engine_b.kv_cache_usage_bytes = 1_000
        engine_b.kv_cache_capacity_bytes = 10_000
        engine_b.gpu_utilization = 0.05

        decision = await manager.schedule_request(
            request_id="req-load-aware",
            trace_id="trace-load-aware",
            model_id="test-model",
        )

        assert decision.is_scheduled
        assert decision.engine_id == "engine-b"

    @pytest.mark.asyncio
    async def test_schedule_request_kv_aware_rejects_over_budget(self) -> None:
        """KV-aware policy should reject requests that exceed KV token budget."""
        manager = ControlPlaneManager(
            scheduling_policy="kv_aware",
            routing_strategy="least_loaded",
        )
        manager.register_engine("engine-001", model_id="test-model", host="localhost", port=8000)
        manager.update_engine_state("engine-001", EngineState.READY)

        policy = manager._get_policy()
        policy._max_kv_tokens_per_engine = 32  # type: ignore[attr-defined]

        decision = await manager.schedule_request(
            request_id="req-kv-over",
            trace_id="trace-kv-over",
            model_id="test-model",
            prompt="x" * 1000,
            max_tokens=64,
        )

        assert decision.is_scheduled is False
        assert "KV budget" in decision.reason

    @pytest.mark.asyncio
    async def test_schedule_request_with_scheduler_ir_hints(self) -> None:
        """Scheduler IR integration should enrich decision reason with IR hints."""
        manager = ControlPlaneManager(
            scheduling_policy="kv_aware_ir",
            routing_strategy="least_loaded",
            enable_scheduler_ir=True,
        )
        manager.register_engine("engine-001", model_id="test-model", host="localhost", port=8000)
        manager.update_engine_state("engine-001", EngineState.READY)

        decision = await manager.schedule_request(
            request_id="req-ir-hints",
            trace_id="trace-ir-hints",
            model_id="test-model",
            prompt="scheduler ir integration test",
            max_tokens=16,
        )

        assert decision.is_scheduled
        assert "ir_kv_required=" in decision.reason
        assert "ir_prefix_reuse=" in decision.reason

    def test_get_status(self) -> None:
        """Test status summary."""
        manager = ControlPlaneManager()
        manager.register_engine("engine-001", model_id="test-model", host="localhost", port=8000)
        manager.update_engine_state("engine-001", EngineState.READY)

        status = manager.get_status()
        assert status["total_engines"] == 1
        assert status["healthy_engines"] == 1
        assert "test-model" in status["models"]
