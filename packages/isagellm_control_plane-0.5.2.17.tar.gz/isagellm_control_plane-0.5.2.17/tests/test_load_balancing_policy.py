"""Tests for LoadBalancingPolicy (#43)."""

from __future__ import annotations

import pytest

from sagellm_control.policies import LoadBalancingPolicy
from sagellm_control.types import (
    EngineInfo,
    EngineState,
    RequestMetadata,
    RequestStatus,
)


def _make_engine(
    engine_id: str,
    active_requests: int = 0,
    queue_length: int = 0,
    state: EngineState = EngineState.READY,
) -> EngineInfo:
    """Helper: create an EngineInfo for testing."""
    e = EngineInfo(
        engine_id=engine_id,
        model_id="test-model",
        host="localhost",
        port=8000,
        state=state,
        active_requests=active_requests,
        queue_length=queue_length,
    )
    return e


def _make_request(request_id: str = "req-001") -> RequestMetadata:
    return RequestMetadata(request_id=request_id)


class TestLoadBalancingPolicyCreation:
    def test_default_strategy(self):
        policy = LoadBalancingPolicy()
        assert policy.strategy == "least_connections"
        assert "load_balancing" in policy.name

    def test_explicit_strategy(self):
        for strategy in ["round_robin", "least_connections", "power_of_two", "weighted_random"]:
            p = LoadBalancingPolicy(strategy=strategy)
            assert p.strategy == strategy

    def test_invalid_strategy_raises(self):
        with pytest.raises(ValueError, match="Unknown load balancing strategy"):
            LoadBalancingPolicy(strategy="nonexistent")

    def test_name_includes_strategy(self):
        p = LoadBalancingPolicy(strategy="round_robin")
        assert "round_robin" in p.name


class TestNoHealthyEngines:
    def test_no_candidates_returns_failed(self):
        policy = LoadBalancingPolicy()
        req = _make_request()
        decision = policy.schedule(req, [], [])
        assert decision.status == RequestStatus.FAILED

    def test_all_unhealthy_returns_failed(self):
        policy = LoadBalancingPolicy()
        req = _make_request()
        engines = [
            _make_engine("e1", state=EngineState.ERROR),
            _make_engine("e2", state=EngineState.STOPPED),
        ]
        decision = policy.schedule(req, engines, [])
        assert decision.status == RequestStatus.FAILED


class TestLeastConnections:
    def test_routes_to_least_loaded(self):
        policy = LoadBalancingPolicy(strategy="least_connections")
        req = _make_request()
        engines = [
            _make_engine("e1", active_requests=5),
            _make_engine("e2", active_requests=1),
            _make_engine("e3", active_requests=10),
        ]
        decision = policy.schedule(req, engines, [])
        assert decision.status == RequestStatus.SCHEDULED
        assert decision.engine_id == "e2"

    def test_tie_broken_by_engine_id(self):
        policy = LoadBalancingPolicy(strategy="least_connections")
        req = _make_request()
        engines = [
            _make_engine("e_b", active_requests=0),
            _make_engine("e_a", active_requests=0),
        ]
        decision = policy.schedule(req, engines, [])
        # Alphabetically first wins on tie
        assert decision.engine_id == "e_a"

    def test_queued_requests_add_to_load(self):
        policy = LoadBalancingPolicy(strategy="least_connections")
        req = _make_request()
        engines = [
            _make_engine("e1", active_requests=2, queue_length=8),  # load=10
            _make_engine("e2", active_requests=0, queue_length=0),  # load=0
        ]
        decision = policy.schedule(req, engines, [])
        assert decision.engine_id == "e2"


class TestRoundRobin:
    def test_cycles_through_engines(self):
        policy = LoadBalancingPolicy(strategy="round_robin")
        req = _make_request()
        engines = [
            _make_engine("e1"),
            _make_engine("e2"),
            _make_engine("e3"),
        ]
        ids = [policy.schedule(req, engines, []).engine_id for _ in range(6)]
        # Should cycle: e1, e2, e3, e1, e2, e3
        assert ids == ["e1", "e2", "e3", "e1", "e2", "e3"]

    def test_single_engine_always_selected(self):
        policy = LoadBalancingPolicy(strategy="round_robin")
        req = _make_request()
        engines = [_make_engine("solo")]
        for _ in range(3):
            d = policy.schedule(req, engines, [])
            assert d.engine_id == "solo"


class TestPowerOfTwo:
    def test_schedules_successfully(self):
        policy = LoadBalancingPolicy(strategy="power_of_two")
        req = _make_request()
        engines = [_make_engine(f"e{i}", active_requests=i) for i in range(5)]
        decision = policy.schedule(req, engines, [])
        assert decision.status == RequestStatus.SCHEDULED

    def test_favors_less_loaded(self):
        """With 2 engines of known load, always picks the less loaded."""
        policy = LoadBalancingPolicy(strategy="power_of_two")
        req = _make_request()
        # Only 2 engines - power_of_two samples both, picks less loaded
        engines = [
            _make_engine("heavy", active_requests=100),
            _make_engine("light", active_requests=0),
        ]
        decision = policy.schedule(req, engines, [])
        assert decision.engine_id == "light"


class TestWeightedRandom:
    def test_schedules_successfully(self):
        policy = LoadBalancingPolicy(strategy="weighted_random")
        req = _make_request()
        engines = [_make_engine(f"e{i}") for i in range(3)]
        decision = policy.schedule(req, engines, [])
        assert decision.status == RequestStatus.SCHEDULED
        assert decision.engine_id in {e.engine_id for e in engines}

    def test_high_load_engine_rarely_selected(self):
        """A very heavily loaded engine should rarely win with weighted random."""
        policy = LoadBalancingPolicy(strategy="weighted_random")
        req = _make_request()
        engines = [
            _make_engine("heavy", active_requests=1000),
            _make_engine("light", active_requests=0),
        ]
        selections = [policy.schedule(req, engines, []).engine_id for _ in range(100)]
        heavy_count = selections.count("heavy")
        # With such an extreme imbalance, heavy should be chosen very rarely
        assert heavy_count < 20  # loose bound - light weight ~1/1001


class TestReorderQueue:
    def test_reorder_returns_fifo(self):
        policy = LoadBalancingPolicy(strategy="round_robin")
        requests = [_make_request(f"req-{i:03d}") for i in range(5)]
        result = policy.reorder_queue(requests)
        assert [r.request_id for r in result] == [r.request_id for r in requests]


class TestLoadStats:
    def test_get_load_stats(self):
        policy = LoadBalancingPolicy()
        engines = [
            _make_engine("e1", active_requests=3, queue_length=2),
            _make_engine("e2", active_requests=0, queue_length=0),
        ]
        stats = policy.get_load_stats(engines)
        assert stats["e1"] == 5.0
        assert stats["e2"] == 0.0


class TestDecisionReason:
    def test_reason_contains_strategy(self):
        policy = LoadBalancingPolicy(strategy="least_connections")
        req = _make_request()
        engines = [_make_engine("e1")]
        decision = policy.schedule(req, engines, [])
        assert "least_connections" in decision.reason
