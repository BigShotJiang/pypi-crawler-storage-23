"""Tests for sagellm_control observability: scheduling metrics and trace integration.

Covers:
- SchedulingMetrics dataclass serialisation
- ControlPlaneMetricsCollector aggregate stats and percentiles
- TraceContext context-variable propagation
- SchedulingSpan timing and attribute recording
- ControlPlaneManager.schedule_request() metric recording
- ControlPlaneManager.get_metrics_snapshot() / .metrics_collector
- ControlPlanePrometheusExporter (skipped when prometheus_client absent)

Issues: #47, #48, #60, #62, #63, #64
"""

from __future__ import annotations

import asyncio
import json
import time

import pytest

from sagellm_control.observability import (
    PROMETHEUS_AVAILABLE,
    ControlPlaneMetricsCollector,
    ControlPlanePrometheusExporter,
    SchedulingMetrics,
    SchedulingSpan,
    TraceContext,
    get_current_trace_context,
)
from sagellm_control.observability.metrics import _percentiles
from sagellm_control.observability.tracing import scheduling_span

# ---------------------------------------------------------------------------
# SchedulingMetrics tests
# ---------------------------------------------------------------------------


class TestSchedulingMetrics:
    """Test SchedulingMetrics dataclass."""

    def test_defaults(self) -> None:
        m = SchedulingMetrics()
        assert m.request_id == ""
        assert m.trace_id == ""
        assert m.engine_id is None
        assert m.success is False

    def test_to_dict_keys(self) -> None:
        m = SchedulingMetrics(
            request_id="r1",
            trace_id="t1",
            engine_id="e1",
            wait_ms=5.0,
            decision_ms=1.0,
            success=True,
        )
        d = m.to_dict()
        assert d["request_id"] == "r1"
        assert d["trace_id"] == "t1"
        assert d["engine_id"] == "e1"
        assert d["wait_ms"] == 5.0
        assert d["success"] is True

    def test_to_json_valid(self) -> None:
        m = SchedulingMetrics(request_id="r2", trace_id="t2", success=True)
        payload = json.loads(m.to_json())
        assert payload["request_id"] == "r2"


# ---------------------------------------------------------------------------
# ControlPlaneMetricsCollector tests
# ---------------------------------------------------------------------------


class TestControlPlaneMetricsCollector:
    """Test aggregate scheduling metrics collection."""

    def test_initial_state(self) -> None:
        c = ControlPlaneMetricsCollector()
        assert c.total_requests == 0
        assert c.successful_decisions == 0
        assert c.failed_decisions == 0
        assert c.success_rate == 1.0  # No data → 1.0 by convention

    def test_record_success(self) -> None:
        c = ControlPlaneMetricsCollector()
        m = c.record_scheduling_decision(
            request_id="r1",
            trace_id="t1",
            engine_id="e1",
            wait_ms=10.0,
            decision_ms=0.5,
            queue_length_at_decision=2,
            success=True,
            policy_name="fifo",
        )
        assert isinstance(m, SchedulingMetrics)
        assert c.total_requests == 1
        assert c.successful_decisions == 1
        assert c.failed_decisions == 0
        assert c.success_rate == 1.0
        assert c.queue_length_current == 2

    def test_record_failure(self) -> None:
        c = ControlPlaneMetricsCollector()
        c.record_scheduling_decision(
            request_id="r1",
            trace_id="t1",
            engine_id=None,
            wait_ms=1.0,
            decision_ms=0.1,
            queue_length_at_decision=0,
            success=False,
            failure_reason="no_healthy_engines",
        )
        assert c.failed_decisions == 1
        assert c.success_rate == 0.0

    def test_engine_assignment_counts(self) -> None:
        c = ControlPlaneMetricsCollector()
        for _ in range(3):
            c.record_scheduling_decision(
                request_id="r",
                trace_id="t",
                engine_id="e1",
                wait_ms=1.0,
                decision_ms=0.1,
                queue_length_at_decision=0,
                success=True,
            )
        c.record_scheduling_decision(
            request_id="r",
            trace_id="t",
            engine_id="e2",
            wait_ms=1.0,
            decision_ms=0.1,
            queue_length_at_decision=0,
            success=True,
        )
        counts = c.engine_assignment_counts()
        assert counts["e1"] == 3
        assert counts["e2"] == 1

    def test_wait_percentiles(self) -> None:
        c = ControlPlaneMetricsCollector()
        for ms in [10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0, 100.0]:
            c.record_scheduling_decision(
                request_id="r",
                trace_id="t",
                engine_id="e",
                wait_ms=ms,
                decision_ms=0.1,
                queue_length_at_decision=1,
                success=True,
            )
        p = c.wait_percentiles()
        assert p["p50"] > 0
        assert p["p95"] >= p["p50"]
        assert p["p99"] >= p["p95"]

    def test_snapshot_keys(self) -> None:
        c = ControlPlaneMetricsCollector()
        c.record_scheduling_decision("r", "t", "e", 5.0, 0.5, 1, True)
        snap = c.snapshot()
        expected_keys = {
            "total_requests",
            "successful_decisions",
            "failed_decisions",
            "success_rate",
            "queue_length_current",
            "wait_ms",
            "decision_ms",
            "engine_assignment_counts",
        }
        assert expected_keys.issubset(snap.keys())

    def test_recent_history(self) -> None:
        c = ControlPlaneMetricsCollector()
        for i in range(10):
            c.record_scheduling_decision(f"r{i}", "t", "e", 1.0, 0.1, 0, True)
        history = c.recent_history(5)
        assert len(history) == 5
        assert history[-1].request_id == "r9"

    def test_reset(self) -> None:
        c = ControlPlaneMetricsCollector()
        c.record_scheduling_decision("r", "t", "e", 1.0, 0.1, 0, True)
        c.reset()
        assert c.total_requests == 0
        assert c.recent_history() == []

    def test_max_history_bound(self) -> None:
        c = ControlPlaneMetricsCollector(max_history=5)
        for i in range(10):
            c.record_scheduling_decision(f"r{i}", "t", "e", 1.0, 0.1, 0, True)
        assert len(c.recent_history(100)) <= 5


# ---------------------------------------------------------------------------
# Percentile helper tests
# ---------------------------------------------------------------------------


class TestPercentiles:
    """Test the internal _percentiles helper."""

    def test_empty(self) -> None:
        p = _percentiles([])
        assert p == {"p50": 0.0, "p95": 0.0, "p99": 0.0}

    def test_single(self) -> None:
        p = _percentiles([42.0])
        assert p["p50"] == 42.0
        assert p["p95"] == 42.0
        assert p["p99"] == 42.0

    def test_ordering(self) -> None:
        samples = list(range(1, 101))  # 1..100
        p = _percentiles([float(s) for s in samples])
        assert p["p50"] <= p["p95"] <= p["p99"]


# ---------------------------------------------------------------------------
# TraceContext tests
# ---------------------------------------------------------------------------


class TestTraceContext:
    """Test trace-context propagation via contextvars."""

    def test_context_set_and_restore(self) -> None:
        before = get_current_trace_context()
        assert before["trace_id"] == ""

        with TraceContext(trace_id="trace-001", request_id="req-001"):
            inner = get_current_trace_context()
            assert inner["trace_id"] == "trace-001"
            assert inner["request_id"] == "req-001"
            assert inner["span_id"] != ""

        after = get_current_trace_context()
        assert after["trace_id"] == ""

    def test_nested_contexts(self) -> None:
        with TraceContext(trace_id="outer", request_id="r-outer"):
            assert get_current_trace_context()["trace_id"] == "outer"
            with TraceContext(trace_id="inner", request_id="r-inner"):
                assert get_current_trace_context()["trace_id"] == "inner"
            assert get_current_trace_context()["trace_id"] == "outer"

    def test_auto_generate_trace_id(self) -> None:
        with TraceContext() as ctx:
            assert len(ctx.trace_id) > 0
            active = get_current_trace_context()
            assert active["trace_id"] == ctx.trace_id

    def test_async_context_isolation(self) -> None:
        """Verify that asyncio tasks each get their own context copy."""

        async def _outer() -> str:
            with TraceContext(trace_id="task-outer"):
                # Inner task in a new asyncio Task gets a copy of the current
                # context, so it starts with "task-outer" but any mutations
                # inside it remain isolated.
                inner_result: list[str] = []

                async def _inner() -> None:
                    with TraceContext(trace_id="task-inner"):
                        inner_result.append(get_current_trace_context()["trace_id"])

                await asyncio.get_event_loop().create_task(_inner())
                # Outer context should be unaffected
                return get_current_trace_context()["trace_id"]

        loop = asyncio.new_event_loop()
        try:
            result = loop.run_until_complete(_outer())
        finally:
            loop.close()
        assert result == "task-outer"


# ---------------------------------------------------------------------------
# SchedulingSpan tests
# ---------------------------------------------------------------------------


class TestSchedulingSpan:
    """Test the lightweight span context manager."""

    def test_span_records_duration(self) -> None:
        with TraceContext(trace_id="t1", request_id="r1"):
            with SchedulingSpan("test_span") as span:
                time.sleep(0.01)

        assert span.data.duration_ms >= 5.0  # at least 5 ms
        assert span.data.name == "test_span"
        assert span.data.trace_id == "t1"
        assert span.data.request_id == "r1"

    def test_span_set_attribute(self) -> None:
        with SchedulingSpan("test_span") as span:
            span.set_attribute("engine_id", "e1")
            span.set_attribute("policy", "fifo")

        assert span.data.attributes["engine_id"] == "e1"
        assert span.data.attributes["policy"] == "fifo"

    def test_span_captures_error(self) -> None:
        with pytest.raises(ValueError):
            with SchedulingSpan("err_span") as span:
                raise ValueError("boom")

        assert span.data.error == "boom"

    def test_scheduling_span_contextmanager(self) -> None:
        with scheduling_span("algo_span") as span:
            span.set_attribute("k", "v")
        assert span.data.duration_ms >= 0.0
        assert span.data.attributes["k"] == "v"


# ---------------------------------------------------------------------------
# ControlPlaneManager integration tests
# ---------------------------------------------------------------------------


class TestControlPlaneManagerObservability:
    """Test that ControlPlaneManager records metrics through schedule_request."""

    def _make_manager(self):
        from sagellm_control import ControlPlaneManager

        mgr = ControlPlaneManager(scheduling_policy="fifo")
        mgr.register_engine(
            engine_id="e1",
            model_id="test-model",
            host="localhost",
            port=8001,
            metadata={"pre_verified_healthy": True},
        )
        return mgr

    def test_metrics_collector_property(self) -> None:
        mgr = self._make_manager()
        assert isinstance(mgr.metrics_collector, ControlPlaneMetricsCollector)

    def test_get_metrics_snapshot_returns_dict(self) -> None:
        mgr = self._make_manager()
        snap = mgr.get_metrics_snapshot()
        assert isinstance(snap, dict)
        assert "total_requests" in snap

    def test_successful_schedule_recorded(self) -> None:
        mgr = self._make_manager()
        decision = asyncio.get_event_loop().run_until_complete(
            mgr.schedule_request(
                request_id="req-1",
                trace_id="trace-1",
                model_id="test-model",
            )
        )
        assert decision.is_scheduled
        snap = mgr.get_metrics_snapshot()
        assert snap["total_requests"] == 1
        assert snap["successful_decisions"] == 1
        assert snap["failed_decisions"] == 0
        assert "e1" in snap["engine_assignment_counts"]

    def test_failed_schedule_recorded(self) -> None:
        mgr = self._make_manager()
        decision = asyncio.get_event_loop().run_until_complete(
            mgr.schedule_request(
                request_id="req-fail",
                trace_id="trace-fail",
                model_id="unknown-model",  # No engines for this model
            )
        )
        assert not decision.is_scheduled
        snap = mgr.get_metrics_snapshot()
        assert snap["total_requests"] == 1
        assert snap["failed_decisions"] == 1

    def test_wait_ms_recorded(self) -> None:
        mgr = self._make_manager()
        asyncio.get_event_loop().run_until_complete(
            mgr.schedule_request(
                request_id="req-2",
                trace_id="trace-2",
                model_id="test-model",
            )
        )
        history = mgr.metrics_collector.recent_history(1)
        assert len(history) == 1
        # Wait time should be a small non-negative number
        assert history[0].wait_ms >= 0.0
        assert history[0].decision_ms >= 0.0
        assert history[0].trace_id == "trace-2"

    def test_multiple_requests_cumulate(self) -> None:
        mgr = self._make_manager()
        loop = asyncio.get_event_loop()
        for i in range(5):
            loop.run_until_complete(
                mgr.schedule_request(
                    request_id=f"req-{i}",
                    trace_id=f"trace-{i}",
                    model_id="test-model",
                )
            )
        snap = mgr.get_metrics_snapshot()
        assert snap["total_requests"] == 5
        assert snap["successful_decisions"] == 5


# ---------------------------------------------------------------------------
# Prometheus exporter tests (optional dep)
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not PROMETHEUS_AVAILABLE, reason="prometheus_client not installed")
class TestControlPlanePrometheusExporter:
    """Test Prometheus export (requires prometheus_client)."""

    def test_export_not_empty(self) -> None:
        exp = ControlPlanePrometheusExporter()
        c = ControlPlaneMetricsCollector()
        c.record_scheduling_decision("r1", "t1", "e1", 5.0, 0.5, 2, True, policy_name="fifo")
        exp.update(c.snapshot())
        output = exp.export().decode("utf-8")
        assert "sagellm_cp_requests_total" in output

    def test_observe_wait_and_decision(self) -> None:
        exp = ControlPlanePrometheusExporter()
        exp.observe_wait(10.5)
        exp.observe_decision(0.3)
        output = exp.export().decode("utf-8")
        assert "sagellm_cp_wait_ms" in output
        assert "sagellm_cp_decision_ms" in output

    def test_queue_length_gauge(self) -> None:
        exp = ControlPlanePrometheusExporter()
        exp.update_queue_length(7)
        output = exp.export().decode("utf-8")
        assert "sagellm_cp_queue_length" in output

    def test_delta_counter_increments(self) -> None:
        exp = ControlPlanePrometheusExporter()
        snap1 = {
            "total_requests": 10,
            "successful_decisions": 9,
            "failed_decisions": 1,
            "queue_length_current": 2,
            "wait_ms": {"p50": 5.0, "p95": 20.0, "p99": 40.0},
            "decision_ms": {"p50": 0.3, "p95": 1.0, "p99": 2.0},
            "engine_assignment_counts": {"e1": 9},
        }
        exp.update(snap1)
        snap2 = {**snap1, "total_requests": 15, "successful_decisions": 14}
        exp.update(snap2)
        # No assertion on specific Prometheus internal values, just verify no error


@pytest.mark.skipif(PROMETHEUS_AVAILABLE, reason="Only when prometheus_client is absent")
class TestControlPlanePrometheusExporterImportError:
    """Test graceful failure when prometheus_client is absent."""

    def test_raises_import_error(self) -> None:
        with pytest.raises(ImportError):
            ControlPlanePrometheusExporter()
