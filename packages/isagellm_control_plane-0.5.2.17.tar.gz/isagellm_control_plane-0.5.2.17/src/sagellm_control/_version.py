"""Version information for sagellm-control-plane."""

__version__ = "0.5.2.17"
__author__ = "IntelliStream Team"
