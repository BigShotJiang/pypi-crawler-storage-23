"""Generation models and sampling."""
