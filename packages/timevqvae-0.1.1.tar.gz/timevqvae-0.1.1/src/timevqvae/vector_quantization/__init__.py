from timevqvae.vector_quantization.vq import VectorQuantize

