"""Evaluation utilities and metrics."""
