from __future__ import annotations

import os
import sys
from pathlib import Path


def main() -> None:
    binary_name = "xurl.exe" if os.name == "nt" else "xurl"
    binary_path = Path(__file__).resolve().parent / "bin" / binary_name
    if not binary_path.exists():
        raise FileNotFoundError(f"xurl binary not found: {binary_path}")

    os.execv(str(binary_path), [str(binary_path), *sys.argv[1:]])
