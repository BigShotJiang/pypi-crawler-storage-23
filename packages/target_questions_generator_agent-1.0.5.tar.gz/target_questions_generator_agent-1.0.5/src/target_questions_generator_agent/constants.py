"""
Prompt Constants for Target Questions Generator Agent

This file contains all prompts used by the Target Questions Generator Agent.
All prompts are centralized here for easy review and maintenance.

Prompt Types:
- PROMPT_TEMPLATE_*: Templates for dynamic content formatting
- SYSTEM_PROMPT_*: Role definitions and system instructions
"""

from typing import Optional, Dict, List, Any
import json


# =============================================================================
# SYSTEM PROMPTS
# =============================================================================

SYSTEM_PROMPT_QUESTION_GENERATOR = """You are an expert AI agent specialized in generating user-friendly questions to help users CREATE and DEFINE a NEW TARGET VARIABLE for supervised machine learning problems.

Your primary role is to:
1. Generate questions that gather requirements to CREATE a new target variable from existing data
2. Help users define the business logic for deriving the target (e.g., thresholds, conditions, aggregations)
3. Ask about the definition of outcomes (what constitutes success, churn, high-value, etc.)
4. Clarify time windows, conditions, and business rules for target generation

**Key Principles:**
- Questions must be SHORT, SIMPLE, and DOMAIN-AWARE
- Use business terminology relevant to the domain, not technical ML jargon
- Focus on gathering the BUSINESS RULES needed to generate the target variable
- Help users articulate what outcome they want to predict and how to define it from data

**Question Types to Generate Based on ML Approach:**

For BINARY CLASSIFICATION (e.g., churn prediction, fraud detection):
- What defines a positive outcome? (e.g., "What constitutes a churned customer?")
- What time window should be used? (e.g., "How many days of inactivity means churn?")
- What threshold defines the event? (e.g., "Below what purchase amount is considered low-value?")
- What conditions must be met? (e.g., "Should we only consider customers with at least 1 purchase?")

For MULTICLASS CLASSIFICATION (e.g., customer segmentation, product categorization):
- How many categories should the target have?
- What defines each category? (e.g., "What spending ranges define Low/Medium/High value?")
- Are categories mutually exclusive?
- What is the basis for categorization? (column to derive from, rules)

For TIME SERIES MULTICLASS CLASSIFICATION (e.g., network threat classification, patient condition monitoring):
- How many severity/threat levels should the target have? (e.g., "Normal, Suspicious, Malicious" or "Stable, Declining, Critical")
- What defines each category based on temporal patterns? (e.g., "What traffic patterns indicate suspicious vs malicious activity?")
- What time window should be analyzed? (e.g., "Should we classify based on last 5 minutes or last 1 hour of observations?")
- What temporal features matter most? (e.g., "Are sudden spikes, gradual trends, or periodic patterns most indicative?")

For REGRESSION (e.g., price prediction, demand forecasting):
- Which value should be predicted? (e.g., "Should we predict total revenue or average order value?")
- What aggregation is needed? (e.g., "Should we predict daily, weekly, or monthly totals?")
- What time horizon? (e.g., "Predict value for next 7 days or 30 days?")
- Any transformations needed? (e.g., "Should we predict log of price?")

**IMPORTANT - UI Implementation:**
- All UI inputs will be textboxes (text input) for the current implementation
- Provide sensible options based on dataset column insights
- Set ui_type to "text" for all questions

**Output Format:**
You MUST return a valid JSON object with the following structure:
{
    "questions": [
        {
            "raw_requirement_key": "descriptive_key_for_this_requirement",
            "question": "User-friendly question text",
            "ui_type": "text",
            "options": ["option1", "option2"],
            "default_value": "suggested_default",
            "data_type": "string|integer|float|boolean|date",
            "validation": {
                "min": null or number,
                "max": null or number,
                "required": true/false,
                "pattern": null or regex_string,
                "allowed_values": null or ["value1", "value2"]
            },
            "help_text": "Helpful text explaining the question in business terms"
        }
    ]
}

**Important:**
- Generate 3-6 questions focused on DEFINING/CREATING the target variable
- Questions should gather business rules and thresholds for target generation
- Make questions domain-specific using the provided context
- Use dataset column insights to suggest relevant columns and realistic thresholds
- Keep questions concise and actionable
- Do NOT ask about model hyperparameters (learning_rate, n_estimators, max_depth, etc.)"""


# =============================================================================
# PROMPT FORMATTING FUNCTIONS
# =============================================================================

def format_system_prompt_question_generator() -> str:
    """
    Format the system prompt for question generation.
    
    Returns:
        System prompt string
    """
    return SYSTEM_PROMPT_QUESTION_GENERATOR


def format_user_prompt_question_generator(
    domain_info: Dict[str, Any],
    usecase_info: Dict[str, Any],
    ml_approach: Dict[str, Any],
    raw_requirements: Dict[str, Any],
    dataset_insights: Dict[str, Any],
    column_insights: Dict[str, Any]
) -> str:
    """
    Format the user prompt for question generation with all context.
    
    Args:
        domain_info: Domain information dictionary
        usecase_info: Use case information dictionary
        ml_approach: ML approach information dictionary
        raw_requirements: Raw technical requirements dictionary
        dataset_insights: General dataset insights dictionary
        column_insights: Column-level insights dictionary
        
    Returns:
        Formatted user prompt string
    """
    
    # Format domain info
    domain_text = f"""
Domain Information:
- Domain Name: {domain_info.get('business_domain_name', 'N/A')}
- Domain Description: {domain_info.get('business_domain_info', 'N/A')}
- Optimization Problems: {json.dumps(domain_info.get('business_optimization_problems', {}), indent=2)}
"""
    
    # Format use case info
    usecase_text = f"""
Use Case Information:
{json.dumps(usecase_info, indent=2)}
"""
    
    # Format ML approach
    ml_approach_text = f"""
ML Approach:
- Name: {ml_approach.get('name', 'N/A')}
- Description: {ml_approach.get('description', 'N/A')}
- Constraints: {json.dumps(ml_approach.get('constraints', []), indent=2)}
"""
    
    # Format raw requirements (now used as additional context if provided)
    raw_requirements_text = ""
    if raw_requirements:
        raw_requirements_text = f"""
Additional Context/Requirements:
{json.dumps(raw_requirements, indent=2)}
"""
    
    # Format dataset insights
    dataset_text = f"""
Dataset Insights:
- Total Rows: {dataset_insights.get('total_row_count', 'N/A')}
- Column Insights: {json.dumps(dataset_insights.get('column_insights', {}), indent=2)}
"""
    
    # Format column insights
    column_text = f"""
Column-Level Insights:
{json.dumps(column_insights, indent=2)}
"""
    
    # Combine into full prompt
    user_prompt = f"""Generate questions to help the user CREATE and DEFINE a NEW TARGET VARIABLE for their supervised learning problem.

{domain_text}

{usecase_text}

{ml_approach_text}
{raw_requirements_text}
{dataset_text}

{column_text}

**Instructions:**
1. Generate 3-6 questions that gather the BUSINESS RULES needed to create the target variable
2. Questions should help define:
   - What outcome/event/value the user wants to predict
   - What thresholds or conditions define that outcome
   - What time windows or aggregations are needed (if applicable)
   - Which existing columns will be used to derive the target
3. Use domain terminology from domain_info and usecase_info
4. Leverage dataset_insights and column_insights to:
   - Suggest relevant columns that could be used to derive the target
   - Provide realistic default thresholds based on data statistics (min, max, mean)
   - Offer sensible options based on data characteristics
5. Make questions short, simple, and actionable
6. Focus on BUSINESS LOGIC for creating the target variable, not model hyperparameters

Return ONLY a valid JSON object matching the structure specified in the system prompt."""

    return user_prompt

