
definitions = {
 "binary_classification":
  "Predicts one of TWO possible outcomes (Yes/No, True/False, 1/0, Pass/Fail). Uses historical data with labels to learn patterns. Predictions are categorical, not numerical values. Time is NOT a critical feature for prediction. Example: Predicting whether a customer will churn (Yes/No) based on their usage patterns and demographics.",

 "multiclass_classification":
  "Predicts one of THREE or MORE possible categories. Uses labeled historical data to learn which category a new observation belongs to. Output is a discrete class label, not a number. Time is NOT a critical feature for prediction. Example: Classifying a support ticket into categories like Billing, Technical, or General Inquiry based on the ticket content.",                

 "regression":
  "Predicts a continuous numerical value rather than a category. Uses historical data with known outcomes to learn relationships between input features and the target number. Time may exist in the data but is not the primary driver. Example: Estimating a property's selling price based on its size, location, and number of bedrooms.",

 "timeseries_regression":
  "Predicts future numerical values based on patterns observed over time. Temporal order, trends, and seasonality are essential for making accurate forecasts. The sequence of past observations drives the prediction. Example: Forecasting next month's electricity demand based on historical consumption patterns and seasonal trends.",

 "timeseries_binary_classification":
  "Predicts one of TWO possible outcomes where temporal patterns in the data are essential for the prediction. The order and sequence of past observations carry critical information — trends, patterns, and changes over time drive the classification. Example: Predicting whether a machine will fail in the next 24 hours based on sensor readings collected over the past week.",

 "timeseries_multiclass_classification":
  "Predicts one of THREE or MORE categories where temporal patterns in the data are essential for the prediction. The sequence, trends, and timebased dependencies in past observations drive the classification. Example: Classifying a patient's condition as Stable, Declining, or Critical based on vital signs monitored over several hours.",

 "recommendation":
  "Produces ranked lists or personalized suggestions rather than a single prediction. Analyzes user preferences, item attributes, and historical interactions to surface the most relevant items. Output is an ordered set of recommendations, not a class or number. Example: Suggesting products a customer is most likely to purchase based on their browsing history and similar users' preferences.",

 "timeseries_recommendation":
  "Produces personalized suggestions where the order and recency of user actions are essential. Recent interactions and sessionlevel behavior drive what is recommended next. Temporal context determines relevance. Example: Recommending the next song to play based on what a user has listened to in the current session and recent listening trends.",  

 "clustering":
  "Groups similar data points together without predefined labels. Discovers natural structure and segments within the data. No target variable is needed — the algorithm identifies patterns on its own. Example: Segmenting customers into distinct groups such as highvalue frequent buyers, occasional browsers, and discount seekers based on their purchasing behavior.",

 "anomaly_detection":
  "Identifies rare, unusual, or abnormal observations that deviate significantly from the expected pattern. Works by learning what 'normal' looks like and flagging anything that doesn't fit. Time is NOT the primary signal. Example: Detecting fraudulent credit card transactions by identifying spending patterns that are significantly different from a customer's typical behavior.",

 "not_applicable":
  "The problem does not require a machine learning prediction, recommendation, grouping, or anomaly detection approach. It may be better addressed through traditional reporting, dashboards, descriptive statistics, rulebased logic, or manual analysis. Example: Generating a monthly sales summary report or building a dashboard to visualize key performance metrics."
 }