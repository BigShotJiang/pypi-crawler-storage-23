from adam.commands.command import Command
from adam.commands.devices.device import Device
from adam.utils_repl.repl_state import ReplState
from adam.utils_job.job import Job
from adam.presentation.tabulize import tabulize
from adam.utils_rdbms.athena import Athena
from adam.utils_context import NULL

class DeviceAuditLog(Command, Device):
    COMMAND = f'{ReplState.L}:'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(DeviceAuditLog, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return DeviceAuditLog.COMMAND

    def run(self, cmd: str, state: ReplState):
        if not self.args(cmd):
            return super().run(cmd, state)

        state.device = ReplState.L

        return state

    def completion(self, state: ReplState):
        return super().completion(state)

    def help(self, state: ReplState):
        return super().help(state, 'move to Audit Log Operations device')

    def ls(self, cmd: str, _: ReplState, ctx = NULL):
        tabulize(Athena.table_names(),
                 header='NAME',
                 separator=',',
                 ctx=ctx.copy(show_out=True))

    def pwd(self, _: ReplState):
        return '\t'.join([f'{ReplState.L}:>', '/'])

    def try_fallback_action(self, chain: Command, state: ReplState, cmd: str, job: Job = None, ctx = NULL):
        return True, chain.retry(f'audit {cmd}', job, state, ctx=ctx) if job else chain.run(f'audit {cmd}', state)

    def show_tables(self, _: ReplState, ctx = NULL):
        tabulize(Athena.table_names(),
                 separator=',',
                 ctx=ctx.copy(show_out=True))

    def show_table_preview(self, _: ReplState, table: str, rows: int, ctx = NULL):
        Athena.run_query(f'select * from {table} limit {rows}', ctx=ctx)