"""Common utilities for OpenViking examples"""
