from zenius_downloader.cli import main

main()
