from __future__ import annotations

import sys

from bridle._harness import run


def main() -> None:
    sys.exit(run())
