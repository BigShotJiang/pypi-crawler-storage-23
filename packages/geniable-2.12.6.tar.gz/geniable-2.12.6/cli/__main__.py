"""Entry point for running CLI as module: python -m cli"""

from cli.main import app

if __name__ == "__main__":
    app()
