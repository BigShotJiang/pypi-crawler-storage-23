"""
Normalize embed-client config to adapter config format for validation.

Converts client config (server.host, server.port, protocol, ssl, auth)
to the format expected by mcp_proxy_adapter.core.validation.config_validator,
and maps validation results back to embed-client section/key names.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

# Section/key mapping: adapter -> embed-client (for user-facing messages)
_ADAPTER_TO_CLIENT_KEY: Dict[str, str] = {
    "server.ssl.cert": "ssl.cert_file",
    "server.ssl.key": "ssl.key_file",
    "server.ssl.ca": "ssl.ca_cert_file",
    "server.ssl.crl": "ssl.crl_file",
}


def client_to_adapter_format(
    config_data: Dict[str, Any],
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Convert embed-client config to adapter ConfigValidator input format.

    Adapter expects: server.host, server.port, server.protocol, server.debug,
    server.log_level, server.ssl.{cert,key,ca}, auth, optional ssl, etc.
    """
    server = config_data.get("server", {})
    protocol = config_data.get("protocol", server.get("protocol", "http"))
    ssl_config = config_data.get("ssl", {})
    auth_config = config_data.get("auth", {})

    # Cert paths: embed-client uses ssl.cert_file / auth.certificate (keep as-is; adapter uses cwd for abspath)
    cert_file = ssl_config.get("cert_file") or (auth_config.get("certificate") or {}).get(
        "cert_file"
    )
    key_file = ssl_config.get("key_file") or (auth_config.get("certificate") or {}).get(
        "key_file"
    )
    ca_cert_file = ssl_config.get("ca_cert_file") or (
        auth_config.get("certificate") or {}
    ).get("ca_cert_file")
    crl_file = ssl_config.get("crl_file")

    server_ssl: Optional[Dict[str, Any]] = None
    if protocol in ("https", "mtls") and (cert_file or key_file or ca_cert_file):
        server_ssl = {
            "cert": cert_file,
            "key": key_file,
            "ca": ca_cert_file,
            "crl": crl_file,
        }

    adapter_server: Dict[str, Any] = {
        "host": server.get("host", "localhost"),
        "port": server.get("port", 8001),
        "protocol": protocol,
        "debug": False,
        "log_level": "INFO",
        "log_dir": server.get("log_dir", "./logs"),
    }
    if server_ssl:
        adapter_server["ssl"] = server_ssl

    # Adapter auth: use_token, tokens, roles (for validation consistency)
    security = config_data.get("security", {})
    adapter_auth = {
        "use_token": auth_config.get("method") == "api_key",
        "use_roles": bool(security.get("roles")),
        "tokens": {},
        "roles": security.get("roles") if isinstance(security.get("roles"), dict) else {},
    }
    api_key = (auth_config.get("api_key") or {})
    if api_key.get("key"):
        adapter_auth["tokens"] = {api_key["key"]: ["read", "write"]}
    if security.get("tokens") and isinstance(security["tokens"], dict):
        adapter_auth["tokens"] = {
            (v if isinstance(v, str) else str(v)): ["read", "write"]
            for v in security["tokens"].values()
        }

    normalized: Dict[str, Any] = {
        "server": adapter_server,
        "auth": adapter_auth,
    }
    if ssl_config:
        normalized["ssl"] = {
            "enabled": ssl_config.get("enabled", protocol in ("https", "mtls")),
            "cert_file": cert_file,
            "key_file": key_file,
            "ca_cert_file": ca_cert_file,
            "crl_file": crl_file,
        }
    # Minimal sections to avoid "unknown section" warnings
    normalized["client"] = {"enabled": False}
    normalized["registration"] = {"enabled": False}
    return normalized


def map_adapter_errors_to_client(
    adapter_errors: List[Any],
) -> List[str]:
    """
    Map adapter ValidationResult list to embed-client error strings.

    Translates section/key (e.g. server.ssl.cert) to client names (ssl.cert_file).
    """
    from mcp_proxy_adapter.core.validation.validation_result import ValidationResult  # type: ignore[import-untyped]

    result: List[str] = []
    for r in adapter_errors:
        if not isinstance(r, ValidationResult):
            result.append(str(r))
            continue
        if getattr(r, "level", "error") != "error":
            continue
        msg = getattr(r, "message", str(r))
        section = getattr(r, "section", None)
        key = getattr(r, "key", None)
        if section and key:
            full_key = f"{section}.{key}" if key else section
            client_key = _ADAPTER_TO_CLIENT_KEY.get(full_key, full_key)
            result.append(f"{client_key}: {msg}")
        else:
            result.append(msg)
    return result
