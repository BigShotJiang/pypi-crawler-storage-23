"""
Helper functions for EmbeddingServiceClient (polling and list_commands).

Mirrors embed/client/embedding_client_helpers for internal testing against
mcp_proxy_adapter async exchange (execute_async, WebSocket push).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Dict, cast

from embed_client.exceptions import EmbeddingServiceAPIError


async def wait_for_job_poll(
    job_status_fn: Any,
    job_id: str,
    timeout: int = 60,
    poll_interval: float = 1.0,
) -> Dict[str, Any]:
    """
    Poll job_status until done or timeout.

    job_status_fn: async callable(job_id) -> status dict.
    Returns result data on completion; raises EmbeddingServiceAPIError or TimeoutError.
    """
    start_time = time.time()
    while timeout == 0 or (time.time() - start_time < timeout):
        status = await job_status_fn(job_id)
        if not status.get("exists"):
            raise EmbeddingServiceAPIError({"message": f"Job {job_id} not found"})
        done = status.get("done", False) or status.get("status") in (
            "completed",
            "failed",
            "error",
        )
        if done:
            job_status = status.get("status", "")
            if job_status in ("completed", "success"):
                inner = status.get("result") or status.get("data") or status
                if isinstance(inner, dict):
                    data = inner.get("data")
                    if data is not None:
                        return cast(Dict[str, Any], data)
                return cast(Dict[str, Any], inner if isinstance(inner, dict) else {})
            if job_status in ("failed", "error"):
                error = status.get("error") or status.get("message", "Unknown error")
                raise EmbeddingServiceAPIError({"message": str(error)})
            raise EmbeddingServiceAPIError(
                {"message": f"Job completed with unexpected status: {job_status}"}
            )
        await asyncio.sleep(poll_interval)
    raise TimeoutError(f"Job {job_id} did not complete within {timeout} seconds")


async def list_commands_via_client(jsonrpc_call: Any) -> Dict[str, Any]:
    """
    Call list/help/commands via jsonrpc_call(cmd_name, {}); return data or {}.
    """
    for cmd_name in ["list", "help", "commands"]:
        try:
            response = await jsonrpc_call(cmd_name, {})
            if "error" not in response:
                result = response.get("result", {})
                return cast(Dict[str, Any], result.get("data", result))
        except Exception:
            continue
    return {}


__all__ = ["wait_for_job_poll", "list_commands_via_client"]
