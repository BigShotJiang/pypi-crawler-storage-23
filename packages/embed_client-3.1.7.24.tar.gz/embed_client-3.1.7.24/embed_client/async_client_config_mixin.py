"""
Config validation and generation mixin for embedding clients.

Exposes validate_config and generate_config using adapter-based
ConfigValidator and ClientConfigGenerator. Validator is used in client
methods when loading config (e.g. from_config).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from embed_client.config_generator import ClientConfigGenerator
from embed_client.config_validator import ConfigValidator
from embed_client.exceptions import EmbeddingServiceConfigError


class AsyncClientConfigMixin:
    """
    Mixin that provides validate_config and generate_config methods.

    Uses ConfigValidator (adapter-based) and ClientConfigGenerator (adapter-based).
    """

    @staticmethod
    def validate_config(
        config: Union[str, Path, Dict[str, Any]],
    ) -> Tuple[bool, List[str]]:
        """
        Validate configuration file or dictionary.

        Uses adapter-based ConfigValidator. Resolves relative paths when
        config is a file path.

        Args:
            config: Path to JSON config file or config dictionary.

        Returns:
            Tuple of (is_valid, list_of_error_messages).
        """
        validator = ConfigValidator()
        if isinstance(config, (str, Path)):
            path = Path(config)
            if not path.exists():
                return False, [f"Config file not found: {path}"]
            ok, _msg, errs = validator.validate_config_file(path)
            return ok, errs
        if isinstance(config, dict):
            return validator.validate_config_dict(config)
        return False, ["config must be path (str|Path) or dict"]

    @staticmethod
    def generate_config(
        mode: str,
        host: str = "localhost",
        port: int = 8001,
        output_path: Optional[Path] = None,
        cert_file: Optional[str] = None,
        key_file: Optional[str] = None,
        ca_cert_file: Optional[str] = None,
        crl_file: Optional[str] = None,
        token: Optional[str] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Generate client configuration for the given security mode.

        Uses adapter-based ClientConfigGenerator. Modes: http, http_token,
        http_token_roles, https, https_token, https_token_roles, mtls, mtls_roles.

        Args:
            mode: Security mode name.
            host: Server host.
            port: Server port.
            output_path: Optional path to save JSON file.
            cert_file: Client cert (for https/mtls).
            key_file: Client key (for https/mtls).
            ca_cert_file: CA cert (for https/mtls).
            crl_file: Optional CRL file.
            token: Token for token modes.
            **kwargs: Passed to generator (e.g. tokens, roles).

        Returns:
            Configuration dictionary.
        """
        gen = ClientConfigGenerator()
        common_http: Dict[str, Any] = {
            "host": host,
            "port": port,
            "output_path": output_path,
            "crl_file": crl_file,
            "token": token,
            **kwargs,
        }
        common_ssl: Dict[str, Any] = {
            **common_http,
            "cert_file": cert_file,
            "key_file": key_file,
            "ca_cert_file": ca_cert_file,
        }
        if mode == "http":
            return gen.generate_http_config(**common_http)
        if mode == "http_token":
            return gen.generate_http_token_config(**common_http)
        if mode == "http_token_roles":
            return gen.generate_http_token_roles_config(**common_http)
        if mode == "https":
            return gen.generate_https_config(**common_ssl)
        if mode == "https_token":
            return gen.generate_https_token_config(**common_ssl)
        if mode == "https_token_roles":
            return gen.generate_https_token_roles_config(**common_ssl)
        if mode == "mtls":
            return gen.generate_mtls_config(**common_ssl)
        if mode == "mtls_roles":
            return gen.generate_mtls_roles_config(**common_ssl)
        raise ValueError(
            f"Unknown mode: {mode}. Use one of: http, http_token, http_token_roles, "
            "https, https_token, https_token_roles, mtls, mtls_roles"
        )


def validate_config_and_raise(
    config: Union[str, Path, Dict[str, Any]],
) -> None:
    """
    Validate config and raise EmbeddingServiceConfigError if invalid.

    For use inside client methods (e.g. from_config).
    """
    ok, errs = AsyncClientConfigMixin.validate_config(config)
    if not ok:
        raise EmbeddingServiceConfigError(
            "Configuration validation failed: "
            + "; ".join(errs[:5])
            + ("..." if len(errs) > 5 else "")
        )


__all__ = ["AsyncClientConfigMixin", "validate_config_and_raise"]
