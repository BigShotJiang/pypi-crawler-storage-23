"""
Configuration Validator for embed-client.

Uses mcp_proxy_adapter.core.validation.config_validator.ConfigValidator as base.
Normalizes client config to adapter format, runs adapter validation, maps errors
back to embed-client section/key names. Keeps legacy ClientConfig checks for compatibility.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from embed_client.config import ClientConfig
from embed_client.config_presets import validate_client_config
from embed_client.adapter_config_normalizer import (
    client_to_adapter_format,
    map_adapter_errors_to_client,
)

try:
    from mcp_proxy_adapter.core.validation.config_validator import (  # type: ignore[import-untyped]
        ConfigValidator as AdapterConfigValidator,
    )
    _ADAPTER_AVAILABLE = True
except ImportError:
    _ADAPTER_AVAILABLE = False
    AdapterConfigValidator = None  # type: ignore[misc, assignment]


class ConfigValidator:
    """
    Validator for embed-client configuration files.

    Uses adapter ConfigValidator as base: normalizes client config to adapter
    format, runs adapter validation, maps errors to embed-client names.
    """

    def __init__(self) -> None:
        """Initialize configuration validator."""
        pass

    def _validate_via_adapter(
        self, config_data: Dict[str, Any], config_path: Optional[Path] = None
    ) -> List[str]:
        """Run adapter ConfigValidator on normalized config; return list of error strings."""
        if not _ADAPTER_AVAILABLE or AdapterConfigValidator is None:
            return []
        normalized = client_to_adapter_format(
            config_data, config_path=str(config_path) if config_path else None
        )
        validator = AdapterConfigValidator(config_path=str(config_path) if config_path else None)
        results = validator.validate_config(normalized)
        errors = map_adapter_errors_to_client([r for r in results if getattr(r, "level", "") == "error"])
        return errors

    def validate_json_structure(
        self,
        config_data: Dict[str, Any],
        config_path: Optional[Path] = None,
    ) -> Tuple[bool, List[str]]:
        """
        Validate JSON structure and required fields.

        Uses adapter ConfigValidator as base (normalize -> validate -> map errors).
        Then runs legacy ClientConfig validation for embed-client specific checks.
        config_path: optional path to config file (for resolving relative cert paths).
        """
        errors: List[str] = []

        # Base validation via adapter
        adapter_errors = self._validate_via_adapter(config_data, config_path)
        errors.extend(adapter_errors)

        # Legacy checks for sections adapter may not require
        if "server" not in config_data:
            errors.append("Missing required section: server")
        else:
            server = config_data["server"]
            if "host" not in server:
                errors.append("server.host is required")
            if "port" not in server:
                errors.append("server.port is required")
            elif not isinstance(server["port"], int) or server["port"] <= 0:
                errors.append("server.port must be a positive integer")

        protocol = config_data.get("protocol", config_data.get("server", {}).get("protocol", "http"))
        if protocol not in ("http", "https", "mtls"):
            errors.append(f"Invalid protocol: {protocol}. Must be 'http', 'https', or 'mtls'")

        if "auth" in config_data:
            auth = config_data["auth"]
            auth_method = auth.get("method", "none")
            if auth_method == "api_key":
                if "api_key" not in auth or "key" not in auth["api_key"]:
                    errors.append("auth.api_key.key is required for api_key authentication")
            elif auth_method == "jwt":
                jwt = auth.get("jwt", {})
                if not all(key in jwt for key in ["username", "password", "secret"]):
                    errors.append(
                        "auth.jwt.username, auth.jwt.password, and auth.jwt.secret "
                        "are required for JWT authentication"
                    )
            elif auth_method == "certificate":
                cert = auth.get("certificate", {})
                if not all(key in cert for key in ["cert_file", "key_file"]):
                    errors.append(
                        "auth.certificate.cert_file and auth.certificate.key_file "
                        "are required for certificate authentication"
                    )
            elif auth_method == "basic":
                basic = auth.get("basic", {})
                if not all(key in basic for key in ["username", "password"]):
                    errors.append(
                        "auth.basic.username and auth.basic.password "
                        "are required for basic authentication"
                    )

        return len(errors) == 0, errors

    def validate_config_file(
        self, config_path: Path
    ) -> Tuple[bool, str, List[str]]:
        """
        Validate a single configuration file.

        Args:
            config_path: Path to configuration file

        Returns:
            Tuple of (is_valid, status_message, list_of_errors)
        """
        try:
            if not config_path.exists():
                return False, "File not found", []

            with open(config_path, "r", encoding="utf-8") as f:
                config_data = json.load(f)

            # Validate JSON structure (pass path for relative cert resolution)
            is_valid, errors = self.validate_json_structure(config_data, config_path)

            if not is_valid:
                return False, f"{len(errors)} error(s) in structure", errors

            # Validate using ClientConfig validator
            try:
                client_config = ClientConfig(str(config_path))
                config_errors = validate_client_config(client_config)

                if config_errors:
                    errors.extend(config_errors)
                    return False, f"{len(errors)} error(s) found", errors

                return True, "OK", []
            except Exception as e:
                errors.append(f"Error loading config: {str(e)}")
                return False, f"Config loading failed: {str(e)}", errors

        except json.JSONDecodeError as e:
            return False, f"JSON decode error: {str(e)}", []
        except Exception as e:
            return False, f"Unexpected error: {str(e)}", []

    def validate_config_dict(self, config_data: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """
        Validate configuration dictionary.

        Args:
            config_data: Configuration dictionary

        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        # Validate JSON structure (no path for dict)
        is_valid, errors = self.validate_json_structure(config_data, None)

        if not is_valid:
            return False, errors

        # Create temporary ClientConfig to validate
        try:
            # Create a temporary config file
            import tempfile

            with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
                json.dump(config_data, f, indent=2)
                temp_path = f.name

            try:
                client_config = ClientConfig(temp_path)
                config_errors = validate_client_config(client_config)
                if config_errors:
                    errors.extend(config_errors)
                    return False, errors
                return True, []
            finally:
                os.unlink(temp_path)
        except Exception as e:
            errors.append(f"Error validating config: {str(e)}")
            return False, errors

    def validate_config_directory(self, config_dir: Path) -> Dict[str, Tuple[bool, str, List[str]]]:
        """
        Validate all configuration files in a directory.

        Args:
            config_dir: Directory containing configuration files

        Returns:
            Dictionary mapping file names to (is_valid, status_message, list_of_errors)
        """
        results: Dict[str, Tuple[bool, str, List[str]]] = {}

        if not config_dir.exists():
            return results

        config_files = list(config_dir.glob("*.json"))

        for config_file in sorted(config_files):
            results[config_file.name] = self.validate_config_file(config_file)

        return results


__all__ = ["ConfigValidator"]
