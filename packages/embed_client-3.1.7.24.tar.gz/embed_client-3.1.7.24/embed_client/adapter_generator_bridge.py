"""
Bridge to mcp_proxy_adapter config generator.

Uses adapter SimpleConfigGenerator as base: generates adapter config then
converts to embed-client client config format (server.host/port, protocol,
ssl.cert_file/key_file/ca_cert_file, auth, client.timeout).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional

try:
    from mcp_proxy_adapter.core.config.simple_config_generator import (  # type: ignore[import-untyped]
        SimpleConfigGenerator,
    )
    _ADAPTER_AVAILABLE = True
except ImportError:
    _ADAPTER_AVAILABLE = False
    SimpleConfigGenerator = None  # type: ignore[misc, assignment]


def adapter_output_to_client_config(adapter_dict: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert adapter generator output to embed-client config format.

    Adapter has: server.{host, port, protocol, ssl.{cert, key, ca, crl}},
    auth.{use_token, tokens, roles}. We output: server.{host, port},
    protocol, ssl.{enabled, cert_file, key_file, ca_cert_file, crl_file},
    auth.{method, api_key, certificate}, client.timeout, security.
    """
    server = adapter_dict.get("server", {})
    ssl = server.get("ssl") or {}
    auth = adapter_dict.get("auth", {})

    protocol = server.get("protocol", "http")
    ssl_enabled = protocol in ("https", "mtls")
    verify_mode = "CERT_REQUIRED" if protocol == "mtls" else "CERT_NONE"

    # Build embed-client auth: certificate for mTLS, api_key when use_token
    if protocol == "mtls":
        auth_method = "certificate"
    elif auth.get("use_token"):
        auth_method = "api_key"
    else:
        auth_method = "none"
    tokens = auth.get("tokens") or {}
    first_token: Optional[str] = None
    if isinstance(tokens, dict) and tokens:
        first_token = next(iter(tokens.keys()), None)

    config: Dict[str, Any] = {
        "server": {"host": server.get("host", "localhost"), "port": server.get("port", 8001)},
        "client": {"timeout": 30.0},
        "protocol": protocol,
        "auth": {
            "method": auth_method,
            "api_key": {"key": first_token, "header": "X-API-Key"},
            "certificate": {
                "enabled": protocol == "mtls",
                "cert_file": ssl.get("cert") if protocol == "mtls" else None,
                "key_file": ssl.get("key") if protocol == "mtls" else None,
                "ca_cert_file": ssl.get("ca") if protocol == "mtls" else None,
            },
        },
        "ssl": {
            "enabled": ssl_enabled,
            "verify": protocol != "http",
            "verify_mode": verify_mode,
            "check_hostname": False,
            "check_expiry": False,
            "cert_file": ssl.get("cert"),
            "key_file": ssl.get("key"),
            "ca_cert_file": ssl.get("ca"),
            "crl_file": ssl.get("crl"),
            "client_cert_required": protocol == "mtls",
        },
        "security": {"enabled": bool(auth.get("use_token")), "tokens": {}, "roles": {}},
    }
    if auth.get("use_token") and isinstance(tokens, dict) and tokens:
        # embed-client security.tokens: role_name -> token_value
        config["security"]["tokens"] = {"user": first_token} if first_token else dict(tokens)
    if auth.get("use_roles") and isinstance(auth.get("roles"), dict):
        config["security"]["roles"] = auth["roles"]
    return config


def generate_client_config_via_adapter(
    protocol: str,
    host: str = "localhost",
    port: int = 8001,
    cert_file: Optional[str] = None,
    key_file: Optional[str] = None,
    ca_cert_file: Optional[str] = None,
    crl_file: Optional[str] = None,
    token: Optional[str] = None,
    use_token: bool = False,
    use_roles: bool = False,
    tokens: Optional[Dict[str, Any]] = None,
    roles: Optional[Dict[str, Any]] = None,
    output_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Generate embed-client config using adapter SimpleConfigGenerator as base.

    Calls adapter generator, loads output, converts to embed-client format.
    Returns config dict; if output_path given, also saves JSON.
    """
    if not _ADAPTER_AVAILABLE or SimpleConfigGenerator is None:
        raise RuntimeError("mcp_proxy_adapter is not available; install it to use adapter-based generator")

    if protocol == "mtls" and not ca_cert_file:
        raise ValueError("CA certificate is required for mTLS. Provide ca_cert_file.")

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False
    ) as tmp:
        temp_path = tmp.name
    try:
        gen = SimpleConfigGenerator()
        gen.generate(
            protocol=protocol,
            with_proxy=False,
            out_path=temp_path,
            server_host=host,
            server_port=port,
            server_cert_file=cert_file,
            server_key_file=key_file,
            server_ca_cert_file=ca_cert_file,
            server_crl_file=crl_file,
        )
        with open(temp_path, "r", encoding="utf-8") as f:
            adapter_dict = json.load(f)

        # Optionally set auth from adapter CLI-style (tokens/roles)
        if use_token and (token or tokens):
            adapter_dict.setdefault("auth", {})["use_token"] = True
            if tokens:
                adapter_dict["auth"]["tokens"] = tokens
            elif token:
                adapter_dict["auth"]["tokens"] = {token: ["read", "write"]}
        if use_roles and roles:
            adapter_dict.setdefault("auth", {})["use_roles"] = True
            adapter_dict["auth"]["roles"] = roles

        client_config = adapter_output_to_client_config(adapter_dict)
        if output_path:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(client_config, f, indent=2, ensure_ascii=False)
        return client_config
    finally:
        Path(temp_path).unlink(missing_ok=True)
