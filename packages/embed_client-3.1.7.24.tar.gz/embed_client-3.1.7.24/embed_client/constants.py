"""
Shared constants for embed-client package.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

# Environment variable names for embedding service connection
EMBEDDING_SERVICE_BASE_URL_ENV: str = "EMBEDDING_SERVICE_BASE_URL"
EMBEDDING_SERVICE_PORT_ENV: str = "EMBEDDING_SERVICE_PORT"

# Default connection settings
DEFAULT_BASE_URL: str = "http://localhost"
DEFAULT_PORT: int = 8001

# Default poll interval (seconds) when waiting for queued job completion
DEFAULT_POLL_INTERVAL: float = 0.3

# Default error policy for embed command (matches server API default)
EMBED_DEFAULT_ERROR_POLICY: str = "fail_fast"

__all__ = [
    "EMBEDDING_SERVICE_BASE_URL_ENV",
    "EMBEDDING_SERVICE_PORT_ENV",
    "DEFAULT_BASE_URL",
    "DEFAULT_PORT",
    "DEFAULT_POLL_INTERVAL",
    "EMBED_DEFAULT_ERROR_POLICY",
]
