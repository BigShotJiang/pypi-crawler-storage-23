"""
Embedding service client (adapter-based).

Thin wrapper over mcp_proxy_adapter JsonRpcClient: health, embed (with
execute_async when wait=True), job_status, models, list_commands,
wait_for_job, WebSocket channel. Uses adapter async exchange: execute_async,
wait_for_job_via_websocket, open_bidirectional_ws_channel.
Supports from_config, validate_config, generate_config.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union, cast

from embed_client.adapter_config_factory import AdapterConfigFactory
from embed_client.adapter_transport import AdapterTransport
from embed_client.constants import EMBED_DEFAULT_ERROR_POLICY
from embed_client.config_generator import ClientConfigGenerator
from embed_client.config_validator import ConfigValidator
from embed_client.exceptions import (
    EmbeddingServiceAPIError,
    EmbeddingServiceConfigError,
    EmbeddingServiceError,
    EmbeddingServiceTimeoutError,
)
from embed_client.testing_client_helpers import (
    list_commands_via_client,
    wait_for_job_poll,
)

logger = logging.getLogger(__name__)


def _adapter_params(
    protocol: str = "http",
    host: str = "127.0.0.1",
    port: int = 8080,
    cert: Optional[str] = None,
    key: Optional[str] = None,
    ca: Optional[str] = None,
    check_hostname: bool = False,
    token: Optional[str] = None,
    token_header: Optional[str] = None,
    timeout: float = 120.0,
) -> Dict[str, Any]:
    """Build adapter params dict from keyword arguments."""
    return {
        "protocol": protocol,
        "host": host,
        "port": port,
        "cert": cert,
        "key": key,
        "ca": ca,
        "check_hostname": check_hostname,
        "token": token,
        "token_header": token_header or ("X-API-Key" if token else None),
        "timeout": timeout,
    }


class EmbeddingServiceClient:
    """
    Client for embedding service API (adapter-based).

    Uses JsonRpcClient via AdapterTransport; supports embed with wait=True
    via execute_async (WebSocket push), job_status, models, list_commands,
    wait_for_job (poll or WS). from_config, validate_config, generate_config.
    """

    def __init__(
        self,
        protocol: str = "http",
        host: str = "127.0.0.1",
        port: int = 8080,
        cert: Optional[str] = None,
        key: Optional[str] = None,
        ca: Optional[str] = None,
        check_hostname: bool = False,
        token: Optional[str] = None,
        token_header: Optional[str] = None,
        timeout: float = 120.0,
    ) -> None:
        """
        Initialize embedding service client.

        Args:
            protocol: Transport protocol (http, https, mtls).
            host: Server hostname.
            port: Server port.
            cert: Path to client certificate file (mTLS).
            key: Path to client private key file (mTLS).
            ca: Path to CA certificate file (mTLS).
            check_hostname: Whether to verify hostname in SSL.
            token: Authentication token.
            token_header: Header name for token (default X-API-Key if token set).
            timeout: Request/timeout in seconds.
        """
        self._transport = AdapterTransport(
            _adapter_params(
                protocol=protocol,
                host=host,
                port=port,
                cert=cert,
                key=key,
                ca=ca,
                check_hostname=check_hostname,
                token=token,
                token_header=token_header,
                timeout=timeout,
            )
        )
        self.protocol = protocol
        self.host = host
        self.port = port

    @classmethod
    def validate_config(
        cls, config: Union[str, Path, Dict[str, Any]]
    ) -> Tuple[bool, List[str]]:
        """
        Validate configuration file or dictionary (adapter-based validator).

        Returns:
            (is_valid, list of error messages).
        """
        validator = ConfigValidator()
        if isinstance(config, (str, Path)):
            path = Path(config)
            if not path.exists():
                return False, [f"Config file not found: {path}"]
            ok, _msg, errs = validator.validate_config_file(path)
            return ok, errs
        if isinstance(config, dict):
            return validator.validate_config_dict(config)
        return False, ["config must be path (str|Path) or dict"]

    @classmethod
    def generate_config(
        cls,
        mode: str,
        host: str = "localhost",
        port: int = 8001,
        output_path: Optional[Path] = None,
        cert_file: Optional[str] = None,
        key_file: Optional[str] = None,
        ca_cert_file: Optional[str] = None,
        crl_file: Optional[str] = None,
        token: Optional[str] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Generate client configuration (adapter-based generator).

        Modes: http, http_token, http_token_roles, https, https_token,
        https_token_roles, mtls, mtls_roles.
        """
        gen = ClientConfigGenerator()
        common_http: Dict[str, Any] = {
            "host": host,
            "port": port,
            "output_path": output_path,
            "crl_file": crl_file,
            "token": token,
            **kwargs,
        }
        common_ssl: Dict[str, Any] = {
            **common_http,
            "cert_file": cert_file,
            "key_file": key_file,
            "ca_cert_file": ca_cert_file,
        }
        if mode == "http":
            return gen.generate_http_config(**common_http)
        if mode == "http_token":
            return gen.generate_http_token_config(**common_http)
        if mode == "http_token_roles":
            return gen.generate_http_token_roles_config(**common_http)
        if mode == "https":
            return gen.generate_https_config(**common_ssl)
        if mode == "https_token":
            return gen.generate_https_token_config(**common_ssl)
        if mode == "https_token_roles":
            return gen.generate_https_token_roles_config(**common_ssl)
        if mode == "mtls":
            return gen.generate_mtls_config(**common_ssl)
        if mode == "mtls_roles":
            return gen.generate_mtls_roles_config(**common_ssl)
        raise ValueError(
            f"Unknown mode: {mode}. Use one of: http, http_token, http_token_roles, "
            "https, https_token, https_token_roles, mtls, mtls_roles"
        )

    @classmethod
    def from_config(
        cls,
        config: Union[str, Path, Dict[str, Any]],
        validate: bool = True,
    ) -> "EmbeddingServiceClient":
        """
        Create client from config file path or config dictionary.

        Uses AdapterConfigFactory; supports auth.api_key.key / auth.api_key.header
        from generator output. When validate=True (default), runs adapter-based
        validator and raises EmbeddingServiceConfigError if invalid.
        """
        if isinstance(config, (str, Path)):
            path = Path(config)
            with open(path, "r", encoding="utf-8") as f:
                config_dict = cast(Dict[str, Any], json.load(f))
        elif isinstance(config, dict):
            config_dict = config
        else:
            raise TypeError("config must be path (str|Path) or dict")

        if validate:
            valid, errs = cls.validate_config(
                path if isinstance(config, (str, Path)) else config_dict
            )
            if not valid:
                raise EmbeddingServiceConfigError(
                    "Configuration validation failed: "
                    + "; ".join(errs[:5])
                    + ("..." if len(errs) > 5 else "")
                )

        params = AdapterConfigFactory.from_config_dict(config_dict)
        params.pop("_original_config", None)
        # Generator uses auth.api_key.key / .header; factory uses api_keys
        api_key = (config_dict.get("auth") or {}).get("api_key") or {}
        if api_key.get("key"):
            params["token"] = api_key["key"]
            params["token_header"] = api_key.get("header", "X-API-Key")
        kwargs = {
            k: params[k]
            for k in (
                "protocol",
                "host",
                "port",
                "cert",
                "key",
                "ca",
                "check_hostname",
                "token",
                "token_header",
                "timeout",
            )
            if k in params
        }
        return cls(**kwargs)

    async def __aenter__(self) -> "EmbeddingServiceClient":
        """Ensure transport client is created."""
        await self._transport._ensure_client()
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Close transport."""
        await self._transport.close()

    async def health(self) -> Dict[str, Any]:
        """Check server health."""
        return await self._transport.health()

    async def embed(
        self,
        texts: List[str],
        model: Optional[str] = None,
        dimension: Optional[int] = None,
        job_id: Optional[str] = None,
        error_policy: Optional[str] = None,
        device: Optional[str] = None,
        wait: bool = False,
        wait_timeout: int = 60,
        poll_interval: float = 1.0,
        use_push: bool = True,
    ) -> Dict[str, Any]:
        """
        Generate embeddings for texts (queue or execute_async when wait=True).

        When wait=True uses adapter execute_async("embed_execute", ...) and
        WebSocket push for result (no HTTP polling).

        Args:
            texts: List of texts to embed.
            model: Optional model name.
            dimension: Optional vector dimension.
            job_id: Optional custom job ID.
            error_policy: fail_fast or continue; default from server.
            device: auto, cpu, cuda, etc.; default from server.
            wait: If True, wait for completion via WebSocket.
            wait_timeout: Max wait in seconds when wait=True.
            poll_interval: Unused (kept for API compatibility).
            use_push: Unused; WS used when wait=True.

        Returns:
            If wait=False: {"job_id", "status", "message"}.
            If wait=True: {"results": [...], "model", "dimension"} (embed result shape).

        Raises:
            EmbeddingServiceError: On request or job failure.
            EmbeddingServiceTimeoutError: When wait_timeout exceeded.
        """
        del poll_interval, use_push
        params: Dict[str, Any] = {"texts": texts}
        if model is not None:
            params["model"] = model
        if dimension is not None:
            params["dimension"] = dimension
        if job_id is not None:
            params["job_id"] = job_id
        if error_policy is not None:
            params["error_policy"] = error_policy
        else:
            params["error_policy"] = EMBED_DEFAULT_ERROR_POLICY
        if device is not None:
            params["device"] = device

        if wait:
            return await self._embed_via_execute_async(params, wait_timeout)

        response = await self._transport.jsonrpc_call("embed", params)
        if "error" in response:
            raise EmbeddingServiceError(
                f"Embedding failed: {response['error']}"
            ) from None
        result = response.get("result", {})
        if not result.get("success"):
            error = result.get("error", {})
            raise EmbeddingServiceAPIError(
                {"message": error.get("message", "Unknown error")}
            )
        data = result.get("data", {})
        out_job_id = data.get("job_id") or result.get("job_id")
        if not out_job_id and (
            isinstance(data.get("results"), list)
            or isinstance(data.get("embeddings"), list)
        ):
            return data
        if not out_job_id:
            raise EmbeddingServiceError(
                "No job_id or results returned from server"
            ) from None
        return {
            "job_id": out_job_id,
            "status": data.get("status") or result.get("status", "pending"),
            "message": data.get("message")
            or result.get("message", "Job queued successfully"),
        }

    async def _embed_via_execute_async(
        self, params: Dict[str, Any], timeout: int = 60
    ) -> Dict[str, Any]:
        """
        Run embed in-process via execute_async (WebSocket push).

        Uses adapter execute_async; server runs embed_execute and pushes
        result via WebSocket. Returns embed result shape; raises on failure/timeout.
        """
        timeout_sec = float(timeout) if timeout > 0 else 60.0
        loop = asyncio.get_running_loop()
        fut: asyncio.Future[Dict[str, Any]] = loop.create_future()

        def on_result(event: Dict[str, Any]) -> None:
            if not fut.done():
                fut.set_result(event)

        await self._transport.execute_async(
            "embed_execute",
            params,
            on_result=on_result,
            timeout=timeout_sec,
        )
        try:
            event = await asyncio.wait_for(fut, timeout=timeout_sec + 5.0)
        except asyncio.TimeoutError as e:
            raise EmbeddingServiceTimeoutError(
                f"Embed (execute_async) did not complete within {timeout_sec}s"
            ) from e

        ev = event.get("event") or event.get("type")
        if ev == "job_failed":
            err = event.get("error", "Unknown error")
            raise EmbeddingServiceAPIError({"message": str(err)})
        if ev not in ("job_completed", "job_completed_success"):
            raise EmbeddingServiceAPIError(
                {"message": f"Unexpected WebSocket event: {ev}"}
            )

        raw = event.get("result") or {}
        if isinstance(raw.get("data"), dict):
            return raw["data"]
        result_val = raw.get("result")
        inner = result_val if isinstance(result_val, dict) else {}
        if isinstance(inner.get("data"), dict):
            return inner["data"]
        return raw

    async def wait_for_job(
        self,
        job_id: str,
        timeout: int = 60,
        poll_interval: float = 1.0,
    ) -> Dict[str, Any]:
        """
        Wait for job completion by polling job_status.

        Returns embed result shape: results, model, dimension (optional device).
        """
        return await wait_for_job_poll(
            self.job_status,
            job_id,
            timeout=timeout,
            poll_interval=poll_interval,
        )

    async def wait_for_job_via_websocket(
        self, job_id: str, timeout: int = 60
    ) -> Dict[str, Any]:
        """
        Wait for job completion via adapter WebSocket /ws (push).
        """
        timeout_sec = float(timeout) if timeout > 0 else 60.0
        try:
            payload = await self._transport.wait_for_job_via_websocket(
                job_id, timeout=timeout_sec
            )
        except asyncio.TimeoutError as e:
            raise EmbeddingServiceTimeoutError(
                f"Job {job_id} did not complete within {timeout_sec} seconds"
            ) from e
        except RuntimeError as e:
            raise EmbeddingServiceAPIError({"message": str(e)}) from e
        ev = payload.get("event") or payload.get("type")
        if ev == "job_failed":
            err = payload.get("error", "Unknown error")
            raise EmbeddingServiceAPIError({"message": str(err)})
        if ev in ("job_completed", "job_completed_success"):
            raw = payload.get("result") or {}
            if isinstance(raw.get("data"), dict):
                return raw["data"]
            result_val = raw.get("result")
            inner = result_val if isinstance(result_val, dict) else {}
            if isinstance(inner.get("data"), dict):
                return inner["data"]
            return raw
        raise EmbeddingServiceAPIError({"message": f"Unexpected WebSocket event: {ev}"})

    def open_bidirectional_ws_channel(
        self,
        receive_timeout: float = 60.0,
        heartbeat: float = 30.0,
    ) -> Any:
        """
        Open adapter bidirectional WebSocket channel to /ws.

        Use after entering client (async with client). Returns context manager:
        send_json() to send, receive_iter() to consume events.
        """
        return self._transport.open_bidirectional_ws_channel(
            receive_timeout=receive_timeout,
            heartbeat=heartbeat,
        )

    async def job_status(self, job_id: str) -> Dict[str, Any]:
        """
        Get job status (queue_get_job_status or embed_job_status).
        """
        try:
            response = await self._transport.jsonrpc_call(
                "queue_get_job_status", {"job_id": job_id}
            )
            if "error" not in response:
                result = response.get("result", {})
                if result.get("success"):
                    return result.get("data", {})
        except Exception as e:
            logger.debug(
                "queue_get_job_status not available (%s), using embed_job_status",
                e,
            )
        response = await self._transport.jsonrpc_call(
            "embed_job_status", {"job_id": job_id}
        )
        if "error" in response:
            raise EmbeddingServiceAPIError(
                {"message": str(response["error"])}
            ) from None
        result = response.get("result", {})
        if not result.get("success"):
            error = result.get("error", {})
            raise EmbeddingServiceAPIError(
                {"message": error.get("message", "Unknown error")}
            )
        return result.get("data", {})

    async def models(self) -> Dict[str, Any]:
        """List available models (shape matches server models result.data)."""
        response = await self._transport.jsonrpc_call("models", {})
        if "error" in response:
            raise EmbeddingServiceAPIError(
                {"message": str(response["error"])}
            ) from None
        result = response.get("result", {})
        if not result.get("success"):
            error = result.get("error", {})
            raise EmbeddingServiceAPIError(
                {"message": error.get("message", "Unknown error")}
            )
        return result.get("data", {})

    async def list_commands(self) -> Dict[str, Any]:
        """List available commands (list/help/commands via JSON-RPC)."""
        return await list_commands_via_client(self._transport.jsonrpc_call)

    def __repr__(self) -> str:
        return f"EmbeddingServiceClient({self.protocol}://{self.host}:{self.port})"


__all__ = ["EmbeddingServiceClient"]
