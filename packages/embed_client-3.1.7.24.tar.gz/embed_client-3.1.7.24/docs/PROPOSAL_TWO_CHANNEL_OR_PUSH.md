# Proposal: Two-channel or push-based completion to eliminate poll wait

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com  
**Date:** 2026-02  
**Audience:** Server (embed) and client (embed-client) developers

---

## Summary

Introduce a **second channel** (or push mechanism) so that when a job completes, the server **notifies the client** instead of the client polling `job_status` in a loop. This removes the inherent wait of the poll interval and reduces unnecessary round-trips.

---

## Motivation

- **Current flow (single channel):** Client submits → gets `job_id` → repeatedly calls `job_status(job_id)` every `poll_interval` (e.g. 0.3 s) until status is `completed`.  
- **Problem:** Even if the server finishes the job in 0.1 s, the client may only notice at the next poll (up to `poll_interval` later). So latency includes **poll delay** (0–0.3 s per job). With many jobs, total time is dominated by queue wait **and** by the fact that the client is “asleep” between polls instead of being notified as soon as the job is done.
- **Goal:** As soon as the job completes on the server, the client is informed (push or second channel). No periodic polling → no poll wait, fewer requests, lower latency.

---

## Two-channel / push options

### Option A: WebSocket (or bidirectional link)

- **Channel 1:** Existing HTTP/JSON-RPC: submit job, get `job_id`.
- **Channel 2:** WebSocket (or long-lived connection): client subscribes to “my jobs” or a session; server pushes a message when a job completes, e.g. `{ "event": "job_completed", "job_id": "...", "result": {...} }`.
- **Client:** After submit, wait on the WebSocket for the completion message for that `job_id` (with timeout). No polling.

### Option B: Server-Sent Events (SSE)

- **Channel 1:** HTTP submit, get `job_id`.
- **Channel 2:** SSE stream: client opens `GET /events` (or per-session); server sends `job_completed` events. Client blocks on the stream until the event for its `job_id` (with timeout).
- **Client:** Same as A: submit then wait on SSE, no polling.

### Option C: Callback URL

- **Channel 1:** HTTP submit with optional `callback_url` (or header). Server returns `job_id` immediately.
- **Channel 2:** When the job completes, server does an HTTP POST to `callback_url` with the result (or job_id + result). Client runs a small HTTP server or uses a webhook endpoint.
- **Client:** After submit, either blocks waiting for the callback (e.g. future + timeout) or uses an async callback. No polling from client to server for status.

### Option D: Long-polling

- **Channel 1:** HTTP submit, get `job_id`.
- **Channel 2:** Client calls “wait for completion” endpoint (long-poll): e.g. `GET /job/{job_id}/wait?timeout=60`. Server holds the request until the job completes (or timeout), then returns the result in the response.
- **Client:** One request per job that blocks until done. No short-interval polling; the “wait” is on the server side.

---

## Benefits

- **Eliminate poll wait:** Client gets the result as soon as the server finishes, not at the next poll tick.
- **Fewer round-trips:** No repeated `job_status` calls; one submit + one notification (or one long-poll) per job.
- **Better latency:** Especially when server time is short (e.g. &lt;1 s) and poll_interval is 0.3 s; push removes the 0–0.3 s delay.
- **Same API surface possible:** Client can keep `embed()` / `submit_job` + “wait for result”; internally it uses the second channel instead of polling.

---

## Client-side impact (embed-client)

- If server supports one of the options (e.g. WebSocket or long-poll wait endpoint), the client can:
  - Prefer “wait via push” or “wait via long-poll” when available.
  - Fall back to current polling when the server does not advertise the feature.
- Configuration: e.g. `use_push_completion: true` and endpoint/URL for the second channel.

---

## Relation to other proposals

- **Request coalescing** (PROPOSAL_SERVER_REQUEST_COALESCING.md) reduces queue wait by batching many small requests into one. It does not remove poll delay.
- **Two-channel / push** removes poll delay and reduces status-check traffic. Both can be combined: coalescing on the server + push completion so the client gets the result as soon as the (possibly coalesced) job is done.

---

## Summary

Yes: a **two-channel** (or push) design—submit on one channel, get completion on another—removes the waiting time due to polling and improves latency and efficiency. The document above outlines concrete options (WebSocket, SSE, callback URL, long-poll) for server and client.
