# Server modes (sync vs queue) and client transparency

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

## Server behaviour

The embedding server (embed project) can operate in two modes:

1. **Sync mode** (queue disabled): The server processes the request immediately and returns the full result in the same response: `{ "data": { "results": [...], "model": "...", "dimension": N, "device": "..." } }`. No `job_id`.

2. **Queue mode** (queue enabled): The server enqueues the job and returns immediately with `{ "data": { "job_id": "...", "status": "pending", "message": "..." } }`. The client must poll `embed_job_status` (or `queue_get_job_status`) with this `job_id` until the job completes, then use the result from the status response.

The mode is determined by server configuration (`queue_manager.enabled` and availability of the queue manager). The client cannot assume one or the other.

## Client behaviour (transparent to the user)

The client high-level method `embed()` hides the mode:

- After calling the server once, the client checks whether the response contains a `job_id` (in any of the common shapes: top-level, `result.data.job_id`, `data.job_id`).
- **If `job_id` is present (queue mode):** The client polls `embed_job_status` (or the adapter’s queue status) at a configurable interval until the job is completed (or timeout). It then returns the same result shape as in sync mode: `{ "results": [...], "model": "...", "dimension": N }` (and optionally `embeddings` for legacy).
- **If no `job_id` (sync mode):** The client treats the response as the final result and returns it (normalized to the same shape).

So the caller always receives the **final embedding result**; they do not see `job_id` or polling. Timeout applies only when the server is in queue mode (default wait 60 s if the user does not pass `timeout`).

## API alignment

- **embed:** params `texts`, `model`, `dimension`, `error_policy`, `device`. Response: either full result (sync) or `job_id` (queue). Client normalizes both to the same return shape.
- **embed_job_status:** param `job_id`. Used by the client for polling in queue mode.
- **timing_stats:** optional `file_path`. **models:** no params.
