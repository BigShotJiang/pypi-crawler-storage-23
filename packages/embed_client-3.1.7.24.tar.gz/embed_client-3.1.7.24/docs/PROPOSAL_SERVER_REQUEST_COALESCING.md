# Proposal: Request coalescing / dynamic batching on the embedding server

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com  
**Date:** 2026-02  
**Audience:** Server (embed) developers

---

## Summary

Propose adding a **request coalescing** (dynamic batching) layer on the embedding server: collect multiple incoming embed requests over a short time window, merge their texts into a single batch, run one `embed` call, then split the result and respond to each original request. This improves throughput and GPU utilization without increasing the number of model copies in memory (unlike raising `max_concurrent_jobs`).

---

## Motivation

- **Current behaviour:** Each embed job is processed independently. With `max_concurrent_jobs=1`, jobs run one after another. A single batch of 10 texts is fast (~0.2 s on server), but when many clients send small requests (e.g. 1 text each), total wall-clock time is dominated by queue wait (tens of seconds for 11 jobs).
- **Constraint:** GPU memory is limited; increasing `max_concurrent_jobs` to 2 would roughly double model memory (two worker processes, two model copies), which is not acceptable.
- **Goal:** Use one model instance and one forward pass to serve multiple logical requests by batching them together, then splitting the output. Memory grows with batch size (activations), not with number of model copies.

---

## Proposed behaviour

1. **Input:** Multiple embed requests (possibly from different clients) arrive within a configurable time window (e.g. 20–50 ms) or until a max batch size is reached (e.g. 32 or 64 texts).
2. **Coalescing:** A component (middleware or queue front) collects these requests and merges their `texts` into one list, keeping a mapping: `(request_id, start_index, count)` so we know which slice of the batch belongs to which request.
3. **Single embed call:** One `embed(texts=merged_texts)` is executed (one job in the queue or one direct call). One forward pass, one model in GPU.
4. **Split:** The returned `results` (or `embeddings`) are sliced according to the mapping; each original request receives only its slice (same order as its input texts).
5. **Responses:** Each waiting client/caller gets its response as soon as the single batch completes; from the client’s perspective the API is unchanged (request/response per call).

---

## Design details

### Where to implement

- **Option A (recommended):** In front of the existing queue: a “coalescer” that:
  - Accepts incoming embed requests and holds them briefly (time window + max batch size).
  - When the window expires or the batch is full, builds one job with merged texts and a metadata structure for splitting.
  - Submits one job to the current queue; when the job completes, splits the result and resolves all waiting requests (e.g. futures or callbacks).
- **Option B:** Inside the queue worker: the worker dequeues multiple small jobs, merges their texts, runs one embed, then splits and assigns results back to each job. This requires the queue to support “batch dequeue” or the worker to peek and group.

### Configuration (suggested)

- `coalescing_enabled`: bool (default `false` for backward compatibility).
- `coalescing_window_sec`: float (e.g. 0.02–0.05). Max time to wait for more requests before sending the batch.
- `coalescing_max_texts`: int (e.g. 32, 64). Flush when the merged batch reaches this size even if the window has not expired.
- Optional: `coalescing_max_wait_sec` per request (e.g. 0.1) so that a single request is never delayed beyond that if no other requests arrive.

### Mapping and splitting

- For each incoming request `i`, store `(num_texts_i, result_offset)` or simply `num_texts_i` and compute offsets as cumulative sum.
- After `embed()` returns, `results` is a list of items (e.g. `{body, embedding, tokens, bm25_tokens}`). Slice `results[offset:offset+num_texts_i]` for request `i`. If the API returns `embeddings` only, slice the same way and optionally attach tokens if needed per contract.

### Error handling

- If the single batch call fails (e.g. one text invalid with `error_policy=fail_fast`), the whole batch fails; all coalesced requests should receive the same error (or a generic “batch failed”).
- If the server supports per-item errors (`error_policy=continue`), map each item in `results` back to the correct request; if an item has `error` set, the corresponding request can be failed or returned with a partial result plus error, depending on API contract.

### Compatibility

- Clients do not need to change: they still send one request per logical call. Only the server’s internal handling changes when coalescing is enabled.
- Existing behaviour (no coalescing) remains the default; coalescing is opt-in via config.

---

## Benefits

- **Throughput:** One forward pass serves N logical requests; GPU time scales with total texts, not with number of requests.
- **Latency:** Slight increase for the first request in a window (waits up to `coalescing_window_sec`), but average latency can drop when many small requests are batched.
- **Memory:** No extra model copies; only batch activations grow (bounded by `coalescing_max_texts` and model max length).
- **Queue depth:** Fewer jobs in the queue (one coalesced job instead of N small ones), so queue wait time decreases.

---

## Open points

- Exact placement (in front of queue vs inside worker) and interaction with existing queue semantics (job_id, status, retention).
- Whether to coalesce only “embed” or also other heavy commands, if any.
- Metrics: e.g. coalesced_batch_size, coalescing_wait_sec per request, to tune window and max_texts.

---

## References

- Client-side observation: batch of 10 texts on server &lt; 1 s; with 11 separate jobs (1 batch + 10 single) and `max_concurrent_jobs=1`, total time ~30–45 s (queue serialization).
- Server docs: `QUEUE_GPU_OVERLOAD_EXPLANATION.md`, `max_concurrent_jobs`, single model vs multiple workers.
