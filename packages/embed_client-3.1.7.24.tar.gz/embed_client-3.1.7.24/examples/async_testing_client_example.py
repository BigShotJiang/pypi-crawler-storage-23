#!/usr/bin/env python3
"""
Examples of async methods: EmbeddingServiceClient, validate_config, generate_config,
embed with wait=True (execute_async/WebSocket), health, batch, wait_for_job.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

# Add project root for imports when run as script
_root = Path(__file__).resolve().parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from embed_client.testing_client import EmbeddingServiceClient  # noqa: E402
from embed_client.async_client import EmbeddingServiceAsyncClient  # noqa: E402


async def example_validate_and_generate_config():
    """Validate config and generate a new one using client methods."""
    print("=== Validate and generate config (async client methods) ===\n")

    # Generate config via client class method (adapter-based generator)
    config = EmbeddingServiceClient.generate_config(
        mode="http",
        host="localhost",
        port=8001,
        output_path=None,
    )
    print("Generated HTTP config (keys):", list(config.keys()))

    # Validate config dict
    valid, errors = EmbeddingServiceClient.validate_config(config)
    print(f"Validate generated config: valid={valid}, errors={errors}\n")

    # Same via EmbeddingServiceAsyncClient (mixin)
    valid2, errors2 = EmbeddingServiceAsyncClient.validate_config(config)
    print(f"EmbeddingServiceAsyncClient.validate_config: valid={valid2}\n")


async def example_from_config_and_health(config_path: str | Path):
    """Create client from config file (with validation), check health."""
    print("=== From config + health (validation on load) ===\n")

    # Optional: validate before loading
    valid, errs = EmbeddingServiceClient.validate_config(config_path)
    if not valid:
        print("Config invalid:", errs)
        return
    print("Config valid, loading client...")

    client = EmbeddingServiceClient.from_config(config_path, validate=True)
    async with client:
        health = await client.health()
        print(f"Health: {health}\n")


async def example_embed_wait_single_text(config_path: str | Path):
    """Embed a single text with wait=True (execute_async / WebSocket push)."""
    print("=== Embed single text (wait=True, execute_async/WS) ===\n")

    client = EmbeddingServiceClient.from_config(config_path, validate=False)
    async with client:
        texts = ["Hello, async embedding with WebSocket push."]
        result = await client.embed(texts, wait=True, wait_timeout=60)
        print(
            "Embed result keys:",
            list(result.keys()) if isinstance(result, dict) else type(result),
        )
        if isinstance(result, dict) and "results" in result:
            print("Number of result items:", len(result["results"]))
        print()


async def example_embed_batch(config_path: str | Path):
    """Embed a batch of texts (async, wait=True)."""
    print("=== Embed batch of texts (async) ===\n")

    client = EmbeddingServiceClient.from_config(config_path, validate=False)
    batch_texts = [
        "First document for batch embedding.",
        "Second document with different content.",
        "Third document to measure batch latency.",
    ]
    async with client:
        result = await client.embed(batch_texts, wait=True, wait_timeout=90)
        print(
            "Batch embed result keys:",
            list(result.keys()) if isinstance(result, dict) else type(result),
        )
        if isinstance(result, dict) and "results" in result:
            print("Batch size:", len(result["results"]))
        print()


async def example_list_commands_and_models(config_path: str | Path):
    """List commands and models via async client."""
    print("=== List commands and models (async) ===\n")

    client = EmbeddingServiceClient.from_config(config_path, validate=False)
    async with client:
        commands = await client.list_commands()
        print(
            "Commands (keys):",
            list(commands.keys())[:5] if isinstance(commands, dict) else type(commands),
        )
        try:
            models = await client.models()
            print(
                "Models (keys):",
                list(models.keys()) if isinstance(models, dict) else type(models),
            )
        except Exception as e:
            print("Models (optional):", e)
        print()


async def example_submit_and_wait_via_websocket(config_path: str | Path):
    """Submit embed without wait, then wait_for_job_via_websocket."""
    print("=== Submit job then wait via WebSocket (async) ===\n")

    client = EmbeddingServiceClient.from_config(config_path, validate=False)
    async with client:
        # Submit without wait
        result = await client.embed(["Text for async job."], wait=False, wait_timeout=0)
        job_id = result.get("job_id") if isinstance(result, dict) else None
        if not job_id:
            print("No job_id in response; server may return sync result.")
            print("Result:", result)
            return
        # Wait for result via WebSocket push
        data = await client.wait_for_job_via_websocket(job_id, timeout=60)
        print(
            "Job completed via WS, result keys:",
            list(data.keys())[:8] if isinstance(data, dict) else type(data),
        )
        print()


def main():
    """Run examples; config path can be passed as first argument."""
    config_path = Path(__file__).parent.parent / "configs" / "mtls_8001.json"
    if len(sys.argv) > 1:
        config_path = Path(sys.argv[1])

    if not config_path.exists():
        print(f"Config not found: {config_path}")
        print("Run without server: validate and generate only.")
        asyncio.run(example_validate_and_generate_config())
        return

    async def run_all():
        await example_validate_and_generate_config()
        await example_from_config_and_health(config_path)
        await example_embed_wait_single_text(config_path)
        await example_embed_batch(config_path)
        await example_list_commands_and_models(config_path)
        await example_submit_and_wait_via_websocket(config_path)

    asyncio.run(run_all())
    print("Done.")


if __name__ == "__main__":
    main()
