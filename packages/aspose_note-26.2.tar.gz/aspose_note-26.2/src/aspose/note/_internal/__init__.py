"""Internal implementation modules.

End users should use the public API in `aspose.note`.
"""

from __future__ import annotations
