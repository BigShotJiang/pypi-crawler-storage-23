"""Aspose namespace package (Python).

This repository provides a Python implementation inspired by Aspose.Note public APIs.
"""

from __future__ import annotations

__all__ = ["note"]
