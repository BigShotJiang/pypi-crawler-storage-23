#!/usr/bin/env python3
"""
Historical data seeding script for Beacon SDK.

Generates traces over a configurable time period with realistic distributions,
varied span types, models, agent names, environments, and latency patterns.

Requirements:
- BEACON_ENDPOINT environment variable
- BEACON_API_KEY environment variable
- For real API calls: OPENAI_API_KEY

Usage:
    # Default: 500 traces over 90 days, 10% real API calls
    python seed_historical_data.py

    # Custom configuration
    python seed_historical_data.py --traces 1000 --days 180 --real-ratio 0.05

    # Dry run (no data sent)
    python seed_historical_data.py --dry-run
"""

import argparse
import logging
import os
import random
import sys
import time
from datetime import datetime
from typing import Any

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dotenv import load_dotenv

load_dotenv()

from lumenova_beacon import BeaconClient, BeaconCallbackHandler, trace
from lumenova_beacon.tracing.span import Span

# LangChain imports
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_core.tools import tool
from langchain_core.messages import HumanMessage

# LangGraph imports
from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.prebuilt import ToolNode

from config.models import MODELS, AGENT_NAMES, ENVIRONMENTS
from config.scenarios import SCENARIOS
from generators.timestamps import HistoricalTimestampGenerator
from generators.spans import SimulatedSpanBuilder
from generators.traces import TraceBuilder

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


# ============================================================================
# REAL API SCENARIO FUNCTIONS
# ============================================================================

# Sample prompts for variety
GENERATION_PROMPTS = [
    "Explain observability in software engineering in one sentence.",
    "What is distributed tracing and why is it important?",
    "Describe the difference between logs, metrics, and traces.",
    "What are spans in the context of observability?",
    "Explain the concept of trace context propagation.",
]

# Sample documents for RAG scenarios
RAG_DOCUMENTS = [
    Document(
        page_content="Observability is the ability to understand the internal state of a system by examining its outputs, such as logs, metrics, and traces.",
        metadata={"source": "obs-guide", "page": 1},
    ),
    Document(
        page_content="Distributed tracing tracks requests as they flow through microservices, creating a complete picture of the request lifecycle.",
        metadata={"source": "tracing-101", "page": 3},
    ),
    Document(
        page_content="Spans represent units of work in distributed tracing, containing timing data, metadata, and parent-child relationships.",
        metadata={"source": "tracing-101", "page": 7},
    ),
    Document(
        page_content="OpenTelemetry is a vendor-neutral observability framework for instrumenting, generating, collecting, and exporting telemetry data.",
        metadata={"source": "otel-docs", "page": 1},
    ),
]

RAG_QUESTIONS = [
    "What are spans in distributed tracing?",
    "How does observability help understand system state?",
    "What is OpenTelemetry used for?",
    "How do traces flow through microservices?",
]


# Tool definitions for LangGraph agent
@tool
@trace
def get_weather(location: str) -> str:
    """Get the current weather for a location."""
    time.sleep(0.3)  # Simulate API latency
    weather_options = ["sunny", "cloudy", "rainy", "partly cloudy"]
    temp = random.randint(45, 85)
    return f"The weather in {location} is {random.choice(weather_options)} with a temperature of {temp}°F."


@tool
@trace
def search_knowledge(query: str) -> str:
    """Search internal knowledge base for information."""
    time.sleep(0.4)  # Simulate search latency
    results = {
        "observability": "Observability helps teams understand system behavior through logs, metrics, and traces.",
        "tracing": "Distributed tracing follows requests across service boundaries to identify bottlenecks.",
        "spans": "Spans are the building blocks of traces, representing individual operations.",
    }
    for key, value in results.items():
        if key in query.lower():
            return f"Found: {value}"
    return "No relevant information found in knowledge base."


@tool
@trace
def calculate(expression: str) -> str:
    """Evaluate a simple mathematical expression."""
    time.sleep(0.2)
    try:
        # Safe evaluation of simple expressions
        result = eval(expression, {"__builtins__": {}}, {})
        return f"Result: {result}"
    except Exception:
        return f"Could not evaluate: {expression}"


def run_langchain_generation(handler: BeaconCallbackHandler, streaming: bool = False) -> None:
    """Run a simple LangChain generation - creates GENERATION span.

    Args:
        handler: BeaconCallbackHandler with session/metadata configured
        streaming: If True, enable streaming to capture TTFT metrics
    """
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.7, streaming=streaming)
    prompt = random.choice(GENERATION_PROMPTS)

    logger.debug(f"Running generation (streaming={streaming}): {prompt[:50]}...")
    llm.invoke(prompt, config={"callbacks": [handler]})


def run_langchain_rag(handler: BeaconCallbackHandler, streaming: bool = False) -> None:
    """Run a LangChain RAG pipeline - creates CHAIN + RETRIEVAL + GENERATION spans.

    Args:
        handler: BeaconCallbackHandler with session/metadata configured
        streaming: If True, enable streaming to capture TTFT metrics
    """
    # Create embeddings and vector store
    embeddings = OpenAIEmbeddings()
    vectorstore = FAISS.from_documents(RAG_DOCUMENTS, embeddings)
    retriever = vectorstore.as_retriever(search_kwargs={"k": 2})

    def format_docs(docs: list[Document]) -> str:
        return "\n\n".join(doc.page_content for doc in docs)

    # Create RAG chain
    prompt = ChatPromptTemplate.from_template(
        """Answer the question based on the following context:

Context: {context}

Question: {question}

Answer:"""
    )

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0, streaming=streaming)

    rag_chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )

    question = random.choice(RAG_QUESTIONS)
    logger.debug(f"Running RAG (streaming={streaming}): {question}")
    rag_chain.invoke(question, config={"callbacks": [handler]})


def run_langgraph_agent(handler: BeaconCallbackHandler, streaming: bool = False) -> None:
    """Run a LangGraph agent with tools - creates AGENT + TOOL + GENERATION spans.

    Args:
        handler: BeaconCallbackHandler with session/metadata configured
        streaming: If True, enable streaming to capture TTFT metrics
    """

    def should_continue(state: MessagesState) -> str:
        messages = state["messages"]
        last_message = messages[-1]
        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "tools"
        return END

    def call_model(state: MessagesState) -> dict[str, Any]:
        messages = state["messages"]
        llm = ChatOpenAI(model="gpt-4o-mini", temperature=0, streaming=streaming)
        llm_with_tools = llm.bind_tools([get_weather, search_knowledge])
        response = llm_with_tools.invoke(messages)
        return {"messages": [response]}

    # Build the graph
    workflow = StateGraph(MessagesState)
    workflow.add_node("agent", call_model)
    workflow.add_node("tools", ToolNode([get_weather, search_knowledge]))

    workflow.add_edge(START, "agent")
    workflow.add_conditional_edges("agent", should_continue, ["tools", END])
    workflow.add_edge("tools", "agent")

    app = workflow.compile()

    # Select a query
    queries = [
        "What's the weather in San Francisco?",
        "What's the weather in New York City?",
        "Search for information about observability.",
        "Find details about distributed tracing.",
    ]
    query = random.choice(queries)

    logger.debug(f"Running agent: {query}")
    app.invoke(
        {"messages": [HumanMessage(content=query)]}, config={"callbacks": [handler]}
    )


def run_multi_turn_chat(handler: BeaconCallbackHandler, streaming: bool = False) -> None:
    """Run a multi-turn conversation - creates multiple GENERATION spans with session tracking.

    Args:
        handler: BeaconCallbackHandler with session/metadata configured
        streaming: If True, enable streaming to capture TTFT metrics
    """
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.7, streaming=streaming)

    # Conversation topics
    conversations = [
        [
            "What is Python?",
            "Can you give me a simple example?",
        ],
        [
            "Explain microservices architecture.",
            "What are the main challenges?",
        ],
        [
            "What is observability?",
            "How does it differ from monitoring?",
        ],
    ]

    conversation = random.choice(conversations)
    messages: list[Any] = []

    for turn in conversation:
        messages.append(HumanMessage(content=turn))
        logger.debug(f"Chat turn: {turn[:30]}...")
        response = llm.invoke(messages, config={"callbacks": [handler]})
        messages.append(response)
        time.sleep(0.5)  # Small delay between turns


def run_real_api_scenario(client: BeaconClient, start_time: datetime, stream_ratio: float = 0.3) -> None:
    """Run a diverse real API scenario using LangChain instrumentation.

    Randomly selects from multiple scenario types:
    - Simple generation (30%)
    - RAG pipeline (25%)
    - LangGraph agent (25%)
    - Multi-turn chat (20%)

    Args:
        client: BeaconClient instance
        start_time: Start time for the trace (used for historical timestamp override)
        stream_ratio: Probability of using streaming (0.0-1.0), enables TTFT tracking
    """
    # Set timestamp override for historical data seeding
    client._timestamp_override = start_time

    try:
        session_id = f"real-session-{start_time.strftime('%Y%m%d%H%M%S')}-{random.randint(1000, 9999)}"

        # Decide if this call should use streaming
        streaming = random.random() < stream_ratio

        # Create handler with metadata matching simulated span config
        handler = BeaconCallbackHandler(
            session_id=session_id,
            environment=random.choice(ENVIRONMENTS),
            agent_name=random.choice(AGENT_NAMES),
            metadata={
                "source": "historical_seeding",
                "scenario_type": "real_api",
                "streaming": streaming,
            },
        )

        # Select scenario by weight
        scenario_weights = {
            "generation": 0.30,
            "rag": 0.25,
            "agent": 0.25,
            "multi_turn": 0.20,
        }

        scenario = random.choices(
            list(scenario_weights.keys()),
            weights=list(scenario_weights.values()),
            k=1,
        )[0]

        if scenario == "generation":
            logger.debug(f"Scenario: Simple Generation (session={session_id}, streaming={streaming})")
            run_langchain_generation(handler, streaming=streaming)
        elif scenario == "rag":
            logger.debug(f"Scenario: RAG Pipeline (session={session_id}, streaming={streaming})")
            run_langchain_rag(handler, streaming=streaming)
        elif scenario == "agent":
            logger.debug(f"Scenario: LangGraph Agent (session={session_id}, streaming={streaming})")
            run_langgraph_agent(handler, streaming=streaming)
        elif scenario == "multi_turn":
            logger.debug(f"Scenario: Multi-Turn Chat (session={session_id}, streaming={streaming})")
            run_multi_turn_chat(handler, streaming=streaming)
    except Exception as e:
        logger.warning(f"Real API scenario '{scenario}' failed: {e}")
    finally:
        # Clear timestamp override after scenario
        client._timestamp_override = None


def send_spans_in_batches(
    client: BeaconClient,
    spans: list[Span],
    batch_size: int = 50,
    delay_between_batches: float = 0.5,
) -> int:
    """Send spans to Beacon in batches via the SDK.

    Args:
        client: BeaconClient instance
        spans: List of Beacon spans to send
        batch_size: Number of spans per batch
        delay_between_batches: Delay between batches in seconds

    Returns:
        Number of spans successfully sent.
    """
    total_sent = 0
    total_batches = (len(spans) + batch_size - 1) // batch_size

    for i in range(0, len(spans), batch_size):
        batch = spans[i : i + batch_size]
        batch_num = i // batch_size + 1

        try:
            # Use SDK's export_spans method
            sent = client.export_spans(batch)
            total_sent += sent

            if sent == len(batch):
                logger.info(
                    f"Sent batch {batch_num}/{total_batches} ({len(batch)} spans)"
                )
            else:
                logger.warning(
                    f"Batch {batch_num}: only {sent}/{len(batch)} spans sent"
                )
        except Exception as e:
            logger.error(f"Error sending batch {batch_num}: {e}")

        # Delay between batches to avoid overwhelming the server
        if i + batch_size < len(spans):
            time.sleep(delay_between_batches)

    return total_sent


def generate_statistics(spans: list[Span]) -> dict:
    """Generate statistics about the generated spans.

    Args:
        spans: List of generated spans

    Returns:
        Dictionary of statistics.
    """
    from collections import Counter

    stats = {
        "total_spans": len(spans),
        "unique_traces": len(set(s.trace_id for s in spans)),
        "unique_sessions": len(set(s.session_id for s in spans if s.session_id)),
        "span_types": Counter(s.span_type.value for s in spans),
        "environments": Counter(
            s.attributes.get("deployment.environment.name", "unknown") for s in spans
        ),
        "models": Counter(
            s.attributes.get("gen_ai.request.model", "none")
            for s in spans
            if "gen_ai.request.model" in s.attributes
        ),
        "error_count": sum(1 for s in spans if s.status_code.value == "ERROR"),
    }

    return stats


def print_statistics(stats: dict) -> None:
    """Print statistics in a formatted way.

    Args:
        stats: Statistics dictionary from generate_statistics()
    """
    print("\n" + "=" * 60)
    print("GENERATION STATISTICS")
    print("=" * 60)

    print(f"\nTotal Spans: {stats['total_spans']}")
    print(f"Unique Traces: {stats['unique_traces']}")
    print(f"Unique Sessions: {stats['unique_sessions']}")
    print(f"Error Spans: {stats['error_count']} ({stats['error_count']/stats['total_spans']*100:.1f}%)")

    print("\nSpan Types:")
    for span_type, count in sorted(stats["span_types"].items(), key=lambda x: -x[1]):
        print(f"  {span_type}: {count}")

    print("\nEnvironments:")
    for env, count in sorted(stats["environments"].items(), key=lambda x: -x[1]):
        print(f"  {env}: {count}")

    print("\nModels:")
    for model, count in sorted(stats["models"].items(), key=lambda x: -x[1]):
        if model != "none":
            print(f"  {model}: {count}")


def main() -> None:
    """Main entry point for the historical seeding script."""
    parser = argparse.ArgumentParser(
        description="Generate historical trace data for Beacon",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--traces",
        type=int,
        default=500,
        help="Number of traces to generate",
    )
    parser.add_argument(
        "--days",
        type=int,
        default=90,
        help="Number of days of history to generate",
    )
    parser.add_argument(
        "--real-ratio",
        type=float,
        default=0.1,
        help="Ratio of real API calls (0.0-1.0)",
    )
    parser.add_argument(
        "--stream-ratio",
        type=float,
        default=0.3,
        help="Ratio of streaming LLM calls for real API (0.0-1.0)",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=50,
        help="Number of spans to send per batch",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Generate spans but don't send them",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose logging",
    )
    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    print("=" * 60)
    print("BEACON SDK - HISTORICAL DATA SEEDING")
    print("=" * 60)

    # Validate environment
    endpoint = os.getenv("BEACON_ENDPOINT")
    api_key = os.getenv("BEACON_API_KEY")

    if not endpoint or not api_key:
        print("\nError: Missing required environment variables.")
        print("Please set BEACON_ENDPOINT and BEACON_API_KEY")
        sys.exit(1)

    print(f"\nConfiguration:")
    print(f"  Traces: {args.traces}")
    print(f"  Days: {args.days}")
    print(f"  Real API Ratio: {args.real_ratio * 100:.0f}%")
    print(f"  Stream Ratio: {args.stream_ratio * 100:.0f}%")
    print(f"  Batch Size: {args.batch_size}")
    print(f"  Dry Run: {args.dry_run}")
    print(f"  Endpoint: {endpoint}")

    # Initialize client - always needed now (for export_spans)
    print("\nInitializing Beacon client...")
    client = BeaconClient(
        endpoint=endpoint,
        api_key=api_key,
        timeout=60.0,  # Increase timeout for batch exports
    )

    # Initialize generators
    print("Initializing generators...")
    timestamp_gen = HistoricalTimestampGenerator(
        days_back=args.days,
        total_traces=args.traces,
    )

    span_builder = SimulatedSpanBuilder(
        models=MODELS,
        agent_names=AGENT_NAMES,
        environments=ENVIRONMENTS,
    )

    trace_builder = TraceBuilder(
        span_builder=span_builder,
        agent_names=AGENT_NAMES,
        environments=ENVIRONMENTS,
    )

    # Generate timestamps
    print(f"\nGenerating {args.traces} trace timestamps over {args.days} days...")
    timestamps = timestamp_gen.generate_timestamps()

    # Limit to requested number
    if len(timestamps) > args.traces:
        timestamps = timestamps[: args.traces]
    elif len(timestamps) < args.traces:
        # If we don't have enough, we'll work with what we have
        print(f"  Note: Generated {len(timestamps)} timestamps (requested {args.traces})")

    # Calculate split
    real_call_count = int(len(timestamps) * args.real_ratio)
    simulated_count = len(timestamps) - real_call_count

    print(f"\nGenerating traces:")
    print(f"  Real API calls: {real_call_count}")
    print(f"  Simulated: {simulated_count}")

    all_spans: list[Span] = []
    start_time = time.time()

    # Generate simulated traces
    print("\nGenerating simulated traces...")
    simulated_timestamps = timestamps[real_call_count:]
    simulated_spans = trace_builder.build_multiple_traces(SCENARIOS, simulated_timestamps)
    all_spans.extend(simulated_spans)
    print(f"  Generated {len(simulated_spans)} simulated spans")

    # Generate real API traces (if any)
    # Note: Real API spans are auto-exported via BeaconCallbackHandler + OpenTelemetry
    # so we don't collect them manually - they go directly to the backend
    real_api_count = 0
    if real_call_count > 0 and not args.dry_run:
        print(f"\nMaking {real_call_count} real API calls (LangChain instrumented)...")
        print("  Scenarios: Generation (30%), RAG (25%), Agent (25%), Multi-turn (20%)")
        print(f"  Streaming: {args.stream_ratio * 100:.0f}% of calls (captures TTFT)")
        for i, ts in enumerate(timestamps[:real_call_count]):
            run_real_api_scenario(client, ts, stream_ratio=args.stream_ratio)
            real_api_count += 1
            if (i + 1) % 10 == 0:
                print(f"  Completed {i + 1}/{real_call_count} real calls")

        # Flush real API spans to ensure they're sent
        print("  Flushing real API spans...")
        client.flush()

    generation_time = time.time() - start_time

    # Print statistics for simulated spans only
    # (real API spans are tracked via OpenTelemetry, not in all_spans)
    if all_spans:
        stats = generate_statistics(all_spans)
        print_statistics(stats)
    else:
        print("\n" + "=" * 60)
        print("GENERATION STATISTICS")
        print("=" * 60)
        print(f"\nReal API calls made: {real_api_count}")
        print("(Real API spans exported via OpenTelemetry - stats not available)")

    # Send simulated spans
    if args.dry_run:
        print("\n[DRY RUN] Skipping sending spans to Beacon")
    elif all_spans:
        print(f"\nSending {len(all_spans)} simulated spans to Beacon via SDK...")

        send_start = time.time()
        sent_count = send_spans_in_batches(
            client,
            all_spans,
            batch_size=args.batch_size,
        )

        # Final flush for any remaining spans
        client.flush()

        send_time = time.time() - send_start
        print(f"\nSent {sent_count}/{len(all_spans)} simulated spans in {send_time:.1f}s")

    # Summary
    print("\n" + "=" * 60)
    print("SEEDING COMPLETE")
    print("=" * 60)
    if all_spans:
        stats = generate_statistics(all_spans)
        print(f"Simulated spans generated: {len(all_spans)}")
        print(f"Unique simulated traces: {stats['unique_traces']}")
    if real_api_count > 0:
        print(f"Real API calls made: {real_api_count}")
        print("  (spans exported via OpenTelemetry to /v1/traces)")
    print(f"Generation time: {generation_time:.1f}s")
    print(f"Endpoint: {endpoint}")
    if not args.dry_run:
        print("\nCheck your Beacon dashboard to view the traces!")
    print("=" * 60)


if __name__ == "__main__":
    main()
