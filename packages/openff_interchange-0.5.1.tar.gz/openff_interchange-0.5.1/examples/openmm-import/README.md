# OpenMM import

In this example, a prepared system stored in OpenMM files is imported into Interchange
