# Building a variety of different virtual sites

In this example, several different types of SMIRNOFF virtual sites are used to model different chemistries.
