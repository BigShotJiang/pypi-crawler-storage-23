# Conformer energies

In this example, several conformers of a small molecule are generated and their (MM) energies are evaluated.
