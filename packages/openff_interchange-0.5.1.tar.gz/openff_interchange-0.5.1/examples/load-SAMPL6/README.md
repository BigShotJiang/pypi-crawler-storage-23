# Load a prepared SAMPL6 system

[Source](https://github.com/samplchallenges/SAMPL6/tree/c661d3985af7fa0ba8c64a1774cfb2363cd31bda/host_guest/SAMPLing)
