# Packed box

In this example, a box of mixed solvents is prepared with Sage and evaluated with Interchange.
