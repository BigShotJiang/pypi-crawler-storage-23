from openff.interchange.interop.openmm._import._import import from_openmm

__all__ = ("from_openmm",)
