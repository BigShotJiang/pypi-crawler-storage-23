"""Classes used to represent GROMACS state."""
