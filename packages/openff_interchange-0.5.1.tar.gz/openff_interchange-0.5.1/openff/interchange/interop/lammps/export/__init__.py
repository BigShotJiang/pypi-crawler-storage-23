"""Export to LAMMPS data files."""

from openff.interchange.interop.lammps.export.export import to_lammps

__all__ = ("to_lammps",)
