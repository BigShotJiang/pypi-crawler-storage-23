"""Interfaces with LAMMPS."""

from openff.interchange.interop.lammps.export import to_lammps

__all__ = ("to_lammps",)
