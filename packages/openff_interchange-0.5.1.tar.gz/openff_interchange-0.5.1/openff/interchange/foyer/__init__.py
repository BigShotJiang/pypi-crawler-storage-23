"""Foyer compatibility."""
