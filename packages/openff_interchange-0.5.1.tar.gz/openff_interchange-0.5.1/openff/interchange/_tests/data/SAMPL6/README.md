# SAMPL6 Files

* [`complex.xml`](https://github.com/samplchallenges/SAMPL6/blob/master/host_guest/SAMPLing/CB8-G3-0/OPENMM/complex.xml)
* [`complex.pdb`](https://github.com/samplchallenges/SAMPL6/blob/master/host_guest/SAMPLing/CB8-G3-0/PDB/complex.pdb)
* [`complex.gro`](//raw.githubusercontent.com/samplchallenges/SAMPL6/master/host_guest/SAMPLing/CB8-G3-0/GROMACS/complex.gro)
* [`complex.top`](//raw.githubusercontent.com/samplchallenges/SAMPL6/master/host_guest/SAMPLing/CB8-G3-0/GROMACS/complex.top)
* [`complex.prmtop`](//github.com/samplchallenges/SAMPL6/raw/master/host_guest/SAMPLing/CB8-G3-0/AMBER/complex.inp)
* [`complex.inpcrd`](//github.com/samplchallenges/SAMPL6/raw/master/host_guest/SAMPLing/CB8-G3-0/AMBER/complex.inp)
