"""Unit tests for GROMACS interoperability."""
