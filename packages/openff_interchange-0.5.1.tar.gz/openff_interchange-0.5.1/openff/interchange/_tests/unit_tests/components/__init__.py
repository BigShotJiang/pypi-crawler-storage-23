"""Unit tests for `components` module."""
