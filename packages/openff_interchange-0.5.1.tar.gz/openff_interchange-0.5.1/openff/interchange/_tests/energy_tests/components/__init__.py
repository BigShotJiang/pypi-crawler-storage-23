"""Energy tests for some `components` members."""
