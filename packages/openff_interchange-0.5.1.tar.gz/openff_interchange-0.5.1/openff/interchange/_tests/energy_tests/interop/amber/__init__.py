"""Energy tests specifically relevant to Amber behaviors."""
