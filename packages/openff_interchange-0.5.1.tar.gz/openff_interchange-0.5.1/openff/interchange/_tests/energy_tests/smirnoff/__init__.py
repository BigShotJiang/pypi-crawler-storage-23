"""Energy tests directly related to the SMIRNOFF submodule."""
