"""Interoperability tests with GROMACS."""
