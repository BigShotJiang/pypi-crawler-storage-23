"""Classes used by multiple modules."""
