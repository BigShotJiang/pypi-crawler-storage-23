from .contract import Vanity

__all__ = [
    "Vanity",
]
