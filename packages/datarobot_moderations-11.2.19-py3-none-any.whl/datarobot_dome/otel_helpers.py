#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------

import json
import logging

from opentelemetry import trace

from datarobot_dome.constants import GuardStage

_logger = logging.getLogger("otel_helpers")


def __get_otel_values(guards_list, stage, result_df):
    guard_values = {}
    for guard in guards_list:
        if not guard.has_average_score_custom_metric():
            continue
        guard_metric_column_name = guard.metric_column_name
        if guard_metric_column_name not in result_df.columns:
            _logger.warning(f"Missing column: {guard_metric_column_name} in result_df")
            continue
        guard_values[guard.get_span_column_name(stage)] = result_df[
            guard_metric_column_name
        ].tolist()[0]
    return guard_values


def report_otel_evaluation_set_metric(pipeline, result_df):
    current_span = trace.get_current_span()
    if not current_span:
        _logger.warning("No currently active span found to report evaluation set metric")
        return

    prompt_values = __get_otel_values(pipeline.get_prescore_guards(), GuardStage.PROMPT, result_df)
    response_values = __get_otel_values(
        pipeline.get_postscore_guards(), GuardStage.RESPONSE, result_df
    )

    final_value = {"prompt_guards": prompt_values, "response_guards": response_values}

    current_span.set_attribute("datarobot.moderation.evaluation", json.dumps(final_value))
