#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
from datarobot.enums import CustomMetricAggregationType
from datarobot.enums import CustomMetricDirectionality
from deepeval.metrics import TaskCompletionMetric
from langchain_openai import AzureChatOpenAI
from langchain_openai import ChatOpenAI
from llama_index.core import Settings
from llama_index.core.evaluation import FaithfulnessEvaluator
from llama_index.core.evaluation import GuidelineEvaluator
from llama_index.llms.langchain import LangChainLLM
from ragas.llms import LangchainLLMWrapper
from ragas.llms import LlamaIndexLLMWrapper
from ragas.metrics import AgentGoalAccuracyWithoutReference

from datarobot_dome.constants import AGENT_GOAL_ACCURACY_COLUMN_NAME
from datarobot_dome.constants import COST_COLUMN_NAME
from datarobot_dome.constants import CUSTOM_METRIC_DESCRIPTION_SUFFIX
from datarobot_dome.constants import FAITHFULLNESS_COLUMN_NAME
from datarobot_dome.constants import GUIDELINE_ADHERENCE_COLUMN_NAME
from datarobot_dome.constants import ROUGE_1_COLUMN_NAME
from datarobot_dome.constants import SPAN_PREFIX
from datarobot_dome.constants import TASK_ADHERENCE_SCORE_COLUMN_NAME
from datarobot_dome.constants import TOKEN_COUNT_COLUMN_NAME
from datarobot_dome.constants import GuardLLMType
from datarobot_dome.constants import GuardStage
from datarobot_dome.constants import OOTBType
from datarobot_dome.guard_helpers import ModerationDeepEvalLLM

from .base import Guard
from .guard_llm_mixin import GuardLLMMixin


class OOTBGuard(Guard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)
        self._ootb_type = config["ootb_type"]

    @property
    def ootb_type(self):
        return self._ootb_type

    def has_latency_custom_metric(self):
        """Latency is not tracked for token counts guards"""
        return self._ootb_type != OOTBType.TOKEN_COUNT

    def get_span_column_name(self, _):
        if self._ootb_type == OOTBType.TOKEN_COUNT:
            return TOKEN_COUNT_COLUMN_NAME
        elif self._ootb_type == OOTBType.ROUGE_1:
            return ROUGE_1_COLUMN_NAME
        elif self._ootb_type == OOTBType.CUSTOM_METRIC:
            return self.name
        else:
            raise NotImplementedError(f"No span attribute name defined for {self._ootb_type} guard")

    def get_span_attribute_name(self, stage):
        return f"{SPAN_PREFIX}.{stage.lower()}.{self.get_span_column_name(stage)}"


class OOTBCostMetric(OOTBGuard):
    def __init__(self, config, stage):
        super().__init__(config, stage)
        # The cost is calculated based on the usage metrics returned by the
        # completion object, so it can be evaluated only at response stage
        self._stage = GuardStage.RESPONSE
        cost_config = config["additional_guard_config"]["cost"]
        self.currency = cost_config["currency"]
        self.input_price = cost_config["input_price"]
        self.input_unit = cost_config["input_unit"]
        self.input_multiplier = self.input_price / self.input_unit
        self.output_price = cost_config["output_price"]
        self.output_unit = cost_config["output_unit"]
        self.output_multiplier = self.output_price / self.output_unit

    def get_average_score_custom_metric_name(self, _):
        return f"Total cost in {self.currency}"

    def get_average_score_metric(self, _):
        return {
            "name": self.get_average_score_custom_metric_name(_),
            "directionality": CustomMetricDirectionality.LOWER_IS_BETTER,
            "units": "value",
            "type": CustomMetricAggregationType.SUM,
            "baselineValue": 0,
            "isModelSpecific": True,
            "timeStep": "hour",
            "description": (
                f"{self.get_average_score_custom_metric_name(_)}. "
                f" {CUSTOM_METRIC_DESCRIPTION_SUFFIX}"
            ),
        }

    def get_span_column_name(self, _):
        return f"{COST_COLUMN_NAME}.{self.currency.lower()}"

    def get_span_attribute_name(self, _):
        return f"{SPAN_PREFIX}.{self._stage.lower()}.{self.get_span_column_name(_)}"


class OOTBFaithfulnessGuard(OOTBGuard, GuardLLMMixin):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)

        if self.stage == GuardStage.PROMPT:
            raise Exception("Faithfulness cannot be configured for the Prompt stage")

        # Default LLM Type for Faithfulness is set to Azure OpenAI
        self._llm_type = config.get("llm_type", GuardLLMType.AZURE_OPENAI)
        Settings.llm = self.get_llm(config, self._llm_type)
        Settings.embed_model = None
        self._evaluator = FaithfulnessEvaluator()

    @property
    def faithfulness_evaluator(self):
        return self._evaluator

    def get_span_column_name(self, _):
        return FAITHFULLNESS_COLUMN_NAME

    def get_span_attribute_name(self, _):
        return f"{SPAN_PREFIX}.{self._stage.lower()}.{self.get_span_column_name(_)}"


class OOTBAgentGoalAccuracyGuard(OOTBGuard, GuardLLMMixin):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)

        if self.stage == GuardStage.PROMPT:
            raise Exception("Agent Goal Accuracy guard cannot be configured for the Prompt stage")

        # Default LLM Type for Agent Goal Accuracy is set to Azure OpenAI
        self._llm_type = config.get("llm_type", GuardLLMType.AZURE_OPENAI)
        llm = self.get_llm(config, self._llm_type)
        if self._llm_type == GuardLLMType.AZURE_OPENAI:
            evaluator_llm = LangchainLLMWrapper(llm)
        else:
            evaluator_llm = LlamaIndexLLMWrapper(llm)
        self.scorer = AgentGoalAccuracyWithoutReference(llm=evaluator_llm)

    @property
    def accuracy_scorer(self):
        return self.scorer

    def get_span_column_name(self, _):
        return AGENT_GOAL_ACCURACY_COLUMN_NAME

    def get_span_attribute_name(self, _):
        return f"{SPAN_PREFIX}.{self._stage.lower()}.{self.get_span_column_name(_)}"


class OOTBTaskAdherenceGuard(OOTBGuard, GuardLLMMixin):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)

        if self.stage == GuardStage.PROMPT:
            raise Exception("Agent Goal Accuracy guard cannot be configured for the Prompt stage")

        # Default LLM Type for Task Adherence is set to Azure OpenAI
        self._llm_type = config.get("llm_type", GuardLLMType.AZURE_OPENAI)
        llm = self.get_llm(config, self._llm_type)
        deepeval_llm = ModerationDeepEvalLLM(llm)
        self.scorer = TaskCompletionMetric(model=deepeval_llm, include_reason=True)

    @property
    def task_adherence_scorer(self):
        return self.scorer

    def get_span_column_name(self, _):
        return TASK_ADHERENCE_SCORE_COLUMN_NAME

    def get_span_attribute_name(self, _):
        return f"{SPAN_PREFIX}.{self._stage.lower()}.{self.get_span_column_name(_)}"


class OOTBAgentGuidelineAdherence(OOTBGuard, GuardLLMMixin):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)

        if self.stage == GuardStage.PROMPT:
            raise Exception(
                "Agent Guideline Adherence guard cannot be configured for the Prompt stage"
            )

        self.guideline = config.get("additional_guard_config", {}).get("agent_guideline")
        if self.guideline is None or len(self.guideline) == 0:
            raise Exception("Agent Guideline Adherence requires at least one guideline.")

        # Default LLM Type for Guideline Adherence is set to Azure OpenAI
        self._llm_type = config.get("llm_type", GuardLLMType.AZURE_OPENAI)
        llm = self.get_llm(config, self._llm_type)
        if isinstance(llm, AzureChatOpenAI) or isinstance(llm, ChatOpenAI):
            llm = LangChainLLM(llm=llm)
        self.scorer = GuidelineEvaluator(llm=llm, guidelines=self.guideline)

    @property
    def guideline_adherence_scorer(self) -> GuidelineEvaluator:
        return self.scorer

    def get_span_column_name(self, _):
        return GUIDELINE_ADHERENCE_COLUMN_NAME

    def get_span_attribute_name(self, _):
        return f"{SPAN_PREFIX}.{self._stage.lower()}.{self.get_span_column_name(_)}"
