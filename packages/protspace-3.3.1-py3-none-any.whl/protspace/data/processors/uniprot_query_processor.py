import gzip
import logging
import shutil
import tempfile
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import requests
from pymmseqs.commands import easy_search
from tqdm import tqdm

from protspace.data.annotations.manager import ProteinAnnotationManager
from protspace.data.processors.base_processor import BaseProcessor
from protspace.utils import REDUCERS

logger = logging.getLogger(__name__)


class UniProtQueryProcessor(BaseProcessor):
    """Processor for UniProt query-based protein data analysis."""

    def __init__(self, config: dict[str, Any]):
        # Remove command-line specific arguments that aren't used for dimension reduction
        clean_config = config.copy()
        for arg in [
            "query",
            "sp",
            "output",
            "methods",
            "verbose",
            "custom_names",
            "delimiter",
            "annotations",
            "save_files",
            "no_save_files",
            "keep_tmp",
        ]:
            clean_config.pop(arg, None)

        # Initialize base class with cleaned config and reducers
        super().__init__(clean_config, REDUCERS)

    def process_query(
        self,
        query: str,
        output_path: Path,
        intermediate_dir: Path,
        annotations: str = None,
        delimiter: str = ",",
        keep_tmp: bool = False,
        non_binary: bool = False,
        fasta_path: Path = None,
        headers: list[str] = None,
    ) -> tuple[pd.DataFrame, np.ndarray, list[str], dict[str, Path]]:
        """
        Process a UniProt query and return data for visualization.

        Args:
            query: UniProt search query (exact query to send to UniProt)
            output_path: Path for output file
            intermediate_dir: Directory for intermediate files
            annotations: Annotations to fetch
            delimiter: CSV delimiter
            keep_tmp: Whether to keep temporary files (FASTA, complete protein annotations, and similarity matrix)
            non_binary: Whether to use non-binary formats (CSV instead of parquet)
            fasta_path: Optional pre-downloaded FASTA file path
            headers: Optional pre-extracted protein IDs

        Returns:
            Tuple of (annotations_df, embeddings_array, headers_list, saved_files_dict)
        """

        saved_files = {}
        fasta_filename = "sequences.fasta"

        # Always use parquet for internal metadata cache
        if keep_tmp:
            intermediate_dir.mkdir(parents=True, exist_ok=True)
            fasta_save_path = intermediate_dir / fasta_filename
            metadata_save_path = intermediate_dir / "all_annotations.parquet"
            similarity_matrix_path = intermediate_dir / "similarity_matrix.csv"
        else:
            fasta_save_path = None
            metadata_save_path = None
            similarity_matrix_path = None

        # Check for cached files when keep_tmp is enabled
        fasta_cached = keep_tmp and fasta_save_path and fasta_save_path.exists()
        similarity_cached = (
            keep_tmp and similarity_matrix_path and similarity_matrix_path.exists()
        )
        metadata_cached = (
            keep_tmp and metadata_save_path and metadata_save_path.exists()
        )

        # Download FASTA from UniProt or use pre-downloaded one
        if fasta_path and headers:
            # Use pre-downloaded FASTA and headers
            if keep_tmp and fasta_save_path:
                # Copy to permanent location
                import shutil

                fasta_save_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy(fasta_path, fasta_save_path)
                fasta_path = fasta_save_path
                saved_files["fasta"] = fasta_save_path
        elif fasta_cached:
            logger.info(f"Loading cached FASTA from: {fasta_save_path}")
            # Extract headers from cached FASTA
            headers = self._extract_identifiers_from_fasta_file(fasta_save_path)
            fasta_path = fasta_save_path
            saved_files["fasta"] = fasta_save_path
        else:
            headers, fasta_path = self._search_and_download_fasta(
                query, save_to=fasta_save_path
            )
            if not headers:
                raise ValueError(f"No sequences found for query: '{query}'")
            if fasta_save_path:
                saved_files["fasta"] = fasta_save_path

        # Generate or load similarity matrix
        if similarity_cached:
            logger.info(
                f"Loading cached similarity matrix from: {similarity_matrix_path}"
            )
            sim_df = pd.read_csv(similarity_matrix_path, index_col=0)
            data = sim_df.values
            headers = sim_df.index.tolist()
            saved_files["similarity_matrix"] = similarity_matrix_path
        else:
            data, headers = self._get_similarity_matrix(fasta_path, headers)
            if not fasta_save_path:
                # Clean up temporary FASTA if not keeping it
                fasta_path.unlink(missing_ok=True)
            # Save similarity matrix if keep_tmp is enabled
            if similarity_matrix_path:
                self._save_similarity_matrix(data, headers, similarity_matrix_path)
                saved_files["similarity_matrix"] = similarity_matrix_path

        # Generate or load metadata file (with incremental fetching support)
        if metadata_cached:
            logger.info(f"Loading cached metadata from: {metadata_save_path}")
            cached_df = pd.read_parquet(metadata_save_path)

            # Determine required annotations for incremental check
            if annotations and not annotations.endswith(".csv"):
                annotations_list = [
                    annotation.strip() for annotation in annotations.split(",")
                ]
                from protspace.data.annotations.configuration import (
                    AnnotationConfiguration,
                )

                annotations_list = AnnotationConfiguration(
                    annotations_list
                ).user_annotations
            else:
                annotations_list = None

            if annotations_list is None:
                from protspace.data.annotations.configuration import (
                    ANNOTATION_GROUPS,
                )

                required_annotations = set(ANNOTATION_GROUPS["default"])
            else:
                required_annotations = set(annotations_list)

            cached_annotations = set(cached_df.columns) - {"identifier"}
            missing = required_annotations - cached_annotations

            if not missing:
                # Cache has everything we need
                if annotations_list:
                    cols = ["identifier"] + [
                        f for f in annotations_list if f in cached_df.columns
                    ]
                    annotations_df = cached_df[cols]
                else:
                    annotations_df = cached_df
            else:
                # Incremental fetch of missing annotations
                from protspace.data.annotations.configuration import (
                    AnnotationConfiguration,
                )

                sources_to_fetch = AnnotationConfiguration.determine_sources_to_fetch(
                    cached_annotations, required_annotations
                )
                logger.info(f"Missing annotations: {missing}")
                logger.info(
                    f"Will fetch from sources: {[k for k, v in sources_to_fetch.items() if v]}"
                )

                annotations_df = self._generate_metadata(
                    headers,
                    annotations,
                    delimiter,
                    metadata_save_path,
                    non_binary,
                    keep_tmp,
                    cached_data=cached_df,
                    sources_to_fetch=sources_to_fetch,
                )

            saved_files["metadata"] = metadata_save_path
        else:
            annotations_df = self._generate_metadata(
                headers,
                annotations,
                delimiter,
                metadata_save_path,
                non_binary,
                keep_tmp,
            )
            if metadata_save_path:
                saved_files["metadata"] = metadata_save_path

        return annotations_df, data, headers, saved_files

    def _search_and_download_fasta(
        self,
        query: str,
        save_to: Path = None,
    ) -> tuple[list[str], Path]:
        logger.info(f"Searching UniProt for query: '{query}'")

        base_url = "https://rest.uniprot.org/uniprotkb/stream"
        params = {"compressed": "true", "format": "fasta", "query": query}

        try:
            response = requests.get(base_url, params=params, stream=True)
            response.raise_for_status()

            # Download to temporary compressed file first
            temp_file = tempfile.NamedTemporaryFile(
                mode="wb", suffix=".fasta.gz", delete=False
            )
            temp_gz_file = Path(temp_file.name)

            # Download compressed FASTA to temp file
            total_size = int(response.headers.get("content-length", 0))
            with tqdm(
                total=total_size, unit="B", unit_scale=True, desc="Downloading FASTA"
            ) as pbar:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        temp_file.write(chunk)
                        pbar.update(len(chunk))

            temp_file.close()

            # Extract identifiers from compressed FASTA file
            identifiers = self._extract_identifiers_from_fasta(str(temp_gz_file))

            # Always extract the FASTA file for processing
            if save_to:
                # Extract to the user-specified location
                extracted_fasta_path = save_to
                # Create directory if it doesn't exist
                extracted_fasta_path.parent.mkdir(parents=True, exist_ok=True)
                logger.info(f"Extracting FASTA to: {save_to}")
            else:
                # Extract to a temporary file
                extracted_fasta_path = temp_gz_file.with_suffix("")
                logger.info(
                    f"Extracting FASTA to temporary file: {extracted_fasta_path}"
                )

            with gzip.open(temp_gz_file, "rt") as gz_file:
                content = gz_file.read()
                with open(extracted_fasta_path, "w") as output_file:
                    output_file.write(content)

            # Clean up the compressed file since we don't need it anymore
            temp_gz_file.unlink(missing_ok=True)

            logger.info(f"Downloaded and extracted {len(identifiers)} sequences")

            return identifiers, extracted_fasta_path

        except requests.RequestException as e:
            logger.error(f"Error downloading FASTA: {e}")
            raise
        except Exception as e:
            logger.error(f"Error processing FASTA: {e}")
            raise

    def _get_similarity_matrix(
        self, fasta_path: Path, headers: list[str]
    ) -> tuple[np.ndarray, list[str]]:
        """Generate similarity matrix using pymmseqs from extracted FASTA file."""
        n_seqs = len(headers)
        input_fasta = str(fasta_path.absolute())

        # Generate similarity matrix using pymmseqs
        logger.info("Generating similarity matrix using pymmseqs...")

        # Create temporary directory for pymmseqs output files
        temp_mmseqs_dir = str(
            Path(tempfile.mkdtemp(prefix="protspace_pymmseqs_")).absolute()
        )
        temp_alignment_file = str(Path(temp_mmseqs_dir) / "output.tsv")

        try:
            df = easy_search(
                query_fasta=input_fasta,
                target_fasta_or_db=input_fasta,
                alignment_file=temp_alignment_file,
                tmp_dir=temp_mmseqs_dir,
                max_seqs=n_seqs * n_seqs,
                e=1000000,
                s=8,
            ).to_pandas()

            similarity_matrix = np.zeros((n_seqs, n_seqs))

            # Create header to index mapping
            header_to_idx = {header: idx for idx, header in enumerate(headers)}

            # Fill the similarity matrix with bit scores
            for _, row in df.iterrows():
                target = row["target"]
                query = row["query"]
                fident = row["fident"]

                # Map headers to indices
                target_idx = header_to_idx.get(target)
                query_idx = header_to_idx.get(query)

                if target_idx is not None and query_idx is not None:
                    similarity_matrix[target_idx, query_idx] = fident
                    similarity_matrix[query_idx, target_idx] = fident

        finally:
            # Clean up temporary files and directories
            shutil.rmtree(temp_mmseqs_dir, ignore_errors=True)

        return similarity_matrix, headers

    def _save_similarity_matrix(
        self, similarity_matrix: np.ndarray, headers: list[str], save_path: Path
    ):
        """Save similarity matrix as CSV with headers as row/column names."""
        # Create directory if it doesn't exist
        save_path.parent.mkdir(parents=True, exist_ok=True)

        # Create DataFrame with headers as both index and columns
        df = pd.DataFrame(similarity_matrix, index=headers, columns=headers)
        df.to_csv(save_path)
        logger.info(f"Similarity matrix saved to: {save_path}")

    def _extract_identifiers_from_fasta(self, fasta_gz_path: str) -> list[str]:
        """Extract sequence identifiers from compressed FASTA file."""
        identifiers = []

        with gzip.open(fasta_gz_path, "rt") as f:
            for line in f:
                if line.startswith(">"):
                    # Extract UniProt accession from FASTA header
                    # Format: >sp|P01308|INS_HUMAN or >tr|A0A0A0MRZ7|A0A0A0MRZ7_HUMAN
                    header = line.strip()
                    if "|" in header:
                        parts = header.split("|")
                        if len(parts) >= 2:
                            accession = parts[1]
                            identifiers.append(accession)
                    else:
                        # Fallback: use first word after >
                        accession = header[1:].split()[0]
                        identifiers.append(accession)

        return identifiers

    def _extract_identifiers_from_fasta_file(self, fasta_path: Path) -> list[str]:
        """Extract sequence identifiers from uncompressed FASTA file."""
        identifiers = []

        with open(fasta_path) as f:
            for line in f:
                if line.startswith(">"):
                    # Extract UniProt accession from FASTA header
                    # Format: >sp|P01308|INS_HUMAN or >tr|A0A0A0MRZ7|A0A0A0MRZ7_HUMAN
                    header = line.strip()
                    if "|" in header:
                        parts = header.split("|")
                        if len(parts) >= 2:
                            accession = parts[1]
                            identifiers.append(accession)
                    else:
                        # Fallback: use first word after >
                        accession = header[1:].split()[0]
                        identifiers.append(accession)

        return identifiers

    def _generate_metadata(
        self,
        headers: list[str],
        annotations: str,
        delimiter: str,
        metadata_save_path: Path = None,
        non_binary: bool = False,
        keep_tmp: bool = False,
        cached_data: pd.DataFrame = None,
        sources_to_fetch: dict = None,
    ) -> pd.DataFrame:
        """Generate metadata and return DataFrame.

        Args:
            headers: Protein identifiers
            annotations: Annotation spec string
            delimiter: CSV delimiter
            metadata_save_path: Path to save parquet cache
            non_binary: Whether to use non-binary output format
            keep_tmp: Whether to keep temporary files
            cached_data: Previously cached DataFrame (for incremental fetching)
            sources_to_fetch: Dict indicating which sources to fetch
        """
        try:
            if annotations and annotations.endswith(".csv"):
                logger.info(f"Using delimiter: {repr(delimiter)} to read metadata")
                annotations_df = pd.read_csv(
                    annotations, delimiter=delimiter
                ).convert_dtypes()
            else:
                if annotations:
                    annotations_list = [
                        annotation.strip() for annotation in annotations.split(",")
                    ]
                    from protspace.data.annotations.configuration import (
                        AnnotationConfiguration,
                    )

                    annotations_list = AnnotationConfiguration(
                        annotations_list
                    ).user_annotations
                else:
                    annotations_list = (
                        None  # No specific annotations requested, use all
                    )

                # Create directory only if metadata_save_path is provided
                if metadata_save_path:
                    metadata_save_path.parent.mkdir(parents=True, exist_ok=True)

                manager_kwargs = {
                    "headers": headers,
                    "annotations": annotations_list,
                    "output_path": metadata_save_path,
                    "non_binary": False if metadata_save_path else non_binary,
                }
                if cached_data is not None:
                    manager_kwargs["cached_data"] = cached_data
                if sources_to_fetch is not None:
                    manager_kwargs["sources_to_fetch"] = sources_to_fetch

                annotations_df = ProteinAnnotationManager(
                    **manager_kwargs,
                ).to_pd()

                if keep_tmp and metadata_save_path:
                    logger.info(f"Metadata file saved to: {metadata_save_path}")
                else:
                    if metadata_save_path and metadata_save_path.exists():
                        metadata_save_path.unlink()
                        logger.debug(
                            f"Temporary metadata file deleted: {metadata_save_path}"
                        )

        except Exception as e:
            logger.warning(
                f"Could not generate metadata ({str(e)}) - creating empty metadata"
            )
            annotations_df = pd.DataFrame(columns=["identifier"])

        # Create full metadata with NaN for missing entries
        full_metadata = pd.DataFrame({"identifier": headers})
        if len(annotations_df.columns) > 1:
            annotations_df = annotations_df.astype(str)
            full_metadata = full_metadata.merge(
                annotations_df.drop_duplicates("identifier"),
                on="identifier",
                how="left",
            )

        return full_metadata
