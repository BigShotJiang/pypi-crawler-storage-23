import json
from pathlib import Path
from typing import Any

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq


class ArrowReader:
    """A class to read and manipulate Arrow data for ProtSpace."""

    def __init__(self, arrow_data_path: Path):
        """
        Initialize with path to directory containing Arrow/Parquet files.

        Args:
            arrow_data_path: Path to directory containing the .parquet files
        """
        self.data_path = Path(arrow_data_path)
        self._protein_annotations_df = None
        self._projections_metadata_df = None
        self._projections_data_df = None
        # Initialize data structure to match JsonReader format
        self.data = {
            "protein_data": {},
            "projections": [],
            "visualization_state": {"annotation_colors": {}, "marker_shapes": {}},
        }
        self._load_data()
        self._build_data_structure()

    def _load_data(self):
        """Load data from Parquet files."""
        try:
            protein_annotations_path = self.data_path / "selected_annotations.parquet"
            projections_metadata_path = self.data_path / "projections_metadata.parquet"
            projections_data_path = self.data_path / "projections_data.parquet"

            if protein_annotations_path.exists():
                self._protein_annotations_df = pq.read_table(
                    str(protein_annotations_path)
                ).to_pandas()
            else:
                self._protein_annotations_df = pd.DataFrame(columns=["protein_id"])

            if projections_metadata_path.exists():
                self._projections_metadata_df = pq.read_table(
                    str(projections_metadata_path)
                ).to_pandas()
            else:
                self._projections_metadata_df = pd.DataFrame(
                    columns=["projection_name", "dimensions", "info_json"]
                )

            if projections_data_path.exists():
                self._projections_data_df = pq.read_table(
                    str(projections_data_path)
                ).to_pandas()
            else:
                self._projections_data_df = pd.DataFrame(
                    columns=["projection_name", "identifier", "x", "y", "z"]
                )

        except Exception as e:
            raise ValueError(
                f"Error loading Arrow data from {self.data_path}: {e}"
            ) from e

    def _build_data_structure(self):
        """Build the data structure to match JsonReader format."""
        # Build protein_data
        for _, row in self._protein_annotations_df.iterrows():
            protein_id = row["protein_id"]
            annotations = {}
            for col in self._protein_annotations_df.columns:
                if col != "protein_id":
                    annotations[col] = row[col]
            self.data["protein_data"][protein_id] = {"annotations": annotations}

        # Build projections
        self.data["projections"] = []
        for projection_name in self._projections_metadata_df[
            "projection_name"
        ].unique():
            proj_meta = self._projections_metadata_df[
                self._projections_metadata_df["projection_name"] == projection_name
            ].iloc[0]

            proj_data = self._projections_data_df[
                self._projections_data_df["projection_name"] == projection_name
            ]

            projection = {
                "name": projection_name,
                "dimensions": proj_meta["dimensions"],
                "info": {},
                "data": [],
            }

            # Add info if available
            if pd.notna(proj_meta["info_json"]):
                try:
                    projection["info"] = json.loads(proj_meta["info_json"])
                except json.JSONDecodeError:
                    pass

            # Add projection data
            for _, row in proj_data.iterrows():
                coordinates = {"x": row["x"], "y": row["y"]}
                if pd.notna(row["z"]):
                    coordinates["z"] = row["z"]

                projection["data"].append(
                    {"identifier": row["identifier"], "coordinates": coordinates}
                )

            self.data["projections"].append(projection)

        # Load visualization state from separate JSON file if it exists
        self._load_visualization_state()

    def _load_visualization_state(self):
        """Load visualization state.

        Priority: visualization_state.json > settings.parquet (from bundle).
        """
        viz_state_path = self.data_path / "visualization_state.json"
        if viz_state_path.exists():
            try:
                with open(viz_state_path) as f:
                    viz_state = json.load(f)
                    self.data["visualization_state"] = viz_state
                    return
            except (json.JSONDecodeError, FileNotFoundError):
                pass

        # Fall back to settings.parquet (extracted from a 4-part bundle)
        settings_path = self.data_path / "settings.parquet"
        if settings_path.exists():
            try:
                from protspace.data.io.bundle import read_settings_from_file
                from protspace.data.io.settings_converter import (
                    settings_to_visualization_state,
                )

                settings = read_settings_from_file(settings_path)
                self.data["visualization_state"] = settings_to_visualization_state(
                    settings
                )
            except Exception:
                pass

    def save_data(self, output_path: Path = None):
        """Save the current data back to parquet files."""
        if output_path is None:
            output_path = self.data_path
        else:
            output_path = Path(output_path)

        output_path.mkdir(parents=True, exist_ok=True)

        # Save protein annotations
        protein_annotations_path = output_path / "protein_annotations.parquet"
        protein_annotations_table = pa.Table.from_pandas(self._protein_annotations_df)
        pq.write_table(protein_annotations_table, str(protein_annotations_path))

        # Save projections metadata
        projections_metadata_path = output_path / "projections_metadata.parquet"
        projections_metadata_table = pa.Table.from_pandas(self._projections_metadata_df)
        pq.write_table(projections_metadata_table, str(projections_metadata_path))

        # Save projections data
        projections_data_path = output_path / "projections_data.parquet"
        projections_data_table = pa.Table.from_pandas(self._projections_data_df)
        pq.write_table(projections_data_table, str(projections_data_path))

        # Save visualization state as a separate JSON file
        viz_state_path = output_path / "visualization_state.json"
        with open(viz_state_path, "w") as f:
            json.dump(self.data.get("visualization_state", {}), f, indent=2)

    def get_projection_names(self) -> list[str]:
        """Get list of projection names."""
        return [proj["name"] for proj in self.data.get("projections", [])]

    def get_all_annotations(self) -> list[str]:
        """Get list of all annotation names."""
        annotations = set()
        for protein_data in self.data.get("protein_data", {}).values():
            annotations.update(protein_data.get("annotations", {}).keys())
        return list(annotations)

    def get_protein_ids(self) -> list[str]:
        """Get list of all protein IDs."""
        return list(self.data.get("protein_data", {}).keys())

    def get_projection_data(self, projection_name: str) -> list[dict[str, Any]]:
        """Get projection data in the same format as JsonReader."""
        for proj in self.data.get("projections", []):
            if proj["name"] == projection_name:
                return proj.get("data", [])
        raise ValueError(f"Projection {projection_name} not found")

    def get_projection_info(self, projection_name: str) -> dict[str, Any]:
        """Get projection info in the same format as JsonReader."""
        for proj in self.data.get("projections", []):
            if proj["name"] == projection_name:
                result = {"dimensions": proj.get("dimensions")}
                if "info" in proj:
                    result["info"] = proj["info"]
                return result
        raise ValueError(f"Projection {projection_name} not found")

    def get_protein_annotations(self, protein_id: str) -> dict[str, Any]:
        """Get protein annotations in the same format as JsonReader."""
        return (
            self.data.get("protein_data", {}).get(protein_id, {}).get("annotations", {})
        )

    def get_annotation_colors(self, annotation: str) -> dict[str, str]:
        """Get annotation colors from visualization state."""
        return (
            self.data.get("visualization_state", {})
            .get("annotation_colors", {})
            .get(annotation, {})
        )

    def get_marker_shape(self, annotation: str) -> dict[str, str]:
        """Get marker shapes from visualization state."""
        return (
            self.data.get("visualization_state", {})
            .get("marker_shapes", {})
            .get(annotation, {})
        )

    def get_unique_annotation_values(self, annotation: str) -> list[Any]:
        """Get a list of unique values for a given annotation."""
        unique_values = set()
        for protein_data in self.data.get("protein_data", {}).values():
            value = protein_data.get("annotations", {}).get(annotation)
            if value is not None:
                unique_values.add(value)
        return list(unique_values)

    def get_all_annotation_values(self, annotation: str) -> list[Any]:
        """Get a list of all values for a given annotation."""
        all_values = []
        protein_ids = self.get_protein_ids()
        for protein_id in protein_ids:
            all_values.append(
                self.get_protein_annotations(protein_id).get(annotation, None)
            )
        return all_values

    def update_annotation_color(self, annotation: str, value: str, color: str):
        """Update annotation color in visualization state."""
        if "visualization_state" not in self.data:
            self.data["visualization_state"] = {}
        if "annotation_colors" not in self.data["visualization_state"]:
            self.data["visualization_state"]["annotation_colors"] = {}
        if annotation not in self.data["visualization_state"]["annotation_colors"]:
            self.data["visualization_state"]["annotation_colors"][annotation] = {}

        self.data["visualization_state"]["annotation_colors"][annotation][value] = color

    def update_marker_shape(self, annotation: str, value: str, shape: str):
        """Update marker shape in visualization state."""
        if "visualization_state" not in self.data:
            self.data["visualization_state"] = {}
        if "marker_shapes" not in self.data["visualization_state"]:
            self.data["visualization_state"]["marker_shapes"] = {}
        if annotation not in self.data["visualization_state"]["marker_shapes"]:
            self.data["visualization_state"]["marker_shapes"][annotation] = {}

        self.data["visualization_state"]["marker_shapes"][annotation][value] = shape

    def get_data(self) -> dict[str, Any]:
        """Return the current data."""
        return self.data
