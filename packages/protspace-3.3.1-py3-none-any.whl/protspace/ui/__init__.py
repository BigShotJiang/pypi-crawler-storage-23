"""UI components for ProtSpace."""

from . import styles

__all__ = ["styles"]
