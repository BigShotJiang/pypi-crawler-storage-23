# GANA PLAYER 🎧

A production-ready, cyberpunk-styled CLI music player for Linux and Termux.

## Features
- 🌌 **3D Hyperdrive UI**: Visuals that react to playback state.
- 🧠 **AI Recommendations**: Smart suggestions based on your listening history.
- 📡 **Offline Caching**: Automatically saves songs for offline play.
- 📱 **Android Integration**: Lock screen controls and Bluetooth earbud support.

## Requirements
You must have `mpv` and `ffmpeg` installed on your system.

**Termux:**
```bash
pkg install mpv ffmpeg python
