"""mutbot.copilot — GitHub Copilot 扩展模块。"""
