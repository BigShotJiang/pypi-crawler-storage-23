# serverless.com repo "python -m build" works without setup.py
# Should update package_dir if not using our recommended directory structure

import setuptools

# TODO: Change the PACKAGE_NAME to the package's name - Either xxx-local or
#  xxx-remote (without the -python-package suffix). Only lowercase, no
#  underlines.
# Used by pypa/gh-action-pypi-publish
# Package Name should be identical to the inner directory name
# Changing the package name here, will cause a change in the package directory
#  name as well

# PACKAGE_NAME should be singular if handling only one instance
# PACKAGE_NAME should not include the word "main"

# e.g.: queue-local, without python-package suffix
PACKAGE_NAME = "translate-remote"

package_dir = PACKAGE_NAME.replace("-", "_")
# If we need backward-compatible:
# old_package_dir = "old_package_name"

PACKAGE_DESCRIPTION = f"PyPI {PACKAGE_NAME} Python Package owned by Circlez.ai"

setuptools.setup(
    name=PACKAGE_NAME,
    # Increase this number every time you make a change you
    #  want to publish. After 0.0.9 switch to 0.0.10 and not 0.1.0
    #blah
    # version can't be 0.0.
    # If you find yourself increasing the version in more than one patch number (it might indicate there are multiple branches which you should submit their PRs before your PR)  # noqa: E501
    # TODO add the Jira Work Item (Jira Issue) number after the version i.e., 0.0.1b2432
    # TODO Add b2870 Make sure PythonVersionFile.psm1 and makec supports it
    version='0.0.4b2870',  # https://pypi.org/project/translate-remote/
    author="Circles",
    author_email="info@circlez.ai",
    description="PyPI package for circles translation",
    # long_description=f"{description}",
    long_description ="PyPI package for circles translation"  # noqa E501
            + "JIRA Work Item: https://circles-zone.atlassian.net/browse/BU-2614"  # noqa E501
            + "GHA: https://github.com/circles-zone/logger-local-python-package/actions",  # noqa E501

    long_description_content_type='text/markdown',
    url=f"https://github.com/circles-zone/{PACKAGE_NAME}-python-package",
    packages=[package_dir],
    # packages=[package_dir, old_package_dir],
    #packages=setuptools.find_packages(),

    # I'm not sure we need package_dir
    package_dir={package_dir: f'{package_dir}/src'},
    # TODO Unfortunately in event-main-local-restapi there are no
    #  repo-directory and no package directory (flat directory structure)
    # package_dir={package_dir: f'src'},

    # package_dir={package_dir: f'{package_dir}/src',
    #  old_package_dir: f'{package_dir}/src'},
    package_data={package_dir: ['*.py']},
    classifiers=[
        "Programming Language :: Python :: 3",
        # https://packaging.python.org/en/latest/guides/writing-pyproject-toml/#license
        # TODO Fix all repos, especially the Python templates
        # "License :: MIT AND (Apache-2.0 OR BSD-2-Clause)",
        "Operating System :: OS Independent",
    ],
    # Do not add packages needed only for tests i.e. packages for get_test_xxx(
    # TODO: Update which packages to include with this package in production
    #  (dependencies) - Not for development/testing
    install_requires=[
        'python-sdk-remote',
        'translate',
        # TODO: in -remote package, please use logger-remote instead.
        'logger-local',
        # TODO: In -local package please uncomment the bellow line. In -remote packages please delete this line.  # noqa E501
        # 'smart-datastore-local',
        # 'logzio-python-handler>=4.1.2',  # https://pypi.org/project/logzio-python-handler/  # noqa E501
    ]
)
