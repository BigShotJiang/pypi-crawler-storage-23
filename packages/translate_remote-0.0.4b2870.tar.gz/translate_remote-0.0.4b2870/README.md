# General

Unlike the README.md in the root directory, this is a README.md of this specific repo/package<br>

TODO Please update this README.md of this specific repo/package and not the README.md in the root directory based on the python-package-template repo<br>

## TODOs

TODO example of a TODO, please it with a real TODO<br>

## Versions

[pub] 0.0.1 Initial version (change the directories, files, setup.py, .github/workflows/*.yml)<br>

## Installing instructions

It's advised to use venv<br>
If you have Windows, it's also advised to use Windows Subsystem for Linux<br>

## Install dependencies

Run ./download-beta-sdk.sh from the bash terminal<br>
Run pip install -r requirements.txt from the bash terminal<br>
