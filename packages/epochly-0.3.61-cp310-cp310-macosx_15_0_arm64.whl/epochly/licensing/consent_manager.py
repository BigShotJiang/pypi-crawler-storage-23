"""
Epochly Consent Manager.

Orchestration layer between TermsAcceptanceClient (low-level API client) and
the rest of Epochly. Provides:
  - check_consent_required: which terms need acceptance
  - is_fully_consented: quick boolean check
  - record_consent_for_all / record_consent: accept outstanding terms
  - get_consent_summary: detailed per-document status
  - withdraw_all_consent: withdraw all terms
  - consent_gate: enforcement check that raises ConsentRequiredError
  - check_reaccept_needed: terms needing re-acceptance after version change

All actual API communication is delegated to TermsAcceptanceClient.
"""

import logging
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from epochly.licensing.terms_acceptance import (
    VALID_TERMS_NAMES,
    TermsAcceptanceClient,
)

logger = logging.getLogger(__name__)


# ============================================================================
# Exceptions
# ============================================================================


class ConsentRequiredError(Exception):
    """Raised when an operation requires terms consent that has not been given.

    Attributes:
        operation: The operation that was blocked.
        outstanding_terms: List of terms names still needing acceptance.
    """

    def __init__(
        self,
        operation: str,
        outstanding_terms: List[str],
        message: Optional[str] = None,
    ):
        self.operation = operation
        self.outstanding_terms = outstanding_terms
        if message is None:
            terms_str = ", ".join(sorted(outstanding_terms))
            message = (
                f"Operation '{operation}' requires acceptance of the following "
                f"terms: {terms_str}. Please accept them before proceeding."
            )
        super().__init__(message)


# ============================================================================
# ConsentManager
# ============================================================================


class ConsentManager:
    """
    High-level orchestrator for Epochly terms consent.

    Wraps a TermsAcceptanceClient and provides enforcement, summary,
    and bulk-operation methods used by the CLI, licensing, and trial systems.
    """

    def __init__(
        self,
        terms_client: Optional[TermsAcceptanceClient] = None,
    ):
        """
        Initialise the consent manager.

        Args:
            terms_client: Optional pre-configured client. If *None*, a default
                          client is created using :func:`_default_cache_dir`.
        """
        if terms_client is not None:
            self.terms_client = terms_client
        else:
            self.terms_client = TermsAcceptanceClient(
                cache_dir=_default_cache_dir(),
            )

    # ------------------------------------------------------------------
    # Query methods
    # ------------------------------------------------------------------

    def check_consent_required(self) -> List[str]:
        """
        Return the list of terms names that still need acceptance.

        A term needs acceptance if it has not been accepted or if
        ``needs_reaccept`` is True (version changed).

        Returns:
            List of terms_name strings needing acceptance (empty if all OK).
        """
        needed: List[str] = []
        results = self.terms_client.check_all()
        for name, status in results.items():
            if not status.get("accepted") or status.get("needs_reaccept"):
                needed.append(name)
        return sorted(needed)

    def is_fully_consented(self) -> bool:
        """
        Check if all terms documents are accepted and current.

        Returns:
            True if every term is accepted with the current version.
        """
        return len(self.check_consent_required()) == 0

    def get_consent_summary(self) -> Dict[str, Any]:
        """
        Return a detailed summary of consent status for every terms document.

        Returns:
            Dict containing per-document status plus aggregate fields:
            - ``fully_consented`` (bool): all terms accepted and current
            - ``outstanding`` (list[str]): terms needing acceptance
            - One key per terms_name with its API status dict
        """
        results = self.terms_client.check_all()
        outstanding: List[str] = []
        for name, status in results.items():
            if not status.get("accepted") or status.get("needs_reaccept"):
                outstanding.append(name)

        summary: Dict[str, Any] = {}
        for name in sorted(VALID_TERMS_NAMES):
            summary[name] = results.get(name, {"accepted": False})
        summary["fully_consented"] = len(outstanding) == 0
        summary["outstanding"] = sorted(outstanding)
        return summary

    def check_reaccept_needed(self) -> List[Dict[str, Any]]:
        """
        Return terms that were accepted but need re-acceptance (version changed).

        Terms that were *never* accepted are NOT included here — they belong
        in :meth:`check_consent_required` instead.

        Returns:
            List of dicts with ``terms_name``, ``accepted_version``,
            ``current_version`` for each outdated acceptance.
        """
        reaccept: List[Dict[str, Any]] = []
        results = self.terms_client.check_all()
        for name, status in results.items():
            if (
                status.get("accepted")
                and status.get("needs_reaccept")
            ):
                reaccept.append(
                    {
                        "terms_name": name,
                        "accepted_version": status.get("accepted_version", ""),
                        "current_version": status.get("current_version", ""),
                    }
                )
        return reaccept

    # ------------------------------------------------------------------
    # Mutation methods
    # ------------------------------------------------------------------

    def record_consent_for_all(
        self,
        method: str,
        email: Optional[str] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Record acceptance for *all* terms documents.

        Args:
            method: Acceptance method (e.g. ``'cli_prompt'``).
            email: Optional user email.

        Returns:
            Dict mapping terms_name to API acceptance result.
        """
        return self.terms_client.accept_all(method=method, email=email)

    def record_consent(
        self,
        terms_names: Sequence[str],
        method: str,
        email: Optional[str] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Record acceptance for specific terms documents.

        Args:
            terms_names: List of terms_name strings to accept.
            method: Acceptance method.
            email: Optional user email.

        Returns:
            Dict mapping terms_name to API acceptance result.
        """
        results: Dict[str, Dict[str, Any]] = {}
        for name in terms_names:
            results[name] = self.terms_client.accept(
                name, method=method, email=email
            )
        return results

    def withdraw_all_consent(
        self, email: Optional[str] = None
    ) -> Dict[str, Dict[str, Any]]:
        """
        Withdraw consent for all terms documents.

        Args:
            email: Optional email for EMAIL# record update.

        Returns:
            Dict mapping terms_name to API withdrawal result.
        """
        results: Dict[str, Dict[str, Any]] = {}
        for name in sorted(VALID_TERMS_NAMES):
            results[name] = self.terms_client.withdraw(name, email=email)
        return results

    # ------------------------------------------------------------------
    # Enforcement
    # ------------------------------------------------------------------

    def consent_gate(self, operation: str) -> None:
        """
        Enforce consent requirement for a named operation.

        Call this before operations that legally require consent (trial
        activation, license activation, data collection, etc.).

        Args:
            operation: Human-readable operation name for error messages.

        Raises:
            ConsentRequiredError: If any terms have not been accepted.
        """
        outstanding = self.check_consent_required()
        if outstanding:
            raise ConsentRequiredError(
                operation=operation,
                outstanding_terms=outstanding,
            )


# ============================================================================
# Module-level convenience functions
# ============================================================================

_singleton_lock = threading.Lock()
_singleton_manager: Optional[ConsentManager] = None


def _default_cache_dir() -> str:
    """Return the default cache directory for consent management."""
    return str(Path.home() / ".epochly" / "cache" / "terms")


def get_consent_manager() -> ConsentManager:
    """
    Get or create the singleton ConsentManager.

    Thread-safe via double-checked locking.

    Returns:
        ConsentManager singleton.
    """
    global _singleton_manager
    if _singleton_manager is None:
        with _singleton_lock:
            if _singleton_manager is None:
                client = TermsAcceptanceClient(
                    cache_dir=_default_cache_dir(),
                )
                _singleton_manager = ConsentManager(terms_client=client)
    return _singleton_manager


def require_consent(operation: str) -> None:
    """
    Convenience function: enforce consent for a named operation.

    Creates a fresh ConsentManager per call so environment changes
    are respected.

    Args:
        operation: Operation name for error messages.

    Raises:
        ConsentRequiredError: If any terms are outstanding.
    """
    client = TermsAcceptanceClient(cache_dir=_default_cache_dir())
    manager = ConsentManager(terms_client=client)
    manager.consent_gate(operation)
