"""
Epochly Benchmark Runner.

Measurement engine that times workloads in two modes:
  1. Baseline: Epochly at Level 0 (monitoring only, no optimizations)
  2. Enhanced: Epochly at whatever level the user's license supports

Activation:
  - Uses epochly.set_level() to switch between modes
  - No environment variable overrides -- respects the user's license
  - If licensed for all cores + GPU, benchmarks at Level 4
  - If on community tier (4 cores, no GPU), benchmarks at that configuration
  - The output reports precisely what level, cores, and features are active

Statistical approach:
  - Configurable warmup iterations (excluded from measurements)
  - Multiple measurement iterations
  - Median aggregation (robust to outliers)
  - Speedup computed as baseline_median / enhanced_median
"""

import logging
import multiprocessing
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from epochly.gpu.gpu_detector import GPUDetector
from epochly.benchmark.workloads import WorkloadSpec, get_all_workloads

logger = logging.getLogger('epochly.benchmark')

LEVEL_NAMES = {
    0: 'Monitor Only',
    1: 'Threading',
    2: 'JIT Compilation',
    3: 'Full Optimization',
    4: 'GPU Acceleration',
}

# Timeout constants for benchmark initialization (seconds)
_BENCHMARK_SET_LEVEL_TIMEOUT = 45.0  # set_level(4) wait: 30s spawn + 15s buffer
_BENCHMARK_GET_LEVEL_TIMEOUT = 10.0  # get_level() wait after init


@dataclass
class EpochlyConfig:
    """Runtime configuration discovered from Epochly at benchmark time.

    Represents the actual state of the Epochly installation -- level,
    core count, GPU availability, and license tier.  No values are
    overridden or injected; everything is queried from the running system.
    """

    enabled: bool
    enhanced_level: int
    enhanced_level_name: str
    max_cores: Optional[int]
    gpu_enabled: bool
    tier: str


@dataclass
class BenchmarkResult:
    """Result from a single workload benchmark run."""

    workload_name: str
    display_name: str
    baseline_median: float
    enhanced_median: float
    speedup: float
    enhanced_level: int
    baseline_times: List[float] = field(default_factory=list)
    enhanced_times: List[float] = field(default_factory=list)
    error: Optional[str] = None


def compute_median(times: List[float]) -> float:
    """
    Compute the median of a list of timing values.

    Uses median (not mean) to be robust against outliers from GC pauses,
    OS scheduling, and other transient noise.
    """
    if not times:
        return 0.0
    sorted_times = sorted(times)
    n = len(sorted_times)
    mid = n // 2
    if n % 2 == 0:
        return (sorted_times[mid - 1] + sorted_times[mid]) / 2.0
    return sorted_times[mid]


def _query_epochly_config() -> EpochlyConfig:
    """Query the running Epochly instance for its actual configuration.

    Imports epochly normally (triggering auto_enable with lazy init),
    requests the highest level the license allows (set_level(4) falls
    back to Level 3 if GPU is unavailable, and the license enforcer
    caps at whatever tier the user has), then reads back the actual
    state.

    CRITICAL FIX (Feb 2026): Check EPOCHLY_DISABLE before attempting init,
    and wrap set_level in a timeout to prevent hanging in restricted
    environments where Level 3 ProcessPool creation blocks forever.

    Returns:
        EpochlyConfig with discovered runtime values.
    """
    # Check if Epochly is explicitly disabled
    if os.environ.get('EPOCHLY_DISABLE', '0') == '1':
        logger.info("Epochly is disabled via EPOCHLY_DISABLE=1")
        return EpochlyConfig(
            enabled=False,
            enhanced_level=0,
            enhanced_level_name='Disabled',
            max_cores=multiprocessing.cpu_count(),
            gpu_enabled=False,
            tier='disabled',
        )

    try:
        import epochly

        # Request the highest level with timeout to prevent hang
        # in restricted environments where Level 3 ProcessPool creation blocks.
        # Timeout = 45s: 30s spawn timeout + 15s buffer for license checks.
        init_done = threading.Event()
        init_error = [None]

        def _init_with_timeout():
            try:
                # Respect EPOCHLY_LEVEL env var to cap initialization level.
                # This prevents triggering Level 3 ProcessPool creation on platforms
                # where it hangs (e.g., aarch64 sandbox, restricted containers).
                # Without this, set_level(4) uses force=True which bypasses the
                # env var cap inside set_enhancement_level().
                env_level = os.environ.get('EPOCHLY_LEVEL')
                if env_level is not None:
                    try:
                        target_level = min(4, max(0, int(env_level)))
                    except (ValueError, TypeError):
                        target_level = 4
                else:
                    target_level = 4

                epochly.set_level(target_level)
            except Exception as e:
                init_error[0] = e
            finally:
                init_done.set()

        t = threading.Thread(target=_init_with_timeout, daemon=True)
        t.start()
        timed_out = not init_done.wait(timeout=_BENCHMARK_SET_LEVEL_TIMEOUT)
        if timed_out:
            logger.warning(
                "Epochly initialization timed out after 45s. "
                "Running benchmark at current level."
            )
        elif init_error[0]:
            logger.warning("Epochly set_level(4) raised: %s", init_error[0])

        # Wrap get_level in a timeout too - if Epochly init is stuck,
        # get_level() could also hang accessing internal state.
        level_result = [0]
        level_done = threading.Event()

        def _get_level():
            try:
                level_result[0] = epochly.get_level()
            except Exception:
                level_result[0] = 0
            finally:
                level_done.set()

        lt = threading.Thread(target=_get_level, daemon=True)
        lt.start()
        if not level_done.wait(timeout=_BENCHMARK_GET_LEVEL_TIMEOUT):
            logger.warning("epochly.get_level() timed out - returning degraded config")
            return EpochlyConfig(
                enabled=False,
                enhanced_level=0,
                enhanced_level_name='Disabled',
                max_cores=multiprocessing.cpu_count(),
                gpu_enabled=False,
                tier='timeout',
            )

        actual_level = level_result[0]

        # Query license info for reporting
        license_info: dict = {}
        try:
            license_info = epochly.get_license_info()
        except Exception as lic_exc:
            logger.debug("Could not query license info: %s", lic_exc)

        max_cores = license_info.get('max_cores')
        if max_cores is None:
            max_cores = multiprocessing.cpu_count()

        gpu_enabled = license_info.get('gpu_enabled', False)
        tier = license_info.get('tier', 'unknown')
        level_name = LEVEL_NAMES.get(actual_level, f'Level {actual_level}')

        return EpochlyConfig(
            enabled=True,
            enhanced_level=actual_level,
            enhanced_level_name=level_name,
            max_cores=max_cores,
            gpu_enabled=gpu_enabled,
            tier=tier,
        )

    except Exception as exc:
        logger.warning("Epochly initialization failed: %s", exc)
        return EpochlyConfig(
            enabled=False,
            enhanced_level=0,
            enhanced_level_name='Disabled',
            max_cores=multiprocessing.cpu_count(),
            gpu_enabled=False,
            tier='unavailable',
        )


class BenchmarkRunner:
    """
    Benchmark measurement engine.

    Runs each workload in baseline and enhanced modes, collecting timing
    data and computing speedup statistics.

    The runner uses Epochly exactly as an end user would -- no special
    environment variables, no license overrides, no security bypasses.

    Activation:
      Baseline (Level 0): Monitoring only, no optimizations.
      Enhanced: Whatever level the user's license and hardware support.

    The output reports the actual configuration so users know precisely
    what was measured.
    """

    BASELINE_LEVEL = 0

    def __init__(
        self,
        iterations: int = 10,
        warmup_iterations: int = 2,
    ) -> None:
        self.iterations = iterations
        self.warmup_iterations = warmup_iterations
        self._epochly_config: Optional[EpochlyConfig] = None

    def _ensure_epochly_ready(self) -> EpochlyConfig:
        """Initialize Epochly once and discover the runtime configuration.

        On first call, queries the running Epochly for its actual level,
        core count, GPU status, and license tier.  Subsequent calls return
        the cached configuration.
        """
        if self._epochly_config is not None:
            return self._epochly_config

        self._epochly_config = _query_epochly_config()
        if self._epochly_config.enabled:
            logger.info(
                "Epochly ready: Level %d (%s), %s cores, GPU %s, tier %s",
                self._epochly_config.enhanced_level,
                self._epochly_config.enhanced_level_name,
                self._epochly_config.max_cores or 'all',
                'enabled' if self._epochly_config.gpu_enabled else 'disabled',
                self._epochly_config.tier,
            )
        else:
            logger.warning("Epochly is not available -- benchmarks will run baseline only")

        return self._epochly_config

    def get_epochly_config(self) -> EpochlyConfig:
        """Return the discovered Epochly configuration.

        Initializes Epochly if not already done.
        """
        return self._ensure_epochly_ready()

    def get_applicable_workloads(self) -> Dict[str, WorkloadSpec]:
        """
        Return workloads applicable to the current system.

        GPU workloads are excluded when GPUDetector.is_available() is False.
        """
        all_workloads = get_all_workloads()

        gpu_available = False
        try:
            gpu_available = GPUDetector.is_available()
        except Exception:
            gpu_available = False

        if gpu_available:
            return all_workloads

        return {
            name: spec
            for name, spec in all_workloads.items()
            if spec.category != "gpu"
        }

    def run_single_workload(self, spec: WorkloadSpec) -> BenchmarkResult:
        """
        Run a single workload and return timing results.

        Executes the workload in two phases:
          1. Baseline: Epochly at Level 0 (monitoring only)
          2. Enhanced: Epochly at the user's licensed level

        Each phase includes warmup iterations (discarded) followed by
        measurement iterations (used for median computation).

        If the workload raises an exception, returns a BenchmarkResult
        with error information and zero timing values.
        """
        config = self._ensure_epochly_ready()
        try:
            return self._execute_workload(spec, config)
        except Exception as exc:
            return BenchmarkResult(
                workload_name=spec.code_name,
                display_name=spec.name,
                baseline_median=0.0,
                enhanced_median=0.0,
                speedup=0.0,
                enhanced_level=config.enhanced_level,
                baseline_times=[],
                enhanced_times=[],
                error=f"{type(exc).__name__}: {exc}",
            )

    def _execute_workload(
        self, spec: WorkloadSpec, config: EpochlyConfig
    ) -> BenchmarkResult:
        """Execute a workload in baseline (Level 0) and enhanced modes."""
        import epochly

        # Phase 1: Baseline -- Level 0 (monitoring only, no optimizations)
        epochly.set_level(self.BASELINE_LEVEL)
        baseline_times = self._time_iterations(spec)

        # Phase 2: Enhanced -- user's licensed level
        epochly.set_level(config.enhanced_level)
        enhanced_times = self._time_iterations(spec)

        # Restore to baseline level for next workload
        epochly.set_level(self.BASELINE_LEVEL)

        baseline_median = compute_median(baseline_times)
        enhanced_median = compute_median(enhanced_times)

        if enhanced_median > 0 and baseline_median > 0:
            speedup = baseline_median / enhanced_median
        else:
            speedup = 0.0

        return BenchmarkResult(
            workload_name=spec.code_name,
            display_name=spec.name,
            baseline_median=baseline_median,
            enhanced_median=enhanced_median,
            speedup=speedup,
            enhanced_level=config.enhanced_level,
            baseline_times=baseline_times,
            enhanced_times=enhanced_times,
        )

    def _time_iterations(self, spec: WorkloadSpec) -> List[float]:
        """
        Run warmup + measurement iterations and return measurement times.

        Times are in milliseconds.  The current Epochly level (set by the
        caller via epochly.set_level) determines whether optimizations
        are active during execution.
        """
        # Warmup iterations (discarded)
        for _ in range(self.warmup_iterations):
            spec.execute(spec.size)

        # Measurement iterations
        times: List[float] = []
        for _ in range(self.iterations):
            start = time.perf_counter()
            spec.execute(spec.size)
            elapsed_ms = (time.perf_counter() - start) * 1000.0
            times.append(elapsed_ms)

        return times
