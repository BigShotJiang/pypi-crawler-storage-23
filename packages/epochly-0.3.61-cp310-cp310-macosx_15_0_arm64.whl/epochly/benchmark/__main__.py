"""
Epochly Benchmark CLI.

Entry point for `python -m epochly.benchmark`.

Usage:
    python -m epochly.benchmark              # Run default suite (10 iterations)
    python -m epochly.benchmark --quick      # Quick validation (3 iterations)
    python -m epochly.benchmark --json       # JSON output
    python -m epochly.benchmark --list       # List available workloads
    python -m epochly.benchmark --workload NAME  # Run specific workload
    python -m epochly.benchmark --full       # Full suite with extended iterations
    python -m epochly.benchmark --iterations N   # Custom iteration count
"""

import argparse
import json
import sys
from typing import List

from epochly.benchmark.runner import BenchmarkResult, BenchmarkRunner, EpochlyConfig
from epochly.benchmark.system_info import collect_system_info, format_system_line
from epochly.benchmark.workloads import get_all_workloads


def parse_args(argv: List[str]) -> argparse.Namespace:
    """Parse CLI arguments for the benchmark module."""
    parser = argparse.ArgumentParser(
        prog="epochly.benchmark",
        description="Epochly Performance Benchmark Suite",
    )

    parser.add_argument(
        "--quick",
        action="store_true",
        default=False,
        help="Quick validation mode (3 iterations, 1 warmup)",
    )
    parser.add_argument(
        "--workload",
        type=str,
        default=None,
        help="Run a specific workload by code name",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        default=False,
        help="List all available workloads and exit",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Output results in JSON format",
    )
    parser.add_argument(
        "--full",
        action="store_true",
        default=False,
        help="Full benchmark suite with extended iterations",
    )
    parser.add_argument(
        "--iterations",
        type=int,
        default=10,
        help="Number of measurement iterations per workload (default: 10)",
    )

    return parser.parse_args(argv)


def format_workload_progress(
    result: BenchmarkResult, index: int, total: int
) -> str:
    """
    Format a single workload result as a progress line.

    Example:
      [1/4] JIT Polynomial Evaluation
            Baseline: 845.20ms | Enhanced: 4.40ms | Speedup: 192.1x
    """
    lines = [
        f"  [{index}/{total}] {result.display_name}",
    ]
    if result.error:
        lines.append(f"         ERROR: {result.error}")
    else:
        lines.append(
            f"         Baseline: {result.baseline_median:.2f}ms | "
            f"Enhanced: {result.enhanced_median:.2f}ms | "
            f"Speedup: {result.speedup:.1f}x"
        )
    return "\n".join(lines)


def format_summary_table(
    results: List[BenchmarkResult], config: EpochlyConfig
) -> str:
    """
    Format results as a summary table with configuration context.

    Example:
      ========== Summary ==========
      Enhanced mode: Level 3 (Full Optimization) | 8 cores | GPU disabled | tier: professional

      Workload                       Baseline    Enhanced    Speedup
      ---------------------------------------------------------------
      JIT Polynomial Evaluation      845.20ms      4.40ms    192.1x
      JIT Numerical Loop             612.10ms      7.00ms     87.4x
      ---------------------------------------------------------------
    """
    header = "=" * 10 + " Summary " + "=" * 10
    config_line = f"  Enhanced mode: {format_config_line(config)}"
    col_header = (
        f"  {'Workload':<32} {'Baseline':>10} {'Enhanced':>10} {'Speedup':>10}"
    )
    separator = "  " + "-" * 64

    rows = []
    for r in results:
        if r.error:
            rows.append(f"  {r.display_name:<32} {'ERROR':>10} {'':>10} {'':>10}")
        else:
            rows.append(
                f"  {r.display_name:<32} "
                f"{r.baseline_median:>8.2f}ms "
                f"{r.enhanced_median:>8.2f}ms "
                f"{r.speedup:>9.1f}x"
            )

    parts = [header, config_line, "", col_header, separator]
    parts.extend(rows)
    parts.append(separator)
    return "\n".join(parts)


def format_json_output(
    results: List[BenchmarkResult], config: EpochlyConfig
) -> str:
    """
    Format results as a JSON string.

    Schema:
    {
        "results": [
            {
                "workload_name": "jit_polynomial",
                "display_name": "JIT Polynomial Evaluation",
                "baseline_median_ms": 845.2,
                "enhanced_median_ms": 4.4,
                "speedup": 192.1,
                "enhanced_level": 3,
                "baseline_times_ms": [...],
                "enhanced_times_ms": [...],
                "error": null
            }
        ],
        "epochly_config": {
            "enabled": true,
            "enhanced_level": 3,
            "enhanced_level_name": "Full Optimization",
            "max_cores": 8,
            "gpu_enabled": false,
            "tier": "professional"
        },
        "system": {
            "cpu_model": "...",
            "cpu_cores": 8,
            ...
        }
    }
    """
    result_dicts = []
    for r in results:
        result_dicts.append({
            "workload_name": r.workload_name,
            "display_name": r.display_name,
            "baseline_median_ms": r.baseline_median,
            "enhanced_median_ms": r.enhanced_median,
            "speedup": r.speedup,
            "enhanced_level": r.enhanced_level,
            "baseline_times_ms": r.baseline_times,
            "enhanced_times_ms": r.enhanced_times,
            "error": r.error,
        })

    output = {
        "results": result_dicts,
        "epochly_config": {
            "enabled": config.enabled,
            "enhanced_level": config.enhanced_level,
            "enhanced_level_name": config.enhanced_level_name,
            "max_cores": config.max_cores,
            "gpu_enabled": config.gpu_enabled,
            "tier": config.tier,
        },
        "system": collect_system_info(),
    }

    return json.dumps(output, indent=2)


def format_config_line(config: EpochlyConfig) -> str:
    """
    Format a one-line summary of the Epochly runtime configuration.

    Example:
      "Level 3 (Full Optimization) | 8 cores | GPU disabled | tier: professional"
    """
    gpu_part = "GPU enabled" if config.gpu_enabled else "GPU disabled"
    cores_part = f"{config.max_cores} cores" if config.max_cores else "all cores"
    return (
        f"Level {config.enhanced_level} ({config.enhanced_level_name}) | "
        f"{cores_part} | {gpu_part} | tier: {config.tier}"
    )


def format_header(config: EpochlyConfig) -> str:
    """
    Format the benchmark header with version, system info, and Epochly config.

    Example:
      ==================================================
        Epochly Benchmark Suite
      ==================================================
        System: Python 3.12.1 | Epochly 0.5.0 | 8 cores | Apple M2 Pro | No GPU
        Config: Level 3 (Full Optimization) | 8 cores | GPU disabled | tier: professional
      ==================================================
    """
    divider = "=" * 50
    system_line = format_system_line()
    config_line = format_config_line(config)
    return "\n".join([
        divider,
        "  Epochly Benchmark Suite",
        divider,
        f"  System: {system_line}",
        f"  Config: {config_line}",
        divider,
    ])


def _list_workloads() -> None:
    """Print available workloads and exit."""
    workloads = get_all_workloads()
    print("\nAvailable workloads:\n")
    for code_name, spec in sorted(workloads.items()):
        speedup_lo, speedup_hi = spec.expected_speedup_range
        print(
            f"  {code_name:<20} {spec.name:<35} "
            f"[{spec.category}] "
            f"({speedup_lo:.0f}-{speedup_hi:.0f}x expected)"
        )
    print(f"\n  Total: {len(workloads)} workloads\n")


def main(argv: List[str] = None) -> int:
    """Main entry point for the benchmark CLI."""
    if argv is None:
        argv = sys.argv[1:]

    args = parse_args(argv)

    if args.list:
        _list_workloads()
        return 0

    if args.iterations < 1:
        print("Error: --iterations must be a positive integer (got "
              f"{args.iterations}).")
        return 1

    # Determine iteration count
    iterations = args.iterations
    warmup = 2
    if args.quick:
        iterations = 3
        warmup = 1
    elif args.full:
        iterations = 25
        warmup = 5

    runner = BenchmarkRunner(iterations=iterations, warmup_iterations=warmup)

    # Initialize Epochly and discover runtime configuration
    config = runner.get_epochly_config()

    # Determine which workloads to run
    if args.workload:
        all_workloads = runner.get_applicable_workloads()
        if args.workload not in all_workloads:
            available = get_all_workloads()
            if args.workload in available:
                print(
                    f"Workload '{args.workload}' requires GPU "
                    f"(not available on this system)."
                )
            else:
                print(f"Unknown workload: '{args.workload}'")
                print("Use --list to see available workloads.")
            return 1
        workloads = {args.workload: all_workloads[args.workload]}
    else:
        workloads = runner.get_applicable_workloads()

    # Print header (unless JSON mode)
    if not args.json:
        print(format_header(config))
        print()

    # Run benchmarks
    results: List[BenchmarkResult] = []
    total = len(workloads)

    for i, (name, spec) in enumerate(workloads.items(), start=1):
        result = runner.run_single_workload(spec)
        results.append(result)

        if not args.json:
            print(format_workload_progress(result, i, total))
            print()

    # Output results
    if args.json:
        print(format_json_output(results, config))
    else:
        print(format_summary_table(results, config))
        print()

    return 0


if __name__ == "__main__":
    sys.exit(main())
