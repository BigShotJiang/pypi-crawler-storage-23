#!/usr/bin/env python3
"""
Forkserver Manager Module.

Centralized management of forkserver lifecycle with safety checks.

The forkserver start method provides significantly faster worker spawn times
(~50-100ms vs ~650ms for spawn) but has strict requirements:
1. Must be initialized BEFORE any threads exist
2. Only available on Unix-like platforms (not Windows)
3. Must be called from the main process

This module provides safe initialization with automatic fallback to spawn.

Author: Epochly Development Team
Date: December 12, 2025
"""

import os
import sys
import signal
import subprocess
import threading
import multiprocessing
import logging
from enum import Enum
from typing import Optional, List

_logger = logging.getLogger(__name__)


class ForkserverState(Enum):
    """State machine for forkserver initialization."""
    UNKNOWN = "unknown"           # Not yet checked
    INITIALIZING = "initializing"  # Currently starting
    READY = "ready"               # Forkserver running, safe to use
    UNAVAILABLE = "unavailable"   # Cannot use (threads exist, platform, etc.)
    FAILED = "failed"             # Attempted but failed


# Module-level state (protected by lock)
_forkserver_state: ForkserverState = ForkserverState.UNKNOWN
_forkserver_lock = threading.Lock()
_initialization_error: Optional[str] = None

# Viability test cache (v0.3.56) — result cached per process lifetime
_forkserver_viability_tested: bool = False
_forkserver_viability_result: Optional[bool] = None


def get_forkserver_state() -> ForkserverState:
    """
    Thread-safe state accessor.

    Returns:
        Current forkserver state
    """
    with _forkserver_lock:
        return _forkserver_state


def is_forkserver_safe() -> bool:
    """
    Check if forkserver can be safely initialized.

    Safety requirements:
    1. Platform supports forkserver
    2. No threads exist yet (ONLY main thread via enumerate, not active_count)
    3. We are in the main process (not a worker)
    4. No conflicting multiprocessing contexts active

    NOTE: Uses threading.enumerate() instead of active_count() because:
    - enumerate() is more reliable per Python documentation
    - active_count() can miss daemon threads or threads started by C extensions
    - enumerate() gives us thread names for debugging

    Returns:
        True if forkserver can be safely started, False otherwise
    """
    import sys

    # CRITICAL FIX (Feb 2026): Skip forkserver entirely on macOS in CI environments
    #
    # Root cause: In CI environments (GitHub Actions, etc.), multiple tests calling
    # core.initialize() can cause ensure_running() to hang due to:
    # 1. Resource contention on self-hosted runners with multiple concurrent jobs
    # 2. Race conditions in forkserver process initialization
    # 3. macOS multiprocessing resource tracker issues (all Python versions, not just 3.13)
    #
    # This hang manifests as 45+ minute timeouts in tests like:
    # - test_performance_config_accessible_after_init
    # - test_performance_config_can_be_queried
    #
    # The fix: Skip forkserver on ALL macOS in CI, not just Python 3.13.
    # Spawn method is used as fallback (slightly slower but reliable).
    #
    # See: https://github.com/python/cpython/issues/82
    # See: https://github.com/python/cpython/issues/114997
    import os
    is_ci = os.environ.get('CI') == 'true' or os.environ.get('GITHUB_ACTIONS') == 'true'

    if sys.platform == 'darwin' and is_ci:
        _logger.debug("Forkserver disabled on macOS in CI (resource contention issues)")
        return False

    # Also skip on Python 3.13 macOS even outside CI (resource tracker issues)
    if sys.version_info[:2] == (3, 13) and sys.platform == 'darwin':
        _logger.debug("Forkserver disabled on Python 3.13 macOS (resource tracker issues)")
        return False

    # CRITICAL FIX (Feb 2026, v0.3.54): Skip forkserver on Python 3.14+ in CI
    #
    # Root cause: Python 3.14 introduces the public `interpreters` module (PEP 734)
    # and has internal multiprocessing changes. ensure_running() hangs indefinitely
    # on Linux CI runners (GitHub Actions) with Python 3.14, blocking the main thread
    # during EpochlyCore.initialize(). The blocking os.read() in ensure_running()
    # has no timeout and is not interruptible by Python signals (GIL held).
    #
    # Evidence: v0.3.53 Release Gate - "Linux Python 3.14 - tests/unit/core" hung
    # at test_lazy_initialization.py::test_initialization_metrics_recorded (55% progress)
    # for >6 hours until job timeout. 295/296 other jobs passed.
    #
    # Fix: Disable forkserver on Python 3.14+ in CI. Spawn method fallback is reliable.
    # Forkserver remains available for Python 3.14 outside CI for local development.
    if sys.version_info >= (3, 14) and is_ci:
        _logger.debug("Forkserver disabled on Python 3.14+ in CI (ensure_running() hang risk)")
        return False

    # Check 1: Platform support
    try:
        available_methods = multiprocessing.get_all_start_methods()
        if "forkserver" not in available_methods:
            _logger.debug("Forkserver not available on this platform")
            return False
    except Exception as e:
        _logger.debug(f"Failed to get start methods: {e}")
        return False

    # Check 2: Thread count (CRITICAL - forkserver unsafe after threads exist)
    # NOTE: Use enumerate() not active_count() - more reliable per research
    current_threads = threading.enumerate()
    if len(current_threads) != 1:
        thread_names = [t.name for t in current_threads]
        _logger.debug(
            f"Forkserver unsafe: {len(current_threads)} threads exist: {thread_names}"
        )
        return False

    # Verify the single thread is the main thread
    if current_threads[0].name != "MainThread":
        _logger.debug(f"Forkserver unsafe: only thread is {current_threads[0].name}")
        return False

    # Check 3: Main process check
    try:
        if multiprocessing.current_process().name != "MainProcess":
            _logger.debug("Forkserver init skipped: not main process")
            return False
    except Exception as e:
        _logger.debug(f"Failed to check process name: {e}")
        return False

    # Check 4: No existing context (would conflict)
    # This is harder to detect, so we rely on try/except during actual init

    return True


def _test_forkserver_viability(
    timeout: float = 8.0,
    preload_modules: Optional[List[str]] = None,
) -> bool:
    """Test forkserver viability in a subprocess with OS-level timeout.

    Spawns a separate Python process that attempts to start a forkserver
    (including module preloading). If the subprocess completes within the
    timeout, the forkserver is viable. If it hangs (e.g., due to OpenBLAS
    pthread_atfork deadlocks on aarch64), the subprocess and its entire
    process group are killed via SIGKILL — no hung threads leak into the
    main process.

    The timeout provides 4x headroom over normal <2s startup. Reduced from
    20s to 8s in v0.3.60 to limit worst-case penalty on platforms where
    forkserver hangs (was adding 20s to every subprocess on aarch64).

    Result is cached both per-process and to disk (cross-subprocess).

    Args:
        timeout: Maximum seconds to wait. Default 8s provides 4x headroom
                 over normal <2s startup while limiting worst-case penalty.
        preload_modules: Modules to preload in forkserver child. If None,
                        uses ["numpy"] (the most common hang trigger).

    Returns:
        True if forkserver started successfully, False if it hung/crashed.
    """
    global _forkserver_viability_tested, _forkserver_viability_result

    if _forkserver_viability_tested:
        return _forkserver_viability_result

    # REGRESSION FIX (v0.3.60): Skip viability test when forkserver won't be used.
    # Epochly Level 0-2 never needs forkserver. Only Level 3+ (multicore)
    # uses process pools that benefit from forkserver. The viability test
    # spawns a subprocess with a 8s timeout — on aarch64 where forkserver
    # hangs, this added 20s (previously) to every workload subprocess,
    # pushing 10 workloads past the 60s benchmark timeout.
    env_level = os.environ.get('EPOCHLY_LEVEL', '').strip()
    if env_level and env_level.isdigit() and int(env_level) < 3:
        _logger.debug(
            "Skipping forkserver viability test: EPOCHLY_LEVEL=%s "
            "(forkserver only needed for Level 3+)", env_level
        )
        _forkserver_viability_result = False
        _forkserver_viability_tested = True
        return False

    if os.environ.get('EPOCHLY_DISABLE', '').strip() == '1':
        _logger.debug("Skipping forkserver viability test: EPOCHLY_DISABLE=1")
        _forkserver_viability_result = False
        _forkserver_viability_tested = True
        return False

    # Escape hatch for benchmarking/debugging: skip viability test entirely.
    if os.environ.get('EPOCHLY_SKIP_FORKSERVER_VIABILITY', '').strip() == '1':
        _logger.debug(
            "Skipping forkserver viability test: EPOCHLY_SKIP_FORKSERVER_VIABILITY=1"
        )
        _forkserver_viability_result = False
        _forkserver_viability_tested = True
        return False

    # Check disk cache (survives across subprocesses within the same session).
    # Cache keyed by Python version + platform to avoid stale results.
    import hashlib
    import json as _json
    cache_key = "{}_{}_{}_{}".format(
        sys.version_info[:3], sys.platform,
        os.uname().machine if hasattr(os, 'uname') else 'unknown',
        timeout,
    )
    _cache_hash = hashlib.md5(cache_key.encode()).hexdigest()[:8]
    try:
        _uid = os.getuid()
    except AttributeError:
        _uid = 0  # Windows fallback
    import tempfile
    _cache_dir = tempfile.gettempdir()
    cache_path = os.path.join(
        _cache_dir,
        "epochly_forkserver_viability_{}_{}.json".format(_uid, _cache_hash),
    )

    try:
        if os.path.exists(cache_path):
            import time as _time
            with open(cache_path, 'r') as f:
                cached = _json.load(f)
            # Cache valid for 1 hour (environment may change between sessions)
            if _time.time() - cached.get('timestamp', 0) < 3600:
                _forkserver_viability_result = cached.get('viable', False)
                _forkserver_viability_tested = True
                _logger.debug(
                    "Forkserver viability from disk cache: %s",
                    _forkserver_viability_result,
                )
                return _forkserver_viability_result
    except Exception:
        pass  # Cache miss or corrupt — run the test

    if not sys.executable:
        _logger.warning(
            "sys.executable not available, cannot test forkserver viability"
        )
        _forkserver_viability_result = False
        _forkserver_viability_tested = True
        return False

    modules = preload_modules or ["numpy"]
    modules_repr = repr(modules)

    # Build test script that mirrors production forkserver init.
    # The forkserver child will import preloaded modules — if that causes
    # a deadlock (e.g., OpenBLAS on aarch64), the subprocess hangs and
    # we kill it via SIGKILL.
    test_lines = [
        'import multiprocessing',
        'ctx = multiprocessing.get_context("forkserver")',
        'try:',
        f'    ctx.set_forkserver_preload({modules_repr})',
        'except Exception:',
        '    pass',
        'from multiprocessing.forkserver import ensure_running',
        'ensure_running()',
        'print("OK")',
    ]
    test_script = '\n'.join(test_lines)

    try:
        proc = subprocess.Popen(
            [sys.executable, '-c', test_script],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            start_new_session=True,  # Isolate process group for clean kill
        )
        try:
            stdout, _ = proc.communicate(timeout=timeout)
            success = proc.returncode == 0 and b'OK' in stdout
            if success:
                _logger.debug("Forkserver viability test passed in subprocess")
            else:
                _logger.warning(
                    f"Forkserver viability test failed: "
                    f"exit_code={proc.returncode}, stdout={stdout!r}"
                )
            _forkserver_viability_result = success
        except subprocess.TimeoutExpired:
            _logger.warning(
                f"Forkserver viability test timed out after {timeout}s — "
                f"forkserver hangs on this platform, falling back to spawn"
            )
            # Kill entire process group (test subprocess + its forkserver child)
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                # Process group already dead or can't kill — fall back to direct kill
                try:
                    proc.kill()
                except (ProcessLookupError, PermissionError):
                    pass  # Process already dead — no zombie risk
            try:
                proc.wait(timeout=3)
            except (subprocess.TimeoutExpired, ChildProcessError):
                pass
            _forkserver_viability_result = False
    except OSError as e:
        _logger.warning(f"Forkserver viability test failed to start: {e}")
        _forkserver_viability_result = False
    except Exception as e:
        _logger.warning(f"Forkserver viability test unexpected error: {e}")
        _forkserver_viability_result = False

    # Save result to disk cache for cross-subprocess reuse
    try:
        import time as _time
        import json as _json2
        with open(cache_path, 'w') as f:
            _json2.dump({
                'viable': _forkserver_viability_result,
                'timestamp': _time.time(),
                'cache_key': cache_key,
            }, f)
    except Exception:
        pass  # Non-critical — in-process cache still works

    _forkserver_viability_tested = True
    return _forkserver_viability_result


def try_initialize_forkserver(
    preload_modules: Optional[List[str]] = None
) -> ForkserverState:
    """
    Attempt to initialize forkserver if safe.

    This should be called ONCE at first auto_enable() or Level 3 trigger,
    NOT at import time (to allow user to set their own start method first).

    Args:
        preload_modules: Modules to preload in forkserver for faster worker startup.
                        If None, uses default list: ["epochly.core", "numpy"]

    Returns:
        Final state after initialization attempt
    """
    global _forkserver_state, _initialization_error

    with _forkserver_lock:
        # Already initialized or failed - don't retry
        if _forkserver_state in (ForkserverState.READY, ForkserverState.FAILED):
            return _forkserver_state

        # Already unavailable - don't retry
        if _forkserver_state == ForkserverState.UNAVAILABLE:
            return _forkserver_state

    # Safety check (outside lock to avoid holding lock during checks)
    if not is_forkserver_safe():
        with _forkserver_lock:
            _forkserver_state = ForkserverState.UNAVAILABLE
        return ForkserverState.UNAVAILABLE

    with _forkserver_lock:
        _forkserver_state = ForkserverState.INITIALIZING

    try:
        # Get forkserver context
        ctx = multiprocessing.get_context("forkserver")

        # Configure preload modules (reduces worker startup time)
        default_preloads = [
            "epochly.core",
            "numpy",
        ]
        modules_to_preload = preload_modules or default_preloads

        try:
            ctx.set_forkserver_preload(modules_to_preload)
            _logger.debug(f"Forkserver preload configured: {modules_to_preload}")
        except Exception as e:
            # Preload failure is non-fatal - forkserver can still work
            _logger.debug(f"Forkserver preload failed (non-fatal): {e}")

        # Process-level viability test: detect forkserver hangs before committing.
        # Runs ensure_running() in a subprocess with OS-level timeout (SIGKILL).
        # If it hangs (e.g., OpenBLAS/pthread_atfork deadlock on aarch64), the
        # subprocess is killed cleanly — no hung threads in the main process.
        if not _test_forkserver_viability(
            timeout=8.0, preload_modules=modules_to_preload
        ):
            with _forkserver_lock:
                _forkserver_state = ForkserverState.FAILED
                _initialization_error = (
                    "Forkserver viability test failed: ensure_running() hung or "
                    "crashed in subprocess test"
                )
                _logger.warning(
                    "Forkserver viability test failed, will use spawn"
                )
            return ForkserverState.FAILED

        # Viability confirmed — ensure_running() should complete quickly.
        from multiprocessing.forkserver import ensure_running
        ensure_running()

        with _forkserver_lock:
            _forkserver_state = ForkserverState.READY
            _logger.info("Forkserver initialized successfully")

        return ForkserverState.READY

    except Exception as e:
        with _forkserver_lock:
            _forkserver_state = ForkserverState.FAILED
            _initialization_error = str(e)
            _logger.warning(f"Forkserver initialization failed, will use spawn: {e}")

        return ForkserverState.FAILED


def get_recommended_start_method() -> str:
    """
    Get the recommended ProcessPool start method based on forkserver state.

    Returns:
        "forkserver" if ready, "spawn" otherwise (always safe fallback)
    """
    state = get_forkserver_state()

    if state == ForkserverState.READY:
        return "forkserver"
    else:
        # spawn is always safe (cross-platform, no thread restrictions)
        return "spawn"


def get_initialization_error() -> Optional[str]:
    """
    Get the error message if initialization failed.

    Returns:
        Error message string if failed, None otherwise
    """
    with _forkserver_lock:
        return _initialization_error


def _demote_forkserver_state(error_message: str) -> None:
    """
    Demote forkserver state to FAILED after runtime failure.

    Called when forkserver was READY but pool creation failed at runtime.
    This ensures subsequent calls use spawn instead.

    Args:
        error_message: Description of what failed
    """
    global _forkserver_state, _initialization_error

    with _forkserver_lock:
        # Only demote from READY - other states should not change
        if _forkserver_state == ForkserverState.READY:
            _forkserver_state = ForkserverState.FAILED
            _initialization_error = f"Runtime failure: {error_message}"
            _logger.warning(f"Forkserver demoted to FAILED: {error_message}")
