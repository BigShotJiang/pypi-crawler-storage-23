"""Memory module for CoordMCP."""
