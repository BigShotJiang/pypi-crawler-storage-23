"""
Tests for architecture module.
"""
