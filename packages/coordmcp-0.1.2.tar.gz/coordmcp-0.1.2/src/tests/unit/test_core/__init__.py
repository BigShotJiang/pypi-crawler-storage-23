"""
Tests for core module.
"""
