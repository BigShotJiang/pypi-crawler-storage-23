"""Unit tests for MCP resources."""
