"""
Tests for context module.
"""
