"""
Unit tests for CoordMCP components.
"""
