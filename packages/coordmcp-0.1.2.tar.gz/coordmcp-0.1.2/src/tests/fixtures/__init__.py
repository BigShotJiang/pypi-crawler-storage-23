"""
Test fixtures and sample data for CoordMCP tests.
"""
