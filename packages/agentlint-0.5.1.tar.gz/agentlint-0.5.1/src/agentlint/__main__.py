"""Allow running agentlint as a module: python -m agentlint."""
from agentlint.cli import main

if __name__ == "__main__":
    main()
