# -*- coding: utf-8 -*-
"""Clouvel Domain Services

DDD service layer — single source of truth for tier, quota, and gating logic.
"""
