# -*- coding: utf-8 -*-
"""Tier Service — Single source of truth for user tier resolution.

Replaces duplicated _is_pro() logic in:
- tool_dispatch.py (_is_pro, _get_list_tools_tier, _get_call_tool_tier)
- utils/entitlements.py (can_use_pro)
- tools/meeting/core.py (_can_use_pro)
- tools/proactive.py (_can_use_pro)
"""

from enum import Enum
from typing import Optional


class Tier(Enum):
    FREE = "free"
    FIRST = "first"    # First project (Pro feature access via reverse trial)
    TRIAL = "trial"    # 7-day full trial
    PRO = "pro"        # Paid license
    DEV = "dev"        # Developer mode

    def is_pro_equivalent(self) -> bool:
        """Paid Pro-level access? (license/trial/developer)"""
        return self in (Tier.PRO, Tier.TRIAL, Tier.DEV)

    def is_first_or_above(self) -> bool:
        """First project or above? (KB, meeting, manager access)"""
        return self in (Tier.FIRST, Tier.PRO, Tier.TRIAL, Tier.DEV)


def resolve_tier(project_path: Optional[str] = None) -> Tier:
    """Resolve user tier — v6.0: all users get full access.

    v6.0: Free-ification — always returns PRO-equivalent access.
    """
    return Tier.PRO


def is_pro(project_path: Optional[str] = None) -> bool:
    """v6.0: Always True — all features free."""
    return True


def can_use_pro(project_path: Optional[str] = None) -> bool:
    """v6.0: Always True — all features free."""
    return True


def get_tool_filter_tier(project_path: Optional[str] = None) -> str:
    """v6.0: Always 'pro' — all tools visible."""
    return "pro"
