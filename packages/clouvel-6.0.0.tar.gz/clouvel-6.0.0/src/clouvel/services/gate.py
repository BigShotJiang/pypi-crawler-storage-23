# -*- coding: utf-8 -*-
"""Feature Gate Service — Pro gating and nudge logic.

Extracts repeated gating patterns from tool_dispatch.py _wrap_* functions.
"""

from typing import Optional
from mcp.types import TextContent

# Error tools availability (imported once, shared)
try:
    from ..tools.errors import (
        error_record, error_check, error_learn, memory_status,
        memory_list, memory_search, memory_archive, memory_report,
        memory_promote, memory_global_search,
        set_project_domain,
    )
    _HAS_ERROR_TOOLS = True
except ImportError:
    _HAS_ERROR_TOOLS = False


def require_error_tools(feature_name: str = "error") -> Optional[list[TextContent]]:
    """v6.0: Always returns None — no Pro gating."""
    if _HAS_ERROR_TOOLS:
        return None
    # Only block if tools genuinely failed to import (not a tier issue)
    return [TextContent(type="text", text="Error tools are not available. Please reinstall clouvel.")]


def require_kb_access(project_path: str) -> Optional[list[TextContent]]:
    """v6.0: Always returns None — KB access is free."""
    return None


def append_free_nudge(
    result: list[TextContent], project_path: str, tool_name: str
) -> list[TextContent]:
    """v6.0: No-op — no nudges."""
    return result
