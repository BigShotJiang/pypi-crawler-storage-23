# -*- coding: utf-8 -*-
"""License/trial/upgrade formatters.

v6.0: All features free — most formatters return simple messages.
"""


def format_activate_license_no_key() -> str:
    return "All features are free in Clouvel v6.0. No license needed."


def format_activate_license_success(result: dict) -> str:
    return "All features are free in Clouvel v6.0. No license needed."


def format_activate_license_failure(result: dict) -> str:
    return "All features are free in Clouvel v6.0. No license needed."


def format_license_status_none(result: dict) -> str:
    return """
# Clouvel v6.0 — All Features Free

All tools and features are included at no cost.
No license or trial needed.
"""


def format_license_status_active(result: dict) -> str:
    return """
# Clouvel v6.0 — All Features Free

All tools and features are included at no cost.
"""


def format_trial_already_licensed() -> str:
    return "All features are free in Clouvel v6.0. No license or trial needed."


def format_trial_active(remaining: int) -> str:
    return "All features are free in Clouvel v6.0. No trial needed."


def format_trial_expired() -> str:
    return "All features are free in Clouvel v6.0."


def format_trial_started(remaining: int) -> str:
    return "All features are free in Clouvel v6.0. No trial needed."


def format_upgrade_pro() -> str:
    return """
# Clouvel v6.0 — All Features Free

All 20 tools are included at no cost:
- 8 C-Level AI managers
- Knowledge Base
- Error Learning & Regression Memory
- Context Checkpoint
- Ship (lint+test+build+evidence)
- And more

No license, trial, or payment required.
"""
