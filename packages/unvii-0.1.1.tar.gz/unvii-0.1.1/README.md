# Unvii Client SDK

## Install
```bash
pip install .
```

## Usage
```python
from unvii import Model, generate_api_key

BASE_URL = "https://unvii.onrender.com"
api_key = generate_api_key(base_url=BASE_URL)
model = Model(api_key=api_key, system_prompt="You are concise and helpful.", base_url=BASE_URL)
reply = model.generate_text("Explain black holes in two sentences.")
print(reply)
```
