from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Optional, Sequence

from pyrust.analyzer import Rustyfiability
from pyrust.api import (
    AutoRustyficationConfig,
    analyze_summary,
    enable_auto_rustyfication,
    transpile_with_analysis,
    undo_last_rustyfication,
)
from pyrust.persistence import persist_rustyfication


def _add_help_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "-h",
        "--help",
        "--ayuda",
        action="help",
        help="Muestra esta ayuda y termina.",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="CLI principal de PyRust: rustifica código o ejecuta el pipeline automático.",
        add_help=False,
    )
    _add_help_argument(parser)

    subparsers = parser.add_subparsers(dest="command", metavar="comando", required=True)

    rustificar_parser = subparsers.add_parser(
        "rustificar",
        help="Transpila funciones Python a Rust según el análisis de rustyficabilidad.",
        description=(
            "Transpila funciones Python a Rust usando el analizador para saltar objetivos no compatibles."
        ),
        add_help=False,
    )
    _add_help_argument(rustificar_parser)
    rustificar_parser.add_argument(
        "path",
        type=Path,
        nargs="?",
        default=Path.cwd(),
        help="Ruta a un archivo o directorio Python a rustificar (por defecto, el directorio actual).",
    )
    rustificar_parser.add_argument(
        "--exclude",
        "-x",
        action="append",
        dest="excluded_dirs",
        default=[],
        help="Nombres de directorios a omitir durante el análisis.",
    )
    rustificar_mode = rustificar_parser.add_mutually_exclusive_group()
    rustificar_mode.add_argument(
        "--buscar",
        action="store_true",
        help="Solo lista candidatos FULL/PARTIAL sin transpilar código.",
    )
    rustificar_mode.add_argument(
        "--deshacer",
        action="store_true",
        help="Revierte la última rustyficación registrada (hot-swap).",
    )
    rustificar_mode.add_argument(
        "--errores",
        action="store_true",
        help="Muestra objetivos bloqueantes (veredicto NO) y sus razones completas.",
    )
    rustificar_parser.add_argument(
        "--format",
        choices=["table", "json", "markdown"],
        default="table",
        help="Formato de salida: tabla legible, JSON o Markdown.",
    )
    rustificar_parser.add_argument(
        "--output",
        type=Path,
        help="Ruta opcional para escribir el informe generado (Markdown o JSON).",
    )
    rustificar_parser.add_argument(
        "--limit",
        type=int,
        default=5,
        help="Número máximo de elementos a mostrar en los listados (table/markdown).",
    )
    rustificar_parser.add_argument(
        "--mostrar-codigo",
        action="store_true",
        help="Imprime el código Rust generado para cada función compatible.",
    )
    rustificar_parser.set_defaults(handler=_run_rustificar)

    auto_parser = subparsers.add_parser(
        "auto",
        help="Ejecuta el pipeline automático de rustyficación y hot-swap.",
        description=(
            "Ejecuta el flujo automático: perfilado, análisis, transpilación y recarga de hotspots."
        ),
        add_help=False,
    )
    _add_help_argument(auto_parser)
    auto_parser.add_argument(
        "path",
        type=Path,
        nargs="?",
        default=Path.cwd(),
        help="Ruta del proyecto a procesar (por defecto, el directorio actual).",
    )
    auto_parser.add_argument(
        "--exclude",
        "-x",
        action="append",
        dest="excluded_dirs",
        default=[],
        help="Nombres de directorios a omitir durante el análisis y perfilado.",
    )
    auto_parser.add_argument(
        "--entrypoint",
        type=Path,
        help="Script de entrada opcional dentro del proyecto.",
    )
    auto_parser.add_argument(
        "--hotspot-limit",
        type=int,
        default=5,
        help="Número máximo de hotspots a considerar.",
    )
    auto_parser.add_argument(
        "--min-runtime-pct",
        type=float,
        default=5.0,
        help="Porcentaje mínimo de tiempo de ejecución para seleccionar un hotspot.",
    )
    auto_parser.add_argument(
        "--profile-limit",
        type=int,
        default=25,
        help="Número máximo de filas en el perfilado (usa 0 para desactivar).",
    )

    auto_group = auto_parser.add_mutually_exclusive_group()
    auto_group.add_argument(
        "--use-sys-profile",
        dest="use_sys_profile",
        action="store_true",
        default=True,
        help="Usa cProfile durante el perfilado (por defecto).",
    )
    auto_group.add_argument(
        "--no-use-sys-profile",
        dest="use_sys_profile",
        action="store_false",
        help="Desactiva cProfile y usa el hook ligero.",
    )

    auto_parser.add_argument(
        "--include-stdlib",
        action="store_true",
        help="Incluye llamadas de la stdlib/builtins en el perfilado.",
    )
    auto_parser.add_argument(
        "--include-partial",
        action="store_true",
        help="Permite rustyficar objetivos con veredicto PARTIAL.",
    )
    auto_parser.add_argument(
        "--format",
        choices=["table", "json", "markdown"],
        default="table",
        help="Formato de salida: tabla legible, JSON o Markdown.",
    )
    auto_parser.add_argument(
        "--output",
        type=Path,
        help="Ruta opcional para escribir el resumen generado (Markdown o JSON).",
    )
    auto_parser.add_argument(
        "--force-recompile",
        action="store_true",
        help="Fuerza la recompilación de extensiones aunque exista caché.",
    )
    auto_parser.add_argument(
        "--invalidate-cache",
        action="store_true",
        help="Invalida entradas de caché antes de recompilar.",
    )
    auto_parser.add_argument(
        "--no-use-cache",
        dest="use_cache",
        action="store_false",
        default=True,
        help="Desactiva el uso de caché durante la recarga de extensiones.",
    )
    auto_parser.add_argument(
        "--no-persist",
        dest="persist",
        action="store_false",
        default=True,
        help="Evita que se guarden los cambios de rustyficación en disco (solo hot-swap).",
    )
    auto_parser.set_defaults(handler=_run_auto)

    return parser


def _render_rustificar_summary(results: list, *, show_code: bool, output_format: str) -> str:
    processed = len(results)
    generated = sum(1 for result in results if not result.skipped)
    skipped = sum(1 for result in results if result.skipped)
    errors = sum(1 for result in results if result.error)

    if output_format == "json":
        results_payload: list[dict[str, object]] = []
        payload = {
            "counts": {
                "processed": processed,
                "generated": generated,
                "skipped": skipped,
                "errors": errors,
            },
            "results": results_payload,
        }
        for result in results:
            item = {
                "target": result.target,
                "verdict": result.verdict.name if result.verdict else None,
                "skipped": result.skipped,
                "error": result.error,
                "reasons": list(result.reasons or []),
            }
            if show_code:
                item["rendered"] = result.rendered
            results_payload.append(item)
        return json.dumps(payload, ensure_ascii=False, indent=2)

    lines: list[str] = []
    if output_format == "markdown":
        lines.extend(
            [
                "# Resumen de rustyficación",
                "",
                f"- Targets procesados: {processed}",
                f"- Funciones generadas: {generated}",
                f"- Funciones omitidas: {skipped}",
                f"- Errores: {errors}",
                "",
                "## Detalle",
            ]
        )
        for result in results:
            status = "generada" if not result.skipped else "omitida"
            detail = f" (motivo: {result.error})" if result.error else ""
            lines.append(f"- `{result.target}`: {status}{detail}")
            if show_code and result.rendered:
                lines.extend(["", "```rust", result.rendered.rstrip(), "```"])
        return "\n".join(lines)

    lines.append("Resumen de rustyficación")
    lines.append(f"Targets procesados: {processed}")
    lines.append(f"Funciones generadas: {generated}")
    lines.append(f"Funciones omitidas: {skipped}")
    lines.append(f"Errores: {errors}")
    for result in results:
        status = "generada" if not result.skipped else "omitida"
        detail = f" (motivo: {result.error})" if result.error else ""
        lines.append(f"- {result.target}: {status}{detail}")
        if show_code and result.rendered:
            lines.append("")
            lines.append(result.rendered.rstrip())
            lines.append("")
    return "\n".join(lines)


def _render_rustificar_candidates(summary, *, output_format: str) -> str:
    candidates = [
        result
        for result in summary.results
        if result.verdict in (Rustyfiability.FULL, Rustyfiability.PARTIAL)
    ]
    payload_items = []
    for result in candidates:
        if ":" in result.target:
            file_path, target_name = result.target.rsplit(":", 1)
        else:
            file_path = result.target
            target_name = ""
        payload_items.append(
            {
                "file": file_path,
                "target": target_name,
                "verdict": result.verdict.name,
                "reason": result.reasons[0] if result.reasons else "",
            }
        )

    if output_format == "json":
        payload = {
            "total": len(payload_items),
            "candidates": payload_items,
        }
        return json.dumps(payload, ensure_ascii=False, indent=2)

    lines: list[str] = []
    if output_format == "markdown":
        lines.append("# Candidatos a rustificar")
        lines.append("")
        lines.append(f"- Total: {len(payload_items)}")
        lines.append("")
        if not payload_items:
            lines.append("- (sin candidatos)")
            return "\n".join(lines)
        lines.append("| Archivo | Target | Veredicto | Motivo principal |")
        lines.append("| --- | --- | --- | --- |")
        for item in payload_items:
            display_target = item["target"] or "(module)"
            lines.append(
                f"| {item['file']} | {display_target} | {item['verdict']} | {item['reason']} |"
            )
        return "\n".join(lines)

    lines.append("Candidatos a rustificar (FULL/PARTIAL)")
    lines.append(f"Total: {len(payload_items)}")
    if not payload_items:
        return "\n".join(lines)
    for item in payload_items:
        display_target = item["target"] or "(module)"
        lines.append(
            f"- {item['file']}::{display_target} [{item['verdict']}]"
            + (f" -> {item['reason']}" if item["reason"] else "")
        )
    return "\n".join(lines)


def _render_rustificar_errors(summary, *, output_format: str, limit: Optional[int]) -> str:
    blockers = [result for result in summary.results if result.verdict is Rustyfiability.NO]
    payload_items = [
        {
            "target": result.target,
            "verdict": result.verdict.name,
            "reasons": list(result.reasons),
        }
        for result in blockers
    ]

    if output_format == "json":
        payload = {
            "total": len(payload_items),
            "errors": payload_items,
        }
        return json.dumps(payload, ensure_ascii=False, indent=2)

    display = payload_items if limit is None else payload_items[:limit]
    lines: list[str] = []
    if output_format == "markdown":
        lines.append("# Objetivos bloqueantes")
        lines.append("")
        lines.append(f"- Total: {len(payload_items)}")
        lines.append("")
        if not display:
            lines.append("- (sin bloqueantes)")
            return "\n".join(lines)
        for item in display:
            lines.append(f"- **{item['target']}** — {item['verdict']}")
            if item["reasons"]:
                for reason in item["reasons"]:
                    lines.append(f"  - {reason}")
        if limit is not None and len(payload_items) > limit:
            lines.append(f"- ... {len(payload_items) - limit} más")
        return "\n".join(lines)

    lines.append("Objetivos bloqueantes (veredicto NO)")
    lines.append(f"Total: {len(payload_items)}")
    if not display:
        return "\n".join(lines)
    for item in display:
        lines.append(f"- {item['target']} [{item['verdict']}]")
        if item["reasons"]:
            for reason in item["reasons"]:
                lines.append(f"    - {reason}")
    if limit is not None and len(payload_items) > limit:
        lines.append(f"... {len(payload_items) - limit} más")
    return "\n".join(lines)


def _render_undo_result(result, *, output_format: str) -> str:
    payload = {
        "success": result.success,
        "restored_targets": list(result.restored_targets),
        "extensions_unloaded": list(result.extensions_unloaded),
        "errors": list(result.errors),
        "record_path": result.record_path,
    }

    if output_format == "json":
        return json.dumps(payload, ensure_ascii=False, indent=2)

    if output_format == "markdown":
        lines = [
            "# Resultado de deshacer rustyficación",
            "",
            f"- Éxito: {'sí' if result.success else 'no'}",
        ]
        if result.record_path:
            lines.append(f"- Registro usado: `{result.record_path}`")
        lines.append("")
        lines.append("## Targets restaurados")
        if result.restored_targets:
            for target in result.restored_targets:
                lines.append(f"- `{target}`")
        else:
            lines.append("- (sin targets restaurados)")
        lines.append("")
        lines.append("## Extensiones descargadas")
        if result.extensions_unloaded:
            for name in result.extensions_unloaded:
                lines.append(f"- `{name}`")
        else:
            lines.append("- (sin extensiones descargadas)")
        lines.append("")
        lines.append("## Errores")
        if result.errors:
            for error in result.errors:
                lines.append(f"- {error}")
        else:
            lines.append("- (sin errores)")
        return "\n".join(lines)

    lines = [
        "Resultado de deshacer rustyficación",
        f"Éxito: {'sí' if result.success else 'no'}",
    ]
    if result.record_path:
        lines.append(f"Registro usado: {result.record_path}")
    lines.append("Targets restaurados:")
    if result.restored_targets:
        for target in result.restored_targets:
            lines.append(f"- {target}")
    else:
        lines.append("- (sin targets restaurados)")
    lines.append("Extensiones descargadas:")
    if result.extensions_unloaded:
        for name in result.extensions_unloaded:
            lines.append(f"- {name}")
    else:
        lines.append("- (sin extensiones descargadas)")
    lines.append("Errores:")
    if result.errors:
        for error in result.errors:
            lines.append(f"- {error}")
    else:
        lines.append("- (sin errores)")
    return "\n".join(lines)


def _run_rustificar(args: argparse.Namespace) -> int:
    if args.deshacer:
        result = undo_last_rustyfication()
        rendered = _render_undo_result(result, output_format=args.format)
        if args.output:
            try:
                args.output.write_text(rendered, encoding="utf-8")
            except OSError as exc:
                raise ValueError(f"No se pudo escribir el informe en {args.output}: {exc}") from exc
        print(rendered)
        return 0

    if args.path.exists() and args.path.is_file():
        if args.path.suffix != ".py":
            parser_error = f"El archivo '{args.path}' no es un archivo Python (.py)."
            raise ValueError(parser_error)

    if args.buscar:
        summary = analyze_summary(args.path, excluded_dirs=args.excluded_dirs or None)
        rendered = _render_rustificar_candidates(summary, output_format=args.format)
    elif args.errores:
        summary = analyze_summary(args.path, excluded_dirs=args.excluded_dirs or None)
        rendered = _render_rustificar_errors(
            summary,
            output_format=args.format,
            limit=args.limit,
        )
    else:
        results = transpile_with_analysis(
            args.path,
            excluded_dirs=args.excluded_dirs or None,
        )

        rendered = _render_rustificar_summary(
            results,
            show_code=args.mostrar_codigo,
            output_format=args.format,
        )
    if args.output:
        try:
            args.output.write_text(rendered, encoding="utf-8")
        except OSError as exc:
            raise ValueError(f"No se pudo escribir el informe en {args.output}: {exc}") from exc
    print(rendered)
    return 0


def _render_auto_summary(report, *, output_format: str) -> str:
    profile = report.profile
    metrics = {
        "runtime_total_s": profile.total_runtime,
        "profile_samples": len(profile.samples),
        "targets_analyzed": report.analysis.total_targets,
        "targets_transpiled": len(report.transpilation),
        "hotspots_selected": len(report.selected_targets),
        "targets_reloaded": len(report.reloaded),
        "targets_swapped": len(report.swapped_targets),
        "reload_failures": len(report.reload_failures),
    }

    if output_format == "json":
        payload = {
            "project_root": str(report.project_root),
            "selected_hotspots": list(report.selected_targets),
            "rustified_targets": list(report.swapped_targets),
            "reload_failures": list(report.reload_failures),
            "metrics": metrics,
        }
        return json.dumps(payload, ensure_ascii=False, indent=2)

    lines: list[str] = []
    if output_format == "markdown":
        lines.extend(
            [
                "# Resumen de auto-rustyficación",
                "",
                f"- Proyecto: `{report.project_root}`",
                f"- Hotspots seleccionados: {metrics['hotspots_selected']}",
                f"- Targets rustificados: {metrics['targets_swapped']}",
                f"- Fallos de recarga: {metrics['reload_failures']}",
                "",
                "## Métricas clave",
                f"- Runtime total (s): {metrics['runtime_total_s']:.6f}",
                f"- Muestras de profiling: {metrics['profile_samples']}",
                f"- Targets analizados: {metrics['targets_analyzed']}",
                f"- Targets transpilados: {metrics['targets_transpiled']}",
                f"- Recargas exitosas: {metrics['targets_reloaded']}",
                "",
                "## Hotspots seleccionados",
            ]
        )
        if report.selected_targets:
            for target in report.selected_targets:
                lines.append(f"- `{target}`")
        else:
            lines.append("- (sin hotspots seleccionados)")

        lines.append("")
        lines.append("## Targets rustificados")
        if report.swapped_targets:
            for target in report.swapped_targets:
                lines.append(f"- `{target}`")
        else:
            lines.append("- (sin targets rustificados)")

        lines.append("")
        lines.append("## Fallos de recarga")
        if report.reload_failures:
            for target in report.reload_failures:
                lines.append(f"- `{target}`")
        else:
            lines.append("- (sin fallos de recarga)")
        return "\n".join(lines)

    lines.append("Resumen de auto-rustyficación")
    lines.append(f"Proyecto: {report.project_root}")
    lines.append(f"Hotspots seleccionados: {metrics['hotspots_selected']}")
    lines.append(f"Targets rustificados: {metrics['targets_swapped']}")
    lines.append(f"Fallos de recarga: {metrics['reload_failures']}")
    lines.append("")
    lines.append("Métricas clave")
    lines.append(f"- Runtime total (s): {metrics['runtime_total_s']:.6f}")
    lines.append(f"- Muestras de profiling: {metrics['profile_samples']}")
    lines.append(f"- Targets analizados: {metrics['targets_analyzed']}")
    lines.append(f"- Targets transpilados: {metrics['targets_transpiled']}")
    lines.append(f"- Recargas exitosas: {metrics['targets_reloaded']}")
    lines.append("")
    lines.append("Hotspots seleccionados:")
    if report.selected_targets:
        for target in report.selected_targets:
            lines.append(f"- {target}")
    else:
        lines.append("- (sin hotspots seleccionados)")
    lines.append("")
    lines.append("Targets rustificados:")
    if report.swapped_targets:
        for target in report.swapped_targets:
            lines.append(f"- {target}")
    else:
        lines.append("- (sin targets rustificados)")
    lines.append("")
    lines.append("Fallos de recarga:")
    if report.reload_failures:
        for target in report.reload_failures:
            lines.append(f"- {target}")
    else:
        lines.append("- (sin fallos de recarga)")
    return "\n".join(lines)


def _run_auto(args: argparse.Namespace) -> int:
    profile_limit = None if args.profile_limit == 0 else args.profile_limit
    config = AutoRustyficationConfig(
        hotspot_limit=args.hotspot_limit,
        min_runtime_pct=args.min_runtime_pct,
        profile_limit=profile_limit,
        use_sys_profile=args.use_sys_profile,
        include_stdlib=args.include_stdlib,
        include_partial=args.include_partial,
        excluded_dirs=args.excluded_dirs or None,
        entrypoint=args.entrypoint,
        force_recompile=args.force_recompile,
        invalidate_cache=args.invalidate_cache,
        use_cache=args.use_cache,
    )

    report = enable_auto_rustyfication(args.path, config=config)

    if args.persist:
        persist_rustyfication(report)

    rendered = _render_auto_summary(report, output_format=args.format)
    if args.output:
        try:
            args.output.write_text(rendered, encoding="utf-8")
        except OSError as exc:
            raise ValueError(f"No se pudo escribir el resumen en {args.output}: {exc}") from exc
    print(rendered)
    return 0


def _run(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    handler = getattr(args, "handler", None)
    if handler is None:
        parser.error("No se pudo resolver el comando solicitado.")
    try:
        return handler(args)
    except (FileNotFoundError, ValueError, SyntaxError, RuntimeError, OSError) as exc:
        parser.error(str(exc))


def main(argv: Optional[Sequence[str]] = None) -> None:
    if len(sys.argv) > 1 and sys.argv[1] == "-auto":
        sys.argv[1] = "auto"
    sys.exit(_run(argv))


if __name__ == "__main__":  # pragma: no cover
    main()
