from __future__ import annotations

import logging
from typing import Protocol, runtime_checkable

from pyrust.runtime.types import LoadedModule, ReloadMetrics

@runtime_checkable
class RuntimeEventListener(Protocol):
    """Observador para eventos del ciclo de vida del RuntimeManager."""
    
    def on_success(self, extension_name: str, module: LoadedModule, metrics: ReloadMetrics) -> None:
        ...

    def on_failure(self, extension_name: str, error: Exception, metrics: ReloadMetrics) -> None:
        ...

    def on_rollback(self, extension_name: str, restored: LoadedModule, metrics: ReloadMetrics) -> None:
        ...

class LoggingEventListener:
    """Listener que registra eventos en el logger estándar."""
    
    def __init__(self, logger: logging.Logger | None = None):
        self.logger = logger or logging.getLogger(__name__)

    def on_success(self, extension_name: str, module: LoadedModule, metrics: ReloadMetrics) -> None:
        self.logger.info(
            "Event: SUCCESS | Ext: %s | Swap #%d | Time: %.3fs | Cache: %s | Size: %dB",
            extension_name,
            metrics.swap_count,
            metrics.duration_s,
            metrics.used_cache,
            metrics.source_size_bytes
        )

    def on_failure(self, extension_name: str, error: Exception, metrics: ReloadMetrics) -> None:
        self.logger.error(
            "Event: FAILURE | Ext: %s | Time: %.3fs | Size: %dB | Error: %s",
            extension_name,
            metrics.duration_s,
            metrics.source_size_bytes,
            error
        )

    def on_rollback(self, extension_name: str, restored: LoadedModule, metrics: ReloadMetrics) -> None:
        self.logger.warning(
            "Event: ROLLBACK | Ext: %s | Restored to: %s",
            extension_name,
            restored.path
        )
