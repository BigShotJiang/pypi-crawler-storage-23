"""
Tipos y modelos de datos para el runtime de PyRust.
Separados para evitar importaciones circulares.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Optional

_EXTENSION_NAME_PATTERN = re.compile(r"^[A-Za-z0-9_]+$")
_WINDOWS_RESERVED_NAMES = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{index}" for index in range(1, 10)),
    *(f"LPT{index}" for index in range(1, 10)),
}


@dataclass
class LoadedModule:
    name: str
    path: Path
    module: ModuleType


@dataclass
class ReloadMetrics:
    duration_s: float
    swap_count: int
    used_cache: bool
    forced_recompile: bool
    retry_count: int = 0
    failure_cause: Optional[str] = None
    source_size_bytes: int = 0


@dataclass
class ReloadResult:
    loaded: LoadedModule
    from_cache: bool
    metrics: ReloadMetrics
    runtime_manager: "RuntimeManager | None" = None  # Forward reference to RuntimeManager


@dataclass(slots=True)
class LastSwapRecord:
    project_root: Path
    swapped_targets: list[str]
    extensions: list[dict[str, str]]
    created_at: str
    version: int = 1

    def to_dict(self) -> dict[str, object]:
        return {
            "version": self.version,
            "project_root": str(self.project_root),
            "created_at": self.created_at,
            "swapped_targets": list(self.swapped_targets),
            "extensions": list(self.extensions),
        }

    @classmethod
    def from_dict(cls, payload: dict[str, object]) -> "LastSwapRecord":
        logger = logging.getLogger(__name__)
        version_raw = payload.get("version", 0)
        if not isinstance(version_raw, (int, str, bytes, bytearray)):
            raise ValueError("Registro inválido: 'version' no es numérico")
        version = int(version_raw)
        if version != 1:
            raise ValueError(f"Versión de registro no soportada: {version}")

        project_root_raw = payload.get("project_root")
        if not isinstance(project_root_raw, str) or not project_root_raw:
            raise ValueError("Registro inválido: 'project_root' ausente")

        swapped_targets_raw = payload.get("swapped_targets")
        if swapped_targets_raw is None:
            swapped_targets_raw = []
        if not isinstance(swapped_targets_raw, list):
            raise ValueError("Registro inválido: 'swapped_targets' no es una lista")

        extensions_raw = payload.get("extensions")
        if extensions_raw is None:
            extensions_raw = []
        if not isinstance(extensions_raw, list):
            raise ValueError("Registro inválido: 'extensions' no es una lista")

        created_at = payload.get("created_at")
        if not isinstance(created_at, str):
            created_at = ""

        sanitized_targets: list[str] = []
        for item in swapped_targets_raw:
            if not isinstance(item, str) or not item:
                logger.error("Registro inválido: target omitido por tipo inválido")
                continue
            file_part, _, qualified = item.partition(":")
            if not file_part or not qualified:
                logger.error("Registro inválido: target omitido por formato inseguro (%s)", item)
                continue
            sanitized_targets.append(item)

        sanitized_extensions: list[dict[str, str]] = []
        for entry in extensions_raw:
            if not isinstance(entry, dict):
                logger.error("Registro inválido: extensión omitida por tipo inválido")
                continue
            name = entry.get("name")
            if not isinstance(name, str) or not name:
                logger.error("Registro inválido: extensión omitida por nombre inválido")
                continue
            
            # Validación simple de nombre para evitar dependencias circulares con RuntimeManager
            if not isinstance(name, str) or not name or not _EXTENSION_NAME_PATTERN.fullmatch(name) or name.upper() in _WINDOWS_RESERVED_NAMES:
                 logger.error("Registro inválido: extensión omitida por nombre inseguro (%s)", name)
                 continue
            
            sanitized_entry = {"name": name}
            artifact = entry.get("artifact")
            if isinstance(artifact, str) and artifact:
                sanitized_entry["artifact"] = artifact
            sanitized_extensions.append(sanitized_entry)

        return cls(
            project_root=Path(project_root_raw),
            swapped_targets=sanitized_targets,
            extensions=sanitized_extensions,
            created_at=created_at,
            version=version,
        )
