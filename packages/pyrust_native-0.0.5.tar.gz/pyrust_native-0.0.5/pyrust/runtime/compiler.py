from __future__ import annotations

import logging
import tempfile
from pathlib import Path
from typing import Protocol, runtime_checkable

logger = logging.getLogger(__name__)

# Límite de seguridad para evitar Resource Exhaustion (10 MB)
MAX_SOURCE_SIZE = 10 * 1024 * 1024


@runtime_checkable
class CompilerStrategy(Protocol):
    """Estrategia para compilar código fuente a una extensión nativa."""
    
    def compile(self, extension_name: str, source: object, work_dir: Path) -> Path:
        """
        Compila el source y devuelve la ruta al artefacto generado.
        
        Args:
            extension_name: Nombre del módulo extensión.
            source: Código fuente (str, bytes, Path).
            work_dir: Directorio temporal para realizar la compilación.
            
        Returns:
            Path al archivo compilado (.pyd/.so).
        """
        ...

class PythonSourceCompiler:
    """Compilador por defecto que trata el source como código Python puro."""
    
    def compile(self, extension_name: str, source: object, work_dir: Path) -> Path:
        target = work_dir / f"{extension_name}.py"
        source_code: str | None = None

        if isinstance(source, Path):
            # Verificación de seguridad: tamaño del archivo
            try:
                if source.stat().st_size > MAX_SOURCE_SIZE:
                    raise ValueError(f"El archivo fuente excede el tamaño máximo permitido ({MAX_SOURCE_SIZE} bytes)")
            except OSError:
                pass  # Si no existe, fallará más adelante o en RuntimeManager

            # Si es un path, simplemente devolvemos el path original si no necesitamos copiar
            # Pero la interfaz dice que usemos work_dir. Para consistencia, copiamos o leemos.
            # El RuntimeManager actual optimiza esto. Aquí asumimos que si es Path, 
            # el RuntimeManager ya decidió si usarlo directo o no. 
            return source

        source_bytes = bytes(source) if isinstance(source, (bytes, bytearray)) else str(source).encode("utf-8")
        if len(source_bytes) > MAX_SOURCE_SIZE:
             raise ValueError(f"El código fuente excede el tamaño máximo permitido ({MAX_SOURCE_SIZE} bytes)")

        if isinstance(source, (bytes, bytearray)):
            try:
                source_code = source.decode("utf-8")
            except UnicodeDecodeError:
                # Binario puro
                target.write_bytes(bytes(source))
                return target
        else:
            source_code = str(source)

        # Validación de sintaxis
        try:
            compile(source_code, str(target), "exec")
        except SyntaxError as exc:
            raise ValueError(
                f"El código fuente proporcionado no es Python válido ({exc}) y no se ha configurado un compilador específico."
            ) from exc
            
        target.write_text(source_code, encoding="utf-8")
        return target
