"""
Runtime Rust/Python (Fases 5–7).

Responsable de cargar extensiones compiladas y realizar el hot-swap de funciones.
"""

from __future__ import annotations

import _ctypes
import atexit
import ctypes
import json
import logging
import re
import shutil
import sys
import tempfile
import time
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from importlib import import_module
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from types import ModuleType
from typing import Callable, Dict, Iterable, List, Optional

from pyrust.cache import CacheManager
from pyrust.runtime.compiler import CompilerStrategy, PythonSourceCompiler
from pyrust.runtime.events import LoggingEventListener, RuntimeEventListener
from pyrust.runtime.types import (
    LastSwapRecord,
    LoadedModule,
    ReloadMetrics,
    ReloadResult,
    _EXTENSION_NAME_PATTERN,
    _WINDOWS_RESERVED_NAMES,
)


def _close_shared_runtime_manager() -> None:
    """Cierra la instancia compartida inicializada vía ``get_runtime_manager``."""

    api_module = sys.modules.get("pyrust.api") or import_module("pyrust.api")
    shutdown_runtime = getattr(api_module, "shutdown_runtime", None)
    if shutdown_runtime is None:
        return

    shutdown_runtime()


class RuntimeManager:
    """
    Gestiona módulos compilados y substitución en caliente.

    Implementación inicial: registro en memoria y carga explícita.
    """

    def __init__(
        self,
        *,
        cache_manager: Optional[CacheManager] = None,
        compiler: Optional[Callable[[str, object], Path]] = None,
        event_hooks: Optional[Dict[str, Iterable[Callable[..., None]]]] = None,
        compiler_strategy: Optional[CompilerStrategy] = None,
        listeners: Optional[List[RuntimeEventListener]] = None,
    ) -> None:
        self._modules: Dict[str, LoadedModule] = {}
        self._logger = logging.getLogger(__name__)
        self._cache = cache_manager or CacheManager()

        # Estrategia de compilación (Patrón Strategy)
        if compiler:
            # Adaptador para retrocompatibilidad
            class _CallableCompilerAdapter(CompilerStrategy):
                def compile(self, extension_name: str, source: object, work_dir: Path) -> Path:
                    return compiler(extension_name, source)

            self._compiler_strategy = _CallableCompilerAdapter()
        else:
            self._compiler_strategy = compiler_strategy or PythonSourceCompiler()

        # Listeners de eventos (Patrón Observer)
        self._listeners: List[RuntimeEventListener] = list(listeners or [])
        if not self._listeners and not event_hooks:
            self._listeners.append(LoggingEventListener())

        self._event_hooks: Dict[str, list[Callable[..., None]]] = {
            key: list(value) for key, value in (event_hooks or {}).items()
        }
        self._swap_count = 0
        self._staging_dir: Path | None = Path(tempfile.mkdtemp(prefix="pyrust_runtime_"))
        self._last_metrics: Optional[ReloadMetrics] = None
        self._lock = threading.RLock()

    def __enter__(self) -> "RuntimeManager":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    @property
    def last_metrics(self) -> Optional[ReloadMetrics]:
        return self._last_metrics

    def add_event_hook(self, event: str, callback: Callable[..., None]) -> None:
        self._event_hooks.setdefault(event, []).append(callback)

    def load_extension(
        self,
        module_name: str,
        path: Optional[Path] = None,
        validate: Optional[Callable[[object], bool]] = None,
    ) -> LoadedModule:
        """Carga un módulo compilado con rollback seguro.

        Si la carga o la validación fallan, el gestor mantiene intacta la
        referencia previa y elimina cualquier rastro del intento fallido.
        """

        if path is None:
            raise ValueError(
                "No se resolvió un artefacto para la extensión; especifica 'path' explícito"
            )

        with self._lock:
            resolved_path = self._validate_extension_path(path)
            previous_loaded = self._modules.get(module_name)
            previous_sys_module = sys.modules.get(module_name)
            rollback_needed = True

            self._logger.info("Iniciando carga transaccional de %s", module_name)
            try:
                module = self._load_module(module_name, resolved_path)

                if validate and not validate(module):
                    raise RuntimeError(f"Validación fallida para {module_name}")

                loaded = LoadedModule(name=module_name, path=resolved_path, module=module)
                self._modules[module_name] = loaded
                sys.modules[module_name] = module

                self._logger.info("%s cargado correctamente; liberando versión previa", module_name)
                if previous_loaded:
                    try:
                        self._cleanup_module(previous_loaded.module)
                    except Exception:
                        self._logger.error(
                            "Fallo en cleanup de %s; revirtiendo al estado previo",
                            module_name,
                            exc_info=True,
                        )
                        raise

                rollback_needed = False

                return loaded
            except Exception as exc:  # pragma: no cover - re-raises
                self._logger.error(
                    "Fallo al cargar %s: %s. Revirtiendo a la versión previa.",
                    module_name,
                    exc,
                )
                if rollback_needed:
                    self._rollback(module_name, previous_loaded, previous_sys_module)
                raise

    def get(self, module_name: str) -> Optional[LoadedModule]:
        with self._lock:
            return self._modules.get(module_name)

    def replace_function(self, owner: object, attr: str, replacement: Callable) -> None:
        setattr(owner, attr, replacement)

    def unload_extension(self, module_name: str) -> bool:
        with self._lock:
            loaded = self._modules.pop(module_name, None)
            module = sys.modules.pop(module_name, None)

            if loaded is None and module is None:
                return False

            if loaded is not None:
                try:
                    self._cleanup_module(loaded.module)
                except Exception:  # pragma: no cover - logging only
                    self._logger.exception("Error liberando módulo %s", module_name)
            return True

    def close(self) -> None:
        """Libera el directorio temporal usado para artefactos en caliente."""
        with self._lock:
            staging_dir = self._staging_dir
            if staging_dir is None:
                return

            try:
                # ignore_errors=True ayuda en Windows si hay archivos bloqueados temporalmente
                shutil.rmtree(staging_dir, ignore_errors=True)
            except Exception as exc:  # pragma: no cover - logging only
                self._logger.error("No se pudo eliminar el staging dir %s: %s", staging_dir, exc)
            finally:
                self._staging_dir = None

    def reload(
        self,
        extension_name: str,
        source: object = None,
        *,
        validate: Optional[Callable[[object], bool]] = None,
        force_recompile: bool = False,
        invalidate_cache: bool = False,
        use_cache: bool = True,
        on_success: Optional[Callable[[str, LoadedModule, ReloadMetrics], None]] = None,
        on_failure: Optional[Callable[[str, Exception, ReloadMetrics], None]] = None,
        on_rollback: Optional[Callable[[str, LoadedModule, ReloadMetrics], None]] = None,
    ) -> ReloadResult:
        """Compila/obtiene una extensión y realiza hot-swap con rollback seguro.

        Los callbacks ``on_success``, ``on_failure`` y ``on_rollback`` reciben
        siempre tres argumentos: ``extension_name``, el payload asociado al
        evento (``LoadedModule`` para éxito/rollback o la ``Exception`` para
        fallo) y ``ReloadMetrics`` con los detalles de la operación.
        """

        with self._lock:
            self._validate_extension_name(extension_name)

            previous_loaded = self._modules.get(extension_name)
            hooks: Dict[str, Iterable[Callable[..., None]]] = {
                "success": [on_success] if on_success else [],
                "failure": [on_failure] if on_failure else [],
                "rollback": [on_rollback] if on_rollback else [],
            }

            start = time.perf_counter()
            used_cache = False
            retry_count = 0
            forced_flag = force_recompile
            source_size = 0
            if source is not None:
                try:
                    payload_chk = self._extract_payload(source)
                    source_size = len(payload_chk) if payload_chk else 0
                except Exception:
                    source_size = 0

            def _compile_and_load(force: bool, invalidate: bool) -> LoadedModule:
                nonlocal used_cache
                artifact, used_cache = self._resolve_artifact(
                    extension_name,
                    source,
                    force_recompile=force,
                    invalidate_cache=invalidate,
                    use_cache=use_cache,
                )
                if artifact is None:
                    raise ValueError(
                        "No se pudo resolver un artefacto para la extensión; proporciona 'source' o caché válida"
                    )
                loaded_module = self.load_extension(extension_name, path=artifact, validate=validate)
                return loaded_module

            try:
                loaded = _compile_and_load(force_recompile, invalidate_cache)
            except Exception as exc:  # pragma: no cover - re-raises
                if used_cache and source is not None and not force_recompile:
                    self._logger.warning(
                        "Carga desde caché de %s falló (%s); reintentando con recompilación",
                        extension_name,
                        exc,
                    )
                    retry_count = 1
                    forced_flag = True
                    try:
                        loaded = _compile_and_load(True, True)
                    except Exception as retry_exc:  # pragma: no cover - re-raises
                        exc = retry_exc
                    else:
                        self._swap_count += 1
                        metrics = ReloadMetrics(
                            duration_s=time.perf_counter() - start,
                            swap_count=self._swap_count,
                            used_cache=False,
                            forced_recompile=True,
                            retry_count=retry_count,
                            source_size_bytes=source_size,
                        )
                        self._last_metrics = metrics
                        self._logger.info(
                            "Recarga de %s completada tras recompilar en %.3fs (swap #%d, reintentos=%d)",
                            extension_name,
                            metrics.duration_s,
                            metrics.swap_count,
                            metrics.retry_count,
                        )
                        self._run_hooks("success", extension_name, metrics, loaded, hooks)
                        return ReloadResult(
                            loaded=loaded,
                            from_cache=False,
                            metrics=metrics,
                            runtime_manager=self,
                        )

                metrics = ReloadMetrics(
                    duration_s=time.perf_counter() - start,
                    swap_count=self._swap_count,
                    used_cache=used_cache,
                    forced_recompile=forced_flag,
                    retry_count=retry_count,
                    failure_cause=str(exc),
                    source_size_bytes=source_size,
                )
                self._last_metrics = metrics
                self._run_hooks("failure", extension_name, metrics, exc, hooks)
                if previous_loaded:
                    self._run_hooks("rollback", extension_name, metrics, previous_loaded, hooks)
                self._logger.error(
                    "Recarga de %s falló tras %.3fs (reintentos=%d): %s",
                    extension_name,
                    metrics.duration_s,
                    metrics.retry_count,
                    exc,
                )
                raise

            self._swap_count += 1
            metrics = ReloadMetrics(
                duration_s=time.perf_counter() - start,
                swap_count=self._swap_count,
                used_cache=used_cache,
                forced_recompile=forced_flag,
                retry_count=retry_count,
                source_size_bytes=source_size,
            )
            self._last_metrics = metrics
            self._logger.info(
                "Recarga de %s completada en %.3fs (swap #%d, cache=%s, reintentos=%d)",
                extension_name,
                metrics.duration_s,
                metrics.swap_count,
                metrics.used_cache,
                metrics.retry_count,
            )
            self._run_hooks("success", extension_name, metrics, loaded, hooks)
            return ReloadResult(
                loaded=loaded,
                from_cache=used_cache,
                metrics=metrics,
                runtime_manager=self,
            )

    def _load_module(self, module_name: str, path: Optional[Path]) -> ModuleType:
        previous_sys_module = sys.modules.get(module_name)
        if path is None:
            raise ValueError(
                "No se resolvió un artefacto para la extensión; especifica 'path' explícito"
            )

        spec = spec_from_file_location(module_name, path)
        if spec is None or spec.loader is None:
            raise ImportError(f"No se pudo crear un spec para {module_name} desde {path}")

        module = module_from_spec(spec)
        sys.modules[module_name] = module
        try:
            spec.loader.exec_module(module)
        except Exception:
            if previous_sys_module is None:
                sys.modules.pop(module_name, None)
            else:
                sys.modules[module_name] = previous_sys_module
            raise
        return module

    def _validate_extension_path(self, path: Path) -> Path:
        if not isinstance(path, Path):
            try:
                path = Path(path)
            except TypeError as exc:
                reason = "Ruta del artefacto inválida: se esperaba un Path válido"
                self._logger.error("Rechazando carga de extensión: %s", reason)
                raise ValueError(reason) from exc

        try:
            resolved = path.resolve(strict=False)
        except OSError as exc:
            reason = f"No se pudo resolver la ruta del artefacto '{path}': {exc}"
            self._logger.error("Rechazando carga de extensión: %s", reason)
            raise ValueError(reason) from exc

        staging_dir = self._staging_dir
        try:
            cache_dir = self._cache._cache_dir.resolve(strict=False)
        except OSError:
            cache_dir = self._cache._cache_dir

        allowed = False
        staging_desc = "no disponible"
        if staging_dir is not None:
            try:
                staging_resolved = staging_dir.resolve(strict=False)
            except OSError:
                staging_resolved = staging_dir
            staging_desc = str(staging_resolved)
            allowed = resolved.is_relative_to(staging_resolved)

        if not allowed:
            allowed = resolved.is_relative_to(cache_dir)

        if not allowed:
            reason = (
                "Ruta del artefacto fuera de los directorios permitidos "
                f"(staging={staging_desc}, cache={cache_dir}): {resolved}"
            )
            self._logger.error("Rechazando carga de extensión: %s", reason)
            raise ValueError(reason)

        return resolved

    def _cleanup_module(self, module: object) -> None:
        cleanup_hook = getattr(module, "__pyrust_cleanup__", None) or getattr(
            module, "__pyrust_release__", None
        )
        if callable(cleanup_hook):
            try:
                cleanup_hook()
            except Exception as exc:  # pragma: no cover - logging only
                self._logger.warning("Cleanup falló en %s: %s", module, exc)

        for name, value in vars(module).items():
            close_method = getattr(value, "close", None)
            if callable(close_method):
                try:
                    close_method()
                    continue
                except Exception as exc:  # pragma: no cover - logging only
                    self._logger.warning("No se pudo cerrar %s: %s", name, exc)

            if isinstance(value, ctypes.CDLL):
                try:
                    if sys.platform == "win32":
                        ctypes.windll.kernel32.FreeLibrary(value._handle)
                    else:
                        _ctypes.dlclose(value._handle)
                except Exception as exc:  # pragma: no cover - logging only
                    self._logger.warning("No se pudo liberar handle de %s: %s", name, exc)

    def _rollback(
        self,
        module_name: str,
        previous_loaded: Optional[LoadedModule],
        previous_sys_module: Optional[ModuleType],
    ) -> None:
        if previous_loaded:
            self._modules[module_name] = previous_loaded
        else:
            self._modules.pop(module_name, None)

        if previous_sys_module is not None:
            sys.modules[module_name] = previous_sys_module
        else:
            sys.modules.pop(module_name, None)

    @staticmethod
    def _validate_extension_name(extension_name: str) -> None:
        if not isinstance(extension_name, str) or not extension_name:
            raise ValueError("Nombre de extensión inválido: se requiere una cadena no vacía")

        if not _EXTENSION_NAME_PATTERN.fullmatch(extension_name):
            raise ValueError(
                "Nombre de extensión inválido: solo se permiten caracteres A-Z, a-z, 0-9 y _"
            )

        if extension_name.upper() in _WINDOWS_RESERVED_NAMES:
            raise ValueError(
                "Nombre de extensión inválido: no puede usar nombres reservados del sistema"
            )
    def _resolve_artifact(
        self,
        extension_name: str,
        source: object,
        *,
        force_recompile: bool,
        invalidate_cache: bool,
        use_cache: bool,
    ) -> tuple[Optional[Path], bool]:
        with self._lock:
            self._validate_extension_name(extension_name)

            safe_extension_name = extension_name

            if invalidate_cache:
                self._cache.invalidate(safe_extension_name)

            cached_entry = None
            if use_cache and not force_recompile:
                cached_entry = self._cache.fetch_from_metadata(safe_extension_name)

            try:
                payload = self._extract_payload(source)
            except OSError as exc:
                if cached_entry:
                    self._logger.warning(
                        "No se pudo leer el source de %s; reutilizando artefacto cacheado: %s",
                        extension_name,
                        exc,
                    )
                    return cached_entry.artifact, True
                raise RuntimeError(
                    "No se pudo leer el source y no hay caché válido disponible para "
                    f"'{extension_name}'"
                ) from exc

            if use_cache and not force_recompile and payload is not None:
                cached = self._cache.fetch(safe_extension_name, payload)
                if cached:
                    return cached.artifact, True

            if cached_entry and source is None and use_cache and not force_recompile:
                return cached_entry.artifact, True

            if source is None:
                return None, False

            artifact = self._compiler_strategy.compile(
                safe_extension_name, source, self._ensure_staging_dir()
            )
            if not use_cache and isinstance(source, Path):
                try:
                    resolved_artifact = artifact.resolve()
                except OSError:
                    resolved_artifact = artifact

                staging_dir = self._ensure_staging_dir()
                try:
                    staging_resolved = staging_dir.resolve(strict=False)
                except OSError:
                    staging_resolved = staging_dir

                try:
                    cache_dir = self._cache._cache_dir.resolve(strict=False)
                except OSError:
                    cache_dir = self._cache._cache_dir

                if not (
                    resolved_artifact.is_relative_to(staging_resolved)
                    or resolved_artifact.is_relative_to(cache_dir)
                ):
                    digest = self._cache.hash_payload(payload)
                    artifact = self._stage_artifact(artifact, safe_extension_name, digest)
            if use_cache and payload is not None:
                cached_artifact = artifact
                try:
                    resolved_artifact = artifact.resolve()
                except OSError:
                    resolved_artifact = artifact

                if not resolved_artifact.is_relative_to(self._cache._cache_dir):
                    digest = self._cache.hash_payload(payload)
                    cached_artifact = (
                        self._cache._cache_dir
                        / f"{safe_extension_name}_{digest}{resolved_artifact.suffix or '.py'}"
                    )
                    cached_artifact.parent.mkdir(parents=True, exist_ok=True)
                    try:
                        shutil.copy2(artifact, cached_artifact)
                    except OSError as exc:  # pragma: no cover - exercised via tests
                        self._logger.warning(
                            "No se pudo copiar el artefacto de %s a la caché: %s",
                            extension_name,
                            exc,
                        )
                        artifact = self._stage_artifact(
                            artifact,
                            safe_extension_name,
                            digest,
                        )
                    else:
                        stored = self._cache.store(
                            safe_extension_name, payload, cached_artifact
                        )
                        if stored:
                            artifact = stored.artifact
                else:
                    stored = self._cache.store(safe_extension_name, payload, cached_artifact)
                    if stored:
                        artifact = stored.artifact

            return artifact, False

    def _extract_payload(self, source: object) -> Optional[bytes | str]:
        if source is None:
            return None

        if isinstance(source, Path):
            return source.read_bytes()

        if isinstance(source, (bytes, bytearray)):
            return bytes(source)

        return str(source)

    def _ensure_staging_dir(self) -> Path:
        with self._lock:
            if self._staging_dir is None:
                self._staging_dir = Path(tempfile.mkdtemp(prefix="pyrust_runtime_"))
            return self._staging_dir

    def _stage_artifact(self, artifact: Path, extension_name: str, digest: str) -> Path:
        try:
            resolved = artifact.resolve(strict=False)
        except OSError:
            resolved = artifact

        staging_dir = self._ensure_staging_dir()
        try:
            staging_resolved = staging_dir.resolve(strict=False)
        except OSError:
            staging_resolved = staging_dir

        if resolved.is_relative_to(staging_resolved):
            return resolved

        suffix = resolved.suffix or ".py"
        staged = staging_dir / f"{extension_name}_{digest}{suffix}"
        staged.write_bytes(resolved.read_bytes())
        return staged

    def _run_hooks(
        self,
        event: str,
        extension_name: str,
        metrics: ReloadMetrics,
        payload: object,
        local_hooks: Dict[str, Iterable[Callable[..., None]]],
    ) -> None:
        # 1. Notificar a los Listeners (Patrón Observer)
        for listener in self._listeners:
            try:
                if event == "success" and isinstance(payload, LoadedModule):
                    listener.on_success(extension_name, payload, metrics)
                elif event == "failure" and isinstance(payload, BaseException):
                    listener.on_failure(extension_name, payload, metrics)
                elif event == "rollback" and isinstance(payload, LoadedModule):
                    listener.on_rollback(extension_name, payload, metrics)
            except Exception as exc:  # pragma: no cover - logging only
                self._logger.warning("Listener %s falló para %s: %s", listener, extension_name, exc)

        # 2. Notificar a los Hooks legacy (Retrocompatibilidad)
        callbacks = [
            *(self._event_hooks.get(event, []) or []),
            *(local_hooks.get(event, []) or []),
        ]
        for callback in callbacks:
            try:
                callback(extension_name, payload, metrics)
            except Exception as exc:  # pragma: no cover - logging only
                self._logger.warning("Hook '%s' falló para %s: %s", event, extension_name, exc)


def is_valid_extension_name(extension_name: object) -> bool:
    if not isinstance(extension_name, str):
        return False
    try:
        RuntimeManager._validate_extension_name(extension_name)
    except ValueError:
        return False
    return True


def reload_extension(
    extension_name: str,
    source: object = None,
    *,
    cache_dir: str | Path | None = None,
    cache_manager: CacheManager | None = None,
    compiler: Optional[Callable[[str, object], Path]] = None,
    event_hooks: Optional[Dict[str, Iterable[Callable[..., None]]]] = None,
    compiler_strategy: Optional[CompilerStrategy] = None,
    listeners: Optional[List[RuntimeEventListener]] = None,
    runtime_manager: "RuntimeManager | None" = None,
    validate: Optional[Callable[[object], bool]] = None,
    force_recompile: bool = False,
    invalidate_cache: bool = False,
    use_cache: bool = True,
    on_success: Optional[Callable[[str, LoadedModule, ReloadMetrics], None]] = None,
    on_failure: Optional[Callable[[str, Exception, ReloadMetrics], None]] = None,
    on_rollback: Optional[Callable[[str, LoadedModule, ReloadMetrics], None]] = None,
) -> ReloadResult:
    """Fachada sencilla para recargar extensiones con hot-swap seguro.

    Si no se proporciona ``runtime_manager`` se crea una instancia temporal
    configurada con las opciones de caché y compilador suministradas. Devuelve
    el :class:`ReloadResult` producido por :meth:`RuntimeManager.reload`,
    incluyendo una referencia al gestor utilizado en ``runtime_manager``.

    Los callbacks opcionales ``on_success``, ``on_failure`` y ``on_rollback``
    reciben siempre ``extension_name``, el payload del evento (``LoadedModule``
    o la ``Exception``) y los ``ReloadMetrics`` correspondientes.
    """

    if runtime_manager is not None and any(
        option is not None
        for option in (
            cache_dir,
            cache_manager,
            compiler,
            event_hooks,
            compiler_strategy,
            listeners,
        )
    ):
        raise ValueError(
            "No se pueden mezclar 'runtime_manager' existente con opciones de inicialización"
        )

    manager = runtime_manager
    if manager is None:
        resolved_cache = cache_manager
        if resolved_cache is None:
            resolved_cache = CacheManager(cache_dir=Path(cache_dir) if cache_dir else None)

        manager = RuntimeManager(
            cache_manager=resolved_cache,
            compiler=compiler,
            event_hooks=event_hooks,
            compiler_strategy=compiler_strategy,
            listeners=listeners,
        )

    manager._validate_extension_name(extension_name)

    return manager.reload(
        extension_name,
        source=source,
        validate=validate,
        force_recompile=force_recompile,
        invalidate_cache=invalidate_cache,
        use_cache=use_cache,
        on_success=on_success,
        on_failure=on_failure,
        on_rollback=on_rollback,
    )


_LAST_SWAP_DIRNAME = ".pyrust"
_LAST_SWAP_FILENAME = "last_swap.json"
_RUNTIME_LOGGER = logging.getLogger(__name__)


def _swap_registry_path(base_dir: Path | None = None) -> Path:
    root = Path(base_dir) if base_dir else Path.cwd()
    return root / _LAST_SWAP_DIRNAME / _LAST_SWAP_FILENAME


def expected_project_root_for_record(record_path: Path) -> Path:
    """Deriva la raíz esperada del proyecto desde `.pyrust/last_swap.json`."""

    return record_path.parent.parent


def _swap_registry_path_is_link(path: Path) -> bool:
    try:
        stats = path.lstat()
    except FileNotFoundError:
        return False
    except OSError:
        _RUNTIME_LOGGER.warning(
            "No se pudo inspeccionar '%s' para validar enlaces de intercambio", path
        )
        return True

    return path.is_symlink() or stats.st_nlink > 1


def find_last_swap_record(start_dir: Path | None = None) -> Path | None:
    start = Path(start_dir) if start_dir else Path.cwd()
    for candidate in (start, *start.parents):
        path = candidate / _LAST_SWAP_DIRNAME / _LAST_SWAP_FILENAME
        if path.exists():
            return path
    return None


def write_last_swap_record(record: LastSwapRecord, *, base_dir: Path | None = None) -> Path:
    path = _swap_registry_path(base_dir or record.project_root)
    tmp_path = path.with_suffix(".tmp")
    try:
        if path.parent.is_symlink():
            _RUNTIME_LOGGER.warning(
                "El directorio del registro de swap es un enlace simbólico; evitando escritura"
            )
            return path
    except OSError:
        _RUNTIME_LOGGER.warning(
            "No se pudo inspeccionar '%s' para validar enlaces de intercambio", path.parent
        )
        return path
    path.parent.mkdir(parents=True, exist_ok=True)
    if _swap_registry_path_is_link(path):
        _RUNTIME_LOGGER.warning(
            "El registro de swap es un enlace simbólico o duro; evitando escritura"
        )
        return path
    if _swap_registry_path_is_link(tmp_path):
        _RUNTIME_LOGGER.warning(
            "El registro temporal de swap es un enlace simbólico o duro; evitando escritura"
        )
        return path

    tmp_path.write_text(
        json.dumps(record.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    tmp_path.replace(path)
    return path


def read_last_swap_record(start_dir: Path | None = None) -> tuple[LastSwapRecord | None, Path | None]:
    path = find_last_swap_record(start_dir)
    if path is None:
        return None, None
    if _swap_registry_path_is_link(path):
        _RUNTIME_LOGGER.warning(
            "El registro de swap es un enlace simbólico o duro; evitando lectura"
        )
        return None, path
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        _RUNTIME_LOGGER.warning("No se pudo leer el registro de swap: %s", exc)
        return None, path
    try:
        record = LastSwapRecord.from_dict(payload)
    except ValueError as exc:
        _RUNTIME_LOGGER.warning("No se pudo leer el registro de swap: %s", exc)
        return None, path
    return record, path


def clear_last_swap_record(start_dir: Path | None = None) -> bool:
    path = find_last_swap_record(start_dir)
    if path is None:
        return False
    if _swap_registry_path_is_link(path):
        _RUNTIME_LOGGER.warning(
            "El registro de swap es un enlace simbólico o duro; evitando borrado"
        )
        return False
    path.unlink()
    return True


def record_last_swap(
    *,
    project_root: Path,
    swapped_targets: Iterable[str],
    reloads: Iterable[ReloadResult],
) -> Path:
    record = LastSwapRecord(
        project_root=project_root.resolve(),
        swapped_targets=list(swapped_targets),
        extensions=[
            {"name": result.loaded.name, "artifact": str(result.loaded.path)}
            for result in reloads
        ],
        created_at=datetime.now(timezone.utc).isoformat(),
    )
    return write_last_swap_record(record, base_dir=project_root)


atexit.register(_close_shared_runtime_manager)


__all__ = [
    "LoadedModule",
    "LastSwapRecord",
    "ReloadMetrics",
    "ReloadResult",
    "RuntimeManager",
    "clear_last_swap_record",
    "expected_project_root_for_record",
    "find_last_swap_record",
    "is_valid_extension_name",
    "read_last_swap_record",
    "record_last_swap",
    "reload_extension",
    "write_last_swap_record",
]
