"""
Módulo para persistir los cambios de rustyficación en el código fuente.
"""
from __future__ import annotations

import ast
import logging
import shutil
import sys
from pathlib import Path
from typing import List, Optional

from pyrust.api import AutoRustyficationReport, _extension_name_from_target, _split_target

logger = logging.getLogger(__name__)


def persist_rustyfication(report: AutoRustyficationReport) -> None:
    """
    Aplica los cambios de rustyficación de forma persistente en el proyecto.
    
    1. Crea un paquete `pyrust_extensions` en la raíz del proyecto.
    2. Copia las extensiones compiladas a ese paquete.
    3. Modifica los archivos fuente originales para usar las extensiones,
       manteniendo copias de seguridad (.bak).
    """
    if not report.swapped_targets:
        logger.info("No hay targets para persistir.")
        return

    project_root = report.project_root
    extensions_dir = project_root / "pyrust_extensions"
    extensions_dir.mkdir(exist_ok=True)
    (extensions_dir / "__init__.py").touch(exist_ok=True)

    # Mapa de archivo -> lista de (target, extensión_copiada)
    changes_by_file = {}

    for target in report.swapped_targets:
        # Encontrar el resultado de recarga correspondiente
        reload_result = next((r for r in report.reloaded if r.loaded.name in target or target in str(r.loaded.path)), None)
        # Búsqueda más robusta: el target está en swapped_targets, necesitamos el reload_result asociado
        # En _auto_select_and_reload, guardamos swapped_reload_results[result.target] = reload_result
        # Pero report.reloaded es una lista. Podemos inferirlo por el nombre del módulo cargado.
        
        # Mejor estrategia: usar report.transpilation para obtener el nombre de la extensión generado
        # o simplemente iterar report.reloaded y ver cuál corresponde.
        # Dado que _auto_select_and_reload no expone el mapeo directo en el reporte público fácilmente,
        # vamos a confiar en que el nombre del módulo cargado contiene el hash del target.
        
        # Simplificación: iterar reloaded y buscar coincidencia parcial o usar la lógica de nombres.
        # _extension_name_from_target es determinista.
        ext_name = _extension_name_from_target(target, project_root)
        
        reload_result = next((r for r in report.reloaded if r.loaded.name == ext_name), None)
        
        if not reload_result:
            logger.warning(f"No se encontró el resultado de recarga para {target}, saltando persistencia.")
            continue

        src_ext_path = reload_result.loaded.path
        if not src_ext_path.exists():
            logger.warning(f"El archivo de extensión {src_ext_path} no existe, saltando.")
            continue

        # Copiar extensión
        dest_ext_path = extensions_dir / src_ext_path.name
        shutil.copy2(src_ext_path, dest_ext_path)
        logger.info(f"Extensión copiada: {dest_ext_path.name}")

        file_part, func_name = _split_target(target)
        abs_file_path = (project_root / file_part).resolve()
        
        if abs_file_path not in changes_by_file:
            changes_by_file[abs_file_path] = []
        
        changes_by_file[abs_file_path].append({
            "target": target,
            "func_name": func_name.split(".")[-1], # Solo el nombre de la función
            "ext_module_name": f"pyrust_extensions.{src_ext_path.stem}",
            "ext_func_name": func_name.split(".")[-1] # Asumimos mismo nombre en extensión
        })

    # Aplicar parches a archivos fuente
    for file_path, changes in changes_by_file.items():
        _patch_source_file(file_path, changes)


def _patch_source_file(file_path: Path, changes: List[dict]) -> None:
    """
    Modifica un archivo fuente Python para inyectar las extensiones Rust.
    Crea un backup .bak antes de modificar.
    """
    if not file_path.exists():
        logger.warning(f"Archivo fuente no encontrado: {file_path}")
        return

    # Crear backup
    backup_path = file_path.with_suffix(".py.bak")
    shutil.copy2(file_path, backup_path)
    logger.info(f"Backup creado: {backup_path}")

    try:
        source = file_path.read_text(encoding="utf-8")
        tree = ast.parse(source)
    except Exception as e:
        logger.error(f"Error parseando {file_path}: {e}")
        return

    # Transformador AST
    class RustInjector(ast.NodeTransformer):
        def __init__(self, changes):
            self.changes = {c["func_name"]: c for c in changes}
            self.imports_added = False
            self.in_class = False

        def visit_ClassDef(self, node):
            old_in_class = self.in_class
            self.in_class = True
            self.generic_visit(node)
            self.in_class = old_in_class
            return node

        def visit_FunctionDef(self, node):
            if node.name in self.changes:
                change = self.changes[node.name]
                ext_mod = change["ext_module_name"]
                ext_func = change["ext_func_name"]
                
                func_name = node.name
                original_name = f"_py_{func_name}"
                
                # Si estamos en una clase, usamos estrategia de wrapper para preservar 'self' y decoradores
                if self.in_class:
                    rust_impl_name = f"_rust_impl_{func_name}"
                    
                    # 1. Nodo de importación (define _rust_impl o None)
                    import_node = ast.ImportFrom(
                        module=ext_mod,
                        names=[ast.alias(name=ext_func, asname=rust_impl_name)],
                        level=0
                    )
                    
                    fallback_assign = ast.Assign(
                        targets=[ast.Name(id=rust_impl_name, ctx=ast.Store())],
                        value=ast.Constant(value=None)
                    )
                    
                    print_error = ast.Expr(
                        value=ast.Call(
                            func=ast.Name(id="print", ctx=ast.Load()),
                            args=[
                                ast.Constant(value=f"PyRust warning: failed to load extension for {func_name}:"),
                                ast.Name(id="e", ctx=ast.Load())
                            ],
                            keywords=[]
                        )
                    )

                    try_node = ast.Try(
                        body=[import_node],
                        handlers=[
                            ast.ExceptHandler(
                                type=ast.Name(id="ImportError", ctx=ast.Load()),
                                name="e",
                                body=[print_error, fallback_assign]
                            )
                        ],
                        orelse=[],
                        finalbody=[]
                    )
                    
                    # 2. Wrapper function
                    # Lógica diferenciada según decoradores:
                    # - classmethod: __class__._py_func(*args[1:], **kwargs)
                    # - staticmethod/instance: __class__._py_func(*args, **kwargs)
                    
                    is_classmethod = any(
                        isinstance(d, ast.Name) and d.id == "classmethod" 
                        for d in node.decorator_list
                    )
                    
                    # Argumentos para llamar al original
                    orig_args = []
                    if is_classmethod:
                         # Slice args[1:]
                         orig_args = [
                             ast.Starred(
                                 value=ast.Subscript(
                                     value=ast.Name(id="args", ctx=ast.Load()),
                                     slice=ast.Slice(
                                         lower=ast.Constant(value=1),
                                         upper=None,
                                         step=None
                                     ),
                                     ctx=ast.Load()
                                 ),
                                 ctx=ast.Load()
                             )
                         ]
                    else:
                         orig_args = [ast.Starred(value=ast.Name(id="args", ctx=ast.Load()), ctx=ast.Load())]

                    call_rust = ast.Return(
                        value=ast.Call(
                            func=ast.Name(id="_rust_impl", ctx=ast.Load()),
                            args=[ast.Starred(value=ast.Name(id="args", ctx=ast.Load()), ctx=ast.Load())],
                            keywords=[ast.keyword(arg=None, value=ast.Name(id="kwargs", ctx=ast.Load()))]
                        )
                    )
                    
                    # Fallback usando __class__
                    call_py = ast.Return(
                        value=ast.Call(
                            func=ast.Attribute(
                                value=ast.Name(id="__class__", ctx=ast.Load()),
                                attr=original_name,
                                ctx=ast.Load()
                            ),
                            args=orig_args,
                            keywords=[ast.keyword(arg=None, value=ast.Name(id="kwargs", ctx=ast.Load()))]
                        )
                    )
                    
                    wrapper_body = [
                        ast.If(
                            test=ast.Name(id="_rust_impl", ctx=ast.Load()),
                            body=[call_rust],
                            orelse=[call_py]
                        )
                    ]
                    
                    wrapper = ast.FunctionDef(
                        name=func_name,
                        args=ast.arguments(
                            posonlyargs=[],
                            args=[],
                            vararg=ast.arg(arg="args", annotation=None),
                            kwonlyargs=[ast.arg(arg="_rust_impl", annotation=None)],
                            kw_defaults=[ast.Name(id=rust_impl_name, ctx=ast.Load())],
                            kwarg=ast.arg(arg="kwargs", annotation=None),
                            defaults=[]
                        ),
                        body=wrapper_body,
                        decorator_list=node.decorator_list, # Transferir decoradores
                        returns=None
                    )
                    
                    # 3. Modificar nodo original
                    node.name = original_name
                    node.decorator_list = [] # Quitar decoradores del original
                    
                    return [node, try_node, wrapper]

                else:
                    # Estrategia para funciones globales (asignación directa)
                    node.name = original_name
                    
                    import_node = ast.ImportFrom(
                        module=ext_mod,
                        names=[ast.alias(name=ext_func, asname=func_name)],
                        level=0
                    )
                    
                    fallback_node = ast.Assign(
                        targets=[ast.Name(id=func_name, ctx=ast.Store())],
                        value=ast.Name(id=original_name, ctx=ast.Load())
                    )
                    
                    print_error = ast.Expr(
                        value=ast.Call(
                            func=ast.Name(id="print", ctx=ast.Load()),
                            args=[
                                ast.Constant(value=f"PyRust warning: failed to load extension for {func_name}:"),
                                ast.Name(id="e", ctx=ast.Load())
                            ],
                            keywords=[]
                        )
                    )

                    try_node = ast.Try(
                        body=[import_node],
                        handlers=[
                            ast.ExceptHandler(
                                type=ast.Name(id="ImportError", ctx=ast.Load()),
                                name="e",
                                body=[
                                    print_error,
                                    fallback_node
                                ]
                            )
                        ],
                        orelse=[],
                        finalbody=[]
                    )

                    return [node, try_node]
            
            return node

    # Aplicar transformación
    transformer = RustInjector(changes)
    new_tree = transformer.visit(tree)
    ast.fix_missing_locations(new_tree)

    # Escribir archivo modificado
    # Nota: ast.unparse (Python 3.9+) pierde comentarios. 
    # Es un trade-off aceptable dado que tenemos backup.
    try:
        if sys.version_info >= (3, 9):
            new_source = ast.unparse(new_tree)
        else:
            # Fallback para < 3.9 (aunque el proyecto requiere >= 3.10 según pyproject si mal no recuerdo)
            import astunparse
            new_source = astunparse.unparse(new_tree)
            
        file_path.write_text(new_source, encoding="utf-8")
        logger.info(f"Archivo parcheado guardado: {file_path}")
    except Exception as e:
        logger.error(f"Error escribiendo archivo parcheado {file_path}: {e}")
        # Restaurar backup en caso de error catastrófico de escritura
        shutil.copy2(backup_path, file_path)

