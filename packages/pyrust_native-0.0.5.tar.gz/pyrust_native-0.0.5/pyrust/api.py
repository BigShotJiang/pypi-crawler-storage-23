"""
API pública de PyRust.

Siguiendo la hoja de ruta, este módulo expone puntos de entrada mínimos y define
stubs que se ampliarán en fases posteriores. Incluye la API de análisis de
rustificabilidad y el perfilador inicial.
"""

from __future__ import annotations

import ast
import hashlib
import importlib
import keyword
import logging
import os
import re
import sys
import threading
from collections import Counter
from contextlib import contextmanager, suppress
from dataclasses import dataclass, field
from importlib import import_module
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Dict, Iterable, List, Optional, cast

from .analyzer import AnalysisResult, Analyzer, Rustyfiability
from .cache import CacheManager
from .profiler import ProfileSummary, Profiler
from .runtime import (
    LoadedModule,
    ReloadMetrics,
    ReloadResult,
    RuntimeManager,
    is_valid_extension_name,
    expected_project_root_for_record,
    read_last_swap_record,
    record_last_swap,
)
from .transpiler import IRFunction, IRValidationError, RustTemplateBackend, Transpiler, TranspilerBackend

_FORCE_PYTHON_FALLBACK = os.environ.get("PYRUST_FORCE_PYTHON_FALLBACK", "").lower() in {
    "1",
    "true",
    "yes",
}

_native: ModuleType | None
try:
    if _FORCE_PYTHON_FALLBACK:
        raise ImportError("PYRUST_FORCE_PYTHON_FALLBACK activo; se usará la ruta Python.")
    from . import _native  # type: ignore
except ImportError:  # pragma: no cover - entornos sin compilación de Rust o forzado
    _native = None

_runtime_manager: RuntimeManager | None = None
_runtime_lock = threading.RLock()


def _split_target(target: str) -> tuple[str, str]:
    file_part, _, qualified = target.rpartition(":")
    return file_part, qualified


@dataclass(slots=True)
class AnalysisSummary:
    """
    Resumen agregado del análisis de rustyficabilidad.

    Incluye los conteos por veredicto, agrupación por archivo y listas
    separadas de objetivos parcialmente compatibles ("quick wins") o
    bloqueantes (rutas a refactorizar).
    """

    results: List[AnalysisResult]
    counts: Dict[Rustyfiability, int]
    partial: List[AnalysisResult]
    blockers: List[AnalysisResult]
    grouped_by_file: Dict[str, List[AnalysisResult]]

    @property
    def total_targets(self) -> int:
        return len(self.results)

    @property
    def refactor_targets(self) -> List[str]:
        return [result.target for result in self.blockers]

    @property
    def quick_win_targets(self) -> List[str]:
        return [result.target for result in self.partial]

    @property
    def total_reasons(self) -> int:
        return sum(len(result.reasons) for result in self.results)

    def _serialize_result(self, result: AnalysisResult) -> Dict[str, Any]:
        return {
            "target": result.target,
            "verdict": result.verdict.name,
            "reasons": list(result.reasons),
        }

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_targets": self.total_targets,
            "counts": {verdict.name: self.counts.get(verdict, 0) for verdict in Rustyfiability},
            "partial": [self._serialize_result(result) for result in self.partial],
            "blockers": [self._serialize_result(result) for result in self.blockers],
            "refactor_targets": list(self.refactor_targets),
            "quick_wins": [
                {"target": result.target, "headline": (result.reasons[0] if result.reasons else "")}
                for result in self.partial
            ],
            "grouped_by_file": {
                file_path: [self._serialize_result(result) for result in grouped]
                for file_path, grouped in self.grouped_by_file.items()
            },
            "results": [self._serialize_result(result) for result in self.results],
        }

    def to_table(self, *, limit: Optional[int], show_reasons: bool) -> str:
        lines: List[str] = []
        lines.append("Resumen de rusticabilidad")
        lines.append(f"Total de objetivos analizados: {self.total_targets}")
        if show_reasons:
            lines.append(f"Total de razones registradas: {self.total_reasons}")
        lines.append("")
        lines.append("Conteos por veredicto:")
        for verdict in Rustyfiability:
            lines.append(f"  - {verdict.name:<7}: {self.counts.get(verdict, 0)}")

        def render_section(title: str, items: list[AnalysisResult]) -> None:
            lines.append("")
            lines.append(title)
            if not items:
                lines.append("  (sin elementos)")
                return

            display = items if limit is None else items[:limit]
            for result in display:
                lines.append(f"  - {result.target} [{result.verdict.name}]")
                if result.reasons:
                    if show_reasons:
                        for reason in result.reasons:
                            lines.append(f"      - {reason}")
                    else:
                        lines.append(f"      > {result.reasons[0]}")

            if limit is not None and len(items) > limit:
                lines.append(f"  ... {len(items) - limit} más")

        render_section("Objetivos parcialmente convertibles (quick wins)", self.partial)
        render_section("Bloqueantes (requieren refactor)", self.blockers)

        return "\n".join(lines)

    def to_markdown(self, *, limit: Optional[int], show_reasons: bool) -> str:
        lines: List[str] = []
        lines.append("# Informe de rusticabilidad")
        lines.append(f"- Objetivos analizados: {self.total_targets}")
        lines.append("- Resumen generado por pyrust.analyzer")
        lines.append("")
        lines.append("## Conteo por veredicto")
        for verdict in Rustyfiability:
            lines.append(f"- {verdict.name}: {self.counts.get(verdict, 0)}")

        def render_section(title: str, items: list[AnalysisResult]) -> None:
            lines.append("")
            lines.append(f"## {title}")
            if not items:
                lines.append("- (sin elementos)")
                return

            display = items if limit is None else items[:limit]
            for result in display:
                headline = result.reasons[0] if result.reasons else ""
                lines.append(f"- **{result.target}** — {result.verdict.name}: {headline}")
                if show_reasons and result.reasons:
                    for reason in result.reasons:
                        lines.append(f"  - {reason}")
            if limit is not None and len(items) > limit:
                lines.append(f"- ... {len(items) - limit} más")

        render_section("Quick wins (parciales)", self.partial)
        render_section("Bloqueos a refactorizar", self.blockers)

        lines.append("")
        lines.append("## Detalle por archivo")
        if not self.grouped_by_file:
            lines.append("- (sin archivos analizados)")
        else:
            for file_path, grouped in sorted(self.grouped_by_file.items()):
                lines.append(f"- **{file_path}**")
                detail = grouped if limit is None else grouped[:limit]
                for result in detail:
                    _, target_name = _split_target(result.target)
                    lines.append(
                        f"  - `{target_name}` → {result.verdict.name}"
                        + (f" ({result.reasons[0]})" if result.reasons else "")
                    )
                if limit is not None and len(grouped) > limit:
                    lines.append(f"  - ... {len(grouped) - limit} más en este archivo")

        return "\n".join(lines)


def hello() -> str:
    """
    Devuelve un saludo básico.

    Si el módulo nativo está disponible se usa como verificación rápida de
    compilación Rust; en caso contrario se responde desde Python.
    """

    if _native:
        return cast(Any, _native).hello()
    return "hello from pyrust (python fallback)"


def add(a: int, b: int) -> int:
    """
    Ejemplo de función compartida (Python + Rust) para validar la integración.
    """

    if _native:
        return int(cast(Any, _native).add(int(a), int(b)))
    return int(a) + int(b)


def analyze_project(
    path: str | Path, *, excluded_dirs: list[str | Path] | None = None
) -> list[AnalysisResult]:
    """
    Fase 3: análisis de rustyficabilidad.

    Recorre un archivo o directorio Python y clasifica cada función en términos
    de compatibilidad con la conversión a Rust. ``excluded_dirs`` permite
    omitir rutas por nombre de segmento.
    """

    analyzer = Analyzer()
    exclusions = [str(item) for item in (excluded_dirs or [])]
    return analyzer.analyze_path(Path(path), excluded_dirs=exclusions)


def analyze_summary(
    path: str | Path, *, excluded_dirs: list[str | Path] | None = None
) -> AnalysisSummary:
    """
    Ejecuta :func:`analyze_project` y devuelve un resumen agregado.

    El resumen incluye conteos por :class:`Rustyfiability` y listas de
    objetivos parcialmente convertibles o bloqueantes (veredicto ``NO``).
    """

    results = analyze_project(path, excluded_dirs=excluded_dirs)
    counts: Counter[Rustyfiability] = Counter(result.verdict for result in results)
    for verdict in Rustyfiability:
        counts.setdefault(verdict, 0)

    partial = [result for result in results if result.verdict is Rustyfiability.PARTIAL]
    blockers = [result for result in results if result.verdict is Rustyfiability.NO]

    grouped: Dict[str, List[AnalysisResult]] = {}
    for result in results:
        file_path, _ = _split_target(result.target)
        grouped.setdefault(file_path, []).append(result)

    return AnalysisSummary(
        results=results,
        counts=dict(counts),
        partial=partial,
        blockers=blockers,
        grouped_by_file=grouped,
    )


def profile_project(
    path: str | Path,
    *,
    entrypoint: Optional[str | Path] = None,
    allow_external_entrypoint: bool = False,
    command: Optional[Callable[[], object]] = None,
    limit: int | None = None,
    use_sys_profile: bool = True,
    include_stdlib: bool = False,
    include_site_packages: bool = False,
    excluded_dirs: list[str | Path] | None = None,
    output_path: str | Path | None = None,
) -> ProfileSummary:
    """
    Fase 2: perfilado automático.

    Esta función delega en :class:`Profiler` y servirá como API pública para
    identificar hotspots. ``include_stdlib`` controla si se mantienen las
    funciones de la biblioteca estándar en el resumen: con ``cProfile`` también
    activa/desactiva builtins (p. ej., ``time.sleep``), mientras que el hook de
    ``sys.setprofile`` solo rastrea funciones Python (las builtins no emiten
    eventos aunque se habilite). ``include_site_packages`` opta por mantener o
    filtrar dependencias de terceros instaladas en entornos virtuales.

    La implementación inicial devuelve métricas mínimas y deja pasos claros para
    futuras iteraciones.
    """

    profiler = Profiler()
    return profiler.profile_path(
        Path(path),
        entrypoint=entrypoint,
        allow_external_entrypoint=allow_external_entrypoint,
        command=command,
        limit=limit,
        use_sys_profile=use_sys_profile,
        include_stdlib=include_stdlib,
        include_site_packages=include_site_packages,
        excluded_dirs=excluded_dirs,
        output_path=output_path,
    )


def get_runtime_manager(
    *,
    cache_dir: str | Path | None = None,
    cache_manager: CacheManager | None = None,
    compiler: Optional[Callable[[str, object], Path]] = None,
    event_hooks: Optional[Dict[str, Iterable[Callable[..., None]]]] = None,
) -> RuntimeManager:
    """Devuelve una instancia compartida de :class:`RuntimeManager`.

    Si el runtime aún no está inicializado, se configura con la caché y
    compilador suministrados. Los parámetros adicionales solo se aceptan en la
    primera llamada; posteriores invocaciones deben reutilizar la instancia
    existente o proporcionar un ``runtime_manager`` explícito a
    :func:`reload_extension`.
    """

    global _runtime_manager

    with _runtime_lock:
        if _runtime_manager is not None and any(
            option is not None for option in (cache_dir, cache_manager, compiler, event_hooks)
        ):
            raise ValueError(
                "El runtime compartido ya está inicializado; no se pueden modificar sus parámetros"
            )

        if _runtime_manager is None:
            resolved_cache = cache_manager or CacheManager(
                cache_dir=Path(cache_dir) if cache_dir else None
            )
            _runtime_manager = RuntimeManager(
                cache_manager=resolved_cache, compiler=compiler, event_hooks=event_hooks
            )

        return _runtime_manager


def shutdown_runtime() -> None:
    """Cierra y limpia la instancia compartida de :class:`RuntimeManager`."""

    global _runtime_manager

    with _runtime_lock:
        manager = _runtime_manager
        if manager is None:
            return

        manager.close()
        _runtime_manager = None


def reload_extension(
    extension_name: str,
    *,
    source: object,
    cache_dir: str | Path | None = None,
    cache_manager: CacheManager | None = None,
    compiler: Optional[Callable[[str, object], Path]] = None,
    event_hooks: Optional[Dict[str, Iterable[Callable[..., None]]]] = None,
    runtime_manager: RuntimeManager | None = None,
    validate: Optional[Callable[[object], bool]] = None,
    force_recompile: bool = False,
    invalidate_cache: bool = False,
    use_cache: bool = True,
    on_success: Optional[Callable[[str, LoadedModule, ReloadMetrics], None]] = None,
    on_failure: Optional[Callable[[str, Exception, ReloadMetrics], None]] = None,
    on_rollback: Optional[Callable[[str, LoadedModule, ReloadMetrics], None]] = None,
) -> ReloadResult:
    """Recarga una extensión y realiza hot-swap usando un runtime persistente.

    Este envoltorio reutiliza un :class:`RuntimeManager` compartido para evitar
    reinicios, pero admite pasar una instancia dedicada mediante
    ``runtime_manager``. Si se proporciona un runtime explícito no se pueden
    mezclar opciones de inicialización como ``cache_dir`` o ``compiler``.
    """

    if runtime_manager is not None and any(
        option is not None for option in (cache_dir, cache_manager, compiler, event_hooks)
    ):
        raise ValueError(
            "No se pueden combinar 'runtime_manager' con parámetros de inicialización"
        )

    manager = runtime_manager or get_runtime_manager(
        cache_dir=cache_dir, cache_manager=cache_manager, compiler=compiler, event_hooks=event_hooks
    )

    return manager.reload(
        extension_name,
        source=source,
        validate=validate,
        force_recompile=force_recompile,
        invalidate_cache=invalidate_cache,
        use_cache=use_cache,
        on_success=on_success,
        on_failure=on_failure,
        on_rollback=on_rollback,
    )


def undo_last_rustyfication(*, start_dir: str | Path | None = None) -> UndoRustyficationResult:
    """
    Deshace el último hot-swap registrado, restaurando módulos y extensiones previas.

    Requiere que exista el registro persistente en ``.pyrust/last_swap.json``.
    """

    start_path = Path(start_dir) if start_dir is not None else None
    try:
        record, record_path = read_last_swap_record(start_path)
    except Exception as exc:
        return UndoRustyficationResult(
            success=False,
            restored_targets=[],
            extensions_unloaded=[],
            errors=[f"No se pudo leer el registro de swap: {exc}"],
        )
    if record is None:
        return UndoRustyficationResult(
            success=False,
            restored_targets=[],
            extensions_unloaded=[],
            errors=["No se encontró un registro de swap previo en .pyrust/last_swap.json."],
        )

    if record_path is None:
        return UndoRustyficationResult(
            success=False,
            restored_targets=[],
            extensions_unloaded=[],
            errors=["Error de seguridad: no se pudo determinar la ubicación del registro de swap."],
        )

    expected_root = expected_project_root_for_record(record_path)
    expected_root_resolved = expected_root.resolve()
    record_root_resolved = record.project_root.resolve()
    if record_root_resolved != expected_root_resolved:
        return UndoRustyficationResult(
            success=False,
            restored_targets=[],
            extensions_unloaded=[],
            errors=[
                (
                    "Error de seguridad: el project_root del registro no coincide con la raíz "
                    "esperada derivada de .pyrust/last_swap.json."
                )
            ],
            record_path=str(record_path),
        )

    project_root = expected_root_resolved
    manager = get_runtime_manager()
    logger = logging.getLogger(__name__)
    errors: List[str] = []
    restored: List[str] = []
    extensions_unloaded: List[str] = []

    valid_targets: List[str] = []
    for target in record.swapped_targets:
        file_part, qualified = _split_target(target)
        if not file_part or not qualified:
            message = f"Target inválido (formato inseguro): {target}"
            logger.error(message)
            errors.append(message)
            continue
        file_path = Path(file_part)
        if not file_path.is_absolute():
            file_path = project_root / file_path
        try:
            file_path.resolve().relative_to(project_root)
        except ValueError:
            message = f"Target inválido (fuera de expected_root): {target}"
            logger.error(message)
            errors.append(message)
            continue
        valid_targets.append(target)

    with _temporary_syspath(project_root):
        modules_to_reload: Dict[str, ModuleType] = {}
        for target in valid_targets:
            file_part, qualified = _split_target(target)
            module_name = _module_name_from_path(Path(file_part), project_root)
            if module_name is None:
                message = f"No se pudo resolver el módulo para {target}"
                logger.error(message)
                errors.append(message)
                continue
            if module_name in modules_to_reload:
                continue
            try:
                loaded_module = import_module(module_name)
                modules_to_reload[module_name] = importlib.reload(loaded_module)
            except Exception as exc:  # pragma: no cover - errores externos
                message = f"No se pudo recargar {module_name}: {exc}"
                logger.error(message)
                errors.append(message)

        for target in valid_targets:
            file_part, qualified = _split_target(target)
            module_name = _module_name_from_path(Path(file_part), project_root)
            if module_name is None:
                continue
            reloaded_module = modules_to_reload.get(module_name)
            if reloaded_module is None:
                message = f"No se pudo restaurar {target}: módulo no recargado"
                logger.error(message)
                errors.append(message)
                continue
            owner: object | None = reloaded_module
            segments = qualified.split(".")
            for segment in segments[:-1]:
                owner = getattr(owner, segment, None)
                if owner is None:
                    message = f"No se pudo restaurar {target}: owner inexistente"
                    logger.error(message)
                    errors.append(message)
                    break
            if owner is None:
                continue
            attr = segments[-1]
            original = getattr(owner, attr, None)
            if original is None:
                message = f"No se pudo restaurar {target}: atributo no encontrado"
                logger.error(message)
                errors.append(message)
                continue
            manager.replace_function(owner, attr, original)
            restored.append(target)

    for extension in record.extensions:
        name = extension.get("name")
        if not isinstance(name, str) or not name:
            message = "Extensión inválida (nombre ausente)"
            logger.error(message)
            errors.append(message)
            continue
        if not is_valid_extension_name(name):
            message = f"Extensión inválida (nombre inseguro): {name}"
            logger.error(message)
            errors.append(message)
            continue
        if manager.unload_extension(name):
            extensions_unloaded.append(name)
        else:
            if name in sys.modules:
                sys.modules.pop(name, None)
                extensions_unloaded.append(name)

    success = bool(restored or extensions_unloaded) and not errors
    return UndoRustyficationResult(
        success=success,
        restored_targets=restored,
        extensions_unloaded=extensions_unloaded,
        errors=errors,
        record_path=str(record_path) if record_path else None,
    )


@dataclass(slots=True)
class TranspilationResult:
    """
    Resultado de transpilar una función tras pasar por el analizador.

    Incluye el veredicto original, las razones del análisis, el IR generado y
    el código renderizado. Si la función fue marcada como ``NO`` o falló el
    renderizado, ``skipped`` será ``True`` y ``rendered`` permanecerá vacío.
    """

    target: str
    verdict: Rustyfiability
    reasons: List[str]
    skipped: bool
    lineno: int | None = None
    qualified_name: str | None = None
    ir: IRFunction | None = None
    rendered: str | None = None
    error: str | None = None


@dataclass(slots=True)
class UndoRustyficationResult:
    """
    Resultado de la operación de deshacer la última rustyficación.

    ``success`` indica si se restauraron los módulos/funciones esperados sin errores.
    """

    success: bool
    restored_targets: List[str]
    extensions_unloaded: List[str]
    errors: List[str]
    record_path: Optional[str] = None


@dataclass(slots=True)
class AutoRustyficationConfig:
    """Parámetros de la fase de auto-rustyficación."""

    hotspot_limit: int = 5
    min_runtime_pct: float = 5.0
    profile_limit: int | None = 25
    use_sys_profile: bool = True
    include_stdlib: bool = False
    include_partial: bool = False
    excluded_dirs: list[str | Path] | None = None
    entrypoint: str | Path | None = None
    command: Callable[[], object] | None = None
    backend: TranspilerBackend | None = None
    compiler: Optional[Callable[[str, object], Path]] = None
    cache_dir: str | Path | None = None
    cache_manager: CacheManager | None = None
    event_hooks: Optional[Dict[str, Iterable[Callable[..., None]]]] = None
    module_builder: Optional[Callable[[TranspilationResult], object]] = None
    force_recompile: bool = False
    invalidate_cache: bool = False
    use_cache: bool = True
    log_level: int = logging.INFO


@dataclass(slots=True)
class AutoRustyficationReport:
    """Resultado completo del pipeline automático."""

    project_root: Path
    config: AutoRustyficationConfig
    profile: ProfileSummary
    analysis: AnalysisSummary
    transpilation: list[TranspilationResult]
    selected_targets: list[str] = field(default_factory=list)
    reloaded: list[ReloadResult] = field(default_factory=list)
    swapped_targets: list[str] = field(default_factory=list)
    reload_failures: list[str] = field(default_factory=list)


def transpile_with_analysis(
    path: str | Path,
    *,
    backend: TranspilerBackend | None = None,
    excluded_dirs: list[str | Path] | None = None,
) -> list[TranspilationResult]:
    """
    Ejecuta el analizador antes de transpilar y evita funciones bloqueadas.

    Pasos:

    1. Usa :class:`Analyzer` para obtener veredictos por función.
    2. Salta cualquier objetivo con veredicto ``NO`` (``skipped=True``).
    3. Para el resto, genera IR con :class:`Transpiler` incluyendo el veredicto
       y razones como metadatos en :class:`IRFunction`.
    4. Renderiza con el backend indicado (``RustTemplateBackend`` por defecto).

    Devuelve una lista ordenada acorde a los resultados del analizador para
    preservar la trazabilidad.
    """

    analyzer = Analyzer()
    results = analyzer.analyze_path(Path(path), excluded_dirs=[str(item) for item in (excluded_dirs or [])])

    backend = backend or RustTemplateBackend()
    transpiler = Transpiler()

    function_nodes = _collect_function_nodes(results)

    transpiled: list[TranspilationResult] = []
    for result in results:
        _, target_qualname = _split_target(result.target)
        if result.verdict is Rustyfiability.NO:
            transpiled.append(
                TranspilationResult(
                    target=result.target,
                    verdict=result.verdict,
                    reasons=list(result.reasons),
                    skipped=True,
                    qualified_name=target_qualname or None,
                )
            )
            continue

        node = function_nodes.get(result.target)
        if node is None:
            transpiled.append(
                TranspilationResult(
                    target=result.target,
                    verdict=result.verdict,
                    reasons=list(result.reasons),
                    skipped=True,
                    qualified_name=target_qualname or None,
                    error="Nodo de función no encontrado para el objetivo analizado",
                )
            )
            continue

        if isinstance(node, ast.AsyncFunctionDef):
            transpiled.append(
                TranspilationResult(
                    target=result.target,
                    verdict=result.verdict,
                    reasons=list(result.reasons),
                    skipped=True,
                    lineno=node.lineno,
                    qualified_name=target_qualname or None,
                    error="Funciones async no soportadas por el transpiler actual",
                )
            )
            continue

        try:
            ir = transpiler.function_to_ir(
                node,
                verdict=result.verdict,
                analysis_reasons=result.reasons,
            )
            rendered = transpiler.render(ir, backend)
            transpiled.append(
                TranspilationResult(
                    target=result.target,
                    verdict=result.verdict,
                    reasons=list(result.reasons),
                    skipped=False,
                    lineno=node.lineno,
                    qualified_name=target_qualname or None,
                    ir=ir,
                    rendered=rendered,
                )
            )
        except IRValidationError as exc:
            transpiled.append(
                TranspilationResult(
                    target=result.target,
                    verdict=result.verdict,
                    reasons=list(result.reasons),
                    skipped=True,
                    lineno=node.lineno,
                    qualified_name=target_qualname or None,
                    error=str(exc),
                )
            )

    return transpiled


def _collect_function_nodes(results: list[AnalysisResult]) -> dict[str, ast.FunctionDef | ast.AsyncFunctionDef]:
    """Construye un mapa ``target -> nodo AST`` alineado con el analizador."""

    paths = {Path(_split_target(result.target)[0]) for result in results}
    nodes: dict[str, ast.FunctionDef | ast.AsyncFunctionDef] = {}
    logger = logging.getLogger(__name__)

    for file_path in paths:
        try:
            source = file_path.read_text(encoding="utf-8")
            tree = ast.parse(source)
        except (OSError, SyntaxError) as exc:
            logger.warning("No se pudo procesar %s: %s", file_path, exc)
            continue

        class _Visitor(ast.NodeVisitor):
            def __init__(self) -> None:
                self.context: list[str] = []

            def visit_ClassDef(self, node: ast.ClassDef) -> None:
                self.context.append(node.name)
                self.generic_visit(node)
                self.context.pop()

            def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
                qualified = ".".join([*self.context, node.name])
                nodes[f"{file_path}:{qualified}"] = node
                self.context.append(node.name)
                self.generic_visit(node)
                self.context.pop()

            def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
                qualified = ".".join([*self.context, node.name])
                nodes[f"{file_path}:{qualified}"] = node
                self.context.append(node.name)
                self.generic_visit(node)
                self.context.pop()

        _Visitor().visit(tree)

    return nodes


def enable_auto_rustyfication(
    project_root: Optional[str | Path] = None, *, config: AutoRustyficationConfig | None = None
) -> AutoRustyficationReport:
    """Ejecuta el pipeline completo de rustyficación automática (fase 7)."""

    cfg = config or AutoRustyficationConfig()
    root = Path(project_root) if project_root is not None else Path.cwd()
    logger = logging.getLogger(__name__)
    logger.setLevel(cfg.log_level)

    try:
        logger.info("Iniciando auto-rustyficación en %s", root)
        profile_summary = profile_project(
            root,
            entrypoint=cfg.entrypoint,
            command=cfg.command,
            limit=cfg.profile_limit,
            use_sys_profile=cfg.use_sys_profile,
            include_stdlib=cfg.include_stdlib,
            excluded_dirs=cfg.excluded_dirs,
        )
        analysis = analyze_summary(root, excluded_dirs=cfg.excluded_dirs)
        transpilation = transpile_with_analysis(
            root, backend=cfg.backend, excluded_dirs=cfg.excluded_dirs
        )

        selected, reloads, swapped, failures = _auto_select_and_reload(
            root,
            cfg,
            profile_summary,
            transpilation,
            logger=logger,
        )

        return AutoRustyficationReport(
            project_root=root,
            config=cfg,
            profile=profile_summary,
            analysis=analysis,
            transpilation=transpilation,
            selected_targets=selected,
            reloaded=reloads,
            swapped_targets=swapped,
            reload_failures=failures,
        )
    finally:
        shutdown_runtime()


def _auto_select_and_reload(
    project_root: Path,
    config: AutoRustyficationConfig,
    profile: ProfileSummary,
    transpilation: list[TranspilationResult],
    *,
    logger: logging.Logger,
) -> tuple[list[str], list[ReloadResult], list[str], list[str]]:
    total_runtime = profile.total_runtime
    selected: list[tuple[TranspilationResult, float]] = []
    for sample in profile.top_hotspots(config.hotspot_limit):
        runtime_pct = (sample.total_time / total_runtime * 100) if total_runtime else 0.0
        if runtime_pct < config.min_runtime_pct:
            logger.debug(
                "Saltando %s por debajo del umbral mínimo de runtime: %.2f%% < %.2f%%",
                sample.qualified_name,
                runtime_pct,
                config.min_runtime_pct,
            )
            continue

        match = _match_transpilation_to_sample(
            sample.qualified_name, transpilation, include_partial=config.include_partial
        )
        if match is None:
            logger.info("No se encontraron coincidencias para %s", sample.qualified_name)
            continue
        selected.append((match, runtime_pct))

    if not selected:
        logger.info("No hay hotspots seleccionados para rustyficación")
        return [], [], [], []

    cache_dir = config.cache_dir
    if cache_dir is None and config.cache_manager is None:
        cache_dir = project_root / ".pyrust_cache"

    manager = get_runtime_manager(
        cache_dir=cache_dir,
        cache_manager=config.cache_manager,
        compiler=config.compiler,
        event_hooks=config.event_hooks,
    )
    reloaded: list[ReloadResult] = []
    swapped: list[str] = []
    swapped_reload_results: dict[str, ReloadResult] = {}
    reload_failures: list[str] = []
    selected_targets: list[str] = []

    with _temporary_syspath(project_root):
        for result, runtime_pct in selected:
            payload = config.module_builder(result) if config.module_builder else result.rendered
            if payload is None:
                logger.warning("No hay payload para recargar %s", result.target)
                continue

            extension_name = _extension_name_from_target(result.target, project_root)
            logger.info(
                "Recargando %s (hotspot: %.2f%% del runtime)", result.target, runtime_pct
            )
            try:
                reload_result = reload_extension(
                    extension_name,
                    source=payload,
                    runtime_manager=manager,
                    force_recompile=config.force_recompile,
                    invalidate_cache=config.invalidate_cache,
                    use_cache=config.use_cache,
                )
            except Exception:  # pragma: no cover - errores inesperados en recarga
                logger.exception("Error recargando %s; se omitirá este hotspot", result.target)
                reload_failures.append(result.target)
                continue

            reloaded.append(reload_result)
            selected_targets.append(result.target)

            owner, attr, owner_error = _resolve_owner_for_target(result.target, project_root)
            compiled_fn = getattr(reload_result.loaded.module, attr, None)
            if owner is None or compiled_fn is None:
                reason = owner_error or (
                    f"atributo compilado '{attr}' no encontrado en la extensión" if compiled_fn is None else ""
                )
                logger.info(
                    "No se pudo intercambiar la función %s: owner=%s, compiled=%s, motivo=%s",
                    result.target,
                    owner,
                    compiled_fn,
                    reason,
                )
                continue

            manager.replace_function(owner, attr, compiled_fn)
            swapped.append(result.target)
            swapped_reload_results[result.target] = reload_result

    if swapped:
        try:
            record_last_swap(
                project_root=project_root,
                swapped_targets=swapped,
                reloads=swapped_reload_results.values(),
            )
        except Exception as exc:  # pragma: no cover - logging only
            logger.warning("No se pudo registrar el último swap: %s", exc)

    return selected_targets, reloaded, swapped, reload_failures


def _match_transpilation_to_sample(
    qualified_name: str, results: list[TranspilationResult], *, include_partial: bool
) -> TranspilationResult | None:
    parts = qualified_name.rsplit(":", 2)
    if len(parts) < 3:
        return None
    filename, line_text, func_name = parts[0], parts[1], parts[2]

    resolved = Path(filename).resolve()
    try:
        sample_line = int(line_text)
    except ValueError:
        sample_line = None

    def _eligible(result: TranspilationResult) -> bool:
        if result.skipped or result.verdict is Rustyfiability.NO:
            return False
        if (not include_partial) and result.verdict is Rustyfiability.PARTIAL:
            return False
        return True

    for result in results:
        if not _eligible(result):
            continue
        target_file, _ = _split_target(result.target)
        if Path(target_file).resolve() != resolved:
            continue
        if sample_line is not None and result.lineno == sample_line:
            return result

    for result in results:
        if not _eligible(result):
            continue
        target_file, target_qualname = _split_target(result.target)
        if Path(target_file).resolve() != resolved:
            continue
        if result.qualified_name == func_name or target_qualname == func_name:
            return result
    return None


def _extension_name_from_target(target: str, project_root: Path) -> str:
    file_part, qualified = _split_target(target)
    stem = Path(file_part).stem or "module"
    func = qualified.split(".")[-1] if qualified else stem

    def _sanitize_component(value: str, fallback: str) -> str:
        sanitized = re.sub(r"[^A-Za-z0-9_]", "_", value)
        return sanitized or fallback

    safe_stem = _sanitize_component(stem, "module")
    safe_func = _sanitize_component(func, safe_stem)
    try:
        relative = Path(file_part).resolve().relative_to(project_root.resolve())
    except ValueError:
        relative = Path(file_part).resolve()
    relative_key = relative.as_posix()
    digest = hashlib.sha256(relative_key.encode("utf-8")).hexdigest()[:16]
    extension_name = f"pyrust_auto_{safe_stem}_{safe_func}_{digest}"
    RuntimeManager._validate_extension_name(extension_name)
    return extension_name


def _resolve_owner_for_target(
    target: str, project_root: Path
) -> tuple[object | None, str, str | None]:
    file_part, qualified = _split_target(target)
    if not qualified:
        return None, "", "target sin segmento calificado"

    segments = qualified.split(".")
    attr = segments[-1]

    module_name = _module_name_from_path(Path(file_part), project_root)
    if module_name is None:
        return None, attr, f"ruta no importable para módulo: {file_part}"

    try:
        module = import_module(module_name)
    except Exception as exc:
        return None, attr, f"no se pudo importar '{module_name}': {exc}"

    owner: object | None = module
    for segment in segments[:-1]:
        try:
            owner = getattr(owner, segment, None)
        except Exception as exc:
            return None, attr, f"error al resolver owner en '{segment}': {exc}"
        if owner is None:
            return None, attr, f"owner inexistente en segmento '{segment}'"

    return owner, attr, None


def _module_name_from_path(file_path: Path, project_root: Path) -> str | None:
    try:
        relative = file_path.resolve().relative_to(project_root.resolve())
    except ValueError:
        return None

    if relative.name == "__init__.py":
        relative = relative.parent
    else:
        relative = relative.with_suffix("")

    if not relative.parts:
        return None

    for segment in relative.parts:
        if not segment.isidentifier() or keyword.iskeyword(segment):
            return None

    return ".".join(relative.parts)


@contextmanager
def _temporary_syspath(root: Path):
    root_str = str(root.resolve())
    already_present = root_str in sys.path
    if not already_present:
        sys.path.insert(0, root_str)
    try:
        yield
    finally:
        if not already_present:
            with suppress(ValueError):
                sys.path.remove(root_str)
