# PyRust

[![PyPI version](https://img.shields.io/pypi/v/pyrust)](https://pypi.org/project/pyrust/)
[![PyPI status](https://img.shields.io/pypi/status/pyrust)](https://pypi.org/project/pyrust/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://github.com/pyrust-dev/pyrust/blob/main/LICENSE)

**Acelera tu código Python automáticamente con Rust.**

PyRust es una herramienta que identifica los cuellos de botella de tu proyecto y los "rustifica" automáticamente, generando extensiones nativas seguras y eficientes sin que tengas que escribir una sola línea de Rust.

📚 **Documentación**: https://pyrust-dev.github.io/pyrust/
🗒️ **Notas de publicación**: https://github.com/pyrust-dev/pyrust/releases

## 🚀 Aceleración Automática (`pyrust auto`)

La joya de la corona de PyRust es el comando `auto`. Con una sola ejecución, PyRust orquesta todo el proceso de optimización:

1.  **Perfilado**: Ejecuta tu código y detecta las funciones más lentas (hotspots).
2.  **Análisis**: Verifica qué funciones son seguras de convertir a Rust (sin efectos secundarios peligrosos).
3.  **Transpilación**: Genera código Rust optimizado equivalente a tu Python.
4.  **Compilación**: Crea extensiones nativas usando PyO3 y Maturin.
5.  **Inyección Segura**: Modifica tu código para usar la versión rápida, manteniendo la original como respaldo.

### Uso básico

Simplemente ve a la raíz de tu proyecto y ejecuta:

```bash
pyrust auto .
```

### ¿Qué ocurre con mi código?

PyRust es extremadamente cuidadoso con tu código fuente:

*   **Backups automáticos**: Antes de tocar nada, crea copias de seguridad (`.py.bak`).
*   **Inyección Híbrida**: No borra tu código Python. Inyecta un mecanismo de carga inteligente:

```python
# Ejemplo de lo que PyRust inyecta en tu archivo:
try:
    # Intenta importar la versión acelerada en Rust
    from pyrust_extensions.mi_modulo_rust import funcion_lenta as funcion_lenta
except ImportError:
    # Si falla algo (ej. en otra máquina sin compilar), usa la original
    funcion_lenta = _py_funcion_lenta

# Tu función original se renombra y se mantiene segura
def _py_funcion_lenta(...):
    ...
```

*   **Soporte Avanzado**: Funciona con funciones globales, **métodos de clase** y **métodos estáticos**, preservando la semántica de `self` y `cls`.

---

## Índice

- [Instalación](#instalación)
- [Otras Herramientas](#otras-herramientas)
  - [Perfilado Manual](#perfilado-manual)
  - [Análisis de Compatibilidad](#análisis-de-compatibilidad)
  - [API de Runtime](#api-de-runtime)
- [Seguridad y Robustez](#seguridad-y-robustez)
- [Compatibilidad](#compatibilidad)
- [Desarrollo](#desarrollo)

## Instalación

```bash
pip install pyrust
```

**Requisitos:**
- Python 3.10+
- (Opcional) Rust 1.70+ si deseas compilar desde el código fuente.

## Otras Herramientas

Si prefieres tener control manual sobre el proceso, PyRust expone cada paso como una herramienta independiente.

### Perfilado Manual

Localiza los puntos lentos de tu código sin modificarlo.

```bash
pyrust-profile mi_proyecto --limit 5
```

### Análisis de Compatibilidad

Descubre qué partes de tu código son candidatas a ser rustificadas. PyRust analiza el AST y te dice qué funciones son `FULL` (totalmente convertibles), `PARTIAL` o `NO` (requieren cambios).

```bash
pyrust-analyze mi_proyecto --limit 3
```

### API de Runtime

Para usuarios avanzados que desean cargar extensiones dinámicamente o hacer *hot-swap* en tiempo de ejecución sin reiniciar el proceso.

```python
from pyrust.runtime import reload_extension

# Carga y compila una extensión al vuelo
result = reload_extension("mi_extension", source="ruta/al/archivo.py")
print(result.loaded.module.mi_funcion_rapida(10))
```

## Seguridad y Robustez

PyRust está diseñado para ser seguro por defecto:

- **Límites de Recursos**: El compilador rechaza archivos excesivamente grandes (DoS protection).
- **Transpilación Segura**: El generador Rust valida tipos estrictamente y evita inyecciones.
- **Protección contra Carreras**: Sistema de caché con bloqueos de archivo (`filelock`) para entornos concurrentes.
- **Validación de Integridad**: Verificación de firmas SHA256 en los binarios cargados.

## Compatibilidad

| Componente | Versión Soportada |
| --- | --- |
| **Python** | 3.10+ |
| **Rust** | 1.70+ (Edición 2021) |
| **Plataformas** | Linux (x86_64/aarch64), Windows (x86_64), macOS (x86_64/arm64) |

## Desarrollo

Para contribuir a PyRust:

```bash
# Crear entorno virtual
python -m venv .venv
source .venv/bin/activate  # o .venv\Scripts\activate en Windows

# Instalar dependencias de desarrollo
pip install -e ".[dev]"

# Ejecutar tests
pytest
```
