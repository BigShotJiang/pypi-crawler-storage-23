# Documentation

This folder contains extended project documentation.

## Guides

- [PyPI Package README](README_PYPI.md)
- [Security Policy](../SECURITY.md)
- [Changelog](../CHANGELOG.md)
- [Main Project README](../README.md)
