def main():
    print("Hello from safe-py-runner!")


if __name__ == "__main__":
    main()
