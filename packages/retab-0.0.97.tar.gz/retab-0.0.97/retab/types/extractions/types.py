"""Extraction-specific shared types."""
