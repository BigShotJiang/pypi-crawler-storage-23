"""Agent updater - check for and install updates from PyPI."""

from __future__ import annotations

import asyncio
import json
import logging
import subprocess
import sys
import time
from typing import Any
from urllib.request import urlopen, Request
from urllib.error import URLError

from snippbot_device import __version__

logger = logging.getLogger(__name__)

PYPI_PACKAGE_NAME = "snippbot-device"
PYPI_JSON_URL = f"https://pypi.org/pypi/{PYPI_PACKAGE_NAME}/json"
CHECK_INTERVAL_HOURS = 6


def _parse_version(version_str: str) -> tuple[int, ...]:
    """Parse a PEP-440 version string into a comparable tuple.

    Handles simple versions like "0.1.0" and pre-release tags like "0.1.0a1"
    by stripping any non-numeric suffix from each segment.
    """
    parts: list[int] = []
    for segment in version_str.strip().split("."):
        # Strip non-numeric suffixes (e.g. "0a1" -> "0")
        numeric = ""
        for ch in segment:
            if ch.isdigit():
                numeric += ch
            else:
                break
        if numeric:
            parts.append(int(numeric))
        else:
            parts.append(0)
    return tuple(parts)


class AgentUpdater:
    """Checks PyPI for newer versions of snippbot-device and installs them."""

    def __init__(self, auto_update: bool = True) -> None:
        self._auto_update = auto_update
        self._current_version = __version__
        self._last_check: float = 0.0
        self._latest_version: str | None = None

    @property
    def current_version(self) -> str:
        return self._current_version

    @property
    def latest_version(self) -> str | None:
        return self._latest_version

    async def check_for_update(self) -> dict[str, Any]:
        """Query PyPI for the latest version of snippbot-device.

        Returns a dict with keys:
          - update_available (bool)
          - current_version (str)
          - latest_version (str | None)
          - error (str | None)
        """
        result: dict[str, Any] = {
            "update_available": False,
            "current_version": self._current_version,
            "latest_version": None,
            "error": None,
        }

        try:
            latest = await asyncio.get_event_loop().run_in_executor(
                None, self._fetch_latest_version
            )
            self._latest_version = latest
            self._last_check = time.time()

            result["latest_version"] = latest

            if latest and _parse_version(latest) > _parse_version(self._current_version):
                result["update_available"] = True
                logger.info(
                    "Update available: %s -> %s",
                    self._current_version,
                    latest,
                )
            else:
                logger.debug("Already up to date: %s", self._current_version)

        except Exception as exc:
            logger.warning("Failed to check for updates: %s", exc)
            result["error"] = str(exc)

        return result

    def _fetch_latest_version(self) -> str | None:
        """Synchronously fetch the latest version from PyPI."""
        try:
            req = Request(
                PYPI_JSON_URL,
                headers={"Accept": "application/json", "User-Agent": f"snippbot-device/{self._current_version}"},
            )
            with urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                version = data.get("info", {}).get("version")
                return version if isinstance(version, str) else None
        except (URLError, json.JSONDecodeError, OSError) as exc:
            logger.debug("PyPI fetch failed: %s", exc)
            return None

    async def install_update(self) -> dict[str, Any]:
        """Install the latest version of snippbot-device via pip.

        Returns a dict with:
          - success (bool)
          - version (str | None) - the version installed
          - output (str)
          - error (str)
        """
        result: dict[str, Any] = {
            "success": False,
            "version": None,
            "output": "",
            "error": "",
        }

        if not self._latest_version:
            check = await self.check_for_update()
            if not check["update_available"]:
                result["error"] = "No update available"
                return result

        target = self._latest_version
        logger.info("Installing update: %s -> %s", self._current_version, target)

        try:
            proc = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: subprocess.run(
                    [
                        sys.executable, "-m", "pip", "install",
                        "--upgrade", f"{PYPI_PACKAGE_NAME}=={target}",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=120,
                ),
            )

            result["output"] = proc.stdout
            result["error"] = proc.stderr

            if proc.returncode == 0:
                result["success"] = True
                result["version"] = target
                logger.info("Successfully updated to %s", target)
            else:
                logger.error("pip install failed (rc=%d): %s", proc.returncode, proc.stderr)

        except subprocess.TimeoutExpired:
            result["error"] = "pip install timed out after 120s"
            logger.error("pip install timed out")
        except FileNotFoundError:
            result["error"] = "pip not found"
            logger.error("pip not found at %s", sys.executable)

        return result

    async def check_and_update(self) -> dict[str, Any]:
        """Convenience method: check for update and install if available and auto_update is on.

        Returns the combined result dict.
        """
        check = await self.check_for_update()

        if not check["update_available"]:
            return {
                "action": "none",
                "reason": "already up to date" if not check["error"] else check["error"],
                **check,
            }

        if not self._auto_update:
            return {
                "action": "skipped",
                "reason": "auto_update is disabled",
                **check,
            }

        install = await self.install_update()
        return {
            "action": "updated" if install["success"] else "failed",
            **check,
            **install,
        }

    def should_check(self) -> bool:
        """Return True if enough time has elapsed since the last check."""
        if self._last_check == 0.0:
            return True
        elapsed_hours = (time.time() - self._last_check) / 3600
        return elapsed_hours >= CHECK_INTERVAL_HOURS
