# Google Trends MCP Server

MCP Server สำหรับวิเคราะห์ Keyword ผ่าน Google Trends (pytrends)

## Installation

```bash
pip install google-trends-mcp
```

หรือใช้ `uvx`:
```bash
uvx google-trends-mcp
```

## Usage

Server นี้มี 10 tools ให้ใช้:

1. **interest_over_time** - ดูความนิยมของ keyword ตามช่วงเวลา
2. **interest_by_region** - ดูความนิยมของ keyword ตามภูมิภาค
3. **related_topics** - ดู topic ที่เกี่ยวข้อง
4. **related_queries** - ดู query ที่เกี่ยวข้อง
5. **trending_searches** - ดู keyword ที่กำลัง trending
6. **realtime_trending** - ดู trending แบบ realtime
7. **suggestions** - ดูคำแนะนำ keyword
8. **categories** - ดูรายการ category ทั้งหมด
9. **historical_hourly** - ดูข้อมูลรายชั่วโมงย้อนหลัง
10. **compare_keywords** - เปรียบเทียบ keyword หลายตัว

## Example

```python
# ดูความนิยม "AI" ใน US ในช่วง 12 เดือนที่ผ่านมา
interest_over_time(
    keywords=["AI"],
    timeframe="today 12-m",
    geo="US"
)
```

## License

MIT License

## Author

Chanont (chanont025@gmail.com)
