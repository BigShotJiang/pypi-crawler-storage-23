"""
Google Trends MCP Server
========================
MCP Server สำหรับวิเคราะห์ Keyword ผ่าน Google Trends (pytrends)

Tools:
  1. interest_over_time      - ดูความนิยมของ keyword ตามช่วงเวลา
  2. interest_by_region      - ดูความนิยมของ keyword ตามภูมิภาค
  3. related_topics           - ดู topic ที่เกี่ยวข้อง
  4. related_queries          - ดู query ที่เกี่ยวข้อง
  5. trending_searches        - ดู keyword ที่กำลัง trending
  6. realtime_trending        - ดู trending แบบ realtime
  7. suggestions              - ดูคำแนะนำ keyword
  8. categories               - ดูรายการ category ทั้งหมด
  9. historical_hourly        - ดูข้อมูลรายชั่วโมงย้อนหลัง
  10. compare_keywords         - เปรียบเทียบ keyword หลายตัว (interest + region)
"""

import json
import logging
import traceback
from typing import Any

# ---------------------------------------------------------------------------
# Monkey-patch: pytrends 4.9.2 ใช้ method_whitelist ที่ถูกลบใน urllib3 2.x
# แก้โดยแปลง method_whitelist -> allowed_methods อัตโนมัติ
# ---------------------------------------------------------------------------
import urllib3.util.retry

_OrigRetry = urllib3.util.retry.Retry


class _PatchedRetry(_OrigRetry):  # type: ignore[misc]
    def __init__(self, *args, **kwargs):
        if "method_whitelist" in kwargs:
            kwargs["allowed_methods"] = kwargs.pop("method_whitelist")
        super().__init__(*args, **kwargs)


urllib3.util.retry.Retry = _PatchedRetry  # type: ignore[misc]
# ---------------------------------------------------------------------------

import pandas as pd
from mcp.server.fastmcp import FastMCP
from pytrends.request import TrendReq

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("google-trends-mcp")

# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------
mcp = FastMCP("google-trends")

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_pytrends(hl: str = "en-US", tz: int = 360) -> TrendReq:
    """สร้าง TrendReq instance พร้อม timeout ที่เหมาะสม"""
    return TrendReq(hl=hl, tz=tz, timeout=(10, 30), retries=3, backoff_factor=0.5)


def _df_to_text(df: pd.DataFrame, max_rows: int = 50) -> str:
    """แปลง DataFrame เป็น text-friendly markdown table"""
    if df is None or df.empty:
        return "(ไม่มีข้อมูล / No data)"
    if len(df) > max_rows:
        df = df.head(max_rows)
        truncated = f"\n... (แสดง {max_rows} แถวแรกจากทั้งหมด {len(df)} แถว)"
    else:
        truncated = ""
    return df.to_markdown() + truncated


def _dict_of_df_to_text(data: dict, max_rows: int = 30) -> str:
    """แปลง dict ของ DataFrames (เช่น related_topics) เป็น text"""
    parts = []
    for keyword, tables in data.items():
        parts.append(f"## Keyword: {keyword}")
        if isinstance(tables, dict):
            for table_name, df in tables.items():
                parts.append(f"### {table_name}")
                if isinstance(df, pd.DataFrame):
                    parts.append(_df_to_text(df, max_rows))
                else:
                    parts.append(str(df))
        elif isinstance(tables, pd.DataFrame):
            parts.append(_df_to_text(tables, max_rows))
        else:
            parts.append(str(tables))
    return "\n\n".join(parts)


def _safe_json(obj: Any) -> str:
    """แปลง object เป็น JSON string อย่างปลอดภัย"""
    try:
        return json.dumps(obj, ensure_ascii=False, indent=2, default=str)
    except Exception:
        return str(obj)


def _build_payload(
    pt: TrendReq,
    keywords: list[str],
    timeframe: str = "today 5-y",
    geo: str = "",
    cat: int = 0,
    gprop: str = "",
) -> None:
    """build_payload wrapper พร้อม validation"""
    if not keywords:
        raise ValueError("ต้องระบุ keyword อย่างน้อย 1 ตัว")
    if len(keywords) > 5:
        raise ValueError("pytrends รองรับสูงสุด 5 keywords ต่อครั้ง")
    pt.build_payload(keywords, cat=cat, timeframe=timeframe, geo=geo, gprop=gprop)


# ---------------------------------------------------------------------------
# Tool 1: Interest Over Time
# ---------------------------------------------------------------------------
@mcp.tool()
def interest_over_time(
    keywords: list[str],
    timeframe: str = "today 5-y",
    geo: str = "",
    cat: int = 0,
    gprop: str = "",
    hl: str = "en-US",
) -> str:
    """
    ดูความนิยมของ keyword ตามช่วงเวลา (Interest Over Time)

    Args:
        keywords: รายการ keyword (สูงสุด 5 ตัว) เช่น ["Bitcoin", "Ethereum"]
        timeframe: ช่วงเวลา เช่น "today 5-y", "today 3-m", "2023-01-01 2023-12-31"
        geo: รหัสประเทศ เช่น "TH", "US" (ว่าง = ทั่วโลก)
        cat: หมายเลข category (0 = ทั้งหมด)
        gprop: ประเภท Google เช่น "youtube", "news", "images", "froogle"
        hl: ภาษา เช่น "th", "en-US"

    Returns:
        ตารางแสดงค่า interest (0-100) ตามช่วงเวลา
    """
    try:
        pt = _get_pytrends(hl=hl)
        _build_payload(pt, keywords, timeframe, geo, cat, gprop)
        df = pt.interest_over_time()
        if df.empty:
            return "ไม่พบข้อมูล interest over time สำหรับ keyword ที่ระบุ"
        # ลบ column isPartial ถ้ามี
        if "isPartial" in df.columns:
            df = df.drop(columns=["isPartial"])
        return f"# Interest Over Time\n**Keywords:** {', '.join(keywords)}\n**Timeframe:** {timeframe}\n**Geo:** {geo or 'Worldwide'}\n\n{_df_to_text(df)}"
    except Exception as e:
        logger.error(traceback.format_exc())
        return f"Error: {e}"


# ---------------------------------------------------------------------------
# Tool 2: Interest by Region
# ---------------------------------------------------------------------------
@mcp.tool()
def interest_by_region(
    keywords: list[str],
    timeframe: str = "today 5-y",
    geo: str = "",
    resolution: str = "COUNTRY",
    inc_low_vol: bool = True,
    inc_geo_code: bool = False,
    cat: int = 0,
    gprop: str = "",
    hl: str = "en-US",
) -> str:
    """
    ดูความนิยมของ keyword ตามภูมิภาค/ประเทศ (Interest by Region)

    Args:
        keywords: รายการ keyword (สูงสุด 5 ตัว)
        timeframe: ช่วงเวลา
        geo: รหัสประเทศ (ว่าง = ทั่วโลก)
        resolution: ระดับความละเอียด "COUNTRY", "REGION", "CITY", "DMA"
        inc_low_vol: รวมพื้นที่ที่มี search volume ต่ำ
        inc_geo_code: แสดงรหัส ISO ของประเทศ
        cat: หมายเลข category
        gprop: ประเภท Google
        hl: ภาษา

    Returns:
        ตารางแสดง interest ตามภูมิภาค เรียงจากมากไปน้อย
    """
    try:
        pt = _get_pytrends(hl=hl)
        _build_payload(pt, keywords, timeframe, geo, cat, gprop)
        df = pt.interest_by_region(
            resolution=resolution,
            inc_low_vol=inc_low_vol,
            inc_geo_code=inc_geo_code,
        )
        if df.empty:
            return "ไม่พบข้อมูล interest by region สำหรับ keyword ที่ระบุ"
        # เรียงจากมากไปน้อยตาม keyword แรก
        df = df.sort_values(by=keywords[0], ascending=False)
        # ตัดที่ไม่มีค่า
        df = df[df[keywords[0]] > 0]
        return f"# Interest by Region\n**Keywords:** {', '.join(keywords)}\n**Resolution:** {resolution}\n**Geo:** {geo or 'Worldwide'}\n\n{_df_to_text(df, max_rows=40)}"
    except Exception as e:
        logger.error(traceback.format_exc())
        return f"Error: {e}"


# ---------------------------------------------------------------------------
# Tool 3: Related Topics
# ---------------------------------------------------------------------------
@mcp.tool()
def related_topics(
    keywords: list[str],
    timeframe: str = "today 5-y",
    geo: str = "",
    cat: int = 0,
    gprop: str = "",
    hl: str = "en-US",
) -> str:
    """
    ดู topic ที่เกี่ยวข้องกับ keyword (Related Topics)

    แสดงทั้ง "top" (ยอดนิยมสุด) และ "rising" (กำลังเพิ่มขึ้น)

    Args:
        keywords: รายการ keyword (สูงสุด 5 ตัว)
        timeframe: ช่วงเวลา
        geo: รหัสประเทศ
        cat: หมายเลข category
        gprop: ประเภท Google
        hl: ภาษา

    Returns:
        ตาราง related topics แบ่งเป็น top และ rising
    """
    try:
        pt = _get_pytrends(hl=hl)
        _build_payload(pt, keywords, timeframe, geo, cat, gprop)
        data = pt.related_topics()
        if not data:
            return "ไม่พบ related topics"
        return f"# Related Topics\n**Keywords:** {', '.join(keywords)}\n\n{_dict_of_df_to_text(data)}"
    except Exception as e:
        logger.error(traceback.format_exc())
        return f"Error: {e}"


# ---------------------------------------------------------------------------
# Tool 4: Related Queries
# ---------------------------------------------------------------------------
@mcp.tool()
def related_queries(
    keywords: list[str],
    timeframe: str = "today 5-y",
    geo: str = "",
    cat: int = 0,
    gprop: str = "",
    hl: str = "en-US",
) -> str:
    """
    ดู query ที่เกี่ยวข้องกับ keyword (Related Queries)

    แสดงทั้ง "top" (ยอดนิยมสุด) และ "rising" (กำลังเพิ่มขึ้น)

    Args:
        keywords: รายการ keyword (สูงสุด 5 ตัว)
        timeframe: ช่วงเวลา
        geo: รหัสประเทศ
        cat: หมายเลข category
        gprop: ประเภท Google
        hl: ภาษา

    Returns:
        ตาราง related queries แบ่งเป็น top และ rising
    """
    try:
        pt = _get_pytrends(hl=hl)
        _build_payload(pt, keywords, timeframe, geo, cat, gprop)
        data = pt.related_queries()
        if not data:
            return "ไม่พบ related queries"
        return f"# Related Queries\n**Keywords:** {', '.join(keywords)}\n\n{_dict_of_df_to_text(data)}"
    except Exception as e:
        logger.error(traceback.format_exc())
        return f"Error: {e}"


# ---------------------------------------------------------------------------
# Tool 5: Trending Searches
# ---------------------------------------------------------------------------
@mcp.tool()
def trending_searches(
    country: str = "thailand",
) -> str:
    """
    ดู keyword ที่กำลัง trending ในประเทศที่ระบุ (Trending Searches)

    Args:
        country: ชื่อประเทศ เช่น "thailand", "united_states", "japan", "united_kingdom"

    Returns:
        รายการ keyword ที่กำลัง trending
    """
    try:
        pt = _get_pytrends()
        df = pt.trending_searches(pn=country)
        if df.empty:
            return f"ไม่พบ trending searches สำหรับ {country}"
        return f"# Trending Searches\n**Country:** {country}\n\n{_df_to_text(df)}"
    except Exception as e:
        logger.error(traceback.format_exc())
        return f"Error: {e}"


# ---------------------------------------------------------------------------
# Tool 6: Realtime Trending
# ---------------------------------------------------------------------------
@mcp.tool()
def realtime_trending(
    country: str = "TH",
    cat: str = "all",
) -> str:
    """
    ดู keyword ที่กำลัง trending แบบ realtime (Realtime Trending Searches)

    Args:
        country: รหัสประเทศ 2 ตัวอักษร เช่น "TH", "US", "JP", "IN"
        cat: หมวดหมู่ เช่น "all", "e" (entertainment), "b" (business), "t" (tech), "s" (sports), "h" (health)

    Returns:
        รายการ keyword ที่กำลัง trending แบบ realtime
    """
    try:
        pt = _get_pytrends()
        df = pt.realtime_trending_searches(pn=country, cat=cat)
        if df.empty:
            return f"ไม่พบ realtime trending searches สำหรับ {country}"
        return f"# Realtime Trending Searches\n**Country:** {country}\n**Category:** {cat}\n\n{_df_to_text(df)}"
    except Exception as e:
        logger.error(traceback.format_exc())
        return f"Error: {e}"


# ---------------------------------------------------------------------------
# Tool 7: Suggestions
# ---------------------------------------------------------------------------
@mcp.tool()
def suggestions(
    keyword: str,
    hl: str = "en-US",
) -> str:
    """
    ดูคำแนะนำ keyword จาก Google Trends (Suggestions/Autocomplete)

    ใช้เพื่อหา topic ID ที่แม่นยำสำหรับ search term ที่กำกวม
    เช่น "iron" อาจหมายถึง Iron Chemical Element, Iron Man, etc.

    Args:
        keyword: keyword ที่ต้องการหาคำแนะนำ
        hl: ภาษา เช่น "th", "en-US"

    Returns:
        รายการคำแนะนำพร้อม mid (topic ID), title, type
    """
    try:
        pt = _get_pytrends(hl=hl)
        data = pt.suggestions(keyword)
        if not data:
            return f"ไม่พบคำแนะนำสำหรับ '{keyword}'"
        return f"# Suggestions for '{keyword}'\n\n{_safe_json(data)}"
    except Exception as e:
        logger.error(traceback.format_exc())
        return f"Error: {e}"


# ---------------------------------------------------------------------------
# Tool 8: Categories
# ---------------------------------------------------------------------------
@mcp.tool()
def categories(
    hl: str = "en-US",
) -> str:
    """
    ดูรายการ category ทั้งหมดที่ใช้ได้ใน Google Trends (Categories)

    ใช้เพื่อหาหมายเลข category สำหรับ filter ผลลัพธ์

    Args:
        hl: ภาษา

    Returns:
        โครงสร้าง category tree
    """
    try:
        pt = _get_pytrends(hl=hl)
        data = pt.categories()
        if not data:
            return "ไม่พบข้อมูล categories"
        # แสดงเฉพาะ top-level categories เพื่อไม่ให้ output ยาวเกิน
        children = data.get("children", [])
        result_lines = ["# Google Trends Categories", ""]
        for child in children:
            cid = child.get("id", "?")
            name = child.get("name", "?")
            result_lines.append(f"- **{cid}**: {name}")
            for sub in child.get("children", [])[:5]:
                sid = sub.get("id", "?")
                sname = sub.get("name", "?")
                result_lines.append(f"  - {sid}: {sname}")
            if len(child.get("children", [])) > 5:
                result_lines.append(f"  - ... ({len(child['children']) - 5} more)")
        return "\n".join(result_lines)
    except Exception as e:
        logger.error(traceback.format_exc())
        return f"Error: {e}"


# ---------------------------------------------------------------------------
# Tool 9: Historical Hourly Interest
# ---------------------------------------------------------------------------
@mcp.tool()
def historical_hourly(
    keywords: list[str],
    year_start: int = 2024,
    month_start: int = 1,
    day_start: int = 1,
    hour_start: int = 0,
    year_end: int = 2024,
    month_end: int = 1,
    day_end: int = 8,
    hour_end: int = 0,
    geo: str = "",
    cat: int = 0,
    gprop: str = "",
    sleep: int = 5,
    hl: str = "en-US",
) -> str:
    """
    ดูข้อมูล interest รายชั่วโมงย้อนหลัง (Historical Hourly Interest)

    ข้อควรระวัง: ส่ง request หลายครั้ง (ทีละ 1 สัปดาห์) อาจโดน rate limit
    แนะนำให้ใช้ช่วงเวลาสั้นๆ (1-2 สัปดาห์)

    Args:
        keywords: รายการ keyword (สูงสุด 5 ตัว)
        year_start: ปีเริ่มต้น
        month_start: เดือนเริ่มต้น
        day_start: วันเริ่มต้น
        hour_start: ชั่วโมงเริ่มต้น
        year_end: ปีสิ้นสุด
        month_end: เดือนสิ้นสุด
        day_end: วันสิ้นสุด
        hour_end: ชั่วโมงสิ้นสุด
        geo: รหัสประเทศ
        cat: หมายเลข category
        gprop: ประเภท Google
        sleep: วินาทีที่ delay ระหว่าง request (ป้องกัน rate limit)
        hl: ภาษา

    Returns:
        ตารางแสดง interest รายชั่วโมง
    """
    try:
        pt = _get_pytrends(hl=hl)
        df = pt.get_historical_interest(
            keywords,
            year_start=year_start,
            month_start=month_start,
            day_start=day_start,
            hour_start=hour_start,
            year_end=year_end,
            month_end=month_end,
            day_end=day_end,
            hour_end=hour_end,
            cat=cat,
            geo=geo,
            gprop=gprop,
            sleep=sleep,
        )
        if df is None or df.empty:
            return "ไม่พบข้อมูล historical hourly interest"
        if "isPartial" in df.columns:
            df = df.drop(columns=["isPartial"])
        return (
            f"# Historical Hourly Interest\n"
            f"**Keywords:** {', '.join(keywords)}\n"
            f"**Period:** {year_start}-{month_start:02d}-{day_start:02d} to "
            f"{year_end}-{month_end:02d}-{day_end:02d}\n\n"
            f"{_df_to_text(df, max_rows=100)}"
        )
    except Exception as e:
        logger.error(traceback.format_exc())
        return f"Error: {e}"


# ---------------------------------------------------------------------------
# Tool 10: Compare Keywords (Bonus)
# ---------------------------------------------------------------------------
@mcp.tool()
def compare_keywords(
    keywords: list[str],
    timeframe: str = "today 12-m",
    geo: str = "",
    cat: int = 0,
    gprop: str = "",
    hl: str = "en-US",
) -> str:
    """
    เปรียบเทียบ keyword หลายตัวแบบครบวงจร (Interest Over Time + Interest by Region + Related Queries)

    รวม 3 มุมมองไว้ในคำสั่งเดียว เหมาะสำหรับวิเคราะห์ keyword เชิงเปรียบเทียบ

    Args:
        keywords: รายการ keyword (2-5 ตัว) เช่น ["iPhone", "Samsung", "Pixel"]
        timeframe: ช่วงเวลา เช่น "today 12-m", "today 3-m"
        geo: รหัสประเทศ
        cat: หมายเลข category
        gprop: ประเภท Google
        hl: ภาษา

    Returns:
        รายงานเปรียบเทียบแบบครบวงจร
    """
    try:
        if len(keywords) < 2:
            return "ต้องระบุอย่างน้อย 2 keywords สำหรับการเปรียบเทียบ"

        pt = _get_pytrends(hl=hl)
        _build_payload(pt, keywords, timeframe, geo, cat, gprop)

        parts = [
            f"# Keyword Comparison Report",
            f"**Keywords:** {', '.join(keywords)}",
            f"**Timeframe:** {timeframe}",
            f"**Geo:** {geo or 'Worldwide'}",
            "",
        ]

        # 1) Interest Over Time
        parts.append("---\n## 1. Interest Over Time")
        try:
            iot = pt.interest_over_time()
            if not iot.empty:
                if "isPartial" in iot.columns:
                    iot = iot.drop(columns=["isPartial"])
                # แสดง summary stats
                parts.append("### Summary Statistics")
                stats = iot[keywords].describe().loc[["mean", "std", "min", "max"]]
                parts.append(_df_to_text(stats))
                parts.append("")
                # แสดง recent 10 rows
                parts.append("### Recent Data (last 10 periods)")
                parts.append(_df_to_text(iot.tail(10)))
            else:
                parts.append("(ไม่มีข้อมูล)")
        except Exception as ex:
            parts.append(f"(Error: {ex})")

        # 2) Interest by Region (Top 15)
        parts.append("\n---\n## 2. Interest by Region (Top 15)")
        try:
            ibr = pt.interest_by_region(resolution="COUNTRY", inc_low_vol=True)
            if not ibr.empty:
                ibr_sorted = ibr.sort_values(by=keywords[0], ascending=False)
                ibr_sorted = ibr_sorted[ibr_sorted[keywords[0]] > 0].head(15)
                parts.append(_df_to_text(ibr_sorted))
            else:
                parts.append("(ไม่มีข้อมูล)")
        except Exception as ex:
            parts.append(f"(Error: {ex})")

        # 3) Related Queries (Top 5 per keyword)
        parts.append("\n---\n## 3. Related Queries (Top)")
        try:
            rq = pt.related_queries()
            for kw in keywords:
                if kw in rq and isinstance(rq[kw], dict):
                    top_q = rq[kw].get("top")
                    if isinstance(top_q, pd.DataFrame) and not top_q.empty:
                        parts.append(f"### {kw}")
                        parts.append(_df_to_text(top_q.head(5)))
        except Exception as ex:
            parts.append(f"(Error: {ex})")

        return "\n".join(parts)
    except Exception as e:
        logger.error(traceback.format_exc())
        return f"Error: {e}"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
