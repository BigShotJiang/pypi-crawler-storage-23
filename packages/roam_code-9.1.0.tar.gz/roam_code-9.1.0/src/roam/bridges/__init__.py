"""Cross-language bridge framework for symbol resolution."""
from __future__ import annotations
