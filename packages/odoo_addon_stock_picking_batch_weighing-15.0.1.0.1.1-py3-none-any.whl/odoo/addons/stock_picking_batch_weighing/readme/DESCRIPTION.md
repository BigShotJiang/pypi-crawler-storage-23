We can go to the weighing operations from an action button in the batch picking form.
