from .at_track import AITraceTracker

__all__ = [
    "track"
]

tracker = AITraceTracker()

track = tracker.track
