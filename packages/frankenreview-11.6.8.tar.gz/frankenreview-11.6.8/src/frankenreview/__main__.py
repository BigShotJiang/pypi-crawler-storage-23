"""
Frankenreview v11 - Entry point for `python -m frankenreview`
"""

from .cli import main

if __name__ == "__main__":
    main()
