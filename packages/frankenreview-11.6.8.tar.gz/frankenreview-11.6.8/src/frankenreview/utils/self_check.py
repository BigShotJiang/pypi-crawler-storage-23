"""
Frankenreview Self-Check Module

Provides diagnostic checks for project health and configuration validation.
"""

import sys
import ast
import json
from pathlib import Path


def check_syntax(root_dir: Path) -> dict:
    """
    Check all Python files for syntax errors using AST.
    
    Args:
        root_dir: Directory to scan for Python files.
        
    Returns:
        Dictionary with status, count of files checked, and any errors.
    """
    errors = []
    count = 0
    for file in root_dir.rglob("*.py"):
        if "venv" in str(file) or ".frankenreview" in str(file):
            continue
        try:
            with open(file, "r", encoding="utf-8") as f:
                ast.parse(f.read(), filename=str(file))
            count += 1
        except SyntaxError as e:
            errors.append(f"{file.name}: {e}")
        except Exception as e:
            errors.append(f"{file.name}: {e}")
            
    return {
        "status": "passed" if not errors else "failed",
        "checked": count,
        "errors": errors
    }


def check_config(root_dir: Path) -> dict:
    """
    Check if config.yaml exists and is valid YAML.
    
    Args:
        root_dir: The frankenreview source directory.
        
    Returns:
        Dictionary with status and config details.
    """
    config_path = root_dir.parent.parent / "config.yaml"
    if not config_path.exists():
        return {"status": "warning", "message": "config.yaml not found"}
    
    try:
        import yaml
        with open(config_path) as f:
            cfg = yaml.safe_load(f)
        return {"status": "passed", "keys": list(cfg.keys())}
    except Exception as e:
        return {"status": "failed", "error": str(e)}


def check_imports(root_dir: Path) -> dict:
    """
    Check that critical imports are available.
    
    Args:
        root_dir: Project source directory.
        
    Returns:
        Dictionary with import check results.
    """
    required = ["playwright", "yaml"]
    missing = []
    
    for pkg in required:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    
    return {
        "status": "passed" if not missing else "failed",
        "missing": missing
    }


def run_self_check(json_output: bool = False) -> int:
    """
    Run comprehensive self-diagnostic checks.
    
    Validates syntax, imports, and configuration for the project.
    
    Args:
        json_output: If True, output results as JSON; otherwise print human-readable.
        
    Returns:
        Exit code: 0 for success, 1 for failure.
    """
    root_dir = Path(__file__).parent.parent
    project_root = root_dir.parent.parent
    
    results = {
        "syntax": check_syntax(root_dir),
        "imports": check_imports(root_dir),
        "config": check_config(root_dir)
    }
    
    all_passed = all(
        r.get("status") == "passed" 
        for r in results.values()
    )
    
    results["overall"] = "passed" if all_passed else "failed"
    
    if json_output:
        print(json.dumps(results, indent=2))
    else:
        print("[>] Frankenreview Self-Check")
        print()
        
        for check_name, check_result in results.items():
            if check_name == "overall":
                continue
            status = check_result.get("status", "unknown")
            icon = "[+]" if status == "passed" else "[!]" if status == "warning" else "[x]"
            print(f"  {icon} {check_name.capitalize()}: {status}")
            
            if status == "failed":
                if "errors" in check_result and check_result["errors"]:
                    for err in check_result["errors"][:5]:
                        print(f"      - {err}")
                if "missing" in check_result:
                    print(f"      Missing: {', '.join(check_result['missing'])}")
                if "error" in check_result:
                    print(f"      {check_result['error']}")
        
        print()
        if all_passed:
            print("[+] All checks passed.")
        else:
            print("[!] Some checks failed. Review output above.")
    
    return 0 if all_passed else 1
