# Frankenreview v11.6.7

<p align="center">
  <img src="https://img.shields.io/badge/version-11.6.7-blue.svg" alt="Version">
  <img src="https://img.shields.io/badge/python-3.8+-green.svg" alt="Python">
  <img src="https://img.shields.io/badge/cost-$0.00-success.svg" alt="Cost">
  <img src="https://img.shields.io/badge/model-Gemini-purple.svg" alt="Gemini">
  <img src="https://img.shields.io/badge/status-production-brightgreen.svg" alt="Status">
</p>

> Lean, stateless, zero-cost code reviewer and research agent powered by Gemini via browser automation.

**Architecture:** Pull Model | **Cost:** $0.00 | **Runtime:** Playwright + Chrome

> [!CAUTION]
> **Data Privacy Notice**: Google AI Studio may use submitted code for model training. Do NOT submit proprietary, confidential, or sensitive code.

---

## Overview

Frankenreview packs a repository into structured XML context and submits it to Gemini via browser automation (no API key required).

| Layer | Module | Function |
|---|---|---|
| **Dumper** | `engine/repo_dumper.py` | Repository to XML context |
| **Browser** | `engine/browser/client.py` | AI Studio automation |
| **CLI** | `cli.py` | Stateless command interface |
| **Research** | `agents/research.py` | Deep research agent |

---

## Installation

```bash
pip install frankenreview && playwright install chromium
```

---

## Usage

```bash
frankenreview --start-chrome              # Start Chrome debugger
frankenreview -r                          # Review current directory
frankenreview -r --model gemini-3-pro     # Use specific model
frankenreview -r --json                   # JSON output for CI
frankenreview --research --prompt q.md    # Deep research

# Model Discovery
frankenreview --available-models           # Cached model list (instant)
frankenreview --fetch-models               # Live fetch from Google AI docs

# Session Management
frankenreview --open-chat                 # Open chat for manual use
frankenreview -r --continue               # Continue previous session
frankenreview --delete-chat               # Delete saved session
```

---

## CLI Reference

| Flag | Description |
|---|---|
| `-r`, `--review` | Run code review |
| `--research` | Deep research mode |
| `--start-chrome` | Launch Chrome debugger |
| `--stop-chrome` | Stop Chrome instance |
| `--path PATH` | Target project |
| `--model ID` | Gemini model ID |
| `--attach FILE` | Extra context files |
| `--json` | JSON output |
| `--continue` | Resume previous session |
| `--open-chat` | Open chat without review |
| `--delete-chat` | Delete saved session |
| `--available-models` | Display cached model compatibility list |
| `--fetch-models` | Actively fetch models from Google AI docs and update cache |

---

## Configuration

Edit `config.yaml`:

```yaml
chat_url: "https://aistudio.google.com/prompts/new_chat?model=gemini-flash-latest"
delete_after_review: true
prune_dirs: [.git, node_modules, __pycache__]
model_failover: [gemini-3-flash-preview, gemini-2.5-pro, gemini-2.0-flash]
```

---

## Documentation

- [CONTEXT.md](docs/CONTEXT.md) - Architecture
- [FR_FEATURE_CATALOG.md](docs/FR_FEATURE_CATALOG.md) - Features
- [MODEL_COMPATIBILITY_2026.md](docs/MODEL_COMPATIBILITY_2026.md) - Models

---

## License

MIT - See [LICENSE](LICENSE)
