import json
import os
import re
import sys
import requests

from ..utils import metaflowconfig
from outerbounds._vendor import click


@click.group()
def cli(**kwargs):
    pass


@cli.group(help="Commands for pushing Deployments metadata.", hidden=True)
def flowproject(**kwargs):
    pass


@flowproject.command()
@click.option(
    "-d",
    "--config-dir",
    default=os.path.expanduser(os.environ.get("METAFLOW_HOME", "~/.metaflowconfig")),
    help="Path to Metaflow configuration directory",
    show_default=True,
)
@click.option(
    "-p",
    "--profile",
    default=os.environ.get("METAFLOW_PROFILE", ""),
    help="The named metaflow profile in which your workstation exists",
)
@click.option("--id", help="The ID for this deployment")
def get_metadata(config_dir, profile, id):
    api_url = metaflowconfig.get_sanitized_url_from_config(
        config_dir, profile, "OBP_API_SERVER"
    )
    perimeter = _get_perimeter(config_dir, profile)
    headers = _get_request_headers()

    project, branch = _parse_id(id)

    # GET the latest flowproject config in order to modify it
    # /v1/perimeters/:perimeter/:project/:branch/flowprojects/latest
    response = requests.get(
        url=f"{api_url}/v1/perimeters/{perimeter}/projects/{project}/branches/{branch}/latestflowproject",
        headers=headers,
    )
    if response.status_code >= 500:
        raise Exception("API request failed.")

    body = response.json()
    if response.status_code >= 400:
        raise Exception("request failed: %s" % body)

    out = json.dumps(body)

    print(out, file=sys.stdout)


@flowproject.command()
@click.option(
    "-d",
    "--config-dir",
    default=os.path.expanduser(os.environ.get("METAFLOW_HOME", "~/.metaflowconfig")),
    help="Path to Metaflow configuration directory",
    show_default=True,
)
@click.option(
    "-p",
    "--profile",
    default=os.environ.get("METAFLOW_PROFILE", ""),
    help="The named metaflow profile in which your workstation exists",
)
@click.argument("json_str")
def set_metadata(config_dir, profile, json_str):
    api_url = metaflowconfig.get_sanitized_url_from_config(
        config_dir, profile, "OBP_API_SERVER"
    )

    perimeter = _get_perimeter(config_dir, profile)
    headers = _get_request_headers()
    payload = json.loads(json_str)

    # POST the updated flowproject config
    # /v1/perimeters/:perimeter/flowprojects
    response = requests.post(
        url=f"{api_url}/v1/perimeters/{perimeter}/flowprojects",
        json=payload,
        headers=headers,
    )
    if response.status_code >= 500:
        raise Exception("API request failed. %s" % response.text)

    if response.status_code >= 400:
        raise Exception("request failed: %s" % response.text)
    body = response.json()

    print(body, file=sys.stdout)


@flowproject.command(
    name="list-templates",
    help="List deployed workflow templates for a project/branch.",
)
@click.option(
    "-d",
    "--config-dir",
    default=os.path.expanduser(os.environ.get("METAFLOW_HOME", "~/.metaflowconfig")),
    help="Path to Metaflow configuration directory",
    show_default=True,
)
@click.option(
    "-p",
    "--profile",
    default=os.environ.get("METAFLOW_PROFILE", ""),
    help="The named metaflow profile in which your workstation exists",
)
@click.option("--id", required=True, help="project/branch identifier")
@click.option(
    "-o",
    "--output",
    default="",
    help="Output format",
    type=click.Choice(["json", ""]),
)
def list_templates(config_dir, profile, id, output):
    api_url = metaflowconfig.get_sanitized_url_from_config(
        config_dir, profile, "OBP_API_SERVER"
    )
    perimeter = _get_perimeter(config_dir, profile)
    headers = _get_request_headers()

    project, branch = _parse_id(id)
    templates = _list_argo_templates(project, branch)

    if output == "json":
        print(json.dumps({"templates": templates}), file=sys.stdout)
    else:
        if not templates:
            print(f"No workflow templates found for {project}/{branch}")
        else:
            print(f"🟩🟩🟩 Workflow Templates for {project}/{branch}")
            for name in templates:
                print(f"🌀 Found template: {name}")
            print(f"✅ {len(templates)} templates found")


@flowproject.command(
    name="delete-metadata",
    help="Delete flowproject metadata for a project/branch.",
)
@click.option(
    "-d",
    "--config-dir",
    default=os.path.expanduser(os.environ.get("METAFLOW_HOME", "~/.metaflowconfig")),
    help="Path to Metaflow configuration directory",
    show_default=True,
)
@click.option(
    "-p",
    "--profile",
    default=os.environ.get("METAFLOW_PROFILE", ""),
    help="The named metaflow profile in which your workstation exists",
)
@click.option("--id", required=True, help="project/branch identifier")
@click.option("--yes", is_flag=True, help="Skip confirmation prompt")
@click.option(
    "-o",
    "--output",
    default="",
    help="Output format",
    type=click.Choice(["json", ""]),
)
def delete_metadata(config_dir, profile, id, yes, output):
    api_url = metaflowconfig.get_sanitized_url_from_config(
        config_dir, profile, "OBP_API_SERVER"
    )
    perimeter = _get_perimeter(config_dir, profile)
    headers = _get_request_headers()

    project, branch = _parse_id(id)

    if not yes:
        click.confirm(
            f"Delete all flowproject metadata for {project}/{branch}?", abort=True
        )

    url = (
        f"{api_url}/v1/perimeters/{perimeter}/projects/{project}"
        f"/branches/{branch}/flowprojects"
    )
    response = requests.delete(url=url, headers=headers)
    if response.status_code >= 500:
        raise Exception("API request failed. %s" % response.text)
    if response.status_code >= 400:
        raise Exception("request failed: %s" % response.text)

    msg = f"Flowproject metadata deleted for {project}/{branch}."
    if output == "json":
        print(json.dumps({"status": "ok", "message": msg}), file=sys.stdout)
    else:
        print(f"✅ {msg}")


@flowproject.command(
    name="teardown-branch",
    help="Tear down all deployed resources for a project/branch.",
)
@click.option(
    "-d",
    "--config-dir",
    default=os.path.expanduser(os.environ.get("METAFLOW_HOME", "~/.metaflowconfig")),
    help="Path to Metaflow configuration directory",
    show_default=True,
)
@click.option(
    "-p",
    "--profile",
    default=os.environ.get("METAFLOW_PROFILE", ""),
    help="The named metaflow profile in which your workstation exists",
)
@click.option("--id", required=True, help="project/branch identifier")
@click.option(
    "--dry-run", is_flag=True, help="Print what would be deleted without deleting"
)
@click.option("--yes", is_flag=True, help="Skip confirmation prompt")
@click.option(
    "-o",
    "--output",
    default="",
    help="Output format",
    type=click.Choice(["json", ""]),
)
def teardown_branch(config_dir, profile, id, dry_run, yes, output):
    api_url = metaflowconfig.get_sanitized_url_from_config(
        config_dir, profile, "OBP_API_SERVER"
    )
    perimeter = _get_perimeter(config_dir, profile)
    headers = _get_request_headers()

    project, branch = _parse_id(id)

    # ------ discover resources ------
    print(f"🟩🟩🟩 Discovering Resources for {project}/{branch}")

    metadata = _get_flowproject_metadata(api_url, perimeter, headers, project, branch)
    templates = _list_argo_templates(project, branch)
    data_assets = _assets_from_metadata(metadata, "data")
    model_assets = _assets_from_metadata(metadata, "models")
    apps = _list_apps(api_url, perimeter, headers, project, branch)
    has_metadata = metadata is not None

    for tpl in templates:
        print(f"🌀 Found template: {tpl}")
    for name in data_assets:
        print(f"🌀 Found data asset: {name}")
    for name in model_assets:
        print(f"🌀 Found model asset: {name}")
    for app in apps:
        print(f"🌀 Found app: {app['name']}")
    if has_metadata:
        print("🌀 Found flowproject metadata")

    # ------ summarize ------
    summary = {
        "workflow_templates": templates,
        "data_assets": data_assets,
        "model_assets": model_assets,
        "apps": [a["name"] for a in apps],
        "flowproject_metadata": has_metadata,
    }

    total = (
        len(templates)
        + len(data_assets)
        + len(model_assets)
        + len(apps)
        + (1 if has_metadata else 0)
    )

    if total == 0:
        msg = f"No resources found for {project}/{branch}. Nothing to tear down."
        if output == "json":
            print(
                json.dumps({"status": "noop", "message": msg, **summary}),
                file=sys.stdout,
            )
        else:
            print(msg)
        return

    print(f"✅ {total} resources discovered")

    if dry_run:
        if output == "json":
            print(
                json.dumps({"status": "dry_run", **summary}),
                file=sys.stdout,
            )
        else:
            print("Dry run — nothing was deleted.")
        return

    # ------ confirm ------
    if not yes:
        click.confirm(f"Delete {total} resource(s) for {project}/{branch}?", abort=True)

    # ------ execute teardown ------
    print(f"🟩🟩🟩 Tearing Down Resources")
    errors = []

    # 1. workflow templates (cascade deletes crons + sensors)
    for tpl in templates:
        print(f"⚙️ Deleting template: {tpl}")
        try:
            _delete_workflow_template(api_url, perimeter, headers, tpl)
        except Exception as exc:
            print(f"❌ Failed to delete template {tpl}: {exc}")
            errors.append({"resource": "template", "name": tpl, "error": str(exc)})

    # 2. data assets
    for asset_name in data_assets:
        print(f"⚙️ Deleting data asset: {asset_name}")
        try:
            _delete_asset(
                api_url, perimeter, headers, project, branch, "data", asset_name
            )
        except Exception as exc:
            print(f"❌ Failed to delete data asset {asset_name}: {exc}")
            errors.append(
                {"resource": "data_asset", "name": asset_name, "error": str(exc)}
            )

    # 3. model assets
    for asset_name in model_assets:
        print(f"⚙️ Deleting model asset: {asset_name}")
        try:
            _delete_asset(
                api_url, perimeter, headers, project, branch, "models", asset_name
            )
        except Exception as exc:
            print(f"❌ Failed to delete model asset {asset_name}: {exc}")
            errors.append(
                {"resource": "model_asset", "name": asset_name, "error": str(exc)}
            )

    # 4. apps
    for app in apps:
        print(f"⚙️ Deleting app: {app['name']}")
        try:
            _delete_app(api_url, perimeter, headers, app["id"])
        except Exception as exc:
            print(f"❌ Failed to delete app {app['name']}: {exc}")
            errors.append({"resource": "app", "name": app["name"], "error": str(exc)})

    # 5. flowproject metadata
    if has_metadata:
        print("⚙️ Deleting flowproject metadata")
        try:
            url = (
                f"{api_url}/v1/perimeters/{perimeter}/projects/{project}"
                f"/branches/{branch}/flowprojects"
            )
            resp = requests.delete(url=url, headers=headers)
            resp.raise_for_status()
        except Exception as exc:
            print(f"❌ Failed to delete flowproject metadata: {exc}")
            errors.append({"resource": "flowproject_metadata", "error": str(exc)})

    # ------ report ------
    if errors:
        msg = f"Teardown completed with {len(errors)} error(s)."
        if output == "json":
            print(
                json.dumps({"status": "partial", "message": msg, "errors": errors}),
                file=sys.stdout,
            )
        else:
            print(f"❌ {msg}")
        sys.exit(1)
    else:
        deleted = total - len(errors)
        print(f"✅ {deleted} resources deleted successfully")
        if output == "json":
            print(
                json.dumps(
                    {
                        "status": "ok",
                        "message": f"Teardown complete for {project}/{branch}.",
                    }
                ),
                file=sys.stdout,
            )
        else:
            print(f"✅✅✅ Teardown successful!")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_request_headers():
    headers = {"Content-Type": "application/json", "Connection": "keep-alive"}
    try:
        from metaflow.metaflow_config import SERVICE_HEADERS

        headers = {**headers, **(SERVICE_HEADERS or {})}
    except ImportError:
        headers = headers

    return headers


def _get_perimeter(config_dir, profile):
    """Read the current perimeter from the resolved config."""
    conf = metaflowconfig.init_config(config_dir, profile)
    perimeter = conf.get("OBP_PERIMETER") or os.environ.get("OBP_PERIMETER")
    if perimeter is None:
        raise Exception("Perimeter not found in config, but is required.")
    return perimeter


def _parse_id(id: str):
    parts = id.split("/")
    if len(parts) != 2:
        raise Exception("ID should consist of two parts: project/branch")

    project, branch = parts
    # Sanitize the branch the same way deploy_obproject does so API
    # lookups match what was stored during deploy.
    branch = _sanitize_branch(branch)
    return project, branch


def _sanitize_branch(branch: str) -> str:
    """Normalize a git branch name the same way deploy_obproject does."""
    return re.sub(r"[-/]", "_", branch).lower()


def _get_flowproject_metadata(api_url, perimeter, headers, project, branch):
    """Fetch the latest flowproject metadata, or None if not found."""
    url = (
        f"{api_url}/v1/perimeters/{perimeter}/projects/{project}"
        f"/branches/{branch}/latestflowproject"
    )
    resp = requests.get(url=url, headers=headers)
    if resp.status_code >= 400:
        return None
    return resp.json()


def _templates_from_metadata(metadata):
    """Extract workflow template IDs from flowproject metadata."""
    if metadata is None:
        return []
    return [
        w["flow_template_id"]
        for w in metadata.get("workflows", [])
        if w.get("flow_template_id")
    ]


def _assets_from_metadata(metadata, kind):
    """Extract asset IDs from flowproject metadata.  *kind* is 'data' or 'models'."""
    if metadata is None:
        return []
    return [
        item.get("id", "") for item in metadata.get(kind, []) if item and item.get("id")
    ]


def _get_metaflow_branch(branch):
    """Convert a sanitized branch to the metaflow branch annotation value.

    Metaflow's ``@project`` decorator produces three branch formats:

    * ``prod``  — ``--production`` without ``--branch``
    * ``test.<branch>`` — ``--branch=<branch>`` without ``--production``
    * ``user.<username>`` — neither flag (local dev)

    ``deploy_obproject`` always passes ``--production`` (main/master) or
    ``--branch`` (everything else), so deployed templates are always ``prod``
    or ``test.*``.  However a user can also pass ``user.<name>`` directly
    as the branch component of ``--id`` to target ``user.*`` templates.
    """
    if branch in ("main", "master"):
        return "prod"
    if branch.startswith("user."):
        return branch
    return f"test.{branch}"


def _list_argo_templates(project, branch):
    """List actual Argo workflow template names for a project/branch.

    Queries Argo directly so that truncated names are resolved correctly.
    """
    import urllib3

    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    from metaflow.plugins.argo.argo_client import ArgoClient
    from metaflow.metaflow_config import KUBERNETES_NAMESPACE

    metaflow_branch = _get_metaflow_branch(branch)
    client = ArgoClient(namespace=KUBERNETES_NAMESPACE)

    matched = []
    for template in client.get_workflow_templates():
        annotations = template.get("metadata", {}).get("annotations", {})
        if (
            annotations.get("metaflow/project_name") == project
            and annotations.get("metaflow/branch_name") == metaflow_branch
        ):
            matched.append(template["metadata"]["name"])
    return matched


def _list_apps(api_url, perimeter, headers, project, branch):
    """List app capsules matching project and branch tags."""
    url = f"{api_url}/v1/perimeters/{perimeter}/capsules"
    resp = requests.get(url=url, headers=headers)
    if resp.status_code >= 400:
        return []
    data = resp.json()
    capsules = (
        data if isinstance(data, list) else data.get("capsules", data.get("data", []))
    )

    matched = []
    for capsule in capsules:
        tags = capsule.get("spec", {}).get("tags", [])
        has_project = any(
            t.get("key") == "project" and t.get("value") == project for t in tags
        )
        has_branch = any(
            t.get("key") == "branch" and t.get("value") == branch for t in tags
        )
        if has_project and has_branch:
            name = capsule.get("spec", {}).get(
                "displayName", capsule.get("id", "unknown")
            )
            matched.append({"id": capsule["id"], "name": name})
    return matched


def _delete_app(api_url, perimeter, headers, capsule_id):
    """Delete a single app capsule by ID."""
    url = f"{api_url}/v1/perimeters/{perimeter}/capsules/{capsule_id}"
    resp = requests.delete(url=url, headers=headers)
    resp.raise_for_status()


def _delete_workflow_template(api_url, perimeter, headers, template_name):
    """Delete a single workflow template (cascades to crons + sensors)."""
    import urllib3

    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    from metaflow.plugins.argo.argo_workflows import ArgoWorkflows

    ArgoWorkflows.delete(template_name)


def _delete_asset(api_url, perimeter, headers, project, branch, kind, asset_name):
    """Delete a single asset.  *kind* is 'data' or 'models'."""
    url = (
        f"{api_url}/v1/perimeters/{perimeter}/projects/{project}"
        f"/branches/{branch}/{kind}/{asset_name}"
    )
    resp = requests.delete(url=url, headers=headers)
    resp.raise_for_status()
