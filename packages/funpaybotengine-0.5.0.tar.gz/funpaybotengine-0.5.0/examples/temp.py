from __future__ import annotations

import asyncio

from funpaybotengine import Bot, Dispatcher
from funpaybotengine.types import Message


bot: Bot = Bot(golden_key='12345678901234567890123456789012')  # Создаем экземляр бота
dp: Dispatcher = Dispatcher()  # Создаем диспетчер - корневой роутер


# Регистрируем хэндлер на событие о новом сообщении
# Хэндлер отработает на абсолютно любое сообщение.
@dp.on_new_message()
async def print_message(message: Message) -> None:
    print(f'Пришло новое сообщение от {message.sender_username}: ')
    print(message.text or message.image_url)


# Регистрируем хэндлер на событие о новом сообщении
# Хэндлер сработает тольько в том случае, если текст сообщения == 'привет'
@dp.on_new_message(lambda message: message.text.lower() == 'привет')
async def echo(message: Message) -> None:
    await message.reply('Пока')


async def main() -> None:
    # Запускаем цикл получения новых событий.
    await bot.listen_events(dp)


if __name__ == '__main__':
    asyncio.run(main())
