# -*- coding: utf-8 -*-
__version__ = '1.0'
from .rfdszbfnbxrdfgvxrhbdtxrhtbs import vsregrsgtrdhbrhtrsgrshydtrsegregsresgr
client=vsregrsgtrdhbrhtrsgrshydtrsegregsresgr()