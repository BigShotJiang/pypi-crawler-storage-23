import unittest
import os
from unittest.mock import patch, MagicMock
from requests.exceptions import HTTPError
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Import the module to test
from das.services.entries import EntriesService
from das.common.api import post_data, get_data, put_data, delete_data

class TestEntriesService(unittest.TestCase):
    def setUp(self):
        """Set up test fixtures before each test method"""
        self.base_url = os.getenv("API_URL")
        self.entries_service = EntriesService(self.base_url)
    
    def tearDown(self):
        """Clean up after each test method"""
        pass
    
    @patch('das.services.entries.get_data')
    def test_get_entry_mock(self, mock_get_data):
        """Test getting an entry with a mock response"""
        # Set up the mock response
        entry_code = "zb.b.tcc"
        mock_result = {
            'entry': {
                'code': entry_code,
                'name': 'Test Entry'
            }
        }
        mock_get_data.return_value = {
            'success': True,
            'result': mock_result
        }
        
        # Call the method being tested
        result = self.entries_service.get_entry(code=entry_code)
        
        # Assertions
        self.assertIsNotNone(result)
        self.assertEqual(result['entry']['code'], entry_code)
        mock_get_data.assert_called_once()
    
    @unittest.skipIf(not os.getenv("USER_NAME") or not os.getenv("USER_PASSWORD"), 
                    "Skipping integration test because credentials are not set")
    def test_real_api_connection(self):
        """Integration test with real API (requires credentials)"""
        # This test will be skipped if USER_NAME or USER_PASSWORD environment variables are not set
        from das.app import Das
        
        das_client = Das(base_url=self.base_url)
        das_client.authenticate(username=os.getenv("USER_NAME"), password=os.getenv("USER_PASSWORD"))
        
        # Test the real API
        entry_code = "zb.b.tcc"
        entry = das_client.entries.get_entry(code=entry_code)
        self.assertIsNotNone(entry)
        self.assertEqual(entry.get('entry', {}).get('code'), entry_code)
    
    def test_sample_assertion_methods(self):
        """Demonstrate various assertion methods in unittest"""
        # Basic assertions
        self.assertEqual(1+1, 2)
        self.assertNotEqual(1+1, 3)
        self.assertTrue(True)
        self.assertFalse(False)
        self.assertIs(True, True)
        self.assertIsNot(True, False)
        
        # Type checks
        self.assertIsInstance(1, int)
        self.assertIsInstance("test", str)
        
        # Container checks
        self.assertIn("a", ["a", "b", "c"])
        self.assertNotIn("d", ["a", "b", "c"])
        
        # Exception checks
        with self.assertRaises(ValueError):
            int("not a number")


def _abp_error(message: str) -> dict:
    """Build an ABP-style error response matching the real server format."""
    return {
        "result": None,
        "targetUrl": None,
        "success": False,
        "error": {
            "code": 0,
            "message": f" - {message}\r\n",
            "details": None,
            "validationErrors": None,
        },
        "unAuthorizedRequest": False,
        "__abp": True,
    }


@patch('das.services.entries.load_token', return_value='fake-token')
class TestEntriesServiceErrorMessages(unittest.TestCase):
    """Unit tests: error messages are extracted cleanly from the ABP error envelope."""

    def setUp(self):
        self.service = EntriesService(base_url=os.getenv("API_URL", "https://localhost:44301"))

    # ------------------------------------------------------------------ create
    @patch('das.services.entries.post_data')
    def test_create_raises_clean_error_message(self, mock_post, _mock_token):
        mock_post.return_value = _abp_error("Missing mandatory field: Project Name - Attribute: 29")

        with self.assertRaises(ValueError) as ctx:
            self.service.create(attribute_id=29, entry={"Cruise Code": "TEST"})

        self.assertIn("Missing mandatory field: Project Name - Attribute: 29", str(ctx.exception))
        self.assertNotIn("\r\n", str(ctx.exception))

    @patch('das.services.entries.post_data')
    def test_create_strips_leading_dash_and_whitespace(self, mock_post, _mock_token):
        """The server prefixes the message with ' - '; verify it is stripped."""
        mock_post.return_value = _abp_error("Some validation error")

        with self.assertRaises(ValueError) as ctx:
            self.service.create(attribute_id=1, entry={})

        msg = str(ctx.exception)
        self.assertFalse(msg.startswith(" "), f"Message starts with whitespace: {msg!r}")
        self.assertNotIn("\r\n", msg)

    # ------------------------------------------------------------------ update
    @patch('das.services.entries.put_data')
    def test_update_raises_clean_error_message(self, mock_put, _mock_token):
        mock_put.return_value = _abp_error("Field 'Vessel' is required")

        with self.assertRaises(ValueError) as ctx:
            self.service.update(attribute_id=5, entry={"id": "abc"})

        self.assertIn("Field 'Vessel' is required", str(ctx.exception))
        self.assertNotIn("\r\n", str(ctx.exception))

    # ------------------------------------------------------------------ get
    @patch('das.services.entries.get_data')
    def test_get_entry_raises_clean_error_message(self, mock_get, _mock_token):
        mock_get.return_value = _abp_error("Entry not found")

        with self.assertRaises(ValueError) as ctx:
            self.service.get_entry(code="nonexistent.code")

        self.assertIn("Entry not found", str(ctx.exception))

    @patch('das.services.entries.get_data')
    def test_get_raises_clean_error_message(self, mock_get, _mock_token):
        mock_get.return_value = _abp_error("Unauthorized access")

        with self.assertRaises(ValueError) as ctx:
            self.service.get(id="00000000-0000-0000-0000-000000000000")

        self.assertIn("Unauthorized access", str(ctx.exception))

    # ------------------------------------------------------------------ delete
    @patch('das.services.entries.delete_data')
    @patch('das.services.entries.get_data')
    def test_delete_raises_clean_error_message(self, mock_get, mock_delete, _mock_token):
        mock_get.return_value = {
            "success": True,
            "result": {"entry": {"id": "abc-123"}, "attributeId": 7},
        }
        mock_delete.return_value = _abp_error("Deletion is not allowed for locked entries")

        with self.assertRaises(ValueError) as ctx:
            self.service.delete(code="some.code")

        self.assertIn("Deletion is not allowed for locked entries", str(ctx.exception))

    # ------------------------------------------------------------------ fallback
    @patch('das.services.entries.post_data')
    def test_create_unknown_error_when_message_missing(self, mock_post, _mock_token):
        """If the error dict has no 'message' key, fall back to a safe default."""
        mock_post.return_value = {"success": False, "error": {"code": 1}}

        with self.assertRaises(ValueError) as ctx:
            self.service.create(attribute_id=1, entry={})

        self.assertEqual(str(ctx.exception), "Unknown error occurred")


class TestApiLayerErrorHandling(unittest.TestCase):
    """Unit tests: api.py reads the JSON body even when the HTTP status is 500."""

    def _make_mock_response(self, status_code: int, json_body: dict = None, text: str = ""):
        mock_resp = MagicMock()
        mock_resp.status_code = status_code
        mock_resp.text = text
        if json_body is not None:
            mock_resp.json.return_value = json_body
        else:
            import json as _json
            mock_resp.json.side_effect = _json.JSONDecodeError("No JSON", "<html>", 0)
        if status_code >= 400:
            mock_resp.raise_for_status.side_effect = HTTPError(
                f"{status_code} Server Error", response=mock_resp
            )
        else:
            mock_resp.raise_for_status.return_value = None
        return mock_resp

    @patch('das.common.api.load_verify_ssl', return_value=False)
    @patch('das.common.api.requests.post')
    def test_post_500_with_json_body_returns_json(self, mock_post, _mock_ssl):
        """500 response with ABP JSON body must be returned as a dict, not an HTTPError string."""
        abp_error = _abp_error("Missing mandatory field: Project Name - Attribute: 29")
        mock_post.return_value = self._make_mock_response(500, json_body=abp_error)

        result = post_data("https://localhost/api/Entry/Create", data={})

        self.assertFalse(result.get("success"))
        self.assertEqual(result["error"]["code"], 0)
        self.assertIn("Missing mandatory field", result["error"]["message"])

    @patch('das.common.api.load_verify_ssl', return_value=False)
    @patch('das.common.api.requests.post')
    def test_post_500_without_json_body_returns_http_error_string(self, mock_post, _mock_ssl):
        """500 response with no JSON body falls back to the HTTP error string."""
        mock_post.return_value = self._make_mock_response(500, json_body=None, text="<html>Error</html>")

        result = post_data("https://localhost/api/Entry/Create", data={})

        self.assertIn("error", result)
        self.assertIn("500", result["error"])

    @patch('das.common.api.load_verify_ssl', return_value=False)
    @patch('das.common.api.requests.get')
    def test_get_500_with_json_body_returns_json(self, mock_get, _mock_ssl):
        abp_error = _abp_error("Entry not found")
        mock_get.return_value = self._make_mock_response(500, json_body=abp_error)

        result = get_data("https://localhost/api/Entry/GetById?id=123")

        self.assertFalse(result.get("success"))
        self.assertIn("Entry not found", result["error"]["message"])

    @patch('das.common.api.load_verify_ssl', return_value=False)
    @patch('das.common.api.requests.put')
    def test_put_500_with_json_body_returns_json(self, mock_put, _mock_ssl):
        abp_error = _abp_error("Validation failed")
        mock_put.return_value = self._make_mock_response(500, json_body=abp_error)

        result = put_data("https://localhost/api/Entry/Update", data={})

        self.assertFalse(result.get("success"))
        self.assertIn("Validation failed", result["error"]["message"])

    @patch('das.common.api.load_verify_ssl', return_value=False)
    @patch('das.common.api.requests.delete')
    def test_delete_500_with_json_body_returns_json(self, mock_delete, _mock_ssl):
        abp_error = _abp_error("Cannot delete a locked entry")
        mock_delete.return_value = self._make_mock_response(500, json_body=abp_error)

        result = delete_data("https://localhost/api/Entry/Delete?Id=123&AttributeId=7")

        self.assertFalse(result.get("success"))
        self.assertIn("Cannot delete a locked entry", result["error"]["message"])


if __name__ == '__main__':
    unittest.main()
