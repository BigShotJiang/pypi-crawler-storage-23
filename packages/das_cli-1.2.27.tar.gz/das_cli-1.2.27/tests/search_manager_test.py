import json
import os
import sys
import unittest
from dotenv import load_dotenv
from das.app import Das
from das.managers.search_manager import SearchManager
from das.common.config import save_verify_ssl, load_verify_ssl
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
load_dotenv()

class TestSearchManager(unittest.TestCase):
    def setUp(self):
        self.das_client = Das(base_url=os.getenv("API_URL"))
        self.das_client.authenticate(username=os.getenv("USER_NAME"), password=os.getenv("USER_PASSWORD"))

    def test_search_manager_with_filter(self):
        search_manager = SearchManager()
        results = search_manager.search_entries(attribute="Cores", query="name(64PE320-03BC#01) or code(zb.b.1ub)", max_results=5, page=1, sort_by="Name", sort_order="asc")
        self.assertIsInstance(results, dict)
        self.assertIn('items', results)
        self.assertGreater(len(results['items']), 0)

    def test_search_manager_with_filter_and_sorting(self):
        search_manager = SearchManager()
        results = search_manager.search_entries(attribute="Cores", query="name(64PE320-03BC#01) and code(zb.b.zub)", max_results=5, page=1, sort_by="Name", sort_order="asc")
        self.assertIsInstance(results, dict)
        self.assertIn('items', results)
        self.assertGreater(len(results['items']), 0)        

    def test_search_manager(self):
        search_manager = SearchManager()
        results = search_manager.search_entries(attribute="Cores", max_results=1000, query="", sort_by="Name", sort_order="asc")
        self.assertIsInstance(results, dict)
        self.assertIn('items', results)
        self.assertGreater(len(results['items']), 0)        

    def test_search_get_all_entries(self):
        save_verify_ssl(False)  # disable (dev/testing)
        search_manager = SearchManager()
        results = search_manager.search_entries(attribute="Digital Object Identifier", query="", max_results=1000, page=0, sort_by="Name", sort_order="asc")
        self.assertIsInstance(results, dict)
        self.assertIn('items', results)
        self.assertGreater(len(results['items']), 0)        
        with open("results.json", "w") as f:
            json.dump(results, f, indent=4)

if __name__ == '__main__':
    unittest.main()
