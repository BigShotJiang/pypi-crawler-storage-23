
from dotenv import load_dotenv
import unittest
import os
import random
import string
from das.app import Das
from das.common.config import save_api_url
from das.managers.entries_manager import EntryManager

# Load environment variables from .env file
load_dotenv()

class TestEntriesManager(unittest.TestCase):
    def setUp(self):
        """Set up test fixtures before each test method"""        
        self.das_client = Das(base_url=os.getenv("API_URL"))
        self.das_client.authenticate(username=os.getenv("USER_NAME"), password=os.getenv("USER_PASSWORD"))
        self.entry_manager = EntryManager()

    def test_create_entry(self):
        """Test creating an entry"""
        
        entry_data = {
            "Alias": "test.entry.001",
            "Event": "64PE428-02PC",
            "Number": 1,
            "Number Alias": "001",
            "Start Depth": 576,
            "End Depth": 600,
            "Length": 24,
            "Diameter": 12,
            "Storage location":  "OCS-refrigerator4 (core-lab)",
            "Availability": "pc.b.b",
            "Comment": "This is a test entry created by unit test."
        }

        created_entry_id = self.entry_manager.create(attribute="Cores", entry=entry_data)

        self.assertIsNotNone(created_entry_id)
        # assert createrd entry id is an guid
        self.assertRegex(created_entry_id[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')

    def test_delete_entry(self):
        """Test deleting an entry"""

        entry_data = {
            "Alias": "test.entry.001",
            "Event": "64PE428-02PC",
            "Number": 1,
            "Number Alias": "001",
            "Start Depth": 576,
            "End Depth": 600,
            "Length": 24,
            "Diameter": 12,
            "Storage location":  "OCS-refrigerator4 (core-lab)",
            "Availability": "pc.b.b",
            "Comment": "This is a test entry created by unit test."
        }

        response = self.entry_manager.create(attribute="Cores", entry=entry_data)  

        self.assertTrue(self.entry_manager.delete(id=response[0]['id']))

    def test_delete_entry_by_code(self):
        """Test deleting an entry by code"""

        entry_data = {
            "Alias": "test.entry.001",
            "Event": "64PE428-02PC",
            "Number": 1,
            "Number Alias": "001",
            "Start Depth": 576,
            "End Depth": 600,
            "Length": 24,
            "Diameter": 12,
            "Storage location":  "OCS-refrigerator4 (core-lab)",
            "Availability": "pc.b.b",
            "Comment": "This is a test entry created by unit test."
        }

        response = self.entry_manager.create(attribute="Cores", entry=entry_data)  

        entry = self.entry_manager.get(id=response[0]['id'])    

        self.assertIsNotNone(entry)

        self.assertTrue(self.entry_manager.delete(code=entry['Code']))  

    def test_create_new_cruise(self):
        """Test creating a new cruise"""

        project_data = {
           "Name":  "Project 1",
           "Description": "This is a test project",
           "Start Date": "2026-01-01",
           "End Date": "2026-01-02",
           "Principal Investigator": "John Doe",
           "Funding Agency": "NIOZ",
           "Grant Number": "1234567890",
           "Comment": "This is a test project",
           "Acronym": "TEST"
        }

        created_project = self.entry_manager.create(attribute="Project", entry=project_data)

        cruise_data = {
          "Cruise Code": "TEST-Cruise-001",
          "Project(s)": created_project[0].get('id'),
          "Vessel": "Algoa",
          "Start Date": "2026-01-01",
          "End Date": "2026-01-02",
          "Port of Departure": "Test Port",
          "Port of Arrival": "Test Port",
          "Principal Investigator": "John Doe",
          "MFP ID": "1234567890",          
          "Comment": "This is a test project",
          "Project name": "Project 1",
        }

        created_cruise = self.entry_manager.create(attribute="Cruise", entry=cruise_data)

        self.assertIsNotNone(created_cruise)
        self.assertRegex(created_cruise[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')


    def test_create_new_cruise_with_multiple_projects(self):
        """Test creating a new cruise with multiple projects"""
        # create a random phrase for the project name
        random_phrase = ''.join(random.choices(string.ascii_letters + string.digits, k=10))
        
        project_data = {
           "Name":  f"Project 1 - {random_phrase}",
           "Description": "This is a test project",
           "Start Date": "2026-01-01",
           "End Date": "2026-01-02",
           "Principal Investigator": "John Doe",
           "Funding Agency": "NIOZ",
           "Grant Number": "1234567890",
           "Comment": "This is a test project",
           "Acronym": random_phrase
        }

        created_project = self.entry_manager.create(attribute="Project", entry=project_data)
        project_1_id = created_project[0].get('id')
        
        project_data = {
           "Name":  f"Project 2 - {random_phrase}",
           "Description": "This is a test project",
           "Start Date": "2026-01-01",
           "End Date": "2026-01-02",
           "Principal Investigator": "John Doe",
           "Funding Agency": "NIOZ",
           "Grant Number": "1234567890",
           "Comment": "This is a test project",
           "Acronym": random_phrase
        }

        created_project = self.entry_manager.create(attribute="Project", entry=project_data)
        project_2_id = created_project[0].get('id')

        cruise_data = {
          "Cruise Code": f"TEST-Cruise-001-M-Ids-{random_phrase}",
          "Project(s)": f"{project_1_id},{project_2_id}",
          "Vessel": "Algoa",
          "Start Date": "2026-01-01",
          "End Date": "2026-01-02",
          "Port of Departure": "Test Port",
          "Port of Arrival": "Test Port",
          "Principal Investigator": "John Doe",
          "MFP ID": "1234567890",          
          "Comment": "This is a test project",
          "Project name": "Project 1",
        }

        created_cruise = self.entry_manager.create(attribute="Cruise", entry=cruise_data)

        self.assertIsNotNone(created_cruise)
        self.assertRegex(created_cruise[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')

    def test_create_new_cruise_with_multiple_projects_by_code(self):
        """Test creating a new cruise with multiple projects"""
        # create a random phrase for the project name
        random_phrase = ''.join(random.choices(string.ascii_letters + string.digits, k=10))

        project_data = {
           "Name":  f"Project 2 - {random_phrase}",
           "Description": "This is a test project",
           "Start Date": "2026-01-01",
           "End Date": "2026-01-02",
           "Principal Investigator": "John Doe",
           "Funding Agency": "NIOZ",
           "Grant Number": "1234567890",
           "Comment": "This is a test project",
           "Acronym": random_phrase
        }
        created_project = self.entry_manager.create(attribute="Project", entry=project_data)

        project_1 = self.entry_manager.get(id=created_project[0].get('id'))
        project_1_code = project_1.get('Code')

        project_data = {
           "Name":  f"Project 2 - {random_phrase}",
           "Description": "This is a test project",
           "Start Date": "2026-01-01",
           "End Date": "2026-01-02",
           "Principal Investigator": "John Doe",
           "Funding Agency": "NIOZ",
           "Grant Number": "1234567890",
           "Comment": "This is a test project",
           "Acronym": random_phrase
        }
        created_project = self.entry_manager.create(attribute="Project", entry=project_data)

        project_2 = self.entry_manager.get(id=created_project[0].get('id'))
        project_2_code = project_2.get('Code')

        cruise_data = {
          "Cruise Code": f"TEST-Cruise-001-M-Codes-{random_phrase}",
          "Project(s)": f"{project_1_code},{project_2_code}",
          "Vessel": "Algoa",
          "Start Date": "2026-01-01",
          "End Date": "2026-01-02",
          "Port of Departure": "Test Port",
          "Port of Arrival": "Test Port",
          "Principal Investigator": "John Doe",
          "MFP ID": "1234567890",          
          "Comment": "This is a test project",
          "Project name": "Project 1",
        }

        created_cruise = self.entry_manager.create(attribute="Cruise", entry=cruise_data)

        self.assertIsNotNone(created_cruise)
        self.assertRegex(created_cruise[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')        

    def test_update_entry(self):
        """Test updating an entry"""
        
        updated_entry_data = {
            'id': 'c4c6dff6-5ccb-11f0-a78d-a84a63c8db73', 
            'displayname': 'Aarnoud van de Burgt', 
            'order': 208, 
            'trackingnumber': 208, 
            'description': "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in orci consequat, hendrerit lectus in, lobortis magna. Duis pulvinar varius pellentesque. Suspendisse scelerisque dolor id ex aliquet, id luctus est euismod. Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec accumsan tortor leo, ultricies sodales risus volutpat in. Praesent quis augue lacinia, luctus nulla nec, gravida sapien. Nulla facilisi. Nunc molestie elementum velit ac mattis. Etiam sed magna vehicula lectus efficitur euismod quis ut purus. Integer ac dapibus tortor. Nullam sollicitudin semper tristique. Donec maximus lectus ac sapien mollis, et commodo ante rutrum. Vivamus erat dui, ullamcorper at tellus quis, tempor accumsan felis. Maecenas condimentum nunc eget ipsum consequat convallis. Proin pulvinar cursus mauris pretium finibus. Quisque orci lacus, ullamcorper nec ex et, vehicula sollicitudin nisl. Pellentesque tincidunt massa volutpat est rutrum, ut tincidunt diam interdum. Nunc sollicitudin posuere rutrum. Sed quis magna iaculis, consequat nibh ac, dictum dolor. Nullam lorem diam, sollicitudin ac pellentesque ut, tincidunt eget magna. Vestibulum finibus tincidunt mauris, vel ultrices turpis posuere a. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae;", 
            'code': '4d.b.mh', 
            'acronym': None, 
            'islocked': False, 
            'creationtime': '2025-07-09T15:51:10.10467', 
            'creatoruserid': 20656,
            'deleteruserid': None, 
            'deletiontime': None, 
            'isdeleted': False, 
            'lastmodificationtime': '2025-10-26T02:06:01.4350132', 
            'lastmodifieruserid': 20466, 
            'tenantid': 1, 
            'qtydigitalobjects': 0, 
            'name': 'Aarnoud', 
            'surname': 'van de Burgt', 
            'emailaddress': 'aarnoud.van.de.burgt@nioz.nl', 
            'jobtitle': 'Head of National Marine Facilities',
            'orcid': None, 
            'showpageonwebsite': '1',
            'showportraitonwebsite': None, 
            'personid': '11623', 
            'team': None, 
            'researchinterests': None, 
            'secodarypositions': None, 
            'promotor': None, 
            'university': None, 
            'phonenumber': '+31222369332', 
            'showportraitonwebsite': None, 
            'personid': '11623', 
            'team': None, 
            'researchinterests': None, 
            'secodarypositions': None, 
            'promotor': None, 
            'university': None, 
            'phonenumber': '+31222369332', 
            'teamname': None, 
            'contractenddate': '2025-11-30T00:00:00', 
            'showuntildate': '2025-11-30T00:00:00', 
            'educationaltitle': None, 
            'location': 'T', 
            'educationaldegree': None, 
            'researchfield': None, 
            'taborder': 5, 
            'showportraitonintranet': None, 
            'isdasaccountexists': True, 
            'dutchdescription': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in orci consequat, hendrerit lectus in, lobortis magna. Duis pulvinar varius pellentesque. Suspendisse scelerisque dolor id ex aliquet, id luctus est euismod. Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec accumsan tortor leo, ultricies sodales risus volutpat in. Praesent quis augue lacinia, luctus nulla nec, gravida sapien. Nulla facilisi. Nunc molestie elementum velit ac mattis. Etiam sed magna vehicula lectus efficitur euismod quis ut purus. Integer ac dapibus tortor. Nullam sollicitudin semper tristique. Donec maximus lectus ac sapien mollis, et commodo ante rutrum. Vivamus erat dui, ullamcorper at tellus quis, tempor accumsan felis. Maecenas condimentum nunc eget ipsum consequat convallis. Proin pulvinar cursus mauris pretium finibus. Quisque orci lacus, ullamcorper nec ex et, vehicula sollicitudin nisl. Pellentesque tincidunt massa volutpat est rutrum, ut tincidunt diam interdum. Nunc sollicitudin posuere rutrum. Sed quis magna iaculis, consequat nibh ac, dictum dolor. Nullam lorem diam, sollicitudin ac pellentesque ut, tincidunt eget magna. Vestibulum finibus tincidunt mauris, vel ultrices turpis posuere a. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae;', 
            'dutchjobtitle': 'Hoofd National Marine Facilities', 
            'showjobtitle': None, 
            'isdefaultprofileonwebsite': None, 
            'None': ''
        }

        updated_entry_id = self.entry_manager.update(id="c4c6dff6-5ccb-11f0-a78d-a84a63c8db73", entry=updated_entry_data)
        self.assertIsNotNone(updated_entry_id)
        self.assertRegex(updated_entry_id[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')

    def test_partial_update_entry(self):
        """Test updating an entry partially"""
        entry_id = "c4c6dff6-5ccb-11f0-a78d-a84a63c8db73"
       
        original_entry_data = self.entry_manager.get(id=entry_id)

        updated_entry_data = {
            "description": "Sed in mauris nec nibh accumsan aliquam. Duis ut vulputate sapien, sed mollis urna. Integer euismod viverra arcu, sed rhoncus mi. Etiam fermentum, felis at iaculis fermentum, lacus ex scelerisque nulla, eu rhoncus nisi tellus commodo turpis. Phasellus quis tincidunt metus, non suscipit est. Ut nulla nisl, aliquet a turpis rhoncus, mollis pellentesque augue. Mauris bibendum accumsan sapien in semper. Aliquam nulla lectus, eleifend ut metus sit amet, viverra bibendum est. Sed nec vestibulum sem. Mauris hendrerit maximus nisi quis posuere. In eget varius augue. Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
            "jobtitle": 'Head of National Marine Facilities',
            "showjobtitle": 'yes',
            "showpageonwebsite": 'yes',
            "showportraitonwebsite": 'no',
            'educationaltitle': 'ing.',
            'orcid': '0000-0000-0000-0000',
        }

        updated_entry_response = self.entry_manager.update(id=entry_id, entry=updated_entry_data)

        after_update_entry_data = self.entry_manager.get(id=entry_id)

        key_to_ignore = ['Updated At']

        # Expects all data as the original entry data except for the updated data
        for key, value in original_entry_data.items():
            if key not in updated_entry_data and key not in key_to_ignore:
                self.assertEqual(after_update_entry_data[key], value)
            else:
                self.assertNotEqual(after_update_entry_data[key], value)

        self.assertIsNotNone(updated_entry_response[0]['id'])
        self.assertRegex(updated_entry_response[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')

    def test_update_entry_by_code(self):
        """Test updating an entry"""
        
        updated_entry_data = {
            "Availability": "pc.b.c",
            "Number" : 2,
            "diameterincm": 15,
            "27": "#2319-03_03HM"
        }

        updated_entry_id = self.entry_manager.update(code="zb.b.0", entry=updated_entry_data)
        self.assertIsNotNone(updated_entry_id)
        self.assertRegex(updated_entry_id[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')        


    def test_create_entry_with_json_file(self):
        """Test creating an entry from a JSON file"""
        file_path = os.path.join(os.path.dirname(__file__), 'test_data', 'entry_data.json')
        self.entry_manager.create_from_file(attribute="Cores", file_path=file_path)
        # If no exception is raised, the test is considered passed for this example

    def test_create_entry_with_csv_file(self):
        """Test creating an entry from a CSV file"""
        file_path = os.path.join(os.path.dirname(__file__), 'test_data', 'sample_entry.csv')
        self.entry_manager.create_from_file(attribute="Cores", file_path=file_path)
        # If no exception is raised, the test is considered passed for this example

    # def test_create_entry_with_excel_file(self):
    #     """Test creating an entry from an Excel file"""
    #     file_path = os.path.join(os.path.dirname(__file__), 'test_data', 'entry_data.xlsx')
    #     self.entry_manager.create_from_file(attribute="Cores", file_path=file_path)
    #     # If no exception is raised, the test is considered passed for this example

    def test_update_entry_with_column_names(self):
            """Test updating an entry with column names"""
            updated_entry_data = {
                'displayname': 'Eveline Garritsen-van Arnhem', 
                'personid': 100015, 
                'name': 'Eveline', 
                'surname': 'Garritsen-van Arnhem', 
                'phonenumber': '+31222369559', 
                'emailaddress': 'eveline.garritsen@nioz.nl', 
                'jobtitle': 'Research Assistant', 
                'DutchJobTitle': 'Onderzoekmedewerker', 
                'contractenddate': '2034-12-01', 
                'showuntildate': '2034-12-01', 
                'educationaltitle': 'ing.', 
                'educationaldegree': None, 
                'location': 'T', 
                'taborder': 3, 
                'IsDefaultProfileOnWebsite': False, 
                'isPrivate': True, 
                '128': [{'id': 'd080b26e-2db0-4d68-acae-44c3a7399c51', 'attributeid': 128}]
                }

            updated_entry_id = self.entry_manager.update(id="994a9fa5-5ccb-11f0-aafa-a84a63c8db73", entry=updated_entry_data)
            self.assertIsNotNone(updated_entry_id[0]['id'])
            self.assertRegex(updated_entry_id[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')

    def test_create_entry_with_column_names(self):
        """Test creating an entry with column names"""
        created_entry_data = {
            'displayname': 'Maximilian Garritsen-van Arnhem', 
            'personid': 100099, 
            'name': 'Maximilian', 
            'surname': 'Garritsen-van Arnhem', 
        }
        created_entry_id = self.entry_manager.create(attribute="Person", entry=created_entry_data)
        self.assertIsNotNone(created_entry_id[0]['id'])
        self.assertRegex(created_entry_id[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')    

    def test_create_entry_error_message(self):
        """Test that creating an incomplete entry raises a ValueError with a clean, human-readable message."""

        cruise_data = {
            "Cruise Code": "TEST-Cruise-001",
            # intentionally missing required fields so the server returns a validation error
        }

        with self.assertRaises(ValueError) as ctx:
            self.entry_manager.create(attribute="Cruise", entry=cruise_data)

        message = str(ctx.exception)

        # Must be a non-empty string
        self.assertTrue(len(message) > 0, "Error message should not be empty")

        # Must not contain raw CRLF — the server appends \r\n which should be stripped
        self.assertNotIn("\r\n", message, "Error message should have trailing whitespace stripped")

        # Must not look like a raw Python dict (the old broken behaviour)
        self.assertNotIn("{'code':", message, "Error message should not be a raw dict repr")
        self.assertNotIn("\"code\":", message, "Error message should not be a raw JSON string")