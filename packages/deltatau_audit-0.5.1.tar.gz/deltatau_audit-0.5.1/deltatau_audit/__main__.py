"""Allow running as: python -m deltatau_audit"""
from .cli import main

main()
