
# Author: Shun Ogawa (a.k.a. "ToPo")
# Copyright (c) 2025 Shun Ogawa (a.k.a. "ToPo")
# License: Apache License Version 2.0

from typing import Optional, List, Dict
from .llm_interface import LLMInterface
from .image_controller_base64 import process_images_to_base64
#===================================================================================
# Coreの部分
#===================================================================================
class OllamaLLM:

    #---------------------------------------------------------------
    # パラメータの初期化
    #---------------------------------------------------------------
    def __init__(
            self, 
            model_path,
            temp: float = 0.0,
            top_k: int = -1,
            top_p: float = 0.0
    ):

        # LLMの初期化
        self.llm = LLMInterface(
            model_name=model_path,
            options = {
                "temperature": temp,
                "top_k": top_k,
                "top_p": top_p,
            }
        )

    #-----------------------------------------------------------------------------
    # 画像をBase64に変換し、ユーザーメッセージ構造を構築
    #-----------------------------------------------------------------------------
    def build_user_message(self, text: str, images: Optional[List] = None) -> Dict:

        # テキストの入力
        message = {"role": "user", "content": text}
        
        # 画像がある場合
        if images:
            base64_images = process_images_to_base64(user_images=images)
            if base64_images:
                message["images"] = base64_images
                
        return message

    #-----------------------------------------------------------------------------
    # 回答を生成 (メインメソッド)
    #-----------------------------------------------------------------------------
    def respond(
        self, 
        user_text: str, 
        user_images: List = None,
        system_prompt: str = None, 
        stream: bool = False
    ):
        
        # システムプロンプト作成
        system_message = {"role": "system", "content": system_prompt}
        
        # ユーザー入力(パスからBase64へ)
        user_message = self.build_user_message(text=user_text, images=user_images)
        
        # メッセージリストの結合
        # 結合順序: System -> User
        messages = [system_message] + [user_message]

        # 回答生成フェーズ (ストリーミング応答対応)
        if stream:
            generator = self.llm.chat(messages=messages, stream=True)
            if generator:
                for chunk in generator:
                    if "error" in chunk:
                        yield f"\n[エラー: {chunk['error']}]"
                    elif "message" in chunk and "content" in chunk["message"]:
                        yield chunk["message"]["content"]
            else:
                yield "[エラー: モデルがストリーミング応答を返しませんでした]"
                
        # 一括応答
        else:
            try:
                response = self.llm.chat(messages=messages)
                full_reply = response.get("message", {}).get("content", "[応答が空でした]")
                yield full_reply
            except Exception as e:
                yield f"[エラー: {str(e)}]"
        
        # モデルを解放
        self.free_model()

    #---------------------------------------------------------------
    # ロードしたモデルを止める
    #---------------------------------------------------------------
    def free_model(self):
        if hasattr(self.llm, "free_model"):
            self.llm.free_model()