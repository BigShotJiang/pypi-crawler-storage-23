import os
import gc
from typing import Optional, List, Dict, Generator
from llama_cpp import Llama
from llama_cpp.llama_chat_format import Llava15ChatHandler
from huggingface_hub import hf_hub_download

class LlamaCppUnifiedLLM:
    def __init__(
            self, 
            model_path_or_repo: str,
            filename: Optional[str] = None,       # リポジトリ指定時のGGUFファイル名
            mmproj_path_or_repo: Optional[str] = None,
            mmproj_filename: str = "mmproj-model-f16.gguf", # VLM用の標準的な名前
            temp: float = 0.6,
            n_ctx: int = 4096,
            n_gpu_layers: int = -1
    ):
        # 1. Visionハンドラの設定（自動ダウンロード対応）
        self.chat_handler = None
        if mmproj_path_or_repo:
            mmproj_path = self._prepare_file(mmproj_path_or_repo, mmproj_filename)
            self.chat_handler = Llava15ChatHandler(clip_model_path=mmproj_path)
            print(f"Vision mode enabled: {mmproj_path}")

        # 2. 本体モデルのロード
        # ローカルパスが存在すればそのまま、なければHFからダウンロード
        if os.path.exists(model_path_or_repo):
            self.llm = Llama(
                model_path=model_path_or_repo,
                chat_handler=self.chat_handler,
                n_gpu_layers=n_gpu_layers,
                n_ctx=n_ctx,
                logits_all=True if self.chat_handler else False,
                verbose=False
            )
        else:
            print(f"Downloading model from {model_path_or_repo}...")
            # filename未指定の場合のワイルドカード指定（例: Q4_K_M系を優先）
            target_file = filename or "*Q4_K_M.gguf"
            self.llm = Llama.from_pretrained(
                repo_id=model_path_or_repo,
                filename=target_file,
                chat_handler=self.chat_handler,
                n_gpu_layers=n_gpu_layers,
                n_ctx=n_ctx,
                logits_all=True if self.chat_handler else False,
                verbose=False
            )
        
        self.temp = temp

    def _prepare_file(self, path_or_repo: str, filename: str) -> str:
        """ローカルになければHFから1ファイルだけ落としてパスを返すヘルパー"""
        if os.path.exists(path_or_repo):
            return path_or_repo
        return hf_hub_download(repo_id=path_or_repo, filename=filename)

    def respond(
        self, 
        user_text: str, 
        user_images: Optional[List[str]] = None, 
        system_prompt: str = "あなたは優秀なアシスタントです。", 
        stream: bool = False
    ) -> Generator[str, None, None]:
        
        # メッセージ構築（前述の自動スイッチロジック）
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        
        if not user_images or not self.chat_handler:
            messages.append({"role": "user", "content": user_text})
        else:
            content = [{"type": "text", "text": user_text}]
            for b64 in user_images:
                img_url = b64 if b64.startswith("data:") else f"data:image/jpeg;base64,{b64}"
                content.append({"type": "image_url", "image_url": {"url": img_url}})
            messages.append({"role": "user", "content": content})

        try:
            response_iter = self.llm.create_chat_completion(
                messages=messages, stream=stream, temperature=self.temp
            )
            for chunk in (response_iter if stream else [response_iter]):
                item = chunk if not stream else chunk['choices'][0].get('delta', {})
                content = item.get('content') or item.get('message', {}).get('content')
                if content: yield content
        except Exception as e:
            yield f"[Error] {str(e)}"

    def free_model(self):
        if hasattr(self, "llm"): del self.llm
        if hasattr(self, "chat_handler"): del self.chat_handler
        gc.collect()