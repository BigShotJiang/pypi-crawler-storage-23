
from typing import List, Optional, Dict
from mlx_vlm.utils import load_image
from .mlx_interface import MlxLLMInterface
#--------------------------------------------------------------------------------------------
# LLM推論を制御するメインクラス
#--------------------------------------------------------------------------------------------
class MlxLLM:

    def __init__(
            self,
            model_path: str, 
            use_vision: bool = False, 
            temp: float = 0.0,
            top_k: int = -1, 
            top_p: float = 1.0, 
            min_p: float = 0.0, 
            max_tokens: int = 8192,
            enable_thinking: bool = False
    ):
        # LLMの初期化
        self.llm = MlxLLMInterface(
            model_path=model_path,
            use_vision=use_vision,
            temp=temp,
            top_k=top_k,
            top_p=top_p,
            min_p=min_p,
            max_tokens=max_tokens,
            enable_thinking=enable_thinking
        )
    
    #-----------------------------------------------------------------------------
    # MLX/VLM形式のメッセージ構造を構築する共通メソッド
    #-----------------------------------------------------------------------------
    def _build_message(self, role: str, text: str, images: Optional[List] = None) -> Dict:
        # 画像があり、かつVLMインターフェースが有効な場合
        if images and self.llm.use_vision:
            content = [{"type": "text", "text": text}]
            for _ in images:
                content.append({"type": "image"})
            return {"role": role, "content": content}
        
        # 通常のテキストのみの場合
        return {"role": role, "content": text}

    #-----------------------------------------------------------------------------
    # ユーザー入力に対してツール実行と回答生成を行うメインメソッド
    #-----------------------------------------------------------------------------
    def respond(
            self,
            user_text: str, 
            user_images: List = None,
            system_prompt: str = None,
            stream: bool = False):
        
        # 初期化
        messages = []
        
        # システムプロンプト
        if system_prompt:
            messages.append(self._build_message(role="system", text=system_prompt))
        
        # ユーザー画像の処理
        user_images = user_images or []
        pil_user_images = [load_image(str(p)) for p in user_images]
        
        # すべてを結合
        messages.append(self._build_message(role="user", text=user_text, images=pil_user_images))

        # 回答生成フェーズ
        full_reply = ""
        generator = self.llm.generate(
            messages=messages, 
            images=pil_user_images if pil_user_images else None,
            stream=stream
        )

        # ストリーミング応答
        if stream:
            for response in generator:
                chunk = response.text
                full_reply += chunk
                yield chunk
        
        # 一括応答
        else:
            for response in generator:
                full_reply += response.text
            yield full_reply