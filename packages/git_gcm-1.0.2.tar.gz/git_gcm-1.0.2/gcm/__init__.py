"""GCM - Git Commit Message Generator"""

__version__ = "0.1.0"
