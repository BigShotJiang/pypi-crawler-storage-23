# Backward-compatibility shim — real module is salmalm.core.prompt
import importlib as _importlib
import sys as _sys
_real = _importlib.import_module("salmalm.core.prompt")
_sys.modules[__name__] = _real
