from __future__ import annotations

import json
from pathlib import Path
from xml.etree import ElementTree as ET

from jinja2 import Environment, FileSystemLoader, select_autoescape

from .utils import ensure_dir


def _env() -> Environment:
    tpl_dir = Path(__file__).parent / "templates"
    return Environment(
        loader=FileSystemLoader(str(tpl_dir)),
        autoescape=select_autoescape(["html"]),
    )


def write_junit(out_dir: Path, report: dict) -> str:
    results = report.get("results") or []
    failures = sum(1 for r in results if r.get("status") in {"FAIL", "NO_BASELINE"})
    warnings = sum(1 for r in results if r.get("status") in {"WARN", "QUARANTINED"})

    suite = ET.Element(
        "testsuite",
        name=f"{report.get('project', 'visualcheck')}.{report.get('suite', 'suite')}",
        tests=str(len(results)),
        failures=str(failures),
        errors="0",
    )
    if warnings:
        suite.set("skipped", str(warnings))

    for r in results:
        case = ET.SubElement(
            suite,
            "testcase",
            classname=f"{report.get('project', 'visualcheck')}.{r.get('view_id', 'view')}",
            name=str(r.get("snapshot_id", "snapshot")),
        )
        if r.get("status") in {"FAIL", "NO_BASELINE"}:
            msg = f"status={r.get('status')} pixel_diff_pct={r.get('pixel_diff_pct')} ssim={r.get('ssim')}"
            fail = ET.SubElement(case, "failure", message=msg)
            fail.text = f"baseline={r.get('baseline')} current={r.get('current')} diff={r.get('diff')}"
        elif r.get("status") in {"WARN", "QUARANTINED"}:
            ET.SubElement(case, "skipped", message="warning-threshold-breach")

    xml_path = out_dir / "report.junit.xml"
    ET.ElementTree(suite).write(xml_path, encoding="utf-8", xml_declaration=True)
    return str(xml_path)


def _load_json(path: Path, default):
    try:
        if path.exists():
            return json.loads(path.read_text())
    except Exception:
        pass
    return default


def _project_root_from_report_dir(report_dir: Path) -> Path | None:
    # .../test_report/<project>/visual_runs/<run_id>/report
    try:
        if report_dir.name != "report":
            return None
        run_dir = report_dir.parent
        if run_dir.parent.name != "visual_runs":
            return None
        return run_dir.parent.parent
    except Exception:
        return None


def write_dashboard(project_dir: Path) -> str:
    runs_root = project_dir / "visual_runs"
    history_dir = project_dir / "history"
    trends = _load_json(history_dir / "trends.json", {"runs": []})
    trend_runs = list(reversed((trends.get("runs") or [])[-30:]))

    run_rows = []
    if runs_root.exists():
        for run_dir in sorted([p for p in runs_root.iterdir() if p.is_dir()], key=lambda p: p.name, reverse=True)[:100]:
            rj = run_dir / "report" / "report.json"
            data = _load_json(rj, {})
            run_rows.append(
                {
                    "run_id": run_dir.name,
                    "status": data.get("status", "UNKNOWN"),
                    "generated_at": data.get("generated_at", "-"),
                    "env": data.get("env", "-"),
                    "suite": data.get("suite", "-"),
                    "report_rel": f"visual_runs/{run_dir.name}/report/report.html",
                }
            )

    html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>visualcheck dashboard - {project_dir.name}</title>
  <style>
    body {{ font-family: "IBM Plex Sans", "Segoe UI", Arial, sans-serif; margin: 0; padding: 18px; background: #f6f9ff; color: #12213b; }}
    h1, h2 {{ margin: 0 0 10px 0; }}
    .card {{ background: #fff; border: 1px solid #d8e2f5; border-radius: 12px; padding: 12px; margin-bottom: 12px; }}
    table {{ width: 100%; border-collapse: collapse; background: #fff; border: 1px solid #d8e2f5; border-radius: 12px; overflow: hidden; }}
    th, td {{ border-bottom: 1px solid #e7edf8; padding: 8px; font-size: 13px; text-align: left; }}
    th {{ background: #f4f8ff; }}
    .PASS {{ color: #146d3c; font-weight: 700; }}
    .WARN {{ color: #895b00; font-weight: 700; }}
    .FAIL {{ color: #b3261e; font-weight: 700; }}
    .QUARANTINED {{ color: #5a3e8b; font-weight: 700; }}
    .NO_BASELINE {{ color: #555; font-weight: 700; }}
    code {{ background: #f2f6ff; padding: 1px 4px; border-radius: 4px; }}
  </style>
</head>
<body>
  <div class="card">
    <h1>visualcheck dashboard</h1>
    <div><b>Project:</b> <code>{project_dir.name}</code></div>
    <div style="margin-top:6px;">Open latest report quickly and inspect recent run history from one place.</div>
  </div>

  <div class="card">
    <h2>Latest Runs</h2>
    <table>
      <thead><tr><th>Run ID</th><th>Status</th><th>Generated</th><th>Env</th><th>Suite</th><th>Report</th></tr></thead>
      <tbody>
        {''.join(
            f"<tr><td><code>{r['run_id']}</code></td><td class='{r['status']}'>{r['status']}</td><td>{r['generated_at']}</td><td>{r['env']}</td><td>{r['suite']}</td><td><a href='{r['report_rel']}'>open report</a></td></tr>"
            for r in run_rows
        ) or "<tr><td colspan='6'>No runs found yet.</td></tr>"}
      </tbody>
    </table>
  </div>

  <div class="card">
    <h2>History Trends</h2>
    <table>
      <thead><tr><th>Run ID</th><th>Status</th><th>Generated</th><th>Commit</th><th>Branch</th><th>Counts</th></tr></thead>
      <tbody>
        {''.join(
            f"<tr><td><code>{r.get('run_id','-')}</code></td><td class='{r.get('status','')}'>{r.get('status','-')}</td><td>{r.get('generated_at','-')}</td><td><code>{r.get('commit','-')}</code></td><td>{r.get('branch','-')}</td><td><code>{json.dumps(r.get('counts',{}), separators=(',',':'))}</code></td></tr>"
            for r in trend_runs
        ) or "<tr><td colspan='6'>No trend data yet.</td></tr>"}
      </tbody>
    </table>
  </div>
</body>
</html>
"""
    dashboard_path = project_dir / "dashboard.html"
    dashboard_path.write_text(html, encoding="utf-8")
    return str(dashboard_path)


def write_report(out_dir: Path, report: dict) -> dict:
    ensure_dir(out_dir)
    (out_dir / "report.json").write_text(json.dumps(report, indent=2))

    env = _env()
    tpl = env.get_template("report.html")

    html = tpl.render(**report)
    html_path = out_dir / "report.html"
    html_path.write_text(html, encoding="utf-8")
    junit_path = write_junit(out_dir, report)
    dashboard_path = None
    project_dir = _project_root_from_report_dir(out_dir)
    if project_dir is not None:
        dashboard_path = write_dashboard(project_dir)
    return {
        "report_json": str(out_dir / "report.json"),
        "report_html": str(html_path),
        "report_junit_xml": junit_path,
        "dashboard_html": dashboard_path,
    }
