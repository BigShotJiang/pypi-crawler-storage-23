from __future__ import annotations

import concurrent.futures as cf
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from PIL import Image, ImageDraw
from playwright.sync_api import Page, sync_playwright

from .utils import ensure_dir, slug
from .views import resolve_view_configs


def _collect_ignore_regions(cfg: dict, snapshot_id: str, local: Optional[dict]) -> dict:
    ignore = {"selectors": [], "rects": []}

    global_block = (cfg.get("ignore_regions") or {}).get("global") or {}
    by_snapshot = (cfg.get("ignore_regions") or {}).get("by_snapshot") or {}
    snap_block = by_snapshot.get(snapshot_id) or {}

    for block in [global_block, snap_block, local or {}]:
        ignore["selectors"].extend(block.get("selectors") or [])
        ignore["rects"].extend(block.get("rects") or [])

    # de-dupe selectors
    ignore["selectors"] = list(dict.fromkeys(ignore["selectors"]))
    return ignore


def _mask_png(png_path: Path, rects: List[Tuple[float, float, float, float]]) -> None:
    if not rects:
        return
    img = Image.open(png_path).convert("RGBA")
    draw = ImageDraw.Draw(img)
    for x, y, w, h in rects:
        draw.rectangle([x, y, x + w, y + h], fill=(255, 0, 255, 255))
    img.save(png_path)


def _rects_from_selectors(page: Page, selectors: List[str]) -> List[Tuple[float, float, float, float]]:
    rects: List[Tuple[float, float, float, float]] = []
    for sel in selectors:
        try:
            # query_selector_all is usually faster/less blocking than locator.count on heavy pages
            els = page.query_selector_all(sel)
            for el in els[:10]:
                bb = el.bounding_box()
                if bb:
                    rects.append((bb["x"], bb["y"], bb["width"], bb["height"]))
        except Exception:
            # ignore selector failures (dynamic pages)
            continue
    return rects


def _mask_from_ignore(page: Page, png_path: Path, ignore: dict) -> None:
    rects: List[Tuple[float, float, float, float]] = []
    rects.extend(_rects_from_selectors(page, ignore.get("selectors") or []))
    for r in ignore.get("rects") or []:
        rects.append((r["x"], r["y"], r["width"], r["height"]))
    _mask_png(png_path, rects)


def _abs_url(base: str, url: str) -> str:
    if url.startswith("http://") or url.startswith("https://"):
        return url
    return base.rstrip("/") + "/" + url.lstrip("/")


def _retry(action_name: str, retries: int, retry_delay_ms: int, action: Callable[[], Any]) -> Any:
    for attempt in range(retries + 1):
        try:
            return action()
        except Exception:
            if attempt >= retries:
                raise
            wait_s = max(0, retry_delay_ms) / 1000.0
            print(f"[capture] retrying action={action_name} attempt={attempt + 1}/{retries}")
            time.sleep(wait_s)
    return None


def _wait_for_stability(page: Page, checks: int, interval_ms: int, timeout_ms: int) -> bool:
    if checks <= 0:
        return True
    start = time.time()
    last = None
    stable = 0
    while True:
        try:
            sig = page.evaluate(
                "() => [document.documentElement.scrollHeight, document.body ? document.body.innerText.length : 0]"
            )
        except Exception:
            return False
        if sig == last:
            stable += 1
        else:
            stable = 0
        last = sig
        if stable >= checks:
            return True
        elapsed_ms = (time.time() - start) * 1000.0
        if elapsed_ms >= max(0, timeout_ms):
            return False
        page.wait_for_timeout(max(1, interval_ms))


def _page_signature(page: Page) -> dict:
    try:
        sig = page.evaluate(
            """() => ({
              scrollHeight: document.documentElement ? document.documentElement.scrollHeight : 0,
              textLength: document.body ? document.body.innerText.length : 0,
              imageCount: document.images ? document.images.length : 0,
              viewportW: window.innerWidth,
              viewportH: window.innerHeight
            })"""
        )
        if isinstance(sig, dict):
            return sig
    except Exception:
        pass
    return {}


def _page_load_metrics(page: Page) -> dict:
    try:
        out = page.evaluate(
            """() => {
              const imgs = Array.from(document.images || []);
              const pendingImgs = imgs.filter((i) => !i.complete).length;
              const pendingLazy = imgs.filter((i) => i.loading === "lazy" && !i.complete).length;
              return {
                readyState: document.readyState,
                scrollHeight: document.documentElement ? document.documentElement.scrollHeight : 0,
                textLength: document.body ? document.body.innerText.length : 0,
                imageCount: imgs.length,
                pendingImages: pendingImgs,
                pendingLazyImages: pendingLazy,
                viewportW: window.innerWidth,
                viewportH: window.innerHeight
              };
            }"""
        )
        if isinstance(out, dict):
            return out
    except Exception:
        pass
    return {
        "readyState": "unknown",
        "scrollHeight": 0,
        "textLength": 0,
        "imageCount": 0,
        "pendingImages": 0,
        "pendingLazyImages": 0,
    }


def _wait_for_full_load(
    page: Page,
    timeout_ms: int,
    interval_ms: int,
    stable_checks: int,
) -> tuple[bool, dict]:
    start = time.time()
    last_sig = None
    stable = 0
    latest = _page_load_metrics(page)
    while True:
        remaining_ms = max(0, int(timeout_ms - (time.time() - start) * 1000))
        if remaining_ms <= 0:
            return False, latest

        try:
            page.wait_for_load_state("load", timeout=min(1500, remaining_ms))
        except Exception:
            pass
        try:
            page.wait_for_load_state("networkidle", timeout=min(1200, remaining_ms))
        except Exception:
            pass

        latest = _page_load_metrics(page)
        sig = (
            latest.get("readyState"),
            latest.get("scrollHeight"),
            latest.get("textLength"),
            latest.get("pendingImages"),
            latest.get("pendingLazyImages"),
        )
        ready = (
            latest.get("readyState") == "complete"
            and int(latest.get("pendingImages", 0)) == 0
            and int(latest.get("pendingLazyImages", 0)) == 0
        )
        if ready and sig == last_sig:
            stable += 1
        else:
            stable = 0
        last_sig = sig
        if ready and stable >= max(1, stable_checks):
            return True, latest
        page.wait_for_timeout(max(1, interval_ms))


def _settle_lazy_content(
    page: Page,
    rounds: int,
    scroll_delay_ms: int,
    timeout_ms: int,
    interval_ms: int,
    stable_checks: int,
) -> tuple[bool, dict]:
    start_y = 0
    try:
        start_y = int(page.evaluate("() => Math.max(0, window.scrollY || 0)"))
    except Exception:
        pass
    latest = _page_load_metrics(page)
    try:
        for _ in range(max(0, rounds)):
            page.evaluate(
                "() => window.scrollTo(0, (document.documentElement && document.documentElement.scrollHeight) || (document.body && document.body.scrollHeight) || 0)"
            )
            page.wait_for_timeout(max(0, scroll_delay_ms))
            ok, latest = _wait_for_full_load(
                page,
                timeout_ms=min(max(1000, timeout_ms), 7000),
                interval_ms=interval_ms,
                stable_checks=stable_checks,
            )
            if ok and int(latest.get("pendingLazyImages", 0)) == 0:
                break
    finally:
        try:
            page.evaluate("(y) => window.scrollTo(0, y)", start_y)
        except Exception:
            pass
    return True, latest


def _capture_view(
    cfg: dict,
    base_url: str,
    out_dir: Path,
    view_id: str,
    context_kwargs: dict,
    headed: bool,
    slow_mo_ms: int,
    storage_state: Optional[Path],
    selected_snapshot_ids: Optional[Set[str]] = None,
) -> List[dict]:
    capture_cfg = cfg.get("capture") or {}
    extra_wait_ms = int(capture_cfg.get("extra_wait_ms", 1000))
    scroll_times = int(capture_cfg.get("scrolls", 5))
    scroll_delay = int(capture_cfg.get("scroll_delay_ms", 700))
    retries = int(capture_cfg.get("retries", 0))
    retry_delay_ms = int(capture_cfg.get("retry_delay_ms", 700))
    screenshot_timeout_ms = int(capture_cfg.get("screenshot_timeout_ms", 90000))
    stability_checks = int(capture_cfg.get("stability_checks", 0))
    stability_interval_ms = int(capture_cfg.get("stability_interval_ms", 250))
    stability_timeout_ms = int(capture_cfg.get("stability_timeout_ms", 3000))
    wait_for_full_load = bool(capture_cfg.get("wait_for_full_load", True))
    full_load_timeout_ms = int(capture_cfg.get("full_load_timeout_ms", 120000))
    full_load_interval_ms = int(capture_cfg.get("full_load_check_interval_ms", 500))
    full_load_stable_checks = int(capture_cfg.get("full_load_stable_checks", 2))
    lazy_load_scroll_rounds = int(capture_cfg.get("lazy_load_scroll_rounds", max(3, scroll_times)))
    browser_channel = capture_cfg.get("browser_channel", "chrome")

    manifest: List[dict] = []

    with sync_playwright() as p:
        try:
            browser = p.chromium.launch(
                headless=not headed,
                slow_mo=slow_mo_ms or None,
                channel=browser_channel or None,
            )
        except Exception:
            # Fallback to bundled Chromium when requested channel is unavailable.
            browser = p.chromium.launch(headless=not headed, slow_mo=slow_mo_ms or None)
        try:
            ctx_kwargs = dict(context_kwargs)
            if storage_state:
                ctx_kwargs["storage_state"] = str(storage_state)

            context = browser.new_context(**ctx_kwargs)
            try:
                page = context.new_page()
                page.set_default_timeout(30000)
                page.set_default_navigation_timeout(45000)

                view_out = ensure_dir(out_dir / slug(view_id))

                for pg in cfg.get("pages", []) or []:
                    snap_id = pg["id"]
                    if selected_snapshot_ids and snap_id not in selected_snapshot_ids:
                        continue
                    url = _abs_url(base_url, pg["url"])
                    print(f"[capture] view={view_id} snapshot={snap_id} url={url}")
                    _retry(
                        "goto",
                        retries,
                        retry_delay_ms,
                        lambda: page.goto(url, wait_until="domcontentloaded"),
                    )
                    if pg.get("wait_for"):
                        _retry(
                            "wait_for_selector",
                            retries,
                            retry_delay_ms,
                            lambda: page.wait_for_selector(pg["wait_for"], timeout=30000),
                        )
                    if wait_for_full_load:
                        ok_load, _ = _wait_for_full_load(
                            page,
                            timeout_ms=full_load_timeout_ms,
                            interval_ms=full_load_interval_ms,
                            stable_checks=full_load_stable_checks,
                        )
                        if not ok_load:
                            print(f"[capture] full-load timeout view={view_id} snapshot={snap_id}; continuing with best effort")

                    page.wait_for_timeout(extra_wait_ms)
                    if stability_checks > 0:
                        _wait_for_stability(page, stability_checks, stability_interval_ms, stability_timeout_ms)
                    try:
                        for _ in range(max(1, scroll_times)):
                            page.keyboard.press("PageDown")
                            page.wait_for_timeout(scroll_delay)
                    except Exception:
                        try:
                            for _ in range(max(1, scroll_times)):
                                page.mouse.wheel(0, 800)
                                page.wait_for_timeout(scroll_delay)
                        except Exception:
                            pass
                    if wait_for_full_load:
                        _settle_lazy_content(
                            page,
                            rounds=lazy_load_scroll_rounds,
                            scroll_delay_ms=scroll_delay,
                            timeout_ms=full_load_timeout_ms,
                            interval_ms=full_load_interval_ms,
                            stable_checks=full_load_stable_checks,
                        )
                        ok_load, _ = _wait_for_full_load(
                            page,
                            timeout_ms=full_load_timeout_ms,
                            interval_ms=full_load_interval_ms,
                            stable_checks=full_load_stable_checks,
                        )
                        if not ok_load:
                            print(f"[capture] post-lazy full-load timeout view={view_id} snapshot={snap_id}; continuing with best effort")

                    full_page = bool(pg.get("full_page", True))
                    png_path = view_out / f"{slug(snap_id)}.png"
                    _retry(
                        "screenshot",
                        retries,
                        retry_delay_ms,
                        lambda: page.screenshot(path=str(png_path), full_page=full_page, timeout=screenshot_timeout_ms),
                    )

                    ignore = _collect_ignore_regions(cfg, snap_id, pg.get("ignore_regions"))
                    _mask_from_ignore(page, png_path, ignore)

                    manifest.append(
                        {
                            "type": "page",
                            "snapshot_id": snap_id,
                            "view_id": view_id,
                            "url": url,
                            "png": str(png_path),
                            "signature": _page_signature(page),
                        }
                    )

                for flow in cfg.get("flows", []) or []:
                    flow_id = flow["id"]
                    start = _abs_url(base_url, flow["start_url"])
                    _retry(
                        "goto",
                        retries,
                        retry_delay_ms,
                        lambda: page.goto(start, wait_until="domcontentloaded"),
                    )
                    page.wait_for_timeout(300)
                    if stability_checks > 0:
                        _wait_for_stability(page, stability_checks, stability_interval_ms, stability_timeout_ms)
                    if wait_for_full_load:
                        _wait_for_full_load(
                            page,
                            timeout_ms=full_load_timeout_ms,
                            interval_ms=full_load_interval_ms,
                            stable_checks=full_load_stable_checks,
                        )

                    for step in flow.get("steps", []) or []:
                        act = step["action"]
                        if act == "goto":
                            _retry(
                                "goto",
                                retries,
                                retry_delay_ms,
                                lambda: page.goto(_abs_url(base_url, step["url"]), wait_until="domcontentloaded"),
                            )
                        elif act == "click":
                            _retry(
                                "click",
                                retries,
                                retry_delay_ms,
                                lambda: page.locator(step["selector"]).click(timeout=30000),
                            )
                        elif act == "fill":
                            page.locator(step["selector"]).fill(step.get("text", ""), timeout=30000)
                        elif act == "press":
                            page.keyboard.press(step["key"])
                        elif act == "wait":
                            page.wait_for_timeout(int(step.get("ms", 0)))
                        elif act == "wait_for_selector":
                            _retry(
                                "wait_for_selector",
                                retries,
                                retry_delay_ms,
                                lambda: page.wait_for_selector(step["selector"], timeout=30000),
                            )
                        else:
                            raise ValueError(f"Unknown flow step action: {act}")

                    for snap in flow.get("snapshots", []) or []:
                        snap_id = f"{flow_id}__{snap['id']}"
                        if selected_snapshot_ids and snap_id not in selected_snapshot_ids:
                            continue
                        if snap.get("wait_for"):
                            _retry(
                                "wait_for_selector",
                                retries,
                                retry_delay_ms,
                                lambda: page.wait_for_selector(snap["wait_for"], timeout=30000),
                            )
                        if wait_for_full_load:
                            _settle_lazy_content(
                                page,
                                rounds=lazy_load_scroll_rounds,
                                scroll_delay_ms=scroll_delay,
                                timeout_ms=full_load_timeout_ms,
                                interval_ms=full_load_interval_ms,
                                stable_checks=full_load_stable_checks,
                            )
                            ok_load, _ = _wait_for_full_load(
                                page,
                                timeout_ms=full_load_timeout_ms,
                                interval_ms=full_load_interval_ms,
                                stable_checks=full_load_stable_checks,
                            )
                            if not ok_load:
                                print(
                                    f"[capture] post-lazy full-load timeout view={view_id} snapshot={snap_id}; continuing with best effort"
                                )
                        page.wait_for_timeout(500)
                        full_page = bool(snap.get("full_page", True))
                        png_path = view_out / f"{slug(snap_id)}.png"
                        _retry(
                            "screenshot",
                            retries,
                            retry_delay_ms,
                            lambda: page.screenshot(path=str(png_path), full_page=full_page, timeout=screenshot_timeout_ms),
                        )

                        ignore = _collect_ignore_regions(cfg, snap_id, snap.get("ignore_regions"))
                        _mask_from_ignore(page, png_path, ignore)

                        manifest.append(
                            {
                                "type": "flow",
                                "flow_id": flow_id,
                                "snapshot_id": snap_id,
                                "view_id": view_id,
                                "url": page.url,
                                "png": str(png_path),
                                "signature": _page_signature(page),
                            }
                        )
            finally:
                context.close()
        finally:
            browser.close()

    return manifest


def capture_all(
    cfg: dict,
    env: str,
    out_dir: Path,
    headed: bool = False,
    slow_mo_ms: int = 0,
    workers: int = 1,
    storage_state: Optional[Path] = None,
) -> dict:
    base_url = cfg["envs"].get(env)
    if not base_url:
        raise ValueError(f"Unknown env '{env}'. Known: {sorted(cfg['envs'].keys())}")

    ensure_dir(out_dir)
    with sync_playwright() as p:
        views = resolve_view_configs(cfg, p.devices)

    if workers <= 1 or len(views) <= 1:
        manifest: List[dict] = []
        for view_id, context_kwargs in views:
            manifest.extend(
                _capture_view(
                    cfg=cfg,
                    base_url=base_url,
                    out_dir=out_dir,
                    view_id=view_id,
                    context_kwargs=context_kwargs,
                    headed=headed,
                    slow_mo_ms=slow_mo_ms,
                    storage_state=storage_state,
                )
            )
    else:
        manifest = []
        with cf.ThreadPoolExecutor(max_workers=min(workers, len(views))) as ex:
            futures = [
                ex.submit(
                    _capture_view,
                    cfg,
                    base_url,
                    out_dir,
                    view_id,
                    context_kwargs,
                    headed,
                    slow_mo_ms,
                    storage_state,
                    None,
                )
                for view_id, context_kwargs in views
            ]
            for fut in cf.as_completed(futures):
                manifest.extend(fut.result())

    manifest.sort(key=lambda item: (item["view_id"], item["snapshot_id"], item["type"]))
    return {"env": env, "base_url": base_url, "out_dir": str(out_dir), "manifest": manifest}


def capture_selected(
    cfg: dict,
    env: str,
    out_dir: Path,
    selections: List[dict],
    headed: bool = False,
    slow_mo_ms: int = 0,
    storage_state: Optional[Path] = None,
) -> dict:
    base_url = cfg["envs"].get(env)
    if not base_url:
        raise ValueError(f"Unknown env '{env}'. Known: {sorted(cfg['envs'].keys())}")
    ensure_dir(out_dir)
    with sync_playwright() as p:
        views = resolve_view_configs(cfg, p.devices)
    view_index = {vid: ctx for vid, ctx in views}

    by_view: Dict[str, Set[str]] = {}
    for s in selections:
        by_view.setdefault(s["view_id"], set()).add(s["snapshot_id"])

    manifest: List[dict] = []
    for view_id, snap_ids in by_view.items():
        ctx = view_index.get(view_id)
        if not ctx:
            continue
        manifest.extend(
            _capture_view(
                cfg=cfg,
                base_url=base_url,
                out_dir=out_dir,
                view_id=view_id,
                context_kwargs=ctx,
                headed=headed,
                slow_mo_ms=slow_mo_ms,
                storage_state=storage_state,
                selected_snapshot_ids=snap_ids,
            )
        )
    manifest.sort(key=lambda item: (item["view_id"], item["snapshot_id"], item["type"]))
    return {"env": env, "base_url": base_url, "out_dir": str(out_dir), "manifest": manifest}
