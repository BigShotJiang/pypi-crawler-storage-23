from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image, ImageDraw

from visualcheck.baseline import cleanup_visual_runs
from visualcheck.baseline import resolve_baseline
from visualcheck.config import load_config
from visualcheck.diff_engine import diff_images
from visualcheck.report import write_report


class VisualCheckCoreTests(unittest.TestCase):
    def test_load_config_accepts_new_sections(self) -> None:
        with tempfile.TemporaryDirectory(prefix="vc_cfg_") as td:
            root = Path(td)
            cfg_p = root / "visualcheck.yaml"
            cfg_p.write_text(
                """
project: demo
suite: smoke
envs:
  prod: "https://example.com"
views:
  desktop_profiles: ["desktop_1440x900"]
  mobile_devices: []
pages:
  - id: home
    url: "/"
baseline:
  priority: ["figma", "runtime"]
  create_if_missing: true
  never_overwrite: true
  on_created: "INFO"
  figma_authoritative: false
compare:
  resize_on_mismatch: true
  mismatch_level: "WARN"
  thresholds:
    max_pixel_diff_pct: 0.1
    min_ssim: 0.99
  suggest_ignore_regions:
    enabled: true
    min_area: 100
    max_regions: 5
capture:
  browser_channel: "chrome"
  screenshot_timeout_ms: 50000
  wait_for_full_load: true
  full_load_timeout_ms: 120000
  full_load_check_interval_ms: 500
  full_load_stable_checks: 2
  lazy_load_scroll_rounds: 6
stability:
  reruns_on_warn: 1
  reruns_on_fail: 1
  require_consensus: "best"
quarantine:
  snapshots: ["home"]
owners:
  by_snapshot:
    home: "web-team"
""".strip()
            )
            cfg = load_config(cfg_p)
            self.assertEqual(cfg["stability"]["reruns_on_warn"], 1)
            self.assertIn("home", cfg["quarantine"]["snapshots"])

    def test_diff_images_region_and_suggestion(self) -> None:
        with tempfile.TemporaryDirectory(prefix="vc_diff_") as td:
            root = Path(td)
            baseline = root / "base.png"
            current = root / "cur.png"
            diff = root / "out" / "diff.png"

            b = Image.new("RGB", (100, 100), color=(255, 255, 255))
            b.save(baseline)
            c = Image.new("RGB", (100, 100), color=(255, 255, 255))
            d = ImageDraw.Draw(c)
            d.rectangle([10, 10, 60, 40], fill=(255, 0, 0))
            c.save(current)

            out = diff_images(
                baseline_png=baseline,
                current_png=current,
                diff_png=diff,
                resize_on_mismatch=True,
                region_rules=[
                    {
                        "name": "hero",
                        "x": 0,
                        "y": 0,
                        "width": 80,
                        "height": 60,
                        "max_pixel_diff_pct": 0.0,
                        "min_ssim": 1.0,
                    }
                ],
                suggest_regions=True,
                suggest_min_area=100,
                suggest_max_regions=3,
            )
            self.assertTrue(diff.exists())
            self.assertGreater(out["pixel_diff_pct"], 0.0)
            self.assertTrue(out["region_results"])
            self.assertTrue(out["suggested_regions"])

    def test_cleanup_visual_runs(self) -> None:
        with tempfile.TemporaryDirectory(prefix="vc_clean_") as td:
            root = Path(td)
            cfg = {"__root__": str(root), "project": "demo"}
            runs = root / "test_report" / "demo" / "visual_runs"
            for rid in ["20260101_000000", "20260102_000000", "20260103_000000"]:
                (runs / rid).mkdir(parents=True, exist_ok=True)
            dry = cleanup_visual_runs(cfg, keep_last=1, dry_run=True)
            self.assertEqual(len(dry["deleted"]), 2)
            real = cleanup_visual_runs(cfg, keep_last=1, dry_run=False)
            self.assertEqual(len(real["deleted"]), 2)

    def test_write_report_generates_junit(self) -> None:
        with tempfile.TemporaryDirectory(prefix="vc_rep_") as td:
            out = Path(td)
            report = {
                "project": "demo",
                "suite": "smoke",
                "env": "prod",
                "run_id": "r1",
                "generated_at": "2026-02-20T00:00:00",
                "status": "WARN",
                "thresholds": {"max_pixel_diff_pct": 0.1, "min_ssim": 0.99},
                "results": [
                    {
                        "snapshot_id": "home",
                        "view_id": "desktop_1440x900",
                        "status": "WARN",
                        "pixel_diff_pct": 0.2,
                        "ssim": 0.98,
                        "current": "cur.png",
                        "baseline": "base.png",
                        "diff": "diff.png",
                        "current_rel": "assets/current/home.png",
                        "baseline_rel": "assets/baseline/home.png",
                        "diff_rel": "assets/diff/home.png",
                    }
                ],
            }
            paths = write_report(out, report)
            self.assertTrue(Path(paths["report_json"]).exists())
            self.assertTrue(Path(paths["report_html"]).exists())
            self.assertTrue(Path(paths["report_junit_xml"]).exists())
            data = json.loads(Path(paths["report_json"]).read_text())
            self.assertEqual(data["status"], "WARN")

    def test_runtime_priority_does_not_trigger_figma_sync_when_runtime_exists(self) -> None:
        with tempfile.TemporaryDirectory(prefix="vc_priority_") as td:
            root = Path(td)
            cfg = {
                "__root__": str(root),
                "project": "demo",
                "suite": "smoke",
                "baseline": {
                    "priority": ["runtime", "figma"],
                    "create_if_missing": True,
                    "never_overwrite": True,
                    "on_created": "INFO",
                },
                "figma": {
                    "file_key": "dummy",
                    "frames": [{"id": "home", "node_id": "1:1", "view_id": "desktop_1440x900"}],
                },
            }
            runtime = root / "visual_baseline" / "demo" / "smoke" / "runtime" / "desktop_1440x900" / "home.png"
            runtime.parent.mkdir(parents=True, exist_ok=True)
            Image.new("RGB", (10, 10), color=(255, 255, 255)).save(runtime)

            with patch("visualcheck.figma.figma_sync_baselines") as fig_sync:
                p, kind = resolve_baseline(cfg, "desktop_1440x900", "home")
                self.assertEqual(kind, "runtime")
                self.assertEqual(Path(p), runtime)
                fig_sync.assert_not_called()

    def test_runtime_first_create_if_missing_skips_figma_lookup(self) -> None:
        with tempfile.TemporaryDirectory(prefix="vc_runtime_first_") as td:
            root = Path(td)
            cfg = {
                "__root__": str(root),
                "project": "demo",
                "suite": "smoke",
                "baseline": {
                    "priority": ["runtime", "figma"],
                    "create_if_missing": True,
                    "never_overwrite": True,
                    "on_created": "INFO",
                },
                "figma": {
                    "file_key": "dummy",
                    "frames": [{"id": "home", "node_id": "1:1", "view_id": "desktop_1440x900"}],
                },
            }
            with patch("visualcheck.figma.figma_sync_baselines") as fig_sync:
                p, kind = resolve_baseline(cfg, "desktop_1440x900", "home")
                self.assertIsNone(p)
                self.assertEqual(kind, "none")
                fig_sync.assert_not_called()

    def test_figma_does_not_seed_runtime_by_default(self) -> None:
        with tempfile.TemporaryDirectory(prefix="vc_figma_seed_") as td:
            root = Path(td)
            cfg = {
                "__root__": str(root),
                "project": "demo",
                "suite": "smoke",
                "baseline": {
                    "priority": ["figma", "runtime"],
                    "create_if_missing": True,
                    "never_overwrite": True,
                    "on_created": "INFO",
                },
                "figma": {
                    "file_key": "dummy",
                    "frames": [{"id": "home", "node_id": "1:1", "view_id": "desktop_1440x900"}],
                },
            }
            figma = root / "visual_baseline" / "demo" / "smoke" / "figma" / "desktop_1440x900" / "home.png"
            figma.parent.mkdir(parents=True, exist_ok=True)
            Image.new("RGB", (10, 10), color=(255, 255, 255)).save(figma)
            runtime = root / "visual_baseline" / "demo" / "smoke" / "runtime" / "desktop_1440x900" / "home.png"
            p, kind = resolve_baseline(cfg, "desktop_1440x900", "home")
            self.assertEqual(kind, "figma")
            self.assertEqual(Path(p), figma)
            self.assertFalse(runtime.exists())

    def test_figma_can_seed_runtime_when_enabled(self) -> None:
        with tempfile.TemporaryDirectory(prefix="vc_figma_seed_on_") as td:
            root = Path(td)
            cfg = {
                "__root__": str(root),
                "project": "demo",
                "suite": "smoke",
                "baseline": {
                    "priority": ["figma", "runtime"],
                    "create_if_missing": True,
                    "never_overwrite": True,
                    "on_created": "INFO",
                    "seed_runtime_from_figma": True,
                },
                "figma": {
                    "file_key": "dummy",
                    "frames": [{"id": "home", "node_id": "1:1", "view_id": "desktop_1440x900"}],
                },
            }
            figma = root / "visual_baseline" / "demo" / "smoke" / "figma" / "desktop_1440x900" / "home.png"
            figma.parent.mkdir(parents=True, exist_ok=True)
            Image.new("RGB", (10, 10), color=(255, 255, 255)).save(figma)
            runtime = root / "visual_baseline" / "demo" / "smoke" / "runtime" / "desktop_1440x900" / "home.png"
            p, kind = resolve_baseline(cfg, "desktop_1440x900", "home")
            self.assertEqual(kind, "figma")
            self.assertEqual(Path(p), figma)
            self.assertTrue(runtime.exists())

    def test_figma_local_frame_mapping_skips_sync_call(self) -> None:
        with tempfile.TemporaryDirectory(prefix="vc_figma_local_skip_") as td:
            root = Path(td)
            cfg = {
                "__root__": str(root),
                "project": "demo",
                "suite": "smoke",
                "baseline": {
                    "priority": ["figma", "runtime"],
                    "create_if_missing": True,
                    "never_overwrite": True,
                    "on_created": "INFO",
                },
                "figma": {
                    "file_key": "dummy",
                    "frames": [{"id": "home_frame", "node_id": "1:1", "view_id": "desktop_1440x900"}],
                },
            }
            figma = root / "visual_baseline" / "demo" / "smoke" / "figma" / "desktop_1440x900" / "home_frame.png"
            figma.parent.mkdir(parents=True, exist_ok=True)
            Image.new("RGB", (10, 10), color=(255, 255, 255)).save(figma)

            with patch("visualcheck.figma.figma_sync_baselines") as fig_sync:
                p, kind = resolve_baseline(cfg, "desktop_1440x900", "home")
                self.assertEqual(kind, "figma")
                self.assertEqual(Path(p), figma)
                fig_sync.assert_not_called()

    def test_force_reset_figma_baseline_triggers_sync(self) -> None:
        with tempfile.TemporaryDirectory(prefix="vc_figma_force_") as td:
            root = Path(td)
            cfg = {
                "__root__": str(root),
                "project": "demo",
                "suite": "smoke",
                "baseline": {
                    "priority": ["figma", "runtime"],
                    "create_if_missing": True,
                    "never_overwrite": True,
                    "on_created": "INFO",
                    "force_reset_figma_baseline": True,
                },
                "figma": {
                    "file_key": "dummy",
                    "frames": [{"id": "home", "node_id": "1:1", "view_id": "desktop_1440x900"}],
                },
            }
            figma = root / "visual_baseline" / "demo" / "smoke" / "figma" / "desktop_1440x900" / "home.png"
            figma.parent.mkdir(parents=True, exist_ok=True)
            Image.new("RGB", (10, 10), color=(255, 255, 255)).save(figma)

            with patch("visualcheck.figma.figma_sync_baselines") as fig_sync:
                p, kind = resolve_baseline(cfg, "desktop_1440x900", "home")
                self.assertEqual(kind, "figma")
                self.assertEqual(Path(p), figma)
                fig_sync.assert_called_once()
                _, kwargs = fig_sync.call_args
                self.assertTrue(kwargs.get("force"))
                self.assertIn("home", kwargs.get("only_ids") or [])


if __name__ == "__main__":
    unittest.main()
