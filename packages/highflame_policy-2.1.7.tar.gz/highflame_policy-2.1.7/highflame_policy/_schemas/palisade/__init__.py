"""Palisade schema data files."""
