"""Allow ``python -m rastir.server`` to start the collector server."""

from rastir.server.app import main

if __name__ == "__main__":
    main()
