from typing import Dict, Optional

from supervisely.app import DataJson
from supervisely.app.widgets import Widget

INFO = "info"
WARNING = "warning"
ERROR = "error"


class DoneLabel(Widget):
    """Displays completion messages (success, done)."""

    def __init__(
        self,
        text: Optional[str] = None,
        widget_id: Optional[str] = None,
    ):
        """
        :param text: Message text.
        :type text: Optional[str]
        :param widget_id: Unique widget identifier.
        :type widget_id: Optional[str]

        :Usage Example:

            .. code-block:: python

                from supervisely.app.widgets import DoneLabel
                label = DoneLabel(text="Done!")
        """
        self._text = text
        super().__init__(widget_id=widget_id, file_path=__file__)

    def get_json_data(self) -> Dict[str, str]:
        """Returns dictionary with widget data, which defines the appearance and behavior of the widget.

        Dictionary contains the following fields:
            - text: DoneLabel text

        :returns: Dictionary with widget data
        :rtype: Dict[str, str]
        """
        return {"text": self._text}

    def get_json_state(self) -> None:
        """DoneLabel widget does not have state,
        the method returns None."""
        return None

    @property
    def text(self) -> str:
        """Returns DoneLabel text.

        :returns: DoneLabel text
        :rtype: str
        """
        return self._text

    @text.setter
    def text(self, value: str) -> None:
        """Sets DoneLabel text.

        :param value: DoneLabel text
        :type value: str
        """
        self._text = value
        DataJson()[self.widget_id]["text"] = self._text
        DataJson().send_changes()
