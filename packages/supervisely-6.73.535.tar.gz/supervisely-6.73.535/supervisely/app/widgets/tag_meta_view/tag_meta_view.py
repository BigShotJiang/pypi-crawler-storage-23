from supervisely.app.widgets import Widget
from supervisely.annotation.tag_meta import TagMeta


class TagMetaView(Widget):
    """Displays a TagMeta as a compact card with name, value type, and optional type text."""

    def __init__(
        self,
        tag_meta: TagMeta,
        show_type_text: bool = True,
        limit_long_names: bool = False,
        widget_id: str = None,
    ):
        """:param tag_meta: TagMeta to display.
        :type tag_meta: TagMeta
        :param show_type_text: If True, show value type text.
        :type show_type_text: bool
        :param limit_long_names: If True, truncate long names.
        :type limit_long_names: bool
        :param widget_id: Unique widget identifier.
        :type widget_id: str, optional
        """
        self._tag_meta = tag_meta
        self._show_type_text = show_type_text
        self._limit_long_names = limit_long_names
        super().__init__(widget_id=widget_id, file_path=__file__)

    def get_json_data(self):
        res = self._tag_meta.to_json()
        res["limit_long_names"] = self._limit_long_names
        res["type_text"] = None
        if self._show_type_text is True:
            res["type_text"] = self._tag_meta.value_type.upper()
        return res

    def get_json_state(self):
        return None
