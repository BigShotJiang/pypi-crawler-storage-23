# Changelog

All notable changes to sqlalchemy-config will be documented in this file.

## version `0.4.7b0`
* BUGFIX - Fixed `get_orm_classes` to detect ORM models using SQLAlchemy >= 2.0 `DeclarativeBase` in addition to the legacy `declarative_base()` pattern.

### version `0.4.6b3`
* BUILD - Rewrote conda recipe to build from git source with per-version Python builds (3.11, 3.12, 3.13) and pytest test execution.
* BUILD - Pinned explicit Python version matrix in conda build config.
* BUILD - Added missing numpydoc dependency to pyproject.toml and conda meta.yaml.
* BUILD - Made pypi-upload.sh executable.
* DOCS - Simplified README install instructions and usage TL;DR, removed deprecated `get_sessionmaker` example.

## version `0.4.6b0`
* API - Added comprehensive top-level import and module API coverage tests.
* TESTS - Expanded test suite to 431 tests across config, orm_code, orm_doc, test_connect, type_cast, utils, and imports.
* TESTS - Added dedicated test helpers and golden-file assertions for reflected schema and ORM documentation outputs.
* BUGFIX - Fixed config permission handling regression and improved associated test coverage.
* BUGFIX - Fixed multiple type-casting date parsing edge cases.
* BUGFIX - Fixed ORM code generation issues in property/range handling and foreign-key column info updates.
* DOCS - Added developer reference API documentation page and refreshed generated API docs.
* BUILD - Standardized CI coverage collection via `coverage run`/`coverage report` and retained 80% coverage enforcement.
* BUILD - Added coverage path normalization settings for consistent reporting across local/docker/CI environments.

## version `0.4.5b0`
* BUILD - Migrated from setup.py to pyproject.toml with setuptools backend
* BUILD - Conda recipe consolidated to single noarch:python meta.yaml with Jinja2 templating
* BUILD - Updated supported Python versions from 3.8/3.9/3.10 to 3.11/3.12/3.13
* BUILD - Replaced git-based pyaddons dependency with cfin-pyaddons PyPI package
* BUILD - Added PyPI upload script (resources/pypi/pypi-upload.sh)
* BUILD - Rewrote MANIFEST.in with proper inclusions and exclusions
* BUILD - Updated CI Docker image from chrisfin/pypan:base to chrisfin/pypan:complete-3.13
* BUILD - Removed legacy setup.py, requirements.txt, and egg-info directory
* DOCS - Switched Sphinx theme from furo to sphinx-book-theme
* DOCS - Extracted changelog from README.md into standalone CHANGELOG.md

## version `0.4.4a0`
* SCRIPT - `orm-create-src` , fixed reflection errors due to SQLAlchemy 2.

## version `0.4.3a0`
* SCRIPT - `orm-test-connect` , improved the reporting of table query errors.

## version `0.4.2a0`
* BUGFIX - Fixed bug in ORM class detection for orm-doc-*.

## version `0.4.1a0`
* BUGFIX - Fixed import bug for SQLAlchemy 2.

## version `0.4.0a0`
* BUGFIX - Fixed config permissions checking added flexibility of perms arguments.
* BUGFIX - Fixed bug in exist check from config file.
* API - `get_new_sessionmaker` function, added option to raise on database exists.
* API - Added data type URLs
* API - Updated imports for SQLAlchemy 2
* TESTS - Added config tests.
* BUILD - Updated requirements to use SQLAlchemy >=2
* BUILD - Removed unused example directory and conftest.py

## version `0.3.1a0`
* API - added `get_new_sessionmaker` function and deprecated `get_sessionmaker`.
* DOCS - Added documentation for the test connection API.

## version `0.3.0a0`
* API - added better Python type conversion functions in Column objects.
* API - added a set of casting functions in the `sqlalchemy.type_cast` module.
* BUILD - added pytest calls from conda build.

## version `0.2.0a3`
* DOCS - added change log
* DOCS - Fixed missing columns in ``orm-create-src`` documentation.

## version `0.2.0a2`
* API - fixed description crash for columns with undefined doc attribute

## version `0.2.0a1`
* BUILD - added missing requirement.

## version `0.2.0a0`
* API - added a simpler sessionmaker function to the config module
* SCRIPTS - added scripts moved from pyaddons ``orm-doc-api``, ``orm-doc-schema``, ``orm-docstring``.
* SCRIPTS - added new ORM code producing script ``orm-create-src``.
* BUILD - removed Python v3.7
* BUILD - Updated requirements for new scripts
* DOCS - Added new script/API docs
