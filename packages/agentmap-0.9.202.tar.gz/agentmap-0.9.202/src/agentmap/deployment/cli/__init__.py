"""
CLI handlers for AgentMap using the new service architecture.
"""

from agentmap.deployment.cli.main_cli import main_cli

__all__ = ["main_cli"]
