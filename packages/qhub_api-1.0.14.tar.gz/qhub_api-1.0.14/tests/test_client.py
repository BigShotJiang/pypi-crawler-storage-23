import unittest

from qhub.api.platform.client import HubPlatformClient
from qhub.api.service.client import HubServiceClient

BASE_URL = "https://api.quantumhub.com"


class ClientTests(unittest.TestCase):

    def test_should_init_platform_api_client(self):
        client = HubPlatformClient(base_url=BASE_URL, api_key="test-api-key")
        self.assertIsInstance(client, HubPlatformClient)

    def test_should_init_service_api_client(self):
        client = HubServiceClient(base_url=BASE_URL, token="test-token")
        self.assertIsInstance(client, HubServiceClient)
