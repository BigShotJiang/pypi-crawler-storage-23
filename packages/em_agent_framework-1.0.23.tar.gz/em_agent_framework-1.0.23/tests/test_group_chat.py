"""
Tests for GroupChatManager with different routing strategies.
"""

import sys
from pathlib import Path
from typing import Annotated

import pytest

from em_agent_framework.config.settings import AgentConfig, ModelConfig
from em_agent_framework.core.agent import Agent
from core.group_chat import GroupChatManager
from em_agent_framework.core.tools.decorators import tool


@tool(description="Research information on the web for a given search query")
def research_web(query: Annotated[str, "Search query"]) -> str:
    """Research information on the web."""
    return f"Research results for '{query}': Found comprehensive information..."


@tool(description="Write code in a specified programming language for a given task")
def write_code(
    language: Annotated[str, "Programming language"], task: Annotated[str, "Task description"]
) -> str:
    """Write code in specified language."""
    return f"Generated {language} code for: {task}\n\n# Code here..."


class TestGroupChat:
    """Tests for GroupChatManager."""

    @pytest.fixture
    def agent_config(self):
        """Create test agent configuration."""
        return AgentConfig(max_turns=5, max_retries_per_model=2, verbose=True)

    @pytest.fixture
    def model_configs(self):
        """Create test model configurations."""
        return [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

    @pytest.fixture
    def researcher_agent(self, agent_config, model_configs):
        """Create a researcher agent."""
        return Agent(
            name="researcher",
            system_instruction="You are a research specialist. You excel at finding and summarizing information.",
            tools=[research_web],
            model_configs=model_configs,
            agent_config=agent_config,
            friendly_name="Research Specialist",
            agent_description="Expert at researching and summarizing information",
        )

    @pytest.fixture
    def coder_agent(self, agent_config, model_configs):
        """Create a coder agent."""
        return Agent(
            name="coder",
            system_instruction="You are a coding specialist. You excel at writing clean, efficient code.",
            tools=[write_code],
            model_configs=model_configs,
            agent_config=agent_config,
            friendly_name="Code Specialist",
            agent_description="Expert at writing and reviewing code",
        )

    @pytest.fixture
    def reviewer_agent(self, agent_config, model_configs):
        """Create a reviewer agent."""
        return Agent(
            name="reviewer",
            system_instruction="You are a code reviewer. You excel at finding issues and suggesting improvements.",
            tools=[],
            model_configs=model_configs,
            agent_config=agent_config,
            friendly_name="Code Reviewer",
            agent_description="Expert at reviewing code and suggesting improvements",
        )

    @pytest.mark.asyncio
    async def test_round_robin_strategy(self, researcher_agent, coder_agent, agent_config):
        """Test round-robin routing strategy."""
        manager = GroupChatManager(
            agents=[researcher_agent, coder_agent],
            strategy="round_robin",
            max_total_turns=4,
            verbose=True,
        )

        history = await manager.initiate_conversation(
            query="Research Python best practices then write a sample function.",
            first_agent=researcher_agent,
        )

        assert len(history) > 0
        # Should have alternated between agents
        print(f"\nRound-robin conversation: {len(history)} messages")

    @pytest.mark.asyncio
    async def test_skill_based_strategy(self, researcher_agent, coder_agent):
        """Test skill-based routing strategy."""
        manager = GroupChatManager(
            agents=[researcher_agent, coder_agent],
            strategy="skill_based",
            max_total_turns=6,
            verbose=True,
        )

        history = await manager.initiate_conversation(
            query="I need someone to research REST APIs and then write Python code to call one."
        )

        assert len(history) > 0
        print(f"\nSkill-based conversation: {len(history)} messages")

    @pytest.mark.asyncio
    async def test_custom_strategy(self, researcher_agent, coder_agent, reviewer_agent):
        """Test custom routing strategy."""

        def custom_transition(current_agent, conversation_history, agents, context):
            """Custom transition: researcher -> coder -> reviewer -> end."""
            if current_agent is None:
                return agents[0]  # Start with researcher

            if current_agent.name == "researcher":
                # After researcher, go to coder
                for agent in agents:
                    if agent.name == "coder":
                        return agent

            elif current_agent.name == "coder":
                # After coder, go to reviewer
                for agent in agents:
                    if agent.name == "reviewer":
                        return agent

            # After reviewer, end conversation
            return None

        manager = GroupChatManager(
            agents=[researcher_agent, coder_agent, reviewer_agent],
            strategy=custom_transition,
            max_total_turns=5,
            verbose=True,
        )

        history = await manager.initiate_conversation(
            query="Research sorting algorithms, write a Python quicksort, then review the code."
        )

        assert len(history) > 0
        # Should follow the custom pattern
        print(f"\nCustom strategy conversation: {len(history)} messages")

    @pytest.mark.asyncio
    async def test_termination_function(self, researcher_agent, coder_agent):
        """Test termination function."""

        def terminate_on_keyword(current_agent, history, agents, context):
            """Terminate if 'DONE' appears in last message."""
            if not history:
                return False

            last_content = history[-1]
            if hasattr(last_content, "parts"):
                for part in last_content.parts:
                    if hasattr(part, "text") and "DONE" in part.text:
                        return True
            return False

        manager = GroupChatManager(
            agents=[researcher_agent, coder_agent],
            strategy="round_robin",
            terminate_func=terminate_on_keyword,
            max_total_turns=10,
            verbose=True,
        )

        # Modified query to include termination signal
        history = await manager.initiate_conversation(
            query="Write a simple hello world function and say DONE when complete."
        )

        assert len(history) > 0
        print(f"\nTermination test: {len(history)} messages")

    @pytest.mark.asyncio
    async def test_conversation_context(self, researcher_agent, coder_agent):
        """Test shared context between agents."""
        context = {"project": "web_scraper", "language": "python"}

        manager = GroupChatManager(
            agents=[researcher_agent, coder_agent],
            strategy="round_robin",
            max_total_turns=4,
            context=context,
            verbose=True,
        )

        history = await manager.initiate_conversation(query="Build a web scraper.")

        assert len(history) > 0
        assert manager.context["project"] == "web_scraper"
        print(f"\nContext test: {manager.context}")

    @pytest.mark.asyncio
    async def test_reset_conversation(self, researcher_agent, coder_agent):
        """Test resetting conversation."""
        manager = GroupChatManager(
            agents=[researcher_agent, coder_agent],
            strategy="round_robin",
            max_total_turns=4,
            verbose=True,
        )

        # First conversation
        history1 = await manager.initiate_conversation(
            query="First task", first_agent=researcher_agent
        )

        assert len(history1) > 0
        assert manager.turn_count > 0

        # Reset
        manager.reset()

        assert len(manager.conversation_history) == 0
        assert manager.turn_count == 0

        # Second conversation
        history2 = await manager.initiate_conversation(query="Second task", first_agent=coder_agent)

        assert len(history2) > 0
        print(f"\nReset test - First: {len(history1)}, After reset: {len(history2)}")

    @pytest.mark.asyncio
    async def test_strategy_switching(self, researcher_agent, coder_agent):
        """Test changing strategy mid-way."""
        manager = GroupChatManager(
            agents=[researcher_agent, coder_agent],
            strategy="round_robin",
            max_total_turns=4,
            verbose=True,
        )

        # Start with round-robin
        history1 = await manager.initiate_conversation(
            query="First task", first_agent=researcher_agent
        )

        # Change to skill-based
        manager.set_strategy("skill_based")
        manager.reset()

        history2 = await manager.initiate_conversation(query="Research Python and write code")

        assert len(history1) > 0
        assert len(history2) > 0
        print("\nStrategy switch test completed")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
