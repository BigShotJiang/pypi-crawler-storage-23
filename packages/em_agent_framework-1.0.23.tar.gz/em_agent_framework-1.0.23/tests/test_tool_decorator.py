"""
Tests for the @tool decorator and validation.
"""

import sys
from pathlib import Path
from typing import Annotated

import pytest

from em_agent_framework.core.tools.decorators import (
    get_tool_category,
    get_tool_description,
    is_tool,
    tool,
    validate_tool,
)
from core.tools.utils import create_function_declaration


class TestToolDecorator:
    """Tests for @tool decorator."""

    def test_tool_decorator_basic(self):
        """Test basic tool decoration."""

        @tool(description="Add two numbers together")
        def add(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
            """Developer docs: implementation details."""
            return a + b

        assert is_tool(add)
        assert get_tool_description(add) == "Add two numbers together"
        assert get_tool_category(add) is None

    def test_tool_decorator_with_category(self):
        """Test tool decoration with category."""

        @tool(description="Calculate square root", category="math")
        def sqrt(n: Annotated[float, "Number"]) -> float:
            """Developer docs."""
            return n**0.5

        assert is_tool(sqrt)
        assert get_tool_description(sqrt) == "Calculate square root"
        assert get_tool_category(sqrt) == "math"

    def test_tool_decorator_empty_description(self):
        """Test that empty description raises error."""
        with pytest.raises(ValueError, match="description cannot be empty"):

            @tool(description="")
            def bad_tool():
                pass

    def test_tool_decorator_short_description(self):
        """Test that short description raises error."""
        with pytest.raises(ValueError, match="too short"):

            @tool(description="Add")
            def bad_tool():
                pass

    def test_tool_decorator_non_string_description(self):
        """Test that non-string description raises error."""
        with pytest.raises(ValueError, match="must be a string"):

            @tool(description=123)
            def bad_tool():
                pass

    def test_tool_decorator_filename_mistake(self):
        """Test detection of common mistake (passing filename)."""
        with pytest.raises(ValueError, match="looks like a filename"):

            @tool(description="tool.py")
            def bad_tool():
                pass

    def test_undecorated_function(self):
        """Test that undecorated function is not a tool."""

        def regular_function(x: int) -> int:
            """Just a regular function."""
            return x * 2

        assert not is_tool(regular_function)
        assert get_tool_description(regular_function) is None
        assert get_tool_category(regular_function) is None

    def test_validate_tool_success(self):
        """Test validating a properly decorated tool."""

        @tool(description="Multiply two numbers")
        def multiply(a: int, b: int) -> int:
            return a * b

        # Should not raise
        validate_tool(multiply)

    def test_validate_tool_failure(self):
        """Test validating an undecorated function."""

        def undecorated(x: int) -> int:
            return x

        with pytest.raises(ValueError, match="not decorated with @tool"):
            validate_tool(undecorated)


class TestToolDecoratorIntegration:
    """Integration tests with create_function_declaration."""

    def test_create_function_declaration_with_decorator(self):
        """Test that decorator description is used over docstring."""

        @tool(description="LLM sees this description")
        def example_tool(param: Annotated[str, "Parameter"]) -> str:
            """Developers see this docstring."""
            return param

        func_decl = create_function_declaration(example_tool)
        func_dict = func_decl.to_dict()

        assert func_dict["name"] == "example_tool"
        assert func_dict["description"] == "LLM sees this description"
        assert "param" in func_dict["parameters"]["properties"]

    def test_create_function_declaration_without_decorator_with_docstring(self):
        """Test that missing decorator raises error even with docstring (decorator is mandatory)."""

        def tool_without_decorator(param: Annotated[str, "Parameter"]) -> str:
            """This is the description."""
            return param

        # Should raise error because decorator is mandatory
        with pytest.raises(ValueError, match="must be decorated with @tool"):
            create_function_declaration(tool_without_decorator)

    def test_create_function_declaration_without_decorator_or_docstring(self):
        """Test that missing decorator raises error."""

        def bad_tool(param: Annotated[str, "Parameter"]) -> str:
            return param

        with pytest.raises(ValueError, match="must be decorated with @tool"):
            create_function_declaration(bad_tool)

    def test_decorator_preserves_function_behavior(self):
        """Test that decorator doesn't break function execution."""

        @tool(description="Add two numbers")
        def add(a: int, b: int) -> int:
            """Developer docs."""
            return a + b

        result = add(5, 3)
        assert result == 8

    def test_multiple_tools_with_categories(self):
        """Test organizing multiple tools by category."""

        @tool(description="Add numbers", category="arithmetic")
        def add(a: int, b: int) -> int:
            return a + b

        @tool(description="Calculate mean", category="statistics")
        def mean(numbers: list) -> float:
            return sum(numbers) / len(numbers)

        @tool(description="Parse JSON", category="data")
        def parse_json(data: str) -> dict:
            import json

            return json.loads(data)

        # All are tools
        assert all(is_tool(f) for f in [add, mean, parse_json])

        # Categories are correct
        assert get_tool_category(add) == "arithmetic"
        assert get_tool_category(mean) == "statistics"
        assert get_tool_category(parse_json) == "data"

    def test_decorator_with_context_parameter(self):
        """Test that decorator works with context injection."""

        @tool(description="Add numbers with user tracking")
        def add_with_context(
            a: Annotated[int, "First number"], b: Annotated[int, "Second number"], context: dict
        ) -> str:
            """Developer docs."""
            userid = context.get("userid", "unknown")
            return f"User {userid}: {a} + {b} = {a + b}"

        # Should be a valid tool
        assert is_tool(add_with_context)

        # Function declaration should exclude context parameter
        func_decl = create_function_declaration(add_with_context)
        func_dict = func_decl.to_dict()

        assert "a" in func_dict["parameters"]["properties"]
        assert "b" in func_dict["parameters"]["properties"]
        assert "context" not in func_dict["parameters"]["properties"]


class TestToolDecoratorEdgeCases:
    """Edge case tests for @tool decorator."""

    def test_description_with_whitespace(self):
        """Test that description is stripped of whitespace."""

        @tool(description="  Add two numbers  ")
        def add(a: int, b: int) -> int:
            return a + b

        assert get_tool_description(add) == "Add two numbers"

    def test_description_with_newlines(self):
        """Test multi-line description."""

        @tool(description="Add two numbers\nReturns their sum")
        def add(a: int, b: int) -> int:
            return a + b

        # Description should be preserved
        assert "Add two numbers" in get_tool_description(add)

    def test_unicode_in_description(self):
        """Test Unicode characters in description."""

        @tool(description="Calculate π × radius²")
        def circle_area(radius: float) -> float:
            import math

            return math.pi * radius**2

        assert "π" in get_tool_description(circle_area)

    def test_very_long_description(self):
        """Test very long description is allowed."""
        long_desc = "This is a very detailed description. " * 20

        @tool(description=long_desc)
        def complex_tool(x: int) -> int:
            return x

        assert len(get_tool_description(complex_tool)) > 100


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
