"""
Tests for context injection into tools.
"""

import sys
from pathlib import Path
from typing import Annotated

import pytest

from em_agent_framework.config.settings import AgentConfig, ModelConfig
from em_agent_framework.core.agent import Agent
from em_agent_framework.core.tools.decorators import tool


class TestContextInjection:
    """Tests for context injection functionality."""

    @pytest.fixture
    def agent_config(self):
        """Create test agent configuration."""
        return AgentConfig(
            max_turns=10,
            max_retries_per_model=2,
            verbose=False,  # Disable verbose to avoid Unicode issues in Windows
        )

    @pytest.fixture
    def model_configs(self):
        """Create test model configurations."""
        return [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=15.0),
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=15.0),
        ]

    @pytest.mark.asyncio
    async def test_basic_context_injection(self, agent_config, model_configs):
        """Test that context is injected into tools."""

        # Define tool that uses context
        @tool(description="Get user information from the context like name, email, or age")
        def get_user_info(
            field: Annotated[str, "Field to retrieve: name, email, age"], context: dict
        ) -> str:
            """Get user information from context."""
            user_data = context.get("user_data", {})
            return user_data.get(field, f"Field '{field}' not found")

        # Create agent with context
        agent = Agent(
            name="context_test_agent",
            system_instruction="You are a helpful assistant. Use get_user_info to retrieve user data.",
            tools=[get_user_info],
            context={"user_data": {"name": "John Doe", "email": "john@example.com", "age": 30}},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("What is the user's email?")

        assert isinstance(response, str)
        assert "john@example.com" in response.lower()
        print(f"\nContext injection response: {response}")

    @pytest.mark.asyncio
    async def test_context_not_sent_to_llm(self, agent_config, model_configs):
        """Test that context parameter is not visible in tool declaration."""

        @tool(description="Process a query using secret information from context")
        def secret_tool(query: Annotated[str, "Query"], context: dict) -> str:
            """Tool with secret context."""
            secret = context.get("secret_key")
            return f"Processed {query} with secret: {secret}"

        # Check that function declaration doesn't include context parameter
        from core.tools.utils import create_function_declaration

        func_decl = create_function_declaration(secret_tool)

        # The function should only have 'query' parameter, not 'context'
        # Convert FunctionDeclaration to dict to inspect it
        func_dict = func_decl.to_dict()
        assert "query" in func_dict["parameters"]["properties"]
        assert "context" not in func_dict["parameters"]["properties"]

        print("\n✅ Context parameter NOT exposed to LLM")

    @pytest.mark.asyncio
    async def test_large_data_in_context(self, agent_config, model_configs):
        """Test that large data can be passed via context without going to LLM."""

        @tool(
            description="Process dataset from context by counting items, summing values, or calculating average"
        )
        def process_data(
            operation: Annotated[str, "Operation: count, sum, average"], context: dict
        ) -> str:
            """Process data from context."""
            data = context.get("large_dataset", [])

            if operation == "count":
                return f"Dataset has {len(data)} items"
            elif operation == "sum":
                return f"Sum: {sum(data)}"
            elif operation == "average":
                return f"Average: {sum(data) / len(data) if data else 0:.2f}"
            return "Unknown operation"

        # Create large dataset (simulating a big dataframe)
        large_data = list(range(1000))

        agent = Agent(
            name="data_processor",
            system_instruction="Process data using the process_data tool.",
            tools=[process_data],
            context={"large_dataset": large_data},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("How many items are in the dataset?")

        assert isinstance(response, str)
        assert "1000" in response
        print(f"\nLarge data processing: {response}")

    @pytest.mark.asyncio
    async def test_multiple_context_fields(self, agent_config, model_configs):
        """Test tool accessing multiple context fields."""

        @tool(
            description="Create a report using user, company, and records information from context"
        )
        def create_report(report_type: Annotated[str, "Type of report"], context: dict) -> str:
            """Create a report using multiple context fields."""
            user = context.get("user_id")
            company = context.get("company_name")
            data_count = len(context.get("records", []))

            return f"{report_type} Report for {company} (User {user}): {data_count} records"

        agent = Agent(
            name="reporter",
            system_instruction="Generate reports using create_report tool. CRITICAL: You MUST include the EXACT output from the tool verbatim in your response.",
            tools=[create_report],
            context={"user_id": 42, "company_name": "Acme Corp", "records": [1, 2, 3, 4, 5]},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        response = await agent.send_message("Generate a sales report for Acme Corp.")

        assert isinstance(response, str)
        assert "Acme Corp" in response
        # Response should mention records - LLM may paraphrase so check multiple variations
        assert any(keyword in response.lower() for keyword in ["5", "five", "record"])
        print(f"\nMultiple context fields: {response}")

    @pytest.mark.asyncio
    async def test_context_updated_during_conversation(self, agent_config, model_configs):
        """Test that context includes updated chat_history."""

        @tool(description="Check the number of messages in the conversation history")
        def check_history_length(context: dict) -> str:
            """Check how many messages are in history."""
            history = context.get("chat_history", [])
            return f"Conversation has {len(history)} messages"

        agent = Agent(
            name="history_checker",
            system_instruction="Use check_history_length to see conversation length.",
            tools=[check_history_length],
            context={},  # Empty initially
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # First message
        response1 = await agent.send_message("How long is the conversation?")
        assert isinstance(response1, str)

        # Second message - history should have grown
        response2 = await agent.send_message("Check again")
        assert isinstance(response2, str)

        print(f"\nHistory tracking response 1: {response1}")
        print(f"History tracking response 2: {response2}")

    @pytest.mark.asyncio
    async def test_tool_without_context_parameter(self, agent_config, model_configs):
        """Test that tools without context parameter work normally."""

        @tool(description="Calculate the square of a number")
        def simple_tool(value: Annotated[int, "A number"]) -> str:
            """Simple tool without context."""
            return f"Value squared: {value * value}"

        @tool(description="Multiply a number by the multiplier value from context")
        def context_tool(value: Annotated[int, "A number"], context: dict) -> str:
            """Tool with context."""
            multiplier = context.get("multiplier", 1)
            return f"Value times {multiplier}: {value * multiplier}"

        agent = Agent(
            name="mixed_tools_agent",
            system_instruction="You are a math assistant. Use simple_tool to square numbers and context_tool to multiply numbers by the multiplier.",
            tools=[simple_tool, context_tool],
            context={"multiplier": 5},
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Tool without context should work
        response1 = await agent.send_message("Use simple_tool to calculate 7 squared")
        assert isinstance(response1, str)
        # May or may not have called the tool, just verify response exists

        # Tool with context should work
        response2 = await agent.send_message("Use context_tool with value 10")
        assert isinstance(response2, str)

        print(f"\nSimple tool: {response1}")
        print(f"Context tool: {response2}")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
