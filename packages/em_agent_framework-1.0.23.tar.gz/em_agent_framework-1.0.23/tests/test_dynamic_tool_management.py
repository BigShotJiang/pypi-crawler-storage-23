"""
Test dynamic tool loading and unloading during conversation.

This test verifies that tools can be added and removed mid-conversation,
and that the agent correctly uses available tools and cannot use removed tools.
"""

import pytest
from typing import Annotated

from em_agent_framework import Agent, AgentConfig, ModelConfig
from em_agent_framework.core.tools.decorators import tool
from em_agent_framework.core.tools import create_function_declaration


# Initial tools
@tool(description="Add two numbers")
def add(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Add two numbers."""
    return a + b


@tool(description="Multiply two numbers")
def multiply(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Multiply two numbers."""
    return a * b


# Tools to be added mid-conversation
@tool(description="Subtract two numbers")
def subtract(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Subtract second number from first."""
    return a - b


@tool(description="Divide two numbers")
def divide(a: Annotated[float, "Numerator"], b: Annotated[float, "Denominator"]) -> float:
    """Divide first number by second."""
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b


@tool(description="Calculate power")
def power(base: Annotated[float, "Base number"], exponent: Annotated[float, "Exponent"]) -> float:
    """Calculate base raised to exponent."""
    return base ** exponent


class TestDynamicToolManagement:
    """Test dynamic tool loading and unloading."""

    @pytest.fixture
    def agent_config(self):
        """Create test agent configuration."""
        return AgentConfig(
            max_turns=10,
            verbose=True,
            enable_parallel_tools=True,
        )

    @pytest.fixture
    def model_configs(self):
        """Create model configurations for testing."""
        return [
            ModelConfig(
                name="gemini-2.5-flash",
                provider="gemini",
                temperature=0.1,
                timeout=30.0,
            )
        ]

    @pytest.mark.asyncio
    async def test_add_tool_mid_conversation(self, agent_config, model_configs):
        """Test adding a new tool during conversation."""
        # Start with basic tools
        agent = Agent(
            name="Math Agent",
            system_instruction="You are a math assistant. Use the available tools to solve problems.",
            tools=[add, multiply],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Initially should have add and multiply
        assert "add" in agent.executor.tools
        assert "multiply" in agent.executor.tools
        assert "subtract" not in agent.executor.tools
        assert len(agent.function_declarations) == 2

        # Test that agent can use initial tools
        response = await agent.send_message("Calculate 5 + 3, then multiply the result by 2")
        assert isinstance(response, str)
        print(f"\n✅ Before adding subtract: {response}")

        # Add subtract tool mid-conversation
        agent.executor.add_tool(subtract)

        # Update function declarations to include new tool
        agent.function_declarations.append(create_function_declaration(subtract))

        # Verify tool was added
        assert "subtract" in agent.executor.tools
        assert len(agent.function_declarations) == 3
        print(f"\n✅ Added 'subtract' tool. Total tools: {len(agent.executor.tools)}")

        # Test that agent can now use the newly added tool
        response = await agent.send_message("Now calculate 20 - 7 using the subtract tool")
        assert isinstance(response, str)
        print(f"\n✅ After adding subtract: {response}")

    @pytest.mark.asyncio
    async def test_remove_tool_mid_conversation(self, agent_config, model_configs):
        """Test removing a tool during conversation."""
        # Start with multiple tools
        agent = Agent(
            name="Math Agent",
            system_instruction="You are a math assistant. Use the available tools to solve problems.",
            tools=[add, multiply, subtract],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Initially should have all three tools
        assert "add" in agent.executor.tools
        assert "multiply" in agent.executor.tools
        assert "subtract" in agent.executor.tools
        initial_count = len(agent.function_declarations)

        # Test that agent can use subtract
        response = await agent.send_message("Calculate 10 - 3")
        assert isinstance(response, str)
        print(f"\n✅ Before removing subtract: {response}")

        # Remove subtract tool mid-conversation
        agent.executor.remove_tool("subtract")

        # Update function declarations to remove the tool
        agent.function_declarations = [
            decl for decl in agent.function_declarations
            if decl.name != "subtract"
        ]

        # Verify tool was removed
        assert "subtract" not in agent.executor.tools
        assert len(agent.function_declarations) == initial_count - 1
        print(f"\n✅ Removed 'subtract' tool. Remaining tools: {len(agent.executor.tools)}")

        # Agent should still be able to use remaining tools
        response = await agent.send_message("Calculate 5 + 3, then multiply by 2")
        assert isinstance(response, str)
        print(f"\n✅ After removing subtract (using add/multiply): {response}")

    @pytest.mark.asyncio
    async def test_multiple_tool_additions(self, agent_config, model_configs):
        """Test adding multiple tools sequentially."""
        # Start with minimal tools
        agent = Agent(
            name="Math Agent",
            system_instruction="You are a math assistant. Use available tools to solve problems.",
            tools=[add],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        assert len(agent.executor.tools) == 1
        assert len(agent.function_declarations) == 1

        # Add multiply
        agent.executor.add_tool(multiply)
        agent.function_declarations.append(create_function_declaration(multiply))
        print(f"\n✅ Added multiply. Total tools: {len(agent.executor.tools)}")

        # Test multiply works
        response = await agent.send_message("Calculate 4 × 5")
        assert isinstance(response, str)
        print(f"\n✅ After adding multiply: {response}")

        # Add divide
        agent.executor.add_tool(divide)
        agent.function_declarations.append(create_function_declaration(divide))
        print(f"\n✅ Added divide. Total tools: {len(agent.executor.tools)}")

        # Test divide works
        response = await agent.send_message("Calculate 20 ÷ 4")
        assert isinstance(response, str)
        print(f"\n✅ After adding divide: {response}")

        # Add power
        agent.executor.add_tool(power)
        agent.function_declarations.append(create_function_declaration(power))
        print(f"\n✅ Added power. Total tools: {len(agent.executor.tools)}")

        # Test power works
        response = await agent.send_message("Calculate 2 to the power of 8")
        assert isinstance(response, str)
        print(f"\n✅ After adding power: {response}")

        # Final check - should have all 4 tools
        assert len(agent.executor.tools) == 4
        assert len(agent.function_declarations) == 4

    @pytest.mark.asyncio
    async def test_tool_swap(self, agent_config, model_configs):
        """Test removing one tool and adding another."""
        # Start with add and multiply
        agent = Agent(
            name="Math Agent",
            system_instruction="You are a math assistant. Use available tools to solve problems.",
            tools=[add, multiply],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Use initial tools
        response = await agent.send_message("Calculate (5 + 3) × 2")
        assert isinstance(response, str)
        print(f"\n✅ Initial tools (add, multiply): {response}")

        # Remove multiply and add divide
        agent.executor.remove_tool("multiply")
        agent.function_declarations = [
            decl for decl in agent.function_declarations
            if decl.name != "multiply"
        ]

        agent.executor.add_tool(divide)
        agent.function_declarations.append(create_function_declaration(divide))

        print(f"\n✅ Swapped multiply for divide. Current tools: {list(agent.executor.tools.keys())}")

        # Now agent should be able to add and divide, but not multiply
        response = await agent.send_message("Calculate 20 ÷ 5, then add 3")
        assert isinstance(response, str)
        print(f"\n✅ After swap (add, divide): {response}")

        # Verify multiply is gone
        assert "multiply" not in agent.executor.tools
        assert "divide" in agent.executor.tools
        assert "add" in agent.executor.tools

    @pytest.mark.asyncio
    async def test_tool_persistence_across_turns(self, agent_config, model_configs):
        """Test that dynamically added tools persist across multiple conversation turns."""
        agent = Agent(
            name="Math Agent",
            system_instruction="You are a math assistant. Use available tools to solve problems.",
            tools=[add],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Turn 1: Use add
        response1 = await agent.send_message("Calculate 5 + 3")
        assert isinstance(response1, str)
        print(f"\n✅ Turn 1 (add only): {response1}")

        # Add multiply
        agent.executor.add_tool(multiply)
        agent.function_declarations.append(create_function_declaration(multiply))

        # Turn 2: Use multiply
        response2 = await agent.send_message("Now multiply 4 by 6")
        assert isinstance(response2, str)
        print(f"\n✅ Turn 2 (added multiply): {response2}")

        # Add subtract
        agent.executor.add_tool(subtract)
        agent.function_declarations.append(create_function_declaration(subtract))

        # Turn 3: Use all three tools in sequence
        response3 = await agent.send_message("Calculate (10 + 5) × 2, then subtract 10")
        assert isinstance(response3, str)
        print(f"\n✅ Turn 3 (using all three tools): {response3}")

        # Verify all tools are still available
        assert len(agent.executor.tools) == 3
        assert "add" in agent.executor.tools
        assert "multiply" in agent.executor.tools
        assert "subtract" in agent.executor.tools

    @pytest.mark.asyncio
    async def test_remove_nonexistent_tool(self, agent_config, model_configs):
        """Test that removing a non-existent tool doesn't cause errors."""
        agent = Agent(
            name="Math Agent",
            system_instruction="You are a math assistant.",
            tools=[add],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        initial_count = len(agent.executor.tools)

        # Try to remove a tool that doesn't exist
        agent.executor.remove_tool("nonexistent_tool")

        # Should not affect existing tools
        assert len(agent.executor.tools) == initial_count
        assert "add" in agent.executor.tools

    @pytest.mark.asyncio
    async def test_readd_removed_tool(self, agent_config, model_configs):
        """Test removing and re-adding the same tool."""
        agent = Agent(
            name="Math Agent",
            system_instruction="You are a math assistant.",
            tools=[add, multiply],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Remove multiply
        agent.executor.remove_tool("multiply")
        agent.function_declarations = [
            decl for decl in agent.function_declarations
            if decl.name != "multiply"
        ]

        assert "multiply" not in agent.executor.tools
        print("\n✅ Removed multiply")

        # Re-add multiply
        agent.executor.add_tool(multiply)
        agent.function_declarations.append(create_function_declaration(multiply))

        assert "multiply" in agent.executor.tools
        print("\n✅ Re-added multiply")

        # Test that it works
        response = await agent.send_message("Calculate 7 × 8")
        assert isinstance(response, str)
        print(f"\n✅ Using re-added multiply: {response}")

    @pytest.mark.asyncio
    async def test_update_tools_func_basic(self, agent_config, model_configs):
        """Test using update_tools_func to dynamically modify tools."""
        call_count = {"count": 0}

        def dynamic_tool_updater(conversation_history, current_tools):
            """Add tools progressively based on call count."""
            call_count["count"] += 1

            # Start with just add
            tools = [add]

            # After first call, add multiply
            if call_count["count"] >= 2:
                tools.append(multiply)

            # After second call, add subtract
            if call_count["count"] >= 3:
                tools.append(subtract)

            print(f"\n🔄 update_tools_func called (call {call_count['count']}): {[t.__name__ for t in tools]}")
            return tools

        agent = Agent(
            name="Dynamic Math Agent",
            system_instruction="You are a math assistant. Use available tools.",
            tools=[add],  # Start with just add
            model_configs=model_configs,
            agent_config=agent_config,
            update_tools_func=dynamic_tool_updater,
        )

        # First message: only add should be available
        print("\n📝 Message 1: Should have [add]")
        response1 = await agent.send_message("Calculate 5 + 3")
        assert isinstance(response1, str)
        print(f"✅ Response 1: {response1}")

        # Second message: should now have add and multiply
        print("\n📝 Message 2: Should have [add, multiply]")
        response2 = await agent.send_message("Now calculate 4 × 6")
        assert isinstance(response2, str)
        print(f"✅ Response 2: {response2}")

        # Third message: should now have add, multiply, and subtract
        print("\n📝 Message 3: Should have [add, multiply, subtract]")
        response3 = await agent.send_message("Now calculate 20 - 7")
        assert isinstance(response3, str)
        print(f"✅ Response 3: {response3}")

    @pytest.mark.asyncio
    async def test_update_tools_func_context_aware(self, agent_config, model_configs):
        """Test update_tools_func that responds to conversation context."""
        def context_aware_updater(conversation_history, current_tools):
            """Add tools based on what user is asking for."""
            # Start with basic tools
            tools = [add, multiply]

            # Check conversation history for keywords
            history_text = str(conversation_history).lower()

            if "divide" in history_text or "÷" in history_text or "/" in history_text:
                tools.append(divide)
                print("\n🔄 Detected division request - adding divide tool")

            if "power" in history_text or "exponent" in history_text or "^" in history_text:
                tools.append(power)
                print("\n🔄 Detected power request - adding power tool")

            if "subtract" in history_text or "-" in history_text:
                tools.append(subtract)
                print("\n🔄 Detected subtraction request - adding subtract tool")

            return tools

        agent = Agent(
            name="Context-Aware Math Agent",
            system_instruction="You are a math assistant. Use available tools for calculations.",
            tools=[add, multiply],
            model_configs=model_configs,
            agent_config=agent_config,
            update_tools_func=context_aware_updater,
        )

        # First: basic operation
        print("\n📝 Message 1: Basic multiplication")
        response1 = await agent.send_message("Calculate 5 × 3")
        assert isinstance(response1, str)
        print(f"✅ Response 1: {response1}")

        # Second: mention division - should trigger divide tool addition
        print("\n📝 Message 2: Request division")
        response2 = await agent.send_message("Now I need to divide 20 by 4")
        assert isinstance(response2, str)
        print(f"✅ Response 2: {response2}")

        # Third: mention power - should trigger power tool addition
        print("\n📝 Message 3: Request power")
        response3 = await agent.send_message("Calculate 2 to the power of 5")
        assert isinstance(response3, str)
        print(f"✅ Response 3: {response3}")

    @pytest.mark.asyncio
    async def test_update_tools_func_conditional_removal(self, agent_config, model_configs):
        """Test update_tools_func that removes tools based on context."""
        message_count = {"count": 0}

        def conditional_tool_manager(conversation_history, current_tools):
            """Provide different tool sets based on message count."""
            message_count["count"] += 1

            # Messages 1-2: full toolset
            if message_count["count"] <= 2:
                tools = [add, multiply, subtract, divide]
                print(f"\n🔄 Turn {message_count['count']}: Full toolset (4 tools)")
            # Messages 3-4: arithmetic only (remove divide)
            elif message_count["count"] <= 4:
                tools = [add, multiply, subtract]
                print(f"\n🔄 Turn {message_count['count']}: Arithmetic only (3 tools)")
            # Messages 5+: basic only
            else:
                tools = [add, multiply]
                print(f"\n🔄 Turn {message_count['count']}: Basic only (2 tools)")

            return tools

        agent = Agent(
            name="Conditional Tool Agent",
            system_instruction="You are a math assistant. Use available tools.",
            tools=[add, multiply, subtract, divide],
            model_configs=model_configs,
            agent_config=agent_config,
            update_tools_func=conditional_tool_manager,
        )

        # Message 1: Full toolset
        print("\n📝 Message 1: Should have all 4 tools")
        response1 = await agent.send_message("Calculate 20 ÷ 4")
        assert isinstance(response1, str)
        print(f"✅ Response 1: {response1}")

        # Message 2: Still full toolset
        print("\n📝 Message 2: Should have all 4 tools")
        response2 = await agent.send_message("Multiply 5 by 3")
        assert isinstance(response2, str)
        print(f"✅ Response 2: {response2}")

        # Message 3: Arithmetic only (no divide)
        print("\n📝 Message 3: Should have 3 tools (no divide)")
        response3 = await agent.send_message("Calculate 10 - 3")
        assert isinstance(response3, str)
        print(f"✅ Response 3: {response3}")

        # Message 4: Still arithmetic only
        print("\n📝 Message 4: Should have 3 tools (no divide)")
        response4 = await agent.send_message("Add 7 and 8")
        assert isinstance(response4, str)
        print(f"✅ Response 4: {response4}")

        # Message 5: Basic only
        print("\n📝 Message 5: Should have 2 tools (add, multiply)")
        response5 = await agent.send_message("Calculate 6 times 4")
        assert isinstance(response5, str)
        print(f"✅ Response 5: {response5}")
