"""
Test that removed tools are automatically moved to complementary_tools.

When update_tools_func removes a tool from the active toolset, it should be
moved to complementary_tools so it can be loaded back via search_tool if needed.
"""

import pytest
from typing import Annotated

from em_agent_framework import Agent, AgentConfig, ModelConfig
from em_agent_framework.core.tools.decorators import tool


# Tools
@tool(description="Add two numbers")
def add(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Add two numbers."""
    return a + b


@tool(description="Multiply two numbers")
def multiply(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Multiply two numbers."""
    return a * b


@tool(description="Subtract two numbers")
def subtract(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Subtract second number from first."""
    return a - b


@tool(description="Divide two numbers")
def divide(a: Annotated[float, "Numerator"], b: Annotated[float, "Denominator"]) -> float:
    """Divide first number by second."""
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b


class TestToolRemovalToComplementary:
    """Test that removed tools are moved to complementary_tools."""

    @pytest.fixture
    def agent_config(self):
        """Create test agent configuration."""
        return AgentConfig(
            max_turns=10,
            verbose=True,
        )

    @pytest.fixture
    def model_configs(self):
        """Create model configurations for testing."""
        return [
            ModelConfig(
                name="gemini-2.5-flash",
                provider="gemini",
                temperature=0.1,
                timeout=30.0,
            )
        ]

    @pytest.mark.asyncio
    async def test_removed_tools_are_completely_removed(self, agent_config, model_configs):
        """Test that tools removed by update_tools_func are completely removed (not moved to complementary)."""
        turn_count = {"count": 0}

        def dynamic_tool_manager(conversation_history, current_tools):
            """Remove tools after certain turns."""
            turn_count["count"] += 1

            # Turn 1-2: All four tools
            if turn_count["count"] <= 2:
                print(f"\n🔄 Turn {turn_count['count']}: All tools (add, multiply, subtract, divide)")
                return [add, multiply, subtract, divide]

            # Turn 3: Remove divide and subtract (keep add, multiply)
            elif turn_count["count"] == 3:
                print(f"\n🔄 Turn {turn_count['count']}: Removing divide and subtract")
                return [add, multiply]

            # Turn 4+: Remove multiply (keep only add)
            else:
                print(f"\n🔄 Turn {turn_count['count']}: Removing multiply")
                return [add]

        agent = Agent(
            name="Tool Removal Agent",
            system_instruction="You are a math assistant. Use available tools.",
            tools=[add, multiply, subtract, divide],
            model_configs=model_configs,
            agent_config=agent_config,
            update_tools_func=dynamic_tool_manager,
        )

        # Initially no complementary tools
        initial_complementary_count = len(agent.complementary_tools)
        print(f"\n📊 Initial state:")
        print(f"   Active tools: {[t.__name__ for t in agent.tools]}")
        print(f"   Complementary tools: {[t.__name__ for t in agent.complementary_tools]}")

        # First message: use divide
        print(f"\n{'='*80}")
        print("MESSAGE 1: Use divide (should work)")
        print(f"{'='*80}")
        response1 = await agent.send_message("Calculate 20 ÷ 4")
        print(f"✅ Response: {response1}")

        # Check state after turn 1
        print(f"\n📊 After turn 1:")
        print(f"   Active tools: {[t.__name__ for t in agent.tools]}")
        print(f"   Complementary tools: {[t.__name__ for t in agent.complementary_tools]}")

        # Second message: this will trigger removal of divide and subtract
        print(f"\n{'='*80}")
        print("MESSAGE 2: Use multiply (divide/subtract should be removed)")
        print(f"{'='*80}")
        response2 = await agent.send_message("Now calculate 5 × 3")
        print(f"✅ Response: {response2}")

        # Check that divide and subtract were completely removed (NOT moved to complementary)
        print(f"\n📊 After turn 2 (divide/subtract removed):")
        print(f"   Active tools: {[t.__name__ for t in agent.tools]}")
        print(f"   Complementary tools: {[t.__name__ for t in agent.complementary_tools]}")

        assert "divide" not in {t.__name__ for t in agent.tools}, "divide should be removed from active tools"
        assert "subtract" not in {t.__name__ for t in agent.tools}, "subtract should be removed from active tools"
        assert "divide" not in {t.__name__ for t in agent.complementary_tools}, "divide should NOT be in complementary_tools (no auto-migration)"
        assert "subtract" not in {t.__name__ for t in agent.complementary_tools}, "subtract should NOT be in complementary_tools (no auto-migration)"
        print("✅ Assertion passed: divide and subtract completely removed (not in complementary)")

        # Third message: this will trigger removal of multiply
        print(f"\n{'='*80}")
        print("MESSAGE 3: Use add (multiply should be removed)")
        print(f"{'='*80}")
        response3 = await agent.send_message("Now calculate 7 + 8")
        print(f"✅ Response: {response3}")

        # Check that multiply was completely removed (NOT moved to complementary)
        print(f"\n📊 After turn 3 (multiply removed):")
        print(f"   Active tools: {[t.__name__ for t in agent.tools]}")
        print(f"   Complementary tools: {[t.__name__ for t in agent.complementary_tools]}")

        assert "multiply" not in {t.__name__ for t in agent.tools}, "multiply should be removed from active tools"
        assert "multiply" not in {t.__name__ for t in agent.complementary_tools}, "multiply should NOT be in complementary_tools (no auto-migration)"
        print("✅ Assertion passed: multiply completely removed (not in complementary)")

        # Final check: complementary_tools should be empty (no auto-migration)
        complementary_names = {t.__name__ for t in agent.complementary_tools}
        assert len(complementary_names) == 0, "No tools should be auto-migrated to complementary"
        assert "add" not in complementary_names  # add is still active

        print(f"\n{'='*80}")
        print("✅ TEST PASSED: Removed tools completely removed (not auto-migrated to complementary)")
        print(f"   Final active tools: {[t.__name__ for t in agent.tools]}")
        print(f"   Final complementary tools: {[t.__name__ for t in agent.complementary_tools]}")
        print(f"{'='*80}")

    @pytest.mark.asyncio
    async def test_no_duplicate_in_complementary(self, agent_config, model_configs):
        """Test that tools aren't duplicated in complementary_tools if already there."""
        call_count = {"count": 0}

        def toggle_tool_manager(conversation_history, current_tools):
            """Toggle subtract tool on/off to test no duplicates."""
            call_count["count"] += 1

            # Odd turns: include subtract
            if call_count["count"] % 2 == 1:
                print(f"\n🔄 Call {call_count['count']}: Adding subtract")
                return [add, subtract]
            # Even turns: exclude subtract
            else:
                print(f"\n🔄 Call {call_count['count']}: Removing subtract")
                return [add]

        agent = Agent(
            name="Toggle Agent",
            system_instruction="You are a math assistant.",
            tools=[add, subtract],
            complementary_tools=[multiply],  # Start with multiply in complementary
            model_configs=model_configs,
            agent_config=agent_config,
            update_tools_func=toggle_tool_manager,
        )

        print(f"\n📊 Initial complementary tools: {[t.__name__ for t in agent.complementary_tools]}")
        initial_comp_count = len(agent.complementary_tools)

        # Message 1: subtract gets removed and added to complementary
        response1 = await agent.send_message("Calculate 5 + 3")
        print(f"\n📊 After message 1:")
        print(f"   Complementary tools: {[t.__name__ for t in agent.complementary_tools]}")
        comp_count_1 = len(agent.complementary_tools)

        # Message 2: subtract added back to active (removed from complementary implicitly)
        response2 = await agent.send_message("Calculate 10 - 3")
        print(f"\n📊 After message 2:")
        print(f"   Complementary tools: {[t.__name__ for t in agent.complementary_tools]}")
        comp_count_2 = len(agent.complementary_tools)

        # Message 3: subtract removed again (should not create duplicate)
        response3 = await agent.send_message("Calculate 7 + 2")
        print(f"\n📊 After message 3:")
        print(f"   Complementary tools: {[t.__name__ for t in agent.complementary_tools]}")
        comp_count_3 = len(agent.complementary_tools)

        # Check no duplicates
        complementary_names = [t.__name__ for t in agent.complementary_tools]
        unique_names = set(complementary_names)

        print(f"\n✅ Complementary tools list: {complementary_names}")
        print(f"✅ Unique names: {unique_names}")
        print(f"✅ Counts: initial={initial_comp_count}, after_msg1={comp_count_1}, after_msg2={comp_count_2}, after_msg3={comp_count_3}")

        assert len(complementary_names) == len(unique_names), \
            f"Duplicate tools in complementary_tools: {complementary_names}"

        print(f"\n✅ TEST PASSED: No duplicates in complementary_tools")

    @pytest.mark.asyncio
    async def test_removed_tool_gives_unknown_error(self, agent_config, model_configs):
        """Test that calling a completely removed tool gives 'Unknown function' error."""
        turn_count = {"count": 0}

        def remove_multiply_after_first_use(conversation_history, current_tools):
            """Remove multiply tool after it's been used once."""
            turn_count["count"] += 1

            # Keep all tools for first 2 turns
            if turn_count["count"] <= 2:
                print(f"\n🔄 Turn {turn_count['count']}: All tools available")
                return [add, multiply, subtract]
            # Remove multiply after turn 2
            else:
                print(f"\n🔄 Turn {turn_count['count']}: Removing multiply tool")
                return [add, subtract]

        agent = Agent(
            name="Tool Removal Test Agent",
            system_instruction="You are a math assistant. Use available tools. When a tool is not available, the error message will tell you how to add it.",
            tools=[add, multiply, subtract],
            model_configs=model_configs,
            agent_config=agent_config,
            update_tools_func=remove_multiply_after_first_use,
        )

        print(f"\n{'='*80}")
        print("TEST: Removed tool should suggest using search_tool")
        print(f"{'='*80}")

        # First message: Use multiply successfully
        print(f"\n📝 Message 1: Use multiply (should work)")
        response1 = await agent.send_message("Calculate 5 × 3")
        assert isinstance(response1, str)
        print(f"✅ Response 1: {response1}")

        # Check that multiply is still in active tools
        assert "multiply" in agent.executor.tools
        print(f"\n✅ multiply is in active tools")

        # Second message: This should trigger removal of multiply
        print(f"\n📝 Message 2: Use add (multiply will be removed after this)")
        response2 = await agent.send_message("Now calculate 7 + 8")
        assert isinstance(response2, str)
        print(f"✅ Response 2: {response2}")

        # Check that multiply is now completely removed (not in active OR complementary)
        assert "multiply" not in agent.executor.tools
        assert "multiply" not in agent.executor.complementary_tool_names
        print(f"\n✅ multiply completely removed from both active and complementary tools")

        # Third message: Try to use multiply - should get "Unknown function" error
        print(f"\n📝 Message 3: Try to use multiply (should fail with 'Unknown function')")

        # Let's check the executor directly to verify the error message
        try:
            # Try to execute multiply directly through the executor
            result = await agent.executor.execute("multiply", {"a": 4, "b": 6})
            # If we get here, it means multiply was somehow still in tools (shouldn't happen)
            assert False, "multiply should not be executable after removal"
        except ValueError as e:
            error_message = str(e)
            print(f"\n✅ Got expected error: {error_message}")

            # Verify the error message says "Unknown function" (not search_tool suggestion)
            assert "unknown function" in error_message.lower(), \
                f"Error message should say 'Unknown function'. Got: {error_message}"

            print(f"✅ Error message correctly indicates unknown function (complete removal)")

        print(f"\n{'='*80}")
        print("✅ TEST PASSED: Removed tool gives 'Unknown function' error (complete removal)")
        print(f"{'='*80}")

    @pytest.mark.asyncio
    async def test_explicit_add_to_complementary(self, agent_config, model_configs):
        """Test explicitly adding removed tools to complementary_tools using add_to_complementary()."""
        turn_count = {"count": 0}

        def dynamic_tool_manager(conversation_history, current_tools):
            """Remove tools after certain turns."""
            turn_count["count"] += 1

            if turn_count["count"] <= 2:
                return [add, multiply, subtract]
            else:
                return [add]  # Remove multiply and subtract

        agent = Agent(
            name="Explicit Complementary Agent",
            system_instruction="You are a math assistant.",
            tools=[add, multiply, subtract],
            model_configs=model_configs,
            agent_config=agent_config,
            update_tools_func=dynamic_tool_manager,
        )

        print(f"\n📊 Initial state:")
        print(f"   Active tools: {[t.__name__ for t in agent.tools]}")
        print(f"   Complementary tools: {[t.__name__ for t in agent.complementary_tools]}")

        # Message 1: trigger removal
        await agent.send_message("Calculate 5 + 3")

        print(f"\n📊 After removal:")
        print(f"   Active tools: {[t.__name__ for t in agent.tools]}")
        print(f"   Complementary tools: {[t.__name__ for t in agent.complementary_tools]}")

        # Verify tools were completely removed
        assert "multiply" not in {t.__name__ for t in agent.tools}
        assert "multiply" not in {t.__name__ for t in agent.complementary_tools}
        print("✅ multiply completely removed")

        # Now explicitly add multiply to complementary_tools
        agent.add_to_complementary(multiply, subtract)

        print(f"\n📊 After explicit add_to_complementary:")
        print(f"   Active tools: {[t.__name__ for t in agent.tools]}")
        print(f"   Complementary tools: {[t.__name__ for t in agent.complementary_tools]}")

        # Verify tools are now in complementary
        assert "multiply" in {t.__name__ for t in agent.complementary_tools}
        assert "subtract" in {t.__name__ for t in agent.complementary_tools}
        assert "multiply" not in {t.__name__ for t in agent.tools}
        print("✅ multiply and subtract explicitly added to complementary_tools")

        # Now trying to call multiply should give search_tool message
        try:
            await agent.executor.execute("multiply", {"a": 4, "b": 6})
            assert False, "Should not be able to execute complementary tool"
        except ValueError as e:
            error_message = str(e)
            print(f"\n✅ Error calling complementary tool: {error_message}")
            assert "search_tool" in error_message.lower() or "complementary" in error_message.lower()
            print("✅ Error correctly suggests using search_tool")

        print(f"\n{'='*80}")
        print("✅ TEST PASSED: Explicit add_to_complementary() works correctly")
        print(f"{'='*80}")


if __name__ == "__main__":
    import asyncio

    async def main():
        test = TestToolRemovalToComplementary()
        config = AgentConfig(max_turns=10, verbose=True)
        models = [ModelConfig(name="gemini-2.5-flash", provider="gemini", temperature=0.1, timeout=30.0)]

        print("\n" + "="*80)
        print("TEST 1: Removed tools move to complementary")
        print("="*80)
        await test.test_removed_tools_move_to_complementary(config, models)

        print("\n\n" + "="*80)
        print("TEST 2: No duplicates in complementary")
        print("="*80)
        await test.test_no_duplicate_in_complementary(config, models)

    asyncio.run(main())
