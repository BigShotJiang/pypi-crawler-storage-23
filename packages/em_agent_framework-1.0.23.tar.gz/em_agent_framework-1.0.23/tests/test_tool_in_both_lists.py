"""
Test to check if tools can exist in BOTH active and complementary lists simultaneously.
"""

import pytest
from typing import Annotated

from em_agent_framework import Agent, AgentConfig, ModelConfig
from em_agent_framework.core.tools.decorators import tool


@tool(description="Add two numbers")
def add(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Add two numbers."""
    return a + b


@tool(description="Multiply two numbers")
def multiply(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Multiply two numbers."""
    return a * b


@tool(description="Subtract two numbers")
def subtract(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Subtract second number from first."""
    return a - b


class TestToolInBothLists:
    """Test if tools can exist in both active and complementary lists."""

    @pytest.fixture
    def agent_config(self):
        """Create test agent configuration."""
        return AgentConfig(
            max_turns=10,
            verbose=True,
        )

    @pytest.fixture
    def model_configs(self):
        """Create model configurations for testing."""
        return [
            ModelConfig(
                name="gemini-2.5-flash",
                provider="gemini",
                temperature=0.1,
                timeout=30.0,
            )
        ]

    @pytest.mark.asyncio
    async def test_tool_readded_remains_in_complementary(self, agent_config, model_configs):
        """Test that when a tool is re-added, it remains in complementary (BUG)."""
        call_count = {"count": 0}

        def toggle_tool(conversation_history, current_tools):
            """Toggle subtract on/off."""
            call_count["count"] += 1

            # Odd: include subtract
            if call_count["count"] % 2 == 1:
                print(f"\n🔄 Call {call_count['count']}: Adding subtract to active")
                return [add, subtract]
            # Even: remove subtract
            else:
                print(f"\n🔄 Call {call_count['count']}: Removing subtract from active")
                return [add]

        agent = Agent(
            name="Toggle Agent",
            system_instruction="You are a math assistant.",
            tools=[add, subtract],
            model_configs=model_configs,
            agent_config=agent_config,
            update_tools_func=toggle_tool,
        )

        print(f"\n📊 Initial state:")
        print(f"   Active tools: {[t.__name__ for t in agent.tools]}")
        print(f"   Complementary tools: {[t.__name__ for t in agent.complementary_tools]}")

        # Message 1: subtract gets removed and moved to complementary
        print(f"\n{'='*80}")
        print("MESSAGE 1: Remove subtract")
        print(f"{'='*80}")
        await agent.send_message("Calculate 5 + 3")

        print(f"\n📊 After message 1:")
        print(f"   Active tools: {[t.__name__ for t in agent.tools]}")
        print(f"   Complementary tools: {[t.__name__ for t in agent.complementary_tools]}")

        # Check: subtract should be in complementary, not in active
        assert "subtract" not in [t.__name__ for t in agent.tools]
        assert "subtract" in [t.__name__ for t in agent.complementary_tools]
        print("✅ subtract is in complementary only")

        # Message 2: subtract gets re-added to active
        print(f"\n{'='*80}")
        print("MESSAGE 2: Re-add subtract")
        print(f"{'='*80}")
        await agent.send_message("Calculate 10 - 3")

        print(f"\n📊 After message 2:")
        print(f"   Active tools: {[t.__name__ for t in agent.tools]}")
        print(f"   Complementary tools: {[t.__name__ for t in agent.complementary_tools]}")

        # BUG CHECK: Is subtract in BOTH lists?
        in_active = "subtract" in [t.__name__ for t in agent.tools]
        in_complementary = "subtract" in [t.__name__ for t in agent.complementary_tools]

        print(f"\n📊 Tool overlap check:")
        print(f"   subtract in active: {in_active}")
        print(f"   subtract in complementary: {in_complementary}")

        if in_active and in_complementary:
            print(f"\n❌ BUG CONFIRMED: subtract exists in BOTH active and complementary lists!")
            print(f"   This is inefficient and could cause confusion.")
            print(f"   When a tool is re-added to active, it should be removed from complementary.")

            # This will fail, demonstrating the bug
            assert not (in_active and in_complementary), \
                "Tool should not exist in both active and complementary lists simultaneously"
        else:
            print(f"\n✅ No overlap: subtract is only in active (as expected)")


if __name__ == "__main__":
    import asyncio

    async def main():
        test = TestToolInBothLists()
        config = AgentConfig(max_turns=10, verbose=True)
        models = [ModelConfig(name="gemini-2.5-flash", provider="gemini", temperature=0.1, timeout=30.0)]

        await test.test_tool_readded_remains_in_complementary(config, models)

    asyncio.run(main())
