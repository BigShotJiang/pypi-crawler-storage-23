"""
Test to demonstrate update_tools_func bug.

The bug: update_tools_func is only called ONCE at the top of send_message(),
not inside the _handle_function_calling_loop. This means tools cannot be
dynamically updated based on intermediate tool results during a multi-turn
conversation within a single send_message() call.
"""

import pytest
from typing import Annotated

from em_agent_framework import Agent, AgentConfig, ModelConfig
from em_agent_framework.core.tools.decorators import tool


# Tools
@tool(description="Add two numbers")
def add(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Add two numbers."""
    print(f"  [TOOL EXECUTED] add({a}, {b}) = {a + b}")
    return a + b


@tool(description="Multiply two numbers")
def multiply(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Multiply two numbers."""
    print(f"  [TOOL EXECUTED] multiply({a}, {b}) = {a * b}")
    return a * b


@tool(description="Subtract two numbers")
def subtract(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Subtract second number from first."""
    print(f"  [TOOL EXECUTED] subtract({a}, {b}) = {a - b}")
    return a - b


class TestUpdateToolsFuncBug:
    """Demonstrate the update_tools_func bug."""

    @pytest.fixture
    def agent_config(self):
        """Create test agent configuration."""
        return AgentConfig(
            max_turns=10,
            verbose=True,
        )

    @pytest.fixture
    def model_configs(self):
        """Create model configurations for testing."""
        return [
            ModelConfig(
                name="gemini-2.5-flash",
                provider="gemini",
                temperature=0.1,
                timeout=30.0,
            )
        ]

    @pytest.mark.asyncio
    async def test_update_tools_func_not_called_in_loop(self, agent_config, model_configs):
        """
        Demonstrate that update_tools_func is NOT called during the function calling loop.

        Expected behavior: update_tools_func should be called before each turn in the loop
        Actual behavior: update_tools_func is only called once at the start of send_message()
        """
        call_log = []

        def tool_updater_with_logging(conversation_history, current_tools):
            """Log each time update_tools_func is called."""
            call_count = len(call_log) + 1
            call_log.append({
                "call_number": call_count,
                "history_length": len(conversation_history) if conversation_history else 0,
            })

            print(f"\n{'='*60}")
            print(f"🔄 update_tools_func CALLED (Call #{call_count})")
            print(f"   History length: {len(conversation_history) if conversation_history else 0}")
            print(f"{'='*60}")

            # Start with add
            tools = [add]

            # Add multiply after first turn (should happen after add is executed)
            # BUG: This will never trigger during the loop!
            if call_count >= 2:
                tools.append(multiply)
                print(f"   ✅ Added multiply tool (call #{call_count})")

            # Add subtract after second turn
            if call_count >= 3:
                tools.append(subtract)
                print(f"   ✅ Added subtract tool (call #{call_count})")

            return tools

        agent = Agent(
            name="Test Agent",
            system_instruction="You are a math assistant. Perform the calculation step by step using available tools.",
            tools=[add],
            model_configs=model_configs,
            agent_config=agent_config,
            update_tools_func=tool_updater_with_logging,
        )

        print("\n" + "="*80)
        print("TEST: Multi-turn conversation requiring add, then multiply, then subtract")
        print("="*80)
        print("\nExpected: update_tools_func called 3+ times (before each turn)")
        print("Actual: update_tools_func called ONLY ONCE at the start\n")

        # This will require multiple turns:
        # Turn 1: add(5, 3) = 8
        # Turn 2: multiply(8, 2) = 16  <- multiply should be available by now
        # Turn 3: subtract(16, 6) = 10 <- subtract should be available by now
        response = await agent.send_message(
            "Calculate: (5 + 3) × 2 - 6. Do this step by step using the tools."
        )

        print("\n" + "="*80)
        print(f"RESULT: {response}")
        print("="*80)

        print(f"\n📊 update_tools_func was called {len(call_log)} time(s):")
        for log_entry in call_log:
            print(f"   Call #{log_entry['call_number']}: history_length={log_entry['history_length']}")

        print(f"\n❌ BUG CONFIRMED: update_tools_func was only called {len(call_log)} time(s)")
        print(f"   Expected: At least 3 calls (one before each turn in the loop)")
        print(f"   Actual: Only 1 call (at the start of send_message)")

        # The test will likely fail because multiply/subtract won't be available when needed
        assert isinstance(response, str)

        # This assertion will FAIL, demonstrating the bug
        # We expect at least 3 calls: initial + after each tool execution
        # But we only get 1 call
        print(f"\n⚠️  Assertion check: len(call_log) >= 3")
        print(f"   Actual: len(call_log) = {len(call_log)}")

        # Comment out the assertion to let the test "pass" and show the bug
        # assert len(call_log) >= 3, f"Expected at least 3 calls, but got {len(call_log)}"

        # Instead, just verify the bug exists
        if len(call_log) == 1:
            print(f"\n✅ BUG CONFIRMED: update_tools_func only called once!")
        else:
            print(f"\n❓ Unexpected: update_tools_func called {len(call_log)} times")


if __name__ == "__main__":
    import asyncio

    async def main():
        test = TestUpdateToolsFuncBug()
        config = test.agent_config()
        models = test.model_configs()
        await test.test_update_tools_func_not_called_in_loop(config, models)

    asyncio.run(main())
