"""
Anthropic provider for Claude models on Vertex AI.
"""

import asyncio
from typing import Any, Dict, List, Optional

from anthropic import AnthropicVertex
from google.genai import types

from em_agent_framework.config.settings import ModelConfig

from .provider import ModelProvider, ProviderResponse


class AnthropicProvider(ModelProvider):
    """
    Provider for Anthropic Claude models on Vertex AI.

    Uses the Anthropic Vertex SDK which is the official way to access
    Claude models on Google Cloud Vertex AI.
    """

    def __init__(
        self,
        model_config: ModelConfig,
        system_instruction: str,
        project_id: Optional[str] = None,
        location: str = "global",
        timeout: float = 10.0,
    ):
        """
        Initialize Anthropic provider.

        Args:
            model_config: Configuration for the model
            system_instruction: System instruction/prompt
            project_id: Google Cloud project ID
            location: Google Cloud location (default: "global")
            timeout: Request timeout in seconds
        """
        self.model_config = model_config
        self.system_instruction = system_instruction
        self.project_id = project_id
        self.location = location
        self.timeout = timeout
        self._tools = None
        self._history = []
        self._last_input_tokens = 0  # Track input tokens from latest response
        self._last_output_tokens = 0  # Track output tokens from latest response

        # Initialize Anthropic Vertex client
        self._client = AnthropicVertex(
            region=location,
            project_id=project_id,
        )

    @property
    def model_name(self) -> str:
        """Get the current model name."""
        return self.model_config.name

    @property
    def provider_type(self) -> str:
        """Get the provider type."""
        return "anthropic"

    def is_anthropic_model(self) -> bool:
        """Check if current model is an Anthropic (Claude) model."""
        return True  # AnthropicProvider is always for Anthropic models

    def initialize_chat(
        self, history: List[types.Content], tools: Optional[List[Any]] = None
    ) -> None:
        """
        Initialize or reinitialize the chat session.

        Args:
            history: Initial conversation history
            tools: Optional tools available to the model
        """
        self._tools = tools
        self._history = history or []

    def _convert_history_to_anthropic_format(
        self, history: List[types.Content]
    ) -> List[Dict[str, Any]]:
        """
        Convert google.genai.types.Content history to Anthropic message format.

        Args:
            history: History in google.genai Content format

        Returns:
            List of messages in Anthropic format
        """
        messages = []
        # Track tool_use IDs for matching with tool_results
        # Map: function_name -> list of generated IDs (FIFO queue)
        tool_use_id_map = {}

        for item in history:
            # Convert role to Anthropic format
            # In Gemini: function responses have role="function"
            # In Anthropic: tool results must have role="user"
            if item.role == "function":
                role = "user"
            elif item.role == "user":
                role = "user"
            else:
                role = "assistant"

            # Extract text and tool calls from parts
            content_parts = []

            for part in item.parts:
                if hasattr(part, "text") and part.text:
                    content_parts.append({"type": "text", "text": part.text})
                elif hasattr(part, "function_call") and part.function_call:
                    # Convert function call to Anthropic tool use format
                    # Use the actual tool_use id from Claude's response if available
                    tool_use_id = None
                    if hasattr(part.function_call, "id"):
                        tool_use_id = part.function_call.id
                    elif hasattr(part.function_call, "raw") and hasattr(part.function_call.raw, "id"):
                        tool_use_id = part.function_call.raw.id

                    # If no ID exists (e.g., from Gemini), generate a unique one for Claude
                    if not tool_use_id:
                        import uuid
                        tool_use_id = f"toolu_{uuid.uuid4().hex[:24]}"

                    # Store the ID for matching with function_response later
                    func_name = part.function_call.name
                    if func_name not in tool_use_id_map:
                        tool_use_id_map[func_name] = []
                    tool_use_id_map[func_name].append(tool_use_id)

                    content_parts.append({
                        "type": "tool_use",
                        "id": tool_use_id,
                        "name": part.function_call.name,
                        "input": dict(part.function_call.args),
                    })
                elif hasattr(part, "function_response") and part.function_response:
                    # Convert function response to Anthropic tool result format
                    # Use the actual tool_use_id that was stored with the function call
                    tool_use_id = None
                    if hasattr(part.function_response, "id"):
                        tool_use_id = part.function_response.id

                    # If no ID exists (e.g., from Gemini), get the matching ID from our map
                    if not tool_use_id:
                        func_name = part.function_response.name
                        if func_name in tool_use_id_map and tool_use_id_map[func_name]:
                            # Pop the first ID (FIFO order to match tool_use sequence)
                            tool_use_id = tool_use_id_map[func_name].pop(0)
                        else:
                            # Fallback: generate a new ID if we somehow don't have a match
                            import uuid
                            tool_use_id = f"toolu_{uuid.uuid4().hex[:24]}"

                    content_parts.append({
                        "type": "tool_result",
                        "tool_use_id": tool_use_id,
                        "content": str(part.function_response.response),
                    })

            # Only add message if it has content
            if content_parts:
                # If there's only one text part, use simple string format
                if len(content_parts) == 1 and content_parts[0].get("type") == "text":
                    messages.append({"role": role, "content": content_parts[0]["text"]})
                else:
                    messages.append({"role": role, "content": content_parts})

        return messages

    def _convert_tools_to_anthropic_format(
        self, tools: Optional[List[Any]] = None
    ) -> Optional[List[Dict[str, Any]]]:
        """
        Convert tools to Anthropic format.

        Args:
            tools: Tools in google.genai format

        Returns:
            Tools in Anthropic format or None
        """
        if not tools:
            return None

        anthropic_tools = []
        for tool in tools:
            anthropic_tools.append({
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.parameters,
            })

        return anthropic_tools

    async def send_message(
        self, message: str, history: List[types.Content], tools: Optional[List[Any]] = None
    ) -> ProviderResponse:
        """
        Send a message to Claude.

        Args:
            message: The message to send
            history: Current conversation history
            tools: Optional tools available to the model

        Returns:
            ProviderResponse with model output
        """
        # Update internal state
        if tools != self._tools:
            self._tools = tools
        self._history = history or []

        # Convert history to Anthropic format
        messages = self._convert_history_to_anthropic_format(history)

        # Add new message
        messages.append({"role": "user", "content": message})

        # Build request parameters
        request_params = {
            "model": self.model_config.name,
            "max_tokens": self.model_config.max_output_tokens or 8192,
            "messages": messages,
            "system": self.system_instruction,
        }

        if self.model_config.temperature is not None:
            request_params["temperature"] = self.model_config.temperature

        # Add tools if provided
        if tools:
            anthropic_tools = self._convert_tools_to_anthropic_format(tools)
            if anthropic_tools:
                request_params["tools"] = anthropic_tools

        # Send message with timeout
        response = await asyncio.wait_for(
            asyncio.to_thread(
                self._client.messages.create,
                **request_params
            ),
            timeout=self.timeout,
        )

        return self._parse_response(response, message)

    async def send_function_response(
        self, function_response_parts: List[Any], history: List[types.Content]
    ) -> ProviderResponse:
        """
        Send function execution results back to Claude.

        Args:
            function_response_parts: List of function response parts
            history: Current conversation history

        Returns:
            ProviderResponse with model's next response
        """
        self._history = history or []

        # Convert history to Anthropic format
        # The function_response_parts are already in the history, so we don't need to add them separately
        messages = self._convert_history_to_anthropic_format(history)

        # Build request parameters
        request_params = {
            "model": self.model_config.name,
            "max_tokens": self.model_config.max_output_tokens or 8192,
            "messages": messages,
            "system": self.system_instruction,
        }

        if self.model_config.temperature is not None:
            request_params["temperature"] = self.model_config.temperature

        # Add tools if we have them
        if self._tools:
            anthropic_tools = self._convert_tools_to_anthropic_format(self._tools)
            if anthropic_tools:
                request_params["tools"] = anthropic_tools

        # Send function responses with timeout
        response = await asyncio.wait_for(
            asyncio.to_thread(
                self._client.messages.create,
                **request_params
            ),
            timeout=self.timeout,
        )

        return self._parse_response(response)

    def _parse_response(self, response: Any, user_message: Optional[str] = None) -> ProviderResponse:
        """
        Parse Anthropic response into standardized ProviderResponse.

        Args:
            response: Raw response from Anthropic
            user_message: Optional user message that was sent

        Returns:
            Standardized ProviderResponse
        """
        text_parts = []
        function_calls = []
        finish_reason = None

        if response:
            # Extract finish reason
            if hasattr(response, "stop_reason"):
                finish_reason = response.stop_reason

            # Extract and track token usage from latest call
            if hasattr(response, "usage"):
                self._last_input_tokens = getattr(response.usage, "input_tokens", 0)
                self._last_output_tokens = getattr(response.usage, "output_tokens", 0)

            # Extract content
            if hasattr(response, "content"):
                for block in response.content:
                    # Extract text
                    if hasattr(block, "type") and block.type == "text":
                        if hasattr(block, "text"):
                            text_parts.append(block.text)

                    # Extract tool use (function calls)
                    elif hasattr(block, "type") and block.type == "tool_use":
                        function_calls.append({
                            "name": block.name,
                            "args": block.input,
                            "id": block.id,  # CRITICAL: Must preserve Claude's tool_use ID for matching tool_results
                            "raw": block,
                        })

        return ProviderResponse(
            text="\n".join(text_parts),
            function_calls=function_calls,
            raw_response=response,
            finish_reason=finish_reason,
        )

    def is_malformed_response(self, response: Any) -> bool:
        """
        Check if response is malformed.

        Args:
            response: Response to check

        Returns:
            True if response is malformed
        """
        # Anthropic responses don't have the same malformed states as Gemini
        # Check for basic response validity
        if not response:
            return True

        # Check if response has content
        if hasattr(response, "content") and response.content:
            return False

        # Check for error states
        if hasattr(response, "stop_reason") and response.stop_reason == "error":
            return True

        return False

    def count_tokens(
        self, messages: List[Dict[str, Any]], tools: Optional[List[Any]] = None
    ) -> int:
        """
        Count tokens based on actual usage from the latest response.

        This returns the total token count (input + output) from the most
        recent Claude API call.

        Args:
            messages: List of messages (not used, kept for interface compatibility)
            tools: Optional tools (not used, kept for interface compatibility)

        Returns:
            Total token count from latest API call (input_tokens + output_tokens)
        """
        return self._last_input_tokens + self._last_output_tokens

    def get_chat_history(self) -> List[types.Content]:
        """Get current chat history."""
        return self._history

    def get_last_input_tokens(self) -> int:
        """Get input tokens from the latest API call."""
        return self._last_input_tokens

    def get_last_output_tokens(self) -> int:
        """Get output tokens from the latest API call."""
        return self._last_output_tokens

    def update_system_instruction(
        self, new_instruction: str, history: List[types.Content]
    ) -> None:
        """
        Update system instruction and reinitialize chat.

        Args:
            new_instruction: New system instruction
            history: Current conversation history to preserve
        """
        self.system_instruction = new_instruction
        self.initialize_chat(history, self._tools)
