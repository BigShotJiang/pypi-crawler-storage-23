# Contributing to AI Agent Framework

Thank you for your interest in contributing to AI Agent Framework! This document provides guidelines and instructions for contributing.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [Contributing Guidelines](#contributing-guidelines)
- [Pull Request Process](#pull-request-process)
- [Coding Standards](#coding-standards)
- [Testing](#testing)
- [Documentation](#documentation)

## Code of Conduct

We are committed to providing a welcoming and inclusive environment. Please be respectful and constructive in all interactions.

## Getting Started

1. **Fork the repository** on GitHub
2. **Clone your fork** locally:
   ```bash
   git clone https://github.com/YOUR_USERNAME/emergence-ai-agent-framework.git
   cd emergence-ai-agent-framework
   ```
3. **Add upstream remote**:
   ```bash
   git remote add upstream https://github.com/emergence-ai/emergence-ai-agent-framework.git
   ```

## Development Setup

### Prerequisites

- Python 3.8 or higher
- pip and virtualenv
- Google Cloud account with Vertex AI enabled

### Installation

1. **Create a virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. **Install development dependencies**:
   ```bash
   pip install -e ".[dev]"
   ```

3. **Set up environment variables**:
   ```bash
   cp .env.example .env
   # Edit .env with your credentials
   ```

4. **Run tests to verify setup**:
   ```bash
   pytest tests/ -v
   ```

## Contributing Guidelines

### Types of Contributions

We welcome:
- **Bug fixes**: Fix issues in existing code
- **New features**: Add new capabilities (please discuss in an issue first)
- **Documentation**: Improve docs, add examples
- **Tests**: Add test coverage
- **Performance improvements**: Optimize existing code

### Before You Start

1. **Check existing issues** to avoid duplicate work
2. **Open an issue** for new features or major changes
3. **Discuss your approach** before investing significant time

## Pull Request Process

1. **Create a feature branch**:
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes**:
   - Follow coding standards (see below)
   - Add tests for new functionality
   - Update documentation as needed

3. **Run tests and linting**:
   ```bash
   pytest tests/ -v
   black src/ tests/
   mypy src/
   ```

4. **Commit your changes**:
   ```bash
   git add .
   git commit -m "Description of changes"
   ```

   Use clear commit messages:
   - `feat: Add new feature`
   - `fix: Fix bug in tool execution`
   - `docs: Update README`
   - `test: Add tests for agent fallback`

5. **Push to your fork**:
   ```bash
   git push origin feature/your-feature-name
   ```

6. **Open a Pull Request**:
   - Provide a clear description
   - Reference related issues
   - Ensure CI passes

## Coding Standards

### Python Style

- **Follow PEP 8** style guide
- **Use Black** for formatting (line length: 100)
- **Use type hints** for all function signatures
- **Use descriptive names** for variables and functions

### Tool Decorator

All tools MUST use the `@tool` decorator:

```python
from core.tools.decorators import tool

@tool(description="Clear description for LLM (min 10 chars)")
def my_tool(param: str) -> str:
    """Docstring for developers.

    Args:
        param: Description of parameter

    Returns:
        Description of return value
    """
    return f"Result: {param}"
```

### Code Organization

- **Keep functions focused**: Single responsibility principle
- **Avoid deep nesting**: Extract complex logic into functions
- **Use meaningful names**: Code should be self-documenting
- **Add comments sparingly**: Only for non-obvious logic

### Example Code

```python
from typing import Optional, List
from core.agent import Agent
from core.tools.decorators import tool
from config.settings import AgentConfig, ModelConfig

@tool(description="Add two numbers and return their sum")
def add_numbers(a: int, b: int) -> int:
    """Add two integers.

    Args:
        a: First number
        b: Second number

    Returns:
        Sum of a and b
    """
    return a + b

# Create agent
agent = Agent(
    name="math_agent",
    system_instruction="You are a helpful math assistant.",
    tools=[add_numbers],
    model_configs=[
        ModelConfig(name="gemini-2.5-flash", provider="gemini"),
    ],
    agent_config=AgentConfig(max_turns=10, verbose=True)
)
```

## Testing

### Writing Tests

- **Use pytest** for all tests
- **Test each feature** thoroughly
- **Include edge cases** and error conditions
- **Use descriptive test names**: `test_agent_falls_back_from_gemini_to_anthropic`

### Test Structure

```python
import pytest
from core.agent import Agent
from core.tools.decorators import tool
from config.settings import AgentConfig

class TestMyFeature:
    """Test suite for my feature."""

    @pytest.fixture
    def agent_config(self):
        return AgentConfig(max_turns=5, verbose=False)

    @pytest.mark.asyncio
    async def test_feature_works(self, agent_config):
        """Test that feature works as expected."""
        # Arrange
        @tool(description="Test tool")
        def test_tool(value: str) -> str:
            return f"Result: {value}"

        # Act
        agent = Agent(
            name="test_agent",
            tools=[test_tool],
            agent_config=agent_config
        )
        response = await agent.send_message("test")

        # Assert
        assert isinstance(response, str)
```

### Running Tests

```bash
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_agent_basic.py -v

# Run with coverage
pytest tests/ --cov=core --cov=config --cov=utils --cov-report=html

# Run specific test
pytest tests/test_agent_basic.py::TestAgentBasic::test_agent_creation -v
```

## Documentation

### Docstrings

Use Google-style docstrings:

```python
def function_name(param1: str, param2: int) -> bool:
    """Brief description of function.

    Longer description if needed.

    Args:
        param1: Description of param1
        param2: Description of param2

    Returns:
        Description of return value

    Raises:
        ValueError: When param1 is empty

    Example:
        >>> function_name("test", 42)
        True
    """
    pass
```

### README Updates

When adding features:
1. Update main README.md
2. Add usage examples
3. Update feature list
4. Add to table of contents if needed

## Questions?

- Open an issue for bugs or feature requests
- Contact: deepak@emergence.ai
- Check existing documentation in docs/

Thank you for contributing to AI Agent Framework!
