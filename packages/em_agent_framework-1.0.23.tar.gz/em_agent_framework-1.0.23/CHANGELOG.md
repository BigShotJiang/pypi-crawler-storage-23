# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.23] - 2026-02-21

### ⚠️ BREAKING CHANGES
- **Removed Automatic Tool Migration to Complementary**: Tools removed by `update_tools_func` are now **completely removed** by default
  - **Previous Behavior**: Removed tools were automatically moved to `complementary_tools`
  - **New Behavior**: Removed tools are completely removed (not in active OR complementary)
  - **Migration Guide**: If you want removed tools to remain available via `search_tool`, explicitly add them:
    ```python
    # In your update_tools_func
    def my_updater(history, current_tools):
        new_tools = [add, multiply]  # subtract removed
        return new_tools

    # After calling send_message, explicitly preserve removed tools
    agent.add_to_complementary(subtract)  # Now available via search_tool
    ```
  - **Rationale**: Automatic migration was too "magical" and cluttered `complementary_tools` with tools that might never be used again
  - **Affected Code**: Lines removed from `agent.py:414-422` and `agent.py:798-806`

### Added
- **New Method**: `agent.add_to_complementary(*tools)` - Explicitly add tools to `complementary_tools`
  - Use this when you want removed tools to remain available via `search_tool`
  - Example: `agent.add_to_complementary(multiply, divide)`
  - Tools in `complementary_tools` are not shown to the LLM but can be loaded dynamically
  - Prevents duplicates automatically

### Changed
- **Tool Cleanup**: Tools re-added to active tools are now automatically removed from `complementary_tools`
  - Prevents tools from existing in both lists simultaneously
  - Ensures cleaner tool management

### Fixed
- **Tool List Overlap**: Fixed potential issue where re-added tools could exist in both active and complementary lists

## [1.0.22] - 2026-02-21

### Fixed
- **CRITICAL: Executor Complementary Tools Sync**: Fixed removed tools not being properly synced to executor's `complementary_tool_names`
  - **Root Cause**: When `update_tools_func` removed tools and moved them to `complementary_tools`, the executor's `complementary_tool_names` set wasn't updated
  - **Impact**: Removed tools showed "Unknown function" error instead of helpful "Use search_tool to add it first" message
  - **Solution**: Now properly syncs `executor.complementary_tools` and `executor.complementary_tool_names` when tools are updated
  - **Lines Changed**: `agent.py:429-430` and `agent.py:818-819`
  - **Test Coverage**: Added `test_removed_tool_gives_search_tool_message` to verify proper error messaging

### Added
- **New Test**: `test_removed_tool_gives_search_tool_message` - Verifies that calling a removed tool gives the helpful error message: *"Complementary tool 'tool_name' not active. Use search_tool to add it first."*

### Changed
- **Executor Sync**: When `update_tools_func` updates tools, the executor now syncs three properties:
  - `executor.tools` - Active tools dict
  - `executor.complementary_tools` - List of complementary tools
  - `executor.complementary_tool_names` - Set of complementary tool names for fast lookup

## [1.0.21] - 2026-02-21

### Fixed
- **CRITICAL: Dynamic Tool Updates in Multi-Turn Conversations**: Fixed `update_tools_func` only being called once at the start of `send_message()`
  - **Root Cause**: `update_tools_func` was only called at the beginning of `send_message()`, not during the function calling loop
  - **Impact**: Tools could not be dynamically added/removed based on intermediate tool execution results within a single conversation turn
  - **Solution**: Now calls `update_tools_func` after each tool execution in the `_handle_function_calling_loop`
  - **Benefit**: Enables truly dynamic tool management based on conversation history and tool results
  - Example use case: Progressively add specialized tools as the conversation requires them (e.g., add multiply tool after add is used)

### Added
- **Automatic Tool Migration to Complementary Tools**: When `update_tools_func` removes tools from the active toolset, they are now automatically moved to `complementary_tools`
  - Prevents tool loss when dynamically managing toolsets
  - Removed tools can be reloaded later via `search_tool` if needed
  - Prevents duplicate entries in `complementary_tools`
  - Applied in both `send_message()` and `_handle_function_calling_loop()`

### Changed
- **Improved Tool Update Timing**: `update_tools_func` is now called:
  1. Once at the start of `send_message()` (before initial LLM call)
  2. After each tool execution in the function calling loop (with updated conversation history including tool results)
  - This allows tools to evolve based on the complete conversation context at each step

## [1.0.20] - 2026-02-02

### Added
- **Thinking Mode Support**: Added extended thinking/reasoning capabilities for both Claude and Gemini models
  - New `ModelConfig` parameters:
    - `thinking_budget`: For Claude and Gemini 2.5 - specify thinking token budget (min 1024 for Claude)
    - `thinking_level`: For Gemini 3 - specify "LOW" or "HIGH" thinking level (default: HIGH)
  - **Claude Implementation**:
    - Passes `thinking` parameter with `budget_tokens` to Anthropic API
    - Automatically strips thinking blocks from conversation history to prevent token accumulation
    - Thinking tokens billed as output tokens (one-time cost when generated)
    - **IMPORTANT**: Automatically sets `temperature=1` when thinking is enabled (required by Anthropic API)
  - **Gemini Implementation**:
    - Uses `thinking_level` for Gemini 3 models ("LOW" or "HIGH") via `ThinkingConfig`
    - Uses `thinking_budget` for Gemini 2.5 models (token budget, min 128) via `ThinkingConfig`
    - Thought signatures handled automatically by Google genai SDK
    - **Model Names**: Use `gemini-3-pro-preview`, `gemini-3-flash-preview`, `gemini-2.5-pro`, or `gemini-2.5-flash`
  - **Benefits**: Enables deeper reasoning on complex problems, better step-by-step thinking, improved accuracy on multi-step tasks
  - Test suite: `test_thinking_mode.py` includes 6 comprehensive tests for both providers

### Changed
- **Conversation History Management**: Thinking blocks and thought summaries are now automatically stripped from conversation history to prevent context window accumulation across multiple turns

## [1.0.19] - 2026-01-29

### Fixed
- **CRITICAL: Duplicate Tool Results for Claude**: Fixed error when LLM makes incorrect function calls
  - Error: `messages.48.content.1: each tool_use must have a single result. Found multiple tool_result blocks with id: toolu_vrtx_...`
  - Root cause: When deduplicating function calls, we were sending ALL results (including duplicates) to Claude
  - Claude matches tool results by ID and requires exactly ONE tool_result per tool_use
  - Gemini requires the number of function_response parts to match the number of function_call parts (positional matching)
  - Solution: For Claude/Anthropic models, send only UNIQUE function responses. For Gemini, send ALL responses
  - This prevents duplicate tool_result blocks with the same ID from being sent to Claude
  - Especially important when tool execution fails (e.g., missing required arguments)

- **CRITICAL: Claude to Gemini Fallback with Function Calls**: Fixed error when falling back from Claude to Gemini after Claude made function calls
  - Error: `400 INVALID_ARGUMENT: function call missing 'thought_signature'`
  - Root cause: The `_compress_history_for_gemini` method was defined but never called
  - When Claude makes function calls and we fall back to Gemini, Gemini receives Claude's function calls without the required `thought_signature` field
  - Solution: Call `_compress_history_for_gemini` in both `send_message` and `send_function_response` methods when current model is Gemini
  - The compression method detects incompatible function calls and summarizes the entire history into text that Gemini can process
  - This enables seamless cross-provider fallback even after function calling has started

## [1.0.18] - 2026-01-29

### Fixed
- **CRITICAL: Claude Multi-Round Tool Calls**: Fixed duplicate conversation history bug that prevented Claude from making multiple consecutive rounds of tool calls
  - Root cause: In agent.py `_handle_function_calling_loop`, we were adding the same model response to conversation history TWICE
  - Line 630 added the initial response, then line 762 added the next response after tool execution
  - On subsequent iterations, line 630 would re-add the response that was already added at line 762 in the previous turn
  - This created duplicate tool_use blocks in the conversation history without matching tool_result blocks
  - Solution: Only add model response to history on first iteration (line 630). Subsequent iterations already have their response added at line 762 from the previous turn
  - This fix enables Claude to successfully handle multi-round agentic workflows where each round requires tool calls

### Testing
- Added `test_claude_multi_round_tools.py` to verify Claude can successfully execute multiple consecutive rounds of tool calls
- Test validates: Round 1: add(5,3) → Round 2: multiply(result, 2) → Final answer: 16

## [1.0.17] - 2026-01-29

### Fixed
- **CRITICAL: Claude Sequential Tool Calls (ACTUAL ROOT CAUSE)**: Fixed the real bug causing "tool_use ids were found without tool_result blocks" errors
  - Root cause: In `anthropic_provider.py` _parse_response(), we were NOT extracting the `id` field from Claude's tool_use blocks
  - This meant function_calls had no IDs, so tool_results couldn't match them to tool_use blocks
  - Solution: Now properly extract `block.id` when parsing tool_use blocks (line 342)
  - This completes the fix started in v1.0.14, which addressed a secondary issue in conversation history storage

### Changed
- **Logging**: Removed verbose [ToolExecutor] debug logs that printed function name and parameters for cleaner output

## [1.0.16] - 2026-01-29

### Note
- Version not published to PyPI (superceded by 1.0.17)

## [1.0.15] - 2026-01-29

### Fixed
- **Version Reporting**: Fixed __version__.py to correctly show version 1.0.15 (was showing 1.0.4)

## [0.1.0] - 2025-01-XX

### Added
- Initial beta release of AI Agent Framework
- Multi-model support for Gemini and Anthropic via Vertex AI
- Automatic model fallback with seamless provider switching
- Parallel tool execution capability
- `@tool` decorator for LLM-friendly tool descriptions
- Context injection for passing data to tools without LLM overhead
- Dynamic tool loading and validation
- Group chat manager with intelligent routing
- Load instructions tool for dynamic system prompt updates
- Comprehensive test suite with cross-provider fallback tests
- Full type hint support (PEP 561)
- Apache 2.0 license

### Features
- **Agent Class**: Production-ready agent with retry logic and metrics
- **Tool System**: Mandatory `@tool` decorator with description validation
- **Multi-Model Fallback**: Automatic switching between Gemini and Anthropic
- **Context Injection**: Pass user data, DataFrames, etc. to tools without sending through LLM
- **Group Chat**: Multi-agent coordination with custom routing
- **Metrics Tracking**: Token usage, function calls, model switches, latency

### Documentation
- Comprehensive README with examples
- API documentation for all public classes
- Cross-provider fallback testing guide
- Tool decorator implementation guide
- PyPI readiness documentation

## [1.0.14] - 2026-01-29

### Fixed
- **CRITICAL: Claude Sequential Tool Calls**: Fixed bug where second and subsequent Claude tool calls would fail with "tool_use ids were found without tool_result blocks"
  - Root cause: When storing function responses to conversation history, we were creating them from `unique_results` which didn't have tool_use IDs
  - Solution: Now properly extract IDs from the first occurrence of each unique call via `duplicate_map`
  - This ensures every tool_use block has a matching tool_result block with the same ID
  - Added test case `test_claude_sequential_tool_calls.py` to prevent regression

### Changed
- **Logging**: Removed "Executing N function(s)" log line to reduce verbosity
  - Now only shows duplicate count if duplicates were removed
  - Tool calls are still shown with name and arguments

## [1.0.13] - 2026-01-29

### Fixed
- **Version Reporting**: Fixed `__version__.py` to correctly report version 1.0.13
  - Previous releases (1.0.11, 1.0.12) had stale version numbers in `__version__.py`
  - This ensures `import em_agent_framework; print(em_agent_framework.__version__)` shows the correct version

## [1.0.12] - 2026-01-29

### Fixed
- **Test Suite**: Fixed `test_multiple_context_fields` to ensure LLM includes tool output verbatim in response
  - Updated system instruction to be more explicit about including exact tool output
  - Test now passes reliably across all model providers

## [1.0.11] - 2026-01-29

### Added
- **Termination Condition Logging**: Comprehensive logging for conversation termination and progress tracking
  - Turn counter shows progress: `[Agent] 🔄 Turn 1/10`
  - No more function calls: `[Agent] ✓ No more function calls - conversation complete`
  - Termination condition met: `[Agent] ⛔ Termination condition met - stopping conversation`
  - Max turns reached: `[Agent] ⚠️ Maximum turns (10) reached - stopping conversation`
  - All termination logs only appear when `verbose=True`

## [1.0.10] - 2026-01-29

### Added
- **LLM Call Logging**: Log individual LLM calls to file with full conversation history when `verbose=True` and `log_llm_calls=True`
  - Shows system instruction, complete conversation history, and new message/function responses
  - Logs exactly what the LLM sees for each API call
  - Configurable log file path via `log_file_path` in AgentConfig
  - Useful for debugging and understanding agent behavior

### Fixed
- **Tool Call Deduplication API Compatibility**: Fixed Gemini error requiring matching function_call and function_response counts
  - Now sends ALL responses to LLM API (including duplicates) to satisfy Gemini's requirements
  - Stores only UNIQUE calls/responses in conversation history to keep it clean
  - Executes only unique calls to save costs
- **Test Suite**: Fixed `test_multiple_context_fields` assertion to be more robust with LLM summarization

### Improved
- **Tool Call/Response Formatting**: Enhanced visual formatting of tool execution logs
  - Clearer separation between tool calls and responses with borders
  - Numbered tool calls and responses for easy tracking
  - Better readability for multi-tool executions

## [1.0.9] - 2026-01-29

### Added
- **Tool Call Deduplication**: Automatically deduplicates identical tool calls to avoid redundant execution
  - When the agent makes multiple calls to the same tool with identical parameters, only one execution occurs
  - Results are reused for duplicate calls, reducing API costs and execution time
  - Only unique tool calls are stored in conversation history, keeping it clean and concise
  - Deduplication uses name + args signature matching with JSON serialization for consistent comparison
  - Example: 4 calls to `get_stock_price(symbol='AAPL')` → only 1 actual execution
  - Verbose logging shows: `Executing N unique function(s) (M duplicate(s) removed)`

## [1.0.8] - 2026-01-28

### Fixed
- **Critical: Gemini → Claude Fallback with Tool Calls**: Fixed error where tool_use blocks didn't have matching tool_result blocks when falling back from Gemini to Claude
  - Root cause: Function role messages (containing Gemini's tool results) were being skipped during history conversion
  - Solution: Convert function role messages to user role messages with tool_result blocks, matching Anthropic's expected format
  - Fixes error: `'tool_use' ids were found without 'tool_result' blocks immediately after: toolu_xxx`
- **Improved Error Logging**: Enhanced exception handler to show exception type even when error message is blank
  - Now shows: `[Agent] Error on LLM call (attempt 1/3): ValueError: <message>`
  - Added full stack trace for better debugging
  - Only prints when `verbose=True`

## [1.0.7] - 2026-01-28

### Fixed
- **Critical: Gemini thought_signature Preservation**: Fixed issue where Gemini models would fail on second and subsequent tool calls with "missing thought_signature" error
  - Root cause: When storing function calls in conversation history, we were creating new Part objects which stripped Gemini-specific metadata
  - Solution: Now preserve the complete raw Part object directly, maintaining all metadata including thought_signature
  - This fixes both normal Gemini usage and cross-provider fallback scenarios
  - All cross-provider fallback tests pass (9/9)

## [1.0.6] - 2026-01-28

### Added
- **Instruction File Status Logging on Startup**: Agent now logs whether an instruction file was provided or not when `verbose=True`
  - Shows instruction file path if provided
  - Shows "No instruction file provided" if not provided
  - Helps with debugging instruction library configuration issues

## [1.0.5] - 2026-01-28

### Added
- **Recursive Agent Calls**: Agents can now spawn sub-agents to handle subtasks in parallel
  - Added `parent_agent_id` field to Agent class to track agent hierarchy
  - Added `recursion_depth` field to track nesting level
  - Added `max_recursion_depth` configuration parameter (default: 2)
  - Created `recursive_agent_call` tool that allows agents to delegate subtasks
  - Sub-agent responses include metadata (agent_id, parent_agent_id, recursion_depth) for UI bundling
  - All agents automatically receive unique IDs via UUID
  - Opt-in via `enable_recursive_agents=True` in AgentConfig
- **Comprehensive Instruction Library Logging**: Enhanced logging for instruction file operations
  - Logs file size and character count when loading instruction library
  - Logs each instruction template with ID, description, and length
  - Logs instruction content when loaded via `load_instructions` tool
  - Shows what content is added to system prompt with character counts
  - Logs instruction file status on agent startup
- Comprehensive test suite for recursive agent functionality (9 tests in test_recursive_agent.py)
- Example demonstrating recursive agent usage (examples/recursive_agent_example.py)
- Documentation for recursive agent feature in README

### Changed
- AgentConfig now includes `enable_recursive_agents` parameter to control whether `recursive_agent_call` tool is added (default: False)
- AgentConfig now includes `max_recursion_depth` parameter (default: 2)
- Recursive agent functionality is now opt-in via `enable_recursive_agents=True` in AgentConfig

### Fixed
- **Gemini thought_signature Preservation**: Fixed critical bug where Gemini's thought_signature was lost during conversation history tracking
  - Now uses raw function_call parts for Gemini to preserve thought_signature and other metadata
  - Only uses FunctionCallWithId wrapper for Anthropic/Claude models
  - Prevents "function call missing thought_signature" errors with Gemini
- **Cross-Provider Fallback Tool Use ID Compatibility**: Fixed critical bug where Gemini-to-Claude fallback produced duplicate or missing tool_use IDs
  - Generated unique UUIDs for tool_use blocks that don't have IDs (from Gemini)
  - Implemented stateful ID tracking to match tool_use with corresponding tool_result blocks
  - Prevents "tool_use ids must be unique" errors during provider switches
  - Ensures seamless cross-provider fallback with tool calls
- **Claude Conversation History Tracking**: Fixed critical bug where function responses weren't being added to conversation history before sending to Claude
  - This caused Claude to reject parallel tool calls with "tool_use ids were found without tool_result blocks" errors
  - Function responses are now properly added to history before calling `send_function_response`
  - AnthropicProvider now relies on function responses being in history rather than adding them separately
  - Enables full Claude-only configurations with recursive agents and parallel tool execution
- **Enhanced Error Debugging**: Added full stack trace printing (`traceback.print_exc()`) to all error handlers when `verbose=True`
  - Better debugging for production issues
  - Stack traces now show complete error context

## [1.0.4] - 2026-01-24

### Changed
- Token counting now tracks only the latest API call instead of cumulative tokens
- Both AnthropicProvider and VertexAIProvider expose consistent token counting interfaces
- Added `get_last_input_tokens()` and `get_last_output_tokens()` methods to providers
- Simplified conversation.py by disabling automatic summarization based on token counting

### Added
- Comprehensive token counting tests (test_token_counting.py)
- Extended math agent tests with multiple model variants (Claude 4.5, Gemini 2.5, Gemini 2.0)
- Math instructions JSON file for testing dynamic instruction loading
- 17 new tests for model variants and instruction loading

## [1.0.3] - 2026-01-24

### Added
- Support for Claude Sonnet 4.5 model (claude-sonnet-4-5@20250929) via Vertex AI
- Claude Sonnet 4.5 model configuration and testing

### Planned for Future Releases
- Sphinx documentation
- GitHub Actions CI/CD
- Code coverage reporting
- Additional examples and tutorials
- Performance benchmarks
- Docker image

---

[0.1.0]: https://github.com/emergence-ai/emergence-ai-agent-framework/releases/tag/v0.1.0
