"""
AI-BOM Detectors Package.

This package contains pattern matching, model registry, and endpoint detection
functionality for identifying AI/LLM components in Python projects.
"""
