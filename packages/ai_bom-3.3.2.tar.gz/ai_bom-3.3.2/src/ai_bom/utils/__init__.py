"""Utility functions for AI BOM analysis."""
