"""Tests for TEI loop controller."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from tei_loop.models import (
    Dimension,
    DimensionScore,
    EvalResult,
    RunMode,
    TEIConfig,
    Trace,
    TraceStep,
)


def _mock_agent(query):
    return f"Response to: {query}"


def _make_eval_result(score=0.85, all_passed=True):
    dims = {}
    for d in Dimension:
        dims[d] = DimensionScore(
            dimension=d, score=score, passed=all_passed, threshold=0.7
        )
    return EvalResult(
        dimension_scores=dims,
        aggregate_score=score,
        all_passed=all_passed,
    )


@pytest.mark.asyncio
async def test_loop_init_with_defaults():
    with patch("tei_loop.loop.build_providers") as mock_build:
        mock_eval_llm = MagicMock()
        mock_improve_llm = MagicMock()
        mock_build.return_value = ("openai", mock_eval_llm, mock_improve_llm)

        from tei_loop import TEILoop
        loop = TEILoop(agent=_mock_agent, show_cost=False)
        assert loop.config.mode == RunMode.RUNTIME
        assert loop.config.max_retries == 3


@pytest.mark.asyncio
async def test_loop_evaluate_only():
    with patch("tei_loop.loop.build_providers") as mock_build, \
         patch("tei_loop.loop.run_and_trace") as mock_trace, \
         patch("tei_loop.loop.print_model_recommendation"):

        mock_eval_llm = MagicMock()
        mock_eval_llm.get_cost = MagicMock(return_value=0.01)
        mock_improve_llm = MagicMock()
        mock_improve_llm.get_cost = MagicMock(return_value=0.0)
        mock_build.return_value = ("openai", mock_eval_llm, mock_improve_llm)

        trace = Trace(
            agent_input="test",
            agent_output="response",
            steps=[TraceStep(name="run")],
        )
        mock_trace.return_value = trace

        from tei_loop import TEILoop
        loop = TEILoop(agent=_mock_agent, show_cost=False)

        with patch.object(loop, "_evaluator") as mock_evaluator_attr:
            loop._initialized = True
            loop._provider_name = "openai"
            loop._eval_llm = mock_eval_llm
            loop._improve_llm = mock_improve_llm

            from tei_loop.evaluator import TEIEvaluator
            mock_evaluator = MagicMock(spec=TEIEvaluator)
            mock_evaluator.evaluate = AsyncMock(return_value=_make_eval_result(0.85, True))
            loop._evaluator = mock_evaluator
            loop._improver = MagicMock()

            result = await loop.evaluate_only("test query")

            assert result.total_iterations == 1
            assert result.baseline_score == 0.85
            assert result.improvement_delta == 0.0


@pytest.mark.asyncio
async def test_loop_stops_when_near_optimal():
    """When score >= 0.95, TEI stops — no more improvement possible."""
    with patch("tei_loop.loop.build_providers") as mock_build, \
         patch("tei_loop.loop.run_and_trace") as mock_trace, \
         patch("tei_loop.loop.print_model_recommendation"):

        mock_eval_llm = MagicMock()
        mock_eval_llm.get_cost = MagicMock(return_value=0.01)
        mock_improve_llm = MagicMock()
        mock_improve_llm.get_cost = MagicMock(return_value=0.0)
        mock_build.return_value = ("openai", mock_eval_llm, mock_improve_llm)

        trace = Trace(agent_input="test", agent_output="good response")
        mock_trace.return_value = trace

        from tei_loop import TEILoop
        loop = TEILoop(agent=_mock_agent, max_retries=3, show_cost=False)
        loop._initialized = True
        loop._provider_name = "openai"
        loop._eval_llm = mock_eval_llm
        loop._improve_llm = mock_improve_llm

        from tei_loop.evaluator import TEIEvaluator
        mock_evaluator = MagicMock(spec=TEIEvaluator)
        mock_evaluator.evaluate = AsyncMock(return_value=_make_eval_result(0.96, True))
        loop._evaluator = mock_evaluator
        loop._improver = MagicMock()

        result = await loop.run("test query")

        assert result.total_iterations == 1
        assert result.converged is True


@pytest.mark.asyncio
async def test_development_mode_config():
    from tei_loop import TEILoop
    with patch("tei_loop.loop.build_providers"):
        loop = TEILoop(agent=_mock_agent, mode="development", show_cost=False)
        assert loop.config.mode == RunMode.DEVELOPMENT
