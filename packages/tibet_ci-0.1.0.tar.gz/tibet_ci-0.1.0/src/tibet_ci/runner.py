"""
Core pipeline runner for tibet-ci.

Runs a full CI pipeline with TIBET tokens per stage.
Each stage is auto-configured based on the detected project type.
"""

import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path

from .detector import detect_project, ProjectInfo
from .provenance import CIProvenance


@dataclass
class StageResult:
    """
    Result of a single pipeline stage.

    Contains the command that was run, its exit code, duration,
    and the TIBET token ID linking it to the provenance chain.
    """
    name: str
    command: str
    exit_code: int
    output_summary: str
    duration_ms: float
    tibet_token_id: str
    passed: bool

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "command": self.command,
            "exit_code": self.exit_code,
            "output_summary": self.output_summary,
            "duration_ms": round(self.duration_ms, 1),
            "tibet_token_id": self.tibet_token_id,
            "passed": self.passed,
        }


@dataclass
class PipelineResult:
    """
    Result of a full pipeline run.

    Contains all stage results, timing, pass/fail counts,
    the TIBET chain checksum, and the badge status.
    """
    stages: list[StageResult] = field(default_factory=list)
    total_time: float = 0.0
    passed: int = 0
    failed: int = 0
    checksum: str = ""
    tibet_chain_length: int = 0
    badge_status: str = "UNKNOWN"  # PASSING, FAILING, WARNING

    def to_dict(self) -> dict:
        return {
            "stages": [s.to_dict() for s in self.stages],
            "total_time_ms": round(self.total_time, 1),
            "passed": self.passed,
            "failed": self.failed,
            "checksum": self.checksum,
            "tibet_chain_length": self.tibet_chain_length,
            "badge_status": self.badge_status,
        }


# The default stage order for a full pipeline run.
DEFAULT_STAGES = [
    "detect",
    "install_deps",
    "lint",
    "test",
    "audit",
    "build",
    "report",
]


def _compute_badge_status(passed: int, failed: int) -> str:
    """Determine badge status from pass/fail counts."""
    if failed == 0:
        return "PASSING"
    if failed <= 1 and passed > 0:
        return "WARNING"
    return "FAILING"


class PipelineRunner:
    """
    Runs a CI pipeline with TIBET provenance on every stage.

    Usage::

        runner = PipelineRunner()
        result = runner.run(".")
        print(result.badge_status)  # "PASSING"
    """

    def __init__(self, actor: str = "tibet-ci"):
        self.provenance = CIProvenance(actor=actor)
        self._project: ProjectInfo | None = None

    @property
    def platform(self) -> str:
        """The detected CI platform."""
        return self.provenance.platform

    def run(
        self,
        path: str | Path = ".",
        stages: list[str] | None = None,
    ) -> PipelineResult:
        """
        Run the full CI pipeline at the given path.

        Args:
            path: Project root directory.
            stages: List of stage names to run. If None, runs all defaults.

        Returns:
            PipelineResult with all stage results and the TIBET chain.
        """
        root = Path(path).resolve()
        stage_list = stages or DEFAULT_STAGES

        # Reset provenance for this run
        self.provenance = CIProvenance(actor=self.provenance.actor)

        result = PipelineResult()
        pipeline_start = time.monotonic()

        for stage_name in stage_list:
            stage_fn = self._get_stage_function(stage_name)
            if stage_fn is None:
                continue

            stage_result = stage_fn(root)
            result.stages.append(stage_result)

            if stage_result.passed:
                result.passed += 1
            else:
                result.failed += 1

        result.total_time = (time.monotonic() - pipeline_start) * 1000
        result.tibet_chain_length = len(self.provenance.tokens)
        result.checksum = self.provenance.chain_checksum()
        result.badge_status = _compute_badge_status(result.passed, result.failed)

        return result

    def _get_stage_function(self, name: str):
        """Map stage name to its runner method."""
        mapping = {
            "detect": self._stage_detect,
            "install_deps": self._stage_install_deps,
            "lint": self._stage_lint,
            "test": self._stage_test,
            "audit": self._stage_audit,
            "build": self._stage_build,
            "report": self._stage_report,
        }
        return mapping.get(name)

    def _run_command(self, command: str, cwd: Path, timeout: int = 300) -> tuple[int, str]:
        """
        Execute a shell command and return (exit_code, output).

        Output is truncated to 4096 characters for token storage.
        """
        try:
            proc = subprocess.run(
                command,
                shell=True,
                cwd=str(cwd),
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            output = (proc.stdout + proc.stderr).strip()
            # Truncate for token storage
            if len(output) > 4096:
                output = output[:4096] + "\n... (truncated)"
            return proc.returncode, output
        except subprocess.TimeoutExpired:
            return 124, f"Command timed out after {timeout}s: {command}"
        except FileNotFoundError:
            return 127, f"Command not found: {command}"
        except Exception as exc:
            return 1, f"Error executing command: {exc}"

    def _make_stage_result(
        self,
        name: str,
        command: str,
        exit_code: int,
        output: str,
        duration_ms: float,
    ) -> StageResult:
        """Create a StageResult and record a TIBET token."""
        passed = exit_code == 0
        token = self.provenance.create_token(
            stage_name=name,
            command=command,
            exit_code=exit_code,
            output_summary=output[:512],
        )
        return StageResult(
            name=name,
            command=command,
            exit_code=exit_code,
            output_summary=output[:512],
            duration_ms=duration_ms,
            tibet_token_id=token.token_id,
            passed=passed,
        )

    # --- Individual stage implementations ---

    def _stage_detect(self, root: Path) -> StageResult:
        """Detect project type."""
        start = time.monotonic()
        self._project = detect_project(root)
        duration = (time.monotonic() - start) * 1000

        info = self._project
        output = (
            f"language={info.language}, build_tool={info.build_tool}, "
            f"test={info.test_command}, lint={info.lint_command}, "
            f"files={info.config_files}"
        )
        command = f"tibet-ci detect {root}"

        return self._make_stage_result("detect", command, 0, output, duration)

    def _stage_install_deps(self, root: Path) -> StageResult:
        """Install project dependencies."""
        if self._project is None:
            self._project = detect_project(root)

        commands = {
            "python": "pip install -e '.[dev]' 2>&1 || pip install -e . 2>&1",
            "node": "npm ci 2>&1 || npm install 2>&1",
            "rust": "cargo fetch 2>&1",
            "go": "go mod download 2>&1",
            "java": "mvn dependency:resolve 2>&1" if self._project.build_tool == "maven"
                    else "gradle dependencies 2>&1",
        }
        command = commands.get(self._project.language, "echo 'No dependency install needed'")

        start = time.monotonic()
        exit_code, output = self._run_command(command, root)
        duration = (time.monotonic() - start) * 1000

        return self._make_stage_result("install_deps", command, exit_code, output, duration)

    def _stage_lint(self, root: Path) -> StageResult:
        """Run linter."""
        if self._project is None:
            self._project = detect_project(root)

        command = self._project.lint_command or "echo 'No linter configured'"

        start = time.monotonic()
        exit_code, output = self._run_command(command, root)
        duration = (time.monotonic() - start) * 1000

        return self._make_stage_result("lint", command, exit_code, output, duration)

    def _stage_test(self, root: Path) -> StageResult:
        """Run tests."""
        if self._project is None:
            self._project = detect_project(root)

        command = self._project.test_command or "echo 'No test command configured'"

        start = time.monotonic()
        exit_code, output = self._run_command(command, root)
        duration = (time.monotonic() - start) * 1000

        return self._make_stage_result("test", command, exit_code, output, duration)

    def _stage_audit(self, root: Path) -> StageResult:
        """Run TIBET compliance audit."""
        if self._project is None:
            self._project = detect_project(root)

        # Try tibet-pol if available, otherwise basic file checks
        audit_checks: list[str] = []
        exit_code = 0

        # Check for LICENSE
        if (root / "LICENSE").exists() or (root / "LICENSE.md").exists():
            audit_checks.append("LICENSE: found")
        else:
            audit_checks.append("LICENSE: MISSING")
            exit_code = 1

        # Check for README
        if (root / "README.md").exists() or (root / "README.rst").exists():
            audit_checks.append("README: found")
        else:
            audit_checks.append("README: MISSING")
            exit_code = 1

        # Check for config files
        if self._project.config_files:
            audit_checks.append(f"Config: {', '.join(self._project.config_files)}")
        else:
            audit_checks.append("Config: no project files found")
            exit_code = 1

        # Check for .gitignore
        if (root / ".gitignore").exists():
            audit_checks.append(".gitignore: found")
        else:
            audit_checks.append(".gitignore: missing (warning)")

        output = "\n".join(audit_checks)
        command = "tibet-ci audit (built-in)"
        duration = 0.1  # Near-instant for file checks

        return self._make_stage_result("audit", command, exit_code, output, duration)

    def _stage_build(self, root: Path) -> StageResult:
        """Build the project."""
        if self._project is None:
            self._project = detect_project(root)

        commands = {
            "python": "python -m build 2>&1 || echo 'build module not installed, skipping'",
            "node": "npm run build 2>&1 || echo 'no build script, skipping'",
            "rust": "cargo build --release 2>&1",
            "go": "go build ./... 2>&1",
            "java": "mvn package -DskipTests 2>&1" if self._project.build_tool == "maven"
                    else "gradle build -x test 2>&1",
        }
        command = commands.get(self._project.language, "echo 'No build command for this project'")

        start = time.monotonic()
        exit_code, output = self._run_command(command, root)
        duration = (time.monotonic() - start) * 1000

        return self._make_stage_result("build", command, exit_code, output, duration)

    def _stage_report(self, root: Path) -> StageResult:
        """Generate final report with badge and checksum."""
        start = time.monotonic()

        chain = self.provenance.chain()
        passed_stages = sum(
            1 for t in chain
            if t.get("erin", {}).get("exit_code", 1) == 0
        )
        total_stages = len(chain)
        checksum = self.provenance.chain_checksum()

        badge = _compute_badge_status(
            passed_stages,
            total_stages - passed_stages,
        )

        lines = [
            f"TIBET CI Report",
            f"  Platform:   {self.provenance.platform}",
            f"  Stages:     {passed_stages}/{total_stages} passed",
            f"  Badge:      {badge}",
            f"  Checksum:   {checksum}",
            f"  Chain:      {total_stages} tokens",
        ]
        output = "\n".join(lines)
        duration = (time.monotonic() - start) * 1000

        # Report always passes — it's informational
        return self._make_stage_result("report", "tibet-ci report (built-in)", 0, output, duration)
