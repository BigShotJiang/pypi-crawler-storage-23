"""
TIBET provenance for CI/CD pipeline stages.

Every stage in the pipeline — detect, lint, test, build — gets a
TIBET token. The chain of tokens IS the audit trail. When someone
asks "what ran in build #4217?" the TIBET chain proves it.
"""

import hashlib
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class CIToken:
    """
    A single TIBET token for one CI pipeline stage.

    The four TIBET layers:
    - ERIN: What ran (stage name, command, exit code, output hash)
    - ERAAN: What came before (previous stage token, dependencies)
    - EROMHEEN: Where it ran (CI platform, runner, commit, branch)
    - ERACHTER: Why it ran (intent: "CI pipeline stage: {name}")
    """
    token_id: str
    timestamp: str
    stage_name: str
    erin: dict = field(default_factory=dict)
    eraan: dict = field(default_factory=dict)
    eromheen: dict = field(default_factory=dict)
    erachter: dict = field(default_factory=dict)
    parent_id: Optional[str] = None
    content_hash: str = ""

    def to_dict(self) -> dict:
        return {
            "token_id": self.token_id,
            "timestamp": self.timestamp,
            "type": "ci_stage",
            "stage_name": self.stage_name,
            "erin": self.erin,
            "eraan": self.eraan,
            "eromheen": self.eromheen,
            "erachter": self.erachter,
            "parent_id": self.parent_id,
            "content_hash": self.content_hash,
        }


def _detect_ci_platform() -> str:
    """Detect which CI platform we're running on."""
    if os.environ.get("GITHUB_ACTIONS"):
        return "github-actions"
    if os.environ.get("GITLAB_CI"):
        return "gitlab-ci"
    if os.environ.get("BITBUCKET_PIPELINES"):
        return "bitbucket-pipelines"
    if os.environ.get("JENKINS_URL"):
        return "jenkins"
    return "local"


def _detect_ci_environment() -> dict:
    """Gather CI environment details from environment variables."""
    platform = _detect_ci_platform()
    env: dict = {
        "platform": platform,
        "runner": os.uname().nodename,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    if platform == "github-actions":
        env["commit_sha"] = os.environ.get("GITHUB_SHA", "")
        env["branch"] = os.environ.get("GITHUB_REF_NAME", "")
        env["repository"] = os.environ.get("GITHUB_REPOSITORY", "")
        env["run_id"] = os.environ.get("GITHUB_RUN_ID", "")
        env["actor"] = os.environ.get("GITHUB_ACTOR", "")
    elif platform == "gitlab-ci":
        env["commit_sha"] = os.environ.get("CI_COMMIT_SHA", "")
        env["branch"] = os.environ.get("CI_COMMIT_BRANCH", "")
        env["repository"] = os.environ.get("CI_PROJECT_PATH", "")
        env["run_id"] = os.environ.get("CI_PIPELINE_ID", "")
        env["actor"] = os.environ.get("GITLAB_USER_LOGIN", "")
    elif platform == "bitbucket-pipelines":
        env["commit_sha"] = os.environ.get("BITBUCKET_COMMIT", "")
        env["branch"] = os.environ.get("BITBUCKET_BRANCH", "")
        env["repository"] = os.environ.get("BITBUCKET_REPO_FULL_NAME", "")
        env["run_id"] = os.environ.get("BITBUCKET_BUILD_NUMBER", "")
    elif platform == "jenkins":
        env["commit_sha"] = os.environ.get("GIT_COMMIT", "")
        env["branch"] = os.environ.get("GIT_BRANCH", "")
        env["run_id"] = os.environ.get("BUILD_NUMBER", "")
        env["job_name"] = os.environ.get("JOB_NAME", "")
    else:
        # Local — try git for commit info
        env["commit_sha"] = ""
        env["branch"] = ""

    return env


class CIProvenance:
    """
    Manages the TIBET provenance chain for a CI pipeline run.

    Each stage creates a token. Tokens are chained via parent_id.
    The full chain represents the complete audit trail for one build.
    """

    def __init__(self, actor: str = "tibet-ci"):
        self.actor = actor
        self.tokens: list[CIToken] = []
        self._last_id: str | None = None
        self._ci_env: dict = _detect_ci_environment()

    @property
    def platform(self) -> str:
        """The detected CI platform."""
        return self._ci_env.get("platform", "local")

    def create_token(
        self,
        stage_name: str,
        command: str,
        exit_code: int,
        output_summary: str = "",
        dependencies: list[str] | None = None,
    ) -> CIToken:
        """
        Create a TIBET token for one pipeline stage.

        Args:
            stage_name: Name of the stage (detect, lint, test, etc.)
            command: The command that was executed
            exit_code: Process exit code (0 = success)
            output_summary: Truncated output for the token
            dependencies: List of dependency identifiers

        Returns:
            CIToken with all four TIBET layers populated.
        """
        now = datetime.now(timezone.utc).isoformat()

        # Hash the output for integrity
        output_hash = hashlib.sha256(output_summary.encode()).hexdigest()[:32]

        # ERIN — what ran
        erin = {
            "stage": stage_name,
            "command": command,
            "exit_code": exit_code,
            "output_hash": output_hash,
            "jis": f"jis:ci:{stage_name}",
        }

        # ERAAN — what came before
        eraan = {
            "parent_token": self._last_id,
            "dependencies": dependencies or [],
            "chain_position": len(self.tokens),
        }

        # EROMHEEN — where it ran
        eromheen = dict(self._ci_env)
        eromheen["actor"] = self.actor

        # ERACHTER — why it ran
        erachter = {
            "intent": f"CI pipeline stage: {stage_name}",
            "pipeline_jis": "jis:ci:pipeline",
            "stage_jis": f"jis:ci:{stage_name}",
        }

        # Generate token ID and content hash
        token_id = hashlib.sha256(
            f"{stage_name}:{command}:{now}".encode()
        ).hexdigest()[:16]

        content = json.dumps({"erin": erin}, sort_keys=True)
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:32]

        token = CIToken(
            token_id=token_id,
            timestamp=now,
            stage_name=stage_name,
            erin=erin,
            eraan=eraan,
            eromheen=eromheen,
            erachter=erachter,
            parent_id=self._last_id,
            content_hash=content_hash,
        )

        self.tokens.append(token)
        self._last_id = token.token_id
        return token

    def chain(self) -> list[dict]:
        """Return the full token chain as a list of dicts."""
        return [t.to_dict() for t in self.tokens]

    def chain_checksum(self) -> str:
        """
        Compute a checksum over the entire token chain.

        This is the integrity proof for the whole pipeline run.
        """
        chain_data = json.dumps(self.chain(), sort_keys=True)
        return hashlib.sha256(chain_data.encode()).hexdigest()[:16]
