"""
tibet-ci — Zero-Config CI/CD TIBET Integration
===============================================

One line to audit your entire pipeline.
Auto-detects your project, runs the right tools, and wraps every
pipeline stage in a TIBET provenance chain.

Python? Node? Rust? Go? Java? tibet-ci knows what to do.

Usage::

    from tibet_ci import PipelineRunner, detect_project

    info = detect_project(".")
    runner = PipelineRunner()
    result = runner.run(".")

    if result.badge_status == "PASSING":
        print(f"All {len(result.stages)} stages passed")

Authors: J. van de Meent & R. AI (Root AI)
License: MIT — Humotica AI Lab 2025-2026
"""

from .detector import detect_project, ProjectInfo
from .runner import PipelineRunner, PipelineResult, StageResult
from .provenance import CIProvenance, CIToken

__version__ = "0.1.0"

__all__ = [
    "PipelineRunner",
    "PipelineResult",
    "StageResult",
    "CIProvenance",
    "CIToken",
    "ProjectInfo",
    "detect_project",
]
