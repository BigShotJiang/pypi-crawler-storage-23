"""
Project auto-detection for CI pipelines.

Scans a directory for known project files and determines the
language, build tool, test runner, and linter. Supports Python,
Node, Rust, Go, and Java out of the box.
"""

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ProjectInfo:
    """
    Everything tibet-ci knows about a detected project.

    Populated by scanning for config files (pyproject.toml, package.json,
    Cargo.toml, go.mod, pom.xml, build.gradle).
    """
    language: str  # python, node, rust, go, java, unknown
    build_tool: str  # pip, hatch, npm, yarn, cargo, go, maven, gradle, unknown
    test_command: str  # pytest, npm test, cargo test, etc.
    lint_command: str  # ruff check ., npx eslint ., etc.
    package_manager: str  # pip, npm, yarn, cargo, go, mvn, gradle
    source_dir: str  # src/, lib/, ., etc.
    config_files: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "language": self.language,
            "build_tool": self.build_tool,
            "test_command": self.test_command,
            "lint_command": self.lint_command,
            "package_manager": self.package_manager,
            "source_dir": self.source_dir,
            "config_files": self.config_files,
        }


def detect_project(path: str | Path = ".") -> ProjectInfo:
    """
    Auto-detect the project type at the given path.

    Looks for known config files and returns a ProjectInfo with
    the appropriate language, build tool, test command, and linter.

    Args:
        path: Directory to scan. Defaults to current directory.

    Returns:
        ProjectInfo describing the detected project.
    """
    root = Path(path).resolve()
    found_files: list[str] = []

    # Define detection rules: (filename, detector_function)
    detectors = [
        ("pyproject.toml", _detect_python_pyproject),
        ("setup.py", _detect_python_setup),
        ("package.json", _detect_node),
        ("Cargo.toml", _detect_rust),
        ("go.mod", _detect_go),
        ("pom.xml", _detect_java_maven),
        ("build.gradle", _detect_java_gradle),
        ("build.gradle.kts", _detect_java_gradle),
    ]

    # Scan for config files
    for filename, _ in detectors:
        if (root / filename).exists():
            found_files.append(filename)

    # Use the first matching detector
    for filename, detector_fn in detectors:
        if (root / filename).exists():
            info = detector_fn(root)
            info.config_files = found_files
            return info

    # Nothing found — unknown project
    return ProjectInfo(
        language="unknown",
        build_tool="unknown",
        test_command="",
        lint_command="",
        package_manager="unknown",
        source_dir=".",
        config_files=found_files,
    )


def _detect_python_pyproject(root: Path) -> ProjectInfo:
    """Detect Python project with pyproject.toml."""
    pyproject = root / "pyproject.toml"
    content = pyproject.read_text(encoding="utf-8")

    # Determine build tool
    build_tool = "pip"
    if "hatchling" in content or "hatch" in content:
        build_tool = "hatch"
    elif "setuptools" in content:
        build_tool = "setuptools"
    elif "poetry" in content:
        build_tool = "poetry"
    elif "flit" in content:
        build_tool = "flit"

    # Determine source directory
    source_dir = "src" if (root / "src").is_dir() else "."

    # Determine package manager
    package_manager = "pip"
    if build_tool == "poetry":
        package_manager = "poetry"

    return ProjectInfo(
        language="python",
        build_tool=build_tool,
        test_command="pytest",
        lint_command="ruff check .",
        package_manager=package_manager,
        source_dir=source_dir,
    )


def _detect_python_setup(root: Path) -> ProjectInfo:
    """Detect Python project with setup.py (legacy)."""
    source_dir = "src" if (root / "src").is_dir() else "."

    return ProjectInfo(
        language="python",
        build_tool="setuptools",
        test_command="pytest",
        lint_command="ruff check .",
        package_manager="pip",
        source_dir=source_dir,
    )


def _detect_node(root: Path) -> ProjectInfo:
    """Detect Node.js project with package.json."""
    pkg_json = root / "package.json"
    content = pkg_json.read_text(encoding="utf-8")

    # Detect yarn
    package_manager = "npm"
    if (root / "yarn.lock").exists():
        package_manager = "yarn"
    elif (root / "pnpm-lock.yaml").exists():
        package_manager = "pnpm"

    # Detect source directory
    source_dir = "src" if (root / "src").is_dir() else "."

    # Detect test command
    test_command = "npm test"
    if package_manager == "yarn":
        test_command = "yarn test"
    elif package_manager == "pnpm":
        test_command = "pnpm test"

    # Detect lint command — check for eslint config
    lint_command = "npx eslint ."
    if (root / "biome.json").exists():
        lint_command = "npx biome check ."

    return ProjectInfo(
        language="node",
        build_tool=package_manager,
        test_command=test_command,
        lint_command=lint_command,
        package_manager=package_manager,
        source_dir=source_dir,
    )


def _detect_rust(root: Path) -> ProjectInfo:
    """Detect Rust project with Cargo.toml."""
    source_dir = "src" if (root / "src").is_dir() else "."

    return ProjectInfo(
        language="rust",
        build_tool="cargo",
        test_command="cargo test",
        lint_command="cargo clippy -- -D warnings",
        package_manager="cargo",
        source_dir=source_dir,
    )


def _detect_go(root: Path) -> ProjectInfo:
    """Detect Go project with go.mod."""
    return ProjectInfo(
        language="go",
        build_tool="go",
        test_command="go test ./...",
        lint_command="go vet ./...",
        package_manager="go",
        source_dir=".",
    )


def _detect_java_maven(root: Path) -> ProjectInfo:
    """Detect Java project with pom.xml (Maven)."""
    source_dir = "src/main/java" if (root / "src" / "main" / "java").is_dir() else "src"

    return ProjectInfo(
        language="java",
        build_tool="maven",
        test_command="mvn test",
        lint_command="mvn checkstyle:check",
        package_manager="mvn",
        source_dir=source_dir,
    )


def _detect_java_gradle(root: Path) -> ProjectInfo:
    """Detect Java project with build.gradle (Gradle)."""
    source_dir = "src/main/java" if (root / "src" / "main" / "java").is_dir() else "src"

    return ProjectInfo(
        language="java",
        build_tool="gradle",
        test_command="gradle test",
        lint_command="gradle check",
        package_manager="gradle",
        source_dir=source_dir,
    )
