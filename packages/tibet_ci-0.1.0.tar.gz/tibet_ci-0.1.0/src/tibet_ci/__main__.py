"""Allow running tibet-ci as: python3 -m tibet_ci"""

from .cli import main

main()
