"""
tibet-ci CLI — Zero-Config CI/CD TIBET Integration.

Usage::

    tibet-ci info            Concept overview
    tibet-ci run [path]      Run full pipeline (auto-detect project)
    tibet-ci detect [path]   Detect project type only
    tibet-ci demo            Demo run with simulated project
    tibet-ci badge [path]    Generate badge status
"""

import argparse
import json
import sys
import tempfile
from pathlib import Path

from .detector import detect_project
from .runner import PipelineRunner, DEFAULT_STAGES


def cmd_info(args: argparse.Namespace) -> int:
    print()
    print("=" * 64)
    print("  TIBET-CI — Zero-Config CI/CD TIBET Integration")
    print("=" * 64)
    print()
    print("The CI/CD Multiplier:")
    print("  One line in your pipeline config — TIBET audits everything.")
    print()
    print("  # .github/workflows/tibet.yml")
    print("  - uses: humotica/tibet-ci@v1")
    print()
    print("How it works:")
    print("  1. DETECT   Auto-detect language, build tool, test runner")
    print("  2. INSTALL  Install dependencies (pip/npm/cargo/go mod)")
    print("  3. LINT     Run linter (ruff/eslint/clippy/vet)")
    print("  4. TEST     Run tests (pytest/jest/cargo test/go test)")
    print("  5. AUDIT    TIBET compliance audit")
    print("  6. BUILD    Build package/binary")
    print("  7. REPORT   Generate badge + checksum rapport")
    print()
    print("Every stage = TIBET token:")
    print()
    print("  +--------------------------------------------------+")
    print("  | ERIN      | What ran: command, exit code, hash    |")
    print("  | ERAAN     | Previous stage token, dependencies    |")
    print("  | EROMHEEN  | CI platform, runner, commit, branch   |")
    print("  | ERACHTER  | Intent: 'CI pipeline stage: {name}'  |")
    print("  +--------------------------------------------------+")
    print()
    print("Supported projects:")
    print("  Python    pyproject.toml / setup.py    pytest + ruff")
    print("  Node      package.json                 jest + eslint")
    print("  Rust      Cargo.toml                   cargo test + clippy")
    print("  Go        go.mod                       go test + go vet")
    print("  Java      pom.xml / build.gradle       mvn/gradle test")
    print()
    print("Supported CI platforms:")
    print("  GitHub Actions, GitLab CI, Bitbucket Pipelines, Jenkins")
    print()
    print("=" * 64)
    return 0


def cmd_detect(args: argparse.Namespace) -> int:
    path = args.path or "."
    info = detect_project(path)

    if args.json:
        print(json.dumps(info.to_dict(), indent=2))
    else:
        print()
        print(f"  Project Detection: {Path(path).resolve()}")
        print(f"  {'─' * 50}")
        print(f"  Language:        {info.language}")
        print(f"  Build tool:      {info.build_tool}")
        print(f"  Test command:    {info.test_command or '(none)'}")
        print(f"  Lint command:    {info.lint_command or '(none)'}")
        print(f"  Package manager: {info.package_manager}")
        print(f"  Source dir:      {info.source_dir}")
        print(f"  Config files:    {', '.join(info.config_files) or '(none)'}")
        print()

    return 0


def cmd_run(args: argparse.Namespace) -> int:
    path = args.path or "."
    stages = args.stages.split(",") if args.stages else None

    runner = PipelineRunner()
    result = runner.run(path, stages=stages)

    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
    else:
        print()
        print(f"  TIBET CI Pipeline — {Path(path).resolve()}")
        print(f"  Platform: {runner.platform}")
        print(f"  {'─' * 56}")
        print()

        for stage in result.stages:
            status = "PASS" if stage.passed else "FAIL"
            marker = "[+]" if stage.passed else "[X]"
            print(f"  {marker} {stage.name:<16} {status}  ({stage.duration_ms:.0f}ms)")
            if not stage.passed and stage.output_summary:
                # Show first line of failure output
                first_line = stage.output_summary.split("\n")[0][:60]
                print(f"      {first_line}")

        print()
        print(f"  {'─' * 56}")
        print(f"  Stages:     {result.passed} passed, {result.failed} failed")
        print(f"  Total time: {result.total_time:.0f}ms")
        print(f"  Badge:      {result.badge_status}")
        print(f"  Checksum:   {result.checksum}")
        print(f"  TIBET chain: {result.tibet_chain_length} tokens")
        print()

    return 0 if result.badge_status != "FAILING" else 1


def cmd_badge(args: argparse.Namespace) -> int:
    path = args.path or "."

    runner = PipelineRunner()
    # Run only detect + audit for quick badge
    result = runner.run(path, stages=["detect", "audit"])

    if args.json:
        data = {
            "badge_status": result.badge_status,
            "checksum": result.checksum,
            "passed": result.passed,
            "failed": result.failed,
        }
        print(json.dumps(data, indent=2))
    else:
        print()
        print(f"  TIBET Badge: {result.badge_status}")
        print(f"  Checksum:    {result.checksum}")
        print()

    return 0


def cmd_demo(args: argparse.Namespace) -> int:
    print()
    print("  TIBET CI Demo — Simulated Python Project")
    print("  " + "=" * 52)
    print()

    # Create a temporary project to demo against
    with tempfile.TemporaryDirectory(prefix="tibet-ci-demo-") as tmpdir:
        tmp = Path(tmpdir)

        # Create minimal Python project
        (tmp / "pyproject.toml").write_text(
            '[build-system]\nrequires = ["hatchling"]\n'
            'build-backend = "hatchling.build"\n\n'
            '[project]\nname = "demo-project"\nversion = "0.1.0"\n'
        )
        (tmp / "src").mkdir()
        (tmp / "src" / "demo.py").write_text(
            '"""Demo module."""\n\ndef hello() -> str:\n    return "Hello from TIBET CI"\n'
        )
        (tmp / "LICENSE").write_text("MIT License\n")
        (tmp / "README.md").write_text("# Demo Project\n")
        (tmp / ".gitignore").write_text("__pycache__/\n*.pyc\n")

        print("  Created simulated Python project:")
        print(f"    pyproject.toml  (hatchling)")
        print(f"    src/demo.py")
        print(f"    LICENSE, README.md, .gitignore")
        print()

        # Run detect stage
        info = detect_project(tmp)
        print(f"  [1/7] DETECT")
        print(f"    Language:  {info.language}")
        print(f"    Build:     {info.build_tool}")
        print(f"    Test:      {info.test_command}")
        print(f"    Lint:      {info.lint_command}")
        print()

        # Run full pipeline
        runner = PipelineRunner()
        result = runner.run(tmp, stages=["detect", "audit", "report"])

        print(f"  Running pipeline stages...")
        print()

        for stage in result.stages:
            status = "PASS" if stage.passed else "FAIL"
            marker = "[+]" if stage.passed else "[X]"
            print(f"  {marker} {stage.name:<16} {status}  ({stage.duration_ms:.1f}ms)")

        print()
        print(f"  {'─' * 52}")
        print(f"  Badge:      {result.badge_status}")
        print(f"  Checksum:   {result.checksum}")
        print(f"  Chain:      {result.tibet_chain_length} TIBET tokens")
        print()

        # Show one token as example
        if runner.provenance.tokens:
            token = runner.provenance.tokens[0]
            print(f"  Example TIBET Token (first stage):")
            print(f"    token_id:     {token.token_id}")
            print(f"    stage:        {token.stage_name}")
            print(f"    content_hash: {token.content_hash}")
            print(f"    ERIN:         jis:ci:{token.stage_name}")
            print(f"    ERAAN:        parent={token.parent_id or '(root)'}")
            print(f"    EROMHEEN:     platform={runner.platform}")
            print(f"    ERACHTER:     {token.erachter.get('intent', '')}")
            print()

    if args.json:
        print(json.dumps(result.to_dict(), indent=2))

    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="tibet-ci",
        description="Zero-Config CI/CD TIBET Integration",
    )
    parser.add_argument(
        "-j", "--json",
        action="store_true",
        default=False,
        help="Output as JSON",
    )

    sub = parser.add_subparsers(dest="command")

    # info
    sub.add_parser("info", help="Concept overview")

    # detect
    p_detect = sub.add_parser("detect", help="Detect project type")
    p_detect.add_argument("path", nargs="?", default=".", help="Project path")
    p_detect.add_argument("-j", "--json", action="store_true", default=False)

    # run
    p_run = sub.add_parser("run", help="Run full CI pipeline")
    p_run.add_argument("path", nargs="?", default=".", help="Project path")
    p_run.add_argument("-j", "--json", action="store_true", default=False)
    p_run.add_argument(
        "-s", "--stages",
        default=None,
        help=f"Comma-separated stages to run (default: all). "
             f"Available: {','.join(DEFAULT_STAGES)}",
    )

    # demo
    p_demo = sub.add_parser("demo", help="Demo run with simulated project")
    p_demo.add_argument("-j", "--json", action="store_true", default=False)

    # badge
    p_badge = sub.add_parser("badge", help="Generate badge status")
    p_badge.add_argument("path", nargs="?", default=".", help="Project path")
    p_badge.add_argument("-j", "--json", action="store_true", default=False)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    commands = {
        "info": cmd_info,
        "detect": cmd_detect,
        "run": cmd_run,
        "demo": cmd_demo,
        "badge": cmd_badge,
    }
    sys.exit(commands[args.command](args))
