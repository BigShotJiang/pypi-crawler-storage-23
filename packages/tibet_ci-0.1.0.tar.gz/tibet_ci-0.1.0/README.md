# tibet-ci — Zero-Config CI/CD TIBET Integration

> One line to audit your entire pipeline.
>
> Every stage is a TIBET token. Every build has provenance.

**tibet-ci** auto-detects your project, runs the right tools, and wraps every pipeline stage in a [TIBET](https://pypi.org/project/tibet-core/) provenance chain. Python? Node? Rust? Go? Java? tibet-ci knows what to do.

## The CI/CD Multiplier

One line in your pipeline config — TIBET audits everything:

```yaml
# .github/workflows/tibet.yml
name: TIBET CI
on: [push, pull_request]

jobs:
  tibet:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: humotica/tibet-ci@v1
```

That's it. tibet-ci will:

1. **Detect** your project type (Python, Node, Rust, Go, Java)
2. **Run** `tibet-pol` on pipeline steps (process integrity)
3. **Run** `tibet-audit` on compliance checks
4. **Run** `tibet-forge` on code quality
5. **Output** a TIBET badge + checksum rapport

## Pipeline Flow

```
  ┌────────────┐
  │   detect    │  Auto-detect language, build tool, test runner
  └─────┬──────┘
        │
  ┌─────▼──────┐
  │ install_deps│  Install dependencies (pip/npm/cargo/go mod)
  └─────┬──────┘
        │
  ┌─────▼──────┐
  │    lint     │  Run linter (ruff/eslint/clippy/vet)
  └─────┬──────┘
        │
  ┌─────▼──────┐
  │    test     │  Run tests (pytest/jest/cargo test/go test)
  └─────┬──────┘
        │
  ┌─────▼──────┐
  │   audit     │  TIBET compliance audit
  └─────┬──────┘
        │
  ┌─────▼──────┐
  │   build     │  Build package/binary
  └─────┬──────┘
        │
  ┌─────▼──────┐
  │   report    │  Generate badge + checksum rapport
  └─────┬──────┘
        │
  ┌─────▼──────┐
  │ TIBET Chain │  Every stage = token. Chain = audit trail.
  └────────────┘
```

Each stage produces a TIBET token with:

| Layer | Content |
|-------|---------|
| **ERIN** | What ran: stage name, command, exit code, output hash |
| **ERAAN** | Previous stage token, dependency chain |
| **EROMHEEN** | CI platform, runner, commit SHA, branch |
| **ERACHTER** | Intent: "CI pipeline stage: {name}" |

## Install

```bash
pip install tibet-ci
```

With optional integrations:

```bash
pip install tibet-ci[full]  # includes tibet-pol, tibet-audit, tibet-forge, rich
```

## CLI Usage

```bash
# Detect project type
tibet-ci detect .
# → Python (pyproject.toml), build_tool=hatch, test=pytest, lint=ruff

# Run full pipeline
tibet-ci run .
# → detect → install_deps → lint → test → audit → build → report
# → TIBET badge: PASSING (7/7 stages, checksum: a3f7c2...)

# Run specific stages only
tibet-ci run . --stages detect,lint,test

# Output as JSON
tibet-ci run . --json

# Generate badge status
tibet-ci badge .

# Demo run with simulated project
tibet-ci demo

# Concept overview
tibet-ci info
```

## Works With

| CI Platform | Detection |
|-------------|-----------|
| **GitHub Actions** | `GITHUB_ACTIONS` env var |
| **GitLab CI** | `GITLAB_CI` env var |
| **Bitbucket Pipelines** | `BITBUCKET_PIPELINES` env var |
| **Jenkins** | `JENKINS_URL` env var |
| **Local** | Fallback — works everywhere |

## Project Auto-Detection

| Files Found | Language | Build Tool | Test Command | Lint Command |
|------------|----------|------------|--------------|-------------|
| `pyproject.toml` / `setup.py` | Python | pip/hatch | `pytest` | `ruff check .` |
| `package.json` | Node | npm/yarn | `npm test` | `npx eslint .` |
| `Cargo.toml` | Rust | cargo | `cargo test` | `cargo clippy` |
| `go.mod` | Go | go | `go test ./...` | `go vet ./...` |
| `pom.xml` | Java | maven | `mvn test` | `mvn checkstyle:check` |
| `build.gradle` | Java | gradle | `gradle test` | `gradle check` |

## Python API

```python
from tibet_ci import PipelineRunner, detect_project

# Detect
info = detect_project(".")
print(info.language)    # "python"
print(info.build_tool)  # "hatch"
print(info.test_command) # "pytest"

# Run full pipeline
runner = PipelineRunner()
result = runner.run(".")
print(result.badge_status)  # "PASSING"
print(result.checksum)      # "a3f7c2b1..."

for stage in result.stages:
    status = "PASS" if stage.passed else "FAIL"
    print(f"  [{status}] {stage.name} ({stage.duration_ms}ms)")

# Run specific stages
result = runner.run(".", stages=["detect", "lint", "test"])
```

## Part of the TIBET Ecosystem

| Package | Purpose |
|---------|---------|
| [`tibet-core`](https://pypi.org/project/tibet-core/) | Protocol core |
| [`tibet-y2k38`](https://pypi.org/project/tibet-y2k38/) | Y2K38 Time Bridge |
| [`tibet-pol`](https://pypi.org/project/tibet-pol/) | Process Integrity Checker |
| [`tibet-pqc`](https://pypi.org/project/tibet-pqc/) | Post-Quantum Crypto Router |
| [`tibet-overlay`](https://pypi.org/project/tibet-overlay/) | Identity Overlay |
| [`tibet-twin`](https://pypi.org/project/tibet-twin/) | Digital Twin Guard |
| **tibet-ci** | CI/CD Multiplier |

## License

MIT — Humotica AI Lab 2025-2026

## Authors

- **J. van de Meent** — jasper@humotica.com
- **R. AI (Root AI)** — root_idd@humotica.nl
