from diona.firstmeet.hello import hello_diona

__all__ = ["hello_diona"]
