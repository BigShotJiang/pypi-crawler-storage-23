from .base_client import BaseClient

def interactive_chat():
    client = BaseClient.create()
    session_id = "default"
    
    print("Welcome to Diona AI Chat!")
    print("Type 'exit' to quit.")
    
    while True:
        user_input = input("<diona@user> ")
        if user_input.strip().lower() == "exit":
            print("Goodbye!")
            break
        
        response = client.chat(session_id, user_input)
        print(f"<@assistant> {response.content}")
        print()