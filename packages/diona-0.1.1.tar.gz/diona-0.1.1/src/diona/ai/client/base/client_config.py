import os
import yaml

class ClientConfig:
    def __init__(self):
        self.config = self._load_config()
        self.prompt_path = self._get_config_value('diona.ai.clientset.prompt')
        self.system_prompt = self._load_system_prompt()
    
    def _load_config(self):
        config_path = os.path.join(os.getcwd(), 'config.yml')
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        return {}
    
    def _get_config_value(self, key, default=None):
        keys = key.split('.')
        value = self.config
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        return value
    
    def _load_system_prompt(self):
        if self.prompt_path and os.path.exists(self.prompt_path):
            with open(self.prompt_path, 'r', encoding='utf-8') as f:
                return f.read().strip()
        return "You are a helpful assistant"
    
    def get_system_prompt(self):
        return self.system_prompt