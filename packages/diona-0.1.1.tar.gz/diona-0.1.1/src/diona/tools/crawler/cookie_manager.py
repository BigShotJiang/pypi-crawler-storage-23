import os
import json
import time
from typing import List, Dict, Any


class CookieManager:
    """通用Cookie管理类"""
    
    def __init__(self, base_cookie_path: str = None):
        """
        初始化Cookie管理器
        
        Args:
            base_cookie_path: cookie基础路径，默认使用当前目录
        """
        self.base_cookie_path = base_cookie_path or os.path.join(os.getcwd(), 'cookies')
        # 确保目录存在
        os.makedirs(self.base_cookie_path, exist_ok=True)
    
    def load_cookies(self, spider_name: str) -> List[Dict[str, Any]]:
        """
        加载保存的cookie
        
        Args:
            spider_name: 爬虫名称
            
        Returns:
            cookie列表
        """
        cookie_file = os.path.join(self.base_cookie_path, f"{spider_name}_cookies.json")
        
        if not os.path.exists(cookie_file):
            print(f"Cookie文件不存在: {cookie_file}")
            return []
        
        try:
            with open(cookie_file, 'r', encoding='utf-8') as f:
                cookies = json.load(f)
            
            # 检查cookie是否过期
            valid_cookies = []
            for cookie in cookies:
                if self._is_cookie_valid(cookie):
                    valid_cookies.append(cookie)
                else:
                    print(f"Cookie已过期: {cookie.get('name')}")
            
            print(f"成功加载 {len(valid_cookies)} 个cookie")
            return valid_cookies
        except Exception as e:
            print(f"加载cookie失败: {e}")
            return []
    
    def save_cookies(self, spider_name: str, cookies: List[Dict[str, Any]]) -> bool:
        """
        保存cookie
        
        Args:
            spider_name: 爬虫名称
            cookies: cookie列表
            
        Returns:
            是否保存成功
        """
        cookie_file = os.path.join(self.base_cookie_path, f"{spider_name}_cookies.json")
        
        try:
            # 过滤出有效的cookie
            valid_cookies = []
            for cookie in cookies:
                if self._is_cookie_valid(cookie):
                    valid_cookies.append(cookie)
            
            with open(cookie_file, 'w', encoding='utf-8') as f:
                json.dump(valid_cookies, f, ensure_ascii=False, indent=2)
            
            print(f"成功保存 {len(valid_cookies)} 个cookie到 {cookie_file}")
            return True
        except Exception as e:
            print(f"保存cookie失败: {e}")
            return False
    
    def _is_cookie_valid(self, cookie: Dict[str, Any]) -> bool:
        """
        检查cookie是否有效
        
        Args:
            cookie: cookie字典
            
        Returns:
            cookie是否有效
        """
        # 检查cookie是否有过期时间
        if 'expires' in cookie:
            try:
                # 检查cookie是否过期
                expires = float(cookie['expires'])
                current_time = time.time()
                if expires < current_time:
                    return False
            except ValueError:
                pass
        
        # 检查cookie是否有必要的字段
        required_fields = ['name', 'value', 'domain', 'path']
        for field in required_fields:
            if field not in cookie:
                return False
        
        return True