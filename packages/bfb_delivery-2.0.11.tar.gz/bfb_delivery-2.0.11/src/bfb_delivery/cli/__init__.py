"""CLI init. See :doc:`CLI` </CLI>."""
