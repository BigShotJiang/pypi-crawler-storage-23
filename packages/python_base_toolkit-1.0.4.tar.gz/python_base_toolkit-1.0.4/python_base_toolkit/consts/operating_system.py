class Platform:
    WINDOWS = "Windows"
    LINUX = "Linux"
    MACOS = "macOS"
