class FakeDatabaseError(Exception):
    pass
