"""Obra SaaS CLI utility functions."""

from obra.utils.terminal import is_headless

__all__ = ["is_headless"]
