"""
Typed constants for message template keys.

This module provides IDE autocomplete support for message keys.
Use these constants instead of raw strings to catch typos at development time.

Usage:
    from obra.messages import get_message
    from obra.messages.keys import Keys

    msg = get_message(Keys.RECOVERY_AUTH_LOGIN)

Note: This file is regenerated in Story 6 after all domains are complete.
"""


class Keys:
    """
    String constants for all message template keys.

    Naming convention: DOMAIN_CATEGORY_NAME
    Example: "recovery.auth.login" -> RECOVERY_AUTH_LOGIN
    """

    # ==========================================================================
    # Recovery Domain
    # ==========================================================================

    # Auth category
    RECOVERY_AUTH_LOGIN = "recovery.auth.login"
    RECOVERY_AUTH_SETUP = "recovery.auth.setup"
    RECOVERY_AUTH_TERMS = "recovery.auth.terms"

    # Session category
    RECOVERY_SESSION_RESUME = "recovery.session.resume"
    RECOVERY_SESSION_CONTINUE = "recovery.session.continue"
    RECOVERY_SESSION_REPAIR = "recovery.session.repair"
    RECOVERY_SESSION_FORCE_COMPLETE = "recovery.session.force_complete"
    RECOVERY_SESSION_RESET_REVIEW = "recovery.session.reset_review"
    RECOVERY_SESSION_SHOW = "recovery.session.show"

    # Config category
    RECOVERY_CONFIG_CONFIG = "recovery.config.config"
    RECOVERY_CONFIG_DOCTOR = "recovery.config.doctor"
    RECOVERY_CONFIG_LLM_SETUP = "recovery.config.llm_setup"

    # Network category
    RECOVERY_NETWORK_RETRY = "recovery.network.retry"
    RECOVERY_NETWORK_TIMEOUT = "recovery.network.timeout"
    RECOVERY_NETWORK_SERVER_ERROR = "recovery.network.server_error"

    # Execution category
    RECOVERY_EXECUTION_BREAKPOINT = "recovery.execution.breakpoint"
    RECOVERY_EXECUTION_STALLED = "recovery.execution.stalled"
    RECOVERY_EXECUTION_FAILED = "recovery.execution.failed"

    # ==========================================================================
    # Status Domain
    # ==========================================================================

    # Session category
    STATUS_SESSION_COMPLETE = "status.session.complete"
    STATUS_SESSION_ESCALATED = "status.session.escalated"
    STATUS_SESSION_PAUSED = "status.session.paused"
    STATUS_SESSION_FAILED = "status.session.failed"
    STATUS_SESSION_EXPIRED = "status.session.expired"
    STATUS_SESSION_ABANDONED = "status.session.abandoned"

    # Phase category
    STATUS_PHASE_DERIVATION = "status.phase.derivation"
    STATUS_PHASE_EXECUTION = "status.phase.execution"
    STATUS_PHASE_REFINEMENT = "status.phase.refinement"
    STATUS_PHASE_USERPLAN = "status.phase.userplan"

    # Celebration category
    STATUS_CELEBRATION_MISSION_COMPLETE = "status.celebration.mission_complete"

    # ==========================================================================
    # Progress Domain
    # ==========================================================================

    # Item category
    PROGRESS_ITEM_EXECUTING = "progress.item.executing"
    PROGRESS_ITEM_COMPLETE = "progress.item.complete"

    # Story category
    PROGRESS_STORY_COMPLETE = "progress.story.complete"

    # Epic category
    PROGRESS_EPIC_COMPLETE = "progress.epic.complete"

    # Fix category
    PROGRESS_FIX_SUMMARY = "progress.fix.summary"

    # Files category
    PROGRESS_FILES_SUMMARY = "progress.files.summary"

    # ==========================================================================
    # Error Domain
    # ==========================================================================

    # Session category
    ERROR_SESSION_NOT_FOUND = "error.session.not_found"
    ERROR_SESSION_EXPIRED = "error.session.expired"
    ERROR_SESSION_INVALID_STATE = "error.session.invalid_state"

    # Auth category
    ERROR_AUTH_EXPIRED = "error.auth.expired"
    ERROR_AUTH_REQUIRED = "error.auth.required"
    ERROR_AUTH_TERMS_NOT_ACCEPTED = "error.auth.terms_not_accepted"
    ERROR_AUTH_BETA_DENIED = "error.auth.beta_denied"

    # Network category
    ERROR_NETWORK_ERROR = "error.network.error"
    ERROR_NETWORK_RATE_LIMITED = "error.network.rate_limited"
    ERROR_NETWORK_SERVER_ERROR = "error.network.server_error"

    # Config category
    ERROR_CONFIG_INVALID = "error.config.invalid"
    ERROR_CONFIG_LLM_NOT_FOUND = "error.config.llm_not_found"
    ERROR_CONFIG_VERSION_MISMATCH = "error.config.version_mismatch"

    # Execution category
    ERROR_EXECUTION_TIMEOUT = "error.execution.timeout"

    # ==========================================================================
    # Warning Domain
    # ==========================================================================

    # Deprecation category
    WARNING_DEPRECATION_FLAG = "warning.deprecation.flag"
    WARNING_DEPRECATION_COMMAND = "warning.deprecation.command"
    WARNING_DEPRECATION_OPTION = "warning.deprecation.option"
    WARNING_DEPRECATION_CONFIG_KEY = "warning.deprecation.config_key"
    WARNING_DEPRECATION_MODEL = "warning.deprecation.model"
    WARNING_DEPRECATION_PACKAGE = "warning.deprecation.package"

    # Quality category
    WARNING_QUALITY_INPUT_CHECK = "warning.quality.input_check"
    WARNING_QUALITY_OBJECTIVE_VAGUE = "warning.quality.objective_vague"

    # Cache category
    WARNING_CACHE_SIZE_WARNING = "warning.cache.size_warning"
    WARNING_CACHE_SIZE_CRITICAL = "warning.cache.size_critical"

    # Version category
    WARNING_VERSION_UPDATE_AVAILABLE = "warning.version.update_available"
    WARNING_VERSION_INCOMPATIBLE = "warning.version.incompatible"

    # Runtime category
    WARNING_RUNTIME_GENERIC = "warning.runtime.generic"

    # ==========================================================================
    # Guidance Domain
    # ==========================================================================

    # Requirement category
    GUIDANCE_REQUIREMENT_SELECT_PROJECT = "guidance.requirement.select_project"
    GUIDANCE_REQUIREMENT_ACCEPT_TERMS = "guidance.requirement.accept_terms"
    GUIDANCE_REQUIREMENT_LOGIN_REQUIRED = "guidance.requirement.login_required"

    # Options category
    GUIDANCE_OPTIONS_PROJECT_SELECTION = "guidance.options.project_selection"
    GUIDANCE_OPTIONS_DIRECTORY_CHOICE = "guidance.options.directory_choice"

    # Hint category
    GUIDANCE_HINT_USE_COMMAND = "guidance.hint.use_command"
    GUIDANCE_HINT_TIP = "guidance.hint.tip"

    # Validation category
    GUIDANCE_VALIDATION_INVALID_CHOICE = "guidance.validation.invalid_choice"
    GUIDANCE_VALIDATION_INVALID_INPUT = "guidance.validation.invalid_input"

    # Input category
    GUIDANCE_INPUT_PROVIDE_PLAN = "guidance.input.provide_plan"
    GUIDANCE_INPUT_PROVIDE_OBJECTIVE = "guidance.input.provide_objective"

    # ==========================================================================
    # Prompt Domain
    # ==========================================================================

    # Confirm category
    PROMPT_CONFIRM_DIRECTORY_USE = "prompt.confirm.directory_use"
    PROMPT_CONFIRM_FORCE_COMPLETE = "prompt.confirm.force_complete"
    PROMPT_CONFIRM_CLEAR_NOTES = "prompt.confirm.clear_notes"
    PROMPT_CONFIRM_RESET_CONFIG = "prompt.confirm.reset_config"
    PROMPT_CONFIRM_FACTORY_RESET = "prompt.confirm.factory_reset"
    PROMPT_CONFIRM_SOFT_RESET = "prompt.confirm.soft_reset"
    PROMPT_CONFIRM_REMOVE_STEP = "prompt.confirm.remove_step"
    PROMPT_CONFIRM_DELETE_ITEM = "prompt.confirm.delete_item"
    PROMPT_CONFIRM_CONTINUE_ACTION = "prompt.confirm.continue_action"
    PROMPT_CONFIRM_DELETE_PROJECT = "prompt.confirm.delete_project"
    PROMPT_CONFIRM_ABANDON_SESSION = "prompt.confirm.abandon_session"
    PROMPT_CONFIRM_GENERIC = "prompt.confirm.generic"

    # Choice category
    PROMPT_CHOICE_SELECT_OPTION = "prompt.choice.select_option"
