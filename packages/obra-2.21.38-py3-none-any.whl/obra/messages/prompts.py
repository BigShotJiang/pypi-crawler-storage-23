"""
Prompt domain message templates.

Templates for confirmation dialogs and choice prompts.
"""

from __future__ import annotations

from typing import Any

from obra.messages.registry import (
    MessageDomain,
    MessageTemplate,
    PromptCategory,
)

__all__ = [
    "TEMPLATES",
    "build_confirm_prompt",
    "get_prompt",
]

# =============================================================================
# Prompt Templates
# =============================================================================

TEMPLATES: dict[str, MessageTemplate] = {
    # -------------------------------------------------------------------------
    # Confirm Category
    # -------------------------------------------------------------------------
    "prompt.confirm.directory_use": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Use this directory for this run?",
        verbose_template=("Directory confirmation:\nUse this directory for this run?"),
    ),
    "prompt.confirm.force_complete": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Force-complete anyway?",
        verbose_template=(
            "Force completion:\n"
            "This will mark the session as complete even if work is incomplete.\n"
            "Force-complete anyway?"
        ),
    ),
    "prompt.confirm.clear_notes": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Are you sure you want to clear all notes?",
        verbose_template=(
            "Clear all notes:\n"
            "This action cannot be undone.\n"
            "Are you sure you want to clear all notes?"
        ),
    ),
    "prompt.confirm.reset_config": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Reset configuration to defaults?",
        verbose_template=(
            "Configuration reset:\n"
            "This will restore all settings to their default values.\n"
            "Reset configuration to defaults?"
        ),
    ),
    "prompt.confirm.factory_reset": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Proceed with factory reset?",
        verbose_template=(
            "Factory reset:\n"
            "This will remove all local data and settings.\n"
            "Proceed with factory reset?"
        ),
    ),
    "prompt.confirm.soft_reset": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Proceed with soft reset?",
        verbose_template=(
            "Soft reset:\n"
            "This will reset session state without removing data.\n"
            "Proceed with soft reset?"
        ),
    ),
    "prompt.confirm.remove_step": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Are you sure you want to remove this step?",
        verbose_template=(
            "Remove step:\n"
            "This will remove the step from the plan.\n"
            "Are you sure you want to remove this step?"
        ),
    ),
    "prompt.confirm.delete_item": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Are you sure you want to delete this item?",
        verbose_template=(
            "Delete item:\n"
            "This action cannot be undone.\n"
            "Are you sure you want to delete this item?"
        ),
    ),
    "prompt.confirm.continue_action": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Are you sure you want to continue?",
        verbose_template="Are you sure you want to continue with this action?",
    ),
    "prompt.confirm.delete_project": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Are you sure you want to delete this project?",
        verbose_template=(
            "Delete project:\n"
            "This will remove the project and all associated data.\n"
            "Are you sure you want to delete this project?"
        ),
    ),
    "prompt.confirm.abandon_session": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Abandon this session?",
        verbose_template=(
            "Abandon session:\nAny unsaved work will be lost.\nAbandon this session?"
        ),
    ),
    "prompt.confirm.generic": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Are you sure you want to {action}?",
        verbose_template="Confirmation required: Are you sure you want to {action}?",
        placeholders=("action",),
    ),
    # -------------------------------------------------------------------------
    # Choice Category
    # -------------------------------------------------------------------------
    "prompt.choice.select_option": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CHOICE,
        template="Select an option (1-{count}):",
        verbose_template="Please select an option by entering a number (1-{count}):",
        placeholders=("count",),
    ),
    # -------------------------------------------------------------------------
    # Defaults Category (proposed defaults during plan refinement)
    # -------------------------------------------------------------------------
    "prompt.defaults.header": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Proposed defaults detected",
    ),
    "prompt.defaults.issue_label": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Issue {issue_id}: {description}",
        placeholders=("issue_id", "description"),
    ),
    "prompt.defaults.proposed_value": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Proposed: {value}",
        placeholders=("value",),
    ),
    "prompt.defaults.input_prompt": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Accept, override, or 'skip': ",
    ),
    "prompt.defaults.auto_accept_warning": MessageTemplate(
        domain=MessageDomain.PROMPT,
        category=PromptCategory.CONFIRM,
        template="Non-interactive environment detected; auto-accepting proposed defaults.",
    ),
}


# =============================================================================
# Builder Functions (FR-3)
# =============================================================================


def get_prompt(key: str, **kwargs: Any) -> str:
    """
    Get a prompt message with automatic domain prefix.

    Args:
        key: Key without 'prompt.' prefix (e.g., 'confirm.reset_config')
        **kwargs: Placeholder values

    Returns:
        Formatted message string
    """
    from obra.messages.registry import get_message

    return get_message(f"prompt.{key}", **kwargs)


def build_confirm_prompt(action: str) -> str:
    """
    Build a generic confirmation prompt.

    Args:
        action: The action being confirmed

    Returns:
        Formatted confirmation prompt
    """
    from obra.messages.registry import get_message

    return get_message("prompt.confirm.generic", action=action)
