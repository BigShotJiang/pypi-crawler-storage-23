"""Dependency verifier implementing Step 5 (VERIFY) of the resolution protocol.

Uses a decorator-based registry (consistent with Rule 6) to map
(ecosystem, kind) pairs to probe functions. Unknown ecosystems degrade
gracefully to status='unverified'.
"""

from __future__ import annotations

import logging
import shutil
import socket
import subprocess
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.hybrid.dependency_manifest import DependencyManifest, normalize_ecosystem

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Verifier registry
# ---------------------------------------------------------------------------

_VERIFIER_REGISTRY: dict[tuple[str, str], Callable[..., tuple[str, str]]] = {}

_RUNTIME_PROBE_COMMANDS: dict[str, list[list[str]]] = {
    "python": [["python3", "--version"], ["python", "--version"]],
    "node": [["node", "--version"], ["nodejs", "--version"]],
    "rust": [["rustc", "--version"]],
    "go": [["go", "version"]],
    "ruby": [["ruby", "--version"]],
}

_RUNTIME_SUFFIX_HINTS: tuple[str, ...] = (
    "_runtime",
    "_interpreter",
)
_RUNTIME_PREFIX_HINTS: tuple[str, ...] = (
    "runtime_",
    "interpreter_",
)


def register_verifier(
    ecosystem: str,
    kind: str,
) -> Callable[
    [Callable[..., tuple[str, str]]],
    Callable[..., tuple[str, str]],
]:
    """Decorator to register a verifier probe for an (ecosystem, kind) pair.

    The decorated function must accept ``(name, manifest, entry)`` and return
    ``(status, detail)`` where *status* is one of ``installed``, ``missing``,
    or ``unverified``.
    """

    def decorator(
        fn: Callable[..., tuple[str, str]],
    ) -> Callable[..., tuple[str, str]]:
        _VERIFIER_REGISTRY[(ecosystem, kind)] = fn
        return fn

    return decorator


# ---------------------------------------------------------------------------
# DependencyVerifier
# ---------------------------------------------------------------------------


class DependencyVerifier:
    """Verify dependency status via per-ecosystem probes."""

    _SUBPROCESS_TIMEOUT = 10

    def verify(self, manifest: DependencyManifest) -> DependencyManifest:
        """Update ``status`` and ``detail`` on each entry in-place.

        Entry count is never changed (invariant 1).
        """
        for entry in manifest.entries:
            self.verify_entry(entry, manifest)
        return manifest

    def verify_entry(self, entry: Any, manifest: DependencyManifest) -> None:
        """Run the verifier probe for a single entry, updating it in-place."""
        probe = _VERIFIER_REGISTRY.get((entry.ecosystem, entry.kind))
        if probe is None:
            # Fall back to a cross-kind probe keyed on ("*", kind)
            probe = _VERIFIER_REGISTRY.get(("*", entry.kind))
        if probe is None:
            entry.status = "unverified"
            entry.detail = "cannot verify automatically (unknown ecosystem)"
            return
        try:
            status, detail = probe(
                getattr(entry, 'verify_key', None) or entry.name,
                manifest,
                entry,
            )
            entry.status = status
            entry.verify_detail = detail
            if (
                status != "installed"
                and entry.execute_detail
                and entry.execute_detail != detail
            ):
                entry.detail = f"{detail} | execute: {entry.execute_detail}"
            else:
                entry.detail = detail
        except Exception:
            logger.warning(
                "Verifier probe failed for %s/%s: %s",
                entry.ecosystem,
                entry.kind,
                entry.name,
                exc_info=True,
            )
            entry.status = "unverified"
            entry.verify_detail = "verifier probe raised an exception"
            if entry.execute_detail:
                entry.detail = (
                    f"{entry.verify_detail} | execute: {entry.execute_detail}"
                )
            else:
                entry.detail = entry.verify_detail


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _run(
    cmd: list[str],
    *,
    timeout: int = DependencyVerifier._SUBPROCESS_TIMEOUT,
    cwd: str | None = None,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        timeout=timeout,
        capture_output=True,
        text=True,
        check=True,
        cwd=cwd,
    )


def _venv_python(manifest: DependencyManifest) -> str:
    """Return the venv python path if available, else 'python3'."""
    py_info = manifest.environment_info.get("python")
    if py_info and py_info.venv_path:
        candidate = str(Path(py_info.venv_path) / "bin" / "python")
        if Path(candidate).exists():
            return candidate
    return "python3"


def _probe_runtime_alias(alias: str) -> tuple[str, str]:
    """Probe a runtime by canonical ecosystem alias."""
    commands = _RUNTIME_PROBE_COMMANDS.get(alias)
    if not commands:
        return ("unverified", f"unknown runtime alias: {alias}")

    for cmd in commands:
        try:
            result = _run(cmd)
            output = (result.stdout or result.stderr).strip()
            return ("installed", output or f"{cmd[0]} is available")
        except (subprocess.CalledProcessError, FileNotFoundError):
            continue

    binaries = ", ".join(cmd[0] for cmd in commands)
    return ("missing", f"{alias} runtime not found ({binaries})")


def _resolve_runtime_alias(raw: str) -> str | None:
    """Resolve runtime aliases from ecosystem/name strings."""
    if not raw:
        return None

    cleaned = raw.strip().lower()
    if not cleaned:
        return None

    alias = normalize_ecosystem(cleaned)
    if alias in _RUNTIME_PROBE_COMMANDS:
        return alias

    normalized = cleaned.replace("-", "_").replace(" ", "_")
    alias = normalize_ecosystem(normalized)
    if alias in _RUNTIME_PROBE_COMMANDS:
        return alias

    for suffix in _RUNTIME_SUFFIX_HINTS:
        if normalized.endswith(suffix):
            alias = normalize_ecosystem(normalized[: -len(suffix)])
            if alias in _RUNTIME_PROBE_COMMANDS:
                return alias

    for prefix in _RUNTIME_PREFIX_HINTS:
        if normalized.startswith(prefix):
            alias = normalize_ecosystem(normalized[len(prefix):])
            if alias in _RUNTIME_PROBE_COMMANDS:
                return alias

    return None


# ---------------------------------------------------------------------------
# Python verifiers
# ---------------------------------------------------------------------------


@register_verifier("python", "package")
def _verify_python_package(
    name: str,
    manifest: DependencyManifest,
    entry: Any,
) -> tuple[str, str]:
    python = _venv_python(manifest)
    try:
        _run([python, "-c", f"import {name}"])
        return ("installed", f"import {name} succeeded ({python})")
    except (subprocess.CalledProcessError, FileNotFoundError):
        return ("missing", f"import {name} failed ({python})")


@register_verifier("python", "runtime")
def _verify_python_runtime(
    name: str,
    manifest: DependencyManifest,
    entry: Any,
) -> tuple[str, str]:
    return _probe_runtime_alias("python")


# ---------------------------------------------------------------------------
# Node verifiers
# ---------------------------------------------------------------------------


@register_verifier("node", "package")
def _verify_node_package(
    name: str,
    manifest: DependencyManifest,
    entry: Any,
) -> tuple[str, str]:
    pkg_dir = Path(manifest.working_dir) / "node_modules" / name
    if pkg_dir.exists():
        return ("installed", f"node_modules/{name} exists")
    return ("missing", f"node_modules/{name} not found")


@register_verifier("node", "runtime")
def _verify_node_runtime(
    name: str,
    manifest: DependencyManifest,
    entry: Any,
) -> tuple[str, str]:
    return _probe_runtime_alias("node")


# ---------------------------------------------------------------------------
# Rust verifiers
# ---------------------------------------------------------------------------


@register_verifier("rust", "package")
def _verify_rust_package(
    name: str,
    manifest: DependencyManifest,
    entry: Any,
) -> tuple[str, str]:
    try:
        result = _run(["cargo", "install", "--list"])
        # cargo install --list outputs lines like "package_name v1.2.3:"
        for line in result.stdout.splitlines():
            if line.startswith(name + " ") or line.startswith(name + "\t"):
                return ("installed", f"cargo install --list contains {name}")
        return ("missing", f"{name} not in cargo install --list")
    except (subprocess.CalledProcessError, FileNotFoundError):
        return ("missing", f"cargo install --list failed for {name}")


@register_verifier("rust", "runtime")
def _verify_rust_runtime(
    name: str,
    manifest: DependencyManifest,
    entry: Any,
) -> tuple[str, str]:
    return _probe_runtime_alias("rust")


# ---------------------------------------------------------------------------
# Go verifiers
# ---------------------------------------------------------------------------


@register_verifier("go", "package")
def _verify_go_package(
    name: str,
    manifest: DependencyManifest,
    entry: Any,
) -> tuple[str, str]:
    try:
        _run(["go", "list", name], cwd=manifest.working_dir)
        return ("installed", f"go list {name} succeeded")
    except (subprocess.CalledProcessError, FileNotFoundError):
        return ("missing", f"go list {name} failed")


@register_verifier("go", "runtime")
def _verify_go_runtime(
    name: str,
    manifest: DependencyManifest,
    entry: Any,
) -> tuple[str, str]:
    return _probe_runtime_alias("go")


# ---------------------------------------------------------------------------
# Ruby verifiers
# ---------------------------------------------------------------------------


@register_verifier("ruby", "package")
def _verify_ruby_package(
    name: str,
    manifest: DependencyManifest,
    entry: Any,
) -> tuple[str, str]:
    try:
        _run(["gem", "list", "-i", name])
        return ("installed", f"gem list -i {name} succeeded")
    except (subprocess.CalledProcessError, FileNotFoundError):
        return ("missing", f"gem list -i {name} failed")


@register_verifier("ruby", "runtime")
def _verify_ruby_runtime(
    name: str,
    manifest: DependencyManifest,
    entry: Any,
) -> tuple[str, str]:
    return _probe_runtime_alias("ruby")


@register_verifier("*", "runtime")
def _verify_runtime_fallback(
    name: str,
    manifest: DependencyManifest,
    entry: Any,
) -> tuple[str, str]:
    """Cross-ecosystem runtime fallback for entries with unknown ecosystem labels."""
    candidates = [
        str(entry.ecosystem or "").strip(),
        str(name or "").strip(),
        str(entry.name or "").strip(),
    ]
    for candidate in candidates:
        if not candidate:
            continue
        alias = _resolve_runtime_alias(candidate)
        if alias is not None:
            return _probe_runtime_alias(alias)
    return ("unverified", f"cannot verify runtime automatically ({name})")


# ---------------------------------------------------------------------------
# System tool verifier
# ---------------------------------------------------------------------------

# LLMs frequently append descriptive segments to tool names (e.g. "git_cli"
# instead of "git", "gcc_compiler" instead of "gcc").  When the trailing
# underscore-delimited segment matches one of these known descriptive words,
# we generate a stripped candidate for shutil.which() probing.
_DESCRIPTIVE_TOOL_SEGMENTS: frozenset[str] = frozenset({
    "cli", "cmd", "bin", "tool", "binary", "exec",
    "compiler", "interpreter", "runtime", "server",
    "client", "utility", "program", "app",
})


def _system_tool_candidates(name: str) -> list[str]:
    """Generate candidate binary names from an LLM-provided tool name."""
    candidates = [name]
    # Strip trailing segment if it is a known descriptive word
    # (e.g. "git_cli" → "git", "gcc_compiler" → "gcc").
    parts = name.rsplit("_", 1)
    if len(parts) == 2 and parts[1].lower() in _DESCRIPTIVE_TOOL_SEGMENTS:
        candidates.append(parts[0])
    # LLMs may use underscores where the real binary uses hyphens
    # (e.g. "docker_compose" → "docker-compose").
    hyphenated = name.replace("_", "-")
    if hyphenated != name:
        candidates.append(hyphenated)
    return candidates


@register_verifier("system", "tool")
def _verify_system_tool(
    name: str,
    manifest: DependencyManifest,
    entry: Any,
) -> tuple[str, str]:
    for candidate in _system_tool_candidates(name):
        path = shutil.which(candidate)
        if path:
            return ("installed", f"which {candidate} -> {path}")
    return ("missing", f"{name} not found on PATH")


# ---------------------------------------------------------------------------
# Cross-ecosystem service verifier
# ---------------------------------------------------------------------------

_SERVICE_PORTS: dict[str, int] = {
    "redis": 6379,
    "postgres": 5432,
    "postgresql": 5432,
    "mysql": 3306,
    "mongodb": 27017,
    "mongo": 27017,
    "elasticsearch": 9200,
}


@register_verifier("*", "service")
def _verify_service(
    name: str,
    manifest: DependencyManifest,
    entry: Any,
) -> tuple[str, str]:
    lower = name.lower()

    # Docker special-case
    if lower == "docker":
        try:
            _run(["docker", "info"])
            return ("installed", "docker info succeeded")
        except (subprocess.CalledProcessError, FileNotFoundError):
            return ("missing", "docker info failed or docker not found")

    # Port-based probe for known services
    port = _SERVICE_PORTS.get(lower)
    if port:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            sock.connect(("127.0.0.1", port))
            sock.close()
            return ("installed", f"{name} responding on port {port}")
        except OSError:
            return ("missing", f"{name} not responding on port {port}")

    return ("unverified", "cannot probe unknown service automatically")
