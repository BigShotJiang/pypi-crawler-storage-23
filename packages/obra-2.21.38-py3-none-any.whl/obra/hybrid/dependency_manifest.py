"""Dependency manifest data model for the Story0 dependency resolution protocol."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Any


ECOSYSTEM_ALIASES: dict[str, str] = {
    "python": "python",
    "python3": "python",
    "py": "python",
    "node": "node",
    "nodejs": "node",
    "javascript": "node",
    "js": "node",
    "typescript": "node",
    "rust": "rust",
    "rs": "rust",
    "cargo": "rust",
    "go": "go",
    "golang": "go",
    "ruby": "ruby",
    "rb": "ruby",
    "system": "system",
    "c": "unknown",
    "c++": "unknown",
    "cpp": "unknown",
    "cmake": "unknown",
    "zig": "unknown",
    "java": "unknown",
    "kotlin": "unknown",
}

BLOCKING_POLICY: dict[str, bool] = {
    "runtime": True,
    "service": True,
    "package": False,
    "tool": False,
}


def normalize_ecosystem(raw: str | None) -> str:
    """Map LLM/user ecosystem strings to canonical names."""
    if not raw:
        return "unknown"
    return ECOSYSTEM_ALIASES.get(raw.strip().lower(), "unknown")


@dataclass
class DependencyEntry:
    """One detected or LLM-inferred dependency."""

    dependency_id: str
    name: str
    ecosystem: str
    kind: str
    status: str
    proposed_command: list[str] | None
    override_command: list[str] | None
    requires_elevation: bool
    source: str
    blocking: bool
    detail: str
    version_constraint: str | None
    execute_detail: str | None = None
    verify_detail: str | None = None
    install_key: str | None = None
    verify_key: str | None = None
    attempt_count: int = 0
    attempt_budget: int = 0
    last_failure_class: str | None = None
    decision_source: str | None = None
    terminal_reason: str | None = None

    @property
    def effective_command(self) -> list[str] | None:
        """Return override_command if set, otherwise proposed_command."""
        return self.override_command or self.proposed_command

    @staticmethod
    def compute_id(name: str, ecosystem: str) -> str:
        """Compute a stable dependency ID from name and ecosystem."""
        key = f"{name.lower().strip()}:{ecosystem}"
        return hashlib.sha256(key.encode()).hexdigest()[:16]


@dataclass
class EnvironmentDetail:
    """Per-ecosystem environment metadata."""

    venv_path: str | None
    created_by: str | None  # "uv" | "venv" | "conda" | None
    manager: str | None


@dataclass
class DependencyManifest:
    """Full dependency scan result."""

    entries: list[DependencyEntry]
    scan_timestamp: str
    working_dir: str
    ecosystems_detected: list[str]
    environment_info: dict[str, EnvironmentDetail] = field(default_factory=dict)
    scanner_schema_version: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Serialize manifest to a plain dict for state persistence."""
        return {
            "entries": [
                {
                    "dependency_id": e.dependency_id,
                    "name": e.name,
                    "ecosystem": e.ecosystem,
                    "kind": e.kind,
                    "status": e.status,
                    "proposed_command": e.proposed_command,
                    "override_command": e.override_command,
                    "requires_elevation": e.requires_elevation,
                    "source": e.source,
                    "blocking": e.blocking,
                    "detail": e.detail,
                    "version_constraint": e.version_constraint,
                    "execute_detail": e.execute_detail,
                    "verify_detail": e.verify_detail,
                    "install_key": e.install_key,
                    "verify_key": e.verify_key,
                    "attempt_count": e.attempt_count,
                    "attempt_budget": e.attempt_budget,
                    "last_failure_class": e.last_failure_class,
                    "decision_source": e.decision_source,
                    "terminal_reason": e.terminal_reason,
                }
                for e in self.entries
            ],
            "scan_timestamp": self.scan_timestamp,
            "working_dir": self.working_dir,
            "ecosystems_detected": self.ecosystems_detected,
            "environment_info": {
                eco: {
                    "venv_path": info.venv_path,
                    "created_by": info.created_by,
                    "manager": info.manager,
                }
                for eco, info in self.environment_info.items()
            },
            "scanner_schema_version": self.scanner_schema_version,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DependencyManifest:
        """Deserialize manifest from a plain dict."""
        entries = [
            DependencyEntry(
                dependency_id=e["dependency_id"],
                name=e["name"],
                ecosystem=e["ecosystem"],
                kind=e["kind"],
                status=e["status"],
                proposed_command=e.get("proposed_command"),
                override_command=e.get("override_command"),
                requires_elevation=e.get("requires_elevation", False),
                source=e["source"],
                blocking=e.get("blocking", False),
                detail=e.get("detail", ""),
                version_constraint=e.get("version_constraint"),
                execute_detail=e.get("execute_detail"),
                verify_detail=e.get("verify_detail"),
                install_key=e.get("install_key"),
                verify_key=e.get("verify_key"),
                attempt_count=e.get("attempt_count", 0),
                attempt_budget=e.get("attempt_budget", 0),
                last_failure_class=e.get("last_failure_class"),
                decision_source=e.get("decision_source"),
                terminal_reason=e.get("terminal_reason"),
            )
            for e in data.get("entries", [])
        ]
        env_info = {
            eco: EnvironmentDetail(
                venv_path=info.get("venv_path"),
                created_by=info.get("created_by"),
                manager=info.get("manager"),
            )
            for eco, info in data.get("environment_info", {}).items()
        }
        return cls(
            entries=entries,
            scan_timestamp=data.get("scan_timestamp", ""),
            working_dir=data.get("working_dir", ""),
            ecosystems_detected=data.get("ecosystems_detected", []),
            environment_info=env_info,
            scanner_schema_version=data.get("scanner_schema_version", 0),
        )
