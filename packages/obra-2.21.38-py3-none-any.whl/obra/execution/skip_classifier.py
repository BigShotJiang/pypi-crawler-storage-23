"""Heuristic classifier for skip reasons."""

from __future__ import annotations

from obra.execution.skip_record import SkipReason

TIMEOUT_EXIT_CODE = 124
SIGKILL_EXIT_CODES = (137, 143)


def get_tier(reason: SkipReason) -> int:
    """Map a SkipReason to its tier (1=gap, 2=context, 3=intentional)."""
    if reason in {
        SkipReason.MISSING_SECRET,
        SkipReason.DESIGN_DECISION,
        SkipReason.EXTERNAL_DEPENDENCY,
        SkipReason.TRANSIENT_EXHAUSTED,
        SkipReason.QUALITY_THRESHOLD,
        SkipReason.DEFERRED_CONCERN,
        SkipReason.PERMISSION_DENIED,
        SkipReason.SCOPE_BOUNDARY,
        SkipReason.UNKNOWN,
    }:
        return 1
    if reason in {
        SkipReason.CONTAINER_EXECUTION,
        SkipReason.RESUME_RECOVERY,
        SkipReason.MAX_ITERATIONS,
        SkipReason.DIMINISHING_RETURNS,
        SkipReason.NO_IMPROVEMENTS,
    }:
        return 2
    if reason in {
        SkipReason.USER_TIMEOUT,
        SkipReason.USER_DECLINED,
        SkipReason.BYPASS_FLAG,
    }:
        return 3
    return 1


def classify_skip_reason(
    exit_code: int | None = None,
    logs: str = "",
    source_hint: SkipReason | None = None,
    error_type: str = "",
) -> tuple[SkipReason, int]:
    """Classify skip reason based on exit codes, logs, or hints."""
    if source_hint:
        return source_hint, get_tier(source_hint)

    reason = SkipReason.UNKNOWN
    tier = 1

    if exit_code is not None and (
        exit_code == TIMEOUT_EXIT_CODE or exit_code in SIGKILL_EXIT_CODES
    ):
        reason = SkipReason.TRANSIENT_EXHAUSTED
        tier = 1

    logs_lower = (logs or "").lower()
    if "permission denied" in logs_lower:
        reason = SkipReason.PERMISSION_DENIED
        tier = 1
    elif any(token in logs_lower for token in ("secret", "api key", "token")):
        reason = SkipReason.MISSING_SECRET
        tier = 1
    elif "timeout" in logs_lower:
        reason = SkipReason.USER_TIMEOUT
        tier = 3
    elif error_type:
        error_lower = error_type.lower()
        if "permission" in error_lower:
            reason = SkipReason.PERMISSION_DENIED
            tier = 1

    return reason, tier


__all__ = ["classify_skip_reason", "get_tier"]
