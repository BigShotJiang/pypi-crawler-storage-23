"""Resilience policy abstraction for handler retry and timeout configuration.

This module provides a domain abstraction for resilience policies (retry counts,
delays, timeouts) that replaces magic numbers scattered throughout handler code.
Handler-specific policies can be loaded from configuration with environment
variable overrides following Rule 22 (Configuration-Wired Operations).

Usage:
    from obra.execution.resilience import ResiliencePolicy, BackoffStrategy

    # Load handler-specific policy from config
    policy = ResiliencePolicy.for_handler("derive")

    # Calculate delay for retry attempt
    delay = policy.calculate_delay(attempt=2)

    # Access policy values
    if attempt > policy.max_retries:
        raise MaxRetriesExceeded()

Environment Variable Overrides:
    Each policy value can be overridden via environment variable:
    - OBRA_RESILIENCE_{HANDLER}_MAX_RETRIES
    - OBRA_RESILIENCE_{HANDLER}_BASE_DELAY_S
    - OBRA_RESILIENCE_{HANDLER}_MAX_DELAY_S
    - OBRA_RESILIENCE_{HANDLER}_TIMEOUT_WINDOW_S

    Example: OBRA_RESILIENCE_DERIVE_MAX_RETRIES=10

Related:
    - obra/execution/retry.py (retry decorator using these policies)
    - obra/config/default_config.yaml (orchestration.resilience section)
    - ADR-068: Magic Value Domain Abstractions
"""

from __future__ import annotations

import logging
import os
import random
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class BackoffStrategy(Enum):
    """Backoff strategy for retry delays.

    Attributes:
        FIXED: Use base_delay_s for all attempts (no exponential growth)
        EXPONENTIAL: Delay grows as base_delay_s * 2^attempt (classic exponential backoff)
        JITTER: Exponential with random jitter to prevent thundering herd
    """

    FIXED = "fixed"
    EXPONENTIAL = "exponential"
    JITTER = "jitter"


@dataclass(frozen=True)
class ResiliencePolicy:
    """Handler-specific resilience configuration.

    Encapsulates retry and timeout settings for a specific handler or operation.
    Policies are loaded from configuration with environment variable overrides.

    Attributes:
        max_retries: Maximum number of retry attempts before giving up
        base_delay_s: Initial delay in seconds between retries
        max_delay_s: Maximum delay cap in seconds (limits exponential growth)
        timeout_window_s: Total timeout window in seconds for the operation
        backoff_strategy: Strategy for calculating delays (FIXED, EXPONENTIAL, JITTER)
    """

    max_retries: int
    base_delay_s: float
    max_delay_s: float
    timeout_window_s: int
    backoff_strategy: BackoffStrategy = BackoffStrategy.EXPONENTIAL

    @classmethod
    def for_handler(cls, handler_name: str) -> ResiliencePolicy:
        """Load resilience policy for a specific handler.

        Follows Rule 22 (Configuration-Wired Operations) with 3-tier resolution:
        1. Environment variable (OBRA_RESILIENCE_{HANDLER}_*)
        2. Handler-specific config (orchestration.resilience.{handler})
        3. Default config (orchestration.resilience.default)

        Raises ConfigurationError if no configuration is found.

        Args:
            handler_name: Name of the handler (e.g., "derive", "fix", "execute")

        Returns:
            ResiliencePolicy configured for the handler

        Raises:
            ConfigurationError: If no resilience config exists for handler or default
        """
        # Import here to avoid circular dependency
        from obra.config.loaders import load_layered_config
        from obra.exceptions import ConfigurationError

        config, _, _ = load_layered_config()
        env_prefix = f"OBRA_RESILIENCE_{handler_name.upper()}_"

        # Get resilience config section
        resilience_config = config.get("orchestration", {}).get("resilience", {})

        # Try handler-specific config first, then default
        handler_config = resilience_config.get(handler_name)
        if handler_config is None:
            handler_config = resilience_config.get("default")

        if handler_config is None:
            msg = (
                f"No resilience configuration found for handler '{handler_name}' "
                f"and no default configuration available. "
                f"Add orchestration.resilience.{handler_name} or "
                f"orchestration.resilience.default to config."
            )
            raise ConfigurationError(msg)

        # Extract values with environment variable overrides
        max_retries = _get_int_with_env_override(
            env_prefix + "MAX_RETRIES",
            handler_config.get("max_retries"),
        )
        base_delay_s = _get_float_with_env_override(
            env_prefix + "BASE_DELAY_S",
            handler_config.get("base_delay_s"),
        )
        max_delay_s = _get_float_with_env_override(
            env_prefix + "MAX_DELAY_S",
            handler_config.get("max_delay_s"),
        )
        timeout_window_s = _get_int_with_env_override(
            env_prefix + "TIMEOUT_WINDOW_S",
            handler_config.get("timeout_window_s"),
        )

        # Parse backoff strategy (not commonly overridden via env)
        strategy_str = handler_config.get("backoff_strategy", "exponential")
        try:
            backoff_strategy = BackoffStrategy(strategy_str.lower())
        except ValueError:
            logger.warning(
                "Unknown backoff strategy '%s' for handler '%s', using EXPONENTIAL",
                strategy_str,
                handler_name,
            )
            backoff_strategy = BackoffStrategy.EXPONENTIAL

        return cls(
            max_retries=max_retries,
            base_delay_s=base_delay_s,
            max_delay_s=max_delay_s,
            timeout_window_s=timeout_window_s,
            backoff_strategy=backoff_strategy,
        )

    def calculate_delay(self, attempt: int) -> float:
        """Calculate the delay before the next retry attempt.

        Args:
            attempt: The current attempt number (0-indexed)

        Returns:
            Delay in seconds before the next retry
        """
        if self.backoff_strategy == BackoffStrategy.FIXED:
            return self.base_delay_s

        # Calculate exponential delay: base_delay_s * 2^attempt
        delay = self.base_delay_s * (2**attempt)

        # Cap at max_delay_s
        delay = min(delay, self.max_delay_s)

        if self.backoff_strategy == BackoffStrategy.JITTER:
            # Apply jitter: multiply by random factor between 0.5 and 1.5
            jitter_factor = 0.5 + random.random()
            delay = delay * jitter_factor
            # Re-apply cap after jitter
            delay = min(delay, self.max_delay_s)

        return delay

    def to_dict(self) -> dict[str, Any]:
        """Convert policy to dictionary for logging/serialization."""
        return {
            "max_retries": self.max_retries,
            "base_delay_s": self.base_delay_s,
            "max_delay_s": self.max_delay_s,
            "timeout_window_s": self.timeout_window_s,
            "backoff_strategy": self.backoff_strategy.value,
        }


def _get_int_with_env_override(env_var: str, config_value: Any) -> int:
    """Get integer value with environment variable override.

    Args:
        env_var: Environment variable name to check
        config_value: Default value from configuration

    Returns:
        Integer value from env var or config
    """
    env_val = os.environ.get(env_var)
    if env_val is not None:
        try:
            return int(env_val)
        except ValueError:
            logger.warning(
                "Invalid integer value '%s' for %s, using config value",
                env_val,
                env_var,
            )
    return int(config_value) if config_value is not None else 0


def _get_float_with_env_override(env_var: str, config_value: Any) -> float:
    """Get float value with environment variable override.

    Args:
        env_var: Environment variable name to check
        config_value: Default value from configuration

    Returns:
        Float value from env var or config
    """
    env_val = os.environ.get(env_var)
    if env_val is not None:
        try:
            return float(env_val)
        except ValueError:
            logger.warning(
                "Invalid float value '%s' for %s, using config value",
                env_val,
                env_var,
            )
    return float(config_value) if config_value is not None else 0.0


__all__ = [
    "BackoffStrategy",
    "ResiliencePolicy",
]
