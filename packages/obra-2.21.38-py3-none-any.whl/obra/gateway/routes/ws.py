"""WebSocket transport — bidirectional protocol for interactive clients."""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import asdict
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from websockets.exceptions import ConnectionClosed

from obra.api.protocol import EscalationDecision, UserDecisionChoice
from obra.gateway.auth import verify_token
from obra.gateway.event_bus import SessionEventBus
from obra.gateway.protocol import (
    EventFrame,
    HelloFrame,
    ResponseFrame,
    _SUPPORTED_METHODS,
    parse_frame,
    serialize_frame,
)
from obra.gateway.session_manager import SessionLimitError, SessionNotFoundError

logger = logging.getLogger(__name__)

router = APIRouter()

_OBRA_VERSION = "2.21.21"


# ---------------------------------------------------------------------------
# Connection Manager
# ---------------------------------------------------------------------------


class ConnectionManager:
    """Tracks WebSocket connections and their session subscriptions."""

    def __init__(self) -> None:
        self.connections: set[WebSocket] = set()
        self.subscriptions: dict[str, set[WebSocket]] = {}
        self._subscription_tasks: dict[tuple[str, int], asyncio.Task[None]] = {}
        self._seq_counters: dict[tuple[str, int], int] = {}

    def connect(self, ws: WebSocket) -> None:
        self.connections.add(ws)

    def disconnect(self, ws: WebSocket) -> None:
        self.connections.discard(ws)
        # Clean up all subscriptions for this connection
        for session_id in list(self.subscriptions):
            self._remove_subscription(session_id, ws)

    def subscribe(self, session_id: str, ws: WebSocket, event_bus: SessionEventBus) -> None:
        """Subscribe a WebSocket to a session's event stream."""
        if session_id not in self.subscriptions:
            self.subscriptions[session_id] = set()
        self.subscriptions[session_id].add(ws)

        key = (session_id, id(ws))
        self._seq_counters[key] = 0
        task = asyncio.create_task(self._broadcast_events(session_id, ws, event_bus))
        self._subscription_tasks[key] = task

    def unsubscribe(self, session_id: str, ws: WebSocket) -> None:
        """Unsubscribe a WebSocket from a session's event stream."""
        self._remove_subscription(session_id, ws)

    def _remove_subscription(self, session_id: str, ws: WebSocket) -> None:
        """Remove a subscription and cancel its broadcast task."""
        if session_id in self.subscriptions:
            self.subscriptions[session_id].discard(ws)
            if not self.subscriptions[session_id]:
                del self.subscriptions[session_id]

        key = (session_id, id(ws))
        task = self._subscription_tasks.pop(key, None)
        if task and not task.done():
            task.cancel()
        self._seq_counters.pop(key, None)

    async def _broadcast_events(
        self, session_id: str, ws: WebSocket, event_bus: SessionEventBus
    ) -> None:
        """Consume events from an event bus and forward to the subscribed WebSocket."""
        key = (session_id, id(ws))
        try:
            async for event in event_bus.consume():
                seq = self._seq_counters.get(key, 0)
                frame = EventFrame(
                    event=event.get("event_type", "unknown"),
                    payload=event.get("payload", {}),
                    session_id=session_id,
                    seq=seq,
                )
                self._seq_counters[key] = seq + 1

                try:
                    await ws.send_text(serialize_frame(frame))
                except (WebSocketDisconnect, ConnectionClosed, RuntimeError):
                    # Client disconnected — clean up silently
                    self._remove_subscription(session_id, ws)
                    return

                # Auto-unsubscribe on terminal events
                event_type = event.get("event_type", "")
                if event_type in ("session_completed", "session_error"):
                    self._remove_subscription(session_id, ws)
                    return

        except asyncio.CancelledError:
            pass


# Module-level connection manager (shared across the WS route)
_manager = ConnectionManager()


# ---------------------------------------------------------------------------
# WebSocket Endpoint
# ---------------------------------------------------------------------------


@router.websocket("/v1/ws")
async def websocket_endpoint(ws: WebSocket) -> None:
    """WebSocket endpoint for bidirectional gateway communication."""
    await ws.accept()

    # Step 1: Authenticate — first message must be {type: "auth", token: "..."}
    try:
        auth_raw = await ws.receive_text()
        auth_data = json.loads(auth_raw)
    except (json.JSONDecodeError, WebSocketDisconnect):
        await _close_with_error(ws, "Invalid authentication frame", 4001)
        return

    if auth_data.get("type") != "auth" or "token" not in auth_data:
        await _close_with_error(ws, "First message must be {type: 'auth', token: '...'}", 4001)
        return

    # Verify token against the app-level expected token
    from fastapi.security import HTTPAuthorizationCredentials

    expected_token = ws.app.state.gateway_token
    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials=auth_data["token"])
    if not verify_token(creds, expected_token):
        await _close_with_error(ws, "Authentication failed", 4001)
        return

    # Step 2: Send HelloFrame
    sm = ws.app.state.session_manager
    sessions_snapshot = [
        {
            "session_id": r.session_id,
            "status": r.status,
            "objective": r.objective,
            "project_id": r.project_id,
        }
        for r in sm.list_sessions()
    ]
    hello = HelloFrame(
        server_version=_OBRA_VERSION,
        methods=_SUPPORTED_METHODS,
        sessions=sessions_snapshot,
    )
    await ws.send_text(serialize_frame(hello))

    # Step 3: Register connection and process messages
    _manager.connect(ws)
    try:
        while True:
            raw = await ws.receive_text()
            try:
                req = parse_frame(raw)
            except ValueError as exc:
                error_resp = json.dumps({"type": "error", "detail": str(exc)})
                await ws.send_text(error_resp)
                continue

            response = await _dispatch(req, ws)
            await ws.send_text(serialize_frame(response))

    except (WebSocketDisconnect, ConnectionClosed):
        pass
    finally:
        _manager.disconnect(ws)


# ---------------------------------------------------------------------------
# Message Dispatch
# ---------------------------------------------------------------------------


async def _dispatch(req: Any, ws: WebSocket) -> ResponseFrame:
    """Route a request frame to the appropriate handler."""
    sm = ws.app.state.session_manager
    method = req.method
    params = req.params
    req_id = req.id

    try:
        if method == "create_session":
            payload = _handle_create_session(params, sm)
        elif method == "list_sessions":
            payload = _handle_list_sessions(sm)
        elif method == "get_session":
            payload = _handle_get_session(params, sm)
        elif method == "cancel_session":
            payload = _handle_cancel_session(params, sm)
        elif method == "subscribe":
            payload = _handle_subscribe(params, sm, ws)
        elif method == "unsubscribe":
            payload = _handle_unsubscribe(params, ws)
        elif method == "escalation_decision":
            payload = _handle_escalation_decision(params, sm)
        else:
            return ResponseFrame(id=req_id, ok=False, error=f"Unknown method: {method}")
        return ResponseFrame(id=req_id, ok=True, payload=payload)
    except SessionNotFoundError:
        return ResponseFrame(id=req_id, ok=False, error="Session not found")
    except SessionLimitError:
        return ResponseFrame(id=req_id, ok=False, error="Session limit reached")
    except Exception as exc:
        logger.exception("Error handling WS method %s", method)
        return ResponseFrame(id=req_id, ok=False, error=str(exc))


# ---------------------------------------------------------------------------
# Handler Implementations
# ---------------------------------------------------------------------------


def _handle_create_session(params: dict[str, Any], sm: Any) -> dict[str, Any]:
    """Create a new orchestration session."""
    objective = params.get("objective", "")
    project_id = params.get("project_id", "")
    working_dir = params.get("working_dir", ".")

    session_id = sm.create_session(
        objective=objective,
        project_id=project_id,
        working_dir=working_dir,
    )
    return {"session_id": session_id, "status": "created"}


def _handle_list_sessions(sm: Any) -> dict[str, Any]:
    """List all sessions."""
    records = sm.list_sessions()
    return {
        "sessions": [
            {
                "session_id": r.session_id,
                "status": r.status,
                "objective": r.objective,
                "created_at": r.created_at.isoformat(),
                "project_id": r.project_id,
            }
            for r in records
        ]
    }


def _handle_get_session(params: dict[str, Any], sm: Any) -> dict[str, Any]:
    """Get session details."""
    session_id = params.get("session_id", "")
    r = sm.get_session(session_id)
    completion = None
    if r.completion_notice is not None:
        completion = asdict(r.completion_notice)
    return {
        "session_id": r.session_id,
        "status": r.status,
        "objective": r.objective,
        "created_at": r.created_at.isoformat(),
        "project_id": r.project_id,
        "completion_notice": completion,
        "error": r.error,
    }


def _handle_cancel_session(params: dict[str, Any], sm: Any) -> dict[str, Any]:
    """Cancel a running session."""
    session_id = params.get("session_id", "")
    sm.cancel_session(session_id)
    return {"session_id": session_id, "status": "cancelling"}


def _handle_subscribe(params: dict[str, Any], sm: Any, ws: WebSocket) -> dict[str, Any]:
    """Subscribe to a session's event stream."""
    session_id = params.get("session_id", "")
    event_bus = sm.get_event_bus(session_id)
    _manager.subscribe(session_id, ws, event_bus)
    return {"session_id": session_id, "subscribed": True}


def _handle_unsubscribe(params: dict[str, Any], ws: WebSocket) -> dict[str, Any]:
    """Unsubscribe from a session's event stream."""
    session_id = params.get("session_id", "")
    _manager.unsubscribe(session_id, ws)
    return {"session_id": session_id, "unsubscribed": True}


def _handle_escalation_decision(params: dict[str, Any], sm: Any) -> dict[str, Any]:
    """Resolve a pending escalation."""
    session_id = params.get("session_id", "")
    choice_str = params.get("choice", "force_complete")
    was_timeout = params.get("was_timeout", False)

    event_bus = sm.get_event_bus(session_id)
    decision = EscalationDecision(
        choice=UserDecisionChoice(choice_str),
        was_timeout=was_timeout,
    )
    resolved = event_bus.resolve_escalation(decision)

    if not resolved:
        return {"session_id": session_id, "escalation_resolved": False, "error": "No pending escalation"}

    return {"session_id": session_id, "escalation_resolved": True}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _close_with_error(ws: WebSocket, detail: str, code: int) -> None:
    """Send error message and close the WebSocket."""
    try:
        await ws.send_text(json.dumps({"type": "error", "detail": detail}))
        await ws.close(code=code)
    except Exception:
        pass
