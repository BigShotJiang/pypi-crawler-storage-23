"""Bearer token authentication for the gateway server."""

from __future__ import annotations

import hmac
import secrets
from typing import Callable

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

_bearer_scheme = HTTPBearer()


def verify_token(credentials: HTTPAuthorizationCredentials, expected_token: str) -> bool:
    """Verify bearer token using constant-time comparison.

    Args:
        credentials: The HTTP authorization credentials.
        expected_token: The expected token to compare against.

    Returns:
        True if token matches, False otherwise.
    """
    return hmac.compare_digest(credentials.credentials, expected_token)


def get_auth_dependency(token: str) -> Callable:
    """Create a FastAPI dependency that validates bearer token auth.

    Args:
        token: The expected bearer token.

    Returns:
        A FastAPI Depends callable that raises 401 on invalid/missing tokens.
    """

    async def _verify(
        credentials: HTTPAuthorizationCredentials = Depends(_bearer_scheme),
    ) -> HTTPAuthorizationCredentials:
        if not verify_token(credentials, token):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or missing authentication token",
            )
        return credentials

    return _verify


def generate_token() -> str:
    """Generate a cryptographically secure URL-safe token.

    Returns:
        A 32-byte URL-safe token string.
    """
    return secrets.token_urlsafe(32)
