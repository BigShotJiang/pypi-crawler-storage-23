"""Device code authentication flow for headless environments.

Provides device code flow for authenticating with Obra when a browser
is not available (e.g., SSH sessions, containers, CI/CD).
"""

import logging
import time
from http import HTTPStatus
from typing import Any

import requests  # type: ignore[import-untyped]

from obra.config import DEFAULT_NETWORK_TIMEOUT, FIREBASE_API_KEY
from obra.exceptions import AuthenticationError

from .types import AuthResult

logger = logging.getLogger(__name__)

# Firebase REST API endpoint for custom token exchange
FIREBASE_CUSTOM_TOKEN_ENDPOINT = (
    "https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken"
)


def login_with_device_code(
    timeout: float = 600,
    api_base_url: str | None = None,
) -> AuthResult:
    """Authenticate using the device code flow.

    Initiates a device code flow with the server, displays a URL and code
    for the user to authenticate in a browser on any device, then polls
    until authentication is complete.

    Args:
        timeout: Maximum seconds to wait for authentication (default: 10 minutes)
        api_base_url: Optional API base URL override

    Returns:
        AuthResult with user info and tokens

    Raises:
        AuthenticationError: If authentication fails, times out, or code expires
    """
    # Import here to avoid circular imports
    from obra.auth.tokens import DEFAULT_API_BASE_URL, get_user_info

    base_url = api_base_url or DEFAULT_API_BASE_URL

    # Step 1: Initiate device auth
    try:
        response = requests.post(
            f"{base_url}/initiate_device_auth",
            json={},
            timeout=DEFAULT_NETWORK_TIMEOUT,
        )
    except requests.RequestException as e:
        msg = f"Network error initiating device auth: {e}"
        raise AuthenticationError(msg) from e

    if response.status_code != HTTPStatus.OK:
        msg = f"Failed to initiate device auth: HTTP {response.status_code}"
        raise AuthenticationError(msg)

    data: Any = response.json()
    if not isinstance(data, dict):
        msg = "Invalid response from device auth endpoint"
        raise AuthenticationError(msg)

    user_code: str = data.get("user_code", "")
    device_code: str = data.get("device_code", "")
    verification_uri: str = data.get("verification_uri", "")
    interval: int = data.get("interval", 5)
    expires_in: int = data.get("expires_in", 600)

    if not user_code or not device_code or not verification_uri:
        msg = "Incomplete response from device auth endpoint"
        raise AuthenticationError(msg)

    # Step 2: Display instructions
    print(f"\nTo authenticate, visit:\n  {verification_uri}?code={user_code}")
    print(f"\nOr visit {verification_uri} and enter code: {user_code}")
    print("\nWaiting for authentication...")

    # Step 3: Poll for completion
    max_attempts = int(min(timeout, expires_in) / interval)
    custom_token: str | None = None

    for _attempt in range(max_attempts):
        time.sleep(interval)

        try:
            poll_response = requests.post(
                f"{base_url}/poll_device_auth",
                json={"device_code": device_code},
                timeout=DEFAULT_NETWORK_TIMEOUT,
            )
        except requests.RequestException as e:
            logger.warning("Poll request failed: %s", e)
            continue

        if poll_response.status_code == HTTPStatus.GONE:
            msg = "Device code expired. Please try again."
            raise AuthenticationError(msg)

        if poll_response.status_code != HTTPStatus.OK:
            logger.warning("Unexpected poll status: %s", poll_response.status_code)
            continue

        poll_data: Any = poll_response.json()
        if not isinstance(poll_data, dict):
            continue

        status = poll_data.get("status", "")

        if status == "authorization_pending":
            continue
        if status == "expired":
            msg = "Device code expired. Please try again."
            raise AuthenticationError(msg)
        if status == "completed":
            custom_token = poll_data.get("custom_token", "")
            break

    if not custom_token:
        msg = "Authentication timed out."
        raise AuthenticationError(msg)

    # Step 4: Exchange custom token for ID + refresh tokens
    try:
        token_response = requests.post(
            FIREBASE_CUSTOM_TOKEN_ENDPOINT,
            params={"key": FIREBASE_API_KEY},
            json={"token": custom_token, "returnSecureToken": True},
            timeout=DEFAULT_NETWORK_TIMEOUT,
        )
    except requests.RequestException as e:
        msg = f"Network error exchanging custom token: {e}"
        raise AuthenticationError(msg) from e

    if token_response.status_code != HTTPStatus.OK:
        msg = f"Failed to exchange custom token: HTTP {token_response.status_code}"
        raise AuthenticationError(msg)

    token_data: Any = token_response.json()
    if not isinstance(token_data, dict):
        msg = "Invalid response from token exchange"
        raise AuthenticationError(msg)

    id_token: str = token_data.get("idToken", "")
    refresh_token: str = token_data.get("refreshToken", "")

    if not id_token:
        msg = "No ID token received from token exchange"
        raise AuthenticationError(msg)

    # Step 5: Get user info
    user_info = get_user_info(id_token)

    # Step 6: Return AuthResult
    provider_info = user_info.get("providerUserInfo", [{}])
    provider_id = provider_info[0].get("providerId", "unknown") if provider_info else "unknown"

    return AuthResult(
        firebase_uid=user_info["localId"],
        email=user_info.get("email", ""),
        id_token=id_token,
        refresh_token=refresh_token,
        auth_provider=provider_id,
        display_name=user_info.get("displayName"),
    )


__all__ = ["login_with_device_code"]
