"""Allow running as `python -m rosforge`."""

from rosforge.cli.app import app

app()
