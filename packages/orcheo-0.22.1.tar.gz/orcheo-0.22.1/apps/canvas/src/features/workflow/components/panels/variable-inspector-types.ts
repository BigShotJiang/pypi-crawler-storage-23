export type VariablesMap = Record<string, unknown>;

export type VariableInspectorView = "tree" | "json" | "table";
