class WholeTableTestsWarning(RuntimeWarning):
    """Warns when the user runs tests that require the whole table on a subset of it"""
