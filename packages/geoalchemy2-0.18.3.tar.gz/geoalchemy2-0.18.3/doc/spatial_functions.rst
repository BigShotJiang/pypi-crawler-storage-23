.. _spatial_functions:

Spatial Functions
=================

.. automodule:: geoalchemy2.functions
   :members:
