.. _elements:

Elements
========

.. autoclass:: geoalchemy2.elements._SpatialElement
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: geoalchemy2.elements.WKTElement
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: geoalchemy2.elements.WKBElement
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: geoalchemy2.elements.RasterElement
   :members:
   :show-inheritance:

.. autoclass:: geoalchemy2.elements.CompositeElement
   :members:
   :show-inheritance:
