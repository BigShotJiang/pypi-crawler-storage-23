"""This module defines some dialect-specific functions used for administration tasks."""

from geoalchemy2.admin.dialects import common  # noqa
from geoalchemy2.admin.dialects import geopackage  # noqa
from geoalchemy2.admin.dialects import mariadb  # noqa
from geoalchemy2.admin.dialects import mysql  # noqa
from geoalchemy2.admin.dialects import postgresql  # noqa
from geoalchemy2.admin.dialects import sqlite  # noqa
