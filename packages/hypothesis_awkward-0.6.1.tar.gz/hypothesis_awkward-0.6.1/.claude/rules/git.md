# Git

- Do not stage or commit automatically. Let the user review changes first.
