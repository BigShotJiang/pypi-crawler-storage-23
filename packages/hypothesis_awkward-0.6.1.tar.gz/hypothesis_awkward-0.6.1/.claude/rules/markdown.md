# Markdown Style

- Always specify a language for fenced code blocks (MD040)
- Run `dprint fmt` after creating/editing markdown files
