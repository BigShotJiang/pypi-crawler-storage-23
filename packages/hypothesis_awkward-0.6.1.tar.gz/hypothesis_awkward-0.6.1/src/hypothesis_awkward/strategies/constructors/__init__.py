__all__ = ['arrays']

from .array_ import arrays
