See https://django-upgrade.readthedocs.io/en/latest/changelog.html
