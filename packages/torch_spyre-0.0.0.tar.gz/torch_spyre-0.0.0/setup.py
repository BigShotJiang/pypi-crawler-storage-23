"""
Empty setup.py for torch-spyre
"""
from setuptools import setup

setup(
    name="torch-spyre",
    version="0.0.0",
    description="Empty placeholder package - reserved name",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
