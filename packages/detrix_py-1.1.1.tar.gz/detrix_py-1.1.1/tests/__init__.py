"""Tests for Detrix Python client."""
