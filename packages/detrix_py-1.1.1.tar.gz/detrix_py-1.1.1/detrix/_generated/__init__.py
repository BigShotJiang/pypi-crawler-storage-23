# Generated code - do not edit manually
# Regenerate with: task clients:generate-python-models
from .models import (
    ClientState,
    ErrorResponse,
    HealthResponse,
    InfoResponse,
    Service,
    SleepResponse,
    Status,
    StatusResponse,
    WakeRequest,
    WakeResponse,
)
from .models import (
    Status1 as WakeStatus,
)
from .models import (
    Status2 as SleepStatus,
)

__all__ = [
    "ClientState",
    "ErrorResponse",
    "HealthResponse",
    "InfoResponse",
    "Service",
    "SleepResponse",
    "SleepStatus",
    "Status",
    "StatusResponse",
    "WakeRequest",
    "WakeResponse",
    "WakeStatus",
]
