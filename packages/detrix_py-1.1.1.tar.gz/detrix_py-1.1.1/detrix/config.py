"""Configuration management for Detrix Python client."""

import os
import socket
from pathlib import Path

AUTH_TOKEN_FILENAME = "auth-token"


def get_detrix_home(override: str | None = None) -> Path:
    """Get the Detrix home directory.

    Args:
        override: Optional path override

    Returns:
        Path to Detrix home directory (default: ~/detrix)
    """
    if override:
        return Path(override)

    env_home = os.environ.get("DETRIX_HOME")
    if env_home:
        return Path(env_home)

    return Path.home() / "detrix"


def get_token_file_path(detrix_home: Path | None = None) -> Path:
    """Get the path to the auth token file.

    Args:
        detrix_home: Optional Detrix home directory

    Returns:
        Path to auth-token file
    """
    home = detrix_home or get_detrix_home()
    return home / AUTH_TOKEN_FILENAME


def get_free_port() -> int:
    """Get a free port assigned by the OS.

    Returns:
        Available port number
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        s.listen(1)
        port: int = s.getsockname()[1]
    return port


def generate_connection_name(name: str) -> str:
    """Generate a connection name.

    If a name is provided, uses it as-is (consistent with Go and Rust clients).
    If empty, generates a default name as "detrix-client-{pid}".

    Args:
        name: Connection name. If empty, auto-generates with PID.

    Returns:
        Connection name string
    """
    if name:
        return name
    return f"detrix-client-{os.getpid()}"


def get_env_config() -> dict[str, str | bool | None]:
    """Get configuration from environment variables.

    Supported environment variables:
        DETRIX_NAME: Connection name
        DETRIX_CONTROL_HOST: Host for control plane server
        DETRIX_CONTROL_PORT: Port for control plane server
        DETRIX_DEBUG_PORT: Port for debugpy
        DETRIX_DAEMON_URL: URL of the Detrix daemon
        DETRIX_TOKEN: Authentication token
        DETRIX_HEALTH_CHECK_TIMEOUT: Timeout for daemon health checks (seconds)
        DETRIX_REGISTER_TIMEOUT: Timeout for connection registration (seconds)
        DETRIX_UNREGISTER_TIMEOUT: Timeout for connection unregistration (seconds)
        DETRIX_WORKSPACE_ROOT: Override workspace root (default: cwd)
        DETRIX_VERIFY_SSL: Whether to verify SSL certificates (default: true)
        DETRIX_CA_BUNDLE: Path to CA bundle file for SSL verification

    Returns:
        Dictionary with configuration values from environment
    """
    # Parse DETRIX_VERIFY_SSL (default: true)
    verify_ssl_str = os.environ.get("DETRIX_VERIFY_SSL", "true").lower()
    verify_ssl = verify_ssl_str not in ("false", "0", "no", "off")

    # Get CA bundle path (validated at usage time)
    ca_bundle = os.environ.get("DETRIX_CA_BUNDLE")

    return {
        "name": os.environ.get("DETRIX_NAME"),
        "advertise_host": os.environ.get("DETRIX_HOST"),
        "control_host": os.environ.get("DETRIX_CONTROL_HOST"),
        "control_port": os.environ.get("DETRIX_CONTROL_PORT"),
        "debug_port": os.environ.get("DETRIX_DEBUG_PORT"),
        "daemon_url": os.environ.get("DETRIX_DAEMON_URL"),
        "workspace_root": os.environ.get("DETRIX_WORKSPACE_ROOT"),
        "token": os.environ.get("DETRIX_TOKEN"),
        "health_check_timeout": os.environ.get("DETRIX_HEALTH_CHECK_TIMEOUT"),
        "register_timeout": os.environ.get("DETRIX_REGISTER_TIMEOUT"),
        "unregister_timeout": os.environ.get("DETRIX_UNREGISTER_TIMEOUT"),
        "verify_ssl": verify_ssl,
        "ca_bundle": ca_bundle,
    }
