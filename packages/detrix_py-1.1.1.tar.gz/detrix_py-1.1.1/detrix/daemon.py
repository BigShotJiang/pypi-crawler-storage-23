"""Daemon client for communicating with Detrix daemon.

This module provides an abstraction layer for communicating with the Detrix
daemon. It defines a DaemonClient Protocol for testability and provides
a default HTTP implementation using httpx.

Example:
    # Using module-level convenience functions
    if check_daemon_health("http://127.0.0.1:8090"):
        connection_id = register_connection(
            daemon_url="http://127.0.0.1:8090",
            host="127.0.0.1",
            port=5678,
            connection_id="my-service-123",
            token=None,
        )

    # Using the client class directly (for custom configuration)
    client = HttpDaemonClient("http://127.0.0.1:8090")
    if client.health_check():
        connection_id = client.register("127.0.0.1", 5678, "my-service-123")
"""

import contextlib
import logging
import ssl
from pathlib import Path
from typing import Protocol, runtime_checkable

import httpx

from .errors import ConfigError, DaemonError

_logger = logging.getLogger("detrix.daemon")

# Backward compatibility: DaemonConnectionError is the historical name
# New code should use DaemonError from errors.py
DaemonConnectionError = DaemonError


@runtime_checkable
class DaemonClient(Protocol):
    """Protocol for daemon communication.

    This protocol defines the interface for communicating with the Detrix
    daemon. It enables dependency injection and easy mocking in tests.

    Implementations:
        - HttpDaemonClient: Default HTTP-based implementation using httpx

    Example for testing:
        class MockDaemonClient:
            def health_check(self, timeout: float = 2.0) -> bool:
                return True

            def register(self, host: str, port: int, connection_id: str,
                        token: Optional[str] = None) -> str:
                return connection_id

            def unregister(self, connection_id: str,
                          token: Optional[str] = None) -> None:
                pass

        # Use in tests
        mock_client = MockDaemonClient()
        assert isinstance(mock_client, DaemonClient)
    """

    def health_check(self, timeout: float = 2.0) -> bool:
        """Check if daemon is reachable and healthy.

        Args:
            timeout: Request timeout in seconds

        Returns:
            True if daemon is healthy, False otherwise
        """
        ...

    def register(
        self,
        host: str,
        port: int,
        connection_id: str,
        token: str | None = None,
        timeout: float = 5.0,
    ) -> tuple[str, str | None]:
        """Register a DAP connection with the daemon.

        Args:
            host: Host where debugpy is listening
            port: Port where debugpy is listening
            connection_id: Unique connection identifier
            token: Optional authentication token
            timeout: Request timeout in seconds

        Raises:
            DaemonError: If daemon is not reachable or registration fails

        Returns:
            Tuple of (connection_id, advertise_url) from daemon response
        """
        ...

    def unregister(
        self,
        connection_id: str,
        token: str | None = None,
        timeout: float = 2.0,
    ) -> None:
        """Unregister connection from daemon.

        Args:
            connection_id: Connection ID to unregister
            token: Optional authentication token
            timeout: Request timeout in seconds

        Note:
            Errors are typically ignored (best effort cleanup).
        """
        ...

    def fetch_advertise_url(self, timeout: float = 2.0) -> str | None:
        """Fetch the daemon's advertise URL from its health endpoint.

        Args:
            timeout: Request timeout in seconds

        Returns:
            The daemon's advertise URL, or None if not configured or unreachable.
        """
        ...


class HttpDaemonClient:
    """HTTP-based implementation of DaemonClient using httpx.

    This is the default implementation that communicates with the Detrix
    daemon over HTTP/HTTPS. Uses httpx for:
    - Connection pooling (automatic keep-alive)
    - Better timeout handling
    - HTTP/2 support (when server supports it)

    Args:
        base_url: Base URL of the daemon (e.g., "http://127.0.0.1:8090")
        connect_timeout: Timeout for establishing connections (default: 2.0s)
        default_timeout: Default timeout for requests (default: 5.0s)

    Example:
        client = HttpDaemonClient("http://127.0.0.1:8090")
        if client.health_check():
            conn_id = client.register("127.0.0.1", 5678, "my-service")
        client.close()  # Close connection pool when done

        # Or use as context manager:
        with HttpDaemonClient("http://127.0.0.1:8090") as client:
            if client.health_check():
                conn_id = client.register("127.0.0.1", 5678, "my-service")
    """

    def __init__(
        self,
        base_url: str,
        connect_timeout: float = 2.0,
        default_timeout: float = 5.0,
        verify_ssl: bool = True,
        ca_bundle: str | None = None,
    ):
        """Initialize the HTTP daemon client.

        Args:
            base_url: Base URL of the daemon (e.g., "http://127.0.0.1:8090")
            connect_timeout: Timeout for establishing connections
            default_timeout: Default timeout for requests
            verify_ssl: Whether to verify SSL certificates (default: True)
            ca_bundle: Path to CA bundle file for SSL verification

        Raises:
            ConfigError: If ca_bundle is provided but the file doesn't exist
        """
        # Validate CA bundle if provided (fail fast)
        if ca_bundle and not Path(ca_bundle).is_file():
            raise ConfigError(f"CA bundle not found: {ca_bundle}")

        self.base_url = base_url.rstrip("/")
        self._connect_timeout = connect_timeout
        self._default_timeout = default_timeout

        # Configure SSL verification
        if ca_bundle:
            ssl_context = ssl.create_default_context(cafile=ca_bundle)
            verify: ssl.SSLContext | bool = ssl_context
        else:
            verify = verify_ssl

        # Create a client with connection pooling
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=httpx.Timeout(default_timeout, connect=connect_timeout),
            verify=verify,
        )

    def __enter__(self) -> "HttpDaemonClient":
        """Context manager entry."""
        return self

    def __exit__(self, *args: object) -> None:
        """Context manager exit - close the client."""
        self.close()

    def close(self) -> None:
        """Close the HTTP client and release connections."""
        self._client.close()

    def health_check(self, timeout: float = 2.0) -> bool:
        """Check if daemon is reachable and healthy.

        Args:
            timeout: Request timeout in seconds

        Returns:
            True if daemon is healthy, False otherwise
        """
        try:
            response = self._client.get("/health", timeout=timeout)
            if response.status_code == 200:
                data = response.json()
                return bool(data.get("service") == "detrix")
        except (httpx.HTTPError, ValueError) as e:
            _logger.debug("Health check failed: %s", e)
        return False

    def fetch_advertise_url(self, timeout: float = 2.0) -> str | None:
        """Fetch the daemon's advertise URL from its health endpoint.

        Returns None if not configured or daemon unreachable.

        Args:
            timeout: Request timeout in seconds

        Returns:
            The daemon's advertise URL, or None if not configured or unreachable.
        """
        try:
            response = self._client.get("/health", timeout=timeout)
            if response.status_code == 200:
                data = response.json()
                return data.get("advertiseUrl") or None
        except (httpx.HTTPError, ValueError) as e:
            _logger.debug("Failed to fetch advertise URL: %s", e)
        return None

    def register(
        self,
        host: str,
        port: int,
        connection_id: str,
        token: str | None = None,
        timeout: float = 5.0,
        control_plane_url: str | None = None,
        workspace_root: str | None = None,
    ) -> tuple[str, str | None]:
        """Register a DAP connection with the daemon.

        Args:
            host: Host where debugpy is listening
            port: Port where debugpy is listening
            connection_id: Unique connection identifier (user-facing name)
            token: Optional authentication token
            timeout: Request timeout in seconds
            control_plane_url: URL of this client's control plane for file fetching
            workspace_root: Override workspace root (default: cwd or DETRIX_WORKSPACE_ROOT)

        Raises:
            DaemonError: If daemon is not reachable or registration fails

        Returns:
            Tuple of (connection_id, advertise_url) from daemon response
        """
        import os
        import socket

        # Build identity fields for UUID-based connection tracking
        if not workspace_root:
            workspace_root = os.environ.get("DETRIX_WORKSPACE_ROOT", "")
        if not workspace_root:
            try:
                workspace_root = os.getcwd()
            except OSError:
                workspace_root = ""

        try:
            hostname = socket.gethostname()
        except OSError:
            hostname = "unknown"

        payload: dict[str, object] = {
            "host": host,
            "port": port,
            "language": "python",
            "name": connection_id,  # User-facing name
            "workspaceRoot": workspace_root,
            "hostname": hostname,
        }

        # Include control plane URL so the daemon can fetch files from us
        if control_plane_url:
            payload["controlPlaneUrl"] = control_plane_url

        # Auto-detect build commit from CI environment variables
        build_commit = (
            os.environ.get("GIT_COMMIT")
            or os.environ.get("CI_COMMIT_SHA")
            or os.environ.get("GITHUB_SHA")
        )
        if build_commit:
            payload["buildCommit"] = build_commit

        github_ref_tag = (
            os.environ.get("GITHUB_REF_NAME")
            if os.environ.get("GITHUB_REF_TYPE") == "tag"
            else None
        )
        build_tag = os.environ.get("GIT_TAG") or os.environ.get("CI_COMMIT_TAG") or github_ref_tag
        if build_tag:
            payload["buildTag"] = build_tag

        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        try:
            response = self._client.post(
                "/api/v1/connections",
                json=payload,
                headers=headers,
                timeout=timeout,
            )
            response.raise_for_status()
            data = response.json()
            result_id: str = data.get("connectionId", connection_id)
            advertise_url: str | None = data.get("advertiseUrl")
            return result_id, advertise_url
        except httpx.HTTPStatusError as e:
            raise DaemonError(
                f"Failed to register connection: HTTP {e.response.status_code} - "
                f"{e.response.reason_phrase}"
            ) from e
        except httpx.ConnectError as e:
            raise DaemonError(f"Cannot connect to daemon at {self.base_url}: {e}") from e
        except httpx.HTTPError as e:
            raise DaemonError(f"Cannot connect to daemon at {self.base_url}: {e}") from e

    def unregister(
        self,
        connection_id: str,
        token: str | None = None,
        timeout: float = 2.0,
    ) -> None:
        """Unregister connection from daemon.

        Args:
            connection_id: Connection ID to unregister
            token: Optional authentication token
            timeout: Request timeout in seconds

        Note:
            Errors are ignored (best effort cleanup).
        """
        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        # Best effort - ignore errors during cleanup
        with contextlib.suppress(httpx.HTTPError):
            self._client.delete(
                f"/api/v1/connections/{connection_id}",
                headers=headers,
                timeout=timeout,
            )


# Module-level convenience functions that use HttpDaemonClient
# These maintain backward compatibility with existing code
# Note: These create a new client for each call. For repeated calls,
# prefer using HttpDaemonClient directly for connection reuse.


def check_daemon_health(
    daemon_url: str,
    timeout: float = 2.0,
    verify_ssl: bool = True,
    ca_bundle: str | None = None,
) -> bool:
    """Check if daemon is reachable and healthy.

    This is a convenience wrapper around HttpDaemonClient.health_check().

    Args:
        daemon_url: Base URL of the daemon (e.g., http://127.0.0.1:8090)
        timeout: Request timeout in seconds
        verify_ssl: Whether to verify SSL certificates (default: True)
        ca_bundle: Path to CA bundle file for SSL verification

    Returns:
        True if daemon is healthy, False otherwise
    """
    with HttpDaemonClient(daemon_url, verify_ssl=verify_ssl, ca_bundle=ca_bundle) as client:
        return client.health_check(timeout=timeout)


def register_connection(
    daemon_url: str,
    host: str,
    port: int,
    connection_id: str,
    token: str | None,
    timeout: float = 5.0,
    verify_ssl: bool = True,
    ca_bundle: str | None = None,
    control_plane_url: str | None = None,
) -> tuple[str, str | None]:
    """Register a DAP connection with the daemon.

    This is a convenience wrapper around HttpDaemonClient.register().

    Args:
        daemon_url: Base URL of the daemon
        host: Host where debugpy is listening
        port: Port where debugpy is listening
        connection_id: Unique connection identifier
        token: Optional authentication token
        timeout: Request timeout in seconds
        verify_ssl: Whether to verify SSL certificates (default: True)
        ca_bundle: Path to CA bundle file for SSL verification
        control_plane_url: URL of this client's control plane for file fetching

    Raises:
        DaemonError: If daemon is not reachable or registration fails

    Returns:
        Tuple of (connection_id, advertise_url) from daemon response
    """
    with HttpDaemonClient(daemon_url, verify_ssl=verify_ssl, ca_bundle=ca_bundle) as client:
        return client.register(host, port, connection_id, token, timeout, control_plane_url)


def unregister_connection(
    daemon_url: str,
    connection_id: str,
    token: str | None,
    timeout: float = 2.0,
    verify_ssl: bool = True,
    ca_bundle: str | None = None,
) -> None:
    """Unregister connection from daemon.

    This is a convenience wrapper around HttpDaemonClient.unregister().

    Args:
        daemon_url: Base URL of the daemon
        connection_id: Connection ID to unregister
        token: Optional authentication token
        timeout: Request timeout in seconds
        verify_ssl: Whether to verify SSL certificates (default: True)
        ca_bundle: Path to CA bundle file for SSL verification

    Note:
        Errors are ignored (best effort cleanup).
    """
    with HttpDaemonClient(daemon_url, verify_ssl=verify_ssl, ca_bundle=ca_bundle) as client:
        client.unregister(connection_id, token, timeout)
