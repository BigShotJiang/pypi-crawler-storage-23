"""Jabs Vision TIMM based models and code."""
