"""Constants for Fabric OneLake ingestion."""

# Default schema for schemas-disabled Fabric Lakehouses
# Fabric Lakehouses without explicit schemas use "dbo" as the default schema
DEFAULT_SCHEMA_SCHEMALESS_LAKEHOUSE = "dbo"
