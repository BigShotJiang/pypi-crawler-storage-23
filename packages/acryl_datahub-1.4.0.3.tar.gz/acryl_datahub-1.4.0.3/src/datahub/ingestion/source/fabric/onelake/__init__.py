"""Microsoft Fabric OneLake ingestion source for DataHub."""

from datahub.ingestion.source.fabric.onelake.source import FabricOneLakeSource

__all__ = ["FabricOneLakeSource"]
