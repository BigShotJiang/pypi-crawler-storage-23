# This module previously contained the Document API.
# The Document SDK has been moved to datahub.sdk.document
# Use: from datahub.sdk import Document

__all__: list[str] = []
