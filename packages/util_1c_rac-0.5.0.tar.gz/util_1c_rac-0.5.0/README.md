# Utils for 1C:Enterprise Remote Administration Client
