from __future__ import annotations

from dataclasses import dataclass
from typing import AsyncIterator

from flyte._initialize import ensure_client, get_client, get_init_config
from flyte.remote._common import ToJSONMixin
from flyte.syncify import syncify

from flyteplugins.union.internal.common import list_pb2
from flyteplugins.union.internal.common.authorization_pb2 import Action
from flyteplugins.union.internal.common.identifier_pb2 import RoleIdentifier
from flyteplugins.union.internal.common.role_pb2 import ROLE_TYPE_CUSTOM, RoleSpec
from flyteplugins.union.internal.common.role_pb2 import Role as RolePb2
from flyteplugins.union.internal.identity.role_payload_pb2 import (
    CreateRoleRequest,
    DeleteRoleRequest,
    GetRoleRequest,
    ListRolesRequest,
    UpdateRoleRequest,
)
from flyteplugins.union.internal.identity.role_service_pb2_grpc import RoleServiceStub


def _resolve_action_name(name: str) -> str:
    """Normalize an action name to match the proto enum.

    Accepts short names like ``"read"`` or full names like ``"ACTION_READ"``.
    """
    upper = name.strip().upper()
    if not upper.startswith("ACTION_"):
        upper = f"ACTION_{upper}"
    return upper


@dataclass
class Role(ToJSONMixin):
    """Represents a Union RBAC Role."""

    pb2: RolePb2

    @property
    def name(self) -> str:
        return self.pb2.id.name

    @property
    def organization(self) -> str:
        return self.pb2.id.organization

    @property
    def description(self) -> str:
        return self.pb2.role_spec.description

    @property
    def role_type(self) -> str:
        return self.pb2.role_type

    @property
    def actions(self) -> list[str]:
        return [Action.Name(a) for a in self.pb2.actions]

    def __rich_repr__(self):
        yield "name", self.name
        yield "organization", self.organization
        yield "description", self.description

    @syncify
    @classmethod
    async def create(cls, name: str, *, description: str = "", actions: list[str] | None = None) -> Role:
        """Create a new role."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = RoleServiceStub(client._channel)

        resolved = [Action.Value(_resolve_action_name(a)) for a in (actions or [])]
        role = RolePb2(
            id=RoleIdentifier(organization=org, name=name),
            role_spec=RoleSpec(description=description),
            role_type=ROLE_TYPE_CUSTOM,
            actions=resolved,
        )
        request = CreateRoleRequest(role=role)
        await stub.CreateRole(request)

        return await cls.get.aio(name)

    @syncify
    @classmethod
    async def get(cls, name: str) -> Role:
        """Get a role by name."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = RoleServiceStub(client._channel)

        request = GetRoleRequest(id=RoleIdentifier(organization=org, name=name))
        response = await stub.GetRole(request)
        return cls(pb2=response.role)

    @syncify
    @classmethod
    async def delete(cls, name: str) -> None:
        """Delete a role."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = RoleServiceStub(client._channel)

        request = DeleteRoleRequest(id=RoleIdentifier(organization=org, name=name))
        await stub.DeleteRole(request)

    @syncify
    @classmethod
    async def update(cls, name: str, *, description: str = "", actions: list[str] | None = None) -> None:
        """Update a role."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = RoleServiceStub(client._channel)

        resolved = [Action.Value(_resolve_action_name(a)) for a in (actions or [])]
        role = RolePb2(
            id=RoleIdentifier(organization=org, name=name),
            role_spec=RoleSpec(description=description),
            role_type=ROLE_TYPE_CUSTOM,
            actions=resolved,
        )
        request = UpdateRoleRequest(role=role)
        await stub.UpdateRole(request)

    @syncify
    @classmethod
    async def listall(cls, *, limit: int = 100) -> AsyncIterator[Role]:
        """List all roles in the organization."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = RoleServiceStub(client._channel)

        request = ListRolesRequest(
            organization=org,
            request=list_pb2.ListRequest(limit=limit),
        )
        response = await stub.List(request)

        for role in response.roles:
            yield cls(pb2=role)
