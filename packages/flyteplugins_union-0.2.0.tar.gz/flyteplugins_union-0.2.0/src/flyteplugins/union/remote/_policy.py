from __future__ import annotations

from dataclasses import dataclass
from typing import AsyncIterator

from flyte._initialize import ensure_client, get_client, get_init_config
from flyte.remote._common import ToJSONMixin
from flyte.syncify import syncify

from flyteplugins.union.internal.common import list_pb2
from flyteplugins.union.internal.common.authorization_pb2 import (
    Domain,
    Organization,
    Project,
    Resource,
)
from flyteplugins.union.internal.common.identifier_pb2 import PolicyIdentifier, RoleIdentifier
from flyteplugins.union.internal.common.policy_pb2 import Policy as PolicyPb2
from flyteplugins.union.internal.common.policy_pb2 import PolicyBinding
from flyteplugins.union.internal.identity.policy_payload_pb2 import (
    CreatePolicyBindingRequest,
    CreatePolicyRequest,
    DeletePolicyBindingRequest,
    DeletePolicyRequest,
    GetPolicyRequest,
    ListPoliciesRequest,
)
from flyteplugins.union.internal.identity.policy_service_pb2_grpc import PolicyServiceStub


def _binding_to_dict(binding: PolicyBinding) -> dict:
    """Convert a PolicyBinding protobuf to a plain dict."""
    d: dict = {"role": binding.role_id.name}
    res = binding.resource
    resource: dict = {}
    if res.HasField("organization"):
        resource["organization"] = res.organization.name
    if res.HasField("domain"):
        resource["domain"] = res.domain.name
    if res.HasField("project"):
        resource["project"] = res.project.name
    if resource:
        d["resource"] = resource
    return d


def _dict_to_binding(d: dict, org: str) -> PolicyBinding:
    """Convert a plain dict to a PolicyBinding protobuf."""
    role_name = d["role"]
    res = d.get("resource") or {}

    resource_org = res.get("organization", org)
    resource_kwargs: dict = {"organization": Organization(name=resource_org)}
    if "domain" in res:
        resource_kwargs["domain"] = Domain(
            name=res["domain"],
            organization=Organization(name=resource_org),
        )
    if "project" in res:
        domain_name = res.get("domain", "")
        resource_kwargs["project"] = Project(
            name=res["project"],
            domain=Domain(
                name=domain_name,
                organization=Organization(name=resource_org),
            ),
        )

    return PolicyBinding(
        role_id=RoleIdentifier(organization=org, name=role_name),
        resource=Resource(**resource_kwargs),
    )


@dataclass
class Policy(ToJSONMixin):
    """Represents a Union RBAC Policy."""

    pb2: PolicyPb2

    @property
    def name(self) -> str:
        return self.pb2.id.name

    @property
    def organization(self) -> str:
        return self.pb2.id.organization

    @property
    def description(self) -> str:
        return self.pb2.description

    @property
    def bindings(self) -> list[dict]:
        return [_binding_to_dict(b) for b in self.pb2.bindings]

    def __rich_repr__(self):
        yield "name", self.name
        yield "organization", self.organization
        yield "description", self.description

    @syncify
    @classmethod
    async def create(cls, name: str, *, description: str = "", bindings: list[dict] | None = None) -> Policy:
        """Create a new policy."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = PolicyServiceStub(client._channel)

        policy = PolicyPb2(
            id=PolicyIdentifier(organization=org, name=name),
            description=description,
        )
        await stub.CreatePolicy(CreatePolicyRequest(policy=policy))

        if bindings:
            policy_id = PolicyIdentifier(organization=org, name=name)
            for b in bindings:
                pb_binding = _dict_to_binding(b, org)
                await stub.CreatePolicyBinding(CreatePolicyBindingRequest(id=policy_id, binding=pb_binding))

        return await cls.get.aio(name)

    @syncify
    @classmethod
    async def update(cls, name: str, old_bindings: list[dict], new_bindings: list[dict]) -> Policy:
        """Update a policy by diffing bindings and applying add/remove operations."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = PolicyServiceStub(client._channel)

        policy_id = PolicyIdentifier(organization=org, name=name)

        old_pb = [_dict_to_binding(b, org) for b in old_bindings]
        new_pb = [_dict_to_binding(b, org) for b in new_bindings]

        old_set = {b.SerializeToString() for b in old_pb}
        new_set = {b.SerializeToString() for b in new_pb}

        # Delete removed bindings
        for b in old_pb:
            if b.SerializeToString() not in new_set:
                await stub.DeletePolicyBinding(DeletePolicyBindingRequest(id=policy_id, binding=b))

        # Add new bindings
        for b in new_pb:
            if b.SerializeToString() not in old_set:
                await stub.CreatePolicyBinding(CreatePolicyBindingRequest(id=policy_id, binding=b))

        return await cls.get.aio(name)

    @syncify
    @classmethod
    async def get(cls, name: str) -> Policy:
        """Get a policy by name."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = PolicyServiceStub(client._channel)

        request = GetPolicyRequest(id=PolicyIdentifier(organization=org, name=name))
        response = await stub.GetPolicy(request)
        return cls(pb2=response.policy)

    @syncify
    @classmethod
    async def delete(cls, name: str) -> None:
        """Delete a policy."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = PolicyServiceStub(client._channel)

        request = DeletePolicyRequest(id=PolicyIdentifier(organization=org, name=name))
        await stub.DeletePolicy(request)

    @syncify
    @classmethod
    async def listall(cls, *, limit: int = 100) -> AsyncIterator[Policy]:
        """List all policies in the organization."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = PolicyServiceStub(client._channel)

        request = ListPoliciesRequest(
            organization=org,
            request=list_pb2.ListRequest(limit=limit),
        )
        response = await stub.List(request)

        for policy in response.policies:
            yield cls(pb2=policy)
