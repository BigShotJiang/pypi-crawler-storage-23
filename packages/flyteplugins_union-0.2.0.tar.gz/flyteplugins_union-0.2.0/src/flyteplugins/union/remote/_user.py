from __future__ import annotations

from dataclasses import dataclass
from typing import AsyncIterator

from flyte._initialize import ensure_client, get_client, get_init_config
from flyte.remote._common import ToJSONMixin
from flyte.syncify import syncify

from flyteplugins.union.internal.common import list_pb2
from flyteplugins.union.internal.common.identifier_pb2 import UserIdentifier
from flyteplugins.union.internal.common.identity_pb2 import User as UserPb2
from flyteplugins.union.internal.identity.user_payload_pb2 import (
    DeleteUserRequest,
    GetUserRequest,
    ListUsersRequest,
)
from flyteplugins.union.internal.identity.user_service_pb2_grpc import UserServiceStub


@dataclass
class User(ToJSONMixin):
    """Represents a Union user."""

    pb2: UserPb2

    @property
    def subject(self) -> str:
        return self.pb2.id.subject

    @property
    def email(self) -> str:
        return self.pb2.spec.email

    @property
    def first_name(self) -> str:
        return self.pb2.spec.first_name

    @property
    def last_name(self) -> str:
        return self.pb2.spec.last_name

    def __rich_repr__(self):
        yield "subject", self.subject
        yield "email", self.email
        yield "first_name", self.first_name
        yield "last_name", self.last_name

    @syncify
    @classmethod
    async def get(cls, subject: str) -> User:
        """Get a user by subject identifier."""
        ensure_client()
        client = get_client()
        stub = UserServiceStub(client._channel)

        request = GetUserRequest(id=UserIdentifier(subject=subject))
        response = await stub.GetUser(request)
        return cls(pb2=response.user)

    @syncify
    @classmethod
    async def delete(cls, subject: str) -> None:
        """Delete a user."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = UserServiceStub(client._channel)

        request = DeleteUserRequest(
            id=UserIdentifier(subject=subject),
            organization=org,
        )
        await stub.DeleteUser(request)

    @syncify
    @classmethod
    async def listall(cls, *, limit: int = 100) -> AsyncIterator[User]:
        """List all users in the organization."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = UserServiceStub(client._channel)

        request = ListUsersRequest(
            organization=org,
            request=list_pb2.ListRequest(limit=limit),
        )
        response = await stub.ListUsers(request)

        for user in response.users:
            yield cls(pb2=user)
