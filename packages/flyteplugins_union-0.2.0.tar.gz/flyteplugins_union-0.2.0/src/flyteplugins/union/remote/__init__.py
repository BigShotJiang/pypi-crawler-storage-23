"""Union remote control plane objects.

This module provides remote object classes for Union-specific control plane
entities, following the same pattern as flyte.remote objects.

Example:
    from flyteplugins.union.remote import ApiKey

    # List all API keys
    keys = ApiKey.listall()
    for key in keys:
        print(key.client_id)

    # Create a new API key
    api_key = ApiKey.create(name="my-ci-key")
    print(api_key.client_secret)

    # Get a specific API key
    key = ApiKey.get(client_id="my-client-id")

    # Delete an API key
    ApiKey.delete(client_id="my-client-id")
"""

from flyteplugins.union.remote._api_key import ApiKey
from flyteplugins.union.remote._member import Member
from flyteplugins.union.remote._policy import Policy
from flyteplugins.union.remote._role import Role
from flyteplugins.union.remote._user import User

__all__ = ["ApiKey", "Member", "Policy", "Role", "User"]
