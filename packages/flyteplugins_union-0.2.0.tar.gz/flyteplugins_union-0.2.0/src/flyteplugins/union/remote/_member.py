from __future__ import annotations

from dataclasses import dataclass
from typing import AsyncIterator

from flyte._initialize import ensure_client, get_client, get_init_config
from flyte.remote._common import ToJSONMixin
from flyte.syncify import syncify

from flyteplugins.union.internal.common.identity_pb2 import EnrichedIdentity
from flyteplugins.union.internal.identity.member_payload_pb2 import ListMembersRequest
from flyteplugins.union.internal.identity.member_service_pb2_grpc import MemberServiceStub


@dataclass
class Member(ToJSONMixin):
    """Represents a Union organization member (user or application)."""

    pb2: EnrichedIdentity

    @property
    def is_user(self) -> bool:
        return self.pb2.HasField("user")

    @property
    def is_application(self) -> bool:
        return self.pb2.HasField("application")

    @property
    def identity_type(self) -> str:
        if self.is_user:
            return "user"
        if self.is_application:
            return "application"
        return "unknown"

    @property
    def subject(self) -> str:
        if self.is_user:
            return self.pb2.user.id.subject
        if self.is_application:
            return self.pb2.application.id.subject
        return ""

    @property
    def name(self) -> str:
        if self.is_user:
            spec = self.pb2.user.spec
            full = f"{spec.first_name} {spec.last_name}".strip()
            return full or spec.email
        if self.is_application:
            return self.pb2.application.spec.name
        return ""

    def __rich_repr__(self):
        yield "type", self.identity_type
        yield "subject", self.subject
        yield "name", self.name

    @syncify
    @classmethod
    async def listall(cls) -> AsyncIterator[Member]:
        """List all members in the organization."""
        ensure_client()
        client = get_client()
        org = get_init_config().org
        stub = MemberServiceStub(client._channel)

        request = ListMembersRequest(organization=org)
        response = await stub.ListMembers(request)

        for member in response.members:
            yield cls(pb2=member)
