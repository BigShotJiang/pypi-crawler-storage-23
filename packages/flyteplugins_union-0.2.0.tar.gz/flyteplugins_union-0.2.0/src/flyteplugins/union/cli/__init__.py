import tempfile

import rich_click as click


def edit_with_retry(yaml_text: str, apply_fn, *, console, noun: str = "resource"):
    """Open an editor and retry or save to file on failure.

    Args:
        yaml_text: Initial YAML content to edit.
        apply_fn: Callable that takes the edited YAML string and applies it.
                  Should raise on failure.
        console: Rich console for output.
        noun: Name of the resource for messages (e.g. "role", "policy").

    Returns:
        The result of apply_fn on success, or None if cancelled.
    """
    edited = click.edit(yaml_text, extension=".yaml")
    if edited is None:
        console.print(f"[yellow]Edit cancelled, {noun} not modified.[/yellow]")
        return None

    while True:
        try:
            return apply_fn(edited)
        except Exception as e:
            console.print(f"[red]Error:[/red] {e}\n")
            action = click.prompt(
                "Would you like to (r)etry editing, (s)ave to file, or (a)bort?",
                type=click.Choice(["r", "s", "a"], case_sensitive=False),
                default="r",
            )
            if action == "r":
                edited = click.edit(edited, extension=".yaml")
                if edited is None:
                    console.print(f"[yellow]Edit cancelled, {noun} not modified.[/yellow]")
                    return None
            elif action == "s":
                tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", prefix=f"{noun}-", delete=False)
                tmp.write(edited)
                tmp.close()
                console.print(f"[cyan]Saved to {tmp.name}[/cyan]")
                console.print(f"You can retry with: [cyan]--file {tmp.name}[/cyan]")
                return None
            else:
                console.print(f"[yellow]Aborted, {noun} not modified.[/yellow]")
                return None
