import rich_click as click
import yaml as _yaml
from flyte.cli import _common as common

from flyteplugins.union.cli import edit_with_retry
from flyteplugins.union.remote import Policy

_BINDING_COMMENT = (
    "# Each binding maps a role to a resource scope.\n"
    "# Organization is inherited from your config.\n"
    "# Resource fields (all optional): domain, project\n"
    "#\n"
    "# Example binding:\n"
    "#   - role: my-role\n"
    "#     resource:\n"
    "#       domain: production\n"
    "#       project: my-project\n"
)


def _new_policy_yaml(name: str, description: str = "") -> str:
    """Generate a YAML template for creating a new policy."""
    data = {"name": name, "description": description, "bindings": []}
    body = _yaml.safe_dump(data, default_flow_style=False, sort_keys=False)
    return _BINDING_COMMENT + "\n" + body


def _policy_to_yaml(policy: Policy) -> str:
    """Serialize a Policy to YAML for interactive editing."""
    data = {"name": policy.name, "description": policy.description, "bindings": policy.bindings}
    body = _yaml.safe_dump(data, default_flow_style=False, sort_keys=False)
    return _BINDING_COMMENT + "\n" + body


@click.command("policy")
@click.argument("name", type=str)
@click.option("--file", "file_path", type=click.Path(exists=True), default=None, help="Create policy from a YAML file")
@click.option("--edit", "edit_mode", is_flag=True, help="Open an editor to configure the policy before creating")
@click.pass_obj
def create_policy(cfg: common.CLIConfig, name: str, file_path: str | None, edit_mode: bool):
    """Create a policy.

    Requires --file or --edit to specify bindings for the policy.

    Examples:

        $ flyte --org my-org create policy my-policy --edit
        $ flyte --org my-org create policy my-policy --file policy.yaml
    """
    if not file_path and not edit_mode:
        raise click.ClickException("Must specify --file or --edit to configure the policy.")

    cfg.init(project="", domain="")
    console = common.get_console()

    try:
        if file_path:
            with open(file_path) as f:
                data = _yaml.safe_load(f.read())
            policy = Policy.create(
                data["name"],
                description=data.get("description", ""),
                bindings=data.get("bindings"),
            )
        else:
            yaml_text = _new_policy_yaml(name)

            def _apply(edited_yaml):
                data = _yaml.safe_load(edited_yaml)
                return Policy.create(
                    data["name"],
                    description=data.get("description", ""),
                    bindings=data.get("bindings"),
                )

            policy = edit_with_retry(yaml_text, _apply, console=console, noun="policy")
            if policy is None:
                return

        console.print(f"[green]✓[/green] Successfully created policy: [cyan]{policy.name}[/cyan]")
    except Exception as e:
        raise click.ClickException(f"Unable to create policy: {e}") from e


@click.command("policy")
@click.argument("name", type=str, required=False)
@click.option("--limit", type=int, default=100, help="Maximum number of policies to list")
@click.pass_obj
def get_policy(cfg: common.CLIConfig, name: str | None, limit: int):
    """Get or list policies.

    If NAME is provided, gets a specific policy. Otherwise, lists all policies.

    Examples:

        $ flyte --org my-org get policy
        $ flyte --org my-org get policy --limit 10
        $ flyte --org my-org get policy my-policy
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    try:
        if name:
            policy = Policy.get(name)
            console.print(common.format(f"Policy {name}", [policy], "json"))
        else:
            policies = list(Policy.listall(limit=limit))
            if not policies:
                console.print("[yellow]No policies found.[/yellow]")
                return
            console.print(common.format("Policies", policies, cfg.output_format))
    except Exception as e:
        raise click.ClickException(f"Unable to get policy(ies): {e}") from e


@click.command("policy")
@click.argument("name", type=str)
@click.option("--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_obj
def delete_policy(cfg: common.CLIConfig, name: str, yes: bool):
    """Delete a policy.

    Examples:

        $ flyte --org my-org delete policy my-policy
        $ flyte --org my-org delete policy my-policy --yes
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    if not yes:
        click.confirm(f"Are you sure you want to delete policy '{name}' in org '{cfg.org}'?", abort=True)

    try:
        Policy.delete(name)
        console.print(f"[green]✓[/green] Successfully deleted policy: [cyan]{name}[/cyan]")
    except Exception as e:
        raise click.ClickException(f"Unable to delete policy: {e}") from e


@click.command("policy")
@click.argument("name", type=str)
@click.pass_obj
def update_policy(cfg: common.CLIConfig, name: str):
    """Update a policy interactively.

    Opens the policy in your $EDITOR as YAML. Save and close to apply changes.
    Bindings that are added or removed will be applied to the policy.

    Examples:

        $ flyte --org my-org update policy my-policy
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    try:
        policy = Policy.get(name)
    except Exception as e:
        raise click.ClickException(f"Unable to get policy '{name}': {e}") from e

    old_bindings = policy.bindings
    yaml_text = _policy_to_yaml(policy)

    def _apply(edited_yaml):
        data = _yaml.safe_load(edited_yaml)
        new_bindings = data.get("bindings") or []
        new_description = data.get("description", "")
        if new_bindings == old_bindings and new_description == policy.description:
            return "no_changes"
        Policy.update(name, old_bindings, new_bindings)

    result = edit_with_retry(yaml_text, _apply, console=console, noun="policy")
    if result == "no_changes":
        console.print("[yellow]No changes detected.[/yellow]")
    elif result is not None:
        console.print(f"[green]✓[/green] Successfully updated policy: [cyan]{name}[/cyan]")
