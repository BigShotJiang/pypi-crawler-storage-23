import rich_click as click
from flyte.cli import _common as common

from flyteplugins.union.remote import User


@click.command("user")
@click.argument("subject", type=str, required=False)
@click.option("--limit", type=int, default=100, help="Maximum number of users to list")
@click.pass_obj
def get_user(cfg: common.CLIConfig, subject: str | None, limit: int):
    """Get or list users.

    If SUBJECT is provided, gets a specific user. Otherwise, lists all users.

    Examples:

        $ flyte --org my-org get user
        $ flyte --org my-org get user --limit 10
        $ flyte --org my-org get user user-subject-id
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    try:
        if subject:
            user = User.get(subject)
            console.print(common.format(f"User {subject}", [user], "json"))
        else:
            users = list(User.listall(limit=limit))
            if not users:
                console.print("[yellow]No users found.[/yellow]")
                return
            console.print(common.format("Users", users, cfg.output_format))
    except Exception as e:
        raise click.ClickException(f"Unable to get user(s): {e}") from e


@click.command("user")
@click.argument("subject", type=str)
@click.option("--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_obj
def delete_user(cfg: common.CLIConfig, subject: str, yes: bool):
    """Delete a user.

    Examples:

        $ flyte --org my-org delete user user-subject-id
        $ flyte --org my-org delete user user-subject-id --yes
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    if not yes:
        click.confirm(f"Are you sure you want to delete user '{subject}' from org '{cfg.org}'?", abort=True)

    try:
        User.delete(subject)
        console.print(f"[green]✓[/green] Successfully deleted user: [cyan]{subject}[/cyan]")
    except Exception as e:
        raise click.ClickException(f"Unable to delete user: {e}") from e
