import rich_click as click
from flyte.cli import _common as common

from flyteplugins.union.remote import Member


@click.command("member")
@click.pass_obj
def get_member(cfg: common.CLIConfig):
    """List all members (users and applications) in an organization.

    Examples:

        $ flyte --org my-org get member
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    try:
        members = list(Member.listall())
        if not members:
            console.print("[yellow]No members found.[/yellow]")
            return
        console.print(common.format("Members", members, cfg.output_format))
    except Exception as e:
        raise click.ClickException(f"Unable to get members: {e}") from e
