import rich_click as click
import yaml as _yaml
from flyte.cli import _common as common

from flyteplugins.union.cli import edit_with_retry
from flyteplugins.union.internal.common.authorization_pb2 import Action
from flyteplugins.union.remote import Role

# All valid action names for the Action enum (excluding ACTION_NONE).
_ALL_ACTIONS = [Action.Name(v) for v in sorted(Action.values()) if v != Action.Value("ACTION_NONE")]


def _new_role_yaml(name: str, description: str = "") -> str:
    """Generate a YAML template for creating a new role."""
    data = {"name": name, "description": description, "actions": []}
    body = _yaml.safe_dump(data, default_flow_style=False, sort_keys=False)
    comment = "# Valid actions:\n"
    for a in _ALL_ACTIONS:
        comment += f"#   - {a}\n"
    return comment + "\n" + body


def _role_to_yaml(role: Role) -> str:
    """Serialize a Role to YAML for interactive editing."""
    data = {"name": role.name, "description": role.description, "actions": role.actions}
    body = _yaml.safe_dump(data, default_flow_style=False, sort_keys=False)
    comment = "# Valid actions:\n"
    for a in _ALL_ACTIONS:
        comment += f"#   - {a}\n"
    return comment + "\n" + body


@click.command("role")
@click.argument("name", type=str)
@click.option("--file", "file_path", type=click.Path(exists=True), default=None, help="Create role from a YAML file")
@click.option("--edit", "edit_mode", is_flag=True, help="Open an editor to configure the role before creating")
@click.pass_obj
def create_role(cfg: common.CLIConfig, name: str, file_path: str | None, edit_mode: bool):
    """Create a role.

    Requires --file or --edit to specify actions for the role.

    Examples:

        $ flyte --org my-org create role my-role --edit
        $ flyte --org my-org create role my-role --file role.yaml
    """
    if not file_path and not edit_mode:
        raise click.ClickException("Must specify --file or --edit to configure the role.")

    cfg.init(project="", domain="")
    console = common.get_console()

    try:
        if file_path:
            with open(file_path) as f:
                data = _yaml.safe_load(f.read())
            role = Role.create(
                data["name"],
                description=data.get("description", ""),
                actions=data.get("actions"),
            )
        else:
            yaml_text = _new_role_yaml(name)

            def _apply(edited_yaml):
                data = _yaml.safe_load(edited_yaml)
                return Role.create(
                    data["name"],
                    description=data.get("description", ""),
                    actions=data.get("actions"),
                )

            role = edit_with_retry(yaml_text, _apply, console=console, noun="role")
            if role is None:
                return

        console.print(f"[green]✓[/green] Successfully created role: [cyan]{role.name}[/cyan]")
    except Exception as e:
        raise click.ClickException(f"Unable to create role: {e}") from e


@click.command("role")
@click.argument("name", type=str, required=False)
@click.option("--limit", type=int, default=100, help="Maximum number of roles to list")
@click.pass_obj
def get_role(cfg: common.CLIConfig, name: str | None, limit: int):
    """Get or list roles.

    If NAME is provided, gets a specific role. Otherwise, lists all roles.

    Examples:

        $ flyte --org my-org get role
        $ flyte --org my-org get role --limit 10
        $ flyte --org my-org get role my-role
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    try:
        if name:
            role = Role.get(name)
            console.print(common.format(f"Role {name}", [role], "json"))
        else:
            roles = list(Role.listall(limit=limit))
            if not roles:
                console.print("[yellow]No roles found.[/yellow]")
                return
            console.print(common.format("Roles", roles, cfg.output_format))
    except Exception as e:
        raise click.ClickException(f"Unable to get role(s): {e}") from e


@click.command("role")
@click.argument("name", type=str)
@click.option("--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_obj
def delete_role(cfg: common.CLIConfig, name: str, yes: bool):
    """Delete a role.

    Examples:

        $ flyte --org my-org delete role my-role
        $ flyte --org my-org delete role my-role --yes
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    if not yes:
        click.confirm(f"Are you sure you want to delete role '{name}' in org '{cfg.org}'?", abort=True)

    try:
        Role.delete(name)
        console.print(f"[green]✓[/green] Successfully deleted role: [cyan]{name}[/cyan]")
    except Exception as e:
        raise click.ClickException(f"Unable to delete role: {e}") from e


@click.command("role")
@click.argument("name", type=str)
@click.pass_obj
def update_role(cfg: common.CLIConfig, name: str):
    """Update a role interactively.

    Opens the role in your $EDITOR as YAML. Save and close to apply changes.

    Examples:

        $ flyte --org my-org update role my-role
    """
    cfg.init(project="", domain="")
    console = common.get_console()

    try:
        role = Role.get(name)
    except Exception as e:
        raise click.ClickException(f"Unable to get role '{name}': {e}") from e

    yaml_text = _role_to_yaml(role)

    def _apply(edited_yaml):
        data = _yaml.safe_load(edited_yaml)
        new_description = data.get("description", "")
        new_actions = sorted(data.get("actions") or [])
        if new_description == role.description and new_actions == sorted(role.actions):
            return "no_changes"
        Role.update(name, description=new_description, actions=data.get("actions"))

    result = edit_with_retry(yaml_text, _apply, console=console, noun="role")
    if result == "no_changes":
        console.print("[yellow]No changes detected.[/yellow]")
    elif result is not None:
        console.print(f"[green]✓[/green] Successfully updated role: [cyan]{name}[/cyan]")
