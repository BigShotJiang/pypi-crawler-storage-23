from flyteplugins.union.internal.common import identity_pb2 as _identity_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ListMembersRequest(_message.Message):
    __slots__ = ["organization", "include_support_staff"]
    ORGANIZATION_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_SUPPORT_STAFF_FIELD_NUMBER: _ClassVar[int]
    organization: str
    include_support_staff: bool
    def __init__(self, organization: _Optional[str] = ..., include_support_staff: bool = ...) -> None: ...

class ListMembersResponse(_message.Message):
    __slots__ = ["members"]
    MEMBERS_FIELD_NUMBER: _ClassVar[int]
    members: _containers.RepeatedCompositeFieldContainer[_identity_pb2.EnrichedIdentity]
    def __init__(self, members: _Optional[_Iterable[_Union[_identity_pb2.EnrichedIdentity, _Mapping]]] = ...) -> None: ...
