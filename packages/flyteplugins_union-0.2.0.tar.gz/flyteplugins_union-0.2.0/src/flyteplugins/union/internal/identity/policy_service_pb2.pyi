from google.api import annotations_pb2 as _annotations_pb2
from flyteplugins.union.internal.identity import policy_payload_pb2 as _policy_payload_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
