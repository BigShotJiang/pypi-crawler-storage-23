from buf.validate import validate_pb2 as _validate_pb2
from flyteplugins.union.internal.common import authorization_pb2 as _authorization_pb2
from flyteplugins.union.internal.common import identifier_pb2 as _identifier_pb2
from flyteplugins.union.internal.common import identity_pb2 as _identity_pb2
from flyteplugins.union.internal.common import list_pb2 as _list_pb2
from flyteplugins.union.internal.common import role_pb2 as _role_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateRoleRequest(_message.Message):
    __slots__ = ["role"]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    role: _role_pb2.Role
    def __init__(self, role: _Optional[_Union[_role_pb2.Role, _Mapping]] = ...) -> None: ...

class CreateRoleResponse(_message.Message):
    __slots__ = []
    def __init__(self) -> None: ...

class CreateRoleActionRequest(_message.Message):
    __slots__ = ["id", "action"]
    ID_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    id: _identifier_pb2.RoleIdentifier
    action: _authorization_pb2.Action
    def __init__(self, id: _Optional[_Union[_identifier_pb2.RoleIdentifier, _Mapping]] = ..., action: _Optional[_Union[_authorization_pb2.Action, str]] = ...) -> None: ...

class CreateRoleActionResponse(_message.Message):
    __slots__ = []
    def __init__(self) -> None: ...

class DeleteRoleActionRequest(_message.Message):
    __slots__ = ["id", "action"]
    ID_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    id: _identifier_pb2.RoleIdentifier
    action: _authorization_pb2.Action
    def __init__(self, id: _Optional[_Union[_identifier_pb2.RoleIdentifier, _Mapping]] = ..., action: _Optional[_Union[_authorization_pb2.Action, str]] = ...) -> None: ...

class DeleteRoleActionResponse(_message.Message):
    __slots__ = []
    def __init__(self) -> None: ...

class UpdateRoleRequest(_message.Message):
    __slots__ = ["role"]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    role: _role_pb2.Role
    def __init__(self, role: _Optional[_Union[_role_pb2.Role, _Mapping]] = ...) -> None: ...

class UpdateRoleResponse(_message.Message):
    __slots__ = []
    def __init__(self) -> None: ...

class GetRoleRequest(_message.Message):
    __slots__ = ["id"]
    ID_FIELD_NUMBER: _ClassVar[int]
    id: _identifier_pb2.RoleIdentifier
    def __init__(self, id: _Optional[_Union[_identifier_pb2.RoleIdentifier, _Mapping]] = ...) -> None: ...

class GetRoleResponse(_message.Message):
    __slots__ = ["role"]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    role: _role_pb2.Role
    def __init__(self, role: _Optional[_Union[_role_pb2.Role, _Mapping]] = ...) -> None: ...

class DeleteRoleRequest(_message.Message):
    __slots__ = ["id"]
    ID_FIELD_NUMBER: _ClassVar[int]
    id: _identifier_pb2.RoleIdentifier
    def __init__(self, id: _Optional[_Union[_identifier_pb2.RoleIdentifier, _Mapping]] = ...) -> None: ...

class DeleteRoleResponse(_message.Message):
    __slots__ = []
    def __init__(self) -> None: ...

class ListRolesRequest(_message.Message):
    __slots__ = ["organization", "identity", "request"]
    ORGANIZATION_FIELD_NUMBER: _ClassVar[int]
    IDENTITY_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    organization: str
    identity: _identity_pb2.Identity
    request: _list_pb2.ListRequest
    def __init__(self, organization: _Optional[str] = ..., identity: _Optional[_Union[_identity_pb2.Identity, _Mapping]] = ..., request: _Optional[_Union[_list_pb2.ListRequest, _Mapping]] = ...) -> None: ...

class ListRolesResponse(_message.Message):
    __slots__ = ["roles", "token"]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    roles: _containers.RepeatedCompositeFieldContainer[_role_pb2.Role]
    token: str
    def __init__(self, roles: _Optional[_Iterable[_Union[_role_pb2.Role, _Mapping]]] = ..., token: _Optional[str] = ...) -> None: ...
