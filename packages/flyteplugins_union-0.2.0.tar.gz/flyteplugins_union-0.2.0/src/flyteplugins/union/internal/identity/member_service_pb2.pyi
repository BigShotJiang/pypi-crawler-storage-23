from google.api import annotations_pb2 as _annotations_pb2
from flyteplugins.union.internal.identity import member_payload_pb2 as _member_payload_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
