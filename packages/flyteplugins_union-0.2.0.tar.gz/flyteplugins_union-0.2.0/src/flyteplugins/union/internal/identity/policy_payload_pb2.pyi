from buf.validate import validate_pb2 as _validate_pb2
from flyteplugins.union.internal.common import identifier_pb2 as _identifier_pb2
from flyteplugins.union.internal.common import list_pb2 as _list_pb2
from flyteplugins.union.internal.common import policy_pb2 as _policy_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreatePolicyRequest(_message.Message):
    __slots__ = ["policy"]
    POLICY_FIELD_NUMBER: _ClassVar[int]
    policy: _policy_pb2.Policy
    def __init__(self, policy: _Optional[_Union[_policy_pb2.Policy, _Mapping]] = ...) -> None: ...

class CreatePolicyResponse(_message.Message):
    __slots__ = []
    def __init__(self) -> None: ...

class CreatePolicyBindingRequest(_message.Message):
    __slots__ = ["id", "binding"]
    ID_FIELD_NUMBER: _ClassVar[int]
    BINDING_FIELD_NUMBER: _ClassVar[int]
    id: _identifier_pb2.PolicyIdentifier
    binding: _policy_pb2.PolicyBinding
    def __init__(self, id: _Optional[_Union[_identifier_pb2.PolicyIdentifier, _Mapping]] = ..., binding: _Optional[_Union[_policy_pb2.PolicyBinding, _Mapping]] = ...) -> None: ...

class CreatePolicyBindingResponse(_message.Message):
    __slots__ = []
    def __init__(self) -> None: ...

class DeletePolicyBindingRequest(_message.Message):
    __slots__ = ["id", "binding"]
    ID_FIELD_NUMBER: _ClassVar[int]
    BINDING_FIELD_NUMBER: _ClassVar[int]
    id: _identifier_pb2.PolicyIdentifier
    binding: _policy_pb2.PolicyBinding
    def __init__(self, id: _Optional[_Union[_identifier_pb2.PolicyIdentifier, _Mapping]] = ..., binding: _Optional[_Union[_policy_pb2.PolicyBinding, _Mapping]] = ...) -> None: ...

class DeletePolicyBindingResponse(_message.Message):
    __slots__ = []
    def __init__(self) -> None: ...

class GetPolicyRequest(_message.Message):
    __slots__ = ["id"]
    ID_FIELD_NUMBER: _ClassVar[int]
    id: _identifier_pb2.PolicyIdentifier
    def __init__(self, id: _Optional[_Union[_identifier_pb2.PolicyIdentifier, _Mapping]] = ...) -> None: ...

class GetPolicyResponse(_message.Message):
    __slots__ = ["policy"]
    POLICY_FIELD_NUMBER: _ClassVar[int]
    policy: _policy_pb2.Policy
    def __init__(self, policy: _Optional[_Union[_policy_pb2.Policy, _Mapping]] = ...) -> None: ...

class DeletePolicyRequest(_message.Message):
    __slots__ = ["id"]
    ID_FIELD_NUMBER: _ClassVar[int]
    id: _identifier_pb2.PolicyIdentifier
    def __init__(self, id: _Optional[_Union[_identifier_pb2.PolicyIdentifier, _Mapping]] = ...) -> None: ...

class DeletePolicyResponse(_message.Message):
    __slots__ = []
    def __init__(self) -> None: ...

class ListPoliciesRequest(_message.Message):
    __slots__ = ["organization", "request"]
    ORGANIZATION_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIELD_NUMBER: _ClassVar[int]
    organization: str
    request: _list_pb2.ListRequest
    def __init__(self, organization: _Optional[str] = ..., request: _Optional[_Union[_list_pb2.ListRequest, _Mapping]] = ...) -> None: ...

class ListPoliciesResponse(_message.Message):
    __slots__ = ["policies", "token"]
    POLICIES_FIELD_NUMBER: _ClassVar[int]
    TOKEN_FIELD_NUMBER: _ClassVar[int]
    policies: _containers.RepeatedCompositeFieldContainer[_policy_pb2.Policy]
    token: str
    def __init__(self, policies: _Optional[_Iterable[_Union[_policy_pb2.Policy, _Mapping]]] = ..., token: _Optional[str] = ...) -> None: ...
