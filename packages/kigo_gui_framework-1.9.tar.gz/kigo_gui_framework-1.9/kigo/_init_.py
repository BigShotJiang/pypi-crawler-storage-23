# kigo/__init__.py
from .app import App

# import module so we can reference __all__
from . import widgets_v17 as widgets
from .widgets_v17 import *  # re-export widgets

__all__ = ["App"]
__all__.extend(widgets.__all__)
