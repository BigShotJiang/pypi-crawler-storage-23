# kigo/skins.py
from __future__ import annotations

from typing import Dict, Optional, Callable

from kigo.style import StyleManager, StyleSheet, KIGO_BASE_CSS
from kigo.qt import QtCore

Qt = QtCore.Qt

# -------------------------------------------------------------------
# Internal skin registry (Kigo SkinReg v1.9)
# -------------------------------------------------------------------

_SKINS: Dict[str, dict] = {}

# Required token keys (contract)
REQUIRED_TOKENS = {
    "--bg",
    "--fg",
    "--card",
    "--border",

    "--accent",
    "--accentHover",
    "--accentPressed",
    "--onAccent",

    "--danger",
    "--disabled",
    "--muted",

    "--font",
    "--fontSize",
}


# -------------------------------------------------------------------
# Public API: register_skin
# -------------------------------------------------------------------

def register_skin(
    *,
    name: str,
    tokens: Dict[str, str],
    extra_css: str = "",
    window_flags: Optional[Callable] = None,
    preview: Optional[dict] = None,
):
    """
    Register a skin with Kigo.

    This is the ONLY supported way to add skins.

    Parameters
    ----------
    name : str
        Unique skin name (lowercase, no spaces).
    tokens : dict
        CSS variable tokens. Must contain REQUIRED_TOKENS.
    extra_css : str
        Extra Qt StyleSheet appended after KIGO_BASE_CSS.
    window_flags : callable(window) | None
        Optional hook to modify top-level window (glass, frameless, etc).
    preview : dict | None
        Optional metadata for skin galleries / previews.
    """

    if not isinstance(name, str) or not name:
        raise ValueError("Skin name must be a non-empty string")

    key = name.strip().lower()

    if key in _SKINS:
        raise ValueError(f"Skin '{key}' is already registered")

    missing = REQUIRED_TOKENS - set(tokens.keys())
    if missing:
        raise ValueError(
            f"Skin '{key}' is missing required tokens: {sorted(missing)}"
        )

    _SKINS[key] = {
        "name": key,
        "tokens": dict(tokens),
        "extra_css": extra_css or "",
        "window_flags": window_flags,
        "preview": preview or {},
    }


# -------------------------------------------------------------------
# SkinManager (runtime application)
# -------------------------------------------------------------------

class SkinManager:
    """
    Runtime skin controller.

    Usage:
        SkinManager.apply("neon", window=app.root)
    """

    current: Optional[str] = None

    @staticmethod
    def apply(name: str, *, window=None):
        if not _SKINS:
            raise RuntimeError("No skins registered")

        key = name.strip().lower()
        if key not in _SKINS:
            raise ValueError(
                f"Unknown skin '{key}'. Available: {sorted(_SKINS)}"
            )

        skin = _SKINS[key]

        css = KIGO_BASE_CSS + "\n" + skin["extra_css"]

        StyleManager.apply(
            StyleSheet(css),
            tokens=skin["tokens"],
        )

        # Optional window hook (glass, frameless, etc.)
        if skin["window_flags"] and window is not None:
            w = getattr(window, "qt_widget", window)
            skin["window_flags"](w)

        SkinManager.current = key

    @staticmethod
    def available() -> list[str]:
        return sorted(_SKINS.keys())

    @staticmethod
    def info(name: str) -> dict:
        key = name.strip().lower()
        if key not in _SKINS:
            raise ValueError(f"Unknown skin '{key}'")
        return dict(_SKINS[key])


# -------------------------------------------------------------------
# Helper: glass window behavior
# -------------------------------------------------------------------

def enable_glass_window(window):
    """
    Best-effort translucent window support.
    Cross-platform safe (no OS-specific hacks).
    """
    window.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
    window.setAutoFillBackground(False)


# -------------------------------------------------------------------
# Optional convenience wrappers
# -------------------------------------------------------------------

def apply_neon(window=None):
    SkinManager.apply("neon", window=window)

def apply_retro(window=None):
    SkinManager.apply("retro", window=window)

def apply_glass(window=None):
    SkinManager.apply("glass", window=window)