I've added CSS like styling, media playback, and hierarchical UI components and also a very late happy new year! Refer to demo-examples.py to see how its used.

