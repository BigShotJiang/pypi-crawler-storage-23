"""Risk classifier: maps intent tag types to risk tiers.

Unknown tags default to Tier 2 (EXTERNAL_ACTION) — conservative fail-closed
approach. If we don't know what an action does, we ask the user first.
"""
from __future__ import annotations

from shikigami_bot.domain.guardrails import ActionClassification, RiskTier
from shikigami_bot.relay.response_parser import IntentTag

# Explicit mapping of known tag types to risk tiers.
# Conservative default: Tier 2 for anything not listed here.
# Tuple: (RiskTier, description, requires_2fa)
_TAG_RISK_MAP: dict[str, tuple[RiskTier, str, bool]] = {
    # Tier 0 — read-only
    "SEARCH": (RiskTier.READ_ONLY, "Search for information", False),
    "READ": (RiskTier.READ_ONLY, "Read a file or resource", False),
    # Tier 1 — local write (memory, goals)
    "REMEMBER": (RiskTier.LOCAL_WRITE, "Store a memory", False),
    "FORGET": (RiskTier.LOCAL_WRITE, "Remove a memory", False),
    "GOAL": (RiskTier.LOCAL_WRITE, "Set or update a goal", False),
    "DONE": (RiskTier.LOCAL_WRITE, "Mark a goal as done", False),
    "CANCEL": (RiskTier.LOCAL_WRITE, "Cancel a goal", False),
    "PROPOSE_SKILL": (RiskTier.LOCAL_WRITE, "Propose a new skill", False),
    # Tier 2 — external actions requiring user confirmation
    "SEND_EMAIL": (RiskTier.EXTERNAL_ACTION, "Send an email", False),
    "POST": (RiskTier.EXTERNAL_ACTION, "Post content externally", False),
    "CALL_API": (RiskTier.EXTERNAL_ACTION, "Call an external API", False),
    "WEBHOOK": (RiskTier.EXTERNAL_ACTION, "Trigger a webhook", False),
    # Tier 3 — irreversible actions requiring double confirmation (+ 2FA if enrolled)
    "DELETE": (RiskTier.IRREVERSIBLE, "Permanently delete data", True),
    "PUBLISH": (RiskTier.IRREVERSIBLE, "Publish content publicly", False),
    "PURGE": (RiskTier.IRREVERSIBLE, "Purge all data", True),
}

_UNKNOWN_TAG_TIER = RiskTier.EXTERNAL_ACTION
_UNKNOWN_TAG_DESCRIPTION = "Unknown action (conservative: treated as external)"


def classify_tag(tag: IntentTag) -> ActionClassification:
    """Classify an intent tag into a risk tier.

    Unknown tag types default to Tier 2 (EXTERNAL_ACTION) — conservative.

    Args:
        tag: The intent tag extracted from an LLM response

    Returns:
        ActionClassification with risk tier and description
    """
    entry = _TAG_RISK_MAP.get(tag.tag_type)
    if entry is not None:
        tier, description, requires_2fa = entry
    else:
        tier = _UNKNOWN_TAG_TIER
        description = _UNKNOWN_TAG_DESCRIPTION
        requires_2fa = False

    return ActionClassification(
        action_name=tag.tag_type,
        risk_tier=tier,
        description=description,
        requires_2fa=requires_2fa,
    )


def classify_tags(tags: list[IntentTag]) -> list[ActionClassification]:
    """Classify a list of intent tags.

    Args:
        tags: Intent tags from parsed LLM response

    Returns:
        List of ActionClassification, one per tag
    """
    return [classify_tag(tag) for tag in tags]
