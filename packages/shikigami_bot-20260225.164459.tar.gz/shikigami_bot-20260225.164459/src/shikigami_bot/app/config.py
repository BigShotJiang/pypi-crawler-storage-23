"""Application configuration via Pydantic Settings.

Fails closed: missing required env vars raise at startup, not at runtime.
"""
from __future__ import annotations

from pathlib import Path

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Config(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    # Telegram
    telegram_bot_token: SecretStr

    # Directory paths (overridden by env vars in production)
    shikigami_agents_dir: Path = Path("agents")
    shikigami_skills_dir: Path = Path("skills")
    shikigami_data_dir: Path = Path("data")

    # Database (optional for local dev — omit to use SQLite)
    database_url: str | None = None

    # Allowed Telegram user IDs (comma-separated)
    allowed_user_ids: str = ""

    # Anthropic API key (for relay router / Haiku classification)
    anthropic_api_key: SecretStr | None = None

    # Relay router confidence threshold (below this, ask user for confirmation)
    relay_confidence_threshold: float = 0.8

    # Slack (optional — Socket Mode; requires both tokens to activate)
    slack_bot_token: SecretStr | None = None
    slack_app_token: SecretStr | None = None

    # Langfuse (optional)
    langfuse_public_key: str | None = None
    langfuse_secret_key: SecretStr | None = None
    langfuse_host: str = "https://cloud.langfuse.com"

    # 2FA TOTP encryption key (Fernet key, base64-encoded; optional)
    totp_encryption_key: SecretStr | None = None

    # Deepgram (optional — if absent, STT/TTS are disabled)
    deepgram_api_key: SecretStr | None = None
    tts_voice_id: str = "aura-2-thalia-en"

    # Relay fast-path (disabled by default — use Anthropic SDK for simple messages)
    relay_fast_path_enabled: bool = False
    relay_fast_path_max_chars: int = 40

    # Streaming progress (disabled by default — show tool progress during CLI runs)
    streaming_progress_enabled: bool = False
    streaming_progress_throttle_seconds: float = 2.0

    @property
    def allowed_user_id_set(self) -> frozenset[str]:
        if not self.allowed_user_ids:
            return frozenset()
        return frozenset(uid.strip() for uid in self.allowed_user_ids.split(",") if uid.strip())
