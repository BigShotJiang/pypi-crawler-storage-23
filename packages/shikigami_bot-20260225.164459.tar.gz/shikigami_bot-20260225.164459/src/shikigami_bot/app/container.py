"""Dependency injection container — wires all components from Config.

All adapters are instantiated here. Domain code never imports adapters directly.
"""
from __future__ import annotations

import structlog

from shikigami_bot.adapters.llm.anthropic_direct import AnthropicDirectAdapter
from shikigami_bot.adapters.llm.claude_cli import ClaudeCLIAdapter
from shikigami_bot.adapters.storage.sqlite import SQLiteStore
from shikigami_bot.adapters.transports.slack import SlackTransport
from shikigami_bot.app.agent_loader import (
    RoutingEntry,
    build_routing_table,
    load_agents,
)
from shikigami_bot.app.config import Config
from shikigami_bot.adapters.auth.totp import TOTPAdapter
from shikigami_bot.app.guardrails import AllowlistGuardrails
from shikigami_bot.app.observability import create_langfuse
from shikigami_bot.app.pipeline import MessagePipeline
from shikigami_bot.domain.agent import AgentDefinition
from shikigami_bot.domain.ports import TransportPort
from shikigami_bot.relay.router import RelayRouter

log = structlog.get_logger()


class Container:
    """Wires together adapters from config.

    All adapters are injected here -- domain code never imports adapters directly.
    """

    def __init__(self, config: Config) -> None:
        self.config = config

        # Session store (Postgres for production, SQLite for local dev)
        self._database_url = config.database_url
        # Initialized lazily in initialize() — postgres needs async setup
        self.session_store: SQLiteStore | None = None

        # 2FA adapter (needs memory store, finalized in initialize())
        self._totp_encryption_key = (
            config.totp_encryption_key.get_secret_value()
            if config.totp_encryption_key
            else None
        )
        self.two_factor: TOTPAdapter | None = None

        # Guardrails (fail closed: empty allowlist = deny all)
        # 2FA is injected in initialize() once the store is ready
        self.guardrails = AllowlistGuardrails(config.allowed_user_id_set)

        # Agent definitions from agents/ directory
        agents_dir = config.shikigami_agents_dir
        skills_dirs = [config.shikigami_skills_dir]
        if agents_dir.exists():
            self.agents: dict[str, AgentDefinition] = load_agents(
                agents_dir, skills_dirs=skills_dirs
            )
        else:
            log.warning(
                "container.agents_dir_missing",
                path=str(agents_dir),
            )
            self.agents = {}

        # Routing table for the relay
        self.routing_table: list[RoutingEntry] = build_routing_table(self.agents)

        # Relay router (Haiku-based classification via Anthropic SDK)
        api_key = (
            config.anthropic_api_key.get_secret_value()
            if config.anthropic_api_key
            else ""
        )
        self.relay = RelayRouter(
            api_key=api_key,
            confidence_threshold=config.relay_confidence_threshold,
        )

        # LLM adapter (Claude Code CLI subprocess)
        self.llm = ClaudeCLIAdapter(
            claude_path="claude",
            timeout_seconds=300,
            anthropic_api_key=api_key,
        )

        # Fast-path LLM (Anthropic SDK direct, bypasses CLI for simple messages)
        self.fast_path_llm: AnthropicDirectAdapter | None = None
        if config.relay_fast_path_enabled and api_key:
            self.fast_path_llm = AnthropicDirectAdapter(api_key=api_key)

        # Slack transport (optional — requires both tokens)
        self.slack_transport: SlackTransport | None = None
        if config.slack_bot_token and config.slack_app_token:
            self._setup_slack_transport(config)

        # Observability (Langfuse — no-op if keys not configured)
        secret_key = (
            config.langfuse_secret_key.get_secret_value()
            if config.langfuse_secret_key
            else None
        )
        self.langfuse = create_langfuse(
            public_key=config.langfuse_public_key,
            secret_key=secret_key,
            host=config.langfuse_host,
        )

    def _setup_slack_transport(self, config: Config) -> None:
        """Instantiate SlackTransport when both Slack tokens are available."""
        from slack_bolt.async_app import AsyncApp
        from slack_sdk.web.async_client import AsyncWebClient

        bot_token = config.slack_bot_token.get_secret_value()  # type: ignore[union-attr]
        app_token = config.slack_app_token.get_secret_value()  # type: ignore[union-attr]

        slack_app = AsyncApp(token=bot_token)
        slack_client = AsyncWebClient(token=bot_token)
        self.slack_transport = SlackTransport(app=slack_app, client=slack_client)
        log.info(
            "container.slack_transport_ready",
            app_token_prefix=app_token[:10],
        )

    async def initialize(self) -> None:
        """Initialize async components (DB connections, etc.)."""
        if self._database_url:
            from shikigami_bot.adapters.storage.postgres import PostgresStore

            pg = await PostgresStore.create(self._database_url)
            self.session_store = pg  # type: ignore[assignment]
            self._postgres_store = pg
        else:
            store = SQLiteStore(db_path=":memory:")
            await store.initialize()
            self.session_store = store

        # Wire 2FA now that the memory store is available
        if self._totp_encryption_key and self.session_store is not None:
            self.two_factor = TOTPAdapter(
                memory=self.session_store,  # type: ignore[arg-type]
                encryption_key=self._totp_encryption_key,
            )
            self.guardrails = AllowlistGuardrails(
                self.config.allowed_user_id_set,
                two_factor=self.two_factor,
            )
            await log.ainfo("container.2fa_enabled")

        await log.ainfo(
            "container.initialized",
            agents=len(self.agents),
            routes=len(self.routing_table),
            store_type="postgres" if self._database_url else "sqlite",
            two_factor="enabled" if self.two_factor else "disabled",
        )

    async def shutdown(self) -> None:
        """Clean up resources."""
        if self.session_store is not None:
            await self.session_store.close()
        await self.langfuse.close()

    def create_pipeline(self, transport: TransportPort) -> MessagePipeline:
        """Create a MessagePipeline wired to the given transport."""
        return MessagePipeline(
            transport=transport,
            guardrails=self.guardrails,
            relay=self.relay,
            session_store=self.session_store,
            llm=self.llm,
            agents=self.agents,
            routing_table=self.routing_table,
            langfuse=self.langfuse,
            fast_path_llm=self.fast_path_llm,
            fast_path_max_chars=self.config.relay_fast_path_max_chars,
            streaming_enabled=self.config.streaming_progress_enabled,
            streaming_throttle_seconds=self.config.streaming_progress_throttle_seconds,
        )
