"""ProposalHandler — HITL (Human-in-the-Loop) approval for agent self-learning.

When the LLM emits a [PROPOSE_SKILL: ...] tag the handler:
  1. Persists the proposal in the database (status=pending).
  2. Sends an inline keyboard via the transport asking the operator to
     Approve or Reject.
  3a. Approve: updates status to 'approved', appends diff to the agent's
      SKILLS.md file.
  3b. Reject: updates status to 'rejected', no file written.

Security: only 'Approve' (exact string) triggers a write.  Any other
answer including empty strings is treated as rejection (fail-closed).
"""
from __future__ import annotations

import logging
from pathlib import Path

from shikigami_bot.domain.ports import ProposalStore, TransportPort
from shikigami_bot.relay.response_parser import IntentTag

logger = logging.getLogger(__name__)

_APPROVE = "Approve"
_REJECT = "Reject"
_OPTIONS = [_APPROVE, _REJECT]

# Map tag_type -> (proposal_type_str, target_filename)
_TAG_META: dict[str, tuple[str, str]] = {
    "PROPOSE_SKILL": ("skill", "SKILLS.md"),
}

# Default base path — can be overridden in tests
_DEFAULT_AGENTS_BASE = Path(__file__).parent.parent.parent.parent / "agents"


class ProposalHandler:
    """Handles PROPOSE_SKILL intent tags.

    Args:
        proposal_store: Persistence layer for proposals.
        transport: Transport to send inline-keyboard messages.
        agents_base_path: Filesystem path to the agents/ directory.
            Defaults to the project-level ``agents/`` folder.
    """

    def __init__(
        self,
        proposal_store: ProposalStore,
        transport: TransportPort,
        agents_base_path: Path | None = None,
    ) -> None:
        self._store = proposal_store
        self._transport = transport
        self._agents_base = agents_base_path or _DEFAULT_AGENTS_BASE

    async def handle_propose_tag(
        self,
        tag: IntentTag,
        agent_name: str,
        chat_id: str,
        thread_id: str | None,
    ) -> bool:
        """Process a single PROPOSE_SKILL tag.

        Args:
            tag: The parsed intent tag from the LLM response.
            agent_name: Name of the agent that produced the tag.
            chat_id: Chat to send the inline keyboard to.
            thread_id: Optional thread/topic id for the keyboard message.

        Returns:
            True if the proposal was approved, False otherwise.
        """
        type_str, filename = _TAG_META[tag.tag_type]
        diff = tag.content

        # 1. Persist pending proposal
        proposal_id = await self._store.create_proposal(
            agent_name=agent_name,
            type=type_str,
            diff=diff,
        )
        logger.info(
            "proposal.created",
            extra={
                "proposal_id": proposal_id,
                "agent": agent_name,
                "type": type_str,
            },
        )

        # 2. Ask operator via inline keyboard
        question = (
            f"Agent *{agent_name}* proposes a {type_str} change:\n"
            f"```\n{diff}\n```\n"
            f"Approve or Reject?"
        )
        answer = await self._transport.ask_user(
            chat_id=chat_id,
            question=question,
            options=_OPTIONS,
            thread_id=thread_id,
        )

        # 3. Handle response — fail-closed: only "Approve" triggers a write
        if answer == _APPROVE:
            await self._store.update_proposal_status(proposal_id, "approved")
            self._write_diff(agent_name=agent_name, filename=filename, diff=diff)
            logger.info(
                "proposal.approved",
                extra={"proposal_id": proposal_id, "agent": agent_name},
            )
            return True
        else:
            await self._store.update_proposal_status(proposal_id, "rejected")
            logger.info(
                "proposal.rejected",
                extra={
                    "proposal_id": proposal_id,
                    "agent": agent_name,
                    "answer": answer,
                },
            )
            return False

    def _write_diff(self, agent_name: str, filename: str, diff: str) -> None:
        """Append the diff to the agent's target file, creating it if needed.

        Args:
            agent_name: The agent's directory name under agents/.
            filename: Target file name (e.g. SKILLS.md).
            diff: Content to append.
        """
        target = self._agents_base / agent_name / filename
        target.parent.mkdir(parents=True, exist_ok=True)

        # Append mode so existing content is preserved
        with target.open("a", encoding="utf-8") as fh:
            fh.write(diff)
            if not diff.endswith("\n"):
                fh.write("\n")

        logger.info(
            "proposal.file_written",
            extra={"path": str(target)},
        )
