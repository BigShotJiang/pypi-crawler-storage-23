"""Message processing pipeline — the central orchestrator.

Wires: transport -> guardrails -> relay -> session -> LLM -> parse -> reply.

Each stage can fail independently. Errors are logged with structlog and
the user receives a friendly error message — never a raw stack trace.
"""
from __future__ import annotations

import structlog

import asyncio
import time

from shikigami_bot.app.agent_loader import RoutingEntry
from shikigami_bot.app.observability import LangfuseClient, NoOpLangfuse, _utcnow
from shikigami_bot.app.proposal_handler import ProposalHandler
from shikigami_bot.app.risk_classifier import classify_tags
from shikigami_bot.domain.agent import AgentDefinition
from shikigami_bot.domain.message import Message
from shikigami_bot.domain.ports import (
    Guardrails,
    LLMPort,
    SessionStore,
    TransportPort,
)
from shikigami_bot.domain.progress import ProgressCallback, ProgressEvent
from shikigami_bot.relay.response_parser import parse_response
from shikigami_bot.relay.router import RelayRouter

log = structlog.get_logger()


class MessagePipeline:
    """Orchestrates the message processing flow.

    transport -> guardrails -> relay -> session -> LLM -> parse -> reply
    """

    def __init__(
        self,
        transport: TransportPort,
        guardrails: Guardrails,
        relay: RelayRouter,
        session_store: SessionStore,
        llm: LLMPort,
        agents: dict[str, AgentDefinition],
        routing_table: list[RoutingEntry],
        proposal_handler: ProposalHandler | None = None,
        langfuse: LangfuseClient | NoOpLangfuse | None = None,
        fast_path_llm: LLMPort | None = None,
        fast_path_max_chars: int = 40,
        streaming_enabled: bool = False,
        streaming_throttle_seconds: float = 2.0,
    ) -> None:
        self._transport = transport
        self._guardrails = guardrails
        self._relay = relay
        self._session_store = session_store
        self._llm = llm
        self._agents = agents
        self._routing_table = routing_table
        self._proposal_handler = proposal_handler
        self._langfuse = langfuse or NoOpLangfuse()
        self._fast_path_llm = fast_path_llm
        self._fast_path_max_chars = fast_path_max_chars
        self._streaming_enabled = streaming_enabled
        self._streaming_throttle_seconds = streaming_throttle_seconds

    async def process_message(self, message: Message) -> None:
        """Process a single incoming message through the full pipeline."""

        # 1. Auth check (fail fast)
        if not await self._guardrails.is_authorized(message):
            await log.ainfo(
                "pipeline.auth_denied",
                user_id=message.user_id,
                chat_id=message.chat_id,
            )
            return

        # Create Langfuse trace for this pipeline run.
        # session_id maps chat_id so conversation turns are grouped.
        trace_id = await self._langfuse.create_trace(
            name="message_pipeline",
            session_id=message.chat_id,
            user_id=message.user_id,
            input=message.text,
            tags=["pipeline"],
        )

        # 2. Send typing indicator
        try:
            await self._transport.send_typing(
                chat_id=message.chat_id,
                thread_id=message.thread_id,
            )
        except Exception:
            await log.aexception("pipeline.typing_indicator_failed")
            # Non-fatal — continue processing

        # 3. Get active sessions for context
        try:
            active_sessions = await self._session_store.list_active_sessions(
                chat_id=message.chat_id,
            )
        except Exception:
            await log.aexception("pipeline.session_list_failed")
            active_sessions = []

        # 4. Route via relay
        relay_span = await self._langfuse.create_span(
            trace_id=trace_id,
            name="relay_routing",
            input=message.text,
        )
        try:
            decision = await self._relay.route(
                message_text=message.text,
                routing_table=self._routing_table,
                active_sessions=active_sessions,
            )
        except Exception:
            await log.aexception("pipeline.relay_failed")
            await self._langfuse.end_span(
                span_id=relay_span, level="ERROR", status_message="relay_failed",
            )
            await self._send_error(message, "I had trouble understanding that. Please try again.")
            return

        await self._langfuse.end_span(
            span_id=relay_span,
            output={
                "agent": decision.agent_name,
                "confidence": decision.confidence,
                "session_action": decision.session_action,
            },
        )

        await log.ainfo(
            "pipeline.routed",
            agent=decision.agent_name,
            skill=decision.skill_name,
            confidence=decision.confidence,
            session_action=decision.session_action,
            needs_confirmation=decision.needs_confirmation,
        )

        # 5. Handle confirmation if needed
        if decision.needs_confirmation:
            hitl_span = await self._langfuse.create_span(
                trace_id=trace_id,
                name="hitl_routing_confirmation",
                input={"original_agent": decision.agent_name, "confidence": decision.confidence},
            )
            try:
                agent_options = list(self._agents.keys())
                confirmed_agent = await self._transport.ask_user(
                    chat_id=message.chat_id,
                    question=(
                        f"I think this should go to *{decision.agent_name}* "
                        f"(confidence: {decision.confidence:.0%}). Is that right?"
                    ),
                    options=agent_options,
                    thread_id=message.thread_id,
                )
                # Update the decision with the user's confirmed choice
                if confirmed_agent in self._agents:
                    decision = decision.model_copy(
                        update={"agent_name": confirmed_agent, "needs_confirmation": False}
                    )
                await self._langfuse.end_span(
                    span_id=hitl_span,
                    output={"confirmed_agent": confirmed_agent},
                )
            except Exception:
                await log.aexception("pipeline.confirmation_failed")
                await self._langfuse.end_span(
                    span_id=hitl_span, level="ERROR", status_message="confirmation_failed",
                )
                # Fall through with original decision

        # Resolve the agent definition
        agent = self._agents.get(decision.agent_name)
        if agent is None:
            await log.awarning(
                "pipeline.unknown_agent",
                agent_name=decision.agent_name,
            )
            # Fall back to "general" if it exists, otherwise first available
            agent = self._agents.get("general") or next(iter(self._agents.values()))

        # 5b. Acknowledge specialist routing to the user
        if agent.name != "general":
            try:
                await self._transport.send_typing(
                    chat_id=message.chat_id,
                    thread_id=message.thread_id,
                )
                await self._transport.send(
                    chat_id=message.chat_id,
                    text=f"_{agent.name.capitalize()} is on it…_",
                    thread_id=message.thread_id,
                )
            except Exception:
                await log.aexception("pipeline.specialist_ack_failed")

        # 6. Create or resume session
        claude_session_id: str | None = None
        session_id: str | None = None

        if decision.session_action == "resume" and decision.session_id is not None:
            try:
                existing_session = await self._session_store.get_session(
                    decision.session_id
                )
            except Exception:
                await log.aexception("pipeline.session_lookup_failed")
                existing_session = None

            if existing_session is not None:
                session_id = existing_session.session_id
                claude_session_id = existing_session.claude_session_id
                await log.ainfo(
                    "pipeline.session_resumed",
                    session_id=session_id,
                    claude_session_id=claude_session_id,
                )
            else:
                await log.awarning(
                    "pipeline.session_not_found_fallback_new",
                    session_id=decision.session_id,
                )
                # Fall through to create new session below

        if session_id is None:
            # Create new session
            try:
                new_session = await self._session_store.create_session(
                    chat_id=message.chat_id,
                    agent_name=agent.name,
                    topic_summary=message.text[:200],
                )
                session_id = new_session.session_id
                await log.ainfo(
                    "pipeline.session_created",
                    session_id=session_id,
                )
            except Exception:
                await log.aexception("pipeline.session_create_failed")
                # Continue without session tracking — LLM still works

        # 7. Invoke LLM (fast-path or full CLI, optionally with streaming)
        use_fast_path = self._is_fast_path_eligible(
            message=message,
            agent=agent,
            decision=decision,
        )

        llm_start = _utcnow()
        progress_cleanup = None
        try:
            if use_fast_path:
                llm_response = await self._fast_path_llm.invoke(  # type: ignore[union-attr]
                    agent=agent,
                    user_message=message.text,
                    session_id=None,
                    memory_context="",
                )
            elif self._streaming_enabled and hasattr(self._llm, "invoke_streaming"):
                on_progress, progress_cleanup = self._make_progress_callback(
                    chat_id=message.chat_id,
                    thread_id=message.thread_id,
                )
                llm_response = await self._llm.invoke_streaming(
                    agent=agent,
                    user_message=message.text,
                    session_id=claude_session_id,
                    memory_context="",
                    on_progress=on_progress,
                )
            else:
                llm_response = await self._llm.invoke(
                    agent=agent,
                    user_message=message.text,
                    session_id=claude_session_id,
                    memory_context="",
                )
        except Exception:
            await log.aexception("pipeline.llm_invoke_failed")
            await self._langfuse.create_generation(
                trace_id=trace_id,
                name="llm_invoke",
                input=message.text,
                start_time=llm_start,
                end_time=_utcnow(),
                metadata={"error": "llm_invoke_failed"},
            )
            await self._send_error(
                message,
                "Something went wrong while processing your message. Please try again later.",
            )
            return
        finally:
            if progress_cleanup is not None:
                try:
                    await progress_cleanup()
                except Exception:
                    await log.aexception("pipeline.progress_cleanup_failed")

        # Log LLM generation with token usage
        await self._langfuse.create_generation(
            trace_id=trace_id,
            name="llm_invoke",
            model=llm_response.model or None,
            input=message.text,
            output=llm_response.text,
            input_tokens=llm_response.input_tokens,
            output_tokens=llm_response.output_tokens,
            start_time=llm_start,
            end_time=_utcnow(),
            metadata={
                "agent": agent.name,
                "is_error": llm_response.is_error,
                "session_id": llm_response.session_id,
            },
        )

        # Check for LLM error responses
        if llm_response.is_error:
            await log.awarning(
                "pipeline.llm_error",
                error_message=llm_response.error_message,
            )
            if llm_response.error_message and "timeout" in llm_response.error_message.lower():
                await self._send_error(
                    message,
                    "The request took too long. Please try a shorter or simpler message.",
                )
            else:
                await self._send_error(
                    message,
                    "Something went wrong while processing your message. Please try again later.",
                )
            return

        # 8. Parse response (extract intent tags)
        parsed = parse_response(llm_response.text)

        # 9. Risk-tier check and side effects (REMEMBER, GOAL, etc.)
        if parsed.tags:
            classifications = classify_tags(parsed.tags)
            for tag, classification in zip(parsed.tags, classifications, strict=True):
                await log.ainfo(
                    "pipeline.intent_tag",
                    tag_type=tag.tag_type,
                    content=tag.content,
                    metadata=tag.metadata,
                    risk_tier=int(classification.risk_tier),
                )

                # Check whether the user approves this action (Tier 2/3 ask user)
                if hasattr(self._guardrails, "check_action"):
                    try:
                        approved = await self._guardrails.check_action(
                            action=classification,
                            message=message,
                            transport=self._transport,
                        )
                    except Exception:
                        await log.aexception(
                            "pipeline.risk_check_failed",
                            tag_type=tag.tag_type,
                        )
                        approved = False  # Fail closed

                    # Log HITL approval event
                    await self._langfuse.log_event(
                        trace_id=trace_id,
                        name="hitl_action_check",
                        input={
                            "tag_type": tag.tag_type,
                            "risk_tier": int(classification.risk_tier),
                            "action": classification.action_name,
                        },
                        output={"approved": approved},
                        level="WARNING" if not approved else "DEFAULT",
                    )

                    if not approved:
                        await log.ainfo(
                            "pipeline.action_rejected_by_user",
                            tag_type=tag.tag_type,
                            risk_tier=int(classification.risk_tier),
                        )
                        continue

                # Route PROPOSE tags to the proposal handler
                if tag.tag_type == "PROPOSE_SKILL":
                    if self._proposal_handler is not None:
                        try:
                            await self._proposal_handler.handle_propose_tag(
                                tag=tag,
                                agent_name=agent.name,
                                chat_id=message.chat_id,
                                thread_id=message.thread_id,
                            )
                            # Log self-learning proposal event
                            await self._langfuse.log_event(
                                trace_id=trace_id,
                                name="self_learning_proposal",
                                input={
                                    "tag_type": tag.tag_type,
                                    "agent": agent.name,
                                    "diff": tag.content,
                                },
                            )
                        except Exception:
                            await log.aexception(
                                "pipeline.proposal_handler_failed",
                                tag_type=tag.tag_type,
                            )
                    else:
                        await log.awarning(
                            "pipeline.propose_tag_no_handler",
                            tag_type=tag.tag_type,
                        )

        # Update session with claude session ID from LLM response
        if session_id is not None:
            try:
                await self._session_store.update_session(
                    session_id=session_id,
                    claude_session_id=llm_response.session_id,
                    increment_messages=True,
                )
            except Exception:
                await log.aexception("pipeline.session_update_failed")

        # 10. Send clean response to user
        if parsed.clean_text:
            try:
                await self._transport.send(
                    chat_id=message.chat_id,
                    text=parsed.clean_text,
                    reply_to_message_id=message.reply_to_message_id,
                    thread_id=message.thread_id,
                )
            except Exception:
                await log.aexception("pipeline.send_reply_failed")

        # Finalize trace with output
        await self._langfuse.update_trace(
            trace_id=trace_id,
            output=parsed.clean_text,
            metadata={
                "agent": agent.name,
                "tags_count": len(parsed.tags),
                "session_id": session_id,
            },
        )

        await log.ainfo(
            "pipeline.complete",
            chat_id=message.chat_id,
            agent=agent.name,
            tags=len(parsed.tags),
        )

    def _is_fast_path_eligible(
        self,
        message: Message,
        agent: AgentDefinition,
        decision: object,
    ) -> bool:
        """Check if this message qualifies for the fast-path (direct SDK call)."""
        if self._fast_path_llm is None:
            return False
        if not agent.fast_path:
            return False
        if len(message.text) > self._fast_path_max_chars:
            return False
        if hasattr(decision, "session_action") and decision.session_action != "new":  # type: ignore[union-attr]
            return False
        if hasattr(decision, "confidence") and decision.confidence < 0.8:  # type: ignore[union-attr]
            return False
        return True

    def _make_progress_callback(
        self,
        chat_id: str,
        thread_id: str | None,
    ) -> tuple[ProgressCallback, asyncio.coroutines]:
        """Create a throttled progress callback and cleanup coroutine.

        Returns (on_progress, cleanup) where:
        - on_progress: async callback for ProgressEvent updates
        - cleanup: async callable that deletes the progress message
        """
        state: dict[str, str | float | None] = {
            "message_id": None,
            "last_sent": 0.0,
        }

        async def on_progress(event: ProgressEvent) -> None:
            now = time.monotonic()
            elapsed = now - (state["last_sent"] or 0.0)
            if elapsed < self._streaming_throttle_seconds and state["message_id"] is not None:
                return

            try:
                msg_id = await self._transport.send_progress(
                    chat_id=chat_id,
                    text=event.friendly_text,
                    message_id=state["message_id"],  # type: ignore[arg-type]
                    thread_id=thread_id,
                )
                state["message_id"] = msg_id
                state["last_sent"] = now
            except Exception:
                await log.aexception("pipeline.progress_send_failed")

        async def cleanup() -> None:
            if state["message_id"] is not None:
                try:
                    await self._transport.delete_message(
                        chat_id=chat_id,
                        message_id=state["message_id"],  # type: ignore[arg-type]
                    )
                except Exception:
                    await log.aexception("pipeline.progress_delete_failed")

        return on_progress, cleanup

    async def _send_error(self, message: Message, text: str) -> None:
        """Send a user-friendly error message. Never raises."""
        try:
            await self._transport.send(
                chat_id=message.chat_id,
                text=text,
                reply_to_message_id=message.reply_to_message_id,
                thread_id=message.thread_id,
            )
        except Exception:
            await log.aexception("pipeline.error_send_failed")
