"""Langfuse observability via REST API.

Uses the Langfuse batch ingestion endpoint directly (no SDK) because
the langfuse Python SDK uses pydantic.v1 internals that are incompatible
with Python 3.14+.

Graceful no-op: if LANGFUSE_HOST is not configured or the HTTP call fails,
the pipeline continues without observability.
"""
from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from typing import Any

import httpx
import structlog

log = structlog.get_logger()

# Sentinel for "not configured" — avoids None checks everywhere.
_NOOP = object()


def _utcnow() -> str:
    """ISO-8601 UTC timestamp for Langfuse."""
    return datetime.now(timezone.utc).isoformat()


def _new_id() -> str:
    return uuid.uuid4().hex


class LangfuseClient:
    """Lightweight Langfuse REST client for trace/span/generation ingestion.

    All public methods are fire-and-forget: errors are logged but never
    raised so that observability failures never break the pipeline.
    """

    def __init__(
        self,
        public_key: str,
        secret_key: str,
        host: str = "https://cloud.langfuse.com",
    ) -> None:
        self._host = host.rstrip("/")
        self._auth = (public_key, secret_key)
        self._client = httpx.AsyncClient(timeout=5.0)

    async def close(self) -> None:
        await self._client.aclose()

    # ------------------------------------------------------------------
    # Public helpers — each returns the created ID for nesting
    # ------------------------------------------------------------------

    async def create_trace(
        self,
        *,
        name: str,
        session_id: str | None = None,
        user_id: str | None = None,
        input: Any = None,
        metadata: dict[str, Any] | None = None,
        tags: list[str] | None = None,
    ) -> str:
        trace_id = _new_id()
        body: dict[str, Any] = {
            "id": trace_id,
            "timestamp": _utcnow(),
            "name": name,
        }
        if session_id is not None:
            body["sessionId"] = session_id
        if user_id is not None:
            body["userId"] = user_id
        if input is not None:
            body["input"] = input
        if metadata:
            body["metadata"] = metadata
        if tags:
            body["tags"] = tags

        await self._ingest([{"id": _new_id(), "type": "trace-create", "body": body}])
        return trace_id

    async def create_span(
        self,
        *,
        trace_id: str,
        name: str,
        input: Any = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        span_id = _new_id()
        body: dict[str, Any] = {
            "id": span_id,
            "traceId": trace_id,
            "name": name,
            "startTime": _utcnow(),
        }
        if input is not None:
            body["input"] = input
        if metadata:
            body["metadata"] = metadata

        await self._ingest([{"id": _new_id(), "type": "span-create", "body": body}])
        return span_id

    async def end_span(
        self,
        *,
        span_id: str,
        output: Any = None,
        metadata: dict[str, Any] | None = None,
        level: str | None = None,
        status_message: str | None = None,
    ) -> None:
        body: dict[str, Any] = {
            "id": span_id,
            "endTime": _utcnow(),
        }
        if output is not None:
            body["output"] = output
        if metadata:
            body["metadata"] = metadata
        if level:
            body["level"] = level
        if status_message:
            body["statusMessage"] = status_message

        await self._ingest([{"id": _new_id(), "type": "span-update", "body": body}])

    async def create_generation(
        self,
        *,
        trace_id: str,
        name: str,
        model: str | None = None,
        input: Any = None,
        output: Any = None,
        input_tokens: int | None = None,
        output_tokens: int | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        gen_id = _new_id()
        body: dict[str, Any] = {
            "id": gen_id,
            "traceId": trace_id,
            "name": name,
            "startTime": start_time or _utcnow(),
        }
        if end_time:
            body["endTime"] = end_time
        if model:
            body["model"] = model
        if input is not None:
            body["input"] = input
        if output is not None:
            body["output"] = output
        if input_tokens is not None or output_tokens is not None:
            body["usageDetails"] = {}
            if input_tokens is not None:
                body["usageDetails"]["inputTokens"] = input_tokens
            if output_tokens is not None:
                body["usageDetails"]["outputTokens"] = output_tokens
        if metadata:
            body["metadata"] = metadata

        await self._ingest(
            [{"id": _new_id(), "type": "generation-create", "body": body}]
        )
        return gen_id

    async def update_trace(
        self,
        *,
        trace_id: str,
        output: Any = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        body: dict[str, Any] = {"id": trace_id}
        if output is not None:
            body["output"] = output
        if metadata:
            body["metadata"] = metadata

        await self._ingest(
            [{"id": _new_id(), "type": "trace-create", "body": body}]
        )

    async def log_event(
        self,
        *,
        trace_id: str,
        name: str,
        input: Any = None,
        output: Any = None,
        metadata: dict[str, Any] | None = None,
        level: str = "DEFAULT",
    ) -> str:
        event_id = _new_id()
        body: dict[str, Any] = {
            "id": event_id,
            "traceId": trace_id,
            "name": name,
            "startTime": _utcnow(),
            "level": level,
        }
        if input is not None:
            body["input"] = input
        if output is not None:
            body["output"] = output
        if metadata:
            body["metadata"] = metadata

        await self._ingest(
            [{"id": _new_id(), "type": "event-create", "body": body}]
        )
        return event_id

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _ingest(self, events: list[dict[str, Any]]) -> None:
        """POST to /api/public/ingestion. Swallows all errors."""
        now = _utcnow()
        for ev in events:
            ev.setdefault("timestamp", now)

        url = f"{self._host}/api/public/ingestion"
        try:
            resp = await self._client.post(
                url,
                json={"batch": events},
                auth=self._auth,
            )
            if resp.status_code not in (200, 207):
                await log.awarning(
                    "langfuse.ingest_error",
                    status=resp.status_code,
                    body=resp.text[:500],
                )
        except Exception:
            await log.adebug("langfuse.ingest_failed", exc_info=True)


class NoOpLangfuse:
    """Drop-in replacement when Langfuse is not configured."""

    async def close(self) -> None:
        pass

    async def create_trace(self, **kw: Any) -> str:
        return _new_id()

    async def create_span(self, **kw: Any) -> str:
        return _new_id()

    async def end_span(self, **kw: Any) -> None:
        pass

    async def create_generation(self, **kw: Any) -> str:
        return _new_id()

    async def update_trace(self, **kw: Any) -> None:
        pass

    async def log_event(self, **kw: Any) -> str:
        return _new_id()


def create_langfuse(
    public_key: str | None,
    secret_key: str | None,
    host: str = "https://cloud.langfuse.com",
) -> LangfuseClient | NoOpLangfuse:
    """Factory: returns a real client if keys are configured, NoOp otherwise."""
    if public_key and secret_key:
        return LangfuseClient(
            public_key=public_key,
            secret_key=secret_key,
            host=host,
        )
    return NoOpLangfuse()
