"""Application entry point — wires aiogram bot to the message pipeline."""
from __future__ import annotations

import asyncio

import aiogram
import structlog

from .config import Config
from .container import Container

log = structlog.get_logger()


async def run() -> None:
    """Start the bot: build container, wire transport, begin polling."""
    config = Config()  # Fails closed if required env vars are missing
    container = Container(config)
    await container.initialize()

    await log.ainfo(
        "shikigami-bot starting",
        allowed_users=len(config.allowed_user_id_set),
        agents=len(container.agents),
    )

    # Avoid top-level import so tests don't need a Telegram bot token
    from shikigami_bot.adapters.transports.telegram import TelegramTransport

    bot = aiogram.Bot(token=config.telegram_bot_token.get_secret_value())
    dp = aiogram.Dispatcher()
    transport = TelegramTransport(bot)
    pipeline = container.create_pipeline(transport)

    @dp.message()
    async def handle_message(msg: aiogram.types.Message) -> None:
        domain_msg = TelegramTransport.to_domain_message(msg)

        # Check for pending text reply (e.g. 2FA code input)
        if msg.text and transport.resolve_text_reply(
            str(msg.chat.id), msg.text
        ):
            return

        # Handle /2fa command
        if msg.text and msg.text.strip().lower() == "/2fa":
            await _handle_2fa_setup(
                msg, transport, container,
            )
            return

        await pipeline.process_message(domain_msg)

    @dp.callback_query()
    async def handle_callback_query(callback: aiogram.types.CallbackQuery) -> None:
        """Resolve pending ask_user() Futures when the user taps an inline button."""
        await callback.answer()  # Dismiss the loading spinner
        if callback.message is not None and callback.data is not None:
            chat_id = str(callback.message.chat.id)
            transport.resolve_callback(chat_id, callback.data)

    try:
        await dp.start_polling(bot)
    finally:
        await container.shutdown()
        await bot.session.close()


async def _handle_2fa_setup(
    msg: aiogram.types.Message,
    transport: "TelegramTransport",  # noqa: F821
    container: Container,
) -> None:
    """Handle /2fa — enroll user for TOTP 2FA."""
    from shikigami_bot.adapters.transports.telegram import TelegramTransport as TT

    chat_id = str(msg.chat.id)
    user_id = str(msg.from_user.id) if msg.from_user else "0"
    thread_id = str(msg.message_thread_id) if msg.message_thread_id is not None else None

    if container.two_factor is None:
        await transport.send(
            chat_id=chat_id,
            text="2FA is not configured. Set TOTP\\_ENCRYPTION\\_KEY in the environment.",
            thread_id=thread_id,
        )
        return

    already_enrolled = await container.two_factor.is_enrolled(user_id)
    if already_enrolled:
        answer = await transport.ask_user(
            chat_id=chat_id,
            question="You already have 2FA set up. Do you want to re-enroll (this resets your secret)?",
            options=["Re-enroll", "Cancel"],
            thread_id=thread_id,
        )
        if answer != "Re-enroll":
            await transport.send(
                chat_id=chat_id,
                text="2FA setup cancelled.",
                thread_id=thread_id,
            )
            return

    uri, qr_bytes, raw_secret = await container.two_factor.enroll(user_id)

    await transport.send_photo(
        chat_id=chat_id,
        photo=qr_bytes,
        caption="Scan this QR code with your authenticator app (1Password, Authy, Google Authenticator, etc.)",
        thread_id=thread_id,
    )

    # Instruction + secret as separate message for easy copying
    await transport.send(
        chat_id=chat_id,
        text="Copy the following code into your authenticator app if you can't scan the QR code:",
        thread_id=thread_id,
    )
    await transport.send(
        chat_id=chat_id,
        text=f"`{raw_secret}`",
        thread_id=thread_id,
    )

    # Verify enrollment by asking for a code
    code = await transport.ask_user_text(
        chat_id=chat_id,
        question="Enter the 6-digit code from your authenticator app to verify setup:",
        thread_id=thread_id,
    )

    if code and await container.two_factor.verify(user_id, code.strip()):
        await transport.send(
            chat_id=chat_id,
            text="2FA setup complete. Critical actions will now require a TOTP code.",
            thread_id=thread_id,
        )
    else:
        await transport.send(
            chat_id=chat_id,
            text="Verification failed. Please try /2fa again.",
            thread_id=thread_id,
        )


def main() -> None:
    asyncio.run(run())


if __name__ == "__main__":
    main()
