"""Agent loader — parse agent.yml + prompt.md files into AgentDefinition models.

Reads agent directories, parses agent.yml config and prompt.md body,
loads skill definitions from skills/<name>/SKILL.md, and builds routing tables.

All returned objects are frozen (immutable). This module never writes files.
"""
from __future__ import annotations

import os
import re
import shutil
from pathlib import Path

import structlog
import yaml
from pydantic import BaseModel, ValidationError

from shikigami_bot.domain.agent import AgentDefinition, SkillDefinition

log = structlog.get_logger()

# Matches a --- fenced YAML frontmatter block at the start of the file.
_FRONTMATTER_RE = re.compile(
    r"\A---[ \t]*\n(.*?\n)---[ \t]*\n",
    re.DOTALL,
)


class RoutingEntry(BaseModel, frozen=True):
    """Single entry in the relay routing table."""

    agent_name: str
    skill_name: str | None = None
    description: str


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

# Matches personality sections: # Soul, ## Soul, ## Personality (with optional suffix).
# Captures everything from the header to the end of the file (or next same-level header).
_PERSONALITY_RE = re.compile(
    r"^(#{1,2})\s+(?:Soul|Personality)\b[^\n]*\n(.*)",
    re.DOTALL | re.MULTILINE,
)


def _split_frontmatter(text: str) -> tuple[str, str]:
    """Split YAML frontmatter from markdown body.

    Returns (yaml_str, body_str). Raises ValueError on missing/invalid frontmatter.
    """
    match = _FRONTMATTER_RE.match(text)
    if not match:
        raise ValueError("Must start with YAML frontmatter (--- fenced block)")
    yaml_str = match.group(1)
    body = text[match.end() :]
    return yaml_str, body


def _extract_personality(body: str) -> tuple[str, str | None]:
    """Extract personality section from markdown body.

    Looks for a heading matching # Soul, ## Soul, or ## Personality.
    Everything from that heading onward is the personality text.
    The heading itself is stripped from the personality content.

    Returns (system_prompt, personality). personality is None if no section found.
    """
    match = _PERSONALITY_RE.search(body)
    if not match:
        return body.strip(), None

    # Everything before the personality header is system_prompt
    system_prompt = body[: match.start()].strip()
    # The personality content is after the header line
    personality = match.group(2).strip()

    return system_prompt, personality if personality else None


def _parse_skill_md(path: Path) -> SkillDefinition:
    """Parse a single skill .md file into a SkillDefinition."""
    text = path.read_text(encoding="utf-8")
    try:
        yaml_str, body = _split_frontmatter(text)
    except ValueError as exc:
        raise ValueError(f"Invalid skill file {path.name}: {exc}") from exc

    try:
        data = yaml.safe_load(yaml_str)
    except yaml.YAMLError as exc:
        raise ValueError(f"Invalid YAML in skill {path.name}: {exc}") from exc

    if not isinstance(data, dict):
        raise ValueError(f"Skill {path.name}: frontmatter must be a YAML mapping")

    requires = data.get("requires", {}) or {}

    return SkillDefinition(
        name=data.get("name", path.stem),
        description=data.get("description", ""),
        version=data.get("version"),
        content=body.strip(),
        requires_env=requires.get("env") or [],
        requires_bins=requires.get("bins") or [],
    )


def load_skills(
    skills_dirs: list[Path],
    skill_names: list[str],
) -> list[SkillDefinition]:
    """Load skill definitions by name from ordered search directories.

    For each skill name, searches ``skills_dirs`` in order for
    ``<dir>/<name>/SKILL.md``.  First match wins (project-local dirs should
    come before global dirs in the list).

    Skills not found in any directory are logged as warnings and skipped.
    """
    resolved: list[SkillDefinition] = []

    for name in skill_names:
        # Guard against path traversal (e.g. "../../etc")
        if not name or "/" in name or "\\" in name or ".." in name:
            log.warning("skill.invalid_name", skill=name)
            continue

        found = False
        for search_dir in skills_dirs:
            skill_file = search_dir / name / "SKILL.md"
            if skill_file.is_file():
                resolved.append(_parse_skill_md(skill_file))
                found = True
                break
        if not found:
            log.warning(
                "skill.not_found",
                skill=name,
                searched=[str(d) for d in skills_dirs],
            )

    return resolved


def gate_skills(skills: list[SkillDefinition]) -> list[SkillDefinition]:
    """Filter skills whose runtime requirements are not met.

    Checks ``requires_env`` (env vars present) and ``requires_bins``
    (binaries on PATH via ``shutil.which``).  Skills that fail any check
    are logged and excluded from the returned list.
    """
    passed: list[SkillDefinition] = []

    for skill in skills:
        missing_env = [v for v in skill.requires_env if v not in os.environ]
        missing_bins = [b for b in skill.requires_bins if shutil.which(b) is None]

        if missing_env or missing_bins:
            log.warning(
                "skill.gated",
                skill=skill.name,
                missing_env=missing_env or None,
                missing_bins=missing_bins or None,
            )
            continue

        passed.append(skill)

    return passed


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def parse_agent_dir(
    agent_dir: Path,
    skills_dirs: list[Path] | None = None,
) -> AgentDefinition:
    """Parse an agent directory containing agent.yml + prompt.md.

    The agent directory contains:
    - agent.yml: name, description, model, orchestrator, tools, skills
    - prompt.md: full system prompt + optional personality section (# Soul)

    Skills referenced by name in agent.yml ``skills:`` are resolved from
    *skills_dirs* (first match wins).  When *skills_dirs* is ``None``,
    no skills are loaded (backward compat).

    Raises:
        FileNotFoundError: if agent.yml does not exist
        ValueError: on invalid YAML or missing required fields
    """
    agent_yml = agent_dir / "agent.yml"
    if not agent_yml.exists():
        raise FileNotFoundError(f"agent.yml not found: {agent_yml}")

    # Parse agent.yml
    try:
        data = yaml.safe_load(agent_yml.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise ValueError(f"Invalid YAML in {agent_yml}: {exc}") from exc

    if not isinstance(data, dict):
        raise ValueError(f"agent.yml must be a YAML mapping: {agent_yml}")

    # Read prompt.md (optional — agent may have no system prompt)
    prompt_md = agent_dir / "prompt.md"
    body = prompt_md.read_text(encoding="utf-8") if prompt_md.exists() else ""

    # Extract personality from prompt body
    system_prompt, personality = _extract_personality(body)

    # Load skills from standalone directories
    skill_names: list[str] = data.get("skills") or []
    if skills_dirs is not None and skill_names:
        skills = gate_skills(load_skills(skills_dirs, skill_names))
    else:
        skills = []

    # Build the AgentDefinition
    try:
        agent = AgentDefinition(
            name=data.get("name", ""),
            description=data.get("description", ""),
            system_prompt=system_prompt,
            personality=personality,
            model=data.get("model", "sonnet"),
            orchestrator=data.get("orchestrator", False),
            fast_path=data.get("fast_path", True),
            allowed_tools=data.get("tools") or [],
            skills=skills,
        )
    except ValidationError as exc:
        raise ValueError(
            f"Validation error in {agent_yml}: {exc}"
        ) from exc

    # Fail fast on empty required fields (Pydantic allows empty strings)
    if not agent.name:
        raise ValueError(f"Missing required field 'name' in {agent_yml}")
    if not agent.description:
        raise ValueError(f"Missing required field 'description' in {agent_yml}")

    return agent


def load_agents(
    agents_dir: Path,
    skills_dirs: list[Path] | None = None,
) -> dict[str, AgentDefinition]:
    """Load all agent definitions from an agents/ directory.

    Each subdirectory with an agent.yml is treated as an agent.
    Subdirectories without agent.yml are silently skipped.

    *skills_dirs* controls where standalone skills are resolved from.
    When ``None`` (default), ``[Path("skills")]`` is used as the
    project-local default.  The ``SHIKI_SKILLS_PATH`` env var, if set,
    is prepended to the list.

    Returns a dict mapping agent name to AgentDefinition.

    Raises:
        FileNotFoundError: if agents_dir does not exist
    """
    if not agents_dir.exists():
        raise FileNotFoundError(f"Agents directory not found: {agents_dir}")

    # Build skills search path
    if skills_dirs is None:
        skills_dirs = [Path("skills")]

    env_path = os.environ.get("SHIKI_SKILLS_PATH")
    if env_path:
        resolved = Path(env_path).resolve()
        if resolved.is_dir():
            skills_dirs = [resolved] + skills_dirs
        else:
            log.warning("skills_path.invalid", path=env_path)

    agents: dict[str, AgentDefinition] = {}
    for subdir in sorted(agents_dir.iterdir()):
        if not subdir.is_dir():
            continue
        if not (subdir / "agent.yml").exists():
            continue
        agent = parse_agent_dir(subdir, skills_dirs=skills_dirs)
        agents[agent.name] = agent

    return agents


def build_routing_table(
    agents: dict[str, AgentDefinition],
) -> list[RoutingEntry]:
    """Build a flat routing table for the relay agent.

    Each agent gets one entry for itself (skill_name=None).
    Each skill within an agent gets an additional entry.
    """
    table: list[RoutingEntry] = []

    for agent in agents.values():
        # Agent-level entry
        table.append(
            RoutingEntry(
                agent_name=agent.name,
                skill_name=None,
                description=agent.description,
            )
        )
        # Skill-level entries
        for skill in agent.skills:
            table.append(
                RoutingEntry(
                    agent_name=agent.name,
                    skill_name=skill.name,
                    description=skill.description,
                )
            )

    return table
