"""Fail-closed authorization with allowlist enforcement and risk-tier checking."""
from __future__ import annotations

import structlog

from shikigami_bot.domain.guardrails import ActionClassification, RiskTier
from shikigami_bot.domain.message import Message
from shikigami_bot.domain.ports import TransportPort, TwoFactorPort

log = structlog.get_logger()


class AllowlistGuardrails:
    """Fail-closed authorization: deny by default.

    If allowed_user_ids is empty, ALL users are denied.
    This is intentional -- explicit allowlisting required.

    Also implements risk-tier checking for action confirmations:
    - Tier 0-1: auto-approved
    - Tier 2: single confirmation via inline keyboard
    - Tier 3: double confirmation (warning + explicit confirm) + optional 2FA
    - requires_2fa: any action with this flag requires TOTP after confirmation
    """

    _CONFIRM = "Approve"
    _REJECT = "Reject"
    _CONFIRM_FINAL = "Yes, I'm sure"

    def __init__(
        self,
        allowed_user_ids: frozenset[str],
        two_factor: TwoFactorPort | None = None,
    ) -> None:
        self._allowed = allowed_user_ids
        self._two_factor = two_factor

    async def is_authorized(self, message: Message) -> bool:
        user_id = message.user_id.strip()

        if user_id in self._allowed:
            await log.ainfo(
                "User authorized",
                user_id=user_id,
                chat_id=message.chat_id,
            )
            return True

        await log.awarning(
            "User denied — not in allowlist",
            user_id=user_id,
            chat_id=message.chat_id,
            allowlist_size=len(self._allowed),
        )
        return False

    async def check_action(
        self,
        action: ActionClassification,
        message: Message,
        transport: TransportPort,
    ) -> bool:
        """Check whether an action is permitted given its risk tier.

        Tier 0-1: auto-approved without user interaction.
        Tier 2: single confirmation via inline keyboard.
        Tier 3: double confirmation — warning first, then explicit confirm.
        requires_2fa: after confirmation, also verify TOTP code.

        Args:
            action: The classified action to check
            message: Originating message (for chat_id / thread_id)
            transport: Transport used to ask the user

        Returns:
            True if the action is approved, False if rejected or timed out.
        """
        tier = action.risk_tier

        if tier <= RiskTier.LOCAL_WRITE and not action.requires_2fa:
            # Tier 0-1: auto-approved
            await log.ainfo(
                "action.auto_approved",
                action=action.action_name,
                tier=int(tier),
            )
            return True

        if tier == RiskTier.EXTERNAL_ACTION and not action.requires_2fa:
            # Tier 2: single confirmation
            answer = await transport.ask_user(
                chat_id=message.chat_id,
                question=(
                    f"The bot wants to perform an external action:\n"
                    f"*{action.description}*\n\n"
                    f"Do you approve?"
                ),
                options=[self._CONFIRM, self._REJECT],
                thread_id=message.thread_id,
            )
            approved = answer == self._CONFIRM
            await log.ainfo(
                "action.tier2_decision",
                action=action.action_name,
                approved=approved,
            )
            return approved

        # Tier 3 OR requires_2fa: double confirmation + optional TOTP
        first_answer = await transport.ask_user(
            chat_id=message.chat_id,
            question=(
                f"WARNING: The bot wants to perform an IRREVERSIBLE action:\n"
                f"*{action.description}*\n\n"
                f"This cannot be undone. Do you want to proceed?"
            ),
            options=[self._CONFIRM, self._REJECT],
            thread_id=message.thread_id,
        )

        if first_answer != self._CONFIRM:
            await log.ainfo(
                "action.tier3_rejected_at_first_prompt",
                action=action.action_name,
            )
            return False

        second_answer = await transport.ask_user(
            chat_id=message.chat_id,
            question=(
                f"Final confirmation required.\n"
                f"Are you absolutely sure you want to *{action.description.lower()}*?"
            ),
            options=[self._CONFIRM_FINAL, self._REJECT],
            thread_id=message.thread_id,
        )
        if second_answer != self._CONFIRM_FINAL:
            await log.ainfo(
                "action.tier3_decision",
                action=action.action_name,
                approved=False,
            )
            return False

        await log.ainfo(
            "action.tier3_decision",
            action=action.action_name,
            approved=True,
        )

        # 2FA check (Tier 3 always requires 2FA if enrolled, requires_2fa flag forces it)
        if action.requires_2fa or tier == RiskTier.IRREVERSIBLE:
            approved = await self._check_2fa(message, transport)
            if not approved:
                return False

        return True

    async def _check_2fa(
        self,
        message: Message,
        transport: TransportPort,
    ) -> bool:
        """Verify TOTP code. Blocks action if user is not enrolled."""
        if self._two_factor is None:
            # 2FA not configured — fail open with warning for now
            await log.awarning(
                "action.2fa_not_configured",
                user_id=message.user_id,
            )
            return True

        user_id = message.user_id.strip()

        if not await self._two_factor.is_enrolled(user_id):
            await transport.send(
                chat_id=message.chat_id,
                text=(
                    "This action requires 2FA verification, but you are not enrolled.\n"
                    "Use /2fa to set up two-factor authentication first."
                ),
                thread_id=message.thread_id,
            )
            await log.awarning(
                "action.2fa_not_enrolled",
                user_id=user_id,
            )
            return False

        code = await transport.ask_user_text(
            chat_id=message.chat_id,
            question="Enter your 6-digit 2FA code:",
            thread_id=message.thread_id,
        )

        if not code:
            await log.ainfo("action.2fa_timeout", user_id=user_id)
            return False

        valid = await self._two_factor.verify(user_id, code.strip())
        await log.ainfo(
            "action.2fa_result",
            user_id=user_id,
            valid=valid,
        )

        if not valid:
            await transport.send(
                chat_id=message.chat_id,
                text="Invalid 2FA code. Action blocked.",
                thread_id=message.thread_id,
            )

        return valid
