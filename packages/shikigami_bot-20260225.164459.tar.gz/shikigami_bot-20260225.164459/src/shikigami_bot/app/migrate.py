"""Database schema migration — applies SQL migrations to Postgres or SQLite.

Usage:
    uv run python -m shikigami_bot.app.migrate          # reads DATABASE_URL from .env
    uv run python -m shikigami_bot.app.migrate --sqlite  # apply to local SQLite file
"""
from __future__ import annotations

import argparse
import asyncio
import sys

SCHEMA_SQL = """\
-- Sessions: conversation tracking between users and agents
CREATE TABLE IF NOT EXISTS sessions (
    session_id        TEXT PRIMARY KEY,
    chat_id           TEXT NOT NULL,
    agent_name        TEXT NOT NULL,
    topic_summary     TEXT NOT NULL,
    claude_session_id TEXT,
    message_count     INTEGER NOT NULL DEFAULT 0,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_active       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sessions_chat_id ON sessions (chat_id);
CREATE INDEX IF NOT EXISTS idx_sessions_chat_agent ON sessions (chat_id, agent_name);

-- Conversations: message log per chat
CREATE TABLE IF NOT EXISTS conversations (
    id          SERIAL PRIMARY KEY,
    chat_id     TEXT NOT NULL,
    thread_id   TEXT,
    role        TEXT NOT NULL,
    content     TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_conversations_chat ON conversations (chat_id, created_at);

-- Memory: key-value store per user for agent memory
CREATE TABLE IF NOT EXISTS memory (
    user_id    TEXT NOT NULL,
    key        TEXT NOT NULL,
    value      TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, key)
);

-- Proposals: self-learning skill/soul proposals awaiting HITL approval
CREATE TABLE IF NOT EXISTS proposals (
    id          SERIAL PRIMARY KEY,
    agent_name  TEXT NOT NULL,
    type        TEXT NOT NULL CHECK (type IN ('skill', 'soul')),
    diff        TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_proposals_status ON proposals (status);
"""

# SQLite-compatible version (no SERIAL, no TIMESTAMPTZ, no now())
SCHEMA_SQL_SQLITE = """\
CREATE TABLE IF NOT EXISTS sessions (
    session_id        TEXT PRIMARY KEY,
    chat_id           TEXT NOT NULL,
    agent_name        TEXT NOT NULL,
    topic_summary     TEXT NOT NULL,
    claude_session_id TEXT,
    message_count     INTEGER NOT NULL DEFAULT 0,
    created_at        TEXT NOT NULL,
    last_active       TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sessions_chat_id ON sessions (chat_id);
CREATE INDEX IF NOT EXISTS idx_sessions_chat_agent ON sessions (chat_id, agent_name);

CREATE TABLE IF NOT EXISTS conversations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id     TEXT NOT NULL,
    thread_id   TEXT,
    role        TEXT NOT NULL,
    content     TEXT NOT NULL,
    created_at  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_conversations_chat ON conversations (chat_id, created_at);

CREATE TABLE IF NOT EXISTS memory (
    user_id    TEXT NOT NULL,
    key        TEXT NOT NULL,
    value      TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (user_id, key)
);

CREATE TABLE IF NOT EXISTS proposals (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_name  TEXT NOT NULL,
    type        TEXT NOT NULL CHECK (type IN ('skill', 'soul')),
    diff        TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    created_at  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_proposals_status ON proposals (status);
"""


async def migrate_postgres(database_url: str) -> None:
    """Apply schema to a PostgreSQL database."""
    import asyncpg

    conn = await asyncpg.connect(database_url)
    try:
        await conn.execute(SCHEMA_SQL)
        print("Postgres schema applied successfully.")
    finally:
        await conn.close()


async def migrate_sqlite(db_path: str) -> None:
    """Apply schema to a SQLite database."""
    import aiosqlite

    async with aiosqlite.connect(db_path) as db:
        await db.executescript(SCHEMA_SQL_SQLITE)
        await db.commit()
    print(f"SQLite schema applied to {db_path}.")


async def main() -> None:
    parser = argparse.ArgumentParser(description="Apply database migrations")
    parser.add_argument(
        "--sqlite",
        metavar="PATH",
        help="Apply migrations to a SQLite database file",
    )
    parser.add_argument(
        "--database-url",
        metavar="URL",
        help="PostgreSQL connection URL (overrides DATABASE_URL env var)",
    )
    args = parser.parse_args()

    if args.sqlite:
        await migrate_sqlite(args.sqlite)
    elif args.database_url:
        await migrate_postgres(args.database_url)
    else:
        import os

        database_url = os.environ.get("DATABASE_URL")
        if not database_url:
            print("Error: No --sqlite, --database-url, or DATABASE_URL provided.", file=sys.stderr)
            sys.exit(1)
        await migrate_postgres(database_url)


if __name__ == "__main__":
    asyncio.run(main())
