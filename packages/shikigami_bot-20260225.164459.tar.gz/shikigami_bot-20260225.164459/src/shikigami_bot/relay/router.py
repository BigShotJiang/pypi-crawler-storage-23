"""Haiku-based semantic message dispatcher (relay router).

Uses the Anthropic SDK for classification. No tools, no file access —
classification only. Accepts a message, routing table, and optional
active sessions, then returns a structured RoutingDecision.
"""
from __future__ import annotations

import json
import logging
import re

import anthropic

from shikigami_bot.app.agent_loader import RoutingEntry
from shikigami_bot.domain.routing import RoutingDecision
from shikigami_bot.domain.session import SessionSummary

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# System prompt — hardcoded routing instructions for the relay
# ---------------------------------------------------------------------------

_ROUTING_SYSTEM_PROMPT = """\
You are the Relay — the routing brain of Shikigami, a multi-agent AI assistant.
Your ONLY job is to classify an incoming user message and decide which agent \
(and optionally which skill) should handle it.

## ROUTING PRINCIPLES

1. **Specialist first**: If a specialist agent clearly matches, route to it. \
Specialists have deeper capabilities for their domain.
2. **General as default**: If no specialist matches, or the message is casual \
conversation / a simple question, route to "general".
3. **Session continuity**: If the user is continuing an active conversation \
with an agent, prefer resuming that session — even if another agent could \
also handle it. Context continuity matters.
4. **Confidence honesty**: Only rate confidence > 0.8 when the intent is \
unambiguous. Ambiguous messages should get lower confidence.

## INPUT

You will receive:
1. A routing table listing available agents and skills with descriptions
2. Optionally, a list of active sessions the user has open
3. The user's message

## DECISION RULES

- Match the message to the most appropriate agent (and skill, if applicable) \
from the routing table.
- If the message clearly relates to an active session's topic, set \
session_action to "resume" and include the session_id.
- If the message is a new topic or there are no active sessions, set \
session_action to "new" and leave session_id as null.
- Assign a confidence score between 0.0 and 1.0.
- Provide brief reasoning explaining your decision.

## OUTPUT FORMAT

Respond with ONLY a JSON object matching this exact schema (no markdown, no \
explanation outside the JSON):

{
  "agent_name": "<name of the target agent>",
  "skill_name": "<name of the specific skill, or null>",
  "confidence": <float between 0.0 and 1.0>,
  "session_action": "<'new' or 'resume'>",
  "session_id": "<session ID to resume, or null>",
  "reasoning": "<brief explanation>",
  "needs_confirmation": <true if confidence is low or ambiguous>
}
"""

# Regex to strip markdown code fences from Haiku responses
_CODE_FENCE_RE = re.compile(
    r"```(?:json)?\s*\n?(.*?)\n?\s*```",
    re.DOTALL,
)


# ---------------------------------------------------------------------------
# Fallback decision
# ---------------------------------------------------------------------------

def _fallback_decision(reason: str) -> RoutingDecision:
    """Return a safe fallback routing decision."""
    return RoutingDecision(
        agent_name="general",
        skill_name=None,
        confidence=0.1,
        session_action="new",
        session_id=None,
        reasoning=reason,
        needs_confirmation=True,
    )


# ---------------------------------------------------------------------------
# RelayRouter
# ---------------------------------------------------------------------------


class RelayRouter:
    """Haiku-based semantic message dispatcher.

    Uses Anthropic SDK (NOT Claude Code CLI) for classification.
    No tools, no file access -- classification only.
    """

    def __init__(
        self,
        api_key: str,
        confidence_threshold: float = 0.8,
        model: str = "claude-haiku-4-5-20251001",
        base_url: str | None = None,
    ) -> None:
        self._confidence_threshold = confidence_threshold
        self._model = model

        kwargs: dict[str, str] = {"api_key": api_key}
        if base_url is not None:
            kwargs["base_url"] = base_url

        self._client = anthropic.AsyncAnthropic(**kwargs)

    # -----------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------

    async def route(
        self,
        message_text: str,
        routing_table: list[RoutingEntry],
        active_sessions: list[SessionSummary] | None = None,
    ) -> RoutingDecision:
        """Classify *message_text* and return a routing decision.

        On empty routing table, SDK errors, or parse failures, returns a
        safe fallback decision (general agent, needs_confirmation=True).
        """
        # Short-circuit: empty routing table
        if not routing_table:
            logger.warning("Empty routing table — falling back to general agent")
            return _fallback_decision("No agents available in routing table")

        # Build the user message
        user_content = self._build_user_message(
            message_text, routing_table, active_sessions
        )

        # Call the Anthropic API
        try:
            response = await self._client.messages.create(
                model=self._model,
                system=_ROUTING_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_content}],
                max_tokens=512,
            )
        except Exception:
            logger.exception("Anthropic API call failed — returning fallback")
            return _fallback_decision("API call failed")

        # Extract text from response
        raw_text = self._extract_text(response)
        if raw_text is None:
            return _fallback_decision("No text content in API response")

        # Parse JSON -> RoutingDecision
        decision = self._parse_decision(raw_text)

        # Enforce confidence threshold
        if decision.confidence < self._confidence_threshold:
            decision = decision.model_copy(update={"needs_confirmation": True})

        return decision

    # -----------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------

    @staticmethod
    def _build_user_message(
        message_text: str,
        routing_table: list[RoutingEntry],
        active_sessions: list[SessionSummary] | None,
    ) -> str:
        """Compose the user message sent to Haiku."""
        parts: list[str] = []

        # Routing table
        parts.append("## Routing Table\n")
        for entry in routing_table:
            skill_label = f" (skill: {entry.skill_name})" if entry.skill_name else ""
            parts.append(
                f"- agent={entry.agent_name}{skill_label}: {entry.description}"
            )

        # Active sessions
        if active_sessions:
            parts.append("\n## Active Sessions\n")
            for sess in active_sessions:
                parts.append(
                    f"- session_id={sess.session_id}, agent={sess.agent_name}, "
                    f"topic=\"{sess.topic_summary}\", "
                    f"messages={sess.message_count}, "
                    f"last_active={sess.last_active.isoformat()}"
                )
        else:
            parts.append("\n## Active Sessions\n")
            parts.append("No active sessions.")

        # User message
        parts.append(f"\n## User Message\n\n{message_text}")

        return "\n".join(parts)

    @staticmethod
    def _extract_text(response: object) -> str | None:
        """Extract the first text block from an Anthropic Message response."""
        content = getattr(response, "content", None)
        if not content:
            return None

        for block in content:
            if getattr(block, "type", None) == "text":
                return getattr(block, "text", None)

        return None

    def _parse_decision(self, raw_text: str) -> RoutingDecision:
        """Parse raw response text into a RoutingDecision.

        Handles optional markdown code fences. Returns fallback on failure.
        """
        text = raw_text.strip()

        # Strip markdown code fences if present
        fence_match = _CODE_FENCE_RE.search(text)
        if fence_match:
            text = fence_match.group(1).strip()

        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            logger.warning("Failed to parse routing response as JSON: %s", text[:200])
            return _fallback_decision("Failed to parse JSON from routing response")

        try:
            return RoutingDecision.model_validate(data)
        except Exception:
            logger.warning("Failed to validate routing decision: %s", data)
            return _fallback_decision("Invalid routing decision structure")
