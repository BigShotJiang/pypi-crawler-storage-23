"""Parse agent responses to extract intent tags and produce clean text.

Intent tags are bracket-delimited directives embedded in LLM output:
  [REMEMBER: user prefers dark mode]
  [GOAL: finish report | DEADLINE: 2026-03-01]

This module extracts them into structured IntentTag objects and returns
the remaining user-facing text with all tags stripped.

Safety: all extraction is regex-based. Content is stored as plain strings
and is never evaluated, exec'd, or interpreted as code.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Tag types we recognise
# ---------------------------------------------------------------------------
_SIMPLE_TAG_TYPES = frozenset({"REMEMBER", "FORGET", "DONE", "CANCEL"})
_JSON_TAG_TYPES = frozenset({"PROPOSE_SKILL"})
_ALL_TAG_TYPES = _SIMPLE_TAG_TYPES | _JSON_TAG_TYPES | {"GOAL"}

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class IntentTag:
    """A single extracted intent tag."""

    tag_type: str  # REMEMBER, FORGET, GOAL, DONE, CANCEL, PROPOSE_SKILL
    content: str
    metadata: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class ParsedResponse:
    """Result of parsing an agent response."""

    clean_text: str  # Tags stripped
    tags: list[IntentTag] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------

# Build alternation of known tag types
_TAG_NAMES = "|".join(sorted(_ALL_TAG_TYPES))

# Match [TAG_TYPE: content] — non-greedy on content so nested brackets
# cause the match to stop at the first ']'. This means nested brackets
# like [REMEMBER: use [square] brackets] will match up to the first ']'
# and leave the rest as text, which is the safest behaviour.
_TAG_PATTERN = re.compile(
    rf"\[({_TAG_NAMES}):\s+(.*?)\]",
    re.DOTALL,
)

# GOAL-specific sub-pattern for optional DEADLINE
_GOAL_DEADLINE = re.compile(
    r"^(.*?)\s*\|\s*DEADLINE:\s*(\S+)$",
    re.DOTALL,
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def parse_response(text: str) -> ParsedResponse:
    """Extract all intent tags from *text* and return clean text + tags.

    Malformed or empty tags are silently ignored (logged at debug level).
    """
    tags: list[IntentTag] = []
    clean = text

    for match in _TAG_PATTERN.finditer(text):
        tag_type = match.group(1)
        raw_content = match.group(2).strip()

        if not raw_content:
            logger.debug("Ignoring empty %s tag", tag_type)
            continue

        tag = _build_tag(tag_type, raw_content)
        if tag is not None:
            tags.append(tag)

    # Strip all matched tags from the user-facing text
    clean = _TAG_PATTERN.sub("", clean)
    # Normalise whitespace: collapse runs of spaces, strip edges
    clean = re.sub(r"  +", " ", clean).strip()

    return ParsedResponse(clean_text=clean, tags=tags)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _build_tag(tag_type: str, raw_content: str) -> IntentTag | None:
    """Build an IntentTag from the tag type and raw content string."""

    if tag_type == "GOAL":
        return _parse_goal(raw_content)

    # Simple tags and JSON tags share the same shape — content is always a
    # plain string. Callers wanting structured data from PROPOSE_SKILL
    # can json.loads(tag.content) themselves.
    return IntentTag(tag_type=tag_type, content=raw_content, metadata={})


def _parse_goal(raw_content: str) -> IntentTag:
    """Parse GOAL content which may include ``| DEADLINE: <date>``."""
    deadline_match = _GOAL_DEADLINE.match(raw_content)
    if deadline_match:
        goal_text = deadline_match.group(1).strip()
        deadline = deadline_match.group(2).strip()
        return IntentTag(
            tag_type="GOAL",
            content=goal_text,
            metadata={"deadline": deadline},
        )
    return IntentTag(tag_type="GOAL", content=raw_content, metadata={})
