def main() -> None:
    print("Hello from shikigami-bot!")
