"""Langfuse observability adapter (stub)."""
from __future__ import annotations

# TODO: implement Langfuse tracing adapter
