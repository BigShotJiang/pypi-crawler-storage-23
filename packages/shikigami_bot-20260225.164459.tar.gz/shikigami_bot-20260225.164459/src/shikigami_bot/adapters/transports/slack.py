"""Slack transport adapter using Slack Bolt + Socket Mode.

Implements TransportPort protocol. Socket Mode requires no public URL and
works behind firewalls (e.g. on Elysium/Proxmox).

Channel → thread mapping:
  chat_id   = Slack channel ID (e.g. "C01234ABCDE")
  thread_id = Slack thread_ts (e.g. "1234567890.123456") — None for top-level
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any, Callable, Coroutine

import structlog
from slack_bolt.async_app import AsyncApp
from slack_sdk.web.async_client import AsyncWebClient

from shikigami_bot.domain.message import Message

log = structlog.get_logger()

# Maximum character length for a single Slack block text element.
_SLACK_MAX_TEXT = 3000


class SlackTransport:
    """Slack transport adapter using Slack Bolt (Socket Mode).

    Implements TransportPort protocol.
    chat_id  = Slack channel ID
    thread_id = Slack thread_ts; None means top-level channel message
    """

    def __init__(self, app: AsyncApp, client: AsyncWebClient) -> None:
        self._app = app
        self._client = client

    # ------------------------------------------------------------------
    # TransportPort interface
    # ------------------------------------------------------------------

    async def send(
        self,
        chat_id: str,
        text: str,
        reply_to_message_id: str | None = None,
        thread_id: str | None = None,
    ) -> None:
        """Post a message to a Slack channel, chunking if necessary."""
        chunks = _chunk_message(text)

        for chunk in chunks:
            kwargs: dict[str, Any] = {
                "channel": chat_id,
                "text": chunk,
            }
            if thread_id is not None:
                kwargs["thread_ts"] = thread_id
            # Slack has no first-class reply_to for non-threaded messages;
            # thread_ts is the canonical way to continue a thread. We accept
            # reply_to_message_id for interface parity but prefer thread_id.
            elif reply_to_message_id is not None:
                kwargs["thread_ts"] = reply_to_message_id

            try:
                await self._client.chat_postMessage(**kwargs)
            except Exception:
                log.exception(
                    "slack.send_failed",
                    chat_id=chat_id,
                    thread_id=thread_id,
                )
                raise

    async def ask_user(
        self,
        chat_id: str,
        question: str,
        options: list[str],
        thread_id: str | None = None,
    ) -> str:
        """Post a question with numbered options as a plain text message.

        Slack does not have an inline keyboard equivalent in the same sense as
        Telegram, so we format the options as a numbered list. Returns the first
        option as default — real selection handling is the pipeline's responsibility.
        """
        numbered = "\n".join(f"{i + 1}. {opt}" for i, opt in enumerate(options))
        full_text = f"{question}\n\n{numbered}"

        kwargs: dict[str, Any] = {
            "channel": chat_id,
            "text": full_text,
        }
        if thread_id is not None:
            kwargs["thread_ts"] = thread_id

        await self._client.chat_postMessage(**kwargs)
        return options[0]

    async def ask_user_text(
        self,
        chat_id: str,
        question: str,
        thread_id: str | None = None,
    ) -> str:
        """Post a question and return empty string (Slack has no inline text input).

        The pipeline should handle text replies via message events.
        """
        kwargs: dict[str, Any] = {"channel": chat_id, "text": question}
        if thread_id is not None:
            kwargs["thread_ts"] = thread_id
        await self._client.chat_postMessage(**kwargs)
        return ""

    async def send_progress(
        self,
        chat_id: str,
        text: str,
        message_id: str | None = None,
        thread_id: str | None = None,
    ) -> str:
        """Send or update a progress indicator message. Returns message ts."""
        if message_id is not None:
            try:
                await self._client.chat_update(
                    channel=chat_id,
                    ts=message_id,
                    text=text,
                )
                return message_id
            except Exception:
                pass  # Fall through to send new message

        kwargs: dict[str, Any] = {"channel": chat_id, "text": text}
        if thread_id is not None:
            kwargs["thread_ts"] = thread_id
        result = await self._client.chat_postMessage(**kwargs)
        return result.get("ts", "")

    async def delete_message(self, chat_id: str, message_id: str) -> None:
        """Delete a message. Swallows errors if the message is already gone."""
        try:
            await self._client.chat_delete(channel=chat_id, ts=message_id)
        except Exception:
            pass

    async def send_typing(self, chat_id: str, thread_id: str | None = None) -> None:
        """No-op: Slack bots do not have a native typing indicator API.

        The method exists for TransportPort protocol compliance.
        """
        # Slack does not expose a bot typing indicator via the Web API.
        # We log at trace level so callers can verify the no-op is intentional.
        await log.adebug(
            "slack.send_typing.noop",
            chat_id=chat_id,
            thread_id=thread_id,
        )

    async def send_voice(
        self,
        chat_id: str,
        audio: bytes,
        thread_id: str | None = None,
    ) -> None:
        """Upload audio as a voice message to a Slack channel.

        Uses the Slack Web API ``files_uploadV2`` endpoint.  The audio is
        uploaded as an OGG file; Slack renders it inline as an audio player.
        """
        kwargs: dict[str, Any] = {
            "channel": chat_id,
            "filename": "voice.ogg",
            "content": audio,
            "title": "Voice message",
        }
        if thread_id:
            kwargs["thread_ts"] = thread_id
        await self._client.files_uploadV2(**kwargs)

    # ------------------------------------------------------------------
    # Message conversion
    # ------------------------------------------------------------------

    @staticmethod
    def to_domain_message(event: dict[str, Any]) -> Message:
        """Convert a Slack event payload to our domain Message model.

        Handles both channel messages and app_mention events. The ``event``
        dict is the inner ``event`` block from a Slack Events API payload or
        the dict passed by Slack Bolt's event handler.

        Mapping:
          chat_id   = event["channel"]
          user_id   = event["user"]
          thread_id = event.get("thread_ts") — present only when in a thread
          text      = event["text"] (may contain @mention markup)
          timestamp = event["ts"] converted from Slack epoch float
        """
        raw_ts = event.get("ts", "0")
        try:
            epoch = float(raw_ts)
        except (ValueError, TypeError):
            epoch = 0.0
        timestamp = datetime.fromtimestamp(epoch, tz=timezone.utc)

        thread_ts = event.get("thread_ts")
        # Slack sets thread_ts == ts for the root message of a thread; we only
        # treat a message as being *in* a thread when it differs from its own ts.
        if thread_ts is not None and thread_ts == raw_ts:
            thread_ts = None

        # The username field in Slack events is the display/real name, not a
        # handle, and is not always present. We use the user ID as the canonical
        # identifier and leave username None when unavailable.
        username: str | None = event.get("username") or event.get("user_name") or None

        return Message(
            transport="slack",
            chat_id=event.get("channel", ""),
            thread_id=thread_ts,
            user_id=event.get("user", ""),
            username=username,
            text=event.get("text", ""),
            timestamp=timestamp,
            reply_to_message_id=None,
        )

    # ------------------------------------------------------------------
    # Handler registration helper
    # ------------------------------------------------------------------

    def register_handlers(
        self,
        on_message: Callable[[Message], Coroutine[Any, Any, None]],
    ) -> None:
        """Register Slack Bolt event handlers that feed into the pipeline.

        Args:
            on_message: Async callback invoked with a domain Message for each
                        incoming event (app_mention or direct message).
        """
        app = self._app

        async def _dispatch(event: dict[str, Any]) -> None:
            try:
                domain_msg = SlackTransport.to_domain_message(event)
                await on_message(domain_msg)
            except Exception:
                log.exception("slack.handler_error", event_type=event.get("type"))

        @app.event("app_mention")
        async def handle_mention(event: dict[str, Any]) -> None:  # type: ignore[misc]
            await _dispatch(event)

        @app.event("message")
        async def handle_message(event: dict[str, Any]) -> None:  # type: ignore[misc]
            # Ignore bot messages and message-changed subtypes to avoid loops
            subtype = event.get("subtype")
            if subtype in {"bot_message", "message_changed", "message_deleted"}:
                return
            if event.get("bot_id"):
                return
            await _dispatch(event)


# ------------------------------------------------------------------
# Internal helpers
# ------------------------------------------------------------------


def _chunk_message(text: str, max_length: int = _SLACK_MAX_TEXT) -> list[str]:
    """Split text into chunks that fit within Slack's text limit.

    Uses the same priority order as the Telegram adapter:
    1. Paragraph boundaries (\\n\\n)
    2. Line breaks (\\n)
    3. Word boundaries (space)
    4. Hard split at max_length
    """
    if len(text) <= max_length:
        return [text]

    chunks: list[str] = []
    paragraphs = text.split("\n\n")
    current = ""

    for para in paragraphs:
        candidate = f"{current}\n\n{para}" if current else para

        if len(candidate) <= max_length:
            current = candidate
        else:
            if current:
                chunks.append(current)
                current = ""

            if len(para) <= max_length:
                current = para
            else:
                sub_chunks = _split_at_boundary(para, "\n", max_length)
                chunks.extend(sub_chunks[:-1])
                current = sub_chunks[-1]

    if current:
        chunks.append(current)

    return chunks


def _split_at_boundary(text: str, separator: str, max_length: int) -> list[str]:
    parts = text.split(separator)
    chunks: list[str] = []
    current = ""

    for part in parts:
        candidate = f"{current}{separator}{part}" if current else part

        if len(candidate) <= max_length:
            current = candidate
        else:
            if current:
                chunks.append(current)
                current = ""

            if len(part) <= max_length:
                current = part
            else:
                word_chunks = _split_at_words(part, max_length)
                chunks.extend(word_chunks[:-1])
                current = word_chunks[-1]

    if current:
        chunks.append(current)

    return chunks


def _split_at_words(text: str, max_length: int) -> list[str]:
    words = text.split(" ")
    chunks: list[str] = []
    current = ""

    for word in words:
        candidate = f"{current} {word}" if current else word

        if len(candidate) <= max_length:
            current = candidate
        else:
            if current:
                chunks.append(current)
            if len(word) <= max_length:
                current = word
            else:
                hard_chunks = _hard_split(word, max_length)
                chunks.extend(hard_chunks[:-1])
                current = hard_chunks[-1]

    if current:
        chunks.append(current)

    return chunks if chunks else [text]


def _hard_split(text: str, max_length: int) -> list[str]:
    return [text[i : i + max_length] for i in range(0, len(text), max_length)]
