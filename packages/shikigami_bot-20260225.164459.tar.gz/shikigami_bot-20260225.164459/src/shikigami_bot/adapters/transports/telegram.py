"""Telegram transport adapter using aiogram 3.x.

Implements TransportPort protocol. Handles markdown sanitization,
message chunking, forum topics, and voice I/O via Deepgram.
"""
from __future__ import annotations

import asyncio
import io
import logging
import re
from datetime import timezone

import aiogram
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from shikigami_bot.domain.memory import MemoryStore
from shikigami_bot.domain.message import Message
from shikigami_bot.domain.ports import STTPort, TTSPort

logger = logging.getLogger(__name__)

VOICE_PREFERENCE_KEY = "voice_preference"
VALID_VOICE_PREFERENCES = frozenset({"voice", "text", "both"})
DEFAULT_VOICE_PREFERENCE = "text"


class TelegramTransport:
    """Telegram transport adapter using aiogram.

    Implements TransportPort protocol.
    Handles markdown sanitization, message chunking, forum topics, and voice I/O.
    """

    def __init__(
        self,
        bot: aiogram.Bot,
        stt: STTPort | None = None,
        tts: TTSPort | None = None,
        memory: MemoryStore | None = None,
    ) -> None:
        self._bot = bot
        self._stt = stt
        self._tts = tts
        self._memory = memory
        # Pending inline-button callbacks: chat_id -> Future[str]
        self._pending_callbacks: dict[str, asyncio.Future[str]] = {}
        # Pending free-text replies: chat_id -> Future[str]
        self._pending_text_replies: dict[str, asyncio.Future[str]] = {}

    def resolve_callback(self, chat_id: str, chosen: str) -> None:
        """Resolve a pending ask_user() Future when the user clicks an inline button."""
        future = self._pending_callbacks.pop(chat_id, None)
        if future is not None and not future.done():
            future.set_result(chosen)

    # ------------------------------------------------------------------
    # TransportPort interface
    # ------------------------------------------------------------------

    async def send(
        self,
        chat_id: str,
        text: str,
        reply_to_message_id: str | None = None,
        thread_id: str | None = None,
    ) -> None:
        """Send a message, chunking if necessary and sanitizing markdown."""
        sanitized = self._sanitize_markdown(text)
        chunks = self._chunk_message(sanitized)

        for chunk in chunks:
            kwargs: dict = {
                "chat_id": chat_id,
                "text": chunk,
                "parse_mode": "Markdown",
            }
            if reply_to_message_id is not None:
                kwargs["reply_to_message_id"] = reply_to_message_id
            if thread_id is not None:
                kwargs["message_thread_id"] = thread_id

            try:
                await self._bot.send_message(**kwargs)
            except TelegramBadRequest:
                # Fallback: retry without formatting
                kwargs.pop("parse_mode", None)
                kwargs["parse_mode"] = None
                kwargs["text"] = chunk.replace("*", "").replace("_", "")
                await self._bot.send_message(**kwargs)

    async def ask_user(
        self,
        chat_id: str,
        question: str,
        options: list[str],
        thread_id: str | None = None,
        timeout: float = 60.0,
    ) -> str:
        """Send a question with inline keyboard buttons and wait for the user's click.

        Registers a Future in _pending_callbacks keyed by chat_id.
        The @dp.callback_query() handler in main.py resolves the Future
        when the user taps a button. Falls back to options[0] on timeout.
        """
        buttons = [
            [InlineKeyboardButton(text=opt, callback_data=opt)]
            for opt in options
        ]
        markup = InlineKeyboardMarkup(inline_keyboard=buttons)

        kwargs: dict = {
            "chat_id": chat_id,
            "text": question,
            "reply_markup": markup,
        }
        if thread_id is not None:
            kwargs["message_thread_id"] = thread_id

        loop = asyncio.get_event_loop()
        future: asyncio.Future[str] = loop.create_future()
        self._pending_callbacks[chat_id] = future

        await self._bot.send_message(**kwargs)

        try:
            return await asyncio.wait_for(asyncio.shield(future), timeout=timeout)
        except TimeoutError:
            logger.warning("ask_user timeout for chat_id=%s, falling back to %s", chat_id, options[0])
            self._pending_callbacks.pop(chat_id, None)
            return options[0]

    async def ask_user_text(
        self,
        chat_id: str,
        question: str,
        thread_id: str | None = None,
        timeout: float = 120.0,
    ) -> str:
        """Ask the user for free-text input and wait for a message reply.

        Sends a question (no inline buttons). The next message from the user
        in that chat is captured via a Future registered in _pending_text_replies.
        """
        kwargs: dict = {"chat_id": chat_id, "text": question}
        if thread_id is not None:
            kwargs["message_thread_id"] = thread_id

        loop = asyncio.get_event_loop()
        future: asyncio.Future[str] = loop.create_future()
        self._pending_text_replies[chat_id] = future

        await self._bot.send_message(**kwargs)

        try:
            return await asyncio.wait_for(asyncio.shield(future), timeout=timeout)
        except TimeoutError:
            logger.warning("ask_user_text timeout for chat_id=%s", chat_id)
            self._pending_text_replies.pop(chat_id, None)
            return ""

    def resolve_text_reply(self, chat_id: str, text: str) -> bool:
        """Resolve a pending ask_user_text() Future. Returns True if consumed."""
        future = self._pending_text_replies.pop(chat_id, None)
        if future is not None and not future.done():
            future.set_result(text)
            return True
        return False

    async def send_photo(
        self,
        chat_id: str,
        photo: bytes,
        caption: str | None = None,
        thread_id: str | None = None,
    ) -> None:
        """Send a photo (PNG bytes) to a chat."""
        photo_file = aiogram.types.BufferedInputFile(photo, filename="qrcode.png")
        kwargs: dict = {"chat_id": chat_id, "photo": photo_file}
        if caption is not None:
            kwargs["caption"] = caption
        if thread_id is not None:
            kwargs["message_thread_id"] = thread_id
        await self._bot.send_photo(**kwargs)

    async def send_progress(
        self,
        chat_id: str,
        text: str,
        message_id: str | None = None,
        thread_id: str | None = None,
    ) -> str:
        """Send or update a progress indicator message. Returns the message ID."""
        if message_id is not None:
            try:
                await self._bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=int(message_id),
                    text=text,
                )
                return message_id
            except TelegramBadRequest:
                pass  # Message unchanged or deleted — send a new one

        kwargs: dict = {"chat_id": chat_id, "text": text}
        if thread_id is not None:
            kwargs["message_thread_id"] = thread_id
        sent = await self._bot.send_message(**kwargs)
        return str(sent.message_id)

    async def delete_message(self, chat_id: str, message_id: str) -> None:
        """Delete a message. Swallows errors if the message is already gone."""
        try:
            await self._bot.delete_message(chat_id=chat_id, message_id=int(message_id))
        except TelegramBadRequest:
            pass

    async def send_typing(self, chat_id: str, thread_id: str | None = None) -> None:
        """Send 'typing' chat action."""
        kwargs: dict = {
            "chat_id": chat_id,
            "action": "typing",
        }
        if thread_id is not None:
            kwargs["message_thread_id"] = thread_id

        await self._bot.send_chat_action(**kwargs)

    async def send_voice(
        self,
        chat_id: str,
        audio: bytes,
        thread_id: str | None = None,
    ) -> None:
        """Send an OGG/Opus voice message.

        Args:
            chat_id: Target chat identifier.
            audio: OGG/Opus audio bytes.
            thread_id: Forum thread ID, if applicable.
        """
        voice_file = aiogram.types.BufferedInputFile(audio, filename="voice.ogg")
        kwargs: dict = {
            "chat_id": chat_id,
            "voice": voice_file,
        }
        if thread_id is not None:
            kwargs["message_thread_id"] = thread_id

        await self._bot.send_voice(**kwargs)

    # ------------------------------------------------------------------
    # Voice preference commands
    # ------------------------------------------------------------------

    async def handle_voice_command(self, message: Message) -> bool:
        """Handle /voice, /text, /both commands. Returns True if handled."""
        text = message.text.strip().lower()
        if text not in ("/voice", "/text", "/both"):
            return False

        preference = text.lstrip("/")

        if self._memory is None:
            await self.send(
                chat_id=message.chat_id,
                text="Voice preferences are not available (no memory store configured).",
                thread_id=message.thread_id,
            )
            return True

        await self._memory.set(message.user_id, VOICE_PREFERENCE_KEY, preference)

        labels = {"voice": "voice only", "text": "text only", "both": "text and voice"}
        await self.send(
            chat_id=message.chat_id,
            text=f"Response mode set to *{labels[preference]}*.",
            thread_id=message.thread_id,
        )
        return True

    async def send_with_voice_preference(
        self,
        chat_id: str,
        text: str,
        user_id: str,
        reply_to_message_id: str | None = None,
        thread_id: str | None = None,
    ) -> None:
        """Send a response respecting the user's voice preference.

        Reads preference from MemoryStore. Falls back to text if TTS
        is unavailable or synthesis fails.
        """
        preference = DEFAULT_VOICE_PREFERENCE

        if self._memory is not None:
            stored = await self._memory.get(user_id, VOICE_PREFERENCE_KEY)
            if stored in VALID_VOICE_PREFERENCES:
                preference = stored

        send_text = preference in ("text", "both")
        send_voice = preference in ("voice", "both") and self._tts is not None

        if send_voice:
            try:
                audio = await self._tts.synthesize(text)
                if audio:
                    await self.send_voice(chat_id=chat_id, audio=audio, thread_id=thread_id)
                else:
                    # Empty audio = synthesis failed, fall back to text
                    send_text = True
            except Exception:
                logger.exception("telegram.tts.synthesis_failed")
                send_text = True

        if send_text or (preference == "voice" and self._tts is None):
            await self.send(
                chat_id=chat_id,
                text=text,
                reply_to_message_id=reply_to_message_id,
                thread_id=thread_id,
            )

    # ------------------------------------------------------------------
    # Message conversion
    # ------------------------------------------------------------------

    @classmethod
    async def to_domain_message_with_stt(
        cls,
        msg: aiogram.types.Message,
        stt: STTPort | None = None,
    ) -> Message:
        """Convert an aiogram Message to a domain Message, transcribing voice if needed.

        If the message contains a voice note and an STT adapter is provided,
        downloads the audio and transcribes it. The transcript is injected as
        the message text. Falls back to empty text if STT is unavailable or fails.
        """
        domain_msg = cls.to_domain_message(msg)

        if msg.voice is not None and stt is not None:
            try:
                file = await msg.bot.get_file(msg.voice.file_id)
                buf = io.BytesIO()
                await msg.bot.download_file(file.file_path, buf)
                audio_bytes = buf.getvalue()
                transcript = await stt.transcribe(audio_bytes, mime_type="audio/ogg")
                if transcript:
                    domain_msg = Message(
                        transport=domain_msg.transport,
                        chat_id=domain_msg.chat_id,
                        thread_id=domain_msg.thread_id,
                        user_id=domain_msg.user_id,
                        username=domain_msg.username,
                        text=transcript,
                        timestamp=domain_msg.timestamp,
                        reply_to_message_id=domain_msg.reply_to_message_id,
                    )
            except Exception:
                logger.exception("telegram.voice.stt_failed")

        return domain_msg

    @staticmethod
    def to_domain_message(msg: aiogram.types.Message) -> Message:
        """Convert an aiogram Message to our domain Message model."""
        # Ensure timezone-aware datetime
        timestamp = msg.date
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=timezone.utc)

        # Extract reply_to_message_id if present
        reply_to = None
        if msg.reply_to_message is not None:
            reply_to = str(msg.reply_to_message.message_id)

        return Message(
            transport="telegram",
            chat_id=str(msg.chat.id),
            thread_id=str(msg.message_thread_id) if msg.message_thread_id is not None else None,
            user_id=str(msg.from_user.id) if msg.from_user else "0",
            username=msg.from_user.username if msg.from_user else None,
            text=msg.text or "",
            timestamp=timestamp,
            reply_to_message_id=reply_to,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _sanitize_markdown(text: str) -> str:
        """Sanitize markdown for Telegram's strict parser.

        Rules:
        - Convert **bold** -> *bold* (Telegram Markdown v1)
        - Convert __italic__ -> _italic_
        - Keep `code` and ```code blocks``` unchanged
        - Escape unmatched * and _ chars
        """
        # Extract code blocks and inline code to protect them
        code_blocks: list[str] = []
        placeholder_prefix = "\x00CODE_BLOCK_"

        def _replace_code_block(match: re.Match) -> str:
            idx = len(code_blocks)
            code_blocks.append(match.group(0))
            return f"{placeholder_prefix}{idx}\x00"

        # Protect fenced code blocks first (```...```)
        result = re.sub(r"```[\s\S]*?```", _replace_code_block, text)
        # Then inline code (`...`)
        result = re.sub(r"`[^`]+`", _replace_code_block, result)

        # Convert **bold** -> *bold*
        result = re.sub(r"\*\*(.+?)\*\*", r"*\1*", result)

        # Convert __italic__ -> _italic_
        result = re.sub(r"__(.+?)__", r"_\1_", result)

        # Escape unmatched * (odd count outside of matched pairs)
        # First, find all * that are part of matched pairs *...*
        # and escape any remaining lone *
        result = _escape_unmatched(result, "*")
        result = _escape_unmatched(result, "_")

        # Restore code blocks
        for idx, block in enumerate(code_blocks):
            result = result.replace(f"{placeholder_prefix}{idx}\x00", block)

        return result

    @staticmethod
    def _chunk_message(text: str, max_length: int = 4096) -> list[str]:
        """Split text into chunks respecting Telegram's message limit.

        Priority:
        1. Split at paragraph boundaries (\\n\\n)
        2. Split at line breaks (\\n)
        3. Split at word boundaries (space)
        4. Hard split at max_length
        """
        if len(text) <= max_length:
            return [text]

        chunks: list[str] = []

        # Try splitting at paragraph boundaries first
        paragraphs = text.split("\n\n")
        current = ""

        for para in paragraphs:
            candidate = f"{current}\n\n{para}" if current else para

            if len(candidate) <= max_length:
                current = candidate
            else:
                # Current chunk is full, push it
                if current:
                    chunks.append(current)
                    current = ""

                # Check if this single paragraph fits
                if len(para) <= max_length:
                    current = para
                else:
                    # Paragraph itself is too long; split further at line breaks
                    sub_chunks = _split_at_boundary(para, "\n", max_length)
                    # All but last go directly to chunks
                    chunks.extend(sub_chunks[:-1])
                    current = sub_chunks[-1]

        if current:
            chunks.append(current)

        return chunks


def _escape_unmatched(text: str, char: str) -> str:
    """Escape unmatched occurrences of char (e.g. * or _).

    Matched pairs like *bold* are left alone.
    Lone characters are escaped with backslash.
    """
    # Find positions of unescaped chars
    positions: list[int] = []
    i = 0
    while i < len(text):
        if text[i] == "\\" and i + 1 < len(text) and text[i + 1] == char:
            i += 2  # skip already-escaped
            continue
        if text[i] == char:
            positions.append(i)
        i += 1

    if len(positions) % 2 == 0:
        # Even count — all matched
        return text

    # Odd count — escape the last unmatched one
    last_pos = positions[-1]
    text = text[:last_pos] + "\\" + text[last_pos:]
    return text


def _split_at_boundary(text: str, separator: str, max_length: int) -> list[str]:
    """Split text at the given separator, respecting max_length.

    Falls back to word boundaries, then hard split.
    """
    parts = text.split(separator)
    chunks: list[str] = []
    current = ""

    for part in parts:
        candidate = f"{current}{separator}{part}" if current else part

        if len(candidate) <= max_length:
            current = candidate
        else:
            if current:
                chunks.append(current)
                current = ""

            if len(part) <= max_length:
                current = part
            else:
                # Still too long, try word boundary split
                word_chunks = _split_at_words(part, max_length)
                chunks.extend(word_chunks[:-1])
                current = word_chunks[-1]

    if current:
        chunks.append(current)

    return chunks


def _split_at_words(text: str, max_length: int) -> list[str]:
    """Split text at word boundaries (spaces), falling back to hard split."""
    words = text.split(" ")
    chunks: list[str] = []
    current = ""

    for word in words:
        candidate = f"{current} {word}" if current else word

        if len(candidate) <= max_length:
            current = candidate
        else:
            if current:
                chunks.append(current)
            if len(word) <= max_length:
                current = word
            else:
                # Hard split: word itself exceeds max_length
                hard_chunks = _hard_split(word, max_length)
                chunks.extend(hard_chunks[:-1])
                current = hard_chunks[-1]

    if current:
        chunks.append(current)

    return chunks if chunks else [text]


def _hard_split(text: str, max_length: int) -> list[str]:
    """Hard split text at max_length boundaries."""
    return [text[i : i + max_length] for i in range(0, len(text), max_length)]
