"""Deepgram speech-to-text adapter.

Implements STTPort using Deepgram's Nova model.
Accepts OGG/Opus bytes directly — no local audio conversion required.
API key is injected at construction time from Config.
"""
from __future__ import annotations

import logging

import httpx

logger = logging.getLogger(__name__)

_DEEPGRAM_STT_URL = "https://api.deepgram.com/v1/listen"
_DEFAULT_MODEL = "nova-2"


class DeepgramSTT:
    """Deepgram Nova speech-to-text adapter.

    Implements STTPort. Sends raw audio bytes to Deepgram and returns
    the transcript text. Supports OGG/Opus directly.
    """

    def __init__(
        self,
        api_key: str,
        model: str = _DEFAULT_MODEL,
        timeout: float = 30.0,
    ) -> None:
        self._api_key = api_key
        self._model = model
        self._timeout = timeout

    async def transcribe(self, audio: bytes, mime_type: str = "audio/ogg") -> str:
        """Transcribe audio bytes to text using Deepgram Nova.

        Args:
            audio: Raw audio bytes (OGG/Opus or other Deepgram-supported format).
            mime_type: MIME type of the audio (default: audio/ogg).

        Returns:
            Transcript string, or empty string if transcription fails.
        """
        headers = {
            "Authorization": f"Token {self._api_key}",
            "Content-Type": mime_type,
        }
        params = {
            "model": self._model,
            "punctuate": "true",
            "language": "en-US",
        }

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(
                _DEEPGRAM_STT_URL,
                content=audio,
                headers=headers,
                params=params,
            )

        if response.status_code != 200:
            logger.warning(
                "deepgram.stt.error: status=%d body=%s",
                response.status_code,
                response.text[:200],
            )
            return ""

        data = response.json()
        try:
            transcript = (
                data["results"]["channels"][0]["alternatives"][0]["transcript"]
            )
            return transcript
        except (KeyError, IndexError, TypeError):
            logger.warning(
                "deepgram.stt.parse_error: response=%s",
                str(data)[:200],
            )
            return ""
