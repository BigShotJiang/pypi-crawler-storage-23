"""Deepgram text-to-speech adapter.

Implements TTSPort using Deepgram's Aura-2 model.
Returns OGG/Opus bytes suitable for sending as Telegram voice messages.
API key and voice are injected at construction time from Config.
"""
from __future__ import annotations

import logging

import httpx

logger = logging.getLogger(__name__)

_DEEPGRAM_TTS_URL = "https://api.deepgram.com/v1/speak"
_DEFAULT_VOICE = "aura-2-thalia-en"


class DeepgramTTS:
    """Deepgram Aura-2 text-to-speech adapter.

    Implements TTSPort. Sends text to Deepgram and returns OGG/Opus
    audio bytes. The voice is configurable via the voice_id parameter.
    """

    def __init__(
        self,
        api_key: str,
        voice_id: str = _DEFAULT_VOICE,
        timeout: float = 30.0,
    ) -> None:
        self._api_key = api_key
        self._voice_id = voice_id
        self._timeout = timeout

    async def synthesize(self, text: str) -> bytes:
        """Convert text to speech using Deepgram Aura-2.

        Args:
            text: The text to synthesize.

        Returns:
            OGG/Opus audio bytes, or empty bytes on failure.
        """
        headers = {
            "Authorization": f"Token {self._api_key}",
            "Content-Type": "application/json",
        }
        params = {
            "model": self._voice_id,
            "encoding": "ogg-opus",
        }
        payload = {"text": text}

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(
                _DEEPGRAM_TTS_URL,
                json=payload,
                headers=headers,
                params=params,
            )

        if response.status_code != 200:
            logger.warning(
                "deepgram.tts.error: status=%d body=%s",
                response.status_code,
                response.text[:200],
            )
            return b""

        return response.content
