"""PostgreSQL session + memory store adapter using asyncpg.

Implements both SessionStore and MemoryStore protocols.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

import asyncpg

from shikigami_bot.domain.session import Session, SessionSummary

_ACTIVE_CUTOFF_HOURS = 24


class PostgresStore:
    """PostgreSQL-backed session and memory store.

    Implements SessionStore and MemoryStore protocols.
    Requires an asyncpg connection pool.
    """

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    @classmethod
    async def create(cls, database_url: str, **pool_kwargs: object) -> PostgresStore:
        """Create a PostgresStore with a new connection pool."""
        pool = await asyncpg.create_pool(database_url, **pool_kwargs)
        return cls(pool)

    async def close(self) -> None:
        """Close the connection pool."""
        await self._pool.close()

    # ------------------------------------------------------------------
    # SessionStore protocol
    # ------------------------------------------------------------------

    async def create_session(
        self, chat_id: str, agent_name: str, topic_summary: str
    ) -> Session:
        now = datetime.now(tz=timezone.utc)
        session_id = str(uuid.uuid4())

        await self._pool.execute(
            """INSERT INTO sessions
               (session_id, chat_id, agent_name, topic_summary,
                claude_session_id, message_count, created_at, last_active)
               VALUES ($1, $2, $3, $4, NULL, 0, $5, $5)""",
            session_id, chat_id, agent_name, topic_summary, now,
        )

        return Session(
            session_id=session_id,
            chat_id=chat_id,
            agent_name=agent_name,
            topic_summary=topic_summary,
            claude_session_id=None,
            message_count=0,
            created_at=now,
            last_active=now,
        )

    async def get_session(self, session_id: str) -> Session | None:
        row = await self._pool.fetchrow(
            "SELECT * FROM sessions WHERE session_id = $1", session_id
        )
        if row is None:
            return None
        return _row_to_session(row)

    async def list_active_sessions(
        self, chat_id: str, agent_name: str | None = None
    ) -> list[SessionSummary]:
        cutoff = datetime.now(tz=timezone.utc) - timedelta(hours=_ACTIVE_CUTOFF_HOURS)

        if agent_name is not None:
            rows = await self._pool.fetch(
                """SELECT session_id, agent_name, topic_summary, message_count, last_active
                   FROM sessions
                   WHERE chat_id = $1 AND agent_name = $2 AND last_active > $3
                   ORDER BY last_active DESC""",
                chat_id, agent_name, cutoff,
            )
        else:
            rows = await self._pool.fetch(
                """SELECT session_id, agent_name, topic_summary, message_count, last_active
                   FROM sessions
                   WHERE chat_id = $1 AND last_active > $2
                   ORDER BY last_active DESC""",
                chat_id, cutoff,
            )

        return [
            SessionSummary(
                session_id=row["session_id"],
                agent_name=row["agent_name"],
                topic_summary=row["topic_summary"],
                message_count=row["message_count"],
                last_active=row["last_active"],
            )
            for row in rows
        ]

    async def update_session(
        self,
        session_id: str,
        claude_session_id: str | None = None,
        topic_summary: str | None = None,
        increment_messages: bool = False,
    ) -> None:
        now = datetime.now(tz=timezone.utc)
        sets: list[str] = ["last_active = $1"]
        values: list[object] = [now]
        idx = 2

        if claude_session_id is not None:
            sets.append(f"claude_session_id = ${idx}")
            values.append(claude_session_id)
            idx += 1

        if topic_summary is not None:
            sets.append(f"topic_summary = ${idx}")
            values.append(topic_summary)
            idx += 1

        if increment_messages:
            sets.append("message_count = message_count + 1")

        values.append(session_id)

        await self._pool.execute(
            f"UPDATE sessions SET {', '.join(sets)} WHERE session_id = ${idx}",
            *values,
        )

    # ------------------------------------------------------------------
    # MemoryStore protocol
    # ------------------------------------------------------------------

    async def get(self, user_id: str, key: str) -> str | None:
        row = await self._pool.fetchrow(
            "SELECT value FROM memory WHERE user_id = $1 AND key = $2",
            user_id, key,
        )
        return row["value"] if row else None

    async def set(self, user_id: str, key: str, value: str) -> None:
        await self._pool.execute(
            """INSERT INTO memory (user_id, key, value, updated_at)
               VALUES ($1, $2, $3, now())
               ON CONFLICT (user_id, key)
               DO UPDATE SET value = $3, updated_at = now()""",
            user_id, key, value,
        )

    async def delete(self, user_id: str, key: str) -> None:
        await self._pool.execute(
            "DELETE FROM memory WHERE user_id = $1 AND key = $2",
            user_id, key,
        )


def _row_to_session(row: asyncpg.Record) -> Session:
    """Convert an asyncpg Record to a Session domain model."""
    last_active = row["last_active"]
    created_at = row["created_at"]

    # Ensure timezone awareness
    if last_active.tzinfo is None:
        last_active = last_active.replace(tzinfo=timezone.utc)
    if created_at.tzinfo is None:
        created_at = created_at.replace(tzinfo=timezone.utc)

    return Session(
        session_id=row["session_id"],
        chat_id=row["chat_id"],
        agent_name=row["agent_name"],
        topic_summary=row["topic_summary"],
        claude_session_id=row["claude_session_id"],
        message_count=row["message_count"],
        created_at=created_at,
        last_active=last_active,
    )
