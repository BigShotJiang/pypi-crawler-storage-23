"""SQLite session + memory store adapter for local development."""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

import aiosqlite

from shikigami_bot.domain.proposal import Proposal, ProposalType
from shikigami_bot.domain.session import Session, SessionSummary

_SCHEMA_SQL = """\
CREATE TABLE IF NOT EXISTS sessions (
    session_id       TEXT PRIMARY KEY,
    chat_id          TEXT NOT NULL,
    agent_name       TEXT NOT NULL,
    topic_summary    TEXT NOT NULL,
    claude_session_id TEXT,
    message_count    INTEGER NOT NULL DEFAULT 0,
    created_at       TEXT NOT NULL,
    last_active      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS memory (
    user_id    TEXT NOT NULL,
    key        TEXT NOT NULL,
    value      TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (user_id, key)
);
"""

_ACTIVE_CUTOFF_HOURS = 24


class SQLiteStore:
    """SQLite-backed session and memory store for local development.

    Uses aiosqlite for async operations.
    Implements both SessionStore and MemoryStore protocols.
    """

    def __init__(self, db_path: str = ":memory:") -> None:
        self._db_path = db_path
        self._db: aiosqlite.Connection | None = None

    async def initialize(self) -> None:
        """Create the database connection and tables."""
        self._db = await aiosqlite.connect(self._db_path)
        self._db.row_factory = aiosqlite.Row
        await self._db.executescript(_SCHEMA_SQL)
        await self._db.commit()

    async def close(self) -> None:
        """Close the database connection."""
        if self._db is not None:
            await self._db.close()
            self._db = None

    # ------------------------------------------------------------------
    # SessionStore protocol methods
    # ------------------------------------------------------------------

    async def create_session(
        self, chat_id: str, agent_name: str, topic_summary: str
    ) -> Session:
        """Create a new session and persist it."""
        assert self._db is not None, "Store not initialized — call initialize() first"

        now = datetime.now(tz=timezone.utc)
        session = Session(
            session_id=str(uuid.uuid4()),
            chat_id=chat_id,
            agent_name=agent_name,
            topic_summary=topic_summary,
            claude_session_id=None,
            message_count=0,
            created_at=now,
            last_active=now,
        )

        await self._db.execute(
            """INSERT INTO sessions
               (session_id, chat_id, agent_name, topic_summary,
                claude_session_id, message_count, created_at, last_active)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                session.session_id,
                session.chat_id,
                session.agent_name,
                session.topic_summary,
                session.claude_session_id,
                session.message_count,
                session.created_at.isoformat(),
                session.last_active.isoformat(),
            ),
        )
        await self._db.commit()
        return session

    async def get_session(self, session_id: str) -> Session | None:
        """Retrieve a session by its id, or None if not found."""
        assert self._db is not None, "Store not initialized — call initialize() first"

        async with self._db.execute(
            "SELECT * FROM sessions WHERE session_id = ?", (session_id,)
        ) as cursor:
            row = await cursor.fetchone()

        if row is None:
            return None

        return _row_to_session(row)

    async def list_active_sessions(
        self, chat_id: str, agent_name: str | None = None
    ) -> list[SessionSummary]:
        """List active sessions for a chat, most recent first.

        Sessions with last_active older than 24 hours are excluded.
        """
        assert self._db is not None, "Store not initialized — call initialize() first"

        cutoff = (
            datetime.now(tz=timezone.utc) - timedelta(hours=_ACTIVE_CUTOFF_HOURS)
        ).isoformat()

        if agent_name is not None:
            query = (
                "SELECT session_id, agent_name, topic_summary, message_count, last_active "
                "FROM sessions "
                "WHERE chat_id = ? AND agent_name = ? AND last_active > ? "
                "ORDER BY last_active DESC"
            )
            params: tuple[str, ...] = (chat_id, agent_name, cutoff)
        else:
            query = (
                "SELECT session_id, agent_name, topic_summary, message_count, last_active "
                "FROM sessions "
                "WHERE chat_id = ? AND last_active > ? "
                "ORDER BY last_active DESC"
            )
            params = (chat_id, cutoff)

        async with self._db.execute(query, params) as cursor:
            rows = await cursor.fetchall()

        return [
            SessionSummary(
                session_id=row["session_id"],
                agent_name=row["agent_name"],
                topic_summary=row["topic_summary"],
                message_count=row["message_count"],
                last_active=datetime.fromisoformat(row["last_active"]),
            )
            for row in rows
        ]

    async def update_session(
        self,
        session_id: str,
        claude_session_id: str | None = None,
        topic_summary: str | None = None,
        increment_messages: bool = False,
    ) -> None:
        """Update mutable fields of a session."""
        assert self._db is not None, "Store not initialized — call initialize() first"

        now = datetime.now(tz=timezone.utc).isoformat()
        sets: list[str] = ["last_active = ?"]
        values: list[str | int] = [now]

        if claude_session_id is not None:
            sets.append("claude_session_id = ?")
            values.append(claude_session_id)

        if topic_summary is not None:
            sets.append("topic_summary = ?")
            values.append(topic_summary)

        if increment_messages:
            sets.append("message_count = message_count + 1")

        values.append(session_id)

        await self._db.execute(
            f"UPDATE sessions SET {', '.join(sets)} WHERE session_id = ?",
            tuple(values),
        )
        await self._db.commit()

    # ------------------------------------------------------------------
    # MemoryStore protocol methods
    # ------------------------------------------------------------------

    async def get(self, user_id: str, key: str) -> str | None:
        """Get a memory value by user_id and key."""
        assert self._db is not None, "Store not initialized — call initialize() first"

        async with self._db.execute(
            "SELECT value FROM memory WHERE user_id = ? AND key = ?",
            (user_id, key),
        ) as cursor:
            row = await cursor.fetchone()

        return row["value"] if row else None

    async def set(self, user_id: str, key: str, value: str) -> None:
        """Set a memory value, upserting if it already exists."""
        assert self._db is not None, "Store not initialized — call initialize() first"

        now = datetime.now(tz=timezone.utc).isoformat()
        await self._db.execute(
            """INSERT INTO memory (user_id, key, value, updated_at)
               VALUES (?, ?, ?, ?)
               ON CONFLICT (user_id, key)
               DO UPDATE SET value = ?, updated_at = ?""",
            (user_id, key, value, now, value, now),
        )
        await self._db.commit()

    async def delete(self, user_id: str, key: str) -> None:
        """Delete a memory entry."""
        assert self._db is not None, "Store not initialized — call initialize() first"

        await self._db.execute(
            "DELETE FROM memory WHERE user_id = ? AND key = ?",
            (user_id, key),
        )
        await self._db.commit()


# Keep backward-compatible alias
SQLiteSessionStore = SQLiteStore


def _row_to_session(row: aiosqlite.Row) -> Session:
    """Convert a database row to a Session domain model."""
    return Session(
        session_id=row["session_id"],
        chat_id=row["chat_id"],
        agent_name=row["agent_name"],
        topic_summary=row["topic_summary"],
        claude_session_id=row["claude_session_id"],
        message_count=row["message_count"],
        created_at=datetime.fromisoformat(row["created_at"]),
        last_active=datetime.fromisoformat(row["last_active"]),
    )


_CREATE_PROPOSALS_TABLE = """\
CREATE TABLE IF NOT EXISTS proposals (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_name  TEXT NOT NULL,
    type        TEXT NOT NULL CHECK (type IN ('skill', 'soul')),
    diff        TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending', 'approved', 'rejected')),
    created_at  TEXT NOT NULL
);
"""


class SQLiteProposalStore:
    """SQLite-backed proposal store for PROPOSE_SKILL HITL flow.

    Uses aiosqlite for async operations.
    Implements ProposalStore protocol.
    """

    def __init__(self, db_path: str = ":memory:") -> None:
        self._db_path = db_path
        self._db: aiosqlite.Connection | None = None

    async def initialize(self) -> None:
        """Create the database connection and proposals table."""
        self._db = await aiosqlite.connect(self._db_path)
        self._db.row_factory = aiosqlite.Row
        await self._db.execute(_CREATE_PROPOSALS_TABLE)
        await self._db.commit()

    async def close(self) -> None:
        """Close the database connection."""
        if self._db is not None:
            await self._db.close()
            self._db = None

    # ------------------------------------------------------------------
    # ProposalStore protocol methods
    # ------------------------------------------------------------------

    async def create_proposal(
        self, agent_name: str, type: str, diff: str
    ) -> int:
        """Persist a new pending proposal and return its ID."""
        assert self._db is not None, "Store not initialized — call initialize() first"

        now = datetime.now(tz=timezone.utc).isoformat()
        async with self._db.execute(
            """INSERT INTO proposals (agent_name, type, diff, status, created_at)
               VALUES (?, ?, ?, 'pending', ?)""",
            (agent_name, type, diff, now),
        ) as cursor:
            proposal_id = cursor.lastrowid
        await self._db.commit()
        assert proposal_id is not None
        return proposal_id

    async def get_proposal(self, proposal_id: int) -> Proposal | None:
        """Retrieve a proposal by ID, or None if not found."""
        assert self._db is not None, "Store not initialized — call initialize() first"

        async with self._db.execute(
            "SELECT * FROM proposals WHERE id = ?", (proposal_id,)
        ) as cursor:
            row = await cursor.fetchone()

        if row is None:
            return None

        return _row_to_proposal(row)

    async def update_proposal_status(self, proposal_id: int, status: str) -> None:
        """Update the status of an existing proposal."""
        assert self._db is not None, "Store not initialized — call initialize() first"

        await self._db.execute(
            "UPDATE proposals SET status = ? WHERE id = ?",
            (status, proposal_id),
        )
        await self._db.commit()


def _row_to_proposal(row: aiosqlite.Row) -> Proposal:
    """Convert a database row to a Proposal domain model."""
    created_at = datetime.fromisoformat(row["created_at"])
    if created_at.tzinfo is None:
        created_at = created_at.replace(tzinfo=timezone.utc)
    return Proposal(
        id=row["id"],
        agent_name=row["agent_name"],
        type=ProposalType(row["type"]),
        diff=row["diff"],
        status=row["status"],
        created_at=created_at,
    )
