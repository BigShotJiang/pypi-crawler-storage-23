"""Anthropic SDK direct adapter for fast-path responses.

Bypasses the Claude CLI subprocess for simple messages, providing
sub-3s latency for greetings and short queries. Uses the same
system prompt builder as the CLI adapter for consistency.
"""
from __future__ import annotations

import logging

import anthropic

from shikigami_bot.adapters.llm._prompt_builder import build_system_prompt
from shikigami_bot.domain.agent import AgentDefinition
from shikigami_bot.domain.llm import LLMResponse

logger = logging.getLogger(__name__)


class AnthropicDirectAdapter:
    """Anthropic SDK adapter for fast-path LLM calls.

    Implements LLMPort. Always returns session_id=None (no CLI session).
    """

    def __init__(self, api_key: str, model: str = "claude-haiku-4-5-20251001") -> None:
        self._client = anthropic.AsyncAnthropic(api_key=api_key)
        self._model = model

    async def invoke(
        self,
        agent: AgentDefinition,
        user_message: str,
        session_id: str | None = None,
        memory_context: str = "",
    ) -> LLMResponse:
        """Invoke the Anthropic API directly (no CLI subprocess).

        Returns LLMResponse with session_id=None (fast-path never creates
        CLI sessions).
        """
        system_prompt = build_system_prompt(agent, memory_context=memory_context)

        try:
            response = await self._client.messages.create(
                model=self._model,
                max_tokens=1024,
                system=system_prompt,
                messages=[{"role": "user", "content": user_message}],
            )
        except anthropic.APIError as exc:
            logger.warning("anthropic_direct.api_error: %s", exc)
            return LLMResponse(
                text="",
                model=self._model,
                is_error=True,
                error_message=str(exc),
            )

        text = ""
        for block in response.content:
            if block.type == "text":
                text += block.text

        return LLMResponse(
            text=text,
            model=response.model,
            session_id=None,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
        )
