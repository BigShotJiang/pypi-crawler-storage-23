"""Claude Code CLI subprocess adapter.

This is the critical security boundary between the bot and the Claude CLI.
All security invariants are enforced here:

- Explicit env allowlist (never os.environ passthrough)
- Structural prompt separation (--append-system-prompt vs -p)
- Tool restriction via --allowedTools
- Timeout with process group kill
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import signal
import sys
from typing import Final

from shikigami_bot.adapters.llm._prompt_builder import build_system_prompt
from shikigami_bot.adapters.llm.tool_names import friendly_progress
from shikigami_bot.domain.agent import AgentDefinition
from shikigami_bot.domain.llm import LLMResponse
from shikigami_bot.domain.progress import ProgressCallback, ProgressEvent

logger = logging.getLogger(__name__)

# Known error patterns from Claude CLI output (ported from GoBot).
_ERROR_PATTERNS: Final[list[str]] = [
    "authentication_error",
    "API Error: 400",
    "API Error: 401",
    "API Error: 403",
    "API Error: 429",
    "OAuth token has expired",
    "Failed to authenticate",
    "invalid_api_key",
    "invalidRequestError",
    "Could not process image",
    "overloaded_error",
    "rate_limit_error",
    "credit balance",
    "add funds",
    "billing",
    "insufficient_quota",
    "payment_required",
]

# Regex to strip markdown code fences that Claude sometimes wraps JSON in.
_FENCE_RE = re.compile(r"```(?:json)?\s*\n?(.*?)\n?\s*```", re.DOTALL)

# Grace period (seconds) between SIGTERM and SIGKILL on timeout.
_KILL_GRACE_SECONDS: Final[float] = 5.0


def _extract_tool_input_summary(tool_name: str, tool_input: dict) -> str:
    """Extract a short summary string from tool input for logging."""
    if tool_name == "Read":
        return tool_input.get("file_path", "")
    elif tool_name in ("Write", "Edit"):
        return tool_input.get("file_path", "")
    elif tool_name == "Bash":
        return tool_input.get("command", "")[:80]
    elif tool_name in ("Grep", "Glob"):
        return tool_input.get("pattern", "")
    elif tool_name == "WebSearch":
        return tool_input.get("query", "")
    elif tool_name == "WebFetch":
        return tool_input.get("url", "")
    return ""


class ClaudeCLIAdapter:
    """Claude Code CLI subprocess adapter.

    Implements LLMPort. This is the critical security boundary:
    - Explicit env allowlist (never os.environ passthrough)
    - Structural prompt separation (--append-system-prompt vs -p)
    - Tool restriction via --allowedTools
    - Timeout with process group kill
    """

    def __init__(
        self,
        claude_path: str = "claude",
        timeout_seconds: int = 300,
        anthropic_api_key: str | None = None,
    ) -> None:
        self._claude_path = claude_path
        self._timeout_seconds = timeout_seconds
        self._api_key = anthropic_api_key or ""

    # ------------------------------------------------------------------
    # Public interface (satisfies LLMPort protocol)
    # ------------------------------------------------------------------

    async def invoke(
        self,
        agent: AgentDefinition,
        user_message: str,
        session_id: str | None = None,
        memory_context: str = "",
    ) -> LLMResponse:
        """Invoke the Claude CLI as a subprocess.

        Returns an LLMResponse with the result text and session ID.
        On timeout, process error, or malformed output, returns is_error=True.
        """
        cmd = self._build_command(agent, user_message, session_id)
        env = self._build_env()

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
                start_new_session=True,  # own process group for killpg
            )
        except FileNotFoundError:
            return LLMResponse(
                text="",
                model="",
                is_error=True,
                error_message=f"Claude CLI not found at: {self._claude_path}",
            )

        try:
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(),
                timeout=self._timeout_seconds,
            )
        except asyncio.TimeoutError:
            await self._kill_process(proc)
            return LLMResponse(
                text="",
                model="",
                is_error=True,
                error_message=f"Timeout after {self._timeout_seconds}s",
            )

        stdout = stdout_bytes.decode("utf-8", errors="replace")
        stderr = stderr_bytes.decode("utf-8", errors="replace")

        # Non-zero exit code
        if proc.returncode != 0:
            logger.warning(
                "Claude CLI exited with code %d: %s",
                proc.returncode,
                stderr[:500],
            )
            return LLMResponse(
                text=stderr or stdout,
                model="",
                is_error=True,
                error_message=f"Process exited with code {proc.returncode}",
            )

        return self._parse_output(stdout)

    async def invoke_streaming(
        self,
        agent: AgentDefinition,
        user_message: str,
        session_id: str | None = None,
        memory_context: str = "",
        on_progress: ProgressCallback | None = None,
    ) -> LLMResponse:
        """Invoke Claude CLI with streaming JSONL output.

        Parses stream-json events line-by-line, dispatching progress
        callbacks for tool_use events. Falls back to invoke() on any
        parse failure.
        """
        cmd = self._build_command_streaming(agent, user_message, session_id)
        env = self._build_env()

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
                start_new_session=True,
            )
        except FileNotFoundError:
            return await self.invoke(agent, user_message, session_id, memory_context)

        try:
            result = await asyncio.wait_for(
                self._read_stream(proc, on_progress),
                timeout=self._timeout_seconds,
            )
            return result
        except asyncio.TimeoutError:
            await self._kill_process(proc)
            return LLMResponse(
                text="",
                model="",
                is_error=True,
                error_message=f"Timeout after {self._timeout_seconds}s",
            )
        except Exception:
            logger.exception("Streaming parse failure, falling back to invoke()")
            await self._kill_process(proc)
            return await self.invoke(agent, user_message, session_id, memory_context)

    # ------------------------------------------------------------------
    # Command construction
    # ------------------------------------------------------------------

    def _build_command(
        self,
        agent: AgentDefinition,
        user_message: str,
        session_id: str | None = None,
    ) -> list[str]:
        """Construct the CLI argument list.

        Structure:
          [caffeinate -i]  claude  -p <user_msg>
            --append-system-prompt <system>
            --output-format json
            [--allowedTools <tools>]
            [--resume <session_id>]
        """
        args: list[str] = [
            self._claude_path,
            "-p", user_message,
            "--append-system-prompt", self._build_system_prompt(agent),
            "--output-format", "json",
        ]

        # Model selection based on agent tier
        model_map = {
            "haiku": "claude-haiku-4-5-20251001",
            "sonnet": "claude-sonnet-4-6",
            "opus": "claude-opus-4-6",
        }
        if agent.model in model_map:
            args.extend(["--model", model_map[agent.model]])

        # Tool restriction
        if agent.allowed_tools:
            args.extend(["--allowedTools", ",".join(agent.allowed_tools)])

        # Session resume
        if session_id is not None:
            args.extend(["--resume", session_id])

        # macOS: wrap with caffeinate to prevent idle sleep
        if sys.platform == "darwin":
            args = ["/usr/bin/caffeinate", "-i"] + args

        return args

    def _build_command_streaming(
        self,
        agent: AgentDefinition,
        user_message: str,
        session_id: str | None = None,
    ) -> list[str]:
        """Like _build_command but with --output-format stream-json."""
        args: list[str] = [
            self._claude_path,
            "-p", user_message,
            "--append-system-prompt", self._build_system_prompt(agent),
            "--output-format", "stream-json",
        ]

        model_map = {
            "haiku": "claude-haiku-4-5-20251001",
            "sonnet": "claude-sonnet-4-6",
            "opus": "claude-opus-4-6",
        }
        if agent.model in model_map:
            args.extend(["--model", model_map[agent.model]])

        if agent.allowed_tools:
            args.extend(["--allowedTools", ",".join(agent.allowed_tools)])

        if session_id is not None:
            args.extend(["--resume", session_id])

        if sys.platform == "darwin":
            args = ["/usr/bin/caffeinate", "-i"] + args

        return args

    async def _read_stream(
        self,
        proc: asyncio.subprocess.Process,
        on_progress: ProgressCallback | None,
    ) -> LLMResponse:
        """Read JSONL stream line-by-line, dispatch progress, return result."""
        assert proc.stdout is not None
        result_data: dict | None = None

        async for raw_line in proc.stdout:
            line = raw_line.decode("utf-8", errors="replace").strip()
            if not line:
                continue

            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue

            event_type = data.get("type", "")

            if event_type == "assistant" and on_progress is not None:
                self._dispatch_tool_progress(data, on_progress)

            elif event_type == "result":
                result_data = data

        # Wait for process to finish
        await proc.wait()

        if result_data is None:
            return LLMResponse(
                text="",
                model="",
                is_error=True,
                error_message="No result event in stream",
            )

        return self._parse_result_event(result_data)

    def _dispatch_tool_progress(
        self,
        data: dict,
        on_progress: ProgressCallback,
    ) -> None:
        """Extract tool_use from assistant event and fire callback."""
        message = data.get("message", {})
        content = message.get("content", [])
        for block in content:
            if block.get("type") == "tool_use":
                tool_name = block.get("name", "unknown")
                tool_input = block.get("input", {})
                text = friendly_progress(tool_name, tool_input)
                summary = _extract_tool_input_summary(tool_name, tool_input)
                event = ProgressEvent(
                    tool_name=tool_name,
                    tool_input_summary=summary,
                    friendly_text=text,
                )
                # Fire-and-forget (don't block the stream reader)
                asyncio.create_task(on_progress(event))

    @staticmethod
    def _parse_result_event(data: dict) -> LLMResponse:
        """Parse a stream-json result event into LLMResponse."""
        result_text = data.get("result", "") or ""
        session_id = data.get("session_id")
        model = data.get("model", "")

        usage = data.get("usage", {})
        input_tokens = usage.get("input_tokens")
        output_tokens = usage.get("output_tokens")

        return LLMResponse(
            text=result_text,
            model=model,
            session_id=session_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
        )

    # ------------------------------------------------------------------
    # Environment construction — the security-critical allowlist
    # ------------------------------------------------------------------

    def _build_env(self) -> dict[str, str]:
        """Build an explicit env allowlist. NEVER pass os.environ through."""
        return {
            "PATH": os.environ.get("PATH", ""),
            "HOME": os.environ.get("HOME", ""),
            "ANTHROPIC_API_KEY": self._api_key,
        }

    # ------------------------------------------------------------------
    # System prompt construction
    # ------------------------------------------------------------------

    @staticmethod
    def _build_system_prompt(
        agent: AgentDefinition,
        memory_context: str = "",
    ) -> str:
        """Combine prompt.md system prompt + personality + memory context.

        Delegates to the shared prompt builder so all LLM adapters
        produce consistent system prompts.
        """
        return build_system_prompt(agent, memory_context=memory_context)

    # ------------------------------------------------------------------
    # Output parsing
    # ------------------------------------------------------------------

    def _parse_output(self, stdout: str) -> LLMResponse:
        """Parse --output-format json response.

        Handles:
        - Valid JSON with result + session_id
        - Markdown-fenced JSON
        - Malformed JSON (returns error)
        - Error patterns in result text
        """
        if not stdout.strip():
            return LLMResponse(
                text="",
                model="",
                is_error=True,
                error_message="Empty output from Claude CLI",
            )

        raw = stdout.strip()

        # Strip markdown code fences if present
        fence_match = _FENCE_RE.search(raw)
        if fence_match:
            raw = fence_match.group(1).strip()

        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            return LLMResponse(
                text=stdout,
                model="",
                is_error=True,
                error_message=f"Malformed JSON from Claude CLI: {exc}",
            )

        result_text = data.get("result", "") or ""
        session_id = data.get("session_id")
        model = data.get("model", "")

        # Token usage (if present)
        usage = data.get("usage", {})
        input_tokens = usage.get("input_tokens")
        output_tokens = usage.get("output_tokens")

        is_error = self._is_error_response(result_text)

        return LLMResponse(
            text=result_text,
            model=model,
            is_error=is_error,
            error_message=result_text if is_error else None,
            session_id=session_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
        )

    # ------------------------------------------------------------------
    # Error detection
    # ------------------------------------------------------------------

    def _is_error_response(self, text: str) -> bool:
        """Detect known error patterns in Claude output."""
        return any(pattern in text for pattern in _ERROR_PATTERNS)

    # ------------------------------------------------------------------
    # Process management
    # ------------------------------------------------------------------

    @staticmethod
    async def _kill_process(proc: asyncio.subprocess.Process) -> None:
        """Kill a process group: SIGTERM, wait grace period, then SIGKILL."""
        try:
            pgid = os.getpgid(proc.pid)
            os.killpg(pgid, signal.SIGTERM)
        except (ProcessLookupError, OSError):
            return

        # Wait for graceful shutdown
        try:
            await asyncio.wait_for(proc.wait(), timeout=_KILL_GRACE_SECONDS)
        except asyncio.TimeoutError:
            try:
                pgid = os.getpgid(proc.pid)
                os.killpg(pgid, signal.SIGKILL)
            except (ProcessLookupError, OSError):
                pass
