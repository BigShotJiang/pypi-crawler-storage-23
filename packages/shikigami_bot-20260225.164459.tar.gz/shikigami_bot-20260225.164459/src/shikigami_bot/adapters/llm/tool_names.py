"""Friendly tool name mapping for streaming progress messages."""
from __future__ import annotations

TOOL_FRIENDLY_NAMES: dict[str, str] = {
    "Read": "Reading",
    "Write": "Writing",
    "Edit": "Editing",
    "Bash": "Running",
    "Grep": "Searching code",
    "Glob": "Finding files",
    "WebSearch": "Searching the web",
    "WebFetch": "Fetching page",
    "NotebookEdit": "Editing notebook",
}


def friendly_progress(tool_name: str, tool_input: dict | None = None) -> str:
    """Build a friendly progress string like 'Reading `file.py`...'"""
    verb = TOOL_FRIENDLY_NAMES.get(tool_name, f"Using {tool_name}")
    target = _extract_target(tool_name, tool_input or {})
    if target:
        return f"{verb} `{target}`..."
    return f"{verb}..."


def _extract_target(tool_name: str, tool_input: dict) -> str:
    """Extract the most relevant target from tool input."""
    if tool_name == "Read":
        path = tool_input.get("file_path", "")
        if path:
            return path.rsplit("/", 1)[-1]
    elif tool_name == "Write":
        path = tool_input.get("file_path", "")
        if path:
            return path.rsplit("/", 1)[-1]
    elif tool_name == "Edit":
        path = tool_input.get("file_path", "")
        if path:
            return path.rsplit("/", 1)[-1]
    elif tool_name == "Bash":
        cmd = tool_input.get("command", "")
        if cmd:
            return cmd[:40]
    elif tool_name == "Grep":
        pattern = tool_input.get("pattern", "")
        if pattern:
            return pattern[:30]
    elif tool_name == "Glob":
        pattern = tool_input.get("pattern", "")
        if pattern:
            return pattern[:30]
    elif tool_name == "WebSearch":
        query = tool_input.get("query", "")
        if query:
            return query[:30]
    elif tool_name == "WebFetch":
        url = tool_input.get("url", "")
        if url:
            return url[:40]
    return ""
