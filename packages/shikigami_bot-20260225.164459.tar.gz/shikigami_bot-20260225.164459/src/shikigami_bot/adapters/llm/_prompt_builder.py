"""Shared system prompt builder for LLM adapters.

Extracted from ClaudeCLIAdapter so both the CLI adapter and the
Anthropic direct adapter can reuse the same prompt construction logic.
"""
from __future__ import annotations

from datetime import UTC, datetime

from shikigami_bot.domain.agent import AgentDefinition


def build_system_prompt(
    agent: AgentDefinition,
    memory_context: str = "",
) -> str:
    """Combine agent system prompt + personality + skills + time + memory.

    The 4-layer prompt hierarchy:
    1. Agent system prompt (from prompt.md)
    2. Personality / soul (from # Soul section)
    3. Skills manifest (Tier 1: names + descriptions)
    4. Current time (UTC)
    5. Memory context (read-only, clearly labeled)
    """
    parts: list[str] = []

    if agent.system_prompt:
        parts.append(agent.system_prompt)

    if agent.personality:
        parts.append(agent.personality)

    if agent.skills:
        skill_lines = []
        for skill in agent.skills:
            skill_lines.append(f"- **{skill.name}**: {skill.description}")
        parts.append("## Available Skills\n\n" + "\n".join(skill_lines))

    parts.append(
        "## CURRENT TIME\n"
        f"{datetime.now(tz=UTC).strftime('%A, %d %B %Y, %H:%M UTC')}"
    )

    if memory_context:
        parts.append(
            "\n---\n"
            "MEMORY (read-only context):\n"
            f"{memory_context}\n"
            "---"
        )

    return "\n\n".join(parts)
