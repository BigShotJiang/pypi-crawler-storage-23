"""TOTP two-factor authentication adapter.

Secrets are encrypted at rest with Fernet (AES-128-CBC + HMAC-SHA256).
Requires a stable TOTP_ENCRYPTION_KEY env var (Fernet key, base64-encoded).
"""
from __future__ import annotations

import io

import pyotp
import qrcode
from cryptography.fernet import Fernet, InvalidToken

from shikigami_bot.domain.memory import MemoryStore

_SECRET_KEY = "2fa_totp_secret"
_ISSUER = "Shikigami"


class TOTPAdapter:
    """TOTP-based 2FA using pyotp, encrypted secret storage via MemoryStore.

    Implements TwoFactorPort protocol.
    """

    def __init__(self, memory: MemoryStore, encryption_key: str) -> None:
        self._memory = memory
        self._fernet = Fernet(encryption_key.encode())

    def _encrypt(self, plaintext: str) -> str:
        return self._fernet.encrypt(plaintext.encode()).decode()

    def _decrypt(self, ciphertext: str) -> str:
        return self._fernet.decrypt(ciphertext.encode()).decode()

    async def is_enrolled(self, user_id: str) -> bool:
        secret = await self._memory.get(user_id, _SECRET_KEY)
        return secret is not None

    async def enroll(self, user_id: str) -> tuple[str, bytes, str]:
        """Enroll a user for TOTP 2FA.

        Returns (provisioning_uri, qr_png_bytes, raw_secret).
        Overwrites any existing enrollment.
        """
        secret = pyotp.random_base32()
        encrypted = self._encrypt(secret)
        await self._memory.set(user_id, _SECRET_KEY, encrypted)

        totp = pyotp.TOTP(secret)
        uri = totp.provisioning_uri(name=user_id, issuer_name=_ISSUER)

        img = qrcode.make(uri)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        qr_bytes = buf.getvalue()

        return uri, qr_bytes, secret

    async def verify(self, user_id: str, code: str) -> bool:
        """Verify a 6-digit TOTP code. Returns False if not enrolled or invalid."""
        encrypted = await self._memory.get(user_id, _SECRET_KEY)
        if encrypted is None:
            return False

        try:
            secret = self._decrypt(encrypted)
        except InvalidToken:
            return False

        totp = pyotp.TOTP(secret)
        return totp.verify(code, valid_window=1)
