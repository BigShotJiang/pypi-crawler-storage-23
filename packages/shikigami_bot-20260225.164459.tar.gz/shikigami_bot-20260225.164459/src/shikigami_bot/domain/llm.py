"""LLM response model — output of any LLM adapter."""
from __future__ import annotations

from pydantic import BaseModel


class LLMResponse(BaseModel):
    """Response from an LLM invocation."""

    text: str
    model: str
    is_error: bool = False
    error_message: str | None = None
    session_id: str | None = None  # Claude CLI session ID for --resume
    input_tokens: int | None = None
    output_tokens: int | None = None
