"""Memory storage protocol — placeholder for future postgres-backed implementation."""
from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class MemoryStore(Protocol):
    """Key-value memory per user. Will be replaced by richer postgres schema."""

    async def get(self, user_id: str, key: str) -> str | None: ...
    async def set(self, user_id: str, key: str, value: str) -> None: ...
    async def delete(self, user_id: str, key: str) -> None: ...
