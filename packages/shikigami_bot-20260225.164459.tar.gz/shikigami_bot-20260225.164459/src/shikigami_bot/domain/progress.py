"""Progress event model for streaming tool updates."""
from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass


@dataclass(frozen=True)
class ProgressEvent:
    """A tool-use progress update from a streaming LLM invocation."""

    tool_name: str
    tool_input_summary: str
    friendly_text: str


ProgressCallback = Callable[[ProgressEvent], Awaitable[None]]
