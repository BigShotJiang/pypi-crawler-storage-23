"""Session models for conversation tracking."""
from __future__ import annotations

from datetime import datetime, timezone

from pydantic import BaseModel, Field


def _utcnow() -> datetime:
    return datetime.now(tz=timezone.utc)


class Session(BaseModel):
    """A conversation session between a user and an agent."""

    session_id: str
    chat_id: str
    agent_name: str
    topic_summary: str
    claude_session_id: str | None = None  # Claude CLI --resume ID
    message_count: int = 0
    created_at: datetime = Field(default_factory=_utcnow)
    last_active: datetime = Field(default_factory=_utcnow)


class SessionSummary(BaseModel):
    """Lightweight session info for relay routing context."""

    session_id: str
    agent_name: str
    topic_summary: str
    message_count: int
    last_active: datetime
