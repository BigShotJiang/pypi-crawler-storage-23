"""Routing decision model — output of the relay router."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class RoutingDecision(BaseModel):
    """Structured output from the Haiku relay router."""

    session_action: Literal["new", "resume"]
    session_id: str | None = None  # Required when action is "resume"
    agent_name: str
    skill_name: str | None = None
    confidence: float = Field(ge=0.0, le=1.0)
    reasoning: str
    needs_confirmation: bool = False
