"""Transport-agnostic message model."""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class Message(BaseModel):
    """A message received from any transport."""

    transport: str  # e.g. "telegram"
    chat_id: str
    thread_id: Optional[str] = None  # Forum topic id, channel, etc.
    user_id: str
    username: Optional[str] = None
    text: str
    timestamp: datetime
    reply_to_message_id: Optional[str] = None
