"""Domain model for guardrails: risk tiers and action classification.

Risk tiers represent the level of consequence an action can have:
- Tier 0: read-only (web search, read files) — auto-allowed
- Tier 1: write local state (memory, goals) — auto-allowed
- Tier 2: external actions (send email, post) — requires user confirmation
- Tier 3: irreversible (delete, publish) — requires double confirmation
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


class RiskTier(IntEnum):
    """Risk tier for a bot action.

    Higher tier = more consequences = more confirmation required.
    """

    READ_ONLY = 0       # Safe reads: web search, file read
    LOCAL_WRITE = 1     # Memory, goals, local state
    EXTERNAL_ACTION = 2  # Send email, post, call API
    IRREVERSIBLE = 3    # Delete, publish, permanent changes


@dataclass(frozen=True)
class ActionClassification:
    """Classification of a single bot action.

    Args:
        action_name: The tag type or action identifier (e.g. "REMEMBER", "SEND_EMAIL")
        risk_tier: Risk level for this action
        description: Human-readable description shown to user in confirmation prompts
        requires_2fa: Whether this action requires TOTP verification on top of confirmation
    """

    action_name: str
    risk_tier: RiskTier
    description: str
    requires_2fa: bool = False
