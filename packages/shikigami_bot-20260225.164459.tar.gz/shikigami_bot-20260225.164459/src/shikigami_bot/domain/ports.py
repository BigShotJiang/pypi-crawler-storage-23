"""Port protocols — interfaces that adapters must implement.

All ports use typing.Protocol for structural subtyping. Domain code
depends on these protocols, never on concrete adapter implementations.
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable

from .agent import AgentDefinition
from .llm import LLMResponse
from .message import Message
from .proposal import Proposal
from .session import Session, SessionSummary


@runtime_checkable
class LLMPort(Protocol):
    """Any LLM backend (Claude CLI, OpenRouter, etc.) must implement this."""

    async def invoke(
        self,
        agent: AgentDefinition,
        user_message: str,
        session_id: str | None = None,
        memory_context: str = "",
    ) -> LLMResponse: ...


@runtime_checkable
class STTPort(Protocol):
    """Speech-to-text port. Converts audio bytes to a transcript string."""

    async def transcribe(self, audio: bytes, mime_type: str = "audio/ogg") -> str: ...


@runtime_checkable
class TTSPort(Protocol):
    """Text-to-speech port. Converts text to audio bytes."""

    async def synthesize(self, text: str) -> bytes: ...


@runtime_checkable
class TransportPort(Protocol):
    """Any transport (Telegram, Slack, etc.) must implement this."""

    async def send(
        self,
        chat_id: str,
        text: str,
        reply_to_message_id: str | None = None,
        thread_id: str | None = None,
    ) -> None: ...

    async def ask_user(
        self,
        chat_id: str,
        question: str,
        options: list[str],
        thread_id: str | None = None,
    ) -> str: ...

    async def ask_user_text(
        self,
        chat_id: str,
        question: str,
        thread_id: str | None = None,
    ) -> str:
        """Ask the user for free-text input (e.g. a TOTP code)."""
        ...

    async def send_typing(self, chat_id: str, thread_id: str | None = None) -> None: ...

    async def send_progress(
        self,
        chat_id: str,
        text: str,
        message_id: str | None = None,
        thread_id: str | None = None,
    ) -> str:
        """Send or update a progress indicator message. Returns the message ID."""
        ...

    async def delete_message(
        self,
        chat_id: str,
        message_id: str,
    ) -> None:
        """Delete a message. Swallows errors if the message is already gone."""
        ...

    async def send_voice(
        self,
        chat_id: str,
        audio: bytes,
        thread_id: str | None = None,
    ) -> None: ...


@runtime_checkable
class SessionStore(Protocol):
    """Session persistence (postgres, sqlite, etc.)."""

    async def create_session(
        self, chat_id: str, agent_name: str, topic_summary: str
    ) -> Session: ...

    async def get_session(self, session_id: str) -> Session | None: ...

    async def list_active_sessions(
        self, chat_id: str, agent_name: str | None = None
    ) -> list[SessionSummary]: ...

    async def update_session(
        self,
        session_id: str,
        claude_session_id: str | None = None,
        topic_summary: str | None = None,
        increment_messages: bool = False,
    ) -> None: ...


@runtime_checkable
class Guardrails(Protocol):
    """Auth and content checks. Fail closed: deny by default."""

    async def is_authorized(self, message: Message) -> bool: ...


@runtime_checkable
class TwoFactorPort(Protocol):
    """TOTP-based two-factor authentication for critical agent actions."""

    async def is_enrolled(self, user_id: str) -> bool: ...
    async def enroll(self, user_id: str) -> tuple[str, bytes, str]:
        """Enroll a user for 2FA. Returns (provisioning_uri, qr_png_bytes, raw_secret)."""
        ...
    async def verify(self, user_id: str, code: str) -> bool: ...


@runtime_checkable
class ProposalStore(Protocol):
    """Persistence for agent self-learning proposals."""

    async def create_proposal(
        self, agent_name: str, type: str, diff: str
    ) -> int: ...

    async def get_proposal(self, proposal_id: int) -> Proposal | None: ...

    async def update_proposal_status(
        self, proposal_id: int, status: str
    ) -> None: ...
