"""Proposal domain model for PROPOSE_SKILL self-learning loop.

Proposals represent human-in-the-loop change requests from the agent to its
own configuration. They are stored as pending until approved or rejected by
the operator.
"""
from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum

from pydantic import BaseModel


class ProposalType(str, Enum):
    """Type of agent configuration change being proposed."""

    skill = "skill"
    soul = "soul"  # Deprecated: kept for historical DB rows, no longer emitted


class Proposal(BaseModel):
    """A pending, approved, or rejected configuration change proposal.

    Attributes:
        id: Database ID; None until persisted.
        agent_name: Name of the agent that produced the proposal.
        type: Whether this is a skill or soul change.
        diff: The proposed change content (free-form text or diff).
        status: Current state — pending / approved / rejected.
        created_at: UTC timestamp of creation.
    """

    id: int | None
    agent_name: str
    type: ProposalType
    diff: str
    status: str = "pending"
    created_at: datetime

    model_config = {"frozen": False}
