"""Agent and skill definition models.

Agent definitions are immutable (frozen) — they represent human-approved
configuration that cannot be changed from within the running system.
"""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class SkillDefinition(BaseModel, frozen=True):
    """Parsed from agents/<name>/skills/<skill>.md YAML frontmatter."""

    name: str
    description: str
    version: str | None = None
    content: str = ""
    requires_env: list[str] = []
    requires_bins: list[str] = []


class AgentDefinition(BaseModel, frozen=True):
    """Parsed from agents/<name>/agent.yml + prompt.md.

    Immutable after creation — agents cannot modify their own definitions.
    """

    name: str
    description: str
    system_prompt: str = ""
    personality: str | None = None
    model: Literal["haiku", "sonnet", "opus"] = "sonnet"
    orchestrator: bool = False
    fast_path: bool = True
    allowed_tools: list[str] = []
    skills: list[SkillDefinition] = []
