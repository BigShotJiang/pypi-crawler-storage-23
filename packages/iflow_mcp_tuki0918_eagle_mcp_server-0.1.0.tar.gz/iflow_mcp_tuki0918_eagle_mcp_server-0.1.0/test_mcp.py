#!/usr/bin/env python3
import subprocess
import json
import time

# Start the MCP server
proc = subprocess.Popen(
    ['python3', 'main.py'],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    cwd='/app/auto-mcp-upload/data/9959'
)

# Initialize
init_request = '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}'
proc.stdin.write(init_request + '\n')
proc.stdin.flush()

# Read initialization response
response = proc.stdout.readline()
print("Init response:", response[:200])

# Get tools list
tools_request = '{"jsonrpc":"2.0","id":2,"method":"tools/list"}'
proc.stdin.write(tools_request + '\n')
proc.stdin.flush()

tools_response = proc.stdout.readline()
print("Tools response:", tools_response[:1000])

# Parse and count tools
try:
    tools_data = json.loads(tools_response)
    if 'result' in tools_data and 'tools' in tools_data['result']:
        tool_count = len(tools_data['result']['tools'])
        print(f"✅ MCP服务测试成功！发现 {tool_count} 个工具")
    else:
        print("❌ 工具列表格式错误")
except Exception as e:
    print(f"❌ 解析工具列表失败: {e}")

# Terminate
proc.terminate()
proc.wait(timeout=5)