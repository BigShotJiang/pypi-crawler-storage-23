"""Utility functions for terminal UI rendering.

Handles ANSI escape codes, text width calculations, and text wrapping.
"""

import re
import shutil
import unicodedata
from collections.abc import Callable

import wcwidth

# ANSI escape sequence patterns
# CSI sequences: ESC [ ... m (colors, styles)
CSI_PATTERN = re.compile(r"\x1b\[[0-9;]*[a-zA-Z]")
# APC sequences: ESC _ ... BEL (application program commands)
APC_PATTERN = re.compile(r"\x1b_[^\x07]*\x07")
# Combined pattern for stripping
ANSI_PATTERN = re.compile(r"\x1b(?:\[[0-9;]*[a-zA-Z]|_[^\x07]*\x07)")

# Grapheme segmenter cache
_segmenter: object | None = None


def get_segmenter() -> object:
    """Get the shared grapheme segmenter instance."""
    global _segmenter  # noqa: PLW0603
    if _segmenter is None:
        try:
            import unicodedatapkg  # type: ignore  # noqa: PLC0415

            _segmenter = unicodedatapkg.grapheme_cluster_break
        except ImportError:
            # Fallback to simple iteration
            _segmenter = None
    return _segmenter


def strip_ansi(text: str) -> str:
    """Remove ANSI escape sequences from text."""
    return ANSI_PATTERN.sub("", text)


def visible_width(text: str) -> int:
    """Calculate the visible width of a string in terminal columns.

    Ignores ANSI escape codes and handles wide characters (emojis, CJK, etc.)
    using wcwidth for accurate terminal column counting.
    """
    text = strip_ansi(text)
    width = 0
    for char in text:
        w = wcwidth.wcwidth(char)
        if w is None:
            # Control character or non-printable
            w = 0
        elif w < 0:
            # Combining character (overlaps previous)
            w = 0
        width += w
    return width


def extract_ansi_code(text: str, pos: int) -> tuple[str, int] | None:
    """Extract ANSI escape sequence from text at given position.

    Returns (code, length) or None if no code at position.
    """
    if pos >= len(text) or text[pos] != "\x1b":
        return None

    match = ANSI_PATTERN.match(text[pos:])
    if match:
        return (match.group(), match.end())
    return None


def _update_active_ansi(active_ansi: str, word: str) -> str:
    """Update active ANSI codes from a word."""
    pos = 0
    while pos < len(word):
        code_info = extract_ansi_code(word, pos)
        if code_info:
            code, length = code_info
            if code == "\x1b[0m":
                active_ansi = ""
            else:
                active_ansi += code
            pos += length
        else:
            pos += 1
    return active_ansi


def wrap_text_with_ansi(text: str, width: int) -> list[str]:
    """Wrap text preserving ANSI codes.

    Only does word wrapping - NO padding, NO background colors.
    Returns lines where each line is <= width visible chars.
    Active ANSI codes are preserved across line breaks.
    """
    if not text:
        return [""]

    lines: list[str] = []
    paragraphs = text.split("\n")

    for paragraph in paragraphs:
        if not paragraph:
            lines.append("")
            continue

        words = paragraph.split(" ")
        current_line = ""
        current_width = 0
        active_ansi = ""

        for word in words:
            word_width = visible_width(word)
            separator = 1 if current_line else 0

            if current_width + word_width + separator > width:
                # Line would exceed width, flush current line
                if current_line:
                    lines.append(current_line + "\x1b[0m")
                # Start new line with active ANSI codes
                current_line = active_ansi + word if active_ansi else word
                current_width = word_width
            else:
                # Add word to current line
                if current_line:
                    current_line += " "
                    current_width += 1
                current_line += word
                current_width += word_width

            # Update active ANSI codes from word
            active_ansi = _update_active_ansi(active_ansi, word)

        if current_line:
            lines.append(current_line + "\x1b[0m")
        elif not lines:
            lines.append("")

    return lines


def is_whitespace(char: str) -> bool:
    """Check if a character is whitespace."""
    return char in " \t\n\r\f\v"


def is_punctuation(char: str) -> bool:
    """Check if a character is punctuation."""
    cat = unicodedata.category(char)
    return cat.startswith("P")


def apply_background_to_line(
    line: str, width: int, bg_fn: Callable[[str], str]
) -> str:
    """Apply background color to a line, padding to full width.

    Args:
        line: Line of text (may contain ANSI codes)
        width: Total width to pad to
        bg_fn: Background color function

    Returns:
        Line with background applied and padded to width
    """
    text_width = visible_width(line)
    if text_width < width:
        padding = " " * (width - text_width)
        return bg_fn(line + padding)
    return bg_fn(line)


def truncate_to_width(
    text: str, max_width: int, ellipsis: str = "...", pad: bool = False
) -> str:
    """Truncate text to fit within a maximum visible width.

    Properly handles ANSI escape codes (they don't count toward width).

    Args:
        text: Text to truncate (may contain ANSI codes)
        max_width: Maximum visible width
        ellipsis: Ellipsis string when truncating (default: "...")
        pad: If True, pad result with spaces to exactly max_width

    Returns:
        Truncated text, optionally padded to exactly max_width
    """
    if max_width <= 0:
        return ""

    visible = visible_width(text)
    if visible <= max_width:
        if pad and visible < max_width:
            return text + " " * (max_width - visible)
        return text

    # Need to truncate
    ellipsis_width = 0 if not ellipsis else visible_width(ellipsis)

    target_width = max_width - ellipsis_width
    target_width = max(target_width, 0)

    result = []
    current_width = 0

    i = 0
    while i < len(text) and current_width < target_width:
        # Check for ANSI code
        code_info = extract_ansi_code(text, i)
        if code_info:
            code, length = code_info
            result.append(code)
            i += length
            continue

        char = text[i]
        char_width = 2 if visible_width(char) > 1 else 1

        if current_width + char_width > target_width:
            break

        result.append(char)
        current_width += char_width
        i += 1

    result.append(ellipsis)

    if pad:
        total_width = current_width + ellipsis_width
        if total_width < max_width:
            result.append(" " * (max_width - total_width))

    return "".join(result)


def slice_by_column(
    line: str, start_col: int, length: int, strict: bool = False
) -> str:
    """Extract a range of visible columns from a line.

    Handles ANSI codes and wide characters properly.

    Args:
        line: Input line
        start_col: Starting column (0-indexed)
        length: Number of columns to extract
        strict: If True, exclude wide chars at boundary that would
            extend past range

    Returns:
        Extracted text with ANSI codes preserved
    """
    if length <= 0:
        return ""

    result = []
    col = 0
    i = 0
    active_ansi = ""

    # Skip to start_col, tracking active ANSI codes
    while i < len(line) and col < start_col:
        code_info = extract_ansi_code(line, i)
        if code_info:
            code, code_len = code_info
            if code == "\x1b[0m":
                active_ansi = ""
            else:
                active_ansi += code
            i += code_len
            continue

        char = line[i]
        char_width = 2 if ord(char) > 127 and visible_width(char) > 1 else 1
        col += char_width
        i += 1

    # Add active ANSI codes at start position
    result.append(active_ansi)

    # Extract length columns
    extracted_width = 0
    while i < len(line) and extracted_width < length:
        code_info = extract_ansi_code(line, i)
        if code_info:
            code, code_len = code_info
            result.append(code)
            i += code_len
            continue

        char = line[i]
        char_width = 2 if ord(char) > 127 and visible_width(char) > 1 else 1

        if strict and extracted_width + char_width > length:
            break

        result.append(char)
        extracted_width += char_width
        i += 1

    return "".join(result)


def get_terminal_size() -> tuple[int, int]:
    """Get terminal size as (columns, rows)."""
    try:
        cols, rows = shutil.get_terminal_size()
    except Exception:
        return (80, 24)
    else:
        return (cols, rows)
