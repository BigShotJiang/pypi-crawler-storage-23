# PolyRead TTS — API environment definition.
# All environments are fully ElevenLabs-compatible (same paths, headers, response shapes).
#
# NOTE: Update PRODUCTION URL to https://api.polyread.ai once that domain is live.

import enum


class ElevenLabsEnvironment(enum.Enum):
    PRODUCTION = "https://polyread-ai-fe-stag-1060321088182.europe-west1.run.app/api"
    PRODUCTION_DOMAIN = "https://api.polyread.ai"
