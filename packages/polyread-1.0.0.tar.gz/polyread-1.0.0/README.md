# PolyRead TTS — Python SDK

ElevenLabs-compatible SDK for the [PolyRead TTS API](https://polyread.ai).
Switch from ElevenLabs by changing **one line of code**.

## Installation

```bash
pip install polyread
```

## Quick Start

```python
from elevenlabs import ElevenLabs

client = ElevenLabs(api_key="pr_live_...")

audio = client.text_to_speech.convert(
    voice_id="VOICE_ID",
    text="Hello from PolyRead!",
    model_id="polyread-tts-1",
    voice_settings={"stability": 0.5, "similarity_boost": 0.75},
)
```

## Switching from ElevenLabs

| Before (ElevenLabs) | After (PolyRead) |
|---|---|
| `from elevenlabs import ElevenLabs` | `from elevenlabs import ElevenLabs` — **unchanged** |
| `pip install elevenlabs` | `pip install polyread` |
| `ElevenLabs(api_key="el_...")` | `ElevenLabs(api_key="pr_live_...")` |
| `client.text_to_speech.convert(...)` | `client.text_to_speech.convert(...)` — **unchanged** |

All class names, method names, and parameter shapes are identical. Only the package and API key change.

## API Keys

Create an API key from your [PolyRead Developer Dashboard](https://app.polyread.ai/developer).
Keys start with `pr_live_`.

## Supported Models

| model_id | Description |
|---|---|
| `polyread-tts-1` | Standard quality, lowest latency (default) |
| `polyread-tts-1-hd` | Higher quality, slightly higher latency |
| `polyread-multilingual-v1` | 20+ language support |

## Base URL

All requests go to the PolyRead API automatically.
You can override it:

```python
client = ElevenLabs(
    api_key="pr_live_...",
    base_url="https://your-custom-endpoint.com/api",
)
```

## License

MIT
