__version__ = "1.2.3"
__author__ = "N. K. Franklin-Gent"
__license__ = "MIT"
