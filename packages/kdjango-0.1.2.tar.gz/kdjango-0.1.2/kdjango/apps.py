from django.apps import AppConfig

class KDjangoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kdjango'
    verbose_name = 'KDjango Apple Admin'
