try:
    from ._version import version as __version__
except ImportError:
    import importlib.metadata
    import contextlib
    with contextlib.suppress(Exception):
        __version__ = importlib.metadata.version("kdjango")
