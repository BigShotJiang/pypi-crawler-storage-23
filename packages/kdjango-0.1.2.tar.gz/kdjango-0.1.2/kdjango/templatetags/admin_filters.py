from django import template
from django.contrib import admin

register = template.Library()

@register.filter
def to_object_display_value(value):
    """
    Formatta il valore di un oggetto per la visualizzazione nella dashboard.
    """
    return value

@register.simple_tag
def get_model_icon(app_label, model_name):
    """
    Recupera l'icona definita nel ModelAdmin per un dato modello.
    """
    try:
        # Cerchiamo nel registro dell'admin site di default
        for model_class, model_admin in admin.site._registry.items():
            if model_class._meta.app_label == app_label and model_class._meta.model_name == model_name.lower():
                return getattr(model_admin, 'icon', None)
    except Exception:
        pass
    return None
