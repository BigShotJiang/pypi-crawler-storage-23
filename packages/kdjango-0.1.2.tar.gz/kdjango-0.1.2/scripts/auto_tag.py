import os
import re
import subprocess

def get_latest_v_tag():
    try:
        # Ottiene tutti i tag che iniziano con 'v' ordinati per data (più recente prima)
        output = subprocess.check_output(
            ["git", "tag", "-l", "v*", "--sort=-v:refname"], 
            text=True
        ).strip()
        
        tags = output.split('\n') if output else []
        if not tags or not tags[0]:
            return "v0.1.0"
        
        return tags[0]
    except Exception as e:
        print(f"Errore nel recupero tag: {e}")
        return "v0.1.0"

def get_next_version(current_tag):
    # Estrae i numeri da vX.Y.Z
    match = re.match(r'v(\d+)\.(\d+)\.(\d+)', current_tag)
    if not match:
        return "v0.1.1" # Fallback sicuro
    
    major, minor, patch = map(int, match.groups())
    # Incrementiamo la patch per default
    return f"v{major}.{minor}.{patch + 1}"

def create_gitlab_tag(new_tag):
    project_id = os.getenv('CI_PROJECT_ID')
    gitlab_token = os.getenv('GITLAB_TOKEN')
    gitlab_url = os.getenv('CI_SERVER_URL')
    commit_sha = os.getenv('CI_COMMIT_SHA')

    if not gitlab_token:
        print("Errore: GITLAB_TOKEN non configurato.")
        return False

    import requests

    api_url = f"{gitlab_url}/api/v4/projects/{project_id}/repository/tags"
    payload = {
        'tag_name': new_tag,
        'ref': commit_sha,
        'message': f"Automatic release {new_tag}"
    }
    headers = {'PRIVATE-TOKEN': gitlab_token}

    print(f"Creazione tag {new_tag} per il commit {commit_sha}...")
    response = requests.post(api_url, json=payload, headers=headers)

    if response.status_code == 201:
        print(f"Tag {new_tag} creato con successo!")
        return True
    else:
        print(f"Fallito: {response.status_code} - {response.text}")
        return False

if __name__ == "__main__":
    latest = get_latest_v_tag()
    tag = get_next_version(latest)
    
    if os.getenv('CI'):
        create_gitlab_tag(tag)
    else:
        print(f"Ultimo tag rilevato: {latest}")
        print(f"Prossima versione calcolata: {tag}")
