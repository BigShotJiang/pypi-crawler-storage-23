#!/bin/bash

# Script di sviluppo per KDjango
# Avvia l'app di test utilizzando la libreria locale in modalità editable

# Colori per output
BLUE='\033[0;34m'
GREEN='\033[0;32m'
NC='\033[0m'

# Percorso della root del progetto
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_TEST_DIR="$PROJECT_ROOT/app_test"

echo -e "${BLUE}== Nome Progetto: KDjango 🍎 ==${NC}"
echo -e "${BLUE}== Modalità Sviluppo Attiva ==${NC}"

# 1. Entra nella cartella di test
cd "$APP_TEST_DIR" || exit

# 2. Verifica se il venv esiste
if [ ! -d "venv" ]; then
    echo -e "${BLUE}Creazione virtual environment...${NC}"
    python3 -m venv venv
fi

# 3. Attiva il venv
source venv/bin/activate

# 4. Assicura che la libreria locale e le dipendenze siano installate
echo -e "${BLUE}Verifica dipendenze e installazione editable di kdjango...${NC}"
pip install -r requirements.txt > /dev/null
# pip install -e "$PROJECT_ROOT" > /dev/null  # Gia incluso tramite -e .. nel requirements.txt

# 5. Esegue migrazioni (opzionale ma utile)
echo -e "${BLUE}Controllo migrazioni...${NC}"
python manage.py migrate --noinput

# 6. Avvia il server
# Django autoreloader rileva i cambiamenti ai file Python.
# I template vengono ricaricati ad ogni richiesta grazie a DEBUG=True.
echo -e "${GREEN}Avvio server Django su http://127.0.0.1:8000 ...${NC}"
python manage.py runserver 0.0.0.0:8000
