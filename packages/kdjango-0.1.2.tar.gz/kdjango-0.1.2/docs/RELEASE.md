# Guida al Rilascio di KDjango 🍎

KDjango utilizza un sistema di versionamento automatico basato sui **Tag Git**. Non è necessario modificare manualmente la versione nei file `pyproject.toml` o `__init__.py`.

## Procedura di Rilascio

Il progetto è configurato per il **rilascio automatico**.

### 1. Rilascio Automatico (Consigliato)
Basta pushare i tuoi cambiamenti sul branch `main`:
```bash
git add .
git commit -m "Descrizione cambiamenti"
git push origin main
```
La pipeline:
1. Calcolerà la prossima versione patch (es. v0.2.1 -> v0.2.2).
2. Creerà automaticamente un Tag Git sul repository.
3. Il Tag innescherà una nuova pipeline che costruirà il pacchetto e lo invierà a PyPI.

### 2. Rilascio Manuale (Opzionale)
Se vuoi forzare una versione specifica (es. un salto di release Major o Minor):
```bash
git tag -a v1.0.0 -m "Release 1.0.0"
git push origin v1.0.0
```
La pipeline riconoscerà il tag manuale e procederà con l'invio su PyPI saltando l'auto-tagging.

---

## Configurazione Necessaria su GitLab

Affinché l'automazione funzioni, devono essere configurate due variabili in **Settings > CI/CD > Variables**:

1. `PYPI_TOKEN`: Il token API di PyPI (inizia con `pypi-`).
2. `GITLAB_TOKEN`: Un **Project Access Token** con permessi `write_repository` e `api`.

### Creazione del GITLAB_TOKEN:
1. In GitLab, vai su **Settings > Access Tokens**.
2. Clicca su **Add new token**.
3. Nome: `CI_VERSION_BOT` (o simile).
4. Scopes: `api`, `write_repository`.
5. Role: `Maintainer`.
6. Copia il token generato e aggiungilo alle variabili CI/CD con il nome `GITLAB_TOKEN`.

---

## Logica di Versionamento

Il progetto utilizza `setuptools_scm`:

- **Versione Ufficiale**: Se il commit corrente ha un tag (es. `v0.1.1`), la versione sarà esattamente `0.1.1`.
- **Versione di Sviluppo**: Se ci sono commit dopo l'ultimo tag, la versione sarà generata automaticamente (es. `0.1.1.post1.dev5`), indicando che si tratta di una build successiva alla v0.1.1.
- **Fallback**: Se non viene trovato alcun tag, la versione di base è `0.1.0`.

## Controllare la Versione Localmente

Puoi verificare quale versione è attualmente rilevata dal sistema eseguendo:

```bash
# In Python
python -c "import kdjango; print(kdjango.__version__)"

# Oppure tramite pip se installato
pip show kdjango
```
