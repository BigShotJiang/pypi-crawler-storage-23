from django.contrib import admin
from .models import Prodotto

@admin.register(Prodotto)
class ProdottoAdmin(admin.ModelAdmin):
    icon = 'pi-plus'
    list_display = ('nome', 'prezzo', 'disponibile')
    list_filter = ('disponibile',)
    search_fields = ('nome', 'descrizione')
    ordering = ('nome',)

