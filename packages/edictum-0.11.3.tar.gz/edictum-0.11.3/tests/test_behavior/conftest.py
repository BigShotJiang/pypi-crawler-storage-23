"""Shared fixtures for behavior tests."""

from __future__ import annotations

from tests.conftest import *  # noqa: F401, F403
