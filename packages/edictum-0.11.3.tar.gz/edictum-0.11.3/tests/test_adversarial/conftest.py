"""Shared adversarial test fixtures."""

from __future__ import annotations
