"""Gnosis MCP -- Zero-config MCP server for searchable documentation."""

__version__ = "0.8.4"

__all__ = ["__version__"]
