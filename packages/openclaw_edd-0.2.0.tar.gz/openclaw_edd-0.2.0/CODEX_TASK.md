# CODEX_TASK

- ✅ 删除 streaming indexer 相关代码，run/eval 路径改为直接读 session 文件。
