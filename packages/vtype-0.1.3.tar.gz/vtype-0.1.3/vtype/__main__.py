#!/usr/bin/env python3
"""
vtype — offline voice input for any focused window.

Press Ctrl+Alt+V to start/stop listening.
Speak. Silence auto-triggers transcription.
Transcribed text is typed into whatever window is currently focused.

Usage:
    vtype
"""

import platform
import subprocess
import threading

import numpy as np
import sounddevice as sd
from faster_whisper import WhisperModel
from pynput import keyboard
from pynput.keyboard import Controller as KbController

SAMPLE_RATE  = 16000
CHUNK_SIZE   = int(SAMPLE_RATE * 0.1)   # 100ms chunks

SPEECH_RMS   = 0.015
SILENCE_RMS  = 0.010
SILENCE_SECS = 1.2
MIN_SPEECH   = 0.4    # seconds

IDLE         = 'idle'
LISTENING    = 'listening'
SPEAKING     = 'speaking'
TRANSCRIBING = 'transcribing'


def _notify(title, message=''):
    """Show a brief OS notification (best-effort)."""
    try:
        system = platform.system()
        if system == 'Darwin':
            subprocess.run(
                ['osascript', '-e',
                 f'display notification "{message}" with title "{title}"'],
                timeout=2, capture_output=True
            )
        elif system == 'Windows':
            script = (
                '[Windows.UI.Notifications.ToastNotificationManager,'
                ' Windows.UI.Notifications, ContentType=WindowsRuntime] | Out-Null;'
                '$t = [Windows.UI.Notifications.ToastNotificationManager]::'
                'GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02);'
                f'$t.SelectSingleNode("//text[@id=1]").InnerText = "{title}";'
                f'$t.SelectSingleNode("//text[@id=2]").InnerText = "{message}";'
                '$n = [Windows.UI.Notifications.ToastNotificationManager]::'
                'CreateToastNotifier("vtype");'
                '$n.Show([Windows.UI.Notifications.ToastNotification]::new($t));'
            )
            subprocess.run(['powershell', '-Command', script],
                           timeout=3, capture_output=True)
        elif system == 'Linux':
            subprocess.run(['notify-send', title, message],
                           timeout=2, capture_output=True)
    except Exception:
        pass


class VType:
    def __init__(self, model_size='base'):
        self.model_size = model_size
        self.state      = IDLE
        self.speech_buf = []
        self.silence_cnt = 0
        self.lock       = threading.Lock()
        self.kb         = KbController()
        self.model      = None
        self.stream     = None

    # ── Audio callback ────────────────────────────────────────────────────────
    def _audio_cb(self, indata, frames, t, status):
        if self.state not in (LISTENING, SPEAKING):
            return

        rms = float(np.sqrt(np.mean(indata ** 2)))

        with self.lock:
            if self.state == LISTENING:
                if rms > SPEECH_RMS:
                    self.state = SPEAKING
                    self.speech_buf = [indata.copy()]
                    self.silence_cnt = 0

            elif self.state == SPEAKING:
                self.speech_buf.append(indata.copy())
                if rms < SILENCE_RMS:
                    self.silence_cnt += 1
                    if self.silence_cnt * 0.1 >= SILENCE_SECS:
                        buf = list(self.speech_buf)
                        self.speech_buf = []
                        self.silence_cnt = 0
                        self.state = TRANSCRIBING
                        threading.Thread(
                            target=self._process, args=(buf,), daemon=True
                        ).start()
                else:
                    self.silence_cnt = 0

    # ── Transcribe + type ─────────────────────────────────────────────────────
    def _process(self, chunks):
        audio = np.concatenate(chunks).flatten()
        if len(audio) / SAMPLE_RATE < MIN_SPEECH:
            with self.lock:
                self.state = LISTENING
            return

        segments, _ = self.model.transcribe(audio, language='en', beam_size=5)
        segments = list(segments)
        text = ''.join(s.text for s in segments).strip()

        no_speech = max((s.no_speech_prob for s in segments), default=1.0)
        if text and no_speech <= 0.6:
            self.kb.type(text)

        with self.lock:
            self.state = LISTENING

    # ── Hotkey toggle ─────────────────────────────────────────────────────────
    def _toggle(self):
        with self.lock:
            if self.state == IDLE:
                self.state = LISTENING
                self.speech_buf = []
                self.silence_cnt = 0
                _notify("vtype", "Listening...")
                print("[vtype] Listening...", flush=True)
            elif self.state == TRANSCRIBING:
                pass  # busy — ignore
            else:
                self.state = IDLE
                self.speech_buf = []
                self.silence_cnt = 0
                _notify("vtype", "Stopped")
                print("[vtype] Stopped.", flush=True)

    # ── Main loop ─────────────────────────────────────────────────────────────
    def run(self):
        print(f"vtype — loading speech model ({self.model_size})...", flush=True)
        self.model = WhisperModel(self.model_size, device="cpu", compute_type="int8")
        print("Ready. Press Ctrl+Alt+V to start/stop voice input.", flush=True)
        _notify("vtype", "Ready — press Ctrl+Alt+V to speak")

        self.stream = sd.InputStream(
            samplerate=SAMPLE_RATE, channels=1, dtype='float32',
            blocksize=CHUNK_SIZE, callback=self._audio_cb
        )
        self.stream.start()

        stop_event = threading.Event()
        print("Press Ctrl+C to quit.", flush=True)
        with keyboard.GlobalHotKeys({'<ctrl>+<alt>+v': self._toggle}):
            try:
                while not stop_event.is_set():
                    stop_event.wait(timeout=0.5)
            except KeyboardInterrupt:
                pass

        self.stream.stop()
        print("vtype stopped.", flush=True)


def main():
    VType().run()


if __name__ == '__main__':
    main()
