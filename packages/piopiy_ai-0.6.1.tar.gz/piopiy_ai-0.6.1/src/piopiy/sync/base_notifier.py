#
# Copyright (c) 2024-2026, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

"""Base notifier interface for Pipecat."""

import warnings

from piopiy.utils.sync.base_notifier import BaseNotifier

with warnings.catch_warnings():
    warnings.simplefilter("always")
    warnings.warn(
        "Package piopiy.sync is deprecated, use piopiy.utils.sync instead.",
        DeprecationWarning,
        stacklevel=2,
    )
