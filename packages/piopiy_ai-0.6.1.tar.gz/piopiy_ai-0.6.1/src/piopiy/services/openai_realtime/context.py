#
# Copyright (c) 2024-2026, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

"""OpenAI Realtime LLM context and aggregator implementations.

.. deprecated:: 0.0.91
    OpenAI Realtime no longer uses types from this module under the hood.
    It now uses `LLMContext` and `LLMContextAggregatorPair`.
    Using the new patterns should allow you to not need types from this module.

    See deprecation warning in piopiy.services.openai.realtime.context for
    more details.
"""

from piopiy.services.openai.realtime.context import *
