#
# Copyright (c) 2024-2026, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

"""Daily transport implementation for Pipecat.

This module provides comprehensive Daily video conferencing integration including
audio/video streaming, transcription, recording, dial-in/out functionality, and
real-time communication features.
"""

import warnings

from piopiy.transports.daily.transport import *

with warnings.catch_warnings():
    warnings.simplefilter("always")
    warnings.warn(
        "Module `piopiy.transports.services.daily` is deprecated, "
        "use `piopiy.transports.daily.transport` instead.",
        DeprecationWarning,
        stacklevel=2,
    )
