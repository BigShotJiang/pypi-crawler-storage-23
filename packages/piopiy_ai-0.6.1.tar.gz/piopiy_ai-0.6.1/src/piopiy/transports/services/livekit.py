#
# Copyright (c) 2024-2026, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

"""LiveKit transport implementation for Pipecat.

This module provides comprehensive LiveKit real-time communication integration
including audio streaming, data messaging, participant management, and room
event handling for conversational AI applications.
"""

import warnings

from piopiy.transports.livekit.transport import *

with warnings.catch_warnings():
    warnings.simplefilter("always")
    warnings.warn(
        "Module `piopiy.transports.services.livekit` is deprecated, "
        "use `piopiy.transports.livekit.transport` instead.",
        DeprecationWarning,
        stacklevel=2,
    )
