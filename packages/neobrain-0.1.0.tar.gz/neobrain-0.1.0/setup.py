from setuptools import setup, find_packages

setup(
    name="neobrain",   # pip me lowercase best hota hai
    version="0.1.0",
    author="Tejas Misal",
    author_email="tejasmisal32@gmail.com",
    description="Speech to text automation package",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "selenium",
        "webdriver-manager"
    ],
    python_requires=">=3.8",
)