0.0.6 (2022-10-21)
==================

- NoAuth, Basic Authentication
- DjangoAuth (getting user info using Django SessionID)

0.0.1 (2022-10-20)
==================

- First public release
