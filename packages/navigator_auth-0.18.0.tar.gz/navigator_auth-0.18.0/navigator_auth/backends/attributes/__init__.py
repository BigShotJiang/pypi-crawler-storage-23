from .abstract import UserAttribute
from .internal import DomainAttribute

__all__ = ['UserAttribute', 'DomainAttribute']
