"""FDA decision document fetching and text extraction."""
