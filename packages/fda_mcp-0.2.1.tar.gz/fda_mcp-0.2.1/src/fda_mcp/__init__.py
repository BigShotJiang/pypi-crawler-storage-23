"""FDA MCP — MCP server for FDA data via the OpenFDA API."""
