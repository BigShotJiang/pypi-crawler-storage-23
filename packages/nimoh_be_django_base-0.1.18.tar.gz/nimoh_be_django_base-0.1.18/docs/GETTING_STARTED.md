# Getting Started with nimoh-be-django-base

This guide walks you through creating a new Django backend project from scratch using the `nimoh-be-django-base` package.

---

## Prerequisites

| Requirement | Version | Notes |
|---|---|---|
| Python | 3.11+ | |
| PostgreSQL | 14+ | Running locally or via Docker |
| Redis | 6+ | Running locally or via Docker |
| pip | latest | `pip install --upgrade pip` |

Start Postgres and Redis before proceeding:

```bash
# macOS (Homebrew)
brew services start postgresql
brew services start redis

# or via Docker
docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=root postgres:16
docker run -d -p 6379:6379 redis:7
```

---

## Quick start (automated)

If you have the `nimoh-be-django-base` repository cloned locally, you can
bootstrap an entire new project with **one command** from the repo root:

```bash
cd /path/to/nimoh-be-django-base
make new-app
# or, skip the name prompt:
make new-app NAME=my_api
```

This will:
1. Create a workspace directory (`./my_api/`)
2. Create a `.venv` inside it and install `nimoh-be-django-base[all]`
3. Run `nimoh-base init` interactively so you fill in project config
4. Install the generated project's `requirements.txt`
5. Copy `.env.example` → `.env`
6. Run `migrate`
7. Print the next steps (createsuperuser, start)

Once done, `cd` into the project directory and use the generated `Makefile`
(see [Project Makefile commands](#project-makefile-commands) below).

---

## Manual setup (step by step)

Follow these steps if you prefer to control each stage yourself.

---

## Step 1 — Install the CLI

Create a temporary virtual environment just for scaffolding (or install globally):

```bash
pip install "nimoh-be-django-base[all]"
```

Verify the CLI is available:

```bash
nimoh-base --version
# nimoh-base, version 0.1.x
```

---

## Step 2 — Create a workspace directory

```bash
mkdir my-app && cd my-app
```

---

## Step 3 — Create your `init.yml` configuration file

Create `init.yml` in your workspace directory. All fields shown below are supported:

```yaml
# init.yml — project configuration for nimoh-base init

project_name: "My App"          # Human-readable name (spaces OK)
project_slug: my_app            # Python identifier — used as the Django app label
                                # Auto-derived from project_name if omitted
description: "My Django backend"
author: "Your Name"
author_email: "you@example.com"

# Database (PostgreSQL)
db_engine: postgresql
db_name: my_app
db_user: your_pg_user
db_password: your_pg_password
db_host: localhost
db_port: 5432

# Redis
redis_url: "redis://localhost:6379/0"

# Frontend (used for CORS)
frontend_url: "http://localhost:3000"

# Optional feature flags
use_celery: true        # Async task queue
use_channels: true      # WebSocket / Django Channels
use_monitoring: true    # Request/error monitoring app
use_privacy: true       # GDPR / privacy consent app
use_sendgrid: false     # SendGrid email backend
```

> **Tip:** `project_slug` must be a valid Python identifier (letters, digits, underscores — no spaces or hyphens). If you omit it, it will be auto-derived from `project_name` (e.g. `"My App"` → `my_app`).

---

## Step 4 — Scaffold the project

```bash
nimoh-base init --config init.yml --no-input -o .
```

This generates a `<project_slug>/` directory (e.g. `my_app/`) inside your workspace:

```
my-app/
├── init.yml
└── my_app/               ← generated project
    ├── manage.py
    ├── requirements.txt
    ├── requirements-dev.txt
    ├── .env.example
    ├── Dockerfile
    ├── docker-compose.yml
    ├── Makefile
    ├── my_app/            ← Django app (models, views, urls)
    │   ├── apps.py
    │   └── models.py
    └── config/
        ├── settings/
        │   ├── base.py
        │   ├── development.py
        │   └── production.py
        ├── urls.py
        ├── celery.py
        └── wsgi.py
```

Alternatively, run without `--no-input` to be prompted for each value interactively:

```bash
nimoh-base init
```

---

## Step 5 — Set up the project virtual environment

```bash
cd my_app
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 6 — Configure environment variables

```bash
cp .env.example .env
```

Open `.env` and fill in any secrets. Key variables:

```dotenv
SECRET_KEY=<generate with: python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())">
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1

DATABASE_URL=postgresql://your_pg_user:your_pg_password@localhost:5432/my_app
REDIS_URL=redis://localhost:6379/0
CELERY_BROKER_URL=redis://localhost:6379/1
CELERY_RESULT_BACKEND=redis://localhost:6379/2

FRONTEND_URL=http://localhost:3000
```

---

## Step 7 — Create the database

```bash
createdb my_app
# Grant your user access (only needed if your pg user isn't a superuser)
psql my_app -c "GRANT ALL ON SCHEMA public TO your_pg_user;"
```

---

## Step 8 — Run migrations

```bash
python manage.py migrate
```

Expected output ends with all migrations showing `OK`.

---

## Step 9 — Create a superuser

```bash
python manage.py createsuperuser
```

---

## Step 10 — Start supporting services

The health check at `/api/v1/health/` reports three components: **database**,
**cache** (Redis), and **celery**. The Django dev server (`runserver`) only
covers the database. Redis and Celery must be started separately.

Choose whichever approach fits your setup:

### Option A — Docker (recommended, no local installs needed)

```bash
# Start just Redis + Celery worker (keeps Django local for fast iteration)
docker compose up -d redis celery_worker

# Or with the generated Makefile:
make start    # starts docker services then dev server in one command
```

Verify both are running:

```bash
docker compose ps
# redis          running
# celery_worker  running
```

> **Tip:** Stop background services with `make stop-docker` or
> `docker compose stop redis celery_worker`.

### Option B — Local processes

Open **two extra terminals** in the project directory with the venv activated:

**Terminal 2 — Celery worker:**
```bash
celery -A config worker --loglevel=info
```

**Terminal 3 — Celery beat scheduler** (only needed for periodic tasks):
```bash
celery -A config beat --loglevel=info --scheduler django_celery_beat.schedulers:DatabaseScheduler
```

Redis must already be running locally (`brew services start redis` on macOS, or
`docker run -d -p 6379:6379 redis:7`).

### Option C — Full Docker Compose stack

Run everything (Django, Postgres, Redis, Celery) together:

```bash
docker compose up --build
# or:
make start-docker
```

This is the closest approximation to production and is useful for integration
testing, but means your Django code changes are only picked up after a rebuild.

---

## Step 11 — Run the development server

```bash
# Manual:
python manage.py runserver

# Or with make (starts Redis + Celery via Docker first, then the server):
make start
```

> Start the supporting services (Step 10) **before** running the server so the
> health check is fully green on first request.

---

## Step 12 — Verify the app is working

With the server running, hit these endpoints:

| Endpoint | Expected |
|---|---|
| `GET /api/v1/health/` | `status: healthy` for database, cache **and** celery |
| `GET /api/v1/schema/docs/` | Swagger UI page (HTTP 200) |
| `GET /api/v1/schema/redoc/` | ReDoc page (HTTP 200) |
| `GET /admin/` | Django admin login page |

Expected health response when all services are up:

```json
{
  "status": "healthy",
  "checks": {
    "database": { "status": "healthy", "details": "Postgresql connection successful" },
    "cache":    { "status": "healthy" },
    "celery":   { "status": "healthy", "workers": 1 }
  }
}
```

If **cache** shows `unhealthy` → Redis is not reachable. Check `REDIS_URL` in
`.env` and confirm Redis is running (`docker compose ps redis` or
`redis-cli ping`).

If **celery** shows `unhealthy` → the Celery worker is not running or cannot
connect to the broker. Check `CELERY_BROKER_URL` in `.env` and start the worker
(see Step 10).

---

## Project Makefile commands

Every generated project includes a `Makefile` with these targets:

```bash
make help           # list all available commands

# Development
make run            # python manage.py runserver (Redis + Celery must already be running)
make start          # docker compose up -d redis celery_worker, then runserver
make start-docker   # full stack in Docker (Django + Postgres + Redis + Celery)
make stop-docker    # docker compose down

# Database
make migrate        # apply all migrations
make migrations     # generate new migrations
make createsuperuser

# Code quality
make lint
make format
make test

# Package
make upgrade        # pip install --upgrade nimoh-be-django-base[all]
                    #   (uses the workspace .venv one level up if present)
```

### Upgrading the base package

```bash
# From inside your project directory:
make upgrade
# then run migrations in case new migrations were added:
make migrate
```

---

## Using Docker Compose (full stack)

The generated project includes a `docker-compose.yml`. To run everything with Docker:

```bash
docker compose up --build
# or:
make start-docker
```

This starts the Django app, PostgreSQL, Redis, and Celery worker together.

---

## Key integration points

### Adding your own models

Edit `my_app/models.py` — it already imports the base `Profile` and `User` models from `nimoh-base`:

```python
from nimoh_be_django_base.apps.authentication.models import User
# Add your custom fields here
```

After adding models:

```bash
python manage.py makemigrations
python manage.py migrate
```

### Adding new Django apps

```bash
python manage.py startapp orders
```

Register it in `config/settings/base.py` under `INSTALLED_APPS`.

### Environment-specific settings

- Development: `config/settings/development.py` — `DEBUG=True`, verbose logging
- Production: `config/settings/production.py` — security headers, HTTPS, S3 storage

Set `DJANGO_SETTINGS_MODULE` to switch:

```bash
export DJANGO_SETTINGS_MODULE=config.settings.production
```

---

## Troubleshooting

### `ValueError: Empty module name` on migrate

Your `INSTALLED_APPS` has an empty string. This means `project_slug` was empty during scaffolding. Fix: ensure `project_slug` is set in `init.yml` and re-scaffold, or manually replace `''` with `'your_slug'` in `config/settings/base.py`.

### `django.db.utils.OperationalError: could not connect to server`

PostgreSQL is not running, or `DATABASE_URL` in `.env` has wrong credentials. Check `pg_isready` and your `.env` values.

### `redis.exceptions.ConnectionError`

Redis is not running. Start it with `brew services start redis` or `docker run -d -p 6379:6379 redis:7`.

### `ModuleNotFoundError` after adding a new app

Re-run `pip install -r requirements.txt` to catch any newly added dependencies.
