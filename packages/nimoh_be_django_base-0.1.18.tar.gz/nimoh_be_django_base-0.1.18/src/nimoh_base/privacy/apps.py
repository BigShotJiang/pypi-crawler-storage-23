"""Privacy app configuration."""

from django.apps import AppConfig


class PrivacyConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "nimoh_base.privacy"
    label = "nimoh_privacy"
    verbose_name = "Nimoh Base: Privacy"
