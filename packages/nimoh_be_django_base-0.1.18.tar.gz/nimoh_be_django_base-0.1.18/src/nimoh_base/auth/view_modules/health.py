"""Health check views.

This module provides health monitoring endpoints for:
- Authentication service status
- Database connectivity
- Redis cache connectivity
- Email service status
- Overall system health

Health check primitives are provided by nimoh_base.core.health.
"""

import logging

from django.conf import settings
from django.utils import timezone
from django.views.decorators.cache import never_cache
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from nimoh_base.core.api_tags import system_health_schema
from nimoh_base.core.health import check_cache, check_database, check_email
from nimoh_base.core.utils import get_client_ip

logger = logging.getLogger(__name__)


@system_health_schema(
    description="Check authentication system health",
    summary="Returns the current health status of the authentication system including database connectivity and critical components.",
)
@api_view(["GET"])
@permission_classes([AllowAny])
@never_cache
def health_check_view(request):
    """
    Authentication service health check.

    This endpoint provides comprehensive health information about the
    authentication service and its dependencies.

    **Authentication**: Not required
    **Caching**: Disabled (always fresh status)

    **Response**:
    ```json
    {
        "status": "healthy",
        "timestamp": "2023-10-29T15:30:00Z",
        "version": "1.0.0",
        "checks": {
            "database": {
                "status": "healthy",
                "response_time_ms": 15,
                "details": "PostgreSQL connection successful"
            },
            "cache": {
                "status": "healthy",
                "response_time_ms": 3,
                "details": "Redis connection successful"
            },
            "email": {
                "status": "healthy",
                "response_time_ms": 125,
                "details": "SMTP connection successful"
            }
        }
    }
    ```

    **Response Codes**:
    - `200 OK`: Service is healthy
    - `503 Service Unavailable`: One or more components are unhealthy
    """

    timestamp = timezone.now()
    checks = {}
    overall_status = "healthy"

    # Check database connectivity
    db_status = check_database()
    checks["database"] = db_status

    # Check cache connectivity
    cache_status = check_cache()
    checks["cache"] = cache_status

    # Check email service
    email_status = check_email()
    checks["email"] = email_status

    # Determine overall status from individual checks
    if db_status["status"] != "healthy":
        overall_status = "unhealthy"
    if cache_status["status"] != "healthy" and overall_status == "healthy":
        overall_status = "degraded"
    if email_status["status"] != "healthy" and overall_status == "healthy":
        overall_status = "degraded"

    # Check authentication-specific components
    auth_status = check_auth_components()
    checks["authentication"] = auth_status
    if auth_status["status"] != "healthy":
        overall_status = "unhealthy"

    health_data = {
        "status": overall_status,
        "timestamp": timestamp,
        "version": getattr(settings, "VERSION", "1.0.0"),
        "checks": checks,
    }

    # Log health check
    logger.info(
        "Health check performed",
        extra={
            "status": overall_status,
            "checks_count": len(checks),
            "ip_address": get_client_ip(request),
        },
    )

    # Return appropriate status code
    if overall_status == "healthy":
        return Response(health_data, status=status.HTTP_200_OK)
    else:
        return Response(health_data, status=status.HTTP_503_SERVICE_UNAVAILABLE)


def check_auth_components():
    """Check authentication-specific components."""
    import time

    start_time = time.time()

    try:
        from ..models import TokenBlacklist, User, UserSession

        # Test model queries
        user_count = User.objects.count()
        active_sessions = UserSession.objects.filter(is_active=True).count()
        blacklisted_tokens = TokenBlacklist.objects.count()

        response_time = int((time.time() - start_time) * 1000)

        return {
            "status": "healthy",
            "response_time_ms": response_time,
            "details": f"Auth models accessible (Users: {user_count}, Sessions: {active_sessions}, Blacklisted: {blacklisted_tokens})",
        }

    except Exception as e:
        response_time = int((time.time() - start_time) * 1000)
        logger.error("Auth components health check failed", extra={"error": str(e)})

        return {
            "status": "unhealthy",
            "response_time_ms": response_time,
            "details": f"Auth components check failed: {type(e).__name__}",
        }
