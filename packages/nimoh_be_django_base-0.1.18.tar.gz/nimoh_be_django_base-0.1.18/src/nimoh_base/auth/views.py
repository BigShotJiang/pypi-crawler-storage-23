"""Authentication views.

This module provides a clean interface for authentication views that have been
organized into logical modules within the view_modules/ directory structure.

Views Organization:
- authentication.py: Core auth (registration, login, logout)
- password.py: Password management (change, reset)
- email.py: Email verification
- tokens.py: JWT token management
- health.py: Health check endpoints

Note: Onboarding-related views are handled by the dedicated onboarding app.
"""

# Import organized authentication views from modules
from .view_modules.authentication import login_view as LoginView
from .view_modules.authentication import logout_view as LogoutView
from .view_modules.authentication import register_view as UserRegistrationView
from .view_modules.email import EmailVerificationResendView, EmailVerificationView
from .view_modules.password import PasswordResetConfirmView
from .view_modules.password import change_password_view as PasswordChangeView
from .view_modules.password import password_reset_request_view as PasswordResetRequestView
from .view_modules.sessions import list_sessions_view as ListSessionsView
from .view_modules.sessions import terminate_all_sessions_view as TerminateAllSessionsView
from .view_modules.sessions import terminate_session_view as TerminateSessionView
from .view_modules.tokens import ExchangeTokenView, RefreshTokenView, TokenVerifyView

# Export all authentication views for module-level imports
__all__ = [
    "EmailVerificationResendView",
    # Email verification views
    "EmailVerificationView",
    "ExchangeTokenView",
    # Session management views
    "ListSessionsView",
    "LoginView",
    "LogoutView",
    # Password management views
    "PasswordChangeView",
    "PasswordResetConfirmView",
    "PasswordResetRequestView",
    # Token management views
    "RefreshTokenView",
    "TerminateAllSessionsView",
    "TerminateSessionView",
    "TokenVerifyView",
    # Core authentication views
    "UserRegistrationView",
]
