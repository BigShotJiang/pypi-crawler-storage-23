"""Vaani — Voice to polished text, right at your cursor."""

__version__ = "0.1.0"
