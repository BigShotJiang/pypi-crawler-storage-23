"""
Tests for cellitac.mainModel (ML stage).
Run with:  pytest tests/ -v
No R needed – tests use synthetic data.
"""

import os
import json
import numpy as np
import pandas as pd
import pytest

from cellitac.mainModel import scATACMLPipeline


# ============================================================================
# Fixtures
# ============================================================================

def _make_pipeline(tmp_path, n_cells=200, n_rna=50, n_atac=80, seed=0):
    """Create a minimal synthetic pipeline ready to run."""
    rng        = np.random.default_rng(seed)
    data_dir   = tmp_path / "data"
    output_dir = tmp_path / "results"
    data_dir.mkdir()

    cells      = [f"cell_{i}" for i in range(n_cells)]
    cell_types = (
        ["T_cell"]   * 70 +
        ["B_cell"]   * 60 +
        ["NK_cell"]  * 40 +
        ["Monocyte"] * 30
    )

    rna_cols  = [f"GENE_{i}"  for i in range(n_rna)]
    atac_cols = [f"peak_{i}:{i*100}-{i*100+200}" for i in range(n_atac)]
    all_cols  = rna_cols + atac_cols

    X = pd.DataFrame(
        rng.random((n_cells, len(all_cols))),
        index=cells, columns=all_cols,
    )
    X.to_csv(data_dir / "combined_features.csv")

    labels = pd.DataFrame({"cell_type": cell_types}, index=cells)
    labels.index.name = "cell_id"
    labels.to_csv(data_dir / "cell_labels.csv")

    pipeline = scATACMLPipeline(
        data_dir=str(data_dir),
        output_dir=str(output_dir),
    )
    return pipeline


# ============================================================================
# Tests
# ============================================================================

def test_load_data(tmp_path):
    p = _make_pipeline(tmp_path)
    assert p.load_data() is True
    assert p.X.shape[0] > 0
    assert len(p.class_names) == 4


def test_full_pipeline_runs(tmp_path):
    p = _make_pipeline(tmp_path)
    result = p.run_complete_pipeline()
    assert result is True


def test_output_files_created(tmp_path):
    p = _make_pipeline(tmp_path)
    p.run_complete_pipeline()

    expected_files = [
        "ml_pipeline_report.json",
        "model_performance_summary.csv",
        "detailed_model_results.xlsx",
        "class_distribution_analysis.png",
        "model_performance_comparison.png",
        "confusion_matrices.png",
        "overfitting_analysis.png",
        "learning_curves.png",
        "performance_radar.png",
        "feature_distributions.png",
        "class_separation_pca.png",
        "basic_tf_network.png",
        "simple_feature_heatmap.png",
        "feature_importance.png",
    ]
    for fname in expected_files:
        path = os.path.join(str(tmp_path / "results"), fname)
        assert os.path.exists(path), f"Missing output file: {fname}"


def test_metrics_df_structure(tmp_path):
    p = _make_pipeline(tmp_path)
    p.run_complete_pipeline()

    assert hasattr(p, "metrics_df")
    required_cols = {"Model", "Accuracy", "Precision", "Recall", "F1_Score", "AUC"}
    assert required_cols.issubset(set(p.metrics_df.columns))
    assert len(p.metrics_df) == 3   # RF, XGBoost, SVM


def test_json_report_valid(tmp_path):
    p = _make_pipeline(tmp_path)
    p.run_complete_pipeline()

    report_path = tmp_path / "results" / "ml_pipeline_report.json"
    with open(report_path) as f:
        report = json.load(f)

    assert "Dataset_Info"     in report
    assert "Model_Performance" in report
    assert report["Dataset_Info"]["Cell_Types"] == 4


def test_rare_class_filtering(tmp_path):
    """Cells with < ML_RARE_CLASS_MIN (10) should be removed."""
    rng      = np.random.default_rng(42)
    data_dir = tmp_path / "data"
    data_dir.mkdir()

    cells = [f"cell_{i}" for i in range(120)]
    types = ["T_cell"] * 50 + ["B_cell"] * 50 + ["Rare"] * 20   # Rare > 10, kept
    types_tiny = ["T_cell"] * 50 + ["B_cell"] * 50 + ["Tiny"] * 5 + ["Rare"] * 15

    X = pd.DataFrame(rng.random((120, 30)), index=cells,
                     columns=[f"f{i}" for i in range(30)])
    X.to_csv(data_dir / "combined_features.csv")

    labels = pd.DataFrame({"cell_type": types_tiny}, index=cells)
    labels.index.name = "cell_id"
    labels.to_csv(data_dir / "cell_labels.csv")

    p = scATACMLPipeline(data_dir=str(data_dir), output_dir=str(tmp_path / "results"))
    p.load_data()

    # "Tiny" (5 cells) should be removed; others kept
    assert "Tiny" not in p.class_names
    assert "T_cell" in p.class_names


def test_reproducibility(tmp_path):
    """Running pipeline twice must give same best model name."""
    def _best_model(tp):
        p = _make_pipeline(tp, seed=99)
        p.run_complete_pipeline()
        return p.metrics_df.loc[p.metrics_df["F1_Score"].idxmax(), "Model"]

    tmp1 = tmp_path / "run1"
    tmp2 = tmp_path / "run2"
    tmp1.mkdir(); tmp2.mkdir()

    assert _best_model(tmp1) == _best_model(tmp2)
