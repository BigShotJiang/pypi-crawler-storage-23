"""
cellitac.pipeline
=================
Top-level public functions that wire preprocessing + ML together.
These are what users import from ``cellitac`` directly.
"""

from cellitac import config as cfg
from cellitac.preprocessing import run_team1, run_team2, run_integration
from cellitac.mainModel import scATACMLPipeline


def run_preprocessing(
    input_dir:        str = cfg.INPUT_DIR,
    output_dir_team1: str = cfg.OUTPUT_DIR_TEAM1,
    output_dir_team2: str = cfg.OUTPUT_DIR_TEAM2,
    output_dir_python:str = cfg.OUTPUT_DIR_PYTHON,
) -> dict:
    """
    Run the full preprocessing pipeline (RNA → ATAC → integration).

    Parameters
    ----------
    input_dir         : folder with raw 10x data files
    output_dir_team1  : RNA output folder
    output_dir_team2  : ATAC output folder
    output_dir_python : ML-ready CSV output folder

    Returns
    -------
    dict from run_integration with keys 'features', 'labels', 'splits'
    """
    run_team1(input_dir=input_dir, output_dir=output_dir_team1)
    run_team2(input_dir=input_dir,
              output_dir_team1=output_dir_team1,
              output_dir=output_dir_team2)
    return run_integration(
        output_dir_team1=output_dir_team1,
        output_dir_team2=output_dir_team2,
        output_dir=output_dir_python,
    )


def run_model(
    data_dir:   str = cfg.OUTPUT_DIR_PYTHON,
    output_dir: str = cfg.OUTPUT_DIR_ML,
) -> bool:
    """
    Run the ML classification pipeline on preprocessed data.

    Parameters
    ----------
    data_dir   : folder containing python_ready_data CSVs
    output_dir : folder where ML results will be saved

    Returns
    -------
    True if pipeline completed successfully, False otherwise
    """
    pipeline = scATACMLPipeline(data_dir=data_dir, output_dir=output_dir)
    return pipeline.run_complete_pipeline()


def run_full_pipeline(
    input_dir:         str = cfg.INPUT_DIR,
    output_dir:        str = "cellitac_results",
) -> bool:
    """
    Run everything end-to-end: preprocessing + ML.

    Parameters
    ----------
    input_dir  : folder with raw 10x PBMC data files
    output_dir : base folder for all outputs

    Returns
    -------
    True if all steps completed successfully
    """
    import os

    team1_dir  = os.path.join(output_dir, "team1_rna_output")
    team2_dir  = os.path.join(output_dir, "team2_atac_output")
    python_dir = os.path.join(output_dir, "python_ready_data")
    ml_dir     = os.path.join(output_dir, "ml_results")

    print(f"=== cellitac Full Pipeline ===")
    print(f"    Input : {input_dir}")
    print(f"    Output: {output_dir}\n")

    # Stage 1: preprocessing
    try:
        run_preprocessing(
            input_dir=input_dir,
            output_dir_team1=team1_dir,
            output_dir_team2=team2_dir,
            output_dir_python=python_dir,
        )
    except Exception as exc:
        print(f"[FAIL] Preprocessing stage failed: {exc}")
        return False

    # Stage 2: ML
    return run_model(data_dir=python_dir, output_dir=ml_dir)
