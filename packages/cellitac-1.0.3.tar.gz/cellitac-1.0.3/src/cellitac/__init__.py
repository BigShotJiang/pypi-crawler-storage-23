"""
cellitac
========
Single-Cell ATAC + RNA Multiome Processing & ML Classification Pipeline.

This package runs two stages end-to-end:

  Stage 1 – Preprocessing (R via rpy2)
      • Team 1: RNA processing, QC, normalization, cell-type annotation
                (Seurat + SingleR + celldex)
      • Team 2: ATAC processing, QC, TF-IDF, LSI
                (Signac + EnsDb)
      • Integration: combine RNA + ATAC → ML-ready CSVs

  Stage 2 – ML Classification (pure Python)
      • Class imbalance analysis & SMOTE balancing
      • Feature engineering & selection
      • Random Forest, XGBoost, SVM training
      • Evaluation, visualizations, reports

Quick start
-----------
>>> from cellitac import run_preprocessing, run_model, run_full_pipeline
>>> run_full_pipeline(input_dir="~/singlecell/ATAC", output_dir="results")

Or from the command line::

    cellitac --input ~/singlecell/ATAC --output results
    cellitac-preprocess --input ~/singlecell/ATAC
    cellitac-model --data python_ready_data --output ml_results
"""

from cellitac._version import __version__
from cellitac.pipeline import run_preprocessing, run_model, run_full_pipeline

__all__ = [
    "run_preprocessing",
    "run_model",
    "run_full_pipeline",
    "__version__",
]
