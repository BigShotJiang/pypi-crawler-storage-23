MaterForge - Materials Formulation Engine with Python
=====================================================

A high-performance Python library for material simulation and analysis. MaterForge enables
efficient modeling of pure metals and alloys through YAML configuration files, providing
symbolic and numerical property evaluation for various material properties.

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   tutorials/getting_started
   tutorials/first_simulation
   how-to/define_materials
   how-to/energy_temperature_conversion
   explanation/design_philosophy
   explanation/material_properties
   reference/yaml_schema
   reference/api
   reference/api/material

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
