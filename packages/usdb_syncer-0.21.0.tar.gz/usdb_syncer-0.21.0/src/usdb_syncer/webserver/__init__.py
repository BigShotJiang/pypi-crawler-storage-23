"""Webserver to display song collection over HTTP."""
