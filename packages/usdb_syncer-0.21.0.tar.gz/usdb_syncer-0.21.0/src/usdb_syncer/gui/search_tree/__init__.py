"""Provides the search tree widget."""
