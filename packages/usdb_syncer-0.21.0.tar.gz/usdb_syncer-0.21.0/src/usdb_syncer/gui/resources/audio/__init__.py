"""File was generated using `write_resource_files.py`."""

from importlib import resources

METRONOME_TICK_WAV = resources.files(__package__) / "metronome-tick.wav"
