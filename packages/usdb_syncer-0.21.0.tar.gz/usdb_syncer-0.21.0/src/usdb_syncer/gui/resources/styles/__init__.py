"""File was generated using `write_resource_files.py`."""

from importlib import resources

DARK_QSS = resources.files(__package__) / "dark.qss"
DIFF_CSS = resources.files(__package__) / "diff.css"
