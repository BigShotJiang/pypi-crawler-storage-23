"""Resources package for the GUI."""
