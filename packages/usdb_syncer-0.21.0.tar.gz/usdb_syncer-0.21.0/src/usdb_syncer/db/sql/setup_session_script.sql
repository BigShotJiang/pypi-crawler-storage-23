PRAGMA journal_mode = WAL;

PRAGMA foreign_keys = ON;