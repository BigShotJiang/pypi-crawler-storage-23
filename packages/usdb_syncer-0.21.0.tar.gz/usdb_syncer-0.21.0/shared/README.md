These files are fetched by clients from GitHub at runtime. Do not move or rename!
