Authors
========

.. image:: _static/ird_small.png
    :target: https://www.ird.fr

* `Julie Orjuela <mailto:julie.orjuela@ird.fr>`_ (UMR DIADE - IRD)

* Yves Vigouroux (UMR DIADE - IRD)
