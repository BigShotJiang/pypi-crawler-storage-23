GLOBAL MODE
------------

iKISS was adapted to propose a `Global mode`. Useful if you are interested on counts kmers contained on genes by genetic group/population.

If you active `KMERS_MODULE` and unactive the "outliers mode", so not active `PCADAPT` and `LFMM` steps, iKISS calculate occurrences of presence and absence of kmers into the populations/groups given by user into the SAMPLES_FILE. If `MAPPING` and `INTERSECT` are also activated you can check occurrences found into chosen features (genes).

If you want to activate the global mode configurate iKISS such as :

.. code-block:: yaml

    WORKFLOW:
        # convert reads in kmers and computes a binary matrix
        KMERS_MODULE : true
        # structure genotype based in ancestry
        SNMF: false #or true
        # structure genotype based in pca
        PCADAPT : false
        # calculate association between genotype and phenotype
        LFMM : false
        # mapping of kmers over a genomic reference
        MAPPING_KMERS: true
        # assembly kmers outliers detected by pcadapt and lfmm
        ASSEMBLY_KMERS : false
        # intersect outliers position (directly kmers or contigs) and features in a gff
        INTERSECT : true


.. note::

 If you are in `global mode`, it is also possible to run SNMF; it is not incompatible.