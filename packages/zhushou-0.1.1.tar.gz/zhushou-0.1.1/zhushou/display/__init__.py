"""ZhuShou display utilities."""
