"""ZhuShou git integration."""
