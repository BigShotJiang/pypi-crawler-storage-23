"""ZhuShou tool executor."""
