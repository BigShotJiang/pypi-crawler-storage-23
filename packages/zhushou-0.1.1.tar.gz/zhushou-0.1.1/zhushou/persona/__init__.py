"""ZhuShou persona configuration."""
