"""ZhuShou memory subsystem."""
