from dataclasses import dataclass
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from kubernetes.client.models import V1JobCondition
else:
    V1JobCondition = object


@dataclass(frozen=True)
class K8sConfig:
    """Immutable configuration container for Kubernetes operations."""

    kubernetes_namespace: str


@dataclass(frozen=True)
class PodFailureInfo:
    """Information about a failed pod.

    Attributes:
        pod_name: Name of the failed pod.
        reason: Reason for pod failure (e.g., 'OOMKilled', 'Error', 'DeadlineExceeded').
        message: Detailed error message from the container, if available.
    """

    pod_name: str
    reason: str
    message: Optional[str]

    def to_dict(self) -> dict[str, Optional[str]]:
        """Convert PodFailureInfo to a dictionary for JSON serialization.

        Returns:
            Dictionary containing pod failure information with keys:
                - pod_name: Name of the failed pod
                - reason: Reason for pod failure
                - message: Detailed error message (may be None)
        """
        return {
            "pod_name": self.pod_name,
            "reason": self.reason,
            "message": self.message,
        }


@dataclass(frozen=True)
class JobStatus:
    """Immutable container for Kubernetes job status information.

    This class encapsulates the complete status of a Kubernetes job, including
    its execution state, error details, and pod-level failure information.

    Attributes:
        exists: Whether the job exists in Kubernetes.
        succeeded: Whether the job completed successfully.
        failed: Whether the job failed.
        active: Whether the job is currently running.
        error_message: Human-readable error message if the job failed.
        conditions: List of Kubernetes job conditions.
        pod_failures: List of pod failure details for failed jobs.
    """

    exists: bool
    succeeded: bool
    failed: bool
    active: bool
    error_message: Optional[str]
    conditions: list["V1JobCondition"]
    pod_failures: list[PodFailureInfo]

    @property
    def state(self) -> str:
        """Get the current state of the job as a string.

        Returns:
            One of: 'NotFound', 'Active', 'Succeeded', 'Failed', or 'Unknown'.
        """
        if not self.exists:
            return "NotFound"
        if self.succeeded:
            return "Succeeded"
        if self.failed:
            return "Failed"
        if self.active:
            return "Active"
        return "Unknown"

    def to_dict(self) -> dict:
        """Convert JobStatus to a dictionary for JSON serialization.

        Returns:
            Dictionary containing job status information with all fields including:
                - exists: Whether the job exists
                - succeeded: Whether the job succeeded
                - failed: Whether the job failed
                - active: Whether the job is active
                - error_message: Error message if any
                - state: Current state string
                - conditions: List of job condition dictionaries
                - pod_failures: List of pod failure dictionaries
        """
        return {
            "exists": self.exists,
            "succeeded": self.succeeded,
            "failed": self.failed,
            "active": self.active,
            "error_message": self.error_message,
            "state": self.state,
            "conditions": [condition.to_dict() for condition in self.conditions],
            "pod_failures": [failure.to_dict() for failure in self.pod_failures],
        }
