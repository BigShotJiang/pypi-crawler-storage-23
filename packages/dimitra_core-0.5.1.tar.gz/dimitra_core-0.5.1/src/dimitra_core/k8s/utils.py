import logging

from kubernetes import client

from dimitra_core.k8s.config import get_k8s_config
from dimitra_core.k8s.data import JobStatus, PodFailureInfo

logger = logging.getLogger("dimitra-core[k8s]")


def stop_task(job_name: str) -> object:
    """Stop a Kubernetes job and delete its associated pods.

    Deletes the specified Kubernetes job with immediate grace period termination.
    Associated pods are deleted in the background via Kubernetes garbage collection.

    Args:
        job_name: Name of the Kubernetes job to stop.

    Returns:
        Kubernetes V1Status object from the delete operation.

    Raises:
        Exception: If kubernetes_namespace is not configured.
        ApiException: If the job deletion fails.
    """
    logger.info(f"Stopping job and associated pods for job name: {job_name}")

    namespace = get_k8s_config().kubernetes_namespace
    batch_v1 = client.BatchV1Api()

    if not namespace:
        raise Exception("No namespace provided")

    response = batch_v1.delete_namespaced_job(
        name=job_name,
        namespace=namespace,
        body=client.V1DeleteOptions(grace_period_seconds=0, propagation_policy="Background"),
    )
    logger.info(f"Delete job response: {response}")
    return response


def get_job_status(job_name: str) -> JobStatus:
    """Get the status of a Kubernetes job and its associated pods.

    Queries the Kubernetes API to retrieve the current status of a job,
    including success/failure state, active status, and detailed error
    information from failed pods. This function examines both job-level
    conditions and pod-level container statuses to provide comprehensive
    failure diagnostics.

    Args:
        job_name: Name of the Kubernetes job to check.

    Returns:
        JobStatus: Immutable object containing job state, error details,
            and pod failure information.

    Raises:
        ApiException: If the Kubernetes API call fails (except for 404/not found).
    """
    logger.info(f"Checking job status for: {job_name}")

    from kubernetes.client.exceptions import ApiException

    namespace = get_k8s_config().kubernetes_namespace

    batch_v1 = client.BatchV1Api()
    core_v1 = client.CoreV1Api()

    try:
        # Try to read the job
        job = batch_v1.read_namespaced_job(name=job_name, namespace=namespace)

        status = job.status
        exists = True
        succeeded = status.succeeded is not None and status.succeeded > 0
        failed = status.failed is not None and status.failed > 0
        active = status.active is not None and status.active > 0
        error_message = None
        conditions = status.conditions or []
        pod_failures: list[PodFailureInfo] = []

        # If job failed, try to get more details from pods
        if failed:
            error_message = "Job failed in Kubernetes"

            # Get pods for this job
            label_selector = f"job-name={job_name}"
            try:
                pods = core_v1.list_namespaced_pod(namespace=namespace, label_selector=label_selector)

                # Look for failed pods and extract error details
                for pod in pods.items:
                    if pod.status.phase == "Failed":
                        # Check container statuses for specific errors
                        if pod.status.container_statuses:
                            for container_status in pod.status.container_statuses:
                                if container_status.state.terminated:
                                    terminated = container_status.state.terminated
                                    reason = terminated.reason
                                    message = terminated.message

                                    # Add pod failure info
                                    pod_failures.append(
                                        PodFailureInfo(
                                            pod_name=pod.metadata.name,
                                            reason=reason,
                                            message=message,
                                        )
                                    )

                                    if reason == "OOMKilled":
                                        error_message = "Task failed: Out of memory (OOMKilled)"
                                    elif reason == "Error":
                                        error_message = f"Task failed: {message or 'Container error'}"
                                    else:
                                        error_message = f"Task failed: {reason}"

                                    # Use the first failed container's error
                                    break

                        # If no container status, check pod conditions
                        if pod.status.conditions:
                            for condition in pod.status.conditions:
                                if condition.type == "PodScheduled" and condition.status == "False":
                                    error_message = f"Task failed: Pod scheduling failed - {condition.reason}"
                                    pod_failures.append(
                                        PodFailureInfo(
                                            pod_name=pod.metadata.name,
                                            reason=condition.reason,
                                            message=condition.message,
                                        )
                                    )
                                    break

                        # Use the first failed pod's error
                        break

            except ApiException as e:
                logger.warning(f"Could not fetch pods for job {job_name}: {e}")

        # Check job conditions for deadline exceeded
        if status.conditions:
            for condition in status.conditions:
                if condition.type == "Failed" and condition.reason == "DeadlineExceeded":
                    failed = True
                    error_message = "Task failed: Job deadline exceeded (15 days)"

        return JobStatus(
            exists=exists,
            succeeded=succeeded,
            failed=failed,
            active=active,
            error_message=error_message,
            conditions=conditions,
            pod_failures=pod_failures,
        )

    except ApiException as e:
        if e.status == 404:
            # Job doesn't exist
            logger.info(f"Job {job_name} not found in Kubernetes")
            return JobStatus(
                exists=False,
                succeeded=False,
                failed=False,
                active=False,
                error_message="Job not found in Kubernetes",
                conditions=[],
                pod_failures=[],
            )
        else:
            # Some other API error
            logger.error(f"Error checking job status for {job_name}: {e}")
            raise
