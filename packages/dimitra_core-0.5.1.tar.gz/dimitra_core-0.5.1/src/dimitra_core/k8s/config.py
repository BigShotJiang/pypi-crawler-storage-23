import logging
import threading
from typing import Optional

from dimitra_core.k8s.data import K8sConfig

logger = logging.getLogger("dimitra-core[k8s]")

_k8s_config: Optional[K8sConfig] = None
_k8s_config_lock = threading.Lock()


def init_k8s(kubernetes_namespace: str):
    """Initialize the Kubernetes module with namespace configuration.

    This function must be called once before using any K8s utility functions.
    It stores the Kubernetes namespace for job operations and loads the Kubernetes
    configuration from the environment (in-cluster or kubeconfig).
    The initialization is thread-safe and will raise an error if called multiple times.

    Args:
        kubernetes_namespace: Kubernetes namespace where jobs will be managed.

    Returns:
        None

    Raises:
        RuntimeError: If the module is already initialized.
        ImportError: If kubernetes package is not installed.
    """
    with _k8s_config_lock:
        global _k8s_config
        if _k8s_config:
            raise RuntimeError("Module already initialized")

        try:
            import kubernetes  # noqa: F401
        except ImportError as e:
            raise ImportError(
                f"Missing imports, install dimitra-core[k8s] or dimitra-core[all] to use the k8s module: {e}"
            )

        _k8s_config = K8sConfig(kubernetes_namespace=kubernetes_namespace)

        logger.info("Initialized k8s module")


def get_k8s_config():
    """Retrieve the current K8s configuration.

    Returns the singleton K8sConfig instance containing the Kubernetes namespace
    for job operations.

    Returns:
        K8sConfig: Immutable configuration object containing kubernetes_namespace.

    Raises:
        RuntimeError: If the module has not been initialized.
    """
    if _k8s_config is None:
        raise RuntimeError("dimitra_core.k8s module needs to be initialized using init_k8s")
    return _k8s_config


def _reset_k8s_for_tests():
    """Reset the K8s module state for testing purposes.

    This function is intended for use in test fixtures only. It clears the
    singleton configuration to allow multiple test cases to initialize the
    module independently.

    Warning:
        This function should never be called in production code.
    """
    global _k8s_config
    with _k8s_config_lock:
        _k8s_config = None
