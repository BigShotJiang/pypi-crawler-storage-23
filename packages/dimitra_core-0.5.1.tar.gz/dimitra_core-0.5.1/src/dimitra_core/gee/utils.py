import logging
import os
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import ee
import numpy as np
import rasterio
from ee.batch import Task
from ee.featurecollection import FeatureCollection
from rasterio.transform import from_origin
from rasterio.windows import Window

from dimitra_core.gee.config import get_gee_config
from dimitra_core.gee.constants import TASK_POLL_INTERVAL, TASK_WAIT_TIMEOUT

logger = logging.getLogger("dimitra-core[gee]")


def get_fao_gaul_table(country_code: str | int, state_codes: list[str | int]):
    """Retrieve FAO GAUL administrative boundaries for a country or specific states.

    Args:
        country_code: FAO GAUL country code (level 0) as string or integer.
        state_codes: List of FAO GAUL state codes (level 1). Empty list returns country boundary.

    Returns:
        ee.FeatureCollection: Filtered GAUL feature collection for the specified region.
    """
    _country_code = int(country_code)
    _state_codes = [int(state_code) for state_code in state_codes]

    level = 1 if _state_codes else 0
    gaul = ee.FeatureCollection(f"projects/sat-io/open-datasets/FAO/GAUL/GAUL_2024_L{level}")
    gaul_level0 = gaul.filter(ee.Filter.eq("gaul0_code", _country_code))

    # check if the filter has worked
    filtered_countries = gaul_level0.aggregate_array("gaul0_code").distinct().getInfo()
    if set(filtered_countries) != set([_country_code]):
        raise Exception(f"Unable to find correct FAO GAUL country for: {_country_code}")

    if level == 0:
        return gaul_level0

    gaul_level1 = gaul_level0.filter(ee.Filter.inList("gaul1_code", _state_codes))

    filtered_states = gaul_level1.aggregate_array("gaul1_code").distinct().getInfo()
    if set(filtered_states) != set(_state_codes):
        raise Exception("Some FAO GAUL states are not filtered correctly for this region")

    return gaul_level1


def get_fao_gaul_table_codes(fao_gaul_table: FeatureCollection):
    """Get the distinct country and state codes from a FAO GAUL feature collection.

    Args:
        fao_gaul_table: FAO GAUL feature collection to extract codes from.

    Returns:
        tuple: A tuple of (country_codes, state_codes) as Python lists containing
            distinct gaul0_code and gaul1_code values respectively.
    """
    country_codes = fao_gaul_table.aggregate_array("gaul0_code").distinct().getInfo()
    state_codes = fao_gaul_table.aggregate_array("gaul1_code").distinct().getInfo()
    return country_codes, state_codes


def wait_for_gee_task(task: Task, poll_interval=TASK_POLL_INTERVAL, timeout=TASK_WAIT_TIMEOUT):
    """Wait for a Google Earth Engine task to complete synchronously.

    Args:
        task: Google Earth Engine Task object to monitor.
        poll_interval: Time in seconds between status checks. Defaults to TASK_POLL_INTERVAL.
        timeout: Maximum wait time in seconds. Defaults to TASK_WAIT_TIMEOUT.

    Returns:
        str: Final task state (COMPLETED, FAILED, or CANCELLED).
    """
    start = time.time()
    while True:
        if time.time() - start > timeout:
            raise TimeoutError("GEE Task timed out")

        status = task.status()
        state = status["state"]
        if state == Task.State.UNSUBMITTED:
            raise Exception("GEE task is UNSUBMITTED, you likely forgot to start the task using task.start()")
        if state in [Task.State.COMPLETED, Task.State.FAILED, Task.State.CANCELLED]:
            return state
        time.sleep(poll_interval)


def download_gee_export(file_name_prefix, output_file, file_suffix):
    """Download and merge GEE export files from Google Cloud Storage.

    Args:
        file_name_prefix: GCS object prefix for the exported files.
        output_file: Local path where the downloaded/merged file will be saved.
        file_suffix: File extension suffix (e.g., '.tif') to append to the prefix.

    Returns:
        None
    """
    gee_config = get_gee_config()
    bucket = gee_config.gcs_client.bucket(gee_config.gcs_bucket_name)

    gcs_key = f"{file_name_prefix}{file_suffix}"
    blob = bucket.blob(gcs_key)

    # check if the file exists
    if blob.exists():
        logger.info(f"Downloading single file for {file_name_prefix}")
        blob.download_to_filename(output_file)
        return

    matching_blobs = list(bucket.list_blobs(prefix=file_name_prefix))
    if not matching_blobs:
        raise Exception("No matching files found")

    tile_blobs = []
    for blob in matching_blobs:
        if blob.name.endswith(".tif") and blob.name != gcs_key:
            tile_blobs.append(blob)

    with tempfile.TemporaryDirectory() as temp_dir:
        local_tile_paths = []

        def download_blob(i, blob):
            local_path = os.path.join(temp_dir, f"tile_{i}.tif")
            blob.download_to_filename(local_path)
            return local_path

        # download all the tiles
        total_blobs = len(tile_blobs)
        logger.info(f"Downloading {total_blobs} blobs for {file_name_prefix}")
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = [executor.submit(download_blob, i, blob) for i, blob in enumerate(tile_blobs)]
            for future in as_completed(futures):
                local_tile_paths.append(future.result())

        logger.info(f"Downloaded all blobs for {file_name_prefix}, merging tiles into {output_file}")
        _merge_split_export_tiles(local_tile_paths, output_file)
        logger.info(f"Merged all {total_blobs} tiles into {output_file}")


def _merge_split_export_tiles(local_tile_paths, output_path):
    """Merge multiple GeoTIFF tiles into a single raster file.

    Args:
        local_tile_paths: List of local file paths to the tile GeoTIFF files.
        output_path: Path where the merged GeoTIFF will be saved.

    Returns:
        None
    """
    total_tiles = len(local_tile_paths)
    logger.info(f"Merging {total_tiles} tiles into {output_path}")
    # Step 1: Calculate merged bounds and resolution
    minx, miny, maxx, maxy = None, None, None, None
    res_x, res_y = None, None
    for path in local_tile_paths:
        with rasterio.open(path) as src:
            bounds = src.bounds
            if minx is None:
                minx, miny, maxx, maxy = bounds.left, bounds.bottom, bounds.right, bounds.top
                res_x, res_y = src.res
                dtype = src.dtypes[0]
                crs = src.crs
            else:
                minx = min(minx, bounds.left)
                miny = min(miny, bounds.bottom)
                maxx = max(maxx, bounds.right)
                maxy = max(maxy, bounds.top)

    # Step 2: Compute output raster size
    width = int(np.ceil((maxx - minx) / res_x))
    height = int(np.ceil((maxy - miny) / res_y))
    transform = from_origin(minx, maxy, res_x, res_y)

    # Step 3: Create output raster
    meta = {
        "driver": "GTiff",
        "height": height,
        "width": width,
        "count": 1,
        "dtype": dtype,
        "crs": crs,
        "transform": transform,
        "compress": "DEFLATE",
    }

    with rasterio.open(output_path, "w", **meta) as dst:
        # Step 4: Write tiles one by one
        for i, path in enumerate(local_tile_paths):
            logger.info(f"Writing tile {i+1}/{total_tiles} into {output_path}")
            with rasterio.open(path) as src:
                # Destination offsets
                x_off = int((src.bounds.left - minx) / res_x)
                y_off = int((maxy - src.bounds.top) / res_y)

                # If tile is very large, write in chunks
                tile_height = src.height
                tile_width = src.width
                block_size = 1024  # adjust if needed

                for i in range(0, tile_height, block_size):
                    for j in range(0, tile_width, block_size):
                        h = min(block_size, tile_height - i)
                        w = min(block_size, tile_width - j)
                        window = Window(j, i, w, h)
                        data = src.read(1, window=window)
                        dst_window = Window(x_off + j, y_off + i, w, h)
                        dst.write(data, 1, window=dst_window)
