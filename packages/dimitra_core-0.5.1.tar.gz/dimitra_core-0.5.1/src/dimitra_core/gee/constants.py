DEFAULT_SCOPES = [
    "https://www.googleapis.com/auth/earthengine",
    "https://www.googleapis.com/auth/devstorage.full_control",
]

TASK_POLL_INTERVAL = 10  # Poll GEE task every 10 seconds

TASK_WAIT_TIMEOUT = 24 * 3600  # Timeout if GEE task takes more than 1 day to complete
