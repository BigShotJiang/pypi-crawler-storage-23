import logging
import threading
from typing import Optional

from dimitra_core.gee.constants import DEFAULT_SCOPES
from dimitra_core.gee.data import GEEConfig

logger = logging.getLogger("dimitra-core[gee]")

_gee_config: Optional[GEEConfig] = None
_gee_config_lock = threading.Lock()


def init_gee(
    service_account_file_path: str,
    gcs_bucket_name: str,
    scopes: Optional[list[str]] = DEFAULT_SCOPES,
):
    """Initialize the Google Earth Engine module with service account credentials.

    This function must be called once before using any GEE utility functions.
    It creates a singleton Google Cloud Storage client that is reused across all operations
    and initializes the Earth Engine API with the provided service account credentials.
    The initialization is thread-safe and will raise an error if called multiple times.

    Args:
        service_account_file_path: Path to the Google Cloud service account JSON file.
        gcs_bucket_name: Google Cloud Storage bucket name for GEE exports.
        scopes: OAuth2 scopes for Google Cloud services. Defaults to DEFAULT_SCOPES.

    Returns:
        None
    """
    with _gee_config_lock:
        global _gee_config
        if _gee_config:
            raise RuntimeError("Module already initialized")

        try:
            import ee
            from google.cloud import storage
            from google.oauth2.service_account import Credentials
        except ImportError as e:
            raise ImportError(
                f"Missing imports, install dimitra-core[gee] or dimitra-core[all] to use the gee module: {e}"
            )

        credentials = Credentials.from_service_account_file(service_account_file_path, scopes=scopes)
        ee.Initialize(credentials=credentials)

        _gee_config = GEEConfig(
            gcs_bucket_name=gcs_bucket_name,
            gcs_client=storage.Client.from_service_account_json(service_account_file_path),
        )

        logger.info("Initialized gee module")


def get_gee_config():
    """Retrieve the current GEE configuration.

    Returns the singleton GEEConfig instance containing the google storage client,
    and bucket name.

    Returns:
        GEEConfig: Immutable configuration object containing gcs_client, and gcs_bucket_name.
    """
    if _gee_config is None:
        raise RuntimeError("dimitra_core.gee module needs to be initialized using init_gee")
    return _gee_config


def _reset_gee_for_tests():
    global _gee_config
    with _gee_config_lock:
        _gee_config = None
