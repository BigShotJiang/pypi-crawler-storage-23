from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from google.cloud.storage import Client as GCSClient  # type: ignore[import-not-found]
else:
    GCSClient = object


@dataclass(frozen=True)
class GEEConfig:
    """Immutable configuration container for GEE operations."""

    gcs_bucket_name: str
    gcs_client: GCSClient
