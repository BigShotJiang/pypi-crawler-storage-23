from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mypy_boto3_s3 import S3Client  # type: ignore[import-not-found]
else:
    S3Client = object


@dataclass(frozen=True)
class S3Config:
    """Immutable configuration container for S3 operations."""

    region_name: str
    bucket_name: str
    s3_client: S3Client
