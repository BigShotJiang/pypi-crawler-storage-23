import logging
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import BinaryIO, Optional

from botocore.exceptions import ClientError

from dimitra_core.s3.config import get_s3_config
from dimitra_core.s3.constants import FILE_EXPIRATION

logger = logging.getLogger("dimitra-core[s3]")


def upload_file(file_path: str, s3_key: str, bucket_name: Optional[str] = None, silent=False) -> None:
    """Upload a file to S3.

    Args:
        file_path: Local path to the file to upload.
        s3_key: S3 object key (destination path).
        bucket_name: S3 bucket name. Defaults to configured bucket.
        silent: Suppress logging if True. Defaults to False.

    Returns:
        None
    """
    s3_config = get_s3_config()
    if not silent:
        logger.info(f"Uploading file: {file_path} to S3 key: {s3_key}")
    bucket_name = bucket_name if bucket_name else s3_config.bucket_name
    s3_config.s3_client.upload_file(file_path, bucket_name, s3_key)


def delete_file(s3_key: str, bucket_name: Optional[str] = None, silent=False) -> None:
    """Delete a file from dimitra_core.s3.

    Args:
        s3_key: S3 object key to delete.
        bucket_name: S3 bucket name. Defaults to configured bucket.
        silent: Suppress logging if True. Defaults to False.

    Returns:
        None
    """
    s3_config = get_s3_config()
    if not silent:
        logger.info(f"Deleting file from S3 key: {s3_key}")
    bucket_name = bucket_name if bucket_name else s3_config.bucket_name
    s3_config.s3_client.delete_object(Bucket=bucket_name, Key=s3_key)


def upload_bytes(
    bytes: BinaryIO, s3_key: str, content_type: str, bucket_name: Optional[str] = None, silent=False
) -> None:
    """Upload bytes to S3 from a file-like object.

    Args:
        bytes: File-like object containing data to upload.
        s3_key: S3 object key (destination path).
        content_type: MIME type of the content.
        bucket_name: S3 bucket name. Defaults to configured bucket.
        silent: Suppress logging if True. Defaults to False.

    Returns:
        None
    """
    s3_config = get_s3_config()
    if not silent:
        logger.info(f"Uploading bytes to S3 key: {s3_key}")
    bytes.seek(0)
    bucket_name = bucket_name if bucket_name else s3_config.bucket_name
    s3_config.s3_client.upload_fileobj(bytes, bucket_name, s3_key, ExtraArgs={"ContentType": content_type})


def download_file(s3_key: str, file_path: str, bucket_name: Optional[str] = None) -> None:
    """Download a file from S3 to local filesystem.

    Args:
        s3_key: S3 object key to download.
        file_path: Local path where file will be saved.
        bucket_name: S3 bucket name. Defaults to configured bucket.

    Returns:
        None
    """
    s3_config = get_s3_config()
    logger.info(f"Downloading file from S3 key: {s3_key} to file_path: {file_path}")
    bucket_name = bucket_name if bucket_name else s3_config.bucket_name
    s3_config.s3_client.download_file(bucket_name, s3_key, file_path)


def upload_directory(dir_path: str, dir_s3_key: str, bucket_name: Optional[str] = None) -> None:
    """Upload a directory and its contents to S3 recursively.

    Args:
        dir_path: Local directory path to upload.
        dir_s3_key: S3 prefix (directory path) for uploaded files.
        bucket_name: S3 bucket name. Defaults to configured bucket.

    Returns:
        None
    """
    s3_config = get_s3_config()
    logger.info(f"Uploading directory from dir_path: {dir_path} to dir_s3_key: {dir_s3_key}")
    bucket_name = bucket_name if bucket_name else s3_config.bucket_name
    path = Path(dir_path)
    with ThreadPoolExecutor(max_workers=20) as exc:
        for f in path.rglob("*"):
            if f.is_file():
                file_path = str(f)
                s3_key = (Path(dir_s3_key) / f.relative_to(path)).as_posix()
                exc.submit(upload_file, file_path, s3_key, bucket_name=bucket_name, silent=True)


def get_presigned_url(s3_key: str, expires_in=FILE_EXPIRATION, bucket_name: Optional[str] = None) -> Optional[str]:
    """Generate a presigned URL for downloading a file from dimitra_core.s3.

    Args:
        s3_key: S3 object key to generate URL for.
        expires_in: URL expiration time in seconds. Defaults to FILE_EXPIRATION.
        bucket_name: S3 bucket name. Defaults to configured bucket.

    Returns:
        str: Presigned URL for downloading the file, or None if s3_key is empty.
    """
    s3_config = get_s3_config()
    if not s3_key:
        return None
    bucket_name = bucket_name if bucket_name else s3_config.bucket_name
    params = {"Bucket": bucket_name, "Key": s3_key}
    response = s3_config.s3_client.generate_presigned_url("get_object", Params=params, ExpiresIn=expires_in)
    return response


def put_presigned_url(
    s3_key: str, file_type: str, expires_in=FILE_EXPIRATION, bucket_name: Optional[str] = None
) -> Optional[str]:
    """Generate a presigned URL for uploading a file to S3.

    Args:
        s3_key: S3 object key for the upload destination.
        file_type: MIME type of the file to be uploaded.
        expires_in: URL expiration time in seconds. Defaults to FILE_EXPIRATION.
        bucket_name: S3 bucket name. Defaults to configured bucket.

    Returns:
        str: Presigned URL for uploading the file, or None if s3_key or file_type is empty.
    """
    s3_config = get_s3_config()
    if (not s3_key) or (not file_type):
        return None
    bucket_name = bucket_name if bucket_name else s3_config.bucket_name
    params = {"Bucket": bucket_name, "Key": s3_key, "ContentType": file_type}
    response = s3_config.s3_client.generate_presigned_url("put_object", Params=params, ExpiresIn=expires_in)
    return response


def s3_key_exists(s3_key: str, bucket_name: Optional[str] = None) -> bool:
    """Check if an S3 key exists in the bucket.

    Args:
        s3_key: S3 object key to check.
        bucket_name: S3 bucket name. Defaults to configured bucket.

    Returns:
        bool: True if the key exists, False otherwise.
    """
    s3_config = get_s3_config()
    logger.info(f"Checking if S3 key exists: {s3_key}")
    bucket_name = bucket_name if bucket_name else s3_config.bucket_name
    try:
        s3_config.s3_client.head_object(Bucket=bucket_name, Key=s3_key)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "404":
            return False
        raise


def get_file_size(s3_key: str, bucket_name: Optional[str] = None) -> Optional[int]:
    """Get the size of a file in S3.

    Args:
        s3_key: S3 object key to check.
        bucket_name: S3 bucket name. Defaults to configured bucket.

    Returns:
        int: File size in bytes, or None if the file doesn't exist or an error occurs.
    """
    s3_config = get_s3_config()
    if not s3_key:
        return None

    bucket_name = bucket_name if bucket_name else s3_config.bucket_name
    try:
        response = s3_config.s3_client.head_object(Bucket=bucket_name, Key=s3_key)
        return response["ContentLength"]
    except Exception as e:
        logger.error(f"Error in getting file size: {e}")
        return None
