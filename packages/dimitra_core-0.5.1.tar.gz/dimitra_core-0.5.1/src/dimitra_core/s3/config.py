import logging
import threading
from typing import Optional

from dimitra_core.s3.data import S3Config

logger = logging.getLogger("dimitra-core[s3]")

_s3_config: Optional[S3Config] = None
_s3_config_lock = threading.Lock()


def init_s3(default_bucket_name, default_region_name):
    """Initialize the S3 module with default bucket and region configuration.

    This function must be called once before using any S3 utility functions.
    It creates a singleton boto3 S3 client that is reused across all operations.
    The initialization is thread-safe and will raise an error if called multiple times.

    Args:
        default_bucket_name: Default S3 bucket name for operations.
        default_region_name: AWS region name (e.g., 'us-west-2', 'eu-central-1').

    Returns:
        None
    """
    with _s3_config_lock:
        global _s3_config
        if _s3_config:
            raise RuntimeError("Module already initialized")

        try:
            import boto3
        except ImportError as e:
            raise ImportError(
                f"Missing imports, install dimitra-core[s3] or dimitra-core[all] to use the s3 module: {e}"
            )

        _s3_config = S3Config(
            bucket_name=default_bucket_name,
            region_name=default_region_name,
            s3_client=boto3.client(
                "s3", region_name=default_region_name, config=boto3.session.Config(max_pool_connections=50)
            ),
        )
        logger.info("Initialized s3 module")


def get_s3_config():
    """Retrieve the current S3 configuration.

    Returns the singleton S3Config instance containing the boto3 client,
    bucket name, and region.

    Returns:
        S3Config: Immutable configuration object containing s3_client, bucket_name, and region_name.
    """
    if _s3_config is None:
        raise RuntimeError("dimitra_core.s3 module needs to be initialized using init_s3")
    return _s3_config


def _reset_s3_for_tests():
    global _s3_config
    with _s3_config_lock:
        _s3_config = None
