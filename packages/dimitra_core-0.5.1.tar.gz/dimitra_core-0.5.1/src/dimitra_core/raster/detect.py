import os
import platform
import shutil
import sys
from pathlib import Path


def detect_gdal_geos() -> tuple[str | None, str | None]:
    """Detects the gdal and geos library path on any platform, using various detection methods.
    returns the GDAL_LIBRARY_PATH and GEOS_LIBRARY_PATH if found in env.
    **Recommended on Windows**: Install osgeo library on via GDAL wheel package

    Returns:
        A tuple of (gdal_library_path, geos_library_path). Each path is a string if found,
        or (None, None) if either library could not be located.
    """
    gdal_lib = os.getenv("GDAL_LIBRARY_PATH")
    geos_lib = os.getenv("GEOS_LIBRARY_PATH")

    # If both env vars are explicitly set, trust them
    if gdal_lib and geos_lib:
        return gdal_lib, geos_lib

    # If only one is set, ignore both (avoid half-configured state)
    if gdal_lib or geos_lib:
        gdal_lib = None
        geos_lib = None

    # Windows: try osgeo wheels first
    if sys.platform == "win32":
        try:
            import osgeo

            osgeo_dir = Path(osgeo.__file__).parent
            _gdal_lib = osgeo_dir / "gdal.dll"
            _geos_lib = osgeo_dir / "geos_c.dll"

            if _gdal_lib.exists() and _geos_lib.exists():
                return str(_gdal_lib), str(_geos_lib)
        except ImportError:
            pass

    # Detect architecture
    arch = platform.machine().lower()
    is_arm = arch in ("arm64", "aarch64")

    candidates: list[Path] = []

    gdalinfo = shutil.which("gdalinfo")
    if gdalinfo is None:
        raise RuntimeError("GDAL installation not found. Please install GDAL CLI tools for your platform.")

    bin_dir = Path(gdalinfo).parent
    candidates.append(bin_dir)
    candidates.append(bin_dir.parent / "lib")  # /usr/lib
    candidates.append(bin_dir.parent / "Library" / "lib")  # conda

    # Platform-specific well-known locations
    if sys.platform == "darwin":
        candidates += [
            Path("/opt/homebrew/lib"),  # Apple Silicon Homebrew
            Path("/usr/local/lib"),  # Intel macOS Homebrew
        ]
    elif sys.platform == "win32":
        candidates += [
            Path(r"C:\OSGeo4W\bin"),
            Path(r"C:\Program Files\GDAL"),
        ]
    else:  # Linux
        candidates += [
            Path("/usr/lib"),
            Path("/usr/local/lib"),
        ]

        if is_arm:
            candidates.append(Path("/usr/lib/aarch64-linux-gnu"))
        else:
            candidates.append(Path("/usr/lib/x86_64-linux-gnu"))

    gdal_candidates: list[Path] = []
    geos_candidates: list[Path] = []

    for base in candidates:
        if not base.exists():
            continue

        if sys.platform == "win32":
            gdal_candidates += list(base.glob("gdal*.dll"))
            geos_candidates += list(base.glob("geos_c.dll"))
        elif sys.platform == "darwin":
            gdal_candidates += list(base.glob("libgdal*.dylib"))
            geos_candidates += list(base.glob("libgeos_c*.dylib"))
        else:  # Linux
            gdal_candidates += list(base.glob("libgdal.so*"))
            geos_candidates += list(base.glob("libgeos_c.so*"))

    # Prefer fully versioned libraries, avoid unversioned symlinks
    gdal_candidates.sort(key=lambda p: (p.name.count("."), p.name), reverse=True)
    geos_candidates.sort(key=lambda p: (p.name.count("."), p.name), reverse=True)

    gdal_lib = str(gdal_candidates[0]) if gdal_candidates else None
    geos_lib = str(geos_candidates[0]) if geos_candidates else None

    if not gdal_lib or not geos_lib:
        raise RuntimeError(
            "GDAL/GEOS libraries could not be detected automatically.\n"
            f"GDAL found: {gdal_lib}\n"
            f"GEOS found: {geos_lib}\n"
            "Please set GDAL_LIBRARY_PATH and GEOS_LIBRARY_PATH explicitly."
        )

    return gdal_lib, geos_lib
