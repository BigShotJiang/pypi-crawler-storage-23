import logging
import os
import uuid
from typing import Optional

import numpy as np
from numpy.typing import NDArray
from PIL import Image, ImageColor
from rio_tiler.io import COGReader

from dimitra_core.logging import init_logging

_logger = logging.getLogger(__name__)
_cog_reader: Optional[COGReader] = None
_output_dir: Optional[str] = None
_colors: Optional[dict[int, tuple[int, ...]]] = None


def init_visualize_worker(tif_path: str, output_dir: str, colors: dict[int, str]) -> None:
    """Initialize a worker process for generating visualization tiles.

    This function is called once per worker process in the multiprocessing pool to set up
    the shared resources needed for tile generation. It creates a COGReader instance for
    the input GeoTIFF file, sets up the output directory, converts hex color codes to RGB
    tuples, and initializes logging for the worker.

    The function sets GDAL_NUM_THREADS to "1" to prevent each worker from spawning
    additional threads, which would cause thread contention when multiple workers run
    in parallel.

    Args:
        tif_path: Path to the input GeoTIFF file to be visualized.
        output_dir: Directory path where generated WEBP tile images will be saved.
        colors: Dictionary mapping raster pixel values (int) to hex color codes (str).
    """
    global _cog_reader, _output_dir, _colors, _logger
    os.environ["GDAL_NUM_THREADS"] = "1"

    _cog_reader = COGReader(tif_path)
    _output_dir = output_dir
    _colors = {}

    for val, hex_color in colors.items():
        _colors[val] = ImageColor.getrgb(hex_color)

    init_logging()

    worker_id = uuid.uuid4()
    _logger = logging.getLogger(f"dimitra-core[raster][visualize][{worker_id}]")


def _apply_colormap(tile_array: NDArray[np.int_]) -> NDArray[np.uint8]:
    """Apply color mapping to a raster tile array to create an RGBA image.

    Converts a single-band raster tile with integer values to a 4-channel RGBA image
    by mapping each unique pixel value to its corresponding RGB color from the global
    color map. Pixels not in the color map remain transparent (alpha = 0).

    Args:
        tile_array: 2D numpy array containing raster pixel values. Shape is (height, width).

    Returns:
        4D numpy array of type uint8 with shape (height, width, 4) representing an RGBA image.
    """
    global _colors

    if _colors is None:
        raise Exception("_colors is None")

    h, w = tile_array.shape
    rgba = np.zeros((h, w, 4), dtype=np.uint8)

    for val, color in _colors.items():
        mask = tile_array == val
        rgba[mask, :3] = color
        rgba[mask, 3] = 255

    return rgba


def visualize_tile(tile_info: tuple[int, int, int]) -> Optional[None]:
    """Generate and save a single XYZ tile as a colorized WEBP image.

    Reads a tile from the GeoTIFF file at the specified XYZ coordinates, applies the
    color map to create an RGBA image, and saves it as a lossless WEBP file. Empty
    tiles (all zeros) are skipped to reduce storage usage.

    Args:
        tile_info: Tuple of (x, y, z) coordinates following the XYZ tile scheme where:
                   - x: Tile column index (west to east)
                   - y: Tile row index (north to south)
                   - z: Zoom level (lower numbers = wider geographic area)

    Note:
        The function saves the generated tile image to disk in the output_dir folder.
    """
    global _cog_reader, _output_dir, _logger

    try:
        if _cog_reader is None:
            raise Exception("_cog_reader is None")
        if _output_dir is None:
            raise Exception("_output_dir is None")
        if _colors is None:
            raise Exception("_colors is None")

        x, y, z = tile_info
        tile, _ = _cog_reader.tile(x, y, z)

        # Skip tiles where no pixel matches any color in the color map
        if not np.isin(tile[0], list(_colors.keys())).any():
            return None

        rgba = _apply_colormap(tile[0])
        img = Image.fromarray(rgba, "RGBA")

        out_dir = os.path.join(_output_dir, str(z), str(x))
        os.makedirs(out_dir, exist_ok=True)

        out_path = os.path.join(out_dir, f"{y}.webp")
        img.save(out_path, format="WEBP", lossless=True)
    except Exception as e:
        _logger.error(f"Error in creating visualization image for tile {tile_info}: {e}")
