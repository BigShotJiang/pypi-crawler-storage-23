import logging
import math
import multiprocessing
import shutil
import subprocess
import tempfile
from typing import TYPE_CHECKING, Callable, Optional

from dimitra_core.raster.constants import (
    DEFAULT_MAX_VISUALIZATION_ZOOM,
    DEFAULT_MIN_VISUALIZATION_ZOOM,
    LARGEST_MAX_VISUALIZATION_ZOOM,
    LARGEST_MIN_VISUALIZATION_ZOOM,
    MAX_WORKERS,
    SMALLEST_MAX_VISUALIZATION_ZOOM,
    SMALLEST_MIN_VISUALIZATION_ZOOM,
    WINDOW_SIZE,
)

if TYPE_CHECKING:
    import numpy as np
    from rasterio import DatasetReader

logger = logging.getLogger("dimitra-core[raster]")


def _optimal_float_dtype(src_dtype: "np.dtype", scale: float, offset: float):
    """Select the most memory-efficient float dtype that can represent all possible scaled values.

    Uses the source dtype's theoretical max/min values (O(1) lookup via np.iinfo) to determine
    the range of possible output values after applying scale and offset.

    Args:
        src_dtype: The numpy dtype of the source raster data.
        scale: Scale factor to be applied to the data.
        offset: Offset to be added after scaling.

    Returns:
        The most efficient numpy float dtype that can represent the full value range.
    """
    import numpy as np

    if not np.issubdtype(src_dtype, np.integer):
        return src_dtype

    info = np.iinfo(src_dtype)
    # Use Python floats to avoid numpy overflow warnings during comparison
    max_abs = float(max(abs(info.max * scale + offset), abs(info.min * scale + offset)))

    # float16: max 65504, 10-bit mantissa (~3 decimal digits precision)
    # Only safe for small integer types (uint8/int8) where all distinct values are representable
    if max_abs <= float(np.finfo(np.float16).max) and src_dtype.itemsize <= 1:
        return np.dtype(np.float16)

    # float32: max ~3.4e38, 23-bit mantissa (~7 decimal digits precision)
    if max_abs <= float(np.finfo(np.float32).max):
        return np.dtype(np.float32)

    return np.dtype(np.float64)


def read_src_data(src: "DatasetReader", band=1, window=None) -> "np.ndarray":
    """Read raster band data with scale and offset metadata applied.

    Reads a single band from the rasterio source and applies the scale and offset
    metadata if present (formula: actual_value = raw_value * scale + offset).
    When scale/offset transform the data, the output dtype is promoted to the most
    memory-efficient float type that can represent the full value range.

    Args:
        src: An open rasterio dataset reader object.
        band: Band number to read (1-indexed). Defaults to 1.
        window: Optional rasterio Window to read a subset of the raster.

    Returns:
        numpy ndarray of the band data with scale/offset applied. Returns the
        original dtype when scale=1.0 and offset=0.0, otherwise returns the
        smallest float dtype that fits the value range.
    """

    nodata = src.nodata
    data = src.read(band, window=window)

    scale: float = src.scales[band - 1]
    offset: float = src.offsets[band - 1]

    # No transformation needed, return raw data in its original dtype
    if scale == 1.0 and offset == 0.0:
        return data

    target_dtype = _optimal_float_dtype(data.dtype, scale, offset)

    scaled = data.astype(target_dtype) * scale + offset
    if nodata is not None:
        nodata_mask = data == nodata  # mask using RAW values
        scaled[nodata_mask] = nodata  # keep nodata unchanged

    return scaled


def windows_generator(src_width: int, src_height: int, window_size=WINDOW_SIZE):
    """Generate rasterio windows for processing large rasters in chunks.

    Args:
        src_width: Width of the source raster in pixels.
        src_height: Height of the source raster in pixels.
        window_size: Size of each window in pixels. Defaults to WINDOW_SIZE.

    Yields:
        rasterio.windows.Window: Window object representing a rectangular subset of the raster.
    """
    from rasterio import windows

    num_windows_rows = math.ceil(src_height / window_size)
    num_windows_cols = math.ceil(src_width / window_size)

    for window_row_index in range(num_windows_rows):
        for window_col_index in range(num_windows_cols):
            # Calculate window boundaries
            window_row_start = window_row_index * window_size
            window_row_end = min(window_row_start + window_size, src_height)
            window_col_start = window_col_index * window_size
            window_col_end = min(window_col_start + window_size, src_width)

            # Create rasterio Window object
            window = windows.Window(
                window_col_start,
                window_row_start,
                width=window_col_end - window_col_start,
                height=window_row_end - window_row_start,
            )
            yield window


def crop_raster(boundary_file, input_path, output_path, nodata=0, compress="PACKBITS"):
    """Crop a raster using a vector boundary and save the result.

    Uses GDAL's gdalwarp command to clip the input raster to the boundary geometry
    and save it as a GeoTIFF with optional compression.

    Args:
        boundary_file: Path to a GeoJSON file containing the boundary geometry.
        input_path: Path to the input raster file to be cropped.
        output_path: Path where the cropped raster will be saved.
        nodata: NoData value for the destination raster. Defaults to 0.
                Set to None to omit the nodata specification.
        compress: Compression method for the output GeoTIFF. Defaults to "PACKBITS".
                  Supported values: "LZW", "PACKBITS", "DEFLATE".
                  Set to None to omit compression.

    Returns:
        None

    Raises:
        ValueError: If compress has an invalid value (not one of LZW, PACKBITS, DEFLATE, or None).
        Exception: If the gdalwarp command fails with error details from stderr.
    """
    # Validate compress parameter
    valid_compress_values = ["LZW", "PACKBITS", "DEFLATE", None]
    if compress not in valid_compress_values:
        raise ValueError(f"Invalid compress value: {compress}. Must be one of {valid_compress_values}")

    cmd = [
        "gdalwarp",
        "-cutline",
        boundary_file,
        "-crop_to_cutline",
        "-of",
        "GTiff",
        "-multi",
        "-wo",
        "NUM_THREADS=ALL_CPUS",
    ]

    # Add compression only if it's not None
    if compress is not None:
        cmd.extend(["-co", f"COMPRESS={compress}"])

    cmd.extend(["-co", "BIGTIFF=YES"])

    # Add nodata value only if it's not None
    if nodata is not None:
        cmd.extend(["-dstnodata", str(nodata)])

    cmd.extend(["-q", input_path, output_path])

    try:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, check=True)
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.decode("utf-8") if e.stderr else "Unknown error"
        logger.error(f"Error in crop raster: {error_msg}")
        raise Exception(error_msg)


def convert_to_cog(input_path: str, output_path: str) -> None:
    """Convert a TIFF file to Cloud Optimized GeoTIFF (COG) format.

    Uses GDAL's gdal_translate command to convert a standard GeoTIFF to COG format
    while preserving compression, predictor, blocksize, and other important properties.
    The output file will be identical to the input file except in COG format.

    Args:
        input_path: Path to the input TIFF file to be converted.
        output_path: Path where the COG file will be saved.

    Returns:
        None

    Raises:
        Exception: If the gdal_translate command fails with error details from stderr.
    """
    import rasterio

    with rasterio.open(input_path) as src:
        image_structure = src.tags(ns="IMAGE_STRUCTURE")
        block_shapes = src.block_shapes

    cog_options: list[str] = []

    # preserve compression
    compression = image_structure.get("COMPRESSION")
    if compression:
        cog_options += ["-co", f"COMPRESS={compression.upper()}"]

    # preserve predictor if present
    predictor = image_structure.get("PREDICTOR")
    if predictor:
        cog_options += ["-co", f"PREDICTOR={predictor}"]

    # preserve block size
    if block_shapes and block_shapes[0]:
        block_height, block_width = block_shapes[0]
        block_size = min(block_height, block_width)
        cog_options += ["-co", f"BLOCKSIZE={block_size}"]

    # always set BigTIFF
    cog_options += ["-co", "BIGTIFF=YES"]

    # always disable overviews
    cog_options += ["-co", "OVERVIEWS=NONE"]

    cmd = [
        "gdal_translate",
        "-of",
        "COG",
        *cog_options,
        input_path,
        output_path,
    ]

    try:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, check=True)
        logger.info(f"Successfully converted {input_path} to COG format at {output_path}")
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.decode("utf-8") if e.stderr else "Unknown error"
        logger.error(f"Error converting to COG: {error_msg}")
        raise Exception(error_msg)


def _generate_tiles(
    file_path: str,
    tile_output_dir: str,
    colors: dict[int, str],
    tiles_info: list[tuple[int, int, int]],
    max_workers: int,
    progress_update_func: Optional[Callable[[int], None]],
) -> None:
    from dimitra_core.raster.workers.visualize import (
        init_visualize_worker,
        visualize_tile,
    )

    total = len(tiles_info)
    logger.info(f"Using {max_workers} processes")
    logger.info(f"Generating {total} visualization images")
    with multiprocessing.Pool(
        processes=max_workers,
        initializer=init_visualize_worker,
        initargs=(file_path, tile_output_dir, colors),
    ) as pool:
        pool_results = pool.imap_unordered(visualize_tile, tiles_info)

        completed = 0
        last_progress = 0

        for _ in pool_results:
            completed += 1
            if progress_update_func:
                progress = math.floor(completed * 100 / total)
                if progress > last_progress:
                    last_progress = progress
                    progress_update_func(progress)


def visualize_tiff_file(
    file_path: str,
    colors: dict[int, str],
    s3_dir: Optional[str] = None,
    s3_bucket_name: Optional[str] = None,
    output_dir: Optional[str] = None,
    progress_update_func: Optional[Callable[[int], None]] = None,
    max_workers: int = MAX_WORKERS,
    min_visualization_zoom: int = DEFAULT_MIN_VISUALIZATION_ZOOM,
    max_visualization_zoom: int = DEFAULT_MAX_VISUALIZATION_ZOOM,
) -> tuple[int, int]:
    """Generate XYZ visualization tiles from a GeoTIFF file.

    This function creates web-optimized WEBP tiles from a Cloud-Optimized GeoTIFF (COG)
    file following the XYZ tile scheme used by mapping services like Mapbox. The tiles
    are generated for multiple zoom levels, colorized according to the provided color map,
    and either uploaded to an S3 bucket or saved to a local directory.

    The function uses multiprocessing to generate tiles in parallel for improved performance.
    Each tile is colorized based on the input raster values and the provided color mapping,
    then saved as a lossless WEBP image. Empty tiles (all zeros) are skipped to minimize
    storage requirements.

    Either ``s3_dir`` (with ``s3_bucket_name``) or ``output_dir`` must be provided, but
    not both.

    Args:
        file_path: Path to the input GeoTIFF file (preferably Cloud-Optimized GeoTIFF).
        colors: Dictionary mapping raster pixel values (int) to hex color codes (str).
                Example: {1: "#FF0000", 2: "#00FF00"} maps value 1 to red and 2 to green.
        s3_dir: S3 directory path where the tiles will be uploaded. The tiles will be
                organized as {s3_dir}/{z}/{x}/{y}.webp following the XYZ tile convention.
                Mutually exclusive with ``output_dir``.
        s3_bucket_name: Name of the S3 bucket where tiles will be uploaded.
                        Required when ``s3_dir`` is specified.
        output_dir: Local directory path where the tiles will be saved. The tiles will be
                    organized as {output_dir}/{z}/{x}/{y}.webp following the XYZ tile
                    convention. Mutually exclusive with ``s3_dir``.
        progress_update_func: Optional callback function that receives progress updates
                              as an integer percentage (0-100). Called periodically as
                              tiles are generated. Defaults to None.
        max_workers: Maximum number of worker processes to use for parallel tile generation.
                     Defaults to MAX_WORKERS constant. More workers increase performance
                     but consume more memory.
        min_visualization_zoom: Minimum zoom level to generate tiles for (inclusive).
                                Defaults to DEFAULT_MIN_VISUALIZATION_ZOOM constant.
                                Lower zoom levels show larger geographic areas with less detail.
        max_visualization_zoom: Maximum zoom level to generate tiles for (inclusive).
                                Defaults to DEFAULT_MAX_VISUALIZATION_ZOOM constant.
                                Higher zoom levels show smaller areas with more detail.

    Returns:
        tuple of (min_visualization_zoom, max_visualization_zoom) which can be different from the provided values

    Raises:
        ValueError: If both ``s3_dir`` and ``output_dir`` are provided, or if neither is
                    provided, or if ``s3_dir`` is provided without ``s3_bucket_name``.
    """
    if s3_dir and output_dir:
        raise ValueError("Cannot specify both 's3_dir' and 'output_dir'. Use one or the other.")
    if not s3_dir and not output_dir:
        raise ValueError("Must specify either 's3_dir' (with 's3_bucket_name') or 'output_dir'.")
    if s3_dir and not s3_bucket_name:
        raise ValueError("'s3_bucket_name' is required when 's3_dir' is specified.")
    if not (SMALLEST_MIN_VISUALIZATION_ZOOM <= min_visualization_zoom <= LARGEST_MIN_VISUALIZATION_ZOOM):
        raise ValueError(
            f"min_visualization_zoom should be equal to or between {SMALLEST_MIN_VISUALIZATION_ZOOM} and {LARGEST_MIN_VISUALIZATION_ZOOM}"
        )
    if not (SMALLEST_MAX_VISUALIZATION_ZOOM <= max_visualization_zoom <= LARGEST_MAX_VISUALIZATION_ZOOM):
        raise ValueError(
            f"max_visualization_zoom should be equal to or between {SMALLEST_MAX_VISUALIZATION_ZOOM} and {LARGEST_MAX_VISUALIZATION_ZOOM}"
        )

    if max_visualization_zoom <= min_visualization_zoom:
        logger.warning(
            f"max_visualization_zoom of {max_visualization_zoom} is smaller or equal to min_visualization_zoom of {min_visualization_zoom}, setting min_visualization_zoom to {max_visualization_zoom-1}"
        )
        min_visualization_zoom = max_visualization_zoom - 1

    from mercantile import tiles
    from rio_tiler.io import COGReader

    with COGReader(file_path) as cog:
        bounds = cog.bounds

    tiles_info: list[tuple[int, int, int]] = []
    for z in range(min_visualization_zoom, max_visualization_zoom + 1):
        zoom_tiles = tiles(*bounds, zooms=[z])
        for t in zoom_tiles:
            tiles_info.append((t.x, t.y, t.z))

    temp_dir = None
    if not output_dir:
        temp_dir = tempfile.mkdtemp()
        output_dir = temp_dir

    try:
        _generate_tiles(file_path, output_dir, colors, tiles_info, max_workers, progress_update_func)

        if s3_dir:
            from dimitra_core.s3 import upload_directory

            logger.info(f"Uploading visualization images to s3_bucket_name: {s3_bucket_name} s3_dir: {s3_dir}")
            upload_directory(output_dir, s3_dir, bucket_name=s3_bucket_name)
    finally:
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)

    return min_visualization_zoom, max_visualization_zoom


def compute_max_zoom_level_epsg_4326(tiff_path: str) -> int:
    """Compute the maximum zoom level for XYZ tile generation based on pixel size.

    This function dynamically calculates the appropriate maximum zoom level for generating
    XYZ tiles from a GeoTIFF file in EPSG:4326 projection. The zoom level is determined by
    comparing the raster's pixel resolution (converted to meters) with the Web Mercator
    resolution at different zoom levels.

    Args:
        tiff_path: Path to the input GeoTIFF file. Must be in EPSG:4326 projection.

    Returns:
        int: The maximum zoom level appropriate for this raster's resolution.
             Higher values indicate more detailed zoom levels (e.g., zoom 18 is more
             detailed than zoom 10).
    """
    import rasterio

    with rasterio.open(tiff_path) as ds:
        if ds.crs.to_epsg() != 4326:
            raise Exception("GeoTIFF must be in EPSG:4326")

        # Pixel size in degrees
        pixel_width_deg = abs(ds.transform.a)
        pixel_height_deg = abs(ds.transform.e)

        # Raster bounds and center latitude
        bounds = ds.bounds
        center_lat = (bounds.top + bounds.bottom) / 2.0

        # Degrees → meters conversion
        meters_per_deg_lon = 111320 * math.cos(math.radians(center_lat))
        meters_per_deg_lat = 110574

        pixel_size_m = max(pixel_width_deg * meters_per_deg_lon, pixel_height_deg * meters_per_deg_lat)

        # Web Mercator resolution formula
        initial_resolution = 156543.03392  # meters/pixel at z=0

        zmax = math.ceil(math.log2(initial_resolution / pixel_size_m))
        return max(zmax, SMALLEST_MAX_VISUALIZATION_ZOOM)
