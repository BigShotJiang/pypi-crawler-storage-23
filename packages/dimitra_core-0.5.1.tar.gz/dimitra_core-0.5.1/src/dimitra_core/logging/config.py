import logging


def init_logging(log_level: str = "INFO") -> None:
    """Configure logging for dimitra-core and client applications.

    boto3 library logs are automatically suppressed

    Args:
        log_level: Level of logging to be enabled.

    Returns:
        None
    """
    numeric_level = getattr(logging, log_level, logging.INFO)

    logging.basicConfig(level=numeric_level)
    logging.getLogger("botocore").setLevel(logging.WARNING)
