from dimitra_core.logging.config import init_logging

__all__ = ["init_logging"]
