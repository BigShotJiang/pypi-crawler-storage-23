"""Tests for the S3 module."""

from io import BytesIO
from unittest.mock import ANY, MagicMock, patch

import pytest
from botocore.exceptions import ClientError


@pytest.fixture(autouse=True)
def reset_s3_module():
    """Reset S3 module state before each test."""
    from dimitra_core.s3.config import _reset_s3_for_tests

    _reset_s3_for_tests()
    yield
    _reset_s3_for_tests()


@pytest.fixture
def mock_boto3():
    """Create and inject a mock boto3 module."""
    mock_boto3 = MagicMock()
    mock_client = MagicMock()
    mock_boto3.client.return_value = mock_client
    mock_boto3.session.Config = MagicMock

    with patch.dict("sys.modules", {"boto3": mock_boto3}):
        yield mock_boto3, mock_client


class TestS3Initialization:
    """Test S3 module initialization."""

    def test_init_s3_success(self, mock_boto3):
        """Test successful S3 initialization."""
        mock_boto3_module, mock_client = mock_boto3

        from dimitra_core.s3.config import init_s3

        init_s3(default_bucket_name="test-bucket", default_region_name="us-west-2")

        # Verify boto3.client was called with correct arguments
        mock_boto3_module.client.assert_called_once_with("s3", region_name="us-west-2", config=ANY)

    def test_init_s3_already_initialized(self, mock_boto3):
        """Test that re-initializing raises RuntimeError."""
        mock_boto3_module, mock_client = mock_boto3

        from dimitra_core.s3.config import init_s3

        init_s3(default_bucket_name="test-bucket", default_region_name="us-west-2")

        with pytest.raises(RuntimeError, match="already initialized"):
            init_s3(default_bucket_name="test-bucket", default_region_name="us-west-2")

    def test_init_s3_missing_boto3(self):
        """Test initialization fails gracefully when boto3 is not installed."""
        # Ensure boto3 is not in sys.modules
        with patch.dict("sys.modules", {"boto3": None}):
            from dimitra_core.s3.config import init_s3

            with pytest.raises(ImportError, match="install dimitra-core\\[s3\\]"):
                init_s3(default_bucket_name="test-bucket", default_region_name="us-west-2")

    def test_get_s3_config_not_initialized(self):
        """Test that accessing config before initialization raises RuntimeError."""
        from dimitra_core.s3.config import get_s3_config

        with pytest.raises(RuntimeError, match="needs to be initialized"):
            get_s3_config()


class TestUploadFile:
    """Test upload_file function."""

    @pytest.fixture
    def initialized_s3(self, mock_boto3):
        """Initialize S3 module before tests."""
        mock_boto3_module, mock_client = mock_boto3

        from dimitra_core.s3.config import init_s3

        init_s3(default_bucket_name="test-bucket", default_region_name="us-west-2")
        yield mock_client

    def test_upload_file_with_default_bucket(self, initialized_s3):
        """Test uploading a file using default bucket."""
        from dimitra_core.s3.utils import upload_file

        upload_file(file_path="/path/to/file.txt", s3_key="uploads/file.txt")

        initialized_s3.upload_file.assert_called_once_with("/path/to/file.txt", "test-bucket", "uploads/file.txt")

    def test_upload_file_with_custom_bucket(self, initialized_s3):
        """Test uploading a file to a custom bucket."""
        from dimitra_core.s3.utils import upload_file

        upload_file(file_path="/path/to/file.txt", s3_key="uploads/file.txt", bucket_name="custom-bucket")

        initialized_s3.upload_file.assert_called_once_with("/path/to/file.txt", "custom-bucket", "uploads/file.txt")


class TestDeleteFile:
    """Test delete_file function."""

    @pytest.fixture
    def initialized_s3(self, mock_boto3):
        """Initialize S3 module before tests."""
        mock_boto3_module, mock_client = mock_boto3

        from dimitra_core.s3.config import init_s3

        init_s3(default_bucket_name="test-bucket", default_region_name="us-west-2")
        yield mock_client

    def test_delete_file_with_default_bucket(self, initialized_s3):
        """Test deleting a file using default bucket."""
        from dimitra_core.s3.utils import delete_file

        delete_file(s3_key="uploads/file.txt")

        initialized_s3.delete_object.assert_called_once_with(Bucket="test-bucket", Key="uploads/file.txt")

    def test_delete_file_with_custom_bucket(self, initialized_s3):
        """Test deleting a file from a custom bucket."""
        from dimitra_core.s3.utils import delete_file

        delete_file(s3_key="uploads/file.txt", bucket_name="custom-bucket")

        initialized_s3.delete_object.assert_called_once_with(Bucket="custom-bucket", Key="uploads/file.txt")


class TestUploadBytes:
    """Test upload_bytes function."""

    @pytest.fixture
    def initialized_s3(self, mock_boto3):
        """Initialize S3 module before tests."""
        mock_boto3_module, mock_client = mock_boto3

        from dimitra_core.s3.config import init_s3

        init_s3(default_bucket_name="test-bucket", default_region_name="us-west-2")
        yield mock_client

    def test_upload_bytes_success(self, initialized_s3):
        """Test uploading bytes to S3."""
        from dimitra_core.s3.utils import upload_bytes

        file_obj = BytesIO(b"test content")
        upload_bytes(bytes=file_obj, s3_key="uploads/data.bin", content_type="application/octet-stream")

        initialized_s3.upload_fileobj.assert_called_once()
        call_args = initialized_s3.upload_fileobj.call_args
        assert call_args[0][1] == "test-bucket"
        assert call_args[0][2] == "uploads/data.bin"
        assert call_args[1]["ExtraArgs"]["ContentType"] == "application/octet-stream"


class TestDownloadFile:
    """Test download_file function."""

    @pytest.fixture
    def initialized_s3(self, mock_boto3):
        """Initialize S3 module before tests."""
        mock_boto3_module, mock_client = mock_boto3

        from dimitra_core.s3.config import init_s3

        init_s3(default_bucket_name="test-bucket", default_region_name="us-west-2")
        yield mock_client

    def test_download_file_with_default_bucket(self, initialized_s3):
        """Test downloading a file using default bucket."""
        from dimitra_core.s3.utils import download_file

        download_file(s3_key="uploads/file.txt", file_path="/tmp/downloaded.txt")

        initialized_s3.download_file.assert_called_once_with("test-bucket", "uploads/file.txt", "/tmp/downloaded.txt")

    def test_download_file_with_custom_bucket(self, initialized_s3):
        """Test downloading a file from a custom bucket."""
        from dimitra_core.s3.utils import download_file

        download_file(s3_key="uploads/file.txt", file_path="/tmp/downloaded.txt", bucket_name="custom-bucket")

        initialized_s3.download_file.assert_called_once_with("custom-bucket", "uploads/file.txt", "/tmp/downloaded.txt")


class TestUploadDirectory:
    """Test upload_directory function."""

    @pytest.fixture
    def initialized_s3(self, mock_boto3):
        """Initialize S3 module before tests."""
        mock_boto3_module, mock_client = mock_boto3

        from dimitra_core.s3.config import init_s3

        init_s3(default_bucket_name="test-bucket", default_region_name="us-west-2")
        yield mock_client

    def test_upload_directory_success(self, initialized_s3, tmp_path):
        """Test uploading a directory with multiple files."""
        # Create test directory structure
        test_dir = tmp_path / "test_upload"
        test_dir.mkdir()
        (test_dir / "file1.txt").write_text("content1")
        (test_dir / "file2.txt").write_text("content2")
        subdir = test_dir / "subdir"
        subdir.mkdir()
        (subdir / "file3.txt").write_text("content3")

        from dimitra_core.s3.utils import upload_directory

        upload_directory(dir_path=str(test_dir), dir_s3_key="uploads/mydir")

        # Should upload 3 files
        assert initialized_s3.upload_file.call_count == 3


class TestGetPresignedUrl:
    """Test get_presigned_url function."""

    @pytest.fixture
    def initialized_s3(self, mock_boto3):
        """Initialize S3 module before tests."""
        mock_boto3_module, mock_client = mock_boto3

        from dimitra_core.s3.config import init_s3

        init_s3(default_bucket_name="test-bucket", default_region_name="us-west-2")
        yield mock_client

    def test_get_presigned_url_success(self, initialized_s3):
        """Test generating a presigned URL."""
        initialized_s3.generate_presigned_url.return_value = "https://test-url.com"

        from dimitra_core.s3.utils import get_presigned_url

        url = get_presigned_url(s3_key="uploads/file.txt")

        assert url == "https://test-url.com"
        initialized_s3.generate_presigned_url.assert_called_once()
        call_args = initialized_s3.generate_presigned_url.call_args
        assert call_args[0][0] == "get_object"
        assert call_args[1]["Params"]["Bucket"] == "test-bucket"
        assert call_args[1]["Params"]["Key"] == "uploads/file.txt"

    def test_get_presigned_url_empty_key(self, initialized_s3):
        """Test that empty s3_key returns None."""
        from dimitra_core.s3.utils import get_presigned_url

        url = get_presigned_url(s3_key="")

        assert url is None
        initialized_s3.generate_presigned_url.assert_not_called()


class TestPutPresignedUrl:
    """Test put_presigned_url function."""

    @pytest.fixture
    def initialized_s3(self, mock_boto3):
        """Initialize S3 module before tests."""
        mock_boto3_module, mock_client = mock_boto3

        from dimitra_core.s3.config import init_s3

        init_s3(default_bucket_name="test-bucket", default_region_name="us-west-2")
        yield mock_client

    def test_put_presigned_url_success(self, initialized_s3):
        """Test generating a presigned URL for uploading."""
        initialized_s3.generate_presigned_url.return_value = "https://upload-url.com"

        from dimitra_core.s3.utils import put_presigned_url

        url = put_presigned_url(s3_key="uploads/file.txt", file_type="text/plain")

        assert url == "https://upload-url.com"
        call_args = initialized_s3.generate_presigned_url.call_args
        assert call_args[0][0] == "put_object"
        assert call_args[1]["Params"]["ContentType"] == "text/plain"

    def test_put_presigned_url_empty_key(self, initialized_s3):
        """Test that empty s3_key returns None."""
        from dimitra_core.s3.utils import put_presigned_url

        url = put_presigned_url(s3_key="", file_type="text/plain")

        assert url is None


class TestKeyExists:
    """Test s3_key_exists function."""

    @pytest.fixture
    def initialized_s3(self, mock_boto3):
        """Initialize S3 module before tests."""
        mock_boto3_module, mock_client = mock_boto3

        from dimitra_core.s3.config import init_s3

        init_s3(default_bucket_name="test-bucket", default_region_name="us-west-2")
        yield mock_client

    def test_s3_key_exists_returns_true(self, initialized_s3):
        """Test that existing key returns True."""
        initialized_s3.head_object.return_value = {"ContentLength": 1024}

        from dimitra_core.s3.utils import s3_key_exists

        result = s3_key_exists(s3_key="uploads/file.txt")

        assert result is True
        initialized_s3.head_object.assert_called_once_with(Bucket="test-bucket", Key="uploads/file.txt")

    def test_s3_key_exists_returns_false_when_not_found(self, initialized_s3):
        """Test that non-existent key returns False."""
        initialized_s3.head_object.side_effect = ClientError(
            {"Error": {"Code": "404", "Message": "Not Found"}}, "HeadObject"
        )

        from dimitra_core.s3.utils import s3_key_exists

        result = s3_key_exists(s3_key="uploads/nonexistent.txt")

        assert result is False

    def test_s3_key_exists_raises_on_other_errors(self, initialized_s3):
        """Test that non-404 errors are re-raised."""
        initialized_s3.head_object.side_effect = ClientError(
            {"Error": {"Code": "403", "Message": "Forbidden"}}, "HeadObject"
        )

        from dimitra_core.s3.utils import s3_key_exists

        with pytest.raises(ClientError):
            s3_key_exists(s3_key="uploads/file.txt")


class TestGetFileSize:
    """Test get_file_size function."""

    @pytest.fixture
    def initialized_s3(self, mock_boto3):
        """Initialize S3 module before tests."""
        mock_boto3_module, mock_client = mock_boto3

        from dimitra_core.s3.config import init_s3

        init_s3(default_bucket_name="test-bucket", default_region_name="us-west-2")
        yield mock_client

    def test_get_file_size_success(self, initialized_s3):
        """Test getting file size successfully."""
        initialized_s3.head_object.return_value = {"ContentLength": 1024}

        from dimitra_core.s3.utils import get_file_size

        size = get_file_size(s3_key="uploads/file.txt")

        assert size == 1024
        initialized_s3.head_object.assert_called_once_with(Bucket="test-bucket", Key="uploads/file.txt")

    def test_get_file_size_file_not_found(self, initialized_s3):
        """Test getting size of non-existent file returns None."""
        initialized_s3.head_object.side_effect = ClientError(
            {"Error": {"Code": "404", "Message": "Not Found"}}, "HeadObject"
        )

        from dimitra_core.s3.utils import get_file_size

        size = get_file_size(s3_key="uploads/nonexistent.txt")

        assert size is None
