"""Tests for the GEE module."""

from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture(autouse=True)
def reset_gee_module():
    """Reset GEE module state before each test."""
    from dimitra_core.gee.config import _reset_gee_for_tests

    _reset_gee_for_tests()
    yield
    _reset_gee_for_tests()


@pytest.fixture
def mock_gee_dependencies():
    """Create and inject mock ee, google.cloud.storage, and google.oauth2 modules."""
    mock_ee = MagicMock()
    mock_storage = MagicMock()
    mock_oauth2 = MagicMock()
    mock_credentials_class = MagicMock()
    mock_credentials = MagicMock()
    mock_storage_client = MagicMock()

    # Setup mock behavior
    mock_credentials_class.from_service_account_file.return_value = mock_credentials
    mock_oauth2.service_account.Credentials = mock_credentials_class
    mock_storage.Client.from_service_account_json.return_value = mock_storage_client

    with patch.dict(
        "sys.modules",
        {
            "ee": mock_ee,
            "google.cloud": MagicMock(storage=mock_storage),
            "google.cloud.storage": mock_storage,
            "google.oauth2": mock_oauth2,
            "google.oauth2.service_account": mock_oauth2.service_account,
        },
    ):
        yield mock_ee, mock_storage, mock_credentials_class, mock_storage_client


class TestGEEInitialization:
    """Test GEE module initialization."""

    def test_init_gee_success(self, mock_gee_dependencies):
        """Test successful GEE initialization."""
        mock_ee, mock_storage, mock_credentials_class, mock_storage_client = mock_gee_dependencies

        from dimitra_core.gee.config import init_gee

        init_gee(
            service_account_file_path="/path/to/service-account.json",
            gcs_bucket_name="test-gcs-bucket",
        )

        # Verify credentials were created
        mock_credentials_class.from_service_account_file.assert_called_once()
        # Verify EE was initialized
        mock_ee.Initialize.assert_called_once()
        # Verify storage client was created
        mock_storage.Client.from_service_account_json.assert_called_once_with("/path/to/service-account.json")

    def test_init_gee_already_initialized(self, mock_gee_dependencies):
        """Test that re-initializing raises RuntimeError."""
        mock_ee, mock_storage, mock_credentials_class, mock_storage_client = mock_gee_dependencies

        from dimitra_core.gee.config import init_gee

        init_gee(
            service_account_file_path="/path/to/service-account.json",
            gcs_bucket_name="test-gcs-bucket",
        )

        with pytest.raises(RuntimeError, match="already initialized"):
            init_gee(
                service_account_file_path="/path/to/service-account.json",
                gcs_bucket_name="test-gcs-bucket",
            )

    def test_init_gee_missing_dependencies(self):
        """Test initialization fails gracefully when dependencies are not installed."""
        with patch.dict("sys.modules", {"ee": None, "google.cloud": None, "google.oauth2": None}):
            from dimitra_core.gee.config import init_gee

            with pytest.raises(ImportError, match="install dimitra-core\\[gee\\]"):
                init_gee(
                    service_account_file_path="/path/to/service-account.json",
                    gcs_bucket_name="test-gcs-bucket",
                )

    def test_get_gee_config_not_initialized(self):
        """Test that accessing config before initialization raises RuntimeError."""
        from dimitra_core.gee.config import get_gee_config

        with pytest.raises(RuntimeError, match="needs to be initialized"):
            get_gee_config()


class TestGetFaoGaulTable:
    """Test get_fao_gaul_table function."""

    @pytest.fixture
    def mock_ee_module(self):
        """Create a mock ee module for testing."""
        with patch("dimitra_core.gee.utils.ee") as mock_ee:
            yield mock_ee

    def test_get_fao_gaul_table_country_level(self, mock_ee_module):
        """Test getting FAO GAUL table for entire country (level 0)."""
        from dimitra_core.gee.utils import get_fao_gaul_table

        # Setup mocks
        mock_feature_collection = MagicMock()
        mock_filtered_collection = MagicMock()
        mock_filtered_collection.aggregate_array.return_value.distinct.return_value.getInfo.return_value = [250]

        mock_ee_module.FeatureCollection.return_value = mock_feature_collection
        mock_feature_collection.filter.return_value = mock_filtered_collection
        mock_ee_module.Filter.eq.return_value = "filter_expression"

        result = get_fao_gaul_table(country_code=250, state_codes=[])

        # Verify correct dataset was used (level 0)
        mock_ee_module.FeatureCollection.assert_called_once_with("projects/sat-io/open-datasets/FAO/GAUL/GAUL_2024_L0")
        # Verify filter was applied
        mock_ee_module.Filter.eq.assert_called_once_with("gaul0_code", 250)
        # Should return level 0 collection
        assert result == mock_filtered_collection

    def test_get_fao_gaul_table_state_level(self, mock_ee_module):
        """Test getting FAO GAUL table for specific states (level 1)."""
        from dimitra_core.gee.utils import get_fao_gaul_table

        # Setup mocks
        mock_feature_collection = MagicMock()
        mock_level0_collection = MagicMock()
        mock_level1_collection = MagicMock()

        # Mock country filter - aggregate_array for level0
        mock_level0_collection.aggregate_array.return_value.distinct.return_value.getInfo.return_value = [250]
        # Mock state filter - aggregate_array for level1
        mock_level1_collection.aggregate_array.return_value.distinct.return_value.getInfo.return_value = [5001, 5002]

        mock_ee_module.FeatureCollection.return_value = mock_feature_collection
        # First filter call (on feature collection) returns level0, second filter call (on level0) returns level1
        mock_feature_collection.filter.return_value = mock_level0_collection
        mock_level0_collection.filter.return_value = mock_level1_collection
        mock_ee_module.Filter.eq.return_value = "eq_filter"
        mock_ee_module.Filter.inList.return_value = "inList_filter"

        result = get_fao_gaul_table(country_code=250, state_codes=[5001, 5002])

        # Verify correct dataset was used (level 1)
        mock_ee_module.FeatureCollection.assert_called_once_with("projects/sat-io/open-datasets/FAO/GAUL/GAUL_2024_L1")
        # Verify state filter was applied
        mock_ee_module.Filter.inList.assert_called_once_with("gaul1_code", [5001, 5002])
        # Should return level 1 collection
        assert result == mock_level1_collection

    def test_get_fao_gaul_table_invalid_country(self, mock_ee_module):
        """Test exception is raised for invalid country code."""
        from dimitra_core.gee.utils import get_fao_gaul_table

        mock_feature_collection = MagicMock()
        mock_filtered_collection = MagicMock()
        # Return different country code than requested
        mock_filtered_collection.aggregate_array.return_value.distinct.return_value.getInfo.return_value = [999]

        mock_ee_module.FeatureCollection.return_value = mock_feature_collection
        mock_feature_collection.filter.return_value = mock_filtered_collection
        mock_ee_module.Filter.eq.return_value = "filter_expression"

        with pytest.raises(Exception, match="Unable to find correct FAO GAUL country"):
            get_fao_gaul_table(country_code=250, state_codes=[])

    def test_get_fao_gaul_table_invalid_states(self, mock_ee_module):
        """Test exception is raised when some state codes don't match."""
        from dimitra_core.gee.utils import get_fao_gaul_table

        mock_feature_collection = MagicMock()
        mock_level0_collection = MagicMock()
        mock_level1_collection = MagicMock()

        mock_level0_collection.aggregate_array.return_value.distinct.return_value.getInfo.return_value = [250]
        # Return only one state code instead of two
        mock_level1_collection.aggregate_array.return_value.distinct.return_value.getInfo.return_value = [5001]

        mock_ee_module.FeatureCollection.return_value = mock_feature_collection
        mock_feature_collection.filter.side_effect = [mock_level0_collection, mock_level1_collection]
        mock_ee_module.Filter.eq.return_value = "eq_filter"
        mock_ee_module.Filter.inList.return_value = "inList_filter"

        with pytest.raises(Exception, match="Some FAO GAUL states are not filtered correctly"):
            get_fao_gaul_table(country_code=250, state_codes=[5001, 5002])


class TestGetFaoGaulTableCodes:
    """Test get_fao_gaul_table_codes function."""

    def test_get_fao_gaul_table_codes_returns_country_and_state_codes(self):
        """Test that get_fao_gaul_table_codes returns distinct country and state codes as Python lists."""
        from dimitra_core.gee.utils import get_fao_gaul_table_codes

        mock_fao_gaul_table = MagicMock()

        # aggregate_array("gaul0_code").distinct().getInfo() -> [250]
        # aggregate_array("gaul1_code").distinct().getInfo() -> [5001, 5002]
        def aggregate_array_side_effect(field_name):
            mock_agg = MagicMock()
            if field_name == "gaul0_code":
                mock_agg.distinct.return_value.getInfo.return_value = [250]
            elif field_name == "gaul1_code":
                mock_agg.distinct.return_value.getInfo.return_value = [5001, 5002]
            return mock_agg

        mock_fao_gaul_table.aggregate_array.side_effect = aggregate_array_side_effect

        country_codes, state_codes = get_fao_gaul_table_codes(mock_fao_gaul_table)

        assert country_codes == [250]
        assert state_codes == [5001, 5002]
        # Verify correct fields were queried
        mock_fao_gaul_table.aggregate_array.assert_any_call("gaul0_code")
        mock_fao_gaul_table.aggregate_array.assert_any_call("gaul1_code")


class TestWaitForGeeTask:
    """Test wait_for_gee_task function."""

    @pytest.fixture
    def mock_task(self):
        """Create a mock GEE Task."""
        task = MagicMock()
        return task

    def test_wait_for_gee_task_completed(self, mock_task):
        """Test waiting for a task that completes successfully."""
        from dimitra_core.gee.utils import wait_for_gee_task

        mock_task.status.return_value = {"state": "COMPLETED"}
        mock_task.State.COMPLETED = "COMPLETED"
        mock_task.State.FAILED = "FAILED"
        mock_task.State.CANCELLED = "CANCELLED"

        state = wait_for_gee_task(mock_task, poll_interval=0.1, timeout=1)

        assert state == "COMPLETED"
        mock_task.status.assert_called()

    def test_wait_for_gee_task_failed(self, mock_task):
        """Test waiting for a task that fails."""
        from dimitra_core.gee.utils import wait_for_gee_task

        mock_task.status.return_value = {"state": "FAILED"}
        mock_task.State.COMPLETED = "COMPLETED"
        mock_task.State.FAILED = "FAILED"
        mock_task.State.CANCELLED = "CANCELLED"

        state = wait_for_gee_task(mock_task, poll_interval=0.1, timeout=1)

        assert state == "FAILED"

    def test_wait_for_gee_task_cancelled(self, mock_task):
        """Test waiting for a task that is cancelled."""
        from dimitra_core.gee.utils import wait_for_gee_task

        mock_task.status.return_value = {"state": "CANCELLED"}
        mock_task.State.COMPLETED = "COMPLETED"
        mock_task.State.FAILED = "FAILED"
        mock_task.State.CANCELLED = "CANCELLED"

        state = wait_for_gee_task(mock_task, poll_interval=0.1, timeout=1)

        assert state == "CANCELLED"

    def test_wait_for_gee_task_timeout(self, mock_task):
        """Test that timeout raises TimeoutError."""
        from dimitra_core.gee.utils import wait_for_gee_task

        # Always return RUNNING status
        mock_task.status.return_value = {"state": "RUNNING"}
        mock_task.State.COMPLETED = "COMPLETED"
        mock_task.State.FAILED = "FAILED"
        mock_task.State.CANCELLED = "CANCELLED"

        with pytest.raises(TimeoutError, match="GEE Task timed out"):
            wait_for_gee_task(mock_task, poll_interval=0.1, timeout=0.5)


class TestDownloadGeeExport:
    """Test download_gee_export function."""

    @pytest.fixture
    def initialized_gee(self, mock_gee_dependencies):
        """Initialize GEE module before tests."""
        mock_ee, mock_storage, mock_credentials_class, mock_storage_client = mock_gee_dependencies

        from dimitra_core.gee.config import init_gee

        init_gee(
            service_account_file_path="/path/to/service-account.json",
            gcs_bucket_name="test-gcs-bucket",
        )
        yield mock_storage_client

    def test_download_single_file(self, initialized_gee):
        """Test downloading a single file (no tiles)."""
        from dimitra_core.gee.utils import download_gee_export

        # Setup mocks
        mock_bucket = MagicMock()
        mock_blob = MagicMock()
        mock_blob.exists.return_value = True

        initialized_gee.bucket.return_value = mock_bucket
        mock_bucket.blob.return_value = mock_blob

        download_gee_export(file_name_prefix="export_file", output_file="/tmp/output.tif", file_suffix=".tif")

        # Verify blob was downloaded
        mock_blob.download_to_filename.assert_called_once_with("/tmp/output.tif")
        # Verify list_blobs was not called (no tiling)
        mock_bucket.list_blobs.assert_not_called()

    def test_download_no_matching_files(self, initialized_gee):
        """Test exception when no files found in GCS."""
        from dimitra_core.gee.utils import download_gee_export

        mock_bucket = MagicMock()
        mock_blob = MagicMock()
        mock_blob.exists.return_value = False
        mock_bucket.list_blobs.return_value = []

        initialized_gee.bucket.return_value = mock_bucket
        mock_bucket.blob.return_value = mock_blob

        with pytest.raises(Exception, match="No matching files found"):
            download_gee_export(file_name_prefix="nonexistent", output_file="/tmp/output.tif", file_suffix=".tif")

    @patch("dimitra_core.gee.utils._merge_split_export_tiles")
    def test_download_multiple_tiles(self, mock_merge, initialized_gee):
        """Test downloading and merging multiple tiles."""
        from dimitra_core.gee.utils import download_gee_export

        # Setup mocks
        mock_bucket = MagicMock()
        mock_blob = MagicMock()
        mock_blob.exists.return_value = False

        mock_tile1 = MagicMock()
        mock_tile1.name = "export_file-0000000000-0000000000.tif"
        mock_tile2 = MagicMock()
        mock_tile2.name = "export_file-0000000001-0000000000.tif"

        mock_bucket.list_blobs.return_value = [mock_tile1, mock_tile2]
        initialized_gee.bucket.return_value = mock_bucket
        mock_bucket.blob.return_value = mock_blob

        with patch("tempfile.TemporaryDirectory") as mock_tmpdir:
            mock_tmpdir.return_value.__enter__.return_value = "/tmp/test_dir"

            download_gee_export(file_name_prefix="export_file", output_file="/tmp/output.tif", file_suffix=".tif")

            # Verify tiles were downloaded
            assert mock_tile1.download_to_filename.called
            assert mock_tile2.download_to_filename.called
            # Verify merge was called
            mock_merge.assert_called_once()
