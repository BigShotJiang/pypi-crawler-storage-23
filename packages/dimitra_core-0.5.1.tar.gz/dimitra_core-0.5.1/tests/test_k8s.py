"""Tests for the K8s module."""

from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture(autouse=True)
def reset_k8s_module():
    """Reset K8s module state before each test."""
    from dimitra_core.k8s.config import _reset_k8s_for_tests

    _reset_k8s_for_tests()
    yield
    _reset_k8s_for_tests()


@pytest.fixture
def mock_k8s_dependencies():
    """Create and inject mock kubernetes module."""
    mock_kubernetes = MagicMock()
    mock_client = MagicMock()
    mock_config = MagicMock()

    # Setup BatchV1Api and CoreV1Api
    mock_batch_v1 = MagicMock()
    mock_core_v1 = MagicMock()
    mock_client.BatchV1Api.return_value = mock_batch_v1
    mock_client.CoreV1Api.return_value = mock_core_v1

    mock_kubernetes.client = mock_client
    mock_kubernetes.config = mock_config

    # Create a proper ApiException class that inherits from Exception
    class ApiException(Exception):
        def __init__(self, status=None, reason=None):
            self.status = status
            self.reason = reason
            super().__init__(reason)

    mock_exceptions = MagicMock()
    mock_exceptions.ApiException = ApiException

    with patch.dict(
        "sys.modules",
        {
            "kubernetes": mock_kubernetes,
            "kubernetes.client": mock_client,
            "kubernetes.client.exceptions": mock_exceptions,
            "kubernetes.config": mock_config,
        },
    ):
        yield mock_kubernetes, mock_batch_v1, mock_core_v1


class TestK8sInitialization:
    """Test K8s module initialization."""

    def test_init_k8s_success(self, mock_k8s_dependencies):
        """Test successful K8s initialization."""
        mock_kubernetes, mock_batch_v1, mock_core_v1 = mock_k8s_dependencies

        from dimitra_core.k8s.config import init_k8s

        init_k8s(kubernetes_namespace="test-namespace")

        # Verify no exceptions raised and module initialized
        from dimitra_core.k8s.config import get_k8s_config

        config = get_k8s_config()
        assert config.kubernetes_namespace == "test-namespace"

    def test_init_k8s_already_initialized(self, mock_k8s_dependencies):
        """Test that re-initializing raises RuntimeError."""
        mock_kubernetes, mock_batch_v1, mock_core_v1 = mock_k8s_dependencies

        from dimitra_core.k8s.config import init_k8s

        init_k8s(kubernetes_namespace="test-namespace")

        with pytest.raises(RuntimeError, match="already initialized"):
            init_k8s(kubernetes_namespace="test-namespace")

    def test_init_k8s_missing_dependencies(self):
        """Test initialization fails gracefully when dependencies are not installed."""
        with patch.dict("sys.modules", {"kubernetes": None}):
            from dimitra_core.k8s.config import init_k8s

            with pytest.raises(ImportError, match="install dimitra-core\\[k8s\\]"):
                init_k8s(kubernetes_namespace="test-namespace")

    def test_get_k8s_config_not_initialized(self):
        """Test that accessing config before initialization raises RuntimeError."""
        from dimitra_core.k8s.config import get_k8s_config

        with pytest.raises(RuntimeError, match="needs to be initialized"):
            get_k8s_config()


class TestStopTask:
    """Test stop_task function."""

    @pytest.fixture
    def initialized_k8s_with_mocked_client(self, mock_k8s_dependencies):
        """Initialize K8s and mock the client APIs."""
        from dimitra_core.k8s.config import init_k8s

        init_k8s(kubernetes_namespace="test-namespace")

        with patch("dimitra_core.k8s.utils.client") as mock_client:
            mock_batch_v1 = MagicMock()
            mock_core_v1 = MagicMock()
            mock_client.BatchV1Api.return_value = mock_batch_v1
            mock_client.CoreV1Api.return_value = mock_core_v1
            mock_client.V1DeleteOptions = MagicMock
            yield mock_batch_v1, mock_core_v1

    def test_stop_task_success(self, initialized_k8s_with_mocked_client):
        """Successfully stop a job."""
        mock_batch_v1, mock_core_v1 = initialized_k8s_with_mocked_client
        mock_response = MagicMock()
        mock_batch_v1.delete_namespaced_job.return_value = mock_response

        from dimitra_core.k8s.utils import stop_task

        result = stop_task("test-job")

        assert result == mock_response
        mock_batch_v1.delete_namespaced_job.assert_called_once()
        call_args = mock_batch_v1.delete_namespaced_job.call_args
        assert call_args[1]["name"] == "test-job"
        assert call_args[1]["namespace"] == "test-namespace"

    def test_stop_task_calls_delete_correctly(self, initialized_k8s_with_mocked_client):
        """Verify delete called with correct parameters."""
        mock_batch_v1, mock_core_v1 = initialized_k8s_with_mocked_client
        mock_response = MagicMock()
        mock_batch_v1.delete_namespaced_job.return_value = mock_response

        from dimitra_core.k8s.utils import stop_task

        stop_task("my-job")

        # Verify call parameters
        call_args = mock_batch_v1.delete_namespaced_job.call_args
        assert call_args[1]["name"] == "my-job"
        assert call_args[1]["namespace"] == "test-namespace"
        # Verify delete options
        delete_options = call_args[1]["body"]
        assert delete_options.grace_period_seconds == 0
        assert delete_options.propagation_policy == "Background"


class TestGetJobStatus:
    """Test get_job_status function."""

    @pytest.fixture
    def initialized_k8s_with_mocked_client(self, mock_k8s_dependencies):
        """Initialize K8s and mock the client APIs."""
        from dimitra_core.k8s.config import init_k8s

        init_k8s(kubernetes_namespace="test-namespace")

        with patch("dimitra_core.k8s.utils.client") as mock_client:
            mock_batch_v1 = MagicMock()
            mock_core_v1 = MagicMock()
            mock_client.BatchV1Api.return_value = mock_batch_v1
            mock_client.CoreV1Api.return_value = mock_core_v1
            yield mock_batch_v1, mock_core_v1

    @pytest.fixture
    def mock_succeeded_job(self):
        """Create a mock succeeded job."""
        job = MagicMock()
        job.status.succeeded = 1
        job.status.failed = None
        job.status.active = None
        job.status.conditions = []
        return job

    @pytest.fixture
    def mock_active_job(self):
        """Create a mock active job."""
        job = MagicMock()
        job.status.succeeded = None
        job.status.failed = None
        job.status.active = 1
        job.status.conditions = []
        return job

    @pytest.fixture
    def mock_failed_job(self):
        """Create a mock failed job."""
        job = MagicMock()
        job.status.succeeded = None
        job.status.failed = 1
        job.status.active = None
        job.status.conditions = []
        return job

    @pytest.fixture
    def mock_failed_pod_oomkilled(self):
        """Create a mock OOMKilled pod."""
        pod = MagicMock()
        pod.metadata.name = "test-job-abc123"
        pod.status.phase = "Failed"

        container_status = MagicMock()
        container_status.state.terminated.reason = "OOMKilled"
        container_status.state.terminated.message = "Container ran out of memory"
        pod.status.container_statuses = [container_status]
        pod.status.conditions = []

        return pod

    @pytest.fixture
    def mock_failed_pod_error(self):
        """Create a mock error pod."""
        pod = MagicMock()
        pod.metadata.name = "test-job-xyz789"
        pod.status.phase = "Failed"

        container_status = MagicMock()
        container_status.state.terminated.reason = "Error"
        container_status.state.terminated.message = "Command failed with exit code 1"
        pod.status.container_statuses = [container_status]
        pod.status.conditions = []

        return pod

    def test_get_job_status_succeeded(self, initialized_k8s_with_mocked_client, mock_succeeded_job):
        """Job exists and succeeded, verify JobStatus object."""
        mock_batch_v1, mock_core_v1 = initialized_k8s_with_mocked_client
        mock_batch_v1.read_namespaced_job.return_value = mock_succeeded_job

        from dimitra_core.k8s.data import JobStatus
        from dimitra_core.k8s.utils import get_job_status

        result = get_job_status("test-job")

        assert isinstance(result, JobStatus)
        assert result.exists is True
        assert result.succeeded is True
        assert result.failed is False
        assert result.active is False
        assert result.error_message is None
        assert result.state == "Succeeded"
        assert result.pod_failures == []

    def test_get_job_status_active(self, initialized_k8s_with_mocked_client, mock_active_job):
        """Job running, verify active=True."""
        mock_batch_v1, mock_core_v1 = initialized_k8s_with_mocked_client
        mock_batch_v1.read_namespaced_job.return_value = mock_active_job

        from dimitra_core.k8s.utils import get_job_status

        result = get_job_status("test-job")

        assert result.exists is True
        assert result.succeeded is False
        assert result.failed is False
        assert result.active is True
        assert result.state == "Active"

    def test_get_job_status_failed_basic(self, initialized_k8s_with_mocked_client, mock_failed_job):
        """Job failed without pod details."""
        mock_batch_v1, mock_core_v1 = initialized_k8s_with_mocked_client
        mock_batch_v1.read_namespaced_job.return_value = mock_failed_job

        # Mock empty pod list
        mock_pod_list = MagicMock()
        mock_pod_list.items = []
        mock_core_v1.list_namespaced_pod.return_value = mock_pod_list

        from dimitra_core.k8s.utils import get_job_status

        result = get_job_status("test-job")

        assert result.exists is True
        assert result.succeeded is False
        assert result.failed is True
        assert result.active is False
        assert result.error_message == "Job failed in Kubernetes"
        assert result.state == "Failed"
        assert result.pod_failures == []

    def test_get_job_status_failed_oomkilled(self, initialized_k8s_with_mocked_client, mock_failed_job, mock_failed_pod_oomkilled):
        """OOMKilled scenario, verify pod_failures populated."""
        mock_batch_v1, mock_core_v1 = initialized_k8s_with_mocked_client
        mock_batch_v1.read_namespaced_job.return_value = mock_failed_job

        # Mock pod list with OOMKilled pod
        mock_pod_list = MagicMock()
        mock_pod_list.items = [mock_failed_pod_oomkilled]
        mock_core_v1.list_namespaced_pod.return_value = mock_pod_list

        from dimitra_core.k8s.data import PodFailureInfo
        from dimitra_core.k8s.utils import get_job_status

        result = get_job_status("test-job")

        assert result.failed is True
        assert result.error_message == "Task failed: Out of memory (OOMKilled)"
        assert len(result.pod_failures) == 1
        assert isinstance(result.pod_failures[0], PodFailureInfo)
        assert result.pod_failures[0].pod_name == "test-job-abc123"
        assert result.pod_failures[0].reason == "OOMKilled"
        assert result.pod_failures[0].message == "Container ran out of memory"

    def test_get_job_status_failed_container_error(self, initialized_k8s_with_mocked_client, mock_failed_job, mock_failed_pod_error):
        """Container error, verify error message."""
        mock_batch_v1, mock_core_v1 = initialized_k8s_with_mocked_client
        mock_batch_v1.read_namespaced_job.return_value = mock_failed_job

        # Mock pod list with error pod
        mock_pod_list = MagicMock()
        mock_pod_list.items = [mock_failed_pod_error]
        mock_core_v1.list_namespaced_pod.return_value = mock_pod_list

        from dimitra_core.k8s.utils import get_job_status

        result = get_job_status("test-job")

        assert result.failed is True
        assert "Command failed with exit code 1" in result.error_message
        assert len(result.pod_failures) == 1
        assert result.pod_failures[0].pod_name == "test-job-xyz789"
        assert result.pod_failures[0].reason == "Error"

    def test_get_job_status_failed_deadline_exceeded(self, initialized_k8s_with_mocked_client):
        """Deadline exceeded case."""
        mock_batch_v1, mock_core_v1 = initialized_k8s_with_mocked_client

        # Create job with deadline exceeded condition
        job = MagicMock()
        job.status.succeeded = None
        job.status.failed = None
        job.status.active = None
        condition = MagicMock()
        condition.type = "Failed"
        condition.reason = "DeadlineExceeded"
        job.status.conditions = [condition]

        mock_batch_v1.read_namespaced_job.return_value = job

        from dimitra_core.k8s.utils import get_job_status

        result = get_job_status("test-job")

        assert result.failed is True
        assert "deadline exceeded" in result.error_message.lower()
        assert result.state == "Failed"

    def test_get_job_status_not_found(self, initialized_k8s_with_mocked_client):
        """404 case, verify exists=False."""
        mock_batch_v1, mock_core_v1 = initialized_k8s_with_mocked_client

        from kubernetes.client.exceptions import ApiException

        # Mock 404 error
        mock_batch_v1.read_namespaced_job.side_effect = ApiException(status=404)

        from dimitra_core.k8s.utils import get_job_status

        result = get_job_status("nonexistent-job")

        assert result.exists is False
        assert result.succeeded is False
        assert result.failed is False
        assert result.active is False
        assert result.error_message == "Job not found in Kubernetes"
        assert result.state == "NotFound"
        assert result.pod_failures == []

    def test_get_job_status_returns_job_status_instance(self, initialized_k8s_with_mocked_client, mock_succeeded_job):
        """Verify return type is JobStatus."""
        mock_batch_v1, mock_core_v1 = initialized_k8s_with_mocked_client
        mock_batch_v1.read_namespaced_job.return_value = mock_succeeded_job

        from dimitra_core.k8s.data import JobStatus
        from dimitra_core.k8s.utils import get_job_status

        result = get_job_status("test-job")

        assert isinstance(result, JobStatus)

    def test_get_job_status_state_property(self, initialized_k8s_with_mocked_client):
        """Test state property returns correct values."""
        mock_batch_v1, mock_core_v1 = initialized_k8s_with_mocked_client

        from dimitra_core.k8s.utils import get_job_status

        # Test Succeeded state
        job = MagicMock()
        job.status.succeeded = 1
        job.status.failed = None
        job.status.active = None
        job.status.conditions = []
        mock_batch_v1.read_namespaced_job.return_value = job

        result = get_job_status("test-job")
        assert result.state == "Succeeded"

        # Reset for next test
        from dimitra_core.k8s.config import _reset_k8s_for_tests, init_k8s

        _reset_k8s_for_tests()
        init_k8s(kubernetes_namespace="test-namespace")

        # Test Failed state
        job = MagicMock()
        job.status.succeeded = None
        job.status.failed = 1
        job.status.active = None
        job.status.conditions = []
        mock_batch_v1.read_namespaced_job.return_value = job

        mock_pod_list = MagicMock()
        mock_pod_list.items = []
        mock_core_v1.list_namespaced_pod.return_value = mock_pod_list

        result = get_job_status("test-job")
        assert result.state == "Failed"

    def test_get_job_status_pod_scheduling_failed(self, initialized_k8s_with_mocked_client, mock_failed_job):
        """Pod scheduling failure case."""
        mock_batch_v1, mock_core_v1 = initialized_k8s_with_mocked_client
        mock_batch_v1.read_namespaced_job.return_value = mock_failed_job

        # Create pod with scheduling failure
        pod = MagicMock()
        pod.metadata.name = "test-job-failed"
        pod.status.phase = "Failed"
        pod.status.container_statuses = None

        condition = MagicMock()
        condition.type = "PodScheduled"
        condition.status = "False"
        condition.reason = "Unschedulable"
        condition.message = "0/3 nodes are available"
        pod.status.conditions = [condition]

        mock_pod_list = MagicMock()
        mock_pod_list.items = [pod]
        mock_core_v1.list_namespaced_pod.return_value = mock_pod_list

        from dimitra_core.k8s.utils import get_job_status

        result = get_job_status("test-job")

        assert result.failed is True
        assert "scheduling failed" in result.error_message.lower()
        assert len(result.pod_failures) == 1
        assert result.pod_failures[0].reason == "Unschedulable"
        assert result.pod_failures[0].message == "0/3 nodes are available"


class TestJobStatusSerialization:
    """Test JobStatus and PodFailureInfo serialization to dict."""

    def test_job_status_to_dict_with_pod_failures(self):
        """Test JobStatus.to_dict() with pod failures."""
        from dimitra_core.k8s.data import JobStatus, PodFailureInfo

        pod_failure = PodFailureInfo(
            pod_name="test-pod-789",
            reason="OOMKilled",
            message="Out of memory",
        )

        job_status = JobStatus(
            exists=True,
            succeeded=False,
            failed=True,
            active=False,
            error_message="Task failed",
            conditions=[],
            pod_failures=[pod_failure],
        )

        result = job_status.to_dict()

        assert result["failed"] is True
        assert result["state"] == "Failed"
        assert result["error_message"] == "Task failed"
        assert len(result["pod_failures"]) == 1
        assert result["pod_failures"][0]["pod_name"] == "test-pod-789"
        assert result["pod_failures"][0]["reason"] == "OOMKilled"
        assert result["pod_failures"][0]["message"] == "Out of memory"

    def test_job_status_to_dict_json_serializable(self):
        """Test that JobStatus.to_dict() result is JSON serializable."""
        import json

        from dimitra_core.k8s.data import JobStatus, PodFailureInfo

        pod_failure = PodFailureInfo(
            pod_name="test-pod",
            reason="Error",
            message="Test error",
        )

        mock_condition = MagicMock()
        mock_condition.to_dict.return_value = {
            "type": "Failed",
            "status": "True",
            "reason": "BackoffLimitExceeded",
            "message": "Job has reached the specified backoff limit",
        }

        job_status = JobStatus(
            exists=True,
            succeeded=False,
            failed=True,
            active=False,
            error_message="Job failed",
            conditions=[mock_condition],
            pod_failures=[pod_failure],
        )

        result_dict = job_status.to_dict()

        # This should not raise an exception
        json_string = json.dumps(result_dict)
        assert isinstance(json_string, str)

        # Verify we can parse it back
        parsed = json.loads(json_string)
        assert parsed["exists"] is True
        assert parsed["failed"] is True
        assert parsed["state"] == "Failed"
        assert len(parsed["pod_failures"]) == 1
        assert len(parsed["conditions"]) == 1
