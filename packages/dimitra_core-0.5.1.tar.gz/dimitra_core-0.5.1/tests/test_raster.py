"""Tests for the raster module."""

import subprocess
from unittest.mock import MagicMock, patch

import numpy as np
import pytest
from rasterio.windows import Window


class TestReadSrcData:
    """Test read_src_data function."""

    def test_applies_scale_and_offset(self):
        """Test that scale and offset are correctly applied to raster data."""
        from dimitra_core.raster.utils import read_src_data

        mock_src = MagicMock()
        mock_src.read.return_value = np.array([[100, 200], [300, 400]], dtype=np.int32)
        mock_src.scales = (0.01,)
        mock_src.offsets = (5.0,)
        mock_src.nodata = None

        result = read_src_data(mock_src, band=1)

        expected = np.array([[6.0, 7.0], [8.0, 9.0]], dtype=np.float32)
        assert result.dtype == np.float32
        np.testing.assert_array_almost_equal(result, expected)
        mock_src.read.assert_called_once_with(1, window=None)

    def test_returns_original_dtype_without_scale_offset(self):
        """Test that data is returned in its original dtype when scale=1.0 and offset=0.0."""
        from dimitra_core.raster.utils import read_src_data

        original_data = np.array([[1, 2], [3, 4]], dtype=np.int32)
        mock_src = MagicMock()
        mock_src.read.return_value = original_data
        mock_src.scales = (1.0,)
        mock_src.offsets = (0.0,)

        result = read_src_data(mock_src)

        assert result.dtype == np.int32
        np.testing.assert_array_equal(result, original_data)

    def test_invalid_band_raises_index_error(self):
        """Test that accessing a band beyond available scales raises IndexError."""
        from dimitra_core.raster.utils import read_src_data

        mock_src = MagicMock()
        mock_src.read.return_value = np.array([[1, 2]], dtype=np.int32)
        mock_src.scales = (1.0,)  # Only 1 band
        mock_src.offsets = (0.0,)

        with pytest.raises(IndexError):
            read_src_data(mock_src, band=5)


class TestDetectGdalGeos:
    """Test detect_gdal_geos function."""

    def test_detect_from_environment_variables(self):
        """Test detection when both GDAL and GEOS environment variables are set."""
        with patch.dict(
            "os.environ",
            {
                "GDAL_LIBRARY_PATH": "/usr/lib/libgdal.so",
                "GEOS_LIBRARY_PATH": "/usr/lib/libgeos_c.so",
            },
        ):
            from dimitra_core.raster.detect import detect_gdal_geos

            gdal_lib, geos_lib = detect_gdal_geos()

            assert gdal_lib == "/usr/lib/libgdal.so"
            assert geos_lib == "/usr/lib/libgeos_c.so"


class TestWindowsGenerator:
    """Test windows_generator function."""

    def test_even_division(self):
        """Test window generation when raster dimensions divide evenly by window size."""
        from dimitra_core.raster.utils import windows_generator

        # 1000x1000 raster with 500 window size = 2x2 grid (4 windows)
        windows = list(windows_generator(src_width=1000, src_height=1000, window_size=500))

        assert len(windows) == 4

        # Check first window
        assert windows[0] == Window(col_off=0, row_off=0, width=500, height=500)

        # Check last window
        assert windows[3] == Window(col_off=500, row_off=500, width=500, height=500)

    def test_uneven_division(self):
        """Test window generation when raster dimensions don't divide evenly."""
        from dimitra_core.raster.utils import windows_generator

        # 1100x1300 raster with 500 window size
        # Should create 3 columns (500, 500, 100) and 3 rows (500, 500, 300)
        windows = list(windows_generator(src_width=1100, src_height=1300, window_size=500))

        assert len(windows) == 9  # 3x3 grid

        # Check first window
        assert windows[0] == Window(col_off=0, row_off=0, width=500, height=500)

        # Check last column of first row (should have width=100)
        assert windows[2] == Window(col_off=1000, row_off=0, width=100, height=500)

        # Check last row, first column (should have height=300)
        assert windows[6] == Window(col_off=0, row_off=1000, width=500, height=300)

        # Check bottom-right corner (should have width=100, height=300)
        assert windows[8] == Window(col_off=1000, row_off=1000, width=100, height=300)

    def test_small_raster(self):
        """Test window generation for a raster smaller than window size."""
        from dimitra_core.raster.utils import windows_generator

        # 300x200 raster with 500 window size
        windows = list(windows_generator(src_width=300, src_height=200, window_size=500))

        assert len(windows) == 1
        assert windows[0] == Window(col_off=0, row_off=0, width=300, height=200)


class TestCropRaster:
    """Test crop_raster function."""

    def test_successful_crop(self):
        """Test successful raster cropping."""
        from dimitra_core.raster.utils import crop_raster

        boundary_file = "/path/to/boundary.geojson"
        input_path = "/path/to/input.tif"
        output_path = "/path/to/output.tif"

        expected_cmd = [
            "gdalwarp",
            "-cutline",
            boundary_file,
            "-crop_to_cutline",
            "-of",
            "GTiff",
            "-multi",
            "-wo",
            "NUM_THREADS=ALL_CPUS",
            "-co",
            "COMPRESS=PACKBITS",
            "-co",
            "BIGTIFF=YES",
            "-dstnodata",
            "0",
            "-q",
            input_path,
            output_path,
        ]

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)

            crop_raster(boundary_file, input_path, output_path)

            # Verify subprocess.run was called with correct arguments
            mock_run.assert_called_once_with(
                expected_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, check=True
            )

    def test_crop_failure_with_error_message(self):
        """Test that crop_raster raises an exception when gdalwarp fails."""
        from dimitra_core.raster.utils import crop_raster

        boundary_file = "/path/to/boundary.geojson"
        input_path = "/path/to/input.tif"
        output_path = "/path/to/output.tif"

        error_message = "ERROR: Invalid boundary file"

        with patch("subprocess.run") as mock_run:
            # Simulate subprocess.CalledProcessError
            mock_run.side_effect = subprocess.CalledProcessError(
                returncode=1, cmd="gdalwarp", stderr=error_message.encode("utf-8")
            )

            with pytest.raises(Exception, match=error_message):
                crop_raster(boundary_file, input_path, output_path)

    def test_crop_with_custom_nodata_value(self):
        """Test crop_raster with a custom nodata value."""
        from dimitra_core.raster.utils import crop_raster

        boundary_file = "/path/to/boundary.geojson"
        input_path = "/path/to/input.tif"
        output_path = "/path/to/output.tif"
        nodata_value = -9999

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)

            crop_raster(boundary_file, input_path, output_path, nodata=nodata_value)

            # Verify the nodata value is converted to string in the command
            call_args = mock_run.call_args[0][0]
            assert "-dstnodata" in call_args
            nodata_index = call_args.index("-dstnodata")
            assert call_args[nodata_index + 1] == "-9999"

    def test_crop_with_none_nodata_value(self):
        """Test crop_raster with nodata=None omits the -dstnodata flag."""
        from dimitra_core.raster.utils import crop_raster

        boundary_file = "/path/to/boundary.geojson"
        input_path = "/path/to/input.tif"
        output_path = "/path/to/output.tif"

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)

            crop_raster(boundary_file, input_path, output_path, nodata=None)

            # Verify the -dstnodata flag is NOT in the command
            call_args = mock_run.call_args[0][0]
            assert "-dstnodata" not in call_args
            # Verify other parts of the command are still present
            assert "gdalwarp" in call_args
            assert "-cutline" in call_args
            assert input_path in call_args
            assert output_path in call_args

    def test_crop_with_custom_compression(self):
        """Test crop_raster with custom compression value."""
        from dimitra_core.raster.utils import crop_raster

        boundary_file = "/path/to/boundary.geojson"
        input_path = "/path/to/input.tif"
        output_path = "/path/to/output.tif"

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)

            crop_raster(boundary_file, input_path, output_path, compress="LZW")

            call_args = mock_run.call_args[0][0]
            assert "COMPRESS=LZW" in call_args

    def test_crop_with_no_compression(self):
        """Test crop_raster with compress=None omits the compression flag."""
        from dimitra_core.raster.utils import crop_raster

        boundary_file = "/path/to/boundary.geojson"
        input_path = "/path/to/input.tif"
        output_path = "/path/to/output.tif"

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)

            crop_raster(boundary_file, input_path, output_path, compress=None)

            call_args = mock_run.call_args[0][0]
            compress_flags = [arg for arg in call_args if arg.startswith("COMPRESS=")]
            assert len(compress_flags) == 0

    def test_crop_with_invalid_compression(self):
        """Test crop_raster raises ValueError for invalid compression values."""
        from dimitra_core.raster.utils import crop_raster

        boundary_file = "/path/to/boundary.geojson"
        input_path = "/path/to/input.tif"
        output_path = "/path/to/output.tif"

        with pytest.raises(ValueError, match="Invalid compress value"):
            crop_raster(boundary_file, input_path, output_path, compress="INVALID")


class TestConvertToCog:
    """Test convert_to_cog function."""

    def test_function_signature_and_return_type(self):
        """Test that convert_to_cog has correct signature and returns None."""
        from dimitra_core.raster.utils import convert_to_cog

        input_path = "/path/to/input.tif"
        output_path = "/path/to/output_cog.tif"

        # Mock rasterio.open context manager
        mock_src = MagicMock()
        mock_src.tags.return_value = {
            "COMPRESSION": "ZSTD",
            "PREDICTOR": "2",
        }
        mock_src.block_shapes = [(512, 512)]

        mock_rasterio_open = MagicMock()
        mock_rasterio_open.__enter__.return_value = mock_src
        mock_rasterio_open.__exit__.return_value = None

        with patch("rasterio.open", return_value=mock_rasterio_open):
            with patch("subprocess.run") as mock_run:
                mock_run.return_value = MagicMock(returncode=0)

                result = convert_to_cog(input_path, output_path)

                # Verify function returns None
                assert result is None


class TestVisualizeTiffFile:
    """Test visualize_tiff_file function."""

    def test_successful_visualization_with_default_parameters(self):
        """Test successful tile generation and upload with default parameters."""
        from dimitra_core.raster.utils import visualize_tiff_file

        file_path = "/path/to/input.tif"
        colors = {1: "#FF0000", 2: "#00FF00", 3: "#0000FF"}
        s3_dir = "visualizations/test"
        s3_bucket_name = "test-bucket"

        # Mock COGReader and its context manager
        mock_cog_reader = MagicMock()
        mock_cog_reader.__enter__ = MagicMock(return_value=mock_cog_reader)
        mock_cog_reader.__exit__ = MagicMock(return_value=False)
        mock_cog_reader.bounds = (-180, -90, 180, 90)

        # Mock tiles generator
        mock_tile = MagicMock()
        mock_tile.x, mock_tile.y, mock_tile.z = 1, 2, 3
        mock_tiles = [mock_tile]

        # Mock multiprocessing pool
        mock_pool = MagicMock()
        mock_pool.__enter__ = MagicMock(return_value=mock_pool)
        mock_pool.__exit__ = MagicMock(return_value=False)
        mock_pool.imap_unordered = MagicMock(return_value=iter([None]))

        with patch("rio_tiler.io.COGReader", return_value=mock_cog_reader):
            with patch("mercantile.tiles", return_value=mock_tiles):
                with patch("multiprocessing.Pool", return_value=mock_pool):
                    with patch("dimitra_core.s3.upload_directory") as mock_upload:
                        visualize_tiff_file(file_path, colors, s3_dir=s3_dir, s3_bucket_name=s3_bucket_name)

                        # Verify upload_directory was called
                        assert mock_upload.call_count == 1
                        call_args = mock_upload.call_args[1]
                        assert call_args["bucket_name"] == s3_bucket_name

    def test_visualization_with_progress_callback(self):
        """Test that progress callback is called during tile generation."""
        from dimitra_core.raster.utils import visualize_tiff_file

        file_path = "/path/to/input.tif"
        colors = {1: "#FF0000"}
        s3_dir = "visualizations/test"
        s3_bucket_name = "test-bucket"

        # Mock COGReader
        mock_cog_reader = MagicMock()
        mock_cog_reader.__enter__ = MagicMock(return_value=mock_cog_reader)
        mock_cog_reader.__exit__ = MagicMock(return_value=False)
        mock_cog_reader.bounds = (-180, -90, 180, 90)

        # Mock tiles - create multiple tiles to test progress
        mock_tiles = [MagicMock(x=i, y=i, z=10) for i in range(5)]

        # Mock multiprocessing pool
        mock_pool = MagicMock()
        mock_pool.__enter__ = MagicMock(return_value=mock_pool)
        mock_pool.__exit__ = MagicMock(return_value=False)
        mock_pool.imap_unordered = MagicMock(return_value=iter([None] * 5))

        # Create a mock progress callback
        progress_callback = MagicMock()

        with patch("rio_tiler.io.COGReader", return_value=mock_cog_reader):
            with patch("mercantile.tiles", return_value=mock_tiles):
                with patch("multiprocessing.Pool", return_value=mock_pool):
                    with patch("dimitra_core.s3.upload_directory"):
                        visualize_tiff_file(
                            file_path,
                            colors,
                            s3_dir=s3_dir,
                            s3_bucket_name=s3_bucket_name,
                            progress_update_func=progress_callback,
                        )

                        # Verify progress callback was called
                        assert progress_callback.call_count > 0
                        # Verify it was called with integer percentages
                        for call_args in progress_callback.call_args_list:
                            progress_value = call_args[0][0]
                            assert isinstance(progress_value, int)
                            assert 0 <= progress_value <= 100

    def test_visualization_with_custom_zoom_levels(self):
        """Test visualization with custom min and max zoom levels."""
        from dimitra_core.raster.utils import visualize_tiff_file

        file_path = "/path/to/input.tif"
        colors = {1: "#FF0000"}
        s3_dir = "visualizations/test"
        s3_bucket_name = "test-bucket"
        min_zoom = 5
        max_zoom = 8

        # Mock COGReader
        mock_cog_reader = MagicMock()
        mock_cog_reader.__enter__ = MagicMock(return_value=mock_cog_reader)
        mock_cog_reader.__exit__ = MagicMock(return_value=False)
        mock_cog_reader.bounds = (-180, -90, 180, 90)

        # Mock tiles
        mock_tiles = [MagicMock(x=1, y=1, z=z) for z in range(min_zoom, max_zoom + 1)]

        # Mock multiprocessing pool
        mock_pool = MagicMock()
        mock_pool.__enter__ = MagicMock(return_value=mock_pool)
        mock_pool.__exit__ = MagicMock(return_value=False)
        mock_pool.imap_unordered = MagicMock(return_value=iter([None] * len(mock_tiles)))

        with patch("rio_tiler.io.COGReader", return_value=mock_cog_reader):
            with patch("mercantile.tiles", return_value=mock_tiles) as mock_tiles_func:
                with patch("multiprocessing.Pool", return_value=mock_pool):
                    with patch("dimitra_core.s3.upload_directory"):
                        visualize_tiff_file(
                            file_path,
                            colors,
                            s3_dir=s3_dir,
                            s3_bucket_name=s3_bucket_name,
                            min_visualization_zoom=min_zoom,
                            max_visualization_zoom=max_zoom,
                        )

                        # Verify tiles was called with correct zoom range
                        assert mock_tiles_func.called

    def test_visualization_with_custom_max_workers(self):
        """Test visualization with custom number of worker processes."""
        from dimitra_core.raster.utils import visualize_tiff_file

        file_path = "/path/to/input.tif"
        colors = {1: "#FF0000"}
        s3_dir = "visualizations/test"
        s3_bucket_name = "test-bucket"
        max_workers = 2

        # Mock COGReader
        mock_cog_reader = MagicMock()
        mock_cog_reader.__enter__ = MagicMock(return_value=mock_cog_reader)
        mock_cog_reader.__exit__ = MagicMock(return_value=False)
        mock_cog_reader.bounds = (-180, -90, 180, 90)

        # Mock tiles
        mock_tiles = [MagicMock(x=1, y=1, z=10)]

        # Mock multiprocessing pool
        mock_pool = MagicMock()
        mock_pool.__enter__ = MagicMock(return_value=mock_pool)
        mock_pool.__exit__ = MagicMock(return_value=False)
        mock_pool.imap_unordered = MagicMock(return_value=iter([None]))

        with patch("rio_tiler.io.COGReader", return_value=mock_cog_reader):
            with patch("mercantile.tiles", return_value=mock_tiles):
                with patch("multiprocessing.Pool", return_value=mock_pool) as mock_pool_cls:
                    with patch("dimitra_core.s3.upload_directory"):
                        visualize_tiff_file(
                            file_path, colors, s3_dir=s3_dir, s3_bucket_name=s3_bucket_name, max_workers=max_workers
                        )

                        # Verify Pool was created with correct number of workers
                        mock_pool_cls.assert_called_once()
                        call_kwargs = mock_pool_cls.call_args[1]
                        assert call_kwargs["processes"] == max_workers

    def test_function_signature_and_return_type(self):
        """Test that visualize_tiff_file has correct signature and returns a tuple of two ints."""
        from dimitra_core.raster.utils import visualize_tiff_file

        file_path = "/path/to/input.tif"
        colors = {1: "#FF0000"}
        s3_dir = "visualizations/test"
        s3_bucket_name = "test-bucket"

        # Mock all dependencies
        mock_cog_reader = MagicMock()
        mock_cog_reader.__enter__ = MagicMock(return_value=mock_cog_reader)
        mock_cog_reader.__exit__ = MagicMock(return_value=False)
        mock_cog_reader.bounds = (-180, -90, 180, 90)

        mock_tiles = []
        mock_pool = MagicMock()
        mock_pool.__enter__ = MagicMock(return_value=mock_pool)
        mock_pool.__exit__ = MagicMock(return_value=False)
        mock_pool.imap_unordered = MagicMock(return_value=iter([]))

        with patch("rio_tiler.io.COGReader", return_value=mock_cog_reader):
            with patch("mercantile.tiles", return_value=mock_tiles):
                with patch("multiprocessing.Pool", return_value=mock_pool):
                    with patch("dimitra_core.s3.upload_directory"):
                        result = visualize_tiff_file(file_path, colors, s3_dir=s3_dir, s3_bucket_name=s3_bucket_name)

                        # Verify function returns a tuple of two ints
                        assert isinstance(result, tuple)
                        assert len(result) == 2
                        assert all(isinstance(v, int) for v in result)

    def test_visualization_with_output_dir(self):
        """Test tile generation with output_dir instead of S3."""
        from dimitra_core.raster.utils import visualize_tiff_file

        file_path = "/path/to/input.tif"
        colors = {1: "#FF0000"}
        output_dir = "/path/to/output"

        # Mock COGReader
        mock_cog_reader = MagicMock()
        mock_cog_reader.__enter__ = MagicMock(return_value=mock_cog_reader)
        mock_cog_reader.__exit__ = MagicMock(return_value=False)
        mock_cog_reader.bounds = (-180, -90, 180, 90)

        # Mock tiles
        mock_tile = MagicMock()
        mock_tile.x, mock_tile.y, mock_tile.z = 1, 2, 3
        mock_tiles = [mock_tile]

        # Mock multiprocessing pool
        mock_pool = MagicMock()
        mock_pool.__enter__ = MagicMock(return_value=mock_pool)
        mock_pool.__exit__ = MagicMock(return_value=False)
        mock_pool.imap_unordered = MagicMock(return_value=iter([None]))

        with patch("rio_tiler.io.COGReader", return_value=mock_cog_reader):
            with patch("mercantile.tiles", return_value=mock_tiles):
                with patch("multiprocessing.Pool", return_value=mock_pool):
                    with patch("dimitra_core.s3.upload_directory") as mock_upload:
                        visualize_tiff_file(file_path, colors, output_dir=output_dir)

                        # Verify upload_directory was NOT called
                        mock_upload.assert_not_called()

    def test_validation_both_s3_and_output_dir_raises(self):
        """Test that passing both s3_dir and output_dir raises ValueError."""
        from dimitra_core.raster.utils import visualize_tiff_file

        with pytest.raises(ValueError, match="Cannot specify both"):
            visualize_tiff_file(
                "/path/to/input.tif",
                {1: "#FF0000"},
                s3_dir="visualizations/test",
                s3_bucket_name="test-bucket",
                output_dir="/path/to/output",
            )

    def test_validation_neither_s3_nor_output_dir_raises(self):
        """Test that passing neither s3_dir nor output_dir raises ValueError."""
        from dimitra_core.raster.utils import visualize_tiff_file

        with pytest.raises(ValueError, match="Must specify either"):
            visualize_tiff_file("/path/to/input.tif", {1: "#FF0000"})

    def test_validation_s3_dir_without_bucket_raises(self):
        """Test that passing s3_dir without s3_bucket_name raises ValueError."""
        from dimitra_core.raster.utils import visualize_tiff_file

        with pytest.raises(ValueError, match="s3_bucket_name.*required"):
            visualize_tiff_file("/path/to/input.tif", {1: "#FF0000"}, s3_dir="visualizations/test")


class TestVisualizeTile:
    """Test visualize_tile function from workers module."""

    def test_successful_tile_generation(self):
        """Test successful generation of a tile with valid data."""
        from dimitra_core.raster.workers.visualize import visualize_tile

        tile_info = (10, 20, 5)  # x, y, z

        # Mock tile data - non-zero values
        mock_tile_data = np.array([[1, 2], [3, 4]])
        mock_cog_reader = MagicMock()
        mock_cog_reader.tile = MagicMock(return_value=([mock_tile_data], None))

        # Mock colors mapping
        mock_colors = {1: (255, 0, 0), 2: (0, 255, 0), 3: (0, 0, 255), 4: (255, 255, 0)}

        # Mock image
        mock_image = MagicMock()

        with patch("dimitra_core.raster.workers.visualize._cog_reader", mock_cog_reader):
            with patch("dimitra_core.raster.workers.visualize._colors", mock_colors):
                with patch("dimitra_core.raster.workers.visualize._output_dir", "/tmp/output"):
                    with patch("dimitra_core.raster.workers.visualize.Image.fromarray", return_value=mock_image):
                        with patch("os.makedirs"):
                            visualize_tile(tile_info)

                            # Verify tile was read with correct coordinates
                            mock_cog_reader.tile.assert_called_once_with(10, 20, 5)

                            # Verify image was saved
                            mock_image.save.assert_called_once()
                            save_args = mock_image.save.call_args
                            assert save_args[1]["format"] == "WEBP"
                            assert save_args[1]["lossless"] is True

    def test_tile_with_all_zeros_returns_none(self):
        """Test that tiles with all zero values are skipped."""
        from dimitra_core.raster.workers.visualize import visualize_tile

        tile_info = (10, 20, 5)

        # Mock tile data - all zeros
        mock_tile_data = np.zeros((256, 256))
        mock_cog_reader = MagicMock()
        mock_cog_reader.tile = MagicMock(return_value=([mock_tile_data], None))

        mock_colors = {1: (255, 0, 0)}

        with patch("dimitra_core.raster.workers.visualize._cog_reader", mock_cog_reader):
            with patch("dimitra_core.raster.workers.visualize._colors", mock_colors):
                with patch("dimitra_core.raster.workers.visualize._output_dir", "/tmp/output"):
                    result = visualize_tile(tile_info)

                    # Verify function returns None for empty tiles
                    assert result is None

    def test_tile_generation_with_error_handling(self):
        """Test that errors during tile generation are logged but don't raise exceptions."""
        from dimitra_core.raster.workers.visualize import visualize_tile

        tile_info = (10, 20, 5)

        # Mock tile reading to raise an exception
        mock_cog_reader = MagicMock()
        mock_cog_reader.tile = MagicMock(side_effect=Exception("Read error"))

        mock_logger = MagicMock()

        with patch("dimitra_core.raster.workers.visualize._cog_reader", mock_cog_reader):
            with patch("dimitra_core.raster.workers.visualize._logger", mock_logger):
                # Should not raise exception
                visualize_tile(tile_info)

                # Verify error was logged
                assert mock_logger.error.called
                error_message = mock_logger.error.call_args[0][0]
                assert "Error in creating visualization image" in error_message
                assert str(tile_info) in error_message

    def test_function_signature(self):
        """Test that visualize_tile accepts tuple of three integers."""
        from dimitra_core.raster.workers.visualize import visualize_tile

        tile_info = (1, 2, 3)

        # Mock all dependencies to prevent actual tile generation
        mock_tile_data = np.zeros((256, 256))
        mock_cog_reader = MagicMock()
        mock_cog_reader.tile = MagicMock(return_value=([mock_tile_data], None))

        with patch("dimitra_core.raster.workers.visualize._cog_reader", mock_cog_reader):
            with patch("dimitra_core.raster.workers.visualize._colors", {}):
                with patch("dimitra_core.raster.workers.visualize._output_dir", "/tmp/output"):
                    result = visualize_tile(tile_info)

                    # Verify function can be called with correct signature
                    assert result is None  # Returns None for all-zero tiles


class TestComputeMaxZoomLevelEpsg4326:
    """Test compute_max_zoom_level_epsg_4326 function."""

    def test_successful_computation(self):
        """Test successful max zoom computation with valid EPSG:4326 raster."""
        from dimitra_core.raster.utils import compute_max_zoom_level_epsg_4326

        tiff_path = "/path/to/input.tif"

        # Mock rasterio dataset
        mock_ds = MagicMock()
        mock_ds.__enter__ = MagicMock(return_value=mock_ds)
        mock_ds.__exit__ = MagicMock(return_value=False)

        # Mock CRS as EPSG:4326
        mock_crs = MagicMock()
        mock_crs.to_epsg = MagicMock(return_value=4326)
        mock_ds.crs = mock_crs

        # Mock transform
        mock_transform = MagicMock()
        mock_transform.a = 0.0001  # pixel width in degrees
        mock_transform.e = -0.0001  # pixel height in degrees (negative)
        mock_ds.transform = mock_transform

        # Mock bounds
        mock_bounds = MagicMock()
        mock_bounds.top = 10.0
        mock_bounds.bottom = 0.0
        mock_ds.bounds = mock_bounds

        with patch("rasterio.open", return_value=mock_ds):
            zoom_level = compute_max_zoom_level_epsg_4326(tiff_path)

            # Verify function returns an integer
            assert isinstance(zoom_level, int)
            # Verify result is a reasonable zoom level (0-25 range)
            assert 0 <= zoom_level <= 25

    def test_raises_exception_for_non_epsg_4326(self):
        """Test that function raises exception when raster is not in EPSG:4326."""
        from dimitra_core.raster.utils import compute_max_zoom_level_epsg_4326

        tiff_path = "/path/to/web_mercator.tif"

        # Mock rasterio dataset
        mock_ds = MagicMock()
        mock_ds.__enter__ = MagicMock(return_value=mock_ds)
        mock_ds.__exit__ = MagicMock(return_value=False)

        # Mock CRS as EPSG:3857 (Web Mercator) instead of 4326
        mock_crs = MagicMock()
        mock_crs.to_epsg = MagicMock(return_value=3857)
        mock_ds.crs = mock_crs

        with patch("rasterio.open", return_value=mock_ds):
            with pytest.raises(Exception, match="GeoTIFF must be in EPSG:4326"):
                compute_max_zoom_level_epsg_4326(tiff_path)
