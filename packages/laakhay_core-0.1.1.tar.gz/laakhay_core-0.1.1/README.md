# Laakhay Core

`laakhay-core` is the high-performance, zero-dependency bedrock of the Laakhay ecosystem. It provides the source of truth for all domain models, identity grammars, and primitive types.

## 🏗 Philosophy: The "Thin Core"
This library follows a strict separation of **Data** and **Behavior**.
- **Schema Authority**: Defines *what* a Bar or Position is.
- **Identity Authority**: Centralizes URM (Universal Representation Mapping).
- **Stability First**: Zero runtime dependencies to prevent version drift.

[Read more about our Philosophy](docs/philosophy.md)

---

## 🛠 Features

- **Standardized Identity**: [URM System](docs/urm.md) for exchange-agnostic instrument resolution.
- **Atomic Models**: Efficient [OHLCV (Bar), Orders, and Positions](docs/models.md).
- **Semantic Components**: Type-safe `BaseAsset`, `QuoteAsset`, and `InstrumentExpiry`.
- **Memory Efficient**: Uses `__slots__` and `frozen` dataclasses for high-throughput trading.
- **Python 3.9+**: Built for modern Python environments.

---

## 🚀 Quick Start

### Installation
`laakhay-core` is meant to be used as a backend library:
```bash
pip install laakhay-core
```

### Basic Usage
```python
from laakhay.core import Bar, Timeframe, AssetSpec, parse_urm_id

# 1. Create a high-performance Bar
bar = Bar(ts=1708453200, open="52000", high="52500", low="51800", close="52100", volume="150")

# 2. Work with Identities (Stocks or Crypto)
# Equity URM
aapl = parse_urm_id("urm://nasdaq:aapl:equity")

# Crypto spot URM
btc = parse_urm_id("urm://binance:btc/usdt:spot")

# 3. Handle Metadata
aapl_meta = AssetSpec(symbol="AAPL", currency="USD", precision=2)
```

## 📖 Documentation
- [Universal Representation Mapping (URM)](docs/urm.md)
- [Core Models & Specifications](docs/models.md)
- [Architectural Philosophy](docs/philosophy.md)

## 🧪 Development
```bash
make test    # Run all unit tests
make lint    # Check formatting and types
```
