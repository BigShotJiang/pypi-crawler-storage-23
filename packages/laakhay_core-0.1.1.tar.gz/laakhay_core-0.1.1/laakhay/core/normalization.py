"""Normalization and coercion helpers for core contracts."""

from __future__ import annotations

from datetime import UTC, date, datetime, time
from decimal import Decimal, InvalidOperation

from .exceptions import ValidationError
from .types import PriceLike, TimestampLike


def to_decimal(value: PriceLike, *, field_name: str = "value") -> Decimal:
    """Coerce a scalar price/qty/rate input to Decimal."""
    if isinstance(value, Decimal):
        return value
    if isinstance(value, int):
        return Decimal(value)
    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, str):
        raw = value.strip()
        if raw == "":
            raise ValidationError(f"{field_name} cannot be empty", code="invalid_decimal")
        try:
            return Decimal(raw)
        except InvalidOperation as exc:
            raise ValidationError(
                f"{field_name} must be numeric; got {value!r}",
                code="invalid_decimal",
                details={"field": field_name, "value": value},
            ) from exc
    raise ValidationError(
        f"{field_name} has unsupported type {type(value).__name__}",
        code="invalid_decimal_type",
        details={"field": field_name, "type": type(value).__name__},
    )


def to_timestamp(value: TimestampLike, *, field_name: str = "timestamp") -> datetime:
    """Coerce supported timestamp forms into timezone-aware UTC datetime."""
    if isinstance(value, datetime):
        return value if value.tzinfo is not None else value.replace(tzinfo=UTC)

    if isinstance(value, date):
        return datetime.combine(value, time.min, tzinfo=UTC)

    if isinstance(value, int):
        # Treat large integers as epoch milliseconds.
        if abs(value) >= 10_000_000_000:
            return datetime.fromtimestamp(value / 1000, tz=UTC)
        return datetime.fromtimestamp(value, tz=UTC)

    if isinstance(value, str):
        raw = value.strip()
        if raw == "":
            raise ValidationError(f"{field_name} cannot be empty", code="invalid_timestamp")
        if raw.endswith("Z"):
            raw = raw[:-1] + "+00:00"
        try:
            parsed = datetime.fromisoformat(raw)
        except ValueError as exc:
            raise ValidationError(
                f"{field_name} must be ISO-8601 or epoch seconds/ms; got {value!r}",
                code="invalid_timestamp",
                details={"field": field_name, "value": value},
            ) from exc
        return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=UTC)

    raise ValidationError(
        f"{field_name} has unsupported type {type(value).__name__}",
        code="invalid_timestamp_type",
        details={"field": field_name, "type": type(value).__name__},
    )
