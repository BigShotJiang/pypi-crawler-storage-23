"""Primitive type aliases and shared types for the Laakhay ecosystem."""

from datetime import date, datetime
from decimal import Decimal
from typing import TypeAlias

# Basic Type Aliases
Price: TypeAlias = Decimal
Qty: TypeAlias = Decimal
Rate: TypeAlias = Decimal
Timestamp: TypeAlias = datetime
Symbol: TypeAlias = str

# Coercion-friendly aliases
PriceLike: TypeAlias = Decimal | float | int | str
QtyLike: TypeAlias = Decimal | float | int | str
RateLike: TypeAlias = Decimal | float | int | str
TimestampLike: TypeAlias = datetime | date | str | int
SymbolLike: TypeAlias = str
