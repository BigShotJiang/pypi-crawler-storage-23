"""Shared canonical enums used across Laakhay libraries."""

from enum import StrEnum


class DataSource(StrEnum):
    DEFAULT = "default"
    OHLCV = "ohlcv"
    TRADES = "trades"
    ORDERBOOK = "orderbook"
    LIQUIDATION = "liquidation"


class MarketType(StrEnum):
    SPOT = "spot"
    FUTURES = "futures"
    PERPETUAL = "perpetual"
    OPTIONS = "options"
    EQUITY = "equity"
    FX = "fx"
    BOND = "bond"


class MarketVariant(StrEnum):
    SPOT = "spot"
    LINEAR_PERP = "linear_perp"
    INVERSE_PERP = "inverse_perp"
    LINEAR_DELIVERY = "linear_delivery"
    INVERSE_DELIVERY = "inverse_delivery"
    OPTIONS = "options"

    EQUITY = "equity"
    FX = "fx"

    @classmethod
    def from_market_type(cls, market_type: MarketType, default: "MarketVariant | None" = None) -> "MarketVariant":
        if default is not None:
            return default
        if market_type == MarketType.SPOT:
            return cls.SPOT
        if market_type == MarketType.OPTIONS:
            return cls.OPTIONS
        if market_type == MarketType.EQUITY:
            return cls.EQUITY
        if market_type == MarketType.FX:
            return cls.SPOT
        return cls.LINEAR_PERP

    def to_market_type(self) -> MarketType:
        if self in (
            self.LINEAR_PERP,
            self.INVERSE_PERP,
            self.LINEAR_DELIVERY,
            self.INVERSE_DELIVERY,
        ):
            return MarketType.FUTURES
        if self == self.OPTIONS:
            return MarketType.OPTIONS
        if self == self.EQUITY:
            return MarketType.EQUITY
        if self == self.FX:
            return MarketType.FX
        return MarketType.SPOT


class InstrumentType(StrEnum):
    SPOT = "spot"
    PERPETUAL = "perpetual"
    FUTURE = "future"
    OPTION = "option"
    MOVE = "move"
    BASKET = "basket"
