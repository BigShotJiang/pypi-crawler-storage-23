"""Core exceptions for the Laakhay ecosystem."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


class LaakhayError(Exception):
    """Base exception for all Laakhay-related errors."""

    default_code = "laakhay_error"

    def __init__(self, message: str, *, code: str | None = None, details: Mapping[str, Any] | None = None) -> None:
        super().__init__(message)
        self.code = code or self.default_code
        self.details = dict(details or {})


class ValidationError(LaakhayError, ValueError):
    """Raised when data validation fails."""

    default_code = "validation_error"


class ConfigurationError(LaakhayError):
    """Raised when application configuration is invalid."""

    default_code = "configuration_error"


class DataError(LaakhayError):
    """Base class for data-related errors."""

    default_code = "data_error"


class MissingDataError(DataError):
    """Raised when requested data is not found."""

    default_code = "missing_data"


class CapabilityError(LaakhayError):
    """Raised when a requested feature/capability is unavailable."""

    default_code = "capability_error"


class ContractMismatchError(LaakhayError):
    """Raised when producer/consumer contracts diverge."""

    default_code = "contract_mismatch"


class ConflictError(LaakhayError):
    """Raised for invalid or conflicting state transitions."""

    default_code = "conflict_error"


class SymbolResolutionError(ValidationError):
    """Raised when URM cannot resolve symbols/specs across representations."""

    default_code = "symbol_resolution_error"

    def __init__(
        self,
        message: str,
        *,
        exchange: str | None = None,
        value: str | None = None,
        market_type: Any | None = None,
        known_aliases: Mapping[str, str] | None = None,
        code: str | None = None,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        merged_details: dict[str, Any] = dict(details or {})
        if exchange is not None:
            merged_details["exchange"] = exchange
        if value is not None:
            merged_details["value"] = value
        if market_type is not None:
            merged_details["market_type"] = str(market_type)
        if known_aliases:
            merged_details["known_aliases"] = dict(known_aliases)
        super().__init__(message, code=code or self.default_code, details=merged_details)
        self.exchange = exchange
        self.value = value
        self.market_type = market_type
        self.known_aliases = dict(known_aliases or {})
