"""Trading signal model."""

from dataclasses import dataclass
from decimal import Decimal
from typing import Any, TypeAlias

from ..normalization import to_decimal
from ..types import Price, Symbol
from .order import OrderSide, OrderType

# Advanced Parameters Types
RiskType: TypeAlias = float | Decimal | str  # e.g. 0.01, Decimal("100"), "1%"
SLTPType: TypeAlias = Decimal | str  # e.g. Decimal("50000"), "2%"


@dataclass(slots=True, frozen=True)
class Signal:
    """Trading signal with optional risk management parameters."""

    symbol: Symbol
    side: OrderSide | str
    type: OrderType | str
    price: Price | None = None  # Required for LIMIT/STOP

    # Risk Management overrides
    sl: SLTPType | None = None
    tp: SLTPType | None = None

    # Position Sizing override
    size: RiskType | None = None
    schema_version: int = 1

    def __post_init__(self) -> None:
        object.__setattr__(self, "side", OrderSide(self.side))
        object.__setattr__(self, "type", OrderType(self.type))
        if self.price is not None:
            object.__setattr__(self, "price", to_decimal(self.price, field_name="price"))
        if self.sl is not None:
            object.__setattr__(self, "sl", _coerce_sltp(self.sl))
        if self.tp is not None:
            object.__setattr__(self, "tp", _coerce_sltp(self.tp))
        if self.size is not None:
            object.__setattr__(self, "size", _coerce_risk(self.size))

        if self.type in {OrderType.LIMIT, OrderType.STOP, OrderType.STOP_LIMIT} and self.price is None:
            raise ValueError(f"Price required for {self.type} signals")

    def to_dict(self) -> dict[str, Any]:
        return {
            "symbol": self.symbol,
            "side": self.side.value,
            "type": self.type.value,
            "price": str(self.price) if self.price is not None else None,
            "sl": str(self.sl) if self.sl is not None else None,
            "tp": str(self.tp) if self.tp is not None else None,
            "size": str(self.size) if self.size is not None else None,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Signal":
        return cls(
            symbol=str(raw["symbol"]),
            side=str(raw["side"]),
            type=str(raw["type"]),
            price=raw.get("price"),
            sl=raw.get("sl"),
            tp=raw.get("tp"),
            size=raw.get("size"),
            schema_version=int(raw.get("schema_version", 1)),
        )


def _coerce_sltp(value: SLTPType) -> SLTPType:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, str) and value.strip().endswith("%"):
        return value.strip()
    return to_decimal(value, field_name="sl/tp")


def _coerce_risk(value: RiskType) -> RiskType:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, str):
        raw = value.strip()
        if raw.endswith("%"):
            return raw
        return to_decimal(raw, field_name="size")
    if isinstance(value, float):
        return to_decimal(value, field_name="size")
    return to_decimal(value, field_name="size")
