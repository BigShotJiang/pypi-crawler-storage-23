"""Standardized time range contracts."""

from dataclasses import dataclass
from typing import Any

from ..normalization import to_timestamp
from ..types import Timestamp


@dataclass(frozen=True, slots=True)
class DataRange:
    """A canonical time window for data requests.

    Semantics:
    - include_start=True (default): start boundary is inclusive.
    - include_end=False (default): end boundary is exclusive.
    """

    start_ts: Timestamp
    end_ts: Timestamp
    include_start: bool = True
    include_end: bool = False
    schema_version: int = 1

    def __post_init__(self) -> None:
        start = to_timestamp(self.start_ts, field_name="start_ts")
        end = to_timestamp(self.end_ts, field_name="end_ts")
        object.__setattr__(self, "start_ts", start)
        object.__setattr__(self, "end_ts", end)
        if end < start:
            raise ValueError("end_ts must be >= start_ts")

    @property
    def duration_seconds(self) -> float:
        return (self.end_ts - self.start_ts).total_seconds()

    def contains(self, ts: Timestamp) -> bool:
        point = to_timestamp(ts, field_name="ts")
        if self.include_start:
            start_ok = point >= self.start_ts
        else:
            start_ok = point > self.start_ts
        if self.include_end:
            end_ok = point <= self.end_ts
        else:
            end_ok = point < self.end_ts
        return start_ok and end_ok

    def to_dict(self) -> dict[str, Any]:
        return {
            "start_ts": self.start_ts.isoformat(),
            "end_ts": self.end_ts.isoformat(),
            "include_start": self.include_start,
            "include_end": self.include_end,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "DataRange":
        return cls(
            start_ts=raw["start_ts"],
            end_ts=raw["end_ts"],
            include_start=bool(raw.get("include_start", True)),
            include_end=bool(raw.get("include_end", False)),
            schema_version=int(raw.get("schema_version", 1)),
        )
