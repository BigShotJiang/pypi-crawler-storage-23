"""Position and execution models."""

from dataclasses import dataclass, field
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

from ..ids import order_id, trade_id
from ..normalization import to_decimal, to_timestamp
from ..types import Price, Qty, Symbol, Timestamp
from .order import OrderSide


@dataclass(frozen=True, slots=True)
class Trade:
    """Execution output from an order."""

    trade_id: trade_id | str
    order_id: order_id | str
    symbol: Symbol
    side: OrderSide | str
    qty: Qty
    price: Price
    timestamp: Timestamp = field(default_factory=lambda: datetime.now(UTC))
    fee: Price = Decimal("0")
    fee_asset: str | None = None
    schema_version: int = 1

    def __post_init__(self) -> None:
        object.__setattr__(self, "trade_id", str(self.trade_id))
        object.__setattr__(self, "order_id", str(self.order_id))
        object.__setattr__(self, "side", OrderSide(self.side))
        object.__setattr__(self, "qty", to_decimal(self.qty, field_name="qty"))
        object.__setattr__(self, "price", to_decimal(self.price, field_name="price"))
        object.__setattr__(self, "fee", to_decimal(self.fee, field_name="fee"))
        object.__setattr__(self, "timestamp", to_timestamp(self.timestamp, field_name="timestamp"))

    def to_dict(self) -> dict[str, Any]:
        return {
            "trade_id": self.trade_id,
            "order_id": self.order_id,
            "symbol": self.symbol,
            "side": self.side.value,
            "qty": str(self.qty),
            "price": str(self.price),
            "timestamp": self.timestamp.isoformat(),
            "fee": str(self.fee),
            "fee_asset": self.fee_asset,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Trade":
        return cls(
            trade_id=str(raw["trade_id"]),
            order_id=str(raw["order_id"]),
            symbol=str(raw["symbol"]),
            side=str(raw["side"]),
            qty=raw["qty"],
            price=raw["price"],
            timestamp=raw.get("timestamp", datetime.now(UTC)),
            fee=raw.get("fee", "0"),
            fee_asset=raw.get("fee_asset"),
            schema_version=int(raw.get("schema_version", 1)),
        )


@dataclass(frozen=True, slots=True)
class Position:
    """Pure position state container (no accounting/update policy)."""

    symbol: Symbol
    qty: Qty = Decimal("0")
    avg_entry_price: Price = Decimal("0")
    schema_version: int = 1

    def __post_init__(self) -> None:
        object.__setattr__(self, "qty", to_decimal(self.qty, field_name="qty"))
        object.__setattr__(self, "avg_entry_price", to_decimal(self.avg_entry_price, field_name="avg_entry_price"))

    @property
    def market_value(self) -> Price:
        """Net market value at average entry price."""
        return self.qty * self.avg_entry_price

    @property
    def abs_qty(self) -> Qty:
        return abs(self.qty)

    @property
    def is_flat(self) -> bool:
        return self.qty == 0

    @property
    def is_long(self) -> bool:
        return self.qty > 0

    @property
    def is_short(self) -> bool:
        return self.qty < 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "symbol": self.symbol,
            "qty": str(self.qty),
            "avg_entry_price": str(self.avg_entry_price),
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Position":
        return cls(
            symbol=str(raw["symbol"]),
            qty=raw.get("qty", "0"),
            avg_entry_price=raw.get("avg_entry_price", "0"),
            schema_version=int(raw.get("schema_version", 1)),
        )
