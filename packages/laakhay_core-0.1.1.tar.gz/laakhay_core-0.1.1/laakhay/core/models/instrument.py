"""Canonical description of an instrument."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from ..enums import InstrumentType
from ..normalization import to_decimal, to_timestamp
from ..types import Price, Rate, Timestamp

_ASSET_TOKEN_PATTERN = re.compile(r"^[A-Z0-9][A-Z0-9._-]*$")


class _AssetToken(str):
    _field_name = "asset"

    def __new__(cls, value: str) -> _AssetToken:
        if isinstance(value, cls):
            return value
        if not isinstance(value, str):
            raise TypeError(f"{cls._field_name} must be a string")
        normalized = value.strip().upper()
        if not normalized:
            raise ValueError(f"{cls._field_name} cannot be empty")
        if not _ASSET_TOKEN_PATTERN.match(normalized):
            raise ValueError(f"{cls._field_name} contains invalid characters: {value!r}")
        return str.__new__(cls, normalized)


class BaseAsset(_AssetToken):
    _field_name = "base"


class QuoteAsset(_AssetToken):
    _field_name = "quote"

    def __new__(cls, value: str | None) -> QuoteAsset:
        if value is None or value == "":
            return str.__new__(cls, "")
        return super().__new__(cls, value)


@dataclass(frozen=True, slots=True)
class InstrumentExpiry:
    """Typed expiry wrapper for instrument contracts."""

    value: Timestamp

    def __post_init__(self) -> None:
        object.__setattr__(self, "value", to_timestamp(self.value, field_name="expiry"))

    @classmethod
    def from_value(cls, value: Timestamp | str | int | InstrumentExpiry) -> InstrumentExpiry:
        if isinstance(value, cls):
            return value
        return cls(value=value)

    def isoformat(self) -> str:
        return self.value.isoformat()

    def strftime(self, fmt: str) -> str:
        return self.value.strftime(fmt)

    def __str__(self) -> str:
        return self.value.isoformat()

    def __getattr__(self, name: str) -> Any:
        return getattr(self.value, name)


@dataclass(frozen=True, slots=True)
class AssetSpec:
    """Canonical asset metadata (no venue/exchange-specific rules)."""

    symbol: str
    precision: int
    currency: str | None = None
    display_precision: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: int = 1

    def __post_init__(self) -> None:
        if self.precision < 0:
            raise ValueError("precision must be >= 0")
        if self.display_precision is not None and self.display_precision < 0:
            raise ValueError("display_precision must be >= 0")
        object.__setattr__(self, "symbol", self.symbol.upper())

    def to_dict(self) -> dict[str, Any]:
        return {
            "symbol": self.symbol,
            "precision": self.precision,
            "currency": self.currency,
            "display_precision": self.display_precision,
            "metadata": self.metadata,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> AssetSpec:
        return cls(
            symbol=str(raw["symbol"]),
            precision=int(raw["precision"]),
            currency=raw.get("currency"),
            display_precision=int(raw["display_precision"]) if raw.get("display_precision") is not None else None,
            metadata=dict(raw.get("metadata", {})),
            schema_version=int(raw.get("schema_version", 1)),
        )


@dataclass(frozen=True, slots=True)
class InstrumentSpec:
    """Canonical description of an instrument.

    Encodes base, quote, instrument type, and optional metadata
    (expiry, strike, contract size, etc.).
    """

    base: BaseAsset
    quote: QuoteAsset
    instrument_type: InstrumentType
    expiry: InstrumentExpiry | None = None
    strike: float | None = None
    contract_size: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: int = 1

    def __post_init__(self) -> None:
        object.__setattr__(self, "base", BaseAsset(self.base))
        object.__setattr__(self, "quote", QuoteAsset(self.quote))
        if self.expiry is not None:
            object.__setattr__(self, "expiry", InstrumentExpiry.from_value(self.expiry))
        if self.strike is not None:
            object.__setattr__(self, "strike", float(self.strike))
        if self.contract_size is not None:
            object.__setattr__(self, "contract_size", float(self.contract_size))
        object.__setattr__(self, "metadata", dict(self.metadata))

    def __str__(self) -> str:
        """String representation."""
        if self.quote:
            id_part = f"{self.base}/{self.quote}"
        else:
            id_part = str(self.base)

        parts = [id_part]
        if self.instrument_type != InstrumentType.SPOT:
            parts.append(self.instrument_type.value)
        if self.expiry:
            parts.append(self.expiry.strftime("%Y%m%d"))
        if self.strike is not None:
            parts.append(f"C{int(self.strike)}")
        return ":".join(filter(None, parts))

    def to_dict(self) -> dict[str, Any]:
        return {
            "base": self.base,
            "quote": self.quote,
            "instrument_type": self.instrument_type.value,
            "expiry": self.expiry.isoformat() if self.expiry else None,
            "strike": str(self.strike) if self.strike is not None else None,
            "contract_size": str(self.contract_size) if self.contract_size is not None else None,
            "metadata": self.metadata,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> InstrumentSpec:
        return cls(
            base=str(raw["base"]),
            quote=str(raw["quote"]),
            instrument_type=InstrumentType(raw["instrument_type"]),
            expiry=InstrumentExpiry.from_value(raw["expiry"]) if raw.get("expiry") else None,
            strike=float(raw["strike"]) if raw.get("strike") is not None else None,
            contract_size=float(raw["contract_size"]) if raw.get("contract_size") is not None else None,
            metadata=dict(raw.get("metadata", {})),
            schema_version=int(raw.get("schema_version", 1)),
        )


@dataclass(frozen=True, slots=True)
class NormalizedIdentity:
    """Canonical instrument identity detached from exchange symbol strings."""

    base: BaseAsset
    quote: QuoteAsset
    instrument_type: InstrumentType
    exchange: str | None = None
    expiry: InstrumentExpiry | None = None
    strike: float | None = None
    option_type: str | None = None
    qualifiers: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "base", BaseAsset(self.base))
        object.__setattr__(self, "quote", QuoteAsset(self.quote))
        if self.exchange is not None:
            normalized_exchange = self.exchange.strip().lower()
            object.__setattr__(self, "exchange", normalized_exchange or None)
        if self.expiry is not None:
            object.__setattr__(self, "expiry", InstrumentExpiry.from_value(self.expiry))
        if self.strike is not None:
            object.__setattr__(self, "strike", float(self.strike))
        if self.option_type is not None:
            normalized_option_type = self.option_type.strip().upper()
            if normalized_option_type not in {"C", "P"}:
                raise ValueError("option_type must be 'C' or 'P'")
            object.__setattr__(self, "option_type", normalized_option_type)
        object.__setattr__(self, "qualifiers", tuple(str(v) for v in self.qualifiers))

    def to_spec(self) -> InstrumentSpec:
        metadata: dict[str, Any] = {}
        if self.exchange:
            metadata["exchange"] = self.exchange
        if self.option_type:
            metadata["option_type"] = self.option_type
        if self.qualifiers:
            metadata["qualifiers"] = list(self.qualifiers)
        return InstrumentSpec(
            base=self.base,
            quote=self.quote,
            instrument_type=self.instrument_type,
            expiry=self.expiry,
            strike=self.strike,
            metadata=metadata,
        )

    @classmethod
    def from_spec(cls, spec: InstrumentSpec, *, exchange: str | None = None) -> NormalizedIdentity:
        metadata = spec.metadata
        resolved_exchange = exchange if exchange is not None else metadata.get("exchange")
        option_type = metadata.get("option_type")
        qualifiers = metadata.get("qualifiers")
        return cls(
            base=spec.base,
            quote=spec.quote,
            instrument_type=spec.instrument_type,
            exchange=str(resolved_exchange) if resolved_exchange is not None and resolved_exchange != "*" else None,
            expiry=spec.expiry,
            strike=spec.strike,
            option_type=str(option_type) if option_type is not None else None,
            qualifiers=tuple(str(v) for v in qualifiers) if isinstance(qualifiers, list) else (),
        )


@dataclass(frozen=True, slots=True)
class OptionSpec:
    """Canonical option contract definition."""

    underlying: str
    quote: str
    option_type: str
    strike: Price
    expiry: Timestamp
    style: str = "european"
    contract_size: Price | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: int = 1

    def __post_init__(self) -> None:
        normalized_type = self.option_type.lower().strip()
        if normalized_type not in {"call", "put"}:
            raise ValueError("option_type must be either 'call' or 'put'")
        object.__setattr__(self, "option_type", normalized_type)
        object.__setattr__(self, "underlying", self.underlying.upper())
        object.__setattr__(self, "quote", self.quote.upper())
        object.__setattr__(self, "strike", to_decimal(self.strike, field_name="strike"))
        object.__setattr__(self, "expiry", to_timestamp(self.expiry, field_name="expiry"))
        if self.contract_size is not None:
            object.__setattr__(self, "contract_size", to_decimal(self.contract_size, field_name="contract_size"))

    def to_dict(self) -> dict[str, Any]:
        return {
            "underlying": self.underlying,
            "quote": self.quote,
            "option_type": self.option_type,
            "strike": str(self.strike),
            "expiry": self.expiry.isoformat(),
            "style": self.style,
            "contract_size": str(self.contract_size) if self.contract_size is not None else None,
            "metadata": self.metadata,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> OptionSpec:
        return cls(
            underlying=str(raw["underlying"]),
            quote=str(raw["quote"]),
            option_type=str(raw["option_type"]),
            strike=raw["strike"],
            expiry=raw["expiry"],
            style=str(raw.get("style", "european")),
            contract_size=raw.get("contract_size"),
            metadata=dict(raw.get("metadata", {})),
            schema_version=int(raw.get("schema_version", 1)),
        )


@dataclass(frozen=True, slots=True)
class BondSpec:
    """Canonical bond contract definition."""

    issuer: str
    currency: str
    coupon_rate: Rate
    maturity: Timestamp
    face_value: Price
    day_count_convention: str = "30/360"
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: int = 1

    def __post_init__(self) -> None:
        object.__setattr__(self, "issuer", self.issuer.strip())
        object.__setattr__(self, "currency", self.currency.upper())
        object.__setattr__(self, "coupon_rate", to_decimal(self.coupon_rate, field_name="coupon_rate"))
        object.__setattr__(self, "maturity", to_timestamp(self.maturity, field_name="maturity"))
        object.__setattr__(self, "face_value", to_decimal(self.face_value, field_name="face_value"))

    def to_dict(self) -> dict[str, Any]:
        return {
            "issuer": self.issuer,
            "currency": self.currency,
            "coupon_rate": str(self.coupon_rate),
            "maturity": self.maturity.isoformat(),
            "face_value": str(self.face_value),
            "day_count_convention": self.day_count_convention,
            "metadata": self.metadata,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> BondSpec:
        return cls(
            issuer=str(raw["issuer"]),
            currency=str(raw["currency"]),
            coupon_rate=raw["coupon_rate"],
            maturity=raw["maturity"],
            face_value=raw["face_value"],
            day_count_convention=str(raw.get("day_count_convention", "30/360")),
            metadata=dict(raw.get("metadata", {})),
            schema_version=int(raw.get("schema_version", 1)),
        )
