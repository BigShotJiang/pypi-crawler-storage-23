"""Trading order models and enums."""

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from ..ids import order_id
from ..normalization import to_decimal, to_timestamp
from ..types import Price, Qty, Symbol, Timestamp


class OrderSide(StrEnum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(StrEnum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP = "STOP"
    STOP_LIMIT = "STOP_LIMIT"


class OrderStatus(StrEnum):
    PENDING = "PENDING"
    FILLED = "FILLED"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"


@dataclass(slots=True)
class Order:
    """Mutable order state model used by execution engines and orchestrators."""

    id: order_id | str
    symbol: Symbol
    side: OrderSide | str
    type: OrderType | str
    qty: Qty
    price: Price | None = None
    stop_price: Price | None = None
    status: OrderStatus | str = OrderStatus.PENDING
    timestamp: Timestamp = field(default_factory=lambda: datetime.now(UTC))
    label: str = ""
    schema_version: int = 1

    def __post_init__(self) -> None:
        self.id = str(self.id)
        self.side = OrderSide(self.side)
        self.type = OrderType(self.type)
        self.status = OrderStatus(self.status)
        self.qty = to_decimal(self.qty, field_name="qty")
        self.timestamp = to_timestamp(self.timestamp, field_name="timestamp")
        if self.price is not None:
            self.price = to_decimal(self.price, field_name="price")
        if self.stop_price is not None:
            self.stop_price = to_decimal(self.stop_price, field_name="stop_price")

        if self.qty <= 0:
            raise ValueError("Order quantity must be positive")
        if self.type in {OrderType.LIMIT, OrderType.STOP_LIMIT} and self.price is None:
            raise ValueError(f"Limit price required for {self.type} orders")
        if self.type in {OrderType.STOP, OrderType.STOP_LIMIT} and self.stop_price is None:
            raise ValueError(f"Stop price required for {self.type} orders")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "symbol": self.symbol,
            "side": self.side.value,
            "type": self.type.value,
            "qty": str(self.qty),
            "price": str(self.price) if self.price is not None else None,
            "stop_price": str(self.stop_price) if self.stop_price is not None else None,
            "status": self.status.value,
            "timestamp": self.timestamp.isoformat(),
            "label": self.label,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Order":
        return cls(
            id=str(raw["id"]),
            symbol=str(raw["symbol"]),
            side=str(raw["side"]),
            type=str(raw["type"]),
            qty=raw["qty"],
            price=raw.get("price"),
            stop_price=raw.get("stop_price"),
            status=str(raw.get("status", OrderStatus.PENDING.value)),
            timestamp=raw.get("timestamp", datetime.now(UTC)),
            label=str(raw.get("label", "")),
            schema_version=int(raw.get("schema_version", 1)),
        )
