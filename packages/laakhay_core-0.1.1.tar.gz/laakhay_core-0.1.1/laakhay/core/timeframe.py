"""Timeframe utilities and constants."""

from __future__ import annotations

import re
from enum import StrEnum


class TimeframeUnit(StrEnum):
    MINUTE = "m"
    HOUR = "h"
    DAY = "d"
    WEEK = "w"
    MONTH = "M"


class Timeframe(str):
    """Trading timeframe representation (e.g., '1m', '5m', '1h', '1d')."""

    _PATTERN = re.compile(r"^(\d+)([mhdwM])$")

    def __new__(cls, value: str):
        if not isinstance(value, str):
            raise TypeError(f"Timeframe must be a string, got {type(value)}")
        match = cls._PATTERN.match(value)
        if not match:
            raise ValueError(f"Invalid timeframe format: {value}. Expected format like '1m', '15m', '1h', '1d'.")
        amount = int(match.group(1))
        if amount <= 0:
            raise ValueError(f"Timeframe amount must be positive, got {amount}")

        return str.__new__(cls, value)

    @property
    def amount(self) -> int:
        match = self._PATTERN.match(self)
        return int(match.group(1))

    @property
    def unit(self) -> TimeframeUnit:
        match = self._PATTERN.match(self)
        return TimeframeUnit(match.group(2))

    @property
    def seconds(self) -> int:
        """Total seconds in this timeframe."""
        if self.unit == TimeframeUnit.MONTH:
            raise ValueError(
                "Month-based timeframe cannot be represented as fixed seconds; "
                "use calendar-aware logic in downstream engines.",
            )
        multipliers = {
            TimeframeUnit.MINUTE: 60,
            TimeframeUnit.HOUR: 3600,
            TimeframeUnit.DAY: 86400,
            TimeframeUnit.WEEK: 604800,
        }
        return self.amount * multipliers[self.unit]

    @property
    def milliseconds(self) -> int:
        """Total milliseconds in this timeframe."""
        return self.seconds * 1000

    @property
    def minutes(self) -> int:
        """Total minutes in this timeframe."""
        return self.seconds // 60

    def __str__(self) -> str:
        return str.__str__(self)

    def __repr__(self) -> str:
        return f"Timeframe('{str(self)}')"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Timeframe):
            return self.seconds == other.seconds
        if isinstance(other, str):
            try:
                return self.seconds == Timeframe(other).seconds
            except ValueError:
                return False
        return False

    def __hash__(self) -> int:
        return str.__hash__(self)

    @classmethod
    def coerce(cls, value: str | Timeframe) -> Timeframe:
        """Coerce a string or Timeframe object into a Timeframe instance."""
        if isinstance(value, cls):
            return value
        return cls(str(value))

    @classmethod
    def from_seconds(cls, seconds: int) -> Timeframe | None:
        """Coerce seconds into a standard Timeframe if exactly matching."""
        if seconds % 86400 == 0:
            return cls(f"{seconds // 86400}d")
        if seconds % 3600 == 0:
            return cls(f"{seconds // 3600}h")
        if seconds % 60 == 0:
            return cls(f"{seconds // 60}m")
        return None
