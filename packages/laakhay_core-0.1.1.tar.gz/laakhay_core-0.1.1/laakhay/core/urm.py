"""Universal Representation Mapping (URM) contracts and pure utilities.

Canonical URM format:
    urm://{venue}:{identity}:{instrument}[?k=v&k=v...]
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Protocol, runtime_checkable
from urllib.parse import parse_qsl, urlencode

from .enums import InstrumentType, MarketType
from .exceptions import SymbolResolutionError
from .models.instrument import InstrumentExpiry, InstrumentSpec, NormalizedIdentity

_URM_ID_PATTERN = re.compile(r"^urm://([^:/?]+):([^:?]+):([^?]+)(?:\?(.*))?$")
_DATE_YYYYMMDD = re.compile(r"^\d{8}$")
_DATE_YYYY_MM_DD = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_NUMERIC = re.compile(r"^\d+(\.\d+)?$")

_VENUE_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]*$")
_QUERY_KEY_PATTERN = re.compile(r"^[a-z][a-z0-9_]*$")
_INSTRUMENT_ALIASES: dict[str, InstrumentType] = {
    "spot": InstrumentType.SPOT,
    "equity": InstrumentType.SPOT,
    "perp": InstrumentType.PERPETUAL,
    "perpetual": InstrumentType.PERPETUAL,
    "future": InstrumentType.FUTURE,
    "option": InstrumentType.OPTION,
}

COMMON_QUOTES = {
    "USDT",
    "USDC",
    "USD",
    "BTC",
    "ETH",
    "BNB",
    "EUR",
    "JPY",
    "GBP",
    "AUD",
}


def _canonical_number(value: float) -> str:
    return str(int(value)) if float(value).is_integer() else str(value)


def _canonical_expiry_date(value: InstrumentExpiry) -> str:
    return value.strftime("%Y-%m-%d")


def _parse_expiry(value: str, *, urm_id: str) -> InstrumentExpiry:
    if _DATE_YYYYMMDD.match(value):
        return InstrumentExpiry(datetime.strptime(value, "%Y%m%d"))
    if _DATE_YYYY_MM_DD.match(value):
        return InstrumentExpiry(datetime.strptime(value, "%Y-%m-%d"))
    raise SymbolResolutionError(
        "expiry must be YYYYMMDD or YYYY-MM-DD",
        value=urm_id,
    )


def _split_identity(identity: str, *, urm_id: str) -> tuple[str, str]:
    normalized = identity.strip().upper()
    if not normalized:
        raise SymbolResolutionError("identity cannot be empty", value=urm_id)

    if "/" in normalized:
        parts = normalized.split("/")
        if len(parts) != 2:
            raise SymbolResolutionError("identity must be BASE/QUOTE or ASSET", value=urm_id)
        base, quote = parts
        if not base or not quote:
            raise SymbolResolutionError("identity base/quote cannot be empty", value=urm_id)
        return base, quote
    return normalized, ""


def _qualifiers_from_query_items(
    query_items: list[tuple[str, str]],
    *,
    urm_id: str,
) -> tuple[str, ...]:
    seen_keys: set[str] = set()
    qualifiers: list[str] = []
    for raw_key, raw_value in query_items:
        key = raw_key.strip().lower()
        value = raw_value.strip()
        if not key:
            raise SymbolResolutionError("query key cannot be empty", value=urm_id)
        if key in seen_keys:
            raise SymbolResolutionError(
                f"duplicate query key '{key}' is not allowed",
                value=urm_id,
            )
        seen_keys.add(key)

        if not _QUERY_KEY_PATTERN.match(key):
            raise SymbolResolutionError(f"invalid query key '{key}'", value=urm_id)
        if value == "":
            raise SymbolResolutionError(f"query value for '{key}' cannot be empty", value=urm_id)

        qualifiers.append(f"{key}={value}")

    return tuple(qualifiers)


def _query_items_from_identity(identity: NormalizedIdentity) -> list[tuple[str, str]]:
    items: list[tuple[str, str]] = []
    if identity.option_type in {"C", "P"}:
        items.append(("right", identity.option_type.lower()))
    if identity.strike is not None:
        items.append(("strike", _canonical_number(identity.strike)))
    if identity.expiry is not None:
        items.append(("expiry", _canonical_expiry_date(identity.expiry)))

    for qualifier in identity.qualifiers:
        if "=" not in qualifier:
            raise SymbolResolutionError(
                "qualifiers must use 'key=value' format under canonical URM",
                value=qualifier,
            )
        key, value = qualifier.split("=", 1)
        key = key.strip().lower()
        value = value.strip()
        if not key or not value:
            raise SymbolResolutionError(
                "qualifiers must use non-empty 'key=value' pairs",
                value=qualifier,
            )
        if key in {"right", "strike", "expiry"}:
            continue
        items.append((key, value))

    seen_keys: set[str] = set()
    for key, _ in items:
        if key in seen_keys:
            raise SymbolResolutionError(
                f"duplicate query key '{key}' is not allowed",
                value=key,
            )
        seen_keys.add(key)

    return sorted(items, key=lambda item: item[0])


def _instrument_token_to_type(token: str, *, urm_id: str) -> InstrumentType:
    normalized = token.strip().lower()
    if normalized in _INSTRUMENT_ALIASES:
        return _INSTRUMENT_ALIASES[normalized]
    raise SymbolResolutionError(
        f"Invalid instrument in URM ID: {token}",
        value=urm_id,
    )


def _identity_to_instrument_token(identity: NormalizedIdentity) -> str:
    if identity.instrument_type == InstrumentType.SPOT:
        return "equity" if not identity.quote else "spot"
    if identity.instrument_type == InstrumentType.PERPETUAL:
        return "perp"
    if identity.instrument_type == InstrumentType.FUTURE:
        return "future"
    if identity.instrument_type == InstrumentType.OPTION:
        return "option"
    return identity.instrument_type.value


@runtime_checkable
class UniversalRepresentationMapper(Protocol):
    """Protocol for exchange-specific symbol mappers."""

    def to_spec(
        self,
        exchange_symbol: str,
        *,
        market_type: MarketType,
    ) -> InstrumentSpec:
        """Convert exchange-native symbol to canonical InstrumentSpec."""
        ...

    def to_exchange_symbol(
        self,
        spec: InstrumentSpec,
        *,
        market_type: MarketType,
    ) -> str:
        """Convert canonical InstrumentSpec to exchange-native symbol."""
        ...

    def clear_cache(self) -> None:
        """Clear internal mapper caches (if any)."""
        ...


class BaseURMMapper(ABC):
    """Abstract base mapper to extend in data libraries."""

    def __init__(self) -> None:
        self._supported_quotes: set[str] = set(COMMON_QUOTES)

    def set_quotes(self, quotes: set[str] | list[str]) -> None:
        """Set known quote assets for this exchange to assist in symbol splitting."""
        self._supported_quotes = {q.upper() for q in quotes}

    def to_spec(
        self,
        exchange_symbol: str,
        *,
        market_type: MarketType,
    ) -> InstrumentSpec:
        symbol = self._normalize_symbol(exchange_symbol)
        spec = self._to_spec_impl(symbol, market_type=market_type)
        self._validate_spec(spec, exchange_symbol=symbol, market_type=market_type)
        return spec

    def to_exchange_symbol(
        self,
        spec: InstrumentSpec,
        *,
        market_type: MarketType,
    ) -> str:
        symbol = self._to_exchange_symbol_impl(spec, market_type=market_type)
        return self._normalize_symbol(symbol)

    def clear_cache(self) -> None:
        """No-op by default; subclasses may override."""
        return

    @abstractmethod
    def _to_spec_impl(
        self,
        exchange_symbol: str,
        *,
        market_type: MarketType,
    ) -> InstrumentSpec:
        """Subclass hook: symbol -> spec conversion logic."""

    @abstractmethod
    def _to_exchange_symbol_impl(
        self,
        spec: InstrumentSpec,
        *,
        market_type: MarketType,
    ) -> str:
        """Subclass hook: spec -> symbol conversion logic."""

    def _split_base_quote(self, symbol: str) -> tuple[str, str]:
        """Split symbol into base and quote using supported quotes if available."""
        sorted_quotes = sorted(self._supported_quotes, key=len, reverse=True)
        for quote in sorted_quotes:
            if symbol.endswith(quote):
                base = symbol[: -len(quote)]
                if base:
                    return base, quote

        raise SymbolResolutionError(
            f"Cannot split symbol '{symbol}' into base/quote without metadata",
            value=symbol,
        )

    def _normalize_symbol(self, exchange_symbol: str) -> str:
        symbol = exchange_symbol.strip()
        if not symbol:
            raise SymbolResolutionError("Symbol cannot be empty", value=exchange_symbol)
        return symbol

    def _validate_spec(
        self,
        spec: InstrumentSpec,
        *,
        exchange_symbol: str,
        market_type: MarketType,
    ) -> None:
        if not isinstance(spec, InstrumentSpec):
            raise SymbolResolutionError(
                "Mapper returned invalid spec type",
                value=exchange_symbol,
                market_type=market_type,
            )
        if not spec.base:
            raise SymbolResolutionError(
                "InstrumentSpec must have a base asset",
                value=exchange_symbol,
                market_type=market_type,
            )


def parse_urm_identity(urm_id: str) -> NormalizedIdentity:
    """Parse canonical URM into typed NormalizedIdentity.

    Format:
        urm://{venue}:{identity}:{instrument}[?k=v&k=v...]
    """
    match = _URM_ID_PATTERN.match(urm_id)
    if not match:
        raise SymbolResolutionError(
            f"Invalid URM ID format: {urm_id}",
            value=urm_id,
        )

    venue_raw, identity_raw, instrument_raw, query_raw = match.groups()
    venue = venue_raw.strip().lower()
    if venue != "*" and not _VENUE_PATTERN.match(venue):
        raise SymbolResolutionError(f"Invalid venue in URM ID: {venue_raw}", value=urm_id)

    instrument_type = _instrument_token_to_type(instrument_raw, urm_id=urm_id)

    query_items = parse_qsl(query_raw or "", keep_blank_values=True, strict_parsing=bool(query_raw))
    qualifiers = _qualifiers_from_query_items(query_items, urm_id=urm_id)

    params: dict[str, str] = {}
    for item in qualifiers:
        key, value = item.split("=", 1)
        params[key] = value

    option_type: str | None = None
    if "right" in params:
        normalized_right = params["right"].strip().lower()
        if normalized_right not in {"c", "p"}:
            raise SymbolResolutionError("right must be c or p", value=urm_id)
        option_type = normalized_right.upper()

    strike: float | None = None
    if "strike" in params:
        strike_raw = params["strike"]
        if not _NUMERIC.match(strike_raw):
            raise SymbolResolutionError("strike must be numeric", value=urm_id)
        strike = float(strike_raw)

    expiry: InstrumentExpiry | None = None
    if "expiry" in params:
        expiry = _parse_expiry(params["expiry"], urm_id=urm_id)

    base, quote = _split_identity(identity_raw, urm_id=urm_id)

    if "margin" in params:
        params["margin"] = params["margin"].lower()

    passthrough_qualifiers = tuple(
        f"{key}={value}" for key, value in params.items() if key not in {"right", "strike", "expiry"}
    )

    return NormalizedIdentity(
        base=base,
        quote=quote,
        instrument_type=instrument_type,
        exchange=venue if venue != "*" else None,
        expiry=expiry,
        strike=strike,
        option_type=option_type,
        qualifiers=passthrough_qualifiers,
    )


def identity_to_urm_id(identity: NormalizedIdentity) -> str:
    """Convert NormalizedIdentity to canonical URM string."""
    venue = (identity.exchange or "*").lower()
    if venue != "*" and not _VENUE_PATTERN.match(venue):
        raise SymbolResolutionError(f"Invalid venue in identity: {venue}", value=venue)

    id_part = identity.base.lower() if not identity.quote else f"{identity.base.lower()}/{identity.quote.lower()}"
    instrument_token = _identity_to_instrument_token(identity)
    base = f"urm://{venue}:{id_part}:{instrument_token}"
    query_items = _query_items_from_identity(identity)
    if not query_items:
        return base
    return f"{base}?{urlencode(query_items)}"


def parse_urm_id(urm_id: str) -> InstrumentSpec:
    """Parse canonical URM into InstrumentSpec."""
    return parse_urm_identity(urm_id).to_spec()


def spec_to_urm_id(spec: InstrumentSpec, *, exchange: str | None = None) -> str:
    """Convert InstrumentSpec to canonical URM string."""
    return identity_to_urm_id(NormalizedIdentity.from_spec(spec, exchange=exchange))


def validate_urm_id(urm_id: str) -> bool:
    """Return True if URM parses successfully, else False."""
    try:
        parse_urm_id(urm_id)
        return True
    except SymbolResolutionError:
        return False
