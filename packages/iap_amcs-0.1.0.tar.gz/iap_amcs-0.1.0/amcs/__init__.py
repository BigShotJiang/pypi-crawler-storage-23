"""AMCS package public exports."""

from amcs.canonical_json import canonical_bytes, canonical_dumps
from amcs.crypto import (
    b64decode,
    b64encode,
    decrypt_field,
    encrypt_field,
    generate_keypair,
    sign,
    verify,
)
from amcs.hashing import event_hash, sha256_hex
from amcs.merkle import build_inclusion_proof, merkle_root_hex, verify_inclusion_proof
from amcs.sdk import (
    AMCSClient,
    AppendResult,
    RootCheckpoint,
    VerificationResult,
    action_invoke_payload,
    build_root_checkpoint,
    capability_update_payload,
    interaction_append_payload,
    memory_upsert_payload,
    objective_update_payload,
    policy_update_payload,
    verify_chain,
    verify_root_checkpoint,
)
from amcs.store import EventStore, SQLiteEventStore
from amcs.types import build_event_envelope, validate_event_envelope
from amcs.version import __version__

__all__ = [
    "__version__",
    "canonical_dumps",
    "canonical_bytes",
    "build_event_envelope",
    "validate_event_envelope",
    "sha256_hex",
    "event_hash",
    "merkle_root_hex",
    "build_inclusion_proof",
    "verify_inclusion_proof",
    "EventStore",
    "SQLiteEventStore",
    "AMCSClient",
    "AppendResult",
    "RootCheckpoint",
    "interaction_append_payload",
    "memory_upsert_payload",
    "action_invoke_payload",
    "objective_update_payload",
    "policy_update_payload",
    "capability_update_payload",
    "verify_chain",
    "build_root_checkpoint",
    "verify_root_checkpoint",
    "VerificationResult",
    "encrypt_field",
    "decrypt_field",
    "generate_keypair",
    "sign",
    "verify",
    "b64encode",
    "b64decode",
]
