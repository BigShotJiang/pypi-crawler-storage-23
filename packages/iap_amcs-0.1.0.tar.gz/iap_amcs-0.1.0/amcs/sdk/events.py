"""Standard payload builders for AMCS event types."""

from __future__ import annotations

from typing import Any


def _require_confidence_str(confidence: str) -> str:
    if not isinstance(confidence, str):
        raise TypeError("confidence must be a string")
    return confidence


def interaction_append_payload(
    *,
    role: str,
    content: str,
    turn_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload = {
        "role": role,
        "content": content,
        "metadata": metadata or {},
    }
    if turn_id is not None:
        payload["turn_id"] = turn_id
    return payload


def memory_upsert_payload(
    *,
    memory_id: str,
    content: str,
    confidence: str = "1.0",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "memory_id": memory_id,
        "content": content,
        "confidence": _require_confidence_str(confidence),
        "metadata": metadata or {},
    }


def action_invoke_payload(
    *,
    action_name: str,
    arguments: dict[str, Any],
    status: str = "requested",
) -> dict[str, Any]:
    return {
        "action_name": action_name,
        "arguments": arguments,
        "status": status,
    }


def objective_update_payload(
    *,
    objective_id: str,
    status: str,
    detail: str | None = None,
) -> dict[str, Any]:
    payload = {
        "objective_id": objective_id,
        "status": status,
    }
    if detail is not None:
        payload["detail"] = detail
    return payload


def policy_update_payload(
    *,
    policy_id: str,
    changes: dict[str, Any],
    rationale: str | None = None,
) -> dict[str, Any]:
    payload = {
        "policy_id": policy_id,
        "changes": changes,
    }
    if rationale is not None:
        payload["rationale"] = rationale
    return payload


def capability_update_payload(
    *,
    capability_name: str,
    enabled: bool,
    confidence: str = "1.0",
) -> dict[str, Any]:
    return {
        "capability_name": capability_name,
        "enabled": enabled,
        "confidence": _require_confidence_str(confidence),
    }
