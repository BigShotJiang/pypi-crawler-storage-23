"""Hashing primitives for AMCS events."""

from __future__ import annotations

import hashlib

from amcs.canonical_json import canonical_bytes


def sha256_hex(data: bytes) -> str:
    """Return the SHA-256 hex digest for raw bytes."""
    return hashlib.sha256(data).hexdigest()


def event_hash(event_envelope: dict) -> str:
    """Compute deterministic event hash from canonical JSON bytes."""
    return sha256_hex(canonical_bytes(event_envelope))
