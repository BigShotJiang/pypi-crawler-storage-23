"""Store interfaces for AMCS event persistence."""

from __future__ import annotations

from typing import Any, Protocol


class EventStore(Protocol):
    """Protocol for append-only AMCS event stores."""

    def append_event(self, agent_id: str, event_envelope: dict[str, Any]) -> dict[str, Any]:
        ...

    def get_events(
        self,
        agent_id: str,
        from_seq: int = 1,
        to_seq: int | None = None,
    ) -> list[dict[str, Any]]:
        ...

    def get_event_hashes(
        self,
        agent_id: str,
        from_seq: int,
        to_seq: int,
    ) -> list[str]:
        ...

    def get_latest_sequence(self, agent_id: str) -> int | None:
        ...

    def get_memory_root(self, agent_id: str, seq: int | None = None) -> str | None:
        ...
