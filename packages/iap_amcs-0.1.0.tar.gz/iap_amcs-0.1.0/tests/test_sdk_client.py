from amcs.sdk.client import AMCSClient
from amcs.store.sqlite import SQLiteEventStore


def test_sdk_append_returns_sequence_hash_and_root(tmp_path) -> None:
    store = SQLiteEventStore(str(tmp_path / "events.db"))
    client = AMCSClient(store=store, agent_id="agent-1")

    result = client.append(
        "interaction.append",
        {"message": "hello"},
        scope="private",
        tags=["test"],
    )

    assert result.agent_id == "agent-1"
    assert result.sequence == 1
    assert isinstance(result.event_hash, str) and len(result.event_hash) == 64
    assert isinstance(result.memory_root, str) and len(result.memory_root) == 64


def test_sdk_get_memory_root_for_latest_and_specific_sequence(tmp_path) -> None:
    store = SQLiteEventStore(str(tmp_path / "events.db"))
    client = AMCSClient(store=store, agent_id="agent-1")

    first = client.append("interaction.append", {"message": "one"})
    second = client.append("interaction.append", {"message": "two"})

    assert client.get_memory_root(1) == first.memory_root
    assert client.get_memory_root() == second.memory_root
