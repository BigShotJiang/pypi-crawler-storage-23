from amcs.merkle import EMPTY_MERKLE_ROOT_HEX, merkle_root_hex


def test_merkle_root_empty_list_returns_documented_constant() -> None:
    assert merkle_root_hex([]) == EMPTY_MERKLE_ROOT_HEX
    assert EMPTY_MERKLE_ROOT_HEX == (
        "e3b0c44298fc1c149afbf4c8996fb924"
        "27ae41e4649b934ca495991b7852b855"
    )


def test_merkle_root_single_leaf_returns_leaf() -> None:
    leaf = "ca978112ca1bbdcafac231b39a23dc4d"
    leaf += "a786eff8147c4e72b9807785afee48bb"

    assert merkle_root_hex([leaf]) == leaf


def test_merkle_root_known_three_leaf_vector_with_odd_duplication() -> None:
    leaves = [
        "ca978112ca1bbdcafac231b39a23dc4d"
        "a786eff8147c4e72b9807785afee48bb",  # sha256("a")
        "3e23e8160039594a33894f6564e1b134"
        "8bbd7a0088d42c4acb73eeaed59c009d",  # sha256("b")
        "2e7d2c03a9507ae265ecf5b5356885a5"
        "3393a2029d241394997265a1a25aefc6",  # sha256("c")
    ]

    assert merkle_root_hex(leaves) == (
        "d31a37ef6ac14a2db1470c4316beb559"
        "2e6afd4465022339adafda76a18ffabe"
    )
