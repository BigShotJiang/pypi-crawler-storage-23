from amcs.merkle import build_inclusion_proof, merkle_root_hex, verify_inclusion_proof


def test_inclusion_proof_verifies_for_correct_leaf_and_root() -> None:
    leaves = [
        "ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb",
        "3e23e8160039594a33894f6564e1b1348bbd7a0088d42c4acb73eeaed59c009d",
        "2e7d2c03a9507ae265ecf5b5356885a53393a2029d241394997265a1a25aefc6",
    ]

    root = merkle_root_hex(leaves)
    proof = build_inclusion_proof(leaves, 1)

    assert verify_inclusion_proof(leaves[1], proof, root) is True


def test_inclusion_proof_fails_for_wrong_leaf_or_root() -> None:
    leaves = [
        "ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb",
        "3e23e8160039594a33894f6564e1b1348bbd7a0088d42c4acb73eeaed59c009d",
        "2e7d2c03a9507ae265ecf5b5356885a53393a2029d241394997265a1a25aefc6",
    ]

    root = merkle_root_hex(leaves)
    proof = build_inclusion_proof(leaves, 1)

    wrong_leaf = leaves[0]
    wrong_root = "0" * 64

    assert verify_inclusion_proof(wrong_leaf, proof, root) is False
    assert verify_inclusion_proof(leaves[1], proof, wrong_root) is False
