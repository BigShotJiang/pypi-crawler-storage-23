import pytest

from amcs.types import EventValidationError, build_event_envelope, validate_event_envelope


def test_build_event_envelope_sets_defaults() -> None:
    event = build_event_envelope(
        agent_id="agent-1",
        event_type="interaction.append",
        payload={"message": "hello"},
    )

    assert event["agent_id"] == "agent-1"
    assert event["amcs_version"] == "AMCS-0.1"
    assert event["sequence"] is None
    assert event["event_type"] == "interaction.append"
    assert event["payload"] == {"message": "hello"}
    assert event["scope"] == "private"
    assert event["tags"] == []
    assert isinstance(event["event_id"], str) and event["event_id"]
    assert isinstance(event["timestamp"], str) and event["timestamp"]


def test_validate_rejects_invalid_scope() -> None:
    event = build_event_envelope(
        agent_id="agent-1",
        event_type="interaction.append",
        payload={"message": "hello"},
    )
    event["scope"] = "team"

    with pytest.raises(EventValidationError, match="scope must be one of"):
        validate_event_envelope(event)


def test_validate_rejects_missing_required_fields() -> None:
    event = {
        "amcs_version": "AMCS-0.1",
        "event_id": "evt-1",
        "agent_id": "agent-1",
        "sequence": None,
        "payload": {},
        "scope": "private",
        "timestamp": "2026-02-19T00:00:00Z",
    }

    with pytest.raises(EventValidationError, match="Missing required field"):
        validate_event_envelope(event)


def test_validate_rejects_missing_amcs_version() -> None:
    event = build_event_envelope(
        agent_id="agent-1",
        event_type="interaction.append",
        payload={"message": "hello"},
    )
    del event["amcs_version"]

    with pytest.raises(EventValidationError, match="Missing required field"):
        validate_event_envelope(event)


def test_validate_rejects_wrong_amcs_version() -> None:
    event = build_event_envelope(
        agent_id="agent-1",
        event_type="interaction.append",
        payload={"message": "hello"},
    )
    event["amcs_version"] = "AMCS-0.2"

    with pytest.raises(EventValidationError, match="amcs_version must be exactly AMCS-0.1"):
        validate_event_envelope(event)


def test_validate_rejects_non_uuid4_event_id() -> None:
    event = build_event_envelope(
        agent_id="agent-1",
        event_type="interaction.append",
        payload={"message": "hello"},
    )
    event["event_id"] = "evt-1"

    with pytest.raises(EventValidationError, match="event_id must be a valid UUID"):
        validate_event_envelope(event)


def test_validate_rejects_invalid_timestamp_format() -> None:
    event = build_event_envelope(
        agent_id="agent-1",
        event_type="interaction.append",
        payload={"message": "hello"},
    )
    event["timestamp"] = "not-a-timestamp"

    with pytest.raises(EventValidationError, match="timestamp must be a valid RFC3339 timestamp"):
        validate_event_envelope(event)
