import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from amcs import __version__


def test_import_and_version() -> None:
    assert isinstance(__version__, str)
    assert __version__
