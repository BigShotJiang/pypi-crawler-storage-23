from amcs.hashing import event_hash, sha256_hex


def test_sha256_hex_matches_known_vector() -> None:
    assert sha256_hex(b"abc") == (
        "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
    )


def test_event_hash_is_stable_across_key_order() -> None:
    event_a = {
        "event_id": "evt-1",
        "agent_id": "agent-1",
        "event_type": "interaction.append",
        "timestamp": "2026-02-19T00:00:00Z",
        "scope": "private",
        "payload": {"a": 1, "b": 2},
        "tags": ["x", "y"],
    }
    event_b = {
        "tags": ["x", "y"],
        "scope": "private",
        "payload": {"b": 2, "a": 1},
        "timestamp": "2026-02-19T00:00:00Z",
        "event_type": "interaction.append",
        "agent_id": "agent-1",
        "event_id": "evt-1",
    }

    assert event_hash(event_a) == event_hash(event_b)


def test_event_hash_changes_when_payload_changes() -> None:
    base_event = {
        "event_id": "evt-1",
        "agent_id": "agent-1",
        "event_type": "interaction.append",
        "timestamp": "2026-02-19T00:00:00Z",
        "scope": "private",
        "payload": {"text": "hello"},
        "tags": [],
    }

    changed_event = {
        **base_event,
        "payload": {"text": "hello!"},
    }

    assert event_hash(base_event) != event_hash(changed_event)
