from fastapi.testclient import TestClient

from amcs.api.app import create_app
from amcs.store.sqlite import SQLiteEventStore
from amcs.types import build_event_envelope


def _seed(db_path: str) -> None:
    store = SQLiteEventStore(db_path)
    store.append_event(
        "agent-1",
        build_event_envelope(
            agent_id="agent-1",
            event_type="interaction.append",
            payload={"message": "hello"},
            timestamp="2026-02-19T00:00:01Z",
        ),
    )


def test_get_root_endpoint(tmp_path) -> None:
    db_path = str(tmp_path / "events.db")
    _seed(db_path)
    app = create_app(db_path)
    client = TestClient(app)

    response = client.get("/agents/agent-1/root")
    assert response.status_code == 200
    body = response.json()
    assert body["agent_id"] == "agent-1"
    assert isinstance(body["memory_root"], str)
    assert len(body["memory_root"]) == 64


def test_verify_endpoint(tmp_path) -> None:
    db_path = str(tmp_path / "events.db")
    _seed(db_path)
    app = create_app(db_path)
    client = TestClient(app)

    response = client.post("/agents/agent-1/verify", json={"from_seq": 1})
    assert response.status_code == 200
    body = response.json()
    assert body["ok"] is True
    assert body["checked_events"] == 1
