import pytest

from amcs.crypto.ed25519 import b64decode, generate_keypair, sign, verify


def test_ed25519_sign_verify_roundtrip() -> None:
    private_key, public_key = generate_keypair()
    message = b"amcs-signature-test"

    sig = sign(private_key, message)

    assert verify(public_key, message, sig) is True


def test_ed25519_verify_fails_when_message_changes() -> None:
    private_key, public_key = generate_keypair()
    sig = sign(private_key, b"hello")

    assert verify(public_key, b"hello!", sig) is False


def test_ed25519_verify_fails_with_wrong_public_key() -> None:
    private_key, _ = generate_keypair()
    _, wrong_public = generate_keypair()
    sig = sign(private_key, b"hello")

    assert verify(wrong_public, b"hello", sig) is False


def test_ed25519_sign_rejects_wrong_private_key_length() -> None:
    with pytest.raises(ValueError, match="private key must be 32 bytes"):
        sign(b"short", b"msg")


def test_ed25519_verify_rejects_wrong_lengths() -> None:
    private_key, public_key = generate_keypair()
    sig = sign(private_key, b"hello")
    assert verify(public_key[:-1], b"hello", sig) is False
    assert verify(public_key, b"hello", sig[:-1]) is False


def test_b64decode_rejects_invalid_input() -> None:
    with pytest.raises(ValueError, match="invalid base64 input"):
        b64decode("***not-base64***")
