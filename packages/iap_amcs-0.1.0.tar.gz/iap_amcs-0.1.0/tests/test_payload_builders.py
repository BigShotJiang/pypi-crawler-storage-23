import pytest

from amcs.sdk.events import (
    action_invoke_payload,
    capability_update_payload,
    interaction_append_payload,
    memory_upsert_payload,
    objective_update_payload,
    policy_update_payload,
)


def test_interaction_append_payload_shape() -> None:
    payload = interaction_append_payload(
        role="assistant",
        content="hello",
        turn_id="turn-1",
        metadata={"channel": "chat"},
    )

    assert payload == {
        "role": "assistant",
        "content": "hello",
        "turn_id": "turn-1",
        "metadata": {"channel": "chat"},
    }


def test_memory_upsert_payload_uses_string_confidence() -> None:
    payload = memory_upsert_payload(memory_id="mem-1", content="fact", confidence="0.92")
    assert payload["confidence"] == "0.92"

    with pytest.raises(TypeError, match="confidence must be a string"):
        memory_upsert_payload(memory_id="mem-1", content="fact", confidence=0.92)  # type: ignore[arg-type]


def test_action_objective_policy_capability_shapes() -> None:
    action = action_invoke_payload(action_name="search", arguments={"q": "amcs"})
    objective = objective_update_payload(objective_id="obj-1", status="active", detail="started")
    policy = policy_update_payload(
        policy_id="pol-1",
        changes={"allow": ["read"]},
        rationale="needed",
    )
    capability = capability_update_payload(capability_name="web", enabled=True, confidence="0.8")

    assert action == {"action_name": "search", "arguments": {"q": "amcs"}, "status": "requested"}
    assert objective == {"objective_id": "obj-1", "status": "active", "detail": "started"}
    assert policy == {"policy_id": "pol-1", "changes": {"allow": ["read"]}, "rationale": "needed"}
    assert capability == {"capability_name": "web", "enabled": True, "confidence": "0.8"}
