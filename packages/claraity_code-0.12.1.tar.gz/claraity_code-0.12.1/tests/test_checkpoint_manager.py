"""
Unit Tests for CheckpointManager

Tests checkpoint save/load/restore functionality with comprehensive coverage.

Coverage targets:
- Save checkpoint: Create and verify checkpoint files
- Load checkpoint: Restore from disk with data integrity
- Restore to agent: Populate agent memory from checkpoint
- List checkpoints: Query available checkpoints
- Auto-cleanup: Delete old checkpoints when limit exceeded
- Error handling: Corrupted files, missing files, etc.
"""

import json
import os
import pytest
import tempfile
from datetime import datetime
from pathlib import Path
from unittest.mock import Mock, MagicMock

from src.execution.checkpoint import CheckpointManager, ExecutionCheckpoint, CheckpointMetadata


class TestCheckpointManager:
    """Test suite for CheckpointManager"""

    @pytest.fixture
    def temp_checkpoint_dir(self):
        """Create temporary directory for checkpoints"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield tmpdir

    @pytest.fixture
    def checkpoint_manager(self, temp_checkpoint_dir):
        """Create CheckpointManager with temporary directory"""
        return CheckpointManager(
            checkpoint_dir=temp_checkpoint_dir,
            max_checkpoints=3
        )

    @pytest.fixture
    def mock_agent(self):
        """Create mock CodingAgent with memory and tool history"""
        agent = Mock()

        # Prevent Mock auto-creation of attributes that get serialized
        agent.current_todos = []
        agent.model_name = "test-model"
        agent.context_window = 8192

        # Mock memory structure
        agent.memory = Mock()

        # Mock working memory with messages
        working_memory = Mock()
        message1 = Mock()
        message1.role = Mock(value="user")
        message1.content = "Create a calculator"
        message1.timestamp = datetime.now()

        message2 = Mock()
        message2.role = Mock(value="assistant")
        message2.content = "I'll create a calculator for you"
        message2.timestamp = datetime.now()

        working_memory.messages = [message1, message2]
        agent.memory.working_memory = working_memory

        # Mock episodic memory
        episodic_memory = Mock()
        episodic_memory.compressed_history = [
            "Session 1: Discussed calculator requirements",
            "Session 2: Implemented basic operations"
        ]
        agent.memory.episodic_memory = episodic_memory

        # Mock task context
        task_context = Mock()
        task_context.project_type = "Python CLI Tool"
        task_context.key_files = ["calculator.py", "test_calculator.py"]
        task_context.key_concepts = ["arithmetic operations", "user input"]
        agent.memory.task_context = task_context

        # Mock tool execution history
        agent.tool_execution_history = [
            {
                "tool": "write_file",
                "arguments": {"file_path": "calculator.py", "content": "# Calculator"},
                "success": True
            },
            {
                "tool": "edit_file",
                "arguments": {"file_path": "calculator.py", "old_string": "# Calculator", "new_string": "# Calculator v1.0"},
                "success": True
            },
            {
                "tool": "read_file",
                "arguments": {"file_path": "README.md"},
                "success": True
            }
        ]

        # Mock working directory
        agent.working_directory = "/tmp/test_project"

        return agent

    def test_initialization(self, temp_checkpoint_dir):
        """Test CheckpointManager initialization"""
        manager = CheckpointManager(
            checkpoint_dir=temp_checkpoint_dir,
            max_checkpoints=5
        )

        assert manager.checkpoint_dir == Path(temp_checkpoint_dir)
        assert manager.max_checkpoints == 5
        assert manager.checkpoint_dir.exists()

    def test_save_checkpoint_creates_file(self, checkpoint_manager, mock_agent, temp_checkpoint_dir):
        """Test that save_checkpoint creates a JSON file"""
        checkpoint_id = checkpoint_manager.save_checkpoint(
            agent=mock_agent,
            execution_progress="Implemented calculator",
            task_description="Building calculator app"
        )

        # Verify checkpoint ID is returned
        assert isinstance(checkpoint_id, str)
        assert len(checkpoint_id) == 8  # UUID first 8 chars

        # Verify checkpoint file exists
        checkpoint_file = Path(temp_checkpoint_dir) / f"checkpoint_{checkpoint_id}.json"
        assert checkpoint_file.exists()

        # Verify it's valid JSON
        with open(checkpoint_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            assert "metadata" in data
            assert "working_memory" in data
            assert "episodic_memory" in data

    def test_save_checkpoint_extracts_data_correctly(self, checkpoint_manager, mock_agent):
        """Test that save_checkpoint extracts all data from agent correctly"""
        checkpoint_id = checkpoint_manager.save_checkpoint(
            agent=mock_agent,
            execution_progress="Implemented calculator",
            task_description="Building calculator app",
            current_phase="Phase 1",
            pending_tasks=["Add tests", "Add documentation"]
        )

        # Load the checkpoint
        checkpoint = checkpoint_manager.load_checkpoint(checkpoint_id)

        # Verify metadata
        assert checkpoint.metadata.task_description == "Building calculator app"
        assert checkpoint.metadata.working_directory == "/tmp/test_project"
        assert checkpoint.metadata.files_modified_count == 1  # Both operations on calculator.py (unique files)
        assert checkpoint.metadata.tool_calls_count == 3
        assert checkpoint.metadata.conversation_turns == 1  # One user message

        # Verify working memory
        assert len(checkpoint.working_memory) == 2
        assert checkpoint.working_memory[0]["role"] == "user"
        assert checkpoint.working_memory[0]["content"] == "Create a calculator"
        assert checkpoint.working_memory[1]["role"] == "assistant"

        # Verify episodic memory
        assert len(checkpoint.episodic_memory) == 2
        assert "Session 1" in checkpoint.episodic_memory[0]

        # Verify task context
        assert checkpoint.task_context["project_type"] == "Python CLI Tool"
        assert "calculator.py" in checkpoint.task_context["key_files"]

        # Verify tool history
        assert len(checkpoint.tool_execution_history) == 3
        assert checkpoint.tool_execution_history[0]["tool"] == "write_file"

        # Verify files modified (only successful write/edit operations, unique files)
        assert len(checkpoint.files_modified) == 1  # calculator.py modified twice = 1 unique file
        assert "calculator.py" in checkpoint.files_modified

        # Verify optional fields
        assert checkpoint.current_phase == "Phase 1"
        assert "Add tests" in checkpoint.pending_tasks

    def test_load_checkpoint(self, checkpoint_manager, mock_agent):
        """Test loading a checkpoint from disk"""
        # Save a checkpoint
        checkpoint_id = checkpoint_manager.save_checkpoint(
            agent=mock_agent,
            execution_progress="Test progress",
            task_description="Test task"
        )

        # Load it back
        checkpoint = checkpoint_manager.load_checkpoint(checkpoint_id)

        # Verify it's an ExecutionCheckpoint instance
        assert isinstance(checkpoint, ExecutionCheckpoint)
        assert isinstance(checkpoint.metadata, CheckpointMetadata)

        # Verify data integrity
        assert checkpoint.metadata.checkpoint_id == checkpoint_id
        assert checkpoint.metadata.task_description == "Test task"

    def test_load_checkpoint_nonexistent_file(self, checkpoint_manager):
        """Test loading a checkpoint that doesn't exist"""
        with pytest.raises(FileNotFoundError):
            checkpoint_manager.load_checkpoint("nonexistent")

    def test_load_checkpoint_corrupted_file(self, checkpoint_manager, temp_checkpoint_dir):
        """Test loading a corrupted checkpoint file"""
        # Create a corrupted checkpoint file
        corrupted_file = Path(temp_checkpoint_dir) / "checkpoint_corrupted.json"
        with open(corrupted_file, 'w') as f:
            f.write("{ invalid json }")

        with pytest.raises(json.JSONDecodeError):
            checkpoint_manager.load_checkpoint("corrupted")

    def test_restore_to_agent(self, checkpoint_manager, mock_agent):
        """Test restoring checkpoint state to agent"""
        # Save checkpoint
        checkpoint_id = checkpoint_manager.save_checkpoint(
            agent=mock_agent,
            execution_progress="Test",
            task_description="Test"
        )

        # Create a new mock agent (simulating fresh start)
        from src.memory.memory_manager import Message, MessageRole
        new_agent = Mock()
        new_agent.memory = Mock()
        new_agent.memory.working_memory = Mock()
        new_agent.memory.working_memory.messages = []
        new_agent.memory.episodic_memory = Mock()
        new_agent.memory.episodic_memory.compressed_history = []
        new_agent.memory.task_context = Mock()
        new_agent.tool_execution_history = []

        # Load checkpoint
        checkpoint = checkpoint_manager.load_checkpoint(checkpoint_id)

        # Restore to new agent
        checkpoint_manager.restore_to_agent(checkpoint, new_agent)

        # Verify working memory was restored
        assert len(new_agent.memory.working_memory.messages) == 2
        restored_msg = new_agent.memory.working_memory.messages[0]
        assert restored_msg.role == MessageRole.USER
        assert restored_msg.content == "Create a calculator"

        # Verify episodic memory was restored
        assert len(new_agent.memory.episodic_memory.compressed_history) == 2

        # Verify task context was restored
        assert new_agent.memory.task_context.project_type == "Python CLI Tool"
        assert new_agent.memory.task_context.key_files == ["calculator.py", "test_calculator.py"]

        # Verify tool history was restored
        assert len(new_agent.tool_execution_history) == 3
        assert new_agent.tool_execution_history[0]["tool"] == "write_file"

    def test_list_checkpoints(self, checkpoint_manager, mock_agent):
        """Test listing all checkpoints"""
        # Initially empty
        checkpoints = checkpoint_manager.list_checkpoints()
        assert len(checkpoints) == 0

        # Save 3 checkpoints with small delays to ensure distinct timestamps
        import time
        id1 = checkpoint_manager.save_checkpoint(mock_agent, "Progress 1", "Task 1")
        time.sleep(0.05)
        id2 = checkpoint_manager.save_checkpoint(mock_agent, "Progress 2", "Task 2")
        time.sleep(0.05)
        id3 = checkpoint_manager.save_checkpoint(mock_agent, "Progress 3", "Task 3")

        # List them
        checkpoints = checkpoint_manager.list_checkpoints()
        assert len(checkpoints) == 3

        # Verify they're sorted by timestamp (newest first)
        assert checkpoints[0].checkpoint_id == id3
        assert checkpoints[1].checkpoint_id == id2
        assert checkpoints[2].checkpoint_id == id1

        # Verify metadata is correct
        assert all(isinstance(c, CheckpointMetadata) for c in checkpoints)
        assert checkpoints[0].task_description == "Task 3"

    def test_list_checkpoints_skips_corrupted_files(self, checkpoint_manager, mock_agent, temp_checkpoint_dir):
        """Test that list_checkpoints skips corrupted files"""
        # Save a valid checkpoint
        checkpoint_manager.save_checkpoint(mock_agent, "Progress", "Task")

        # Create a corrupted checkpoint file
        corrupted_file = Path(temp_checkpoint_dir) / "checkpoint_corrupted.json"
        with open(corrupted_file, 'w') as f:
            f.write("{ invalid json }")

        # List should skip corrupted file
        checkpoints = checkpoint_manager.list_checkpoints()
        assert len(checkpoints) == 1  # Only valid checkpoint

    def test_cleanup_old_checkpoints(self, checkpoint_manager, mock_agent):
        """Test automatic cleanup of old checkpoints"""
        import time

        # Manager has max_checkpoints=3

        # Save 5 checkpoints with small delay to ensure unique timestamps
        for i in range(5):
            checkpoint_manager.save_checkpoint(
                mock_agent,
                f"Progress {i}",
                f"Task {i}"
            )
            time.sleep(0.01)  # 10ms delay to ensure unique timestamps

        # Should only have 3 checkpoints (most recent)
        checkpoints = checkpoint_manager.list_checkpoints()
        assert len(checkpoints) == 3

        # Verify newest 3 are kept
        assert checkpoints[0].task_description == "Task 4"
        assert checkpoints[1].task_description == "Task 3"
        assert checkpoints[2].task_description == "Task 2"

    def test_truncate_working_memory(self, checkpoint_manager, temp_checkpoint_dir):
        """Test that working memory is truncated to last 20 messages"""
        # Create agent with many messages
        agent = Mock()
        agent.memory = Mock()
        agent.memory.working_memory = Mock()

        # Create 30 messages
        messages = []
        for i in range(30):
            msg = Mock()
            msg.role = Mock(value="user" if i % 2 == 0 else "assistant")
            msg.content = f"Message {i}"
            msg.timestamp = datetime.now()
            messages.append(msg)

        agent.memory.working_memory.messages = messages
        agent.memory.episodic_memory = Mock()
        agent.memory.episodic_memory.compressed_history = []
        agent.memory.task_context = Mock()
        agent.memory.task_context.project_type = None
        agent.memory.task_context.key_files = []
        agent.memory.task_context.key_concepts = []
        agent.tool_execution_history = []
        agent.working_directory = "/tmp/test"
        agent.current_todos = []
        agent.model_name = "test-model"
        agent.context_window = 8192

        # Save checkpoint
        checkpoint_id = checkpoint_manager.save_checkpoint(
            agent,
            "Test",
            "Test"
        )

        # Load and verify only last 20 messages saved
        checkpoint = checkpoint_manager.load_checkpoint(checkpoint_id)
        assert len(checkpoint.working_memory) == 20

        # Verify it's the LAST 20 messages
        assert checkpoint.working_memory[0]["content"] == "Message 10"
        assert checkpoint.working_memory[-1]["content"] == "Message 29"

    def test_checkpoint_serialization_deserialization(self):
        """Test ExecutionCheckpoint to_dict and from_dict"""
        # Create checkpoint
        metadata = CheckpointMetadata(
            checkpoint_id="test123",
            timestamp=datetime.now().isoformat(),
            task_description="Test task",
            working_directory="/tmp/test",
            files_modified_count=5,
            tool_calls_count=10,
            conversation_turns=3
        )

        checkpoint = ExecutionCheckpoint(
            metadata=metadata,
            working_memory=[{"role": "user", "content": "Hello"}],
            episodic_memory=["Summary 1"],
            task_context={"project_type": "Python"},
            tool_execution_history=[{"tool": "write_file", "success": True}],
            files_modified=["file1.py"],
            current_phase="Phase 1",
            pending_tasks=["Task 1"]
        )

        # Serialize
        data = checkpoint.to_dict()
        assert isinstance(data, dict)
        assert "metadata" in data
        assert "working_memory" in data

        # Deserialize
        restored_checkpoint = ExecutionCheckpoint.from_dict(data)
        assert isinstance(restored_checkpoint, ExecutionCheckpoint)
        assert restored_checkpoint.metadata.checkpoint_id == "test123"
        assert restored_checkpoint.working_memory[0]["content"] == "Hello"
        assert restored_checkpoint.current_phase == "Phase 1"

    @pytest.mark.skip(reason="Mock creates attributes on demand, making this test unreliable")
    def test_agent_without_memory_attributes(self, checkpoint_manager):
        """Test saving checkpoint from agent without memory attributes"""
        # NOTE: This test is skipped because Mock objects create attributes on demand
        # when accessed via hasattr(), making it impossible to test the "no memory" case
        # with Mocks. The try-except blocks in save_checkpoint() handle missing attributes
        # gracefully in practice with real agents.

        # Create agent with minimal attributes
        agent = Mock()
        agent.working_directory = "/tmp/test"
        agent.tool_execution_history = []  # Empty tool history
        # No memory attribute

        # Should not crash, just save empty data
        checkpoint_id = checkpoint_manager.save_checkpoint(
            agent,
            "Test",
            "Test"
        )

        # Load and verify empty data
        checkpoint = checkpoint_manager.load_checkpoint(checkpoint_id)
        assert len(checkpoint.working_memory) == 0
        assert len(checkpoint.episodic_memory) == 0
        assert checkpoint.task_context == {}
        assert len(checkpoint.tool_execution_history) == 0


class TestCheckpointIntegration:
    """Integration tests with real agent components"""

    def test_save_and_restore_round_trip(self):
        """Test complete save/restore round trip with real memory components"""
        # This test requires real CodingAgent and MemoryManager
        # Skip if not available
        pytest.skip("Integration test - requires full agent setup")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
