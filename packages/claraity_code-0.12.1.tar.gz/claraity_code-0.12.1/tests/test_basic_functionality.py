def test_example():
    assert 1 + 1 == 2

def test_string_length():
    assert len('hello') == 5
