"""
Tool Gating Service - Centralized tool call gating logic.

Consolidates the four gating checks used by stream_response():

1. Repeat detection: blocks calls that failed with identical args before
2. Plan mode gate: restricts writes when plan mode is active
3. Director gate: restricts writes based on director phase
4. Approval check: determines if user approval is needed

Usage:
    gating = ToolGatingService(plan_mode_state, director_adapter,
                               permission_manager, error_tracker, mcp_manager)
    result = gating.evaluate(tool_name, tool_args)
    # result.action tells you what to do: ALLOW, DENY, NEEDS_APPROVAL, BLOCKED_REPEAT
"""

import json
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Dict, Optional, TYPE_CHECKING

from src.observability import get_logger

if TYPE_CHECKING:
    from src.core.plan_mode import PlanModeState
    from src.core.permission_mode import PermissionManager
    from src.core.error_recovery import ErrorRecoveryTracker
    from src.mcp.connection_manager import McpConnectionManager
    from src.director.adapter import DirectorAdapter

logger = get_logger(__name__)


class GateAction(Enum):
    """What the caller should do with this tool call."""
    ALLOW = auto()
    DENY = auto()
    NEEDS_APPROVAL = auto()
    BLOCKED_REPEAT = auto()


@dataclass
class GateResult:
    """Result of evaluating all gating checks for a tool call.

    Attributes:
        action: What the caller should do (ALLOW, DENY, NEEDS_APPROVAL, BLOCKED_REPEAT).
        message: Human-readable explanation (set for DENY/BLOCKED_REPEAT).
        gate_response: Full gated response dict for LLM feedback (set for DENY gates).
        call_summary: Summary of the blocked call (set for BLOCKED_REPEAT).
    """
    action: GateAction
    message: Optional[str] = None
    gate_response: Optional[Dict[str, Any]] = None
    call_summary: Optional[str] = None


class ToolGatingService:
    """Centralized gating for tool calls.

    Evaluates whether a tool call should be allowed, denied, or
    require user approval. Used by stream_response().
    """

    # Tools that require user approval in NORMAL permission mode
    RISKY_TOOLS = frozenset({
        'write_file', 'edit_file', 'append_to_file',
        'run_command', 'git_commit',
    })

    def __init__(
        self,
        plan_mode_state: "PlanModeState",
        director_adapter: "DirectorAdapter",
        permission_manager: Optional["PermissionManager"],
        error_tracker: "ErrorRecoveryTracker",
        mcp_manager: "McpConnectionManager",
    ):
        self._plan_mode_state = plan_mode_state
        self._director_adapter = director_adapter
        self._permission_manager = permission_manager
        self._error_tracker = error_tracker
        self._mcp_manager = mcp_manager

    # ------------------------------------------------------------------
    # Individual checks (can be called standalone)
    # ------------------------------------------------------------------

    def check_repeat(
        self, tool_name: str, tool_args: Dict[str, Any]
    ) -> Optional[GateResult]:
        """Check if this exact call has failed before.

        Returns GateResult with BLOCKED_REPEAT if repeated, else None.
        """
        is_repeat, call_summary = self._error_tracker.is_repeated_failed_call(
            tool_name, tool_args
        )
        if is_repeat:
            return GateResult(
                action=GateAction.BLOCKED_REPEAT,
                message=(
                    "[BLOCKED] This exact call failed previously. "
                    "You must try a different approach or different arguments."
                ),
                call_summary=call_summary,
            )
        return None

    def check_plan_mode_gate(
        self, tool_name: str, tool_args: Dict[str, Any]
    ) -> Optional[GateResult]:
        """Check if tool is restricted by plan mode.

        Returns GateResult with DENY if gated, else None.
        """
        from src.core.plan_mode import PlanGateDecision

        target_path = tool_args.get("file_path") or tool_args.get("path")
        decision = self._plan_mode_state.gate_tool(tool_name, target_path)

        if decision == PlanGateDecision.DENY:
            response = {
                "status": "denied",
                "error_code": "PLAN_MODE_GATED",
                "message": (
                    f"Tool '{tool_name}' is not allowed in plan mode. "
                    f"Only read-only tools and writing to the plan file are permitted."
                ),
                "plan_path": (
                    str(self._plan_mode_state.plan_file_path)
                    if self._plan_mode_state.plan_file_path else None
                ),
                "allowed_actions": [
                    "Use read-only tools (read_file, grep, glob, etc.)",
                    f"Write to plan file: {self._plan_mode_state.plan_file_path}",
                    "Call request_plan_approval when ready for approval",
                ],
            }
            return GateResult(
                action=GateAction.DENY,
                message=response["message"],
                gate_response=response,
            )

        if decision == PlanGateDecision.REQUIRE_APPROVAL:
            response = {
                "status": "denied",
                "error_code": "PLAN_APPROVAL_REQUIRED",
                "message": (
                    f"Tool '{tool_name}' cannot run until the plan is approved. "
                    f"The plan is awaiting user approval."
                ),
                "plan_path": (
                    str(self._plan_mode_state.plan_file_path)
                    if self._plan_mode_state.plan_file_path else None
                ),
                "allowed_actions": [
                    "Wait for user to approve or reject the plan",
                    "Use read-only tools while waiting",
                ],
            }
            return GateResult(
                action=GateAction.DENY,
                message=response["message"],
                gate_response=response,
            )

        return None  # Allowed

    def check_director_gate(
        self, tool_name: str, tool_args: Dict[str, Any]
    ) -> Optional[GateResult]:
        """Check if tool is restricted by director phase.

        Returns GateResult with DENY if gated, else None.
        """
        if not self._director_adapter.is_active:
            return None

        from src.director.adapter import DirectorGateDecision

        decision = self._director_adapter.gate_tool(tool_name, tool_args)

        if decision == DirectorGateDecision.DENY:
            phase = self._director_adapter.phase.name
            response = {
                "status": "denied",
                "error_code": "DIRECTOR_MODE_GATED",
                "message": (
                    f"Tool '{tool_name}' is not allowed in Director "
                    f"{phase} phase. Use read-only tools or the "
                    f"appropriate director checkpoint tool."
                ),
                "phase": phase,
            }
            return GateResult(
                action=GateAction.DENY,
                message=response["message"],
                gate_response=response,
            )

        return None  # Allowed

    def needs_approval(
        self, tool_name: str, tool_args: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Determine if a tool call requires user approval.

        Logic depends on the current permission mode:
        - AUTO: never ask
        - PLAN: only MCP write tools
        - NORMAL: risky built-in tools and MCP write tools
        """
        from src.core.permission_mode import PermissionMode
        from src.core.plan_mode import is_agent_internal_write

        mode = (
            self._permission_manager.get_mode()
            if self._permission_manager
            else PermissionMode.NORMAL
        )

        # AUTO mode: never ask
        if mode == PermissionMode.AUTO:
            return False

        # PLAN mode: gating handles built-in tools; only MCP writes need approval
        if mode == PermissionMode.PLAN:
            if self._mcp_manager.is_mcp_tool(tool_name):
                return self._mcp_manager.requires_approval(tool_name)
            return False

        # Agent-internal writes bypass approval (plan files, sessions, logs)
        if tool_args and is_agent_internal_write(tool_name, tool_args):
            return False

        # MCP tools: delegate to policy gate
        if self._mcp_manager.is_mcp_tool(tool_name):
            return self._mcp_manager.requires_approval(tool_name)

        # NORMAL mode: ask only for risky tools
        return tool_name in self.RISKY_TOOLS

    # ------------------------------------------------------------------
    # Combined evaluation
    # ------------------------------------------------------------------

    def evaluate(
        self, tool_name: str, tool_args: Dict[str, Any]
    ) -> GateResult:
        """Run all gating checks in priority order.

        Order: repeat -> plan mode -> director -> approval -> allow.

        Returns a GateResult indicating what the caller should do.
        """
        # 1. Repeat detection (highest priority)
        result = self.check_repeat(tool_name, tool_args)
        if result:
            return result

        # 2. Plan mode gate
        result = self.check_plan_mode_gate(tool_name, tool_args)
        if result:
            return result

        # 3. Director gate
        result = self.check_director_gate(tool_name, tool_args)
        if result:
            return result

        # 4. Approval check
        if self.needs_approval(tool_name, tool_args):
            return GateResult(action=GateAction.NEEDS_APPROVAL)

        # 5. Allowed
        return GateResult(action=GateAction.ALLOW)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def format_gate_response(self, gate_response: Dict[str, Any]) -> str:
        """Format a gate response dict as JSON string for LLM feedback."""
        return json.dumps(gate_response, indent=2)
