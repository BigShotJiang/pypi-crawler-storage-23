"""Main coding agent orchestration."""

import asyncio
import json
import os
import traceback
import uuid
from typing import Optional, List, Dict, Any, TYPE_CHECKING
from pathlib import Path

from src.observability import get_logger

if TYPE_CHECKING:
    from src.hooks import HookManager, HookDecision
    from src.core.protocol import UIProtocol
    from src.rag import CodeIndexer, Embedder, HybridRetriever, CodeChunk

from src.memory import MemoryManager, TaskContext
from src.llm import LLMBackend, OllamaBackend, OpenAIBackend, LLMConfig, LLMBackendType
from src.llm.base import ProviderDelta
from src.llm.failure_handler import LLMError, RateLimitError, TimeoutError
from src.tools import (
    ToolExecutor,
    ToolNotFoundError,
    ToolExecutionError,
    ReadFileTool,
    WriteFileTool,
    EditFileTool,
    AppendToFileTool,
    ListDirectoryTool,
    RunCommandTool,
    SearchCodeTool,
    AnalyzeCodeTool,
    GrepTool,
    GlobTool,
    GetFileOutlineTool,
    GetSymbolContextTool,
    GitStatusTool,
    GitDiffTool,
    GitCommitTool,
    DelegateToSubagentTool,
    TaskState,
    TaskCreateTool,
    TaskUpdateTool,
    TaskListTool,
    TaskGetTool,
    CreateCheckpointTool,
    # Clarity tools disconnected - migrating to markdown-based knowledge system
    # QueryComponentTool,
    # QueryDependenciesTool,
    # QueryDecisionsTool,
    # QueryFlowsTool,
    # QueryArchitectureSummaryTool,
    # SearchComponentsTool,
    # ClaritySetupTool,
    # GetNextTaskTool,
    # UpdateComponentStatusTool,
    # AddArtifactTool,
    # GetImplementationSpecTool,
    # AddMethodTool,
    # AddAcceptanceCriterionTool,
    # UpdateMethodTool,
    # UpdateAcceptanceCriterionTool,
    # UpdateImplementationPatternTool,
    EnterPlanModeTool,
    RequestPlanApprovalTool,
)
from src.tools.tool_parser import ToolCallParser, ParsedResponse

from src.prompts import PromptLibrary, TaskType
from .context_builder import ContextBuilder
from .file_reference_parser import FileReferenceParser
from .agent_interface import AgentInterface
from .error_recovery import ErrorRecoveryTracker
from .error_context import ErrorContext

# Permission mode (simplified - workflow system deprecated)
from src.core.permission_mode import PermissionManager, PermissionMode

# Plan mode (Claude Code-style planning workflow)
from src.core.plan_mode import PlanModeState, PlanGateDecision

# Director mode (lazy import to avoid circular dependency)
# src.director.adapter -> prompts -> src.core.plan_mode -> src.core -> agent
if TYPE_CHECKING:
    from src.director.adapter import DirectorAdapter, DirectorGateDecision

# Subagent components (lazy import to avoid circular dependency)
if TYPE_CHECKING:
    from src.subagents import SubAgentManager, SubAgentResult

# ClarAIty integration
try:
    from src.clarity.integration import ClarityAgentHook
    CLARITY_AVAILABLE = True
except ImportError:
    CLARITY_AVAILABLE = False
    ClarityAgentHook = None

# Observability integration (Langfuse v3 API + structured logging)
try:
    from src.observability import (
        observe_agent_method,
        observe_tool_execution,
        start_trace,
        update_trace,
        record_llm_latency,
        record_token_usage,
        record_tool_metric,
        # Structured logging
        bind_context,
        clear_context,
        new_request_id,
        get_logger,
        ErrorCategory,
    )
    OBSERVABILITY_AVAILABLE = True
except ImportError:
    OBSERVABILITY_AVAILABLE = False
    # No-op decorators if observability not available
    def observe_agent_method(name, **kwargs):
        def decorator(func):
            return func
        return decorator
    def observe_tool_execution(name, **kwargs):
        def decorator(func):
            return func
        return decorator
    def start_trace(*args, **kwargs):
        pass
    def update_trace(*args, **kwargs):
        pass
    def record_llm_latency(*args, **kwargs):
        pass
    def record_token_usage(*args, **kwargs):
        pass
    def record_tool_metric(*args, **kwargs):
        pass
    def bind_context(**kwargs):
        pass
    def clear_context():
        pass
    def new_request_id():
        return ''
    def get_logger(name=None):
        # Fallback when observability not available - use standard logging
        import logging
        return logging.getLogger(name or __name__)
    class ErrorCategory:
        PROVIDER_TIMEOUT = 'provider_timeout'
        PROVIDER_ERROR = 'provider_error'
        TOOL_TIMEOUT = 'tool_timeout'
        TOOL_ERROR = 'tool_error'
        UNEXPECTED = 'unexpected'


# Module-level logger for agent operations (use structlog if available)
logger = get_logger("core.agent")


class CodingAgent(AgentInterface):
    """
    Main AI coding agent that orchestrates all components.
    Optimized for small open-source LLMs.

    Implements AgentInterface to enable loose coupling with subsystems.
    """

    @property
    def todo_state(self) -> Dict[str, Any]:
        """Backward-compat dict view for context_builder, pause logic, UI."""
        return {
            'todos': self.task_state.get_todos_list(),
            'current_todo_id': self.task_state.current_task_id,
            'last_stop_reason': self.task_state.last_stop_reason,
        }

    def __init__(
        self,
        model_name: str,
        backend: str,
        base_url: str,
        context_window: int,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
        working_directory: str = ".",
        api_key: Optional[str] = None,
        api_key_env: str = "OPENAI_API_KEY",
        embedding_model: Optional[str] = None,
        embedding_api_key: Optional[str] = None,
        embedding_api_key_env: str = "EMBEDDING_API_KEY",
        embedding_base_url: Optional[str] = None,
        load_file_memories: bool = True,
        permission_mode: str = "normal",
        hook_manager: Optional['HookManager'] = None,
        enable_clarity: bool = True,
    ):
        """
        Initialize coding agent.

        All configuration should come from .env file via CLI.

        Args:
            model_name: Name of the LLM model (required, from .env: LLM_MODEL)
            backend: Backend type (required, from .env: LLM_BACKEND)
            base_url: Base URL for LLM API (required, from .env: LLM_HOST)
            context_window: Context window size (required, from .env: MAX_CONTEXT_TOKENS)
            temperature: LLM temperature (from .env: LLM_TEMPERATURE)
            max_tokens: Max output tokens (from .env: LLM_MAX_TOKENS)
            top_p: Top-p sampling (from .env: LLM_TOP_P)
            working_directory: Working directory for file operations
            api_key: API key for OpenAI-compatible backends (optional)
            api_key_env: Environment variable name for API key (default: OPENAI_API_KEY)
            embedding_model: Name of the embedding model (from .env: EMBEDDING_MODEL)
            embedding_api_key: API key for embedding service (optional)
            embedding_api_key_env: Environment variable for embedding API key (default: EMBEDDING_API_KEY)
            embedding_base_url: Base URL for embedding API (from .env: EMBEDDING_BASE_URL)
            load_file_memories: Whether to load file-based memories on init (default: True)
            permission_mode: Permission mode (plan/normal/auto, default: normal)
            hook_manager: Optional hook manager for event hooks
            enable_clarity: Enable ClarAIty blueprint generation (default: True)
        """
        self.model_name = model_name
        self.backend_name = backend  # Store backend name for logging
        self.context_window = context_window
        self.working_directory = Path(working_directory)
        self.hook_manager = hook_manager

        # Store embedding configuration (no defaults, controlled by .env)
        self.embedding_model = embedding_model
        self.embedding_api_key = embedding_api_key
        self.embedding_api_key_env = embedding_api_key_env
        self.embedding_base_url = embedding_base_url

        # Initialize LLM backend
        # Read from .env if not provided
        llm_config = LLMConfig(
            backend_type=LLMBackendType(backend),
            model_name=model_name,
            base_url=base_url,
            context_window=context_window,
            num_ctx=context_window,
            temperature=temperature if temperature is not None else float(os.getenv("LLM_TEMPERATURE", "0.2")),
            max_tokens=max_tokens if max_tokens is not None else int(os.getenv("LLM_MAX_TOKENS", "16384")),
            top_p=top_p if top_p is not None else float(os.getenv("LLM_TOP_P", "0.95")),
        )

        if backend == "ollama":
            self.llm: LLMBackend = OllamaBackend(llm_config)
        elif backend == "openai":
            self.llm: LLMBackend = OpenAIBackend(
                llm_config,
                api_key=api_key,
                api_key_env=api_key_env
            )
        elif backend == "anthropic":
            from src.llm.anthropic_backend import AnthropicBackend
            self.llm: LLMBackend = AnthropicBackend(
                llm_config,
                api_key=api_key,
                api_key_env=api_key_env if api_key_env != "OPENAI_API_KEY" else "ANTHROPIC_API_KEY",
            )
        else:
            raise ValueError(f"Unsupported backend: {backend}")

        # Initialize memory system with file-based memory loading
        self.memory = MemoryManager(
            total_context_tokens=context_window,
            working_memory_tokens=int(context_window * 0.4),
            episodic_memory_tokens=int(context_window * 0.2),
            embedding_model=self.embedding_model,
            embedding_api_key=self.embedding_api_key,
            embedding_api_key_env=self.embedding_api_key_env,
            embedding_base_url=self.embedding_base_url,
            embedding_dimension=None,  # Will be read from .env inside SemanticMemory
            load_file_memories=load_file_memories,
            starting_directory=self.working_directory,
        )

        # Initialize RAG components (lazy loading)
        self.indexer: Optional[CodeIndexer] = None
        self.embedder: Optional[Embedder] = None
        self.retriever: Optional[HybridRetriever] = None
        self.indexed_chunks: List[CodeChunk] = []

        # Initialize task state for CRUD task tracking (before tools registration)
        self.task_state = TaskState()

        # Initialize error recovery tracker (for intelligent retry behavior)
        # Uses defaults: max_same_tool_error_failures=4, max_total_failures=10
        self._error_tracker = ErrorRecoveryTracker()

        # Approval state tracking (for pause/approval precedence)
        self._awaiting_approval = False

        # Tool output size limit (parsed once, not on every tool call)
        self._max_tool_output_chars = int(os.getenv("TOOL_OUTPUT_MAX_CHARS", "100000"))

        # Compaction cooldown: skip further attempts after a failure
        # within the same stream_response() call. Reset on next user message.
        self._compaction_failed = False

        # Initialize plan mode state (Claude Code-style planning workflow)
        # Must be initialized before tools registration since plan mode tools need it
        self.plan_mode_state = PlanModeState(
            clarity_dir=self.working_directory / ".clarity"
        )

        # Session ID for plan mode (will be set when session starts)
        self._session_id: Optional[str] = None

        # Initialize director adapter (disciplined workflow mode)
        from src.director.adapter import DirectorAdapter
        self.director_adapter = DirectorAdapter()

        # Initialize tools
        self.tool_executor = ToolExecutor(hook_manager=hook_manager)
        self._register_tools()

        # MCP connection manager (lazy - no connections at init time)
        # Connections added via enable_mcp_integration()
        from src.integrations.mcp.manager import McpConnectionManager
        self._mcp_manager = McpConnectionManager()
        self._tools_cache = None  # Invalidated when tools are registered/unregistered

        # Set workspace root on file operation tools so path validation works
        from src.tools.file_operations import FileOperationTool
        FileOperationTool._workspace_root = self.working_directory

        # Initialize tool parser
        self.tool_parser = ToolCallParser()

        # Track tool execution history for testing/debugging
        self.tool_execution_history: List[Dict[str, Any]] = []

        # Initialize context builder
        self.context_builder = ContextBuilder(
            memory_manager=self.memory,
            retriever=self.retriever,
            max_context_tokens=context_window,
            project_root=Path(self.working_directory),
        )

        # Initialize file reference parser
        self.file_reference_parser = FileReferenceParser(
            base_dir=self.working_directory,
            max_file_size=100_000  # 100K chars max
        )

        # Initialize permission manager
        try:
            mode = PermissionManager.from_string(permission_mode)
        except ValueError as e:
            print(f"Warning: {e}. Using NORMAL mode.")
            mode = PermissionMode.NORMAL
        self.permission_manager = PermissionManager(mode=mode)

        # Centralized tool gating service (used by both sync and async tool loops)
        from src.core.tool_gating import ToolGatingService
        self._gating = ToolGatingService(
            plan_mode_state=self.plan_mode_state,
            director_adapter=self.director_adapter,
            permission_manager=self.permission_manager,
            error_tracker=self._error_tracker,
            mcp_manager=self._mcp_manager,
        )

        # Special tool handlers (clarify, plan approval, director plan approval)
        from src.core.special_tool_handlers import SpecialToolHandlers
        self._special_handlers = SpecialToolHandlers(
            memory=self.memory,
            plan_mode_state=self.plan_mode_state,
            director_adapter=self.director_adapter,
            tool_executor=self.tool_executor,
            permission_manager=self.permission_manager,
        )

        # Initialize subagent manager (lazy import to avoid circular dependency)
        from src.subagents import SubAgentManager
        self.subagent_manager = SubAgentManager(
            main_agent=self,
            working_directory=self.working_directory,
            max_parallel_workers=4,
            enable_auto_delegation=True
        )

        # Discover available subagents
        self.subagent_manager.discover_subagents()

        # Register delegation tool (now that subagent_manager is initialized)
        self.tool_executor.register_tool(
            DelegateToSubagentTool(self.subagent_manager)
        )

        # Register director checkpoint tools
        from src.director.tools import (
            DirectorCompleteUnderstandTool,
            DirectorCompletePlanTool,
            DirectorCompleteSliceTool,
            DirectorCompleteIntegrationTool,
        )
        self.tool_executor.register_tool(DirectorCompleteUnderstandTool(self.director_adapter))
        self.tool_executor.register_tool(DirectorCompletePlanTool(self.director_adapter))
        self.tool_executor.register_tool(DirectorCompleteSliceTool(self.director_adapter))
        self.tool_executor.register_tool(DirectorCompleteIntegrationTool(self.director_adapter))

        # Initialize ClarAIty hook (if available and enabled)
        self.clarity_hook = None
        if enable_clarity and CLARITY_AVAILABLE:
            try:
                self.clarity_hook = ClarityAgentHook()
                logger.info("ClarAIty integration enabled")
            except Exception as e:
                logger.warning(f"Failed to initialize ClarAIty: {e}", exc_info=True)

        # SESSION START HOOK
        if self.hook_manager:
            try:
                self.hook_manager.emit_session_start(
                    working_directory=str(self.working_directory),
                    model_name=model_name,
                    config={
                        "backend": backend,
                        "context_window": context_window,
                        "permission_mode": permission_mode
                    }
                )

            except Exception as e:
                # SessionStart hooks don't block, just log errors
                logger.warning(f"SessionStart hook error: {e}", exc_info=True)

    def get_available_subagents(self) -> List[str]:
        """Get list of all available subagent names.

        Returns:
            List of subagent names that can be used for delegation

        Example:
            >>> subagents = agent.get_available_subagents()
            >>> print(subagents)
            ['code-reviewer', 'test-writer', 'doc-writer']
        """
        return self.subagent_manager.get_available_subagents()

    def set_session_id(self, session_id: str, is_new_session: bool = True) -> None:
        """
        Set the session ID for plan mode and other session-scoped features.

        This should be called when a session is started or resumed.

        Args:
            session_id: The session ID
            is_new_session: If True, reset plan mode state (for new sessions).
                           If False, preserve existing state (for resumed sessions).
        """
        self._session_id = session_id

        # Reset plan mode state for new sessions to avoid stale state
        if is_new_session and hasattr(self, 'plan_mode_state'):
            self.plan_mode_state.reset()

        # Update the plan mode tool with the session ID
        if hasattr(self, '_enter_plan_mode_tool'):
            self._enter_plan_mode_tool.session_id = session_id

        # Enable task state file persistence for this session
        # Saves to .clarity/sessions/{session_id}/todos.json
        todos_path = self.working_directory / ".clarity" / "sessions" / session_id / "todos.json"
        self.task_state.set_persistence_path(todos_path)

    def is_in_plan_mode(self) -> bool:
        """Check if currently in plan mode."""
        return self.plan_mode_state.is_active

    # NOTE: _check_plan_mode_gate and _check_director_gate moved to
    # src/core/tool_gating.py -> ToolGatingService (Phase 2 refactor)

    def _refresh_director_context(self, current_context: list) -> None:
        """
        Refresh the director mode injection in the system prompt.

        Called after director checkpoint tools change the phase so the LLM
        sees the new phase instructions on its next iteration without
        rebuilding the entire context.
        """
        if not current_context or not self.director_adapter.is_active:
            return

        system_msg = current_context[0]
        if system_msg.get("role") != "system":
            return

        content = system_msg.get("content", "")

        # Remove old director injection (from <director-mode to end of content)
        marker = "<director-mode"
        idx = content.find(marker)
        if idx > 0:
            content = content[:idx].rstrip()

        # Append fresh injection for the current phase
        new_injection = self.director_adapter.get_prompt_injection()
        if new_injection:
            content = content + "\n\n" + new_injection

        system_msg["content"] = content

    def _sync_plan_mode_from_store(self) -> None:
        """
        Synchronize plan_mode_state from MessageStore.

        MessageStore maintains current mode as a property (updated when
        permission_mode_changed events are added). This method simply
        queries that property and syncs the agent's in-memory state.

        Called at the start of each turn before building context.
        """
        if not self.memory.has_message_store:
            return

        # Query mode state directly from MessageStore (O(1) property access)
        store = self.memory.message_store
        current_mode = store.current_mode
        plan_hash = store.plan_hash
        plan_path = store.plan_path

        # Synchronize both plan_mode_state AND permission_manager based on current mode
        from src.core.permission_mode import PermissionMode

        if current_mode == "plan":
            # In plan mode - ensure state is active
            if not self.plan_mode_state.is_active:
                # Reconstruct plan mode state
                if plan_path:
                    self.plan_mode_state.plan_file_path = Path(plan_path)
                    self.plan_mode_state.session_id = self._session_id
                self.plan_mode_state.is_active = True
                self.plan_mode_state._awaiting_approval = False
            # Sync permission_manager to PLAN mode
            if self.permission_manager.get_mode() != PermissionMode.PLAN:
                self.permission_manager.set_mode(PermissionMode.PLAN)

        elif current_mode == "awaiting_approval":
            # Awaiting approval - set awaiting state
            if plan_path:
                self.plan_mode_state.plan_file_path = Path(plan_path)
            self.plan_mode_state.is_active = False
            self.plan_mode_state._awaiting_approval = True
            if plan_hash:
                self.plan_mode_state.plan_hash = plan_hash
            # Keep permission_manager in PLAN mode during approval
            if self.permission_manager.get_mode() != PermissionMode.PLAN:
                self.permission_manager.set_mode(PermissionMode.PLAN)

        elif current_mode == "normal":
            # Normal mode - clear plan mode, set permission_manager to NORMAL
            if self.plan_mode_state.is_active or self.plan_mode_state._awaiting_approval:
                self.plan_mode_state.is_active = False
                self.plan_mode_state._awaiting_approval = False
            if self.permission_manager.get_mode() != PermissionMode.NORMAL:
                self.permission_manager.set_mode(PermissionMode.NORMAL)

        elif current_mode == "auto":
            # Auto mode - clear plan mode, set permission_manager to AUTO
            if self.plan_mode_state.is_active or self.plan_mode_state._awaiting_approval:
                self.plan_mode_state.is_active = False
                self.plan_mode_state._awaiting_approval = False
            if self.permission_manager.get_mode() != PermissionMode.AUTO:
                self.permission_manager.set_mode(PermissionMode.AUTO)

    def _register_tools(self) -> None:
        """Register available tools."""
        # File operations
        self.tool_executor.register_tool(ReadFileTool())
        self.tool_executor.register_tool(WriteFileTool())
        self.tool_executor.register_tool(EditFileTool())
        self.tool_executor.register_tool(AppendToFileTool())
        self.tool_executor.register_tool(ListDirectoryTool())

        # Code operations
        self.tool_executor.register_tool(SearchCodeTool())
        self.tool_executor.register_tool(AnalyzeCodeTool())

        # Enhanced search tools (ripgrep-like)
        self.tool_executor.register_tool(GrepTool())
        self.tool_executor.register_tool(GlobTool())

        # LSP-based semantic code analysis
        self.tool_executor.register_tool(GetFileOutlineTool())
        self.tool_executor.register_tool(GetSymbolContextTool())

        # System operations
        self.tool_executor.register_tool(RunCommandTool())

        # Task management (CRUD tools share TaskState)
        self.tool_executor.register_tool(TaskCreateTool(task_state=self.task_state))
        self.tool_executor.register_tool(TaskUpdateTool(task_state=self.task_state))
        self.tool_executor.register_tool(TaskListTool(task_state=self.task_state))
        self.tool_executor.register_tool(TaskGetTool(task_state=self.task_state))

        # Checkpoint tool (controller will be set later by CLI)
        self.tool_executor.register_tool(CreateCheckpointTool(controller=None))

        # Git operations
        self.tool_executor.register_tool(GitStatusTool())
        self.tool_executor.register_tool(GitDiffTool())
        self.tool_executor.register_tool(GitCommitTool())

        # ClarAIty tools disconnected - migrating to markdown-based knowledge system
        # See discussion: SQL DB not LLM-friendly, replacing with .clarity/knowledge/ markdown files
        # Code preserved in src/tools/clarity_tools.py and src/tools/clarity_setup_tool.py

        # Testing & Validation tools
        from src.testing.validation_tool import RunTestsTool, DetectTestFrameworkTool
        self.tool_executor.register_tool(RunTestsTool())
        self.tool_executor.register_tool(DetectTestFrameworkTool())

        # Web tools (search and fetch)
        from src.tools.web_tools import WebSearchTool, WebFetchTool, RunBudget
        self._web_run_budget = RunBudget(max_searches=3, max_fetches=5)
        self._web_search_tool = WebSearchTool()
        self._web_fetch_tool = WebFetchTool()
        self._web_search_tool.set_run_budget(self._web_run_budget)
        self._web_fetch_tool.set_run_budget(self._web_run_budget)
        self.tool_executor.register_tool(self._web_search_tool)
        self.tool_executor.register_tool(self._web_fetch_tool)

        # Plan mode tools (Claude Code-style planning workflow)
        # Note: These tools need plan_mode_state and session_id set
        # They are registered here but the state is passed during execution
        self._enter_plan_mode_tool = EnterPlanModeTool(
            plan_mode_state=self.plan_mode_state,
            session_id=None  # Will be set when session starts
        )
        self._request_plan_approval_tool = RequestPlanApprovalTool(
            plan_mode_state=self.plan_mode_state
        )
        self.tool_executor.register_tool(self._enter_plan_mode_tool)
        self.tool_executor.register_tool(self._request_plan_approval_tool)

        # Subagent delegation (requires subagent_manager to be initialized)
        # This is registered after subagent_manager is initialized in __init__
        # Will be registered separately via _register_delegation_tool()

        self._invalidate_tools_cache()

    def _get_tools(self):
        """Build the tool list for LLM requests (native + MCP).

        Results are cached; call _invalidate_tools_cache() when tools change.
        """
        if self._tools_cache is not None:
            return self._tools_cache
        from src.llm.base import ToolDefinition
        from src.integrations.mcp.bridge import McpBridgeTool
        native_defs = [
            ToolDefinition(**t.get_schema())
            for t in self.tool_executor.tools.values()
            if not isinstance(t, McpBridgeTool)
        ]
        mcp_defs = self._mcp_manager.get_all_tool_definitions() or []
        self._tools_cache = native_defs + list(mcp_defs)
        return self._tools_cache

    def _invalidate_tools_cache(self):
        """Clear cached tool definitions (call after registering/unregistering tools)."""
        self._tools_cache = None

    async def enable_mcp_integration(self, name, mcp_registry, client, secret_store=None):
        """Enable a named MCP integration by connecting and discovering tools.

        Args:
            name: Connection identifier (e.g. "jira", "github").
            mcp_registry: McpToolRegistry instance (with policy gate).
            client: McpClient instance (transport configured, not connected).
            secret_store: Optional SecretStore for auth token resolution.

        Returns:
            Number of MCP tools registered.
        """
        result = await self._mcp_manager.connect(
            name=name,
            config=client._config,
            client=client,
            registry=mcp_registry,
            tool_executor=self.tool_executor,
            secret_store=secret_store,
        )
        self._invalidate_tools_cache()
        return result

    async def disable_mcp_integration(self, name):
        """Disconnect a named MCP integration.

        Args:
            name: Connection identifier.
        """
        await self._mcp_manager.disconnect(name, self.tool_executor)
        self._invalidate_tools_cache()

    def _fix_orphaned_tool_calls(self, context: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Fix tool_call/tool_result ordering to satisfy Claude API requirements.

        Claude API requires:
        1. Every tool_use must have a corresponding tool_result
        2. tool_result must come IMMEDIATELY AFTER the assistant message with tool_use

        This method:
        1. Detects orphaned tool_calls (missing tool_result) and creates synthetic ones
        2. Reorders ALL tool_results to be immediately after their assistant messages

        The reordering is critical because when context is rebuilt from MessageStore,
        tool_results may have later seq numbers and appear in wrong positions.

        Args:
            context: The conversation context (list of messages)

        Returns:
            The context with proper tool_call/tool_result ordering
        """
        from src.core.tool_status import ToolStatus as CoreToolStatus
        from src.observability import get_logger
        logger = get_logger("agent")

        logger.debug(f"[ORPHAN_CHECK] Scanning context with {len(context)} messages")

        # Collect all tool_call_ids from assistant messages
        tool_call_ids_needed = set()
        tool_call_info = {}  # tool_call_id -> (tool_name, index in context)

        for i, msg in enumerate(context):
            if msg.get("role") == "assistant" and msg.get("tool_calls"):
                for tc in msg["tool_calls"]:
                    tc_id = tc.get("id")
                    tc_name = tc.get("function", {}).get("name", "unknown")
                    if tc_id:
                        tool_call_ids_needed.add(tc_id)
                        tool_call_info[tc_id] = (tc_name, i)

        # Collect all existing tool_results (by tool_call_id -> message)
        existing_tool_results = {}
        for msg in context:
            if msg.get("role") == "tool":
                tc_id = msg.get("tool_call_id")
                if tc_id:
                    existing_tool_results[tc_id] = msg

        # Find orphans (tool_calls without tool_results)
        orphaned_ids = tool_call_ids_needed - set(existing_tool_results.keys())

        logger.debug(
            f"[ORPHAN_CHECK] tool_calls_needed: {list(tool_call_ids_needed)}, "
            f"tool_results_found: {list(existing_tool_results.keys())}, "
            f"orphans: {list(orphaned_ids)}"
        )

        # Create synthetic tool_results for orphans
        for tc_id in orphaned_ids:
            tc_name, _ = tool_call_info.get(tc_id, ("unknown", -1))
            synthetic_msg = {
                "role": "tool",
                "tool_call_id": tc_id,
                "name": tc_name,
                "content": "Tool call rejected by user."
            }
            existing_tool_results[tc_id] = synthetic_msg

            logger.debug(f"[ORPHAN_FIX] Created synthetic tool_result for orphan: {tc_id}")

            # Persist to MessageStore so this fix is permanent
            persisted_msg = self.memory.add_tool_result(
                tool_call_id=tc_id,
                content=synthetic_msg["content"],
                tool_name=tc_name,
                status="interrupted",
            )
            if persisted_msg:
                logger.debug(
                    f"[ORPHAN_FIX] Persisted synthetic tool_result: "
                    f"uuid={persisted_msg.uuid}, seq={persisted_msg.seq}, "
                    f"tool_call_id={tc_id}"
                )
            else:
                logger.error(
                    f"[ORPHAN_FIX] FAILED to persist synthetic tool_result for {tc_id}! "
                    "MessageStore may not be configured."
                )

            # Update tool_state if message_store exists
            if self.memory.message_store:
                self.memory.message_store.update_tool_state(
                    tc_id,
                    CoreToolStatus.ERROR  # Mark as error since it was interrupted
                )

        # CRITICAL: Rebuild context with tool_results in correct positions
        # Tool_results MUST come immediately after their assistant messages
        # This handles both orphans AND mispositioned existing tool_results
        result_context = []
        tool_results_placed = set()

        for msg in context:
            # Skip tool messages - we'll insert them in the correct position
            if msg.get("role") == "tool":
                continue

            result_context.append(msg)

            # After each assistant message with tool_calls, insert ALL its tool_results
            if msg.get("role") == "assistant" and msg.get("tool_calls"):
                for tc in msg["tool_calls"]:
                    tc_id = tc.get("id")
                    if tc_id and tc_id in existing_tool_results:
                        result_context.append(existing_tool_results[tc_id])
                        tool_results_placed.add(tc_id)

        # Log reordering
        if tool_call_ids_needed:
            logger.debug(
                f"[ORPHAN_FIX] Rebuilt context: {len(tool_results_placed)} tool_results "
                f"placed immediately after their assistant messages"
            )

        return result_context

    # NOTE: _handle_clarify_tool, _handle_request_plan_approval_tool, and
    # _handle_director_plan_approval moved to src/core/special_tool_handlers.py
    # -> SpecialToolHandlers (Phase 3 refactor)

    def index_codebase(
        self,
        directory: Optional[str] = None,
        file_patterns: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Index codebase for RAG retrieval.

        Args:
            directory: Directory to index (default: working directory)
            file_patterns: File patterns to include

        Returns:
            Indexing statistics
        """
        if not directory:
            directory = str(self.working_directory)

        print(f"Indexing codebase at: {directory}")

        # Lazy import RAG components (optional dependency)
        try:
            from src.rag import CodeIndexer, Embedder, HybridRetriever
        except ImportError:
            raise ImportError(
                "RAG dependencies not installed. Install with: pip install claraity-code[rag]"
            )

        # Initialize RAG components
        self.indexer = CodeIndexer(chunk_size=512, chunk_overlap=50)
        self.embedder = Embedder(
            model_name=self.embedding_model,
            api_key=self.embedding_api_key,
            api_key_env=self.embedding_api_key_env,
            base_url=self.embedding_base_url,
        )

        # Index codebase
        chunks, index, dep_graph = self.indexer.index_codebase(
            root_path=directory,
            file_patterns=file_patterns,
        )

        print(f"Generated {len(chunks)} chunks from {index.total_files} files")

        # Generate embeddings
        print("Generating embeddings...")
        self.indexed_chunks = self.embedder.embed_chunks(chunks)

        # Setup retriever
        self.retriever = HybridRetriever(self.embedder, alpha=0.7)
        self.retriever.index_chunks(self.indexed_chunks)

        # Update context builder
        self.context_builder.retriever = self.retriever

        print("Indexing complete!")

        return {
            "total_files": index.total_files,
            "total_chunks": len(self.indexed_chunks),
            "languages": index.languages,
        }

    async def _handle_error_budget_pause(
        self, reason, tool_name, call_id, error_context_block,
        tool_call_count, elapsed_seconds, ui, max_resumes
    ):
        """Handle error budget exceeded pause flow.

        Returns dict with:
            action: 'defer' | 'break' | 'continue'
            events: list of UIEvent objects to yield
            context_additions: list of messages to append to current_context
            tool_message: optional tool result message dict
            user_rejected: True if user chose to stop
        """
        from src.core.events import (
            TextDelta, PausePromptStart, PausePromptEnd,
        )

        result = {
            'action': 'break',
            'events': [],
            'context_additions': [],
            'tool_message': None,
            'user_rejected': False,
        }

        # Check approval precedence (don't show pause during approval wait)
        if self._awaiting_approval:
            logger.debug("error budget exceeded but approval pending; deferring pause")
            result['action'] = 'defer'
            result['tool_message'] = {
                "role": "tool",
                "tool_call_id": call_id,
                "name": tool_name,
                "content": error_context_block
            }
            return result

        # Set state for potential resumption
        self.task_state.last_stop_reason = 'error_budget'

        # Check resume cap (prevent infinite Continue loops)
        resume_count = self.task_state.error_budget_resume_count
        progress_since_resume = self.task_state.successful_tools_since_resume

        if resume_count >= max_resumes:
            result['events'].append(TextDelta(content=(
                f"\n[ERROR] Reached maximum error recovery attempts "
                f"({max_resumes}). "
                "Please provide guidance on how to proceed."
            )))
            result['user_rejected'] = True
            return result

        # Check for no-progress (resumed but still failing)
        pause_reason_code = 'error_budget'
        if resume_count > 0 and progress_since_resume == 0:
            pause_reason_code = 'error_budget_no_progress'
            reason = f"{reason} (no progress since last resume)"

        # Check if UI supports interactive pause
        if hasattr(ui, 'has_pause_capability') and ui.has_pause_capability():
            pending_todos = self.task_state.get_pending_summary()
            error_stats = self._error_tracker.get_stats()
            stats = {
                'tool_calls': tool_call_count,
                'elapsed_s': elapsed_seconds,
                'errors_total': error_stats['total_failures'],
                'error_reason': reason,
            }

            result['events'].append(PausePromptStart(
                reason=f"Error budget: {reason}",
                reason_code=pause_reason_code,
                pending_todos=pending_todos,
                stats=stats,
            ))

            try:
                pause_result = await ui.wait_for_pause_response(timeout=None)
                result['events'].append(PausePromptEnd(
                    continue_work=pause_result.continue_work,
                    feedback=pause_result.feedback,
                ))

                if not pause_result.continue_work:
                    result['user_rejected'] = True
                    return result

                # User chose to continue - partial reset
                self.task_state.error_budget_resume_count += 1
                self.task_state.successful_tools_since_resume = 0
                self._error_tracker.reset_tool_error_counts(tool_name=tool_name)

                result['context_additions'].append({
                    "role": "system",
                    "content": "<notice>Continuing after error budget pause. Try a different approach; repeated identical calls are blocked.</notice>"
                })

                if pause_result.feedback:
                    result['context_additions'].append({
                        "role": "user",
                        "content": f"[User guidance: {pause_result.feedback}]"
                    })

                result['tool_message'] = {
                    "role": "tool",
                    "tool_call_id": call_id,
                    "name": tool_name,
                    "content": error_context_block
                }
                result['action'] = 'continue'
                return result

            except asyncio.CancelledError:
                result['user_rejected'] = True
                return result
        else:
            # Fallback - no interactive pause available
            result['events'].append(TextDelta(content=self._build_pause_message('error_budget')))
            result['user_rejected'] = False
            return result

    async def stream_response(
        self,
        user_input: str,
        ui: 'UIProtocol',
        attachments: 'Optional[List]' = None,
    ) -> 'AsyncIterator[UIEvent]':
        """
        Stream response to UI as typed UIEvent objects.

        This is the main integration point between the agent and Textual TUI.
        Transforms LLM streaming output into typed events for the UI.

        Args:
            user_input: User message
            ui: UIProtocol for bidirectional communication (approvals, interrupts)
            attachments: Optional list of Attachment objects (images, text files)

        Yields:
            UIEvent instances (StreamStart, TextDelta, ToolCallStart, etc.)
        """
        from typing import AsyncIterator, Optional, List
        from src.core.events import (
            UIEvent, StreamStart, StreamEnd, TextDelta,
            PausePromptStart, PausePromptEnd, ContextUpdated, ContextCompacting, ContextCompacted,
            FileReadEvent,
        )
        from src.core.tool_status import ToolStatus as CoreToolStatus
        from src.core.render_meta import ToolApprovalMeta
        from src.core.stream_phases import build_pause_stats
        import time

        # Bind context for logging correlation
        stream_id = str(uuid.uuid4())[:8]
        bind_context(
            session=self.memory.session_id if hasattr(self.memory, 'session_id') else None,
            stream=stream_id,
            request=new_request_id(),
            comp='core.agent',
            op='stream_response',
        )

        # Reset error tracker at start of each user request
        # (NOT in tool loop - that would reset mid-request)
        self._error_tracker.reset()

        # Reset compaction cooldown for new user message
        self._compaction_failed = False

        # Track blocked calls for controller constraint injection
        blocked_calls: List[str] = []

        # Safety limit for iterations (emergency brake only)
        # Primary limits are: MAX_TOOL_CALLS (200) and MAX_WALL_TIME_SECONDS (90)
        # Definition: 1 iteration = 1 LLM call cycle (can produce 0-5+ tool calls)
        ABSOLUTE_MAX_ITERATIONS = 50

        # Approval check delegated to self._gating.needs_approval()

        try:
            # Create task context
            task_context = TaskContext(
                task_id=str(uuid.uuid4()),
                description=user_input,
                task_type="chat",
                key_concepts=[],
            )
            self.memory.set_task_context(task_context)

            # Add user message to memory with attachments
            # MemoryManager will build multimodal content and store it in MessageStore
            self.memory.add_user_message(user_input, attachments=attachments)

            # Parse and load file references
            file_references = self.file_reference_parser.parse_and_load(user_input)

            # Emit FileReadEvent for each loaded file (TUI shows subtle confirmation)
            for ref in (file_references or []):
                if ref.is_loaded:
                    yield FileReadEvent(
                        path=ref.display_path,
                        lines_read=ref.lines_read,
                        truncated=ref.truncated,
                    )

            # StreamStart AFTER FileReadEvents so TUI can flush buffered
            # file-read notes (which need UserMessage widget to be mounted).
            # Sequence: add_user_message → FileReadEvent(s) → StreamStart → LLM call
            yield StreamStart()

            # CRITICAL: Sync plan mode state from MessageStore before building context
            # This ensures agent's in-memory state matches persisted state (single source of truth)
            self._sync_plan_mode_from_store()

            # Build initial context (with agent state for task continuation)
            # MemoryManager uses MessageStore when configured (Option A: Single Source of Truth)
            context = self.context_builder.build_context(
                user_query=user_input,
                task_type="chat",
                language="python",
                use_rag=len(self.indexed_chunks) > 0,
                available_chunks=self.indexed_chunks if self.indexed_chunks else None,
                file_references=file_references if file_references else None,
                agent_state=self.todo_state if self.todo_state.get('todos') else None,
                plan_mode_state=self.plan_mode_state,
                director_adapter=self.director_adapter,
            )

            # NOTE: Context usage is emitted after each LLM response with real token count
            # (see chunk.done handling below). We don't emit here to avoid overwriting
            # accurate LLM usage with tiktoken estimates on subsequent messages.

            # Multimodal content (attachments) is now properly stored in MessageStore
            # and will be included in context automatically via build_context()

            # Tool execution loop with realistic budgets
            # These limits are for real coding workflows (reading files, searching, etc.)
            MAX_TOOL_CALLS = 200  # Primary budget - generous for multi-step workflows
            MAX_WALL_TIME_SECONDS = None  # Disabled - tool_call limit is primary constraint
            MAX_PAUSE_CONTINUES = 3  # Safety cap - prevent infinite continuation
            MAX_ERROR_BUDGET_RESUMES = 2  # Cap on error budget "Continue" to prevent infinite loops

            tool_call_count = 0
            loop_start_time = time.monotonic()
            iteration = 0
            pause_continue_count = 0  # Track how many times user continued after pause
            current_context = context.copy()

            while True:  # Budgets checked inside loop
                iteration += 1

                # Budget checks: tool calls, wall time, and absolute safety limit
                elapsed_seconds = time.monotonic() - loop_start_time

                # Determine which limit was hit (if any)
                pause_reason = None
                pause_reason_code = None

                if tool_call_count >= MAX_TOOL_CALLS:
                    pause_reason = f"Tool limit reached ({tool_call_count}/{MAX_TOOL_CALLS})"
                    pause_reason_code = 'max_tool_calls'
                elif MAX_WALL_TIME_SECONDS and elapsed_seconds >= MAX_WALL_TIME_SECONDS:
                    pause_reason = f"Time limit reached ({elapsed_seconds:.0f}s/{MAX_WALL_TIME_SECONDS}s)"
                    pause_reason_code = 'max_wall_time'
                elif iteration >= ABSOLUTE_MAX_ITERATIONS:
                    pause_reason = f"Iteration limit reached ({iteration}/{ABSOLUTE_MAX_ITERATIONS})"
                    pause_reason_code = 'max_iterations'
                elif ui.check_interrupted():
                    pause_reason = "User interrupted"
                    pause_reason_code = 'user_interrupt'

                # Handle pause if limit was hit
                if pause_reason_code:
                    # Check if we've exceeded max continues (safety cap)
                    if pause_continue_count >= MAX_PAUSE_CONTINUES:
                        yield TextDelta(content=f"\n\n---\n**Stopped**: Maximum continues ({MAX_PAUSE_CONTINUES}) reached. Start a new message to continue.\n")
                        break

                    # Set state for potential resumption
                    self.task_state.last_stop_reason = pause_reason_code

                    # Check if UI supports interactive pause
                    if hasattr(ui, 'has_pause_capability') and ui.has_pause_capability():
                        # TUI mode - use interactive widget
                        pending_todos = self.task_state.get_pending_summary()

                        yield PausePromptStart(
                            reason=pause_reason,
                            reason_code=pause_reason_code,
                            pending_todos=pending_todos,
                            stats=build_pause_stats(tool_call_count, elapsed_seconds, iteration),
                        )

                        try:
                            result = await ui.wait_for_pause_response(timeout=None)
                            yield PausePromptEnd(
                                continue_work=result.continue_work,
                                feedback=result.feedback,
                            )

                            if not result.continue_work:
                                break  # User chose to stop

                            # User chose to continue - reset budgets
                            pause_continue_count += 1
                            tool_call_count = 0
                            iteration = 0
                            loop_start_time = time.monotonic()

                            # Inject feedback into context if provided
                            if result.feedback:
                                current_context.append({
                                    "role": "user",
                                    "content": f"[User guidance after pause: {result.feedback}]"
                                })

                            # Continue the loop instead of breaking
                            continue

                        except asyncio.CancelledError:
                            break
                    else:
                        # Fallback - no interactive pause available
                        yield TextDelta(content=self._build_pause_message(pause_reason_code))
                        break

                # Clear blocked calls from previous iteration
                blocked_calls.clear()

                # Wrap LLM streaming in try/except to handle provider errors gracefully
                # (e.g., ReadTimeout, connection errors) without silent exit
                provider_error = None
                response_content = ""
                tool_calls = None

                try:
                    # === SAFETY NET: Fix any orphaned tool_calls before LLM call ===
                    # This handles Ctrl+C interrupts, crashes, and any edge cases
                    # where tool_use exists without tool_result
                    current_context = self._fix_orphaned_tool_calls(current_context)

                    # === UNIFIED ARCHITECTURE: Use ProviderDelta + StreamingPipeline ===
                    # 1. Start assistant stream through MemoryManager
                    self.memory.start_assistant_stream(
                        provider=self.backend_name,
                        model=self.model_name
                    )

                    # 2. Get LLM stream - yields ProviderDelta objects
                    llm_stream = self.llm.generate_provider_deltas_async(
                        messages=current_context,
                        tools=self._get_tools(),
                        tool_choice="auto"
                    )

                    # 3. Process ProviderDelta objects through MemoryManager
                    finalized_message = None
                    last_usage = None

                    async for delta in llm_stream:
                        # Feed delta to MemoryManager (uses StreamingPipeline internally)
                        finalized_message = self.memory.process_provider_delta(delta)

                        # Yield text deltas to TUI for incremental rendering
                        if delta.text_delta:
                            yield TextDelta(content=delta.text_delta)

                        # Track usage for context update
                        if delta.usage:
                            last_usage = delta.usage

                        # Check for interrupt
                        if ui.check_interrupted():
                            break

                    # 4. Extract tool_calls and response_content from finalized message
                    if finalized_message and finalized_message.tool_calls:
                        tool_calls = finalized_message.tool_calls

                    # Derive response_content from pipeline (single source of truth)
                    response_content = (finalized_message.content or "") if finalized_message else self.memory.get_partial_text()

                    # Emit context usage update with real token count from LLM
                    if (last_usage and last_usage.get("input_tokens") is not None
                        and self.context_builder
                        and self.context_builder.max_context_tokens > 0):
                        input_tokens = last_usage.get("input_tokens")
                        pressure_level = self._get_pressure_level(input_tokens)

                        yield ContextUpdated(
                            used=input_tokens,
                            limit=self.context_builder.max_context_tokens,
                            pressure_level=pressure_level,
                        )

                        # Compaction trigger: if context usage >= 85%, compact
                        # and rebuild current_context so next LLM call is smaller.
                        # Uses the LLM's real token count (ground truth).
                        # Skip if compaction already failed this request (cooldown).
                        COMPACTION_THRESHOLD = 0.85
                        utilization = input_tokens / self.context_builder.max_context_tokens
                        if utilization >= COMPACTION_THRESHOLD and not self._compaction_failed:
                            logger.info(
                                "compaction_triggered",
                                input_tokens=input_tokens,
                                context_window=self.context_builder.max_context_tokens,
                                utilization=f"{utilization:.1%}",
                                iteration=iteration,
                            )

                            yield ContextCompacting(tokens_before=input_tokens)

                            # Wrap compaction in its own try/except so failures
                            # don't fall into the provider-error handler below.
                            messages_removed = 0
                            try:
                                messages_removed = await self.memory.compact_conversation_async(
                                    current_input_tokens=input_tokens,
                                    llm_backend=self.llm,
                                )

                                if messages_removed > 0:
                                    # Rebuild current_context from compacted MessageStore
                                    current_context = self.context_builder.build_context(
                                        user_query=user_input,
                                        task_type="chat",
                                        language="python",
                                        use_rag=len(self.indexed_chunks) > 0,
                                        available_chunks=self.indexed_chunks if self.indexed_chunks else None,
                                        file_references=file_references if file_references else None,
                                        agent_state=self.todo_state if self.todo_state.get('todos') else None,
                                        plan_mode_state=self.plan_mode_state,
                                        director_adapter=self.director_adapter,
                                    )
                            except Exception as compact_err:
                                logger.error("compaction_failed", error=str(compact_err))
                                self._compaction_failed = True

                            # Always emit ContextCompacted to clear status bar
                            yield ContextCompacted(
                                messages_removed=messages_removed,
                                tokens_before=input_tokens,
                                tokens_after=0,
                            )

                except Exception as e:
                    # Provider error (ReadTimeout, connection error, API error)
                    # Use structured logging with full context for debugging
                    error_type = type(e).__name__
                    error_msg = str(e).strip() or repr(e)

                    # Determine error category
                    is_timeout = 'timeout' in error_type.lower()
                    category = ErrorCategory.PROVIDER_TIMEOUT if is_timeout else ErrorCategory.PROVIDER_ERROR

                    # Find root cause in exception chain
                    root_cause = e
                    while root_cause.__cause__ is not None:
                        root_cause = root_cause.__cause__
                    root_cause_type = type(root_cause).__name__
                    root_cause_message = str(root_cause).strip()[:500]

                    # Calculate elapsed time since iteration start
                    elapsed_ms = int((time.monotonic() - loop_start_time) * 1000)

                    # Record error to SQLite store and get error_id for reference
                    from src.observability.error_store import get_error_store, ErrorCategory as StoreCategory
                    import traceback as tb
                    error_store = get_error_store()
                    error_id = error_store.record_from_dict(
                        level="ERROR",
                        category=category,
                        error_type=error_type,
                        message=error_msg,
                        traceback=tb.format_exc(),
                        component="core.agent",
                        operation="stream_response",
                        model=self.model_name,
                        backend=self.backend_name,
                        elapsed_ms=elapsed_ms,
                        root_cause_type=root_cause_type,
                        root_cause_message=root_cause_message,
                    )

                    # Log with structlog (JSONL) - includes error_id for correlation
                    logger.exception(
                        "llm_provider_error",
                        category=category,
                        error_type=error_type,
                        error_id=error_id,
                        model=self.model_name,
                        backend=self.backend_name,
                        iteration=iteration,
                        tool_call_count=tool_call_count,
                        elapsed_ms=elapsed_ms,
                        root_cause_type=root_cause_type,
                        root_cause_message=root_cause_message,
                    )

                    # Determine user-friendly message (no stack traces!)
                    is_timeout = "timeout" in root_cause_type.lower()
                    if is_timeout:
                        user_message = "Request timed out. The server took too long to respond."
                    else:
                        user_message = "Connection error. Please check your network."

                    # Emit ErrorEvent for TUI visibility (recoverable)
                    # Use root_cause_type (not error_type) to correctly classify wrapped exceptions
                    from src.core.events import ErrorEvent
                    yield ErrorEvent(
                        error_type="provider_timeout" if is_timeout else "network",
                        user_message=user_message,
                        error_id=error_id,
                        recoverable=True,
                        retry_after=None
                    )

                    # Set provider_error for pause flow (also user-friendly)
                    provider_error = user_message

                # Handle provider error by transitioning to pause state
                if provider_error:
                    pause_reason = provider_error  # Already user-friendly, no prefix needed
                    pause_reason_code = 'provider_error'

                    # Store any partial response
                    if response_content:
                        self.memory.add_assistant_message(response_content)

                    # Transition to pause state (same as other limits)
                    if hasattr(ui, 'has_pause_capability') and ui.has_pause_capability():
                        # TUI mode - emit PausePromptStart and wait
                        pending_todos = self.task_state.get_pending_summary()

                        yield PausePromptStart(
                            reason=pause_reason,
                            reason_code=pause_reason_code,
                            pending_todos=pending_todos,
                            stats=build_pause_stats(
                                tool_call_count, time.monotonic() - loop_start_time,
                                iteration, error=provider_error
                            ),
                        )

                        # Wait for user decision (with timeout to prevent deadlock)
                        try:
                            result = await ui.wait_for_pause_response(timeout=300.0)
                            yield PausePromptEnd(
                                continue_work=result.continue_work,
                                feedback=result.feedback
                            )
                            if not result.continue_work:
                                # Save partial response to memory so next message has context
                                if response_content and response_content.strip():
                                    # Truncate to avoid polluting memory with very long partials
                                    partial = response_content.strip()
                                    if len(partial) > 4000:
                                        partial = partial[:4000] + "..."
                                    # Tag as timed out for clarity in conversation history
                                    self.memory.add_assistant_message(
                                        partial + "\n\n[TIMED OUT: Response was cut off due to provider timeout. User chose to stop.]"
                                    )
                                break
                            # User chose to retry - add partial response context so LLM can continue
                            if response_content and response_content.strip():
                                # Truncate if very long (keep last 2000 chars for context)
                                partial = response_content.strip()
                                if len(partial) > 2000:
                                    partial = "..." + partial[-2000:]
                                # Add assistant's partial response with anchor delimiter
                                current_context.append({
                                    "role": "assistant",
                                    "content": partial + "\n\n[END OF PARTIAL RESPONSE]"
                                })
                                # Add continuation instruction (plain text, no fake system prefix)
                                current_context.append({
                                    "role": "user",
                                    "content": "Your previous response was cut off by a timeout. Continue AFTER [END OF PARTIAL RESPONSE]. Do not repeat anything above. If unsure where to resume, ask."
                                })
                                # Add visual separator in UI so continuation is clearly appended
                                yield TextDelta(content="\n\n")
                            continue
                        except asyncio.CancelledError:
                            # Treat cancellation as STOP (not interrupt semantics)
                            yield PausePromptEnd(continue_work=False, feedback="Pause cancelled")
                            break
                    else:
                        # Fallback - no interactive pause available
                        yield TextDelta(content=self._build_pause_message(pause_reason_code))
                        break

                # If interrupted, stop processing
                if ui.check_interrupted():
                    break

                # If no tool calls, we're done
                # NOTE: Message already added to store by process_provider_delta() at line 2198
                # Do NOT call add_assistant_message() again - it would create duplicate
                if not tool_calls:
                    break

                # Process tool calls
                tool_messages = []
                user_rejected = False  # Track if user rejected any tool

                for tc in tool_calls:
                    call_id = tc.id or f"call_{uuid.uuid4().hex[:8]}"

                    # Run all gating checks via centralized service
                    tool_args = tc.function.get_parsed_arguments()
                    from src.core.tool_gating import GateAction
                    gate_result = self._gating.evaluate(tc.function.name, tool_args)

                    if gate_result.action == GateAction.BLOCKED_REPEAT:
                        blocked_calls.append(gate_result.call_summary)

                        if self.memory.message_store:
                            self.memory.message_store.update_tool_state(
                                call_id,
                                CoreToolStatus.SKIPPED
                            )

                        tool_messages.append({
                            "role": "tool",
                            "tool_call_id": call_id,
                            "name": tc.function.name,
                            "content": gate_result.message,
                        })
                        continue  # Move to next tool call

                    if gate_result.action == GateAction.DENY:
                        if self.memory.message_store:
                            self.memory.message_store.update_tool_state(
                                call_id,
                                CoreToolStatus.ERROR,
                                error=gate_result.message
                            )

                        gated_output = self._gating.format_gate_response(gate_result.gate_response)
                        tool_messages.append({
                            "role": "tool",
                            "tool_call_id": call_id,
                            "name": tc.function.name,
                            "content": gated_output
                        })

                        self.memory.add_tool_result(
                            tool_call_id=call_id,
                            content=gated_output,
                            tool_name=tc.function.name,
                            status="gated",
                        )
                        continue  # Skip to next tool call

                    requires_approval = gate_result.action == GateAction.NEEDS_APPROVAL

                    # Freeze approval policy in render meta registry (store-driven UI)
                    # This captures the policy at tool-call creation time (freeze semantics)
                    mode = self.permission_manager.get_mode() if self.permission_manager else PermissionMode.NORMAL
                    self.memory.render_meta.set_approval_meta(
                        call_id,
                        ToolApprovalMeta(
                            requires_approval=requires_approval,
                            permission_mode=mode.value if hasattr(mode, 'value') else str(mode)
                        )
                    )

                    # Initialize tool state in message store (for TUI rendering)
                    if self.memory.message_store:
                        self.memory.message_store.update_tool_state(
                            call_id,
                            CoreToolStatus.PENDING
                        )

                    # Handle approval if required
                    if requires_approval:
                        # Set approval state to prevent pause prompts during approval wait
                        self._awaiting_approval = True

                        # Update tool state in message store
                        if self.memory.message_store:
                            self.memory.message_store.update_tool_state(
                                call_id,
                                CoreToolStatus.AWAITING_APPROVAL
                            )

                        try:
                            # Wait for user approval via UI (no timeout - user may be multitasking)
                            approval_result = await ui.wait_for_approval(call_id, tc.function.name, timeout=None)

                            if not approval_result.approved:
                                # Build rejection message with optional feedback
                                if approval_result.feedback:
                                    # User provided feedback - pass to LLM so it can try again
                                    rejection_msg = f"User rejected with feedback: {approval_result.feedback}"

                                    # Update tool_state in message store
                                    if self.memory.message_store:
                                        self.memory.message_store.update_tool_state(
                                            call_id,
                                            CoreToolStatus.REJECTED
                                        )

                                    # Add feedback to tool messages so LLM sees it
                                    tool_messages.append({
                                        "role": "tool",
                                        "tool_call_id": call_id,
                                        "name": tc.function.name,
                                        "content": rejection_msg
                                    })

                                    # Persist tool result to MessageStore for session replay
                                    self.memory.add_tool_result(
                                        tool_call_id=call_id,
                                        content=rejection_msg,
                                        tool_name=tc.function.name,
                                        status="rejected",
                                    )

                                    # Continue to next tool call (don't stop - LLM will see feedback)
                                    continue
                                else:
                                    # Pure rejection (Escape) - stop completely
                                    rejection_msg = "Tool call rejected by user"

                                    # CRITICAL: Update tool_state in message store
                                    if self.memory.message_store:
                                        self.memory.message_store.update_tool_state(
                                            call_id,
                                            CoreToolStatus.REJECTED
                                        )

                                    # CRITICAL: Add tool_result for rejected call
                                    # Claude API requires every tool_use to have a tool_result
                                    tool_messages.append({
                                        "role": "tool",
                                        "tool_call_id": call_id,
                                        "name": tc.function.name,
                                        "content": rejection_msg
                                    })

                                    # Persist tool result to MessageStore for session replay
                                    self.memory.add_tool_result(
                                        tool_call_id=call_id,
                                        content=rejection_msg,
                                        tool_name=tc.function.name,
                                        status="rejected",
                                    )

                                    # User rejected without feedback - stop execution immediately
                                    # Don't continue processing, let user decide next action
                                    user_rejected = True
                                    break  # Exit tool loop immediately

                            # Update tool state in message store
                            if self.memory.message_store:
                                self.memory.message_store.update_tool_state(
                                    call_id,
                                    CoreToolStatus.APPROVED
                                )

                        except asyncio.TimeoutError:
                            if self.memory.message_store:
                                self.memory.message_store.update_tool_state(
                                    call_id,
                                    CoreToolStatus.CANCELLED
                                )
                            tool_messages.append({
                                "role": "tool",
                                "tool_call_id": call_id,
                                "name": tc.function.name,
                                "content": "Tool call approval timed out"
                            })
                            continue

                        except asyncio.CancelledError:
                            cancelled_msg = "Tool call cancelled by user (stream interrupted)"

                            # CRITICAL: Update tool_state in message store
                            if self.memory.message_store:
                                self.memory.message_store.update_tool_state(
                                    call_id,
                                    CoreToolStatus.CANCELLED
                                )

                            # CRITICAL: Add tool_result for cancelled call
                            tool_messages.append({
                                "role": "tool",
                                "tool_call_id": call_id,
                                "name": tc.function.name,
                                "content": cancelled_msg
                            })

                            # Persist tool result to MessageStore for session replay
                            self.memory.add_tool_result(
                                tool_call_id=call_id,
                                content=cancelled_msg,
                                tool_name=tc.function.name,
                                status="cancelled",
                            )

                            # Mark as cancelled (similar to user_rejected)
                            user_rejected = True
                            break  # Exit tool loop, don't re-raise

                        finally:
                            # ALWAYS reset approval state, even on exception/cancel
                            self._awaiting_approval = False

                    # Execute tool
                    # Update tool state in message store
                    if self.memory.message_store:
                        self.memory.message_store.update_tool_state(
                            call_id,
                            CoreToolStatus.RUNNING
                        )

                    start_time = time.monotonic()

                    # Increment tool call counter for budget tracking
                    tool_call_count += 1

                    # Special handling for clarify tool (requires UI interaction)
                    if self._special_handlers.handles(tc.function.name) and tc.function.name == "clarify":
                        clarify_result = await self._special_handlers.handle_clarify(
                            call_id,
                            tc.function.get_parsed_arguments(),
                            ui
                        )

                        duration_ms = int((time.monotonic() - start_time) * 1000)

                        # Update tool state in message store
                        if self.memory.message_store:
                            self.memory.message_store.update_tool_state(
                                call_id,
                                CoreToolStatus.SUCCESS,
                                result=clarify_result,
                                duration_ms=duration_ms
                            )

                        # Persist tool result to MessageStore for session replay
                        self.memory.add_tool_result(
                            tool_call_id=call_id,
                            content=json.dumps(clarify_result),
                            tool_name=tc.function.name,
                            status="success",
                            duration_ms=duration_ms,
                        )

                        tool_messages.append({
                            "role": "tool",
                            "tool_call_id": call_id,
                            "name": tc.function.name,
                            "content": json.dumps(clarify_result)
                        })
                        continue  # Skip to next tool call

                    # Special handling for request_plan_approval (requires UI approval)
                    if self._special_handlers.handles(tc.function.name) and tc.function.name == "request_plan_approval":
                        approval_result, plan_rejected = await self._special_handlers.handle_plan_approval(
                            call_id, ui
                        )

                        duration_ms = int((time.monotonic() - start_time) * 1000)

                        # Determine tool status based on rejection flag
                        tool_status = CoreToolStatus.REJECTED if plan_rejected else CoreToolStatus.SUCCESS
                        result_status = "rejected" if plan_rejected else "success"

                        if self.memory.message_store:
                            self.memory.message_store.update_tool_state(
                                call_id,
                                tool_status,
                                result=approval_result,
                                duration_ms=duration_ms
                            )

                        self.memory.add_tool_result(
                            tool_call_id=call_id,
                            content=approval_result,
                            tool_name=tc.function.name,
                            status=result_status,
                            duration_ms=duration_ms,
                        )

                        tool_messages.append({
                            "role": "tool",
                            "tool_call_id": call_id,
                            "name": tc.function.name,
                            "content": approval_result
                        })

                        # If user rejected without feedback (Escape), stop tool loop
                        if plan_rejected:
                            user_rejected = True
                            break  # Exit tool loop, wait for user input (no LLM call)

                        continue  # Skip to next tool call

                    # Special handling for director_complete_plan (requires UI approval)
                    if self._special_handlers.handles(tc.function.name) and tc.function.name == "director_complete_plan":
                        # Execute the tool first (transitions to AWAITING_APPROVAL)
                        try:
                            tool_kwargs = tc.function.get_parsed_arguments()
                        except Exception as parse_err:
                            logger.error("director_complete_plan: failed to parse arguments: %s", parse_err)
                            tool_kwargs = {}
                        result = await self.tool_executor.execute_tool_async(
                            tc.function.name, **tool_kwargs
                        )

                        if result.is_success():
                            # Emit AWAITING_APPROVAL phase change for UI status bar
                            self.memory.persist_system_event(
                                event_type="director_phase_changed",
                                content="Director phase: AWAITING_APPROVAL",
                                extra={"phase": "AWAITING_APPROVAL"},
                                include_in_llm_context=False,
                            )

                            # Now handle the approval flow
                            approval_result, plan_rejected = await self._special_handlers.handle_director_plan_approval(
                                call_id, result, ui
                            )

                            duration_ms = int((time.monotonic() - start_time) * 1000)
                            tool_status = CoreToolStatus.REJECTED if plan_rejected else CoreToolStatus.SUCCESS
                            result_status = "rejected" if plan_rejected else "success"

                            if self.memory.message_store:
                                self.memory.message_store.update_tool_state(
                                    call_id, tool_status,
                                    result=approval_result,
                                    duration_ms=duration_ms
                                )

                            self.memory.add_tool_result(
                                tool_call_id=call_id,
                                content=approval_result,
                                tool_name=tc.function.name,
                                status=result_status,
                                duration_ms=duration_ms,
                            )

                            tool_messages.append({
                                "role": "tool",
                                "tool_call_id": call_id,
                                "name": tc.function.name,
                                "content": approval_result
                            })

                            # Persist director phase change for UI status bar
                            new_phase = self.director_adapter.phase.name
                            self.memory.persist_system_event(
                                event_type="director_phase_changed",
                                content=f"Director phase: {new_phase}",
                                extra={"phase": new_phase},
                                include_in_llm_context=False,
                            )

                            # Refresh system prompt so LLM sees EXECUTE (or PLAN) injection
                            if not plan_rejected:
                                self._refresh_director_context(current_context)

                            if plan_rejected:
                                user_rejected = True
                                break
                        else:
                            # Tool execution failed
                            duration_ms = int((time.monotonic() - start_time) * 1000)
                            error_msg = result.error or "director_complete_plan failed"
                            if self.memory.message_store:
                                self.memory.message_store.update_tool_state(
                                    call_id, CoreToolStatus.ERROR,
                                    error=error_msg, duration_ms=duration_ms
                                )
                            self.memory.add_tool_result(
                                tool_call_id=call_id,
                                content=error_msg,
                                tool_name=tc.function.name,
                                status="error",
                                duration_ms=duration_ms,
                            )
                            tool_messages.append({
                                "role": "tool",
                                "tool_call_id": call_id,
                                "name": tc.function.name,
                                "content": error_msg
                            })

                        continue  # Skip to next tool call

                    try:
                        tool_kwargs = tc.function.get_parsed_arguments()
                        # Pass tool_call_id for delegation tool (registry linking)
                        if tc.function.name == 'delegate_to_subagent':
                            tool_kwargs['_tool_call_id'] = call_id

                        result = await self.tool_executor.execute_tool_async(
                            tc.function.name,
                            **tool_kwargs
                        )

                        duration_ms = int((time.monotonic() - start_time) * 1000)

                        if result.is_success():
                            output = result.output

                            # Claude Code style: return ERROR with guidance for oversized output
                            if isinstance(output, str) and len(output) > self._max_tool_output_chars:
                                error_msg, tool_msg, history = self._format_oversized_output_error(
                                    len(output), tc.function.name,
                                    tc.function.get_parsed_arguments(), call_id
                                )

                                # Update tool state in message store
                                if self.memory.message_store:
                                    self.memory.message_store.update_tool_state(
                                        call_id, CoreToolStatus.ERROR,
                                        error=error_msg, duration_ms=duration_ms
                                    )

                                # Persist tool result to MessageStore for session replay
                                self.memory.add_tool_result(
                                    tool_call_id=call_id, content=error_msg,
                                    tool_name=tc.function.name, status="error",
                                    duration_ms=duration_ms,
                                )
                                tool_messages.append(tool_msg)
                                self.tool_execution_history.append(history)
                                continue  # Skip to next tool call

                            # Update tool state in message store
                            if self.memory.message_store:
                                self.memory.message_store.update_tool_state(
                                    call_id,
                                    CoreToolStatus.SUCCESS,
                                    result=output,
                                    duration_ms=duration_ms
                                )

                            # Persist tool result to MessageStore for session replay
                            self.memory.add_tool_result(
                                tool_call_id=call_id,
                                content=str(output),
                                tool_name=tc.function.name,
                                status="success",
                                duration_ms=duration_ms,
                            )

                            # Track successful tool since error budget resume (for progress detection)
                            if self.task_state.error_budget_resume_count > 0:
                                self.task_state.successful_tools_since_resume += 1

                            # Notify UI when tasks change
                            if tc.function.name in ('task_create', 'task_update'):
                                ui.notify_todos_updated(self.task_state.get_todos_list())

                            # Persist mode change event for enter_plan_mode
                            # (request_plan_approval is handled specially above with approval flow)
                            if tc.function.name == 'enter_plan_mode':
                                self.memory.persist_system_event(
                                    event_type="permission_mode_changed",
                                    content="Mode: -> plan",
                                    extra={"old_mode": "normal", "new_mode": "plan"},
                                    include_in_llm_context=False,
                                )

                            # Persist director phase change events for UI status bar
                            # and refresh system prompt so LLM sees new phase instructions
                            # (director_complete_plan is handled specially above with approval flow)
                            if tc.function.name in ('director_complete_understand', 'director_complete_slice', 'director_complete_integration'):
                                new_phase = self.director_adapter.phase.name
                                self.memory.persist_system_event(
                                    event_type="director_phase_changed",
                                    content=f"Director phase: {new_phase}",
                                    extra={"phase": new_phase},
                                    include_in_llm_context=False,
                                )
                                # Refresh system prompt so LLM sees new phase instructions
                                self._refresh_director_context(current_context)

                            tool_messages.append({
                                "role": "tool",
                                "tool_call_id": call_id,
                                "name": tc.function.name,
                                "content": str(output)
                            })
                        else:
                            # Update tool state in message store
                            if self.memory.message_store:
                                self.memory.message_store.update_tool_state(
                                    call_id,
                                    CoreToolStatus.ERROR,
                                    error=result.error,
                                    duration_ms=duration_ms
                                )

                            # Record failure for intelligent retry
                            # Extract exit_code from metadata; pass result.output as stdout
                            # (ToolResult has .output with combined stdout/stderr, not separate .stdout/.stderr)
                            error_type = self._classify_tool_error(result.error or "Unknown error")
                            error_context = self._error_tracker.record_failure(
                                error_type=error_type,
                                tool_name=tc.function.name,
                                tool_args=tc.function.get_parsed_arguments(),
                                error_message=result.error or "Unknown error",
                                exit_code=result.metadata.get("exit_code"),
                                stdout=result.output if result.output else None,
                                stderr=None  # stderr is included in result.output
                            )

                            # Build tool message with both output and error context
                            error_prompt = error_context.to_prompt_block()
                            if result.output:
                                tool_error_content = f"Command output:\n{result.output}\n\n{error_prompt}"
                            else:
                                tool_error_content = error_prompt

                            # Persist tool result to MessageStore for session replay
                            self.memory.add_tool_result(
                                tool_call_id=call_id,
                                content=tool_error_content,
                                tool_name=tc.function.name,
                                status="error",
                                duration_ms=duration_ms,
                            )

                            # Check if retry should be allowed
                            allowed, reason = self._error_tracker.should_allow_retry(tc.function.name, error_type)

                            if allowed:
                                # Inject structured error context + output for LLM
                                tool_messages.append({
                                    "role": "tool",
                                    "tool_call_id": call_id,
                                    "name": tc.function.name,
                                    "content": tool_error_content
                                })
                            else:
                                # Error budget exceeded - pause flow
                                pause = await self._handle_error_budget_pause(
                                    reason, tc.function.name, call_id, tool_error_content,
                                    tool_call_count, elapsed_seconds, ui, MAX_ERROR_BUDGET_RESUMES
                                )
                                for evt in pause['events']:
                                    yield evt
                                if pause['tool_message']:
                                    tool_messages.append(pause['tool_message'])
                                current_context.extend(pause['context_additions'])
                                if pause['action'] == 'defer':
                                    continue
                                elif pause['user_rejected'] or pause['action'] == 'break':
                                    user_rejected = pause['user_rejected']
                                    break

                    except Exception as e:
                        duration_ms = int((time.monotonic() - start_time) * 1000)

                        # Update tool state in message store
                        if self.memory.message_store:
                            self.memory.message_store.update_tool_state(
                                call_id,
                                CoreToolStatus.ERROR,
                                error=str(e),
                                duration_ms=duration_ms
                            )

                        # Record exception as failure for intelligent retry
                        error_type = self._classify_tool_error(str(e))
                        error_context = self._error_tracker.record_failure(
                            error_type=error_type,
                            tool_name=tc.function.name,
                            tool_args=tc.function.get_parsed_arguments(),
                            error_message=str(e)
                        )

                        # Persist tool result to MessageStore for session replay
                        self.memory.add_tool_result(
                            tool_call_id=call_id,
                            content=error_context.to_prompt_block(),
                            tool_name=tc.function.name,
                            status="error",
                            duration_ms=duration_ms,
                        )

                        # Check if retry should be allowed
                        allowed, reason = self._error_tracker.should_allow_retry(tc.function.name, error_type)

                        if allowed:
                            # Inject structured error context for LLM
                            tool_messages.append({
                                "role": "tool",
                                "tool_call_id": call_id,
                                "name": tc.function.name,
                                "content": error_context.to_prompt_block()
                            })
                        else:
                            # Error budget exceeded - pause flow
                            pause = await self._handle_error_budget_pause(
                                reason, tc.function.name, call_id, error_context.to_prompt_block(),
                                tool_call_count, elapsed_seconds, ui, MAX_ERROR_BUDGET_RESUMES
                            )
                            for evt in pause['events']:
                                yield evt
                            if pause['tool_message']:
                                tool_messages.append(pause['tool_message'])
                            current_context.extend(pause['context_additions'])
                            if pause['action'] == 'defer':
                                continue
                            elif pause['user_rejected'] or pause['action'] == 'break':
                                user_rejected = pause['user_rejected']
                                break

                # If user rejected a tool, add tool_results for remaining unprocessed calls
                # Claude API requires every tool_use to have a corresponding tool_result
                if user_rejected:
                    # Fill in skipped results for unprocessed tool calls
                    from src.core.stream_phases import fill_skipped_tool_results
                    processed_call_ids = {msg.get("tool_call_id") for msg in tool_messages if msg.get("role") == "tool"}
                    skipped_msgs = fill_skipped_tool_results(
                        tool_calls, processed_call_ids,
                        reason="Tool call skipped (previous tool rejected by user)",
                    )
                    for msg in skipped_msgs:
                        tool_messages.append(msg)
                        self.memory.add_tool_result(
                            tool_call_id=msg["tool_call_id"],
                            content=msg["content"],
                            tool_name=msg["name"],
                            status="skipped",
                        )
                        if self.memory.message_store:
                            self.memory.message_store.update_tool_state(
                                msg["tool_call_id"],
                                CoreToolStatus.SKIPPED,
                            )

                    # Add assistant message + tool_results to context for history
                    from src.core.stream_phases import build_assistant_context_message
                    current_context.append(
                        build_assistant_context_message(response_content, tool_calls)
                    )
                    current_context.extend(tool_messages)

                    break  # Exit main while loop

                # Add assistant's response with tool calls to context
                from src.core.stream_phases import build_assistant_context_message
                current_context.append(
                    build_assistant_context_message(response_content, tool_calls)
                )

                # Add tool results to context
                current_context.extend(tool_messages)

                # Inject controller constraint for blocked calls
                from src.core.stream_phases import inject_controller_constraint
                inject_controller_constraint(current_context, blocked_calls)

        except Exception as e:
            # Outer exception handler - catches any exceptions not handled by inner handlers
            # Log full stack trace for debugging
            logger.error(
                f"Unhandled exception in stream_response:\n"
                f"{traceback.format_exc()}"
            )

            # Format error message properly (handles empty str(e))
            error_type = type(e).__name__
            error_msg = str(e).strip()
            if not error_msg:
                error_msg = repr(e)
            formatted_error = f"{error_type}: {error_msg}"

            # Yield error as text with proper formatting
            yield TextDelta(content=f"\n\n[Error: {formatted_error}]")

        # Yield StreamEnd to signal completion
        yield StreamEnd()

    @observe_tool_execution("agent_execute_tool", capture_args=True)
    def execute_tool(self, tool_name: str, **kwargs: Any) -> Any:
        """
        Execute a tool.

        Args:
            tool_name: Name of tool
            **kwargs: Tool parameters

        Returns:
            Tool result

        Raises:
            ToolNotFoundError: Tool does not exist
            ToolExecutionError: Tool execution failed
        """
        result = self.tool_executor.execute_tool(tool_name, **kwargs)

        if result.is_success():
            return result.output
        else:
            # Determine error type from error message
            error_msg = result.error or "Unknown error"
            if "not found" in error_msg.lower() or "unknown tool" in error_msg.lower():
                raise ToolNotFoundError(error_msg)
            else:
                raise ToolExecutionError(error_msg)

    def call_llm(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 4096,
        stream: bool = False,
        **kwargs
    ) -> str:
        """
        Call LLM with conversation messages, returns response text.

        Implements AgentInterface.call_llm().

        Args:
            messages: Conversation history in OpenAI format
            temperature: Sampling temperature (0.0 = deterministic, 1.0 = creative)
            max_tokens: Maximum tokens in response
            stream: Enable streaming (not supported in v1)
            **kwargs: Additional LLM parameters

        Returns:
            str: LLM response text

        Raises:
            LLMError: LLM API error (general)
            RateLimitError: Rate limit exceeded
            TimeoutError: Request timeout
        """
        try:
            # CRITICAL: Validate messages before LLM call
            self.llm.validate_messages(messages)

            # Use the LLM backend's generate method
            # Note: generate_with_tools expects messages with tools list
            # For simple call_llm, we'll use a basic generate call
            response = self.llm.generate_with_tools(
                messages=messages,
                tools=[],  # No tools for simple LLM call
                temperature=temperature,
                max_tokens=max_tokens,
                **kwargs
            )

            # Extract text from response
            if isinstance(response, dict):
                return response.get('content', str(response))
            return str(response)
        except (LLMError, RateLimitError, TimeoutError):
            # Re-raise properly typed LLM exceptions
            raise
        except ValueError as e:
            # Message validation errors
            raise ValueError(f"Invalid messages: {e}") from e
        except Exception as e:
            # Wrap unknown exceptions as LLMError
            raise LLMError(f"LLM call failed: {e}") from e

    def get_context(self) -> Dict[str, Any]:
        """
        Get current execution context.

        Implements AgentInterface.get_context().

        Returns:
            Dict[str, Any]: Context dictionary with working_directory,
                          conversation_history, session_id, and active_task
        """
        # Get conversation history from working memory
        conversation_history = [
            {
                "role": msg.role.value,
                "content": msg.content,
                "timestamp": msg.timestamp.isoformat() if msg.timestamp else None,
            }
            for msg in self.memory.working_memory.messages
        ]

        return {
            "working_directory": str(self.working_directory),
            "conversation_history": conversation_history,
            "session_id": self.memory.session_id,
            "active_task": None,  # TODO: Track active task in future iteration
        }

    def update_memory(self, key: str, value: Any) -> None:
        """
        Update agent memory with key-value pair.

        Implements AgentInterface.update_memory().

        Stores structured data in memory manager's key-value store.
        Data is preserved with full structure (dicts, lists, etc.).

        Args:
            key: Memory key (e.g., 'last_test_result', 'validation_status')
            value: Value to store (any JSON-serializable type)

        Raises:
            MemoryError: Memory update failed
        """
        try:
            self.memory.set_value(key, value)
        except Exception as e:
            raise MemoryError(f"Memory update failed for key '{key}': {e}") from e

    def get_memory(self, key: str, default: Any = None) -> Any:
        """
        Retrieve agent memory by key.

        Retrieves structured data from memory manager's key-value store.

        Args:
            key: Memory key
            default: Default value if key not found

        Returns:
            Stored value, or default if not found

        Example:
            results = agent.get_memory('test_results', {'passed': 0, 'failed': 0})
        """
        return self.memory.get_value(key, default)

    def resume_session_from_jsonl(self, jsonl_path: Path) -> "HydrationResult":
        """
        Resume session from JSONL file using SessionHydrator.

        Restores conversation history only. Task state (todos) is restored
        separately from todos.json when the caller invokes set_session_id().

        Args:
            jsonl_path: Path to session.jsonl file

        Returns:
            HydrationResult with store, base_llm_messages, agent_state, report

        Usage:
            result = agent.resume_session_from_jsonl(Path(".clarity/sessions/abc/session.jsonl"))
            agent.set_session_id(session_id, is_new_session=False)  # enables todo persistence
        """
        from src.session import SessionHydrator, HydrationResult

        hydrator = SessionHydrator()
        result = hydrator.hydrate(jsonl_path)

        # Store session reference
        self._session_store = result.store

        # Extract session_id from hydration result
        session_id = result.report.session_id

        # Inject MessageStore into MemoryManager as single source of truth
        # This replaces the old dual-path approach (_resumed_base_context + _sync_to_working_memory)
        # Now MemoryManager.get_context_for_llm() uses MessageStore directly
        self.memory.set_message_store(result.store, session_id)

        # Todos are NOT restored from JSONL. The JSON file (todos.json) is the
        # single source of truth for task state. It gets loaded automatically
        # when set_session_id() -> set_persistence_path() is called by the
        # caller (e.g. app._load_session).

        from src.observability import get_logger
        logger = get_logger(__name__)
        logger.info(f"Session resumed: {result.report.context_messages} context messages, "
                   f"using MessageStore")

        return result

    def get_statistics(self) -> Dict[str, Any]:
        """Get agent statistics."""
        stats = {
            "model": self.model_name,
            "context_window": self.context_window,
            "indexed_chunks": len(self.indexed_chunks),
            "memory": self.memory.get_statistics(),
        }

        return stats

    def clear_memory(self) -> None:
        """Clear all memory."""
        self.memory.clear_all()

    def set_permission_mode(self, mode: str) -> None:
        """Set permission mode.

        Args:
            mode: Permission mode string (plan/normal/auto)

        Raises:
            ValueError: If mode is invalid
        """
        current_mode = self.permission_manager.get_mode()
        permission_mode = PermissionManager.from_string(mode)
        self.permission_manager.set_mode(permission_mode)

        # Handle plan mode state transitions
        if permission_mode == PermissionMode.PLAN and current_mode != PermissionMode.PLAN:
            # Entering plan mode - activate plan mode state
            session_id = self._session_id or "default-session"
            if not self.plan_mode_state.is_active:
                self.plan_mode_state.enter(session_id)
        elif permission_mode != PermissionMode.PLAN and current_mode == PermissionMode.PLAN:
            # Leaving plan mode - reject if awaiting approval, then reset
            if self.plan_mode_state.is_awaiting_approval():
                self.plan_mode_state.reject()
            if self.plan_mode_state.is_active:
                self.plan_mode_state.reset()

        # Persist mode change event to store for UI rendering
        old_mode_str = current_mode.value
        new_mode_str = permission_mode.value
        if old_mode_str != new_mode_str:
            self.memory.persist_system_event(
                event_type="permission_mode_changed",
                content=f"Mode: {old_mode_str} -> {new_mode_str}",
                extra={"old_mode": old_mode_str, "new_mode": new_mode_str},
                include_in_llm_context=False,
            )

    def get_permission_mode(self) -> str:
        """Get current permission mode.

        Returns:
            Permission mode string (plan/normal/auto)
        """
        return self.permission_manager.get_mode().value

    def get_permission_mode_description(self) -> str:
        """Get description of current permission mode.

        Returns:
            Human-readable description of current mode
        """
        return self.permission_manager.format_mode_description()

    # -------------------------------------------------------------------------
    # Context Pressure Helpers
    # -------------------------------------------------------------------------

    def _get_pressure_level(self, used_tokens: int) -> str:
        """
        Get pressure level based on context utilization.

        Args:
            used_tokens: Number of tokens currently used

        Returns:
            Pressure level string: 'green', 'yellow', 'orange', or 'red'
        """
        if self.context_builder.max_context_tokens <= 0:
            logger.warning(
                f"Invalid max_context_tokens: {self.context_builder.max_context_tokens}"
            )
            return "green"

        utilization = used_tokens / self.context_builder.max_context_tokens

        if utilization >= 0.95:
            return "red"
        elif utilization >= 0.85:
            return "orange"
        elif utilization >= 0.70:
            return "yellow"
        else:
            return "green"

    # -------------------------------------------------------------------------
    # Error Recovery Helpers
    # -------------------------------------------------------------------------

    def _format_oversized_output_error(
        self,
        output_size: int,
        tool_name: str,
        tool_args: Dict[str, Any],
        tool_call_id: str
    ) -> tuple:
        """
        Format error response for oversized tool output.

        This is the unified helper for handling outputs that exceed
        _max_tool_output_chars, providing consistent error messages
        and data structures across sync/async/streaming code paths.

        Args:
            output_size: Size of the output in characters
            tool_name: Name of the tool that generated the output
            tool_args: Arguments passed to the tool
            tool_call_id: ID of the tool call

        Returns:
            Tuple of (error_msg, tool_message_dict, history_entry_dict)
        """
        error_msg = (
            f"Error: Output too large ({output_size:,} characters, "
            f"limit is {self._max_tool_output_chars:,}). "
            f"For read_file: use offset and limit parameters to read specific portions of the file. "
            f"For grep/search: use head_limit parameter to limit results. "
            f"For command output: consider piping through head/tail."
        )

        tool_message = {
            "role": "tool",
            "tool_call_id": tool_call_id,
            "name": tool_name,
            "content": error_msg
        }

        history_entry = {
            "tool": tool_name,
            "arguments": tool_args,
            "success": False,
            "error": error_msg
        }

        return error_msg, tool_message, history_entry

    def _classify_tool_error(self, error_message: str) -> str:
        """
        Classify tool error into error type for recovery tracking.

        Args:
            error_message: The error message from tool execution

        Returns:
            Error type string (file_not_found, permission, command_failed, etc.)
        """
        error_lower = error_message.lower()

        # File/path errors
        if "not found" in error_lower or "no such file" in error_lower:
            return "file_not_found"
        if "directory" in error_lower and ("not found" in error_lower or "does not exist" in error_lower):
            return "directory_not_found"

        # Permission errors
        if "permission" in error_lower or "access denied" in error_lower or "forbidden" in error_lower:
            return "permission_denied"

        # Command execution errors
        if "command not found" in error_lower or "not recognized" in error_lower:
            return "command_not_found"
        if "exit code" in error_lower or "returned" in error_lower and "error" in error_lower:
            return "command_failed"
        if "timeout" in error_lower:
            return "timeout"

        # Edit/patch errors
        if "old_string not found" in error_lower or "no match" in error_lower:
            return "edit_no_match"
        if "conflict" in error_lower or "merge" in error_lower:
            return "edit_conflict"

        # Git errors
        if "git" in error_lower:
            if "uncommitted" in error_lower or "working tree" in error_lower:
                return "git_dirty"
            if "conflict" in error_lower:
                return "git_conflict"
            return "git_error"

        # Network errors
        if "connection" in error_lower or "network" in error_lower:
            return "network_error"

        # Generic tool error
        return "tool_execution_error"

    def _build_pause_message(self, reason: str) -> str:
        """
        Build pause message and set agent state for resumption.

        Args:
            reason: Stop reason code

        Returns:
            Formatted pause message string for user display
        """
        self.task_state.last_stop_reason = reason

        # Preserve current_task_id if we have an in_progress task
        in_progress = next(
            (t for t in self.task_state.list_all()
             if t.get('status') == 'in_progress'),
            None
        )
        if in_progress:
            self.task_state.current_task_id = in_progress.get('id')

        # Build user-visible message
        pending = self.task_state.get_pending_summary()

        reason_text = {
            'max_iterations': 'iteration limit',
            'max_tool_calls': 'tool call limit',
            'max_wall_time': 'time limit',
            'user_interrupt': 'user interrupt',
            'error_budget': 'error limit',
            'provider_error': 'provider error - retry available',
        }.get(reason, reason)

        if pending:
            pending_str = ", ".join(pending[:3])
            message = f"\n\n---\n**Paused** ({reason_text}). Pending: {pending_str}\nSend `?` to continue.\n"
        else:
            message = f"\n\n---\n**Paused** ({reason_text}). Send `?` to continue.\n"

        return message

    def shutdown(self) -> None:
        """
        Shutdown agent and cleanup resources.

        Emits SessionEnd hook if hook_manager is configured.
        """
        # Log prompt cache summary for the session
        if hasattr(self, 'llm') and hasattr(self.llm, 'log_cache_summary'):
            self.llm.log_cache_summary()

        # SESSION END HOOK
        if self.hook_manager:
            try:
                # Gather session stats
                stats = self.get_statistics()

                self.hook_manager.emit_session_end(
                    duration=0.0,  # Would need to track session start time
                    statistics=stats,
                    exit_reason="normal"
                )

            except Exception as e:
                logger.warning(f"SessionEnd hook error: {e}", exc_info=True)
