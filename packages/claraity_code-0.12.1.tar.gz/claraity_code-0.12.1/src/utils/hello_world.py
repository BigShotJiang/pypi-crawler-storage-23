def hello_world():
    """Return a simple hello world message."""
    return "Hello, World!"

if __name__ == "__main__":
    print(hello_world())
