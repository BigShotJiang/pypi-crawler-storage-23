"""External service integrations (MCP, Jira, etc.)."""
