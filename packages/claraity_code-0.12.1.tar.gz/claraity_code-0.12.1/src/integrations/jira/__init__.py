"""Atlassian Jira integration via MCP.

Thin module: owns tool allowlist, read/write classification,
Jira-specific defaults, and connection state. Auth follows
Atlassian Rovo MCP's supported flow - no custom OAuth here.
"""
