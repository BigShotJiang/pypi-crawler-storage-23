"""
UI Event Types - Re-exported from src.core.events.

All event types are defined in src/core/events.py (the canonical home).
This module re-exports them for backward compatibility so existing
UI code can continue to use `from src.ui.events import ...`.
"""

# Re-export everything from core.events
from src.core.events import (  # noqa: F401
    ToolStatus,
    StreamStart, StreamEnd,
    TextDelta,
    CodeBlockStart, CodeBlockDelta, CodeBlockEnd,
    ToolCallStart, ToolCallStatus, ToolCallResult,
    ThinkingStart, ThinkingDelta, ThinkingEnd,
    PausePromptStart, PausePromptEnd,
    ContextUpdated, ContextCompacting, ContextCompacted,
    FileReadEvent,
    ErrorEvent,
    UIEvent,
)

__all__ = [
    'ToolStatus',
    'StreamStart', 'StreamEnd',
    'TextDelta',
    'CodeBlockStart', 'CodeBlockDelta', 'CodeBlockEnd',
    'ToolCallStart', 'ToolCallStatus', 'ToolCallResult',
    'ThinkingStart', 'ThinkingDelta', 'ThinkingEnd',
    'PausePromptStart', 'PausePromptEnd',
    'ContextUpdated', 'ContextCompacting', 'ContextCompacted',
    'FileReadEvent',
    'ErrorEvent',
    'UIEvent',
]
