# Hello World Function

def hello_world():
    """Return a simple hello world message."""
    return "Hello, World!"
