"""Synthkit: Convert AI-generated Markdown into production-ready documents."""

__version__ = "0.1.0"
