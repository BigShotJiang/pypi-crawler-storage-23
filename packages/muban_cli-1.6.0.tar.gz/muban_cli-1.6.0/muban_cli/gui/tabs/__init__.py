"""GUI tabs module."""
