"""GUI dialogs module."""
