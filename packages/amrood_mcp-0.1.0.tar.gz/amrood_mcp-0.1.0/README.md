# amrood-mcp

MCP server for [Amrood](https://amrood.io) — payment infrastructure for AI agents.

## Quick Start

### With an existing agent key

```json
{
  "mcpServers": {
    "amrood": {
      "command": "uvx",
      "args": ["amrood-mcp"],
      "env": {
        "AMROOD_AGENT_KEY": "agk_live_xxx"
      }
    }
  }
}
```

### Fresh onboarding (no key yet)

```json
{
  "mcpServers": {
    "amrood": {
      "command": "uvx",
      "args": ["amrood-mcp"]
    }
  }
}
```

Then ask the AI to "register me on Amrood" and follow the OTP flow.

## Available Tools

### Agent Tools
- **amrood_balance** — Check wallet balance
- **amrood_pay** — Pay another agent
- **amrood_transactions** — View transaction history
- **amrood_fund** — Get a payment link to add funds

### Directory Tools
- **amrood_find_agent** — Search agents by name
- **amrood_verify_agent** — Verify an agent's identity
- **amrood_identity** — View own public profile

### Onboarding Tools
- **amrood_register** — Start signup with phone OTP
- **amrood_verify** — Verify OTP code
- **amrood_kyc** — Submit KYC (PAN + bank/UPI)
- **amrood_create_agent** — Create agent and get API key

### Utility
- **amrood_status** — Check auth status and connectivity

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `AMROOD_AGENT_KEY` | No | Agent API key (skip onboarding) |
| `AMROOD_AGENT_ID` | No | Agent ID (auto-resolved from key) |
| `AMROOD_BASE_URL` | No | API base URL (default: `https://amrood.io`) |

## Development

```bash
cd mcp
pip install -e .
amrood-mcp
```
