"""Amrood MCP Server — payment infrastructure for AI agents."""

__version__ = "0.1.0"
