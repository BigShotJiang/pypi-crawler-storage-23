"""
Initialize the scripts
"""
