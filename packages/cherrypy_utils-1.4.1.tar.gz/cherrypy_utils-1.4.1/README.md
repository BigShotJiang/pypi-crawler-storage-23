# Overview

This is a generic utility library full of helper functions relating to cherrypy webservice routines.
Included are handlers for:

- authentication: `from cherrypy_utils import authentication`
- sqlalchemy with cherrypy (cherrypy_sqlalchemy_utils.py & database.py)
- json parsing and constructing orm entities from json (json_utils.py)
- timestamp (ISO and posix epoch) parsing (timestamp.py)
- url construction and parsing from parts (similar to os.path.join) (url_utils.py)
- ldap login utilities (login/ldap_auth.py & login/models.py)

## Usage

To use this package in your project, simply install it with `pip install cherrypy_utils`
