# ASA Engine CLI

Structural risk scanner for AI-generated codebases.

## Installation

```bash
pip install asa-engine
```

## Usage

```bash
# Scan your project
asa scan

# JSON output (for CI/automation)
asa scan --json

# Skip web report URL
asa scan --no-url
```

## What it measures

The scanner calculates the **AI Chaos Index (ACI)** — a 0–100 score based on five root causes of structural failure:

| Code | Root Cause | What it detects |
|------|-----------|-----------------|
| RC01 | Architecture Drift | Oversized files, deep nesting |
| RC02 | Dependency Corruption | Circular imports, god files |
| RC03 | Structural Entropy | Naming inconsistency |
| RC04 | Test Infrastructure | Test-to-source ratio |
| RC05 | Deployment Safety | CI/CD pipeline presence |

## Risk bands

| ACI Score | Band | Interpretation |
|-----------|------|---------------|
| 0–30 | Stable | Architecture handles AI-assisted development well |
| 31–55 | Fragile | Hidden coupling, targeted fixes prevent escalation |
| 56–75 | Unstable | Active structural decay, velocity declining |
| 76–100 | Critical | Codebase resists change, rewrite risk rising |

## Links

- [CLI Documentation](https://vibecodiq.com/scan/cli)
- [Web Assessment](https://vibecodiq.com/scan)
- [AI Chaos Knowledge Base](https://vibecodiq.com/ai-chaos)

## Requirements

- Python 3.10+
- Works on macOS, Linux, and Windows

## License

Proprietary. © Vibecodiq.
