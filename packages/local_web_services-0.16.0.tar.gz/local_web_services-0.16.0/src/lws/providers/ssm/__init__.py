"""SSM Parameter Store provider package."""
