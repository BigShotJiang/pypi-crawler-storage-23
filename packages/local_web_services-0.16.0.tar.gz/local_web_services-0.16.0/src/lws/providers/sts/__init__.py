"""STS provider package."""
