"""Filesystem-backed S3 provider."""
