"""CEL field mappings for stream filter expressions."""

import re
from typing import Dict, List

# CEL field mappings organized by subscription method
CEL_FIELD_MAPPINGS: Dict[str, Dict[str, str]] = {
    # Wallet balance subscription fields
    "subscribe_wallet_balance": {
        "wallet_address": "a",
        "token_address": "ta",
        "token_price_in_usd": "tpiu",
        "balance": "b",
        "timestamp": "t",
    },
    # Token candle subscription fields
    "subscribe_token_candles": {
        "open": "o",
        "close": "c",
        "high": "h",
        "low": "l",
        "volume": "v",
        "resolution": "r",
        "time": "t",
        "number": "n",
    },
    # Token stats subscription fields
    "subscribe_token_stats": {
        "address": "a",
        "timestamp": "t",
        "buys_1m": "b1m",
        "sells_1m": "s1m",
        "buyers_1m": "be1m",
        "sellers_1m": "se1m",
        "buy_volume_in_usd_1m": "bviu1m",
        "sell_volume_in_usd_1m": "sviu1m",
        "price_1m": "p1m",
        "open_in_usd_1m": "oiu1m",
        "close_in_usd_1m": "ciu1m",
        "buys_5m": "b5m",
        "sells_5m": "s5m",
        "buyers_5m": "be5m",
        "sellers_5m": "se5m",
        "buy_volume_in_usd_5m": "bviu5m",
        "sell_volume_in_usd_5m": "sviu5m",
        "price_5m": "p5m",
        "open_in_usd_5m": "oiu5m",
        "close_in_usd_5m": "ciu5m",
        "buys_15m": "b15m",
        "sells_15m": "s15m",
        "buyers_15m": "be15m",
        "sellers_15m": "se15m",
        "buy_volume_in_usd_15m": "bviu15m",
        "sell_volume_in_usd_15m": "sviu15m",
        "price_15m": "p15m",
        "open_in_usd_15m": "oiu15m",
        "close_in_usd_15m": "ciu15m",
        "buys_30m": "b30m",
        "sells_30m": "s30m",
        "buyers_30m": "be30m",
        "sellers_30m": "se30m",
        "buy_volume_in_usd_30m": "bviu30m",
        "sell_volume_in_usd_30m": "sviu30m",
        "price_30m": "p30m",
        "open_in_usd_30m": "oiu30m",
        "close_in_usd_30m": "ciu30m",
        "buys_1h": "b1h",
        "sells_1h": "s1h",
        "buyers_1h": "be1h",
        "sellers_1h": "se1h",
        "buy_volume_in_usd_1h": "bviu1h",
        "sell_volume_in_usd_1h": "sviu1h",
        "price_1h": "p1h",
        "open_in_usd_1h": "oiu1h",
        "close_in_usd_1h": "ciu1h",
        "buys_4h": "b4h",
        "sells_4h": "s4h",
        "buyers_4h": "be4h",
        "sellers_4h": "se4h",
        "buy_volume_in_usd_4h": "bviu4h",
        "sell_volume_in_usd_4h": "sviu4h",
        "price_4h": "p4h",
        "open_in_usd_4h": "oiu4h",
        "close_in_usd_4h": "ciu4h",
        "buys_24h": "b24h",
        "sells_24h": "s24h",
        "buyers_24h": "be24h",
        "sellers_24h": "se24h",
        "buy_volume_in_usd_24h": "bviu24h",
        "sell_volume_in_usd_24h": "sviu24h",
        "price_24h": "p24h",
        "price": "p",
        "open_in_usd_24h": "oiu24h",
        "close_in_usd_24h": "ciu24h",
    },
    # Token holder subscription fields
    "subscribe_token_holders": {
        "token_address": "a",
        "holders": "h",
        "top100_amount": "t100a",
        "top10_amount": "t10a",
        "top100_holders": "t100h",
        "top10_holders": "t10h",
        "top100_ratio": "t100r",
        "top10_ratio": "t10r",
        "timestamp": "ts",
    },
    # New token subscription fields (dex-new-token, supports CEL filter)
    "subscribe_new_token": {
        "token_address": "a",
        "name": "n",
        "symbol": "s",
        "decimals": "dec",
        "image_url": "iu",
        "description": "de",
        "created_at_ms": "cts",
        "coingecko_coin_id": "cgi",
        "social_media.twitter": "sm.tw",
        "social_media.telegram": "sm.tg",
        "social_media.website": "sm.w",
        "social_media.tiktok": "sm.tt",
        "social_media.discord": "sm.dc",
        "social_media.facebook": "sm.fb",
        "social_media.github": "sm.gh",
        "social_media.instagram": "sm.ig",
        "social_media.linkedin": "sm.li",
        "social_media.medium": "sm.md",
        "social_media.reddit": "sm.rd",
        "social_media.youtube": "sm.yt",
        "social_media.bitbucket": "sm.bb",
        "launch_from.program_address": "lf.pa",
        "launch_from.protocol_family": "lf.pf",
        "launch_from.protocol_name": "lf.pn",
        "migrated_to.program_address": "mt.pa",
        "migrated_to.protocol_family": "mt.pf",
        "migrated_to.protocol_name": "mt.pn",
    },
    # Token supply subscription fields
    "subscribe_token_supply": {
        "token_address": "a",
        "supply": "s",
        "timestamp": "ts",
    },
    # DEX pool balance subscription fields
    "subscribe_dex_pool_balance": {
        "pool_address": "a",
        "token_a_address": "taa",
        "token_a_liquidity_in_usd": "taliu",
        "token_b_address": "tba",
        "token_b_liquidity_in_usd": "tbliu",
    },
    # Token liquidity subscription fields
    "subscribe_token_liquidity": {
        "token_address": "a",
        "metric_type": "t",
        "value": "v",
        "timestamp": "ts",
    },
    # New token metadata subscription fields (dex-new-tokens-metadata)
    "subscribe_new_tokens_metadata": {
        "token_address": "a",
        "name": "n",
        "decimals": "dec",
        "symbol": "s",
        "image_url": "iu",
        "description": "de",
        "created_at_ms": "cts",
        "coingecko_coin_id": "cgi",
        "social_media.twitter": "sm.tw",
        "social_media.telegram": "sm.tg",
        "social_media.website": "sm.w",
        "social_media.tiktok": "sm.tt",
        "social_media.discord": "sm.dc",
        "social_media.facebook": "sm.fb",
        "social_media.github": "sm.gh",
        "social_media.instagram": "sm.ig",
        "social_media.linkedin": "sm.li",
        "social_media.medium": "sm.md",
        "social_media.reddit": "sm.rd",
        "social_media.youtube": "sm.yt",
        "social_media.bitbucket": "sm.bb",
        "launch_from.program_address": "lf.pa",
        "launch_from.protocol_family": "lf.pf",
        "launch_from.protocol_name": "lf.pn",
        "migrated_to.program_address": "mt.pa",
        "migrated_to.protocol_family": "mt.pf",
        "migrated_to.protocol_name": "mt.pn",
    },
    # New tokens list subscription fields (dex-new-tokens)
    "subscribe_new_tokens": {
        "token_address": "a",
        "name": "n",
        "decimals": "dec",
        "symbol": "s",
        "image_url": "iu",
        "description": "de",
        "created_at_ms": "cts",
        "coingecko_coin_id": "cgi",
        "social_media.twitter": "sm.tw",
        "social_media.telegram": "sm.tg",
        "social_media.website": "sm.w",
        "social_media.tiktok": "sm.tt",
        "social_media.discord": "sm.dc",
        "social_media.facebook": "sm.fb",
        "social_media.github": "sm.gh",
        "social_media.instagram": "sm.ig",
        "social_media.linkedin": "sm.li",
        "social_media.medium": "sm.md",
        "social_media.reddit": "sm.rd",
        "social_media.youtube": "sm.yt",
        "social_media.bitbucket": "sm.bb",
        "launch_from.program_address": "lf.pa",
        "launch_from.protocol_family": "lf.pf",
        "launch_from.protocol_name": "lf.pn",
        "migrated_to.program_address": "mt.pa",
        "migrated_to.protocol_family": "mt.pf",
        "migrated_to.protocol_name": "mt.pn",
    },
    # Token trade subscription fields
    "subscribe_token_trades": {
        "token_address": "a",
        "timestamp": "t",
        "kind": "k",
        "buy_amount": "ba",
        "buy_amount_in_usd": "baiu",
        "buy_token_address": "btma",
        "buy_token_name": "btn",
        "buy_token_symbol": "bts",
        "buy_wallet_address": "bwa",
        "sell_amount": "sa",
        "sell_amount_in_usd": "saiu",
        "sell_token_address": "stma",
        "sell_token_name": "stn",
        "sell_token_symbol": "sts",
        "sell_wallet_address": "swa",
        "tx_hash": "h",
    },
    # Wallet token PnL subscription fields
    "subscribe_wallet_pnl": {
        "wallet_address": "a",
        "token_address": "ta",
        "token_price_in_usd": "tpiu",
        "timestamp": "t",
        "open_time": "ot",
        "last_time": "lt",
        "close_time": "ct",
        "buy_amount": "ba",
        "buy_amount_in_usd": "baiu",
        "buy_count": "bs",
        "buy_count_30d": "bs30d",
        "buy_count_7d": "bs7d",
        "sell_amount": "sa",
        "sell_amount_in_usd": "saiu",
        "sell_count": "ss",
        "sell_count_30d": "ss30d",
        "sell_count_7d": "ss7d",
        "held_duration_timestamp": "hdts",
        "average_buy_price_in_usd": "abpiu",
        "average_sell_price_in_usd": "aspiu",
        "unrealized_profit_in_usd": "upiu",
        "unrealized_profit_ratio": "upr",
        "realized_profit_in_usd": "rpiu",
        "realized_profit_ratio": "rpr",
        "total_realized_profit_in_usd": "trpiu",
        "total_realized_profit_ratio": "trr",
    },
    # Wallet trade subscription fields
    "subscribe_wallet_trade": {
        "token_address": "a",
        "timestamp": "t",
        "kind": "k",
        "buy_amount": "ba",
        "buy_amount_in_usd": "baiu",
        "buy_token_address": "btma",
        "buy_token_name": "btn",
        "buy_token_symbol": "bts",
        "buy_wallet_address": "bwa",
        "sell_amount": "sa",
        "sell_amount_in_usd": "saiu",
        "sell_token_address": "stma",
        "sell_token_name": "stn",
        "sell_token_symbol": "sts",
        "sell_wallet_address": "swa",
        "tx_hash": "h",
    },
    # Token max liquidity subscription fields
    "subscribe_token_max_liquidity": {
        "token_address": "a",
        "pool_address": "p",
        "liquidity_in_usd": "liu",
        "liquidity_in_native": "lin",
        "timestamp": "ts",
    },
    # Token total liquidity subscription fields
    "subscribe_token_total_liquidity": {
        "token_address": "a",
        "liquidity_in_usd": "liu",
        "liquidity_in_native": "lin",
        "pool_count": "pc",
        "timestamp": "ts",
    },
}


def get_field_mappings(method_name: str) -> Dict[str, str]:
    """Get field mappings for a specific subscription method.

    Args:
        method_name: The subscription method name.

    Returns:
        A dictionary mapping long field names to short field names.
    """
    return CEL_FIELD_MAPPINGS.get(method_name, {})


def replace_filter_fields(filter_expr: str, method_name: str) -> str:
    """Replace long field names with short field names in filter expressions.

    Automatically adds meta. prefix if not present.

    Args:
        filter_expr: The filter expression to process.
        method_name: The subscription method name.

    Returns:
        The processed filter expression with short field names.
    """
    if not filter_expr:
        return filter_expr

    field_mappings = get_field_mappings(method_name)
    result = filter_expr

    # Sort entries by key length descending to replace longer (nested) paths first
    # This prevents partial replacements (e.g., "launch_from" matching before "launch_from.protocol_family")
    sorted_entries = sorted(field_mappings.items(), key=lambda x: len(x[0]), reverse=True)

    for long_field, short_field in sorted_entries:
        escaped_field = re.escape(long_field)
        # Pattern 1: meta.fieldName (with meta. prefix) — check first to avoid double meta.
        pattern1 = rf"\bmeta\.{escaped_field}\b"
        # Pattern 2: fieldName (without meta. prefix)
        pattern2 = rf"\b{escaped_field}\b"

        result = re.sub(pattern1, f"meta.{short_field}", result)
        result = re.sub(pattern2, f"meta.{short_field}", result)

    return result


def get_available_fields(method_name: str) -> List[str]:
    """Get available field names for a specific subscription method.

    Args:
        method_name: The subscription method name.

    Returns:
        A list of available field names.
    """
    return list(get_field_mappings(method_name).keys())
