"""ChainStream SDK Client."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional, Protocol

from chainstream.stream.client import StreamApi

# Default URLs
CHAINSTREAM_BASE_URL = "https://api.chainstream.io"
CHAINSTREAM_STREAM_URL = "wss://realtime-dex.chainstream.io/connection/websocket"


class TokenProvider(Protocol):
    """Protocol for providing access tokens."""

    def get_token(self) -> str:
        """Get the current access token."""
        ...


@dataclass
class StaticTokenProvider:
    """A simple token provider that returns a static token."""

    token: str

    def get_token(self) -> str:
        """Get the static token."""
        return self.token


@dataclass
class ChainStreamClientOptions:
    """Options for ChainStreamClient configuration."""

    base_url: str = CHAINSTREAM_BASE_URL
    stream_url: str = CHAINSTREAM_STREAM_URL


class ChainStreamClient:
    """ChainStream SDK Client for accessing both REST API and WebSocket streams.

    Example:
        ```python
        import asyncio
        from chainstream import ChainStreamClient
        from chainstream.stream import Resolution, TokenCandle

        async def main():
            client = ChainStreamClient("your-access-token")

            # Subscribe to token candles
            unsub = await client.stream.subscribe_token_candles(
                chain="sol",
                token_address="So11111111111111111111111111111111111111112",
                resolution=Resolution.S1,
                callback=lambda candle: print(f"Candle: {candle}"),
            )

            # Wait for some data
            await asyncio.sleep(30)

            # Unsubscribe and close
            unsub.unsubscribe()
            await client.close()

        asyncio.run(main())
        ```
    """

    def __init__(
        self,
        access_token: str,
        options: Optional[ChainStreamClientOptions] = None,
        token_provider: Optional[TokenProvider] = None,
    ) -> None:
        """Initialize the ChainStreamClient.

        Args:
            access_token: The access token for authentication.
            options: Optional configuration options.
            token_provider: Optional custom token provider.
        """
        self._options = options or ChainStreamClientOptions()
        self._token_provider = token_provider or StaticTokenProvider(access_token)
        self._access_token = access_token

        # Initialize stream API
        self._stream = StreamApi(self._options.stream_url, access_token)

    @property
    def stream(self) -> StreamApi:
        """Get the stream API client."""
        return self._stream

    def get_access_token(self) -> str:
        """Get the current access token."""
        return self._token_provider.get_token()

    async def close(self) -> None:
        """Close all connections."""
        await self._stream.disconnect()
