package commands

class StopRequest : Request

class StopCmd {

    fun run(): Map<String, Any> {
        return emptyMap()
    }
}
