# =====================================
# generator=datazen
# version=3.2.4
# hash=bb36bc33fac9a3d6a94a91ad7f6cbf33
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "An interface generator for distributed computing."
PKG_NAME = "ifgen"
VERSION = "4.7.3"
