# =====================================
# generator=datazen
# version=3.2.4
# hash=91b95d05935cfffb260a5bf6ce0786f0
# =====================================
"""
ifgen - Package's default entry-point.
"""

# built-in
import sys

# internal
from ifgen.entry import main

if __name__ == "__main__":
    sys.exit(main(sys.argv))
