"""Tests for sanitization module."""
