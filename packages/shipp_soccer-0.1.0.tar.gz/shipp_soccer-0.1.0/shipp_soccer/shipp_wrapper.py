"""
Thin wrapper around the Shipp.ai API for live soccer match events.

Provides live match scores and play-by-play events (goals, cards,
substitutions) via Shipp connections with cursor-based polling.
"""

import os
import time
import logging
from datetime import datetime, timezone
from typing import Optional

import requests

logger = logging.getLogger(__name__)

SHIPP_BASE_URL = "https://api.shipp.ai/api/v1"
DEFAULT_TIMEOUT = 15
MAX_RETRIES = 2
RETRY_BACKOFF = 2.0


class ShippSoccerClient:
    """Client for Shipp.ai soccer/football live data."""

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("SHIPP_API_KEY")
        if not self.api_key:
            raise ValueError(
                "SHIPP_API_KEY is required. Set it as an environment variable "
                "or pass it to ShippSoccerClient(api_key='...'). "
                "Get a key at https://platform.shipp.ai"
            )
        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "User-Agent": "soccer-match-tracker/1.0",
        })
        self._connection_id = None
        self._last_event_id = None

    def _url(self, endpoint: str) -> str:
        """Build URL with api_key query parameter."""
        sep = "&" if "?" in endpoint else "?"
        return f"{SHIPP_BASE_URL}{endpoint}{sep}api_key={self.api_key}"

    def _request(self, method: str, endpoint: str, **kwargs) -> dict:
        """Make an API request with retry and rate-limit handling."""
        url = self._url(endpoint)
        kwargs.setdefault("timeout", DEFAULT_TIMEOUT)

        last_error = None
        for attempt in range(MAX_RETRIES + 1):
            try:
                response = self.session.request(method, url, **kwargs)

                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", 5))
                    logger.warning("Rate limited, waiting %d seconds", retry_after)
                    time.sleep(retry_after)
                    continue

                response.raise_for_status()
                return response.json()

            except requests.exceptions.Timeout:
                last_error = f"Timeout after {DEFAULT_TIMEOUT}s"
                logger.warning("Attempt %d: %s", attempt + 1, last_error)
            except requests.exceptions.ConnectionError as e:
                last_error = f"Connection error: {e}"
                logger.warning("Attempt %d: %s", attempt + 1, last_error)
            except requests.exceptions.HTTPError as e:
                if e.response is not None and e.response.status_code < 500:
                    raise
                last_error = f"HTTP error: {e}"
                logger.warning("Attempt %d: %s", attempt + 1, last_error)

            if attempt < MAX_RETRIES:
                time.sleep(RETRY_BACKOFF * (attempt + 1))

        raise RuntimeError(
            f"Shipp API failed after {MAX_RETRIES + 1} attempts: {last_error}"
        )

    def _ensure_connection(self):
        """Create a soccer connection if one doesn't exist."""
        if self._connection_id is None:
            result = self._request("POST", "/connections/create", json={
                "filter_instructions": "Track all soccer matches today across major leagues including goals, cards, and substitutions",
            })
            self._connection_id = result.get("connection_id")
            self._last_event_id = None
            if not self._connection_id:
                raise RuntimeError("Failed to create soccer connection: no connection_id returned")
            logger.info("Created soccer connection: %s", self._connection_id)

    def get_live_matches(self) -> list:
        """
        Get all currently live soccer matches with scores.

        Returns:
            List of live match dicts with: match_id, home_team, away_team,
            home_score, away_score, minute, status, competition.
        """
        try:
            self._ensure_connection()
            payload = {}
            if self._last_event_id:
                payload["since_event_id"] = self._last_event_id

            result = self._request(
                "POST",
                f"/connections/{self._connection_id}",
                json=payload,
            )

            events = result.get("data", result.get("events", []))

            # Update cursor
            if events:
                last = events[-1]
                cursor = last.get("id") or last.get("event_id")
                if cursor:
                    self._last_event_id = str(cursor)

            return events

        except Exception as e:
            logger.error("Failed to get live matches: %s", e)
            # Reset connection on failure
            self._connection_id = None
            self._last_event_id = None
            return []

    def get_match_events(self, match_id: str) -> list:
        """
        Get play-by-play events for a specific match.

        Args:
            match_id: The match identifier.

        Returns:
            List of event dicts: minute, type (goal, card, sub), player, team.
        """
        try:
            self._ensure_connection()
            result = self._request(
                "POST",
                f"/connections/{self._connection_id}",
                json={"match_id": match_id},
            )
            return result.get("data", result.get("events", []))
        except Exception as e:
            logger.error("Failed to get events for match %s: %s", match_id, e)
            return []

    def get_schedule(self, date: Optional[str] = None) -> list:
        """
        Get today's soccer schedule.

        Args:
            date: YYYY-MM-DD format. Defaults to today.

        Returns:
            List of scheduled match dicts.
        """
        if date is None:
            date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        try:
            result = self._request(
                "GET",
                "/sports/soccer/schedule",
                params={"date": date},
            )
            return result.get("schedule", result.get("games", result.get("data", [])))
        except Exception as e:
            logger.error("Failed to get soccer schedule: %s", e)
            return []

    def close_connection(self):
        """Clean up the connection."""
        self._connection_id = None
        self._last_event_id = None
