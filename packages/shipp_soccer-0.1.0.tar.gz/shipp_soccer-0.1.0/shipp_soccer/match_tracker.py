"""
Soccer Match Tracker -- Main orchestrator.

Provides live scores, standings, fixtures, and match events across
Premier League, La Liga, Champions League, and MLS.
"""

import json
import logging
from datetime import datetime, timezone
from typing import Optional

from .football_data import FootballDataClient
from .shipp_wrapper import ShippSoccerClient

logger = logging.getLogger(__name__)

# League display names
LEAGUE_NAMES = {
    "PL": "Premier League",
    "PD": "La Liga",
    "CL": "Champions League",
    "MLS": "MLS",
}

ALL_LEAGUES = ["PL", "PD", "CL", "MLS"]


class LiveScoresDisplay:
    """Formatted display of live soccer scores."""

    def __init__(self, data: dict):
        self.data = data

    def display(self) -> str:
        """Render live scores grouped by league."""
        lines = []
        lines.append("=== LIVE FOOTBALL SCORES ===")
        lines.append("")

        leagues = self.data.get("leagues", {})
        if not leagues:
            lines.append("No live matches at this time.")
            return "\n".join(lines)

        for league_code, matches in leagues.items():
            league_name = LEAGUE_NAMES.get(league_code, league_code)
            lines.append(f"--- {league_name} ---")

            for match in matches:
                home = match.get("home_team", "Home")
                away = match.get("away_team", "Away")
                home_score = match.get("home_score", "?")
                away_score = match.get("away_score", "?")
                status = match.get("status", "")
                minute = match.get("minute", "")

                # Format status display
                if status in ("FINISHED", "FT"):
                    status_str = "FT"
                elif status in ("HALFTIME", "HT"):
                    status_str = "HT"
                elif minute:
                    status_str = f"{minute}'"
                elif status in ("SCHEDULED", "TIMED"):
                    time_str = match.get("start_time", "TBD")
                    lines.append(f"  {home} vs {away}   {time_str}")
                    continue
                else:
                    status_str = status

                lines.append(f"  {home} {home_score} - {away_score} {away}   {status_str}")

                # Show recent events
                events = match.get("events", [])
                for event in events[-5:]:  # Last 5 events
                    evt_minute = event.get("minute", "?")
                    evt_type = event.get("type", "").upper()
                    player = event.get("player", "Unknown")
                    team = event.get("team", "")

                    # Format event type
                    if evt_type in ("GOAL", "NORMAL_GOAL"):
                        evt_label = "GOAL"
                    elif evt_type in ("PENALTY_GOAL", "PENALTY"):
                        evt_label = "PENALTY"
                    elif evt_type in ("OWN_GOAL",):
                        evt_label = "OWN GOAL"
                    elif evt_type in ("YELLOW_CARD", "YELLOW"):
                        evt_label = "YELLOW CARD"
                    elif evt_type in ("RED_CARD", "RED"):
                        evt_label = "RED CARD"
                    elif evt_type in ("SECOND_YELLOW", "YELLOW_RED"):
                        evt_label = "SECOND YELLOW"
                    elif evt_type in ("SUBSTITUTION", "SUB"):
                        evt_label = "SUB"
                    else:
                        evt_label = evt_type

                    lines.append(f"    {evt_minute}' {evt_label}  {player} ({team})")

            lines.append("")

        return "\n".join(lines)

    def to_json(self, indent: int = 2) -> str:
        """Return as JSON."""
        return json.dumps(self.data, indent=indent, default=str)


class StandingsDisplay:
    """Formatted league standings table."""

    def __init__(self, data: dict):
        self.data = data

    def table(self) -> str:
        """Render a formatted league table."""
        lines = []
        comp = self.data.get("competition", "League")
        matchday = self.data.get("matchday", "?")
        lines.append(f"=== {comp} Standings (Matchday {matchday}) ===")

        header = (
            f" {'#':<3} {'Team':<26} {'P':>3} {'W':>4} {'D':>4} {'L':>4} "
            f"{'GF':>4} {'GA':>4} {'GD':>5} {'Pts':>4}"
        )
        lines.append(header)
        lines.append(f" {'-' * len(header)}")

        for entry in self.data.get("standings", []):
            pos = entry.get("position", "?")
            team = entry.get("team", "Unknown")[:24]
            played = entry.get("played", 0)
            won = entry.get("won", 0)
            draw = entry.get("draw", 0)
            lost = entry.get("lost", 0)
            gf = entry.get("goals_for", 0)
            ga = entry.get("goals_against", 0)
            gd = entry.get("goal_difference", 0)
            pts = entry.get("points", 0)

            gd_str = f"+{gd}" if gd > 0 else str(gd)

            lines.append(
                f" {pos:<3} {team:<26} {played:>3} {won:>4} {draw:>4} {lost:>4} "
                f"{gf:>4} {ga:>4} {gd_str:>5} {pts:>4}"
            )

        return "\n".join(lines)

    def to_json(self, indent: int = 2) -> str:
        """Return as JSON."""
        return json.dumps(self.data, indent=indent, default=str)


class FixturesDisplay:
    """Formatted upcoming fixtures display."""

    def __init__(self, data: dict):
        self.data = data

    def display(self) -> str:
        """Render upcoming fixtures grouped by date and league."""
        lines = []
        days = self.data.get("days", 7)
        lines.append(f"=== Upcoming Fixtures (Next {days} Days) ===")
        lines.append("")

        matches_by_date = {}
        for league_code, matches in self.data.get("leagues", {}).items():
            for match in matches:
                utc_date = match.get("utc_date", "")
                try:
                    dt = datetime.fromisoformat(utc_date.replace("Z", "+00:00"))
                    date_key = dt.strftime("%A, %B %d")
                    time_str = dt.strftime("%H:%M")
                except (ValueError, AttributeError):
                    date_key = "TBD"
                    time_str = "TBD"

                if date_key not in matches_by_date:
                    matches_by_date[date_key] = {}
                if league_code not in matches_by_date[date_key]:
                    matches_by_date[date_key][league_code] = []

                matches_by_date[date_key][league_code].append({
                    **match,
                    "time": time_str,
                })

        for date_label, leagues in sorted(matches_by_date.items()):
            lines.append(date_label)
            for league_code, matches in leagues.items():
                league_name = LEAGUE_NAMES.get(league_code, league_code)
                lines.append(f"  {league_name}")
                for match in matches:
                    home = match.get("home_team", "Home")
                    away = match.get("away_team", "Away")
                    time_str = match.get("time", "TBD")
                    lines.append(f"    {home} vs {away}      {time_str}")
            lines.append("")

        if not matches_by_date:
            lines.append("No upcoming fixtures found.")

        return "\n".join(lines)

    def to_json(self, indent: int = 2) -> str:
        """Return as JSON."""
        return json.dumps(self.data, indent=indent, default=str)


class MatchTracker:
    """
    Main soccer match tracker orchestrator.

    Combines live data from Shipp connections with reference data from
    football-data.org to provide a comprehensive football tracking experience.
    """

    def __init__(
        self,
        shipp_api_key: Optional[str] = None,
        football_data_api_key: Optional[str] = None,
    ):
        """
        Initialize the match tracker.

        Args:
            shipp_api_key: API key for live match data. Falls back to SHIPP_API_KEY.
            football_data_api_key: football-data.org API key.
                                  Falls back to FOOTBALL_DATA_API_KEY.
        """
        self.shipp = ShippSoccerClient(api_key=shipp_api_key)
        self.football_data = FootballDataClient(api_key=football_data_api_key)

    def live_scores(self, league: Optional[str] = None) -> LiveScoresDisplay:
        """
        Get live scores across leagues.

        Args:
            league: Optional league code to filter (PL, PD, CL, MLS).
                   None returns all leagues.

        Returns:
            LiveScoresDisplay with formatted output.
        """
        # Get live match data from Shipp
        live_events = self.shipp.get_live_matches()

        # Get today's matches from football-data.org for context
        leagues_to_check = [league] if league else ALL_LEAGUES
        fd_matches = {}
        for lc in leagues_to_check:
            try:
                result = self.football_data.get_matches(lc, status="LIVE,IN_PLAY,PAUSED,FINISHED")
                if result.get("matches"):
                    fd_matches[lc] = result["matches"]
            except Exception as e:
                logger.warning("Failed to get %s matches from football-data.org: %s", lc, e)

        # Merge Shipp live events with football-data match info
        leagues = {}
        for league_code, matches in fd_matches.items():
            league_matches = []
            for match in matches:
                match_data = {
                    "match_id": match.get("match_id"),
                    "home_team": match.get("home_team"),
                    "away_team": match.get("away_team"),
                    "home_score": match.get("home_score"),
                    "away_score": match.get("away_score"),
                    "status": match.get("status"),
                    "minute": None,
                    "matchday": match.get("matchday"),
                    "events": [],
                }

                # Try to enrich with live Shipp events
                for event in live_events:
                    event_home = (event.get("home_team") or "").lower()
                    event_away = (event.get("away_team") or "").lower()
                    match_home = (match.get("home_team") or "").lower()
                    match_away = (match.get("away_team") or "").lower()

                    if (event_home and match_home and
                        (event_home in match_home or match_home in event_home)):
                        # Match found -- use Shipp data for more granular info
                        if event.get("home_score") is not None:
                            match_data["home_score"] = event["home_score"]
                        if event.get("away_score") is not None:
                            match_data["away_score"] = event["away_score"]
                        if event.get("minute"):
                            match_data["minute"] = event["minute"]
                        if event.get("events"):
                            match_data["events"] = event["events"]
                        break

                league_matches.append(match_data)

            if league_matches:
                leagues[league_code] = league_matches

        # Also include live Shipp matches not in football-data
        # (edge case: Shipp has matches football-data.org doesn't cover)
        tracked_teams = set()
        for matches in leagues.values():
            for m in matches:
                tracked_teams.add((m.get("home_team") or "").lower())

        for event in live_events:
            home = (event.get("home_team") or "").lower()
            if home and home not in tracked_teams:
                comp = event.get("competition", "OTHER")
                if comp not in leagues:
                    leagues[comp] = []
                leagues[comp].append({
                    "match_id": event.get("match_id"),
                    "home_team": event.get("home_team"),
                    "away_team": event.get("away_team"),
                    "home_score": event.get("home_score"),
                    "away_score": event.get("away_score"),
                    "status": event.get("status"),
                    "minute": event.get("minute"),
                    "events": event.get("events", []),
                })

        return LiveScoresDisplay({
            "leagues": leagues,
            "fetched_at": datetime.now(timezone.utc).isoformat(),
        })

    def standings(self, league: str = "PL") -> StandingsDisplay:
        """
        Get current league standings.

        Args:
            league: League code (PL, PD, CL, MLS). Default: PL.

        Returns:
            StandingsDisplay with formatted table.
        """
        data = self.football_data.get_standings(league)
        return StandingsDisplay(data)

    def upcoming(self, league: Optional[str] = None, days: int = 7) -> FixturesDisplay:
        """
        Get upcoming fixtures across leagues.

        Args:
            league: Optional league code to filter. None returns all.
            days: Number of days ahead. Default: 7.

        Returns:
            FixturesDisplay with formatted output.
        """
        leagues_to_check = [league] if league else ALL_LEAGUES
        all_fixtures = {}

        for lc in leagues_to_check:
            try:
                result = self.football_data.get_upcoming(lc, days=days)
                if result.get("matches"):
                    all_fixtures[lc] = result["matches"]
            except Exception as e:
                logger.warning("Failed to get upcoming fixtures for %s: %s", lc, e)

        return FixturesDisplay({
            "leagues": all_fixtures,
            "days": days,
            "fetched_at": datetime.now(timezone.utc).isoformat(),
        })

    def match_events(self, match_id: str) -> list:
        """
        Get play-by-play events for a specific match.

        Args:
            match_id: Match identifier.

        Returns:
            List of event dicts: minute, type, player, team.
        """
        return self.shipp.get_match_events(match_id)

    def team_squad(self, team_id: int) -> list:
        """
        Get the squad / roster for a team.

        Args:
            team_id: football-data.org team ID.

        Returns:
            List of player dicts.
        """
        result = self.football_data.get_team_squad(team_id)
        return result.get("squad", [])

    def dashboard(self, leagues: Optional[list] = None) -> str:
        """
        Generate a full multi-league football dashboard.

        Includes: live scores, standings for each league, and upcoming fixtures.

        Args:
            leagues: List of league codes. Default: all.

        Returns:
            Formatted dashboard string.
        """
        leagues_list = leagues or ALL_LEAGUES
        sections = []

        # Live scores
        try:
            live = self.live_scores()
            sections.append(live.display())
        except Exception as e:
            sections.append(f"=== LIVE SCORES ===\nError: {e}\n")

        # Standings for each league
        for lc in leagues_list:
            try:
                st = self.standings(league=lc)
                sections.append(st.table())
                sections.append("")
            except Exception as e:
                league_name = LEAGUE_NAMES.get(lc, lc)
                sections.append(f"=== {league_name} Standings ===\nError: {e}\n")

        # Upcoming fixtures
        try:
            upcoming = self.upcoming(days=7)
            sections.append(upcoming.display())
        except Exception as e:
            sections.append(f"=== Upcoming Fixtures ===\nError: {e}\n")

        return "\n".join(sections)


def main():
    """CLI entry point for the soccer match tracker."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Soccer Match Tracker -- Live scores, standings, and fixtures"
    )
    parser.add_argument(
        "--action",
        choices=["live", "standings", "upcoming", "squad", "dashboard"],
        default="dashboard",
        help="Action to perform (default: dashboard)",
    )
    parser.add_argument(
        "--league",
        choices=["PL", "PD", "CL", "MLS"],
        default=None,
        help="League to filter (default: all)",
    )
    parser.add_argument(
        "--days",
        type=int,
        default=7,
        help="Days ahead for upcoming fixtures (default: 7)",
    )
    parser.add_argument(
        "--team-id",
        type=int,
        default=None,
        help="Team ID for squad lookup",
    )
    parser.add_argument(
        "--format",
        choices=["display", "json"],
        default="display",
        help="Output format (default: display)",
    )

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    tracker = MatchTracker()

    if args.action == "live":
        live = tracker.live_scores(league=args.league)
        if args.format == "json":
            print(live.to_json())
        else:
            print(live.display())

    elif args.action == "standings":
        league = args.league or "PL"
        standings = tracker.standings(league=league)
        if args.format == "json":
            print(standings.to_json())
        else:
            print(standings.table())

    elif args.action == "upcoming":
        upcoming = tracker.upcoming(league=args.league, days=args.days)
        if args.format == "json":
            print(upcoming.to_json())
        else:
            print(upcoming.display())

    elif args.action == "squad":
        if args.team_id is None:
            print("Error: --team-id is required for squad lookup")
            return
        squad = tracker.team_squad(args.team_id)
        if args.format == "json":
            print(json.dumps(squad, indent=2))
        else:
            for player in squad:
                pos = player.get("position", "?")
                name = player.get("name", "Unknown")
                num = player.get("shirt_number", "")
                nat = player.get("nationality", "")
                print(f"  #{num:<3} {name:<30} {pos:<15} {nat}")

    elif args.action == "dashboard":
        leagues = [args.league] if args.league else None
        print(tracker.dashboard(leagues=leagues))


if __name__ == "__main__":
    main()
