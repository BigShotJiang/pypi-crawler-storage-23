"""
Comprehensive tests for the soccer-match-tracker skill.

Tests cover:
- RateLimiter behavior (throttling, window expiry)
- ResponseCache (hits, misses, expiry, errors)
- FootballDataClient (standings, matches, upcoming, squad, todays_matches)
- ShippSoccerClient (connection management, live matches, match events, retries)
- MatchTracker orchestrator (live_scores, standings, upcoming, dashboard)
- Display classes (LiveScoresDisplay, StandingsDisplay, FixturesDisplay)
- Error handling (API failures, auth errors, rate limit exhaustion)
- Edge cases (empty data, unknown league codes, cache TTL)
"""

import json
import os
import sys
import tempfile
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from unittest import mock
from unittest.mock import MagicMock, patch, PropertyMock

import pytest
import requests

# The skill directory uses hyphens which are not valid Python package names.
# Add the skill root to sys.path so we can import the `scripts` package directly.
_SKILL_ROOT = str(Path(__file__).resolve().parent.parent)
if _SKILL_ROOT not in sys.path:
    sys.path.insert(0, _SKILL_ROOT)

# Ensure required env vars are set before importing modules that check them at __init__
os.environ.setdefault("FOOTBALL_DATA_API_KEY", "test-football-key")
os.environ.setdefault("SHIPP_API_KEY", "test-shipp-key")

from scripts.football_data import (
    FootballDataClient,
    RateLimiter,
    ResponseCache,
    LEAGUE_CODES,
    CACHE_TTL,
)
from scripts.shipp_wrapper import (
    ShippSoccerClient,
    MAX_RETRIES,
)
from scripts.match_tracker import (
    MatchTracker,
    LiveScoresDisplay,
    StandingsDisplay,
    FixturesDisplay,
    LEAGUE_NAMES,
    ALL_LEAGUES,
)


# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------

def _make_standings_response(league="PL"):
    """Build a realistic football-data.org standings response."""
    return {
        "competition": {"name": "Premier League", "code": league},
        "season": {
            "startDate": "2025-08-01",
            "endDate": "2026-05-31",
            "currentMatchday": 25,
        },
        "standings": [
            {
                "type": "TOTAL",
                "table": [
                    {
                        "position": 1,
                        "team": {"id": 64, "name": "Liverpool FC", "crest": "https://example.com/liv.png"},
                        "playedGames": 25,
                        "won": 19,
                        "draw": 4,
                        "lost": 2,
                        "goalsFor": 55,
                        "goalsAgainst": 18,
                        "goalDifference": 37,
                        "points": 61,
                        "form": "W,W,W,D,W",
                    },
                    {
                        "position": 2,
                        "team": {"id": 65, "name": "Manchester City FC", "crest": "https://example.com/mci.png"},
                        "playedGames": 25,
                        "won": 17,
                        "draw": 3,
                        "lost": 5,
                        "goalsFor": 50,
                        "goalsAgainst": 25,
                        "goalDifference": 25,
                        "points": 54,
                        "form": "W,L,W,W,D",
                    },
                ],
            }
        ],
    }


def _make_matches_response(status="FINISHED"):
    """Build a realistic football-data.org matches response."""
    return {
        "matches": [
            {
                "id": 1001,
                "matchday": 25,
                "status": status,
                "utcDate": "2026-02-15T15:00:00Z",
                "homeTeam": {"id": 64, "name": "Liverpool FC"},
                "awayTeam": {"id": 65, "name": "Manchester City FC"},
                "score": {
                    "fullTime": {"home": 2, "away": 1},
                    "halfTime": {"home": 1, "away": 0},
                    "winner": "HOME_TEAM",
                    "duration": "REGULAR",
                },
                "referees": [
                    {"name": "Michael Oliver", "nationality": "England"},
                ],
            }
        ],
    }


def _make_team_response():
    return {
        "id": 64,
        "name": "Liverpool FC",
        "shortName": "Liverpool",
        "crest": "https://example.com/liv.png",
        "venue": "Anfield",
        "coach": {"name": "Arne Slot"},
        "squad": [
            {
                "id": 501,
                "name": "Mohamed Salah",
                "position": "Offence",
                "dateOfBirth": "1992-06-15",
                "nationality": "Egypt",
                "shirtNumber": 11,
            },
            {
                "id": 502,
                "name": "Virgil van Dijk",
                "position": "Defence",
                "dateOfBirth": "1991-07-08",
                "nationality": "Netherlands",
                "shirtNumber": 4,
            },
        ],
    }


# ---------------------------------------------------------------------------
# RateLimiter tests
# ---------------------------------------------------------------------------

class TestRateLimiter:
    """Tests for the RateLimiter class."""

    def test_allows_requests_under_limit(self):
        """Requests under the limit should pass without sleeping."""
        rl = RateLimiter(max_requests=5, window_seconds=60)
        with patch("time.sleep") as mock_sleep:
            for _ in range(5):
                rl.wait_if_needed()
            mock_sleep.assert_not_called()

    def test_blocks_when_limit_reached(self):
        """When the limit is reached, wait_if_needed should sleep."""
        rl = RateLimiter(max_requests=2, window_seconds=60)
        with patch("time.sleep"):
            rl.wait_if_needed()
            rl.wait_if_needed()

        with patch("time.sleep") as mock_sleep:
            rl.wait_if_needed()
            mock_sleep.assert_called_once()

    def test_old_timestamps_expire(self):
        """Timestamps outside the window should be pruned."""
        rl = RateLimiter(max_requests=2, window_seconds=1)
        rl._timestamps = [time.time() - 5, time.time() - 5]
        # Both timestamps are older than 1 second, so they should be pruned
        with patch("time.sleep") as mock_sleep:
            rl.wait_if_needed()
            mock_sleep.assert_not_called()
        # Only the new timestamp should remain
        assert len(rl._timestamps) == 1


# ---------------------------------------------------------------------------
# ResponseCache tests
# ---------------------------------------------------------------------------

class TestResponseCache:
    """Tests for the ResponseCache class."""

    def test_cache_miss_returns_none(self):
        """A cache miss should return None."""
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = ResponseCache(cache_dir=tmpdir, ttl=300)
            assert cache.get("nonexistent_key") is None

    def test_cache_set_and_get(self):
        """Data stored in cache should be retrievable."""
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = ResponseCache(cache_dir=tmpdir, ttl=300)
            data = {"standings": [{"team": "Liverpool"}]}
            cache.set("test_key", data)
            result = cache.get("test_key")
            assert result == data

    def test_cache_expiry(self):
        """Expired cache entries should return None."""
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = ResponseCache(cache_dir=tmpdir, ttl=1)
            cache.set("expire_key", {"data": "old"})
            # Manually set cached_at to a time in the past
            path = cache._cache_path("expire_key")
            with open(path, "w") as f:
                old_time = (datetime.now(timezone.utc) - timedelta(seconds=600)).isoformat()
                json.dump({"cached_at": old_time, "data": {"data": "old"}}, f)
            assert cache.get("expire_key") is None

    def test_cache_corrupted_json(self):
        """Corrupted cache files should return None, not raise."""
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = ResponseCache(cache_dir=tmpdir, ttl=300)
            path = cache._cache_path("bad_key")
            with open(path, "w") as f:
                f.write("NOT VALID JSON {{{")
            assert cache.get("bad_key") is None

    def test_cache_path_sanitization(self):
        """Cache keys with special characters should produce valid file names."""
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = ResponseCache(cache_dir=tmpdir, ttl=300)
            key = "/competitions/PL/standings?season=2025&matchday=10"
            path = cache._cache_path(key)
            assert "/" not in path.name
            assert "?" not in path.name


# ---------------------------------------------------------------------------
# FootballDataClient tests
# ---------------------------------------------------------------------------

class TestFootballDataClient:
    """Tests for the FootballDataClient class."""

    def _make_client(self):
        """Create a client with mocked session."""
        client = FootballDataClient(api_key="test-key")
        client.cache = ResponseCache(cache_dir=tempfile.mkdtemp(), ttl=300)
        return client

    def test_missing_api_key_raises(self):
        """Creating a client without an API key should raise ValueError."""
        with patch.dict(os.environ, {}, clear=True):
            env_backup = os.environ.pop("FOOTBALL_DATA_API_KEY", None)
            try:
                with pytest.raises(ValueError, match="FOOTBALL_DATA_API_KEY"):
                    FootballDataClient(api_key=None)
            finally:
                if env_backup:
                    os.environ["FOOTBALL_DATA_API_KEY"] = env_backup

    def test_resolve_league_alias(self):
        """League aliases should resolve to canonical codes."""
        client = self._make_client()
        assert client._resolve_league("premier-league") == "PL"
        assert client._resolve_league("epl") == "PL"
        assert client._resolve_league("la-liga") == "PD"
        assert client._resolve_league("ucl") == "CL"
        assert client._resolve_league("PL") == "PL"

    def test_resolve_unknown_league_passthrough(self):
        """Unknown league codes should pass through unchanged."""
        client = self._make_client()
        assert client._resolve_league("UNKNOWN") == "UNKNOWN"

    @patch("time.sleep")
    def test_get_standings_parses_total(self, mock_sleep):
        """get_standings should parse the TOTAL standings type."""
        client = self._make_client()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = _make_standings_response()
        mock_response.raise_for_status = MagicMock()
        client.session.get = MagicMock(return_value=mock_response)

        result = client.get_standings("PL")

        assert result["competition"] == "Premier League"
        assert result["competition_code"] == "PL"
        assert result["matchday"] == 25
        assert len(result["standings"]) == 2
        assert result["standings"][0]["team"] == "Liverpool FC"
        assert result["standings"][0]["points"] == 61
        assert result["standings"][1]["team"] == "Manchester City FC"

    @patch("time.sleep")
    def test_get_standings_fallback_no_total(self, mock_sleep):
        """When no TOTAL type exists, use the first standings group."""
        client = self._make_client()
        response_data = _make_standings_response()
        response_data["standings"][0]["type"] = "HOME"  # not TOTAL

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = response_data
        mock_response.raise_for_status = MagicMock()
        client.session.get = MagicMock(return_value=mock_response)

        result = client.get_standings("PL")
        # Should still return standings from the first group
        assert len(result["standings"]) == 2

    @patch("time.sleep")
    def test_get_standings_empty_standings(self, mock_sleep):
        """Empty standings data should return an empty list."""
        client = self._make_client()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "competition": {"name": "Empty League"},
            "season": {"startDate": "2025", "endDate": "2026", "currentMatchday": 0},
            "standings": [],
        }
        mock_response.raise_for_status = MagicMock()
        client.session.get = MagicMock(return_value=mock_response)

        result = client.get_standings("PL")
        assert result["standings"] == []

    @patch("time.sleep")
    def test_get_matches(self, mock_sleep):
        """get_matches should parse match data correctly."""
        client = self._make_client()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = _make_matches_response()
        mock_response.raise_for_status = MagicMock()
        client.session.get = MagicMock(return_value=mock_response)

        result = client.get_matches("PL", status="FINISHED")

        assert result["competition"] == "PL"
        assert result["count"] == 1
        match = result["matches"][0]
        assert match["home_team"] == "Liverpool FC"
        assert match["away_team"] == "Manchester City FC"
        assert match["home_score"] == 2
        assert match["away_score"] == 1
        assert match["winner"] == "HOME_TEAM"
        assert len(match["referees"]) == 1

    @patch("time.sleep")
    def test_request_403_raises_valueerror(self, mock_sleep):
        """A 403 response should raise ValueError about invalid API key."""
        client = self._make_client()
        mock_response = MagicMock()
        mock_response.status_code = 403
        mock_response.raise_for_status.side_effect = requests.exceptions.HTTPError(
            response=mock_response
        )
        client.session.get = MagicMock(return_value=mock_response)

        with pytest.raises(ValueError, match="API key invalid"):
            client._request("/competitions/PL/standings", use_cache=False)

    @patch("time.sleep")
    def test_request_404_raises_valueerror(self, mock_sleep):
        """A 404 response should raise ValueError about resource not found."""
        client = self._make_client()
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.raise_for_status.side_effect = requests.exceptions.HTTPError(
            response=mock_response
        )
        client.session.get = MagicMock(return_value=mock_response)

        with pytest.raises(ValueError, match="Resource not found"):
            client._request("/competitions/FAKE/standings", use_cache=False)

    @patch("time.sleep")
    def test_request_429_retries(self, mock_sleep):
        """A 429 response should trigger a retry after waiting."""
        client = self._make_client()

        # First response: 429; second response: 200
        mock_429 = MagicMock()
        mock_429.status_code = 429
        mock_429.headers = {"X-RequestCounter-Reset": "2"}

        mock_200 = MagicMock()
        mock_200.status_code = 200
        mock_200.json.return_value = {"data": "ok"}
        mock_200.raise_for_status = MagicMock()

        client.session.get = MagicMock(side_effect=[mock_429, mock_200])

        result = client._request("/test", use_cache=False)
        assert result == {"data": "ok"}
        mock_sleep.assert_called()

    @patch("time.sleep")
    def test_request_connection_error(self, mock_sleep):
        """A connection error should raise RuntimeError."""
        client = self._make_client()
        client.session.get = MagicMock(
            side_effect=requests.exceptions.ConnectionError("Connection refused")
        )

        with pytest.raises(RuntimeError, match="request failed"):
            client._request("/test", use_cache=False)

    @patch("time.sleep")
    def test_get_team_squad(self, mock_sleep):
        """get_team_squad should parse squad data correctly."""
        client = self._make_client()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = _make_team_response()
        mock_response.raise_for_status = MagicMock()
        client.session.get = MagicMock(return_value=mock_response)

        result = client.get_team_squad(64)
        assert result["team"] == "Liverpool FC"
        assert result["coach"] == "Arne Slot"
        assert result["squad_size"] == 2
        assert result["squad"][0]["name"] == "Mohamed Salah"
        assert result["squad"][1]["shirt_number"] == 4

    @patch("time.sleep")
    def test_get_todays_matches_handles_failure(self, mock_sleep):
        """get_todays_matches should gracefully handle per-league failures."""
        client = self._make_client()

        call_count = 0

        def side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                # PL succeeds
                mock_resp = MagicMock()
                mock_resp.status_code = 200
                mock_resp.json.return_value = {
                    "matches": [
                        {
                            "id": 5001,
                            "status": "SCHEDULED",
                            "utcDate": "2026-02-18T20:00:00Z",
                            "homeTeam": {"name": "Arsenal FC"},
                            "awayTeam": {"name": "Chelsea FC"},
                            "score": {"fullTime": {"home": None, "away": None}},
                            "matchday": 26,
                        }
                    ]
                }
                mock_resp.raise_for_status = MagicMock()
                return mock_resp
            else:
                # Other leagues fail
                mock_resp = MagicMock()
                mock_resp.status_code = 200
                mock_resp.json.return_value = {"matches": []}
                mock_resp.raise_for_status = MagicMock()
                return mock_resp

        client.session.get = MagicMock(side_effect=side_effect)

        result = client.get_todays_matches()
        assert "PL" in result
        assert result["PL"][0]["home_team"] == "Arsenal FC"

    @patch("time.sleep")
    def test_request_caching(self, mock_sleep):
        """Second call to the same endpoint should use cache."""
        client = self._make_client()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": "fresh"}
        mock_response.raise_for_status = MagicMock()
        client.session.get = MagicMock(return_value=mock_response)

        # First call hits the API
        result1 = client._request("/competitions/PL/standings")
        assert result1 == {"data": "fresh"}
        assert client.session.get.call_count == 1

        # Second call should use cache
        result2 = client._request("/competitions/PL/standings")
        assert result2 == {"data": "fresh"}
        # Should still be 1 call - second was served from cache
        assert client.session.get.call_count == 1


# ---------------------------------------------------------------------------
# ShippSoccerClient tests
# ---------------------------------------------------------------------------

class TestShippSoccerClient:
    """Tests for the ShippSoccerClient class."""

    def test_missing_api_key_raises(self):
        """Creating a client without an API key should raise ValueError."""
        with patch.dict(os.environ, {}, clear=True):
            env_backup = os.environ.pop("SHIPP_API_KEY", None)
            try:
                with pytest.raises(ValueError, match="SHIPP_API_KEY"):
                    ShippSoccerClient(api_key=None)
            finally:
                if env_backup:
                    os.environ["SHIPP_API_KEY"] = env_backup

    def test_ensure_connection_creates_connection(self):
        """_ensure_connection should POST to create a connection."""
        client = ShippSoccerClient(api_key="test-key")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"connection_id": "conn-123"}
        mock_response.raise_for_status = MagicMock()
        client.session.request = MagicMock(return_value=mock_response)

        client._ensure_connection()
        assert client._connection_id == "conn-123"

    def test_ensure_connection_no_id_raises(self):
        """_ensure_connection should raise if no connection_id is returned."""
        client = ShippSoccerClient(api_key="test-key")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {}  # no connection_id
        mock_response.raise_for_status = MagicMock()
        client.session.request = MagicMock(return_value=mock_response)

        with pytest.raises(RuntimeError, match="no connection_id"):
            client._ensure_connection()

    def test_get_live_matches_updates_cursor(self):
        """get_live_matches should update _last_event_id from events."""
        client = ShippSoccerClient(api_key="test-key")
        client._connection_id = "conn-existing"

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {"id": "evt-1", "home_team": "Liverpool", "away_team": "Arsenal"},
                {"id": "evt-2", "home_team": "Chelsea", "away_team": "Spurs"},
            ]
        }
        mock_response.raise_for_status = MagicMock()
        client.session.request = MagicMock(return_value=mock_response)

        events = client.get_live_matches()
        assert len(events) == 2
        assert client._last_event_id == "evt-2"

    def test_get_live_matches_error_resets_connection(self):
        """On error, get_live_matches should reset connection and return []."""
        client = ShippSoccerClient(api_key="test-key")
        client._connection_id = "conn-will-fail"
        client._last_event_id = "old-evt"
        client.session.request = MagicMock(
            side_effect=requests.exceptions.ConnectionError("down")
        )

        result = client.get_live_matches()
        assert result == []
        assert client._connection_id is None
        assert client._last_event_id is None

    @patch("time.sleep")
    def test_request_retries_on_timeout(self, mock_sleep):
        """_request should retry on Timeout errors up to MAX_RETRIES."""
        client = ShippSoccerClient(api_key="test-key")

        mock_success = MagicMock()
        mock_success.status_code = 200
        mock_success.json.return_value = {"ok": True}
        mock_success.raise_for_status = MagicMock()

        # Fail twice with Timeout, then succeed
        client.session.request = MagicMock(
            side_effect=[
                requests.exceptions.Timeout("timeout1"),
                requests.exceptions.Timeout("timeout2"),
                mock_success,
            ]
        )

        result = client._request("GET", "/test")
        assert result == {"ok": True}
        assert client.session.request.call_count == 3

    @patch("time.sleep")
    def test_request_raises_after_max_retries(self, mock_sleep):
        """_request should raise RuntimeError after exhausting retries."""
        client = ShippSoccerClient(api_key="test-key")
        client.session.request = MagicMock(
            side_effect=requests.exceptions.Timeout("always timeout")
        )

        with pytest.raises(RuntimeError, match="failed after"):
            client._request("GET", "/test")

        assert client.session.request.call_count == MAX_RETRIES + 1

    @patch("time.sleep")
    def test_request_429_rate_limit(self, mock_sleep):
        """_request should wait and retry on 429 responses."""
        client = ShippSoccerClient(api_key="test-key")

        mock_429 = MagicMock()
        mock_429.status_code = 429
        mock_429.headers = {"Retry-After": "1"}

        mock_200 = MagicMock()
        mock_200.status_code = 200
        mock_200.json.return_value = {"ok": True}
        mock_200.raise_for_status = MagicMock()

        client.session.request = MagicMock(side_effect=[mock_429, mock_200])
        result = client._request("GET", "/test")
        assert result == {"ok": True}

    @patch("time.sleep")
    def test_request_client_error_not_retried(self, mock_sleep):
        """Client errors (4xx, not 429) should be raised immediately."""
        client = ShippSoccerClient(api_key="test-key")

        mock_response = MagicMock()
        mock_response.status_code = 401
        http_error = requests.exceptions.HTTPError(response=mock_response)
        mock_response.raise_for_status.side_effect = http_error

        client.session.request = MagicMock(return_value=mock_response)

        with pytest.raises(requests.exceptions.HTTPError):
            client._request("GET", "/test")

        # Should only try once for client errors
        assert client.session.request.call_count == 1

    def test_close_connection(self):
        """close_connection should clear connection state."""
        client = ShippSoccerClient(api_key="test-key")
        client._connection_id = "conn-123"
        client._last_event_id = "evt-456"
        client.close_connection()
        assert client._connection_id is None
        assert client._last_event_id is None

    def test_get_match_events_returns_events(self):
        """get_match_events should return events for a specific match."""
        client = ShippSoccerClient(api_key="test-key")
        client._connection_id = "conn-123"

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {"minute": 23, "type": "GOAL", "player": "Salah", "team": "Liverpool"},
                {"minute": 45, "type": "YELLOW_CARD", "player": "Rice", "team": "Arsenal"},
            ]
        }
        mock_response.raise_for_status = MagicMock()
        client.session.request = MagicMock(return_value=mock_response)

        events = client.get_match_events("match-999")
        assert len(events) == 2
        assert events[0]["player"] == "Salah"

    def test_get_schedule(self):
        """get_schedule should return game list."""
        client = ShippSoccerClient(api_key="test-key")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "games": [
                {"home_team": "Liverpool", "away_team": "Arsenal", "time": "15:00"},
            ]
        }
        mock_response.raise_for_status = MagicMock()
        client.session.request = MagicMock(return_value=mock_response)

        games = client.get_schedule("2026-02-18")
        assert len(games) == 1


# ---------------------------------------------------------------------------
# Display class tests
# ---------------------------------------------------------------------------

class TestLiveScoresDisplay:
    """Tests for LiveScoresDisplay."""

    def test_no_live_matches(self):
        """Should show 'No live matches' message when there are none."""
        display = LiveScoresDisplay({"leagues": {}})
        output = display.display()
        assert "No live matches" in output

    def test_live_match_display(self):
        """Should correctly format a live match with score."""
        data = {
            "leagues": {
                "PL": [
                    {
                        "home_team": "Liverpool FC",
                        "away_team": "Arsenal FC",
                        "home_score": 2,
                        "away_score": 1,
                        "status": "IN_PLAY",
                        "minute": 67,
                        "events": [],
                    }
                ]
            }
        }
        display = LiveScoresDisplay(data)
        output = display.display()
        assert "Premier League" in output
        assert "Liverpool FC" in output
        assert "2 - 1" in output
        assert "67'" in output

    def test_finished_match_shows_ft(self):
        """Finished matches should show FT."""
        data = {
            "leagues": {
                "PD": [
                    {
                        "home_team": "Real Madrid",
                        "away_team": "Barcelona",
                        "home_score": 3,
                        "away_score": 2,
                        "status": "FINISHED",
                        "minute": None,
                        "events": [],
                    }
                ]
            }
        }
        display = LiveScoresDisplay(data)
        output = display.display()
        assert "FT" in output
        assert "La Liga" in output

    def test_scheduled_match_shows_vs(self):
        """Scheduled matches should show 'vs' format."""
        data = {
            "leagues": {
                "CL": [
                    {
                        "home_team": "Bayern Munich",
                        "away_team": "PSG",
                        "home_score": None,
                        "away_score": None,
                        "status": "SCHEDULED",
                        "minute": None,
                        "start_time": "20:00",
                        "events": [],
                    }
                ]
            }
        }
        display = LiveScoresDisplay(data)
        output = display.display()
        assert "vs" in output
        assert "Champions League" in output

    def test_event_formatting(self):
        """Match events should be formatted with type labels."""
        data = {
            "leagues": {
                "PL": [
                    {
                        "home_team": "Liverpool",
                        "away_team": "Arsenal",
                        "home_score": 1,
                        "away_score": 0,
                        "status": "IN_PLAY",
                        "minute": 30,
                        "events": [
                            {"minute": 23, "type": "GOAL", "player": "Salah", "team": "Liverpool"},
                            {"minute": 28, "type": "YELLOW_CARD", "player": "Rice", "team": "Arsenal"},
                            {"minute": 29, "type": "SUBSTITUTION", "player": "Saka", "team": "Arsenal"},
                        ],
                    }
                ]
            }
        }
        display = LiveScoresDisplay(data)
        output = display.display()
        assert "GOAL" in output
        assert "YELLOW CARD" in output
        assert "SUB" in output

    def test_to_json(self):
        """to_json should return valid JSON."""
        data = {"leagues": {"PL": []}}
        display = LiveScoresDisplay(data)
        parsed = json.loads(display.to_json())
        assert parsed == data


class TestStandingsDisplay:
    """Tests for StandingsDisplay."""

    def test_table_formatting(self):
        """Standings table should include all columns."""
        data = {
            "competition": "Premier League",
            "matchday": 25,
            "standings": [
                {
                    "position": 1,
                    "team": "Liverpool FC",
                    "played": 25,
                    "won": 19,
                    "draw": 4,
                    "lost": 2,
                    "goals_for": 55,
                    "goals_against": 18,
                    "goal_difference": 37,
                    "points": 61,
                },
            ],
        }
        display = StandingsDisplay(data)
        output = display.table()
        assert "Premier League" in output
        assert "Matchday 25" in output
        assert "Liverpool FC" in output
        assert "+37" in output  # positive goal difference


class TestFixturesDisplay:
    """Tests for FixturesDisplay."""

    def test_no_fixtures(self):
        """Should show 'No upcoming fixtures' when empty."""
        display = FixturesDisplay({"leagues": {}, "days": 7})
        output = display.display()
        assert "No upcoming fixtures" in output

    def test_fixtures_grouped_by_date(self):
        """Fixtures should be grouped by date."""
        data = {
            "leagues": {
                "PL": [
                    {
                        "home_team": "Liverpool",
                        "away_team": "Arsenal",
                        "utc_date": "2026-02-20T15:00:00Z",
                    },
                ]
            },
            "days": 7,
        }
        display = FixturesDisplay(data)
        output = display.display()
        assert "Liverpool" in output
        assert "Arsenal" in output
        assert "vs" in output


# ---------------------------------------------------------------------------
# MatchTracker integration tests (with mocks)
# ---------------------------------------------------------------------------

class TestMatchTracker:
    """Tests for the MatchTracker orchestrator."""

    def _make_tracker(self):
        """Create a MatchTracker with mocked sub-clients."""
        with patch.object(ShippSoccerClient, "__init__", return_value=None), \
             patch.object(FootballDataClient, "__init__", return_value=None):
            tracker = MatchTracker(shipp_api_key="test", football_data_api_key="test")
        tracker.shipp = MagicMock(spec=ShippSoccerClient)
        tracker.football_data = MagicMock(spec=FootballDataClient)
        return tracker

    def test_standings_delegates_to_football_data(self):
        """standings() should delegate to football_data.get_standings."""
        tracker = self._make_tracker()
        tracker.football_data.get_standings.return_value = {
            "competition": "Premier League",
            "competition_code": "PL",
            "matchday": 25,
            "standings": [],
        }

        result = tracker.standings("PL")
        assert isinstance(result, StandingsDisplay)
        tracker.football_data.get_standings.assert_called_once_with("PL")

    def test_live_scores_merges_data(self):
        """live_scores() should merge Shipp and football-data sources."""
        tracker = self._make_tracker()
        tracker.shipp.get_live_matches.return_value = [
            {
                "home_team": "Liverpool FC",
                "away_team": "Arsenal FC",
                "home_score": 2,
                "away_score": 1,
                "minute": 67,
                "status": "LIVE",
                "events": [{"minute": 23, "type": "GOAL", "player": "Salah", "team": "Liverpool"}],
            }
        ]
        tracker.football_data.get_matches.return_value = {
            "matches": [
                {
                    "match_id": 1001,
                    "home_team": "Liverpool FC",
                    "away_team": "Arsenal FC",
                    "home_score": 1,
                    "away_score": 0,
                    "status": "IN_PLAY",
                    "matchday": 25,
                }
            ]
        }

        result = tracker.live_scores(league="PL")
        assert isinstance(result, LiveScoresDisplay)
        leagues = result.data["leagues"]
        # Should have merged the Shipp live score into the football-data match
        assert "PL" in leagues
        match = leagues["PL"][0]
        assert match["home_score"] == 2  # Shipp score overrides
        assert match["minute"] == 67

    def test_upcoming_all_leagues(self):
        """upcoming() without league should query all leagues."""
        tracker = self._make_tracker()
        tracker.football_data.get_upcoming.return_value = {
            "matches": [
                {"home_team": "A", "away_team": "B", "utc_date": "2026-02-20T15:00:00Z"}
            ]
        }

        result = tracker.upcoming(days=3)
        assert isinstance(result, FixturesDisplay)
        # Should have been called for each league in ALL_LEAGUES
        assert tracker.football_data.get_upcoming.call_count == len(ALL_LEAGUES)

    def test_dashboard_handles_errors_gracefully(self):
        """dashboard() should not crash when individual sections fail."""
        tracker = self._make_tracker()
        tracker.shipp.get_live_matches.side_effect = Exception("Shipp down")
        tracker.football_data.get_matches.side_effect = Exception("FD down")
        tracker.football_data.get_standings.side_effect = Exception("standings down")
        tracker.football_data.get_upcoming.side_effect = Exception("upcoming down")

        # Should not raise -- errors are caught and shown inline
        output = tracker.dashboard()
        assert "Error" in output

    def test_match_events_delegates_to_shipp(self):
        """match_events() should delegate to shipp.get_match_events."""
        tracker = self._make_tracker()
        tracker.shipp.get_match_events.return_value = [
            {"minute": 10, "type": "GOAL", "player": "Salah", "team": "Liverpool"}
        ]

        events = tracker.match_events("match-123")
        assert len(events) == 1
        tracker.shipp.get_match_events.assert_called_once_with("match-123")

    def test_team_squad_returns_squad_list(self):
        """team_squad() should return the squad list."""
        tracker = self._make_tracker()
        tracker.football_data.get_team_squad.return_value = {
            "squad": [
                {"name": "Salah", "position": "Forward"},
                {"name": "Van Dijk", "position": "Defence"},
            ]
        }
        squad = tracker.team_squad(64)
        assert len(squad) == 2
        assert squad[0]["name"] == "Salah"


# ---------------------------------------------------------------------------
# Multi-league / edge case tests
# ---------------------------------------------------------------------------

class TestMultiLeagueHandling:
    """Tests for multi-league scenarios and edge cases."""

    def test_league_codes_has_all_aliases(self):
        """LEAGUE_CODES should contain all expected aliases."""
        assert "PL" in LEAGUE_CODES
        assert "PD" in LEAGUE_CODES
        assert "CL" in LEAGUE_CODES
        assert "MLS" in LEAGUE_CODES
        assert "premier-league" in LEAGUE_CODES
        assert "la-liga" in LEAGUE_CODES
        assert "epl" in LEAGUE_CODES
        assert "ucl" in LEAGUE_CODES

    def test_league_names_mapping(self):
        """LEAGUE_NAMES should cover all main league codes."""
        for code in ALL_LEAGUES:
            assert code in LEAGUE_NAMES

    def test_unknown_league_in_display(self):
        """LiveScoresDisplay should handle unknown league codes gracefully."""
        data = {
            "leagues": {
                "UNKNOWN_LEAGUE": [
                    {
                        "home_team": "Team A",
                        "away_team": "Team B",
                        "home_score": 0,
                        "away_score": 0,
                        "status": "IN_PLAY",
                        "minute": 10,
                        "events": [],
                    }
                ]
            }
        }
        display = LiveScoresDisplay(data)
        output = display.display()
        # Should fall back to the code itself as the header
        assert "UNKNOWN_LEAGUE" in output
        assert "Team A" in output
