# Setup Guide — soccer-match-tracker Skill

This guide walks you through configuring all required and optional API keys
for the `soccer-match-tracker` skill.

## Required: Shipp.ai API Key

The Shipp.ai API key is required for live match scores, minute-by-minute
events, and real-time match data across global soccer competitions.

### Steps

1. **Create an account** at [platform.shipp.ai](https://platform.shipp.ai)
2. **Sign in** and navigate to **Settings > API Keys**
3. **Generate a new API key** — copy it immediately (it won't be shown again)
4. **Set the environment variable**:

```bash
# Add to your shell profile (~/.zshrc, ~/.bashrc, etc.)
export SHIPP_API_KEY="shipp_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```

5. **Verify** by running:

```bash
curl -s -H "Authorization: Bearer $SHIPP_API_KEY" \
  "https://api.shipp.ai/api/v1/connections" | python3 -m json.tool
```

You should see a JSON response (even if the connections list is empty).

### API Key Format

Shipp API keys typically start with `shipp_live_` or `shipp_test_`. Use the
`live` key for production sports data.

### Rate Limits

Your rate limit depends on your Shipp.ai plan:

| Plan       | Requests/min | Connections | Notes                    |
|------------|-------------|-------------|--------------------------|
| Free       | 30          | 3           | Great for trying it out  |
| Starter    | 120         | 10          | Suitable for one sport   |
| Pro        | 600         | 50          | All three sports         |
| Enterprise | Custom      | Unlimited   | Contact sales            |

## Required: Football-Data.org API Key

The Football-Data.org API key is required for standings, fixtures, team
data, and competition details. This is a core dependency of the skill.

### Steps

1. **Register** at [football-data.org/client/register](https://www.football-data.org/client/register)
2. **Confirm your email** — the API key is sent to your inbox
3. **Set the environment variable**:

```bash
export FOOTBALL_DATA_API_KEY="your-football-data-api-key"
```

4. **Verify** by running:

```bash
curl -s -H "X-Auth-Token: $FOOTBALL_DATA_API_KEY" \
  "https://api.football-data.org/v4/competitions" | python3 -m json.tool
```

You should see a JSON list of available competitions.

### Free Tier Limits

- 10 requests per minute
- Access to major competitions: Premier League, La Liga, Bundesliga,
  Serie A, Ligue 1, Champions League
- No player-level stats (team and competition data only)

### Paid Plans

If you need access to additional leagues or higher rate limits,
football-data.org offers paid tiers. Check
[football-data.org/pricing](https://www.football-data.org/coverage) for
current plans and coverage details.

## Python Dependencies

Install the required packages:

```bash
pip install requests rich
```

`rich` is used for rendering formatted match tables and live-updating
terminal output. All other dependencies are from the Python standard
library (`os`, `time`, `logging`, `datetime`, `json`, `typing`).

## Environment Variable Summary

| Variable                | Required | Source             | Purpose                              |
|-------------------------|----------|--------------------|--------------------------------------|
| `SHIPP_API_KEY`         | Yes      | platform.shipp.ai  | Live scores, match events            |
| `FOOTBALL_DATA_API_KEY` | Yes      | football-data.org   | Standings, fixtures, team data       |

## Verifying Your Setup

Run the built-in smoke test:

```bash
cd skills/community/soccer-match-tracker
python3 scripts/match_tracker.py --once
```

This will attempt to:
1. Fetch live match scores (requires `SHIPP_API_KEY`)
2. Fetch league standings (requires `FOOTBALL_DATA_API_KEY`)
3. Fetch upcoming fixtures (requires `FOOTBALL_DATA_API_KEY`)
4. Display a formatted summary of today's matches and current tables

Each section will show either data or an error message indicating which
key is missing or which service is unavailable.

## Troubleshooting

### "SHIPP_API_KEY environment variable is not set"

Your shell session doesn't have the key. Make sure you either:
- Added `export SHIPP_API_KEY=...` to your shell profile and restarted the terminal
- Or ran the export command in the current session

### "FOOTBALL_DATA_API_KEY environment variable is not set"

The Football-Data.org API key is required for this skill to function.
Follow the steps in the "Required: Football-Data.org API Key" section above.

### "Shipp API 401: Unauthorized"

The key is set but invalid. Double-check:
- No extra spaces or newline characters in the key
- The key is from the correct environment (live vs test)
- The key hasn't been revoked

### "Shipp API 402: Payment Required"

Your plan's quota has been exceeded. Check your usage at
[platform.shipp.ai/usage](https://platform.shipp.ai) or upgrade your plan.

### "Shipp API 429: Too Many Requests"

You've hit the rate limit. The tracker automatically retries with backoff,
but if it persists, reduce polling frequency or upgrade your plan.

### "Football-Data.org 403: Restricted"

Your API key may not have access to the requested competition. The free
tier only covers major European competitions — smaller leagues or lower
divisions require a paid plan.

### Football-data.org returns empty results

Ensure `FOOTBALL_DATA_API_KEY` is set and valid. If you recently registered,
allow a few minutes for the key to activate. Also check that the competition
you are querying is included in your plan's coverage.

## Documentation Links

- **Shipp.ai Docs**: [docs.shipp.ai](https://docs.shipp.ai)
- **Shipp.ai API Reference**: [docs.shipp.ai/api](https://docs.shipp.ai/api)
- **Football-Data.org Docs**: [football-data.org/documentation](https://www.football-data.org/documentation/quickstart)
- **Football-Data.org API v4**: [football-data.org/documentation/api](https://www.football-data.org/documentation/api)
