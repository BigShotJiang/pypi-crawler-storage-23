raise RuntimeError(
    "This is a placeholder package to prevent typosquatting. "
    "Install the official package: pip install tracewell"
)