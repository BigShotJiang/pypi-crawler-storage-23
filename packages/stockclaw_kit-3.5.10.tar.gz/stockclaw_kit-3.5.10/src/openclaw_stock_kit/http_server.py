#!/usr/bin/env python3
"""StockClaw Kit HTTP 서버"""

import json
import logging
import mimetypes
import os
from pathlib import Path

import httpx

logger = logging.getLogger("stock-kit.http")

# ─── method → api_code 매핑 (프론트엔드 호환용) ─────────────────────────
KIWOOM_METHOD_MAP = {
    "surgeStocks": "ka10019",
    "volumeSurge": "ka10023",
    "ka10032": "ka10032",
    "ka10027": "ka10027",
    "ka10029": "ka10029",
    "themeGroups": "ka90001",
    "themeStocks": "ka90002",
    "supplyDemand": "ka90009",
    "programTop50": "ka90003",
    "stockInfo": "ka10001",
    "investorTrend": "ka10059",
    "investorSummary": "ka10061",
    "investorChart": "ka10060",
    "realtimeRank": "ka00198",
    "stockQuote": "ka10007",
    "stockHoga": "ka10004",
}

# ─── MIME 타입 보조 ─────────────────────────────────────────────────────
_MIME_MAP = {
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".mjs": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".ico": "image/x-icon",
}


def _mime(path: Path) -> str:
    return _MIME_MAP.get(path.suffix.lower(), "application/octet-stream")


def _json_ok(data) -> dict:
    """성공 응답 래퍼 — 도구 반환값이 이미 dict면 그대로 통과"""
    if isinstance(data, dict):
        return data
    # 문자열(JSON 직렬화된 도구 출력)이면 파싱 시도
    if isinstance(data, str):
        try:
            return json.loads(data)
        except Exception:
            return {"ok": True, "result": data}
    return {"ok": True, "result": data}


def _json_err(message: str, status: int = 400) -> tuple:
    """에러 응답 (body dict, status code)"""
    return {"ok": False, "error": message}, status


def create_app(registry, modules_status, config_dir, env_file):
    """Starlette ASGI 앱을 생성하여 반환.

    Args:
        registry: ToolRegistry 인스턴스 (registry.get_tool(name) 사용)
        modules_status: 모듈 로딩 상태 딕셔너리
        config_dir: Path — ~/.stockclaw-kit 설정 디렉토리
        env_file: Path — config_dir/.env 파일 경로

    Returns:
        Starlette ASGI 앱
    """
    from starlette.applications import Starlette
    from starlette.responses import HTMLResponse, JSONResponse, Response
    from starlette.routing import Route, Mount
    from starlette.middleware import Middleware
    from starlette.middleware.cors import CORSMiddleware

    _pkg_dir = Path(__file__).parent
    _ui_dir = _pkg_dir / "ui"

    # ─── 헬퍼: registry 도구 호출 ────────────────────────────────────────
    def _call(tool_name: str, args: dict):
        """registry에서 도구를 꺼내 호출. 결과는 dict 또는 str."""
        fn = registry.get_tool(tool_name)
        if fn is None:
            return None, f"도구 '{tool_name}'를 찾을 수 없습니다 (모듈 로딩 실패?)"
        try:
            import asyncio
            if asyncio.iscoroutinefunction(fn):
                loop = asyncio.get_event_loop()
                result = loop.run_until_complete(fn(**args))
            else:
                result = fn(**args)
            return result, None
        except Exception as e:
            return None, str(e)

    async def _call_async(tool_name: str, args: dict):
        """async 컨텍스트에서 도구 호출 — 동기 함수는 스레드풀에서 실행."""
        fn = registry.get_tool(tool_name)
        if fn is None:
            return None, f"도구 '{tool_name}'를 찾을 수 없습니다 (모듈 로딩 실패?)"
        try:
            import asyncio
            if asyncio.iscoroutinefunction(fn):
                result = await fn(**args)
            else:
                # 동기 함수를 스레드풀에서 실행하여 event loop 블로킹 방지
                import functools
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, functools.partial(fn, **args))
            return result, None
        except Exception as e:
            return None, str(e)

    # ─── 키 유틸리티 ─────────────────────────────────────────────────────
    def _load_env_keys() -> dict:
        if not env_file.exists():
            return {}
        try:
            from dotenv import dotenv_values
            return dict(dotenv_values(env_file))
        except Exception:
            return {}

    def _save_env_keys(keys: dict):
        lines = [f"{k}={v}" for k, v in keys.items() if v]
        env_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
        try:
            env_file.chmod(0o600)
        except OSError:
            pass
        for k, v in keys.items():
            if v:
                os.environ[k] = str(v)

    def _is_setup_done() -> bool:
        if not env_file.exists():
            return False
        try:
            from dotenv import dotenv_values
            keys = {k: v for k, v in dotenv_values(env_file).items() if v}
            return len(keys) > 0
        except Exception:
            return False

    # ─── 뉴스 DB ─────────────────────────────────────────────────────
    from .news_db import NewsDB
    _news_db = NewsDB(str(config_dir))
    # ─── 텔레그램 DB ─────────────────────────────────────────────────
    from .telegram_db import TelegramDB
    _telegram_db = TelegramDB(str(config_dir))

    # ═══════════════════════════════════════════════════════════════════
    # 정적 페이지 라우트
    # ═══════════════════════════════════════════════════════════════════

    async def page_root(request):
        """/ — 통합 UI가 있으면 UI로, 없으면 setup으로 리다이렉트"""
        from starlette.responses import RedirectResponse
        if (_ui_dir / "stockclaw-kit-ui.html").exists():
            return RedirectResponse("/ui/stockclaw-kit-ui.html", status_code=302)
        return RedirectResponse("/setup", status_code=302)

    async def page_setup(request):
        """/setup → setup.html 직접 서빙 (무료배포용 설정 페이지)"""
        target = _pkg_dir / "setup.html"
        if not target.exists():
            return Response("setup.html not found", status_code=404)
        return Response(target.read_bytes(), media_type="text/html; charset=utf-8")

    async def page_settings(request):
        """/settings → /setup#credentials 리다이렉트"""
        from starlette.responses import RedirectResponse
        return RedirectResponse("/setup#credentials", status_code=302)

    async def page_landing(request):
        """/landing → landing.html 서빙"""
        target = _pkg_dir / "landing.html"
        if not target.exists():
            return Response("landing.html not found", status_code=404)
        return Response(target.read_bytes(), media_type="text/html; charset=utf-8")

    async def page_ui_static(request):
        """GET /ui/{path:path} — ui/ 디렉토리 정적 파일 서빙"""
        rel = request.path_params.get("path", "")
        # 경로 탈출 방지
        target = (_ui_dir / rel).resolve()
        if not str(target).startswith(str(_ui_dir.resolve())):
            return JSONResponse({"ok": False, "error": "forbidden"}, status_code=403)
        if not target.exists() or not target.is_file():
            return Response("Not Found", status_code=404)
        content = target.read_bytes()
        return Response(content, media_type=_mime(target))

    # ═══════════════════════════════════════════════════════════════════
    # 키움증권 API
    # ═══════════════════════════════════════════════════════════════════

    async def api_kiwoom_call(request):
        """POST /api/kiwoom/call"""
        try:
            body = await request.json()
        except Exception:
            body = {}

        # method → api_code 자동 변환 (프론트엔드 호환)
        api_code = body.get("api_code")
        method = body.get("method")
        if not api_code and method:
            api_code = KIWOOM_METHOD_MAP.get(method)
            if not api_code:
                err, status = _json_err(f"알 수 없는 method: {method}")
                return JSONResponse(err, status_code=status)

        if not api_code:
            err, status = _json_err("api_code 또는 method 필드가 필요합니다")
            return JSONResponse(err, status_code=status)

        params = body.get("params", {})
        payload_json = json.dumps(params, ensure_ascii=False)

        result, error = await _call_async("kiwoom_call_api", {
            "api_code": api_code,
            "payload_json": payload_json,
        })
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    async def api_kiwoom_list(request):
        """GET /api/kiwoom/list"""
        result, error = await _call_async("kiwoom_list_apis", {})
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    async def api_kiwoom_spec(request):
        """GET /api/kiwoom/spec?api_code=xxx"""
        api_code = request.query_params.get("api_code", "")
        if not api_code:
            err, status = _json_err("api_code 쿼리 파라미터가 필요합니다")
            return JSONResponse(err, status_code=status)
        result, error = await _call_async("kiwoom_api_spec", {"api_code": api_code})
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    async def api_kiwoom_condition_list(request):
        """POST /api/kiwoom/condition/list"""
        result, error = await _call_async("kiwoom_condition_list", {})
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    async def api_kiwoom_condition_search(request):
        """POST /api/kiwoom/condition/search"""
        try:
            body = await request.json()
        except Exception:
            body = {}
        result, error = await _call_async("kiwoom_condition_search", body)
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    async def api_kiwoom_condition_realtime(request):
        """POST /api/kiwoom/condition/realtime"""
        try:
            body = await request.json()
        except Exception:
            body = {}
        result, error = await _call_async("kiwoom_condition_realtime", body)
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    async def api_kiwoom_condition_stop(request):
        """POST /api/kiwoom/condition/stop"""
        try:
            body = await request.json()
        except Exception:
            body = {}
        result, error = await _call_async("kiwoom_condition_stop", body)
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    # ═══════════════════════════════════════════════════════════════════
    # DataKit API
    # ═══════════════════════════════════════════════════════════════════

    async def api_datakit_call(request):
        """POST /api/datakit/call"""
        try:
            body = await request.json()
        except Exception:
            body = {}

        function = body.get("function")
        if not function:
            err, status = _json_err("function 필드가 필요합니다")
            return JSONResponse(err, status_code=status)

        params = body.get("params", {})
        params_json = json.dumps(params, ensure_ascii=False)

        result, error = await _call_async("datakit_call", {
            "function": function,
            "params_json": params_json,
        })
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    async def api_datakit_list(request):
        """GET /api/datakit/list"""
        result, error = await _call_async("datakit_list_functions", {})
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    # ═══════════════════════════════════════════════════════════════════
    # KIS API
    # ═══════════════════════════════════════════════════════════════════

    # KIS 카테고리 → 도구 이름 매핑
    _KIS_CATEGORY_MAP = {
        "domestic_stock": "kis_domestic_stock",
        "overseas_stock": "kis_overseas_stock",
        "domestic_bond": "kis_domestic_bond",
        "domestic_futureoption": "kis_domestic_futureoption",
        "overseas_futureoption": "kis_overseas_futureoption",
        "elw": "kis_elw",
        "etfetn": "kis_etfetn",
        "auth": "kis_auth",
    }

    async def api_kis_category(request):
        """POST /api/kis/{category}"""
        category = request.path_params.get("category", "")
        tool_name = _KIS_CATEGORY_MAP.get(category)
        if not tool_name:
            err, status = _json_err(
                f"알 수 없는 KIS 카테고리: {category}. "
                f"사용 가능: {', '.join(_KIS_CATEGORY_MAP.keys())}"
            )
            return JSONResponse(err, status_code=status)

        try:
            body = await request.json()
        except Exception:
            body = {}

        api_type = body.get("api_type")
        if not api_type:
            err, status = _json_err("api_type 필드가 필요합니다")
            return JSONResponse(err, status_code=status)

        params = body.get("params", {})
        result, error = await _call_async(tool_name, {
            "api_type": api_type,
            "params": params,
        })
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    # ═══════════════════════════════════════════════════════════════════
    # 멤버십 데이터 API
    # ═══════════════════════════════════════════════════════════════════

    async def api_membership_call(request):
        """POST /api/membership/call"""
        try:
            body = await request.json()
        except Exception:
            body = {}

        api_id = body.get("api_id")
        if not api_id:
            err, status = _json_err("api_id 필드가 필요합니다 (예: 'ka-002')")
            return JSONResponse(err, status_code=status)

        params = body.get("params", {})
        result, error = await _call_async("membership_call", {
            "api_id": api_id,
            "params": params,
        })
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    async def api_membership_list(request):
        """GET /api/membership/list"""
        result, error = await _call_async("membership_list_functions", {})
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    # ═══════════════════════════════════════════════════════════════════
    # 뉴스 & 텔레그램 API
    # ═══════════════════════════════════════════════════════════════════

    async def api_news_search(request):
        """POST /api/news/search"""
        try:
            body = await request.json()
        except Exception:
            body = {}

        query = body.get("query", "")
        if not query:
            err, status = _json_err("query 필드가 필요합니다")
            return JSONResponse(err, status_code=status)

        display = body.get("display", 10)
        result, error = await _call_async("news_search", {
            "query": query,
            "display": display,
        })
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    async def api_news_stock(request):
        """POST /api/news/stock"""
        try:
            body = await request.json()
        except Exception:
            body = {}

        stock_name = body.get("stock_name", "")
        if not stock_name:
            err, status = _json_err("stock_name 필드가 필요합니다")
            return JSONResponse(err, status_code=status)

        kwargs = {"stock_name": stock_name}
        for key in ("days", "display", "dedup"):
            if key in body:
                kwargs[key] = body[key]

        result, error = await _call_async("news_search_stock", kwargs)
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    async def api_news_db_save(request):
        """POST /api/news/db/save — 뉴스 기사 DB 저장"""
        try:
            body = await request.json()
        except Exception:
            body = {}
        keyword = body.get("keyword", "")
        articles = body.get("articles", [])
        if not keyword or not articles:
            err, status = _json_err("keyword와 articles 필드가 필요합니다")
            return JSONResponse(err, status_code=status)
        result = _news_db.save_articles(keyword, articles)
        return JSONResponse({"ok": True, **result})

    async def api_news_db_history(request):
        """GET /api/news/db/history — 저장된 뉴스 조회"""
        keyword = request.query_params.get("keyword", "")
        limit = int(request.query_params.get("limit", "100"))
        offset = int(request.query_params.get("offset", "0"))
        result = _news_db.get_history(keyword, limit, offset)
        return JSONResponse({"ok": True, **result})

    async def api_news_db_keywords(request):
        """GET /api/news/db/keywords — 저장된 키워드 목록"""
        keywords = _news_db.get_keywords()
        return JSONResponse({"ok": True, "keywords": keywords})

    async def api_news_db_delete(request):
        """POST /api/news/db/delete — 선택 삭제"""
        try:
            body = await request.json()
        except Exception:
            body = {}
        ids = body.get("ids", [])
        if not ids:
            err, status = _json_err("ids 필드가 필요합니다")
            return JSONResponse(err, status_code=status)
        deleted = _news_db.delete_articles(ids)
        return JSONResponse({"ok": True, "deleted": deleted})

    async def api_news_db_delete_all(request):
        """POST /api/news/db/delete-all — 전체 삭제"""
        deleted = _news_db.delete_all()
        return JSONResponse({"ok": True, "deleted": deleted})

    # ─── 텔레그램 메시지 DB API ──────────────────────────────────────
    async def api_telegram_db_save(request):
        """POST /api/telegram/db/save — 텔레그램 메시지 DB 저장"""
        try:
            body = await request.json()
        except Exception:
            body = {}
        messages = body.get("messages", [])
        if not messages:
            err, status = _json_err("messages 필드가 필요합니다")
            return JSONResponse(err, status_code=status)
        result = _telegram_db.save_messages(messages)
        return JSONResponse({"ok": True, **result})

    async def api_telegram_db_messages(request):
        """GET /api/telegram/db/messages — 저장된 텔레그램 메시지 조회"""
        channel_id = request.query_params.get("channel_id", "")
        keyword = request.query_params.get("keyword", "")
        start_date = request.query_params.get("start_date", "")
        end_date = request.query_params.get("end_date", "")
        is_ad = request.query_params.get("is_ad", "")
        limit = int(request.query_params.get("limit", "50"))
        page = int(request.query_params.get("page", "1"))
        result = _telegram_db.get_messages(
            channel_id=channel_id, keyword=keyword,
            start_date=start_date, end_date=end_date,
            is_ad=is_ad, limit=limit, page=page
        )
        return JSONResponse({"ok": True, "success": True, **result})

    async def api_telegram_db_channels(request):
        """GET /api/telegram/db/channels — 저장된 채널 목록 + 메시지 수"""
        channels = _telegram_db.get_channels()
        return JSONResponse({"ok": True, "channels": channels})

    async def api_telegram_db_stats(request):
        """GET /api/telegram/db/stats — 통계"""
        stats = _telegram_db.get_stats()
        return JSONResponse({"ok": True, **stats})

    async def api_telegram_db_delete(request):
        """POST /api/telegram/db/delete — 선택 삭제"""
        try:
            body = await request.json()
        except Exception:
            body = {}
        ids = body.get("ids", [])
        if not ids:
            err, status = _json_err("ids 필드가 필요합니다")
            return JSONResponse(err, status_code=status)
        deleted = _telegram_db.delete_messages(ids)
        return JSONResponse({"ok": True, "deleted": deleted})

    async def api_telegram(request):
        """GET /api/telegram (status) | POST /api/telegram (action)"""
        if request.method == "GET":
            kwargs = {"action": "status"}
        else:
            try:
                body = await request.json()
            except Exception:
                body = {}
            kwargs = {
                "action": body.get("action", "status"),
            }
            if body.get("code"):
                kwargs["code"] = body["code"]
            if body.get("password"):
                kwargs["password"] = body["password"]

        result, error = await _call_async("telegram_auth", kwargs)
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    async def api_telegram_channels(request):
        """GET /api/telegram/channels"""
        result, error = await _call_async("telegram_get_channels", {})
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    async def api_telegram_messages(request):
        """POST /api/telegram/messages"""
        try:
            body = await request.json()
        except Exception:
            body = {}

        channel = body.get("channel", "")
        if not channel:
            err, status = _json_err("channel 필드가 필요합니다")
            return JSONResponse(err, status_code=status)

        kwargs = {"channel": channel}
        if "limit" in body:
            kwargs["limit"] = body["limit"]
        if "filter_ads" in body:
            kwargs["filter_ads"] = body["filter_ads"]
        if "start_date" in body:
            kwargs["start_date"] = body["start_date"]
        if "end_date" in body:
            kwargs["end_date"] = body["end_date"]

        result, error = await _call_async("telegram_get_messages", kwargs)
        if error:
            return JSONResponse({"ok": False, "error": error}, status_code=500)
        return JSONResponse(_json_ok(result))

    # ═══════════════════════════════════════════════════════════════════
    # 설정 API
    # ═══════════════════════════════════════════════════════════════════

    async def api_keys(request):
        """GET /api/keys | POST /api/keys"""
        if request.method == "GET":
            saved = _load_env_keys()
            return JSONResponse({"keys": saved})

        # POST
        try:
            body = await request.json()
        except Exception:
            err, status = _json_err("JSON 파싱 실패")
            return JSONResponse(err, status_code=status)

        new_keys = body.get("keys", {})
        saved = _load_env_keys()
        saved.update(new_keys)
        saved = {k: v for k, v in saved.items() if v}
        try:
            config_dir.mkdir(parents=True, exist_ok=True)
            _save_env_keys(saved)
            return JSONResponse({"ok": True})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status_code=500)

    async def api_env(request):
        """GET /api/env — 현재 환경 조회 | POST /api/env — 환경 전환"""
        if request.method == "GET":
            return JSONResponse({
                "ok": True,
                "kiwoom_env": os.environ.get("KIWOOM_ENV", "live"),
                "kis_env": os.environ.get("KIS_ENV", "real"),
            })
        # POST
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"ok": False, "error": "JSON 파싱 실패"}, status_code=400)

        changed = {}
        if "kiwoom_env" in body:
            val = body["kiwoom_env"]
            if val in ("live", "mock"):
                os.environ["KIWOOM_ENV"] = val
                changed["KIWOOM_ENV"] = val
        if "kis_env" in body:
            val = body["kis_env"]
            if val in ("real", "demo"):
                os.environ["KIS_ENV"] = val
                changed["KIS_ENV"] = val

        # .env에도 영구 저장
        if changed:
            saved = _load_env_keys()
            saved.update(changed)
            _save_env_keys(saved)

        return JSONResponse({
            "ok": True,
            "kiwoom_env": os.environ.get("KIWOOM_ENV", "live"),
            "kis_env": os.environ.get("KIS_ENV", "real"),
            "token_invalidated": bool(changed),
        })

    async def api_status(request):
        """GET /api/status"""
        active = sum(1 for m in modules_status.values() if m.get("ok"))
        total_tools = sum(
            len(m.get("tools", [])) for m in modules_status.values() if m.get("ok")
        )
        return JSONResponse({
            "ok": True,
            "active_modules": f"{active}/{len(modules_status)}",
            "total_tools": total_tools,
            "config_dir": str(config_dir),
            "modules": modules_status,
        })

    async def api_feeds(request):
        """GET /api/feeds — 피드 카탈로그"""
        catalog_path = _pkg_dir / "data" / "feeds_catalog.json"
        try:
            data = json.loads(catalog_path.read_text("utf-8"))
            return JSONResponse(data)
        except FileNotFoundError:
            return JSONResponse({"ok": False, "error": "feeds_catalog.json을 찾을 수 없습니다"}, status_code=404)
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status_code=500)

    async def api_chart_proxy(request):
        """차트 데이터 프록시 (readinginvestor.com → 로컬)"""
        path = request.path_params.get("path", "")
        query = request.url.query or ""
        target = f"https://readinginvestor.com/api/chart/{path}"
        if query:
            target += f"?{query}"
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.get(target)
                return JSONResponse(resp.json(), status_code=resp.status_code)
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status_code=502)

    async def api_naver_forum(request):
        """GET /api/naver/forum — 네이버 종토방 프록시 (PC HTML 파싱)"""
        import re
        code = request.query_params.get("code", "")
        page = request.query_params.get("page", "1")
        if not code:
            return JSONResponse({"ok": False, "error": "code 파라미터 필요"}, status_code=400)

        target = f"https://finance.naver.com/item/board.naver?code={code}&page={page}"
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.get(target, headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                })
                html = resp.text

                posts = []
                # 게시글 행 파싱: <tr onMouseOver ... > ... </tr>
                rows = re.findall(r'<tr\s+onMouseOver[^>]*>(.*?)</tr>', html, re.DOTALL | re.IGNORECASE)
                for row in rows:
                    # 제목 + nid 추출
                    title_match = re.search(r'nid=(\d+)[^>]*title="([^"]*)"', row)
                    if not title_match:
                        continue
                    nid = title_match.group(1)
                    title = title_match.group(2).strip()

                    # 날짜: 첫 번째 <span class="tah p10 gray03">날짜</span>
                    date_match = re.search(r'class="tah p10 gray03"[^>]*>([^<]+)<', row)
                    date = date_match.group(1).strip() if date_match else ""

                    # 작성자: <td class="p11 로 시작하는 셀 안에서 텍스트 추출
                    writer = ""
                    writer_td = re.search(r'class="p11[^"]*"[^>]*>(.*?)</td>', row, re.DOTALL)
                    if writer_td:
                        # HTML 태그 제거 후 텍스트만
                        writer_text = re.sub(r'<[^>]+>', '', writer_td.group(1)).strip()
                        writer = writer_text

                    # 조회수: 날짜/제목/작성자 이후의 첫 번째 숫자 span
                    # 싫어요/좋아요: strong 태그 안 숫자
                    all_nums = re.findall(r'<(?:span|strong)[^>]*>\s*(\d[\d,]*)\s*</(?:span|strong)>', row)
                    # 날짜를 제외한 순수 숫자만 필터
                    pure_nums = [n for n in all_nums if not re.search(r'\d{4}\.', n)]
                    views = int(pure_nums[0].replace(",", "")) if len(pure_nums) > 0 else 0
                    bad = int(pure_nums[1].replace(",", "")) if len(pure_nums) > 1 else 0
                    good = int(pure_nums[2].replace(",", "")) if len(pure_nums) > 2 else 0

                    posts.append({
                        "title": title,
                        "date": date,
                        "readCount": views,
                        "goodCount": good,
                        "badCount": bad,
                        "writerId": writer,
                        "discussionId": nid,
                    })

                return JSONResponse({"ok": True, "posts": posts, "page": int(page)})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status_code=502)

    # ═══════════════════════════════════════════════════════════════════
    # 라우트 조립
    # ═══════════════════════════════════════════════════════════════════

    routes = [
        # 정적 페이지
        Route("/", page_root),
        Route("/setup", page_setup),
        Route("/settings", page_settings),
        Route("/landing", page_landing),
        Route("/ui/{path:path}", page_ui_static),

        # 차트 프록시
        Route("/api/chart/{path:path}", api_chart_proxy, methods=["GET"]),

        # 네이버 종토방 프록시
        Route("/api/naver/forum", api_naver_forum, methods=["GET"]),

        # 키움증권
        Route("/api/kiwoom/call", api_kiwoom_call, methods=["POST"]),
        Route("/api/kiwoom/list", api_kiwoom_list, methods=["GET"]),
        Route("/api/kiwoom/spec", api_kiwoom_spec, methods=["GET"]),
        Route("/api/kiwoom/condition/list", api_kiwoom_condition_list, methods=["POST"]),
        Route("/api/kiwoom/condition/search", api_kiwoom_condition_search, methods=["POST"]),
        Route("/api/kiwoom/condition/realtime", api_kiwoom_condition_realtime, methods=["POST"]),
        Route("/api/kiwoom/condition/stop", api_kiwoom_condition_stop, methods=["POST"]),

        # DataKit
        Route("/api/datakit/call", api_datakit_call, methods=["POST"]),
        Route("/api/datakit/list", api_datakit_list, methods=["GET"]),

        # KIS (카테고리별 단일 핸들러)
        Route("/api/kis/{category}", api_kis_category, methods=["POST"]),

        # 멤버십 데이터
        Route("/api/membership/call", api_membership_call, methods=["POST"]),
        Route("/api/membership/list", api_membership_list, methods=["GET"]),

        # 뉴스 & 텔레그램
        Route("/api/news/search", api_news_search, methods=["POST"]),
        Route("/api/news/stock", api_news_stock, methods=["POST"]),
        Route("/api/news/db/save", api_news_db_save, methods=["POST"]),
        Route("/api/news/db/history", api_news_db_history, methods=["GET"]),
        Route("/api/news/db/keywords", api_news_db_keywords, methods=["GET"]),
        Route("/api/news/db/delete", api_news_db_delete, methods=["POST"]),
        Route("/api/news/db/delete-all", api_news_db_delete_all, methods=["POST"]),
        Route("/api/telegram", api_telegram, methods=["GET", "POST"]),
        Route("/api/telegram/channels", api_telegram_channels, methods=["GET"]),
        Route("/api/telegram/messages", api_telegram_messages, methods=["POST"]),
        Route("/api/telegram/db/save", api_telegram_db_save, methods=["POST"]),
        Route("/api/telegram/db/messages", api_telegram_db_messages, methods=["GET"]),
        Route("/api/telegram/db/channels", api_telegram_db_channels, methods=["GET"]),
        Route("/api/telegram/db/stats", api_telegram_db_stats, methods=["GET"]),
        Route("/api/telegram/db/delete", api_telegram_db_delete, methods=["POST"]),

        # 설정
        Route("/api/keys", api_keys, methods=["GET", "POST"]),
        Route("/api/env", api_env, methods=["GET", "POST"]),
        Route("/api/status", api_status, methods=["GET"]),
        Route("/api/feeds", api_feeds, methods=["GET"]),
    ]

    # CORS — localhost 오리진만 허용 (보안)
    middleware = [
        Middleware(
            CORSMiddleware,
            allow_origins=[
                "http://localhost",
                "http://127.0.0.1",
                "http://localhost:8200",
                "http://127.0.0.1:8200",
                "http://localhost:8201",
                "http://127.0.0.1:8201",
            ],
            allow_methods=["GET", "POST"],
            allow_headers=["Content-Type", "Authorization"],
        )
    ]

    app = Starlette(routes=routes, middleware=middleware)
    return app
