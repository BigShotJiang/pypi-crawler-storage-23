// StockClaw Kit — Panels (VI, 급등락, 테마, 수급, 순위, 종토방, 프로그램매매, 조건검색)
        // 모든 순위/급증 API에서 공통으로 사용되는 필터 파라미터
        const COMMON_FILTERS = {
            // 시장 구분: 000=전체, 001=코스피, 101=코스닥
            mrkt_tp: '000',
            // 거래소 구분: 1=KRX, 2=NXT, 3=통합
            stex_tp: '3',
            // 종목 조건: 0=전체, 1=관리종목제외, 5=증100제외, 20=ETF+ETN+스팩제외
            stk_cnd: '20',
            // 관리종목 포함: 0=미포함, 1=포함
            mang_stk_incls: '0',
            // 상하한 포함: 0=미포함, 1=포함
            updown_incls: '1',
            // 신용 조건: 0=전체
            crd_cnd: '0',
            // 가격 조건: 0=전체
            pric_cnd: '0',
            // 거래대금 조건: 0=전체
            trde_prica_cnd: '0',
            // 거래량 조건: 0=전체, 0000=전체(4자리)
            trde_qty_cnd: '0',
            trde_qty_cnd_4digit: '0000'
        };

        // 공통 필터 설정 UI 적용 (호출 시 현재 UI 선택값을 COMMON_FILTERS에 반영)
        function applyCommonFiltersFromUI() {
            const stkCndSelect = document.getElementById('commonStkCnd');
            const stexTpSelect = document.getElementById('commonStexTp');
            if (stkCndSelect) COMMON_FILTERS.stk_cnd = stkCndSelect.value;
            if (stexTpSelect) COMMON_FILTERS.stex_tp = stexTpSelect.value;
        }

        // 공통 필터를 API 파라미터에 병합
        function mergeCommonFilters(params) {
            applyCommonFiltersFromUI();
            return { ...params };
        }

        // ==================== 급등락 모니터 (ka10019) ====================
        let surgeAutoRefreshId = null;
        let surgeCountdown = 30;

        // 시간구분 변경 시 단위 텍스트 업데이트
        document.addEventListener('DOMContentLoaded', () => {
            const tmTpSelect = document.getElementById('surgeTmTp');
            if (tmTpSelect) {
                tmTpSelect.addEventListener('change', () => {
                    const unit = tmTpSelect.value === '1' ? '분' : '일';
                    document.getElementById('surgeTmUnit').textContent = unit;
                });
            }
        });

        // ==================== VI 모니터 ====================
        let viMonitorData = [];  // VI 발동 이벤트 저장
        let viPollingTimer = null;

        async function fetchViMonitorData() {
            const tbody = document.getElementById('viTableBody');
            const lastUpdate = document.getElementById('viLastUpdate');
            const btn = document.getElementById('viRefreshBtn');

            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 조회 중...';
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 40px;"><i class="fas fa-spinner fa-spin"></i> VI 데이터 로딩 중...</td></tr>';

            try {
                if (typeof callKiwoom !== 'function') {
                    throw new Error('Kiwoom API가 연결되지 않았습니다. 토큰을 먼저 발급하세요.');
                }

                // ka10054: VI 발동 종목 조회 (stock-diagnosis.js와 동일한 파라미터)
                const result = await callKiwoom('ka10054', {
                    mrkt_tp: '000',
                    bf_mkrt_tp: '1',
                    stk_cd: '',
                    motn_tp: '0',
                    skip_stk: '000000011',
                    trde_qty_tp: '0',
                    min_trde_qty: '0',
                    max_trde_qty: '100000000',
                    trde_prica_tp: '0',
                    min_trde_prica: '0',
                    max_trde_prica: '100000000',
                    motn_drc: '0',
                    stex_tp: '1'
                });

                const viData = result.data?.vi_motn_stk || result.data?.motn_stk;

                if (!result.success || !viData) {
                    throw new Error(result.error || 'VI 데이터를 가져올 수 없습니다.');
                }

                // 종목코드 접미사 제거 (_AL, _NX 등)
                const cleanCode = (code) => (code || '').replace(/_[A-Z]+$/, '').trim();

                // API 응답을 renderViTable이 기대하는 형식으로 매핑
                viMonitorData = viData.map(v => {
                    const code = cleanCode(v.stk_cd || '');

                    // VI 유형 판단 (viaplc_tp 또는 motn_tp 기준)
                    const viType = v.viaplc_tp || v.motn_tp || '';
                    let mappedViType;
                    if (viType.includes('동적') || viType === '2') {
                        mappedViType = 'dynamic';
                    } else {
                        mappedViType = 'static';  // '1', '정적', 그 외 모두 정적
                    }

                    // 방향 판단: VI 발동가 vs 기준가
                    const motnPrc = Math.abs(parseInt(v.motn_pric)) || 0;
                    const stdPrc = Math.abs(parseInt(v.static_stdpc)) || 0;
                    const isUp = motnPrc > stdPrc;

                    // 발동시간 포맷 (HHMMSS → HH:MM:SS)
                    const tm = v.trde_cntr_proc_time || v.motn_tm || '';
                    const timeFormatted = tm.length >= 6
                        ? `${tm.slice(0,2)}:${tm.slice(2,4)}:${tm.slice(4,6)}`
                        : (tm || '');

                    // 시장 구분 (mrkt_div: 1=코스피, 2=코스닥)
                    const market = v.mrkt_div === '1' ? 'kospi' : 'kosdaq';

                    return {
                        code: code,
                        name: v.stk_nm || '',
                        price: motnPrc,
                        changeRate: '',
                        viType: mappedViType,
                        direction: isUp ? 'up' : 'down',
                        time: timeFormatted,
                        market: market
                    };
                });

                lastUpdate.textContent = new Date().toLocaleTimeString('ko-KR');
                addLog(`VI 발동 종목 ${viMonitorData.length}개 조회 완료`, viMonitorData.length > 0 ? 'warning' : 'success');

                // 현재 필터 적용하여 렌더링
                applyViFilter();

            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--danger); padding: 40px;">
                    <i class="fas fa-exclamation-circle" style="font-size: 24px; margin-bottom: 8px; display: block;"></i>
                    ${e.message}
                </td></tr>`;
                addLog('VI 조회 오류: ' + e.message, 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-search"></i> 조회';
            }
        }

        function applyViFilter() {
            // 현재 저장된 VI 데이터에 필터 적용
            const marketFilter = document.querySelector('input[name="viMarket"]:checked')?.value || 'all';
            const typeFilter = document.querySelector('input[name="viType"]:checked')?.value || 'all';
            const directionFilter = document.querySelector('input[name="viDirection"]:checked')?.value || 'all';

            let filtered = [...viMonitorData];

            if (marketFilter !== 'all') {
                filtered = filtered.filter(item => item.market === marketFilter);
            }
            if (typeFilter !== 'all') {
                filtered = filtered.filter(item => item.viType === typeFilter);
            }
            if (directionFilter !== 'all') {
                filtered = filtered.filter(item => item.direction === directionFilter);
            }

            renderViTable(filtered);
        }

        function renderViTable(items) {
            const tbody = document.getElementById('viTableBody');
            if (!items || items.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 40px;">VI 발동 데이터가 없습니다</td></tr>';
                return;
            }
            tbody.innerHTML = items.map((item) => {
                const dirColor = item.direction === 'up' ? 'var(--danger)' : 'var(--success)';
                const viTypeLabel = item.viType === 'static' ? '정적' : '동적';
                const dirLabel = item.direction === 'up' ? '상승' : '하락';
                return `<tr>
                    <td style="text-align: center; font-family: monospace;">${item.time || ''}</td>
                    <td>${escapeHtml(item.name || '')}</td>
                    <td style="text-align: center; font-family: monospace;">${item.code || ''}</td>
                    <td style="text-align: center;">${viTypeLabel} <span style="color: ${dirColor};">${dirLabel}</span></td>
                    <td style="text-align: right;">${(item.price || 0).toLocaleString()}</td>
                    <td style="text-align: right; color: ${dirColor};">${item.changeRate || '-'}</td>
                </tr>`;
            }).join('');
        }

        // 급등락 종목 조회
        async function fetchSurgeStocks() {
            const statusLabel = document.getElementById('surgeStatusLabel');
            const tbody = document.getElementById('surgeTableBody');

            // 연결 확인
            if (!isConnected || !kiwoomAPI) {
                alert('Kiwoom API가 연결되지 않았습니다. 토큰을 먼저 발급하세요.');
                return;
            }

            // 필터 값 수집
            const mrkt_tp = document.querySelector('input[name="surgeMrkt"]:checked')?.value || '000';
            const flu_tp = document.querySelector('input[name="surgeFlu"]:checked')?.value || '1';
            const tm_tp = document.getElementById('surgeTmTp')?.value || '1';
            const tm = document.getElementById('surgeTm')?.value || '60';
            const pric_cnd = document.getElementById('surgePricCnd')?.value || '8';

            statusLabel.textContent = '조회 중...';
            statusLabel.style.color = 'var(--accent)';
            tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px;"><i class="fas fa-spinner fa-spin"></i> 데이터 로딩 중...</td></tr>';

            try {
                const result = await callKiwoom('surgeStocks', {
                    mrkt_tp,
                    flu_tp,
                    tm_tp,
                    tm,
                    trde_qty_tp: '0000',
                    stk_cnd: '0',
                    crd_cnd: '0',
                    pric_cnd,
                    updown_incls: '1',
                    stex_tp: '1'
                });
                console.log('[급등락] 응답:', result);

                if (result.success && result.data) {
                    const items = result.data.pric_jmpflu || [];
                    renderSurgeTable(items, flu_tp);
                    statusLabel.textContent = `${items.length}건 조회 완료`;
                    statusLabel.style.color = 'var(--success)';
                    addLog(`급등락 모니터: ${items.length}건 조회 (${flu_tp === '1' ? '급등' : '급락'})`, 'success');
                } else {
                    throw new Error(result.error || 'API 오류');
                }
            } catch (e) {
                console.error('[급등락] 오류:', e);
                statusLabel.textContent = '조회 실패';
                statusLabel.style.color = 'var(--danger)';
                tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--danger); padding: 40px;">
                    조회 실패: ${escapeHtml(e.message)}
                </td></tr>`;
                addLog(`급등락 모니터 오류: ${e.message}`, 'error');
            }
        }

        // 급등락 테이블 렌더링
        function renderSurgeTable(items, flu_tp) {
            const tbody = document.getElementById('surgeTableBody');

            if (!items || items.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 40px;">조회 결과가 없습니다</td></tr>';
                return;
            }

            const isUp = flu_tp === '1';
            tbody.innerHTML = items.map((item, idx) => {
                const stockCode = item.stk_cd || '';
                const stockName = item.stk_nm || '';
                const curPrice = parseInt(item.cur_prc || 0);
                const fluRt = parseFloat(item.flu_rt || 0);
                const jmpRt = parseFloat(item.jmp_rt || 0);
                const volume = parseInt(item.trde_qty || 0);

                const priceColor = fluRt > 0 ? 'var(--danger)' : fluRt < 0 ? 'var(--success)' : 'var(--text)';
                const jmpColor = isUp ? 'var(--danger)' : '#3b82f6';

                return `<tr style="cursor: pointer;" onclick="openSurgeChart('${escapeHtml(stockCode)}', '${escapeHtml(stockName)}')">
                    <td style="text-align: center;">${idx + 1}</td>
                    <td style="font-family: monospace;">${stockCode}</td>
                    <td style="font-weight: 500;">${stockName}</td>
                    <td style="text-align: right; font-family: monospace;">${curPrice.toLocaleString()}</td>
                    <td style="text-align: right; color: ${priceColor}; font-weight: 500;">${fluRt > 0 ? '+' : ''}${fluRt.toFixed(2)}%</td>
                    <td style="text-align: right; color: ${jmpColor}; font-weight: 600;">${jmpRt > 0 ? '+' : ''}${jmpRt.toFixed(2)}%</td>
                    <td style="text-align: right; font-family: monospace;">${formatVolume(volume)}</td>
                    <td style="text-align: center;">
                        <button class="btn" style="padding: 4px 8px; font-size: 11px;" onclick="event.stopPropagation(); openSurgeChart('${escapeHtml(stockCode)}', '${escapeHtml(stockName)}')">
                            <i class="fas fa-chart-line"></i>
                        </button>
                    </td>
                </tr>`;
            }).join('');
        }

        // 거래량 포맷
        function formatVolume(vol) {
            if (vol >= 100000000) return (vol / 100000000).toFixed(1) + '억';
            if (vol >= 10000) return (vol / 10000).toFixed(0) + '만';
            if (vol >= 1000) return (vol / 1000).toFixed(1) + 'K';
            return vol.toLocaleString();
        }

        // 공통 차트 열기 함수
        function openChartWithStock(stockCode, stockName, chartType = 'daily') {
            // 차트 패널로 전환
            document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
            document.querySelector('.menu-item[data-panel="chart"]').classList.add('active');
            document.querySelectorAll('.content-panel').forEach(panel => panel.classList.remove('active'));
            document.getElementById('panel-chart').classList.add('active');

            // 종목코드 입력창 설정
            const chartStockInput = document.getElementById('chartStockCode');
            if (chartStockInput) {
                chartStockInput.value = stockCode;
            }

            // 차트 매니저 초기화 및 로드
            (async () => {
                await initChartManager();
                if (chartManager) {
                    chartManager.loadChart(stockCode, chartType, stockName);
                }
                addLog(`차트 이동: ${stockName} (${stockCode})`, 'info');
            })();
        }

        // 급등락 차트 열기 -> 종목 상세로 이동
        function openSurgeChart(stockCode, stockName) {
            openStockDetailTab(stockCode, stockName);
        }

        // 자동 갱신 토글
        function toggleSurgeAutoRefresh() {
            const checkbox = document.getElementById('surgeAutoRefresh');
            const label = document.getElementById('surgeRefreshLabel');

            if (checkbox.checked) {
                surgeCountdown = 30;
                label.textContent = `다음 갱신: ${surgeCountdown}초`;
                surgeAutoRefreshId = setInterval(() => {
                    surgeCountdown--;
                    if (surgeCountdown <= 0) {
                        fetchSurgeStocks();
                        surgeCountdown = 30;
                    }
                    label.textContent = `다음 갱신: ${surgeCountdown}초`;
                }, 1000);
                addLog('급등락 모니터 자동갱신 시작 (30초)', 'info');
            } else {
                if (surgeAutoRefreshId) {
                    clearInterval(surgeAutoRefreshId);
                    surgeAutoRefreshId = null;
                }
                label.textContent = '-';
                addLog('급등락 모니터 자동갱신 중지', 'info');
            }
        }

        // ==================== 거래량 급증 (ka10023) ====================
        let volumeAutoRefreshId = null;
        let volumeCountdown = 30;

        // 전체 조회 함수 (2x2 그리드 전체 갱신)
        function fetchAllVolumeGridPanels() {
            const statusLabel = document.getElementById('volumeStatusLabel');
            statusLabel.textContent = '전체 조회 중...';
            statusLabel.style.color = 'var(--accent)';

            // 모든 패널 동시 조회
            Promise.all([
                fetchVolumeSurge(),
                fetchTradingAmount(),
                fetchChangeRate(),
                fetchExpectedRate()
            ]).then(() => {
                statusLabel.textContent = '전체 조회 완료';
                statusLabel.style.color = 'var(--success)';
            }).catch(() => {
                statusLabel.textContent = '일부 조회 실패';
                statusLabel.style.color = 'var(--warning)';
            });
        }

        // 거래대금상위 조회 (ka10032) - 2x2 그리드용
        async function fetchTradingAmount() {
            const tbody = document.getElementById('tradingAmtTableBody');
            tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin"></i></td></tr>`;

            try {
                applyCommonFiltersFromUI();
                const mrkt_tp = document.getElementById('tradingAmtMrktSelect')?.value || COMMON_FILTERS.mrkt_tp;

                const result = await callKiwoom('ka10032', {
                    mrkt_tp,
                    mang_stk_incls: COMMON_FILTERS.mang_stk_incls,
                    stex_tp: COMMON_FILTERS.stex_tp
                });
                if (result.success && result.data) {
                    const items = result.data.trde_prica_upper || [];
                    renderTradingAmtTableCompact(items);
                    addLog(`거래대금상위: ${items.length}건`, 'success');
                } else {
                    throw new Error(result.error || 'API 오류');
                }
            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--danger); padding: 20px;">${escapeHtml(e.message)}</td></tr>`;
            }
        }

        // 거래대금상위 테이블 렌더링 (컴팩트 2x2 그리드용)
        function renderTradingAmtTableCompact(items) {
            const tbody = document.getElementById('tradingAmtTableBody');
            if (!items?.length) { tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 20px;">데이터 없음</td></tr>`; return; }

            const html = items.slice(0, 30).map((item, i) => {
                const stkCd = item.stk_cd || '';
                const stkNm = item.stk_nm || '';
                const curPrc = Math.abs(parseInt(item.cur_prc) || 0);
                const fluRt = parseFloat(item.flu_rt) || 0;
                const fluRtColor = fluRt > 0 ? 'var(--success)' : fluRt < 0 ? 'var(--danger)' : 'var(--text-muted)';
                const trdePrica = parseInt(item.trde_prica) || 0;
                // trde_prica 단위: 백만원 → 억 단위로 표시 (/ 100)
                const trdePricaBillion = Math.round(trdePrica / 100);

                return `<tr style="cursor: pointer;" onclick="openStockDetailTab('${stkCd}', '${stkNm}')">
                    <td style="text-align: center; padding: 3px;">${i + 1}</td>
                    <td style="padding: 3px; max-width: 80px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${stkNm}</td>
                    <td style="text-align: right; padding: 3px;">${curPrc.toLocaleString()}</td>
                    <td style="text-align: right; padding: 3px; color: ${fluRtColor};">${fluRt > 0 ? '+' : ''}${fluRt.toFixed(2)}%</td>
                    <td style="text-align: right; padding: 3px; color: #f59e0b;">${trdePricaBillion.toLocaleString()}억</td>
                </tr>`;
            }).join('');
            tbody.innerHTML = html;
        }

        // 전일대비등락률상위 조회 (ka10027) - 2x2 그리드용
        async function fetchChangeRate() {
            const tbody = document.getElementById('changeRateTableBody');
            tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin"></i></td></tr>`;

            try {
                applyCommonFiltersFromUI();
                const sort_tp = document.getElementById('changeRateSortTp')?.value || '1';

                const result = await callKiwoom('ka10027', {
                    mrkt_tp: COMMON_FILTERS.mrkt_tp,
                    sort_tp,
                    trde_qty_cnd: COMMON_FILTERS.trde_qty_cnd_4digit,
                    stk_cnd: COMMON_FILTERS.stk_cnd,
                    crd_cnd: COMMON_FILTERS.crd_cnd,
                    updown_incls: COMMON_FILTERS.updown_incls,
                    pric_cnd: COMMON_FILTERS.pric_cnd,
                    trde_prica_cnd: COMMON_FILTERS.trde_prica_cnd,
                    stex_tp: COMMON_FILTERS.stex_tp
                });
                if (result.success && result.data) {
                    const items = result.data.pred_pre_flu_rt_upper || [];
                    renderChangeRateTableCompact(items);
                    addLog(`등락률상위: ${items.length}건`, 'success');
                } else {
                    throw new Error(result.error || 'API 오류');
                }
            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--danger); padding: 20px;">${escapeHtml(e.message)}</td></tr>`;
            }
        }

        // 등락률상위 테이블 렌더링 (컴팩트 2x2 그리드용)
        function renderChangeRateTableCompact(items) {
            const tbody = document.getElementById('changeRateTableBody');
            if (!items?.length) { tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 20px;">데이터 없음</td></tr>`; return; }

            const html = items.slice(0, 30).map((item, i) => {
                const stkCd = item.stk_cd || '';
                const stkNm = item.stk_nm || '';
                const curPrc = Math.abs(parseInt(item.cur_prc) || 0);
                const fluRt = parseFloat(item.flu_rt) || 0;
                const fluRtColor = fluRt > 0 ? 'var(--success)' : fluRt < 0 ? 'var(--danger)' : 'var(--text-muted)';
                const nowTrdeQty = parseInt(item.now_trde_qty) || 0;

                return `<tr style="cursor: pointer;" onclick="openStockDetailTab('${stkCd}', '${stkNm}')">
                    <td style="text-align: center; padding: 3px;">${i + 1}</td>
                    <td style="padding: 3px; max-width: 80px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${stkNm}</td>
                    <td style="text-align: right; padding: 3px;">${curPrc.toLocaleString()}</td>
                    <td style="text-align: right; padding: 3px; color: ${fluRtColor}; font-weight: 600;">${fluRt > 0 ? '+' : ''}${fluRt.toFixed(2)}%</td>
                    <td style="text-align: right; padding: 3px;">${formatVolume(nowTrdeQty)}</td>
                </tr>`;
            }).join('');
            tbody.innerHTML = html;
        }

        // 예상체결등락률상위 조회 (ka10029) - 2x2 그리드용
        async function fetchExpectedRate() {
            const tbody = document.getElementById('expectedRateTableBody');
            tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin"></i></td></tr>`;

            try {
                applyCommonFiltersFromUI();
                const sort_tp = document.getElementById('expectedRateSortTp')?.value || '1';

                const result = await callKiwoom('ka10029', {
                    mrkt_tp: COMMON_FILTERS.mrkt_tp,
                    sort_tp,
                    trde_qty_cnd: COMMON_FILTERS.trde_qty_cnd,
                    stk_cnd: COMMON_FILTERS.stk_cnd,
                    crd_cnd: COMMON_FILTERS.crd_cnd,
                    pric_cnd: COMMON_FILTERS.pric_cnd,
                    stex_tp: COMMON_FILTERS.stex_tp
                });
                if (result.success && result.data) {
                    const items = result.data.exp_cntr_flu_rt_upper || [];
                    renderExpectedRateTableCompact(items);
                    addLog(`예상체결등락률: ${items.length}건`, 'success');
                } else {
                    throw new Error(result.error || 'API 오류');
                }
            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 20px;">장 전/후 조회</td></tr>`;
            }
        }

        // 예상체결등락률 테이블 렌더링 (컴팩트 2x2 그리드용)
        function renderExpectedRateTableCompact(items) {
            const tbody = document.getElementById('expectedRateTableBody');
            if (!items?.length) { tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 20px;">데이터 없음</td></tr>`; return; }

            const html = items.slice(0, 30).map((item, i) => {
                const stkCd = item.stk_cd || '';
                const stkNm = item.stk_nm || '';
                const expCntrPric = Math.abs(parseInt(item.exp_cntr_pric) || 0);
                const fluRt = parseFloat(item.flu_rt) || 0;
                const fluRtColor = fluRt > 0 ? 'var(--success)' : fluRt < 0 ? 'var(--danger)' : 'var(--text-muted)';
                const expCntrQty = parseInt(item.exp_cntr_qty) || 0;

                return `<tr style="cursor: pointer;" onclick="openStockDetailTab('${stkCd}', '${stkNm}')">
                    <td style="text-align: center; padding: 3px;">${i + 1}</td>
                    <td style="padding: 3px; max-width: 80px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${stkNm}</td>
                    <td style="text-align: right; padding: 3px;">${expCntrPric.toLocaleString()}</td>
                    <td style="text-align: right; padding: 3px; color: ${fluRtColor}; font-weight: 600;">${fluRt > 0 ? '+' : ''}${fluRt.toFixed(2)}%</td>
                    <td style="text-align: right; padding: 3px;">${formatVolume(expCntrQty)}</td>
                </tr>`;
            }).join('');
            tbody.innerHTML = html;
        }

        // 거래량 급증 종목 조회 - 2x2 그리드용
        async function fetchVolumeSurge() {
            const tbody = document.getElementById('volumeTableBody');
            tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin"></i></td></tr>`;

            try {
                applyCommonFiltersFromUI();
                const sort_tp = document.getElementById('volumeSortTp')?.value || '2';

                const result = await callKiwoom('volumeSurge', {
                    mrkt_tp: COMMON_FILTERS.mrkt_tp,
                    sort_tp,
                    tm_tp: '2',
                    trde_qty_tp: '5',
                    stk_cnd: COMMON_FILTERS.stk_cnd,
                    pric_tp: '8',
                    stex_tp: COMMON_FILTERS.stex_tp
                });
                if (result.success && result.data) {
                    const items = result.data.trde_qty_sdnin || [];
                    renderVolumeTableCompact(items, sort_tp);
                    addLog(`거래량급증: ${items.length}건`, 'success');
                } else {
                    throw new Error(result.error || 'API 오류');
                }
            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--danger); padding: 20px;">${escapeHtml(e.message)}</td></tr>`;
            }
        }

        // 거래량 급증 테이블 렌더링 (컴팩트 2x2 그리드용)
        function renderVolumeTableCompact(items, sort_tp) {
            const tbody = document.getElementById('volumeTableBody');
            if (!items?.length) { tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 20px;">데이터 없음</td></tr>`; return; }

            const html = items.slice(0, 30).map((item, i) => {
                const curPrc = Math.abs(parseInt(item.cur_prc) || 0);
                const fluRt = parseFloat(item.flu_rt) || 0;
                const fluRtColor = fluRt > 0 ? 'var(--success)' : fluRt < 0 ? 'var(--danger)' : 'var(--text-muted)';
                const sdninRt = parseFloat(item.sdnin_rt) || 0;
                const isIncrease = sort_tp === '1' || sort_tp === '2';
                const sdninColor = isIncrease ? 'var(--success)' : 'var(--danger)';

                return `<tr style="cursor: pointer;" onclick="openStockDetailTab('${item.stk_cd}', '${item.stk_nm}')">
                    <td style="text-align: center; padding: 3px;">${i + 1}</td>
                    <td style="padding: 3px; max-width: 80px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${item.stk_nm}</td>
                    <td style="text-align: right; padding: 3px;">${curPrc.toLocaleString()}</td>
                    <td style="text-align: right; padding: 3px; color: ${fluRtColor};">${fluRt > 0 ? '+' : ''}${fluRt.toFixed(2)}%</td>
                    <td style="text-align: right; padding: 3px; color: ${sdninColor}; font-weight: 600;">${sdninRt > 0 ? '+' : ''}${sdninRt.toFixed(0)}%</td>
                </tr>`;
            }).join('');
            tbody.innerHTML = html;
        }

        // 거래량 급증 차트 열기 -> 종목 상세로 이동
        function openVolumeChart(stockCode, stockName) {
            openStockDetailTab(stockCode, stockName);
        }

        // 거래량/시세 자동갱신 토글 (2x2 그리드 전체 갱신)
        function toggleVolumeAutoRefresh() {
            const checkbox = document.getElementById('volumeAutoRefresh');
            const label = document.getElementById('volumeRefreshLabel');

            if (checkbox.checked) {
                volumeCountdown = 30;
                fetchAllVolumeGridPanels();  // 전체 조회
                volumeAutoRefreshId = setInterval(() => {
                    volumeCountdown--;
                    if (volumeCountdown <= 0) {
                        fetchAllVolumeGridPanels();  // 전체 조회
                        volumeCountdown = 30;
                    }
                    label.textContent = `다음 갱신: ${volumeCountdown}초`;
                }, 1000);
                addLog('거래량/시세 2x2 자동갱신 시작 (30초)', 'info');
            } else {
                if (volumeAutoRefreshId) {
                    clearInterval(volumeAutoRefreshId);
                    volumeAutoRefreshId = null;
                }
                label.textContent = '-';
                addLog('거래량/시세 자동갱신 중지', 'info');
            }
        }

        // ==================== 테마 분석 (ka90001 + ka90002) ====================
        let themeGroups = [];  // 테마 목록 저장

        // 테마 그룹 조회
        async function fetchThemeGroups() {
            const statusLabel = document.getElementById('themeStatusLabel');
            const tbody = document.getElementById('themeTableBody');

            statusLabel.textContent = '조회 중...';
            statusLabel.style.color = 'var(--accent)';
            tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 40px;">
                <i class="fas fa-spinner fa-spin"></i> 로딩 중...
            </td></tr>`;

            try {
                const flu_pl_amt_tp = document.getElementById('themeFluPlAmtTp').value;
                const date_tp = document.getElementById('themeDateTp').value;
                const thema_nm = document.getElementById('themeSearchName').value.trim();

                // themeGroups API 파라미터 전달
                const result = await callKiwoom('themeGroups', {
                    qry_tp: thema_nm ? '1' : '0',  // 테마명 검색 시 1, 전체 조회 시 0
                    date_tp: date_tp || '1',
                    thema_nm: thema_nm || '',
                    flu_pl_amt_tp: flu_pl_amt_tp || '3',
                    stex_tp: '1'
                });

                if (result.success && result.data) {
                    themeGroups = result.data.thema_grp || [];
                    renderThemeTable(themeGroups);
                    statusLabel.textContent = `${themeGroups.length}개 테마 조회 완료`;
                    statusLabel.style.color = 'var(--success)';
                    addLog(`테마 분석: ${themeGroups.length}개 테마 조회`, 'success');
                } else {
                    throw new Error(result.error || 'API 오류');
                }
            } catch (e) {
                statusLabel.textContent = '조회 실패';
                statusLabel.style.color = 'var(--danger)';
                tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--danger); padding: 40px;">
                    조회 실패: ${escapeHtml(e.message)}
                </td></tr>`;
                addLog(`테마 분석 오류: ${e.message}`, 'error');
            }
        }

        // 테마 목록 테이블 렌더링
        function renderThemeTable(items) {
            const tbody = document.getElementById('themeTableBody');

            if (!items || items.length === 0) {
                tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 40px;">
                    데이터가 없습니다
                </td></tr>`;
                return;
            }

            const html = items.map((item, index) => {
                const fluRt = parseFloat(item.flu_rt) || 0;
                const fluRtColor = fluRt > 0 ? 'var(--success)' : fluRt < 0 ? 'var(--danger)' : 'var(--text-muted)';
                const fluRtSign = fluRt > 0 ? '+' : '';

                const dtPrftRt = parseFloat(item.dt_prft_rt) || 0;
                const dtPrftRtColor = dtPrftRt > 0 ? 'var(--success)' : dtPrftRt < 0 ? 'var(--danger)' : 'var(--text-muted)';
                const dtPrftRtSign = dtPrftRt > 0 ? '+' : '';

                return `
                    <tr style="cursor: pointer;" onclick="selectTheme('${item.thema_grp_cd}', '${item.thema_nm}')">
                        <td style="text-align: center;">${index + 1}</td>
                        <td style="font-weight: 500;">${item.thema_nm || '-'}</td>
                        <td style="text-align: center;">${item.stk_num || '-'}</td>
                        <td style="text-align: right; color: ${fluRtColor};">${fluRtSign}${fluRt.toFixed(2)}%</td>
                        <td style="text-align: center; color: var(--success);">${item.rising_stk_num || 0}</td>
                        <td style="text-align: center; color: var(--danger);">${item.fall_stk_num || 0}</td>
                        <td style="text-align: right; color: ${dtPrftRtColor};">${dtPrftRtSign}${dtPrftRt.toFixed(2)}%</td>
                    </tr>
                `;
            }).join('');

            tbody.innerHTML = html;
        }

        // 테마 선택 → 구성 종목 조회
        async function selectTheme(themaGrpCd, themaNm) {
            const titleEl = document.getElementById('themeStocksTitle');
            const tbody = document.getElementById('themeStocksTableBody');

            titleEl.textContent = `구성 종목: ${themaNm}`;
            tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 40px;">
                <i class="fas fa-spinner fa-spin"></i> 로딩 중...
            </td></tr>`;

            try {
                const result = await callKiwoom('themeStocks', {thema_grp_cd: themaGrpCd, stex_tp: '1'});

                if (result.success && result.data) {
                    // API 응답 필드명: thema_comp_stk
                    const stocks = result.data.thema_comp_stk || [];
                    renderThemeStocksTable(stocks);
                    addLog(`테마 종목: ${themaNm} - ${stocks.length}개`, 'success');
                } else {
                    throw new Error(result.error || 'API 오류');
                }
            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--danger); padding: 40px;">
                    조회 실패: ${escapeHtml(e.message)}
                </td></tr>`;
                addLog(`테마 종목 오류: ${e.message}`, 'error');
            }
        }

        // 테마 구성 종목 테이블 렌더링
        function renderThemeStocksTable(items) {
            const tbody = document.getElementById('themeStocksTableBody');

            if (!items || items.length === 0) {
                tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 40px;">
                    종목이 없습니다
                </td></tr>`;
                return;
            }

            const html = items.map((item, index) => {
                const curPrc = parseInt(item.cur_prc) || 0;
                const absPrice = Math.abs(curPrc);
                const priceColor = curPrc < 0 ? 'var(--danger)' : 'var(--text)';

                const fluRt = parseFloat(item.flu_rt) || 0;
                const fluRtColor = fluRt > 0 ? 'var(--success)' : fluRt < 0 ? 'var(--danger)' : 'var(--text-muted)';
                const fluRtSign = fluRt > 0 ? '+' : '';

                const trdeQty = parseInt(item.acc_trde_qty) || 0;

                return `
                    <tr style="cursor: pointer;" onclick="openThemeChart('${item.stk_cd}', '${item.stk_nm}')">
                        <td style="text-align: center;">${index + 1}</td>
                        <td style="font-family: monospace;">${item.stk_cd || '-'}</td>
                        <td style="font-weight: 500;">${item.stk_nm || '-'}</td>
                        <td style="text-align: right; color: ${priceColor};">${absPrice.toLocaleString()}</td>
                        <td style="text-align: right; color: ${fluRtColor};">${fluRtSign}${fluRt.toFixed(2)}%</td>
                        <td style="text-align: right;">${trdeQty.toLocaleString()}</td>
                        <td style="text-align: center;">
                            <button class="btn btn-sm" style="padding: 2px 8px; font-size: 11px;" onclick="event.stopPropagation(); openThemeChart('${item.stk_cd}', '${item.stk_nm}')">
                                <i class="fas fa-chart-line"></i>
                            </button>
                        </td>
                    </tr>
                `;
            }).join('');

            tbody.innerHTML = html;
        }

        // 테마 종목 차트 열기 -> 종목 상세로 이동
        function openThemeChart(stockCode, stockName) {
            openStockDetailTab(stockCode, stockName);
        }

        // 실시간 순위 차트 열기 (조건검색 편입/이탈) -> 종목 상세로 이동
        function openRealtimeChart(stockCode, stockName) {
            openStockDetailTab(stockCode, stockName);
        }

        // 실시간 종목 조회 순위 차트 열기 -> 종목 상세로 이동
        function openRankChart(stockCode, stockName) {
            openStockDetailTab(stockCode, stockName);
        }

        // 수급 분석 차트 열기 -> 종목 상세로 이동
        function openSupplyChart(stockCode, stockName) {
            openStockDetailTab(stockCode, stockName);
        }

        // ==================== 수급 분석 (ka90009: 외국인 + ka10065: 기관 장중) ====================
        async function fetchSupplyDemand() {
            const statusEl = document.getElementById('supplyStatus');
            const mrktTp = document.getElementById('supplyMrktTp').value;
            const amtQtyTp = document.getElementById('supplyAmtQtyTp').value;

            statusEl.textContent = '조회 중...';
            statusEl.style.color = 'var(--accent)';

            try {
                // 수급 데이터 조회 (ka90009)
                const result = await callKiwoom('supplyDemand', {
                    mrkt_tp: mrktTp,       // 시장구분: 000:전체, 001:코스피, 101:코스닥
                    amt_qty_tp: amtQtyTp,  // 1:금액(천만), 2:수량(천)
                    qry_dt_tp: '1',        // 조회일자 포함
                    stex_tp: '1'           // 1:KRX
                });

                // ka90009 응답에서 외국인+기관 데이터 모두 렌더링
                if (result.success && result.data && result.data.frgnr_orgn_trde_upper) {
                    const items = result.data.frgnr_orgn_trde_upper;

                    // 외국인 테이블 (for_netprps: 순매수, for_netslmt: 순매도)
                    renderSupplyTable('foreignBuyTable', items, 'for_netprps', amtQtyTp);
                    renderSupplyTable('foreignSellTable', items, 'for_netslmt', amtQtyTp);

                    // 기관 테이블 (orgn_netprps: 순매수, orgn_netslmt: 순매도)
                    renderSupplyTable('institutionBuyTable', items, 'orgn_netprps', amtQtyTp);
                    renderSupplyTable('institutionSellTable', items, 'orgn_netslmt', amtQtyTp);
                } else {
                    const emptyMsg = '<tr><td colspan="4" class="empty-state">데이터 없음</td></tr>';
                    document.querySelector('#foreignBuyTable tbody').innerHTML = emptyMsg;
                    document.querySelector('#foreignSellTable tbody').innerHTML = emptyMsg;
                    document.querySelector('#institutionBuyTable tbody').innerHTML = emptyMsg;
                    document.querySelector('#institutionSellTable tbody').innerHTML = emptyMsg;
                }

                statusEl.textContent = '조회 완료';
                statusEl.style.color = 'var(--success)';
                addLog(`수급 분석 완료`, 'success');
            } catch (e) {
                statusEl.textContent = '조회 실패';
                statusEl.style.color = 'var(--danger)';
                addLog(`수급 분석 오류: ${e.message}`, 'error');
            }
        }

        // 수급/프로그램 탭 전환
        function switchSupplyTab(tab) {
            // 탭 버튼 스타일
            document.querySelectorAll('.supply-tab-btn').forEach(btn => {
                if (btn.dataset.tab === tab) {
                    btn.style.background = 'var(--accent)';
                    btn.style.color = 'white';
                } else {
                    btn.style.background = 'transparent';
                    btn.style.color = 'var(--text-muted)';
                }
            });

            // 필터 표시/숨김
            document.getElementById('supplyFilters').style.display = tab === 'foreign-inst' ? 'flex' : 'none';
            document.getElementById('programFilters').style.display = tab === 'program' ? 'flex' : 'none';

            // 탭 컨텐츠 표시/숨김
            document.getElementById('supplyTabForeignInst').style.display = tab === 'foreign-inst' ? 'block' : 'none';
            document.getElementById('supplyTabProgram').style.display = tab === 'program' ? 'block' : 'none';
        }

        // 시세 모니터 탭 전환
        function switchMarketTab(tab) {
            // 탭 버튼 스타일
            document.querySelectorAll('.market-tab-btn').forEach(btn => {
                if (btn.dataset.tab === tab) {
                    btn.style.background = 'var(--accent)';
                    btn.style.color = 'white';
                } else {
                    btn.style.background = 'transparent';
                    btn.style.color = 'var(--text-muted)';
                }
            });

            // 필터 표시/숨김
            document.getElementById('gridFilters').style.display = tab === 'grid' ? 'flex' : 'none';
            document.getElementById('surgeFilters').style.display = tab === 'surge' ? 'flex' : 'none';
            document.getElementById('realtimeFilters').style.display = tab === 'realtime' ? 'flex' : 'none';

            // 탭 컨텐츠 표시/숨김
            document.getElementById('marketTabGrid').style.display = tab === 'grid' ? 'block' : 'none';
            document.getElementById('marketTabSurge').style.display = tab === 'surge' ? 'block' : 'none';
            document.getElementById('marketTabRealtime').style.display = tab === 'realtime' ? 'block' : 'none';

            // 탭 전환 시 해당 데이터 자동 조회
            if (tab === 'surge') {
                fetchSurgeStocksForMarketTab();
            } else if (tab === 'realtime') {
                fetchRealtimeRankForMarketTab();
            }
        }

        // 급등락 조회 (시세 모니터 탭용)
        async function fetchSurgeStocksForMarketTab() {
            const tbody = document.getElementById('surgeStocksTableBody');
            const fluTp = document.getElementById('surgeSortTp')?.value || '1';

            tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px;"><i class="fas fa-spinner fa-spin"></i></td></tr>';

            try {
                const result = await callKiwoom('surgeStocks', {
                    mrkt_tp: '000',
                    flu_tp: fluTp,
                    tm_tp: '1',
                    tm: '60',
                    trde_qty_tp: '0000',
                    stk_cnd: COMMON_FILTERS.stk_cnd,
                    crd_cnd: '0',
                    pric_cnd: '8',
                    updown_incls: '1',
                    stex_tp: COMMON_FILTERS.stex_tp
                });
                if (result.success && result.data?.pric_jmpflu) {
                    const items = result.data.pric_jmpflu.slice(0, 50);
                    const isUp = fluTp === '1';
                    tbody.innerHTML = items.map((item, i) => {
                        const stkCd = item.stk_cd || '';
                        const stkNm = item.stk_nm || '';
                        const curPrc = parseInt(item.cur_prc || 0);
                        const fluRt = parseFloat(item.flu_rt || 0);
                        const vol = parseInt(item.trde_qty || 0);
                        const amt = parseInt(item.trde_prica || 0);
                        const priceColor = fluRt > 0 ? 'var(--success)' : fluRt < 0 ? 'var(--danger)' : 'var(--text-muted)';
                        return `<tr style="cursor: pointer;" onclick="openStockDetailTab('${escapeHtml(stkCd)}', '${escapeHtml(stkNm)}')">
                            <td style="text-align: center;">${i + 1}</td>
                            <td style="font-family: monospace; font-size: 11px;">${stkCd}</td>
                            <td style="max-width: 80px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${stkNm}</td>
                            <td style="text-align: right; font-family: monospace;">${curPrc.toLocaleString()}</td>
                            <td style="text-align: right; color: ${priceColor}; font-weight: 600;">${fluRt > 0 ? '+' : ''}${fluRt.toFixed(2)}%</td>
                            <td style="text-align: right;">${formatVolume(vol)}</td>
                            <td style="text-align: right;">${Math.round(amt / 100).toLocaleString()}억</td>
                        </tr>`;
                    }).join('');
                    addLog(`급등락 ${items.length}건`, 'success');
                } else {
                    tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 40px;">데이터 없음</td></tr>';
                }
            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--danger); padding: 40px;">${escapeHtml(e.message)}</td></tr>`;
            }
        }

        // 실시간순위 조회 (시세 모니터 탭용) - 5개 시간대 동시 조회
        async function fetchRealtimeRankForMarketTab() {
            const timeFrames = [
                { qry: '5', bodyId: 'realtimeRank30sBody', label: '30초' },
                { qry: '1', bodyId: 'realtimeRank1mBody', label: '1분' },
                { qry: '2', bodyId: 'realtimeRank10mBody', label: '10분' },
                { qry: '3', bodyId: 'realtimeRank1hBody', label: '1시간' },
                { qry: '4', bodyId: 'realtimeRankDayBody', label: '당일' }
            ];

            // 로딩 상태 표시
            timeFrames.forEach(tf => {
                const tbody = document.getElementById(tf.bodyId);
                if (tbody) tbody.innerHTML = '<tr><td style="text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin"></i></td></tr>';
            });

            const host = localStorage.getItem('kiwoom_host') || 'https://api.kiwoom.com';
            const token = localStorage.getItem('kiwoom_token');
            if (!token) {
                timeFrames.forEach(tf => {
                    const tbody = document.getElementById(tf.bodyId);
                    if (tbody) tbody.innerHTML = '<tr><td style="text-align: center; color: var(--danger); padding: 20px;">토큰 없음</td></tr>';
                });
                return;
            }

            // 병렬 조회
            await Promise.all(timeFrames.map(async (tf) => {
                const tbody = document.getElementById(tf.bodyId);
                try {
                    console.log(`[실시간순위] ${tf.label} 조회 시작, qry_tp=${tf.qry}`);
                    const result = await callKiwoom('realtimeRank', {qry_tp: tf.qry});
                    console.log(`[실시간순위] ${tf.label} 응답:`, result);
                    // API 응답: item_inq_rank 또는 stk_rnk_inq_by_tm
                    const rankItems = result.data?.item_inq_rank || result.data?.stk_rnk_inq_by_tm;
                    if (result.success && rankItems) {
                        const items = rankItems.slice(0, 30);
                        tbody.innerHTML = items.map((item, i) => {
                            const stkCd = item.stk_cd || '';
                            const stkNm = item.stk_nm || '';
                            const fluRt = parseFloat(item.flu_rt || 0);
                            const priceColor = fluRt > 0 ? 'var(--success)' : fluRt < 0 ? 'var(--danger)' : 'var(--text-muted)';
                            return `<tr style="cursor: pointer;" onclick="openStockDetailTab('${escapeHtml(stkCd)}', '${escapeHtml(stkNm)}')">
                                <td style="width: 24px; text-align: center; color: var(--text-muted);">${i + 1}</td>
                                <td style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${stkNm}</td>
                                <td style="width: 50px; text-align: right; color: ${priceColor}; font-weight: 600;">${fluRt > 0 ? '+' : ''}${fluRt.toFixed(1)}%</td>
                            </tr>`;
                        }).join('');
                    } else {
                        tbody.innerHTML = '<tr><td colspan="3" style="text-align: center; color: var(--text-muted); padding: 20px;">-</td></tr>';
                    }
                } catch (e) {
                    tbody.innerHTML = `<tr><td colspan="3" style="text-align: center; color: var(--danger); padding: 20px;">${escapeHtml(e.message)}</td></tr>`;
                }
            }));
            addLog('실시간순위 5개 시간대 조회', 'success');
        }

        // 프로그램 TOP 조회 (통합 패널용)
        async function fetchProgramTop50() {
            const statusEl = document.getElementById('supplyStatus');
            const tbody = document.getElementById('programTopTableBody');

            // 라디오 버튼 값 읽기 (새 name 사용)
            const mrktTp = document.querySelector('input[name="programMrkt"]:checked')?.value || 'P00101';
            const trdeTp = document.querySelector('input[name="programType"]:checked')?.value || '2';

            statusEl.textContent = '조회 중...';
            statusEl.style.color = 'var(--accent)';
            tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 40px;"><i class="fas fa-spinner fa-spin"></i></td></tr>';

            try {
                const result = await callKiwoom('programTop50', {
                    trde_upper_tp: trdeTp,  // '1'=순매도, '2'=순매수
                    amt_qty_tp: '1',        // 금액 기준
                    mrkt_tp: '00101',       // 코스피 (기본값)
                    stex_tp: '1'            // KRX
                });
                if (result.success && result.data?.prm_netprps_upper_50) {
                    renderProgramTopTable(result.data.prm_netprps_upper_50);
                    statusEl.textContent = `프로그램 ${result.data.prm_netprps_upper_50.length}건`;
                    statusEl.style.color = 'var(--success)';
                    addLog(`프로그램 TOP ${result.data.prm_netprps_upper_50.length}건`, 'success');
                } else {
                    tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 40px;">데이터 없음</td></tr>';
                    statusEl.textContent = '데이터 없음';
                    statusEl.style.color = 'var(--warning)';
                }
            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--danger); padding: 40px;">${escapeHtml(e.message)}</td></tr>`;
                statusEl.textContent = '조회 실패';
                statusEl.style.color = 'var(--danger)';
            }
        }

        // 프로그램 TOP 테이블 렌더링
        function renderProgramTopTable(items) {
            const tbody = document.getElementById('programTopTableBody');
            if (!items?.length) {
                tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 40px;">데이터 없음</td></tr>';
                return;
            }

            const html = items.map((item, i) => {
                const stkCd = item.stk_cd || '';
                const stkNm = item.stk_nm || '';
                const curPrc = parseInt((item.cur_prc || '0').replace(/[^0-9-]/g, '')) || 0;
                const fluRt = parseFloat((item.flu_rt || '0').replace(/[^0-9.-]/g, '')) || 0;
                const fluRtColor = fluRt > 0 ? 'var(--success)' : fluRt < 0 ? 'var(--danger)' : 'var(--text-muted)';
                const netAmt = parseInt((item.prm_netprps_amt || '0').replace(/[^0-9-]/g, '')) || 0;
                const buyAmt = parseInt((item.prm_buy_amt || '0').replace(/[^0-9]/g, '')) || 0;
                const sellAmt = parseInt((item.prm_sell_amt || '0').replace(/[^0-9]/g, '')) || 0;

                return `<tr style="cursor: pointer;" onclick="openStockDetailTab('${escapeHtml(stkCd)}', '${escapeHtml(stkNm)}')">
                    <td style="text-align: center;">${i + 1}</td>
                    <td>${stkCd}</td>
                    <td style="max-width: 100px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${stkNm}</td>
                    <td style="text-align: right;">${Math.abs(curPrc).toLocaleString()}</td>
                    <td style="text-align: right; color: ${fluRtColor};">${fluRt > 0 ? '+' : ''}${fluRt.toFixed(2)}%</td>
                    <td style="text-align: right; color: ${netAmt >= 0 ? 'var(--success)' : 'var(--danger)'}; font-weight: 600;">${netAmt >= 0 ? '+' : ''}${netAmt.toLocaleString()}</td>
                    <td style="text-align: right; color: var(--success);">${buyAmt.toLocaleString()}</td>
                    <td style="text-align: right; color: var(--danger);">${sellAmt.toLocaleString()}</td>
                </tr>`;
            }).join('');
            tbody.innerHTML = html;
        }

        // 투자자별 테이블 렌더링 (ka10065 응답용)
        function renderInvestorTable(tableId, items, amtQtyTp, isSell = false) {
            const tbody = document.querySelector(`#${tableId} tbody`);
            const excludeEtf = document.getElementById('supplyExcludeEtf')?.checked ?? true;

            if (!items || items.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4" class="empty-state">데이터 없음</td></tr>';
                return;
            }

            // ETF/ETN 필터링
            let filtered = items;
            if (excludeEtf) {
                filtered = items.filter(item => !isEtfOrEtn(item.stk_nm || ''));
            }

            if (filtered.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4" class="empty-state">데이터 없음</td></tr>';
                return;
            }

            const html = filtered.slice(0, 25).map(item => {
                const code = item.stk_cd || '';
                const name = item.stk_nm || '';
                // ka10065: netslmt = 순매수금액 (백만원 단위)
                const netslmt = parseInt(item.netslmt) || 0;
                // 억원 단위로 변환 (백만원 / 100 = 억원)
                const valueInEok = Math.round(netslmt / 100);
                return `
                    <tr style="cursor: pointer;" onclick="openStockDetailTab('${escapeHtml(code)}', '${escapeHtml(name)}')">
                        <td>${code}</td>
                        <td>${name}</td>
                        <td style="text-align: right;">${valueInEok.toLocaleString()} 억</td>
                        <td style="text-align: center;">
                            <button class="btn btn-sm" style="padding: 2px 8px; font-size: 11px;" onclick="event.stopPropagation(); openStockDetailTab('${escapeHtml(code)}', '${escapeHtml(name)}')">
                                <i class="fas fa-chart-line"></i>
                            </button>
                        </td>
                    </tr>
                `;
            }).join('');

            tbody.innerHTML = html;
        }

        // ETF/ETN 필터링 함수
        function isEtfOrEtn(name) {
            const etfPatterns = [
                'KODEX', 'TIGER', 'KBSTAR', 'KOSEF', 'ARIRANG', 'HANARO', 'SOL',
                'ACE', 'PLUS', 'TIMEFOLIO', 'FOCUS', 'BNK', 'TREX', 'KINDEX',
                'ETN', 'TRUE', 'QV', 'RISE', 'WOORI', 'VITA'
            ];
            const upperName = name.toUpperCase();
            return etfPatterns.some(p => upperName.includes(p)) ||
                   upperName.includes('인버스') ||
                   upperName.includes('레버리지') ||
                   upperName.includes('선물');
        }

        function renderSupplyTable(tableId, items, prefix, amtQtyTp) {
            const tbody = document.querySelector(`#${tableId} tbody`);
            const codeKey = `${prefix}_stk_cd`;
            const nameKey = `${prefix}_stk_nm`;
            const amtKey = `${prefix}_amt`;
            const qtyKey = `${prefix}_qty`;
            const valueKey = amtQtyTp === '1' ? amtKey : qtyKey;
            const excludeEtf = document.getElementById('supplyExcludeEtf')?.checked ?? true;

            // 데이터 필터링 (해당 필드가 있는 것만)
            let filtered = items.filter(item => item[codeKey] && item[codeKey].trim());

            // ETF/ETN 필터링
            if (excludeEtf) {
                filtered = filtered.filter(item => !isEtfOrEtn(item[nameKey] || ''));
            }

            if (filtered.length === 0) {
                const isInstitution = prefix.startsWith('orgn');
                const msg = isInstitution ? '장중에만 기관 데이터가 제공됩니다' : '데이터 없음';
                tbody.innerHTML = `<tr><td colspan="4" class="empty-state">${msg}</td></tr>`;
                return;
            }

            const html = filtered.slice(0, 25).map(item => {
                const code = item[codeKey] || '';
                const name = item[nameKey] || '';
                const rawValue = parseInt(item[valueKey]) || 0;
                // ka90009 (HTS 0785): amt_qty_tp=1이면 천만원 단위 → 억원 변환 (/10)
                // amt_qty_tp=2이면 천주 단위 그대로
                const value = amtQtyTp === '1' ? Math.round(rawValue / 10) : rawValue;
                const unit = amtQtyTp === '1' ? '억' : '천';
                return `
                    <tr style="cursor: pointer;" onclick="openStockDetailTab('${escapeHtml(code)}', '${escapeHtml(name)}')">
                        <td>${code}</td>
                        <td>${name}</td>
                        <td style="text-align: right;">${value.toLocaleString()} ${unit}</td>
                        <td style="text-align: center;">
                            <button class="btn btn-sm" style="padding: 2px 8px; font-size: 11px;" onclick="event.stopPropagation(); openStockDetailTab('${escapeHtml(code)}', '${escapeHtml(name)}')">
                                <i class="fas fa-chart-line"></i>
                            </button>
                        </td>
                    </tr>
                `;
            }).join('');

            tbody.innerHTML = html;
        }

        // 실시간 순위 새로고침 (IPC 기반)
        // ==================== 실시간 순위 (파이썬 동일 구현) ====================
        const QRY_TYPES = [
            { name: '30초', qryTp: '5' },
            { name: '1분', qryTp: '1' },
            { name: '10분', qryTp: '2' },
            { name: '1시간', qryTp: '3' },
            { name: '당일누적', qryTp: '4' }
        ];
        let currentRankTab = '5';
        let rankData = {};  // qryTp -> items
        let rankAutoRefreshId = null;

        // 탭 전환
        function switchRankTab(qryTp) {
            currentRankTab = qryTp;
            document.querySelectorAll('.rank-tab').forEach(tab => {
                tab.classList.toggle('active', tab.dataset.qry === qryTp);
            });
            document.querySelectorAll('.rank-content').forEach(content => {
                content.style.display = content.id === `rankContent${qryTp}` ? 'block' : 'none';
            });
        }

        // 전체 시간대 조회
        async function refreshAllRanks() {
            if (!isConnected || !kiwoomAPI) {
                alert('Kiwoom API가 연결되지 않았습니다. 토큰을 먼저 발급하세요.');
                return;
            }

            const statusLabel = document.getElementById('rankStatusLabel');
            statusLabel.textContent = '조회 중...';
            statusLabel.style.color = 'var(--accent)';
            addLog('실시간 순위 전체 조회 중...', 'info');

            let successCount = 0;
            for (let i = 0; i < QRY_TYPES.length; i++) {
                const { name, qryTp } = QRY_TYPES[i];
                try {
                    statusLabel.textContent = `${name} 조회 중...`;
                    const result = await kiwoomAPI.realtimeRank({ qryTp, expectedCount: 20, maxRetries: 2 });
                    console.log(`[${name}] result:`, result);
                    if (result.success && result.items) {
                        rankData[qryTp] = result.items;
                        renderRankTable(qryTp, result.items, result.dt, result.tm);
                        successCount++;
                    } else {
                        addLog(`${name} 조회 실패: ${result.error}`, 'error');
                    }
                } catch (e) {
                    addLog(`${name} 조회 오류: ${e.message}`, 'error');
                }
                // Rate Limit은 프록시 서버에서 전역 관리 (1분에 4건)
                // 클라이언트는 딜레이 없이 요청, 프록시가 자동 대기
            }

            statusLabel.textContent = `완료 (${successCount}/${QRY_TYPES.length})`;
            statusLabel.style.color = 'var(--success)';
            addLog(`실시간 순위 조회 완료: ${successCount}/${QRY_TYPES.length}`, 'success');

            // 30초 순위(qryTp: '5') 1위 종목을 기본 종목코드로 설정
            updateDefaultStockCode();

            // 다음 자동 새로고침 스케줄
            scheduleNextRefresh();
        }

        // 30초 순위 1위 종목을 종목조회 기본값으로 설정
        function updateDefaultStockCode() {
            const rank30secData = rankData['5'];  // 30초 순위
            if (rank30secData && rank30secData.length > 0) {
                const top1 = rank30secData[0];
                const stockCode = top1.stk_cd || top1.stbd_cd || '';
                if (stockCode) {
                    const input = document.getElementById('stockCode');
                    if (input && !input.value) {  // 비어있을 때만 설정
                        input.value = stockCode;
                        input.placeholder = `${stockCode} (30초 순위 1위)`;
                    }
                }
            }
        }

        // 단일 시간대 조회
        async function fetchRealtimeRank(qryTp) {
            return await callKiwoom('realtimeRank', {qry_tp: qryTp});
        }

        // 테이블 렌더링
        function renderRankTable(qryTp, items, dt, tm) {
            const tbody = document.querySelector(`#rankTable${qryTp} tbody`);
            const timeSpan = document.getElementById(`rankTime${qryTp}`);

            // 기준시간 표시
            if (dt && tm) {
                const dateStr = `${dt.substring(0,4)}-${dt.substring(4,6)}-${dt.substring(6,8)}`;
                const timeStr = `${tm.substring(0,2)}:${tm.substring(2,4)}:${tm.substring(4,6)}`;
                timeSpan.textContent = `${dateStr} ${timeStr}`;
            }

            if (!items || items.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" class="empty-state">데이터가 없습니다</td></tr>';
                return;
            }

            tbody.innerHTML = items.map((item, i) => {
                const rank = item.bigd_rank || (i + 1);
                const rankChg = parseInt(item.rank_chg) || 0;
                const rankChgSign = item.rank_chg_sign || '3';
                const code = item.stk_cd || '';
                const name = item.stk_nm || '';
                const price = parseInt(item.past_curr_prc) || 0;
                const baseSign = item.base_comp_sign || '3';
                const baseRate = parseFloat(item.base_comp_chgr) || 0;
                const prevSign = item.prev_base_sign || '3';
                const prevRate = parseFloat(item.prev_base_chgr) || 0;

                // 순위 변동 표시
                let rankChgHtml = '';
                if (rankChgSign === '1') {  // 상승
                    rankChgHtml = `<span class="rank-up">▲${rankChg}</span>`;
                } else if (rankChgSign === '2') {  // 하락
                    rankChgHtml = `<span class="rank-down">▼${Math.abs(rankChg)}</span>`;
                } else {
                    rankChgHtml = `<span class="rank-same">-</span>`;
                }

                // 등락률 색상
                const baseClass = baseSign === '2' ? 'price-up' : (baseSign === '5' ? 'price-down' : '');
                const prevClass = prevSign === '2' ? 'price-up' : (prevSign === '5' ? 'price-down' : '');

                return `
                    <tr onclick="onRankRowClick('${escapeHtml(code)}', '${escapeHtml(name)}')">
                        <td>${rank}</td>
                        <td>${rankChgHtml}</td>
                        <td>${code}</td>
                        <td>${name}</td>
                        <td>${price.toLocaleString()}</td>
                        <td class="${baseClass}">${baseSign === '2' ? '+' : (baseSign === '5' ? '-' : '')}${baseRate.toFixed(2)}%</td>
                        <td class="${prevClass}">${prevSign === '2' ? '+' : (prevSign === '5' ? '-' : '')}${prevRate.toFixed(2)}%</td>
                        <td style="text-align: center;">
                            <button class="btn btn-sm" style="padding: 2px 8px; font-size: 11px;" onclick="event.stopPropagation(); openRankChart('${code}', '${escapedName}')">
                                <i class="fas fa-chart-line"></i>
                            </button>
                        </td>
                    </tr>
                `;
            }).join('');
        }

        // 종목 행 클릭 → 종목 상세 탭으로 이동
        function onRankRowClick(code, name) {
            openStockDetailTab(code, name);
        }

        // 자동 새로고침 스케줄 (정시/30초에 갱신)
        function scheduleNextRefresh() {
            if (rankAutoRefreshId) {
                clearTimeout(rankAutoRefreshId);
            }

            const now = new Date();
            const sec = now.getSeconds();
            let nextSec;

            // 다음 30초 또는 00초까지 대기
            if (sec < 30) {
                nextSec = 30 - sec;
            } else {
                nextSec = 60 - sec;
            }

            const nextTime = new Date(now.getTime() + nextSec * 1000);
            const nextTimeStr = `${String(nextTime.getHours()).padStart(2,'0')}:${String(nextTime.getMinutes()).padStart(2,'0')}:${String(nextTime.getSeconds()).padStart(2,'0')}`;

            document.getElementById('nextRefreshLabel').textContent = `다음 새로고침: ${nextTimeStr}`;

            rankAutoRefreshId = setTimeout(() => {
                refreshAllRanks();
            }, nextSec * 1000 + 1000);  // +1초 여유
        }

        // 기존 refreshRank 호환용
        async function refreshRank() {
            await refreshAllRanks();
        }

        // ========== 종목 조회 기능 (종토방 전용) ==========
        let currentStockCode = '';

        async function searchStock() {
            const code = document.getElementById('stockCode').value.trim();
            if (!code) {
                alert('종목코드를 입력하세요');
                return;
            }

            currentStockCode = code;
            addLog(`종토방 조회: ${code}`, 'info');
            document.getElementById('stockSearchStatus').textContent = '조회 중...';

            // 컨테이너 표시
            const container = document.getElementById('stockInfoContainer');
            const emptyState = document.getElementById('stockEmptyState');
            container.style.display = 'block';
            emptyState.style.display = 'none';

            // 종토방 바로 로드
            await loadForumData(code, 1);
            document.getElementById('stockSearchStatus').textContent = '조회 완료';
        }

        // 종토방 페이지 상태
        let forumCurrentPage = 1;

        // 네이버 종토방 데이터 로드
        async function loadForumData(code, page = 1) {
            if (!code) return;
            if (page < 1) page = 1;

            const tbody = document.getElementById('forumTableBody');
            tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: var(--text-muted);"><i class="fas fa-spinner fa-spin"></i> 종토방 로딩...</td></tr>';

            // 종목코드 표시
            const stockNameEl = document.getElementById('forumStockName');
            if (stockNameEl) {
                stockNameEl.textContent = `종토방 (${code})`;
            }

            try {
                const result = await kiwoomAPI.stockForum(code, page);

                if (result.ok && result.posts) {
                    forumCurrentPage = page;
                    renderForumTable(result.posts);
                    updateForumPagination();
                    addLog(`종토방 ${page}페이지 조회 완료 (${result.posts.length}개)`, 'success');
                } else {
                    tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted);">종토방 조회 실패: ${result.error || ''}</td></tr>`;
                }
            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted);">오류: ${escapeHtml(e.message)}</td></tr>`;
            }
        }

        // 종토방 테이블 렌더링
        function renderForumTable(data) {
            const tbody = document.getElementById('forumTableBody');

            if (!data || data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: var(--text-muted);">게시글이 없습니다</td></tr>';
                return;
            }

            let rows = data.map(item => {
                // 네이버 API 필드명: goodCount, badCount, readCount, title, discussionId, writerId, date
                const good = Number(item.goodCount || item.likeCount || item.good || 0);
                const bad = Number(item.badCount || item.unlikeCount || item.bad || 0);
                const net = good - bad;
                const netClass = net > 0 ? 'color: var(--success);' : (net < 0 ? 'color: var(--danger);' : '');
                const views = Number(item.readCount || item.viewCount || item.views || 0);
                const writer = item.writerId || item.writerName || item.writer || '-';
                // date는 "2025-07-02 16:18:44" 형식
                const dateStr = item.date || item.dateTime || '';
                const date = dateStr ? dateStr.slice(5, 10).replace('-', '/') : '-';
                const postId = item.discussionId || item.nttId || '';

                return `<tr style="cursor: pointer;" onclick="window.open('https://m.stock.naver.com/domestic/stock/${currentStockCode}/discuss/${postId}', '_blank')">
                    <td style="font-size: 12px; color: var(--text-muted);">${date}</td>
                    <td style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 300px;" title="${escapeHtml(item.title || '')}">${escapeHtml(item.title) || '-'}</td>
                    <td style="text-align: center; font-size: 12px;">${views.toLocaleString()}</td>
                    <td style="text-align: center; font-size: 12px; ${netClass}">${good > 0 ? '+' + good : good}</td>
                    <td style="font-size: 12px; color: var(--text-muted);">${writer}</td>
                </tr>`;
            }).join('');

            tbody.innerHTML = rows;
        }

        // 종토방 페이지네이션 업데이트
        function updateForumPagination() {
            document.getElementById('forumPageInfo').textContent = `${forumCurrentPage}페이지`;
            document.getElementById('forumPrevBtn').disabled = forumCurrentPage <= 1;
        }

        // ==================== 프로그램매매 실시간 (0w) - 다중 종목 지원 ====================
        let programTradeStocks = {};  // { stockCode: { name, data, lastUpdate } }
        let programTradePollingId = null;

        // 금액 포맷 헬퍼 (억/만 단위)
        function formatPTAmt(val) {
            const num = Number(val) || 0;
            if (Math.abs(num) >= 100000000) {
                return (num / 100000000).toFixed(1) + '억';
            } else if (Math.abs(num) >= 10000) {
                return (num / 10000).toFixed(0) + '만';
            }
            return num.toLocaleString();
        }

        // 수량 포맷 헬퍼
        function formatPTQty(val) {
            const num = Number(val) || 0;
            return num.toLocaleString();
        }

        // 색상 결정 헬퍼
        function getPTColor(val) {
            const num = Number(val) || 0;
            if (num > 0) return 'var(--danger)';   // 매수 우위 = 빨강
            if (num < 0) return 'var(--primary)';  // 매도 우위 = 파랑
            return 'inherit';
        }

        // 가격 포맷
        function formatPTPrice(val) {
            const num = Number(val) || 0;
            return num.toLocaleString();
        }

        // 종목 추가
        async function addProgramTradeStock() {
            const input = document.getElementById('ptStockCode');
            const stockCode = input.value.trim();

            // ETN/ETF 코드는 알파벳 포함 가능 (예: 0008Z0)
            if (!/^[0-9A-Z]{6}$/i.test(stockCode)) {
                alert('종목코드는 6자리입니다');
                return;
            }

            if (programTradeStocks[stockCode]) {
                alert('이미 등록된 종목입니다');
                return;
            }

            const host = localStorage.getItem('kiwoom_host');
            const token = localStorage.getItem('kiwoom_token');

            if (!host || !token) {
                alert('키움 API 연결 정보가 없습니다. 먼저 API 인증 탭에서 로그인하세요.');
                return;
            }

            try {
                try {
                    console.warn('미지원 기능');
                } catch (e) {}
                const result = { success: true };

                if (result.success) {
                    // 종목 정보 가져오기
                    let stockName = stockCode;
                    try {
                        const infoData = await callKiwoom('stockInfo', {stk_cd: stockCode});
                        if (infoData.success && infoData.data && infoData.data.stk_nm) {
                            stockName = infoData.data.stk_nm;
                        }
                    } catch (e) {
                        console.log('종목명 조회 실패, 코드로 표시:', e);
                    }

                    // 상태에 추가
                    programTradeStocks[stockCode] = {
                        name: stockName,
                        data: null,
                        lastUpdate: null
                    };

                    // 테이블 렌더링
                    renderProgramTradeTable();
                    updateProgramTradeStatus();

                    // 폴링 시작 (첫 종목 추가 시)
                    if (!programTradePollingId) {
                        programTradePollingId = setInterval(pollAllProgramTrade, 1000);
                    }

                    addLog(`프로그램매매 구독 시작: ${stockName} (${stockCode})`, 'success');
                    input.value = '';
                } else {
                    throw new Error(result.error || '등록 실패');
                }
            } catch (e) {
                addLog(`프로그램매매 등록 실패: ${e.message}`, 'error');
                alert('등록 실패: ' + e.message);
            }
        }

        // 종목 제거
        async function removeProgramTradeStock(stockCode) {
            try {
                console.warn('미지원 기능');
            } catch (e) {
                console.error('프로그램매매 해제 오류:', e);
            }

            const stockInfo = programTradeStocks[stockCode];
            delete programTradeStocks[stockCode];

            renderProgramTradeTable();
            updateProgramTradeStatus();

            // 종목이 없으면 폴링 중지
            if (Object.keys(programTradeStocks).length === 0 && programTradePollingId) {
                clearInterval(programTradePollingId);
                programTradePollingId = null;
            }

            addLog(`프로그램매매 구독 해제: ${stockInfo?.name || stockCode}`, 'info');
        }

        // 전체 삭제
        async function clearAllProgramTrade() {
            if (Object.keys(programTradeStocks).length === 0) return;

            if (!confirm('모든 종목의 프로그램매매 구독을 해제하시겠습니까?')) return;

            for (const stockCode of Object.keys(programTradeStocks)) {
                try {
                    console.warn('미지원 기능');
                } catch (e) {
                    console.error('해제 오류:', stockCode, e);
                }
            }

            programTradeStocks = {};

            if (programTradePollingId) {
                clearInterval(programTradePollingId);
                programTradePollingId = null;
            }

            renderProgramTradeTable();
            updateProgramTradeStatus();
            addLog('프로그램매매 전체 구독 해제', 'info');
        }

        // 모든 종목 폴링
        async function pollAllProgramTrade() {
            const stockCodes = Object.keys(programTradeStocks);
            if (stockCodes.length === 0) return;

            try {
                console.warn('미지원 기능');
                const result = { success: false };

                if (result.success && result.data) {
                    let hasUpdate = false;
                    const now = new Date();

                    for (const stockCode of stockCodes) {
                        if (result.data[stockCode]) {
                            programTradeStocks[stockCode].data = result.data[stockCode];
                            programTradeStocks[stockCode].lastUpdate = now;
                            hasUpdate = true;
                        }
                    }

                    if (hasUpdate) {
                        renderProgramTradeTable();
                        document.getElementById('ptLastUpdate').textContent =
                            now.toTimeString().slice(0, 8);
                    }
                }
            } catch (e) {
                console.error('프로그램매매 폴링 오류:', e);
            }
        }

        // 테이블 렌더링
        function renderProgramTradeTable() {
            const tbody = document.getElementById('programTradeTableBody');
            const stockCodes = Object.keys(programTradeStocks);

            if (stockCodes.length === 0) {
                tbody.innerHTML = `
                    <tr id="ptEmptyRow">
                        <td colspan="10" style="text-align: center; color: var(--text-muted); padding: 40px;">
                            <i class="fas fa-plus-circle" style="font-size: 24px; margin-bottom: 8px; display: block;"></i>
                            종목코드를 입력하고 추가 버튼을 클릭하세요
                        </td>
                    </tr>
                `;
                return;
            }

            let html = '';
            for (const stockCode of stockCodes) {
                const stock = programTradeStocks[stockCode];
                const data = stock.data || {};

                const curPrice = formatPTPrice(data.curPrice);
                const buyAmt = formatPTAmt(data.buyAmt);
                const sellAmt = formatPTAmt(data.sellAmt);

                const netAmt = Number(data.netAmt) || 0;
                const netAmtStr = (netAmt >= 0 ? '+' : '') + formatPTAmt(data.netAmt);
                const netAmtColor = getPTColor(netAmt);

                const netAmtChange = Number(data.netAmtChange) || 0;
                const netAmtChangeStr = (netAmtChange >= 0 ? '+' : '') + formatPTAmt(data.netAmtChange);
                const netAmtChangeColor = getPTColor(netAmtChange);

                const netQty = Number(data.netQty) || 0;
                const netQtyStr = (netQty >= 0 ? '+' : '') + formatPTQty(data.netQty);
                const netQtyColor = getPTColor(netQty);

                const time = data.time || '';
                const timeStr = time.length >= 6
                    ? `${time.slice(0,2)}:${time.slice(2,4)}:${time.slice(4,6)}`
                    : '--:--:--';

                html += `
                    <tr id="pt-row-${stockCode}">
                        <td style="font-family: monospace;">${stockCode}</td>
                        <td style="font-weight: 500;">${stock.name}</td>
                        <td style="text-align: right; font-family: monospace;">${data.curPrice ? curPrice : '-'}</td>
                        <td style="text-align: right; color: var(--danger);">${data.buyAmt ? buyAmt : '-'}</td>
                        <td style="text-align: right; color: var(--primary);">${data.sellAmt ? sellAmt : '-'}</td>
                        <td style="text-align: right; font-weight: 600; color: ${netAmtColor};">${data.netAmt !== undefined ? netAmtStr : '-'}</td>
                        <td style="text-align: right; color: ${netAmtChangeColor};">${data.netAmtChange !== undefined ? netAmtChangeStr : '-'}</td>
                        <td style="text-align: right; color: ${netQtyColor};">${data.netQty !== undefined ? netQtyStr : '-'}</td>
                        <td style="text-align: center; font-size: 11px; color: var(--text-muted);">${timeStr}</td>
                        <td style="text-align: center;">
                            <button class="btn btn-danger" style="padding: 4px 8px; font-size: 11px;" onclick="removeProgramTradeStock('${stockCode}')">
                                <i class="fas fa-times"></i>
                            </button>
                        </td>
                    </tr>
                `;
            }

            tbody.innerHTML = html;
        }

        // 상태 업데이트
        function updateProgramTradeStatus() {
            const count = Object.keys(programTradeStocks).length;
            document.getElementById('programTradeStatus').textContent = `${count}개 종목 구독 중`;
        }

        // ==================== 조건검색 관련 상태 및 함수 ====================
        let conditions = [];  // 조건 목록 [{seq, name}]
        let selectedConditionSeq = null;  // 현재 선택된 조건 seq
        let selectedConditionsForRealtime = [];  // 실시간 감시용 선택된 조건 [{seq, name}]
        let normalSearchResults = [];  // 일반조회 결과
        let realtimeResults = [];  // 실시간 편입/이탈 결과
        let isRealtimeMonitoring = false;  // 실시간 모니터링 상태
        let conditionWs = null;  // WebSocket 연결
        let stockNameCache = {};  // 종목명 캐시 {code: name}
        const SELECTED_CONDITIONS_BASE_KEY = 'kiwoom_selected_conditions';  // 사용자별 localStorage 기본 키

        // 조건검색 목록 불러오기 (ka10171)
        async function loadConditions() {
            const btnLoad = document.getElementById('btnLoadConditions');
            btnLoad.disabled = true;
            btnLoad.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 조회 중...';

            addLog('조건검색 목록 조회 중...', 'info');
            document.getElementById('conditionMonitorStatus').textContent = '조회 중...';

            try {
                // 조건검색 목록 조회
                const res = await fetch(`${API_BASE}/api/kiwoom/condition/list`, {method: 'POST', headers: {'Content-Type': 'application/json'}});
                const result = await res.json();

                const condList = result.ok ? (result.data?.conditions || (Array.isArray(result.data) ? result.data : [])) : [];
                if (condList.length > 0) {
                    conditions = condList.map((item, idx) => {
                        if (Array.isArray(item)) {
                            return { seq: item[0] || String(idx), name: item[1] || `조건${idx + 1}` };
                        }
                        return { seq: item.seq || String(idx), name: item.name || `조건${idx + 1}` };
                    });

                    if (conditions.length > 0) {
                        // 드롭다운 채우기 (seq 순서대로 정렬)
                        const select = document.getElementById('conditionSelect');
                        select.innerHTML = '<option value="">-- 조건식 선택 --</option>';
                        const sortedConditions = [...conditions].sort((a, b) => parseInt(a.seq) - parseInt(b.seq));
                        sortedConditions.forEach(cond => {
                            const opt = document.createElement('option');
                            opt.value = cond.seq;
                            opt.textContent = `#${cond.seq} ${cond.name}`;
                            select.appendChild(opt);
                        });
                        select.disabled = false;

                        // localStorage에서 저장된 선택 목록 로드
                        loadSelectedConditionsFromStorage();

                        addLog(`조건검색 목록 ${conditions.length}개 로드 완료`, 'success');
                        document.getElementById('conditionMonitorStatus').textContent = `${conditions.length}개 조건`;
                    } else {
                        document.getElementById('conditionMonitorStatus').textContent = '조건 없음';
                    }
                } else {
                    throw new Error(result.error || '조건 목록 조회 실패');
                }
            } catch (e) {
                addLog('조건검색 목록 조회 오류: ' + e.message, 'error');
                document.getElementById('conditionMonitorStatus').textContent = '오류';
            } finally {
                btnLoad.disabled = false;
                btnLoad.innerHTML = '<i class="fas fa-sync-alt"></i> 조건 불러오기';
            }
        }

        // 조건 선택 시 바로 조회
        async function onConditionSelect() {
            const select = document.getElementById('conditionSelect');
            selectedConditionSeq = select.value || null;
            document.getElementById('btnNormalSearch').disabled = !selectedConditionSeq;

            // 조건 선택하면 바로 일반조회 실행
            if (selectedConditionSeq) {
                await normalSearch();
            }
        }

        // 일반조회 (ka10172 - search_type: 0)
        async function normalSearch() {
            if (!selectedConditionSeq) {
                alert('조건을 선택하세요');
                return;
            }

            const cond = conditions.find(c => c.seq === selectedConditionSeq);
            if (!cond) return;

            const btn = document.getElementById('btnNormalSearch');
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 조회 중...';

            addLog(`일반조회 시작: ${cond.name}`, 'info');

            try {
                // 조건검색 실행
                const res = await fetch(`${API_BASE}/api/kiwoom/condition/search`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({seq: selectedConditionSeq, search_type: "0"})});
                const result = await res.json();

                const stkList = result.ok ? (result.data?.stk_list || (Array.isArray(result.data) ? result.data : [])) : [];
                if (stkList.length > 0) {
                    normalSearchResults = stkList.map((item, idx) => {
                        // 필드 12는 등락률 × 1000 (예: 13390 = 13.39%)
                        const changeRaw = parseInt(item['12'] || item.chg_rate || 0);
                        const changeRate = changeRaw / 1000;  // 1000으로 나눠서 실제 퍼센트로 변환

                        const code = (item['9001'] || item.stk_cd || '').replace('A', '');
                        const name = item['302'] || item.stk_nm || '';

                        // 종목명 캐시에 저장 (실시간 편입/이탈 시 사용)
                        if (code && name) {
                            stockNameCache[code] = name;
                        }

                        return {
                            no: idx + 1,
                            code: code,
                            name: name,
                            price: parseInt(item['10'] || item.price || 0),
                            change: changeRate,
                            volume: parseInt(item['13'] || item.acml_vol || item.volume || 0)
                        };
                    });

                    renderNormalSearchResults(cond.name);
                    addLog(`일반조회 완료: ${cond.name} - ${normalSearchResults.length}개 종목`, 'success');
                } else {
                    throw new Error(result.error || '일반조회 실패');
                }
            } catch (e) {
                addLog(`일반조회 오류: ${e.message}`, 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-search"></i> 일반조회';
            }
        }

        // 일반조회 결과 렌더링
        function renderNormalSearchResults(condName) {
            document.getElementById('normalSearchCondName').textContent = condName;
            document.getElementById('normalSearchCount').textContent = `(${normalSearchResults.length}개)`;

            if (normalSearchResults.length === 0) {
                document.getElementById('normalSearchEmpty').style.display = 'flex';
                document.getElementById('normalSearchTableContainer').style.display = 'none';
                return;
            }

            document.getElementById('normalSearchEmpty').style.display = 'none';
            document.getElementById('normalSearchTableContainer').style.display = 'block';

            const tbody = document.getElementById('normalSearchBody');
            tbody.innerHTML = '';

            normalSearchResults.forEach(item => {
                const tr = document.createElement('tr');
                const changeColor = item.change > 0 ? 'var(--danger)' : item.change < 0 ? 'var(--info)' : 'var(--text-muted)';
                const changePrefix = item.change > 0 ? '+' : '';

                tr.innerHTML = `
                    <td style="text-align: center;">${item.no}</td>
                    <td style="text-align: center;">${item.code}</td>
                    <td>${item.name || '-'}</td>
                    <td style="text-align: right;">${item.price.toLocaleString()}</td>
                    <td style="text-align: right; color: ${changeColor};">${changePrefix}${item.change.toFixed(2)}%</td>
                    <td style="text-align: right;">${item.volume.toLocaleString()}</td>
                `;
                tr.style.cursor = 'pointer';
                tr.addEventListener('click', () => {
                    openStockDetailTab(item.code, item.name);
                });
                tbody.appendChild(tr);
            });
        }

        // 일반조회 결과 초기화
        function clearNormalSearch() {
            normalSearchResults = [];
            document.getElementById('normalSearchCondName').textContent = '';
            document.getElementById('normalSearchCount').textContent = '';
            document.getElementById('normalSearchEmpty').style.display = 'flex';
            document.getElementById('normalSearchTableContainer').style.display = 'none';
        }

        // 실시간 감시 중지 (ka10174)
        async function stopAllConditions() {
            addLog('실시간 감시 중지...', 'info');
            document.getElementById('conditionMonitorStatus').textContent = '중지 중...';

            try {
                // 1. 모니터링 중지
                await fetch(`${API_BASE}/api/kiwoom/condition/stop`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({})});

                // 2. 선택된 조건들만 실시간 중지
                for (const cond of selectedConditionsForRealtime) {
                    await fetch(`${API_BASE}/api/kiwoom/condition/stop`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({seq: cond.seq})});
                    await new Promise(r => setTimeout(r, 100));
                }

                isRealtimeMonitoring = false;
                stopRealtimePolling();

                document.getElementById('btnStartAll').style.display = 'inline-flex';
                document.getElementById('btnStopAll').style.display = 'none';
                document.getElementById('realtimeStatus').textContent = '';
                document.getElementById('conditionMonitorStatus').textContent = `${conditions.length}개 조건`;

                addLog('실시간 감시 중지 완료', 'success');
            } catch (e) {
                addLog(`실시간 중지 오류: ${e.message}`, 'error');
            }
        }

        // 실시간 결과 렌더링
        function renderRealtimeResults() {
            const showExited = document.getElementById('chkShowExited').checked;
            const filtered = showExited ? realtimeResults : realtimeResults.filter(r => r.type === 'entry');

            document.getElementById('realtimeCount').textContent = `(${filtered.length})`;

            if (filtered.length === 0 && !isRealtimeMonitoring) {
                document.getElementById('realtimeEmpty').style.display = 'flex';
                document.getElementById('realtimeTableContainer').style.display = 'none';
                return;
            }

            document.getElementById('realtimeEmpty').style.display = 'none';
            document.getElementById('realtimeTableContainer').style.display = 'block';

            const tbody = document.getElementById('realtimeBody');
            tbody.innerHTML = '';

            filtered.slice(0, 100).forEach(item => {
                const tr = document.createElement('tr');
                tr.style.cursor = 'pointer';
                tr.onclick = () => openStockDetailTab(item.code, item.name || '');
                const isEntry = item.type === 'entry';
                const statusColor = isEntry ? 'var(--success)' : 'var(--danger)';
                const statusIcon = isEntry ? 'fa-arrow-up' : 'fa-arrow-down';
                const statusText = isEntry ? '편입' : '이탈';
                const changeColor = item.change > 0 ? 'var(--danger)' : item.change < 0 ? 'var(--info)' : 'var(--text-muted)';
                const changePrefix = item.change > 0 ? '+' : '';

                // 거래대금 포맷 (백만원 단위)
                const tradeAmountFormatted = item.tradeAmount ?
                    (item.tradeAmount >= 100000000 ? (item.tradeAmount / 100000000).toFixed(1) + '억' :
                     item.tradeAmount >= 1000000 ? (item.tradeAmount / 1000000).toFixed(0) + '백만' :
                     item.tradeAmount.toLocaleString()) : '-';

                tr.innerHTML = `
                    <td style="color: ${statusColor}; text-align: center;">
                        <i class="fas ${statusIcon}"></i> ${statusText}
                    </td>
                    <td style="text-align: center; color: var(--text-muted);">${item.time}</td>
                    <td style="text-align: center;">${item.code}</td>
                    <td>${item.name || '-'}</td>
                    <td style="text-align: right;">${item.price.toLocaleString()}</td>
                    <td style="text-align: right; color: ${changeColor};">${changePrefix}${item.change.toFixed(2)}%</td>
                    <td style="text-align: right;">${item.volume.toLocaleString()}</td>
                    <td style="text-align: right;">${tradeAmountFormatted}</td>
                    <td style="color: var(--text-muted);">${item.conditionName}</td>
                    <td style="text-align: center;">
                        <button class="btn btn-sm" style="padding: 2px 8px; font-size: 11px;" onclick="event.stopPropagation(); openStockDetailTab('${escapeHtml(item.code)}', '${escapeHtml(item.name || '')}')">
                            <i class="fas fa-chart-line"></i>
                        </button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }

        // 실시간 결과 필터
        function filterRealtimeResults() {
            renderRealtimeResults();
        }

        // 실시간 결과 초기화
        function clearRealtimeResults() {
            realtimeResults = [];
            renderRealtimeResults();
            addLog('실시간 결과 초기화', 'info');
        }

        // ==================== 검색식 선택 모달 관련 함수 ====================

        // 모달 열기
        function openConditionSelectModal() {
            // 조건 목록이 없으면 먼저 불러오기
            if (conditions.length === 0) {
                alert('먼저 "조건 불러오기" 버튼을 클릭하여 검색식을 불러와주세요.');
                return;
            }

            // localStorage에서 저장된 선택 목록 로드
            loadSelectedConditionsFromStorage();

            // UI 업데이트
            renderConditionAllList();
            renderConditionSelectedList();

            document.getElementById('conditionSelectOverlay').classList.remove('hidden');
        }

        // 모달 닫기
        function closeConditionSelectModal() {
            document.getElementById('conditionSelectOverlay').classList.add('hidden');
        }

        // localStorage에서 선택된 조건 로드 (사용자별)
        function loadSelectedConditionsFromStorage() {
            try {
                // 사용자별 키 사용
                const saved = getUserData(SELECTED_CONDITIONS_BASE_KEY, []);
                if (saved && Array.isArray(saved)) {
                    selectedConditionsForRealtime = saved;
                    // 유효한 조건만 필터링 (현재 조건 목록에 있는 것만)
                    selectedConditionsForRealtime = selectedConditionsForRealtime.filter(sc =>
                        conditions.some(c => c.seq === sc.seq)
                    );
                } else {
                    selectedConditionsForRealtime = [];
                }
            } catch (e) {
                console.error('[조건선택] 사용자별 데이터 로드 오류:', e);
                selectedConditionsForRealtime = [];
            }
            updateSelectedConditionBadge();
        }

        // localStorage에 선택된 조건 저장 (사용자별)
        function saveSelectedConditionsToStorage() {
            try {
                // 사용자별 키 사용
                setUserData(SELECTED_CONDITIONS_BASE_KEY, selectedConditionsForRealtime);
            } catch (e) {
                console.error('[조건선택] 사용자별 데이터 저장 오류:', e);
            }
            updateSelectedConditionBadge();
        }

        // 선택된 조건 배지 업데이트
        function updateSelectedConditionBadge() {
            const badge = document.getElementById('selectedConditionBadge');
            if (selectedConditionsForRealtime.length > 0) {
                badge.textContent = selectedConditionsForRealtime.length;
                badge.style.display = 'inline';
            } else {
                badge.style.display = 'none';
            }
            // 실시간 시작 버튼 활성화 상태 업데이트
            document.getElementById('btnStartAll').disabled = selectedConditionsForRealtime.length === 0;
        }

        // 전체 검색식 목록 렌더링
        function renderConditionAllList() {
            const container = document.getElementById('condAllList');
            const selectedSeqs = selectedConditionsForRealtime.map(c => c.seq);

            // 선택되지 않은 조건만 표시 + seq 번호순 정렬
            const available = conditions
                .filter(c => !selectedSeqs.includes(c.seq))
                .sort((a, b) => parseInt(a.seq) - parseInt(b.seq));

            document.getElementById('condAllCount').textContent = `${available.length}개`;

            if (available.length === 0) {
                container.innerHTML = `
                    <div class="empty-placeholder">
                        <i class="fas fa-check-circle" style="font-size: 24px; margin-bottom: 8px; color: var(--success);"></i>
                        <p>모든 검색식이<br>선택되었습니다</p>
                    </div>
                `;
                return;
            }

            container.innerHTML = available.map(cond => `
                <div class="condition-item" draggable="true"
                     ondragstart="condDragStart(event, '${cond.seq}', '${escapeHtml(cond.name)}')"
                     ondragend="condDragEnd(event)">
                    <span class="cond-seq">#${cond.seq}</span>
                    <span class="cond-name">${escapeHtml(cond.name)}</span>
                </div>
            `).join('');
        }

        // 선택된 검색식 목록 렌더링
        function renderConditionSelectedList() {
            const container = document.getElementById('condSelectedList');

            document.getElementById('condSelectedCount').textContent = `${selectedConditionsForRealtime.length}개`;

            if (selectedConditionsForRealtime.length === 0) {
                container.innerHTML = `
                    <div class="empty-placeholder">
                        <i class="fas fa-inbox" style="font-size: 24px; margin-bottom: 8px; opacity: 0.3;"></i>
                        <p>좌측에서 검색식을<br>드래그하여 추가하세요</p>
                    </div>
                `;
                return;
            }

            // seq 번호순 정렬
            const sorted = [...selectedConditionsForRealtime].sort((a, b) => parseInt(a.seq) - parseInt(b.seq));

            container.innerHTML = sorted.map(cond => `
                <div class="condition-item" draggable="true"
                     ondragstart="condDragStartFromSelected(event, '${cond.seq}', '${escapeHtml(cond.name)}')"
                     ondragend="condDragEnd(event)">
                    <span class="cond-seq">#${cond.seq}</span>
                    <span class="cond-name">${escapeHtml(cond.name)}</span>
                    <span class="cond-remove" onclick="condRemoveFromSelected('${cond.seq}')">
                        <i class="fas fa-times"></i>
                    </span>
                </div>
            `).join('');
        }

        // HTML 이스케이프 (XSS 방지)
        function escapeHtml(str) {
            return String(str).replace(/[&<>"']/g, m => ({
                '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
            }[m]));
        }

        // 드래그 시작 (전체 목록에서)
        function condDragStart(event, seq, name) {
            event.target.classList.add('dragging');
            event.dataTransfer.setData('application/json', JSON.stringify({ seq, name, from: 'all' }));
            event.dataTransfer.effectAllowed = 'move';
        }

        // 드래그 시작 (선택 목록에서)
        function condDragStartFromSelected(event, seq, name) {
            event.target.classList.add('dragging');
            event.dataTransfer.setData('application/json', JSON.stringify({ seq, name, from: 'selected' }));
            event.dataTransfer.effectAllowed = 'move';
        }

        // 드래그 끝
        function condDragEnd(event) {
            event.target.classList.remove('dragging');
        }

        // 선택 영역 드래그 오버
        function condHandleDragOver(event) {
            event.preventDefault();
            event.dataTransfer.dropEffect = 'move';
            document.getElementById('condSelectedDropZone').classList.add('dragover');
        }

        // 선택 영역 드래그 떠남
        function condHandleDragLeave(event) {
            document.getElementById('condSelectedDropZone').classList.remove('dragover');
        }

        // 선택 영역에 드롭
        function condHandleDrop(event) {
            event.preventDefault();
            document.getElementById('condSelectedDropZone').classList.remove('dragover');

            try {
                const data = JSON.parse(event.dataTransfer.getData('application/json'));
                if (data.from === 'all') {
                    // 전체 목록에서 선택 목록으로 이동
                    if (!selectedConditionsForRealtime.some(c => c.seq === data.seq)) {
                        selectedConditionsForRealtime.push({ seq: data.seq, name: data.name });
                        renderConditionAllList();
                        renderConditionSelectedList();
                    }
                }
            } catch (e) {
                console.error('[조건선택] 드롭 오류:', e);
            }
        }

        // 전체 목록 영역 드래그 오버
        function condHandleListDragOver(event) {
            event.preventDefault();
            event.dataTransfer.dropEffect = 'move';
            document.getElementById('condAllList').style.background = 'rgba(239, 68, 68, 0.1)';
        }

        // 전체 목록 영역 드래그 떠남
        function condHandleListDragLeave(event) {
            document.getElementById('condAllList').style.background = '';
        }

        // 전체 목록 영역에 드롭 (선택 해제)
        function condHandleListDrop(event) {
            event.preventDefault();
            document.getElementById('condAllList').style.background = '';

            try {
                const data = JSON.parse(event.dataTransfer.getData('application/json'));
                if (data.from === 'selected') {
                    // 선택 목록에서 전체 목록으로 이동 (제거)
                    selectedConditionsForRealtime = selectedConditionsForRealtime.filter(c => c.seq !== data.seq);
                    renderConditionAllList();
                    renderConditionSelectedList();
                }
            } catch (e) {
                console.error('[조건선택] 드롭 오류:', e);
            }
        }

        // 선택 목록에서 제거
        function condRemoveFromSelected(seq) {
            selectedConditionsForRealtime = selectedConditionsForRealtime.filter(c => c.seq !== seq);
            renderConditionAllList();
            renderConditionSelectedList();
        }

        // 전체 선택
        function condSelectAll() {
            selectedConditionsForRealtime = conditions.map(c => ({ seq: c.seq, name: c.name }));
            renderConditionAllList();
            renderConditionSelectedList();
        }

        // 전체 삭제
        function condClearSelected() {
            selectedConditionsForRealtime = [];
            renderConditionAllList();
            renderConditionSelectedList();
        }

        // 저장 버튼 클릭
        function saveSelectedConditions() {
            saveSelectedConditionsToStorage();
            closeConditionSelectModal();
            addLog(`실시간 감시 검색식 ${selectedConditionsForRealtime.length}개 저장 완료`, 'success');
        }

        // 선택된 조건만 실시간 시작
        async function startSelectedConditions() {
            if (selectedConditionsForRealtime.length === 0) {
                alert('실시간 감시할 검색식을 먼저 선택하세요.');
                return;
            }

            addLog(`선택된 ${selectedConditionsForRealtime.length}개 조건 실시간 시작...`, 'info');
            document.getElementById('conditionMonitorStatus').textContent = '시작 중...';

            try {
                // 1. Desktop Token 전달 — StockClaw Kit 로컬 모드에서는 불필요
                // conditionSetToken은 HTTP 버전에서 불필요 (서버가 직접 관리)

                // 2. 선택된 조건들만 실시간 감시 요청
                for (const cond of selectedConditionsForRealtime) {
                    const res = await fetch(`${API_BASE}/api/kiwoom/condition/realtime`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({seq: cond.seq})});
                    const result = await res.json();
                    if (result.ok) {
                        addLog(`실시간 시작: ${cond.name}`, 'success');
                    }
                    await new Promise(r => setTimeout(r, 300));
                }

                // 3. 모니터링 시작 요청 (선택된 조건만)
                await fetch(`${API_BASE}/api/kiwoom/condition/realtime`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({conditions: selectedConditionsForRealtime.map(c => ({ seq: c.seq, name: c.name }))})});

                isRealtimeMonitoring = true;
                document.getElementById('btnStartAll').style.display = 'none';
                document.getElementById('btnStopAll').style.display = 'inline-flex';
                document.getElementById('btnStopAll').disabled = false;
                document.getElementById('realtimeStatus').innerHTML = '<span style="color: var(--success);"><i class="fas fa-circle fa-xs"></i> 실시간 감시 중</span>';
                document.getElementById('realtimeEmpty').style.display = 'none';
                document.getElementById('realtimeTableContainer').style.display = 'block';
                document.getElementById('conditionMonitorStatus').textContent = `${selectedConditionsForRealtime.length}개 감시 중`;

                // 4. 렌더러 폴링도 시작
                startRealtimePolling();

            } catch (e) {
                addLog(`실시간 시작 오류: ${e.message}`, 'error');
                document.getElementById('conditionMonitorStatus').textContent = '오류';
            }
        }

        // 실시간 이벤트 리스너 (메인 프로세스에서 변환된 데이터 수신)
        let realtimeEventListenerRegistered = false;

        function startRealtimePolling() {
            // 이미 등록되어 있으면 스킵
            if (realtimeEventListenerRegistered) return;

            console.warn('[조건검색] 실시간 조건검색은 미지원');
            realtimeEventListenerRegistered = true;
        }

        function stopRealtimePolling() {
            // 이벤트 리스너는 별도 해제 불필요 (페이지 언로드 시 자동 해제)
            realtimeEventListenerRegistered = false;
        }

        // ========== 조건검색 상태 동기화 (페이지 복귀 시) ==========
        async function syncConditionRealtimeStatus() {
            try {
                const res = await fetch(`${API_BASE}/api/kiwoom/condition/list`, {method: 'POST', headers: {'Content-Type': 'application/json'}});
                const status = await res.json();

                if (status.isActive) {
                    // 메인 프로세스에서 모니터링 중이면 UI 동기화
                    isRealtimeMonitoring = true;
                    conditions = status.conditions || [];

                    // 메인 프로세스 이벤트 형식 → 렌더러 형식 변환
                    const rawEvents = status.todayEvents || [];
                    realtimeResults = rawEvents.map(e => ({
                        time: e.time || '',
                        code: e.stockCode || '',
                        name: e.stockName || e.stockCode,
                        price: e.price || 0,
                        change: e.changeRate || 0,
                        volume: e.volume || 0,
                        tradeAmount: e.tradeAmount || 0,
                        conditionName: e.conditionName || '',
                        type: e.eventType || 'entry'
                    }));

                    // UI 업데이트
                    document.getElementById('btnStartAll').style.display = 'none';
                    document.getElementById('btnStopAll').style.display = 'inline-flex';
                    document.getElementById('btnStopAll').disabled = false;
                    document.getElementById('realtimeStatus').innerHTML = '<span style="color: var(--success);"><i class="fas fa-circle fa-xs"></i> 실시간 감시 중</span>';
                    document.getElementById('realtimeEmpty').style.display = 'none';
                    document.getElementById('realtimeTableContainer').style.display = 'block';
                    document.getElementById('conditionMonitorStatus').textContent = `${conditions.length}개 감시 중`;

                    // 조건 목록 드롭다운 채우기 (seq 순서대로 정렬)
                    if (conditions.length > 0) {
                        const select = document.getElementById('conditionSelect');
                        select.innerHTML = '<option value="">-- 조건식 선택 --</option>';
                        const sortedConditions = [...conditions].sort((a, b) => parseInt(a.seq) - parseInt(b.seq));
                        sortedConditions.forEach(cond => {
                            const opt = document.createElement('option');
                            opt.value = cond.seq;
                            opt.textContent = `#${cond.seq} ${cond.name}`;
                            select.appendChild(opt);
                        });
                        select.disabled = false;
                        document.getElementById('btnStartAll').disabled = false;
                    }

                    // 결과 렌더링
                    renderRealtimeResults();

                    // 폴링 시작 (UI 업데이트용)
                    startRealtimePolling();

                    addLog(`실시간 상태 복원: ${conditions.length}개 조건, ${realtimeResults.length}개 이벤트`, 'info');
                }
            } catch (e) {
                console.error('조건검색 상태 동기화 오류:', e);
            }
        }

        // ========== 조건검색 이력 조회 (로컬 메모리 + 서버 DB) ==========
        let historyDate = null;  // 현재 조회 중인 날짜
        let historyEvents = [];  // 조회된 이력

        async function loadConditionHistory(date) {
            historyDate = date || getTodayDateKST();
            document.getElementById('historyDateInput').value = historyDate;
            document.getElementById('historyLoading').style.display = 'block';
            document.getElementById('historyTableContainer').style.display = 'none';
            document.getElementById('historyEmpty').style.display = 'none';

            const today = getTodayDateKST();

            try {
                // 오늘 날짜면 로컬 메모리에서 조회
                if (historyDate === today) {
                    const res = await fetch(`${API_BASE}/api/kiwoom/condition/list`, {method: 'POST', headers: {'Content-Type': 'application/json'}});
                    const status = await res.json();
                    const rawEvents = status.todayEvents || [];

                    // 메인 프로세스 이벤트 형식 → 이력 형식 변환
                    historyEvents = rawEvents.map(e => ({
                        stockCode: e.stockCode || '',
                        stockName: e.stockName || e.stockCode,
                        eventType: e.eventType || 'entry',
                        conditionName: e.conditionName || '',
                        time: e.time || '',
                        price: e.price || 0,
                        changeRate: e.changeRate || 0,
                        volume: e.volume || 0,
                        tradeAmount: e.tradeAmount || 0
                    }));

                    document.getElementById('historyLoading').style.display = 'none';

                    if (historyEvents.length > 0) {
                        renderHistoryResults();
                        document.getElementById('historyTableContainer').style.display = 'block';
                    } else {
                        document.getElementById('historyEmpty').style.display = 'flex';
                    }
                } else {
                    // 과거 날짜는 서버 DB에서 조회
                    const token = null;  // StockClaw Kit 로컬 모드
                    if (!token) {
                        addLog('이력 조회: 로그인이 필요합니다', 'error');
                        document.getElementById('historyLoading').style.display = 'none';
                        document.getElementById('historyEmpty').style.display = 'flex';
                        return;
                    }

                    const response = await fetch(`https://readinginvestor.com/api/kiwoom/realtime/events?date=${historyDate}`, {
                        headers: { 'Authorization': `Bearer ${token}` }
                    });
                    const data = await response.json();

                    document.getElementById('historyLoading').style.display = 'none';

                    if (data.success && data.events && data.events.length > 0) {
                        historyEvents = data.events;
                        renderHistoryResults();
                        document.getElementById('historyTableContainer').style.display = 'block';
                    } else {
                        document.getElementById('historyEmpty').style.display = 'flex';
                    }
                }
            } catch (e) {
                console.error('이력 조회 오류:', e);
                document.getElementById('historyLoading').style.display = 'none';
                document.getElementById('historyEmpty').style.display = 'flex';
                addLog(`이력 조회 오류: ${e.message}`, 'error');
            }
        }

        function renderHistoryResults() {
            const showExited = document.getElementById('chkHistoryShowExited')?.checked ?? true;
            const filtered = showExited ? historyEvents : historyEvents.filter(r => r.eventType === 'entry');

            document.getElementById('historyCount').textContent = `(${filtered.length})`;

            const tbody = document.getElementById('historyBody');
            tbody.innerHTML = '';

            filtered.slice(0, 200).forEach(item => {
                const tr = document.createElement('tr');
                tr.style.cursor = 'pointer';
                tr.onclick = () => openStockDetailTab(item.stockCode, item.stockName || '');
                const isEntry = item.eventType === 'entry';
                const statusColor = isEntry ? 'var(--success)' : 'var(--danger)';
                const statusIcon = isEntry ? 'fa-arrow-up' : 'fa-arrow-down';
                const statusText = isEntry ? '편입' : '이탈';
                const changeColor = item.changeRate > 0 ? 'var(--danger)' : item.changeRate < 0 ? 'var(--info)' : 'var(--text-muted)';
                const changePrefix = item.changeRate > 0 ? '+' : '';

                tr.innerHTML = `
                    <td style="color: ${statusColor}; text-align: center;">
                        <i class="fas ${statusIcon}"></i> ${statusText}
                    </td>
                    <td style="text-align: center; color: var(--text-muted);">${item.time || '-'}</td>
                    <td style="text-align: center;">${item.stockCode}</td>
                    <td>${item.stockName || '-'}</td>
                    <td style="text-align: right;">${(item.price || 0).toLocaleString()}</td>
                    <td style="text-align: right; color: ${changeColor};">${changePrefix}${(item.changeRate || 0).toFixed(2)}%</td>
                    <td style="text-align: right;">${(item.volume || 0).toLocaleString()}</td>
                    <td style="color: var(--text-muted);">${item.conditionName || '-'}</td>
                `;
                tbody.appendChild(tr);
            });
        }

        function filterHistoryResults() {
            renderHistoryResults();
        }

        function getTodayDateKST() {
            const now = new Date();
            const kstOffset = 9 * 60 * 60 * 1000;
            const kstDate = new Date(now.getTime() + kstOffset);
            return kstDate.toISOString().split('T')[0];
        }
