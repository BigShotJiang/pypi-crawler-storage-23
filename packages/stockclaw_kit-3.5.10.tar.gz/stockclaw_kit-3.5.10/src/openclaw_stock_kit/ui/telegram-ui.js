/**
 * 텔레그램 UI 컨트롤러
 *
 * 텔레그램 관련 모든 UI 패널의 이벤트 핸들러와 렌더링 로직
 */

// ============================================================
// XSS 방어 유틸리티
// ============================================================

// HTML 특수문자 이스케이프 - innerHTML 사용 시 반드시 적용
function escapeHtmlTg(unsafe) {
    if (unsafe === null || unsafe === undefined) return '';
    return String(unsafe)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// ============================================================
// 상태 관리
// ============================================================

const TelegramUI = {
    // IPC 핸들러 등록 여부 (중복 등록 방지)
    _messageHandlerRegistered: false,

    // 현재 상태
    state: {
        isConnected: false,
        isMonitoring: false,
        channels: [],           // 텔레그램에서 불러온 채널
        savedChannels: [],      // 서버에 저장된 채널
        messages: [],           // 실시간 메시지 버퍼
        messageCount: 0,
        adCount: 0,
        crawlResult: null,
        viewerPage: 1,
        // 실시간 모드
        liveMode: false,
        // 자동 새로고침 관련
        autoRefreshEnabled: false,
        autoRefreshInterval: 10,  // 초
        // 실시간 메시지 고유 인덱스 카운터
        realtimeMsgCounter: 0,
        autoRefreshTimer: null,
        // 광고 키워드 설정 (v2.0 - 기본값 + 사용자 추가/제거)
        addedKeywords: [],      // 사용자가 추가한 키워드
        removedKeywords: [],    // 사용자가 기본에서 제거한 키워드
        tempAddedKeywords: [],  // 모달 편집용 임시 저장
        tempRemovedKeywords: [] // 모달 편집용 임시 저장
    },

    // ============================================================
    // 광고 필터링
    // 3단계 판별: 화이트리스트 → 확실한 광고 패턴 → 의심 키워드 조합
    // ============================================================

    // 🔴 확실한 광고 패턴 (이것만 있으면 바로 광고 판정)
    defaultAdKeywords: [
        '핀업이.*골라놨',
        '베스트\\s*초이스',
        '연말특가|한정판매',
        '📌\\s*최대.*할인',
        '📌.*리워드\\s*쿠폰',
        'VIP\\s*(가입|신청|상담)',
        '무료\\s*(상담|체험)\\s*(신청|문의)',
        '카톡\\s*(상담|문의)',
        '010-\\d{4}-\\d{4}',
        'DM.*문의|문의.*DM',
        '지금\\s*바로\\s*(가입|신청|클릭)',
        '멤버십.*가입',
        '유료\\s*(서비스|구독|가입)',
        '강의\\s*보러\\s*가기',
        'finup\\.co\\.kr',
        'VIP\\s*(회원|멤버|룸|클래스)',
        '수익\\s*인증.*클래스',
        '무료\\s*강의.*신청',
        '입금\\s*전용\\s*계좌',
        '월\\s*\\d+만원\\s*수익',
        '수익률\\s*\\d+%',
        '주식\\s*리딩방',
        '(카카오|카톡).*오픈채팅',
        '텔레그램\\s*채널.*가입',
        '선착순\\s*\\d+명',
        '마감\\s*임박',
        '지금\\s*가입하면',
        '특별\\s*할인',
        '프리미엄\\s*서비스',
        '무료\\s*체험\\s*이벤트',
        '이벤트\\s*참여하기',
        '공짜로\\s*받기',
        '(돈|수익).*벌.*방법',
        '재테크\\s*비법',
        '부자.*되는\\s*법',
        '투자\\s*비법.*공개',
        '비밀\\s*노하우',
        '급등주\\s*추천',
        '오늘의\\s*추천주',
        '종목\\s*추천.*받기',
        '검증된\\s*수익',
        '100%\\s*수익',
        '무조건\\s*수익',
        '손실\\s*없',
        '원금\\s*보장',
        'https?://open\\.kakao\\.com',               // 카카오 오픈채팅
        'bit\\.ly|goo\\.gl|tinyurl',                 // 단축 URL
        '친추.*하시면|친구.*추가',
        '구독.*좋아요',
        '팔로우.*하면',
        '공유.*이벤트',
        '리트윗\\s*이벤트',
        '댓글.*달면',
        '초대.*코드',
        '추천인\\s*코드',
        '가입\\s*링크',
        '지금\\s*클릭',
        '서둘러.*신청',
        '놓치지\\s*마',
        '빨리\\s*신청',
        '한정\\s*수량',
        '오늘만\\s*특가',
        '깜짝\\s*할인',
        '특별\\s*가격',
        '할인\\s*쿠폰',
        '무료\\s*쿠폰',
        '캐시백\\s*이벤트',
        '포인트\\s*적립',
        '아직도\\s*안\\s*(쓰고|쓰나|써봤|사용)',    // "아직도 안쓰고 있나요?"
        '돈\\s*되는|돈되는',                        // "돈되는 뉴스!"
        '(구독|신청)\\s*마감',                      // "[구독 마감 D-1]"
        'D-\\d+.*마감|마감.*D-\\d+',               // "D-1 마감"
        '놓치면\\s*끝',                            // "놓치면 끝!"
        '수익\\s*터지|수익.*터져',                  // "수익 터지는 중!"
        '멘토와\\s*함께',                          // "멘토와 함께하는"
        '일프로\\s*멘토',                          // "일프로 멘토"
        '\\d+일\\s*코스|\\d+일\\s*아카데미',       // "32일 코스", "32일 아카데미"
        'AI\\s*실전매매',                          // "AI 실전매매"
        '버튼만\\s*딸깍',                          // "버튼만 딸깍!"
        '수익\\s*자동화',                          // "수익 자동화"
        'stock\\.finup\\.co\\.kr'                   // finup 강의 URL
    ],

    // 🟡 의심 키워드 (단독으로는 광고 아님, 2개 이상 조합 시 광고) - v2.1
    suspiciousKeywords: [
        '무료강의', '무료체험', '무료상담',
        '수익인증', '수익공개', '인증수익',
        '선착순', '한정', '마감임박',
        '캐시백', '리워드', '보상',
        '프로모션', '특가', '할인가',
        // v2.1 추가
        '코스강의', '아카데미', '커리큘럼',
        '핵심VOD', 'LIVE강의', '검색기'
    ],

    // 🟢 화이트리스트 패턴 (이 패턴이 있으면 광고 아님으로 판정)
    whitelistPatterns: [
        '공시링크\\s*:',
        'dart\\.fss\\.or\\.kr',
        'finance\\.naver\\.com',
        '목표주가',
        '투자의견',
        'EPS|PER|PBR|ROE',
        '실적\\s*발표',
        '분기\\s*실적',
        '공시\\s*확인',
        '기관\\s*매수',
        '외국인\\s*매수',
        '거래량\\s*급증',
        '상한가\\s*도달',
        '신고가\\s*갱신',
        '배당\\s*공시',
        '무상증자',
        '유상증자'
    ],

    // 서버 URL
    serverUrl: 'https://readinginvestor.com',

    // StockClaw Kit API URL (same origin)
    telegramProxyUrl: '',

    // ============================================================
    // 초기화
    // ============================================================

    // 실제 Electron 환경 여부 체크
    isElectron() {
        // contextIsolation이 true면 process 객체가 노출되지 않으므로
        // preload.js에서 노출한 electronAPI 존재 여부로 판단
        return !!(window.electronAPI && window.electronAPI.telegram);
    },

    init() {
        // 날짜 기본값 설정 (한국 시간 기준)
        const getKSTDateString = (date) => {
            const kst = new Date(date.getTime() + 9 * 60 * 60 * 1000); // UTC+9
            return kst.toISOString().split('T')[0];
        };
        const today = getKSTDateString(new Date());
        const weekAgo = getKSTDateString(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000));
        const monthAgo = getKSTDateString(new Date(Date.now() - 30 * 24 * 60 * 60 * 1000));

        const crawlStartDate = document.getElementById('tgCrawlStartDate');
        const crawlEndDate = document.getElementById('tgCrawlEndDate');
        if (crawlStartDate) crawlStartDate.value = weekAgo;
        if (crawlEndDate) crawlEndDate.value = today;

        // 데이터 뷰어 날짜 기본값 설정 (1개월)
        const viewerStartDate = document.getElementById('tgViewerStartDate');
        const viewerEndDate = document.getElementById('tgViewerEndDate');
        if (viewerStartDate) viewerStartDate.value = monthAgo;
        if (viewerEndDate) viewerEndDate.value = today;

        // 로컬 설정 로드
        this.loadLocalConfig();

        // 광고 키워드 로드
        this.loadAdKeywords();

        // 저장된 채널 로드
        this.loadSavedChannels();

        // 데이터 뷰어 채널 목록 로드
        this.loadViewerChannels();

        // 텔레그램 연결 상태 확인 (프록시 서버에서 세션 유지 중일 수 있음)
        this.checkAuth();

        // Electron 환경: 모니터링 상태 동기화 및 메시지 핸들러 등록
        if (this.isElectron()) {
            this.syncMonitoringStatus();
            this.setupMessageHandler();  // 항상 핸들러 등록 (init 시점에)

            // Desktop Token을 메인 프로세스에 전달 (페이지 전환 중에도 서버 저장 가능하도록)
            this.sendDesktopTokenToMain();
        }
    },

    /**
     * Desktop Token을 메인 프로세스에 전달
     * - 페이지 전환 중에도 실시간 메시지를 서버에 저장하기 위해 필요
     */
    async sendDesktopTokenToMain() {
        try {
            const token = localStorage.getItem('desktop_token');
            if (token && window.electronAPI?.telegram?.setDesktopToken) {
                await window.electronAPI.telegram.setDesktopToken(token);
                console.log('[TelegramUI] Desktop Token을 메인 프로세스에 전달 완료');
            }
        } catch (error) {
            console.error('[TelegramUI] Desktop Token 전달 오류:', error);
        }
    },

    /**
     * Main Process의 모니터링 상태와 UI 동기화
     */
    async syncMonitoringStatus() {
        try {
            const status = await this.callTelegramAPI('getMonitoringStatus');
            console.log('[TelegramUI] 모니터링 상태 동기화:', status);

            if (status.isMonitoring) {
                this.state.isMonitoring = true;
                this.updateMonitoringUI(true);
                console.log('[TelegramUI] 모니터링 중 상태로 UI 복원');

                // 페이지 전환 중 누락된 메시지가 있을 수 있으므로 서버에서 최신 메시지 로드
                console.log('[TelegramUI] 누락 메시지 복구를 위해 서버 DB 조회...');
                await this.loadMessages();
            }
        } catch (error) {
            console.error('[TelegramUI] 모니터링 상태 확인 오류:', error);
        }
    },

    // ============================================================
    // 로컬 설정 관리
    // ============================================================

    loadLocalConfig() {
        try {
            const config = localStorage.getItem('telegram_config');
            if (config) {
                const parsed = JSON.parse(config);
                const apiIdEl = document.getElementById('tgApiId');
                const apiHashEl = document.getElementById('tgApiHash');
                const phoneEl = document.getElementById('tgPhoneNumber');

                if (apiIdEl && parsed.api_id) apiIdEl.value = parsed.api_id;
                if (apiHashEl && parsed.api_hash) apiHashEl.value = parsed.api_hash;
                if (phoneEl && parsed.phone_number) phoneEl.value = parsed.phone_number;
            }
        } catch (e) {
            console.error('[TelegramUI] 설정 로드 오류:', e);
        }
    },

    saveLocalConfig(config) {
        try {
            const existing = JSON.parse(localStorage.getItem('telegram_config') || '{}');
            const merged = { ...existing, ...config };
            localStorage.setItem('telegram_config', JSON.stringify(merged));
            return true;
        } catch (e) {
            console.error('[TelegramUI] 설정 저장 오류:', e);
            return false;
        }
    },

    // ============================================================
    // 인증 관련
    // ============================================================

    async checkAuth() {
        this.showLoading('tgAuthStatusInfo', '상태 확인 중...');

        try {
            // Electron API 호출 (또는 프록시 서버)
            const result = await this.callTelegramAPI('checkAuth');

            if (result.authenticated) {
                this.state.isConnected = true;
                this.updateAuthUI(true, result.user);
            } else {
                // 연결되지 않았지만 세션이 있는 경우 자동 연결 시도
                if (result.hasSession) {
                    console.log('[TelegramUI] 기존 세션 발견 - 자동 연결 시도');
                    await this.tryAutoConnect();
                } else {
                    this.state.isConnected = false;
                    this.updateAuthUI(false);
                }
            }
        } catch (error) {
            console.error('[TelegramUI] 인증 확인 오류:', error);
            this.showError('tgAuthStatusInfo', error.message);
        }
    },

    // 기존 세션으로 자동 연결 시도
    async tryAutoConnect() {
        this.showLoading('tgAuthStatusInfo', '기존 세션으로 연결 중...');

        try {
            const result = await this.callTelegramAPI('tryConnect');
            console.log('[TelegramUI] tryAutoConnect 결과:', result);

            // success: true이면 연결 성공 (status 필드 체크 제거)
            if (result.success && result.user) {
                this.state.isConnected = true;
                this.updateAuthUI(true, result.user);
                console.log('[TelegramUI] 자동 연결 성공:', result.user?.firstName || result.user?.username);
            } else {
                this.state.isConnected = false;
                this.updateAuthUI(false);
                console.log('[TelegramUI] 자동 연결 실패 - 재인증 필요:', result.error || '알 수 없음');
            }
        } catch (error) {
            console.error('[TelegramUI] 자동 연결 오류:', error);
            this.state.isConnected = false;
            this.updateAuthUI(false);
        }
    },

    async saveApiSettings() {
        const apiId = document.getElementById('tgApiId')?.value?.trim();
        const apiHash = document.getElementById('tgApiHash')?.value?.trim();

        if (!apiId || !apiHash) {
            alert('API ID와 API Hash를 모두 입력해주세요.');
            return;
        }

        if (this.saveLocalConfig({ api_id: apiId, api_hash: apiHash })) {
            alert('API 설정이 저장되었습니다.');
        } else {
            alert('저장에 실패했습니다.');
        }
    },

    async startAuth() {
        const apiId = document.getElementById('tgApiId')?.value?.trim();
        const apiHash = document.getElementById('tgApiHash')?.value?.trim();
        const phoneNumber = document.getElementById('tgPhoneNumber')?.value?.trim();

        if (!apiId || !apiHash || !phoneNumber) {
            alert('API ID, API Hash, 전화번호를 모두 입력해주세요.');
            return;
        }

        this.saveLocalConfig({ api_id: apiId, api_hash: apiHash, phone_number: phoneNumber });

        try {
            const result = await this.callTelegramAPI('startAuth', { apiId, apiHash, phoneNumber });

            if (result.success) {
                if (result.status === 'code_required') {
                    document.getElementById('tgCodeSection').style.display = 'block';
                    document.getElementById('tgAuthCode').focus();
                    alert('인증 코드가 텔레그램으로 전송되었습니다.');
                }
            } else {
                alert('인증 시작 실패: ' + result.error);
            }
        } catch (error) {
            console.error('[TelegramUI] 인증 시작 오류:', error);
            alert('오류: ' + error.message);
        }
    },

    async submitCode() {
        const code = document.getElementById('tgAuthCode')?.value?.trim();

        if (!code) {
            alert('인증 코드를 입력해주세요.');
            return;
        }

        try {
            const result = await this.callTelegramAPI('submitCode', { code });

            if (result.success) {
                if (result.status === 'password_required') {
                    document.getElementById('tgCodeSection').style.display = 'none';
                    document.getElementById('tgPasswordSection').style.display = 'block';
                    document.getElementById('tgPassword').focus();
                    alert('2단계 인증 비밀번호를 입력해주세요.');
                } else if (result.status === 'authenticated') {
                    this.state.isConnected = true;
                    this.updateAuthUI(true);
                    document.getElementById('tgCodeSection').style.display = 'none';
                    alert('인증이 완료되었습니다!');
                }
            } else {
                alert('코드 인증 실패: ' + result.error);
            }
        } catch (error) {
            console.error('[TelegramUI] 코드 제출 오류:', error);
            alert('오류: ' + error.message);
        }
    },

    async submitPassword() {
        const password = document.getElementById('tgPassword')?.value;

        if (!password) {
            alert('비밀번호를 입력해주세요.');
            return;
        }

        try {
            const result = await this.callTelegramAPI('submitPassword', { password });

            if (result.success) {
                this.state.isConnected = true;
                this.updateAuthUI(true);
                document.getElementById('tgPasswordSection').style.display = 'none';
                alert('인증이 완료되었습니다!');
            } else {
                alert('비밀번호 인증 실패: ' + result.error);
            }
        } catch (error) {
            console.error('[TelegramUI] 비밀번호 제출 오류:', error);
            alert('오류: ' + error.message);
        }
    },

    async tryConnect() {
        this.showLoading('tgAuthStatusInfo', '기존 세션으로 연결 시도 중...');

        try {
            const result = await this.callTelegramAPI('tryConnect');

            if (result.success) {
                this.state.isConnected = true;
                this.updateAuthUI(true);
                alert('연결 성공!');
            } else {
                this.updateAuthUI(false);
                alert('연결 실패: ' + (result.error || '세션이 없거나 만료되었습니다.'));
            }
        } catch (error) {
            console.error('[TelegramUI] 연결 시도 오류:', error);
            this.showError('tgAuthStatusInfo', error.message);
        }
    },

    async disconnect() {
        if (!confirm('텔레그램 연결을 해제하시겠습니까?')) return;

        try {
            await this.callTelegramAPI('disconnect');
            this.state.isConnected = false;
            this.updateAuthUI(false);
            alert('연결이 해제되었습니다.');
        } catch (error) {
            console.error('[TelegramUI] 연결 해제 오류:', error);
            alert('오류: ' + error.message);
        }
    },

    updateAuthUI(connected, user = null) {
        const badge = document.getElementById('tgAuthStatusBadge');
        const info = document.getElementById('tgAuthStatusInfo');
        const disconnectBtn = document.getElementById('tgDisconnectBtn');

        if (connected) {
            badge.style.background = 'rgba(34,197,94,0.2)';
            badge.style.color = '#22c55e';
            badge.textContent = '연결됨';

            if (user) {
                info.innerHTML = `
                    <div style="color: var(--success);">
                        <i class="fas fa-check-circle"></i> 연결됨
                    </div>
                    <div style="margin-top: 8px; color: var(--text);">
                        ${user.firstName || ''} ${user.lastName || ''}
                        ${user.username ? `(@${user.username})` : ''}
                    </div>
                    <div style="color: var(--text-muted); font-size: 12px;">${user.phone || ''}</div>
                `;
            } else {
                info.innerHTML = '<div style="color: var(--success);"><i class="fas fa-check-circle"></i> 텔레그램에 연결되었습니다.</div>';
            }

            disconnectBtn.style.display = 'inline-flex';

            // 연결 성공 시 채널 목록 자동 불러오기
            this.loadChannels();
        } else {
            badge.style.background = 'rgba(239,68,68,0.2)';
            badge.style.color = '#ef4444';
            badge.textContent = '연결 안됨';
            info.innerHTML = '<span style="color: var(--text-muted);">텔레그램 인증이 필요합니다.</span>';
            disconnectBtn.style.display = 'none';
        }

        // 모니터링 상태도 업데이트
        document.getElementById('tgMonitorStatus').textContent = connected ? '연결됨' : '미연결';
    },

    // ============================================================
    // 채널 관리
    // ============================================================

    async loadChannels() {
        const listEl = document.getElementById('tgChannelList');
        this.showLoading('tgChannelList', '채널 목록을 불러오는 중...');

        try {
            const result = await this.callTelegramAPI('getDialogs');

            if (result.success) {
                this.state.channels = result.channels;
                this.renderChannelList(result.channels);
            } else {
                this.showError('tgChannelList', result.error || '채널 목록을 불러올 수 없습니다.');
            }
        } catch (error) {
            console.error('[TelegramUI] 채널 로드 오류:', error);
            this.showError('tgChannelList', error.message);
        }
    },

    renderChannelList(channels) {
        const listEl = document.getElementById('tgChannelList');

        if (!channels || channels.length === 0) {
            listEl.innerHTML = '<div style="text-align: center; padding: 30px; color: var(--text-muted);">참여 중인 채널/그룹이 없습니다.</div>';
            return;
        }

        const savedIds = this.state.savedChannels.map(c => c.channel_id);

        listEl.innerHTML = channels.map(ch => {
            const isSaved = savedIds.includes(ch.channel_id);
            return `
            <div class="channel-item" draggable="true"
                 data-channel='${JSON.stringify(ch).replace(/'/g, "&#39;")}'
                 ondragstart="tgHandleDragStart(event)"
                 ondragend="tgHandleDragEnd(event)"
                 style="display: flex; align-items: center; gap: 12px; padding: 10px; border-bottom: 1px solid var(--border); cursor: grab; transition: opacity 0.2s, background 0.2s; ${isSaved ? 'opacity: 0.5; background: var(--bg-dark);' : ''}">
                <input type="checkbox" class="tg-channel-checkbox" data-id="${ch.channel_id}" ${isSaved ? 'checked' : ''}>
                <i class="fas fa-grip-vertical" style="color: var(--text-muted); font-size: 12px;"></i>
                <div style="flex: 1;">
                    <div style="font-weight: 500;">${this.escapeHtml(ch.channel_name)}</div>
                    <div style="font-size: 12px; color: var(--text-muted);">
                        ${ch.channel_username ? `@${ch.channel_username}` : ch.channel_id}
                        <span style="margin-left: 8px; padding: 2px 6px; background: var(--bg-dark); border-radius: 4px; font-size: 11px;">
                            ${ch.channel_type}
                        </span>
                        ${isSaved ? '<span style="margin-left: 6px; color: var(--success);"><i class="fas fa-check"></i> 저장됨</span>' : ''}
                    </div>
                </div>
            </div>
        `}).join('');
    },

    selectAllChannels() {
        document.querySelectorAll('.tg-channel-checkbox').forEach(cb => cb.checked = true);
    },

    deselectAllChannels() {
        document.querySelectorAll('.tg-channel-checkbox').forEach(cb => cb.checked = false);
    },

    async saveChannels() {
        const selected = [];
        document.querySelectorAll('.tg-channel-checkbox:checked').forEach(cb => {
            const id = cb.dataset.id;
            const channel = this.state.channels.find(c => c.channel_id === id);
            if (channel) selected.push(channel);
        });

        if (selected.length === 0) {
            alert('저장할 채널을 선택해주세요.');
            return;
        }

        // 브라우저 환경에서는 로컬 저장
        if (!this.isElectron()) {
            // localStorage에 저장
            const existing = JSON.parse(localStorage.getItem('telegram_saved_channels') || '[]');
            const merged = [...existing];

            for (const ch of selected) {
                const idx = merged.findIndex(c => c.channel_id === ch.channel_id);
                if (idx >= 0) {
                    merged[idx] = { ...ch, is_active: true };
                } else {
                    merged.push({ ...ch, is_active: true });
                }
            }

            localStorage.setItem('telegram_saved_channels', JSON.stringify(merged));
            alert(`${selected.length}개 채널이 로컬에 저장되었습니다.\n(브라우저 환경 - 서버 저장 불가)`);
            this.loadSavedChannels();
            return;
        }

        try {
            const response = await this.callServerAPI(`${this.serverUrl}/api/telegram/channels/bulk`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ channels: selected })
            });

            if (response.browserMode) return;

            const result = await response.json();

            if (result.success) {
                alert(result.message);
                this.loadSavedChannels();
            } else {
                alert('저장 실패: ' + result.error);
            }
        } catch (error) {
            console.error('[TelegramUI] 채널 저장 오류:', error);
            alert('오류: ' + error.message);
        }
    },

    // 드래그로 채널 추가 (항상 로컬 저장 - 앱에서 서버 호출 불필요)
    async addChannelByDrag(channel) {
        // 이미 저장된 채널인지 확인
        const savedIds = this.state.savedChannels.map(c => c.channel_id);
        if (savedIds.includes(channel.channel_id)) {
            console.log('[TelegramUI] 이미 저장된 채널:', channel.channel_name);
            return;
        }

        // 로컬 저장 (브라우저/Electron 모두)
        const existing = JSON.parse(localStorage.getItem('telegram_saved_channels') || '[]');
        existing.push({ ...channel, is_active: true });
        localStorage.setItem('telegram_saved_channels', JSON.stringify(existing));
        this.loadSavedChannels();
        // 좌측 목록도 갱신 (저장됨 표시)
        this.renderChannelList(this.state.channels);
        console.log('[TelegramUI] 드래그로 채널 추가:', channel.channel_name);
    },

    // 드래그로 채널 제거 (항상 로컬 저장 - 앱에서 서버 호출 불필요)
    async removeChannelByDrag(channelId) {
        const channels = JSON.parse(localStorage.getItem('telegram_saved_channels') || '[]');
        const filtered = channels.filter(c => c.channel_id !== channelId);
        localStorage.setItem('telegram_saved_channels', JSON.stringify(filtered));
        this.loadSavedChannels();
        this.renderChannelList(this.state.channels);
        console.log('[TelegramUI] 드래그로 채널 제거:', channelId);
    },

    async loadSavedChannels() {
        // 항상 localStorage에서 로드 (앱에서 서버 호출 불필요)
        const channels = JSON.parse(localStorage.getItem('telegram_saved_channels') || '[]');
        this.state.savedChannels = channels;
        this.renderSavedChannels(channels);
        this.updateChannelCounts(channels);
        console.log('[TelegramUI] 로컬 저장 채널 로드:', channels.length);
    },

    async clearSavedChannels() {
        if (!confirm('저장된 모든 채널을 삭제하시겠습니까?')) {
            return;
        }

        // 항상 로컬 저장 삭제 (앱에서 서버 호출 불필요)
        localStorage.removeItem('telegram_saved_channels');
        this.state.savedChannels = [];
        this.renderSavedChannels([]);
        this.updateChannelCounts([]);
        // 좌측 목록도 갱신 (저장됨 표시 제거)
        this.renderChannelList(this.state.channels);
        console.log('[TelegramUI] 저장된 채널 삭제 완료');
    },

    updateChannelCounts(channels) {
        const activeChannels = channels.filter(c => c.is_active);

        const crawlInfoEl = document.getElementById('tgCrawlChannelInfo');
        if (crawlInfoEl) {
            crawlInfoEl.innerHTML = `
                <span style="color: var(--success);">${activeChannels.length}개 채널</span> 활성화됨
            `;
        }

        const monitorChannelsEl = document.getElementById('tgMonitorChannels');
        if (monitorChannelsEl) {
            monitorChannelsEl.textContent = activeChannels.length;
        }
    },

    renderSavedChannels(channels) {
        const listEl = document.getElementById('tgSavedChannelList');
        const countEl = document.getElementById('tgSavedChannelCount');

        countEl.textContent = `${channels.length}개`;

        if (!channels || channels.length === 0) {
            listEl.innerHTML = `<div style="text-align: center; padding: 60px 20px; color: var(--text-muted); font-size: 13px;">
                <i class="fas fa-inbox" style="font-size: 32px; margin-bottom: 12px; display: block; opacity: 0.3;"></i>
                좌측에서 채널을 드래그하여 추가하세요<br>
                <span style="font-size: 11px; margin-top: 8px; display: block;">저장된 채널은 메시지 뷰어에서<br>모니터링/크롤링할 수 있습니다</span>
            </div>`;
            return;
        }

        // 브라우저: channel_id 사용, Electron: DB id 사용
        const useChannelId = !this.isElectron();

        listEl.innerHTML = channels.map(ch => {
            const identifier = useChannelId ? ch.channel_id : ch.id;
            const identifierStr = useChannelId ? `'${ch.channel_id}'` : ch.id;

            return `
            <div class="saved-channel-item" draggable="true"
                 data-channel-id="${ch.channel_id}"
                 ondragstart="tgHandleSavedDragStart(event, '${ch.channel_id}')"
                 ondragend="tgHandleSavedDragEnd(event)"
                 style="display: flex; align-items: center; gap: 12px; padding: 10px; border-bottom: 1px solid var(--border); cursor: grab; transition: opacity 0.2s;">
                <i class="fas fa-grip-vertical" style="color: var(--text-muted); font-size: 12px;"></i>
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                    <input type="checkbox" class="tg-saved-channel-toggle" data-id="${identifier}" ${ch.is_active ? 'checked' : ''} onchange="TelegramUI.toggleChannelActive(${identifierStr}, this.checked)">
                    <span style="font-size: 12px; color: ${ch.is_active ? 'var(--success)' : 'var(--text-muted)'};">
                        ${ch.is_active ? '활성' : '비활성'}
                    </span>
                </label>
                <div style="flex: 1;">
                    <div style="font-weight: 500;">${this.escapeHtml(ch.channel_name || 'Unknown')}</div>
                    <div style="font-size: 12px; color: var(--text-muted);">
                        ${ch.channel_username ? `@${ch.channel_username}` : ch.channel_id}
                    </div>
                </div>
                <button class="btn btn-sm btn-danger" onclick="TelegramUI.deleteChannel(${identifierStr})" title="삭제">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `}).join('');
    },

    async toggleChannelActive(id, active) {
        // 브라우저 환경: localStorage 업데이트
        if (!this.isElectron()) {
            const channels = JSON.parse(localStorage.getItem('telegram_saved_channels') || '[]');
            const idx = channels.findIndex(c => c.channel_id === id);
            if (idx >= 0) {
                channels[idx].is_active = active;
                localStorage.setItem('telegram_saved_channels', JSON.stringify(channels));
                this.loadSavedChannels();
            }
            return;
        }

        try {
            const response = await this.callServerAPI(`${this.serverUrl}/api/telegram/channels/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ is_active: active })
            });

            if (response.browserMode) return;

            const result = await response.json();
            if (result.success) {
                this.loadSavedChannels();
            }
        } catch (error) {
            console.error('[TelegramUI] 채널 토글 오류:', error);
        }
    },

    async deleteChannel(id) {
        if (!confirm('이 채널을 삭제하시겠습니까?')) return;

        // 브라우저 환경: localStorage에서 삭제
        if (!this.isElectron()) {
            const channels = JSON.parse(localStorage.getItem('telegram_saved_channels') || '[]');
            const filtered = channels.filter(c => c.channel_id !== id);
            localStorage.setItem('telegram_saved_channels', JSON.stringify(filtered));
            this.loadSavedChannels();
            return;
        }

        try {
            const response = await this.callServerAPI(`${this.serverUrl}/api/telegram/channels/${id}`, {
                method: 'DELETE'
            });

            if (response.browserMode) return;

            const result = await response.json();
            if (result.success) {
                this.loadSavedChannels();
            } else {
                alert('삭제 실패: ' + result.error);
            }
        } catch (error) {
            console.error('[TelegramUI] 채널 삭제 오류:', error);
            alert('오류: ' + error.message);
        }
    },

    // ============================================================
    // 실시간 모니터링
    // ============================================================

    // WebSocket 연결 객체
    monitoringWs: null,

    async startMonitoring() {
        if (!this.state.isConnected) {
            alert('먼저 텔레그램에 연결해주세요.');
            return;
        }

        const activeChannels = this.state.savedChannels.filter(c => c.is_active);
        if (activeChannels.length === 0) {
            alert('모니터링할 채널이 없습니다. 채널 관리에서 채널을 추가해주세요.');
            return;
        }

        try {
            const channelIds = activeChannels.map(c => c.channel_id);

            // 브라우저 환경: 폴링 방식으로 실시간 모니터링
            if (!this.isElectron()) {
                const channelNameMap = {};
                activeChannels.forEach(c => { channelNameMap[c.channel_id] = c.channel_name || c.channel_username || c.channel_id; });

                // 각 채널별 마지막 메시지 ID 추적
                if (!this.state.lastMessageIds) this.state.lastMessageIds = {};

                this.state.isMonitoring = true;
                this.state.messageCount = 0;
                this.state.adCount = 0;
                this.updateMonitoringUI(true);

                // 즉시 1회 실행 + 10초 간격 폴링
                const pollMessages = async () => {
                    for (const channelId of channelIds) {
                        try {
                            const response = await fetch('/api/telegram/messages', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ channel: channelId, limit: 5 })
                            });
                            const result = await response.json();
                            if (result.success && result.messages) {
                                const channelName = channelNameMap[channelId] || result.channel || channelId;
                                const lastId = this.state.lastMessageIds[channelId] || 0;
                                // 메시지는 newest first → 새 메시지만 필터
                                const newMsgs = result.messages.filter(m => (m.id || 0) > lastId);
                                if (newMsgs.length > 0) {
                                    this.state.lastMessageIds[channelId] = Math.max(...newMsgs.map(m => m.id || 0));
                                    for (const m of newMsgs.reverse()) {
                                        // 광고 필터링
                                        const content = m.text || m.content || '';
                                        const isAd = this.isAdMessage(content);
                                        if (isAd) {
                                            this.state.adCount++;
                                            continue;
                                        }
                                        this.state.messageCount++;
                                        const realtimeMsg = {
                                            content: content,
                                            message_date: m.date || '',
                                            channel_name: channelName,
                                            message_id: m.id || '',
                                            views: m.views || 0,
                                            forwards: m.forwards || 0,
                                            is_ad: isAd,
                                        };
                                        this.addRealtimeMessage(realtimeMsg);
                                        // DB에도 저장 (비동기, 실패해도 무시)
                                        fetch('/api/telegram/db/save', {
                                            method: 'POST',
                                            headers: { 'Content-Type': 'application/json' },
                                            body: JSON.stringify({ messages: [realtimeMsg] })
                                        }).catch(e => console.warn('[TelegramUI] 실시간 메시지 DB 저장 실패:', e));
                                    }
                                    // 모니터링 배지 업데이트
                                    const msgCountEl = document.getElementById('tgMonitorMessages');
                                    if (msgCountEl) msgCountEl.textContent = this.state.messageCount;
                                    const badgeEl = document.getElementById('tgMonitorStatusBadge');
                                    if (badgeEl) badgeEl.style.display = 'flex';
                                }
                            }
                        } catch (e) {
                            console.warn('[TelegramUI] 모니터링 폴링 오류:', channelId, e);
                        }
                    }
                };

                await pollMessages();
                this.state.monitoringTimer = setInterval(pollMessages, 10000);
                console.log('[TelegramUI] 브라우저 모니터링 시작: 채널', channelIds.length, '개, 10초 폴링');
                return;
            }

            // Electron 환경: 서버 API 호출 + IPC 메시지 핸들러
            const result = await this.callTelegramAPI('startMonitoring', { channelIds });

            if (result.success) {
                this.state.isMonitoring = true;
                this.state.messageCount = 0;
                this.state.adCount = 0;

                this.updateMonitoringUI(true);

                // 메시지 핸들러는 init()에서 이미 등록됨 (setupMessageHandler() 호출 불필요)

                console.log('[TelegramUI] 모니터링 시작: 채널', result.channels?.length || 0, '개');
            } else {
                alert('모니터링 시작 실패: ' + result.error);
            }
        } catch (error) {
            console.error('[TelegramUI] 모니터링 시작 오류:', error);
            alert('오류: ' + error.message);
        }
    },

    async stopMonitoring() {
        try {
            // 브라우저 환경: 폴링 타이머 및 WebSocket 해제
            if (!this.isElectron()) {
                if (this.state.monitoringTimer) {
                    clearInterval(this.state.monitoringTimer);
                    this.state.monitoringTimer = null;
                }
                if (this.monitoringWs) {
                    this.monitoringWs.close();
                    this.monitoringWs = null;
                }
            } else {
                await this.callTelegramAPI('stopMonitoring');
            }

            this.state.isMonitoring = false;
            this.updateMonitoringUI(false);

            console.log('[TelegramUI] 모니터링 중지');
        } catch (error) {
            console.error('[TelegramUI] 모니터링 중지 오류:', error);
        }
    },

    // 모니터링 UI 상태 업데이트
    updateMonitoringUI(isMonitoring) {
        const startBtn = document.getElementById('tgStartMonitorBtn');
        const stopBtn = document.getElementById('tgStopMonitorBtn');
        const statusEl = document.getElementById('tgMonitorStatus');
        const statusBadge = document.getElementById('tgMonitorStatusBadge');
        const viewerLiveBadge = document.getElementById('tgViewerLiveBadge');

        if (isMonitoring) {
            if (startBtn) startBtn.style.display = 'none';
            if (stopBtn) stopBtn.style.display = 'inline-flex';
            if (statusEl) {
                statusEl.textContent = '모니터링 중';
                statusEl.style.color = 'var(--success)';
            }
            // 모니터링 시작 시 실시간 모드 자동 활성화
            this.state.liveMode = true;
            if (viewerLiveBadge) viewerLiveBadge.style.display = 'flex';
        } else {
            if (startBtn) startBtn.style.display = 'inline-flex';
            if (stopBtn) stopBtn.style.display = 'none';
            if (statusEl) {
                statusEl.textContent = '대기';
                statusEl.style.color = '';
            }
            if (statusBadge) statusBadge.style.display = 'none';
            if (viewerLiveBadge) viewerLiveBadge.style.display = 'none';
            // 모니터링 중지 시 실시간 모드 비활성화
            this.state.liveMode = false;
        }
    },

    // WebSocket 핸들러 설정 (브라우저 환경)
    setupWebSocketHandler() {
        // Electron IPC 모드에서는 WebSocket 불필요 (IPC로 진행상황 수신)
        if (this.isElectron()) {
            console.log('[TelegramUI] Electron IPC 모드 - WebSocket 스킵');
            return;
        }

        // StockClaw Kit 브라우저 환경: WebSocket 미지원
        console.log('[TelegramUI] StockClaw Kit 브라우저 환경 - WebSocket 스킵');
        return;

        // 기존 연결이 있으면 닫기
        if (this.monitoringWs) {
            this.monitoringWs.close();
        }

        const wsUrl = this.telegramProxyUrl.replace('http://', 'ws://').replace('https://', 'wss://');
        console.log('[TelegramUI] WebSocket 연결:', wsUrl);

        this.monitoringWs = new WebSocket(wsUrl);

        this.monitoringWs.onopen = () => {
            console.log('[TelegramUI] WebSocket 연결됨');
        };

        this.monitoringWs.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);

                if (data.type === 'new_message') {
                    this.handleNewMessage(data.data);
                } else if (data.type === 'status') {
                    console.log('[TelegramUI] 서버 상태:', data.data);
                } else if (data.type === 'crawl_start') {
                    // 크롤링 시작
                    this.handleCrawlStart(data.data);
                } else if (data.type === 'crawl_progress') {
                    // 크롤링 진행 상황
                    this.handleCrawlProgress(data.data);
                } else if (data.type === 'crawl_complete') {
                    // 크롤링 완료
                    this.handleCrawlComplete(data.data);
                }
            } catch (e) {
                console.error('[TelegramUI] WebSocket 메시지 파싱 오류:', e);
            }
        };

        this.monitoringWs.onclose = () => {
            console.log('[TelegramUI] WebSocket 연결 해제');
            // 모니터링 중이었다면 재연결 시도
            if (this.state.isMonitoring) {
                console.log('[TelegramUI] WebSocket 재연결 시도...');
                setTimeout(() => this.setupWebSocketHandler(), 3000);
            }
        };

        this.monitoringWs.onerror = (error) => {
            console.error('[TelegramUI] WebSocket 오류:', error);
        };
    },

    setupMessageHandler() {
        // 중복 등록 방지
        if (this._messageHandlerRegistered) {
            console.log('[TelegramUI] 메시지 핸들러 이미 등록됨 - 스킵');
            return;
        }

        // Electron IPC 또는 WebSocket으로 메시지 수신
        if (window.electronAPI?.onTelegramMessage) {
            window.electronAPI.onTelegramMessage((msg) => {
                this.handleNewMessage(msg);
            });
        }

        // 크롤링 진행상황 수신
        if (window.electronAPI?.onTelegramCrawlProgress) {
            window.electronAPI.onTelegramCrawlProgress((progress) => {
                this.handleCrawlProgressIPC(progress);
            });
        }

        // 텔레그램 자동 연결 이벤트 수신
        if (window.electronAPI?.onTelegramAutoConnected) {
            window.electronAPI.onTelegramAutoConnected((result) => {
                if (result.success) {
                    this.state.isConnected = true;
                    this.updateAuthUI(true, result.user);
                }
            });
        }

        this._messageHandlerRegistered = true;
    },

    // IPC로 수신된 크롤링 진행상황 처리
    handleCrawlProgressIPC(progress) {
        if (progress.type === 'progress') {
            const percent = Math.round((progress.currentChannel / progress.totalChannels) * 100);
            const percentEl = document.getElementById('tgCrawlPercent');
            const progressBar = document.getElementById('tgCrawlProgressBar');
            const statusEl = document.getElementById('tgCrawlStatus');

            if (percentEl) percentEl.textContent = percent + '%';
            if (progressBar) progressBar.style.width = percent + '%';

            if (progress.status === 'completed') {
                if (statusEl) statusEl.textContent = progress.currentChannel + '/' + progress.totalChannels + ' 채널';
                this.addCrawlLog('success', progress.channelName + ': ' + progress.collected + '개 수집 (총 ' + progress.totalCollected + '개)');
            } else if (progress.status === 'error') {
                this.addCrawlLog('error', '채널 ' + progress.channelId + ' 오류: ' + progress.error);
            }
        } else if (progress.type === 'complete') {
            const percentEl = document.getElementById('tgCrawlPercent');
            const progressBar = document.getElementById('tgCrawlProgressBar');
            const statusEl = document.getElementById('tgCrawlStatus');

            if (percentEl) percentEl.textContent = '100%';
            if (progressBar) progressBar.style.width = '100%';
            if (statusEl) statusEl.innerHTML = '<i class="fas fa-check-circle" style="color: var(--success); margin-right: 6px;"></i>완료';

            this.addCrawlLog('success', '크롤링 완료: ' + progress.totalChannels + '개 채널, ' + progress.totalMessages + '개 메시지');
        }
    },

    handleNewMessage(msg) {
        console.log('[TelegramUI] 실시간 메시지 수신:', msg.channel_name || msg.channelName);

        this.state.messageCount++;
        if (msg.is_ad || msg.isAd) this.state.adCount++;

        // 채널관리 패널의 모니터링 상태 업데이트
        const msgCountEl = document.getElementById('tgMonitorMessages');
        if (msgCountEl) msgCountEl.textContent = this.state.messageCount;

        // 실시간 뱃지 표시
        const statusBadge = document.getElementById('tgMonitorStatusBadge');
        if (statusBadge) statusBadge.style.display = 'block';

        // 뷰어의 실시간 뱃지도 표시
        const viewerLiveBadge = document.getElementById('tgViewerLiveBadge');
        if (viewerLiveBadge) viewerLiveBadge.style.display = 'block';

        // 서버 DB에 실시간 저장 (비동기)
        this.saveRealtimeMessage(msg);

        // 메시지 버퍼에 추가 (최근 100개)
        this.state.messages.unshift(msg);
        if (this.state.messages.length > 100) {
            this.state.messages.pop();
        }

        // 기존 테이블 상단에 새 메시지 추가 (항상)
        this.addMessageToTable(msg);
    },

    // 실시간 메시지를 서버 DB에 저장
    async saveRealtimeMessage(msg) {
        try {
            // 채널 ID 정규화 함수
            const normalizeChannelId = (channelId) => {
                const str = String(channelId);
                if (str.startsWith('-100')) return str;
                if (str.startsWith('-')) return '-100' + str.substring(1);
                return '-100' + str;
            };

            // camelCase → snake_case 변환
            const serverMsg = {
                channel_id: normalizeChannelId(msg.channelId || msg.channel_id),  // 정규화
                channel_name: msg.channelName || msg.channel_name,
                message_id: msg.messageId || msg.message_id,
                content: msg.content || '',
                has_media: msg.hasMedia || msg.has_media || false,
                media_type: msg.mediaType || msg.media_type || null,
                urls: msg.urls || [],
                is_ad: msg.isAd || msg.is_ad || false,
                views: msg.views || 0,
                forwards: msg.forwards || 0,
                message_date: msg.date || msg.message_date || null,
                image_url: msg.imageUrl || msg.image_url || null
            };

            const saveUrl = `${this.serverUrl}/api/telegram/messages`;
            const response = await this.callServerAPI(saveUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ messages: [serverMsg] })
            });

            if (!response.browserMode && response.ok) {
                const result = await response.json();
                console.log('[TelegramUI] 실시간 메시지 저장:', result.saved > 0 ? '성공' : '중복');
            }
        } catch (error) {
            console.error('[TelegramUI] 실시간 메시지 저장 실패:', error.message);
        }
    },

    // 실시간으로 테이블 최상단에 메시지 추가 (기존 데이터 유지!)
    addMessageToTable(msg) {
        const tbody = document.getElementById('tgViewerTable');
        if (!tbody) return;

        // "메시지 없음" 플레이스홀더 행만 제거 (기존 메시지는 유지!)
        const placeholderRow = tbody.querySelector('tr td[colspan]');
        if (placeholderRow && placeholderRow.parentElement) {
            placeholderRow.parentElement.remove();
        }

        // 필드명 통일 (camelCase/snake_case 둘 다 지원)
        const isAd = msg.is_ad || msg.isAd || false;
        const channelName = msg.channel_name || msg.channelName || '';
        const messageDate = msg.message_date || msg.date || null;
        const messageId = msg.message_id || msg.messageId || '';
        const views = msg.views || 0;
        const forwards = msg.forwards || 0;
        const content = msg.content || '';
        const imageUrl = msg.image_url || msg.imageUrl || '';
        const urls = msg.urls || [];

        // 광고 필터링 체크
        const adFilter = document.getElementById('tgViewerAd')?.value;
        if (adFilter === 'false' && isAd) return;
        if (adFilter === 'true' && !isAd) return;

        // 고유 인덱스 생성 (실시간 메시지용) - 카운터 사용으로 동시 도착 메시지도 구분
        this.state.realtimeMsgCounter++;
        const realtimeIdx = 'rt_' + Date.now() + '_' + this.state.realtimeMsgCounter;

        // 메시지 행 HTML 생성 (renderMessageTable과 동일 구조)
        const time = messageDate ? new Date(messageDate).toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' }) : '';
        const contentPreview = content.length > 0
            ? this.escapeHtml(content).substring(0, 80) + (content.length > 80 ? '...' : '')
            : '<span style="color: var(--text-muted);">내용 없음</span>';
        const fullContent = this.escapeHtml(content).replace(/\n/g, '<br>');

        // 이미지 URL 처리
        let finalImageUrl = '';
        if (imageUrl) {
            if (imageUrl.startsWith('http')) {
                finalImageUrl = imageUrl;
            } else if (this.isElectron()) {
                // Electron 앱: 로컬 파일로 접근 (서버 경로도 로컬 파일 우선)
                const fileName = imageUrl.replace(/^\/telegram\/images\//, '').replace(/^\/telegram-images\//, '');
                finalImageUrl = 'tg-image://' + fileName;
            } else if (imageUrl.startsWith('/telegram-images/')) {
                // 브라우저: 서버 URL로 변환
                finalImageUrl = `https://readinginvestor.com${imageUrl}`;
            } else {
                // 브라우저: same-origin 이미지 경로
                finalImageUrl = '/telegram/image/' + imageUrl;
            }
        }

        // 메시지 행 생성
        const tr = document.createElement('tr');
        tr.className = 'msg-row';
        tr.dataset.msgIdx = realtimeIdx;
        tr.style.cssText = 'cursor: pointer; animation: fadeIn 0.3s; background: rgba(34, 197, 94, 0.1);';
        tr.onclick = () => this.toggleMessageDetail(realtimeIdx);

        // 3초 후 하이라이트 제거
        setTimeout(() => {
            tr.style.background = '';
        }, 3000);

        tr.innerHTML = `
            <td style="font-size: 12px; color: var(--text-muted);">${time}</td>
            <td style="font-size: 13px;">${this.escapeHtml(channelName)}</td>
            <td style="max-width: 400px;">${contentPreview}</td>
            <td style="text-align: right; font-size: 12px;">${views}</td>
            <td style="text-align: center;">${isAd ? '<span style="color: var(--danger); font-size: 11px;">광고</span>' : '-'}</td>
        `;

        // 상세 행 생성
        const detailTr = document.createElement('tr');
        detailTr.className = 'msg-detail';
        detailTr.id = `msg-detail-${realtimeIdx}`;
        detailTr.style.display = 'none';

        let detailHtml = `<td colspan="5" style="padding: 16px; background: var(--bg-dark); border-left: 3px solid var(--accent);">`;

        // 이미지
        if (finalImageUrl) {
            detailHtml += `
                <div style="margin-bottom: 12px;">
                    <img src="${finalImageUrl}" style="max-width: 300px; max-height: 200px; border-radius: 8px; cursor: pointer;"
                         onclick="TelegramUI.showImageModal('${finalImageUrl}'); event.stopPropagation();"
                         onerror="this.style.display='none'">
                </div>`;
        }

        // 전체 내용
        detailHtml += `<div style="font-size: 14px; line-height: 1.6; white-space: pre-wrap;">${fullContent || '<span style="color: var(--text-muted);">내용 없음</span>'}</div>`;

        // URL 링크
        if (urls && urls.length > 0) {
            detailHtml += `<div style="margin-top: 12px; display: flex; flex-wrap: wrap; gap: 8px;">`;
            urls.forEach(url => {
                detailHtml += `<a href="${url}" target="_blank" onclick="event.stopPropagation();"
                    style="font-size: 12px; color: var(--accent); text-decoration: underline; word-break: break-all;">
                    <i class="fas fa-external-link-alt" style="margin-right: 4px;"></i>${url.substring(0, 50)}${url.length > 50 ? '...' : ''}
                </a>`;
            });
            detailHtml += `</div>`;
        }

        // 메타 정보
        detailHtml += `<div style="margin-top: 12px; font-size: 11px; color: var(--text-muted);">
            조회수: ${views} | 전달: ${forwards} | ID: ${messageId}
        </div>`;
        detailHtml += `</td>`;

        detailTr.innerHTML = detailHtml;

        // 최상단에 추가 (상세 행 먼저, 메시지 행 나중에 - insertBefore 순서)
        tbody.insertBefore(detailTr, tbody.firstChild);
        tbody.insertBefore(tr, tbody.firstChild);

        // 최대 200개 행 유지 (100개 메시지 = 200개 행)
        while (tbody.children.length > 200) {
            tbody.removeChild(tbody.lastChild);
        }

        // 카운트 업데이트
        const countEl = document.getElementById('tgViewerCount');
        if (countEl) {
            const currentCount = parseInt(countEl.textContent.replace(/[^0-9]/g, '')) || 0;
            countEl.textContent = '총 ' + (currentCount + 1) + '건';
        }
    },

    // ============================================================
    // 실시간 모드
    // ============================================================

    toggleLiveMode() {
        const checkbox = document.getElementById('tgViewerLiveMode');
        this.state.liveMode = checkbox?.checked || false;

        if (this.state.liveMode) {
            // 실시간 모드 활성화: 현재 데이터 로드 후 새 메시지 즉시 반영
            this.loadMessages();
            console.log('[TelegramUI] 실시간 모드 활성화 - 새 메시지가 즉시 테이블에 추가됩니다');
        } else {
            console.log('[TelegramUI] 실시간 모드 비활성화');
        }
    },

    // ============================================================
    // 일괄 크롤링
    // ============================================================

    async startCrawl() {
        if (!this.state.isConnected) {
            alert('먼저 텔레그램에 연결해주세요.');
            return;
        }

        const startDate = document.getElementById('tgCrawlStartDate')?.value;
        const endDate = document.getElementById('tgCrawlEndDate')?.value;

        if (!startDate || !endDate) {
            alert('시작 날짜와 종료 날짜를 선택해주세요.');
            return;
        }

        const activeChannels = this.state.savedChannels.filter(c => c.is_active);
        if (activeChannels.length === 0) {
            alert('크롤링할 채널이 없습니다.');
            return;
        }

        document.getElementById('tgStartCrawlBtn').style.display = 'none';
        document.getElementById('tgStopCrawlBtn').style.display = 'inline-flex';
        // 진행 섹션 표시
        const progressSection = document.getElementById('tgCrawlProgressSection');
        if (progressSection) progressSection.style.display = 'block';
        document.getElementById('tgCrawlLog').innerHTML = '';
        document.getElementById('tgCrawlStatus').innerHTML = '<i class="fas fa-spinner fa-spin" style="margin-right: 6px;"></i>준비 중...';
        document.getElementById('tgCrawlPercent').textContent = '0%';
        document.getElementById('tgCrawlProgressBar').style.width = '0%';

        const channelIds = activeChannels.map(c => c.channel_id);
        console.log('[TelegramUI] 크롤링 시작 - 채널:', channelIds, '기간:', startDate, '~', endDate);
        this.addCrawlLog('info', `크롤링 시작: ${activeChannels.length}개 채널 (${startDate} ~ ${endDate})`);

        // Electron에서는 IPC로 진행상황 수신, 브라우저에서만 WebSocket 사용
        if (!this.isElectron() && !this.monitoringWs) {
            this.setupWebSocketHandler();
            // WebSocket 연결 대기
            await new Promise(r => setTimeout(r, 500));
        }

        try {
            this.addCrawlLog('info', '서버에 크롤링 요청 중...');
            // 주의: onProgress 콜백은 IPC로 전달 불가 (함수는 직렬화 안됨)
            // 진행 상태는 WebSocket을 통해 수신됨
            const result = await this.callTelegramAPI('crawlChannels', {
                channelIds,
                startDate,
                endDate
            });
            console.log('[TelegramUI] 크롤링 결과:', result);

            if (result && result.success) {
                this.state.crawlResult = result;
                this.showCrawlResult(result);

                if (this.isElectron()) {
                    // Electron: 서버 DB에 저장 후 테이블 새로고침
                    await this.saveCrawlMessages(result);
                } else {
                    // 브라우저: 크롤링 결과를 로컬 DB에 저장 후 조회
                    if (result.messages && result.messages.length > 0) {
                        // 클라이언트 측 광고 판별 적용
                        result.messages.forEach(m => {
                            if (m.is_ad === undefined) {
                                m.is_ad = this.isAdMessage(m.content || m.text || '');
                            }
                        });

                        // DB에 저장
                        try {
                            const saveResponse = await fetch('/api/telegram/db/save', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ messages: result.messages })
                            });
                            const saveResult = await saveResponse.json();
                            console.log('[TelegramUI] DB 저장 결과:', saveResult);
                            this.addCrawlLog('success', `${saveResult.saved || 0}개 DB 저장 (중복: ${saveResult.duplicates || 0}개)`);
                        } catch (dbErr) {
                            console.warn('[TelegramUI] DB 저장 실패:', dbErr);
                            this.addCrawlLog('error', 'DB 저장 실패: ' + dbErr.message);
                        }

                        // DB에서 다시 조회하여 테이블 렌더링
                        await this.loadMessages();
                        // 채널 드롭다운도 갱신
                        await this.loadViewerChannels();
                    }
                }

                document.getElementById('tgStartCrawlBtn').style.display = 'inline-flex';
                document.getElementById('tgStopCrawlBtn').style.display = 'none';
            } else {
                const errorMsg = result?.error || '알 수 없는 오류';
                console.error('[TelegramUI] 크롤링 실패:', errorMsg);
                this.addCrawlLog('error', '크롤링 실패: ' + errorMsg);
                document.getElementById('tgCrawlStatus').innerHTML = `<i class="fas fa-times-circle" style="color: var(--danger); margin-right: 6px;"></i>실패: ${errorMsg}`;

                document.getElementById('tgStartCrawlBtn').style.display = 'inline-flex';
                document.getElementById('tgStopCrawlBtn').style.display = 'none';
            }
        } catch (error) {
            console.error('[TelegramUI] 크롤링 오류:', error);
            this.addCrawlLog('error', '오류: ' + error.message);
            document.getElementById('tgCrawlStatus').innerHTML = `<i class="fas fa-times-circle" style="color: var(--danger); margin-right: 6px;"></i>오류: ${error.message}`;

            document.getElementById('tgStartCrawlBtn').style.display = 'inline-flex';
            document.getElementById('tgStopCrawlBtn').style.display = 'none';
        }
    },

    // WebSocket 크롤링 진행 상황 핸들러
    handleCrawlStart(data) {
        console.log('[TelegramUI] 크롤링 시작:', data);
        document.getElementById('tgCrawlStatus').textContent = '크롤링 시작...';
        document.getElementById('tgCrawlPercent').textContent = '0%';
        document.getElementById('tgCrawlProgressBar').style.width = '0%';
        this.addCrawlLog('info', `크롤링 시작: ${data.totalChannels}개 채널 (${data.startDate} ~ ${data.endDate})`);
    },

    handleCrawlProgress(data) {
        const percent = Math.round((data.currentChannel / data.totalChannels) * 100);
        document.getElementById('tgCrawlPercent').textContent = `${percent}%`;
        document.getElementById('tgCrawlProgressBar').style.width = `${percent}%`;
        document.getElementById('tgCrawlStatus').textContent = `${data.currentChannel}/${data.totalChannels} 채널 처리 중`;

        if (data.status === 'processing') {
            this.addCrawlLog('info', `채널 처리 중: ${data.channelId}`);
        } else if (data.status === 'completed') {
            this.addCrawlLog('success', `${data.channelName}: ${data.collected}개 수집 (총 ${data.totalCollected}개)`);
        } else if (data.status === 'error') {
            this.addCrawlLog('error', `채널 ${data.channelId} 오류: ${data.error}`);
        }
    },

    handleCrawlComplete(data) {
        console.log('[TelegramUI] 크롤링 완료:', data);
        document.getElementById('tgCrawlPercent').textContent = '100%';
        document.getElementById('tgCrawlProgressBar').style.width = '100%';
        document.getElementById('tgCrawlStatus').innerHTML = '<i class="fas fa-check-circle" style="margin-right: 6px; color: var(--success);"></i>완료';
        this.addCrawlLog('success', `크롤링 완료: ${data.totalChannels}개 채널, ${data.totalMessages}개 메시지`);

        // 메시지 목록 자동 새로고침
        this.loadMessages();

        // 3초 후 진행 섹션 숨김
        setTimeout(() => {
            const progressSection = document.getElementById('tgCrawlProgressSection');
            if (progressSection) progressSection.style.display = 'none';
        }, 3000);
    },

    updateCrawlProgress(progress) {
        const percent = Math.round((progress.currentChannel / progress.totalChannels) * 100);
        document.getElementById('tgCrawlPercent').textContent = `${percent}%`;
        document.getElementById('tgCrawlProgressBar').style.width = `${percent}%`;
        document.getElementById('tgCrawlStatus').textContent = `${progress.currentChannel}/${progress.totalChannels} 채널`;

        this.addCrawlLog('info', `채널 ${progress.channelId}: ${progress.collected}개 수집`);
    },

    addCrawlLog(type, message) {
        const logEl = document.getElementById('tgCrawlLog');
        const time = new Date().toLocaleTimeString();
        const color = type === 'error' ? 'var(--danger)' : type === 'success' ? 'var(--success)' : 'var(--text-muted)';

        logEl.innerHTML += `<div style="color: ${color};">[${time}] ${message}</div>`;
        logEl.scrollTop = logEl.scrollHeight;
    },

    showCrawlResult(result) {
        // 크롤링 완료 표시
        const statusEl = document.getElementById('tgCrawlStatus');
        if (statusEl) {
            statusEl.innerHTML = `<i class="fas fa-check-circle" style="color: var(--success); margin-right: 6px;"></i>완료: ${result.total || result.totalMessages || result.messages?.length || 0}개 수집`;
        }

        // 진행 섹션 3초 후 숨김
        setTimeout(() => {
            const progressSection = document.getElementById('tgCrawlProgressSection');
            if (progressSection) progressSection.style.display = 'none';
        }, 3000);

        // 메시지 목록 자동 새로고침
        this.loadMessages();
    },

    async saveCrawlMessages(result) {
        console.log('[saveCrawlMessages] 시작, result:', result);

        let allMessages = [];

        // 새 형식: result.messages 배열 직접 사용 (IPC 버전)
        if (result.messages && Array.isArray(result.messages)) {
            allMessages = result.messages;
        }
        // 기존 형식: result.channels[].messages 사용 (서버 버전)
        else if (result.channels && Array.isArray(result.channels)) {
            result.channels.forEach(ch => {
                if (ch.messages && Array.isArray(ch.messages)) {
                    allMessages.push(...ch.messages);
                }
            });
        } else {
            console.error('[saveCrawlMessages] 메시지 데이터 없음:', result);
            this.addCrawlLog('error', '크롤링 결과에 메시지가 없습니다');
            return;
        }

        console.log('[saveCrawlMessages] 총 메시지 수:', allMessages.length);

        if (allMessages.length === 0) {
            console.log('[saveCrawlMessages] 저장할 메시지 없음');
            return;
        }

        try {
            // 서버 DB에 저장 (user_id로 격리됨)
            // - 인증 정보는 로컬에 저장 (보안)
            const saveUrl = `${this.serverUrl}/api/telegram/messages`;
            console.log('[saveCrawlMessages] 저장 URL:', saveUrl, 'isElectron:', this.isElectron());

            // 채널 ID 정규화 함수
            const normalizeChannelId = (channelId) => {
                const str = String(channelId);
                if (str.startsWith('-100')) return str;
                if (str.startsWith('-')) return '-100' + str.substring(1);
                return '-100' + str;
            };

            // camelCase → snake_case 변환 함수
            const convertToServerFormat = (msg) => ({
                channel_id: normalizeChannelId(msg.channelId || msg.channel_id),  // 정규화
                channel_name: msg.channelName || msg.channel_name,
                message_id: msg.messageId || msg.message_id,
                content: msg.content || '',
                has_media: msg.hasMedia || msg.has_media || false,
                media_type: msg.mediaType || msg.media_type || null,
                urls: msg.urls || [],
                is_ad: msg.isAd || msg.is_ad || false,
                views: msg.views || 0,
                forwards: msg.forwards || 0,
                message_date: msg.date || msg.message_date || null,
                image_url: msg.imageUrl || msg.image_url || null
            });

            // 배치로 저장 (100개씩)
            for (let i = 0; i < allMessages.length; i += 100) {
                const rawBatch = allMessages.slice(i, i + 100);
                const batch = rawBatch.map(convertToServerFormat);
                console.log(`[saveCrawlMessages] 배치 ${i/100 + 1}: ${batch.length}개 전송 중...`);
                console.log('[saveCrawlMessages] 샘플 메시지:', batch[0]);

                if (this.isElectron()) {
                    // Electron: callServerAPI로 쿠키 포함 요청
                    const response = await this.callServerAPI(saveUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ messages: batch })
                    });

                    console.log('[saveCrawlMessages] 응답:', response);

                    if (response.browserMode) {
                        throw new Error('서버 연결 불가');
                    }

                    const saveResult = await response.json();
                    console.log('[saveCrawlMessages] 저장 결과:', saveResult);
                    if (!saveResult.success) {
                        throw new Error(saveResult.error || '저장 실패');
                    }
                } else {
                    // 브라우저: 직접 fetch (개발용)
                    const response = await fetch(saveUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        credentials: 'include',
                        body: JSON.stringify({ messages: batch })
                    });

                    if (!response.ok) {
                        const errorData = await response.json().catch(() => ({}));
                        throw new Error(errorData.error || `HTTP ${response.status}`);
                    }
                }
            }

            this.addCrawlLog('success', `서버에 ${allMessages.length}개 메시지 저장 완료`);

            // 저장 완료 후 테이블 자동 새로고침
            console.log('[saveCrawlMessages] 저장 완료, 테이블 새로고침...');
            await this.loadMessages();
        } catch (error) {
            this.addCrawlLog('error', '메시지 저장 실패: ' + error.message);
        }
    },

    downloadCrawlResult() {
        if (!this.state.crawlResult) return;

        const blob = new Blob([JSON.stringify(this.state.crawlResult, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `telegram_crawl_${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
    },

    // ============================================================
    // 데이터 뷰어
    // ============================================================

    async loadMessages(page = 1) {
        const keyword = document.getElementById('tgViewerKeyword')?.value?.trim();
        const channelId = document.getElementById('tgViewerChannel')?.value;
        const isAd = document.getElementById('tgViewerAd')?.value;
        const startDate = document.getElementById('tgViewerStartDate')?.value;
        const endDate = document.getElementById('tgViewerEndDate')?.value;

        const params = new URLSearchParams({ page, limit: 50 });
        if (keyword) params.append('keyword', keyword);
        if (channelId) params.append('channel_id', channelId);
        if (isAd) params.append('is_ad', isAd);
        if (startDate) params.append('start_date', startDate);
        if (endDate) {
            // end_date 다음날 00:00:00까지 조회하여 해당 날짜의 모든 메시지 포함
            const endDateObj = new Date(endDate + 'T00:00:00');
            endDateObj.setDate(endDateObj.getDate() + 1);
            const endDatePlusOne = endDateObj.toISOString().split('T')[0];
            params.append('end_date', endDatePlusOne);
        }

        try {
            let result;

            if (this.isElectron()) {
                // Electron: 서버 DB에서 조회 (기본)
                console.log('[TelegramUI] 서버 DB에서 메시지 조회 중...');
                const response = await this.callServerAPI(`${this.serverUrl}/api/telegram/messages?${params}`);

                if (!response.browserMode && response.ok) {
                    result = await response.json();
                    console.log('[TelegramUI] 서버 DB 조회 성공:', result?.messages?.length || 0, '건');
                } else {
                    // 서버 연결 실패 시: 기존 테이블 유지하고 에러 토스트만 표시
                    console.log('[TelegramUI] 서버 연결 실패 (HTTP', response.status || 'N/A', ') - 기존 테이블 유지');

                    // 에러 토스트 표시
                    const toast = document.createElement('div');
                    toast.style.cssText = 'position: fixed; top: 20px; right: 20px; background: #ef4444; color: white; padding: 12px 20px; border-radius: 8px; z-index: 10000; font-size: 14px; box-shadow: 0 4px 12px rgba(0,0,0,0.3);';
                    toast.innerHTML = '<i class="fas fa-exclamation-triangle" style="margin-right: 8px;"></i>서버 연결 실패 (일시적) - 기존 데이터 유지';
                    document.body.appendChild(toast);
                    setTimeout(() => toast.remove(), 5000);

                    // 기존 테이블 유지 - loadMessages 조기 종료
                    return;
                }
            } else {
                // 브라우저: DB에서 조회
                const dbParams = new URLSearchParams();
                dbParams.append('page', page);
                dbParams.append('limit', '50');
                if (keyword) dbParams.append('keyword', keyword);
                if (channelId) dbParams.append('channel_id', channelId);
                if (isAd) dbParams.append('is_ad', isAd);
                if (startDate) dbParams.append('start_date', startDate);
                if (endDate) {
                    const endDateObj = new Date(endDate + 'T00:00:00');
                    endDateObj.setDate(endDateObj.getDate() + 1);
                    dbParams.append('end_date', endDateObj.toISOString().split('T')[0]);
                }

                console.log('[TelegramUI] DB에서 메시지 조회:', dbParams.toString());
                const response = await fetch(`/api/telegram/db/messages?${dbParams}`);
                const dbResult = await response.json();
                console.log('[TelegramUI] DB 조회 결과:', dbResult?.messages?.length, '건');
                result = {
                    success: dbResult.ok || dbResult.success,
                    messages: dbResult.messages || [],
                    pagination: dbResult.pagination || { page: 1, totalPages: 1, total: 0 }
                };
            }

            console.log('[TelegramUI] loadMessages result:', JSON.stringify({
                success: result.success,
                hasMessages: !!result.messages,
                msgCount: result?.messages?.length,
                pagination: result.pagination
            }));

            if (result.success) {
                console.log('[TelegramUI] renderMessageTable 호출 직전, messages:', result.messages?.length);
                const tbody = document.getElementById('tgViewerTable');
                console.log('[TelegramUI] tgViewerTable DOM 요소:', tbody ? '있음' : '없음');

                this.renderMessageTable(result.messages);
                console.log('[TelegramUI] renderMessageTable 호출 완료');

                this.renderPagination(result.pagination);
                document.getElementById('tgViewerCount').textContent = `총 ${result.pagination?.total || result.messages?.length || 0}건`;

                // 마지막 업데이트 시간 표시
                const lastUpdateEl = document.getElementById('tgViewerLastUpdate');
                if (lastUpdateEl) {
                    const now = new Date();
                    lastUpdateEl.textContent = `(${now.toLocaleTimeString()} 갱신)`;
                }
            } else {
                console.log('[TelegramUI] 메시지 로드 실패:', result.error);
                this.showError('tgViewerTable', '메시지 없음 또는 로드 실패');
            }
        } catch (error) {
            console.error('[TelegramUI] 메시지 로드 오류:', error);
            this.showError('tgViewerTable', '메시지 로드 실패: ' + error.message);
        }
    },

    renderMessageTable(messages) {
        console.log('[renderMessageTable] 시작, messages:', messages?.length);
        const tbody = document.getElementById('tgViewerTable');
        console.log('[renderMessageTable] tbody 요소:', tbody ? 'OK' : 'NOT FOUND');

        if (!messages || messages.length === 0) {
            console.log('[renderMessageTable] 메시지 없음, 빈 메시지 표시');
            tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 40px; color: var(--text-muted);">메시지가 없습니다.</td></tr>';
            return;
        }

        // ✅ 다중 이미지 그룹화: 같은 grouped_id를 가진 메시지들의 이미지를 수집
        const groupedImages = {};  // grouped_id -> [image_urls]
        messages.forEach(msg => {
            if (msg.grouped_id && (msg.image_url || msg.imageUrl)) {
                if (!groupedImages[msg.grouped_id]) {
                    groupedImages[msg.grouped_id] = [];
                }
                const imgUrl = msg.image_url || msg.imageUrl;
                if (imgUrl && !groupedImages[msg.grouped_id].includes(imgUrl)) {
                    groupedImages[msg.grouped_id].push(imgUrl);
                }
            }
        });

        // 같은 grouped_id 내에서 첫 번째 메시지만 표시 (나머지는 스킵)
        const seenGroupIds = new Set();

        console.log('[renderMessageTable] HTML 생성 시작...');
        const html = messages.map((msg, idx) => {
            // 그룹된 메시지 중 첫 번째만 표시
            if (msg.grouped_id) {
                if (seenGroupIds.has(msg.grouped_id)) {
                    return '';  // 이미 표시된 그룹 → 스킵
                }
                seenGroupIds.add(msg.grouped_id);
            }
            // URL 파싱
            let urls = [];
            try {
                urls = msg.urls ? (typeof msg.urls === 'string' ? JSON.parse(msg.urls) : msg.urls) : [];
            } catch (e) {}

            // 이미지 URL 파싱 + 다중 이미지 그룹 지원
            // 서버 메시지: image_url (서버 경로, e.g., "/telegram-images/xxx.jpg")
            // 로컬 메시지: imageUrl (파일명만, e.g., "123_456.jpg")
            let imageUrls = [];  // 다중 이미지 지원
            const isElectronEnv = !!(window.electronAPI?.telegram);

            // 다중 이미지 그룹인 경우 모든 이미지 수집
            const rawImageUrls = msg.grouped_id && groupedImages[msg.grouped_id]
                ? groupedImages[msg.grouped_id]
                : (msg.imageUrl || msg.image_url ? [msg.imageUrl || msg.image_url] : []);

            try {
                for (const rawImageUrl of rawImageUrls) {
                    if (rawImageUrl && rawImageUrl.trim()) {
                        let processedUrl = null;
                        if (rawImageUrl.startsWith('http')) {
                            // 이미 절대 URL이면 그대로 사용
                            processedUrl = rawImageUrl;
                        } else if (isElectronEnv) {
                            // Electron 앱: 로컬 파일로 접근 (서버 경로도 로컬 파일 우선)
                            const fileName = rawImageUrl.replace(/^\/telegram\/images\//, '').replace(/^\/telegram-images\//, '');
                            processedUrl = `tg-image://${fileName}`;
                        } else if (rawImageUrl.startsWith('/telegram-images/')) {
                            // 브라우저: 서버 URL로 변환
                            processedUrl = `https://readinginvestor.com${rawImageUrl}`;
                        }
                        if (processedUrl && !imageUrls.includes(processedUrl)) {
                            imageUrls.push(processedUrl);
                        }
                    }
                }
            } catch (e) {
                console.error('[이미지URL] 파싱 오류:', e);
            }
            const imageUrl = imageUrls.length > 0 ? imageUrls[0] : null;  // 호환용

            const hasContent = msg.content && msg.content.trim().length > 0;
            const hasMedia = msg.has_media || msg.hasMedia || imageUrls.length > 0;

            // 미디어 타입 한글 변환 (서버: media_type, 로컬: mediaType)
            const mediaType = msg.media_type || msg.mediaType;
            const mediaTypeKr = this.getMediaTypeLabel(mediaType);
            const mediaIcon = this.getMediaTypeIcon(mediaType);

            // 다중 이미지 표시
            const imageCountStr = imageUrls.length > 1 ? ` (${imageUrls.length})` : '';
            const contentPreview = hasContent
                ? this.linkifyText(this.escapeHtml(msg.content).substring(0, 80)) + (msg.content.length > 80 ? '...' : '')
                : (hasMedia ? `<span style="color: var(--accent);"><i class="${mediaIcon}"></i> ${mediaTypeKr}${imageCountStr}</span>` : '<span style="color: var(--text-muted);">내용 없음</span>');

            return `
                <tr class="msg-row" data-msg-idx="${idx}" onclick="TelegramUI.toggleMessageDetail(${idx})" style="cursor: pointer;">
                    <td style="font-size: 12px; color: var(--text-muted);">
                        ${msg.message_date ? new Date(msg.message_date).toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' }) : '-'}
                    </td>
                    <td style="font-size: 13px;">${this.escapeHtml(msg.channel_name || '-')}</td>
                    <td style="max-width: 400px;">
                        ${contentPreview}
                    </td>
                    <td style="text-align: right; font-size: 12px;">${msg.views || 0}</td>
                    <td style="text-align: center;">
                        ${msg.is_ad ? '<span style="color: var(--danger); font-size: 11px;">광고</span>' : '-'}
                    </td>
                </tr>
                <tr class="msg-detail" id="msg-detail-${idx}" style="display: none;">
                    <td colspan="5" style="padding: 16px; background: var(--bg-dark); border-left: 3px solid var(--accent);">
                        ${imageUrls.length > 0 ? `
                            <div style="margin-bottom: 12px; display: flex; flex-wrap: wrap; gap: 8px;">
                                ${imageUrls.map(imgUrl => `
                                    <img src="${imgUrl}" style="max-width: 200px; max-height: 150px; border-radius: 8px; cursor: pointer; object-fit: cover;"
                                         onclick="TelegramUI.showImageModal('${imgUrl}'); event.stopPropagation();"
                                         onerror="this.style.display='none'">
                                `).join('')}
                            </div>
                            ${imageUrls.length > 1 ? `<div style="font-size: 11px; color: var(--text-muted); margin-bottom: 8px;"><i class="fas fa-images"></i> ${imageUrls.length}개 이미지</div>` : ''}
                        ` : ''}
                        ${hasMedia && imageUrls.length === 0 ? `
                            <div style="margin-bottom: 12px; padding: 10px; background: rgba(218,119,86,0.1); border-radius: 6px; color: var(--accent);">
                                <i class="${mediaIcon}" style="margin-right: 6px;"></i> ${mediaTypeKr}
                            </div>
                        ` : ''}
                        <div style="white-space: pre-wrap; line-height: 1.6; color: var(--text);">
                            ${hasContent ? this.linkifyText(this.escapeHtml(msg.content)) : '<span style="color: var(--text-muted);">텍스트 내용 없음</span>'}
                        </div>
                        ${urls.length > 0 ? `
                            <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border);">
                                <div style="font-size: 12px; color: var(--text-muted); margin-bottom: 8px;">
                                    <i class="fas fa-link"></i> 링크 (${urls.length}개)
                                </div>
                                ${urls.map(url => `
                                    <a href="${this.escapeHtml(url)}" target="_blank" rel="noopener"
                                       onclick="event.stopPropagation();"
                                       style="display: block; color: var(--accent); font-size: 13px; margin: 4px 0;
                                              overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                        ${this.escapeHtml(url)}
                                    </a>
                                `).join('')}
                            </div>
                        ` : ''}
                        <div style="margin-top: 12px; font-size: 11px; color: var(--text-muted);">
                            조회수: ${msg.views || 0} | 전달: ${msg.forwards || 0} | ID: ${msg.message_id || '-'}
                        </div>
                    </td>
                </tr>
            `;
        }).join('');

        console.log('[renderMessageTable] HTML 생성 완료, 길이:', html?.length);
        tbody.innerHTML = html;
        console.log('[renderMessageTable] innerHTML 할당 완료');

        // 현재 메시지 데이터 저장 (토글용)
        this.state.viewerMessages = messages;
    },

    toggleMessageDetail(idx) {
        const detailRow = document.getElementById(`msg-detail-${idx}`);
        if (detailRow) {
            const isVisible = detailRow.style.display !== 'none';
            detailRow.style.display = isVisible ? 'none' : 'table-row';
        }
    },

    // 이미지 모달 표시
    showImageModal(imageUrl) {
        // 기존 모달 제거
        const existingModal = document.getElementById('tgImageModal');
        if (existingModal) existingModal.remove();

        // 모달 생성
        const modal = document.createElement('div');
        modal.id = 'tgImageModal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            cursor: pointer;
        `;

        modal.innerHTML = `
            <img src="${imageUrl}" style="max-width: 90%; max-height: 90%; object-fit: contain; border-radius: 8px; cursor: default;"
                 onclick="event.stopPropagation();">
            <div style="position: absolute; top: 20px; right: 30px; color: white; font-size: 32px; cursor: pointer; opacity: 0.8;"
                 onclick="document.getElementById('tgImageModal').remove();">
                &times;
            </div>
        `;

        // 모달 배경 클릭 시 닫기
        modal.onclick = () => modal.remove();

        // ESC 키로 닫기
        const handleEsc = (e) => {
            if (e.key === 'Escape') {
                modal.remove();
                document.removeEventListener('keydown', handleEsc);
            }
        };
        document.addEventListener('keydown', handleEsc);

        document.body.appendChild(modal);
    },

    renderPagination(pagination) {
        const container = document.getElementById('tgViewerPagination');
        if (!pagination) {
            if (container) container.innerHTML = '';
            return;
        }
        const { page, totalPages } = pagination;

        if (totalPages <= 1) {
            container.innerHTML = '';
            return;
        }

        let html = '';

        if (page > 1) {
            html += `<button class="btn btn-sm btn-secondary" onclick="TelegramUI.loadMessages(${page - 1})">이전</button>`;
        }

        html += `<span style="padding: 4px 12px; color: var(--text-muted);">${page} / ${totalPages}</span>`;

        if (page < totalPages) {
            html += `<button class="btn btn-sm btn-secondary" onclick="TelegramUI.loadMessages(${page + 1})">다음</button>`;
        }

        container.innerHTML = html;
    },

    // 데이터 뷰어용 채널 목록 로드
    async loadViewerChannels() {
        const select = document.getElementById('tgViewerChannel');
        if (!select) return;

        try {
            let result;

            if (this.isElectron()) {
                const response = await this.callServerAPI(`${this.serverUrl}/api/telegram/messages/channels`);
                if (response.browserMode) return;
                result = await response.json();
            } else {
                // 브라우저: DB에서 채널 목록 + 메시지 수 조회
                try {
                    const response = await fetch('/api/telegram/db/channels');
                    const dbResult = await response.json();
                    if (dbResult.ok && dbResult.channels && dbResult.channels.length > 0) {
                        select.innerHTML = '<option value="">전체 채널</option>' +
                            dbResult.channels.map(ch =>
                                `<option value="${this.escapeHtml(ch.channel_id)}">${this.escapeHtml(ch.channel_name || ch.channel_id)} (${ch.message_count})</option>`
                            ).join('');
                        return;
                    }
                } catch (e) {
                    console.warn('[TelegramUI] DB 채널 목록 조회 실패:', e);
                }
                // DB에 데이터 없으면 savedChannels 폴백
                const savedChannels = this.state.savedChannels || JSON.parse(localStorage.getItem('telegram_saved_channels') || '[]');
                if (savedChannels.length > 0) {
                    select.innerHTML = '<option value="">전체 채널</option>' +
                        savedChannels.map(ch =>
                            `<option value="${this.escapeHtml(ch.channel_id)}">${this.escapeHtml(ch.channel_name || ch.channel_username || ch.channel_id)}</option>`
                        ).join('');
                }
                return;
            }

            if (result.success && result.channels) {
                select.innerHTML = '<option value="">전체 채널</option>' +
                    result.channels.map(ch =>
                        `<option value="${ch.username || ch.channel_id || ch.id}">${this.escapeHtml(ch.channel_name || ch.title || ch.channel_id || ch.id)}${ch.unread ? ' (' + ch.unread + ')' : ''}</option>`
                    ).join('');
            }
        } catch (error) {
            console.error('[TelegramUI] 채널 목록 로드 오류:', error);
        }
    },

    // ============================================================
    // 데이터 분석
    // ============================================================

    async loadAnalysisStats() {
        try {
            let result;

            if (this.isElectron()) {
                const response = await this.callServerAPI(`${this.serverUrl}/api/telegram/analysis/stats`);
                if (response.browserMode) return;
                result = await response.json();
            } else {
                // StockClaw Kit에는 분석 API 없음
                return;
            }

            if (result.success && result.stats) {
                document.getElementById('tgAnalysisTotalMessages').textContent = result.stats.total_messages?.toLocaleString() || '0';
                document.getElementById('tgAnalysisAdMessages').textContent = result.stats.ad_messages?.toLocaleString() || '0';
                document.getElementById('tgAnalysisUrlMessages').textContent = result.stats.url_messages?.toLocaleString() || '0';
                document.getElementById('tgAnalysisChannels').textContent = result.stats.channel_count?.toLocaleString() || '0';
            }
        } catch (error) {
            console.error('[TelegramUI] 통계 로드 오류:', error);
        }
    },

    async loadChannelStats() {
        const container = document.getElementById('tgChannelStatsChart');

        try {
            let result;

            if (this.isElectron()) {
                const response = await this.callServerAPI(`${this.serverUrl}/api/telegram/analysis/channels`);
                if (response.browserMode) return;
                result = await response.json();
            } else {
                // StockClaw Kit에는 분석 API 없음
                return;
            }

            if (result.success && result.channels && result.channels.length > 0) {
                const maxCount = Math.max(...result.channels.map(ch => ch.message_count || 0));
                container.innerHTML = result.channels.map(ch => `
                    <div style="display: flex; align-items: center; gap: 8px; padding: 8px 0; border-bottom: 1px solid var(--border);">
                        <div style="flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                            ${this.escapeHtml(ch.channel_name || ch.channel_id)}
                        </div>
                        <div style="width: 100px; height: 8px; background: var(--bg-dark); border-radius: 4px; overflow: hidden;">
                            <div style="width: ${maxCount > 0 ? Math.min(100, (ch.message_count / maxCount) * 100) : 0}%; height: 100%; background: var(--accent);"></div>
                        </div>
                        <div style="width: 60px; text-align: right; font-size: 12px; color: var(--text-muted);">
                            ${ch.message_count}
                        </div>
                    </div>
                `).join('');
            } else {
                container.innerHTML = '<div style="text-align: center; padding: 30px; color: var(--text-muted);">데이터가 없습니다.</div>';
            }
        } catch (error) {
            console.error('[TelegramUI] 채널 통계 오류:', error);
            container.innerHTML = '<div style="text-align: center; padding: 30px; color: var(--danger);">로드 실패</div>';
        }
    },

    async loadTimelineStats() {
        const container = document.getElementById('tgTimelineChart');

        try {
            let result;

            if (this.isElectron()) {
                const response = await this.callServerAPI(`${this.serverUrl}/api/telegram/analysis/timeline?period=hour`);
                if (response.browserMode) return;
                result = await response.json();
            } else {
                // StockClaw Kit에는 분석 API 없음
                return;
            }

            if (result.success && result.timeline && result.timeline.length > 0) {
                const maxCount = Math.max(...result.timeline.map(t => t.message_count || 0));

                container.innerHTML = `
                    <div style="display: flex; align-items: flex-end; height: 150px; gap: 4px; padding: 10px 0;">
                        ${result.timeline.map(t => `
                            <div style="flex: 1; display: flex; flex-direction: column; align-items: center;">
                                <div style="width: 100%; background: var(--accent); border-radius: 2px 2px 0 0; height: ${maxCount > 0 ? (t.message_count / maxCount) * 120 : 0}px;" title="${t.time_period}시: ${t.message_count}건"></div>
                                <span style="font-size: 10px; color: var(--text-muted); margin-top: 4px;">${t.time_period}</span>
                            </div>
                        `).join('')}
                    </div>
                `;
            } else {
                container.innerHTML = '<div style="text-align: center; padding: 30px; color: var(--text-muted);">데이터가 없습니다.</div>';
            }
        } catch (error) {
            console.error('[TelegramUI] 시간대 통계 오류:', error);
        }
    },

    async loadKeywords() {
        const container = document.getElementById('tgKeywordsList');

        try {
            let result;

            if (this.isElectron()) {
                const response = await this.callServerAPI(`${this.serverUrl}/api/telegram/analysis/keywords?limit=30`);
                if (response.browserMode) return;
                result = await response.json();
            } else {
                // StockClaw Kit에는 분석 API 없음
                return;
            }

            if (result.success && result.keywords && result.keywords.length > 0) {
                container.innerHTML = result.keywords.map((kw, i) => `
                    <div style="display: inline-block; padding: 4px 10px; margin: 4px; background: var(--bg-dark); border-radius: 12px; font-size: 13px;">
                        <span style="color: var(--accent); font-weight: 500;">${i + 1}.</span>
                        ${this.escapeHtml(kw.word)}
                        <span style="color: var(--text-muted); font-size: 11px;">(${kw.count})</span>
                    </div>
                `).join('');
            } else {
                container.innerHTML = '<div style="text-align: center; padding: 30px; color: var(--text-muted);">데이터가 없습니다.</div>';
            }
        } catch (error) {
            console.error('[TelegramUI] 키워드 분석 오류:', error);
        }
    },

    async loadDomains() {
        const container = document.getElementById('tgDomainsList');

        try {
            let result;

            if (this.isElectron()) {
                const response = await this.callServerAPI(`${this.serverUrl}/api/telegram/analysis/domains?limit=20`);
                if (response.browserMode) return;
                result = await response.json();
            } else {
                // StockClaw Kit에는 분석 API 없음
                return;
            }

            if (result.success && result.domains && result.domains.length > 0) {
                container.innerHTML = result.domains.map((d, i) => `
                    <div style="display: flex; align-items: center; gap: 8px; padding: 6px 0; border-bottom: 1px solid var(--border);">
                        <span style="color: var(--accent); width: 24px;">${i + 1}.</span>
                        <span style="flex: 1; font-size: 13px;">${this.escapeHtml(d.domain)}</span>
                        <span style="font-size: 12px; color: var(--text-muted);">${d.count}</span>
                    </div>
                `).join('');
            } else {
                container.innerHTML = '<div style="text-align: center; padding: 30px; color: var(--text-muted);">데이터가 없습니다.</div>';
            }
        } catch (error) {
            console.error('[TelegramUI] 도메인 분석 오류:', error);
        }
    },

    // ============================================================
    // 유틸리티
    // ============================================================

    async callTelegramAPI(method, params = {}) {
        console.log('[TelegramUI] callTelegramAPI:', method, params);

        // Electron 환경 - IPC 사용
        if (this.isElectron() && window.electronAPI?.telegram) {
            const fn = window.electronAPI.telegram[method];
            if (!fn) {
                console.error('[TelegramUI] Electron API 메서드 없음:', method);
                return { success: false, error: `API 메서드 없음: ${method}` };
            }
            try {
                console.log('[TelegramUI] Electron IPC 호출:', method);
                const result = await fn(params);
                console.log('[TelegramUI] Electron IPC 결과:', result);
                return result;
            } catch (e) {
                console.error('[TelegramUI] Electron IPC 오류:', e);
                return { success: false, error: e.message };
            }
        }

        // 브라우저 환경 - 로컬 프록시 서버 사용
        return await this.callTelegramProxy(method, params);
    },

    // 로컬 텔레그램 프록시 서버 호출 (브라우저용)
    async callTelegramProxy(method, params = {}) {
        const methodMap = {
            'checkAuth': { url: '/api/telegram', method: 'GET' },
            'startAuth': { url: '/api/telegram', method: 'POST', body: { action: 'send_code' } },
            'submitCode': { url: '/api/telegram', method: 'POST', body: { action: 'verify', code: params.code } },
            'submitPassword': { url: '/api/telegram', method: 'POST', body: { action: 'verify_2fa', password: params.password } },
            'tryConnect': { url: '/api/telegram', method: 'GET' },
            'disconnect': { url: '/api/telegram', method: 'POST', body: { action: 'status' } },
            'getDialogs': { url: '/api/telegram/channels', method: 'GET' }
        };

        // crawlChannels: 브라우저 mode에서 모든 채널 병렬 크롤링
        if (method === 'crawlChannels') {
            const channelIds = params.channelIds || [];
            const startDate = params.startDate || '';
            const endDate = params.endDate || '';
            if (!channelIds.length) {
                return { success: false, error: '크롤링할 채널이 없습니다' };
            }

            // 채널 ID → 채널명 매핑 (savedChannels에서)
            const channelNameMap = {};
            (this.state.savedChannels || []).forEach(c => {
                channelNameMap[c.channel_id] = c.channel_name || c.channel_username || c.channel_id;
            });

            // 모든 채널 병렬 크롤링
            const promises = channelIds.map(async (channelId, idx) => {
                try {
                    const bodyParams = { channel: channelId };
                    if (startDate) bodyParams.start_date = startDate;
                    if (endDate) bodyParams.end_date = endDate;

                    const response = await fetch('/api/telegram/messages', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(bodyParams)
                    });
                    const result = await response.json();
                    const msgs = (result.success && result.messages) ? result.messages : (result.messages || []);
                    const channelName = channelNameMap[channelId] || result.channel || channelId;
                    return {
                        success: true,
                        channelId,
                        channelName,
                        messages: msgs.map(m => ({
                            ...m,
                            channel_id: channelId,
                            content: m.content || m.text || '',
                            message_date: m.message_date || m.date || '',
                            channel_name: m.channel_name || channelName,
                            message_id: m.message_id || m.id || '',
                        }))
                    };
                } catch (e) {
                    console.warn('[TelegramUI] 채널 크롤링 실패:', channelId, e);
                    return { success: false, channelId, channelName: channelId, messages: [], error: e.message };
                }
            });

            const results = await Promise.allSettled(promises);
            const allMessages = [];
            let processedCount = 0;
            for (const r of results) {
                processedCount++;
                const data = r.status === 'fulfilled' ? r.value : { success: false, channelId: '?', channelName: '?', messages: [], error: r.reason?.message };
                allMessages.push(...data.messages);
                if (typeof this.handleCrawlProgress === 'function') {
                    this.handleCrawlProgress({
                        currentChannel: processedCount,
                        totalChannels: channelIds.length,
                        channelId: data.channelId,
                        channelName: data.channelName,
                        collected: data.messages.length,
                        totalCollected: allMessages.length,
                        status: data.success ? 'completed' : 'error',
                        error: data.error || ''
                    });
                }
            }
            return { success: true, messages: allMessages, total: allMessages.length };
        }

        const config = methodMap[method];
        if (!config) {
            console.warn('[TelegramUI] 알 수 없는 메서드:', method);
            return { success: false, error: `알 수 없는 메서드: ${method}` };
        }

        try {
            const options = {
                method: config.method,
                headers: { 'Content-Type': 'application/json' }
            };

            if (config.body && config.method !== 'GET') {
                options.body = JSON.stringify(config.body);
            }

            const response = await fetch(config.url, options);
            const result = await response.json();

            // status API 응답을 checkAuth 형식으로 변환
            if (method === 'checkAuth') {
                const isConnected = result.status === 'connected';
                return {
                    authenticated: isConnected,
                    hasSession: isConnected,
                    user: result.user || '',
                    status: result.status || 'disconnected'
                };
            }

            // getDialogs 응답: StockClaw Kit 필드 → 기존 코드 필드 매핑
            if (method === 'getDialogs' && result.channels) {
                result.success = true;
                result.channels = result.channels.map(ch => ({
                    channel_id: ch.id || ch.channel_id,
                    channel_name: ch.title || ch.channel_name || '',
                    channel_username: ch.username || ch.channel_username || '',
                    channel_type: ch.type || ch.channel_type || 'channel',
                    unread: ch.unread || 0,
                    ...ch,
                }));
            }

            return result;
        } catch (error) {
            console.error('[TelegramUI] 프록시 호출 오류:', error);
            return {
                success: false,
                error: `프록시 서버 연결 실패: ${error.message}`,
                proxyError: true
            };
        }
    },

    // 서버 API 호출 헬퍼
    // 브라우저 개발 환경에서는 CORS로 인해 직접 호출 불가
    async callServerAPI(url, options = {}) {
        // 브라우저 환경에서는 서버 API 직접 호출 불가 (CORS)
        if (!this.isElectron()) {
            return { success: false, browserMode: true };
        }

        // Electron 환경 - Desktop Token 인증 사용
        try {
            // 1. Desktop Token 가져오기 (safeStorage 암호화 저장)
            const desktopToken = await window.electronAPI.getDesktopToken();
            console.log('[callServerAPI] Desktop Token 존재:', !!desktopToken);

            options.headers = options.headers || {};

            // 2. Desktop Token이 있으면 Authorization 헤더에 추가
            if (desktopToken) {
                options.headers['Authorization'] = `Bearer ${desktopToken}`;
                console.log('[callServerAPI] Authorization 헤더 추가됨');
            } else {
                // 3. Token 없으면 쿠키 시도 (fallback)
                const cookies = await window.electronAPI.getCookies('https://readinginvestor.com');
                console.log('[callServerAPI] 쿠키 fallback, connect.sid 포함:', cookies?.includes('connect.sid'));
                if (cookies) {
                    options.headers['Cookie'] = cookies;
                }
            }

            options.credentials = 'include';

            const response = await fetch(url, options);
            console.log('[callServerAPI] 응답 상태:', response.status);
            return response;
        } catch (error) {
            console.error('[TelegramUI] 서버 API 오류:', error);
            return { success: false, browserMode: true, error: error.message };
        }
    },

    showLoading(elementId, message = '로딩 중...') {
        const el = document.getElementById(elementId);
        if (el) {
            el.innerHTML = `
                <div style="text-align: center; padding: 20px; color: var(--text-muted);">
                    <i class="fas fa-spinner fa-spin"></i> ${message}
                </div>
            `;
        }
    },

    showError(elementId, message) {
        const el = document.getElementById(elementId);
        if (el) {
            el.innerHTML = `
                <div style="color: var(--danger);">
                    <i class="fas fa-exclamation-triangle"></i> ${message}
                </div>
            `;
        }
    },

    // 미디어 타입 한글 라벨
    getMediaTypeLabel(mediaType) {
        if (!mediaType) return '미디어';
        const typeMap = {
            'MessageMediaPhoto': '사진',
            'MessageMediaDocument': '파일/문서',
            'MessageMediaVideo': '동영상',
            'MessageMediaGeo': '위치',
            'MessageMediaContact': '연락처',
            'MessageMediaPoll': '투표',
            'MessageMediaWebPage': '웹페이지 미리보기',
            'MessageMediaVenue': '장소',
            'MessageMediaGame': '게임',
            'MessageMediaInvoice': '인보이스',
            'MessageMediaGeoLive': '실시간 위치',
            'MessageMediaDice': '주사위/이모지',
            'MessageMediaStory': '스토리',
            'photo': '사진',
            'video': '동영상',
            'document': '파일',
            'audio': '오디오',
            'voice': '음성 메시지',
            'sticker': '스티커',
            'animation': 'GIF/애니메이션'
        };
        return typeMap[mediaType] || mediaType;
    },

    // 미디어 타입 아이콘
    getMediaTypeIcon(mediaType) {
        if (!mediaType) return 'fas fa-file';
        const iconMap = {
            'MessageMediaPhoto': 'fas fa-image',
            'MessageMediaDocument': 'fas fa-file-alt',
            'MessageMediaVideo': 'fas fa-video',
            'MessageMediaGeo': 'fas fa-map-marker-alt',
            'MessageMediaContact': 'fas fa-address-card',
            'MessageMediaPoll': 'fas fa-poll',
            'MessageMediaWebPage': 'fas fa-globe',
            'MessageMediaVenue': 'fas fa-map-pin',
            'MessageMediaGame': 'fas fa-gamepad',
            'MessageMediaInvoice': 'fas fa-file-invoice-dollar',
            'MessageMediaGeoLive': 'fas fa-location-arrow',
            'MessageMediaDice': 'fas fa-dice',
            'MessageMediaStory': 'fas fa-book-open',
            'photo': 'fas fa-image',
            'video': 'fas fa-video',
            'document': 'fas fa-file-alt',
            'audio': 'fas fa-music',
            'voice': 'fas fa-microphone',
            'sticker': 'fas fa-smile',
            'animation': 'fas fa-film'
        };
        return iconMap[mediaType] || 'fas fa-file';
    },

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },

    linkifyText(escapedHtml) {
        if (!escapedHtml) return '';
        return escapedHtml.replace(
            /(https?:\/\/[^\s<&"']+)/g,
            '<a href="$1" target="_blank" rel="noopener" onclick="event.stopPropagation();" style="color: var(--accent, #6c8cff); text-decoration: underline;">$1</a>'
        );
    },

    // ============================================================
    // 광고 키워드 설정
    // 기본 패턴(60+) + 사용자 추가/제거 분리
    // ============================================================

    // 사용자 커스텀 키워드 로드
    loadAdKeywords() {
        try {
            const savedAdded = localStorage.getItem('tg_ad_keywords_added');
            const savedRemoved = localStorage.getItem('tg_ad_keywords_removed');

            this.state.addedKeywords = savedAdded ? JSON.parse(savedAdded) : [];
            this.state.removedKeywords = savedRemoved ? JSON.parse(savedRemoved) : [];

            console.log('[TelegramUI] 광고 키워드 로드:', {
                기본: this.defaultAdKeywords.length,
                사용자추가: this.state.addedKeywords.length,
                사용자제거: this.state.removedKeywords.length
            });
        } catch (e) {
            console.error('[TelegramUI] 광고 키워드 로드 실패:', e);
            this.state.addedKeywords = [];
            this.state.removedKeywords = [];
        }
    },

    // 사용자 커스텀 키워드 저장
    saveAdKeywordsToStorage() {
        try {
            localStorage.setItem('tg_ad_keywords_added', JSON.stringify(this.state.addedKeywords));
            localStorage.setItem('tg_ad_keywords_removed', JSON.stringify(this.state.removedKeywords));
        } catch (e) {
            console.error('[TelegramUI] 광고 키워드 저장 실패:', e);
        }
    },

    // 최종 광고 키워드 목록 계산 (기본값 - 제거 + 추가)
    getEffectiveAdKeywords() {
        const effective = this.defaultAdKeywords.filter(k => !this.state.removedKeywords.includes(k));
        return [...effective, ...this.state.addedKeywords];
    },

    // 모달 열기
    openAdKeywordModal() {
        // 현재 커스텀을 임시 목록에 복사
        this.state.tempAddedKeywords = [...this.state.addedKeywords];
        this.state.tempRemovedKeywords = [...this.state.removedKeywords];
        this.renderAdKeywordList();

        const overlay = document.getElementById('tgAdKeywordOverlay');
        if (overlay) {
            overlay.classList.remove('hidden');
        }
    },

    // 모달 닫기
    closeAdKeywordModal() {
        const overlay = document.getElementById('tgAdKeywordOverlay');
        if (overlay) {
            overlay.classList.add('hidden');
        }
        // 임시 목록 초기화
        this.state.tempAddedKeywords = [];
        this.state.tempRemovedKeywords = [];
    },

    // 키워드 목록 렌더링 (사용자 추가/제거만 표시)
    renderAdKeywordList() {
        const container = document.getElementById('tgAdKeywordList');
        if (!container) return;

        // 기본 패턴 개수 표시
        const effectiveCount = this.defaultAdKeywords.length - this.state.tempRemovedKeywords.length + this.state.tempAddedKeywords.length;

        let html = `
            <div style="margin-bottom: 16px; padding: 12px; background: var(--bg-tertiary); border-radius: 8px;">
                <div style="font-size: 13px; color: var(--text-secondary); margin-bottom: 8px;">
                    <i class="fas fa-info-circle"></i>
                    기본 패턴 <strong>${this.defaultAdKeywords.length}개</strong> +
                    사용자 추가 <strong style="color: var(--success);">${this.state.tempAddedKeywords.length}개</strong> -
                    사용자 제거 <strong style="color: var(--danger);">${this.state.tempRemovedKeywords.length}개</strong> =
                    <strong>총 ${effectiveCount}개</strong> 적용 중
                </div>
            </div>
        `;

        // 사용자 추가 키워드 섹션
        html += `<div style="margin-bottom: 16px;">
            <div style="font-size: 12px; font-weight: 600; color: var(--success); margin-bottom: 8px;">
                <i class="fas fa-plus-circle"></i> 사용자 추가 키워드 (${this.state.tempAddedKeywords.length})
            </div>
            <div style="display: flex; flex-wrap: wrap; gap: 6px;">`;

        if (this.state.tempAddedKeywords.length === 0) {
            html += '<span style="color: var(--text-muted); font-size: 12px;">없음</span>';
        } else {
            html += this.state.tempAddedKeywords.map((keyword, index) => `
                <div class="ad-keyword-tag" style="
                    display: inline-flex;
                    align-items: center;
                    gap: 6px;
                    padding: 6px 10px;
                    background: rgba(34, 197, 94, 0.1);
                    border: 1px solid var(--success);
                    border-radius: 16px;
                    font-size: 12px;
                    color: var(--success);
                ">
                    <code style="font-family: monospace; font-size: 11px;">${this.escapeHtml(keyword)}</code>
                    <button onclick="tgRemoveAddedKeyword(${index})" style="
                        background: none;
                        border: none;
                        color: var(--danger);
                        cursor: pointer;
                        padding: 2px;
                        line-height: 1;
                        opacity: 0.7;
                    " title="삭제">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `).join('');
        }
        html += `</div></div>`;

        // 사용자 제거 키워드 섹션
        html += `<div style="margin-bottom: 16px;">
            <div style="font-size: 12px; font-weight: 600; color: var(--danger); margin-bottom: 8px;">
                <i class="fas fa-minus-circle"></i> 기본에서 제거한 키워드 (${this.state.tempRemovedKeywords.length})
            </div>
            <div style="display: flex; flex-wrap: wrap; gap: 6px;">`;

        if (this.state.tempRemovedKeywords.length === 0) {
            html += '<span style="color: var(--text-muted); font-size: 12px;">없음</span>';
        } else {
            html += this.state.tempRemovedKeywords.map((keyword, index) => `
                <div class="ad-keyword-tag" style="
                    display: inline-flex;
                    align-items: center;
                    gap: 6px;
                    padding: 6px 10px;
                    background: rgba(239, 68, 68, 0.1);
                    border: 1px solid var(--danger);
                    border-radius: 16px;
                    font-size: 12px;
                    color: var(--danger);
                    text-decoration: line-through;
                ">
                    <code style="font-family: monospace; font-size: 11px;">${this.escapeHtml(keyword)}</code>
                    <button onclick="tgRestoreRemovedKeyword(${index})" style="
                        background: none;
                        border: none;
                        color: var(--success);
                        cursor: pointer;
                        padding: 2px;
                        line-height: 1;
                        opacity: 0.7;
                    " title="복원">
                        <i class="fas fa-undo"></i>
                    </button>
                </div>
            `).join('');
        }
        html += `</div></div>`;

        // 기본 패턴 보기 토글
        html += `
            <div style="border-top: 1px solid var(--border-color); padding-top: 12px;">
                <button onclick="tgToggleDefaultPatterns()" style="
                    background: var(--bg-tertiary);
                    border: 1px solid var(--border-color);
                    border-radius: 6px;
                    padding: 8px 12px;
                    font-size: 12px;
                    color: var(--text-secondary);
                    cursor: pointer;
                    width: 100%;
                ">
                    <i class="fas fa-eye"></i> 기본 패턴 ${this.defaultAdKeywords.length}개 보기/숨기기
                </button>
                <div id="tgDefaultPatternsList" style="display: none; margin-top: 12px; max-height: 200px; overflow-y: auto;">
                    <div style="display: flex; flex-wrap: wrap; gap: 4px;">
                        ${this.defaultAdKeywords.map((keyword, index) => {
                            const isRemoved = this.state.tempRemovedKeywords.includes(keyword);
                            return `
                                <div style="
                                    display: inline-flex;
                                    align-items: center;
                                    gap: 4px;
                                    padding: 4px 8px;
                                    background: ${isRemoved ? 'rgba(239, 68, 68, 0.1)' : 'var(--bg-card)'};
                                    border: 1px solid ${isRemoved ? 'var(--danger)' : 'var(--border-color)'};
                                    border-radius: 12px;
                                    font-size: 11px;
                                    color: ${isRemoved ? 'var(--danger)' : 'var(--text-secondary)'};
                                    ${isRemoved ? 'text-decoration: line-through;' : ''}
                                ">
                                    <code style="font-family: monospace; font-size: 10px;">${this.escapeHtml(keyword.substring(0, 30))}${keyword.length > 30 ? '...' : ''}</code>
                                    ${!isRemoved ? `
                                        <button onclick="tgRemoveDefaultKeyword(${index})" style="
                                            background: none;
                                            border: none;
                                            color: var(--danger);
                                            cursor: pointer;
                                            padding: 1px;
                                            line-height: 1;
                                            opacity: 0.5;
                                            font-size: 10px;
                                        " title="제거">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    ` : ''}
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            </div>
        `;

        container.innerHTML = html;
    },

    // 기본 패턴 목록 토글
    toggleDefaultPatterns() {
        const list = document.getElementById('tgDefaultPatternsList');
        if (list) {
            list.style.display = list.style.display === 'none' ? 'block' : 'none';
        }
    },

    // 사용자 추가 키워드 추가
    addAdKeyword() {
        const input = document.getElementById('tgNewAdKeyword');
        if (!input) return;

        const keyword = input.value.trim();
        if (!keyword) {
            alert('키워드를 입력하세요.');
            return;
        }

        // 기본 패턴에 이미 있는지 체크
        if (this.defaultAdKeywords.includes(keyword)) {
            alert('이미 기본 패턴에 포함된 키워드입니다.');
            return;
        }

        // 중복 체크
        if (this.state.tempAddedKeywords.includes(keyword)) {
            alert('이미 추가된 키워드입니다.');
            return;
        }

        // 정규식 유효성 검사
        try {
            new RegExp(keyword, 'i');
        } catch (e) {
            alert('유효하지 않은 정규식 패턴입니다: ' + e.message);
            return;
        }

        this.state.tempAddedKeywords.push(keyword);
        this.renderAdKeywordList();
        input.value = '';
        input.focus();
    },

    // 사용자 추가 키워드 삭제
    removeAddedKeyword(index) {
        this.state.tempAddedKeywords.splice(index, 1);
        this.renderAdKeywordList();
    },

    // 기본 패턴에서 제거
    removeDefaultKeyword(index) {
        const keyword = this.defaultAdKeywords[index];
        if (!this.state.tempRemovedKeywords.includes(keyword)) {
            this.state.tempRemovedKeywords.push(keyword);
            this.renderAdKeywordList();
        }
    },

    // 제거된 기본 패턴 복원
    restoreRemovedKeyword(index) {
        this.state.tempRemovedKeywords.splice(index, 1);
        this.renderAdKeywordList();
    },

    // 기본값 복원 (사용자 커스텀 초기화)
    resetAdKeywords() {
        if (confirm('사용자 추가/제거한 키워드를 모두 초기화하시겠습니까?\n기본 패턴만 사용하게 됩니다.')) {
            this.state.tempAddedKeywords = [];
            this.state.tempRemovedKeywords = [];
            this.renderAdKeywordList();
        }
    },

    // 저장
    saveAdKeywords() {
        this.state.addedKeywords = [...this.state.tempAddedKeywords];
        this.state.removedKeywords = [...this.state.tempRemovedKeywords];
        this.saveAdKeywordsToStorage();
        this.closeAdKeywordModal();

        // 서버에도 새 키워드 전송하여 DB 재분류 요청
        this.reclassifyAdsWithNewKeywords();

        alert('광고 키워드 설정이 저장되었습니다.');
    },

    // 서버에 새 키워드로 광고 재분류 요청
    async reclassifyAdsWithNewKeywords() {
        // StockClaw Kit에는 reclassify-ads API 없음 (브라우저 환경)
        if (!this.isElectron()) {
            return;
        }
        try {
            const effectiveKeywords = this.getEffectiveAdKeywords();
            const response = await this.callServerAPI(`${this.serverUrl}/api/telegram/reclassify-ads`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    keywords: effectiveKeywords,
                    whitelistPatterns: this.whitelistPatterns,
                    suspiciousKeywords: this.suspiciousKeywords
                })
            });

            if (response && response.ok) {
                const result = await response.json();
                console.log('[TelegramUI] 광고 재분류 완료:', result);
                // 메시지 목록 새로고침
                this.loadMessages();
            }
        } catch (e) {
            console.error('[TelegramUI] 광고 재분류 요청 실패:', e);
        }
    },

    // ============================================================
    // 이미지 동기화 체크
    // ============================================================

    /**
     * 서버-로컬 이미지 동기화 상태 확인 및 누락 이미지 재수집
     */
    async checkImageSync() {
        if (!this.isElectron()) {
            alert('이 기능은 데스크톱 앱에서만 사용 가능합니다.');
            return;
        }

        const btn = document.getElementById('tgSyncImagesBtn');
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 확인 중...';
        }

        try {
            // 서버에서 이미지 없는 메시지 개수 확인
            const response = await this.callServerAPI(`${this.serverUrl}/api/telegram/messages-without-images?limit=1`);
            if (response.browserMode) {
                alert('서버 연결 실패');
                return;
            }

            const data = await response.json();
            const missingCount = data.total || data.messages?.length || 0;

            if (missingCount === 0) {
                alert('모든 이미지가 동기화되어 있습니다!');
                if (btn) {
                    btn.innerHTML = '<i class="fas fa-check"></i> 동기화 완료';
                    setTimeout(() => {
                        btn.innerHTML = '<i class="fas fa-sync"></i> 이미지 동기화';
                        btn.disabled = false;
                    }, 2000);
                }
                return;
            }

            // 누락 이미지 재수집 진행
            if (confirm(`${missingCount}개의 메시지에 이미지가 누락되었습니다.\n지금 재수집하시겠습니까?`)) {
                if (btn) btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 재수집 중...';

                const result = await window.electronAPI.telegram.resyncImages(Math.min(missingCount, 50));

                if (result.success) {
                    alert(`이미지 재수집 완료!\n- 대상: ${result.total}건\n- 업로드: ${result.uploaded}건`);
                } else {
                    alert('이미지 재수집 실패: ' + (result.error || '알 수 없는 오류'));
                }
            }

        } catch (error) {
            console.error('[TelegramUI] 이미지 동기화 체크 오류:', error);
            alert('동기화 확인 중 오류: ' + error.message);
        } finally {
            if (btn) {
                btn.innerHTML = '<i class="fas fa-sync"></i> 이미지 동기화';
                btn.disabled = false;
            }
        }
    },

    // 메시지가 광고인지 클라이언트 측에서 체크 (실시간 모니터링용) - v2.1
    isAdMessage(text) {
        if (!text) return false;

        // 1️⃣ 화이트리스트 체크 (뉴스/공시는 광고 아님)
        for (const pattern of this.whitelistPatterns) {
            try {
                if (new RegExp(pattern, 'i').test(text)) {
                    return false;
                }
            } catch {}
        }

        // 2️⃣ 확실한 광고 패턴 체크 (기본 - 제거 + 추가)
        const effectiveKeywords = this.getEffectiveAdKeywords();
        for (const keyword of effectiveKeywords) {
            try {
                if (new RegExp(keyword, 'i').test(text)) {
                    return true;
                }
            } catch {
                if (text.includes(keyword)) {
                    return true;
                }
            }
        }

        // 3️⃣ 의심 키워드 체크 (2개 이상 조합 시 광고)
        const normalizedText = text.toLowerCase().replace(/\s+/g, '');
        let suspiciousCount = 0;
        for (const keyword of this.suspiciousKeywords) {
            if (normalizedText.includes(keyword.toLowerCase().replace(/\s+/g, ''))) {
                suspiciousCount++;
            }
        }
        if (suspiciousCount >= 2) return true;

        // 4️⃣ t.me 링크 3개 이상 (채널 홍보) - v2.1 추가
        const telegramUrls = text.match(/https?:\/\/t\.me\/[^\s]+/g) || [];
        if (telegramUrls.length >= 3) return true;

        // 5️⃣ 외부 URL 5개 이상 (뉴스 제외)
        const urls = text.match(/https?:\/\/[^\s]+/g) || [];
        const nonNewsUrls = urls.filter(url =>
            !url.includes('dart.fss.or.kr') &&
            !url.includes('finance.naver.com') &&
            !url.includes('naver.com/item') &&
            !url.includes('n.news.naver.com')
        );
        if (nonNewsUrls.length >= 5) return true;

        return false;
    }
};

// ============================================================
// 전역 함수 (HTML onclick 핸들러용)
// ============================================================

function tgCheckAuth() { TelegramUI.checkAuth(); }
function tgSaveApiSettings() { TelegramUI.saveApiSettings(); }
function tgStartAuth() { TelegramUI.startAuth(); }
function tgSubmitCode() { TelegramUI.submitCode(); }
function tgSubmitPassword() { TelegramUI.submitPassword(); }
function tgTryConnect() { TelegramUI.tryConnect(); }
function tgDisconnect() { TelegramUI.disconnect(); }

function tgLoadChannels() { TelegramUI.loadChannels(); }
function tgSelectAll() { TelegramUI.selectAllChannels(); }
function tgDeselectAll() { TelegramUI.deselectAllChannels(); }
function tgSaveChannels() { TelegramUI.saveChannels(); }
function tgClearSavedChannels() { TelegramUI.clearSavedChannels(); }

// 드래그 앤 드롭 핸들러
function tgHandleDragStart(e) {
    const channelData = e.target.dataset.channel;
    if (!channelData) return;

    e.dataTransfer.setData('text/plain', channelData);
    e.dataTransfer.effectAllowed = 'copy';
    e.target.style.opacity = '0.4';
    e.target.style.cursor = 'grabbing';

    // 드롭존 하이라이트
    const dropZone = document.getElementById('tgSavedChannelDropZone');
    if (dropZone) dropZone.style.boxShadow = 'inset 0 0 0 3px var(--success)';
}

function tgHandleDragEnd(e) {
    // 드롭존 하이라이트 제거
    const dropZone = document.getElementById('tgSavedChannelDropZone');
    if (dropZone) dropZone.style.boxShadow = '';

    const listEl = document.getElementById('tgSavedChannelList');
    if (listEl) listEl.style.background = '';

    // 저장된 채널이면 흐린 상태 유지, 아니면 원래대로
    const channelData = e.target.dataset.channel;
    if (channelData) {
        try {
            const channel = JSON.parse(channelData);
            const savedIds = TelegramUI.state.savedChannels.map(c => c.channel_id);
            if (savedIds.includes(channel.channel_id)) {
                e.target.style.opacity = '0.5';
                e.target.style.cursor = 'grab';
                return;
            }
        } catch (err) {}
    }
    e.target.style.opacity = '';
    e.target.style.cursor = 'grab';
}

function tgHandleDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';

    const listEl = document.getElementById('tgSavedChannelList');
    if (listEl) listEl.style.background = 'rgba(34, 197, 94, 0.1)';
}

function tgHandleDragLeave(e) {
    // 자식 요소로 이동할 때는 무시
    if (e.target.id === 'tgSavedChannelDropZone' || e.target.id === 'tgSavedChannelList') {
        const listEl = document.getElementById('tgSavedChannelList');
        if (listEl) listEl.style.background = '';
    }
}

function tgHandleDrop(e) {
    e.preventDefault();

    const listEl = document.getElementById('tgSavedChannelList');
    if (listEl) listEl.style.background = '';

    const dropZone = document.getElementById('tgSavedChannelDropZone');
    if (dropZone) dropZone.style.boxShadow = '';

    try {
        const channelData = e.dataTransfer.getData('text/plain');
        if (!channelData) return;

        const channel = JSON.parse(channelData);
        TelegramUI.addChannelByDrag(channel);
    } catch (err) {
        console.error('[TelegramUI] 드롭 처리 오류:', err);
    }
}

// 저장된 채널 드래그 (제거용)
function tgHandleSavedDragStart(e, channelId) {
    e.dataTransfer.setData('text/plain', JSON.stringify({ action: 'remove', channelId }));
    e.dataTransfer.effectAllowed = 'move';
    e.target.style.opacity = '0.4';

    // 좌측 채널 목록을 드롭존으로 표시
    const channelList = document.getElementById('tgChannelList');
    if (channelList) channelList.style.boxShadow = 'inset 0 0 0 3px var(--danger)';
}

function tgHandleSavedDragEnd(e) {
    e.target.style.opacity = '';

    const channelList = document.getElementById('tgChannelList');
    if (channelList) {
        channelList.style.boxShadow = '';
        channelList.style.background = '';
    }
}

// 좌측 채널 목록에 드롭 (저장된 채널 제거)
function tgHandleChannelListDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';

    const channelList = document.getElementById('tgChannelList');
    if (channelList) channelList.style.background = 'rgba(239, 68, 68, 0.1)';
}

function tgHandleChannelListDragLeave(e) {
    if (e.target.id === 'tgChannelList') {
        e.target.style.background = '';
    }
}

function tgHandleChannelListDrop(e) {
    e.preventDefault();

    const channelList = document.getElementById('tgChannelList');
    if (channelList) {
        channelList.style.background = '';
        channelList.style.boxShadow = '';
    }

    try {
        const data = JSON.parse(e.dataTransfer.getData('text/plain'));
        if (data.action === 'remove' && data.channelId) {
            TelegramUI.removeChannelByDrag(data.channelId);
        }
    } catch (err) {
        console.error('[TelegramUI] 드롭 처리 오류:', err);
    }
}

function tgStartMonitoring() { TelegramUI.startMonitoring(); }
function tgStopMonitoring() { TelegramUI.stopMonitoring(); }

function tgToggleLiveMode() { TelegramUI.toggleLiveMode(); }

function tgStartCrawl() { TelegramUI.startCrawl(); }
function tgStopCrawl() { }
function tgDownloadCrawlResult() { TelegramUI.downloadCrawlResult(); }

function tgLoadMessages(page = 1) { TelegramUI.loadMessages(page); }

function tgLoadChannelStats() { TelegramUI.loadChannelStats(); }
function tgLoadTimelineStats() { TelegramUI.loadTimelineStats(); }
function tgLoadKeywords() { TelegramUI.loadKeywords(); }
function tgLoadDomains() { TelegramUI.loadDomains(); }

// 광고 키워드 설정 함수 v2.0
function tgOpenAdKeywordModal() { TelegramUI.openAdKeywordModal(); }
function tgCloseAdKeywordModal() { TelegramUI.closeAdKeywordModal(); }
function tgAddAdKeyword() { TelegramUI.addAdKeyword(); }
function tgRemoveAddedKeyword(index) { TelegramUI.removeAddedKeyword(index); }
function tgRemoveDefaultKeyword(index) { TelegramUI.removeDefaultKeyword(index); }
function tgRestoreRemovedKeyword(index) { TelegramUI.restoreRemovedKeyword(index); }
function tgToggleDefaultPatterns() { TelegramUI.toggleDefaultPatterns(); }
function tgResetAdKeywords() { TelegramUI.resetAdKeywords(); }
function tgSaveAdKeywords() { TelegramUI.saveAdKeywords(); }

// 이미지 동기화 체크
function tgCheckImageSync() { TelegramUI.checkImageSync(); }

// 초기화
document.addEventListener('DOMContentLoaded', () => {
    TelegramUI.init();
});

// CSS 애니메이션 추가
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.7; }
    }

    .btn-success {
        background: var(--success);
        border-color: var(--success);
    }

    .btn-success:hover {
        background: #16a34a;
    }

    .btn-sm {
        padding: 4px 8px;
        font-size: 12px;
    }
`;
document.head.appendChild(style);
