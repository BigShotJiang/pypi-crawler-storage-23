/**
 * setup-wizard.js
 * Setup wizard logic extracted from setup.html, adapted for embedding
 * inside stockclaw-kit-ui.html as a content panel.
 *
 * Parent page requirements:
 *   - <div id="panel-setup-wizard" class="content-panel"> with <div id="setup-wizard-content">
 *   - window.API_BASE global
 *   - window.switchPanel(panelId) function
 *   - window.showToast(msg, type) function (optional, falls back to alert)
 */

(function () {
  'use strict';

  // ─── CSS Variables (parent page uses these names) ─────────
  // --bg-dark      → replaces --bg, --surface2 backgrounds
  // --bg-card      → replaces --surface card backgrounds
  // --border       → same
  // --text         → same
  // --text-muted   → replaces --text2
  // --accent       → same (orange #da7756 in parent, blue in setup.html — wizard injects own vars)
  // --success      → replaces --green
  // --danger       → replaces --red
  // --warning      → replaces --orange

  // ─── Inject wizard-scoped CSS ─────────────────────────────
  const WIZARD_STYLE_ID = 'setup-wizard-styles';
  if (!document.getElementById(WIZARD_STYLE_ID)) {
    const style = document.createElement('style');
    style.id = WIZARD_STYLE_ID;
    style.textContent = `
/* ── Setup Wizard Scoped Styles ── */
#setup-wizard-content {
  font-family: -apple-system, 'Segoe UI', system-ui, sans-serif;
  line-height: 1.6;
}

.sw-wrap {
  max-width: 580px;
  margin: 0 auto;
  padding: 24px 20px 60px;
}

/* Progress dots */
.sw-progress-header { margin-bottom: 28px; }
.sw-module-dots {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  margin-bottom: 8px;
}
.sw-mdot {
  width: 10px; height: 10px;
  border-radius: 50%;
  background: var(--border);
  transition: all 0.3s;
}
.sw-mdot.done { background: var(--success); }
.sw-mdot.active { background: #6c8cff; width: 24px; border-radius: 5px; }
.sw-mdot.skip { background: var(--bg-dark); }
.sw-progress-text {
  text-align: center;
  font-size: 12px;
  color: var(--text-muted);
}

/* Page transitions */
.sw-page { display: none; animation: swFadeIn 0.3s ease; }
.sw-page.active { display: block; }
@keyframes swFadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* Welcome */
.sw-welcome-logo {
  width: 72px; height: 72px;
  border-radius: 18px;
  background: linear-gradient(135deg, #6c8cff, #a78bfa);
  display: flex; align-items: center; justify-content: center;
  font-size: 32px; font-weight: 800; color: #fff;
  margin: 0 auto 20px;
  box-shadow: 0 8px 32px rgba(108,140,255,0.3);
}
.sw-welcome-title {
  text-align: center; font-size: 26px; font-weight: 700; margin-bottom: 6px;
  background: linear-gradient(135deg, #e4e6ed, #a78bfa);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
}
.sw-welcome-sub { text-align: center; font-size: 15px; color: var(--text-muted); margin-bottom: 8px; }
.sw-welcome-desc {
  text-align: center; font-size: 14px; color: var(--text-muted);
  margin-bottom: 24px; line-height: 1.7; max-width: 480px; margin-left: auto; margin-right: auto;
}
.sw-feature-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 28px; }
.sw-feature-card {
  background: var(--bg-card); border: 1px solid var(--border);
  border-radius: 12px; padding: 16px;
}
.sw-feature-card .f-icon { font-size: 20px; margin-bottom: 8px; }
.sw-feature-card .f-title { font-size: 14px; font-weight: 600; margin-bottom: 4px; }
.sw-f-badge {
  font-size: 11px; padding: 2px 8px; border-radius: 10px;
  display: inline-block; font-weight: 600;
}
.sw-badge-free { background: #065f46; color: #6ee7b7; }
.sw-badge-naver { background: #1e3a4a; color: #38bdf8; }
.sw-badge-broker { background: #3b2a1a; color: #fb923c; }

/* Module card */
.sw-mod-card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 24px 22px;
  margin-bottom: 18px;
}
.sw-mod-header {
  display: flex; align-items: center; gap: 14px; margin-bottom: 14px;
}
.sw-mod-icon {
  width: 48px; height: 48px; border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  font-size: 22px; flex-shrink: 0;
}
.sw-mod-title { font-size: 19px; font-weight: 700; }
.sw-mod-badge {
  font-size: 11px; padding: 3px 10px; border-radius: 10px;
  font-weight: 600; margin-left: 8px;
}
.sw-mod-desc { font-size: 14px; color: var(--text-muted); line-height: 1.6; margin-bottom: 4px; }
.sw-mod-note { font-size: 13px; color: var(--text-muted); margin-top: 10px; line-height: 1.5; }

.sw-always-on-tag {
  display: inline-flex; align-items: center; gap: 6px;
  background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3);
  border-radius: 8px; padding: 8px 14px; font-size: 13px; color: var(--success);
  font-weight: 600; margin-top: 14px;
}

/* Key form */
.sw-key-form {
  display: none;
  margin-top: 18px;
  padding-top: 18px;
  border-top: 1px solid var(--border);
  animation: swFadeIn 0.3s ease;
}
.sw-key-form.show { display: block; }

.sw-api-guide {
  font-size: 12px; color: var(--text-muted); margin-bottom: 14px; line-height: 1.7;
  background: var(--bg-dark); border-radius: 8px; padding: 10px 12px;
  border-left: 3px solid #6c8cff;
}
.sw-api-guide a { color: #6c8cff; text-decoration: none; }
.sw-api-guide a:hover { text-decoration: underline; }

.sw-field { margin-bottom: 14px; }
.sw-field:last-child { margin-bottom: 0; }
.sw-field label {
  display: flex; align-items: center; gap: 8px;
  font-size: 13px; font-weight: 500; margin-bottom: 6px; color: var(--text);
}
.sw-field label .sw-req { font-size: 10px; color: var(--warning); font-weight: 600; }
.sw-field label .sw-opt { font-size: 10px; color: var(--text-muted); font-weight: 500; }
.sw-input-wrap { position: relative; }
.sw-input-wrap input { padding-right: 38px !important; }
.sw-field input {
  width: 100%; padding: 10px 12px;
  background: var(--bg-dark); border: 1px solid var(--border); border-radius: 8px;
  color: var(--text); font-size: 14px;
  font-family: 'SF Mono', 'Cascadia Code', 'Consolas', monospace;
  outline: none; transition: border-color 0.2s;
}
.sw-field input:focus { border-color: #6c8cff; }
.sw-field input::placeholder { color: #4a4f63; }
.sw-toggle-vis {
  position: absolute; right: 10px; top: 50%; transform: translateY(-50%);
  background: none; border: none; color: var(--text-muted); cursor: pointer;
  font-size: 14px; padding: 4px; line-height: 1;
}
.sw-toggle-vis:hover { color: var(--text); }
.sw-subsection-label {
  font-size: 13px; font-weight: 600; margin-bottom: 10px; margin-top: 4px;
}
.sw-api-divider { border: none; border-top: 1px solid var(--border); margin: 12px 0; }

/* Buttons */
.sw-btn-row { display: flex; gap: 10px; margin-top: 20px; align-items: center; }
.sw-btn {
  padding: 11px 26px; border: none; border-radius: 10px;
  font-size: 14px; font-weight: 600; cursor: pointer;
  transition: all 0.2s; font-family: inherit;
}
.sw-btn-primary { background: #6c8cff; color: #fff; flex: 1; }
.sw-btn-primary:hover { background: #4a6adf; }
.sw-btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
.sw-btn-secondary {
  background: var(--bg-dark); color: var(--text); border: 1px solid var(--border);
}
.sw-btn-secondary:hover { background: var(--border); }
.sw-btn-skip {
  background: none; color: var(--text-muted); border: 1px solid var(--border);
  padding: 11px 22px; border-radius: 10px; font-size: 14px; font-weight: 600;
  cursor: pointer; transition: all 0.2s; font-family: inherit;
}
.sw-btn-skip:hover { color: var(--text); border-color: var(--text-muted); }
.sw-btn-setup {
  background: #6c8cff; color: #fff;
  padding: 11px 22px; border-radius: 10px; font-size: 14px; font-weight: 600;
  cursor: pointer; transition: all 0.2s; font-family: inherit; border: none; flex: 1;
}
.sw-btn-setup:hover { background: #4a6adf; }

/* Test page */
.sw-test-modules { display: flex; flex-direction: column; gap: 10px; margin-bottom: 22px; }
.sw-test-module-card {
  display: flex; align-items: center; gap: 14px; padding: 12px 14px;
  background: var(--bg-card); border: 1px solid var(--border); border-radius: 10px;
}
.sw-test-status-dot {
  width: 10px; height: 10px; border-radius: 50%;
  background: var(--text-muted); flex-shrink: 0; transition: background 0.3s;
}
.sw-test-status-dot.ok { background: var(--success); box-shadow: 0 0 6px rgba(34,197,94,0.5); }
.sw-test-status-dot.fail { background: var(--danger); box-shadow: 0 0 6px rgba(239,68,68,0.5); }
.sw-test-status-dot.loading { background: var(--warning); animation: swPulse 1s infinite; }
@keyframes swPulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
.sw-test-mod-info { flex: 1; }
.sw-test-mod-name { font-size: 14px; font-weight: 600; }
.sw-test-mod-desc { font-size: 12px; color: var(--text-muted); margin-top: 2px; }
.sw-test-mod-status {
  font-size: 12px; font-weight: 600; padding: 3px 10px; border-radius: 8px;
}
.sw-test-mod-status.ok { background: #065f46; color: #6ee7b7; }
.sw-test-mod-status.fail { background: #7f1d1d; color: #fca5a5; }
.sw-test-mod-status.loading { background: #451a03; color: var(--warning); }
.sw-test-mod-status.skip { background: var(--bg-dark); color: var(--text-muted); }
.sw-test-hint {
  background: var(--bg-card); border: 1px solid var(--border);
  border-left: 3px solid var(--warning); border-radius: 8px;
  padding: 12px 14px; font-size: 13px; color: var(--text-muted);
  margin-bottom: 18px; display: none;
}
.sw-test-hint.show { display: block; }

/* Complete page */
.sw-complete-check {
  width: 80px; height: 80px; border-radius: 50%;
  background: rgba(34,197,94,0.15); border: 3px solid var(--success);
  display: flex; align-items: center; justify-content: center;
  font-size: 36px; margin: 0 auto 22px; animation: swPopIn 0.5s ease;
}
@keyframes swPopIn { 0%{transform:scale(0.5);opacity:0} 80%{transform:scale(1.1)} 100%{transform:scale(1);opacity:1} }
.sw-complete-title { text-align: center; font-size: 24px; font-weight: 700; margin-bottom: 8px; }
.sw-complete-sub { text-align: center; font-size: 14px; color: var(--text-muted); margin-bottom: 28px; }
.sw-complete-summary {
  background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px;
  padding: 14px 16px; margin-bottom: 18px; display: flex; align-items: center; gap: 12px;
}
.sw-summary-count { font-size: 34px; font-weight: 800; color: var(--success); line-height: 1; }
.sw-summary-label { font-size: 14px; color: var(--text-muted); }
.sw-summary-label strong { display: block; font-size: 15px; color: var(--text); margin-bottom: 2px; }
.sw-complete-links { display: flex; gap: 12px; margin-top: 8px; }
.sw-link-btn {
  flex: 1; padding: 12px; border-radius: 10px; text-align: center;
  font-size: 14px; font-weight: 600; cursor: pointer;
  border: none; transition: all 0.2s; font-family: inherit;
}
.sw-link-btn-primary { background: #6c8cff; color: #fff; }
.sw-link-btn-primary:hover { background: #4a6adf; }
.sw-link-btn-secondary { background: var(--bg-dark); color: var(--text); border: 1px solid var(--border); }
.sw-link-btn-secondary:hover { background: var(--border); }

/* Telegram auth */
.sw-tg-auth-box {
  display: none;
  margin-top: 18px;
  padding: 14px;
  background: var(--bg-dark);
  border: 1px solid var(--border);
  border-radius: 10px;
  animation: swFadeIn 0.3s ease;
}
.sw-tg-auth-box.show { display: block; }
.sw-tg-auth-status {
  display: flex; align-items: center; gap: 10px;
  margin-bottom: 12px; font-size: 14px;
}
.sw-tg-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
.sw-tg-dot.connected { background: var(--success); box-shadow: 0 0 6px rgba(34,197,94,0.5); }
.sw-tg-dot.pending   { background: var(--warning); animation: swPulse 1s infinite; }
.sw-tg-dot.error     { background: var(--danger); }
.sw-tg-auth-step { font-size: 13px; color: var(--text-muted); margin-bottom: 12px; line-height: 1.6; }
.sw-tg-code-row { display: flex; gap: 10px; align-items: center; }
.sw-tg-code-row input {
  flex: 1; padding: 10px 12px;
  background: var(--bg-dark); border: 1px solid var(--border); border-radius: 8px;
  color: var(--text); font-size: 16px; font-family: 'SF Mono', 'Cascadia Code', monospace;
  letter-spacing: 4px; text-align: center; outline: none;
}
.sw-tg-code-row input:focus { border-color: #6c8cff; }
.sw-tg-code-row input::placeholder { letter-spacing: 0; font-size: 13px; }
.sw-btn-tg {
  padding: 10px 18px; border: none; border-radius: 8px;
  font-size: 14px; font-weight: 600; cursor: pointer;
  transition: all 0.2s; font-family: inherit;
  background: #229ED9; color: #fff;
}
.sw-btn-tg:hover { background: #1A8BC7; }
.sw-btn-tg:disabled { opacity: 0.5; cursor: not-allowed; }
.sw-tg-success {
  display: flex; align-items: center; gap: 10px;
  padding: 12px 14px; background: rgba(34,197,94,0.1);
  border: 1px solid rgba(34,197,94,0.3); border-radius: 8px;
  font-size: 14px; color: var(--success); font-weight: 600;
}

/* Responsive */
@media (max-width: 520px) {
  .sw-wrap { padding: 16px 10px 50px; }
  .sw-feature-grid { grid-template-columns: 1fr; }
  .sw-complete-links { flex-direction: column; }
  .sw-btn-row { flex-wrap: wrap; }
}
`;
    document.head.appendChild(style);
  }

  // ─── API Base ──────────────────────────────────────────────
  const API_BASE = window.API_BASE || '';

  // ─── Module Definitions ───────────────────────────────────
  const SETUP_MODULES = [
    {
      id: 'free', name: '무료 데이터', icon: 'fas fa-database', badge: 'FREE',
      iconBg: '#065f46', iconColor: '#6ee7b7',
      description: 'PyKRX 기반 주가·시가총액·재무제표 등 (키 불필요)',
      alwaysOn: true,
      keys: []
    },
    {
      id: 'news', name: '뉴스 검색', icon: 'fas fa-newspaper', badge: 'FREE',
      iconBg: '#1f2d3b', iconColor: '#38bdf8',
      description: '네이버 뉴스 API 기반 종목·키워드 뉴스 검색',
      keys: [
        { id: 'NAVER_CLIENT_ID', label: 'Client ID', required: true, placeholder: '네이버 개발자센터 Client ID' },
        { id: 'NAVER_CLIENT_SECRET', label: 'Client Secret', required: true, placeholder: 'Client Secret' }
      ],
      guide: '발급: <a href="https://developers.naver.com/apps/" target="_blank">developers.naver.com</a> → 검색 > 뉴스'
    },
    {
      id: 'telegram', name: '텔레그램 뉴스', icon: 'fab fa-telegram', badge: 'FREE',
      iconBg: '#1a2a3f', iconColor: '#38bdf8',
      description: '텔레그램 채널/그룹 실시간 뉴스 수집',
      keys: [
        { id: 'TELEGRAM_API_ID', label: 'API ID', required: true, placeholder: 'my.telegram.org에서 발급' },
        { id: 'TELEGRAM_API_HASH', label: 'API Hash', required: true, placeholder: 'API Hash' },
        { id: 'TELEGRAM_PHONE', label: '전화번호', required: true, placeholder: '+82 10-XXXX-XXXX' }
      ],
      guide: '발급: <a href="https://my.telegram.org/" target="_blank">my.telegram.org</a> → API development tools',
      hasAuth: true
    },
    {
      id: 'kiwoom', name: '키움증권', icon: 'fas fa-chart-line', badge: 'REST API',
      iconBg: '#3b1f0b', iconColor: '#fb923c',
      description: '키움증권 Open API (실시간 시세, 주문, 잔고 등 185개)',
      keys: [
        { id: 'KIWOOM_APP_KEY', label: 'App Key', required: true, placeholder: '실전 App Key', section: '실전투자', sectionColor: '#fb923c' },
        { id: 'KIWOOM_APP_SECRET', label: 'App Secret', required: true, placeholder: '실전 App Secret' },
        { id: '_div_kiwoom', divider: true },
        { id: 'KIWOOM_PAPER_APP_KEY', label: 'App Key (모의)', required: false, placeholder: '모의투자 App Key (선택)', section: '모의투자 (선택)', sectionColor: 'var(--text-muted)' },
        { id: 'KIWOOM_PAPER_APP_SECRET', label: 'App Secret (모의)', required: false, placeholder: '모의투자 App Secret (선택)' }
      ],
      guide: '발급: <a href="https://openapi.kiwoom.com/" target="_blank">openapi.kiwoom.com</a>'
    },
    {
      id: 'kis', name: '한국투자증권', icon: 'fas fa-university', badge: 'REST API',
      iconBg: '#1a2e1a', iconColor: '#4ade80',
      description: 'KIS Open API (국내외 주식, 채권, 선물옵션 등 166개)',
      keys: [
        { id: 'KIS_APP_KEY', label: 'App Key', required: true, placeholder: '실전 App Key', section: '실전투자', sectionColor: '#4ade80' },
        { id: 'KIS_APP_SECRET', label: 'App Secret', required: true, placeholder: '실전 App Secret' },
        { id: '_div_kis', divider: true },
        { id: 'KIS_PAPER_APP_KEY', label: 'App Key (모의)', required: false, placeholder: '모의투자 App Key (선택)', section: '모의투자 (선택)', sectionColor: 'var(--text-muted)' },
        { id: 'KIS_PAPER_APP_SECRET', label: 'App Secret (모의)', required: false, placeholder: '모의투자 App Secret (선택)' }
      ],
      guide: '발급: <a href="https://apiportal.koreainvestment.com/" target="_blank">한국투자증권 Open API</a>'
    },
    {
      id: 'datakit', name: '공시/경제지표', icon: 'fas fa-landmark', badge: 'FREE',
      iconBg: '#1e3a5f', iconColor: '#60a5fa',
      description: 'DART 전자공시, ECOS 경제통계, 환율 데이터',
      keys: [
        { id: 'DART_API_KEY', label: 'DART API Key', required: false, placeholder: 'DART 전자공시 (선택)' },
        { id: 'ECOS_API_KEY', label: 'ECOS API Key', required: false, placeholder: 'ECOS 경제통계 (선택)' },
        { id: 'EXIM_API_KEY', label: 'EXIM API Key', required: false, placeholder: '한국수출입은행 환율 (선택)' }
      ],
      guide: 'DART: <a href="https://opendart.fss.or.kr/" target="_blank">opendart.fss.or.kr</a> | ECOS: <a href="https://ecos.bok.or.kr/" target="_blank">ecos.bok.or.kr</a>'
    },
    {
      id: 'membership', name: '테마트래커 멤버십', icon: 'fas fa-crown', badge: '멤버십',
      iconBg: '#2a1a3b', iconColor: '#a78bfa',
      description: '프리미엄 데이터 피드 + AI 브리핑',
      keys: [
        { id: 'MEMBERSHIP_API_KEY', label: 'API Key', required: false, placeholder: 'tt_live_... (선택)' }
      ],
      guide: '발급: <a href="https://readinginvestor.com/my-page" target="_blank">readinginvestor.com</a> → 내정보 → API 키 탭'
    }
  ];

  // ─── State ────────────────────────────────────────────────
  let swCurrentIdx = -1;       // -1 = welcome
  let swConfigured = new Set(['free']);
  let swExpandedForm = false;

  // ─── Toast Helper ─────────────────────────────────────────
  function swToast(msg, type) {
    if (typeof window.showToast === 'function') {
      window.showToast(msg, type);
    } else {
      if (type === 'error') console.error('[setup-wizard]', msg);
      else console.log('[setup-wizard]', msg);
    }
  }

  // ─── Root Element ─────────────────────────────────────────
  function swRoot() {
    return document.getElementById('setup-wizard-content');
  }

  // ─── Render full wizard shell ──────────────────────────────
  function renderShell() {
    const root = swRoot();
    if (!root) return;
    root.innerHTML = `
<div class="sw-wrap">
  <div class="sw-progress-header">
    <div class="sw-module-dots" id="sw-module-dots"></div>
    <div class="sw-progress-text" id="sw-progress-text"></div>
  </div>

  <!-- Welcome page -->
  <div class="sw-page active" id="sw-page-welcome">
    <div class="sw-welcome-logo"><i class="fas fa-seedling" style="font-size:28px;color:#fff;"></i></div>
    <div class="sw-welcome-title">OpenClaw Stock Kit</div>
    <div class="sw-welcome-sub">한국 주식 데이터 &amp; 매매 도구</div>
    <div class="sw-welcome-desc">
      API 키만 설정하면, OpenClaw에서 주식 질문을<br>자연어로 바로 물어볼 수 있습니다.
    </div>
    <div class="sw-feature-grid">
      <div class="sw-feature-card">
        <div class="f-icon"><i class="fas fa-database"></i></div>
        <div class="f-title">과거 주가/차트</div>
        <span class="sw-f-badge sw-badge-free">키 불필요</span>
      </div>
      <div class="sw-feature-card">
        <div class="f-icon"><i class="fas fa-newspaper"></i></div>
        <div class="f-title">종목 뉴스</div>
        <span class="sw-f-badge sw-badge-naver">네이버 API</span>
      </div>
      <div class="sw-feature-card">
        <div class="f-icon"><i class="fas fa-chart-line"></i></div>
        <div class="f-title">실시간 시세</div>
        <span class="sw-f-badge sw-badge-broker">키움/KIS</span>
      </div>
      <div class="sw-feature-card">
        <div class="f-icon"><i class="fas fa-flask"></i></div>
        <div class="f-title">테마 분석</div>
        <span class="sw-f-badge sw-badge-naver">멤버십</span>
      </div>
    </div>
    <div class="sw-btn-row">
      <button class="sw-btn sw-btn-primary" onclick="window._swStartSetup()">설정 시작하기 →</button>
    </div>
  </div>

  <!-- Module page (dynamic) -->
  <div class="sw-page" id="sw-page-module">
    <div class="sw-mod-card" id="sw-mod-card"></div>
    <div id="sw-mod-actions"></div>
  </div>

  <!-- Test page -->
  <div class="sw-page" id="sw-page-test">
    <div style="font-size:20px;font-weight:700;margin-bottom:6px;">연결 상태 확인</div>
    <div style="font-size:14px;color:var(--text-muted);margin-bottom:22px;">설정한 API 키가 제대로 작동하는지 확인합니다.</div>
    <div class="sw-test-modules" id="sw-test-modules"></div>
    <div class="sw-test-hint" id="sw-test-hint">
      일부 모듈에 문제가 있습니다. API 키를 다시 확인하거나, 설정 페이지에서 수정할 수 있습니다.
    </div>
    <div class="sw-btn-row">
      <button class="sw-btn sw-btn-secondary" onclick="window._swRunTests()">다시 테스트</button>
      <button class="sw-btn sw-btn-primary" onclick="window._swGoComplete()">완료 →</button>
    </div>
  </div>

  <!-- Complete page -->
  <div class="sw-page" id="sw-page-complete">
    <div class="sw-complete-check">✓</div>
    <div class="sw-complete-title">설정이 완료되었습니다!</div>
    <div class="sw-complete-sub" id="sw-complete-sub">OpenClaw에서 주식 질문을 바로 시작할 수 있습니다.</div>
    <div class="sw-complete-summary">
      <div class="sw-summary-count" id="sw-active-count">-</div>
      <div style="width:1px;background:var(--border);align-self:stretch;margin:0 4px;"></div>
      <div class="sw-summary-label">
        <strong>활성 모듈</strong>
        선택한 기능이 준비되었습니다.
      </div>
    </div>
    <div class="sw-complete-links">
      <button class="sw-link-btn sw-link-btn-primary" onclick="window._swResetWizard()">다시 설정하기</button>
      <button class="sw-link-btn sw-link-btn-secondary" onclick="window.switchPanel && window.switchPanel('volume-surge')">시작하기 →</button>
    </div>
  </div>
</div>
`;
  }

  // ─── Page Navigation ──────────────────────────────────────
  function swShowPage(id) {
    const root = swRoot();
    if (!root) return;
    root.querySelectorAll('.sw-page').forEach(function (p) { p.classList.remove('active'); });
    const target = root.querySelector('#sw-page-' + id);
    if (target) target.classList.add('active');
    // Scroll wizard content to top
    const panel = document.getElementById('panel-setup-wizard');
    if (panel) panel.scrollTop = 0;
  }

  // ─── Progress Dots ────────────────────────────────────────
  function swUpdateDots() {
    const dotsEl = document.getElementById('sw-module-dots');
    const textEl = document.getElementById('sw-progress-text');
    if (!dotsEl || !textEl) return;

    const total = SETUP_MODULES.length + 3; // welcome + modules + test + complete
    let currentPos;
    if (swCurrentIdx === -1) currentPos = 0;
    else if (swCurrentIdx < SETUP_MODULES.length) currentPos = swCurrentIdx + 1;
    else currentPos = swCurrentIdx + 1;

    let html = '';
    for (let i = 0; i < total; i++) {
      let cls = 'sw-mdot';
      if (i < currentPos) cls += ' done';
      else if (i === currentPos) cls += ' active';
      html += '<div class="' + cls + '"></div>';
    }
    dotsEl.innerHTML = html;

    if (swCurrentIdx === -1) {
      textEl.textContent = '';
    } else if (swCurrentIdx < SETUP_MODULES.length) {
      textEl.textContent = (swCurrentIdx + 1) + ' / ' + SETUP_MODULES.length + ' 기능';
    } else if (swCurrentIdx === SETUP_MODULES.length) {
      textEl.textContent = '연결 확인';
    } else {
      textEl.textContent = '완료';
    }
  }

  // ─── Start Setup ──────────────────────────────────────────
  function swStartSetup() {
    swCurrentIdx = 0;
    swRenderModule();
    swShowPage('module');
    swUpdateDots();
  }

  // ─── Render Current Module ────────────────────────────────
  function swRenderModule() {
    const mod = SETUP_MODULES[swCurrentIdx];
    const card = document.getElementById('sw-mod-card');
    const actions = document.getElementById('sw-mod-actions');
    if (!card || !actions) return;
    swExpandedForm = false;

    // Header
    let html = '<div class="sw-mod-header">';
    html += '<div class="sw-mod-icon" style="background:' + mod.iconBg + ';color:' + mod.iconColor + ';">';
    html += '<i class="' + mod.icon + '"></i>';
    html += '</div>';
    html += '<div>';
    html += '<div class="sw-mod-title">' + mod.name;
    html += ' <span class="sw-mod-badge" style="background:' + mod.iconBg + ';color:' + mod.iconColor + ';">' + mod.badge + '</span>';
    html += '</div>';
    html += '</div></div>';
    html += '<div class="sw-mod-desc">' + mod.description + '</div>';

    if (mod.alwaysOn) {
      html += '<div class="sw-always-on-tag"><i class="fas fa-check-circle"></i> 항상 활성화 — API 키가 필요 없습니다</div>';
      card.innerHTML = html;
      actions.innerHTML =
        '<div class="sw-btn-row">' +
        '<button class="sw-btn-skip" onclick="window._swPrevModule()">← 이전</button>' +
        '<button class="sw-btn sw-btn-primary" onclick="window._swNextModule()">다음 →</button>' +
        '</div>';
      return;
    }

    // Key form (hidden initially)
    html += '<div class="sw-key-form" id="sw-key-form">';
    if (mod.guide) {
      html += '<div class="sw-api-guide">' + mod.guide + '</div>';
    }
    mod.keys.forEach(function (k) {
      if (k.divider) {
        html += '<hr class="sw-api-divider">';
        return;
      }
      if (k.section) {
        html += '<div class="sw-subsection-label" style="color:' + k.sectionColor + ';">' + k.section + '</div>';
      }
      html += '<div class="sw-field">';
      html += '<label>' + k.label;
      html += k.required
        ? ' <span class="sw-req">필수</span>'
        : ' <span class="sw-opt">선택</span>';
      html += '</label>';
      html += '<div class="sw-input-wrap">';
      html += '<input type="password" id="sw-key-' + k.id + '" placeholder="' + (k.placeholder || '') + '">';
      html += '<button class="sw-toggle-vis" onclick="window._swToggleVis(this)" title="보기/숨기기"><i class="fas fa-eye"></i></button>';
      html += '</div></div>';
    });

    // Telegram auth box
    if (mod.hasAuth) {
      html += '<div class="sw-tg-auth-box" id="sw-tg-auth-box">';
      html += '<div class="sw-tg-auth-status" id="sw-tg-auth-status">';
      html += '<div class="sw-tg-dot pending" id="sw-tg-dot"></div>';
      html += '<span id="sw-tg-status-text">인증 대기 중</span>';
      html += '</div>';
      html += '<div id="sw-tg-auth-content">';
      html += '<div class="sw-tg-auth-step">키를 저장하면 텔레그램 앱으로 인증 코드가 전송됩니다.</div>';
      html += '<button class="sw-btn-tg" id="sw-btn-tg-send" onclick="window._swTgSendCode()">인증 코드 보내기</button>';
      html += '</div>';
      html += '</div>';
    }

    html += '</div>'; // end sw-key-form
    card.innerHTML = html;

    // Action buttons
    actions.innerHTML =
      '<div class="sw-btn-row">' +
      '<button class="sw-btn-skip" onclick="window._swPrevModule()">← 이전</button>' +
      '<button class="sw-btn-setup" id="sw-btn-setup-or-save" onclick="window._swToggleSetup()">지금 설정하기</button>' +
      '<button class="sw-btn-skip" onclick="window._swSkipModule()">나중에 →</button>' +
      '</div>';

    // Pre-load existing keys
    swPreloadModuleKeys(mod);
  }

  // ─── Toggle: expand form / save ──────────────────────────
  function swToggleSetup() {
    if (!swExpandedForm) {
      const form = document.getElementById('sw-key-form');
      if (form) form.classList.add('show');
      const mod = SETUP_MODULES[swCurrentIdx];
      const btn = document.getElementById('sw-btn-setup-or-save');
      if (btn) btn.textContent = mod.hasAuth ? '저장하고 인증하기' : '저장하고 다음 →';
      swExpandedForm = true;
      // Focus first non-divider key
      const firstKey = mod.keys.find(function (k) { return !k.divider; });
      if (firstKey) {
        const el = document.getElementById('sw-key-' + firstKey.id);
        if (el) setTimeout(function () { el.focus(); }, 100);
      }
    } else {
      swSaveModuleKeys();
    }
  }

  // ─── Save current module keys ─────────────────────────────
  async function swSaveModuleKeys() {
    const mod = SETUP_MODULES[swCurrentIdx];
    const btn = document.getElementById('sw-btn-setup-or-save');
    if (btn) { btn.disabled = true; btn.textContent = '저장 중...'; }

    const keys = {};
    let hasAny = false;
    mod.keys.forEach(function (k) {
      if (k.divider) return;
      const el = document.getElementById('sw-key-' + k.id);
      if (el && el.value.trim()) {
        keys[k.id] = el.value.trim();
        hasAny = true;
      }
    });

    if (!hasAny) {
      swToast('입력된 키가 없습니다. 나중에 설정할 수 있습니다.', 'info');
      if (btn) { btn.disabled = false; btn.textContent = '저장하고 다음 →'; }
      swSkipModule();
      return;
    }

    try {
      const r = await fetch(API_BASE + '/api/keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keys: keys })
      });
      const d = await r.json();
      if (d.ok) {
        swToast(mod.name + ' API 키가 저장되었습니다.', 'success');
        swConfigured.add(mod.id);
      } else {
        swToast('저장 실패: ' + (d.error || '알 수 없는 오류'), 'error');
      }
    } catch (e) {
      swToast('서버 연결 실패. 로컬에 저장됩니다.', 'info');
      swConfigured.add(mod.id);
    }

    if (btn) btn.disabled = false;

    // Telegram: show auth flow after save, don't navigate yet
    if (mod.hasAuth) {
      if (btn) {
        btn.textContent = '다음 →';
        btn.onclick = function () { swNextModule(); };
      }
      const authBox = document.getElementById('sw-tg-auth-box');
      if (authBox) {
        authBox.classList.add('show');
        swTgCheckStatus();
      }
      return;
    }

    swNextModule();
  }

  // ─── Telegram Auth Flow ───────────────────────────────────
  async function swTgCheckStatus() {
    const dot = document.getElementById('sw-tg-dot');
    const txt = document.getElementById('sw-tg-status-text');
    const content = document.getElementById('sw-tg-auth-content');
    if (!dot) return;

    try {
      const r = await fetch(API_BASE + '/api/telegram');
      const d = await r.json();
      if (d.success && d.status === 'connected') {
        dot.className = 'sw-tg-dot connected';
        txt.textContent = '텔레그램 인증 완료 (' + (d.user || '') + ')';
        content.innerHTML = '<div class="sw-tg-success"><i class="fas fa-check-circle"></i> 텔레그램에 연결되었습니다</div>';
        return;
      }
    } catch (_) {}

    dot.className = 'sw-tg-dot pending';
    txt.textContent = '인증이 필요합니다';
    content.innerHTML =
      '<div class="sw-tg-auth-step">키가 저장되었습니다. 아래 버튼을 누르면 텔레그램 앱으로 인증 코드가 전송됩니다.</div>' +
      '<button class="sw-btn-tg" onclick="window._swTgSendCode()">인증 코드 보내기</button>';
  }

  async function swTgSendCode() {
    const dot = document.getElementById('sw-tg-dot');
    const txt = document.getElementById('sw-tg-status-text');
    const content = document.getElementById('sw-tg-auth-content');

    content.innerHTML = '<div class="sw-tg-auth-step">인증 코드 전송 중...</div>';
    dot.className = 'sw-tg-dot pending';
    txt.textContent = '코드 전송 중...';

    try {
      const r = await fetch(API_BASE + '/api/telegram', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'send_code' })
      });
      const d = await r.json();

      if (d.success && d.status === 'code_sent') {
        txt.textContent = '코드가 전송되었습니다 (' + (d.phone || '') + ')';
        content.innerHTML =
          '<div class="sw-tg-auth-step">텔레그램 앱에서 받은 <b>인증 코드</b>를 입력하세요.</div>' +
          '<div class="sw-tg-code-row">' +
          '<input type="text" id="sw-tg-code" placeholder="인증 코드 5자리" maxlength="10" autocomplete="off">' +
          '<button class="sw-btn-tg" onclick="window._swTgVerify()">확인</button>' +
          '</div>';
        setTimeout(function () {
          const el = document.getElementById('sw-tg-code');
          if (el) el.focus();
        }, 100);
      } else {
        dot.className = 'sw-tg-dot error';
        txt.textContent = '코드 전송 실패';
        content.innerHTML =
          '<div class="sw-tg-auth-step" style="color:var(--danger)">' + (d.error || '알 수 없는 오류') + '</div>' +
          '<button class="sw-btn-tg" onclick="window._swTgSendCode()">다시 시도</button>';
      }
    } catch (e) {
      dot.className = 'sw-tg-dot error';
      txt.textContent = '서버 연결 실패';
      content.innerHTML =
        '<div class="sw-tg-auth-step" style="color:var(--danger)">서버에 연결할 수 없습니다. stock-kit 서버가 실행 중인지 확인하세요.</div>' +
        '<button class="sw-btn-tg" onclick="window._swTgSendCode()">다시 시도</button>';
    }
  }

  async function swTgVerify() {
    const codeEl = document.getElementById('sw-tg-code');
    const code = codeEl ? codeEl.value.trim() : '';
    if (!code) { swToast('인증 코드를 입력하세요.', 'info'); return; }

    const dot = document.getElementById('sw-tg-dot');
    const txt = document.getElementById('sw-tg-status-text');
    const content = document.getElementById('sw-tg-auth-content');

    txt.textContent = '인증 확인 중...';

    try {
      const r = await fetch(API_BASE + '/api/telegram', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'verify', code: code })
      });
      const d = await r.json();

      if (d.success && d.status === 'connected') {
        dot.className = 'sw-tg-dot connected';
        txt.textContent = '텔레그램 인증 완료';
        content.innerHTML = '<div class="sw-tg-success"><i class="fas fa-check-circle"></i> 텔레그램에 연결되었습니다</div>';
        swToast('텔레그램 인증 성공!', 'success');
      } else if (d.success && d.status === 'need_2fa') {
        txt.textContent = '2단계 인증 필요';
        content.innerHTML =
          '<div class="sw-tg-auth-step">이 계정은 <b>2단계 인증(2FA)</b>이 설정되어 있습니다. 비밀번호를 입력하세요.</div>' +
          '<div class="sw-tg-code-row">' +
          '<input type="password" id="sw-tg-2fa" placeholder="2FA 비밀번호" autocomplete="off">' +
          '<button class="sw-btn-tg" onclick="window._swTgVerify2fa()">확인</button>' +
          '</div>';
        setTimeout(function () {
          const el = document.getElementById('sw-tg-2fa');
          if (el) el.focus();
        }, 100);
      } else {
        dot.className = 'sw-tg-dot error';
        txt.textContent = '인증 실패';
        swToast('인증 실패: ' + (d.error || '코드가 올바르지 않습니다'), 'error');
        content.innerHTML =
          '<div class="sw-tg-auth-step" style="color:var(--danger)">' + (d.error || '코드가 올바르지 않습니다') + '</div>' +
          '<div class="sw-tg-code-row">' +
          '<input type="text" id="sw-tg-code" placeholder="인증 코드 재입력" maxlength="10" autocomplete="off">' +
          '<button class="sw-btn-tg" onclick="window._swTgVerify()">확인</button>' +
          '</div>';
      }
    } catch (e) {
      dot.className = 'sw-tg-dot error';
      txt.textContent = '서버 연결 실패';
      swToast('서버 연결 실패', 'error');
    }
  }

  async function swTgVerify2fa() {
    const pwEl = document.getElementById('sw-tg-2fa');
    const pw = pwEl ? pwEl.value.trim() : '';
    if (!pw) { swToast('비밀번호를 입력하세요.', 'info'); return; }

    const dot = document.getElementById('sw-tg-dot');
    const txt = document.getElementById('sw-tg-status-text');
    const content = document.getElementById('sw-tg-auth-content');

    txt.textContent = '2FA 확인 중...';

    try {
      const r = await fetch(API_BASE + '/api/telegram', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'verify_2fa', password: pw })
      });
      const d = await r.json();

      if (d.success && d.status === 'connected') {
        dot.className = 'sw-tg-dot connected';
        txt.textContent = '텔레그램 인증 완료';
        content.innerHTML = '<div class="sw-tg-success"><i class="fas fa-check-circle"></i> 텔레그램에 연결되었습니다</div>';
        swToast('텔레그램 인증 성공!', 'success');
      } else {
        dot.className = 'sw-tg-dot error';
        txt.textContent = '2FA 인증 실패';
        swToast('2FA 실패: ' + (d.error || '비밀번호가 올바르지 않습니다'), 'error');
      }
    } catch (e) {
      dot.className = 'sw-tg-dot error';
      txt.textContent = '서버 연결 실패';
    }
  }

  // ─── Navigation ───────────────────────────────────────────
  function swPrevModule() {
    if (swCurrentIdx <= 0) {
      swCurrentIdx = -1;
      swShowPage('welcome');
      swUpdateDots();
    } else {
      swCurrentIdx--;
      swRenderModule();
      swShowPage('module');
      swUpdateDots();
    }
  }

  function swSkipModule() {
    swNextModule();
  }

  function swNextModule() {
    swCurrentIdx++;
    if (swCurrentIdx >= SETUP_MODULES.length) {
      swGoTest();
    } else {
      swRenderModule();
      swShowPage('module');
      swUpdateDots();
    }
  }

  // ─── Test Page ────────────────────────────────────────────
  function swGoTest() {
    swCurrentIdx = SETUP_MODULES.length;
    swShowPage('test');
    swUpdateDots();
    swRenderTestModules();
    setTimeout(swRunTests, 400);
  }

  function swRenderTestModules() {
    const wrap = document.getElementById('sw-test-modules');
    if (!wrap) return;
    wrap.innerHTML = '';
    SETUP_MODULES.forEach(function (mod) {
      wrap.innerHTML +=
        '<div class="sw-test-module-card" id="sw-tmc-' + mod.id + '">' +
        '<div class="sw-test-status-dot loading" id="sw-tdot-' + mod.id + '"></div>' +
        '<div class="sw-test-mod-info">' +
        '<div class="sw-test-mod-name"><i class="' + mod.icon + '"></i> ' + mod.name + '</div>' +
        '<div class="sw-test-mod-desc">' + mod.description.substring(0, 32) + '...</div>' +
        '</div>' +
        '<div class="sw-test-mod-status loading" id="sw-tst-' + mod.id + '">확인 중...</div>' +
        '</div>';
    });
  }

  async function swRunTests() {
    const hint = document.getElementById('sw-test-hint');
    if (hint) hint.classList.remove('show');
    SETUP_MODULES.forEach(function (mod) { swSetTestStatus(mod.id, 'loading', '확인 중...'); });

    try {
      const r = await fetch(API_BASE + '/api/status');
      const d = await r.json();
      const modules = (d.data && d.data.modules) || d.modules || {};
      let anyFail = false;

      SETUP_MODULES.forEach(function (mod) {
        if (mod.alwaysOn) {
          swSetTestStatus(mod.id, 'ok', '정상');
        } else if (!swConfigured.has(mod.id)) {
          swSetTestStatus(mod.id, 'skip', '건너뜀');
        } else {
          const m = modules[mod.id];
          if (m && (m.ok || m.status === 'ok' || m.active)) {
            swSetTestStatus(mod.id, 'ok', '정상');
          } else if (m) {
            swSetTestStatus(mod.id, 'fail', '실패');
            anyFail = true;
          } else {
            swSetTestStatus(mod.id, 'ok', '저장됨');
          }
        }
      });
      if (anyFail && hint) hint.classList.add('show');
    } catch (e) {
      SETUP_MODULES.forEach(function (mod) {
        swSetTestStatus(
          mod.id,
          mod.alwaysOn ? 'ok' : (swConfigured.has(mod.id) ? 'ok' : 'skip'),
          mod.alwaysOn ? '정상' : (swConfigured.has(mod.id) ? '저장됨' : '건너뜀')
        );
      });
      swToast('서버 연결을 확인할 수 없습니다.', 'info');
    }
  }

  function swSetTestStatus(id, state, label) {
    const dot = document.getElementById('sw-tdot-' + id);
    const st = document.getElementById('sw-tst-' + id);
    if (!dot || !st) return;
    dot.className = 'sw-test-status-dot ' + state;
    st.className = 'sw-test-mod-status ' + state;
    st.textContent = label;
  }

  // ─── Complete Page ────────────────────────────────────────
  function swGoComplete() {
    swCurrentIdx = SETUP_MODULES.length + 1;
    swShowPage('complete');
    swUpdateDots();
    localStorage.setItem('setup_complete', 'true');
    localStorage.setItem('setup_modules', JSON.stringify([...swConfigured]));

    const cnt = swConfigured.size;
    const countEl = document.getElementById('sw-active-count');
    const subEl = document.getElementById('sw-complete-sub');
    if (countEl) countEl.textContent = cnt;
    if (subEl) {
      subEl.textContent = cnt > 1
        ? cnt + '개 모듈이 준비되었습니다. 이제 시세 모니터에서 바로 시작하세요.'
        : '무료 기능으로 바로 시작할 수 있습니다. 언제든지 설정 페이지에서 추가할 수 있습니다.';
    }
  }

  // ─── Reset wizard ─────────────────────────────────────────
  function swResetWizard() {
    swCurrentIdx = -1;
    swConfigured = new Set(['free']);
    swExpandedForm = false;
    renderShell();
    swUpdateDots();
  }

  // ─── Utilities ────────────────────────────────────────────
  function swToggleVis(btn) {
    const inp = btn.parentElement.querySelector('input');
    if (!inp) return;
    if (inp.type === 'password') {
      inp.type = 'text';
      btn.innerHTML = '<i class="fas fa-eye-slash"></i>';
    } else {
      inp.type = 'password';
      btn.innerHTML = '<i class="fas fa-eye"></i>';
    }
  }

  async function swPreloadModuleKeys(mod) {
    try {
      const r = await fetch(API_BASE + '/api/keys');
      const d = await r.json();
      const keys = d.keys || {};
      mod.keys.forEach(function (k) {
        if (k.divider) return;
        const el = document.getElementById('sw-key-' + k.id);
        if (el && keys[k.id]) {
          el.value = keys[k.id];
          swConfigured.add(mod.id);
        }
      });
    } catch (_) {}
  }

  // ─── Check if setup is needed ─────────────────────────────
  async function swCheckSetupNeeded() {
    // If already completed before, show a resume option
    const done = localStorage.getItem('setup_complete');
    if (done === 'true') {
      return false; // Not needed — user has completed before
    }
    // Also check if server already has keys
    try {
      const r = await fetch(API_BASE + '/api/keys');
      const d = await r.json();
      const keys = d.keys || {};
      if (Object.keys(keys).length > 0) {
        return false; // Keys already configured
      }
    } catch (_) {}
    return true;
  }

  // ─── Public: initSetupWizard ──────────────────────────────
  /**
   * Call this when the panel-setup-wizard becomes visible.
   * It renders the wizard shell and starts from the beginning,
   * unless setup was already completed (in which case it shows
   * a summary/re-run option).
   */
  async function initSetupWizard() {
    const root = swRoot();
    if (!root) {
      console.warn('[setup-wizard] #setup-wizard-content not found');
      return;
    }

    // Always re-render the shell to ensure fresh state when
    // the panel is switched to
    renderShell();

    const needed = await swCheckSetupNeeded();
    if (!needed) {
      // Already set up — show a lighter welcome with option to reconfigure
      root.querySelector && (() => {
        const welcomeTitle = root.querySelector('.sw-welcome-title');
        const welcomeSub = root.querySelector('.sw-welcome-sub');
        const welcomeDesc = root.querySelector('.sw-welcome-desc');
        const btnRow = root.querySelector('.sw-btn-row');
        if (welcomeTitle) welcomeTitle.textContent = 'OpenClaw Stock Kit';
        if (welcomeSub) welcomeSub.textContent = '설정이 이미 완료되어 있습니다';
        if (welcomeDesc) welcomeDesc.textContent = '새로 설정하려면 아래 버튼을 클릭하세요. 기존 키는 덮어씌워집니다.';
        if (btnRow) {
          btnRow.innerHTML =
            '<button class="sw-btn sw-btn-secondary" onclick="window._swStartSetup()" style="flex:1">다시 설정하기</button>' +
            '<button class="sw-btn sw-btn-primary" onclick="window.switchPanel && window.switchPanel(\'volume-surge\')" style="flex:1">시작하기 →</button>';
        }
      })();
    }

    swUpdateDots();
  }

  // ─── Expose globals for inline onclick handlers ───────────
  // (inline onclick= can't reach module-scoped vars)
  window._swStartSetup   = swStartSetup;
  window._swNextModule   = swNextModule;
  window._swPrevModule   = swPrevModule;
  window._swSkipModule   = swSkipModule;
  window._swToggleSetup  = swToggleSetup;
  window._swToggleVis    = swToggleVis;
  window._swRunTests     = swRunTests;
  window._swGoComplete   = swGoComplete;
  window._swResetWizard  = swResetWizard;
  window._swTgCheckStatus = swTgCheckStatus;
  window._swTgSendCode   = swTgSendCode;
  window._swTgVerify     = swTgVerify;
  window._swTgVerify2fa  = swTgVerify2fa;

  // ─── Public API ───────────────────────────────────────────
  window.initSetupWizard = initSetupWizard;

})();
