// StockClaw Kit — Core (유틸리티, API, 설정, 대시보드, 연결)

        // ========== XSS 방어 유틸리티 ==========
        // HTML 특수문자 이스케이프 - innerHTML 사용 시 반드시 적용
        function escapeHtml(unsafe) {
            if (unsafe === null || unsafe === undefined) return '';
            return String(unsafe)
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        }

        // 숫자만 허용 (주가, 등락률 등)
        function sanitizeNumber(value) {
            const num = parseFloat(value);
            return isNaN(num) ? 0 : num;
        }

        // 종목코드 검증 (6자리 숫자)
        function sanitizeStockCode(code) {
            if (!code) return '';
            const cleaned = String(code).replace(/[^0-9A-Za-z]/g, '');
            return cleaned.substring(0, 6);
        }

        {
            // 잘못된 호스트 URL 강제 수정
            let savedHost = localStorage.getItem('kiwoom_host');

            // openapi 또는 openapivts가 포함되면 무조건 수정
            if (savedHost && !savedHost.includes('mockapi.kiwoom.com') && !savedHost.includes('api.kiwoom.com')) {
                savedHost = (savedHost.includes('vts') || savedHost.includes('mock'))
                    ? 'https://mockapi.kiwoom.com'
                    : 'https://api.kiwoom.com';
                localStorage.setItem('kiwoom_host', savedHost);
            }
        }

        // ========== StockClaw Kit API Layer ==========
        const API_BASE = (() => {
            if (window.stockClawAPI) return window.stockClawAPI.baseUrl;
            return window.location.origin || '';
        })();

        // method→api_code 매핑 (Electron kiwoom-proxy 호환)
        const KIWOOM_METHODS = {
            surgeStocks: 'ka10019',
            volumeSurge: 'ka10023',
            themeGroups: 'ka90001',
            themeStocks: 'ka90002',
            supplyDemand: 'ka90009',
            programTop50: 'ka90003',
            stockInfo: 'ka10001',
            investorTrend: 'ka10059',
            investorSummary: 'ka10061',
            investorChart: 'ka10060',
            realtimeRank: 'ka00198',
            stockQuote: 'ka10007',
            stockHoga: 'ka10004',
            ka10032: 'ka10032',
            ka10027: 'ka10027',
            ka10029: 'ka10029',
            programTrade: 'ka90013',
        };

        async function callKiwoom(method, params = {}) {
            const api_code = KIWOOM_METHODS[method] || method;
            const doCall = async () => {
                const res = await fetch(`${API_BASE}/api/kiwoom/call`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ api_code, params })
                });
                return await res.json();
            };

            let data = await doCall();

            // 토큰 에러 시 자동 갱신 후 1회 재시도 (issueToken 자체는 재시도 안 함)
            const errStr = !data.ok && data.error
                ? (typeof data.error === 'string' ? data.error : (data.error.message || JSON.stringify(data.error)))
                : '';
            if (errStr && api_code !== 'issueToken' &&
                (errStr.includes('token') || errStr.includes('Token') ||
                 errStr.includes('인증') || errStr.includes('401'))) {
                console.log('[callKiwoom] 토큰 에러 감지, 자동 갱신 시도:', errStr);
                try {
                    const tokenData = await callKiwoom('issueToken', {});
                    if (tokenData.success && tokenData.token) {
                        localStorage.setItem('kiwoom_token', tokenData.token);
                        console.log('[callKiwoom] 토큰 자동 갱신 성공, 재시도');
                        data = await doCall();
                    }
                } catch (e) {
                    console.log('[callKiwoom] 토큰 자동 갱신 실패:', e.message);
                }
            }

            if (!data.ok && data.error) {
                const msg = typeof data.error === 'string' ? data.error : (data.error.message || JSON.stringify(data.error));
                throw new Error(msg);
            }
            // 래퍼: result.success && result.data.xxx 패턴과 result.xxx 직접 접근 모두 지원
            const rawData = data.data || data;
            const wrapper = { success: true, data: rawData };
            if (typeof rawData === 'object' && rawData !== null) {
                for (const key of Object.keys(rawData)) {
                    if (key !== 'success' && key !== 'data') {
                        wrapper[key] = rawData[key];
                    }
                }
            }
            return wrapper;
        }

        // ========== kiwoomAPI Browser Shim (Electron preload 대체) ==========
        const kiwoomAPI = {
            async health() {
                try {
                    const res = await fetch(API_BASE + '/api/status');
                    const d = await res.json();
                    return { status: d.ok ? 'ok' : 'error', modules: d.modules };
                } catch { return { status: 'error' }; }
            },
            async status() {
                try {
                    const res = await fetch(API_BASE + '/api/status');
                    const d = await res.json();
                    return {
                        status: d.ok ? 'ok' : 'error',
                        active_modules: d.active_modules,
                        modules: d.modules,
                        token_status: d.modules?.kiwoom?.ok ? 'valid' : 'none'
                    };
                } catch { return { status: 'error' }; }
            },
            async realtimeRank(params = {}) {
                return await callKiwoom('realtimeRank', params);
            },
            async stockForum(code, page) {
                try {
                    const res = await fetch(`${API_BASE}/api/naver/forum?code=${code}&page=${page || 1}`);
                    return await res.json();
                } catch (e) {
                    return { success: false, error: e.message };
                }
            },
            async issueToken() {
                return await callKiwoom('issueToken', {});
            },
            // Config methods - browser mode uses localStorage / /api/keys
            async setHost(apiType) {
                localStorage.setItem('kiwoom_api_type', apiType);
                return { ok: true };
            },
            async saveCredentials(creds) {
                try {
                    const payload = {};
                    if (creds.appKey) payload.KIWOOM_APP_KEY = creds.appKey;
                    if (creds.secretKey) payload.KIWOOM_APP_SECRET = creds.secretKey;
                    const res = await fetch(API_BASE + '/api/keys', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(payload)
                    });
                    return await res.json();
                } catch { return { ok: false }; }
            },
            async loadCredentials() {
                try {
                    const res = await fetch(API_BASE + '/api/keys');
                    const d = await res.json();
                    return {
                        appKey: d.keys?.KIWOOM_APP_KEY || '',
                        secretKey: d.keys?.KIWOOM_APP_SECRET || '',
                        credentialsDir: ''
                    };
                } catch { return { appKey: '', secretKey: '', credentialsDir: '' }; }
            },
            async setToken(token) {
                localStorage.setItem('kiwoom_token', token);
                return { ok: true };
            },
            async setCredentialsFolder(folder) {
                // no-op in browser mode
                return { ok: true };
            },
            async scanFolder(folder) {
                // no-op in browser mode
                return { files: [] };
            }
        };

        async function callDataKit(fn, params = {}) {
            const res = await fetch(`${API_BASE}/api/datakit/call`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ function: fn, params })
            });
            return res.json();
        }

        async function callMembership(apiId, params = {}) {
            const res = await fetch(`${API_BASE}/api/membership/call`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ api_id: apiId, params })
            });
            return res.json();
        }

        async function getApiStatus() {
            const res = await fetch(`${API_BASE}/api/status`);
            return res.json();
        }

        async function loadSettings() {
            const res = await fetch(`${API_BASE}/api/keys`);
            return res.json();
        }

        async function saveSettings(keys) {
            const res = await fetch(`${API_BASE}/api/keys`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ keys })
            });
            return res.json();
        }
        let isConnected = false;
        let currentHost = '';  // 현재 API 호스트
        let currentToken = ''; // 현재 토큰

        // ==================== 사용자별 데이터 관리 ====================
        let currentUserId = null;  // 현재 로그인한 사용자 ID

        // 사용자 ID 초기화 (Desktop Token에서 추출)
        async function initCurrentUserId() {
            // StockClaw Kit은 로컬 실행 — 단일 사용자
            currentUserId = 'local';
            return currentUserId;
        }

        // 사용자별 localStorage 키 생성
        function getUserStorageKey(baseKey) {
            if (currentUserId) {
                return `${baseKey}_user_${currentUserId}`;
            }
            return baseKey;  // 사용자 ID 없으면 기본 키 사용
        }

        // 사용자별 데이터 저장
        function setUserData(baseKey, data) {
            try {
                const key = getUserStorageKey(baseKey);
                localStorage.setItem(key, JSON.stringify(data));
                console.log(`[Storage] 저장: ${key}`);
            } catch (e) {
                console.error(`[Storage] 저장 실패 (${baseKey}):`, e);
            }
        }

        // 사용자별 데이터 로드
        function getUserData(baseKey, defaultValue = null) {
            try {
                const key = getUserStorageKey(baseKey);
                const saved = localStorage.getItem(key);
                if (saved) {
                    return JSON.parse(saved);
                }
            } catch (e) {
                console.error(`[Storage] 로드 실패 (${baseKey}):`, e);
            }
            return defaultValue;
        }

        // 초기화
        document.addEventListener('DOMContentLoaded', async () => {
            // 메뉴 클릭 이벤트
            document.querySelectorAll('.menu-item').forEach(item => {
                item.addEventListener('click', () => {
                    const panelId = item.dataset.panel;
                    // dropdown-toggle은 data-panel이 없으므로 무시
                    if (panelId) {
                        switchPanel(panelId);
                    }
                });
            });

            // 첫 접속 감지: 키가 없으면 설정 마법사 자동 표시
            try {
                const statusRes = await fetch(API_BASE + '/api/keys');
                const statusData = await statusRes.json();
                const hasKeys = statusData.keys && Object.values(statusData.keys).some(v => v);
                if (!hasKeys) {
                    switchPanel('setup-wizard');
                }
            } catch (e) {
                console.warn('[init] 첫접속 감지 실패:', e);
            }

            // 서버 연결 상태 1회 확인 (10초 폴링 제거)
            await checkConnection();

            // ★ 사용자 ID 초기화 (사용자별 데이터 로드 전 필수)
            await initCurrentUserId();
            console.log('[init] 현재 사용자 ID:', currentUserId);

            // 바로 인증 정보 로드 (브라우저 모드에서는 isConnected가 항상 true)
            await loadCredentials();

            // 토큰이 있으면 자동으로 조건 목록 불러오기
            const token = localStorage.getItem('kiwoom_token');
            if (token) {
                await autoLoadConditions();
            }

            // 조건검색 실시간 상태 동기화 (페이지 복귀 시)
            await syncConditionRealtimeStatus();

            // API Keys 패널 초기화
            loadApiKeys();
            refreshApiStatus();

            // 대시보드 기본 패널 초기화
            initDashboard();
        });

        // 자동 조건 불러오기 (초기화 시)
        async function autoLoadConditions() {
            try {
                await loadConditions();
                // 조건이 있으면 첫 번째 조건 자동 선택
                const select = document.getElementById('conditionSelect');
                if (select.options.length > 1) {
                    select.selectedIndex = 1;  // 첫 번째 조건 선택 (0은 placeholder)
                    onConditionSelect();
                }

                // ★ 저장된 검색식이 있으면 자동으로 실시간 감시 시작
                setTimeout(() => {
                    autoStartSavedConditions();
                }, 1000);
            } catch (e) {
                console.log('조건 자동 로드 실패:', e.message);
            }
        }

        // 저장된 검색식 자동 실시간 시작
        async function autoStartSavedConditions() {
            try {
                // localStorage에서 저장된 선택 목록 로드
                loadSelectedConditionsFromStorage();

                // 저장된 조건이 없거나 이미 실시간 모니터링 중이면 스킵
                if (selectedConditionsForRealtime.length === 0) {
                    console.log('[AutoStart] 저장된 실시간 감시 검색식 없음');
                    return;
                }

                if (isRealtimeMonitoring) {
                    console.log('[AutoStart] 이미 실시간 모니터링 중');
                    return;
                }

                // 장 시간 체크 (08:55 ~ 15:30)
                const now = new Date();
                const currentTime = now.getHours() * 100 + now.getMinutes();
                if (currentTime < 855 || currentTime > 1530) {
                    console.log(`[AutoStart] 장 시간이 아님 (현재: ${currentTime})`);
                    return;
                }

                console.log(`[AutoStart] 저장된 ${selectedConditionsForRealtime.length}개 검색식 자동 실시간 시작...`);
                addLog(`앱 시작: 저장된 ${selectedConditionsForRealtime.length}개 검색식 자동 실시간 시작`, 'info');

                // startSelectedConditions와 동일한 로직
                try {
                    // 1. Desktop Token 전달 — StockClaw Kit 로컬 모드에서는 불필요
                    const token = null;  // StockClaw Kit 로컬 모드
                    // conditionSetToken은 HTTP 버전에서 불필요 (서버가 직접 관리)

                    // 2. 선택된 조건들만 실시간 감시 요청
                    for (const cond of selectedConditionsForRealtime) {
                        const res = await fetch(`${API_BASE}/api/kiwoom/condition/realtime`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({seq: cond.seq})});
                        const result = await res.json();
                        if (result.ok) {
                            addLog(`자동 시작: ${cond.name}`, 'success');
                        }
                        await new Promise(r => setTimeout(r, 300));
                    }

                    // 3. 메인 프로세스에 모니터링 시작 요청
                    await fetch(`${API_BASE}/api/kiwoom/condition/realtime`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({conditions: selectedConditionsForRealtime.map(c => ({ seq: c.seq, name: c.name }))})});

                    isRealtimeMonitoring = true;
                    document.getElementById('btnStartAll').style.display = 'none';
                    document.getElementById('btnStopAll').style.display = 'inline-flex';
                    document.getElementById('btnStopAll').disabled = false;
                    document.getElementById('realtimeStatus').innerHTML = '<span style="color: var(--success);"><i class="fas fa-circle fa-xs"></i> 실시간 감시 중 (자동)</span>';
                    document.getElementById('realtimeEmpty').style.display = 'none';
                    document.getElementById('realtimeTableContainer').style.display = 'block';
                    document.getElementById('conditionMonitorStatus').textContent = `${selectedConditionsForRealtime.length}개 감시 중`;

                    // 4. 렌더러 폴링도 시작
                    startRealtimePolling();

                    console.log(`[AutoStart] 자동 실시간 감시 시작 완료`);
                } catch (e) {
                    console.error('[AutoStart] 자동 실시간 시작 오류:', e.message);
                }
            } catch (e) {
                console.error('[AutoStart] 자동 시작 오류:', e);
            }
        }

        // 현재 호스트에 맞는 토큰 키 반환 (실전/모의 분리)
        function getTokenKey() {
            const host = localStorage.getItem('kiwoom_host') || '';
            return (host.includes('mockapi') || host.includes('vts')) ? 'kiwoom_token_mock' : 'kiwoom_token_real';
        }

        // 현재 호스트의 토큰 가져오기
        function getCurrentToken() {
            return localStorage.getItem(getTokenKey()) || '';
        }

        // 현재 호스트에 토큰 저장
        function setCurrentToken(token) {
            localStorage.setItem(getTokenKey(), token);
            // 레거시 호환: kiwoom_token에도 저장
            localStorage.setItem('kiwoom_token', token);
        }

        // 토큰이 있는지 확인하는 헬퍼 함수
        function hasValidToken() {
            const token = getCurrentToken();
            return token && token.length > 0;
        }

        // 분석도구 드롭다운 토글
        function toggleAnalysisDropdown(event) {
            event.stopPropagation();  // 이벤트 전파 차단 - 화면 변경 방지
            const menu = document.getElementById('analysisDropdownMenu');
            const toggle = menu.previousElementSibling;
            if (menu.style.display === 'none') {
                menu.style.display = 'block';
                toggle.classList.add('open');
            } else {
                menu.style.display = 'none';
                toggle.classList.remove('open');
            }
        }

        // 설정 드롭다운 토글
        function toggleSettingsDropdown(event) {
            event.stopPropagation();  // 이벤트 전파 차단 - 화면 변경 방지
            const menu = document.getElementById('settingsDropdownMenu');
            const toggle = menu.previousElementSibling;
            if (menu.style.display === 'none') {
                menu.style.display = 'block';
                toggle.classList.add('open');
            } else {
                menu.style.display = 'none';
                toggle.classList.remove('open');
            }
        }

        // ========== Dashboard: AI Tool Mission Control ==========
        async function initDashboard() {
            const container = document.getElementById('dash-content');
            if (!container) return;

            let statusData = { ok: false, modules: {}, active_modules: '0/0', total_tools: 0 };
            let keysData = { keys: {} };

            let kospiData = null, kosdaqData = null;
            try {
                const [sRes, kRes, kospiRes, kosdaqRes] = await Promise.allSettled([
                    fetch(API_BASE + '/api/status').then(r => r.json()),
                    fetch(API_BASE + '/api/keys').then(r => r.json()),
                    callKiwoom('ka10001', { stk_cd: '069500' }).catch(() => null),
                    callKiwoom('ka10001', { stk_cd: '229200' }).catch(() => null)
                ]);
                if (sRes.status === 'fulfilled') statusData = sRes.value;
                if (kRes.status === 'fulfilled') keysData = kRes.value;
                if (kospiRes.status === 'fulfilled') kospiData = kospiRes.value;
                if (kosdaqRes.status === 'fulfilled') kosdaqData = kosdaqRes.value;
            } catch (e) {
                console.warn('[Dashboard] API 호출 실패:', e);
            }

            // 시장 지수 파싱
            function parseStockData(raw) {
                if (!raw || !raw.success) return null;
                const d = raw.data || raw;
                const price = Math.abs(parseInt(d.cur_prc || 0));
                const change = parseInt(d.pred_pre || 0);
                const rate = parseFloat(d.flu_rt || 0);
                if (!price) return null;
                return { value: price, change: change, changeRate: rate };
            }
            const kospiParsed = parseStockData(kospiData);
            const kosdaqParsed = parseStockData(kosdaqData);

            const modules = statusData.modules || {};
            const keys = keysData.keys || {};
            const displayModules = Object.keys(modules).filter(k => k !== 'premium');
            const totalModules = displayModules.length;
            const activeModules = displayModules.filter(k => modules[k].ok).length;
            // 모듈별 필요 키 매핑 (apiCount: 실제 함수 수 하드코딩)
            const moduleKeyMap = {
                datakit: { label: 'DataKit', icon: 'fa-database', color: '#3b82f6',
                    desc: '주가·공시·경제통계 (PyKRX, DART, ECOS)',
                    apiCount: 13,
                    keys: ['DART_API_KEY', 'ECOS_API_KEY', 'EXIM_API_KEY'] },
                kiwoom: { label: '키움증권', icon: 'fa-chart-line', color: '#ef4444',
                    desc: '실시간 시세·주문·조건검색',
                    apiCount: 185,
                    keys: ['KIWOOM_APP_KEY', 'KIWOOM_APP_SECRET'] },
                kis: { label: '한국투자', icon: 'fa-landmark', color: '#8b5cf6',
                    desc: '국내외 주식·채권·선물옵션',
                    apiCount: 166,
                    keys: ['KIS_APP_KEY', 'KIS_APP_SECRET'] },
                news: { label: '뉴스·텔레그램', icon: 'fa-newspaper', color: '#f59e0b',
                    desc: '네이버 뉴스 검색·텔레그램 채널',
                    apiCount: 8,
                    keys: ['NAVER_CLIENT_ID', 'NAVER_CLIENT_SECRET', 'TELEGRAM_API_ID'] },
                membership: { label: '멤버십', icon: 'fa-crown', color: '#10b981',
                    desc: '프리미엄 데이터 피드 + AI 브리핑',
                    apiCount: 10,
                    keys: ['MEMBERSHIP_API_KEY'],
                    mergedModules: ['premium', 'membership'] }
            };
            // moduleKeyMap.apiCount 우선, 없으면 description 파싱, 최후엔 tools.length
            function getApiCount(moduleId, mod) {
                const meta = moduleKeyMap[moduleId];
                if (meta?.apiCount) return meta.apiCount;
                const match = mod.description?.match(/\((\d+)\s*APIs/i);
                return match ? parseInt(match[1]) : (mod.tools?.length || 0);
            }
            const totalApis = Object.entries(modules)
                .filter(([id]) => id !== 'premium')
                .reduce((sum, [id, m]) => sum + getApiCount(id, m), 0);
            const totalKeys = Object.keys(keys).length;

            // 모듈 카드 생성
            let moduleCards = '';
            for (const [id, mod] of Object.entries(modules)) {
                // premium은 membership과 합쳐서 표시
                if (id === 'premium') continue;
                const meta = moduleKeyMap[id] || { label: id, icon: 'fa-puzzle-piece', color: '#6b7280', desc: '', keys: [] };
                const isOk = mod.ok;
                const apiCount = getApiCount(id, mod);

                // 키 상태 계산
                const requiredKeys = meta.keys;
                const configuredKeys = requiredKeys.filter(k => keys[k]);
                const keyStatus = requiredKeys.length === 0
                    ? '<span style="color: var(--text-muted); font-size: 11px;">키 불필요</span>'
                    : `<span style="font-size: 11px; color: ${configuredKeys.length === requiredKeys.length ? 'var(--green, #22c55e)' : 'var(--orange, #f59e0b)'};">${configuredKeys.length}/${requiredKeys.length} 키 설정</span>`;

                moduleCards += `
                <div style="background: var(--bg-card, #1e1e2e); border: 1px solid var(--border, #2e2e3e); border-radius: 12px; padding: 16px; display: flex; flex-direction: column; gap: 10px;">
                    <div style="display: flex; align-items: center; justify-content: space-between;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <div style="width: 36px; height: 36px; border-radius: 8px; background: ${meta.color}22; display: flex; align-items: center; justify-content: center;">
                                <i class="fas ${meta.icon}" style="color: ${meta.color}; font-size: 16px;"></i>
                            </div>
                            <div>
                                <div style="font-weight: 600; font-size: 14px;">${meta.label}</div>
                                <div style="font-size: 11px; color: var(--text-muted, #888);">${meta.desc}</div>
                            </div>
                        </div>
                        <div style="width: 8px; height: 8px; border-radius: 50%; background: ${isOk ? '#22c55e' : '#ef4444'};"></div>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 6px; border-top: 1px solid var(--border, #2e2e3e);">
                        <span style="font-size: 12px; color: var(--text-muted, #888);"><i class="fas fa-wrench" style="margin-right: 4px;"></i>${apiCount} APIs</span>
                        ${keyStatus}
                    </div>
                </div>`;
            }

            // 시장 카드 렌더 헬퍼
            function renderMarketCard(label, icon, parsed, color) {
                if (!parsed) {
                    return `<div class="stat-card" style="flex: 1; min-width: 200px;">
                        <div class="stat-icon" style="background: ${color}22; color: ${color};"><i class="fas ${icon}"></i></div>
                        <div class="stat-info"><h3 style="font-size: 20px; color: var(--text-muted);">--</h3><p>${label}</p></div>
                    </div>`;
                }
                const chgColor = parsed.change > 0 ? 'var(--red)' : parsed.change < 0 ? '#3b82f6' : 'var(--text-muted)';
                const arrow = parsed.change > 0 ? 'fa-caret-up' : parsed.change < 0 ? 'fa-caret-down' : '';
                const sign = parsed.change > 0 ? '+' : '';
                return `<div class="stat-card" style="flex: 1; min-width: 200px;">
                    <div class="stat-icon" style="background: ${color}22; color: ${color};"><i class="fas ${icon}"></i></div>
                    <div class="stat-info">
                        <h3 style="font-size: 20px;">${parsed.value.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})}</h3>
                        <p style="display:flex;align-items:center;gap:6px;">${label}
                            <span style="color:${chgColor};font-size:12px;font-weight:600;">
                                ${arrow ? '<i class="fas ' + arrow + '"></i>' : ''}${sign}${parsed.change.toFixed(2)} (${sign}${parsed.changeRate.toFixed(2)}%)
                            </span>
                        </p>
                    </div>
                </div>`;
            }

            container.innerHTML = `
                <div style="display: flex; align-items: center; justify-content: flex-end; margin-bottom: 16px;">
                    <button onclick="initDashboard()" style="padding: 6px 12px; font-size: 12px; background: var(--surface, #252535); border: 1px solid var(--border, #2e2e3e); color: var(--text, #e0e0e0); border-radius: 6px; cursor: pointer;">
                        <i class="fas fa-sync-alt"></i> 새로고침
                    </button>
                </div>

                <!-- 시장 지수 카드 -->
                <div class="market-stat-row" style="display: flex; gap: 12px; margin-bottom: 16px; flex-wrap: wrap;">
                    ${renderMarketCard('KODEX 200', 'fa-chart-line', kospiParsed, '#ef4444')}
                    ${renderMarketCard('KODEX 코스닥150', 'fa-chart-area', kosdaqParsed, '#3b82f6')}
                </div>

                <!-- 급등 종목 프리뷰 (비동기 로드) -->
                <div id="dashSurgePreview"></div>

                <!-- 구분선 -->
                <div style="border-top: 1px solid var(--border); margin: 20px 0; opacity: 0.5;"></div>

                <!-- API 상태 -->
                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 16px;">
                    <i class="fas fa-server" style="color: var(--text-muted);"></i>
                    <span style="font-size: 14px; font-weight: 600;">API 현황</span>
                    <span style="font-size: 12px; color: ${statusData.ok ? 'var(--green)' : 'var(--red)'}; margin-left: auto;">${statusData.ok ? '정상' : '오류'}</span>
                </div>

                <!-- 요약 stat bar -->
                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 20px;">
                    <div style="background: var(--bg-card, #1e1e2e); border: 1px solid var(--border, #2e2e3e); border-radius: 10px; padding: 14px 16px; text-align: center;">
                        <div style="font-size: 28px; font-weight: 700; color: ${activeModules === totalModules ? '#22c55e' : '#f59e0b'};">${activeModules}/${totalModules}</div>
                        <div style="font-size: 12px; color: var(--text-muted, #888); margin-top: 2px;">모듈</div>
                    </div>
                    <div style="background: var(--bg-card, #1e1e2e); border: 1px solid var(--border, #2e2e3e); border-radius: 10px; padding: 14px 16px; text-align: center;">
                        <div style="font-size: 28px; font-weight: 700; color: var(--accent, #6c8cff);">${totalApis}</div>
                        <div style="font-size: 12px; color: var(--text-muted, #888); margin-top: 2px;">APIs</div>
                    </div>
                    <div style="background: var(--bg-card, #1e1e2e); border: 1px solid var(--border, #2e2e3e); border-radius: 10px; padding: 14px 16px; text-align: center;">
                        <div style="font-size: 28px; font-weight: 700; color: #22c55e;">${totalKeys}</div>
<div style="font-size: 12px; color: var(--text-muted, #888); margin-top: 2px;">API 키</div>
                    </div>
                    <div style="background: var(--bg-card, #1e1e2e); border: 1px solid var(--border, #2e2e3e); border-radius: 10px; padding: 14px 16px; text-align: center;">
                        <div style="font-size: 28px; font-weight: 700; color: var(--text, #e0e0e0);">${statusData.ok ? 'ON' : 'OFF'}</div>
                        <div style="font-size: 12px; color: var(--text-muted, #888); margin-top: 2px;">서버</div>
                    </div>
                </div>

                <!-- 모듈 카드 그리드 -->
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 12px; margin-bottom: 20px;">
                    ${moduleCards}
                </div>

            `;

            // 급등 종목 프리뷰 비동기 로드
            loadDashSurgePreview();
        }
        window.initDashboard = initDashboard;

        // ========== Dashboard: 급등 종목 프리뷰 ==========
        async function loadDashSurgePreview() {
            const container = document.getElementById('dashSurgePreview');
            if (!container) return;

            container.innerHTML = `
                <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 16px;">
                    <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
                        <i class="fas fa-bolt" style="color: var(--orange);"></i>
                        <h3 style="margin: 0; font-size: 16px;">급등 종목</h3>
                        <span style="font-size: 11px; color: var(--text-muted);"><i class="fas fa-spinner fa-spin"></i></span>
                    </div>
                    <div style="text-align: center; padding: 20px; color: var(--text-muted);"><i class="fas fa-spinner fa-spin"></i></div>
                </div>`;

            if (!hasValidToken()) {
                container.innerHTML = `
                    <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 16px;">
                        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
                            <i class="fas fa-bolt" style="color: var(--orange);"></i>
                            <h3 style="margin: 0; font-size: 16px;">급등 종목</h3>
                        </div>
                        <div style="text-align: center; padding: 20px; color: var(--text-muted);">
                            <i class="fas fa-key" style="font-size: 20px; margin-bottom: 8px; display: block; opacity: 0.5;"></i>
                            <p style="margin: 0 0 8px;">키움 API 키를 설정하면 급등 종목을 확인할 수 있습니다</p>
                            <button onclick="switchPanel('setup-wizard')" style="padding: 5px 12px; font-size: 12px; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer;">
                                <i class="fas fa-magic"></i> 설정 마법사
                            </button>
                        </div>
                    </div>`;
                return;
            }

            try {
                const result = await callKiwoom('surgeStocks', {
                    mrkt_tp: '000', flu_tp: '1', tm_tp: '1', tm: '60',
                    trde_qty_tp: '0000', stk_cnd: '0', crd_cnd: '0',
                    pric_cnd: '0', updown_incls: '1', stex_tp: '1'
                });
                if (result.success && result.data) {
                    const items = (result.data.pric_jmpflu || result.data || []);
                    const list = Array.isArray(items) ? items.slice(0, 10) : [];
                    renderDashSurgeTable(container, list);
                } else {
                    throw new Error('데이터 없음');
                }
            } catch (e) {
                console.warn('[Dashboard Surge]', e);
                container.innerHTML = `
                    <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 16px;">
                        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
                            <i class="fas fa-bolt" style="color: var(--orange);"></i>
                            <h3 style="margin: 0; font-size: 16px;">급등 종목</h3>
                        </div>
                        <div style="text-align: center; padding: 20px; color: var(--text-muted);">
                            <i class="fas fa-exclamation-circle" style="font-size: 18px; margin-bottom: 6px; display: block; opacity: 0.5;"></i>
                            <p style="margin: 0; font-size: 13px;">데이터를 불러올 수 없습니다</p>
                            <p style="margin: 4px 0 0; font-size: 11px; opacity: 0.7;">${escapeHtml(e.message)}</p>
                        </div>
                    </div>`;
            }
        }

        function renderDashSurgeTable(container, items) {
            if (!items || items.length === 0) {
                container.innerHTML = `
                    <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 16px;">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <i class="fas fa-bolt" style="color: var(--orange);"></i>
                            <h3 style="margin: 0; font-size: 16px;">급등 종목</h3>
                        </div>
                        <p style="text-align: center; padding: 20px; color: var(--text-muted);">현재 급등 종목이 없습니다</p>
                    </div>`;
                return;
            }

            const rows = items.map((item, idx) => {
                const code = item.stk_cd || item['9001'] || '';
                const name = item.stk_nm || item['9002'] || item.hts_kor_isnm || '';
                const price = parseInt(item.cur_prc || item['10'] || item.stck_prpr || 0);
                const rate = parseFloat(item.flu_rt || item['12'] || item.prdy_ctrt || 0);
                const color = rate > 0 ? 'var(--red)' : rate < 0 ? '#3b82f6' : 'var(--text)';
                const sign = rate > 0 ? '+' : '';
                return `<tr style="cursor:pointer;transition:background 0.15s;"
                            onmouseover="this.style.background='var(--surface2)'"
                            onmouseout="this.style.background='transparent'"
                            onclick="openStockDetailTab('${escapeHtml(code)}','${escapeHtml(name)}')">
                    <td style="text-align:center;padding:7px 6px;font-size:12px;color:var(--text-muted);">${idx+1}</td>
                    <td style="padding:7px 6px;font-weight:500;font-size:13px;">${name}</td>
                    <td style="text-align:right;padding:7px 6px;font-family:monospace;font-size:13px;">${price.toLocaleString()}</td>
                    <td style="text-align:right;padding:7px 6px;color:${color};font-weight:600;font-size:13px;">${sign}${rate.toFixed(2)}%</td>
                </tr>`;
            }).join('');

            container.innerHTML = `
                <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 16px;">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                        <h3 style="margin: 0; font-size: 16px; display: flex; align-items: center; gap: 8px;">
                            <i class="fas fa-bolt" style="color: var(--orange);"></i> 급등 종목
                        </h3>
                        <button onclick="switchPanel('volume-surge')" style="padding:4px 10px;font-size:11px;background:transparent;border:1px solid var(--border);color:var(--accent);border-radius:6px;cursor:pointer;">
                            전체보기 <i class="fas fa-arrow-right" style="font-size:10px;"></i>
                        </button>
                    </div>
                    <table style="width:100%;border-collapse:collapse;">
                        <thead><tr style="border-bottom:1px solid var(--border);">
                            <th style="text-align:center;padding:6px;font-size:11px;color:var(--text-muted);font-weight:500;">#</th>
                            <th style="text-align:left;padding:6px;font-size:11px;color:var(--text-muted);font-weight:500;">종목명</th>
                            <th style="text-align:right;padding:6px;font-size:11px;color:var(--text-muted);font-weight:500;">현재가</th>
                            <th style="text-align:right;padding:6px;font-size:11px;color:var(--text-muted);font-weight:500;">등락률</th>
                        </tr></thead>
                        <tbody>${rows}</tbody>
                    </table>
                </div>`;
        }

        // ========== Feeds: 데이터 피드 카탈로그 ==========
        async function initFeeds() {
            const container = document.getElementById('feeds-content');
            if (!container) return;
            if (container.dataset.loaded === 'true') return; // 중복 로드 방지

            // API 키 확인
            let hasKey = false;
            try {
                const res = await fetch(API_BASE + '/api/keys');
                const d = await res.json();
                hasKey = !!(d.keys?.MEMBERSHIP_API_KEY);
            } catch(e) {}

            // 서버 catalog에서 동적 로딩 (업데이트 없이도 신규 API 자동 반영)
            const FALLBACK_FEEDS = [
                { id: 'ka-002', name: '종목 뉴스 매칭', icon: '🔔', desc: '관심 종목의 뉴스를 실시간으로 매칭하여 알림' },
                { id: 'ka-003', name: '오전장 브리핑', icon: '☀️', desc: '시장 요약, 장전 뉴스, 관전 포인트 등 오전장 종합 분석' },
                { id: 'ka-004', name: '테마별 이벤트', icon: '🏷️', desc: 'AI반도체, 2차전지 등 테마별 시장 이벤트 분석' },
                { id: 'ka-005', name: '종목별 뉴스 통합', icon: '📰', desc: '다중 채널 뉴스를 종목 기준으로 통합 제공' },
                { id: 'ka-006', name: 'AI 일일 요약', icon: '🤖', desc: 'AI가 분석한 시장 상황 자동 요약 리포트' },
                { id: 'ka-007', name: '뉴욕증시', icon: '🗽', desc: '미국 주요 지수 및 글로벌 시장 동향' },
                { id: 'ka-008', name: '주도주 시황', icon: '📊', desc: '시장 주도주 및 핵심 테마 흐름 분석' },
                { id: 'ka-009', name: '장전 뉴스', icon: '🌅', desc: '장 시작 전 반드시 확인해야 할 주요 뉴스' },
                { id: 'ka-010', name: '오후장 특징종목', icon: '📈', desc: '오후 시간대 급등·급락 특징 종목 분석' },
            ];

            let feeds = FALLBACK_FEEDS;
            try {
                const apiKey = localStorage.getItem('MEMBERSHIP_API_KEY') || '';
                const headers = { 'Content-Type': 'application/json' };
                if (apiKey) headers['X-API-Key'] = apiKey;
                const fetchOpts = { headers };
                if (typeof AbortSignal !== 'undefined' && AbortSignal.timeout) {
                    fetchOpts.signal = AbortSignal.timeout(5000);
                }
                const catalogRes = await fetch('https://readinginvestor.com/api/feed/catalog', fetchOpts);
                if (catalogRes.ok) {
                    const catalogData = await catalogRes.json();
                    if (catalogData.feeds && catalogData.feeds.length > 0) {
                        feeds = catalogData.feeds;
                    } else if (Array.isArray(catalogData) && catalogData.length > 0) {
                        feeds = catalogData;
                    }
                }
            } catch(e) { /* 오프라인/장애 시 fallback 사용 */ }

            let feedCards = feeds.map(f => `
                <div style="display: flex; align-items: flex-start; gap: 12px; padding: 14px 16px; background: var(--bg-card, #1e1e2e); border: 1px solid var(--border, #2e2e3e); border-radius: 10px;">
                    <div style="font-size: 22px; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; background: rgba(108,140,255,0.1); border-radius: 8px; flex-shrink: 0;">${f.icon}</div>
                    <div style="flex: 1; min-width: 0;">
                        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
                            <span style="font-weight: 600; font-size: 14px;">${f.name}</span>
                            <code style="font-size: 11px; color: var(--accent, #6c8cff); background: rgba(108,140,255,0.1); padding: 1px 6px; border-radius: 4px;">${f.id}</code>
                        </div>
                        <div style="font-size: 13px; color: var(--text-muted, #888); line-height: 1.4;">${f.desc}</div>
                    </div>
                </div>
            `).join('');

            const statusBadge = hasKey
                ? '<span style="display: inline-flex; align-items: center; gap: 4px; font-size: 12px; color: #22c55e; background: rgba(34,197,94,0.1); padding: 4px 10px; border-radius: 6px;"><i class="fas fa-check-circle"></i> API 키 설정됨</span>'
                : '<span style="display: inline-flex; align-items: center; gap: 4px; font-size: 12px; color: #f59e0b; background: rgba(245,158,11,0.1); padding: 4px 10px; border-radius: 6px;"><i class="fas fa-exclamation-circle"></i> API 키 미설정</span>';

            container.innerHTML = `
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                    <h2 style="margin: 0; font-size: 20px;">데이터 피드</h2>
                    ${statusBadge}
                </div>
                <p style="font-size: 14px; color: var(--text-muted, #888); margin-bottom: 20px; line-height: 1.5;">
                    AI가 분석한 주식 뉴스, 테마 시황, 시장 요약을 REST API로 제공합니다.<br>
                    엔드포인트: <code style="color: var(--accent, #6c8cff);">readinginvestor.com/api/feed/{api-id}</code> &nbsp;|&nbsp; Rate Limit: 120회/분
                </p>

                <div style="display: grid; gap: 8px; margin-bottom: 24px;">
                    ${feedCards}
                </div>

                ${!hasKey ? `
                <div style="background: linear-gradient(135deg, rgba(108,140,255,0.08), rgba(139,92,246,0.08)); border: 1px solid rgba(108,140,255,0.2); border-radius: 12px; padding: 24px; text-align: center;">
                    <div style="font-size: 24px; margin-bottom: 8px;">🔑</div>
                    <div style="font-size: 16px; font-weight: 600; margin-bottom: 6px;">멤버십으로 ${feeds.length}개 API 전체 이용</div>
                    <div style="font-size: 13px; color: var(--text-muted, #888); margin-bottom: 16px; line-height: 1.5;">
                        readinginvestor.com 멤버십에 가입하면 API 키가 자동 발급됩니다.<br>
                        <a href="https://readinginvestor.com/my-page" target="_blank" style="color: var(--accent, #6c8cff);">내정보</a> → API 키 탭에서 키를 복사해 설정 페이지에 입력하세요.
                    </div>
                    <a href="https://readinginvestor.com/pricing" target="_blank" rel="noopener"
                       style="display: inline-block; padding: 10px 24px; background: var(--accent, #6c8cff); color: white; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 14px;">
                        멤버십 가입하기
                    </a>
                    <div style="margin-top: 10px;">
                        <a href="https://readinginvestor.com/api-docs" target="_blank" rel="noopener"
                           style="font-size: 12px; color: var(--accent, #6c8cff); text-decoration: none;">
                            API 문서 보기 →
                        </a>
                    </div>
                </div>
                ` : `
                <div style="background: var(--bg-card, #1e1e2e); border: 1px solid var(--border, #2e2e3e); border-radius: 10px; padding: 16px; display: flex; align-items: center; justify-content: space-between;">
                    <div>
                        <div style="font-size: 14px; font-weight: 600; margin-bottom: 2px;">멤버십 활성화됨</div>
                        <div style="font-size: 12px; color: var(--text-muted, #888);">${feeds.length}개 API 전체 이용 가능 · 120회/분</div>
                    </div>
                    <a href="https://readinginvestor.com/api-docs" target="_blank" rel="noopener"
                       style="padding: 8px 16px; background: var(--surface, #252535); border: 1px solid var(--border, #2e2e3e); color: var(--text, #e0e0e0); border-radius: 6px; text-decoration: none; font-size: 13px;">
                        API 문서
                    </a>
                </div>
                `}
            `;

            container.dataset.loaded = 'true';
        }
        window.initFeeds = initFeeds;

        // 패널 전환
        function switchPanel(panelId) {
            // topbar 패널명 업데이트
            const _panelNames = {
                'dashboard': '대시보드', 'setup-wizard': '설정 마법사', 'credentials': 'API Keys',
                'feeds': '데이터 피드', 'stock-detail': '종목 상세', 'volume-surge': '시세 모니터',
                'vi-monitor': 'VI 모니터', 'supply-demand': '수급/프로그램', 'theme-analysis': '테마 분석',
                'condition-search': '조건검색', 'chart': '차트', 'stock-supply': '수급 분석',
                'program-trade': '프로그램매매', 'stock-search': '종토방', 'news-search': '뉴스 검색',
                'telegram-channels': '채널 관리', 'telegram-viewer': '메시지 뷰어'
            };
            const _topName = document.getElementById('topbarPanelName');
            if (_topName) _topName.textContent = _panelNames[panelId] || panelId;

            // 메뉴 활성화
            document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
            const targetItem = document.querySelector(`[data-panel="${panelId}"]`);
            if (targetItem) targetItem.classList.add('active');

            // 패널 표시
            document.querySelectorAll('.content-panel').forEach(p => p.classList.remove('active'));
            const targetPanel = document.getElementById(`panel-${panelId}`);
            if (targetPanel) {
                targetPanel.classList.add('active');
            } else {
                console.warn(`패널을 찾을 수 없음: panel-${panelId}`);
                return;
            }

            // 대시보드 패널 진입 시 초기화
            if (panelId === 'dashboard') {
                initDashboard();
            }
            if (panelId === 'feeds') {
                initFeeds();
            }
            if (panelId === 'news-search' && typeof initNewsSearch === 'function') {
                initNewsSearch();
            }
            // 설정 마법사 패널 진입 시 초기화
            if (panelId === 'setup-wizard' && typeof initSetupWizard === 'function') {
                initSetupWizard();
            }
            // API Keys 패널 진입 시 초기화
            if (panelId === 'credentials' && typeof initSettingsPanel === 'function') {
                initSettingsPanel();
            }

            // 차트 패널 진입 시 기본 차트 로드 (최초 1회만)
            if (panelId === 'chart' && !chartManager) {
                (async () => {
                    await initChartManager();
                    const defaultCode = document.getElementById('chartStockCode').value.trim() || '005930';
                    const stockName = getStockName(defaultCode);
                    chartManager.loadChart(defaultCode, 'daily', stockName);
                    addLog(`기본 차트 로드: ${defaultCode} ${stockName || ''}`, 'info');
                })();
            }

            // 토큰이 있을 때만 자동 조회 실행 (키움 API 관련 패널)
            // 텔레그램 뷰어는 Desktop Token 사용 - 키움 토큰 무관
            if (hasValidToken() || panelId === 'telegram-viewer' || panelId === 'telegram-channels') {
                setTimeout(() => {
                    autoFetchPanelData(panelId);
                }, 100);
            }

        }

        // 패널별 자동 조회 함수
        function autoFetchPanelData(panelId) {
            switch (panelId) {
                case 'volume-surge':
                    // 시세 모니터: 현재 활성 탭에 따라 조회
                    if (typeof fetchAllVolumeGridPanels === 'function') fetchAllVolumeGridPanels();
                    break;
                case 'theme-analysis':
                    if (typeof fetchThemeGroups === 'function') fetchThemeGroups();
                    break;
                case 'supply-demand':
                    if (typeof fetchSupplyDemand === 'function') fetchSupplyDemand();
                    break;
                case 'condition-search':
                    // 조건검색 탭: 실시간 상태 동기화 (탭 복귀 시 데이터 유지)
                    if (typeof syncConditionRealtimeStatus === 'function') {
                        syncConditionRealtimeStatus();
                    }
                    if (typeof autoLoadConditions === 'function') autoLoadConditions();
                    break;
                case 'vi-monitor':
                    if (typeof refreshViMonitor === 'function') refreshViMonitor();
                    break;
                case 'telegram-viewer':
                    // 텔레그램 뷰어: 채널 목록만 로드 (메시지는 크롤링/모니터링 버튼으로 수집)
                    TelegramUI.loadViewerChannels().catch(e => {
                        console.warn('[autoFetch] telegram-viewer 채널 로드 오류:', e);
                    });
                    break;
            }
        }

        // 연결 상태 확인 (IPC 기반)
        async function checkConnection() {
            if (!kiwoomAPI) {
                isConnected = false;
                updateConnectionUI(false);
                return;
            }

            try {
                const healthData = await kiwoomAPI.health();
                if (healthData.status === 'ok') {
                    isConnected = true;

                    // status API로 상세 정보 가져오기
                    try {
                        const statusData = await kiwoomAPI.status();
                        updateConnectionUI(true, statusData);
                    } catch (e) {
                        updateConnectionUI(true, {});
                    }
                } else {
                    isConnected = false;
                    updateConnectionUI(false);
                }
            } catch (e) {
                isConnected = false;
                updateConnectionUI(false);
            }
        }

        function updateConnectionUI(connected, data = {}) {
            const statusEl = document.getElementById('connectionStatus');
            const dotEl = document.getElementById('statusDot');
            const textEl = document.getElementById('statusText');

            if (connected) {
                statusEl.classList.add('connected');
                dotEl.classList.add('connected');
                textEl.textContent = 'Kiwoom API 연결됨';

                addLog('Kiwoom API 연결 성공', 'success');
            } else {
                statusEl.classList.remove('connected');
                dotEl.classList.remove('connected');
                textEl.textContent = 'Kiwoom API 연결 안됨';
            }

            // topbar 연결 배지 동기화
            const _topBadge = document.getElementById('topbarStatusBadge');
            const _topText = document.getElementById('topbarStatusText');
            if (_topBadge) {
                if (connected) {
                    _topBadge.classList.add('connected');
                    if (_topText) _topText.textContent = '연결됨';
                } else {
                    _topBadge.classList.remove('connected');
                    if (_topText) _topText.textContent = '연결 안됨';
                }
            }
        }

        // 로그 추가
        function addLog(message, type = 'info') {
            const logsEl = document.getElementById('systemLogs');
            if (!logsEl) return; // 대시보드에 로그 영역 없으면 스킵
            const time = new Date().toLocaleTimeString();
            const line = document.createElement('div');
            line.className = `log-line ${type}`;
            line.textContent = `[${time}] ${message}`;
            logsEl.appendChild(line);
            logsEl.scrollTop = logsEl.scrollHeight;
        }

        function clearLogs() {
            document.getElementById('systemLogs').innerHTML = '';
            addLog('로그가 초기화되었습니다', 'info');
        }
