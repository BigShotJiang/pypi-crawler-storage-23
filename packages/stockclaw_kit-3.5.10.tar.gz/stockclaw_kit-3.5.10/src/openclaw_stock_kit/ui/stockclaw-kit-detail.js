// StockClaw Kit — Detail (API설정, 차트, 종목상세, 수급분석, API키, 사이드바)
        function isMockHost(host) {
            return host.includes('openapivts') || host.includes('mockapi') || host.includes('vts');
        }

        async function onHostChange() {
            const host = 'local';
            const realCard = document.getElementById('realCredentialsCard');
            const mockCard = document.getElementById('mockCredentialsCard');
            const envDesc = document.getElementById('envDescription');
            const newApiType = isMockHost(host) ? 'mock' : 'real';

            if (isMockHost(host)) {
                // 모의투자: 직접 입력 UI 표시
                realCard.style.display = 'none';
                mockCard.style.display = 'block';
                envDesc.textContent = '모의투자 환경입니다. App Key와 Secret Key를 직접 입력하세요.';
            } else {
                // 실전투자: 폴더 선택 UI 표시
                realCard.style.display = 'block';
                mockCard.style.display = 'none';
                envDesc.textContent = '실전투자 환경입니다. 키 파일이 저장된 폴더를 선택하세요.';
            }

            // ★ 백엔드(Electron)에 호스트 변경 알림 - 항상 호출
            if (kiwoomAPI && kiwoomAPI.setHost) {
                try {
                    await kiwoomAPI.setHost(newApiType);
                } catch (e) {
                    console.error('[onHostChange] 호스트 변경 실패:', e);
                }
            }

            const oldHost = localStorage.getItem('kiwoom_host');
            const oldApiType = oldHost ? (isMockHost(oldHost) ? 'mock' : 'real') : null;

            // ★ 모드 전환 시 해당 모드의 저장된 설정+토큰 로드 (localStorage)
            {
                try {
                    const savedConfig = getUserData('kiwoom_config_' + newApiType);
                    const result = savedConfig ? { success: true, config: savedConfig } : { success: false };
                    if (result.success && result.config) {
                        const config = result.config;

                        // 인증 정보 UI에 표시
                        if (newApiType === 'mock' && config.appKey) {
                            document.getElementById('mockAppKey').value = config.appKey;
                            document.getElementById('mockSecretKey').value = config.secretKey || '';
                            // KiwoomAPI에도 설정 (세션용)
                            if (config.appKey && config.secretKey) {
                                await kiwoomAPI.saveCredentials({
                                    appKey: config.appKey,
                                    secretKey: config.secretKey,
                                    apiType: 'mock'
                                });
                            }
                        } else if (newApiType === 'real' && config.credentialsDir) {
                            document.getElementById('credentialsFolderPath').value = config.credentialsDir;
                            await kiwoomAPI.setCredentialsFolder(config.credentialsDir);
                        }

                        // 저장된 토큰이 있으면 적용
                        if (config.token) {
                            const isExpired = config.tokenExpiresAt && new Date(config.tokenExpiresAt) < new Date();
                            if (!isExpired) {
                                await kiwoomAPI.setToken(config.token);
                                localStorage.setItem('kiwoom_token', config.token);
                                document.getElementById('currentToken').value = '********** (저장된 토큰)';
                                setTokenStatus('저장된 토큰 적용됨', false);
                                addLog(`${newApiType === 'mock' ? '모의투자' : '실전투자'} 저장된 토큰 적용`, 'success');
                                localStorage.setItem('kiwoom_host', host);
                                return; // 저장된 토큰 적용 완료
                            } else {
                                addLog(`${newApiType === 'mock' ? '모의투자' : '실전투자'} 토큰 만료됨 - 재발급 필요`, 'warning');
                            }
                        }
                    }
                } catch (e) {
                    console.error('[onHostChange] 저장된 설정 로드 실패:', e);
                }
            }

            // 저장된 토큰이 없거나 만료된 경우 - 기존 토큰 삭제
            if (oldApiType && oldApiType !== newApiType) {
                localStorage.removeItem('kiwoom_token');
                localStorage.removeItem('kiwoom_token_expires');
                document.getElementById('currentToken').value = '';
                setTokenStatus('토큰 미발급', false);
                addLog(`⚠️ 환경 변경됨 (${oldApiType} → ${newApiType}). 토큰을 발급해주세요!`, 'warning');
            }

            localStorage.setItem('kiwoom_host', host);
            addLog(`접속 환경 변경: ${host}`, 'info');

            // ★ 마지막 사용 모드 저장 (localStorage)
            try {
                setUserData('kiwoom_last_mode', newApiType);
            } catch (e) {
                console.error('[onHostChange] 마지막 모드 저장 실패:', e);
            }
        }

        // API 호스트 설정 (IPC 기반)
        async function setApiHost(host) {
            if (!kiwoomAPI) return;
            try {
                const apiType = isMockHost(host) ? 'mock' : 'real';
                await kiwoomAPI.setHost(apiType);
            } catch (e) {
                console.error('호스트 설정 오류:', e);
            }
        }

        // 폴더 선택 (브라우저 파일 탐색기 사용)
        async function pickCredentialsFolder() {
            // 브라우저 환경: 파일 탐색기 사용
            document.getElementById('folderPicker').click();
        }

        // 브라우저에서 폴더 선택 시 처리
        function handleFolderSelect(event) {
            const files = event.target.files;
            if (files.length === 0) return;

            // 첫 번째 파일의 webkitRelativePath에서 폴더명 추출
            const firstFile = files[0];
            const folderPath = firstFile.webkitRelativePath.split('/')[0];

            document.getElementById('credentialsFolderPath').value = folderPath;

            // 선택된 파일들에서 appkey.txt, secretkey.txt 찾기
            let appKey = null;
            let secretKey = null;
            const fileList = [];

            for (const file of files) {
                const fileName = file.name.toLowerCase();
                fileList.push(file.name);

                if (fileName === 'appkey.txt' || fileName.includes('appkey')) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        appKey = e.target.result.trim();
                        updateCredentialsFromFiles(appKey, secretKey);
                    };
                    reader.readAsText(file);
                }

                if (fileName === 'secretkey.txt' || fileName.includes('secretkey') || fileName.includes('secret')) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        secretKey = e.target.result.trim();
                        updateCredentialsFromFiles(appKey, secretKey);
                    };
                    reader.readAsText(file);
                }
            }

            // 파일 힌트 업데이트
            document.getElementById('fileHint').textContent = `폴더 내 파일: ${fileList.join(', ')}`;
            document.getElementById('fileHint').style.color = 'var(--success)';
        }

        // 파일에서 읽은 자격증명 업데이트
        function updateCredentialsFromFiles(appKey, secretKey) {
            if (appKey && secretKey) {
                // Mock API 또는 실제 API에 저장
                if (kiwoomAPI && kiwoomAPI.saveCredentials) {
                    kiwoomAPI.saveCredentials({ appKey, secretKey, apiType: 'real' });
                }
                addLog('키 파일에서 자격증명 로드 완료', 'success');
            }
        }

        // 폴더 스캔 (파일 존재 확인) - IPC 기반
        async function scanFolder(folder) {
            if (!kiwoomAPI) return;
            try {
                const data = await kiwoomAPI.scanFolder(folder);
                if (data.success) {
                    // camelCase 응답 필드 (appkeyCount, secretkeyCount)
                    const appkeyCount = data.appkeyCount || data.appkey_count || 0;
                    const secretkeyCount = data.secretkeyCount || data.secretkey_count || 0;
                    document.getElementById('fileHint').textContent =
                        `appkey 파일 ${appkeyCount}개, secretkey 파일 ${secretkeyCount}개 발견`;
                    if (appkeyCount > 0 && secretkeyCount > 0) {
                        document.getElementById('fileHint').style.color = 'var(--success)';
                    }
                }
            } catch (e) {
                console.error('[scanFolder] 오류:', e);
                document.getElementById('fileHint').textContent = '폴더 스캔 실패';
            }
        }

        // credentials 폴더 설정 (IPC 기반)
        async function setCredentialsFolder(folder) {
            if (!kiwoomAPI) return;
            try {
                await kiwoomAPI.setCredentialsFolder(folder);

                // ★ localStorage에 저장
                setUserData('kiwoom_config_real', {credentialsDir: folder});
                addLog(`키 파일 폴더 설정: ${folder}`, 'success');
            } catch (e) {
                addLog('폴더 설정 오류: ' + e.message, 'error');
            }
        }

        // 모의투자 인증 정보 저장
        async function saveMockCredentials() {
            if (!kiwoomAPI) {
                alert('Kiwoom API가 초기화되지 않았습니다.');
                return;
            }

            const appKey = document.getElementById('mockAppKey').value.trim();
            const secretKey = document.getElementById('mockSecretKey').value.trim();

            if (!appKey || !secretKey) {
                alert('App Key와 Secret Key를 모두 입력해주세요.');
                return;
            }

            addLog('모의투자 인증 정보 저장 중...', 'info');

            try {
                // 1. KiwoomAPI 클래스에 저장 (세션용)
                const data = await kiwoomAPI.saveCredentials({
                    appKey: appKey,
                    secretKey: secretKey,
                    apiType: 'mock'
                });

                // 2. ★ localStorage에 저장
                setUserData('kiwoom_config_mock', {appKey: appKey, secretKey: secretKey});
                if (data.success) {
                    addLog('모의투자 인증 정보 저장 완료', 'success');
                } else {
                    addLog('저장 실패: ' + (data.error || 'Unknown'), 'error');
                    alert('저장 실패: ' + (data.error || 'Unknown'));
                }
            } catch (e) {
                addLog('저장 오류: ' + e.message, 'error');
                alert('저장 오류: ' + e.message);
            }
        }

        // 토큰 발급 (IPC 기반)
        async function issueToken() {
            if (!isConnected || !kiwoomAPI) {
                alert('Kiwoom API가 연결되지 않았습니다');
                return;
            }

            const host = 'local';

            // 모의투자인 경우 인증 정보 확인
            if (isMockHost(host)) {
                const appKey = document.getElementById('mockAppKey').value.trim();
                const secretKey = document.getElementById('mockSecretKey').value.trim();
                if (!appKey || !secretKey) {
                    alert('모의투자 App Key와 Secret Key를 입력해주세요.');
                    return;
                }
                // 먼저 저장
                await saveMockCredentials();
            }

            setTokenStatus('토큰 발급 중...', true);
            addLog('토큰 발급 중...', 'info');

            try {
                const data = await kiwoomAPI.issueToken();

                if (data.success) {
                    setTokenStatus('토큰 발급 완료', false);
                    // 토큰 표시 (마스킹)
                    if (data.token) {
                        document.getElementById('currentToken').value = data.token;
                        // localStorage에도 저장 (다른 탭에서 사용)
                        localStorage.setItem('kiwoom_token', data.token);

                        // ★ 모드별 토큰 저장 (localStorage)
                        const apiType = isMockHost(host) ? 'mock' : 'real';
                        {
                            // 기존 설정 로드 후 토큰 추가
                            const config = getUserData('kiwoom_config_' + apiType) || {};
                            config.token = data.token;
                            config.tokenExpiresAt = data.expires_at || null;
                            setUserData('kiwoom_config_' + apiType, config);
                            console.log(`[Storage] ${apiType} 토큰 저장 완료`);
                        }
                    }
                    addLog(`토큰 발급 성공: ${data.token_status}`, 'success');
                    // 화면 데이터만 갱신 (전체 새로고침 대신)
                    await refreshAfterTokenIssue();
                } else {
                    setTokenStatus('토큰 발급 실패: ' + data.error, false);
                    addLog('토큰 발급 실패: ' + data.error, 'error');
                    alert('토큰 발급 실패: ' + data.error);
                }
            } catch (e) {
                setTokenStatus('토큰 발급 오류', false);
                addLog('토큰 발급 오류: ' + e.message, 'error');
                alert('토큰 발급 오류: ' + e.message);
            }
        }

        // 토큰 발급/적용 후 화면 갱신 (전체 새로고침 대신)
        async function refreshAfterTokenIssue() {
            try {
                addLog('데이터 갱신 중...', 'info');

                // 1. 대시보드 상태 갱신
                const statusData = await kiwoomAPI.status();
                updateConnectionUI(true, statusData);

                // 2. 순위 데이터 조회
                await refreshAllRanks();

                // 3. 조건검색 목록 조회 시도
                try {
                    await loadConditionList();
                } catch (e) {
                    console.log('[refreshAfterTokenIssue] 조건목록 조회 실패 (무시):', e.message);
                }

                // 4. 마지막 동기화 시간 업데이트
                document.getElementById('lastSyncTime').textContent = new Date().toLocaleTimeString();

                addLog('데이터 갱신 완료', 'success');
            } catch (e) {
                console.error('[refreshAfterTokenIssue] 오류:', e);
                addLog('데이터 갱신 중 오류: ' + e.message, 'warning');
            }
        }

        // 토큰 상태 메시지 업데이트
        function setTokenStatus(message, busy) {
            document.getElementById('tokenStatusMsg').textContent = message;
        }

        // 토큰 복사
        async function copyToken() {
            const tokenInput = document.getElementById('currentToken');
            const token = tokenInput.value;

            if (!token || token === '토큰 미발급') {
                alert('복사할 토큰이 없습니다.');
                return;
            }

            try {
                await navigator.clipboard.writeText(token);
                alert('토큰이 클립보드에 복사되었습니다.');
            } catch (e) {
                // Fallback
                tokenInput.type = 'text';
                tokenInput.select();
                document.execCommand('copy');
                tokenInput.type = 'password';
                alert('토큰이 클립보드에 복사되었습니다.');
            }
        }

        // 외부 토큰 적용 (IPC 기반)
        async function applyExternalToken() {
            if (!kiwoomAPI) {
                alert('Kiwoom API가 초기화되지 않았습니다.');
                return;
            }

            const token = document.getElementById('externalToken').value.trim();

            if (!token) {
                alert('붙여넣은 토큰이 없습니다.');
                return;
            }

            // ★ 현재 선택된 호스트 확인 (실전/모의)
            const selectedHost = 'local';
            const apiType = isMockHost(selectedHost) ? '모의투자' : '실전투자';

            // 사용자에게 확인
            const confirmed = confirm(
                `외부 토큰을 적용합니다.\n\n` +
                `현재 선택된 환경: ${apiType}\n` +
                `호스트: ${selectedHost}\n\n` +
                `토큰이 ${apiType}용으로 발급된 것이 맞습니까?`
            );

            if (!confirmed) {
                addLog('토큰 적용 취소됨', 'warning');
                return;
            }

            try {
                const data = await kiwoomAPI.setToken(token);

                if (data.success) {
                    document.getElementById('currentToken').value = token;
                    document.getElementById('externalToken').value = '';
                    // localStorage에 토큰과 호스트 함께 저장
                    localStorage.setItem('kiwoom_token', token);
                    localStorage.setItem('kiwoom_host', selectedHost);
                    setTokenStatus('외부 토큰 적용됨', false);
                    addLog(`외부 토큰 적용 완료 (${apiType})`, 'success');
                    // 화면 데이터만 갱신 (전체 새로고침 대신)
                    await refreshAfterTokenIssue();
                } else {
                    alert('토큰 적용 실패: ' + data.error);
                }
            } catch (e) {
                addLog('토큰 적용 오류: ' + e.message, 'error');
                alert('토큰 적용 오류: ' + e.message);
            }
        }

        // 인증 정보 로드 (페이지 로드 시)
        async function loadCredentials() {
            if (!kiwoomAPI) return;

            try {
                // ★ 0. 마지막 사용 모드 로드 (우선 적용)
                let lastMode = null;
                try {
                    const lastModeResult = { success: true, data: getUserData('kiwoom_last_mode', 'mock') };
                    if (lastModeResult.success && lastModeResult.data) {
                        lastMode = lastModeResult.data;
                        console.log('[loadCredentials] 마지막 사용 모드 로드됨:', lastMode);
                    }
                } catch (e) {
                    console.error('[loadCredentials] 마지막 모드 로드 실패:', e);
                }

                // ★ 1. localStorage에서 먼저 로드 (우선)
                let userMockConfig = null;
                let userRealConfig = null;

                {
                    userMockConfig = getUserData('kiwoom_config_mock');
                    userRealConfig = getUserData('kiwoom_config_real');

                    if (userMockConfig) {
                        console.log('[loadCredentials] 사용자별 모의투자 설정 로드됨');
                    }
                    if (userRealConfig) {
                        console.log('[loadCredentials] 사용자별 실전투자 설정 로드됨');
                    }
                }

                // 2. KiwoomAPI에서도 로드 (fallback)
                const data = await kiwoomAPI.loadCredentials();
                console.log('[loadCredentials] KiwoomAPI 로드된 데이터:', data);

                if (data.success) {
                    // StockClaw Kit: 호스트 선택 불필요 (로컬 모드)
                    if (lastMode) {
                        console.log('[loadCredentials] 마지막 모드 로드됨:', lastMode);
                    }
                    await onHostChange();

                    // 모의투자 인증 정보 - 사용자별 저장소 우선
                    if (userMockConfig) {
                        document.getElementById('mockAppKey').value = userMockConfig.appKey || '';
                        document.getElementById('mockSecretKey').value = userMockConfig.secretKey || '';
                        // KiwoomAPI에도 설정 (세션용)
                        if (userMockConfig.appKey && userMockConfig.secretKey) {
                            await kiwoomAPI.saveCredentials({
                                appKey: userMockConfig.appKey,
                                secretKey: userMockConfig.secretKey,
                                apiType: 'mock'
                            });
                        }
                    } else if (data.mock && data.mock.appKey) {
                        document.getElementById('mockAppKey').value = data.mock.appKey;
                        if (data.mock.secretKey) {
                            document.getElementById('mockSecretKey').value = data.mock.secretKey;
                        } else if (data.mock.hasSecret) {
                            document.getElementById('mockSecretKey').placeholder = '저장됨 (변경 시에만 입력)';
                        }
                    }

                    // 실전투자 폴더 - 사용자별 저장소 우선
                    if (userRealConfig && userRealConfig.credentialsDir) {
                        document.getElementById('credentialsFolderPath').value = userRealConfig.credentialsDir;
                        // KiwoomAPI에도 설정 (세션용)
                        await kiwoomAPI.setCredentialsFolder(userRealConfig.credentialsDir);
                    } else if (data.real && data.real.credentialsDir) {
                        document.getElementById('credentialsFolderPath').value = data.real.credentialsDir;
                    }

                    // ★ 현재 모드의 저장된 토큰 로드 및 적용
                    const currentApiType = data.currentHost?.includes('mockapi') || data.currentHost?.includes('vts') ? 'mock' : 'real';
                    const currentConfig = currentApiType === 'mock' ? userMockConfig : userRealConfig;

                    if (currentConfig && currentConfig.token) {
                        // 토큰 만료 확인
                        const isExpired = currentConfig.tokenExpiresAt && new Date(currentConfig.tokenExpiresAt) < new Date();
                        if (!isExpired) {
                            // 유효한 토큰 → KiwoomAPI에 설정
                            await kiwoomAPI.setToken(currentConfig.token);
                            localStorage.setItem('kiwoom_token', currentConfig.token);
                            document.getElementById('currentToken').value = '********** (저장된 토큰)';
                            setTokenStatus('저장된 토큰 적용됨', false);
                            console.log(`[loadCredentials] ${currentApiType} 저장된 토큰 적용 완료`);
                            return; // 토큰 로드 완료, status 체크 스킵
                        } else {
                            console.log(`[loadCredentials] ${currentApiType} 토큰 만료됨 - 재발급 필요`);
                        }
                    }
                }

                // 토큰 상태 확인 (저장된 토큰이 없거나 만료된 경우)
                const statusData = await kiwoomAPI.status();
                console.log('[loadCredentials] 토큰 상태:', statusData);
                if (statusData.success && statusData.kiwoom) {
                    if (statusData.kiwoom.has_token) {
                        document.getElementById('currentToken').value = '********** (발급됨)';
                        setTokenStatus(statusData.kiwoom.token_status || '토큰 있음', false);
                    } else {
                        setTokenStatus('토큰 미발급', false);
                    }
                }

                // ★ 토큰이 없으면 자동 발급 시도
                if (!hasValidToken()) {
                    console.log('[loadCredentials] 토큰 없음 → 자동 발급 시도');
                    try {
                        const tokenData = await kiwoomAPI.issueToken();
                        if (tokenData.success && tokenData.token) {
                            localStorage.setItem('kiwoom_token', tokenData.token);
                            setCurrentToken(tokenData.token);
                            document.getElementById('currentToken').value = '********** (자동발급)';
                            setTokenStatus('토큰 자동발급 완료', false);
                            addLog('토큰 자동발급 성공', 'success');
                        }
                    } catch (e) {
                        console.log('[loadCredentials] 자동 토큰 발급 실패:', e.message);
                    }
                }
            } catch (e) {
                console.error('인증 정보 로드 실패:', e);
            }
        }

        // ========== 차트 관련 함수 ==========
        let chartManager = null;

        // 차트 매니저 초기화
        async function initChartManager() {
            if (chartManager) return;

            chartManager = new AIQuantChartManager({
                containerId: 'aiQuantChartContainer',
                proxyUrl: location.origin,  // 로컬 서버 프록시 사용 (CORS 회피)
            });
            console.log('[Chart] 차트 매니저 초기화 완료');
        }

        // 입력창에서 차트 로드
        async function loadChartFromInput() {
            const code = document.getElementById('chartStockCode').value.trim();
            if (!code) {
                alert('종목코드를 입력하세요');
                return;
            }
            await initChartManager();

            // 차트 탭 컨테이너로 복원 (종목상세에서 변경되었을 수 있음)
            const chartTabContainer = document.getElementById('aiQuantChartContainer');
            if (chartManager && chartTabContainer) {
                chartManager.container = chartTabContainer;
                chartManager.containerId = 'aiQuantChartContainer';
            }

            // 종목명 조회 (저장된 종목 목록에서)
            const stockName = getStockName(code);
            chartManager.loadChart(code, 'daily', stockName);
            addLog(`차트 로드: ${code} ${stockName || ''}`, 'info');
        }

        // 종목코드로 종목명 조회
        function getStockName(code) {
            // 대표 종목은 하드코딩
            const knownStocks = {
                '005930': '삼성전자',
                '000660': 'SK하이닉스',
                '373220': 'LG에너지솔루션',
                '207940': '삼성바이오로직스',
                '005380': '현대차',
                '051910': 'LG화학',
                '006400': '삼성SDI',
                '035420': 'NAVER',
                '000270': '기아',
                '035720': '카카오'
            };
            return knownStocks[code] || null;
        }

        // 종목코드+이름으로 차트 로드 (조건검색에서 호출)
        async function loadChartWithStock(code, name) {
            await initChartManager();

            // 차트 탭 컨테이너로 복원 (종목상세에서 변경되었을 수 있음)
            const chartTabContainer = document.getElementById('aiQuantChartContainer');
            if (chartManager && chartTabContainer) {
                chartManager.container = chartTabContainer;
                chartManager.containerId = 'aiQuantChartContainer';
            }

            chartManager.loadChart(code, chartManager?.currentPeriod || 'daily', name);
            addLog(`차트 로드: ${code} ${name}`, 'info');

            // 차트 패널로 이동
            document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
            document.querySelector('.menu-item[data-panel="chart"]').classList.add('active');
            document.querySelectorAll('.content-panel').forEach(panel => panel.classList.remove('active'));
            document.getElementById('panel-chart').classList.add('active');
        }

        // 기간 변경
        function changeChartPeriod(period) {
            if (!chartManager) return;
            chartManager.changePeriod(period);

            // 버튼 상태 업데이트
            document.querySelectorAll('.chart-period-btn').forEach(btn => {
                btn.classList.toggle('active', btn.dataset.period === period);
            });

        }

        // 새로고침
        function refreshChart() {
            if (chartManager) {
                chartManager.refresh();
            }
        }

        // 지표 토글 함수들
        function toggleChartMA(maKey, enabled) {
            if (chartManager) chartManager.toggleMA(maKey, enabled);
        }
        function toggleChartIchimoku(enabled) {
            if (chartManager) chartManager.toggleIchimoku(enabled);
        }
        function toggleChartBollinger(enabled) {
            if (chartManager) chartManager.toggleBollinger(enabled);
        }
        // 전체화면 토글
        function toggleFullscreen() {
            const chartContainer = document.getElementById('aiQuantChartContainer');
            const btn = document.getElementById('fullscreenBtn');

            if (!document.fullscreenElement) {
                // 전체화면 진입
                if (chartContainer.requestFullscreen) {
                    chartContainer.requestFullscreen();
                } else if (chartContainer.webkitRequestFullscreen) {
                    chartContainer.webkitRequestFullscreen();
                }
                if (btn) btn.innerHTML = '<i class="fas fa-compress"></i>';
            } else {
                // 전체화면 해제
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                } else if (document.webkitExitFullscreen) {
                    document.webkitExitFullscreen();
                }
                if (btn) btn.innerHTML = '<i class="fas fa-expand"></i>';
            }
        }

        // 전체화면 변경 이벤트 리스너
        document.addEventListener('fullscreenchange', () => {
            const btn = document.getElementById('fullscreenBtn');
            if (document.fullscreenElement) {
                if (btn) btn.innerHTML = '<i class="fas fa-compress"></i>';
                // 전체화면에서 차트 크기 조정
                if (chartManager && chartManager.chart) {
                    setTimeout(() => {
                        chartManager.chart.applyOptions({
                            width: window.innerWidth,
                            height: window.innerHeight
                        });
                    }, 100);
                }
            } else {
                if (btn) btn.innerHTML = '<i class="fas fa-expand"></i>';
            }
        });

        // 차트 이미지 저장
        function saveChartAsImage() {
            if (!chartManager || !chartManager.chart) {
                alert('차트가 로드되지 않았습니다.');
                return;
            }

            try {
                const canvas = chartManager.container.querySelector('canvas');
                if (canvas) {
                    const link = document.createElement('a');
                    link.download = `chart_${chartManager.currentCode || 'unknown'}_${new Date().toISOString().slice(0,10)}.png`;
                    link.href = canvas.toDataURL('image/png');
                    link.click();
                } else {
                    alert('캔버스를 찾을 수 없습니다.');
                }
            } catch (error) {
                console.error('차트 저장 오류:', error);
                alert('차트 저장 중 오류가 발생했습니다.');
            }
        }

        // F11 단축키로 전체화면
        document.addEventListener('keydown', (e) => {
            if (e.key === 'F11') {
                e.preventDefault();
                toggleFullscreen();
            }
        });

        // 지표 버튼 토글
        document.addEventListener('DOMContentLoaded', () => {
            const indicatorBtn = document.getElementById('indicatorBtn');
            const indicatorPanel = document.getElementById('indicatorPanel');
            if (indicatorBtn && indicatorPanel) {
                // 지표 버튼 클릭 시만 패널 토글
                indicatorBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    indicatorPanel.classList.toggle('hidden');
                });
                // 패널 외부 클릭 시 닫힘 (패널 내부 클릭은 유지)
                document.addEventListener('click', (e) => {
                    if (!indicatorBtn.contains(e.target) && !indicatorPanel.contains(e.target)) {
                        indicatorPanel.classList.add('hidden');
                    }
                });
                // 패널 내부 클릭 시 이벤트 전파 방지 (닫힘 방지)
                indicatorPanel.addEventListener('click', (e) => {
                    e.stopPropagation();
                });
            }
        });

        // ==================== 종목 상세 통합 패널 ====================
        let currentDetailStock = '';
        let detailForumPage = 1;
        let detailSupplyPeriod = 30;
        let detailChartPeriod = 'daily';
        let detailChartManager = null;

        // 종목 상세 통합 조회
        async function loadStockDetail() {
            const code = document.getElementById('detailStockCode').value.trim();
            // ETN/ETF 코드는 알파벳 포함 가능 (예: 0008Z0, 500001)
            if (!code || !/^[0-9A-Z]{6}$/i.test(code)) {
                alert('종목코드 6자리를 입력하세요');
                return;
            }

            currentDetailStock = code;
            detailForumPage = 1;
            document.getElementById('detailStatus').textContent = '조회 중...';

            // 모든 섹션 동시 로드
            await Promise.all([
                loadDetailStockInfo(code),
                loadDetailChart(code),
                loadDetailSupply(code),
                loadDetailProgramTrade(code),
                loadDetailForum(code, 1)
            ]);

            document.getElementById('detailStatus').textContent = '조회 완료';
            addLog(`종목 상세 조회: ${code}`, 'info');
        }

        // 종목 기본 정보 조회
        async function loadDetailStockInfo(code) {
            try {
                const data = await callKiwoom('stockInfo', {stk_cd: code});

                if (data.success && data.data) {
                    const d = data.data;
                    document.getElementById('detailStockName').textContent = d.stk_nm || code;
                    document.getElementById('detailStockPrice').textContent = parseInt(d.cur_prc || 0).toLocaleString() + '원';

                    const change = parseInt(d.pred_pre) || 0;
                    const rate = parseFloat(d.flu_rt) || 0;
                    const sign = change > 0 ? '+' : '';
                    const changeEl = document.getElementById('detailStockChange');
                    changeEl.textContent = `${sign}${change.toLocaleString()} (${sign}${rate.toFixed(2)}%)`;
                    changeEl.style.color = change > 0 ? '#ef4444' : change < 0 ? '#3b82f6' : 'inherit';
                }
            } catch (e) {
                console.error('종목 정보 오류:', e);
            }
        }

        // 상세 페이지 차트 로드 (기존 chartManager 재사용, 드래그 이벤트 재바인딩)
        async function loadDetailChart(code) {
            const container = document.getElementById('detailChartContainer');
            if (!container) return;

            // 컨테이너 비우기 (empty-state 등 제거)
            container.innerHTML = '';

            // 레이아웃이 완료될 때까지 잠시 대기
            await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));

            // 정확한 높이 계산:
            // 그리드: calc(100vh - 180px), 2행, gap 12px
            // 각 셀 높이: (100vh - 180px - 12px) / 2
            // 헤더: ~40px, 차트영역: 셀높이 - 헤더 - border(2px)
            const viewportHeight = window.innerHeight;
            const gridHeight = viewportHeight - 180;  // calc(100vh - 180px)
            const cellHeight = (gridHeight - 12) / 2;  // gap 12px, 2행
            const headerHeight = 40;  // section-header 높이
            const chartHeight = Math.floor(cellHeight - headerHeight - 4);  // border, padding 여유

            console.log('[loadDetailChart] 계산: viewport=', viewportHeight, 'grid=', gridHeight, 'cell=', cellHeight, 'chart=', chartHeight);

            // 차트 컨테이너에 명시적 높이 설정
            container.style.height = chartHeight + 'px';
            container.style.minHeight = chartHeight + 'px';

            // 기존 chartManager 재사용
            await initChartManager();
            if (chartManager) {
                // 차트 컨테이너 변경
                const originalContainer = chartManager.container;
                chartManager.container = container;
                chartManager.containerId = 'detailChartContainer';

                // 기존 드래그 이벤트 제거
                chartManager.removeDragZoomEvents();

                const name = getStockName(code) || document.getElementById('detailStockName').textContent || code;
                await chartManager.loadChart(code, detailChartPeriod, name);

                // 차트 리사이즈 (정확한 크기로)
                if (chartManager.chart) {
                    const rect = container.getBoundingClientRect();
                    console.log('[loadDetailChart] 차트 리사이즈:', rect.width, 'x', chartHeight);
                    chartManager.chart.resize(rect.width, chartHeight);
                }

                // 새 컨테이너에 드래그 이벤트 재바인딩
                chartManager.setupDragZoom();
            }
        }

        // 상세 차트 기간 변경
        function changeDetailChartPeriod(period) {
            detailChartPeriod = period;

            // 버튼 활성화 상태 업데이트
            document.querySelectorAll('#panel-stock-detail .detail-section:first-child .btn[data-period]').forEach(btn => {
                btn.classList.toggle('active', btn.dataset.period === period);
            });

            if (currentDetailStock) {
                loadDetailChart(currentDetailStock);
            }
        }

        // 보조지표 패널 토글
        function toggleDetailIndicatorPanel() {
            const panel = document.getElementById('detailIndicatorPanel');
            panel.classList.toggle('hidden');
        }

        // 이동평균선 토글
        function toggleDetailMA(maKey, enabled) {
            if (chartManager) chartManager.toggleMA(maKey, enabled);
        }

        // 일목균형표 토글
        function toggleDetailIchimoku(enabled) {
            if (chartManager) chartManager.toggleIchimoku(enabled);
        }

        // 볼린저밴드 토글
        function toggleDetailBollinger(enabled) {
            if (chartManager) chartManager.toggleBollinger(enabled);
        }

        // 지표 패널 외부 클릭시 닫기
        document.addEventListener('click', (e) => {
            const panel = document.getElementById('detailIndicatorPanel');
            const btn = document.getElementById('detailIndicatorBtn');
            if (panel && !panel.classList.contains('hidden')) {
                if (!panel.contains(e.target) && !btn.contains(e.target)) {
                    panel.classList.add('hidden');
                }
            }
        });

        // 상세 수급 로드 (investor-summary + investor-chart 사용)
        async function loadDetailSupply(code) {
            console.log('[수급분석] loadDetailSupply 호출, code:', code);
            const host = 'local';
            const token = localStorage.getItem('kiwoom_token');

            // 초기화
            ['detailSupplyIndividual', 'detailSupplyForeign', 'detailSupplyInstitution', 'detailSupplyEtc'].forEach(id => {
                document.getElementById(id).textContent = '-';
            });
            document.getElementById('detailSupplyTableBody').innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-muted);"><i class="fas fa-spinner fa-spin"></i> 로딩...</td></tr>';

            if (!host || !token) return;

            try {
                const today = new Date();
                const startDate = new Date(today.getTime() - detailSupplyPeriod * 24 * 60 * 60 * 1000);
                const formatDate = (d) => d.toISOString().slice(0, 10).replace(/-/g, '');

                console.log('[수급분석] API 호출 - stkCd:', code, 'fromDt:', formatDate(startDate), 'toDt:', formatDate(today));

                // 수급 합계 + 일별 차트 병렬 조회
                const [summaryData, chartData] = await Promise.all([
                    callKiwoom('investorSummary', {
                        stk_cd: code,
                        strt_dt: formatDate(startDate),
                        end_dt: formatDate(today),
                        amt_qty_tp: '1',
                        trde_tp: '0',
                        unit_tp: '1'
                    }),
                    callKiwoom('investorChart', {
                        stk_cd: code,
                        dt: formatDate(today),
                        amt_qty_tp: '1',
                        trde_tp: '0',
                        unit_tp: '1'
                    })
                ]);

                console.log('[수급분석] investorSummary 응답:', summaryData);
                console.log('[수급분석] investorChart 응답:', chartData);

                // 합계 처리
                const summaryArr = summaryData.data?.stk_invsr_orgn_tot || summaryData.stk_invsr_orgn_tot;
                if (summaryArr && summaryArr.length > 0) {
                    const summary = summaryArr[0];
                    const formatValue = (val) => {
                        const cleanVal = String(val || '0').replace(/^--/, '-').replace(/^\+\+/, '+');
                        const num = parseInt(cleanVal) || 0;
                        const absVal = Math.abs(num);
                        const display = (absVal / 100).toFixed(1) + '억';
                        return { num, display: (num >= 0 ? '+' : '-') + display, isPositive: num > 0 };
                    };
                    const parseClean = (v) => parseInt(String(v || '0').replace(/^--/, '-').replace(/^\+\+/, '+')) || 0;
                    const etcSum = parseClean(summary.fnnc_invt) + parseClean(summary.insrnc) +
                                   parseClean(summary.invtrt) + parseClean(summary.etc_fnnc) +
                                   parseClean(summary.bank);
                    const ind = formatValue(summary.ind_invsr);
                    const frn = formatValue(summary.frgnr_invsr);
                    const org = formatValue(summary.orgn);
                    const etc = formatValue(etcSum);

                    document.getElementById('detailSupplyIndividual').innerHTML = `<span style="color:${ind.isPositive ? '#ef4444' : '#3b82f6'}">${ind.display}</span>`;
                    document.getElementById('detailSupplyForeign').innerHTML = `<span style="color:${frn.isPositive ? '#ef4444' : '#3b82f6'}">${frn.display}</span>`;
                    document.getElementById('detailSupplyInstitution').innerHTML = `<span style="color:${org.isPositive ? '#ef4444' : '#3b82f6'}">${org.display}</span>`;
                    document.getElementById('detailSupplyEtc').innerHTML = `<span style="color:${etc.isPositive ? '#ef4444' : '#3b82f6'}">${etc.display}</span>`;
                }

                // 일별 차트 처리
                const chartArr = chartData.data?.stk_invsr_orgn_chart || chartData.stk_invsr_orgn_chart;
                if (chartArr && chartArr.length > 0) {
                    const rows = chartArr.slice(0, detailSupplyPeriod);
                    const parseClean = (v) => parseInt(String(v || '0').replace(/^--/, '-').replace(/^\+\+/, '+')) || 0;
                    const formatDate2 = (dt) => {
                        if (!dt) return '-';
                        return dt.slice(4, 6) + '/' + dt.slice(6, 8);
                    };
                    const formatNum = (val) => {
                        const cleanVal = String(val || '0').replace(/^--/, '-').replace(/^\+\+/, '+');
                        const num = parseInt(cleanVal) || 0;
                        const absVal = Math.abs(num);
                        const display = (absVal / 100).toFixed(1) + '억';
                        return { num, display: (num > 0 ? '+' : '') + (num < 0 ? '-' : '') + display };
                    };
                    const tableRows = rows.map(r => {
                        const ind = formatNum(r.ind_invsr);
                        const frgn = formatNum(r.frgnr_invsr);
                        const inst = formatNum(r.orgn);
                        const priceClean = String(r.cur_prc || '0').replace(/^[+-]+/, '');
                        const curPrc = parseInt(priceClean) || 0;
                        return `<tr>
                            <td style="padding:6px 8px;">${formatDate2(r.dt)}</td>
                            <td style="padding:6px 8px;text-align:right;">${curPrc.toLocaleString()}</td>
                            <td style="padding:6px 8px;text-align:right;color:${ind.num > 0 ? '#ef4444' : ind.num < 0 ? '#3b82f6' : 'inherit'}">${ind.display}</td>
                            <td style="padding:6px 8px;text-align:right;color:${frgn.num > 0 ? '#ef4444' : frgn.num < 0 ? '#3b82f6' : 'inherit'}">${frgn.display}</td>
                            <td style="padding:6px 8px;text-align:right;color:${inst.num > 0 ? '#ef4444' : inst.num < 0 ? '#3b82f6' : 'inherit'}">${inst.display}</td>
                        </tr>`;
                    }).join('');
                    document.getElementById('detailSupplyTableBody').innerHTML = tableRows;
                } else {
                    document.getElementById('detailSupplyTableBody').innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-muted);">데이터 없음</td></tr>';
                }
            } catch (e) {
                console.error('수급 로드 오류:', e);
                document.getElementById('detailSupplyTableBody').innerHTML = `<tr><td colspan="5" style="text-align:center;color:var(--danger);">오류: ${escapeHtml(e.message)}</td></tr>`;
            }
        }

        // 수급 기간 변경
        function changeDetailSupplyPeriod(days) {
            detailSupplyPeriod = days;

            // 버튼 활성화 업데이트
            document.querySelectorAll('#panel-stock-detail .detail-section:nth-child(2) .section-header .btn').forEach(btn => {
                const btnDays = btn.textContent === '1주' ? 7 : btn.textContent === '1개월' ? 30 : 90;
                btn.classList.toggle('active', btnDays === days);
            });

            if (currentDetailStock) {
                loadDetailSupply(currentDetailStock);
            }
        }

        // 프로그램매매 로드
        async function loadDetailProgramTrade(code) {
            document.getElementById('detailPtBuy').textContent = '-';
            document.getElementById('detailPtSell').textContent = '-';
            document.getElementById('detailPtNet').textContent = '-';
            document.getElementById('detailProgramTradeInfo').innerHTML = '<i class="fas fa-spinner fa-spin"></i> 조회 중...';

            try {
                const today = new Date();
                const formatDate = (d) => d.toISOString().slice(0, 10).replace(/-/g, '');

                const result = await callKiwoom('programTrade', {
                    stk_cd: code,
                    amt_qty_tp: '1',  // 금액 기준
                    date: formatDate(today)
                });

                const rows = result.data?.stk_daly_prm_trde_trnsn || result.stk_daly_prm_trde_trnsn;
                if (rows && rows.length > 0) {
                    // 최신 데이터 (첫번째 행)
                    const latest = rows[0];

                    // --2704120 같은 이중 부호 처리 헬퍼
                    const cleanInt = (v) => parseInt(String(v || '0').replace(/^--/, '-').replace(/^\+\+/, '+')) || 0;

                    const formatPTAmt = (val) => {
                        const num = Math.abs(cleanInt(val));
                        if (num >= 100000000) return (num / 100000000).toFixed(1) + '억';
                        if (num >= 10000) return (num / 10000).toFixed(0) + '만';
                        return num.toLocaleString();
                    };

                    const buyAmt = cleanInt(latest.prm_buy_amt);
                    const sellAmt = cleanInt(latest.prm_sell_amt);
                    const netAmt = cleanInt(latest.prm_netprps_amt);

                    document.getElementById('detailPtBuy').textContent = formatPTAmt(Math.abs(buyAmt));
                    document.getElementById('detailPtSell').textContent = formatPTAmt(Math.abs(sellAmt));

                    const netEl = document.getElementById('detailPtNet');
                    netEl.textContent = (netAmt >= 0 ? '+' : '') + formatPTAmt(Math.abs(netAmt));
                    netEl.style.color = netAmt > 0 ? '#ef4444' : netAmt < 0 ? '#3b82f6' : 'inherit';

                    // 일별 테이블 표시 (최근 5일)
                    const tableRows = rows.slice(0, 5).map(r => {
                        const dt = r.dt || '';
                        const dateStr = dt.length >= 8 ? dt.slice(4,6) + '/' + dt.slice(6,8) : '-';
                        const buy = cleanInt(r.prm_buy_amt);
                        const sell = cleanInt(r.prm_sell_amt);
                        const net = cleanInt(r.prm_netprps_amt);
                        return `<div style="display:grid;grid-template-columns:50px 1fr 1fr 1fr;gap:4px;padding:3px 0;font-size:11px;border-bottom:1px solid var(--border);">
                            <span style="color:var(--text-muted);">${dateStr}</span>
                            <span style="text-align:right;color:#ef4444;">${formatPTAmt(Math.abs(buy))}</span>
                            <span style="text-align:right;color:#3b82f6;">${formatPTAmt(Math.abs(sell))}</span>
                            <span style="text-align:right;color:${net > 0 ? '#ef4444' : net < 0 ? '#3b82f6' : 'inherit'}">${(net >= 0 ? '+' : '') + formatPTAmt(Math.abs(net))}</span>
                        </div>`;
                    }).join('');

                    document.getElementById('detailProgramTradeInfo').innerHTML = `
                        <div style="display:grid;grid-template-columns:50px 1fr 1fr 1fr;gap:4px;padding:3px 0;font-size:10px;color:var(--text-muted);border-bottom:1px solid var(--border);">
                            <span>일자</span><span style="text-align:right;">매수</span><span style="text-align:right;">매도</span><span style="text-align:right;">순매수</span>
                        </div>
                        ${tableRows}
                    `;
                } else {
                    document.getElementById('detailProgramTradeInfo').textContent = '데이터 없음';
                }
            } catch (e) {
                console.error('프로그램매매 오류:', e);
                document.getElementById('detailProgramTradeInfo').textContent = '조회 실패: ' + e.message;
            }
        }

        // 프로그램매매 새로고침
        function refreshDetailProgramTrade() {
            if (currentDetailStock) {
                loadDetailProgramTrade(currentDetailStock);
            }
        }

        // 종토방 로드
        async function loadDetailForum(code, page = 1) {
            if (!code) return;
            if (page < 1) page = 1;

            detailForumPage = page;
            document.getElementById('detailForumPageInfo').textContent = page;

            const tbody = document.getElementById('detailForumTableBody');
            tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:var(--text-muted);"><i class="fas fa-spinner fa-spin"></i> 로딩...</td></tr>';

            try {
                const result = await kiwoomAPI.stockForum(code, page);

                const posts = result.posts || result.data?.posts || [];
                if (posts.length > 0) {
                    const rows = posts.map(item => {
                        // 네이버 API 필드명: date, readCount, discussionId
                        const dateStr = item.date || item.dateTime || '';
                        const date = dateStr ? dateStr.slice(5, 10).replace('-', '/') : '-';
                        const views = Number(item.readCount || item.viewCount || item.views || 0);
                        const postId = item.discussionId || item.nttId || '';
                        return `
                        <tr style="cursor:pointer;" onclick="window.open('https://m.stock.naver.com/domestic/stock/${code}/discuss/${postId}', '_blank')">
                            <td style="padding:6px 8px;font-size:11px;color:var(--text-muted);">${date}</td>
                            <td style="padding:6px 8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px;" title="${escapeHtml(item.title || '')}">${escapeHtml(item.title) || '-'}</td>
                            <td style="padding:6px 8px;text-align:center;font-size:11px;">${views.toLocaleString()}</td>
                        </tr>
                    `}).join('');
                    tbody.innerHTML = rows;
                } else {
                    tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:var(--text-muted);">게시글 없음</td></tr>';
                }

                // 페이지네이션 업데이트
                document.getElementById('detailForumPrevBtn').disabled = page <= 1;
            } catch (e) {
                tbody.innerHTML = `<tr><td colspan="3" style="text-align:center;color:var(--danger);">오류: ${escapeHtml(e.message)}</td></tr>`;
            }
        }

        // 다른 화면에서 종목 상세 페이지로 이동
        function openStockDetailTab(code, name) {
            // 종목코드 정리: _AL, _NX 등 마켓 접미사만 제거 (ETN/ETF는 알파벳 포함 가능)
            const cleanCode = (code || '').replace(/_[A-Z]+$/, '').trim();
            if (!cleanCode || cleanCode.length !== 6) {
                console.warn('[openStockDetailTab] 유효하지 않은 종목코드:', code, '-> cleaned:', cleanCode);
                return;
            }

            // 종목 상세 탭으로 전환
            document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
            document.querySelector('.menu-item[data-panel="stock-detail"]').classList.add('active');
            document.querySelectorAll('.content-panel').forEach(p => p.classList.remove('active'));
            document.getElementById('panel-stock-detail').classList.add('active');

            // 종목코드 입력 및 조회
            document.getElementById('detailStockCode').value = cleanCode;
            if (name) {
                document.getElementById('detailStockName').textContent = name;
            }
            loadStockDetail();
        }

        // ==================== 종목 수급 분석 탭 ====================
        let stockSupplyState = {
            code: '',
            name: '',
            price: 0,
            change: 0,
            changeRate: 0,
            chartData: [],
            summaryData: null,
            currentPeriod: 30  // 기본 30일
        };

        // 종목 수급 조회 (탭에서 직접 입력)
        async function loadStockSupply() {
            const codeInput = document.getElementById('supplyStockCode');
            const code = codeInput.value.trim();

            if (!code) {
                alert('종목코드를 입력하세요');
                return;
            }

            stockSupplyState.code = code;
            addLog(`종목 수급 조회: ${code}`, 'info');

            // 종목 정보 로드
            await loadStockSupplyData(code);
        }

        // 실시간 순위에서 종목 클릭 시 탭으로 이동
        function openStockSupplyTab(code, name) {
            // 종목 수급 탭으로 전환
            document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
            document.querySelector('.menu-item[data-panel="stock-supply"]').classList.add('active');
            document.querySelectorAll('.content-panel').forEach(p => p.classList.remove('active'));
            document.getElementById('panel-stock-supply').classList.add('active');

            // 종목코드 입력
            document.getElementById('supplyStockCode').value = code;
            stockSupplyState.code = code;
            stockSupplyState.name = name || code;

            addLog(`종목 수급 탭 이동: ${name} (${code})`, 'info');

            // 데이터 로드
            loadStockSupplyData(code);
        }

        // 기간 변경
        async function changeSupplyPeriod(days) {
            stockSupplyState.currentPeriod = days;

            // 버튼 활성화
            document.querySelectorAll('#panel-stock-supply .period-btn').forEach(btn => {
                btn.classList.toggle('active', parseInt(btn.dataset.days) === days);
            });

            // 데이터 재로드
            if (stockSupplyState.code) {
                await loadStockSupplyData(stockSupplyState.code);
            }
        }

        // 종목 수급 데이터 로드
        async function loadStockSupplyData(code) {
            const host = 'local';
            const token = localStorage.getItem('kiwoom_token');

            if (!host || !token) {
                addLog('로그인 필요', 'error');
                document.getElementById('supplyStockInfo').innerHTML = '<span style="color:var(--danger);">로그인이 필요합니다</span>';
                return;
            }

            // 로딩 표시
            document.getElementById('supplyStockInfo').innerHTML = '<i class="fas fa-spinner fa-spin"></i> 조회 중...';

            try {
                // 1. 기본 정보 조회 (ka10001)
                const infoData = await callKiwoom('stockInfo', {stk_cd: code});

                if (infoData.success && infoData.data) {
                    const d = infoData.data;
                    stockSupplyState.price = Math.abs(parseInt(d.cur_prc)) || 0;
                    stockSupplyState.change = parseInt(d.pred_pre) || 0;
                    stockSupplyState.changeRate = parseFloat(d.flu_rt) || 0;
                    stockSupplyState.name = d.stk_nm || code;

                    // 상단 정보 업데이트
                    const isUp = stockSupplyState.change > 0;
                    const isDown = stockSupplyState.change < 0;
                    const sign = isUp ? '+' : '';
                    const priceClass = isUp ? 'price-up' : isDown ? 'price-down' : '';

                    document.getElementById('supplyStockInfo').innerHTML = `
                        <strong>${stockSupplyState.name}</strong>
                        <span class="${priceClass}" style="margin-left: 12px; font-weight: 700;">${stockSupplyState.price.toLocaleString()}원</span>
                        <span class="${priceClass}" style="margin-left: 8px;">${sign}${stockSupplyState.change.toLocaleString()} (${sign}${stockSupplyState.changeRate.toFixed(2)}%)</span>
                    `;
                }

                // 2. 수급 데이터 로드
                await loadSupplyTabData(code, stockSupplyState.currentPeriod);

            } catch (e) {
                console.error('종목 수급 로드 오류:', e);
                addLog(`종목 수급 로드 오류: ${e.message}`, 'error');
                document.getElementById('supplyStockInfo').innerHTML = `<span style="color:var(--danger);">오류: ${escapeHtml(e.message)}</span>`;
            }
        }

        // 수급 탭 데이터 로드 (ka10060, ka10061)
        async function loadSupplyTabData(code, days) {
            const host = 'local';
            const token = localStorage.getItem('kiwoom_token');

            // 로딩 표시
            document.getElementById('supplyTableData').innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);"><i class="fas fa-spinner fa-spin"></i> 로딩 중...</td></tr>';

            try {
                // 기간 계산
                const today = new Date();
                const startDate = new Date(today.getTime() - days * 24 * 60 * 60 * 1000);
                const formatDate = (d) => d.toISOString().slice(0, 10).replace(/-/g, '');

                // 수급 합계 + 일별 차트 병렬 조회
                const [summaryData, chartData] = await Promise.all([
                    callKiwoom('investorSummary', {
                        stk_cd: code + '_AL',
                        strt_dt: formatDate(startDate),
                        end_dt: formatDate(today),
                        amt_qty_tp: '1',
                        trde_tp: '0',
                        unit_tp: '1000'
                    }),
                    callKiwoom('investorChart', {
                        stk_cd: code + '_AL',
                        dt: formatDate(today),
                        amt_qty_tp: '1',
                        trde_tp: '0',
                        unit_tp: '1000'
                    })
                ]);

                if (summaryData.success && summaryData.data) {
                    const rawTot = summaryData.data.stk_invsr_orgn_tot;
                    stockSupplyState.summaryData = Array.isArray(rawTot) ? rawTot[0] : summaryData.data;
                    renderSupplyTabSummary(stockSupplyState.summaryData);
                }

                if (chartData.success && chartData.data) {
                    const rawChart = chartData.data.stk_invsr_orgn_chart;
                    stockSupplyState.chartData = Array.isArray(rawChart) ? rawChart : [];
                    renderSupplyTabTable(stockSupplyState.chartData.slice(0, days));
                } else {
                    document.getElementById('supplyTableData').innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);">데이터 없음</td></tr>';
                }

            } catch (e) {
                console.error('수급 데이터 로드 오류:', e);
                addLog(`수급 데이터 로드 오류: ${e.message}`, 'error');
                document.getElementById('supplyTableData').innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);">오류 발생</td></tr>';
            }
        }

        // 수급 요약 렌더링
        function renderSupplyTabSummary(data) {
            if (!data) return;

            // API는 백만원 단위로 반환 (금액 기준 amt_qty_tp='1', unit_tp='1000')
            const formatValue = (val) => {
                const cleanVal = String(val || '0').replace(/^--/, '-').replace(/^\+\+/, '+');
                const num = parseInt(cleanVal) || 0;
                const absVal = Math.abs(num);
                // 백만원 단위 → 억 단위 (100으로 나눔), 반올림 + 콤마
                const billions = Math.round(absVal / 100);
                const display = billions.toLocaleString() + '억';
                return { num, display: (num >= 0 ? '+' : '-') + display, isPositive: num > 0 };
            };
            console.log('[수급탭] 합계 원본값:', { ind: data.ind_invsr, frn: data.frgnr_invsr, org: data.orgn });

            const ind = formatValue(data.ind_invsr);
            const frn = formatValue(data.frgnr_invsr);
            const org = formatValue(data.orgn);
            // 기타 합계 (금융투자 + 보험 + 투신 + 기타금융 + 은행 등)
            const parseClean = (v) => parseInt(String(v || '0').replace(/^--/, '-').replace(/^\+\+/, '+')) || 0;
            const etcSum = parseClean(data.fnnc_invt) + parseClean(data.insrnc) +
                           parseClean(data.invtrt) + parseClean(data.etc_fnnc) +
                           parseClean(data.bank);
            const etc = formatValue(etcSum);

            document.getElementById('supplyIndividual').innerHTML = `<span class="supply-card-value ${ind.isPositive ? 'positive' : 'negative'}">${ind.display}</span>`;
            document.getElementById('supplyForeign').innerHTML = `<span class="supply-card-value ${frn.isPositive ? 'positive' : 'negative'}">${frn.display}</span>`;
            document.getElementById('supplyInstitution').innerHTML = `<span class="supply-card-value ${org.isPositive ? 'positive' : 'negative'}">${org.display}</span>`;
            document.getElementById('supplyEtc').innerHTML = `<span class="supply-card-value ${etc.isPositive ? 'positive' : 'negative'}">${etc.display}</span>`;
        }

        // 수급 테이블 렌더링
        function renderSupplyTabTable(data) {
            const tbody = document.getElementById('supplyTableData');
            if (!data || data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);">데이터 없음</td></tr>';
                return;
            }

            console.log('[수급탭] 테이블 첫번째 행 원본:', data[0]);
            // API는 백만원 단위로 반환 (금액 기준 amt_qty_tp='1', unit_tp='1000')
            const formatNum = (val) => {
                const cleanVal = String(val || '0').replace(/^--/, '-').replace(/^\+\+/, '+');
                const num = parseInt(cleanVal) || 0;
                const absVal = Math.abs(num);
                // 백만원 단위 → 억 단위 (100으로 나눔), 반올림 + 콤마
                const billions = Math.round(absVal / 100);
                const display = billions.toLocaleString() + '억';
                return { num, display: (num > 0 ? '+' : '') + (num < 0 ? '-' : '') + display };
            };

            const formatDate = (dt) => {
                if (!dt) return '-';
                // YYYYMMDD → MM/DD
                return dt.slice(4, 6) + '/' + dt.slice(6, 8);
            };

            tbody.innerHTML = data.map(d => {
                const ind = formatNum(d.ind_invsr);
                const frn = formatNum(d.frgnr_invsr);
                const org = formatNum(d.orgn);
                const fnnc = formatNum(d.fnnc_invt);
                const insrnc = formatNum(d.insrnc);
                const invtrt = formatNum(d.invtrt);
                const priceClean = String(d.cur_prc || '0').replace(/^[+-]+/, '');
                const price = parseInt(priceClean) || 0;

                return `
                    <tr>
                        <td>${formatDate(d.dt)}</td>
                        <td>${price.toLocaleString()}</td>
                        <td class="${ind.num > 0 ? 'price-up' : ind.num < 0 ? 'price-down' : ''}">${ind.display}</td>
                        <td class="${frn.num > 0 ? 'price-up' : frn.num < 0 ? 'price-down' : ''}">${frn.display}</td>
                        <td class="${org.num > 0 ? 'price-up' : org.num < 0 ? 'price-down' : ''}">${org.display}</td>
                        <td class="${fnnc.num > 0 ? 'price-up' : fnnc.num < 0 ? 'price-down' : ''}">${fnnc.display}</td>
                        <td class="${insrnc.num > 0 ? 'price-up' : insrnc.num < 0 ? 'price-down' : ''}">${insrnc.display}</td>
                        <td class="${invtrt.num > 0 ? 'price-up' : invtrt.num < 0 ? 'price-down' : ''}">${invtrt.display}</td>
                    </tr>
                `;
            }).join('');
        }

        // ==================== API Keys 관리 ====================
        const API_KEY_FIELDS = [
            'KIWOOM_APP_KEY', 'KIWOOM_SECRET_KEY', 'KIWOOM_ACCOUNT',
            'KIS_APP_KEY', 'KIS_APP_SECRET',
            'DART_API_KEY', 'ECOS_API_KEY', 'EXIM_API_KEY',
            'NAVER_CLIENT_ID', 'NAVER_CLIENT_SECRET',
            'TELEGRAM_API_ID', 'TELEGRAM_API_HASH', 'TELEGRAM_PHONE',
            'MEMBERSHIP_API_KEY'
        ];

        async function loadApiKeys() {
            try {
                const data = await loadSettings();
                const keys = data.keys || data;
                API_KEY_FIELDS.forEach(field => {
                    const el = document.getElementById('key-' + field);
                    if (el && keys[field]) el.value = keys[field];
                });
                console.log('[API Keys] 키 로딩 완료');
            } catch (e) {
                console.error('[API Keys] 로딩 실패:', e);
            }
        }

        async function saveApiKeys() {
            const keys = {};
            API_KEY_FIELDS.forEach(field => {
                const el = document.getElementById('key-' + field);
                if (el && el.value.trim()) keys[field] = el.value.trim();
            });
            try {
                await saveSettings(keys);
                alert('API 키가 저장되었습니다. 서버를 재시작하면 적용됩니다.');
            } catch (e) {
                alert('저장 실패: ' + e.message);
            }
        }

        async function refreshApiStatus() {
            try {
                const data = await getApiStatus();
                const modules = data.modules || {};
                const statusMap = {
                    'datakit': 'status-datakit',
                    'kiwoom': 'status-kiwoom',
                    'kis': 'status-kis',
                    'news': 'status-news',
                    'telegram': 'status-telegram',
                    'membership': 'status-membership'
                };
                Object.entries(statusMap).forEach(([mod, elId]) => {
                    const el = document.getElementById(elId);
                    if (!el) return;
                    const info = modules[mod];
                    if (info && info.ok) {
                        el.textContent = '✅ 활성';
                        el.style.color = 'var(--success)';
                    } else {
                        el.textContent = '⬚ 비활성';
                        el.style.color = 'var(--text-muted)';
                    }
                });
            } catch (e) {
                console.error('[Status] 조회 실패:', e);
            }
        }

        // ==================== 사이드바 토글 ====================
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('collapsed');
            const isCollapsed = sidebar.classList.contains('collapsed');
            localStorage.setItem('sidebar_collapsed', isCollapsed ? '1' : '0');
        }

        // 페이지 로드 시 사이드바 상태 복원
        (function restoreSidebarState() {
            if (localStorage.getItem('sidebar_collapsed') === '1') {
                const sidebar = document.querySelector('.sidebar');
                if (sidebar) sidebar.classList.add('collapsed');
            }
        })();
