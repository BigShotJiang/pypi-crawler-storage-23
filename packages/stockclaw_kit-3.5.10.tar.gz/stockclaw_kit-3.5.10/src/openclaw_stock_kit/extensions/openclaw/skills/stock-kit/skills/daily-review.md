# 하루 정리 — 장마감 후 리뷰

장마감 후 오늘 시장을 종합 정리한다. 상한가/급등주 이유, 주도 테마, 테마 흐름 변화를 포함.

## 트리거

- "오늘 하루 정리해줘"
- "오늘 장 어땠어?"
- "장마감 정리"
- "오늘 상한가 종목"
- "오늘 테마 정리"

## 실행 흐름

| 단계 | API 호출 | 목적 |
|------|---------|------|
| 1 | ka-006 | 일일 종합 요약 (테마별/종목별) |
| 2 | ka-004 (topic=surge_stocks) | 상한가/급등주와 사유 |
| 3 | ka-004 (topic=theme_ranking) | 테마별 등락률 순위 |
| 4 | ka-008 (hours=8) | 종일 테마 흐름 변화 |
| 5 | LLM 종합 | 하루 전체 리포트 생성 |

## CLI 예시

```bash
# 일일 종합
stockclaw-kit run membership_call '{"api_id":"ka-006"}' 2>/dev/null

# 상한가/급등주
stockclaw-kit run membership_call '{"api_id":"ka-004","params":{"topic":"surge_stocks"}}' 2>/dev/null

# 테마 등락률
stockclaw-kit run membership_call '{"api_id":"ka-004","params":{"topic":"theme_ranking"}}' 2>/dev/null

# 테마 타임라인 (종일)
stockclaw-kit run membership_call '{"api_id":"ka-008","params":{"hours":8,"top":5}}' 2>/dev/null
```

## 응답 형식

1. 시장 개요 (코스피/코스닥 등락)
2. 상한가/급등주 TOP5 + 각 종목 사유
3. 오늘의 주도 테마 순위
4. 테마 흐름: 오전에 뜨고 오후에 꺼진 테마 vs 종일 강한 테마
5. 내일 주목 포인트 (있으면)

## 주의사항

- 16시 이후 데이터 확정 (ka-006은 16시 이후 생성)
- ka-004 오후장 분석은 장마감 후 1회 생성
- 과거 날짜 리뷰는 date 파라미터 지정
