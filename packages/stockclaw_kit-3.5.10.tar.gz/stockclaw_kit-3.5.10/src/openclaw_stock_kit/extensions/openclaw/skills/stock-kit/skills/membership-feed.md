# 멤버십 데이터 피드 (membership-feed)

readinginvestor.com의 데이터 피드 API를 통해 종목-뉴스 매칭, 오전장/오후장 AI분석, 시간별 요약, 테마 점수, 급등 감지 등을 조회한다.

## 기본 호출 형식

```bash
stockclaw-kit run <tool_name> '<JSON>' 2>/dev/null
```

환경 및 API 키 상태 확인:
```bash
stockclaw-kit run membership_get_env_info '{}' 2>/dev/null
```

---

## 도구 1: membership_call — 데이터 피드 API 범용 호출

8개 데이터 피드 API를 `api_id`로 분기하여 호출한다.

### 파라미터

| 파라미터 | 타입 | 필수 | 설명 |
|----------|------|------|------|
| `api_id` | string | 필수 | API ID (ka-002 ~ ka-009) |
| `params` | dict | 선택 | API별 파라미터 객체 (기본: {}) |

### API별 파라미터

| API ID | 기능 | 필수 파라미터 | 선택 파라미터 |
|--------|------|-------------|-------------|
| ka-002 | 종목-뉴스 매칭 | — | stock, theme, since, limit, page, match_type |
| ka-003 | 오전장 브리핑 | — | date, topic |
| ka-004 | 오후장 분석 | — | date, topic, stock_code, days |
| ka-005 | 장중 시간별 요약 | — | date, hour |
| ka-006 | 일일 종합 요약 | — | date, type |
| ka-007 | 테마 실시간 점수 | — | theme, top |
| ka-008 | 테마 타임라인 | — | theme, hours, top, interval |
| ka-009 | 거래대금 급등 감지 | — | stock_code, limit |

### CLI 예시

```bash
# AI 일일 요약 (오늘)
stockclaw-kit run membership_call '{"api_id":"ka-006"}' 2>/dev/null

# 종목-뉴스 매칭 (삼성전자)
stockclaw-kit run membership_call '{"api_id":"ka-002","params":{"stock":"005930","limit":10}}' 2>/dev/null

# 오전장 브리핑 (장전 뉴스 AI분석)
stockclaw-kit run membership_call '{"api_id":"ka-003","params":{"topic":"pre_market_news"}}' 2>/dev/null

# 오후장 분석 (현대차 과거 상승 이유 60거래일 검색)
stockclaw-kit run membership_call '{"api_id":"ka-004","params":{"stock_code":"005380","topic":"stock_reasons","days":60}}' 2>/dev/null

# 장중 시간별 요약 (10시~11시)
stockclaw-kit run membership_call '{"api_id":"ka-005","params":{"hour":10}}' 2>/dev/null

# 테마 실시간 점수 (TOP 5)
stockclaw-kit run membership_call '{"api_id":"ka-007","params":{"top":5}}' 2>/dev/null

# 테마 타임라인 (반도체, 최근 6시간)
stockclaw-kit run membership_call '{"api_id":"ka-008","params":{"theme":"반도체","hours":6}}' 2>/dev/null

# 거래대금 급등 감지
stockclaw-kit run membership_call '{"api_id":"ka-009","params":{"limit":20}}' 2>/dev/null
```

---

## 인증 설정

| 환경변수 | 설명 |
|----------|------|
| `MEMBERSHIP_API_KEY` | readinginvestor.com 데이터 피드 API 키 |

키 형식: `tt_live_` + 64자 hex (총 72자)
발급: https://readinginvestor.com → 프로필 → 내정보 → API 키 탭
Rate Limit: 분당 120회

---

## 사용 시나리오

| 질문 유형 | 권장 API | topic/파라미터 |
|----------|---------|--------------|
| "오늘 시장 요약해줘" | ka-006 | — |
| "삼성전자 관련 뉴스" | ka-002 | stock=005930 |
| "미국장 어땠어?" | ka-003 | topic=ny_market |
| "오늘 주도주가 뭐야?" | ka-003 | topic=leading_stocks |
| "장전에 무슨 뉴스?" | ka-003 | topic=pre_market_news |
| "현대차 왜 올라?" | ka-004 | stock_code=005380, topic=stock_reasons |
| "10시에 뭐 있었어?" | ka-005 | hour=10 |
| "지금 핫한 테마?" | ka-007 | top=5 |
| "반도체 테마 추이" | ka-008 | theme=반도체 |
| "급등주 뭐 있어?" | ka-009 | — |

### ka-003 topic 값

| topic 값 | 내용 | 기존 매핑 |
|----------|------|----------|
| pre_market_news | 장전 뉴스 AI 분석 | 기존 ka-009 |
| ny_market | 뉴욕증시 요약 | 기존 ka-007 |
| leading_stocks | 전일 주도주 | 기존 ka-008 |
| after_hours | 시간외 상승 종목 | 기존 ka-007 일부 |
| watch_points | AI 핵심 관전 포인트 | 신규 |
| full | 전체 통합 분석 | 기본값 |

### ka-004 topic 값

| topic 값 | 내용 |
|----------|------|
| surge_stocks | 상한가/급등주와 사유 |
| theme_ranking | 테마별 등락률 순위 |
| leading_analysis | 주도주 분석 |
| stock_reasons | 개별 종목 상승/하락 이유 |
| awake | 이상 거래 감지 |
| full | 전체 리포트 (기본값) |

### news_search_stock과의 차이

| 비교 | membership_call (ka-002) | news_search_stock |
|------|----------------------|------------------|
| 데이터 소스 | AI 매칭 + 다중 소스 통합 | 네이버 뉴스 API |
| 분석 수준 | AI 감성분석, 테마 분류 포함 | 원본 뉴스 제공 |
| API 키 | MEMBERSHIP_API_KEY | NAVER_CLIENT_ID |

---

## DB 자동 저장

| API | 정규화 테이블 | 용도 |
|-----|-------------|------|
| ka-002 | `membership_stock_events` | 종목별 뉴스 매칭 시계열 |
| ka-003~009 | `membership_daily_summary` | 요약/분석 계열 (일자별 UPSERT) |
| 전체 | `hub_api_responses` | 통합 로그 (JSON) |
