"""StockClaw Kit — 로컬 SQLite DB (hub_api_responses + 정규화 테이블)

PostgreSQL 의존성 없이 로컬 파일 기반 SQLite를 사용.
STOCKCLAW_DB 환경변수로 DB 경로 변경 가능 (기본: ~/.openclaw/data/stockclaw_local.db).
"""
import sqlite3
import json
import hashlib
import os
import threading
from pathlib import Path
from datetime import datetime, timezone, timedelta

_KST = timezone(timedelta(hours=9))
_DB_PATH = Path(os.getenv(
    "STOCKCLAW_DB",
    str(Path.home() / ".openclaw" / "data" / "stockclaw_local.db")
))
_local = threading.local()  # 스레드별 연결


def get_conn() -> sqlite3.Connection:
    """스레드별 SQLite 연결 반환 (WAL 모드)"""
    conn = getattr(_local, "conn", None)
    if conn is not None:
        return conn
    _DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(_DB_PATH), timeout=5)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    _local.conn = conn
    _ensure_tables(conn)
    return conn


def _ensure_tables(conn: sqlite3.Connection):
    """테이블 없으면 생성"""
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS hub_api_responses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tool_name TEXT NOT NULL,
            params_hash TEXT,
            params TEXT,
            response TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS idx_har_tool ON hub_api_responses(tool_name);
        CREATE INDEX IF NOT EXISTS idx_har_created ON hub_api_responses(created_at DESC);

        CREATE TABLE IF NOT EXISTS kiwoom_prices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticker TEXT, env TEXT, price_data TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS kiwoom_charts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticker TEXT, period TEXT, bar_count INTEGER, env TEXT, chart_data TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS kiwoom_orderbooks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticker TEXT, env TEXT, orderbook TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS kiwoom_balances (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            env TEXT, balance_data TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS kiwoom_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticker TEXT, side TEXT, qty INTEGER, price INTEGER, env TEXT, order_data TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS shared_ohlcv (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT, ticker TEXT, date TEXT,
            open REAL, high REAL, low REAL, close REAL, volume REAL, market_cap REAL,
            UNIQUE(source, ticker, date)
        );
        CREATE TABLE IF NOT EXISTS shared_supply (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT, ticker TEXT, date TEXT,
            inst_buy REAL, foreign_buy REAL, individual_buy REAL,
            UNIQUE(source, ticker, date)
        );
        CREATE TABLE IF NOT EXISTS shared_dart_disclosures (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            rcpNo TEXT UNIQUE,
            corpCode TEXT, corpName TEXT, reportNm TEXT, rcptDt TEXT, flrNm TEXT, rmk TEXT
        );
        CREATE TABLE IF NOT EXISTS shared_macro (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT, indicator TEXT, date TEXT, value TEXT, unit TEXT,
            UNIQUE(source, indicator, date)
        );
        CREATE TABLE IF NOT EXISTS membership_stock_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            api_id TEXT, stock_code TEXT, event_date TEXT, event_type TEXT,
            title TEXT, summary TEXT, score REAL,
            created_at TEXT DEFAULT (datetime('now')),
            UNIQUE(api_id, stock_code, event_date, event_type)
        );
        CREATE TABLE IF NOT EXISTS membership_daily_summary (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            api_id TEXT, report_date TEXT, summary_text TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            UNIQUE(api_id, report_date)
        );
    """)


def save_hub(tool_name: str, params: dict, response: dict):
    """hub_api_responses에 API 호출 로그 저장"""
    try:
        conn = get_conn()
        p_json = json.dumps(params, ensure_ascii=False, default=str)
        p_hash = hashlib.md5(p_json.encode()).hexdigest()
        r_json = json.dumps(response, ensure_ascii=False, default=str)
        conn.execute(
            "INSERT INTO hub_api_responses (tool_name, params_hash, params, response) VALUES (?, ?, ?, ?)",
            (tool_name, p_hash, p_json, r_json),
        )
        conn.commit()
    except Exception as e:
        print(f"[DB] hub save failed ({tool_name}): {e}")
