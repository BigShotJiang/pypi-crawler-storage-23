"""OpenClaw Stock Kit — 통합 설치 모듈

stockclaw-kit setup                → 전체 설치 (Claude Code + OpenClaw + Antigravity)
stockclaw-kit setup claude-code    → Claude Code 플러그인만
stockclaw-kit setup openclaw       → OpenClaw 스킬만
stockclaw-kit setup antigravity    → Google Antigravity만
"""

import io
import json
import os
import shutil
import socket
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

# Windows cp949 대응: stdout을 UTF-8로 강제
if sys.stdout.encoding and sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
if sys.stderr.encoding and sys.stderr.encoding.lower() not in ("utf-8", "utf8"):
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# 번들 데이터 경로 (패키지 내부)
_EXTENSIONS_DIR = Path(__file__).parent / "extensions"


def _print(msg: str):
    print(f"  {msg}")


def _print_ok(msg: str):
    print(f"  [OK] {msg}")


def _print_skip(msg: str):
    print(f"  [SKIP] {msg}")


def _print_err(msg: str):
    print(f"  [ERROR] {msg}", file=sys.stderr)


def _copytree(src: Path, dst: Path):
    """src 디렉토리를 dst로 병합 복사 (기존 파일 덮어쓰기, 삭제 안 함)"""
    shutil.copytree(src, dst, dirs_exist_ok=True)


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")


# ─── Claude Code 플러그인 설치 ───


def setup_claude_code() -> bool:
    """Claude Code 플러그인 설치

    1. ~/.claude/plugins/marketplaces/stock-kit/ 에 플러그인 파일 복사
    2. installed_plugins.json 에 항목 추가
    3. known_marketplaces.json 에 항목 추가
    """
    print("\n--- Claude Code Plugin ---")

    src = _EXTENSIONS_DIR / "claude-code"
    if not src.exists():
        _print_err(f"번들 데이터 없음: {src}")
        return False

    # 플러그인 설치 경로
    claude_dir = Path.home() / ".claude"
    plugins_dir = claude_dir / "plugins"
    install_dir = plugins_dir / "marketplaces" / "stock-kit"

    # 1) 디렉토리 생성
    install_dir.mkdir(parents=True, exist_ok=True)

    # 2) 플러그인 파일 복사
    for item in src.iterdir():
        dst_item = install_dir / item.name
        if item.is_dir():
            _copytree(item, dst_item)
        else:
            shutil.copy2(item, dst_item)
    _print_ok(f"플러그인 파일 복사 → {install_dir}")

    # 3) plugin.json에서 버전 읽기
    plugin_json_path = install_dir / ".claude-plugin" / "plugin.json"
    version = "0.1.0"
    if plugin_json_path.exists():
        try:
            with open(plugin_json_path, encoding="utf-8") as f:
                pdata = json.load(f)
            version = pdata.get("version", version)
        except Exception:
            pass

    # 4) installed_plugins.json 업데이트
    installed_path = plugins_dir / "installed_plugins.json"
    installed = {"version": 2, "plugins": {}}
    if installed_path.exists():
        try:
            with open(installed_path, encoding="utf-8") as f:
                installed = json.load(f)
        except Exception:
            pass

    now = _now_iso()
    plugin_key = "stock-kit@stock-kit"
    # 기존 항목이 있으면 업데이트, 없으면 추가
    installed.setdefault("plugins", {})[plugin_key] = [
        {
            "scope": "user",
            "installPath": str(install_dir),
            "version": version,
            "installedAt": now,
            "lastUpdated": now,
        }
    ]

    with open(installed_path, "w", encoding="utf-8") as f:
        json.dump(installed, f, indent=2, ensure_ascii=False)
    _print_ok(f"installed_plugins.json 업데이트 (key={plugin_key})")

    # 5) known_marketplaces.json 업데이트
    known_path = plugins_dir / "known_marketplaces.json"
    known = {}
    if known_path.exists():
        try:
            with open(known_path, encoding="utf-8") as f:
                known = json.load(f)
        except Exception:
            pass

    known["stock-kit"] = {
        "source": {
            "source": "local",
            "repo": "readinginvestor/stock-kit",
        },
        "installLocation": str(install_dir),
        "lastUpdated": now,
    }

    with open(known_path, "w", encoding="utf-8") as f:
        json.dump(known, f, indent=2, ensure_ascii=False)
    _print_ok("known_marketplaces.json 업데이트")

    _print("")
    _print("Claude Code 플러그인 설치 완료!")
    _print(f"  경로: {install_dir}")
    _print("  Claude Code를 재시작하면 자동 로딩됩니다.")
    _print("  /stock 명령으로 주식 데이터를 조회하세요.")
    return True


# ─── OpenClaw 스킬 설치 ───


def setup_openclaw() -> bool:
    """OpenClaw 스킬 + 에이전트 설치

    1. OPENCLAW_WORKSPACE 또는 ~/.openclaw/workspace/ 확인
    2. extensions/openclaw/skills/ → {workspace}/skills/ 복사
    3. extensions/openclaw/agents/ → {workspace}/agents/ 복사
    """
    print("\n--- OpenClaw Skill + Agent ---")

    src = _EXTENSIONS_DIR / "openclaw"
    if not src.exists():
        _print_err(f"번들 데이터 없음: {src}")
        return False

    # 워크스페이스 경로 결정
    workspace = os.getenv("OPENCLAW_WORKSPACE")
    if workspace:
        workspace = Path(workspace)
    else:
        workspace = Path.home() / ".openclaw" / "workspace"

    # 스킬 복사
    src_skills = src / "skills"
    if src_skills.exists():
        skills_dir = workspace / "skills"
        skills_dir.mkdir(parents=True, exist_ok=True)
        for item in src_skills.iterdir():
            dst_item = skills_dir / item.name
            if item.is_dir():
                _copytree(item, dst_item)
            else:
                shutil.copy2(item, dst_item)
        _print_ok(f"스킬 복사 → {skills_dir / 'stock-kit'}")

    # 에이전트 복사
    src_agents = src / "agents"
    if src_agents.exists():
        agents_dir = workspace / "agents"
        agents_dir.mkdir(parents=True, exist_ok=True)
        for item in src_agents.iterdir():
            dst_item = agents_dir / item.name
            if item.is_dir():
                _copytree(item, dst_item)
            else:
                shutil.copy2(item, dst_item)
        _print_ok(f"에이전트 복사 → {agents_dir / 'stock-kit.md'}")

    _print("")
    _print("OpenClaw 설치 완료! (스킬 + 에이전트)")
    _print(f"  스킬: {workspace / 'skills' / 'stock-kit'}")
    _print(f"  에이전트: {workspace / 'agents' / 'stock-kit.md'}")
    _print("  서버 실행: stockclaw-kit")
    return True


# ─── Google Antigravity 설치 ───


def setup_antigravity() -> bool:
    """Google Antigravity Workflow + Rule 설치

    1. SKILL.md → ~/.gemini/antigravity/global_workflows/stock-kit.md (워크플로우)
    2. ~/.gemini/GEMINI.md에 stock-kit 참조 추가 (글로벌 룰)
    """
    print("\n--- Google Antigravity ---")

    # SKILL.md 소스 찾기 (openclaw 번들 사용)
    skill_src = _EXTENSIONS_DIR / "openclaw" / "skills" / "stock-kit" / "SKILL.md"
    if not skill_src.exists():
        _print_err(f"SKILL.md 없음: {skill_src}")
        return False

    gemini_dir = Path.home() / ".gemini"

    # 1) Global Workflow 설치 → /stock-kit 명령으로 사용 가능
    workflows_dir = gemini_dir / "antigravity" / "global_workflows"
    workflows_dir.mkdir(parents=True, exist_ok=True)

    dst_workflow = workflows_dir / "stock-kit.md"
    shutil.copy2(skill_src, dst_workflow)
    _print_ok(f"워크플로우 복사 → {dst_workflow}")

    # sub-skills도 복사
    sub_skills_src = skill_src.parent / "skills"
    if sub_skills_src.exists():
        dst_skills = workflows_dir / "stock-kit-skills"
        dst_skills.mkdir(parents=True, exist_ok=True)
        for item in sub_skills_src.iterdir():
            shutil.copy2(item, dst_skills / item.name)
        _print_ok(f"서브 스킬 {len(list(sub_skills_src.iterdir()))}개 복사 → {dst_skills}")

    # 2) GEMINI.md에 stock-kit 참조 추가 (기존 내용 보존)
    gemini_md = gemini_dir / "GEMINI.md"
    marker = "<!-- stock-kit -->"

    existing = ""
    if gemini_md.exists():
        existing = gemini_md.read_text(encoding="utf-8")

    if marker not in existing:
        stock_kit_rule = f"""
{marker}
## Stock Kit (한국 주식 데이터 & 매매 도구)

주식/시세/종목/매매/뉴스/차트 관련 질문이 오면 `stockclaw-kit run` CLI를 사용하세요.

- 도구 목록: `stockclaw-kit run list`
- 사용 가이드: `/stock-kit` 워크플로우 실행
- 설치 확인: `stockclaw-kit run gateway_status`
{marker}
"""
        with open(gemini_md, "a", encoding="utf-8") as f:
            f.write(stock_kit_rule)
        _print_ok(f"GEMINI.md에 stock-kit 참조 추가 → {gemini_md}")
    else:
        _print_skip("GEMINI.md에 이미 stock-kit 등록됨")

    _print("")
    _print("Antigravity 설치 완료!")
    _print(f"  워크플로우: /stock-kit 명령으로 사용")
    _print(f"  글로벌 룰: 주식 관련 질문 시 자동 인식")
    _print("  Antigravity를 재시작하면 적용됩니다.")
    return True


# ─── 통합 설치 ───


def setup_all() -> bool:
    """Claude Code + OpenClaw + Antigravity 모두 설치"""
    print("=" * 50)
    print("OpenClaw Stock Kit — 통합 설치")
    print("=" * 50)

    ok_cc = setup_claude_code()
    ok_oc = setup_openclaw()
    ok_ag = setup_antigravity()

    results = []
    if ok_cc: results.append("Claude Code")
    if ok_oc: results.append("OpenClaw")
    if ok_ag: results.append("Antigravity")

    print("\n" + "=" * 50)
    if results:
        print(f"설치 완료: {', '.join(results)}")
    else:
        print("설치 실패")
    print("=" * 50)

    return bool(results)


def run_setup(target: str | None = None) -> int:
    """CLI에서 호출되는 진입점

    Args:
        target: "claude-code", "openclaw", "antigravity", 또는 None (전부)

    Returns:
        종료 코드 (0=성공, 1=실패)
    """
    if target == "claude-code":
        print("=" * 50)
        print("OpenClaw Stock Kit — Claude Code 플러그인 설치")
        print("=" * 50)
        ok = setup_claude_code()
    elif target == "openclaw":
        print("=" * 50)
        print("OpenClaw Stock Kit — OpenClaw 스킬 설치")
        print("=" * 50)
        ok = setup_openclaw()
    elif target == "antigravity":
        print("=" * 50)
        print("OpenClaw Stock Kit — Antigravity 설치")
        print("=" * 50)
        ok = setup_antigravity()
    else:
        ok = setup_all()

    return 0 if ok else 1


# ─── 서버 관리 ───

_STATE_DIR = Path.home() / ".stockclaw-kit"
_SERVER_JSON = _STATE_DIR / "server.json"
_PM2_NAME = "stockclaw-kit"


def _is_port_in_use(port: int) -> bool:
    """socket으로 포트 사용 여부 체크"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        try:
            s.connect(("127.0.0.1", port))
            return True
        except (ConnectionRefusedError, OSError):
            return False


def _is_pid_running(pid: int) -> bool:
    """PID가 현재 실행 중인지 확인"""
    if pid <= 0:
        return False
    if sys.platform == "win32":
        try:
            result = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/NH", "/FO", "CSV"],
                capture_output=True,
                text=True,
            )
            return str(pid) in result.stdout
        except Exception:
            return False
    else:
        try:
            os.kill(pid, 0)
            return True
        except (ProcessLookupError, PermissionError):
            return False


def server_start(port: int = 8200) -> bool:
    """서버를 시작합니다. pm2가 있으면 pm2로, 없으면 daemon 모드로 실행."""
    print("\n--- StockClaw Kit 서버 시작 ---")

    # 이미 실행 중인지 확인
    if _is_port_in_use(port):
        _print_skip(f"이미 실행 중 (port={port})")
        return True

    _STATE_DIR.mkdir(parents=True, exist_ok=True)

    # CLI 경로 탐색
    cli_path = shutil.which("stockclaw-kit")

    has_pm2 = shutil.which("pm2") is not None

    if has_pm2:
        # pm2 모드
        _print(f"pm2로 서버 시작 (port={port}) ...")
        if cli_path:
            pm2_cmd = [
                "pm2", "start", cli_path,
                "--name", _PM2_NAME,
                "--interpreter", "none",
                "--", "serve", "-p", str(port),
            ]
        else:
            pm2_cmd = [
                "pm2", "start", sys.executable,
                "--name", _PM2_NAME,
                "--interpreter", "none",
                "--", "-m", "openclaw_stock_kit", "serve", "-p", str(port),
            ]

        try:
            subprocess.run(pm2_cmd, check=True, shell=True)
            subprocess.run(["pm2", "save"], check=False, shell=True)
        except subprocess.CalledProcessError as e:
            _print_err(f"pm2 시작 실패: {e}")
            return False

        # PID 확인
        pid = 0
        try:
            result = subprocess.run(
                ["pm2", "jlist"], capture_output=True, text=True, shell=True
            )
            procs = json.loads(result.stdout)
            for p in procs:
                if p.get("name") == _PM2_NAME:
                    pid = p.get("pid", 0)
                    break
        except Exception:
            pass

        mode = "pm2"

    else:
        # daemon 모드
        _print(f"daemon 모드로 서버 시작 (port={port}) ...")
        if cli_path:
            cmd = [cli_path, "serve", "-p", str(port)]
        else:
            cmd = [sys.executable, "-m", "openclaw_stock_kit", "serve", "-p", str(port)]

        try:
            if sys.platform == "win32":
                proc = subprocess.Popen(
                    cmd,
                    creationflags=0x08000000,  # CREATE_NO_WINDOW
                )
            else:
                proc = subprocess.Popen(
                    cmd,
                    start_new_session=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            pid = proc.pid
        except Exception as e:
            _print_err(f"서버 시작 실패: {e}")
            return False

        mode = "daemon"

    # 상태 파일 저장
    state = {
        "pid": pid,
        "port": port,
        "mode": mode,
        "started_at": _now_iso(),
    }
    with open(_SERVER_JSON, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)

    _print_ok(f"서버 시작 완료 (mode={mode}, pid={pid}, port={port})")
    return True


def server_stop() -> bool:
    """실행 중인 서버를 중지합니다."""
    print("\n--- StockClaw Kit 서버 중지 ---")

    if not _SERVER_JSON.exists():
        _print_skip("실행 중인 서버 없음 (server.json 없음)")
        return True

    try:
        with open(_SERVER_JSON, encoding="utf-8") as f:
            state = json.load(f)
    except Exception as e:
        _print_err(f"server.json 읽기 실패: {e}")
        return False

    mode = state.get("mode", "daemon")
    pid = state.get("pid", 0)

    if mode == "pm2":
        _print(f"pm2로 서버 중지 ({_PM2_NAME}) ...")
        try:
            subprocess.run(["pm2", "delete", _PM2_NAME], check=True, shell=True)
            subprocess.run(["pm2", "save"], check=False, shell=True)
            _print_ok("pm2 프로세스 제거 완료")
        except subprocess.CalledProcessError as e:
            _print_err(f"pm2 중지 실패: {e}")
            return False
    else:
        # daemon 모드: PID로 종료
        if pid and _is_pid_running(pid):
            _print(f"프로세스 종료 (pid={pid}) ...")
            try:
                if sys.platform == "win32":
                    subprocess.run(["taskkill", "/F", "/PID", str(pid)], check=True)
                else:
                    os.kill(pid, 15)  # SIGTERM
                _print_ok(f"프로세스 종료 완료 (pid={pid})")
            except Exception as e:
                _print_err(f"프로세스 종료 실패: {e}")
                return False
        else:
            _print_skip(f"프로세스가 이미 종료됨 (pid={pid})")

    # 상태 파일 삭제
    try:
        _SERVER_JSON.unlink()
    except Exception:
        pass

    _print_ok("서버 중지 완료")
    return True


def server_status() -> dict:
    """서버 상태를 반환하고 콘솔에 출력합니다."""
    print("\n--- StockClaw Kit 서버 상태 ---")

    if not _SERVER_JSON.exists():
        result = {"running": False, "port": 0, "pid": 0, "mode": "", "started_at": ""}
        _print("서버가 실행되지 않고 있습니다.")
        return result

    try:
        with open(_SERVER_JSON, encoding="utf-8") as f:
            state = json.load(f)
    except Exception as e:
        _print_err(f"server.json 읽기 실패: {e}")
        return {"running": False, "port": 0, "pid": 0, "mode": "", "started_at": ""}

    pid = state.get("pid", 0)
    port = state.get("port", 0)
    mode = state.get("mode", "")
    started_at = state.get("started_at", "")

    # 실제 실행 여부 확인
    if mode == "pm2":
        running = False
        try:
            result = subprocess.run(
                ["pm2", "jlist"], capture_output=True, text=True, shell=True
            )
            procs = json.loads(result.stdout)
            for p in procs:
                if p.get("name") == _PM2_NAME and p.get("pm2_env", {}).get("status") == "online":
                    running = True
                    pid = p.get("pid", pid)
                    break
        except Exception:
            running = _is_pid_running(pid)
    else:
        running = _is_pid_running(pid)

    # 포트도 함께 확인
    port_active = _is_port_in_use(port) if port else False

    status = {
        "running": running and port_active,
        "port": port,
        "pid": pid,
        "mode": mode,
        "started_at": started_at,
    }

    # 콘솔 출력
    state_str = "실행 중" if status["running"] else "중지됨"
    _print(f"상태     : {state_str}")
    _print(f"모드     : {mode}")
    _print(f"PID      : {pid}")
    _print(f"포트     : {port}")
    _print(f"시작시간 : {started_at}")

    return status


def server_restart(port: int = 8200) -> bool:
    """서버를 재시작합니다."""
    print("\n--- StockClaw Kit 서버 재시작 ---")
    server_stop()
    return server_start(port)
