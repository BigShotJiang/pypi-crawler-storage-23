# pidevkit-agent

Agent orchestration/runtime package for `pidevkit`.

## Install

```bash
pip install pidevkit-agent
```

## Import

```python
from pidevkit.agent import Agent
```
