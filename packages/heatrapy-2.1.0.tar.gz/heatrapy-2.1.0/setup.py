# -*- coding: utf-8 -*-
"""heatrapy: Library for simulating heat transfer processes

Computes heat transfer processes in solids for 1D and 2D models.

"""

from setuptools import setup

description = 'This package is a module for simulating dynamic 1D and 2D heat '
description += 'transfer processes by using the finite difference method. The '
description += 'packages is based on thermal objects. Two different '
description += 'approaches can be used: single thermal object and a system of '
description += 'thermal objects that can contact with each other. The heatrapy'
description += 'package includes the incorporation of phase transitions.'


setup(name='heatrapy',
      version='2.1.0',
      description='Library for simulating 1D and 2D heat transfer processes',
      long_description=description,
      classifiers=[
          'Development Status :: 3 - Alpha',
          'License :: OSI Approved :: MIT License',
          'Programming Language :: Python :: 3.7',
          'Topic :: Scientific/Engineering :: Physics',
      ],
      url='https://github.com/djsilva99/heatrapy',
      author='Daniel Silva',
      author_email='djsilva@gmx.com',
      license='MIT',
      packages=['heatrapy'],
      install_requires=[
          'numpy==2.2.6', 'matplotlib==3.10.8'
      ],
      include_package_data=True,
      zip_safe=False)
