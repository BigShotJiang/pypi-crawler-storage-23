"""rangebar has been renamed to opendeviationbar.

This shim package re-exports everything from opendeviationbar so existing
``import rangebar`` and ``from rangebar import ...`` continue to work.

To silence this warning, update your imports::

    # Before
    from rangebar import get_range_bars

    # After
    from opendeviationbar import get_open_deviation_bars
"""

from __future__ import annotations

import warnings

warnings.warn(
    "The 'rangebar' package has been renamed to 'opendeviationbar'. "
    "Install it with: pip install opendeviationbar. "
    "This shim will be removed in a future release.",
    DeprecationWarning,
    stacklevel=2,
)

from opendeviationbar import *  # noqa: F401, F403, E402
from opendeviationbar import __version__  # noqa: F401, E402
