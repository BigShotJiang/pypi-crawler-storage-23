# rangebar → opendeviationbar

**This package has been renamed to [`opendeviationbar`](https://pypi.org/project/opendeviationbar/).**

The algorithm uses open-anchored deviation thresholds (not classic Nicolellis range bars), so the name was updated to reflect this.

## Migration

```bash
pip install opendeviationbar
pip uninstall rangebar
```

Update your imports:

```python
# Before
from rangebar import get_range_bars

# After
from opendeviationbar import get_open_deviation_bars
```

## Compatibility

This shim package depends on `opendeviationbar` and re-exports all symbols. Existing `import rangebar` code will continue to work with a deprecation warning.
