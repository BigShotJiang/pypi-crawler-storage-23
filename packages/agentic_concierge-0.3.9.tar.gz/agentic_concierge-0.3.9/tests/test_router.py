"""Tests for capability-based recruitment (recruit_specialist)."""
from __future__ import annotations

import pytest
from agentic_concierge.application.recruit import recruit_specialist
from agentic_concierge.config import DEFAULT_CONFIG
from agentic_concierge.config.schema import ConciergeConfig, SpecialistConfig


@pytest.mark.parametrize("prompt,expected", [
    # engineering keywords → code_execution capability → engineering pack
    ("I need to build a Python service", "engineering"),
    ("implement a pipeline in Scala", "engineering"),
    ("deploy to kubernetes", "engineering"),
    # research keywords → systematic_review capability → research pack
    ("systematic review of literature", "research"),
    ("survey papers on arxiv", "research"),
    ("bibliography and citations", "research"),
])
def test_keyword_routing(prompt, expected):
    assert recruit_specialist(prompt, DEFAULT_CONFIG).specialist_id == expected


@pytest.mark.parametrize("prompt,expected", [
    ("write some code", "engineering"),
    ("build a small API", "engineering"),
    ("explore a topic", "research"),
    ("tell me about something", "research"),
])
def test_fallback_routing(prompt, expected):
    assert recruit_specialist(prompt, DEFAULT_CONFIG).specialist_id == expected


def _make_tie_config(first: str, second: str) -> ConciergeConfig:
    """Two specialists sharing the same keyword; order controls tie-break."""
    return ConciergeConfig(
        models=DEFAULT_CONFIG.models,
        specialists={
            first: SpecialistConfig(description=first, keywords=["foo"], workflow=first),
            second: SpecialistConfig(description=second, keywords=["foo"], workflow=second),
        },
    )


@pytest.mark.parametrize("first,second,expected", [
    ("alpha", "beta", "alpha"),  # alpha listed first → wins the tie
    ("beta", "alpha", "beta"),   # beta listed first → wins the tie
])
def test_tie_break_uses_config_order(first, second, expected):
    """When two specialists score equally, the one first in config wins."""
    config = _make_tie_config(first, second)
    assert recruit_specialist("foo bar", config).specialist_id == expected
