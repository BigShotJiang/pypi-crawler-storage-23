"""Bootstrap: system probing, profile detection, and backend management."""
