# Tasks: phase0-fixtures-docker

## Test-first tasks
- [x] Add tests for tooling file presence and script validation.

## Implementation tasks
- [x] Add `scripts/capture_fixture.sh`.
- [x] Add `docker/Dockerfile`.
- [x] Update README for fixture workflow.
