# Tasks: phase0-structure-refactor

## Test-first tasks
- [x] Add unit tests for session service functions.

## Implementation tasks
- [x] Add `src/rdc/services/session_service.py`.
- [x] Refactor `commands/session.py` to call service layer.
- [x] Keep behavior and exit code parity.
