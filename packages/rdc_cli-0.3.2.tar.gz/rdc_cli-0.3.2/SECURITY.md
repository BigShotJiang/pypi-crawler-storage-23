# Security Policy

## Reporting a Vulnerability

To report a security vulnerability, please open a GitHub issue with the label `security`.
Do not include sensitive exploit details in public issues.
