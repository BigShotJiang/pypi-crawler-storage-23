# My CREATESONLINE Application

> ** UPGRADE-SAFE PROJECT** - All customizations are preserved during framework upgrades!

## Quick Start

```bash
# Install
pip install createsonline

# Run
python main.py

# Visit
http://localhost:8000
```

## Project Structure

```
your-project/
├── main.py               Your app bootstrap (SAFE TO EDIT)
├── routes.py             Your URL routes (SAFE TO EDIT)
├── user_config.py        Your settings (SAFE TO EDIT)
├── templates/            Your HTML templates (SAFE TO EDIT)
└── static/               Your CSS/JS/images (SAFE TO EDIT)
```

## Add Custom Routes

Edit `routes.py`:

```python
async def my_view(request):
    return {"message": "Hello!"}

urlpatterns.append(path('/custom', my_view))
```

## Upgrade Framework

```bash
pip install --upgrade createsonline
# Your files are automatically preserved! ✨
```

## Documentation

- Quick Start: `/static/guide.html`
- Examples: `/static/examples.html`
- GitHub: https://github.com/meahmedh/createsonline
