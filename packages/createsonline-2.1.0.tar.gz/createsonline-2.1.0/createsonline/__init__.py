# createsonline/__init__.py
"""
CREATESONLINE - The AI-Native Web Framework

Build Intelligence Into Everything
"""

from pathlib import Path

def _get_version():
    """Get version from VERSION file (dev) or package metadata (installed)."""
    version_file = Path(__file__).parent.parent / "VERSION"
    if version_file.exists():
        return version_file.read_text().strip()
    try:
        from importlib.metadata import version
        return version('createsonline')
    except Exception:
        return '2.0.0'

__version__ = _get_version()
__framework_name__ = 'CREATESONLINE'
__tagline__ = 'Build Intelligence Into Everything'
__author__ = 'Ahmed Hassan'
__license__ = 'MIT'

# Import main API
from .app import CreatesonlineInternalApp, create_app
from .server import run_server
from .static_files import StaticFileHandler, serve_static, serve_template
from .templates import render_template, render_to_response, TemplateEngine
from .project_init import ProjectInitializer, auto_discover_routes, init_project_if_needed

# Session and Authentication (v1.55.0)
from .session import (
    SessionManager,
    SessionMiddleware,
    get_session,
    get_user_id,
    is_authenticated,
    set_session_cookie,
    clear_session_cookie
)
from .decorators import (
    require_login,
    require_role,
    require_any_role,
    require_permission,
    optional_login
)

# Secure Database Sessions (v1.55.0)
from .database_session import (
    SecureDatabaseSessionManager,
    create_secure_session_manager
)

# Rich Text Editor (v1.60.0)
from .editor import (
    rich_text_widget,
    rte_widget,
    RichTextWidget,
    rich_text_field_class
)
from .upload_handler import (
    UploadHandler,
    create_upload_route
)

# SEO Checker & Middleware (v1.60.0)
from .seo_middleware import (
    SEOAnalyzer,
    SEOMiddleware,
    analyze_html_seo
)

# NLP Module (v2.0.0)
from .nlp import (
    BPETokenizer,
    WordTokenizer,
    CharTokenizer,
    Vocabulary,
    TextProcessor,
)

# ML / Transformer Module (v2.0.0)
from .ml import (
    TransformerLM,
    TransformerSeq2Seq,
    TransformerEncoderBlock,
    TransformerDecoderBlock,
    MultiHeadAttention,
    Trainer,
    Adam,
    AdamW,
    SGD,
    DataLoader,
    TextDataset,
    Checkpoint,
    WarmupScheduler,
    CosineScheduler,
    train_language_model,
)

# Agent / SubAgent Framework (v2.0.0)
from .agents import (
    Agent,
    SubAgent,
    AgentResponse,
    ToolRegistry,
    Tool,
    ToolResult,
    ConversationMemory,
    VectorMemory,
    MemoryManager,
    AgentOrchestrator,
    Pipeline,
    ParallelPipeline,
    PromptTemplate,
    FewShotPrompt,
    ChainOfThought,
)

# Dynamic Admin (v2.0.0)
from .admin import (
    DynamicAdmin,
    ModelConfig,
    ModelMeta,
    AdminHTMLGenerator,
)

# Upgrade-Safe Customization System (v2.0.0)
from .customization import (
    CustomizationLoader,
    UserOverride,
    HookRegistry,
    PluginBase,
)

# Auto-Discovery System (v2.0.0)
from .autodiscover import (
    discover,
    discover_views,
    discover_api,
    route,
)

__all__ = [
    'create_app',
    'CreatesonlineInternalApp',
    'run_server',
    'StaticFileHandler',
    'serve_static',
    'serve_template',
    'render_template',
    'render_to_response',
    'TemplateEngine',
    'ProjectInitializer',
    'auto_discover_routes',
    'init_project_if_needed',
    # Session & Auth (v1.55.0)
    'SessionManager',
    'SessionMiddleware',
    'get_session',
    'get_user_id',
    'is_authenticated',
    'set_session_cookie',
    'clear_session_cookie',
    'require_login',
    'require_role',
    'require_any_role',
    'require_permission',
    'optional_login',
    # Secure Database Sessions (v1.55.0)
    'SecureDatabaseSessionManager',
    'create_secure_session_manager',
    # Rich Text Editor (v1.60.0)
    'rich_text_widget',
    'rte_widget',
    'RichTextWidget',
    'rich_text_field_class',
    'UploadHandler',
    'create_upload_route',
    # SEO Checker & Middleware (v1.60.0)
    'SEOAnalyzer',
    'SEOMiddleware',
    'analyze_html_seo',
    # Upgrade-Safe Customization (v2.0.0)
    'CustomizationLoader',
    'UserOverride',
    'HookRegistry',
    'PluginBase',
    # Auto-Discovery (v2.0.0)
    'discover',
    'discover_views',
    'discover_api',
    'route',
    # NLP (v2.0.0)
    'BPETokenizer',
    'WordTokenizer',
    'CharTokenizer',
    'Vocabulary',
    'TextProcessor',
    # ML / Transformer (v2.0.0)
    'TransformerLM',
    'TransformerSeq2Seq',
    'TransformerEncoderBlock',
    'TransformerDecoderBlock',
    'MultiHeadAttention',
    'Trainer',
    'Adam',
    'AdamW',
    'SGD',
    'DataLoader',
    'TextDataset',
    'Checkpoint',
    'WarmupScheduler',
    'CosineScheduler',
    'train_language_model',
    # Agents (v2.0.0)
    'Agent',
    'SubAgent',
    'AgentResponse',
    'ToolRegistry',
    'Tool',
    'ToolResult',
    'ConversationMemory',
    'VectorMemory',
    'MemoryManager',
    'AgentOrchestrator',
    'Pipeline',
    'ParallelPipeline',
    'PromptTemplate',
    'FewShotPrompt',
    'ChainOfThought',
    # Dynamic Admin (v2.0.0)
    'DynamicAdmin',
    'ModelConfig',
    'ModelMeta',
    'AdminHTMLGenerator',
    '__version__',
]

