# createsonline/security/__init__.py
"""
CREATESONLINE Security Module

Ultra-high security implementations that prevent vulnerabilities:
- SQL injection protection
- XSS prevention
- CSRF protection
- Rate limiting
- Input validation
- Authentication & authorization
- Encryption utilities
"""

__all__ = [
    'SecurityManager',
    'InputValidator',
    'RateLimiter',
    'CSRFProtection',
    'XSSProtection',
    'SQLInjectionProtection',
    'encrypt_password',
    'verify_password',
    'generate_secure_token',
    'secure_middleware'
]

from .core import (
    SecurityManager,
    secure_middleware,
    InputValidator,
    RateLimiter,
    CSRFProtection,
    XSSProtection,
    SQLInjectionProtection,
    PasswordPolicy,
    ThreatDetector,
    AuditLogger,
    SecurityMetrics,
)
from .encryption import encrypt_password, verify_password, generate_secure_token