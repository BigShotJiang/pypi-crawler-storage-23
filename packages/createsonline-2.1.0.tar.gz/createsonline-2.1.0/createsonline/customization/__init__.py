# createsonline/customization/__init__.py
"""
CREATESONLINE Upgrade-Safe Customization System

This module provides the architecture for user customizations that survive
framework upgrades. Users place their files in a 'custom/' directory at
the project root, and the framework automatically discovers and loads them.

How it works:
    1. Framework ships in `createsonline/` package — pip upgrades replace this.
    2. User customizations go in `custom/` at project root — NEVER touched by pip.
    3. On startup, CustomizationLoader scans `custom/` and merges overrides.
    4. Any framework class, template, route, or admin config can be overridden.

Directory structure users create:
    project_root/
    ├── main.py              (upgrade-safe, auto-generated)
    ├── routes.py             (upgrade-safe, auto-generated)
    ├── user_config.py        (upgrade-safe, auto-generated)
    ├── custom/               (ALL user customizations go here)
    │   ├── __init__.py
    │   ├── models.py         (custom SQLAlchemy models)
    │   ├── views.py          (custom view handlers)
    │   ├── admin.py          (admin panel overrides)
    │   ├── middleware.py      (custom middleware)
    │   ├── hooks.py          (lifecycle hooks)
    │   ├── templates/        (template overrides)
    │   └── static/           (static file overrides)
    └── createsonline/        (framework package — pip-managed)
"""

from .loader import (
    CustomizationLoader,
    UserOverride,
    HookRegistry,
    PluginBase,
)

__all__ = [
    'CustomizationLoader',
    'UserOverride',
    'HookRegistry',
    'PluginBase',
]
