# createsonline/agents/__init__.py
"""
CREATESONLINE Agent Framework

Build intelligent agents with tools, memory, and orchestration.
Supports both local ML models and external LLM APIs.

Usage:
    from createsonline.agents import Agent, ToolRegistry, ConversationMemory

    # Create agent with tools and memory
    memory = ConversationMemory(max_turns=50)
    tools = ToolRegistry()
    tools.register("search", search_fn, "Search the web")
    
    agent = Agent(
        name="assistant",
        system_prompt="You are a helpful assistant.",
        tools=tools,
        memory=memory,
    )
    
    response = await agent.run("What's the weather today?")
"""

from .base import Agent, SubAgent, AgentResponse
from .tools import ToolRegistry, Tool, ToolResult
from .memory import ConversationMemory, VectorMemory, MemoryManager
from .orchestrator import AgentOrchestrator, Pipeline, ParallelPipeline
from .prompts import PromptTemplate, FewShotPrompt, ChainOfThought

__all__ = [
    # Core
    'Agent',
    'SubAgent',
    'AgentResponse',
    # Tools
    'ToolRegistry',
    'Tool',
    'ToolResult',
    # Memory
    'ConversationMemory',
    'VectorMemory',
    'MemoryManager',
    # Orchestration
    'AgentOrchestrator',
    'Pipeline',
    'ParallelPipeline',
    # Prompts
    'PromptTemplate',
    'FewShotPrompt',
    'ChainOfThought',
]
