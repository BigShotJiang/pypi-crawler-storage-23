# createsonline/admin/__init__.py
from .interface import AdminSite, ModelAdmin
from .dynamic_admin import DynamicAdmin, ModelConfig, ModelMeta, AdminHTMLGenerator

# Create default admin site
admin_site = AdminSite(name='admin')

__all__ = [
    'AdminSite', 'ModelAdmin', 'admin_site',
    'DynamicAdmin', 'ModelConfig', 'ModelMeta', 'AdminHTMLGenerator',
]