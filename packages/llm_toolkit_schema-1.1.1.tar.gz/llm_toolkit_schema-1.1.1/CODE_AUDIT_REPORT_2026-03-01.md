# Code Audit Report

Date: 2026-03-01  
Repository: `llm-toolkit-schema`  
Scope: Coding standards, performance, security, hallucination controls, and observability

## Executive Summary

- The codebase is generally high quality with strong typing, clear module boundaries, and extensive tests.
- Functional tests pass (`1214 passed`), but CI currently fails due to strict coverage gate (`97.71%` vs required `100%`).
- Highest-impact issues are: mutable event payload despite immutability claims, validation/signature format drift, partially implemented governance behavior, and exporter hardening/performance gaps.

## Verification Performed

- Static inspection of core modules:
  - `llm_toolkit_schema/event.py`
  - `llm_toolkit_schema/validate.py`
  - `llm_toolkit_schema/signing.py`
  - `llm_toolkit_schema/governance.py`
  - `llm_toolkit_schema/stream.py`
  - `llm_toolkit_schema/export/*.py`
  - `llm_toolkit_schema/namespaces/*.py`
  - `llm_toolkit_schema/_cli.py`
- Grep-based scans for broad exception handling and risky patterns.
- Test run: `python -m pytest -q` in project venv.

## Findings by Category

### 1) Coding Standards & Correctness

#### 1.1 Event immutability contract is violated (High)

**Observation**
- The documentation promises immutability after creation, but `Event.payload` returns the internal mutable dict directly.

**Risk**
- Consumers can mutate payloads post-validation/signing, leading to data integrity bugs and confusing behavior.

**Evidence**
- `llm_toolkit_schema/event.py` (`payload` property returns `_payload` directly).

**Recommended Fix**
- Return a defensive copy or read-only mapping (`MappingProxyType`) in `payload` property.
- Optionally deep-freeze nested structures at construction if strict immutability is required.
- Add tests that verify mutation attempts do not alter internal event state.

#### 1.2 Governance `strict_unknown` field is unused (Medium)

**Observation**
- `strict_unknown` exists in `EventGovernancePolicy`, but no logic uses it in `check_event`.

**Risk**
- Misleading API: users assume strict unknown handling exists when it does not.

**Evidence**
- `llm_toolkit_schema/governance.py` (field present, no behavior branch).

**Recommended Fix**
- Implement strict behavior: block/warn unknown event types when `strict_unknown=True`.
- Or remove the field/docs until behavior is fully implemented.

#### 1.3 Broad exception handling in user-facing ingestion paths (Medium)

**Observation**
- Broad `except Exception` blocks are used in CLI and stream parsing paths.

**Risk**
- Can mask root causes and leak low-level/internal exception text into user output.

**Evidence**
- `llm_toolkit_schema/_cli.py`
- `llm_toolkit_schema/stream.py`

**Recommended Fix**
- Catch typed exceptions (`JSONDecodeError`, `DeserializationError`, etc.).
- Preserve structured diagnostics internally while providing sanitized user messages.

### 2) Security

#### 2.1 Validation/signature format mismatch (High)

**Observation**
- Signing code emits prefixed values:
  - checksum: `sha256:<hex>`
  - signature: `hmac-sha256:<hex>`
- Stdlib fallback validator currently validates both fields as bare 64-hex.

**Risk**
- Signed valid events may fail schema validation in fallback path.
- Security/validation logic drift can cause reject/accept inconsistencies.

**Evidence**
- `llm_toolkit_schema/signing.py`
- `llm_toolkit_schema/validate.py`

**Recommended Fix**
- Use dedicated patterns:
  - checksum: `^sha256:[0-9a-f]{64}$`
  - signature: `^hmac-sha256:[0-9a-f]{64}$`
- Align with published JSON schema and model validators.

#### 2.2 Exporter endpoint hardening gaps (Medium)

**Observation**
- Webhook/OTLP/Grafana URLs and Datadog site are accepted with minimal validation.

**Risk**
- SSRF-like misconfiguration, accidental local-network targeting, or malformed host injection in operational setups.

**Evidence**
- `llm_toolkit_schema/export/webhook.py`
- `llm_toolkit_schema/export/otlp.py`
- `llm_toolkit_schema/export/grafana.py`
- `llm_toolkit_schema/export/datadog.py`

**Recommended Fix**
- Parse and validate URLs at construction:
  - Enforce allowed schemes (`https` by default; configurable `http` for local dev).
  - Optional denylist for localhost/private CIDRs unless explicitly enabled.
  - Strict hostname validation for `dd_site`.

#### 2.3 Datadog fallback IDs are not deterministic across runs (Medium)

**Observation**
- Uses `hash()` fallback for trace/span IDs.

**Risk**
- Python hash randomization yields unstable IDs across processes; trace correlation can break.

**Evidence**
- `llm_toolkit_schema/export/datadog.py`

**Recommended Fix**
- Replace fallback with stable derivation (e.g., SHA-256 truncation).

### 3) Performance & Scalability

#### 3.1 OTLP `batch_size` is configured but not enforced (Medium)

**Observation**
- `batch_size` is stored and documented, but `export_batch` does not chunk by it.

**Risk**
- Large batches may cause oversized payloads, memory spikes, and network backpressure issues.

**Evidence**
- `llm_toolkit_schema/export/otlp.py`

**Recommended Fix**
- Implement chunking in `export_batch` using `self._batch_size` and send per chunk.

#### 3.2 In-memory accumulation for ingestion constructors (Medium)

**Observation**
- `from_file`, `from_queue`, `from_async_queue`, `from_async_iter`, and `from_kafka` collect all events into lists.

**Risk**
- High memory use for long streams or large files.

**Evidence**
- `llm_toolkit_schema/stream.py`

**Recommended Fix**
- Provide iterator/async-iterator streaming alternatives and bounded/limit options.

#### 3.3 Datadog exporter uses current wall clock instead of event timestamp (Low-Medium)

**Observation**
- Span start time/metric timestamps are based on `time.time()` rather than event timestamp.

**Risk**
- Distorted observability timelines and inaccurate replay analysis.

**Evidence**
- `llm_toolkit_schema/export/datadog.py`

**Recommended Fix**
- Parse and use `event.timestamp` for temporal fidelity.

### 4) Hallucination & Agentic Safety Controls

#### 4.1 Guard/fence modules are schema-only, not enforcement (Medium)

**Observation**
- Namespaces provide payload data classes for guard/fence events, but no runtime policy engine exists here.

**Risk**
- Teams may assume these modules enforce anti-hallucination behavior by default.

**Evidence**
- `llm_toolkit_schema/namespaces/guard.py`
- `llm_toolkit_schema/namespaces/fence.py`
- `llm_toolkit_schema/namespaces/template.py`

**Recommended Fix**
- Add explicit runtime policy hooks (or a companion enforcement module):
  - pre-generation input guard checks
  - post-generation output validation and retry policy
  - citation/grounding validation hooks
  - configurable fail-open/fail-closed behavior

## Observability Posture

### Strengths

- Strong event envelope model with trace/org/team/session metadata.
- Dedicated exporters for OTLP, Datadog, Grafana, webhook, and JSONL.
- Signing/audit-chain support for tamper evidence.
- Comprehensive tests and high effective coverage.

### Gaps

- Timestamp normalization inconsistency across exporters.
- Some documented behavior not fully implemented (`strict_unknown`, `batch_size`).
- Hardening guards for egress endpoints should be stronger for production use.

## Prioritized Remediation Plan

### P0 (Immediate)

1. Fix validator/signature format alignment in `validate.py`.
2. Enforce event payload immutability contract in `event.py`.

### P1 (Next)

3. Implement `strict_unknown` governance behavior (or remove option).
4. Enforce OTLP exporter chunking by configured `batch_size`.
5. Replace Datadog `hash()` fallback IDs with deterministic cryptographic derivation.

### P2 (Hardening)

6. Add URL/site validation and safe egress options in exporters.
7. Add streaming ingestion APIs to avoid full-memory accumulation.
8. Introduce explicit runtime guardrail/fence enforcement hooks and docs.

## Suggested Acceptance Criteria for Fixes

- New unit tests for each fix path and regression scenario.
- No behavioral drift in existing passing tests.
- Compatibility docs updated where behavior changes are user-visible.
- Security-sensitive changes reviewed with threat-model checklist.

## Test Status (at time of audit)

- Command: `python -m pytest -q`
- Result: Functional tests passed (`1214 passed`), process exited non-zero due to coverage gate.
- Coverage gate failure: total coverage below required threshold (`97.71%` vs `100%`).

---

If needed, I can generate a follow-up implementation patch set that addresses P0 + P1 items with tests.