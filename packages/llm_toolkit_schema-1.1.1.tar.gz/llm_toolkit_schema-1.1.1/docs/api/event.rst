.. _api_event:

llm_toolkit_schema.event
========================

.. automodule:: llm_toolkit_schema.event
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
