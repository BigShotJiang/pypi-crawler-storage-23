from setuptools import setup

# 配置已移至setup.cfg
setup()