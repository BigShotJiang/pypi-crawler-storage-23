# Reference

[Project README](../../README.md) · [Docs Index](../README.md)

- [Command contract v1](command-contract-v1.md)
- [FastAPI scaffold layout](fastapi-scaffold-template.md)
- [Config example](examples/pyquick.toml)
