# Quality and Performance

[Project README](../../README.md) · [Docs Index](../README.md)

- [E2E testing](e2e-testing.md)
- [Performance benchmarks](perf-benchmarks.md)
- [Alpha performance baseline](perf-baseline-alpha.md)
