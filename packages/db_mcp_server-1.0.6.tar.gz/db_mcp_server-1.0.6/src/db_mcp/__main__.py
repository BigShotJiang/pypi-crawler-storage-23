from db_mcp.server import main

main()
