# Configuration for NERSC IRI API
# OpenAPI documentation: https://api.iri.nersc.gov/

export IRI_BASE_URL="https://api.iri.nersc.gov"
export IRI_SITE_ID="dd7f822a-3ad2-54ae-bddb-796ee07bd206" # NERSC
export IRI_ACCESS_TOKEN="<your_token>"
