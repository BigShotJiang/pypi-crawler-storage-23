# Hardware Autofocus Plan

Ways to describe a hardware-based autofocus plan.

::: useq.AutoFocusPlan
    options:
        show_signature: true
        show_signature_annotations: true
        members:
            - as_action
            - event
            - should_autofocus

::: useq.AxesBasedAF
    options:
        show_source: true
        show_signature: true
        show_signature_annotations: true
        members:
            - should_autofocus
