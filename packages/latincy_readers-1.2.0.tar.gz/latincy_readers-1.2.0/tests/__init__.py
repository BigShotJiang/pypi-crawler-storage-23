"""Test suite for latincy-readers."""
