from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from dcc_quantities._abc import AbstractValueType

if TYPE_CHECKING:
    from datetime import datetime


class SiComplexList(AbstractValueType):
    def __init__(
        self,
        data: list,
        label: Optional[str] = None,
        unit: Optional[str] = None,
        date_time: Optional[datetime] = None,
        phase: Optional[str] = None,
        uncertainty: Optional[str] = None,
    ) -> None:
        super().__init__(label, unit, date_time)
        self.data = data
        self.phase = phase
        self.uncertainty = uncertainty
        self._sorted = False

    def to_json_dict(self):
        return NotImplemented

    def __len__(self) -> int:
        return len(self.data)

    @property
    def sorted(self) -> bool:
        return self._sorted
