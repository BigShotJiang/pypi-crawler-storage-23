from __future__ import annotations

from dcc_quantities._helpers import parse_attributes, unexpected_key_serialization_handler


class DccContent:
    def __init__(self, string, lang=None, identifier=None, ref_id=None, ref_type=None) -> None:
        self.string = string
        self.lang = lang
        self.id = identifier
        self.ref_id = ref_id
        self.ref_type = ref_type

    def to_json_dict(self) -> dict:
        key_mapping = {"lang": "@lang", "id": "@id", "ref_id": "@refId", "ref_type": "@refType"}
        result = {"$": self.string}
        for key, value in self.__dict__.items():
            if key == "string":
                continue
            if value not in [None, [None]]:
                if key in key_mapping:
                    result[key_mapping[key]] = value
                else:
                    unexpected_key_serialization_handler(result, key, value, self.__class__.__name__)
        return result


def parse_dcc_content(json_dict):
    if isinstance(json_dict, dict):
        dcc_content_args = parse_attributes(json_dict=json_dict)
        dcc_content_args["string"] = json_dict["$"]
    elif isinstance(json_dict, str):
        dcc_content_args = {"string": json_dict}
    return DccContent(**dcc_content_args)
