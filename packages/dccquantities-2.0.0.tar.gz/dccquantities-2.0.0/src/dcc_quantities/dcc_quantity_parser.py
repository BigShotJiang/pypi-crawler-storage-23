import warnings
from contextlib import contextmanager

from dccXMLJSONConv.dccConv import XMLToDict

from dcc_quantities._config import dcc_config
from dcc_quantities._helpers import parse_attributes, replace_quantities_in_dict
from dcc_quantities.dcc_chars_xml_list import parse as parse_chars_xml_list
from dcc_quantities.dcc_no_quantity import parse as parse_dcc_no_quantity
from dcc_quantities.dcc_quantity_type import DccQuantityType
from dcc_quantities.serializers.dcc_element_key import DccElementKey
from dcc_quantities.serializers.dcc_element_parser import dcc_type_collector
from dcc_quantities.si_hybrid import parse as parse_si_hybrid
from dcc_quantities.si_real_list import parse_const, parse_real_list_xml_list, parse_si_real_value

_SUPPORTED_XML_KEYS = {
    "@id",
    "@refId",
    "@refType",
    "dcc:name",
    "dcc:description",
    "dcc:relative_uncertainty",
    "si:real",
    "dcc:noQuantity",
    "si:realListXMLList",
    "dcc:charsXMLList",
    "si:hybrid",
    "si:constant",
    "dcc:usedMethods",
    "dcc:usedSoftware",
    "dcc:measuringEquipments",
    "dcc:influenceConditions",
    "dcc:measurementMetaData",
    "@_Comment",
}


def parse(xml_str: str):
    json_dict, _ = XMLToDict(xml_str)
    quantity_dict = dcc_type_collector(json_dict, search_keys=[DccElementKey.QUANTITY])
    dcc_quantity_type_objects = []
    for _, item in quantity_dict:
        dcc_quantity_type_objects.append(parse_item_from_json_dict(item))
    return dcc_quantity_type_objects


@contextmanager
def _warning_capture(enabled: bool):
    """
    Context manager that captures all warnings if `enabled` is True, otherwise does nothing.
    Yields a list of warnings.WarningMessage or None.
    """
    if enabled:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            yield caught
    else:
        yield None


def parse_item_from_json_dict(item_json_dict: dict) -> DccQuantityType:
    """
    Parse an item JSON-dict into a DccQuantityType.
    Captures actual warnings.WarningMessage objects in .self_warnings if dcc_configuration.record_warnings is True.
    """
    if isinstance(item_json_dict, DccQuantityType):
        return item_json_dict
    record = getattr(dcc_config, "record_warnings", False)
    with _warning_capture(record) as caught_warnings:
        for key, element in list(item_json_dict.items()):
            if isinstance(element, list) and len(element) == 1:
                item_json_dict[key] = element[0]
        quantity_args = parse_attributes(item_json_dict)
        if "dcc:name" in item_json_dict:
            try:
                quantity_args["name"] = {d["@lang"]: d["$"] for d in item_json_dict["dcc:name"]["dcc:content"]}
            except KeyError as err:
                raise ValueError("[XML Schema Violation]: Property 'dcc:content' not found within 'dcc:name'") from err
        if "dcc:description" in item_json_dict:
            quantity_args["description"] = item_json_dict["dcc:description"]
        relative_uncertainty = None
        if "dcc:relative_uncertainty" in item_json_dict:
            rel = item_json_dict["dcc:relative_uncertainty"]
            relative_uncertainty = {}
            if "dcc:relative_uncertaintyXmlList" in rel:
                lu = rel["dcc:relative_uncertaintyXmlList"]
                relative_uncertainty["uncertainty"] = lu.get("si:valueXMLList", [])
                relative_uncertainty["unit"] = lu.get("si:unitXMLList", [])
            elif "dcc:relative_uncertaintySingle" in rel:
                single = rel["dcc:relative_uncertaintySingle"]
                relative_uncertainty["uncertainty"] = [single["si:value"]["$"]]
                relative_uncertainty["unit"] = [single["si:unit"]["$"]]
        if "si:real" in item_json_dict:
            quantity_args["data"] = parse_si_real_value(
                json_dict=item_json_dict["si:real"], relative_uncertainty=relative_uncertainty
            )
        elif "dcc:noQuantity" in item_json_dict:
            quantity_args["data"] = parse_dcc_no_quantity(json_dict=item_json_dict["dcc:noQuantity"])
        elif "si:realListXMLList" in item_json_dict:
            quantity_args["data"] = parse_real_list_xml_list(
                json_dict=item_json_dict["si:realListXMLList"], relative_uncertainty=relative_uncertainty
            )
        elif "dcc:charsXMLList" in item_json_dict:
            quantity_args["data"] = parse_chars_xml_list(json_dict=item_json_dict["dcc:charsXMLList"])
        elif "si:hybrid" in item_json_dict:
            quantity_args["data"] = parse_si_hybrid(
                json_dict=item_json_dict["si:hybrid"], relative_uncertainty=relative_uncertainty
            )
        elif "si:constant" in item_json_dict:
            quantity_args["data"] = parse_const(
                json_dict=item_json_dict["si:constant"], relative_uncertainty=relative_uncertainty
            )
        if "dcc:usedMethods" in item_json_dict:
            quantity_args["used_methods"] = replace_quantities_in_dict(
                json_dict=item_json_dict["dcc:usedMethods"], parser=parse_item_from_json_dict
            )
        if "dcc:usedSoftware" in item_json_dict:
            quantity_args["used_software"] = replace_quantities_in_dict(
                json_dict=item_json_dict["dcc:usedSoftware"], parser=parse_item_from_json_dict
            )
        if "dcc:measuringEquipments" in item_json_dict:
            quantity_args["measuring_equipments"] = replace_quantities_in_dict(
                json_dict=item_json_dict["dcc:measuringEquipments"], parser=parse_item_from_json_dict
            )
        if "dcc:influenceConditions" in item_json_dict:
            quantity_args.setdefault(
                "measuring_equipments",
                replace_quantities_in_dict(
                    json_dict=item_json_dict["dcc:influenceConditions"], parser=parse_item_from_json_dict
                ),
            )
        if "dcc:measurementMetaData" in item_json_dict:
            quantity_args["measurement_meta_data"] = replace_quantities_in_dict(
                json_dict=item_json_dict["dcc:measurementMetaData"], parser=parse_item_from_json_dict
            )
        unsupported_keys_found = [key for key in item_json_dict if key not in _SUPPORTED_XML_KEYS]
        if len(unsupported_keys_found) > 0:
            msg = "Unsupported keys for dcc:quantity:\n\t-" + "\n\t-".join(unsupported_keys_found)
            warnings.warn(msg, RuntimeWarning, stacklevel=2)
        if "id" in quantity_args:
            quantity_args["identifier"] = quantity_args.pop("id")
        instance = DccQuantityType(**quantity_args)
    if record:
        warning_map = {}
        for w in caught_warnings or []:
            key = str(w.message)
            if key in warning_map:
                warning_map[key][1] += 1
            else:
                warning_map[key] = [w, 1]
        if len(warning_map) > 0:
            instance._warnings = [(warn, count) for warn, count in warning_map.values()]
    return instance
