from __future__ import annotations

import math
import warnings
from typing import Optional

from metas_unclib import UniformDistribution, ufloat, ufloatfromdistribution

from dcc_quantities._config import CoverageProbabilityMissmatchBehavior, dcc_config

uncertainty_keys = [
    "si:expandedUnc",
    "si:coverageInterval",
    "si:expandedUncXMLList",
    "si:coverageIntervalXMLList",
    "si:ellipsoidalRegionXMLList",
    "si:rectangularRegionXMLList",
    "si:measurementUncertaintyUnivariate",
    "si:measurementUncertaintyUnivariateXMLList",
]

_NORMAL_DIST_NAMES = {"normal", "gauss", "gau", "gauß"}
_UNIFORM_DIST_NAMES = {"rectangular", "uniform", "rect", "rectangle"}


def parse_uncertainties(json_dict: dict, data: list, relative_uncertainty: Optional[dict] = None):
    if (
        "si:expandedUnc" in json_dict
        or "si:expandedUncXMLList" in json_dict
        or (
            "si:measurementUncertaintyUnivariate" in json_dict
            or "si:measurementUncertaintyUnivariateXMLList" in json_dict
        )
    ):
        data_with_unc, extra_unc_info = parse_expanded_unc(
            json_dict=json_dict, data=data, relative_uncertainty=relative_uncertainty
        )
    elif not any((uncKey in json_dict for uncKey in uncertainty_keys)) and relative_uncertainty:
        data_with_unc = parse_relative_unc(data=data, relative_uncertainty=relative_uncertainty)
        extra_unc_info = {}
    else:
        warnings.warn("no uncertainty parsed, returning the same data you gave me!", RuntimeWarning, stacklevel=2)
        data_with_unc = data
        extra_unc_info = {}
    return data_with_unc, extra_unc_info


def parse_expanded_unc(json_dict: dict, data: list, relative_uncertainty: Optional[dict] = None):
    unc_data = {}
    if "si:expandedUnc" in json_dict:
        unc_json_data = json_dict["si:expandedUnc"]
        unc_data["uncertainty"] = unc_json_data["si:uncertainty"]
        unc_data["coverageFactor"] = unc_json_data["si:coverageFactor"]
        unc_data["coverage_probability"] = unc_json_data["si:coverageProbability"]
        unc_data["distribution"] = unc_json_data.get("si:distribution", ["normal"])
    elif "si:expandedUncXMLList" in json_dict:
        unc_json_data = json_dict["si:expandedUncXMLList"]
        unc_data["uncertainty"] = unc_json_data["si:uncertaintyXMLList"]
        unc_data["coverageFactor"] = unc_json_data["si:coverageFactorXMLList"]
        unc_data["coverage_probability"] = unc_json_data["si:coverageProbabilityXMLList"]
        unc_data["distribution"] = unc_json_data.get("si:distributionXMLList", ["normal"])
    elif "si:measurementUncertaintyUnivariate" in json_dict:
        unc_json_data = json_dict["si:measurementUncertaintyUnivariate"]["si:expandedMU"]
        unc_data["uncertainty"] = unc_json_data["si:valueExpandedMU"]
        unc_data["coverageFactor"] = unc_json_data["si:coverageFactor"]
        unc_data["coverage_probability"] = unc_json_data["si:coverageProbability"]
        unc_data["distribution"] = unc_json_data.get("si:distribution", ["normal"])
    elif "si:measurementUncertaintyUnivariateXMLList" in json_dict:
        try:
            unc_json_data = json_dict["si:measurementUncertaintyUnivariateXMLList"]["si:expandedMUXMLList"]
            unc_data["uncertainty"] = unc_json_data["si:valueExpandedMUXMLList"]
            unc_data["coverageFactor"] = unc_json_data["si:coverageFactorXMLList"]
            unc_data["coverage_probability"] = unc_json_data["si:coverageProbabilityXMLList"]
            unc_data["distribution"] = unc_json_data.get("si:distributionXMLList", ["normal"])
        except KeyError as err:
            raise NotImplementedError(
                "Uncertanty for Keys "
                + str(json_dict["si:measurementUncertaintyUnivariateXMLList"].keys())
                + " is not implemented yet"
            ) from err
    extra_unc_info = {}
    data_with_unc = []
    distribution = ""
    if unc_data:
        for key in ["uncertainty", "coverageFactor", "coverage_probability", "distribution"]:
            if not isinstance(unc_data[key], list):
                unc_data[key] = [unc_data[key]]

        def get_value(lst, idx):
            return lst[0] if len(lst) == 1 else lst[idx]

        for key in ["uncertainty", "coverageFactor", "coverage_probability", "distribution"]:
            if len(unc_data[key]) not in {1, len(data)}:
                raise RuntimeError(f"Length of {key} does not match data: {json_dict}")
        unc_already_checked = False
        store_original_unc_data = False
        if (len(unc_data["coverageFactor"]) <= 1 or len(unc_data["coverage_probability"]) <= 1) and len(
            unc_data["distribution"]
        ) == 1:
            k_factor = unc_data["coverageFactor"][0]
            cov_prob = unc_data["coverage_probability"][0]
            dist_value = unc_data["distribution"][0]
            distribution = get_distribution_type(dist_value)
            cov_prob, k_factor = handle_coverage_params(cov_prob, k_factor, distribution)
            unc_already_checked = True
            extra_unc_info["coverageFactor"] = [k_factor]
            extra_unc_info["coverage_probability"] = [cov_prob]
            extra_unc_info["distribution"] = [distribution]
            if dcc_config.storeOriginalUncerForNonIntK and not k_factor.is_integer():
                store_original_unc_data = True
        elif dcc_config.storeOriginalUncerForNonIntK:
            store_original_unc_data = False
            for k_factor_from_list in unc_data["coverageFactor"]:
                if not k_factor_from_list.is_integer():
                    store_original_unc_data = False
        for i in range(len(data)):
            data_item = data[i]
            unc_item = get_value(unc_data["uncertainty"], i)
            if store_original_unc_data and i == 0:
                extra_unc_info["originalUnc"] = [unc_item]
            if store_original_unc_data and i != 0:
                extra_unc_info["originalUnc"].append(unc_item)
            if not unc_already_checked:
                k_factor = get_value(unc_data["coverageFactor"], i)
                cov_prob = get_value(unc_data["coverage_probability"], i)
                dist_value = get_value(unc_data["distribution"], i)
                distribution = get_distribution_type(dist_value)
                cov_prob, k_factor = handle_coverage_params(cov_prob, k_factor, distribution)
                if i == 0:
                    extra_unc_info["coverageFactor"] = [k_factor]
                    extra_unc_info["coverage_probability"] = [cov_prob]
                    extra_unc_info["distribution"] = [distribution]
                else:
                    extra_unc_info["coverageFactor"].append(k_factor)
                    extra_unc_info["coverage_probability"].append(cov_prob)
                    extra_unc_info["distribution"].append(distribution)
            if distribution == "normal":
                abs_unc_item = abs(unc_item) / k_factor
                data_with_unc.append(ufloat(data_item, abs_unc_item))
            elif distribution == "uniform":
                effective_a = 1.0 if abs(k_factor - 1.73) < 0.002 else abs(unc_item) * math.sqrt(3) / k_factor
                lower_bound = data_item - effective_a
                upper_bound = data_item + effective_a
                distribution_obj = UniformDistribution(lower_bound, upper_bound)
                data_with_unc.append(ufloatfromdistribution(distribution_obj))
            else:
                warnings.warn(
                    "This uncertainty representation is not supported yet! Proceeding with no uncertainty.",
                    RuntimeWarning,
                    stacklevel=2,
                )
                raise NotImplementedError
        if relative_uncertainty:
            if not isinstance(relative_uncertainty["uncertainty"], list):
                relative_uncertainty["uncertainty"] = [relative_uncertainty["uncertainty"]]
            if len(relative_uncertainty["uncertainty"]) not in {1, len(data)}:
                raise RuntimeError("Relative uncertainty length mismatch")
            rel_unc_list = (
                relative_uncertainty["uncertainty"]
                if len(relative_uncertainty["uncertainty"]) == len(data)
                else relative_uncertainty["uncertainty"] * len(data)
            )
            abs_unc_from_rel_unc = []
            for rel_unc, value in zip(rel_unc_list, data):
                abs_unc_from_rel_unc.append(rel_unc * value)
            for given_abs_unc, computed_abs_unc in zip(unc_data["uncertainty"], abs_unc_from_rel_unc):
                if not math.isclose(given_abs_unc, computed_abs_unc, rel_tol=0.001):
                    warnings.warn(
                        "Absolute uncertainties given and computed "
                        "from relative uncertainty do not match! Proceeding "
                        "with given abs uncertainty",
                        RuntimeWarning,
                        stacklevel=2,
                    )
    return data_with_unc, extra_unc_info


def parse_relative_unc(data: list, relative_uncertainty: dict):
    if len(relative_uncertainty["uncertainty"]) == 1:
        relative_uncertainty["uncertainty"] *= len(data)
    if len(relative_uncertainty["uncertainty"]) == len(data):
        abs_unc_from_rel_unc = [relUnc * value for relUnc, value in zip(relative_uncertainty["uncertainty"], data)]
        data_with_unc = [ufloat(dataItem, abs(uncItem)) for dataItem, uncItem in zip(data, abs_unc_from_rel_unc)]
    else:
        raise RuntimeError(f"Length of uncertainty does not match data: relUnc: {relative_uncertainty}, data: {data}")
    return data_with_unc


def get_distribution_type(name: str) -> Optional[str]:
    """Gets the distribution type based on the name of the distribution.

    Parameters
    ----------
    name : str
        A distribution id (e.g., 'normal', 'Gauss', 'uniform', etc.)

    Returns
    -------
    distribution_type : str | None
        Either "normal" if the input matches any synonyms for a normal distribution, "uniform" if it matches any
        synonyms for a uniform/rectangular distribution, or NoneType.
    """
    normalized = str(name).strip().lower()
    distribution_type = None
    if normalized in _NORMAL_DIST_NAMES:
        distribution_type = "normal"
    elif normalized in _UNIFORM_DIST_NAMES:
        distribution_type = "uniform"
    return distribution_type


def handle_coverage_params(coverage_probability, k_factor, distribution):
    """
    Calculate and check coverageProbability and k_factor for normal and uniform distributions.

    For normal distributions:
      - If k_factor is provided, compute coverage_probability=erf(k_factor/√2).
      - If only coverageProbability is provided, compute k_factor = √2 * erfinv(coverageProbability).
      - If both are provided, recalc coverageProbability from k_factor (priority to k_factor)
        and ensure the mismatch is within dcc_configuration.allowedCoverageProbabilityMissmatch.
      - If a missmatch occures either a warning is generated and given k is used
      (DccConfiguration.CoverageProbabilityMissmatchBehavior.WARNING_TAKE_K_VALUE)
        or and Exception is raised DccConfiguration.CoverageProbabilityMissmatchBehavior.EXCEPTION

    For uniform distributions:
      - If k_factor is provided:
            computed_cov = (k_factor/√3 + 1)/2 if k_factor <= √3, else computed_cov = 1.0.
      - If only coverageProbability is provided, compute k_factor = √3*(2*coverageProbability - 1).
      - If both are provided, compute computed_cov and check against the provided coverageProbability.

    Parameters
    ----------
        coverageProbability (float or None): The provided coverage probability.
        k_factor (float or None): The provided coverage factor.
        distribution (str): "normal" or "uniform".

    Returns
    -------
        tuple: (coverageProbability, k_factor) after calculation/validation.

    Raises
    ------
        ValueError: If neither parameter is provided or if the provided values are inconsistent.
    """
    key = distribution if distribution in dcc_config.allowedCoverageProbabilityMissmatch else "default"
    allowed = dcc_config.allowedCoverageProbabilityMissmatch.get(key)
    if distribution == "normal":
        if k_factor is not None:
            computed_cov = math.erf(k_factor / math.sqrt(2))
            if coverage_probability is None:
                coverage_probability = computed_cov
            elif abs(coverage_probability - computed_cov) > allowed:
                if dcc_config.coverageProbabilityMissmatchBehavior is CoverageProbabilityMissmatchBehavior.EXCEPTION:
                    raise ValueError(
                        "Normal distribution mismatch: "
                        f"provided coverageProbability {coverage_probability} vs computed {computed_cov}"
                    )
                if (
                    dcc_config.coverageProbabilityMissmatchBehavior
                    is CoverageProbabilityMissmatchBehavior.WARNING_TAKE_K_VALUE
                ):
                    warnings.warn(
                        f"Normal distribution mismatch: provided coverageProbability {coverage_probability} "
                        f"vs computed {computed_cov} using k value for further calculations."
                        "Since dcc_configuration.CoverageProbabilityMissmatchBehavior.WARNING_TAKE_K_VALUE set",
                        RuntimeWarning,
                        stacklevel=2,
                    )
                    return computed_cov, k_factor
        elif coverage_probability is not None:
            k_factor = math.sqrt(2) * math.erfinv(coverage_probability)
        else:
            raise ValueError(
                "For normal distribution, at least one of coverageProbability or k_factor must be provided."
            )
        return coverage_probability, k_factor
    if distribution == "uniform":
        if k_factor is not None:
            computed_cov = (k_factor / math.sqrt(3) + 1) / 2 if k_factor <= math.sqrt(3) else 1.0
            if coverage_probability is None:
                coverage_probability = computed_cov
            elif abs(coverage_probability - computed_cov) > allowed:
                if dcc_config.coverageProbabilityMissmatchBehavior is CoverageProbabilityMissmatchBehavior.EXCEPTION:
                    raise ValueError(
                        f"Normal distribution mismatch: provided coverageProbability"
                        f" {coverage_probability} vs computed {computed_cov}"
                    )
                if (
                    dcc_config.coverageProbabilityMissmatchBehavior
                    is CoverageProbabilityMissmatchBehavior.WARNING_TAKE_K_VALUE
                ):
                    warnings.warn(
                        f"Normal distribution mismatch: provided coverageProbability {coverage_probability}"
                        f" vs computed {computed_cov} using k value for further calculations. Since "
                        "dcc_configuration.CoverageProbabilityMissmatchBehavior.WARNING_TAKE_K_VALUE is set",
                        RuntimeWarning,
                        stacklevel=2,
                    )
                    return computed_cov, k_factor
        elif coverage_probability is not None:
            k_factor = math.sqrt(3) * (2 * coverage_probability - 1)
        else:
            raise ValueError(
                "For uniform distribution, at least one of coverageProbability or k_factor must be provided."
            )
        return coverage_probability, k_factor
    raise ValueError(f"Unsupported distribution type. >>{distribution!s}<<")
