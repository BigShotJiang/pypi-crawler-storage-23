from __future__ import annotations

import warnings
from typing import Any, Optional

from dcc_quantities._abc import AbstractQuantityTypeData
from dcc_quantities._helpers import parse_attributes, unexpected_key_serialization_handler
from dcc_quantities.dcc_lang_name import DccLangName
from dcc_quantities.dcc_rich_content_type import parse_dcc_content
from dcc_quantities.serializers.dcc_element_parser import dcc_type_collector


class DccNoQuantity(AbstractQuantityTypeData):
    def __init__(
        self,
        data: str | list[dict[str, Any]],
        identifier: Optional[str] = None,
        ref_id: Optional[list[str]] = None,
        ref_type: Optional[list[str]] = None,
        name: Optional[dict] = None,
    ) -> None:
        super().__init__()
        self.data = data
        self.id = identifier
        self.ref_id = ref_id
        self.ref_type = ref_type
        self.name = DccLangName(name)
        self._sorted = False

    def __len__(self) -> int:
        return len(self.data["content"]) + len(self.data["file"]) + len(self.data["formula"])

    def to_json_dict(self) -> dict:
        private_keys = ["_sorted"]
        key_mapping = {"id": "@id", "ref_id": "@refId", "ref_type": "@refType"}
        data_key_mapping = {"content": "dcc:content", "file": "dcc:file", "formula": "dcc:formula"}
        result = {}
        for key, value in self._iter_items():
            if value is None or key in private_keys:
                continue

            if key in key_mapping:
                result[key_mapping[key]] = value
            elif key == "data":
                for data_key, data_value in self.data.items():
                    if isinstance(data_value, list) and len(data_value) > 0:
                        result[data_key_mapping[data_key]] = []
                        for item in data_value:
                            result[data_key_mapping[data_key]].append(item.to_json_dict())
                if set(self.data) - set(data_key_mapping):
                    pass
            else:
                unexpected_key_serialization_handler(result, key, value, self.__class__.__name__)
        return {"dcc:noQuantity": result}

    @property
    def sorted(self) -> bool:
        return self._sorted


def parse(json_dict) -> DccNoQuantity:
    dcc_no_quantity_args = parse_attributes(json_dict=json_dict)
    if "dcc:name" in json_dict:
        dcc_no_quantity_args["name"] = json_dict["dcc:name"]
    dcc_no_quantity_data = {}
    dcc_content_results = []
    for result in dcc_type_collector(dcc_data=json_dict, search_keys=["dcc:content"]):
        dcc_content_results.append(parse_dcc_content(result[1]))
    dcc_no_quantity_data["content"] = dcc_content_results
    dcc_file_results = []
    dcc_no_quantity_data["file"] = dcc_file_results
    dcc_formula_results = []
    dcc_no_quantity_data["formula"] = dcc_formula_results
    dcc_no_quantity_args["data"] = dcc_no_quantity_data
    for key in json_dict:
        if key not in {"dcc:name", "dcc:content", "dcc:file", "dcc:formula", "@_Comment"}:
            warnings.warn(f"Unsupported key for dcc:noQuantity: {key}", RuntimeWarning, stacklevel=2)
    return DccNoQuantity(**dcc_no_quantity_args)
