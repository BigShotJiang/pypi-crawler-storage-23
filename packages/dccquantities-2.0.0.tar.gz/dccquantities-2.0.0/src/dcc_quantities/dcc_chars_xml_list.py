from __future__ import annotations

import warnings
from typing import Any

from dcc_quantities._abc import AbstractQuantityTypeData


class DccCharsXMLList(AbstractQuantityTypeData):
    # Todo: Add following behaviors.
    #  * '__iter__' method

    def __init__(self, data: list[str]):
        super().__init__()
        self.data = data

    def __len__(self) -> int:
        return len(self.data)

    def __add__(self, other):
        if isinstance(other, DccCharsXMLList):
            return DccCharsXMLList(data=self.data + other.data)
        if isinstance(other, list):
            warnings.warn("Concatenating DccCharsXMLList and list!", RuntimeWarning, stacklevel=2)
            return DccCharsXMLList(data=self.data + other)
        raise TypeError(f"unsupported operand for +: '{type(self).__name__}' and '{type(other).__name__}'")

    def __radd__(self, other):
        if isinstance(other, DccCharsXMLList):
            return DccCharsXMLList(data=other.data + self.data)
        if isinstance(other, list):
            warnings.warn("Concatenating DccCharsXMLList and list!", RuntimeWarning, stacklevel=2)
            return DccCharsXMLList(data=other + self.data)
        raise TypeError(f"unsupported operand for +: '{type(other).__name__}' and '{type(self).__name__}'")

    def to_json_dict(self) -> dict[str, Any]:
        return {"dcc:charsXMLList": self.data}

    @property
    def sorted(self) -> bool:
        if self._sorted is None:
            self._sorted = all((self.data[i] <= self.data[i + 1] for i in range(len(self.data) - 1)))
        "Check if the list of strings is sorted in ascending order."
        return self._sorted


def parse(json_dict: dict | list) -> DccCharsXMLList:
    if isinstance(json_dict, list):
        return DccCharsXMLList(data=json_dict)
    if isinstance(json_dict, dict):
        raise NotImplementedError("DccCharsXMLList.parse() is not implemented.")
    return DccCharsXMLList(data=json_dict)
