"""
The `dcc_lang_name` module defines a class to support XML contents that allow some type of text in different
languages.
For example, the label `<dcc:name>` allows defining names in different languages.
"""

from __future__ import annotations

import contextlib
from collections import UserDict
from typing import Any, Union

from dcc_quantities._config import dcc_config


class DccLangName(UserDict):
    """A mapping containing any XML label information that supports multiple languages.

    `DccLangName` allows string representation by the `str()` call. This representation displays a single name, no
    matter how many languages are contained within the instance. The selected name is based on the current system
    language.

    Only the names contained in the instance can be displayed, even if they don't match the system language. The
    priority level to display a name is displaying:

    - The name that matches with the system language.
    - The name in English.
    - The first found name, no matter the language.
    - The tag '<No Name>' if the instance does not contain any name tag.

    Examples
    --------
    The DccLangName <code>{'de': 'X deutscher Name', 'en': 'X English Name'}</code> is analogous to the following
    XML code:
    ```
    <dcc:name>
        <dcc:content lang="de">X deutscher Name</dcc:content>
        <dcc:content lang="en">X English Name</dcc:content>
    </dcc:name>
    ```

    Assuming the system language is English, the string representation is then displayed as following:
    ```pycon
    >>> names = DccLangName({'de': 'X deutscher Name', 'en': 'X English Name'})
    >>> str(names)
    X English Name
    ```
    """

    def __init__(self, content: dict[str, dict[str, Any]]):
        """

        Parameters
        ----------
        content : dict
            Information about the names and the languages they are written. This content can be provided in either
            of the following structures:
            <ol>
                <li>A python dictionary, where the keys are the languages and the values are the names. E.G.:
            <code>{'de': 'X deutscher Name', 'en': 'X English Name'}</code></li>
                <li>An DCC structured dictionary, analogous to the dictionary obtained though the
            <code>.to_json_dict()</code> method</li>
            </ol>
        """
        with contextlib.suppress(KeyError):
            content = content["dcc:name"]
        if "dcc:content" in content:
            parsed_dict = {}
            for item in content["dcc:content"]:
                parsed_dict[item["@lang"]] = item["$"]
        else:
            parsed_dict = content
        super().__init__(parsed_dict)

    def __new__(cls, *args, **kwargs):
        if not args or args[0] is None:
            return None
        if len(args) == 1 and isinstance(args[0], DccLangName):
            return args[0]
        return super().__new__(cls)

    def __repr__(self) -> str:
        """Representation of the instance's constructor with the current data."""
        return f"DccLangName({dict(self)})"

    def __str__(self) -> str:
        """Representation of the name in a JSON format.

        Example
        -------
        Considering the DccLangName:
            {'de': 'X deutscher Name', 'en': 'X English Name'}
        The representation in English corresponds to:
            '🇪🇳 X English Name'
        """
        if dcc_config.reprStyle == "lib_debug":
            return super().__repr__()
        for lang in dcc_config.preferredLangs:
            if lang in self:
                return f"{self[lang]}"
        first_key = next(iter(self), None)
        return f"{first_key}: {self[first_key]}" if first_key else "<No Name>"

    @property
    def in_use_language_tag(self) -> str:
        """The short representation of the used language tag (EN, DE, etc.) when the 'str' method is called."""
        if len(self) == 0:
            return None
        return str(self).split(": ")[0]

    def matches(self, other: Union[DccLangName, str]) -> bool:
        """Check whether a name is contained within the mapping or if the new provided mapping is a subset of the
        current one.

        Parameters
        ----------
        other :
            Another `DccLangName`, or a string of the name to be matched.

        Examples
        --------
        ```pycon
        >>> names = DccLangName({"en": "Frequency", "de": "Frequenz", "fr": "Fréquence"})
        >>> names.matches("Frequency")
        True  # The name 'Frequency' is contained wihtin the `names` instance.
        >>> names.matches("Speed")
        False  # The name 'Speed' is not within `names`.
        >>> names.matches({"en": "Frequency", "de": "Frequenz"})
        True  # The provided dictionary is a subset of the `names` instance.
        >>> names.matches({"en": "Frequency", "it": "Frequenza"})
        False  # The provided dictionary is not a subset of the `names` instance.
        ```
        """
        if isinstance(other, (dict, DccLangName)):
            return all(key in self and self[key] == value for key, value in other.items())
        if isinstance(other, str):
            return other in self.values()
        raise TypeError(f"Unsupported type {type(other)} for matching")

    def to_json_dict(self) -> dict:
        """Class representations as a JSON dict with the same keys as required for the XML code.

        Returns
        -------
        This method structures all names into the DCC schema. For the `<dcc:name>` this means that a hierarchycal
        dictionary is created, with the top level as a single key `'dcc:name'`, followed at the second level
        by the key `'dcc:content'` providing an iterable (list) with all the names and their languages.

        Examples
        --------
        Considering the previous example case:
        ```pycon
        >>> names.to_json_dict()
        {'dcc:name': {
            'dcc:content': [
                    {'@lang': 'de', '$': 'X deutscher Name'},
                    {'@lang': 'en', '$': 'X English Name'}
                ]
            }
        }
        ```
        """
        return {"dcc:name": {"dcc:content": [{"@lang": key, "$": value} for key, value in self.items()]}}

    # TODO: Discuss whether the following commented code is really needed, considering new quantities do not
    #   update the name field (it is returned as empty).

    # def _merge_names(self, insertion: str, other: DccLangName | str | float | int):
    #     """Merges two DccLangName instances or a DccLangName with another type, handling None gracefully."""
    #     merged = {}
    #     if not isinstance(other, DccLangName):
    #         try:
    #             other = other.name
    #         except AttributeError:
    #             other = {lang: str(other) for lang in self}
    #     for lang in self:
    #         if lang in other:
    #             merged[lang] = f"{self[lang]} {insertion} {other[lang]}"
    #     if not merged:
    #         warnings.warn(
    #             "No matching language found; using first available language as fallback.", RuntimeWarning,
    #             stacklevel=2
    #         )
    #         first_key = next(iter(other), None)
    #         if first_key:
    #             return {first_key: f"{first_key}: {other[first_key]}"}
    #         raise ValueError("Error in name generation; neither left nor right operand had valid names.")
    #     return merged

    # def __add__(self, other: Union[DccLangName, str, float, int]) -> DccLangName:
    #     return DccLangName(self._merge_names("+", other))
    #
    # def __sub__(self, other: Union[DccLangName, str, float, int]) -> DccLangName:
    #     return DccLangName(self._merge_names("-", other))
    #
    # def __mul__(self, other: Union[DccLangName, str, float, int]) -> DccLangName:
    #     return DccLangName(self._merge_names("*", other))
    #
    # def __truediv__(self, other: Union[DccLangName, str, float, int]) -> DccLangName:
    #     return DccLangName(self._merge_names("/", other))
    #
    # def __radd__(self, other: Union[DccLangName, str, float, int]) -> DccLangName:
    #     return DccLangName(self._merge_names("+", other))
    #
    # def __rsub__(self, other: Union[DccLangName, str, float, int]) -> DccLangName:
    #     return DccLangName(self._merge_names("-", other))
    #
    # def __rmul__(self, other: Union[DccLangName, str, float, int]) -> DccLangName:
    #     return DccLangName(self._merge_names("*", other))
    #
    # def __rtruediv__(self, other: Union[DccLangName, str, float, int]) -> DccLangName:
    #     return DccLangName(self._merge_names("/", other))
    #
    # def __neg__(self) -> DccLangName:
    #     return DccLangName({lang: f"-{name}" for lang, name in self.items()})
    #
    # def __pos__(self) -> DccLangName:
    #     return DccLangName({lang: f"+{name}" for lang, name in self.items()})
    #
    # def __pow__(self, other: Union[DccLangName, str, float, int]) -> DccLangName:
    #     return DccLangName(self._merge_names("**", other))
