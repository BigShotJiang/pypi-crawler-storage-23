"""Module containing all table related classes.

It is expected for the default case to read a table from an XML to use the
[`DccQuantityTable`][dcc_quantities.dcc_quantity_table.DccQuantityTable] class. This call will return the
corresponding [`DccFlatTable`][dcc_quantities.dcc_quantity_table.DccFlatTable] or
[`DccLongTable`][dcc_quantities.dcc_quantity_table.DccLongTable] instance.
"""

# fixme:
#   Many docstrings have been commented for them not to appear at the documentation. All methods with commented
#   docstrings have not been tested nor optimized for their use, and many are not being correctly tested.

from __future__ import annotations

import contextlib
import math
import re
import uuid
import warnings
from typing import TYPE_CHECKING, Any, ClassVar, Literal, Optional

import numpy as np
from dccXMLJSONConv.dccConv import DictToXML
from dsi_unit import DsiUnit

from dcc_quantities._helpers import (
    evaluate_query,
    get_exact_slice,
    get_nearest_slice,
    replace_quantities_in_dict,
    slice_and,
)
from dcc_quantities.dcc_lang_name import DccLangName
from dcc_quantities.dcc_quantity_parser import parse_item_from_json_dict
from dcc_quantities.query import to_slice
from dcc_quantities.serializers._explicit_serializer_mixin import ExplicitSerializerMixin
from dcc_quantities.serializers._field_spec import FieldSpec
from dcc_quantities.serializers.dcc_element_key import DccElementKey
from dcc_quantities.serializers.dcc_element_parser import dcc_type_collector

if TYPE_CHECKING:
    import datetime

    from dcc_quantities.dcc_quantity_type import DccQuantityType


def _match_table_pattern(ref_types: list[str], pattern: str) -> bool:
    """Matches whether a pattern (not case-sensitive) is found in a list of refType"""
    pattern = re.compile(pattern, re.IGNORECASE)
    return any(pattern.fullmatch(ref) for ref in ref_types)


def _get_basic_index_dimension_from_ref_types(ref_types: list[str]) -> Optional[int]:
    """
    Given a list of refType strings, this function searches for those that match
    the pattern 'basic_tableIndex([0-9])' (with or without parentheses).

    Returns
    -------
    int
        The numeric dimension as an integer if exactly one match is found.
        None if no match is found.

    Raises
    ------
    ValueError
        If more than one string in the list matches the pattern.
    """
    # if ref_types is None or ref_types == [None]:
    #     return None
    if isinstance(ref_types, str):
        warnings.warn("refTypes was not a List", RuntimeWarning, stacklevel=2)
        ref_types = ref_types.split()
    pattern = re.compile(r"^basic_(?:Flat)?tableindex(?:\((\d+)\)|(\d+))$", re.IGNORECASE)
    matches = []
    for s in ref_types:
        if match := pattern.match(s):
            matches.append(match)
    if len(matches) == 0:
        return None
    if len(matches) > 1:
        raise ValueError("More than one refType matches the pattern ^basic_(\\d+)IndexTable$.")
    m = matches[0]
    index_str = m.group(1) if m.group(1) is not None else m.group(2)
    return int(index_str)


class DccQuantityTable(ExplicitSerializerMixin):
    """Generic Table class for Flat- and Long-Tables."""

    def __init__(
        self,
        idx_quants: dict[str | int, DccQuantityType],
        value_quants: list[DccQuantityType],
        dimension_len: Optional[int] = None,
        identifier: Optional[str] = None,
        ref_id: Optional[str] = None,
        ref_type: Optional[list[str]] = None,
        name: DccLangName = None,
        date_time: Optional[datetime.datetime] = None,
        description: Optional[dict] = None,
        used_methods: Optional[dict] = None,
        used_software: Optional[dict] = None,
        measuring_equipments: Optional[dict] = None,
        influence_conditions: Optional[dict] = None,
        measurement_meta_data: Optional[dict] = None,
    ):
        """

        Parameters
        ----------
        idx_quants
            Mapping from a numerical index to an index quantity. These correspond to the quantities that define the
            dimensions of the table.
        value_quants
            Sequence of all `DccQuantityType` instances that complete the values of the table.
        ref_type
            Sequence of all refTypes corresponding to the Flat- or Long-Table.
        dimension_len
            Table parameter defining the number of dimensions that compose the table. This value should match to the
            number of index quantities.
        identifier
            Unique identifier provided to the table. If not defined, the identifier is initialized to a unique UUID
            value.
        ref_id
            Identifier corresponding to the [IDREFS XML attribute](https://wiki.dcc.ptb.de/en/id_refid).
        name
            Mapping from the supported languages to the names (in those languages) that were given to the table.
        description
            Mapping, analogous to 'name', where each value corresponds to the same description in the specified
            language by the key.
        """
        if identifier is None:
            identifier = "U" + str(uuid.uuid4())
        self.id = identifier
        self.ref_id = ref_id
        if ref_type is None:
            ref_type = []
        self.ref_type = ref_type
        self.name = DccLangName(name) if not isinstance(name, DccLangName) else name
        self.description = description
        self.date_time = date_time
        self.used_methods = used_methods
        self.used_software = used_software
        self.measuring_equipments = measuring_equipments
        self.measurement_meta_data = measurement_meta_data
        self.influence_conditions = influence_conditions
        self._idx_quantities: dict[int, DccQuantityType] = {}
        self._quants_by_id: dict[str, DccQuantityType] = {}

        for idx, quant in idx_quants.items():
            quant.index = int(idx)
            self._quants_by_id[quant.id] = quant
            self._idx_quantities[quant.index] = quant

        if dimension_len is None:
            self._dimension_len = len(self._quants_by_id)
        else:
            self._dimension_len = dimension_len
        missing_indices_in_table = [idx for idx in range(self._dimension_len) if idx not in self._idx_quantities]
        if missing_indices_in_table:
            raise ValueError(
                f"The table is incomplete, as the following indices are missing: {missing_indices_in_table}"
            )

        for quant in value_quants:
            self._quants_by_id[quant.id] = quant

    @property
    def units(self) -> set[DsiUnit]:
        """Set of all distinct units (DsiUnit instance) used within the table."""
        units = set()
        with contextlib.suppress(AttributeError):
            for quant in self._quants_by_id.values():
                units.add(quant.data.unit)
        return units

    @property
    def shape(self) -> tuple[int, ...]:
        """
        Returns the shape of the table. This property is not available for LongTables, as they don't have a fixed shape.
        """
        return tuple(len(d) for d in self._idx_quantities.values())

    @property
    def all_quantities(self) -> list[DccQuantityType]:
        """List of all quantities composing the table (index quantities as well as value quantities)."""
        return list(self._quants_by_id.values())

    @property
    def index_quantities(self) -> list[DccQuantityType]:
        """List of only the index quantities within the table."""
        return list(self._idx_quantities.values())

    @property
    def value_quantities(self) -> list[DccQuantityType]:
        """List of only the value quantities within the table."""
        return [q for q in self._quants_by_id.values() if q.index is None]

    @classmethod
    def from_dcc_data(cls, dcc_data: dict) -> DccFlatTable | DccLongTable:
        """Create a DccQuantityTable instance from a dictionary representation.

        Automatically detects the table format (attribute or reftype) and type (flat or long) to instantiate
        the correct subclass.

        Parameters
        ----------
        dcc_data : dict
            Dictionary containing DCC table data with quantities and metadata.

        Returns
        -------
        DccFlatTable | DccLongTable
            Instance of DccFlatTable or DccLongTable based on detected type.

        Raises
        ------
        RuntimeError
            If table format cannot be determined, duplicate indices found, or missing required index dimensions.
        ValueError
            If unknown table format type is detected.
        """
        # fixme: tables can only be initialized at one instance. When a second table is to be initialized, the
        #  following line breaks everything. A workaround has been coded within 'parse_item_from_json_dict'
        dcc_data = replace_quantities_in_dict(dcc_data, parser=parse_item_from_json_dict)

        all_quants_with_paths = dcc_type_collector(dcc_data=dcc_data, search_keys=[DccElementKey.QUANTITY])
        if "@tableDimension" in dcc_data:
            dimension_len = int(dcc_data["@tableDimension"])
            format_type = "attribute"

            if dimension_len < 0:
                raise ValueError(f"Attr tableDimension/@tableDimension {dimension_len} could not be casted to an int>0")

            index_quants = {}
            with contextlib.suppress(ValueError):
                for _, quant in filter(lambda val: bool(val[1].index), all_quants_with_paths):
                    index_quants[int(quant.index)] = quant

            expected_flat_size = math.prod(len(idx_val) for idx_val in index_quants.values())
            if len(index_quants) > 1 and expected_flat_size > 1:
                for _, quant in filter(lambda val: val[1].index is None, all_quants_with_paths):
                    quant_size = len(getattr(quant, "values", []))
                    if quant_size == expected_flat_size:
                        table_type = "long"
                        break
                else:
                    table_type = "flat"
            else:
                table_type = "long"
        elif "@refType" in dcc_data:
            warnings.warn(
                "'refType' as a Table format is deprecated from DCC v3.4.0. Please use the table Attributes instead.",
                category=DeprecationWarning,
                stacklevel=2,
            )
            if isinstance((ref_types := dcc_data["@refType"]), str):
                warnings.warn("'refTypes' should be a list, but they are specified as a string.", stacklevel=2)
                ref_types = ref_types.split()

            pattern_long = re.compile(r"^basic_(\d+)IndexTable$")
            pattern_flat = re.compile(r"^basic_(\d+)IndexFlatTable$")

            long_matches = [m for ref_str in ref_types if (m := pattern_long.match(ref_str))]
            flat_matches = [m for ref_str in ref_types if (m := pattern_flat.match(ref_str))]

            if len(long_matches) > 1 or len(flat_matches) > 1:
                raise ValueError("More than one 'refType' matches the Long- and/or Flat-Table pattern.")
            if len(long_matches) + len(flat_matches) > 1:
                raise ValueError("Found 'refTypes' for both Long- and Flat-Tables.")
            if len(long_matches) + len(flat_matches) == 0:
                raise ValueError("No 'refTypes' found for Long- or Flat-Tables.")

            format_type = "reftype"
            if len(long_matches) == 1:
                table_type = "long"
                dimension_len = int(long_matches[0].group(1))
            else:
                table_type = "flat"
                dimension_len = int(flat_matches[0].group(1))

        else:
            raise ValueError(
                "[Invalid DCC Table]: The provided structure does not match any DCC table, as the attributes "
                "'@tableDimension' (v3.4.0+) and '@refType' (previous to v3.4.0) were not found."
            )

        args = {
            "ref_type": dcc_data.get("@refType"),
            "identifier": dcc_data.get("@id"),
            "ref_id": dcc_data.get("@refId"),
            "name": dcc_data.get("dcc:name"),
            "description": dcc_data.get("dcc:description"),
            "used_methods": dcc_data.get("dcc:usedMethods"),
            "used_software": dcc_data.get("dcc:usedSoftware"),
            "measuring_equipments": dcc_data.get("dcc:measuringEquipments"),
            "measurement_meta_data": dcc_data.get("dcc:measurementMetaData"),
            "influence_conditions": dcc_data.get("dcc:influenceConditions"),
            "idx_quants": {},
            "value_quants": [],
            "dimension_len": dimension_len,
        }

        idx_quant_map = {}
        val_quants_list = []

        for _, quant in all_quants_with_paths:
            quant_idx = (
                _get_basic_index_dimension_from_ref_types(quant.ref_type) if format_type == "reftype" else quant.index
            )
            if quant_idx is None:
                val_quants_list.append(quant)
            else:
                if quant_idx in idx_quant_map:
                    raise ValueError(f"Duplicate index dimension '{quant_idx}' found in table.")
                idx_quant_map[quant_idx] = quant

        # Sanity Check: all detected indexes were correctly found.
        missing_indices = set(idx_quant_map) - set(range(dimension_len))
        if missing_indices:
            raise RuntimeError(f"Missing index dimensions: {sorted(missing_indices)}")

        args["idx_quants"] = idx_quant_map
        args["value_quants"] = val_quants_list

        table_callable = DccLongTable if table_type == "long" else DccFlatTable
        return table_callable(**args)

    def get_quantity_ids_by_field(
        self, field: Literal["name", "ref_type", "unit"], key: str
    ) -> Optional[str | list[str]]:
        r"""Get the quantity unique ID of a specific field.

        Parameters
        ----------
        field : str
            It corresponds to the field to match the value. It can be one of the following options:
            <ul>
                <li><b>'name'</b>: Name of the quantity, in either of the languages that the quantity defined. The
                provided name must be an exact match.
                <li><b>'ref_type'</b>: Value of the refType that is to be matched to find the quantity. The provided
                value must be an exact match to the refType.
                <li><b>'unit'</b>: D-SI unit that defined the quantity.
            </ul>
        key : str
            The value of the previous defined field.

        Returns
        -------
        quant_id : str | list of str
            Unique quantity ID, which can be used to extract the quantity from the table as `quant = table[quant_id]`.
            When multiple quantities matching the same field value are found, a list with all the IDs is returned.
            If no quantity is found, `None` is returned.

        Examples
        --------
        Assuming a table with a single quantity with the name 'Acceleration', the following code shows how to retrieve
        its ID, then how to obtain the quantity from the table with the ID.
        ```pycon
        >>> table: DccQuantityTable
        >>> quant_id: str = table.get_quantity_ids_by_field("name", "Acceleration")
        >>> acc_quant = table[quant_id]
        ```
        Assuming the same table has at least two quantities with the D-SI unit '\metre', the following code shows how
        to obtain the second quantity with this unit.
        ```pycon
        >>> table: DccQuantityTable
        >>> quant_ids: list[str] = table.get_quantity_ids_by_field("unit", "\\metre")
        >>> dist_quant = table[quant_ids[1]]
        ```
        """
        if (field := field.lower()) == "unit":
            unit = DsiUnit(key)
            if not unit.valid:
                raise ValueError(f"'{key}' is not a valid D-SI unit.")
            quantities = [q.id for q in self.all_quantities if unit == q.data.unit]
        elif field == "name":
            quantities = [q.id for q in self.all_quantities if q.name.matches(key)]
        elif field == "ref_type":
            quantities = [q.id for q in self.all_quantities if key in q.ref_type]
        else:
            raise ValueError(f"Unrecognized field '{field}'.")

        if len(quantities) == 0:
            return None
        if len(quantities) == 1:
            return quantities[0]
        return quantities

    def __getitem__(self, index: str) -> DccQuantityType:
        """Access a single quantity by the unique ID."""
        if index not in self._quants_by_id:
            raise KeyError(f"Quantity ID '{index}' not found in the table.")
        return self._quants_by_id[index]

    def get_table_by_condition(self, *queries):
        # """
        # Get the index Table for the given query.
        # Args:
        #     queries: query strings or a list of such to match against the index quantities.
        #     These are the operators supported ['==','<','<=','>','>=','!=']
        #     a query lookslike this ('>=', 10.0)
        #
        # Returns
        # -------
        #     A DCCFalteTable with subindexed data according to matched index quantities.
        # """
        slices = self.get_index_slices_by_condition(*queries)
        return self[slices]

    def get_table_by_nearest(self, *nearest_values, mode: str = "absolute"):
        # """
        # Get the index Table for the given query.
        # Args:
        #     nearest_values: Either a single list/tuple/array of floats to match against the index quantities,
        #                    or multiple float arguments.
        #     Modes:
        #         - 'lower': nearest index with value <= query.
        #         - 'higher': nearest index with value >= query.
        #         - 'absolute': index with the smallest absolute difference.
        #
        # Returns
        # -------
        #     A DCCFalteTable with subindexed data according to matched index quantities.
        # """
        slices = self.get_nearest_index(*nearest_values, mode=mode)
        return self[slices]

    def get_table_from_values(self, *values):
        # """
        # Get the index Table for the given query.
        # Args:
        #     values: Either a list with a list/tuple/array of floats for each dimension
        #     to match against the index quantities, or multiple arguments.
        #
        # Returns
        # -------
        #     A DCCFalteTable with subindexed data according to matched index quantities.
        # """
        slices = self.get_index_from_values(*values)
        return self[slices]

    def get_index_slices_by_condition(self, *queries):
        # """
        # Get the slices (as lists of indices) for the given query per index dimension.
        #
        # The query for each dimension can be:
        #   - None (unconstrained),
        #   - A simple condition tuple like ('>=', 10.0),
        #   - Or a nested query expression combining multiple conditions (using AND, OR, XOR).
        #
        # Nested queries are recursively evaluated, and the final result per dimension
        # is a sorted list of indices.
        #
        # Raises
        # ------
        #   ValueError: if the number of query conditions does not match the table dimension.
        # """
        if len(queries) == 1 and isinstance(queries[0], (list, tuple)):
            if len(self._idx_quantities) != 1:
                queries = queries[0]
            if len(self._idx_quantities) == 1:
                queries = [queries[0]]
        if len(queries) != len(self._idx_quantities):
            raise ValueError("Number of query conditions does not match the table dimension.")
        consolidated_slices = []
        for i, query in enumerate(queries):
            if query is None:
                idx_len = len(self._idx_quantities[i].values)
                consolidated_slices.append(list(range(idx_len)))
                continue
            if not self._idx_quantities[i].sorted:
                raise ValueError("Index Quantities must be sorted to use this function.")
            indices_set = evaluate_query(query, self._idx_quantities[i].values)
            consolidated_slices.append(to_slice(sorted(indices_set)))
        return consolidated_slices

    def get_nearest_index(self, *nearest_values, mode: str = "absolute"):
        # """Get the slices with the nearest values for the given query.
        #
        # Parameters
        # ----------
        # nearest_values: Sequence of floats
        #     Either a single list/tuple/array of floats to match against the index quantities, or multiple float
        #     arguments.
        # mode: str
        #     - 'lower': nearest index with value <= query.
        #     - 'higher': nearest index with value >= query.
        #     - 'absolute': index with the smallest absolute difference.
        #
        # Returns
        # -------
        #     A list of slices corresponding to the matched index quantities.
        # """
        if len(nearest_values) == 1 and isinstance(nearest_values[0], (list, tuple)):
            nearest_values = nearest_values[0]
        if len(nearest_values) != len(self._idx_quantities):
            raise ValueError("Number of query quantities does not match the table dimension.")
        slices = []
        for i, value in enumerate(nearest_values):
            if not self._idx_quantities[i].sorted:
                raise ValueError("Index Quantities must be sorted to use this function.")
            if value is None:
                slices.append(slice(None))
                continue
            slice_obj = get_nearest_slice(self._idx_quantities[i].values, value, mode=mode)
            slices.append(slice_obj)
        return slices

    def get_index_from_values(self, *values):
        # """
        # Get the slices for the given query.
        # Args:
        #     values: Either a single list/tuple/array of floats to match against the index quantities,
        #             or multiple float arguments.
        #
        # Returns
        # -------
        #     A list of slices corresponding to the matched index quantities.
        # """
        if len(values) == 1 and isinstance(values[0], (list, tuple)):
            values = values[0]
        if len(values) != len(self._idx_quantities):
            raise ValueError("Number of query quantities does not match the table dimension.")
        slices = []
        for i, value in enumerate(values):
            if not self._idx_quantities[i].sorted:
                raise ValueError("Index Quantities must be sorted to use this function.")
            slice_obj = get_exact_slice(self._idx_quantities[i].values, value)
            slices.append(slice_obj)
        return slices

    def to_json_dict(self) -> dict:
        # """Wrap the ordered fields under a single 'dcc:list' element."""
        return {"dcc:list": self._to_dict()}

    def export_as_xml_structure(self) -> str:
        """Exports the current table as an XML string compliant with the DCC-schema."""
        return DictToXML(self.to_json_dict())[0]


class DccLongTable(DccQuantityTable):
    """
    Serialization of a `<dcc:list>` with the refType `basic_{dim}IndexTable`, where `dim` corresponds to the number
    of dimensions that compose the table.
    """

    __serialize_fields__: ClassVar[list[FieldSpec]] = [
        FieldSpec(
            name=None, tag="dcc:name", serializer=lambda s: s.name.to_json_dict()["dcc:name"] if s.name else None
        ),
        FieldSpec("description", "dcc:description"),
        FieldSpec("date_time", "dcc:dateTime"),
        FieldSpec(name=None, tag="dcc:quantity", serializer="_build_quantity_list", merge=False),
        FieldSpec("used_methods", "dcc:usedMethods"),
        FieldSpec("used_software", "dcc:usedSoftware"),
        FieldSpec("measuring_equipments", "dcc:measuringEquipments"),
        FieldSpec("influence_conditions", "dcc:influenceConditions"),
        FieldSpec("measurement_meta_data", "dcc:measurementMetaData"),
        FieldSpec("id", "@id"),
        FieldSpec("ref_id", "@refId"),
        FieldSpec("ref_type", "@refType"),
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        expected_ref_type = f"basic_{self._dimension_len}IndexTable"
        if not _match_table_pattern(ref_types=self.ref_type, pattern=rf"^basic_0*{self._dimension_len}IndexTable$"):
            if _get_basic_index_dimension_from_ref_types(self.ref_type) is None:
                warnings.warn(f"Added missing table refType {expected_ref_type} missing.", RuntimeWarning, stacklevel=2)
                self.ref_type.append(expected_ref_type)
            else:
                raise ValueError(
                    f"Table Dimension refType {expected_ref_type} missing but another one was found: {self.ref_type}"
                )
        for idx, idx_quant in self._idx_quantities.items():
            expected_ref_type = f"basic_tableIndex{idx}"
            if not _match_table_pattern(
                ref_types=idx_quant.ref_type, pattern=rf"^basic_tableIndex(?:\({idx}\)|0*{idx})$"
            ):
                if _get_basic_index_dimension_from_ref_types(idx_quant.ref_type) is not None:
                    raise ValueError(
                        f"Table Dimension refType {expected_ref_type} missing but another one was found:"
                        f" {idx_quant.ref_type}"
                    )
                warnings.warn(
                    f"Table Dimension refType {expected_ref_type} missing, added it", RuntimeWarning, stacklevel=2
                )
                idx_quant.ref_type.append(expected_ref_type)

    def __getitem__(self, index: Any):
        if isinstance(index, str):
            return super().__getitem__(index)
        if isinstance(index, (int, slice, list, np.ndarray)):
            idx_quants = [q[index] for q in self._idx_quantities.values()]
            value_quants = [q[index] for q in self.value_quantities]
            return idx_quants, value_quants
        if isinstance(index, tuple) and len(index) > 1 and all((isinstance(x, (slice, int)) for x in index)):
            if len(self._idx_quantities) > 1:
                raise IndexError(
                    "DccLongTable does not support multi dimensional slices. Use the indexing methods to get the "
                    "1D indexes for your higher dimensional data."
                )
            raise IndexError(
                "DccLongTable does not support multi dimensional slices. Use the indexing methods to get the 1D "
                "indexes for your higher dimensional data.\n But this instance is 1D anyways."
            )
        raise TypeError(f"Unsupported type {type(index)} as index.")

    def get_index_slices_by_condition(self, *queries):
        # """
        # Get the slices (as lists of indices) for the given query per index dimension.
        #
        # The query for each dimension can be:
        #   - None (unconstrained),
        #   - A simple condition tuple like ('>=', 10.0),
        #   - Or a nested query expression combining multiple conditions (using AND, OR, XOR).
        #
        # Nested queries are recursively evaluated, and the final result per dimension
        # is a sorted list of indices.
        #
        # Raises
        # ------
        #   ValueError: if the number of query conditions does not match the table dimension.
        # """
        slices = super().get_index_slices_by_condition(*queries)
        if len(slices) == 1:
            return slices[0]
        return slice_and(*slices)

    def get_nearest_index(self, *nearest_values, mode: str = "absolute"):
        # """
        # Get the slices with the nearest values for the given query.
        # Args:
        #     nearest_values: Either a single list/tuple/array of floats to match against the index quantities,
        #                    or multiple float arguments.
        # Modes:
        #     - 'lower': nearest index with value <= query.
        #     - 'higher': nearest index with value >= query.
        #     - 'absolute': index with the smallest absolute difference.
        #
        # Returns
        # -------
        #     A list of slices corresponding to the matched index quantities.
        # """
        slices = super().get_nearest_index(*nearest_values, mode)
        if len(slices) == 1:
            return slices[0]
        return slice_and(*slices)

    def get_index_from_values(self, *values):
        # """
        # Get the slices for the given query.
        # Args:
        #     values: Either a single list/tuple/array of floats to match against the index quantities,
        #             or multiple float arguments.
        #
        # Returns
        # -------
        #     A list of slices corresponding to the matched index quantities.
        # """
        slices = super().get_index_from_values(*values)
        if len(slices) == 1:
            return slices[0]
        return slice_and(*slices)

    def _build_quantity_list(self) -> list[dict]:
        """Return a flat list of each quantity's inner dict, in index-order followed by value-order."""
        return [q.to_json_dict() for q in self.all_quantities]

    @property
    def shape(self) -> None:
        """Returns `None` and prints a warning, as LongTables don't have a specific shape."""
        warnings.warn(
            "Property `DccLongTable.shape` was invoked, but LongTables don't have any shape. The returned value"
            " as shape is `None`.",
            stacklevel=2,
        )
        return None  # noqa: PLR1711


class DccFlatTable(DccQuantityTable):
    """
    Serialization of a `<dcc:list>` with the refType `basic_{dim}IndexFlatTable`, where `dim` corresponds to the
    number of dimensions that compose the table.
    """

    __serialize_fields__: ClassVar[list[FieldSpec]] = [
        FieldSpec(
            name=None, tag="dcc:name", serializer=lambda s: s.name.to_json_dict()["dcc:name"] if s.name else None
        ),
        FieldSpec("description", "dcc:description"),
        FieldSpec("date_time", "dcc:dateTime"),
        FieldSpec(name=None, tag="dcc:list", serializer="_build_list_wrappers", merge=False),
        FieldSpec("used_methods", "dcc:usedMethods"),
        FieldSpec("used_software", "dcc:usedSoftware"),
        FieldSpec("measuring_equipments", "dcc:measuringEquipments"),
        FieldSpec("influence_conditions", "dcc:influenceConditions"),
        FieldSpec("measurement_meta_data", "dcc:measurementMetaData"),
        FieldSpec("id", "@id"),
        FieldSpec("ref_id", "@refId"),
        FieldSpec("ref_type", "@refType"),
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for value_quant in self.value_quantities:
            if value_quant.shape != self.shape:
                value_quant.data.reshape(self.shape)
        expected_ref_type = f"basic_{self._dimension_len}IndexFlatTable"
        if not _match_table_pattern(ref_types=self.ref_type, pattern=rf"^basic_0*{self._dimension_len}IndexFlatTable$"):
            if _get_basic_index_dimension_from_ref_types(self.ref_type) is None:
                warnings.warn(
                    f"Table Dimension refType {expected_ref_type} missing, added it", RuntimeWarning, stacklevel=2
                )
                self.ref_type.append(expected_ref_type)
            else:
                raise ValueError(
                    f"Table Dimension refType {expected_ref_type} missing, but a different one "
                    f"was found: {self.ref_type}"
                )
        for idx, idx_quant in self._idx_quantities.items():
            expected_idx_ref_type = f"basic_FlatTableIndex{idx}"
            if not _match_table_pattern(ref_types=idx_quant.ref_type, pattern=rf"^basic_FlatTableIndex0*{idx}$"):
                if _get_basic_index_dimension_from_ref_types(idx_quant.ref_type) is not None:
                    raise ValueError(
                        f"Table Dimension refType {expected_idx_ref_type} missing,"
                        f" but a different one was found: {idx_quant.ref_type}"
                    )
                warnings.warn(
                    f"Table Dimension refType {expected_idx_ref_type} missing, added it", RuntimeWarning, stacklevel=2
                )
                idx_quant.ref_type.append(expected_idx_ref_type)

    def __getitem__(self, index: str | list | tuple | int | slice):
        if isinstance(index, str):
            return super().__getitem__(index)
        if isinstance(index, (list, tuple)):
            if len(index) != len(self._idx_quantities):
                raise IndexError(
                    f"Number of index quantities ({len(index)!s}) does not match"
                    f" the table dimension ({len(self._idx_quantities)!s})."
                )
            index_tuple = tuple(index)
            idx_quants = [self._idx_quantities[i][idx_slice] for i, idx_slice in enumerate(index)]
            value_quants = [v_quant[index_tuple] for v_quant in self.value_quantities]
            return idx_quants, value_quants
        if isinstance(index, (int, slice)):
            if len(self._idx_quantities) != 1:
                raise IndexError(
                    "Integer/1D Slice indexing not supported for nD DccFlatTable. Use proper slice indexing.\n"
                    f"Hint this table is {len(self._idx_quantities)!s} dimensional."
                )
            warnings.warn(
                "Indexing an 1D DccFlatTable with an integer or slice, this will work but 1D DccFlatTable should "
                "always be a DccLongTable in the first place!",
                category=RuntimeWarning,
                stacklevel=2,
            )
            idx_quants = [idx_quant[index] for idx_quant in self.index_quantities]
            value_quants = [v_quant[index] for v_quant in self.value_quantities]
            return idx_quants, value_quants
        raise TypeError(f"Unsupported type {type(index)}.")

    def _build_list_wrappers(self) -> list[dict]:
        """
        Build the two <dcc:list> wrappers on the fly:
          - first: index quantities
          - second: data (value) quantities
        """

        def make_wrapper(title: dict, ref_type: list[str], quants: list):
            wrapper = DccLangName(title).to_json_dict()
            wrapper["@refType"] = ref_type
            wrapper["dcc:quantity"] = [q.to_json_dict() for q in quants]
            return wrapper

        idx_quants = [self._idx_quantities[i] for i in sorted(self._idx_quantities)]
        index_wrapper = make_wrapper(
            title={"en": "Index Quantities", "de": "Indexquantities"},
            ref_type=["basic_FlatTableIndices"],
            quants=idx_quants,
        )
        value_wrapper = make_wrapper(
            title={"en": "Data Quantities", "de": "Datenquantities"},
            ref_type=["basic_FlatTableData"],
            quants=self.value_quantities,
        )
        return [index_wrapper, value_wrapper]
