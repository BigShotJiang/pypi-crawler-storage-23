from __future__ import annotations

import warnings
from typing import Optional

from dcc_quantities._abc import AbstractListType
from dcc_quantities.si_real_list import parse_const, parse_real_list_xml_list, parse_si_real_value


class SiHybrid(AbstractListType):
    def to_json_dict(self):
        return {"si:hybrid": super().to_json_dict()}

    def __str__(self) -> str:
        return "\n[\n    " + "\n    ".join((str(child) for child in self.children)) + "\n]\n"

    @property
    def sorted(self) -> bool:
        return self.children[0].sorted


def parse(json_dict: dict, relative_uncertainty: Optional[dict] = None):
    key_parser_mapping = {
        "si:real": parse_si_real_value,
        "si:complex": ...,
        "si:list": ...,
        "si:realList": ...,
        "si:realListXMLList": parse_real_list_xml_list,
        "si:complexList": ...,
        "si:constant": parse_const,
    }
    children = []
    for key, parse_func in key_parser_mapping.items():
        if key in json_dict:
            if isinstance(json_dict[key], list):
                for item in json_dict[key]:
                    children.append(parse_func(item, relative_uncertainty=relative_uncertainty))
            else:
                children.append(parse_func(item, relative_uncertainty=relative_uncertainty))
    for key in json_dict:
        if key not in key_parser_mapping:
            warnings.warn(f"Unsupported key for si:hybrid: {key}", RuntimeWarning, stacklevel=2)
    return SiHybrid(children=children)
