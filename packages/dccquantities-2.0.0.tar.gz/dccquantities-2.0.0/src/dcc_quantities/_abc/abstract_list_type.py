from __future__ import annotations

from typing import TYPE_CHECKING

from dcc_quantities._abc.abstract_quantity_type_data import AbstractQuantityTypeData

if TYPE_CHECKING:
    from dcc_quantities._abc.abstract_value_type import AbstractValueType


class AbstractListType(AbstractQuantityTypeData):
    def __init__(self, children: list[AbstractListType | AbstractValueType]):
        super().__init__()
        self.children = children

    def to_json_dict(self) -> dict:
        result = {}
        for child in self.children:
            child_json = child.to_json_dict()
            for key, value in child_json.items():
                result.setdefault(key, []).append(value)
        return result

    def __len__(self) -> int:
        return len(self.children)
