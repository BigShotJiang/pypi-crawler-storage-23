from __future__ import annotations

import contextlib
from typing import TYPE_CHECKING, Optional

import numpy as np
from metas_unclib import ufloat

from dcc_quantities._abc.abstract_quantity_type_data import AbstractQuantityTypeData

if TYPE_CHECKING:
    from datetime import datetime

    from dsi_unit import DsiUnit


class AbstractValueType(AbstractQuantityTypeData):
    def __init__(
        self,
        label: Optional[str] = None,
        unit: Optional[str | DsiUnit] = None,
        date_time: Optional[list[datetime]] = None,
        _origin_type: Optional[str] = None,
        _unc_info: Optional[dict] = None,
    ):
        super().__init__()
        self.label = label
        self.unit = unit
        self._origin_type = _origin_type
        self._unc_info = _unc_info
        self.date_time = date_time

    def serialize_data_to_json(self) -> dict:
        if not isinstance(self.data, np.ndarray):
            raise ValueError("Data is not a numpy array")

        length = self.data.size
        flatt_uncs = None
        flatt_values = None

        if np.issubdtype(self.data.dtype, np.number):
            flatt_values = list(self.data.flat) if self.data.size > 1 else self.data.flat[0]

        if isinstance(self.data.dtype, object):
            flatt_array = self.data.flat
            if isinstance(flatt_array[0], ufloat):
                vec_values = np.vectorize(lambda x: x.value)
                vec_uncs = np.vectorize(lambda x: x.stdunc)
                if self.data.size > 1:
                    flatt_values = list(vec_values(flatt_array))
                    flatt_uncs = list(vec_uncs(flatt_array))
                else:
                    flatt_values = vec_values(flatt_array)[0]
                    flatt_uncs = vec_uncs(flatt_array)[0]

        suffix = "" if length == 1 and not self._origin_type.endswith("XMLList") else "XMLList"
        result_json = {"si:value" + suffix: flatt_values}
        if flatt_uncs and self._unc_info is not None:
            kfactor = self._unc_info["coverageFactor"]
            cov_prob = self._unc_info["coverage_probability"]
            distribution = self._unc_info["distribution"]
            if all(arr_len == 1 for arr_len in map(len, (kfactor, cov_prob, distribution))):
                kfactor = kfactor[0]
                cov_prob = cov_prob[0]
                distribution = distribution[0]
            if not np.all(np.isclose(kfactor, 1.0)):
                if "originalUnc" not in self._unc_info:
                    unc_values = (np.array(flatt_uncs) * kfactor).tolist()
                    if suffix == "":
                        with contextlib.suppress(TypeError):
                            unc_values = unc_values[0]
                else:
                    unc_values = self._unc_info["originalUnc"]
                    if suffix == "":
                        with contextlib.suppress(TypeError):
                            unc_values = unc_values[0]
                result_json["si:measurementUncertaintyUnivariate" + suffix] = {
                    "si:expandedMU" + suffix: {
                        "si:valueExpandedMU" + suffix: unc_values,
                        "si:coverageFactor" + suffix: kfactor,
                        "si:coverageProbability" + suffix: cov_prob,
                        "si:distribution" + suffix: distribution,
                    }
                }
            else:
                result_json["si:measurementUncertaintyUnivariate" + suffix] = {
                    "si:standardMU" + suffix: {
                        "si:valueStandardMU" + suffix: flatt_uncs,
                        "si:distribution" + suffix: distribution,
                    }
                }
        return result_json
