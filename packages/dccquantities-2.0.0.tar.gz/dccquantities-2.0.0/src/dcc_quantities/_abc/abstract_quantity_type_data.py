from typing import Any, Iterator


class AbstractQuantityTypeData:
    def __init__(self):
        self.data = "None"
        self._sorted = None

    def _iter_items(self) -> Iterator[tuple[str, Any]]:
        """Iterator over all the class' items.

        Iterates over all the non-empty (different to 'None') attributes or items contained within the class.
        The items are returned as the attribute name and its value.
        """
        for k, v in vars(self).items():
            if v is not None:
                yield k, v

    def __str__(self) -> str:
        """String representation of the class' stored values."""
        param_str = ", ".join(f"{key}: {value!s}" for key, value in self._iter_items())
        if len(param_str) > 0:
            param_str = " (" + param_str + ")"
        return f"{self.data!s}{param_str}"

    def __repr__(self) -> str:
        return ", ".join(f"{key}={value!s}" for key, value in self._iter_items())
