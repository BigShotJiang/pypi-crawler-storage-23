from __future__ import annotations

import ctypes
import locale
import sys

if sys.version_info < (3, 11):
    from py_back import enum
else:
    import enum


class CoverageProbabilityMissmatchBehavior(enum.IntEnum):
    EXCEPTION = 1
    WARNING_TAKE_K_VALUE = 2


class DccReprStyle(enum.StrEnum):
    NORMAL = enum.auto()
    LIB_DEBUG = enum.auto()


class DccConfiguration:
    _instance = None

    def __new__(cls) -> DccConfiguration:
        if cls._instance is None:
            cls._instance = super(DccConfiguration, cls).__new__(cls)
            system_lang = cls.get_system_language()
            cls.preferredLangs = list(dict.fromkeys([system_lang, "en", "de"]))
            cls.reprStyle = "normal"
            cls.allowedCoverageProbabilityMissmatch = {"normal": 0.01, "uniform": 0.03, "default": 0.03}
            cls.coverageProbabilityMissmatchBehavior = CoverageProbabilityMissmatchBehavior.WARNING_TAKE_K_VALUE
            cls.storeOriginalUncerForNonIntK = True
            cls.record_warnings = True
        return cls._instance

    @staticmethod
    def get_system_language() -> str:
        """Detects the system language for Windows, Linux, and macOS."""
        if sys.platform == "win32":
            windll = ctypes.windll.kernel32
            system_lang = locale.windows_locale[windll.GetUserDefaultUILanguage()]
        else:
            system_lang = locale.getlocale()
        return system_lang[0].split("_")[0].lower()

    @property
    def system_lang(self) -> str:
        return self.preferredLangs[0]


dcc_config = DccConfiguration()
