""""""

from __future__ import annotations

import warnings
from typing import Sequence


def to_slice(values: Sequence[int]) -> slice:
    """Converting a sequence of integers into a slice object.

    Examples
    --------
        [2, 4, 6, 8] -> slice(2, 10, 2)
        [5, 4, 3] -> slice(5, 2, -1)

    Parameters
    ----------
    values : Sequence
        A non-empty sequence of integers, all spaced with the same step value.
    """
    if len(values) == 0:
        raise ValueError("Cannot convert to a slice an empty sequence")

    if len(values) == 1:
        return slice(values[0], values[0] + 1, 1)

    step = values[1] - values[0]
    for i in range(1, len(values)):
        if values[i] - values[i - 1] != step:
            warnings.warn("Step width is not uniform slice conversion failed.", RuntimeWarning, stacklevel=2)
            return values
    return slice(values[0], values[-1] + step, step)
