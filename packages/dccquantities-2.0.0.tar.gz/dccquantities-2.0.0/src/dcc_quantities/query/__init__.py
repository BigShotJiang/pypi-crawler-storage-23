from dcc_quantities.query.slices import to_slice

__all__ = ["to_slice"]
