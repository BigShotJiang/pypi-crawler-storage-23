import operator
import sys

if sys.version_info < (3, 11):
    from py_back import enum
else:
    import enum

COMPARE_OPERATORS_MAP = {
    "==": operator.eq,
    "<": operator.lt,
    "<=": operator.le,
    ">": operator.gt,
    ">=": operator.ge,
    "!=": operator.ne,
}

AND_LOGIC_OPERATORS = {"AND", "&", "&&"}
OR_LOGIC_OPERATORS = {"OR", "|", "||"}
XOR_LOGIC_OPERATORS = {"XOR", "^"}
LOGIC_OPERATORS = AND_LOGIC_OPERATORS | OR_LOGIC_OPERATORS | XOR_LOGIC_OPERATORS

SUPPORTED_OPERATORS = LOGIC_OPERATORS | COMPARE_OPERATORS_MAP.keys()


class QueryMode(enum.StrEnum):
    LOWER = enum.auto()
    HIGHER = enum.auto()
    ABSOLUTE = enum.auto()
