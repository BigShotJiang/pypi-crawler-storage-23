"""Math function to be used over all instances of the DccQuantities package.

All functions defined within the module are a wrapper to their analogous
[`metas_unclib.umath`](https://github.com/metas-ch/metas-unclib-python-wrapper) functions.
These functions diverge from the `umath` functions as they work only for instances of
[`DccQuantityType`](quantity_type.md#dcc_quantities.dcc_quantity_type.DccQuantityType) and
[`SiRealList`](si_real_list.md#dcc_quantities.si_real_list.SiRealList).
"""

from __future__ import annotations

import numbers
from typing import TYPE_CHECKING, Callable, overload

import numpy as np
from dsi_unit.unit_mapping import UNIT_TO_BASE_TREE_MAP
from metas_unclib import get_value, umath

from dcc_quantities.dcc_quantity_type import DccQuantityType
from dcc_quantities.exceptions import NumericDomainError, UnitError
from dcc_quantities.si_real_list import SiRealList

if TYPE_CHECKING:
    from dsi_unit import DsiUnit


_ANGLE_UNITS: dict[str, tuple] = {
    unit: tree[0] for unit, tree in UNIT_TO_BASE_TREE_MAP.items() if tree[0][0] == "radian"
}
_INV_TRIG_DOMAIN_CHECK: dict[str, Callable[[numbers.Real], bool]] = {
    "asin": lambda n: -1 <= get_value(n) <= 1,
    "acos": lambda n: -1 <= get_value(n) <= 1,
    "atan": lambda n: isinstance(get_value(n), numbers.Real),
    "asinh": lambda n: isinstance(get_value(n), numbers.Real),
    "acosh": lambda n: get_value(n) >= 1,
    "atanh": lambda n: -1 <= get_value(n) <= 1,
}


def _trigonometry_sanity_check(si_values: DccQuantityType | SiRealList, inverse: bool = False) -> None:
    r"""Check for all trigonometry functions.

    A trigonometry function can only be performed over:
        A) An angle of any kind.
        B) An adimensional value which is not '\ppm' nor '\percent'.

    Any direct trigonometric function (sin, cos, tan, etc.) will always return an adimensional value.
    That considered, an inverse trigonometric function (asin, acos, atan, etc.) is only to be performed
    over a pure adimensional value (previous case B) and will always return an angle.

    Parameters
    ----------
    si_values
    inverse : bool, default = False
        Flag defining if the check is for an inverse trigonometric function (from an adimensional to angle).
    """
    if isinstance(si_values, DccQuantityType):
        list_values = si_values.data
    elif isinstance(si_values, SiRealList):
        list_values = [si_values]
    else:
        raise TypeError(
            "Functions from the module 'dcc_math' can be applied only to instances of 'DccQuantityType'"
            " and 'SiRealList'."
        )

    for si_value in list_values:
        unit: DsiUnit = si_value.unit
        valid = unit.is_adimensional
        valid |= not inverse and unit.dsi_string.strip("\\") in _ANGLE_UNITS
        if not valid:
            raise UnitError(
                "Trigonometric functions are only valid for angles or adimensional units, but unit "
                f"'{unit}' was provided."
            )


@overload
def _direct_trigonometric_function(q: DccQuantityType, ufunc: Callable) -> DccQuantityType: ...
@overload
def _direct_trigonometric_function(q: SiRealList, ufunc: Callable) -> SiRealList: ...


def _direct_trigonometric_function(q: DccQuantityType | SiRealList, ufunc: Callable) -> DccQuantityType | SiRealList:
    """General logic for all direct trigonometric functions (sin, cos, tan, etc.).

    Parameters
    ----------
    q :
        Quantity over the angle function is to be implemented.
    ufunc : umath function
        Callback corresponding to the uncertainty math function to be performed.
    """
    _trigonometry_sanity_check(q)
    data = q.data if isinstance(q, DccQuantityType) else q
    data *= data.unit.scale_factor
    if not data.unit.is_adimensional:
        angle_unit_name = data.unit.dsi_string.strip("\\")
        data *= _ANGLE_UNITS[angle_unit_name][2]

    new_si_data = SiRealList(data=ufunc(data.data), unit="\\one")
    return new_si_data if isinstance(q, SiRealList) else DccQuantityType(new_si_data)


@overload
def _inverse_trigonometric_function(q: DccQuantityType, ufunc: Callable) -> DccQuantityType: ...
@overload
def _inverse_trigonometric_function(q: SiRealList, ufunc: Callable) -> SiRealList: ...


def _inverse_trigonometric_function(q: DccQuantityType | SiRealList, ufunc: Callable) -> DccQuantityType | SiRealList:
    """General logic for all inverse trigonometric functions (asin, acos, atan, etc.).

    Parameters
    ----------
    q
        Quantity over the angle function is to be implemented.
    ufunc : umath function
        Callback corresponding to the uncertainty math function to be performed.
    """
    _trigonometry_sanity_check(q, inverse=True)
    data = q.data if isinstance(q, DccQuantityType) else q
    within_domain = np.all(_INV_TRIG_DOMAIN_CHECK[ufunc.__name__](data.data))
    if not within_domain:
        raise NumericDomainError(f"The provided values are outside the valid domain for {ufunc.__name__}.")
    new_si_data = SiRealList(data=ufunc((data * data.unit.scale_factor).data), unit="\\radian")
    return new_si_data if isinstance(q, SiRealList) else DccQuantityType(new_si_data)


@overload
def _generic_umath_function(q: DccQuantityType, ufunc: Callable, *args, **kwargs) -> DccQuantityType: ...
@overload
def _generic_umath_function(q: SiRealList, ufunc: Callable, *args, **kwargs) -> SiRealList: ...


def _generic_umath_function(
    q: DccQuantityType | SiRealList, ufunc: Callable, adimensional: bool = False, result_unit: str = "\\one"
) -> DccQuantityType | SiRealList:
    r"""Wrapper to any general umath function.

    Parameters
    ----------
    q
        Quantity over the angle function is to be implemented.
    ufunc : umath function
        Callback corresponding to the uncertainty math function to be performed.
    adimensional : bool
        Flag to define whether the units require to be adimensional. False by default.
    result_unit : str
        Unit that the result will carry. It sets to '\one' by default.

    Raises
    ------
    UnitError
        When the 'adimensional' flag is set and the quantity has non-adimensional units.
    """
    data = q.data if isinstance(q, DccQuantityType) else q
    if adimensional and not data.unit.is_adimensional:
        raise UnitError(f"Function '{ufunc.__name__}' can only be applied over adimensional quantities.")
    new_data = ufunc((data * data.unit.scale_factor).data)
    if any(isinstance(get_value(v), complex) for v in new_data):
        raise NotImplementedError("Complex numbers are not supported yet. Make yure ")
    new_si_data = SiRealList(data=ufunc((data * data.unit.scale_factor).data), unit=result_unit)
    return new_si_data if isinstance(q, SiRealList) else DccQuantityType(new_si_data)


# ------------------------------------
#   Common math functions
# ------------------------------------
def log(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the natural logarithm of _**a**_, where _**a**_ is adimensional DCC Quantity data.

    Raises
    ------
    UnitError
        When the unit of the provided data is not adimensional.
    """
    return _generic_umath_function(a, ufunc=umath.log, adimensional=True)


def log10(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the base-10 logarithm of _**a**_, where _**a**_ is adimensional DCC Quantity data.

    Raises
    ------
    UnitError
        When the unit of the provided data is not adimensional.
    """
    return _generic_umath_function(a, ufunc=umath.log10, adimensional=True)


def exp(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return _e_ raised to the power _**a**_, where _e_ = 2.718281… is the base of natural logarithms and _**a**_
    is adimensional DCC Quantity data.

    Raises
    ------
    UnitError
        When the unit of the provided data is not adimensional.
    """
    return _generic_umath_function(a, ufunc=umath.exp, adimensional=True)


def sqrt(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the square root of _**a**_, where _**a**_ is DCC Quantity data.

    Raises
    ------
    NotImplementedError
        When any of the provided data becomes complex, it would be expected to have an `SiComplexList` instance
        as the result Quantity data. However, currently only `SiRealList` are supported. This exception will be removed
        when the library supports `SiComplexList`.
    """
    unit = a.data.unit if isinstance(a, DccQuantityType) else a.unit
    return _generic_umath_function(a, ufunc=umath.sqrt, result_unit=unit**0.5)


def abs(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:  # noqa: A001
    """Return a copy of the Dcc Quantity Data where all values are absolute. The function is analogous to `abs(a)`."""
    unit = a.data.unit if isinstance(a, DccQuantityType) else a.unit
    return _generic_umath_function(a, ufunc=umath.abs, result_unit=unit)


# ------------------------------------
#   Direct trigonometric functions
# ------------------------------------
def sin(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the sine of the quantity data.

    The function is valid only for quantity data which unit is 'radians', any of its D-SI units derivatives or
    adimensional. The returned quantity data is always set with the unit 'one'.

    Raises
    ------
    UnitError
        When the unit of the quantity data is not adimensional, 'radians' nor any of its derivate DSI units.
    """
    return _direct_trigonometric_function(a, umath.sin)


def cos(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the cosine of the quantity data.

    The function is valid only for quantity data which unit is 'radians', any of its D-SI units derivatives or
    adimensional. The returned quantity data is always set with the unit 'one'.

    Raises
    ------
    UnitError
        When the unit of the quantity data is not adimensional, 'radians' nor any of its derivate DSI units.
    """
    return _direct_trigonometric_function(a, umath.cos)


def tan(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the tangent of the quantity data.

    The function is valid only for quantity data which unit is 'radians', any of its D-SI units derivatives or
    adimensional. The returned quantity data is always set with the unit 'one'.

    Raises
    ------
    UnitError
        When the unit of the quantity data is not adimensional, 'radians' nor any of its derivate DSI units.
    """
    return _direct_trigonometric_function(a, umath.tan)


def sinh(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the hyperbolic sine of the quantity data.

    The function is valid only for quantity data which unit is 'radians', any of its D-SI units derivatives or
    adimensional. The returned quantity data is always set with the unit 'one'.

    Raises
    ------
    UnitError
        When the unit of the quantity data is not adimensional, 'radians' nor any of its derivate DSI units.
    """
    return _direct_trigonometric_function(a, umath.sinh)


def cosh(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the hyperbolic cosine of the quantity data.

    The function is valid only for quantity data which unit is 'radians', any of its D-SI units derivatives or
    adimensional. The returned quantity data is always set with the unit 'one'.

    Raises
    ------
    UnitError
        When the unit of the quantity data is not adimensional, 'radians' nor any of its derivate DSI units.
    """
    return _direct_trigonometric_function(a, umath.cosh)


def tanh(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the hyperbolic tangent of the quantity data.

    The function is valid only for quantity data which unit is 'radians', any of its D-SI units derivatives or
    adimensional. The returned quantity data is always set with the unit 'one'.

    Raises
    ------
    UnitError
        When the unit of the quantity data is not adimensional, 'radians' nor any of its derivate DSI units.
    """
    return _direct_trigonometric_function(a, umath.tanh)


# ------------------------------------
#   Inverse trigonometric functions
# ------------------------------------
def asin(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the arc sine (inverse sine) of the quantity data. `arcsin` is an alias for this function.

    The function is valid only for quantity data which unit is adimensional. The returned quantity data is always set
    with the unit 'radians'.

    Raises
    ------
    UnitError
        When the unit of the quantity data is not adimensional.
    NumericDomainError
        When any of the data values is not within the arc sine domain. The arc sine domain is defined as all natural
        numbers in the range [-1, 1].
    """
    return _inverse_trigonometric_function(a, umath.asin)


def acos(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the arc cosine (inverse cosine) of the quantity data. `arccos` is an alias for this function.

    The function is valid only for quantity data which unit is adimensional. The returned quantity data is always set
    with the unit 'radians'.

    Raises
    ------
    UnitError
        When the unit of the quantity data is not adimensional.
    NumericDomainError
        When any of the data values is not within the arc sine domain. The arc sine domain is defined as all natural
        numbers in the range [-1, 1].
    """
    return _inverse_trigonometric_function(a, umath.acos)


def atan(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the arc tangent (inverse tangent) of the quantity data. `arctan` is an alias for this function.

    The function is valid only for quantity data which unit is adimensional. The returned quantity data is always set
    with the unit 'radians'.

    Raises
    ------
    UnitError
        When the unit of the quantity data is not adimensional.
    NumericDomainError
        When any of the data values is not within the arc sine domain. The arc sine domain is defined as all natural
        numbers.
    """
    return _inverse_trigonometric_function(a, umath.atan)


def asinh(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the inverse hyperbolic sine of the quantity data. `arcsinh` is an alias for this function.

    The function is valid only for quantity data which unit is adimensional. The returned quantity data is always set
    with the unit 'radians'.

    Raises
    ------
    UnitError
        When the unit of the quantity data is not adimensional.
    NumericDomainError
        When any of the data values is not within the arc sine domain. The arc sine domain is defined as all natural
        numbers.
    """
    return _inverse_trigonometric_function(a, umath.asinh)


def acosh(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the inverse hyperbolic cosine of the quantity data. `arccosh` is an alias for this function.

    The function is valid only for quantity data which unit is adimensional. The returned quantity data is always set
    with the unit 'radians'.

    Raises
    ------
    UnitError
        When the unit of the quantity data is not adimensional.
    NumericDomainError
        When any of the data values is not within the arc sine domain. The arc sine domain is defined as all natural
        numbers equal or greater than 1.
    """
    return _inverse_trigonometric_function(a, umath.acosh)


def atanh(a: DccQuantityType | SiRealList) -> DccQuantityType | SiRealList:
    """Return the inverse hyperbolic tangent of the quantity data. `arctanh` is an alias for this function.

    The function is valid only for quantity data which unit is adimensional. The returned quantity data is always set
    with the unit 'radians'.

    Raises
    ------
    UnitError
        When the unit of the quantity data is not adimensional.
    NumericDomainError
        When any of the data values is not within the arc sine domain. The arc sine domain is defined as all natural
        numbers in the range [-1, 1].
    """
    return _inverse_trigonometric_function(a, umath.atanh)


# ------------------------------------
#   Aliases
# ------------------------------------
arcsin = asin
arccos = acos
arctan = atan
arcsinh = asinh
arccosh = acosh
arctanh = atanh
