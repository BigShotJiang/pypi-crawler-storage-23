from __future__ import annotations

import warnings
from typing import Optional

import numpy as np

import dcc_quantities.query._operators as query_op
from dcc_quantities.query.slices import to_slice
from dcc_quantities.serializers.dcc_element_key import DccElementKey
from dcc_quantities.serializers.dcc_element_parser import dcc_type_collector


def unexpected_key_serialization_handler(result: dict, key: str, value, class_name: str) -> None:
    """
    Handles unexpected keys during JSON serialization.

    If the key contains 'dcc:' or 'si:', it is assumed to be DCC-related and is added to the result,
    otherwise a warning is issued and the key is ignored.
    """
    if "dcc:" in str(key) or "si:" in str(key):
        warnings.warn(
            f"Found unexpected key {key} while converting {class_name} to JSON."
            f" Assuming this is DCC data therefore adding it to the JSON.",
            RuntimeWarning,
            stacklevel=3,
        )
        result[key] = value
    else:
        warnings.warn(
            f"Found unexpected key {key} while converting {class_name} to JSON."
            f" Assuming this other data is unrelated to DCC and ignoring.",
            RuntimeWarning,
            stacklevel=3,
        )


def parse_attributes(json_dict: dict):
    attributes = {}
    if "@id" in json_dict:
        attributes["id"] = json_dict["@id"]
    if "@refId" in json_dict:
        attributes["ref_id"] = json_dict["@refId"]
    if "@refType" in json_dict:
        attributes["ref_type"] = json_dict["@refType"]
    if "@lang" in json_dict:
        attributes["lang"] = json_dict["@lang"]
    if "@index" in json_dict:
        attributes["index"] = json_dict["@index"]
    return attributes


def replace_quantities_in_dict(
    json_dict: dict, parser, search_keys: Optional[list] = None, return_quantity_list: bool = False
):
    if search_keys is None:
        search_keys = [DccElementKey.QUANTITY]
    found_quantities = dcc_type_collector(json_dict, search_keys=search_keys)
    if return_quantity_list:
        quantity_list = []
    for path, result in found_quantities:
        parsed_object = parser(result)
        if return_quantity_list:
            quantity_list.append((path, parsed_object))
        current_node = json_dict
        for key in path[:-1]:
            current_node = current_node[key]
        current_node[path[-1]] = parsed_object
    if return_quantity_list:
        return json_dict, quantity_list
    return json_dict


def ensure_list(data):
    if isinstance(data, list):
        return data
    if data is None:
        return []
    return [data]


def normalize_operator(op):
    """
    Normalizes operator strings to canonical uppercase forms.
    Supports both the comparison operators and the logical operators.
    """
    if isinstance(op, str):
        op = op.strip().upper()
        if op in query_op.AND_LOGIC_OPERATORS:
            return "AND"
        if op in query_op.OR_LOGIC_OPERATORS:
            return "OR"
        if op in query_op.XOR_LOGIC_OPERATORS:
            return "XOR"
        if op in query_op.COMPARE_OPERATORS_MAP:
            return op
    raise ValueError(f"Invalid operator: {op}")


def evaluate_query(query, index_vector):
    """
    Recursively evaluates a query expression against a 1D index_vector.

    A query can be:
      - None: meaning unconstrained (returns all indices).
      - A simple condition tuple like ('>', 10.0), which uses get_conditional_slice.
      - A nested expression like:
            [ subexpr, operator, subexpr, operator, subexpr, ... ]
        where subexpr can itself be nested.

    Returns a set of indices (as integers) that satisfy the query.
    """
    if query is None:
        return set(range(len(index_vector)))
    if isinstance(query, tuple) and len(query) == 2:
        op_str = str(query[0]).strip().upper()
        if op_str in query_op.COMPARE_OPERATORS_MAP:
            s = get_conditional_slice(index_vector, query)
            return set(range(s.start, s.stop))
    if isinstance(query, (list, tuple)):
        if len(query) == 1:
            return evaluate_query(query[0], index_vector)
        result = evaluate_query(query[0], index_vector)
        i = 1
        while i < len(query):
            op = normalize_operator(query[i])
            next_expr = evaluate_query(query[i + 1], index_vector)
            if op == "AND":
                result = result.intersection(next_expr)
            elif op == "OR":
                result = result.union(next_expr)
            elif op == "XOR":
                result = result.symmetric_difference(next_expr)
            else:
                raise ValueError(f"Unsupported logical operator: {op}")
            i += 2
        return result
    raise TypeError("Query must be a tuple, list, or None.")


def get_conditional_slice(index_vector, condition):
    """
    Given a 1D index vector and a condition tuple (operator, value),
    returns a slice covering all indices that satisfy the condition.
    REQUIRES: index_vector to be sorted in ascending order.
    """
    arr = np.array(index_vector)
    op_str, q = condition
    if op_str not in query_op.COMPARE_OPERATORS_MAP:
        raise ValueError(f"Unsupported operator: {op_str}")
    op_func = query_op.COMPARE_OPERATORS_MAP[op_str]
    mask = op_func(arr, q)
    matching_indices = np.where(mask)[0]
    if matching_indices.size == 0:
        raise ValueError(f"No indices satisfy condition {op_str} {q}.")
    if matching_indices.size > 1:
        warnings.warn(
            "Multiple matching indices found; returning slice covering all matches.", RuntimeWarning, stacklevel=2
        )
    start = int(matching_indices.min())
    stop = int(matching_indices.max()) + 1
    return slice(start, stop)


def get_exact_slice(index_vector, *query):
    """
    For a given 1D index vector and one or more query float values,
    returns the index (or indices) that exactly match the query values.

    The returned value is either a single integer (if one match is found)
    or a NumPy array of integers for multiple matches, suitable for NumPy indexing.

    Example usage:
      get_exact_slice(index_vector, 3.0)
      get_exact_slice(index_vector, 3.0, 4.0)
      get_exact_slice(index_vector, [3.0, 4.0])
    """
    if len(query) == 1 and isinstance(query[0], (list, tuple, np.ndarray)):
        query = query[0]
    arr = np.array(index_vector)
    matching_indices = []
    for q in query:
        idx = np.where(arr == q)[0]
        if idx.size == 0:
            raise ValueError(f"No match found for query {q}.")
        matching_indices.extend(idx)
    matching_indices = np.unique(matching_indices)
    if matching_indices.size == 1:
        return int(matching_indices[0])
    return to_slice(matching_indices)


def get_nearest_slice(index_vector, *query, mode="absolute"):
    """
    Given a 1D index vector and one or more query float values, returns the index (or indices)
    corresponding to the nearest value(s) based on the specified mode.

    Modes:
      - 'lower': nearest index with value <= query.
      - 'higher': nearest index with value >= query.
      - 'absolute': index with the smallest absolute difference.

    The returned value is either a single integer (if one match is found)
    or a NumPy array of integers for multiple matches, suitable for NumPy indexing.

    Example usage:
      get_nearest_slice(index_vector, 5.0, mode='lower')
      get_nearest_slice(index_vector, 5.0, 10.0, mode='absolute')
      get_nearest_slice(index_vector, [5.0, 10.0], mode='higher')
    """
    if len(query) == 1 and isinstance(query[0], (list, tuple, np.ndarray)):
        query = query[0]
    arr = np.array(index_vector)
    all_indices = []
    for q in query:
        exact_idx = np.where(arr == q)[0]
        if exact_idx.size > 0:
            all_indices.append(int(exact_idx[0]))
            continue
        if mode == "lower":
            candidates = np.where(arr <= q)[0]
            if candidates.size == 0:
                raise ValueError(f"No index found lower than or equal to {q}.")
            all_indices.append(int(candidates.max()))
        elif mode == "higher":
            candidates = np.where(arr >= q)[0]
            if candidates.size == 0:
                raise ValueError(f"No index found higher than or equal to {q}.")
            all_indices.append(int(candidates.min()))
        elif mode == "absolute":
            diffs = np.abs(arr - q)
            min_diff = diffs.min()
            nearest = np.where(diffs == min_diff)[0]
            if nearest.size > 1:
                warnings.warn(
                    f"Multiple indices equally near {q}; returning all matches.", RuntimeWarning, stacklevel=2
                )
                all_indices.extend(nearest)
            else:
                all_indices.append(int(nearest[0]))
        else:
            raise ValueError(f"Unsupported mode: {mode}")
    all_indices = np.unique(all_indices)
    if all_indices.size == 1:
        return int(all_indices[0])
    return to_slice(all_indices)


def slice_and(*args):
    """
    Returns the intersection (logical AND) of indices from given slices and iterables of ints.
    Any input that is either None or an unconstrained slice (slice(None)) is skipped.

    If a single operand (or a single iterable containing one operand) is passed,
    that operand is returned unchanged.

    Accepts either multiple arguments or a single iterable of such objects.
    """
    if len(args) == 1 and (not isinstance(args[0], (slice, int, type(None)))) and hasattr(args[0], "__iter__"):
        items = list(args[0])
    else:
        items = list(args)
    if len(items) == 1:
        return items[0]
    constraining_sets = []
    for item in items:
        if item is None:
            continue
        if isinstance(item, int):
            constraining_sets.append({item})
        elif isinstance(item, slice):
            if item.stop is None:
                if item.start is None and item.step is None:
                    continue
                raise ValueError("Slice stop cannot be None for finite range calculation (unless it's slice(None)).")
            start = item.start if item.start is not None else 0
            step = item.step if item.step is not None else 1
            constraining_sets.append(set(range(start, item.stop, step)))
        else:
            try:
                constraining_sets.append({int(x) for x in item})
            except Exception as e:
                raise TypeError("Invalid input. Expected a slice, None, or an iterable of integers.") from e
    if not constraining_sets:
        raise ValueError(
            "At least one constraining input is required; all inputs were unconstrained (None or slice(None))."
        )
    common = constraining_sets[0]
    for s in constraining_sets[1:]:
        common = common.intersection(s)
    return sorted(common)


get_vals_from_ufloat_arrays = np.vectorize(lambda x: x.value)
get_uncer_from_ufloat_arrays = np.vectorize(lambda x: x.stdunc)
