"""Encapsulation of all new error classes defined within the package.

The encapsulation allows the direct import of the errors at other packages as following:
```
from dcc_quantities import exceptions

raise exceptions.SiMathError(...)
```
"""

__all__ = ["NumericDomainError", "SiMathError", "UnitError"]


class UnitError(ValueError):
    r"""Invalid units were given to a function. <b>E.G.:</b> <code>sin('\metre')</code>."""


class NumericDomainError(ValueError):
    """Provided value is outside the domain for a trigonometric function."""


class SiMathError(ValueError):
    """Error raised when invalid math is detected at SI classes."""
