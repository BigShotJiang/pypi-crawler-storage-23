"""Module containing all the logic regarding the `DccQuantityType` class.

The class `DccQuantityType` is a generic container for quantity data, designed to deserialize data directly from the
XML tables.
"""

from __future__ import annotations

import uuid
import warnings
from typing import TYPE_CHECKING, ClassVar, Optional, Union

import numpy as np

from dcc_quantities.dcc_lang_name import DccLangName
from dcc_quantities.serializers._explicit_serializer_mixin import ExplicitSerializerMixin
from dcc_quantities.serializers._field_spec import FieldSpec
from dcc_quantities.si_real_list import SiRealList

if TYPE_CHECKING:
    from dsi_unit import DsiUnit

    from dcc_quantities._abc import AbstractQuantityTypeData


class DccQuantityType(ExplicitSerializerMixin):
    """Represents the `<dcc:quantity>` element, serialized in the exact order required by the
    XSD `<quantityType>` sequence.

    The class can be imported directly from the `dcc_quantities` package:
    ```
    from dcc_quantities import DccQuantityType
    ```
    """

    __serialize_fields__: ClassVar[list[FieldSpec]] = [
        FieldSpec(
            name=None,
            tag="dcc:name",
            serializer=lambda s: s.name.to_json_dict()["dcc:name"] if len(s.name) > 0 else None,
        ),
        FieldSpec("description", "dcc:description"),
        FieldSpec(name=None, tag=None, serializer=lambda s: s.data.to_json_dict(), merge=True),
        FieldSpec("relative_uncertainty", "dcc:relativeUncertainty"),
        FieldSpec("used_methods", "dcc:usedMethods"),
        FieldSpec("used_software", "dcc:usedSoftware"),
        FieldSpec("measuring_equipments", "dcc:measuringEquipments"),
        FieldSpec("measurement_meta_data", "dcc:measurementMetaData"),
        FieldSpec("id", "@id"),
        FieldSpec("ref_id", "@refId"),
        FieldSpec("ref_type", "@refType"),
        FieldSpec("index", "@index"),
    ]

    def __init__(
        self,
        data: SiRealList,
        identifier: Optional[str] = None,
        ref_id: Optional[list[str]] = None,
        ref_type: Optional[list[str]] = None,
        name: Optional[dict | DccLangName] = None,
        description: Optional[dict] = None,
        relative_uncertainty: Optional[str] = None,
        used_methods: Optional[dict] = None,
        used_software: Optional[dict] = None,
        measuring_equipments: Optional[dict] = None,
        measurement_meta_data: Optional[dict] = None,
        index: Optional[str] = None,
    ) -> None:
        """

        Parameters
        ----------
        data: SiRealList
            Numerical quantity data. It contains all the values, uncertainties and D-SI unit corresponding to the
            DCC quantity.
            Currently only [`SiRealList`](si_real_list.md#SiRealList) is supported as data.
        identifier: str, optional
            Unique string identifier for the quantity. If not defined, the identifier is initialized to a unique UUID
            value.
        name
            Mapping from the supported languages to the names (in those languages) that were given to the table.
        description
            Mapping, analogous to 'name', where each value corresponds to the same description in the specified
            language by the key.
        """
        self.data = data
        if name is None:
            name = DccLangName({})
        elif isinstance(name, dict):
            name = DccLangName(name)
        self.name = name
        self.description = description
        self.relative_uncertainty = relative_uncertainty
        self.used_methods = used_methods
        self.used_software = used_software
        self.measuring_equipments = measuring_equipments
        self.measurement_meta_data = measurement_meta_data
        self.id = identifier or f"U{uuid.uuid4()}"
        self.index = index

        if ref_id is None:
            ref_id = []
        if not isinstance(ref_id, list):
            ref_id = [ref_id]
        self.ref_id = ref_id

        if ref_type is None:
            ref_type = []
        if not isinstance(ref_type, list):
            ref_type = [ref_type]
        self.ref_type = ref_type

    def __eq__(self, other: DccQuantityType) -> bool:
        # todo: A correct 'eq' would also check the units are 'equal' (ignoring the scaling factor)
        return self.data == other.data

    def __hash__(self) -> str:
        return hash(self.id)

    def set_label(self, label: str):
        """Updates the field 'label' used for the quantity data.

        Parameters
        ----------
        label : str
            New label to override the previous one. This is usually represented with a letter (like 'f' for
            'Frequency') or a symbol (Unicode character) like 'λ'.
        """
        self.data.label = label

    def set_name(self, name: str | dict, language: Optional[str] = None):
        """Updates the field 'name' used for the quantity data.

        This function overwrites any existing name(s) at the specified language(s), while keeping all other
        existing names.

        Parameters
        ----------
        name : str | dict
            String specifying the new name to add or update from the `DccLangName` instance containing all names.
            It can also be a dictionary following the structure `{language: name}`, where:
            <ul>
                <li>`language` follows the same rules as the `language` parameter at this method.</li>
                <li>The dictionary can contain as many entries as required.</li>
            </ul>
        language : str
            Two letters in lowercase indicating the language of the name. E.G.: 'en' for 'English' or 'de' for
            'Deutsch'. This parameter is ignored when `name` is a dictionary, but must be provided when `name` is a
            string.
        """
        if isinstance(name, str):
            if language is None:
                raise ValueError(f"New name '{name}' cannot be set, as no language was specified.")
            self.name[language] = name
        elif isinstance(name, (dict, DccLangName)):
            self.name |= DccLangName(name) if isinstance(name, dict) else name
        else:
            raise TypeError(f"Invalid type '{type(name)}' for parameter 'name'.")

    @classmethod
    def from_single_quantity_value(
        cls,
        name: str | dict[str, str],
        value: int | float,
        uncertainty: int | float,
        unit: str | DsiUnit,
        label: Optional[str] = None,
    ) -> DccQuantityType:
        """Creating a DccQuantity instance with a single value.

        Parameters
        ----------
        name : str or dict
            Name of the Quantity to be created, specified as:
                - A single string in English
                - A dictionary {lang: name} with as many entries as desired
        value : number
            The value related with the Quantity.
        uncertainty : number
            The uncertainty correlated with the value.
        unit : str or DsiUnit
            The unit of the quantity, specified as the DsiUnit rules.
        label : str, optional
            Used label to identify the data. This label can be either a word, a character or a symbol.
        """
        if isinstance(name, str):
            name = {"en": name}
        return cls(name=name, data=SiRealList(data=([value], [uncertainty]), unit=unit, label=label))

    def __str__(self) -> str:
        """String representation with the name of the quantity and its values."""
        q_name = str(self.name)
        q_name = "" if "No Name" in q_name else q_name.rsplit(": ", maxsplit=1)[-1]
        if self.data.label is not None and len(self.data.label) > 0:
            if len(q_name) == 0:
                q_name = self.data.label
            else:
                q_name += f" '{self.data.label}'"
        len_str = ""
        if len(self) > 1:
            len_str = f" (len={len(self)})"
        return f"{q_name}{len_str}: {self.data} {self.data.unit}"

    def _new_instance(
        self, new_data: AbstractQuantityTypeData, names: Optional[Union[str, dict]] = None
    ) -> DccQuantityType:
        """
        Create a new instance of DccQuantityType using the new_data and
        the provided names (which is generated entirely by mergeNames).
        """
        return DccQuantityType(
            data=new_data, identifier="U" + str(uuid.uuid4()), ref_id=self.ref_id, ref_type=self.ref_type, name=names
        )

    def __getitem__(self, index: int):
        new_data = self.data.__getitem__(index)
        if len(new_data) == 0:
            if isinstance(index, (list, tuple)) and all((isinstance(item, bool) for item in index)):
                new_data = self.data.__getitem__(np.array(index))
            else:
                new_data = self.data.__getitem__(np.array(index))
                if len(new_data) == 0:
                    warnings.warn(
                        f"Tried backup indexing {self} with index casted to np.array {np.array(index)!s} but "
                        "still got nothing back. Maybe indexing is wrong",
                        RuntimeWarning,
                        stacklevel=2,
                    )
        if self.name is not None:
            if isinstance(self.name, DccLangName):
                new_name_data = self.name.data
            else:

                def format_slice(idx: slice | int) -> str:
                    if isinstance(idx, slice):
                        start, stop = idx.start or "", idx.stop or ""
                        step = f":{idx.step}" if idx.step is not None else ""
                        return f"[{start}:{stop}{step}]"
                    return f"[{index}]"

                if isinstance(self.name, dict):
                    new_name_data = {lang: f"{name_val}{format_slice(index)}" for lang, name_val in self.name.items()}
                else:
                    new_name_data = f"{self.name}{format_slice(index)}"
        else:
            new_name_data = None
        return self._new_instance(new_data, names=new_name_data)

    def __len__(self) -> int:
        """Number of elements within the 'data' field."""
        return len(self.data)

    def __neg__(self) -> DccQuantityType:
        """Unary operator '-', which negates values at the data, as well as the negated name."""
        return self._new_instance(-self.data)

    def __pos__(self) -> DccQuantityType:
        return self._new_instance(+self.data)

    def __add__(self, other) -> DccQuantityType:
        """Sum operator `+` to allow `self + other`."""
        return self._new_instance(new_data=self.data + (other.data if isinstance(other, DccQuantityType) else other))

    def __radd__(self, other) -> DccQuantityType:
        return self.__add__(other)

    def __sub__(self, other) -> DccQuantityType:
        """Subtract operator `-` to allow `self - other`."""
        return self._new_instance(new_data=self.data - (other.data if isinstance(other, DccQuantityType) else other))

    def __rsub__(self, other) -> DccQuantityType:
        return self._new_instance(new_data=(other.data if isinstance(other, DccQuantityType) else other) - self.data)

    def __mul__(self, other) -> DccQuantityType:
        return self._new_instance(new_data=self.data * (other.data if isinstance(other, DccQuantityType) else other))

    def __rmul__(self, other) -> DccQuantityType:
        return self.__mul__(other)

    def __truediv__(self, other) -> DccQuantityType:
        return self._new_instance(new_data=self.data / (other.data if isinstance(other, DccQuantityType) else other))

    def __rtruediv__(self, other) -> DccQuantityType:
        return self._new_instance(new_data=(other.data if isinstance(other, DccQuantityType) else other) / self.data)

    def __pow__(self, other) -> DccQuantityType:
        return self._new_instance(new_data=self.data ** (other.data if isinstance(other, DccQuantityType) else other))

    @property
    def values(self) -> np.ndarray:
        """All values without the uncertainties of the quantity data as a numpy array."""
        return self.data.values

    @property
    def uncertainties(self) -> np.ndarray:
        """All uncertainties of the quantity data as a numpy array."""
        return self.data.uncertainties

    @property
    def dsi_unit(self) -> DsiUnit:
        """Unit that is defined for the quantity data."""
        return self.data.unit

    @property
    def sorted(self):
        return self.data.sorted

    @property
    def shape(self) -> tuple:
        return self.data.shape

    def reshape(self, *newshape: tuple[int, ...]) -> None:
        self.data.reshape(newshape)

    def to_json_dict(self) -> dict:
        # """Wrap the ordered fields under the <dcc:quantity> root."""
        return self._to_dict()

    # todo: method to simplify the units to the base units, returning a new Quant instance.
