"""Module containing all the logic regarding only the `SiRealList` class.

The `SiRealList` class is a container for _quantity data_, which important information is:
<ul>
    <li><b>Quantity data array</b> or quantity data, where all the values and uncertainties of the quantity are stored.
        This corresponds to the `data` parameter at the constructor.</li>
    <li><b>D-SI Unit</b>, composed by the `dsi_unit.DsiUnit` instance.</li>
</ul>
"""

from __future__ import annotations

import math
import warnings
from copy import deepcopy
from typing import TYPE_CHECKING, Callable, ClassVar, Iterable, Optional, Sequence, TypeVar

import numpy as np
from dsi_unit import DsiUnit
from metas_unclib import get_stdunc, get_value, ucomplex, ufloat

from dcc_quantities._abc import AbstractValueType
from dcc_quantities._helpers import ensure_list, get_uncer_from_ufloat_arrays, get_vals_from_ufloat_arrays
from dcc_quantities.exceptions import SiMathError
from dcc_quantities.parse_uncertainties import parse_uncertainties, uncertainty_keys
from dcc_quantities.serializers._explicit_serializer_mixin import ExplicitSerializerMixin
from dcc_quantities.serializers._field_spec import FieldSpec

if TYPE_CHECKING:
    import numbers
    from datetime import datetime

    T = TypeVar("T")


class SiRealList(ExplicitSerializerMixin, AbstractValueType):
    __single_specs__: ClassVar[list[FieldSpec]] = [
        FieldSpec("label", "si:label", lambda s: s.label[0] if isinstance(s.label, list) else s.label),
        FieldSpec(None, "si:value", "serialize_value", merge=False),
        FieldSpec("unit", "si:unit", lambda s: str(s.unit)),
        FieldSpec(
            "date_time", "si:dateTime", lambda s: s.date_time[0] if isinstance(s.date_time, list) else s.date_time
        ),
        FieldSpec(None, "si:measurementUncertaintyUnivariate", "serialize_unc", merge=True),
    ]
    __list_specs__: ClassVar[list[FieldSpec]] = [
        FieldSpec("label", "si:labelXMLList", lambda s: s.label),
        FieldSpec(None, "si:valueXMLList", "serialize_value", merge=False),
        FieldSpec("unit", "si:unitXMLList", lambda s: str(s.unit)),
        FieldSpec("date_time", "si:dateTimeXMLList", lambda s: s.date_time),
        FieldSpec(None, "si:measurementUncertaintyUnivariateXMLList", "serialize_unc", merge=True),
    ]

    def __init__(
        self,
        data: Iterable[numbers.Real | ufloat | Iterable[numbers.Real | ufloat]] | dict[str, list],
        unit: str | DsiUnit,
        label: Optional[str] = None,
        date_time: Optional[list[datetime]] = None,
        _origin_type: str = "si:realListXMLList",
        _unc_info: Optional[dict] = None,
    ) -> None:
        """Representation of si:reaListXMLList, SiRsi:real, si:constant

        Parameters
        ----------
        data : Array Like
            Quantity data array, defined as values defined their uncertainties. The provided data should match one
            of the following formats:
            <ol>
                <li>Iterable of 2 same-length arrays: <b><i>([value0, value1, ...], [unc0, unc1, ...])</i></b></li>
                <li>Iterable of length N, where each item contains the value and uncertainty:<br>
                    <b><i>[(val0, unc0), (val1, unc1), ...]</i></b></li>
                <li>Dictionaries with the keys 'value' and 'unc' with iterables with the values and uncertainties.</li>
                <li>Iterable of length N, where each item contains the value of the element (no uncertainties).</li>
            </ol>
        unit : DsiUnit
            D-SI unit that corresponds to the quantity data; unit for every single value of the data array.
        label : str
            String value to be used as an identifier of the data. This is usually represented as a character or a
            symbol to be correlated in mathematical equations.
        date_time
            Timestamp in which the values where measured.
        """
        if isinstance(unit, list):
            warnings.warn(
                "List of units are deprecated and will fail in the future. The first unit will be consider as "
                "the common unit for all existing values.",
                category=DeprecationWarning,
                stacklevel=2,
            )
            unit = unit[0]
        if isinstance(unit, str):
            unit = DsiUnit(unit)
        super().__init__(label, unit, date_time, _origin_type=_origin_type, _unc_info=_unc_info)
        self.unit: DsiUnit
        if isinstance(self.label, list):
            warnings.warn(
                "List of label are deprecated and will fail in the future. The first unit will be consider as "
                "the common unit for all existing values.",
                category=DeprecationWarning,
                stacklevel=2,
            )
            self.label = self.label[0]
        self.data = self.parse_data(data)
        self._sorted = None
        if _origin_type in {"si:real", "si:constant"}:
            if len(self.data) != 1:
                warnings.warn(
                    f"Data of length {len(data)} can't have come from type {_origin_type}"
                    'Setting type to "si:realList"',
                    RuntimeWarning,
                    stacklevel=2,
                )
                self._origin_type = "si:RealListXMLList"
        elif _origin_type == "si:realListXMLList":
            pass
        else:
            warnings.warn(
                f"Type {_origin_type} not known - do expect xml export to fail.", RuntimeWarning, stacklevel=2
            )
        if self.date_time and len(self.date_time) not in {1, len(self.data)}:
            raise ValueError("Length of dateTime list must be 1 or match length of data list!")

    def __len__(self) -> int:
        """Number of elements (value and uncertainty) in the data array."""
        return len(self.data)

    def __repr__(self) -> str:
        """Representation of the class. It calls AbstractQuantityTypeData.__repr__()"""
        return f"SiRealList({super().__repr__()})"

    def __str__(self) -> str:
        """Numpy representation of the elements."""
        return str(np.asarray(self.data))

    def __eq__(self, other: SiRealList | Sequence[ufloat | numbers.Real | np.number]):
        """Checking whether all values are mathematically indistinguishable.

        The `==` operator will check whether the values (stored at `self.data`) have the same values as the ones
        being compared. 'Having the same values' is being defined as:

            - Both sequences have the same length.
            - For each item in the sequence, the real value is the same (considering scaling).
            - For each item in the sequence, the uncertainty value is the same (considering scaling).

        Only when all conditions above are true, it will be considered that the current SiRealList instance has the
        same value as the 'other' instance.
        """
        if isinstance(other, SiRealList):
            scale = self.get_scale_factor(other)
            if math.isnan(scale):
                return False  # Non scalable
            other = other.data
        else:
            scale = 1

        self_flatten_data = np.asarray(self.data).flatten()
        other_flatten_data = np.asarray(other).flatten()
        if len(self_flatten_data) != len(other_flatten_data):
            return False

        def _are_same_type(a, b, instance: object | tuple[object, ...]):
            return isinstance(a, instance) and isinstance(b, instance)

        for item, other_item in zip(self_flatten_data, other_flatten_data):
            # Normalizing numpy values:
            item_val = item.item() if isinstance(item, np.number) else item
            other_val = other_item.item() if isinstance(other_item, np.number) else other_item

            if _are_same_type(item_val, other_val, ufloat):
                unc_is_same = math.isclose(get_stdunc(item_val), get_stdunc(other_val) * scale)
                item_val = get_value(item_val)
                other_val = get_value(other_val)
            elif _are_same_type(item_val, other_val, (int, float)):
                unc_is_same = True
            else:
                # The value of the items is not directly comparable.
                # This case also considers complex numbers.
                return False

            value_is_same = (
                math.isclose(item_val, other_val * scale, rel_tol=1e-4)
                or (math.isnan(item_val) and math.isnan(other_val))
                or (math.isinf(item_val) and math.isinf(other_val))
            )

            if not (value_is_same and unc_is_same):
                return False

        return True

    def __hash__(self) -> str:
        r"""Hashable value of the class, created considering all the parameters.

        Note that while a data sequence of [1, 2, 3] with unit '\volt' and another sequence of [1000, 2000, 3000]
        with unit '\\milli\volt' technically have the same value (defined by the `__eq__` method), they would have
        different hashes.
        """
        return hash(self.__repr__())

    def get_scale_factor(self, other: SiRealList | DsiUnit) -> float:
        """Returns the scale of the current unit to a different one."""
        if isinstance(other, SiRealList):
            other = other.unit
        return self.unit.get_scale_factor(other)

    def to_json_dict(self):
        if self._origin_type in {"si:real", "si:constant"}:
            if any(
                (
                    isinstance(val, (list, np.ndarray)) and len(val) > 1
                    for val in (self.data, self.label, self.unit, self.date_time)
                    if val is not None
                )
            ):
                specs, root = (self.__list_specs__, "si:realListXMLList")
            else:
                specs = self.__single_specs__
                root = "si:constant" if self._origin_type == "si:constant" else "si:real"
        else:
            specs, root = (self.__list_specs__, "si:realListXMLList")
        self.__serialize_fields__ = specs
        ordered = self._to_dict()
        del self.__serialize_fields__
        return {root: ordered}

    def serialize_value(self):
        """Return just the flattened 'si:value' or 'si:valueXMLList' entry from `serialize_data_to_json()`."""
        if not hasattr(self, "_data"):
            self._data = self.serialize_data_to_json()
        for key, val in self._data.items():
            if key.startswith("si:value"):
                return val
        return None

    def serialize_unc(self):
        """
        Return only the uncertainty sub-dict (everything *except* the 'si:value…'
        keys) from serialize_data_to_json(), so it merges in the correct position.
        """
        if not hasattr(self, "_data"):
            self._data = self.serialize_data_to_json()
        for key in list(self._data.keys()):
            if key.startswith("si:value"):
                self._data.pop(key)
        out = deepcopy(self._data)
        del self._data
        return out

    def __neg__(self) -> SiRealList:
        """Negation of the data from the instance. The returned instance will have same unit and no label."""
        return SiRealList(data=[-item for item in self.data], unit=self.unit, date_time=self.date_time)

    def __pos__(self) -> SiRealList:
        """Unary operator '+', which returns a new instance with the same parameters."""
        return SiRealList(data=self.data, unit=self.unit, date_time=self.date_time)

    def _perform_generic_math_operation(self, other: T, math_key: Callable[[np.array, T], np.ndarray]) -> np.ndarray:
        """Logic for generic math operations with 'self.data'.

        Parameters
        ----------
        other : Generic type
            Any no SiRealList instance, such as non-complex numbers, sequences and arrays.
        math_key : callable
            Math operation to be used as 'math_key(self.data, other)'. For example, 'lambda a, b: a + b' is a valid
            callable for addition.

        Returns
        -------
        result_data : np.array
            Array with the final values of the operation. Beware, it could be possible for this array to have complex
            values (depending on the math operation).

        Raises
        ------
        SiMathError
            - If 'other' is a sequence or array with a length different to 1 or to 'len(self.data)'.
            - If 'other' is a non-supported type. For example, the 'complex' type.
        """
        if isinstance(other, (int, float, np.integer, np.floating, ufloat)):
            # 'self.data' is a numpy array. 'other' is automatically broadcasted to the correct type.
            result_data = math_key(self.data, other)
        elif isinstance(other, (list, tuple, np.ndarray)):
            if len(other) == 1:
                other = other[0]
            elif self.shape != np.asarray(other).shape:
                raise SiMathError(f"Invalid math for arrays with shapes '{self.shape}' and '{np.asarray(other).shape}'")
            else:
                other = np.asarray(other)
            result_data = math_key(self.data, other)
        else:
            raise SiMathError(f"Unsupported type '{type(other)}' for math operations.")
        return result_data

    def __add__(self, other: T) -> SiRealList:
        """Performs the sum of the current data with other, using the '+' operator.

        Only the data of the instance is modified. Other parameters (like the label) are kept as the one from
        the original instance at the left of the operator.
        Different units and scale factors are also considered for operations with multiple SiRealLists.
        """
        try:
            if isinstance(other, SiRealList):
                scale = self.get_scale_factor(other)
                if math.isnan(scale):
                    raise SiMathError("Only quantities with the same unit can be added.")
                other = other.data * scale
            result_data = self._perform_generic_math_operation(other, math_key=lambda a, b: a + b)
        except SiMathError as err:
            raise SiMathError("SiRealList addition failed. See the error above for more information.") from err
        return SiRealList(data=result_data, unit=self.unit, date_time=self.date_time)

    def __radd__(self, other: T) -> SiRealList:
        """Right add operator, invoked when the left operand is not a SiRealList instance."""
        return self + other

    def __sub__(self, other: T) -> SiRealList:
        """Performs the sum of the current data with other, using the '-' operator.

        Only the data of the instance is modified. Other parameters (like the label) are kept as the one from
        the original instance at the left of the operator.
        Different units and scale factors are also considered for operations with multiple SiRealLists.
        """
        # Normalizing types to those that allow unary neg operator.
        if isinstance(other, (list, tuple)):
            other = np.asarray(other)
        try:
            return self + -other
        except SiMathError as err:
            raise SiMathError(str(err).replace("addition", "subtraction")) from err

    def __rsub__(self, other: T) -> SiRealList:
        """Right subtract (-) operator, invoked when the left operand is not a SiRealList instance."""
        return -self + other

    def __mul__(self, other: T) -> SiRealList:
        """Logic for multiplying with the '*' operator.

        By multiplying, both the data values and the unit (if applied) are modified.
        """
        result_unit = self.unit
        try:
            if isinstance(other, SiRealList):
                result_unit *= other.unit
                other = other.data * result_unit.scale_factor
                result_unit.scale_factor = 1.0
            result_data = self._perform_generic_math_operation(other, math_key=lambda a, b: a * b)
        except SiMathError as err:
            raise SiMathError("SiRealList multiplication failed. See the error above for more information.") from err
        return SiRealList(data=result_data, unit=result_unit, date_time=self.date_time)

    def __rmul__(self, other: T) -> SiRealList:
        """Logic to multiply by the right. The order should not alter the final result."""
        return self * other

    def __pow__(self, other: T) -> SiRealList:
        """Logic to perform 'SiRealList power to other' with the '**' operator."""

        def _all_values_are_equal(iterator: Iterable):
            """Check for all values to be the same in an iterable. It is assumed the iterable has at least 2 items."""
            it = iter(iterator)
            first = next(it)
            return all(math.isclose(first, num) for num in it)

        # The first two conditions normalize 'other' to either a single number or a sequence with a single value.
        if isinstance(other, SiRealList):
            if not other.unit.is_adimensional:
                raise SiMathError(
                    "The 'power to the' operation is only allower to another SiRealList instance with unit 'one'."
                )
            other = other.data * other.unit.scale_factor
        if isinstance(other, (tuple, list, np.ndarray)):
            if len(other) > 1 and not _all_values_are_equal(other):
                raise SiMathError(
                    "Power to an array of different values is not allowed, as this would result in an array with"
                    " different units."
                )
            other = other[0]

        try:
            result_data = self._perform_generic_math_operation(other, math_key=lambda a, b: a**b)
        except (SiMathError, ValueError) as err:
            raise SiMathError("SiRealList power operator failed. See the error above for more information.") from err

        if any(isinstance(d, (complex, ucomplex)) for d in result_data):
            raise NotImplementedError("SiComplexList is not yet supported.")

        result_unit = self.unit**other
        return SiRealList(data=result_data, unit=result_unit, date_time=self.date_time)

    def __truediv__(self, other: T) -> SiRealList:
        """Logic to operate 'SiRealList / other'."""
        result_unit = self.unit
        try:
            if isinstance(other, SiRealList):
                result_unit /= other.unit
                other = other.data / result_unit.scale_factor
                result_unit.scale_factor = 1
            result_data = self._perform_generic_math_operation(other, math_key=lambda a, b: a / b)
        except SiMathError as err:
            raise SiMathError("SiRealList division operator failed. See the error above for more information.") from err
        return SiRealList(data=result_data, unit=result_unit, date_time=self.date_time)

    def __rtruediv__(self, other: numbers.Real | ufloat | list | tuple | np.ndarray) -> SiRealList:
        """Logic to operate 'other / SiRealList', where 'other' is not a SiRealList instance."""
        return self ** (-1) * other

    def __getitem__(self, index: int) -> SiRealList:
        """
        Return a new SiRealList instance containing only the elements specified by `index`.
        Supports all nD indexing types including int, slice, list/array of indices, and boolean indexing.

        If an attribute (label, unit, dateTime) is stored as a list of length 1, it is assumed
        to be universal and is not sub-indexed.
        """

        def subset_attr(attr):
            if attr is None:
                return None
            if len(attr) == 1:
                return attr
            try:
                arr = np.array(attr, dtype=object)
                sub = arr[index]
            except Exception as e:
                raise IndexError(f"Error indexing attribute {attr}: {e}") from e
            if isinstance(sub, np.ndarray):
                return list(sub)
            return [sub]

        new_data = self.data[index]
        if not isinstance(new_data, np.ndarray):
            new_data = [new_data]
        new_label = subset_attr(self.label)
        new_date_time = subset_attr(self.date_time)
        return SiRealList(
            data=new_data, label=new_label, unit=self.unit, date_time=new_date_time, _origin_type=self._origin_type
        )

    @property
    def values(self) -> np.ndarray:
        """Returns a NumPy array of just the numerical values extracted from the data."""
        if np.issubdtype(self.data.dtype, np.number):
            return self.data
        return get_vals_from_ufloat_arrays(self.data)

    @property
    def uncertainties(self) -> np.ndarray:
        """Returns a NumPy array of just the uncertainties extracted from the data."""
        if np.issubdtype(self.data.dtype, np.number):
            raise AttributeError("This siRealList doesn't has any uncer associated!")
        return get_uncer_from_ufloat_arrays(self.data)

    @property
    def shape(self) -> tuple:
        """Return the shape of the underlying data array."""
        return self.data.shape

    @property
    def sorted(self) -> bool:
        if self._sorted is None:
            try:
                self._sorted = all((self.values[i] <= self.values[i + 1] for i in range(len(self.values) - 1)))
            except ValueError as e:
                warnings.warn(
                    f"sorted is only implemented for 1D data. Returning False: {e}", RuntimeWarning, stacklevel=2
                )
                self._sorted = False
        return self._sorted

    def reshape(self, *newshape) -> None:
        """
        Reshape the SiRealList in-place to the given new shape.
        Accepts newshape as separate integers or as a single tuple/list.
        """
        if len(newshape) == 1 and isinstance(newshape[0], (tuple, list)):
            newshape = tuple(newshape[0])
        else:
            newshape = tuple(newshape)
        self.data = np.reshape(self.data, newshape)

        def reshape_attr(attr):
            if attr is None or len(attr) == 1:
                return attr
            return list(np.reshape(np.array(attr, dtype=object), newshape))

        self.date_time = reshape_attr(self.date_time)

    @staticmethod
    def parse_data(data: T) -> np.ndarray[ufloat]:
        """Parsing the data as a numpy array with uncertainties.

        The data must follow one of the next structures:
        <ol>
            <li><b><i>[real_0, real_1, ..., real_n]</i></b><br>
                A sequence of all real values. No uncertainty is defined here.</li>
            <li><b><i>[(real_0, unc_0), (real_1, unc_1), ..., (real_n, unc_n)]</i></b><br>
                A sequence of tuples where each item contains the real value and its uncertainty in this order.</li>
            <li><b><i>[(real_0, real_1, ..., real_n), (unc_0, unc_1, ..., unc_n)]</i></b><br>
                A sequence of two tuples. The first one contains all the real values, the second with all the
                uncertainties matched by index to the real values.</li>
            <li><b><i>{'value': [real_0, real_1, ..., real_n], 'unc': [unc_0, unc_1, ..., unc_n]}</i></b><br>
                A dictionary with the keys 'value' and 'unc', where the data is structured analogously to structure 3.
                </li>
        </ol>
        """
        # 1: Normalizing the data to a sequence of values:
        if isinstance(data, np.ndarray):
            data = data.tolist()
        elif isinstance(data, dict):
            if "values" not in data or "uncs" not in data:
                raise ValueError("Could not parse data as keys do not match. Accepted keys are 'values' and 'uncs'.")
            # Converting struc-4 into struct-3
            data = [data["values"], data["uncs"]]

        def _valid_numeric_type(v: T) -> float:
            return isinstance(v, (float, int, ufloat, np.integer, np.floating))

        # Checking the generic sequence types:
        if isinstance(data, Sequence):
            # Struct-1: Sequence of values without uncertainties.
            if any(isinstance(v, (complex, ucomplex)) for v in data):
                raise ValueError("Only real values are allowed in SiRealList, but complex values were provided.")
            if all(_valid_numeric_type(v) for v in data):
                data = np.array(data)
            # Struct-3: Sequence of separated values and uncertainties.
            elif len(data) == 2 and len(data[0]) == len(data[1]):
                if len(data[0]) == 2:
                    warnings.warn(
                        "The parsed data is ambiguous, as it could be either `[(val_0, val_1), (unc_0, unc_1)]` or "
                        "`[(val_0, unc_0), (val_1, unc_1)]`. The software assumes the first case is provided. Parse"
                        "the data in a dict structure `{'values': [...], 'uncs': [...]}` to avoid this warning.",
                        stacklevel=2,
                    )
                for values in data:
                    if any(not _valid_numeric_type(v) for v in values):
                        raise ValueError(
                            "Data does not conform to structure: "
                            "'[(real_0, real_1, ..., real_n), (unc_0, unc_1, ..., unc_n)]'"
                        )
                data = np.array([ufloat(value=value, stdunc=unc) for value, unc in zip(data[0], data[1])])
            # Struct-2: Sequence with tuples of 2 values (val + unc)
            elif all(len(item) == 2 and all(_valid_numeric_type(v) for v in item) for item in data):
                data = np.array([ufloat(value=value, stdunc=unc) for (value, unc) in data])
            else:
                raise ValueError("Unrecognized sequence of values")
        else:
            raise ValueError("Parsed data does not conform to any structure")

        return data


def parse_si_real_value(json_dict: dict, relative_uncertainty: Optional[dict] = None):
    si_real_list_args = {"_origin_type": "si:real"}
    if "si:label" in json_dict:
        si_real_list_args["label"] = ensure_list(json_dict["si:label"])
    si_real_list_args["unit"] = ensure_list(json_dict["si:unit"])
    if "si:dateTime" in json_dict:
        si_real_list_args["date_time"] = ensure_list(json_dict["si:dateTime"])
    data = ensure_list(json_dict["si:value"])
    si_real_list_args["data"], si_real_list_args["_unc_info"] = parse_uncertainties(
        json_dict=json_dict, data=data, relative_uncertainty=relative_uncertainty
    )
    unsupported_keys = {"si:label", "si:value", "si:unit", "si:dateTime", "@_Comment"} | set(uncertainty_keys)
    for key in json_dict:
        if key not in unsupported_keys:
            warnings.warn(f"Unsupported key for si:real: {key}", RuntimeWarning, stacklevel=2)
    return SiRealList(**si_real_list_args)


def parse_const(json_dict: dict, relative_uncertainty: Optional[dict] = None):
    si_real_list_args = {"_origin_type": "si:constant"}
    data = ensure_list(json_dict["si:value"])
    si_real_list_args["data"], si_real_list_args["_unc_info"] = parse_uncertainties(
        json_dict=json_dict, data=data, relative_uncertainty=relative_uncertainty
    )
    si_real_list_args["unit"] = ensure_list(json_dict["si:unit"])
    if "si:label" in json_dict:
        si_real_list_args["label"] = ensure_list(json_dict["si:label"])
    if "si:dateTime" in json_dict:
        si_real_list_args["date_time"] = ensure_list(json_dict["si:dateTime"])
    if "si:distribution" in json_dict:
        si_real_list_args["distribution"] = ensure_list(json_dict["si:distribution"])
    unsupported_keys = {"si:label", "si:value", "si:unit", "si:dateTime", "si:distribution", "@_Comment"} | set(
        uncertainty_keys
    )
    for key in json_dict:
        if key not in unsupported_keys:
            warnings.warn(f"Unsupported key for si:constant: {key}", RuntimeWarning, stacklevel=2)
    return SiRealList(**si_real_list_args)


def parse_real_list_xml_list(json_dict: dict, relative_uncertainty: Optional[dict] = None):
    si_real_list_args = {"_origin_type": "si:realListXMLList", "unit": ensure_list(json_dict["si:unitXMLList"])}
    if "si:labelXMLList" in json_dict:
        si_real_list_args["label"] = ensure_list(json_dict["si:labelXMLList"])
    if "si:dateTimeXMLList" in json_dict:
        si_real_list_args["date_time"] = ensure_list(json_dict["si:dateTimeXMLList"])
    data = ensure_list(json_dict["si:valueXMLList"])
    si_real_list_args["data"], si_real_list_args["_unc_info"] = parse_uncertainties(
        json_dict=json_dict, data=data, relative_uncertainty=relative_uncertainty
    )
    unsupported_keys = {
        "si:valueXMLList",
        "si:unitXMLList",
        "si:labelXMLList",
        "si:dateTimeXMLList",
        "@_Comment",
    } | set(uncertainty_keys)
    for key in json_dict:
        if key not in unsupported_keys:
            warnings.warn(f"Unsupported key for si:realXMLList: {key}", RuntimeWarning, stacklevel=2)
    return SiRealList(**si_real_list_args)
