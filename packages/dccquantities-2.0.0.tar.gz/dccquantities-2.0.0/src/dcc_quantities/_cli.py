"""Functions to be invoked from the command line interface."""

import argparse
import subprocess
import webbrowser
from pathlib import Path


def deploy_local_docs():
    """Deployment of local documentation.

    The deployment consists of:
        1. Searching if the document folder exists.
        2. Creating the documentation files when the folder doesn't exist or when '--force' is provided.
        3. Open the documentation on the default HTML viewer.
    """
    parser = argparse.ArgumentParser(
        description="Deployment of local documentation at folder 'public/'. Make sure to have installed the "
        "package as `pip install .[docs]`"
    )
    parser.add_argument("--force", action="store_true", help="Rebuilding the whole documentation.")
    parser.add_argument("--no-show", action="store_true", help="Don't show the documentation once it is built.")
    args = parser.parse_args()

    docs_folder_path = Path("public")

    if not docs_folder_path.exists() or args.force:
        print("Building documentation...")
        subprocess.run("mkdocs build", check=True)
    if not args.no_show:
        home_path = docs_folder_path / "index.html"
        webbrowser.open(home_path)
