from __future__ import annotations

import dataclasses as dtc
from typing import Callable, Optional


@dtc.dataclass
class FieldSpec:
    """Definition of fields specification for the DCC serialization.

    Attributes
    ----------
    name : str
        Name of the attribute to serialize.
    tag : str
        XML tag correlated to the 'name' parameter.
    serializer : callable, str
        Callback to run for serialization.
    merge : bool, default = False
        Flag defining if the serializer expects a dictionary to merge.
    """

    name: str
    tag: str
    serializer: Optional[Callable] = None
    merge: bool = False
