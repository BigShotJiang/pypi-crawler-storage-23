"""General parser functions to be applied over XML files."""

from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Literal, Mapping, Optional, Sequence, TypeVar, overload

from dccXMLJSONConv.dccConv import XMLToDict

from dcc_quantities.serializers.dcc_element_key import DccElementKey

if TYPE_CHECKING:
    from dcc_quantities import DccQuantityType
    from dcc_quantities.dcc_quantity_table import DccQuantityTable

    T = TypeVar("T")
    DccType = TypeVar("DccType", DccQuantityTable, DccQuantityType)


def _compile_matchers_in_obj(obj: T) -> T | Mapping | list | str:
    """Recursive object rule-compiler that leaves Callables, Matchers and compiled Regex unchanged."""
    if isinstance(obj, dict):
        return {k: _compile_matchers_in_obj(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_compile_matchers_in_obj(item) for item in obj]
    if isinstance(obj, str):
        return re.compile(obj)
    # Leave callables, compiled regex, and other objects unchanged
    return obj


def _apply_matcher(matcher: re.Pattern | Callable, value: T) -> bool:
    """Apply a matcher (regex or callable) to a value."""
    if callable(matcher) and not hasattr(matcher, "match"):
        # It's a custom function matcher
        return bool(matcher(value))
    if hasattr(matcher, "match"):
        # It's a compiled regex pattern
        return bool(matcher.match(str(value)))
    # Fallback: direct equality check
    return matcher == value


def _should_include_list_item(item: T, attribute_matchers: dict) -> bool:
    """Determine if a list item should be included based on attribute matchers."""
    if (not attribute_matchers) or (not isinstance(item, dict)):
        return True

    for attribute, matcher_list in attribute_matchers.items():
        if attribute not in item:
            continue

        attr_values = item[attribute]

        # Ensure we have a list to iterate over
        if not isinstance(attr_values, list):
            attr_values = [attr_values]

        # Check if any matcher matches any of the attribute values
        for matcher in matcher_list:
            for attr_val in attr_values:
                if _apply_matcher(matcher, attr_val):
                    return True
    return False


def dcc_type_collector(
    dcc_data: dict | list,
    search_keys: Sequence[DccElementKey],
    recursive: bool = False,
    attribute_matchers: Optional[Mapping] = None,
    compile_attributes: bool = True,
) -> list[tuple[list[str], DccType]]:
    """Searches a JSON-like dict for keys in search_keys.

    Parameters
    ----------
    dcc_data :
        Serialized DCC data. This can either be a dictionary (extracted directly from the XML) or a sequence of the
        DCC elements. Any sequence is then converted to a dictionary, where the keys are the numerical index
        corresponding to the position of each element in the sequence.
    search_keys :
        Element keys to search within the json dictionary to be extracted.
    recursive :
        Whether the data to collect is recursive.
    attribute_matchers :
        Rules that define how each XML descriptor should be interpreter by the collector. Each rule must
        be defined as:
            - Compiled regex patterns (re.Pattern objects)
            - String patterns (will be compiled to regex)
            - Callable functions that return bool when given a value
        E.G.:
        ```
        {
            "@refType": [re.compile("basic_([0-9])IndexTable"), "some_pattern"],
            "@tableDimension": [lambda x: isinstance(x, int) and x > 0],
            "@status": [lambda x: x in ["active", "pending"]],
        }
        ```
    compile_attributes : bool, True
        Flag to determine if the attributes defined at `attribute_matchers` should be compiled. Any first call to this
        function should always set this value to `True` (its default value).The key should be set to `False` at any
        recursive call, as compilation checks are recursive and expensive.

    Returns
    -------
    results :
        Sequence of items as (path, value), where:
            - `path` is the hierarchical path (as a list of items) from root to the value
            - `value` is the decoded DCC data as the corresponding instance (depending on the
    """
    if not isinstance(search_keys, set):
        search_keys = set(search_keys)
    if attribute_matchers is None:
        attribute_matchers = {}

    # Convert list to dict with indices as keys for uniform processing
    if isinstance(dcc_data, list):
        dcc_data = dict(enumerate(dcc_data))
    elif not isinstance(dcc_data, dict):
        raise TypeError("Invalid type for 'dcc_data'")

    # Compile string patterns to regex on first call
    if compile_attributes and attribute_matchers:
        attribute_matchers = _compile_matchers_in_obj(attribute_matchers)

    results = []

    for key, value in dcc_data.items():
        key_matched = key in search_keys

        # Process matched keys
        if key_matched:
            if isinstance(value, list):
                results.extend(
                    [
                        ([key, index], item)
                        for index, item in enumerate(value)
                        if _should_include_list_item(item, attribute_matchers)
                    ]
                )
            else:
                results.extend([([key], value)])

        # Recurse into nested structures
        if (recursive or not key_matched) and isinstance(value, (dict, list)):
            sub_results = dcc_type_collector(
                dcc_data=value,
                search_keys=search_keys,
                recursive=recursive,
                attribute_matchers=attribute_matchers,
                compile_attributes=False,
            )
            results.extend([([key, *sub_key], sub_value) for sub_key, sub_value in sub_results])

    return results


@overload
def extract_dcc_elements(
    xml_file_path: str, dcc_element_key: DccElementKey = ..., with_hierarchy_path: Literal[True] = ...
) -> list[tuple[list[str], DccType]]: ...
@overload
def extract_dcc_elements(
    xml_file_path: str, dcc_element_key: DccElementKey = ..., with_hierarchy_path: Literal[False] = ...
) -> list[DccType]: ...


def extract_dcc_elements(
    xml_file_path: Path | str, dcc_element_key: DccElementKey = DccElementKey.TABLE, with_hierarchy_path: bool = False
) -> list[tuple[list[str], DccType]] | list[DccType]:
    """
    Extracts all DCC elements of the same type provided an XML file.

    Parameters
    ----------
    xml_file_path : str
        Path to the XML file containing the DCC.
    dcc_element_key : DccElementKey
        Element type to extract. When not specified, all the tables are extracted from the XML file.
    with_hierarchy_path :
        When true, each item at the final sequence is defined as a tuple where the first item is the hierarchical path
        from the root level to the item and the second item is a dictionary containing the DCC data.

    Returns
    -------
    list
        All extracted elements (defined by the parameter `dcc_element_key`) from the XML in a sequence.
    """
    if not isinstance(xml_file_path, Path):
        xml_file_path = Path(xml_file_path)

    if not xml_file_path.exists():
        raise FileNotFoundError(f'Could not find the file "{xml_file_path!s}"')
    with open(xml_file_path, "r", encoding="utf-8") as xml_file:
        dicted_data = XMLToDict(xml_file.read())[0]

    collected_dcc_data = dcc_type_collector(
        dcc_data=dicted_data,
        search_keys=[dcc_element_key],
        attribute_matchers={
            "@refType": [re.compile(r"basic_([0-9])Index(Flat)?Table")],
            "@tableDimension": [lambda x: isinstance(x, int) and x > 0],  # Custom matcher to match int attrs > 0
        },
    )

    if not with_hierarchy_path:
        collected_dcc_data = [v for p, v in collected_dcc_data]

    return collected_dcc_data
