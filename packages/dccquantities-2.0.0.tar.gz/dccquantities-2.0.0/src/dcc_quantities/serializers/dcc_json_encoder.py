from __future__ import annotations

import datetime
import json

from dsi_unit import DsiUnit
from elementpath.datatypes.datetime import DateTime10


class DCCJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if hasattr(obj, "to_json_dict") and (callable(obj.to_json_dict) or callable(obj.toJSONDict)):
            return obj.to_json_dict()
        if hasattr(obj, "toJSON") and callable(obj.toJSON):
            return obj.toJSON()
        if isinstance(obj, DsiUnit):
            return str(obj)
        if isinstance(obj, DateTime10):
            return str(obj)
        if isinstance(obj, (datetime.datetime, datetime.date, datetime.time)):
            return obj.isoformat()
        return super().default(obj)
