"""Serialization of DCC elements that can be extracted from the XML file."""

import sys

if sys.version_info < (3, 11):
    from py_back import enum
else:
    import enum


class _DccStrEnum(enum.StrEnum):
    """Enumerations where the 'auto' is updated to match the DCC keys structure."""

    @staticmethod
    def _generate_next_value_(name: str, *_) -> str:
        """The `auto` method generates a value `'dcc:' + name.lower()`."""
        return f"dcc:{name.lower()}"


class DccElementKey(_DccStrEnum):
    """Enumeration where all elements have the corresponding DCC-XML key as value.

    Each element value corresponds to a key 'dcc:{element_name}', which is a standardized DCC key for an XML file.
    All members of the `DccElementKey` instances are strings and allow any
    [string method](https://docs.python.org/3/library/stdtypes.html#string-methods).

    Attributes
    ----------
    CONTENT : str
        Member corresponding to the key `'dcc:content'`.
    LIST : str
        Member corresponding to the key `'dcc:list'`.
    TABLE : str
        Alias to `DccElementKey.LIST`.
    NAME : str
        Member corresponding to the key `'dcc:name'`.
    QUANTITY : str
        Member corresponding to the key `'dcc:quantity'`.

    Notes
    -----
    The string 'dcc:{element_name}' can also be used instead of calling directly a member of this class. For example
    `DccElementKey.CONTENT` is equivalent to parsing the string `'dcc:content'`.

    Examples
    --------
    ```pycon
    >>> content_key = DccElementKey.CONTENT
    >>> repr(content_key)
    "<DccElementKey.CONTENT: 'dcc:content'>"
    >>> print(content_key)
    dcc:content
    >>> table_key = DccElementKey.TABLE
    >>> repr(table_key)
    "<DccElementKey.LIST: 'dcc:list'>"
    >>> print(table_key)
    dcc:list
    >>> table_key == "dcc:list"
    True
    ```
    """

    CONTENT = enum.auto()
    LIST = enum.auto()
    NAME = enum.auto()
    QUANTITY = enum.auto()
    TABLE = "dcc:list"
