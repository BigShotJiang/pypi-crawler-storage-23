from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

import numpy as np

if TYPE_CHECKING:
    from dcc_quantities.serializers._field_spec import FieldSpec


class ExplicitSerializerMixin:
    """
    Mixin to serialize object fields in a specified order.

    Subclasses must define:
      - __serialize_fields__: List[FieldSpec]
    """

    __serialize_fields__: ClassVar[list[FieldSpec]]

    def _to_dict(self) -> dict:
        """
        Build an OrderedDict of serialized fields according to `__serialize_fields__`.
        Treat empty lists, tuples, dicts, sets, or zero-length numpy arrays as None (skip them).
        """
        out = {}

        def value_is_invalid(value) -> bool:
            res = value is None
            res |= isinstance(value, (list, tuple, dict, set)) and len(value) == 0
            res |= isinstance(value, np.ndarray) and value.size == 0
            return res

        for spec in self.__serialize_fields__:
            if spec.serializer is None:
                val = getattr(self, spec.name, None)
            elif isinstance(spec.serializer, tuple):
                method, key = spec.serializer
                temp = getattr(self, method)() if isinstance(method, str) else method(self)
                val = temp.get(key) if isinstance(temp, dict) else None
            elif isinstance(spec.serializer, str):
                val = getattr(self, spec.serializer)()
            else:
                val = spec.serializer(self)
            if value_is_invalid(val):
                continue
            if spec.merge:
                if not isinstance(val, dict):
                    raise ValueError(f"Field {spec.name} expected to merge a dict, got {type(val)}")
                for k, v in filter(lambda it: not value_is_invalid(it[1]), val.items()):
                    out[k] = v
            else:
                out[spec.tag or spec.name] = val
        return out
