"""Tests regarding the 'dcc_math' module."""

from __future__ import annotations

import math
import random
from typing import Callable, Sequence

import pytest
from dsi_unit import DsiUnit
from metas_unclib import get_value, ufloat, umath

import dcc_quantities.exceptions as errors
from dcc_quantities import DccQuantityType, SiRealList, dcc_math


@pytest.mark.parametrize(
    ("func", "inverse"),
    [
        *((f, False) for f in (dcc_math.sin, dcc_math.cos, dcc_math.tan, dcc_math.sinh, dcc_math.cosh, dcc_math.tanh)),
        *(
            (f, True)
            for f in (dcc_math.asin, dcc_math.acos, dcc_math.atan, dcc_math.asinh, dcc_math.acosh, dcc_math.atanh)
        ),
    ],
)
@pytest.mark.parametrize(
    ("angle", "in_degrees"),
    [
        *((v, False) for v in (0, math.pi / 2, *(random.uniform(0, math.pi / 2) for _ in range(3)))),
        *((v, True) for v in (90, 45, 27)),
    ],
)
def test_trigonometry(func: Callable, inverse: bool, angle: float, in_degrees: bool):
    """Trigonometric functions (direct and inverse)."""
    if inverse and in_degrees:
        # Cannot do the inverse of any value. This checks avoids the test to fail.
        angle = math.radians(angle)
        in_degrees = False

    unit = "\\one" if inverse else DsiUnit("\\degree" if in_degrees else "\\radian")
    quant = DccQuantityType.from_single_quantity_value(name="test", value=angle, uncertainty=0, unit=unit)
    try:
        result: DccQuantityType = func(quant)
    except errors.NumericDomainError:
        pytest.skip("Case for an invalid domain.")

    math_func = getattr(math, func.__name__)
    math_res = math_func(math.radians(angle)) if in_degrees else math_func(angle)
    assert result.data == [ufloat(math_res)]


@pytest.mark.parametrize("func", [dcc_math.log, dcc_math.log10, dcc_math.exp, dcc_math.abs, dcc_math.sqrt])
@pytest.mark.parametrize(
    "values",
    [
        (0.1, 0.2, 0.3),
        (-0.1, 0.2, -3.3),
        [random.uniform(0, 10) for _ in range(3)],
        ((1.0, 0.1), (2.0, 0.2), (3.0, 0.3)),
    ],
)
def test_general_math(func: Callable, values: Sequence[float] | Sequence[tuple[float, float]]):
    """Tests over math which works mostly with adimensional units."""
    try:
        results: SiRealList = func(SiRealList(data=values, unit="\\one"))
    except NotImplementedError:
        pytest.skip("Complex numbers not supported")
    if isinstance(values[0], float):
        math_func = getattr(math, func.__name__, abs)
        assert results == [ufloat(math_func(v), 0) for v in values]
    else:
        math_func = getattr(umath, func.__name__)
        assert results == [math_func(ufloat(*v)) for v in values]
    assert results.unit == DsiUnit("\\one")


@pytest.mark.parametrize(
    ("func", "quant", "expected_unit"),
    [
        *(
            (dcc_math.sqrt, DccQuantityType.from_single_quantity_value("Test", 4, 0, unit0), unit1)
            for unit0, unit1 in [
                (r"\metre\tothe{2}", r"\metre"),
                (r"\metre", r"\metre\tothe{1_2}"),
                (r"\metre\tothe{2}\per\second\tothe{2}", r"\metre\per\second"),
            ]
        )
    ],
)
def test_math_unit(func: Callable, quant: DccQuantityType, expected_unit: str):
    """Tests over math functions that consider the units."""
    res: DccQuantityType = func(quant)
    assert res.data.unit == DsiUnit(expected_unit)
    assert res.data == [ufloat(getattr(math, func.__name__)(get_value(quant.data.data[0])), 0)]


@pytest.mark.parametrize(
    ("func", "value", "unit", "error"),
    [
        (dcc_math.sin, 0.5, "\\metre", errors.UnitError),
        (dcc_math.log, 0.5, "\\metre", errors.UnitError),
        (dcc_math.log10, 0.5, "\\metre", errors.UnitError),
        (dcc_math.exp, 0.5, "\\metre", errors.UnitError),
        (dcc_math.asin, -1.1, "\\one", errors.NumericDomainError),
        (dcc_math.asin, 1.1, "\\one", errors.NumericDomainError),
        (dcc_math.acos, -1.1, "\\one", errors.NumericDomainError),
        (dcc_math.acos, 1.1, "\\one", errors.NumericDomainError),
        (dcc_math.acosh, 0.1, "\\one", errors.NumericDomainError),
        (dcc_math.atanh, -1.1, "\\one", errors.NumericDomainError),
        (dcc_math.atanh, 1.1, "\\one", errors.NumericDomainError),
    ],
)
def test_invalid_math(func, value, unit, error):
    """Testing all the correct errors are raised. The test will fail only when the correct error is not raised."""
    quant = DccQuantityType.from_single_quantity_value(name="Test", value=value, uncertainty=0, unit=unit)
    with pytest.raises(error):
        _ = func(quant)
