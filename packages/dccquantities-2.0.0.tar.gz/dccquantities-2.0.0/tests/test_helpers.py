import numpy as np
import pytest

from dcc_quantities._helpers import get_conditional_slice, get_exact_slice, get_nearest_slice, slice_and


@pytest.mark.parametrize(
    ("index_vector", "query", "exp_slice"),
    [(np.array([1.0, 1.0, 2.0, 3.0]), 1.0, (0, 2, 1)), ([0.0, 0.5, 1.0, 1.5, 2.0], [0.5, 1.5], (1, 5, 2))],
)
def test_get_exact_slice(index_vector, query, exp_slice):
    s = get_exact_slice(index_vector, query)
    assert (s.start, s.stop, s.step) == exp_slice


@pytest.mark.parametrize(
    ("index_vector", "query", "exp_slice"),
    [
        ([0.0, 0.5, 1.0, 1.5, 2.0], ("<=", 1), (0, 3)),
        ([0.0, 0.5, 1.0, 1.5, 2.0], (">", 1.0), (3, 5)),
        ([0.0, 0.5, 1.0, 1.5, 2.0], ("==", 1.5), (3, 4)),
    ],
)
def test_get_conditional_slice(index_vector, query, exp_slice):
    s = get_conditional_slice(index_vector, query)
    assert (s.start, s.stop) == exp_slice


@pytest.mark.parametrize(
    ("index_vector", "query", "mode", "exp_slice"),
    [
        ([0.0, 0.5, 1.0, 1.5, 2.0], 1.5, "absolute", 3),
        ([0.0, 0.5, 1.0, 1.5, 2.0], 1.2, "lower", 2),
        ([0.0, 0.5, 1.0, 1.5, 2.0], 1.2, "higher", 3),
        ([0.0, 0.5, 1.0, 1.5, 2.0], 1.2, "absolute", 2),
    ],
)
def test_get_nearest_slice(index_vector, query, mode, exp_slice: int):
    s = get_nearest_slice(index_vector, query, mode=mode)
    assert s == exp_slice


def test_get_exact_slice_no_match():
    index_vector = np.array([0.0, 0.5, 1.0, 1.5, 2.0])
    with pytest.raises(ValueError, match="No match found for query"):
        get_exact_slice(index_vector, 3.0)


def test_get_conditional_slice_no_match():
    index_vector = [0.0, 0.5, 1.0, 1.5, 2.0]
    with pytest.raises(ValueError, match="No indices satisfy condition"):
        get_conditional_slice(index_vector, ("<", -1.0))


def test_get_conditional_slice_unsupported_operator():
    index_vector = [0.0, 0.5, 1.0, 1.5, 2.0]
    with pytest.raises(ValueError, match="Unsupported operator"):
        get_conditional_slice(index_vector, ("**", 1.0))


def test_get_nearest_slice_tie():
    index_vector = [1.0, 1.5, 2.0, 10.0, 1.5]
    # TODO test warning
    s = get_nearest_slice(index_vector, 1.75, mode="absolute")
    assert np.all(s == np.array([1, 2, 4]))


def test_get_nearest_slice_no_lower():
    index_vector = [1.0, 1.5, 2.0]
    with pytest.raises(ValueError, match="No index found lower than or equal to"):
        get_nearest_slice(index_vector, 0.5, mode="lower")


def test_get_nearest_slice_no_higher():
    index_vector = [1.0, 1.5, 2.0]
    with pytest.raises(ValueError, match="No index found higher than or equal to"):
        get_nearest_slice(index_vector, 2.5, mode="higher")


def test_slice_and():
    result1 = slice_and(slice(1, 10), slice(5, 15))
    expected1 = [5, 6, 7, 8, 9]
    assert result1 == expected1, f"Test 1 Failed: expected {expected1}, got {result1}"
    result2 = slice_and(slice(0, 10, 2), [2, 3, 4, 6, 8])
    expected2 = [2, 4, 6, 8]
    assert result2 == expected2, f"Test 2 Failed: expected {expected2}, got {result2}"
    result3 = slice_and([1, 2, 3, 4, 5], [3, 4, 5, 6, 7], [0, 4, 5, 3])
    expected3 = [3, 4, 5]
    assert result3 == expected3, f"Test 3 Failed: expected {expected3}, got {result3}"
    inputs = [None, slice(0, 5), [2, 3, 4, 5, 6]]
    result4 = slice_and(inputs)
    expected4 = [2, 3, 4]
    assert result4 == expected4, f"Test 4 Failed: expected {expected4}, got {result4}"
    try:
        _ = slice_and(None, slice(None))
    except ValueError:
        pass
    else:
        raise AssertionError("Test 5 Failed: Expected ValueError for all unconstrained inputs.")
    print("All tests passed.")
