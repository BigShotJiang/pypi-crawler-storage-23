from dccXMLJSONConv.dccConv import get_from_dict
from paths import FilePath

from dcc_quantities.serializers import DccElementKey, dcc_type_collector


def test_basic():
    test_dict = FilePath.SIMPLE_SINE_CALIB.get_xml_dict()
    quantity_list = dcc_type_collector(test_dict, search_keys=[DccElementKey.QUANTITY])
    path = quantity_list[13][0]
    test_content_from_path = get_from_dict(test_dict, path)
    for key, item in quantity_list:
        print(key, item)
    assert len(quantity_list) == 15
    assert quantity_list[13][1] == test_content_from_path


def test_recursion():
    test_dict = {"a": {"a": 1, "b": 2}, "b": {"a": 3, "b": 4}}
    no_recursion = dcc_type_collector(test_dict, search_keys=["a"])
    assert no_recursion == [(["a"], {"a": 1, "b": 2}), (["b", "a"], 3)]
    yes_recursion = dcc_type_collector(test_dict, search_keys=["a"], recursive=True)
    assert yes_recursion == [(["a"], {"a": 1, "b": 2}), (["a", "a"], 1), (["b", "a"], 3)]
