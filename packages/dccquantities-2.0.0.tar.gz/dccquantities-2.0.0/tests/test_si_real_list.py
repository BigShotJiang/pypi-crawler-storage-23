"""Test cases operated over the SiRealList instance."""

from __future__ import annotations

import enum
import itertools
import random
from collections import OrderedDict
from datetime import datetime
from typing import Optional, TypeVar, Union

import numpy as np
import pytest
from dsi_unit import DsiUnit
from metas_unclib import ufloat

from dcc_quantities import exceptions as errors
from dcc_quantities.si_real_list import SiRealList

RealValue = TypeVar("RealValue", int, float, ufloat, list[Union[int, float, ufloat]], SiRealList)


class DataStructType(enum.IntEnum):
    """Enumeration for controlling the different data structures:

    SEQUENCE_VALUES
        [real_0, real_1, ..., real_n]
    SEQUENCE_ITEMS
        [(real_0, unc_0), (real_1, unc_1), ..., (real_n, unc_n)]
    SEQUENCE_VALUES_AND_UNCERTAINTIES
        [(real_0, real_1, ..., real_n), (unc_0, unc_1, ..., unc_n)]
    DICT_VALUES_AND_UNCERTAINTIES
        {'value': [real_0, real_1, ..., real_n], 'unc': [unc_0, unc_1, ..., unc_n]}
    """

    SEQUENCE_SINGLE_VALUES = 1
    SEQUENCE_ITEMS = 2
    SEQUENCE_VALUES_AND_UNCERTAINTIES = 3
    DICT_VALUES_AND_UNCERTAINTIES = 4


@pytest.mark.parametrize(
    ("data", "is_sorted"),
    [
        ([ufloat(-0.1), ufloat(0.0), ufloat(0.1), ufloat(0.2)], True),
        ([ufloat(-0.1), ufloat(0.0), ufloat(1e-12), ufloat(0.2)], True),
        ([ufloat(-0.1), ufloat(0.0), ufloat(0), ufloat(0.2)], True),
        ([ufloat(-0.1, 0.05), ufloat(0.0, 0.05), ufloat(0.1, 0.05), ufloat(0.2, 0.05)], True),
        ([ufloat(0.1), ufloat(0.0), ufloat(0.1), ufloat(0.2)], False),
        ([ufloat(0.1, 0.05), ufloat(0.0, 0.05), ufloat(0.1, 0.05), ufloat(0.2, 0.05)], False),
        (
            [
                ufloat(0.1, 0.05),
                ufloat(0.0, 0.05),
                ufloat(0.1, 0.05),
                ufloat(0.2, 0.05),
                ufloat(0.1, 0.05),
                ufloat(0.0, 0.05),
                ufloat(0.1, 0.05),
                ufloat(0.2, 0.05),
            ],
            False,
        ),
    ],
)
def test_sorted(data: list[ufloat], is_sorted: bool):
    """Check whether the 'sorted' property returns the correct value."""
    si_real_list = SiRealList(data=data, label=["test"], unit=r"\volt", date_time=[datetime.now()])
    assert si_real_list.sorted is is_sorted


@pytest.mark.parametrize(
    ("data", "struct_type"),
    [
        # Struct 1: Sequence of values (no uncertainties)
        *(
            (val, DataStructType.SEQUENCE_SINGLE_VALUES)
            for val in (
                [ufloat(1, 0.1), ufloat(2.0, 0.2)],
                [1, 2.0, ufloat(3.3)],
                np.array([random.random() for _ in range(3)]),
                [random.randint(-5, 5) for _ in range(3)],
            )
        ),
        # Struct 2: Sequence of item (value, uncertainty)
        *(
            (val, DataStructType.SEQUENCE_ITEMS)
            for val in (
                [(1, 0.1), (2.0, 0.2), (3.3, 0.3)],
                [np.array([1, 0.1]), np.array([2.0, 0.2]), np.array([3.3, 0.3])],
            )
        ),
        *(
            (val, DataStructType.SEQUENCE_VALUES_AND_UNCERTAINTIES)
            for val in (
                [(1, 2.0, 3.3), (0.1, 0.2, 0.3)],
                [np.array([1, 2.0, 3.3]), np.array([0.1, 0.2, 0.3])],
                [(1, 2.0), (0.1, 0.2)],
            )
        ),
        *(
            (val, DataStructType.DICT_VALUES_AND_UNCERTAINTIES)
            for val in (
                {"values": [1, 2.0, 3.3], "uncs": [0.1, 0.2, 0.3]},
                {"values": np.array([1, 2.0, 3.3]), "uncs": np.array([0.1, 0.2, 0.3])},
            )
        ),
    ],
)
def test_data_parsing(data, struct_type: DataStructType):
    """Checks for multiple data structures that are allowed to be parsed."""
    if struct_type is DataStructType.SEQUENCE_VALUES_AND_UNCERTAINTIES and len(data[0]) == 2:
        # Testing ambiguous case. This should be warned
        with pytest.warns(UserWarning, match="The parsed data is ambiguous"):
            parsed_data = SiRealList.parse_data(data)
    else:
        parsed_data = SiRealList.parse_data(data)

    if struct_type is DataStructType.SEQUENCE_SINGLE_VALUES:
        expected_data = np.array(data)  # Same output as input, without uncertainties.
    elif struct_type is DataStructType.SEQUENCE_ITEMS:
        expected_data = np.array([ufloat(value=val, stdunc=unc) for (val, unc) in data])
    elif struct_type is DataStructType.SEQUENCE_VALUES_AND_UNCERTAINTIES:
        expected_data = np.array([ufloat(value=val, stdunc=unc) for val, unc in zip(data[0], data[1])])
    elif struct_type is DataStructType.DICT_VALUES_AND_UNCERTAINTIES:
        expected_data = np.array([ufloat(value=val, stdunc=unc) for val, unc in zip(data["values"], data["uncs"])])
    else:
        raise NotImplementedError("Unrecognized struct type for parsing data.")

    for idx, (parsed_val, expected_val) in enumerate(zip(parsed_data, expected_data)):
        if isinstance(parsed_val, ufloat):
            has_same_value = parsed_val.value == pytest.approx(expected_val.value)
            has_same_unc = parsed_val.stdunc == pytest.approx(expected_val.stdunc)
            assert has_same_value, f"Failed with item at index {idx}"
            assert has_same_unc, f"Failed with item at index {idx}"
        else:
            assert parsed_val == pytest.approx(expected_val), f"Failed with item at index {idx}"


@pytest.mark.parametrize(
    ("data", "unit", "label"),
    [
        (val, r"\one", "test")
        for val in itertools.chain(
            (random.randint(-100, 100) for _ in range(5)), (random.random() * 3 for _ in range(5))
        )
    ],
)
@pytest.mark.parametrize("orig_type", ["si:constant", "si:real"])
def test_json_dump(data: int | float, unit: str, label: str, orig_type: str):
    timestamp = datetime.now()
    si_real_list = SiRealList(data=[data], label=[label], unit=unit, date_time=[timestamp], _origin_type=orig_type)
    expected_json = {
        orig_type: OrderedDict({"si:label": label, "si:value": data, "si:unit": unit, "si:dateTime": timestamp})
    }
    assert si_real_list.to_json_dict() == expected_json


@pytest.mark.parametrize(
    ("test_instance", "test_data", "eq_should_match"),
    [
        # Cases that should match.
        (
            SiRealList(
                data=[ufloat(-0.1, 0.0), ufloat(0.0), ufloat(0.1), ufloat(0.2, 0.0)], label=["test"], unit=r"\volt"
            ),
            [ufloat(-0.1), ufloat(0.0, 0.0), ufloat(0.1), ufloat(0.2, 0.0)],
            True,
        ),
        (
            SiRealList(data=[10, 20, 30, 40], label=["test"], unit=r"\milli\volt"),
            SiRealList(data=[0.01, 0.02, 0.03, 0.04], label=["test"], unit=r"\volt"),
            True,
        ),
        (
            SiRealList(data=[10, 20, 30, 40], label=["test"], unit=r"\milli\volt", date_time=[datetime.now()]),
            SiRealList(data=[0.01, 0.02, 0.03, 0.04], label=["test"], unit=r"\volt"),
            True,
        ),
        # Cases that should NOT match (with the reason why).
        (
            SiRealList(data=[(1, 0.1), (2, 0.0), (3, 0.1), (4, 0.2)], label=["test"], unit=r"\volt"),
            SiRealList(data=[(1, 0.1), (2, 0.1), (3, 0.1), (4, 0.2)], label=["test"], unit=r"\volt"),
            False,  # Different uncertainty at value index 1.
        ),
        (
            SiRealList(data=[1, 2, 3, 4], label=["test"], unit=r"\volt"),
            SiRealList(data=[1, 2, 3, 4], label=["test"], unit=r"\metre"),
            False,  # Different (non-scalable) unit.
        ),
        (
            SiRealList(data=[(10, 0.1), (20, 0.1), (30, 0.1), (40, 0.1)], label=["test"], unit=r"\milli\volt"),
            SiRealList(data=[(0.01, 0.1), (0.02, 0.1), (0.03, 0.1), (0.04, 0.1)], label=["test"], unit=r"\volt"),
            False,  # Absolute uncertainty is different considering the scale
        ),
        (
            SiRealList(data=[ufloat(-0.1), ufloat(0.0), ufloat(0.1), ufloat(0.2)], label=["test"], unit=r"\volt"),
            [ufloat(-0.1), ufloat(0.0), ufloat(0.1)],
            False,  # Diff len, "same" values
        ),
        (
            SiRealList(data=[-0.1, 0.0, 0.1, 0.2], label=["test"], unit=r"\volt"),
            [complex(-0.1), complex(0.0), complex(0.1), complex(0.2)],
            False,  # Invalid type (in this case, complex numbers)
        ),
        (
            SiRealList(data=[ufloat(-0.1), ufloat(0.0), ufloat(0.1), ufloat(0.2)], label=["test"], unit=r"\volt"),
            [ufloat(random.random()) for _ in range(4)],
            False,  # Same len, diff values
        ),
        (
            SiRealList(data=[ufloat(-0.1), ufloat(0.0), ufloat(0.1), ufloat(0.2)], label=["test"], unit=r"\volt"),
            [ufloat(random.random()) for _ in range(6)],
            False,  # Diff len, diff values
        ),
    ],
)
def test_equality(test_instance, test_data, eq_should_match: bool):
    """Checking behaviors for '__eq__' comparing only to sequences of values"""
    assert (test_instance == test_data) is eq_should_match
    if isinstance(test_data, SiRealList):
        # Hashing should be as unique as possible, thus they should always be different.
        assert hash(test_instance) != hash(test_data)


@pytest.mark.parametrize(
    ("value", "test_unit"),
    [  # The test unit is not important within all these cases:
        (val, r"\one")
        for val in itertools.chain(
            # Case: Sum random integers
            (random.randint(-100, 100) for _ in range(5)),
            # Case: Sum random floats
            (random.random() * 3 for _ in range(5)),
            # Case: Sum random ufloats
            (ufloat(random.random() * 3) for _ in range(5)),
            # Case: Sum a list of 4 random int values. Total cases: 5
            ([random.randint(-10, 10) for _ in range(4)] for _ in range(5)),
            # Case: Sum a list of 4 random float values. Total cases: 5
            ([random.random() * 3 for _ in range(4)] for _ in range(5)),
            # Case: Sum a list of 1 random float.
        )
    ]
    + [
        (
            SiRealList(
                data=[ufloat(-0.1), ufloat(0.0), ufloat(0.1), ufloat(0.2)],
                label=["1a"],
                unit=r"\volt",
                date_time=[datetime.now()],
            ),
            r"\volt",
        ),
        (
            SiRealList(
                data=[ufloat(-10.0), ufloat(30.0), ufloat(30.0), ufloat(70.7)],
                label=["2a", "2b", "2c", "2d"],
                unit=r"\milli\volt",
                date_time=[datetime.now()],
            ),
            r"\volt",
        ),
        (
            SiRealList(
                data=[ufloat(-10.0), ufloat(30.0), ufloat(30.0), ufloat(70.7)],
                label=["3a"],
                unit=r"\kilo\metre",
                date_time=[datetime.now()],
            ),
            r"\metre",
        ),
    ],
)
@pytest.mark.parametrize("operation", ["+", "-", "*", "/"])
def test_math_operators(value: RealValue, test_unit: str, operation: str, math_callable_map: dict):
    """Tests over all basic math operators (passing cases) using fixed and random data."""
    math_call = math_callable_map[operation]
    test_data = [ufloat(-0.1), ufloat(0.0), ufloat(0.1), ufloat(0.2)]
    si_real_list = SiRealList(data=test_data, label=["test"], unit=test_unit, date_time=[datetime.now()])
    try:
        result = math_call(si_real_list, value)
    except NotImplementedError as err:
        pytest.skip(reason=str(err))

    if isinstance(value, (int, float, ufloat)):
        expected_result = [math_call(td, value) for td in test_data]
    elif isinstance(value, list):
        expected_result = [math_call(td, val) for td, val in zip(test_data, value)]
    else:
        value: SiRealList
        scale = value.get_scale_factor(si_real_list)
        expected_result = [math_call(td, val / scale) for td, val in zip(test_data, value.data)]
    assert result == expected_result

    # Operation per list of a single value should be equal than the op per single value
    if isinstance(value, (int, float, ufloat)):
        assert math_call(si_real_list, [value]) == result

    # Checking right-operators
    right_result = math_call(value, si_real_list)
    if operation in {"+", "*"}:
        # The unit might be different, but the scaling value should be the same
        assert right_result == result
    elif operation == "-":
        assert right_result == -result
    elif operation == "/":
        assert right_result == (result**-1)


@pytest.mark.parametrize(
    ("left", "right", "result_units"),
    [
        (
            SiRealList(data=[1, 2, 3, 4], unit=r"\one", label=["test"]),
            SiRealList(data=[2], unit=r"\metre", label=["test"]),
            None,  # Not allowed 'any to-the {UNIT}' if 'unit' is not "one"
        ),
        (
            SiRealList(data=[1, 2, 3, 4], unit=r"\one", label=["test"]),
            SiRealList(data=[2, 3], unit=r"\one", label=["test"]),
            None,  # Not allowed power to array with different values
        ),
        (
            SiRealList(data=[1, 2], unit=r"\one", label=["test"]),
            SiRealList(data=[2], unit=r"\volt\per\volt", label=["test"]),
            DsiUnit(r"\one"),  # allowed since exponent is convertible to one
        ),
        (
            SiRealList(data=[1, 2], unit=r"\volt", label=["test"]),
            SiRealList(data=[2], unit=r"\joule\per\kilogram\metre\tothe{2}\second\tothe{-2}", label=["test"]),
            DsiUnit(r"\volt\tothe{2}"),  # allowed since exponent is convertible to one
        ),
        (SiRealList(data=[1, 2, 3, 4], unit=r"\one", label=["test"]), 2, DsiUnit(r"\one")),
        (SiRealList(data=[1, 2, 3, 4], unit=r"\metre", label=["test"]), 2, DsiUnit(r"\metre\tothe{2}")),
        (SiRealList(data=[1, 2, 3, 4], unit=r"\metre", label=["test"]), [2], DsiUnit(r"\metre\tothe{2}")),
        (
            SiRealList(data=[1, 2, 3, 4], unit=r"\metre", label=["test"]),
            SiRealList(data=[2, 2, 2, 2], unit=r"\one", label=["test"]),
            DsiUnit(r"\metre\tothe{2}"),
        ),
    ],
)
def test_power_operators(left: SiRealList, right: RealValue, result_units: Optional[DsiUnit]):
    """Tests over all basic math operators (passing cases) using fixed and random data."""
    if result_units is None:
        with pytest.raises(errors.SiMathError):
            _ = left**right
    else:
        result = left**right
        expected_value = left.data**right.data if isinstance(right, SiRealList) else left.data**right
        assert result == expected_value
        assert result.unit == result_units


@pytest.mark.parametrize(
    ("left", "right", "operator"),
    [
        *(
            (  # Invalid operation with different units
                SiRealList(data=[1, 2, 3, 4], unit=r"\one", label=["test"]),
                SiRealList(data=[1, 2, 3, 4], unit=r"\metre", label=["test"]),
                op,
            )
            for op in ("+", "-")
        ),
        *(
            (  # Invalid operation with different lengths (greater than 1)
                SiRealList(data=[1, 2, 3, 4], unit=r"\one", label=["test"]),
                SiRealList(data=[1, 2, 3], unit=r"\one", label=["test"]),
                op,
            )
            for op in ("+", "-", "/", "*")
        ),
        *(
            (  # Invalid operation due to 'right' type
                SiRealList(data=[1, 2, 3, 4], unit=r"\one", label=["test"]),
                complex(5, 2),
                op,
            )
            for op in ("+", "-", "/", "*")
        ),
    ],
)
def test_wrong_math(left, right, operator, math_callable_map):
    """Cases where the math should fail."""
    math_call = math_callable_map[operator]
    with pytest.raises(errors.SiMathError):
        _ = math_call(left, right)
    with pytest.raises(errors.SiMathError):
        _ = math_call(right, left)


@pytest.mark.parametrize(
    "data",
    [
        [random.randint(1, 10) for _ in range(5)],
        [random.randint(-10, 10) for _ in range(5)],
        [random.randint(-10, -1) for _ in range(5)],
        [random.random() for _ in range(5)],
    ],
)
@pytest.mark.parametrize("label", ["pos", "-neg"])
@pytest.mark.parametrize("op", ["-", "+"])
def test_unary_op(data: list[int | float], label: list[str], op: str):
    """Testing common unary (single) operators, such as the sign +/- operators."""
    unary_call = {"+": lambda a: +a, "-": lambda a: -a}

    # Initializing the SiRealList and applying the unary operator
    initial_instance = SiRealList(data=data, unit=r"\one", label=label)
    unary_instance: SiRealList = unary_call[op](initial_instance)

    # Defining the expected data
    expected_data = [unary_call[op](val) for val in data]

    assert unary_instance == expected_data
    assert unary_instance.label is None
