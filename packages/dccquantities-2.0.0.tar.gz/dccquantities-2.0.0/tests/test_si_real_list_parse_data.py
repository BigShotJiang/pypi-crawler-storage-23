from paths import FilePath

from dcc_quantities.dcc_quantity_parser import parse_item_from_json_dict
from dcc_quantities.serializers import DccElementKey, dcc_type_collector


def test_321_uncer_parsing():
    test_file = FilePath.SIMPLE_SINE_CALIB
    quantity_dict = dcc_type_collector(test_file.get_xml_dict(), search_keys=[DccElementKey.QUANTITY])
    dcc_quantity_type_objects = []
    for _, item in quantity_dict[-3:]:
        dcc_quantity_type_objects.append(parse_item_from_json_dict(item))
    uncers = dcc_quantity_type_objects[0].uncertainties
    assert len(uncers) == 31
    assert uncers[0] == 0.00026 / 2  # noqa: RUF069
    assert uncers[30] == 0.0006 / 2  # noqa: RUF069


def test_reshaping_and330_unc_parsing():
    test_file = FilePath.SAMPLE_FLAT_TABLE
    quantity_dict = dcc_type_collector(test_file.get_xml_dict(), search_keys=[DccElementKey.QUANTITY])
    dcc_quantity_type_objects = []
    for _, item in quantity_dict[-3:]:
        dcc_quantity_type_objects.append(parse_item_from_json_dict(item))
    test_quant_with_10x10_data = dcc_quantity_type_objects[2]
    test_quant_with_10x10_data.reshape(10, 10)
    tmp = test_quant_with_10x10_data[2, 9]
    assert tmp.values == 3.55  # noqa: RUF069
    assert tmp.uncertainties == 0.07938 / 2  # noqa: RUF069
