import uuid

import numpy as np
import pandas as pd
import pytest
from dccXMLJSONConv.dccConv import DictToXML, XMLToDict
from paths import FilePath

from dcc_quantities import DccLangName, DccQuantityType, SiRealList
from dcc_quantities.dcc_quantity_table import DccFlatTable


@pytest.mark.skip(reason="Parsing input data with shape (500, 500). Discussion needed onto how to work with it.")
def test_surface_flat_table_xml_generation_and_conversion():
    znte_data = np.load(FilePath.ZNTE_NPY)
    with open(FilePath.ZNTE_FIRST_ROW, encoding="UTF-8") as f:
        first_row = pd.read_csv(f)
    x_vect = np.array(first_row["X"])
    y_vect = np.array(first_row["Y"])
    z_data = SiRealList(data=znte_data, unit="\\metre", label="z")
    x_data = SiRealList(data=x_vect, unit="\\metre", label="x")
    y_data = SiRealList(data=y_vect, unit="\\metre", label="y")
    z_quantity = DccQuantityType(
        data=z_data,
        identifier="U" + str(uuid.uuid4()),
        name={"en": "ZnTe epitaxial film surface", "de": "ZnTe epitaktische Schichtoberfläche"},
    )
    x_quantity = DccQuantityType(
        data=x_data, identifier="U" + str(uuid.uuid4()), name={"en": "X-Position", "de": "X-Position"}
    )
    y_quantity = DccQuantityType(
        data=y_data, identifier="U" + str(uuid.uuid4()), name={"en": "Y-Position", "de": "Y-Position"}
    )
    table_name = DccLangName(
        {"de": "Beispiel Falt-Table mit topographie Daten", "en": "Example table topography data."}
    )
    surface_flatt_table = DccFlatTable({0: x_quantity, 1: y_quantity}, [z_quantity], 2, name=table_name)
    dummy_xml_dct, _ = XMLToDict(FilePath.MINIMAL_DCC_TEMPLATE)
    json_dict_of_table = surface_flatt_table.to_json_dict()
    _ = DictToXML(dummy_xml_dct)
    dummy_xml_dct["dcc:measurementResults"]["dcc:measurementResult"][0]["dcc:results"]["dcc:result"][0]["dcc:data"] = (
        json_dict_of_table
    )
    xml_str, _, errors = DictToXML(dummy_xml_dct)
    assert xml_str != ""
    assert len(errors) == 0
