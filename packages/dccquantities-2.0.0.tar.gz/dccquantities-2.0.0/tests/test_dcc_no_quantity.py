from dcc_quantities.dcc_no_quantity import DccNoQuantity


def test_sorted():
    test_no_quantity = DccNoQuantity(
        data="abc", identifier="123", ref_id=["234", "345"], ref_type=["@foo"], name={"en": "bar", "de": "foo"}
    )
    assert not test_no_quantity.sorted
