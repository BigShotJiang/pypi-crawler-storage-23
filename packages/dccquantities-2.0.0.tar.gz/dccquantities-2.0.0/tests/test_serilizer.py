from __future__ import annotations

import json
from json import loads

from dccXMLJSONConv.dccConv import XMLToDict
from paths import FilePath

from dcc_quantities.dcc_quantity_parser import parse
from dcc_quantities.serializers import DccElementKey, DCCJSONEncoder, dcc_type_collector


def test_basic():
    test_file = FilePath.SIMPLE_SINE_CALIB
    with open(test_file, "r", encoding="utf-8") as xml_file:
        xml_data = xml_file.read()
        json_dict, _ = XMLToDict(xml_data)
        quantity_dict = dcc_type_collector(json_dict, search_keys=[DccElementKey.QUANTITY])
    dcc_quants = parse(xml_data)
    serialized_data = []
    for q in dcc_quants:
        serialized_data.append(q.to_json_dict())
    for i, serialized in enumerate(serialized_data):
        try:
            json_str = json.dumps(serialized, cls=DCCJSONEncoder)
        except TypeError as te:
            raise te
        _simplejson_dict = loads(json_str)
        _input_json_dict = quantity_dict[i][1]
