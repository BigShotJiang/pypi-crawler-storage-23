import copy
import json
import warnings

import numpy as np
import pytest
from dccXMLJSONConv.dccConv import DictToXML, XMLToDict
from paths import FilePath
from xmlschema import XMLSchemaValidationError

from dcc_quantities._helpers import replace_quantities_in_dict
from dcc_quantities.dcc_quantity_parser import parse, parse_item_from_json_dict
from dcc_quantities.serializers import DCCJSONEncoder

XML_SCHEMA_VERSION = "v3.4.0-rc.2"


@pytest.mark.filterwarnings("ignore:Parsing a correctly marked non D-SI unit")
@pytest.mark.filterwarnings("ignore:The id .* does not match any D-SI units!")
def test_all_files_back_and_forth_ser():
    file_path = FilePath.VALIDATION_RESULTS
    if not file_path.exists():
        pytest.skip(reason="Could not access the calibration sample data.")
    with open(file_path, "r", encoding="utf-8") as validation_file:
        validation_dict = json.load(validation_file)
    invalid_file_names = {
        "dcc-2019-75056_mod.xml",
        "DCCTableXMLStub.xml",
        "test_xmlDumpingSingleQuantNoUncer.xml",
        "test_dccQuantTabXMLDumping.xml",
        "CalSchein_20220708_8305_SN1842876.xml",
        "dcc-vacuumlab-CDG.xml",
        "acoustics_refTypeDefinition.xml",
        *[entry["Invalid File"] for entry in validation_dict.values()],
    }
    for _, xml_file in enumerate(file_path.as_path_obj.parent.rglob("*.xml")):
        if xml_file.name in invalid_file_names:
            continue
        with open(xml_file, "r", encoding="utf-8") as f:
            xml_text = f.read()
        xml_dict, errors = XMLToDict(xml_text)
        xml_dict["@xsi:schemaLocation"] = f"https://ptb.de/dcc https://ptb.de/dcc/{XML_SCHEMA_VERSION}/dcc.xsd"
        xml_dict["@schemaVersion"] = XML_SCHEMA_VERSION
        xml_dict_copy = copy.deepcopy(xml_dict)
        ser_dict, quant_list = replace_quantities_in_dict(
            xml_dict_copy, parser=parse_item_from_json_dict, return_quantity_list=True
        )
        assert len(quant_list) > 0
        json_text = json.dumps(ser_dict, cls=DCCJSONEncoder)
        dict_for_conversion = json.loads(json_text)
        xml_out, _, errors = DictToXML(dict_for_conversion)
        assert xml_out, f"No XML produced for {xml_file.name}"
        remaining = [
            err
            for err in errors
            if not (
                isinstance(err, XMLSchemaValidationError)
                and err.reason.startswith("value doesn't match any pattern of ")
            )
        ]
        assert not remaining, f"Unexpected validation errors in {xml_file.name}:\n" + "\n".join(
            (f"  • {type(err).__name__}: {getattr(err, 'reason', err)}" for err in remaining)
        )


def test_parsed_quant_values_and_functions():
    test_file = FilePath.SIMPLE_SINE_CALIB
    with open(test_file, "r", encoding="utf-8") as xml_file:
        xml_data = xml_file.read()
    parsed_quants = parse(xml_data)
    frequency = parsed_quants[10]
    frequency10_times10 = frequency[10] * 10
    assert frequency10_times10.data.data[0] == pytest.approx(1000)
    assert str(frequency10_times10.data.unit) == "\\hertz"
    assert frequency.id != frequency10_times10.id
    frequency10_div10 = frequency[10] / 10
    assert frequency10_div10.data.data[0] == pytest.approx(10)
    freq_squared = frequency[10:15] * frequency[5:10]
    assert str(freq_squared.data.unit) == "\\hertz\\tothe{2}"
    first5_freqs = frequency[:5]
    assert first5_freqs.id != frequency.id
    out_of_range_freqs = frequency[20:100]
    assert len(out_of_range_freqs) == 11
    bool_indexd_freqs = first5_freqs[np.array([True, False, True, False, False])]
    assert len(bool_indexd_freqs) == 2
    bool_indexd_freqs = first5_freqs[True, False, True, False, False]
    assert len(bool_indexd_freqs) == 2


@pytest.mark.parametrize("test_file", [FilePath.SIMPLE_SINE_CALIB, FilePath.ACOUSTICS_DCC, FilePath.BAM_SCHEIN])
def test_basic(test_file):
    try:
        with open(test_file, "r", encoding="utf-8") as xml_file:
            xml_data = xml_file.read()
        parse(xml_data)
    except FileNotFoundError as e:
        warnings.warn(str(e), RuntimeWarning, stacklevel=2)
