import numpy as np

from dcc_quantities.si_real_list import SiRealList


def test_generate_test_table():
    primes1 = np.array([2, 3, 5, 7, 11, 13, 17, 19, 23, 29], dtype=np.float64)
    primes1_uncer = primes1 * 0.01
    primes2 = np.array([31, 37, 41, 43, 47, 53, 59, 61, 67, 71], dtype=np.float64)
    primes2_uncer = primes2 * 0.02
    longform1 = np.repeat(primes1, 10)
    longform1_uncer = np.repeat(primes1_uncer, 10)
    longform2 = np.tile(primes2, 10)
    longform2_uncer = np.tile(primes2_uncer, 10)
    x_qunat = SiRealList(data={"values": longform1, "uncs": longform1_uncer}, unit="\\metre")
    y_qunat = SiRealList(data={"values": longform2, "uncs": longform2_uncer}, unit="\\centi\\metre")
    surface_area = x_qunat * y_qunat
    surface_area.reshape(10, 10)
    assert surface_area.values[2, 1] == primes1[2] * 0.01 * primes2[1]  # noqa: RUF069
    assert np.isclose(surface_area.values[5, 7], primes1[5] * 0.01 * primes2[7])
