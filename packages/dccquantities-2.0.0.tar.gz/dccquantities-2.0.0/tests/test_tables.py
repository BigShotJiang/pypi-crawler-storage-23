"""Testing over the dcc_quantity_table module."""

import pathlib
import random
import tempfile
import warnings
from typing import Literal, Sequence

import numpy as np
import pytest
from dsi_unit import DsiUnit
from paths import FilePath

from dcc_quantities.dcc_quantity_table import DccFlatTable, DccLongTable, DccQuantityTable
from dcc_quantities.serializers import extract_dcc_elements


@pytest.mark.parametrize(
    ("test_file", "table_type", "nof_index_quants", "nof_value_quants", "has_deprecation_warning", "shape"),
    [
        (FilePath.SIMPLE_SINE_CALIB, "long", 1, 4, True, None),
        (FilePath.SIMPLE_SINE_CALIB_ATTR, "long", 1, 4, False, None),
        (FilePath.SIMPLE_2D_TABLE, "long", 2, 3, True, None),
        (FilePath.SIMPLE_2D_TABLE_ATTR, "long", 2, 3, False, None),
        (FilePath.SAMPLE_FLAT_TABLE, "flat", 2, 1, True, (10, 10)),
        (FilePath.FLAT_TABLE_3D, "flat", 3, 1, False, (2, 3, 5)),
        (FilePath.FLAT_TABLE_5D, "flat", 5, 1, False, (2, 3, 5, 7, 11)),
        (FilePath.FLAT_TABLE_6D, "flat", 6, 1, False, (2, 3, 5, 7, 11, 13)),
    ],
)
def test_general_table_parsing(
    test_file: pathlib.Path,
    table_type: Literal["long", "flat"],
    nof_index_quants: int,
    nof_value_quants: int,
    has_deprecation_warning: bool,
    shape: tuple,
):
    """Generic test over XML files which contain one single table."""
    path, table_data = extract_dcc_elements(test_file, with_hierarchy_path=True)[0]
    try:
        if has_deprecation_warning:
            with pytest.warns(DeprecationWarning, match="'refType' as a Table format is deprecated"):
                table = DccQuantityTable.from_dcc_data(table_data)
        else:
            table = DccQuantityTable.from_dcc_data(table_data)
    except Exception as err:
        raise RuntimeError(f"Could not load the table with path '{path}'.") from err

    if table_type == "long":
        assert isinstance(table, DccLongTable)
    else:
        assert isinstance(table, DccFlatTable)

    warnings.simplefilter("ignore", category=UserWarning)  # DccLongTables warn about the shape property
    assert table.shape == shape

    assert nof_value_quants == len(table.value_quantities)
    assert nof_index_quants == len(table.index_quantities)
    assert nof_value_quants + nof_index_quants == len(table.all_quantities)

    # Test: Exporting the table should not modify the data. Once the table is exported, reloading should get the same
    # DCC table data. This is checked by comparing the index and value quantities.
    warnings.simplefilter("ignore", category=DeprecationWarning)
    with tempfile.TemporaryDirectory() as tmpdir:
        out_file = pathlib.Path(tmpdir, "test_file.xml")
        with open(out_file, "w", encoding="utf-8") as fh:
            fh.write(table.export_as_xml_structure())

        reload_table_data = extract_dcc_elements(out_file)[0]
        reload_table = DccQuantityTable.from_dcc_data(reload_table_data)

        assert reload_table.index_quantities == table.index_quantities
        assert reload_table.value_quantities == table.value_quantities


@pytest.mark.parametrize(
    ("file_path", "nof_tables", "units_per_table", "nof_quantities_per_table"),
    [
        (
            FilePath.ISO376,  # Old format table
            8,
            [
                (r"\milli\volt\per\volt", r"\degree"),
                (r"\degree", r"\percent"),
                (),
                (r"\percent", r"\milli\volt\per\volt", r"\kilo\newton"),
                (r"\milli\volt\per\volt", r"\degree"),
                (r"\degree", r"\percent"),
                (),
                (r"\percent", r"\milli\volt\per\volt", r"\kilo\newton"),
            ],
            [4, 2, 2, 19, 4, 2, 2, 19],
        )
    ],
)
def test_multi_table_file(
    file_path: str, nof_tables: int, units_per_table: Sequence[tuple[str]], nof_quantities_per_table: Sequence[int]
):
    """Testing correct loading of data from a file with multiple tables.

    The bases of the test is to check:
        1. As many 'dicted_tables' are extracted from the file as the 'nof_tables' parameters.
        2. Checking all the unique units are the expected ones. The parameter 'units_per_table' should contain an
           iterable of all the unique units that are found in the table.
        3. Checking the total number of quantities. The previous check is not enough as tables that share units among
           quantities with have a different length at the iterables 'table.units' and 'table.all_quantities'.

    IMPORTANT
    ---------
    All the parameters for this test must be checked manually by reading the XML file. Please, do not expand this test
    with the parameters the package returns assuming they are always correct.
    """
    warnings.filterwarnings("ignore", category=DeprecationWarning)

    multi_tables_file_data = extract_dcc_elements(file_path)
    assert len(multi_tables_file_data) == nof_tables
    for table_idx, table_data in enumerate(multi_tables_file_data):
        expected_units, exp_nof_quants = units_per_table[table_idx], nof_quantities_per_table[table_idx]
        table = DccQuantityTable.from_dcc_data(table_data)
        assert table.units == {DsiUnit(u) for u in expected_units}, (
            f"Different values found for the units at table index {table_idx}"
        )
        assert len(table.all_quantities) == exp_nof_quants, (
            f"Different number of quantities read at table index {table_idx}"
        )


def test_getting_quantity_ids(simple_sine_table):
    """Test getting a quantity by ID works."""
    # CASE: Single match
    # ------------------
    # Getting the ID of the single index at the table. All following code should return a single string as ID.
    index_quant = simple_sine_table.index_quantities[0]
    ref_id = index_quant.id

    # Getting ID by name
    for name in ("Frequency", "Frequenz"):
        id_name = simple_sine_table.get_quantity_ids_by_field("name", name)
        assert ref_id == id_name

    # Getting ID by refType
    for ref_type in ("vib_frequency", "vib_nominalFrequency", "basic_tableIndex0"):
        id_ref_type = simple_sine_table.get_quantity_ids_by_field("ref_type", ref_type)
        assert ref_id == id_ref_type

    # Getting ID by unit
    id_unit = simple_sine_table.get_quantity_ids_by_field("unit", "\\hertz")
    assert ref_id == id_unit

    # Invalid ID getting
    for field in ("name", "ref_type"):
        id_invalid = simple_sine_table.get_quantity_ids_by_field(field, "NotExistent")
        assert id_invalid is None

    # Access the quantity via get_item
    assert index_quant == simple_sine_table[ref_id]

    # CASE: Multiple match
    # --------------------
    # The following are cases where multiple IDs are obtained.
    for field, key in [("ref_type", "vib_phase"), ("unit", "\\radian")]:
        result = simple_sine_table.get_quantity_ids_by_field(field, key)
        assert isinstance(result, list)
        assert len(result) == 2

    # CASE: Errors
    # ------------
    with pytest.raises(ValueError, match="Unrecognized field"):
        _ = simple_sine_table.get_quantity_ids_by_field("invalid_field", ...)
    with pytest.raises(ValueError, match="not a valid D-SI"):
        _ = simple_sine_table.get_quantity_ids_by_field("unit", "\\not\\valid")
    with pytest.raises(KeyError, match="not found in the table"):
        _ = simple_sine_table["InvalidQuantityID"]


LARGE_PRIME_FACTOR_PRODUCT = 16777216  # Result of '2 ** 24'


@pytest.mark.parametrize(
    ("file_path", "large_number_processed"),
    [(FilePath.FLAT_TABLE_3D, False), (FilePath.FLAT_TABLE_5D, False), (FilePath.FLAT_TABLE_6D, True)],
)
def test_prime_factored_table(file_path: str, large_number_processed: bool):
    """Validation through 'Means of Prime Factorization'.

    Considering a flat table where all indices are prime factors, their computed value must be always the product
    of those factors. In other words, it is always deterministic.
    This test proves that a table is read correctly, as well as all the items can be accessed.

    The test considers the first and last table indices, as well as 100 random indices of the table. It is also checked
    if any of the provided tables has any number which is bigger than 2**24 (2 to the power of 24).
    """
    table = DccQuantityTable.from_dcc_data(extract_dcc_elements(file_path)[0])
    # All values of the table (Prime products) are contained at one single value quantity.
    quantity_product = table.value_quantities[0]
    table_shape = table.shape
    # The quantity should have the same shape as the table.
    assert quantity_product.shape == table_shape, (
        f"Data array shape {quantity_product.shape} does not match table shape {table}"
    )

    # Check: Product computations
    quant_data = quantity_product.values.astype(np.int64)
    idx_quants = table.index_quantities  # caching all index quantities

    # Computing checks for the first index, last index and other 50 random indices
    first_index_tuple = (0,) * len(table_shape)
    last_index_tuple = tuple(dim - 1 for dim in table_shape)
    random_indices = [tuple(random.randint(0, dim - 1) for dim in table_shape) for _ in range(50)]
    biggest_prod = 0

    def get_prime_factors(n: int) -> list[int]:
        """Extracts all prime factors from a positive 'n' number."""
        factors = []
        # Extracting all even (2) factors
        while n % 2 == 0:
            factors.append(2)
            n //= 2
        # Extracting all odd factors
        d = 3
        while d * d <= n:
            while n % d == 0:
                factors.append(d)
                n //= d
            d += 2
        if n > 1:
            factors.append(n)
        return factors

    for table_indices in (first_index_tuple, last_index_tuple, *random_indices):
        expected_product_factors = np.array(
            [idx_quants[dim].values[pos] for dim, pos in enumerate(table_indices)], dtype=np.int64
        )
        expected_product = np.prod(expected_product_factors)
        assert quant_data[table_indices] == expected_product, f"Incorrect product found at index {table_indices}"
        assert np.all(expected_product_factors == get_prime_factors(expected_product)), (
            f"Incorrect factors found at index {table_indices}"
        )

        biggest_prod = max(biggest_prod, expected_product)

    assert (biggest_prod > LARGE_PRIME_FACTOR_PRODUCT) == large_number_processed


# ---------------------------------------------------------------------
#   WARNING: LEGACY TESTS
#   From these point, the following are legacy tests that have not
#   been cleaned up.
# ---------------------------------------------------------------------


def test_1_dlong_table_indexing(simple_sine_table):
    _ = simple_sine_table[10]
    _ = simple_sine_table[10:15]
    _ = simple_sine_table[1::3]
    with pytest.raises(IndexError) as excinfo:
        _ = simple_sine_table[1::3, 2]
    error_msg = str(excinfo.value)
    assert "DccLongTable does not support multi dimensional slices." in error_msg


def test_flat_table__index_look_up(sample_flat_table):
    slices = sample_flat_table.get_index_slices_by_condition([("<", 5.0), (">", 13.0)])
    slices2 = sample_flat_table.get_index_slices_by_condition(("<", 5.0), (">", 13.0))
    _data = sample_flat_table[slices]
    _data2 = sample_flat_table[slices2]
    _slices3 = sample_flat_table.get_nearest_index(2.0, 0.31)
    _slices4 = sample_flat_table.get_nearest_index(2.05, 0.32)
    _slices5 = sample_flat_table.get_nearest_index([2.05, 2.99], [0.32, 41.0, 47.1])
    _slices32 = sample_flat_table.get_index_from_values(2.0, 31.0)
    _slices62 = sample_flat_table.get_index_from_values([2.0, 3.0], [31.0, 41, 43])
    with pytest.raises(ValueError, match="No match found"):
        _ = sample_flat_table.get_index_from_values(2.05, 0.32)


def test_long_table__index_look_up(simple_sine_table, simple_sine_table_2d):
    idx_slice = simple_sine_table.get_index_slices_by_condition((">", 100.0))
    assert idx_slice.start == 11
    assert idx_slice.stop == 31
    assert idx_slice.step == 1
    _idxs2 = simple_sine_table_2d.get_index_slices_by_condition((">", 100.0), ("<", 100.0))
    idxs3 = simple_sine_table_2d.get_index_slices_by_condition(("<", 100.0), ("<", 10.0))
    data = simple_sine_table_2d[idxs3]
    assert len(data) > 0
    assert np.all(data[0][0].data.values < 100.0)
    assert np.all(data[0][1].data.values < 10.0)
    idx4 = simple_sine_table_2d.get_index_from_values(20.0, 10.0)
    data2 = simple_sine_table_2d[idx4]
    assert data2[0][0].data.values == 20.0  # noqa: RUF069
    assert data2[0][1].data.values == 10.0  # noqa: RUF069


def test_long_table_nested_condition_index_look_up(simple_sine_table_2d):
    idxs = simple_sine_table_2d.get_index_slices_by_condition([(">", 50), "AND", ("<", 100.0)], (">", 10.0))
    data = simple_sine_table_2d[idxs]
    assert np.all(data[0][0].data.values < 100.0)
    assert np.all(data[0][0].data.values > 50.0)
    assert np.all(data[0][1].data.values > 10.0)
    idxs2 = simple_sine_table_2d.get_index_slices_by_condition(
        [[(">", 50), "AND", ("<", 100.0)], "OR", ("<", 15.0)], ("<", 10.0)
    )
    print(idxs2)
    data = simple_sine_table_2d[idxs2]
    assert np.all(data[0][0].data.values < 100.0)
    assert np.all(data[0][0].data.values > 50.0) | np.all(data[0][0].data.values < 15.0)
    assert np.all(data[0][1].data.values < 10.0)


def test_flat_table__indexing(sample_flat_table):
    sliced = sample_flat_table[1:9, 5:7]
    int_indexing = sample_flat_table[9, 5]
    mixed_indexing = sample_flat_table[1:9, 6]
    assert len(sliced) > 0
    assert len(int_indexing) > 0
    assert len(mixed_indexing) > 0
