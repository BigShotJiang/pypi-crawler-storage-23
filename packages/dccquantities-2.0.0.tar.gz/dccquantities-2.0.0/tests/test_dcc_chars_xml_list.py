import pytest

from dcc_quantities.dcc_chars_xml_list import DccCharsXMLList


def test_add():
    # Reason for disabling the linting: DccCharsXMLList is not unpackable
    test_list1 = DccCharsXMLList(["a", "b", "c"])
    test_list2 = DccCharsXMLList(["d", "e", "f"])
    result = test_list1 + test_list2
    assert result.data == ["a", "b", "c", "d", "e", "f"]
    with pytest.warns(RuntimeWarning, match="Concatenating DccCharsXMLList and list!"):
        result = test_list1 + [1, 2, 3]  # noqa: RUF005
    assert result.data == ["a", "b", "c", 1, 2, 3]
    with pytest.warns(RuntimeWarning, match="Concatenating DccCharsXMLList and list!"):
        result = [1, 2, 3] + test_list2  # noqa: RUF005
    assert result.data == [1, 2, 3, "d", "e", "f"]


def test_sorted():
    sorted_list1 = DccCharsXMLList(["a", "b", "c"])
    sorted_list2 = DccCharsXMLList(["0001", "AA", "FE"])
    unsorted_list1 = DccCharsXMLList(["CDE", "AA", "FE"])
    unsorted_list2 = DccCharsXMLList(["Qsafdadsf", "Adsafas A", "FE"])
    assert sorted_list1.sorted
    assert sorted_list2.sorted
    assert not unsorted_list1.sorted
    assert not unsorted_list2.sorted
