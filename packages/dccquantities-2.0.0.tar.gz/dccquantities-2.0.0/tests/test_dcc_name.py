"""Test cases for the DccLangName class."""

from __future__ import annotations

from typing import Union

import pytest

from dcc_quantities import DccLangName


def test_to_json_dict():
    """Testing DccLangName initialization."""
    json_dict = {
        "dcc:name": {
            "dcc:content": [
                {"@lang": "en", "$": "Room temperature during calibration"},
                {"@lang": "de", "$": "Raumtemperatur währenden der Kalibration"},
            ]
        }
    }
    parsed_dict = {"en": "Room temperature during calibration", "de": "Raumtemperatur währenden der Kalibration"}
    name_instance = DccLangName(parsed_dict)
    generated_json_dict = name_instance.to_json_dict()
    assert json_dict == generated_json_dict


@pytest.mark.parametrize(
    ("content", "subset", "should_match"),
    [
        ({"en": "Frequency", "de": "Frequenz", "fr": "Fréquence"}, {"en": "Frequency", "de": "Frequenz"}, True),
        ({"en": "Frequency", "de": "Frequenz"}, {"en": "Frequency", "de": "Frequenz"}, True),
        ({"en": "Frequency", "de": "Frequenz"}, {"en": "Frequency", "it": "Frequenza"}, False),
        ({"en": "Frequency", "de": "Frequenz"}, {"en": "Frequency", "de": "Speed"}, False),
        ({"en": "Frequency", "de": "Frequenz"}, {"en": "Frequency"}, True),
        ({"en": "Frequency", "de": "Frequenz"}, "Frequency", True),
        ({"en": "Frequency", "de": "Frequenz"}, "Speed", False),
    ],
)
def test_subset(content: dict, subset: Union[dict, str], should_match: bool):
    """Testing the '.matches()' method with sets and subsets."""
    name = DccLangName(content)
    assert name.matches(subset) is should_match


def test_matches_with_invalid_type():
    """Testing whether the '.matches()' method raises the correct error."""
    content = {"en": "Frequency", "de": "Frequenz"}
    name_instance = DccLangName(content)
    with pytest.raises(TypeError):
        name_instance.matches(123)
