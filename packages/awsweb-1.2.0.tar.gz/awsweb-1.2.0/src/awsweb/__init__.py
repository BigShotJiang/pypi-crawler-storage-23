"""awsweb - A simple FastAPI web server."""

__version__ = "1.2.0"
