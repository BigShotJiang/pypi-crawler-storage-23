import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from l0n0lc import jit, 映射类型, int32
if not os.path.exists('l0n0lcoutput'):
    os.mkdir('l0n0lcoutput')

with open('l0n0lcoutput/Person.h', 'w') as fp:
    fp.write('''
#pragma once
struct Person{
    Person(){}
    int age = 123;
    int get_age(){
        return this->age;
    }
};             
''')
    

@映射类型('Person', ['"Person.h"'])
class Person:
    age:int32 = int32(0)

    def get_age(self)->int32:
        return int32(0)
    

@jit(总是重编=True)
def test_person():
    p = Person()
    p.age = int32(12)
    age = p.get_age()
    age2 = p.age
    print(age, age2)

test_person()