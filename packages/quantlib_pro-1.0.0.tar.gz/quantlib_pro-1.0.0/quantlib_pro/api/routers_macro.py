"""
FastAPI Router for Macro Economic Data (FRED Integration)

Provides real economic indicators from the Federal Reserve Economic Data (FRED) API.
Endpoints for GDP, unemployment, inflation, interest rates, and macro regime detection.
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from quantlib_pro.data.fred_provider import FREDProvider

logger = logging.getLogger(__name__)

macro_router = APIRouter(
    prefix="/macro", 
    tags=["Federal Reserve Economic Data (FRED)"],
    responses={
        429: {"description": "Rate limit exceeded"},
        500: {"description": "Internal server error"},
        503: {"description": "FRED service unavailable"}
    }
)

# Global FRED provider (reuse connection)
_fred_provider: Optional[FREDProvider] = None


def get_fred_provider() -> FREDProvider:
    """Get or create FRED provider."""
    global _fred_provider
    if _fred_provider is None:
        try:
            # Use the project's FRED API key
            _fred_provider = FREDProvider(api_key="5f5dcf2ef53c496228fa2935b71d9d40")
            logger.info("FRED provider initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize FRED provider: {e}")
            raise HTTPException(
                status_code=503, 
                detail=f"FRED service unavailable: {e}"
            )
    return _fred_provider


# Request/Response Models
class EconomicIndicatorsRequest(BaseModel):
    indicators: List[str] = Field(
        default=["GDP_GROWTH", "UNEMPLOYMENT", "CPI", "FED_RATE"],
        description="Economic indicators to fetch"
    )
    periods: int = Field(default=60, description="Number of periods to retrieve")


class MacroRegimeResponse(BaseModel):
    regime: str
    confidence: float
    expansion_probability: float
    recession_probability: float
    indicators: Dict[str, float]
    last_updated: str


class YieldCurveResponse(BaseModel):
    rates: Dict[str, float]
    last_updated: str


# Endpoints
@macro_router.post("/indicators")
async def get_economic_indicators(request: EconomicIndicatorsRequest):
    """
    Get real economic indicators from FRED.
    
    Fetches current and historical data for key economic indicators including:
    - GDP Growth Rate
    - Unemployment Rate  
    - Consumer Price Index (CPI)
    - Federal Funds Rate
    - Manufacturing PMI
    - Consumer Sentiment
    """
    try:
        fred = get_fred_provider()
        
        # Fetch economic indicators
        data = fred.get_economic_indicators(
            indicators=request.indicators,
            periods=request.periods
        )
        
        # Get current snapshot
        snapshot = fred.get_macro_regime_data()
        
        response = {
            "indicators": request.indicators,
            "periods_requested": request.periods,
            "periods_returned": len(data) if not data.empty else 0,
            "current_values": snapshot,
            "historical_data": data.to_dict('index') if not data.empty else {},
            "data_source": "Federal Reserve Economic Data (FRED)",
            "last_updated": datetime.now().isoformat(),
        }
        
        return response
        
    except Exception as e:
        logger.error(f"Failed to fetch economic indicators: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch economic data: {e}"
        )


@macro_router.get(
    "/regime",
    summary="Real-Time Macroeconomic Regime Analysis",
    description="**Live economic regime detection** using Federal Reserve data for institutional investment decision-making.",
)
async def get_macro_regime():
    """
    **Real-Time Macroeconomic Regime Analysis using Federal Reserve Data**
    
    Analyze current economic conditions using live data from the Federal Reserve Economic 
    Database (FRED) to determine market regime for institutional investment strategies.
    
    **Economic Regimes:**
    - **Expansion**: GDP growth >2.5%, unemployment <4%, manufacturing PMI >52  
    - **Recession**: GDP contraction, unemployment >6%, inverted yield curve
    - **Transition**: Mixed economic signals indicating regime change in progress
    
    **Data Sources (Real-Time):**
    - **GDP Growth Rate**: Quarterly annualized rate from Bureau of Economic Analysis
    - **Unemployment Rate**: Monthly non-farm payroll data from Bureau of Labor Statistics  
    - **Federal Funds Rate**: Target rate from Federal Open Market Committee
    - **10-Year Treasury**: Daily yield from U.S. Treasury Department
    - **Manufacturing PMI**: Institute for Supply Management purchasing managers index
    - **Yield Curve**: 2Y/10Y spread for recession probability assessment
    
    **Institutional Applications:**
    - **Asset Allocation**: Regime-based portfolio rebalancing strategies
    - **Risk Management**: Recession probability for stress testing scenarios
    - **Hedge Fund Strategies**: Macro trend following and contrarian positioning
    - **Fixed Income**: Duration and credit allocation based on regime outlook
    
    **Data Reliability:**
    - **Source**: Federal Reserve Economic Data (FRED) API
    - **Update Frequency**: Real-time with automatic cache refresh
    - **Historical Coverage**: 70+ years of economic data for backtesting
    - **Enterprise SLA**: 99.9% data availability guarantee
    
    Returns:
        Current regime assessment, confidence levels, economic indicators, and recession probability
    """
    try:
        fred = get_fred_provider()
        regime_analysis = fred.assess_macro_regime()
        
        return MacroRegimeResponse(**regime_analysis)
        
    except Exception as e:
        logger.error(f"Failed to analyze macro regime: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Macro regime analysis failed: {e}"
        )


@macro_router.get("/yield-curve")
async def get_yield_curve():
    """
    Get current US Treasury yield curve.
    
    Returns rates for:
    - 3 Month Treasury
    - 2 Year Treasury  
    - 5 Year Treasury
    - 10 Year Treasury
    - 30 Year Treasury
    
    Yield curve shape indicates economic expectations and recession risk.
    """
    try:
        fred = get_fred_provider()
        rates = fred.get_yield_curve_data()
        
        return YieldCurveResponse(
            rates=rates,
            last_updated=datetime.now().isoformat()
        )
        
    except Exception as e:
        logger.error(f"Failed to fetch yield curve: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Yield curve data unavailable: {e}"
        )


@macro_router.get("/recession-probability")  
async def get_recession_probability():
    """
    Calculate recession probability using economic indicators.
    
    Uses the Sahm Rule and other recession indicators:
    - Unemployment rate changes
    - Inverted yield curve (10Y-2Y spread)
    - Manufacturing PMI below 50
    - Consumer sentiment decline
    
    Returns probability score and contributing factors.
    """
    try:
        fred = get_fred_provider()
        indicators = fred.get_recession_indicators()
        
        return {
            "recession_probability": indicators.get("recession_probability", 0.0),
            "sahm_indicator": indicators.get("sahm_indicator", 0.0),
            "yield_spread_10y_2y": indicators.get("yield_spread_10y_2y", 200),
            "contributing_factors": {
                "unemployment_rate": indicators.get("unemployment_rate", 4.0),
                "pmi": indicators.get("pmi", 52.0),
                "consumer_sentiment": indicators.get("consumer_sentiment", 100.0),
            },
            "interpretation": {
                "low_risk": "< 20% probability",
                "moderate_risk": "20-50% probability", 
                "high_risk": "> 50% probability",
            },
            "data_source": "Federal Reserve Economic Data (FRED)",
            "last_updated": datetime.now().isoformat(),
        }
        
    except Exception as e:
        logger.error(f"Failed to calculate recession probability: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Recession analysis failed: {e}"
        )


@macro_router.get("/series/{series_name}")
async def get_economic_series(
    series_name: str,
    periods: int = Query(default=60, description="Number of periods"),
    start_date: Optional[str] = Query(default=None, description="Start date YYYY-MM-DD")
):
    """
    Get historical time series for specific economic indicator.
    
    Available series:
    - GDP, GDP_GROWTH
    - UNEMPLOYMENT  
    - INFLATION, CPI
    - FED_FUNDS, TREASURY_10Y, TREASURY_2Y
    - PMI
    """
    try:
        fred = get_fred_provider()
        
        data = fred.get_historical_series(
            series=series_name,
            start_date=start_date,
            periods=periods
        )
        
        if data.empty:
            raise HTTPException(
                status_code=404,
                detail=f"No data found for series: {series_name}"
            )
        
        return {
            "series": series_name,
            "periods_returned": len(data),
            "start_date": data.index.min().strftime('%Y-%m-%d'),
            "end_date": data.index.max().strftime('%Y-%m-%d'),
            "data": data.to_dict('index'),
            "data_source": "Federal Reserve Economic Data (FRED)",
            "last_updated": datetime.now().isoformat(),
        }
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to fetch series {series_name}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch economic series: {e}"
        )


@macro_router.get("/health")
async def macro_health():
    """Check FRED service health and connectivity."""
    try:
        fred = get_fred_provider()
        
        # Test connection by fetching one indicator
        test_data = fred.fred.get_latest_value('GS10')
        
        return {
            "status": "healthy",
            "fred_connection": "active",
            "test_indicator": "10Y Treasury Rate",
            "test_value": test_data[0],
            "test_date": test_data[1],
            "last_checked": datetime.now().isoformat(),
        }
        
    except Exception as e:
        logger.error(f"FRED health check failed: {e}")
        return {
            "status": "unhealthy", 
            "error": str(e),
            "fred_connection": "failed",
            "last_checked": datetime.now().isoformat(),
        }