"""Suite: Advanced Analytics

Consolidates:
- Correlation-Matrix-Evolution
- correlation-Regime-Tectonic-Shift-Engine
- Correlation-Contagion-Shock-Simulator

Provides advanced analytical tools for market analysis.
"""

# SDK Manager interface
from .manager import AnalyticsManager

# Correlation analysis (Week 15)
from quantlib_pro.analytics.correlation_analysis import (
    CorrelationAnalyzer,
    CorrelationBreakdown,
    CorrelationRegime,
    RegimeChange,
)

__all__ = [
    # SDK Manager
    "AnalyticsManager",
    # Correlation
    "CorrelationAnalyzer",
    "CorrelationBreakdown",
    "CorrelationRegime",
    "RegimeChange",
]
