"""Tests for Pydantic models."""

import pytest
from pydantic import ValidationError

from podcut.models import (
    ColdOpenCandidate,
    ColdOpenSegmentPart,
    ExtractedSegment,
    GeminiAnalysisResult,
    RefinedTimestamp,
    RefinedTimestampPart,
    Segment,
    Transcript,
    Word,
)


class TestWord:
    def test_create(self):
        w = Word(word="hello", start=1.0, end=1.5, probability=0.95)
        assert w.word == "hello"
        assert w.start == 1.0
        assert w.end == 1.5
        assert w.probability == 0.95


class TestSegment:
    def test_create(self):
        s = Segment(id=0, start=0.0, end=5.0, text="Hello world")
        assert s.id == 0
        assert s.text == "Hello world"


class TestTranscript:
    def test_create_minimal(self):
        t = Transcript(text="Hello", language="en")
        assert t.text == "Hello"
        assert t.segments == []
        assert t.words == []

    def test_create_full(self):
        t = Transcript(
            text="Hello world",
            language="en",
            segments=[Segment(id=0, start=0.0, end=2.0, text="Hello world")],
            words=[
                Word(word="Hello", start=0.0, end=0.5, probability=0.9),
                Word(word="world", start=0.6, end=1.0, probability=0.95),
            ],
        )
        assert len(t.segments) == 1
        assert len(t.words) == 2


class TestColdOpenCandidate:
    def test_create(self):
        c = ColdOpenCandidate(
            rank=1,
            start_time=60.0,
            end_time=90.0,
            speaker="Host",
            hook_type="question",
            transcript_excerpt="What if I told you...",
            reasoning="Provocative question",
            engagement_score=8,
        )
        assert c.rank == 1
        assert c.engagement_score == 8

    def test_score_validation(self):
        with pytest.raises(ValidationError):
            ColdOpenCandidate(
                rank=1,
                start_time=0.0,
                end_time=30.0,
                hook_type="question",
                transcript_excerpt="test",
                reasoning="test",
                engagement_score=11,  # > 10
            )

        with pytest.raises(ValidationError):
            ColdOpenCandidate(
                rank=1,
                start_time=0.0,
                end_time=30.0,
                hook_type="question",
                transcript_excerpt="test",
                reasoning="test",
                engagement_score=0,  # < 1
            )


class TestGeminiAnalysisResult:
    def test_parse(self):
        data = {
            "candidates": [
                {
                    "rank": 1,
                    "start_time": 120.5,
                    "end_time": 150.0,
                    "speaker": "Guest",
                    "hook_type": "story",
                    "transcript_excerpt": "Once upon a time...",
                    "reasoning": "Compelling narrative",
                    "engagement_score": 9,
                }
            ]
        }
        result = GeminiAnalysisResult.model_validate(data)
        assert len(result.candidates) == 1
        assert result.candidates[0].hook_type == "story"


class TestColdOpenSegmentPart:
    def test_create(self):
        p = ColdOpenSegmentPart(
            start_time=10.0,
            end_time=25.0,
            transcript_excerpt="Part one text",
        )
        assert p.start_time == 10.0
        assert p.end_time == 25.0


class TestColdOpenCandidateMultiSegment:
    def test_multi_segment_candidate(self):
        c = ColdOpenCandidate(
            rank=1,
            start_time=10.0,
            end_time=600.0,
            speaker="Host and Guest",
            hook_type="debate",
            transcript_excerpt="Combined text",
            reasoning="Good debate",
            engagement_score=8,
            is_multi_segment=True,
            segments=[
                ColdOpenSegmentPart(start_time=10.0, end_time=25.0, transcript_excerpt="Part 1"),
                ColdOpenSegmentPart(start_time=580.0, end_time=600.0, transcript_excerpt="Part 2"),
            ],
        )
        assert c.is_multi_segment is True
        assert len(c.segments) == 2
        assert c.segments[0].start_time == 10.0

    def test_default_single_segment(self):
        c = ColdOpenCandidate(
            rank=1,
            start_time=60.0,
            end_time=90.0,
            hook_type="question",
            transcript_excerpt="text",
            reasoning="reason",
            engagement_score=7,
        )
        assert c.is_multi_segment is False
        assert c.segments == []


class TestRefinedTimestampPart:
    def test_create(self):
        p = RefinedTimestampPart(
            refined_start_sec=9.8,
            refined_end_sec=25.2,
            duration_seconds=15.4,
            cut_quality="clean",
        )
        assert p.duration_seconds == 15.4
        assert p.cut_quality == "clean"


class TestRefinedTimestamp:
    def test_create(self):
        r = RefinedTimestamp(
            original_rank=1,
            refined_start_sec=59.8,
            refined_end_sec=90.2,
            duration_seconds=30.4,
            cut_quality="clean",
        )
        assert r.cut_quality == "clean"
        assert r.duration_seconds == 30.4
        assert r.parts == []

    def test_with_parts(self):
        r = RefinedTimestamp(
            original_rank=1,
            refined_start_sec=9.8,
            refined_end_sec=600.2,
            duration_seconds=30.0,
            cut_quality="clean",
            parts=[
                RefinedTimestampPart(
                    refined_start_sec=9.8,
                    refined_end_sec=25.0,
                    duration_seconds=15.2,
                    cut_quality="clean",
                ),
                RefinedTimestampPart(
                    refined_start_sec=580.0,
                    refined_end_sec=600.2,
                    duration_seconds=20.2,
                    cut_quality="word_boundary",
                ),
            ],
        )
        assert len(r.parts) == 2
        assert r.parts[0].refined_start_sec == 9.8


class TestExtractedSegment:
    def test_create(self, tmp_path):
        e = ExtractedSegment(
            rank=1,
            file_path=tmp_path / "output.mp3",
            start_time=59.8,
            end_time=90.2,
            duration_seconds=30.4,
            hook_type="question",
            speaker="Host",
            transcript_excerpt="What if...",
            reasoning="Great hook",
            engagement_score=8,
            cut_quality="clean",
        )
        assert e.rank == 1
        assert e.file_path.name == "output.mp3"
