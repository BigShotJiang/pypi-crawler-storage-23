"""Tests for the interactive wizard prompt helpers."""

from unittest.mock import patch

import pytest

from podcut.wizard import (
    WizardCancelled,
    _check_and_prompt_api_key,
    _clean_dropped_path,
    _format_file_size,
    _prompt,
    _prompt_choice,
    _prompt_confirm,
    _prompt_int,
    _prompt_path,
    _resolve_model_default,
    _scan_audio_files,
)


# ---------------------------------------------------------------------------
# _prompt
# ---------------------------------------------------------------------------


class TestPrompt:
    def test_returns_user_input(self):
        with patch("builtins.input", return_value="hello"):
            assert _prompt("Enter") == "hello"

    def test_returns_default_on_empty(self):
        with patch("builtins.input", return_value=""):
            assert _prompt("Enter", default="fallback") == "fallback"

    def test_strips_whitespace(self):
        with patch("builtins.input", return_value="  hi  "):
            assert _prompt("Enter") == "hi"

    def test_keyboard_interrupt_raises_cancelled(self):
        with patch("builtins.input", side_effect=KeyboardInterrupt):
            with pytest.raises(WizardCancelled):
                _prompt("Enter")

    def test_eof_raises_cancelled(self):
        with patch("builtins.input", side_effect=EOFError):
            with pytest.raises(WizardCancelled):
                _prompt("Enter")


# ---------------------------------------------------------------------------
# _prompt_int
# ---------------------------------------------------------------------------


class TestPromptInt:
    def test_valid_value(self):
        with patch("builtins.input", return_value="5"):
            assert _prompt_int("N", default=3, min_val=1, max_val=10) == 5

    def test_default_on_empty(self):
        with patch("builtins.input", return_value=""):
            assert _prompt_int("N", default=3, min_val=1, max_val=10) == 3

    def test_rejects_then_accepts(self):
        # First "abc" is invalid, then "0" is out of range, then "5" is good
        with patch("builtins.input", side_effect=["abc", "0", "5"]):
            assert _prompt_int("N", default=3, min_val=1, max_val=10) == 5

    def test_out_of_range_retries(self):
        with patch("builtins.input", side_effect=["99", "2"]):
            assert _prompt_int("N", default=3, min_val=1, max_val=10) == 2


# ---------------------------------------------------------------------------
# _prompt_choice
# ---------------------------------------------------------------------------


class TestPromptChoice:
    def test_select_by_number(self):
        with patch("builtins.input", return_value="2"):
            result = _prompt_choice("Pick", ["alpha", "beta", "gamma"], "alpha")
            assert result == "beta"

    def test_select_by_value(self):
        with patch("builtins.input", return_value="gamma"):
            result = _prompt_choice("Pick", ["alpha", "beta", "gamma"], "alpha")
            assert result == "gamma"

    def test_default_on_empty(self):
        with patch("builtins.input", return_value=""):
            result = _prompt_choice("Pick", ["alpha", "beta"], "alpha")
            assert result == "alpha"

    def test_invalid_then_valid(self):
        with patch("builtins.input", side_effect=["99", "invalid", "1"]):
            result = _prompt_choice("Pick", ["alpha", "beta"], "alpha")
            assert result == "alpha"


# ---------------------------------------------------------------------------
# _prompt_confirm
# ---------------------------------------------------------------------------


class TestPromptConfirm:
    def test_yes(self):
        with patch("builtins.input", return_value="y"):
            assert _prompt_confirm("OK?") is True

    def test_no(self):
        with patch("builtins.input", return_value="n"):
            assert _prompt_confirm("OK?") is False

    def test_default_true(self):
        with patch("builtins.input", return_value=""):
            assert _prompt_confirm("OK?", default=True) is True

    def test_default_false(self):
        with patch("builtins.input", return_value=""):
            assert _prompt_confirm("OK?", default=False) is False

    def test_yes_uppercase(self):
        with patch("builtins.input", return_value="Yes"):
            assert _prompt_confirm("OK?") is True


# ---------------------------------------------------------------------------
# _prompt_path
# ---------------------------------------------------------------------------


class TestPromptPath:
    def test_valid_audio_file(self, sample_wav):
        with patch("builtins.input", return_value=str(sample_wav)):
            result = _prompt_path("File")
            assert result == sample_wav.resolve()

    def test_nonexistent_retries(self, sample_wav):
        with patch("builtins.input", side_effect=["/no/such/file.mp3", str(sample_wav)]):
            result = _prompt_path("File")
            assert result == sample_wav.resolve()

    def test_unsupported_format_retries(self, tmp_path, sample_wav):
        bad_file = tmp_path / "notes.txt"
        bad_file.write_text("not audio")
        with patch("builtins.input", side_effect=[str(bad_file), str(sample_wav)]):
            result = _prompt_path("File")
            assert result == sample_wav.resolve()

    def test_empty_input_retries(self, sample_wav):
        with patch("builtins.input", side_effect=["", str(sample_wav)]):
            result = _prompt_path("File")
            assert result == sample_wav.resolve()

    def test_ctrl_c_raises_cancelled(self):
        with patch("builtins.input", side_effect=KeyboardInterrupt):
            with pytest.raises(WizardCancelled):
                _prompt_path("File")

    def test_select_by_number_from_scan(self, tmp_path):
        """When audio files are found, user can select by number."""
        audio = tmp_path / "episode.mp3"
        audio.write_bytes(b"\x00" * 1024)
        with patch("podcut.wizard._scan_audio_files", return_value=[audio]):
            with patch("builtins.input", return_value="1"):
                result = _prompt_path("File")
                assert result == audio.resolve()

    def test_drag_and_drop_quoted_path(self, sample_wav):
        """Drag-and-drop with surrounding quotes should work."""
        quoted = f"'{sample_wav}'"
        with patch("builtins.input", return_value=quoted):
            result = _prompt_path("File")
            assert result == sample_wav.resolve()

    def test_drag_and_drop_escaped_spaces(self, tmp_path):
        """Drag-and-drop with backslash-escaped spaces should work."""
        spaced_dir = tmp_path / "my podcast"
        spaced_dir.mkdir()
        audio = spaced_dir / "episode.mp3"
        audio.write_bytes(b"\x00" * 1024)
        escaped = str(audio).replace(" ", "\\ ")
        with patch("builtins.input", return_value=escaped):
            result = _prompt_path("File")
            assert result == audio.resolve()


# ---------------------------------------------------------------------------
# _clean_dropped_path
# ---------------------------------------------------------------------------


class TestCleanDroppedPath:
    def test_strips_single_quotes(self):
        assert _clean_dropped_path("'/path/to/file.mp3'") == "/path/to/file.mp3"

    def test_strips_double_quotes(self):
        assert _clean_dropped_path('"/path/to/file.mp3"') == "/path/to/file.mp3"

    def test_unescapes_backslash_space(self):
        assert _clean_dropped_path("/path/to/my\\ file.mp3") == "/path/to/my file.mp3"

    def test_strips_whitespace(self):
        assert _clean_dropped_path("  /path/to/file.mp3  ") == "/path/to/file.mp3"

    def test_combined_quotes_and_spaces(self):
        assert _clean_dropped_path("'/path/to/my\\ file.mp3'") == "/path/to/my file.mp3"

    def test_plain_path_unchanged(self):
        assert _clean_dropped_path("/path/to/file.mp3") == "/path/to/file.mp3"


# ---------------------------------------------------------------------------
# _format_file_size
# ---------------------------------------------------------------------------


class TestFormatFileSize:
    def test_bytes(self):
        assert _format_file_size(500) == "500 B"

    def test_kilobytes(self):
        assert _format_file_size(2048) == "2.0 KB"

    def test_megabytes(self):
        assert _format_file_size(125 * 1024 * 1024) == "125.0 MB"

    def test_gigabytes(self):
        assert _format_file_size(2 * 1024 * 1024 * 1024) == "2.0 GB"


# ---------------------------------------------------------------------------
# _scan_audio_files
# ---------------------------------------------------------------------------


class TestScanAudioFiles:
    def test_finds_audio_in_cwd(self, tmp_path, monkeypatch):
        (tmp_path / "episode.mp3").write_bytes(b"\x00" * 100)
        (tmp_path / "notes.txt").write_text("not audio")
        monkeypatch.chdir(tmp_path)
        files = _scan_audio_files()
        assert len(files) == 1
        assert files[0].name == "episode.mp3"

    def test_finds_audio_in_subdir(self, tmp_path, monkeypatch):
        sub = tmp_path / "episodes"
        sub.mkdir()
        (sub / "ep01.wav").write_bytes(b"\x00" * 100)
        monkeypatch.chdir(tmp_path)
        files = _scan_audio_files()
        assert len(files) == 1
        assert files[0].name == "ep01.wav"

    def test_ignores_hidden_dirs(self, tmp_path, monkeypatch):
        hidden = tmp_path / ".hidden"
        hidden.mkdir()
        (hidden / "secret.mp3").write_bytes(b"\x00" * 100)
        monkeypatch.chdir(tmp_path)
        files = _scan_audio_files()
        assert len(files) == 0

    def test_multiple_extensions(self, tmp_path, monkeypatch):
        for name in ["a.mp3", "b.wav", "c.m4a", "d.flac", "e.ogg", "f.aac"]:
            (tmp_path / name).write_bytes(b"\x00" * 100)
        monkeypatch.chdir(tmp_path)
        files = _scan_audio_files()
        assert len(files) == 6


# ---------------------------------------------------------------------------
# _resolve_model_default
# ---------------------------------------------------------------------------


class TestResolveModelDefault:
    def test_returns_hardcoded_default_with_no_saved(self):
        assert _resolve_model_default("gemini", {}) == "gemini-2.5-flash"

    def test_uses_provider_specific_saved_model(self):
        saved = {"llm_model_gemini": "gemini-2.5-pro"}
        assert _resolve_model_default("gemini", saved) == "gemini-2.5-pro"

    def test_falls_back_to_generic_saved_model(self):
        saved = {"llm_model": "gpt-4.1"}
        assert _resolve_model_default("openai", saved) == "gpt-4.1"

    def test_ignores_invalid_saved_model(self):
        saved = {"llm_model_gemini": "nonexistent-model"}
        assert _resolve_model_default("gemini", saved) == "gemini-2.5-flash"

    def test_provider_specific_takes_precedence(self):
        saved = {"llm_model": "gpt-4.1-mini", "llm_model_openai": "gpt-4.1"}
        assert _resolve_model_default("openai", saved) == "gpt-4.1"


# ---------------------------------------------------------------------------
# _check_and_prompt_api_key
# ---------------------------------------------------------------------------


class TestCheckAndPromptApiKey:
    def test_ollama_skips_check(self):
        # Should not raise or prompt
        _check_and_prompt_api_key("ollama")

    def test_skips_when_key_exists(self, monkeypatch):
        monkeypatch.setenv("GEMINI_API_KEY", "test-key")
        # Should not raise or prompt
        _check_and_prompt_api_key("gemini")

    def test_prompts_when_key_missing(self, monkeypatch, tmp_path):
        monkeypatch.delenv("GEMINI_API_KEY", raising=False)
        # Redirect .env save to temp dir
        env_path = tmp_path / ".env"
        monkeypatch.setattr(
            "podcut.config._dotenv_path_for_save", lambda: env_path
        )
        with patch("builtins.input", return_value="AIzaSyTest123"):
            _check_and_prompt_api_key("gemini")
        # Key should now be in environment
        assert monkeypatch.delenv("GEMINI_API_KEY", raising=False) is None or True

    def test_retries_on_empty_input(self, monkeypatch, tmp_path):
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        env_path = tmp_path / ".env"
        monkeypatch.setattr(
            "podcut.config._dotenv_path_for_save", lambda: env_path
        )
        with patch("builtins.input", side_effect=["", "", "sk-test123"]):
            _check_and_prompt_api_key("openai")
