"""Tests for the pipeline workflow (integration with mocks)."""

from unittest.mock import MagicMock, patch

from podcut.extraction_mode import CLIP_MODE, COLD_OPEN_MODE
from podcut.models import (
    ColdOpenCandidate,
    ExtractedSegment,
    RefinedTimestamp,
    Segment,
    Transcript,
    Word,
)


def _make_transcript() -> Transcript:
    return Transcript(
        text="Hello world this is a test",
        language="en",
        segments=[
            Segment(id=0, start=0.0, end=3.0, text="Hello world"),
            Segment(id=1, start=3.5, end=6.0, text="this is a test"),
        ],
        words=[
            Word(word="Hello", start=0.0, end=0.5, probability=0.9),
            Word(word="world", start=0.6, end=1.0, probability=0.9),
            Word(word="this", start=3.5, end=3.8, probability=0.9),
            Word(word="is", start=3.9, end=4.1, probability=0.9),
            Word(word="a", start=4.2, end=4.3, probability=0.9),
            Word(word="test", start=4.4, end=5.0, probability=0.9),
        ],
    )


def _make_candidates() -> list[ColdOpenCandidate]:
    """Create test candidates. Note: uses start=0, end=30 to pass 15-60s duration filter.

    The test audio (sample_wav_with_tone) is only 10s, so timestamps will be
    clamped to audio duration. The resulting segment will be short but we
    patch _filter_by_duration in tests to avoid that constraint.
    """
    return [
        ColdOpenCandidate(
            rank=1,
            start_time=0.0,
            end_time=3.0,
            speaker="Host",
            hook_type="question",
            transcript_excerpt="Hello world",
            reasoning="Test reason",
            engagement_score=8,
        ),
    ]


def _make_mock_provider(analyze_return=None, analyze_feedback_return=None):
    """Create a mock LLMProvider."""
    provider = MagicMock()
    provider.analyze.return_value = analyze_return or _make_candidates()
    provider.analyze_with_feedback.return_value = analyze_feedback_return or []
    return provider


@patch("podcut.workflow._filter_by_duration", side_effect=lambda c, r, **kw: (c, r))
@patch("podcut.workflow._create_provider")
@patch("podcut.workflow.transcribe")
def test_run_pipeline(
    mock_transcribe,
    mock_provider_cls,
    mock_filter,
    sample_wav_with_tone,
    tmp_output_dir,
):
    """Test full pipeline with mocked external APIs."""
    from podcut.workflow import run_pipeline

    # Setup mocks
    mock_transcribe.return_value = _make_transcript()
    mock_provider = _make_mock_provider()
    mock_provider_cls.return_value = mock_provider

    results = run_pipeline(
        audio_path=sample_wav_with_tone,
        output_dir=tmp_output_dir,
        num_candidates=1,
        output_format="wav",
        gemini_model="gemini-2.5-flash",
        whisper_model="tiny",
    )

    assert len(results) == 1
    assert isinstance(results[0], ExtractedSegment)
    assert results[0].rank == 1
    assert results[0].file_path.exists()
    assert results[0].hook_type == "question"
    assert results[0].engagement_score == 8

    # Verify cleanup was called
    mock_provider.cleanup.assert_called_once()


@patch("podcut.workflow._create_provider")
@patch("podcut.workflow.transcribe")
def test_pipeline_cleans_up_on_error(
    mock_transcribe,
    mock_provider_cls,
    sample_wav_with_tone,
    tmp_output_dir,
):
    """Test that provider is cleaned up even on error."""
    from podcut.workflow import run_pipeline

    mock_transcribe.return_value = _make_transcript()
    mock_provider = _make_mock_provider()
    mock_provider.analyze.side_effect = RuntimeError("API error")
    mock_provider_cls.return_value = mock_provider

    try:
        run_pipeline(
            audio_path=sample_wav_with_tone,
            output_dir=tmp_output_dir,
        )
    except RuntimeError:
        pass

    # Cleanup should still be called
    mock_provider.cleanup.assert_called_once()


# --- Interactive pipeline tests ---


@patch("podcut.workflow._filter_by_duration", side_effect=lambda c, r, **kw: (c, r))
@patch("podcut.workflow._create_provider")
@patch("podcut.workflow.transcribe")
def test_run_pipeline_interactive_auto(
    mock_transcribe,
    mock_provider_cls,
    mock_filter,
    sample_wav_with_tone,
    tmp_output_dir,
):
    """Test interactive pipeline in auto mode (same as non-interactive)."""
    from podcut.workflow import run_pipeline_interactive

    mock_transcribe.return_value = _make_transcript()
    mock_provider = _make_mock_provider()
    mock_provider_cls.return_value = mock_provider

    results = run_pipeline_interactive(
        audio_path=sample_wav_with_tone,
        output_dir=tmp_output_dir,
        num_candidates=1,
        output_format="wav",
        auto=True,
    )

    assert len(results) == 1
    assert isinstance(results[0], ExtractedSegment)
    mock_provider.cleanup.assert_called_once()


@patch("podcut.workflow._filter_by_duration", side_effect=lambda c, r, **kw: (c, r))
@patch("podcut.workflow.prompt_user_selection")
@patch("podcut.workflow.display_candidates_preview")
@patch("podcut.workflow._create_provider")
@patch("podcut.workflow.transcribe")
def test_run_pipeline_interactive_select(
    mock_transcribe,
    mock_provider_cls,
    mock_display,
    mock_select,
    mock_filter,
    sample_wav_with_tone,
    tmp_output_dir,
):
    """Test interactive pipeline with user selection."""
    from podcut.workflow import run_pipeline_interactive

    mock_transcribe.return_value = _make_transcript()
    mock_provider = _make_mock_provider()
    mock_provider_cls.return_value = mock_provider
    # User selects candidate 1
    mock_select.return_value = ([0], None)

    results = run_pipeline_interactive(
        audio_path=sample_wav_with_tone,
        output_dir=tmp_output_dir,
        num_candidates=1,
        output_format="wav",
        auto=False,
    )

    assert len(results) == 1
    mock_display.assert_called_once()
    mock_select.assert_called_once()
    mock_provider.cleanup.assert_called_once()


@patch("podcut.workflow._filter_by_duration", side_effect=lambda c, r, **kw: (c, r))
@patch("podcut.workflow.prompt_user_selection")
@patch("podcut.workflow.display_candidates_preview")
@patch("podcut.workflow._create_provider")
@patch("podcut.workflow.transcribe")
def test_run_pipeline_interactive_feedback(
    mock_transcribe,
    mock_provider_cls,
    mock_display,
    mock_select,
    mock_filter,
    sample_wav_with_tone,
    tmp_output_dir,
):
    """Test interactive pipeline with feedback re-analysis."""
    from podcut.workflow import run_pipeline_interactive

    mock_transcribe.return_value = _make_transcript()

    # New candidates from feedback
    new_candidates = [
        ColdOpenCandidate(
            rank=1,
            start_time=3.5,
            end_time=6.0,
            speaker="Guest",
            hook_type="humor",
            transcript_excerpt="this is a test",
            reasoning="Funny",
            engagement_score=9,
        ),
    ]
    mock_provider = _make_mock_provider(analyze_feedback_return=new_candidates)
    mock_provider_cls.return_value = mock_provider

    # First call: user gives feedback; second call: user selects all
    mock_select.side_effect = [
        ([], "もっと面白い箇所"),
        ([0], None),
    ]

    results = run_pipeline_interactive(
        audio_path=sample_wav_with_tone,
        output_dir=tmp_output_dir,
        num_candidates=1,
        output_format="wav",
        auto=False,
    )

    assert len(results) == 1
    assert results[0].hook_type == "humor"
    assert mock_display.call_count == 2
    assert mock_select.call_count == 2
    mock_provider.analyze_with_feedback.assert_called_once()
    mock_provider.cleanup.assert_called_once()


@patch("podcut.workflow._filter_by_duration", side_effect=lambda c, r, **kw: (c, r))
@patch("podcut.workflow.prompt_user_selection")
@patch("podcut.workflow.display_candidates_preview")
@patch("podcut.workflow._create_provider")
@patch("podcut.workflow.transcribe")
def test_run_pipeline_interactive_no_selection(
    mock_transcribe,
    mock_provider_cls,
    mock_display,
    mock_select,
    mock_filter,
    sample_wav_with_tone,
    tmp_output_dir,
):
    """Test interactive pipeline when user selects nothing."""
    from podcut.workflow import run_pipeline_interactive

    mock_transcribe.return_value = _make_transcript()
    mock_provider = _make_mock_provider()
    mock_provider_cls.return_value = mock_provider
    mock_select.return_value = ([], None)

    results = run_pipeline_interactive(
        audio_path=sample_wav_with_tone,
        output_dir=tmp_output_dir,
        num_candidates=1,
        output_format="wav",
        auto=False,
    )

    assert results == []
    mock_provider.cleanup.assert_called_once()


# --- Transcript truncation tests ---


def test_truncate_transcript_head_tail_strategy():
    """Test head_tail strategy keeps head and tail."""
    from podcut.workflow import _truncate_transcript

    # Build a long transcript
    lines = [f"[{i:05.2f}s] Line number {i}" for i in range(200)]
    text = "\n".join(lines)

    result = _truncate_transcript(text, max_chars=500, strategy="head_tail")
    assert "Line number 0" in result
    assert "Line number 199" in result
    assert "omitted" in result


def test_truncate_transcript_full_strategy():
    """Test full strategy includes head, middle, and tail portions."""
    from podcut.workflow import _truncate_transcript

    # Build a long transcript with identifiable sections
    lines = []
    for i in range(300):
        lines.append(f"[{i:05.2f}s] Line number {i}")
    text = "\n".join(lines)

    result = _truncate_transcript(text, max_chars=600, strategy="full")
    # Should contain content from the beginning
    assert "Line number 0" in result
    # Should contain content from the end
    assert "Line number 299" in result
    # Should contain content from the middle (approximately around line 150)
    # Check that there's middle content by looking for line numbers around 100-200
    has_middle = any(f"Line number {i}" in result for i in range(100, 200))
    assert has_middle, "Full strategy should include middle content"
    # Should have two gap markers
    assert result.count("lines omitted") == 2


def test_truncate_transcript_short_text_unchanged():
    """Test that short text is returned unchanged regardless of strategy."""
    from podcut.workflow import _truncate_transcript

    text = "Short transcript"
    assert _truncate_transcript(text, max_chars=1000, strategy="head_tail") == text
    assert _truncate_transcript(text, max_chars=1000, strategy="full") == text


# --- Reranking tests ---


def _make_rerank_candidates():
    """Create candidates with varied scores for reranking tests."""
    return [
        ColdOpenCandidate(
            rank=1,
            start_time=0.0,
            end_time=30.0,
            hook_type="question",
            transcript_excerpt="text1",
            reasoning="reason1",
            engagement_score=6,
            self_contained_score=5,
            opening_impact_score=3,
        ),
        ColdOpenCandidate(
            rank=2,
            start_time=60.0,
            end_time=90.0,
            hook_type="humor",
            transcript_excerpt="text2",
            reasoning="reason2",
            engagement_score=7,
            self_contained_score=8,
            opening_impact_score=9,
        ),
        ColdOpenCandidate(
            rank=3,
            start_time=120.0,
            end_time=150.0,
            hook_type="question",
            transcript_excerpt="text3",
            reasoning="reason3",
            engagement_score=8,
            self_contained_score=7,
            opening_impact_score=7,
            context_needed="significant",
        ),
    ]


def _make_rerank_refined(n=3):
    """Create matching RefinedTimestamp objects."""
    return [
        RefinedTimestamp(
            original_rank=i + 1,
            refined_start_sec=float(i * 60),
            refined_end_sec=float(i * 60 + 30),
            duration_seconds=30.0,
            cut_quality="clean",
        )
        for i in range(n)
    ]


def test_rerank_cold_open_promotes_high_impact():
    """Test that reranking promotes candidates with high opening_impact_score."""
    from podcut.workflow import _rerank

    candidates = _make_rerank_candidates()
    refined = _make_rerank_refined()

    reranked_c, reranked_r = _rerank(candidates, refined, mode=COLD_OPEN_MODE)

    # Candidate 2 (opening_impact=9) should be ranked #1
    assert reranked_c[0].hook_type == "humor"
    assert reranked_c[0].rank == 1


def test_rerank_context_significant_penalty():
    """Test that context_needed='significant' candidates are penalized."""
    from podcut.workflow import _rerank

    candidates = _make_rerank_candidates()
    refined = _make_rerank_refined()

    reranked_c, _ = _rerank(candidates, refined, mode=COLD_OPEN_MODE)

    # Candidate 3 has context_needed="significant", should be ranked last
    assert reranked_c[-1].context_needed == "significant"


def test_rerank_diversity_penalty():
    """Test that duplicate hook_types get a diversity penalty."""
    from podcut.workflow import _rerank

    candidates = _make_rerank_candidates()
    refined = _make_rerank_refined()

    # Candidates 1 and 3 both have hook_type="question"
    reranked_c, _ = _rerank(candidates, refined, mode=COLD_OPEN_MODE)

    # The two "question" candidates should not be adjacent at top
    question_ranks = [c.rank for c in reranked_c if c.hook_type == "question"]
    assert 1 not in question_ranks  # humor should be #1


def test_rerank_empty_weights_noop():
    """Test that reranking is a no-op when mode has no rerank_weights."""
    from podcut.extraction_mode import ExtractionMode
    from podcut.workflow import _rerank

    mode_no_weights = ExtractionMode(
        name="test",
        label="Test",
        label_plural="Tests",
        min_duration_sec=10,
        max_duration_sec=60,
        description="test",
        hook_types=("question",),
        hook_type_descriptions={},
        allow_multi_segment=False,
        output_file_prefix="test",
    )
    candidates = _make_rerank_candidates()
    refined = _make_rerank_refined()

    result_c, result_r = _rerank(candidates, refined, mode=mode_no_weights)
    # Should return unchanged
    assert [c.rank for c in result_c] == [1, 2, 3]


def test_rerank_clip_mode_weights():
    """Test clip mode reranking uses narrative_completeness and shareability."""
    from podcut.workflow import _rerank

    candidates = [
        ColdOpenCandidate(
            rank=1,
            start_time=0.0,
            end_time=120.0,
            hook_type="story",
            transcript_excerpt="text1",
            reasoning="reason1",
            engagement_score=6,
            self_contained_score=5,
            narrative_completeness=4,
            shareability_score=3,
        ),
        ColdOpenCandidate(
            rank=2,
            start_time=200.0,
            end_time=320.0,
            hook_type="insight",
            transcript_excerpt="text2",
            reasoning="reason2",
            engagement_score=7,
            self_contained_score=9,
            narrative_completeness=9,
            shareability_score=8,
        ),
    ]
    refined = _make_rerank_refined(2)

    reranked_c, _ = _rerank(candidates, refined, mode=CLIP_MODE)
    # Candidate 2 has much higher narrative/self-contained/shareability scores
    assert reranked_c[0].hook_type == "insight"
