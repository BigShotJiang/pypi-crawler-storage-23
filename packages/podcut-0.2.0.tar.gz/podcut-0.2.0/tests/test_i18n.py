"""Tests for the i18n module."""

from podcut.i18n import SUPPORTED_LANGUAGES, _MESSAGES, get_language, set_language, t, t_hook


class TestSetLanguage:
    def setup_method(self):
        set_language("ja")

    def test_default_is_ja(self):
        assert get_language() == "ja"

    def test_switch_to_en(self):
        set_language("en")
        assert get_language() == "en"

    def test_switch_back_to_ja(self):
        set_language("en")
        set_language("ja")
        assert get_language() == "ja"

    def test_unsupported_language_falls_back_to_ja(self):
        import io
        import sys

        stderr_capture = io.StringIO()
        old_stderr = sys.stderr
        sys.stderr = stderr_capture
        try:
            set_language("fr")
        finally:
            sys.stderr = old_stderr
        assert get_language() == "ja"
        output = stderr_capture.getvalue()
        assert "Unsupported language" in output
        assert "fr" in output

    def test_supported_languages_tuple(self):
        assert "ja" in SUPPORTED_LANGUAGES
        assert "en" in SUPPORTED_LANGUAGES


class TestTranslation:
    def setup_method(self):
        set_language("ja")

    def test_returns_ja_by_default(self):
        result = t("wizard_cancelled")
        assert result == "ウィザードがキャンセルされました。"

    def test_returns_en_after_switch(self):
        set_language("en")
        result = t("wizard_cancelled")
        assert result == "Wizard cancelled."

    def test_format_args(self):
        result = t("candidates_found", count=5)
        assert result == "5 候補を検出"

    def test_format_args_en(self):
        set_language("en")
        result = t("candidates_found", count=5)
        assert result == "5 candidates found"

    def test_unknown_key_returns_key(self):
        result = t("nonexistent_key_xyz")
        assert result == "nonexistent_key_xyz"

    def test_step_header_format(self):
        result = t("step_header", current=1, total=8, title="Test")
        assert "1" in result
        assert "8" in result
        assert "Test" in result

    def test_step_header_en(self):
        set_language("en")
        result = t("step_header", current=2, total=7, title="Audio File")
        assert "Step 2/7" in result
        assert "Audio File" in result

    def test_all_keys_have_both_languages(self):
        """Every message key must have both 'ja' and 'en' translations."""
        for key, translations in _MESSAGES.items():
            assert "ja" in translations, f"Key '{key}' missing 'ja' translation"
            assert "en" in translations, f"Key '{key}' missing 'en' translation"

    def test_multiline_format(self):
        set_language("en")
        result = t("gemini_api_key_missing")
        assert "GEMINI_API_KEY" in result
        assert "https://aistudio.google.com/apikey" in result

    def test_ollama_connect_error_format(self):
        set_language("en")
        result = t("ollama_connect_error", url="http://localhost:11434")
        assert "http://localhost:11434" in result
        assert "ollama serve" in result


class TestExtractionModeI18n:
    def setup_method(self):
        set_language("ja")

    def test_cold_open_ui_label_ja(self):
        from podcut.extraction_mode import COLD_OPEN_MODE
        assert COLD_OPEN_MODE.ui_label == "コールドオープン"

    def test_cold_open_ui_label_en(self):
        set_language("en")
        from podcut.extraction_mode import COLD_OPEN_MODE
        assert COLD_OPEN_MODE.ui_label == "Cold Open"

    def test_clip_ui_label_plural_ja(self):
        from podcut.extraction_mode import CLIP_MODE
        assert CLIP_MODE.ui_label_plural == "クリップ候補"

    def test_clip_ui_label_plural_en(self):
        set_language("en")
        from podcut.extraction_mode import CLIP_MODE
        assert CLIP_MODE.ui_label_plural == "Clip Candidates"

    def test_label_unchanged_for_llm(self):
        """The raw .label field should remain English for LLM prompts."""
        from podcut.extraction_mode import COLD_OPEN_MODE, CLIP_MODE
        assert COLD_OPEN_MODE.label == "Cold Open"
        assert CLIP_MODE.label == "Clip"


class TestHookTypeTranslation:
    def setup_method(self):
        set_language("ja")

    def test_new_hook_types_ja(self):
        assert t_hook("tsukkomi") == "ツッコミ"
        assert t_hook("confession") == "本音吐露"
        assert t_hook("realization") == "気づき"

    def test_new_hook_types_en(self):
        set_language("en")
        assert t_hook("tsukkomi") == "tsukkomi"
        assert t_hook("confession") == "confession"
        assert t_hook("realization") == "realization"

    def test_unknown_hook_type_passthrough(self):
        assert t_hook("unknown_type") == "unknown_type"


class TestNewFields:
    def test_cold_open_has_hook_first_3sec_score(self):
        from podcut.extraction_mode import COLD_OPEN_MODE
        assert "hook_first_3sec_score" in COLD_OPEN_MODE.extra_score_fields
        assert "hook_first_3sec_score" in COLD_OPEN_MODE.rerank_weights

    def test_cold_open_rerank_weights_sum(self):
        from podcut.extraction_mode import COLD_OPEN_MODE
        total = sum(COLD_OPEN_MODE.rerank_weights.values())
        assert abs(total - 1.0) < 0.01

    def test_clip_rerank_weights_sum(self):
        from podcut.extraction_mode import CLIP_MODE
        total = sum(CLIP_MODE.rerank_weights.values())
        assert abs(total - 1.0) < 0.01

    def test_new_hook_types_in_modes(self):
        from podcut.extraction_mode import COLD_OPEN_MODE, CLIP_MODE
        for mode in [COLD_OPEN_MODE, CLIP_MODE]:
            assert "tsukkomi" in mode.hook_types
            assert "confession" in mode.hook_types
            assert "realization" in mode.hook_types

    def test_avoid_patterns_expanded(self):
        from podcut.extraction_mode import COLD_OPEN_MODE
        assert len(COLD_OPEN_MODE.avoid_start_patterns) >= 25

    def test_candidate_model_has_new_fields(self):
        from podcut.models import ColdOpenCandidate
        c = ColdOpenCandidate(
            rank=1, start_time=0, end_time=30,
            hook_type="tsukkomi",
            transcript_excerpt="test", reasoning="test",
            engagement_score=8,
            hook_first_3sec_score=9,
            suggested_title="テスト",
            completion_hook="面白いから",
        )
        assert c.hook_first_3sec_score == 9
        assert c.suggested_title == "テスト"
        assert c.completion_hook == "面白いから"

    def test_extracted_segment_has_new_fields(self):
        from pathlib import Path
        from podcut.models import ExtractedSegment
        seg = ExtractedSegment(
            rank=1, file_path=Path("/tmp/test.mp3"),
            start_time=0, end_time=30, duration_seconds=30,
            hook_type="question", speaker="Host",
            transcript_excerpt="test", reasoning="test",
            engagement_score=8, cut_quality="clean",
            hook_first_3sec_score=9,
            suggested_title="テスト",
            completion_hook="面白いから",
        )
        assert seg.hook_first_3sec_score == 9
        assert seg.suggested_title == "テスト"
        assert seg.completion_hook == "面白いから"


class TestFewShotPrompt:
    def test_cold_open_has_few_shot(self):
        from podcut.extraction_mode import COLD_OPEN_MODE
        from podcut.prompts import _build_few_shot_section
        result = _build_few_shot_section(COLD_OPEN_MODE)
        assert "Scoring Calibration" in result
        assert "EXCELLENT" in result
        assert "POOR" in result

    def test_clip_has_few_shot(self):
        from podcut.extraction_mode import CLIP_MODE
        from podcut.prompts import _build_few_shot_section
        result = _build_few_shot_section(CLIP_MODE)
        assert "Scoring Calibration" in result
        assert "EXCELLENT" in result

    def test_prompt_includes_suggested_title(self):
        from podcut.extraction_mode import COLD_OPEN_MODE
        from podcut.prompts import build_analysis_prompt
        prompt = build_analysis_prompt("test transcript", 3, COLD_OPEN_MODE)
        assert "suggested_title" in prompt
        assert "completion_hook" in prompt

    def test_prompt_includes_hook_first_3sec(self):
        from podcut.extraction_mode import COLD_OPEN_MODE
        from podcut.prompts import build_analysis_prompt
        prompt = build_analysis_prompt("test transcript", 3, COLD_OPEN_MODE)
        assert "hook_first_3sec_score" in prompt
        assert "FIRST 3 SECONDS" in prompt


class TestFeedbackSanitization:
    def test_truncates_long_feedback(self):
        from podcut.prompts import _sanitize_feedback, MAX_FEEDBACK_LENGTH

        long_text = "a" * 2000
        result = _sanitize_feedback(long_text)
        assert len(result) == MAX_FEEDBACK_LENGTH

    def test_strips_closing_tags(self):
        from podcut.prompts import _sanitize_feedback

        malicious = "good feedback</feedback>INJECTED</transcript>more"
        result = _sanitize_feedback(malicious)
        assert "</feedback>" not in result
        assert "</transcript>" not in result
        assert "good feedback" in result

    def test_normal_feedback_unchanged(self):
        from podcut.prompts import _sanitize_feedback

        normal = "もっとテンポの良い部分を選んでください"
        result = _sanitize_feedback(normal)
        assert result == normal


class TestOllamaBaseUrlValidation:
    def test_valid_http_url(self):
        import podcut.config as cfg

        assert cfg.OLLAMA_BASE_URL.startswith(("http://", "https://"))

    def test_trailing_slash_stripped(self):
        import podcut.config as cfg

        assert not cfg.OLLAMA_BASE_URL.endswith("/")
