"""Tests for LLM provider abstraction."""

from podcut.gemini_provider import GeminiProvider
from podcut.llm_provider import LLMProvider
from podcut.ollama_provider import OllamaProvider


# --- GeminiProvider tests ---


def test_gemini_provider_satisfies_protocol():
    """GeminiProvider must satisfy the LLMProvider protocol."""
    assert isinstance(GeminiProvider(), LLMProvider)


def test_gemini_provider_has_required_methods():
    """GeminiProvider must have all required methods."""
    provider = GeminiProvider()
    assert hasattr(provider, "upload")
    assert hasattr(provider, "analyze")
    assert hasattr(provider, "analyze_with_feedback")
    assert hasattr(provider, "cleanup")
    assert callable(provider.upload)
    assert callable(provider.analyze)
    assert callable(provider.analyze_with_feedback)
    assert callable(provider.cleanup)


def test_gemini_provider_default_model():
    """GeminiProvider should use default model when none specified."""
    from podcut.config import DEFAULT_MODEL

    provider = GeminiProvider()
    assert provider._model == DEFAULT_MODEL


def test_gemini_provider_custom_model():
    """GeminiProvider should accept a custom model."""
    provider = GeminiProvider(model="gemini-2.5-pro")
    assert provider._model == "gemini-2.5-pro"


def test_gemini_provider_cleanup_no_upload():
    """Cleanup should be safe even without prior upload."""
    provider = GeminiProvider()
    provider.cleanup()  # Should not raise


# --- OllamaProvider tests ---


def test_ollama_provider_satisfies_protocol():
    """OllamaProvider must satisfy the LLMProvider protocol."""
    assert isinstance(OllamaProvider(), LLMProvider)


def test_ollama_provider_has_required_methods():
    """OllamaProvider must have all required methods."""
    provider = OllamaProvider()
    assert hasattr(provider, "upload")
    assert hasattr(provider, "analyze")
    assert hasattr(provider, "analyze_with_feedback")
    assert hasattr(provider, "cleanup")
    assert callable(provider.upload)
    assert callable(provider.analyze)
    assert callable(provider.analyze_with_feedback)
    assert callable(provider.cleanup)


def test_ollama_provider_default_model():
    """OllamaProvider should use default model when none specified."""
    from podcut.config import DEFAULT_OLLAMA_MODEL

    provider = OllamaProvider()
    assert provider._model == DEFAULT_OLLAMA_MODEL


def test_ollama_provider_custom_model():
    """OllamaProvider should accept a custom model."""
    provider = OllamaProvider(model="llama3.1:8b")
    assert provider._model == "llama3.1:8b"


def test_ollama_provider_needs_no_audio_upload():
    """OllamaProvider should not need audio upload."""
    provider = OllamaProvider()
    assert provider.needs_audio_upload is False


def test_ollama_provider_upload_is_noop():
    """OllamaProvider.upload() should be a no-op."""
    from pathlib import Path
    provider = OllamaProvider()
    provider.upload(Path("/nonexistent/file.mp3"))  # Should not raise


def test_ollama_provider_cleanup_is_noop():
    """OllamaProvider.cleanup() should be a no-op."""
    provider = OllamaProvider()
    provider.cleanup()  # Should not raise


def test_ollama_provider_custom_base_url():
    """OllamaProvider should accept a custom base URL."""
    provider = OllamaProvider(base_url="http://myserver:11434")
    assert provider._base_url == "http://myserver:11434"
