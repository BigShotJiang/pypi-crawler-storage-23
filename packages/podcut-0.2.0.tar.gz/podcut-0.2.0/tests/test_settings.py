"""Tests for the settings persistence module."""

import json

import pytest

from podcut.settings import (
    load_settings,
    reset_settings,
    save_settings,
)


@pytest.fixture(autouse=True)
def _isolated_settings(tmp_path, monkeypatch):
    """Redirect settings to a temp directory for every test."""
    settings_dir = tmp_path / ".config" / "podcut"
    settings_file = settings_dir / "settings.json"
    monkeypatch.setattr("podcut.settings.SETTINGS_DIR", settings_dir)
    monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)


class TestLoadSettings:
    def test_returns_empty_when_no_file(self):
        assert load_settings() == {}

    def test_loads_valid_json(self, tmp_path, monkeypatch):
        settings_file = tmp_path / ".config" / "podcut" / "settings.json"
        settings_file.parent.mkdir(parents=True, exist_ok=True)
        settings_file.write_text(json.dumps({"language": "en", "provider": "ollama"}))
        monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)

        result = load_settings()
        assert result == {"language": "en", "provider": "ollama"}

    def test_filters_unknown_keys(self, tmp_path, monkeypatch):
        settings_file = tmp_path / ".config" / "podcut" / "settings.json"
        settings_file.parent.mkdir(parents=True, exist_ok=True)
        settings_file.write_text(json.dumps({
            "language": "ja",
            "SECRET_API_KEY": "should-not-appear",
            "random_junk": 42,
        }))
        monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)

        result = load_settings()
        assert "SECRET_API_KEY" not in result
        assert "random_junk" not in result
        assert result == {"language": "ja"}

    def test_returns_empty_on_corrupt_json(self, tmp_path, monkeypatch):
        settings_file = tmp_path / ".config" / "podcut" / "settings.json"
        settings_file.parent.mkdir(parents=True, exist_ok=True)
        settings_file.write_text("{broken json!!!")
        monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)

        assert load_settings() == {}

    def test_returns_empty_when_json_is_not_dict(self, tmp_path, monkeypatch):
        settings_file = tmp_path / ".config" / "podcut" / "settings.json"
        settings_file.parent.mkdir(parents=True, exist_ok=True)
        settings_file.write_text(json.dumps(["a", "list"]))
        monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)

        assert load_settings() == {}

    def test_loads_provider_model_keys(self, tmp_path, monkeypatch):
        settings_file = tmp_path / ".config" / "podcut" / "settings.json"
        settings_file.parent.mkdir(parents=True, exist_ok=True)
        settings_file.write_text(json.dumps({
            "provider": "gemini",
            "llm_model_gemini": "gemini-2.5-pro",
            "llm_model_ollama": "qwen3:4b",
        }))
        monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)

        result = load_settings()
        assert result["llm_model_gemini"] == "gemini-2.5-pro"
        assert result["llm_model_ollama"] == "qwen3:4b"


class TestSaveSettings:
    def test_creates_directory_and_file(self, tmp_path, monkeypatch):
        settings_dir = tmp_path / "new_dir" / "podcut"
        settings_file = settings_dir / "settings.json"
        monkeypatch.setattr("podcut.settings.SETTINGS_DIR", settings_dir)
        monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)

        save_settings({"language": "en", "provider": "gemini"})

        assert settings_file.exists()
        data = json.loads(settings_file.read_text())
        assert data["language"] == "en"
        assert data["provider"] == "gemini"

    def test_filters_out_unknown_keys(self, tmp_path, monkeypatch):
        settings_dir = tmp_path / ".config" / "podcut"
        settings_file = settings_dir / "settings.json"
        monkeypatch.setattr("podcut.settings.SETTINGS_DIR", settings_dir)
        monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)

        save_settings({
            "language": "ja",
            "GEMINI_API_KEY": "secret",
            "password": "nope",
        })

        data = json.loads(settings_file.read_text())
        assert "GEMINI_API_KEY" not in data
        assert "password" not in data
        assert data["language"] == "ja"

    def test_saves_provider_model_keys(self, tmp_path, monkeypatch):
        settings_dir = tmp_path / ".config" / "podcut"
        settings_file = settings_dir / "settings.json"
        monkeypatch.setattr("podcut.settings.SETTINGS_DIR", settings_dir)
        monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)

        save_settings({
            "provider": "openai",
            "llm_model_openai": "gpt-4.1",
            "llm_model_gemini": "gemini-2.5-flash",
        })

        data = json.loads(settings_file.read_text())
        assert data["llm_model_openai"] == "gpt-4.1"
        assert data["llm_model_gemini"] == "gemini-2.5-flash"


class TestResetSettings:
    def test_removes_existing_file(self, tmp_path, monkeypatch):
        settings_file = tmp_path / ".config" / "podcut" / "settings.json"
        settings_file.parent.mkdir(parents=True, exist_ok=True)
        settings_file.write_text("{}")
        monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)

        assert reset_settings() is True
        assert not settings_file.exists()

    def test_returns_false_when_no_file(self):
        assert reset_settings() is False
