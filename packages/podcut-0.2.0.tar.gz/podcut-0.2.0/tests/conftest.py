"""Shared test fixtures."""

import struct
import wave
from pathlib import Path

import pytest


@pytest.fixture
def tmp_output_dir(tmp_path: Path) -> Path:
    """Temporary output directory."""
    d = tmp_path / "output"
    d.mkdir()
    return d


@pytest.fixture
def sample_wav(tmp_path: Path) -> Path:
    """Create a short silent WAV file for testing."""
    wav_path = tmp_path / "test_audio.wav"
    sample_rate = 16000
    duration_sec = 5
    num_samples = sample_rate * duration_sec

    with wave.open(str(wav_path), "w") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        # Write silence (zeros)
        wf.writeframes(b"\x00\x00" * num_samples)

    return wav_path


@pytest.fixture
def sample_wav_with_tone(tmp_path: Path) -> Path:
    """Create a WAV file with a tone and silence regions for testing."""
    import math

    wav_path = tmp_path / "test_tone.wav"
    sample_rate = 16000
    # 10 seconds total: 1s silence, 3s tone, 1s silence, 3s tone, 2s silence
    duration_sec = 10
    num_samples = sample_rate * duration_sec

    samples = []
    for i in range(num_samples):
        t = i / sample_rate
        if 1.0 <= t < 4.0 or 5.0 <= t < 8.0:
            # 440Hz tone at ~50% amplitude
            value = int(16000 * math.sin(2 * math.pi * 440 * t))
        else:
            value = 0
        samples.append(struct.pack("<h", max(-32768, min(32767, value))))

    with wave.open(str(wav_path), "w") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(b"".join(samples))

    return wav_path
