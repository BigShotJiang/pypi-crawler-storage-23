"""Tests for Gemini client (mocked API)."""

import json
from unittest.mock import MagicMock, patch

import pytest

from podcut.models import ColdOpenCandidate


@patch("podcut.gemini_client._init_client")
def test_analyze_content_basic(mock_init):
    """Test content analysis with mocked Gemini response."""
    from podcut.gemini_client import analyze_content

    mock_client = MagicMock()
    mock_init.return_value = mock_client

    response_data = {
        "candidates": [
            {
                "rank": 1,
                "start_time": 120.5,
                "end_time": 150.0,
                "speaker": "Guest",
                "hook_type": "story",
                "transcript_excerpt": "Once upon a time...",
                "reasoning": "Compelling narrative",
                "engagement_score": 9,
            },
            {
                "rank": 2,
                "start_time": 300.0,
                "end_time": 330.0,
                "speaker": "Host",
                "hook_type": "question",
                "transcript_excerpt": "Have you ever wondered...?",
                "reasoning": "Provocative question",
                "engagement_score": 7,
            },
        ]
    }

    mock_response = MagicMock()
    mock_response.text = json.dumps(response_data)
    mock_client.models.generate_content.return_value = mock_response

    fake_file = MagicMock()
    transcript = "[00:00.00 - 00:05.00] Test transcript"

    candidates = analyze_content(
        uploaded_file=fake_file,
        transcript_text=transcript,
        num_candidates=2,
        model="gemini-2.5-flash",
    )

    assert len(candidates) == 2
    assert isinstance(candidates[0], ColdOpenCandidate)
    assert candidates[0].rank == 1
    assert candidates[0].hook_type == "story"
    assert candidates[1].engagement_score == 7


@patch("podcut.gemini_client._init_client")
def test_analyze_content_strips_markdown_fences(mock_init):
    """Test that markdown code fences are stripped from response."""
    from podcut.gemini_client import analyze_content

    mock_client = MagicMock()
    mock_init.return_value = mock_client

    response_data = {
        "candidates": [
            {
                "rank": 1,
                "start_time": 10.0,
                "end_time": 40.0,
                "speaker": "Host",
                "hook_type": "humor",
                "transcript_excerpt": "Funny moment",
                "reasoning": "Great humor",
                "engagement_score": 8,
            }
        ]
    }

    # Wrap in markdown code fences
    mock_response = MagicMock()
    mock_response.text = f"```json\n{json.dumps(response_data)}\n```"
    mock_client.models.generate_content.return_value = mock_response

    candidates = analyze_content(
        uploaded_file=MagicMock(),
        transcript_text="test",
        num_candidates=1,
    )

    assert len(candidates) == 1
    assert candidates[0].hook_type == "humor"


@patch("podcut.gemini_client._init_client")
def test_analyze_content_invalid_json(mock_init):
    """Test error handling for invalid JSON response."""
    from podcut.gemini_client import analyze_content

    mock_client = MagicMock()
    mock_init.return_value = mock_client

    mock_response = MagicMock()
    mock_response.text = "This is not valid JSON"
    mock_client.models.generate_content.return_value = mock_response

    with pytest.raises(RuntimeError, match="Failed to parse Gemini response"):
        analyze_content(
            uploaded_file=MagicMock(),
            transcript_text="test",
            num_candidates=1,
        )


@patch("podcut.gemini_client._init_client")
def test_analyze_content_with_feedback(mock_init):
    """Test re-analysis with user feedback."""
    from podcut.gemini_client import analyze_content_with_feedback

    mock_client = MagicMock()
    mock_init.return_value = mock_client

    response_data = {
        "candidates": [
            {
                "rank": 1,
                "start_time": 200.0,
                "end_time": 230.0,
                "speaker": "Guest",
                "hook_type": "humor",
                "transcript_excerpt": "A funny moment...",
                "reasoning": "Addresses user request for humor",
                "engagement_score": 9,
                "is_multi_segment": False,
                "segments": [],
            }
        ]
    }

    mock_response = MagicMock()
    mock_response.text = json.dumps(response_data)
    mock_client.models.generate_content.return_value = mock_response

    previous = [
        ColdOpenCandidate(
            rank=1,
            start_time=10.0,
            end_time=40.0,
            hook_type="question",
            transcript_excerpt="old",
            reasoning="old reason",
            engagement_score=7,
        )
    ]

    candidates = analyze_content_with_feedback(
        uploaded_file=MagicMock(),
        transcript_text="test transcript",
        num_candidates=1,
        previous_candidates=previous,
        feedback="もっとユーモアがほしい",
        model="gemini-2.5-flash",
    )

    assert len(candidates) == 1
    assert candidates[0].hook_type == "humor"
    assert candidates[0].engagement_score == 9

    # Verify the prompt was sent with the uploaded file
    call_args = mock_client.models.generate_content.call_args
    assert call_args.kwargs["contents"][0] is not None  # uploaded file
    assert "もっとユーモアがほしい" in call_args.kwargs["contents"][1]


@patch("podcut.gemini_client._init_client")
def test_analyze_content_multi_segment(mock_init):
    """Test analysis returning multi-segment candidates."""
    from podcut.gemini_client import analyze_content

    mock_client = MagicMock()
    mock_init.return_value = mock_client

    response_data = {
        "candidates": [
            {
                "rank": 1,
                "start_time": 10.0,
                "end_time": 600.0,
                "speaker": "Host and Guest",
                "hook_type": "debate",
                "transcript_excerpt": "Combined text",
                "reasoning": "Great debate",
                "engagement_score": 8,
                "is_multi_segment": True,
                "segments": [
                    {"start_time": 10.0, "end_time": 25.0, "transcript_excerpt": "Part 1"},
                    {"start_time": 580.0, "end_time": 600.0, "transcript_excerpt": "Part 2"},
                ],
            }
        ]
    }

    mock_response = MagicMock()
    mock_response.text = json.dumps(response_data)
    mock_client.models.generate_content.return_value = mock_response

    candidates = analyze_content(
        uploaded_file=MagicMock(),
        transcript_text="test",
        num_candidates=1,
    )

    assert len(candidates) == 1
    assert candidates[0].is_multi_segment is True
    assert len(candidates[0].segments) == 2
    assert candidates[0].segments[0].start_time == 10.0


@patch("podcut.gemini_client._init_client")
def test_cleanup_all_files(mock_init):
    """Test cleanup of uploaded files."""
    from podcut.gemini_client import cleanup_all_files

    mock_client = MagicMock()
    mock_init.return_value = mock_client

    fake_file1 = MagicMock()
    fake_file1.name = "file1"
    fake_file2 = MagicMock()
    fake_file2.name = "file2"
    mock_client.files.list.return_value = [fake_file1, fake_file2]

    deleted = cleanup_all_files()
    assert deleted == 2
    assert mock_client.files.delete.call_count == 2
