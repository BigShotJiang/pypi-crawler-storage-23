"""Tests for extraction mode definitions."""

import pytest

from podcut.extraction_mode import (
    AVAILABLE_MODES,
    CLIP_MODE,
    COLD_OPEN_MODE,
    get_mode,
)


class TestColdOpenMode:
    def test_name(self):
        assert COLD_OPEN_MODE.name == "cold_open"

    def test_duration_range(self):
        assert COLD_OPEN_MODE.min_duration_sec == 10
        assert COLD_OPEN_MODE.max_duration_sec == 90

    def test_label(self):
        assert COLD_OPEN_MODE.label == "Cold Open"
        assert COLD_OPEN_MODE.label_plural == "Cold Open Candidates"

    def test_hook_types(self):
        assert "question" in COLD_OPEN_MODE.hook_types
        assert "story" in COLD_OPEN_MODE.hook_types
        assert len(COLD_OPEN_MODE.hook_types) >= 6

    def test_allow_multi_segment(self):
        assert COLD_OPEN_MODE.allow_multi_segment is True

    def test_output_file_prefix(self):
        assert COLD_OPEN_MODE.output_file_prefix == "cold_open"


class TestClipMode:
    def test_name(self):
        assert CLIP_MODE.name == "clip"

    def test_duration_range(self):
        assert CLIP_MODE.min_duration_sec == 60
        assert CLIP_MODE.max_duration_sec == 600

    def test_label(self):
        assert CLIP_MODE.label == "Clip"
        assert CLIP_MODE.label_plural == "Clip Candidates"

    def test_hook_types(self):
        assert "deep_dive" in CLIP_MODE.hook_types
        assert "practical_advice" in CLIP_MODE.hook_types
        assert len(CLIP_MODE.hook_types) >= 7

    def test_allow_multi_segment(self):
        assert CLIP_MODE.allow_multi_segment is False

    def test_output_file_prefix(self):
        assert CLIP_MODE.output_file_prefix == "clip"


class TestGetMode:
    def test_cold_open(self):
        mode = get_mode("cold_open")
        assert mode is COLD_OPEN_MODE

    def test_clip(self):
        mode = get_mode("clip")
        assert mode is CLIP_MODE

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown extraction mode"):
            get_mode("nonexistent")

    def test_available_modes(self):
        assert "cold_open" in AVAILABLE_MODES
        assert "clip" in AVAILABLE_MODES
        assert len(AVAILABLE_MODES) == 2


class TestQualityCriteria:
    def test_cold_open_quality_criteria_non_empty(self):
        assert isinstance(COLD_OPEN_MODE.quality_criteria, tuple)
        assert len(COLD_OPEN_MODE.quality_criteria) > 0

    def test_clip_quality_criteria_non_empty(self):
        assert isinstance(CLIP_MODE.quality_criteria, tuple)
        assert len(CLIP_MODE.quality_criteria) > 0

    def test_cold_open_transcript_strategy(self):
        assert COLD_OPEN_MODE.transcript_strategy == "head_tail"

    def test_clip_transcript_strategy(self):
        assert CLIP_MODE.transcript_strategy == "full"


class TestRerankWeights:
    def test_cold_open_has_opening_impact_weight(self):
        assert "opening_impact_score" in COLD_OPEN_MODE.rerank_weights
        assert COLD_OPEN_MODE.rerank_weights["opening_impact_score"] == 0.25

    def test_clip_has_shareability_weight(self):
        assert "shareability_score" in CLIP_MODE.rerank_weights
        assert CLIP_MODE.rerank_weights["shareability_score"] == 0.15

    def test_cold_open_weights_sum_to_one(self):
        total = sum(COLD_OPEN_MODE.rerank_weights.values())
        assert abs(total - 1.0) < 0.01

    def test_clip_weights_sum_to_one(self):
        total = sum(CLIP_MODE.rerank_weights.values())
        assert abs(total - 1.0) < 0.01

    def test_cold_open_extra_score_fields(self):
        assert "opening_impact_score" in COLD_OPEN_MODE.extra_score_fields

    def test_clip_extra_score_fields(self):
        assert "shareability_score" in CLIP_MODE.extra_score_fields

    def test_cold_open_avoid_patterns(self):
        assert len(COLD_OPEN_MODE.avoid_start_patterns) > 0
        assert "えーと" in COLD_OPEN_MODE.avoid_start_patterns
        assert "こんにちは" in COLD_OPEN_MODE.avoid_start_patterns


class TestExtractionModeImmutable:
    def test_frozen(self):
        with pytest.raises(AttributeError):
            COLD_OPEN_MODE.name = "modified"
