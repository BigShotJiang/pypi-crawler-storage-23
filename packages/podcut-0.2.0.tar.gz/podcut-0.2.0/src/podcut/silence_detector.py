"""Silence detection and cut point optimization using librosa."""

from pathlib import Path

import librosa
import numpy as np
import soundfile as sf

from podcut.config import SILENCE_SEARCH_WINDOW_MS
from podcut.models import ColdOpenCandidate, RefinedTimestamp, Transcript


def _is_numba_locator_error(exc: RuntimeError) -> bool:
    """Return True for known librosa/numba cache-locator runtime errors."""
    msg = str(exc).lower()
    return "cannot cache function" in msg and "no locator available" in msg


def _load_audio_waveform(audio_path: Path) -> tuple[np.ndarray, int]:
    """Load waveform and sample rate.

    Primary path uses librosa; falls back to soundfile when librosa fails due to
    numba cache locator issues seen on some Python distributions.
    """
    try:
        y, sr = librosa.load(str(audio_path), sr=None)
        return y, sr
    except RuntimeError as e:
        if not _is_numba_locator_error(e):
            raise

    y, sr = sf.read(str(audio_path), always_2d=False)
    if isinstance(y, np.ndarray) and y.ndim > 1:
        y = np.mean(y, axis=1)
    y = np.asarray(y, dtype=np.float32)
    return y, int(sr)


def _split_non_silent_intervals(
    y: np.ndarray,
    top_db: int,
) -> np.ndarray:
    """Return non-silent intervals as sample index pairs.

    Uses librosa when available; otherwise computes sample-level contiguous
    non-silent runs based on peak-relative amplitude.
    """
    try:
        return librosa.effects.split(y, top_db=top_db)
    except RuntimeError as e:
        if not _is_numba_locator_error(e):
            raise

    if y.size == 0:
        return np.empty((0, 2), dtype=int)

    peak = float(np.max(np.abs(y)))
    if peak <= 0.0:
        return np.empty((0, 2), dtype=int)

    threshold = peak * (10 ** (-top_db / 20.0))

    # Frame-based detection to avoid O(non_silent_samples) memory.
    # Each frame covers `frame_len` samples; we check if its peak exceeds
    # the threshold, producing a compact boolean array (~1 byte per frame).
    frame_len = 2048
    n_frames = (y.size + frame_len - 1) // frame_len
    is_active = np.empty(n_frames, dtype=np.bool_)
    for i in range(n_frames):
        chunk = y[i * frame_len : (i + 1) * frame_len]
        is_active[i] = float(np.max(np.abs(chunk))) > threshold

    active_idx = np.flatnonzero(is_active)
    if active_idx.size == 0:
        return np.empty((0, 2), dtype=int)

    split_points = np.where(np.diff(active_idx) > 1)[0]
    starts_fr = np.concatenate(([active_idx[0]], active_idx[split_points + 1]))
    ends_fr = np.concatenate((active_idx[split_points], [active_idx[-1]]))

    # Convert frame indices back to sample indices
    starts = starts_fr * frame_len
    ends = np.minimum((ends_fr + 1) * frame_len, y.size)
    return np.stack((starts, ends), axis=1)


def detect_silence_regions(
    audio_path: Path,
    top_db: int = 30,
) -> list[tuple[float, float]]:
    """Detect silence regions in audio file.

    Args:
        audio_path: Path to audio file.
        top_db: Threshold in dB below peak to consider as silence.

    Returns:
        List of (start_sec, end_sec) tuples for silence regions.
    """
    y, sr = _load_audio_waveform(audio_path)
    duration = float(len(y)) / float(sr) if sr else 0.0

    # Get non-silent intervals
    non_silent = _split_non_silent_intervals(y, top_db=top_db)

    silence_regions: list[tuple[float, float]] = []

    # Fully silent waveform fallback: treat entire file as silence.
    if len(non_silent) == 0 and duration > 0.05:
        return [(0.0, duration)]

    # Before first non-silent region
    if len(non_silent) > 0:
        first_start = non_silent[0][0] / sr
        if first_start > 0.05:
            silence_regions.append((0.0, first_start))

    # Between non-silent regions
    for i in range(len(non_silent) - 1):
        gap_start = non_silent[i][1] / sr
        gap_end = non_silent[i + 1][0] / sr
        if gap_end - gap_start > 0.05:
            silence_regions.append((gap_start, gap_end))

    # After last non-silent region
    if len(non_silent) > 0:
        last_end = non_silent[-1][1] / sr
        if duration - last_end > 0.05:
            silence_regions.append((last_end, duration))

    return silence_regions


def find_nearest_silence(
    target_sec: float,
    silence_regions: list[tuple[float, float]],
    search_window_ms: int = SILENCE_SEARCH_WINDOW_MS,
) -> float | None:
    """Find the nearest silence region to a target timestamp.

    Args:
        target_sec: Target time in seconds.
        silence_regions: List of (start, end) silence regions.
        search_window_ms: Search window in milliseconds around target.

    Returns:
        Midpoint of nearest silence region, or None if no silence found in window.
    """
    window_sec = search_window_ms / 1000.0
    best_point: float | None = None
    best_distance = float("inf")

    for sil_start, sil_end in silence_regions:
        sil_mid = (sil_start + sil_end) / 2.0

        if abs(sil_mid - target_sec) <= window_sec:
            distance = abs(sil_mid - target_sec)
            if distance < best_distance:
                best_distance = distance
                best_point = sil_mid

    return best_point


def find_nearest_word_boundary(
    target_sec: float,
    transcript: Transcript,
    search_window_ms: int = SILENCE_SEARCH_WINDOW_MS,
) -> float | None:
    """Find nearest word boundary (gap between words) to target timestamp.

    Falls back to this when no silence region is found.
    """
    window_sec = search_window_ms / 1000.0
    best_point: float | None = None
    best_distance = float("inf")

    for i in range(len(transcript.words) - 1):
        gap_start = transcript.words[i].end
        gap_end = transcript.words[i + 1].start
        gap_mid = (gap_start + gap_end) / 2.0

        if abs(gap_mid - target_sec) <= window_sec:
            distance = abs(gap_mid - target_sec)
            if distance < best_distance:
                best_distance = distance
                best_point = gap_mid

    return best_point


def refine_cut_points(
    candidates: list[ColdOpenCandidate],
    audio_path: Path,
    transcript: Transcript,
    audio_duration: float | None = None,
) -> list[RefinedTimestamp]:
    """Refine candidate cut points using silence detection.

    For each candidate:
    1. Try to find silence near start/end timestamps
    2. Fall back to word boundaries if no silence found
    3. Clamp to audio duration

    Args:
        candidates: Cold open candidates from Gemini.
        audio_path: Path to audio file.
        transcript: Whisper transcript with word timestamps.
        audio_duration: Total audio duration in seconds (auto-detected if None).

    Returns:
        List of refined timestamps.
    """
    if audio_duration is None:
        y, sr = _load_audio_waveform(audio_path)
        audio_duration = float(len(y)) / float(sr) if sr else 0.0

    silence_regions = detect_silence_regions(audio_path)

    refined: list[RefinedTimestamp] = []

    for candidate in candidates:
        start = candidate.start_time
        end = candidate.end_time
        start_quality = "clean"
        end_quality = "clean"

        # Refine start point
        sil_start = find_nearest_silence(start, silence_regions)
        if sil_start is not None:
            start = sil_start
        else:
            wb_start = find_nearest_word_boundary(start, transcript)
            if wb_start is not None:
                start = wb_start
                start_quality = "word_boundary"

        # Refine end point
        sil_end = find_nearest_silence(end, silence_regions)
        if sil_end is not None:
            end = sil_end
        else:
            wb_end = find_nearest_word_boundary(end, transcript)
            if wb_end is not None:
                end = wb_end
                end_quality = "word_boundary"

        # Clamp to audio bounds
        start = max(0.0, min(start, audio_duration))
        end = max(0.0, min(end, audio_duration))

        if end <= start:
            end = min(start + 30.0, audio_duration)

        quality = "clean" if start_quality == "clean" and end_quality == "clean" else "word_boundary"

        refined.append(
            RefinedTimestamp(
                original_rank=candidate.rank,
                refined_start_sec=round(start, 3),
                refined_end_sec=round(end, 3),
                duration_seconds=round(end - start, 3),
                cut_quality=quality,
            )
        )

    return refined
