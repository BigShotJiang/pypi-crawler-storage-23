"""Gemini API client for content analysis and cold open candidate selection."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from rich.console import Console

from podcut.config import DEFAULT_MODEL, UPLOAD_TIMEOUT_SEC, get_gemini_api_key
from podcut.extraction_mode import COLD_OPEN_MODE, ExtractionMode
from podcut.models import ColdOpenCandidate, GeminiAnalysisResult
from podcut.prompts import build_analysis_prompt, build_feedback_prompt

console = Console(stderr=True)

# Retry configuration
MAX_RETRIES = 3
INITIAL_BACKOFF_SEC = 2.0

# Cached client instance
_client_instance: Any = None


def _init_client() -> Any:
    """Initialize Gemini client lazily with caching."""
    global _client_instance
    if _client_instance is None:
        from google import genai

        api_key = get_gemini_api_key()
        _client_instance = genai.Client(api_key=api_key)
    return _client_instance


def _call_gemini_with_retry(
    client: Any,
    model: str,
    contents: list,
    verbose: bool = False,
) -> str:
    """Call Gemini API with retry logic and response parsing.

    Returns:
        Parsed raw text from Gemini response.

    Raises:
        RuntimeError: If API fails after retries or returns empty/invalid response.
    """
    last_error: Exception | None = None
    response = None
    for attempt in range(MAX_RETRIES):
        try:
            response = client.models.generate_content(
                model=model,
                contents=contents,
            )
            break
        except Exception as e:
            last_error = e
            if attempt < MAX_RETRIES - 1:
                wait = INITIAL_BACKOFF_SEC * (2 ** attempt)
                if verbose:
                    console.print(f"[dim]Retry {attempt + 1}/{MAX_RETRIES} after {wait}s: {e}[/dim]")
                time.sleep(wait)
            else:
                raise RuntimeError(
                    f"Gemini API failed after {MAX_RETRIES} retries: {last_error}"
                )

    # Guard against None/empty response
    if response is None or not hasattr(response, "text") or response.text is None:
        raise RuntimeError(
            "Gemini returned an empty or invalid response. "
            "This may indicate a content filtering issue or API error."
        )

    raw_text = response.text.strip()

    # Strip markdown code fences if present
    if raw_text.startswith("```"):
        lines = raw_text.split("\n")
        lines = lines[1:]  # remove opening fence
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        raw_text = "\n".join(lines)

    return raw_text


def _parse_candidates(raw_text: str) -> list[ColdOpenCandidate]:
    """Parse Gemini response text into candidate list.

    Raises:
        RuntimeError: If JSON parsing fails.
    """
    try:
        data = json.loads(raw_text)
    except json.JSONDecodeError as e:
        raise RuntimeError(
            f"Failed to parse Gemini response as JSON: {e}\n"
            f"Raw response:\n{raw_text[:500]}"
        )

    try:
        result = GeminiAnalysisResult.model_validate(data)
    except Exception as e:
        raise RuntimeError(
            f"LLM response JSON does not match expected schema: {e}\n"
            f"Raw response:\n{raw_text[:500]}"
        )
    return result.candidates


def upload_audio(
    audio_path: Path,
    verbose: bool = False,
    timeout_sec: int = UPLOAD_TIMEOUT_SEC,
) -> Any:
    """Upload audio file via Gemini Files API.

    Args:
        audio_path: Path to audio file.
        verbose: Whether to print progress.
        timeout_sec: Maximum seconds to wait for file processing.

    Returns:
        Uploaded file object for use in generate_content.

    Raises:
        TimeoutError: If file processing exceeds timeout.
        RuntimeError: If file processing fails.
    """
    client = _init_client()

    if verbose:
        console.print(f"[dim]Uploading {audio_path.name} to Gemini Files API...[/dim]")

    try:
        uploaded_file = client.files.upload(file=audio_path)
    except Exception as e:
        raise RuntimeError(
            f"Failed to upload audio to Gemini: {e}\n"
            f"Check your network connection and file size (max 2GB)."
        )

    # Wait for file to be processed with timeout
    start_time = time.monotonic()
    while uploaded_file.state.name == "PROCESSING":
        elapsed = time.monotonic() - start_time
        if elapsed > timeout_sec:
            # Attempt cleanup before raising
            try:
                client.files.delete(name=uploaded_file.name)
            except Exception as cleanup_err:
                console.print(f"[yellow]Warning: Failed to clean up uploaded file after timeout: {cleanup_err}[/yellow]")
            raise TimeoutError(
                f"Gemini file processing timed out after {timeout_sec}s. "
                f"The file may be too large or the service is slow. "
                f"Try again or use a shorter audio file."
            )
        time.sleep(2)
        uploaded_file = client.files.get(name=uploaded_file.name)

    if uploaded_file.state.name == "FAILED":
        raise RuntimeError(f"Gemini file upload failed: {uploaded_file.state}")

    if verbose:
        console.print("[dim]File uploaded and ready.[/dim]")

    return uploaded_file


def delete_uploaded_file(uploaded_file: Any, verbose: bool = False) -> None:
    """Delete an uploaded file from Gemini Files API."""
    try:
        client = _init_client()
        client.files.delete(name=uploaded_file.name)
        if verbose:
            console.print("[dim]Cleaned up uploaded file.[/dim]")
    except Exception as e:
        console.print(f"[yellow]Warning: Failed to delete uploaded file: {e}[/yellow]")


def analyze_content(
    uploaded_file: Any,
    transcript_text: str,
    num_candidates: int,
    model: str = DEFAULT_MODEL,
    mode: ExtractionMode = COLD_OPEN_MODE,
    verbose: bool = False,
) -> list[ColdOpenCandidate]:
    """Analyze podcast content using Gemini to identify candidates."""
    client = _init_client()
    prompt = build_analysis_prompt(transcript_text, num_candidates, mode=mode)

    if verbose:
        console.print(f"[dim]Analyzing content with {model}...[/dim]")

    raw_text = _call_gemini_with_retry(client, model, [uploaded_file, prompt], verbose=verbose)
    candidates = _parse_candidates(raw_text)

    if verbose:
        console.print(f"[dim]Found {len(candidates)} candidates.[/dim]")

    return candidates


def analyze_content_with_feedback(
    uploaded_file: Any,
    transcript_text: str,
    num_candidates: int,
    previous_candidates: list[ColdOpenCandidate],
    feedback: str,
    model: str = DEFAULT_MODEL,
    mode: ExtractionMode = COLD_OPEN_MODE,
    verbose: bool = False,
) -> list[ColdOpenCandidate]:
    """Re-analyze podcast content using Gemini with user feedback."""
    client = _init_client()

    previous_dicts = [c.model_dump() for c in previous_candidates]
    prompt = build_feedback_prompt(
        transcript_text=transcript_text,
        num_candidates=num_candidates,
        previous_candidates=previous_dicts,
        feedback=feedback,
        mode=mode,
    )

    if verbose:
        console.print(f"[dim]Re-analyzing with feedback using {model}...[/dim]")

    raw_text = _call_gemini_with_retry(client, model, [uploaded_file, prompt], verbose=verbose)
    candidates = _parse_candidates(raw_text)

    if verbose:
        console.print(f"[dim]Found {len(candidates)} new candidates.[/dim]")

    return candidates


def cleanup_all_files(verbose: bool = False) -> int:
    """Delete all files from Gemini Files API.

    Returns:
        Number of files deleted.
    """
    client = _init_client()
    deleted = 0
    failed = 0
    try:
        for f in client.files.list():
            try:
                client.files.delete(name=f.name)
                deleted += 1
                if verbose:
                    console.print(f"[dim]Deleted: {f.name}[/dim]")
            except Exception as e:
                failed += 1
                console.print(f"[yellow]Warning: Failed to delete {f.name}: {e}[/yellow]")
    except Exception as e:
        console.print(f"[yellow]Warning: Error listing files: {e}[/yellow]")

    if failed > 0:
        console.print(f"[yellow]Warning: {failed} file(s) could not be deleted.[/yellow]")

    return deleted
