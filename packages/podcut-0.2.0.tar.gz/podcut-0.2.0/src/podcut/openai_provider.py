"""OpenAI-compatible LLM provider (supports OpenAI and Grok/xAI)."""

from __future__ import annotations

import json
from pathlib import Path

from rich.console import Console

from podcut.extraction_mode import COLD_OPEN_MODE, ExtractionMode
from podcut.models import ColdOpenCandidate, GeminiAnalysisResult
from podcut.prompts import build_analysis_prompt, build_feedback_prompt

console = Console(stderr=True)

MAX_RETRIES = 2
REQUEST_TIMEOUT_SEC = 120

# Map api_key_env to config getter function names
_KEY_GETTER_MAP = {
    "OPENAI_API_KEY": "get_openai_api_key",
    "XAI_API_KEY": "get_xai_api_key",
}


def _parse_candidates(raw_text: str) -> list[ColdOpenCandidate]:
    """Parse API response text into candidate list."""
    text = raw_text.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines)

    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise RuntimeError(
            f"Failed to parse OpenAI response as JSON: {e}\n"
            f"Raw response:\n{text[:500]}"
        )

    try:
        result = GeminiAnalysisResult.model_validate(data)
    except Exception as e:
        raise RuntimeError(
            f"LLM response JSON does not match expected schema: {e}\n"
            f"Raw response:\n{text[:500]}"
        )
    return result.candidates


def _check_openai_sdk() -> None:
    """Check that the openai SDK is importable."""
    try:
        import openai  # noqa: F401
    except ImportError:
        raise RuntimeError(
            "openai package is not installed. "
            "Install it with: pip install 'podcut[openai]'"
        )


class OpenAIProvider:
    """LLM provider backed by OpenAI-compatible APIs.

    Used for both OpenAI (GPT) and Grok (xAI) by varying base_url and api_key_env.
    """

    def __init__(
        self,
        model: str,
        base_url: str | None = None,
        api_key_env: str = "OPENAI_API_KEY",
    ) -> None:
        self._model = model
        self._base_url = base_url
        self._api_key_env = api_key_env

    def _get_api_key(self) -> str:
        """Get API key using the centralized config getter."""
        from podcut import config
        getter_name = _KEY_GETTER_MAP.get(self._api_key_env)
        if getter_name:
            return getattr(config, getter_name)()
        # Fallback for unknown env vars (shouldn't happen in practice)
        import os
        from podcut.i18n import t
        key = os.environ.get(self._api_key_env, "")
        if not key:
            raise SystemExit(t(f"{self._api_key_env.lower()}_missing"))
        return key

    def _get_client(self):
        """Create an OpenAI client with lazy import."""
        _check_openai_sdk()
        from openai import OpenAI

        api_key = self._get_api_key()
        kwargs: dict = {"api_key": api_key, "timeout": REQUEST_TIMEOUT_SEC}
        if self._base_url:
            kwargs["base_url"] = self._base_url
        return OpenAI(**kwargs)

    def preflight(self) -> None:
        """Verify SDK installation and API key before heavy processing."""
        _check_openai_sdk()
        self._get_api_key()

    @property
    def needs_audio_upload(self) -> bool:
        return False

    def upload(self, audio_path: Path, verbose: bool = False) -> None:
        if verbose:
            console.print("[dim]Skipping audio upload (using transcript only).[/dim]")

    def analyze(
        self,
        transcript_text: str,
        num_candidates: int,
        mode: ExtractionMode = COLD_OPEN_MODE,
        verbose: bool = False,
    ) -> list[ColdOpenCandidate]:
        prompt = build_analysis_prompt(transcript_text, num_candidates, mode=mode, has_audio=False)

        if verbose:
            console.print(f"[dim]Analyzing content with OpenAI-compatible API ({self._model})...[/dim]")

        raw_text = self._call_api(prompt, verbose=verbose)
        candidates = _parse_candidates(raw_text)

        if verbose:
            console.print(f"[dim]Found {len(candidates)} candidates.[/dim]")

        return candidates

    def analyze_with_feedback(
        self,
        transcript_text: str,
        num_candidates: int,
        previous: list[ColdOpenCandidate],
        feedback: str,
        mode: ExtractionMode = COLD_OPEN_MODE,
        verbose: bool = False,
    ) -> list[ColdOpenCandidate]:
        previous_dicts = [c.model_dump() for c in previous]
        prompt = build_feedback_prompt(
            transcript_text=transcript_text,
            num_candidates=num_candidates,
            previous_candidates=previous_dicts,
            feedback=feedback,
            mode=mode,
            has_audio=False,
        )

        if verbose:
            console.print(f"[dim]Re-analyzing with feedback using OpenAI-compatible API ({self._model})...[/dim]")

        raw_text = self._call_api(prompt, verbose=verbose)
        candidates = _parse_candidates(raw_text)

        if verbose:
            console.print(f"[dim]Found {len(candidates)} new candidates.[/dim]")

        return candidates

    def cleanup(self, verbose: bool = False) -> None:
        pass

    def _call_api(self, prompt: str, verbose: bool = False) -> str:
        """Call the OpenAI-compatible API with retries.

        On the first attempt, ``response_format`` and ``temperature`` are
        included.  If the API rejects them (400-level error), the request is
        retried without those parameters so that models with limited
        parameter support still work.
        """
        client = self._get_client()

        messages = [
            {
                "role": "system",
                "content": (
                    "You are a podcast editor AI. "
                    "Always respond with valid JSON only. No markdown, no code fences."
                ),
            },
            {"role": "user", "content": prompt},
        ]

        last_error: Exception | None = None
        use_json_mode = True  # Try json_object mode first

        for attempt in range(MAX_RETRIES + 1):
            try:
                kwargs: dict = {"model": self._model, "messages": messages}
                if use_json_mode:
                    kwargs["response_format"] = {"type": "json_object"}
                    kwargs["temperature"] = 0.3

                response = client.chat.completions.create(**kwargs)
                raw_text = response.choices[0].message.content or ""
                if not raw_text.strip():
                    raise RuntimeError("API returned an empty response.")
                return raw_text.strip()
            except SystemExit:
                raise
            except Exception as e:
                last_error = e
                # If the API rejected json_object / temperature, retry without them
                err_str = str(e).lower()
                if use_json_mode and ("response_format" in err_str or "temperature" in err_str or "400" in err_str):
                    use_json_mode = False
                    if verbose:
                        console.print("[dim]json_object mode not supported, retrying without it...[/dim]")
                    continue
                if attempt < MAX_RETRIES:
                    if verbose:
                        console.print(f"[dim]Retry {attempt + 1}/{MAX_RETRIES}: {e}[/dim]")
                    continue
                raise RuntimeError(
                    f"OpenAI-compatible API failed after {MAX_RETRIES + 1} attempts: {last_error}"
                )
        # Unreachable but satisfies type checker
        raise RuntimeError(f"OpenAI-compatible API failed: {last_error}")
