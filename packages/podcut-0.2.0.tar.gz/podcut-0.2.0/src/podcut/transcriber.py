"""Whisper transcription with MLX (Apple Silicon) and faster-whisper (CPU) backends."""

import logging
from pathlib import Path

from rich.console import Console

from podcut.models import Segment, Transcript, Word

# Suppress the "unauthenticated requests to the HF Hub" warning.
# The HF Hub server sends this via the X-HF-Warning response header, and
# huggingface_hub emits it through logging.warning().  Public Whisper models
# don't require authentication, so this is just noise for end users.
logging.getLogger("huggingface_hub").setLevel(logging.ERROR)

console = Console(stderr=True)


def _transcribe_mlx(audio_path: Path, model_name: str, verbose: bool) -> Transcript:
    """Transcribe using mlx-whisper (Apple Silicon GPU/Neural Engine)."""
    import mlx_whisper

    # Map short names to HuggingFace model IDs
    model_map = {
        "tiny": "mlx-community/whisper-tiny-mlx",
        "base": "mlx-community/whisper-base-mlx",
        "small": "mlx-community/whisper-small-mlx",
        "medium": "mlx-community/whisper-medium-mlx",
        "turbo": "mlx-community/whisper-large-v3-turbo",
        "large-v3": "mlx-community/whisper-large-v3-mlx",
    }
    model_id = model_map.get(model_name, model_name)

    if verbose:
        console.print(f"[dim]Loading MLX Whisper model '{model_id}'...[/dim]")
        console.print(f"[dim]Transcribing {audio_path.name} (MLX accelerated)...[/dim]")

    result = mlx_whisper.transcribe(
        str(audio_path),
        path_or_hf_repo=model_id,
        word_timestamps=True,
    )

    segments: list[Segment] = []
    words: list[Word] = []
    full_text_parts: list[str] = []

    for i, seg in enumerate(result.get("segments", [])):
        text = seg.get("text", "").strip()
        segments.append(
            Segment(
                id=i,
                start=seg["start"],
                end=seg["end"],
                text=text,
            )
        )
        full_text_parts.append(text)

        for w in seg.get("words", []):
            words.append(
                Word(
                    word=w["word"],
                    start=w["start"],
                    end=w["end"],
                    probability=w.get("probability", 0.0),
                )
            )

    language = result.get("language", "unknown")

    if verbose:
        console.print(
            f"[dim]Transcription complete: {len(segments)} segments, "
            f"{len(words)} words, language={language}[/dim]"
        )

    return Transcript(
        text=" ".join(full_text_parts),
        language=language,
        segments=segments,
        words=words,
    )


def _transcribe_faster_whisper(audio_path: Path, model_name: str, verbose: bool) -> Transcript:
    """Transcribe using faster-whisper (CPU)."""
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise SystemExit(
            "faster-whisper is not installed.\n"
            "Install it with: pip install faster-whisper"
        )

    if verbose:
        console.print(f"[dim]Loading faster-whisper model '{model_name}'...[/dim]")

    # Map short names for faster-whisper
    cpu_model_map = {
        "turbo": "deepdml/faster-whisper-large-v3-turbo-ct2",
    }
    effective_model = cpu_model_map.get(model_name, model_name)

    # Fallback chain for turbo: turbo -> large-v3 -> medium
    fallback_chain = [effective_model]
    if model_name == "turbo":
        fallback_chain.extend(["large-v3", "medium"])

    model = None
    for candidate_model in fallback_chain:
        try:
            model = WhisperModel(candidate_model, device="cpu", compute_type="int8")
            if candidate_model != effective_model:
                console.print(
                    f"[yellow]Model '{effective_model}' not available, "
                    f"using '{candidate_model}' instead.[/yellow]"
                )
            break
        except MemoryError:
            raise SystemExit(
                f"Not enough memory for Whisper model '{candidate_model}'.\n"
                "Try a smaller model: podcut find audio.mp3 --whisper-model small"
            )
        except Exception as e:
            if "memory" in str(e).lower() or "oom" in str(e).lower():
                raise SystemExit(
                    f"Not enough memory for Whisper model '{candidate_model}'.\n"
                    "Try a smaller model: podcut find audio.mp3 --whisper-model small"
                )
            if candidate_model == fallback_chain[-1]:
                raise
            if verbose:
                console.print(f"[dim]Model '{candidate_model}' failed: {e}. Trying fallback...[/dim]")

    assert model is not None

    if verbose:
        console.print(f"[dim]Transcribing {audio_path.name} (CPU)...[/dim]")

    raw_segments, info = model.transcribe(
        str(audio_path),
        word_timestamps=True,
        vad_filter=True,
    )

    segments: list[Segment] = []
    words: list[Word] = []
    full_text_parts: list[str] = []

    for seg in raw_segments:
        segments.append(
            Segment(
                id=seg.id,
                start=seg.start,
                end=seg.end,
                text=seg.text.strip(),
            )
        )
        full_text_parts.append(seg.text.strip())

        if seg.words:
            for w in seg.words:
                words.append(
                    Word(
                        word=w.word,
                        start=w.start,
                        end=w.end,
                        probability=w.probability,
                    )
                )

    detected_language = info.language if info.language else "unknown"

    if verbose:
        console.print(
            f"[dim]Transcription complete: {len(segments)} segments, "
            f"{len(words)} words, language={detected_language}[/dim]"
        )

    return Transcript(
        text=" ".join(full_text_parts),
        language=detected_language,
        segments=segments,
        words=words,
    )


def transcribe(
    audio_path: Path,
    model_name: str = "medium",
    backend: str = "auto",
    verbose: bool = False,
) -> Transcript:
    """Transcribe audio file with word-level timestamps.

    Args:
        audio_path: Path to the audio file (MP3/WAV).
        model_name: Whisper model size (tiny, base, small, medium, large-v3).
        backend: "mlx" (Apple Silicon), "cpu" (faster-whisper), or "auto" (try MLX first).
        verbose: Whether to print detailed progress.

    Returns:
        Transcript with segments and word-level timestamps.
    """
    if backend == "auto":
        try:
            import mlx_whisper  # noqa: F401
            backend = "mlx"
            if verbose:
                console.print("[dim]Using MLX backend (Apple Silicon accelerated)[/dim]")
        except ImportError:
            backend = "cpu"
            if verbose:
                console.print("[dim]MLX not available, falling back to CPU backend (slower)[/dim]")

    if backend == "mlx":
        return _transcribe_mlx(audio_path, model_name, verbose)
    elif backend == "cpu":
        return _transcribe_faster_whisper(audio_path, model_name, verbose)
    else:
        raise ValueError(f"Unknown backend '{backend}'. Must be 'auto', 'mlx', or 'cpu'.")


def format_transcript_with_timestamps(transcript: Transcript) -> str:
    """Format transcript with timestamps for inclusion in Gemini prompt.

    Produces a readable format like:
    [00:00.0 - 00:05.2] This is the first segment of speech.
    [00:05.5 - 00:10.1] And this is the second segment.
    """
    lines: list[str] = []
    for seg in transcript.segments:
        start_fmt = _format_time(seg.start)
        end_fmt = _format_time(seg.end)
        lines.append(f"[{start_fmt} - {end_fmt}] {seg.text}")
    return "\n".join(lines)


def _format_time(seconds: float) -> str:
    """Format seconds as MM:SS.d"""
    minutes = int(seconds // 60)
    secs = seconds % 60
    return f"{minutes:02d}:{secs:05.2f}"
