"""Ollama-based LLM provider implementation for local inference."""

from __future__ import annotations

import json
from pathlib import Path

import httpx
from rich.console import Console

from podcut.config import DEFAULT_OLLAMA_MODEL, OLLAMA_BASE_URL
from podcut.extraction_mode import COLD_OPEN_MODE, ExtractionMode
from podcut.i18n import t
from podcut.models import ColdOpenCandidate, GeminiAnalysisResult
from podcut.prompts import build_analysis_prompt, build_feedback_prompt

console = Console(stderr=True)

# Retry configuration
MAX_RETRIES = 2
REQUEST_TIMEOUT_SEC = 300  # Local LLM can be slow


def _call_ollama(
    model: str,
    prompt: str,
    base_url: str = OLLAMA_BASE_URL,
    verbose: bool = False,
) -> str:
    """Call Ollama API and return the response text.

    Uses the /api/chat endpoint with JSON format enforcement and streaming
    to show generation progress.
    """
    import time

    url = f"{base_url}/api/chat"
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": (
                    "You are a podcast editor AI. "
                    "Always respond with valid JSON only. No markdown, no code fences."
                ),
            },
            {"role": "user", "content": prompt},
        ],
        "format": "json",
        "stream": True,
        "options": {
            "temperature": 0.3,
            "num_predict": 4096,
        },
    }

    last_error: Exception | None = None
    for attempt in range(MAX_RETRIES + 1):
        try:
            start_time = time.monotonic()
            collected_content = []
            token_count = 0
            with httpx.Client(timeout=httpx.Timeout(REQUEST_TIMEOUT_SEC, connect=10.0)) as client:
                with client.stream("POST", url, json=payload) as resp:
                    resp.raise_for_status()
                    for line in resp.iter_lines():
                        if not line:
                            continue
                        try:
                            chunk = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        msg = chunk.get("message", {})
                        content = msg.get("content", "")
                        if content:
                            collected_content.append(content)
                            token_count += 1
                        if chunk.get("done"):
                            break

            raw_text = "".join(collected_content).strip()
            if not raw_text:
                raise RuntimeError(t("ollama_empty_response"))

            elapsed = time.monotonic() - start_time
            console.print(f"[dim]  {t('ollama_generation_done', tokens=token_count, elapsed=elapsed)}[/dim]")
            return raw_text
        except httpx.ConnectError:
            raise RuntimeError(t("ollama_connect_error", url=base_url))
        except Exception as e:
            last_error = e
            if attempt < MAX_RETRIES:
                if verbose:
                    console.print(f"[dim]Ollama retry {attempt + 1}/{MAX_RETRIES}: {e}[/dim]")
                continue
            raise RuntimeError(f"Ollama API failed after {MAX_RETRIES + 1} attempts: {last_error}")


def _parse_candidates(raw_text: str) -> list[ColdOpenCandidate]:
    """Parse Ollama response text into candidate list."""
    # Strip markdown code fences if present
    text = raw_text.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines)

    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise RuntimeError(
            f"Failed to parse Ollama response as JSON: {e}\n"
            f"Raw response:\n{text[:500]}"
        )

    try:
        result = GeminiAnalysisResult.model_validate(data)
    except Exception as e:
        raise RuntimeError(
            f"LLM response JSON does not match expected schema: {e}\n"
            f"Raw response:\n{text[:500]}"
        )
    return result.candidates


class OllamaProvider:
    """LLM provider backed by local Ollama server.

    Uses transcript-only analysis (no audio upload).
    """

    def __init__(
        self,
        model: str = DEFAULT_OLLAMA_MODEL,
        base_url: str = OLLAMA_BASE_URL,
    ) -> None:
        self._model = model
        self._base_url = base_url

    @property
    def needs_audio_upload(self) -> bool:
        """Ollama works with transcript only, no audio upload needed."""
        return False

    def upload(self, audio_path: Path, verbose: bool = False) -> None:
        """No-op: local LLM does not need audio upload."""
        if verbose:
            console.print("[dim]Skipping audio upload (local LLM uses transcript only).[/dim]")

    def analyze(
        self,
        transcript_text: str,
        num_candidates: int,
        mode: ExtractionMode = COLD_OPEN_MODE,
        verbose: bool = False,
    ) -> list[ColdOpenCandidate]:
        prompt = build_analysis_prompt(transcript_text, num_candidates, mode=mode, has_audio=False)

        if verbose:
            console.print(f"[dim]Analyzing content with Ollama ({self._model})...[/dim]")

        raw_text = _call_ollama(
            model=self._model,
            prompt=prompt,
            base_url=self._base_url,
            verbose=verbose,
        )
        candidates = _parse_candidates(raw_text)

        if verbose:
            console.print(f"[dim]Found {len(candidates)} candidates.[/dim]")

        return candidates

    def analyze_with_feedback(
        self,
        transcript_text: str,
        num_candidates: int,
        previous: list[ColdOpenCandidate],
        feedback: str,
        mode: ExtractionMode = COLD_OPEN_MODE,
        verbose: bool = False,
    ) -> list[ColdOpenCandidate]:
        previous_dicts = [c.model_dump() for c in previous]
        prompt = build_feedback_prompt(
            transcript_text=transcript_text,
            num_candidates=num_candidates,
            previous_candidates=previous_dicts,
            feedback=feedback,
            mode=mode,
            has_audio=False,
        )

        if verbose:
            console.print(f"[dim]Re-analyzing with feedback using Ollama ({self._model})...[/dim]")

        raw_text = _call_ollama(
            model=self._model,
            prompt=prompt,
            base_url=self._base_url,
            verbose=verbose,
        )
        candidates = _parse_candidates(raw_text)

        if verbose:
            console.print(f"[dim]Found {len(candidates)} new candidates.[/dim]")

        return candidates

    def cleanup(self, verbose: bool = False) -> None:
        """No-op: local LLM has no remote resources to clean up."""
        pass
