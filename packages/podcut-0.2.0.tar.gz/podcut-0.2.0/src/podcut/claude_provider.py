"""Anthropic Claude LLM provider implementation."""

from __future__ import annotations

import json
from pathlib import Path

from rich.console import Console

from podcut.extraction_mode import COLD_OPEN_MODE, ExtractionMode
from podcut.models import ColdOpenCandidate, GeminiAnalysisResult
from podcut.prompts import build_analysis_prompt, build_feedback_prompt

console = Console(stderr=True)

MAX_RETRIES = 2
REQUEST_TIMEOUT_SEC = 120


def _parse_candidates(raw_text: str) -> list[ColdOpenCandidate]:
    """Parse API response text into candidate list."""
    text = raw_text.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines)

    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise RuntimeError(
            f"Failed to parse Claude response as JSON: {e}\n"
            f"Raw response:\n{text[:500]}"
        )

    try:
        result = GeminiAnalysisResult.model_validate(data)
    except Exception as e:
        raise RuntimeError(
            f"LLM response JSON does not match expected schema: {e}\n"
            f"Raw response:\n{text[:500]}"
        )
    return result.candidates


def _check_anthropic_sdk() -> None:
    """Check that the anthropic SDK is importable."""
    try:
        import anthropic  # noqa: F401
    except ImportError:
        raise RuntimeError(
            "anthropic package is not installed. "
            "Install it with: pip install 'podcut[anthropic]'"
        )


class ClaudeProvider:
    """LLM provider backed by the Anthropic Claude API."""

    def __init__(self, model: str) -> None:
        self._model = model

    def _get_client(self):
        """Create an Anthropic client with lazy import."""
        _check_anthropic_sdk()
        from anthropic import Anthropic
        from podcut.config import get_anthropic_api_key

        api_key = get_anthropic_api_key()
        return Anthropic(api_key=api_key, timeout=REQUEST_TIMEOUT_SEC)

    def preflight(self) -> None:
        """Verify SDK installation and API key before heavy processing."""
        _check_anthropic_sdk()
        from podcut.config import get_anthropic_api_key
        get_anthropic_api_key()

    @property
    def needs_audio_upload(self) -> bool:
        return False

    def upload(self, audio_path: Path, verbose: bool = False) -> None:
        if verbose:
            console.print("[dim]Skipping audio upload (using transcript only).[/dim]")

    def analyze(
        self,
        transcript_text: str,
        num_candidates: int,
        mode: ExtractionMode = COLD_OPEN_MODE,
        verbose: bool = False,
    ) -> list[ColdOpenCandidate]:
        prompt = build_analysis_prompt(transcript_text, num_candidates, mode=mode, has_audio=False)

        if verbose:
            console.print(f"[dim]Analyzing content with Claude ({self._model})...[/dim]")

        raw_text = self._call_api(prompt, verbose=verbose)
        candidates = _parse_candidates(raw_text)

        if verbose:
            console.print(f"[dim]Found {len(candidates)} candidates.[/dim]")

        return candidates

    def analyze_with_feedback(
        self,
        transcript_text: str,
        num_candidates: int,
        previous: list[ColdOpenCandidate],
        feedback: str,
        mode: ExtractionMode = COLD_OPEN_MODE,
        verbose: bool = False,
    ) -> list[ColdOpenCandidate]:
        previous_dicts = [c.model_dump() for c in previous]
        prompt = build_feedback_prompt(
            transcript_text=transcript_text,
            num_candidates=num_candidates,
            previous_candidates=previous_dicts,
            feedback=feedback,
            mode=mode,
            has_audio=False,
        )

        if verbose:
            console.print(f"[dim]Re-analyzing with feedback using Claude ({self._model})...[/dim]")

        raw_text = self._call_api(prompt, verbose=verbose)
        candidates = _parse_candidates(raw_text)

        if verbose:
            console.print(f"[dim]Found {len(candidates)} new candidates.[/dim]")

        return candidates

    def cleanup(self, verbose: bool = False) -> None:
        pass

    def _call_api(self, prompt: str, verbose: bool = False) -> str:
        """Call the Anthropic API with retries."""
        client = self._get_client()

        last_error: Exception | None = None
        for attempt in range(MAX_RETRIES + 1):
            try:
                response = client.messages.create(
                    model=self._model,
                    max_tokens=4096,
                    system=(
                        "You are a podcast editor AI. "
                        "Always respond with valid JSON only. No markdown, no code fences, no explanation."
                    ),
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.3,
                )
                raw_text = response.content[0].text if response.content else ""
                if not raw_text.strip():
                    raise RuntimeError("Claude API returned an empty response.")
                return raw_text.strip()
            except SystemExit:
                raise
            except Exception as e:
                last_error = e
                if attempt < MAX_RETRIES:
                    if verbose:
                        console.print(f"[dim]Retry {attempt + 1}/{MAX_RETRIES}: {e}[/dim]")
                    continue
                raise RuntimeError(
                    f"Claude API failed after {MAX_RETRIES + 1} attempts: {last_error}"
                )
        # Unreachable but satisfies type checker
        raise RuntimeError(f"Claude API failed: {last_error}")
