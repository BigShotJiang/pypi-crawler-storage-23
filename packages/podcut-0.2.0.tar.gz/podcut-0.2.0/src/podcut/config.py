"""Configuration management via environment variables."""

import os
from pathlib import Path

from dotenv import load_dotenv

# ---------------------------------------------------------------------------
# API key metadata (must be defined before _load_all_dotenvs)
# ---------------------------------------------------------------------------

PROVIDER_API_KEY_INFO: dict[str, tuple[str, str, str]] = {
    # provider -> (env_var, label, url)
    "gemini": ("GEMINI_API_KEY", "Gemini API key", "https://aistudio.google.com/apikey"),
    "openai": ("OPENAI_API_KEY", "OpenAI API key", "https://platform.openai.com/api-keys"),
    "claude": ("ANTHROPIC_API_KEY", "Anthropic API key", "https://console.anthropic.com/settings/keys"),
    "grok": ("XAI_API_KEY", "xAI API key", "https://console.x.ai/"),
}


def _load_all_dotenvs() -> None:
    """Load .env files without overriding existing environment variables.

    Priority (highest first):
      1. Shell environment variables (``export VAR=...``) — never overwritten
      2. CWD ancestry .env  (project-local settings)
      3. ~/.config/podcut/.env  (wizard-saved API keys)

    Empty-value API key entries (e.g. ``GEMINI_API_KEY=`` in a project .env)
    are cleared after the first pass so that ``~/.config/podcut/.env`` can
    still provide the real value.
    """
    config_env = Path.home() / ".config" / "podcut" / ".env"

    # Snapshot API key vars already present in the shell environment
    # so we never touch them — even if they are empty strings.
    _api_key_vars = {info[0] for info in PROVIDER_API_KEY_INFO.values()}
    shell_preset_keys = {k for k in _api_key_vars if k in os.environ}

    # 1. CWD ancestry (higher priority among .env files)
    current = Path.cwd()
    for parent in [current, *current.parents]:
        env_path = parent / ".env"
        if env_path.exists():
            load_dotenv(env_path, override=False)
            break

    # 2. User config directory (lower priority — fills remaining gaps)
    if config_env.exists():
        load_dotenv(config_env, override=False)

    # 3. Clean up empty-string API key vars that a *project .env* may have
    #    set as placeholders, then re-read *only* the user config file so
    #    the real values can fill in.
    #    Keys that were already in the shell environment (shell_preset_keys)
    #    are never modified — an explicit ``export VAR=''`` is respected.
    empty_keys = [
        k for k in _api_key_vars
        if k not in shell_preset_keys and os.environ.get(k, None) == ""
    ]
    for k in empty_keys:
        del os.environ[k]
    if empty_keys and config_env.exists():
        load_dotenv(config_env, override=False)


_load_all_dotenvs()

# Language setting
DEFAULT_LANGUAGE = os.environ.get("PODCUT_LANGUAGE", "ja")


def get_gemini_api_key() -> str:
    """Get Gemini API key from environment, raising with helpful message if missing."""
    from podcut.i18n import t

    key = os.environ.get("GEMINI_API_KEY", "")
    if not key:
        raise SystemExit(t("gemini_api_key_missing"))
    return key


def get_openai_api_key() -> str:
    """Get OpenAI API key from environment, raising with helpful message if missing."""
    from podcut.i18n import t

    key = os.environ.get("OPENAI_API_KEY", "")
    if not key:
        raise SystemExit(t("openai_api_key_missing"))
    return key


def get_anthropic_api_key() -> str:
    """Get Anthropic API key from environment, raising with helpful message if missing."""
    from podcut.i18n import t

    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        raise SystemExit(t("anthropic_api_key_missing"))
    return key


def get_xai_api_key() -> str:
    """Get xAI API key from environment, raising with helpful message if missing."""
    from podcut.i18n import t

    key = os.environ.get("XAI_API_KEY", "")
    if not key:
        raise SystemExit(t("xai_api_key_missing"))
    return key


# ---------------------------------------------------------------------------
# API key helpers for interactive setup
# ---------------------------------------------------------------------------


def has_api_key(provider_name: str) -> bool:
    """Check whether the required API key for *provider_name* is set.

    Ollama never needs an API key, so it always returns True.
    """
    if provider_name == "ollama":
        return True
    info = PROVIDER_API_KEY_INFO.get(provider_name)
    if info is None:
        return True
    env_var = info[0]
    return bool(os.environ.get(env_var, ""))


def _dotenv_path_for_save() -> Path:
    """Return the path to ~/.config/podcut/.env (creating dir if needed)."""
    config_dir = Path.home() / ".config" / "podcut"
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir / ".env"


def save_api_key_to_dotenv(env_var: str, value: str) -> Path:
    """Append or update *env_var*=*value* in ~/.config/podcut/.env.

    Also sets os.environ so the key is available immediately.
    The file is created with mode 0600 (owner-only read/write).
    Returns the path to the .env file.
    """
    import stat

    env_path = _dotenv_path_for_save()

    # Update or append in the .env file
    lines: list[str] = []
    found = False
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            if line.startswith(f"{env_var}="):
                lines.append(f"{env_var}={value}")
                found = True
            else:
                lines.append(line)
    if not found:
        lines.append(f"{env_var}={value}")

    env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    # Restrict to owner-only read/write (chmod 600)
    try:
        env_path.chmod(stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass

    # Reflect in current process immediately
    os.environ[env_var] = value

    return env_path


DEFAULT_OUTPUT_DIR = Path("./output")
DEFAULT_CANDIDATES = 3
DEFAULT_FORMAT = "mp3"
DEFAULT_MODEL = "gemini-2.5-flash"
AVAILABLE_MODELS = [
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite",
    "gemini-2.5-pro",
    "gemini-3.1-pro-preview",
]
DEFAULT_WHISPER_MODEL = "turbo"
AVAILABLE_WHISPER_MODELS = ["tiny", "base", "small", "medium", "turbo", "large-v3"]

# Provider selection
AVAILABLE_PROVIDERS = ["gemini", "ollama", "openai", "claude", "grok"]
DEFAULT_PROVIDER = "gemini"

# Ollama configuration
_ollama_url = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
if not _ollama_url.startswith(("http://", "https://")):
    import sys
    print(
        f"Warning: OLLAMA_BASE_URL '{_ollama_url}' has invalid scheme. "
        "Must start with http:// or https://. Defaulting to http://localhost:11434.",
        file=sys.stderr,
    )
    _ollama_url = "http://localhost:11434"
OLLAMA_BASE_URL = _ollama_url.rstrip("/")
DEFAULT_OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "qwen3:8b")
AVAILABLE_OLLAMA_MODELS = [
    "qwen3:8b",
    "qwen3:4b",
    "gemma3:12b",
    "llama3.1:8b",
]

# OpenAI configuration
DEFAULT_OPENAI_MODEL = "gpt-4.1-mini"
AVAILABLE_OPENAI_MODELS = [
    "gpt-4.1",
    "gpt-4.1-mini",
    "gpt-4.1-nano",
    "o4-mini",
]

# Claude (Anthropic) configuration
DEFAULT_CLAUDE_MODEL = "claude-sonnet-4-5"
AVAILABLE_CLAUDE_MODELS = [
    "claude-sonnet-4-5",
    "claude-haiku-4-5",
]

# Grok (xAI) configuration
DEFAULT_GROK_MODEL = "grok-3-mini"
AVAILABLE_GROK_MODELS = [
    "grok-3",
    "grok-3-mini",
]
GROK_BASE_URL = "https://api.x.ai/v1"

# Cold open constraints (legacy defaults; prefer ExtractionMode for mode-specific values)
MIN_DURATION_SEC = 10
MAX_DURATION_SEC = 90

# Gemini upload timeout
UPLOAD_TIMEOUT_SEC = 300  # 5 minutes max wait for file processing

# Transcript size limit for Gemini prompt (characters)
MAX_TRANSCRIPT_CHARS = 200_000

# Audio processing
SILENCE_SEARCH_WINDOW_MS = 500
PADDING_MS = 100
FADE_IN_MS = 50
FADE_OUT_MS = 50
