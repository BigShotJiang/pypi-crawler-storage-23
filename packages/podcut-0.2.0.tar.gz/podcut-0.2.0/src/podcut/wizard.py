"""Interactive wizard for cold-open when invoked without arguments."""

import glob
import os
import sys
from pathlib import Path
from types import ModuleType
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from podcut import __version__
from podcut.config import (
    AVAILABLE_CLAUDE_MODELS,
    AVAILABLE_GROK_MODELS,
    AVAILABLE_MODELS,
    AVAILABLE_OLLAMA_MODELS,
    AVAILABLE_OPENAI_MODELS,
    AVAILABLE_PROVIDERS,
    AVAILABLE_WHISPER_MODELS,
    DEFAULT_CANDIDATES,
    DEFAULT_CLAUDE_MODEL,
    DEFAULT_FORMAT,
    DEFAULT_GROK_MODEL,
    DEFAULT_MODEL,
    DEFAULT_OLLAMA_MODEL,
    DEFAULT_OPENAI_MODEL,
    DEFAULT_PROVIDER,
    DEFAULT_WHISPER_MODEL,
    PROVIDER_API_KEY_INFO,
    has_api_key,
    save_api_key_to_dotenv,
)
from podcut.extraction_mode import AVAILABLE_MODES, CLIP_MODE, COLD_OPEN_MODE, ExtractionMode, get_mode
from podcut.i18n import set_language, t
from podcut.settings import PROVIDER_MODEL_KEYS, load_settings, save_settings

console = Console(stderr=True)

AUDIO_EXTENSIONS = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"}
_readline_module: ModuleType | None = None
_readline_configured = False


class WizardCancelled(Exception):
    """Raised when the user presses Ctrl+C during the wizard."""


# ---------------------------------------------------------------------------
# Terminal settings management (prevents ^M after Ctrl+C on macOS)
# ---------------------------------------------------------------------------

def _save_terminal_settings() -> Any:
    """Save current terminal settings so they can be restored later."""
    try:
        import termios
        if sys.stdin.isatty():
            return termios.tcgetattr(sys.stdin)
    except (ImportError, OSError):
        pass
    return None


def _restore_terminal_settings(settings: Any) -> None:
    """Restore previously saved terminal settings."""
    if settings is not None:
        try:
            import termios
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        except (ImportError, OSError):
            pass


def _ensure_terminal_sane() -> None:
    """Ensure terminal has ICRNL enabled so Enter works correctly.

    On macOS, libedit (Python's readline backend) can leave the terminal
    with ICRNL disabled after a Ctrl+C interrupt. When ICRNL is off,
    Enter sends raw \\r which is displayed as ^M and input() never completes.
    """
    try:
        import termios
        if not sys.stdin.isatty():
            return
        attrs = termios.tcgetattr(sys.stdin)
        if not (attrs[0] & termios.ICRNL):
            attrs[0] |= termios.ICRNL
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, attrs)
    except (ImportError, OSError):
        pass


# ---------------------------------------------------------------------------
# readline Tab-completion for audio file paths
# ---------------------------------------------------------------------------

def _setup_audio_file_completer() -> None:
    """Configure readline Tab-completion for audio file paths.

    Skipped entirely in non-interactive sessions (e.g. pytest, pipes) to
    avoid segfaults (EXIT:139) from readline/libedit initialisation.
    """
    global _readline_module, _readline_configured

    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        return
    try:
        import readline
    except (ImportError, OSError):
        return

    def completer(text: str, state: int):
        try:
            expanded = os.path.expanduser(text)
            matches = glob.glob(expanded + "*")
            filtered = [
                m + ("/" if os.path.isdir(m) else "")
                for m in matches
                if os.path.isdir(m) or Path(m).suffix.lower() in AUDIO_EXTENSIONS
            ]
            return filtered[state] if state < len(filtered) else None
        except Exception:
            return None

    try:
        readline.set_completer(completer)
        readline.set_completer_delims(" \t\n;")
        # macOS libedit detection
        if readline.__doc__ and "libedit" in readline.__doc__:
            readline.parse_and_bind("bind ^I rl_complete")
        else:
            readline.parse_and_bind("tab: complete")
        _readline_module = readline
        _readline_configured = True
    except Exception:
        # readline/libedit can crash on certain environments; degrade gracefully
        pass


def _restore_default_completer() -> None:
    """Restore default readline completer."""
    global _readline_configured
    if not _readline_configured or _readline_module is None:
        return
    try:
        _readline_module.set_completer(None)
    except (ImportError, OSError, Exception):
        pass
    finally:
        _readline_configured = False


# ---------------------------------------------------------------------------
# Prompt helpers
# ---------------------------------------------------------------------------

def _prompt(text: str, default: str = "") -> str:
    """Basic input prompt. Raises WizardCancelled on Ctrl+C / EOF."""
    suffix = f" [{default}]" if default else ""
    _ensure_terminal_sane()
    try:
        value = input(f"  {text}{suffix}: ").strip()
    except (KeyboardInterrupt, EOFError):
        console.print()
        raise WizardCancelled()
    return value if value else default


def _format_file_size(size_bytes: int) -> str:
    """Format file size in human-readable form."""
    if size_bytes >= 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 ** 3):.1f} GB"
    if size_bytes >= 1024 * 1024:
        return f"{size_bytes / (1024 ** 2):.1f} MB"
    if size_bytes >= 1024:
        return f"{size_bytes / 1024:.1f} KB"
    return f"{size_bytes} B"


def _scan_audio_files() -> list[Path]:
    """Scan CWD and one level of subdirectories for audio files."""
    found: list[Path] = []
    cwd = Path.cwd()
    # Scan CWD
    try:
        for entry in sorted(cwd.iterdir()):
            if entry.is_file() and entry.suffix.lower() in AUDIO_EXTENSIONS:
                found.append(entry)
    except OSError:
        pass
    # Scan one level deep
    try:
        for subdir in sorted(cwd.iterdir()):
            if subdir.is_dir() and not subdir.name.startswith("."):
                try:
                    for entry in sorted(subdir.iterdir()):
                        if entry.is_file() and entry.suffix.lower() in AUDIO_EXTENSIONS:
                            found.append(entry)
                except OSError:
                    pass
    except OSError:
        pass
    return found


def _clean_dropped_path(raw: str) -> str:
    """Clean a path that may have been drag-and-dropped into the terminal.

    Handles:
    - Surrounding single or double quotes (e.g. '/path/to/file.mp3')
    - Backslash-escaped spaces (e.g. /path/to/my\\ file.mp3)
    - Trailing whitespace / newlines
    """
    raw = raw.strip()
    # Strip surrounding quotes
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in ("'", '"'):
        raw = raw[1:-1]
    # Unescape backslash-space
    raw = raw.replace("\\ ", " ")
    return raw


def _prompt_path(text: str) -> Path:
    """Prompt for an audio file path with auto-scan, drag-and-drop, and Tab-completion."""
    # Auto-scan for audio files
    audio_files = _scan_audio_files()
    if audio_files:
        console.print(t("audio_files_found"))
        for i, f in enumerate(audio_files, 1):
            try:
                size = _format_file_size(f.stat().st_size)
            except (FileNotFoundError, PermissionError, OSError):
                size = "?"
            rel = f.relative_to(Path.cwd()) if f.is_relative_to(Path.cwd()) else f
            console.print(t("audio_file_entry", num=i, name=str(rel), size=size))
        console.print()
        prompt_text = t("audio_select_or_path")
    else:
        console.print(t("no_audio_files_found"))
        prompt_text = text

    _setup_audio_file_completer()
    try:
        while True:
            raw = _prompt(prompt_text)
            if not raw:
                console.print(f"    [red]{t('prompt_enter_file_path')}[/red]")
                continue

            # Try as numbered selection from scanned list
            if audio_files:
                try:
                    idx = int(raw)
                    if 1 <= idx <= len(audio_files):
                        path = audio_files[idx - 1].resolve()
                        if not path.exists():
                            console.print(f"    [red]{t('prompt_file_not_found', path=path)}[/red]")
                            continue
                        console.print(f"    [green]{t('ok')}:[/green] {path.name}")
                        return path
                except ValueError:
                    pass

            # Clean drag-and-drop artifacts
            raw = _clean_dropped_path(raw)

            path = Path(os.path.expanduser(raw)).resolve()
            if not path.exists():
                console.print(f"    [red]{t('prompt_file_not_found', path=path)}[/red]")
                continue
            if path.suffix.lower() not in AUDIO_EXTENSIONS:
                exts = ", ".join(sorted(AUDIO_EXTENSIONS))
                console.print(f"    [red]{t('prompt_unsupported_format', suffix=path.suffix, exts=exts)}[/red]")
                continue
            console.print(f"    [green]{t('ok')}:[/green] {path.name}")
            return path
    finally:
        _restore_default_completer()


def _prompt_choice(
    text: str,
    options: list[str],
    default: str = "",
    descriptions: list[str] | None = None,
) -> str:
    """Display numbered options and accept a number or raw value."""
    for i, opt in enumerate(options, 1):
        tag = t("default_tag") if opt == default else ""
        desc = f"  [dim]{descriptions[i - 1]}[/dim]" if descriptions else ""
        console.print(f"    {i}. {opt}{tag}{desc}")

    while True:
        raw = _prompt(text, default)
        if not raw:
            continue
        # Try as number
        try:
            idx = int(raw)
            if 1 <= idx <= len(options):
                chosen = options[idx - 1]
                console.print(f"    [green]{t('ok')}:[/green] {chosen}")
                return chosen
            console.print(f"    [red]{t('prompt_enter_1_to_n', n=len(options))}[/red]")
            continue
        except ValueError:
            pass
        # Accept raw value if it's in options
        if raw in options:
            console.print(f"    [green]{t('ok')}:[/green] {raw}")
            return raw
        console.print(f"    [red]{t('prompt_invalid_choice', n=len(options), options=', '.join(options))}[/red]")


def _prompt_int(text: str, default: int, min_val: int = 1, max_val: int = 10) -> int:
    """Prompt for an integer within a range."""
    while True:
        raw = _prompt(f"{text} ({min_val}-{max_val})", str(default))
        try:
            value = int(raw)
        except ValueError:
            console.print(f"    [red]{t('prompt_enter_number_range', min_val=min_val, max_val=max_val)}[/red]")
            continue
        if value < min_val or value > max_val:
            console.print(f"    [red]{t('prompt_must_be_between', min_val=min_val, max_val=max_val)}[/red]")
            continue
        console.print(f"    [green]{t('ok')}:[/green] {value}")
        return value


def _prompt_confirm(text: str, default: bool = True) -> bool:
    """Y/n confirmation prompt."""
    hint = "Y/n" if default else "y/N"
    raw = _prompt(text, hint)
    if raw in ("Y/n", "y/N", ""):
        return default
    return raw.lower().startswith("y")


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------

def _show_welcome() -> None:
    """Display the welcome banner."""
    panel = Panel(
        f"[bold]podcut[/bold]  v{__version__}\n\n"
        f"{t('welcome_subtitle')}",
        border_style="cyan",
    )
    console.print(panel)
    console.print()


def _show_summary(
    audio_path: Path,
    extraction_mode: ExtractionMode,
    model: str,
    whisper_model: str,
    candidates: int,
    output_format: str,
    output_dir: Path,
    provider_name: str = "gemini",
) -> None:
    """Display a configuration summary table."""
    file_size_mb = audio_path.stat().st_size / (1024 * 1024)

    table = Table(title=t("summary_title"), show_header=False, border_style="cyan")
    table.add_column("Key", style="bold")
    table.add_column("Value")
    table.add_row(t("summary_audio_file"), audio_path.name)
    table.add_row(t("summary_file_size"), f"{file_size_mb:.1f} MB")
    table.add_row(t("summary_extraction_mode"), f"{extraction_mode.label} ({extraction_mode.min_duration_sec}-{extraction_mode.max_duration_sec}s)")
    table.add_row(t("summary_llm_provider"), provider_name)
    table.add_row(t("summary_llm_model"), model)
    table.add_row(t("summary_whisper_model"), whisper_model)
    table.add_row(t("summary_candidates"), str(candidates))
    table.add_row(t("summary_output_format"), output_format)
    table.add_row(t("summary_output_dir"), str(output_dir))
    console.print()
    console.print(table)
    console.print()


# ---------------------------------------------------------------------------
# Provider helpers
# ---------------------------------------------------------------------------

_PROVIDER_MODEL_INFO: dict[str, tuple[list[str], str, str, str]] = {
    # provider -> (available_models, hardcoded_default, step_title_key, select_prompt_key)
    "gemini": (AVAILABLE_MODELS, DEFAULT_MODEL, "step_gemini_model", "select_gemini_model"),
    "ollama": (AVAILABLE_OLLAMA_MODELS, DEFAULT_OLLAMA_MODEL, "step_ollama_model", "select_ollama_model"),
    "openai": (AVAILABLE_OPENAI_MODELS, DEFAULT_OPENAI_MODEL, "step_openai_model", "select_openai_model"),
    "claude": (AVAILABLE_CLAUDE_MODELS, DEFAULT_CLAUDE_MODEL, "step_claude_model", "select_claude_model"),
    "grok": (AVAILABLE_GROK_MODELS, DEFAULT_GROK_MODEL, "step_grok_model", "select_grok_model"),
}


def _resolve_model_default(provider_name: str, saved: dict[str, Any]) -> str:
    """Return the best default model for *provider_name*, considering saved settings."""
    info = _PROVIDER_MODEL_INFO.get(provider_name)
    if info is None:
        return DEFAULT_MODEL
    available, hardcoded_default, _, _ = info

    # Try provider-specific saved model first
    provider_key = PROVIDER_MODEL_KEYS.get(provider_name, "")
    saved_model = saved.get(provider_key, "")
    if saved_model and saved_model in available:
        return saved_model

    # Fall back to generic saved model if it belongs to this provider's list
    generic = saved.get("llm_model", "")
    if generic and generic in available:
        return generic

    return hardcoded_default


def _check_and_prompt_api_key(provider_name: str) -> None:
    """Check API key for *provider_name*; prompt interactively if missing."""
    if has_api_key(provider_name):
        return

    info = PROVIDER_API_KEY_INFO.get(provider_name)
    if info is None:
        return

    env_var, label, url = info
    console.print(f"[yellow]{t('api_key_not_found', provider=provider_name.capitalize(), env_var=env_var)}[/yellow]")
    console.print(t("api_key_get_at", url=url))

    while True:
        raw = _prompt(t("api_key_enter", label=label))
        if raw:
            break
        console.print(f"[red]{t('api_key_required')}[/red]")

    env_path = save_api_key_to_dotenv(env_var, raw)
    console.print(f"[green]{t('api_key_saved', path=str(env_path))}[/green]")


# ---------------------------------------------------------------------------
# Main wizard entry-point
# ---------------------------------------------------------------------------

def run_wizard(lang: str | None = None) -> None:
    """Run the interactive wizard from start to finish.

    Args:
        lang: If provided, skip the language selection step and use this language.
    """
    from podcut.config import DEFAULT_LANGUAGE

    saved_term = _save_terminal_settings()
    try:
        # Load saved settings for defaults
        saved = load_settings()
        has_saved = bool(saved)

        # Language is already initialized by __init__.py from PODCUT_LANGUAGE.
        # If --lang was provided, apply it now.
        if lang is not None:
            set_language(lang)
            total_steps = 7
            current_step = 0
        else:
            total_steps = 8
            current_step = 0

        _show_welcome()

        # Show hint if we loaded previous settings
        if has_saved:
            console.print(f"[dim]{t('settings_loaded_hint')}[/dim]")
            console.print()

        # Step: Language selection (skipped if --lang was provided)
        if lang is None:
            current_step += 1
            default_lang = saved.get("language", DEFAULT_LANGUAGE)
            console.print(t("step_header", current=current_step, total=total_steps, title=t("step_language")))
            console.print(t("select_language"))
            lang_choice = _prompt_choice(
                t("enter_number_or_value"), ["ja", "en"], default_lang,
                descriptions=["日本語", "English"],
            )
            set_language(lang_choice)
            console.print()
        else:
            lang_choice = lang

        # Step: LLM Provider
        current_step += 1
        default_provider = saved.get("provider", DEFAULT_PROVIDER)
        if default_provider not in AVAILABLE_PROVIDERS:
            default_provider = DEFAULT_PROVIDER
        console.print(t("step_header", current=current_step, total=total_steps, title=t("step_llm_provider")))
        console.print(t("select_llm_provider"))
        provider_descriptions = [
            t("provider_gemini_desc"),
            t("provider_ollama_desc"),
            t("provider_openai_desc"),
            t("provider_claude_desc"),
            t("provider_grok_desc"),
        ]
        provider_name = _prompt_choice(
            t("enter_number_or_value"), AVAILABLE_PROVIDERS, default_provider,
            descriptions=provider_descriptions,
        )
        console.print()

        # API key check (sub-prompt, not a numbered step)
        _check_and_prompt_api_key(provider_name)

        # Step: Extraction Mode
        current_step += 1
        default_mode = saved.get("extraction_mode", COLD_OPEN_MODE.name)
        if default_mode not in AVAILABLE_MODES:
            default_mode = COLD_OPEN_MODE.name
        console.print(t("step_header", current=current_step, total=total_steps, title=t("step_extraction_mode")))
        console.print(t("select_extraction_mode"))
        mode_descriptions = [
            t("mode_cold_open_desc", min=COLD_OPEN_MODE.min_duration_sec, max=COLD_OPEN_MODE.max_duration_sec),
            t("mode_clip_desc", min=CLIP_MODE.min_duration_sec // 60, max=CLIP_MODE.max_duration_sec // 60),
        ]
        mode_name = _prompt_choice(
            t("enter_number_or_value"), AVAILABLE_MODES, default_mode,
            descriptions=mode_descriptions,
        )
        extraction_mode = get_mode(mode_name)
        console.print()

        # Step: Audio file
        current_step += 1
        console.print(t("step_header", current=current_step, total=total_steps, title=t("step_audio_file")))
        audio_path = _prompt_path(t("path_to_audio"))
        console.print()

        # Step: LLM Model (use provider-specific saved default)
        current_step += 1
        model_default = _resolve_model_default(provider_name, saved)
        info = _PROVIDER_MODEL_INFO.get(provider_name)
        if info is not None:
            available_models, _, step_key, select_key = info
            console.print(t("step_header", current=current_step, total=total_steps, title=t(step_key)))
            console.print(t(select_key))
            llm_model = _prompt_choice(t("enter_number_or_value"), available_models, model_default)
        else:
            console.print(t("step_header", current=current_step, total=total_steps, title=t("step_gemini_model")))
            console.print(t("select_gemini_model"))
            llm_model = _prompt_choice(t("enter_number_or_value"), AVAILABLE_MODELS, model_default)
        console.print()

        # Step: Whisper model
        current_step += 1
        default_whisper = saved.get("whisper_model", DEFAULT_WHISPER_MODEL)
        if default_whisper not in AVAILABLE_WHISPER_MODELS:
            default_whisper = DEFAULT_WHISPER_MODEL
        console.print(t("step_header", current=current_step, total=total_steps, title=t("step_whisper_model")))
        console.print(t("select_whisper_model"))
        whisper_descriptions = [
            t("whisper_tiny"),
            t("whisper_base"),
            t("whisper_small"),
            t("whisper_medium"),
            t("whisper_turbo"),
            t("whisper_large"),
        ]
        whisper_model = _prompt_choice(
            t("enter_number_or_value"), AVAILABLE_WHISPER_MODELS, default_whisper,
            descriptions=whisper_descriptions,
        )
        console.print()

        # Step: Candidates
        current_step += 1
        default_candidates = saved.get("candidates", DEFAULT_CANDIDATES)
        if not isinstance(default_candidates, int) or not (1 <= default_candidates <= 10):
            default_candidates = DEFAULT_CANDIDATES
        console.print(t("step_header", current=current_step, total=total_steps, title=t("step_num_candidates")))
        candidates = _prompt_int(
            t("how_many_candidates", label=extraction_mode.label.lower()),
            default_candidates, 1, 10,
        )
        console.print()

        # Step: Output format
        current_step += 1
        default_format = saved.get("output_format", DEFAULT_FORMAT)
        if default_format not in ("mp3", "wav"):
            default_format = DEFAULT_FORMAT
        console.print(t("step_header", current=current_step, total=total_steps, title=t("step_output_format")))
        console.print(t("select_output_format"))
        output_format = _prompt_choice(t("enter_number_or_value"), ["mp3", "wav"], default_format)
        console.print()

        # Summary & confirm
        from podcut.config import DEFAULT_OUTPUT_DIR
        output_dir = DEFAULT_OUTPUT_DIR
        _show_summary(audio_path, extraction_mode, llm_model, whisper_model, candidates, output_format, output_dir, provider_name=provider_name)

        if not _prompt_confirm(t("proceed_with_analysis")):
            console.print(f"[yellow]{t('wizard_cancelled')}[/yellow]")
            raise SystemExit(0)

        # Save settings on confirmation
        new_settings = {
            "language": lang_choice,
            "provider": provider_name,
            "llm_model": llm_model,
            "whisper_model": whisper_model,
            "extraction_mode": mode_name,
            "candidates": candidates,
            "output_format": output_format,
        }
        # Also save provider-specific model
        provider_model_key = PROVIDER_MODEL_KEYS.get(provider_name)
        if provider_model_key:
            new_settings[provider_model_key] = llm_model
        # Merge with existing saved settings to preserve other provider models
        merged = {**saved, **new_settings}
        save_settings(merged)
        console.print(f"[dim]{t('settings_saved')}[/dim]")

        console.print()

        # Preflight: check ffmpeg
        from podcut.audio_processor import check_ffmpeg
        check_ffmpeg()

        # Run the pipeline
        from podcut.display import display_results
        from podcut.workflow import run_pipeline_interactive

        console.print(f"[bold]{t('analyzing', name=audio_path.name)}[/bold]")
        console.print(f"[dim]{t('mode_info', label=extraction_mode.label)}[/dim]")
        console.print(f"[dim]{t('provider_info', provider=provider_name, model=llm_model)}[/dim]")
        console.print(f"[dim]{t('press_ctrl_c')}[/dim]")
        console.print()

        results = run_pipeline_interactive(
            audio_path=audio_path,
            output_dir=output_dir,
            num_candidates=candidates,
            output_format=output_format,
            whisper_model=whisper_model,
            mode=extraction_mode,
            provider_name=provider_name,
            llm_model=llm_model,
        )

        display_results(results, mode=extraction_mode)

    except WizardCancelled:
        console.print(f"\n[yellow]{t('wizard_cancelled')}[/yellow]")
        raise SystemExit(130)
    except KeyboardInterrupt:
        console.print(f"\n[yellow]{t('cancelled_by_user')}[/yellow]")
        raise SystemExit(130)
    finally:
        _restore_terminal_settings(saved_term)
