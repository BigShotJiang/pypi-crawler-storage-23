"""Persistent user settings stored in ~/.config/podcut/settings.json."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

SETTINGS_DIR = Path.home() / ".config" / "podcut"
SETTINGS_FILE = SETTINGS_DIR / "settings.json"

ALLOWED_KEYS = frozenset({
    "language",
    "provider",
    "llm_model",
    "whisper_model",
    "extraction_mode",
    "candidates",
    "output_format",
})

# Provider-specific model memory (e.g. gemini→openai→gemini restores gemini model).
PROVIDER_MODEL_KEYS = {
    "gemini": "llm_model_gemini",
    "ollama": "llm_model_ollama",
    "openai": "llm_model_openai",
    "claude": "llm_model_claude",
    "grok": "llm_model_grok",
}

_ALL_SAVEABLE_KEYS = ALLOWED_KEYS | frozenset(PROVIDER_MODEL_KEYS.values())


def get_settings_path() -> Path:
    """Return the path to the settings file."""
    return SETTINGS_FILE


def load_settings() -> dict[str, Any]:
    """Load saved settings from disk.

    Returns an empty dict if the file doesn't exist or is corrupt.
    """
    if not SETTINGS_FILE.exists():
        return {}
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return {}
        # Filter to only known keys
        return {k: v for k, v in data.items() if k in _ALL_SAVEABLE_KEYS}
    except (json.JSONDecodeError, OSError):
        return {}


def save_settings(settings: dict[str, Any]) -> None:
    """Save settings to disk, filtering to allowed keys only.

    API keys are never persisted here.
    """
    filtered = {k: v for k, v in settings.items() if k in _ALL_SAVEABLE_KEYS}
    SETTINGS_DIR.mkdir(parents=True, exist_ok=True)
    SETTINGS_FILE.write_text(
        json.dumps(filtered, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def reset_settings() -> bool:
    """Delete the settings file. Returns True if a file was removed."""
    if SETTINGS_FILE.exists():
        SETTINGS_FILE.unlink()
        return True
    return False
