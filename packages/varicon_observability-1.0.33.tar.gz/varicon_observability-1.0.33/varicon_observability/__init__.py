from .config import ObservabilityConfig
from .sqs_helpers import get_current_traceparent, set_task_traceparent, dispatch_task_with_sqs_trace

# Lazy imports for modules that depend on optional packages (celery, fastapi, django, otel-sdk)
def __getattr__(name):
    if name == "setup_observability":
        from .setup import setup_observability
        return setup_observability
    if name == "setup_celery_observability":
        from .setup import setup_celery_observability
        return setup_celery_observability
    if name in ("setup_django", "setup_fastapi", "setup_celery", "instrument_asgi"):
        from . import integrations
        return getattr(integrations, name)
    if name == "setup_celery_instrumentation":
        from .celery_instrumentation import setup_celery_instrumentation
        return setup_celery_instrumentation
    if name == "call_task_with_trace_context":
        from .celery_helpers import call_task_with_trace_context
        return call_task_with_trace_context
    if name == "DatabaseSpanFilter":
        from .span_filter import DatabaseSpanFilter
        return DatabaseSpanFilter
    if name == "WebSocketTraceMiddleware":
        from .channels_middleware import WebSocketTraceMiddleware
        return WebSocketTraceMiddleware
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__version__ = "1.0.33"
__all__ = [
    "setup_observability",
    "setup_celery_observability",
    "ObservabilityConfig",
    "setup_django",
    "setup_fastapi",
    "setup_celery",
    "setup_celery_instrumentation",
    "call_task_with_trace_context",
    "get_current_traceparent",
    "set_task_traceparent",
    "dispatch_task_with_sqs_trace",
    "instrument_asgi",
    "DatabaseSpanFilter",
    "WebSocketTraceMiddleware",
]
