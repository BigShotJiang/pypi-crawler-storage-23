"""Tests for the storage module."""
