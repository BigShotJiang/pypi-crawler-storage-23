"""Remote storage implementation classes."""
