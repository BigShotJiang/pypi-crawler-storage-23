# gitta/__init__.py
# Purpose: Marks the gitta directory as a Python package.
