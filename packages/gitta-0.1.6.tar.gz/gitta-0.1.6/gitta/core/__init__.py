# core/__init__.py
# Purpose: Marks the core directory as a Python package.
#
# The core layer is the business logic orchestration layer.
# This is where the main workflow lives.
