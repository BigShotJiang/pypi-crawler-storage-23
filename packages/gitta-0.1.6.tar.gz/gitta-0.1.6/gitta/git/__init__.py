# git/__init__.py
# Purpose: Marks the git directory as a Python package.
#
# All git subprocess logic lives here.
# No other layer should call subprocess directly.
