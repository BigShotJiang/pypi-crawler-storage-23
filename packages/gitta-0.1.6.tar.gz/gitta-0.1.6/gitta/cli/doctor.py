# cli/doctor.py
# Purpose: Handles `gitta doctor`.
#
# Responsibilities:
#   - Check git installation
#   - Check config file
#   - Check API key
#   - Check provider connectivity
#   - Check model availability

import shutil

from gitta.constants import CONFIG_FILE
from gitta.config.storage import load_config
from gitta.git.repository import GitRepository
from gitta.utils.console import print_error, print_info, print_success

def doctor_command():
    """
    Diagnose common issues with your Gitta setup.

    Checks git, configuration, API key, provider connectivity,
    and model availability.

    Usage:
        gitta doctor
    """

    print_info("Running diagnostics...\n")
    all_passed = True

    # 1. Check git is installed
    if shutil.which("git"):
        print_success("[OK] Git is installed")
    else:
        print_error("[FAIL] Git is not installed. Install it from https://git-scm.com")
        all_passed = False

    # 2. Check inside a git repo
    if GitRepository.is_git_repo():
        print_success("[OK] Inside a Git repository")
    else:
        print_error("[FAIL] Not inside a Git repository. Run 'git init' or navigate to a repo.")
        all_passed = False

    # 3. Check config file exists
    if not CONFIG_FILE.exists():
        print_error("[FAIL] Config file not found. Run 'gitta init' to set up.")
        print_error("\nSome checks failed. Review the issues above.")
        return

    print_success(f"[OK] Config file found at {CONFIG_FILE}")

    # 4. Load and validate config
    try:
        config = load_config()
    except Exception as e:
        print_error(f"[FAIL] Could not read config: {e}")
        print_error("\nSome checks failed. Review the issues above.")
        return

    required_fields = ["provider", "base_url", "model", "style"]
    for field in required_fields:
        if config.get(field):
            print_success(f"[OK] Config field '{field}' is set: {config[field]}")
        else:
            print_error(f"[FAIL] Config field '{field}' is missing or empty. Run 'gitta init' to fix.")
            all_passed = False

    # 5. Check API key in config
    api_key = config.get("api_key", "")

    if api_key:
        print_success("[OK] API key found in config")
    else:
        print_error("[FAIL] No API key found in config. Run 'gitta init'.")
        all_passed = False

    # 6. Check provider connectivity and model availability
    base_url = config.get("base_url", "")
    model = config.get("model", "")

    if base_url and model and api_key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key, base_url=base_url)
            client.models.retrieve(model)
            print_success(f"[OK] Model '{model}' is available from provider")
        except Exception as e:
            print_error(f"[FAIL] Could not reach provider or model: {e}. Check your base_url and model in 'gitta init'.")
            all_passed = False

    # Summary
    if all_passed:
        print_success("\nAll checks passed!")
    else:
        print_error("\nSome checks failed. Review the issues above.")
