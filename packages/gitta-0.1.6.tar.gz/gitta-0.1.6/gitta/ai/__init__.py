# ai/__init__.py
# Purpose: Marks the ai directory as a Python package.
#
# Handles all AI communication.
# No other layer should construct API clients directly.
