# utils/errors.py
# Purpose: Custom exceptions.
#
# Example:
#   class GitError(Exception):
#       pass
#
#   class ConfigError(Exception):
#       pass
