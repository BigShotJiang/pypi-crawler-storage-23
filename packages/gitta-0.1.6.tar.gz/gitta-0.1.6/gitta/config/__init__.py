# config/__init__.py
# Purpose: Marks the config directory as a Python package.
#
# Responsible for configuration persistence.
