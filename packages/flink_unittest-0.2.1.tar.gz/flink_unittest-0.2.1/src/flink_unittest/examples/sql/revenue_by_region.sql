-- A comment

SELECT
  region,
  SUM(amount) AS total
FROM orders
GROUP BY region;
