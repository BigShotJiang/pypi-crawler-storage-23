import os
from pathlib import Path

import pytest
import solidipes as sp
import utils
from solidipes.validators.ontology import set_ontology_identifier

ontology_identifier = os.path.join(
    os.path.dirname(__file__), "..", "solidipes_solid_mech_plugin", "ontologies", "solidipes_solid_mech.py"
)


@pytest.fixture
def study_dir_custom_ontology(study_dir: Path) -> Path:
    """Get the study directory with the custom ontology applied."""

    set_ontology_identifier(ontology_identifier)
    return study_dir


class TestPyvistaMeshOntology:
    def test_input_mesh(self, study_dir_custom_ontology: Path) -> None:
        """Check that a mesh without fields is detected as an InputMesh."""
        from solidipes.validators.ontology import OntologyValidator, get_global_validator

        validator = get_global_validator(OntologyValidator)
        file_path = utils.get_asset_path("pyvista_mesh_no_fields.vtu")
        file = sp.load_file(file_path)
        class_name = validator.ontology.get_file_class_name(file)
        assert class_name == "InputMesh"

    def test_output_mesh(self, study_dir_custom_ontology: Path) -> None:
        """Check that a mesh with at least one field is detected as an OutputMesh."""
        from solidipes.validators.ontology import OntologyValidator, get_global_validator

        validator = get_global_validator(OntologyValidator)
        file_path = utils.get_asset_path("pyvista_mesh.vtu")
        file = sp.load_file(file_path)
        class_name = validator.ontology.get_file_class_name(file)
        assert class_name == "OutputMesh"
