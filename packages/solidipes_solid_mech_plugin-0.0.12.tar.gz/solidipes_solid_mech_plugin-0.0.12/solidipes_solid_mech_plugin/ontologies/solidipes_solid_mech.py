from pydantic import Field, model_validator
from solidipes.ontologies.solidipes import File, build_ontology_model
from solidipes.ontologies.solidipes import entity_classes as base_entity_classes
from solidipes.utils.utils import string_to_regex_pattern as regexify


class Mesh(File):
    """Mesh file entity."""

    ontology_class: str | None = Field(
        default=None, pattern=regexify("solidipes_solid_mech_plugin.loaders.pyvista_mesh.PyvistaMesh")
    )
    cell_data_names: list[str]
    point_data_names: list[str]


class InputMesh(Mesh):
    """Mesh file entity with no fields."""

    cell_data_names: list[str] = Field(default_factory=list, min_length=0, max_length=0)
    point_data_names: list[str] = Field(default_factory=list, min_length=0, max_length=0)


class OutputMesh(Mesh):
    """Mesh file entity with at least one field."""

    cell_data_names: list[str]
    point_data_names: list[str]

    @model_validator(mode="after")
    def _check_at_least_one_field(self):
        if not self.cell_data_names and not self.point_data_names:
            raise ValueError(
                "OutputMesh requires at least one field is required in cell_data_names or point_data_names."
            )
        return self


custom_entity_classes = [
    InputMesh,
    OutputMesh,
]

entity_classes = custom_entity_classes + base_entity_classes


ROCrateMetadata = build_ontology_model(entity_classes)
