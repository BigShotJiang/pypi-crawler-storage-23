import os

from solidipes.utils import config

streamlit_pyvista_cache_dir_name = os.path.join(config.solidipes_dirname, ".streamlit-pyvista-cache")
