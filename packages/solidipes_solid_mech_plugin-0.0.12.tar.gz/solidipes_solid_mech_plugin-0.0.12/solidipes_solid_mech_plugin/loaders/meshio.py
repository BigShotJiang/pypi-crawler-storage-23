from solidipes.loaders.file import File


class Meshio(File):
    """File loaded with meshio"""

    from ..viewers.pyvista_plotter import PyvistaPlotter

    _compatible_viewers = [PyvistaPlotter]

    @File.loadable
    def mesh(self):
        import meshio

        return meshio.read(self.file_info.path)
