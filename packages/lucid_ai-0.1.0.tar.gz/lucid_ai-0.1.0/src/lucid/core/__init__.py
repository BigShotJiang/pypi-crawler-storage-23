"""Core protocols and shared infrastructure."""
