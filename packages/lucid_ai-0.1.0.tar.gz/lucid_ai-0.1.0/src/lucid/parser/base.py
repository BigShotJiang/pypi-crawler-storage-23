"""Re-export of DocumentAdapter for parser implementations."""

from __future__ import annotations

from lucid.core.protocols import DocumentAdapter

__all__ = ["DocumentAdapter"]
