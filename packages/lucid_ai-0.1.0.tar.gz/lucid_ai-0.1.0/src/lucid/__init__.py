"""LUCID: Offline-first AI content detection and humanization engine."""

__version__ = "0.1.0"
