# Output Formatting

The output module formats and writes pipeline results in multiple formats.

## OutputFormatter

::: lucid.output.OutputFormatter
    options:
      members:
        - format_json
        - format_text
        - format_annotated
        - write
