"""Detection engine test suite."""
