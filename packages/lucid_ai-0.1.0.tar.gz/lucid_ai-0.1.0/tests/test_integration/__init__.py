"""Integration tests for the LUCID pipeline."""
