"""Tests for document reconstruction."""
