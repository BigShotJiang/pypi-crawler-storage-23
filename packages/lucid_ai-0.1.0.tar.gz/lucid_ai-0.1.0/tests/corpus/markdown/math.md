# Math in Markdown

The equation $E = mc^2$ is inline math. Another expression $f(x) = x^2$ appears here.

This paragraph has no math at all.

$$
\int_0^\infty e^{-x^2} dx = \frac{\sqrt{\pi}}{2}
$$

The display math above is a separate structural block.

A final paragraph with inline $\alpha + \beta = \gamma$ math.
