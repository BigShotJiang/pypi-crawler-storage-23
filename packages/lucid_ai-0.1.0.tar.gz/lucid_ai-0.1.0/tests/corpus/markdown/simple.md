# First Heading

This is the first paragraph under the first heading. It contains
multiple lines of text.

This is the second paragraph. It also spans
multiple lines.

## Second Heading

Content under the second heading provides additional context
for testing paragraph extraction.

### Third Level

A short paragraph at the third heading level.
