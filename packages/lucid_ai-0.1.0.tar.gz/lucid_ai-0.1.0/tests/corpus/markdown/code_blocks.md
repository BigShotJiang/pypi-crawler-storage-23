# Code Examples

This paragraph contains `inline code` within prose text.

```python
def hello():
    print("Hello, world!")
```

Another paragraph after the code block with more `inline code`.

```
Plain code block without language specification.
```

Final paragraph to verify position tracking after multiple code blocks.
