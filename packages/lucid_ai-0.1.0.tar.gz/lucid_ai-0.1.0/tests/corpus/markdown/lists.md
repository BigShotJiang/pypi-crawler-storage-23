# Lists

## Bullet List

- First item in the bullet list.
- Second item with more detail.
- Third item concludes the list.

## Ordered List

1. First ordered item.
2. Second ordered item.
3. Third ordered item.

## Nested List

- Outer item one.
  - Inner item A.
  - Inner item B.
- Outer item two.
  1. Numbered inner item.
  2. Another numbered item.

Paragraph after all lists.
