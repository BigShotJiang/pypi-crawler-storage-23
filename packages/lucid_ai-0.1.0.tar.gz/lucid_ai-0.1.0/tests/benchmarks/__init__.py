"""LUCID benchmark suite."""
