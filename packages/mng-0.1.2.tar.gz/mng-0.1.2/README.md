# mng

This is the main project in this repo, and thus the README for `mng` lives [here](../../README.md).
