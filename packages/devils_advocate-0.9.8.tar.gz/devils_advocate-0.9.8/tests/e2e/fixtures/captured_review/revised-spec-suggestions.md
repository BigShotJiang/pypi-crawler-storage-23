# Specification Enrichment Report

## Overview
This report synthesizes 27 distinct suggestions from domain experts across 13 thematic areas. **10 high-consensus ideas** were identified where multiple reviewers independently proposed similar enhancements, representing strong signals for prioritization. The suggestions focus heavily on accessibility, data input flexibility, professional workflow support, and user experience refinement.

---

## Accessibility

### Screen Reader and Keyboard Navigation Optimization -- 2/2 reviewers
Enhance accessibility with content descriptions and hints that include unit expectations (e.g., "Enter length in inches"), set explicit IME actions (Next/Done), move focus predictably across fields, ensure TalkBack labels read well, and consider larger tap targets and high-contrast themes for shop environments. This improves inclusivity for visually impaired users and accommodates challenging work environments without altering the core layout.

### Voice Command Input Support -- 1/2 reviewers
Integrate Android's speech-to-text for dictating dimensions and price (e.g., "length twelve width six thickness one"), making the app hands-free for users in workshops where typing is impractical. This extends accessibility benefits to users who need to operate the app while handling materials.

---

## Content

### Educational Board Foot Explainer -- 1/2 reviewers
Add an info icon linking to a dialog explaining the board foot formula and examples (e.g., "A board foot is 144 cubic inches of wood"), enriching the app with value for beginners and positioning it as an educational tool. This helps novices understand the domain vocabulary and increases retention by reducing external research needs.

---

## Data Model

### Fractional Input Parsing and Quick-Pick Chips -- 2/2 reviewers
Extend dimension parsing to handle fractional inputs like "1 1/2" or "1.5" interchangeably, storing them as decimals in the model. Additionally offer optional chips/buttons for common fractions (1/8, 1/4, 3/8, 1/2, 5/8, 3/4) that append to the current dimension field. This reduces typing friction for users accustomed to carpentry notations and matches workshop reality where thickness is frequently a standard fraction.

### Line-Item List with Undo/Remove -- 1/2 reviewers
Introduce a simple list of calculated line items (each with dimensions, quantity, bf, cost) beneath the result, with swipe-to-delete and a one-tap Undo snackbar. Running totals become auditable and correctable when entering many boards quickly, providing transparency for professional workflows.

### Save Named Price Presets Per Species/Supplier -- 1/2 reviewers
Let users save multiple named price presets (e.g., "Walnut S4S $12.50/bf", "Pine rough $3.25/bf") and switch quickly. Real pricing varies by wood species, grade, and supplier; presets reduce repetitive entry and errors for professionals working with diverse materials.

---

## Features

### Unit Conversion and Selection -- 2/2 reviewers
Add unit selectors with common presets for dimensions (inches, feet+inches, mm) and price basis (per board foot, per cubic foot/meter, per piece). Also support feet-and-inches entry mode (e.g., 8' 6 1/2") and fractional inputs to reduce mental math and accommodate different regional measurement preferences, enhancing global usability without changing the core workflow.

### Waste Factor Adjustment and Other Toggles -- 2/2 reviewers
Include a slider or toggles to apply waste percentage (e.g., +10% for cuts), sales tax %, and discount % (e.g., contractor pricing), automatically adjusting totals to help users plan for real-world material losses and provide more accurate project estimates. This makes totals "real-world accurate" while keeping defaults off for simplicity.

### Preset Lumber Size Buttons -- 1/2 reviewers
Include quick-select buttons for common lumber sizes (e.g., 2x4, 1x6) that auto-fill dimensions, speeding up repetitive calculations for standard boards and adding convenience for frequent users like builders.

### Quantity Multiplier Per Line Item -- 1/2 reviewers
Add a Quantity field (default 1) so users can price multiple identical boards in one calculation. This is a highly common workflow (e.g., "8 boards at 96 x 6 x 1") and complements the running total behavior, reducing calculation steps.

---

## Integrations

### Export Data to Spreadsheet/CSV -- 2/2 reviewers
Include a button to export running totals and individual calculations as a CSV file shareable via Android's share sheet (e.g., to Google Sheets or email). Optionally generate PDF "cut lists" with line items, dates, and supplier info for contractor workflows, enabling seamless integration with invoicing or inventory tools.

### Live Lumber Price API Fetch -- 1/2 reviewers
Integrate with a public API (e.g., for current wood prices) to auto-populate or suggest the price field based on wood type selection, providing real-time market insights and saving users research time.

---

## Monetization

### Premium Ad-Free Version and Pro Tier -- 2/2 reviewers
Offer an in-app purchase to remove non-intrusive banner ads, and provide a paid Pro tier unlocking advanced features like exports, unlimited presets, saved projects, and branded PDF invoices. This differentiates power users from the free basic calculator while creating revenue streams aligned with "power-user" value.

### Subscription for Project Saving -- 1/2 reviewers
Introduce a monthly subscription to save and load multiple "projects" (grouped calculations with names like "Deck Build"), allowing users to resume work across sessions and creating recurring revenue from professional users.

---

## Onboarding

### First-Launch Interactive Tutorial and Guidance -- 2/2 reviewers
On first app open, overlay tooltips guiding through entering price, dimensions, and calculating with a "Got it" button to dismiss. Additionally, prefill example values or show a short "How to measure" tip and explain what board feet means with a one-screen primer to help novices adopt the app without external searches.

---

## Other

### Multi-Language Localization -- 1/2 reviewers
Expand strings.xml with translations for key languages (e.g., Spanish, French) and adapt formats for regional number separators, broadening appeal to international users in the woodworking community.

---

## Performance Ux

### Real-Time Calculation Preview -- 2/2 reviewers
As users type dimensions, show a live preview of board feet and cost below the inputs (debounced for smoothness), eliminating the need for the calculate button in simple cases and offering instant feedback for iterative adjustments. Include an optional toggle for continuous calculation to make the app feel more like a "calculator" than a "form + submit."

---

## Platform

### Companion Web Version Integration -- 1/2 reviewers
Design for future web export of calculation logic via Kotlin Multiplatform, allowing users to access the same calculator on desktop browsers with sync via QR code scan, extending usability for office-based planning.

### Home Screen Widget for Quick Entry -- 1/2 reviewers
Provide a lightweight widget where users can enter L/W/T and see board feet instantly, optionally with price. Woodworkers may want quick access without opening the full app, especially in a shop setting with gloves or limited time.

---

## Security Privacy

### Optional Local Encryption for Totals -- 2/2 reviewers
If users enable a "save session" feature, encrypt the totalBoardFeet and totalCost using Android Keystore before storing in SharedPreferences, protecting sensitive cost data for professionals without cloud risks. Also include an explicit privacy statement ("No network access; data stays on device") and optional user-initiated local backup/export file to build trust.

---

## Social

### Share Calculation Snapshot -- 2/2 reviewers
Add share functionality that generates a formatted text or image snapshot of results and totals (e.g., "Board Foot Calc: 12x6x1 = 0.5 bf @ $5 = $2.50"), shareable via social apps like WhatsApp, Twitter, or messaging. Also provide copy functionality for clean text export, enabling users to message totals to customers or keep notes.

### Community "Common Dimensions" Templates -- 1/2 reviewers
Offer optional templates like "2x4 nominal vs actual," "deck boards," "turning blanks," etc., that populate fields with typical actual dimensions. This reduces measurement confusion and can become a differentiator via curated domain knowledge.

---

## Ux

### Auto-Focus Next Field on Input -- 1/2 reviewers
Automatically focus the next input field (e.g., from length to width to thickness) after entry using keyboard "next" actions or on-text-change listeners, streamlining rapid entry workflow for users calculating multiple boards quickly and reducing taps.

### Dark Mode Theme Toggle -- 1/2 reviewers
Add a settings toggle for dark mode using Material3 dynamic theming, automatically adapting colors.xml for low-light environments, improving eye comfort for users working in workshops or evenings.

### Undo Last Calculation Button -- 1/2 reviewers
Add an "Undo" button that subtracts the most recent board feet and cost from totals and restores dimension fields, helping users correct mistakes in multi-entry sessions without full clear.

### Inline Validation and Field-Level Errors -- 1/2 reviewers
Instead of only toasts, show inline errors on specific TextInputLayouts (e.g., "Required", "Must be > 0") and clear them when corrected, improving clarity and making "what went wrong" visually obvious.

### Quick "Repeat Last Dimensions" Action -- 1/2 reviewers
Provide a button/icon to reuse the last entered dimensions (and quantity) without retyping, useful when measuring similar boards that only differ slightly or when you accidentally cleared too early, supporting fast repetitive workflows.

---

## High-Consensus Ideas

The following 10 suggestions were independently proposed by **both reviewers**, indicating strong alignment on priority enhancements:

1. **Screen Reader and Keyboard Navigation Optimization** — Accessibility improvements for inclusive design
2. **Fractional Input Parsing and Quick-Pick Chips** — Natural carpentry notation support
3. **Unit Conversion and Selection** — Multi-unit and regional support
4. **Waste Factor Adjustment and Other Toggles** — Real-world project accuracy
5. **Export Data to Spreadsheet/CSV** — Professional workflow integration
6. **Premium Ad-Free Version and Pro Tier** — Sustainable monetization model
7. **First-Launch Interactive Tutorial and Guidance** — Reduced adoption friction
8. **Real-Time Calculation Preview** — Instant feedback and reduced taps
9. **Optional Local Encryption for Totals** — Professional data security
10. **Share Calculation Snapshot** — Social and professional sharing

These represent the strongest signals for immediate implementation consideration.