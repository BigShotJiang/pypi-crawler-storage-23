"""
Tests for antaris-memory v4.5.6 — Layers 7, 8, 9, 10 + Layer 5 positional salience.

Layer 7: IntentReranker
Layer 8: QualifierAnalyzer
Layer 9: MemoryClusterer / ClusterIndex
Layer 10: LayerCalibrator / LayerWeights
Integration: end-to-end search with all new layers
"""
import json
import os
import tempfile
import unittest

from antaris_memory.search import IntentReranker, QualifierAnalyzer, SearchEngine, SearchResult
from antaris_memory.clustering import (
    MemoryClusterer, ClusterIndex, extract_entities, _BoostedResult
)
from antaris_memory.calibration import LayerCalibrator, LayerWeights, f_at_k, mean_reciprocal_rank
from antaris_memory.entry import MemoryEntry


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_entry(content, hash_=None, tags=None, source="test", category="general",
               agent_id="", session_id="*"):
    e = MemoryEntry(content=content, source=source, category=category,
                    session_id=session_id, agent_id=agent_id)
    if hash_:
        e.hash = hash_
    if tags:
        e.tags = tags
    return e


def make_result(content, score=1.0, hash_=None, tags=None):
    entry = make_entry(content, hash_=hash_ or content[:8], tags=tags)
    return SearchResult(
        entry=entry,
        score=score,
        relevance=round(score, 4),
        matched_terms=["test"],
        explanation="test"
    )


def make_tuple(content, score=1.0, hash_=None, tags=None):
    """Return (entry, score, matched) tuple for raw pipeline."""
    entry = make_entry(content, hash_=hash_ or content[:8], tags=tags)
    return (entry, score, ["test"])


# ═══════════════════════════════════════════════════════════════════════════
# Layer 7 — IntentReranker
# ═══════════════════════════════════════════════════════════════════════════

class TestIntentDetection(unittest.TestCase):

    def test_temporal_intent_when(self):
        intents = IntentReranker.detect_intent("when did Jason approve the pricing")
        self.assertIn("temporal", intents)

    def test_temporal_intent_before(self):
        intents = IntentReranker.detect_intent("what happened before the launch")
        self.assertIn("temporal", intents)

    def test_entity_intent_who(self):
        intents = IntentReranker.detect_intent("who approved the budget")
        self.assertIn("entity", intents)

    def test_decision_intent(self):
        intents = IntentReranker.detect_intent("what was the decision about pricing")
        self.assertIn("decision", intents)

    def test_decision_intent_agreed(self):
        intents = IntentReranker.detect_intent("what did the team agreed on")
        self.assertIn("decision", intents)

    def test_howto_intent(self):
        intents = IntentReranker.detect_intent("how to deploy the service")
        self.assertIn("howto", intents)

    def test_quantity_intent(self):
        intents = IntentReranker.detect_intent("how much did the project cost")
        self.assertIn("quantity", intents)

    def test_comparison_intent(self):
        intents = IntentReranker.detect_intent("compare memory vs database approach")
        self.assertIn("comparison", intents)

    def test_multi_intent(self):
        intents = IntentReranker.detect_intent("when was the decision made on the timeline")
        self.assertIn("temporal", intents)
        self.assertIn("decision", intents)

    def test_no_intent(self):
        intents = IntentReranker.detect_intent("memory system")
        self.assertEqual(intents, [])

    def test_location_intent(self):
        intents = IntentReranker.detect_intent("where is the office located")
        self.assertIn("location", intents)


class TestIntentMemorySignals(unittest.TestCase):

    def test_temporal_boost_for_dated_memory(self):
        dated = "On 2026-02-15 Jason approved the pricing model."
        m = IntentReranker.score_intent_match(dated, ["temporal"])
        self.assertGreater(m, 1.0)

    def test_temporal_penalty_for_undated_memory(self):
        undated = "Jason likes the pricing model."
        m = IntentReranker.score_intent_match(undated, ["temporal"])
        self.assertLess(m, 1.0)

    def test_decision_boost_for_decision_memory(self):
        decided = "We decided to go with the Spark tier pricing."
        m = IntentReranker.score_intent_match(decided, ["decision"])
        self.assertGreater(m, 1.0)

    def test_entity_boost_for_named_entity(self):
        named = "Jason Miller approved the budget for Q1."
        m = IntentReranker.score_intent_match(named, ["entity"])
        self.assertGreater(m, 1.0)

    def test_neutral_for_no_intents(self):
        m = IntentReranker.score_intent_match("anything at all", [])
        self.assertEqual(m, 1.0)

    def test_partial_intent_match(self):
        # "temporal" + "decision" — only temporal signals in content
        content = "Yesterday we reviewed the options."
        m = IntentReranker.score_intent_match(content, ["temporal", "decision"])
        self.assertGreater(m, 1.0)  # partial boost (>1 but < INTENT_BOOST)
        self.assertLess(m, IntentReranker.INTENT_BOOST)


class TestIntentRerank(unittest.TestCase):

    def test_rerank_boosts_matching_memory(self):
        tuples = [
            make_tuple("2026-01-15: Jason approved the budget", score=1.0, hash_="dated"),
            make_tuple("The budget is interesting", score=1.0, hash_="undated"),
        ]
        result = IntentReranker.rerank("when was the budget approved", tuples)
        hashes = [r[0].hash for r in result]
        self.assertEqual(hashes[0], "dated")

    def test_rerank_no_intent_returns_unchanged_order(self):
        tuples = [
            make_tuple("alpha content", score=2.0, hash_="h1"),
            make_tuple("beta content", score=1.0, hash_="h2"),
        ]
        result = IntentReranker.rerank("memory system", tuples)
        self.assertEqual(result[0][0].hash, "h1")

    def test_rerank_returns_same_length(self):
        tuples = [make_tuple(f"memory {i}", score=float(i), hash_=f"h{i}") for i in range(5)]
        result = IntentReranker.rerank("when did this happen", tuples)
        self.assertEqual(len(result), 5)

    def test_rerank_preserves_tuple_structure(self):
        tuples = [make_tuple("2026-01-10: event occurred", score=1.0, hash_="e1")]
        result = IntentReranker.rerank("when did event occur", tuples)
        entry, score, matched = result[0]
        self.assertIsInstance(score, float)
        self.assertIsInstance(matched, list)


# ═══════════════════════════════════════════════════════════════════════════
# Layer 8 — QualifierAnalyzer
# ═══════════════════════════════════════════════════════════════════════════

class TestQualifierExtraction(unittest.TestCase):

    def test_temporal_before(self):
        q = QualifierAnalyzer._extract_qualifiers("what happened before the launch")
        self.assertEqual(q.get("temporal"), "before")

    def test_temporal_after(self):
        q = QualifierAnalyzer._extract_qualifiers("what happened after the launch")
        self.assertEqual(q.get("temporal"), "after")

    def test_outcome_success(self):
        q = QualifierAnalyzer._extract_qualifiers("what succeeded in Q1")
        self.assertEqual(q.get("outcome"), "success")

    def test_outcome_failure(self):
        q = QualifierAnalyzer._extract_qualifiers("what failed last week")
        self.assertEqual(q.get("outcome"), "failure")

    def test_negation_detected(self):
        q = QualifierAnalyzer._extract_qualifiers("what did not work")
        self.assertEqual(q.get("negation"), "present")

    def test_degree_most(self):
        q = QualifierAnalyzer._extract_qualifiers("what was the most important decision")
        self.assertEqual(q.get("degree"), "most")

    def test_degree_least(self):
        q = QualifierAnalyzer._extract_qualifiers("what was the least successful feature")
        self.assertEqual(q.get("degree"), "least")

    def test_empty_query(self):
        q = QualifierAnalyzer._extract_qualifiers("memory system search")
        self.assertEqual(q, {})


class TestQualifierAlignment(unittest.TestCase):

    def test_aligned_temporal_boost(self):
        m = QualifierAnalyzer.compute_alignment(
            "what happened before the launch",
            "prior to launch we reviewed the plan"
        )
        self.assertGreater(m, 1.0)

    def test_conflicting_temporal_penalty(self):
        m = QualifierAnalyzer.compute_alignment(
            "what happened before the launch",
            "after launch we shipped the feature"
        )
        self.assertLess(m, 1.0)

    def test_aligned_outcome_success_boost(self):
        m = QualifierAnalyzer.compute_alignment(
            "what succeeded in the sprint",
            "the deployment succeeded and shipped cleanly"
        )
        self.assertGreater(m, 1.0)

    def test_conflicting_outcome_penalty(self):
        m = QualifierAnalyzer.compute_alignment(
            "what succeeded in the sprint",
            "the deployment failed and rolled back"
        )
        self.assertLess(m, 1.0)

    def test_negation_mismatch_penalty(self):
        m = QualifierAnalyzer.compute_alignment(
            "what did not work",
            "the feature worked perfectly"
        )
        self.assertLess(m, 1.0)

    def test_neutral_when_no_query_qualifiers(self):
        m = QualifierAnalyzer.compute_alignment(
            "memory system search",
            "before the launch we had issues"
        )
        self.assertEqual(m, 1.0)


class TestQualifierApply(unittest.TestCase):

    def test_apply_boosts_aligned_memory(self):
        tuples = [
            make_tuple("before launch we finalized the plan", score=1.0, hash_="before"),
            make_tuple("after launch we reviewed results", score=1.0, hash_="after"),
        ]
        result = QualifierAnalyzer.apply("what happened before the launch", tuples)
        hashes = [r[0].hash for r in result]
        self.assertEqual(hashes[0], "before")

    def test_apply_returns_same_length(self):
        tuples = [make_tuple(f"item {i}", score=1.0, hash_=f"h{i}") for i in range(6)]
        result = QualifierAnalyzer.apply("what failed", tuples)
        self.assertEqual(len(result), 6)

    def test_apply_no_qualifiers_unchanged(self):
        tuples = [
            make_tuple("alpha", score=2.0, hash_="h1"),
            make_tuple("beta", score=1.0, hash_="h2"),
        ]
        result = QualifierAnalyzer.apply("memory search", tuples)
        self.assertEqual(result[0][0].hash, "h1")


# ═══════════════════════════════════════════════════════════════════════════
# Layer 9 — MemoryClusterer + ClusterIndex
# ═══════════════════════════════════════════════════════════════════════════

class TestEntityExtraction(unittest.TestCase):

    def test_extracts_multi_word_name(self):
        entities = extract_entities("Jason Miller approved the budget")
        self.assertIn("jason miller", entities)

    def test_extracts_acronym(self):
        entities = extract_entities("We use AWS and GCP for infrastructure")
        self.assertTrue(any(e in entities for e in ["aws", "gcp"]))

    def test_extracts_camelcase(self):
        entities = extract_entities("WealthHealth platform launched today")
        self.assertIn("wealthhealth", entities)

    def test_skips_stopwords(self):
        entities = extract_entities("The project started Monday in January")
        self.assertNotIn("the", entities)
        self.assertNotIn("monday", entities)
        self.assertNotIn("january", entities)

    def test_empty_text(self):
        entities = extract_entities("")
        self.assertEqual(entities, set())

    def test_skips_digits_only(self):
        entities = extract_entities("The value is 12345")
        self.assertNotIn("12345", entities)


class TestMemoryClusterer(unittest.TestCase):

    def setUp(self):
        self.clusterer = MemoryClusterer(max_cluster_size=8)
        # Use "Jason Miller" (multi-word capitalized name) mid-sentence so entity
        # extraction pattern r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b' picks it up.
        self.memories = [
            make_entry("Pricing tier approved by Jason Miller today", hash_="m1",
                       tags=["pricing"]),
            make_entry("Budget reviewed by Jason Miller last week", hash_="m2",
                       tags=["budget"]),
            make_entry("AWS infrastructure was upgraded last week", hash_="m3",
                       tags=["infra"]),
            make_entry("Deployment plan signed off by Jason Miller", hash_="m4",
                       tags=["deployment"]),
            make_entry("Unrelated memory about cooking recipes", hash_="m5"),
        ]
        self.clusterer.build_clusters(self.memories)

    def test_built_after_build_clusters(self):
        self.assertTrue(self.clusterer._built)

    def test_not_built_before_call(self):
        c = MemoryClusterer()
        self.assertFalse(c._built)

    def test_jason_memories_are_neighbors(self):
        neighbors = self.clusterer.get_cluster_for("m1")
        self.assertIn("m2", neighbors)
        self.assertIn("m4", neighbors)

    def test_self_not_in_neighbors(self):
        neighbors = self.clusterer.get_cluster_for("m1")
        self.assertNotIn("m1", neighbors)

    def test_unrelated_memory_has_fewer_neighbors(self):
        # m5 has no named entities → minimal or no cluster overlap
        neighbors_m1 = self.clusterer.get_cluster_for("m1")
        neighbors_m5 = self.clusterer.get_cluster_for("m5")
        self.assertGreaterEqual(len(neighbors_m1), len(neighbors_m5))

    def test_entities_extracted_for_memory(self):
        entities = self.clusterer.get_entities_for("m1")
        self.assertTrue(len(entities) > 0)

    def test_max_cluster_size_enforced(self):
        # Create more memories than max_cluster_size sharing one entity
        memories = [
            make_entry(f"Jason reviewed item {i}", hash_=f"jm{i}")
            for i in range(20)
        ]
        c = MemoryClusterer(max_cluster_size=5)
        c.build_clusters(memories)
        for ent, hashes in c._entity_to_hashes.items():
            self.assertLessEqual(len(hashes), 5)

    def test_stats_structure(self):
        stats = self.clusterer.stats()
        self.assertTrue(stats["built"])
        self.assertIn("unique_entities", stats)
        self.assertIn("avg_cluster_size", stats)
        self.assertIn("memories_with_entities", stats)

    def test_boost_neighbors_returns_list(self):
        results = [make_result(m.content, score=1.0, hash_=m.hash)
                   for m in self.memories]
        boosted = self.clusterer.boost_neighbors(results, top_k=3)
        self.assertIsInstance(boosted, list)
        self.assertEqual(len(boosted), len(results))

    def test_boost_neighbors_sorts_by_score(self):
        results = [make_result(m.content, score=float(i + 1), hash_=m.hash)
                   for i, m in enumerate(self.memories)]
        boosted = self.clusterer.boost_neighbors(results, top_k=3)
        scores = [r.score for r in boosted]
        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_cluster_neighbors_get_boosted(self):
        # m1 (Jason Miller) is top-K anchor; m2 and m4 (also Jason Miller) are neighbors.
        # Neighbors that appear OUTSIDE top-K get boosted.
        results = [
            make_result(self.memories[0].content, score=2.0, hash_="m1"),  # anchor (top-1)
            make_result(self.memories[2].content, score=0.5, hash_="m3"),  # AWS — not neighbor
            make_result(self.memories[1].content, score=0.4, hash_="m2"),  # Jason Miller neighbor
            make_result(self.memories[3].content, score=0.4, hash_="m4"),  # Jason Miller neighbor
            make_result(self.memories[4].content, score=0.1, hash_="m5"),  # unrelated
        ]
        boosted = self.clusterer.boost_neighbors(results, top_k=1, boost_factor=0.5)
        score_map = {r.entry.hash: r.score for r in boosted}
        # m2 and m4 are Jason Miller neighbors of m1 → should get boosted above 0.4
        self.assertGreater(score_map["m2"], 0.4)
        self.assertGreater(score_map["m4"], 0.4)


class TestClusterIndex(unittest.TestCase):
    """Verify the ClusterIndex adapter wires correctly to SearchEngine."""

    def test_build_alias(self):
        ci = ClusterIndex()
        memories = [make_entry("Jason approved budget", hash_="ci1")]
        ci.build(memories)
        self.assertTrue(ci._built)

    def test_apply_cluster_boost_alias(self):
        ci = ClusterIndex()
        memories = [
            make_entry("Jason signed the contract", hash_="ci1"),
            make_entry("Jason reviewed the plan", hash_="ci2"),
        ]
        ci.build(memories)
        results = [make_result(m.content, score=1.0, hash_=m.hash) for m in memories]
        boosted = ci.apply_cluster_boost(results, top_k=1)
        self.assertIsInstance(boosted, list)

    def test_cluster_index_stats_built(self):
        ci = ClusterIndex()
        memories = [make_entry("WealthHealth platform", hash_="w1")]
        ci.build(memories)
        stats = ci.stats()
        self.assertTrue(stats["built"])


class TestBoostedResult(unittest.TestCase):

    def test_boosted_result_score_override(self):
        orig = make_result("test content", score=1.0, hash_="br1")
        br = _BoostedResult(orig, new_score=1.5, boost_amount=0.5)
        self.assertEqual(br.score, 1.5)

    def test_boosted_result_proxies_entry(self):
        orig = make_result("test content", score=1.0, hash_="br2")
        br = _BoostedResult(orig, new_score=1.3, boost_amount=0.3)
        self.assertEqual(br.entry.hash, "br2")

    def test_boosted_result_matched_terms_includes_cluster_boost(self):
        orig = make_result("test content", score=1.0, hash_="br3")
        br = _BoostedResult(orig, new_score=1.2, boost_amount=0.2)
        self.assertIn("cluster_boost", br.matched_terms)

    def test_boosted_result_explanation_includes_boost(self):
        orig = make_result("test", score=1.0, hash_="br4")
        br = _BoostedResult(orig, new_score=1.1, boost_amount=0.1)
        self.assertIn("cluster_boost", br.explanation)


# ═══════════════════════════════════════════════════════════════════════════
# Layer 10 — LayerCalibrator + LayerWeights
# ═══════════════════════════════════════════════════════════════════════════

class TestLayerWeights(unittest.TestCase):

    def test_defaults(self):
        lw = LayerWeights()
        self.assertEqual(lw.bm25_base, 1.0)
        self.assertEqual(lw.intent_weight, 1.0)
        self.assertEqual(lw.cluster_boost, 0.15)

    def test_to_dict_round_trips(self):
        lw = LayerWeights(exact_phrase_bonus=2.0, tag_boost=1.5)
        d = lw.to_dict()
        lw2 = LayerWeights.from_dict(d)
        self.assertEqual(lw2.exact_phrase_bonus, 2.0)
        self.assertEqual(lw2.tag_boost, 1.5)

    def test_save_and_load(self):
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            lw = LayerWeights(intent_weight=0.75, qualifier_weight=0.5)
            lw.save(path, metadata={"test": True})
            lw2 = LayerWeights.load(path)
            self.assertAlmostEqual(lw2.intent_weight, 0.75)
            self.assertAlmostEqual(lw2.qualifier_weight, 0.5)
        finally:
            os.unlink(path)

    def test_from_dict_ignores_unknown_keys(self):
        d = {"bm25_base": 1.0, "unknown_future_key": 99}
        lw = LayerWeights.from_dict(d)
        self.assertEqual(lw.bm25_base, 1.0)
        self.assertFalse(hasattr(lw, "unknown_future_key"))


class TestMetricFunctions(unittest.TestCase):

    def test_f_at_k_perfect(self):
        # k=2: top-2 retrieved = {"a","b"}, expected = {"a","b"} → precision=recall=1.0
        self.assertEqual(f_at_k(["a", "b", "c"], ["a", "b"], k=2), 1.0)

    def test_f_at_k_zero(self):
        self.assertEqual(f_at_k(["x", "y"], ["a", "b"], k=2), 0.0)

    def test_f_at_k_partial(self):
        score = f_at_k(["a", "x", "b"], ["a", "b", "c"], k=3)
        self.assertGreater(score, 0.0)
        self.assertLess(score, 1.0)

    def test_f_at_k_empty_expected(self):
        # Edge case: no expected results
        self.assertEqual(f_at_k([], [], k=5), 1.0)

    def test_mrr_first_result_relevant(self):
        self.assertAlmostEqual(mean_reciprocal_rank(["a", "b"], ["a"]), 1.0)

    def test_mrr_second_result_relevant(self):
        self.assertAlmostEqual(mean_reciprocal_rank(["x", "a"], ["a"]), 0.5)

    def test_mrr_not_found(self):
        self.assertEqual(mean_reciprocal_rank(["x", "y"], ["a"]), 0.0)


class TestLayerCalibrator(unittest.TestCase):

    def setUp(self):
        # Build a tiny search engine + corpus for calibration tests
        self.memories = [
            make_entry("Jason approved the budget on 2026-01-15", hash_="ca1",
                       session_id="*"),
            make_entry("The deployment succeeded after three attempts", hash_="ca2",
                       session_id="*"),
            make_entry("We decided to cut MiniLM from the roadmap", hash_="ca3",
                       session_id="*"),
            make_entry("AWS infrastructure costs increased in Q4", hash_="ca4",
                       session_id="*"),
        ]
        self.engine = SearchEngine()
        self.engine.build_index(self.memories)
        self.test_cases = [
            {
                "query": "Jason budget approval",
                "expected_hashes": ["ca1"],
                "k": 3,
            },
            {
                "query": "deployment success",
                "expected_hashes": ["ca2"],
                "k": 3,
            },
        ]
        self.calibrator = LayerCalibrator()

    def test_evaluate_returns_four_metrics(self):
        def search_fn(q, limit=10):
            return self.engine.search(q, self.memories, limit=limit,
                                      session_id="*")
        f1, f3, f5, mrr = self.calibrator.evaluate(self.test_cases, search_fn)
        self.assertGreaterEqual(f1, 0.0)
        self.assertLessEqual(f1, 1.0)
        self.assertGreaterEqual(mrr, 0.0)

    def test_evaluate_empty_test_cases(self):
        def search_fn(q, limit=10):
            return []
        f1, f3, f5, mrr = self.calibrator.evaluate([], search_fn)
        self.assertEqual((f1, f3, f5, mrr), (0.0, 0.0, 0.0, 0.0))

    def test_calibrate_returns_weights_and_score(self):
        # Use a tiny grid to keep test fast
        tiny_grid = {
            "exact_phrase_bonus": [1.5, 2.0],
            "tag_boost": [1.2, 1.4],
        }
        best_weights, best_score = self.calibrator.calibrate(
            test_cases=self.test_cases,
            search_engine=self.engine,
            memories=self.memories,
            param_grid=tiny_grid,
        )
        self.assertIsInstance(best_weights, LayerWeights)
        self.assertGreaterEqual(best_score, 0.0)
        self.assertLessEqual(best_score, 1.0)

    def test_save_config_creates_file(self):
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            lw = LayerWeights()
            self.calibrator.save_config(path, lw, score=0.85, test_case_count=2)
            self.assertTrue(os.path.exists(path))
            with open(path) as fh:
                data = json.load(fh)
            self.assertIn("weights", data)
            self.assertIn("metadata", data)
            self.assertEqual(data["metadata"]["calibration_score"], 0.85)
        finally:
            os.unlink(path)

    def test_load_config_round_trip(self):
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            lw = LayerWeights(intent_weight=0.6)
            self.calibrator.save_config(path, lw, score=0.7)
            lw2 = LayerCalibrator.load_config(path)
            self.assertAlmostEqual(lw2.intent_weight, 0.6)
        finally:
            os.unlink(path)


# ═══════════════════════════════════════════════════════════════════════════
# Layer 5 Enhancement — Positional Salience
# ═══════════════════════════════════════════════════════════════════════════

class TestPositionalSalience(unittest.TestCase):

    def _run_search(self, positional_boost, use_windows=True):
        memories = [
            make_entry("Project kickoff: Jason presented the vision", hash_="ps1",
                       session_id="*"),
            make_entry("Mid-sprint review discussed memory architecture", hash_="ps2",
                       session_id="*"),
            make_entry("Mid-sprint retrospective covered deployment issues", hash_="ps3",
                       session_id="*"),
            make_entry("Final conclusion: ship antaris-memory v5 next week", hash_="ps4",
                       session_id="*"),
        ]
        engine = SearchEngine()
        results = engine.search(
            "project ship vision",
            memories=memories,
            session_id="*",
            use_windows=use_windows,
            positional_boost=positional_boost,
            use_layer7=False,
            use_layer8=False,
            use_layer9=False,
        )
        return results

    def test_positional_boost_returns_results(self):
        results = self._run_search(positional_boost=1.3)
        self.assertGreater(len(results), 0)

    def test_positional_boost_disabled_still_works(self):
        # boost=1.0 means no positional effect — should still return results
        results = self._run_search(positional_boost=1.0)
        self.assertGreater(len(results), 0)


# ═══════════════════════════════════════════════════════════════════════════
# Integration — SearchEngine with all new layer toggles
# ═══════════════════════════════════════════════════════════════════════════

class TestSearchEngineLayerToggles(unittest.TestCase):

    def setUp(self):
        self.memories = [
            make_entry("Jason approved the Spark pricing on 2026-01-10", hash_="i1",
                       session_id="*", tags=["pricing"]),
            make_entry("We decided to cut MiniLM from the roadmap", hash_="i2",
                       session_id="*", tags=["roadmap"]),
            make_entry("Before launch we finalized the API design", hash_="i3",
                       session_id="*", tags=["api"]),
            make_entry("After launch the metrics looked great", hash_="i4",
                       session_id="*", tags=["metrics"]),
            make_entry("Jason reviewed the infrastructure budget", hash_="i5",
                       session_id="*", tags=["budget"]),
        ]
        self.engine = SearchEngine()

    def _search(self, query, **kwargs):
        defaults = dict(session_id="*", limit=5)
        defaults.update(kwargs)
        return self.engine.search(query, self.memories, **defaults)

    def test_all_layers_enabled_returns_results(self):
        results = self._search("Jason approved pricing",
                               use_layer7=True, use_layer8=True, use_layer9=True)
        self.assertGreater(len(results), 0)

    def test_all_layers_disabled_still_returns_results(self):
        results = self._search("Jason approved pricing",
                               use_layer7=False, use_layer8=False, use_layer9=False)
        self.assertGreater(len(results), 0)

    def test_layer7_toggle_changes_order(self):
        # Temporal query: L7 should boost dated memories
        query = "when did Jason approve pricing"
        with_l7 = self._search(query, use_layer7=True, use_layer8=False, use_layer9=False)
        without_l7 = self._search(query, use_layer7=False, use_layer8=False, use_layer9=False)
        # Both return results; with L7, i1 (has date) should rank higher
        self.assertGreater(len(with_l7), 0)
        self.assertGreater(len(without_l7), 0)

    def test_layer8_toggle(self):
        # Before/after qualifier — L8 should differentiate i3 vs i4
        with_l8 = self._search("what happened before launch",
                               use_layer7=False, use_layer8=True, use_layer9=False)
        self.assertGreater(len(with_l8), 0)

    def test_layer9_toggle(self):
        # With clustering: Jason memories (i1, i5) should boost each other
        with_l9 = self._search("Jason budget",
                               use_layer7=False, use_layer8=False, use_layer9=True)
        self.assertGreater(len(with_l9), 0)

    def test_search_results_are_searchresult_objects(self):
        results = self._search("pricing", use_layer7=True, use_layer8=True, use_layer9=True)
        for r in results:
            self.assertTrue(hasattr(r, "score"))
            self.assertTrue(hasattr(r, "relevance"))
            self.assertTrue(hasattr(r, "entry"))
            self.assertTrue(hasattr(r, "matched_terms"))

    def test_results_sorted_by_score_descending(self):
        results = self._search("Jason", use_layer7=True, use_layer8=True, use_layer9=True)
        scores = [r.score for r in results]
        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_stats_includes_cluster_info(self):
        # Trigger an index build by running a search
        self._search("pricing")
        stats = self.engine.stats()
        self.assertIn("clusters", stats)
        self.assertIn("built", stats["clusters"])

    def test_layer9_cluster_built_after_index(self):
        self._search("pricing")
        self.assertTrue(self.engine._cluster_index._built)

    def test_bypass_flags_all_combinations(self):
        """Smoke test: all 8 toggle combinations should return results without error."""
        query = "Jason pricing roadmap"
        for l7 in (True, False):
            for l8 in (True, False):
                for l9 in (True, False):
                    results = self._search(
                        query, use_layer7=l7, use_layer8=l8, use_layer9=l9
                    )
                    self.assertIsInstance(results, list,
                        f"Failed for L7={l7} L8={l8} L9={l9}")


if __name__ == "__main__":
    unittest.main()
