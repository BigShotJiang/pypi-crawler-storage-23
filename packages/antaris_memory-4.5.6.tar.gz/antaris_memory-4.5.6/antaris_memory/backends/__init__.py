"""
antaris_memory.backends — pluggable storage backends for MemorySystem.

Available backends:
- GCSMemoryBackend: Google Cloud Storage (stub, full impl in v4.3.0)
"""

from .gcs import GCSMemoryBackend

__all__ = ["GCSMemoryBackend"]
