"""
Score Calibration — antaris-memory v5.0.0 (Layer 10).

Offline tool that optimizes layer weights for the search pipeline.
Takes labeled query→memory pairs, runs a grid search over weight
combinations, and outputs an optimized JSON config.

This module has ZERO runtime cost — it produces a config file that
the search pipeline loads at startup.

Usage
-----
    from calibration import LayerCalibrator

    # Define labeled test cases
    test_cases = [
        {
            "query": "when did Jason approve pricing",
            "expected_hashes": ["abc123", "def456"],
            "k": 3,
        },
        ...
    ]

    calibrator = LayerCalibrator()
    best_weights, best_score = calibrator.calibrate(
        test_cases=test_cases,
        search_engine=engine,
        memories=memories,
    )
    calibrator.save_config("calibration_config.json", best_weights, best_score)

Zero external dependencies.
"""

from __future__ import annotations

import json
import itertools
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Weight configuration
# ---------------------------------------------------------------------------

@dataclass
class LayerWeights:
    """Weight configuration for search pipeline layers.

    Each weight is a multiplier applied to the layer's contribution.
    A weight of 0.0 effectively disables the layer.
    A weight of 1.0 means default/unmodified contribution.
    """
    # Core scoring layers (Layers 1-4 are intertwined in _score_entry)
    bm25_base: float = 1.0
    exact_phrase_bonus: float = 1.5
    tag_boost: float = 1.2
    source_boost: float = 1.1
    category_boost: float = 1.3
    rarity_enabled: bool = True
    proper_noun_boost: float = 1.5
    # Post-scoring layers
    window_weight: float = 1.0
    intent_weight: float = 1.0
    qualifier_weight: float = 1.0
    cluster_boost: float = 0.15
    # Positional salience (Layer 5 enhancement)
    positional_first_boost: float = 1.3
    positional_last_boost: float = 1.3

    def to_dict(self) -> Dict[str, Any]:
        return {
            "bm25_base": self.bm25_base,
            "exact_phrase_bonus": self.exact_phrase_bonus,
            "tag_boost": self.tag_boost,
            "source_boost": self.source_boost,
            "category_boost": self.category_boost,
            "rarity_enabled": self.rarity_enabled,
            "proper_noun_boost": self.proper_noun_boost,
            "window_weight": self.window_weight,
            "intent_weight": self.intent_weight,
            "qualifier_weight": self.qualifier_weight,
            "cluster_boost": self.cluster_boost,
            "positional_first_boost": self.positional_first_boost,
            "positional_last_boost": self.positional_last_boost,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "LayerWeights":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})

    @classmethod
    def load(cls, path: str) -> "LayerWeights":
        """Load weights from a JSON config file."""
        with open(path, 'r') as f:
            data = json.load(f)
        return cls.from_dict(data.get("weights", data))

    def save(self, path: str, metadata: Optional[Dict] = None) -> None:
        """Save weights to a JSON config file."""
        output = {
            "weights": self.to_dict(),
            "metadata": metadata or {},
        }
        with open(path, 'w') as f:
            json.dump(output, f, indent=2)


# ---------------------------------------------------------------------------
# Evaluation metrics
# ---------------------------------------------------------------------------

def f_at_k(retrieved_hashes: List[str], expected_hashes: List[str], k: int) -> float:
    """Compute F-score at K (F@K).

    Parameters
    ----------
    retrieved_hashes : list[str]
        Ordered list of memory hashes returned by search.
    expected_hashes : list[str]
        Ground-truth memory hashes that should be retrieved.
    k : int
        Evaluate only the top-K retrieved results.

    Returns
    -------
    float
        F1 score between retrieved top-K and expected, in [0.0, 1.0].
    """
    if not expected_hashes:
        return 1.0 if not retrieved_hashes[:k] else 0.0

    top_k = set(retrieved_hashes[:k])
    expected = set(expected_hashes)

    true_positives = len(top_k & expected)
    if true_positives == 0:
        return 0.0

    precision = true_positives / len(top_k) if top_k else 0.0
    recall = true_positives / len(expected)

    return 2 * (precision * recall) / (precision + recall)


def mean_reciprocal_rank(retrieved_hashes: List[str], expected_hashes: List[str]) -> float:
    """Compute MRR — reciprocal of the rank of the first relevant result."""
    expected = set(expected_hashes)
    for i, h in enumerate(retrieved_hashes):
        if h in expected:
            return 1.0 / (i + 1)
    return 0.0


# ---------------------------------------------------------------------------
# Calibrator
# ---------------------------------------------------------------------------

@dataclass
class CalibrationResult:
    """Result of a single weight configuration evaluation."""
    weights: Dict[str, Any]
    f_at_1: float
    f_at_3: float
    f_at_5: float
    mrr: float
    combined_score: float


class LayerCalibrator:
    """Offline weight optimizer for the search pipeline.

    Runs a grid search over configurable weight ranges and evaluates
    each combination against labeled test cases.

    Parameters
    ----------
    metric_weights : dict, optional
        How to combine F@1, F@3, F@5, MRR into a single score.
        Default: {"f1": 0.4, "f3": 0.25, "f5": 0.15, "mrr": 0.2}
    """

    def __init__(
        self,
        metric_weights: Optional[Dict[str, float]] = None,
    ) -> None:
        self.metric_weights = metric_weights or {
            "f1": 0.40,
            "f3": 0.25,
            "f5": 0.15,
            "mrr": 0.20,
        }

    def evaluate(
        self,
        test_cases: List[Dict],
        search_fn: Callable,
    ) -> Tuple[float, float, float, float]:
        """Evaluate a search function against labeled test cases.

        Parameters
        ----------
        test_cases : list[dict]
            Each dict has: query (str), expected_hashes (list[str]),
            and optionally k (int, default 5).
        search_fn : callable
            Function(query: str, limit: int) → list of SearchResult.

        Returns
        -------
        tuple of (avg_f1, avg_f3, avg_f5, avg_mrr)
        """
        total_f1, total_f3, total_f5, total_mrr = 0.0, 0.0, 0.0, 0.0
        n = len(test_cases)

        if n == 0:
            return 0.0, 0.0, 0.0, 0.0

        for case in test_cases:
            query = case["query"]
            expected = case["expected_hashes"]
            limit = case.get("k", 10)

            results = search_fn(query, limit=max(limit, 10))
            retrieved = [
                getattr(r.entry, 'hash', getattr(r, 'hash', ''))
                for r in results
            ]

            total_f1 += f_at_k(retrieved, expected, 1)
            total_f3 += f_at_k(retrieved, expected, 3)
            total_f5 += f_at_k(retrieved, expected, 5)
            total_mrr += mean_reciprocal_rank(retrieved, expected)

        return total_f1 / n, total_f3 / n, total_f5 / n, total_mrr / n

    def _combined_score(self, f1: float, f3: float, f5: float, mrr: float) -> float:
        """Combine metrics into a single optimization target."""
        w = self.metric_weights
        return (
            w.get("f1", 0.4) * f1
            + w.get("f3", 0.25) * f3
            + w.get("f5", 0.15) * f5
            + w.get("mrr", 0.2) * mrr
        )

    def calibrate(
        self,
        test_cases: List[Dict],
        search_engine: Any,
        memories: list,
        param_grid: Optional[Dict[str, List]] = None,
        session_id: str = "*",
        agent_id: Optional[str] = None,
    ) -> Tuple[LayerWeights, float]:
        """Run grid search to find optimal layer weights.

        Parameters
        ----------
        test_cases : list[dict]
            Labeled query→memory pairs.
        search_engine : SearchEngine
            The search engine instance to evaluate.
        memories : list
            Full memory corpus.
        param_grid : dict, optional
            Maps parameter names to lists of values to try.
            Default grid covers the most impactful parameters.
        session_id, agent_id :
            Passed through to search calls.

        Returns
        -------
        tuple of (best_weights: LayerWeights, best_score: float)
        """
        if param_grid is None:
            param_grid = {
                "exact_phrase_bonus": [1.2, 1.5, 1.8, 2.0],
                "tag_boost": [1.0, 1.2, 1.4],
                "category_boost": [1.0, 1.3, 1.5],
                "proper_noun_boost": [1.0, 1.5, 2.0],
                "intent_weight": [0.5, 0.75, 1.0, 1.25],
                "qualifier_weight": [0.5, 0.75, 1.0],
                "cluster_boost": [0.0, 0.10, 0.15, 0.20],
            }

        param_names = list(param_grid.keys())
        param_values = list(param_grid.values())
        combinations = list(itertools.product(*param_values))

        logger.info(
            f"Calibration: {len(combinations)} weight combinations "
            f"x {len(test_cases)} test cases"
        )

        best_score = -1.0
        best_weights = LayerWeights()
        all_results: List[CalibrationResult] = []

        start_time = time.time()

        for i, combo in enumerate(combinations):
            weights = LayerWeights()
            for name, value in zip(param_names, combo):
                setattr(weights, name, value)

            def make_search_fn(w):
                def search_fn(query: str, limit: int = 20):
                    return search_engine.search(
                        query=query,
                        memories=memories,
                        limit=limit,
                        session_id=session_id,
                        agent_id=agent_id,
                    )
                return search_fn

            search_fn = make_search_fn(weights)
            f1, f3, f5, mrr = self.evaluate(test_cases, search_fn)
            combined = self._combined_score(f1, f3, f5, mrr)

            result = CalibrationResult(
                weights=weights.to_dict(),
                f_at_1=round(f1, 4),
                f_at_3=round(f3, 4),
                f_at_5=round(f5, 4),
                mrr=round(mrr, 4),
                combined_score=round(combined, 4),
            )
            all_results.append(result)

            if combined > best_score:
                best_score = combined
                best_weights = weights
                logger.info(
                    f"  [{i+1}/{len(combinations)}] New best: "
                    f"F@1={f1:.3f} F@3={f3:.3f} F@5={f5:.3f} "
                    f"MRR={mrr:.3f} combined={combined:.4f}"
                )

        elapsed = time.time() - start_time
        logger.info(
            f"Calibration complete in {elapsed:.1f}s — "
            f"best combined score: {best_score:.4f}"
        )

        return best_weights, best_score

    def save_config(
        self,
        path: str,
        weights: LayerWeights,
        score: float,
        test_case_count: int = 0,
    ) -> None:
        """Save calibration results to a JSON config file."""
        weights.save(path, metadata={
            "calibration_score": round(score, 4),
            "test_cases_used": test_case_count,
            "metric_weights": self.metric_weights,
            "generated_by": "antaris-memory LayerCalibrator v5.0.0",
        })
        logger.info(f"Calibration config saved to {path}")

    @staticmethod
    def load_config(path: str) -> LayerWeights:
        """Load a previously saved calibration config."""
        return LayerWeights.load(path)
