"""Entry point for: python -m ai_pipeline_core.observability download <execution_id>."""

from .cli import main

raise SystemExit(main())
