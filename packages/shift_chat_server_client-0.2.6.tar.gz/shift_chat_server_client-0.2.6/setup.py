from setuptools import setup, find_packages

setup(
    name="shift-chat-server-client",
    version="0.2.2",
    description="A Python client for the Shift Chat Server",
    author="Clipboard Health",
    author_email="lucas.pedroso@clipboardhealth.com",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "requests>=2.28.0",
        "requests-toolbelt>=0.10.1", # useful for multipart uploads if we add file upload later
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "flake8>=6.0.0",
            "black>=23.0.0",
        ],
    },
    python_requires=">=3.7",
)
