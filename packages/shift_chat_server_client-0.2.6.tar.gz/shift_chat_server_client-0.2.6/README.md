# Shift Chat Server Client

Python client for interacting with the Shift Chat Server.

## Installation

```bash
pip install .
```

## Usage

### Initialization

```python
from shift_chat.client import ShiftChatClient

# Initialize the client with your credentials
client = ShiftChatClient(
    client_id="your-client-id",
    client_secret="your-client-secret"
)

# Authenticate (optional, methods will auto-authenticate if needed)
client.authenticate()
```

### Managing Users

You can create or update users using the `set_user` method. You must provide either an email address OR a phone number (or both). You can also provide a `reference_id` to map to your own system's user IDs.

**Create/Update user with Email:**

```python
user = client.set_user(
    first_name="John",
    last_name="Doe",
    password="securePassword123",
    email="john.doe@example.com"
)
print(f"Created user: {user['id']}")
```

**Create/Update user with Phone Number:**

```python
user = client.set_user(
    first_name="Jane",
    last_name="Smith",
    password="securePassword123",
    phone_number="+15550123456"
)
print(f"Created user: {user['id']}")
```

**Create/Update user with Reference ID:**

This is useful for mapping users from your system to Shift Chat users.

```python
user = client.set_user(
    first_name="Alice",
    last_name="Wonder",
    password="securePassword123",
    email="alice@example.com",
    reference_id="your-system-user-id-123"
)
```

**Get User by Reference ID:**

```python
user = client.get_user_by_reference_id("your-system-user-id-123")
if user:
    print(f"Found user: {user['id']}")
else:
    print("User not found")
```

### Managing Workspaces and Channels

You can add users to workspaces and channels using their IDs.

**Add User to Workspace:**

```python
client.add_user_to_workspace(
    user_id="user-uuid-123",
    workspace_id="workspace-uuid-456"
)
```

**Add User to Channel:**

```python
client.add_user_to_channel(
    user_id="user-uuid-123",
    channel_id="channel-uuid-789"
)
```

### Acting on Behalf of a User

Once a user exists, you can perform actions on their behalf using `authenticate_user`.

```python
# Get a user-specific client
user_client = client.authenticate_user(user_id="user-uuid-123")

# List workspaces the user belongs to
workspaces = user_client.get_workspaces()
for ws in workspaces:
    print(f"Workspace: {ws['name']}")

# List workspaces with channels (formatted for mobile app)
workspaces_with_channels = user_client.get_workspaces_with_channels()

# Create a channel
channel = user_client.set_channel(
    workspace_id="workspace-uuid-123",
    name="general-discussion",
    is_public=True
)
```
