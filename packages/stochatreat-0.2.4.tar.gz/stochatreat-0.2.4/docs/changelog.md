# Changelog

Release notes are maintained in [GitHub Releases](https://github.com/manmartgarc/stochatreat/releases).
