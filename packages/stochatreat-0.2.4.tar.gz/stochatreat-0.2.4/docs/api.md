# API Reference

::: stochatreat.stochatreat
