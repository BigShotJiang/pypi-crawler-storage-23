# @minecraft/vanilla-data version: 1.21.130
