# VoiceMQTT

MQTT-activated voice transcription to clipboard with real-time audio level display.

## Overview

VoiceMQTT listens for activation messages via MQTT or keyboard input, records audio from your microphone, transcribes it using OpenAI's Whisper (via faster-whisper), and copies the result to your clipboard.

## Features

- **Dual Activation**: Trigger via MQTT messages OR keyboard commands
- **Real-time Audio Display**: Visual audio level meter during recording
- **Automatic Silence Detection**: Recording stops automatically after silence
- **Interactive Menu**: Adjust settings on-the-fly without restarting
- **Noise Calibration**: Measure ambient noise for optimal threshold
- **Clipboard/Paste Toggle**: Choose between copy-only or copy+paste modes
- **Local Whisper**: All transcription happens locally - no cloud services

## Installation

### System Dependencies

```bash
sudo apt install portaudio19-dev wl-clipboard
```

Optional (for paste functionality):
```bash
sudo apt install ydotool
```

### Python Package

```bash
pip install jusfltuls
```

Or from source:
```bash
pip install -e .
```

## Usage

### Basic Usage

```bash
# Connect to local MQTT broker (default)
voicemqtt

# Run without MQTT (keyboard-only mode)
voicemqtt --no-mqtt

# Use custom MQTT broker
voicemqtt --mqtt-host 192.168.1.5 --mqtt-port 1883

# Use public MQTT from config file
voicemqtt --public-mqtt
```

### Interactive Menu

While running, the following keys are available:

| Key | Action |
|-----|--------|
| `q` | Quit the program |
| `r` | Start recording immediately |
| `n` | Measure ambient noise (suggests threshold) |
| `c` | Toggle clipboard/paste mode |
| `d` | Decrease silence threshold (more sensitive) |
| `u` | Increase silence threshold (less sensitive) |

The menu displays the current threshold value and paste mode status.

### Calibration

Measure your ambient noise level for optimal silence detection:

```bash
# Quick noise measurement via menu (press 'n')
# Or use calibration mode:
voicemqtt --calibrate
```

### Command Line Options

```bash
voicemqtt [OPTIONS]

Options:
  --mqtt-host TEXT              MQTT broker host (default: localhost)
  --mqtt-port INTEGER           MQTT broker port (default: 1883)
  --mqtt-topic TEXT             MQTT activation topic (default: voicemqtt/activate)
  --mqtt-user TEXT              MQTT username
  --mqtt-pass TEXT              MQTT password
  --mqtt-tls                    Enable TLS/SSL for MQTT
  --mqtt-ca-certs TEXT          Path to CA certificates
  --public-mqtt                 Use MQTT from ~/.config/influxdb/totalconfig.conf
  --recording-status-topic TEXT Topic for recording status updates
  --model TEXT                  Whisper model: tiny, base, small, medium, large-v1/v2/v3 (default: base)
  --device TEXT                 Device: cpu, cuda (default: cpu)
  --language TEXT               Language code: en, cs, de, auto (default: en)
  --silence-threshold FLOAT     Audio threshold for silence (default: 0.15)
  --silence-duration FLOAT      Seconds of silence before stopping (default: 3.0)
  --single                      Run once and exit
  --calibrate                   Calibrate silence threshold
  --paste                       Also paste transcription using ydotool
  --no-mqtt                     Run without MQTT broker
  --version                     Show version
  --help                        Show help
```

## MQTT Integration

### Activation Topics

VoiceMQTT listens for messages on the configured topic. These payloads trigger recording:

- `record`
- `start`
- `on`
- `1`
- `true`
- `yes`

### Status Topics

Recording status is published to the status topic:

- `2` - Recording with sound detected
- `1` - Recording with silence detected
- `0` - Idle/not recording

### Example MQTT Commands

```bash
# Trigger recording
mosquitto_pub -t voicemqtt/activate -m "record"

# Check status
mosquitto_sub -t voicemqtt/recording
```

## Configuration

### Public MQTT Config

Create `~/.config/influxdb/totalconfig.conf`:

```ini
[mqtt public]
server = mqtt.example.com:8883
username = your_username
password = your_password
```

Use with: `voicemqtt --public-mqtt`

## Tips

1. **Threshold Tuning**: If recording stops too early, press 'u' to increase threshold. If it keeps recording background noise, press 'd' to decrease it.

2. **Noise Measurement**: Press 'n' in a quiet room to automatically set an appropriate threshold based on your ambient noise.

3. **Paste Mode**: Toggle with 'c' - when ON, transcription is automatically typed into the active window (requires ydotool).

4. **Color Coding**: During recording, audio bars are cyan when below threshold, transitioning to dim/green/yellow/red as volume increases.

## Troubleshooting

### PortAudio Error

```
Error: PortAudio library not found!
```

Install portaudio:
```bash
sudo apt install portaudio19-dev
```

### MQTT Connection Failed

```
Failed to connect to MQTT broker
```

Run without MQTT:
```bash
voicemqtt --no-mqtt
```

Or check your broker settings and network connection.

### Clipboard Not Working

```bash
sudo apt install wl-clipboard
```

### ydotool Permission Issues

```bash
sudo usermod -aG input $USER
echo 'KERNEL=="uinput", MODE="0660", GROUP="input"' | sudo tee /etc/udev/rules.d/99-uinput.rules
sudo udevadm control --reload-rules && sudo udevadm trigger
```

Then log out and back in.

## License

Part of jusfltuls - Useful tools for Linux life.
