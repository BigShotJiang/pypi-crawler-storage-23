#!/usr/bin/env python3
"""Wrapper module for login-notify install command."""

import subprocess
import sys
from pathlib import Path


def install():
    """Entry point for login-notify-install command."""
    script_path = Path(__file__).parent / "login-notify.py"
    result = subprocess.run([sys.executable, str(script_path), "install"])
    sys.exit(result.returncode)


if __name__ == "__main__":
    install()
