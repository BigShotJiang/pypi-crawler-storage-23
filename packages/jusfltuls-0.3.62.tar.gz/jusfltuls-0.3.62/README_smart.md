# NVMe Utility Support Implementation

## Overview
This implementation adds support for NVMe disks using the `nvme` CLI utility as a fallback when smartctl logs/tests are not available or don't work properly on certain NVMe drives.

## Files Modified

### 1. `src/jusfltuls/shell_calls.py`
Added NVMe CLI command builders:
- `build_nvme_smart_log(device)` - Get SMART log via `nvme smart-log`
- `build_nvme_self_test_log(device)` - Get self-test log via `nvme self-test-log`
- `build_nvme_start_self_test(device, test_type)` - Start self-test (1=short, 2=extended)

### 2. `src/jusfltuls/nvme_cli.py` (NEW)
New module for NVMe CLI parsing:
- `parse_nvme_smart_log(output)` - Extracts health status and power-on hours
- `parse_nvme_self_test_log(output, power_on_hours)` - Parses test history and progress
- `is_nvme_device(device)` - Detects NVMe devices by path
- `check_nvme_cli_available()` - Verifies nvme command is installed

### 3. `src/jusfltuls/smartctl.py`
Modified SmartHealthMonitor class:
- `get_disk_health()` - Routes NVMe devices to nvme-cli, others to smartctl
- `_get_nvme_disk_health()` - New method using nvme-cli exclusively
- `_get_smartctl_disk_health()` - Original smartctl method (non-NVMe)
- `start_short_test()` - Uses nvme-cli for NVMe devices
- `start_long_test()` - Uses nvme-cli for NVMe devices

### 4. `src/jusfltuls/smartnow.py`
Added startup checks and dependencies:
- `check_nvme_tools(disks)` - Warns if NVMe devices present but nvme-cli missing
- Updated `check_sudo_access()` to include nvme command
- Updated sudoers configuration examples to include `/usr/sbin/nvme`

## Behavior

### NVMe Disks
- **Preferred tool**: `nvme` CLI utility
- **Commands used**:
  - Health: `nvme smart-log /dev/nvmeXnY`
  - Test log: `nvme self-test-log /dev/nvmeXnY`
  - Short test: `nvme self-test /dev/nvmeXnY --test-type=1`
  - Long test: `nvme self-test /dev/nvmeXnY --test-type=2`
- **If nvme-cli fails**: Displays "N/A" in left disk panel

### Non-NVMe Disks
- **Tool**: smartctl (unchanged behavior)
- **Commands**: smartctl -x, smartctl -l selftest, smartctl -t short/long

## Dependencies

### Required Package
```bash
# Debian/Ubuntu
sudo apt install nvme-cli

# RHEL/CentOS/Fedora
sudo yum install nvme-cli

# Arch Linux
sudo pacman -S nvme-cli
```

### Sudo Configuration
Add to `/etc/sudoers`:
```
myuser ALL=(ALL) NOPASSWD: /usr/sbin/smartctl, /usr/bin/btrfs, /usr/bin/snapper, /usr/sbin/nvme
```

Or create a sudoers drop-in:
```bash
echo "USERNAME ALL=(ALL) NOPASSWD: /usr/sbin/smartctl, /usr/bin/btrfs, /usr/bin/snapper, /usr/sbin/nvme" | sudo tee /etc/sudoers.d/diskmanager
```

## Implementation Notes

1. **Automatic Detection**: NVMe devices are detected by checking if the device path contains "nvme"
2. **Graceful Fallback**: If nvme-cli fails or is unavailable, the UI shows "N/A" rather than crashing
3. **Startup Warning**: Users are warned at startup if NVMe devices are present but nvme-cli is not installed
4. **Test Types**: nvme-cli uses numeric codes (1=short, 2=extended) vs smartctl's named options

## Limitations

- Model name is not available from `nvme smart-log` (shown as None in health info)
- Some NVMe disks may still not support all nvme-cli features
- nvme-cli must be installed and available in PATH
