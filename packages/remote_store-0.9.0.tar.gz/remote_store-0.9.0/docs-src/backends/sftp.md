{%
   include-markdown "../../guides/backends/sftp.md"
   rewrite-relative-urls=false
%}

## API Reference

::: remote_store.backends.SFTPBackend
