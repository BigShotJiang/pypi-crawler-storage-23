{%
   include-markdown "../../guides/backends/s3-pyarrow.md"
   rewrite-relative-urls=false
%}

## API Reference

::: remote_store.backends.S3PyArrowBackend
