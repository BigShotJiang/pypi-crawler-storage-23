# Errors

::: remote_store.RemoteStoreError

::: remote_store.NotFound

::: remote_store.AlreadyExists

::: remote_store.PermissionDenied

::: remote_store.InvalidPath

::: remote_store.CapabilityNotSupported

::: remote_store.BackendUnavailable
