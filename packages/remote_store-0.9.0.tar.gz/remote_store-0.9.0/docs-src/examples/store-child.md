# Store.child()

Runtime sub-scoping: create child stores that share a backend but isolate paths.

```python
--8<-- "examples/store_child.py"
```
