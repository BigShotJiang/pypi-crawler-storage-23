# Streaming I/O

Streaming writes and reads with `BytesIO`.

```python
--8<-- "examples/streaming_io.py"
```
