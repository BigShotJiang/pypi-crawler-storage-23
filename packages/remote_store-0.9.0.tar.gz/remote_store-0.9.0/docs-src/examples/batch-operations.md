# Batch Operations

Bulk delete, copy, and existence checks with error aggregation.

```python
--8<-- "examples/batch_operations.py"
```
