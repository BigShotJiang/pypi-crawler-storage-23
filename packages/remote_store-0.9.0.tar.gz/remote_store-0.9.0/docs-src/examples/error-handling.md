# Error Handling

Catching `NotFound`, `AlreadyExists`, and more.

```python
--8<-- "examples/error_handling.py"
```
