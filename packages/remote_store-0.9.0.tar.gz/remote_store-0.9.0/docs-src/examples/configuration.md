# Configuration

Config-as-code, `from_dict()`, multiple stores, S3/SFTP backend configs.

```python
--8<-- "examples/configuration.py"
```
