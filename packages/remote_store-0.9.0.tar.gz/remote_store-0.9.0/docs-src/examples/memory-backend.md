# Memory Backend

In-process memory backend for testing and caching -- no filesystem access needed.

```python
--8<-- "examples/memory_backend.py"
```
