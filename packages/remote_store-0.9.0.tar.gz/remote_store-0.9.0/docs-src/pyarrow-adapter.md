{%
   include-markdown "../guides/pyarrow-adapter.md"
   rewrite-relative-urls=false
%}
