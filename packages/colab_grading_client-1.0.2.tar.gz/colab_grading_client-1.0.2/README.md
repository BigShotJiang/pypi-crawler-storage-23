# colab_grading_client
colab notebook functions to invoke AI teaching and grading assistant

To (re) build the package:
rm -rf dist/
python -m build
twine upload --repository testpypi dist/* 
