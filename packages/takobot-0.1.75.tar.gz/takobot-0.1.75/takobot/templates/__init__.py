"""Engine-shipped workspace templates (copied by bootstrap)."""

