# Assumptions

## Active Assumptions

- [ ] (assumption) | confidence: low/medium/high | evidence:

## Invalidated Assumptions

- (move resolved assumptions here with rationale)
