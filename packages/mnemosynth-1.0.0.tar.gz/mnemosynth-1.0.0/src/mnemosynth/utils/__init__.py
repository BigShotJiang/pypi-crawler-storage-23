"""Utility modules — database and embeddings."""
