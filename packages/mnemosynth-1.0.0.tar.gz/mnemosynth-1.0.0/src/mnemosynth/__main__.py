"""Entry point for `python -m mnemosynth`."""

from mnemosynth.cli.commands import main

if __name__ == "__main__":
    main()
