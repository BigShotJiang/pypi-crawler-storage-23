"""Tests for SQLite database manager."""

import os
import tempfile
from mnemosynth.core.types import MemoryNode, MemoryType, MemoryStatus, RelationshipEdge
from mnemosynth.utils.db import DatabaseManager


class TestDatabaseManager:
    def setup_method(self):
        self.tmp = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmp, "test.db")
        self.db = DatabaseManager(self.db_path)

    def test_save_and_get(self):
        node = MemoryNode.create(content="Test memory", memory_type=MemoryType.SEMANTIC)
        self.db.save_memory(node)

        retrieved = self.db.get_memory(node.id)
        assert retrieved is not None
        assert retrieved.content == "Test memory"
        assert retrieved.memory_type == MemoryType.SEMANTIC

    def test_count(self):
        assert self.db.count_memories() == 0

        self.db.save_memory(MemoryNode.create(content="A", memory_type=MemoryType.EPISODIC))
        self.db.save_memory(MemoryNode.create(content="B", memory_type=MemoryType.SEMANTIC))
        self.db.save_memory(MemoryNode.create(content="C", memory_type=MemoryType.SEMANTIC))

        assert self.db.count_memories() == 3
        assert self.db.count_memories(MemoryType.SEMANTIC) == 2
        assert self.db.count_memories(MemoryType.EPISODIC) == 1

    def test_delete(self):
        node = MemoryNode.create(content="To delete")
        self.db.save_memory(node)
        assert self.db.get_memory(node.id) is not None

        self.db.delete_memory(node.id)
        assert self.db.get_memory(node.id) is None

    def test_text_search(self):
        self.db.save_memory(MemoryNode.create(content="User prefers Python"))
        self.db.save_memory(MemoryNode.create(content="User likes dark mode"))
        self.db.save_memory(MemoryNode.create(content="Project uses React"))

        results = self.db.search_memories_text("User")
        assert len(results) == 2

    def test_get_memories_filtered(self):
        self.db.save_memory(MemoryNode.create(content="A", memory_type=MemoryType.EPISODIC))
        self.db.save_memory(MemoryNode.create(content="B", memory_type=MemoryType.SEMANTIC))

        results = self.db.get_memories(memory_type=MemoryType.EPISODIC)
        assert len(results) == 1
        assert results[0].memory_type == MemoryType.EPISODIC

    def test_relationships(self):
        edge = RelationshipEdge(
            source_id="node_1",
            target_id="node_2",
            relation_type="related_to",
        )
        self.db.save_relationship(edge)

        edges = self.db.get_relationships("node_1", direction="outgoing")
        assert len(edges) == 1
        assert edges[0].relation_type == "related_to"

    def test_update_memory(self):
        node = MemoryNode.create(content="Original", confidence=0.5)
        self.db.save_memory(node)

        node.confidence = 0.9
        node.content = "Updated"
        self.db.save_memory(node)

        retrieved = self.db.get_memory(node.id)
        assert retrieved.content == "Updated"
        assert retrieved.confidence == 0.9
