
from karrio.providers.dpd_meta.shipment.create import (
    parse_shipment_response,
    shipment_request,
)
from karrio.providers.dpd_meta.shipment.return_shipment import (
    parse_return_shipment_response,
    return_shipment_request,
)
