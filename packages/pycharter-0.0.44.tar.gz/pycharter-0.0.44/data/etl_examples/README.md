# ETL Examples: CSV → Transform → CSV

Sample configs to run a simple ETL in the PyCharter UI: extract from a mock CSV, apply transforms, and load to a new CSV file.

## Files

| File | Purpose |
|------|--------|
| `input.csv` | Mock source data (products: id, name, category, price, quantity, updated_at) |
| `extract.yaml` | Extract config: read from CSV file |
| `transform.yaml` | Transform config: rename, convert types, add fields, select columns |
| `load.yaml` | Load config: write to CSV file |
| `pipeline.yaml` | Single-file pipeline (optional; for CLI/config-dir use) |
| `variables.yaml` | Variable injection: values for `${VAR}` in extract/load/transform (e.g. `INPUT_PATH`, `OUTPUT_PATH`) |
| `settings.yaml` | Shared settings: OpenLineage emission, DLQ, etc. Used when running from config dir |

## Using in the ETL UI

1. **Start the API** from the **pycharter repo root** so relative paths resolve:
   ```bash
   cd pycharter
   pycharter api
   ```
   If you run the API from another directory, use variables (step 4).

2. **Open the ETL page** in the UI and load or paste configs:
   - **Extract:** Open `data/etl_examples/extract.yaml` and paste its contents into the Extract panel (or use a template and edit path to `data/etl_examples/input.csv`).
   - **Transform:** Open `data/etl_examples/transform.yaml` and paste into the Transform panel.
   - **Load:** Open `data/etl_examples/load.yaml` and paste into the Load panel.

3. **Run the pipeline**
   - Optionally run **Dry run** first (extract + transform only, no write).
   - Click **Run** to extract, transform, and load. Output is written to `data/etl_examples/output.csv`.

4. **If the API runs from a different directory**, set variables in the UI so paths are absolute:
   - `INPUT_PATH` = full path to `input.csv` (e.g. `/Users/you/repo/pycharter/data/etl_examples/input.csv`)
   - `OUTPUT_PATH` = full path for `output.csv` (e.g. `/Users/you/repo/pycharter/data/etl_examples/output.csv`)

## Transform summary

- **Rename:** `product_id` → `id`, `product_name` → `name`, `updated_at` → `source_updated_at`
- **Convert:** `price` → float, `quantity` → int, `source_updated_at` → datetime
- **Defaults:** `category` defaults to `uncategorized` if missing
- **Add:** `processed_at` (current time), `source` (literal `etl_example`)
- **Select:** only the listed columns are written to the output CSV

## Failure examples (runs that show as failed in the dashboard)

Subdirectories under `data/etl_examples/` contain configs that produce **failed pipeline runs**. When you run them via the **API** (e.g. ETL UI or `POST /etl/run`), the run is **persisted to the dashboard** with status **failed**, so you can test how the dashboard displays failures, errors, and row counts.

| Directory | Cause of failure | Run registered? | When it fails |
|-----------|------------------|------------------|---------------|
| `fail_extract_missing_file/` | Extract path points to a file that does not exist | **Yes** (failed) | During run: extract raises `FileNotFoundError` → caught → result saved with `success: false` |
| `fail_load_invalid_write_mode/` | Load `write_mode: replace` (only `overwrite` and `append` are valid) | **Yes** (failed) | During run: load returns failure → result saved with `success: false` |
| `fail_extract_invalid_type/` | Extract `type: invalid_source` (unknown type) | **No** | At pipeline build: config validation error; run never starts |

To get runs **registered in the dashboard as failed**, run the pipeline via the **API** (start with `pycharter api`, then use the ETL UI or call `POST /api/v1/etl/run` with the extract/transform/load YAML from the failure example). Runs from the CLI are not persisted to the dashboard.

From the **pycharter repo root**:

```bash
cd pycharter
# CLI (run completes with result.success = False; dashboard not updated unless via API)
pycharter etl run data/etl_examples/fail_extract_missing_file
pycharter etl run data/etl_examples/fail_load_invalid_write_mode
```

For dashboard-visible failures: start the API, open the ETL UI, paste in the YAML from `fail_extract_missing_file/` or `fail_load_invalid_write_mode/` (extract, transform, load), and click Run. The run will appear in the dashboard with status **failed** and the error message.

---

## CLI (optional)

From the pycharter repo root, running from the config directory loads `variables.yaml` and `settings.yaml` automatically (so paths and OpenLineage are configured):

```bash
cd pycharter
python -c "
import asyncio
from pycharter.etl_generator import Pipeline
async def main():
    p = Pipeline.from_config_dir('data/etl_examples')
    r = await p.run()
    print(r)
asyncio.run(main())
"
```

Or run using the single-file pipeline:

```bash
pycharter etl run data/etl_examples/pipeline.yaml
```

(If your CLI supports `pycharter etl run` and a pipeline file; otherwise use the Python snippet above.)
