"""Pydantic models for ETL load, transform, and pipeline configuration."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from pycharter.etl_generator._config_enums import (
    ConvertType,
    FileFormat,
    FilterOperator,
    JSONataMode,
    WriteMethod,
    WriteMode,
)
from pycharter.etl_generator._config_extract import (
    CloudStorageExtractConfig,
    DatabaseExtractConfig,
    ExtractConfig,
    FileExtractConfig,
    FileWatcherExtractConfig,
    HTTPExtractConfig,
    KafkaExtractConfig,
    RabbitMQExtractConfig,
    SQSExtractConfig,
    SSEExtractConfig,
    WebSocketExtractConfig,
)
from pycharter.etl_generator._config_settings import (
    LineageConfig,
    SettingsConfig,
)
from pycharter.etl_generator._config_shared import (
    CloudStorageConfig,
    CSVOptions,
    DatabaseConfig,
    DLQConfig,
    JSONOptions,
    LoadValidationConfig,
    MetadataStoreConfig,
    SSHTunnelConfig,
)

# =============================================================================
# LOAD CONFIGS
# =============================================================================


class PostgresLoadConfig(BaseModel):
    """PostgreSQL load configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["postgres", "postgresql", "database"]
    table: str
    schema_name: str | None = "public"
    write_method: WriteMethod = WriteMethod.INSERT
    primary_key: str | list[str] | None = None
    update_columns: list[str] | None = None
    connection_string: str | None = None
    database: DatabaseConfig | None = None
    ssh_tunnel: SSHTunnelConfig | None = None
    batch_size: int = Field(1000, ge=1)
    validation: LoadValidationConfig | None = None


class SQLiteLoadConfig(BaseModel):
    """SQLite load configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["sqlite"] = "sqlite"
    table: str
    path: str
    write_method: WriteMethod = WriteMethod.INSERT
    primary_key: str | list[str] | None = None
    batch_size: int = Field(1000, ge=1)
    validation: LoadValidationConfig | None = None


class FileLoadConfig(BaseModel):
    """File load configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["file"] = "file"
    path: str
    format: FileFormat = FileFormat.JSON
    write_mode: WriteMode = WriteMode.OVERWRITE
    csv_options: CSVOptions | None = None
    json_options: JSONOptions | None = None
    batch_size: int = Field(1000, ge=1)
    validation: LoadValidationConfig | None = None


class CloudStorageLoadConfig(BaseModel):
    """Cloud storage load configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["cloud_storage"] = "cloud_storage"
    storage: CloudStorageConfig
    format: FileFormat = FileFormat.JSON
    write_mode: WriteMode = WriteMode.OVERWRITE
    partition_by: list[str] | None = None
    batch_size: int = Field(1000, ge=1)
    validation: LoadValidationConfig | None = None


# Union type for load config
LoadConfig = (
    PostgresLoadConfig | SQLiteLoadConfig | FileLoadConfig | CloudStorageLoadConfig
)

# =============================================================================
# TRANSFORM CONFIG
# =============================================================================


class FilterConfig(BaseModel):
    """Filter operation configuration."""

    model_config = ConfigDict(extra="forbid")

    expression: str | None = None
    field: str | None = None
    operator: FilterOperator | None = None
    value: Any | None = None


class MapConfig(BaseModel):
    """Map (lookup) operation configuration."""

    model_config = ConfigDict(extra="forbid")

    field: str
    mapping: dict[str, Any] | None
    default: Any | None = None


class JSONataConfig(BaseModel):
    """JSONata transformation configuration."""

    model_config = ConfigDict(extra="forbid")

    expression: str
    mode: JSONataMode = JSONataMode.RECORD


class CustomFunctionConfig(BaseModel):
    """Custom Python function configuration."""

    model_config = ConfigDict(extra="forbid")

    module: str
    function: str
    kwargs: dict[str, Any] | None = None
    mode: JSONataMode = JSONataMode.BATCH


class SimpleOpsConfig(BaseModel):
    """Simple transform operations (object format)."""

    model_config = ConfigDict(extra="forbid")

    rename: dict[str, str] | None = None
    convert: dict[str, ConvertType] | None = None
    defaults: dict[str, Any] | None = None
    add: dict[str, Any] | None = None
    select: list[str] | None = None
    drop: list[str] | None = None
    filter: FilterConfig | None = None


class TransformConfig(BaseModel):
    """Transform configuration (simple ops, JSONata, custom function)."""

    model_config = ConfigDict(extra="forbid")

    # Simple ops: can be list (ordered) or dict (legacy)
    transform: SimpleOpsConfig | list[dict[str, Any]] | None = None
    # JSONata transformation
    jsonata: JSONataConfig | None = None
    # Custom Python function
    custom_function: CustomFunctionConfig | None = None


# =============================================================================
# PIPELINE CONFIG (single-file format)
# =============================================================================


class PipelineConfig(BaseModel):
    """Complete pipeline configuration (single-file format)."""

    model_config = ConfigDict(extra="forbid")

    name: str | None = None
    version: str | None = None
    description: str | None = None

    # Core ETL steps (validated separately based on type)
    extract: dict[str, Any] | None
    transform: dict[str, Any] | list[dict[str, Any]] | None = None
    jsonata: JSONataConfig | None = None
    custom_function: CustomFunctionConfig | None = None
    load: dict[str, Any] | None
    # Inline variables for ${VAR} substitution
    variables: dict[str, str] | None = None
    # Inline settings (for single-file format)
    metadata_store: MetadataStoreConfig | None = None
    dlq: DLQConfig | None = None
    contract: str | None = None
    lineage: LineageConfig | None = None


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================


def parse_extract_config(config: dict[str, Any]) -> ExtractConfig:
    """Parse extract config dict into typed model based on 'type' field."""
    extract_type = config.get("type", "").lower()

    if extract_type == "http":
        return HTTPExtractConfig(**config)
    elif extract_type == "file":
        return FileExtractConfig(**config)
    elif extract_type == "database":
        return DatabaseExtractConfig(**config)
    elif extract_type == "cloud_storage":
        return CloudStorageExtractConfig(**config)
    elif extract_type == "sse":
        return SSEExtractConfig(**config)
    elif extract_type == "websocket":
        return WebSocketExtractConfig(**config)
    elif extract_type == "file_watcher":
        return FileWatcherExtractConfig(**config)
    elif extract_type == "kafka":
        return KafkaExtractConfig(**config)
    elif extract_type == "rabbitmq":
        return RabbitMQExtractConfig(**config)
    elif extract_type == "sqs":
        return SQSExtractConfig(**config)
    else:
        raise ValueError(
            f"Unknown extract type: '{extract_type}'. "
            f"Supported types: http, file, database, cloud_storage, "
            f"sse, websocket, file_watcher, kafka, rabbitmq, sqs"
        )


def parse_load_config(config: dict[str, Any]) -> LoadConfig:
    """Parse load config dict into typed model based on 'type' field."""
    load_type = config.get("type", "").lower()

    if load_type in ("postgres", "postgresql", "database"):
        return PostgresLoadConfig(**config)
    elif load_type == "sqlite":
        return SQLiteLoadConfig(**config)
    elif load_type == "file":
        return FileLoadConfig(**config)
    elif load_type == "cloud_storage":
        return CloudStorageLoadConfig(**config)
    else:
        raise ValueError(
            f"Unknown load type: '{load_type}'. "
            f"Supported types: postgres, postgresql, database, sqlite, file, cloud_storage"
        )


def parse_transform_config(
    config: dict[str, Any] | list[dict[str, Any]] | None,
) -> TransformConfig | None:
    """Parse transform config into typed model."""
    if config is None:
        return None

    # Handle top-level transform that's just a list or simple ops dict
    if isinstance(config, list):
        return TransformConfig(transform=config)

    return TransformConfig(**config)


def parse_settings_config(config: dict[str, Any]) -> SettingsConfig:
    """Parse settings config into typed model."""
    return SettingsConfig(**config)
