"""ETL Generator - Modern ETL pipeline framework.

Provides two APIs: programmatic (Pipeline with ``|`` operator) and
config-driven (YAML files via ``Pipeline.from_config_file``).
"""

from __future__ import annotations

from typing import Any

from pycharter.etl_generator.builder import PipelineBuilder

# Config models (Pydantic)
from pycharter.etl_generator.config_models import (
    DLQConfig,
    ExtractConfig,
    ExtractValidationConfig,
    LineageConfig,
    LoadConfig,
    LoadValidationConfig,
    SettingsConfig,
    TransformConfig,
    parse_extract_config,
    parse_load_config,
    parse_settings_config,
    parse_transform_config,
)
from pycharter.etl_generator.config_validator import (
    ConfigValidationError,
    ConfigValidator,
    validate_config,
)
from pycharter.etl_generator.context import PipelineContext

# Expression evaluation
from pycharter.etl_generator.expression import (
    ExpressionError,
    ExpressionEvaluator,
    evaluate_expression,
    is_expression,
)

# Extractors
from pycharter.etl_generator.extractors import (
    BaseExtractor,
    CloudStorageExtractor,
    DatabaseExtractor,
    ExtractorFactory,
    FileExtractor,
    HTTPExtractor,
)

# Loaders
from pycharter.etl_generator.loaders import (
    BaseLoader,
    CloudStorageLoader,
    DatabaseLoader,
    FileLoader,
    LoaderFactory,
    PostgresLoader,
)

# Core pipeline classes
from pycharter.etl_generator.pipeline import Pipeline
from pycharter.etl_generator.protocols import (
    AckableExtractor,
    Extractor,
    Loader,
    Transformer,
)
from pycharter.etl_generator.result import BatchResult, LoadResult, PipelineResult

# Transformers
from pycharter.etl_generator.transformers import (
    AddField,
    BaseTransformer,
    Convert,
    CustomFunction,
    Default,
    Drop,
    Filter,
    FlatMap,
    Flatten,
    Map,
    Rename,
    Select,
    TransformerChain,
    Unnest,
)

# Config validation and errors
from pycharter.shared.errors import ConfigLoadError

# ---------------------------------------------------------------------------
# Lazy imports — heavy or optional modules loaded on first access
# ---------------------------------------------------------------------------

_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    # Lineage (requires openlineage)
    "LineageEmitter": ("pycharter.etl_generator.lineage", "LineageEmitter"),
    "create_lineage_emitter": (
        "pycharter.etl_generator.lineage",
        "create_lineage_emitter",
    ),
    # Orchestrator and pipeline discovery (heavy, imports many submodules)
    "ETLOrchestrator": (
        "pycharter.etl_generator.orchestrator",
        "ETLOrchestrator",
    ),
    "PipelineFactory": ("pycharter.etl_generator.factory", "PipelineFactory"),
    "AsyncRateLimiter": (
        "pycharter.etl_generator.rate_limiter",
        "AsyncRateLimiter",
    ),
    # Quality checks
    "QualityChecker": ("pycharter.etl_generator.quality", "QualityChecker"),
    "PostLoadChecker": ("pycharter.etl_generator.quality", "PostLoadChecker"),
    "QualityCheckResult": (
        "pycharter.etl_generator.quality",
        "QualityCheckResult",
    ),
    "QualityCheckSeverity": (
        "pycharter.etl_generator.quality",
        "QualityCheckSeverity",
    ),
    "QualityCheckStatus": (
        "pycharter.etl_generator.quality",
        "QualityCheckStatus",
    ),
    "QualityReport": ("pycharter.etl_generator.quality", "QualityReport"),
    "create_quality_checker": (
        "pycharter.etl_generator.quality",
        "create_quality_checker",
    ),
    # State persistence (incremental extraction)
    "PipelineState": ("pycharter.etl_generator.state", "PipelineState"),
    "StateStore": ("pycharter.etl_generator.state", "StateStore"),
    "FileStateStore": ("pycharter.etl_generator.state", "FileStateStore"),
    "SqliteStateStore": ("pycharter.etl_generator.state", "SqliteStateStore"),
    "create_state_store": (
        "pycharter.etl_generator.state",
        "create_state_store",
    ),
    # DLQ sync wrappers
    "add_record_sync": ("pycharter.etl_generator._dlq_sync", "add_record_sync"),
    "add_batch_sync": ("pycharter.etl_generator._dlq_sync", "add_batch_sync"),
    "retry_record_sync": (
        "pycharter.etl_generator._dlq_sync",
        "retry_record_sync",
    ),
    # ETL Validation
    "ETLValidator": ("pycharter.etl_generator.validation", "ETLValidator"),
    "ETLValidationError": (
        "pycharter.etl_generator.validation",
        "ETLValidationError",
    ),
    "resolve_schema": ("pycharter.etl_generator.validation", "resolve_schema"),
    "resolve_contract": (
        "pycharter.etl_generator.validation",
        "resolve_contract",
    ),
    "create_dlq": ("pycharter.etl_generator.validation", "create_dlq"),
    "create_etl_validator": (
        "pycharter.etl_generator.validation",
        "create_etl_validator",
    ),
    # Testing framework
    "MockExtractor": ("pycharter.etl_generator.testing", "MockExtractor"),
    "MockLoader": ("pycharter.etl_generator.testing", "MockLoader"),
    "PipelineTestHarness": (
        "pycharter.etl_generator.testing",
        "PipelineTestHarness",
    ),
    "TestFixture": ("pycharter.etl_generator.testing", "TestFixture"),
    "assert_records_match": (
        "pycharter.etl_generator.testing",
        "assert_records_match",
    ),
    "assert_record_count": (
        "pycharter.etl_generator.testing",
        "assert_record_count",
    ),
    "assert_fields_present": (
        "pycharter.etl_generator.testing",
        "assert_fields_present",
    ),
    "assert_no_field": ("pycharter.etl_generator.testing", "assert_no_field"),
    "assert_field_values": (
        "pycharter.etl_generator.testing",
        "assert_field_values",
    ),
    "assert_schema_shape": (
        "pycharter.etl_generator.testing",
        "assert_schema_shape",
    ),
    "load_fixture": ("pycharter.etl_generator.testing", "load_fixture"),
    "load_test_fixture": (
        "pycharter.etl_generator.testing",
        "load_test_fixture",
    ),
    "validate_pipeline_config": (
        "pycharter.etl_generator.testing",
        "validate_pipeline_config",
    ),
    # Streaming extractors (via extractors/__init__.py __getattr__)
    "KafkaExtractor": (
        "pycharter.etl_generator.extractors.kafka",
        "KafkaExtractor",
    ),
    "RabbitMQExtractor": (
        "pycharter.etl_generator.extractors.rabbitmq",
        "RabbitMQExtractor",
    ),
    "SQSExtractor": (
        "pycharter.etl_generator.extractors.sqs",
        "SQSExtractor",
    ),
}


def __getattr__(name: str) -> Any:
    """Lazy-load optional and heavy modules on first access."""
    if name in _LAZY_IMPORTS:
        import importlib

        module_path, attr_name = _LAZY_IMPORTS[name]
        module = importlib.import_module(module_path)
        return getattr(module, attr_name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def create_orchestrator(contract_dir: str | None = None, **kwargs: Any) -> Any:
    """Factory helper that returns ETLOrchestrator(contract_dir=contract_dir, **kwargs)."""
    from pycharter.etl_generator.orchestrator import ETLOrchestrator

    return ETLOrchestrator(contract_dir=contract_dir, **kwargs)


__all__ = [
    # Core
    "Pipeline",
    "PipelineBuilder",
    "PipelineContext",
    "PipelineResult",
    "BatchResult",
    "LoadResult",
    # Protocols
    "Extractor",
    "AckableExtractor",
    "Transformer",
    "Loader",
    # Config validation
    "ConfigLoadError",
    "ConfigValidator",
    "ConfigValidationError",
    "validate_config",
    # Config models
    "ExtractConfig",
    "LoadConfig",
    "TransformConfig",
    "SettingsConfig",
    "ExtractValidationConfig",
    "LoadValidationConfig",
    "DLQConfig",
    "LineageConfig",
    "parse_extract_config",
    "parse_load_config",
    "parse_transform_config",
    "parse_settings_config",
    # ETL Validation
    "ETLValidator",
    "ETLValidationError",
    "resolve_schema",
    "resolve_contract",
    "create_dlq",
    "create_etl_validator",
    # Expressions
    "ExpressionEvaluator",
    "ExpressionError",
    "evaluate_expression",
    "is_expression",
    # Extractors
    "BaseExtractor",
    "HTTPExtractor",
    "FileExtractor",
    "DatabaseExtractor",
    "CloudStorageExtractor",
    "KafkaExtractor",
    "RabbitMQExtractor",
    "SQSExtractor",
    "ExtractorFactory",
    # Transformers
    "BaseTransformer",
    "TransformerChain",
    "Rename",
    "AddField",
    "Drop",
    "Select",
    "Filter",
    "Convert",
    "Default",
    "Map",
    "FlatMap",
    "CustomFunction",
    "Unnest",
    "Flatten",
    # Loaders
    "BaseLoader",
    "PostgresLoader",
    "DatabaseLoader",
    "FileLoader",
    "CloudStorageLoader",
    "LoaderFactory",
    # Orchestrator and pipeline discovery
    "ETLOrchestrator",
    "PipelineFactory",
    "AsyncRateLimiter",
    "create_orchestrator",
    # Lineage
    "LineageEmitter",
    "create_lineage_emitter",
    # State persistence
    "PipelineState",
    "StateStore",
    "FileStateStore",
    "SqliteStateStore",
    "create_state_store",
    # Quality checks
    "QualityChecker",
    "PostLoadChecker",
    "QualityCheckResult",
    "QualityCheckSeverity",
    "QualityCheckStatus",
    "QualityReport",
    "create_quality_checker",
    # DLQ sync wrappers
    "add_record_sync",
    "add_batch_sync",
    "retry_record_sync",
    # Testing framework
    "MockExtractor",
    "MockLoader",
    "PipelineTestHarness",
    "TestFixture",
    "assert_records_match",
    "assert_record_count",
    "assert_fields_present",
    "assert_no_field",
    "assert_field_values",
    "assert_schema_shape",
    "load_fixture",
    "load_test_fixture",
    "validate_pipeline_config",
]
