"""Factory and config-loading helpers for Pipeline construction."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml

if TYPE_CHECKING:
    from pycharter.metadata_store import MetadataStoreClient

from pycharter.etl_generator.context import PipelineContext

logger = logging.getLogger(__name__)


# =============================================================================
# CONFIG FILE / VARIABLE HELPERS
# =============================================================================


def _unwrap_file_section(value: Any, section: str) -> Any:
    """If value is a dict with exactly one key equal to section, return the inner value.

    This lets callers pass a loaded YAML file as-is (e.g. config["transform"] = load_yaml(...))
    when the file has a single top-level key like "transform" or "jsonata", without double-nesting.
    """
    if value is None:
        return None
    if isinstance(value, dict) and list(value.keys()) == [section]:
        return value[section]
    return value


def _resolve_variables(
    variables: str | Path | dict[str, str] | None,
) -> dict[str, str]:
    """Return variables dict from path (to variables.yaml) or dict. Caller wins on merge."""
    if variables is None:
        return {}
    if isinstance(variables, str | Path):
        return _load_variables_file(Path(variables), {})
    return dict(variables)


def _resolve_settings(
    settings: str | Path | dict[str, Any] | None,
    variables: dict[str, str],
) -> dict[str, Any]:
    """Return settings dict from path or dict. Empty if None."""
    if settings is None:
        return {}
    loaded = _load_config_input(settings, variables)
    return loaded if isinstance(loaded, dict) else {}


def _load_config_input(
    config_input: str | Path | dict[str, Any] | list[dict[str, Any]],
    variables: dict[str, str],
) -> dict[str, Any] | list[dict[str, Any]]:
    """Load config from file path or return dict/list directly."""
    if isinstance(config_input, dict | list):
        return config_input

    path = Path(config_input)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(path) as f:
        content = f.read()

    context = PipelineContext(variables=variables)
    content = context.resolve(content)
    return yaml.safe_load(content) or {}


def _load_variables_file(
    path: Path,
    caller_variables: dict[str, str],
) -> dict[str, str]:
    """Load a variables.yaml file and merge with caller-supplied variables.

    File variables are loaded first, then caller-supplied variables are overlaid
    so that the caller always takes precedence. All values are stringified.

    Args:
        path: Path to variables.yaml file.
        caller_variables: Variables supplied by the caller (take precedence).

    Returns:
        Merged variables dict with string values.

    Raises:
        ValueError: If the file does not contain a dict at the top level.
    """
    if not path.exists():
        return dict(caller_variables)

    with open(path) as f:
        raw = yaml.safe_load(f)

    if raw is None:
        return dict(caller_variables)

    if not isinstance(raw, dict):
        raise ValueError(
            f"variables.yaml must contain a mapping, got {type(raw).__name__}: {path}"
        )

    # File variables as strings, then overlay caller variables (caller wins)
    merged = {k: str(v) for k, v in raw.items()}
    merged.update(caller_variables)
    return merged


# =============================================================================
# COMPONENT FACTORY HELPERS
# =============================================================================


def create_metadata_store(
    settings: dict[str, Any],
) -> MetadataStoreClient | None:
    """Create metadata store client from pipeline settings."""
    store_config = settings.get("metadata_store")
    if not store_config:
        return None

    store_type = store_config.get("type", "").lower()
    connection_string = store_config.get("connection_string")

    if not connection_string:
        logger.warning("metadata_store missing connection_string")
        return None

    if store_type == "postgres":
        from pycharter.metadata_store import PostgresMetadataStore

        return PostgresMetadataStore(connection_string)
    elif store_type == "sqlite":
        from pycharter.metadata_store import SQLiteMetadataStore

        return SQLiteMetadataStore(connection_string)
    elif store_type == "mongodb":
        from pycharter.metadata_store import MongoDBMetadataStore

        return MongoDBMetadataStore(connection_string)
    elif store_type == "redis":
        from pycharter.metadata_store import RedisMetadataStore

        return RedisMetadataStore(connection_string)
    elif store_type == "memory":
        from pycharter.metadata_store import InMemoryMetadataStore

        return InMemoryMetadataStore()
    else:
        logger.warning("Unknown metadata_store type: %s", store_type)
        return None


def create_extract_validator(
    extract_validation_config: dict[str, Any] | None,
    settings: dict[str, Any],
    pipeline_name: str,
    base_dir: Path | None,
) -> Any | None:
    """Create extract validator if configured."""
    if not extract_validation_config:
        return None

    from pycharter.etl_generator.config_models import DLQConfig
    from pycharter.etl_generator.validation import create_etl_validator

    default_dlq = None
    if settings.get("dlq"):
        default_dlq = DLQConfig(**settings["dlq"])

    return create_etl_validator(
        validation_config=extract_validation_config,
        pipeline_name=pipeline_name,
        stage="extract",
        metadata_store=None,
        default_contract=None,
        default_dlq_config=default_dlq,
        base_dir=base_dir,
    )


def create_load_validator(
    load_validation_config: dict[str, Any] | None,
    settings: dict[str, Any],
    pipeline_name: str,
    base_dir: Path | None,
) -> Any | None:
    """Create load validator if configured."""
    if not load_validation_config:
        return None

    from pycharter.etl_generator.config_models import DLQConfig
    from pycharter.etl_generator.validation import create_etl_validator

    default_dlq = None
    if settings.get("dlq"):
        default_dlq = DLQConfig(**settings["dlq"])

    default_contract = settings.get("contract")

    metadata_store = None
    if settings.get("metadata_store"):
        metadata_store = create_metadata_store(settings)

    return create_etl_validator(
        validation_config=load_validation_config,
        pipeline_name=pipeline_name,
        stage="load",
        metadata_store=metadata_store,
        default_contract=default_contract,
        default_dlq_config=default_dlq,
        base_dir=base_dir,
    )


def create_state_store(settings: dict[str, Any]) -> Any:
    """Create state store from settings config."""
    from pycharter.etl_generator.state import create_state_store as _create

    store_config = settings.get("state_store", {})
    return _create(store_config)


def create_quality_checker(
    quality_checks_config: list[dict[str, Any]] | None,
    pipeline_name: str,
) -> Any | None:
    """Create quality checker if quality checks are configured."""
    if not quality_checks_config:
        return None
    from pycharter.etl_generator.quality import create_quality_checker as _create

    return _create(quality_checks_config, pipeline_name=pipeline_name)


def prepare_lineage(
    settings: dict[str, Any],
    extract_config_raw: dict[str, Any] | None,
    load_config_raw: dict[str, Any] | None,
) -> tuple[Any, list[Any], list[Any]]:
    """Build lineage emitter and dataset descriptors from settings and raw configs.

    Returns:
        Tuple of (emitter, input_datasets, output_datasets).
        All three are None/empty when lineage is disabled or unavailable.
    """
    from pycharter.etl_generator.lineage import (
        create_lineage_emitter,
        dataset_from_extract_config,
        dataset_from_load_config,
    )

    emitter = create_lineage_emitter(settings)
    if emitter is None:
        return None, [], []

    input_ds = (
        [dataset_from_extract_config(extract_config_raw)] if extract_config_raw else []
    )
    output_ds = [dataset_from_load_config(load_config_raw)] if load_config_raw else []
    return emitter, input_ds, output_ds


def finalize_run(
    result: Any,
    start_time: Any,
    run_id: str,
    pipeline_name: str,
    quality_checker: Any | None,
    all_loaded_records: list[dict[str, Any]],
    state_store: Any | None,
    existing_state: Any | None,
    max_watermark: str | None,
    emitter: Any | None,
    input_ds: list[Any],
    output_ds: list[Any],
) -> None:
    """Post-loop finalisation: quality checks, watermark save, lineage emit, logging."""
    from datetime import UTC, datetime

    from pycharter.etl_generator.result import LoadResult

    result.end_time = datetime.now(UTC)
    result.duration_seconds = (result.end_time - start_time).total_seconds()
    result.rows_failed = sum(br.rows_failed for br in result.batch_results)

    if quality_checker and result.success:
        last_load_result = LoadResult(
            success=True,
            rows_loaded=result.rows_loaded,
            rows_failed=result.rows_failed,
        )
        quality_report = quality_checker.run(all_loaded_records, last_load_result)
        result.quality_report = quality_report
        if not quality_report.passed:
            result.success = False
            for failure in quality_report.hard_failures:
                result.errors.append(f"Quality check failed: {failure.message}")
        for warning in quality_report.warnings:
            logger.warning("[%s] Quality warning: %s", run_id, warning.message)

    if result.errors:
        result.success = False

    if state_store and result.success and max_watermark:
        from pycharter.etl_generator.state import PipelineState

        state_store.save(
            PipelineState(
                pipeline_name=pipeline_name,
                watermark=max_watermark,
                last_run_id=run_id,
                last_run_at=datetime.now(UTC).isoformat(),
                run_count=((existing_state.run_count + 1) if existing_state else 1),
            )
        )

    if emitter:
        try:
            if result.success:
                payload = emitter.complete(
                    pipeline_name,
                    run_id,
                    input_ds,
                    output_ds,
                    result,
                )
            else:
                payload = emitter.fail(pipeline_name, run_id, input_ds, result)
            if payload:
                result.lineage_events.append(payload)
        except Exception:
            logger.debug("Lineage COMPLETE/FAIL emission failed", exc_info=True)

    logger.info(
        "[%s] Complete: extracted=%s, loaded=%s, "
        "quarantined_extract=%s, quarantined_load=%s",
        run_id,
        result.rows_extracted,
        result.rows_loaded,
        result.rows_quarantined_extract,
        result.rows_quarantined_load,
    )


def apply_transforms_dispatch(
    data: list[dict[str, Any]],
    transform_config: dict[str, Any] | list[dict[str, Any]] | None,
    transformers: list[Any],
) -> list[dict[str, Any]]:
    """Apply transformers to data (config-driven or programmatic).

    Args:
        data: Records to transform.
        transform_config: Config-driven transform spec (if any).
        transformers: Programmatic transformer chain.

    Returns:
        Transformed records.
    """
    if transform_config:
        from pycharter.etl_generator.transformers import apply_transforms

        return apply_transforms(data, transform_config)

    result = data
    for transformer in transformers:
        result = transformer.transform(result)
    return result
