"""
Expression evaluation for ETL transformations.

Provides a unified expression evaluator for field values, computed columns,
and dynamic expressions in ETL pipelines.

Supported expressions:
- ${field_name} - Reference a field value
- ${field_name:-default} - Field with default if missing/null
- now() - Current timestamp (ISO format)
- uuid() - Generate a UUID
- env(VAR_NAME) - Get environment variable
- lower(${field}) - Lowercase a field value
- upper(${field}) - Uppercase a field value
- concat(${field1}, " ", ${field2}) - Concatenate values
- coalesce(${field1}, ${field2}, "default") - First non-null value
- Literal values - Strings, numbers, booleans
"""

from __future__ import annotations

import logging
import re
from collections.abc import Callable
from typing import Any

from pycharter.etl_generator._builtin_functions import BUILTIN_FUNCTIONS
from pycharter.shared.errors import ExpressionError

logger = logging.getLogger(__name__)

# Pattern for field references: ${field} or ${field:-default}
FIELD_PATTERN = re.compile(r"\$\{([^}:]+)(?::-([^}]*))?\}")

# Pattern for function calls: func_name(args)
FUNCTION_PATTERN = re.compile(r"^(\w+)\((.*)\)$", re.DOTALL)


class ExpressionEvaluator:
    """
    Evaluates expressions in the context of a data record.

    Usage:
        evaluator = ExpressionEvaluator()

        # Evaluate field reference
        result = evaluator.evaluate("${first_name}", {"first_name": "Alice"})
        # -> "Alice"

        # Evaluate with default
        result = evaluator.evaluate("${middle_name:-N/A}", {"first_name": "Alice"})
        # -> "N/A"

        # Evaluate function
        result = evaluator.evaluate("now()", {})
        # -> "2024-01-15T10:30:00"

        # Evaluate string interpolation
        result = evaluator.evaluate("Hello, ${name}!", {"name": "World"})
        # -> "Hello, World!"

        # Evaluate computed expression
        result = evaluator.evaluate("concat(${first_name}, ' ', ${last_name})",
                                   {"first_name": "Alice", "last_name": "Smith"})
        # -> "Alice Smith"
    """

    def __init__(
        self,
        strict: bool = False,
        default_on_missing: str | None = None,
    ):
        """
        Initialize the expression evaluator.

        Args:
            strict: If True, raise errors on missing fields.
                   If False, replace with empty string or default.
            default_on_missing: Default value for missing fields when not strict.
        """
        self.strict = strict
        self.default_on_missing = default_on_missing or ""

        # Register built-in functions
        self._functions: dict[str, Callable] = dict(BUILTIN_FUNCTIONS)

    def evaluate(
        self,
        expression: Any,
        record: dict[str, Any],
        context: dict[str, Any] | None = None,
    ) -> Any:
        """
        Evaluate an expression in the context of a record.

        Args:
            expression: The expression to evaluate (string or literal)
            record: The data record providing field values
            context: Additional context variables

        Returns:
            The evaluated value

        Raises:
            ExpressionError: If evaluation fails and strict=True
        """
        context = context or {}

        # Non-string values are returned as-is
        if not isinstance(expression, str):
            return expression

        expression = expression.strip()

        # Empty string
        if not expression:
            return expression

        # Check for function call (entire expression is a function)
        func_match = FUNCTION_PATTERN.match(expression)
        if func_match:
            func_name = func_match.group(1).lower()
            args_str = func_match.group(2).strip()

            if func_name in self._functions:
                return self._call_function(func_name, args_str, record, context)

        # Check for field references in the expression
        if "${" in expression:
            return self._interpolate_fields(expression, record, context)

        # Check for simple function calls without $ prefix (now(), uuid())
        if expression.endswith("()") and expression[:-2].isidentifier():
            func_name = expression[:-2].lower()
            if func_name in self._functions:
                return self._call_function(func_name, "", record, context)

        # Return as literal
        return expression

    def _interpolate_fields(
        self,
        expression: str,
        record: dict[str, Any],
        context: dict[str, Any],
    ) -> str:
        """Interpolate ${field} references in a string."""

        def get_nested(obj: Any, path: str) -> Any:
            """Get nested value by dotted path with array indexing.

            Supports ``schedule.departure`` and ``legs[0].airport``.
            """
            bracket_re = re.compile(r"^(\w+)\[(-?\d+)\]$")
            for part in path.split("."):
                if obj is None:
                    return None
                m = bracket_re.match(part)
                if m:
                    key, idx = m.group(1), int(m.group(2))
                    obj = obj.get(key) if isinstance(obj, dict) else None
                    if isinstance(obj, list):
                        try:
                            obj = obj[idx]
                        except IndexError:
                            return None
                    else:
                        return None
                elif isinstance(obj, dict):
                    obj = obj.get(part)
                else:
                    return None
            return obj

        def replace_field(match):
            field_name = match.group(1)
            default_value = match.group(2)
            value = None

            # Check record first, then context, then dotted path
            if field_name in record:
                value = record[field_name]
            elif field_name in context:
                value = context[field_name]
            elif "." in field_name or "[" in field_name:
                value = get_nested(record, field_name)
                if value is None:
                    value = get_nested(context, field_name)

            if value is None:
                if self.strict and default_value is None:
                    raise ExpressionError(
                        f"Field '{field_name}' not found in record. "
                        f"Available: {sorted(record.keys())}"
                    )
                value = (
                    default_value
                    if default_value is not None
                    else self.default_on_missing
                )

            # Convert to string for interpolation
            if value is None:
                return default_value if default_value is not None else ""
            return str(value)

        return FIELD_PATTERN.sub(replace_field, expression)

    def _call_function(
        self,
        func_name: str,
        args_str: str,
        record: dict[str, Any],
        context: dict[str, Any],
    ) -> Any:
        """Call a built-in function with parsed arguments."""
        func = self._functions.get(func_name)
        if func is None:
            if self.strict:
                raise ExpressionError(f"Unknown function: {func_name}")
            logger.warning("Unknown function: %s", func_name)
            return f"{func_name}({args_str})"

        # Parse arguments
        args = self._parse_args(args_str, record, context) if args_str else []

        try:
            return func(args, record, context)
        except Exception as e:
            if self.strict:
                raise ExpressionError(f"Error in {func_name}(): {e}") from e
            logger.warning("Error in %s(): %s", func_name, e)
            return None

    def _parse_args(
        self,
        args_str: str,
        record: dict[str, Any],
        context: dict[str, Any],
    ) -> list[Any]:
        """Parse function arguments, handling nested expressions."""
        if not args_str:
            return []

        args = []
        current_arg = ""
        depth = 0
        in_string = False
        string_char = None

        for i, char in enumerate(args_str):
            if char in ('"', "'") and (i == 0 or args_str[i - 1] != "\\"):
                if not in_string:
                    in_string = True
                    string_char = char
                elif char == string_char:
                    in_string = False
                    string_char = None
                current_arg += char
            elif in_string:
                current_arg += char
            elif char == "(":
                depth += 1
                current_arg += char
            elif char == ")":
                depth -= 1
                current_arg += char
            elif char == "," and depth == 0:
                # Argument separator
                args.append(self._evaluate_arg(current_arg.strip(), record, context))
                current_arg = ""
            else:
                current_arg += char

        # Add last argument
        if current_arg.strip():
            args.append(self._evaluate_arg(current_arg.strip(), record, context))

        return args

    def _evaluate_arg(
        self,
        arg: str,
        record: dict[str, Any],
        context: dict[str, Any],
    ) -> Any:
        """Evaluate a single argument."""
        # Remove surrounding quotes
        if (arg.startswith('"') and arg.endswith('"')) or (
            arg.startswith("'") and arg.endswith("'")
        ):
            return arg[1:-1]

        # Check for number
        try:
            if "." in arg:
                return float(arg)
            return int(arg)
        except ValueError:
            pass

        # Check for boolean
        if arg.lower() == "true":
            return True
        if arg.lower() == "false":
            return False
        if arg.lower() == "null" or arg.lower() == "none":
            return None

        # Evaluate as expression
        return self.evaluate(arg, record, context)

    def register_function(
        self,
        name: str,
        func: Callable[[list[Any], dict[str, Any], dict[str, Any] | None], Any],
    ) -> None:
        """
        Register a custom function.

        Args:
            name: Function name (will be lowercased)
            func: Function that takes (args, record, context) and returns a value
        """
        self._functions[name.lower()] = func


# Default evaluator instance
_default_evaluator = ExpressionEvaluator()


def evaluate_expression(
    expression: Any,
    record: dict[str, Any],
    context: dict[str, Any] | None = None,
) -> Any:
    """
    Evaluate an expression in the context of a record.

    This is a convenience function using the default evaluator.

    Args:
        expression: The expression to evaluate
        record: The data record providing field values
        context: Additional context variables

    Returns:
        The evaluated value
    """
    return _default_evaluator.evaluate(expression, record, context)


def is_expression(value: Any) -> bool:
    """
    Check if a value contains expression syntax.

    Args:
        value: The value to check

    Returns:
        True if the value contains ${} or function calls
    """
    if not isinstance(value, str):
        return False

    value = value.strip()

    # Check for field reference
    if "${" in value:
        return True

    # Check for function call
    if FUNCTION_PATTERN.match(value):
        return True

    # Check for simple function (now(), uuid())
    if value.endswith("()") and value[:-2].isidentifier():
        return True

    return False
