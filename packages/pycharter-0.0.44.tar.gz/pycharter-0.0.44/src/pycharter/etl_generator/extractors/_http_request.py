"""Single-page HTTP request extraction with retry logic.

Extracted from ``http.py`` to keep module sizes under 400 lines.
This module contains the core request/retry/parse loop used by
:class:`~pycharter.etl_generator.extractors.http.HTTPExtractor`.
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from typing import Any

import httpx

from pycharter.etl_generator.extractors._http_helpers import (
    DEFAULT_BACKOFF_FACTOR,
    DEFAULT_MAX_ATTEMPTS,
    DEFAULT_RATE_LIMIT_DELAY,
    DEFAULT_RETRY_STATUS_CODES,
    build_request_url,
    configure_timeout,
    extract_by_path,
    extract_data_array,
    make_http_request,
    resolve_rate_limit_delay,
)
from pycharter.utils.value_injector import resolve_values

logger = logging.getLogger(__name__)


async def extract_single_page(
    extract_config: dict[str, Any],
    params: dict[str, Any],
    headers: dict[str, Any],
    contract_dir: Any | None = None,
    return_full_response: bool = False,
    config_context: dict[str, Any] | None = None,
) -> tuple[list[dict[str, Any]], Any | None, httpx.Response | None]:
    """Extract data from a single API request with retry logic.

    Args:
        extract_config: Extraction configuration dictionary.
        params: Query parameters for the request.
        headers: HTTP headers for the request.
        contract_dir: Optional contract directory for resolving paths.
        return_full_response: Whether to return the full parsed response.
        config_context: Optional context for value resolution.

    Returns:
        A 3-tuple of ``(extracted_records, full_response_data, response_obj)``.
        When *return_full_response* is ``False`` the last two elements are
        ``None``.
    """
    # Get configuration
    base_url = extract_config.get("base_url", "")
    api_endpoint = extract_config.get("api_endpoint", "")
    method = extract_config.get("method", "GET").upper()
    timeout_config = extract_config.get("timeout", {})
    retry_config = extract_config.get("retry", {})
    response_path = extract_config.get("response_path")
    response_format = extract_config.get("response_format", "json")
    rate_limit_delay = extract_config.get("rate_limit_delay", DEFAULT_RATE_LIMIT_DELAY)
    body = extract_config.get("body")

    # Resolve variables and convert types
    source_file = str(contract_dir / "extract.yaml") if contract_dir else None
    resolved_params = resolve_values(
        params, context=config_context, source_file=source_file
    )
    resolved_headers = resolve_values(
        headers, context=config_context, source_file=source_file
    )
    resolved_timeout_config = resolve_values(
        timeout_config, context=config_context, source_file=source_file
    )
    resolved_rate_limit_delay = resolve_rate_limit_delay(
        rate_limit_delay, contract_dir, config_context
    )

    if body:
        resolved_body = resolve_values(
            body, context=config_context, source_file=source_file
        )
    else:
        resolved_body = None

    # Extract path parameters from api_endpoint
    path_params: dict[str, Any] = {}
    if "{" in api_endpoint:
        path_param_names = re.findall(r"\{(\w+)\}", api_endpoint)
        for param_name in path_param_names:
            if param_name in resolved_params:
                path_params[param_name] = resolved_params.pop(param_name)

    # Validate all path placeholders are resolved
    if "{" in api_endpoint:
        missing = [name for name in path_param_names if name not in path_params]
        if missing:
            raise ValueError(
                f"Missing required path parameters: {missing}. "
                f"Endpoint '{api_endpoint}' requires: {path_param_names}. "
                f"Pass them via CLI (e.g. --{missing[0]} <value>) or set defaults in extract.yaml."
            )

    # Build URL with path parameter substitution
    url = build_request_url(base_url, api_endpoint, path_params)

    # Configure timeout
    timeout = configure_timeout(resolved_timeout_config)

    # Configure retry
    max_attempts = int(retry_config.get("max_attempts", DEFAULT_MAX_ATTEMPTS))
    backoff_factor = float(retry_config.get("backoff_factor", DEFAULT_BACKOFF_FACTOR))
    retry_on_status = retry_config.get("retry_on_status", DEFAULT_RETRY_STATUS_CODES)

    # Make request with retry logic
    last_exception = None
    request_start_time = None

    logger.debug(
        "Starting HTTP extraction: %s %s "
        "(timeout: connect=%ss, read=%ss, max_attempts=%s)",
        method,
        url,
        timeout.connect,
        timeout.read,
        max_attempts,
    )
    logger.debug("Request params: %s", resolved_params)
    logger.debug("Request headers: %s", dict(resolved_headers))

    for attempt in range(max_attempts):
        try:
            request_start_time = time.time()
            logger.debug(
                "HTTP request attempt %s/%s to %s", attempt + 1, max_attempts, url
            )

            async with httpx.AsyncClient(timeout=timeout) as client:
                if attempt > 0:
                    wait_time = backoff_factor ** (attempt - 1)
                    logger.debug(
                        "Retrying after %.2fs (attempt %s/%s)",
                        wait_time,
                        attempt + 1,
                        max_attempts,
                    )
                    await asyncio.sleep(wait_time)

                request_attempt_start = time.time()
                try:
                    response = await make_http_request(
                        client,
                        method,
                        url,
                        resolved_params,
                        resolved_headers,
                        resolved_body,
                    )
                    request_duration = time.time() - request_attempt_start
                    logger.debug(
                        "HTTP request completed: %s (%.2fs, attempt %s/%s)",
                        response.status_code,
                        request_duration,
                        attempt + 1,
                        max_attempts,
                    )
                except httpx.TimeoutException as timeout_error:
                    request_duration = time.time() - request_attempt_start
                    timeout_info = ""
                    if hasattr(timeout_error, "timeout") and isinstance(
                        timeout_error.timeout, httpx.Timeout
                    ):
                        timeout_info = (
                            f" (connect={timeout_error.timeout.connect}s, "
                            f"read={timeout_error.timeout.read}s)"
                        )
                    logger.error(
                        "HTTP request timeout after %.2fs%s: %s: %s (attempt %s/%s)",
                        request_duration,
                        timeout_info,
                        type(timeout_error).__name__,
                        timeout_error,
                        attempt + 1,
                        max_attempts,
                    )
                    raise
                except httpx.RequestError as request_error:
                    request_duration = time.time() - request_attempt_start
                    logger.error(
                        "HTTP request error after %.2fs: %s: %s (attempt %s/%s)",
                        request_duration,
                        type(request_error).__name__,
                        request_error,
                        attempt + 1,
                        max_attempts,
                    )
                    raise

                # Check if we should retry based on status code
                if (
                    response.status_code in retry_on_status
                    and attempt < max_attempts - 1
                ):
                    wait_time = backoff_factor**attempt
                    logger.warning(
                        "HTTP %s received, will retry after %.2fs (attempt %s/%s)",
                        response.status_code,
                        wait_time,
                        attempt + 1,
                        max_attempts,
                    )
                    await asyncio.sleep(wait_time)
                    continue

                # Raise for non-2xx status codes
                response.raise_for_status()

                # Parse response
                parse_start = time.time()
                if response_format == "json":
                    data = response.json()
                else:
                    data = response.text
                parse_duration = time.time() - parse_start
                logger.debug("Response parsed in %.3fs", parse_duration)

                # Extract data array
                extract_start = time.time()
                if response_path:
                    extracted_data = extract_by_path(data, response_path)
                else:
                    extracted_data = extract_data_array(data)
                extract_duration = time.time() - extract_start

                # Inject path param values into each record so
                # downstream transforms/loads have access to them
                # (e.g. {symbol} from the URL becomes a field on every row).
                if path_params:
                    for record in extracted_data:
                        if isinstance(record, dict):
                            for k, v in path_params.items():
                                if k not in record:
                                    record[k] = v

                total_duration = time.time() - request_start_time
                logger.debug(
                    "Extraction successful: %s records extracted "
                    "(total: %.2fs, parse: %.3fs, extract: %.3fs)",
                    len(extracted_data),
                    total_duration,
                    parse_duration,
                    extract_duration,
                )

                # Apply rate limiting delay
                if resolved_rate_limit_delay > 0:
                    logger.debug(
                        "Applying rate limit delay: %ss", resolved_rate_limit_delay
                    )
                    await asyncio.sleep(resolved_rate_limit_delay)

                if return_full_response:
                    return extracted_data, data, response
                return extracted_data, None, None

        except httpx.HTTPStatusError as e:
            last_exception = e
            request_duration = (
                time.time() - request_start_time if request_start_time else 0
            )
            logger.error(
                "HTTP status error %s",
                e.response.status_code,
                extra={
                    "status_code": e.response.status_code,
                    "url": url,
                    "attempt": attempt + 1,
                    "duration": request_duration,
                },
                exc_info=True,
            )
            if e.response.status_code in retry_on_status and attempt < max_attempts - 1:
                wait_time = backoff_factor**attempt
                await asyncio.sleep(wait_time)
                continue
            raise RuntimeError(
                f"HTTP error {e.response.status_code}: {e.response.text}"
            ) from e
        except httpx.TimeoutException as e:
            last_exception = e
            request_duration = (
                time.time() - request_start_time if request_start_time else 0
            )
            logger.error(
                "HTTP timeout",
                extra={
                    "url": url,
                    "duration": request_duration,
                    "attempt": attempt + 1,
                },
                exc_info=True,
            )
            if attempt < max_attempts - 1:
                wait_time = backoff_factor**attempt
                await asyncio.sleep(wait_time)
                continue
            raise RuntimeError(
                f"Request timeout after {request_duration:.2f}s: {e}"
            ) from e
        except httpx.RequestError as e:
            last_exception = e
            request_duration = (
                time.time() - request_start_time if request_start_time else 0
            )
            logger.error(
                "HTTP request error",
                extra={
                    "url": url,
                    "duration": request_duration,
                    "attempt": attempt + 1,
                },
                exc_info=True,
            )
            if attempt < max_attempts - 1:
                wait_time = backoff_factor**attempt
                await asyncio.sleep(wait_time)
                continue
            raise RuntimeError(f"Request failed: {e}") from e
        except Exception as e:
            request_duration = (
                time.time() - request_start_time if request_start_time else 0
            )
            logger.error(
                "Unexpected extraction error",
                extra={
                    "url": url,
                    "duration": request_duration,
                    "attempt": attempt + 1,
                },
                exc_info=True,
            )
            raise RuntimeError(f"Extraction failed: {e}") from e

    # If we exhausted all retries
    if last_exception:
        raise RuntimeError(
            f"Extraction failed after {max_attempts} attempts: {last_exception}"
        ) from last_exception
    raise RuntimeError("Extraction failed: unknown error")
