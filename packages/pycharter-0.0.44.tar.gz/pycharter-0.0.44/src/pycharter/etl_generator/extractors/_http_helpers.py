"""Shared helper functions for HTTP extraction.

These were originally private methods on ``HTTPExtractor``.  They are
kept here as module-level functions so that both ``_http_request`` and
``_http_pagination`` can reuse them without circular-dependency issues.
"""

from __future__ import annotations

import logging
import re
from typing import Any

import httpx

from pycharter.utils.value_injector import resolve_values

logger = logging.getLogger(__name__)

# Default configuration values
DEFAULT_RATE_LIMIT_DELAY = 0.2
DEFAULT_MAX_ATTEMPTS = 3
DEFAULT_BACKOFF_FACTOR = 2.0
DEFAULT_RETRY_STATUS_CODES = [429, 500, 502, 503, 504]
DEFAULT_TIMEOUT_CONNECT = 10.0
DEFAULT_TIMEOUT_READ = 30.0
DEFAULT_TIMEOUT_WRITE = 10.0
DEFAULT_TIMEOUT_POOL = 10.0

# Common response data keys
RESPONSE_DATA_KEYS = ["data", "results", "items", "records", "values"]


def get_path_param_names(api_endpoint: str) -> list[str]:
    """Return the ``{param}`` placeholder names found in *api_endpoint*."""
    if not api_endpoint or "{" not in api_endpoint:
        return []
    return re.findall(r"\{(\w+)\}", api_endpoint)


def resolve_rate_limit_delay(
    rate_limit_delay: Any,
    contract_dir: Any | None = None,
    config_context: dict[str, Any] | None = None,
) -> float:
    """Resolve and convert *rate_limit_delay* to float."""
    if isinstance(rate_limit_delay, str):
        source_file = str(contract_dir / "extract.yaml") if contract_dir else None
        resolved = resolve_values(
            rate_limit_delay, context=config_context, source_file=source_file
        )
        return float(resolved)
    return float(rate_limit_delay)


def build_request_url(
    base_url: str,
    api_endpoint: str,
    path_params: dict[str, Any] | None = None,
) -> str:
    """Build full request URL from base URL and endpoint."""
    if api_endpoint.startswith(("http://", "https://")):
        url = api_endpoint
    elif base_url:
        url = f"{base_url.rstrip('/')}/{api_endpoint.lstrip('/')}"
    else:
        raise ValueError(
            "Either 'api_endpoint' must be a full URL (starting with http:// or "
            "https://) or 'base_url' must be provided in extract.yaml"
        )
    if path_params and "{" in url:
        try:
            url = url.format(**path_params)
        except KeyError as e:
            raise ValueError(
                f"Missing required path parameter in URL: {e}. "
                f"URL: {url}, Available params: {list(path_params.keys())}"
            ) from e
    return url


def configure_timeout(timeout_config: dict[str, Any]) -> httpx.Timeout:
    """Configure HTTP timeout from config dictionary."""
    timeout = httpx.Timeout(
        connect=float(timeout_config.get("connect", DEFAULT_TIMEOUT_CONNECT)),
        read=float(timeout_config.get("read", DEFAULT_TIMEOUT_READ)),
        write=float(timeout_config.get("write", DEFAULT_TIMEOUT_WRITE)),
        pool=float(timeout_config.get("pool", DEFAULT_TIMEOUT_POOL)),
    )
    logger.debug(
        "Configured HTTP timeout: connect=%ss, read=%ss, write=%ss, pool=%ss",
        timeout.connect,
        timeout.read,
        timeout.write,
        timeout.pool,
    )
    return timeout


async def make_http_request(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    params: dict[str, Any],
    headers: dict[str, Any],
    body: Any | None = None,
) -> httpx.Response:
    """Make HTTP request with specified method."""
    method = method.upper()
    logger.debug("Making %s request to %s", method, url)
    try:
        if method == "GET":
            return await client.get(url, params=params, headers=headers)
        elif method == "POST":
            if body:
                return await client.post(
                    url,
                    json=body if isinstance(body, dict) else body,
                    params=params,
                    headers=headers,
                )
            else:
                return await client.post(url, params=params, headers=headers)
        else:
            raise ValueError(f"Unsupported HTTP method: {method}")
    except httpx.TimeoutException as e:
        timeout_info = ""
        if hasattr(e, "timeout") and isinstance(e.timeout, httpx.Timeout):
            timeout_info = (
                f" (connect timeout: {e.timeout.connect}s, "
                f"read timeout: {e.timeout.read}s)"
            )
        logger.error("HTTP request timeout for %s %s%s", method, url, timeout_info)
        raise
    except httpx.RequestError as e:
        logger.error(
            "HTTP request error for %s %s: %s: %s",
            method,
            url,
            type(e).__name__,
            e,
        )
        raise


def extract_by_path(data: Any, path: str) -> list[dict[str, Any]]:
    """Extract data using a simple path notation (e.g., 'data.items')."""
    current = data
    for part in path.split("."):
        if isinstance(current, dict):
            current = current.get(part)
        elif isinstance(current, list) and part.isdigit():
            current = current[int(part)]
        else:
            return []
        if current is None:
            return []
    if isinstance(current, list):
        return current
    elif isinstance(current, dict):
        return [current]
    return []


def extract_data_array(data: Any) -> list[dict[str, Any]]:
    """Extract data array from response, handling common response structures."""
    if isinstance(data, list):
        return data
    elif isinstance(data, dict):
        for key in RESPONSE_DATA_KEYS:
            if key in data and isinstance(data[key], list):
                return data[key]
        return [data]
    return []


def check_stop_conditions(
    page_data: list[dict[str, Any]],
    stop_conditions: list[dict[str, Any]],
    params: dict[str, Any],
    response_data: Any = None,
) -> bool:
    """Check if pagination should stop based on configured stop conditions."""
    if not stop_conditions:
        limit = params.get("limit", 100)
        return len(page_data) < limit
    for condition in stop_conditions:
        if check_stop_condition(condition, page_data, params, response_data):
            return True
    return False


def check_stop_condition(
    condition: dict[str, Any],
    page_data: list[dict[str, Any]],
    params: dict[str, Any],
    response_data: Any = None,
) -> bool:
    """Check a single stop condition."""
    condition_type = condition.get("type")
    if condition_type == "empty_response":
        if not page_data:
            logger.debug("Stop condition 'empty_response' triggered: page is empty")
            return True
    elif condition_type == "fewer_records":
        limit = params.get("limit", 100)
        record_count = len(page_data)
        if record_count < limit:
            logger.debug(
                "Stop condition 'fewer_records' triggered: "
                "page returned %s records < limit %s",
                record_count,
                limit,
            )
            return True
    elif condition_type == "max_pages":
        max_pages = condition.get("value", 1000)
        current_page = params.get("page", 0)
        if current_page >= max_pages:
            logger.debug(
                "Stop condition 'max_pages' triggered: page %s >= %s",
                current_page,
                max_pages,
            )
            return True
    elif condition_type == "custom":
        return check_custom_stop_condition(condition, response_data)
    return False


def check_custom_stop_condition(
    condition: dict[str, Any],
    response_data: Any,
) -> bool:
    """Check custom stop condition based on response path."""
    response_path = condition.get("response_path")
    expected_value = condition.get("value")
    if not response_path or not response_data:
        return False
    try:
        current = response_data
        for part in response_path.split("."):
            if isinstance(current, dict):
                current = current.get(part)
            elif isinstance(current, list) and part.isdigit():
                current = current[int(part)]
            else:
                return False
        return current == expected_value
    except (KeyError, IndexError, TypeError):
        return False


def extract_link_header_url(response: httpx.Response) -> str | None:
    """Extract next URL from Link header (RFC 5988)."""
    link_header = response.headers.get("Link", "")
    if not link_header:
        return None
    pattern = r'<([^>]+)>;\s*rel=["\']?next["\']?'
    match = re.search(pattern, link_header, re.IGNORECASE)
    if match:
        return match.group(1)
    return None
