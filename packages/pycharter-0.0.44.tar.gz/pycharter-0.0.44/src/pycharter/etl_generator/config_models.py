"""Pydantic models for ETL pipeline configuration (re-export facade).

Replaces JSON Schema files with type-safe Python models for:
- Extract configuration (HTTP, file, database, cloud storage)
- Transform configuration (simple ops, JSONata, custom function)
- Load configuration (Postgres, SQLite, file, cloud storage)
- Settings (shared pipeline config)
- Validation (source/target schema validation)
- DLQ (dead letter queue)
"""

from __future__ import annotations

# Enums
from pycharter.etl_generator._config_enums import (  # noqa: F401
    CloudProvider,
    ConvertType,
    DLQBackend,
    ExtractType,
    FileFormat,
    FilterOperator,
    HTTPMethod,
    JSONataMode,
    LoadType,
    MetadataStoreType,
    OnErrorAction,
    PaginationStrategy,
    ResponseFormat,
    WriteMethod,
    WriteMode,
)

# Extract configs
from pycharter.etl_generator._config_extract import (  # noqa: F401
    CloudStorageExtractConfig,
    DatabaseExtractConfig,
    ExtractConfig,
    FileExtractConfig,
    FileWatcherExtractConfig,
    HTTPExtractConfig,
    InputParamConfig,
    KafkaExtractConfig,
    PaginationConfig,
    RabbitMQExtractConfig,
    RetryConfig,
    SQSExtractConfig,
    SSEExtractConfig,
    TimeoutConfig,
    WebSocketExtractConfig,
)

# Load, transform, pipeline configs, and parse helpers
from pycharter.etl_generator._config_load import (  # noqa: F401
    CloudStorageLoadConfig,
    CustomFunctionConfig,
    FileLoadConfig,
    FilterConfig,
    JSONataConfig,
    LoadConfig,
    MapConfig,
    PipelineConfig,
    PostgresLoadConfig,
    SimpleOpsConfig,
    SQLiteLoadConfig,
    TransformConfig,
    parse_extract_config,
    parse_load_config,
    parse_settings_config,
    parse_transform_config,
)

# Settings
from pycharter.etl_generator._config_settings import (  # noqa: F401
    LineageConfig,
    PluginConfig,
    SettingsConfig,
    StateStoreConfig,
)

# Shared config models
from pycharter.etl_generator._config_shared import (  # noqa: F401
    CloudStorageConfig,
    ContractRef,
    CSVOptions,
    DatabaseConfig,
    DLQConfig,
    ExtractValidationConfig,
    IncrementalConfig,
    JSONOptions,
    LoadValidationConfig,
    MetadataStoreConfig,
    SSHTunnelConfig,
)

__all__ = [
    # Enums
    "ExtractType",
    "LoadType",
    "CloudProvider",
    "WriteMethod",
    "FileFormat",
    "WriteMode",
    "OnErrorAction",
    "DLQBackend",
    "MetadataStoreType",
    "FilterOperator",
    "PaginationStrategy",
    "HTTPMethod",
    "ResponseFormat",
    "ConvertType",
    "JSONataMode",
    # Shared config models
    "SSHTunnelConfig",
    "DatabaseConfig",
    "CSVOptions",
    "JSONOptions",
    "CloudStorageConfig",
    "DLQConfig",
    "ContractRef",
    "ExtractValidationConfig",
    "LoadValidationConfig",
    "MetadataStoreConfig",
    "IncrementalConfig",
    # Settings models
    "LineageConfig",
    "PluginConfig",
    "StateStoreConfig",
    "SettingsConfig",
    # Extract configs
    "PaginationConfig",
    "RetryConfig",
    "TimeoutConfig",
    "InputParamConfig",
    "HTTPExtractConfig",
    "FileExtractConfig",
    "DatabaseExtractConfig",
    "CloudStorageExtractConfig",
    "SSEExtractConfig",
    "WebSocketExtractConfig",
    "FileWatcherExtractConfig",
    "KafkaExtractConfig",
    "RabbitMQExtractConfig",
    "SQSExtractConfig",
    "ExtractConfig",
    # Load configs
    "PostgresLoadConfig",
    "SQLiteLoadConfig",
    "FileLoadConfig",
    "CloudStorageLoadConfig",
    "LoadConfig",
    # Transform configs
    "FilterConfig",
    "MapConfig",
    "JSONataConfig",
    "CustomFunctionConfig",
    "SimpleOpsConfig",
    "TransformConfig",
    # Pipeline config
    "PipelineConfig",
    # Helper functions
    "parse_extract_config",
    "parse_load_config",
    "parse_transform_config",
    "parse_settings_config",
]
