"""Pipeline class with | operator for chaining ETL stages."""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pycharter.metadata_store import MetadataStoreClient

from pycharter.etl_generator._pipeline_config import (
    _build_from_configs,
    build_from_config_dir,
    build_from_config_file,
    build_from_config_files,
    build_from_dict,
)
from pycharter.etl_generator._pipeline_helpers import (
    _load_variables_file,  # noqa: F401 — re-exported for backward compat
    _unwrap_file_section,  # noqa: F401 — re-exported for backward compat
    apply_transforms_dispatch,
    create_extract_validator,
    create_load_validator,
    create_metadata_store,
    create_quality_checker,
    create_state_store,
    finalize_run,
    prepare_lineage,
)
from pycharter.etl_generator.context import PipelineContext
from pycharter.etl_generator.protocols import Extractor, Loader, Transformer
from pycharter.etl_generator.result import BatchResult, PipelineResult
from pycharter.shared.errors import ErrorContext, get_error_context

logger = logging.getLogger(__name__)


class Pipeline:
    """ETL Pipeline with | operator for chaining transformers."""

    def __init__(
        self,
        extractor: Extractor | None = None,
        transformers: list[Transformer] | None = None,
        loader: Loader | None = None,
        context: PipelineContext | None = None,
        name: str | None = None,
        transform_config: dict[str, Any] | list[dict[str, Any]] | None = None,
        extract_validation_config: dict[str, Any] | None = None,
        load_validation_config: dict[str, Any] | None = None,
        quality_checks_config: list[dict[str, Any]] | None = None,
        settings: dict[str, Any] | None = None,
        base_dir: Path | None = None,
        extract_config_raw: dict[str, Any] | None = None,
        load_config_raw: dict[str, Any] | None = None,
    ):
        self.extractor = extractor
        self._transformers: list[Transformer] = (
            list(transformers) if transformers else []
        )
        self.loader = loader
        self.context = context or PipelineContext()
        self.name = name
        self._transform_config = transform_config
        self._extract_validation_config = extract_validation_config
        self._load_validation_config = load_validation_config
        self._quality_checks_config = quality_checks_config
        self._settings = settings or {}
        self._base_dir = base_dir
        self._run_id: str | None = None
        self._extract_config_raw = extract_config_raw
        self._load_config_raw = load_config_raw

    def __or__(self, other: Transformer | Loader) -> Pipeline:
        """Chain transformer or set loader using | operator."""
        new_loader = other if isinstance(other, Loader) else self.loader
        new_transformers = self._transformers.copy()
        if not isinstance(other, Loader):
            new_transformers.append(other)
        return Pipeline(
            extractor=self.extractor,
            transformers=new_transformers,
            loader=new_loader,
            context=self.context,
            name=self.name,
            extract_validation_config=self._extract_validation_config,
            load_validation_config=self._load_validation_config,
            quality_checks_config=self._quality_checks_config,
            settings=self._settings,
            base_dir=self._base_dir,
        )

    async def run(
        self,
        dry_run: bool = False,
        error_context: ErrorContext | None = None,
        **params: Any,
    ) -> PipelineResult:
        """Run the ETL pipeline.

        Args:
            dry_run: If True, extract and transform but do not load.
            error_context: Optional error context for handling failures.
            **params: Passed to extractor.extract() and loader.load().

        Returns:
            PipelineResult with counts and any errors.
        """
        run_id = str(uuid.uuid4())[:8]
        self._run_id = run_id
        start_time = datetime.now(UTC)
        ctx = error_context or get_error_context()
        result = PipelineResult(
            pipeline_name=self.name,
            run_id=run_id,
            start_time=start_time,
        )
        if not self.extractor:
            result.success = False
            result.errors.append("No extractor configured")
            return result

        logger.info("[%s] Starting pipeline: %s", run_id, self.name or "unnamed")

        state_store = None
        existing_state = None
        inc_config = None
        max_watermark: str | None = None

        if self._extract_config_raw and isinstance(self._extract_config_raw, dict):
            inc_raw = self._extract_config_raw.get("incremental")
            if inc_raw and inc_raw.get("enabled", True):
                inc_config = inc_raw
                state_store = self._create_state_store()
                existing_state = state_store.get(self.name or "unnamed")
                current_wm = (
                    existing_state.watermark if existing_state else None
                ) or inc_config.get("initial_value", "")
                max_watermark = current_wm
                self.context.set("__watermark__", current_wm)
                logger.info("[%s] Incremental mode: watermark=%s", run_id, current_wm)

        emitter, input_ds, output_ds = self._prepare_lineage()
        if emitter:
            run_id = str(uuid.uuid4())
            result.run_id = run_id

        extract_validator = self._create_extract_validator()
        load_validator = self._create_load_validator()
        all_loaded_records: list[dict[str, Any]] = []
        quality_checker = self._create_quality_checker()

        if emitter:
            try:
                payload = emitter.start(self.name or "unnamed", run_id, input_ds)
                if payload:
                    result.lineage_events.append(payload)
            except Exception:
                logger.debug("Lineage START emission failed", exc_info=True)

        try:
            batch_index = 0
            async for batch in self.extractor.extract(**params):
                batch_result = BatchResult(batch_index=batch_index, rows_in=len(batch))
                result.rows_extracted += len(batch)
                if extract_validator:
                    try:
                        (
                            batch,
                            quarantined,
                            error_count,
                        ) = await extract_validator.validate(batch, run_id=run_id)
                        result.rows_quarantined_extract += len(quarantined)
                        if error_count > 0:
                            batch_result.errors.append(
                                f"Extract validation: {error_count} record(s) invalid"
                            )
                    except Exception as e:
                        ctx.handle_error(str(e), e, category="extract_validation")
                        batch_result.errors.append(f"Extract validation failed: {e}")
                        result.success = False
                        result.errors.append(str(e))
                        break
                transformed = self._apply_transforms(batch)
                batch_result.rows_out = len(transformed)
                result.rows_transformed += len(transformed)
                if inc_config and transformed:
                    wm_field = inc_config["watermark_field"]
                    batch_max = max(
                        (str(r.get(wm_field, "")) for r in transformed),
                        default="",
                    )
                    if batch_max > (max_watermark or ""):
                        max_watermark = batch_max
                if load_validator and transformed:
                    try:
                        (
                            transformed,
                            quarantined,
                            error_count,
                        ) = await load_validator.validate(transformed, run_id=run_id)
                        result.rows_quarantined_load += len(quarantined)
                        if error_count > 0:
                            batch_result.errors.append(
                                f"Load validation: {error_count} record(s) invalid"
                            )
                    except Exception as e:
                        ctx.handle_error(str(e), e, category="load_validation")
                        batch_result.errors.append(f"Load validation failed: {e}")
                        result.success = False
                        result.errors.append(str(e))
                        break
                load_success = True
                if not dry_run and self.loader and transformed:
                    try:
                        load_result = await self.loader.load(transformed, **params)
                        load_success = load_result.success
                        if load_result.success:
                            result.rows_loaded += load_result.rows_loaded
                            if quality_checker:
                                all_loaded_records.extend(transformed)
                        else:
                            msg = load_result.error or "Load failed"
                            ctx.handle_error(msg, category="load")
                            batch_result.errors.append(msg)
                            batch_result.rows_failed += len(transformed)
                            result.success = False
                            result.errors.append(msg)
                    except Exception as e:
                        load_success = False
                        ctx.handle_error(str(e), e, category="load")
                        batch_result.errors.append(str(e))
                        batch_result.rows_failed += len(transformed)
                elif dry_run:
                    result.rows_loaded += len(transformed)
                if hasattr(self.extractor, "acknowledge"):
                    try:
                        await self.extractor.acknowledge(batch_index, load_success)
                    except Exception as ack_err:
                        logger.warning(
                            "[%s] Batch %d ack failed: %s",
                            run_id,
                            batch_index,
                            ack_err,
                        )
                result.batches_processed += 1
                result.batch_results.append(batch_result)
                batch_index += 1
        except Exception as e:
            result.success = False
            result.errors.append(str(e))
            ctx.handle_error(str(e), e, category="pipeline")
            logger.error("[%s] Pipeline error: %s", run_id, e)

        finalize_run(
            result=result,
            start_time=start_time,
            run_id=run_id,
            pipeline_name=self.name or "unnamed",
            quality_checker=quality_checker,
            all_loaded_records=all_loaded_records,
            state_store=state_store,
            existing_state=existing_state,
            max_watermark=max_watermark,
            emitter=emitter,
            input_ds=input_ds,
            output_ds=output_ds,
        )
        return result

    def _prepare_lineage(self):
        """Build lineage emitter and dataset descriptors."""
        return prepare_lineage(
            self._settings, self._extract_config_raw, self._load_config_raw
        )

    def _apply_transforms(self, data: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Apply all transformers to data."""
        return apply_transforms_dispatch(
            data, self._transform_config, self._transformers
        )

    def _create_extract_validator(self):
        """Create extract validator if configured."""
        return create_extract_validator(
            self._extract_validation_config,
            self._settings,
            self.name or "unnamed",
            self._base_dir,
        )

    def _create_load_validator(self):
        """Create load validator if configured."""
        return create_load_validator(
            self._load_validation_config,
            self._settings,
            self.name or "unnamed",
            self._base_dir,
        )

    def _create_state_store(self):
        """Create state store from settings config."""
        return create_state_store(self._settings)

    def _create_metadata_store(self) -> MetadataStoreClient | None:
        """Create metadata store from settings."""
        return create_metadata_store(self._settings)

    def _create_quality_checker(self):
        """Create quality checker if quality checks are configured."""
        return create_quality_checker(
            self._quality_checks_config, self.name or "unnamed"
        )

    # Config-driven factory classmethods (delegate to _pipeline_config)

    @classmethod
    def from_config_files(
        cls,
        extract: str | Path | dict[str, Any],
        load: str | Path | dict[str, Any],
        transform: str | Path | dict[str, Any] | list[dict[str, Any]] | None = None,
        variables: str | Path | dict[str, str] | None = None,
        settings: str | Path | dict[str, Any] | None = None,
        *,
        validate: bool = True,
        name: str | None = None,
        load_defaults: dict[str, Any] | None = None,
        base_dir: Path | None = None,
    ) -> Pipeline:
        """Create pipeline from explicit file paths or dicts."""
        return build_from_config_files(
            cls,
            extract,
            load,
            transform,
            variables,
            settings,
            validate=validate,
            name=name,
            load_defaults=load_defaults,
            base_dir=base_dir,
        )

    @classmethod
    def from_config_dir(
        cls,
        directory: str | Path,
        variables: str | Path | dict[str, str] | None = None,
        settings: str | Path | dict[str, Any] | None = None,
        *,
        validate: bool = True,
        name: str | None = None,
        load_defaults: dict[str, Any] | None = None,
        base_dir: Path | None = None,
    ) -> Pipeline:
        """Create pipeline from a directory containing YAML config files."""
        return build_from_config_dir(
            cls,
            directory,
            variables,
            settings,
            validate=validate,
            name=name,
            load_defaults=load_defaults,
            base_dir=base_dir,
        )

    @classmethod
    def from_config_file(
        cls,
        path: str | Path,
        *,
        variables: dict[str, str] | None = None,
        validate: bool = True,
        name: str | None = None,
        load_defaults: dict[str, Any] | None = None,
        base_dir: Path | None = None,
    ) -> Pipeline:
        """Create pipeline from a single YAML config file."""
        return build_from_config_file(
            cls,
            path,
            variables=variables,
            validate=validate,
            name=name,
            load_defaults=load_defaults,
            base_dir=base_dir,
        )

    @classmethod
    def from_dict(
        cls,
        config: dict[str, Any],
        *,
        validate: bool = True,
        name: str | None = None,
        load_defaults: dict[str, Any] | None = None,
        base_dir: Path | None = None,
    ) -> Pipeline:
        """Create pipeline from a config dict."""
        return build_from_dict(
            cls,
            config,
            validate=validate,
            name=name,
            load_defaults=load_defaults,
            base_dir=base_dir,
        )

    @classmethod
    def _build_from_configs(
        cls,
        extract_config: dict[str, Any],
        transform_config: dict[str, Any] | list[dict[str, Any]],
        load_config: dict[str, Any],
        variables: dict[str, str] | None,
        validate: bool,
        name: str | None,
        extract_validation_config: dict[str, Any] | None = None,
        load_validation_config: dict[str, Any] | None = None,
        quality_checks_config: list[dict[str, Any]] | None = None,
        settings: dict[str, Any] | None = None,
        base_dir: Path | None = None,
    ) -> Pipeline:
        """Internal method to build pipeline from resolved configs."""
        return _build_from_configs(
            cls,
            extract_config=extract_config,
            transform_config=transform_config,
            load_config=load_config,
            variables=variables,
            validate=validate,
            name=name,
            extract_validation_config=extract_validation_config,
            load_validation_config=load_validation_config,
            quality_checks_config=quality_checks_config,
            settings=settings,
            base_dir=base_dir,
        )
