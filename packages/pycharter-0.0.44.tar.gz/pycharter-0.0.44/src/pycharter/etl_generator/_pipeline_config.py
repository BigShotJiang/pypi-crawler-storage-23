"""Config-driven Pipeline construction from files, directories, and dicts."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml

if TYPE_CHECKING:
    from pycharter.etl_generator.pipeline import Pipeline

from pycharter.etl_generator._pipeline_helpers import (
    _load_config_input,
    _load_variables_file,
    _resolve_settings,
    _resolve_variables,
    _unwrap_file_section,
)
from pycharter.etl_generator.context import PipelineContext


def build_from_config_files(
    cls: type[Pipeline],
    extract: str | Path | dict[str, Any],
    load: str | Path | dict[str, Any],
    transform: str | Path | dict[str, Any] | list[dict[str, Any]] | None = None,
    variables: str | Path | dict[str, str] | None = None,
    settings: str | Path | dict[str, Any] | None = None,
    *,
    validate: bool = True,
    name: str | None = None,
    load_defaults: dict[str, Any] | None = None,
    base_dir: Path | None = None,
) -> Pipeline:
    """Create pipeline from explicit file paths or dictionaries."""
    variables = _resolve_variables(variables)
    if base_dir is None and isinstance(extract, str | Path):
        base_dir = Path(extract).parent.resolve()

    extract_config = _load_config_input(extract, variables)
    load_config = _load_config_input(load, variables)
    if load_defaults:
        load_config = {**load_defaults, **load_config}
    transform_config = (
        _load_config_input(transform, variables) if transform is not None else {}
    )
    settings_config = _resolve_settings(settings, variables)

    extract_validation_config = (
        extract_config.pop("validation", None)
        if isinstance(extract_config, dict)
        else None
    )
    load_validation_config = (
        load_config.pop("validation", None) if isinstance(load_config, dict) else None
    )
    quality_checks_config = (
        load_config.pop("quality_checks", None)
        if isinstance(load_config, dict)
        else None
    )

    return _build_from_configs(
        cls,
        extract_config=extract_config,
        transform_config=transform_config,
        load_config=load_config,
        variables=variables,
        validate=validate,
        name=name,
        extract_validation_config=extract_validation_config,
        load_validation_config=load_validation_config,
        quality_checks_config=quality_checks_config,
        settings=settings_config,
        base_dir=base_dir,
    )


def build_from_config_dir(
    cls: type[Pipeline],
    directory: str | Path,
    variables: str | Path | dict[str, str] | None = None,
    settings: str | Path | dict[str, Any] | None = None,
    *,
    validate: bool = True,
    name: str | None = None,
    load_defaults: dict[str, Any] | None = None,
    base_dir: Path | None = None,
) -> Pipeline:
    """Create pipeline from a directory (extract.yaml, load.yaml, etc.)."""
    directory = Path(directory)
    if not directory.is_dir():
        raise NotADirectoryError(f"Not a directory: {directory}")

    variables_file = directory / "variables.yaml"
    initial_vars = _load_variables_file(variables_file, {})
    variables = _resolve_variables(variables)
    variables = {**initial_vars, **variables}

    extract_file = directory / "extract.yaml"
    load_file = directory / "load.yaml"
    transform_file = directory / "transform.yaml"
    settings_file = directory / "settings.yaml"
    if not extract_file.exists():
        raise FileNotFoundError(f"Required file not found: {extract_file}")
    if not load_file.exists():
        raise FileNotFoundError(f"Required file not found: {load_file}")

    extract_config = _load_config_input(extract_file, variables)
    load_config = _load_config_input(load_file, variables)
    if load_defaults:
        load_config = {**load_defaults, **load_config}
    transform_config = (
        _load_config_input(transform_file, variables) if transform_file.exists() else {}
    )
    dir_settings = (
        _load_config_input(settings_file, variables) if settings_file.exists() else {}
    )
    if not isinstance(dir_settings, dict):
        dir_settings = {}
    settings_config = {**dir_settings, **_resolve_settings(settings, variables)}

    extract_validation_config = (
        extract_config.pop("validation", None)
        if isinstance(extract_config, dict)
        else None
    )
    load_validation_config = (
        load_config.pop("validation", None) if isinstance(load_config, dict) else None
    )
    quality_checks_config = (
        load_config.pop("quality_checks", None)
        if isinstance(load_config, dict)
        else None
    )

    return _build_from_configs(
        cls,
        extract_config=extract_config,
        transform_config=transform_config,
        load_config=load_config,
        variables=variables,
        validate=validate,
        name=name or directory.name,
        extract_validation_config=extract_validation_config,
        load_validation_config=load_validation_config,
        quality_checks_config=quality_checks_config,
        settings=settings_config,
        base_dir=(base_dir or directory).resolve(),
    )


def build_from_config_file(
    cls: type[Pipeline],
    path: str | Path,
    *,
    variables: dict[str, str] | None = None,
    validate: bool = True,
    name: str | None = None,
    load_defaults: dict[str, Any] | None = None,
    base_dir: Path | None = None,
) -> Pipeline:
    """Create pipeline from a single YAML config file."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    if not path.is_file():
        raise ValueError(f"Not a file: {path}. Use from_config_dir() for directories.")
    with open(path) as f:
        raw_content = f.read()
    raw_config = yaml.safe_load(raw_content) or {}
    file_vars = {}
    if isinstance(raw_config.get("variables"), dict):
        file_vars = {k: str(v) for k, v in raw_config["variables"].items()}
    variables = {**file_vars, **(variables or {})}
    context = PipelineContext(variables=variables)
    resolved_content = context.resolve(raw_content)
    config = yaml.safe_load(resolved_content) or {}
    if "extract" not in config:
        raise ValueError(f"Config file missing 'extract' section: {path}")
    if "load" not in config:
        raise ValueError(f"Config file missing 'load' section: {path}")

    extract_config = config["extract"]
    load_config = config["load"]
    if load_defaults:
        load_config = {**load_defaults, **load_config}
    extract_validation_config = (
        extract_config.pop("validation", None)
        if isinstance(extract_config, dict)
        else None
    )
    load_validation_config = (
        load_config.pop("validation", None) if isinstance(load_config, dict) else None
    )
    quality_checks_config = (
        load_config.pop("quality_checks", None)
        if isinstance(load_config, dict)
        else None
    )
    settings = {}
    for key in ("metadata_store", "dlq", "contract", "lineage"):
        if config.get(key):
            settings[key] = config[key]

    return _build_from_configs(
        cls,
        extract_config=extract_config,
        transform_config=config.get("transform", {}),
        load_config=load_config,
        variables=variables,
        validate=validate,
        name=name if name is not None else config.get("name"),
        extract_validation_config=extract_validation_config,
        load_validation_config=load_validation_config,
        quality_checks_config=quality_checks_config,
        settings=settings,
        base_dir=(base_dir or path.parent).resolve(),
    )


def build_from_dict(
    cls: type[Pipeline],
    config: dict[str, Any],
    *,
    validate: bool = True,
    name: str | None = None,
    load_defaults: dict[str, Any] | None = None,
    base_dir: Path | None = None,
) -> Pipeline:
    """Create pipeline from a config dict with extract, load, and optional sections."""
    if "extract" not in config:
        raise ValueError("Config dict missing 'extract' section")
    if "load" not in config:
        raise ValueError("Config dict missing 'load' section")

    variables = {}
    if isinstance(config.get("variables"), dict):
        variables = {k: str(v) for k, v in config["variables"].items()}

    context = PipelineContext(variables=variables)
    extract_config = context.resolve_dict(config["extract"])
    load_config = context.resolve_dict(config["load"])
    if load_defaults:
        load_config = {**load_defaults, **load_config}

    extract_validation_config = (
        extract_config.pop("validation", None)
        if isinstance(extract_config, dict)
        else None
    )
    load_validation_config = (
        load_config.pop("validation", None) if isinstance(load_config, dict) else None
    )
    quality_checks_config = (
        load_config.pop("quality_checks", None)
        if isinstance(load_config, dict)
        else None
    )

    # Build transform config: normalise file-style input where a YAML file
    # may have a single top-level key (e.g. "transform" or "jsonata").
    transform_config: dict[str, Any] = {}
    raw_transform_input = config.get("transform", {})

    if isinstance(raw_transform_input, dict) and "transform" in raw_transform_input:
        raw_transform = raw_transform_input["transform"]
        jsonata_src = (
            config.get("jsonata")
            if config.get("jsonata") is not None
            else raw_transform_input.get("jsonata")
        )
        custom_src = (
            config.get("custom_function")
            if config.get("custom_function") is not None
            else raw_transform_input.get("custom_function")
        )
    else:
        raw_transform = _unwrap_file_section(raw_transform_input, "transform")
        jsonata_src = config.get("jsonata")
        custom_src = config.get("custom_function")

    if isinstance(raw_transform, list):
        transform_config["transform"] = [
            context.resolve_dict(item) if isinstance(item, dict) else item
            for item in raw_transform
        ]
    elif raw_transform:
        transform_config["transform"] = context.resolve_dict(raw_transform)

    jsonata_val = _unwrap_file_section(jsonata_src, "jsonata")
    if jsonata_val:
        transform_config["jsonata"] = context.resolve_dict(jsonata_val)

    custom_val = _unwrap_file_section(custom_src, "custom_function")
    if custom_val:
        transform_config["custom_function"] = context.resolve_dict(custom_val)

    # Build inline settings from top-level keys
    settings: dict[str, Any] = {}
    for key in ("metadata_store", "dlq", "lineage"):
        if config.get(key):
            val = config[key]
            settings[key] = context.resolve_dict(val) if isinstance(val, dict) else val
    if config.get("contract"):
        settings["contract"] = config["contract"]

    return _build_from_configs(
        cls,
        extract_config=extract_config,
        transform_config=transform_config,
        load_config=load_config,
        variables=variables,
        validate=validate,
        name=name if name is not None else config.get("name"),
        extract_validation_config=extract_validation_config,
        load_validation_config=load_validation_config,
        quality_checks_config=quality_checks_config,
        settings=settings,
        base_dir=base_dir,
    )


def _build_from_configs(
    cls: type[Pipeline],
    extract_config: dict[str, Any],
    transform_config: dict[str, Any] | list[dict[str, Any]],
    load_config: dict[str, Any],
    variables: dict[str, str] | None,
    validate: bool,
    name: str | None,
    extract_validation_config: dict[str, Any] | None = None,
    load_validation_config: dict[str, Any] | None = None,
    quality_checks_config: list[dict[str, Any]] | None = None,
    settings: dict[str, Any] | None = None,
    base_dir: Path | None = None,
) -> Pipeline:
    """Build a Pipeline instance from fully resolved config dicts."""
    from pycharter.etl_generator.config_validator import ConfigValidator
    from pycharter.etl_generator.extractors.factory import ExtractorFactory
    from pycharter.etl_generator.loaders.factory import LoaderFactory

    if validate:
        validator = ConfigValidator(strict=True)
        validator.validate_extract(extract_config)
        if transform_config:
            if isinstance(transform_config, list):
                validator.validate_transform({"transform": transform_config})
            else:
                validator.validate_transform(transform_config)
        validator.validate_load(load_config)
        if settings:
            validator.validate_settings(settings)

    context = PipelineContext(variables=variables)
    extractor = ExtractorFactory.create(extract_config) if extract_config else None
    loader_instance = LoaderFactory.create(load_config) if load_config else None

    if settings and settings.get("plugins"):
        from pycharter.etl_generator._plugins import load_plugins_from_settings

        load_plugins_from_settings(settings)

    return cls(
        extractor=extractor,
        transformers=None,
        loader=loader_instance,
        context=context,
        name=name,
        transform_config=transform_config if transform_config else None,
        extract_validation_config=extract_validation_config,
        load_validation_config=load_validation_config,
        quality_checks_config=quality_checks_config,
        settings=settings or {},
        base_dir=base_dir,
        extract_config_raw=extract_config,
        load_config_raw=load_config,
    )
