"""Quality assurance business logic.

Extracts domain logic from quality route handlers so that routes remain
thin HTTP adapters.  Functions raise domain exceptions (never FastAPI
``HTTPException``) -- callers map them to HTTP responses.
"""

from __future__ import annotations

import json
import logging
import tempfile
import uuid
from pathlib import Path
from typing import Any

from sqlalchemy import desc
from sqlalchemy.orm import Session

from pycharter.metadata_store import MetadataStoreClient
from pycharter.quality import (
    QualityCheck,
    QualityCheckOptions,
    QualityReport,
    QualityThresholds,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Domain exceptions
# ---------------------------------------------------------------------------


class QualityCheckValidationError(ValueError):
    """Raised when quality check request parameters are invalid."""


class QualityMetricNotFoundError(LookupError):
    """Raised when a quality metric cannot be found."""


class QualityReportNotFoundError(LookupError):
    """Raised when quality reports cannot be found for a schema."""


# ---------------------------------------------------------------------------
# Shared helpers (private)
# ---------------------------------------------------------------------------


def _serialize_metric(metric: Any) -> dict[str, Any]:
    """Serialize a QualityMetricModel to a plain dict.

    Args:
        metric: A QualityMetricModel instance.

    Returns:
        Serialized metric dictionary.
    """
    return {
        "id": str(metric.id),
        "schema_id": metric.schema_id,
        "schema_version": metric.schema_version,
        "data_contract_id": (
            str(metric.data_contract_id) if metric.data_contract_id else None
        ),
        "overall_score": metric.overall_score,
        "violation_rate": metric.violation_rate,
        "completeness": metric.completeness,
        "accuracy": metric.accuracy,
        "record_count": metric.record_count,
        "valid_count": metric.valid_count,
        "invalid_count": metric.invalid_count,
        "violation_count": metric.violation_count,
        "field_scores": metric.field_scores,
        "threshold_breaches": metric.threshold_breaches,
        "passed": metric.passed == "true",
        "data_version": metric.data_version,
        "data_source": metric.data_source,
        "data_fingerprint": metric.data_fingerprint,
        "check_timestamp": (
            metric.check_timestamp.isoformat() if metric.check_timestamp else None
        ),
        "created_at": (metric.created_at.isoformat() if metric.created_at else None),
        "updated_at": (metric.updated_at.isoformat() if metric.updated_at else None),
    }


def _parse_json_field(raw: str, field_name: str) -> dict[str, Any]:
    """Parse a JSON string, raising a domain error on failure.

    Args:
        raw: Raw JSON string.
        field_name: Human-readable field name for error messages.

    Returns:
        Parsed dictionary.

    Raises:
        QualityCheckValidationError: If the JSON is invalid.
    """
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise QualityCheckValidationError(f"Invalid {field_name} JSON format") from exc


def _build_quality_options(
    *,
    record_violations: bool,
    calculate_metrics: bool,
    check_thresholds: bool,
    thresholds: dict[str, Any] | None,
    include_field_metrics: bool,
    sample_size: int | None,
    data_source: str | None,
    data_version: str | None,
) -> QualityCheckOptions:
    """Build a QualityCheckOptions from individual parameters.

    Args:
        record_violations: Whether to record violations.
        calculate_metrics: Whether to calculate quality metrics.
        check_thresholds: Whether to check quality thresholds.
        thresholds: Raw thresholds dict (or None).
        include_field_metrics: Whether to include field-level metrics.
        sample_size: Sample size for large datasets.
        data_source: Data source identifier.
        data_version: Data version identifier.

    Returns:
        Configured QualityCheckOptions instance.
    """
    thresholds_obj = None
    if check_thresholds and thresholds:
        thresholds_obj = QualityThresholds(**thresholds)

    return QualityCheckOptions(
        record_violations=record_violations,
        calculate_metrics=calculate_metrics,
        check_thresholds=check_thresholds,
        thresholds=thresholds_obj,
        include_field_metrics=include_field_metrics,
        sample_size=sample_size,
        data_source=data_source,
        data_version=data_version,
    )


# ---------------------------------------------------------------------------
# Public service functions
# ---------------------------------------------------------------------------


def run_quality_check(
    *,
    contract_name: str | None,
    contract_version: str | None,
    contract: dict[str, Any] | None,
    data: list[dict[str, Any]],
    record_violations: bool,
    calculate_metrics: bool,
    check_thresholds: bool,
    thresholds: dict[str, Any] | None,
    include_field_metrics: bool,
    sample_size: int | None,
    data_source: str | None,
    data_version: str | None,
    store: MetadataStoreClient,
    db: Session,
) -> QualityReport:
    """Run a contract quality check against in-memory data.

    Validates data against a contract and calculates quality metrics.
    The system automatically prevents metric inflation by detecting
    duplicate datasets using data fingerprinting.

    Args:
        contract_name: Data contract name (for store-based validation).
        contract_version: Data contract version (for store-based validation).
        contract: Contract dictionary (for contract-based validation).
        data: Data records to validate.
        record_violations: Whether to record violations.
        calculate_metrics: Whether to calculate quality metrics.
        check_thresholds: Whether to check quality thresholds.
        thresholds: Quality thresholds dict.
        include_field_metrics: Whether to include field-level metrics.
        sample_size: Sample size for large datasets.
        data_source: Data source identifier.
        data_version: Data version identifier.
        store: Metadata store client.
        db: Database session for persisting metrics.

    Returns:
        Quality report with metrics and violations.

    Raises:
        QualityCheckValidationError: If required parameters are missing.
    """
    if not (contract_name and contract_version) and not contract:
        raise QualityCheckValidationError(
            "Either (contract_name and contract_version) or contract must be provided"
        )

    quality_check_instance = QualityCheck(
        store=store if (contract_name and contract_version) else None,
        db_session=db,
    )

    options = _build_quality_options(
        record_violations=record_violations,
        calculate_metrics=calculate_metrics,
        check_thresholds=check_thresholds,
        thresholds=thresholds,
        include_field_metrics=include_field_metrics,
        sample_size=sample_size,
        data_source=data_source,
        data_version=data_version,
    )

    return quality_check_instance.run(
        contract_name=contract_name,
        contract_version=contract_version,
        contract=contract,
        data=data,
        options=options,
    )


def run_quality_check_with_file(
    *,
    file_content: bytes,
    filename: str,
    contract_name: str | None,
    contract_version: str | None,
    contract_raw: str | None,
    record_violations: bool,
    calculate_metrics: bool,
    check_thresholds: bool,
    thresholds_raw: str | None,
    include_field_metrics: bool,
    sample_size: int | None,
    data_source: str | None,
    data_version: str | None,
    store: MetadataStoreClient,
    db: Session,
) -> QualityReport:
    """Run a quality check with uploaded file data.

    Writes the file content to a temporary file, validates it against a
    contract, and returns quality metrics. The temp file is always cleaned up.

    Args:
        file_content: Raw bytes of the uploaded file.
        filename: Original filename (used to determine format and default data_source).
        contract_name: Data contract name (for store-based validation).
        contract_version: Data contract version (for store-based validation).
        contract_raw: Contract as a JSON string (for contract-based validation).
        record_violations: Whether to record violations.
        calculate_metrics: Whether to calculate quality metrics.
        check_thresholds: Whether to check quality thresholds.
        thresholds_raw: Quality thresholds as a JSON string.
        include_field_metrics: Whether to include field-level metrics.
        sample_size: Sample size for large datasets.
        data_source: Data source identifier (defaults to filename).
        data_version: Data version identifier.
        store: Metadata store client.
        db: Database session for persisting metrics.

    Returns:
        Quality report with metrics and violations.

    Raises:
        QualityCheckValidationError: If parameters are invalid or file format
            is unsupported.
    """
    if not (contract_name and contract_version) and not contract_raw:
        raise QualityCheckValidationError(
            "Either (contract_name and contract_version) or contract must be provided"
        )

    contract_dict = None
    if contract_raw:
        contract_dict = _parse_json_field(contract_raw, "contract")

    thresholds_dict = None
    if thresholds_raw:
        thresholds_dict = _parse_json_field(thresholds_raw, "thresholds")

    file_extension = Path(filename).suffix.lower()
    if file_extension not in (".json", ".csv"):
        raise QualityCheckValidationError(
            f"Unsupported file format: {file_extension}. "
            "Only JSON and CSV files are supported."
        )

    with tempfile.NamedTemporaryFile(delete=False, suffix=file_extension) as tmp_file:
        tmp_file.write(file_content)
        tmp_file_path = tmp_file.name

    try:
        quality_check_instance = QualityCheck(
            store=store if (contract_name and contract_version) else None,
            db_session=db,
        )

        options = _build_quality_options(
            record_violations=record_violations,
            calculate_metrics=calculate_metrics,
            check_thresholds=check_thresholds,
            thresholds=thresholds_dict,
            include_field_metrics=include_field_metrics,
            sample_size=sample_size,
            data_source=data_source or filename,
            data_version=data_version,
        )

        return quality_check_instance.run(
            contract_name=contract_name,
            contract_version=contract_version,
            contract=contract_dict,
            data=tmp_file_path,
            options=options,
        )
    finally:
        Path(tmp_file_path).unlink(missing_ok=True)


def query_violations(
    *,
    schema_id: str | None,
    start_date: Any,
    end_date: Any,
    severity: str | None,
    violation_status: str | None,
    store: MetadataStoreClient,
) -> tuple[list[Any], dict[str, Any]]:
    """Query data quality violations.

    Args:
        schema_id: Filter by schema ID.
        start_date: Filter violations after this date.
        end_date: Filter violations before this date.
        severity: Filter by severity.
        violation_status: Filter by status.
        store: Metadata store client.

    Returns:
        Tuple of (violation records, summary dict).
    """
    quality_check_instance = QualityCheck(store=store)
    tracker = quality_check_instance.violation_tracker

    violations = tracker.get_violations(
        schema_id=schema_id,
        start_date=start_date,
        end_date=end_date,
        severity=severity,
        status=violation_status,
    )

    summary = tracker.get_violation_summary(schema_id=schema_id)
    return violations, summary


def list_quality_metrics(
    *,
    schema_id: str | None,
    limit: int,
    offset: int,
    db: Session,
) -> dict[str, Any]:
    """List quality metrics from the database.

    Returns quality metrics grouped by schema/data source, showing the
    latest quality check results for each data feed.

    Args:
        schema_id: Optional filter by schema ID.
        limit: Maximum number of results.
        offset: Offset for pagination.
        db: Database session.

    Returns:
        Dictionary with metrics list, total count, limit, and offset.
    """
    from pycharter.db.models.quality_metric import QualityMetricModel

    query = db.query(QualityMetricModel)

    if schema_id:
        query = query.filter(QualityMetricModel.schema_id == schema_id)

    total = query.count()

    metrics = (
        query.order_by(desc(QualityMetricModel.check_timestamp))
        .offset(offset)
        .limit(limit)
        .all()
    )

    return {
        "metrics": [_serialize_metric(m) for m in metrics],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


def get_quality_metric(
    *,
    metric_id: str,
    db: Session,
) -> dict[str, Any]:
    """Get a specific quality metric by ID.

    Args:
        metric_id: Quality metric ID (UUID string).
        db: Database session.

    Returns:
        Serialized quality metric dictionary.

    Raises:
        QualityCheckValidationError: If the metric_id is not a valid UUID.
        QualityMetricNotFoundError: If no metric with the given ID exists.
    """
    from pycharter.db.models.quality_metric import QualityMetricModel

    try:
        metric_uuid = uuid.UUID(metric_id)
    except ValueError as exc:
        raise QualityCheckValidationError(
            f"Invalid metric ID format: {metric_id}"
        ) from exc

    metric = (
        db.query(QualityMetricModel)
        .filter(QualityMetricModel.id == metric_uuid)
        .first()
    )

    if not metric:
        raise QualityMetricNotFoundError(f"Quality metric not found: {metric_id}")

    result = _serialize_metric(metric)
    result["additional_metadata"] = metric.additional_metadata
    return result


def get_quality_reports(
    *,
    schema_id: str,
    data_source: str | None,
    limit: int,
    db: Session,
) -> dict[str, Any]:
    """Get quality reports for a specific schema.

    Returns the latest quality metrics for a schema, optionally filtered
    by data source, with summary statistics.

    Args:
        schema_id: Schema identifier.
        data_source: Optional filter by data source.
        limit: Maximum number of reports to return.
        db: Database session.

    Returns:
        Dictionary with reports list and summary statistics.

    Raises:
        QualityReportNotFoundError: If no reports exist for the schema.
    """
    from pycharter.db.models.quality_metric import QualityMetricModel

    query = db.query(QualityMetricModel).filter(
        QualityMetricModel.schema_id == schema_id
    )

    if data_source:
        query = query.filter(QualityMetricModel.data_source == data_source)

    reports = (
        query.order_by(desc(QualityMetricModel.check_timestamp)).limit(limit).all()
    )

    if not reports:
        raise QualityReportNotFoundError(
            f"No quality reports found for schema: {schema_id}"
        )

    reports_list = []
    for metric in reports:
        entry = _serialize_metric(metric)
        entry["additional_metadata"] = metric.additional_metadata
        reports_list.append(entry)

    latest_report = reports_list[0] if reports_list else None
    avg_score = (
        sum(r["overall_score"] for r in reports_list) / len(reports_list)
        if reports_list
        else 0
    )

    return {
        "schema_id": schema_id,
        "data_source": data_source,
        "reports": reports_list,
        "count": len(reports_list),
        "summary": {
            "latest_score": (latest_report["overall_score"] if latest_report else None),
            "average_score": round(avg_score, 2),
            "latest_check": (
                latest_report["check_timestamp"] if latest_report else None
            ),
            "latest_status": (
                "passed"
                if latest_report and latest_report["passed"]
                else "failed"
                if latest_report
                else None
            ),
        },
    }


def convert_report_to_response(report: QualityReport) -> dict[str, Any]:
    """Convert a QualityReport domain object to an API-friendly dict.

    This returns a dictionary suitable for constructing the response model
    in the route handler.

    Args:
        report: The domain QualityReport from a quality check run.

    Returns:
        Dictionary matching QualityReportResponse fields.
    """
    quality_score_data = None
    if report.quality_score:
        quality_score_data = {
            "overall_score": report.quality_score.overall_score,
            "violation_rate": report.quality_score.violation_rate,
            "completeness": report.quality_score.completeness,
            "accuracy": report.quality_score.accuracy,
            "field_scores": report.quality_score.field_scores,
            "record_count": report.quality_score.record_count,
            "valid_count": report.quality_score.valid_count,
            "invalid_count": report.quality_score.invalid_count,
        }

    field_metrics_data: dict[str, dict[str, Any]] = {}
    for field_name, metrics in report.field_metrics.items():
        field_metrics_data[field_name] = {
            "field_name": metrics.field_name,
            "null_count": metrics.null_count,
            "violation_count": metrics.violation_count,
            "total_count": metrics.total_count,
            "violation_rate": metrics.violation_rate,
            "completeness": metrics.completeness,
            "error_types": metrics.error_types,
        }

    return {
        "schema_id": report.schema_id,
        "schema_version": report.schema_version,
        "check_timestamp": report.check_timestamp,
        "quality_score": quality_score_data,
        "field_metrics": field_metrics_data,
        "violation_count": report.violation_count,
        "record_count": report.record_count,
        "valid_count": report.valid_count,
        "invalid_count": report.invalid_count,
        "threshold_breaches": report.threshold_breaches,
        "passed": report.passed,
        "metadata": report.metadata,
    }
