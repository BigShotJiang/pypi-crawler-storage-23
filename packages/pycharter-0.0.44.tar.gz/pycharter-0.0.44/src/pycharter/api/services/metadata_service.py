"""Service layer for metadata entity CRUD and schema storage operations.

Encapsulates business logic extracted from the metadata route handlers,
keeping route handlers thin and focused on HTTP concerns.
"""

from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel
from sqlalchemy.orm import Session

from pycharter.api.utils import get_by_id_with_fallback, model_to_dict
from pycharter.metadata_store import MetadataStoreClient
from pycharter.utils.version import compare_versions, get_latest_version

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Domain exceptions (no FastAPI dependency)
# ---------------------------------------------------------------------------


class DuplicateEntityError(ValueError):
    """Raised when attempting to create an entity that already exists."""


class EntityNotFoundError(LookupError):
    """Raised when a requested entity cannot be found."""


class DuplicateContractError(ValueError):
    """Raised when a schema contract with the same name+version already exists."""


class InvalidVersionError(ValueError):
    """Raised when a schema version is not higher than the latest existing version."""


class InvalidIdFormatError(ValueError):
    """Raised when an entity ID is not a valid UUID."""


# ---------------------------------------------------------------------------
# Schema storage
# ---------------------------------------------------------------------------


def store_schema(
    schema_name: str,
    version: str,
    schema_data: dict[str, Any],
    store: MetadataStoreClient,
) -> str:
    """Validate version constraints and persist a schema via the metadata store.

    Args:
        schema_name: Human-readable name of the data contract.
        version: SemVer version string for the schema.
        schema_data: JSON Schema definition to store.
        store: Metadata store client instance.

    Returns:
        The contract ID assigned by the metadata store.

    Raises:
        DuplicateContractError: If the same name+version combination exists.
        InvalidVersionError: If the version is not higher than the latest.
        ValueError: If the underlying store rejects the schema.
    """
    existing_contracts = [
        c
        for c in store.list_contracts()
        if (c.get("name") or c.get("title")) == schema_name
    ]

    if existing_contracts:
        for contract in existing_contracts:
            if contract.get("version") == version:
                raise DuplicateContractError(
                    f"Contract '{schema_name}' with version '{version}' already exists. "
                    f"Cannot create duplicate contracts. Use a different version number."
                )

        existing_versions = [
            c.get("version") for c in existing_contracts if c.get("version")
        ]
        latest_version = (
            get_latest_version(existing_versions) if existing_versions else None
        )

        if latest_version:
            version_comparison = compare_versions(version, latest_version)
            if version_comparison <= 0:
                raise InvalidVersionError(
                    f"Version '{version}' must be higher than the latest existing "
                    f"version '{latest_version}' for contract '{schema_name}'. "
                    f"Existing versions: {', '.join(existing_versions)}"
                )

    return store.store_schema(schema_name, version, schema_data)


# ---------------------------------------------------------------------------
# Entity listing
# ---------------------------------------------------------------------------

# Map of URL entity type names to their SQLAlchemy model classes.
# Populated lazily to avoid circular imports at module level.
_ENTITY_MAP: dict[str, type] | None = None

_SUPPORTED_ENTITY_TYPES = frozenset(
    {
        "owners",
        "domains",
        "systems",
        "environments",
        "storage_locations",
        "tags",
    }
)


def _get_entity_map() -> dict[str, type]:
    """Return the entity-type-to-model mapping, importing models lazily."""
    global _ENTITY_MAP  # noqa: PLW0603
    if _ENTITY_MAP is None:
        from pycharter.db.models import (
            DomainModel,
            EnvironmentModel,
            OwnerModel,
            StorageLocationModel,
            SystemModel,
            TagModel,
        )

        _ENTITY_MAP = {
            "owners": OwnerModel,
            "domains": DomainModel,
            "systems": SystemModel,
            "environments": EnvironmentModel,
            "storage_locations": StorageLocationModel,
            "tags": TagModel,
        }
    return _ENTITY_MAP


def list_metadata_entities(
    entity_type: str,
    db: Session,
) -> list[dict[str, Any]]:
    """List all entities of the given type.

    Args:
        entity_type: One of ``owners``, ``domains``, ``systems``,
            ``environments``, ``storage_locations``, ``tags``.
        db: Active SQLAlchemy session.

    Returns:
        List of entity dictionaries.

    Raises:
        EntityNotFoundError: If *entity_type* is not a recognised type.
    """
    entity_map = _get_entity_map()

    if entity_type not in entity_map:
        raise EntityNotFoundError(
            f"Unknown entity type: {entity_type}. "
            f"Supported types: {', '.join(entity_map.keys())}"
        )

    model_class = entity_map[entity_type]
    entities = db.query(model_class).all()

    if entity_type == "storage_locations":
        return _enrich_storage_locations(entities)

    return [model_to_dict(entity) for entity in entities]


# ---------------------------------------------------------------------------
# Generic entity create / update
# ---------------------------------------------------------------------------


def create_entity(
    model_class: type,
    data: BaseModel,
    db: Session,
    *,
    unique_field: str = "name",
) -> dict[str, Any]:
    """Create a new entity after checking for duplicates.

    Args:
        model_class: SQLAlchemy model class to instantiate.
        data: Pydantic request model whose fields map to model columns.
        db: Active SQLAlchemy session.
        unique_field: Column name used for duplicate detection (default ``"name"``).

    Returns:
        Dictionary representation of the newly created entity.

    Raises:
        DuplicateEntityError: If an entity with the same *unique_field* value
            already exists.
    """
    unique_value = getattr(data, unique_field)
    column = getattr(model_class, unique_field)
    existing = db.query(model_class).filter(column == unique_value).first()
    if existing:
        entity_label = model_class.__tablename__.rstrip("s").replace("_", " ")
        raise DuplicateEntityError(
            f"{entity_label.title()} with {unique_field} '{unique_value}' already exists"
        )

    field_values = data.model_dump(exclude_unset=False)
    entity = model_class(**field_values)
    db.add(entity)
    db.commit()
    db.refresh(entity)

    result = model_to_dict(entity)
    if model_class.__tablename__ == "storage_locations":
        _append_storage_location_relations(entity, result)
    return result


def update_entity(
    model_class: type,
    entity_id: str,
    data: BaseModel,
    db: Session,
    *,
    entity_label: str | None = None,
    validate_uuid: bool = True,
) -> dict[str, Any]:
    """Update an existing entity, applying only the fields that are not ``None``.

    Args:
        model_class: SQLAlchemy model class.
        entity_id: Primary-key value (string or UUID-formatted string).
        data: Pydantic update request whose non-``None`` fields should be applied.
        db: Active SQLAlchemy session.
        entity_label: Human-friendly name for error messages (e.g. ``"Owner"``).
            Defaults to the model class name without the ``Model`` suffix.
        validate_uuid: When ``True`` (default), validate *entity_id* as a UUID
            before querying. Set to ``False`` for models with non-UUID primary keys.

    Returns:
        Dictionary representation of the updated entity.

    Raises:
        InvalidIdFormatError: If *validate_uuid* is ``True`` and *entity_id* is
            not a valid UUID string.
        EntityNotFoundError: If no entity with the given ID exists.
    """
    if entity_label is None:
        entity_label = model_class.__name__.replace("Model", "")

    if validate_uuid:
        _ensure_uuid_format(entity_id, entity_label)

    entity = get_by_id_with_fallback(db, model_class, entity_id)
    if entity is None:
        raise EntityNotFoundError(f"{entity_label} with ID '{entity_id}' not found")

    update_fields = data.model_dump(exclude_unset=True)
    for field_name, value in update_fields.items():
        if value is not None:
            setattr(entity, field_name, value)

    db.commit()
    db.refresh(entity)

    result = model_to_dict(entity)
    if model_class.__tablename__ == "storage_locations":
        _append_storage_location_relations(entity, result)
    return result


# ---------------------------------------------------------------------------
# Artifact listing
# ---------------------------------------------------------------------------


def list_artifacts(db: Session) -> dict[str, list[dict[str, Any]]]:
    """List all artifacts grouped by type (schemas, coercion/validation rules, metadata).

    Args:
        db: Active SQLAlchemy session.

    Returns:
        Dictionary keyed by artifact type with lists of ``{title, version, id}``
        dictionaries.
    """
    from pycharter.db.models import (
        CoercionRuleModel,
        MetadataRecordModel,
        SchemaModel,
        ValidationRuleModel,
    )

    schemas = (
        db.query(SchemaModel).order_by(SchemaModel.title, SchemaModel.version).all()
    )
    coercion_rules = (
        db.query(CoercionRuleModel)
        .order_by(CoercionRuleModel.title, CoercionRuleModel.version)
        .all()
    )
    validation_rules = (
        db.query(ValidationRuleModel)
        .order_by(ValidationRuleModel.title, ValidationRuleModel.version)
        .all()
    )
    metadata_records = (
        db.query(MetadataRecordModel)
        .order_by(MetadataRecordModel.title, MetadataRecordModel.version)
        .all()
    )

    return {
        "schemas": [
            {"title": s.title, "version": s.version, "id": str(s.id)} for s in schemas
        ],
        "coercion_rules": [
            {"title": cr.title, "version": cr.version, "id": str(cr.id)}
            for cr in coercion_rules
        ],
        "validation_rules": [
            {"title": vr.title, "version": vr.version, "id": str(vr.id)}
            for vr in validation_rules
        ],
        "metadata": [
            {"title": mr.title, "version": mr.version, "id": str(mr.id)}
            for mr in metadata_records
        ],
    }


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _ensure_uuid_format(value: str, entity_label: str) -> None:
    """Validate that *value* looks like a UUID string."""
    from pycharter.api.utils import ensure_uuid

    try:
        ensure_uuid(value)
    except ValueError:
        raise InvalidIdFormatError(
            f"Invalid {entity_label.lower()} ID format: {value}"
        ) from None


def _enrich_storage_locations(
    entities: list[Any],
) -> list[dict[str, Any]]:
    """Convert storage location models to dicts and attach related names."""
    result: list[dict[str, Any]] = []
    for entity in entities:
        data = model_to_dict(entity)
        if entity.system:
            data["system_name"] = entity.system.name
        if entity.environment:
            data["environment_name"] = entity.environment.name
        result.append(data)
    return result


def _append_storage_location_relations(
    entity: Any,
    result: dict[str, Any],
) -> None:
    """Mutate *result* to include ``system_name`` / ``environment_name``."""
    if entity.system:
        result["system_name"] = entity.system.name
    if entity.environment:
        result["environment_name"] = entity.environment.name
