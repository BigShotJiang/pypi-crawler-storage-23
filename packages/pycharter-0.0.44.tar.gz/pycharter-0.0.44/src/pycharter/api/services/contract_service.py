"""Contract business logic service.

Extracts domain logic from contract route handlers so that routes remain
thin HTTP adapters.  Functions raise domain exceptions (never FastAPI
``HTTPException``) -- callers map them to HTTP responses.
"""

from __future__ import annotations

import logging
import uuid
from contextlib import suppress
from typing import Any

from sqlalchemy.orm import Session

from pycharter import build_contract
from pycharter.api.utils import ensure_uuid, safe_uuid_to_str
from pycharter.contract_builder.builder import ContractArtifacts
from pycharter.db.models import (
    CoercionRuleModel,
    DataContractModel,
    MetadataRecordModel,
    SchemaModel,
    ValidationRuleModel,
)
from pycharter.metadata_store import MetadataStoreClient

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Domain exceptions
# ---------------------------------------------------------------------------


class ContractNotFoundError(LookupError):
    """Raised when a contract or artifact cannot be found."""


class ContractConflictError(ValueError):
    """Raised when a contract or artifact already exists."""


class ArtifactNotFoundError(LookupError):
    """Raised when a referenced artifact cannot be found."""


class ContractBuildError(RuntimeError):
    """Raised when building a contract from artifacts fails."""


# ---------------------------------------------------------------------------
# Shared helpers (private)
# ---------------------------------------------------------------------------


def _get_by_id(db: Session, model: type, id_value: Any, label: str) -> Any:
    """Fetch a record by ID, raising ArtifactNotFoundError if absent.

    Args:
        db: Database session.
        model: SQLAlchemy model class.
        id_value: Primary key value (UUID or str).
        label: Human-readable name for error messages.

    Returns:
        The model instance.

    Raises:
        ArtifactNotFoundError: If no matching record is found.
    """
    from pycharter.api.utils import get_by_id_with_fallback

    record = get_by_id_with_fallback(db, model, id_value)
    if record is None:
        raise ArtifactNotFoundError(
            f"{label} with ID {safe_uuid_to_str(id_value)} not found"
        )
    return record


def _validate_uuid(value: str) -> None:
    """Validate that *value* is a well-formed UUID string.

    Args:
        value: The string to validate.

    Raises:
        ValueError: If the string is not a valid UUID.
    """
    ensure_uuid(value)


# ---------------------------------------------------------------------------
# 3a. build_contract_from_db
# ---------------------------------------------------------------------------


def _fetch_ownership(metadata_record: Any) -> dict[str, Any]:
    """Extract ownership data from a metadata record's relationships.

    Args:
        metadata_record: A MetadataRecordModel instance.

    Returns:
        Ownership dict (may be empty).
    """
    ownership: dict[str, Any] = {}
    with suppress(Exception):
        if (
            hasattr(metadata_record, "business_owners_rel")
            and metadata_record.business_owners_rel
        ):
            owners = [
                {
                    "name": getattr(rel.owner, "name", ""),
                    "email": getattr(rel.owner, "email", ""),
                }
                for rel in metadata_record.business_owners_rel
                if hasattr(rel, "owner") and rel.owner
            ]
            if owners:
                ownership["business_owners"] = owners
    return ownership


def _collect_metadata_artifacts(
    contract: DataContractModel,
    db: Session,
    *,
    include_ownership: bool,
    include_governance: bool,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None, Any]:
    """Load metadata, ownership, and governance data for a contract.

    Args:
        contract: The DataContractModel whose metadata to load.
        db: Database session.
        include_ownership: Whether to extract ownership info.
        include_governance: Whether to include governance rules.

    Returns:
        Tuple of (metadata_data, ownership_data, governance_rules_data).
    """
    if not contract.metadata_record_id:
        return None, None, None

    record = _get_by_id(
        db, MetadataRecordModel, contract.metadata_record_id, "MetadataRecord"
    )

    metadata_data: dict[str, Any] = {"version": record.version}
    if record.description:
        metadata_data["description"] = record.description
    if record.status:
        metadata_data["status"] = record.status

    ownership_data = _fetch_ownership(record) if include_ownership else None
    governance_data = (
        record.governance_rules
        if include_governance and record.governance_rules
        else None
    )
    return metadata_data, ownership_data, governance_data


def build_contract_from_db(
    contract_id: str,
    store: MetadataStoreClient,
    db: Session,
    *,
    include_metadata: bool = True,
    include_ownership: bool = True,
    include_governance: bool = True,
) -> dict[str, Any]:
    """Build a complete contract dict from database artifacts.

    Args:
        contract_id: Contract UUID string.
        store: Metadata store (used for ontology lookup).
        db: Database session.
        include_metadata: Include metadata section.
        include_ownership: Include ownership section.
        include_governance: Include governance rules section.

    Returns:
        The fully assembled contract dictionary.

    Raises:
        ValueError: If *contract_id* is not a valid UUID.
        ContractNotFoundError: If the contract or a required artifact is missing.
        ContractBuildError: If the contract cannot be assembled.
    """
    _validate_uuid(contract_id)

    contract = _get_by_id(db, DataContractModel, contract_id, "Contract")

    if not contract.schema_id:
        raise ContractBuildError(
            f"Contract '{contract.name}' (ID: {contract_id}) does not have a linked schema. "
            "Cannot build contract without a schema."
        )

    schema = _get_by_id(db, SchemaModel, contract.schema_id, "Schema")
    schema_data = dict(schema.schema_data) if schema.schema_data else {}
    if "version" not in schema_data:
        schema_data["version"] = schema.version

    coercion_rules_data = _load_rules(db, CoercionRuleModel, contract.coercion_rules_id)
    validation_rules_data = _load_rules(
        db, ValidationRuleModel, contract.validation_rules_id
    )

    metadata_data, ownership_data, governance_data = _collect_metadata_artifacts(
        contract,
        db,
        include_ownership=include_ownership,
        include_governance=include_governance,
    )

    ontology_data = None
    with suppress(NotImplementedError):
        ontology_data = store.get_ontology(contract.name, contract.version)

    artifacts = ContractArtifacts(
        schema=schema_data,
        coercion_rules=coercion_rules_data,
        validation_rules=validation_rules_data,
        metadata=metadata_data if include_metadata else None,
        ownership=ownership_data,
        governance_rules=governance_data,
        ontology=ontology_data,
    )

    try:
        return build_contract(
            artifacts,
            include_metadata=include_metadata,
            include_ownership=include_ownership,
            include_governance=include_governance,
        )
    except ValueError as exc:
        raise ContractBuildError(f"Failed to build contract: {exc}") from exc


def _load_rules(
    db: Session,
    model: type,
    rules_id: Any,
) -> dict[str, Any] | None:
    """Load coercion or validation rules by ID.

    Args:
        db: Database session.
        model: CoercionRuleModel or ValidationRuleModel.
        rules_id: FK value (UUID, str, or None).

    Returns:
        Dict with ``version`` and ``rules`` keys, or ``None``.
    """
    if not rules_id:
        return None
    record = _get_by_id(db, model, rules_id, model.__name__)
    if record and record.rules:
        return {"version": record.version, "rules": dict(record.rules)}
    return None


# ---------------------------------------------------------------------------
# 3b. create_from_existing_artifacts
# ---------------------------------------------------------------------------


def _find_artifact(
    db: Session,
    model: type,
    title: str | None,
    version: str | None,
    label: str,
) -> uuid.UUID | None:
    """Look up an artifact by title+version, returning its UUID.

    Args:
        db: Database session.
        model: SQLAlchemy model class with ``title`` and ``version`` columns.
        title: Artifact title (may be None).
        version: Artifact version (may be None).
        label: Human-readable name for error messages.

    Returns:
        UUID of the found artifact, or None if title/version not provided.

    Raises:
        ArtifactNotFoundError: If title+version are given but no match exists.
    """
    if not title or not version:
        return None
    record = (
        db.query(model).filter(model.title == title, model.version == version).first()
    )
    if not record:
        raise ArtifactNotFoundError(
            f"{label} not found: title='{title}', version='{version}'"
        )
    return ensure_uuid(record.id)


def create_from_existing_artifacts(
    request: Any,
    db: Session,
) -> DataContractModel:
    """Create a data contract by linking to existing artifacts.

    Args:
        request: A ``ContractCreateFromArtifactsRequest`` instance.
        db: Database session.

    Returns:
        The newly created DataContractModel.

    Raises:
        ContractConflictError: If a contract with the same name+version exists.
        ArtifactNotFoundError: If a referenced artifact cannot be found.
        RuntimeError: If the database commit fails.
    """
    _check_contract_duplicate(db, request.name, request.version)

    schema_id = _find_artifact(
        db, SchemaModel, request.schema_title, request.schema_version, "Schema"
    )
    if schema_id is None:
        raise ArtifactNotFoundError(
            f"Schema not found: title='{request.schema_title}', version='{request.schema_version}'"
        )

    coercion_rules_id = _find_artifact(
        db,
        CoercionRuleModel,
        request.coercion_rules_title,
        request.coercion_rules_version,
        "Coercion rules",
    )
    validation_rules_id = _find_artifact(
        db,
        ValidationRuleModel,
        request.validation_rules_title,
        request.validation_rules_version,
        "Validation rules",
    )
    metadata_record_id = _find_artifact(
        db,
        MetadataRecordModel,
        request.metadata_title,
        request.metadata_version,
        "Metadata",
    )

    new_contract = DataContractModel(
        name=request.name,
        version=request.version,
        status=request.status or "active",
        description=request.description,
        schema_id=schema_id,
        coercion_rules_id=coercion_rules_id,
        validation_rules_id=validation_rules_id,
        metadata_record_id=metadata_record_id,
    )

    try:
        db.add(new_contract)
        db.commit()
        db.refresh(new_contract)
    except Exception as exc:
        db.rollback()
        logger.error("Error creating contract from artifacts: %s", exc, exc_info=True)
        raise RuntimeError(f"Failed to create contract: {exc}") from exc

    return new_contract


def _check_contract_duplicate(db: Session, name: str, version: str) -> None:
    """Raise ContractConflictError if a contract with *name*/*version* exists.

    Args:
        db: Database session.
        name: Contract name.
        version: Contract version.

    Raises:
        ContractConflictError: If a matching contract exists.
    """
    existing = (
        db.query(DataContractModel)
        .filter(DataContractModel.name == name, DataContractModel.version == version)
        .first()
    )
    if existing:
        total = db.query(DataContractModel).count()
        logger.warning(
            "Contract '%s' v'%s' already exists. Total contracts: %s. ID: %s",
            name,
            version,
            total,
            safe_uuid_to_str(existing.id),
        )
        raise ContractConflictError(
            f"Contract '{name}' with version '{version}' already exists "
            f"(ID: {safe_uuid_to_str(existing.id)})"
        )


# ---------------------------------------------------------------------------
# 3c. create_mixed -- sub-resolvers
# ---------------------------------------------------------------------------


def _resolve_schema(
    request: Any,
    store: MetadataStoreClient,
    db: Session,
) -> uuid.UUID | None:
    """Resolve schema: create new via store or find existing by title+version.

    Args:
        request: A ``ContractCreateMixedRequest`` instance.
        store: Metadata store for creating new artifacts.
        db: Database session.

    Returns:
        UUID of the schema, or None if resolution fails silently.

    Raises:
        ContractConflictError: If the schema or contract already exists.
        ArtifactNotFoundError: If an existing schema cannot be found.
        ValueError: If schema creation fails for a non-conflict reason.
    """
    if request.schema is not None:
        return _create_new_schema(request, store, db)
    if request.schema_title and request.schema_version:
        return _find_existing_schema(request, db)
    return None


def _create_new_schema(
    request: Any,
    store: MetadataStoreClient,
    db: Session,
) -> uuid.UUID | None:
    """Create a new schema artifact via the metadata store.

    Args:
        request: Request with ``name``, ``version``, ``schema`` fields.
        store: Metadata store client.
        db: Database session.

    Returns:
        UUID of the schema created by the store.

    Raises:
        ContractConflictError: If the schema already exists.
        ValueError: If schema creation fails.
    """
    try:
        store.store_schema(request.name, request.version, request.schema)
        dc = (
            db.query(DataContractModel)
            .filter(
                DataContractModel.name == request.name,
                DataContractModel.version == request.version,
            )
            .first()
        )
        return dc.schema_id if dc else None
    except ValueError as exc:
        error_msg = str(exc)
        if "already exists" in error_msg.lower():
            schema_title = request.schema.get("title") or request.name
            schema_version = request.schema.get("version") or request.version
            raise ContractConflictError(
                f"Schema artifact '{schema_title}' v'{schema_version}' already exists. "
                "To use this existing schema, select 'Use Existing' mode and pick it by title and version. "
                "To create a new schema artifact, use a different version number in your schema JSON."
            ) from exc
        raise


def _find_existing_schema(request: Any, db: Session) -> uuid.UUID | None:
    """Find an existing schema by title+version, checking for contract duplicates.

    Args:
        request: Request with ``name``, ``version``, ``schema_title``, ``schema_version``.
        db: Database session.

    Returns:
        UUID of the found schema.

    Raises:
        ContractConflictError: If a contract with the same name+version exists.
        ArtifactNotFoundError: If the schema is not found.
    """
    _check_contract_duplicate(db, request.name, request.version)

    schema = (
        db.query(SchemaModel)
        .filter(
            SchemaModel.title == request.schema_title,
            SchemaModel.version == request.schema_version,
        )
        .first()
    )
    if not schema:
        raise ArtifactNotFoundError(
            f"Schema not found: title='{request.schema_title}', version='{request.schema_version}'"
        )
    return ensure_uuid(schema.id)


def _resolve_rules(
    request_data: dict[str, Any] | None,
    request_title: str | None,
    request_version: str | None,
    contract_name: str,
    contract_version: str,
    store_fn: Any,
    db: Session,
    model: type,
    label: str,
) -> uuid.UUID | None:
    """Resolve a rules artifact: create new or find existing.

    Args:
        request_data: New rules data dict, or None.
        request_title: Existing artifact title, or None.
        request_version: Existing artifact version, or None.
        contract_name: Parent contract name.
        contract_version: Parent contract version.
        store_fn: Callable to store new artifact (e.g. store.store_coercion_rules).
        db: Database session.
        model: SQLAlchemy model for DB lookup.
        label: Human-readable label for error messages.

    Returns:
        UUID of the resolved artifact, or None.

    Raises:
        ContractConflictError: If the artifact already exists.
        ArtifactNotFoundError: If an existing artifact cannot be found.
        ValueError: If creation fails for a non-conflict reason.
    """
    if request_data is not None and len(request_data) > 0:
        return _create_new_rules(
            request_data, contract_name, contract_version, store_fn, label
        )
    if request_title and request_version:
        return _find_artifact(db, model, request_title, request_version, label)
    return None


def _create_new_rules(
    data: dict[str, Any],
    contract_name: str,
    contract_version: str,
    store_fn: Any,
    label: str,
) -> uuid.UUID | None:
    """Create a new rules artifact via a store method.

    Args:
        data: The rules payload.
        contract_name: Parent contract name.
        contract_version: Parent contract version.
        store_fn: Store method to call.
        label: Human-readable label.

    Returns:
        UUID of the newly created artifact.

    Raises:
        ContractConflictError: If the artifact already exists.
        ValueError: If creation fails for a non-conflict reason.
    """
    try:
        result_id = store_fn(contract_name, contract_version, data)
        return ensure_uuid(result_id) if result_id else None
    except ValueError as exc:
        if "already exists" in str(exc).lower():
            raise ContractConflictError(
                f"{label} artifact already exists with this version. "
                f"To use existing {label.lower()}, select 'Use Existing' mode. "
                f"To create new {label.lower()}, the artifact version must be unique."
            ) from exc
        raise


def _resolve_metadata(
    request: Any,
    store: MetadataStoreClient,
    db: Session,
) -> uuid.UUID | None:
    """Resolve metadata: create new via store or find existing by title+version.

    Args:
        request: A ``ContractCreateMixedRequest`` instance.
        store: Metadata store for creating new artifacts.
        db: Database session.

    Returns:
        UUID of the metadata record, or None.

    Raises:
        ContractConflictError: If the metadata artifact already exists.
        ArtifactNotFoundError: If an existing metadata record cannot be found.
        ValueError: If metadata creation fails for a non-conflict reason.
    """
    if request.metadata is not None and len(request.metadata) > 0:
        return _create_new_rules(
            request.metadata,
            request.name,
            request.version,
            store.store_metadata,
            "Metadata",
        )
    if request.metadata_title and request.metadata_version:
        return _find_artifact(
            db,
            MetadataRecordModel,
            request.metadata_title,
            request.metadata_version,
            "Metadata",
        )
    return None


def _validate_artifact_ids(
    ids: dict[str, uuid.UUID | None],
) -> None:
    """Validate that all non-None IDs are UUID objects.

    Args:
        ids: Mapping of id_name to id_value.

    Raises:
        ValueError: If any non-None value is not a uuid.UUID.
    """
    for id_name, id_value in ids.items():
        if id_value is not None and not isinstance(id_value, uuid.UUID):
            raise ValueError(
                f"Invalid {id_name} type: {type(id_value)} (value: {id_value}). "
                "Expected uuid.UUID or None."
            )


def _verify_artifacts_exist(
    db: Session,
    ids: dict[str, tuple[type, uuid.UUID | None]],
) -> None:
    """Verify that all referenced artifacts exist in the database.

    Args:
        db: Database session.
        ids: Mapping of label to (model_class, uuid_value).

    Raises:
        ArtifactNotFoundError: If an artifact cannot be found.
    """
    for label, (model, id_value) in ids.items():
        if id_value is None:
            continue
        exists = db.query(model).filter(model.id == id_value).first()
        if not exists:
            raise ArtifactNotFoundError(
                f"{label} with ID '{id_value}' not found in database. "
                "This may indicate the artifact was created in a different database or was deleted."
            )


def _update_contract_fields(
    new_contract: DataContractModel,
    request: Any,
    db: Session,
) -> None:
    """Update status/description on an existing contract if needed.

    Args:
        new_contract: The contract to update.
        request: Request with ``status`` and ``description`` fields.
        db: Database session.

    Raises:
        RuntimeError: If the commit fails.
    """
    needs_update = False
    if request.status and new_contract.status != request.status:
        new_contract.status = request.status
        needs_update = True
    if (
        request.description is not None
        and new_contract.description != request.description
    ):
        new_contract.description = request.description
        needs_update = True

    if needs_update:
        try:
            db.commit()
            db.refresh(new_contract)
        except Exception as exc:
            db.rollback()
            logger.error(
                "Error updating contract status/description: %s", exc, exc_info=True
            )
            raise RuntimeError(f"Failed to update contract: {exc}") from exc


def create_mixed(
    request: Any,
    store: MetadataStoreClient,
    db: Session,
) -> DataContractModel:
    """Create a data contract with a mix of new and existing artifacts.

    Args:
        request: A ``ContractCreateMixedRequest`` instance.
        store: Metadata store client.
        db: Database session.

    Returns:
        The created or updated DataContractModel.

    Raises:
        ContractConflictError: If the contract or an artifact already exists.
        ArtifactNotFoundError: If a referenced artifact cannot be found.
        ValueError: If UUID validation fails or creation fails.
        RuntimeError: If the database commit fails.
    """
    schema_id = _resolve_schema(request, store, db)

    coercion_rules_id = _resolve_rules(
        request.coercion_rules,
        request.coercion_rules_title,
        request.coercion_rules_version,
        request.name,
        request.version,
        store.store_coercion_rules,
        db,
        CoercionRuleModel,
        "Coercion rules",
    )
    validation_rules_id = _resolve_rules(
        request.validation_rules,
        request.validation_rules_title,
        request.validation_rules_version,
        request.name,
        request.version,
        store.store_validation_rules,
        db,
        ValidationRuleModel,
        "Validation rules",
    )
    metadata_record_id = _resolve_metadata(request, store, db)

    db.expire_all()

    new_contract = (
        db.query(DataContractModel)
        .filter(
            DataContractModel.name == request.name,
            DataContractModel.version == request.version,
        )
        .first()
    )

    if new_contract:
        _update_contract_fields(new_contract, request, db)
        return new_contract

    return _create_fallback_contract(
        request,
        schema_id,
        coercion_rules_id,
        validation_rules_id,
        metadata_record_id,
        db,
    )


def _create_fallback_contract(
    request: Any,
    schema_id: uuid.UUID | None,
    coercion_rules_id: uuid.UUID | None,
    validation_rules_id: uuid.UUID | None,
    metadata_record_id: uuid.UUID | None,
    db: Session,
) -> DataContractModel:
    """Create a contract when store methods did not create one automatically.

    Args:
        request: The original request.
        schema_id: Resolved schema UUID.
        coercion_rules_id: Resolved coercion rules UUID.
        validation_rules_id: Resolved validation rules UUID.
        metadata_record_id: Resolved metadata record UUID.
        db: Database session.

    Returns:
        The newly created DataContractModel.

    Raises:
        ValueError: If UUID types are invalid.
        ArtifactNotFoundError: If referenced artifacts don't exist.
        RuntimeError: If the database commit fails.
    """
    logger.info(
        "Contract not found after store operations, creating new one: %s v%s",
        request.name,
        request.version,
    )

    final_ids = {
        "schema_id": ensure_uuid(schema_id) if schema_id else None,
        "coercion_rules_id": ensure_uuid(coercion_rules_id)
        if coercion_rules_id
        else None,
        "validation_rules_id": ensure_uuid(validation_rules_id)
        if validation_rules_id
        else None,
        "metadata_record_id": ensure_uuid(metadata_record_id)
        if metadata_record_id
        else None,
    }
    _validate_artifact_ids(final_ids)

    _verify_artifacts_exist(
        db,
        {
            "Schema": (SchemaModel, final_ids["schema_id"]),
            "Coercion rules": (CoercionRuleModel, final_ids["coercion_rules_id"]),
            "Validation rules": (ValidationRuleModel, final_ids["validation_rules_id"]),
            "Metadata record": (MetadataRecordModel, final_ids["metadata_record_id"]),
        },
    )

    logger.debug(
        "Creating contract with IDs - schema_id type: %s, "
        "coercion_rules_id type: %s, validation_rules_id type: %s, "
        "metadata_record_id type: %s",
        type(final_ids["schema_id"]),
        type(final_ids["coercion_rules_id"]),
        type(final_ids["validation_rules_id"]),
        type(final_ids["metadata_record_id"]),
    )

    # If we created artifacts via store, the data_contract row may already exist
    if request.schema is not None:
        existing_dc = (
            db.query(DataContractModel)
            .filter(
                DataContractModel.name == request.name,
                DataContractModel.version == request.version,
            )
            .first()
        )
        if existing_dc:
            return existing_dc

    new_contract = DataContractModel(
        name=request.name,
        version=request.version,
        status=request.status or "active",
        description=request.description,
        schema_id=final_ids["schema_id"],
        coercion_rules_id=final_ids["coercion_rules_id"],
        validation_rules_id=final_ids["validation_rules_id"],
        metadata_record_id=final_ids["metadata_record_id"],
    )

    try:
        db.add(new_contract)
        db.commit()
        db.refresh(new_contract)
    except Exception as exc:
        db.rollback()
        _handle_create_error(exc, final_ids)

    return new_contract


def _handle_create_error(
    exc: Exception,
    final_ids: dict[str, uuid.UUID | None],
) -> None:
    """Handle errors from contract creation, enriching FK messages.

    Args:
        exc: The original exception.
        final_ids: The artifact IDs that were used.

    Raises:
        RuntimeError: Always, with an enriched message.
    """
    error_msg = str(exc)
    logger.error("Error creating contract with mixed artifacts: %s", exc, exc_info=True)

    if (
        "foreign key constraint" in error_msg.lower()
        or "FOREIGN KEY constraint failed" in error_msg
    ):
        logger.error(
            "Foreign key constraint failed. IDs: schema=%s, coercion=%s, validation=%s, metadata=%s",
            final_ids["schema_id"],
            final_ids["coercion_rules_id"],
            final_ids["validation_rules_id"],
            final_ids["metadata_record_id"],
        )
        raise RuntimeError(
            "Failed to create contract: One or more referenced artifacts do not exist in the database. "
            "Please verify that all artifacts exist in the current database before creating the contract. "
            f"Error: {error_msg}"
        ) from exc

    raise RuntimeError(f"Failed to create contract: {error_msg}") from exc


# ---------------------------------------------------------------------------
# 3d. update_fields
# ---------------------------------------------------------------------------


def update_fields(
    contract_id: str,
    request: Any,
    db: Session,
) -> DataContractModel:
    """Update a contract's metadata fields.

    Args:
        contract_id: Contract UUID string.
        request: A ``ContractUpdateRequest`` instance.
        db: Database session.

    Returns:
        The updated DataContractModel.

    Raises:
        ValueError: If *contract_id* is not a valid UUID or no fields provided.
        ContractNotFoundError: If the contract does not exist.
        ContractConflictError: If name+version would clash with another contract.
        RuntimeError: If the database update fails.
    """
    _validate_uuid(contract_id)

    contract = _get_by_id(db, DataContractModel, contract_id, "Contract")

    _check_update_has_fields(request)
    _check_name_version_unique(request, contract, db)

    _execute_raw_update(contract_id, contract, request, db)

    db.expire(contract)
    return _get_by_id(db, DataContractModel, contract_id, "Contract")


def _check_update_has_fields(request: Any) -> None:
    """Ensure at least one update field is provided.

    Args:
        request: A ``ContractUpdateRequest`` instance.

    Raises:
        ValueError: If no fields are provided.
    """
    if not any(
        [
            request.name,
            request.version,
            request.status is not None,
            request.description is not None,
        ]
    ):
        raise ValueError("At least one field must be provided for update")


def _check_name_version_unique(
    request: Any,
    contract: DataContractModel,
    db: Session,
) -> None:
    """Check that the new name+version combination is unique.

    Args:
        request: Update request.
        contract: Current contract model.
        db: Database session.

    Raises:
        ContractConflictError: If another contract with the same name+version exists.
    """
    if not (request.name or request.version):
        return

    new_name = request.name if request.name else contract.name
    new_version = request.version if request.version else contract.version

    existing = (
        db.query(DataContractModel)
        .filter(
            DataContractModel.name == new_name,
            DataContractModel.version == new_version,
            DataContractModel.id != contract.id,
        )
        .first()
    )
    if existing:
        raise ContractConflictError(
            f"Contract with name '{new_name}' and version '{new_version}' already exists"
        )


def _build_set_clauses(request: Any) -> tuple[list[str], dict[str, Any]]:
    """Build SQL SET clauses from a ContractUpdateRequest.

    Args:
        request: Update request.

    Returns:
        Tuple of (set_clause_strings, params_dict).
    """
    clauses: list[str] = []
    params: dict[str, Any] = {}

    if request.name is not None:
        clauses.append("name = :name")
        params["name"] = request.name
    if request.version is not None:
        clauses.append("version = :version")
        params["version"] = request.version
    if request.status is not None:
        clauses.append("status = :status")
        params["status"] = request.status
    if request.description is not None:
        clauses.append("description = :description")
        params["description"] = request.description

    clauses.append("updated_at = CURRENT_TIMESTAMP")
    return clauses, params


def _execute_raw_update(
    contract_id: str,
    contract: DataContractModel,
    request: Any,
    db: Session,
) -> None:
    """Execute a raw SQL UPDATE for the contract.

    Args:
        contract_id: Contract UUID string.
        contract: Current contract model.
        request: Update request.
        db: Database session.

    Raises:
        ContractNotFoundError: If no rows are updated after all fallback attempts.
        RuntimeError: If the update or commit fails.
    """
    from sqlalchemy import text

    set_clauses, params = _build_set_clauses(request)
    set_clause = ", ".join(set_clauses)
    contract_id_str = safe_uuid_to_str(contract.id) or contract_id

    engine = db.bind if hasattr(db, "bind") else None
    is_sqlite = engine and "sqlite" in str(engine.url)

    try:
        _do_update(db, set_clause, params, contract_id_str, contract, is_sqlite, text)
        db.commit()
    except (ContractNotFoundError, RuntimeError):
        db.rollback()
        raise
    except Exception as exc:
        db.rollback()
        logger.error("Error updating contract: %s", exc, exc_info=True)
        raise RuntimeError(f"Failed to update contract: {exc}") from exc


def _do_update(
    db: Session,
    set_clause: str,
    params: dict[str, Any],
    contract_id_str: str,
    contract: DataContractModel,
    is_sqlite: bool,
    text: Any,
) -> None:
    """Try multiple SQL strategies to update the contract row.

    Args:
        db: Database session.
        set_clause: SQL SET clause string.
        params: Query parameters.
        contract_id_str: Contract ID as string.
        contract: Contract model instance.
        is_sqlite: Whether using SQLite backend.
        text: SQLAlchemy ``text`` function.

    Raises:
        ContractNotFoundError: If no rows are updated.
    """
    table = "data_contracts" if is_sqlite else "pycharter.data_contracts"
    params["contract_id"] = contract_id_str

    if is_sqlite:
        sql = f"UPDATE {table} SET {set_clause} WHERE id = :contract_id"
    else:
        sql = f"UPDATE {table} SET {set_clause} WHERE id = :contract_id::uuid"

    result = db.execute(text(sql), params)
    if result.rowcount > 0:
        return

    # Fallback: alternative comparison
    if is_sqlite:
        fallback = (
            f"UPDATE {table} SET {set_clause} WHERE CAST(id AS TEXT) = :contract_id"
        )
    else:
        fallback = f"UPDATE {table} SET {set_clause} WHERE id::text = :contract_id"

    params["contract_id"] = contract_id_str
    result = db.execute(text(fallback), params)
    if result.rowcount > 0:
        return

    # Last resort for PostgreSQL: try UUID object
    if not is_sqlite:
        uuid_sql = f"UPDATE {table} SET {set_clause} WHERE id = :contract_id"
        params["contract_id"] = contract.id
        result = db.execute(text(uuid_sql), params)
        if result.rowcount > 0:
            return

    raise ContractNotFoundError(
        f"Contract not found or could not be updated: {contract_id_str}"
    )
