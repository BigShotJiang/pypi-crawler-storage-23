"""Route handlers for quality assurance."""

from __future__ import annotations

from typing import Any

from fastapi import (
    APIRouter,
    Body,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    UploadFile,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from pycharter.api.dependencies.database import get_db_session
from pycharter.api.dependencies.store import get_metadata_store
from pycharter.api.models.quality import (
    FieldQualityMetricsResponse,
    QualityCheckRequest,
    QualityReportResponse,
    QualityScoreResponse,
    ViolationQueryRequest,
    ViolationRecordResponse,
    ViolationsResponse,
)
from pycharter.api.services.quality_service import (
    QualityCheckValidationError,
    QualityMetricNotFoundError,
    QualityReportNotFoundError,
    convert_report_to_response,
)
from pycharter.api.services.quality_service import (
    get_quality_metric as svc_get_quality_metric,
)
from pycharter.api.services.quality_service import (
    get_quality_reports as svc_get_quality_reports,
)
from pycharter.api.services.quality_service import (
    list_quality_metrics as svc_list_quality_metrics,
)
from pycharter.api.services.quality_service import (
    query_violations as svc_query_violations,
)
from pycharter.api.services.quality_service import (
    run_quality_check as svc_run_quality_check,
)
from pycharter.api.services.quality_service import (
    run_quality_check_with_file as svc_run_quality_check_with_file,
)
from pycharter.metadata_store import MetadataStoreClient

router = APIRouter(tags=["Quality"])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_report_response(report_dict: dict) -> QualityReportResponse:
    """Convert a service-layer report dict into a response model."""
    quality_score = None
    if report_dict["quality_score"]:
        quality_score = QualityScoreResponse(**report_dict["quality_score"])

    field_metrics = {
        name: FieldQualityMetricsResponse(**data)
        for name, data in report_dict["field_metrics"].items()
    }

    return QualityReportResponse(
        schema_id=report_dict["schema_id"],
        schema_version=report_dict["schema_version"],
        check_timestamp=report_dict["check_timestamp"],
        quality_score=quality_score,
        field_metrics=field_metrics,
        violation_count=report_dict["violation_count"],
        record_count=report_dict["record_count"],
        valid_count=report_dict["valid_count"],
        invalid_count=report_dict["invalid_count"],
        threshold_breaches=report_dict["threshold_breaches"],
        passed=report_dict["passed"],
        metadata=report_dict["metadata"],
    )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.post(
    "/quality/check",
    response_model=QualityReportResponse,
    status_code=status.HTTP_200_OK,
    summary="Run contract (row-based) quality check",
    description=(
        "Run a contract quality check: validate each row against a data "
        "contract and compute row-based metrics (accuracy, completeness, "
        "per-record results). Use this for record-level validation. For "
        "column/dataset-level checks (e.g. row count, null rate) on ETL "
        "pipelines, use the ETL run with quality_checks in load config."
    ),
    response_description="Contract quality report with metrics and violations",
)
async def quality_check(
    request: QualityCheckRequest,
    store: MetadataStoreClient = Depends(get_metadata_store),
    db: Session = Depends(get_db_session),
) -> QualityReportResponse:
    """Run a quality check against a data contract."""
    try:
        report = svc_run_quality_check(
            contract_name=request.contract_name,
            contract_version=request.contract_version,
            contract=request.contract,
            data=request.data,
            record_violations=request.record_violations,
            calculate_metrics=request.calculate_metrics,
            check_thresholds=request.check_thresholds,
            thresholds=request.thresholds,
            include_field_metrics=request.include_field_metrics,
            sample_size=request.sample_size,
            data_source=request.data_source,
            data_version=request.data_version,
            store=store,
            db=db,
        )
    except QualityCheckValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc

    return _build_report_response(convert_report_to_response(report))


@router.post(
    "/quality/check/upload",
    response_model=QualityReportResponse,
    status_code=status.HTTP_200_OK,
    summary="Run quality check with file upload",
    description=(
        "Run a quality check against a data contract using an uploaded "
        "file (JSON or CSV). The system automatically prevents metric "
        "inflation by detecting duplicate datasets."
    ),
    response_description="Quality check report",
)
async def quality_check_upload(
    file: UploadFile = File(..., description="Data file (JSON or CSV)"),
    contract_name: str | None = Form(
        None, description="Data contract name (for store-based validation)"
    ),
    contract_version: str | None = Form(
        None, description="Data contract version (for store-based validation)"
    ),
    contract: str | None = Form(
        None, description="Contract JSON string (for contract-based validation)"
    ),
    record_violations: bool = Form(True, description="Record violations"),
    calculate_metrics: bool = Form(True, description="Calculate quality metrics"),
    check_thresholds: bool = Form(False, description="Check quality thresholds"),
    thresholds: str | None = Form(None, description="Quality thresholds JSON string"),
    include_field_metrics: bool = Form(True, description="Include field-level metrics"),
    sample_size: int | None = Form(None, description="Sample size for large datasets"),
    data_source: str | None = Form(
        None, description="Data source identifier (e.g., file name)"
    ),
    data_version: str | None = Form(None, description="Data version identifier"),
    store: MetadataStoreClient = Depends(get_metadata_store),
    db: Session = Depends(get_db_session),
) -> QualityReportResponse:
    """Run a quality check with an uploaded file (JSON or CSV)."""
    try:
        content = await file.read()
        report = svc_run_quality_check_with_file(
            file_content=content,
            filename=file.filename,
            contract_name=contract_name,
            contract_version=contract_version,
            contract_raw=contract,
            record_violations=record_violations,
            calculate_metrics=calculate_metrics,
            check_thresholds=check_thresholds,
            thresholds_raw=thresholds,
            include_field_metrics=include_field_metrics,
            sample_size=sample_size,
            data_source=data_source,
            data_version=data_version,
            store=store,
            db=db,
        )
    except QualityCheckValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Quality check failed: {exc}",
        ) from exc

    return _build_report_response(convert_report_to_response(report))


@router.post(
    "/quality/violations",
    response_model=ViolationsResponse,
    status_code=status.HTTP_200_OK,
    summary="Query violations",
    description="Query data quality violations",
    response_description="List of violations",
)
async def query_violations_route(
    request: ViolationQueryRequest,
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> ViolationsResponse:
    """Query data quality violations."""
    try:
        violations, summary = svc_query_violations(
            schema_id=request.schema_id,
            start_date=request.start_date,
            end_date=request.end_date,
            severity=request.severity,
            violation_status=request.status,
            store=store,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to query violations: {exc}",
        ) from exc

    violation_responses = [
        ViolationRecordResponse(
            id=str(v.id),
            schema_id=v.schema_id,
            record_id=v.record_id,
            severity=v.severity,
            status=v.status,
            field_violations=v.field_violations,
            error_count=len(v.field_violations),
            timestamp=v.timestamp,
            resolved_at=v.resolved_at,
            resolved_by=v.resolved_by,
            metadata=v.metadata,
        )
        for v in violations
    ]

    return ViolationsResponse(
        violations=violation_responses,
        total=len(violation_responses),
        summary=summary,
    )


@router.get(
    "/quality/metrics",
    status_code=status.HTTP_200_OK,
    summary="List quality metrics",
    description="Retrieve quality metrics for different data feeds/schemas",
    response_description="List of quality metrics",
)
async def list_quality_metrics(
    schema_id: str | None = Query(None, description="Filter by schema ID"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of results"),
    offset: int = Query(0, ge=0, description="Offset for pagination"),
    db: Session = Depends(get_db_session),
) -> dict:
    """List quality metrics from the database."""
    try:
        return svc_list_quality_metrics(
            schema_id=schema_id, limit=limit, offset=offset, db=db
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve quality metrics: {exc}",
        ) from exc


@router.get(
    "/quality/metrics/{metric_id}",
    status_code=status.HTTP_200_OK,
    summary="Get quality metric by ID",
    description="Retrieve a specific quality metric from the database by its ID",
    response_description="Quality metric details",
)
async def get_quality_metric(
    metric_id: str,
    db: Session = Depends(get_db_session),
) -> dict:
    """Get a specific quality metric from the database by ID."""
    try:
        return svc_get_quality_metric(metric_id=metric_id, db=db)
    except QualityCheckValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc
    except QualityMetricNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get quality metric: {exc}",
        ) from exc


@router.get(
    "/quality/reports/{schema_id}",
    status_code=status.HTTP_200_OK,
    summary="Get quality report for schema",
    description="Retrieve the latest quality report for a specific schema/data feed",
    response_description="Quality report with metrics",
)
async def get_quality_report(
    schema_id: str,
    data_source: str | None = Query(None, description="Filter by data source"),
    limit: int = Query(
        10, ge=1, le=100, description="Maximum number of reports to return"
    ),
    db: Session = Depends(get_db_session),
) -> dict:
    """Get quality reports for a specific schema."""
    try:
        return svc_get_quality_reports(
            schema_id=schema_id, data_source=data_source, limit=limit, db=db
        )
    except QualityReportNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get quality report: {exc}",
        ) from exc


# ---------------------------------------------------------------------------
# Thresholds (SLA) endpoints
# ---------------------------------------------------------------------------


class ThresholdsUpdateRequest(BaseModel):
    """Request body for updating SLA thresholds."""

    min_overall_score: float = Field(95.0, ge=0.0, le=100.0)
    max_violation_rate: float = Field(0.05, ge=0.0, le=1.0)
    min_completeness: float = Field(0.95, ge=0.0, le=1.0)
    min_accuracy: float = Field(0.95, ge=0.0, le=1.0)
    field_thresholds: dict[str, dict[str, float]] = Field(default_factory=dict)


@router.get(
    "/quality/thresholds/{name}/{version}",
    status_code=status.HTTP_200_OK,
    summary="Get SLA thresholds for a contract",
    description="Retrieve the quality SLA thresholds defined in a data contract's metadata.",
    response_description="Current SLA thresholds",
)
async def get_thresholds(
    name: str,
    version: str,
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> dict[str, Any]:
    """Get quality SLA thresholds from a data contract."""
    try:
        metadata = store.get_metadata(name, version)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve contract metadata: {exc}",
        ) from exc

    if not metadata:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Contract not found: {name}:{version}",
        )

    dq = metadata.get("data_quality") if isinstance(metadata, dict) else {}
    sla = (dq or {}).get("sla") if isinstance(dq, dict) else None

    return {
        "contract_name": name,
        "contract_version": version,
        "sla": sla,
        "has_sla": sla is not None,
    }


@router.put(
    "/quality/thresholds/{name}/{version}",
    status_code=status.HTTP_200_OK,
    summary="Update SLA thresholds for a contract",
    description="Update the quality SLA thresholds in a data contract's metadata.",
    response_description="Updated SLA thresholds",
)
async def update_thresholds(
    name: str,
    version: str,
    request: ThresholdsUpdateRequest = Body(...),
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> dict[str, Any]:
    """Update quality SLA thresholds in a data contract."""
    try:
        metadata = store.get_metadata(name, version)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve contract metadata: {exc}",
        ) from exc

    if not metadata:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Contract not found: {name}:{version}",
        )

    # Update the data_quality.sla section
    if not isinstance(metadata, dict):
        metadata = {}

    dq = metadata.get("data_quality", {}) or {}
    dq["sla"] = request.model_dump()
    metadata["data_quality"] = dq

    try:
        store.update_metadata(name, version, metadata)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update contract metadata: {exc}",
        ) from exc

    return {
        "contract_name": name,
        "contract_version": version,
        "sla": request.model_dump(),
        "updated": True,
    }
