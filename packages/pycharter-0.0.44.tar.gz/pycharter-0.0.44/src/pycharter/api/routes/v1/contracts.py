"""
Route handlers for contract parsing and building.
"""

from __future__ import annotations

import logging
import tempfile
from pathlib import Path

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    UploadFile,
    status,
)
from sqlalchemy.orm import Session

from pycharter import (
    build_contract_from_store,
    parse_contract,
    parse_contract_file,
)
from pycharter.api.dependencies.database import get_db_session
from pycharter.api.dependencies.store import get_metadata_store
from pycharter.api.models.contracts import (
    ContractBuildRequest,
    ContractBuildResponse,
    ContractCreateFromArtifactsRequest,
    ContractCreateMixedRequest,
    ContractListItem,
    ContractListResponse,
    ContractParseRequest,
    ContractParseResponse,
    ContractUpdateRequest,
)
from pycharter.api.services import contract_service
from pycharter.api.services.contract_service import (
    ArtifactNotFoundError,
    ContractBuildError,
    ContractConflictError,
    ContractNotFoundError,
)
from pycharter.api.utils import ensure_uuid, get_by_id_or_404, safe_uuid_to_str
from pycharter.db.models import DataContractModel
from pycharter.metadata_store import MetadataStoreClient

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Contracts"])


def _contract_to_item(contract: DataContractModel) -> ContractListItem:
    """Convert a DataContractModel to a ContractListItem response."""
    return ContractListItem(
        id=safe_uuid_to_str(contract.id),
        name=contract.name,
        version=contract.version,
        status=contract.status,
        description=contract.description,
        schema_id=safe_uuid_to_str(contract.schema_id) if contract.schema_id else None,
        created_at=contract.created_at.isoformat() if contract.created_at else None,
        updated_at=contract.updated_at.isoformat() if contract.updated_at else None,
    )


@router.post(
    "/contracts/parse",
    response_model=ContractParseResponse,
    status_code=status.HTTP_200_OK,
    summary="Parse a data contract",
    description="Parse a data contract dictionary into its component parts (schema, metadata, ownership, governance rules, etc.)",
    response_description="Parsed contract components",
    tags=["Contracts"],
)
async def parse_contract_endpoint(
    request: ContractParseRequest,
) -> ContractParseResponse:
    """
    Parse a data contract into its components.

    This endpoint takes a complete data contract dictionary and breaks it down
    into its constituent parts: schema, metadata, ownership, governance rules,
    coercion rules, and validation rules.

    Args:
        request: Contract parse request containing contract data

    Returns:
        Parsed contract components

    Raises:
        HTTPException: If contract parsing fails
    """
    # Handle potential double-wrapping
    contract_data = request.contract
    if (
        isinstance(contract_data, dict)
        and "contract" in contract_data
        and len(contract_data) == 1
    ):
        contract_data = contract_data["contract"]

    if not isinstance(contract_data, dict):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid contract format: expected dict, got {type(contract_data)}",
        )

    if "schema" not in contract_data:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Contract must contain a 'schema' field at the top level",
        )

    try:
        contract_metadata = parse_contract(contract_data)
        return ContractParseResponse(
            schema=contract_metadata.schema,
            metadata=contract_metadata.metadata,
            ownership=contract_metadata.ownership,
            governance_rules=contract_metadata.governance_rules,
            coercion_rules=contract_metadata.coercion_rules,
            validation_rules=contract_metadata.validation_rules,
            versions=contract_metadata.versions,
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e


@router.post(
    "/contracts/parse/upload",
    response_model=ContractParseResponse,
    status_code=status.HTTP_200_OK,
    summary="Parse a data contract from file upload",
    description="Parse a data contract file (YAML or JSON) uploaded via multipart/form-data into its component parts (schema, metadata, ownership, governance rules, etc.)",
    response_description="Parsed contract components",
    tags=["Contracts"],
)
async def parse_contract_file_endpoint(
    file: UploadFile = File(..., description="Contract file (YAML or JSON)"),
    should_validate: bool = Form(
        True,
        alias="validate",
        description="Validate contract against schema before parsing",
    ),
) -> ContractParseResponse:
    """
    Parse a data contract from an uploaded file.

    This endpoint accepts a contract file (YAML or JSON) and breaks it down
    into its constituent parts: schema, metadata, ownership, governance rules,
    coercion rules, and validation rules.

    Args:
        file: Uploaded contract file (YAML or JSON)
        validate: Whether to validate contract against schema before parsing

    Returns:
        Parsed contract components

    Raises:
        HTTPException: If contract parsing fails or file format is unsupported
    """
    # Validate file format
    file_extension = Path(file.filename).suffix.lower()
    if file_extension not in [".yaml", ".yml", ".json"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported file format: {file_extension}. Only YAML (.yaml, .yml) and JSON (.json) files are supported.",
        )

    # Save uploaded file temporarily
    with tempfile.NamedTemporaryFile(delete=False, suffix=file_extension) as tmp_file:
        # Read file content
        content = await file.read()
        tmp_file.write(content)
        tmp_file_path = tmp_file.name

    try:
        # Parse contract file
        contract_metadata = parse_contract_file(tmp_file_path, validate=should_validate)

        return ContractParseResponse(
            schema=contract_metadata.schema,
            metadata=contract_metadata.metadata,
            ownership=contract_metadata.ownership,
            governance_rules=contract_metadata.governance_rules,
            coercion_rules=contract_metadata.coercion_rules,
            validation_rules=contract_metadata.validation_rules,
            versions=contract_metadata.versions,
        )
    except FileNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e
    except Exception as e:
        logger.error("Error parsing contract file: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to parse contract file: {str(e)}",
        ) from e
    finally:
        # Clean up temporary file
        try:
            Path(tmp_file_path).unlink()
        except Exception:
            pass


@router.post(
    "/contracts/{contract_id}/build",
    response_model=ContractBuildResponse,
    status_code=status.HTTP_200_OK,
    summary="Build a contract from contract ID",
    description="Reconstruct a complete data contract from a contract ID by fetching its linked artifacts",
    response_description="Complete contract dictionary",
    tags=["Contracts"],
)
async def build_contract_from_id_endpoint(
    contract_id: str,
    include_metadata: bool = Query(True, description="Include metadata in contract"),
    include_ownership: bool = Query(True, description="Include ownership in contract"),
    include_governance: bool = Query(
        True, description="Include governance rules in contract"
    ),
    store: MetadataStoreClient = Depends(get_metadata_store),
    db: Session = Depends(get_db_session),
) -> ContractBuildResponse:
    """
    Build a contract from contract ID.

    Args:
        contract_id: Contract ID (UUID)
        include_metadata: Whether to include metadata in contract
        include_ownership: Whether to include ownership in contract
        include_governance: Whether to include governance rules in contract
        store: Metadata store dependency
        db: Database session dependency

    Returns:
        Complete contract dictionary

    Raises:
        HTTPException: If contract not found or building fails
    """
    try:
        contract_dict = contract_service.build_contract_from_db(
            contract_id=contract_id,
            store=store,
            db=db,
            include_metadata=include_metadata,
            include_ownership=include_ownership,
            include_governance=include_governance,
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
        ) from e
    except (ContractNotFoundError, ArtifactNotFoundError) as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e)) from e
    except ContractBuildError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e)
        ) from e

    return ContractBuildResponse(contract=contract_dict)


@router.post(
    "/contracts/build",
    response_model=ContractBuildResponse,
    status_code=status.HTTP_200_OK,
    summary="Build a contract from metadata store",
    description="Reconstruct a complete data contract from components stored in the metadata store",
    response_description="Complete contract dictionary",
    tags=["Contracts"],
)
async def build_contract_endpoint(
    request: ContractBuildRequest,
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> ContractBuildResponse:
    """
    Build a contract from metadata store.

    This endpoint reconstructs a complete data contract dictionary from
    components stored in the metadata store. You can optionally include
    metadata, ownership, and governance rules.

    Args:
        request: Contract build request with schema_id and options
        store: Metadata store dependency

    Returns:
        Complete contract dictionary

    Raises:
        HTTPException: If contract building fails or schema not found
    """
    contract = build_contract_from_store(
        store=store,
        contract_name=request.contract_name,
        contract_version=request.contract_version,
        include_metadata=request.include_metadata,
        include_ownership=request.include_ownership,
        include_governance=request.include_governance,
    )

    if not contract:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Contract not found: {request.contract_name!r} @ {request.contract_version!r}",
        )

    return ContractBuildResponse(contract=contract)


@router.post(
    "/contracts/create-from-artifacts",
    response_model=ContractListItem,
    status_code=status.HTTP_201_CREATED,
    summary="Create a data contract from existing artifacts",
    description="Create a new data contract by linking to existing artifacts (schemas, coercion rules, validation rules, metadata) identified by title and version",
    response_description="Created contract information",
    tags=["Contracts"],
)
async def create_contract_from_artifacts(
    request: ContractCreateFromArtifactsRequest,
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """
    Create a new data contract from existing artifacts.

    Args:
        request: Contract creation request with artifact titles/versions
        db: Database session dependency

    Returns:
        Created contract information

    Raises:
        HTTPException: If contract creation fails or artifacts not found
    """
    try:
        new_contract = contract_service.create_from_existing_artifacts(request, db)
    except ContractConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e)) from e
    except ArtifactNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e)) from e
    except RuntimeError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e)
        ) from e

    return _contract_to_item(new_contract)


@router.post(
    "/contracts/create-mixed",
    response_model=ContractListItem,
    status_code=status.HTTP_201_CREATED,
    summary="Create a data contract with mixed artifacts",
    description="Create a new data contract by mixing new artifacts (provided as data) and existing artifacts (identified by title and version). Each artifact type can be either new or existing independently.",
    response_description="Created contract information",
    tags=["Contracts"],
)
async def create_contract_mixed(
    request: ContractCreateMixedRequest,
    store: MetadataStoreClient = Depends(get_metadata_store),
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """
    Create a new data contract with mixed artifacts (some new, some existing).

    Args:
        request: Contract creation request with mixed artifacts
        store: Metadata store dependency
        db: Database session dependency

    Returns:
        Created contract information

    Raises:
        HTTPException: If contract creation fails or artifacts not found
    """
    try:
        new_contract = contract_service.create_mixed(request, store, db)
    except ContractConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e)) from e
    except ArtifactNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e)) from e
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
        ) from e
    except RuntimeError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e)
        ) from e

    return _contract_to_item(new_contract)


@router.get(
    "/contracts",
    response_model=ContractListResponse,
    status_code=status.HTTP_200_OK,
    summary="List data contracts",
    description="Get a list of all data contracts stored in the database",
    response_description="List of contracts",
    tags=["Contracts"],
)
async def list_contracts(
    db: Session = Depends(get_db_session),
) -> ContractListResponse:
    """
    List all data contracts from the database.

    Args:
        db: Database session dependency

    Returns:
        List of contracts with metadata

    Raises:
        HTTPException: If database query fails
    """
    try:
        # Query all contracts
        contracts = (
            db.query(DataContractModel)
            .order_by(DataContractModel.created_at.desc())
            .all()
        )

        # Log for debugging
        logger.debug("Found %s contracts in database", len(contracts))

        contract_items = [_contract_to_item(contract) for contract in contracts]

        return ContractListResponse(
            contracts=contract_items,
            total=len(contract_items),
        )
    except Exception as e:
        logger.error("Error listing contracts: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list contracts: {str(e)}",
        ) from e


@router.get(
    "/contracts/{contract_id}",
    response_model=ContractListItem,
    status_code=status.HTTP_200_OK,
    summary="Get data contract by ID",
    description="Retrieve a specific data contract from the database by its ID",
    response_description="Contract details",
    tags=["Contracts"],
)
async def get_contract(
    contract_id: str,
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """
    Get a specific data contract from the database by ID.

    Args:
        contract_id: Contract ID (UUID)
        db: Database session dependency

    Returns:
        Contract details

    Raises:
        HTTPException: If contract not found or database query fails
    """
    # Validate contract ID format
    try:
        ensure_uuid(contract_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid contract ID format: {contract_id}",
        ) from None

    # Get contract from database
    contract = get_by_id_or_404(
        db,
        DataContractModel,
        contract_id,
        error_message=f"Contract not found: {contract_id}",
        model_name="Contract",
    )

    return _contract_to_item(contract)


@router.put(
    "/contracts/{contract_id}",
    response_model=ContractListItem,
    status_code=status.HTTP_200_OK,
    summary="Update data contract",
    description="Update contract metadata (name, version, status, description)",
    response_description="Updated contract details",
    tags=["Contracts"],
)
async def update_contract(
    contract_id: str,
    request: ContractUpdateRequest,
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """
    Update a data contract's metadata.

    Args:
        contract_id: Contract ID (UUID)
        request: Contract update request with fields to update
        db: Database session dependency

    Returns:
        Updated contract details

    Raises:
        HTTPException: If contract not found, invalid update, or database query fails
    """
    try:
        updated = contract_service.update_fields(contract_id, request, db)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
        ) from e
    except (ContractNotFoundError, ArtifactNotFoundError) as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e)) from e
    except ContractConflictError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
        ) from e
    except RuntimeError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e)
        ) from e

    return _contract_to_item(updated)


@router.delete(
    "/contracts/{contract_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete data contract",
    description="Delete a data contract by ID. This removes the contract record; linked artifacts (schema, coercion rules, etc.) may remain depending on database constraints.",
    tags=["Contracts"],
)
async def delete_contract(
    contract_id: str,
    db: Session = Depends(get_db_session),
) -> None:
    """
    Delete a data contract by ID.

    Args:
        contract_id: Contract ID (UUID)
        db: Database session dependency

    Raises:
        HTTPException: If contract not found or database query fails
    """
    try:
        ensure_uuid(contract_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid contract ID format: {contract_id}",
        ) from None

    contract = get_by_id_or_404(
        db,
        DataContractModel,
        contract_id,
        error_message=f"Contract not found: {contract_id}",
        model_name="Contract",
    )

    try:
        db.delete(contract)
        db.commit()
    except Exception as e:
        db.rollback()
        logger.error("Error deleting contract: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete contract: {str(e)}",
        ) from e
