"""Route handlers for metadata store operations."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from pycharter.api.dependencies.database import get_db_session
from pycharter.api.dependencies.store import get_metadata_store
from pycharter.api.models.metadata import (
    CoercionRulesStoreRequest,
    MetadataGetResponse,
    MetadataStoreRequest,
    MetadataStoreResponse,
    RulesGetResponse,
    RulesStoreResponse,
    SchemaGetResponse,
    SchemaListItem,
    SchemaListResponse,
    SchemaStoreRequest,
    SchemaStoreResponse,
    ValidationRulesStoreRequest,
)
from pycharter.api.models.metadata_entities import (
    DomainCreateRequest,
    DomainUpdateRequest,
    EnvironmentCreateRequest,
    EnvironmentUpdateRequest,
    OwnerCreateRequest,
    OwnerUpdateRequest,
    StorageLocationCreateRequest,
    StorageLocationUpdateRequest,
    SystemCreateRequest,
    SystemUpdateRequest,
    TagCreateRequest,
    TagUpdateRequest,
)
from pycharter.api.services.metadata_service import (
    DuplicateContractError,
    DuplicateEntityError,
    EntityNotFoundError,
    InvalidIdFormatError,
    InvalidVersionError,
)
from pycharter.api.services.metadata_service import (
    create_entity as _create_entity,
)
from pycharter.api.services.metadata_service import (
    list_artifacts as _list_artifacts,
)
from pycharter.api.services.metadata_service import (
    list_metadata_entities as _list_metadata_entities,
)
from pycharter.api.services.metadata_service import (
    store_schema as _store_schema,
)
from pycharter.api.services.metadata_service import (
    update_entity as _update_entity,
)
from pycharter.db.models import (
    DomainModel,
    EnvironmentModel,
    OwnerModel,
    StorageLocationModel,
    SystemModel,
    TagModel,
)
from pycharter.metadata_store import MetadataStoreClient

router = APIRouter(tags=["Metadata"])


# ---------------------------------------------------------------------------
# Schema endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/metadata/schemas",
    response_model=SchemaStoreResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Store a schema",
    description=(
        "Store a JSON Schema definition in the metadata store. "
        "Validates version numbers and prevents duplicate contracts."
    ),
    response_description="Stored schema information",
)
async def store_schema(
    request: SchemaStoreRequest,
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> SchemaStoreResponse:
    """Store a schema in the metadata store."""
    try:
        contract_id = _store_schema(
            request.schema_name, request.version, request.schema, store
        )
    except DuplicateContractError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT, detail=str(exc)
        ) from exc
    except InvalidVersionError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc

    return SchemaStoreResponse(
        schema_id=contract_id,
        schema_name=request.schema_name,
        version=request.version,
    )


@router.get(
    "/metadata/schemas/{contract_name}/{contract_version}",
    response_model=SchemaGetResponse,
    status_code=status.HTTP_200_OK,
    summary="Get a schema",
    description="Retrieve a schema from the metadata store by contract name and version",
    response_description="Schema definition",
)
async def get_schema(
    contract_name: str,
    contract_version: str,
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> SchemaGetResponse:
    """Get a schema from the metadata store by data contract name and version."""
    schema = store.get_schema(contract_name, contract_version)
    if not schema:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Schema not found for contract {contract_name!r} @ {contract_version!r}",
        )
    return SchemaGetResponse(
        schema=schema,
        version=schema.get("version") if isinstance(schema, dict) else None,
    )


@router.get(
    "/metadata/schemas",
    response_model=SchemaListResponse,
    status_code=status.HTTP_200_OK,
    summary="List all schemas",
    description="Retrieve a list of all schemas stored in the metadata store",
    response_description="List of schemas",
)
async def list_schemas(
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> SchemaListResponse:
    """List all schemas in the metadata store."""
    contracts = store.list_contracts()
    schema_items = [
        SchemaListItem(
            id=c.get("id", ""),
            name=c.get("name"),
            title=c.get("name"),
            version=c.get("version"),
        )
        for c in contracts
    ]
    return SchemaListResponse(schemas=schema_items, count=len(schema_items))


@router.get(
    "/metadata/schemas/{contract_name}/{contract_version}/complete",
    response_model=SchemaGetResponse,
    status_code=status.HTTP_200_OK,
    summary="Get complete schema with rules",
    description="Retrieve a complete schema with coercion and validation rules merged by contract name and version",
    response_description="Complete schema with rules merged",
)
async def get_complete_schema(
    contract_name: str,
    contract_version: str,
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> SchemaGetResponse:
    """Get complete schema with rules merged for a data contract."""
    complete_schema = store.get_complete_schema(contract_name, contract_version)
    if not complete_schema:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Schema not found for contract {contract_name!r} @ {contract_version!r}",
        )
    return SchemaGetResponse(
        schema=complete_schema,
        version=(
            complete_schema.get("version")
            if isinstance(complete_schema, dict)
            else None
        ),
    )


# ---------------------------------------------------------------------------
# Metadata endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/metadata/metadata",
    response_model=MetadataStoreResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Store metadata",
    description="Store metadata for a resource in the metadata store",
    response_description="Stored metadata information",
)
async def store_metadata(
    request: MetadataStoreRequest,
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> MetadataStoreResponse:
    """Store metadata for a schema in the metadata store."""
    metadata_id = store.store_metadata(
        request.contract_name, request.contract_version, request.metadata
    )
    return MetadataStoreResponse(
        metadata_id=metadata_id,
        contract_name=request.contract_name,
        contract_version=request.contract_version,
    )


@router.get(
    "/metadata/metadata/{contract_name}/{contract_version}",
    response_model=MetadataGetResponse,
    status_code=status.HTTP_200_OK,
    summary="Get metadata",
    description="Retrieve metadata for a data contract by name and version",
    response_description="Metadata dictionary",
)
async def get_metadata(
    contract_name: str,
    contract_version: str,
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> MetadataGetResponse:
    """Get metadata for a data contract."""
    metadata = store.get_metadata(contract_name, contract_version)
    if not metadata:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Metadata not found for contract {contract_name!r} @ {contract_version!r}",
        )
    return MetadataGetResponse(metadata=metadata)


# ---------------------------------------------------------------------------
# Rules endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/metadata/coercion-rules",
    response_model=RulesStoreResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Store coercion rules",
    description="Store coercion rules for a schema in the metadata store",
    response_description="Stored rules information",
)
async def store_coercion_rules(
    request: CoercionRulesStoreRequest,
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> RulesStoreResponse:
    """Store coercion rules for a schema in the metadata store."""
    rule_id = store.store_coercion_rules(
        request.contract_name, request.contract_version, request.coercion_rules
    )
    return RulesStoreResponse(
        rule_id=rule_id,
        contract_name=request.contract_name,
        contract_version=request.contract_version,
    )


@router.post(
    "/metadata/validation-rules",
    response_model=RulesStoreResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Store validation rules",
    description="Store validation rules for a schema in the metadata store",
    response_description="Stored rules information",
)
async def store_validation_rules(
    request: ValidationRulesStoreRequest,
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> RulesStoreResponse:
    """Store validation rules for a schema in the metadata store."""
    rule_id = store.store_validation_rules(
        request.contract_name, request.contract_version, request.validation_rules
    )
    return RulesStoreResponse(
        rule_id=rule_id,
        contract_name=request.contract_name,
        contract_version=request.contract_version,
    )


@router.get(
    "/metadata/coercion-rules/{contract_name}/{contract_version}",
    response_model=RulesGetResponse,
    status_code=status.HTTP_200_OK,
    summary="Get coercion rules",
    description="Retrieve coercion rules for a data contract by name and version",
    response_description="Coercion rules dictionary",
)
async def get_coercion_rules(
    contract_name: str,
    contract_version: str,
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> RulesGetResponse:
    """Get coercion rules for a data contract."""
    rules = store.get_coercion_rules(contract_name, contract_version)
    if not rules:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Coercion rules not found for contract {contract_name!r} @ {contract_version!r}",
        )
    return RulesGetResponse(
        rules=rules,
        contract_name=contract_name,
        contract_version=contract_version,
    )


@router.get(
    "/metadata/validation-rules/{contract_name}/{contract_version}",
    response_model=RulesGetResponse,
    status_code=status.HTTP_200_OK,
    summary="Get validation rules",
    description="Retrieve validation rules for a data contract by name and version",
    response_description="Validation rules dictionary",
)
async def get_validation_rules(
    contract_name: str,
    contract_version: str,
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> RulesGetResponse:
    """Get validation rules for a data contract."""
    rules = store.get_validation_rules(contract_name, contract_version)
    if not rules:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Validation rules not found for contract {contract_name!r} @ {contract_version!r}",
        )
    return RulesGetResponse(
        rules=rules,
        contract_name=contract_name,
        contract_version=contract_version,
    )


# ---------------------------------------------------------------------------
# Listing endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/metadata/artifacts",
    status_code=status.HTTP_200_OK,
    summary="List all artifacts",
    description=(
        "Retrieve lists of all artifacts (schemas, coercion rules, "
        "validation rules, metadata) with their titles and versions"
    ),
    response_description="Lists of artifacts",
)
async def list_artifacts(
    db: Session = Depends(get_db_session),
) -> dict[str, list[dict[str, Any]]]:
    """List all artifacts grouped by type."""
    return _list_artifacts(db)


@router.get(
    "/metadata/coercion-functions",
    status_code=status.HTTP_200_OK,
    summary="List coercion functions",
    description=(
        "Return all supported coercion function names and their descriptions "
        "(for Options > Coercion reference)"
    ),
)
async def list_coercion_functions_route() -> dict[str, list[dict[str, str]]]:
    """List built-in coercion functions with short descriptions."""
    from pycharter.shared.coercions import list_coercion_functions

    return {"functions": list_coercion_functions()}


@router.get(
    "/metadata/validation-functions",
    status_code=status.HTTP_200_OK,
    summary="List validation functions",
    description=(
        "Return all supported validation function names, descriptions, and "
        "expected arguments (for Options > Validation reference)"
    ),
)
async def list_validation_functions_route() -> dict[str, list[dict[str, Any]]]:
    """List built-in validation functions with descriptions and arguments."""
    from pycharter.shared.validations import list_validation_functions

    return {"functions": list_validation_functions()}


@router.get(
    "/metadata/{entity_type}",
    status_code=status.HTTP_200_OK,
    summary="List metadata entities by type",
    description=(
        "Retrieve a list of metadata entities by type "
        "(owners, domains, systems, environments, storage_locations, tags)"
    ),
    response_description="List of entity dictionaries",
)
async def list_metadata_entities(
    entity_type: str,
    db: Session = Depends(get_db_session),
) -> list[dict[str, Any]]:
    """List metadata entities by type."""
    try:
        return _list_metadata_entities(entity_type, db)
    except EntityNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
        ) from exc


# ---------------------------------------------------------------------------
# Entity create helpers
# ---------------------------------------------------------------------------


def _handle_create(
    model_class: type,
    data: Any,
    db: Session,
    *,
    unique_field: str = "name",
) -> dict[str, Any]:
    """Thin wrapper that maps service exceptions to HTTP errors."""
    try:
        return _create_entity(model_class, data, db, unique_field=unique_field)
    except DuplicateEntityError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc


def _handle_update(
    model_class: type,
    entity_id: str,
    data: Any,
    db: Session,
    *,
    entity_label: str | None = None,
    validate_uuid: bool = True,
) -> dict[str, Any]:
    """Thin wrapper that maps service exceptions to HTTP errors."""
    try:
        return _update_entity(
            model_class,
            entity_id,
            data,
            db,
            entity_label=entity_label,
            validate_uuid=validate_uuid,
        )
    except InvalidIdFormatError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc
    except EntityNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
        ) from exc


# ---------------------------------------------------------------------------
# Entity CRUD endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/metadata/owners",
    status_code=status.HTTP_201_CREATED,
    summary="Create owner",
    description="Create a new owner",
    response_description="Created owner",
)
async def create_owner(
    request: OwnerCreateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Create a new owner."""
    return _handle_create(OwnerModel, request, db, unique_field="id")


@router.post(
    "/metadata/domains",
    status_code=status.HTTP_201_CREATED,
    summary="Create domain",
    description="Create a new domain",
    response_description="Created domain",
)
async def create_domain(
    request: DomainCreateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Create a new domain."""
    return _handle_create(DomainModel, request, db)


@router.post(
    "/metadata/systems",
    status_code=status.HTTP_201_CREATED,
    summary="Create system",
    description="Create a new system",
    response_description="Created system",
)
async def create_system(
    request: SystemCreateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Create a new system."""
    return _handle_create(SystemModel, request, db)


@router.post(
    "/metadata/environments",
    status_code=status.HTTP_201_CREATED,
    summary="Create environment",
    description="Create a new environment",
    response_description="Created environment",
)
async def create_environment(
    request: EnvironmentCreateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Create a new environment."""
    return _handle_create(EnvironmentModel, request, db)


@router.post(
    "/metadata/storage_locations",
    status_code=status.HTTP_201_CREATED,
    summary="Create storage location",
    description="Create a new storage location",
    response_description="Created storage location",
)
async def create_storage_location(
    request: StorageLocationCreateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Create a new storage location."""
    return _handle_create(StorageLocationModel, request, db)


@router.post(
    "/metadata/tags",
    status_code=status.HTTP_201_CREATED,
    summary="Create tag",
    description="Create a new tag",
    response_description="Created tag",
)
async def create_tag(
    request: TagCreateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Create a new tag."""
    return _handle_create(TagModel, request, db)


# ---------------------------------------------------------------------------
# Entity update endpoints
# ---------------------------------------------------------------------------


@router.put(
    "/metadata/owners/{owner_id}",
    status_code=status.HTTP_200_OK,
    summary="Update owner",
    description="Update an existing owner",
    response_description="Updated owner",
)
async def update_owner(
    owner_id: str,
    request: OwnerUpdateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Update an existing owner."""
    return _handle_update(
        OwnerModel,
        owner_id,
        request,
        db,
        entity_label="Owner",
        validate_uuid=False,
    )


@router.put(
    "/metadata/domains/{domain_id}",
    status_code=status.HTTP_200_OK,
    summary="Update domain",
    description="Update an existing domain",
    response_description="Updated domain",
)
async def update_domain(
    domain_id: str,
    request: DomainUpdateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Update an existing domain."""
    return _handle_update(DomainModel, domain_id, request, db, entity_label="Domain")


@router.put(
    "/metadata/systems/{system_id}",
    status_code=status.HTTP_200_OK,
    summary="Update system",
    description="Update an existing system",
    response_description="Updated system",
)
async def update_system(
    system_id: str,
    request: SystemUpdateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Update an existing system."""
    return _handle_update(SystemModel, system_id, request, db, entity_label="System")


@router.put(
    "/metadata/environments/{environment_id}",
    status_code=status.HTTP_200_OK,
    summary="Update environment",
    description="Update an existing environment",
    response_description="Updated environment",
)
async def update_environment(
    environment_id: str,
    request: EnvironmentUpdateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Update an existing environment."""
    return _handle_update(
        EnvironmentModel, environment_id, request, db, entity_label="Environment"
    )


@router.put(
    "/metadata/storage_locations/{storage_location_id}",
    status_code=status.HTTP_200_OK,
    summary="Update storage location",
    description="Update an existing storage location",
    response_description="Updated storage location",
)
async def update_storage_location(
    storage_location_id: str,
    request: StorageLocationUpdateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Update an existing storage location."""
    return _handle_update(
        StorageLocationModel,
        storage_location_id,
        request,
        db,
        entity_label="StorageLocation",
    )


@router.put(
    "/metadata/tags/{tag_id}",
    status_code=status.HTTP_200_OK,
    summary="Update tag",
    description="Update an existing tag",
    response_description="Updated tag",
)
async def update_tag(
    tag_id: str,
    request: TagUpdateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Update an existing tag."""
    return _handle_update(TagModel, tag_id, request, db, entity_label="Tag")
