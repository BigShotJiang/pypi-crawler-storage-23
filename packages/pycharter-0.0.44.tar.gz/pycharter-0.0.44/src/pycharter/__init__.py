# ruff: noqa: E402
"""
PyCharter - Data Contract Management, ETL Pipelines, and Validation

Core Services:
1. ETL Pipelines - Build and run ETL pipelines with | operator
2. Contract Parser - Reads and decomposes data contract files
3. Contract Builder - Constructs consolidated contracts from separate artifacts
4. Metadata Store - Database operations for metadata storage
5. Pydantic Generator - Generates Pydantic models from JSON Schema
6. JSON Schema Converter - Converts Pydantic models to JSON Schema
7. Runtime Validator - Validation utilities
8. Quality Assurance - Data quality checking and monitoring

ETL API:
    >>> from pycharter import Pipeline, HTTPExtractor, PostgresLoader, Rename, AddField
    >>>
    >>> # Programmatic pipeline with | operator
    >>> pipeline = (
    ...     Pipeline(HTTPExtractor(url="https://api.example.com/data"))
    ...     | Rename({"old": "new"})
    ...     | AddField("processed_at", "now()")
    ...     | PostgresLoader(connection_string="...", table="users")
    ... )
    >>> result = await pipeline.run()  # run() is async; use asyncio.run() from scripts
    >>>
    >>> # Config-driven (explicit files)
    >>> pipeline = Pipeline.from_config_files(
    ...     extract="configs/extract.yaml",
    ...     load="configs/load.yaml",
    ...     variables={"API_KEY": "secret"}
    ... )
    >>>
    >>> # Config-driven (directory with extract.yaml, transform.yaml, load.yaml)
    >>> pipeline = Pipeline.from_config_dir("pipelines/users/")
    >>>
    >>> # Config-driven (single file)
    >>> pipeline = Pipeline.from_config_file("pipelines/users/pipeline.yaml")

Validator API:
    >>> from pycharter import Validator
    >>>
    >>> # From explicit files
    >>> validator = Validator.from_files(schema="schema.yaml")
    >>>
    >>> # From directory
    >>> validator = Validator.from_dir("contracts/users/")
    >>>
    >>> result = validator.validate({"name": "Alice", "age": 30})
"""

from __future__ import annotations


def _get_version() -> str:
    try:
        from importlib.metadata import version

        return version("pycharter")
    except Exception:
        return "0.0.0.dev0"


__version__ = _get_version()

# Contract Builder
from pycharter.contract_builder import (
    ContractArtifacts,
    build_contract,
    build_contract_from_store,
)

# Contract Parser
from pycharter.contract_parser import (
    ContractMetadata,
    parse_contract,
    parse_contract_file,
)

# ETL Pipelines — core types
from pycharter.etl_generator import (
    AddField,
    BaseExtractor,
    BaseLoader,
    BaseTransformer,
    BatchResult,
    CloudStorageExtractor,
    CloudStorageLoader,
    Convert,
    CustomFunction,
    DatabaseExtractor,
    DatabaseLoader,
    Default,
    Drop,
    Extractor,
    FileExtractor,
    FileLoader,
    Filter,
    FlatMap,
    Flatten,
    HTTPExtractor,
    Loader,
    LoadResult,
    Map,
    Pipeline,
    PipelineBuilder,
    PipelineContext,
    PipelineResult,
    PostgresLoader,
    Rename,
    Select,
    Transformer,
    TransformerChain,
    Unnest,
)

# JSON Schema Converter
from pycharter.json_schema_converter import model_to_schema, to_dict, to_file, to_json

# Metadata Store — core client always available
from pycharter.metadata_store import MetadataStoreClient

# Pydantic Generator
from pycharter.pydantic_generator import (
    from_dict,
    from_file,
    from_json,
    from_url,
    generate_model,
    generate_model_file,
)

# Runtime Validator
from pycharter.runtime_validator import (
    ValidationResult,
    Validator,
    ValidatorBuilder,
    create_validator,
    get_merged_schema_from_contract,
    get_model_from_contract,
    get_model_from_store,
    merge_rules_into_schema,
    validate,
    validate_batch,
    validate_batch_with_contract,
    validate_batch_with_store,
    validate_input,
    validate_output,
    validate_with_contract,
    validate_with_contract_decorator,
    validate_with_store,
)

# Protocols and Error Handling
from pycharter.shared import (
    CoercionRegistry,
    ConfigError,
    ConfigLoadError,
    ConfigValidationError,
    DataValidator,
    ErrorContext,
    ErrorMode,
    ExpressionError,
    LenientMode,
    MetadataStore,
    PyCharterError,
    StrictMode,
    ValidationRegistry,
    set_error_mode,
)

# ============================================================================
# LAZY IMPORTS — optional or heavy modules loaded on first access
# ============================================================================

_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    # Metadata store backends (optional database drivers)
    "InMemoryMetadataStore": (
        "pycharter.metadata_store",
        "InMemoryMetadataStore",
    ),
    "MongoDBMetadataStore": (
        "pycharter.metadata_store",
        "MongoDBMetadataStore",
    ),
    "PostgresMetadataStore": (
        "pycharter.metadata_store",
        "PostgresMetadataStore",
    ),
    "RedisMetadataStore": (
        "pycharter.metadata_store",
        "RedisMetadataStore",
    ),
    "SQLiteMetadataStore": (
        "pycharter.metadata_store",
        "SQLiteMetadataStore",
    ),
    # Documentation Generation
    "DocsGenerator": ("pycharter.docs_generator", "DocsGenerator"),
    "HTMLRenderer": ("pycharter.docs_generator", "HTMLRenderer"),
    "MarkdownRenderer": ("pycharter.docs_generator", "MarkdownRenderer"),
    "generate_docs": ("pycharter.docs_generator", "generate_docs"),
    # Domain Entity Lifecycle
    "DEFAULT_STATE_FIELD": ("pycharter.domain", "DEFAULT_STATE_FIELD"),
    "check_state_alignment": ("pycharter.domain", "check_state_alignment"),
    "get_domain_entity_info": ("pycharter.domain", "get_domain_entity_info"),
    "get_lifecycle_binding": ("pycharter.domain", "get_lifecycle_binding"),
    "validate_lifecycle_binding": (
        "pycharter.domain",
        "validate_lifecycle_binding",
    ),
    # Quality Assurance
    "DataProfiler": ("pycharter.quality", "DataProfiler"),
    "FieldQualityMetrics": ("pycharter.quality", "FieldQualityMetrics"),
    "InMemoryMetricsStore": ("pycharter.quality", "InMemoryMetricsStore"),
    "MetricsCollector": ("pycharter.quality", "MetricsCollector"),
    "MetricsSummary": ("pycharter.quality", "MetricsSummary"),
    "QualityCheck": ("pycharter.quality", "QualityCheck"),
    "QualityCheckOptions": ("pycharter.quality", "QualityCheckOptions"),
    "QualityMetrics": ("pycharter.quality", "QualityMetrics"),
    "QualityReport": ("pycharter.quality", "QualityReport"),
    "QualityScore": ("pycharter.quality", "QualityScore"),
    "QualityThresholds": ("pycharter.quality", "QualityThresholds"),
    "SQLiteMetricsStore": ("pycharter.quality", "SQLiteMetricsStore"),
    "ValidationMetric": ("pycharter.quality", "ValidationMetric"),
    "ViolationRecord": ("pycharter.quality", "ViolationRecord"),
    "ViolationTracker": ("pycharter.quality", "ViolationTracker"),
    "check_quality": ("pycharter.quality", "check_quality"),
    "check_quality_with_store": (
        "pycharter.quality",
        "check_quality_with_store",
    ),
    "profile_data": ("pycharter.quality", "profile_data"),
    # Schema Evolution
    "ChangeType": ("pycharter.schema_evolution", "ChangeType"),
    "CompatibilityMode": ("pycharter.schema_evolution", "CompatibilityMode"),
    "CompatibilityResult": (
        "pycharter.schema_evolution",
        "CompatibilityResult",
    ),
    "SchemaChange": ("pycharter.schema_evolution", "SchemaChange"),
    "SchemaDiff": ("pycharter.schema_evolution", "SchemaDiff"),
    "check_compatibility": (
        "pycharter.schema_evolution",
        "check_compatibility",
    ),
    "compute_diff": ("pycharter.schema_evolution", "compute_diff"),
}


def __getattr__(name: str):
    """Lazy-load optional and heavy modules on first access."""
    if name in _LAZY_IMPORTS:
        import importlib

        module_path, attr_name = _LAZY_IMPORTS[name]
        try:
            module = importlib.import_module(module_path)
            return getattr(module, attr_name)
        except ImportError:
            return None
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # ETL Pipelines
    "Pipeline",
    "PipelineBuilder",
    "PipelineContext",
    "PipelineResult",
    "BatchResult",
    "LoadResult",
    "Extractor",
    "Transformer",
    "Loader",
    "BaseExtractor",
    "HTTPExtractor",
    "FileExtractor",
    "DatabaseExtractor",
    "CloudStorageExtractor",
    "BaseTransformer",
    "TransformerChain",
    "Rename",
    "AddField",
    "Drop",
    "Select",
    "Filter",
    "Convert",
    "Default",
    "Map",
    "FlatMap",
    "CustomFunction",
    "Unnest",
    "Flatten",
    "BaseLoader",
    "PostgresLoader",
    "DatabaseLoader",
    "FileLoader",
    "CloudStorageLoader",
    # Data Contract Services
    "Validator",
    "ValidatorBuilder",
    "create_validator",
    "ValidationResult",
    "validate_with_store",
    "validate_batch_with_store",
    "validate_with_contract",
    "validate_batch_with_contract",
    "get_model_from_store",
    "get_model_from_contract",
    "validate",
    "validate_batch",
    "validate_input",
    "validate_output",
    "validate_with_contract_decorator",
    "merge_rules_into_schema",
    "get_merged_schema_from_contract",
    # Contract Management
    "parse_contract",
    "parse_contract_file",
    "ContractMetadata",
    "build_contract",
    "build_contract_from_store",
    "ContractArtifacts",
    # Pydantic Generator
    "from_dict",
    "from_file",
    "from_json",
    "from_url",
    "generate_model",
    "generate_model_file",
    # JSON Schema Converter
    "to_dict",
    "to_file",
    "to_json",
    "model_to_schema",
    # Metadata Store
    "MetadataStoreClient",
    "InMemoryMetadataStore",
    "MongoDBMetadataStore",
    "PostgresMetadataStore",
    "RedisMetadataStore",
    "SQLiteMetadataStore",
    # Quality Assurance
    "QualityCheck",
    "QualityCheckOptions",
    "QualityReport",
    "QualityThresholds",
    "QualityMetrics",
    "QualityScore",
    "FieldQualityMetrics",
    "ViolationTracker",
    "ViolationRecord",
    "DataProfiler",
    "check_quality",
    "check_quality_with_store",
    "profile_data",
    "MetricsCollector",
    "ValidationMetric",
    "MetricsSummary",
    "InMemoryMetricsStore",
    "SQLiteMetricsStore",
    # Documentation Generation
    "DocsGenerator",
    "generate_docs",
    "MarkdownRenderer",
    "HTMLRenderer",
    # Schema Evolution
    "check_compatibility",
    "compute_diff",
    "CompatibilityResult",
    "SchemaDiff",
    "SchemaChange",
    "ChangeType",
    "CompatibilityMode",
    # Domain Entity Lifecycle
    "DEFAULT_STATE_FIELD",
    "get_lifecycle_binding",
    "get_domain_entity_info",
    "check_state_alignment",
    "validate_lifecycle_binding",
    # Protocols and Error Handling
    "PyCharterError",
    "ConfigError",
    "ConfigValidationError",
    "ConfigLoadError",
    "ExpressionError",
    "ErrorMode",
    "ErrorContext",
    "StrictMode",
    "LenientMode",
    "set_error_mode",
    "MetadataStore",
    "CoercionRegistry",
    "ValidationRegistry",
    "DataValidator",
]
