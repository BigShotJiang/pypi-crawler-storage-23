Displays the sequence of Sale order line and helps to maintain the
order. The line sequence number is also displayed in sale order reports.
