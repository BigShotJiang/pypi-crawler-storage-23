"""Prompt registry and catalog utilities.

This module provides the central catalog of all prompts in Obra, including
metadata for discovery, filtering, and documentation.

Refactoring: REFACTOR-PROMPT-LIBRARY-001
"""

from __future__ import annotations

__all__ = [
    "PROMPT_CATALOG",
    "get_prompt_metadata",
    "get_prompts_by_tier",
    "list_prompts",
]

# Prompt catalog with metadata for all prompts in Obra
# Each entry has:
#   module: Full module path containing the prompt
#   builder: Function name to build the prompt (or 'load_prompt' for text files)
#   tier: 'fast' (simple, low-latency) or 'slow' (complex, multi-step)
#   output: Expected output format ('json', 'text', 'yaml')
PROMPT_CATALOG: dict[str, dict[str, str]] = {
    # ==========================================================================
    # Derivation & Planning Prompts (obra/execution/prompts/)
    # ==========================================================================
    "derivation.base": {
        "module": "obra.prompts.derive.derivation",
        "builder": "build_derivation_prompt",
        "tier": "slow",
        "output": "json",
        "description": "Main derivation prompt for plan generation from objectives",
    },
    "derivation.step1": {
        "module": "obra.prompts.derive.derivation",
        "builder": "build_step1_epics_only_prompt",
        "tier": "slow",
        "output": "text",
        "description": "Step 1: Epic-only structure planning",
    },
    "derivation.step2": {
        "module": "obra.prompts.derive.derivation",
        "builder": "build_step2_prompt",
        "tier": "slow",
        "output": "text",
        "description": "Step 2: Expand epics into stories and tasks",
    },
    "derivation.step3": {
        "module": "obra.prompts.derive.derivation",
        "builder": "build_step3_prompt",
        "tier": "slow",
        "output": "json",
        "description": "Step 3: Convert prose plan to JSON",
    },
    "derivation.four_phase_guidance": {
        "module": "obra.prompts.derive.derivation",
        "builder": "build_four_phase_guidance",
        "tier": "fast",
        "output": "text",
        "description": "4-phase workflow guidance for complex work types",
    },
    "derivation.refinement": {
        "module": "obra.prompts.derive.derivation",
        "builder": "build_refinement_prompt",
        "tier": "fast",
        "output": "json",
        "description": "Refine plan JSON after validation errors",
    },
    "revision": {
        "module": "obra.prompts.derive.revision",
        "builder": "build_revision_prompt",
        "tier": "slow",
        "output": "json",
        "description": "Plan revision prompt for addressing issues",
    },
    "derive.plan_repair": {
        "module": "obra.prompts.derive.plan_repair",
        "builder": "build_plan_repair_prompt",
        "tier": "slow",
        "output": "json",
        "description": "Plan integrity auto-repair prompt for structural violations",
    },
    # ==========================================================================
    # Intent & Plan Conversion Prompts
    # ==========================================================================
    "intent_to_plan": {
        "module": "obra.prompts.intent.conversion",
        "builder": "build_intent_to_plan_prompt",
        "tier": "slow",
        "output": "json",
        "description": "Convert unstructured intent to UserPlan structure",
    },
    "quality_assessment": {
        "module": "obra.prompts.review.quality",
        "builder": "build_quality_assessment_prompt",
        "tier": "fast",
        "output": "json",
        "description": "Assess UserPlan quality with score and hints",
    },
    "intent.generation": {
        "module": "obra.prompts.intent.generation",
        "builder": "build_intent_generation_prompt",
        "tier": "slow",
        "output": "yaml",
        "description": "Expand objective into structured intent document",
    },
    "project_classification": {
        "module": "obra.prompts.intent.generation",
        "builder": "build_project_classification_prompt",
        "tier": "fast",
        "output": "json",
        "description": "Classify project as EMPTY or EXISTING",
    },
    "intent.user_stories": {
        "module": "obra.prompts.intent.user_stories",
        "builder": "build_user_story_generation_prompt",
        "tier": "slow",
        "output": "json",
        "description": "Generate user stories with verification methods from intent",
    },
    "llm.response_protocol": {
        "module": "obra.prompts.fragments.response_protocol",
        "builder": "get_response_protocol_instructions",
        "tier": "fast",
        "output": "text",
        "description": "Response protocol instructions for completion signals",
    },
    # ==========================================================================
    # Alignment & Gap Detection Prompts
    # ==========================================================================
    "plan_alignment": {
        "module": "obra.prompts.review.alignment",
        "builder": "build_plan_intent_alignment_prompt",
        "tier": "slow",
        "output": "json",
        "description": "Audit plan alignment against intent (epics/stories)",
    },
    "story_alignment": {
        "module": "obra.prompts.review.alignment",
        "builder": "build_story_intent_alignment_prompt",
        "tier": "fast",
        "output": "json",
        "description": "Audit single story alignment against intent",
    },
    "gap_detection": {
        "module": "obra.prompts.review.alignment",
        "builder": "build_gap_detection_prompt",
        "tier": "slow",
        "output": "json",
        "description": "Detect missing requirements after story assessment",
    },
    "story_gap": {
        "module": "obra.prompts.review.gap_check",
        "builder": "build_story_gap_prompt",
        "tier": "fast",
        "output": "json",
        "description": "Post-execution story-level gap check",
    },
    "epic_gap": {
        "module": "obra.prompts.review.gap_check",
        "builder": "build_epic_gap_prompt",
        "tier": "fast",
        "output": "json",
        "description": "Post-execution epic-level gap check",
    },
    # ==========================================================================
    # Hybrid Handler Prompts (obra/hybrid/prompts/)
    # ==========================================================================
    "exploration": {
        "module": "obra.prompts.derive.exploration",
        "builder": "build_exploration_prompt",
        "tier": "slow",
        "output": "yaml",
        "description": "Codebase exploration for pattern discovery",
    },
    "task_classification": {
        "module": "obra.prompts.derive.exploration",
        "builder": "build_task_classification_prompt",
        "tier": "fast",
        "output": "json",
        "description": "Classify tasks to UserPlan steps",
    },
    "examine_fallback": {
        "module": "obra.prompts.review.examine",
        "builder": "build_fallback_examine_prompt",
        "tier": "fast",
        "output": "text",
        "description": "Fallback plan examination prompt",
    },
    "fix.batch_context": {
        "module": "obra.prompts.fix.context",
        "builder": "build_batch_fix_context",
        "tier": "fast",
        "output": "text",
        "description": "Context block for batch issue fixing",
    },
    "fix.issue_context": {
        "module": "obra.prompts.fix.context",
        "builder": "build_issue_specific_context",
        "tier": "fast",
        "output": "text",
        "description": "Context block for single issue fixing",
    },
    "hybrid.template_edit": {
        "module": "obra.prompts.fragments.template_edit",
        "builder": "build_template_edit_prompt",
        "tier": "fast",
        "output": "text",
        "description": "Template edit instruction prompt for structured outputs",
    },
    "hybrid.context.working_directory": {
        "module": "obra.prompts.fragments.context",
        "builder": "build_working_directory_constraint",
        "tier": "fast",
        "output": "text",
        "description": "Working directory constraint for prompt context",
    },
    "hybrid.recovery_banner": {
        "module": "obra.prompts.fragments.recovery",
        "builder": "build_interactive_recovery_banner",
        "tier": "fast",
        "output": "text",
        "description": "Interactive guard recovery banner for retries",
    },
    # ==========================================================================
    # Auto/Assessment Prompts
    # ==========================================================================
    "assessment": {
        "module": "obra.prompts.execute.assessment",
        "builder": "build_assessment_prompt",
        "tier": "fast",
        "output": "text",
        "description": "Assess autonomous workplan runner failure",
    },
    "project.default_claude_md": {
        "module": "obra.prompts.templates.claude_md",
        "builder": "DEFAULT_OBRA_CLAUDE_MD",
        "tier": "fast",
        "output": "text",
        "description": "Default CLAUDE.md template for Obra projects",
    },
    "domain.software.sizing_guidance": {
        "module": "obra.domains.software.prompts.sizing",
        "builder": "SIZING_GUIDANCE",
        "tier": "fast",
        "output": "text",
        "description": "Sizing guidance for software development domain",
    },
    "domain.business.sizing_guidance": {
        "module": "obra.domains.business.prompts.sizing",
        "builder": "SIZING_GUIDANCE",
        "tier": "fast",
        "output": "text",
        "description": "Sizing guidance for business workflows domain",
    },
    # ==========================================================================
    # Agent Prompts (obra/agents/prompts/)
    # ==========================================================================
    "headless": {
        "module": "obra.prompts.agents",
        "builder": "load_prompt",
        "file": "headless.txt",
        "tier": "fast",
        "output": "text",
        "description": "Headless mode instruction for Claude Code agent",
    },
    "agents.security_sweep": {
        "module": "obra.prompts.agents",
        "builder": "load_prompt",
        "file": "security_sweep.txt",
        "tier": "fast",
        "output": "text",
        "description": "Fast-tier security vulnerability scan",
    },
    "agents.security_deep": {
        "module": "obra.prompts.agents",
        "builder": "load_prompt",
        "file": "security_deep.txt",
        "tier": "slow",
        "output": "text",
        "description": "Deep security analysis with OWASP coverage",
    },
    "agents.testing_coverage": {
        "module": "obra.prompts.agents",
        "builder": "load_prompt",
        "file": "testing_coverage.txt",
        "tier": "fast",
        "output": "text",
        "description": "Test coverage gap detection",
    },
    "agents.code_quality": {
        "module": "obra.prompts.agents",
        "builder": "load_prompt",
        "file": "code_quality.txt",
        "tier": "fast",
        "output": "text",
        "description": "Code quality analysis",
    },
    "agents.docs_analysis": {
        "module": "obra.prompts.agents",
        "builder": "load_prompt",
        "file": "docs_analysis.txt",
        "tier": "fast",
        "output": "text",
        "description": "Documentation quality analysis",
    },
}


def list_prompts() -> list[str]:
    """List all registered prompt names.

    Returns:
        Sorted list of prompt names in the catalog.

    Example:
        >>> prompts = list_prompts()
        >>> 'derivation.base' in prompts
        True
    """
    return sorted(PROMPT_CATALOG.keys())


def get_prompt_metadata(name: str) -> dict[str, str] | None:
    """Get metadata for a specific prompt.

    Args:
        name: Prompt name (e.g., 'derivation.base', 'intent_to_plan')

    Returns:
        Dict with module, builder, tier, output, description; None if not found.

    Example:
        >>> meta = get_prompt_metadata('derivation.base')
        >>> meta['tier']
        'slow'
        >>> meta['output']
        'json'
    """
    return PROMPT_CATALOG.get(name)


def get_prompts_by_tier(tier: str) -> list[str]:
    """Get all prompts with the specified tier.

    Args:
        tier: Tier to filter by ('fast' or 'slow')

    Returns:
        Sorted list of prompt names matching the tier.

    Example:
        >>> slow_prompts = get_prompts_by_tier('slow')
        >>> 'derivation.base' in slow_prompts
        True
        >>> 'assessment' in slow_prompts
        False
    """
    return sorted(name for name, meta in PROMPT_CATALOG.items() if meta.get("tier") == tier)
