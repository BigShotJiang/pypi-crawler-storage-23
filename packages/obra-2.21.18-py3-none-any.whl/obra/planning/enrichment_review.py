"""Intent enrichment plan review using expert-aligned prompts.

Story-level review: Reviews each story independently with its tasks.
Parsimonious: One LLM call per story, stop when done.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from obra.config.llm import resolve_tier_config
from obra.exceptions import ConfigurationError
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.intent.enrichment_config import load_enrichment_config
from obra.intent.prompts_enrichment import build_review_prompt
from obra.intent.telemetry import log_enrichment_event

logger = logging.getLogger(__name__)


@dataclass
class StoryReviewResult:
    """Result of reviewing a single story."""

    story_id: str
    changes_required: bool
    issues: list[str]
    updated_tasks: list[dict[str, Any]] | None
    raw_response: str
    duration_s: float


@dataclass
class EnrichmentReviewResult:
    """Aggregated result of reviewing all stories."""

    changes_required: bool
    issues: list[str]
    plan_items: list[dict[str, Any]] | None
    raw_response: str
    duration_s: float
    story_results: list[StoryReviewResult] = field(default_factory=list)


class EnrichmentPlanReviewer:
    """Run expert-aligned review of derived plan items.

    Story-level review: Reviews each story independently with its tasks.
    Emits progress events for each story being reviewed.
    """

    def __init__(
        self,
        working_dir: Path,
        *,
        llm_config: dict[str, Any],
        on_stream: Any | None = None,
        on_progress: Any | None = None,
        log_event: Any | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._llm_config = llm_config
        self._on_stream = on_stream
        self._on_progress = on_progress
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        try:
            self._config = load_enrichment_config(working_dir)
        except ConfigurationError as exc:
            logger.warning("Enrichment review disabled due to config error: %s", exc)
            self._config = {"enabled": False}

    def is_enabled(self) -> bool:
        return bool(self._config.get("enabled", False))

    def review(
        self,
        objective: str,
        *,
        intent_markdown: str,
        plan_items: list[dict[str, Any]],
        intent_id: str | None = None,
    ) -> EnrichmentReviewResult | None:
        """Review plan items story-by-story.

        Iterates over stories, reviewing each with its tasks independently.
        One LLM call per story (parsimonious, bounded).

        Args:
            objective: The user's objective
            intent_markdown: Intent document for context
            plan_items: Full plan (epics, stories, tasks)
            intent_id: Optional intent ID for artifacts

        Returns:
            Aggregated review result with updated plan_items
        """
        if not self.is_enabled():
            return None

        stage_config = self._get_stage_config("revise")
        max_passes = self._validate_and_get_config(stage_config)
        if max_passes < 1:
            return None

        # Get max_refinement_cycles (default 1 = one pass per story)
        max_refinement_cycles = int(stage_config.get("max_refinement_cycles", 1))

        resolved = resolve_tier_config(
            stage_config["model_tier"],
            role="implementation",
            override_thinking_level=stage_config["reasoning_level"],
        )
        timeout_s = int(stage_config.get("timeout_s") or 0)

        # Extract stories and build task lookup.
        # Skip close-out stories — they are template-injected, not LLM-derived,
        # so reviewing them wastes an LLM call and emits misleading activity events.
        stories = [
            item
            for item in plan_items
            if item.get("item_type") == "story"
            and not item.get("context", {}).get("closeout_domain")
        ]
        tasks_by_parent = self._group_tasks_by_parent(plan_items)

        if not stories:
            logger.info("No stories to review")
            return EnrichmentReviewResult(
                changes_required=False,
                issues=[],
                plan_items=plan_items,
                raw_response="",
                duration_s=0.0,
            )

        from concurrent.futures import ThreadPoolExecutor, as_completed

        from obra.config.loaders import get_enrichment_review_max_concurrent

        start = time.time()
        all_issues: list[str] = []
        story_results: list[StoryReviewResult] = []
        any_changes = False
        updated_plan_items = list(plan_items)  # Copy to modify
        total_stories = len(stories)
        max_workers = get_enrichment_review_max_concurrent()

        if max_workers > 1:
            self._emit_story_progress(
                "story_review_batch_started",
                story_count=total_stories,
                max_concurrent=max_workers,
            )

        def review_one(
            args: tuple[int, dict[str, Any], list[dict[str, Any]]],
        ) -> tuple[int, StoryReviewResult]:
            idx, story, story_tasks = args
            story_id = story.get("id", "unknown")
            story_title = story.get("title", "Untitled")

            logger.info("Reviewing story %s with %d tasks", story_id, len(story_tasks))

            if max_workers == 1:
                self._emit_story_progress(
                    "story_review_started",
                    story_id=story_id,
                    story_title=story_title,
                    story_index=idx,
                    total_stories=total_stories,
                    task_count=len(story_tasks),
                )

            story_result = self._review_story(
                objective=objective,
                intent_markdown=intent_markdown,
                story=story,
                tasks=story_tasks,
                resolved=resolved,
                timeout_s=timeout_s,
                max_passes=max_passes,
                max_refinement_cycles=max_refinement_cycles,
            )

            return (idx, story_result)

        work = [
            (idx, story, tasks_by_parent.get(story.get("id", "unknown"), []))
            for idx, story in enumerate(stories, start=1)
        ]
        results: list[tuple[int, StoryReviewResult]] = []
        errors: list[tuple[int, str, Exception]] = []

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(review_one, w): w for w in work}
            for future in as_completed(futures):
                work_item = futures[future]
                idx, story = work_item[0], work_item[1]
                story_id = story.get("id", "unknown")
                story_title = story.get("title", "Untitled")

                try:
                    result_idx, story_result = future.result()
                    results.append((result_idx, story_result))
                except Exception as exc:
                    logger.warning("Story %s review failed: %s", story_id, exc)
                    errors.append((idx, story_id, exc))
                    story_result = StoryReviewResult(
                        story_id=story_id,
                        changes_required=False,
                        issues=[],
                        updated_tasks=None,
                        raw_response="",
                        duration_s=0.0,
                    )
                    results.append((idx, story_result))

                self._emit_story_progress(
                    "story_review_completed",
                    story_id=story_id,
                    story_title=story_title,
                    story_index=idx,
                    total_stories=total_stories,
                    changes_required=story_result.changes_required,
                    issue_count=len(story_result.issues),
                    issues=story_result.issues,
                    duration_s=story_result.duration_s,
                )

        if errors:
            logger.warning(
                "%d/%d stories failed review: %s",
                len(errors),
                total_stories,
                [e[1] for e in errors],
            )

        results.sort(key=lambda x: x[0])
        for _, story_result in results:
            story_results.append(story_result)

            if story_result.changes_required:
                any_changes = True
                all_issues.extend(story_result.issues)

                if story_result.updated_tasks:
                    updated_plan_items = self._apply_task_updates(
                        updated_plan_items,
                        story_result.story_id,
                        story_result.updated_tasks,
                    )

        duration = time.time() - start

        # Build aggregated raw response
        raw_responses = [sr.raw_response for sr in story_results if sr.raw_response]
        aggregated_response = "\n---\n".join(raw_responses)

        result = EnrichmentReviewResult(
            changes_required=any_changes,
            issues=all_issues,
            plan_items=updated_plan_items if any_changes else None,
            raw_response=aggregated_response,
            duration_s=duration,
            story_results=story_results,
        )

        self._write_artifact(intent_id, aggregated_response)
        self._log_telemetry(result, intent_id=intent_id)

        logger.info(
            "Review complete: %d stories, %d issues, changes_required=%s",
            len(stories),
            len(all_issues),
            any_changes,
        )

        return result

    def _validate_and_get_config(self, stage_config: dict[str, Any]) -> int:
        """Validate required config fields and return max_passes."""
        if "max_passes" not in stage_config:
            msg = "planning.enrichment.stages.review.max_passes is required"
            raise ConfigurationError(
                msg,
                "Set max_passes for the review stage in config.",
            )
        if not stage_config.get("model_tier"):
            msg = "planning.enrichment.stages.review.model_tier is required"
            raise ConfigurationError(
                msg,
                "Set model_tier for the review stage in config.",
            )
        if "reasoning_level" not in stage_config:
            msg = "planning.enrichment.stages.review.reasoning_level is required"
            raise ConfigurationError(
                msg,
                "Set reasoning_level for the review stage in config.",
            )
        if "timeout_s" not in stage_config:
            msg = "planning.enrichment.stages.review.timeout_s is required"
            raise ConfigurationError(
                msg,
                "Set timeout_s for the review stage in config.",
            )
        return int(stage_config.get("max_passes", 0))

    def _group_tasks_by_parent(
        self, plan_items: list[dict[str, Any]]
    ) -> dict[str, list[dict[str, Any]]]:
        """Group tasks by their parent_id (story ID)."""
        tasks_by_parent: dict[str, list[dict[str, Any]]] = {}
        for item in plan_items:
            if item.get("item_type") == "task":
                parent_id = item.get("parent_id")
                if parent_id:
                    if parent_id not in tasks_by_parent:
                        tasks_by_parent[parent_id] = []
                    tasks_by_parent[parent_id].append(item)
        return tasks_by_parent

    def _review_story(
        self,
        *,
        objective: str,
        intent_markdown: str,
        story: dict[str, Any],
        tasks: list[dict[str, Any]],
        resolved: dict[str, Any],
        timeout_s: int,
        max_passes: int,
        max_refinement_cycles: int,
    ) -> StoryReviewResult:
        """Review a single story with its tasks using template edit pattern.

        Uses TemplateEditPipeline to eliminate preamble contamination issues.

        Args:
            objective: User objective for context
            intent_markdown: Intent document for context
            story: The story to review
            tasks: Tasks belonging to this story
            resolved: Resolved LLM config
            timeout_s: Timeout per LLM call (unused - pipeline manages)
            max_passes: Retry limit on parse failure
            max_refinement_cycles: LLM calls per story (unused - single pass)

        Returns:
            StoryReviewResult with any issues and updated tasks
        """
        story_id = story.get("id", "unknown")
        start = time.time()

        prompt = build_review_prompt(
            objective,
            intent_markdown,
            json.dumps(story, indent=2),
            json.dumps(tasks, indent=2),
        )

        # Create template edit pipeline
        # FIX-REVIEW-STALL-001: Disable streaming to avoid 300s idle timeout during file editing.
        # Anthropic CLI in 'execute' mode is silent on stdout, which triggers idle timeouts
        # during long-running story review tasks.
        pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name=f"enrichment_review_{story_id}",
            on_stream=None,
            log_event=self._log_event,
            max_retries=max_passes,
        )

        # Template schema for story review
        template_schema = {
            "changes_required": False,
            "issues": [],
            "tasks": [],
            "_instructions": (
                "Review the story and its tasks against the intent. Fill in:\n"
                "- changes_required: true if any issues found, false otherwise\n"
                "- issues: List of specific issues found (empty if none)\n"
                "- tasks: Updated task list if changes needed (same as input if no changes)"
            ),
        }

        def validator(data: dict) -> tuple[bool, str | None]:
            if "changes_required" not in data:
                return (False, "changes_required field is required")
            if not isinstance(data.get("changes_required"), bool):
                # Try to coerce string to bool
                cr = data.get("changes_required")
                if isinstance(cr, str):
                    data["changes_required"] = cr.lower() == "true"
                else:
                    return (False, "changes_required must be a boolean")
            tasks_value = data.get("tasks")
            if tasks_value is None:
                return (True, None)
            if not isinstance(tasks_value, list):
                return (False, "tasks must be a list when provided")
            for index, task in enumerate(tasks_value, start=1):
                if not isinstance(task, dict):
                    return (False, f"task {index} must be an object")
                task_id = str(task.get("id", "")).strip()
                if not task_id:
                    return (False, f"task {index} missing id")
                item_type = str(task.get("item_type", "")).strip().lower()
                if item_type != "task":
                    return (False, f"{task_id} item_type must be 'task'")
                parent_id = str(task.get("parent_id", "")).strip()
                if not parent_id:
                    return (False, f"{task_id} missing parent_id")
                if parent_id != story_id:
                    return (
                        False,
                        f"{task_id} parent_id must match story {story_id}",
                    )
                title = str(task.get("title", "")).strip()
                description = str(task.get("description", "")).strip()
                if not title:
                    return (False, f"{task_id} missing title")
                if not description:
                    return (False, f"{task_id} missing description")
                acceptance = task.get("acceptance_criteria", [])
                if not isinstance(acceptance, list):
                    return (False, f"{task_id} acceptance_criteria must be a list")
                dependencies = task.get("dependencies", [])
                if not isinstance(dependencies, list):
                    return (False, f"{task_id} dependencies must be a list")
            return (True, None)

        def fallback() -> dict:
            return {"changes_required": False, "issues": [], "tasks": tasks}

        result_data, metadata = pipeline.execute(
            base_prompt=prompt,
            template_content=template_schema,
            validator=validator,
            fallback_fn=fallback,
            llm_config={
                "provider": resolved["provider"],
                "model": resolved["model"],
                "thinking": resolved["thinking_level"],
                "auth": resolved["auth_method"],
            },
        )

        if metadata.get("status") == "template_fallback":
            logger.warning(
                "Story %s review failed parsing after %d attempts",
                story_id,
                metadata.get("attempts", max_passes),
            )
        elif metadata.get("status") == "no_changes_required":
            logger.info(
                "Story %s reviewed: no changes required (template unchanged)",
                story_id,
            )

        duration = time.time() - start
        changes_required = bool(result_data.get("changes_required", False))

        return StoryReviewResult(
            story_id=story_id,
            changes_required=changes_required,
            issues=_normalize_list(result_data.get("issues")),
            updated_tasks=_normalize_plan_items(result_data.get("tasks")),
            raw_response=json.dumps(result_data),
            duration_s=duration,
        )

    def _apply_task_updates(
        self,
        plan_items: list[dict[str, Any]],
        story_id: str,
        updated_tasks: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Replace tasks for a story with updated versions.

        Args:
            plan_items: Full plan items list
            story_id: ID of the story whose tasks are being updated
            updated_tasks: New task list from review

        Returns:
            Updated plan_items with tasks replaced
        """
        # Build lookup of updated tasks by ID
        updated_by_id = {task.get("id"): task for task in updated_tasks}

        result = []
        for item in plan_items:
            if item.get("item_type") == "task" and item.get("parent_id") == story_id:
                # This task belongs to the reviewed story
                task_id = item.get("id")
                if task_id in updated_by_id:
                    # Use updated version
                    result.append(updated_by_id[task_id])
                    del updated_by_id[task_id]
                # else: task was removed by review, don't include
            else:
                # Not a task for this story, keep as-is
                result.append(item)

        # Add any new tasks from the review
        for new_task in updated_by_id.values():
            # Ensure parent_id is set correctly
            new_task["parent_id"] = story_id
            result.append(new_task)

        return result

    def _write_artifact(self, intent_id: str | None, response_text: str) -> None:
        if not intent_id or not response_text:
            return
        artifacts_config = self._config.get("artifacts", {})
        artifacts_dir = artifacts_config.get("dir")
        if not artifacts_dir:
            return
        root = Path(artifacts_dir).expanduser() / intent_id
        root.mkdir(parents=True, exist_ok=True)
        path = root / "review.md"
        path.write_text(response_text, encoding="utf-8")

    def _log_telemetry(self, result: EnrichmentReviewResult, *, intent_id: str | None) -> None:
        telemetry_config = self._config.get("telemetry", {})
        if not telemetry_config.get("enabled", False):
            return
        if not intent_id:
            return
        output_path = telemetry_config.get("output_path")
        if not output_path:
            msg = "planning.enrichment.telemetry.output_path is required"
            raise ConfigurationError(
                msg,
                "Set planning.enrichment.telemetry.output_path in config.",
            )
        include_content = bool(telemetry_config.get("include_content", False))
        payload = {
            "intent_id": intent_id,
            "stages": [
                {
                    "stage": "review",
                    "duration_s": result.duration_s,
                    "parsed_keys": ["changes_required", "issues", "plan_items"],
                    **({"raw_response": result.raw_response} if include_content else {}),
                }
            ],
        }
        log_enrichment_event(Path(output_path), payload)

    def _get_stage_config(self, stage: str) -> dict[str, Any]:
        stages = self._config.get("stages")
        if not isinstance(stages, dict):
            msg = "planning.enrichment.stages must be a mapping"
            raise ConfigurationError(
                msg,
                "Set planning.enrichment.stages in config.",
            )
        stage_config = stages.get(stage)
        if not isinstance(stage_config, dict):
            msg = f"planning.enrichment.stages.{stage} must be a mapping"
            raise ConfigurationError(
                msg,
                f"Set planning.enrichment.stages.{stage} in config.",
            )
        return stage_config

    def _emit_story_progress(self, action: str, **kwargs: Any) -> None:
        """Emit story-level progress event."""
        if self._on_progress:
            try:
                self._on_progress(action, kwargs)
            except Exception as exc:
                logger.debug("Story progress callback failed: %s", exc)

    def _build_stream_handler(self):
        if not self._on_stream:
            return None
        return lambda chunk: self._on_stream("enrichment_review", chunk)


def _normalize_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value]
    if value:
        return [str(value)]
    return []


def _normalize_plan_items(value: Any) -> list[dict[str, Any]] | None:
    if value is None:
        return None
    if not isinstance(value, list):
        return None
    return [item for item in value if isinstance(item, dict)]
