"""SenseCheck plan response parser."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from obra.api.protocol import ValidatorResult


@dataclass
class PlanSenseCheckResult:
    """Result from plan validation."""

    sound: bool
    issues: list[dict[str, Any]]
    should_auto_revise: bool


def _coerce_issues(value: Any) -> list[dict[str, Any]]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ValueError("Plan SenseCheck issues must be a list")

    issues: list[dict[str, Any]] = []
    for item in value:
        if isinstance(item, dict):
            if item:
                issues.append(item)
            continue
        if item is None:
            continue
        description = str(item).strip()
        if description:
            issues.append({"description": description})
    return issues


def _coerce_should_auto_revise(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in ("true", "false"):
            return normalized == "true"
    raise ValueError("Plan SenseCheck should_auto_revise must be a bool")


def parse_plan_response(response: str) -> ValidatorResult:
    """Parse SenseCheck plan response into ValidatorResult.

    Args:
        response: Raw LLM response from plan SenseCheck prompt.

    Returns:
        ValidatorResult with issues populated and should_auto_revise in provenance.
    """
    if response is None or not response.strip():
        raise ValueError("Plan SenseCheck response was empty")

    stripped = response.strip()
    if stripped.upper() == "SOUND":
        return ValidatorResult(sound=True)

    try:
        data = json.loads(stripped)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Plan SenseCheck response was not valid JSON: {exc!s}") from exc

    if not isinstance(data, dict):
        raise ValueError("Plan SenseCheck JSON response must be an object")

    issues = _coerce_issues(data.get("issues"))
    should_auto_revise = _coerce_should_auto_revise(data.get("should_auto_revise"))

    result = PlanSenseCheckResult(
        sound=not issues,
        issues=issues,
        should_auto_revise=should_auto_revise,
    )

    return ValidatorResult(
        sound=result.sound,
        issues=result.issues,
        provenance={"should_auto_revise": result.should_auto_revise},
    )
