"""LLM configuration resolution and CLI building for Obra.

Handles model validation, thinking level mapping, config resolution, and CLI argument
construction for all supported LLM providers (Anthropic, OpenAI, Google).

Example:
    from obra.config.llm import resolve_llm_config, build_llm_args

    config = resolve_llm_config("orchestrator", override_model="sonnet")
    args = build_llm_args(config, mode="text")
"""

# pylint: disable=too-many-lines

import logging
import os
import re
import shutil
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, cast

import yaml

from obra.exceptions import ConfigurationError
from obra.model_registry import get_reasoning_profile

from .loaders import (
    get_project_layer_path,
    get_provider_tier_defaults,
    get_role_tier_defaults,
    get_tier_fallbacks,
    get_xhigh_supported_models,
    load_config,
    load_layered_config,
    load_llm_section,
    save_config,
)
from .providers import (
    DEFAULT_AUTH_METHOD,
    DEFAULT_MODEL,
    DEFAULT_PROVIDER,
    LLM_AUTH_METHODS,
    LLM_PROVIDERS,
)

if TYPE_CHECKING:
    from obra.execution.os_compat import (
        PROVIDER_API_KEY_ENV_VARS,
        build_subprocess_env,
    )

# Module logger
logger = logging.getLogger(__name__)

# Deprecation warning flag for build_llm_args()
_DEPRECATION_WARNED = False

# Default thinking level
DEFAULT_THINKING_LEVEL = "medium"
DEFAULT_THINKING_SELECTION = "default"

# Abstract thinking levels (user-facing, provider-agnostic)
# Maps to provider-specific parameters in build_llm_args()
THINKING_LEVELS = ["off", "low", "medium", "high", "extra high", "maximum"]

# Provider-specific thinking level mappings
# See docs/reference/llm-providers/ for official documentation
# NOTE: THINKING_LEVEL_MAP is intentionally NOT migrated to config. It defines
# a domain rule (provider capability mapping) rather than user-configurable values.
# Modifying this requires code changes to handle new thinking levels.
THINKING_LEVEL_MAP: dict[str, dict[str, str | None]] = {
    "anthropic": {
        # Claude Code CLI - no supported reasoning-level controls at this time.
        # Keep the mapping for future re-enablement of prompt keywords.
        "off": None,
        "low": None,
        "medium": None,
        "high": None,
        "maximum": None,
    },
    "openai": {
        # Codex CLI model_reasoning_effort values
        # See: docs/reference/llm-providers/openai-codex-reasoning.md
        "off": "minimal",  # Minimize reasoning overhead
        "low": "low",
        "medium": "medium",  # Default
        "high": "high",
        "extra high": "xhigh",
        "maximum": "xhigh",  # Supported by OpenAI models listed in llm.xhigh_supported_models
    },
    "google": {
        # Gemini CLI - no reasoning effort control available
        "off": None,
        "low": None,
        "medium": None,
        "high": None,
        "maximum": None,
    },
}

# Known model shortcuts for quick switching
# Full model names (e.g., "claude-sonnet-4-6") are passed through
MODEL_SHORTCUTS = {"default", "sonnet", "opus", "haiku"}

class _RuntimeRefreshDict(dict[str, Any]):
    """Dictionary facade that refreshes from runtime config on each read.

    This keeps public constants backward-compatible while avoiding import-time
    freezing of layered config data.
    """

    def __init__(self, loader: Callable[[], dict[str, Any]]):
        super().__init__()
        self._loader = loader

    def _refresh(self) -> None:
        super().clear()
        super().update(self._loader())

    def __getitem__(self, key: str) -> Any:
        self._refresh()
        return super().__getitem__(key)

    def get(self, key: str, default: Any = None) -> Any:
        self._refresh()
        return super().get(key, default)

    def items(self):
        self._refresh()
        return super().items()

    def keys(self):
        self._refresh()
        return super().keys()

    def values(self):
        self._refresh()
        return super().values()

    def __contains__(self, key: object) -> bool:
        self._refresh()
        return super().__contains__(key)

    def __iter__(self):
        self._refresh()
        return super().__iter__()

    def __len__(self) -> int:
        self._refresh()
        return super().__len__()

    def copy(self) -> dict[str, Any]:
        self._refresh()
        return dict(super().items())


def _load_runtime_provider_tier_defaults() -> dict[str, dict[str, str]]:
    """Load provider tier defaults from layered runtime config."""
    return get_provider_tier_defaults()


def _load_runtime_tier_fallbacks() -> dict[str, tuple[str, ...]]:
    """Load tier fallback chains from layered runtime config."""
    raw = get_tier_fallbacks()
    return {tier: tuple(fallback_list) for tier, fallback_list in raw.items()}


def _load_runtime_xhigh_supported_models() -> dict[str, set[str]]:
    """Load xhigh-supported model sets from layered runtime config."""
    raw = get_xhigh_supported_models()
    return {provider: set(models) for provider, models in raw.items()}

# Model name patterns for provider inference (regex)
# Used by infer_provider_from_model() to auto-detect provider
MODEL_PROVIDER_PATTERNS: dict[str, str] = {
    # Anthropic/Claude patterns
    r"^opus$": "anthropic",
    r"^sonnet$": "anthropic",
    r"^haiku$": "anthropic",
    r"^claude": "anthropic",  # claude-*, claude-3-*, etc.
    # OpenAI/Codex patterns
    r"^gpt": "openai",  # gpt-4, gpt-5.2, etc.
    r"^o[134]": "openai",  # o1, o3, o4 models
    r"^codex": "openai",  # codex-*, codex-mini, etc.
    # Google/Gemini patterns
    r"^gemini": "google",  # gemini-2.5-*, gemini-3-*, etc.
}

# Model name prefixes for fast provider inference (non-regex fallback)
MODEL_PROVIDER_PREFIXES: dict[str, str] = {
    "opus": "anthropic",
    "sonnet": "anthropic",
    "haiku": "anthropic",
    "claude": "anthropic",
    "gpt": "openai",
    "o1": "openai",
    "o3": "openai",
    "o4": "openai",
    "codex": "openai",
    "gemini": "google",
}

TIER_NAMES: tuple[str, str, str] = ("fast", "medium", "high")

# DEPRECATED: This constant now reads from config. To modify defaults, edit
# obra/config/default_config.yaml under llm.tier_fallbacks.
# User config can override at ~/.obra/config.yaml.
TIER_FALLBACKS: dict[str, tuple[str, ...]] = cast(
    dict[str, tuple[str, ...]],
    _RuntimeRefreshDict(_load_runtime_tier_fallbacks),
)

# Provider-specific tier defaults (FEAT-LLM-TIERS-SPLIT-001)
# Maps provider name to default tier model assignments
# Source: docs/design/PROVIDER_TIER_DEFAULTS.md and obra/model_registry.py
# Note: Use explicit model names for clarity in UI and logs
# DEPRECATED: This constant now reads from config. To modify defaults, edit
# obra/config/default_config.yaml under llm.provider_defaults.
# User config can override at ~/.obra/config.yaml.
PROVIDER_TIER_DEFAULTS: dict[str, dict[str, str]] = cast(
    dict[str, dict[str, str]],
    _RuntimeRefreshDict(_load_runtime_provider_tier_defaults),
)

# Models that support xhigh/maximum reasoning effort
# Used by get_effective_thinking_value() for fallback logic
# DEPRECATED: This constant now reads from config. To modify defaults, edit
# obra/config/default_config.yaml under llm.xhigh_supported_models.
# User config can override at ~/.obra/config.yaml.
XHIGH_SUPPORTED_MODELS: dict[str, set[str]] = cast(
    dict[str, set[str]],
    _RuntimeRefreshDict(_load_runtime_xhigh_supported_models),
)


def _load_runtime_role_tier_defaults() -> dict[str, dict[str, dict[str, str]]]:
    """Load role-tier defaults from layered runtime config."""
    return get_role_tier_defaults()


# Role-aware tier defaults: provider -> role -> {fast, medium, high}
# Orchestrator may use higher-capability models than implementation for the same tier.
# When a role's tiers are set to "default" (passthrough), these values are used.
# DEPRECATED as hardcoded constant: Now reads from config llm.role_defaults.
# User config can override at ~/.obra/config-layers/01-user.yaml.
ROLE_TIER_DEFAULTS: dict[str, dict[str, dict[str, str]]] = cast(
    dict[str, dict[str, dict[str, str]]],
    _RuntimeRefreshDict(_load_runtime_role_tier_defaults),
)


def get_role_tier_default(provider: str, role: str, tier: str) -> str | None:
    """Get the role-aware tier default model for a provider/role/tier combination.

    Args:
        provider: Provider name (anthropic, openai, google, ollama)
        role: Role name (orchestrator, implementation)
        tier: Tier name (fast, medium, high)

    Returns:
        Model name string, or None if no default exists.
    """
    return ROLE_TIER_DEFAULTS.get(provider, {}).get(role, {}).get(tier)


def update_role_tiers_for_provider(
    role: str, new_provider: str, config: dict[str, Any]
) -> tuple[dict[str, Any], str]:
    """Update tier configuration for a role when provider changes.

    When a role's provider is changed, this function auto-updates the role's
    tier mappings to match the new provider's model names.

    Args:
        role: Role name (orchestrator or implementation)
        new_provider: New provider name (anthropic, openai, google, ollama)
        config: Full config dict (will be modified in place)

    Returns:
        Tuple of (updated_config, notification_message)

    Example:
        >>> config = {"llm": {"orchestrator": {"provider": "openai"}}}
        >>> config, msg = update_role_tiers_for_provider("orchestrator", "openai", config)
        >>> print(msg)
        Updated orchestrator tiers to match OpenAI: fast=gpt-5.3-codex, ...
    """
    # Try role-aware defaults first, fall back to provider defaults
    role_defaults = ROLE_TIER_DEFAULTS.get(new_provider, {}).get(role, {})
    tier_defaults = role_defaults if role_defaults else PROVIDER_TIER_DEFAULTS.get(new_provider, {})
    if not tier_defaults:
        # Unknown provider, no update
        return config, ""

    # Ensure role config exists
    if "llm" not in config:
        config["llm"] = {}
    if role not in config["llm"] or not isinstance(config["llm"][role], dict):
        config["llm"][role] = {}

    # Update tiers
    config["llm"][role]["tiers"] = tier_defaults.copy()

    # Build notification message
    tier_list = ", ".join(f"{tier}={model}" for tier, model in tier_defaults.items())
    provider_display = new_provider.capitalize()
    notification = f"Updated {role} tiers to match {provider_display}: {tier_list}"

    return config, notification


def _coerce_provider(raw: Any, path: str) -> str:
    # Allow "per-role" as a special delegation value at top-level llm.provider
    # Allow "per-tier" as a special delegation value at role-level provider
    # (llm.orchestrator.provider, llm.implementation.provider)
    if isinstance(raw, str) and (raw in LLM_PROVIDERS or raw in ("per-role", "per-tier")):
        return raw
    if raw is not None:
        logger.warning(
            "%s invalid or unknown provider '%s', using default '%s'",
            path,
            raw,
            DEFAULT_PROVIDER,
        )
    return DEFAULT_PROVIDER


def _coerce_auth_method(raw: Any, path: str) -> str:
    if isinstance(raw, str) and raw in LLM_AUTH_METHODS:
        return raw
    if raw is not None:
        logger.warning(
            "%s invalid auth_method '%s', using default '%s'",
            path,
            raw,
            DEFAULT_AUTH_METHOD,
        )
    return DEFAULT_AUTH_METHOD


def _coerce_thinking_level(raw: Any, path: str) -> str:
    if isinstance(raw, str) and raw in (*THINKING_LEVELS, DEFAULT_THINKING_SELECTION):
        return raw
    if raw is not None:
        logger.warning(
            "%s invalid thinking_level '%s', using default '%s'",
            path,
            raw,
            DEFAULT_THINKING_LEVEL,
        )
    return DEFAULT_THINKING_LEVEL


def _coerce_optional_thinking_level(raw: Any, path: str) -> str | None:
    if raw is None:
        return None
    # YAML gotcha: 'off' is parsed as boolean False, 'on' as True
    # Handle this gracefully by converting False -> "off"
    if raw is False:
        return "off"
    if raw is True:
        return "maximum"  # Reasonable interpretation of 'on'
    if isinstance(raw, str):
        stripped = raw.strip()
        if not stripped or stripped == "null":
            return None
        if stripped in THINKING_LEVELS:
            return stripped
    logger.warning(
        "%s invalid reasoning level '%s', using null",
        path,
        raw,
    )
    return None


def _coerce_model(raw: Any, provider: str, path: str) -> str:
    model_value = raw if isinstance(raw, str) and raw.strip() else DEFAULT_MODEL
    try:
        return validate_model(model_value, provider)
    except ValueError as exc:
        logger.warning(
            "%s invalid model '%s' for provider '%s': %s. Using default.",
            path,
            model_value,
            provider,
            exc,
        )
        return DEFAULT_MODEL


def _coerce_bool(raw: Any, default: bool) -> bool:
    if isinstance(raw, bool):
        return raw
    return default


# Anthropic extended thinking budget constraints
# See: https://docs.anthropic.com/en/docs/build-with-claude/extended-thinking
THINKING_BUDGET_MIN = 1024
THINKING_BUDGET_MAX = 128000
DEFAULT_THINKING_BUDGET = 10000


def _coerce_thinking_budget(raw: Any, path: str) -> int | None:
    """Coerce thinking_budget to valid int or None.

    Args:
        raw: Raw value from config (int, str, or None)
        path: Config path for logging

    Returns:
        Valid budget int (1024-128000) or None for provider default
    """
    if raw is None:
        return None
    if isinstance(raw, str):
        stripped = raw.strip().lower()
        if not stripped or stripped == "null":
            return None
        try:
            raw = int(stripped)
        except ValueError:
            logger.warning("%s invalid thinking_budget '%s', using null", path, raw)
            return None
    if isinstance(raw, int):
        if raw < THINKING_BUDGET_MIN:
            logger.warning(
                "%s thinking_budget %d below minimum %d, using minimum",
                path,
                raw,
                THINKING_BUDGET_MIN,
            )
            return THINKING_BUDGET_MIN
        if raw > THINKING_BUDGET_MAX:
            logger.warning(
                "%s thinking_budget %d above maximum %d, using maximum",
                path,
                raw,
                THINKING_BUDGET_MAX,
            )
            return THINKING_BUDGET_MAX
        return raw
    logger.warning("%s invalid thinking_budget type %s, using null", path, type(raw).__name__)
    return None


def _normalize_reasoning_bounds(
    raw_bounds: Any,
    *,
    tier: str,
) -> dict[str, str | None]:
    if not isinstance(raw_bounds, dict):
        raw_bounds = {}
    min_level = _coerce_optional_thinking_level(
        raw_bounds.get("min_level"),
        f"llm.reasoning.tiers.{tier}.min_level",
    )
    max_level = _coerce_optional_thinking_level(
        raw_bounds.get("max_level"),
        f"llm.reasoning.tiers.{tier}.max_level",
    )
    return {
        "min_level": min_level,
        "max_level": max_level,
    }


def _normalize_reasoning_config(raw_llm: dict[str, Any]) -> dict[str, Any]:
    raw_reasoning = raw_llm.get("reasoning", {})
    if not isinstance(raw_reasoning, dict):
        raw_reasoning = {}
    force_level = _coerce_optional_thinking_level(
        raw_reasoning.get("force_level"),
        "llm.reasoning.force_level",
    )
    strict_mode = _coerce_bool(raw_reasoning.get("strict_mode"), False)
    raw_tiers = raw_reasoning.get("tiers", {})
    if not isinstance(raw_tiers, dict):
        raw_tiers = {}
    tiers = {}
    for tier in TIER_NAMES:
        tiers[tier] = _normalize_reasoning_bounds(raw_tiers.get(tier, {}), tier=tier)
    return {
        "force_level": force_level,
        "strict_mode": strict_mode,
        "tiers": tiers,
    }


def _base_llm_defaults(raw_llm: dict[str, Any]) -> dict[str, Any]:
    provider = _coerce_provider(raw_llm.get("provider", DEFAULT_PROVIDER), "llm.provider")
    auth_method = _coerce_auth_method(
        raw_llm.get("auth_method", DEFAULT_AUTH_METHOD),
        "llm.auth_method",
    )
    thinking_level = _coerce_thinking_level(
        raw_llm.get("thinking_level", DEFAULT_THINKING_LEVEL), "llm.thinking_level"
    )
    thinking_budget = _coerce_thinking_budget(raw_llm.get("thinking_budget"), "llm.thinking_budget")
    model = _coerce_model(raw_llm.get("model", DEFAULT_MODEL), provider, "llm.model")
    return {
        "provider": provider,
        "auth_method": auth_method,
        "model": model,
        "thinking_level": thinking_level,
        "thinking_budget": thinking_budget,
        "parse_retry_enabled": _coerce_bool(raw_llm.get("parse_retry_enabled", True), True),
        "parse_retry_providers": raw_llm.get("parse_retry_providers"),
        "parse_retry_models": raw_llm.get("parse_retry_models"),
        "reasoning": _normalize_reasoning_config(raw_llm),
    }


def _normalize_role_config(
    raw_role: Any, base_defaults: dict[str, Any], role: str
) -> dict[str, Any]:
    if not isinstance(raw_role, dict):
        raw_role = {}
    provider = _coerce_provider(
        raw_role.get("provider", base_defaults["provider"]),
        f"llm.{role}.provider",
    )
    auth_method = _coerce_auth_method(
        raw_role.get("auth_method", base_defaults["auth_method"]),
        f"llm.{role}.auth_method",
    )
    thinking_level = _coerce_thinking_level(
        raw_role.get("thinking_level", base_defaults["thinking_level"]),
        f"llm.{role}.thinking_level",
    )
    # Role can override thinking_budget; if not set, inherit from base
    raw_budget = raw_role.get("thinking_budget")
    if raw_budget is not None:
        thinking_budget = _coerce_thinking_budget(raw_budget, f"llm.{role}.thinking_budget")
    else:
        thinking_budget = base_defaults.get("thinking_budget")
    model = _coerce_model(
        raw_role.get("model", base_defaults["model"]),
        provider,
        f"llm.{role}.model",
    )

    # Normalize role-specific tiers using role-aware defaults
    raw_tiers = raw_role.get("tiers")
    normalized_tiers = _normalize_role_tiers(raw_tiers, provider, role, base_defaults)

    return {
        "provider": provider,
        "auth_method": auth_method,
        "model": model,
        "thinking_level": thinking_level,
        "thinking_budget": thinking_budget,
        "parse_retry_enabled": _coerce_bool(
            raw_role.get("parse_retry_enabled", base_defaults["parse_retry_enabled"]),
            base_defaults["parse_retry_enabled"],
        ),
        "parse_retry_providers": raw_role.get(
            "parse_retry_providers", base_defaults["parse_retry_providers"]
        ),
        "parse_retry_models": raw_role.get(
            "parse_retry_models", base_defaults["parse_retry_models"]
        ),
        "tiers": normalized_tiers,
    }


def _normalize_tier_entry(
    tier: str, value: Any, base_defaults: dict[str, Any]
) -> dict[str, Any] | None:
    if value is None:
        return None

    if isinstance(value, str):
        # "default" means "resolve from provider tier defaults" — return None
        # so _normalize_role_tiers falls through to provider_defaults lookup
        if value in ("default", "per-tier", "per-role"):
            return None
        provider_guess = infer_provider_from_model(value) or base_defaults["provider"]
        return {
            "provider": provider_guess,
            "auth_method": base_defaults["auth_method"],
            "model": _coerce_model(value, provider_guess, f"llm.tiers.{tier}.model"),
            "thinking_level": base_defaults["thinking_level"],
        }

    if isinstance(value, dict):
        provider = _coerce_provider(
            value.get("provider", base_defaults["provider"]),
            f"llm.tiers.{tier}.provider",
        )
        auth_method = _coerce_auth_method(
            value.get("auth_method", base_defaults["auth_method"]),
            f"llm.tiers.{tier}.auth_method",
        )
        thinking_level = _coerce_thinking_level(
            value.get("thinking_level", base_defaults["thinking_level"]),
            f"llm.tiers.{tier}.thinking_level",
        )
        model_value = value.get("model", base_defaults["model"])
        return {
            "provider": provider,
            "auth_method": auth_method,
            "model": _coerce_model(model_value, provider, f"llm.tiers.{tier}.model"),
            "thinking_level": thinking_level,
        }

    msg = f"Invalid llm.tiers.{tier} entry: expected string or mapping, got {type(value).__name__}."
    raise ConfigurationError(
        msg,
        f"Set llm.tiers.{tier} to a model shortcut or a mapping with provider/model.",
    )


def _normalize_role_tiers(
    raw_tiers: Any, provider: str, role: str, base_defaults: dict[str, Any]
) -> dict[str, dict[str, Any]]:
    """Normalize tier configuration for a specific role.

    Uses role-aware tier defaults as primary fallback, then provider-specific tier
    defaults when tiers are not explicitly configured.

    Args:
        raw_tiers: Raw tiers dict from config (e.g., {fast: haiku, medium: sonnet})
        provider: Provider name for this role (anthropic, openai, google, ollama)
        role: Role name (orchestrator, implementation)
        base_defaults: Base config defaults for fallback (provider, auth_method, etc.)

    Returns:
        Dict mapping tier names to normalized config dicts with provider, model, etc.
        Falls back to ROLE_TIER_DEFAULTS then PROVIDER_TIER_DEFAULTS for the provider.

    Example:
        >>> _normalize_role_tiers({"fast": "haiku"}, "anthropic", "orchestrator", base_defaults)
        {
            "fast": {"provider": "anthropic", "model": "haiku", ...},
            "medium": {"provider": "anthropic", "model": "opus", ...},  # from defaults
            "high": {"provider": "anthropic", "model": "opus", ...}     # from defaults
        }
    """
    if raw_tiers is None:
        raw_tiers = {}
    if not isinstance(raw_tiers, dict):
        raw_tiers = {}

    # Get role-aware tier defaults, falling back to role-agnostic provider defaults
    role_tier_defaults = ROLE_TIER_DEFAULTS.get(provider, {}).get(role, {})
    provider_defaults = PROVIDER_TIER_DEFAULTS.get(provider, {})

    normalized: dict[str, dict[str, Any]] = {}
    for tier_name in TIER_NAMES:
        # Check if tier is explicitly configured
        if tier_name in raw_tiers:
            entry = _normalize_tier_entry(tier_name, raw_tiers[tier_name], base_defaults)
            if entry:
                normalized[tier_name] = entry
        else:
            # Try role-aware defaults first, then role-agnostic
            default_model = role_tier_defaults.get(tier_name) or provider_defaults.get(tier_name)
            if default_model and default_model != "default":
                normalized[tier_name] = {
                    "provider": provider,
                    "auth_method": base_defaults["auth_method"],
                    "model": _coerce_model(default_model, provider, f"llm.{tier_name}.model"),
                    "thinking_level": base_defaults["thinking_level"],
                }

    return normalized


def _normalize_tiers(raw_tiers: Any, base_defaults: dict[str, Any]) -> dict[str, dict[str, Any]]:
    if raw_tiers is None:
        return {}
    if not isinstance(raw_tiers, dict):
        msg = "Invalid llm.tiers section in ~/.obra/config-layers/01-user.yaml."
        raise ConfigurationError(
            msg,
            "Set llm.tiers to a mapping like {fast: haiku, medium: sonnet, high: opus}.",
        )

    normalized: dict[str, dict[str, Any]] = {}
    for tier_name in TIER_NAMES:
        if tier_name not in raw_tiers:
            continue
        entry = _normalize_tier_entry(tier_name, raw_tiers[tier_name], base_defaults)
        if entry:
            normalized[tier_name] = entry
    return normalized


def _get_env_tier_override(tier: str) -> str | None:
    env_value = os.environ.get(f"OBRA_{tier.upper()}_MODEL")
    if not env_value:
        return None
    stripped = env_value.strip()
    return stripped or None


def _normalized_llm_config(raw_llm: dict[str, Any]) -> dict[str, Any]:
    base_defaults = _base_llm_defaults(raw_llm)
    raw_roles = raw_llm.get("roles", {})
    raw_profiles = raw_llm.get("profiles", {})
    roles = raw_roles if isinstance(raw_roles, dict) else {}
    profiles = raw_profiles if isinstance(raw_profiles, dict) else {}

    return {
        "provider": base_defaults["provider"],
        "auth_method": base_defaults["auth_method"],
        "model": base_defaults["model"],
        "thinking_level": base_defaults["thinking_level"],
        "parse_retry_enabled": base_defaults["parse_retry_enabled"],
        "parse_retry_providers": base_defaults["parse_retry_providers"],
        "parse_retry_models": base_defaults["parse_retry_models"],
        "reasoning": base_defaults["reasoning"],
        "roles": roles,
        "profiles": profiles,
        "orchestrator": _normalize_role_config(
            raw_llm.get("orchestrator", {}),
            base_defaults,
            "orchestrator",
        ),
        "implementation": _normalize_role_config(
            raw_llm.get("implementation", {}), base_defaults, "implementation"
        ),
    }


def infer_provider_from_model(model: str) -> str | None:
    """Infer the LLM provider from a model name.

    Uses regex patterns first (MODEL_PROVIDER_PATTERNS), then falls back
    to prefix matching (MODEL_PROVIDER_PREFIXES).

    Args:
        model: Model name to analyze (e.g., "opus", "gpt-5.2", "gemini-2.5-flash")

    Returns:
        Provider name ("anthropic", "openai", "google") or None if unknown

    Examples:
        >>> infer_provider_from_model("opus")
        'anthropic'
        >>> infer_provider_from_model("gpt-5.2")
        'openai'
        >>> infer_provider_from_model("gemini-2.5-flash")
        'google'
        >>> infer_provider_from_model("custom-model")
        None
    """
    if not model or model == "default":
        return None

    model_lower = model.lower()

    # Try regex patterns first (most precise)
    for pattern, provider in MODEL_PROVIDER_PATTERNS.items():
        if re.match(pattern, model_lower):
            return provider

    # Fall back to prefix matching
    for prefix, provider in MODEL_PROVIDER_PREFIXES.items():
        if model_lower.startswith(prefix):
            return provider

    return None


def _materialize_default_thinking_level(
    provider: str,
    model: str | None,
    thinking_level: str | None,
    *,
    role: str | None = None,
    tier: str | None = None,
) -> str:
    """Resolve "default" thinking selection to a concrete normalized level."""
    if thinking_level and thinking_level != DEFAULT_THINKING_SELECTION:
        return thinking_level
    profile = get_reasoning_profile(provider, model, role=role, tier=tier)
    return profile.default_level


def get_thinking_level_notes(
    provider: str,
    thinking_level: str,
    model: str | None = None,
) -> list[str]:
    """Get user-facing notes about thinking level behavior for a provider.

    Provides feedback about how the selected thinking level maps to
    provider-specific behavior, including limitations and recommendations.

    Note: Anthropic models don't support reasoning-level controls, but the
    crosswalk handles this silently (maps all levels to None), so no user
    note is needed - the system just works without special flags.

    Args:
        provider: LLM provider name
        thinking_level: Abstract thinking level (off, low, medium, high, extra high, maximum)
        model: Optional model name for model-specific notes

    Returns:
        List of note strings to display to the user

    Examples:
        >>> get_thinking_level_notes("anthropic", "maximum")
        []

        >>> get_thinking_level_notes("google", "high")
        ['Gemini CLI does not support reasoning effort control']

        >>> get_thinking_level_notes("openai", "maximum", "gpt-5.1")
        ['xhigh reasoning not supported on gpt-5.1, using "high" instead']
        >>> get_thinking_level_notes("openai", "extra high", "gpt-5.2")
        ['Using xhigh reasoning effort for maximum analysis']
    """
    notes = []
    effective_level = _materialize_default_thinking_level(provider, model, thinking_level)

    # Provider-specific notes
    # Note: Anthropic models don't need a note - the crosswalk silently maps
    # all reasoning levels to None (no special flags sent), which is correct.

    if provider == "openai":
        # Check xhigh support
        if effective_level in {"extra high", "maximum"}:
            supported = XHIGH_SUPPORTED_MODELS.get("openai", set())
            if model and model not in supported:
                notes.append(f'xhigh reasoning not supported on {model}, using "high" instead')
                notes.append(f"For xhigh, use: {', '.join(sorted(supported))}")
            else:
                notes.append("Using xhigh reasoning effort for maximum analysis")

    elif provider == "google" and effective_level != "off":
        notes.append("Gemini CLI does not support reasoning effort control")

    return notes


def get_effective_thinking_value(
    provider: str,
    thinking_level: str,
    model: str | None = None,
) -> str | None:
    """Get the effective provider-specific thinking value with fallback.

    Maps abstract thinking level to provider-specific value, applying
    fallback logic for unsupported configurations (e.g., xhigh -> high
    for OpenAI models that don't support xhigh).

    Args:
        provider: LLM provider name
        thinking_level: Abstract thinking level (off, low, medium, high, extra high, maximum)
        model: Optional model name for model-specific fallback

    Returns:
        Provider-specific thinking value (e.g., "xhigh", "high")
        or None if the provider doesn't support the level

    Examples:
        >>> get_effective_thinking_value("openai", "maximum", "gpt-5.2")
        'xhigh'
        >>> get_effective_thinking_value("openai", "extra high", "gpt-5.2")
        'xhigh'
        >>> get_effective_thinking_value("openai", "maximum", "gpt-5.1")
        'high'  # Fallback - xhigh not supported
        >>> get_effective_thinking_value("anthropic", "maximum")
        None
        >>> get_effective_thinking_value("google", "high")
        None  # No reasoning control
    """
    effective_level = _materialize_default_thinking_level(provider, model, thinking_level)
    provider_map: dict[str, str | None] = THINKING_LEVEL_MAP.get(provider, {})
    base_value = provider_map.get(effective_level)

    # Apply fallback logic for OpenAI xhigh
    if provider == "openai" and effective_level in {"extra high", "maximum"}:
        supported = XHIGH_SUPPORTED_MODELS.get("openai", set())
        if model and model not in supported:
            # Fall back to high
            return provider_map.get("high", "high")

    return base_value


def get_anthropic_api_thinking_param(
    thinking_level: str,
    thinking_budget: int | None = None,
) -> dict[str, Any] | None:
    """Build Anthropic API thinking parameter for extended thinking.

    This function is for future API path integration. Currently Obra uses
    CLI only, where thinking control is not available. When API path is
    added, this function provides the correctly formatted thinking parameter.

    Args:
        thinking_level: Abstract thinking level ("off" = disabled, else enabled)
        thinking_budget: Token budget for thinking (1024-128000); None = default

    Returns:
        Dict for API `thinking` parameter, or None if thinking disabled

    Examples:
        >>> get_anthropic_api_thinking_param("off")
        None
        >>> get_anthropic_api_thinking_param("medium")
        {'type': 'enabled', 'budget_tokens': 10000}
        >>> get_anthropic_api_thinking_param("high", 32000)
        {'type': 'enabled', 'budget_tokens': 32000}

    See:
        https://docs.anthropic.com/en/docs/build-with-claude/extended-thinking
    """
    if thinking_level == "off":
        return None
    budget = thinking_budget if thinking_budget is not None else DEFAULT_THINKING_BUDGET
    return {"type": "enabled", "budget_tokens": budget}


@dataclass(frozen=True)
class ReasoningSelection:
    """Resolved reasoning selection for an invocation."""

    normalized_level: str
    provider_level: str | None
    source: str
    clamped: bool
    clamp_reason: str | None
    supported_levels: list[str]
    default_level: str


def resolve_reasoning_selection(
    *,
    provider: str,
    model: str | None,
    stage_level: str | None,
    user_forced_level: str | None,
    tier_min_level: str | None,
    tier_max_level: str | None,
    cli_override: str | None = None,
    strict_mode: bool = False,
    role: str | None = None,
    tier: str | None = None,
) -> ReasoningSelection:
    """Resolve the effective reasoning level for an invocation.

    Precedence: CLI override > user forced > stage default > model default.
    Clamping: user tier min/max, then provider/model capability.

    Args:
        provider: Provider name (anthropic, openai, google, ollama)
        model: Model identifier (or None for provider default)
        stage_level: Stage default reasoning level
        user_forced_level: User forced reasoning level
        tier_min_level: User min level for the selected tier
        tier_max_level: User max level for the selected tier
        cli_override: CLI-provided override (highest priority)
        strict_mode: If true, unsupported levels raise ConfigurationError
        role: Optional role context (orchestrator, implementation)
        tier: Optional tier context (fast, medium, high)

    Returns:
        ReasoningSelection with normalized and provider-specific values.
    """
    level_order = {level: idx for idx, level in enumerate(THINKING_LEVELS)}

    def _validate_level(level: str | None, label: str, *, allow_default: bool = False) -> None:
        if level is None:
            return
        valid_levels = set(THINKING_LEVELS)
        if allow_default:
            valid_levels.add(DEFAULT_THINKING_SELECTION)
        if level not in valid_levels:
            msg = (
                f"Invalid reasoning level for {label}: {level}. "
                f"Valid: {', '.join(sorted(valid_levels))}"
            )
            raise ConfigurationError(msg)

    _validate_level(stage_level, "stage", allow_default=True)
    _validate_level(user_forced_level, "user_force", allow_default=True)
    _validate_level(tier_min_level, "tier_min")
    _validate_level(tier_max_level, "tier_max")
    _validate_level(cli_override, "cli_override", allow_default=True)

    if tier_min_level and tier_max_level:
        if level_order[tier_min_level] > level_order[tier_max_level]:
            msg = (
                f"Invalid tier reasoning bounds: min '{tier_min_level}' "
                f"is higher than max '{tier_max_level}'."
            )
            raise ConfigurationError(msg)

    profile = get_reasoning_profile(provider, model, role=role, tier=tier)
    default_level = profile.default_level

    selected_raw = cli_override or user_forced_level or stage_level
    selected_level = (
        default_level
        if selected_raw in (None, DEFAULT_THINKING_SELECTION)
        else selected_raw
    )
    source = (
        "cli_override"
        if cli_override
        else (
            "user_forced"
            if user_forced_level
            else "stage_default"
            if stage_level
            else "model_default"
        )
    )

    clamped = False
    clamp_reason = None

    if tier_min_level and level_order[selected_level] < level_order[tier_min_level]:
        selected_level = tier_min_level
        clamped = True
        clamp_reason = "tier_min"
    if tier_max_level and level_order[selected_level] > level_order[tier_max_level]:
        selected_level = tier_max_level
        clamped = True
        clamp_reason = "tier_max"

    supported_levels = profile.supported_levels
    if selected_level not in supported_levels:
        supported_sorted = sorted(supported_levels, key=lambda x: level_order.get(x, 0))
        lower_levels = [
            level for level in supported_sorted if level_order[level] <= level_order[selected_level]
        ]
        fallback_level = lower_levels[-1] if lower_levels else supported_sorted[0]
        if strict_mode:
            msg = (
                f"Reasoning level '{selected_level}' is not supported for "
                f"{provider}:{profile.model_id or model or 'default'}."
            )
            raise ConfigurationError(msg)
        selected_level = fallback_level
        clamped = True
        clamp_reason = "provider_unsupported"

    provider_level = profile.level_map.get(selected_level)

    return ReasoningSelection(
        normalized_level=selected_level,
        provider_level=provider_level,
        source=source,
        clamped=clamped,
        clamp_reason=clamp_reason,
        supported_levels=sorted(supported_levels, key=lambda x: level_order.get(x, 0)),
        default_level=default_level,
    )


def validate_model(model: str, provider: str = DEFAULT_PROVIDER) -> str:
    """Validate and normalize a model name.

    Supports two types of model names:
    1. Shortcuts: default, sonnet, opus, haiku (validated against provider)
    2. Full model names: claude-sonnet-4-6, gpt-4o, etc. (passthrough)

    Args:
        model: Model name to validate (shortcut or full name)
        provider: Provider to validate against for shortcuts

    Returns:
        Validated model name (unchanged)

    Raises:
        ValueError: If shortcut is not valid for the given provider
    """
    if not model:
        return DEFAULT_MODEL

    # Shortcuts are validated against provider's model list
    if model in MODEL_SHORTCUTS:
        provider_info = LLM_PROVIDERS.get(provider, LLM_PROVIDERS[DEFAULT_PROVIDER])
        valid_models = cast(Sequence[str], provider_info.get("models", []))
        if model not in valid_models:
            msg = (
                f"Model '{model}' not valid for provider '{provider}'. "
                f"Valid: {', '.join(valid_models)}"
            )
            raise ValueError(msg)
        return model

    # Full model names are passed through without validation
    # This allows users to use specific model versions like "claude-sonnet-4-6"
    return model


def get_project_planning_config(project_path: Path | None) -> dict[str, Any]:
    """Load planning configuration from project-level config layer.

    Args:
        project_path: Base project path (repo root preferred)

    Returns:
        Dictionary with planning config values (empty if not set)

    Raises:
        ConfigurationError: If the planning section is malformed
    """
    if project_path is None:
        return {}

    from obra.intent.storage import IntentStorage

    project_id = IntentStorage().get_project_id(project_path)
    config_path = get_project_layer_path(project_id)
    if not config_path.exists():
        return {}

    try:
        with config_path.open(encoding="utf-8") as config_file:
            raw_config = yaml.safe_load(config_file) or {}
    except yaml.YAMLError as exc:
        msg = f"Invalid YAML in {config_path}: {exc}"
        raise ConfigurationError(
            msg,
            "Fix the YAML syntax in the project config layer and try again.",
        ) from exc
    except OSError as exc:
        msg = f"Unable to read {config_path}: {exc}"
        raise ConfigurationError(
            msg,
            "Check file permissions for the project config layer and retry.",
        ) from exc

    planning_section = raw_config.get("planning")
    if planning_section is None:
        return {}
    if not isinstance(planning_section, dict):
        logger.warning(
            "Ignoring invalid planning section in %s (expected mapping).",
            config_path,
        )
        return {}

    config: dict[str, Any] = {}
    perm_value = planning_section.get("permissive_mode")
    if perm_value is not None:
        if not isinstance(perm_value, bool):
            logger.warning(
                "Ignoring invalid planning.permissive_mode in %s (expected boolean).",
                config_path,
            )
        else:
            config["permissive_mode"] = perm_value

    domain_value = planning_section.get("domain")
    if domain_value is not None:
        if not isinstance(domain_value, str) or not domain_value.strip():
            logger.warning(
                "Ignoring invalid planning.domain in %s (expected non-empty string).",
                config_path,
            )
        else:
            config["domain"] = domain_value.strip()

    # Backward compatibility: allow top-level domain key if present
    if "domain" not in config and isinstance(raw_config.get("domain"), str):
        domain_top = raw_config["domain"].strip()
        if domain_top:
            config["domain"] = domain_top

    return config


def resolve_llm_config(
    role: str,
    override_provider: str | None = None,
    override_model: str | None = None,
    override_auth_method: str | None = None,
    override_thinking_level: str | None = None,
    override_skip_git_check: bool | None = None,
    override_auto_init_git: bool | None = None,
) -> dict[str, Any]:
    """Resolve LLM configuration for a role with optional overrides.

    Resolution order (highest to lowest priority):
    1. Session overrides (passed as arguments, e.g., CLI flags)
    2. Layered config (user, project, session)
    3. Defaults (anthropic, oauth, default, medium)

    Args:
        role: "orchestrator" or "implementation"
        override_provider: Optional provider override (session-only)
        override_model: Optional model override (session-only)
        override_auth_method: Optional auth method override (session-only)
        override_thinking_level: Optional thinking level override (session-only)
        override_skip_git_check: Optional git skip check override (CLI flag)
        override_auto_init_git: Optional git auto init override (CLI flag)

    Returns:
        Resolved config dict with provider, auth_method, model, thinking_level keys
        and optional parse retry controls.
    """
    if role not in ("orchestrator", "implementation"):
        msg = f"Invalid role: {role}"
        raise ValueError(msg)

    # Get base config from layered config
    llm_config = get_llm_config()
    role_config = llm_config.get(role, {})

    # Load git section from layered config (GIT-HARD-001)
    raw_config, _, _ = load_layered_config()
    raw_llm = load_llm_section(raw_config)
    git_config = raw_llm.get("git", {}) if raw_llm else {}
    codex_config = raw_llm.get("codex", {}) if raw_llm else {}

    approval_mode: str | None = None
    if isinstance(codex_config, dict):
        raw_approval = codex_config.get("approval_mode")
        if isinstance(raw_approval, str) and raw_approval.strip():
            approval_value = raw_approval.strip()
            if approval_value in {"suggest", "auto-edit", "full-auto"}:
                approval_mode = approval_value
            else:
                logger.warning(
                    "Ignoring invalid llm.codex.approval_mode '%s'. "
                    "Expected: suggest, auto-edit, full-auto.",
                    approval_value,
                )

    bypass_sandbox = False
    if isinstance(codex_config, dict):
        bypass_sandbox = _coerce_bool(codex_config.get("bypass_sandbox", False), False)

    # Backward compatibility: Check for old llm.codex.skip_git_check config (GIT-HARD-001)
    skip_check = git_config.get("skip_check")
    if skip_check is None:
        # Check old config path: llm.codex.skip_git_check
        codex_config = raw_llm.get("codex", {}) if raw_llm else {}
        old_skip_check = codex_config.get("skip_git_check")
        if old_skip_check is not None:
            skip_check = old_skip_check
            from obra.messages import get_message

            logger.warning(
                get_message(
                    "warning.deprecation.config_key",
                    old="llm.codex.skip_git_check",
                    new="llm.git.skip_check",
                )
            )
        else:
            skip_check = False
    else:
        skip_check = bool(skip_check)

    # Resolve provider: top-level "per-role" means use role-specific provider
    # Role-level "per-tier" means each tier can have its own provider
    raw_top_provider = raw_llm.get("provider") if raw_llm else None
    top_level_provider = llm_config.get("provider", "per-role")
    if not raw_top_provider:
        top_level_provider = "per-role"
    role_level_provider = role_config.get("provider", DEFAULT_PROVIDER)

    if top_level_provider not in ("per-role", "per-tier"):
        # Top-level provider cascades to all roles
        effective_provider = top_level_provider
    elif role_level_provider not in ("per-role", "per-tier"):
        # Role-level provider
        effective_provider = role_level_provider
    else:
        # Provider is "per-tier": look at medium tier to get a default provider
        tier_config = role_config.get("tiers", {})
        tier_entry = tier_config.get("medium", {})
        if isinstance(tier_entry, dict) and "provider" in tier_entry:
            effective_provider = tier_entry["provider"]
        elif isinstance(tier_entry, str):
            # Model name only - infer provider from model
            inferred = infer_provider_from_model(tier_entry)
            effective_provider = inferred if inferred else DEFAULT_PROVIDER
        else:
            effective_provider = DEFAULT_PROVIDER

    # Resolve model: "per-tier", "per-role", and "default" all mean look up
    # from tier config / provider defaults. Only explicit model names cascade.
    # "default" must NOT pass through as a literal — it causes provider CLIs
    # (especially Gemini) to run in auto mode instead of using the configured
    # tier model (e.g., gemini-3-pro-preview for orchestrator medium tier).
    _model_passthrough = ("per-tier", "per-role", "default")
    raw_top_model = raw_llm.get("model") if raw_llm else None
    top_level_model = llm_config.get("model", "per-tier")
    if not raw_top_model:
        top_level_model = "per-tier"
    role_level_model = role_config.get("model", "per-tier")

    provider_defaults = PROVIDER_TIER_DEFAULTS.get(effective_provider, {})

    if top_level_model not in _model_passthrough:
        # Top-level explicit model cascades to all roles
        effective_model = top_level_model
    elif role_level_model not in _model_passthrough:
        # Role-level explicit model
        effective_model = role_level_model
    else:
        # Resolve from tier config - use "medium" as default tier
        tier_config = role_config.get("tiers", {})
        tier_entry = tier_config.get("medium")
        if tier_entry and tier_entry not in _model_passthrough:
            # Tier entry can be a string (model name) or dict (full config)
            if isinstance(tier_entry, str):
                effective_model = tier_entry
            elif isinstance(tier_entry, dict):
                tier_model = tier_entry.get("model", DEFAULT_MODEL)
                if tier_model not in _model_passthrough:
                    effective_model = tier_model
                else:
                    # Try role-aware defaults first, then provider defaults
                    role_default = get_role_tier_default(
                        effective_provider, role, "medium"
                    )
                    effective_model = (
                        role_default
                        if role_default and role_default != "default"
                        else provider_defaults.get("medium", DEFAULT_MODEL)
                    )
            else:
                effective_model = DEFAULT_MODEL
        else:
            # Fall back to role-aware tier defaults, then provider defaults
            role_default = get_role_tier_default(
                effective_provider, role, "medium"
            )
            if role_default and role_default != "default":
                effective_model = role_default
            else:
                effective_model = provider_defaults.get("medium", DEFAULT_MODEL)

    # Start with resolved values
    resolved = {
        "provider": effective_provider,
        "auth_method": role_config.get("auth_method", DEFAULT_AUTH_METHOD),
        "model": effective_model,
        "thinking_level": role_config.get("thinking_level", DEFAULT_THINKING_LEVEL),
        "parse_retry_enabled": role_config.get("parse_retry_enabled", True),
        "parse_retry_providers": role_config.get("parse_retry_providers"),
        "parse_retry_models": role_config.get("parse_retry_models"),
        "git": {
            "skip_check": skip_check,
            "auto_init": git_config.get("auto_init", False),
        },
        "codex": {
            "approval_mode": approval_mode,
            "bypass_sandbox": bypass_sandbox,
        },
    }

    # Apply overrides (session-only, don't persist)
    if override_provider:
        if override_provider not in LLM_PROVIDERS:
            msg = f"Invalid provider: {override_provider}"
            raise ValueError(msg)
        resolved["provider"] = override_provider

    if override_auth_method:
        if override_auth_method not in LLM_AUTH_METHODS:
            msg = f"Invalid auth method: {override_auth_method}"
            raise ValueError(msg)
        resolved["auth_method"] = override_auth_method

    if override_model:
        # Validate model against resolved provider
        resolved["model"] = validate_model(override_model, resolved["provider"])

    if override_thinking_level:
        if override_thinking_level not in (*THINKING_LEVELS, DEFAULT_THINKING_SELECTION):
            msg = (
                f"Invalid thinking level: {override_thinking_level}. "
                f"Valid: {', '.join([*THINKING_LEVELS, DEFAULT_THINKING_SELECTION])}"
            )
            raise ValueError(msg)
        resolved["thinking_level"] = override_thinking_level

    resolved["thinking_level"] = _materialize_default_thinking_level(
        resolved["provider"],
        resolved["model"],
        resolved.get("thinking_level"),
        role=role,
        tier="medium",
    )

    # Apply git overrides (CLI flags override config)
    if override_skip_git_check is not None:
        resolved["git"]["skip_check"] = override_skip_git_check
        logger.debug(f"Git skip_check overridden by CLI flag: {override_skip_git_check}")

    if override_auto_init_git is not None:
        resolved["git"]["auto_init"] = override_auto_init_git
        logger.debug(f"Git auto_init overridden by CLI flag: {override_auto_init_git}")

    if resolved["provider"] == "openai":
        if (
            resolved["git"]["skip_check"] is not True
            or resolved["codex"]["approval_mode"] != "full-auto"
            or resolved["codex"]["bypass_sandbox"] is not True
        ):
            logger.info(
                "OpenAI provider selected; forcing git.skip_check, codex.approval_mode, "
                "and codex.bypass_sandbox to safe defaults for Codex CLI."
            )
        resolved["git"]["skip_check"] = True
        resolved["codex"]["approval_mode"] = "full-auto"
        resolved["codex"]["bypass_sandbox"] = True

    return resolved


# pylint: disable=too-many-arguments,too-many-positional-arguments,too-many-branches,too-many-locals
def resolve_tier_config(
    tier: str,
    role: str = "implementation",
    override_provider: str | None = None,
    override_model: str | None = None,
    override_auth_method: str | None = None,
    override_thinking_level: str | None = None,
) -> dict[str, Any]:
    """Resolve model config for a given tier with role-specific fallback chain.

    Reads tier configuration from llm.{role}.tiers and falls back to provider-specific
    tier defaults when not explicitly configured.

    Fallback order:
    - fast: llm.{role}.tiers.fast -> medium -> high -> provider tier defaults -> role defaults
    - medium: llm.{role}.tiers.medium -> high -> provider tier defaults -> role defaults
    - high: llm.{role}.tiers.high -> medium -> provider tier defaults -> role defaults

    Args:
        tier: Tier name (fast, medium, high)
        role: Role to resolve for (orchestrator or implementation)
        override_provider: Optional provider override
        override_model: Optional model override
        override_auth_method: Optional auth method override
        override_thinking_level: Optional thinking level override

    Returns:
        Resolved config dict with provider, model, auth_method, thinking_level, etc.

    Example:
        >>> resolve_tier_config("fast", role="orchestrator")
        {'provider': 'anthropic', 'model': 'haiku', ...}
    """
    tier_fallbacks = TIER_FALLBACKS.copy()
    provider_tier_defaults = PROVIDER_TIER_DEFAULTS.copy()

    if tier not in tier_fallbacks:
        msg = f"Invalid tier: {tier}. Valid: {', '.join(TIER_NAMES)}"
        raise ValueError(msg)
    if role not in ("orchestrator", "implementation"):
        msg = f"Invalid role: {role}"
        raise ValueError(msg)

    env_override_model = _get_env_tier_override(tier)
    override_model = override_model or env_override_model
    if override_model and not override_provider:
        inferred_provider = infer_provider_from_model(override_model)
        if inferred_provider:
            override_provider = inferred_provider

    llm_config = get_llm_config()
    role_config = llm_config.get(role, {})

    # Fast-config pattern: top-level llm.provider/llm.model act as override switches
    # When set to "per-role"/"per-tier", children decide; otherwise, value cascades
    top_level_provider = llm_config.get("provider", "per-role")
    top_level_model = llm_config.get("model", "per-tier")

    # Determine effective provider: top-level overrides role unless "per-role"
    # Role-level "per-tier" means each tier can have its own provider
    role_level_provider = role_config.get("provider", DEFAULT_PROVIDER)

    if top_level_provider not in ("per-role", "per-tier"):
        effective_provider = top_level_provider
        provider_is_per_tier = False
    elif role_level_provider not in ("per-role", "per-tier"):
        effective_provider = role_level_provider
        provider_is_per_tier = False
    else:
        # Provider is "per-tier": will be resolved from tier entry later
        effective_provider = DEFAULT_PROVIDER  # Placeholder, resolved below
        provider_is_per_tier = True

    # Determine effective model with two-level cascade:
    # 1. llm.model (top-level) overrides everything unless passthrough
    # 2. llm.{role}.model (role-level) overrides tiers unless passthrough
    # 3. Otherwise, tiers decide their own model
    # "default" is a passthrough value (not a literal model name) — it means
    # "resolve from provider tier defaults" rather than "pass to CLI as-is".
    _model_passthrough = ("per-tier", "per-role", "default")
    role_level_model = role_config.get("model", "per-tier")

    if top_level_model not in _model_passthrough:
        # Top-level cascade: llm.model overrides all
        effective_model = top_level_model
        model_cascades_to_tiers = True
    elif role_level_model not in _model_passthrough:
        # Role-level cascade: llm.{role}.model overrides tiers
        effective_model = role_level_model
        model_cascades_to_tiers = True
    else:
        # No cascade: tiers decide
        effective_model = DEFAULT_MODEL
        model_cascades_to_tiers = False

    base_config = {
        "provider": effective_provider,
        "auth_method": role_config.get(
            "auth_method",
            llm_config.get("auth_method", DEFAULT_AUTH_METHOD),
        ),
        "model": effective_model,
        "thinking_level": role_config.get(
            "thinking_level",
            llm_config.get("thinking_level", DEFAULT_THINKING_LEVEL),
        ),
        "parse_retry_enabled": role_config.get("parse_retry_enabled", True),
        "parse_retry_providers": role_config.get("parse_retry_providers"),
        "parse_retry_models": role_config.get("parse_retry_models"),
    }

    # If model cascades from top-level or role-level, skip tier lookup
    if model_cascades_to_tiers:
        chosen = {
            "provider": effective_provider,
            "auth_method": base_config["auth_method"],
            "model": effective_model,
            "thinking_level": base_config["thinking_level"],
        }
    else:
        # Normal tier resolution
        tier_overrides = role_config.get("tiers", {})
        fallback_chain = tier_fallbacks[tier]

        chosen = {}
        for candidate in fallback_chain:
            candidate_config = tier_overrides.get(candidate, {})
            # Skip passthrough values — "default" means "resolve from
            # provider tier defaults", not a literal model name
            if candidate_config and candidate_config not in _model_passthrough:
                # Normalize: string means just the model name
                if isinstance(candidate_config, str):
                    chosen = {"model": candidate_config}
                    # When provider is "per-tier", infer provider from model name
                    if provider_is_per_tier:
                        inferred = infer_provider_from_model(candidate_config)
                        if inferred:
                            chosen["provider"] = inferred
                else:
                    chosen = candidate_config
                    # When provider is "per-tier" and tier entry has no provider,
                    # infer from model name
                    if provider_is_per_tier and "provider" not in chosen and "model" in chosen:
                        inferred = infer_provider_from_model(chosen["model"])
                        if inferred:
                            chosen["provider"] = inferred
                break

        # Fall back to role-aware tier defaults, then provider tier defaults
        if not chosen:
            # When provider is "per-tier", use default provider for tier defaults
            if provider_is_per_tier:
                role_provider = DEFAULT_PROVIDER
            else:
                role_provider = role_config.get("provider", base_config["provider"])

            # Try role-aware defaults first (e.g., orchestrator-fast = sonnet)
            role_default = get_role_tier_default(role_provider, role, tier)
            if role_default and role_default != "default":
                chosen = {
                    "provider": role_provider,
                    "auth_method": base_config["auth_method"],
                    "model": role_default,
                    "thinking_level": base_config["thinking_level"],
                }
            else:
                # Final fallback: role-agnostic provider defaults
                provider_defaults = provider_tier_defaults.get(role_provider, {})
                if tier in provider_defaults:
                    default_model = provider_defaults[tier]
                    chosen = {
                        "provider": role_provider,
                        "auth_method": base_config["auth_method"],
                        "model": default_model,
                        "thinking_level": base_config["thinking_level"],
                    }

    resolved = {
        "provider": chosen.get("provider", base_config["provider"]),
        "auth_method": chosen.get("auth_method", base_config["auth_method"]),
        "model": chosen.get("model", base_config["model"]),
        "thinking_level": chosen.get("thinking_level", base_config["thinking_level"]),
        "parse_retry_enabled": base_config["parse_retry_enabled"],
        "parse_retry_providers": base_config["parse_retry_providers"],
        "parse_retry_models": base_config["parse_retry_models"],
    }

    if override_provider:
        if override_provider not in LLM_PROVIDERS:
            msg = f"Invalid provider: {override_provider}"
            raise ValueError(msg)
        resolved["provider"] = override_provider

    if override_auth_method:
        if override_auth_method not in LLM_AUTH_METHODS:
            msg = f"Invalid auth method: {override_auth_method}"
            raise ValueError(msg)
        resolved["auth_method"] = override_auth_method

    if override_model:
        resolved["model"] = validate_model(override_model, resolved["provider"])

    if override_thinking_level:
        if override_thinking_level not in (*THINKING_LEVELS, DEFAULT_THINKING_SELECTION):
            msg = (
                f"Invalid thinking level: {override_thinking_level}. "
                f"Valid: {', '.join([*THINKING_LEVELS, DEFAULT_THINKING_SELECTION])}"
            )
            raise ValueError(msg)
        resolved["thinking_level"] = override_thinking_level

    resolved["thinking_level"] = _materialize_default_thinking_level(
        resolved["provider"],
        resolved["model"],
        resolved.get("thinking_level"),
        role=role,
        tier=tier,
    )

    return resolved


def get_llm_config() -> dict[str, Any]:
    """Get LLM configuration from config file.

    Returns:
        Normalized LLM config with role defaults and optional tiers:
        {
            "provider": "anthropic",
            "auth_method": "oauth",
            "model": "default",
            "thinking_level": "medium",
            "orchestrator": {...},
            "implementation": {...},
            "tiers": {
                "fast": {
                    "provider": "...",
                    "auth_method": "...",
                    "model": "...",
                    "thinking_level": "...",
                }
            }
        }
    """
    config, _, _ = load_layered_config()
    llm_section = load_llm_section(config)
    if not llm_section:
        return _normalized_llm_config({})
    return _normalized_llm_config(llm_section)


def set_llm_config(
    role: str,  # "orchestrator" or "implementation"
    provider: str,
    auth_method: str,
    model: str = "default",
    thinking_level: str = "medium",
) -> str:
    """Set LLM configuration for a specific role.

    Args:
        role: "orchestrator" or "implementation"
        provider: LLM provider (anthropic, openai, google)
        auth_method: Auth method (oauth, api_key)
        model: Model to use (default recommended for oauth)
        thinking_level: Abstract thinking level (off, low, medium, high, extra high, maximum)
            Maps to provider-specific values via THINKING_LEVEL_MAP

    Returns:
        Notification message if tiers were auto-updated, empty string otherwise

    Raises:
        ValueError: If any parameter is invalid
    """
    if role not in ("orchestrator", "implementation"):
        msg = f"Invalid role: {role}. Must be 'orchestrator' or 'implementation'"
        raise ValueError(msg)

    if provider not in LLM_PROVIDERS:
        msg = f"Invalid provider: {provider}. Valid: {list(LLM_PROVIDERS.keys())}"
        raise ValueError(msg)

    if auth_method not in LLM_AUTH_METHODS:
        msg = f"Invalid auth method: {auth_method}. Valid: {list(LLM_AUTH_METHODS.keys())}"
        raise ValueError(msg)

    provider_info = LLM_PROVIDERS[provider]
    provider_models = cast(Sequence[str], provider_info.get("models", []))
    if model not in provider_models:
        msg = f"Invalid model '{model}' for {provider}. Valid: {provider_models}"
        raise ValueError(msg)

    if thinking_level not in (*THINKING_LEVELS, DEFAULT_THINKING_SELECTION):
        msg = (
            f"Invalid thinking level: {thinking_level}. "
            f"Valid: {', '.join([*THINKING_LEVELS, DEFAULT_THINKING_SELECTION])}"
        )
        raise ValueError(msg)

    config = load_config()
    if "llm" not in config:
        config["llm"] = get_llm_config()

    if provider == "openai":
        llm_section = config.get("llm")
        if isinstance(llm_section, dict):
            git_config = llm_section.setdefault("git", {})
            if isinstance(git_config, dict):
                git_config["skip_check"] = True

    # Check if provider is changing (FEAT-LLM-TIERS-SPLIT-001)
    old_provider = None
    if role in config["llm"] and isinstance(config["llm"][role], dict):
        old_provider = config["llm"][role].get("provider")

    notification = ""
    if old_provider and old_provider != provider:
        # Provider changed - auto-update tiers
        config, notification = update_role_tiers_for_provider(role, provider, config)

    config["llm"][role] = {
        "provider": provider,
        "auth_method": auth_method,
        "model": model,
        "thinking_level": thinking_level,
    }

    save_config(config)
    return notification


def get_llm_display(role: str) -> str:
    """Get a human-readable display string for LLM config.

    Args:
        role: "orchestrator" or "implementation"

    Returns:
        Display string like "Anthropic (OAuth, default)"
    """
    llm_config = get_llm_config()
    role_config = llm_config.get(role, {})

    provider = role_config.get("provider", DEFAULT_PROVIDER)
    auth_method = role_config.get("auth_method", DEFAULT_AUTH_METHOD)
    model = role_config.get("model", DEFAULT_MODEL)

    provider_name = LLM_PROVIDERS.get(provider, {}).get("name", provider)
    auth_name = "OAuth" if auth_method == "oauth" else "API Key"

    return f"{provider_name} ({auth_name}, {model})"


def get_thinking_keyword(resolved_config: dict[str, str]) -> str | None:
    """Get the prompt keyword to prepend for providers that support it.

    This keeps a generic hook for prompt-keyword thinking controls even when
    a provider does not currently support them.

    Args:
        resolved_config: Resolved config dict from resolve_llm_config()

    Returns:
        Keyword string to prefix (without ": "), or None if unsupported.
    """
    provider = resolved_config.get("provider", DEFAULT_PROVIDER)
    thinking_level = resolved_config.get("thinking_level", DEFAULT_THINKING_LEVEL)

    provider_map = THINKING_LEVEL_MAP.get(provider, {})
    keyword = provider_map.get(thinking_level)
    if provider == "anthropic" and isinstance(keyword, str) and keyword:
        return keyword
    return None


def build_llm_args(
    resolved_config: dict[str, str],
    mode: str = "text",
    response_format: str = "json",
) -> list[str]:
    """Build CLI arguments from resolved LLM configuration.

    Generates provider-specific CLI arguments including the --model flag
    when model != "default" and thinking_level mapped to provider-specific
    parameters via THINKING_LEVEL_MAP.

    Note: For Claude Code, thinking is triggered via prompt keyword (see
    get_thinking_keyword()), not CLI args. For OpenAI Codex, thinking is
    controlled via --config model_reasoning_effort=<level>.

    Args:
        resolved_config: Resolved config dict from resolve_llm_config()
            Must have: provider, model keys
            Optional: thinking_level
                (maps to provider-specific values)
        mode: Operation mode - "text" for derive/examine phases that need
            --print, "execute" for execute/fix phases that need to write
            files (no --print). Default is "text" for backward compatibility.
        response_format: Response format - "json" to add --output-format json,
            "text" for prose output (no --output-format flag). Default "json".

    Returns:
        List of CLI arguments (e.g., ["--dangerously-skip-permissions", "--model", "sonnet"])

    Example:
        # OpenAI with maximum thinking -> xhigh reasoning effort
        >>> build_llm_args({"provider": "openai", "model": "gpt-5.2", "thinking_level": "maximum"})
        ["exec", "--sandbox", "read-only", "--model", "gpt-5.2", "--config", "model_reasoning_effort=xhigh"]

        # Anthropic text mode (derive/examine) - with --print for JSON output
        >>> build_llm_args({"provider": "anthropic", "model": "sonnet"}, mode="text")
        [
            "--print",
            "--output-format",
            "json",
            "--dangerously-skip-permissions",
            "--model",
            "sonnet",
            "...",
        ]

        # Anthropic execute mode (execute/fix) - no --print, allows file writing
        >>> build_llm_args({"provider": "anthropic", "model": "sonnet"}, mode="execute")
        ["--dangerously-skip-permissions", "--model", "sonnet", ...]
    """
    import warnings
    from pathlib import Path

    from obra.execution.os_compat import resolve_profile
    from obra.execution.spec_builder import build_command_spec, build_provider_spec

    # Emit deprecation warning once per session
    global _DEPRECATION_WARNED
    if not _DEPRECATION_WARNED:
        warnings.warn(
            "build_llm_args() is deprecated. Use build_command_spec() -> "
            "build_provider_spec() pipeline for typed execution.",
            DeprecationWarning,
            stacklevel=2,
        )
        _DEPRECATION_WARNED = True

    # Build CommandSpec with reasonable defaults for fields not in original signature
    cmd_spec = build_command_spec(
        config=resolved_config,
        mode=mode,
        response_format=response_format,
        cwd=Path("."),  # Default to current directory
        streaming=False,  # Not used in original build_llm_args
        timeout_s=0,  # Not used in original build_llm_args
        auth_method="api_key",  # Default authentication method
    )

    # Resolve platform profile
    provider = resolved_config.get("provider", DEFAULT_PROVIDER)
    profile = resolve_profile(provider=provider)

    # Build ProviderSpec through typed pipeline
    provider_spec = build_provider_spec(cmd_spec, profile)

    # Return argv for backward compatibility
    return provider_spec.argv


def get_llm_cli(provider: str = DEFAULT_PROVIDER) -> str:
    """Get the CLI executable path for a provider.

    Returns the full executable path for cross-platform subprocess compatibility.
    On Windows, this ensures extensions (.cmd/.exe) are included.
    On macOS/Linux, returns the resolved path for reliability.

    Args:
        provider: LLM provider name

    Returns:
        Full path to CLI executable, or bare command name as fallback
    """
    provider_info = LLM_PROVIDERS.get(provider, LLM_PROVIDERS[DEFAULT_PROVIDER])
    cli_name = str(provider_info.get("cli", "claude"))
    # Full path for Windows compatibility (.cmd/.exe) and reliability everywhere
    cli_path = shutil.which(cli_name)
    return cli_path or cli_name


def get_llm_command() -> tuple[str, list[str]]:
    """Get the implementation LLM command and arguments.

    Returns:
        Tuple of (command, args) for subprocess execution.
        Uses provider-specific CLI:
        - Anthropic: claude (Claude Code CLI)
        - Google: gemini (Gemini CLI)
        - OpenAI: codex (OpenAI Codex CLI)

    Note:
        Consider using resolve_llm_config() + build_llm_args() for more control.
    """
    llm_config = get_llm_config()
    impl_config = llm_config.get("implementation", {})

    provider = impl_config.get("provider", DEFAULT_PROVIDER)
    model = impl_config.get("model", DEFAULT_MODEL)

    cli = get_llm_cli(provider)
    args = build_llm_args({"provider": provider, "model": model})

    return cli, args


# Deprecated re-exports — import from obra.execution.os_compat instead.
# Kept here to preserve existing import paths via obra.config lazy loading.


def __getattr__(name: str):
    """Lazy re-export for PROVIDER_API_KEY_ENV_VARS and build_subprocess_env."""
    if name in ("PROVIDER_API_KEY_ENV_VARS", "build_subprocess_env"):
        import obra.execution.os_compat as _os_compat

        _exports = {
            "PROVIDER_API_KEY_ENV_VARS": _os_compat.PROVIDER_API_KEY_ENV_VARS,
            "build_subprocess_env": _os_compat.build_subprocess_env,
        }
        return _exports[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


# Handler role names for role-based LLM configuration (ADR-061)
# Canonical pre-planning keys use the "enrichment_*" prefix. Legacy
# "scaffolded_*" aliases are accepted via _ROLE_ALIASES.
HANDLER_ROLES = (
    "derive",
    "examine",
    "revise",
    "execute",
    "fix",
    "review",
    "validator",
    "enrichment_assumptions",
    "enrichment_analogues",
    "enrichment_brief",
)

_ROLE_ALIASES: dict[str, str] = {
    "scaffolded_assumptions": "enrichment_assumptions",
    "scaffolded_analogues": "enrichment_analogues",
    "scaffolded_brief": "enrichment_brief",
}

# Default role-to-profile mappings when llm.roles is not configured
# Planning roles use orchestrator, execution roles use implementation
DEFAULT_ROLE_MAPPINGS: dict[str, str] = {
    # Handler actions
    "derive": "orchestrator",
    "examine": "orchestrator",
    "revise": "orchestrator",
    "execute": "implementation",
    "fix": "implementation",
    "review": "implementation",
    "validator": "implementation",
    # Intent enrichment stages (canonical keys)
    "enrichment_assumptions": "orchestrator",
    "enrichment_analogues": "orchestrator",
    "enrichment_brief": "orchestrator",
}


def _normalize_role_key(role: str) -> str:
    """Normalize role/action keys, supporting legacy aliases."""
    role_key = role.strip().lower()
    return _ROLE_ALIASES.get(role_key, role_key)


def _get_role_entry(roles: dict[str, Any], role: str) -> Any:
    """Return role config entry, checking canonical and legacy aliases."""
    if role in roles:
        return roles.get(role)
    for legacy_key, canonical_key in _ROLE_ALIASES.items():
        if canonical_key == role and legacy_key in roles:
            return roles.get(legacy_key)
    return None


def _resolve_action_profile(action: str) -> str:
    """Resolve action to orchestration profile role for tier-based routing."""
    action_key = _normalize_role_key(action)
    default_profile = DEFAULT_ROLE_MAPPINGS.get(action_key, "implementation")
    if default_profile not in ("orchestrator", "implementation"):
        default_profile = "implementation"

    llm_config = get_llm_config()
    roles = llm_config.get("roles", {})
    profiles = llm_config.get("profiles", {})
    role_entry = _get_role_entry(roles, action_key)

    if isinstance(role_entry, str):
        if role_entry in ("orchestrator", "implementation"):
            return role_entry
        if role_entry in profiles:
            return default_profile
    elif isinstance(role_entry, dict):
        profile_name = role_entry.get("profile")
        if isinstance(profile_name, str) and profile_name in ("orchestrator", "implementation"):
            return profile_name
        if isinstance(profile_name, str) and profile_name in profiles:
            return default_profile

    return default_profile


def resolve_action_llm_config(
    action: str,
    *,
    model_tier: str | None = None,
    override_provider: str | None = None,
    override_model: str | None = None,
    override_auth_method: str | None = None,
    override_thinking_level: str | None = None,
) -> dict[str, Any]:
    """Canonical operation resolver: action -> role -> tier/model config.

    Args:
        action: Action/handler key (derive, examine, revise, execute, fix, review, ...)
        model_tier: Optional fast/medium/high tier selector for the action.
            If omitted, resolves action profile config directly.
        override_provider: Optional provider override.
        override_model: Optional model override.
        override_auth_method: Optional auth method override (tier path only).
        override_thinking_level: Optional thinking level override.

    Returns:
        Resolved LLM config dictionary.
    """
    action_key = _normalize_role_key(action)
    if model_tier:
        profile_role = _resolve_action_profile(action_key)
        return resolve_tier_config(
            tier=model_tier,
            role=profile_role,
            override_provider=override_provider,
            override_model=override_model,
            override_auth_method=override_auth_method,
            override_thinking_level=override_thinking_level,
        )

    return resolve_role_llm_config(
        action_key,
        override_provider=override_provider,
        override_model=override_model,
        override_thinking_level=override_thinking_level,
    )


def resolve_role_llm_config(
    role: str,
    override_provider: str | None = None,
    override_model: str | None = None,
    override_thinking_level: str | None = None,
) -> dict[str, Any]:
    """Resolve LLM config for a handler role (derive, examine, execute, etc.).

    This function provides indirection between handlers and LLM settings,
    allowing different handlers to use different models based on configuration.

    Resolution order:
    1. llm.roles.<role> - explicit role configuration
    2. llm.profiles.<profile> - if role references a profile
    3. Default mapping (derive->orchestrator, execute->implementation)
    4. Top-level llm.* settings as final fallback

    Args:
        role: Handler role name (derive, examine, revise, execute, fix, review)
        override_provider: Optional provider override (session-only)
        override_model: Optional model override (session-only)
        override_thinking_level: Optional thinking level override (session-only)

    Returns:
        Resolved config dict with provider, auth_method, model, thinking_level keys

    Example:
        >>> # With config: llm.roles.derive: orchestrator
        >>> config = resolve_role_llm_config("derive")
        >>> config["model"]
        'opus'

        >>> # With config: llm.roles.execute: {profile: implementation, thinking_level: low}
        >>> config = resolve_role_llm_config("execute")
        >>> config["thinking_level"]
        'low'

    See:
        ADR-069: Role-Based LLM Configuration
    """
    role_key = _normalize_role_key(role)

    if role_key not in HANDLER_ROLES:
        logger.warning("Unknown handler role '%s', using implementation config", role)
        return resolve_llm_config("implementation")

    llm_config = get_llm_config()
    profiles = llm_config.get("profiles", {})
    roles = llm_config.get("roles", {})

    # Get role entry (may be string, dict, or None)
    role_entry = _get_role_entry(roles, role_key)

    resolved: dict[str, Any]

    if role_entry is None:
        # No explicit role config - use default mapping
        default_profile = DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation")
        if default_profile in profiles:
            resolved = profiles[default_profile].copy()
        else:
            # Fall back to legacy role config (llm.orchestrator.* or llm.implementation.*)
            resolved = resolve_llm_config(default_profile)

    elif isinstance(role_entry, str):
        # Simple profile reference: "derive: orchestrator"
        if role_entry in profiles:
            resolved = profiles[role_entry].copy()
        elif role_entry in ("orchestrator", "implementation"):
            # Legacy role name reference
            resolved = resolve_llm_config(role_entry)
        else:
            logger.warning(
                "Role '%s' references unknown profile '%s', using default",
                role_key,
                role_entry,
            )
            resolved = resolve_llm_config(DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation"))

    elif isinstance(role_entry, dict):
        if "profile" in role_entry:
            # Profile with overrides: {profile: orchestrator, thinking_level: high}
            profile_name = role_entry["profile"]
            if profile_name in profiles:
                resolved = profiles[profile_name].copy()
            elif profile_name in ("orchestrator", "implementation"):
                resolved = resolve_llm_config(profile_name)
            else:
                logger.warning(
                    "Role '%s' references unknown profile '%s', using default",
                    role_key,
                    profile_name,
                )
                resolved = resolve_llm_config(DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation"))

            # Apply overrides from role entry
            for key, value in role_entry.items():
                if key != "profile" and value is not None:
                    resolved[key] = value
        else:
            # Fully custom config (no profile reference)
            # Start with defaults and overlay role-specific settings
            default_profile = DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation")
            resolved = resolve_llm_config(default_profile)
            for key, value in role_entry.items():
                if value is not None:
                    resolved[key] = value
    else:
        logger.warning(
            "Invalid role config type for '%s': %s, using default",
            role_key,
            type(role_entry).__name__,
        )
        resolved = resolve_llm_config(DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation"))

    # Apply session overrides (highest priority)
    if override_provider:
        if override_provider not in LLM_PROVIDERS:
            msg = f"Invalid provider: {override_provider}"
            raise ValueError(msg)
        resolved["provider"] = override_provider

    if override_model:
        resolved["model"] = validate_model(
            override_model, resolved.get("provider", DEFAULT_PROVIDER)
        )

    if override_thinking_level:
        if override_thinking_level not in (*THINKING_LEVELS, DEFAULT_THINKING_SELECTION):
            msg = (
                f"Invalid thinking level: {override_thinking_level}. "
                f"Valid: {', '.join([*THINKING_LEVELS, DEFAULT_THINKING_SELECTION])}"
            )
            raise ValueError(msg)
        resolved["thinking_level"] = override_thinking_level

    context_role = _resolve_action_profile(role_key)
    context_tier = "medium"
    if isinstance(role_entry, dict):
        tier_value = role_entry.get("tier")
        if isinstance(tier_value, str) and tier_value in TIER_NAMES:
            context_tier = tier_value
    resolved["thinking_level"] = _materialize_default_thinking_level(
        resolved.get("provider", DEFAULT_PROVIDER),
        resolved.get("model"),
        resolved.get("thinking_level"),
        role=context_role,
        tier=context_tier,
    )

    logger.debug(
        "Resolved role '%s' config: provider=%s, model=%s, thinking=%s",
        role_key,
        resolved.get("provider"),
        resolved.get("model"),
        resolved.get("thinking_level"),
    )

    return resolved


# Public exports
__all__ = [
    "DEFAULT_ROLE_MAPPINGS",
    "DEFAULT_THINKING_BUDGET",
    # Thinking constants
    "DEFAULT_THINKING_SELECTION",
    "DEFAULT_THINKING_LEVEL",
    # Role-based configuration (ADR-061)
    "HANDLER_ROLES",
    "MODEL_PROVIDER_PATTERNS",
    "MODEL_PROVIDER_PREFIXES",
    # Model constants
    "MODEL_SHORTCUTS",
    # Subprocess environment
    "PROVIDER_API_KEY_ENV_VARS",
    "PROVIDER_TIER_DEFAULTS",
    "ROLE_TIER_DEFAULTS",
    "THINKING_BUDGET_MAX",
    # Thinking budget constants
    "THINKING_BUDGET_MIN",
    "THINKING_LEVELS",
    "THINKING_LEVEL_MAP",
    "TIER_FALLBACKS",
    "TIER_NAMES",
    "XHIGH_SUPPORTED_MODELS",
    "ReasoningSelection",
    "build_llm_args",
    "build_subprocess_env",
    "get_anthropic_api_thinking_param",
    "get_effective_thinking_value",
    "get_llm_cli",
    "get_llm_command",
    "get_llm_config",
    "get_role_tier_default",
    "get_llm_display",
    "get_project_planning_config",
    "get_provider_tier_defaults",
    # CLI building
    "get_thinking_keyword",
    # Thinking level functions
    "get_thinking_level_notes",
    # Model inference
    "infer_provider_from_model",
    # Config resolution
    "resolve_llm_config",
    "resolve_action_llm_config",
    "resolve_reasoning_selection",
    "resolve_role_llm_config",
    "resolve_tier_config",
    "set_llm_config",
    "update_role_tiers_for_provider",
    # Model validation
    "validate_model",
]
