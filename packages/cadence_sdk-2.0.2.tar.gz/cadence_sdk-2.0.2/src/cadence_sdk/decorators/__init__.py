"""Decorators for Cadence SDK plugins."""

from .settings_decorators import plugin_settings

__all__ = [
    "plugin_settings",
]
