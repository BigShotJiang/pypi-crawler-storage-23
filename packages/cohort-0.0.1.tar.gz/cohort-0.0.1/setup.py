from setuptools import setup

setup(
    name="cohort",
    version="0.0.1",
    description="Multi-agent orchestration framework for structured AI deliberation",
    long_description="# cohort\n\nMulti-agent orchestration framework. Full release coming soon.",
    long_description_content_type="text/markdown",
    author="Ryan Wheeler",
    url="https://github.com/rywheeler/cohort",
    py_modules=["cohort"],
    python_requires=">=3.10",
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)
