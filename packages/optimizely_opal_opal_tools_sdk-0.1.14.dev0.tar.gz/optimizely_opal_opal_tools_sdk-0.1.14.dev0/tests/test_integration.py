#!/usr/bin/env python3
"""Tests for FastAPI integration with the @tool decorator and resources."""

import json
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from opal_tools_sdk import (
    UI,
    ToolsService,
    _registry,
    resource,
    tool,
)
from pydantic import BaseModel, Field


class SimpleParams(BaseModel):
    """Simple tool parameters."""

    name: str = Field(description="The name to greet")


@pytest.fixture(autouse=True)
def clear_registry():
    """Clear the global registry before each test."""
    _registry.services.clear()
    yield
    _registry.services.clear()


def test_simple_tool_endpoint():
    """Test that a simple tool creates a working endpoint"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="greet", description="Greet a user")
    async def greet_tool(params: SimpleParams, environment: dict) -> str:
        """Greet tool."""
        return f"Hello, {params.name}!"

    client = TestClient(app)

    # Call the endpoint (returns result directly, not wrapped in response envelope)
    response = client.post("/tools/greet", json={"name": "Alice"})

    assert response.status_code == 200
    # Verify correct content-type header for regular tools (application/json)
    assert response.headers["content-type"] == "application/json"
    assert response.json() == "Hello, Alice!"


def test_environment_parameter_passed():
    """Test that environment parameter is correctly passed to the tool"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="check_env", description="Check environment")
    async def check_env(params: SimpleParams, environment: dict) -> dict:
        """Check environment tool."""
        return {
            "has_environment": environment is not None,
            "param_name": params.name,
        }

    client = TestClient(app)

    # Call the endpoint
    response = client.post("/tools/check_env", json={"name": "Test"})

    assert response.status_code == 200
    assert response.json() == {
        "has_environment": True,
        "param_name": "Test",
    }


def test_invalid_parameters():
    """Test that invalid parameters return proper error"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="validate_params", description="Validate parameters")
    async def validate_params(params: SimpleParams, environment: dict) -> str:
        """Validate params tool."""
        return f"Valid: {params.name}"

    client = TestClient(app)

    # Call with missing required parameter
    response = client.post("/tools/validate_params", json={})

    assert response.status_code == 400  # Validation error (Pydantic ValidationError)


def test_multiple_tools_same_service():
    """Test that multiple tools can be registered on the same service"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="tool_one", description="First tool")
    async def tool_one(params: SimpleParams, environment: dict) -> str:
        """Tool one."""
        return "Tool 1"

    @tool(name="tool_two", description="Second tool")
    async def tool_two(params: SimpleParams, environment: dict) -> str:
        """Tool two."""
        return "Tool 2"

    client = TestClient(app)

    # Call both endpoints
    response1 = client.post("/tools/tool_one", json={"name": "Test"})
    response2 = client.post("/tools/tool_two", json={"name": "Test"})

    assert response1.status_code == 200
    assert response2.status_code == 200
    assert response1.json() == "Tool 1"
    assert response2.json() == "Tool 2"


def test_resource_endpoint():
    """Test that a resource endpoint returns correct content."""
    app = FastAPI()
    _ = ToolsService(app)

    @resource(
        uri="ui://test-app/form",
        name="test-form",
        description="A test form",
        mime_type="application/vnd.opal.proteus+json",
    )
    async def get_form() -> str:
        """Get test form."""
        proteus_spec = {"type": "form", "fields": [{"name": "title", "type": "text"}]}
        return json.dumps(proteus_spec)

    client = TestClient(app)

    # Call the resource endpoint via POST /resources/read
    response = client.post("/resources/read", json={"uri": "ui://test-app/form"})

    assert response.status_code == 200
    assert response.json() == {
        "uri": "ui://test-app/form",
        "mimeType": "application/vnd.opal.proteus+json",
        "text": '{"type": "form", "fields": [{"name": "title", "type": "text"}]}',
    }


def test_tool_with_ui_resource():
    """Test that a tool can declare an associated UI resource."""
    app = FastAPI()
    _ = ToolsService(app)

    @resource(
        uri="ui://test-app/create-form",
        name="create-form",
        description="Form for creating items",
        mime_type="application/vnd.opal.proteus+json",
    )
    async def get_create_form() -> str:
        """Get create form."""
        return "{}"

    @tool(
        name="create_item",
        description="Create a new item",
        ui_resource="ui://test-app/create-form",
    )
    async def create_item(params: SimpleParams) -> dict:
        """Create item tool."""
        return {"id": "item-123", "title": params.name}

    client = TestClient(app)

    # Call discovery endpoint
    response = client.get("/discovery")

    assert response.status_code == 200
    discovery = response.json()

    # Verify function has ui_resource
    assert len(discovery["functions"]) == 1
    function = discovery["functions"][0]
    assert function["name"] == "create_item"
    assert function["ui_resource"] == "ui://test-app/create-form"


def test_discovery():
    """Test that discovery works."""
    app = FastAPI()
    _ = ToolsService(app)

    @tool(name="simple_tool", description="A simple tool")
    async def simple_tool(params: SimpleParams) -> dict:
        """Simple tool."""
        return {"result": "ok"}

    client = TestClient(app)

    # Call discovery endpoint
    response = client.get("/discovery")

    assert response.status_code == 200
    assert response.json() == {
        "functions": [
            {
                "name": "simple_tool",
                "description": "A simple tool",
                "parameters": [
                    {
                        "name": "name",
                        "in_context": False,
                        "description": "The name to greet",
                        "required": True,
                        "type": "string",
                    }
                ],
                "endpoint": "/tools/simple_tool",
                "http_method": "POST",
            }
        ]
    }


def test_multiple_resources():
    """Test registering multiple resources."""
    app = FastAPI()
    _ = ToolsService(app)

    @resource(
        uri="ui://test-app/form1",
        name="form1",
        description="First form",
        mime_type="application/vnd.opal.proteus+json",
    )
    async def get_form1() -> str:
        """Get form 1."""
        return "{}"

    @resource(
        uri="ui://test-app/form2",
        name="form2",
        description="Second form",
        mime_type="application/vnd.opal.proteus+json",
    )
    async def get_form2() -> str:
        """Get form 2."""
        return "{}"

    client = TestClient(app)

    # Verify both resources are accessible via POST /resources/read
    response1 = client.post("/resources/read", json={"uri": "ui://test-app/form1"})
    assert response1.status_code == 200
    assert response1.json()["uri"] == "ui://test-app/form1"

    response2 = client.post("/resources/read", json={"uri": "ui://test-app/form2"})
    assert response2.status_code == 200
    assert response2.json()["uri"] == "ui://test-app/form2"


def test_resource_with_proteus_document_return():
    """Test that a resource returning ProteusDocument is auto-serialized."""
    app = FastAPI()
    _ = ToolsService(app)

    @resource(
        uri="ui://test-app/dynamic-form",
        name="dynamic-form",
        description="A dynamic form using UI.Document",
    )
    async def get_dynamic_form():
        """Get dynamic form as ProteusDocument."""
        return UI.Document(
            appName="Item Manager",
            title="Create New Item",
            body=[
                UI.Heading(children="Create Item"),
                UI.Field(
                    label="Item Name",
                    children=UI.Input(name="item_name", placeholder="Enter item name"),
                ),
                UI.Field(
                    label="Description",
                    children=UI.Textarea(name="description", placeholder="Enter description"),
                ),
            ],
            actions=[
                UI.Action(children="Save", appearance="primary"),
                UI.CancelAction(children="Cancel"),
            ],
        )

    client = TestClient(app)

    # Call the resource endpoint
    response = client.post("/resources/read", json={"uri": "ui://test-app/dynamic-form"})

    assert response.status_code == 200
    result = response.json()

    # Verify URI
    assert result["uri"] == "ui://test-app/dynamic-form"

    # Verify MIME type was auto-set
    assert result["mimeType"] == "application/vnd.opal.proteus+json"

    # Verify the text is a serialized ProteusDocument
    parsed_doc = json.loads(result["text"])
    assert parsed_doc["$type"] == "Document"
    assert len(parsed_doc["body"]) == 3
    assert parsed_doc["body"][0]["$type"] == "Heading"
    assert parsed_doc["body"][0]["children"] == "Create Item"
    assert parsed_doc["body"][1]["$type"] == "Field"
    assert parsed_doc["body"][1]["label"] == "Item Name"
    assert len(parsed_doc["actions"]) == 2
    assert parsed_doc["actions"][0]["$type"] == "Action"
    assert parsed_doc["actions"][1]["$type"] == "CancelAction"


def test_resource_with_proteus_document_and_explicit_mime_type():
    """Test that explicit MIME type is preserved when returning ProteusDocument."""
    app = FastAPI()
    _ = ToolsService(app)

    @resource(
        uri="ui://test-app/custom-mime",
        name="custom-mime",
        description="ProteusDocument with custom MIME type",
        mime_type="application/custom+json",
    )
    async def get_custom():
        """Get custom resource."""
        return UI.Document(
            appName="Test App",
            title="Test Document",
            body=[UI.Text(children="Test")],
        )

    client = TestClient(app)

    # Call the resource endpoint
    response = client.post("/resources/read", json={"uri": "ui://test-app/custom-mime"})

    assert response.status_code == 200
    result = response.json()

    # Verify explicit MIME type is preserved (not auto-set)
    assert result["mimeType"] == "application/custom+json"
