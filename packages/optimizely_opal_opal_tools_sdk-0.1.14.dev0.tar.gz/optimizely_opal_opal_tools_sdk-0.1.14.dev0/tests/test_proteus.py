#!/usr/bin/env python3
"""Tests for Proteus components."""

from opal_tools_sdk import UI


def test_proteus_heading():
    """Test creating a UI.Heading with children"""
    heading = UI.Heading(children="Test Heading")
    assert heading.field_type == "Heading"

    doc = UI.Document(appName="Test App", body=heading, title="Test Title")
    data = doc.model_dump(by_alias=True, exclude_none=True, mode='json')
    assert data == {
        "$type": "Document",
        "appName": "Test App",
        "body": {"$type": "Heading", "children": "Test Heading"},
        "title": "Test Title",
    }


def test_proteus_text():
    """Test creating a UI.Text with children"""
    text = UI.Text(children="Test text content")
    assert text.field_type == "Text"

    doc = UI.Document(appName="Test App", body=text, title="Test Title")
    data = doc.model_dump(by_alias=True, exclude_none=True, mode='json')
    assert data == {
        "$type": "Document",
        "appName": "Test App",
        "body": {"$type": "Text", "children": "Test text content"},
        "title": "Test Title",
    }


def test_proteus_heading_with_props():
    """Test UI.Heading with additional properties"""
    heading = UI.Heading(children="Styled Heading", level="2", fontSize="md", fontWeight="600")

    doc = UI.Document(appName="Test App", body=heading, title="Test Title")
    data = doc.model_dump(by_alias=True, exclude_none=True, mode='json')
    assert data == {
        "$type": "Document",
        "appName": "Test App",
        "body": {
            "$type": "Heading",
            "children": "Styled Heading",
            "level": "2",
            "fontSize": "md",
            "fontWeight": "600",
        },
        "title": "Test Title",
    }


def test_proteus_group():
    """Test creating a UI.Group with children array"""
    group = UI.Group(
        flexDirection="column",
        gap="16",
        children=[
            UI.Text(children="First item"),
            UI.Text(children="Second item"),
        ],
    )

    doc = UI.Document(appName="Test App", body=group, title="Test Title")
    data = doc.model_dump(by_alias=True, exclude_none=True, mode='json')
    assert data == {
        "$type": "Document",
        "appName": "Test App",
        "body": {
            "$type": "Group",
            "flexDirection": "column",
            "gap": "16",
            "children": [
                {"$type": "Text", "children": "First item"},
                {"$type": "Text", "children": "Second item"},
            ],
        },
        "title": "Test Title",
    }


def test_proteus_document():
    """Test creating a UI.Document"""
    doc = UI.Document(
        appName="Test App",
        body=[
            UI.Heading(children="Title", level="2"),
            UI.Text(children="Description"),
        ],
        title="Test Title",
    )

    data = doc.model_dump(by_alias=True, exclude_none=True, mode='json')
    assert data == {
        "$type": "Document",
        "appName": "Test App",
        "body": [
            {"$type": "Heading", "children": "Title", "level": "2"},
            {"$type": "Text", "children": "Description"},
        ],
        "title": "Test Title",
    }
