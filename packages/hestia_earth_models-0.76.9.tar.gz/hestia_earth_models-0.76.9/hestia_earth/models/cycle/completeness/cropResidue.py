from hestia_earth.schema import TermTermType
from hestia_earth.utils.model import find_term_match, filter_list_term_type
from hestia_earth.utils.tools import list_sum, flatten

from hestia_earth.models.log import logRequirements, log_as_table
from . import MODEL

REQUIREMENTS = {
    "Cycle": {
        "completeness.cropResidue": "False",
        "products": [
            {"@type": "Product", "value": ">= 0", "term.@id": "belowGroundCropResidue"},
            {
                "@type": "Product",
                "value": "> 0",
                "term.@id": "aboveGroundCropResidueTotal",
            },
            {
                "@type": "Product",
                "value": "> 0",
                "term.@id": [
                    "aboveGroundCropResidueRemoved",
                    "aboveGroundCropResidueIncorporated",
                    "aboveGroundCropResidueBurnt",
                    "aboveGroundCropResidueLeftOnField",
                ],
            },
        ],
        "practices": [
            {
                "@type": "Practice",
                "value": "100",
                "term.termType": "cropResidueManagement",
            }
        ],
    }
}
RETURNS = {"Completeness": {"cropResidue": ""}}
MODEL_KEY = "cropResidue"

_REQUIRED_TERM_IDS = [
    i["term.@id"]
    for i in REQUIREMENTS["Cycle"]["products"]
    if isinstance(i["term.@id"], str)
]
_OPTIONAL_TERM_IDS = flatten(
    [
        i["term.@id"]
        for i in REQUIREMENTS["Cycle"]["products"]
        if isinstance(i["term.@id"], list)
    ]
)


def run(cycle: dict):
    products = cycle.get("products", [])

    # all required terms + at least one of the optional terms must be present
    required_products = [
        {
            "product-id": term_id,
            "value": list_sum(
                find_term_match(products, term_id).get("value"), default=None
            ),
            "allow-zero-value": term_id.startswith("below"),
        }
        for term_id in _REQUIRED_TERM_IDS
    ]
    required_abg_total = list_sum(
        [
            p.get("value")
            for p in required_products
            if p.get("product-id") == "aboveGroundCropResidueTotal"
        ]
    )

    optional_products = [
        {
            "product-id": term_id,
            "value": list_sum(
                find_term_match(products, term_id).get("value"), default=None
            ),
            "allow-zero-value": False,
        }
        for term_id in _OPTIONAL_TERM_IDS
    ]
    sum_optional_products = list_sum(
        [p.get("value") for p in optional_products if p.get("value") is not None]
    )
    has_total_products = (
        required_abg_total * 0.995
        <= sum_optional_products
        <= required_abg_total * 1.005
    )

    practices = [
        {
            "practice-id": practice.get("term", {}).get("@id"),
            "value": list_sum(practice.get("value"), default=None),
        }
        for practice in filter_list_term_type(
            cycle.get("practices", []), TermTermType.CROPRESIDUEMANAGEMENT
        )
    ]
    sum_practices = list_sum(
        [p.get("value") for p in practices if p.get("value") is not None]
    )
    has_total_practices = 99.5 <= sum_practices <= 100.5

    has_all_required_products = all(
        [
            all([v["value"] is not None, v["allow-zero-value"] or v["value"] != 0])
            for v in required_products
        ]
    )

    has_one_optional_product = any(
        [
            all([v["value"] is not None, v["allow-zero-value"] or v["value"] != 0])
            for v in optional_products
        ]
    )

    logRequirements(
        cycle,
        model=MODEL,
        term=None,
        key=MODEL_KEY,
        has_all_required_products=has_all_required_products,
        has_one_optional_product=has_one_optional_product,
        has_total_products=has_total_products,
        has_total_practices=has_total_practices,
        required_products=log_as_table(required_products),
        optional_products=log_as_table(optional_products),
        sum_optional_products=sum_optional_products,
        practices=log_as_table(practices),
        sum_practices=sum_practices,
    )

    return all(
        [
            has_all_required_products,
            has_one_optional_product,
            has_total_products or has_total_practices,
        ]
    )
