from functools import lru_cache
from hestia_earth.utils.lookup import (
    download_lookup,
    get_table_value,
    extract_grouped_data,
)
from hestia_earth.utils.tools import safe_parse_float

from hestia_earth.models.log import debugMissingLookup
from hestia_earth.models.utils.constant import DEFAULT_COUNTRY_ID
from hestia_earth.models.utils.impact_assessment import get_site, get_country_id
from hestia_earth.models.utils.lookup import get_region_lookup_value
from hestia_earth.models.utils.landCover import get_group_term_id
from . import MODEL


def _lookup_value(
    term_id: str, lookup_name: str, col_match: str, col_val: str, column: str
):
    value = get_table_value(download_lookup(lookup_name), col_match, col_val, column)
    debugMissingLookup(
        lookup_name, col_match, col_val, column, value, model=MODEL, term=term_id
    )
    return value


@lru_cache()
def _region_factor(
    term_id: str,
    country_id: str,
    grouping: str,
    ecoregion: str,
    lookup_prefix: str,
    lookup_name: str,
    group_key: str,
):
    value = (
        get_region_lookup_value(
            lookup_name, country_id, grouping, model=MODEL, term=term_id
        )
        if lookup_prefix == "region"
        else _lookup_value(term_id, lookup_name, "ecoregion", ecoregion, grouping)
    )
    value = extract_grouped_data(value, group_key) if group_key else value
    return safe_parse_float(value, default=None)


def get_region_factor(
    term_id: str,
    impact_assessment: dict,
    lookup_suffix: str,
    group_key: str = None,
    blank_node: dict = None,
):
    term_id = blank_node.get("term", {}).get("@id")
    is_during_cycle = term_id.endswith("DuringCycle")
    land_cover = blank_node.get("landCover", {}).get("@id")

    site = get_site(impact_assessment)
    ecoregion = site.get("ecoregion") if is_during_cycle else None
    country_id = (
        get_country_id(impact_assessment, blank_node=blank_node)
        if is_during_cycle
        else DEFAULT_COUNTRY_ID
    )
    grouping = get_group_term_id(land_cover)

    lookup_prefix = "ecoregion" if ecoregion else "region" if country_id else None
    lookup_name = f"{lookup_prefix}-landCover-{lookup_suffix}.csv"

    return _region_factor(
        term_id=term_id,
        grouping=grouping,
        country_id=country_id,
        ecoregion=ecoregion,
        lookup_prefix=lookup_prefix,
        lookup_name=lookup_name,
        group_key=group_key,
    )
