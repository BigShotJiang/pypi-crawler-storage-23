import numpy as np

_PERCENTILES = [10, 90]


def _include_percentiles(node: dict):
    values = np.percentile(node.get("distribution", []), _PERCENTILES)
    return {
        f"percentile{percentile}th": float(value)
        for percentile, value in zip(_PERCENTILES, values)
    }


def _process_node(node: dict):
    return node | (
        _include_percentiles(node)
        if len(node.get("distribution", [])) > len(_PERCENTILES)
        else {}
    )


def run(impact: dict):
    return impact | (
        {
            key: list(map(_process_node, impact[key]))
            for key in ["emissionsResourceUse", "impacts", "endpoints"]
            if key in impact
        }
        if impact.get("aggregated", False)
        else {}
    )
