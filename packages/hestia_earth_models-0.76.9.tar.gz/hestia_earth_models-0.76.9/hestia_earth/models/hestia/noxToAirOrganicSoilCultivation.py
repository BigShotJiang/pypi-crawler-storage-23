from hestia_earth.schema import EmissionMethodTier

from hestia_earth.models.log import (
    format_conditional_message,
    format_float,
    logRequirements,
    logShouldRun,
)
from hestia_earth.models.utils.emission import _new_emission
from hestia_earth.models.utils.measurement import most_relevant_measurement_value

from . import MODEL

REQUIREMENTS = {
    "Cycle": {
        "site": {
            "@type": "Site",
            "measurements": [
                {"@type": "Measurement", "value": "", "term.@id": "organicSoils"},
            ],
        },
    }
}
RETURNS = {"Emission": [{"value": "", "methodTier": "tier 1"}]}
TERM_ID = "noxToAirOrganicSoilCultivation"
TIER = EmissionMethodTier.TIER_1.value


def _emission():
    emission = _new_emission(term=TERM_ID, model=MODEL, value=0)
    emission["methodTier"] = TIER
    return emission


def _should_run(cycle: dict):
    end_date = cycle.get("endDate")
    site = cycle.get("site", {})
    measurements = site.get("measurements", [])

    organic_soils = most_relevant_measurement_value(
        measurements, "organicSoils", end_date
    )

    no_organic_soils = organic_soils is not None and organic_soils == 0

    logRequirements(
        cycle,
        model=MODEL,
        term=TERM_ID,
        organic_soils=format_float(organic_soils, unit="pct"),
        no_organic_soils=format_conditional_message(
            no_organic_soils,
            "True (the model can run, zero emissions can be assumed)",
            "False (the model cannot run, emission factors not available)",
        ),
    )

    should_run = all([no_organic_soils])

    logShouldRun(cycle, MODEL, TERM_ID, should_run, methodTier=TIER)

    return should_run


def run(cycle: dict):
    should_run = _should_run(cycle)
    return [_emission()] if should_run else []
