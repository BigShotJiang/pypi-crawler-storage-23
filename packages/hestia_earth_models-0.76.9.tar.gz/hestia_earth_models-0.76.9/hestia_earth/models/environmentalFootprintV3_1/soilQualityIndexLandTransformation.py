from hestia_earth.utils.tools import list_sum

from hestia_earth.models.utils.impact_assessment import get_country_id
from hestia_earth.models.utils.landCover import get_pef_grouping
from hestia_earth.models.utils.lookup import get_region_lookup_value
from hestia_earth.models.utils.landTransformation import run as run_landTransformation
from . import MODEL

REQUIREMENTS = {
    "ImpactAssessment": {
        "emissionsResourceUse": [
            {
                "@type": "Indicator",
                "term.@id": [
                    "landTransformation20YearAverageDuringCycle",
                    "landTransformation20YearAverageInputsProduction",
                ],
                "value": "",
                "landCover": {"@type": "Term", "term.termType": "landCover"},
                "previousLandCover": {"@type": "Term", "term.termType": "landCover"},
            }
        ],
        "optional": {
            "country": {"@type": "Term", "termType": "region"},
        },
    }
}
# Note: CFs in `region-pefTermGrouping-landTransformation-from.csv` appear to be the opposite values as those in
# `region-pefTermGrouping-landTransformation-to.csv` but can be different in some cases.
LOOKUPS = {
    "region-pefTermGrouping-landTransformation-from": "",
    "region-pefTermGrouping-landTransformation-to": "",
    "landCover": "pefTermGrouping",
}
RETURNS = {"Indicator": {"value": ""}}
TERM_ID = "soilQualityIndexLandTransformation"

from_lookup_file = f"{list(LOOKUPS.keys())[0]}.csv"
to_lookup_file = f"{list(LOOKUPS.keys())[1]}.csv"


def _extend_indicator_data(impact_assessment: dict, indicator: dict) -> dict:
    country_id = get_country_id(impact_assessment, blank_node=indicator)

    grouping_from = get_pef_grouping(indicator.get("previousLandCover", {}).get("@id"))
    coefficient_from = (
        get_region_lookup_value(
            model=MODEL,
            term=TERM_ID,
            lookup_name=from_lookup_file,
            term_id=country_id,
            column=grouping_from,
            fallback_world=True,
        )
        if grouping_from
        else None
    )

    grouping_to = get_pef_grouping(indicator.get("landCover", {}).get("@id"))
    coefficient_to = (
        get_region_lookup_value(
            model=MODEL,
            term=TERM_ID,
            lookup_name=to_lookup_file,
            term_id=country_id,
            column=grouping_to,
            fallback_world=True,
        )
        if grouping_to
        else None
    )

    return {
        "country-id": country_id,
        "pef-grouping-from": grouping_from,
        "factor-from": coefficient_from,
        "pef-grouping-to": grouping_to,
        "factor-to": coefficient_to,
        "coefficient": (
            list_sum([coefficient_from, coefficient_to], default=0) * 20
            if all(
                [
                    coefficient_from is not None,
                    coefficient_to is not None,
                ]
            )
            else None
        ),
    }


def run(impact_assessment: dict):
    return run_landTransformation(
        model=MODEL,
        term_id=TERM_ID,
        period=20,
        impact_assessment=impact_assessment,
        extend_indicator_data_func=_extend_indicator_data,
    )
