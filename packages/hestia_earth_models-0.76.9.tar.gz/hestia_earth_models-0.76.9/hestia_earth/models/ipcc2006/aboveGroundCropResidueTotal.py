from hestia_earth.schema import TermTermType
from hestia_earth.utils.model import filter_list_term_type
from hestia_earth.utils.tools import list_sum, safe_parse_float

from hestia_earth.models.log import logRequirements, logShouldRun, log_as_table
from hestia_earth.models.utils.property import get_node_property_value
from hestia_earth.models.utils.completeness import _is_term_type_incomplete
from hestia_earth.models.utils.product import _new_product
from hestia_earth.models.utils.crop import get_crop_lookup_value
from hestia_earth.models.utils.cropResidue import sum_above_ground_crop_residue
from . import MODEL

REQUIREMENTS = {
    "Cycle": {
        "completeness.cropResidue": "False",
        "products": [
            {
                "@type": "Product",
                "primary": "True",
                "value": "> 0",
                "optional": {
                    "properties": [
                        {"@type": "Property", "value": "", "term.@id": "dryMatter"}
                    ]
                },
            }
        ],
    }
}
LOOKUPS = {"crop": ["Crop_residue_intercept", "Crop_residue_slope"]}
RETURNS = {"Product": [{"value": ""}]}
TERM_ID = "aboveGroundCropResidueTotal"
PROPERTY_KEY = "dryMatter"


def _product_data(product: dict):
    term_id = product.get("term", {}).get("@id")
    value = list_sum(product.get("value"), default=None)
    dm_value = get_node_property_value(MODEL, product, PROPERTY_KEY, default=None)
    lookup_data = {
        lookup: safe_parse_float(
            get_crop_lookup_value(MODEL, TERM_ID, term_id, lookup), default=None
        )
        for lookup in LOOKUPS["crop"]
    }

    is_valid = all([value, dm_value] + list(lookup_data.values()))

    value_in_dm = (
        (
            value * dm_value * lookup_data["Crop_residue_slope"]
            + lookup_data["Crop_residue_intercept"] * 1000
        )
        if is_valid
        else None
    )

    return {
        "product-id": term_id,
        "product-value": value,
        "dryMatter": dm_value,
        "value-converted-with-dryMatter": value_in_dm,
        "valid": is_valid,
    } | lookup_data


def _should_run(cycle: dict):
    term_type_incomplete = _is_term_type_incomplete(cycle, TERM_ID)
    crop_residue_from_products = sum_above_ground_crop_residue(cycle)

    # filter crop products with matching data in the lookup
    crop_products = [
        _product_data(product)
        for product in filter_list_term_type(
            cycle.get("products", []), TermTermType.CROP
        )
    ]

    valid_products = [
        p
        for p in crop_products
        if p.get("valid")
        and p.get("value-converted-with-dryMatter") >= crop_residue_from_products
    ]

    has_single_valid_crop_product = len(valid_products) == 1
    value = (
        valid_products[0]["value-converted-with-dryMatter"]
        if has_single_valid_crop_product
        else None
    )

    logRequirements(
        cycle,
        model=MODEL,
        term=TERM_ID,
        term_type_cropResidue_incomplete=term_type_incomplete,
        minimum_crop_residue=crop_residue_from_products,
        has_single_valid_crop_product=has_single_valid_crop_product,
        crop_products=log_as_table(crop_products),
    )

    should_run = all([term_type_incomplete, has_single_valid_crop_product])
    logShouldRun(cycle, MODEL, TERM_ID, should_run)
    return should_run, value


def run(cycle: dict):
    should_run, value = _should_run(cycle)
    return [_new_product(term=TERM_ID, model=MODEL, value=value)] if should_run else []
