def test_import():
    import xeroml  # noqa: F401
