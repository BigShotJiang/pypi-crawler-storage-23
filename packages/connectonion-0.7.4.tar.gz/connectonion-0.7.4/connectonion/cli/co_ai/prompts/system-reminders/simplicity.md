---
name: simplicity
triggers:
  - tool: edit
  - tool: multi_edit
  - tool: write
---

<system-reminder>
Keep it simple:
- Only change what's directly needed
- Don't add error handling for scenarios that can't happen
- Three similar lines > premature abstraction
</system-reminder>
