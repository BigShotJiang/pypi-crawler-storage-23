::: mkdocs-typer2
    :module: bmde.cli
    :name: bmde

