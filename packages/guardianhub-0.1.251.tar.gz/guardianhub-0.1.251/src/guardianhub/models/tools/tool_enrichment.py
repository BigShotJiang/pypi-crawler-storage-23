from pydantic import BaseModel, Field, field_validator
from typing import Dict, Any, Optional, List
from guardianhub.models.registry.registry import register_model


@register_model
class EnrichedPayload(BaseModel):
    """
    The 'Refined Intelligence' packet.
    Converts raw LLM intent into a machine-executable payload.
    """
    tool_name: str = Field(..., description="The literal name of the tool to be executed.")
    table: Optional[str] = Field(None, description="The target database table (e.g., 'incident', 'change_request').")
    sysparm_query: Optional[str] = Field(None, description="ServiceNow encoded query string.")
    params: Dict[str, Any] = Field(default_factory=dict, description="Generic parameters for non-SNOW tools.")
    rationale: str = Field(..., description="Brief technical justification for these specific parameters.")

    @field_validator('table')
    @classmethod
    def validate_table_name(cls, v: Optional[str]) -> Optional[str]:
        if v and v.lower() not in ["incident", "change_request", "cmdb_ci", "sys_user"]:
            # Optional: Strict enforcement of allowed tables
            pass
        return v

@register_model
class EnrichedResponse(BaseModel):
    """The structured output wrapper for the Tactical LLM call."""
    payload: EnrichedPayload
    confidence: float = Field(ge=0.0, le=1.0)