# models/agent_models.py
from typing import Dict, List, Optional, Any, Literal

from pydantic import BaseModel, Field, field_serializer,ConfigDict
from guardianhub.models.registry.registry import register_model

@register_model
class WebSearchQuery(BaseModel):
    """Model for search query parameters."""
    query: str
    categories: Optional[List[str]] = Field(default_factory=list)
    language: Optional[str] = "en"
    time_range: Optional[str] = None
    results_per_page: int = 10
    max_pages: int = 1

@register_model
class WebSearchResult(BaseModel):
    """Model for search results."""
    url: str
    title: str
    content: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = {}