"""Generated OpenAPI clients.

Each service is generated into a subpackage, e.g.

- celine.sdk.openapi.policies
- celine.sdk.openapi.dt

These are generated via `celine-sdk generate services.yaml`.
"""
