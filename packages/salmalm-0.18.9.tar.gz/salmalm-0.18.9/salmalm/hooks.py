# Backward-compatibility shim — real module is salmalm.features.hooks
import warnings as _w
_w.warn("hooks is a shim; use salmalm.features.hooks directly", DeprecationWarning, stacklevel=2)
import importlib as _importlib
import sys as _sys
_real = _importlib.import_module("salmalm.features.hooks")
_sys.modules[__name__] = _real
