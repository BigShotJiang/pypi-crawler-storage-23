# Copyright 2025 Veritensor Security Apache 2.0
# RAG Scanner: Detects Prompt Injections, PII, and Stealth Attacks (CSS/HTML hiding).

import logging
import re 
from typing import List, Generator, Set
from pathlib import Path
from veritensor.engines.static.rules import SignatureLoader
from veritensor.engines.content.pii import PIIScanner
from veritensor.core.text_utils import normalize_text, extract_base64_content
from veritensor.core.file_utils import validate_file_extension 

logger = logging.getLogger(__name__)

# Supported text formats for RAG scanning
TEXT_EXTENSIONS = {
    # Documentation & Markup
    ".txt", ".md", ".markdown", ".rst", ".adoc", ".asciidoc", 
    ".tex", ".org", ".wiki", ".html", ".htm", ".css",
    
    # Data & Configs
    ".json", ".xml", ".yaml", ".yml", ".toml", 
    ".ini", ".cfg", ".conf", ".env", ".properties", ".editorconfig",
    
    # Source Code
    ".py", ".js", ".ts", ".java", ".c", ".cpp", ".h", ".hpp",
    ".rs", ".go", ".rb", ".php", ".pl", ".lua",
    ".sh", ".bash", ".zsh", ".ps1", ".bat", ".sql",
    
    # Infrastructure
    ".dockerfile", ".tf", ".tfvars", ".k8s", ".helm", ".tpl",
    ".gitignore", ".gitattributes",
    
    # Logs
    ".log", ".out", ".err"
}

DOC_EXTS = {".pdf", ".docx", ".pptx"}

# Import Optional Dependencies
try:
    import pypdf
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

try:
    import docx
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False

try:
    from pptx import Presentation
    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False

CHUNK_SIZE = 1024 * 1024 # 1MB chunks
OVERLAP_SIZE = 4096      # 4KB overlap

# --- STEALTH ATTACK SIGNATURES (CSS/HTML Hiding) ---
STEALTH_PATTERNS = [
    r"font-size:\s*0px",
    r"font-size:\s*1px",
    r"color:\s*white",
    r"color:\s*#ffffff",
    r"color:\s*#fff",
    r"color:\s*transparent",
    r"display:\s*none",
    r"visibility:\s*hidden",
    r"opacity:\s*0",
    r"position:\s*absolute;\s*left:\s*-\d+px",
    r"z-index:\s*-\d+",
    r"<!--.*?ignore previous.*?-->", 
    r"<span[^>]*style=.*?>.*?</span>" 
]

# Copyright 2025 Veritensor Security Apache 2.0
# RAG Scanner: Detects Prompt Injections, PII, and Stealth Attacks (CSS/HTML hiding).

import logging
import re 
from typing import List, Generator, Set
from pathlib import Path
from veritensor.engines.static.rules import SignatureLoader
from veritensor.engines.content.pii import PIIScanner
# --- NEW IMPORT ---
from veritensor.core.text_utils import normalize_text, detect_stealth_text

logger = logging.getLogger(__name__)

# Supported text formats for RAG scanning
TEXT_EXTENSIONS = {
    # Documentation & Markup
    ".txt", ".md", ".markdown", ".rst", ".adoc", ".asciidoc", 
    ".tex", ".org", ".wiki", ".html", ".htm", ".css",
    
    # Data & Configs
    ".json", ".xml", ".yaml", ".yml", ".toml", 
    ".ini", ".cfg", ".conf", ".env", ".properties", ".editorconfig",
    
    # Source Code
    ".py", ".js", ".ts", ".java", ".c", ".cpp", ".h", ".hpp",
    ".rs", ".go", ".rb", ".php", ".pl", ".lua",
    ".sh", ".bash", ".zsh", ".ps1", ".bat", ".sql",
    
    # Infrastructure
    ".dockerfile", ".tf", ".tfvars", ".k8s", ".helm", ".tpl",
    ".gitignore", ".gitattributes",
    
    # Logs
    ".log", ".out", ".err"
}

DOC_EXTS = {".pdf", ".docx", ".pptx"}

# Import Optional Dependencies
try:
    import pypdf
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

try:
    import docx
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False

try:
    from pptx import Presentation
    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False

CHUNK_SIZE = 1024 * 1024 # 1MB chunks
OVERLAP_SIZE = 4096      # 4KB overlap

# --- STEALTH ATTACK SIGNATURES (CSS/HTML Hiding) ---
STEALTH_PATTERNS = [
    r"font-size:\s*0px",
    r"font-size:\s*1px",
    r"color:\s*white",
    r"color:\s*#ffffff",
    r"color:\s*#fff",
    r"color:\s*transparent",
    r"display:\s*none",
    r"visibility:\s*hidden",
    r"opacity:\s*0",
    r"position:\s*absolute;\s*left:\s*-\d+px",
    r"z-index:\s*-\d+",
    r"<!--.*?ignore previous.*?-->", 
    r"<span[^>]*style=.*?>.*?</span>" 
]

def scan_document(file_path: Path) -> List[str]:
    """
    Universal entry point for scanning documents (RAG Data).
    Dispatches to specific extractors based on extension and performs
    deep inspection for injections, obfuscation, and PII.
    """
    ext = file_path.suffix.lower()
    threats = []
    
    # Load signatures once
    signatures = SignatureLoader.get_prompt_injections()

    try:
        # --- PHASE 0: File Integrity (Magic Numbers) ---
        # Check if the file is an executable masquerading as a document (e.g. exe renamed to pdf)
        extension_threat = validate_file_extension(file_path)
        if extension_threat:
            threats.append(extension_threat)
            # CRITICAL: If it's a binary threat, do not attempt to parse as text
            return threats
            
        # --- PHASE 1: Raw Content Scan (Stealth Detection) ---
        # Scan binary content for hidden strings before text extraction
        if ext in DOC_EXTS or ext in TEXT_EXTENSIONS:
            raw_threats = _scan_raw_binary(file_path)
            threats.extend(raw_threats)
            
        # --- PHASE 2: Extracted Text Scan (Semantic Detection) ---
        text_generator = None
        
        # Select appropriate extractor
        if ext in TEXT_EXTENSIONS:
            text_generator = _read_text_sliding(file_path)
        elif ext == ".pdf" and PDF_AVAILABLE:
            full_text = _read_pdf(file_path)
            text_generator = _yield_string_chunks(full_text)
        elif ext == ".docx" and DOCX_AVAILABLE:
            full_text = _read_docx(file_path)
            text_generator = _yield_string_chunks(full_text)
        elif ext == ".pptx" and PPTX_AVAILABLE:
            full_text = _extract_text_from_pptx(file_path)
            text_generator = _yield_string_chunks(full_text)
        else:
            # File type not supported for deep text scan, return accumulated threats
            return threats 

        # Scan Extracted Chunks
        for chunk in text_generator:
            if not chunk: continue

            # --- 0. Normalization (Security Hardening) ---
            # Normalize Unicode (e.g. Cyrillic 'a' -> Latin 'a') to prevent bypasses
            normalized_chunk = normalize_text(chunk)
            
            # Prepare cleaned version for regex (collapsing whitespace)
            clean_chunk = " ".join(normalized_chunk.split())

            # --- 1. Text Steganography Check ---
            # Check for zero-width characters and whitespace steganography
            stego_threats = detect_stealth_text(normalized_chunk)
            if stego_threats:
                threats.extend(stego_threats)

            # --- 2. Base64 De-obfuscation (NEW) ---
            # Extract potential Base64 strings and check them for malicious payloads
            decoded_parts = extract_base64_content(clean_chunk)
            for decoded in decoded_parts:
                for pattern in signatures:
                    # Check decoded content against signatures
                    if pattern.startswith("regex:"):
                        regex_str = pattern.replace("regex:", "", 1).strip()
                        try:
                            if re.search(regex_str, decoded, re.IGNORECASE):
                                threats.append(f"HIGH: Obfuscated (Base64) Injection detected: '{pattern}'")
                        except re.error:
                            pass
                    else:
                        if pattern.lower() in decoded.lower():
                            threats.append(f"HIGH: Obfuscated (Base64) Injection detected: '{pattern}'")

            # --- 3. Prompt Injection Logic ---
            
            # A. Check for Spaced/Obfuscated keywords (e.g., "j a i l b r e a k")
            if len(clean_chunk) > 50 and (clean_chunk.count(" ") / len(clean_chunk)) > 0.3:
                collapsed_chunk = clean_chunk.replace(" ", "")
                CRITICAL_KEYWORDS = [
                   "asananswer", "alwayswrite", "ignoreprevious", "systemoverride", 
                   "pwned", "jailbreak"
                ]
                for kw in CRITICAL_KEYWORDS:
                    if kw in collapsed_chunk.lower():
                        threats.append(f"HIGH: Obfuscated/Spaced Injection detected in {file_path.name}: '{kw}'")
                        # Return immediately on high confidence threat
                        return threats

            # B. Check Standard Signatures
            for pattern in signatures:
                is_hit = False
                found_text = ""
                
                if pattern.startswith("regex:"):
                    regex_str = pattern.replace("regex:", "", 1).strip()
                    try:
                        match = re.search(regex_str, clean_chunk, re.IGNORECASE)
                        if match:
                            is_hit = True
                            found_text = match.group(0)[:100]
                    except re.error:
                        logger.warning(f"Invalid regex in signatures: {regex_str}")
                else:
                    if pattern.lower() in clean_chunk.lower():
                        is_hit = True
                        found_text = pattern 
                
                if is_hit:
                    threats.append(f"HIGH: Prompt Injection detected in {file_path.name}: Found '{found_text}'")
                    return threats 

            # --- 4. PII Scan ---
            # Use normalized chunk for better NLP recognition
            pii_threats = PIIScanner.scan(normalized_chunk)
            if pii_threats:
                threats.extend(pii_threats)
                return threats

    except Exception as e:
        logger.warning(f"Failed to scan document {file_path}: {e}")
        threats.append(f"WARNING: Doc Scan Error: {str(e)}")
        
    return threats

# --- Helpers ---

def _scan_raw_binary(path: Path) -> List[str]:
    """
    Scans the raw bytes of a file for CSS/HTML hiding techniques.
    """
    threats = []
    try:
        with open(path, "rb") as f:
            buffer = ""
            while True:
                chunk_bytes = f.read(CHUNK_SIZE)
                if not chunk_bytes:
                    break
                
                # Decode as Latin-1 to preserve all byte values
                chunk_str = chunk_bytes.decode("latin-1")
                data = buffer + chunk_str
                
                # Check Stealth Patterns
                for pattern in STEALTH_PATTERNS:
                    match = re.search(pattern, data, re.IGNORECASE)
                    if match:
                        found_text = match.group(0)
                        if len(found_text) > 50: found_text = found_text[:47] + "..."
                        
                        threats.append(f"MEDIUM: Stealth/Hiding technique detected in {path.name} (Raw): '{found_text}'")
                        return threats 
                
                buffer = chunk_str[-OVERLAP_SIZE:]
    except Exception:
        pass 
    return threats

def _read_text_sliding(path: Path) -> Generator[str, None, None]:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        buffer = ""
        while True:
            chunk = f.read(CHUNK_SIZE)
            if not chunk:
                break
            data = buffer + chunk
            yield data
            buffer = chunk[-OVERLAP_SIZE:]

def _yield_string_chunks(text: str) -> Generator[str, None, None]:
    if not text: return
    yield text

def _read_pdf(path: Path) -> str:
    text_content = []
    try:
        reader = pypdf.PdfReader(path)
        max_pages = min(len(reader.pages), 50) 
        for i in range(max_pages):
            page_text = reader.pages[i].extract_text()
            if page_text:
                text_content.append(page_text)
        return "\n".join(text_content)
    except Exception as e:
        logger.debug(f"PDF parsing error: {e}")
        return ""

def _read_docx(path: Path) -> str:
    text_content = []
    try:
        doc = docx.Document(path)
        max_paras = min(len(doc.paragraphs), 2000)
        for i in range(max_paras):
            text_content.append(doc.paragraphs[i].text)
        return "\n".join(text_content)
    except Exception as e:
        logger.debug(f"DOCX parsing error: {e}")
        return ""

def _extract_text_from_pptx(path: Path) -> str:
    if not PPTX_AVAILABLE:
        return ""
    text_runs = []
    try:
        prs = Presentation(path)
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text"):
                    text_runs.append(shape.text)
    except Exception as e:
        logger.warning(f"Failed to parse PPTX {path.name}: {e}")
    return "\n".join(text_runs)
