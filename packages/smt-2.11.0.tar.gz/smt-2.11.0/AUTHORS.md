# Authors

SMT is developed by:

* Mohamed Amine Bouhlel
* John Hwang
* Nathalie Bartoli
* Rémi Lafage
* Joseph Morlier
* Joaquim Martins

SMT has been developed thanks to contributions from:

* Alexandre Thouvenot
* Andres Lopez Lopera
* Antoine Averland
* Emile Roux
* Enrico Stragiotti
* Ewout ter Hoeven
* Florent Vergnes
* Frederick Zahle
* Heine Røstum
* Hugo Reimeringer
* Hugo Valayer
* Jasper Bussemaker
* Julien Schueller
* Laurent Wilkens
* Lisa Pretsch
* Lucas Alber
* Maël Tremouille
* Mauricio Castano Aguirre
* Maxime Lalande
* Mostafa Meliani
* Neal Kesterton
* Nick Thompson
* Nicolas Gonel
* Nina Moëllo
* Paul Saves
* Raul Carreira Rufato
* Reino Ruusu
* Rémi Vauclin
* Rémy Charayron
* Rémy Priem
* Robert Wenink
* Ruben Conde
* Steven Berguin
* Sylvain Dubreuil
* Vincent Drouet
* Yingqian Liao
* Zhou Tianxun
