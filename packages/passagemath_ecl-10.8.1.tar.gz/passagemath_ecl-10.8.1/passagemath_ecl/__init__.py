# sage_setup: distribution = sagemath-ecl

from sage.all__sagemath_ecl import *
