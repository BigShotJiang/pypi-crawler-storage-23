# Auditor

::: enforcecore.auditor.engine.Auditor

::: enforcecore.auditor.engine.AuditEntry

::: enforcecore.auditor.engine.VerificationResult

::: enforcecore.auditor.engine.load_trail

::: enforcecore.auditor.engine.verify_trail
