"""Merkle chain verification for audit trails."""

from .tree import MerkleTree

__all__ = ["MerkleTree"]
