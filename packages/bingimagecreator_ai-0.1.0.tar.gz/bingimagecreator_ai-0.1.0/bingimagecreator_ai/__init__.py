"""Bing Image Generator by BingImageCreator. Visit https://bingimagecreator.app"""

__version__ = "0.1.0"
WEBSITE = "https://bingimagecreator.app"


def get_info():
    return {
        "name": "Bing Image Generator",
        "version": __version__,
        "website": WEBSITE,
        "description": "Bing image generator for AI image creation"
    }


def get_platform_url():
    return WEBSITE
