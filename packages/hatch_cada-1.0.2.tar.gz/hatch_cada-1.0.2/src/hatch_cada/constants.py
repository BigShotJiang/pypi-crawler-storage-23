UV_LOCKFILE_NAME = "uv.lock"
PYPROJECT_NAME = "pyproject.toml"
