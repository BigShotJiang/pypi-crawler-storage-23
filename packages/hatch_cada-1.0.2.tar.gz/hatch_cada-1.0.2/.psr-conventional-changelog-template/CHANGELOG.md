# Changelog

<!-- version list -->

## [v0.1.0](https://github.com/bilelomrani1/psr-conventional-changelog-template/releases/tag/v0.1.0) (2025-12-31)
### Features

- First release by [@bilelomrani1](https://github.com/bilelomrani1) ([0cb77c5](https://github.com/bilelomrani1/psr-conventional-changelog-template/commit/0cb77c5af56d1234263220cca8061fe20b378778))
