"""Changelog templates for Python Semantic Release."""

from psr_templates.ext import GitHubUsernameExtension

__all__ = ["GitHubUsernameExtension"]
