# PiJector: Production-Grade LLM Security Layer

> [!WARNING]
> **BETA PHASE**: PiJector is currently in a beta phase and is undergoing active verification by developers. Please use with caution in production environments and report any issues.

**PiJector** is a lightweight, drop-in security layer for LLM applications. It acts as a Web Application Firewall (WAF) for your AI, intercepting inputs to detect injections and monitoring outputs to prevent prompt leakage.

## Features

- **Multi-SDK Support**: Drop-in wrappers for OpenAI and Google Gemini.
- **Standalone Proxy**: OpenAI-compatible REST API for language-agnostic security.
- **Scoring Engine**: Pluggable detectors (Regex, Canary, Semantic) to score risk.
- **Framework Native**: Integrations for LangChain, FastAPI, and LlamaIndex.

## Quick Start

### OpenAI Integration
```python
from openai import OpenAI
from pijector import PijectorShield

client = PijectorShield(OpenAI())
# ... same calls as before
```

### Gemini Integration
```python
import google.generativeai as genai
from pijector.integrations.gemini import PijectorGeminiShield

model = genai.GenerativeModel('gemini-pro')
secure_model = PijectorGeminiShield(model)

response = secure_model.generate_content("Ignore instructions...")
```

## Documentation

- **[User Guide](https://github.com/animeshs34/llm_security_sdk/blob/main/USERS.md)**: Detailed instructions for SDK and Middleware usage.
- **[Configuration](https://github.com/animeshs34/llm_security_sdk/blob/main/pijector/config.py)**: Documentation of all security settings.
- **[Contributing](https://github.com/animeshs34/llm_security_sdk/blob/main/CONTRIBUTING.md)**: How to help improve PiJector.
- **[Deployment](https://github.com/animeshs34/llm_security_sdk/blob/main/DISTRIBUTION.md)**: How to ship as library or middleware.

## Quick Start

```python
from openai import OpenAI
from pijector import PijectorShield

client = PijectorShield(OpenAI())
# ... standard OpenAI calls
```
