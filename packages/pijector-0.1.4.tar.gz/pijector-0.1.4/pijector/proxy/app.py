import os
import json
import httpx
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from ..core.scanner import InjectionScanner
from ..config import PijectorConfig

app = FastAPI(title="PiJector Proxy")

# Security: Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Should be restricted in production via ENV
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

config = PijectorConfig()
scanner = InjectionScanner(config)

# Get target LLM URL from environment
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")

@app.post("/v1/chat/completions")
async def proxy_chat_completions(request: Request):
    body = await request.json()
    
    # 1. Scan input
    messages = body.get("messages", [])
    user_input = " ".join([m.get("content", "") for m in messages if m.get("role") == "user"])
    
    if user_input:
        result = scanner.scan(user_input)
        if result.risk_score > config.block_threshold:
            return Response(
                status_code=403,
                content=json.dumps({"error": "Security violation", "details": result.to_dict()}),
                media_type="application/json"
            )

    # 2. Forward to real LLM
    headers = dict(request.headers)
    # Remove 'host' to avoid issues with target
    headers.pop("host", None)
    
    async with httpx.AsyncClient() as client:
        llm_response = await client.post(
            f"{LLM_BASE_URL}/chat/completions",
            json=body,
            headers=headers
        )

    # 3. Return response (optionally scan output)
    return Response(
        status_code=llm_response.status_code,
        content=llm_response.content,
        headers=dict(llm_response.headers)
    )

@app.get("/health")
async def health():
    return {"status": "ok", "engine": "pijector"}
