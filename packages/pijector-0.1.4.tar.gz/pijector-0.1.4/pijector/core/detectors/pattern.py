import re
from typing import List
from .base import BaseDetector, DetectionResult

class PatternDetector(BaseDetector):
    def __init__(self, weight: float = 0.3):
        self._weight = weight
        # Production-grade prompt injection patterns
        self.patterns = [
            # Instruction Override
            re.compile(r"ignore (all )?previous instructions", re.IGNORECASE),
            re.compile(r"disregard (the )?(above|previous) instructions", re.IGNORECASE),
            re.compile(r"system prompt", re.IGNORECASE),
            re.compile(r"reveal (your )?secrets?", re.IGNORECASE),
            
            # Persona Switching
            re.compile(r"you are now (a|an|the) ", re.IGNORECASE),
            re.compile(r"act as (a|an|the) ", re.IGNORECASE),
            re.compile(r"new task is", re.IGNORECASE),
            
            # Jailbreak Signatures
            re.compile(r"DAN mode", re.IGNORECASE),
            re.compile(r"jailbreak", re.IGNORECASE),
            re.compile(r"do anything now", re.IGNORECASE),
            re.compile(r"stay in character", re.IGNORECASE),
            
            # Markup/Parsing Injections
            re.compile(r"<\|im_start\|>", re.IGNORECASE),
            re.compile(r"\[INST\]", re.IGNORECASE),
            re.compile(r"### Assistant:", re.IGNORECASE),
            re.compile(r"\{.*\"role\":.*\"system\".*\}", re.IGNORECASE), # JSON injection
            
            # Indirect Injections / Encoding
            re.compile(r"base64", re.IGNORECASE),
            re.compile(r"ROT13", re.IGNORECASE),
            re.compile(r"unicode", re.IGNORECASE),
        ]

    @property
    def name(self) -> str:
        return "pattern_detector"

    @property
    def weight(self) -> float:
        return self._weight

    def detect(self, text: str) -> DetectionResult:
        findings = []
        max_score = 0.0
        
        for pattern in self.patterns:
            if pattern.search(text):
                findings.append(f"Matched pattern: {pattern.pattern}")
                max_score = max(max_score, 1.0) # Full trigger if any pattern matches

        return DetectionResult(
            triggered=len(findings) > 0,
            score=max_score,
            finding=", ".join(findings) if findings else None
        )
