from dataclasses import dataclass, field
from typing import List, Optional
from abc import ABC, abstractmethod

@dataclass
class DetectionResult:
    triggered: bool
    score: float  # 0.0 to 1.0
    finding: Optional[str] = None
    metadata: dict = field(default_factory=dict)

class BaseDetector(ABC):
    @property
    @abstractmethod
    def name(self) -> str:
        """The identifier for this detector."""
        pass

    @property
    @abstractmethod
    def weight(self) -> float:
        """The weight of this detector in the final score (0.0 to 1.0)."""
        pass

    @abstractmethod
    def detect(self, text: str) -> DetectionResult:
        """Scan the text and return a DetectionResult."""
        pass
