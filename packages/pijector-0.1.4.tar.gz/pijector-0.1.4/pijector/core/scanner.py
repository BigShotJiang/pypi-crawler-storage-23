from typing import List, Dict, Any
from dataclasses import dataclass
from .detectors.base import BaseDetector, DetectionResult
from ..config import PijectorConfig

@dataclass
class ScanResult:
    risk_score: float
    findings: List[str]
    severity: str
    recommendation: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "risk_score": self.risk_score,
            "findings": self.findings,
            "severity": self.severity,
            "recommendation": self.recommendation
        }

class InjectionScanner:
    def __init__(self, config: PijectorConfig = None, detectors: List[BaseDetector] = None):
        self.config = config or PijectorConfig()
        self.detectors = detectors or []
        
        # Initialize default detectors if none provided
        if not self.detectors:
            from .detectors.pattern import PatternDetector
            from .detectors.canary import CanaryDetector
            from .detectors.semantic import SemanticDetector
            
            self.detectors.append(PatternDetector(weight=0.3))
            self.detectors.append(CanaryDetector(weight=0.1))
            self.detectors.append(SemanticDetector(
                weight=0.4, 
                model_name=self.config.embedding_model_name,
                threshold=self.config.semantic_threshold
            ))
        
        # Load custom detectors from config
        for detector_cls in self.config.custom_detectors:
            self.detectors.append(detector_cls())

    def add_detector(self, detector: BaseDetector):
        self.detectors.append(detector)

    def scan(self, text: str) -> ScanResult:
        if not text:
            return ScanResult(0.0, [], "LOW", "ALLOW")
            
        scores = []
        findings = []
        
        # Calculate total weight for normalization
        total_weight = sum(d.weight for d in self.detectors)
        if total_weight == 0:
            return ScanResult(0.0, [], "LOW", "ALLOW")

        for detector in self.detectors:
            try:
                result = detector.detect(text)
                # Normalize contribution based on weight
                weighted_contribution = result.score * (detector.weight / total_weight)
                scores.append(weighted_contribution)
                
                if result.triggered and result.finding:
                    findings.append(f"[{detector.name}] {result.finding}")
            except Exception as e:
                # Log error but don't fail the whole scan
                findings.append(f"[{detector.name}] Error: {str(e)}")

        final_score = sum(scores)
        severity = self._score_to_severity(final_score)
        recommendation = self._get_recommendation(final_score)

        return ScanResult(
            risk_score=round(final_score, 4),
            findings=findings,
            severity=severity,
            recommendation=recommendation
        )

    def _score_to_severity(self, score: float) -> str:
        if score > 0.8: return "CRITICAL"
        if score > 0.5: return "HIGH"
        if score > 0.3: return "MEDIUM"
        return "LOW"

    def _get_recommendation(self, score: float) -> str:
        if score > self.config.block_threshold:
            return "BLOCK"
        if score > self.config.warn_threshold:
            return "FLAG"
        return "ALLOW"
