from typing import List, Optional, Callable, Any
from pydantic import BaseModel, Field, ConfigDict

class PijectorConfig(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    # Thresholds
    block_threshold: float = 0.85
    warn_threshold: float = 0.5

    # Scanning toggles
    scan_input: bool = True
    scan_output: bool = True

    # Categories/Detectors to enable
    enabled_categories: List[str] = Field(
        default_factory=lambda: ["instruction_override", "jailbreak", "indirect", "encoding"]
    )

    # Actions
    on_detect: str = "block"  # "block", "warn", "log", "sanitize"
    
    # Event Handlers (Callbacks)
    on_injection: Optional[Callable[[Any], None]] = None
    on_leak: Optional[Callable[[Any], None]] = None

    log_level: str = "HIGH_ONLY"  # "ALL", "HIGH_ONLY", "NONE"
    
    # Trusted users skip scanning
    allowlist: List[str] = Field(default_factory=list)

    # Custom detector classes
    custom_detectors: List[Any] = Field(default_factory=list)

    # Embedding settings for SemanticDetector
    embedding_model_name: str = "all-MiniLM-L6-v2"
    semantic_threshold: float = 0.8

    def register_detector(self, detector_class: Any):
        self.custom_detectors.append(detector_class)
