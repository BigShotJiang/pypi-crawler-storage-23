import sys
import argparse
from pijector.core.scanner import InjectionScanner
from pijector.core.detectors.pattern import PatternDetector
from pijector.config import PijectorConfig

def main():
    parser = argparse.ArgumentParser(description="PiJector CLI - Scan text for LLM injections.")
    parser.add_argument("text", help="Text to scan (or file path if --file is set)")
    parser.add_argument("--file", action="store_true", help="Treat input as a file path")
    parser.add_argument("--threshold", type=float, default=0.85, help="Block threshold (0.0 to 1.0)")
    
    args = parser.parse_args()
    
    config = PijectorConfig(block_threshold=args.threshold)
    scanner = InjectionScanner(config)
    scanner.add_detector(PatternDetector())
    
    text_to_scan = args.text
    if args.file:
        with open(args.text, "r") as f:
            text_to_scan = f.read()
            
    result = scanner.scan(text_to_scan)
    
    print(f"Risk Score: {result.risk_score}")
    print(f"Severity: {result.severity}")
    if result.findings:
        print("Findings:")
        for finding in result.findings:
            print(f"  - {finding}")
            
    if result.risk_score > config.block_threshold:
        print("\nRESULT: BLOCK")
        sys.exit(1)
    else:
        print("\nRESULT: ALLOW")
        sys.exit(0)

if __name__ == "__main__":
    main()
