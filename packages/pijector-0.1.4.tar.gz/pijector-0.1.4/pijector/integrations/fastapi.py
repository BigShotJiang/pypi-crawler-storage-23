import json
from typing import Optional, Callable
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from ..core.scanner import InjectionScanner
from ..config import PijectorConfig

class PijectorMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, config: Optional[PijectorConfig] = None):
        super().__init__(app)
        self.config = config or PijectorConfig()
        self.scanner = InjectionScanner(self.config)

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        if request.method == "POST":
            # Only scan if actually calling an AI-related endpoint (naive check)
            # A real version would allow specifying paths
            try:
                # Read body without consuming it permanently (using a trick or copy)
                body = await request.body()
                if body:
                    # Very naive check for messages or prompt in JSON
                    try:
                        data = json.loads(body)
                        # Scan common AI API fields
                        text_to_scan = ""
                        if "messages" in data:
                            text_to_scan = " ".join([m.get("content", "") for m in data["messages"] if m.get("role") == "user"])
                        elif "prompt" in data:
                            text_to_scan = str(data["prompt"])

                        if text_to_scan:
                            result = self.scanner.scan(text_to_scan)
                            if result.risk_score > self.config.block_threshold:
                                return Response(
                                    status_code=403,
                                    content=json.dumps({
                                        "error": "Security violation",
                                        "details": result.to_dict()
                                    })
                                )
                    except json.JSONDecodeError:
                        pass # nosec B110
            except Exception: # pylint: disable=broad-except
                # Safety catch to ensure middleware doesn't break the main app flow
                pass # nosec B110

        # Proceed to the endpoint
        response = await call_next(request)
        return response
