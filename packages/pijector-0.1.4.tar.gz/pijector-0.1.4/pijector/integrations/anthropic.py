from typing import Any, Optional, Union, List, Dict
from ..core.scanner import InjectionScanner
from ..config import PijectorConfig

class InjectionDetected(Exception):
    def __init__(self, result):
        self.result = result
        super().__init__(f"PiJector: Potential injection detected: {result.findings}")

class PijectorAnthropicShield:
    """
    A drop-in wrapper for Anthropic's Claude client.
    """
    def __init__(self, client: Any, config: Optional[PijectorConfig] = None):
        self._client = client
        self._config = config or PijectorConfig()
        self._scanner = InjectionScanner(self._config)

    def __getattr__(self, name):
        attr = getattr(self._client, name)
        # Proxy 'messages' or other attributes
        if not callable(attr) and hasattr(attr, '__dict__') or name in ["messages"]:
            return PijectorAnthropicShield(attr, self._config)
        
        if name == "create" and callable(attr):
            return self._wrap_create(attr)
            
        return attr

    def _wrap_create(self, original_create):
        def wrapper(*args, **kwargs):
            # 1. Scan Input
            if self._config.scan_input:
                messages = kwargs.get("messages", [])
                user_input = " ".join([m.get("content", "") if isinstance(m.get("content"), str) else "" for m in messages if m.get("role") == "user"])
                
                if user_input:
                    result = self._scanner.scan(user_input)
                    if result.risk_score > self._config.block_threshold:
                        if self._config.on_injection:
                            self._config.on_injection(result)
                        raise InjectionDetected(result)

            # 2. Call real Anthropic API
            response = original_create(*args, **kwargs)

            # 3. Scan Output
            if self._config.scan_output:
                output_text = ""
                if hasattr(response, 'content') and response.content:
                    # Anthropic returns a list of content blocks
                    output_text = " ".join([block.text for block in response.content if hasattr(block, 'text')])
                
                if output_text:
                    output_result = self._scanner.scan(output_text)
                    if output_result.risk_score > self._config.block_threshold:
                        if self._config.on_leak:
                            self._config.on_leak(output_result)
                        print(f"PIJECTOR ALERT: Anthropic output security risk: {output_result.findings}")
            
            return response
        return wrapper
