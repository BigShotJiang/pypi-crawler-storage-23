from typing import Any, Optional, Union, List, Dict
from ..core.scanner import InjectionScanner
from ..config import PijectorConfig

class InjectionDetected(Exception):
    def __init__(self, result):
        self.result = result
        super().__init__(f"PiJector: Potential injection detected: {result.findings}")

class PijectorGeminiShield:
    """
    A drop-in wrapper for Google Gemini's GenerativeModel.
    """
    def __init__(self, model: Any, config: Optional[PijectorConfig] = None):
        self._model = model
        self.config = config or PijectorConfig()
        self.scanner = InjectionScanner(self.config)

    def __getattr__(self, name):
        """Proxy attributes to the original model."""
        return getattr(self._model, name)

    def generate_content(self, contents: Union[str, List[Any], Dict[str, Any]], **kwargs):
        """
        Intercept and scan content generation.
        """
        # 1. Extract and scan input messages
        if self.config.scan_input:
            text_to_scan = self._extract_text(contents)
            if text_to_scan:
                result = self.scanner.scan(text_to_scan)
                if result.risk_score > self.config.block_threshold:
                    if self.config.on_injection:
                        self.config.on_injection(result)
                    raise InjectionDetected(result)

        # 2. Call real Gemini model
        response = self._model.generate_content(contents, **kwargs)

        # 3. Scan output
        if self.config.scan_output and hasattr(response, 'text'):
            try:
                output_text = response.text
                output_result = self.scanner.scan(output_text)
                if output_result.risk_score > self.config.block_threshold:
                    if self.config.on_leak:
                        self.config.on_leak(output_result)
                    # We log output risks as the model has already generated them.
                    # Blocking here would require failing the entire call after generation.
                    print(f"PIJECTOR ALERT: Gemini output security risk: {output_result.findings}")
            except Exception: # pylint: disable=broad-except
                # General safety catch to prevent middleware from crashing the app
                pass # nosec B110

        return response

    async def generate_content_async(self, contents: Any, **kwargs):
        """
        Intercept and scan content generation (Async version).
        """
        if self.config.scan_input:
            text_to_scan = self._extract_text(contents)
            if text_to_scan:
                result = self.scanner.scan(text_to_scan)
                if result.risk_score > self.config.block_threshold:
                    raise InjectionDetected(result)

        response = await self._model.generate_content_async(contents, **kwargs)

        if self.config.scan_output and hasattr(response, 'text'):
            output_text = response.text
            output_result = self.scanner.scan(output_text)
            if output_result.risk_score > self.config.block_threshold:
                if self.config.on_leak:
                    self.config.on_leak(output_result)
                print(f"PIJECTOR ALERT: Gemini output security risk: {output_result.findings}")

        return response

    def _extract_text(self, contents: Any) -> str:
        """Extract plain text from various Gemini content formats."""
        if isinstance(contents, str):
            return contents
        if isinstance(contents, list):
            texts = []
            for item in contents:
                if isinstance(item, str):
                    texts.append(item)
                elif hasattr(item, 'parts'): # Content object
                    for part in item.parts:
                        if hasattr(part, 'text'):
                            texts.append(part.text)
            return " ".join(texts)
        if isinstance(contents, dict):
            # Simple dict format
            parts = contents.get("parts", [])
            return " ".join([p.get("text", "") for p in parts if "text" in p])
        return ""
