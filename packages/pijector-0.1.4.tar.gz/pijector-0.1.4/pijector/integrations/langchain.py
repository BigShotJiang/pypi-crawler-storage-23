from typing import Any, Dict, List, Optional
from langchain.callbacks.base import BaseCallbackHandler
from langchain.schema import LLMResult
from ..core.scanner import InjectionScanner
from ..config import PijectorConfig

class PijectorCallbackHandler(BaseCallbackHandler):
    """
    A LangChain-native callback handler for PiJector.
    """
    def __init__(self, config: Optional[PijectorConfig] = None):
        self.config = config or PijectorConfig()
        self.scanner = InjectionScanner(self.config)

    def on_llm_start(
        self, serialized: Dict[str, Any], prompts: List[str], **kwargs: Any
    ) -> Any:
        """Scan inputs before they are sent to the LLM."""
        if self.config.scan_input:
            for prompt in prompts:
                result = self.scanner.scan(prompt)
                if result.risk_score > self.config.block_threshold:
                    # In LangChain callbacks, we can raise an exception to stop execution
                    raise ValueError(f"PiJector blocked malicious input: {result.findings}")

    def on_llm_end(self, response: LLMResult, **kwargs: Any) -> Any:
        """Scan LLM output for leaks or jailbreaks."""
        if self.config.scan_output:
            for generation_list in response.generations:
                for generation in generation_list:
                    output_text = generation.text
                    result = self.scanner.scan(output_text)
                    if result.risk_score > self.config.block_threshold:
                        # Log or flag output (harder to stop 'end' but can prevent display)
                        print(f"PIJECTOR ALERT: Output risk detected: {result.findings}")
