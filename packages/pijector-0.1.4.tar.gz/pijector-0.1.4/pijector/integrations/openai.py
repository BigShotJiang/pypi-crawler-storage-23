from typing import Any, Optional, Dict, List
from ..core.scanner import InjectionScanner
from ..config import PijectorConfig

class InjectionDetected(Exception):
    def __init__(self, result):
        self.result = result
        super().__init__(f"PiJector: Potential injection detected: {result.findings}")

class PijectorShield:
    """
    A robust drop-in wrapper for OpenAI clients.
    Uses recursive proxying to intercept deep calls like client.chat.completions.create.
    """
    def __init__(self, client: Any, config: Optional[PijectorConfig] = None):
        self._client = client
        self._config = config or PijectorConfig()
        self._scanner = InjectionScanner(self._config)

    def __getattr__(self, name):
        attr = getattr(self._client, name)
        # If the attribute is another object (like 'chat'), wrap it too
        if not callable(attr) and hasattr(attr, '__dict__') or name in ["chat", "completions"]:
            return PijectorShield(attr, self._config)
        
        # If it's the 'create' method we want to intercept
        if name == "create" and callable(attr):
            return self._wrap_create(attr)
            
        return attr

    def _wrap_create(self, original_create):
        def wrapper(*args, **kwargs):
            # 1. Scan Input
            if self._config.scan_input:
                messages = kwargs.get("messages", [])
                user_input = " ".join([m.get("content", "") for m in messages if m.get("role") == "user"])
                
                if user_input:
                    result = self._scanner.scan(user_input)
                    if result.risk_score > self._config.block_threshold:
                        if self._config.on_injection:
                            self._config.on_injection(result)
                        raise InjectionDetected(result)

            # 2. Call real LLM
            response = original_create(*args, **kwargs)

            # 3. Scan Output
            if self._config.scan_output:
                output_text = ""
                # Handle both chat completions and regular completions
                if hasattr(response, 'choices') and response.choices:
                    choice = response.choices[0]
                    if hasattr(choice, 'message'):
                        output_text = choice.message.content
                    elif hasattr(choice, 'text'):
                        output_text = choice.text
                
                if output_text:
                    output_result = self._scanner.scan(output_text)
                    if output_result.risk_score > self._config.block_threshold:
                        if self._config.on_leak:
                            self._config.on_leak(output_result)
                        # Specific handling for output risk can be added here
            
            return response
        return wrapper
