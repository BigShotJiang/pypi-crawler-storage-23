from typing import Any, Dict, List, Optional
from llama_index.core.callbacks.base_handler import BaseCallbackHandler
from llama_index.core.callbacks.schema import CBEventType, EventPayload
from ..core.scanner import InjectionScanner
from ..config import PijectorConfig

class PijectorLlamaIndexHandler(BaseCallbackHandler):
    """
    A LlamaIndex-native callback handler for PiJector.
    """
    def __init__(
        self, 
        config: Optional[PijectorConfig] = None,
        event_starts_to_ignore: List[CBEventType] = None,
        event_ends_to_ignore: List[CBEventType] = None,
    ):
        super().__init__(
            event_starts_to_ignore=event_starts_to_ignore or [],
            event_ends_to_ignore=event_ends_to_ignore or [],
        )
        self.config = config or PijectorConfig()
        self.scanner = InjectionScanner(self.config)

    def on_event_start(
        self,
        event_type: CBEventType,
        payload: Optional[Dict[str, Any]] = None,
        event_id: str = "",
        parent_id: str = "",
        **kwargs: Any,
    ) -> str:
        """Scan inputs on LLM start events."""
        if event_type == CBEventType.LLM and self.config.scan_input:
            if payload and EventPayload.MESSAGES in payload:
                messages = payload[EventPayload.MESSAGES]
                # Join all user message content for scanning
                text_to_scan = " ".join([m.content for m in messages if getattr(m, 'role', '') == 'user'])
                if text_to_scan:
                    result = self.scanner.scan(text_to_scan)
                    if result.risk_score > self.config.block_threshold:
                        raise ValueError(f"PiJector: Security violation detected. Risk: {result.findings}")
        return event_id

    def on_event_end(
        self,
        event_type: CBEventType,
        payload: Optional[Dict[str, Any]] = None,
        event_id: str = "",
        **kwargs: Any,
    ) -> None:
        """Scan outputs on LLM end events."""
        if event_type == CBEventType.LLM and self.config.scan_output:
            if payload and EventPayload.RESPONSE in payload:
                response = payload[EventPayload.RESPONSE]
                # Handle different response types (Streaming vs Static)
                output_text = str(response)
                if output_text:
                    result = self.scanner.scan(output_text)
                    if result.risk_score > self.config.block_threshold:
                        # For LlamaIndex, we log the violation as event_end occurs after generation
                        print(f"PIJECTOR ALERT: Output security risk: {result.findings}")

    def start_trace(self, trace_id: Optional[str] = None) -> None:
        pass

    def end_trace(
        self,
        trace_id: Optional[str] = None,
        trace_map: Optional[Dict[str, List[str]]] = None,
    ) -> None:
        pass
