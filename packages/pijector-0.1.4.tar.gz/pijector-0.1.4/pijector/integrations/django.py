import json
from django.http import JsonResponse
from ..core.scanner import InjectionScanner
from ..config import PijectorConfig

class PijectorMiddleware:
    """
    Django middleware to scan incoming requests for LLM injection attacks.
    """
    def __init__(self, get_response):
        self.get_response = get_response
        self.config = PijectorConfig()
        self.scanner = InjectionScanner(self.config)

    def __call__(self, request):
        if request.method == "POST" and self.config.scan_input:
            # Check if content type is JSON
            if request.content_type == "application/json":
                try:
                    # Django's request.body can be read multiple times if using a specific setting,
                    # but typically we should be careful.
                    data = json.loads(request.body)
                    
                    # Look for common AI payload fields
                    text_to_scan = ""
                    if "messages" in data:
                        text_to_scan = " ".join([m.get("content", "") for m in data["messages"] if m.get("role") == "user"])
                    elif "prompt" in data:
                        text_to_scan = str(data["prompt"])

                    if text_to_scan:
                        result = self.scanner.scan(text_to_scan)
                        if result.risk_score > self.config.block_threshold:
                            if self.config.on_injection:
                                self.config.on_injection(result)
                            return JsonResponse({
                                "error": "Security violation",
                                "details": result.to_dict()
                            }, status=403)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    # Ignore malformed JSON or non-unicode bodies
                    pass # nosec B110

        response = self.get_response(request)
        return response
