"""
Aliyun Kafka Management Tool
"""
__version__ = "0.1.0"
