"""
Authentication module for Aliyun Kafka Management Tool
Handles interactive credential input and environment variable support
"""
import os
from dataclasses import dataclass
from typing import Optional
from rich.console import Console
from rich.prompt import Prompt

console = Console()


@dataclass
class AliyunCredentials:
    """Aliyun API credentials"""
    access_key_id: str
    access_key_secret: str
    security_token: Optional[str] = None  # For STS temporary credentials
    region_id: str = "cn-shanghai"


class AuthManager:
    """Manages Aliyun authentication with interactive and environment variable support"""

    def __init__(self):
        self.credentials: Optional[AliyunCredentials] = None

    def get_credentials(self, force_prompt: bool = False) -> AliyunCredentials:
        """
        Get Aliyun credentials with priority:
        1. Environment variables (if available and not forcing prompt)
        2. Interactive prompt

        Args:
            force_prompt: Force interactive prompt even if env vars are set

        Returns:
            AliyunCredentials object
        """
        if self.credentials and not force_prompt:
            return self.credentials

        # Try environment variables first
        if not force_prompt:
            creds = self._load_from_env()
            if creds:
                self.credentials = creds
                return creds

        # Fall back to interactive prompt
        self.credentials = self._prompt_credentials()
        return self.credentials

    def _load_from_env(self) -> Optional[AliyunCredentials]:
        """Load credentials from environment variables"""
        access_key_id = os.getenv("ALIKAFKA_ACCESS_KEY_ID")
        access_key_secret = os.getenv("ALIKAFKA_ACCESS_KEY_SECRET")
        security_token = os.getenv("ALIKAFKA_SECURITY_TOKEN")
        region_id = os.getenv("ALIKAFKA_REGION", "cn-shanghai")

        if not access_key_id or not access_key_secret:
            return None

        return AliyunCredentials(
            access_key_id=access_key_id,
            access_key_secret=access_key_secret,
            security_token=security_token,
            region_id=region_id
        )

    def _prompt_credentials(self) -> AliyunCredentials:
        """
        Interactively prompt user for credentials

        Returns:
            AliyunCredentials object with user-provided values
        """
        console.print("\n[bold cyan]Aliyun Credentials Required[/bold cyan]")
        console.print("[dim]" + "-" * 40 + "[/dim]\n")

        # Collect all environment variables first
        key_id_env = os.getenv("ALIKAFKA_ACCESS_KEY_ID")
        secret_env = os.getenv("ALIKAFKA_ACCESS_KEY_SECRET")
        token_env = os.getenv("ALIKAFKA_SECURITY_TOKEN")
        region_env = os.getenv("ALIKAFKA_REGION")

        # Display all environment variables being used
        if any([key_id_env, secret_env, token_env, region_env]):
            console.print("\n[bold yellow]Credentials from environment:[/bold yellow]")

        if key_id_env:
            preview = key_id_env[:30] + "..." if len(key_id_env) > 30 else key_id_env
            console.print(f"  ALIKAFKA_ACCESS_KEY_ID: [red]{preview}[/red]")
        if secret_env:
            preview = secret_env[:10] + "..." if len(secret_env) > 10 else secret_env
            console.print(f"  ALIKAFKA_ACCESS_KEY_SECRET: [dim]{preview}[/dim]")
        if token_env:
            preview = token_env[:30] + "..." if len(token_env) > 30 else token_env
            console.print(f"  ALIKAFKA_SECURITY_TOKEN: [red]{preview}[/red]")
        if region_env:
            console.print(f"  ALIKAFKA_REGION: [cyan]{region_env}[/cyan]")

        console.print("")  # empty line

        # Access Key ID
        if key_id_env:
            access_key_id = key_id_env
        else:
            access_key_id = Prompt.ask("[yellow]Access Key ID[/yellow]", default="")

        # Access Key Secret
        if secret_env:
            access_key_secret = secret_env
        else:
            # Only prompt if not in env (use Prompt with password=True to hide input)
            access_key_secret = Prompt.ask("[yellow]Access Key Secret[/yellow]", password=True)

        # Security Token (optional)
        if token_env:
            security_token = token_env
        else:
            # Only prompt if not in env
            security_token = Prompt.ask(
                "[yellow]Security Token[/yellow] [dim](optional, press Enter to skip)[/dim]",
                default=""
            ) or None

        # Region ID
        if region_env:
            region_id = region_env
        else:
            region_id = Prompt.ask(
                "[yellow]Region ID[/yellow]",
                default="cn-shanghai"
            )

        return AliyunCredentials(
            access_key_id=access_key_id,
            access_key_secret=access_key_secret,
            security_token=security_token,
            region_id=region_id
        )

    def validate_credentials(self, credentials: Optional[AliyunCredentials] = None) -> bool:
        """
        Validate credentials by checking if required fields are present

        Note: This does NOT make an API call to avoid permission issues.
        Credentials will be validated when you perform actual operations.

        Args:
            credentials: Credentials to validate (uses cached if None)

        Returns:
            True if credentials have required fields, False otherwise
        """
        if not credentials:
            credentials = self.get_credentials()

        # Basic validation: check if required fields are present
        if not credentials.access_key_id or not credentials.access_key_secret:
            console.print("[red]✗[/red] [dim]Missing Access Key ID or Secret[/dim]\n")
            return False

        console.print("[green]✓[/green] [dim]Credentials configured (will be validated on first use)[/dim]\n")
        return True

    def clear_credentials(self):
        """Clear cached credentials"""
        self.credentials = None


# Convenience function for quick access
def get_credentials(force_prompt: bool = False) -> AliyunCredentials:
    """
    Convenience function to get credentials

    Args:
        force_prompt: Force interactive prompt

    Returns:
        AliyunCredentials object
    """
    manager = AuthManager()
    return manager.get_credentials(force_prompt=force_prompt)
