#!/usr/bin/env python3
"""
Aliyun Kafka Management Tool - CLI Entry Point
"""
import click
from pathlib import Path
from rich.console import Console
from rich import print as rprint

from .auth import AuthManager, AliyunCredentials
from .client import AliKafkaClient
from .config import ConfigManager
from .sync import SyncManager
from .git_helper import GitHelper

# Try to get version from package metadata, fallback to hardcoded version
try:
    from importlib.metadata import version, PackageNotFoundError
    __version__ = version("alikafka-management-tool")
except PackageNotFoundError:
    __version__ = "0.2.3"

console = Console()


@click.group()
@click.version_option(version=__version__)
@click.option("--config-path", "-c", type=click.Path(exists=True),
              help="Path to config directory (default: ./config)")
@click.pass_context
def cli(ctx, config_path):
    """Aliyun Kafka Management Tool

    Manage Aliyun Kafka resources using YAML configuration files.

    \b
    OPTION ORDER:
        Global options (like --config-path) must come BEFORE the command.

    \b
    Examples:
        alikafka -c /path/to/config list-instances --local
        alikafka --config-path /path/to/config apply -i instance-123

    \b
    Common commands:
        init        Initialize configuration from existing Kafka instance
        apply       Apply YAML configuration to Kafka
        diff        Show differences between YAML and Kafka state
        list-instances  List Kafka instances
    """
    ctx.ensure_object(dict)
    ctx.obj['CONFIG_PATH'] = config_path


@cli.command()
@click.option("--instance", "-i", required=True, help="Instance ID to initialize from")
@click.option("--region", "-r", default="cn-shanghai", help="Region ID")
@click.pass_context
def init(ctx, instance, region):
    """Initialize configuration from existing Kafka instance

    Export current state from an existing Kafka instance to YAML files.
    """
    console.print("\n[bold cyan]Initializing configuration from Kafka instance[/bold cyan]\n")

    try:
        # Get credentials
        auth_manager = AuthManager()
        credentials = auth_manager.get_credentials()
        credentials.region_id = region

        # Validate credentials
        if not auth_manager.validate_credentials(credentials):
            console.print("[red]✗[/red] Credential validation failed")
            return

        # Get config path from context
        config_path = ctx.obj.get('CONFIG_PATH')
        config_dir = Path(config_path) if config_path else None

        # Initialize client and config manager
        client = AliKafkaClient(credentials)
        config_manager = ConfigManager(config_dir)

        # Get instance detail to retrieve instance name
        console.print(f"[dim]Fetching instance details for {instance}...[/dim]")
        instance_detail = client.get_instance_detail(instance)
        if instance_detail and instance_detail.name:
            instance_name = instance_detail.name
            # Add mapping to index
            config_manager.add_instance_mapping(instance, instance_name)
            console.print(f"[green]✓[/green] [dim]Instance name: {instance_name}[/dim]")
        else:
            console.print(f"[yellow]Warning:[/yellow] Could not retrieve instance name, using ID as directory name")

        # Export all resources
        sync_manager = SyncManager(client, config_manager)
        result = sync_manager.export_all(instance, force=True)

        if result.success:
            # Get the actual directory name used
            dir_name = config_manager.get_instance_name(instance) or instance
            console.print(f"\n[green]✓[/green] Configuration initialized successfully!")
            console.print(f"[dim]Config files created in: config/instances/{dir_name}/[/dim]")
        else:
            console.print(f"\n[red]✗[/red] Initialization failed with errors")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise click.ClickException(str(e))


@cli.command()
@click.option("--instance", "-i", "instance_id", help="Specific instance ID")
@click.option("--instance-name", "-n", "instance_name", help="Instance name (from index.yaml)")
@click.option("--dry-run", "-d", is_flag=True, help="Show what would change without applying")
@click.option("--topics-only", is_flag=True, help="Only sync topics")
@click.option("--groups-only", is_flag=True, help="Only sync consumer groups")
@click.option("--users-only", is_flag=True, help="Only sync SASL users")
@click.option("--auto-password", "--generate-password", "auto_password", is_flag=True, default=True,
              help="Auto-generate passwords for new SASL users (default: enabled)")
@click.option("--no-auto-password", "auto_password", flag_value=False,
              help="Disable auto-password and prompt interactively")
@click.pass_context
def apply(ctx, instance_id, instance_name, dry_run, topics_only, groups_only, users_only, auto_password):
    """Apply configuration from YAML to Kafka

    Apply YAML configuration to Aliyun Kafka. Changes will be created, updated, or deleted
    to match the desired state in YAML files.
    """
    console.print("\n[bold cyan]Applying configuration to Kafka[/bold cyan]\n")

    try:
        # Get config path from context
        config_path = ctx.obj.get('CONFIG_PATH')
        if config_path:
            config_dir = Path(config_path)
        else:
            config_dir = None

        # Get credentials
        auth_manager = AuthManager()
        credentials = auth_manager.get_credentials()

        # Initialize client and config manager
        client = AliKafkaClient(credentials)
        config_manager = ConfigManager(config_dir)

        # Determine which instances to sync
        # Support both --instance (ID) and --instance-name
        if instance_id:
            instances = [instance_id]
        elif instance_name:
            # Resolve instance name to ID
            resolved_id = config_manager.get_instance_id_by_name(instance_name)
            if not resolved_id:
                console.print(f"[red]Error:[/red] Instance '{instance_name}' not found in index.yaml")
                console.print("[dim]Available instances:[/dim]")
                index = config_manager.load_index()
                for inst_id, inst_name in index.get("instances", {}).items():
                    console.print(f"  [dim]{inst_name} (ID: {inst_id})[/dim]")
                return
            instances = [resolved_id]
            console.print(f"[dim]Resolved instance name '{instance_name}' to ID: {resolved_id}[/dim]")
        else:
            instances = config_manager.list_instances()
            if not instances:
                console.print("[yellow]No instances found in config[/yellow]")
                console.print("[dim]Run 'alikafka init' first to export from existing instance[/dim]")
                return

        # Apply to each instance
        for inst_id in instances:
            console.print(f"\n[bold]Processing instance:[/bold] {inst_id}")

            sync_manager = SyncManager(client, config_manager)
            result = sync_manager.apply_all(inst_id, dry_run=dry_run, topics_only=topics_only, groups_only=groups_only, users_only=users_only, auto_password=auto_password)

            if result.success:
                if dry_run:
                    console.print(f"\n[dim]Dry run complete. No changes were applied.[/dim]")
                else:
                    console.print(f"\n[green]✓[/green] Applied configuration to instance '{inst_id}'")
                    stats = f"Created: {result.created}, Updated: {result.updated}, Deleted: {result.deleted}"
                    if hasattr(result, 'acls_created') and (result.acls_created > 0 or result.acls_deleted > 0):
                        stats += f" | ACLs: +{result.acls_created}, -{result.acls_deleted}"
                    console.print(f"  {stats}")
            else:
                console.print(f"\n[red]✗[/red] Failed to apply configuration to instance '{inst_id}'")
                if result.errors:
                    for error in result.errors:
                        console.print(f"  [dim]• {error}[/dim]")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise click.ClickException(str(e))


@cli.command()
@click.option("--instance", "-i", "instance_id", help="Specific instance ID")
@click.option("--instance-name", "-n", "instance_name", help="Instance name (from index.yaml)")
@click.pass_context
def export(ctx, instance_id, instance_name):
    """Export current Kafka state to YAML

    Export current resources from Aliyun Kafka to YAML configuration files.
    """
    console.print("\n[bold cyan]Exporting configuration from Kafka[/bold cyan]\n")

    try:
        # Get credentials
        auth_manager = AuthManager()
        credentials = auth_manager.get_credentials()

        # Get config path from context
        config_path = ctx.obj.get('CONFIG_PATH')
        config_dir = Path(config_path) if config_path else None

        # Initialize client and config manager
        client = AliKafkaClient(credentials)
        config_manager = ConfigManager(config_dir)

        # Determine which instances to export
        if instance_id:
            instances = [instance_id]
        elif instance_name:
            # Resolve instance name to ID
            resolved_id = config_manager.get_instance_id_by_name(instance_name)
            if not resolved_id:
                console.print(f"[red]Error:[/red] Instance '{instance_name}' not found in index.yaml")
                console.print("[dim]Available instances:[/dim]")
                index = config_manager.load_index()
                for inst_id, inst_name in index.get("instances", {}).items():
                    console.print(f"  [dim]{inst_name} (ID: {inst_id})[/dim]")
                return
            instances = [resolved_id]
            console.print(f"[dim]Resolved instance name '{instance_name}' to ID: {resolved_id}[/dim]")
        else:
            # Get all instances from the account
            all_instances = client.get_all_instances()
            if not all_instances:
                console.print("[yellow]No instances found in account[/yellow]")
                return
            instances = [inst.instance_id for inst in all_instances]

        # Export each instance
        for inst_id in instances:
            console.print(f"\n[bold]Exporting instance:[/bold] {inst_id}")

            sync_manager = SyncManager(client, config_manager)
            result = sync_manager.export_all(inst_id, force=True)

            if result.success:
                console.print(f"[green]✓[/green] Exported configuration for instance '{inst_id}'")
            else:
                console.print(f"[red]✗[/red] Failed to export instance '{inst_id}'")
                if result.errors:
                    for error in result.errors:
                        console.print(f"  [dim]• {error}[/dim]")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise click.ClickException(str(e))


@cli.command()
@click.option("--instance", "-i", "instance_id", help="Instance ID to diff")
@click.option("--instance-name", "-n", "instance_name", help="Instance name (from index.yaml)")
@click.pass_context
def diff(ctx, instance_id, instance_name):
    """Show differences between YAML and Kafka state

    Display what would change if you applied the YAML configuration.
    """
    console.print("\n[bold cyan]Comparing YAML configuration with Kafka state[/bold cyan]\n")

    try:
        # Get credentials
        auth_manager = AuthManager()
        credentials = auth_manager.get_credentials()

        # Get config path from context
        config_path = ctx.obj.get('CONFIG_PATH')
        config_dir = Path(config_path) if config_path else None

        # Initialize client and config manager
        client = AliKafkaClient(credentials)
        config_manager = ConfigManager(config_dir)

        # Resolve instance
        if instance_id:
            target_instance = instance_id
        elif instance_name:
            resolved_id = config_manager.get_instance_id_by_name(instance_name)
            if not resolved_id:
                console.print(f"[red]Error:[/red] Instance '{instance_name}' not found in index.yaml")
                console.print("[dim]Available instances:[/dim]")
                index = config_manager.load_index()
                for inst_id, inst_name in index.get("instances", {}).items():
                    console.print(f"  [dim]{inst_name} (ID: {inst_id})[/dim]")
                return
            target_instance = resolved_id
            console.print(f"[dim]Resolved instance name '{instance_name}' to ID: {resolved_id}[/dim]")
        else:
            console.print("[red]Error:[/red] Please specify --instance or --instance-name")
            return

        # Run diff
        sync_manager = SyncManager(client, config_manager)
        sync_manager.diff(target_instance)

        console.print("\n[dim]Run 'alikafka apply --dry-run' for more details[/dim]")
        console.print("[dim]Run 'alikafka apply' to apply these changes[/dim]\n")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise click.ClickException(str(e))


@cli.command()
def git_status():
    """Show git status of configuration files

    Display modified configuration files and suggest a commit message.
    """
    console.print("\n[bold cyan]Git Status for Configuration Files[/bold cyan]\n")

    git_helper = GitHelper()

    if not git_helper.is_repo():
        console.print("[yellow]Not in a git repository[/yellow]")
        console.print("[dim]Run 'git init' to initialize a repository[/dim]")
        return

    git_helper.print_git_status()


@cli.command()
@click.option("--local", "-l", "list_config", is_flag=True, help="List instances in local config repository (default)")
@click.option("--api", "-a", "list_all", is_flag=True, help="List all Kafka instances in the account (from API)")
@click.pass_context
def list_instances(ctx, list_config, list_all):
    """List Kafka instances

    By default (or --local), lists instances in the local config repository.
    Use --api to list all instances in your Aliyun account.

    \b
    Examples:
        alikafka list-instances --local
        alikafka -c /path/to/config list-instances --local
    """
    console.print("\n[bold cyan]Listing Kafka Instances[/bold cyan]\n")

    if list_all:
        # API 模式：列出账号中的所有实例
        _list_instances_from_api()
    else:
        # 本地模式：列出配置仓库中的实例
        _list_instances_from_config(ctx)


def _list_instances_from_config(ctx):
    """List instances from local config repository"""
    try:
        from .config import ConfigManager

        # Get config path from context
        config_path = ctx.obj.get('CONFIG_PATH')
        config_dir = Path(config_path) if config_path else None

        config_manager = ConfigManager(config_dir)
        instances = config_manager.list_instances()

        if not instances:
            console.print("[yellow]No instances found in config repository[/yellow]")
            console.print("[dim]Run 'alikafka init' first to export from existing instance[/dim]")
            console.print("[dim]Or use --api to list all instances in your account[/dim]")
            return

        # Load index for instance names
        index = config_manager.load_index()
        instance_map = index.get("instances", {})

        # Display instances
        from rich.table import Table

        table = Table(title=f"Instances in Config Repository ({len(instances)})")
        table.add_column("Instance ID", style="cyan")
        table.add_column("Config Name", style="green")

        for inst_id in instances:
            config_name = instance_map.get(inst_id, "N/A")
            table.add_row(inst_id, config_name)

        console.print(table)
        console.print(f"\n[dim]Total: {len(instances)} instance(s)[/dim]")
        console.print("[dim]Tip: Use --api to list all instances in your Aliyun account, or omit options to use --local to list all instances in config repository (default)[/dim]")

    except Exception as e:
        console.print(f"[red]Error listing instances:[/red] {e}")


def _list_instances_from_api():
    """List all instances from Aliyun API"""
    try:
        # Get credentials
        auth_manager = AuthManager()
        credentials = auth_manager.get_credentials()

        # Initialize client
        client = AliKafkaClient(credentials)

        # Get instances
        instances = client.get_all_instances()

        if not instances:
            console.print("[yellow]No instances found[/yellow]")
            return

        # Display instances
        from rich.table import Table

        table = Table(title=f"All Aliyun Kafka Instances ({len(instances)})")
        table.add_column("Instance ID", style="cyan")
        table.add_column("Name", style="green")
        table.add_column("Region", style="blue")
        table.add_column("Status", style="yellow")

        for inst in instances:
            status_color = "green" if inst.status == "running" else "red"
            table.add_row(
                inst.instance_id,
                inst.name,
                inst.region_id,
                f"[{status_color}]{inst.status}[/{status_color}]"
            )

        console.print(table)
        console.print(f"\n[dim]Total: {len(instances)} instance(s)[/dim]")
        console.print("[dim]Tip: Use --config to list only instances in config repository (or omit options for default behavior)[/dim]")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise click.ClickException(str(e))


def main():
    """Main entry point"""
    cli()


if __name__ == "__main__":
    main()
