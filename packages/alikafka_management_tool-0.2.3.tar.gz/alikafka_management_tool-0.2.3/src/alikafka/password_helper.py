"""
Password management utilities for SASL users
"""
import os
import getpass
import secrets
import string
from typing import Optional


class PasswordHelper:
    """Helper class for resolving passwords from various sources"""

    @staticmethod
    def resolve_password(username: str, password_value: Optional[str]) -> Optional[str]:
        """
        Resolve password from:
        1. Direct value (not recommended)
        2. Environment variable: ${ENV_VAR}
        3. Username-based env: ${USERNAME_PASSWORD}
        """
        # Direct password
        if password_value and not password_value.startswith("${"):
            return password_value

        # Environment variable placeholder
        if password_value and password_value.startswith("${"):
            env_var = password_value.strip("${}")
            return os.getenv(env_var)

        # Try username-based environment variable
        env_var_name = f"{username.upper().replace('-', '_')}_PASSWORD"
        return os.getenv(env_var_name)

    @staticmethod
    def prompt_password(username: str) -> str:
        """Prompt user for password interactively"""
        print(f"\n[yellow]New SASL user '{username}' requires a password[/yellow]")
        while True:
            password = getpass.getpass(f"Enter password for '{username}': ")
            if not password:
                print("[red]Password cannot be empty. Please try again.[/red]")
                continue
            confirm = getpass.getpass(f"Confirm password for '{username}': ")
            if password == confirm:
                print("[green]✓[/green] Password set")
                return password
            print("[red]Passwords do not match. Please try again.[/red]")

    @staticmethod
    def get_password(username: str, password_value: Optional[str], allow_prompt: bool = True) -> Optional[str]:
        """Get password using all available methods"""
        password = PasswordHelper.resolve_password(username, password_value)
        if not password and allow_prompt:
            password = PasswordHelper.prompt_password(username)
        return password

    @staticmethod
    def generate_password(length: int = 16) -> str:
        """Generate a secure random password for SASL user

        Args:
            length: Password length (default: 16)

        Returns:
            Randomly generated password with letters, digits, and special characters
        """
        # Include: letters (upper/lower), digits, and special chars
        alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
        password = ''.join(secrets.choice(alphabet) for _ in range(length))
        return password
