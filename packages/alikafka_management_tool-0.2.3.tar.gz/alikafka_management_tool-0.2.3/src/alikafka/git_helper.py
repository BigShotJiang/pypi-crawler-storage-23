"""
Git Status Helper
Provides git status information and helpful commands for manual workflow
"""
from typing import List, Dict, Optional
from pathlib import Path

try:
    from git import Repo, InvalidGitRepositoryError
    GIT_AVAILABLE = True
except ImportError:
    GIT_AVAILABLE = False

from rich.console import Console
from rich.syntax import Syntax

console = Console()


class GitHelper:
    """Helper class for git operations"""

    def __init__(self, repo_path: str = "."):
        """
        Initialize git helper

        Args:
            repo_path: Path to the git repository
        """
        self.repo_path = Path(repo_path).resolve()

        if not GIT_AVAILABLE:
            console.print("[yellow]Warning:[/yellow] GitPython not installed. Git features disabled.")
            self.repo = None
            return

        try:
            self.repo = Repo(self.repo_path)
        except InvalidGitRepositoryError:
            console.print(f"[yellow]Warning:[/yellow] Not a git repository: {self.repo_path}")
            self.repo = None

    def is_repo(self) -> bool:
        """Check if current directory is a git repository"""
        return self.repo is not None

    def get_status(self) -> Dict[str, any]:
        """
        Get git status information

        Returns:
            Dictionary with status information
        """
        if not self.is_repo():
            return {}

        return {
            "branch": self.repo.active_branch.name if self.repo.active_branch else None,
            "is_dirty": self.repo.is_dirty(),
            "untracked_files": [str(f) for f in self.repo.untracked_files],
            "modified_files": [item.a_path for item in self.repo.index.diff(None)],
            "staged_files": [item.a_path for item in self.repo.index.diff("HEAD")]
        }

    def get_modified_files(self) -> List[str]:
        """
        Get list of modified files

        Returns:
            List of file paths
        """
        if not self.is_repo():
            return []

        status = self.get_status()
        files = []

        # Add modified files
        files.extend(status.get("modified_files", []))

        # Add staged files
        files.extend(status.get("staged_files", []))

        # Add untracked files (only in config/)
        untracked = status.get("untracked_files", [])
        files.extend([f for f in untracked if f.startswith("config/")])

        return list(set(files))  # Remove duplicates

    def get_config_files(self) -> List[str]:
        """
        Get modified files in the config directory

        Returns:
            List of config file paths
        """
        all_modified = self.get_modified_files()
        return [f for f in all_modified if f.startswith("config/")]

    def get_diff_summary(self) -> str:
        """
        Get a summary of changes

        Returns:
            String with diff summary
        """
        if not self.is_repo():
            return "Not a git repository"

        config_files = self.get_config_files()

        if not config_files:
            return "No changes in config files"

        summary = []
        for f in config_files:
            summary.append(f"  - {f}")

        return "\n".join(summary)

    def suggest_commit_message(self, operation: str, instance_id: str, changes: Dict[str, int]) -> str:
        """
        Generate a suggested commit message

        Args:
            operation: Operation performed (e.g., "apply", "export")
            instance_id: Instance ID
            changes: Dictionary with counts of created, updated, deleted items

        Returns:
            Suggested commit message
        """
        parts = []

        # Add prefix
        parts.append("[alikafka]")

        # Add operation and instance
        parts.append(f"{operation.capitalize()} {instance_id}:")

        # Add changes summary
        change_parts = []

        for resource_type, counts in changes.items():
            created = counts.get("created", 0)
            updated = counts.get("updated", 0)
            deleted = counts.get("deleted", 0)

            if created > 0:
                change_parts.append(f"+{created} {resource_type}")
            if updated > 0:
                change_parts.append(f"~{updated} {resource_type}")
            if deleted > 0:
                change_parts.append(f"-{deleted} {resource_type}")

        if change_parts:
            parts.append(" ".join(change_parts))

        return " ".join(parts)

    def print_git_status(self):
        """Print formatted git status"""
        if not self.is_repo():
            console.print("\n[dim]Not in a git repository[/dim]")
            return

        status = self.get_status()
        config_files = self.get_config_files()

        console.print(f"\n[bold cyan]Git Status[/bold cyan]")
        console.print(f"  Branch: [green]{status.get('branch', 'N/A')}[/green]")

        if config_files:
            console.print(f"\n[bold]Modified Config Files:[/bold]")
            for f in config_files:
                console.print(f"  [yellow]{f}[/yellow]")
        else:
            console.print(f"\n[dim]No changes in config files[/dim]")

    def print_commit_suggestion(self, message: str):
        """
        Print suggested commit message with git commands

        Args:
            message: The commit message
        """
        console.print(f"\n[bold cyan]Suggested Commit Message:[/bold cyan]")
        console.print(f"  {message}\n")

        console.print(f"[bold cyan]To commit these changes:[/bold cyan]")
        console.print(f"  [dim]git add config/[/dim]")
        console.print(f"  [dim]git commit -m \"{message}\"[/dim]")
        console.print(f"  [dim]git push[/dim]\n")
