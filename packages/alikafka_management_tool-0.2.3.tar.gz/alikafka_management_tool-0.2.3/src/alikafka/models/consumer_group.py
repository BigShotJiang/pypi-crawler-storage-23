"""
Consumer Group related data models
"""
from typing import Optional, List
from pydantic import BaseModel, Field


class ConsumerGroupTag(BaseModel):
    """Tag for a consumer group"""
    key: str = Field(..., max_length=128)
    value: Optional[str] = Field(None, max_length=128)


class ConsumerGroup(BaseModel):
    """Aliyun Kafka consumer group model"""
    group_name: str = Field(..., min_length=1, max_length=128)
    remark: Optional[str] = Field(None, max_length=128)
    tags: List[ConsumerGroupTag] = Field(default_factory=list)

    class Config:
        json_schema_extra = {
            "example": {
                "group_name": "event-processor",
                "remark": "Processes user and order events",
                "tags": [
                    {"key": "Team", "value": "Data"},
                    {"key": "Environment", "value": "production"}
                ]
            }
        }
