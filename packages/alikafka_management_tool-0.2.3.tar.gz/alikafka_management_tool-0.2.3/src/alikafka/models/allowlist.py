"""
Allowlist (whitelist) data models
"""
from typing import List, Optional
from pydantic import BaseModel, Field


class EndpointAllowlist(BaseModel):
    """Allowlist configuration for a specific endpoint type"""
    endpoint: str = Field(default="", description="Comma-separated endpoint URLs")
    port_range: Optional[str] = Field(None, description="Port range, e.g., '9092/9092'")
    description: Optional[str] = Field(None, description="Human-readable description")
    allowed_ips: List[str] = Field(default_factory=list, description="Allowed IP addresses")
    security_group_id: Optional[str] = Field(None, description="Security group ID")


class InstanceAllowlist(BaseModel):
    """Complete allowlist configuration for an instance"""
    instance_id: str
    vpc_default_endpoint: Optional[EndpointAllowlist] = Field(None, description="VPC default endpoint (port 9092)")
    vpc_sasl_endpoint: Optional[EndpointAllowlist] = Field(None, description="VPC SASL endpoint (port 9094)")
    vpc_ssl_endpoint: Optional[EndpointAllowlist] = Field(None, description="VPC SSL endpoint")
    internet_default_endpoint: Optional[EndpointAllowlist] = Field(None, description="Internet default endpoint")
    internet_sasl_endpoint: Optional[EndpointAllowlist] = Field(None, description="Internet SASL endpoint")
    internet_ssl_endpoint: Optional[EndpointAllowlist] = Field(None, description="Internet SSL endpoint")

    class Config:
        json_schema_extra = {
            "example": {
                "instance_id": "alikafka_post-cn-7pp2tz53u00a",
                "vpc_default_endpoint": {
                    "endpoint": "alikafka-post-cn-7pp2tz53u00a-1-vpc.alikafka.aliyuncs.com:9092",
                    "port_range": "9092/9092",
                    "description": "通过默认接入点可以在 VPC 内对实例进行访问",
                    "allowed_ips": ["10.0.0.0/24"],
                    "security_group_id": "sg-xxx"
                }
            }
        }
