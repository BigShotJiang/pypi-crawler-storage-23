"""
SASL User and ACL related data models
"""
from typing import Optional, List
from pydantic import BaseModel, Field
from enum import Enum


class SASLType(str, Enum):
    """SASL authentication types"""
    PLAIN = "plain"
    SCRAM_SHA_256 = "scram-sha-256"
    SCRAM_SHA_512 = "scram-sha-512"


class PermissionType(str, Enum):
    """ACL resource types"""
    TOPIC = "Topic"
    GROUP = "Group"


class ACLOperation(str, Enum):
    """ACL operation types"""
    # For Topic
    PUBLISH = "Publish"
    CONSUME = "Consume"
    # For Group
    ALL = "All"


class PatternType(str, Enum):
    """ACL pattern types"""
    LITERAL = "LITERAL"
    PREFIXED = "PREFIXED"


class ACLPermission(BaseModel):
    """ACL permission for a SASL user"""
    resource: str = Field(..., description="Topic name or consumer group name")
    permission_type: PermissionType = Field(..., description="Topic or Group")
    operation: ACLOperation = Field(..., description="Operation allowed")
    pattern_type: PatternType = Field(default=PatternType.LITERAL, description="LITERAL or PREFIXED")

    class Config:
        json_schema_extra = {
            "example": {
                "resource": "user-events",
                "permission_type": PermissionType.TOPIC,
                "operation": ACLOperation.CONSUME
            }
        }


class SASLUser(BaseModel):
    """Aliyun Kafka SASL user model"""
    username: str = Field(..., min_length=1, max_length=128)
    password: Optional[str] = Field(None, min_length=1, max_length=128)
    type: SASLType = Field(default=SASLType.PLAIN)
    acl_permissions: List[ACLPermission] = Field(default_factory=list)

    class Config:
        json_schema_extra = {
            "example": {
                "username": "app-client",
                "password": "${APP_CLIENT_PASSWORD}",  # Use env var placeholder
                "type": SASLType.PLAIN,
                "acl_permissions": [
                    {
                        "resource": "user-events",
                        "permission_type": PermissionType.TOPIC,
                        "operation": ACLOperation.CONSUME
                    },
                    {
                        "resource": "order-events",
                        "permission_type": PermissionType.TOPIC,
                        "operation": ACLOperation.CONSUME
                    }
                ]
            }
        }
