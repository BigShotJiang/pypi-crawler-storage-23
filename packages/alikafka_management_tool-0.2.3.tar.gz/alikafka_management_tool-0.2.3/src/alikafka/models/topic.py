"""
Topic-related data models
"""
from typing import Optional, List, Dict
from pydantic import BaseModel, Field, field_validator


class TopicTag(BaseModel):
    """Tag for a topic"""
    key: str = Field(..., max_length=128)
    value: Optional[str] = Field(None, max_length=128)


class TopicConfig(BaseModel):
    """Configuration parameters for a topic"""
    # Message retention (milliseconds)
    retention_ms: Optional[str] = Field(None, pattern=r'^\d+$')
    # Maximum message size (bytes)
    max_message_bytes: Optional[str] = Field(None, alias="max.message.bytes")
    # Message timestamp type: CreateTime or LogAppendTime
    message_timestamp_type: Optional[str] = Field(None, alias="message.timestamp.type")
    # For Serverless instances
    retention_hours: Optional[str] = Field(None, pattern=r'^\d+$')

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "retention_ms": "604800000",  # 7 days
                "max_message_bytes": "10485760",  # 10 MB
                "message_timestamp_type": "CreateTime"
            }
        }


class Topic(BaseModel):
    """Aliyun Kafka topic model"""
    name: str = Field(..., min_length=1, max_length=249)
    remark: Optional[str] = Field(None, max_length=64)  # Allow None/empty string from API
    partition_num: int = Field(default=12, ge=0, le=360)  # Allow 0 for deleted/system topics
    local_topic: bool = Field(default=False)  # Local storage vs cloud storage
    compact_topic: bool = Field(default=False)  # Compact cleanup policy
    replication_factor: Optional[int] = Field(None, ge=1, le=3)  # Only for local_topic
    min_insync_replicas: Optional[int] = Field(None, ge=1, le=3)  # Only for local_topic
    config: Optional[TopicConfig] = None
    tags: List[TopicTag] = Field(default_factory=list)

    @field_validator('name')
    def validate_name(cls, v):
        """Validate topic name format"""
        # Allowed: letters, numbers, underscore, hyphen, period
        # Note: Topics starting with '__' are valid Kafka system/internal topics
        import re
        if not re.match(r'^[a-zA-Z0-9_.\-]{1,249}$', v):
            raise ValueError(
                "Topic name must contain only letters, numbers, underscore, hyphen, and period"
            )
        return v

    @field_validator('remark', mode='before')
    @classmethod
    def validate_remark(cls, v):
        """Validate remark format"""
        # Allow None, empty string, or whitespace-only from API
        if v is None or v == "" or (isinstance(v, str) and not v.strip()):
            return ""
        # For import/export, just check length - allow any characters including Unicode
        if len(v) > 64:
            # Truncate if too long
            return v[:64]
        return v

    class Config:
        json_schema_extra = {
            "example": {
                "name": "user-events",
                "remark": "User behavior events topic",
                "partition_num": 12,
                "local_topic": False,
                "compact_topic": False,
                "replication_factor": None,
                "min_insync_replicas": None,
                "config": {
                    "retention_ms": "604800000",
                    "max_message_bytes": "10485760",
                    "message_timestamp_type": "CreateTime"
                },
                "tags": [
                    {"key": "Environment", "value": "production"}
                ]
            }
        }
