"""
Instance-related data models
"""
from typing import Optional, List, Union
from pydantic import BaseModel, Field, field_validator


class InstanceTag(BaseModel):
    """Tag for an instance"""
    key: str = Field(..., max_length=128)
    value: Optional[str] = Field(None, max_length=128)


class InstanceMetadata(BaseModel):
    """Metadata for an Aliyun Kafka instance"""
    # Basic information
    instance_id: Optional[str] = None  # Optional, used as key in YAML
    name: str
    region_id: str
    deploy_type: Optional[str] = Field(None, validate_default=True)
    spec_type: Optional[str] = None
    status: Optional[str] = None
    tags: List[InstanceTag] = Field(default_factory=list)

    # Instance type/version
    series: Optional[str] = None  # "v2", "v3", "confluent"
    paid_type: Optional[str] = None  # "Subscription", "PayAsYouGo", etc.

    # Traffic specifications
    io_max: Optional[int] = None  # Max traffic MB/s
    io_max_read: Optional[int] = None  # Max read traffic Mbit/s
    io_max_write: Optional[int] = None  # Max write traffic Mbit/s
    io_max_spec: Optional[str] = None  # Traffic spec description
    eip_max: Optional[int] = None  # Max public traffic

    # Disk/storage
    disk_size: Optional[int] = None  # Disk size GB
    disk_type: Optional[str] = None  # "UltraDisk", "SSD"
    msg_retain: Optional[int] = None  # Message retention hours

    # Usage statistics
    topic_num_limit: Optional[int] = None  # Topic count limit
    used_topic_count: Optional[int] = None  # Used topic count
    used_partition_count: Optional[int] = None  # Used partition count
    used_group_count: Optional[int] = None  # Used consumer group count

    # Connection endpoints
    domain_endpoint: Optional[str] = None
    sasl_domain_endpoint: Optional[str] = None
    ssl_domain_endpoint: Optional[str] = None
    vpc_sasl_domain_endpoint: Optional[str] = None

    # Other information
    create_time: Optional[int] = None  # Creation time (milliseconds timestamp)
    expired_time: Optional[int] = None  # Expiration time (milliseconds timestamp)
    service_status: Optional[int] = None  # Service status code
    vpc_id: Optional[str] = None
    zone_id: Optional[str] = None
    security_group: Optional[str] = None

    @field_validator('status', mode='before')
    @classmethod
    def convert_status(cls, v):
        """Convert status code to human-readable string"""
        if v is None:
            return None
        if isinstance(v, int):
            # Map integer status codes to string values
            status_map = {
                0: "Pending",
                1: "Deploying",
                2: "Running",
                3: "Stopped",
                5: "Expired",
                6: "Released",
                7: "Upgrading"
            }
            return status_map.get(v, f"Status_{v}")
        return str(v) if not isinstance(v, str) else v

    @field_validator('deploy_type', mode='before')
    @classmethod
    def convert_deploy_type(cls, v):
        """Convert deploy_type to string, handling integer values from API"""
        if v is None:
            return None
        if isinstance(v, int):
            # Map integer codes to string values
            deploy_map = {
                0: "Vpc",
                1: "Internet",
                2: "ClassicNet",
                5: "Ecs"
            }
            return deploy_map.get(v, str(v))
        return str(v)

    @field_validator('paid_type', mode='before')
    @classmethod
    def convert_paid_type(cls, v):
        """Convert paid_type to human-readable string"""
        if v is None:
            return None
        if isinstance(v, int):
            paid_map = {
                0: "Subscription",
                1: "PayAsYouGo",
                3: "ServerlessV3",
                4: "Confluent"
            }
            return paid_map.get(v, v)
        return v

    @field_validator('disk_type', mode='before')
    @classmethod
    def convert_disk_type(cls, v):
        """Convert disk_type to human-readable string"""
        if v is None:
            return None
        if isinstance(v, int):
            disk_map = {
                0: "UltraDisk",
                1: "SSD"
            }
            return disk_map.get(v, v)
        return v

    class Config:
        json_schema_extra = {
            "example": {
                "instance_id": "alikafka_pre-cn-mp919o4v****",
                "name": "My Kafka Instance",
                "region_id": "cn-shanghai",
                "deploy_type": "ECS",
                "spec_type": "professional",
                "status": "running",
                "tags": [
                    {"key": "Environment", "value": "production"},
                    {"key": "Team", "value": "Data"}
                ]
            }
        }


class InstanceInfo(BaseModel):
    """Brief information about an instance"""
    instance_id: str
    name: str
    region_id: str
    status: str

    @field_validator('status', mode='before')
    @classmethod
    def convert_status(cls, v):
        """Convert status code to human-readable string"""
        if v is None:
            return None
        if isinstance(v, int):
            # Map integer status codes to string values
            status_map = {
                0: "Pending",
                1: "Deploying",
                2: "Running",
                3: "Stopped",
                5: "Expired",
                6: "Released",
                7: "Upgrading"
            }
            return status_map.get(v, f"Status_{v}")
        return str(v) if not isinstance(v, str) else v

    class Config:
        json_schema_extra = {
            "example": {
                "instance_id": "alikafka_pre-cn-mp919o4v****",
                "name": "My Kafka Instance",
                "region_id": "cn-shanghai",
                "status": "running"
            }
        }
