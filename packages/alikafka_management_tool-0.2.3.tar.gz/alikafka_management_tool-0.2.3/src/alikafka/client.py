"""
Aliyun Kafka API Client Wrapper
Provides convenient methods for managing Aliyun Kafka resources
"""
from typing import List, Optional
from rich.console import Console

from alibabacloud_alikafka20190916.client import Client as AliKafkaClientSDK
from alibabacloud_tea_openapi import models as open_api
from alibabacloud_alikafka20190916 import models as alikafka_models

from .auth import AliyunCredentials
from .models import Topic, ConsumerGroup, InstanceInfo, InstanceMetadata, SASLUser, ACLPermission, SASLType

console = Console()


class AliKafkaClient:
    """Wrapper for Aliyun Kafka SDK with convenient methods"""

    def __init__(self, credentials: AliyunCredentials):
        """
        Initialize Aliyun Kafka client

        Args:
            credentials: AliyunCredentials object
        """
        config = open_api.Config(
            access_key_id=credentials.access_key_id,
            access_key_secret=credentials.access_key_secret,
            region_id=credentials.region_id
        )

        # Add security token if provided (for STS credentials)
        if credentials.security_token:
            config.security_token = credentials.security_token

        self.client = AliKafkaClientSDK(config)
        self.credentials = credentials

    # ==================== Instance Management ====================

    def get_all_instances(self) -> List[InstanceInfo]:
        """
        Get all Kafka instances for the current account

        Returns:
            List of InstanceInfo objects
        """
        try:
            request = alikafka_models.GetInstanceListRequest()
            response = self.client.get_instance_list(request)

            instances = []
            if response.body and hasattr(response.body, 'instance_list'):
                instance_list = response.body.instance_list
                # SDK uses instance_vo attribute
                inst_vos = getattr(instance_list, 'instance_vo', None) or \
                           getattr(instance_list, 'instanceVO', None) or []

                # Handle if inst_vos is directly the list
                if hasattr(inst_vos, '__iter__') and not isinstance(inst_vos, str):
                    inst_iterable = inst_vos
                else:
                    inst_iterable = []

                for inst in inst_iterable:
                    instances.append(InstanceInfo(
                        instance_id=getattr(inst, 'instance_id', ''),
                        name=getattr(inst, 'name', ''),
                        region_id=self.credentials.region_id,
                        status=getattr(inst, 'view_instance_status_code', getattr(inst, 'status', ''))
                    ))

            return instances

        except Exception as e:
            console.print(f"[red]Error fetching instances:[/red] {e}")
            raise

    def get_instance_detail(self, instance_id: str) -> Optional[InstanceMetadata]:
        """
        Get detailed information about a specific instance

        Args:
            instance_id: The instance ID

        Returns:
            InstanceMetadata object or None
        """
        try:
            request = alikafka_models.GetInstanceListRequest()
            response = self.client.get_instance_list(request)

            if response.body and hasattr(response.body, 'instance_list'):
                instance_list = response.body.instance_list
                inst_vos = getattr(instance_list, 'instance_vo', None) or \
                           getattr(instance_list, 'instanceVO', None) or []

                if hasattr(inst_vos, '__iter__') and not isinstance(inst_vos, str):
                    inst_iterable = inst_vos
                else:
                    inst_iterable = []

                for inst in inst_iterable:
                    if getattr(inst, 'instance_id', '') == instance_id:
                        # Convert tags
                        tags = []
                        if hasattr(inst, 'tags') and inst.tags:
                            tag_list = inst.tags
                            tags_list = getattr(tag_list, 'tag_vo', []) or []
                            for tag in tags_list:
                                from .models import InstanceTag
                                tags.append(InstanceTag(
                                    key=getattr(tag, 'key', ''),
                                    value=getattr(tag, 'value', '')
                                ))

                        # Extract all available fields
                        return InstanceMetadata(
                            # Basic information
                            instance_id=getattr(inst, 'instance_id', ''),
                            name=getattr(inst, 'name', ''),
                            region_id=self.credentials.region_id,
                            deploy_type=getattr(inst, 'deploy_type', None),
                            spec_type=getattr(inst, 'spec_type', None),
                            status=getattr(inst, 'view_instance_status_code', None),
                            tags=tags,
                            # Instance type/version
                            series=getattr(inst, 'series', None),
                            paid_type=getattr(inst, 'paid_type', None),
                            # Traffic specifications
                            io_max=getattr(inst, 'io_max', None),
                            io_max_read=getattr(inst, 'io_max_read', None),
                            io_max_write=getattr(inst, 'io_max_write', None),
                            io_max_spec=getattr(inst, 'io_max_spec', None),
                            eip_max=getattr(inst, 'eip_max', None),
                            # Disk/storage
                            disk_size=getattr(inst, 'disk_size', None),
                            disk_type=getattr(inst, 'disk_type', None),
                            msg_retain=getattr(inst, 'msg_retain', None),
                            # Usage statistics
                            topic_num_limit=getattr(inst, 'topic_num_limit', None),
                            used_topic_count=getattr(inst, 'used_topic_count', None),
                            used_partition_count=getattr(inst, 'used_partition_count', None),
                            used_group_count=getattr(inst, 'used_group_count', None),
                            # Connection endpoints
                            domain_endpoint=getattr(inst, 'domain_endpoint', None),
                            sasl_domain_endpoint=getattr(inst, 'sasl_domain_endpoint', None),
                            ssl_domain_endpoint=getattr(inst, 'ssl_domain_endpoint', None),
                            vpc_sasl_domain_endpoint=getattr(inst, 'vpc_sasl_domain_endpoint', None),
                            # Other information
                            create_time=getattr(inst, 'create_time', None),
                            expired_time=getattr(inst, 'expired_time', None),
                            service_status=getattr(inst, 'service_status', None),
                            vpc_id=getattr(inst, 'vpc_id', None),
                            zone_id=getattr(inst, 'zone_id', None),
                            security_group=getattr(inst, 'security_group', None)
                        )

            return None

        except Exception as e:
            console.print(f"[red]Error fetching instance details:[/red] {e}")
            raise

    def get_allowed_ip_list(self, instance_id: str) -> Optional[dict]:
        """
        Get the allowlist (whitelist) configuration for a specific instance

        Args:
            instance_id: The instance ID

        Returns:
            Dictionary containing internet_list and vpc_list with port_range information,
            or None if not found
        """
        try:
            request = alikafka_models.GetAllowedIpListRequest(
                instance_id=instance_id,
                region_id=self.credentials.region_id
            )

            response = self.client.get_allowed_ip_list(request)

            if response.body and response.body.success:
                result = {'internet_list': [], 'vpc_list': []}

                # Extract internet list
                if response.body.allowed_list and response.body.allowed_list.internet_list:
                    for item in response.body.allowed_list.internet_list:
                        internet_entry = {
                            'allowed_ip_list': item.allowed_ip_list or [],
                            'port_range': item.port_range,
                            'security_group_id': item.security_group_id,
                            'allowed_ip_group': item.allowed_ip_group,
                            'black_iplist': item.black_iplist,
                            'black_ipmap': item.black_ipmap
                        }
                        result['internet_list'].append(internet_entry)

                # Extract VPC list
                if response.body.allowed_list and response.body.allowed_list.vpc_list:
                    for item in response.body.allowed_list.vpc_list:
                        vpc_entry = {
                            'allowed_ip_list': item.allowed_ip_list or [],
                            'port_range': item.port_range,
                            'security_group_id': item.security_group_id,
                            'allowed_ip_group': item.allowed_ip_group,
                            'black_iplist': item.black_iplist,
                            'black_ipmap': item.black_ipmap
                        }
                        result['vpc_list'].append(vpc_entry)

                return result
            else:
                console.print(f"[yellow]Warning:[/yellow] Failed to get allowlist: {response.body.message if response.body else 'Unknown error'}")
                return None

        except Exception as e:
            console.print(f"[red]Error fetching allowlist:[/red] {e}")
            return None

    # ==================== Topic Management ====================

    def create_topic(self, instance_id: str, topic: Topic) -> bool:
        """
        Create a new topic in the specified instance

        Args:
            instance_id: The instance ID
            topic: Topic object with configuration

        Returns:
            True if successful
        """
        try:
            request = alikafka_models.CreateTopicRequest(
                instance_id=instance_id,
                topic=topic.name,
                remark=topic.remark,
                region_id=self.credentials.region_id,
                partition_num=str(topic.partition_num),
                local_topic=topic.local_topic,
                compact_topic=topic.compact_topic
            )

            # Optional parameters
            if topic.replication_factor:
                request.replication_factor = topic.replication_factor
            if topic.min_insync_replicas:
                request.min_insync_replicas = topic.min_insync_replicas

            # Config as JSON string
            if topic.config:
                config_dict = topic.config.model_dump(exclude_none=True, by_alias=True)
                import json
                request.config = json.dumps(config_dict)

            # Tags
            if topic.tags:
                tag_list = []
                for tag in topic.tags:
                    tag_model = alikafka_models.CreateTopicRequestTag()
                    tag_model.key = tag.key
                    tag_model.value = tag.value
                    tag_list.append(tag_model)
                request.tag = tag_list

            response = self.client.create_topic(request)

            if response.body and response.body.success:
                console.print(f"[green]✓[/green] Created topic '{topic.name}'")
                return True
            else:
                console.print(f"[red]✗[/red] Failed to create topic '{topic.name}'")
                return False

        except Exception as e:
            console.print(f"[red]Error creating topic:[/red] {e}")
            raise

    def delete_topic(self, instance_id: str, topic_name: str) -> bool:
        """
        Delete a topic from the specified instance

        Args:
            instance_id: The instance ID
            topic_name: Name of the topic to delete

        Returns:
            True if successful
        """
        try:
            request = alikafka_models.DeleteTopicRequest(
                instance_id=instance_id,
                topic=topic_name,
                region_id=self.credentials.region_id
            )

            response = self.client.delete_topic(request)

            if response.body and response.body.success:
                console.print(f"[green]✓[/green] Deleted topic '{topic_name}'")
                return True
            else:
                console.print(f"[red]✗[/red] Failed to delete topic '{topic_name}'")
                return False

        except Exception as e:
            console.print(f"[red]Error deleting topic:[/red] {e}")
            raise

    def modify_topic_remark(self, instance_id: str, topic_name: str, remark: str) -> bool:
        """
        Modify the remark (description) of a topic

        Args:
            instance_id: The instance ID
            topic_name: Name of the topic
            remark: New description/remark

        Returns:
            True if successful
        """
        try:
            request = alikafka_models.ModifyTopicRemarkRequest(
                instance_id=instance_id,
                topic=topic_name,
                remark=remark,
                region_id=self.credentials.region_id
            )

            response = self.client.modify_topic_remark(request)

            if response.body and response.body.success:
                console.print(f"[green]✓[/green] Updated remark for topic '{topic_name}'")
                return True
            else:
                console.print(f"[yellow]Warning:[/yellow] Failed to update remark: {response.body.message if response.body else 'Unknown error'}")
                return False

        except Exception as e:
            console.print(f"[red]Error updating topic remark:[/red] {e}")
            return False

    def modify_partition_num(self, instance_id: str, topic_name: str, current_partitions: int, desired_partitions: int) -> bool:
        """
        Modify the number of partitions for a topic (can only increase, not decrease)

        Args:
            instance_id: The instance ID
            topic_name: Name of the topic
            current_partitions: Current number of partitions
            desired_partitions: Desired number of partitions

        Returns:
            True if successful
        """
        try:
            if desired_partitions <= current_partitions:
                console.print(f"[yellow]Warning:[/yellow] Cannot decrease partitions from {current_partitions} to {desired_partitions} (not supported by Aliyun Kafka)")
                return False

            # Calculate how many partitions to add
            add_partition_num = desired_partitions - current_partitions

            # Validate max partition limit
            if desired_partitions > 360:
                console.print(f"[red]Error:[/red] Desired partition count {desired_partitions} exceeds maximum of 360")
                return False

            request = alikafka_models.ModifyPartitionNumRequest(
                instance_id=instance_id,
                topic=topic_name,
                add_partition_num=add_partition_num,
                region_id=self.credentials.region_id
            )

            response = self.client.modify_partition_num(request)

            if response.body and response.body.success:
                console.print(f"[green]✓[/green] Increased partitions for topic '{topic_name}': {current_partitions} -> {desired_partitions}")
                return True
            else:
                console.print(f"[yellow]Warning:[/yellow] Failed to modify partitions: {response.body.message if response.body else 'Unknown error'}")
                return False

        except Exception as e:
            console.print(f"[red]Error modifying topic partitions:[/red] {e}")
            return False

    def list_topics(self, instance_id: str) -> List[Topic]:
        """
        List all topics in the specified instance

        Args:
            instance_id: The instance ID

        Returns:
            List of Topic objects
        """
        try:
            request = alikafka_models.GetTopicListRequest(
                instance_id=instance_id,
                region_id=self.credentials.region_id
            )

            response = self.client.get_topic_list(request)

            topics = []
            if response.body and hasattr(response.body, 'topic_list'):
                topic_list = response.body.topic_list
                # Correct SDK attribute: topic_vo (not topic_v_o)
                topic_vos = getattr(topic_list, 'topic_vo', None) or \
                           getattr(topic_list, 'topicVO', None) or []

                # Handle if topic_vos is directly the list or wrapped in a list attribute
                if hasattr(topic_vos, '__iter__') and not isinstance(topic_vos, str):
                    topic_iterable = topic_vos
                else:
                    topic_iterable = []

                for topic_vo in topic_iterable:
                    # Convert tags - SDK uses tag_vo attribute
                    tags = []
                    if hasattr(topic_vo, 'tags') and topic_vo.tags:
                        # tags is a GetTopicListResponseBodyTopicListTopicVOTags object with tag_vo list
                        tag_vo_list = getattr(topic_vo.tags, 'tag_vo', []) or []
                        for tag in tag_vo_list:
                            from .models import TopicTag
                            tags.append(TopicTag(
                                key=getattr(tag, 'key', ''),
                                value=getattr(tag, 'value', '')
                            ))

                    # SDK uses partition_num, not partition
                    partition_num = getattr(topic_vo, 'partition_num', 0) or 0

                    topics.append(Topic(
                        name=getattr(topic_vo, 'topic', ''),
                        remark=getattr(topic_vo, 'remark') or "",  # Handle None/empty
                        partition_num=partition_num,
                        local_topic=getattr(topic_vo, 'local_topic', False),
                        compact_topic=getattr(topic_vo, 'compact_topic', False),
                        tags=tags
                    ))

            return topics

        except Exception as e:
            console.print(f"[red]Error listing topics:[/red] {e}")
            raise

    # ==================== Consumer Group Management ====================

    def create_consumer_group(self, instance_id: str, group: ConsumerGroup) -> bool:
        """
        Create a new consumer group in the specified instance

        Args:
            instance_id: The instance ID
            group: ConsumerGroup object

        Returns:
            True if successful
        """
        try:
            request = alikafka_models.CreateConsumerGroupRequest(
                instance_id=instance_id,
                consumer_id=group.group_name,
                remark=group.remark or "",
                region_id=self.credentials.region_id
            )

            # Tags
            if group.tags:
                tag_list = []
                for tag in group.tags:
                    tag_model = alikafka_models.CreateConsumerGroupRequestTag()
                    tag_model.key = tag.key
                    tag_model.value = tag.value
                    tag_list.append(tag_model)
                request.tag = tag_list

            response = self.client.create_consumer_group(request)

            if response.body and response.body.success:
                console.print(f"[green]✓[/green] Created consumer group '{group.group_name}'")
                return True
            else:
                console.print(f"[red]✗[/red] Failed to create consumer group '{group.group_name}'")
                return False

        except Exception as e:
            console.print(f"[red]Error creating consumer group:[/red] {e}")
            raise

    def delete_consumer_group(self, instance_id: str, group_name: str) -> bool:
        """
        Delete a consumer group from the specified instance

        Args:
            instance_id: The instance ID
            group_name: Name of the consumer group to delete

        Returns:
            True if successful
        """
        try:
            request = alikafka_models.DeleteConsumerGroupRequest(
                instance_id=instance_id,
                consumer_id=group_name,
                region_id=self.credentials.region_id
            )

            response = self.client.delete_consumer_group(request)

            if response.body and response.body.success:
                console.print(f"[green]✓[/green] Deleted consumer group '{group_name}'")
                return True
            else:
                console.print(f"[red]✗[/red] Failed to delete consumer group '{group_name}'")
                return False

        except Exception as e:
            console.print(f"[red]Error deleting consumer group:[/red] {e}")
            raise

    def list_consumer_groups(self, instance_id: str) -> List[ConsumerGroup]:
        """
        List all consumer groups in the specified instance

        Args:
            instance_id: The instance ID

        Returns:
            List of ConsumerGroup objects
        """
        try:
            request = alikafka_models.GetConsumerListRequest(
                instance_id=instance_id,
                region_id=self.credentials.region_id
            )

            response = self.client.get_consumer_list(request)

            groups = []
            if response.body and hasattr(response.body, 'consumer_list'):
                consumer_list = response.body.consumer_list
                # Correct SDK attribute: consumer_vo (not consumer_v_o)
                group_vos = getattr(consumer_list, 'consumer_vo', None) or \
                           getattr(consumer_list, 'consumerVO', None) or []

                # Handle if group_vos is directly the list or wrapped in a list attribute
                if hasattr(group_vos, '__iter__') and not isinstance(group_vos, str):
                    group_iterable = group_vos
                else:
                    group_iterable = []

                for group_vo in group_iterable:
                    # Convert tags - SDK uses tag_vo attribute
                    tags = []
                    if hasattr(group_vo, 'tags') and group_vo.tags:
                        # tags is a GetConsumerListResponseBodyConsumerListConsumerVOTags object with tag_vo list
                        tag_vo_list = getattr(group_vo.tags, 'tag_vo', []) or []
                        for tag in tag_vo_list:
                            from .models import ConsumerGroupTag
                            tags.append(ConsumerGroupTag(
                                key=getattr(tag, 'key', ''),
                                value=getattr(tag, 'value', '')
                            ))

                    groups.append(ConsumerGroup(
                        group_name=getattr(group_vo, 'consumer_id', ''),  # Correct: consumer_id, not consumer_group
                        remark=getattr(group_vo, 'remark', ''),
                        tags=tags
                    ))

            return groups

        except Exception as e:
            console.print(f"[red]Error listing consumer groups:[/red] {e}")
            raise

    # ==================== SASL User Management ====================
    # API documentation: https://api.aliyun.com/document/alikafka/2019-09-16/DescribeSaslUsers

    def describe_sasl_users(self, instance_id: str, acl_permissions_map: dict = None) -> List[SASLUser]:
        """
        Describe all SASL users in the specified instance

        Args:
            instance_id: The instance ID
            acl_permissions_map: Optional dict mapping username -> list of ACLPermission objects

        Returns:
            List of SASLUser objects
        """
        try:
            request = alikafka_models.DescribeSaslUsersRequest(
                instance_id=instance_id,
                region_id=self.credentials.region_id
            )

            response = self.client.describe_sasl_users(request)

            users = []
            if response.body and hasattr(response.body, 'sasl_user_list'):
                user_list = response.body.sasl_user_list
                # Correct SDK attribute: sasl_user_vo (not sasl_user_v_o)
                user_vos = getattr(user_list, 'sasl_user_vo', None) or \
                           getattr(user_list, 'saslUserVO', None) or []

                # Handle if user_vos is directly the list or wrapped in a list attribute
                if hasattr(user_vos, '__iter__') and not isinstance(user_vos, str):
                    user_iterable = user_vos
                else:
                    user_iterable = []

                for user_vo in user_iterable:
                    # Convert password - never export actual passwords from API
                    # Use placeholder for security
                    user_type = getattr(user_vo, 'type', None)
                    try:
                        sasl_type = SASLType(user_type) if user_type else SASLType.PLAIN
                    except ValueError:
                        sasl_type = SASLType.PLAIN

                    username = getattr(user_vo, 'username', '')

                    # Get ACL permissions for this user if map is provided
                    acl_perms = acl_permissions_map.get(username, []) if acl_permissions_map else []

                    user = SASLUser(
                        username=username,
                        password=None,  # Passwords are not returned by the API
                        type=sasl_type,
                        acl_permissions=acl_perms
                    )
                    users.append(user)

            return users

        except Exception as e:
            console.print(f"[red]Error describing SASL users:[/red] {e}")
            raise

    def create_sasl_user(self, instance_id: str, user: SASLUser, password: str = None) -> bool:
        """
        Create a new SASL user in the specified instance

        Args:
            instance_id: The instance ID
            user: SASLUser object with username, type, and ACL permissions
            password: Password string (required for creation)

        Returns:
            True if successful
        """
        if not password:
            raise ValueError("Password is required for creating SASL users")

        try:
            request = alikafka_models.CreateSaslUserRequest(
                instance_id=instance_id,
                username=user.username,
                password=password,
                type=user.type.value,
                region_id=self.credentials.region_id
            )

            response = self.client.create_sasl_user(request)

            if response.body and response.body.success:
                return True
            else:
                console.print(f"[red]✗[/red] Failed to create SASL user '{user.username}'")
                return False

        except Exception as e:
            console.print(f"[red]Error creating SASL user:[/red] {e}")
            raise

    def delete_sasl_user(self, instance_id: str, username: str) -> bool:
        """
        Delete a SASL user from the specified instance

        Args:
            instance_id: The instance ID
            username: Username of the SASL user to delete

        Returns:
            True if successful
        """
        try:
            request = alikafka_models.DeleteSaslUserRequest(
                instance_id=instance_id,
                username=username,
                region_id=self.credentials.region_id
            )

            response = self.client.delete_sasl_user(request)

            if response.body and response.body.success:
                console.print(f"[green]✓[/green] Deleted SASL user '{username}'")
                return True
            else:
                console.print(f"[red]✗[/red] Failed to delete SASL user '{username}'")
                return False

        except Exception as e:
            console.print(f"[red]Error deleting SASL user:[/red] {e}")
            raise

    def list_sasl_users(self, instance_id: str) -> List[SASLUser]:
        """
        Alias for describe_sasl_users for backward compatibility

        Args:
            instance_id: The instance ID

        Returns:
            List of SASLUser objects
        """
        return self.describe_sasl_users(instance_id)

    def get_all_acl_permissions(self, instance_id: str, topics: List = None, groups: List = None) -> dict:
        """
        Get ALL ACL permissions for all users on all resources.

        Strategy:
        1. Use DescribeAclResourceName to find all resources with ACLs (4 combinations)
        2. Then use DescribeAcls with username="*" to get all user permissions for those resources

        Args:
            instance_id: The instance ID
            topics: Optional list of Topic objects (to avoid re-fetching)
            groups: Optional list of ConsumerGroup objects (to avoid re-fetching)

        Returns:
            Dict mapping username -> list of ACLPermission objects
        """
        try:
            from .models.sasl_user import ACLPermission, PermissionType, ACLOperation, PatternType

            # Get all SASL users first to initialize the dict
            users = self.describe_sasl_users(instance_id)
            user_acls = {user.username: [] for user in users}

            # Step 1: Discover resources with ACLs (4 combinations)
            console.print("[dim]Discovering resources with ACL permissions...[/dim]")

            all_resources_with_acls = []

            # Try all 4 combinations: (Topic, Group) x (LITERAL, PREFIXED)
            for resource_type in ["Topic", "Group"]:
                for pattern_type in ["LITERAL", "PREFIXED"]:
                    try:
                        request = alikafka_models.DescribeAclResourceNameRequest(
                            instance_id=instance_id,
                            acl_resource_type=resource_type,
                            acl_resource_pattern_type=pattern_type,
                            region_id=self.credentials.region_id
                        )
                        response = self.client.describe_acl_resource_name(request)

                        if response.body and hasattr(response.body, 'data'):
                            resource_data = response.body.data
                            resource_names = getattr(resource_data, 'data', []) or []

                            for resource_name in resource_names:
                                all_resources_with_acls.append({
                                    'type': resource_type,
                                    'name': resource_name,
                                    'pattern': pattern_type
                                })
                    except Exception as e:
                        # Silently skip errors for individual queries
                        pass

            # Remove duplicates and log
            unique_resources = []
            seen = set()
            for res in all_resources_with_acls:
                key = f"{res['type']}:{res['name']}"
                if key not in seen:
                    seen.add(key)
                    unique_resources.append(res)

            topic_count = sum(1 for r in unique_resources if r['type'] == 'Topic')
            group_count = sum(1 for r in unique_resources if r['type'] == 'Group')
            console.print(f"[dim]  Found {topic_count} topics and {group_count} groups with ACLs[/dim]")

            # Step 2: Query detailed permissions for each resource (using username="*" wildcard)
            console.print(f"[dim]Querying detailed ACL permissions for {len(unique_resources)} resources...[/dim]")

            for resource in unique_resources:
                resource_type = resource['type']
                resource_name = resource['name']

                try:
                    # Use username="*" to get all user permissions for this resource
                    request = alikafka_models.DescribeAclsRequest(
                        instance_id=instance_id,
                        username="*",  # Get all users at once
                        acl_resource_type=resource_type,
                        acl_resource_name=resource_name,
                        region_id=self.credentials.region_id
                    )
                    response = self.client.describe_acls(request)

                    if response.body and hasattr(response.body, 'kafka_acl_list'):
                        acl_list = response.body.kafka_acl_list
                        acl_vos = getattr(acl_list, 'kafka_acl_vo', []) or []

                        for acl_vo in acl_vos:
                            username = getattr(acl_vo, 'username', '')
                            if not username or username == '*':
                                continue

                            if username not in user_acls:
                                user_acls[username] = []

                            acl_operation = getattr(acl_vo, 'acl_operation_type', '')

                            # Map operation types
                            operation = None
                            if acl_operation:
                                acl_op_upper = acl_operation.upper()
                                if acl_op_upper in ['READ']:
                                    operation = ACLOperation.CONSUME
                                elif acl_op_upper in ['WRITE']:
                                    operation = ACLOperation.PUBLISH
                                elif acl_op_upper in ['ALL', 'IDEMPOTENT_WRITE']:
                                    operation = ACLOperation.ALL
                                else:
                                    try:
                                        operation = ACLOperation(acl_op_upper)
                                    except ValueError:
                                        operation = ACLOperation.ALL

                            if operation:
                                perm_type = PermissionType.TOPIC if resource_type == "Topic" else PermissionType.GROUP
                                # Get pattern_type from the resource info
                                pattern_type_value = resource.get('pattern', 'LITERAL')
                                pattern_type = PatternType.LITERAL if pattern_type_value == 'LITERAL' else PatternType.PREFIXED

                                user_acls[username].append(ACLPermission(
                                    resource=resource_name,
                                    permission_type=perm_type,
                                    operation=operation,
                                    pattern_type=pattern_type
                                ))
                except Exception as e:
                    # Silently skip errors for individual queries
                    pass

            console.print(f"[dim]Completed querying ACL permissions[/dim]")
            return user_acls

        except Exception as e:
            console.print(f"[yellow]Warning: Error fetching ACL permissions:[/yellow] {e}")
            console.print("[dim]SASL users will be exported without ACL permissions.[/dim]")
            return {}

    def get_user_acl_permissions(self, instance_id: str, username: str, resource_type: str, resource_name: str) -> List:
        """
        Get ACL permissions for a specific SASL user on a specific resource

        Note: The Aliyun DescribeAcls API requires both username AND resource info.
        You cannot query all permissions for a user at once.

        Args:
            instance_id: The instance ID
            username: The SASL username
            resource_type: Resource type (e.g., "Topic", "Group")
            resource_name: Resource name (e.g., topic name or consumer group name)

        Returns:
            List of ACL permission objects
        """
        try:
            from .models.sasl_user import ACLPermission, PermissionType, ACLOperation

            request = alikafka_models.DescribeAclsRequest(
                instance_id=instance_id,
                username=username,
                acl_resource_type=resource_type,
                acl_resource_name=resource_name,
                region_id=self.credentials.region_id
            )

            response = self.client.describe_acls(request)

            permissions = []
            if response.body and hasattr(response.body, 'kafka_acl_list'):
                acl_list = response.body.kafka_acl_list
                acl_vos = getattr(acl_list, 'kafka_acl_vo', []) or []

                for acl_vo in acl_vos:
                    # Map Aliyun ACL operation to our model
                    acl_operation = getattr(acl_vo, 'acl_operation_type', '')
                    res_type = getattr(acl_vo, 'acl_resource_type', '')
                    res_name = getattr(acl_vo, 'acl_resource_name', '')

                    # Map operation types
                    operation = None
                    if acl_operation:
                        acl_op_upper = acl_operation.upper()
                        # Map Read/Write to Consume/Publish for backward compatibility
                        if acl_op_upper in ['READ']:
                            operation = ACLOperation.CONSUME
                        elif acl_op_upper in ['WRITE']:
                            operation = ACLOperation.PUBLISH
                        elif acl_op_upper in ['ALL', 'IDEMPOTENT_WRITE']:
                            operation = ACLOperation.ALL
                        else:
                            # Use the raw value if it's not one of the known operations
                            try:
                                operation = ACLOperation(acl_op_upper)
                            except ValueError:
                                operation = ACLOperation.ALL  # Default fallback

                    # Map resource type
                    permission_type = None
                    if res_type:
                        res_type_upper = res_type.upper()
                        try:
                            permission_type = PermissionType(res_type_upper)
                        except ValueError:
                            # Fallback to checking the value
                            if 'TOPIC' in res_type_upper:
                                permission_type = PermissionType.TOPIC
                            elif 'GROUP' in res_type_upper:
                                permission_type = PermissionType.GROUP

                    if operation and permission_type:
                        permissions.append(ACLPermission(
                            resource=res_name,
                            permission_type=permission_type,
                            operation=operation
                        ))

            return permissions

        except Exception as e:
            console.print(f"[red]Error fetching ACL permissions for user '{username}' on resource '{resource_name}':[/red] {e}")
            return []

    def create_acl(self, instance_id: str, username: str, permission: ACLPermission) -> bool:
        """
        Create an ACL permission for a SASL user

        Args:
            instance_id: The instance ID
            username: The SASL username
            permission: ACLPermission object

        Returns:
            True if successful
        """
        try:
            # Map operation types
            operation_map = {
                "Publish": "Write",
                "Consume": "Read",
                "All": "Read"
            }
            acl_operation_type = operation_map.get(permission.operation.value, "Read")

            request = alikafka_models.CreateAclRequest(
                instance_id=instance_id,
                region_id=self.credentials.region_id,
                username=username,
                acl_resource_type=permission.permission_type.value,  # Topic or Group
                acl_resource_name=permission.resource,
                acl_operation_type=acl_operation_type,
                acl_resource_pattern_type=permission.pattern_type.value  # LITERAL or PREFIXED
            )

            response = self.client.create_acl(request)

            if response.body and response.body.success:
                return True
            else:
                console.print(f"[yellow]Warning:[/yellow] Failed to create ACL: {response.body.message if response.body else 'Unknown error'}")
                return False

        except Exception as e:
            console.print(f"[red]Error creating ACL:[/red] {e}")
            return False

    def delete_acl(self, instance_id: str, username: str, permission: ACLPermission) -> bool:
        """
        Delete an ACL permission for a SASL user

        Args:
            instance_id: The instance ID
            username: The SASL username
            permission: ACLPermission object

        Returns:
            True if successful
        """
        try:
            # Map operation types
            operation_map = {
                "Publish": "Write",
                "Consume": "Read",
                "All": "Read"
            }
            acl_operation_type = operation_map.get(permission.operation.value, "Read")

            request = alikafka_models.DeleteAclRequest(
                instance_id=instance_id,
                region_id=self.credentials.region_id,
                username=username,
                acl_resource_type=permission.permission_type.value,
                acl_resource_name=permission.resource,
                acl_operation_type=acl_operation_type,
                acl_resource_pattern_type=permission.pattern_type.value
            )

            response = self.client.delete_acl(request)

            if response.body and response.body.success:
                return True
            else:
                console.print(f"[yellow]Warning:[/yellow] Failed to delete ACL: {response.body.message if response.body else 'Unknown error'}")
                return False

        except Exception as e:
            console.print(f"[red]Error deleting ACL:[/red] {e}")
            return False

    def get_user_acls(self, instance_id: str, username: str) -> List[ACLPermission]:
        """
        Get all ACL permissions for a specific SASL user

        Args:
            instance_id: The instance ID
            username: The SASL username

        Returns:
            List of ACLPermission objects
        """
        try:
            # Get all ACL permissions and filter by username
            # get_all_acl_permissions already returns ACLPermission objects
            all_acls = self.get_all_acl_permissions(instance_id)
            user_acls = all_acls.get(username, [])

            # Return as-is (already ACLPermission objects)
            return user_acls

        except Exception as e:
            console.print(f"[red]Error fetching user ACLs:[/red] {e}")
            return []
