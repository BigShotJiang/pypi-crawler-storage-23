"""
YAML Configuration Manager
Handles loading and saving of YAML configuration files
"""
import os
from pathlib import Path
from typing import List, Optional
import yaml

from rich.console import Console

from .models import Topic, ConsumerGroup, SASLUser, InstanceMetadata

console = Console()


class ConfigManager:
    """Manages YAML configuration files for Kafka resources"""

    def __init__(self, config_dir: Optional[Path] = None):
        """
        Initialize configuration manager

        Args:
            config_dir: Custom config directory path.
                       If None, uses environment variable ALIKAFKA_CONFIG_DIR.
                       If still None, uses "config" subdirectory from current working directory.
        """
        if config_dir is None:
            # Try to read from environment variable
            env_path = os.getenv("ALIKAFKA_CONFIG_DIR")
            if env_path:
                config_dir = Path(env_path)
            else:
                # Default to "config" directory from current working directory
                config_dir = Path.cwd() / "config"

        self.config_dir = Path(config_dir)
        self.instances_dir = self.config_dir / "instances"
        self.index_file = self.config_dir / "index.yaml"

        # Ensure directories exist
        self.instances_dir.mkdir(parents=True, exist_ok=True)

    def get_instance_dir(self, instance_id: str) -> Path:
        """
        Get the directory path for a specific instance using instance name from index

        Args:
            instance_id: The instance ID

        Returns:
            Path object for the instance directory
        """
        # Try to get instance name from index
        instance_name = self.get_instance_name(instance_id)

        # Fall back to instance_id if no mapping found
        if not instance_name:
            instance_name = instance_id

        # Sanitize instance name for use as directory name
        safe_name = instance_name.replace("/", "-").replace("\\", "-")
        instance_dir = self.instances_dir / safe_name
        instance_dir.mkdir(parents=True, exist_ok=True)
        return instance_dir

    def get_instance_name(self, instance_id: str) -> Optional[str]:
        """
        Get instance name from index mapping

        Args:
            instance_id: The instance ID

        Returns:
            Instance name or None if not found
        """
        index = self.load_index()
        return index.get("instances", {}).get(instance_id)

    def add_instance_mapping(self, instance_id: str, instance_name: str):
        """
        Add or update instance ID -> name mapping in index

        Args:
            instance_id: The instance ID
            instance_name: The instance name
        """
        index = self.load_index()

        if "instances" not in index:
            index["instances"] = {}

        index["instances"][instance_id] = instance_name
        self.save_index(index)

    def get_instance_id_by_name(self, instance_name: str) -> Optional[str]:
        """
        Find instance ID by instance name from index.yaml

        Args:
            instance_name: The instance name to search for

        Returns:
            Instance ID or None if not found
        """
        index = self.load_index()
        instances = index.get("instances", {})

        # Reverse lookup: find instance_id where name matches
        for inst_id, name in instances.items():
            if name == instance_name:
                return inst_id

        return None

    def load_index(self) -> dict:
        """
        Load index mapping from file

        Returns:
            Dictionary with instance mappings
        """
        if not self.index_file.exists():
            return {"instances": {}}

        with open(self.index_file, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {"instances": {}}

    def save_index(self, index: dict):
        """
        Save index mapping to file

        Args:
            index: Dictionary with instance mappings
        """
        with open(self.index_file, "w", encoding="utf-8") as f:
            yaml.safe_dump(index, f, default_flow_style=False, allow_unicode=True, sort_keys=True)

    def list_instances(self) -> List[str]:
        """
        List all instances with configuration

        Returns:
            List of instance IDs
        """
        if not self.instances_dir.exists():
            return []

        instances = []
        for item in self.instances_dir.iterdir():
            if item.is_dir() and (item / "metadata.yaml").exists():
                # Read instance_id from metadata.yaml
                metadata_file = item / "metadata.yaml"
                try:
                    with open(metadata_file, "r", encoding="utf-8") as f:
                        data = yaml.safe_load(f)
                        if data:
                            # New format: instance_id is the top-level key
                            if len(data) == 1:
                                instance_id = next(iter(data.keys()))
                                instances.append(instance_id)
                            # Old format: instance_id is a field
                            elif data.get("instance_id"):
                                instances.append(data["instance_id"])
                except Exception:
                    # Skip invalid metadata files
                    continue
        return instances

    # ==================== Global Config ====================

    def load_global_config(self) -> dict:
        """
        Load global configuration

        Returns:
            Dictionary with global configuration
        """
        global_config_path = self.config_dir / "global.yaml"

        if not global_config_path.exists():
            return {"default_region": "cn-shanghai"}

        with open(global_config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}

    def save_global_config(self, config: dict):
        """
        Save global configuration

        Args:
            config: Configuration dictionary
        """
        global_config_path = self.config_dir / "global.yaml"

        with open(global_config_path, "w", encoding="utf-8") as f:
            yaml.safe_dump(config, f, default_flow_style=False, allow_unicode=True)

    # ==================== Topic Config ====================

    def load_topics(self, instance_id: str) -> List[Topic]:
        """
        Load topics from YAML file

        Args:
            instance_id: The instance ID

        Returns:
            List of Topic objects
        """
        instance_dir = self.get_instance_dir(instance_id)
        topics_file = instance_dir / "topics.yaml"

        if not topics_file.exists():
            return []

        with open(topics_file, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
            topic_data = data.get("topics", [])
            return [Topic(**topic) for topic in topic_data]

    def save_topics(self, instance_id: str, topics: List[Topic]):
        """
        Save topics to YAML file

        Args:
            instance_id: The instance ID
            topics: List of Topic objects
        """
        instance_dir = self.get_instance_dir(instance_id)
        topics_file = instance_dir / "topics.yaml"

        data = {
            "topics": [topic.model_dump(exclude_none=True, by_alias=True) for topic in topics]
        }

        with open(topics_file, "w", encoding="utf-8") as f:
            yaml.safe_dump(data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)

    # ==================== Consumer Group Config ====================

    def load_consumer_groups(self, instance_id: str) -> List[ConsumerGroup]:
        """
        Load consumer groups from YAML file

        Args:
            instance_id: The instance ID

        Returns:
            List of ConsumerGroup objects
        """
        instance_dir = self.get_instance_dir(instance_id)
        groups_file = instance_dir / "consumer_groups.yaml"

        if not groups_file.exists():
            return []

        with open(groups_file, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
            group_data = data.get("consumer_groups", [])
            return [ConsumerGroup(**group) for group in group_data]

    def save_consumer_groups(self, instance_id: str, groups: List[ConsumerGroup]):
        """
        Save consumer groups to YAML file

        Args:
            instance_id: The instance ID
            groups: List of ConsumerGroup objects
        """
        instance_dir = self.get_instance_dir(instance_id)
        groups_file = instance_dir / "consumer_groups.yaml"

        data = {
            "consumer_groups": [group.model_dump(exclude_none=True) for group in groups]
        }

        with open(groups_file, "w", encoding="utf-8") as f:
            yaml.safe_dump(data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)

    # ==================== SASL User Config ====================

    def load_sasl_users(self, instance_id: str) -> List[SASLUser]:
        """
        Load SASL users from YAML file

        Args:
            instance_id: The instance ID

        Returns:
            List of SASLUser objects
        """
        instance_dir = self.get_instance_dir(instance_id)
        users_file = instance_dir / "sasl_users.yaml"

        if not users_file.exists():
            return []

        with open(users_file, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
            user_data = data.get("sasl_users", [])
            return [SASLUser(**user) for user in user_data]

    def save_sasl_users(self, instance_id: str, users: List[SASLUser]):
        """
        Save SASL users to YAML file

        Args:
            instance_id: The instance ID
            users: List of SASLUser objects
        """
        instance_dir = self.get_instance_dir(instance_id)
        users_file = instance_dir / "sasl_users.yaml"

        # Use mode='json' to properly convert Enum types to their string values
        data = {
            "sasl_users": [user.model_dump(exclude_none=True, mode='json') for user in users]
        }

        # Add header comment
        header_comment = """# SASL Users Configuration
#
# This file contains SASL user definitions with their ACL permissions.
# Passwords are not exported for security - use ${PASSWORD} placeholders.
#

"""

        with open(users_file, "w", encoding="utf-8") as f:
            f.write(header_comment)
            yaml.safe_dump(data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)

    # ==================== Instance Metadata ====================

    def load_instance_metadata(self, instance_id: str) -> Optional[InstanceMetadata]:
        """
        Load instance metadata from YAML file

        Args:
            instance_id: The instance ID

        Returns:
            InstanceMetadata object or None
        """
        instance_dir = self.get_instance_dir(instance_id)
        metadata_file = instance_dir / "metadata.yaml"

        if not metadata_file.exists():
            return None

        with open(metadata_file, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            if data:
                # New format: instance_id is the top-level key
                if instance_id in data:
                    metadata_dict = data[instance_id]
                    metadata_dict["instance_id"] = instance_id
                    return InstanceMetadata(**metadata_dict)
                # Old format (backward compatibility): instance_id is a field
                elif isinstance(data, dict) and "instance_id" in data:
                    return InstanceMetadata(**data)
        return None

    def save_instance_metadata(self, instance_id: str, metadata: InstanceMetadata):
        """
        Save instance metadata to YAML file

        Args:
            instance_id: The instance ID
            metadata: InstanceMetadata object
        """
        instance_dir = self.get_instance_dir(instance_id)
        metadata_file = instance_dir / "metadata.yaml"

        # Use instance_id as the top-level key
        data = {
            instance_id: metadata.model_dump(exclude_none=True, exclude={"instance_id"})
        }

        # Add header comment with schema disable
        header_comment = """# yaml-language-server: $schema=off
# Aliyun Kafka Instance Metadata
# This file contains instance metadata and configuration information
#

"""

        with open(metadata_file, "w", encoding="utf-8") as f:
            f.write(header_comment)
            yaml.safe_dump(
                data,
                f,
                default_flow_style=False,
                allow_unicode=True,
                sort_keys=False
            )

    # ==================== Instance Allowlist ====================

    def save_instance_allowlist(self, instance_id: str, allowlist: "InstanceAllowlist"):
        """
        Save instance allowlist to YAML file

        Args:
            instance_id: The instance ID
            allowlist: InstanceAllowlist object
        """
        from .models import InstanceAllowlist

        instance_dir = self.get_instance_dir(instance_id)
        allowlist_file = instance_dir / "allowlist.yaml"

        # Use instance_id as the top-level key
        data = {
            instance_id: allowlist.model_dump(exclude_none=True, exclude={"instance_id"})
        }

        # Add header comment
        header_comment = """# Allowlist Configuration
#
# This file contains IP allowlist (whitelist) configuration for different endpoint types.
# Each endpoint type includes the endpoint URL, port range, allowed IPs, and security group.
#

"""

        with open(allowlist_file, "w", encoding="utf-8") as f:
            f.write(header_comment)
            yaml.safe_dump(
                data,
                f,
                default_flow_style=False,
                allow_unicode=True,
                sort_keys=False
            )

    def load_instance_allowlist(self, instance_id: str) -> Optional["InstanceAllowlist"]:
        """
        Load instance allowlist from YAML file

        Args:
            instance_id: The instance ID

        Returns:
            InstanceAllowlist object or None
        """
        from .models import InstanceAllowlist

        instance_dir = self.get_instance_dir(instance_id)
        allowlist_file = instance_dir / "allowlist.yaml"

        if not allowlist_file.exists():
            return None

        with open(allowlist_file, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            if data and instance_id in data:
                allowlist_dict = data[instance_id]
                allowlist_dict["instance_id"] = instance_id
                return InstanceAllowlist(**allowlist_dict)
        return None
