import pytest

from dlubal.api import geo_zone_tool

from tests import testdata


@pytest.mark.integration
class TestGetGeoLocations:
    @pytest.mark.parametrize("address", testdata.ADDRESS_CASES)
    def test_get_geo_locations_returns_locations(self, geozone_token, address):
        """Get geo locations for a given address or coordinates."""
        result = geo_zone_tool.get_geo_locations(
            geozone_token,
            address,
            testdata.LANGUAGE_EN,
        )

        assert result is not None
        assert result.locations is not None
        assert len(result.locations) > 0

    def test_get_geo_locations_for_coords_returns_location_with_valid_lat_lon(
        self,
        geozone_token,
    ):
        """Geo locations for '52.0 13.0' should return at least one location."""
        result = geo_zone_tool.get_geo_locations(
            geozone_token,
            testdata.COORDS_52_13,
            testdata.LANGUAGE_EN,
        )

        assert result is not None
        assert result.locations is not None
        assert len(result.locations) > 0

        loc = result.locations[0]

        assert getattr(loc, "displayName", "")  # non-empty-ish
        assert getattr(loc, "country", "") or getattr(loc, "country_code", "")

        lat = float(loc.latitude)
        lon = float(loc.longitude)
        assert -90.0 <= lat <= 90.0
        assert -180.0 <= lon <= 180.0


class TestGetUserData:
    def test_get_user_data_empty_token_raises_value_error(self):
        with pytest.raises(ValueError, match="token must not be empty"):
            geo_zone_tool.get_user_data("")

    @pytest.mark.integration
    def test_get_user_data_returns_email_and_clicks(self, geozone_token):
        result = geo_zone_tool.get_user_data(geozone_token)

        assert result is not None
        assert getattr(result, "email", "")
        assert int(getattr(result, "clicks", 0)) >= 0


@pytest.mark.integration
class TestGetLoadZoneStandards:
    def test_get_load_zone_standards_returns_types_standards_and_annexes(
        self,
        geozone_token,
    ):
        """Verify types -> standards -> annexes structure is present and non-empty."""
        result = geo_zone_tool.get_load_zone_standards(
            token=geozone_token,
            country_code=testdata.COUNTRY_CODE_DE,
            language=testdata.LANGUAGE_EN,
        )

        assert result is not None
        assert result.types is not None
        assert len(result.types) > 0

        group = result.types[0]
        assert getattr(group, "name", "")
        assert group.standards is not None
        assert len(group.standards) > 0

        std_group = group.standards[0]
        assert getattr(std_group, "name", "")
        assert std_group.annexes is not None
        assert len(std_group.annexes) > 0

    def test_get_load_zone_standards_cz_it_returns_layers_with_id_and_name(
        self,
        geozone_token,
    ):
        """For CZ/IT we should get at least one layer with a positive id and non-empty name."""
        result = geo_zone_tool.get_load_zone_standards(
            token=geozone_token,
            country_code=testdata.COUNTRY_CODE_CZ,
            language=testdata.LANGUAGE_IT,
        )

        assert result is not None
        assert result.types is not None
        assert len(result.types) > 0

        # Walk the nested response to find the first available layer.
        found_layer = None
        for loadzone_group in result.types:
            for std_group in loadzone_group.standards:
                for annex_group in std_group.annexes:
                    if annex_group.layers:
                        found_layer = annex_group.layers[0]
                        break
                if found_layer:
                    break
            if found_layer:
                break

        assert found_layer is not None, "Expected at least one layer in response"

        # Validate the layer has a positive id and a non-empty name.
        assert int(found_layer.id) > 0
        assert getattr(found_layer, "name", "")


@pytest.mark.integration
class TestGetLoadZoneCharacteristics:
    def test_get_load_zone_characteristics_de_returns_characteristics(
        self,
        geozone_token,
    ):
        """Get load zone characteristics for DE and validate key response fields."""
        result = geo_zone_tool.get_load_zone_characteristics(
            token=geozone_token,
            address=testdata.COORDS_52_13,
            load_zone_type=testdata.LOAD_ZONE_SNOW,
            standard=testdata.STANDARD_EN_1991_1_3,
            annex=testdata.ANNEX_DIN_EN_1991_1_3,
            layer_id=testdata.LAYER_ID_1,
            language=testdata.LANGUAGE_EN,
        )

        assert result is not None
        assert result.code == "OK"
        assert result.characteristics is not None
        assert len(result.characteristics) > 0

        item = result.characteristics[0]
        assert item.standard == testdata.STANDARD_EN_1991_1_3
        assert item.annex == testdata.ANNEX_DIN_EN_1991_1_3

        zone = item.zoneCharacteristics
        assert zone is not None
        if hasattr(zone, "characteristics") and len(zone.characteristics) > 0:
            characteristic = zone.characteristics[0]
            assert getattr(characteristic, "calculatedValue", "") or getattr(
                characteristic, "nameHtml", ""
            )

        geo = result.geoLocation
        assert getattr(geo, "latitude", "")
        assert getattr(geo, "longitude", "")


class TestGetLoadZoneScreenshot:
    @pytest.mark.parametrize(
        "override_kwargs, expected_message",
        testdata.SCREENSHOT_INVALID_CASES,
    )
    def test_get_load_zone_screenshot_invalid_inputs_raise_value_error(
        self,
        override_kwargs,
        expected_message,
    ):
        """Client-side validation rejects invalid inputs before GraphQL is called."""
        base_kwargs = testdata._screenshot_invalid_base_kwargs(**override_kwargs)

        with pytest.raises(ValueError, match=expected_message):
            geo_zone_tool.get_load_zone_screenshot(**base_kwargs)

    @pytest.mark.integration
    @pytest.mark.parametrize("extra_kwargs", testdata.SCREENSHOT_EXTRA_KWARGS)
    def test_get_load_zone_screenshot_returns_non_empty_screenshot(
        self,
        geozone_token,
        extra_kwargs,
    ):
        """Get load zone screenshot and ensure it returns a non-empty payload."""
        base_kwargs = testdata._screenshot_base_kwargs(geozone_token)
        base_kwargs.update(extra_kwargs)

        result = geo_zone_tool.get_load_zone_screenshot(**base_kwargs)

        assert result is not None
        assert getattr(result, "screenshot", "")


class TestGetLoadZonePdf:
    @pytest.mark.parametrize(
        "override_kwargs, expected_message",
        testdata.PDF_INVALID_CASES,
    )
    def test_get_load_zone_pdf_invalid_inputs_raise_value_error(
        self,
        override_kwargs,
        expected_message,
    ):
        """Client-side validation rejects invalid inputs before GraphQL is called."""
        base_kwargs = testdata._pdf_invalid_base_kwargs(**override_kwargs)

        with pytest.raises(ValueError, match=expected_message):
            geo_zone_tool.get_load_zone_pdf(**base_kwargs)

    @pytest.mark.integration
    def test_get_load_zone_pdf_stream_returns_progress_messages(self, geozone_token):
        """Consume the progress stream and ensure it yields progress messages."""
        stream = geo_zone_tool.get_load_zone_pdf(
            **testdata._pdf_base_kwargs(geozone_token)
        )

        messages = list(stream)

        assert len(messages) > 0
        first = messages[0]
        assert getattr(first, "message", "") or getattr(first, "currentStep", 0) >= 0


@pytest.mark.integration
class TestGetLoadZonePdfResult:
    def test_get_load_zone_pdf_result_returns_pdf(self, geozone_token):
        """Return final PDF result from the progress stream."""
        result = geo_zone_tool.get_load_zone_pdf_result(
            **testdata._pdf_base_kwargs(geozone_token)
        )

        assert result is not None
        assert getattr(result, "pdf", "")
        assert getattr(result, "name", "")
