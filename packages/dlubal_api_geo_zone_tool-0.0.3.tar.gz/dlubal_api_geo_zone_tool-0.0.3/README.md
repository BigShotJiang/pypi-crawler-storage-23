# dlubal.api.geo_zone_tool

Python client for the Dlubal GeoZone GraphQL API.

Python `>=3.11` is required.

## Installation

```bash
pip install dlubal.api.geo_zone_tool
```

## Quick Start

```python
from dlubal.api import geo_zone_tool

token = "<your-token>"

locations = geo_zone_tool.get_geo_locations(
    token=token,
    address="Flugplatzweg 6, 14913, Germany",
    language=geo_zone_tool.Language.EN,
)

print(f"Found {len(locations.locations)} location(s)")
```

## Documentation

- User guide: `docs/USER_GUIDE.md`
- Developer guide: `docs/DEVELOPER_GUIDE.md`

## API Overview

- `get_geo_locations`
- `get_user_data`
- `get_load_zone_standards`
- `get_load_zone_characteristics`
- `get_load_zone_screenshot`
- `get_load_zone_pdf`
- `get_load_zone_pdf_result`

## PyPI Description (Markdown)

PyPI project description is rendered from `README.md` because
`pyproject.toml` contains:

```toml
[project]
readme = "README.md"
```

How to publish Markdown description updates:

1. Update `README.md`.
2. Build artifacts:

```bash
python -m pip install -U build twine
python -m build
python -m twine check dist/*
```

3. Upload:
   - TestPyPI: `python -m twine upload --repository testpypi dist/*`
   - PyPI: `python -m twine upload dist/*`

## Errors

The client can raise:

- `ValueError` for invalid input values.
- `TypeError` for invalid enum parameters.
- `RuntimeError` for GraphQL or WebSocket subscription errors.
- `requests.HTTPError` for HTTP response errors.
