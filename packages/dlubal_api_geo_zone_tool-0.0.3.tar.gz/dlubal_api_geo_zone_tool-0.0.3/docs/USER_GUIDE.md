# User Guide

This guide is for developers who consume `dlubal.api.geo_zone_tool` in their
applications.

## Install

```bash
pip install dlubal.api.geo_zone_tool
```

## Authentication

Every API call requires a valid GeoZone token.

```python
TOKEN = "<your-token>"
```

## Import

```python
from dlubal.api import geo_zone_tool
```

## Common Enums

- `geo_zone_tool.Language` (`EN`, `DE`, `IT`, ...)
- `geo_zone_tool.LoadZoneType` (`SNOW`, `WIND`, `EARTHQUAKE`, `TORNADO`)
- `geo_zone_tool.ScreenshotType` (`PNG`, `JPEG`)

## Examples

### Find Locations

```python
from dlubal.api import geo_zone_tool

locations = geo_zone_tool.get_geo_locations(
    token="<your-token>",
    address="Flugplatzweg 6, 14913, Germany",
    language=geo_zone_tool.Language.EN,
)

for loc in locations.locations:
    print(loc)
```

### Get User Info

```python
from dlubal.api import geo_zone_tool

user = geo_zone_tool.get_user_data(token="<your-token>")
print(user)
```

### Get Available Standards

```python
from dlubal.api import geo_zone_tool

standards = geo_zone_tool.get_load_zone_standards(
    token="<your-token>",
    country_code="DE",
    language=geo_zone_tool.Language.EN,
)

for group in standards.types:
    print(group.name)
```

### Get Load Zone Characteristics

```python
from dlubal.api import geo_zone_tool

result = geo_zone_tool.get_load_zone_characteristics(
    token="<your-token>",
    address="Flugplatzweg 6, 14913, Germany",
    load_zone_type=geo_zone_tool.LoadZoneType.SNOW,
    standard="EN 1991-1-3",
    annex="DIN EN 1991-1-3",
    layer_id=1,
    language=geo_zone_tool.Language.EN,
)

print(result)
```

### Get Screenshot (Base64)

```python
from dlubal.api import geo_zone_tool

screenshot = geo_zone_tool.get_load_zone_screenshot(
    token="<your-token>",
    address="Flugplatzweg 6, 14913, Germany",
    load_zone_type=geo_zone_tool.LoadZoneType.SNOW,
    standard="EN 1991-1-3",
    annex="DIN EN 1991-1-3",
    layer_id=1,
    zoom=6,
    screenshot_type=geo_zone_tool.ScreenshotType.JPEG,
    screenshot_quality=80,
)

print(screenshot.screenshot[:40])  # base64 prefix
```

### Stream PDF Progress

```python
from dlubal.api import geo_zone_tool

for msg in geo_zone_tool.get_load_zone_pdf(
    token="<your-token>",
    address="Flugplatzweg 6, 14913, Germany",
    standard="EN 1991-1-3",
    annex="DIN EN 1991-1-3",
    layer_id=1,
):
    print(msg.progress_message, msg.state)
```

### Get Final PDF (Base64)

```python
from dlubal.api import geo_zone_tool

pdf_result = geo_zone_tool.get_load_zone_pdf_result(
    token="<your-token>",
    address="Flugplatzweg 6, 14913, Germany",
    standard="EN 1991-1-3",
    annex="DIN EN 1991-1-3",
    layer_id=1,
)

if pdf_result is not None:
    print("PDF ready")
```

## Error Behavior

- `ValueError`: empty strings, negative numeric values.
- `TypeError`: wrong enum type used in function call.
- `RuntimeError`: GraphQL response errors or WebSocket subscription errors.
- `requests.HTTPError`: HTTP transport failures.

## API Endpoint

The package targets:

- `https://api-gateway.dlubal.com/geo-zone/pub/graphql`
