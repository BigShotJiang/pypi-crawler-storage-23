# GraphQL connection settings
GEO_ZONE_GRAPHQL_URL = "https://api-gateway.dlubal.com/geo-zone/pub/graphql"

# Service metadata
AUTHORIZATION_HEADER = "Authorization"
