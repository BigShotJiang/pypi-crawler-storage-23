GET_GEO_LOCATIONS_QUERY = """
query GetGeoLocations($address: String!, $sortCountryCode: String, $language: LanguageEnum = EN) {
  getGeoLocations(address: $address, sortCountryCode: $sortCountryCode, language: $language) {
    altitude
    latitude
    longitude
    displayName
    street
    zip
    city
    country
    state
    countryCode
  }
}
"""

GET_USER_DATA_QUERY = """
query GetUserData {
  getUserData {
    email
    clicks
  }
}
"""

GET_LOAD_ZONE_STANDARDS_QUERY = """
query GetLoadZoneStandards($countryCode: String!, $language: LanguageEnum = EN) {
  getLoadZoneStandards(countryCode: $countryCode, language: $language) {
    name
    standards {
      name
      annexes {
        name
        actual
        layers {
          id
          name
        }
      }
    }
  }
}
"""

GET_ZONE_CHARACTERISTICS_QUERY = """
query GetZoneCharacteristics($input: CharacteristicsInput4!, $language: LanguageEnum = EN) {
  getLoadZoneCharacteristics(input: $input, language: $language) {
    code
    message
    noLiability
    geoLocation {
      altitude
      latitude
      longitude
      street
      zip
      city
      country
      state
      countryCode
    }
    characteristics {
      standard
      annex
      zoneCharacteristics {
        id
        zone { value }
        characteristics {
          name
          calculatedValue
          nameHtml
          unitsHtml
          description
          decimalPlaces
          sequence
        }
      }
    }
  }
}
"""

GET_LOAD_ZONE_SCREENSHOT_QUERY = """
query GetLoadZoneScreenshot($input: GetLoadzoneScreenshotPublicInput!, $language: LanguageEnum = EN) {
  getLoadZoneScreenshot(input: $input, language: $language)
}
"""

GET_PDF_SUBSCRIPTION = """
subscription GetPdf($pdfInput: GetLoadzonePdfInput!, $language: LanguageEnum = EN) {
  getPdf(pdfInput: $pdfInput, language: $language) {
    message
    currentStep
    steps
    pdfResult {
      name
      pdf
    }
  }
}
"""
