from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class GeoLocation:
    altitude: str
    latitude: str
    longitude: str
    displayName: str | None = None
    street: str | None = None
    zip: str | None = None
    city: str | None = None
    country: str | None = None
    state: str | None = None
    countryCode: str | None = None

    @property
    def country_code(self) -> str | None:
        return self.countryCode

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "GeoLocation":
        return GeoLocation(
            altitude=str(data.get("altitude", "")),
            latitude=str(data.get("latitude", "")),
            longitude=str(data.get("longitude", "")),
            displayName=data.get("displayName"),
            street=data.get("street"),
            zip=data.get("zip"),
            city=data.get("city"),
            country=data.get("country"),
            state=data.get("state"),
            countryCode=data.get("countryCode"),
        )


@dataclass(frozen=True)
class GeoLocations:
    locations: list[GeoLocation]


@dataclass(frozen=True)
class UserData:
    email: str
    clicks: int

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "UserData":
        return UserData(
            email=str(data.get("email", "")),
            clicks=int(data.get("clicks", 0)),
        )


@dataclass(frozen=True)
class LoadzoneLayerShortType:
    id: int
    name: str | None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "LoadzoneLayerShortType":
        return LoadzoneLayerShortType(
            id=int(data.get("id", 0)),
            name=data.get("name") or data.get("layerName"),
        )


@dataclass(frozen=True)
class AnnexGroupType:
    name: str
    layers: list[LoadzoneLayerShortType]
    actual: bool | None = None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "AnnexGroupType":
        layers = [
            LoadzoneLayerShortType.from_dict(item)
            for item in data.get("layers", [])
        ]
        return AnnexGroupType(
            name=str(data.get("name", "")),
            layers=layers,
            actual=bool(data["actual"]) if data.get("actual") is not None else None,
        )


@dataclass(frozen=True)
class StandardGroupType:
    name: str
    annexes: list[AnnexGroupType]
    countryCode: str | None = None
    countryName: str | None = None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "StandardGroupType":
        country = data.get("country") or {}
        annexes = [AnnexGroupType.from_dict(item) for item in data.get("annexes", [])]
        return StandardGroupType(
            name=str(data.get("name", "")),
            annexes=annexes,
            countryCode=country.get("countryCode"),
            countryName=country.get("name"),
        )


@dataclass(frozen=True)
class LoadzoneGroupType:
    name: str
    standards: list[StandardGroupType]

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "LoadzoneGroupType":
        standards = [
            StandardGroupType.from_dict(item)
            for item in data.get("standards", [])
        ]
        return LoadzoneGroupType(
            name=str(data.get("type", "")) or str(data.get("name", "")),
            standards=standards,
        )


@dataclass(frozen=True)
class LoadZoneTypes:
    types: list[LoadzoneGroupType]


@dataclass(frozen=True)
class StandardType:
    id: int
    name: str

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "StandardType":
        return StandardType(
            id=int(data.get("id", 0)),
            name=str(data.get("name", "")),
        )


@dataclass(frozen=True)
class AnnexType:
    id: int
    name: str

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "AnnexType":
        return AnnexType(
            id=int(data.get("id", 0)),
            name=str(data.get("name", "")),
        )


@dataclass(frozen=True)
class CharacteristicsZoneType:
    value: str
    id: int | None = None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "CharacteristicsZoneType":
        return CharacteristicsZoneType(
            id=int(data["id"]) if data.get("id") is not None else None,
            value=str(data.get("value", "")),
        )


@dataclass(frozen=True)
class CharacteristicsVariableType:
    name: str
    calculatedValue: str | None
    nameHtml: str
    unitsHtml: str
    description: str
    decimalPlaces: int
    sequence: int

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "CharacteristicsVariableType":
        return CharacteristicsVariableType(
            name=str(data.get("name", "")),
            calculatedValue=data.get("calculatedValue"),
            nameHtml=str(data.get("nameHtml", "")),
            unitsHtml=str(data.get("unitsHtml", "")),
            description=str(data.get("description", "")),
            decimalPlaces=int(data.get("decimalPlaces", 0)),
            sequence=int(data.get("sequence", 0)),
        )


@dataclass(frozen=True)
class CharacteristicsLayerType:
    id: int
    zone: CharacteristicsZoneType
    characteristics: list[CharacteristicsVariableType]
    loadzoneId: str | None = None
    standard: StandardType | None = None
    annex: AnnexType | None = None
    layerId: int | None = None
    notes: str | None = None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "CharacteristicsLayerType":
        layer_id = data.get("id", data.get("layerId", 0))
        standard_data = data.get("standard")
        annex_data = data.get("annex")
        return CharacteristicsLayerType(
            id=int(layer_id),
            zone=CharacteristicsZoneType.from_dict(data.get("zone") or {}),
            characteristics=[
                CharacteristicsVariableType.from_dict(item)
                for item in data.get("characteristics", [])
            ],
            loadzoneId=(
                str(data.get("loadzoneId", ""))
                if data.get("loadzoneId") is not None
                else None
            ),
            standard=(
                StandardType.from_dict(standard_data) if standard_data else None
            ),
            annex=AnnexType.from_dict(annex_data) if annex_data else None,
            layerId=int(data["layerId"]) if data.get("layerId") is not None else None,
            notes=data.get("notes"),
        )


@dataclass(frozen=True)
class CharacteristicsLoadzoneType2:
    standard: str
    annex: str
    zoneCharacteristics: CharacteristicsLayerType
    loadzoneId: str | None = None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "CharacteristicsLoadzoneType2":
        return CharacteristicsLoadzoneType2(
            standard=str(data.get("standard", "")),
            annex=str(data.get("annex", "")),
            zoneCharacteristics=CharacteristicsLayerType.from_dict(
                data.get("zoneCharacteristics") or {}
            ),
            loadzoneId=(
                str(data.get("loadzoneId", ""))
                if data.get("loadzoneId") is not None
                else None
            ),
        )


@dataclass(frozen=True)
class CharacteristicsResponseMiaType:
    code: str
    message: str | None
    geoLocation: GeoLocation | None
    characteristics: list[CharacteristicsLoadzoneType2]
    noLiability: str | None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "CharacteristicsResponseMiaType":
        geo = data.get("geoLocation")
        return CharacteristicsResponseMiaType(
            code=str(data.get("code", "")),
            message=data.get("message"),
            geoLocation=GeoLocation.from_dict(geo) if geo else None,
            characteristics=[
                CharacteristicsLoadzoneType2.from_dict(item)
                for item in data.get("characteristics", [])
            ],
            noLiability=data.get("noLiability"),
        )


@dataclass(frozen=True)
class Screenshot:
    screenshot: str


@dataclass(frozen=True)
class PdfResultType:
    name: str
    pdf: str

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "PdfResultType":
        return PdfResultType(
            name=str(data.get("name", "")),
            pdf=str(data.get("pdf", "")),
        )


@dataclass(frozen=True)
class PdfProgressType:
    message: str
    currentStep: int
    steps: int
    pdfResult: PdfResultType | None

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "PdfProgressType":
        pdf_result = data.get("pdfResult")
        return PdfProgressType(
            message=str(data.get("message", "")),
            currentStep=int(data.get("currentStep", 0)),
            steps=int(data.get("steps", 0)),
            pdfResult=PdfResultType.from_dict(pdf_result) if pdf_result else None,
        )
