"""Setup script for jira-status-updater."""

from setuptools import setup

# Read the contents of README.md
with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="jira-ticket-updater",
    version="1.0.9",
    description="A command-line tool for updating Jira ticket status",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Pandiyaraj Karuppasamy",
    author_email="pandiyarajk@live.com",
    packages=["jira_ticket_updater"],
    package_dir={"": "src"},
    include_package_data=True,
    install_requires=[
        "requests>=2.25.0",
    ],
    entry_points={
        "console_scripts": [
            "jira-ticket-updater=jira_ticket_updater.main:main",
        ],
    },
    python_requires=">=3.8",
    keywords="jira status-update automation devops workflow",
)
