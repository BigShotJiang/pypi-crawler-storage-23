"""Jira Issue Intelligence - Advanced analysis and reporting for Jira issues."""

import re
from collections import Counter
from datetime import datetime


class JiraIssueIntelligence:

    # =====================================================
    # ENTRY POINT
    # =====================================================
    def analyze_issue(self, issue: dict):

        comments = issue.get("comments", [])
        if not comments:
            return "No comments found."

        # -------------------------
        # BASIC ISSUE INFO
        # -------------------------
        issue_key = issue.get("issue_key")
        summary = issue.get("summary")
        status = issue.get("status")
        sprint = issue.get("sprint")
        story_points = issue.get("story_points")
        priority = issue.get("priority")
        implementor = issue.get("implementor")
        reviewer = issue.get("reviewer")
        time_spent = issue.get("time_spent")
        original_estimate = issue.get("original_estimate")

        # -------------------------
        # COMMENT ANALYSIS
        # -------------------------
        contributors = Counter()
        timestamps = []
        merges = 0
        tag_changes = 0
        fixes = 0
        refactors = 0
        workflow_changes = 0
        email_changes = 0
        deletions = 0
        testcase_refs = set()

        for c in comments:
            author = c["author"]
            body = c["body"].lower()
            created = self.parse_datetime(c["created"])

            contributors[author] += 1
            timestamps.append(created)

            if "merge branch" in body:
                merges += 1

            if "@batch" in body or "tag moved" in body:
                tag_changes += 1

            if "fix applied" in body or "script fix" in body:
                fixes += 1

            if any(k in body for k in ["refactor", "cleanup", "unused", "remove"]):
                refactors += 1

            if ".yml" in body or "workflow" in body or "external-trigger" in body:
                workflow_changes += 1

            if "email" in body:
                email_changes += 1

            if "delete" in body:
                deletions += 1

            found = re.findall(r"\bT\d+\b", body.upper())
            for t in found:
                testcase_refs.add(t)

        duration_days = max((max(timestamps) - min(timestamps)).days, 1)

        # -------------------------
        # EFFORT ANALYSIS
        # -------------------------
        spent_hours = self.parse_time_to_hours(time_spent)
        estimated_hours = self.parse_time_to_hours(original_estimate)

        estimation_variance = round(spent_hours - estimated_hours, 2)
        estimation_ratio = round(spent_hours / estimated_hours, 2) if estimated_hours else 0

        # -------------------------
        # PRODUCTIVITY METRICS
        # -------------------------
        productivity_score = (
            len(testcase_refs) * 3 +
            merges +
            tag_changes +
            fixes * 2 +
            refactors * 2 +
            workflow_changes * 3 +
            email_changes * 2
        )

        # -------------------------
        # REPORT BUILDING
        # -------------------------
        report = []
        report.append("=" * 110)
        report.append("🏢 JIRA ISSUE INTELLIGENCE REPORT")
        report.append("=" * 110)

        report.append(f"\n🎯 Issue: {issue_key}")
        report.append(f"Summary: {summary}")
        report.append(f"Status: {status}")
        report.append(f"Sprint: {sprint}")
        report.append(f"Priority: {priority}")
        report.append(f"Story Points: {story_points}")

        report.append("\n👤 OWNERSHIP")
        report.append(f"Implementor: {implementor}")
        report.append(f"Reviewer: {reviewer}")
        report.append(f"Total Contributors: {len(contributors)}")
        for name, count in contributors.most_common():
            report.append(f"  - {name}: {count} updates")

        report.append("\n⏱ EFFORT ANALYSIS")
        report.append(f"Original Estimate: {original_estimate} ({estimated_hours} hrs)")
        report.append(f"Actual Time Spent: {time_spent} ({spent_hours} hrs)")
        report.append(f"Variance (hrs): {estimation_variance}")
        report.append(f"Effort Ratio (Actual / Estimate): {estimation_ratio}x")

        if estimation_ratio > 2:
            effort_status = "⚠ Significant Effort Variance (Scope Expanded)"
        elif estimation_ratio > 1:
            effort_status = "⚠ Moderate Effort Variance"
        elif estimation_ratio == 1:
            effort_status = "✅ Accurate Estimation"
        else:
            effort_status = "✅ Completed Below Estimate"

        report.append(f"Estimation Health: {effort_status}")

        report.append("\n🔄 DEVELOPMENT ACTIVITY")
        report.append(f"Duration: {duration_days} days")
        report.append(f"Total Comments: {len(comments)}")
        report.append(f"Merges: {merges}")
        report.append(f"Tag Updates: {tag_changes}")
        report.append(f"Fixes Applied: {fixes}")
        report.append(f"Refactors/Cleanup: {refactors}")
        report.append(f"Workflow Changes: {workflow_changes}")
        report.append(f"Email Script Changes: {email_changes}")
        report.append(f"Deletions: {deletions}")

        report.append("\n🧪 TEST IMPACT")
        report.append(f"Unique Testcases Impacted: {len(testcase_refs)}")
        if testcase_refs:
            report.append(", ".join(sorted(testcase_refs)))

        report.append("\n📊 PRODUCTIVITY SCORE")
        report.append(f"Engineering Impact Score: {productivity_score}")

        if productivity_score > 100:
            level = "🚀 Enterprise Scale Impact"
        elif productivity_score > 50:
            level = "🔥 High Impact Ticket"
        else:
            level = "⚙ Standard Impact"

        report.append(f"Impact Level: {level}")

        metrics = {
            "spent_hours": spent_hours,
            "estimated_hours": estimated_hours,
            "estimation_ratio": estimation_ratio,
            "merges": merges,
            "fixes": fixes,
            "refactors": refactors,
            "workflow_changes": workflow_changes,
            "tag_changes": tag_changes,
            "testcase_count": len(testcase_refs),
            "comment_count": len(comments),
            "contributors": contributors
        }

        root_causes = self.analyze_estimation_root_cause(issue, metrics)
        report.append("\n🧠 ROOT-CAUSE ANALYSIS FOR ESTIMATION VARIANCE")
        for idx, cause in enumerate(root_causes, 1):
            report.append(f"{idx}. {cause}")

        report.append("\n🧾 EXECUTIVE SUMMARY")
        report.append(
            f"{issue_key} was completed in {duration_days} days under sprint '{sprint}'. "
            f"It involved {len(testcase_refs)} testcases, {merges} merges, "
            f"and multiple automation improvements including permission handling, "
            f"tag migration, validation enhancements, workflow stabilization, "
            f"and regression script fixes. "
            f"Effort ratio was {estimation_ratio}x against estimate. "
            f"Overall impact classified as {level}."
        )

        report.append("\n" + "=" * 110)

        return "\n".join(report)

    # =====================================================
    # UTILITIES
    # =====================================================
    def parse_datetime(self, dt_str):
        dt_str = re.sub(r'([+-]\d{2})(\d{2})$', r'\1:\2', dt_str)
        return datetime.fromisoformat(dt_str)

    def parse_time_to_hours(self, time_str):
        if not time_str:
            return 0

        days = re.search(r"(\d+)d", time_str)
        hours = re.search(r"(\d+)h", time_str)
        minutes = re.search(r"(\d+)m", time_str)

        total = 0
        if days:
            total += int(days.group(1)) * 8
        if hours:
            total += int(hours.group(1))
        if minutes:
            total += int(minutes.group(1)) / 60

        return round(total, 2)

    def analyze_estimation_root_cause(self, issue, metrics):
        """
        Performs intelligent root-cause analysis for estimation variance.
        
        Args:
            issue: Issue dictionary (reserved for future use)
            metrics: Dictionary containing analysis metrics
        """
        # Extract metrics for analysis
        estimation_ratio = metrics["estimation_ratio"]

        merges = metrics["merges"]
        fixes = metrics["fixes"]
        refactors = metrics["refactors"]
        workflow_changes = metrics["workflow_changes"]
        tag_changes = metrics["tag_changes"]
        testcase_count = metrics["testcase_count"]
        comment_count = metrics["comment_count"]
        contributors = metrics["contributors"]

        causes = []

        # ---------------------------------------
        # 1️⃣ Scope Expansion Detection
        # ---------------------------------------
        if tag_changes > 5 or testcase_count > 10:
            causes.append("Scope Expansion: Large number of tag migrations or testcase modifications.")

        # ---------------------------------------
        # 2️⃣ Regression Stabilization Detection
        # ---------------------------------------
        if fixes > 3:
            causes.append("Regression Stabilization: Multiple script fixes applied during development.")

        # ---------------------------------------
        # 3️⃣ Workflow / CI Instability
        # ---------------------------------------
        if workflow_changes > 2:
            causes.append("CI/Workflow Hardening: Pipeline configuration changes increased effort.")

        # ---------------------------------------
        # 4️⃣ Technical Debt / Refactor Impact
        # ---------------------------------------
        if refactors > 3:
            causes.append("Technical Debt Cleanup: Refactoring and cleanup increased development time.")

        # ---------------------------------------
        # 5️⃣ High Merge Density
        # ---------------------------------------
        if merges > 8:
            causes.append("High Merge Activity: Frequent branch merges indicate parallel changes or instability.")

        # ---------------------------------------
        # 6️⃣ Collaboration Overhead
        # ---------------------------------------
        if len(contributors) > 3:
            causes.append("Multi-Contributor Coordination Overhead.")

        # ---------------------------------------
        # 7️⃣ Communication Amplification
        # ---------------------------------------
        if comment_count > 40:
            causes.append("High Communication Volume: Significant discussion and iteration.")

        # ---------------------------------------
        # 8️⃣ Severe Underestimation Flag
        # ---------------------------------------
        if estimation_ratio > 3:
            causes.append("Initial Story Sizing Inaccurate: Complexity underestimated at planning stage.")

        if not causes:
            causes.append("Minor variance due to natural implementation overhead.")

        return causes
