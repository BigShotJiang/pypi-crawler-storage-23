"""Webhook verification for Sema SDK."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import re
import time

from sema_sdk.exceptions import WebhookVerificationError
from sema_sdk.types import WebhookEvent, WebhookPayload

DEFAULT_TOLERANCE_SECONDS = 300  # 5 minutes


class WebhookVerifier:
    """
    Verifier for Sema webhooks using Standard Webhooks signature format.

    Example:
        ```python
        verifier = WebhookVerifier(secret="whsec_...")

        # In your webhook handler:
        try:
            event = verifier.verify(request.body, request.headers)
            print(f"Received event {event.webhook_id} for item {event.payload.item_id}")
            # Use event.webhook_id as idempotency key
        except WebhookVerificationError as e:
            return Response(status=400, body=str(e))
        ```
    """

    def __init__(
        self,
        secret: str,
        tolerance_seconds: int = DEFAULT_TOLERANCE_SECONDS,
    ) -> None:
        """
        Initialize the webhook verifier.

        Args:
            secret: Webhook secret (format: whsec_... or raw base64).
            tolerance_seconds: Maximum age of webhook in seconds. Defaults to 300 (5 minutes).
        """
        self._secret_bytes = self._decode_secret(secret)
        self._tolerance_seconds = tolerance_seconds

    @staticmethod
    def _decode_secret(secret: str) -> bytes:
        """Decode the webhook secret to bytes."""
        raw = secret.strip()
        if not raw:
            raise WebhookVerificationError("Webhook secret cannot be empty")

        def normalize_base64_for_decode(s: str) -> tuple[str, bool]:
            if not s:
                return s, False

            # Allow both standard base64 (+/) and base64url (-_). Padding is optional.
            is_url_safe = "-" in s or "_" in s
            pattern = r"^[A-Za-z0-9\-_]+={0,2}$" if is_url_safe else r"^[A-Za-z0-9+/]+={0,2}$"
            if re.fullmatch(pattern, s) is None:
                return s, False

            # Reject impossible lengths. (mod 4 == 1 can't be valid base64 data.)
            mod = len(s) % 4
            if mod == 1:
                return s, False

            # Convert base64url -> base64 for decoding.
            normalized = s.replace("-", "+").replace("_", "/") if is_url_safe else s

            # Add padding if missing.
            if mod == 2:
                normalized += "=="
            elif mod == 3:
                normalized += "="

            return normalized, True

        if raw.startswith("whsec_"):
            candidate = raw[6:]
            normalized, is_b64 = normalize_base64_for_decode(candidate)
            if not is_b64:
                raise WebhookVerificationError(
                    "Invalid webhook secret: whsec_ secrets must contain base64 after the prefix"
                )
            try:
                return base64.b64decode(normalized, validate=True)
            except Exception as e:
                raise WebhookVerificationError(
                    "Invalid webhook secret: whsec_ secrets must contain base64 after the prefix"
                ) from e

        normalized, is_b64 = normalize_base64_for_decode(raw)
        if is_b64:
            try:
                return base64.b64decode(normalized, validate=True)
            except Exception:
                # Fall back to UTF-8 if it looks like base64 but isn't actually decodable
                return raw.encode("utf-8")

        return raw.encode("utf-8")

    def verify(
        self,
        payload: bytes | str,
        headers: dict[str, str],
    ) -> WebhookEvent:
        """
        Verify a webhook signature and parse the payload.

        Args:
            payload: Raw request body (bytes or string).
            headers: Request headers (case-insensitive keys supported).

        Returns:
            WebhookEvent containing webhook_id, timestamp, and parsed payload.

        Raises:
            WebhookVerificationError: If verification fails.
        """
        # Normalize headers to lowercase
        normalized_headers = {k.lower(): v for k, v in headers.items()}

        webhook_id = normalized_headers.get("webhook-id")
        webhook_timestamp = normalized_headers.get("webhook-timestamp")
        webhook_signature = normalized_headers.get("webhook-signature")

        if not webhook_id:
            raise WebhookVerificationError("Missing webhook-id header")
        if not webhook_timestamp:
            raise WebhookVerificationError("Missing webhook-timestamp header")
        if not webhook_signature:
            raise WebhookVerificationError("Missing webhook-signature header")

        # Parse and validate timestamp
        try:
            timestamp = int(webhook_timestamp)
        except ValueError as e:
            raise WebhookVerificationError("Invalid webhook-timestamp header") from e

        current_time = int(time.time())
        if abs(current_time - timestamp) > self._tolerance_seconds:
            raise WebhookVerificationError(
                f"Webhook timestamp too old (tolerance: {self._tolerance_seconds}s)"
            )

        # Normalize payload to string
        if isinstance(payload, bytes):
            payload_str = payload.decode("utf-8")
        else:
            payload_str = payload

        # Compute expected signature
        signed_content = f"{webhook_id}.{webhook_timestamp}.{payload_str}"
        expected_signature = base64.b64encode(
            hmac.new(
                self._secret_bytes,
                signed_content.encode("utf-8"),
                hashlib.sha256,
            ).digest()
        ).decode("ascii")

        # Check against provided signatures (may be multiple for key rotation)
        signature_valid = False
        for sig in webhook_signature.split(" "):
            if sig.startswith("v1,"):
                provided_sig = sig[3:]  # Remove "v1," prefix
                if hmac.compare_digest(expected_signature, provided_sig):
                    signature_valid = True
                    break

        if not signature_valid:
            raise WebhookVerificationError("Invalid webhook signature")

        # Parse payload
        try:
            payload_data = json.loads(payload_str)
            parsed_payload = WebhookPayload.model_validate(payload_data)
        except Exception as e:
            raise WebhookVerificationError(f"Failed to parse webhook payload: {e}") from e

        return WebhookEvent(
            webhook_id=webhook_id,
            timestamp=timestamp,
            payload=parsed_payload,
        )
