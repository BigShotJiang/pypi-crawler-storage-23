"""Exceptions for Sema SDK."""

from typing import Any


class SemaError(Exception):
    """Base exception for all Sema SDK errors."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class SemaAPIError(SemaError):
    """Error returned by the Sema API."""

    def __init__(
        self,
        message: str,
        status_code: int,
        response_body: dict[str, Any] | None = None,
    ) -> None:
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(message)

    def __str__(self) -> str:
        return f"{self.message} (status={self.status_code})"


class AuthenticationError(SemaAPIError):
    """Invalid or missing API key."""

    def __init__(
        self,
        message: str = "Invalid or missing API key",
        response_body: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, status_code=401, response_body=response_body)


class NotFoundError(SemaAPIError):
    """Resource not found."""

    def __init__(
        self,
        message: str = "Resource not found",
        response_body: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, status_code=404, response_body=response_body)


class RateLimitError(SemaAPIError):
    """Rate limit exceeded (429)."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        response_body: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, status_code=429, response_body=response_body)


class WebhookVerificationError(SemaError):
    """Webhook signature or timestamp validation failed."""

    pass
