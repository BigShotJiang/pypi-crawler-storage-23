"""Email utilities for processing HTML email content."""

from collections.abc import Sequence
from typing import Protocol, TypeVar


class AttachmentLike(Protocol):
    """Protocol for attachment objects with content_id and download_url."""

    content_id: str | None
    download_url: str | None


# TypeVar for preserving concrete attachment types in partition function
T = TypeVar("T", bound=AttachmentLike)


def partition_email_attachments(
    body_html: str, attachments: Sequence[T]
) -> tuple[list[T], list[T]]:
    """
    Partition attachments into inline and non-inline based on cid: references in HTML.

    Email clients like Gmail set content_id on ALL attachments, not just inline ones.
    This function checks if cid:{content_id} actually appears in the HTML body to
    correctly identify which attachments are truly inline.

    Args:
        body_html: HTML body content from the email (e.g., content_summary.body_html)
        attachments: List of attachments with content_id attribute.
            Typically from client.get_item_attachments(item_id).attachments

    Returns:
        Tuple of (inline, non_inline) attachment lists.
        - inline: Attachments whose cid: is referenced in the HTML
        - non_inline: Attachments to list separately (no content_id or not in HTML)

    Example:
        ```python
        from sema_sdk import SemaClient, partition_email_attachments

        client = SemaClient()

        # In your webhook handler:
        body_html = event.payload.deliverable.content_summary.body_html
        attachments = client.get_item_attachments(event.payload.item_id).attachments

        inline, non_inline = partition_email_attachments(body_html, attachments)

        # inline attachments are already displayed in the resolved HTML
        # non_inline attachments should be listed separately
        for att in non_inline:
            print(f"Attachment: {att.filename}")
        ```
    """
    if not body_html or not attachments:
        return [], list(attachments)

    # Find content_ids that are actually referenced in the HTML
    inline_cids: set[str] = set()
    for att in attachments:
        if att.content_id and f"cid:{att.content_id}" in body_html:
            inline_cids.add(att.content_id)

    # Partition based on whether content_id is in inline_cids
    inline: list[T] = []
    non_inline: list[T] = []
    for att in attachments:
        if att.content_id and att.content_id in inline_cids:
            inline.append(att)
        else:
            non_inline.append(att)

    return inline, non_inline


def resolve_email_inline_images(
    body_html: str | None, attachments: Sequence[AttachmentLike]
) -> str | None:
    """
    Replace cid: references in HTML email body with presigned download URLs.

    HTML emails embed inline images using Content-ID (cid:) references that point
    to MIME attachments. This function replaces those references with actual
    download URLs so the images display correctly outside an email client.

    Args:
        body_html: HTML body content from the email (e.g., content_summary.body_html).
            May be None when not present.
        attachments: List of attachments with content_id and download_url attributes.
            Typically from client.get_item_attachments(item_id).attachments

    Returns:
        HTML with cid: references replaced by download URLs (or None if body_html is None).
        References without matching attachments are left unchanged.

    Example:
        ```python
        from sema_sdk import SemaClient, resolve_email_inline_images

        client = SemaClient()

        # In your webhook handler:
        body_html = event.payload.deliverable.content_summary.body_html
        attachments = client.get_item_attachments(event.payload.item_id).attachments

        resolved_html = resolve_email_inline_images(body_html, attachments)
        ```
    """
    if not body_html:
        return body_html

    for att in attachments:
        if att.content_id and att.download_url:
            body_html = body_html.replace(f"cid:{att.content_id}", att.download_url)

    return body_html
