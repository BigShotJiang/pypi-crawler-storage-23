"""Sema SDK - Official Python SDK for Sema."""

from sema_sdk.client import AsyncSemaClient, SemaClient
from sema_sdk.email import partition_email_attachments, resolve_email_inline_images
from sema_sdk.exceptions import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    SemaAPIError,
    SemaError,
    WebhookVerificationError,
)
from sema_sdk.types import (
    AfterResponseHook,
    Attachment,
    AttachmentList,
    BeforeRequestHook,
    Delivery,
    DeliveryAttempt,
    Inbox,
    InboxList,
    Item,
    OnErrorHook,
    RequestContext,
    ResponseContext,
    WebhookEvent,
    WebhookPayload,
)
from sema_sdk.version import __version__
from sema_sdk.webhooks import WebhookVerifier

__all__ = [
    # Clients
    "SemaClient",  # Sync client (default)
    "AsyncSemaClient",  # Async client
    # Version
    "__version__",
    # Webhooks
    "WebhookVerifier",
    # Email utilities
    "partition_email_attachments",
    "resolve_email_inline_images",
    # Types
    "Attachment",
    "AttachmentList",
    "Inbox",
    "InboxList",
    "Item",
    "Delivery",
    "DeliveryAttempt",
    "WebhookEvent",
    "WebhookPayload",
    # Hooks
    "RequestContext",
    "ResponseContext",
    "BeforeRequestHook",
    "AfterResponseHook",
    "OnErrorHook",
    # Exceptions
    "SemaError",
    "SemaAPIError",
    "AuthenticationError",
    "NotFoundError",
    "RateLimitError",
    "WebhookVerificationError",
]
