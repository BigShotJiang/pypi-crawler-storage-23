"""Type definitions for Sema SDK."""

from collections.abc import Awaitable, Callable
from datetime import datetime
from typing import Any, Literal, TypedDict

from pydantic import BaseModel, ConfigDict, Field


class Inbox(BaseModel):
    """Inbox resource returned by the Sema API."""

    model_config = ConfigDict(frozen=True)

    id: str = Field(..., description="Unique inbox identifier")
    name: str = Field(..., description="Human-readable name")
    description: str | None = Field(None, description="Inbox description")

    owner_type: Literal["user", "organization"] = Field(..., description="Owner type")
    owner_id: str = Field(..., description="Owner ID")
    owner_name: str | None = Field(None, description="Owner's display name")
    owner_email: str | None = Field(None, description="Owner's email (for users)")

    email_enabled: bool = Field(..., description="Whether email receiving is enabled")
    email_address: str | None = Field(None, description="Email address for receiving")
    api_enabled: bool = Field(..., description="Whether API receiving is enabled")

    allowed_senders: list[str] = Field(default_factory=list, description="Allowed sender emails")
    allowed_domains: list[str] = Field(default_factory=list, description="Allowed sender domains")

    webhook_url: str | None = Field(None, description="Webhook URL for delivery")
    webhook_configured: bool = Field(..., description="Whether webhook is configured")
    payload_mode: Literal["full", "thin"] = Field(..., description="Webhook payload mode")

    is_active: bool = Field(..., description="Whether inbox accepts new items")
    item_count: int = Field(default=0, ge=0, description="Number of items in the inbox")

    created_at: datetime = Field(..., description="When the inbox was created")
    updated_at: datetime = Field(..., description="When the inbox was last updated")


class InboxList(BaseModel):
    """Response for listing inboxes."""

    model_config = ConfigDict(frozen=True)

    inboxes: list[Inbox] = Field(..., description="List of inboxes")
    total: int = Field(..., ge=0, description="Total number of inboxes")


class Item(BaseModel):
    """Item resource returned by the Sema API."""

    model_config = ConfigDict(frozen=True)

    id: str = Field(..., description="Unique item identifier")
    inbox_id: str = Field(..., description="Inbox that received the item")
    inbound_channel: Literal["api", "email"] = Field(..., description="Inbound channel")
    status: str = Field(..., description="Current item status")
    content_type: str = Field(..., description="MIME type of the content")
    size_bytes: int = Field(..., ge=0, description="Size of raw content in bytes")

    sender_address: str = Field(..., description="Sender's address")
    sender_display_name: str | None = Field(None, description="Sender's display name")
    sender_domain: str = Field(..., description="Sender's domain")

    subject: str | None = Field(None, description="Subject line")
    dedupe_key: str = Field(..., description="Deduplication key")

    auth_decision: str = Field(..., description="Authorization decision")
    auth_reasons: list[str] = Field(default_factory=list, description="Authorization reasons")

    received_at: datetime = Field(..., description="When the item was received")
    normalized_at: datetime | None = Field(None, description="When normalization completed")
    ready_at: datetime | None = Field(None, description="When the item became ready")
    created_at: datetime = Field(..., description="When the item was created")
    updated_at: datetime = Field(..., description="When the item was last updated")

    metadata: dict[str, Any] = Field(default_factory=dict, description="Custom metadata")


class CreateItemResponse(BaseModel):
    """Response after successfully creating an item."""

    model_config = ConfigDict(frozen=True)

    id: str = Field(..., description="Unique item identifier")
    inbox_id: str = Field(..., description="Inbox that received the item")
    inbound_channel: Literal["api", "email"] = Field(..., description="Inbound channel")
    status: str = Field(..., description="Current item status")
    content_type: str = Field(..., description="MIME type of the content")
    size_bytes: int = Field(..., ge=0, description="Size of raw content in bytes")
    dedupe_key: str = Field(..., description="Deduplication key")
    is_duplicate: bool = Field(..., description="True if this is a duplicate submission")
    created_at: datetime = Field(..., description="When the item was created")


class ItemList(BaseModel):
    """Response for listing items."""

    model_config = ConfigDict(frozen=True)

    items: list[Item] = Field(..., description="List of items")
    total: int = Field(..., ge=0, description="Total number of items")


class DeliveryAttempt(BaseModel):
    """A single delivery attempt."""

    model_config = ConfigDict(frozen=True)

    id: str = Field(..., description="Unique attempt identifier")
    attempt_number: int = Field(..., ge=1, description="Attempt number (1-based)")
    status_code: int | None = Field(None, description="HTTP status code")
    response_body: str | None = Field(None, description="Response body (truncated)")
    error_message: str | None = Field(None, description="Error message if failed")
    started_at: datetime = Field(..., description="When the attempt started")
    completed_at: datetime | None = Field(None, description="When the attempt completed")
    duration_ms: int | None = Field(None, ge=0, description="Duration in milliseconds")


class Delivery(BaseModel):
    """Delivery resource with attempts."""

    model_config = ConfigDict(frozen=True)

    id: str = Field(..., description="Unique delivery identifier")
    item_id: str = Field(..., description="Item being delivered")
    webhook_url: str = Field(..., description="Webhook URL target")
    status: str = Field(..., description="Delivery status")
    attempt_count: int = Field(..., ge=0, description="Number of attempts made")
    max_attempts: int = Field(..., ge=1, description="Maximum attempts allowed")
    last_error: str | None = Field(None, description="Last error message")
    succeeded_at: datetime | None = Field(None, description="When delivery succeeded")
    failed_at: datetime | None = Field(None, description="When delivery permanently failed")
    created_at: datetime = Field(..., description="When delivery was created")
    attempts: list[DeliveryAttempt] = Field(default_factory=list, description="Delivery attempts")


class DeliveryList(BaseModel):
    """Response for listing deliveries."""

    model_config = ConfigDict(frozen=True)

    deliveries: list[Delivery] = Field(..., description="List of deliveries")


class Attachment(BaseModel):
    """Attachment resource with presigned download URL."""

    model_config = ConfigDict(frozen=True)

    id: str = Field(..., description="Unique attachment identifier")
    filename: str = Field(..., description="Original filename")
    content_type: str = Field(..., description="MIME type of the attachment")
    size_bytes: int = Field(..., ge=0, description="Size in bytes")
    download_url: str | None = Field(None, description="Presigned download URL")
    content_id: str | None = Field(
        None, description="Content-ID for inline attachments (matches cid: references in HTML)"
    )
    created_at: datetime = Field(..., description="When the attachment was created")


class AttachmentList(BaseModel):
    """Response for listing attachments."""

    model_config = ConfigDict(frozen=True)

    attachments: list[Attachment] = Field(..., description="List of attachments")


# Webhook types


class WebhookSender(BaseModel):
    """Sender information in webhook payload."""

    model_config = ConfigDict(frozen=True)

    address: str = Field(..., description="Sender's email address")
    display_name: str | None = Field(None, description="Sender's display name")
    domain: str = Field(..., description="Sender's domain")
    verified: bool | None = Field(None, description="Whether sender is verified")


class WebhookAttachment(BaseModel):
    """Attachment information in webhook payload."""

    model_config = ConfigDict(frozen=True)

    filename: str = Field(..., description="Attachment filename")
    content_type: str = Field(..., description="MIME type")
    size_bytes: int = Field(..., ge=0, description="Size in bytes")
    ref: str = Field(..., description="Storage reference")
    content_id: str | None = Field(
        None, description="Content-ID for inline attachments (matches cid: references in body_html)"
    )


class WebhookContentSummary(BaseModel):
    """Content summary in webhook payload."""

    model_config = ConfigDict(frozen=True)

    subject: str | None = Field(None, description="Subject line")
    from_address: str | None = Field(None, alias="from", description="From address")
    to: list[str] | None = Field(None, description="To addresses")
    body_preview: str | None = Field(None, description="Body preview (plain text)")
    body_html: str | None = Field(
        None, description="Full HTML body with cid: references for inline images"
    )
    received_at: datetime | None = Field(None, description="When received")


class WebhookDeliverable(BaseModel):
    """Deliverable data in webhook payload."""

    model_config = ConfigDict(frozen=True, extra="allow")

    raw_ref: str = Field(..., description="Reference to raw item bytes")
    normalized_ref: str | None = Field(None, description="Reference to normalized item")
    sender: WebhookSender | None = Field(None, description="Sender info (full mode only)")
    content_summary: WebhookContentSummary | None = Field(
        None, description="Content summary (full mode only)"
    )
    attachments: list[WebhookAttachment] | None = Field(
        None, description="Attachments (full mode only)"
    )


class WebhookPayload(BaseModel):
    """Webhook payload envelope (v1)."""

    model_config = ConfigDict(frozen=True)

    schema_version: str = Field(..., description="Schema version")
    tenant_id: str = Field(..., description="Tenant identifier")
    inbox_id: str = Field(..., description="Inbox that received the item")
    item_id: str = Field(..., description="Unique item identifier")
    inbound_channel: Literal["api", "email"] = Field(..., description="Inbound channel")
    event_type: str = Field(..., description="Event type (e.g., ITEM_READY)")
    occurred_at: datetime = Field(..., description="When the event occurred")
    payload_mode: Literal["full", "thin"] = Field(..., description="Payload mode")
    deliverable: WebhookDeliverable = Field(..., description="Deliverable data")


class WebhookEvent(BaseModel):
    """Verified webhook event with metadata."""

    model_config = ConfigDict(frozen=True)

    webhook_id: str = Field(..., description="Unique webhook ID (use as idempotency key)")
    timestamp: int = Field(..., description="Unix timestamp when webhook was sent")
    payload: WebhookPayload = Field(..., description="Parsed webhook payload")


# -------------------------------------------------------------------------
# Client hooks types
# -------------------------------------------------------------------------


class RequestContext(TypedDict):
    """Context passed to hooks before a request is made."""

    method: str
    """HTTP method."""
    url: str
    """Request URL (without auth headers)."""
    attempt: int
    """Attempt number (1-based, increases on retries)."""


class ResponseContext(TypedDict):
    """Context passed to hooks after a response is received."""

    method: str
    """HTTP method."""
    url: str
    """Request URL (without auth headers)."""
    attempt: int
    """Attempt number (1-based, increases on retries)."""
    status: int
    """HTTP status code."""
    duration_ms: float
    """Request duration in milliseconds."""


# Hook callback type aliases
BeforeRequestHook = Callable[[RequestContext], Awaitable[None] | None]
"""Callback called before each HTTP request (including retries)."""

AfterResponseHook = Callable[[ResponseContext], Awaitable[None] | None]
"""Callback called after a successful response."""

OnErrorHook = Callable[[RequestContext, Exception], Awaitable[None] | None]
"""Callback called when an error occurs (before retry or throw)."""
