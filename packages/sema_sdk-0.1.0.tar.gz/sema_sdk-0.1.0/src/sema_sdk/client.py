"""Sema API client."""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
import os
import random
import time
from collections.abc import AsyncIterator, Callable, Iterator
from email.utils import parsedate_to_datetime
from io import IOBase
from typing import Any, BinaryIO
from urllib.parse import urlparse
from uuid import uuid4

import httpx

from sema_sdk.exceptions import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    SemaAPIError,
)
from sema_sdk.types import (
    AfterResponseHook,
    AttachmentList,
    BeforeRequestHook,
    CreateItemResponse,
    DeliveryList,
    Inbox,
    InboxList,
    Item,
    ItemList,
    OnErrorHook,
    RequestContext,
    ResponseContext,
)
from sema_sdk.version import __version__

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://api.withsema.com"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 3
MAX_RETRY_DELAY = 30.0  # 30 seconds
BASE_RETRY_DELAY = 0.5  # 500ms

HTTPS_REJECT_MESSAGE = (
    "Production API keys (sk_live_...) must not be used with a non-HTTPS base URL. "
    "Use https://api.withsema.com or set SEMA_BASE_URL to an HTTPS URL."
)


def _is_loopback_host(hostname: str | None) -> bool:
    if not hostname:
        return False
    h = hostname.lower()
    if h in ("localhost", "127.0.0.1", "::1"):
        return True
    if h.startswith("127."):
        return True  # IPv4 loopback range
    return False


# =============================================================================
# Sync Client (default)
# =============================================================================


class SemaClient:
    """
    Synchronous client for the Sema API.

    Example:
        ```python
        with SemaClient(api_key="sk_live_...") as client:
            inbox = client.create_inbox(name="My Inbox")
            item = client.upload_item(
                inbox.id, file_content, sender_address="sender@example.com"
            )
        ```

    For async usage, see `AsyncSemaClient`.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        *,
        on_before_request: BeforeRequestHook | None = None,
        on_after_response: AfterResponseHook | None = None,
        on_error: OnErrorHook | None = None,
    ) -> None:
        """
        Initialize the Sema client.

        Args:
            api_key: Your Sema API key (format: sk_live_... or sk_test_...).
                Falls back to SEMA_API_KEY env when not provided.
            base_url: API base URL. Falls back to SEMA_BASE_URL env or
                https://api.withsema.com when not provided.
            timeout: Request timeout in seconds. Defaults to 30.
            max_retries: Maximum number of retries for transient failures.
                Defaults to 3. Set to 0 to disable retries.
            on_before_request: Optional hook called before each HTTP request.
            on_after_response: Optional hook called after a successful response.
            on_error: Optional hook called when an error occurs.
        """
        self._api_key = api_key if api_key is not None else os.environ.get("SEMA_API_KEY", "")
        self._base_url = (base_url or os.environ.get("SEMA_BASE_URL") or DEFAULT_BASE_URL).rstrip(
            "/"
        )
        if not self._api_key:
            raise ValueError(
                "Sema API key is required. Set api_key or SEMA_API_KEY environment variable."
            )
        parsed = urlparse(self._base_url)
        if parsed.scheme == "http":
            hostname = parsed.hostname
            if self._api_key.startswith("sk_live_") and not _is_loopback_host(hostname):
                raise ValueError(HTTPS_REJECT_MESSAGE)
            logger.warning("Sema client is using a non-HTTPS base URL. Use HTTPS in production.")
        self._timeout = timeout
        self._max_retries = max_retries
        self._client: httpx.Client | None = None
        self._on_before_request = on_before_request
        self._on_after_response = on_after_response
        self._on_error = on_error

    def _get_client(self) -> httpx.Client:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self._base_url,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "User-Agent": f"sema-sdk-python/{__version__}",
                },
                timeout=self._timeout,
            )
        return self._client

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> SemaClient:
        """Enter context."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Exit context."""
        self.close()

    def _call_hook(
        self,
        hook: Callable[..., Any] | None,
        *args: Any,
    ) -> None:
        """Safely call a hook, catching any errors to prevent user code from breaking the SDK."""
        if hook is None:
            return
        try:
            result = hook(*args)
            # For sync client, we don't support async hooks
            if inspect.isawaitable(result):
                logger.warning("Async hooks not supported in sync client; use AsyncSemaClient.")
        except Exception:
            # Silently ignore hook errors to not break SDK functionality
            pass

    @staticmethod
    def _safe_json(response: httpx.Response) -> dict[str, Any] | None:
        if not response.content:
            return None
        try:
            value = response.json()
        except Exception:
            return None
        return value if isinstance(value, dict) else None

    def _error_from_response(self, response: httpx.Response) -> Exception:
        body = self._safe_json(response)

        if response.status_code == 401:
            return AuthenticationError(response_body=body)
        if response.status_code == 404:
            return NotFoundError(response_body=body)
        if response.status_code == 429:
            detail = body.get("detail", "Rate limit exceeded") if body else "Rate limit exceeded"
            return RateLimitError(message=detail, response_body=body)
        if response.status_code >= 400:
            if body is None:
                return SemaAPIError(
                    message=f"Request failed with status {response.status_code}",
                    status_code=response.status_code,
                )
            detail = body.get("detail", "API error")
            return SemaAPIError(
                message=detail,
                status_code=response.status_code,
                response_body=body,
            )

        return SemaAPIError(
            message="Request failed",
            status_code=response.status_code,
            response_body=body,
        )

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Handle API response, raising appropriate exceptions on errors."""
        if response.status_code == 401:
            raise AuthenticationError(response_body=self._safe_json(response))
        if response.status_code == 404:
            raise NotFoundError(response_body=self._safe_json(response))
        if response.status_code == 429:
            body = self._safe_json(response)
            detail = body.get("detail", "Rate limit exceeded") if body else "Rate limit exceeded"
            raise RateLimitError(message=detail, response_body=body)
        if response.status_code >= 400:
            body = self._safe_json(response)
            detail = body.get("detail", "API error") if body else "API error"
            raise SemaAPIError(
                message=detail,
                status_code=response.status_code,
                response_body=body,
            )
        return response.json()

    def _request_with_retry(
        self,
        request_func: Callable[[], httpx.Response],
        method: str = "",
        url: str = "",
    ) -> httpx.Response:
        """
        Execute a request with retry logic for transient failures.

        Args:
            request_func: Callable that performs the HTTP request.
            method: HTTP method (for hooks context).
            url: Request URL (for hooks context).

        Returns:
            The HTTP response.

        Raises:
            httpx.RequestError: If all retries are exhausted on network errors.
            SemaAPIError: If all retries are exhausted on server errors.
        """
        attempt = 0

        while True:
            attempt += 1
            request_context: RequestContext = {
                "method": method,
                "url": url,
                "attempt": attempt,
            }

            # Call before_request hook
            self._call_hook(self._on_before_request, request_context)

            start_time = time.perf_counter()

            try:
                response = request_func()
                duration_ms = (time.perf_counter() - start_time) * 1000

                # Check if we should retry based on status code
                if self._should_retry(response.status_code, attempt - 1):
                    # Call on_error hook for retryable errors
                    error = self._error_from_response(response)
                    self._call_hook(self._on_error, request_context, error)

                    delay = self._get_retry_delay(response, attempt - 1)
                    time.sleep(delay)
                    continue

                # Response context for hooks
                response_context: ResponseContext = {
                    "method": method,
                    "url": url,
                    "attempt": attempt,
                    "status": response.status_code,
                    "duration_ms": duration_ms,
                }

                # Call appropriate hook based on status
                if response.status_code >= 400:
                    # Error response that we're not retrying - call on_error
                    error = self._error_from_response(response)
                    self._call_hook(self._on_error, request_context, error)
                else:
                    # Success - call after_response
                    self._call_hook(self._on_after_response, response_context)

                return response

            except httpx.RequestError as e:
                # Call on_error hook
                self._call_hook(self._on_error, request_context, e)

                # Network errors (timeout, connection errors, etc.)
                if attempt - 1 < self._max_retries:
                    delay = self._get_backoff(attempt - 1)
                    time.sleep(delay)
                    continue
                raise

    def _should_retry(self, status_code: int, attempt: int) -> bool:
        """Determine if a response status code should trigger a retry."""
        if attempt >= self._max_retries:
            return False
        # Retry on 429 (rate limited) or 5xx (server errors)
        return status_code == 429 or status_code >= 500

    def _get_retry_delay(self, response: httpx.Response, attempt: int) -> float:
        """Get the delay before retrying, respecting Retry-After header for 429s."""
        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            if retry_after:
                parsed = self._parse_retry_after(retry_after)
                if parsed is not None:
                    return min(parsed, MAX_RETRY_DELAY)
        return self._get_backoff(attempt)

    def _parse_retry_after(self, value: str) -> float | None:
        """
        Parse Retry-After header value to seconds.

        Supports both integer seconds and HTTP-date formats.
        """
        # Try parsing as integer seconds
        try:
            return float(value)
        except ValueError:
            pass

        # Try parsing as HTTP-date
        try:
            dt = parsedate_to_datetime(value)
            delay = dt.timestamp() - time.time()
            return max(delay, 0)
        except (ValueError, TypeError):
            pass

        return None

    def _get_backoff(self, attempt: int) -> float:
        """Calculate exponential backoff with jitter."""
        exponential = BASE_RETRY_DELAY * (2**attempt)
        jitter = random.random() * 0.2  # Up to 200ms jitter
        return min(exponential + jitter, MAX_RETRY_DELAY)

    # -------------------------------------------------------------------------
    # Inbox operations
    # -------------------------------------------------------------------------

    def create_inbox(
        self,
        name: str,
        *,
        description: str | None = None,
        webhook_url: str | None = None,
        webhook_secret: str | None = None,
        email_enabled: bool = False,
        email_prefix: str | None = None,
        owner_type: str | None = None,
        owner_id: str | None = None,
    ) -> Inbox:
        """
        Create a new inbox.

        Args:
            name: Human-readable name for the inbox.
            description: Optional description.
            webhook_url: HTTPS URL for webhook delivery.
            webhook_secret: Secret for signing webhooks (auto-generated if not provided).
            email_enabled: Whether to enable email receiving.
            email_prefix: Email prefix (part before @).
            owner_type: Owner type ('user' or 'organization').
            owner_id: Owner ID (defaults to current user).

        Returns:
            The created Inbox.
        """
        client = self._get_client()

        payload: dict[str, Any] = {"name": name}
        if description is not None:
            payload["description"] = description
        if webhook_url is not None:
            payload["webhook_url"] = webhook_url
        if webhook_secret is not None:
            payload["webhook_secret"] = webhook_secret
        if email_enabled:
            payload["email_enabled"] = email_enabled
        if email_prefix is not None:
            payload["email_prefix"] = email_prefix
        if owner_type is not None:
            payload["owner_type"] = owner_type
        if owner_id is not None:
            payload["owner_id"] = owner_id

        url = f"{self._base_url}/v1/inboxes"
        response = self._request_with_retry(
            lambda: client.post("/v1/inboxes", json=payload),
            method="POST",
            url=url,
        )
        data = self._handle_response(response)
        return Inbox.model_validate(data)

    def get_inbox(self, inbox_id: str) -> Inbox:
        """
        Get an inbox by ID.

        Args:
            inbox_id: The inbox UUID.

        Returns:
            The Inbox.

        Raises:
            NotFoundError: If the inbox does not exist.
        """
        client = self._get_client()
        url = f"{self._base_url}/v1/inboxes/{inbox_id}"
        response = self._request_with_retry(
            lambda: client.get(f"/v1/inboxes/{inbox_id}"),
            method="GET",
            url=url,
        )
        data = self._handle_response(response)
        return Inbox.model_validate(data)

    def update_inbox(
        self,
        inbox_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        webhook_url: str | None = None,
        webhook_secret: str | None = None,
        is_active: bool | None = None,
        allowed_senders: list[str] | None = None,
        allowed_domains: list[str] | None = None,
        payload_mode: str | None = None,
        email_enabled: bool | None = None,
        email_prefix: str | None = None,
    ) -> Inbox:
        """
        Update an inbox.

        Args:
            inbox_id: The inbox UUID.
            name: New name.
            description: New description.
            webhook_url: New webhook URL.
            webhook_secret: New webhook secret.
            is_active: Whether the inbox accepts new items.
            allowed_senders: List of allowed sender emails.
            allowed_domains: List of allowed sender domains.
            payload_mode: Webhook payload mode ('full' or 'thin').
            email_enabled: Whether email receiving is enabled.
            email_prefix: Email prefix.

        Returns:
            The updated Inbox.
        """
        client = self._get_client()

        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if webhook_url is not None:
            payload["webhook_url"] = webhook_url
        if webhook_secret is not None:
            payload["webhook_secret"] = webhook_secret
        if is_active is not None:
            payload["is_active"] = is_active
        if allowed_senders is not None:
            payload["allowed_senders"] = allowed_senders
        if allowed_domains is not None:
            payload["allowed_domains"] = allowed_domains
        if payload_mode is not None:
            payload["payload_mode"] = payload_mode
        if email_enabled is not None:
            payload["email_enabled"] = email_enabled
        if email_prefix is not None:
            payload["email_prefix"] = email_prefix

        url = f"{self._base_url}/v1/inboxes/{inbox_id}"
        response = self._request_with_retry(
            lambda: client.patch(f"/v1/inboxes/{inbox_id}", json=payload),
            method="PATCH",
            url=url,
        )
        data = self._handle_response(response)
        return Inbox.model_validate(data)

    def list_inboxes(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> InboxList:
        """
        List inboxes with optional pagination.

        Args:
            limit: Maximum number of inboxes to return.
            offset: Number of inboxes to skip.

        Returns:
            InboxList with inboxes and total count.
        """
        client = self._get_client()
        params: dict[str, int] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        url = f"{self._base_url}/v1/inboxes"
        response = self._request_with_retry(
            lambda: client.get("/v1/inboxes", params=params or None),
            method="GET",
            url=url,
        )
        data = self._handle_response(response)
        return InboxList.model_validate(data)

    # -------------------------------------------------------------------------
    # Item operations
    # -------------------------------------------------------------------------

    def upload_item(
        self,
        inbox_id: str,
        file: bytes | BinaryIO,
        *,
        sender_address: str,
        filename: str | None = None,
        content_type: str | None = None,
        sender_display_name: str | None = None,
        subject: str | None = None,
        provider_message_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> CreateItemResponse:
        """
        Upload an item to an inbox.

        Args:
            inbox_id: The inbox UUID.
            file: File content as bytes or file-like object.
            sender_address: Sender's email address or identifier.
            filename: Filename for the upload. Defaults to a generated name.
            content_type: MIME type. Defaults to application/octet-stream.
            sender_display_name: Sender's display name.
            subject: Subject line.
            provider_message_id: External message ID for deduplication.
            metadata: Custom key-value metadata.

        Returns:
            The created item response.
        """
        client = self._get_client()

        # Read file content if it's a file-like object
        if isinstance(file, IOBase):
            file_content = file.read()
            if isinstance(file_content, str):
                file_content = file_content.encode("utf-8")
        else:
            file_content = file

        # Build multipart form data
        actual_filename = filename or f"upload-{uuid4().hex[:8]}"
        actual_content_type = content_type or "application/octet-stream"

        files = {"file": (actual_filename, file_content, actual_content_type)}

        data: dict[str, str] = {"sender_address": sender_address}
        if sender_display_name is not None:
            data["sender_display_name"] = sender_display_name
        if subject is not None:
            data["subject"] = subject
        if provider_message_id is not None:
            data["provider_message_id"] = provider_message_id
        if metadata is not None:
            data["metadata"] = json.dumps(metadata)

        url = f"{self._base_url}/v1/inboxes/{inbox_id}/items"
        response = self._request_with_retry(
            lambda: client.post(f"/v1/inboxes/{inbox_id}/items", files=files, data=data),
            method="POST",
            url=url,
        )
        resp_data = self._handle_response(response)
        return CreateItemResponse.model_validate(resp_data)

    def get_item(self, item_id: str) -> Item:
        """
        Get an item by ID.

        Args:
            item_id: The item UUID.

        Returns:
            The Item.

        Raises:
            NotFoundError: If the item does not exist.
        """
        client = self._get_client()
        url = f"{self._base_url}/v1/items/{item_id}"
        response = self._request_with_retry(
            lambda: client.get(f"/v1/items/{item_id}"),
            method="GET",
            url=url,
        )
        data = self._handle_response(response)
        return Item.model_validate(data)

    def list_items(
        self,
        inbox_id: str,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> ItemList:
        """
        List items in an inbox.

        Args:
            inbox_id: The inbox UUID.
            limit: Maximum number of items to return.
            offset: Number of items to skip.

        Returns:
            ItemList with items and total count.
        """
        client = self._get_client()

        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset

        url = f"{self._base_url}/v1/inboxes/{inbox_id}/items"
        response = self._request_with_retry(
            lambda: client.get(f"/v1/inboxes/{inbox_id}/items", params=params),
            method="GET",
            url=url,
        )
        data = self._handle_response(response)
        return ItemList.model_validate(data)

    # -------------------------------------------------------------------------
    # Delivery operations
    # -------------------------------------------------------------------------

    def get_item_deliveries(self, item_id: str) -> DeliveryList:
        """
        Get deliveries for an item.

        Args:
            item_id: The item UUID.

        Returns:
            DeliveryList with all deliveries for the item.

        Raises:
            NotFoundError: If the item does not exist.
        """
        client = self._get_client()
        url = f"{self._base_url}/v1/items/{item_id}/deliveries"
        response = self._request_with_retry(
            lambda: client.get(f"/v1/items/{item_id}/deliveries"),
            method="GET",
            url=url,
        )
        data = self._handle_response(response)
        return DeliveryList.model_validate(data)

    # -------------------------------------------------------------------------
    # Attachment operations
    # -------------------------------------------------------------------------

    def get_item_attachments(self, item_id: str) -> AttachmentList:
        """
        Get attachments for an item with presigned download URLs.

        Args:
            item_id: The item UUID.

        Returns:
            AttachmentList with all attachments for the item.

        Raises:
            NotFoundError: If the item does not exist.
        """
        client = self._get_client()
        url = f"{self._base_url}/v1/items/{item_id}/attachments"
        response = self._request_with_retry(
            lambda: client.get(f"/v1/items/{item_id}/attachments"),
            method="GET",
            url=url,
        )
        data = self._handle_response(response)
        return AttachmentList.model_validate(data)

    # -------------------------------------------------------------------------
    # Pagination iterators
    # -------------------------------------------------------------------------

    def iter_items(
        self,
        inbox_id: str,
        *,
        page_size: int = 100,
    ) -> Iterator[Item]:
        """
        Iterate over all items in an inbox with automatic pagination.

        Args:
            inbox_id: The inbox UUID.
            page_size: Number of items to fetch per page. Defaults to 100.

        Yields:
            Item objects one at a time.

        Example:
            ```python
            for item in client.iter_items(inbox_id):
                print(item.id, item.status)
            ```
        """
        offset = 0

        while True:
            result = self.list_items(inbox_id, limit=page_size, offset=offset)

            yield from result.items

            offset += len(result.items)

            # Stop if we've fetched all items or got an empty page
            if offset >= result.total or len(result.items) == 0:
                break

    def iter_inboxes(
        self,
        *,
        page_size: int = 100,
    ) -> Iterator[Inbox]:
        """
        Iterate over all inboxes with automatic pagination.

        Args:
            page_size: Number of inboxes to fetch per page. Defaults to 100.

        Yields:
            Inbox objects one at a time.

        Example:
            ```python
            for inbox in client.iter_inboxes():
                print(inbox.id, inbox.name)
            ```
        """
        offset = 0

        while True:
            result = self.list_inboxes(limit=page_size, offset=offset)

            yield from result.inboxes

            offset += len(result.inboxes)

            # Stop if we've fetched all inboxes or got an empty page
            if offset >= result.total or len(result.inboxes) == 0:
                break


# =============================================================================
# Async Client
# =============================================================================


class AsyncSemaClient:
    """
    Async client for the Sema API.

    Example:
        ```python
        async with AsyncSemaClient(api_key="sk_live_...") as client:
            inbox = await client.create_inbox(name="My Inbox")
            item = await client.upload_item(
                inbox.id, file_content, sender_address="sender@example.com"
            )
        ```

    For sync usage, see `SemaClient`.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        *,
        on_before_request: BeforeRequestHook | None = None,
        on_after_response: AfterResponseHook | None = None,
        on_error: OnErrorHook | None = None,
    ) -> None:
        """
        Initialize the Sema client.

        Args:
            api_key: Your Sema API key (format: sk_live_... or sk_test_...).
                Falls back to SEMA_API_KEY env when not provided.
            base_url: API base URL. Falls back to SEMA_BASE_URL env or
                https://api.withsema.com when not provided.
            timeout: Request timeout in seconds. Defaults to 30.
            max_retries: Maximum number of retries for transient failures.
                Defaults to 3. Set to 0 to disable retries.
            on_before_request: Optional hook called before each HTTP request.
            on_after_response: Optional hook called after a successful response.
            on_error: Optional hook called when an error occurs.
        """
        self._api_key = api_key if api_key is not None else os.environ.get("SEMA_API_KEY", "")
        self._base_url = (base_url or os.environ.get("SEMA_BASE_URL") or DEFAULT_BASE_URL).rstrip(
            "/"
        )
        if not self._api_key:
            raise ValueError(
                "Sema API key is required. Set api_key or SEMA_API_KEY environment variable."
            )
        parsed = urlparse(self._base_url)
        if parsed.scheme == "http":
            hostname = parsed.hostname
            if self._api_key.startswith("sk_live_") and not _is_loopback_host(hostname):
                raise ValueError(HTTPS_REJECT_MESSAGE)
            logger.warning("Sema client is using a non-HTTPS base URL. Use HTTPS in production.")
        self._timeout = timeout
        self._max_retries = max_retries
        self._client: httpx.AsyncClient | None = None
        self._on_before_request = on_before_request
        self._on_after_response = on_after_response
        self._on_error = on_error

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "User-Agent": f"sema-sdk-python/{__version__}",
                },
                timeout=self._timeout,
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> AsyncSemaClient:
        """Enter async context."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context."""
        await self.close()

    async def _call_hook(
        self,
        hook: Callable[..., Any] | None,
        *args: Any,
    ) -> None:
        """Safely call a hook, catching any errors to prevent user code from breaking the SDK."""
        if hook is None:
            return
        try:
            result = hook(*args)
            # Handle both sync and async hooks
            if inspect.isawaitable(result):
                await result
        except Exception:
            # Silently ignore hook errors to not break SDK functionality
            pass

    @staticmethod
    def _safe_json(response: httpx.Response) -> dict[str, Any] | None:
        if not response.content:
            return None
        try:
            value = response.json()
        except Exception:
            return None
        return value if isinstance(value, dict) else None

    def _error_from_response(self, response: httpx.Response) -> Exception:
        body = self._safe_json(response)

        if response.status_code == 401:
            return AuthenticationError(response_body=body)
        if response.status_code == 404:
            return NotFoundError(response_body=body)
        if response.status_code == 429:
            detail = body.get("detail", "Rate limit exceeded") if body else "Rate limit exceeded"
            return RateLimitError(message=detail, response_body=body)
        if response.status_code >= 400:
            if body is None:
                return SemaAPIError(
                    message=f"Request failed with status {response.status_code}",
                    status_code=response.status_code,
                )
            detail = body.get("detail", "API error")
            return SemaAPIError(
                message=detail,
                status_code=response.status_code,
                response_body=body,
            )

        return SemaAPIError(
            message="Request failed",
            status_code=response.status_code,
            response_body=body,
        )

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Handle API response, raising appropriate exceptions on errors."""
        if response.status_code == 401:
            raise AuthenticationError(response_body=self._safe_json(response))
        if response.status_code == 404:
            raise NotFoundError(response_body=self._safe_json(response))
        if response.status_code == 429:
            body = self._safe_json(response)
            detail = body.get("detail", "Rate limit exceeded") if body else "Rate limit exceeded"
            raise RateLimitError(message=detail, response_body=body)
        if response.status_code >= 400:
            body = self._safe_json(response)
            detail = body.get("detail", "API error") if body else "API error"
            raise SemaAPIError(
                message=detail,
                status_code=response.status_code,
                response_body=body,
            )
        return response.json()

    async def _request_with_retry(
        self,
        request_func: Callable[[], Any],
        method: str = "",
        url: str = "",
    ) -> httpx.Response:
        """
        Execute a request with retry logic for transient failures.

        Args:
            request_func: Async callable that performs the HTTP request.
            method: HTTP method (for hooks context).
            url: Request URL (for hooks context).

        Returns:
            The HTTP response.

        Raises:
            httpx.RequestError: If all retries are exhausted on network errors.
            SemaAPIError: If all retries are exhausted on server errors.
        """
        attempt = 0

        while True:
            attempt += 1
            request_context: RequestContext = {
                "method": method,
                "url": url,
                "attempt": attempt,
            }

            # Call before_request hook
            await self._call_hook(self._on_before_request, request_context)

            start_time = time.perf_counter()

            try:
                response = await request_func()
                duration_ms = (time.perf_counter() - start_time) * 1000

                # Check if we should retry based on status code
                if self._should_retry(response.status_code, attempt - 1):
                    # Call on_error hook for retryable errors
                    error = self._error_from_response(response)
                    await self._call_hook(self._on_error, request_context, error)

                    delay = self._get_retry_delay(response, attempt - 1)
                    await asyncio.sleep(delay)
                    continue

                # Response context for hooks
                response_context: ResponseContext = {
                    "method": method,
                    "url": url,
                    "attempt": attempt,
                    "status": response.status_code,
                    "duration_ms": duration_ms,
                }

                # Call appropriate hook based on status
                if response.status_code >= 400:
                    # Error response that we're not retrying - call on_error
                    error = self._error_from_response(response)
                    await self._call_hook(self._on_error, request_context, error)
                else:
                    # Success - call after_response
                    await self._call_hook(self._on_after_response, response_context)

                return response

            except httpx.RequestError as e:
                # Call on_error hook
                await self._call_hook(self._on_error, request_context, e)

                # Network errors (timeout, connection errors, etc.)
                if attempt - 1 < self._max_retries:
                    delay = self._get_backoff(attempt - 1)
                    await asyncio.sleep(delay)
                    continue
                raise

    def _should_retry(self, status_code: int, attempt: int) -> bool:
        """Determine if a response status code should trigger a retry."""
        if attempt >= self._max_retries:
            return False
        # Retry on 429 (rate limited) or 5xx (server errors)
        return status_code == 429 or status_code >= 500

    def _get_retry_delay(self, response: httpx.Response, attempt: int) -> float:
        """Get the delay before retrying, respecting Retry-After header for 429s."""
        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            if retry_after:
                parsed = self._parse_retry_after(retry_after)
                if parsed is not None:
                    return min(parsed, MAX_RETRY_DELAY)
        return self._get_backoff(attempt)

    def _parse_retry_after(self, value: str) -> float | None:
        """
        Parse Retry-After header value to seconds.

        Supports both integer seconds and HTTP-date formats.
        """
        # Try parsing as integer seconds
        try:
            return float(value)
        except ValueError:
            pass

        # Try parsing as HTTP-date
        try:
            dt = parsedate_to_datetime(value)
            delay = dt.timestamp() - time.time()
            return max(delay, 0)
        except (ValueError, TypeError):
            pass

        return None

    def _get_backoff(self, attempt: int) -> float:
        """Calculate exponential backoff with jitter."""
        exponential = BASE_RETRY_DELAY * (2**attempt)
        jitter = random.random() * 0.2  # Up to 200ms jitter
        return min(exponential + jitter, MAX_RETRY_DELAY)

    # -------------------------------------------------------------------------
    # Inbox operations
    # -------------------------------------------------------------------------

    async def create_inbox(
        self,
        name: str,
        *,
        description: str | None = None,
        webhook_url: str | None = None,
        webhook_secret: str | None = None,
        email_enabled: bool = False,
        email_prefix: str | None = None,
        owner_type: str | None = None,
        owner_id: str | None = None,
    ) -> Inbox:
        """
        Create a new inbox.

        Args:
            name: Human-readable name for the inbox.
            description: Optional description.
            webhook_url: HTTPS URL for webhook delivery.
            webhook_secret: Secret for signing webhooks (auto-generated if not provided).
            email_enabled: Whether to enable email receiving.
            email_prefix: Email prefix (part before @).
            owner_type: Owner type ('user' or 'organization').
            owner_id: Owner ID (defaults to current user).

        Returns:
            The created Inbox.
        """
        client = await self._get_client()

        payload: dict[str, Any] = {"name": name}
        if description is not None:
            payload["description"] = description
        if webhook_url is not None:
            payload["webhook_url"] = webhook_url
        if webhook_secret is not None:
            payload["webhook_secret"] = webhook_secret
        if email_enabled:
            payload["email_enabled"] = email_enabled
        if email_prefix is not None:
            payload["email_prefix"] = email_prefix
        if owner_type is not None:
            payload["owner_type"] = owner_type
        if owner_id is not None:
            payload["owner_id"] = owner_id

        url = f"{self._base_url}/v1/inboxes"
        response = await self._request_with_retry(
            lambda: client.post("/v1/inboxes", json=payload),
            method="POST",
            url=url,
        )
        data = self._handle_response(response)
        return Inbox.model_validate(data)

    async def get_inbox(self, inbox_id: str) -> Inbox:
        """
        Get an inbox by ID.

        Args:
            inbox_id: The inbox UUID.

        Returns:
            The Inbox.

        Raises:
            NotFoundError: If the inbox does not exist.
        """
        client = await self._get_client()
        url = f"{self._base_url}/v1/inboxes/{inbox_id}"
        response = await self._request_with_retry(
            lambda: client.get(f"/v1/inboxes/{inbox_id}"),
            method="GET",
            url=url,
        )
        data = self._handle_response(response)
        return Inbox.model_validate(data)

    async def update_inbox(
        self,
        inbox_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        webhook_url: str | None = None,
        webhook_secret: str | None = None,
        is_active: bool | None = None,
        allowed_senders: list[str] | None = None,
        allowed_domains: list[str] | None = None,
        payload_mode: str | None = None,
        email_enabled: bool | None = None,
        email_prefix: str | None = None,
    ) -> Inbox:
        """
        Update an inbox.

        Args:
            inbox_id: The inbox UUID.
            name: New name.
            description: New description.
            webhook_url: New webhook URL.
            webhook_secret: New webhook secret.
            is_active: Whether the inbox accepts new items.
            allowed_senders: List of allowed sender emails.
            allowed_domains: List of allowed sender domains.
            payload_mode: Webhook payload mode ('full' or 'thin').
            email_enabled: Whether email receiving is enabled.
            email_prefix: Email prefix.

        Returns:
            The updated Inbox.
        """
        client = await self._get_client()

        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if webhook_url is not None:
            payload["webhook_url"] = webhook_url
        if webhook_secret is not None:
            payload["webhook_secret"] = webhook_secret
        if is_active is not None:
            payload["is_active"] = is_active
        if allowed_senders is not None:
            payload["allowed_senders"] = allowed_senders
        if allowed_domains is not None:
            payload["allowed_domains"] = allowed_domains
        if payload_mode is not None:
            payload["payload_mode"] = payload_mode
        if email_enabled is not None:
            payload["email_enabled"] = email_enabled
        if email_prefix is not None:
            payload["email_prefix"] = email_prefix

        url = f"{self._base_url}/v1/inboxes/{inbox_id}"
        response = await self._request_with_retry(
            lambda: client.patch(f"/v1/inboxes/{inbox_id}", json=payload),
            method="PATCH",
            url=url,
        )
        data = self._handle_response(response)
        return Inbox.model_validate(data)

    async def list_inboxes(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> InboxList:
        """
        List inboxes with optional pagination.

        Args:
            limit: Maximum number of inboxes to return.
            offset: Number of inboxes to skip.

        Returns:
            InboxList with inboxes and total count.
        """
        client = await self._get_client()
        params: dict[str, int] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        url = f"{self._base_url}/v1/inboxes"
        response = await self._request_with_retry(
            lambda: client.get("/v1/inboxes", params=params or None),
            method="GET",
            url=url,
        )
        data = self._handle_response(response)
        return InboxList.model_validate(data)

    # -------------------------------------------------------------------------
    # Item operations
    # -------------------------------------------------------------------------

    async def upload_item(
        self,
        inbox_id: str,
        file: bytes | BinaryIO,
        *,
        sender_address: str,
        filename: str | None = None,
        content_type: str | None = None,
        sender_display_name: str | None = None,
        subject: str | None = None,
        provider_message_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> CreateItemResponse:
        """
        Upload an item to an inbox.

        Args:
            inbox_id: The inbox UUID.
            file: File content as bytes or file-like object.
            sender_address: Sender's email address or identifier.
            filename: Filename for the upload. Defaults to a generated name.
            content_type: MIME type. Defaults to application/octet-stream.
            sender_display_name: Sender's display name.
            subject: Subject line.
            provider_message_id: External message ID for deduplication.
            metadata: Custom key-value metadata.

        Returns:
            The created item response.
        """
        client = await self._get_client()

        # Read file content if it's a file-like object
        if isinstance(file, IOBase):
            file_content = file.read()
            if isinstance(file_content, str):
                file_content = file_content.encode("utf-8")
        else:
            file_content = file

        # Build multipart form data
        actual_filename = filename or f"upload-{uuid4().hex[:8]}"
        actual_content_type = content_type or "application/octet-stream"

        files = {"file": (actual_filename, file_content, actual_content_type)}

        data: dict[str, str] = {"sender_address": sender_address}
        if sender_display_name is not None:
            data["sender_display_name"] = sender_display_name
        if subject is not None:
            data["subject"] = subject
        if provider_message_id is not None:
            data["provider_message_id"] = provider_message_id
        if metadata is not None:
            data["metadata"] = json.dumps(metadata)

        url = f"{self._base_url}/v1/inboxes/{inbox_id}/items"
        response = await self._request_with_retry(
            lambda: client.post(f"/v1/inboxes/{inbox_id}/items", files=files, data=data),
            method="POST",
            url=url,
        )
        resp_data = self._handle_response(response)
        return CreateItemResponse.model_validate(resp_data)

    async def get_item(self, item_id: str) -> Item:
        """
        Get an item by ID.

        Args:
            item_id: The item UUID.

        Returns:
            The Item.

        Raises:
            NotFoundError: If the item does not exist.
        """
        client = await self._get_client()
        url = f"{self._base_url}/v1/items/{item_id}"
        response = await self._request_with_retry(
            lambda: client.get(f"/v1/items/{item_id}"),
            method="GET",
            url=url,
        )
        data = self._handle_response(response)
        return Item.model_validate(data)

    async def list_items(
        self,
        inbox_id: str,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> ItemList:
        """
        List items in an inbox.

        Args:
            inbox_id: The inbox UUID.
            limit: Maximum number of items to return.
            offset: Number of items to skip.

        Returns:
            ItemList with items and total count.
        """
        client = await self._get_client()

        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset

        url = f"{self._base_url}/v1/inboxes/{inbox_id}/items"
        response = await self._request_with_retry(
            lambda: client.get(f"/v1/inboxes/{inbox_id}/items", params=params),
            method="GET",
            url=url,
        )
        data = self._handle_response(response)
        return ItemList.model_validate(data)

    # -------------------------------------------------------------------------
    # Delivery operations
    # -------------------------------------------------------------------------

    async def get_item_deliveries(self, item_id: str) -> DeliveryList:
        """
        Get deliveries for an item.

        Args:
            item_id: The item UUID.

        Returns:
            DeliveryList with all deliveries for the item.

        Raises:
            NotFoundError: If the item does not exist.
        """
        client = await self._get_client()
        url = f"{self._base_url}/v1/items/{item_id}/deliveries"
        response = await self._request_with_retry(
            lambda: client.get(f"/v1/items/{item_id}/deliveries"),
            method="GET",
            url=url,
        )
        data = self._handle_response(response)
        return DeliveryList.model_validate(data)

    # -------------------------------------------------------------------------
    # Attachment operations
    # -------------------------------------------------------------------------

    async def get_item_attachments(self, item_id: str) -> AttachmentList:
        """
        Get attachments for an item with presigned download URLs.

        Args:
            item_id: The item UUID.

        Returns:
            AttachmentList with all attachments for the item.

        Raises:
            NotFoundError: If the item does not exist.
        """
        client = await self._get_client()
        url = f"{self._base_url}/v1/items/{item_id}/attachments"
        response = await self._request_with_retry(
            lambda: client.get(f"/v1/items/{item_id}/attachments"),
            method="GET",
            url=url,
        )
        data = self._handle_response(response)
        return AttachmentList.model_validate(data)

    # -------------------------------------------------------------------------
    # Pagination iterators
    # -------------------------------------------------------------------------

    async def iter_items(
        self,
        inbox_id: str,
        *,
        page_size: int = 100,
    ) -> AsyncIterator[Item]:
        """
        Iterate over all items in an inbox with automatic pagination.

        Args:
            inbox_id: The inbox UUID.
            page_size: Number of items to fetch per page. Defaults to 100.

        Yields:
            Item objects one at a time.

        Example:
            ```python
            async for item in client.iter_items(inbox_id):
                print(item.id, item.status)
            ```
        """
        offset = 0

        while True:
            result = await self.list_items(inbox_id, limit=page_size, offset=offset)

            for item in result.items:
                yield item

            offset += len(result.items)

            # Stop if we've fetched all items or got an empty page
            if offset >= result.total or len(result.items) == 0:
                break

    async def iter_inboxes(
        self,
        *,
        page_size: int = 100,
    ) -> AsyncIterator[Inbox]:
        """
        Iterate over all inboxes with automatic pagination.

        Args:
            page_size: Number of inboxes to fetch per page. Defaults to 100.

        Yields:
            Inbox objects one at a time.

        Example:
            ```python
            async for inbox in client.iter_inboxes():
                print(inbox.id, inbox.name)
            ```
        """
        offset = 0

        while True:
            result = await self.list_inboxes(limit=page_size, offset=offset)

            for inbox in result.inboxes:
                yield inbox

            offset += len(result.inboxes)

            # Stop if we've fetched all inboxes or got an empty page
            if offset >= result.total or len(result.inboxes) == 0:
                break
