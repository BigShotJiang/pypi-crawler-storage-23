from .main import get_serial_from_tid
