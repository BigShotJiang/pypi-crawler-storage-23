"""
通知模块单元测试 - 增强
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch
from src.core.notification.webhook import WebhookManager, WebhookConfig, WebhookPayload


class TestWebhookConfigExtended:
    """Webhook配置扩展测试"""
    
    def test_webhook_config_default_retry(self):
        """测试默认重试配置"""
        config = WebhookConfig(
            id="test-1",
            url="http://example.com/webhook",
            events=["test.completed"]
        )
        assert config.retry_config == {"max_attempts": 3, "interval": 5}
    
    def test_webhook_config_custom_retry(self):
        """测试自定义重试配置"""
        config = WebhookConfig(
            id="test-1",
            url="http://example.com/webhook",
            events=["test.completed"],
            retry_config={"max_attempts": 5, "interval": 10}
        )
        assert config.retry_config == {"max_attempts": 5, "interval": 10}
    
    def test_webhook_config_with_created_at(self):
        """测试创建时间"""
        import datetime
        now = datetime.datetime.now().isoformat()
        config = WebhookConfig(
            id="test-1",
            url="http://example.com/webhook",
            events=["test.completed"],
            created_at=now
        )
        assert config.created_at == now


class TestWebhookPayloadExtended:
    """Webhook负载扩展测试"""
    
    def test_payload_all_fields(self):
        """测试所有字段"""
        payload = WebhookPayload(
            event="test.failed",
            test_id="test_456",
            project="oc-collab",
            version="v2.0",
            status="failed",
            passed=50,
            failed=20,
            errors=5,
            duration=120.5,
            metadata={"runner": "docker"}
        )
        
        assert payload.event == "test.failed"
        assert payload.test_id == "test_456"
        assert payload.project == "oc-collab"
        assert payload.version == "v2.0"
        assert payload.status == "failed"
        assert payload.passed == 50
        assert payload.failed == 20
        assert payload.errors == 5
        assert payload.duration == 120.5
        assert payload.metadata["runner"] == "docker"


class TestWebhookManagerMethods:
    """Webhook管理器方法测试"""
    
    def test_build_payload_failed_status(self):
        """测试构建失败状态负载"""
        manager = WebhookManager()
        
        mock_result = Mock()
        mock_result.id = "test_999"
        mock_result.project = "test-agent"
        mock_result.version = "v1.3"
        mock_result.status = "failed"
        mock_result.passed = 80
        mock_result.failed = 15
        mock_result.errors = 5
        mock_result.duration = 200.0
        
        payload = manager.build_payload(mock_result)
        
        assert payload.event == "test.failed"
        assert payload.status == "failed"
        assert payload.failed == 15
    
    def test_build_payload_error_status(self):
        """测试错误状态负载"""
        manager = WebhookManager()
        
        mock_result = Mock()
        mock_result.id = "test_888"
        mock_result.project = "test-agent"
        mock_result.version = "v1.3"
        mock_result.status = "error"
        mock_result.passed = 0
        mock_result.failed = 0
        mock_result.errors = 100
        mock_result.duration = 50.0
        
        payload = manager.build_payload(mock_result)
        
        assert payload.event == "test.error"
        assert payload.errors == 100


class TestWebhookSendNotification:
    """Webhook发送通知测试"""
    
    @pytest.mark.asyncio
    async def test_notify_with_enabled(self):
        """测试启用通知"""
        manager = WebhookManager()
        manager._enabled = True
        
        mock_result = Mock()
        mock_result.id = "test_111"
        mock_result.project = "pm-agent"
        mock_result.version = "v1.3"
        mock_result.status = "passed"
        mock_result.passed = 10
        mock_result.failed = 0
        mock_result.errors = 0
        mock_result.duration = 10.0
        
        with patch.object(manager, '_send_notifications', new_callable=AsyncMock) as mock_notify:
            await manager.notify(mock_result)
            mock_notify.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_notify_with_disabled(self):
        """测试禁用通知"""
        manager = WebhookManager()
        manager._enabled = False
        
        mock_result = Mock()
        mock_result.id = "test_222"
        mock_result.project = "pm-agent"
        mock_result.version = "v1.3"
        mock_result.status = "passed"
        mock_result.passed = 10
        mock_result.failed = 0
        mock_result.errors = 0
        mock_result.duration = 10.0
        
        with patch.object(manager, '_send_notifications', new_callable=AsyncMock) as mock_notify:
            await manager.notify(mock_result)
            mock_notify.assert_not_called()
