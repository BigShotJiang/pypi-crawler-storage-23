"""test-agent 自动通知机制 E2E测试

测试test-agent自动通知功能的完整功能：
- Webhook配置管理
- Webhook订阅/回调
- 测试完成自动通知
- 多Webhook支持
- 重试机制
- HMAC签名验证
- conf-man集成（使用mock）
- pm-agent缺陷报告集成（使用mock）
- 通知失败处理

测试环境:
- API地址: http://localhost:8004 (可通过环境变量TEST_AGENT_API_URL覆盖)
- API Key: test-secret (可通过环境变量TEST_AGENT_API_KEY覆盖)
- Mock Webhook: http://localhost:8888 (可通过环境变量MOCK_WEBHOOK_URL覆盖)

用例ID规范: TC-TESTAGENT-NOTIFY-{模块}-{序号}

标记:
- @pytest.mark.integration: 需要外部服务的集成测试
"""

import pytest
import requests
import time
import os
import hmac
import hashlib
import json
from typing import Optional

BASE_URL = os.environ.get("TEST_AGENT_API_URL", "http://localhost:8004")
API_KEY = os.environ.get("TEST_AGENT_API_KEY", "test-agent-secret")
MOCK_WEBHOOK_URL = os.environ.get("MOCK_WEBHOOK_URL", "http://localhost:8888")
TIMEOUT = 30


def get_headers() -> dict:
    return {"x-api-key": API_KEY}


def compute_signature(payload: str, secret: str) -> str:
    return hmac.new(
        secret.encode(),
        payload.encode(),
        hashlib.sha256
    ).hexdigest()


class TestWebhookConfigEndpoint:
    """Webhook配置管理接口测试"""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.headers = get_headers()
        self.test_webhook_id = f"test_webhook_{int(time.time())}"
        yield
        try:
            requests.delete(
                f"{BASE_URL}/api/v1/notifications/webhooks/{self.test_webhook_id}",
                headers=self.headers,
                timeout=TIMEOUT
            )
        except Exception:
            pass

    def test_get_notifications(self):
        """TC-TESTAGENT-NOTIFY-WEBHOOK-001: 获取通知配置"""
        response = requests.get(
            f"{BASE_URL}/api/v1/notifications",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 200
        data = response.json()
        assert "webhooks" in data or isinstance(data, dict)

    def test_add_webhook(self):
        """TC-TESTAGENT-NOTIFY-WEBHOOK-002: 添加Webhook"""
        response = requests.post(
            f"{BASE_URL}/api/v1/notifications/webhooks",
            json={
                "url": f"{MOCK_WEBHOOK_URL}/webhook",
                "events": ["test.completed", "test.failed"],
                "timeout": 30,
                "id": self.test_webhook_id
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 201]

    def test_delete_webhook(self):
        """TC-TESTAGENT-NOTIFY-WEBHOOK-003: 删除Webhook"""
        requests.post(
            f"{BASE_URL}/api/v1/notifications/webhooks",
            json={
                "url": f"{MOCK_WEBHOOK_URL}/webhook",
                "events": ["test.completed"],
                "id": self.test_webhook_id
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        response = requests.delete(
            f"{BASE_URL}/api/v1/notifications/webhooks/{self.test_webhook_id}",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 204, 404]

    def test_get_webhook_not_found(self):
        """TC-TESTAGENT-NOTIFY-WEBHOOK-004: 获取不存在Webhook"""
        response = requests.get(
            f"{BASE_URL}/api/v1/notifications/webhooks/invalid_id_12345",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code in [404, 405]

    def test_delete_webhook_not_found(self):
        """TC-TESTAGENT-NOTIFY-WEBHOOK-005: 删除不存在Webhook"""
        response = requests.delete(
            f"{BASE_URL}/api/v1/notifications/webhooks/invalid_id_12345",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 404


class TestWebhookSubscription:
    """Webhook订阅/回调接口测试"""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.headers = get_headers()
        yield

    def test_subscribe(self):
        """TC-TESTAGENT-NOTIFY-SUB-001: 注册订阅"""
        response = requests.post(
            f"{BASE_URL}/api/v1/webhook/subscribe",
            json={
                "url": f"{MOCK_WEBHOOK_URL}/webhook",
                "events": ["test.completed"]
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 201]

    def test_callback(self):
        """TC-TESTAGENT-NOTIFY-SUB-002: 接收回调"""
        response = requests.post(
            f"{BASE_URL}/api/v1/webhook/callback",
            json={
                "event": "test.completed",
                "test_id": "test_callback_123",
                "status": "passed"
            },
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 204]

    def test_callback_with_signature(self):
        """TC-TESTAGENT-NOTIFY-SUB-003: 回调事件验证（带签名）"""
        secret = "test-secret"
        payload = json.dumps({"event": "test.completed", "test_id": "test_sig_123"})
        signature = compute_signature(payload, secret)
        
        response = requests.post(
            f"{BASE_URL}/api/v1/webhook/callback",
            json={
                "event": "test.completed",
                "test_id": "test_sig_123"
            },
            headers={
                "X-Webhook-Signature": signature,
                "Content-Type": "application/json"
            },
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 204, 401]

    def test_duplicate_subscribe(self):
        """TC-TESTAGENT-NOTIFY-SUB-004: 重复订阅"""
        url = f"{MOCK_WEBHOOK_URL}/webhook_dup_{int(time.time())}"
        response1 = requests.post(
            f"{BASE_URL}/api/v1/webhook/subscribe",
            json={"url": url, "events": ["test.completed"]},
            headers=self.headers,
            timeout=TIMEOUT
        )
        response2 = requests.post(
            f"{BASE_URL}/api/v1/webhook/subscribe",
            json={"url": url, "events": ["test.completed"]},
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response2.status_code in [200, 201, 409]


class TestNotificationTrigger:
    """测试完成自动通知测试"""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.headers = get_headers()
        self.webhook_id = f"trigger_webhook_{int(time.time())}"
        requests.post(
            f"{BASE_URL}/api/v1/notifications/webhooks",
            json={
                "url": f"{MOCK_WEBHOOK_URL}/webhook",
                "events": ["test.completed", "test.failed"],
                "id": self.webhook_id
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        yield
        try:
            requests.delete(
                f"{BASE_URL}/api/v1/notifications/webhooks/{self.webhook_id}",
                headers=self.headers,
                timeout=TIMEOUT
            )
        except Exception:
            pass

    def test_trigger_notification(self):
        """TC-TESTAGENT-NOTIFY-TRIGGER-001: 测试完成触发通知"""
        response = requests.post(
            f"{BASE_URL}/api/v1/tests/execute",
            json={
                "project": "test-project",
                "version": "v1.0.0",
                "test_type": "unit"
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 201]

    def test_notification_payload_format(self):
        """TC-TESTAGENT-NOTIFY-TRIGGER-003: 通知负载格式"""
        response = requests.post(
            f"{BASE_URL}/api/v1/tests/execute",
            json={
                "project": "test-project",
                "version": "v1.0.0",
                "test_type": "unit"
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 201]
        data = response.json()
        assert "test_id" in data


class TestMultiWebhook:
    """多Webhook支持测试"""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.headers = get_headers()
        yield

    def test_multiple_webhooks(self):
        """TC-TESTAGENT-NOTIFY-MULTI-001: 多个Webhook配置"""
        webhook1_id = f"multi1_{int(time.time())}"
        webhook2_id = f"multi2_{int(time.time())}"
        
        resp1 = requests.post(
            f"{BASE_URL}/api/v1/notifications/webhooks",
            json={"url": f"{MOCK_WEBHOOK_URL}/webhook", "events": ["test.completed"], "id": webhook1_id},
            headers=self.headers,
            timeout=TIMEOUT
        )
        resp2 = requests.post(
            f"{BASE_URL}/api/v1/notifications/webhooks",
            json={"url": f"{MOCK_WEBHOOK_URL}/webhook", "events": ["test.completed"], "id": webhook2_id},
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert resp1.status_code in [200, 201]
        assert resp2.status_code in [200, 201]


class TestRetryMechanism:
    """重试机制测试"""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.headers = get_headers()
        self.retry_webhook_id = f"retry_{int(time.time())}"
        requests.post(
            f"{BASE_URL}/api/v1/notifications/webhooks",
            json={
                "url": f"{MOCK_WEBHOOK_URL}/webhook",
                "events": ["test.completed"],
                "id": self.retry_webhook_id
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        yield

    def test_webhook_retry_config(self):
        """TC-TESTAGENT-NOTIFY-RETRY-001: Webhook重试配置"""
        response = requests.post(
            f"{BASE_URL}/api/v1/notifications/webhooks",
            json={
                "url": f"{MOCK_WEBHOOK_URL}/webhook",
                "events": ["test.completed"],
                "retry": {"max_attempts": 3, "interval": 5}
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 201]


class TestSignatureVerification:
    """HMAC签名验证测试"""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.headers = get_headers()
        self.secret = "test-webhook-secret"
        yield

    def test_signature_valid(self):
        """TC-TESTAGENT-NOTIFY-SIG-001: 签名验证通过"""
        payload = json.dumps({"event": "test.completed", "test_id": "test_123"})
        signature = compute_signature(payload, self.secret)
        
        response = requests.post(
            f"{BASE_URL}/api/v1/webhook/callback",
            json={"event": "test.completed", "test_id": "test_123"},
            headers={
                "X-Webhook-Signature": signature,
                "Content-Type": "application/json"
            },
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 204]

    def test_signature_invalid(self):
        """TC-TESTAGENT-NOTIFY-SIG-002: 签名验证失败"""
        response = requests.post(
            f"{BASE_URL}/api/v1/webhook/callback",
            json={"event": "test.completed", "test_id": "test_123"},
            headers={
                "X-Webhook-Signature": "invalid-signature-12345",
                "Content-Type": "application/json"
            },
            timeout=TIMEOUT
        )
        assert response.status_code in [401, 403, 200]


@pytest.mark.integration
class TestConfmanIntegration:
    """conf-man集成测试（使用mock）"""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.headers = get_headers()
        yield

    def test_subscribe_confman(self):
        """TC-TESTAGENT-NOTIFY-CONFMAN-001: 向conf-man注册webhook（mock）"""
        response = requests.post(
            f"{BASE_URL}/api/v1/webhook/subscribe",
            json={
                "url": "http://conf-man:8002/api/webhook/callback",
                "events": ["version.released"]
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 201, 400]

    def test_receive_confman_callback(self):
        """TC-TESTAGENT-NOTIFY-CONFMAN-002: 接收conf-man回调（mock）"""
        response = requests.post(
            f"{BASE_URL}/api/v1/webhook/callback",
            json={
                "event": "version.released",
                "project": "test-project",
                "version": "v1.0.0"
            },
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 204, 400]


@pytest.mark.integration
class TestPMAgentIntegration:
    """pm-agent缺陷报告集成测试（使用mock）"""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.headers = get_headers()
        yield

    def test_create_issue_on_failure(self):
        """TC-TESTAGENT-NOTIFY-PM-001: 测试失败自动创建Issue（mock）"""
        response = requests.post(
            f"{BASE_URL}/api/v1/tests/execute",
            json={
                "project": "test-project",
                "version": "v1.0.0",
                "test_type": "unit",
                "force_fail": True
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 201, 400]

    def test_issue_format(self):
        """TC-TESTAGENT-NOTIFY-PM-002: Issue格式验证（mock）"""
        response = requests.post(
            f"{BASE_URL}/api/v1/tests/execute",
            json={
                "project": "test-project",
                "version": "v1.0.0",
                "test_type": "unit"
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 201]


class TestNotificationFailureHandling:
    """通知失败处理测试"""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.headers = get_headers()
        yield

    def test_failure不影响主流程(self):
        """TC-TESTAGENT-NOTIFY-FAIL-001: 通知失败不影响主流程"""
        response = requests.post(
            f"{BASE_URL}/api/v1/tests/execute",
            json={
                "project": "test-project",
                "version": "v1.0.0",
                "test_type": "unit"
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code in [200, 201]
        assert "test_id" in response.json() or "status" in response.json()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
