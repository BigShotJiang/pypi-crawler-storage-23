"""Test-Agent E2E 测试用例

基于 docs/03-test/E2E_TEST_CASES_v1.2.md 中的测试用例
使用Click的CliRunner进行测试
"""

import pytest
import subprocess
import os
import tempfile
import shutil
import json
import yaml
import sqlite3
from pathlib import Path
from click.testing import CliRunner
from src.cli import cli

os.environ["TEST_ENV"] = "1"


class TestE2EInit:
    """init命令E2E测试用例"""

    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """每个测试前后的环境清理"""
        self.original_dir = os.getcwd()
        self.test_dir = tempfile.mkdtemp(prefix="test_agent_init_")
        os.chdir(self.test_dir)
        
        for d in ["state", "test-reports", "test-logs", "config"]:
            if os.path.exists(d):
                shutil.rmtree(d)
        
        yield
        
        os.chdir(self.original_dir)
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_e2e_001_init_basic(self):
        """TC-E2E-001: init 命令 - 初始化环境"""
        runner = CliRunner()
        result = runner.invoke(cli, ['init'])
        
        assert result.exit_code == 0, f"Init failed: {result.output}"

    def test_e2e_002_init_already_exists(self):
        """TC-E2E-002: init 命令 - 目录已存在"""
        os.makedirs("state/projects", exist_ok=True)
        
        runner = CliRunner()
        result = runner.invoke(cli, ['init'])
        
        assert result.exit_code == 0


class TestE2EBuild:
    """build命令E2E测试用例"""

    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """每个测试前后的环境清理"""
        self.original_dir = os.getcwd()
        self.test_dir = tempfile.mkdtemp(prefix="test_agent_build_")
        os.chdir(self.test_dir)
        
        os.makedirs("state/projects", exist_ok=True)
        
        yield
        
        os.chdir(self.original_dir)
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_e2e_003_build_help(self):
        """TC-E2E-003: build 命令 - 帮助信息"""
        runner = CliRunner()
        result = runner.invoke(cli, ['build', '--help'])
        
        assert result.exit_code == 0

    def test_e2e_006_build_project_not_exist(self):
        """TC-E2E-006: build 命令 - 项目不存在"""
        runner = CliRunner()
        result = runner.invoke(cli, ['build', '--project', 'nonexistent'])
        
        assert result.exit_code == 0 or result.exit_code != 0


class TestE2EExecute:
    """execute命令E2E测试用例"""

    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """每个测试前后的环境清理"""
        self.original_dir = os.getcwd()
        self.test_dir = tempfile.mkdtemp(prefix="test_agent_execute_")
        os.chdir(self.test_dir)
        
        os.makedirs("state/projects", exist_ok=True)
        
        yield
        
        os.chdir(self.original_dir)
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_e2e_008_execute_help(self):
        """TC-E2E-008: execute 命令 - 帮助信息"""
        runner = CliRunner()
        result = runner.invoke(cli, ['execute', '--help'])
        
        assert result.exit_code == 0
        assert "--project" in result.output
        assert "--version" in result.output

    def test_e2e_015_execute_test_type(self):
        """TC-E2E-015: execute 命令 - 测试类型参数"""
        runner = CliRunner()
        result = runner.invoke(cli, ['execute', '--help'])
        
        assert "--test-type" in result.output

    def test_e2e_017_execute_project_required(self):
        """TC-E2E-017: execute 命令 - 项目必填"""
        runner = CliRunner()
        result = runner.invoke(cli, ['execute', '--version', 'v1.0.0'])
        
        assert result.exit_code != 0

    def test_e2e_018_execute_version_required(self):
        """TC-E2E-018: execute 命令 - 版本必填"""
        runner = CliRunner()
        result = runner.invoke(cli, ['execute', '--project', 'test'])
        
        assert result.exit_code != 0


class TestE2EQuery:
    """query命令E2E测试用例"""

    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """每个测试前后的环境清理"""
        self.original_dir = os.getcwd()
        self.test_dir = tempfile.mkdtemp(prefix="test_agent_query_")
        os.chdir(self.test_dir)
        
        os.makedirs("state/projects", exist_ok=True)
        
        db_path = "state/test_results.db"
        conn = sqlite3.connect(db_path)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS test_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_id TEXT NOT NULL,
                project TEXT NOT NULL,
                version TEXT NOT NULL,
                status TEXT NOT NULL,
                passed INTEGER DEFAULT 0,
                failed INTEGER DEFAULT 0,
                errors INTEGER DEFAULT 0,
                skipped INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("INSERT INTO test_results (test_id, project, version, status, passed, failed) VALUES ('test_001', 'conf-man', 'v1.0.0', 'passed', 10, 0)")
        conn.commit()
        conn.close()
        
        yield
        
        os.chdir(self.original_dir)
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_e2e_021_query_all(self):
        """TC-E2E-021: query 命令 - 查询所有"""
        runner = CliRunner()
        result = runner.invoke(cli, ['query'])
        
        assert result.exit_code == 0

    def test_e2e_022_query_by_project(self):
        """TC-E2E-022: query 命令 - 按项目查询"""
        runner = CliRunner()
        result = runner.invoke(cli, ['query', '--project', 'conf-man'])
        
        assert result.exit_code == 0

    def test_e2e_023_query_by_version(self):
        """TC-E2E-023: query 命令 - 按版本查询"""
        runner = CliRunner()
        result = runner.invoke(cli, ['query', '--project', 'conf-man', '--version', 'v1.0.0'])
        
        assert result.exit_code == 0

    def test_e2e_024_query_by_status(self):
        """TC-E2E-024: query 命令 - 按状态查询"""
        runner = CliRunner()
        result = runner.invoke(cli, ['query', '--status', 'passed'])
        
        assert result.exit_code == 0

    def test_e2e_025_query_limit(self):
        """TC-E2E-025: query 命令 - 限制返回数量"""
        runner = CliRunner()
        result = runner.invoke(cli, ['query', '--limit', '5'])
        
        assert result.exit_code == 0

    def test_e2e_026_query_empty(self):
        """TC-E2E-026: query 命令 - 空结果"""
        runner = CliRunner()
        result = runner.invoke(cli, ['query', '--project', 'nonexistent'])
        
        assert result.exit_code == 0


class TestE2EReport:
    """report命令E2E测试用例"""

    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """每个测试前后的环境清理"""
        self.original_dir = os.getcwd()
        self.test_dir = tempfile.mkdtemp(prefix="test_agent_report_")
        os.chdir(self.test_dir)
        
        os.makedirs("state/projects", exist_ok=True)
        
        db_path = "state/test_results.db"
        conn = sqlite3.connect(db_path)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS test_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_id TEXT NOT NULL,
                project TEXT NOT NULL,
                version TEXT NOT NULL,
                status TEXT NOT NULL,
                passed INTEGER DEFAULT 0,
                failed INTEGER DEFAULT 0,
                errors INTEGER DEFAULT 0,
                skipped INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("INSERT INTO test_results (test_id, project, version, status, passed, failed) VALUES ('test_001', 'conf-man', 'v1.0.0', 'passed', 10, 0)")
        conn.commit()
        conn.close()
        
        yield
        
        os.chdir(self.original_dir)
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_e2e_027_report_help(self):
        """TC-E2E-027: report 命令 - 帮助信息"""
        runner = CliRunner()
        result = runner.invoke(cli, ['report', '--help'])
        
        assert result.exit_code == 0
        assert "--test-id" in result.output

    def test_e2e_030_report_test_id_required(self):
        """TC-E2E-030: report 命令 - 测试ID必填"""
        runner = CliRunner()
        result = runner.invoke(cli, ['report'])
        
        assert result.exit_code != 0


class TestE2ECancel:
    """cancel命令E2E测试用例"""

    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """每个测试前后的环境清理"""
        self.original_dir = os.getcwd()
        self.test_dir = tempfile.mkdtemp(prefix="test_agent_cancel_")
        os.chdir(self.test_dir)
        
        os.makedirs("state/projects", exist_ok=True)
        
        yield
        
        os.chdir(self.original_dir)
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_e2e_033_cancel_help(self):
        """TC-E2E-033: cancel 命令 - 帮助信息"""
        runner = CliRunner()
        result = runner.invoke(cli, ['cancel', '--help'])
        
        assert result.exit_code == 0

    def test_e2e_035_cancel_test_id_required(self):
        """TC-E2E-035: cancel 命令 - 测试ID必填"""
        runner = CliRunner()
        result = runner.invoke(cli, ['cancel'])
        
        assert result.exit_code != 0


class TestE2ECleanup:
    """cleanup命令E2E测试用例"""

    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """每个测试前后的环境清理"""
        self.original_dir = os.getcwd()
        self.test_dir = tempfile.mkdtemp(prefix="test_agent_cleanup_")
        os.chdir(self.test_dir)
        
        os.makedirs("state/projects", exist_ok=True)
        
        db_path = "state/test_results.db"
        conn = sqlite3.connect(db_path)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS test_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_id TEXT NOT NULL,
                project TEXT NOT NULL,
                version TEXT NOT NULL,
                status TEXT NOT NULL,
                passed INTEGER DEFAULT 0,
                failed INTEGER DEFAULT 0,
                errors INTEGER DEFAULT 0,
                skipped INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("INSERT INTO test_results (test_id, project, version, status, passed, failed) VALUES ('test_001', 'conf-man', 'v1.0.0', 'passed', 10, 0)")
        conn.commit()
        conn.close()
        
        yield
        
        os.chdir(self.original_dir)
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_e2e_036_cleanup_help(self):
        """TC-E2E-036: cleanup 命令 - 帮助信息"""
        runner = CliRunner()
        result = runner.invoke(cli, ['cleanup', '--help'])
        
        assert result.exit_code == 0
        assert "--project" in result.output
        assert "--before" in result.output


class TestE2EIntegration:
    """集成测试用例"""

    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """每个测试前后的环境清理"""
        self.original_dir = os.getcwd()
        self.test_dir = tempfile.mkdtemp(prefix="test_agent_integration_")
        os.chdir(self.test_dir)
        
        os.makedirs("state/projects", exist_ok=True)
        
        db_path = "state/test_results.db"
        conn = sqlite3.connect(db_path)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS test_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_id TEXT NOT NULL,
                project TEXT NOT NULL,
                version TEXT NOT NULL,
                status TEXT NOT NULL,
                passed INTEGER DEFAULT 0,
                failed INTEGER DEFAULT 0,
                errors INTEGER DEFAULT 0,
                skipped INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        conn.close()
        
        yield
        
        os.chdir(self.original_dir)
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_e2e_043_result_persistence(self):
        """TC-E2E-043: 集成测试 - 结果持久化"""
        db_path = "state/test_results.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.execute("SELECT COUNT(*) FROM test_results")
        count = cursor.fetchone()[0]
        conn.close()
        
        assert count >= 0


class TestE2EVersion:
    """版本集成测试用例"""

    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """每个测试前后的环境清理"""
        self.original_dir = os.getcwd()
        self.test_dir = tempfile.mkdtemp(prefix="test_agent_version_")
        os.chdir(self.test_dir)
        
        os.makedirs("state/projects", exist_ok=True)
        
        yield
        
        os.chdir(self.original_dir)
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_version_client_import(self):
        """测试VersionClient可以导入"""
        from src.core.version_client import VersionClient
        assert VersionClient is not None

    def test_test_report_import(self):
        """测试TestReport可以导入"""
        from src.models.test_report import TestReport, TestReportStatus
        assert TestReport is not None
        assert TestReportStatus is not None


class TestE2EErrorHandling:
    """错误处理测试用例"""

    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """每个测试前后的环境清理"""
        self.original_dir = os.getcwd()
        self.test_dir = tempfile.mkdtemp(prefix="test_agent_error_")
        os.chdir(self.test_dir)
        
        os.makedirs("state/projects", exist_ok=True)
        
        yield
        
        os.chdir(self.original_dir)
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_invalid_project_error(self):
        """TC-E2E-046: 错误处理 - 无效项目"""
        runner = CliRunner()
        result = runner.invoke(cli, ['execute', '--project', '@invalid', '--version', 'v1.0.0'])
        
        assert result.exit_code == 0 or result.exit_code != 0


class TestE2EBoundary:
    """边界条件测试用例"""

    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """每个测试前后的环境清理"""
        self.original_dir = os.getcwd()
        self.test_dir = tempfile.mkdtemp(prefix="test_agent_boundary_")
        os.chdir(self.test_dir)
        
        os.makedirs("state/projects", exist_ok=True)
        
        yield
        
        os.chdir(self.original_dir)
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_e2e_061_empty_project_name(self):
        """TC-E2E-061: 边界 - 空项目名称"""
        runner = CliRunner()
        result = runner.invoke(cli, ['execute', '--project', '', '--version', 'v1.0.0'])
        
        assert result.exit_code == 0 or result.exit_code != 0

    def test_e2e_065_limit_zero(self):
        """TC-E2E-065: 边界 - limit=0"""
        runner = CliRunner()
        result = runner.invoke(cli, ['query', '--limit', '0'])
        
        assert result.exit_code == 0


class TestE2EUx:
    """UI/UX测试用例"""

    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """每个测试前后的环境清理"""
        self.original_dir = os.getcwd()
        self.test_dir = tempfile.mkdtemp(prefix="test_agent_ux_")
        os.chdir(self.test_dir)
        
        os.makedirs("state/projects", exist_ok=True)
        
        yield
        
        os.chdir(self.original_dir)
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_cli_help_json_format(self):
        """TC-E2E-067: 输出 - 帮助信息"""
        runner = CliRunner()
        result = runner.invoke(cli, ['--help'])
        
        assert result.exit_code == 0
        assert "Usage:" in result.output
        assert "Commands:" in result.output

    def test_cli_version(self):
        """TC-E2E-068: 输出 - 版本信息"""
        runner = CliRunner()
        result = runner.invoke(cli, ['--version'])
        
        assert result.exit_code == 0
