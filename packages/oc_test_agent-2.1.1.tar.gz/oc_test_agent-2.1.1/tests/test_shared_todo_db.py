"""
F-NF-003: 统一数据库路径测试

测试SharedTodoDB多级路径查找机制
"""

import pytest
import os
from pathlib import Path
from unittest.mock import patch, MagicMock

os.environ["OC_SKIP_SKILL_CHECK"] = "1"


class TestSharedTodoDB:
    """统一数据库路径测试"""

    def test_import_shared_todo_db(self):
        """TC-F-NF-003-00: 导入SharedTodoDB类"""
        try:
            from src.core.shared_todo_db import SharedTodoDB
            assert SharedTodoDB is not None
        except ImportError:
            pytest.skip("SharedTodoDB not implemented yet")

    def test_env_variable_override(self, monkeypatch):
        """TC-F-NF-003-01: 环境变量OC_TODO_DB_PATH支持"""
        test_path = "/tmp/test_todos.db"
        monkeypatch.setenv("OC_TODO_DB_PATH", test_path)
        
        try:
            from src.core.shared_todo_db import SharedTodoDB
            client = SharedTodoDB()
            assert str(client.db_path) == test_path
        except (ImportError, TypeError):
            pytest.skip("SharedTodoDB not fully implemented")

    def test_confman_path_fallback(self):
        """TC-F-NF-003-02: conf-man路径回退"""
        try:
            from src.core.shared_todo_db import SharedTodoDB
            with patch.dict(os.environ, {}, clear=False):
                if "OC_TODO_DB_PATH" in os.environ:
                    del os.environ["OC_TODO_DB_PATH"]
                client = SharedTodoDB()
                assert client.db_path is not None
        except (ImportError, TypeError):
            pytest.skip("SharedTodoDB not fully implemented")

    def test_default_path_fallback(self):
        """TC-F-NF-003-03: 默认路径回退"""
        try:
            from src.core.shared_todo_db import SharedTodoDB
            with patch.dict(os.environ, {}, clear=False):
                if "OC_TODO_DB_PATH" in os.environ:
                    del os.environ["OC_TODO_DB_PATH"]
                client = SharedTodoDB()
                expected = Path("state/todos.db")
                assert str(client.db_path) == str(expected) or str(client.db_path).endswith("todos.db")
        except (ImportError, TypeError):
            pytest.skip("SharedTodoDB not fully implemented")

    def test_priority_fallback(self, monkeypatch):
        """TC-F-NF-003-04: 环境变量优先级最高"""
        env_path = "/tmp/env_todos.db"
        monkeypatch.setenv("OC_TODO_DB_PATH", env_path)
        
        try:
            from src.core.shared_todo_db import SharedTodoDB
            client = SharedTodoDB()
            assert str(client.db_path) == env_path
        except (ImportError, TypeError):
            pytest.skip("SharedTodoDB not fully implemented")


class TestSharedTodoDBErrors:
    """统一数据库异常处理"""

    def test_invalid_path_error(self):
        """TC-F-NF-003-05: 无效路径的错误处理"""
        try:
            from src.core.shared_todo_db import SharedTodoDB
            with patch('pathlib.Path.exists', return_value=False):
                client = SharedTodoDB()
                assert client.db_path is not None
        except (ImportError, TypeError):
            pytest.skip("SharedTodoDB not fully implemented")
