"""
通知模块单元测试 - WebSocket扩展
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock
from src.core.notification.websocket import WebSocketManager


class TestWebSocketManagerFull:
    """WebSocket管理器完整测试"""
    
    @pytest.mark.asyncio
    async def test_websocket_manager_connect_disconnect(self):
        """测试连接和断开"""
        manager = WebSocketManager()
        mock_ws = AsyncMock()
        
        await manager.connect(mock_ws, "tests")
        assert "tests" in manager.active_connections
        
        manager.disconnect(mock_ws, "tests")
        assert mock_ws not in manager.active_connections.get("tests", set())
    
    @pytest.mark.asyncio
    async def test_websocket_send_to_channel(self):
        """测试向频道发送消息"""
        manager = WebSocketManager()
        mock_ws = AsyncMock()
        manager.active_connections["tests"] = {mock_ws}
        
        await manager.send_message({"test": "message"}, "tests")
        
        mock_ws.send_json.assert_called_once_with({"test": "message"})
    
    @pytest.mark.asyncio
    async def test_websocket_broadcast_test_result(self):
        """测试广播测试结果"""
        manager = WebSocketManager()
        mock_ws1 = AsyncMock()
        mock_ws2 = AsyncMock()
        manager.active_connections["tests"] = {mock_ws1, mock_ws2}
        
        test_result = {
            "test_id": "test_123",
            "status": "passed"
        }
        
        await manager.broadcast_test_update(test_result)
        
        mock_ws1.send_json.assert_called()
        mock_ws2.send_json.assert_called()
    
    @pytest.mark.asyncio
    async def test_websocket_remove_disconnected(self):
        """测试移除断开的连接"""
        manager = WebSocketManager()
        mock_ws = AsyncMock()
        mock_ws.send_json.side_effect = Exception("Connection closed")
        manager.active_connections["tests"] = {mock_ws}
        
        await manager.send_message({"test": "data"}, "tests")
        
        assert mock_ws not in manager.active_connections.get("tests", set())
    
    def test_websocket_multiple_channels(self):
        """测试多个频道"""
        manager = WebSocketManager()
        
        assert "channel1" not in manager.active_connections
        assert "channel2" not in manager.active_connections
    
    @pytest.mark.asyncio
    async def test_websocket_send_nonexistent_channel(self):
        """测试向不存在的频道发送"""
        manager = WebSocketManager()
        
        await manager.send_message({"test": "data"}, "nonexistent")
        
        assert "nonexistent" not in manager.active_connections
