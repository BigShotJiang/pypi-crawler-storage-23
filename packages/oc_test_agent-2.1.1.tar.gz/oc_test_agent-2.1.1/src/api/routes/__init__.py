"""API Routes - Route aggregation"""

from .health import router as health_router
from .tests import router as tests_router
from .projects import router as projects_router
from .agents import router as agents_router
from .notifications import router as notifications_router
from .webhook import router as webhook_router

__all__ = ["health_router", "tests_router", "projects_router", "agents_router", "notifications_router", "webhook_router"]
