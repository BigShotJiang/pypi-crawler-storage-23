"""Health check route - No authentication required"""

from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
async def health_check():
    """Health check endpoint - no authentication required"""
    return {
        "status": "ok",
        "version": "1.3.0"
    }
