"""Pydantic models for API"""

from typing import Optional
from pydantic import BaseModel


class HealthResponse(BaseModel):
    status: str
    version: str


class TestExecuteRequest(BaseModel):
    project: str
    version: str
    test_type: str = "all"
    agents: Optional[list] = None
    commands: Optional[list] = None
    timeout: int = 3600


class TestExecuteResponse(BaseModel):
    test_id: str
    status: str
    created_at: str


class TestDetailResponse(BaseModel):
    test_id: str
    project: str
    version: str
    status: str
    passed: int
    failed: int
    errors: int
    total: int
    duration: Optional[float] = None
    created_at: Optional[str] = None


class TestListResponse(BaseModel):
    tests: list
    total: int


class ProjectCreateRequest(BaseModel):
    project_id: str
    name: str
    config: Optional[dict] = None


class ProjectResponse(BaseModel):
    project_id: str
    name: str
    created_at: str


class AgentCreateRequest(BaseModel):
    agent_id: str
    name: Optional[str] = None
    metadata: Optional[dict] = None


class AgentResponse(BaseModel):
    agent_id: str
    name: str
    status: str
    created_at: str
