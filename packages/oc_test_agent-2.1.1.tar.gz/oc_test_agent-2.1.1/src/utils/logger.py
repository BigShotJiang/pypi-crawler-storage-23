"""日志工具模块。"""

import logging
import json
from pathlib import Path
from datetime import datetime
from typing import Optional


class LogManager:
    """日志管理器。"""
    
    def __init__(self, log_dir: Path):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self._loggers = {}
    
    def get_logger(self, name: str, log_file: Optional[str] = None) -> logging.Logger:
        """获取Logger实例。
        
        Args:
            name: Logger名称
            log_file: 日志文件名
            
        Returns:
            Logger实例
        """
        if name in self._loggers:
            return self._loggers[name]
        
        logger = logging.getLogger(name)
        logger.setLevel(logging.DEBUG)
        
        if log_file:
            file_handler = logging.FileHandler(self.log_dir / log_file)
            file_handler.setLevel(logging.DEBUG)
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        
        self._loggers[name] = logger
        return logger
    
    def log_error(self, project_id: str, agent_id: str, error_code: str, 
                  message: str, details: dict = None) -> None:
        """记录错误日志。
        
        Args:
            project_id: 项目ID
            agent_id: Agent ID
            error_code: 错误码
            message: 错误消息
            details: 详细错误信息
        """
        log_data = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": "ERROR",
            "source": "test-agent",
            "project_id": project_id,
            "agent_id": agent_id,
            "error_code": error_code,
            "message": message,
            "details": details or {}
        }
        
        error_log = self.log_dir / project_id / "error.log"
        error_log.parent.mkdir(parents=True, exist_ok=True)
        
        with open(error_log, 'a', encoding='utf-8') as f:
            f.write(json.dumps(log_data, ensure_ascii=False) + "\n")
    
    def log_test_result(self, project_id: str, agent_id: str, 
                        result: dict) -> None:
        """记录测试结果。
        
        Args:
            project_id: 项目ID
            agent_id: Agent ID
            result: 测试结果
        """
        result_file = self.log_dir / project_id / f"{agent_id}_result.json"
        result_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(result_file, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
