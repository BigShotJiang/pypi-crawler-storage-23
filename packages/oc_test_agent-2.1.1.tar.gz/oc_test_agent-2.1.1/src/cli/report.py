import click

from ..db.database import Database
from ..core.result_service import ResultService
from ..core.report_service import ReportService


@click.command()
@click.option('--test-id', required=True, help='测试 ID')
@click.option('--format', default='markdown', type=click.Choice(['markdown', 'html', 'json']), help='报告格式')
@click.option('--output', help='输出文件路径')
def report(test_id, format, output):
    """生成测试报告"""
    
    db = Database.get_instance()
    db.init_schema()
    
    result_svc = ResultService()
    result = result_svc.get(test_id)
    
    if not result:
        click.echo(f"Error: 测试 {test_id} 不存在", err=True)
        return
    
    report_svc = ReportService()
    
    if output:
        path = report_svc.save(result, output, format)
        click.echo(f"Report saved to {path}")
    else:
        content = report_svc.generate(result, format)
        click.echo(content)
