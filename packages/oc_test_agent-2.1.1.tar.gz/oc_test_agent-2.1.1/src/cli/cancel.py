import click

from ..db.database import Database
from ..core.result_service import ResultService


@click.command()
@click.option('--test-id', required=True, help='测试 ID')
def cancel(test_id):
    """取消正在执行的测试"""
    
    db = Database.get_instance()
    db.init_schema()
    
    result_svc = ResultService()
    result = result_svc.get(test_id)
    
    if not result:
        click.echo(f"Error: 测试 {test_id} 不存在", err=True)
        return
    
    from ..models.test_result import TestStatus
    
    if result.status != TestStatus.RUNNING:
        click.echo(f"Error: 测试状态为 {result.status.value}，无法取消", err=True)
        return
    
    from ..core.docker_service import DockerService
    docker = DockerService()
    
    if result.container_id:
        docker.stop_container(result.container_id)
    
    result_svc.repo.update_status(test_id, TestStatus.CANCELLED)
    
    click.echo(f"Test {test_id} cancelled")
