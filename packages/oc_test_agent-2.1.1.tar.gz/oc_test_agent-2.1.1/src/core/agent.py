"""Agent管理模块。"""

import os
import json
import multiprocessing
from pathlib import Path
from typing import Optional
from datetime import datetime

from ..utils.errors import (
    ValidationError,
    AgentExistsError,
    AgentNotFoundError,
    PoolFullError
)

# 环境变量配置
OC_STATE_DIR = os.environ.get('OC_STATE_DIR', 'state')
OC_AGENTS_DIR = os.environ.get('OC_AGENTS_DIR', os.path.join(OC_STATE_DIR, 'agents'))


class AgentManager:
    """测试Agent管理器。"""
    
    def __init__(self, base_path: str = None, max_workers: int = 5):
        base_path = base_path or OC_AGENTS_DIR
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        self.max_workers = max_workers
        self._agent_pool = None
        self._running_agents = {}
    
    def register(self, agent_id: str, metadata: Optional[dict] = None) -> tuple[bool, str]:
        """注册Agent。
        
        Args:
            agent_id: Agent ID (带test_前缀)
            metadata: Agent元数据
            
        Returns:
            (成功标志, 消息)
        """
        if not agent_id.startswith('test_'):
            raise ValidationError("T004: Agent ID必须以test_开头")
        
        agent_file = self.base_path / f"{agent_id}.json"
        if agent_file.exists():
            raise AgentExistsError("T006: Agent已注册")
        
        agent_data = {
            "agent_id": agent_id,
            "status": "idle",
            "registered_at": datetime.utcnow().isoformat(),
            "last_heartbeat": datetime.utcnow().isoformat(),
            "metadata": metadata or {
                "name": agent_id,
                "capabilities": ["unit_test", "integration_test"],
                "python_version": "3.10+",
                "max_workers": self.max_workers
            },
            "current_project": None
        }
        
        with open(agent_file, 'w', encoding='utf-8') as f:
            json.dump(agent_data, f, ensure_ascii=False, indent=2)
        
        return True, f"Agent {agent_id} 注册成功"
    
    def unregister(self, agent_id: str) -> tuple[bool, str]:
        """注销Agent。
        
        Args:
            agent_id: Agent ID
            
        Returns:
            (成功标志, 消息)
            
        Raises:
            AgentNotFoundError: Agent未注册
        """
        agent_file = self.base_path / f"{agent_id}.json"
        if not agent_file.exists():
            raise AgentNotFoundError("T005: Agent未注册")
        
        if agent_id in self._running_agents:
            self._running_agents.pop(agent_id)
        
        agent_file.unlink()
        
        return True, f"Agent {agent_id} 已注销"
    
    def get_status(self, agent_id: str) -> str:
        """获取Agent状态。
        
        Args:
            agent_id: Agent ID
            
        Returns:
            状态: idle | running | stopped
            
        Raises:
            AgentNotFoundError: Agent未注册
        """
        agent_file = self.base_path / f"{agent_id}.json"
        if not agent_file.exists():
            raise AgentNotFoundError("T005: Agent未注册")
        
        with open(agent_file, 'r', encoding='utf-8') as f:
            agent_data = json.load(f)
        
        return agent_data.get("status", "idle")
    
    def get(self, agent_id: str) -> dict:
        """获取Agent信息。
        
        Args:
            agent_id: Agent ID
            
        Returns:
            Agent信息字典
        """
        agent_file = self.base_path / f"{agent_id}.json"
        if not agent_file.exists():
            raise AgentNotFoundError("T005: Agent未注册")
        
        with open(agent_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def update_status(self, agent_id: str, status: str, project_id: Optional[str] = None) -> None:
        """更新Agent状态。
        
        Args:
            agent_id: Agent ID
            status: 新状态
            project_id: 当前项目ID
        """
        agent_data = self.get(agent_id)
        agent_data["status"] = status
        agent_data["last_heartbeat"] = datetime.utcnow().isoformat()
        
        if project_id is not None:
            agent_data["current_project"] = project_id
        
        agent_file = self.base_path / f"{agent_id}.json"
        with open(agent_file, 'w', encoding='utf-8') as f:
            json.dump(agent_data, f, ensure_ascii=False, indent=2)
    
    def list_all(self) -> list[dict]:
        """列出所有Agent。
        
        Returns:
            Agent列表
        """
        agents = []
        for agent_file in self.base_path.glob("*.json"):
            with open(agent_file, 'r', encoding='utf-8') as f:
                agents.append(json.load(f))
        return agents
    
    def init_pool(self):
        """初始化Agent进程池。
        
        Returns:
            进程池实例
        """
        if self._agent_pool is None:
            self._agent_pool = multiprocessing.Pool(processes=self.max_workers)
        return self._agent_pool
    
    def get_pool_status(self) -> dict:
        """获取进程池状态。
        
        Returns:
            池状态信息
        """
        running_count = len(self._running_agents)
        return {
            "max_workers": self.max_workers,
            "running": running_count,
            "available": self.max_workers - running_count,
            "is_full": running_count >= self.max_workers
        }
    
    def is_pool_available(self) -> bool:
        """检查进程池是否可用。
        
        Returns:
            是否可以分配新Agent
        """
        return len(self._running_agents) < self.max_workers
    
    def assign_process(self, agent_id: str, process) -> None:
        """分配进程给Agent。
        
        Args:
            agent_id: Agent ID
            process: 进程对象
        """
        self._running_agents[agent_id] = process
        self.update_status(agent_id, "running")
    
    def release_process(self, agent_id: str) -> None:
        """释放Agent的进程。
        
        Args:
            agent_id: Agent ID
        """
        if agent_id in self._running_agents:
            self._running_agents.pop(agent_id)
        self.update_status(agent_id, "idle")
    
    def cleanup(self) -> None:
        """清理进程池资源。"""
        if self._agent_pool is not None:
            self._agent_pool.close()
            self._agent_pool.join()
            self._agent_pool = None
        self._running_agents.clear()
