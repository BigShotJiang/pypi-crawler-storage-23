from pathlib import Path
import logging
import json

from ..models.test_result import TestResult

logger = logging.getLogger(__name__)


class ReportService:
    """测试报告服务"""
    
    def __init__(self):
        pass
    
    def generate(
        self,
        result: TestResult,
        format: str = "markdown"
    ) -> str:
        """生成测试报告"""
        if format == "markdown":
            return self._generate_markdown(result)
        elif format == "html":
            return self._generate_html(result)
        elif format == "json":
            return self._generate_json(result)
        else:
            raise ValueError(f"Unsupported format: {format}")
    
    def _generate_markdown(self, result: TestResult) -> str:
        """生成 Markdown 报告"""
        lines = [
            f"# 测试报告",
            "",
            f"**项目**: {result.project}",
            f"**版本**: {result.version}",
            f"**测试类型**: {result.test_type}",
            f"**状态**: {result.status.value.upper()}",
        ]
        
        if result.duration:
            lines.append(f"**执行时间**: {result.duration:.2f}s")
        
        lines.extend([
            f"**通过**: {result.passed}",
            f"**失败**: {result.failed}",
            f"**错误**: {result.errors}",
            f"**总计**: {result.total}",
            "",
            "---",
            "",
            "## 测试详情",
            ""
        ])
        
        if result.failed > 0 or result.errors > 0:
            lines.extend([
                "### 失败用例",
                "（详细信息需要从测试日志中提取）",
                ""
            ])
        
        return "\n".join(lines)
    
    def _generate_html(self, result: TestResult) -> str:
        """生成 HTML 报告"""
        html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Test Report - {result.project}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        .summary {{ background: #f5f5f5; padding: 15px; border-radius: 5px; }}
        .passed {{ color: green; }}
        .failed {{ color: red; }}
        .error {{ color: orange; }}
    </style>
</head>
<body>
    <h1>测试报告</h1>
    <div class="summary">
        <p><strong>项目:</strong> {result.project}</p>
        <p><strong>版本:</strong> {result.version}</p>
        <p><strong>状态:</strong> <span class="{result.status.value}">{result.status.value.upper()}</span></p>
        <p><strong>通过:</strong> {result.passed}</p>
        <p><strong>失败:</strong> {result.failed}</p>
        <p><strong>错误:</strong> {result.errors}</p>
    </div>
</body>
</html>
"""
        return html
    
    def _generate_json(self, result: TestResult) -> str:
        """生成 JSON 报告"""
        return json.dumps(result.to_dict(), indent=2)
    
    def save(self, result: TestResult, output_path: str, format: str = "markdown") -> str:
        """保存报告到文件"""
        content = self.generate(result, format)
        
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding='utf-8')
        
        logger.info(f"Report saved to {output_path}")
        return str(path)
