import uuid
import os
import logging
import asyncio
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict
import re

from ..db.database import Database, TEST_RESULTS_DB_PATH
from ..db.repositories.result_repo import ResultRepository
from ..models.test_result import TestResult, TestStatus
from .docker_service import DockerService
from .notification.webhook import get_notification_manager
from .notification.bug_report import get_bug_report_generator

logger = logging.getLogger(__name__)


class TestExecutor:
    """测试执行器"""
    
    def __init__(
        self,
        project: str,
        version: str,
        project_path: str,
        test_type: str = "all",
        test_type_filter: str = "directory",
        timeout: int = 300,
        tag: str = "latest"
    ):
        self.id = f"test_{uuid.uuid4().hex[:12]}"
        self.project = project
        self.version = version
        self.project_path = project_path
        self.test_type = test_type
        self.test_type_filter = test_type_filter
        self.timeout = timeout
        self.tag = tag
        
        self.db = Database.get_instance(TEST_RESULTS_DB_PATH)
        self.repo = ResultRepository(self.db)
        self.docker = DockerService()
        self.container_id: Optional[str] = None
        
    def execute(self) -> TestResult:
        """执行测试"""
        logger.info(f"Starting test execution: {self.id}")
        
        result = TestResult(
            id=self.id,
            project=self.project,
            version=self.version,
            status=TestStatus.RUNNING,
            test_type=self.test_type,
            container_id=None,
            created_at=datetime.now()
        )
        self.repo.insert(result)
        
        try:
            logger.setLevel(logging.DEBUG)
            
            image_tag = f"{self.project}:{self.tag}"
            build_success = self.docker.build_image(
                project_path=self.project_path,
                tag=image_tag
            )
            
            if not build_success:
                raise Exception("Docker image build failed")
            
            env = {
                "TEST_MODE": "true",
                "PROJECT": self.project,
                "VERSION": self.version
            }
            
            self.container_id = self.docker.run_container(
                image=image_tag,
                env=env,
                volumes={self.project_path: {"bind": "/app", "mode": "rw"}}
            )
            
            if not self.container_id:
                raise Exception("Failed to start container")
            
            report_path = self._generate_report_path()
            logs_path = self._generate_logs_path()
            
            self.repo.update_status(
                self.id,
                TestStatus.RUNNING,
                container_id=self.container_id
            )

            import sys
            print("DEBUG: Before wait_container", file=sys.stderr)

            wait_result = self.docker.wait_container(
                self.container_id,
                timeout=self.timeout
            )
            
            import sys
            print("DEBUG: After wait_container, about to get logs", file=sys.stderr)
            
            logs = wait_result.get("logs", "")
            status_code = wait_result.get("status_code", -1)
            
            # 强制输出到stderr
            import sys
            print(f"DEBUG: wait_result keys: {wait_result.keys()}", file=sys.stderr)
            print(f"DEBUG: logs length={len(logs)}, status_code={status_code}", file=sys.stderr)
            if logs:
                logger.info(f"DEBUG: logs preview: {logs[:500]}")
            
            passed, failed, errors, total = self._parse_pytest_output(logs)
            
            logger.info(f"DEBUG: parsed - passed={passed}, failed={failed}, errors={errors}, total={total}")
            
            # 解析并保存每个测试用例的详细记录
            test_cases = self._parse_test_cases(logs)
            if test_cases:
                self._save_test_case_records(test_cases)
                logger.info(f"Saved {len(test_cases)} test case records to database")
            
            if passed > 0 or failed > 0 or errors > 0:
                if failed == 0 and errors == 0:
                    final_status = TestStatus.PASSED
                else:
                    final_status = TestStatus.FAILED
            elif status_code == 0:
                final_status = TestStatus.PASSED
            elif status_code == -1:
                final_status = TestStatus.ERROR
            else:
                final_status = TestStatus.FAILED
            
            logger.info(f"DEBUG: final_status={final_status.value}")
            
            self.repo.update_status(
                self.id,
                final_status,
                duration=wait_result.get("duration", 0),
                passed=passed,
                failed=failed,
                errors=errors,
                total=total,
                report_path=report_path,
                logs_path=logs_path
            )
            
            self._send_notifications(final_status, passed, failed, errors)
            
            logger.info(f"Test completed: {self.id} - {final_status.value}")
            
        except Exception as e:
            import traceback
            import sys
            print(f"EXCEPTION IN TRY BLOCK: {e}", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            logger.error(f"Test execution failed: {e}")
            self.repo.update_status(self.id, TestStatus.ERROR)
            
        finally:
            if self.container_id:
                self.docker.remove_container(self.container_id)
        
        return self.repo.find_by_id(self.id)
    
    def cancel(self) -> bool:
        """取消测试"""
        if self.container_id:
            self.docker.stop_container(self.container_id)
            self.repo.update_status(self.id, TestStatus.CANCELLED)
            return True
        return False
    
    def _parse_pytest_output(self, logs: str) -> tuple:
        """解析 pytest 输出"""
        passed = failed = errors = total = 0
        
        logger.info(f"DEBUG _parse_pytest_output: logs length={len(logs)}")
        
        if not logs:
            logger.warning("DEBUG: Empty logs in _parse_pytest_output")
            return 0, 0, 0, 0
        
        pattern = r'(\d+) passed'
        match = re.search(pattern, logs)
        if match:
            passed = int(match.group(1))
            logger.info(f"DEBUG: matched passed={passed}")
        
        pattern = r'(\d+) failed'
        match = re.search(pattern, logs)
        if match:
            failed = int(match.group(1))
            logger.info(f"DEBUG: matched failed={failed}")
        
        pattern = r'(\d+) error'
        match = re.search(pattern, logs)
        if match:
            errors = int(match.group(1))
            logger.info(f"DEBUG: matched errors={errors}")
        
        total = passed + failed + errors
        
        return passed, failed, errors, total
    
    def _parse_test_cases(self, logs: str) -> list:
        """解析测试用例记录"""
        test_cases = []
        
        for line in logs.split('\n'):
            if 'PASSED' in line or 'FAILED' in line or 'ERROR' in line:
                parts = line.split()
                if parts:
                    test_name = None
                    status = 'passed'
                    
                    for i, part in enumerate(parts):
                        if part == '::' and i > 0:
                            test_name = ' '.join(parts[:i+3] if i+3 <= len(parts) else parts[i:])
                            break
                    
                    if 'PASSED' in line:
                        status = 'passed'
                    elif 'FAILED' in line:
                        status = 'failed'
                    elif 'ERROR' in line:
                        status = 'error'
                    
                    if test_name:
                        test_cases.append({
                            'test_case_name': test_name,
                            'status': status,
                            'duration': 0.0,
                            'requirement_id': None,
                            'agent_id': os.environ.get('OC_AGENT_ID', 'unknown')
                        })
        
        return test_cases
    
    def _save_test_case_records(self, test_cases: list) -> None:
        """保存测试用例记录到数据库"""
        for case in test_cases:
            case['test_id'] = self.id
            self.repo.insert_test_case_record(case)
    
    def _generate_report_path(self) -> str:
        """生成报告路径"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_dir = Path("test-reports") / self.project / f"{self.version}_{timestamp}"
        report_dir.mkdir(parents=True, exist_ok=True)
        return str(report_dir / "report.md")
    
    def _generate_logs_path(self) -> str:
        """生成日志路径"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        logs_dir = Path("test-logs") / self.project / f"{self.version}_{timestamp}"
        logs_dir.mkdir(parents=True, exist_ok=True)
        return str(logs_dir / "container.log")
    
    def _save_logs(self, path: str, content: str) -> None:
        """保存日志"""
        log_path = Path(path)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.write_text(content, encoding='utf-8')
    
    def _send_notifications(self, final_status: TestStatus, passed: int, failed: int, errors: int):
        """发送通知（不阻塞主流程）"""
        try:
            notification_manager = get_notification_manager()
            if notification_manager.webhooks:
                test_result = self.repo.find_by_id(self.id)
                if test_result:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    loop.run_until_complete(notification_manager.notify(test_result))
                    loop.close()
            
            if final_status == TestStatus.FAILED and (failed > 0 or errors > 0):
                test_result = self.repo.find_by_id(self.id)
                if test_result:
                    bug_generator = get_bug_report_generator()
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    loop.run_until_complete(bug_generator.generate_and_send(test_result))
                    loop.close()
        except Exception as e:
            logger.warning(f"发送通知失败: {e}")
