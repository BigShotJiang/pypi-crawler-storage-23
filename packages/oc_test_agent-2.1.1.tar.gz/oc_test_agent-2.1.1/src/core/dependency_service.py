from typing import List, Dict
from pathlib import Path
from collections import defaultdict
import logging

logger = logging.getLogger(__name__)


class CircularDependencyError(Exception):
    """循环依赖异常"""
    pass


class DependencyService:
    """依赖服务"""
    
    def __init__(self):
        pass
    
    def parse_dependencies(self, deps_string: str) -> List[Dict]:
        """解析依赖字符串
        
        格式: name:path:version 或 name:path
        """
        dependencies = []
        
        if not deps_string:
            return dependencies
        
        for dep in deps_string.split(","):
            dep = dep.strip()
            if not dep:
                continue
            
            parts = dep.split(":")
            
            if len(parts) >= 3:
                dependencies.append({
                    "name": parts[0],
                    "path": parts[1],
                    "version": parts[2]
                })
            elif len(parts) == 2:
                dependencies.append({
                    "name": parts[0],
                    "path": parts[1],
                    "version": None
                })
        
        return dependencies
    
    def topological_sort(self, dependencies: List[Dict]) -> List[Dict]:
        """拓扑排序"""
        if not dependencies:
            return []
        return dependencies
    
    def detect_circular(self, dependencies: List[Dict]) -> bool:
        """检测循环依赖"""
        return False
    
    def resolve_version(self, dep: Dict) -> str:
        """解析依赖版本"""
        if dep.get("version"):
            return dep["version"]
        
        dep_path = Path(dep.get("path", ""))
        pyproject = dep_path / "pyproject.toml"
        
        if pyproject.exists():
            try:
                import tomli
                with open(pyproject, "rb") as f:
                    data = tomli.load(f)
                    return data.get("project", {}).get("version", "unknown")
            except Exception as e:
                logger.warning(f"Failed to read version from pyproject: {e}")
        
        return "unknown"
