"""
OcCollab API Client for test-agent to interact with oc-collab HTTP API.

This client provides TODO management capabilities via oc-collab HTTP API.
"""

import os
import json
import logging
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)


class OcCollabAPIError(Exception):
    """Exception raised for oc-collab API errors."""
    pass


class OcCollabClient:
    """Client for interacting with oc-collab HTTP API."""
    
    DEFAULT_BASE_URL = "http://localhost:8000"
    
    def __init__(self, base_url: Optional[str] = None, timeout: int = 30):
        """
        Initialize OcCollabClient.
        
        Args:
            base_url: Base URL for oc-collab API. Defaults to localhost:8000
            timeout: Request timeout in seconds
        """
        self.base_url = base_url or os.environ.get('OC_COLLAB_API_URL', self.DEFAULT_BASE_URL)
        self.timeout = timeout
        self._session = None
    
    def _get_session(self):
        """Get or create HTTP session."""
        if self._session is None:
            import requests
            self._session = requests.Session()
            self._session.headers.update({
                'Content-Type': 'application/json',
                'User-Agent': 'test-agent/1.0'
            })
        return self._session
    
    def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Make HTTP request to oc-collab API."""
        import requests
        
        url = f"{self.base_url}{endpoint}"
        try:
            response = self._session.request(
                method, url, timeout=self.timeout, **kwargs
            )
            response.raise_for_status()
            return response.json() if response.content else {}
        except requests.exceptions.ConnectionError:
            raise OcCollabAPIError(f"Cannot connect to oc-collab API at {self.base_url}")
        except requests.exceptions.Timeout:
            raise OcCollabAPIError(f"Request to {url} timed out")
        except requests.exceptions.HTTPError as e:
            raise OcCollabAPIError(f"HTTP error: {e}")
        except Exception as e:
            raise OcCollabAPIError(f"Request failed: {e}")
    
    # TODO API Methods
    
    def list_todos(
        self,
        status: Optional[str] = None,
        receiver: Optional[str] = None,
        unread_only: bool = False
    ) -> List[Dict[str, Any]]:
        """
        List TODOs.
        
        Args:
            status: Filter by status (pending, completed, etc.)
            receiver: Filter by receiver
            unread_only: Only return unread TODOs
            
        Returns:
            List of TODO objects
        """
        params = {}
        if status:
            params['status'] = status
        if receiver:
            params['receiver'] = receiver
        if unread_only:
            params['unread'] = 'true'
        
        result = self._request('GET', '/api/todo/list', params=params)
        return result.get('todos', [])
    
    def get_todo(self, todo_id: str) -> Dict[str, Any]:
        """
        Get a specific TODO by ID.
        
        Args:
            todo_id: TODO ID
            
        Returns:
            TODO object
        """
        result = self._request('GET', f'/api/todo/{todo_id}')
        return result
    
    def create_todo(
        self,
        content: str,
        receiver: str,
        priority: str = "medium",
        sender: Optional[str] = None,
        source: str = "test-agent"
    ) -> Dict[str, Any]:
        """
        Create a new TODO.
        
        Args:
            content: TODO content
            receiver: Receiver agent ID
            priority: Priority (low, medium, high)
            sender: Sender agent ID (optional)
            source: Source of the TODO
            
        Returns:
            Created TODO object
        """
        data = {
            'content': content,
            'receiver': receiver,
            'priority': priority,
            'source': source
        }
        if sender:
            data['sender'] = sender
        
        result = self._request('POST', '/api/todo/create', json=data)
        return result
    
    def update_todo(
        self,
        todo_id: str,
        content: Optional[str] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update a TODO.
        
        Args:
            todo_id: TODO ID
            content: New content (optional)
            status: New status (optional)
            priority: New priority (optional)
            
        Returns:
            Updated TODO object
        """
        data = {}
        if content:
            data['content'] = content
        if status:
            data['status'] = status
        if priority:
            data['priority'] = priority
        
        result = self._request('PUT', f'/api/todo/{todo_id}', json=data)
        return result
    
    def delete_todo(self, todo_id: str) -> bool:
        """
        Delete a TODO.
        
        Args:
            todo_id: TODO ID
            
        Returns:
            True if successful
        """
        self._request('DELETE', f'/api/todo/{todo_id}')
        return True
    
    def complete_todo(self, todo_id: str, result: str = "") -> Dict[str, Any]:
        """
        Mark a TODO as completed.
        
        Args:
            todo_id: TODO ID
            result: Completion result message
            
        Returns:
            Updated TODO object
        """
        return self.update_todo(todo_id, status='completed')
    
    def mark_read(self, todo_id: str) -> bool:
        """
        Mark a TODO as read.
        
        Args:
            todo_id: TODO ID
            
        Returns:
            True if successful
        """
        self._request('POST', f'/api/todo/{todo_id}/read')
        return True
    
    def acknowledge(self, todo_id: str) -> bool:
        """
        Acknowledge a TODO.
        
        Args:
            todo_id: TODO ID
            
        Returns:
            True if successful
        """
        self._request('POST', f'/api/todo/{todo_id}/ack')
        return True
    
    def is_available(self) -> bool:
        """
        Check if oc-collab API is available.
        
        Returns:
            True if API is reachable
        """
        try:
            import requests
            response = requests.get(f"{self.base_url}/health", timeout=5)
            return response.status_code == 200
        except Exception:
            return False


def get_oc_collab_client() -> OcCollabClient:
    """Get OcCollabClient instance."""
    return OcCollabClient()
