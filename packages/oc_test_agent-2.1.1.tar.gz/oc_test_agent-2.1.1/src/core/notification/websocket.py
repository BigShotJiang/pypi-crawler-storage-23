"""
WebSocket推送模块
"""

from typing import Dict, Set
from fastapi import WebSocket


class WebSocketManager:
    """WebSocket连接管理器"""
    
    def __init__(self):
        self.active_connections: Dict[str, Set[WebSocket]] = {}
    
    async def connect(self, websocket: WebSocket, channel: str = "tests"):
        """建立WebSocket连接"""
        await websocket.accept()
        if channel not in self.active_connections:
            self.active_connections[channel] = set()
        self.active_connections[channel].add(websocket)
    
    def disconnect(self, websocket: WebSocket, channel: str = "tests"):
        """断开WebSocket连接"""
        if channel in self.active_connections:
            self.active_connections[channel].discard(websocket)
    
    async def send_message(self, message: dict, channel: str = "tests"):
        """向指定频道发送消息"""
        if channel not in self.active_connections:
            return
        
        disconnected = set()
        for connection in self.active_connections[channel]:
            try:
                await connection.send_json(message)
            except Exception:
                disconnected.add(connection)
        
        for conn in disconnected:
            self.disconnect(conn, channel)
    
    async def broadcast_test_update(self, test_result: dict):
        """广播测试更新"""
        await self.send_message({
            "type": "test_update",
            "data": test_result
        }, channel="tests")


_websocket_manager: WebSocketManager = None


def get_websocket_manager() -> WebSocketManager:
    """获取WebSocket管理器"""
    global _websocket_manager
    if _websocket_manager is None:
        _websocket_manager = WebSocketManager()
    return _websocket_manager
