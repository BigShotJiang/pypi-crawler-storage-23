"""
缺陷报告生成模块
"""

import uuid
from datetime import datetime
from typing import Dict, Any, Optional
import aiohttp


class BugReportGenerator:
    """缺陷报告生成器"""
    
    def __init__(self, pm_agent_url: str = "http://pm-agent:8003"):
        self.pm_agent_url = pm_agent_url
    
    async def generate_and_send(self, test_result: Any) -> Optional[Dict]:
        """生成并发送缺陷报告"""
        if test_result.failed == 0 and test_result.errors == 0:
            return None
        
        report = self._build_report(test_result)
        await self._send_to_pm_agent(report)
        return report
    
    def _build_report(self, test_result: Any) -> Dict[str, Any]:
        """构建缺陷报告"""
        severity = "high" if test_result.failed > 5 else "medium"
        
        return {
            "title": f"[测试失败] {test_result.project} {test_result.version} - {test_result.failed}个用例失败",
            "description": self._build_description(test_result),
            "severity": severity,
            "labels": ["test-failed", "auto-report"],
            "test_id": test_result.id,
            "source": "test-agent"
        }
    
    def _build_description(self, test_result: Any) -> str:
        """构建报告描述"""
        lines = [
            f"测试执行失败",
            "",
            f"**项目**: {test_result.project}",
            f"**版本**: {test_result.version}",
            f"**测试ID**: {test_result.id}",
            f"**失败用例**: {test_result.failed}",
            f"**错误用例**: {test_result.errors}",
            f"**通过用例**: {test_result.passed}",
            f"**总用例**: {test_result.total}",
            "",
            f"详情: http://test-agent:8004/tests/{test_result.id}"
        ]
        return "\n".join(lines)
    
    async def _send_to_pm_agent(self, report: Dict[str, Any]):
        """发送到pm-agent"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.pm_agent_url}/api/issues",
                    json=report,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as resp:
                    resp.raise_for_status()
        except Exception as e:
            print(f"发送缺陷报告失败: {e}")


_bug_report_generator: Optional[BugReportGenerator] = None


def get_bug_report_generator() -> BugReportGenerator:
    """获取缺陷报告生成器"""
    global _bug_report_generator
    if _bug_report_generator is None:
        _bug_report_generator = BugReportGenerator()
    return _bug_report_generator
