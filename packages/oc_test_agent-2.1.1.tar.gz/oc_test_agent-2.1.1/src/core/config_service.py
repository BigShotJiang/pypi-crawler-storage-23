import os
import re
import yaml
from pathlib import Path
from typing import Optional, Dict


class ConfigService:
    """配置服务"""
    
    def __init__(self, config_dir: str = None):
        config_dir = config_dir or os.environ.get('OC_CONFIG_DIR', 'config')
        self.config_dir = Path(config_dir)
        self.projects = self._load_projects()
        self.cleanup = self._load_cleanup()
        self._conf_man_client = None
    
    def _get_conf_man_client(self):
        """获取conf-man HTTP API客户端"""
        if self._conf_man_client is not None:
            return self._conf_man_client
        
        try:
            from .conf_man_client import get_conf_man_client
            self._conf_man_client = get_conf_man_client()
            return self._conf_man_client
        except Exception as e:
            print(f"Warning: Failed to load conf-man client: {e}")
            self._conf_man_client = None
            return None
    
    def _resolve_conf_man_secret(self, value: str) -> str:
        """解析CONF_MAN_SECRET引用"""
        pattern = r'\$\{CONF_MAN_SECRET:([^}]+)\}'
        match = re.match(pattern, value)
        if match:
            key = match.group(1)
            client = self._get_conf_man_client()
            if client:
                try:
                    secret = client.get_secret(key)
                    if secret:
                        return secret
                    else:
                        print(f"Warning: Secret '{key}' not found in conf-man")
                except Exception as e:
                    print(f"Warning: Failed to get secret '{key}': {e}")
            else:
                print(f"Warning: conf-man client not available")
        return value
    
    def _resolve_config_value(self, value):
        """递归解析配置值中的secret引用"""
        if isinstance(value, str):
            return self._resolve_conf_man_secret(value)
        elif isinstance(value, dict):
            return {k: self._resolve_config_value(v) for k, v in value.items()}
        elif isinstance(value, list):
            return [self._resolve_config_value(item) for item in value]
        return value
    
    def _load_projects(self) -> Dict:
        """加载项目配置"""
        config_file = self.config_dir / "projects.yaml"
        if config_file.exists():
            with open(config_file, 'r') as f:
                data = yaml.safe_load(f)
                return data.get('projects', {})
        return {}
    
    def _load_cleanup(self) -> Dict:
        """加载清理配置"""
        config_file = self.config_dir / "cleanup.yaml"
        if config_file.exists():
            with open(config_file, 'r') as f:
                return yaml.safe_load(f)
        return {}
    
    def get_project_path(self, project: str) -> Optional[str]:
        """获取项目路径"""
        return self.projects.get(project, {}).get('path')
    
    def get_project_config(self, project: str) -> Optional[Dict]:
        """获取项目配置"""
        return self.projects.get(project)
    
    def load_webhook_config(self) -> Dict:
        """加载webhook配置并解析secret引用"""
        config_file = self.config_dir / "webhook.yaml"
        if config_file.exists():
            with open(config_file, 'r') as f:
                data = yaml.safe_load(f)
                return self._resolve_config_value(data)
        return {}
