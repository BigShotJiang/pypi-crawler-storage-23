"""Tsumugi AI Agent — Claude Code-like coding assistant."""

__version__ = "0.3.0"
