# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import subprocess


def test_cli_help():
    # Run the CLI command and capture the output
    result = subprocess.run(["composabl", "--help"], capture_output=True, text=True)

    # Check if the command executed successfully
    assert result.returncode == 0

    # Check if the output does not contain any error message
    assert "Error" not in result.stdout
