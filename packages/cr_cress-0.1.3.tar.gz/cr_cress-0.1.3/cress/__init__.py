############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

import sys, argparse

import cress, cress.startup


def parse_arguments():
    """parse command line arguments from sys.argv and extract those for cress"""
    ## COMMAND LINE ARGUMENTS
    if "--" in sys.argv:
        ind_pass = sys.argv.index("--")
        args = sys.argv[ind_pass + 1 :]
    else:
        args = sys.argv

    parser = argparse.ArgumentParser(
        description="""Crowdrender CRESS agent - a background service that handles connecting
        and comms with other computers all over the world."""
    )

    parser.add_argument(
        "--context",
        required=True,
        default="",
        help="""The mode that should be used to configure this node,
        setting nothing is not allowed. You need to choose "CIP"
        or "SIP" to set the mode of the agent as either a client or
        server process""",
    )

    processed_args = parser.parse_known_args(args=args)

    c_line_args = vars(processed_args[0])

    if not "context" in c_line_args:
        # assume implicit desire to use in client mode
        ret = ""

    else:

        ret = c_line_args["context"]

        if not ret in (
            cress.startup.CLIENT,
            cress.startup.SERVER,
            cress.startup.WORKER,
            cress.startup.REVERSE_PROXY,
        ):
            raise ValueError(
                "Mode selection incorrect, you can choose either client or server_session only."
            )

    return ret


def main():
    # parse command line arguments and start
    cress_context = parse_arguments()
    cress.startup.start_cress(cress_context)


if __name__ == "__main__":
    main()
