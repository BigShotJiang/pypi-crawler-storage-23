############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

import logging, os
from logging.handlers import RotatingFileHandler

import zmq, zmq.asyncio

from cress.event import Event

_loggers: "dict[str, logging.Logger]" = {}
EVENT_NAME = "event_name"

EVENT_BUS_SUB_ADDR = "cress_event_subscriber"  # listening channel for event bus
Z_CTX = (
    zmq.asyncio.Context.instance()
)  # 0MQ context required for generating zmq sockets


class MakeRotatingFileHandler(RotatingFileHandler):
    def __init__(self, dir, filename, mode="a", encoding=None, delay=0):
        os.makedirs(dir, exist_ok=True)
        RotatingFileHandler.__init__(
            self,
            os.path.join(dir, filename),
            maxBytes=5 * 10**6,
            backupCount=1,
            mode=mode,
            encoding=encoding,
            delay=delay,
        )


class EventBusHandler(logging.Handler):
    """
    A class which sends the log message to discovery.

    """

    def __init__(self) -> None:
        """ """
        logging.Handler.__init__(self)
        self.publisher = Z_CTX.socket(zmq.PUB)
        self.publisher.connect(f"inproc://{EVENT_BUS_SUB_ADDR}")
        bonjour_event = Event(b"BONJOUR", b"Logging handler attached to event bus")
        self.publisher.send_multipart(bonjour_event.serialise())

    def emit(self, record: logging.LogRecord) -> None:

        # get the event name from the extras
        event_name = record.__dict__[EVENT_NAME]

        # create an event from the logging data
        logging_event = Event(event_name, bytes(record.msg, "utf-8"))

        coro = self.publisher.send_multipart(logging_event.serialise())
        coro.result()


def get_file_logger(log_name: str, dir: str) -> logging.Logger:
    """Creates a logger that will log to a file in dir"""

    # check first if a log of the same name exists, return it if it does
    if log_name in _loggers:
        logger = _loggers[log_name]

    # otherwise, create a new log using the given name
    else:

        # create the appropriate handler for this log file
        log_file_handler = MakeRotatingFileHandler(
            dir,
            log_name,
        )

        # get a logger
        logger = logging.getLogger(log_name)

        # set log level to info
        logger.setLevel(logging.INFO)

        # assign our event bus handler to the logger
        logger.addHandler(log_file_handler)

    return logger


def get_logger(log_name: str) -> logging.Logger:
    """create an instance of the event bus logger

    This logger pushes a new event to the event bus each time it is used.
    The logger requires an event name as an item in the logging 'extras'
    keyword argument like so

    logger.info('my message', extra={'event name':b'MY_EVENT_NAME'})

    """

    # if the log exists already, get it, don't create another one.
    if log_name in _loggers:
        logger = _loggers[log_name]

    else:

        # get our custom event handler
        event_bus_logger = EventBusHandler()

        # get a logger
        logger = logging.getLogger(log_name)

        # set log level to info
        logger.setLevel(logging.INFO)

        # assign our event bus handler to the logger
        logger.addHandler(event_bus_logger)

    return logger
