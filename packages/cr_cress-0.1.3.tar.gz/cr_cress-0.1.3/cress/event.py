############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

""" class to serialise and deserialise events """
from __future__ import annotations

ALL_STATIONS = b"ALL_STATIONS"
CLIENT_ID = 1
DESTINATION = 3
EVENT_NAME = 0
EVENT_VALUE = 1
LAST = -1
NAME_SEP = b"."
REQUEST = b"REQ"
SIGNATURE = -1
SIG_VERSION = b"CREVNT01"
SOURCE = 2

WORKER_OR_GROUP = 2


class Event:
    """A class for serialisation of events within cress's background services

    This class is responsible for respresnting an event/request within the client/master node's
    event bus. It is also responsible for serialising and deserialising events/requests so other
    services can use this class' methods for that purpose.

    """

    type = b""
    value: bytes

    def __init__(
        self, name: bytes, value: bytes, source: bytes = b"", destination: bytes = b""
    ) -> None:

        # Initialise the event by setting the correct name
        self.name = name
        self.value = value
        self.source = source
        self.destination = destination

    def __repr__(self):

        rep = "".join(
            [
                f"{__name__}(b'",
                self.name.decode("utf-8"),
                "', ",
                self.value.decode("utf-8"),
                " ",
                ")",
            ]
        )

        return rep

    def __str__(self):
        return f"{{ {self.name.decode('utf-8')}, {self.value.decode('utf-8')} }}"

    def __eq__(self, other):

        return all(
            [
                self.name == other.name,
                self.value == other.value,
                self.source == other.source,
                self.destination == other.destination,
            ]
        )

    def serialise(self) -> list[bytes]:
        """Return a serialised form of this event so it can be sent over the network/event bus

        This method is responsible for taking this Event object and returning a
        python list containing byte strings that contain the data for the event/request. This is
        done because a list supports the buffer interface and can be sent using pyzmq's send_multipart
        methods really easily.
        """

        return [self.name, self.value, self.source, self.destination, SIG_VERSION]

    @classmethod
    def deserialise(cls, msg: list[bytes]):
        """return a new Event object from the event/msg argument

        This method is responsible for producing an Event object from a given
        raw message received from the network/event bus.

        The method will raise a MalformedEventError if the number of fields
        contained in the msg argument isn't of the correct length, which is 5.
        It will raise an InvalidEventError if the event signature is missing.
        This provides the protocol with filtering should messages/packets
        be sent to an endpoint in use by this system.

        """

        # check if we've at least got enough segments for a valid event
        if not SIG_VERSION in msg:
            raise InvalidEventError(
                f"{msg} is invalid because it doesn't contain {SIG_VERSION}"
            )
        elif not len(msg) == 5:
            raise MalformedEventError(
                f"{msg} is invalid because it doesn't contain sufficient segments to be valid. There should be 5 segments."
            )

        # Get parts of the event name
        name_parts = msg[EVENT_NAME].rpartition(NAME_SEP)

        if name_parts == msg[EVENT_NAME]:
            # if there is no prefix, then the event name is simply passed through as is.
            event_name = name_parts
        else:
            # otherwise the last part of the received event name is used as the event name
            event_name = name_parts[LAST]

        # create a new instance of this class and pass it the resulting object from above
        return cls(event_name, msg[EVENT_VALUE], msg[SOURCE], msg[DESTINATION])

    def create_reply_event(self, value: bytes = b"") -> Event:
        """Return a serialised and correctly addressed reply to an event with optional value

        This is a convenience method that properly addresses an event so only the
        intended originator will receive it. Note that this filtering is not enforced,
        all entities on the event bus can get any event if they subscribe to all events.

        Arguments:
            value: bytes = an optional replacement value for the reply, otherwise
                            the same value as the original event is used.


        """

        name = b"".join([self.source, NAME_SEP, self.name])

        return Event(name, value or self.value, self.source, self.destination)

    def create_forwarded_event(self, value: bytes = b"") -> Event:
        """Return a serialised and correctly addressed event that will be forwarded to the destination of the original event."""

        name = b"".join([self.destination, NAME_SEP, self.name])

        return Event(name, value or self.value, self.source, self.destination)


def wrap_multipart(data: list[bytes]) -> bytes:
    result = []

    assert len(data) <= 255
    result.append(len(data).to_bytes(1, byteorder="big", signed=False))

    for part in data:
        result.append(len(part).to_bytes(4, byteorder="big", signed=False))
        result.append(part)

    return b"".join(result)


def unwrap_multipart(data: bytes) -> list[bytes]:
    result = []
    i = 0

    parts = int.from_bytes(data[0:1], byteorder="big", signed=False)
    i += 1

    for _ in range(parts):
        part_len = int.from_bytes(data[i : (i + 4)], byteorder="big", signed=False)
        i += 4
        part = data[i : (i + part_len)]
        i += part_len
        result.append(part)

    return result


class InvalidEventError(Exception):
    def __init__(self, message):
        # Call the base class constructor with the parameters it needs
        super().__init__(message)


class MalformedEventError(Exception):
    def __init__(self, message):
        # Call the base class constructor with the parameters it needs
        super().__init__(message)
