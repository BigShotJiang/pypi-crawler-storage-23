############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

""" Event Bus Module

This module implements the event bus for the Client and Server/Worker contexts. """

from abc import ABC, abstractmethod
from typing import List, Optional
import asyncio, inspect, importlib
from logging import Logger

import zmq
import zmq.asyncio

from cress.context import BaseEventBusContext, ClientEventBusContext
from cress.config import read_config
from cress.service import IService
from cress.logs import get_logger, EVENT_NAME

loop = asyncio.get_event_loop()
asyncio.set_event_loop(loop)

z_cont = zmq.asyncio.Context.instance()


class IEventBus(ABC):
    logger: Logger

    @abstractmethod
    async def start(self):
        pass


class BaseEventBus(IEventBus):
    """
    The ClientEventBus class is responsible for routing events.

    1. It runs the event bus
    2. It routs requests from clients and events relatd to those requests back to
       the clients that generated them.

    The event bus accepts a limited set of request types and will rout some events
    to all clients. Events which are considered "all stations" such as when a node
    is ONLINE/OFFLINE are considered to be all station events.

    TODO: Move these to their respective actors/servies since we're not defining functionality
    of other components, as it stands this section violates separation of concerns since it
    documents what events are handled, the event bus does not guarantee any particular event
    will be hanlded, it only promises to publish the event to the bus. Actors/services are then
    responsible for handing events on the bus

    CLIENT REQUESTS HANDLED

    CLIENT_REQ_DISCOVERY - Request to the discovery endpoint, e.g. request cloud nodes, credit update
    CLIENT_REQ_POOLUPDATE
    CLIENT_REQ_RENDER
    CLIENT_REQ_SYNC


    EVENTS CONSUMED

    NODE_$STATE$

    STATE =[

    ALL STATION EVENTS

    OFFLINE - Not connected and updates to the node pool don't include this node as active
    ONLINE  - Not connected, updates to the node pool show the node is active
    DISCOVERY_RESP - A response to a request has been received.

    CLIENT RELATED EVENTS

    CONNECTING - There is an active attempt to connect to the node
    CONNECTED  - The node has been connected
    SYNCING - Data is being synchronised with the node
    SYNCED  - The node has reported that its hash agrees with the client/master's
    SYNC_FAILED - Opposite of SYNCED
    RENDERING   - The node is rendering

    ]
    """

    services: List[asyncio.Task] = []

    async def start(self):

        # Start all the services for this event bus
        self._start_services(services=self._get_services())
        self.logger.info(
            f"Starting event bus and all installed services",
            extra={EVENT_NAME: b"CLIENT_EVENTBUS_START"},
        )
        # Start the main loop which monitors all service tasks ensuring they are running
        await self.main()

    def _get_services(self):
        """Get the current list of services from the config file

        Description:
        Services are listed in the config.ini file according to their context;

        configparser['context'] = {'ServiceClassName':'Fully qualified module name'}

        e.g. the logging service

        configparser['common services'] = {'Logger':'cress.services.logging'}

        Returns: either a dictionary of services for the client event bus context, or
            a None type.


        """

        services: dict[str, IService] = {}

        # open the config file and read the services section common to all context
        common_service_mappings: dict[str, str] = read_config("common_services")
        # compile a collection of all services to be started for this context, including ones common to all contexts
        service_mappings: dict[str, str] = dict(
            self.services, **common_service_mappings
        )

        specialized_config_name = self.get_config_services_entry_name()
        if specialized_config_name is not None:
            specialized_service_mappings: dict[str, str] = read_config(
                specialized_config_name
            )
            service_mappings.update(specialized_service_mappings)

        # for each named service, find its class and instantiate an object using that class
        for service_name, service_module in service_mappings.items():

            try:
                # try to import the module containing the class that implements the service
                s_module = importlib.import_module(name=service_module)

                # filter to try and find a class which has the requested service name
                service_module_classes = {
                    cls[0]: cls[1]
                    for cls in inspect.getmembers(s_module, inspect.isclass)
                }

                # create an instantiation of the first class that matched
                # but only if its based on cress.service.Service ( exclude the Service base class )
                service_cls = service_module_classes[service_name]
                if issubclass(service_cls, IService) and service_cls is not IService:
                    print(f"registering {service_cls} as a service...")
                    service = service_cls()
                    services[service.name] = service

            except ModuleNotFoundError:
                print(f"Ignoring {service_name} because it couldn't be imported")

            except KeyError:
                print(
                    f"Couldn't find the {service_name} class in module {service_module}"
                )

        # return the list of services
        return services

    def _start_services(self, services: "dict[str, IService]" = {}):
        """Start service tasks

        This method is responsible for starting the services hosted in the event bus."""

        # get all the services
        for service in services.values():

            # create a task for this service and set its name
            service_task = loop.create_task(service.start())
            service_task.set_name(service.name)

            # for each service, create a task and store the task object
            self.services.append(service_task)

    async def main(self):
        """main method for the event bus
        The main method is resonsible for routing client requests onto the msg bus
        and events back to the clients."""

        # wait for a request or event to process
        while True:

            # await for a service to exit and then attempt a restart
            for service_task in asyncio.as_completed(self.services.copy()):

                # await a service stopping, usually means its broken, if so
                # print the exception and try to restart the service
                await service_task

                # get the corresponding task
                for task in self.services:

                    if task.done():

                        print(
                            f"The {task.get_name()} service stopped running: {task.exception()}"
                        )

                        # get the coroutine that stopped, this will be the start coro, so we can attempt a
                        # restart
                        service_start_coro = task.get_coro()

                        print(f"{__name__}: attempting to restart {task.get_name()}")
                        self.services.append(asyncio.create_task(service_start_coro))

                # here we wait so that if the service is continually dying, we only restart it every
                # second
                await asyncio.sleep(1)

    @staticmethod
    def get_config_services_entry_name() -> Optional[str]:
        return None


class ClientEventBus(BaseEventBus):
    def __init__(self):

        # create the required apparatus to allow incoming connections from other applications
        self.client_event_bus_ctx = ClientEventBusContext()
        # create an object responsible for logging events
        self.logger = get_logger("event_bus")

    @staticmethod
    def get_config_services_entry_name() -> str:
        return "client_eventbus_services"


class ReverseProxyEventBus(BaseEventBus):
    def __init__(self):
        # create the required apparatus to allow incoming connections from other applications
        self.client_event_bus_ctx = BaseEventBusContext()
        # create an object responsible for logging events
        self.logger = get_logger("event_bus")

    @staticmethod
    def get_config_services_entry_name() -> str:
        return "reverse_proxy_eventbus_services"


class ServerEventBus(BaseEventBus):
    def __init__(self):
        # # create required apparatus to connect to clients or accept connections from them
        # self.server_event_bus_ctx = ServerEventBusContext()

        # # create an object repsonsible for logging events
        # self.logger = get_logger("server_event_bus")

        raise NotImplementedError()


def run_client():

    client_event_bus = ClientEventBus()

    loop.create_task(client_event_bus.start())
    loop.run_forever()


def run_reverse_proxy():

    reverse_proxy_event_bus = ReverseProxyEventBus()

    loop.create_task(reverse_proxy_event_bus.start())
    loop.run_forever()


def run_server():

    server_event_bus = ServerEventBus()

    loop.create_task(server_event_bus.start())
    loop.run_forever()
