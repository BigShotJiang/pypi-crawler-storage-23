############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

from abc import ABC, abstractmethod
import asyncio, json
import traceback

from typing import Coroutine, List, Dict, Awaitable, Callable, Tuple, Any

import zmq, zmq.asyncio

from cress.event import Event
from cress.constants import EVENT_BUS_PUB_ADDR, EVENT_BUS_SUB_ADDR


EVENT_NAME = 0
EVENT_HANDLER = 1

z_cont = zmq.asyncio.Context.instance()


class IService(ABC):
    name: str

    @abstractmethod
    async def start(self):
        pass

    @abstractmethod
    def close(self) -> None:
        pass

    @abstractmethod
    async def run(self):
        pass

    @abstractmethod
    async def dispatch_event(self, event: bytes) -> None:
      pass

    @abstractmethod
    async def respond_to_event(
        self, original_event: Event, response_value: bytes = b""
    ) -> None:
      pass

    @abstractmethod
    def set_subscriptions(self, subs):
      pass

class Service(IService):
    handlers: Dict[bytes, Callable[[Event], Awaitable[None]]]

    def __init__(self, service_name="?"):

        self.event_sub = z_cont.socket(zmq.SUB)
        self.event_sub.connect(f"inproc://{EVENT_BUS_PUB_ADDR}")
        self.event_pub = z_cont.socket(zmq.PUB)
        self.event_pub.connect(f"inproc://{EVENT_BUS_SUB_ADDR}")
        self.name = service_name
        self.handlers = {}

    async def start(self):

        try:

            service_start_event = Event(
                b"SERVICE-START",
                bytes(json.dumps({"message": f"{self.name} has started"}), "utf-8"),
            )

            await self.dispatch_event(service_start_event)

            await self.run()

            print(f"{self.name} service finished.")

            # create and dispatch an event to signal the service finished
            finished_event = Event(
                b"SERVICE-FINISHED",
                bytes(json.dumps({"messsage": f"{self.name} finished"}), "utf-8"),
            )

            await self.dispatch_event(finished_event)

        # TODO: logging and cleanup for cancellation and errors
        except asyncio.CancelledError:

            print(f"{self.name} service was cancelled.")

        except Exception as e:

            print(f"{self.name} threw an exception:")
            traceback.print_exc()

        # make sure we call a close method so consumers of this class
        # can cleanup any resources they may have used like sockets
        # or files.
        finally:
            self.close()

    def close(self) -> None:
        """Override this method to cleanup any resources used in your service"""
        pass

    def set_subscriptions(self, subs: List[Tuple[bytes, Callable[[Event], Coroutine[Any, Any, None]]]]):

        # for each subscription set the appropriate socket options
        for sub in subs:
            self.event_sub.subscribe(sub[EVENT_NAME])
            self.handlers[sub[EVENT_NAME]] = sub[EVENT_HANDLER]

    async def dispatch_event(self, event: Event) -> None:

        await self.event_pub.send_multipart(event.serialise())

    async def respond_to_event(
        self, original_event: Event, response_value: bytes = b""
    ) -> None:
        """send a response event to the thing that originated the event

        Clients generaete events which contain a unique ID. This allows us to
        send a response event to just that client by prefixing the event name
        with the client's ID.

        Arguments:
            original_event: Event - the original event
            response_value: bytes - value for the event as a bytes string"""

        value = response_value or original_event.value

        await self.dispatch_event(original_event.create_reply_event(value))

    def get_handler(self, event):
        """return the handler that matches for the given event

        Handlers match the event type. Event types are a combination '
        of the event's given name, followed by suffixes for the client/worker ids.

        Handler matching only uses the event name, not the ids. Ids are ignored.

        EVENTNAME_CLIENTID_WORKERID

        In the above e.g. only the EVENTNAME is considered for matching."""

        # search for a match on the event name first
        if matching_handler := self.handlers.get(event.name, None):
            handler = matching_handler
        # if that fails, check if we have a handler subscribed to everything
        elif b"" in self.handlers:
            handler = self.handlers.get(b"")
        # if there's no handler matching either the event name, nor a handler subscribed
        # to all events, then this is an error condition, raise a ValueError
        else:
            handler = None  # ignore because we otherwise would respond to the services own responses

        return handler

    async def run(self):
        """React to events for this service

        this is the main method for this class. Its responsible for
        reacting to events and calling the handlers that an implementing service
        defines.

        This method can be overriden"""

        while True:

            event = Event.deserialise(await self.event_sub.recv_multipart())

            handler = self.get_handler(event)

            if handler is not None:
                await handler(event)
