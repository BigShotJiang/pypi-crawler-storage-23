from cress.discovery import (
    DiscoveryAPI,
    IDiscoveryAPI,
    IMachineRepository,
    MachineRepository,
)
from cress.auth import Authenticator, CredentialsProvider, CredentialsStorage

from dependency_injector import containers, providers
import gql, gql.transport.requests

from cress.instance import CRESSInstance


class BaseContainer(containers.DeclarativeContainer):
    config = providers.Configuration(strict=True)

    instance = providers.Singleton(CRESSInstance)

    # Declare required depedencies for communication with discovery server.
    discovery_gql_transport = providers.Singleton(
        gql.transport.requests.RequestsHTTPTransport,
        url=config.discovery.api_endpoint,
        headers=providers.Dict(authorization=config.discovery.auth_token),
    )
    discovery_gql_client = providers.Singleton(
        gql.Client,
        transport=discovery_gql_transport,
        fetch_schema_from_transport=False,  # set to True for easier debugging.
    )
    discovery_api = providers.Singleton[IDiscoveryAPI](
        DiscoveryAPI, client=discovery_gql_client
    )


class ClientContainer(BaseContainer):
    machine_repository = providers.Singleton[IMachineRepository](
        MachineRepository, discovery_api=BaseContainer.discovery_api
    )

    credentials_storage = providers.Singleton(CredentialsStorage)

    credentials_provider = providers.Singleton(
        CredentialsProvider,
        machine_repository=machine_repository,
        credentials_storage=credentials_storage,
    )

    authenticator_factory = providers.Factory(
        Authenticator, credentials_provider=credentials_provider
    )
