import cress, os
from cress import event_bus, config
from cress.containers import ClientContainer

CLIENT = "client"
SERVER = "server"
WORKER = "worker"
REVERSE_PROXY = "reverse_proxy"


def start_cress(cress_context: str):
    if cress_context not in {CLIENT, SERVER, WORKER, REVERSE_PROXY}:
        raise RuntimeError(
            'Wrong value for cress context argument, valid args are "client", "server" and "worker".'
        )

    cr_path = config.get_cr_path()
    context_path = os.path.join(cr_path, cress_context)

    if not os.path.exists(context_path):
        config.mkdir_p(context_path)

    # TODO: use switch/case
    if cress_context == CLIENT:
        container = ClientContainer()
        container.instance.add_kwargs(context=cress_context)
        container.config.from_yaml("cress/config.yml", required=True)
        container.wire(packages=[cress])

        event_bus.run_client()

    if cress_context == REVERSE_PROXY:
        container = ClientContainer()
        container.instance.add_kwargs(context=cress_context)
        container.config.from_yaml("cress/config.yml", required=True)
        container.wire(packages=[cress])

        event_bus.run_reverse_proxy()

    if cress_context == SERVER:
        event_bus.run_server()

    if cress_context == WORKER:
        #  run_worker()
        pass
