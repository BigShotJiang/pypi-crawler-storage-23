from abc import ABC, abstractmethod
from typing import Dict, List, Optional
import gql
from gql import gql as gql_query
from uuid import UUID


class IDiscoveryAPI(ABC):
    """Provides methods to communicate with a discovery server."""

    @abstractmethod
    def register_machine(self, uuid: UUID, name: str, public_key: bytes):
        pass

    @abstractmethod
    def update_machine(self, uuid: UUID):
        pass

    @abstractmethod
    def get_machines(self):
        pass

    @abstractmethod
    def get_optimal_refresh_interval(self) -> int:
        pass

    @abstractmethod
    def get_user(self, uuid: UUID):
        pass

    @abstractmethod
    def request_rental_instances(self, bl_version, cr_version):
        pass

    @abstractmethod
    def update_rental_instance_count(self, count: int):
        pass

    @abstractmethod
    def update_blender_grid_token(self, token: str):
        pass

    @abstractmethod
    def update_user_credit(self) -> float:
        pass


class DiscoveryAPI(IDiscoveryAPI):
    def __init__(self, client: gql.Client) -> None:
        self.client = client

    def register_machine(
        self,
        uuid: UUID,
        context: str,
        name: Optional[str] = None,
        public_key: Optional[bytes] = None,
        webrtc_messages: Optional[List] = None,
    ):
        query = gql_query(
            """
            mutation registerMachine($uuid: String!, $name: String, $public_key: String, $webrtcMessages: [webrtcMessageInput]) {
                registerMachine(input: {uuid: $uuid, computerName: $name, machineData: {publicKey: $public_key, webrtcMessages: $webrtcMessages}}) {
                    uuid
                }
            }
            """
        )

        public_key_str = public_key.decode("utf-8") if public_key else None

        self.client.execute(
            query,
            variable_values={
                "uuid": str(uuid),
                "name": name,
                "public_key": public_key_str,
                "webrtcMessages": webrtc_messages,
            },
        )

    def update_machine(
        self,
        uuid: UUID,
        webrtc_message: Optional[str] = None,
    ):
        query = gql_query(
            """
                mutation updateMachine($uuid: String!, $webrtcMessages: [webrtcMessageInput]){
                updateMachine(input: {uuid: $uuid, machineData: {webrtcMessages: $webrtcMessages}}) {
                    uuid
                }
            }
            """
        )

        self.client.execute(
            query,
            variable_values={
                "uuid": str(uuid),
                "webrtcMessages": webrtc_message,
            },
        )

    def get_machines(self):
        query = gql_query(
            """
            query getMachines {
                machines {
                    uuid
                    machineData {
                        publicKey
                        webrtcMessages {
                         sdp
                         type
                         to
                         }
                    }
                }
            }
            """
        )

        return self.client.execute(query)["machines"]

    def get_optimal_refresh_interval(self) -> int:
        query = gql_query(
            """
            query {
                refreshInterval
            }
            """
        )

        return self.client.execute(query)["refreshInterval"]

    def get_user(self, uuid: UUID):
        query = gql_query(
            """
            query getUser($uuid: String!) {
                user(id: $uuid) {
                    id
                    name
                }
            }
            """
        )

        return self.client.execute(
            query,
            variable_values={
                "uuid": str(uuid),
            },
        )

    def request_rental_instances(self, bl_version: str, cr_version: str):
        query = gql_query(
            """
            mutation requestRentalInstances($bl_version: String!, $cr_version: String!) {
                requestRentalInstances(input: {crVersion: $cr_version, blVersion: $bl_version}) {
                    renderCredit
                    accepted
                    numberOfBlenderGridNodes
                    refreshInterval
                }
            }
            """
        )

        return self.client.execute(
            query,
            variable_values={
                "bl_version": bl_version,
                "cr_version": cr_version,
            },
        )

    def update_rental_instance_count(self, count: int):
        query = gql_query(
            """
            mutation updateRentalInstanceCount($count: Int!) {
                updateRentalInstanceCount(input: {count: $count}) {
                    count
                }
            }
            """
        )

        return self.client.execute(
            query,
            variable_values={
                "count": count,
            },
        )

    def update_blender_grid_token(self, token: str) -> bool:
        query = gql_query(
            """
            mutation updateBlenderGridToken($token: String!) {
                updateBlenderGridToken(token: $token)
            }
            """
        )

        return self.client.execute(
            query,
            variable_values={
                "token": token,
            },
        )["updateBlenderGridToken"]

    def update_user_credit(self) -> float:
        query = gql_query(
            """
            mutation {
                updateUserCredit {
                    credit
                }
            }
            """
        )

        return self.client.execute(query)["updateUserCredit"]["credit"]


class IMachineRepository(ABC):
    """An interface for querying properties of a machine."""

    @abstractmethod
    def is_key_authorized(self, key: bytes) -> bool:
        pass


class MachineRepository(IMachineRepository):
    def __init__(self, discovery_api: DiscoveryAPI) -> None:
        self.discovery_api = discovery_api
        self.keys = set()

    def _fetch_keys(self) -> None:
        response = self.discovery_api.get_machines()

        self.keys = set(
            [
                machine["machineData"]["publicKey"].encode("utf-8")
                for machine in response["machines"]
                if machine["machineData"]["publicKey"] is not None
            ]
        )

    def is_key_authorized(self, key: bytes) -> bool:
        if key in self.keys:
            return True

        self._fetch_keys()

        return key in self.keys
