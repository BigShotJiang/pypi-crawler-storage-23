EVENT_BUS_PUB_ADDR = "cress_event_publisher"  # inproc address for event bus publisher
EVENT_BUS_SUB_ADDR = "cress_event_subscriber"  # inproc address for event bus subscriber