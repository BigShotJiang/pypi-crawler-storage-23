############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################
""" Protocols modules

This module implements the cress protocols for how messages are structured.
Various classes are provided for packng/unpacking messages.  

"""

# Std Python Imports
import json
from typing import Dict


class BeaconProtocol:
    """CRESS BEACON PROTOCOL
    The beacon protocol is used to format messages to be sent
    as UDP multicast beacons for the purpose of allowing nodes
    to discover each other and automatically attempt a connection.

    msg             = signature, machine_uuid, *service

    signature       = string; 'CRESS_BCNPROTO'

    machine_uuid    = string; unique id for this machine

    service         = service_name, *endpoint

    service_name    = string

    endpoint        = string; dotted quad ip address and port

    ON THE WIRE

    The current implementation uses json formatted strings.

    python representation
    ['CRESS_BCNPROTO', {'service name':[bound endpoints]}]

    """

    # CLASS VARIABLES
    NODE_UUID = 1
    SERVICES = 2

    def __repr__(self):

        res = "".join(
            ["BeaconProtocol(", str(self.node_uuid), ", ", str(self.services), ")"]
        )

        return res

    def __str__(self):

        res = "".join(
            [
                "BeaconProtocol: ",
                "{",
                "node_uuid: ",
                str(self.node_uuid),
                ", ",
                "services: ",
                str(self.services),
                "}",
            ]
        )

        return res

    def __init__(self, node_uuid, services):

        self.node_uuid = node_uuid
        self.services = services

    @classmethod
    def pack(cls, node_uuid: str, services: Dict):
        """creates a beacon msg according to the CRESS beacon protocol

        Arguments:
            node_uuid - string, unique id for the node the CRESS Client is running on
            services  - pydict, {service_name: service_endpoint}. Service name would be the


        """

        assert type(services) is dict

        beacon = bytes(json.dumps(["CRESS_BCNPROTO", node_uuid, services]), "utf-8")

        return beacon

    @classmethod
    def unpack(cls, beacon_msg):
        """Decodes a serialised message off the network
            according to the CRESS BCN protocol

        Arguments: beacon_msg - bytes,
            a string in python bytes format, containing data received
            from the network.


        Description: The beacon_msg is decoded and if it is
            really a beacon, the contents are returned.

        Returns: beacon    - BeaconProto, object containing the node_uuid
            and a dictionary which contains each service (as key)
            and its endpoint ( as a value, nominally as a string"

        Errors:

        """
        # TODO: need to replace the asserts with error checking, thinking
        # that we raise an error that is handled by the beaconing service
        # it can just log it for now and keep processing beacons.
        assert b"CRESS_BCNPROTO" in beacon_msg

        beacon = json.loads(beacon_msg.decode("utf-8"))

        assert type(beacon[cls.NODE_UUID]) is str
        assert type(beacon[cls.SERVICES]) is dict

        return BeaconProtocol(beacon[cls.NODE_UUID], beacon[cls.SERVICES])
