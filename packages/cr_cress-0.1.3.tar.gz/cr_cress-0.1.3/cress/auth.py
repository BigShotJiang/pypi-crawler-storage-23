############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

import os, shutil, configparser, json
from pathlib import Path

import zmq
import zmq.auth
from zmq.asyncio import Context
from zmq.auth.asyncio import AsyncioAuthenticator

from cress.config import read_config
from cress.discovery import MachineRepository
from cress.logs import get_logger, get_file_logger

SERVER_ROLE = "SERVER"
CLIENT_ROLE = "CLIENT"
EVENT_NAME = "event_name"


def get_certs_folder():
    """return base path for where certificates are stored"""

    return read_config("paths")["config.certificates"]


CERT_DIR = Path(get_certs_folder())
PUBLIC_KEYS_DIR = CERT_DIR / "public_keys"
SECRET_KEYS_DIR = CERT_DIR / "private_keys"
PEER_KEYS_DIR = CERT_DIR / "peer_keys"
# if we don't have a config file, generate one... we kind of need it
PEER_CERTS_CONFIG_FILE = os.path.join(PEER_KEYS_DIR, "config.ini")


def get_dict_fm_config(input):
    """returns a pydict representing the requested config items
    luckily the format of strings containing dictionaries returned from
    configparser objects is readable by json if you input the string as json
    to begin with.

    """
    return json.loads(input)


def read_peer_keys_config() -> str:
    """read and return the config item corresponding to the key argument

    This module function is responsible for getting config items"""

    # get a config obj to parse the file contents with
    config = configparser.ConfigParser(converters={"dict": get_dict_fm_config})

    # open the config file and read the config
    with open(PEER_CERTS_CONFIG_FILE, "rt") as config_file:
        config.read_file(config_file)

    # get the certs for a specific domain
    domain_certs = config["peers"].getdict("certificates")

    return domain_certs


def ensure_certificates() -> None:
    """checks if the zmq curve certificates are present and auto gens them if they're missing

    This function will attempt to the ZAP security certificates, if this fails, it will try
    to generate them as many times as the private 'attempts' variable allows for.

    If the certificates load the function returns True otherwise it returns false

    """

    attempts = 2
    result = False
    error = None

    while attempts:

        try:
            zmq.auth.load_certificates(directory=PUBLIC_KEYS_DIR)
            zmq.auth.load_certificate(SECRET_KEYS_DIR / "server.key_secret")
            result = True
            # Logger - successfully loaded auth certificates
            break

        except OSError as e:

            # Logger.warning("couldn't load certificates, going to try and generate them.")
            generate_certificates(CERT_DIR)

            error = e

        except ValueError as e:

            # Logger.warning("couldn't load certificates, going to try and generate them.")
            generate_certificates(CERT_DIR)

            error = e

        attempts -= 1

    if not result:
        raise RuntimeError(
            f"Could not load certificates, they may not be there and attempting to creat them failed with: {error}"
        )


def ensure_peer_certs_config():
    """if it doesn't already exist the configuration file containing the peers we allow ourselves to connect to

    The peer certificates config is a .ini file which contains a list of domains each having a dictionary of
    {client_key: node id}

    """

    # load this machines client keys
    client_secret_file = SECRET_KEYS_DIR / "client.key_secret"
    client_public, client_secret = zmq.auth.load_certificate(client_secret_file)

    # create the peer keys folder if it doesn't exist

    if not os.path.exists(PEER_KEYS_DIR):
        os.makedirs(PEER_KEYS_DIR)

    # create the config file if it doesn't already exist.
    if not os.path.exists(PEER_CERTS_CONFIG_FILE):
        # create a default onfig parser in case this is the config.ini file is missing
        default_cert_config = configparser.ConfigParser()
        default_cert_config["peers"] = {}
        # add the locoal host key, however, we replace any '%' chars since configparser will otherwise try to interpret them
        # as syntax for its interpolation feature and then most likely barf since its expecting a set format that we won't
        # be giving it.
        default_cert_config["peers"]["certificates"] = json.dumps(
            {client_public.decode("utf-8"): "localhost"}
        ).replace("%", "%%")

        with open(PEER_CERTS_CONFIG_FILE, "w") as config_file:
            default_cert_config.write(config_file)

    # otherwise we open the existing one and make sure there is at least
    # the local host in there.
    else:

        # create a configparser object so we can read an existing config.ini
        cert_config = configparser.ConfigParser()

        with open(PEER_CERTS_CONFIG_FILE, "rt+") as config_file:

            # read in the config data from the file
            cert_config.read(PEER_CERTS_CONFIG_FILE)

            # if the confi file happens to be empty, add at least one entry for
            # the localhost
            if not "peers" in cert_config.sections():
                cert_config["peers"] = {}
                cert_config["peers"]["certificates"] = json.dumps(
                    {client_public.decode("utf-8"): "localhost"}
                ).replace("%", "%%")
                cert_config.write(config_file)

    # copy the new config in the temp config file over the old one
    # TODO:


def generate_certificates(base_dir):
    """Generate client and server CURVE certificate files"""

    keys_dir = CERT_DIR

    # Create directories for certificates, remove old content if necessary
    for d in [keys_dir, PUBLIC_KEYS_DIR, SECRET_KEYS_DIR]:
        if os.path.exists(d):
            shutil.rmtree(d)
        os.mkdir(d)

    # create new keys in certificates dir
    server_public_file, server_secret_file = zmq.auth.create_certificates(
        keys_dir, "server"
    )
    client_public_file, client_secret_file = zmq.auth.create_certificates(
        keys_dir, "client"
    )

    # move public keys to appropriate directory
    for key_file in os.listdir(keys_dir):
        if key_file.endswith(".key"):
            shutil.move(
                os.path.join(keys_dir, key_file), os.path.join(PUBLIC_KEYS_DIR, ".")
            )

    # move secret keys to appropriate directory
    for key_file in os.listdir(keys_dir):
        if key_file.endswith(".key_secret"):
            shutil.move(
                os.path.join(keys_dir, key_file), os.path.join(SECRET_KEYS_DIR, ".")
            )


class CredentialsStorage:
    def __init__(self):
        # make sure we've setup a local config for storing peer certs we're happy to allow connectios to/from
        ensure_certificates()
        ensure_peer_certs_config()

    def contains_key(self, key: bytes):
        keys = read_peer_keys_config()
        # key is a bytes object, whereas the certs config stores them as strings so we have to convert
        return key.decode("utf-8") in keys


class CredentialsProvider:
    def __init__(
        self,
        machine_repository: MachineRepository,
        credentials_storage: CredentialsStorage,
    ) -> None:

        self.logger = get_logger("event_bus")
        self.machine_repository = machine_repository
        self.credentials_storage = credentials_storage

    def validate_peer(self, domain: str, key: bytes) -> bool:
        """Returns True if the peer's key is valid for its domain

        Valid domains are:
            localhost - peers that run on this machine
            localnetwork - self explanetory really
            cloud        -
            remoteuser   - peers belonging to this account, but in a remote network
            reomteshared - peers from another user in a remote network

        """

        return self.credentials_storage.contains_key(
            key
        ) or self.machine_repository.is_key_authorized(key)

    def callback(self, domain: str, key: bytes) -> bool:
        """return true if the connection is valid, false otherwise

        Uses the self.valudate_peer method to check on whether the
        peer should be allowed to make a connection.

        NOTE: this callback only gets called if the peer has set a
        public certificate, otherwise the connection will be silently
        dropped.

        """

        if self.validate_peer(domain, key):
            self.logger.info(
                f"Authorizing: {domain}, {key}", extra={EVENT_NAME: b"AUTH_SUCCESS"}
            )
            return True

        else:
            self.logger.warning(
                f"NOT Authorizing: {domain}, {key}", extra={EVENT_NAME: b"AUTH_FAILURE"}
            )
            return False


class Authenticator:
    """Configures and hosts a ZAP authenticator"""

    def __init__(
        self,
        credentials_provider: CredentialsProvider,
        socket_role: str,
        domain: str = "*",
    ) -> None:
        """ """

        # make sure there are certificates on this machine
        ensure_certificates()

        self.socket_role = socket_role
        ctx = Context.instance()

        # These directories are generated by the generate_certificates script
        base_dir = Path(get_certs_folder())
        self.public_keys_dir = base_dir / "public_keys"
        self.secret_keys_dir = base_dir / "private_keys"

        # If the requested curve role for this socket is a server then...
        if socket_role == SERVER_ROLE:
            # Start an authenticator for this context.
            self.auth = AsyncioAuthenticator(ctx)
            self.auth.start()

            # set the callback that will decide whether to accept the connection or not
            self.auth.configure_curve_callback(
                domain=domain, credentials_provider=credentials_provider
            )

            # load the correct certs for this role and create member variables to store the keys
            server_secret_file = self.secret_keys_dir / "server.key_secret"
            self.server_public, self.server_secret = zmq.auth.load_certificate(
                server_secret_file
            )

        # if the requested curve role for this socket is a clien, then

        elif socket_role == CLIENT_ROLE:

            client_secret_file = self.secret_keys_dir / "client.key_secret"
            self.client_public, self.client_secret = zmq.auth.load_certificate(
                client_secret_file
            )

    def set_socket_keys(self, socket: zmq.Socket) -> None:
        """Set the public/private keys for socket based on its role"""

        if self.socket_role == SERVER_ROLE:
            socket.curve_secretkey = self.server_secret
            socket.curve_publickey = self.server_public
            socket.curve_server = True

        elif self.socket_role == CLIENT_ROLE:
            socket.curve_secretkey = self.client_secret
            socket.curve_publickey = self.client_public

    def close(self) -> None:
        # if the socket is a server it actually has somethign to stop, so do that, otherwise...
        if self.socket_role == SERVER_ROLE:
            self.auth.stop()
        # do nothing
        else:
            pass
