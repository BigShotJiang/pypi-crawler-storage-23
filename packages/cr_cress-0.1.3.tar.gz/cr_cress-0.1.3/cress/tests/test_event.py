############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

import json
from unittest import TestCase

from cress.event import Event, InvalidEventError, MalformedEventError
from cress.event import EVENT_NAME, EVENT_VALUE, EVENT_NAME, SIG_VERSION


class TestSerialising(TestCase):
    def setUp(self) -> None:
        return super().setUp()

    def test_serialisation(self):

        val = bytes(json.dumps({"a value of some kind": 3}), "utf-8")

        new_event = Event(b"TEST", val)

        self.assertEqual(new_event.name, b"TEST")
        self.assertEqual(new_event.value, val)

    def test_deserialisation(self):

        val = bytes(json.dumps({"a value of some kind": 4}), "utf-8")
        # test deserialising an event with no event name prefix
        new_event = Event(b"TEST", val, b"", b"").serialise()
        des_event = Event.deserialise(new_event)

        self.assertEqual(des_event.name, b"TEST")
        self.assertEqual(des_event.value, val)

        # test deserialising an event with a prefix
        no_prefix_event = Event(b"PREFIX.TEST", val, b"", b"").serialise()
        des_no_prefix_event = Event.deserialise(no_prefix_event)

        self.assertEqual(des_no_prefix_event.name, b"TEST")

    def test_malformed_msg(self):

        not_enough_fields = [b"TARGET", b"VALUE", SIG_VERSION]
        empty = []
        too_many_fields = [
            SIG_VERSION,
            b"TEST",
            bytes(json.dumps({"the event type is missing!": "oops"}), "utf-8"),
            b"source",
            b"destination",
            b"superfluous field",
        ]

        self.assertRaises(MalformedEventError, Event.deserialise, not_enough_fields)
        self.assertRaises(InvalidEventError, Event.deserialise, empty)
        self.assertRaises(MalformedEventError, Event.deserialise, too_many_fields)

    def test_forward(self):
        """tests the create_forwarded_event method

        Description: the create_forwarded_event method returns a serialised copy of the
        original event, but the name is prefixed with the id of the destination so that only
        entities on the bus that subscribe to that destination will get it.

        This is used to send events to particular entities, for example, if a client wants to
        synchronise with a new node, only that node should receive the request to sync.
        """

        # create an 'original' event,
        original_event = Event(b"TEST_FORWARDING", b"value", b"source", b"destination")

        # now create a forwadable event with the same value
        forwardable_event = original_event.create_forwarded_event().serialise()

        # test that the new event name matches what we expect from the protocol spec
        self.assertEqual(forwardable_event[EVENT_NAME], b"destination.TEST_FORWARDING")

    def test_reply(self):
        """test the create_reply_event method of the Event class

        Description: the create_reply_event method returns a serialised copy of the original
        event. The name field is prefixed with the id of the source which originated the event.
        This means that when the event is sent on the bus, only entities that are either subscribed
        to all events, or the client that originated the event should recieve it.

        This is used to efficiently send events related to some originating event back to the
        originating entity. Originating entities can be anywhere and have any role. The goal here is
        to allow efficient routing of related events back to the source."""

        # create an 'original' event,
        original_event = Event(b"TEST_REPLY", b"value", b"source", b"destination")

        # now create a forwadable event with the same value
        reply_event = original_event.create_reply_event().serialise()

        # test that the new event name matches what we expect from the protocol spec
        self.assertEqual(reply_event[EVENT_NAME], b"source.TEST_REPLY")
