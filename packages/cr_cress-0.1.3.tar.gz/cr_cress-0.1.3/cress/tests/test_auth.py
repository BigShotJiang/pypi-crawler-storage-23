############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

import os, asyncio, time
from unittest import IsolatedAsyncioTestCase
from uuid import uuid4

import zmq, zmq.auth, zmq.asyncio
import dependency_injector.providers
from uuid import UUID

from cress.auth import SERVER_ROLE, CLIENT_ROLE
from cress.discovery import IDiscoveryAPI
from cress.event import Event
from cress.logs import get_logger, get_file_logger
from cress.containers import ClientContainer
from cress.context import ConnectAuthError, Connector, ConnectError
from cress.config import cress_path

from cress.tests.fake_event_bus import FakeEventBus
from cress.tests.utils import integration_test

# CONSTANTS
EVENT_BUS_SUB_ADDR = "cress_event_subscriber"
EVENT_BUS_PUB_ADDR = "cress_event_publisher"

EVENT_BUS_SUB_ENDPOINT = "127.0.0.1"
EVENT_BUS_PUB_ENDPOINT = "127.0.0.1"

EVENT_NAME = "event_name"

Z_CTX = zmq.asyncio.Context.instance()


class FakeDiscoveryAPI(IDiscoveryAPI):
    def __init__(self):
        self.machines = list()
        self.machines_requested = False

    def register_machine(self, public_key: bytes):
        self.machines.append((uuid4(), public_key))

    def update_machine(self, uuid: UUID):
        pass

    def get_machines(self):
        self.machines_requested = True
        return {
            "machines": list(
                [
                    {"uuid": uuid, "machineData": {"publicKey": public_key}}
                    for (uuid, public_key) in self.machines
                ]
            )
        }

    def get_optimal_refresh_interval(self) -> int:
        return 0

    def get_user(self, uuid: UUID):
        pass

    def request_rental_instances(self, bl_version, cr_version):
        pass

    def update_rental_instance_count(self, count: int):
        pass

    def update_blender_grid_token(self, token: str):
        pass

    def update_user_credit(self) -> float:
        return 0


class FakeCredentialsProvider:
    def __init__(self) -> None:
        self.logger = get_logger("test_credentials_provider")
        self.allowed_keys = set()

    def allow_key(self, key):
        self.allowed_keys.add(key)

    def clear_allowed_keys(self):
        self.allowed_keys.clear()

    def callback(self, domain: str, key: str) -> bool:
        if key in self.allowed_keys:
            self.logger.info(
                f"Authorizing: {domain}, {key}", extra={EVENT_NAME: b"AUTH_SUCCESS"}
            )
            return True
        else:
            self.logger.warning(
                f"NOT Authorizing: {domain}, {key}", extra={EVENT_NAME: b"AUTH_FAILURE"}
            )
            return False


class TestAuth(IsolatedAsyncioTestCase):
    """ """

    async def asyncSetUp(self):

        # Provide a means to capture debug information from this test
        self.logger = get_file_logger("test_auth", os.path.join(cress_path))

        self.container = ClientContainer()
        self.container.discovery_api.override(
            dependency_injector.providers.Singleton(FakeDiscoveryAPI)
        )

        # setup client and server sockets so we can use these to test the authenticator

        self.event_bus = FakeEventBus(
            pub_address=f"inproc://{EVENT_BUS_PUB_ADDR}",
            sub_address=f"inproc://{EVENT_BUS_SUB_ADDR}",
        )

        # setup server sockets
        self.server_pub_sock = Z_CTX.socket(zmq.PUB)
        self.server_sub_sock = Z_CTX.socket(zmq.SUB)
        self.server_sub_sock.subscribe(b"")

        # setup client sockets
        self.client_pub_sock = Z_CTX.socket(zmq.PUB)
        self.client_sub_sock = Z_CTX.socket(zmq.SUB)
        self.client_sub_sock.subscribe(b"")

        self.fake_event_bus_pub = Z_CTX.socket(zmq.PUB)
        self.fake_event_bus_sub = Z_CTX.socket(zmq.SUB)

        self.fake_event_bus_pub.connect(f"inproc://{EVENT_BUS_SUB_ADDR}")
        self.fake_event_bus_sub.connect(f"inproc://{EVENT_BUS_PUB_ADDR}")
        self.fake_event_bus_sub.subscribe(b"")

        # self.server_credentials_provider = self.FakeCredentialsProvider()

        # create authenticator
        # interesting use of https://peps.python.org/pep-0526/ perhaps we can consider using this more often.
        self.discovery_api: FakeDiscoveryAPI = self.container.discovery_api()  # type: ignore
        self.server_authenticator = self.container.authenticator_factory(
            socket_role=SERVER_ROLE
        )
        self.server_authenticator.set_socket_keys(self.server_pub_sock)
        self.server_authenticator.set_socket_keys(self.server_sub_sock)

        # get server public key
        serv_public_key = self.server_authenticator.server_public

        # # ensure that the logger from the auth module has sent a bonjour event
        # logger_bonjour_maybe = Event.deserialise(await self.fake_event_bus_sub.recv_multipart())
        # if not logger_bonjour_maybe.name == b'BONJOUR':
        #     #kill the test now, something's not right
        #     raise RuntimeError(f"Expected to get a bonjour event from the auth loggger, but got {logger_bonjour_maybe} instead.")

        # Start listening for connections from compute nodes on the publish/subscribe channel.
        self.pub_port = self.server_pub_sock.bind_to_random_port(
            f"tcp://{EVENT_BUS_PUB_ENDPOINT}"
        )
        self.sub_port = self.server_sub_sock.bind_to_random_port(
            f"tcp://{EVENT_BUS_SUB_ENDPOINT}"
        )

        # Start processing authentication requests from compute nodes wishing to connect to this client.
        self.client_authenticator = self.container.authenticator_factory(
            socket_role=CLIENT_ROLE
        )

        # Configure sec keys for a pub socket to use as a faked client in the test.
        self.client_sub_sock.curve_publickey = self.client_authenticator.client_public
        self.client_sub_sock.curve_secretkey = self.client_authenticator.client_secret
        self.client_sub_sock.curve_serverkey = serv_public_key

        # set the keys for the client's sub socket
        self.client_pub_sock.curve_publickey = self.client_authenticator.client_public
        self.client_pub_sock.curve_secretkey = self.client_authenticator.client_secret
        self.client_pub_sock.curve_serverkey = serv_public_key

    async def can_connect_to_eventbus(
        self, client_sub_sock: zmq.Socket, client_pub_sock: zmq.Socket
    ) -> bool:
        """Returns True if a connection and subsequent round trip msg succeeds, False if not."""

        self.discovery_api.register_machine(self.client_authenticator.client_public)

        # Connect and send an event on the fake event bus
        # where the first client fails
        client_sub_sock.connect(f"tcp://127.0.0.1:{self.pub_port}")
        client_pub_sock.connect(f"tcp://127.0.0.1:{self.sub_port}")
        client_sub_sock.subscribe(b"")

        # create a coroutine that implements a listening server
        async def server_listens():

            # poke libzmq with a poll to ensure subscription has propagated
            await self.server_sub_sock.poll(timeout=0)
            time.sleep(0.1)

            while True:

                event = Event.deserialise(await self.server_sub_sock.recv_multipart())
                await self.server_pub_sock.send_multipart(event.serialise())

        # create a task for the server_listens coro
        listening_server_task = asyncio.create_task(server_listens())

        # create a coroutine that allows the client to listen for incoming events
        # and return once it gets the hello event back.
        async def wait_for_event():

            while True:

                event = Event.deserialise(await self.client_sub_sock.recv_multipart())

                if event.name == b"HI!":
                    break

        # pyzmq pub/sub connections require time to establish
        await asyncio.sleep(1)

        # try sending a message from the client and see if it arrives
        await self.client_pub_sock.send_multipart(
            Event(b"HI!", b"helloooooo").serialise()
        )
        # try receving an event, since the internals of our FakeEventBus class just
        # replay incoming events back to us, we should eventually see the same
        # event on a recv call to the sub socket

        try:
            await asyncio.wait_for(wait_for_event(), 3.0)

            resp = True

        except asyncio.TimeoutError:

            resp = False

        except:
            raise RuntimeError(f"Unexpected error when testing for a connection")

        finally:

            listening_server_task.cancel()

        return resp

    async def test_auth_succeeds(self):
        self.discovery_api.register_machine(self.client_authenticator.client_public)

        # get the client to try to connect to the server
        self.client_sub_sock.connect(f"tcp://127.0.0.1:{self.pub_port}")
        self.client_pub_sock.connect(f"tcp://127.0.0.1:{self.sub_port}")

        # await for the fake event bus to get a specific event from the credentials provider
        # confirming the key from the client is permitted
        async def detect_auth_success():

            while True:

                maybe_auth_event = Event.deserialise(
                    await self.fake_event_bus_sub.recv_multipart()
                )

                if maybe_auth_event.name == b"AUTH_SUCCESS":

                    break

        try:
            await asyncio.wait_for(detect_auth_success(), 2.0)
        except asyncio.TimeoutError:
            self.fail(f"Auth msg failed to arrive")

    async def test_auth_fails_with_no_key_client(self):
        """tests rejecting a bad handshake

        A peer tries to connect but it has no server key set, this should cause
        pyzmq to not even call our auth module and the client trying to connect
        should not be able to receive any messages.

        """

        self.discovery_api.register_machine(b"wrong key 1")
        self.discovery_api.register_machine(b"wrong key 2")

        # create a new client that has no keys set
        self.pub_no_key_client = Z_CTX.socket(zmq.SUB)
        self.sub_no_key_client = Z_CTX.socket(zmq.PUB)
        self.pub_no_key_client.connect(f"tcp://127.0.0.1:{self.sub_port}")
        self.sub_no_key_client.connect(f"tcp://127.0.0.1:{self.pub_port}")
        self.pub_no_key_client.subscribe(b"")

        # wait for a few seconds for anything from the AUTH module,
        # if we get either AUTH_FAILED or nothing, move on, otherwise
        # fail the test here.

        async def wait_for_auth_events():

            # credentials_event_1st = Event.deserialise(
            #     asyncio.create_task()
            # )
            # credentials_event_2nd = Event.deserialise(
            #     asyncio.create_task()
            # )

            res = await asyncio.gather(
                self.fake_event_bus_sub.recv_multipart(),
                self.fake_event_bus_sub.recv_multipart(),
            )

            return res

        try:

            credentials_event_1st, credentials_event_2nd = await asyncio.wait_for(
                wait_for_auth_events(), 3.0
            )

            # fail this test if we got a valid AUTH
            self.assertNotEqual(
                credentials_event_1st.name,
                b"AUTH_SUCCESS",
                f"Auth succeeded where it should have failed.",
            )
            self.assertNotEqual(
                credentials_event_2nd.name,
                b"AUTH_SUCCESS",
                f"Auth succeeded where it should have failed.",
            )

        except asyncio.TimeoutError:
            # The test has passed if we reach here.
            pass

    async def test_connect_succeeds(self):
        """tests a round trip after a successful auth attempt

        A connection should happen if the auth succeeds so this test
        awaits on the successful connection of a remote node/peer.

        """

        self.assertTrue(
            await self.can_connect_to_eventbus(
                self.client_sub_sock, self.client_pub_sock
            )
        )

    async def test_auth_fails_with_spoofed_public_key(self):
        """test that a peer with a spoofed public key can't create a successful connection"""

        self.discovery_api.register_machine(self.client_authenticator.client_public)

        # Setup new keys which spoof an accepted public key, but guess the secret key cause they don't have it
        public_key, secret_key = zmq.curve_keypair()
        self.client_sub_sock.curve_publickey = self.client_authenticator.client_public
        self.client_sub_sock.curve_secretkey = secret_key
        self.client_pub_sock.curve_publickey = self.client_authenticator.client_public
        self.client_pub_sock.curve_secretkey = secret_key

        try:

            self.assertFalse(
                await self.can_connect_to_eventbus(
                    self.client_sub_sock, self.client_pub_sock
                )
            )

        except asyncio.TimeoutError as e:

            print(f"Unexpected excepton occured: {e}")

    async def asyncTearDown(self):

        self.client_sub_sock.close()
        self.server_pub_sock.close()
        self.client_pub_sock.close()
        self.server_sub_sock
        self.client_authenticator.close()
        self.server_authenticator.close()
        self.event_bus.close()


@integration_test
class AuthIntegrationTester(IsolatedAsyncioTestCase):
    """Implements tests that ensure the authentication systema as a whole works"""

    async def can_connect(self, server: zmq.asyncio.Socket, client: zmq.asyncio.Socket):
        """Check if client can connect to server using tcp transport"""
        result = False
        iface = "tcp://127.0.0.1"
        port = server.bind_to_random_port(iface)
        client.connect("%s:%i" % (iface, port))
        msg = [b"Hello World"]
        # run poll on server twice
        # to flush spurious events
        await server.poll(100, zmq.POLLOUT)

        # Send a test msg to ensure msgs can be sent out
        if await server.poll(1000, zmq.POLLOUT):
            try:
                await server.send_multipart(msg, zmq.NOBLOCK)
            except zmq.Again:
                self.logger.warning("server set POLLOUT, but cannot send")
                return False
        else:
            return False

        # Try to receive the test msg sent above, fail if there's no msg to recv.
        if await client.poll(1000):
            try:
                rcvd_msg = await client.recv_multipart(zmq.NOBLOCK)
            except zmq.Again:
                self.logger.warning("client set POLLIN, but cannot recv")
            else:
                assert rcvd_msg == msg
                result = True
        return result

    async def asyncSetUp(self):
        # create a logger for this batch of tests
        self.logger = get_file_logger("test_auth", os.path.join(cress_path))

        # create a discovery service to communicate with a locally hosted instance of the discovery server application.
        self.container = ClientContainer()
        self.container.config.from_yaml("cress/config.yml", required=True)
        self.local_discovery_api = self.container.discovery_api()

        self.event_bus = FakeEventBus(
            pub_address=f"inproc://{EVENT_BUS_PUB_ADDR}",
            sub_address=f"inproc://{EVENT_BUS_SUB_ADDR}",
        )

        # setup server sockets
        self.server_pub_sock = Z_CTX.socket(zmq.PUB)
        self.server_sub_sock = Z_CTX.socket(zmq.SUB)
        self.server_sub_sock.subscribe(b"")

        # setup client sockets
        self.client_pub_sock = Z_CTX.socket(zmq.PUB)
        self.client_sub_sock = Z_CTX.socket(zmq.SUB)
        self.client_sub_sock.subscribe(b"")

        self.fake_event_bus_pub = Z_CTX.socket(zmq.PUB)
        self.fake_event_bus_sub = Z_CTX.socket(zmq.SUB)

        self.fake_event_bus_pub.connect(f"inproc://{EVENT_BUS_SUB_ADDR}")
        self.fake_event_bus_sub.connect(f"inproc://{EVENT_BUS_PUB_ADDR}")
        self.fake_event_bus_sub.subscribe(b"")

        # create the thing that will help configure authentication for the tests

        self.server_authenticator = self.container.authenticator_factory(
            socket_role=SERVER_ROLE
        )
        self.server_authenticator.set_socket_keys(self.server_pub_sock)
        self.server_authenticator.set_socket_keys(self.server_sub_sock)

        # bind server sockets
        self.pub_port = self.server_pub_sock.bind_to_random_port(
            f"tcp://{EVENT_BUS_PUB_ENDPOINT}"
        )
        self.sub_port = self.server_sub_sock.bind_to_random_port(
            f"tcp://{EVENT_BUS_SUB_ENDPOINT}"
        )

        # create a client authenticator
        self.client_authenticator = self.container.authenticator_factory(
            socket_role=CLIENT_ROLE
        )

        # set the keys for the client's pub socket
        self.client_sub_sock.curve_publickey = self.client_authenticator.client_public
        self.client_sub_sock.curve_secretkey = self.client_authenticator.client_secret
        self.client_sub_sock.curve_serverkey = self.server_authenticator.server_public

        # set the keys for the client's sub socket
        self.client_pub_sock.curve_publickey = self.client_authenticator.client_public
        self.client_pub_sock.curve_secretkey = self.client_authenticator.client_secret
        self.client_pub_sock.curve_serverkey = self.server_authenticator.server_public

    async def test_rev_proxy_connection(self):
        """tests that a reverse proxy can make a successful connection to a client

        In the current architecture, reverse proxies run on every node. They are listening
        for beacons from client's actively requesting workers via the multicast address space.

        The test will pass if the reverse proxy can successfully register with a locally running
        discovery server. So this test has a pre-requisite to have a local discovery server running
        at local.discovery:3000 (you may need to modify your hosts file to ensure local.discovery maps
        to 127.0.0.1)

        The test will first attempt to register a new, fake node (fake just means a random hardware uuid)
        with a made up public key. This info should be stored in the local discovery server. NOTE, you'll
        need to make sure there's a logged in user for this test.

        Once the registration completes, the fake rev proxy will attempt to connect to the listenting client.
        If this succeeds, then the test passes.

        """

        # create auth certs for the fake reverse proxy
        public_k, private_k = zmq.curve_keypair()

        # create the reverse proxy socket
        rev_proxy_sub_sock = Z_CTX.socket(zmq.SUB)
        rev_proxy_sub_sock.subscribe(b"")
        rev_proxy_sub_sock.curve_publickey = public_k
        rev_proxy_sub_sock.curve_secretkey = private_k
        rev_proxy_sub_sock.curve_serverkey = self.server_authenticator.server_public

        endpoint = EVENT_BUS_PUB_ENDPOINT
        port_num = self.pub_port

        # Attempt to register the fake rev proxy with the local instance of discovery, fail if
        # the registration returns an error
        self.local_discovery_api.register_machine(
            uuid4(), "fake reverse proxy", public_k
        )

        # Attempt to make the connection to fake client, fail the test if it times out.

        try:
            rev_proxy_connector = Connector(z_context=Z_CTX, logger=self.logger)
            await asyncio.wait_for(
                rev_proxy_connector.connect(
                    zmq_socket=rev_proxy_sub_sock,
                    sock_name="reverse proxy sub socket",
                    peer_endpoint=f"{endpoint}:{port_num}",
                    connected_event=zmq.EVENT_HANDSHAKE_SUCCEEDED,
                ),
                timeout=3.0,
            )
        except asyncio.TimeoutError:

            self.fail(
                """The test failed as the attempt to connect timed out.
                This test requires that a local discovery service is running.  """
            )

        except ConnectError:

            self.fail(
                """The test failed as the attempt to connect timed out.
                This test requires that a local discovery service is running.  """
            )

        self.assertTrue(
            await self.can_connect(self.server_pub_sock, rev_proxy_sub_sock),
            f"Could not connect client to server and successfully send a message.",
        )
        # rev_proxy_sub_sock.connect(f"tcp://{endpoint}:{port_num}")

        # cleanup resources
        rev_proxy_sub_sock.close()

    async def test_unregistered_peer_cannot_connect(self):
        """tests that the system successfully rejects a connection from a unknown peer.

        The user has to register each machine they wish to use (or manually configure)
        """
        # create auth certs for the fake reverse proxy
        public_k, private_k = zmq.curve_keypair()

        # create the reverse proxy socket
        rev_proxy_sub_sock = Z_CTX.socket(zmq.SUB)
        rev_proxy_sub_sock.subscribe(b"")
        rev_proxy_sub_sock.curve_publickey = public_k
        rev_proxy_sub_sock.curve_secretkey = private_k
        rev_proxy_sub_sock.curve_serverkey = self.server_authenticator.server_public

        endpoint = EVENT_BUS_PUB_ENDPOINT
        port_num = self.pub_port

        # Attempt to make a connection from the bad client to our fake server

        try:
            rev_proxy_connector = Connector(z_context=Z_CTX, logger=self.logger)
            await asyncio.wait_for(
                rev_proxy_connector.connect(
                    zmq_socket=rev_proxy_sub_sock,
                    sock_name="reverse proxy sub socket",
                    peer_endpoint=f"{endpoint}:{port_num}",
                    connected_event=zmq.EVENT_HANDSHAKE_SUCCEEDED,
                ),
                timeout=3.0,
            )

        # fail the test if the connection timed out as this signals something
        # wrong with the test setup/config. Probably that the local discovery service
        # isn't running.
        except asyncio.TimeoutError:

            self.fail(
                """The test failed as the attempt to connect timed out.
                This test requires that a local discovery service is running.  """
            )

        # The test passes if the connection fails with this error.
        except ConnectAuthError:

            pass  # catching the ConnectAuthError is all that's required to pass the test.

        # The test passes if a message can be sent from the server to the client.
        self.assertFalse(
            await self.can_connect(self.server_pub_sock, rev_proxy_sub_sock),
            f"Could not connect client to server and successfully send a message.",
        )

        # cleanup resources
        rev_proxy_sub_sock.close()

    async def asyncTearDown(self):

        self.client_sub_sock.close()
        self.server_pub_sock.close()
        self.client_pub_sock.close()
        self.server_sub_sock.close()
        self.client_authenticator.close()
        self.server_authenticator.close()
        self.event_bus.close()
