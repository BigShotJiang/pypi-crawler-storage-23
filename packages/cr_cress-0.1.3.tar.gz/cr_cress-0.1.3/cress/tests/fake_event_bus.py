from zmq.devices import ThreadDevice
import zmq, zmq.asyncio

from cress.event_bus import BaseEventBus


class FakeEventBus(BaseEventBus):
    def __init__(self, pub_address: str, sub_address: str):
        self.internal_event_forwarder = ThreadDevice(zmq.FORWARDER, zmq.SUB, zmq.PUB)
        self.internal_event_forwarder.context_factory = self.context_factory
        self.internal_event_forwarder.bind_out(pub_address)
        self.internal_event_forwarder.setsockopt_in(zmq.SUBSCRIBE, b"")
        self.internal_event_forwarder.bind_in(sub_address)
        self.internal_event_forwarder.daemon = True
        self.internal_event_forwarder.start()
        print(f"DEBUG:{__class__}, starting internal event forwarder")

    def context_factory(self, io_threads: int = 1):
        """Returns the zmq context used to administer pyzmq sockets."""
        return zmq.asyncio.Context.instance()

    def close(self) -> None:
        del self.internal_event_forwarder
