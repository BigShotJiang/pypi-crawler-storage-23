############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

# std python library imports
import os, asyncio, time, json
from unittest import IsolatedAsyncioTestCase

# Third party package imports
import zmq, zmq.asyncio
from zmq.devices import ThreadDevice as Device

# CRESS imports
from cress.event import Event
from cress.services import beacon
from cress.services.beacon import CLIENT_BEACON_RCVD
from cress.protocols import BeaconProtocol
from cress.context import EVENT_BUS_PUB_ADDR, EVENT_BUS_SUB_ADDR
from cress.tests.fake_event_bus import FakeEventBus

# CONSTANTS
EVENT_BUS_SUB_ENDPOINT = "127.0.0.1"
EVENT_BUS_PUB_ENDPOINT = "127.0.0.1"
Z_CTX = zmq.asyncio.Context.instance()


class TestClientEventBusBeacon(IsolatedAsyncioTestCase):
    """ """

    async def asyncSetUp(self) -> None:

        # Create a fake event bus to use in the test
        self.fake_event_bus = FakeEventBus(
            pub_address=f"inproc://{EVENT_BUS_PUB_ADDR}",
            sub_address=f"inproc://{EVENT_BUS_SUB_ADDR}",
        )

        self.fake_event_bus_sub = Z_CTX.socket(zmq.SUB)
        self.fake_event_bus_sub.connect(f"inproc://{EVENT_BUS_PUB_ADDR}")
        self.fake_event_bus_sub.subscribe(b"")

    async def test_round_trip_beacon(self) -> None:
        """Tests that multicast beacons can go to and from the machine running this test"""

        # setup a beacon and beacon listener class
        beaconer = beacon.Beacon()
        beacon_listener = beacon.BeaconListener()

        # create a fake beacon_this event and use it to cause the beaconer to
        # send a beacon
        beacon_this = Event(
            beacon.SEND_BEACON,
            bytes(json.dumps({"test_service": ("127.0.0.1", 9999)}), "utf-8"),
        )

        # send a beacon using handle_beacon_this
        await beaconer.handle_send_beacon(beacon_this)

        try:
            # receive at least one test beacon message
            # through the listener
            r_msg = beacon_listener.beacon_listening_sckt.recv(4096)
            await asyncio.wait_for(beacon_listener._handle_beacon(r_msg), 3.0)

        except asyncio.TimeoutError:

            self.fail(
                f"Test failed beacuse no beacon was received within the required three second timeout."
            )

        # exit and cleanup
        beaconer.close()
        beacon_listener.close()

    async def test_new_client_event_dispatch(self) -> None:
        """ """

        # create a beacon listener
        beacon_listener = beacon.BeaconListener()

        # create a faked received beacon
        beacon_this = Event(
            beacon.SEND_BEACON,
            bytes(json.dumps({"test_service": ("192.168.1.1", 9999)}), "utf-8"),
        )
        services = json.loads(beacon_this.value.decode("utf-8"))

        # prepare the body of the beacon
        beacon_as_bytes = BeaconProtocol.pack("test machine", services)
        # send an event with the faked beacon data
        await beacon_listener._handle_beacon(beacon_as_bytes)
        # receive the event from the fake event bus
        try:
            new_client_event = Event.deserialise(
                await asyncio.wait_for(self.fake_event_bus_sub.recv_multipart(), 3.0)
            )
            # assert the event is in the right format.
            client_beacon_rcvd_event = Event(
                CLIENT_BEACON_RCVD,
                bytes(json.dumps({"test_service": ("192.168.1.1", 9999)}), "utf-8"),
            )
            self.assertEqual(
                new_client_event,
                client_beacon_rcvd_event,
                f"The events for this test were supposed to match but didnt, {new_client_event}:{client_beacon_rcvd_event}",
            )

        except asyncio.TimeoutError:
            self.fail(
                f"Test timed out waiting for the fake event bus to deliver the required event."
            )

        finally:
            beacon_listener.close()

    async def asyncTearDown(self) -> None:

        # close the eent bus thread
        self.fake_event_bus.close()
        self.fake_event_bus_sub.close(linger=0)
