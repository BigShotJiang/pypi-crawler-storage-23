import asyncio
import os
import sys
from unittest import IsolatedAsyncioTestCase
from cress.context import ClientContext
from cress.logs import get_file_logger
from cress.service import Service
from cress.tests.utils import integration_test
from cress.config import cress_path


class PingPong(Service):
    """ """

    def __init__(self):

        super(PingPong, self).__init__(service_name="PingPong")
        # subscribe to all events from any client or service

        subs = [(b"", self.log_event)]
        self.set_subscriptions(subs)

    async def log_event(self, event):

        print(f"DEBUG: {self.name} recevied an event {event}")
        await asyncio.sleep(0)


@integration_test
class TestServiceIntegrationTests(IsolatedAsyncioTestCase):
    """ """

    async def asyncSetUp(self):
        # create a logger for this batch of tests
        self.logger = get_file_logger("test_service", os.path.join(cress_path))

        # create a CRESS client event bus so we can connect to it
        self.client_event_bus = await asyncio.create_subprocess_exec(
            *[sys.executable, "-m", "cress", "--context", "client"]
        )
        # create a context to use to connect to the event bus process
        self.client_event_bus_context = ClientContext(logger=self.logger)
        await self.client_event_bus_context.connect()

    async def test_processing_event(self):
        # create the event value
        val = bytes(json.dumps({"a value of some kind": 3}), "utf-8")

        # create a new event to test with
        new_event = Event(b"TEST-SERVICE", val)

        # Make sure that the client context subscribes to this new event
        self.client_event_bus_context.subscribe_to_event(b"TEST-SERVICE")

        # send the event
        await self.client_event_bus_context.send_event(new_event)

        # wait for the response, but timeout with an error if we exceed 3 seconds
        event = await asyncio.wait_for(self.client_event_bus_context.recv_event(), 3.0)

        await asyncio.sleep(1)

        self.assertEqual(event.value, new_event.value)

    async def asyncTearDown(self):

        print(f"{__class__} Cleaning up...")
        self.client_event_bus_context.close()

        self.client_event_bus.terminate()
        await self.client_event_bus.wait()
