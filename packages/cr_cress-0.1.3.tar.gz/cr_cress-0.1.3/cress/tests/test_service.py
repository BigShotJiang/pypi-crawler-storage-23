############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

""" This module is responsible for testing the service implementation.

The Service class provides a wrapper for implementations of useful
services in the cress system. It is subclassed and then extended
by such services.

This module tests that the implementation works as per the specification.

"""

import asyncio, sys, json, os
from unittest import IsolatedAsyncioTestCase

from cress.service import Service
from cress.event import Event
from cress.context import ClientContext
from cress.logs import get_logger, get_file_logger, EVENT_NAME
from cress.config import cress_path

from cress.tests.utils import integration_test


class MyTestService(Service):
    """A class to mock an implementation of the Service class

    This class mocks a real service implementing the Service class."""

    def __init__(self):

        super(MyTestService, self).__init__(service_name="TEST-SERVICE")
        self.logger = get_logger("tests")
        subs = [(b"TEST-SERVICE", self.reply_test_event)]
        self.set_subscriptions(subs)
        self.logger.info(
            "test service is ready", extra={EVENT_NAME: b"TEST_SERVICE_READY"}
        )

    async def reply_test_event(self, event):
        """respond to the received event."""
        print(f"{self.name} received the following event {event}.")

        await self.respond_to_event(event)


@integration_test
class TestServiceIntegrationTests(IsolatedAsyncioTestCase):
    """ """

    async def asyncSetUp(self):
        # create a logger for this batch of tests
        self.logger = get_file_logger("test_service", os.path.join(cress_path))

        # create a CRESS client event bus so we can connect to it
        self.client_event_bus = await asyncio.create_subprocess_exec(
            *[sys.executable, "-m", "cress", "--context", "client"]
        )
        # create a context to use to connect to the event bus process
        self.client_event_bus_context = ClientContext(logger=self.logger)
        await self.client_event_bus_context.connect()

    async def test_processing_event(self):
        # create the event value
        val = bytes(json.dumps({"a value of some kind": 3}), "utf-8")

        # create a new event to test with
        new_event = Event(b"TEST-SERVICE", val)

        # Make sure that the client context subscribes to this new event 
        self.client_event_bus_context.subscribe_to_event(b"TEST-SERVICE")

        # send the event
        await self.client_event_bus_context.send_event(new_event)

        # wait for the response, but timeout with an error if we exceed 3 seconds
        event = await asyncio.wait_for(self.client_event_bus_context.recv_event(), 3.0)

        await asyncio.sleep(1)

        self.assertEqual(event.value, new_event.value)

    async def asyncTearDown(self):

        print(f"{__class__} Cleaning up...")
        self.client_event_bus_context.close()

        self.client_event_bus.terminate()
        await self.client_event_bus.wait()
