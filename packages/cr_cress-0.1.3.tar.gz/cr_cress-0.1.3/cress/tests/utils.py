import os, unittest

# Skip integration tests if `INTEGRATION_TESTS` env is `False`
integration_test = unittest.skipIf(
    os.environ.get("INTEGRATION_TESTS", "True") == "False",
    "INTEGRATION_TESTS env is set to False",
)
