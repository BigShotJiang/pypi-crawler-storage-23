############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

from unittest import TestCase

from cress import config


class TestReading(TestCase):
    def setUp(self) -> None:
        return super().setUp()

    def test_read_config_defaults(self):

        services = config.read_config("common_services")

        assert "Logger" in services
