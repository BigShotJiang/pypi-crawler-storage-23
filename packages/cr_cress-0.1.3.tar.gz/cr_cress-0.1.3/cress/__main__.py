############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

# IMPORTS
import sys, os

if __name__ == "__main__":

    try:
        import cress
        import cress.startup

    except ImportError:
        cress_pkg_path = os.path.dirname(__file__)
        parent_folder_cress = os.path.dirname(cress_pkg_path)
        sys.path.append(parent_folder_cress)

        import cress
        import cress.startup

    # We can only do the agent based imports after we've set the system path.
    # parse command line arguments and start
    cress_context = cress.parse_arguments()
    cress.startup.start_cress(cress_context)
