from uuid import UUID

from cress.utils import get_machine_uuid


class CRESSInstance:
    context: str
    uuid: UUID

    def __init__(self, context: str) -> None:
        self.context = context
        self.uuid = get_machine_uuid()
