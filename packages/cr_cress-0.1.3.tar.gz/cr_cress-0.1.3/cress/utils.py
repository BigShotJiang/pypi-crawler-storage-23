############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2023> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################
""" Utility Module """

import uuid


def get_machine_uuid() -> uuid.UUID:
    """Queries the hardware UUID, falls back to NIC mac address on failure"""
    
    # FIXME: without this all local CRESS instances have same UUID
    return uuid.uuid4()

    import platform, re, os, hashlib

    # Get the highest strength encryption guaranteed on this platform.
    # Note that sha512 is always present, the others might not be but we should use them
    # over sha algorithm
    hash_func_names = ["sha3_512", "sha3_384", "sha3_256", "sha512"]

    hash_funcs = [
        hashlib.new(name)
        for name in hash_func_names
        if name in hashlib.algorithms_guaranteed
    ]

    hash_func = hash_funcs[0]

    os_type = platform.system()

    if os_type == "Darwin":

        machine_uuid_str = ""

        p = os.popen("ioreg -rd1 -c IOPlatformExpertDevice | grep -E '(UUID)'", "r")

        while 1:
            line = p.readline()
            if not line:
                break
            machine_uuid_str += line

        match_obj = re.compile(
            "[A-Z,0-9]{8,8}-"
            + "[A-Z,0-9]{4,4}-"
            + "[A-Z,0-9]{4,4}-"
            + "[A-Z,0-9]{4,4}-"
            + "[A-Z,0-9]{12,12}"
        )

        match = match_obj.findall(machine_uuid_str)[0]

        # see if we got an actual uuid or not
        try:
            uuid.UUID(match)
        # if we can't find the uuid, fall back to using the mac address
        except ValueError:

            match = str(uuid.uuid5(uuid.UUID(int=0), str(uuid.getnode())))

        hash_func.update(bytes(match, "utf-8"))

        return uuid.uuid5(uuid.UUID(int=0), hash_func.hexdigest())

    elif os_type == "Windows":

        import winreg

        cryptography = "SOFTWARE\Microsoft\Cryptography"
        hardwareconfig = "SYSTEM\HardwareConfig"

        key_crypto = None
        key_hardware = None
        mach_guid = ""
        hardw_uuid = ""

        try:
            # open keys
            key_crypto = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, cryptography)

            # get values

            mach_guid = winreg.QueryValueEx(key_crypto, "MachineGuid")[0]

        except:

            pass

        try:

            key_hardware = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, hardwareconfig)
            hardw_uuid = winreg.QueryValueEx(key_hardware, "LastConfig")[0]

        except:

            pass

        # if both attempts to get a hardware id fail, then fallback to using the
        # the mac address.

        if mach_guid == "" and hardw_uuid == "":

            mach_guid = str(uuid.getnode())

        hash_func.update(bytes(mach_guid, "utf-8"))
        hash_func.update(bytes(hardw_uuid, "utf-8"))

        return uuid.uuid5(uuid.UUID(int=0), hash_func.hexdigest())

    elif os_type == "Linux":
        # TODO, linux needs upgrading to discover the actual hardware uuid,
        # the current method
        # uses the network interface mac address, which is more likely to change
        # esp with the use of VPN adapters. Its not known to the team if the
        # vpn had a mac addr on linux and if it could override the physcial
        # interfaces.

        machine_id_paths = ["/etc/machine-id", "/var/lib/dbus/machine-id"]

        valid_machine_id_paths = [
            path for path in machine_id_paths if os.path.exists(path)
        ]

        if valid_machine_id_paths:

            f = open(valid_machine_id_paths[0], "rt")

            raw_id = f.readline().rstrip()

            machine_id = bytes(raw_id, "utf-8")

            hash_func.update(machine_id)

            return uuid.uuid5(uuid.UUID(int=0), hash_func.hexdigest())

        else:

            try:

                hash_func.update(bytes(str(uuid.getnode()), "utf-8"))

                return uuid.uuid5(uuid.UUID(int=0), hash_func.hexdigest())

            except:

                return uuid.uuid1()
