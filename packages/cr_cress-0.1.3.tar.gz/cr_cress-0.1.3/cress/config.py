############################  LICENSE  #########################

# <This file is part of the CRESS (Compure REsource Sharing System).>

# Copyright (C) <2013-2021> Crowd Render Pty Limited, Sydney Australia


# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

# You can contact the creator of Crowdrender at info at
# crowdrender dot com dot au

################################################################

import configparser, os, platform, json
import errno
from typing import Any, Dict

# define default locations for the config on various OS platforms
config_locations = {
    "Darwin": os.path.join(os.path.expanduser("~"), "Library", "Application Support"),
    "Windows": os.path.join(os.path.expandvars("$USERPROFILE")),
    "Linux": os.path.join(os.path.expanduser("~"), "config"),
}


def get_config_parser():
    """returns a config parser for the cress system"""

    # TODO: think about how having multiple processes have to access this might cause shenanigans
    config = configparser.RawConfigParser()
    # set the configparser to not convert keys to lower case, we use camelcase keys in code
    config.optionxform = lambda optionstr: optionstr

    return config


default_config = get_config_parser()

# determine the correct location for the cress folder and associated dirs like certs, db etc
cress_path = os.path.join(config_locations[platform.system()], "cress")
certs_path = os.path.join(cress_path, "certificates")

# check if the cress folder exists in the above location, create it if not
os.makedirs(cress_path, exist_ok=True)
os.makedirs(certs_path, exist_ok=True)

# use the default config path for the platform we're on.
default_config["paths"] = {}
default_config["paths"]["config"] = json.dumps(cress_path)
default_config["paths"]["config.certificates"] = json.dumps(certs_path)

# set default services that are present in every event bus context
default_config["common_services"] = {}
default_config["common_services"]["Logger"] = json.dumps("cress.services.logging")
default_config["common_services"]["Bonjour"] = json.dumps("cress.services.bonjour")

# set services that are particular to the client context
default_config["client_eventbus_services"] = {}
default_config["client_eventbus_services"]["NodeManager"] = json.dumps(
    "cress.services.node_manager"
)
default_config["client_eventbus_services"]["Beacon"] = json.dumps(
    "cress.services.beacon"
)
default_config["client_eventbus_services"]["ClientWebRTC"] = json.dumps(
    "cress.services.webrtc"
)


default_config["reverse_proxy_eventbus_services"] = {}
default_config["reverse_proxy_eventbus_services"]["ReverseProxyWebRTC"] = json.dumps(
    "cress.services.webrtc"
)

# set services used in automated testing
default_config["test_services"] = {}
default_config["test_services"]["MyTestService"] = json.dumps(
    "cress.tests.test_service"
)

# define the path where the config should be
config_file_path = os.path.join(
    json.loads(default_config["paths"]["config"]), "config.ini"
)

# make sure there is at least a default config file
if not os.path.exists(config_file_path):

    with open(config_file_path, "wt") as config_file:
        default_config.write(config_file)


def read_config(section: str) -> Dict[str, Any]:
    """read and return the config item corresponding to the key argument

    This module function is responsible for getting config items"""

    # get a config obj to parse the file contents with
    config = get_config_parser()
    try:  # try to read the config, we'll fall back to the default if it fails

        # open the config file and read the config
        with open(config_file_path, "rt") as config_file:
            config.read_file(config_file)

        result = {name: json.loads(item) for name, item in config[section].items()}

    except json.decoder.JSONDecodeError as e:

        raise ValueError(
            f'Appears that the config file is corrupt, couldn\'t decode the section "{section}" using json'
        )

    return result


def get_cr_path():
    """get the cr path from user config, or get/make from default location"""

    import os

    cr_pths = read_config("paths")
    cr_folder = cr_pths.get("cr_folder", "")

    if not os.path.exists(cr_folder):

        cr_folder = os.path.join(os.path.expanduser("~"), "cr")

        mkdir_p(cr_folder)

    return cr_folder


def mkdir_p(path):
    """Make a directory from 'path' if one doesn't exist"""

    try:
        os.makedirs(path, exist_ok=True)  # Python>3.2
    except TypeError:
        try:
            os.makedirs(path)
        except OSError as exc:  # Python >2.5
            if exc.errno == errno.EEXIST and os.path.isdir(path):
                pass
            else:
                raise
